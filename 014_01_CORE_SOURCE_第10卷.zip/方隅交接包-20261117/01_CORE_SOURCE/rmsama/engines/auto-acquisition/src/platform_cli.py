"""Frozen, account-isolated CLI dispatcher. No automatic browser-cookie extraction."""
import os
import sys
from pathlib import Path

def display_qr(data):
    import qrcode
    target=os.environ.get('WORKSPACE_QR_PATH')
    if not target: return False
    Path(target).parent.mkdir(parents=True,exist_ok=True)
    qrcode.make(data).save(target)
    print('二维码已显示在工作台，请使用平台手机 App 扫码。',flush=True)
    return True

def http_only_login(login):
    def wrapped(*args, **kwargs):
        kwargs['prefer_browser_assisted'] = False
        return login(*args, **kwargs)
    return wrapped

def main():
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'): stream.reconfigure(encoding='utf-8',errors='replace')
    if len(sys.argv)<2: raise SystemExit('Required platform: xiaohongshu or weibo')
    platform=sys.argv.pop(1)
    if platform=='xiaohongshu':
        import xhs_cli.cookies
        xhs_cli.cookies.extract_browser_cookies=lambda *a,**k:None
        import xhs_cli.qr_login
        xhs_cli.qr_login._display_qr_in_terminal=display_qr
        xhs_cli.qr_login.qrcode_login=http_only_login(xhs_cli.qr_login.qrcode_login)
        from xhs_cli.cli import cli
    elif platform=='weibo':
        import weibo_cli.auth
        weibo_cli.auth.extract_browser_credential=lambda *a,**k:None
        weibo_cli.auth._display_qr_in_terminal=display_qr
        from weibo_cli.cli import cli
    else: raise SystemExit('Unsupported platform')
    cli()

if __name__=='__main__': main()
