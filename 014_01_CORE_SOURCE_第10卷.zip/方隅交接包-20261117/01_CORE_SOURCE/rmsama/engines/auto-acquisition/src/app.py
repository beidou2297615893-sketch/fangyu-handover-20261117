"""Loopback-only desktop host. No hosted service, paid API or telemetry."""
import argparse
import base64
import json
import logging
import mimetypes
import os
from pathlib import Path
import secrets
import shutil
import sys
import subprocess
import threading
import time
import re
import urllib.request
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse, parse_qs

from core import Core, CoreError
from bridge import BridgeManager, KuaishouBridgeManager

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
ALLOWED_ASSETS = {'.png','.jpg','.jpeg','.webp','.pdf','.xlsx','.xls','.docx','.doc','.txt','.md','.csv'}

def company_config():
    external=(Path(sys.executable).parent if getattr(sys,'frozen',False) else ROOT.parent)/'company.json'
    path=external if external.exists() else ROOT/'resources'/'companies'/'fangyu.json'
    config=json.loads(path.read_text('utf-8-sig')) if path.exists() else {'id':'fangyu','name':'方隅公寓'}
    if not re.fullmatch(r'[a-z][a-z0-9_-]{1,40}',config.get('id','')): raise ValueError('企业配置ID无效')
    return config

class AppServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, data_dir):
        super().__init__(address, Handler)
        data_dir=Path(data_dir).resolve()
        self.core = Core(data_dir, ROOT/'resources')
        self.failures = {}
        self.started = time.time()
        self.company=company_config()
        self.jobs = {}
        self.job_lock = threading.Lock()
        self.closing = False
        runtime=(Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent/'work'/'runtime')/'douyin-bridge'
        self.bridge=BridgeManager(data_dir,runtime)
        self.kuaishou_bridge=KuaishouBridgeManager(data_dir,runtime.parent/'kuaishou-bridge',runtime)
        self._configure_bundled()

    def bridge_for(self,platform='douyin'):
        if platform=='douyin':return self.bridge
        if platform=='kuaishou':return self.kuaishou_bridge
        raise CoreError('该平台不使用浏览器连接服务')

    def close_owned_jobs(self):
        with self.job_lock:
            self.closing=True
            processes=[job.get('process') for job in self.jobs.values() if job.get('process')]
        for event in list(self.core.sequences.values()):event.set()
        self.core.adapters.close()
        for process in processes:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        self.bridge.close();self.kuaishou_bridge.close()

    def _configure_bundled(self):
        """Resolve runtime paths per installation, not development machine."""
        bin_dir = Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent.parent/'work'/'runtime'
        cli = bin_dir/'platform-cli'/'platform-cli.exe'
        adapter_root=self.core.store.directory/'adapters'; adapter_root.mkdir(exist_ok=True)
        for platform in ('xiaohongshu','weibo'):
            if not cli.exists(): continue
            path=adapter_root/(platform+'.json')
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':platform}
            previous.update(executable=str(cli),prefix_args=[platform],isolation_guard=True,reply_contract_verified=platform=='xiaohongshu')
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')
        dy=bin_dir/'douyin-bridge'
        if (dy/'node.exe').exists():
            path=adapter_root/'douyin.json'
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':'douyin'}
            base=json.loads((ROOT/'resources'/'adapters'/'douyin.json').read_text('utf-8-sig'))
            previous.update(executable=str(dy/'node.exe'),isolation_guard=True,reply_contract_verified=True)
            for key in ('search_args','comments_args','status_args'):
                previous[key]=[str(dy/'cli.js') if x=='cli.js' else x for x in base.get(key,[])]
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')

        ks=bin_dir/'kuaishou-bridge'
        if (ks/'cli.js').exists() and (dy/'node.exe').exists():
            path=adapter_root/'kuaishou.json'
            previous=json.loads(path.read_text('utf-8')) if path.exists() else {'id':'kuaishou'}
            base=json.loads((ROOT/'resources'/'adapters'/'kuaishou.json').read_text('utf-8-sig'))
            previous.update(executable=str(dy/'node.exe'),isolation_guard=True,reply_contract_verified=False)
            for key in ('comments_args','status_args'):
                previous[key]=[str(ks/'cli.js') if x=='cli.js' else x for x in base.get(key,[])]
            path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),'utf-8')

class Handler(BaseHTTPRequestHandler):
    server_version = 'LocalWorkspace/1.0'
    def log_message(self, fmt, *args):
        # Never log request bodies, passwords or URL query credentials.
        logging.info('%s %s',self.command,self.path.split('?')[0])
    def host_ok(self):
        return self.headers.get('Host') in ('127.0.0.1:'+str(self.server.server_port),'localhost:'+str(self.server.server_port))
    def token(self):
        try:
            cookie=SimpleCookie(self.headers.get('Cookie',''))
            return cookie['session'].value if 'session' in cookie else ''
        except Exception: return ''
    def user(self): return self.server.core.session(self.token())
    def respond(self, data, code=200, cookie=None):
        body=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.security_headers()
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        if cookie is not None: self.send_header('Set-Cookie','session='+cookie+'; HttpOnly; SameSite=Strict; Path=/'+('; Max-Age=0' if not cookie else ''))
        self.end_headers(); self.wfile.write(body)
    def security_headers(self,embed=False):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','SAMEORIGIN' if embed else 'DENY')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Cache-Control','no-store')
        ancestors="'self'" if embed else "'none'"
        self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors "+ancestors+"; object-src 'none'; base-uri 'none'")
    def file(self,path,attachment=False,embed=False):
        if not path.is_file(): self.respond({'error':'文件不存在'},404); return
        body=path.read_bytes(); self.send_response(200); self.security_headers(embed)
        self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
        self.send_header('Content-Length',str(len(body)))
        if attachment: self.send_header('Content-Disposition','attachment')
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if not self.host_ok(): self.respond({'error':'仅允许本机访问'},403); return
        path=unquote(urlparse(self.path).path)
        if path.startswith('/assets/'):
            name=path[len('/assets/'):]
            if not name or '/' in name or '\\' in name or ':' in name or Path(name).suffix.lower() not in {'.png','.webp'}:
                self.respond({'error':'图片路径无效'},403);return
            base=(ROOT/'web/assets').resolve();target=(base/name).resolve()
            if target.parent!=base:self.respond({'error':'图片路径无效'},403);return
            self.file(target);return
        if path in ('/','/index.html','/app.js','/style.css'):
            self.file(ROOT/'web'/('index.html' if path=='/' else path[1:])); return
        if path=='/health': self.respond({'app':'local-lead-workspace','version':'1.0'}); return
        if not self.user(): self.respond({'error':'请先登录'},401); return
        if path.startswith('/references/'):
            filename=Path(path).name
            self.file(ROOT/'resources'/'references'/filename); return
        if path.startswith('/qr/'):
            job=self.server.jobs.get(path.rsplit('/',1)[1])
            if not job or job.get('user_id')!=self.user()['id'] or not job.get('qr_path'):
                self.respond({'error':'二维码尚未生成'},404); return
            self.file(Path(job['qr_path'])); return
        if path.startswith('/asset/'):
            asset_id=path.rsplit('/',1)[1]
            asset=next((x for x in self.server.core.handle('list',{'entity':'assets'},self.user()) if x['id']==asset_id),None)
            if not asset: self.respond({'error':'文件不存在'},404); return
            target=Path(asset['path']).resolve()
            if not target.is_relative_to((self.server.core.store.directory/'assets').resolve()): self.respond({'error':'无权访问该路径'},403); return
            self.file(target, target.suffix.lower() not in {'.png','.jpg','.jpeg','.webp','.pdf'},embed=target.suffix.lower()=='.pdf'); return
        if path=='/help':
            self.file(ROOT/'resources'/'help.html',embed=True); return
        if path=='/bridge-script':
            user=self.user()
            if user['role']!='admin': self.respond({'error':'需要管理员权限'},403); return
            platform=parse_qs(urlparse(self.path).query).get('platform',['douyin'])[0]
            try:manager=self.server.bridge_for(platform)
            except CoreError as ex:self.respond({'error':str(ex)},400);return
            filename='方隅工作台_快手连接.user.js' if platform=='kuaishou' else '方隅工作台_抖音连接.user.js'
            self.file(manager.root(user['tenant_id'])/filename,True); return
        self.respond({'error':'页面不存在'},404)
    def do_POST(self):
        if not self.host_ok() or self.path!='/api': self.respond({'error':'不允许的请求'},403); return
        origin=self.headers.get('Origin')
        if origin and origin not in ('http://127.0.0.1:'+str(self.server.server_port),'http://localhost:'+str(self.server.server_port)):
            self.respond({'error':'不允许跨站请求'},403); return
        if self.headers.get('X-Local-App')!='1' or not self.headers.get('Content-Type','').startswith('application/json'):
            self.respond({'error':'请求格式错误'},403); return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<=0 or length>29*1024*1024: raise CoreError('请求大小超出限制')
            payload=json.loads(self.rfile.read(length)); action=payload.get('action'); data=payload.get('data') or {}
            if not isinstance(data,dict): raise CoreError('请求参数格式错误')
            core=self.server.core; user=self.user()
            if self.server.closing:raise CoreError('软件正在退出，请重新打开后操作')
            if action=='me': self.respond({'user':user}); return
            if action=='status':
                self.respond({**core.handle('status'),'company':{'id':self.server.company['id'],'name':self.server.company['name'],'industry':self.server.company.get('industry','apartment'),'platform':self.server.company.get('platform','xiaohongshu'),'theme':self.server.company.get('theme',{})}}); return
            if action=='shutdown':
                if not user or user['role']!='admin': raise CoreError('需要管理员权限')
                with self.server.job_lock:self.server.closing=True
                self.respond({'ok':True})
                def stop():
                    try:self.server.close_owned_jobs()
                    finally:self.server.shutdown()
                threading.Thread(target=stop,daemon=True).start(); return
            if action=='login':
                key=self.client_address[0]; failures=self.server.failures.get(key,[])
                failures=[x for x in failures if time.time()-x<300]
                if len(failures)>=10: raise CoreError('登录尝试过多，请 5 分钟后重试')
                try: result=core.handle(action,data)
                except CoreError: self.server.failures[key]=failures+[time.time()]; raise
                self.server.failures.pop(key,None); token=result.pop('token'); self.respond(result,cookie=token); return
            if action=='bootstrap':
                result=core.handle(action,data); self.seed(result['user']); token=result.pop('token'); self.respond(result,cookie=token); return
            if action=='logout':
                core.handle('logout',{'token':self.token()},user); self.respond({'ok':True},cookie=''); return
            if action=='upload_asset':
                if not user: raise CoreError('请先登录')
                name=Path(str(data.get('name','')).replace('\\','/')).name
                suffix=Path(name).suffix.lower()
                if suffix not in ALLOWED_ASSETS: raise CoreError('不支持的文件格式')
                raw=base64.b64decode(data.get('base64',''),validate=True)
                if len(raw)>20*1024*1024: raise CoreError('单个文件不得超过 20 MB')
                directory=core.store.directory/'assets'/user['tenant_id']; directory.mkdir(parents=True,exist_ok=True)
                target=directory/(secrets.token_hex(12)+suffix); target.write_bytes(raw)
                result=core.handle('save',{'entity':'assets','record':{'name':name,'path':str(target),'kind':data.get('kind','内部资料')}},user)
                self.respond(result); return
            if action=='diagnostics':
                if not user or user['role']!='admin': raise CoreError('需要管理员权限')
                self.respond({'platforms':[{k:v for k,v in p.items() if k in ('id','name','version','status','available','search_verified','description','verification_level')} for p in core.adapters.manifests()],'data_directory':str(core.store.directory),'paid_services':'未接入','host':'仅监听 127.0.0.1'}); return
            if action=='open_backup_folder':
                if not user or user['role']!='admin':raise CoreError('需要管理员权限')
                directory=core.store.directory/'backups';directory.mkdir(exist_ok=True)
                os.startfile(str(directory));self.respond({'path':str(directory)});return
            if action in ('bridge_start','bridge_connections'):
                if not user or user['role']!='admin': raise CoreError('需要管理员权限')
                manager=self.server.bridge_for(data.get('platform','douyin'))
                with self.server.job_lock:
                    if self.server.closing:raise CoreError('软件正在退出')
                    result=manager.start(user['tenant_id']) if action=='bridge_start' else manager.connections(user['tenant_id'])
                self.respond(result);return
            if action=='job_status':
                if not user: raise CoreError('请先登录')
                job=self.server.jobs.get(data.get('id'))
                if not job or job['user_id']!=user['id']: raise CoreError('任务不存在')
                self.respond({k:v for k,v in job.items() if k not in ('qr_path','process')}); return
            if action=='account_login':
                spec=core.handle('account_login_spec',data,user)
                job_id=secrets.token_hex(12)
                qr_dir=core.store.directory/'work'; qr_dir.mkdir(exist_ok=True)
                qr_path=qr_dir/(job_id+'.png')
                job={'id':job_id,'status':'running','user_id':user['id'],'qr_path':str(qr_path)}
                self.server.jobs[job_id]=job
                def login_run():
                    try:
                        with self.server.job_lock:
                            if self.server.closing:raise CoreError('软件正在退出')
                            proc=subprocess.Popen(spec['argv'],env={**os.environ,**spec['env'],'WORKSPACE_QR_PATH':str(qr_path)},cwd=spec['cwd'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                            job['process']=proc
                        try: proc.communicate(timeout=240)
                        except subprocess.TimeoutExpired: proc.kill(); proc.communicate(); raise CoreError('扫码登录超时，请重试')
                        if proc.returncode: raise CoreError('登录没有完成，请重试或检查网络；没有读取浏览器现有账号。')
                        job.update(status='completed',result=core.handle('account_check',data,user))
                    except Exception as ex: job.update(status='failed',error=str(ex))
                    finally: job.pop('process',None)
                threading.Thread(target=login_run,daemon=True).start(); self.respond({'login_job':job_id}); return
            if action in ('run_task','run_task_sequence','verify_adapter','account_check','send_reply','run_reply_queue'):
                if not user: raise CoreError('请先登录')
                job_id=secrets.token_hex(12)
                job={'id':job_id,'status':'running','user_id':user['id']}
                self.server.jobs[job_id]=job
                def run():
                    try:
                        if self.server.closing:raise CoreError('软件正在退出')
                        job.update(status='completed',result=core.handle(action,data,user))
                    except Exception as ex: job.update(status='failed',error=str(ex))
                threading.Thread(target=run,daemon=True).start(); self.respond({'job_id':job_id}); return
            result=core.handle(action,data,user); self.respond(result)
        except (CoreError,ValueError,TypeError) as ex: self.respond({'error':str(ex)},400)
        except Exception:
            logging.exception('request failed')
            self.respond({'error':'本地操作未完成，请查看工作台日志或联系管理员'},500)
    def seed(self,user):
        core=self.server.core
        config=self.server.company
        tenant=core.store.get('tenants',user['tenant_id'])
        tenant.update(industry=config.get('industry','公寓'),company_id=config.get('id'),business_rules=config,**config.get('profile',{}))
        core.handle('save',{'entity':'tenants','record':tenant},user)
        for template in config.get('templates',[]):
            core.handle('save',{'entity':'templates','record':{'name':template['name'],'text':template.get('content',template.get('text','')),'keywords':template.get('keywords',[])}},user)

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--data-dir'); parser.add_argument('--port',type=int,default=0); parser.add_argument('--headless','--no-browser',dest='headless',action='store_true',help=argparse.SUPPRESS); args=parser.parse_args()
    config=company_config()
    data_dir=Path(args.data_dir) if args.data_dir else Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/(config['id']+'Workspace')
    data_dir=data_dir.resolve(); data_dir.mkdir(parents=True,exist_ok=True)
    lockfile=(data_dir/'instance.lock').open('a+b')
    if os.name=='nt':
        import msvcrt
        if lockfile.tell()==0: lockfile.write(b'1'); lockfile.flush()
        lockfile.seek(0)
        try: msvcrt.locking(lockfile.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:
            try:
                running=json.loads((data_dir/'running.json').read_text('utf-8'))
                parsed=urlparse(running['url'])
                if parsed.hostname!='127.0.0.1': return
                with urllib.request.urlopen(running['url']+'/health',timeout=2) as r:
                    if json.load(r).get('app')=='local-lead-workspace' and not args.headless:
                        from desktop import focus_process_window
                        for _ in range(20):
                            if focus_process_window(running.get('pid')):break
                            time.sleep(.2)
            except Exception: pass
            return
    logging.basicConfig(filename=data_dir/'workspace.log',level=logging.INFO,encoding='utf-8',format='%(asctime)s %(levelname)s %(message)s')
    server=AppServer(('127.0.0.1',args.port),data_dir)
    url='http://127.0.0.1:'+str(server.server_port)
    (data_dir/'running.json').write_text(json.dumps({'pid':os.getpid(),'url':url,'mode':'headless-test' if args.headless else 'desktop'}),encoding='utf-8')
    if sys.stdout: print(url,flush=True)
    try:
        if args.headless:server.serve_forever(poll_interval=.5)
        else:
            from desktop import run_desktop,show_desktop_error
            try:run_desktop(server,url,data_dir,config['name']+'运营台')
            except Exception as ex:show_desktop_error(ex);raise
    except KeyboardInterrupt: pass
    finally: server.close_owned_jobs(); server.server_close(); lockfile.close()

if __name__=='__main__': main()
