"""Manage only this installation's private Douyin Bridge; never attach to legacy ports."""
import json, os, secrets, socket, subprocess, time
from pathlib import Path

class BridgeManager:
    def __init__(self,data_dir,runtime):
        self.data_dir=Path(data_dir); self.runtime=Path(runtime); self.processes={}
    def root(self,tenant): return self.data_dir/'bridge'/tenant
    def prepare(self,tenant):
        root=self.root(tenant); root.mkdir(parents=True,exist_ok=True)
        config_path=root/'config.json'
        if config_path.exists(): config=json.loads(config_path.read_text('utf-8'))
        else:
            with socket.socket() as sock:
                try: sock.bind(('127.0.0.1',19432)); port=19432
                except OSError: sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
            config={'bridge':{'host':'127.0.0.1','port':port,'token':secrets.token_hex(32),'requestTimeout':25000,'heartbeatInterval':10000,'heartbeatTimeout':30000,'heartbeatMaxFailures':3,'maxBodySize':2097152},'riskControl':{'minInterval':40,'maxInterval':55,'maxConsecutiveFailures':3},'llm':{'enabled':False}}
            config_path.write_text(json.dumps(config,indent=2),'utf-8')
        source=self.runtime/'scripts'/'douyin.user.js'
        if not source.exists(): raise ValueError('抖音组件尚未打包，请使用完整安装包')
        script=source.read_text('utf-8').replace("server: 'http://127.0.0.1:19432'", "server: 'http://127.0.0.1:"+str(config['bridge']['port'])+"'").replace("token: ''", "token: '"+config['bridge']['token']+"'")
        script=script.replace('// @name', '// @name',1)
        target=root/'方隅工作台_抖音连接.user.js'; target.write_text(script,'utf-8')
        return config,target
    def start(self,tenant):
        config,target=self.prepare(tenant)
        p=self.processes.get(tenant)
        if p and p.poll() is None: return {'running':True,'port':config['bridge']['port'],'script':target.name}
        root=self.root(tenant); (root/'logs').mkdir(exist_ok=True)
        log=open(root/'logs'/'bridge.log','ab')
        env={**os.environ,'DOUYIN_CONFIG':str(root/'config.json'),'DOUYIN_LOG_DIR':str(root/'logs'),'DOUYIN_STORAGE_DIR':str(root/'storage')}
        p=subprocess.Popen([str(self.runtime/'node.exe'),str(self.runtime/'server.js')],cwd=self.runtime,env=env,stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        log.close(); self.processes[tenant]=p
        time.sleep(.5)
        if p.poll() is not None: raise ValueError('独立连接服务未启动，请检查端口或本地日志')
        return {'running':True,'port':config['bridge']['port'],'script':target.name,'message':'独立连接服务已启动，等待你在浏览器安装连接脚本并登录。'}
    def connections(self,tenant):
        root=self.root(tenant)
        if not (root/'config.json').exists(): return []
        env={**os.environ,'DOUYIN_CONFIG':str(root/'config.json'),'DOUYIN_LOG_DIR':str(root/'logs'),'DOUYIN_STORAGE_DIR':str(root/'storage')}
        result=subprocess.run([str(self.runtime/'node.exe'),str(self.runtime/'cli.js'),'connections'],cwd=self.runtime,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode: raise ValueError('连接服务未就绪，请先启动独立连接服务')
        items=json.loads(result.stdout)
        if not isinstance(items,list): raise ValueError('连接列表格式发生变化')
        return [{k:v for k,v in x.items() if k in ('id','index','title','url','alive')} for x in items]
    def close(self):
        for proc in self.processes.values():
            if proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=5)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)

class KuaishouBridgeManager(BridgeManager):
    """Private read-only comment collector; never attaches to legacy ports or cookies."""
    def __init__(self,data_dir,runtime,node_runtime):
        super().__init__(data_dir,runtime)
        self.node=Path(node_runtime)/'node.exe'
    def root(self,tenant):return self.data_dir/'kuaishou_bridge'/tenant
    def prepare(self,tenant):
        root=self.root(tenant);root.mkdir(parents=True,exist_ok=True)
        config_path=root/'config.json'
        if config_path.exists():config=json.loads(config_path.read_text('utf-8'))
        else:
            with socket.socket() as sock:
                try:sock.bind(('127.0.0.1',19433));port=19433
                except OSError:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            config={'bridge':{'host':'127.0.0.1','port':port,'token':secrets.token_hex(32)}}
            config_path.write_text(json.dumps(config,indent=2),'utf-8')
        bridge=config.get('bridge',{})
        if bridge.get('host')!='127.0.0.1' or not isinstance(bridge.get('port'),int) or not 1024<=bridge['port']<=65535 or not isinstance(bridge.get('token'),str) or len(bridge['token'])<32:
            raise ValueError('快手独立连接配置无效，请联系管理员')
        source=self.runtime/'scripts/kuaishou-comment-collector.user.js'
        if not source.exists() or not self.node.exists():raise ValueError('快手组件尚未打包，请使用完整安装包')
        script=source.read_text('utf-8');endpoint="const SERVER = 'http://127.0.0.1:19433';";marker="const TOKEN = '';"
        if endpoint not in script or marker not in script:raise ValueError('快手连接脚本模板版本不匹配')
        script=script.replace(endpoint,"const SERVER = 'http://127.0.0.1:"+str(bridge['port'])+"';").replace(marker,'const TOKEN = '+json.dumps(bridge['token'])+';')
        target=root/'方隅工作台_快手连接.user.js';target.write_text(script,'utf-8')
        return config,target
    def environment(self,tenant):return {**os.environ,'KUAISHOU_CONFIG':str(self.root(tenant)/'config.json')}
    def start(self,tenant):
        config,target=self.prepare(tenant);proc=self.processes.get(tenant)
        if proc and proc.poll() is None:return {'running':True,'port':config['bridge']['port'],'script':target.name,'platform':'kuaishou'}
        root=self.root(tenant);(root/'logs').mkdir(exist_ok=True)
        with (root/'logs/bridge.log').open('ab') as log:
            proc=subprocess.Popen([str(self.node),str(self.runtime/'server.js')],cwd=self.runtime,env=self.environment(tenant),stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.processes[tenant]=proc;time.sleep(.5)
        if proc.poll() is not None:raise ValueError('快手独立连接服务启动失败，请检查端口或本地日志')
        self.connections(tenant)
        return {'running':True,'port':config['bridge']['port'],'script':target.name,'platform':'kuaishou','message':'快手独立评论连接已启动；安装连接脚本并打开你有权读取的视频页面。'}
    def connections(self,tenant):
        if not (self.root(tenant)/'config.json').exists():return []
        result=subprocess.run([str(self.node),str(self.runtime/'cli.js'),'connections'],cwd=self.runtime,env=self.environment(tenant),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:raise ValueError('快手连接服务未就绪，请先启动独立连接服务')
        response=json.loads(result.stdout)
        items=response.get('data',{}).get('connections') if isinstance(response,dict) and response.get('ok') else None
        if not isinstance(items,list):raise ValueError('快手连接列表格式发生变化')
        return [{'id':str(x.get('id','')),'title':str(x.get('title','')),'url':str(x.get('url','')),'alive':x.get('alive',True)} for x in items if isinstance(x,dict)]
