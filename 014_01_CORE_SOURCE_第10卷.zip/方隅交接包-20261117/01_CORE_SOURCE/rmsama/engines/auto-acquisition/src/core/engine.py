"""Portable business core; no web framework, paid service or implicit external write."""
import csv
import hashlib
import hmac
import io
import json
import secrets
import sqlite3
import threading
import time
import re
from contextlib import closing
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from .store import Store
from .adapters import Adapters, AdapterBusy
from .backups import BackupManager

class CoreError(ValueError): pass

def now(): return datetime.now().isoformat(timespec='seconds')
def password_hash(password,salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),310000).hex()
def check_password(password,stored):
    return hmac.compare_digest(password_hash(password,stored.split(':')[0]),stored)

class Core:
    ENTITIES={'tenants','users','accounts','tasks','leads','templates','assets','replies','audit','reply_queues'}
    def __init__(self,data_dir,resources_dir=None):
        self.store=Store(data_dir)
        self.resources_dir=Path(resources_dir) if resources_dir else None
        self.adapters=Adapters(self.resources_dir/'adapters' if self.resources_dir else None,self.store.directory/'adapters')
        self.lock=threading.RLock()
        self.running=set()
        self.sequences={}
        # A crash during an external write must never turn into an automatic retry.
        for reply in self.store.list('replies'):
            if reply.get('status')=='sending':
                reply.update(status='unknown',last_error='程序在发送时退出，请人工核实'); self.store.put('replies',reply)
        for queue in self.store.list('reply_queues'):
            if queue.get('status')=='running': queue.update(status='interrupted',message='程序退出，队列未自动恢复'); self.store.put('reply_queues',queue)
        for task in self.store.list('tasks'):
            if task.get('sequence_status')=='running': task.update(sequence_status='interrupted',sequence_message='程序退出，连续采集未自动恢复'); self.store.put('tasks',task)
    def _record(self,data,tenant):
        return {**data,'id':data.get('id') or uuid4().hex,'tenant_id':tenant,'created_at':data.get('created_at') or now(),'updated_at':now()}
    def _public(self,record): return {k:v for k,v in record.items() if k!='password_hash'}
    def _company(self,tenant):
        business=self.store.get('tenants',tenant) or {}
        if isinstance(business.get('business_rules'),dict): return business['business_rules']
        if self.resources_dir:
            for path in sorted((self.resources_dir/'companies').glob('*.json')):
                try: config=json.loads(path.read_text(encoding='utf-8-sig'))
                except (ValueError,OSError): continue
                if config.get('id')==business.get('company_id') or config.get('industry')==business.get('industry'): return config
        return {}
    def _classify(self,row,tenant,company=None):
        if row.get('source_type')=='note':
            row.update(grade='C',grade_reason='搜索笔记仅为候选内容，不能确认作者有客户意向'); return
        text=str(row.get('title',''))+' '+str(row.get('text',''))
        config=self._company(tenant) if company is None else company
        for rule in config.get('intentRules',[]):
            matched=[word for word in rule.get('keywords',[]) if word and word in text]
            if matched:
                row.update(grade={'high':'A','medium':'B','low':'C'}.get(rule.get('level'),'C'),grade_reason='规则判断（待人工核实）：'+rule.get('reason','')+'；命中：'+'、'.join(matched)); return
        row.update(grade='C',grade_reason='规则未命中明确需求，待人工核实')
    def _validate_reply_text(self,text):
        if not text.strip(): raise CoreError('回复内容不能为空')
        if re.search(r'\{[^{}]+\}|\{\{.*?\}\}|【(?:待填|填写|替换)[^】]*】',text): raise CoreError('回复仍含未填写的模板变量，请补齐后再审核或发送')
    def _employee_quota(self,user,tenant):
        config=self._company(tenant).get('defaultRules',{})
        limit=int(user.get('daily_send_limit') or config.get('employeeDailyReplyLimit') or 10)
        today=datetime.now().date().isoformat()
        used=sum(1 for r in self.store.list('replies',tenant) if r.get('sent_by',r.get('attempted_by'))==user['id'] and r.get('status') in ('sending','sent','unknown') and (r.get('attempted_at') or r.get('sent_at','')).startswith(today))
        if used>=limit: raise CoreError('当前员工今日回复限额已用完（%s 条）'%limit)
    def _audit(self,user,action,detail,tenant=None):
        self.store.put('audit',self._record({'actor':user.get('username','system'),'action':action,'detail':detail},tenant or user.get('tenant_id','system')))
    def _admin(self,user):
        if user.get('role')!='admin': raise CoreError('此操作需要管理员权限')
    def _scope(self,user,data):
        tenant=data.get('tenant_id') or user['tenant_id']
        if tenant!=user['tenant_id']: self._admin(user)
        if not self.store.get('tenants',tenant): raise CoreError('企业不存在')
        return tenant
    def _get(self,entity,id,tenant):
        record=self.store.get(entity,id)
        if not record or record['tenant_id']!=tenant: raise CoreError('记录不存在或无权访问')
        return record
    def session(self,token):
        if not token: return None
        with self.store.connect() as db:
            row=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
        user=self.store.get('users',row['user_id']) if row else None
        return self._public(user) if user and not user.get('disabled') else None
    def _login(self,data):
        user=next((u for u in self.store.list('users') if u['username']==data.get('username')),None)
        if not user or user.get('disabled') or not check_password(data.get('password',''),user['password_hash']): raise CoreError('账号或密码错误')
        token=secrets.token_urlsafe(32)
        with self.store.connect() as db:
            db.execute('DELETE FROM sessions WHERE expires<?',(time.time(),))
            db.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user['id'],time.time()+43200))
        self._audit(user,'login','本地登录')
        return {'token':token,'user':self._public(user)}
    def handle(self,action,data=None,user=None):
        data=data or {}
        if action in ('run_task','run_task_sequence','cancel_task','account_check','verify_adapter','send_reply','run_reply_queue','cancel_reply_queue'):
            # Long read-only CLI calls run outside the global mutation lock.
            return self._handle(action,data,user)
        with self.lock: return self._handle(action,data,user)
    def _handle(self,action,data,user):
        if action=='status': return {'initialized':bool(self.store.list('users')),'platforms':self.adapters.manifests()}
        if action=='bootstrap':
            if self.store.list('users'): raise CoreError('已完成初始化')
            if len(data.get('password',''))<10: raise CoreError('密码至少 10 位')
            username=data.get('username','').strip()
            if not username: raise CoreError('请输入管理员账号')
            tenant=self._record({'name':data.get('company_name') or '方隅公寓','industry':'apartment'},'')
            tenant['tenant_id']=tenant['id']; self.store.put('tenants',tenant)
            admin=self._record({'username':username,'role':'admin','password_hash':password_hash(data['password'])},tenant['id']); self.store.put('users',admin)
            return self._login(data)
        if action=='login': return self._login(data)
        if action=='logout':
            with self.store.connect() as db: db.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(data.get('token','').encode()).hexdigest(),))
            return {'ok':True}
        if not user: raise CoreError('请先登录')
        # Refresh permissions: callers cannot keep stale privileges after an account change.
        current=self.store.get('users',user.get('id'))
        if not current or current.get('disabled'): raise CoreError('账号已停用')
        user=self._public(current)
        tenant=self._scope(user,data)
        if action in ('account_login_spec','account_check'):
            account=self._get('accounts',data.get('id'),tenant)
            directory=self.store.directory/'accounts'/tenant/account['id']
            if action=='account_login_spec':
                self._admin(user)
                if account['platform'] in ('douyin','kuaishou'): raise CoreError('该平台请开启独立 Bridge 并绑定明确浏览器连接')
                args=self.adapters.manifest(account['platform']).get('auth_args',['login','--qrcode'])
                spec=self.adapters.account_spec(account['platform'],directory,args)
                spec['timeout']=180
                account['status']='logging_in'; self.store.put('accounts',account)
                self._audit(user,action,account['id'],tenant)
                return spec
            try:
                manifest=self.adapters.manifest(account['platform'])
                args=manifest.get('status_args',['status','--json'])
                payload=self.adapters.execute(account['platform'],args,directory)
                if account['platform'] in ('douyin','kuaishou'):
                    if not account.get('conn_id'): raise CoreError('请从连接列表明确绑定浏览器连接')
                    connections=payload.get('data',{}).get('connections',[]) if account['platform']=='kuaishou' and isinstance(payload,dict) and payload.get('ok') is True else payload
                    connected=next((x for x in connections if str(x.get('id'))==str(account['conn_id']) and (account['platform']=='kuaishou' or x.get('alive') is True)),None) if isinstance(connections,list) else None
                    account.update(status='ready' if connected else 'login_required',checked_at=now()); self.store.put('accounts',account)
                    return {'authenticated':False,'verified':False,'connected':bool(connected),'account':account,'message':'已连接指定浏览器窗口；平台登录身份仍需员工在窗口中确认' if connected else '指定浏览器连接不在线'}
                result=payload.get('data',payload) if isinstance(payload,dict) else {}
                authenticated=result.get('authenticated') is True
                verified=authenticated and account['platform']=='xiaohongshu'
                account.update(status='ready' if verified else ('credential_present' if authenticated else 'login_required'),checked_at=now())
                self.store.put('accounts',account)
                return {'authenticated':authenticated,'verified':verified,'account':account,'message':'账号联网验证通过' if verified else ('本地凭据存在，仍需验证只读搜索' if authenticated else '请先登录')}
            except Exception as exc:
                account.update(status='login_required',checked_at=now()); self.store.put('accounts',account)
                for task in self.store.list('tasks',tenant):
                    if task.get('account_id')==account['id']: task.update(status='paused',last_message='账号登录异常'); self.store.put('tasks',task)
                raise CoreError(str(exc))
        if action=='verify_adapter':
            self._admin(user)
            platform=str(data.get('platform',''))
            if platform=='kuaishou': raise CoreError('快手不支持关键词测试；请检查指定连接，并运行作品评论任务验证采集')
            if not any(x['id']==platform for x in self.adapters.manifests()): raise CoreError('未知平台')
            account=self._get('accounts',data.get('account_id'),tenant) if data.get('account_id') else None
            if not account: raise CoreError('请先创建并选择平台账号')
            if account and account.get('platform')!=platform: raise CoreError('账号平台不匹配')
            directory=self.store.directory/'accounts'/tenant/account['id'] if account else None
            try: result=self.adapters.verify(platform,data.get('keyword') or '租房',directory,account.get('conn_id') if account else None)
            except Exception as exc: raise CoreError(str(exc))
            if account: account.update(status='ready',checked_at=now()); self.store.put('accounts',account)
            self._audit(user,'verify_adapter',platform,tenant); return result
        if action=='dashboard':
            counts={e:len(self.store.list(e,tenant)) for e in ('tasks','leads','accounts','replies','assets')}
            return {'counts':counts,'tenant':self.store.get('tenants',tenant),'platforms':self.adapters.manifests()}
        if action=='list':
            entity=data.get('entity')
            if entity not in self.ENTITIES: raise CoreError('未知数据类型')
            if entity in ('users','audit','reply_queues'): self._admin(user)
            rows=self.store.list(entity,None if entity=='tenants' and user['role']=='admin' else tenant)
            return [self._public(x) for x in rows]
        if action=='save': return self._save(data,user,tenant)
        if action=='delete':
            entity=data.get('entity')
            if entity not in self.ENTITIES or entity in ('audit','replies','tenants','reply_queues'): raise CoreError('该数据不可删除')
            if entity in ('users','accounts'): self._admin(user)
            record=self._get(entity,data.get('id'),tenant)
            if entity=='users' and record['id']==user['id']: raise CoreError('不能删除当前账号')
            if entity=='tasks' and (record['id'] in self.running or record['id'] in self.sequences): raise CoreError('请先停止运行中的任务再删除')
            self.store.delete(entity,record['id']); self._audit(user,'delete',entity+':'+record['id'],tenant)
            return {'ok':True}
        if action=='import_csv':
            rows=list(csv.DictReader(io.StringIO(data.get('content','').lstrip('\ufeff'))))
            if len(rows)>20000: raise CoreError('单次最多导入 20000 条')
            for row in rows:
                if row.get('reply_status'): row['historical_reply_status']=str(row['reply_status'])+'（CSV导入，未核实）'
            return self._import(rows,tenant,user)
        if action=='export_csv':
            fields=['platform','source_id','title','author','text','url','published_at','region','grade','grade_reason','reply_status','historical_reply_status','source_type','stage','assignee','demo']
            out=io.StringIO(); writer=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore'); writer.writeheader()
            for row in self.store.list('leads',tenant):
                writer.writerow({k:("'"+str(v) if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v) for k,v in row.items()})
            return {'filename':'线索导出.csv','content':'\ufeff'+out.getvalue()}
        if action=='run_task': return self._run(data,user,tenant)
        if action=='run_task_sequence': return self._run_sequence(data,user,tenant)
        if action=='cancel_task':
            with self.lock:
                task=self._get('tasks',data.get('id'),tenant)
                event=self.sequences.get(task['id'])
                if event: event.set()
                cancelled=self.adapters.cancel(task['id'])
                task.update(status='paused',last_message='已请求暂停')
                if event: task.update(sequence_status='stopped',sequence_message='已请求暂停连续采集')
                self.store.put('tasks',task)
            self._audit(user,'cancel_task',task['id'],tenant)
            return {'cancelled':cancelled,'status':'paused'}
        if action=='resume_task':
            task=self._get('tasks',data.get('id'),tenant)
            if task['id'] in self.running or task['id'] in self.sequences: raise CoreError('任务仍在结束中，请稍后恢复')
            task.update(status='ready',last_message='已恢复，可继续下一批'); self.store.put('tasks',task)
            self._audit(user,'resume_task',task['id'],tenant); return task
        if action=='suggest_reply':
            lead=self._get('leads',data.get('lead_id'),tenant)
            text=str(lead.get('title',''))+' '+str(lead.get('text',''))
            base=self._company(tenant).get('templates',[])
            industry=self.store.get('tenants',tenant).get('industry')
            templates=[t for t in self.store.list('templates',tenant) if not t.get('industry') or t['industry']==industry] or base
            templates=[{**t,'keywords':t.get('keywords') or next((x.get('keywords',[]) for x in base if x.get('name')==t.get('name')),[])} for t in templates]
            match=next((t for t in templates if any(word in text for word in t.get('keywords',[]))),None)
            if not match: raise CoreError('没有匹配的规则模板，请人工撰写草稿')
            company_name=self.store.get('tenants',tenant).get('name','')
            body=str(match.get('text') or match.get('content') or '').replace('{公司名称}',company_name).replace('{企业名称}',company_name)
            business=self.store.get('tenants',tenant)
            for field in self._company(tenant).get('profileSchema',[]):
                if not isinstance(field,dict) or not field.get('label') or not field.get('key'): continue
                value=business.get(field['key'])
                if value is not None and str(value).strip(): body=body.replace('{'+str(field['label'])+'}',str(value))
            return self._reply('draft_reply',{'lead_id':lead['id'],'text':body},user,tenant)
        if action=='run_reply_queue': return self._reply_queue(data,user,tenant)
        if action=='cancel_reply_queue':
            self._admin(user)
            queue=self._get('reply_queues',data.get('id'),tenant)
            queue.update(status='cancelled',message='已取消后续发送；正在执行的单条需等待结果'); self.store.put('reply_queues',queue)
            self._audit(user,'cancel_reply_queue',queue['id'],tenant); return queue
        if action in ('draft_reply','approve_reply','copy_reply','mark_reply_sent','send_reply'): return self._reply(action,data,user,tenant)
        if action=='backup':
            self._admin(user)
            result=BackupManager(self.store).create()
            self._audit(user,'backup',result['path']); return result
        if action=='restore':
            self._admin(user)
            if self.running or self.sequences or any(x.get('status')=='sending' for x in self.store.list('replies')) or any(x.get('status')=='running' for x in self.store.list('reply_queues')): raise CoreError('仍有任务或发送正在运行，请完成或暂停后再恢复')
            if not check_password(data.get('password',''),current['password_hash']): raise CoreError('管理员密码错误')
            path=Path(data.get('path','')).resolve(); root=(self.store.directory/'backups').resolve()
            if path.parent!=root or not path.is_file(): raise CoreError('只能恢复本工作区 backups 内的备份')
            result=BackupManager(self.store).restore(path)
            restored_tenants=self.store.list('tenants')
            self._audit(user,'restore',str(path),restored_tenants[0]['id'] if restored_tenants else user['tenant_id']); return result
        raise CoreError('未知操作：'+str(action))
    def _save(self,data,user,tenant):
        entity=data.get('entity'); incoming=dict(data.get('record') or {})
        incoming.pop('created_at',None); incoming.pop('updated_at',None)
        if entity not in self.ENTITIES or entity in ('audit','replies','reply_queues'): raise CoreError('不可直接写入该数据')
        if entity in ('users','tenants','accounts'): self._admin(user)
        old=self._get(entity,incoming['id'],tenant) if incoming.get('id') else {}
        record=self._record({**old,**incoming},tenant)
        if entity=='tenants':
            record['tenant_id']=record['id']
            if old and old.get('industry')!=record.get('industry'):
                supplied=incoming.get('business_rules')
                config=supplied if isinstance(supplied,dict) and supplied.get('industry')==record.get('industry') else None
                if self.resources_dir and config is None:
                    for path in sorted((self.resources_dir/'companies').glob('*.json')):
                        candidate=json.loads(path.read_text('utf-8-sig'))
                        if candidate.get('industry')==record.get('industry'): config=candidate; break
                if not config: raise CoreError('该行业没有已安装配置，请先通过交付工厂添加行业组件')
                for template in self.store.list('templates',tenant):
                    if not template.get('industry'): template['industry']=old.get('industry'); self.store.put('templates',template)
                record.update(business_rules=config,company_id=config.get('id'))
        if entity=='users':
            if not old:
                limit=int(self._company(tenant).get('employeeLimit') or 10)
                if len(self.store.list('users',tenant))>=limit: raise CoreError('当前企业员工数量已达到配置上限（%s 人）'%limit)
            if 'daily_send_limit' in record:
                record['daily_send_limit']=int(record['daily_send_limit'])
                if not 1<=record['daily_send_limit']<=1000: raise CoreError('员工每日回复限额必须为 1—1000')
            record.pop('password_hash',None)
            record['username']=str(record.get('username','')).strip()
            if not record['username']: raise CoreError('账号不能为空')
            if record.get('role') not in ('admin','operator'): raise CoreError('员工角色无效')
            if any(x['username']==record['username'] and x['id']!=record['id'] for x in self.store.list('users')): raise CoreError('账号已存在')
            if record['id']==user['id'] and (record.get('role')!='admin' or record.get('disabled')): raise CoreError('不能降级或停用当前管理员')
            password=record.pop('password','')
            if password and len(password)<10: raise CoreError('密码至少 10 位')
            record['password_hash']=password_hash(password) if password else old.get('password_hash')
            if not record['password_hash']: raise CoreError('新员工必须设置密码')
        if entity=='tasks':
            record.setdefault('scope','search')
            if record['scope'] not in ('search','comments'): raise CoreError('任务范围必须为 search 或 comments')
            if record.get('platform')=='kuaishou' and record['scope']!='comments': raise CoreError('快手当前只支持指定作品评论，不支持关键词搜索')
            if record['scope']=='comments':
                expected='https://www.douyin.com/video/' if record.get('platform')=='douyin' else (('https://www.kuaishou.com/short-video/','https://www.kuaishou.com/photo/') if record.get('platform')=='kuaishou' else 'https://www.xiaohongshu.com/')
                if not str(record.get('note_url','')).startswith(expected): raise CoreError('评论任务需填写对应平台完整内容链接')
            if record.get('platform')=='kuaishou':
                record['max_pages']=int(record.get('max_pages',3))
                if not 1<=record['max_pages']<=10: raise CoreError('快手单批评论页数必须为 1—10')
            for key in ('keywords','excludes'):
                value=record.get(key,[]); record[key]=[x.strip() for x in value.split(',') if x.strip()] if isinstance(value,str) else value
                if not isinstance(record[key],list): raise CoreError('关键词必须为列表')
            for key,default in [('time_start','00:00'),('time_end','23:59')]:
                record.setdefault(key,default)
                try: datetime.strptime(record[key],'%H:%M')
                except ValueError: raise CoreError('运行时间格式必须 HH:MM')
            for key in ('date_from','date_to'):
                if record.get(key):
                    try: datetime.strptime(record[key],'%Y-%m-%d')
                    except ValueError: raise CoreError('日期格式必须 YYYY-MM-DD')
            record['daily_limit']=int(record.get('daily_limit') or 20)
            if not 1<=record['daily_limit']<=1000: raise CoreError('每日限额范围 1—1000')
            record.setdefault('unknown_policy','exclude'); record.setdefault('status','ready')
            record['target_count']=int(record.get('target_count') or 100)
            if not 1<=record['target_count']<=10000: raise CoreError('目标总量范围 1—10000')
            record.setdefault('next_page',1)
        if entity=='assets':
            root=(self.store.directory/'assets'/tenant).resolve()
            path=Path(record.get('path','')).resolve()
            if not path.is_relative_to(root) or not path.is_file(): raise CoreError('素材必须位于当前企业专属素材目录且文件存在')
            record['path']=str(path)
        if entity=='templates': record.setdefault('industry',self.store.get('tenants',tenant).get('industry'))
        if entity=='leads':
            if incoming.get('reply_status') and incoming['reply_status']!=old.get('reply_status','未回复'): raise CoreError('回复状态只能通过审核发送流程改变')
            if old and any(record.get(k)!=old.get(k) for k in ('platform','source_id','task_id','comment_id','note_url','source_type')): raise CoreError('线索来源不可更改')
            if not old:
                self._validate_lead(record); self._classify(record,tenant)
                if not self.store.insert_lead(record): raise CoreError('该来源线索已存在')
                self._audit(user,'create_lead',record['id'],tenant); return record
        self.store.put(entity,record)
        if entity=='users' and (incoming.get('password') or record.get('disabled') or (old and old.get('role')!=record.get('role'))):
            with self.store.connect() as db: db.execute('DELETE FROM sessions WHERE user_id=?',(record['id'],))
        self._audit(user,'save',entity+':'+record['id'],tenant)
        return self._public(record)
    def _validate_lead(self,row):
        row['platform']=str(row.get('platform') or 'xiaohongshu')
        row['source_id']=str(row.get('source_id') or row.get('url') or '').strip()
        if not row['source_id']: raise CoreError('线索缺少来源 ID 或原帖链接')
        row.setdefault('stage','待跟进'); row.setdefault('reply_status','未回复'); row.setdefault('grade','C')
    def _import(self,rows,tenant,user):
        prepared=[]
        company=self._company(tenant)
        allowed={'platform','source_id','title','author','text','url','published_at','region','grade','stage','assignee','task_id','demo','comment_id','note_url','author_id','source_type','historical_reply_status','parent_id'}
        for row in rows:
            record=self._record({k:v for k,v in row.items() if k in allowed},tenant); self._validate_lead(record); self._classify(record,tenant,company); prepared.append(record)
        imported=self.store.insert_leads(prepared)
        self._audit(user,'import',{'imported':imported,'duplicates':len(rows)-imported},tenant)
        return {'imported':imported,'duplicates':len(rows)-imported}
    def _run(self,data,user,tenant,sequence_event=None):
        task=self._get('tasks',data.get('id'),tenant)
        with self.lock:
            if task['id'] in self.sequences and self.sequences[task['id']] is not sequence_event: raise CoreError('该任务正在连续执行，请先暂停连续任务')
            if task['id'] in self.running: raise CoreError('该任务正在运行，请勿重复启动')
            self.running.add(task['id'])
        try: return self._run_inner(data,user,tenant,task)
        finally:
            with self.lock: self.running.discard(task['id'])
    def _sequence_wait(self,event):
        return event.wait(10)

    def _run_sequence(self,data,user,tenant):
        task=self._get('tasks',data.get('id'),tenant)
        batches=int(data.get('max_batches',50))
        if not 1<=batches<=50: raise CoreError('连续执行单次最多 50 批')
        if task.get('status')=='paused': raise CoreError('任务已暂停，请先明确恢复任务')
        event=threading.Event()
        with self.lock:
            if task['id'] in self.running or task['id'] in self.sequences: raise CoreError('该任务已在执行，不能重复启动连续采集')
            self.sequences[task['id']]=event
            task.update(sequence_status='running',sequence_batches=0,sequence_message='开始连续采集，每批间隔至少 10 秒')
            self.store.put('tasks',task)
        zero_batches=0; imported=0; duplicates=0; final_status='stopped'; message='已达到本次连续执行批数上限'
        try:
            for index in range(batches):
                if event.is_set(): message='用户已暂停连续采集'; break
                current=self.store.get('users',user['id'])
                if not current or current.get('disabled'): message='操作员工已停用，连续采集停止'; break
                task=self._get('tasks',task['id'],tenant)
                if task.get('status')=='paused': message='任务已暂停'; break
                try: result=self._run({'id':task['id']},self._public(current),tenant,sequence_event=event)
                except CoreError as exc: message=str(exc); break
                imported+=result.get('imported',0); duplicates+=result.get('duplicates',0)
                with self.lock:
                    task=self._get('tasks',task['id'],tenant)
                    task.update(sequence_batches=index+1,sequence_message='已执行 %s 批，本次新增 %s 条'%(index+1,imported))
                    self.store.put('tasks',task)
                if event.is_set(): message='用户已暂停连续采集'; break
                if result.get('status')=='blocked': message=result.get('message','采集异常'); break
                if result.get('exhausted'):
                    final_status='completed'; message='返回数据已无下一批'; break
                if int(result.get('accumulated',0))>=int(task.get('target_count',100)):
                    final_status='completed'; message='已达到任务目标总量'; break
                today=datetime.now().date().isoformat()
                daily_count=sum(1 for lead in self.store.list('leads',tenant) if lead.get('task_id')==task['id'] and lead.get('created_at','').startswith(today))
                if daily_count>=int(task.get('daily_limit',20)): message='已达到今天的线索上限'; break
                zero_batches=zero_batches+1 if not result.get('imported') else 0
                if zero_batches>=3: message='连续 3 批无新增线索，停止连续采集'; break
                if index+1<batches and self._sequence_wait(event): message='用户已暂停连续采集'; break
        except Exception as exc: message='连续采集停止：'+str(exc)
        finally:
            with self.lock:
                task=self._get('tasks',task['id'],tenant)
                task.update(sequence_status=final_status,sequence_message=message)
                self.store.put('tasks',task); self.sequences.pop(task['id'],None)
            self._audit(user,'task_sequence',{'task_id':task['id'],'batches':task.get('sequence_batches',0),'message':message},tenant)
        return {'status':final_status,'message':message,'batches':task.get('sequence_batches',0),'imported':imported,'duplicates':duplicates,'task':task}
    def _run_inner(self,data,user,tenant,task):
        current=datetime.now().strftime('%H:%M'); start=task.get('time_start','00:00'); end=task.get('time_end','23:59')
        in_hours=start<=current<=end if start<=end else current>=start or current<=end
        if not in_hours: raise CoreError('当前不在任务运行时段')
        if task.get('status')=='paused': raise CoreError('任务已暂停，请先恢复任务')
        today=datetime.now().date().isoformat()
        used=sum(1 for x in self.store.list('leads',tenant) if x.get('task_id')==task['id'] and x.get('created_at','').startswith(today))
        remaining=int(task.get('daily_limit',20))-used
        if remaining<=0: raise CoreError('已达到今天的线索上限')
        accumulated=sum(1 for x in self.store.list('leads',tenant) if x.get('task_id')==task['id'])
        remaining=min(remaining,int(task.get('target_count',100))-accumulated)
        if remaining<=0: raise CoreError('已达到任务目标总量')
        if task.get('exhausted') and not data.get('demo'): raise CoreError('上次返回已无更多数据，请新建检索任务')
        try:
            if data.get('demo'):
                items=[{'platform':task.get('platform','xiaohongshu'),'source_id':'demo-'+task['id'],'title':'【演示】想找通勤方便的公寓','text':'【演示数据，不是真实客户】预算和区域待确认','demo':True}]
            else:
                if task.get('account_id'):
                    account=self._get('accounts',task['account_id'],tenant)
                    if account.get('status') not in ('ready','已登录','正常'): raise RuntimeError('账号未确认登录，任务已暂停')
                    if account.get('platform')!=task.get('platform'): raise RuntimeError('账号平台与任务不一致')
                    task['_account_dir']=str(self.store.directory/'accounts'/tenant/account['id'])
                    if account.get('platform') in ('douyin','kuaishou'):
                        if not account.get('conn_id'): raise RuntimeError('该平台账号必须绑定明确的浏览器连接')
                        task['_conn_id']=str(account['conn_id'])
                else: raise RuntimeError('请先选择隔离账号并确认登录')
                items=self.adapters.comments(task.get('platform'),task) if task.get('scope')=='comments' else self.adapters.search(task.get('platform'),task)
                task.pop('_account_dir',None)
                task.pop('_conn_id',None)
            selected=[]; duplicates=0
            existing={(x.get('platform'),x.get('source_id')) for x in self.store.list('leads',tenant)}
            for item in items:
                if not data.get('demo'):
                    text=' '.join(str(item.get(x,'')) for x in ('title','text'))
                    if any(word in text for word in task.get('excludes',[])): continue
                    if task.get('keywords') and not any(word in text for word in task['keywords']): continue
                    exclude=False
                    for field,expected in [('region',task.get('region')),('published_at',task.get('date_from') or task.get('date_to'))]:
                        if not expected: continue
                        value=item.get(field)
                        if not value:
                            if task.get('unknown_policy','exclude')!='keep': exclude=True
                        elif field=='region' and expected not in str(value): exclude=True
                        elif field=='published_at':
                            date=str(value)[:10]
                            try: datetime.strptime(date,'%Y-%m-%d')
                            except ValueError:
                                if task.get('unknown_policy','exclude')!='keep': exclude=True
                                continue
                            if task.get('date_from') and date<task['date_from']: exclude=True
                            if task.get('date_to') and date>task['date_to']: exclude=True
                    if exclude: continue
                item['task_id']=task['id']; item['platform']=task.get('platform','xiaohongshu')
                item.setdefault('source_type','comment' if task.get('scope')=='comments' else 'note')
                source=(item['platform'],str(item.get('source_id') or item.get('url') or ''))
                if source in existing: duplicates+=1; continue
                existing.add(source); selected.append(item)
            with self.lock:
                latest=self._get('tasks',task['id'],tenant)
                if latest.get('status')=='paused': raise RuntimeError('任务已暂停，采集结果未导入')
                page_complete=len(selected)<=remaining
                result=self._import(selected[:remaining],tenant,user); result['duplicates']+=duplicates
                accumulated+=result['imported']; info=task.pop('_page_info',{})
                if page_complete and not data.get('demo'):
                    if task.get('scope')=='comments':
                        cursor=info.get('cursor','')
                        task['exhausted']=info.get('has_more') is False or not cursor
                        task['next_cursor']=cursor
                    elif task.get('platform')=='xiaohongshu':
                        task['next_page']=int(task.get('next_page',1))+1
                        task['exhausted']=info.get('has_more') is False or not items
                    else: task['exhausted']=True
                task.update(status='ready',last_run=now(),accumulated=accumulated,last_message='演示完成' if data.get('demo') else '本批导入 %s 条，累计 %s / %s；%s'%(result['imported'],accumulated,task.get('target_count',100),'已无下一页' if task.get('exhausted') else '可继续下一批'))
                self.store.put('tasks',task); return {**result,'status':'demo' if data.get('demo') else 'completed','message':task['last_message'],'accumulated':accumulated,'next_page':task.get('next_page'),'exhausted':task.get('exhausted',False)}
        except Exception as exc:
            task.pop('_account_dir',None)
            task.pop('_conn_id',None)
            task.pop('_page_info',None)
            task.update(status='paused',last_message=str(exc),last_run=now()); self.store.put('tasks',task)
            self._audit(user,'task_blocked',str(exc),tenant)
            return {'status':'blocked','imported':0,'duplicates':0,'message':str(exc)}
    def _reply(self,action,data,user,tenant):
        if action=='draft_reply':
            lead=self._get('leads',data.get('lead_id'),tenant)
            text=str(data.get('text','')).strip()
            if not text: raise CoreError('回复内容不能为空')
            existing=[r for r in self.store.list('replies',tenant) if r.get('lead_id')==lead['id'] and r.get('status') in ('sent','unknown')]
            if existing: raise CoreError('该线索已发送或结果不明，不可重复创建发送')
            reply=self._record({'lead_id':lead['id'],'text':text,'status':'draft','author_id':user['id']},tenant)
        else:
            reply=self._get('replies',data.get('id'),tenant); lead=self._get('leads',reply['lead_id'],tenant)
            if action=='send_reply': return self._send_reply(data,user,tenant,reply,lead)
            if action=='approve_reply':
                self._admin(user)
                if reply['status']!='draft': raise CoreError('仅草稿可以审核')
                self._validate_reply_text(reply['text'])
                reply.update(status='approved',approved_by=user['id'])
            elif action=='copy_reply':
                if reply['status'] not in ('approved','copied'): raise CoreError('回复必须先通过管理员审核')
                self._validate_reply_text(reply['text']); self._employee_quota(user,tenant)
                reply['status']='copied'
            elif action=='mark_reply_sent':
                if data.get('confirmed') is not True or reply['status']!='copied': raise CoreError('请复制审核后的回复，并明确确认已人工发送')
                if any(x.get('lead_id')==lead['id'] and x.get('status') in ('sent','unknown') for x in self.store.list('replies',tenant)): raise CoreError('该线索已有发送记录，禁止重复发送')
                self._validate_reply_text(reply['text']); self._employee_quota(user,tenant)
                reply.update(status='sent',sent_at=now(),sent_by=user['id']); lead['reply_status']='sent'; self.store.put('leads',lead)
        reply['updated_at']=now(); self.store.put('replies',reply); self._audit(user,action,reply['id'],tenant)
        return {'text':reply['text'],'url':lead.get('url',''),'reply':reply} if action=='copy_reply' else reply

    def _send_reply(self,data,user,tenant,reply,lead):
        with self.lock:
            reply=self._get('replies',reply['id'],tenant)
            lead=self._get('leads',reply['lead_id'],tenant)
            context=self._prepare_send(data,user,tenant,reply,lead)
        if context is None: return reply
        account,task,directory=context
        error=None; busy=False
        try:
            sending_lead={**lead,'_conn_id':account.get('conn_id')}
            result=self.adapters.send(account['platform'],sending_lead,reply['text'],directory)
            if not isinstance(result,dict) or result.get('success') is not True: raise RuntimeError('发送适配器未返回明确成功，必须人工核实')
        except AdapterBusy as exc: error=str(exc); busy=True
        except Exception as exc: error=str(exc)
        with self.lock:
            if error is None:
                reply.update(status='sent',sent_at=now(),sent_by=user['id']); lead['reply_status']='sent'; self.store.put('leads',lead)
            elif busy:
                reply.update(status='approved',last_error=error)
                for key in ('attempted_at','attempted_by','account_id','idempotency_key'): reply.pop(key,None)
            else:
                reply.update(status='unknown',last_error=error); account['status']='check_required'; self.store.put('accounts',account)
                if task: task.update(status='paused',last_message='发送结果不明，请核实'); self.store.put('tasks',task)
            self.store.put('replies',reply); self._audit(user,'send_result',{'id':reply['id'],'status':reply['status']},tenant)
        return reply

    def _prepare_send(self,data,user,tenant,reply,lead):
        if data.get('authorized') is not True: raise CoreError('需明确确认本条内容的真实对外发送')
        if reply['status']=='sent': return None
        if reply['status'] not in ('approved','copied'): raise CoreError('仅审核通过的回复可发送；结果不明不可重试')
        self._validate_reply_text(reply['text']); self._employee_quota(user,tenant)
        if any(r['id']!=reply['id'] and r.get('lead_id')==lead['id'] and r.get('status') in ('sending','sent','unknown') for r in self.store.list('replies',tenant)): raise CoreError('该线索已有发送记录，禁止重复发送')
        account=self._get('accounts',data.get('account_id'),tenant)
        if account.get('platform')=='kuaishou': raise CoreError('快手适配器仅支持读取评论；请使用审核后复制、人工回复流程')
        if account.get('status')!='ready' or account.get('platform')!=lead.get('platform'): raise CoreError('账号未登录或平台不匹配')
        if lead.get('demo'): raise CoreError('演示线索禁止外部发送')
        task=self._get('tasks',lead['task_id'],tenant) if lead.get('task_id') else {}
        if task.get('status')=='paused': raise CoreError('原任务已暂停，不能发送')
        current=datetime.now().strftime('%H:%M'); start=task.get('time_start','00:00'); end=task.get('time_end','23:59')
        if not (start<=current<=end if start<=end else current>=start or current<=end): raise CoreError('当前不在运行时段')
        today=datetime.now().date().isoformat()
        sent=sum(1 for r in self.store.list('replies',tenant) if r.get('account_id')==account['id'] and r.get('status') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))
        if sent>=int(account.get('daily_send_limit') or 20): raise CoreError('该账号今日发送额度已用完')
        directory=self.store.directory/'accounts'/tenant/account['id']
        manifest=self.adapters.manifest(account['platform'])
        if not manifest.get('reply_contract_verified') or not manifest.get('isolation_guard'): raise CoreError('发送适配器契约或账号隔离尚未验证')
        if not lead.get('comment_id') or not lead.get('note_url'): raise CoreError('此线索缺少可回复的评论来源')
        if account['platform']=='douyin' and not account.get('conn_id'): raise CoreError('请先绑定明确的抖音浏览器连接')
        reply.update(status='sending',attempted_at=now(),attempted_by=user['id'],account_id=account['id'],idempotency_key=reply['id'])
        self.store.put('replies',reply); self._audit(user,'send_attempt',reply['id'],tenant)
        return account,task,directory

    def _reply_queue(self,data,user,tenant):
        self._admin(user)
        ids=data.get('reply_ids')
        if data.get('authorized') is not True: raise CoreError('管理员必须明确授权本次已审批回复队列')
        if not isinstance(ids,list) or not 1<=len(ids)<=20 or len(set(ids))!=len(ids): raise CoreError('队列须包含 1—20 条互不重复的回复 ID')
        account=self._get('accounts',data.get('account_id'),tenant)
        with self.lock:
            for id in ids:
                reply=self._get('replies',id,tenant)
                if reply.get('status') not in ('approved','copied'): raise CoreError('队列中含未经审批、已发送或结果不明的回复')
                self._validate_reply_text(reply['text'])
            queue=self._record({'reply_ids':ids,'account_id':account['id'],'authorized_by':user['id'],'status':'running','sent':0,'processed':0,'message':'顺序处理已审批队列'},tenant)
            self.store.put('reply_queues',queue); self._audit(user,'authorize_reply_queue',queue['id'],tenant)
        for id in ids:
            queue=self._get('reply_queues',queue['id'],tenant)
            if queue['status']!='running': return queue
            try:
                current=self.store.get('users',user['id'])
                if not current or current.get('disabled') or current.get('role')!='admin': raise CoreError('队列授权管理员已停用或降级')
                reply=self._get('replies',id,tenant); lead=self._get('leads',reply['lead_id'],tenant)
                result=self._send_reply({'id':id,'account_id':account['id'],'authorized':True},current,tenant,reply,lead)
                queue=self._get('reply_queues',queue['id'],tenant)
                queue['processed']+=1
                if result['status']=='sent': queue['sent']+=1
                else: queue.update(status='stopped',message='发送结果不明，队列已停止，禁止自动重试' if result['status']=='unknown' else '账号通道忙，本条未发送，队列已停止')
            except Exception as exc:
                queue=self._get('reply_queues',queue['id'],tenant); queue.update(status='stopped',message=str(exc))
            self.store.put('reply_queues',queue)
            if queue['status']!='running': return queue
        queue.update(status='completed',message='本次已审批队列处理完成'); self.store.put('reply_queues',queue)
        return queue
