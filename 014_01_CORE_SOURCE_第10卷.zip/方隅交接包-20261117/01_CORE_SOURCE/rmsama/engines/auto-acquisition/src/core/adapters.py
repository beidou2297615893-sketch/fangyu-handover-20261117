"""Explicit, replaceable command adapters. Never access browser cookies."""
import json
import shutil
import subprocess
import os
import re
import time
import threading
from datetime import datetime
from html import unescape
from pathlib import Path
from uuid import uuid4

PLATFORMS = [('xiaohongshu','小红书'),('douyin','抖音'),('kuaishou','快手'),('weibo','微博')]
BUILTIN_IDS={item[0] for item in PLATFORMS}

def safe_platform_id(value):
    return isinstance(value,str) and re.fullmatch(r'[a-z][a-z0-9_-]{1,63}',value) is not None

class AdapterBusy(RuntimeError): pass

class Adapters:
    def __init__(self, root, local_root=None):
        self.root = Path(root) if root else None
        self.local_root = Path(local_root) if local_root else None
        self.processes={}
        self.job_processes={}
        self.lifecycle_lock=threading.Lock()
        self.closed=False
        self.close_event=threading.Event()
        self.channel_locks={}
        self.channel_guard=threading.Lock()
        self.last_send={}

    def manifest(self,platform):
        if not safe_platform_id(platform): raise RuntimeError('平台 ID 不安全或格式无效')
        item=next((x for x in self.manifests() if x['id']==platform),None)
        if not item or not item.get('available'): raise RuntimeError('平台 CLI 未安装或路径未配置')
        return item

    def account_spec(self,platform,account_dir,args):
        manifest=self.manifest(platform)
        generic=platform not in BUILTIN_IDS
        if not manifest.get('isolation_guard') or (generic and manifest.get('account_mode')!='isolated_home'):
            raise RuntimeError('此适配器尚未验证账号隔离保护，不能使用员工账号执行')
        if generic and manifest.get('mapper')!='standard_json': raise RuntimeError('通用适配器必须显式声明 standard_json，不能借用未验证的平台协议')
        root=Path(account_dir).resolve(); root.mkdir(parents=True,exist_ok=True)
        env={**(manifest.get('env',{}) if not generic else {}),'HOME':str(root),'USERPROFILE':str(root),'XDG_CONFIG_HOME':str(root/'.config'),'APPDATA':str(root/'AppData'/'Roaming'),'LOCALAPPDATA':str(root/'AppData'/'Local'),'LEADSTUDIO_ISOLATED':'1','PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8'}
        if platform=='douyin':
            config_dir=root.parents[2]/'bridge'/root.parent.name
            if not (config_dir/'config.json').is_file(): raise RuntimeError('请先在工作台开启本企业独立抖音 Bridge')
            env.update(DOUYIN_CONFIG=str(config_dir/'config.json'),DOUYIN_LOG_DIR=str(config_dir/'logs'),DOUYIN_STORAGE_DIR=str(config_dir/'storage'))
        elif platform=='kuaishou':
            config_dir=root.parents[2]/'kuaishou_bridge'/root.parent.name
            if not (config_dir/'config.json').is_file(): raise RuntimeError('请先在工作台开启本企业独立快手 Bridge')
            env['KUAISHOU_CONFIG']=str(config_dir/'config.json')
        return {'argv':[manifest['executable']]+list(manifest.get('prefix_args',[]))+list(args),'env':env,'cwd':str(root)}

    def execute(self,platform,args,account_dir=None,job_id=None,timeout=35):
        with self.lifecycle_lock:
            if self.closed: raise RuntimeError('工作台正在关闭，不能启动新的 CLI 操作')
        if platform in ('douyin','kuaishou') and account_dir:
            # A private Bridge process is conservatively one channel, including
            # multiple account records bound to the same browser connection.
            channel=platform+':'+str(Path(account_dir).resolve().parent)
        else: channel=platform+':'+str(Path(account_dir).resolve() if account_dir else 'unscoped')
        with self.channel_guard: lock=self.channel_locks.setdefault(channel,threading.Lock())
        if not lock.acquire(blocking=False): raise AdapterBusy('该账号或浏览器连接正在执行其他操作，请稍后重试；本次未执行')
        try:
            is_send=platform=='xiaohongshu' and 'reply' in args
            if is_send:
                wait=2-(time.monotonic()-self.last_send.get(channel,0))
                if wait>0 and self.close_event.wait(wait): raise RuntimeError('工作台正在关闭，已取消发送等待')
            try: return self._execute(platform,args,account_dir,job_id,timeout)
            finally:
                if is_send: self.last_send[channel]=time.monotonic()
        finally: lock.release()

    def _execute(self,platform,args,account_dir=None,job_id=None,timeout=35):
        manifest=self.manifest(platform)
        if platform not in BUILTIN_IDS and not account_dir: raise RuntimeError('通用平台执行必须明确选择独立账号目录')
        spec=self.account_spec(platform,account_dir,args) if account_dir else {'argv':[manifest['executable']]+list(manifest.get('prefix_args',[]))+args,'env':manifest.get('env',{}),'cwd':None}
        process_key=uuid4().hex
        # Spawn and registration share the shutdown lock: close cannot take a
        # snapshot between process creation and ownership registration.
        with self.lifecycle_lock:
            if self.closed: raise RuntimeError('工作台正在关闭，不能启动新的 CLI 操作')
            process=subprocess.Popen(spec['argv'],shell=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',env={**os.environ,**spec['env']},cwd=spec['cwd'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            self.processes[process_key]=process
            if job_id: self.job_processes[job_id]=process
        try:
            stdout,stderr=process.communicate(timeout=timeout)
            if process.returncode: raise RuntimeError('CLI 执行失败或已取消（退出码 %s）；请检查登录及配置。'%process.returncode)
            payload=json.loads(stdout)
            if isinstance(payload,dict) and payload.get('ok') is False: raise RuntimeError('CLI 返回失败，请检查账号登录与平台限制')
            return payload
        except subprocess.TimeoutExpired:
            process.kill(); process.communicate(); raise RuntimeError('CLI 超时，已终止；外部操作结果需人工核实')
        finally:
            with self.lifecycle_lock:
                self.processes.pop(process_key,None)
                if job_id and self.job_processes.get(job_id) is process: self.job_processes.pop(job_id,None)

    def cancel(self,job_id):
        with self.lifecycle_lock: process=self.job_processes.get(job_id)
        if process and process.poll() is None:
            try: process.terminate(); return True
            except OSError: return False
        return False

    def close(self):
        with self.lifecycle_lock:
            self.closed=True; self.close_event.set()
            owned=list(self.processes.values())
            self.processes.clear(); self.job_processes.clear()
        for process in owned:
            if process.poll() is None:
                try: process.terminate()
                except OSError: pass
        deadline=time.monotonic()+2
        for process in owned:
            try: process.wait(timeout=max(0,deadline-time.monotonic()))
            except subprocess.TimeoutExpired:
                try: process.kill()
                except OSError: pass
            except OSError: pass
        return {'closed':True,'owned_processes':len(owned)}

    def manifests(self):
        result = {key: {'id':key,'name':name,'verified':False,'status':'待配置'} for key,name in PLATFORMS}
        for root in (self.root,self.local_root):
            if not root or not root.exists(): continue
            for path in sorted(root.glob('*.json')):
                try:
                    item=json.loads(path.read_text(encoding='utf-8-sig'))
                    if isinstance(item,dict) and safe_platform_id(item.get('id')):
                        result[item['id']]={**result.get(item['id'],{}),**item}
                except (ValueError,OSError):
                    continue
        for item in result.values():
            executable=item.get('executable','')
            item['available']=bool(executable and shutil.which(executable))
            item['status']='可运行' if item.get('search_verified') and item['available'] else '待验证/待安装'
        return list(result.values())

    def search(self, platform, task, verification=False):
        if platform=='kuaishou': raise RuntimeError('快手适配器仅支持指定作品评论采集，不支持关键词搜索')
        manifest=next((x for x in self.manifests() if x['id']==platform),None)
        if not manifest or (not manifest.get('search_verified') and not verification) or not manifest.get('available'):
            raise RuntimeError('该平台 CLI 尚未安装并验证；请配置适配器，或导入 CSV。')
        arguments=manifest.get('search_args',[])
        if not isinstance(arguments,list) or not arguments or not all(isinstance(x,str) for x in arguments):
            raise RuntimeError('适配器缺少安全的 search_args 参数数组')
        values={'keyword':' '.join(task.get('keywords',[])), 'limit':str(task.get('daily_limit',20)), 'date_from':task.get('date_from',''),'date_to':task.get('date_to',''),'page':str(task.get('next_page',1))}
        if manifest.get('mapper')=='douyin_bridge':
            if not task.get('_conn_id'): raise RuntimeError('请先明确选择抖音浏览器连接 conn_id')
            values.update(conn_id=task['_conn_id'],limit=str(min(20,int(values['limit']))))
        args=[x.format_map(values) for x in arguments]
        if manifest.get('mapper')=='xhs_v1' and '--page' not in args: args+=['--page',values['page']]
        payload=self.execute(platform,args,task.get('_account_dir'),task.get('id'))
        raw=payload.get('data',payload) if isinstance(payload,dict) else {}
        task['_page_info']={'has_more':raw.get('has_more') if isinstance(raw,dict) else None}
        items=self.map_items(payload,manifest.get('mapper'),platform)
        if not isinstance(items,list) or not all(isinstance(x,dict) for x in items):
            raise RuntimeError('CLI 输出不符合规范 JSON 列表')
        if platform not in BUILTIN_IDS and any(not (item.get('source_id') or item.get('url')) for item in items): raise RuntimeError('通用标准数据每条必须包含 source_id 或 url')
        return items

    def comments(self,platform,task):
        if platform=='kuaishou':
            manifest=self.manifest(platform)
            if not task.get('_conn_id'): raise RuntimeError('快手评论采集必须明确绑定浏览器连接 conn_id')
            pages=int(task.get('max_pages',3))
            if not 1<=pages<=10: raise RuntimeError('快手单批评论页数必须为 1—10')
            values={'note_url':task['note_url'],'conn_id':task['_conn_id'],'pages':str(pages)}
            arguments=manifest.get('comments_args')
            if not isinstance(arguments,list) or not arguments: raise RuntimeError('快手评论命令尚未配置')
            payload=self.execute(platform,[x.format_map(values) for x in arguments],task.get('_account_dir'),task.get('id'),timeout=140)
            task['_page_info']={'has_more':False}
            return self.map_kuaishou_comments(payload)
        if platform=='douyin':
            manifest=self.manifest(platform)
            if not task.get('_conn_id'): raise RuntimeError('缺少固定抖音连接 conn_id')
            match=re.search(r'/video/(\d+)',task['note_url'])
            if not match: raise RuntimeError('抖音评论任务需要完整 /video/数字ID 链接')
            values={'source_id':match.group(1),'limit':str(min(20,int(task.get('daily_limit',20)))),'conn_id':task['_conn_id']}
            payload=self.execute(platform,[x.format_map(values) for x in manifest['comments_args']],task.get('_account_dir'),task.get('id'))
            task['_page_info']={'has_more':False}
            if not isinstance(payload,list): raise RuntimeError('抖音评论数据结构不匹配')
            return [{'platform':platform,'source_id':'comment:'+str(x['cid']),'comment_id':str(x['cid']),'note_url':task['note_url'],'url':task['note_url'],'title':str(x.get('text',''))[:100],'text':x.get('text',''),'author':x.get('user',{}).get('nickname',''),'author_id':x.get('user',{}).get('uid',''),'published_at':self.timestamp(x.get('time')),'region':'','source_type':'comment','stage':'待核实评论'} for x in payload if x.get('cid')]
        if platform!='xiaohongshu': raise RuntimeError('当前评论采集适配器支持小红书；其他平台待接入')
        args=['comments',task['note_url'],'--json']
        if task.get('next_cursor'): args+=['--cursor',task['next_cursor']]
        payload=self.execute(platform,args,task.get('_account_dir'),task.get('id'))
        raw=payload.get('data',payload)
        task['_page_info']={'has_more':raw.get('has_more'),'cursor':raw.get('cursor','')}
        return self.map_comments(payload,task['note_url'])

    @staticmethod
    def map_kuaishou_comments(payload):
        data=payload.get('data') if isinstance(payload,dict) and payload.get('ok') is True else None
        if not isinstance(data,dict) or not isinstance(data.get('comments'),list) or not data.get('photoId'): raise RuntimeError('快手评论输出结构不符合契约')
        photo_id=str(data['photoId']); url='https://www.kuaishou.com/short-video/'+photo_id
        result=[]
        for item in data['comments']:
            if not isinstance(item,dict) or not item.get('commentId'): continue
            published=item.get('createdAt') or Adapters.timestamp(item.get('timestamp'))
            result.append({'platform':'kuaishou','source_id':str(item['commentId']),'comment_id':str(item['commentId']),'parent_id':photo_id,'note_url':url,'url':url,'title':str(item.get('text',''))[:100],'text':item.get('text',''),'author':item.get('author',''),'author_id':item.get('authorId',''),'published_at':published,'region':'','source_type':'comment','stage':'待核实评论'})
        return result

    @staticmethod
    def map_comments(payload,note_url):
        data=payload.get('data',payload) if isinstance(payload,dict) else None
        comments=data.get('comments') if isinstance(data,dict) else None
        if not isinstance(comments,list): raise RuntimeError('评论输出结构未识别，停止导入')
        result=[]
        queue=list(comments)
        while queue:
            item=queue.pop(0)
            if not isinstance(item,dict): continue
            queue.extend(item.get('sub_comments') or [])
            comment_id=item.get('id')
            if not comment_id: continue
            stamp=item.get('create_time'); published=''
            if isinstance(stamp,(int,float)):
                try: published=datetime.fromtimestamp(stamp/1000 if stamp>100000000000 else stamp).isoformat(timespec='seconds')
                except (ValueError,OSError,OverflowError): pass
            result.append({'platform':'xiaohongshu','source_id':'comment:'+str(comment_id),'comment_id':str(comment_id),'note_url':note_url,'url':note_url,'title':str(item.get('content',''))[:100],'text':item.get('content',''),'author':item.get('user_info',{}).get('nickname',''),'author_id':item.get('user_info',{}).get('user_id',''),'region':item.get('ip_location',''),'published_at':published,'stage':'待核实评论','source_type':'comment'})
        return result

    def send(self,platform,lead,text,account_dir):
        if platform=='kuaishou': raise RuntimeError('快手当前只读采集，不支持自动发送，请复制审核后的回复到原帖人工处理')
        manifest=self.manifest(platform)
        if platform=='douyin':
            if not manifest.get('reply_contract_verified') or not lead.get('_conn_id'): raise RuntimeError('抖音发送契约或固定连接未准备好')
            match=re.search(r'/video/(\d+)',lead.get('note_url',''))
            if not match or not lead.get('comment_id'): raise RuntimeError('缺少抖音视频或评论 ID')
            # The packaged CLI's search first argument is its absolute cli.js path.
            entry=manifest['search_args'][0]
            payload=self.execute(platform,[entry,'post',match.group(1),text,'--reply-to',lead['comment_id'],'--conn-id',lead['_conn_id'],'--no-store'],account_dir,timeout=95)
            if not isinstance(payload,dict) or payload.get('status')!='published' or not payload.get('cid'): raise RuntimeError('抖音回复结果不明，禁止重试')
            return {'success':True,'source_id':str(payload['cid'])}
        if platform!='xiaohongshu' or not manifest.get('reply_contract_verified'):
            raise RuntimeError('此平台回复命令契约尚未验证')
        if not lead.get('comment_id') or not lead.get('note_url'): raise RuntimeError('仅支持回复已采集评论，缺少评论 ID 或笔记链接')
        payload=self.execute(platform,['reply',lead['note_url'],'--comment-id',lead['comment_id'],'--content',text,'--json'],account_dir,timeout=35)
        if not isinstance(payload,dict) or payload.get('ok') is not True: raise RuntimeError('回复结果不明确，请人工核实，不会自动重试')
        return {'success':True}

    @staticmethod
    def timestamp(value):
        if not isinstance(value,(int,float)) or value<=0: return ''
        try: return datetime.fromtimestamp(value/1000 if value>100000000000 else value).isoformat(timespec='seconds')
        except (ValueError,OSError,OverflowError): return ''

    @staticmethod
    def map_items(payload,mapper,platform):
        if mapper=='douyin_bridge':
            if not isinstance(payload,list): raise RuntimeError('抖音 Bridge 搜索输出不是数组')
            return [{'platform':platform,'source_id':str(x['aweme_id']),'title':x.get('desc',''),'text':x.get('desc',''),'author':x.get('author',''),'author_id':x.get('uid',''),'url':'https://www.douyin.com/video/'+str(x['aweme_id']),'published_at':Adapters.timestamp(x.get('time')),'region':'','source_type':'note','stage':'待核实视频'} for x in payload if x.get('aweme_id')]
        if mapper=='xhs_v1':
            data=payload.get('data',payload) if isinstance(payload,dict) else payload
            items=data.get('items') if isinstance(data,dict) else data
            if not isinstance(items,list): raise RuntimeError('小红书搜索输出结构已变化，不能猜测映射')
            result=[]
            for item in items:
                card=item.get('note_card')
                if not isinstance(card,dict) or not item.get('id'): continue
                token=item.get('xsec_token') or card.get('xsec_token') or ''
                result.append({'platform':platform,'source_id':str(item['id']),'title':card.get('display_title') or card.get('title',''),'author':card.get('user',{}).get('nickname',''),'text':card.get('desc',''),'url':'https://www.xiaohongshu.com/explore/'+str(item['id'])+('?xsec_token='+token+'&xsec_source=pc_search' if token else ''),'grade':'C','stage':'待核实（笔记，非已确认客户）','source_type':'note'})
            return result
        if mapper=='weibo_cards':
            data=payload.get('data',payload)
            if isinstance(data,dict) and isinstance(data.get('data'),dict): data=data['data']
            cards=data.get('cards') if isinstance(data,dict) else None
            if not isinstance(cards,list): raise RuntimeError('微博搜索输出结构已变化，不能猜测映射')
            posts=[]
            for card in cards:
                if card.get('mblog'): posts.append(card['mblog'])
                posts.extend(x['mblog'] for x in card.get('card_group',[]) if x.get('mblog'))
            result=[]
            for post in posts:
                source_id=str(post.get('idstr') or post.get('id') or '')
                if not source_id: continue
                text=unescape(re.sub('<[^>]+>','',post.get('text','')))
                result.append({'platform':platform,'source_id':source_id,'title':text[:100],'text':text,'author':post.get('user',{}).get('screen_name',''),'url':'https://weibo.com/'+str(post.get('user',{}).get('id',''))+'/'+str(post.get('bid',source_id)),'published_at':post.get('created_at',''),'region':post.get('region_name',''),'stage':'待核实','source_type':'note'})
            return result
        if mapper=='opencli_douyin':
            if not isinstance(payload,list): raise RuntimeError('抖音搜索输出结构已变化，不能猜测映射')
            result=[]
            for item in payload:
                url=item.get('url',''); match=re.search(r'/video/(\d+)',url)
                if not match: continue
                result.append({'platform':platform,'source_id':match.group(1),'title':item.get('desc',''),'text':item.get('desc',''),'author':item.get('author',''),'url':url,'stage':'待核实'})
            return result
        return payload.get('items') if isinstance(payload,dict) else payload

    def verify(self,platform,keyword,account_dir=None,conn_id=None):
        self.search(platform,{'keywords':[keyword],'daily_limit':1,'_account_dir':account_dir,'_conn_id':conn_id},verification=True)
        self.local_root.mkdir(parents=True,exist_ok=True)
        path=self.local_root/(platform+'.json')
        previous=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'id':platform}
        previous['search_verified']=True
        path.write_text(json.dumps(previous,ensure_ascii=False,indent=2),encoding='utf-8')
        return {'verified':True,'platform':platform,'message':'只读搜索与输出结构验证通过；未发送任何消息'}
