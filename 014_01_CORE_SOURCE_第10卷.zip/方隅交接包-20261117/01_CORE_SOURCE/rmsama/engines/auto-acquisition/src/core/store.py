import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

class Store:
    def __init__(self, directory):
        self.directory=Path(directory)
        self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/'workspace.sqlite3'
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS records(entity TEXT NOT NULL,id TEXT NOT NULL,tenant_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(entity,id));
                CREATE INDEX IF NOT EXISTS scope ON records(entity,tenant_id);
                CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS unique_leads(tenant_id TEXT,platform TEXT,source_id TEXT,lead_id TEXT,PRIMARY KEY(tenant_id,platform,source_id));
            ''')
    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path,timeout=30)
        db.row_factory=sqlite3.Row
        try:
            with db: yield db
        finally: db.close()
    def list(self,entity,tenant_id=None):
        with self.connect() as db:
            rows=db.execute('SELECT body FROM records WHERE entity=?'+(' AND tenant_id=?' if tenant_id is not None else ''),(entity,tenant_id) if tenant_id is not None else (entity,)).fetchall()
        return [json.loads(x['body']) for x in rows]
    def get(self,entity,id):
        with self.connect() as db:
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,id)).fetchone()
        return json.loads(row['body']) if row else None
    def put(self,entity,record):
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,record['id'],record['tenant_id'],json.dumps(record,ensure_ascii=False)))
    def delete(self,entity,id):
        with self.connect() as db:
            db.execute('DELETE FROM records WHERE entity=? AND id=?',(entity,id))
            if entity=='leads': db.execute('DELETE FROM unique_leads WHERE lead_id=?',(id,))
    def insert_lead(self,record):
        return self.insert_leads([record])==1
    def insert_leads(self,records):
        """One transaction per batch: dedupe and records commit or roll back together."""
        inserted=0
        with self.connect() as db:
            for record in records:
                cursor=db.execute('INSERT OR IGNORE INTO unique_leads VALUES(?,?,?,?)',(record['tenant_id'],record['platform'],record['source_id'],record['id']))
                if cursor.rowcount==0: continue
                db.execute('INSERT INTO records VALUES(?,?,?,?)',('leads',record['id'],record['tenant_id'],json.dumps(record,ensure_ascii=False)))
                inserted+=1
        return inserted
