from pathlib import Path
from io import BytesIO
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
base=Path(r'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/PDF表格填写')
(base/'outputs').mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('Kai',r'C:/Windows/Fonts/simkai.ttf'))
r=PdfReader(r'C:/Users/rmsama/OneDrive/Z.pdf')
p=r.pages[0]; w=float(p.mediabox.width); h=float(p.mediabox.height)
b=BytesIO(); c=canvas.Canvas(b,pagesize=(w,h))
sx=w/1415; sy=h/2000
c.setFillColorRGB(0.07,0.07,0.09)
def put(text,x,y,size):
 c.setFont('Kai',size); c.drawString(x*sx,h-y*sy,text)
put('申请人承诺以上信息真实。如有失实或欺骗，自愿承担列入版权登记失信名单',158,1680,11)
put('及个人征信记录，并承担由此引发的法律责任及后果。',158,1721,11)
put('娄桢杰',973,1769,16)
put('[REDACTED:id_card_cn]',970,1805,10)
c.save(); b.seek(0); p.merge_page(PdfReader(b).pages[0]); writer=PdfWriter(); writer.add_page(p)
out=base/'outputs'/'申请材料清单_手写体填写版.pdf'
with out.open('wb') as f: writer.write(f)
check=PdfReader(out); text=check.pages[0].extract_text()
assert all(s in text for s in ['娄桢杰','[REDACTED:id_card_cn]','申请人承诺以上信息真实'])
print(out)
