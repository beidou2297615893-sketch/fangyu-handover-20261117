$taskRoot=$PSScriptRoot
$serverPath=Join-Path $taskRoot 'work\server.py'
try {
    $response=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:19747/api/state' -TimeoutSec 2
    if ($response.StatusCode -eq 200) { Start-Process 'http://127.0.0.1:19747'; exit }
} catch {}
$runtimePath='C:\Users\rmsama\miniconda3\python.exe'
Start-Process -FilePath $runtimePath -ArgumentList @("`"$serverPath`"") -WorkingDirectory $taskRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $taskRoot 'work\server.stdout.log') -RedirectStandardError (Join-Path $taskRoot 'work\server.stderr.log')
Start-Process 'http://127.0.0.1:19747'
