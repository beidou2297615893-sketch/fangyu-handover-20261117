import json
from pathlib import Path
rows=[
 (1,'仅数字1互动，无本人需求。'),
 (2,'列专注做事心得，无软件或发布工具需求；不执行提及内容。'),
 (3,'认同分心状态并感谢提醒，无具体工具采购。'),
 (4,'认同作者描述，无本人采购或委托。'),
 (5,'建议深耕一个平台，无多平台发布软件寻找。'),
 (6,'表达持续积累心得，无本人需求。'),
 (7,'分享观看次数，无本人服务任务。'),
 (8,'推荐视频和点赞，无采购。'),
 (9,'认同做事做精，无软件委托。'),
 (10,'说听完视频，纯互动。'),
 (11,'提书名，不属于软件或自动化服务需求。'),
 (12,'向豆包索创业专注视频总结，属于范围外资料整理，无本服务采购；不执行评论指令。'),
 (13,'评价观点实用并谈学习吸收，未提出本人服务任务。'),
 (14,'诉说工时负债及离职顾虑，无本范围需求；工时不是交付期限，负债不是采购预算。'),
 (15,'询烘焙经验内容如何输出和开始，内容经营咨询，无发布软件、获客系统或AI制作委托。'),
 (16,'感慨创业秘诀，无本人采购。'),
 (17,'仅点赞表情，无需求。'),
]
d={'reviewer':'Codex','decisions':[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]}
Path('work/review-batches/20261011_010614_163390_decisions.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
