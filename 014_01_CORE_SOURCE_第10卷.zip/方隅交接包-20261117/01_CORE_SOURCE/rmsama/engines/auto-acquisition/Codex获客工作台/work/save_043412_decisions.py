import json
from pathlib import Path
p=Path('work/review-batches/20261011_043412_542084_decisions.json')
d={'reviewer':'Codex','decisions':[{'index':1,'verdict':'待确认','score':40,'reason':'讨论付费获客工具仍不精准及公司要求扩量的矛盾，可能涉及实际获客问题，但没有明确寻找新软件或委托承接。被回复者公司买系统、外接API和每日三四千条不能转归本人；付费工具评价不是本人采购预算。','demand_type':'获客系统与CRM','demand_evidence':'但是付费的也有很难找准，就是人的问题，你哪怕想找准，也还是会被扩量要求更激进的扩词，因为这是公司要求','budget_evidence':'','payment_evidence':'','urgent_evidence':''}]}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print(p)
