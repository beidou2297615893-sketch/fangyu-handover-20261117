import json, time, subprocess
from datetime import datetime
from pathlib import Path
from campaign_collect import db, put
from launch_comments import active
ROOT=Path(__file__).resolve().parent.parent
work=ROOT/'work'
assert not active()
stop=json.loads((work/'STOP').read_text('utf-8'))
assert stop.get('origin')=='technical_disconnect' and stop.get('created_by')=='Codex'
assert stop.get('created_at')=='2026-10-11T02:19:44.529462+08:00'
raw=json.loads((work/'恢复评论读回_20261011_022336.json').read_text('utf-8'))
assert raw['status_code']==0 and len(raw['comments'])==20
assert [x['text'] for x in raw['comments'][:5]]==['比福客便宜吗？','售后呢','怎么收费 可以试用？','可以付费，怎么联系怎么用','怎么试用']
assert (ROOT/'outputs/采集恢复核验_20261011_0223.png').exists()
conn='c570de13-8f0f-4ab5-94ac-5efb47ee6cba'
url='https://www.douyin.com/video/7676806387175598451'
node=ROOT.parent/'work/runtime/douyin-bridge/node.exe'
status=json.loads(subprocess.check_output([str(node),str(work/'douyin_read.cjs'),'status'],encoding='utf-8'))
registration=next(x for x in status['connections']['douyin.com'] if x['id']==conn)
assert registration['alive'] and registration['url']==url
assert time.time()-datetime.fromisoformat(registration['lastActivity'].replace('Z','+00:00')).timestamp()<70
stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
(work/f'SDK恢复注册核验_{stamp}.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
binding=work/'抖音连接绑定.json'
(work/f'抖音连接绑定_{stamp}_技术恢复前.json').write_bytes(binding.read_bytes())
fresh=dict(connection_id=conn,conn_id=conn,url=url,server_port=19422,browser_id='3',tab_id='896061671',binding_status='fresh',verified_at=datetime.now().astimezone().isoformat(),verified_by='本人Chrome同URL恢复页北极学长头像、无验证登录限制提示；当前页原SDK注册c570de13与19422状态一致；真实20条评论读回前5条与页面逐条一致；仅绑定本注册，空标题未单独作为成功证据')
binding.write_text(json.dumps(fresh,ensure_ascii=False,indent=2),encoding='utf-8')
with db() as c: put(c,'last_read',time.time())
(work/'STOP').rename(work/f'STOP_{stamp}_本次技术恢复归档.json')
print(json.dumps(dict(verified=True,binding=fresh),ensure_ascii=False))
