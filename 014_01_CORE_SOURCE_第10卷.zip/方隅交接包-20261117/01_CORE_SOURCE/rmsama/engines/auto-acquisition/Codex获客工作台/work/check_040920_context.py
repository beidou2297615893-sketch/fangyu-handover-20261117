import json,sqlite3
from pathlib import Path
w=Path(__file__).parent
b=json.loads((w/'review-batches/20261011_040920_257421.json').read_text('utf-8'))
with sqlite3.connect((w/'campaign.sqlite3').as_uri()+'?mode=ro',uri=True) as src, sqlite3.connect((w/'codex_reviews.sqlite3').as_uri()+'?mode=ro',uri=True) as led:
 for n in (8,20):
  uid=b['comments'][n-1]['record']['user_id']
  for (data,) in src.execute('select data from records where json_extract(data,?)=?',('$.user_id',uid)):
   r=json.loads(data);print(json.dumps({'index':n,'record':{k:r.get(k) for k in ('id','user_id','text','parent_text','published_at','source_url')}},ensure_ascii=False))
   for t in ('reviews','review_rechecks'):
    row=led.execute('select data from '+t+' where id=?',(r['id'],)).fetchone()
    if row:
     d=json.loads(row[0]);print(json.dumps({'table':t,'review':{k:d.get(k) for k in ('id','verdict','reason','demand_type')}},ensure_ascii=False))
