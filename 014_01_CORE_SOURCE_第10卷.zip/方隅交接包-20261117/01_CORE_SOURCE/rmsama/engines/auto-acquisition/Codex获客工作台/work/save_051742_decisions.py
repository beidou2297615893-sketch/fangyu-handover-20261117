import json
from pathlib import Path
rows=[
 (1,'待确认',35,'询私域获客玩法怎么用并可能求教，原文交含义不明确，不当作付款或服务委托；他人两个月使用经历不归其本人。','获客系统与CRM','怎么用的，可以交吗'),
 (2,'待确认',20,'泛问玩法如何，只有获客方法兴趣，未提出工具采购或具体业务委托。','获客系统与CRM','怎么样的'),
 (3,'排除',0,'纯鼓掌表情回复，未表达需求，不从昵称推断。','需求未明确',''),
 (4,'排除',0,'纯鼓掌互动，没有本人采购需求。','需求未明确',''),
 (5,'排除',0,'鼓掌表情没有服务委托或预算。','需求未明确','')]
decisions=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
out=Path(__file__).parent/'review-batches/20261011_051742_656120_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
