import json
from pathlib import Path
rows=[
 (1,'感谢并表示已知道操作，无未解决服务需求。'),
 (2,'回顾重复发布导致流量问题并感谢教程，没有分发软件或制作委托。'),
 (3,'询问抖音原生视频忘加音乐如何处理，属于操作学习，无制作委托。'),
 (4,'感谢分享，无需求。'),
 (5,'赞扬分享，无本人需求。'),
 (6,'表情互动，无需求。'),
 (7,'感谢分享，无需求。'),
 (8,'表示马上按教程操作，非本人项目交付期限或付款表达。'),
 (9,'点赞表情，无需求。'),
 (10,'提供修改视频服务，供应商广告非买方需求。'),
 (11,'表情互动，无需求。'),
 (12,'感谢学习，无采购。'),
 (13,'提供修改视频服务，供应商广告非买方需求。'),
 (14,'夸赞教程知识实用，无需求。'),
 (15,'描述抖音原生按钮缺失，非多平台发布软件或定制制作需求。')
]
ds=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [d['index'] for d in ds]==list(range(1,16))
out=Path(__file__).parent/'review-batches/20261011_053240_865844_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
