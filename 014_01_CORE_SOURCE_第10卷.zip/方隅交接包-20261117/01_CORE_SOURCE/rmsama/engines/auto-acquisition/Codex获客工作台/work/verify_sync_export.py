"""Read-only ledger/XLSX comparison; writes only the local verification report."""
import collections, datetime, hashlib, json, sqlite3, sys, urllib.request, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from codex_review import effective_reviews
from qualify import is_recent

ROOT = Path(__file__).resolve().parents[1]
WORK, OUT = ROOT / 'work', ROOT / 'outputs'
def read(p):
    return json.loads(p.read_text('utf-8'))
def api(route):
    with urllib.request.urlopen('http://127.0.0.1:19747' + route, timeout=10) as r:
        return r.read()

with sqlite3.connect((WORK / 'codex_reviews.sqlite3').as_uri() + '?mode=ro', uri=True) as c:
    reviews = {d['id']: d for d in effective_reviews(c)}
    originals = {i: json.loads(d) for i, d in c.execute('select id,data from reviews')}
    rechecks = {i: json.loads(d) for i, d in c.execute('select id,data from review_rechecks')}
    recheck_batches = [p for p, in c.execute('select distinct batch from review_rechecks')]
    fullpasses = [json.loads(d) for d, in c.execute('select data from review_fullpasses order by pass_id,rowid')]
history = read(OUT / 'Codex待确认复审进度.json')
assert len(rechecks) == history['completed']
for p in recheck_batches:
    batch = read(Path(p))
    assert all(originals[x['record']['id']] == x['previous_review'] for x in batch['comments'])
expected_effective = dict(originals)
expected_effective.update(rechecks)
for d in fullpasses:
    expected_effective[d['id']] = d
assert reviews == expected_effective
for d in reviews.values():
    assert d['reviewer'] == 'Codex'
    for k in ['demand_evidence', 'budget_evidence', 'payment_evidence', 'urgent_evidence']:
        assert not d.get(k) or d[k] in d['record']['text']
snap = read(WORK / '客户分类快照.json')
expected = {x['id']: x for x in snap['rows']}
assert all(x['recent'] == bool(is_recent(x['published_at']) and x['text'].strip()) for x in expected.values())
assert len(reviews) == len(originals)
exported_reviews = {i for i, x in expected.items() if x['verdict'] in ('高意向', '待确认', '排除')}
assert snap['stats']['reviewed'] == len(exported_reviews)
assert exported_reviews.issubset(reviews)
# Validate every exported conclusion against the latest immutable overlay.
for i in exported_reviews:
    d, x = reviews[i], expected[i]
    assert x['verdict'] == d['verdict'] and x['reason'] == d['reason']
    assert x['score'] == d['score'] and x['reviewed_at'] == d['reviewed_at']
    for column, key in [('demand','demand_evidence'),('budget','budget_evidence'),('payment','payment_evidence'),('urgent','urgent_evidence')]:
        assert x[column] == d.get(key, '')
    if d.get('demand_type'):
        assert x['type'] == d['demand_type']
latest = max((p for p in [OUT / '客户分类清单.xlsx', OUT / '客户分类清单_最新.xlsx'] if p.exists()), key=lambda p: p.stat().st_mtime)
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
rel = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
checked_links = 0
with zipfile.ZipFile(latest) as z:
    strings = []
    if 'xl/sharedStrings.xml' in z.namelist():
        strings = [''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml'))]
    def cells(row):
        result = {}
        for e in row.findall('s:c', ns):
            address = e.attrib['r']; col = ''.join(c for c in address if c.isalpha())
            v = e.find('s:v', ns)
            if e.attrib.get('t') == 's': value = strings[int(v.text)]
            elif e.attrib.get('t') == 'inlineStr': value = ''.join(e.find('s:is', ns).itertext())
            else: value = v.text if v is not None else ''
            result[col] = value
        return result
    workbook = ET.fromstring(z.read('xl/workbook.xml'))
    sheets = list(workbook.find('s:sheets', ns))
    assert len(sheets) == 12 and sheets[-1].attrib['name'] == '产品分类汇总'
    tables = [n for n in z.namelist() if n.startswith('xl/tables/') and n.endswith('.xml')]
    assert len(tables) == 12 and all(ET.fromstring(z.read(n)).find('s:autoFilter', ns) is not None for n in tables)
    wbrel = {x.attrib['Id']: x.attrib['Target'] for x in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    views = [snap['customers']] + list(snap['types'].values()) + [snap['rows']]
    for i, sheet in enumerate(sheets):
        dest = wbrel[sheet.attrib[rel]]
        name = (dest.lstrip('/') if dest.startswith('/') else 'xl/' + dest).replace('xl/xl/', 'xl/')
        xml = ET.fromstring(z.read(name))
        rows = {int(r.attrib['r']): cells(r) for r in xml.findall('s:sheetData/s:row', ns)}
        celltypes = {e.attrib['r']:e.attrib.get('t','n') for e in xml.findall('s:sheetData/s:row/s:c',ns)}
        if i == 11:
            assert [rows[5][col] for col in ['A','B','C','D','E']] == ['意向产品','高意向人数','待确认人数','类别内合计','产品范围 / 对应明细页']
            for n,(category,items) in enumerate(snap['types'].items(),6):
                counts=collections.Counter(x['verdict'] for x in items)
                assert (rows[n]['A'],int(rows[n]['B']),int(rows[n]['C']),int(rows[n]['D'])) == (category,counts['高意向'],counts['待确认'],len(items))
                assert rows[n].get('E')
            overall=collections.Counter(x['verdict'] for x in snap['customers'])
            assert (int(rows[14]['B']),int(rows[14]['C']),int(rows[14]['D'])) == (overall['高意向'],overall['待确认'],len(snap['customers']))
        if i == 8:
            actual = {r['P']: r for n, r in rows.items() if n >= 6 and r.get('P')}
            rownums = {r['P']: n for n,r in rows.items() if n>=6 and r.get('P')}
            assert set(actual) == set(expected)
            for ident, row in actual.items():
                x = expected[ident]
                reason = row['H']
                # Authoring escapes formula-like leading text to preserve it as text.
                if reason == "'" + x['reason'] and x['reason'].startswith(('=', '+', '-', '@')):
                    reason = reason[1:]
                assert (row['B'], row['C'], reason) == (x['verdict'], x['type'], x['reason']), ident
                assert float(row['D']) == x['score'], ident
                for column,key in [('G','text'),('I','type_basis'),('J','budget'),('K','payment'),('L','urgent'),('O','uid'),('T','reply_to'),('V','url')]:
                    value=row.get(column,'')
                    raw=x[key] or ''
                    if value == "'"+raw and raw.startswith(('=','+','-','@')):value=value[1:]
                    # XML 1.0 normalizes CRLF/CR line endings to LF; content is unchanged.
                    assert value == raw.replace('\r\n','\n').replace('\r','\n'), (ident,column)
                for column,key in [('E','published_at'),('W','post_date')]:
                    if x[key]:
                        celltype=celltypes[column+str(rownums[ident])]
                        if celltype == 'd':
                            timestamp=datetime.datetime.fromisoformat(row[column].replace('Z','+00:00')).timestamp()
                            assert abs(timestamp-(float(x[key])+8*3600))<0.01,(ident,column)
                        else:
                            assert celltype == 'n',(ident,column)
                            assert abs(float(row[column])-(float(x[key])/86400+25569+8/24))<0.000001,(ident,column)
        if i <= 8:
            rp = str(Path(name).parent / '_rels' / (Path(name).name + '.rels')).replace('\\', '/')
            rr = {r.attrib['Id']: r.attrib['Target'] for r in ET.fromstring(z.read(rp))}
            links = {h.attrib['ref']: rr[h.attrib[rel]] for h in xml.findall('s:hyperlinks/s:hyperlink', ns)}
            for n, x in enumerate(views[i], 6):
                assert (rows[n]['P'],rows[n]['O'],rows[n]['B'],rows[n]['C']) == (x['id'],x['uid'],x['verdict'],x['type'])
                if x['url'].startswith('https://www.douyin.com/video/'):
                    assert links['F' + str(n)] == x['url'] == rows[n]['V']
                    assert rows[n]['N'] == x['post_id'] == x['url'].rsplit('/', 1)[-1]
                    checked_links += 1
    assert len(snap['queries']) == 420
analysis = json.loads(api('/api/analysis'))
excel_meta = json.loads(api('/api/excel'))
assert analysis['reviewed'] == len(reviews)
assert excel_meta['reviewed'] == snap['stats']['reviewed']
assert excel_meta['high'] == snap['stats']['high']
assert hashlib.sha256(api('/customers.xlsx')).digest() == hashlib.sha256(latest.read_bytes()).digest()
progress = read(WORK / '评论任务进度.json')
history = read(OUT / 'Codex待确认复审进度.json')
result = dict(time=datetime.datetime.now().astimezone().isoformat(), pid=progress['pid'],
    phase=progress['status'], collected=progress['stats']['collected'], recent=progress['stats']['recent'],
    reviewed_this_run=len(reviews)-(int(sys.argv[1]) if len(sys.argv)>1 else 8754), reviewed_total=len(reviews),
    pending=analysis['pending'], high=analysis['high'],
    historical_recheck=history, original_rechecked_reviews_unchanged=True,
    rechecks_with_specific_category=sum(d.get('demand_type') not in (None, '需求未明确') for d in rechecks.values()),
    excel_snapshot=excel_meta, excel_pending=sum(x['verdict']=='待分析' for x in expected.values()),
    reviews_committed_after_excel_snapshot=len(set(reviews)-exported_reviews),
    excel_intent_counts=dict(collections.Counter(x['verdict'] for x in expected.values())),
    verified_customer_video_links=checked_links, native_filtered_tables=len(tables), search_keywords=420,
    product_categories_verified=len(snap['types']), product_summary_verified=True,
    errors=[], excel_file=str(latest),
    note='采集保持用户暂停；Excel逐条对应最新Codex全量复审结论，原结论与历史复审均保留。')
for p in [WORK / '同步巡检.json', OUT / '本轮增量复核验收.json']:
    p.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['excel_snapshot','excel_intent_counts','note']}, ensure_ascii=False))
