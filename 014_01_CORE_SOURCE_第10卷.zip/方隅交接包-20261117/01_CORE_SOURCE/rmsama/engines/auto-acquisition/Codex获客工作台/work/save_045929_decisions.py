import json
from pathlib import Path
rows=[
(1,'高意向',80,'评论者具体描述直播关注公众号后自动回复企微二维码、再分流至不同员工的获客流程，作者回复识别为活码需求；有具体方案诉求，原文UID及近期日期已核验、同UID无旧结论。分期原字保留，不推定已付款、预算、期限或同意联系。','获客系统与CRM','直播时，粉丝关注公众号，自动回复企业微信二维码，客户识别二维码自动分期到不同的员工企业微信上'),
(2,'排除',0,'作者解释活码功能并承诺教程，供应方回应不是买家需求；期限不转归。','需求未明确',''),
(3,'排除',0,'询原生平台类目涨价情况，无软件服务采购需求。','需求未明确',''),
(4,'排除',0,'宣传自己开发的清理软件，供应方；180天是功能条件非本人采购期限。','需求未明确',''),
(5,'排除',0,'作者表情回应，无本人采购需求。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,6))
p=Path('work/review-batches/20261011_045929_780502_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
