import os,json,re,datetime,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'; OUT.mkdir(parents=True,exist_ok=True)
roots=[Path('C:/Users/rmsama'),Path('C:/积木软件工坊'),Path('C:/ai'),Path('C:/opt'),Path('C:/From_D')]
skip={'node_modules','.git','__pycache__','Cache','Caches','Code Cache','GPUCache','Windows','miniconda3','xwechat_files','WeChat Files','.cache','site-packages'}
found=[]; errors=[]
def err(e): errors.append(str(e))
for root in roots:
 if not root.exists():continue
 for base,dirs,files in os.walk(root,onerror=err,followlinks=False):
  dirs[:]=[d for d in dirs if d not in skip and not Path(base,d).is_symlink()]
  p=Path(base)
  match=re.search(r'(xiaohongshu.cli|xhs.cli|douyin.cli|douyin.bridge|douyin.rust|douyin.youhai|opencli)',p.name,re.I)
  entry=[f for f in files if f.lower() in ('xhs.exe','dy.exe','douyin.exe','douyin-cli.exe','opencli.cmd','agent-reach.exe')]
  if match and any(f in files for f in ['package.json','pyproject.toml','Cargo.toml','go.mod','cli.js']):
   kind='源码候选'; source=''; version=''
   if 'package.json' in files:
    try:
     pkg=json.loads((p/'package.json').read_text('utf-8-sig')); source=pkg.get('homepage','');version=pkg.get('version','')
    except Exception:pass
   if 'cli.js' in files and (p/'node_modules').exists():kind='已具备依赖的 Bridge CLI'
   found.append(dict(name=p.name,path=str(p),kind=kind,source=source,version=version))
  for f in entry:found.append(dict(name=f,path=str(p/f),kind='命令入口，待运行核验',source='',version=''))
  for f in files:
   if re.search(r'(xiaohongshu.cli|xhs.cli|douyin.cli|opencli)',f,re.I) and f.lower().endswith(('.zip','.7z','.tar.gz','.msi')):
    found.append(dict(name=f,path=str(p/f),kind='下载压缩包/安装包',source='',version=''))
report=dict(scanned_at=datetime.datetime.now().isoformat(),roots=[str(x) for x in roots],excluded=sorted(skip),errors=errors,items=found)
(OUT/'CLI完整盘点.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
lines=['# 本机 CLI 盘点','扫描根目录：'+ '、'.join(report['roots']),'排除依赖、缓存、聊天文件及 Git 内部目录；未扫描其他盘和系统受保护目录。','发现 %d 个入口/源码/备份；副本不等于独立工具。'%len(found),'']
for x in found:lines+=['- '+x['name']+' · '+x['kind'],'  '+x['path']]
(OUT/'CLI完整盘点.md').write_text('\n'.join(lines),'utf-8')
print(json.dumps({'count':len(found),'errors':len(errors),'primary':[x for x in found if not any(s in x['path'] for s in ['packaging','qa-','备份','versions','便携','frozen','_internal','outputs'])][:24]},ensure_ascii=False))
