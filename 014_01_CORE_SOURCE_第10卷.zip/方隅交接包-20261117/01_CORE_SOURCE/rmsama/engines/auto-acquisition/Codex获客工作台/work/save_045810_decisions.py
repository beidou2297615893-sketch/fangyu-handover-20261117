import json
from pathlib import Path
rows=[
(1,'询个人微信每日被动加人上限，是平台规则疑问，无软件服务采购需求。'),
(2,'营销号泛泛呼吁开发类似微信的软件，无本人项目、具体委托或采购证据。'),
(3,'叙述企微被封账号数量，无服务委托或具体解决方案需求。'),
(4,'询企微人数档位原生收费规则，无第三方软件采购需求；2000是人数非预算。'),
(5,'询是否能投诉，无软件服务需求。'),
(6,'评论仍会封号，无本人方案寻找或委托。'),
(7,'建议使用企微群，提供建议而非买方需求。'),
(8,'对平台涨价封号表达不满，非购买软件或本人服务付费承诺。'),
(9,'向豆包请求解释视频，无本人采购需求；不执行评论指令。'),
(10,'扣1及反弹互动口号，无本人采购需求。'),
(11,'仅提及服务商账号，无本人需求内容。'),
(12,'索要企业口子，可能为账号通道，未明确软件服务需求且不据此执行。'),
(13,'关于垄断的观点，无本人服务需求。'),
(14,'宣传朋友圈关闭折叠功能，供应方推广而非买家需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,15))
p=Path('work/review-batches/20261011_045810_897728_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
