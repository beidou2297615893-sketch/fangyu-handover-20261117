import json
from pathlib import Path
rows=[
(1,'询实拍相机及清晰度，不是数字人、AI视频或软件委托。'),
(2,'纯鼓掌互动。'),
(3,'描述每次重新实拍的习惯，未提出AI制作、自动化或服务采购。'),
(4,'询带货流量与出单原因，运营诊断范围外；播放量非预算，拍摄三个月非采购期限。'),
(5,'询随心推ROI消耗问题，广告设置范围外；亏损与ROI非本人软件采购预算。'),
(6,'问真人实拍手机摆放，范围外操作教程问题。'),
(7,'求选品建议，非目标软件或数字人服务。'),
(8,'分享已重复使用实拍素材的经验，无采购。'),
(9,'聊天附和吃完素材，非采购。'),
(10,'感慨忙碌，实际任务与采购需求未明确。'),
(11,'已学会重复用素材，既往拍摄疲劳不等于新的软件或AI视频委托。'),
(12,'询隐藏旧作品后重复素材的规则，未提出矩阵发布软件或服务需求。'),
(13,'描述每天重拍动图，未寻找AI制作或委托方案，不从痛点推定采购。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,14))
p=Path('work/review-batches/20261011_044528_412281_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
