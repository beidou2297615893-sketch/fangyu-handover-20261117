import json
from pathlib import Path
rows=[
 (1,'排除',0,'感谢分享和表情互动，无本人服务需求。','需求未明确',''),
 (2,'排除',0,'评价科普视频有用，没有本人采购或方案需求。','需求未明确',''),
 (3,'排除',0,'单纯赞叹，无本人需求。','需求未明确',''),
 (4,'待确认',25,'询问作者硬件配置，属于技术学习兴趣；未说明自己的项目或委托，不能当作开发采购。','需求未明确','说吧，你的配置是什么'),
 (5,'排除',0,'回应作者本地与云端教程投票并关注鼓励，无本人采购需求。','需求未明确',''),
 (6,'排除',0,'只投票希望本地路线教程，无具体服务需求。','需求未明确',''),
 (7,'排除',0,'纯点赞表情互动，无本人需求。','需求未明确',''),
 (8,'排除',0,'希望观看本地教程的投票互动，未表达本人委托。','需求未明确',''),
 (9,'待确认',38,'询问AI视频本地部署方法，偏向自学操作；未要求他人代部署，也无本人项目范围或付费证据。','数字人与视频','本地怎么部署'),
 (10,'排除',0,'抢首评互动，无本人需求。','需求未明确',''),
 (11,'排除',0,'本地路线投票，无本人具体服务或采购表达。','需求未明确',''),
 (12,'排除',0,'本地路线投票，无本人具体需求。','需求未明确',''),
 (13,'排除',0,'讨论本地视频生成用于打草稿的用途，无寻找服务或委托表达。','需求未明确','')
]
decisions=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [d['index'] for d in decisions]==list(range(1,14))
p=Path(__file__).parent/'review-batches/20261011_115012_638882_decisions.json'
p.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(p)
