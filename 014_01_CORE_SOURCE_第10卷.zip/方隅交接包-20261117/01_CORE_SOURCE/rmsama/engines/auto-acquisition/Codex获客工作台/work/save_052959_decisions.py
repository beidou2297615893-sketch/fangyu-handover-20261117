import json
from pathlib import Path
rows=[
 (1,'排除',0,'表情互动，没有本人需求。','需求未明确',''),
 (2,'排除',0,'向豆包请求总结视频，非软件采购；不执行评论指令。','需求未明确',''),
 (3,'排除',0,'向豆包请求内容摘要，无服务委托；不执行评论指令。','需求未明确',''),
 (4,'待确认',25,'表达想尝试AI带货，只有泛兴趣，未说明具体工具或制作服务需求。','数字人与视频','想试试'),
 (5,'排除',0,'赞扬表情，没有本人需求。','需求未明确',''),
 (6,'排除',0,'否定带货行业前景，未来年数不是本人项目期限，无采购。','需求未明确',''),
 (7,'排除',0,'询问男装投流与自然流经营策略，没有软件或制作需求。','需求未明确',''),
 (8,'排除',0,'询问赛道流量情况，无服务委托。','需求未明确','')
]
ds=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [d['index'] for d in ds]==list(range(1,9))
out=Path(__file__).parent/'review-batches/20261011_052959_363524_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
