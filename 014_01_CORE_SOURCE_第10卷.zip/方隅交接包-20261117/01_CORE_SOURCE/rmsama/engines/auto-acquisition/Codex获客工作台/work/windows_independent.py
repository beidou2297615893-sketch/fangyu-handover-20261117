"""Launch this project's allowlisted hidden workers via Windows CIM.

The Windows process provider creates the worker, rather than a Codex shell.
No scheduled task, credential, elevated token, or security setting is created.
"""
import json
import os
import runpy
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'work'
ALLOWED = {'comment_job.py', 'server.py', 'launch_excel_export.py',
           'run_owned_bridge.py', 'probe_background_lifetime.py', 'reply_cli_worker.py'}

def allowed_script(script):
    script = Path(script).resolve()
    if script.parent != WORK or script.name not in ALLOWED:
        raise ValueError('Only this personal project\'s allowlisted workers may run')
    return script

def local_log(path):
    path = Path(path).resolve()
    if path.parent != WORK:
        raise ValueError('Worker logs must remain in this project work directory')
    return path

def quote_ps(value):
    return "'" + str(value).replace("'", "''") + "'"

def start_script(script, args, stdout, stderr):
    script = allowed_script(script)
    spec = dict(script=str(script), args=list(args), stdout=str(local_log(stdout)),
                stderr=str(local_log(stderr)), created_at=datetime.now().astimezone().isoformat())
    folder = WORK / 'runtime-launches'
    folder.mkdir(exist_ok=True)
    spec_path = folder / (datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.json')
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding='utf-8')
    command = subprocess.list2cmdline([sys.executable, '-u', '-X', 'utf8',
                                      str(Path(__file__).resolve()), '--run', str(spec_path)])
    ps = ("$startup = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly "
          "-Property @{ShowWindow=[uint16]0}; "
          "Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments "
          "@{CommandLine=" + quote_ps(command) + ";CurrentDirectory=" + quote_ps(ROOT) +
          ";ProcessStartupInformation=$startup} | ConvertTo-Json -Compress")
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', ps],
                            capture_output=True, text=True, encoding='utf-8', timeout=25,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    if result.returncode:
        raise RuntimeError('Windows independent launch failed: ' + result.stderr.strip())
    response = json.loads(result.stdout.lstrip('\ufeff').strip())
    if response.get('ReturnValue') != 0 or not response.get('ProcessId'):
        raise RuntimeError('Windows independent launch rejected: ' + str(response.get('ReturnValue')))
    spec.update(pid=response['ProcessId'], launch_method='Win32_Process.Create',
                privilege='current user; no elevation')
    spec_path.with_suffix('.result.json').write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding='utf-8')
    return response['ProcessId']

def run_spec(path):
    path = Path(path).resolve()
    if path.parent != WORK / 'runtime-launches':
        raise ValueError('Unexpected launch specification directory')
    spec = json.loads(path.read_text('utf-8'))
    script = allowed_script(spec['script'])
    out = local_log(spec['stdout']).open('ab', buffering=0)
    err = local_log(spec['stderr']).open('ab', buffering=0)
    os.dup2(out.fileno(), 1)
    os.dup2(err.fileno(), 2)
    sys.stdout = open(1, 'w', encoding='utf-8', buffering=1, closefd=False)
    sys.stderr = open(2, 'w', encoding='utf-8', buffering=1, closefd=False)
    os.environ.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    os.chdir(ROOT)
    sys.path.insert(0, str(WORK))
    sys.argv = [str(script), *spec['args']]
    runpy.run_path(str(script), run_name='__main__')

if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] != '--run':
        raise ValueError('This entry point only runs an existing local launch specification')
    run_spec(sys.argv[2])
