import json, os, subprocess, socket, sys
from pathlib import Path
from datetime import datetime
from windows_independent import start_script
root=Path(__file__).resolve().parents[1]
base=root.parent
cfg=base/'抖音自用采集台/data/bridge.json'
c=json.loads(cfg.read_text(encoding='utf-8-sig'))
assert c['bridge']['host']=='127.0.0.1' and c['bridge']['port']==19422
assert c['bridge'].get('token'), 'Preserve existing credential; do not generate one'
status=subprocess.run([sys.executable,'-X','utf8',str(root/'work/launch_comments.py'),'--status'],cwd=root,capture_output=True,text=True,encoding='utf-8',check=True)
assert not json.loads(status.stdout)['running'], 'Collector mutex is still held; do not interrupt a healthy worker'
def listening(port):
    with socket.socket() as s:
        return s.connect_ex(('127.0.0.1',port))==0
assert not (root/'work/STOP').exists(), 'Existing STOP must remain untouched'
stamp=datetime.now().astimezone().isoformat()
(root/'work/STOP').write_text(json.dumps({'origin':'technical_disconnect','created_by':'Codex','created_at':stamp,'reason':'本人19422、19747服务及采集worker退出，本次技术恢复保护标记'},ensure_ascii=False,indent=2),encoding='utf-8')
result={'created_at':stamp,'scope':str(root),'reason':'原始最后评论响应正常，服务监听消失且采集互斥锁释放','ports':{}}
for port,script,log in [
    (19422,root/'work/run_owned_bridge.py','本人19422恢复'),
    (19747,root/'work/server.py','工作台19747恢复')]:
    if listening(port):
        result['ports'][str(port)]={'already_listening':True}
        continue
    pid=start_script(script,[],root/f'work/{log}.stdout.log',root/f'work/{log}.stderr.log')
    result['ports'][str(port)]={'started_pid':pid,'launch_method':'Win32_Process.Create'}
(root/f'work/本地服务恢复_{datetime.now():%Y%m%d_%H%M%S}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
