"""Serial controller for the approved local queue; existing Douyin CLI executes writes.

No classification, model, collection, DM, or shared project writes.
"""
import argparse
import collections
import datetime
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
WORK, OUT = ROOT / 'work', ROOT / 'outputs'
NODE = ROOT.parent / 'work/runtime/douyin-bridge/node.exe'
ADAPTER = WORK / 'reply_cli_bridge.cjs'
BINDING = WORK / '回复CLI绑定.json'
LOCK = WORK / 'reply_cli_worker.lock'


def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p, value):
    p = Path(p)
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(tmp, p)


def now():
    return datetime.datetime.now().astimezone().isoformat()


def db():
    return sqlite3.connect('file:' + (WORK / 'reply_receipts.sqlite3').as_posix() + '?mode=ro', uri=True)


def snapshot():
    account = load(WORK / '回复账号绑定.json')['account_id']
    with db() as c:
        rows = c.execute('select cid,status from sends where account=?', (account,)).fetchall()
    return dict(rows)


def prepare_tasks():
    q, rules = load(WORK / '评论回复队列.json'), load(WORK / '回复执行规则.json')
    assert rules['sending_authorized_now'] and rules['collection_remains_paused']
    templates = {t['product']: t['reply'] for t in rules['unified_templates']}
    seen, tasks = set(), []
    medium_seen = False
    with sqlite3.connect('file:' + (WORK / 'campaign.sqlite3').as_posix() + '?mode=ro', uri=True) as c:
        for x in q['items']:
            assert x['uid'] and x['uid'] not in seen, 'Queue UID is not unique'
            seen.add(x['uid'])
            assert x['source_verdict'] in ('高意向', '待确认')
            medium_seen = medium_seen or x['source_verdict'] == '待确认'
            assert not (medium_seen and x['source_verdict'] == '高意向'), 'Queue order invalid'
            assert templates[x['product']] == x['reply']
            assert hashlib.sha256(x['reply'].encode('utf-8')).hexdigest() == x['reply_sha256']
            row = c.execute('select data from records where id=?', (x['source_comment_id'],)).fetchone()
            assert row, 'Missing original source'
            original = json.loads(row[0])
            assert str(original['user_id']) == x['uid'] and original['text'] == x['source_text']
            assert original['source_url'] == x['source_url']
            subtype = original.get('subtype', 'root')
            assert subtype in ('root', 'reply')
            bare = x['source_comment_id'].removeprefix('comment:')
            parent = str(original.get('parent_comment_id') or bare)
            assert bare.isdigit() and parent.isdigit()
            assert subtype != 'reply' or parent != bare, 'Missing child root CID'
            video = x['source_url'].split('?')[0].rstrip('/').split('/')[-1]
            assert video.isdigit()
            tasks.append({**x, 'root_cid': parent if subtype == 'reply' else bare,
                          'subtype': subtype, 'video_id': video})
    return tasks


def counts(tasks):
    ledger = snapshot()
    result = dict(collections.Counter(ledger.values()))
    return {'total': len(tasks), 'high': sum(t['source_verdict'] == '高意向' for t in tasks),
            'medium': sum(t['source_verdict'] == '待确认' for t in tasks),
            'sent_verified': result.get('SENT_VERIFIED', 0),
            'pending': sum(t['source_comment_id'] not in ledger for t in tasks),
            'ledger': result, 'child_reply_tasks': sum(t['subtype'] == 'reply' for t in tasks)}


def running():
    with LOCK.open('a+b') as f:
        f.seek(0)
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return True
        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        return False


def call_adapter(op, task_file=None):
    args = [str(NODE), str(ADAPTER), op]
    if task_file:
        args.append(str(task_file))
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, encoding='utf-8',
                            creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        return json.loads(result.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError) as exc:
        # A child transport/process crash can have happened after a publish.
        return {'ok': False, 'status': 'UNKNOWN', 'error': 'Adapter returned no complete receipt',
                'stderr': result.stderr, 'publish_attempted': True}


def progress(status, blocker=None, **extra):
    p = OUT / '评论回复进度.json'
    value = load(p)
    ledger = snapshot()
    states = dict(collections.Counter(ledger.values()))
    value.update(status=status, current_blocker=blocker, updated=now(),
                 sent_verified=states.get('SENT_VERIFIED', 0),
                 unknown_receipts=states.get('UNKNOWN', 0), reply_ledger_statuses=states,
                 execution_method='existing_douyin_cli_serial_queue', **extra)
    save(p, value)
    q = load(WORK / '评论回复队列.json')
    q['summary'].update(sent_verified=value['sent_verified'], pending=sum(x['source_comment_id'] not in ledger for x in q['items']),
                        status=status, updated=now())
    save(WORK / '评论回复队列.json', q)


def track(action, task, evidence, note):
    result = subprocess.run([sys.executable, '-X', 'utf8', str(WORK / 'track_reply.py'), action,
                             '--position', str(task['position']), '--evidence', evidence, '--note', note],
                            cwd=ROOT, capture_output=True, text=True, encoding='utf-8',
                            creationflags=subprocess.CREATE_NO_WINDOW)
    if result.returncode:
        raise RuntimeError('Receipt transaction rejected: ' + result.stderr[-1000:])


def execute(limit):
    with LOCK.open('a+b') as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        try:
            save(WORK / 'reply_cli_worker.pid.json', {'pid': os.getpid(), 'started': now()})
            if (WORK / '回复STOP.json').exists():
                progress('PAUSED_REPLY_STOP', '本项目回复STOP保留'); return
            check = call_adapter('probe')
            save(OUT / '回复CLI预检.json', check)
            if not check.get('ok'):
                progress('WAITING_CLI_ACCOUNT', check.get('status'), preflight=check); return
            binding = load(BINDING)
            if not binding.get('account_verified'):
                progress('WAITING_CLI_BINDING', '账号已匹配，需完成首次绑定验收'); return
            ledger = snapshot()
            if any(v in ('RESERVED', 'UNKNOWN') for v in ledger.values()):
                progress('PAUSED_UNKNOWN_RECEIPT', '先核查已有预留或未知回执，禁止重发'); return
            tasks = prepare_tasks()
            taskdir = WORK / 'reply-cli-tasks'; taskdir.mkdir(exist_ok=True)
            attempted = 0
            for task in tasks:
                if task['source_comment_id'] in snapshot():
                    continue
                if (WORK / '回复STOP.json').exists():
                    progress('PAUSED_REPLY_STOP'); return
                if attempted >= limit:
                    progress('READY_FOR_NEXT'); return
                file = taskdir / f"{task['position']:04d}.json"; save(file, task)
                evidence = f"outputs/回复CLI回执_{task['position']:04d}.json"
                track('reserve', task, '', 'CLI队列单账号预留，尚未发送')
                try:
                    result = call_adapter('send', file)
                except BaseException:
                    track('unknown', task, '', '执行器中断；先核查，禁止重发')
                    raise
                save(ROOT / evidence, result)
                attempted += 1
                if result.get('status') == 'SENT_VERIFIED' and result.get('ok'):
                    assert result['source_comment_id'] == task['source_comment_id']
                    assert result['account_id'] == load(WORK / '回复账号绑定.json')['account_id']
                    track('sent', task, evidence, 'CLI原评论身份匹配，发布及在线回读均匹配')
                    q = load(WORK / '评论回复队列.json')
                    q['items'][task['position'] - 1]['platform_reply_id'] = result['platform_reply_id']
                    save(WORK / '评论回复队列.json', q)
                    progress('REPLYING')
                    print(json.dumps({'position': task['position'], 'status': 'SENT_VERIFIED'}, ensure_ascii=False), flush=True)
                    continue
                action = 'unknown' if result.get('publish_attempted') or result.get('status') == 'EXISTING_REPLY_REQUIRES_RECONCILIATION' else 'defer'
                track(action, task, evidence, result.get('error', result.get('status', 'Unknown result')))
                if result.get('status') == 'SOURCE_NOT_FOUND':
                    progress('REPLYING', '部分原评论已不可核验，已跳过'); continue
                save(WORK / '回复STOP.json', {'origin': 'Codex_reply_cli_guard', 'created': now(),
                     'reason': result.get('error', result.get('status')), 'position': task['position'], 'evidence': evidence})
                progress('PAUSED_REPLY_STOP', '验证、账号或回执异常；停止且不重试', evidence=evidence)
                return
            progress('QUEUE_FINISHED')
        finally:
            lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def main():
    p = argparse.ArgumentParser()
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--dry-run', action='store_true')
    g.add_argument('--status', action='store_true')
    g.add_argument('--probe', action='store_true')
    g.add_argument('--bind', metavar='CONNECTION_ID')
    g.add_argument('--run', action='store_true')
    g.add_argument('--start', action='store_true')
    p.add_argument('--limit', type=int, default=100000)
    a = p.parse_args()
    if a.dry_run or a.status:
        print(json.dumps({**counts(prepare_tasks()), 'running': running(), 'network_calls': 0}, ensure_ascii=False)); return
    if a.bind:
        assert not running(), 'Worker already running'
        save(BINDING, {'conn_id': a.bind, 'expected_account_id': load(WORK / '回复账号绑定.json')['account_id'],
                       'account_verified': False, 'server_port': 19422, 'updated': now()})
    if a.probe or a.bind:
        result = call_adapter('probe'); save(OUT / '回复CLI预检.json', result)
        if a.bind and result.get('ok'):
            b = load(BINDING); b.update(account_verified=True, evidence=result, updated=now()); save(BINDING, b)
        progress('READY_CLI' if result.get('ok') else 'WAITING_CLI_ACCOUNT', None if result.get('ok') else result.get('status'), preflight=result)
        print(json.dumps(result, ensure_ascii=False)); return
    if a.start:
        assert not running(), '唯一回复worker已经运行'
        check = call_adapter('probe'); save(OUT / '回复CLI预检.json', check)
        if not check.get('ok') or not load(BINDING).get('account_verified'):
            progress('WAITING_CLI_ACCOUNT', check.get('status'), preflight=check)
            print(json.dumps({'started': False, 'preflight': check}, ensure_ascii=False)); return
        from windows_independent import start_script
        pid = start_script(WORK / 'reply_cli_worker.py', ['--run', '--limit', str(a.limit)],
                           WORK / 'reply_cli_worker.stdout.log', WORK / 'reply_cli_worker.stderr.log')
        print(json.dumps({'started': True, 'launcher_pid': pid})); return
    execute(a.limit)


if __name__ == '__main__':
    main()
