import json
from pathlib import Path
rows=[
(1,'调侃测试账号被封，无本人采购需求。'),
(2,'叙述自己的工具账号未被封的使用情况，非采购需求，不执行其平台检测说法。'),
(3,'向他人解释一个账号和AI推送的观点，无本人服务需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,4))
p=Path('work/review-batches/20261011_050004_579436_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
