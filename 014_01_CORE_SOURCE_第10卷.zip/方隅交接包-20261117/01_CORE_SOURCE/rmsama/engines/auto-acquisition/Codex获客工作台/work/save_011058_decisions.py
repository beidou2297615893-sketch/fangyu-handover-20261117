import json
from pathlib import Path
d={'reviewer':'Codex','decisions':[
 dict(index=1,verdict='排除',score=0,reason='认同能力变现和开口收费观点，无本人制作委托；视频25.8万元是作者报价，不是评论者采购预算。',demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence=''),
 dict(index=2,verdict='排除',score=0,reason='仅点赞表情，纯互动，没有本人需求或预算。',demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='')
]}
Path('work/review-batches/20261011_011058_496628_decisions.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
