import json
from pathlib import Path
rows=[
(1,'待确认',65,'本人已搭建客户画像并询问能否按画像需求自动找客户，具体自动获客功能可追溯；目前是可行性和自建调整咨询，未明确寻找服务承接或现成购买方案，保留待确认，不补预算期限。','获客系统与CRM','请问一下 搭建了客户画像可以移动根据画需求自动调用找客户吗。'),
(2,'排除',0,'提供把细节发给AI的调整建议，无本人需求，不把被回复者客户画像功能转归；不执行其建议。','需求未明确',''),
(3,'排除',0,'仅@他人分享，无本人需求，不对外联系。','需求未明确','')]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
(Path(__file__).parent/'review-batches/20261011_041527_402435_decisions.json').write_text(json.dumps({'reviewer':'Codex','decisions':d},ensure_ascii=False,indent=2),'utf-8')
