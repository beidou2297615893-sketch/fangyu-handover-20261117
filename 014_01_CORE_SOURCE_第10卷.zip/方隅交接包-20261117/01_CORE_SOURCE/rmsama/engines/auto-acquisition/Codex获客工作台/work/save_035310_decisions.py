import json
from pathlib import Path
# 当前Codex全文读取20条后明确逐条排除；仅保存，不进行关键词判断。
rows=[
 (1,'点赞及666表情，纯互动，无本人需求。'),
 (2,'感谢分享并评价AI好用，是使用反馈，无新的服务需求。'),
 (3,'点赞并感谢分享，无本人采购。'),
 (4,'感谢老师干货分享，纯互动。'),
 (5,'666和比心表情，无本人需求。'),
 (6,'仅平安果表情，纯互动。'),
 (7,'仅点赞表情，无本人服务诉求。'),
 (8,'仅点赞，未表达采购。'),
 (9,'仅点赞表情，无本人需求。'),
 (10,'仅点赞，纯互动。'),
 (11,'感谢分享，没有具体本人业务或服务需求。'),
 (12,'仅点赞表情，纯互动。'),
 (13,'点赞玫瑰鼓掌666互动，没有本人需求。'),
 (14,'只问怎么变现，是泛经营问题，未提出软件、获客、自动化或视频制作服务需求。'),
 (15,'仅点赞表情，无服务诉求。'),
 (16,'仅点赞，无本人采购。'),
 (17,'仅爱心表情，纯互动。'),
 (18,'仅点赞，没有本人需求。'),
 (19,'仅给力表情，纯互动。'),
 (20,'仅点赞表情，没有采购证据。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
p=Path(__file__).parent/'review-batches/20261011_035310_480832_decisions.json'
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(len(d))
