import copy,datetime,json,urllib.request
import control
s=control.read();s['leads']=[];s['stats']={'read':0,'excluded':0};s['criteria'].update(intent=['求租'],exclude=['广告'],region='苏州',days=30)
xhs=control.normalize({'items':[{'id':'test-note','note_card':{'display_title':'苏州求租','user':{'nickname':'测试'}}}]},'小红书','note')
assert xhs[0]['kind']=='note'
dy=control.normalize([{'aweme_info':{'aweme_id':'123','desc':'苏州求租','author':{'nickname':'测试'}}}],'抖音','note')
assert dy[0]['url']=='https://www.douyin.com/video/123'
comments=control.normalize({'comments':[{'id':'test-comment','content':'苏州求租','user_info':{'nickname':'测试'}}]},'小红书','comment','https://www.xiaohongshu.com/explore/test')
control.screen(s,comments);control.screen(s,comments)
assert len(s['leads'])==1 and s['leads'][0]['verdict']=='有需求信号'
assert '发表时间待核实' in s['leads'][0]['reasons']
bad=copy.deepcopy(comments[0]);bad['id']='excluded';bad['text']='广告求租'
old=copy.deepcopy(comments[0]);old['id']='old';old['published']=(datetime.datetime.now().astimezone()-datetime.timedelta(days=60)).isoformat()
control.screen(s,[bad,old]);assert len(s['leads'])==1 and s['stats']['excluded']==2
for route in ['/','/api/state','/api/inventory']:
 with urllib.request.urlopen('http://127.0.0.1:19747'+route) as r:assert r.status==200
try:urllib.request.urlopen('http://127.0.0.1:19747/../../work/control.py')
except urllib.error.HTTPError as e:assert e.code==404
else:raise AssertionError('unexpected source access')
report={'verified_at':control.now(),'checks':['小红书笔记和评论映射','抖音视频映射','同来源去重','排除词过滤','时间过滤与未知时间标记','本机页面及两个数据接口','路径访问边界'],'real_collection':'未验证：客户要求未提供，Python CLI 未登录','ui_approval':'待用户确认','test_data':'只在内存测试，未写入候选客户'}
(control.ROOT/'outputs/验收记录.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print('7 项检查通过；测试客户未写入工作台')
