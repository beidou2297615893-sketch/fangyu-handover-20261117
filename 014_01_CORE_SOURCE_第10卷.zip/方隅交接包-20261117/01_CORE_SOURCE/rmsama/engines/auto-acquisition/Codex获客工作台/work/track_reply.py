"""本地串行预留和回执账本；无网络、无平台发送、无语义判定。"""
import argparse,datetime,hashlib,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'work'; OUT=ROOT/'outputs'
parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['reserve','sent','reconcile-sent','unknown','defer','status'])
parser.add_argument('--position',type=int)
parser.add_argument('--evidence',default='')
parser.add_argument('--note',default='')
a=parser.parse_args()
binding=json.loads((WORK/'回复账号绑定.json').read_text('utf-8'))
assert binding['binding_status']=='VERIFIED'
account=binding['account_id']
queue=json.loads((WORK/'评论回复队列.json').read_text('utf-8'))
c=sqlite3.connect(WORK/'reply_receipts.sqlite3',timeout=10)
c.execute('pragma journal_mode=WAL')
c.execute('create table if not exists sends(account text, cid text, uid text, position integer, status text, text text, sha text, evidence text, note text, updated text, primary key(account,cid))')
c.execute("create unique index if not exists one_active_sender on sends(account) where status in ('RESERVED','UNKNOWN')")
c.execute('create table if not exists events(id integer primary key, account text, cid text, event text, evidence text, note text, at text)')
c.commit()
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
if a.action!='status':
    assert a.position and 1<=a.position<=len(queue['items'])
    x=queue['items'][a.position-1]
    assert x['position']==a.position
    cid=x['source_comment_id']
    with c:
        c.execute('begin immediate')
        existing=c.execute('select status from sends where account=? and cid=?',(account,cid)).fetchone()
        if a.action=='reserve':
            assert not (WORK/'回复STOP.json').exists(), '平台回复暂停标记尚未解除'
            assert not existing, '该评论已有状态；禁止盲目重复预留发送'
            assert not c.execute("select 1 from sends where account=? and uid=? and status='SENT_VERIFIED'",(account,x['uid'])).fetchone(), '同UID已回复'
            c.execute('insert into sends values(?,?,?,?,?,?,?,?,?,?)',(account,cid,x['uid'],a.position,'RESERVED',x['reply'],x['reply_sha256'],a.evidence,a.note,now))
            event='RESERVED'
        else:
            assert existing and existing[0]==('UNKNOWN' if a.action=='reconcile-sent' else 'RESERVED'), '仅结束当前预留，或持真实回执核对UNKNOWN；禁止盲目重试'
            event={'sent':'SENT_VERIFIED','reconcile-sent':'SENT_VERIFIED','unknown':'UNKNOWN','defer':'DEFERRED'}[a.action]
            if a.action in ('sent','reconcile-sent'):
                assert a.evidence and (ROOT/a.evidence).is_file(), '缺少真实回执证据文件'
            if a.action=='reconcile-sent':
                receipt=json.loads((ROOT/a.evidence).read_text('utf-8'))
                assert receipt['source_comment_id']==cid and receipt['position']==a.position
                assert x['source_text'] in receipt['thread_text'] and x['reply'] in receipt['thread_text']
                assert any(l['name']==binding['account_name'] and l['href'].endswith('/'+account) for l in receipt['links']), '回执本人账号不一致'
            c.execute('update sends set status=?,evidence=?,note=?,updated=? where account=? and cid=?',(event,a.evidence,a.note,now,account,cid))
        c.execute('insert into events(account,cid,event,evidence,note,at) values(?,?,?,?,?,?)',(account,cid,event,a.evidence,a.note,now))
    x.update(status=event,sending_account_id=account,receipt=a.evidence or None,live_source_verified=True)
    queue_tmp=WORK/'评论回复队列.json.tmp'
    queue_tmp.write_text(json.dumps(queue,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    queue_tmp.replace(WORK/'评论回复队列.json')
rows=c.execute('select status,count(*) from sends where account=? group by status',(account,)).fetchall()
counts=dict(rows)
p=OUT/'评论回复进度.json'; progress=json.loads(p.read_text('utf-8'))
progress.update(sent_verified=counts.get('SENT_VERIFIED',0),unknown_receipts=counts.get('UNKNOWN',0),reply_ledger_statuses=counts,account_id=account,account_name=binding['account_name'],douyin_handle=binding['douyin_handle'],updated=now,status='REPLYING' if counts.get('RESERVED') else ('PAUSED_UNKNOWN_RECEIPT' if counts.get('UNKNOWN') else 'READY_FOR_NEXT'),current_blocker='发送回执未知，需核查' if counts.get('UNKNOWN') else None)
p.write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'account':binding['douyin_handle'],'status':progress['status'],'counts':counts},ensure_ascii=False))
