import json
from pathlib import Path
rows=[
 (1,'只留工具关键词，领取互动而非具体委托。'),
 (2,'只留工具关键词，不从民宿昵称推断获客采购。'),
 (3,'只留工具关键词，不从设备租赁昵称推断系统需求。'),
 (4,'只留工具关键词，无本人需求。'),
 (5,'只留工具关键词，无具体服务需求。'),
 (6,'只留工具关键词，无采购表达。'),
 (7,'只留工具关键词，无具体委托。'),
 (8,'只留工具关键词，无本人需求。'),
 (9,'只留工具关键词，无具体委托。'),
 (10,'只留工具关键词，无本人需求。'),
 (11,'只留工具关键词，无采购表达。'),
 (12,'只留工具关键词，无具体服务需求。'),
 (13,'只留工具关键词，不从手机壳昵称推断软件需求。'),
 (14,'只留工具关键词，无采购表达。'),
 (15,'只留工具关键词，无本人具体需求。'),
 (16,'只留工具关键词，无具体委托。')
]
ds=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [d['index'] for d in ds]==list(range(1,17))
out=Path(__file__).parent/'review-batches/20261011_053511_588940_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
