"""Read-only audit of actual Codex decisions, source coverage and refreshed Excel."""
import collections, datetime, hashlib, json, sqlite3
from pathlib import Path
from codex_review import effective_reviews

ROOT = Path(__file__).resolve().parents[1]
WORK, OUT = ROOT / 'work', ROOT / 'outputs'
def read(p):
    return json.loads(p.read_text('utf-8'))

baseline = read(WORK / '全评论分析_20261012_基线.json')
old_ids = set(baseline['original_ids'])
with sqlite3.connect((WORK / 'codex_reviews.sqlite3').as_uri() + '?mode=ro', uri=True) as c:
    originals = c.execute('select id,data from reviews order by id').fetchall()
    rechecks = c.execute('select id,data from review_rechecks order by id').fetchall()
    effective = {x['id']: x for x in effective_reviews(c)}
    old_rows = [x for x in originals if x[0] in old_ids]
    digest = lambda x: hashlib.sha256(json.dumps(x, ensure_ascii=False).encode()).hexdigest()
    assert digest(old_rows) == baseline['original_hash']
    assert digest(rechecks) == baseline['recheck_hash']
with sqlite3.connect((WORK / 'campaign.sqlite3').as_uri() + '?mode=ro', uri=True) as c:
    records = {i: json.loads(d) for i,d in c.execute("select id,data from records where id like 'comment:%'")}
assert set(records) == set(effective)
for ident, d in effective.items():
    r = records[ident]
    assert d['reviewer'] == 'Codex'
    assert d['verdict'] in ('高意向', '待确认', '排除') and 0 <= d['score'] <= 100
    assert d['reason'].strip()
    assert d['record']['text'] == r['text'] and d['record']['user_id'] == r['user_id']
    for key in ('demand_evidence', 'budget_evidence', 'payment_evidence', 'urgent_evidence'):
        assert not d.get(key) or d[key] in r['text'], (ident, key)
    if d['verdict'] == '高意向':
        assert d['score'] >= 80 and d.get('demand_evidence') and r['user_id']
snapshot = read(WORK / '客户分类快照.json')
assert {x['id'] for x in snapshot['rows']} == set(records)
assert not any(x['verdict'] == '待分析' for x in snapshot['rows'])
assert len({x['uid'] for x in snapshot['customers']}) == len(snapshot['customers'])
for x in snapshot['customers']:
    assert x['recent'] and x['uid'] and x['verdict'] in ('高意向','待确认')
    assert x['url'] == 'https://www.douyin.com/video/' + x['post_id']
verified = read(OUT / '本轮增量复核验收.json')
assert verified['errors'] == [] and verified['native_filtered_tables'] == 11
assert verified['reviewed_total'] == len(records) and verified['excel_pending'] == 0
assert verified['search_keywords'] == 420
stop = read(WORK / 'STOP')
assert stop['user_requested_pause'] is True
config = Path('C:/Users/rmsama/.codex/automations/automation-13/automation.toml').read_text('utf-8')
assert 'status = "PAUSED"' in config
file = Path(verified['excel_file'])
result = {
    'audited_at': datetime.datetime.now().astimezone().isoformat(),
    'collection_paused': True, 'automation_status': 'PAUSED',
    'collected_comments': len(records), 'codex_reviewed_total': len(effective),
    'previous_original_reviews_preserved': len(old_rows),
    'previous_original_reviews_hash_unchanged': True,
    'historical_rechecks_preserved': len(rechecks), 'historical_rechecks_hash_unchanged': True,
    'newly_read_and_reviewed_this_task': len(originals) - len(old_rows),
    'new_review_verdicts': dict(collections.Counter(json.loads(d)['verdict'] for i,d in originals if i not in old_ids)),
    'pending_all_comments': 0,
    'effective_comment_verdicts': dict(collections.Counter(x['verdict'] for x in effective.values())),
    'deduplicated_current_customer_verdicts': dict(collections.Counter(x['verdict'] for x in snapshot['customers'])),
    'customer_total': len(snapshot['customers']), 'demand_types': {k:len(v) for k,v in snapshot['types'].items()},
    'all_evidence_is_commenter_exact_text': True,
    'all_xlsx_conclusions_match_latest_codex_ledger': True,
    'native_filtered_tables': verified['native_filtered_tables'],
    'verified_native_customer_video_links': verified['verified_customer_video_links'],
    'search_keywords': 420, 'excel_file': str(file), 'excel_sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
    'note': '本任务逐条完整读取并补评此前未入账的332条；其余15795条既有Codex分析和3331条独立复审保留。本任务核对全量覆盖、原话证据、账本与Excel对应，不声称今天重新逐条语义阅读全部历史评论。采集与心跳均保持用户暂停。',
    'errors': []
}
target = OUT / '全评论意向分析验收_20261012.json'
target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
