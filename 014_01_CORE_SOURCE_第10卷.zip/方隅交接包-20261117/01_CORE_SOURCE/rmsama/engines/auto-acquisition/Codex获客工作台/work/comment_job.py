"""Persistent, serialized public-comment collection through the existing Douyin CLI.

Videos are discovery metadata. Only deduplicated comments count toward the target.
All original responses and older/excluded comments remain archived locally.
"""
import argparse,csv,datetime,json,msvcrt,os,random,sqlite3,time
from pathlib import Path
import control
from campaign_collect import BridgeAdapter,db,get,put,row
from qualify import qualify,START,is_recent,date_window

ROOT=control.ROOT;WORK=ROOT/'work';OUT=ROOT/'outputs'
COMMENT="id like 'comment:%'"

def transient_network_error(message):
 # Browser fetch uses "Failed to fetch"; Node may use "fetch failed".
 # Keep the existing finite retries and never classify platform restrictions here.
 return any(t in str(message).lower() for t in ['timeout','timed out','fetch failed','failed to fetch','econnreset','超时'])

def write_json(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp')
 tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),'utf-8');tmp.replace(path)

def setup(c):
 c.executescript('''
 create table if not exists comment_index(id text primary key,recent integer,user_id text);
 create table if not exists video_queue(vid text primary key,data text,hint integer,visits integer default 0,exhausted integer default 0);
 create table if not exists reply_queue(cid text primary key,data text,visits integer default 0,exhausted integer default 0);
 create table if not exists search_state(qid integer primary key,cursor integer default 0,pages integer default 0,exhausted integer default 0);
 create index if not exists records_user on records(user_id);
 ''')

def persist(c,x):
 if not x.get('source_id'):raise RuntimeError('评论缺少稳定ID，停止解析')
 q=qualify(x);x['qualification']=q
 c.execute('insert or ignore into records values(?,?,?,?,?,?,?)',(x['id'],x['user_id'],json.dumps(x,ensure_ascii=False),q['score'],q['tier'],q['urgent'],q['budget_ready']))
 if x['kind']=='comment':
  recent=int(q['date_verified'] and bool(x['text'].strip()))
  c.execute('insert or ignore into comment_index values(?,?,?)',(x['id'],recent,x['user_id']))

def queue_video(c,v,query):
 vid=str(v.get('aweme_id',''))
 if not vid:raise RuntimeError('搜索作品缺少ID')
 hint=int((v.get('statistics') or {}).get('comment_count',1) or 0)
 data=dict(id=vid,text=v.get('desc',''),query=query,published_at=v.get('create_time'))
 c.execute('insert or ignore into video_queue values(?,?,?,?,?)',(vid,json.dumps(data,ensure_ascii=False),hint,int(get(c,'cursor:'+vid,0))//20,int(get(c,'video_done:'+vid,False))))
 c.execute('update video_queue set hint=max(hint,?) where vid=?',(hint,vid))
 persist(c,row(v,'note',vid,query))

def ingest_comment(c,item,video,parent=None):
 x=row(item,'comment',video['id'],video['query'])
 x['parent_text']=video.get('text','')
 if parent:x.update(subtype='reply',parent_comment_id=parent.get('cid',''),reply_to_text=parent.get('text',''))
 else:x['subtype']='root'
 persist(c,x)
 if not parent and int(item.get('reply_comment_total',0) or 0)>0:
  data=dict(video=video,comment=dict(cid=str(item['cid']),text=item.get('text','')))
  c.execute('insert or ignore into reply_queue(cid,data) values(?,?)',(str(item['cid']),json.dumps(data,ensure_ascii=False)))
 # The platform sometimes includes a first reply in its root-comment page.
 for reply in item.get('reply_comment') or []:
  if isinstance(reply,dict) and reply.get('cid') and reply.get('user'):
   ingest_comment(c,reply,video,dict(cid=str(item['cid']),text=item.get('text','')))

def migrate(c,queries):
 if get(c,'comment_job_migrated',False):return
 by_text={q['query']:q for q in queries};by_id={q['id']:q for q in queries}
 for ident,data in c.execute('select id,data from records').fetchall():
  x=json.loads(data)
  if x.get('kind')=='comment':
   c.execute('insert or ignore into comment_index values(?,?,?)',(ident,int(x['qualification']['date_verified'] and bool(x['text'].strip())),x['user_id']))
 # Reuse only this project's genuine responses, never old customer datasets.
 for p in sorted((WORK/'raw-campaign').glob('*.json')):
  raw=json.loads(p.read_text('utf-8'));payload=raw.get('payload',{})
  query=by_text.get(raw.get('source'))
  if query and isinstance(payload.get('data'),list):
   for item in payload['data']:
    if isinstance(item,dict) and isinstance(item.get('aweme_info'),dict):queue_video(c,item['aweme_info'],query)
   c.execute('insert or replace into search_state values(?,?,?,?)',(query['id'],int(payload.get('cursor',20)),1,int(not payload.get('has_more'))))
  if isinstance(payload.get('comments'),list):
   vid=str(raw.get('source',''));v=c.execute('select data from video_queue where vid=?',(vid,)).fetchone()
   if v:
    video=json.loads(v[0])
    for item in payload['comments']:ingest_comment(c,item,video)
 put(c,'comment_job_migrated',True)

def counts(c):
 # Only date eligibility is refreshed; immutable source records and reviews stay intact.
 day=date_window()[0].isoformat()
 if get(c,'comment_date_window',None)!=day:
  eligibility=[(int(is_recent(x.get('published_at')) and bool(x.get('text','').strip())),ident) for ident,data in c.execute("select id,data from records where id like 'comment:%'") for x in [json.loads(data)]]
  c.executemany('update comment_index set recent=? where id=?',eligibility)
  put(c,'comment_date_window',day)
 total=c.execute('select count(*) from comment_index').fetchone()[0]
 recent=c.execute('select count(*) from comment_index where recent=1').fetchone()[0]
 unique=c.execute("select count(distinct user_id) from comment_index where user_id!=''").fetchone()[0]
 high=c.execute(f"select count(distinct user_id) from records where {COMMENT} and tier='高意向'").fetchone()[0]
 urgent=c.execute(f"select count(distinct user_id) from records where {COMMENT} and tier='高意向' and budget=1 and urgent=1").fetchone()[0]
 videos=c.execute('select count(*) from video_queue').fetchone()[0]
 searched=c.execute('select count(*) from search_state where pages>0').fetchone()[0]
 return dict(collected=total,recent=recent,unique=unique,high=high,urgent=urgent,videos=videos,query_done=searched)

def date_text(value):
 try:return datetime.datetime.fromtimestamp(float(value),datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
 except (ValueError,TypeError,OverflowError):return '日期待核实'

def export(c,full=False):
 high_rows=[json.loads(r[0]) for r in c.execute(f"select data from records where {COMMENT} and tier='高意向'")]
 def rank(x):
  q=x['qualification'];return (q['urgent'] and q['budget_ready'],q['budget_ready'],q['urgent'],bool(q.get('payment_evidence')),q['score'],x.get('published_at') or 0)
 high_rows.sort(key=rank,reverse=True);people={}
 for x in high_rows:
  if x['user_id'] and x['user_id'] not in people:people[x['user_id']]={'best':x,'evidence':[]}
  if len(people)>=1000:break
 if people:
  marks=','.join('?' for _ in people)
  for data, in c.execute(f"select data from records where {COMMENT} and user_id in ({marks})",list(people)):
   x=json.loads(data);people[x['user_id']]['evidence'].append(x)
 selected=list(people.values());write_json(OUT/'高意向待复核.json',selected)
 with (OUT/'高意向待复核.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['用户ID','昵称','规则分','评论原话','预算原话','付费意愿原话','紧急原话','发表时间','原始视频','评论ID','人工复核'])
  for v in selected:
   x=v['best'];q=x['qualification'];w.writerow([x['user_id'],x['author'],q['score'],x['text'],q['budget_evidence'],q.get('payment_evidence',''),q['urgent_evidence'],date_text(x['published_at']),x['source_url'],x['source_id'],'未复核'])
 if full:
  for filename,condition in [('全部评论.jsonl',COMMENT),('全部采集记录.jsonl',COMMENT),('视频入口.jsonl',"id like 'note:%'")]:
   temp=OUT/(filename+'.tmp')
   with temp.open('w',encoding='utf-8') as f:
    for data, in c.execute('select data from records where '+condition):f.write(data+'\n')
   temp.replace(OUT/filename)
 return [dict(id=v['best']['id'],author=v['best']['author'],platform='抖音',text=v['best']['text'],url=v['best']['source_url'],verdict='高意向评论待复核',score=v['best']['qualification']['score'],budget_evidence=v['best']['qualification']['budget_evidence'],payment_evidence=v['best']['qualification'].get('payment_evidence',''),urgent_evidence=v['best']['qualification']['urgent_evidence']) for v in selected[:100]]

def progress(c,status,target,full=False):
 c.commit();stats=counts(c);s=control.read();s['status']=status
 s['campaign'].update(stats,phase=status,count_unit='comment',raw_target=target,goal_unit='近三个月去重文字评论',first_phase=1000)
 s['leads']=export(c,full);control.save(s)
 write_json(WORK/'评论任务进度.json',dict(pid=os.getpid(),updated=control.now(),status=status,target=target,stats=stats))
 (OUT/'本轮采集进度.md').write_text('# 持续评论采集\n\n状态：'+status+'\n\n已保存去重评论'+str(stats['collected'])+'条，其中近三个月文字评论'+str(stats['recent'])+'条；目标'+str(target)+'条。视频入口不计入评论数量。\n\n高意向评论用户'+str(stats['high'])+'位，全部仍须内容复核；不等同承诺付款。1000条只是检查点，持续采集主评论和楼中楼，保留原文、日期、ID、来源及排除项。\n\n实时数量看桌面工作台。最终最多1000位客户，不足如实交付。\n','utf-8')
 for threshold in [1000,5000,10000,20000]:
  if stats['recent']>=threshold and not get(c,'comment_milestone:'+str(threshold),False):
   write_json(OUT/('评论检查点'+str(threshold)+'.json'),dict(time=control.now(),stats=stats,completed_list=False,note='评论检查点，继续采集；规则分不是人工验收'))
   put(c,'comment_milestone:'+str(threshold),True)
 return stats

class AlreadyRunning(Exception):pass
class PlatformStop(Exception):pass
class UserStop(Exception):pass

def run(target,sample=False):
 lock_path=WORK/'collector.lock'
 with lock_path.open('r+b' if lock_path.exists() else 'w+b') as lock:
  if not lock_path.stat().st_size:lock.write(b'0');lock.flush()
  lock.seek(0)
  try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
  except OSError:raise AlreadyRunning('已有评论采集任务运行，不重复启动')
  c=db();setup(c);client=BridgeAdapter();calls=0;last_export=0;since_search=0
  queries=json.loads((OUT/'采集计划.json').read_text('utf-8'))['queries']
  groups=list(dict.fromkeys(q['category'] for q in queries));order=['找人做','急需开发','定制报价','哪里可以做','预算多少钱']
  queries.sort(key=lambda q:(next((i for i,v in enumerate(order) if q['query'].endswith(v)),4),(q['id']-1)%5,groups.index(q['category'])))
  migrate(c,queries)
  write_json(WORK/'采集任务.json',dict(pid=os.getpid(),target=target,script=str(Path(__file__).resolve()),started=control.now(),count_unit='comment',mode='sample' if sample else 'continuous',connection_id=client.conn))
  def emit(message,force=False):
   nonlocal last_export
   total=counts(c)['collected'];full=force or total-last_export>=500
   result=progress(c,message,target,full)
   if full:last_export=total
   print(control.now(),json.dumps(result,ensure_ascii=False),message,flush=True);return result
  def check_stop():
   if (WORK/'STOP').exists():raise UserStop('已按停止标记暂停，断点和原始评论保留')
  def read(kind,key,fn):
   nonlocal calls
   check_stop()
   for attempt in range(3):
    delay=max(0,float(get(c,'last_read',0))+random.uniform(30,50)-time.time());deadline=time.monotonic()+delay
    while time.monotonic()<deadline:check_stop();time.sleep(min(1,max(0,deadline-time.monotonic())))
    check_stop()
    try:p=fn()
    except Exception as e:
     put(c,'last_read',time.time());msg=str(e)
     retry=transient_network_error(msg)
     if retry and attempt<2:emit('读取暂时超时 · 保留断点后重试');continue
     raise
    finally:put(c,'last_read',time.time())
    calls+=1;raw=WORK/'raw-campaign';raw.mkdir(exist_ok=True)
    write_json(raw/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+kind+'.json'),dict(source=key,operation=kind,collected_at=control.now(),payload=p))
    if not isinstance(p,dict):raise PlatformStop('平台返回格式异常，已保存证据并停止')
    if p.get('status_code',0)!=0:raise PlatformStop('平台返回错误或限制，已停止，待Codex检查原始响应')
    nil=p.get('search_nil_info') or {}
    if nil.get('search_nil_type')=='verify_check':raise PlatformStop('平台要求验证码，已停止，需要本人处理')
    return p
   raise RuntimeError('连续读取超时，断点保留')
  def next_search():
   # Cover every keyword before taking a second search page.
   states={qid:(cursor,pages,exhausted) for qid,cursor,pages,exhausted in c.execute('select * from search_state')}
   if float(get(c,'search_resume_after',0))>time.time():return None
   valid=[q for q in queries if not states.get(q['id'],(0,0,0))[2] and float(get(c,'search_deferred:'+str(q['id']),0))<=time.time()]
   if not valid:return None
   # Interleave the newly authorized service with the original service searches.
   # IDs and pagination remain unchanged, so restarting resumes existing work.
   new=[q for q in valid if q['category']=='多平台发布']
   original=[q for q in valid if q['category']!='多平台发布']
   if new and original:valid=original if get(c,'last_search_category','')=='多平台发布' else new
   return min(valid,key=lambda q:states.get(q['id'],(0,0,0))[1])
  try:
   stats=emit('持续采集评论 · 1000条仅作检查点',True)
   while stats['recent']<target:
    check_stop()
    video=c.execute("select vid,data from video_queue where exhausted=0 and hint>0 order by case when cast(json_extract(data,'$.published_at') as integer)>=? then 0 else 1 end,visits,hint desc,rowid limit 1",(int(START.timestamp()),)).fetchone()
    reply=c.execute('select cid,data from reply_queue where exhausted=0 order by visits,rowid limit 1').fetchone()
    query=next_search()
    if query and (since_search>=5 or not(video or reply)):
     old=c.execute('select cursor,pages from search_state where qid=?',(query['id'],)).fetchone();cursor,pages=old if old else (0,0)
     try:p=read('search',query['query'],lambda:client.search(query['query'],offset=cursor,count=20))
     except Exception as e:
      # A timed-out search must not strand all already-discovered comment pages.
      # Keep its cursor and defer it, rather than repeatedly restarting that query.
      if not transient_network_error(e):raise
      put(c,'search_deferred:'+str(query['id']),time.time()+3600)
      streak=int(get(c,'search_timeout_streak',0))+1;put(c,'search_timeout_streak',streak)
      if streak>=3:put(c,'search_resume_after',time.time()+3600)
      write_json(WORK/'搜索超时断点.json',dict(time=control.now(),query=query,cursor=cursor,error=str(e),resume_after_seconds=3600,comments_continue=True))
      stats=emit('搜索暂时超时 · 延后该词，继续已发现视频评论');since_search=0;continue
     put(c,'search_timeout_streak',0)
     put(c,'last_search_category',query['category'])
     if not isinstance(p.get('data'),list):raise PlatformStop('搜索结构变化，停止解析')
     for item in p['data']:
      if isinstance(item,dict) and isinstance(item.get('aweme_info'),dict):queue_video(c,item['aweme_info'],query)
     nxt=int(p.get('cursor',cursor+20));more=bool(p.get('has_more'))
     if more and nxt<=cursor:raise PlatformStop('搜索游标未前进，停止重复读取')
     c.execute('insert or replace into search_state values(?,?,?,?)',(query['id'],nxt,pages+1,int(not more or not p['data'])))
     c.commit();since_search=0
    elif video or reply:
     is_reply=bool(reply and (not video or calls%4==3))
     if is_reply:
      cid,data=reply;task=json.loads(data);v=task['video'];parent=task['comment'];key='reply_cursor:'+cid;cursor=get(c,key,0)
      p=read('replies',cid,lambda:client.command(['replies',client.conn,cid,cursor,20,v['id']]))
     else:
      vid,data=video;v=json.loads(data);parent=None;key='cursor:'+vid;cursor=get(c,key,0)
      p=read('comments',v['id'],lambda:client.get_comments(v['id'],cursor=cursor,count=20))
     comments=p.get('comments')
     if comments is None and not p.get('has_more'):comments=[]
     if not isinstance(comments,list):raise PlatformStop('评论结构变化，停止解析')
     for item in comments:ingest_comment(c,item,v,parent)
     nxt=int(p.get('cursor',cursor+20));more=bool(p.get('has_more'))
     if more and comments and nxt<=cursor:raise PlatformStop('评论游标未前进，停止重复读取')
     exhausted=int(not more or not comments)
     c.execute('insert or replace into checkpoint values(?,?)',(key,json.dumps(nxt)))
     if is_reply:c.execute('update reply_queue set visits=visits+1,exhausted=? where cid=?',(exhausted,cid))
     else:
      c.execute('update video_queue set visits=visits+1,exhausted=? where vid=?',(exhausted,v['id']))
      if exhausted:c.execute('insert or replace into checkpoint values(?,?)',('video_done:'+v['id'],'true'))
     c.commit();since_search+=1
    else:
     emit('已读完当前可返回评论 · 实际数量不足目标，等待Codex复核',True);return
    stats=emit('持续采集评论 · 原文和楼中楼均保存')
    if sample and calls>=4:emit('评论小样验证完成 · 待启动持续采集',True);return
   emit('本轮评论采集达标 · 正在等待Codex逐条复核客户',True)
  except Exception as e:emit(str(e),True);raise
  finally:c.close()

def main():
 p=argparse.ArgumentParser();p.add_argument('--target',type=int,default=20000);p.add_argument('--sample',action='store_true');p.add_argument('--export',action='store_true');p.add_argument('--migrate',action='store_true');a=p.parse_args()
 if not 1<=a.target<=20000:raise ValueError('本轮目标为1至20000条近三个月文字评论')
 try:
  if a.export or a.migrate:
   c=db();setup(c);queries=json.loads((OUT/'采集计划.json').read_text('utf-8'))['queries'];migrate(c,queries)
   progress(c,'评论口径已修正 · 准备持续采集',a.target,True);c.close();return 0
  run(a.target,a.sample);return 0
 except AlreadyRunning as e:print(str(e),flush=True);return 2
 except Exception as e:
  c=db();setup(c);progress(c,str(e),a.target,True);c.close()
  print(str(e),flush=True);return 1

if __name__=='__main__':raise SystemExit(main())
