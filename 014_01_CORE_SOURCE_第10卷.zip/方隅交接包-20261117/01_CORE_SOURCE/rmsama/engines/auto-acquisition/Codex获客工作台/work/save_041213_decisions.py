import json
from pathlib import Path
# 当前Codex全文读取15条；逐条结论明确写下，脚本仅保存。
rows=[
(1,'回应中介利润讨论，建议对方搭平台，无本人开发采购需求，不把对方诉求转归。'),
(2,'陈建领复述项链种草并致谢，无本人产品或视频委托说明。'),
(3,'西西子只留项链种草关键词，无本人需求。'),
(4,'Cobra只留项链种草，无本人产品与委托。'),
(5,'竹竹枝枝仅项链种草关键词，未提出采购。'),
(6,'灵说仅种草二字，无本人制作需求。'),
(7,'一块菠萝仅项链种草，未说明本人需求。'),
(8,'纯银专柜店只留项链种草，不从店铺昵称补商家视频采购。'),
(9,'胡OK仅项链种草关键词，无本人委托。'),
(10,'该用户只发项链种草，无本人具体需求。'),
(11,'小柒只留项链种草，无服务采购表达。'),
(12,'Augenstern仅项链种草，无本人视频需求。'),
(13,'该作者仅复述项链种草，未表明本人业务与委托。'),
(14,'叶青儿只留项链种草，无本人服务需求。'),
(15,'Gym茜仅项链种草，无本人产品、视频规格或委托，不从教程宣传转归需求。')]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
(Path(__file__).parent/'review-batches/20261011_041213_120429_decisions.json').write_text(json.dumps({'reviewer':'Codex','decisions':d},ensure_ascii=False,indent=2),'utf-8')
