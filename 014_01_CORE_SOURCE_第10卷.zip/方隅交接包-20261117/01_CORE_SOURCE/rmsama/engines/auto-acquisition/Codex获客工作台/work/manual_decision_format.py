import json
from pathlib import Path
class Decisions:
 def __init__(self): self.d={}
 def put(self,ids,v,s,t,r,e=''):
  for i in ids:
   assert i not in self.d,i
   self.d[i]=dict(index=i,verdict=v,score=s,demand_type=t,reason=r,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='')
 def E(self,ids,r):self.put(ids,'排除',0,'需求未明确',r)
 def P(self,ids,s,t,r):self.put(ids,'待确认',s,t,r)
 def H(self,i,s,t,r,e):self.put([i],'高意向',s,t,r,e)
 def save(self,stem,count=200):
  assert set(self.d)==set(range(1,count+1)),sorted(set(range(1,count+1))-set(self.d))
  p=Path('work/review-batches/'+stem+'_fullpass_decisions.json')
  p.write_text(json.dumps({'reviewer':'Codex','decisions':[self.d[i] for i in sorted(self.d)]},ensure_ascii=False,indent=2),'utf-8');print(str(p),len(self.d))
