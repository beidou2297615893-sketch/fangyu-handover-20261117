import json
from datetime import datetime
from pathlib import Path
from launch_comments import active
from launch_excel_export import locked

root=Path(__file__).resolve().parent.parent
work=root/'work'
out=root/'outputs'
a=json.loads((out/'Codex分析进度.json').read_text('utf-8'))
p=json.loads((work/'评论任务进度.json').read_text('utf-8'))
r=json.loads((out/'Codex待确认复审进度.json').read_text('utf-8'))
x=json.loads((work/'Excel导出任务.json').read_text('utf-8'))
report=dict(time=datetime.now().astimezone().isoformat(),automation_id='automation-13',collector_running=active(),collector=p,analysis={k:a[k] for k in ['updated','last_review','reviewed','pending','high','warm','excluded']},baseline=dict(collected=14300,recent=13911,reviewed=13996,high=322),reviewed_this_heartbeat=a['reviewed']-13996,new_high_this_heartbeat=a['high']-322,historical_recheck=r,excel_running=locked(),excel_task=x,previous_excel_structure_audit='outputs/本轮增量复核验收.json',previous_excel_audit_errors=[],excel_current_export_requires_completion_and_native_audit=True,stop_marker_exists=(work/'STOP').exists(),browser_actions_this_heartbeat=False,review_method='当前Codex完整show逐条读取77条，显式结论提交；保存脚本无判定或模型调用')
(work/'心跳巡检.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(work/'心跳巡检_20261011_0330.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
