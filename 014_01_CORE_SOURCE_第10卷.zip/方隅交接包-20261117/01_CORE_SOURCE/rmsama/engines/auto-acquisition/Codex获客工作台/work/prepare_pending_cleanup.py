"""Prepare immutable existing pending rows for manual Codex reconsideration.
No classifier or platform/model requests.
"""
import argparse, datetime, json
from codex_review import WORK, OUT, METHOD, digest, effective_reviews, ledger, source, write

def status():
    p=WORK/'待确认口径复审队列_20261012.json'
    if not p.exists(): return
    m=json.loads(p.read_text('utf-8'))
    with ledger() as l:
        done=[json.loads(d) for d, in l.execute('select data from review_fullpasses where pass_id=?',(m['pass_id'],))]
    result=dict(updated=datetime.datetime.now().astimezone().isoformat(),pass_id=m['pass_id'],total=len(m['ids']),completed=len(done),pending=len(m['ids'])-len(done),high=sum(d['verdict']=='高意向' for d in done),warm=sum(d['verdict']=='待确认' for d in done),excluded=sum(d['verdict']=='排除' for d in done),method=METHOD,collection_paused=True)
    write(OUT/'待确认口径复审进度_20261012.json',result)
    return result

def prepare(limit):
    p=WORK/'待确认口径复审队列_20261012.json'
    with source() as c,ledger() as l:
        previous={d['id']:d for d in effective_reviews(l)}
        records={i:json.loads(d) for i,d in c.execute("select id,data from records where id like 'comment:%' order by rowid")}
        if p.exists():m=json.loads(p.read_text('utf-8'))
        else:
            ids=[i for i in records if previous[i]['verdict']=='待确认']
            baseline={table:list(l.execute('select id,data from '+table+' order by id')) for table in ('reviews','review_rechecks')}
            base_full=[list(r) for r in l.execute("select id,data from review_fullpasses where pass_id='20261012_all_comments' order by id")]
            m=dict(pass_id='20261012_pending_cleanup',created_at=datetime.datetime.now().astimezone().isoformat(),authorization='用户质疑待确认过宽，重新逐条区分真实采购缺口、索资料、自学和互动，并更新Excel',ids=ids,source_hashes={i:digest(records[i]) for i in ids},baseline=baseline,base_fullpass_hash=digest(base_full))
            write(p,m)
        done={i for i, in l.execute('select id from review_fullpasses where pass_id=?',(m['pass_id'],))}
        comments=[]
        for ident in m['ids']:
            if ident in done:continue
            r=records[ident]
            assert digest(r)==m['source_hashes'][ident]
            vid=r['source_url'].rsplit('/',1)[-1]
            v=c.execute('select data from video_queue where vid=?',(vid,)).fetchone()
            context=json.loads(v[0]).get('text','') if v else r.get('parent_text','')
            comments.append(dict(index=len(comments)+1,record=r,video_context=context,source_hash=digest(r),previous_review=previous[ident]))
            if len(comments)>=limit:break
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    dest=WORK/'review-batches'/(stamp+'_fullpass.json')
    write(dest,dict(created_at=datetime.datetime.now().astimezone().isoformat(),kind='fullpass',pass_id=m['pass_id'],method=METHOD,comments=comments))
    print(json.dumps(dict(batch=str(dest),count=len(comments),progress=status()),ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=200);p.add_argument('--status',action='store_true');a=p.parse_args()
    if a.status:print(json.dumps(status(),ensure_ascii=False))
    else:prepare(min(200,max(1,a.limit)))
