"""Keep one local XLSX export alive if a Codex launcher turn is interrupted."""
import json, msvcrt, os, subprocess, sys
from datetime import datetime
from pathlib import Path
from windows_independent import start_script
ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'work'
LOCK=WORK/'excel_export.lock'
def locked():
    if not LOCK.exists(): return False
    with LOCK.open('r+b') as f:
        try:
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:return True
        msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
        return False
def write(value):
    value['updated']=datetime.now().astimezone().isoformat()
    (WORK/'Excel导出任务.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def main():
    if '--worker' in sys.argv:
        with LOCK.open('a+b') as lock:
            lock.seek(0)
            if lock.read(1)==b'':lock.write(b'1');lock.flush()
            lock.seek(0)
            try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
            except OSError:return
            task={'pid':os.getpid(),'running':True,'scope':str(ROOT),'models_called':False}
            write(task)
            r=subprocess.run([sys.executable,'-X','utf8',str(WORK/'export_customer_excel.py')],cwd=ROOT)
            task.update(running=False,exit_code=r.returncode,completed=r.returncode==0)
            if r.returncode==0:
                task['snapshot']=json.loads((ROOT/'outputs/Excel导出进度.json').read_text('utf-8'))
            write(task)
            lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
            if r.returncode:sys.exit(r.returncode)
    elif '--status' in sys.argv:
        task=json.loads((WORK/'Excel导出任务.json').read_text('utf-8')) if (WORK/'Excel导出任务.json').exists() else {}
        print(json.dumps({'running':locked(),'task':task},ensure_ascii=False))
    elif locked():
        print('本地Excel导出已在运行，未重复启动')
    else:
        pid=start_script(__file__,['--worker'],WORK/'Excel持续导出.stdout.log',WORK/'Excel持续导出.stderr.log')
        print(json.dumps({'started_pid':pid,'scope':str(ROOT),'launch_method':'Win32_Process.Create'},ensure_ascii=False))

if __name__=='__main__':main()
