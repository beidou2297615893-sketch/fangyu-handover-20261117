import json
from pathlib import Path
# 当前Codex逐条全文阅读后的结论；仅保存，无规则分类器。
rows=[
 (1,'仅懵表情，无本人需求。'),
 (2,'希望上线后获提醒，属于等待现有求职产品发布，无本人小程序开发、采购或自动化委托。'),
 (3,'仅蹲发布的互动，无本人相关服务需求。'),
 (4,'蹲发布并鼓掌，未提出本人开发需求。'),
 (5,'问产品是否上线，没有本人小程序开发委托。'),
 (6,'仅感谢，无本人需求。'),
 (7,'仅贴贴表情互动，无本人需求。'),
 (8,'等待视频求职小程序上线，不是要求为本人开发小程序。'),
 (9,'等待发布的互动，无本人服务需求。'),
 (10,'表示等待视频更新或发布，无本人开发采购。'),
 (11,'蹲更新表情互动，未提出本人服务需求。'),
 (12,'蹲住发布互动，无本人需求。'),
 (13,'明确想换工作，是求职者需求，非采购软件开发或业务自动化服务。'),
 (14,'等待发布并加油，纯互动，没有本人开发需求。'),
 (15,'蹲发布加表情，无本人相关服务需求。'),
 (16,'仅加油互动，无本人需求。'),
 (17,'仅蹲顿互动，无本人需求。'),
 (18,'仅蹲发布，无本人服务需求。'),
 (19,'仅蹲蹲互动，无本人需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
p=Path(__file__).parent/'review-batches/20261011_033710_571498_decisions.json'
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(len(d))
