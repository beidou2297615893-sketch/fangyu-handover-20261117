import ast,json
from pathlib import Path
import comment_job as j
positive=['[getComments] 网络请求失败: Failed to fetch','fetch failed','ECONNRESET','Timed out','超时']
negative=['平台要求验证码','平台返回错误或限制','登录失效','评论结构变化','permission denied']
assert all(j.transient_network_error(x) for x in positive)
assert not any(j.transient_network_error(x) for x in negative)
tree=ast.parse(Path(j.__file__).read_text('utf-8'))
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='transient_network_error']
assert len(calls)==2
src=Path(j.__file__).read_text('utf-8')
assert 'for attempt in range(3)' in src and 'attempt<2' in src
assert 'random.uniform(30,50)' in src and "search_deferred:" in src
result=dict(network_cases=positive,restrictions_not_retried=negative,shared_classifier_calls=2,max_attempts=3,pace_seconds=[30,50],platform_reads_in_test=0)
(Path(j.WORK)/'网络错误重试验收_20261011_0404.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(result,ensure_ascii=False))
