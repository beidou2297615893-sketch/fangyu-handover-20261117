import json
from pathlib import Path
rows=[
 (1,'仅提数字人名称，未表达委托、购买或具体用途。'),
 (2,'仅回复数字人，属于主题兴趣，采购目的不明。'),
 (3,'只写数字人，未提出本人服务需求。'),
 (4,'只提数字人，无具体购买或制作任务。'),
 (5,'仅数字人短词，兴趣不能当采购意向。'),
 (6,'仅提数字人，未说明用途和服务委托。'),
 (7,'只写数字人，不能从昵称推断本人业务采购。'),
 (8,'只提数字人，无具体本人任务。'),
 (9,'只写数字人，厂家昵称不能当视频采购需求。'),
 (10,'仅主题短词数字人，购买目的未知。'),
 (11,'仅数字人名称，无委托或方案寻找。'),
 (12,'仅提数字人，未表达本人任务。'),
 (13,'仅数字人短词，学堂昵称不能推断具体采购场景。'),
 (14,'只写数字人，未表明购买或委托。'),
 (15,'仅主题兴趣数字人，未说明服务需求。'),
 (16,'仅提数字人，需求强度未知。'),
 (17,'仅数字人短词，无本人具体用途或采购。'),
]
d={'reviewer':'Codex','decisions':[dict(index=i,verdict='待确认',score=20,reason=r,demand_type='数字人与视频',demand_evidence='数字人',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]}
Path('work/review-batches/20261011_010520_135113_decisions.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
