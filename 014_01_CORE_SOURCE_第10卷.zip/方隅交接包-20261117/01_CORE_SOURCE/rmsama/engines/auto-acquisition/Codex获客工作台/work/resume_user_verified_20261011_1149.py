import json, sqlite3, time
from pathlib import Path
from datetime import datetime
from launch_comments import active

root=Path(__file__).resolve().parent.parent
work=root/'work'
assert not active(), '唯一采集锁仍占用'
stop=work/'STOP'
s=json.loads(stop.read_text('utf-8'))
assert s['origin']=='platform_verification_required' and s['created_by']=='Codex'
assert s['created_at']=='2026-10-11T05:41:13.509978+08:00'
assert s['captcha_reference']=='202610110535314F46C36833FDD9C67CBC'
raw=json.loads((work/'用户验证恢复读回_20261011_1149.json').read_text('utf-8'))
assert raw['status_code']==0 and len(raw['comments'])==20
assert [x['text'] for x in raw['comments'][:5]]==['比福客便宜吗？','售后呢','怎么收费 可以试用？','可以付费，怎么联系怎么用','怎么试用']
conn=sqlite3.connect(work/'campaign.sqlite3')
conn.execute('insert or replace into checkpoint values(?,?)',('last_read',json.dumps(time.time())))
conn.commit(); conn.close()
archive=work/'STOP_验证码_20261011_0541_用户验证解除_1149.json'
assert not archive.exists(); stop.rename(archive)
pause=work/'平台验证暂停.json'
p=json.loads(pause.read_text('utf-8'))
assert p['origin']==s['origin'] and p['created_at']==s['created_at']
p.update(platform_reads_paused=False,captcha_still_present=False,resolved_at=datetime.now().astimezone().isoformat(),resolved_by='用户本窗口明确已亲自验证并要求继续；Codex截图及本人账号、19422实时注册、20条评论原文逐项核验',resolved_evidence='outputs/用户验证后原页_20261011_1148.png')
archived_pause=work/'平台验证暂停_20261011_0541_已解除_1149.json'
assert not archived_pause.exists()
archived_pause.write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
pause.unlink()
e={'checked_at':datetime.now().astimezone().isoformat(),'user_resume_authorized':True,'page_screenshot':'outputs/用户验证后原页_20261011_1148.png','connection_id':s['connection_id'],'url':s['url'],'sdk_last_activity':'2026-10-11T03:48:43.508Z','readback':'work/用户验证恢复读回_20261011_1149.json','readback_count':20,'ui_first_five_matched':True,'collected_baseline':16083,'recent_baseline':15655,'new_collection_verified':False,'new_rule':'验证码出现后暂停worker与automation-13，不周期检查，等用户明确验证并继续'}
(work/'用户验证续跑核验_20261011_1149.json').write_text(json.dumps(e,ensure_ascii=False,indent=2),encoding='utf-8')
print('仅本次Codex平台STOP已归档，恢复读回间隔已写入，等待启动及真实新增核验')
