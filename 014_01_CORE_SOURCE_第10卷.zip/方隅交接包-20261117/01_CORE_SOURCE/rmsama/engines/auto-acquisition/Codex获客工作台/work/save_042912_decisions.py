import json
from pathlib import Path
rows=[
(1,'排除',0,'接单群求拉回复1，纯互动，无本人软件采购。','需求未明确',''),
(2,'排除',0,'请求加入AI接单群，属接单资源需求，未表达买家服务需求。','需求未明确',''),
(3,'待确认',45,'想要视频中CRM工具，存在工具兴趣，但教程分享语境下未说明使用任务或采购方式，保留待确认。','获客系统与CRM','想要！！'),
(4,'排除',0,'仅求教程资源分享，无本人业务需求。','需求未明确',''),
(5,'待确认',55,'need it指向CRM工具，表达需要或想要，但具体本人业务、获取方式和是否找服务仍未明；不凭昵称出海补需求。','获客系统与CRM','need it[碰拳]'),
(6,'待确认',20,'询是否Notion，属于工具识别兴趣，没有本人项目或采购。','获客系统与CRM','notion？'),
(7,'排除',0,'仅索要代码仓库，无本人服务委托。','需求未明确',''),
(8,'排除',0,'仅求分享并感谢，无具体本人需求。','需求未明确',''),
(9,'排除',0,'仅求分享资源，无本人业务。','需求未明确',''),
(10,'排除',0,'索要提示词用于教程学习，无本人任务，不发送任何内容。','需求未明确',''),
(11,'排除',0,'Please share只请求分享资源，无本人采购。','需求未明确',''),
(12,'排除',0,'pls share仅求分享，无本人需求。','需求未明确',''),
(13,'排除',0,'只求分享，无本人服务目标。','需求未明确',''),
(14,'排除',0,'求分享并感谢，无具体本人项目。','需求未明确',''),
(15,'排除',0,'仅求分享资源，无采购需求。','需求未明确',''),
(16,'排除',0,'仅求分享并感谢，无本人服务需求。','需求未明确',''),
(17,'排除',0,'只求分享，无本人采购。','需求未明确',''),
(18,'排除',0,'求分享并感谢，无本人具体需求。','需求未明确',''),
(19,'排除',0,'仅求分享资源，无本人业务。','需求未明确',''),
(20,'待确认',60,'本人博士研究已用3个LLM工具，希望集中LLM知识库并学习Obsidian结构，实际为自学知识工作流；没有委托开发或购买服务，不能按视频CRM主题强定CRM，也没有费用证据。','AI自动化','Have been using 3 LLM tools for my doctoral research and getting to the point where it makes sense to have a centralised LLLM wiki.'),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,21))
p=Path('work/review-batches/20261011_042912_294356_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
