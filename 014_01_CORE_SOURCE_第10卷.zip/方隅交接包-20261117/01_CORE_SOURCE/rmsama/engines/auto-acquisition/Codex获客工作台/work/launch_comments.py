"""Start one hidden comment worker, or report its mutex-based running state."""
import argparse,json,msvcrt,os,subprocess,sys
from windows_independent import start_script
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'work'

def active():
 p=WORK/'collector.lock'
 if not p.exists():return False
 with p.open('r+b') as f:
  f.seek(0)
  try:msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
  except OSError:return True
  msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1);return False

def main():
 p=argparse.ArgumentParser();p.add_argument('--status',action='store_true');p.add_argument('--target',type=int,default=20000);a=p.parse_args()
 running=active()
 if a.status:
  result={'running':running}
  for name,key in [('采集任务.json','job'),('评论任务进度.json','progress')]:
   path=WORK/name
   if path.exists():result[key]=json.loads(path.read_text('utf-8-sig'))
  print(json.dumps(result,ensure_ascii=False));return
 if running:print('评论任务已在运行，未重复启动');return
 if (WORK/'STOP').exists():raise RuntimeError('停止标记仍在，先由Codex核实是否可以恢复')
 if not 1<=a.target<=20000:raise ValueError('目标须为1至20000条评论')
 worker_pid=start_script(WORK/'comment_job.py',['--target',str(a.target)],WORK/'持续评论.stdout.log',WORK/'持续评论.stderr.log')
 print(json.dumps({'started_pid':worker_pid,'target_comments':a.target,'launch_method':'Win32_Process.Create'},ensure_ascii=False))

if __name__=='__main__':main()
