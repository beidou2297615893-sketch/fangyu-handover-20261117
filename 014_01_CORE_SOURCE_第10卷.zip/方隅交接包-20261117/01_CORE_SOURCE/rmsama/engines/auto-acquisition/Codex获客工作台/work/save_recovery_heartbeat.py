import json, socket, subprocess
from datetime import datetime
from pathlib import Path
from launch_comments import active
from launch_excel_export import locked
ROOT=Path(__file__).resolve().parent.parent
WORK, OUT=ROOT/'work',ROOT/'outputs'
def read(p):return json.loads(p.read_text('utf-8'))
def listening(port):
    with socket.socket() as s:return s.connect_ex(('127.0.0.1',port))==0
progress=read(WORK/'评论任务进度.json')
analysis=read(OUT/'Codex分析进度.json')
history=read(OUT/'Codex待确认复审进度.json')
last_raw=[]
for p in sorted((WORK/'raw-campaign').glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:5]:
    d=read(p);last_raw.append({'file':str(p),'status_code':d.get('status_code'),'comments':len(d.get('comments') or []),'reply':len(d.get('reply_comment') or [])})
result={'checked_at':datetime.now().astimezone().isoformat(),'collector_running':active(),
        'worker_pid':progress['pid'],'collected':progress['stats']['collected'],'recent':progress['stats']['recent'],
        'new_collected_after_recovery':progress['stats']['collected']-13952,
        'reviewed_total':analysis['reviewed'],'reviewed_this_continuous_run':analysis['reviewed']-13387,
        'new_review_pending':analysis['pending'],'high_independent':analysis['high'],'new_high_independent':analysis['high']-301,
        'historical_recheck_completed':history['completed'],'historical_recheck_pending':history['pending'],
        'bridge_service_running':listening(19422),'workbench_service_running':listening(19747),
        'binding':read(WORK/'抖音连接绑定.json'),'background_lifetime_test':read(WORK/'job_lifetime_test_result.json'),
        'last_raw_responses':last_raw,'goal_complete':False,'platform_block':None,
        'platform_requests_this_check':0,'recovery_readback_count':20,
        'excel_export_running':locked(),'excel_last_completed_snapshot':read(OUT/'Excel导出进度.json'),
        'excel_verified_snapshot':read(OUT/'本轮增量复核验收.json').get('excel_snapshot'),
        'workbench_visual_verified':False,
        'workbench_visual_limit':'此前错误页标记被浏览器安全检查拒绝，错误页协议不支持；未通过替代浏览器绕过。本人本地API及XLSX核验通过。',
        'old_collector_tab_control_unavailable':'896061667','analysis_priority':'当前Codex连续逐条分析；后台唯一worker串行30—50秒；心跳仅后备唤醒'}
for name in ['心跳巡检.json','后台寿命修复续跑核验_20261011.json']:
    (WORK/name).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k in ['collector_running','collected','recent','new_collected_after_recovery','reviewed_total','reviewed_this_continuous_run','new_review_pending','high_independent','new_high_independent','excel_export_running']},ensure_ascii=False))
