import json
from pathlib import Path

# 当前Codex完整读取18条后逐项作出的结论；这里只保存字段，不判断评论。
rows = [
 (1, '排除', 0, '仅烟花和比心表情互动，无本人需求。'),
 (2, '排除', 0, '仅点赞和玫瑰表情互动，无本人采购。'),
 (3, '排除', 0, '晚上好是问候，没有相关服务需求。'),
 (4, '排除', 0, '仅点赞表情，无本人需求。'),
 (5, '排除', 0, '认可讲解内容，没有提出自己要找的工具或服务。'),
 (6, '排除', 0, '加油及点赞表情互动，无本人采购需求。'),
 (7, '排除', 0, '感恩遇见是社交感谢，无本人需求。'),
 (8, '排除', 0, '科技引领的口号赞扬，没有本人具体服务诉求。'),
 (9, '排除', 0, '仅赞扬做得好，没有方案寻找或委托。'),
 (10, '排除', 0, '赞扬软件厉害，未说自己需要使用或采购什么功能。'),
 (11, '排除', 0, '仅点赞鼓掌玫瑰表情，无本人需求。'),
 (12, '排除', 0, '太美是评价，没有相关采购需求。'),
 (13, '排除', 0, '表情互动，没有工具或服务需求。'),
 (14, '排除', 0, '单个发怒表情，不能证明本人需求。'),
 (15, '排除', 0, '评论科技发展趋势，没有提出本人采购或方案需求。'),
 (16, '排除', 0, '围绕老板及马云对接的模糊叙述，没有本人具体工具、获客服务或委托需求，不能用视频AI对接主题补出采购。'),
 (17, '排除', 0, '赞扬主播讲得好，无本人需求。'),
 (18, '排除', 0, '感谢及赞叹表情互动，无本人服务需求。'),
]
decisions = [dict(index=i, verdict=v, score=s, reason=r, demand_type='需求未明确', demand_evidence='', budget_evidence='', payment_evidence='', urgent_evidence='') for i,v,s,r in rows]
p = Path(__file__).parent / 'review-batches/20261011_033321_455894_decisions.json'
p.write_text(json.dumps(dict(reviewer='Codex', decisions=decisions), ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(saved=len(decisions), path=str(p)), ensure_ascii=False))
