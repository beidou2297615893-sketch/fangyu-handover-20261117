import json
from pathlib import Path
rows=[
 (1,'扣1回应作者看完整教程的引导，无本人看板委托。'),
 (2,'单个1属于教程投票互动，无本人采购需求。'),
 (3,'扣1希望看后续教程，无本人具体项目。'),
 (4,'只扣1回应视频引导，无服务需求。'),
 (5,'教程互动，不从昵称中的工作描述推断采购。'),
 (6,'单个1为教程互动，无本人需求。'),
 (7,'连续1表达希望看完整教程，未要求开发或购买。'),
 (8,'只扣1互动，无本人服务需求。'),
 (9,'扣1回应作者后续教程引导，无委托表达。'),
 (10,'单个1为教程互动，无采购或具体方案需求。'),
 (11,'只扣1互动，没有本人项目。'),
 (12,'1需要结合作者扣1看四个Tab的引导指向希望看教程，不足以认定需要代建数据看板。'),
 (13,'单个1为教程互动，不能把作者团队需求转归评论者。'),
 (14,'扣1为教程互动，无本人委托。'),
 (15,'单个1互动，无本人具体需求。'),
 (16,'扣1观看后续教程的互动，无采购证据。')
]
ds=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [x['index'] for x in ds]==list(range(1,17))
p=Path(__file__).parent/'review-batches/20261011_115049_659908_decisions.json'
p.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(p)
