import json
from pathlib import Path
rows=[
(1,'对企微涨价作一般评论，无本人采购需求。'),
(2,'作者对观点的回应，无本人采购需求。'),
(3,'询平台涨价通知查看位置，无第三方软件服务需求。'),
(4,'作者说明后台通知位置，供应方答复非买家。'),
(5,'明确抱怨并表示不向企微导入客户，未寻找软件方案或委托，不能推定采购。'),
(6,'作者评价平台生态，无本人采购需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,7))
p=Path('work/review-batches/20261011_045907_253470_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
