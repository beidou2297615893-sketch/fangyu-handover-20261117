import json
from pathlib import Path
rows=[
(1,'排除',0,'仅表情称赞，无本人服务需求。','需求未明确',''),
(2,'排除',0,'仅表情称赞，无本人服务需求。','需求未明确',''),
(3,'排除',0,'评价视频画面运动，无小程序采购需求。','需求未明确',''),
(4,'排除',0,'仅表情互动，无本人服务需求。','需求未明确',''),
(5,'待确认',60,'表达想做小程序同时觉得价格高，但本人业务功能和是否继续采购未明，未给预算。','微信小程序','想整一个，没想这么贵'),
(6,'待确认',25,'询小程序域名技术原因，偏使用或学习兴趣，无开发委托。','微信小程序','微信小程序为什么要域名'),
(7,'排除',0,'仅表情互动，无本人需求。','需求未明确',''),
(8,'排除',0,'无意义字母互动，无本人需求。','需求未明确',''),
(9,'排除',0,'讨论平台认证费，300是统一收费认知而非本人采购预算，无服务需求。','需求未明确',''),
(10,'排除',0,'自述同业做开发并评价套路，供应商而非买家。','需求未明确',''),
(11,'排除',0,'家电炊具总代供货广告，非本次软件需求买家。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,12))
p=Path('work/review-batches/20261011_050108_623675_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
