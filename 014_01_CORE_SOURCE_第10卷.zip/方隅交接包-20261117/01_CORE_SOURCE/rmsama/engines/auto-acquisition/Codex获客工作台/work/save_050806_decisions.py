import json
from pathlib import Path
rows=[
(1,'排除',0,'仅写求，索取对象及本人需求不明，无采购证据。','需求未明确',''),
(2,'待确认',25,'请求数字人自动视频教程，属于自学兴趣，无服务委托。','数字人与视频','求教程'),
(3,'排除',0,'点赞鼓励互动，无本人服务需求。','需求未明确',''),
(4,'排除',0,'称赞外观，无数字人制作需求。','需求未明确',''),
(5,'待确认',25,'询数字人自动视频方法，偏学习兴趣，无采购或委托。','数字人与视频','求方法'),
(6,'排除',0,'仅提及他人，无本人需求。','需求未明确',''),
(7,'待确认',40,'询数字人视频生成费用，无具体项目或本人预算。','数字人与视频','花多少钱'),
(8,'排除',0,'回答他人的费用问题，几毛是费用估计而非本人采购预算。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,9))
p=Path('work/review-batches/20261011_050806_427518_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
