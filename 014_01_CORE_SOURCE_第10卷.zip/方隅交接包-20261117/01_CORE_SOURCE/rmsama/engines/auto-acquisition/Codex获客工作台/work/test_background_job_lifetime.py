"""Check only this test's child processes against an owned launcher job ending."""
import ctypes as ct
from ctypes import wintypes as wt
import json, os, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT/'work'
PREFIX = WORK/'job_lifetime_test'
def file(s): return Path(str(PREFIX)+s)
if len(sys.argv)>1 and sys.argv[1]=='--heartbeat':
    while True:
        file('_'+sys.argv[2]+'.json').write_text(json.dumps({'pid':os.getpid(),'time':time.time()}),encoding='utf-8')
        time.sleep(0.2)
if len(sys.argv)>1 and sys.argv[1]=='--launcher':
    deadline=time.monotonic()+10
    while not file('_gate').exists():
        if time.monotonic()>deadline: raise TimeoutError('test gate')
        time.sleep(.05)
    children={}
    for name,flags in [('ordinary',subprocess.CREATE_NO_WINDOW),('independent',subprocess.CREATE_NO_WINDOW|subprocess.CREATE_BREAKAWAY_FROM_JOB)]:
        p=subprocess.Popen([sys.executable,__file__,'--heartbeat',name],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=flags)
        children[name]=p.pid
    file('_pids.json').write_text(json.dumps(children),encoding='utf-8')
    time.sleep(20)
    sys.exit(0)

class Basic(ct.Structure):
    _fields_=[('ProcessTime',ct.c_longlong),('JobTime',ct.c_longlong),('Flags',wt.DWORD),
              ('MinWorking',ct.c_size_t),('MaxWorking',ct.c_size_t),('ActiveLimit',wt.DWORD),
              ('Affinity',ct.c_size_t),('Priority',wt.DWORD),('Scheduling',wt.DWORD)]
class IO(ct.Structure):
    _fields_=[(n,ct.c_ulonglong) for n in ['ReadOps','WriteOps','OtherOps','ReadBytes','WriteBytes','OtherBytes']]
class Extended(ct.Structure):
    _fields_=[('Basic',Basic),('IO',IO),('ProcessMemory',ct.c_size_t),('JobMemory',ct.c_size_t),
              ('PeakProcessMemory',ct.c_size_t),('PeakJobMemory',ct.c_size_t)]
k=ct.WinDLL('kernel32',use_last_error=True)
k.CreateJobObjectW.argtypes=[ct.c_void_p,wt.LPCWSTR];k.CreateJobObjectW.restype=wt.HANDLE
k.SetInformationJobObject.argtypes=[wt.HANDLE,ct.c_int,ct.c_void_p,wt.DWORD]
k.AssignProcessToJobObject.argtypes=[wt.HANDLE,wt.HANDLE]
k.CloseHandle.argtypes=[wt.HANDLE]
k.OpenProcess.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD];k.OpenProcess.restype=wt.HANDLE
k.GetExitCodeProcess.argtypes=[wt.HANDLE,ct.POINTER(wt.DWORD)]
k.TerminateProcess.argtypes=[wt.HANDLE,wt.UINT]
def checked(ok):
    if not ok: raise ct.WinError(ct.get_last_error())
def alive(pid):
    h=k.OpenProcess(0x1000,False,pid)
    if not h:return False
    code=wt.DWORD();checked(k.GetExitCodeProcess(h,ct.byref(code)));k.CloseHandle(h)
    return code.value==259
# The job is created solely for this probe, never assigned existing application processes.
assert not file('_gate').exists() and not file('_pids.json').exists()
job=k.CreateJobObjectW(None,None);checked(job)
limits=Extended();limits.Basic.Flags=0x2000|0x800 # KILL_ON_JOB_CLOSE | BREAKAWAY_OK
checked(k.SetInformationJobObject(job,9,ct.byref(limits),ct.sizeof(limits)))
p=subprocess.Popen([sys.executable,__file__,'--launcher'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
checked(k.AssignProcessToJobObject(job,int(p._handle)))
file('_gate').write_text('ready',encoding='utf-8')
deadline=time.monotonic()+10
while not file('_pids.json').exists():
    if time.monotonic()>deadline:raise TimeoutError('test launch')
    time.sleep(.05)
children=json.loads(file('_pids.json').read_text('utf-8'))
time.sleep(.5)
before={name:alive(pid) for name,pid in children.items()}
checked(k.CloseHandle(job));time.sleep(.5)
after={name:alive(pid) for name,pid in children.items()}
result={'tested_at':time.time(),'before_launcher_job_end':before,'after_launcher_job_end':after,
        'passed':all(before.values()) and not after['ordinary'] and after['independent']}
file('_result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
h=k.OpenProcess(0x0001,False,children['independent'])
if h:checked(k.TerminateProcess(h,0));k.CloseHandle(h)
print(json.dumps(result))
assert result['passed']
