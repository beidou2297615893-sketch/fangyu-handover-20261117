import json
from pathlib import Path
rows=[
 (1,'排除',0,'泛问荧光计划合作，没有本人软件采购或具体功能需求。','需求未明确',''),
 (2,'待确认',20,'泛问操作方法，属于项目兴趣，未明确发布工具采购或委托。','需求未明确','怎么做'),
 (3,'待确认',35,'只询收费，发布工具主题可解释对象但收费范围及采购未明确，无本人金额预算。','多平台发布','怎么收费'),
 (4,'排除',0,'只问合作方式，不足以证明本人软件买方需求。','需求未明确',''),
 (5,'排除',0,'只有什么情况的互动询问，没有具体需求。','需求未明确','')]
decisions=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
out=Path(__file__).parent/'review-batches/20261011_051222_720906_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
