import json, subprocess, sys, time
from datetime import datetime
from pathlib import Path
from campaign_collect import db, put
ROOT = Path(__file__).resolve().parent.parent
conn = sys.argv[1]
node = ROOT.parent / 'work/runtime/douyin-bridge/node.exe'
stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
raw = ROOT / f'work/恢复评论读回_{stamp}.json'
r = subprocess.run([str(node), str(ROOT/'work/douyin_read.cjs'), 'comments', conn,
                    '7676806387175598451', '0', '20'], capture_output=True, text=True,
                   encoding='utf-8', timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
raw.write_text(r.stdout, encoding='utf-8')
with db() as c:
    put(c, 'last_read', time.time())
if r.returncode:
    raise RuntimeError(r.stderr)
p = json.loads(r.stdout)
assert p['status_code'] == 0 and len(p['comments']) > 0
print(json.dumps({'raw':str(raw), 'count':len(p['comments']), 'status_code':p['status_code'],
                  'first_five':[{'cid':x['cid'],'text':x['text']} for x in p['comments'][:5]]}, ensure_ascii=False))
