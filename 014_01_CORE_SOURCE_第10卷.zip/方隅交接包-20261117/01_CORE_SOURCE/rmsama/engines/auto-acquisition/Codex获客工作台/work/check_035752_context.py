import json,sqlite3
from pathlib import Path
root=Path(__file__).resolve().parent
b=json.loads((root/'review-batches/20261011_035752_365998.json').read_text('utf-8'))
src=sqlite3.connect((root/'campaign.sqlite3').as_uri()+'?mode=ro',uri=True)
led=sqlite3.connect((root/'codex_reviews.sqlite3').as_uri()+'?mode=ro',uri=True)
for n in (2,20):
 x=b['comments'][n-1]['record']; uid=x['user_id']
 print(json.dumps({'index':n,'current':x},ensure_ascii=False))
 for data, in src.execute('select data from records where json_extract(data,?)=?',('$.user_id',uid)):
  r=json.loads(data)
  print(json.dumps({'same_uid_record':{k:r.get(k) for k in ('id','user_id','text','parent_text','published_at','source_url')}},ensure_ascii=False))
  for table in ('reviews','review_rechecks'):
   row=led.execute('select data from '+table+' where id=?',(r['id'],)).fetchone()
   if row:
    d=json.loads(row[0]); print(json.dumps({'table':table,'review':{k:d.get(k) for k in ('id','verdict','score','reason','demand_evidence','demand_type')}},ensure_ascii=False))
