import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROOF = ROOT / 'work' / 'background_lifetime_probe.json'
if '--child' in sys.argv:
    for i in range(20):
        PROOF.write_text(json.dumps({'pid': os.getpid(), 'tick': i, 'time': time.time()}), encoding='utf-8')
        time.sleep(2)
else:
    flags = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_BREAKAWAY_FROM_JOB
    child = subprocess.Popen([sys.executable, '-X', 'utf8', __file__, '--child'], cwd=ROOT,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=flags)
    print(json.dumps({'pid': child.pid, 'flags': flags}))
