"""Audit manually committed decisions and final workbook; no classification."""
import collections, datetime, hashlib, json, sqlite3, subprocess, sys
from pathlib import Path
from codex_review import digest, effective_reviews
from qualify import is_recent

ROOT=Path(__file__).resolve().parents[1]
WORK,OUT=ROOT/'work',ROOT/'outputs'
def read(p): return json.loads(p.read_text('utf-8'))
m=read(WORK/'待确认口径复审队列_20261012.json')
base_manifest=read(WORK/'全量逐条复审队列_20261012.json')
with sqlite3.connect((WORK/'campaign.sqlite3').as_uri()+'?mode=ro',uri=True) as c:
    records={i:json.loads(d) for i,d in c.execute("select id,data from records where id like 'comment:%'")}
with sqlite3.connect((WORK/'codex_reviews.sqlite3').as_uri()+'?mode=ro',uri=True) as c:
    for table,baseline in m['baseline'].items():
        assert [list(r) for r in c.execute('select id,data from '+table+' order by id')]==baseline,table
    base_rows=[list(r) for r in c.execute("select id,data from review_fullpasses where pass_id='20261012_all_comments' order by id")]
    assert digest(base_rows)==m['base_fullpass_hash']
    base={i:json.loads(d) for i,d in base_rows}
    stored=c.execute('select id,batch,data from review_fullpasses where pass_id=?',(m['pass_id'],)).fetchall()
    fresh={i:json.loads(d) for i,b,d in stored}
    current={d['id']:d for d in effective_reviews(c)}
assert len(base)==len(records)==16127
assert set(records)==set(base)==set(base_manifest['ids'])
assert len(stored)==len(fresh)==len(m['ids'])==5022 and set(fresh)==set(m['ids'])
assert all(base[i]['verdict']=='待确认' for i in fresh)
expected=dict(base);expected.update(fresh)
assert current==expected
for ident,d in current.items():
    r=records[ident]
    assert digest(r)==base_manifest['source_hashes'][ident]==d['source_hash']
    assert d['record']==r and d['id']==ident and d['reviewer']=='Codex'
    assert d['verdict'] in ('高意向','待确认','排除') and 0<=d['score']<=100 and d['reason'].strip()
    for key in ('demand_evidence','budget_evidence','payment_evidence','urgent_evidence'):
        assert not d.get(key) or d[key] in r['text'],(ident,key)
    if d['verdict']=='高意向':
        assert d['score']>=80 and d['demand_evidence'] and r['user_id'] and is_recent(r['published_at'])
for ident,d in fresh.items():
    assert d['source_hash']==m['source_hashes'][ident] and d['fullpass_id']==m['pass_id']
batch_names={b for i,b,d in stored}
for name in batch_names:
    p=Path(name);batch=read(p);decisions=read(p.with_name(p.stem+'_decisions.json'))
    rows={x['index']:x for x in batch['comments']}
    assert len(rows)==len(batch['comments'])==len(decisions['decisions'])
    assert set(rows)=={d['index'] for d in decisions['decisions']} and decisions['reviewer']=='Codex'
    assert batch['pass_id']==m['pass_id']
    for decision in decisions['decisions']:
        row=rows[decision['index']];ident=row['record']['id']
        assert row['previous_review']==base[ident]
        for k,v in decision.items(): assert fresh[ident][k]==v,(ident,k)
snap=read(WORK/'客户分类快照.json')
assert len(snap['rows'])==16127 and {r['id'] for r in snap['rows']}==set(current)
assert len(snap['customers'])==len({r['uid'] for r in snap['customers']})
assert all(r['uid']!='1899550237005519' for r in snap['customers'])
for r in snap['rows']:
    d=current[r['id']]
    assert (r['verdict'],r['score'],r['reason'],r['type'])==(d['verdict'],d['score'],d['reason'],d['demand_type'])
assert read(WORK/'STOP')['user_requested_pause'] is True
assert 'status = "PAUSED"' in Path('C:/Users/rmsama/.codex/automations/automation-13/automation.toml').read_text('utf-8')
status=subprocess.run([sys.executable,'-X','utf8',str(WORK/'launch_comments.py'),'--status'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',check=True)
assert json.loads(status.stdout)['running'] is False
export=read(OUT/'本轮增量复核验收.json')
assert export['errors']==[] and export['reviewed_total']==16127 and export['excel_pending']==0
assert export['native_filtered_tables']>=11 and export['search_keywords']==420
assert export['reviews_committed_after_excel_snapshot']==0
target=Path(export['excel_file'])
result=dict(audited_at=datetime.datetime.now().astimezone().isoformat(),
    pass_id=m['pass_id'],collected_comments=16127,all_comments_manually_reviewed=16127,
    pending_cleanup_total=5022,pending_cleanup_completed=len(fresh),remaining_to_review=0,
    cleanup_batches=len(batch_names),cleanup_verdicts=dict(collections.Counter(d['verdict'] for d in fresh.values())),
    effective_comment_verdicts=dict(collections.Counter(d['verdict'] for d in current.values())),
    deduplicated_customer_verdicts=dict(collections.Counter(r['verdict'] for r in snap['customers'])),
    customer_total=len(snap['customers']),
    demand_types={t:dict(collections.Counter(r['verdict'] for r in rows)) for t,rows in snap['types'].items()},
    original_reviews_preserved=len(m['baseline']['reviews']),historical_rechecks_preserved=len(m['baseline']['review_rechecks']),
    prior_full_review_preserved=len(base),original_and_historical_ledgers_byte_unchanged=True,
    all_source_hashes_unchanged=True,evidence_exact_commenter_quotes=True,
    every_xlsx_conclusion_matches_latest_ledger=True,verified_native_video_links=export['verified_customer_video_links'],
    native_filtered_tables=export['native_filtered_tables'],search_keywords=420,collection_paused=True,worker_running=False,automation_status='PAUSED',
    excel_file=str(target),excel_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    note='待确认原口径过宽；当前Codex再次完整阅读原5022条待确认及来源回复上下文，排除资料领取、自学、纯互动等，保留明确确认缺口。高意向为公开线索，未认定支付能力、马上付款或外联同意。',errors=[])
(OUT/'待确认口径修正验收_20261012.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
(OUT/'待确认逐条口径复审_20261012.jsonl').write_text(''.join(json.dumps(d,ensure_ascii=False)+'\n' for d in fresh.values()),'utf-8')
print(json.dumps(result,ensure_ascii=False))
