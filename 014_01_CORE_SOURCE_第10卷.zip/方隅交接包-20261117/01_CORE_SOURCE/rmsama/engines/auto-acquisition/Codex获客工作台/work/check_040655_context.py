import json, sqlite3
from pathlib import Path
work=Path(__file__).resolve().parent
with sqlite3.connect((work/'campaign.sqlite3').as_uri()+'?mode=ro',uri=True) as src, sqlite3.connect((work/'codex_reviews.sqlite3').as_uri()+'?mode=ro',uri=True) as led:
 for (data,) in src.execute('select data from records where json_extract(data,?)=?',('$.user_id','99745163187')):
  r=json.loads(data)
  print(json.dumps({'same_uid_record': {k:r.get(k) for k in ('id','user_id','text','parent_text','published_at','source_url')}},ensure_ascii=False))
  for table in ('reviews','review_rechecks'):
   row=led.execute('select data from '+table+' where id=?',(r['id'],)).fetchone()
   if row: print(json.dumps({'table':table,'review':json.loads(row[0])},ensure_ascii=False))
