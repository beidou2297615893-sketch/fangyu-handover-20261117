import json
from pathlib import Path
rows=[(1,'夸赞外貌的互动，没有服务需求。'),(2,'分享删视频及设私密习惯，没有软件采购。'),(3,'感谢平台功能教程，没有本人服务委托。'),(4,'反映手机原生按钮不同，没有软件开发或制作需求。'),(5,'请求教鸿蒙手机上的平台操作，范围不是发布软件或开发委托。'),(6,'夸赞真实感和表情互动，没有采购。'),(7,'说明手机没有原生功能，未提出工具或开发委托。'),(8,'感谢学习分享，没有买方需求。'),(9,'表示早已会原生修改方法，没有未解决服务需求。')]
decisions=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
out=Path(__file__).parent/'review-batches/20261011_052206_842054_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
