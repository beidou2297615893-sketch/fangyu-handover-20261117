import json
from pathlib import Path
rows=[
 (1,'提醒他人CRM客户数据风险，没有本人采购意愿；被回复者愿意买不能归给此人。'),
 (2,'仅点赞比心表情，纯互动。'),
 (3,'向主播问好和点赞，未表达需求。'),
 (4,'称赞作品并点赞，无服务委托。'),
 (5,'仅称赞，无本人采购。'),
 (6,'讨论平台转圈得金币，无本范围需求。'),
 (7,'赞教程讲得好，没有本人任务。'),
 (8,'仅点赞玫瑰表情，无需求。'),
 (9,'仅点赞表情，无需求。'),
 (10,'仅点赞表情，无需求。'),
 (11,'仅点赞表情，无需求。'),
 (12,'仅点赞表情，无需求。'),
 (13,'赞豆包功能强，无本人采购或方案寻找。'),
 (14,'仅点赞表情，无需求。'),
 (15,'仅点赞表情，无需求。'),
 (16,'仅点赞表情，无需求。'),
 (17,'仅玫瑰表情，无需求。'),
 (18,'仅咖啡表情，无需求。'),
 (19,'仅点赞表情，无需求。'),
]
d={'reviewer':'Codex','decisions':[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]}
Path('work/review-batches/20261011_010246_688482_decisions.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
