import json
from pathlib import Path
rows=[
(1,'称赞内容，无本人采购需求。'),
(2,'对收入视频表示早已知道，无服务需求。'),
(3,'观看到结尾的互动，无服务委托。'),
(4,'支持博主收入的互动，无本人需求。'),
(5,'仅表情互动，无本人需求。'),
(6,'调侃博主，无明确服务需求。'),
(7,'调侃形象代言，无本人采购需求。'),
(8,'索取现成表格模板，自称学会，无软件开发委托。'),
(9,'催发视频相关资料，未表达服务需求。'),
(10,'仅表情互动，无本人需求。'),
(11,'询博主外观变化，无服务需求。'),
(12,'仅表情互动，无本人需求。'),
(13,'夸张比较自身收入，收入不是采购预算。'),
(14,'观看到结尾的互动，无本人采购需求。'),
(15,'对收入的俗语评论，无服务需求。'),
(16,'讲述偶遇博主，无本人采购需求。'),
(17,'博主对偶遇评论的回复，非买家需求。'),
(18,'比较本人和博主收入，无采购预算或服务需求。'),
(19,'辨认博主身份，无服务需求。'),
(20,'建议查看个税App以核对收入，非软件委托或产品需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,21))
p=Path('work/review-batches/20261011_045620_817347_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
