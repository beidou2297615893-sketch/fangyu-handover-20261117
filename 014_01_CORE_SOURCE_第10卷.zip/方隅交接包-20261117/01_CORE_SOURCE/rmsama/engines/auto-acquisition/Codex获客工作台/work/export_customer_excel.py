"""Snapshot local evidence for a categorized XLSX. Does not score comments."""
import datetime,json,sqlite3,subprocess,os,sys,re,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
from codex_review import effective_reviews
from qualify import is_recent

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'work';OUT=ROOT/'outputs'
NODE=Path('C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
TYPES=['软件开发','微信小程序','获客系统与CRM','多平台发布','数字人与视频','AI自动化','需求未明确']
SOURCE_TYPES={'软件定制':'软件开发','企业管理':'软件开发','微信小程序':'微信小程序','小程序业务':'微信小程序','获客系统':'获客系统与CRM','客户管理':'获客系统与CRM','私域运营':'获客系统与CRM','销售自动化':'AI自动化','AI工作流':'AI自动化','数字人':'数字人与视频','视频营销':'数字人与视频','多平台发布':'多平台发布'}

def ro(name):
    c=sqlite3.connect((WORK/name).as_uri()+'?mode=ro',uri=True,timeout=10)
    c.execute('pragma query_only=ON');return c

def attach_native_links(snapshot):
    """Supply the native hyperlink feature missing from the authoring engine."""
    files=[OUT/'客户分类清单.xlsx',OUT/'客户分类清单_最新.xlsx']
    target=max((p for p in files if p.exists()),key=lambda p:p.stat().st_mtime)
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    pkg='http://schemas.openxmlformats.org/package/2006/relationships'
    ET.register_namespace('',ns);ET.register_namespace('r',rel)
    customer_views=[snapshot['customers']]+list(snapshot['types'].values())+[snapshot['rows']]
    posts=list({x['url']:x for x in snapshot['rows']}.values())
    views=[(rows,'F') for rows in customer_views]+[(posts,'D')]
    with zipfile.ZipFile(target) as z:parts={n:z.read(n) for n in z.namelist()}
    wb=ET.fromstring(parts['xl/workbook.xml'])
    wrels={x.attrib['Id']:x.attrib['Target'] for x in ET.fromstring(parts['xl/_rels/workbook.xml.rels'])}
    links=0
    for sheet,(rows,column) in zip(wb.find('{'+ns+'}sheets'),views):
        destination=wrels[sheet.attrib['{'+rel+'}id']]
        name=destination.lstrip('/') if destination.startswith('/') else 'xl/'+destination
        name=name.replace('xl/xl/','xl/')
        root=ET.fromstring(parts[name]);old=root.find('{'+ns+'}hyperlinks')
        if old is not None:root.remove(old)
        h=ET.Element('{'+ns+'}hyperlinks')
        base=Path(name);rp=str(base.parent/'_rels'/(base.name+'.rels')).replace('\\','/')
        relationships=ET.fromstring(parts[rp]) if rp in parts else ET.Element('{'+pkg+'}Relationships')
        used={x.attrib['Id'] for x in relationships}
        for i,x in enumerate(rows,6):
            if not re.fullmatch(r'https://www\.douyin\.com/video/\d+',x['url']):continue
            rid='customerLink'+str(i)
            if rid in used:raise ValueError('Hyperlink relationship collision')
            ET.SubElement(relationships,'{'+pkg+'}Relationship',{'Id':rid,'Type':rel+'/hyperlink','Target':x['url'],'TargetMode':'External'})
            ET.SubElement(h,'{'+ns+'}hyperlink',{'ref':column+str(i),'{'+rel+'}id':rid});links+=1
        before={'printOptions','pageMargins','pageSetup','headerFooter','rowBreaks','colBreaks','customProperties','cellWatches','ignoredErrors','smartTags','drawing','legacyDrawing','legacyDrawingHF','picture','oleObjects','controls','webPublishItems','tableParts','extLst'}
        insert=next((i for i,e in enumerate(root) if e.tag.split('}')[-1] in before),len(root))
        root.insert(insert,h)
        parts[name]=ET.tostring(root,encoding='utf-8',xml_declaration=True)
        parts[rp]=ET.tostring(relationships,encoding='utf-8',xml_declaration=True)
    temp=target.with_suffix('.links.tmp.xlsx')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
        for name,blob in parts.items():z.writestr(name,blob)
    temp.replace(target)
    print(json.dumps({'native_video_links':links,'file':str(target)},ensure_ascii=False))

def run():
    with ro('campaign.sqlite3') as c:
        records=[json.loads(x[0]) for x in c.execute("select data from records where id like 'comment:%' order by rowid")]
        posts={json.loads(x[0])['source_url']:json.loads(x[0]) for x in c.execute("select data from records where id like 'note:%'")}
    with ro('codex_reviews.sqlite3') as c:
        reviews={x['id']:x for x in effective_reviews(c)}
    typefile=WORK/'需求分类.json'
    manual=json.loads(typefile.read_text('utf-8')) if typefile.exists() else {}
    rows=[]
    for r in records:
        d=reviews.get(r['id'],{});post=posts.get(r['source_url'],{})
        dtype=d.get('demand_type') or manual.get(r['id'])
        if dtype not in TYPES:dtype=None
        dated=is_recent(r.get('published_at'))
        recent=dated and bool(r['text'].strip())
        rows.append(dict(id=r['id'],uid=r['user_id'],author=r['author'],text=r['text'],
            verdict=d.get('verdict','待分析' if recent else ('非文字评论' if dated else '日期不符')),score=d.get('score'),
            type=dtype or SOURCE_TYPES.get(r.get('category'),'需求未明确'),
            type_basis=({'高意向':'Codex按本人需求确认','待确认':'Codex按评论用途分类，具体确认缺口见判断依据','排除':'Codex已排除，不作为采购线索'}.get(d.get('verdict'),'尚未分析')) if dtype else '按帖子主题归类，本人需求待确认',
            category=r.get('category',''),keyword=r.get('keyword',''),recent=recent,
            published_at=r.get('published_at'),collected_at=r.get('collected_at'),
            reviewed_at=d.get('reviewed_at'),url=r['source_url'],post_id=r['source_url'].rsplit('/',1)[-1],
            post_text=d.get('video_context') or r.get('parent_text') or post.get('text',''),
            post_date=post.get('published_at'),reason=d.get('reason','尚未由Codex复核' if recent else '不计入近三个月目标'),
            demand=d.get('demand_evidence',''),budget=d.get('budget_evidence',''),
            payment=d.get('payment_evidence',''),urgent=d.get('urgent_evidence',''),
            reply_to=r.get('reply_to_text',''),subtype=r.get('subtype','root')))
    def rank(x):
        return (x['verdict']=='高意向',bool(x['budget'] and x['urgent']),bool(x['budget']),bool(x['urgent']),bool(x['payment']),x['score'] or 0,x['published_at'] or 0)
    candidates=sorted([x for x in rows if x['recent'] and x['uid'] and x['verdict'] in ('高意向','待确认')],key=rank,reverse=True)
    people={};bytype={t:{} for t in TYPES}
    for x in candidates:
        people.setdefault(x['uid'],x);bytype[x['type']].setdefault(x['uid'],x)
    now=datetime.datetime.now().astimezone().isoformat()
    snapshot=dict(updated=now,rows=rows,customers=list(people.values()),types={t:list(v.values()) for t,v in bytype.items()},
        queries=json.loads((OUT/'采集计划.json').read_text('utf-8'))['queries'],
        stats=dict(collected=len(rows),recent=sum(x['recent'] for x in rows),reviewed=len(reviews),
                   high=sum(x['verdict']=='高意向' for x in people.values()),customers=len(people)))
    p=WORK/'客户分类快照.json';tmp=p.with_suffix('.json.tmp');tmp.write_text(json.dumps(snapshot,ensure_ascii=False),encoding='utf-8');tmp.replace(p)
    env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=8192'
    render_args=[flag for flag in ['--render','--render-summary'] if flag in sys.argv]
    subprocess.run([str(NODE),str(WORK/'build_customer_excel.mjs')]+render_args,cwd=WORK,env=env,check=True)
    attach_native_links(snapshot)
    print(json.dumps(snapshot['stats'],ensure_ascii=False))

if __name__=='__main__':run()
