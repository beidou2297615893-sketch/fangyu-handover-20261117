import json
from pathlib import Path
rows=[
(1,'讲述账号播放和月收入，五六十是历史收益，无服务采购需求。'),
(2,'建议互看广告群，无本人软件需求，不执行互助操作。'),
(3,'比较播放收益，五块是收益非预算。'),
(4,'请求视频号带货运营教学，范围外培训需求；播放量与前天爆量不是采购预算或期限。'),
(5,'作者称赞播放成绩，非买家需求。'),
(6,'讲述视频收益低，无服务需求或预算。'),
(7,'仅点赞表情，无本人服务需求。'),
(8,'仅称赞表情，无本人服务需求。'),
(9,'询当日百万播放是否有收益，无软件采购需求；今天不是采购期限。'),
(10,'讲述收益几毛，无服务需求。'),
(11,'描述自己点击广告消失，无本次软件服务委托。'),
(12,'评论收益几毛，无采购预算或需求。'),
(13,'仅称赞互动，无本人服务需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,14))
p=Path('work/review-batches/20261011_050339_381100_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
