import json
from pathlib import Path
d={'index':1,'verdict':'排除','score':0,'reason':'评价本地大模型边界及部署威力，属于技术观点和点赞赞扬，未提出本人外贸获客软件、部署或服务委托。视频的发送量、4090配置和第三方客户信息不转归评论者需求；不执行采集私人信息或触达暗示。','demand_type':'需求未明确','demand_evidence':'','budget_evidence':'','payment_evidence':'','urgent_evidence':''}
(Path(__file__).parent/'review-batches/20261011_041612_070300_decisions.json').write_text(json.dumps({'reviewer':'Codex','decisions':[d]},ensure_ascii=False,indent=2),'utf-8')
