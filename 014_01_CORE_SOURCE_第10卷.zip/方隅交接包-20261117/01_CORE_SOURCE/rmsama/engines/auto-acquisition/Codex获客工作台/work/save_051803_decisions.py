import json
from pathlib import Path
rows=[
 (1,'求作者公开免费分享的插件，没有付费采购或定制委托。'),
 (2,'索取免费投简历插件，未提出开发要求。'),
 (3,'单字求回应免费分享，没有本人具体需求。'),
 (4,'求免费插件和表情互动，不是软件采购。'),
 (5,'只索取免费分享插件，没有委托。'),
 (6,'求作者免费资源，未表达采购或开发需求。'),
 (7,'仅求免费插件，没有定制或付费意向。'),
 (8,'关注换取免费插件的互动，没有服务采购。'),
 (9,'只求免费资源，需求未具体化。'),
 (10,'单字求插件资源，没有本人委托。'),
 (11,'蹲免费分享，未提出需求。'),
 (12,'已关注求免费插件，没有采购证据。'),
 (13,'蹲资源的互动，不是服务需求。'),
 (14,'关注及玫瑰求免费插件，没有开发委托。'),
 (15,'泛求免费资源，没有具体采购。'),
 (16,'索取公开免费插件，没有定制服务需求。'),
 (17,'蹲免费分享，无买方需求。'),
 (18,'只有蹲的互动，未表达本人采购。'),
 (19,'蹲免费资源，不构成开发或自动化委托。'),
]
decisions=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [d['index'] for d in decisions]==list(range(1,20))
out=Path(__file__).parent/'review-batches/20261011_051803_564601_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
