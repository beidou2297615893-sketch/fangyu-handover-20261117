import json
from pathlib import Path
# 当前Codex完整阅读11条后逐项判断；只保存。
rows=[
 (1,'排除',0,'以同行身份谈AI开发能力，没有本人采购。',''),
 (2,'排除',0,'明确寻找接单群，是供给方找订单，不是软件买家。',''),
 (3,'排除',0,'单字兔，无可识别服务需求。',''),
 (4,'排除',0,'请求加入接单群，没有本人软件或服务委托。',''),
 (5,'待确认',40,'本人说有需求，但未说明具体软件、功能或服务，也可能指群入口；保持待确认，不把接单教程主题补成采购。','有需求'),
 (6,'排除',0,'请求拉进接单群，不是本人服务采购。',''),
 (7,'排除',0,'询问如何进群，没有软件或自动化委托。',''),
 (8,'排除',0,'求接单群入口，非买家采购。',''),
 (9,'排除',0,'仅求群，无本人软件功能或委托。',''),
 (10,'排除',0,'求群加表情，属于接单资料入口诉求。',''),
 (11,'排除',0,'请求加入视频介绍的接单群，没有本人服务需求。',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type='需求未明确',demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,e in rows]
p=Path(__file__).parent/'review-batches/20261011_034540_967523_decisions.json'
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(len(d))
