"""Desktop entry without PowerShell web parsing or script prompts."""
import json
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
URL = 'http://127.0.0.1:19747'

def ready():
    try:
        with urllib.request.urlopen(URL + '/api/state', timeout=1) as response:
            data = json.load(response)
            return isinstance(data, dict) and all(k in data for k in ('criteria', 'leads', 'platforms'))
    except Exception:
        return False

def main():
    if not ready():
        with (ROOT / 'work/server.stdout.log').open('a', encoding='utf-8') as out, (ROOT / 'work/server.stderr.log').open('a', encoding='utf-8') as err:
            process = subprocess.Popen(
                [sys.executable, str(ROOT / 'work/server.py')], cwd=str(ROOT),
                stdout=out, stderr=err,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            )
        for _ in range(50):
            if ready():
                break
            if process.poll() is not None:
                break
            time.sleep(0.1)
    if not ready():
        raise RuntimeError('工作台服务未启动，请让 Codex 检查本项目 work/server.stderr.log。')
    webbrowser.open(URL)

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, str(exc), '我的获客工作台', 16)
