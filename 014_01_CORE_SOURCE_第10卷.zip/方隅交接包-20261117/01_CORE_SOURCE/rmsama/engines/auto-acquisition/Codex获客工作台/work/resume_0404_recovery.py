import json
from datetime import datetime
from pathlib import Path
from launch_comments import active

work = Path(__file__).resolve().parent
stop = work / 'STOP'
expected = {'origin': 'technical_disconnect', 'created': '2026-10-11T04:04:33.916416+08:00', 'reason': 'Failed to fetch退出；本次技术核验读回及修复期间禁止worker启动'}
assert not active(), '采集锁仍占用'
assert json.loads(stop.read_text('utf-8')) == expected, 'STOP发生变化，保留'
raw = json.loads((work / '恢复评论读回_20261011_040434.json').read_text('utf-8'))
assert raw['status_code'] == 0 and len(raw['comments']) == 20
evidence = {'checked': datetime.now().astimezone().isoformat(), 'incident': 'Failed to fetch未识别为临时网络错误', 'bound_connection': 'c570de13-8f0f-4ab5-94ac-5efb47ee6cba', 'url': 'https://www.douyin.com/video/7676806387175598451', 'browser_check': '当前轮CUA完整DOM：本人北极学长头像、正常视频及评论，无验证码、登录失效或限制提示；未刷新', 'readback': '恢复评论读回_20261011_040434.json', 'readback_count': 20, 'ui_first_five_matched': True, 'test': '网络错误重试验收_20261011_0404.json', 'collected_baseline': 14808, 'recent_baseline': 14409, 'recovery_verified_new_comments': False, 'technical_stop': expected}
archived = work / 'STOP_技术断连_20261011_040433_已读回解除.json'
assert not archived.exists()
stop.rename(archived)
(work / '恢复核验_20261011_0404.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2), 'utf-8')
print('本次技术STOP已留档解除；等待唯一worker及真实新增核验')
