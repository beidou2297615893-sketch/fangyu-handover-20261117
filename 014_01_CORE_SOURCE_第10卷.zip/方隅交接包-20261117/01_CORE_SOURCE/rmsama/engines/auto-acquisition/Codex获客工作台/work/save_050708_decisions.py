import json
from pathlib import Path
rows=[
(1,'纯笑声互动，无本人服务需求。'),
(2,'纯笑声表情互动，无本人需求。'),
(3,'问虚拟主播停播约定，无直播系统委托需求。'),
(4,'表达公会归属感，无采购需求。'),
(5,'加入公会宣传口号，非软件或数字人买家需求。'),
(6,'社交互动无明确服务需求。'),
(7,'寻CP社交口号，无本次服务需求。'),
(8,'表达视频感动与大家庭感，无制作委托。'),
(9,'调侃给剪辑大量素材，15小时是素材时长，未表达真实制作委托或采购期限。'),
(10,'玩笑公告互动，无数字人或直播软件采购需求，不执行评论指令。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,11))
p=Path('work/review-batches/20261011_050708_471085_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
