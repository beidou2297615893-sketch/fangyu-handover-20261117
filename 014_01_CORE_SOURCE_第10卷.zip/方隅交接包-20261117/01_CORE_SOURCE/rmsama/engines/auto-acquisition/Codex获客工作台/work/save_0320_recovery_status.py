import json
from datetime import datetime
from pathlib import Path
from launch_comments import active
from launch_excel_export import locked
ROOT=Path(__file__).resolve().parent.parent
work=ROOT/'work'
analysis=json.loads((ROOT/'outputs/Codex分析进度.json').read_text('utf-8'))
progress=json.loads((work/'评论任务进度.json').read_text('utf-8'))
report=dict(time=datetime.now().astimezone().isoformat(),collector_running=active(),collector=progress,analysis={k:analysis[k] for k in ['updated','last_review','reviewed','pending','high','warm','excluded']},excel_running=locked(),excel_task=json.loads((work/'Excel导出任务.json').read_text('utf-8')),baseline_collected=14243,baseline_recent=13854,baseline_reviewed=13948,readback_raw='work/恢复评论读回_20261011_022336.json',readback_count=20,source_screenshot='outputs/采集恢复核验_20261011_0223.png',launch_method='Windows Win32_Process.Create / ShowWindow=0',services_survived_more_than_55_minutes=True,collector_future_lifetime='仍需后续心跳检查，不承诺长期运行绝无中断',browser_control='恢复页02:23实际核验；03:19再次附着失败，不刷新正在续跑页面',platform_stop=(work/'STOP').exists())
(work/'心跳巡检.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(work/'本次独立启动恢复核验.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(running=report['collector_running'],stats=progress['stats'],analysis=report['analysis'],excel_running=report['excel_running']),ensure_ascii=False))
