"""Conservative demand-signal ranking. Never infer ability or certainty to pay."""
import re,datetime,calendar
TZ=datetime.timezone(datetime.timedelta(hours=8))
def date_window(today=None):
 today=today or datetime.datetime.now(TZ).date()
 month=today.year*12+today.month-1-3
 year,m=divmod(month,12);m+=1
 start=datetime.datetime(year,m,min(today.day,calendar.monthrange(year,m)[1]),tzinfo=TZ)
 end=datetime.datetime.combine(today+datetime.timedelta(days=1),datetime.time(),TZ)
 return start,end

def is_recent(stamp,today=None):
 try:
  if isinstance(stamp,(int,float)) and stamp>0:dt=datetime.datetime.fromtimestamp(stamp/(1000 if stamp>1e12 else 1),TZ)
  elif stamp:dt=datetime.datetime.fromisoformat(str(stamp)).astimezone(TZ)
  else:return False
  start,end=date_window(today)
  return start<=dt<end
 except (ValueError,TypeError,OverflowError,OSError):return False

START,END=date_window()
BUY=re.compile(r'找.{0,5}(人|公司|团队|供应商).{0,8}(做|开发|定制|制作|报价)|找.{0,4}(开发|制作|定制).{0,4}(公司|团队|人员)|哪里.{0,5}(做|开发)|谁.{0,5}(能做|会做|能开发)|想.{0,5}(定制|开发|做个|做一套)|需要.{0,6}(开发|定制|外包|系统)|求.{0,5}(报价|推荐|开发)|准备.{0,5}(采购|外包|上线)|有没有.{0,6}(能做|会做|团队)|有.{0,5}(能做|会做|会开发).{0,12}(吗|没)|我要.{0,5}(做|开发|定制)|外包')
SOFT=re.compile(r'多少钱|怎么做|怎么弄|想了解|咨询|求推荐|求一个|想要|需要|报价')
BUDGET=re.compile(r'预算.{0,12}(\d|[一二三四五六七八九十几两]).{0,5}(万|千|百|元|块)|(?:\d{3,8}|[一二三四五六七八九十两]+[万千百])\s*(?:元|块|预算)|有预算')
PAYMENT=re.compile(r'有偿|愿意付费|可以付费|付费.{0,6}(定制|开发|制作)')
PROVIDER=re.compile(r'找.{0,5}(人|公司|团队|供应商).{0,8}(做|开发|定制|制作|报价)|找.{0,4}(开发|制作|定制).{0,4}(公司|团队|人员)|哪里.{0,5}(做|开发)|谁.{0,5}(能做|会做|能开发)|有没有.{0,6}(能做|会做|团队)|有.{0,5}(能做|会做|会开发).{0,12}(吗|没)|求.{0,5}报价|外包')
URGENCY=re.compile(r'急需|急找|加急|这周|本周|今天.{0,6}(要|做|完成)|明天.{0,6}(要|做|交付)|[123一二三七]天内|尽快.{0,6}(上线|交付|做完)|马上.{0,6}(上线|做|开发)|赶.{0,5}(上线|交付)')
NEGATIVE=re.compile(r'已经.{0,5}(做完|做好|解决)|已.{0,3}(做好|解决)|不需要|不用了|暂时不做|不做了|只要免费|不想付费|没有预算|没预算|预算为?0|求职|找工作|招聘.{0,10}(开发|工程师)|免费教程|招学员|收徒|培训招生')
SELL=re.compile(r'我.{0,5}(接单|代做|能做|会做)|承接.{0,10}(开发|制作|业务)|专业.{0,8}(定制|开发|制作)|需要.{0,5}(联系我|私信我)|提供.{0,8}(开发|制作|服务)|开发.{0,5}(联系我|找我)|低价代做|接单中')
PROMO=re.compile(r'有没有.{0,4}(人|老板|客户).{0,6}(需要|想做)|如果你.{0,6}(想|需要)|教你|手把手|免费教程|开发教程|制作教程|保姆级教程|工具推荐|实测.{0,12}(流程|工具)|分享.{0,8}(教程|工具|方法)|培训招生|这款神器|我挖到.{0,6}(神器|工具)|这条视频.{0,8}(帮你|教你)|专门帮你|\d个避坑指南')
TOPIC=re.compile(r'获客|CRM|CRP|ERP|客户.{0,3}(管理|线索|筛选)|销售.{0,3}(系统|自动化)|私域|企微|企业微信|自动化|智能体|AI客服|RPA|数字人|虚拟主播|带货|口播|宣传视频|短视频|小程序|商城|预约|团购|会员|点单|进销存|订单|软件|网站|后台|微信支付|数据报表',re.I)
def excerpt(regex,text):
 m=regex.search(text);return text[max(0,m.start()-8):min(len(text),m.end()+10)] if m else ''
def qualify(row):
 t=row.get('text','');direct=bool(BUY.search(t));soft=bool(SOFT.search(t));topic=bool(TOPIC.search(t));budget=excerpt(BUDGET,t);urgent=excerpt(URGENCY,t)
 stamp=row.get('published_at');dt=None
 try:
  if isinstance(stamp,(int,float)) and stamp>0:dt=datetime.datetime.fromtimestamp(stamp/(1000 if stamp>1e12 else 1),TZ)
  elif stamp:dt=datetime.datetime.fromisoformat(str(stamp)).astimezone(TZ)
 except (ValueError,TypeError,OverflowError):pass
 recent=is_recent(stamp);reason=[]
 if not t.strip():reason.append('空文本')
 if NEGATIVE.search(t):reason.append('否定/已解决/免费/招聘或教程')
 if SELL.search(t):reason.append('疑似服务供应商广告')
 if dt and not recent:reason.append('需求表达超出三个月范围')
 if PROMO.search(t):reason.append('疑似教程、宣传或招揽客户')
 if not topic:reason.append('本人原话未明确相关服务')
 if not direct:reason.append('仅咨询价格或方法，尚无明确采购需求' if soft else '尚无本人明确采购需求')
 if not dt:reason.append('日期待核实')
 if not row.get('user_id'):reason.append('缺少稳定用户ID，不能计为独立客户')
 identity=bool(row.get('user_id'));url=bool(row.get('source_url'));kind=row.get('kind')
 age=(datetime.datetime.now(TZ)-dt).days if dt else 999
 dims={'需求强度':25 if direct else 10 if soft else 0,'产品适配':25 if topic else 0,'时机':20 if urgent and recent else 15 if recent and age<=30 else 8 if recent else 0,'公开可联系':15 if identity and url else 0,'证据质量':15 if dt and url and kind=='comment' else 10 if dt and url else 0}
 score=sum(dims.values());rejected=bool(NEGATIVE.search(t) or SELL.search(t) or PROMO.search(t) or (dt and not recent) or not t.strip())
 purchase=bool(PROVIDER.search(t) or budget or PAYMENT.search(t))
 if direct and not purchase:reason.append('需要确认找供应商或付费采购，不能把自学制作当采购')
 high=score>=80 and direct and purchase and topic and recent and identity and url and not rejected
 if rejected:score=min(score,49)
 return dict(score=score,dimensions=dims,tier='排除' if rejected else '高意向' if high else '待核实',demand_evidence=excerpt(BUY,t) or excerpt(SOFT,t),budget_evidence=budget,payment_evidence=excerpt(PAYMENT,t),urgent_evidence=urgent,reasons=reason or ['原话存在本人明确需求；尚需核查上下文'],date_verified=recent,urgent=bool(urgent and high),budget_ready=bool(budget and high),manual_verified=False)
