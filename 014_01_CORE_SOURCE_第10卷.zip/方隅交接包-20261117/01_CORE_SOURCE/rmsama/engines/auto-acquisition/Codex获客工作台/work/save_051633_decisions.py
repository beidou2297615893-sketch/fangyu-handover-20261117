import json
from pathlib import Path
rows=[(1,'纯表情赞叹，没有需求。'),(2,'抢沙发和花朵互动，没有本人需求。'),(3,'作者抢沙发回复，没有买方采购。'),(4,'只@他人，不把被提及者或教程主题当成其需求。'),(5,'询演示是否做出小红书式产品，未表达本人开发或采购需求。')]
decisions=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
out=Path(__file__).parent/'review-batches/20261011_051633_004771_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
