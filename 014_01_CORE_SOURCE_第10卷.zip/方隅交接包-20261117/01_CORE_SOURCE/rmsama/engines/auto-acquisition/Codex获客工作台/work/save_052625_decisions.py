import json
from pathlib import Path
rows=[
 (1,'排除',0,'回复他人软件问题讨论营业执照条件，没有本人软件需求，不能把被回复者需求转归评论者。','需求未明确',''),
 (2,'排除',0,'鼓励作者，无需求。','需求未明确',''),
 (3,'排除',0,'作者感谢祝福，无本人采购。','需求未明确',''),
 (4,'排除',0,'询问作者是否申请原创，属于版权操作讨论，非本人软件服务需求。','需求未明确',''),
 (5,'排除',0,'表达观看喜好，无需求。','需求未明确',''),
 (6,'排除',0,'评价抄袭行为，无服务需求。','需求未明确',''),
 (7,'排除',0,'祝原版走红的互动，无采购。','需求未明确',''),
 (8,'排除',0,'陈述刷到正版，无需求。','需求未明确',''),
 (9,'排除',0,'支持作者，无需求。','需求未明确',''),
 (10,'排除',0,'陈述观看记录，无需求。','需求未明确',''),
 (11,'排除',0,'表示下次截图，未提出软件或视频委托。','需求未明确',''),
 (12,'排除',0,'加油互动，无需求。','需求未明确',''),
 (13,'排除',0,'赞扬作者，无需求。','需求未明确',''),
 (14,'排除',0,'支持互动，无需求。','需求未明确',''),
 (15,'排除',0,'支持原创，无服务委托。','需求未明确','')
]
ds=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [d['index'] for d in ds]==list(range(1,16))
out=Path(__file__).parent/'review-batches/20261011_052625_551500_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
