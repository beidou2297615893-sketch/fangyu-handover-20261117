import json
from pathlib import Path
rows=[
(1,'排除',0,'本人想买Mac用于AI编程，实际需求为电脑推荐，范围外硬件采购；不按小程序教程主题推断开发委托。',''),
(2,'排除',0,'作者答复电脑配置，无本人软件采购，也不能转归提问者预算。',''),
(3,'排除',0,'称赞老师能力，纯互动。',''),
(4,'排除',0,'前排互动，无本人需求。',''),
(5,'排除',0,'作者鼓励互动，无采购。',''),
(6,'待确认',35,'表达兴趣并询联系，教程语境下可能关注学习或开发，具体本人目标未明；2222不是可验证预算，也不认定同意我们联系。','2222我有兴趣，怎么联系'),
(7,'排除',0,'仅@他人，无本人需求。',''),
(8,'排除',0,'仅@他人，无本人需求。',''),
(9,'排除',0,'仅@他人，无本人需求，按独立评论保留原记录。',''),
(10,'排除',0,'邀请看自己作品或账号，属互动引流，无本人采购。',''),
(11,'排除',0,'明确质疑博主带小白赚钱，未表达本人服务需求；不将讽刺内容判为购买意向。',''),
(12,'排除',0,'作者回应自身收入增长，5w是历史收入，非本人服务采购预算。',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type='需求未明确',demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,e in rows]
assert [r['index'] for r in d]==list(range(1,13))
p=Path('work/review-batches/20261011_042714_543559_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
