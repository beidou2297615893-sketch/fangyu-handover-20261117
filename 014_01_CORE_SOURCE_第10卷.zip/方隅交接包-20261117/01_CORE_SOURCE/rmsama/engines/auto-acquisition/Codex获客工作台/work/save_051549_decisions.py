import json
from pathlib import Path
rows=[
 (1,'只求拉群围观开源共创，没有本人营销系统需求。'),
 (2,'只求加入开源共创，没有具体采购或委托。'),
 (3,'拉群请求不能证明本人采购AI营销工具。'),
 (4,'只求加入群聊，没有本人业务需求。'),
 (5,'请求入群，未表达工具采购或开发任务。'),
 (6,'只求拉群并致谢，没有具体服务需求。'),
 (7,'泛求群入口，未表达买方需求。'),
 (8,'拉群和感谢互动，没有本人采购。'),
 (9,'只求进群围观，不把作者营销主题转为其需求。'),
 (10,'求拉群但未提出任何个人业务需求。'),
 (11,'只有群入口请求，没有软件采购或委托。'),
 (12,'只求拉群并感谢，没有本人服务需求。'),
 (13,'群聊请求不足以构成AI营销采购线索。'),
 (14,'求拉指向作者共创群，未表达功能或委托。'),
 (15,'只求入群，没有具体系统需求。'),
 (16,'请求拉群，不是本人采购或开发委托。'),
 (17,'泛求拉入共创群，没有自身需求证据。'),
 (18,'想入群属于围观兴趣，没有具体服务委托。'),
 (19,'只求拉群，不能从电玩城昵称推断营销系统需求。'),
]
decisions=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [d['index'] for d in decisions]==list(range(1,20))
out=Path(__file__).parent/'review-batches/20261011_051549_213745_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
