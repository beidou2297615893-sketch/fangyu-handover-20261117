"""Codex controls local state and read-only CLI collection. No sending commands."""
import argparse,json,os,subprocess,datetime,hashlib,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; BASE=ROOT.parent
STATE=ROOT/'outputs'/'state.json'
XHS=BASE/'work/vendor/cli-runtime/Scripts/xhs.exe'
DY=BASE/'work/vendor/cli-runtime/Scripts/dy.exe'
def now():return datetime.datetime.now().astimezone().isoformat(timespec='microseconds')
def read():
 if STATE.exists():return json.loads(STATE.read_text('utf-8'))
 return dict(updated=now(),criteria=dict(description='',keywords=[],region='',intent=[],exclude=[],days=30),status='等待你在 Codex 描述客户要求',platforms=[dict(name='小红书',status='CLI 可运行 · 当前未登录'),dict(name='抖音',status='CLI 可运行 · Python 入口未登录；Bridge 待核验')],leads=[],events=[],stats=dict(read=0,excluded=0))
def save(s):
 s['updated']=now();STATE.parent.mkdir(parents=True,exist_ok=True)
 tmp=STATE.with_suffix('.tmp');tmp.write_text(json.dumps(s,ensure_ascii=False,indent=2),'utf-8');tmp.replace(STATE)
def event(s,text):s['events']=[dict(time=now(),text=text)]+s.get('events',[])[:39]
def cli(args):
 env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
 result=subprocess.run([str(x) for x in args],capture_output=True,text=True,encoding='utf-8',errors='replace',env=env,timeout=100,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'); raw=ROOT/'work'/'raw';raw.mkdir(parents=True,exist_ok=True)
 (raw/(stamp+'.json.txt')).write_text(result.stdout+'\n'+result.stderr,'utf-8')
 if result.returncode:raise RuntimeError('CLI 执行失败；原始证据已保存，需 Codex 核查')
 text=result.stdout.strip()
 try:payload=json.loads(text)
 except ValueError:
  pos=[i for i,c in enumerate(text) if c in '[{'];payload=None
  for i in pos:
   try:payload=json.JSONDecoder().raw_decode(text[i:])[0];break
   except ValueError:pass
  if payload is None:raise RuntimeError('CLI 没有返回可识别 JSON；需核查输出结构')
 if isinstance(payload,dict) and payload.get('ok') is False:
  raise RuntimeError('平台未就绪：'+str(payload.get('error',{}).get('code','接口失败')))
 return payload.get('data',payload) if isinstance(payload,dict) else payload
def rows(payload,key):
 if isinstance(payload,list):return payload
 if isinstance(payload,dict) and isinstance(payload.get(key),list):return payload[key]
 raise RuntimeError('返回结构与已核对契约不符，停止解析')
def normalize(p,platform,kind,url=''):
 result=[]
 for x in rows(p,'comments' if kind=='comment' else ('items' if platform=='小红书' else 'aweme_list')):
  if platform=='小红书':
   card=x.get('note_card',x);u=card.get('user',x.get('user_info',{}));ident=str(x.get('id',''))
   text=x.get('content','') if kind=='comment' else (card.get('display_title') or card.get('title',''))+' '+card.get('desc','')
   link=url or 'https://www.xiaohongshu.com/explore/'+ident
   if not url and x.get('xsec_token'):link+='?xsec_token='+x['xsec_token']+'&xsec_source=pc_search'
   timestamp=x.get('create_time',card.get('time'))
  else:
   card=x.get('aweme_info',x);u=card.get('author',x.get('user',{}));ident=str(x.get('cid',card.get('aweme_id','')))
   text=x.get('text','') if kind=='comment' else card.get('desc','');link=url or 'https://www.douyin.com/video/'+ident
   timestamp=x.get('create_time',card.get('create_time'))
  if not ident:continue
  date=''
  if isinstance(timestamp,(int,float)) and timestamp>0:
   date=datetime.datetime.fromtimestamp(timestamp/(1000 if timestamp>1e12 else 1)).astimezone().isoformat()
  result.append(dict(id=hashlib.sha256((platform+kind+ident).encode()).hexdigest()[:20],platform=platform,author=u.get('nickname','未知用户'),text=text.strip(),url=link,kind=kind,published=date,region=x.get('ip_location',''),verdict='待核实',reasons=[]))
 return result
def screen(s,items):
 c=s['criteria']; old={x['id']:x for x in s['leads']}
 for x in items:
  s['stats']['read']+=1;t=x['text'];reasons=[]
  if any(w in t for w in c['exclude']):s['stats']['excluded']+=1;continue
  if x.get('published') and c.get('days') and (datetime.datetime.now().astimezone()-datetime.datetime.fromisoformat(x['published'])).days>c['days']:
   s['stats']['excluded']+=1;continue
  hits=[w for w in c['intent'] if w in t]
  if hits:reasons.append('需求表达：'+ '、'.join(hits))
  else:reasons.append('尚未找到明确需求表达')
  if c['region']:
   if c['region'] in t:reasons.append('原文提及目标地区')
   else:reasons.append('地区待核实（IP 属地不能当需求地点）')
  if not x.get('published'):reasons.append('发表时间待核实')
  if x['kind']!='comment':reasons.append('搜索内容，作者未必是客户')
  x['verdict']='有需求信号' if hits else '待核实';x['reasons']=reasons
  old[x['id']]=x
 s['leads']=list(old.values())
def main():
 ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='cmd',required=True)
 sub.add_parser('init')
 p=sub.add_parser('set');p.add_argument('--description',required=True);p.add_argument('--keywords',required=True);p.add_argument('--region',default='');p.add_argument('--intent',default='');p.add_argument('--exclude',default='');p.add_argument('--days',type=int,default=30)
 p=sub.add_parser('collect');p.add_argument('--platform',choices=['小红书','抖音'],required=True);p.add_argument('--keyword');p.add_argument('--url');p.add_argument('--limit',type=int,default=10)
 p=sub.add_parser('import');p.add_argument('path')
 a=ap.parse_args();s=read()
 try:
  if a.cmd=='set':
   if not 1<=a.days<=365:raise ValueError('时间范围须为 1—365 天')
   split=lambda x:[v.strip() for v in x.replace('，',',').split(',') if v.strip()]
   s['criteria']=dict(description=a.description,keywords=split(a.keywords),region=a.region,intent=split(a.intent),exclude=split(a.exclude),days=a.days)
   s['status']='条件已准备，等待小批采集';event(s,'Codex 更新客户筛选条件')
  elif a.cmd=='collect':
   if not s['criteria']['description']:raise ValueError('请先明确客户要求')
   if not 1<=a.limit<=20:raise ValueError('首次每批 1—20 条')
   if not (a.keyword or a.url):raise ValueError('需要关键词或作品链接')
   if a.url and not a.url.startswith('https://www.xiaohongshu.com/' if a.platform=='小红书' else 'https://www.douyin.com/'):
    raise ValueError('链接必须是对应平台完整 HTTPS 作品链接')
   s['status']='正在读取'+a.platform+'，本批筛选上限 '+str(a.limit)+' 条';event(s,s['status']);save(s)
   if a.platform=='小红书':
    payload=cli([XHS,'comments',a.url,'--json'] if a.url else [XHS,'search',a.keyword,'--sort','latest','--json'])
   else:
    if a.url:
     import re
     m=re.search(r'/video/(\d+)',a.url)
     if not m:raise ValueError('请使用 /video/数字ID 链接')
     payload=cli([DY,'comments',m[1],'--count',str(a.limit),'--json-output'])
    else:payload=cli([DY,'search',a.keyword,'--count',str(a.limit),'--json-output'])
   items=normalize(payload,a.platform,'comment' if a.url else 'note',a.url or '')[:a.limit];screen(s,items)
   s['status']='本批完成，请核对需求证据';event(s,'读取 '+str(len(items))+' 条；候选记录不等于确认客户')
  elif a.cmd=='import':
   items=json.loads(Path(a.path).read_text('utf-8-sig'))
   if not isinstance(items,list):raise ValueError('导入需要标准记录列表')
   for x in items:
    if not all(k in x for k in ['id','platform','author','text','url','kind']):raise ValueError('导入缺少来源字段')
   screen(s,items);s['status']='Codex 已更新候选结果';event(s,'导入 '+str(len(items))+' 条有来源的记录')
  else:event(s,'工作台已准备；CLI 帮助通过，两平台 Python 入口未登录；未采集真实客户')
 except Exception as e:
  s['status']=str(e);event(s,s['status']);save(s);print(s['status']);return 1
 save(s);print(s['status']);return 0
if __name__=='__main__':sys.exit(main())
