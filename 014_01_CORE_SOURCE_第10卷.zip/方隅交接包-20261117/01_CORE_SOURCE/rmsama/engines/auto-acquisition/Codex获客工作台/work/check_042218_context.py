import json,sqlite3
from pathlib import Path
b=json.loads(Path('work/review-batches/20261011_042218_360334.json').read_text(encoding='utf-8'))
print(type(b).__name__,list(b.keys()))
print(json.dumps(b.get('items',b.get('comments',[]))[17],ensure_ascii=False))
c=sqlite3.connect('work/codex_reviews.sqlite3')
print(c.execute("select name from sqlite_master where type='table'").fetchall())
print(c.execute('pragma table_info(reviews)').fetchall())
