import json, time
from datetime import datetime
from pathlib import Path
from campaign_collect import db, put
from launch_comments import active
ROOT = Path(__file__).resolve().parent.parent
work = ROOT/'work'
assert not active()
stop = json.loads((work/'STOP').read_text('utf-8'))
assert stop['origin']=='technical_disconnect' and stop['created_by']=='Codex'
assert stop['created_at']=='2026-10-11T00:43:35.640055+08:00'
raw = json.loads((work/'恢复评论读回_20261011_004525.json').read_text('utf-8'))
assert raw['status_code']==0 and len(raw['comments'])==20
assert [x['text'] for x in raw['comments'][:5]]==['比福客便宜吗？','防关联吗','售后呢','怎么试用','怎么那个']
assert (ROOT/'outputs/采集恢复核验_20261011_0045.png').exists()
binding = work/'抖音连接绑定.json'
(work/'抖音连接绑定_20261011_0045_技术恢复前.json').write_bytes(binding.read_bytes())
fresh={'connection_id':'2881da1d-9894-4c6b-a1e5-ea79952d13b1','conn_id':'2881da1d-9894-4c6b-a1e5-ea79952d13b1',
       'url':'https://www.douyin.com/video/7676806387175598451','server_port':19422,
       'browser_id':'3','tab_id':'896061670','binding_status':'fresh',
       'verified_at':datetime.now().astimezone().isoformat(),
       'verified_by':'原页控制通道失效后，同本人Chrome重开同一URL；北极学长头像、无验证登录限制提示，真实20条读回前5条与页面一致；仅绑定本新页，不读取旧注册'}
binding.write_text(json.dumps(fresh,ensure_ascii=False,indent=2),encoding='utf-8')
with db() as c:
    put(c,'last_read',time.time())
(work/'STOP').rename(work/'STOP_20261011_0045_本次技术恢复归档.json')
print(json.dumps({'verified':True,'binding':fresh,'old_tab_control_unavailable':'896061667'},ensure_ascii=False))
