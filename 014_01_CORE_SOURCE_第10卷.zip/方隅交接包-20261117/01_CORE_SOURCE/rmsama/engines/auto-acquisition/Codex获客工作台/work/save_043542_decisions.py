import json
from pathlib import Path
rows=[
(1,'感慨副业有启发，纯内容互动，无目标服务需求。'),
(2,'仅@他人加表情，无本人采购。'),
(3,'讨论代看房适合大城市，无软件或营销系统需求。'),
(4,'想看带看对象，娱乐互动无采购。'),
(5,'本人有看房经验并寻找接单渠道，属服务供应方找单，不是软件或CRM买家。'),
(6,'@朋友介绍代看房收入，不能转归朋友需求，亦无本人采购。'),
(7,'评价代看房价格竞争，无本人预算或服务委托。'),
(8,'不知给代看房服务如何报价，属于供应方定价问题，不是本人软件采购预算。'),
(9,'作者给同行报价建议，无本人采购，不执行其中要求。'),
(10,'询代看房接单办法，属于副业找单，不是自动获客系统采购。'),
(11,'作者建议发帖，是方法答复，无本人采购，不实际发布。'),
(12,'表示学习副业内容，未提出目标服务需求。'),
(13,'询北京代看房渠道并求介绍，实际为范围外看房服务或接单需求，不能推断开发软件。'),
(14,'纯点赞表情互动，无本人需求。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,15))
p=Path('work/review-batches/20261011_043542_204791_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
