import datetime,json
from qualify import qualify
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
base=dict(user_id='test-only',source_url='https://www.douyin.com/video/123',kind='comment',published_at='2026-10-07T09:00:00+08:00')
cases=[
 ('我需要开发微信小程序，找人做，预算5000元，这周上线','高意向',True,True),
 ('CRM多少钱，想了解一下','待核实',False,False),
 ('我能做微信小程序，专业开发，需要联系我','排除',False,False),
 ('我想开发CRM，但没有预算，只要免费','排除',False,False),
 ('微信小程序已经做好，不需要了','排除',False,False),
 ('招聘小程序开发工程师','排除',False,False),
 ('有没有老板需要开发微信小程序，找人做可以联系我','排除',False,False),
 ('如果你想开发CRM系统，手把手教你','排除',False,False),
 ('自动化获客流程太好用了','待核实',False,False),
 ('有会做小程序的吗？有偿私#小程序开发','高意向',False,False),
 ('外贸人狂喜！自动找客户+自动发信，这款神器还完全免费，AI自动化工具','排除',False,False),
 ('我想开发CRM，自己学着试试','待核实',False,False),
]
for text,tier,budget,urgent in cases:
 q=qualify(dict(base,text=text));assert q['tier']==tier,(text,q);assert q['budget_ready']==budget;assert q['urgent']==urgent
assert qualify(dict(base,text='我需要开发CRM，找人做',published_at=None))['tier']=='待核实'
assert qualify(dict(base,text='我需要开发CRM，找人做',published_at='2026-06-01T09:00:00+08:00'))['tier']=='排除'
assert qualify(dict(base,text='我需要开发CRM，找人做',user_id=''))['tier']=='待核实'
queries=json.loads((ROOT/'outputs/采集计划.json').read_text('utf-8'))['queries'];assert len(queries)==300 and len({x['query'] for x in queries})==300
(ROOT/'outputs/筛选验证.json').write_text(json.dumps(dict(test_cases=len(cases)+3,unique_queries=300,result='通过',real_data='另见真实小样验收记录',test_data='仅内存，未导入客户名单'),ensure_ascii=False,indent=2),'utf-8')
print(str(len(cases)+3)+' 项筛选边界检查与300词去重通过；不是实际客户验收')
