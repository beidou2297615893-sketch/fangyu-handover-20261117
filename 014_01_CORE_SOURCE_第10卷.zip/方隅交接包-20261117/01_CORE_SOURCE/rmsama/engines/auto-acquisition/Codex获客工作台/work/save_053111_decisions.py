import json
from pathlib import Path
rows=[
 (1,'赞叹互动，无本人需求。'),
 (2,'比较AI人物识别度与真人明星外貌，未表达本人制作委托。'),
 (3,'仅@朋友，无采购需求，不执行对外动作。'),
 (4,'夸赞AI人物外貌，无服务需求。'),
 (5,'讨论AI合成人脸与影响，没有本人采购。'),
 (6,'@朋友讨论网红竞争，无本人需求。'),
 (7,'明确不购买AI带货商品，非服务采购。'),
 (8,'讨论虚拟人物不会塌房，无需求。'),
 (9,'询问短剧更新速度，非本人制作项目期限或委托。'),
 (10,'支持虚拟人物的粉丝互动，无需求。'),
 (11,'夸赞人物外貌，无需求。'),
 (12,'@朋友与表情互动，无需求。'),
 (13,'@朋友夸赞作品，无本人制作需求。'),
 (14,'表达观看AI剧喜好，没有制作委托。'),
 (15,'@朋友赞扬作品，无采购。'),
 (16,'@朋友赞扬作品，无采购。'),
 (17,'赞扬作品，无服务需求。')
]
ds=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [d['index'] for d in ds]==list(range(1,18))
out=Path(__file__).parent/'review-batches/20261011_053111_667720_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
