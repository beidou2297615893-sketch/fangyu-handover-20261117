import json
from pathlib import Path
rows=[
(1,'询博主大号身份，非本人多账号发布需求。'),
(2,'讨论模仿者热度来源，无软件服务需求。'),
(3,'关于博主年龄的玩笑，无采购需求。'),
(4,'请求博主讲事件，范围外内容选题互动，非软件或视频制作委托。'),
(5,'赞美博主，无本人服务需求。'),
(6,'作者鼓励回复，非买方需求。'),
(7,'玩笑搜索口号，无服务需求，不执行评论指令。'),
(8,'评价博主背景品味，无本人制作需求。'),
(9,'赞博主诚实，无采购需求。'),
(10,'讨论他人质疑AI，无本人AI服务需求。'),
(11,'感叹博主年龄，无服务需求。'),
(12,'询他人账号是否有收入，无本人采购需求。'),
(13,'评价博主月收入并表示羡慕，1600不是本人采购预算。'),
(14,'叙述已关注多个博主账号，非本人矩阵发布需求。'),
(15,'比较自身历史创作收益，1万与几块是收入，非采购预算。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,16))
p=Path('work/review-batches/20261011_050537_547572_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
