import json
from pathlib import Path
rows=[
 (1,'排除',0,'只留工具名，没有本人需求，不能转归帖子矩阵运营需求。'),
 (2,'排除',0,'只留豆包AI名称，没有服务委托或购买表达。'),
 (3,'排除',0,'只留工具名，不能从电商昵称推断软件采购。'),
 (4,'排除',0,'只留豆包名称，未提出具体需求。'),
 (5,'排除',0,'工具名互动无买方需求。'),
 (6,'排除',0,'赞扬团队管理效率，未提出本人采购；6人300号是他人案例数据。'),
 (7,'排除',0,'仅Ai字样，无明确需求。')
]
ds=[dict(index=i,verdict=v,score=s,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r in rows]
assert [d['index'] for d in ds]==list(range(1,8))
out=Path(__file__).parent/'review-batches/20261011_052842_808232_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
