import json,sqlite3
from pathlib import Path
w=Path('work').resolve()
b=json.loads((w/'review-batches/20261011_045929_780502.json').read_text('utf-8'))
r=b['comments'][0]['record']
print(json.dumps(r,ensure_ascii=False))
uid=r['user_id']
with sqlite3.connect((w/'campaign.sqlite3').as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect((w/'codex_reviews.sqlite3').as_uri()+'?mode=ro',uri=True) as led:
 for (data,) in src.execute('select data from records where json_extract(data,?)=?',('$.user_id',uid)):
  x=json.loads(data)
  print(json.dumps({k:x.get(k) for k in ('id','user_id','author','text','reply_to_text','published_at','source_url')},ensure_ascii=False))
  for t in ('reviews','review_rechecks'):
   z=led.execute('select data from '+t+' where id=?',(x['id'],)).fetchone()
   if z:print(t,z[0])
