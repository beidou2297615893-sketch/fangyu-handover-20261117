"""保存Codex编写的7类统一回复。仅本地格式化，无平台操作。"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
templates=[
    ('软件开发', '我们做软件产品和定制开发，业务系统、App、网站方面的需求，可以联系我了解产品和方案。'),
    ('微信小程序', '我们有微信小程序产品，也提供定制开发。需要做小程序，可以联系我了解产品和方案。'),
    ('获客系统与CRM', '我们有获客软件和CRM客户管理系统。找客户、管理客户这类需求，可以联系我了解产品和方案。'),
    ('多平台发布', '我们有多平台作品发布软件。需要做多平台发布，可以联系我了解产品和方案。'),
    ('数字人与视频', '我们有数字人和视频制作相关产品，也提供定制服务。有这方面的需求，可以联系我了解产品和方案。'),
    ('AI自动化', '我们有AI自动化产品，也提供业务流程定制。有重复工作想做自动化，可以联系我了解产品和方案。'),
    ('需求未明确', '我们做软件、小程序、获客系统和AI相关产品，也提供定制服务。有这方面的需求，可以联系我了解产品和方案。'),
]
p=ROOT/'work/回复执行规则.json'
r=json.loads(p.read_text('utf-8'))
r['approval_reference']='2026-10-13本窗口最新要求：不要问，直接说我们有产品，以获客为目标、引导联系了解产品和方案；按不同产品意向统一回复，高到中等排序；等待用户开始'
r['product_claim_source']='用户明确要求以“我们有产品”介绍；未因此验证具体功能、现货、价格或交付期限'
r['display_labels']={'高意向':'高意向','待确认':'中等意向','排除':'排除'}
r['label_note']='中等意向是待确认的用户可见名称；不改原账本verdict、score与证据，不等同已确定购买'
r['reply_mode']='产品类别统一介绍对应产品和用途，引导联系了解产品和方案，不提问；高意向与中等意向使用同类别相同正文，意向程度影响优先顺序'
r['unified_templates']=[{'product':k,'reply':v,'status':'DRAFT','allowed_source_verdicts':['高意向','待确认']} for k,v in templates]
r['categories']=[]
r['intent_rules']=[{'intent':'高意向','action':'优先排队，使用对应产品统一话术'}, {'intent':'中等意向（原待确认）','action':'高意向之后排队，使用对应产品统一话术'}, {'intent':'排除或已解决、明确拒绝','action':'不纳入采购线索回复队列'}]
r['queue_order']=['高意向在前，中等意向在后','同档本人预算加紧急、本人预算、本人紧急、付费表达、分数依次优先','历史急需不认定当前仍急需；实际发送前核验最新原评论状态']
r['draft_checks']=[x for x in r['draft_checks'] if '大括号' not in x and '以意向目的和产品分类' not in x and '最多两个必要问题' not in x and '重复问已完整给出的规格' not in x]
r['draft_checks'] += ['7类统一正文由当前Codex编写，无占位符；不按关键词程序猜分类，沿用实际有效语义账本的产品类型','若统一正文与原评论明显不合适（如重复问已完整给出的规格、只是对视频作者索链接），该项暂不发送，不能冒充原作者或把他人产品当作我们的产品','对同UID的同一需求仅回复一次，若原评论已被本账号回复则跳过']
r['draft_checks']=[x for x in r['draft_checks'] if '重复问已完整给出的规格' not in x]
r['draft_checks']=list(dict.fromkeys(r['draft_checks']+['正文直接说明我们有对应产品；不提问、不要求补充需求，不额外编造具体功能、价格、效果或交期']))
r['coverage']={'product_categories':7,'unified_templates':7,'all_customers_individually_drafted':False}
r['supersedes']='outputs/评论回复规则与话术_20261013.md的21条分意向示例；最新以本7类统一话术为准'
p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=['# 产品分类统一回复（等待开始）','','用户最新要求：不要问，直接说我们有对应产品；同产品统一回复，高意向在前，中等意向在后。当前仅本地草稿，没有发送。','','中等意向是原“待确认”的显示名称：已分析，有询价、适配或实际需求信号，购买或委托仍需确认。原账本结论和分数保留。排除项不作为低意向机械群发。','','| 产品意向 | 统一回复正文 |','|---|---|']
lines += [f'| {k} | {v} |' for k,v in templates]
lines += ['', '同一产品的高意向和中等意向使用同一正文；意向程度决定先后顺序。同档保留本人预算、期限、付费表达及分数的优先级，不把历史急需当当前急需。', '', '发送等待用户在本窗口明确要求开始回复。开始回复不恢复采集。同一实际账号共用串行队列、互斥锁和发送回执账本，无论几个CLI都不能重复发。验证码未验证则一次留证后停止，不空转消耗。', '', '实际发送前核验原评论和本人账号；已经回复、明确拒绝、已解决、供应方或统一正文明显不适合的项暂不发送。产品能力、价格和交期未核验时不作承诺，不冒充视频作者，也不默认私信或附加联系方式。', '', '本文件取代同日早前21条分意向示例；这里只编写7类统一话术，尚未实现或验收发送器，也未逐条生成全部客户回复。', '']
out=ROOT/'outputs/产品分类统一回复_20261013.md'
out.write_text('\n'.join(lines),encoding='utf-8')
old=ROOT/'outputs/评论回复规则与话术_20261013.md'
text=old.read_text('utf-8')
notice='> 已被用户最新“同类产品统一回复”的要求替代。当前正文以《产品分类统一回复_20261013.md》为准；以下21条仅保留历史草稿。\n\n'
if notice not in text:old.write_text(notice+text,encoding='utf-8')
for name in ['AGENTS.md','README.md']:
    file=ROOT/name
    original=file.read_text('utf-8')
    entry='\n## 2026-10-13 最新话术：直接介绍产品，不提问\n来源：本窗口用户明确要求“不要问，直接说我们有产品就行，改一下”；approved_by: user。当前7类统一正文直接介绍我们有对应产品，不询问功能、预算或用途，也不要求对方补充需求。以用户对自有产品的声明为来源，不据此编造具体功能、价格、效果或交期。取代同日询问式统一话术，见outputs/产品分类统一回复_20261013.md与work/回复执行规则.json。待确认称中等意向，原账本证据不改；先高后中，同产品统一正文。仍等用户说开始才发送；同账号串行去重，采集暂停与STOP不变。\n'
    if entry not in original:file.write_text(original+entry,encoding='utf-8')
assert len(templates)==7 and len({k for k,v in templates})==7
assert all('{' not in v and '}' not in v for k,v in templates)
assert all('？' not in v and '?' not in v for k,v in templates)
assert r['sending_authorized_now'] is False and r['collection_remains_paused'] is True
print(json.dumps({'products':7,'status':r['status'],'file':str(out),'sent':0},ensure_ascii=False))
