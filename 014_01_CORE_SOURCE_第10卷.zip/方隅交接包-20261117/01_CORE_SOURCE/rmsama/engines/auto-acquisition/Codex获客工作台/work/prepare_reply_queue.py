"""从已人工复核的名单保存统一回复候选队列。只本地读写，不发送、不采集。"""
import collections
import hashlib
import json
import sqlite3
from pathlib import Path
from codex_review import effective_reviews

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'work'
OUT=ROOT/'outputs'
queue_path=WORK/'评论回复队列.json'
if queue_path.exists():
    raise SystemExit('现有回复队列必须先核对历史状态，不覆盖或重新发送')
stop=WORK/'STOP'
stop_hash=hashlib.sha256(stop.read_bytes()).hexdigest() if stop.exists() else None
rules_path=WORK/'回复执行规则.json'
rules=json.loads(rules_path.read_text('utf-8'))
snapshot=json.loads((WORK/'客户分类快照.json').read_text('utf-8'))
uri=(WORK/'codex_reviews.sqlite3').as_uri()+'?mode=ro'
with sqlite3.connect(uri,uri=True) as c:
    c.execute('pragma query_only=ON')
    reviews={x['id']:x for x in effective_reviews(c)}
counts=collections.Counter(x['verdict'] for x in reviews.values())
templates={x['product']:x['reply'] for x in rules['unified_templates']}
people=snapshot['customers']
assert len(people)==len({x['uid'] for x in people}), '客户总表同UID必须唯一'
for x in people:
    d=reviews[x['id']]
    assert d['verdict']==x['verdict'] and d['score']==x['score'], '导出快照必须与最新账本一致'
    assert x['verdict'] in ('高意向','待确认') and x['type'] in templates
def rank(x):
    return (x['verdict']=='高意向', bool(x['budget'] and x['urgent']), bool(x['budget']), bool(x['urgent']), bool(x['payment']), x['score'] or 0, x['published_at'] or 0)
items=[]
for position,x in enumerate(sorted(people,key=rank,reverse=True),1):
    reply=templates[x['type']]
    items.append(dict(position=position,status='WAITING_LOGIN',source_comment_id=x['id'],uid=x['uid'],author=x['author'],source_text=x['text'],source_url=x['url'],video_context=x['post_text'],reply_to=x['reply_to'],source_verdict=x['verdict'],intent=rules['display_labels'][x['verdict']],score=x['score'],product=x['type'],reason=x['reason'],budget=x['budget'],payment=x['payment'],urgent=x['urgent'],reply=reply,reply_sha256=hashlib.sha256(reply.encode()).hexdigest(),sending_account_id=None,platform_reply_id=None,receipt=None,live_source_verified=False))
summary=dict(authorization_date='2026-10-14',authorization='本窗口用户明确要求：大概说数量，然后开始发送；需要登录告知用户',status='WAITING_LOGIN',collected_comments=snapshot['stats']['collected'],analyzed_comments=len(reviews),effective_comment_verdicts=dict(counts),customer_total=len(items),high_customers=sum(x['intent']=='高意向' for x in items),medium_customers=sum(x['intent']=='中等意向' for x in items),sent_verified=0,eligible_live_verified=0,account_id=None,browser_id='2',tab_id='1',login_url='https://www.douyin.com/video/7676806387175598451',login_evidence='outputs/回复登录入口_20261014.png',collection_paused=True,collection_stop_preserved=True,notes='986是已分析的独立候选线索数，逐项在线核验后可能跳过已回复、删除或不适合的评论；没有发送动作或平台回执。')
(WORK/'评论回复队列.json').write_text(json.dumps(dict(summary=summary,items=items),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'评论回复进度.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rules.update(status='AUTHORIZED_WAITING_LOGIN',sending_authorized_now=True,authorization_date='2026-10-14',authorization_reference=summary['authorization'],scope='仅本实例本人抖音账号公开回复本地已复核线索；不私信、不恢复采集',queue_file='work/评论回复队列.json',current_blocker='当前浏览器抖音未登录；本人扫码后核验账号与原评论，才可发送')
rules_path.write_text(json.dumps(rules,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ('AGENTS.md','README.md'):
    p=ROOT/name
    entry='\n## 2026-10-14 用户已授权开始公开回复\n来源：本窗口用户明确要求“大概说数量，然后开始发送吧。要登录的话跟我讲”；approved_by: user。已授权按已认可7类统一获客话术，先高意向后中等意向回复本实例名单，不需再次要求开始确认。当前浏览器2/tab1抖音页面未登录，二维码已展示，等待本人登录后核验真实账号与原评论。work/评论回复队列.json保存986位独立候选（高201/中785），outputs/评论回复进度.json记录实际回执；当前已发送0。在线核验可能跳过删除、已回复或不适合项，不承诺986条必全部可发。同账号串行、UID去重、回执核验规则保持；不私信，不恢复采集或采集心跳，不删除用户STOP。没有核验发送链路前不得声称已回复。\n'
    text=p.read_text('utf-8')
    if entry not in text:p.write_text(text+entry,encoding='utf-8')
assert (hashlib.sha256(stop.read_bytes()).hexdigest() if stop.exists() else None)==stop_hash
print(json.dumps(summary,ensure_ascii=False))
