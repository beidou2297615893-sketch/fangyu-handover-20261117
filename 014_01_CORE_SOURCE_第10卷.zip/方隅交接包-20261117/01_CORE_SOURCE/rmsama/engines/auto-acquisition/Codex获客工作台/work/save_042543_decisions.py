import json
from pathlib import Path
rows=[
(1,'1为接单群回复互动，无本人软件采购需求。',''),
(2,'请求加入经验接单群，属于供应方找单入口，未委托软件或服务。',''),
(3,'1为接单群互动，无本人采购。',''),
(4,'求拉接单群，未表达购买相关软件或服务。',''),
(5,'11为群回复互动，无本人服务需求。',''),
(6,'滴滴为接单群互动，身份及具体需求不明，不能把被回复者经验或承诺转归本人。',''),
(7,'本人愿有偿加入接单群，付费对象是入群而非软件、CRM或视频服务采购，排除目标买家；不将吃饭承诺归给本人。','有偿'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence=p,urgent_evidence='') for i,r,p in rows]
assert [r['index'] for r in d]==list(range(1,8))
p=Path('work/review-batches/20261011_042543_147290_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
