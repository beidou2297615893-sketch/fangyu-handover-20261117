import json
from pathlib import Path
work=Path(__file__).resolve().parent
decision={'index':1,'verdict':'高意向','score':82,'reason':'本人向APP定制开发入口询问能否制作股票方面的APP，提出具体软件服务方向，属于寻找开发承接方的公开需求。已全文读取来源、近三个月日期及稳定UID99745163187，并查本地同人原文和账本：仅本条且未复核，无第三方需求转归。具体股票功能、合规使用场景和委托细节仍须本人确认；无预算、付款承诺或本人期限，不等于授权对外联系。','demand_type':'软件开发','demand_evidence':'你好能做股票方面的app吗','budget_evidence':'','payment_evidence':'','urgent_evidence':''}
(work/'review-batches/20261011_040655_471927_decisions.json').write_text(json.dumps({'reviewer':'Codex','decisions':[decision]},ensure_ascii=False,indent=2),'utf-8')
evidence_path=work/'恢复核验_20261011_0404.json'
evidence=json.loads(evidence_path.read_text('utf-8'))
evidence.update(recovery_verified_new_comments=True, verified_worker_pid=52896, verified_collected=14809, verified_recent=14410, verified_new_comment='7691123598254474003', verified_at='2026-10-11T04:06:42.674769+08:00')
evidence_path.write_text(json.dumps(evidence,ensure_ascii=False,indent=2),'utf-8')
