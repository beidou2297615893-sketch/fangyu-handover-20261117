"""Run the existing personal 19422 Bridge, preserving its configuration."""
import json
import os
import subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
CFG = BASE / '抖音自用采集台/data/bridge.json'
config = json.loads(CFG.read_text('utf-8-sig'))
assert config['bridge']['host'] == '127.0.0.1' and config['bridge']['port'] == 19422
assert config['bridge'].get('token')
runtime = BASE / 'work/runtime/douyin-bridge'
result = subprocess.run([str(runtime / 'node.exe'), str(runtime / 'server.js')],
                        cwd=runtime, env={**os.environ, 'DOUYIN_CONFIG': str(CFG)},
                        stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
raise SystemExit(result.returncode)
