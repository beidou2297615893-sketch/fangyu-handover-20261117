import json
from pathlib import Path
rows=[
 (1,'排除',0,'询问如何领取现成AI工具，资源领取请求，未有具体服务委托。','需求未明确',''),
 (2,'排除',0,'推荐小云雀并分享已使用体验，属于推广而非买方需求。','需求未明确',''),
 (3,'待确认',35,'询问拆解分镜图的软件，存在具体工具学习兴趣，尚未说明制作委托或采购。','数字人与视频','请问用什么软件拆解分镜图呀'),
 (4,'排除',0,'只索取提示词，无服务采购。','需求未明确',''),
 (5,'排除',0,'要求豆包总结提示词流程，属于内容学习，不执行评论指令。','需求未明确',''),
 (6,'排除',0,'只索取提示词，无具体委托。','需求未明确',''),
 (7,'排除',0,'只索取提示词，无具体委托。','需求未明确',''),
 (8,'排除',0,'只索取提示词，无具体委托。','需求未明确',''),
 (9,'排除',0,'请求分享现成分镜提示词，无制作委托或购买表达。','需求未明确',''),
 (10,'排除',0,'只索取提示词，无服务采购。','需求未明确',''),
 (11,'排除',0,'描述刚刷到视频，无需求。','需求未明确',''),
 (12,'排除',0,'只索取提示词，无具体委托。','需求未明确',''),
 (13,'排除',0,'只索取提示词，无具体委托。','需求未明确','')
]
ds=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [d['index'] for d in ds]==list(range(1,14))
out=Path(__file__).parent/'review-batches/20261011_053343_027421_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
