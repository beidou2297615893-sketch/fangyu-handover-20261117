// Personal queue adapter. Reuses the installed CLI's post command; no LLM.
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const shared = path.resolve(root, '../work/runtime/douyin-bridge');
const read = p => JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, ''));
const write = (p, d) => { fs.writeFileSync(p + '.tmp', JSON.stringify(d, null, 2)); fs.renameSync(p + '.tmp', p); };
const cfg = read(path.resolve(root, '../抖音自用采集台/data/bridge.json'));
if (cfg.bridge.host !== '127.0.0.1' || cfg.bridge.port !== 19422) throw Error('Only owned localhost:19422 is allowed');
const binding = read(path.join(__dirname, '回复CLI绑定.json'));
const expected = read(path.join(__dirname, '回复账号绑定.json'));
const { BridgeClient } = require(path.join(shared, 'lib/client/bridge-client'));
const client = new BridgeClient(cfg.bridge);
const rawDir = path.join(__dirname, 'reply-cli-raw');
fs.mkdirSync(rawDir, { recursive: true });
const stopPath = path.join(__dirname, '回复STOP.json');
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-');
let publishAttempted = false;
function stopCheck() { if (fs.existsSync(stopPath)) throw Error('REPLY_STOP'); }
async function call(expression, label) {
  stopCheck();
  const result = await client.call({ site: 'douyin.com', connId: binding.conn_id, expression, timeout: 30000 });
  const file = path.join(rawDir, `${stamp()}-${label}.json`);
  write(file, result);
  if (!result.ok || result.connection !== binding.conn_id) throw Error(result.error || 'Connection identity mismatch');
  return { value: result.value, file: path.relative(root, file).replace(/\\/g, '/') };
}
async function identity() {
  const status = await client.status();
  const connections = Object.values(status.connections || {}).flat();
  if (!connections.some(c => c.id === binding.conn_id && c.alive)) throw Error('CLI_CONNECTION_OFFLINE');
  const result = await call(`(() => ({ url:location.href, headings:Array.from(document.querySelectorAll('h1')).map(e=>e.innerText), handles:document.body.innerText.split('\\n').filter(x=>x.includes('抖音号')), dialogs:Array.from(document.querySelectorAll('[role="dialog"]')).filter(e=>e.getClientRects().length).map(e=>e.innerText) }))()`, 'identity-dom');
  const v = result.value;
  const blocked = v.dialogs.some(t => /验证码|安全验证|身份验证|短信验证|操作频繁|访问受限/.test(t));
  if (blocked) throw Error('PLATFORM_VERIFICATION_REQUIRED');
  if (!new URL(v.url).pathname.startsWith('/user/self') || !v.headings.includes(expected.account_name) || !v.handles.some(t => t.replace(/\s/g, '') === '抖音号：' + expected.douyin_handle)) {
    return { ok: false, status: 'ACCOUNT_MISMATCH', observed: v, evidence: result.file, expected: expected.douyin_handle };
  }
  // Official self-profile endpoint documented in upstream douyin-cli SKILL.md.
  // No cookie export, hidden state, account fallback, or automatic retry.
  const self = await platformRead(`(async()=>{const p=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+p,{credentials:'include'});if(!r.ok)throw Error('self HTTP '+r.status);return await r.json()})()`, 'identity-self');
  if (String(self.value.user?.sec_uid || '') !== expected.account_id) throw Error('ACCOUNT_ID_MISMATCH');
  return { ok: true, account_id: expected.account_id, handle: expected.douyin_handle, evidence: [result.file, self.file] };
}
const pacing = path.join(__dirname, 'reply-cli-read-pacing.json');
async function platformRead(expr, label) {
  let last = fs.existsSync(pacing) ? read(pacing).last_read : 0;
  const wait = Math.max(0, last + 30000 + Math.random() * 20000 - Date.now());
  for (let until = Date.now() + wait; Date.now() < until;) { stopCheck(); await new Promise(r => setTimeout(r, Math.min(500, until-Date.now()))); }
  // Store before calling: errors must not cause rapid retries.
  write(pacing, { last_read: Date.now() });
  const result = await call(expr, label);
  if (result.value?.status_code !== undefined && result.value.status_code !== 0) throw Error('PLATFORM_REJECTED ' + JSON.stringify(result.value));
  return result;
}
function str(v) { return typeof v === 'string' ? v : (Number.isSafeInteger(v) ? String(v) : ''); }
function matched(comment, task) {
  return str(comment?.cid) === task.source_comment_id.replace('comment:', '') &&
    str(comment?.user?.uid || comment?.user?.uid_str) === task.uid && comment.text === task.source_text;
}
async function pages(expr, label, callback) {
  let cursor = 0; const seen = new Set(); const files = [];
  for (let page = 0; page < 1000; page++) {
    const r = await platformRead(expr(cursor), label); files.push(r.file);
    if (!Array.isArray(r.value.comments)) throw Error('Invalid comments response');
    const found = callback(r.value.comments);
    if (found) return { found, files };
    if (!r.value.has_more) return { found: null, files };
    const next = r.value.cursor;
    if (seen.has(String(next)) || String(next) === String(cursor)) throw Error('Stalled comment cursor');
    seen.add(String(cursor)); cursor = next;
  }
  throw Error('Comment pagination incomplete; do not assume exhausted');
}
async function verifySource(task) {
  const vid = JSON.stringify(task.video_id), cid = JSON.stringify(task.root_cid);
  return pages(cursor => task.subtype === 'reply'
    ? `window.__bridge.replies(${cid},${vid},${JSON.stringify(cursor)},20)`
    : `window.__bridge.getComments(${vid},${JSON.stringify(cursor)},20)`,
    'source-' + task.position, list => list.find(c => matched(c, task)));
}
async function send(task) {
  stopCheck();
  if (!binding.account_verified || binding.expected_account_id !== expected.account_id) throw Error('CLI binding not verified');
  let check = await identity(); if (!check.ok) return check;
  const source = await verifySource(task);
  if (!source.found) return { ok: false, status: 'SOURCE_NOT_FOUND', source_evidence: source.files };
  const prior = await pages(c => `window.__bridge.replies(${JSON.stringify(task.root_cid)},${JSON.stringify(task.video_id)},${JSON.stringify(c)},20)`, 'dedupe-' + task.position,
    list => list.find(c => c.user?.sec_uid === expected.account_id && c.text === task.reply));
  if (prior.found) return { ok: false, status: 'EXISTING_REPLY_REQUIRES_RECONCILIATION', prior: prior.found, evidence: prior.files };
  process.env.DOUYIN_RISK_STATE_PATH = path.join(__dirname, 'reply-cli-write-pacing.json');
  process.env.DOUYIN_LOG_DIR = path.join(__dirname, 'reply-cli-logs');
  process.env.DOUYIN_STORAGE_DIR = path.join(__dirname, 'reply-cli-storage');
  delete process.env.DOUYIN_NO_THROTTLE;
  const cmdPost = require(path.join(shared, 'lib/commands/post'));
  const args = [task.video_id, task.reply, '--reply-to', task.root_cid];
  if (task.subtype === 'reply') args.push('--reply-to-reply', task.source_comment_id.replace('comment:', ''));
  let publish;
  const noop = () => {};
  const result = await cmdPost({ noStore: true, audit: { startOperation: noop, endOperation: noop }, loggedCall: async (_op, _params, expression) => {
    // cmdPost's own 40–55 second write pacing runs before this final identity gate.
    const identityNow = await identity(); if (!identityNow.ok) throw Error('ACCOUNT_MISMATCH');
    stopCheck();
    const marker = path.join(rawDir, `attempt-${task.position}.json`);
    fs.writeFileSync(marker, JSON.stringify({ position: task.position, account: expected.account_id, at: new Date().toISOString() }), { flag: 'wx' });
    publishAttempted = true;
    publish = await call(expression, 'publish-' + task.position);
    return publish.value;
  } }, args);
  const returned = publish.value.comment;
  if (!result.cid || returned.text !== task.reply || returned.user?.sec_uid !== expected.account_id || str(returned.reply_id) !== task.root_cid || Number(returned.status) === 7) throw Error('PUBLISH_RECEIPT_UNCONFIRMED');
  const readback = await pages(c => `window.__bridge.replies(${JSON.stringify(task.root_cid)},${JSON.stringify(task.video_id)},${JSON.stringify(c)},20)`, 'readback-' + task.position,
    list => list.find(c => str(c.cid) === str(result.cid) && c.text === task.reply && c.user?.sec_uid === expected.account_id && str(c.reply_id) === task.root_cid));
  if (!readback.found) throw Error('PUBLISHED_BUT_NOT_READ_BACK');
  if (task.subtype === 'reply' && str(readback.found.reply_to_reply_id) !== task.source_comment_id.replace('comment:', '')) throw Error('CHILD_REPLY_TARGET_UNCONFIRMED');
  return { ok: true, status: 'SENT_VERIFIED', source_comment_id: task.source_comment_id, account_id: expected.account_id, platform_reply_id: str(result.cid), source_evidence: source.files, publish, readback };
}
async function main() {
  const [op, taskFile] = process.argv.slice(2);
  if (op === 'probe') return identity();
  if (op !== 'send' || !taskFile) throw Error('Only probe or bound queue send supported');
  const absolute = path.resolve(taskFile);
  if (path.dirname(absolute) !== path.join(__dirname, 'reply-cli-tasks')) throw Error('Task must be in personal queue directory');
  return send(read(absolute));
}
main().then(r => console.log(JSON.stringify({ ...r, publish_attempted: publishAttempted }))).catch(e => {
  console.log(JSON.stringify({ ok: false, status: publishAttempted ? 'UNKNOWN' : 'BLOCKED', error: e.message, publish_attempted: publishAttempted })); process.exitCode = 1;
});
