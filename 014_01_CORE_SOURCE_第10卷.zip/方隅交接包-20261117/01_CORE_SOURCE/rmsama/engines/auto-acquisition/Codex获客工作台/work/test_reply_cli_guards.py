"""Offline guard checks. Never publishes and never edits the live receipt ledger."""
import contextlib
import io
import json
import msvcrt
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
from unittest.mock import patch
import reply_cli_worker as worker

def main():
    tasks = worker.prepare_tasks()
    counts = worker.counts(tasks)
    assert counts['total'] == 986 and counts['sent_verified'] == 1 and counts['pending'] == 985
    assert len({t['uid'] for t in tasks}) == len(tasks)
    assert tasks[0]['source_comment_id'] in worker.snapshot()
    child = next(t for t in tasks if t['position'] == 6)
    assert child['subtype'] == 'reply' and child['root_cid'] == '7679734420706542373'
    with tempfile.TemporaryDirectory(dir=worker.WORK, prefix='reply-guard-test-') as folder:
        p = Path(folder) / 'worker.lock'
        with patch.object(worker, 'LOCK', p):
            assert not worker.running()
            with p.open('a+b') as f:
                f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                assert worker.running()
                f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            assert not worker.running()
        # Start on wrong account must not launch a worker or reserve a recipient.
        with patch.object(worker, 'call_adapter', return_value={'ok':False,'status':'ACCOUNT_MISMATCH','publish_attempted':False}), \
             patch.object(worker, 'save') as save, patch.object(worker, 'progress') as progress, \
             patch('windows_independent.start_script') as launch, \
             patch.object(sys, 'argv', ['reply_cli_worker.py', '--start']), contextlib.redirect_stdout(io.StringIO()):
            worker.main()
            launch.assert_not_called()
            assert progress.call_args.args[0] == 'WAITING_CLI_ACCOUNT'
        # Duplicate reservation for SENT CID is refused by tracker without touching database.
        before = worker.snapshot()
        r = subprocess.run([sys.executable,'-X','utf8',str(worker.WORK/'track_reply.py'),'reserve','--position','1'],
                           cwd=worker.ROOT,capture_output=True,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
        assert r.returncode != 0 and worker.snapshot() == before
    result = {'offline_guards_passed': True, 'queue': counts,
              'checks':['986原文和UID匹配','7类话术及哈希一致','高意向先于中等意向','已成功首条跳过',
                        '楼中楼根CID映射','同账号锁互斥与释放','错误账号禁止启动','重复预留拒绝'],
              'platform_posts_in_tests':0,'live_sending_verified':False,
              'limitation':'尚待正确CLI账号登录后，验证发布与回读真实链路'}
    worker.save(worker.OUT/'回复CLI本地验收.json', result)
    print(json.dumps(result,ensure_ascii=False))

if __name__ == '__main__':
    main()
