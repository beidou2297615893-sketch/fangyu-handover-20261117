import json
from pathlib import Path
rows=[
(1,'待确认',40,'本人准备投流并关注AI获客效率和重复工作，存在相关兴趣，但未明确寻找系统或委托。','获客系统与CRM','投流这种方式我也准备在搞，但是我觉得肯定是不如你ai获客效率高的'),
(2,'排除',0,'主张投流精准，是获客观点，无本人服务采购。','需求未明确',''),
(3,'排除',0,'讨论行业投流成本和转化回本，未提出本人系统需求；每日1000和进线300是广告成本而非采购预算。','需求未明确',''),
(4,'待确认',35,'本人正在投流且指出重复工作，仍为自动化趋势讨论，未确认需委托或购买产品。','获客系统与CRM','我现在就在做投流，我知道精准，但是投流也是重复性工作'),
(5,'排除',0,'解释自然流观点，无本人采购。','需求未明确',''),
(6,'排除',0,'批评对需求方理解，不是本人需求。','需求未明确',''),
(7,'排除',0,'比较截流和投流ROI，未表达采购。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,8))
p=Path('work/review-batches/20261011_045143_006051_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
