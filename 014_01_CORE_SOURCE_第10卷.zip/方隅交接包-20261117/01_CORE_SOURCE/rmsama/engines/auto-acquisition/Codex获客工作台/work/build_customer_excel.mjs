import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const work=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(work,'../outputs');
const data=JSON.parse(await fs.readFile(path.join(work,'客户分类快照.json'),'utf8'));
const wb=Workbook.create();
const headers=['昵称','意向','需求类型','Codex分数','评论时间','原视频链接','评论原话','判断依据','类型依据','预算原话','付费表达','紧急原话','视频标题','帖子ID','用户ID','评论ID','采集时间','分析时间','主评论或回复','被回复原话','检索词','原视频地址','视频发布时间'];
const widths=[24,13,21,14,23,16,58,60,31,30,30,30,62,23,23,23,23,23,16,52,36,54,23];
const colors={'高意向':'#E7F4EC','待确认':'#FFF5DE','待分析':'#EDF1F7'};
const text=v=>typeof v==='string'&&/^[=+\-@]/.test(v)?"'"+v:v;
function date(v,epoch=false){
 if(!v)return null;
 // Excel stores wall time without a timezone: retain the source China date/time.
 const d=new Date(epoch?Number(v)*1000:v);return new Date(d.getTime()+8*3600*1000);
}
const title=x=>x.post_text.split('\n')[0].slice(0,80);
function values(x){return [x.author,x.verdict,x.type,x.score,date(x.published_at,true),'查看原视频',x.text,x.reason,x.type_basis,x.budget,x.payment,x.urgent,title(x),x.post_id,x.uid,x.id,date(x.collected_at),date(x.reviewed_at),x.subtype==='reply'?'楼中楼':'主评论',x.reply_to,x.keyword,x.url,date(x.post_date,true)].map(text);}
let tableid=0;
const previews=[];
function makeSheet(name,rows){
 const s=wb.worksheets.add(name);s.showGridLines=false;
 s.getRange('A2').values=[[name]];s.getRange('A2').format.font={name:'Arial',size:16,bold:true,color:'#23374D'};
 const countNote=name==='全部评论明细'?`${rows.length} 条评论`:`${rows.length} 位线索，其中高意向 ${rows.filter(x=>x.verdict==='高意向').length} 位`;
 s.getRange('A3').values=[[`更新：${data.updated.slice(0,19).replace('T',' ')}　${countNote}`]];
 s.getRange('A3').format.font={name:'Arial',size:10,color:'#677C91'};
 s.getRange('A4').values=[['产品人数见“产品分类汇总”，名单见各分类页；表头可筛选意向、类型、时间，“查看原视频”打开来源。']];
 s.getRange('A4').format.font={name:'Arial',size:10,color:'#677C91'};
 s.getRange('A5:W5').values=[headers];
 const bottom=Math.max(6,5+rows.length);
 if(rows.length)s.getRange(`A6:W${bottom}`).values=rows.map(values);
 s.getRange(`A5:W${bottom}`).format.font={name:'Arial',size:11,color:'#23374D'};
 s.getRange(`A5:W${bottom}`).format.verticalAlignment='top';
 s.getRange('A5:W5').format={fill:'#29496B',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},rowHeight:28,horizontalAlignment:'center',verticalAlignment:'center'};
 widths.forEach((n,i)=>s.getRangeByIndexes(4,i,bottom-4,1).format.columnWidth=n);
 s.getRange(`E6:E${bottom}`).setNumberFormat('yyyy-mm-dd hh:mm');
 s.getRange(`Q6:R${bottom}`).setNumberFormat('yyyy-mm-dd hh:mm');
 s.getRange(`W6:W${bottom}`).setNumberFormat('yyyy-mm-dd hh:mm');
 s.getRange(`D6:D${bottom}`).setNumberFormat('0');
 s.getRange(`N6:P${bottom}`).setNumberFormat('@');
 const table=s.tables.add(`A5:W${bottom}`,true,`Customers${++tableid}`);table.showFilterButton=true;
 s.freezePanes.freezeRows(5);s.freezePanes.freezeColumns(1);
 for(let i=0;i<rows.length;i++){
  const x=rows[i],r=i+6;
  s.getRange(`A${r}:W${r}`).format.rowHeight=Math.max(44,Math.min(300,18*Math.ceil(Math.max(x.text.length/29,x.reason.length/29,title(x).length/31,x.author.length/12,x.reply_to.length/25))+12));
  s.getRange(`A${r}`).format.wrapText=true;
  s.getRange(`G${r}:P${r}`).format.wrapText=true;s.getRange(`T${r}:V${r}`).format.wrapText=true;
  // Native hyperlinks are attached after export; the artifact engine does not
  // calculate HYPERLINK. Keep display text clean in both Excel and previews.
  s.getRange(`F${r}`).format.font={color:'#246EBC'};
 }
 for(const [label,fill] of Object.entries(colors))s.getRange(`B6:B${bottom}`).conditionalFormats.add('containsText',{text:label,format:{fill,font:{bold:true}}});
 if(!rows.length){s.getRange('A6').values=[['暂无已复核线索']];}
 previews.push(name);return s;
}
makeSheet('客户总表',data.customers).tabColor='#29496B';
for(const [name,rows] of Object.entries(data.types))makeSheet(name,rows);
makeSheet('全部评论明细',data.rows);
const posts=Array.from(new Map(data.rows.map(x=>[x.url,x])).values());
const p=wb.worksheets.add('视频帖子');p.showGridLines=false;
p.getRange('A2').values=[['视频帖子']];p.getRange('A2').format.font={name:'Arial',size:16,bold:true};
p.getRange('A3').values=[['客户表显示标题摘要；本表保留已取得的视频完整文案。']];
p.getRange('A5:D5').values=[['帖子ID','发布时间','完整视频文案','视频地址']];
p.getRange(`A6:D${5+posts.length}`).values=posts.map(x=>[x.post_id,date(x.post_date,true),text(x.post_text),x.url]);
p.getRange(`A5:D${5+posts.length}`).format.font={name:'Arial',size:11,color:'#23374D'};
p.getRange('A5:D5').format={fill:'#29496B',font:{bold:true,color:'#FFFFFF'},rowHeight:28};
[23,23,90,55].forEach((n,i)=>p.getRangeByIndexes(4,i,posts.length+1,1).format.columnWidth=n);
p.getRange(`B6:B${5+posts.length}`).setNumberFormat('yyyy-mm-dd hh:mm');
p.getRange(`A6:A${5+posts.length}`).setNumberFormat('@');
p.getRange(`C6:C${5+posts.length}`).format.wrapText=true;
posts.forEach((x,i)=>p.getRange(`A${i+6}:D${i+6}`).format.rowHeight=Math.max(44,Math.min(409,18*Math.ceil(x.post_text.length/44)+12)));
p.tables.add(`A5:D${5+posts.length}`,true,'VideoPosts').showFilterButton=true;p.freezePanes.freezeRows(5);
previews.push('视频帖子');
const q=wb.worksheets.add('搜索关键词');q.showGridLines=false;
q.getRange('A2').values=[['搜索关键词']];q.getRange('A2').format.font={name:'Arial',size:16,bold:true};
q.getRange('A3').values=[[`共 ${data.queries.length} 词，含多平台发布 120 词。仅在抖音寻找评论，不向任何平台发布作品。`]];
q.getRange('A5:D5').values=[['编号','检索类别','主题','搜索词']];
q.getRange(`A6:D${5+data.queries.length}`).values=data.queries.map(x=>[x.id,x.category,x.topic,x.query]);
q.getRange(`A5:D${5+data.queries.length}`).format.font={name:'Arial',size:11,color:'#23374D'};
q.getRange('A5:D5').format={fill:'#29496B',font:{bold:true,color:'#FFFFFF'},rowHeight:28};
[10,22,43,58].forEach((n,i)=>q.getRangeByIndexes(4,i,data.queries.length+1,1).format.columnWidth=n);
q.tables.add(`A5:D${5+data.queries.length}`,true,'SearchKeywords').showFilterButton=true;q.freezePanes.freezeRows(5);
previews.push('搜索关键词');
const summary=wb.worksheets.add('产品分类汇总');summary.showGridLines=false;
summary.tabColor='#29496B';
summary.getRange('A2').values=[['意向产品分类']];
summary.getRange('A2').format.font={name:'Arial',size:16,bold:true,color:'#23374D'};
summary.getRange('A3').values=[[`更新：${data.updated.slice(0,19).replace('T',' ')}　全部评论 ${data.rows.length} 条；客户总表去重 ${data.customers.length} 位`]];
summary.getRange('A4').values=[['各类别分别同人去重；同一人可有多种产品需求，分类人数不能相加当独立客户数。']];
summary.getRange('A3:E4').format.font={name:'Arial',size:10,color:'#677C91'};
summary.getRange('A5:E5').values=[['意向产品','高意向人数','待确认人数','类别内合计','产品范围 / 对应明细页']];
const descriptions={
 '软件开发':'APP、网站、ERP及业务管理系统等，详见“软件开发”页',
 '微信小程序':'商城、点单、预约及业务小程序等，详见“微信小程序”页',
 '获客系统与CRM':'找客、私域、客户跟进及CRM等，详见“获客系统与CRM”页',
 '多平台发布':'多平台分发、排期及矩阵账号工具等，详见“多平台发布”页',
 '数字人与视频':'数字人、AI视频、剪辑及相关工具等，详见“数字人与视频”页',
 'AI自动化':'AI客服、智能体及业务工作流等，详见“AI自动化”页',
 '需求未明确':'本人未说明具体产品；保留确认缺口，不按视频主题猜需求'
};
const summaryRows=Object.entries(data.types).map(([name,rows])=>[
 name,rows.filter(x=>x.verdict==='高意向').length,rows.filter(x=>x.verdict==='待确认').length,rows.length,descriptions[name]
]);
summary.getRange('A6:E12').values=summaryRows;
summary.getRange('A5:E12').format.font={name:'Arial',size:11,color:'#23374D'};
summary.getRange('A5:E5').format={fill:'#29496B',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},rowHeight:28};
[24,17,17,17,78].forEach((n,i)=>summary.getRangeByIndexes(4,i,8,1).format.columnWidth=n);
summary.getRange('A6:E12').format.rowHeight=44;
summary.getRange('E6:E12').format.wrapText=true;
summary.getRange('B6:D12').setNumberFormat('0');
summary.tables.add('A5:E12',true,'ProductIntentSummary').showFilterButton=true;
summary.freezePanes.freezeRows(5);
summary.getRange('A14:E14').values=[['客户总表独立人数',data.customers.filter(x=>x.verdict==='高意向').length,data.customers.filter(x=>x.verdict==='待确认').length,data.customers.length,'全类别同人合并，详见“客户总表”页']];
summary.getRange('A14:E14').format={fill:'#E7F4EC',font:{name:'Arial',size:11,bold:true,color:'#23374D'},rowHeight:44};
summary.getRange('E14').format.wrapText=true;
summary.getRange('A16').values=[['高意向和待确认分开筛选；每条评论的原话、判断依据、预算及期限保留在分类页和全部评论明细。']];
summary.getRange('A16').format.font={name:'Arial',size:10,color:'#677C91'};
previews.push('产品分类汇总');
wb.recalculate();
const inspect=await wb.inspect({kind:'table',range:'客户总表!A5:H9',include:'values,formulas',tableMaxRows:5,tableMaxCols:8,maxChars:1800});
console.log(inspect.ndjson);
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:10},maxChars:1200});
console.log(errors.ndjson);
if(process.argv.includes('--render'))for(const name of previews){
 const blob=await wb.render({sheetName:name,range:name==='搜索关键词'?'A1:D9':'A1:H9',scale:1.2,format:'png'});
 await fs.writeFile(path.join(work,`Excel预览_${name}.png`),new Uint8Array(await blob.arrayBuffer()));
}
if(process.argv.includes('--render-summary')){
 for(const [name,range,label] of [
  ['产品分类汇总','A1:E16','产品分类汇总_本轮'],
  ['客户总表','A1:H9','客户总表_本轮'],
  ['全部评论明细',`A${data.rows.length+3}:H${data.rows.length+5}`,'全部评论明细_本轮末尾']
 ]){
  const blob=await wb.render({sheetName:name,range,scale:1.2,format:'png'});
  await fs.writeFile(path.join(work,`Excel预览_${label}.png`),new Uint8Array(await blob.arrayBuffer()));
 }
}
const target=path.join(out,'客户分类清单.xlsx');
const temp=path.join(out,'客户分类清单.tmp.xlsx');
const file=await SpreadsheetFile.exportXlsx(wb);await file.save(temp);
try{await fs.rename(temp,target);}catch(e){if(e.code==='EPERM'||e.code==='EBUSY'){
 await fs.rename(temp,path.join(out,'客户分类清单_最新.xlsx'));console.log('主文件正打开，最新内容保存为客户分类清单_最新.xlsx');
}else throw e;}
await fs.writeFile(path.join(out,'Excel导出进度.json'),JSON.stringify({updated:data.updated,...data.stats,types:Object.fromEntries(Object.entries(data.types).map(([k,v])=>[k,v.length]))},null,2));
console.log(JSON.stringify({xlsx:target,sheets:previews.length,...data.stats}));
