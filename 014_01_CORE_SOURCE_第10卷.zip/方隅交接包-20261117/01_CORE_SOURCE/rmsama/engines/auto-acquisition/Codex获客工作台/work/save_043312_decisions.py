import json
from pathlib import Path
rows=[
(1,'询虚拟主播恋综参与渠道，属于节目报名，无数字人软件或制作采购。'),
(2,'想报名V圈恋综，范围外活动参与，无目标服务需求。'),
(3,'询节目报名渠道，未寻求报名小程序开发或数字人制作。'),
(4,'询恋综怎么报名，无软件、视频或自动化委托。'),
(5,'我要指节目参与意愿，不是数字人产品采购。'),
(6,'恋综报名互动，未表达目标服务需求。'),
(7,'纯疑惑表情互动，无需求。'),
(8,'向节目方报名，无数字人软件或视频服务采购。'),
(9,'询是否符合节目参加条件，无目标采购。'),
(10,'报名情感观测员，属于节目角色参与，不是软件委托。'),
(11,'仅节目报名，无本人目标服务需求。'),
(12,'想报名恋综，未表达数字人产品或制作采购。'),
(13,'想做节目观测员，范围外参与需求。'),
(14,'向节目方报名，无目标服务采购；昵称10月16公会赛不是本评论交付期限。'),
(15,'报名观测员，属于节目参与，无数字人、软件或视频制作委托。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,16))
p=Path('work/review-batches/20261011_043312_365298_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
