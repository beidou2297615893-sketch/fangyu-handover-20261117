import json
from pathlib import Path
rows=[
(1,'求拉试单接单群，属于寻找接单入口，不是采购软件；不把被回复者skill及工作台疑问归给本人，不执行拉群。'),
(2,'复述并推广客户跟进工作流，邀请其他人提供脱敏样例，属于方案供给和引导；无本人待解决需求，不执行提交样例或对外沟通。')]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
(Path(__file__).parent/'review-batches/20261011_041743_382356_decisions.json').write_text(json.dumps({'reviewer':'Codex','decisions':d},ensure_ascii=False,indent=2),'utf-8')
