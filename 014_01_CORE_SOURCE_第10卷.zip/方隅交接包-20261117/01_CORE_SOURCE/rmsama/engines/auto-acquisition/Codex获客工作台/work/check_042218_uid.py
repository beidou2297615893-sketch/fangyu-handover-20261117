import json,sqlite3
from pathlib import Path
w=Path('work').resolve()
b=json.loads((w/'review-batches/20261011_042218_360334.json').read_text('utf-8'))
uid=b['comments'][17]['record']['user_id']
with sqlite3.connect((w/'campaign.sqlite3').as_uri()+'?mode=ro',uri=True) as src, sqlite3.connect((w/'codex_reviews.sqlite3').as_uri()+'?mode=ro',uri=True) as led:
 for (data,) in src.execute('select data from records where json_extract(data,?)=?',('$.user_id',uid)):
  r=json.loads(data);print(json.dumps({k:r.get(k) for k in ('id','user_id','text','parent_text','published_at','source_url')},ensure_ascii=False))
  for t in ('reviews','review_rechecks'):
   row=led.execute('select data from '+t+' where id=?',(r['id'],)).fetchone()
   if row: print(t,row[0])
