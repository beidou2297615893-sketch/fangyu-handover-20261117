"""Save actual local counters; no comment classification or model calls."""
import json
import sys
from datetime import datetime
from pathlib import Path
from launch_comments import active
from launch_excel_export import locked

root=Path(__file__).resolve().parent.parent
work=root/'work'
out=root/'outputs'
base_reviewed,base_high,base_collected,base_recent=map(int,sys.argv[1:5])
load=lambda p:json.loads(p.read_text('utf-8'))
a=load(out/'Codex分析进度.json')
p=load(work/'评论任务进度.json')
r=load(out/'Codex待确认复审进度.json')
x=load(work/'Excel导出任务.json')
audit=load(out/'本轮增量复核验收.json')
stamp=datetime.now().astimezone()
report=dict(time=stamp.isoformat(),automation_id='automation-13',collector_running=active(),collector=p,analysis={k:a[k] for k in ['updated','last_review','reviewed','pending','high','warm','excluded']},baseline=dict(reviewed=base_reviewed,high=base_high,collected=base_collected,recent=base_recent),reviewed_this_heartbeat=a['reviewed']-base_reviewed,new_high_this_heartbeat=a['high']-base_high,historical_recheck=r,excel_running=locked(),excel_task=x,completed_excel_audit=audit,stop_marker_exists=(work/'STOP').exists(),browser_actions_this_heartbeat=False,review_method='当前Codex逐条全文show阅读并给出显式结论，保存脚本不分类、不调用模型')
for name in ['心跳巡检.json',f'心跳巡检_{stamp:%Y%m%d_%H%M%S}.json']:
    (work/name).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['time','collector_running','analysis','reviewed_this_heartbeat','new_high_this_heartbeat','excel_running','stop_marker_exists']},ensure_ascii=False))
