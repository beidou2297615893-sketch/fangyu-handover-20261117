import json
from pathlib import Path
rows=[
(1,'建议深耕市场数据好的产品，是业务观点，无本人服务采购。'),
(2,'鼓励作者，纯互动。'),
(3,'称赞复盘，纯互动。'),
(4,'评价AI与细分赛道深度，无本人需求。'),
(5,'询作者是否仍在做业务，无本人采购。'),
(6,'建议低成本验证商业模式，无本人预算或委托。'),
(7,'作者回顾过去想法，非需求方。'),
(8,'询作者过去所用年份和模型，只是经验核对，无本人AI业务或开发委托。'),
(9,'作者答复模型经历，非本人采购。'),
(10,'感慨基础建设和停业可惜，无服务需求。'),
(11,'感谢分享，纯互动。'),
(12,'质疑作者历史成本构成，不是本人采购预算或需求。'),
(13,'分析作者产品盈亏策略，是经营观点，无本人采购。'),
(14,'作者附和复盘，纯互动。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,15))
p=Path('work/review-batches/20261011_044820_814467_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
