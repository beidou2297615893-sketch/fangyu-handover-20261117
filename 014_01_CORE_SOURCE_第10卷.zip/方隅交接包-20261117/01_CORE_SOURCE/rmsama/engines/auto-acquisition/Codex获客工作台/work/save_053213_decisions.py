import json
from pathlib import Path
rows=[
 (1,'待确认',35,'询问可提供的小程序种类，有初步产品咨询，未说明本人具体功能或开发委托。','微信小程序','你们有那几类小程序'),
 (2,'排除',0,'供应商说明可定制开发，非买方需求。','需求未明确',''),
 (3,'待确认',25,'只说咨询一下，具体需求未明确，不从店铺昵称推断采购内容。','需求未明确','咨询一下'),
 (4,'排除',0,'作者应答咨询，非本人采购。','需求未明确',''),
 (5,'待确认',25,'仅表达咨询意愿，未给具体服务或功能需求。','需求未明确','咨询一下'),
 (6,'排除',0,'作者应答，没有买方需求。','需求未明确',''),
 (7,'待确认',25,'仅咨询，具体采购需求仍缺失，不将教程功能转归本人。','需求未明确','咨询一下'),
 (8,'排除',0,'作者应答，没有买方需求。','需求未明确',''),
 (9,'待确认',25,'仅表达咨询意愿，无法确定本人需要的功能或服务。','需求未明确','咨询一下'),
 (10,'待确认',25,'仅表达咨询意愿，不从昵称推断ETC相关小程序开发。','需求未明确','咨询一下'),
 (11,'排除',0,'感谢表情互动，没有本人需求。','需求未明确',''),
 (12,'排除',0,'在开发服务帖下表示接，属于供应商应征，无买方委托。','需求未明确','')
]
ds=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [d['index'] for d in ds]==list(range(1,13))
out=Path(__file__).parent/'review-batches/20261011_053213_084832_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=ds),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
