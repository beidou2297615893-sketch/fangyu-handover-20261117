"""Sequential read-only job; reuse installed dy CLI backend, preserve raw evidence."""
import argparse,csv,datetime,json,random,sqlite3,time,subprocess,msvcrt
from pathlib import Path
import control
from qualify import qualify
ROOT=control.ROOT;OUT=ROOT/'outputs';WORK=ROOT/'work'
class BridgeAdapter:
 def __init__(self):
  self.node=control.BASE/'work/runtime/douyin-bridge/node.exe'
  status=self.command(['status']);connections=status.get('connections',[]) if isinstance(status,dict) else status
  if isinstance(connections,dict):connections=[x for v in connections.values() for x in (v if isinstance(v,list) else [])]
  if not isinstance(connections,list):raise RuntimeError('抖音CLI连接状态字段变化')
  active=[x for x in connections if x.get('alive',True) and 'douyin.com/' in x.get('url','')]
  binding=WORK/'抖音连接绑定.json'
  if binding.exists():
   chosen=json.loads(binding.read_text('utf-8-sig'));active=[x for x in active if x.get('id')==chosen.get('connection_id') and x.get('url')==chosen.get('url')]
  if len(active)!=1:raise RuntimeError('抖音CLI需要明确绑定一个活跃抖音窗口，当前数量'+str(len(active)))
  self.conn=active[0]['id']
 def command(self,args):
  r=subprocess.run([str(self.node),str(WORK/'douyin_read.cjs')]+[str(x) for x in args],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  if r.returncode:raise RuntimeError('抖音CLI读取失败：'+r.stderr.strip()[:250])
  return json.loads(r.stdout)
 def search(self,keyword,sort_type=2,offset=0,count=20):return self.command(['search',self.conn,keyword,offset,count])
 def get_comments(self,video,cursor=0,count=20):return self.command(['comments',self.conn,video,cursor,count])
 def close(self):pass
def db():
 c=sqlite3.connect(WORK/'campaign.sqlite3');c.execute('pragma journal_mode=WAL')
 c.execute('create table if not exists records(id text primary key,user_id text,data text,score integer,tier text,urgent integer,budget integer)')
 c.execute('create table if not exists checkpoint(key text primary key,value text)');return c
def get(c,key,default):
 r=c.execute('select value from checkpoint where key=?',(key,)).fetchone();return json.loads(r[0]) if r else default
def put(c,key,value):c.execute('insert or replace into checkpoint values(?,?)',(key,json.dumps(value)));c.commit()
def save(c,item):
 if not item['source_id']:raise RuntimeError('缺少作品或评论ID，停止解析')
 q=qualify(item);item['qualification']=q
 c.execute('insert or ignore into records values(?,?,?,?,?,?,?)',(item['id'],item['user_id'],json.dumps(item,ensure_ascii=False),q['score'],q['tier'],q['urgent'],q['budget_ready']));c.commit()
def state(c,status):
 total=c.execute('select count(*) from records').fetchone()[0]
 unique=c.execute("select count(distinct user_id) from records where user_id!=''").fetchone()[0]
 high=c.execute("select count(distinct user_id) from records where tier='高意向'").fetchone()[0]
 urgent=c.execute("select count(distinct user_id) from records where tier='高意向' and urgent=1 and budget=1").fetchone()[0]
 s=control.read();s['status']=status;s['campaign'].update(collected=total,unique=unique,high=high,urgent=urgent,phase=status,query_done=get(c,'query_done',0));control.save(s);return total
def export(c):
 records=[json.loads(r[0]) for r in c.execute("select data from records order by (tier='高意向') desc,score desc")]
 with (OUT/'全部采集记录.jsonl').open('w',encoding='utf-8') as f:
  for x in records:f.write(json.dumps(x,ensure_ascii=False)+'\n')
 people={}
 for x in records:
  if x['user_id']:
   person=people.setdefault(x['user_id'],{'best':x,'evidence':[]});person['evidence'].append(x)
 high=[v for v in people.values() if v['best']['qualification']['tier']=='高意向'][:1000]
 (OUT/'高意向待复核.json').write_text(json.dumps(high,ensure_ascii=False,indent=2),'utf-8')
 with (OUT/'高意向待复核.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['用户ID','昵称','规则分','需求原话','预算原话','付费意愿原话','紧急原话','发表时间','原始来源','评论ID','人工复核'])
  for v in high:
   x=v['best'];q=x['qualification'];w.writerow([x['user_id'],x['author'],q['score'],x['text'],q['budget_evidence'],q.get('payment_evidence',''),q['urgent_evidence'],x['published_at'],x['source_url'],x['source_id'],'未复核'])
 s=control.read();s['leads']=[dict(id=v['best']['id'],author=v['best']['author'],platform='抖音',text=v['best']['text'],url=v['best']['source_url'],verdict='高意向待复核',score=v['best']['qualification']['score'],budget_evidence=v['best']['qualification']['budget_evidence'],payment_evidence=v['best']['qualification'].get('payment_evidence',''),urgent_evidence=v['best']['qualification']['urgent_evidence']) for v in high[:100]];control.save(s)
 return len(high)
def row(item,kind,vid,query):
 u=item.get('user',{}) if kind=='comment' else item.get('author',{});ident=str(item.get('cid','') if kind=='comment' else item.get('aweme_id',''))
 return dict(id=kind+':'+ident,source_id=ident,user_id=str(u.get('uid_str') or u.get('uid') or u.get('sec_uid') or ''),author=u.get('nickname',''),text=item.get('text','') if kind=='comment' else item.get('desc',''),published_at=item.get('create_time'),source_url='https://www.douyin.com/video/'+vid,category=query['category'],keyword=query['query'],kind=kind,collected_at=control.now())
def run(target,sample):
 # A process lock prevents two Codex commands collecting on the same account.
 with (WORK/'collector.lock').open('a+b') as lock:
  lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
  try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
  except OSError:raise RuntimeError('已有采集任务运行，不能重复启动')
  client=BridgeAdapter();c=db();calls=0
  plan=json.loads((OUT/'采集计划.json').read_text('utf-8'));all_queries=plan['queries']
  groups=list(dict.fromkeys(x['category'] for x in all_queries))
  # Rotate categories and purchasing language before deeper pagination.
  order=['找人做','急需开发','定制报价','哪里可以做','预算多少钱']
  queries=sorted(all_queries,key=lambda x:(next(i for i,v in enumerate(order) if x['query'].endswith(v)),(int(x['id'])-1)%5,groups.index(x['category'])))
  if sample:queries=[next(x for x in queries if x['category']==g) for g in ['微信小程序','客户管理']]
  class SampleComplete(Exception):pass
  def total():return c.execute('select count(*) from records').fetchone()[0]
  def refresh(message):
   done=c.execute("select count(*) from checkpoint where key like 'breadth_done:%'").fetchone()[0]
   put(c,'query_done',done);export(c);state(c,message)
  def reached():
   if total()<target:return False
   refresh('小样完成，待质量核验' if sample else '本阶段完成，待逐条复核');return True
  def call(kind,key,fn):
   nonlocal calls
   if (WORK/'STOP').exists():raise RuntimeError('已停止，断点保留')
   if sample and calls>=4:raise SampleComplete()
   wait=max(0,float(get(c,'last_read',0))+random.uniform(30,50)-time.time())
   deadline=time.monotonic()+wait
   while time.monotonic()<deadline:
    if (WORK/'STOP').exists():raise RuntimeError('已停止，断点保留')
    time.sleep(min(1,max(0,deadline-time.monotonic())))
   put(c,'last_read',time.time());p=fn();calls+=1
   raw=WORK/'raw-campaign';raw.mkdir(exist_ok=True)
   (raw/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+kind+'.json')).write_text(json.dumps(dict(source=key,collected_at=control.now(),payload=p),ensure_ascii=False),'utf-8')
   if not isinstance(p,dict) or p.get('status_code',0)!=0:raise RuntimeError('平台或接口失败，停止采集')
   if p.get('search_nil_info',{}).get('search_nil_type')=='verify_check':raise RuntimeError('平台要求验证码，已停止')
   return p
  def comments(query,video):
   vid=video['id'];cursor=get(c,'cursor:'+vid,0)
   if get(c,'video_done:'+vid,False):return
   p=call('comments',vid,lambda:client.get_comments(vid,cursor=cursor,count=20))
   if not isinstance(p.get('comments'),list):raise RuntimeError('评论结构变化，停止解析')
   for item in p['comments']:
    x=row(item,'comment',vid,query);x['parent_text']=video.get('text','');save(c,x)
   nxt=int(p.get('cursor',cursor+20))
   if p.get('has_more') and p['comments'] and nxt<=cursor:raise RuntimeError('评论游标未前进，停止重复读取')
   put(c,'cursor:'+vid,nxt)
   if not p.get('has_more') or not p['comments']:put(c,'video_done:'+vid,True)
   refresh('小批验证中' if sample else '采集中 · 轮换需求类别')
  try:
   refresh('小批跨类别验证中' if sample else '采集中 · 先1000条')
   if reached():return
   for query in queries:
    key=str(query['id'])
    if get(c,'breadth_done:'+key,False):continue
    videos=get(c,'breadth_videos:'+key,None)
    if videos is None:
     p=call('search',query['query'],lambda:client.search(query['query'],count=20))
     if not isinstance(p.get('data'),list):raise RuntimeError('搜索结构变化，停止解析')
     items=[x['aweme_info'] for x in p['data'] if isinstance(x,dict) and isinstance(x.get('aweme_info'),dict)]
     videos=[]
     for video in items:
      vid=str(video.get('aweme_id',''))
      if not vid:raise RuntimeError('搜索作品缺少ID，停止解析')
      save(c,row(video,'note',vid,query));videos.append(dict(id=vid,text=video.get('desc','')))
     put(c,'breadth_videos:'+key,videos[:2 if not sample else 1]);videos=videos[:2 if not sample else 1]
     refresh('小批验证中' if sample else '采集中 · 轮换需求类别')
     if reached():return
    for video in videos:
     # Earlier sample pages are already preserved; never refetch the same page.
     if not get(c,'cursor:'+video['id'],0):comments(query,video)
     if reached():return
    if not sample:put(c,'breadth_done:'+key,True)
   if sample:refresh('跨类别小样完成，待质量核验');return
   # After all categories/queries, deepen comment pages in rounds, at most 5.
   for depth in range(1,5):
    for query in queries:
     for video in get(c,'breadth_videos:'+str(query['id']),[]):
      if get(c,'cursor:'+video['id'],0)>=100:continue
      comments(query,video)
      if reached():return
   refresh('本轮检索完成；实际数量未必达到目标')
  except SampleComplete:refresh('跨类别小样已读取，待质量核验')
  except Exception:export(c);raise
  finally:client.close();c.close()
def main():
 p=argparse.ArgumentParser();p.add_argument('--target',type=int,default=60);p.add_argument('--sample',action='store_true');p.add_argument('--export',action='store_true');a=p.parse_args()
 try:
  if not 1<=a.target<=20000:raise ValueError('目标必须在1—20000条')
  if a.export:
   c=db();print('高意向待复核人数',export(c));c.close();return 0
  run(a.target,a.sample)
 except Exception as e:
  c=db();state(c,str(e));export(c);c.close();print(str(e));return 1
 return 0
if __name__=='__main__':
 from comment_job import main as comment_main
 raise SystemExit(comment_main())
