"""Prepare immutable local evidence batches for Codex; persist Codex decisions.

This script never calls a model, never reads the platform, and never changes the
collector database. Semantic decisions must be supplied by the Codex conversation.
"""
import argparse, csv, datetime, hashlib, json, sqlite3
from pathlib import Path
from qualify import is_recent

ROOT = Path(__file__).resolve().parents[1]
WORK, OUT = ROOT / 'work', ROOT / 'outputs'
METHOD = 'Codex读取完整评论及已有上下文，按十层规则判断；脚本只负责保存与汇总'

def now():
    return datetime.datetime.now().astimezone().isoformat()

def write(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), 'utf-8')
    tmp.replace(path)

def digest(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

def source():
    c = sqlite3.connect((WORK / 'campaign.sqlite3').as_uri() + '?mode=ro', uri=True, timeout=10)
    c.execute('pragma query_only=ON')
    return c

def ledger():
    c = sqlite3.connect(WORK / 'codex_reviews.sqlite3', timeout=10)
    c.execute('pragma journal_mode=WAL')
    c.execute('create table if not exists reviews(id text primary key, batch text, data text)')
    c.execute('create table if not exists review_rechecks(id text primary key, batch text, data text)')
    c.execute('create table if not exists review_fullpasses(pass_id text, id text, batch text, data text, primary key(pass_id,id))')
    return c

def effective_reviews(c):
    """Latest explicit Codex recheck overlays, without changing original reviews."""
    reviews = {x['id']: x for x in (json.loads(r[0]) for r in c.execute('select data from reviews'))}
    exists = c.execute("select 1 from sqlite_master where type='table' and name='review_rechecks'").fetchone()
    if exists:
        for data, in c.execute('select data from review_rechecks'):
            d = json.loads(data)
            if d['id'] not in reviews:
                raise ValueError('复审缺少原复核记录')
            reviews[d['id']] = d
    exists = c.execute("select 1 from sqlite_master where type='table' and name='review_fullpasses'").fetchone()
    if exists:
        for data, in c.execute('select data from review_fullpasses order by pass_id,rowid'):
            d = json.loads(data)
            if d['id'] not in reviews:
                raise ValueError('全量复审缺少原复核记录')
            reviews[d['id']] = d
    return list(reviews.values())

def prepare_fullpass(limit):
    manifest_path = WORK / '全量逐条复审队列_20261012.json'
    with source() as c, ledger() as l:
        previous = {d['id']:d for d in effective_reviews(l)}
        records = {i:json.loads(d) for i,d in c.execute("select id,data from records where id like 'comment:%' order by rowid")}
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text('utf-8'))
        else:
            baseline = {table:list(l.execute(f'select id,data from {table} order by id')) for table in ('reviews','review_rechecks')}
            manifest = dict(pass_id='20261012_all_comments', created_at=now(), authorization='2026-10-12用户要求全部已采集评论重新逐条分析一遍后汇报', ids=list(records), source_hashes={i:digest(r) for i,r in records.items()}, baseline=baseline)
            write(manifest_path, manifest)
        done = {r[0] for r in l.execute('select id from review_fullpasses where pass_id=?', (manifest['pass_id'],))}
        batch = []
        for ident in manifest['ids']:
            if ident in done:
                continue
            x = records[ident]
            if digest(x) != manifest['source_hashes'][ident]:
                raise ValueError('全量复审原始评论变化，停止并保留证据')
            vid = x['source_url'].rsplit('/',1)[-1]
            v = c.execute('select data from video_queue where vid=?',(vid,)).fetchone()
            context = json.loads(v[0]).get('text','') if v else x.get('parent_text','')
            batch.append(dict(index=len(batch)+1, record=x, video_context=context, source_hash=digest(x), previous_review=previous[ident]))
            if len(batch) >= limit:
                break
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    path = WORK / 'review-batches' / (stamp + '_fullpass.json')
    write(path, dict(created_at=now(), kind='fullpass', pass_id=manifest['pass_id'], method=METHOD, comments=batch))
    refresh()
    print(json.dumps(dict(batch=str(path), count=len(batch), total=len(manifest['ids']), completed=len(done)),ensure_ascii=False))

def prepare_recheck(limit):
    manifest_path = WORK / '待确认复审队列.json'
    with ledger() as l:
        originals = {x['id']: x for x in (json.loads(r[0]) for r in l.execute('select data from reviews'))}
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text('utf-8'))
        else:
            targets = [d for d in originals.values() if d['verdict'] == '待确认']
            targets.sort(key=lambda d: (d.get('demand_type') not in (None, '需求未明确'), -d['score'], d['reviewed_at']))
            manifest = dict(created_at=now(), authorization='2026-10-08用户要求逐条分析大量待确认且需求未明确记录', ids=[d['id'] for d in targets])
            write(manifest_path, manifest)
        done = {r[0] for r in l.execute('select id from review_rechecks')}
        batch = []
        for ident in manifest['ids']:
            if ident in done:
                continue
            d = originals[ident]; x = d['record']
            batch.append(dict(index=len(batch)+1, record=x, video_context=d['video_context'], source_hash=digest(x), previous_review=d))
            if len(batch) >= limit:
                break
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    path = WORK / 'review-batches' / (stamp + '_recheck.json')
    write(path, dict(created_at=now(), kind='recheck', method=METHOD, comments=batch))
    refresh()
    print(json.dumps(dict(batch=str(path), count=len(batch), recheck_total=len(manifest['ids']), recheck_completed=len(done)), ensure_ascii=False))

def prepare(limit, all_comments=False):
    with source() as c, ledger() as l:
        reviewed = {x[0] for x in l.execute('select id from reviews')}
        batch = []
        query = "select r.data from records r join comment_index i on i.id=r.id"
        if not all_comments:
            query += " where i.recent=1"
        query += " order by r.rowid"
        for data, in c.execute(query):
            x = json.loads(data)
            if x['id'] in reviewed:
                continue
            vid = x['source_url'].rsplit('/', 1)[-1]
            v = c.execute('select data from video_queue where vid=?', (vid,)).fetchone()
            context = json.loads(v[0]).get('text', '') if v else x.get('parent_text', '')
            batch.append(dict(index=len(batch) + 1, record=x, video_context=context, source_hash=digest(x)))
            if len(batch) >= limit:
                break
    folder = WORK / 'review-batches'
    folder.mkdir(exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    path = folder / (stamp + '.json')
    write(path, dict(created_at=now(), method=METHOD, comments=batch))
    refresh()
    print(json.dumps(dict(batch=str(path), count=len(batch)), ensure_ascii=False))

def show(path, start=1, end=None):
    batch = json.loads(Path(path).read_text('utf-8'))
    contexts = {}
    authors = {}
    compact = batch.get('kind') == 'fullpass'
    if compact:
        print('完整字段顺序：[index,视频上下文编号,作者编号,北京时间,评论全文,被回复原文全文]；视频和作者表仅去重展示，不删减正文。')
    for item in batch['comments']:
        if item['index'] < start or (end is not None and item['index'] > end):
            continue
        x = item['record']; url = x['source_url']
        if url not in contexts:
            contexts[url] = len(contexts) + 1
            print(json.dumps(dict(context=contexts[url], video=url, text=item['video_context']), ensure_ascii=False))
        if compact:
            key = (x['user_id'], x['author'])
            if key not in authors:
                authors[key] = len(authors) + 1
                print(json.dumps(dict(user=authors[key], uid=x['user_id'], author=x['author']),ensure_ascii=False))
            date = datetime.datetime.fromtimestamp(x['published_at'],datetime.timezone(datetime.timedelta(hours=8))).isoformat() if x['published_at'] else None
            print(json.dumps([item['index'],contexts[url],authors[key],date,x['text'],x.get('reply_to_text','')],ensure_ascii=False))
        else:
            print(json.dumps(dict(n=item['index'], context=contexts[url], author=x['author'], uid=x['user_id'], text=x['text'], reply_to=x.get('reply_to_text', ''), date=x['published_at']), ensure_ascii=False))

def commit(batch_path, decisions_path, dry_run=False):
    batch = json.loads(Path(batch_path).read_text('utf-8'))
    decisions = json.loads(Path(decisions_path).read_text('utf-8'))['decisions']
    items = {x['index']: x for x in batch['comments']}
    if len(decisions) != len(items) or {x['index'] for x in decisions} != set(items):
        raise ValueError('每条评论必须恰好有一条Codex结论，禁止静默漏评')
    values = []
    with source() as c:
        originals={ident:digest(json.loads(data)) for ident,data in c.execute("select id,data from records where id like 'comment:%'")}
    for decision in decisions:
        item = items[decision['index']]; x = item['record']; d = dict(decision)
        if digest(x)!=item['source_hash'] or originals.get(x['id'])!=item['source_hash']:
            raise ValueError('批次与原始数据库证据不一致，未写入复核结果')
        if d['verdict'] not in ('高意向', '待确认', '排除') or not d.get('reason'):
            raise ValueError('缺少有效结论或原因')
        for key in ('demand_evidence', 'budget_evidence', 'payment_evidence', 'urgent_evidence'):
            d.setdefault(key, '')
            if d[key] and d[key] not in x['text']:
                raise ValueError('需求、预算、付费及紧急证据必须来自评论者本人原话')
        if d['verdict'] == '高意向' and (d.get('score',0)<80 or not d['demand_evidence'] or not x['user_id'] or not is_recent(x.get('published_at'))):
            raise ValueError('高意向缺少本人需求、日期或用户ID')
        if not 0 <= d.get('score', 0) <= 100:
            raise ValueError('无效评分')
        d.update(id=x['id'], source_hash=item['source_hash'], reviewed_at=now(), reviewer='Codex', method=METHOD,
                 record=x, video_context=item['video_context'], purchase_status='是否仍在采购、是否成交和付款能力尚未核实')
        if batch.get('kind') == 'recheck':
            prior = item['previous_review']
            d.update(recheck_of=prior['reviewed_at'], previous_verdict=prior['verdict'], previous_reason=prior['reason'], recheck_authorization='2026-10-08用户要求重新逐条判断待确认与需求未明确')
        if batch.get('kind') == 'fullpass':
            prior = item['previous_review']
            d.update(fullpass_id=batch['pass_id'], recheck_of=prior['reviewed_at'], previous_verdict=prior['verdict'], previous_reason=prior['reason'], recheck_authorization='2026-10-12用户要求全部已采集评论重新逐条分析一遍')
        values.append((x['id'], str(batch_path), json.dumps(d, ensure_ascii=False)))
    if dry_run:
        print(json.dumps(dict(validated=len(values),written=0),ensure_ascii=False))
        return
    with ledger() as l:
        if batch.get('kind') == 'fullpass':
            current = {d['id']:d for d in effective_reviews(l)}
            for item in batch['comments']:
                if current[item['record']['id']] != item['previous_review']:
                    raise ValueError('此前结论已变化，拒绝全量复审覆盖')
            l.executemany('insert into review_fullpasses values(?,?,?,?)', [(batch['pass_id'],*v) for v in values])
        elif batch.get('kind') == 'recheck':
            for item in batch['comments']:
                prior = l.execute('select data from reviews where id=?', (item['record']['id'],)).fetchone()
                if prior is None or json.loads(prior[0]) != item['previous_review']:
                    raise ValueError('原结论已变化，拒绝复审覆盖')
            l.executemany('insert into review_rechecks values(?,?,?)', values)
        else:
            l.executemany('insert into reviews values(?,?,?)', values)
    refresh()
    print(json.dumps(dict(saved=len(values), status='Codex结论已逐条保存'), ensure_ascii=False))

def refresh():
    with ledger() as l, source() as c:
        reviews = effective_reviews(l)
        rechecks = [json.loads(x[0]) for x in l.execute('select data from review_rechecks')]
        fullreviews = [json.loads(x[0]) for x in l.execute('select data from review_fullpasses order by pass_id,rowid')]
        recent = c.execute('select count(*) from comment_index where recent=1').fetchone()[0]
        recent_ids={x[0] for x in c.execute('select id from comment_index where recent=1')}
    highs = [x for x in reviews if x['verdict'] == '高意向' and is_recent(x['record'].get('published_at'))]
    highs.sort(key=lambda x: (bool(x['budget_evidence'] and x['urgent_evidence']), bool(x['budget_evidence']), bool(x['urgent_evidence']), bool(x['payment_evidence']), x['score'], x['record']['published_at']), reverse=True)
    people = {}
    for x in highs:
        uid = x['record']['user_id']
        if uid not in people:
            people[uid] = dict(best=x, evidence=[])
        people[uid]['evidence'].append(x)
    selected = list(people.values())[:1000]
    leads = []
    for person in selected[:100]:
        d = person['best']; x = d['record']
        leads.append(dict(id=x['id'], author=x['author'], text=x['text'], url=x['source_url'], score=d['score'], verdict='Codex复核：高意向线索', reason=d['reason'], budget_evidence=d['budget_evidence'], payment_evidence=d['payment_evidence'], urgent_evidence=d['urgent_evidence']))
    status = dict(updated=now(), last_review=max((x['reviewed_at'] for x in reviews), default=None), reviewed=len(reviews), pending=len(recent_ids-{x['id'] for x in reviews}), high=len(people), warm=sum(x['verdict']=='待确认' for x in reviews), excluded=sum(x['verdict']=='排除' for x in reviews), urgent=sum(bool(v['best']['budget_evidence'] and v['best']['urgent_evidence']) for v in selected), method=METHOD, leads=leads)
    write(OUT / 'Codex分析进度.json', status)
    full_manifest_path = WORK / '全量逐条复审队列_20261012.json'
    if full_manifest_path.exists():
        manifest = json.loads(full_manifest_path.read_text('utf-8'))
        current_full = [d for d in fullreviews if d['fullpass_id']==manifest['pass_id']]
        completed = {d['id'] for d in current_full}
        write(OUT / 'Codex全量逐条复审进度_20261012.json', dict(updated=now(), pass_id=manifest['pass_id'], total=len(manifest['ids']), completed=len(completed), pending=len(set(manifest['ids'])-completed), high=sum(d['verdict']=='高意向' for d in current_full), warm=sum(d['verdict']=='待确认' for d in current_full), excluded=sum(d['verdict']=='排除' for d in current_full), method=METHOD, original_and_historical_reviews_preserved=True, collection_paused=True))
        p = OUT / 'Codex全量逐条复审_20261012.jsonl'
        tmp = p.with_suffix('.jsonl.tmp')
        with tmp.open('w',encoding='utf-8') as f:
            for d in current_full:
                f.write(json.dumps(d,ensure_ascii=False)+'\n')
        tmp.replace(p)
    manifest_path = WORK / '待确认复审队列.json'
    if manifest_path.exists():
        targets = json.loads(manifest_path.read_text('utf-8'))['ids']
        done = {d['id'] for d in rechecks}
        write(OUT / 'Codex待确认复审进度.json', dict(updated=now(), total=len(targets), completed=len(done.intersection(targets)), pending=len(set(targets)-done), high=sum(d['verdict']=='高意向' for d in rechecks), warm=sum(d['verdict']=='待确认' for d in rechecks), excluded=sum(d['verdict']=='排除' for d in rechecks), method=METHOD, original_reviews_preserved=True))
    p = OUT / 'Codex待确认逐条复审.jsonl'
    tmp = p.with_suffix('.jsonl.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        for d in rechecks:
            f.write(json.dumps(d, ensure_ascii=False)+'\n')
    tmp.replace(p)
    write(OUT / 'Codex已复核客户.json', selected)
    write(OUT / 'Codex待确认线索.json', [x for x in reviews if x['verdict']=='待确认'])
    with (OUT / 'Codex已复核客户.csv').open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.writer(f);w.writerow(['用户ID','昵称','Codex评分','需求原话','判断依据','预算原话','付费原话','紧急原话','发表时间','来源','评论ID','复核时间','采购状态'])
        for person in selected:
            d=person['best'];x=d['record']
            w.writerow([x['user_id'],x['author'],d['score'],x['text'],d['reason'],d['budget_evidence'],d['payment_evidence'],d['urgent_evidence'],x['published_at'],x['source_url'],x['source_id'],d['reviewed_at'],d['purchase_status']])
    p=OUT/'Codex逐条分析.jsonl';tmp=p.with_suffix('.jsonl.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        for x in reviews:f.write(json.dumps(x,ensure_ascii=False)+'\n')
    tmp.replace(p)

if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--all-comments',action='store_true');p.add_argument('--prepare-recheck',action='store_true');p.add_argument('--prepare-fullpass',action='store_true');p.add_argument('--limit',type=int,default=200);p.add_argument('--show');p.add_argument('--start',type=int,default=1);p.add_argument('--end',type=int);p.add_argument('--commit');p.add_argument('--decisions');p.add_argument('--refresh',action='store_true');p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    if a.prepare_fullpass:prepare_fullpass(min(300,max(1,a.limit)))
    elif a.prepare_recheck:prepare_recheck(min(300,max(1,a.limit)))
    elif a.prepare:prepare(min(300,max(1,a.limit)),a.all_comments)
    elif a.show:show(a.show,a.start,a.end)
    elif a.commit:commit(a.commit,a.decisions,a.dry_run)
    elif a.refresh:refresh()
