import json
from pathlib import Path
rows=[
(1,'评价视频用词，无本人软件服务需求。'),
(2,'寻求博主对自身行为的认可，行为不明，无软件需求证据。'),
(3,'称赞高中生视频，无本人制作委托。'),
(4,'讨论自媒体广告收入模式，无本人采购需求。'),
(5,'询两个账号是否同人，无本人多平台发布需求。'),
(6,'询小粉丝账号收到收益原因，无软件服务需求。'),
(7,'倡议观看并评价博主收益，20块是他人收益不能当本人预算。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,8))
p=Path('work/review-batches/20261011_050440_123814_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
