import json
from pathlib import Path
import control
p=control.ROOT/'outputs/CLI完整盘点.json';d=json.loads(p.read_text('utf-8'))
runtime=Path('C:/Users/rmsama/.opencli/node_modules/@jackwener/opencli')
if runtime.exists() and not any(x['path']==str(runtime) for x in d['items']):
 d['items'].append(dict(name='OpenCLI 用户运行时',path=str(runtime),kind='帮助/doctor 已核验 · 浏览器扩展未连接',source='https://github.com/jackwener/opencli',version='1.8.8'))
for x in d['items']:
 if x['path']==str(control.XHS):x.update(kind='搜索帮助已核验 · 当前未登录',version='0.6.4',source='https://github.com/jackwener/xiaohongshu-cli')
 if x['path']==str(control.DY):x.update(kind='帮助已核验 · 当前未登录',version='0.2.2',source='https://github.com/Youhai020616/douyin')
 if x['name']=='.opencli':x['kind']='用户 OpenCLI 配置/运行目录'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8')
md=['# 本机 CLI 完整盘点','',f"发现 {len(d['items'])} 个入口、源码、下载包及副本，不等于同数量独立工具。",'扫描根目录：'+ '、'.join(d['roots']),'排除目录：'+ '、'.join(d['excluded']),f"受保护目录等读取错误：{len(d['errors'])} 个，详见 JSON。没有宣称排除目录全部扫描。",'']
for x in d['items']:md += ['- '+x['name']+' · '+x['kind'],'  '+x['path']]
(p.parent/'CLI完整盘点.md').write_text('\n'.join(md),'utf-8')
s=control.read();s['platforms'].append(dict(name='OpenCLI（备用入口）',status='服务可运行 · 浏览器扩展未连接')) if not any(x['name'].startswith('OpenCLI') for x in s['platforms']) else None
control.event(s,'CLI 盘点完成：'+str(len(d['items']))+' 个入口与副本；OpenCLI 连接检查未通过，未开启采集')
control.save(s)
print('盘点已更新：'+str(len(d['items']))+' 条；未复制账号数据')
