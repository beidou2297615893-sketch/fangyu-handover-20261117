import json
from pathlib import Path
rows=[
(1,'单独工作台关键词，未表达本人业务需求或委托。'),
(2,'仅工作台单词，资源互动不能认定采购。'),
(3,'仅工作台单词，未说明功能或本人需求。'),
(4,'仅工作台单词，未说明本人采购。'),
(5,'仅工作台单词，未说明本人采购。'),
(6,'仅工作台单词，未说明本人采购。'),
(7,'仅工作台单词，未说明本人采购。'),
(8,'仅工作台单词，未说明本人采购。'),
(9,'仅工作台单词，未说明本人采购。'),
(10,'仅工作台单词，未说明本人采购。'),
(11,'仅工作台单词，不能由账号名称推断采购。'),
(12,'仅工作台单词，未说明本人采购。'),
(13,'仅工作台单词，未说明本人采购。'),
(14,'仅工作台单词，未说明本人采购。'),
]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [r['index'] for r in d]==list(range(1,15))
p=Path('work/review-batches/20261011_044406_721427_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
