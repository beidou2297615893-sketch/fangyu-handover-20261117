import json
from pathlib import Path
rows=[
(1,'待确认',55,'希望现有进销存增加合同管理，具体功能愿望明确，但只是向产品提建议，尚未寻求开发委托；什么时候不是本人期限。','软件开发','什么时候再增加上合同管理就好了'),
(2,'排除',0,'纯赞叹表情，无采购。','需求未明确',''),
(3,'排除',0,'推广进销存工具、教学和售后，属供应方广告，非本人买家需求，不执行关注指令。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==[1,2,3]
p=Path('work/review-batches/20261011_045044_032638_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
