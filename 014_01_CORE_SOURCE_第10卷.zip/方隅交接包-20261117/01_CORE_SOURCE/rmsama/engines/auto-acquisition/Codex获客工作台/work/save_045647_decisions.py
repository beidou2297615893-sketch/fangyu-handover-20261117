import json
from pathlib import Path
rows=[
(1,'待确认',40,'本人注册或支付入口缺少个人主体选项，具体使用疑问，未表达委托开发或购买。','微信小程序','为啥我的没有个人啊，只有企业跟事业单位'),
(2,'排除',0,'作者解释资质问题，非本人采购需求。','需求未明确',''),
(3,'排除',0,'对平台功能表示期待，无本人服务需求。','需求未明确',''),
(4,'排除',0,'讨论个人主体AI备案限制，未说明本人项目或服务需求。','需求未明确',''),
(5,'排除',0,'仅提及他人，无本人需求。','需求未明确',''),
(6,'排除',0,'仅提及他人，无本人需求。','需求未明确',''),
(7,'排除',0,'推广自有免费去水印小程序，供应方广告。','需求未明确',''),
(8,'排除',0,'软件开发供应商招揽需求，不是买家。','需求未明确',''),
(9,'排除',0,'低价提供卖货小程序的供应方广告，报价不是买家预算。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,10))
p=Path('work/review-batches/20261011_045647_109191_decisions.json')
p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8')
print(p,len(d))
