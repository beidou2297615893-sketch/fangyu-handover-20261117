// Read-only wrapper over the original Douyin CLI BridgeClient; keep full text.
const fs = require('fs');
const path = require('path');
const base = path.resolve(__dirname, '..', '..');
const { BridgeClient } = require(path.join(base, 'work/runtime/douyin-bridge/lib/client/bridge-client'));
const config = JSON.parse(fs.readFileSync(path.join(base, '抖音自用采集台/data/bridge.json'), 'utf8'));
const bindingPath=path.join(__dirname,'抖音连接绑定.json');
const binding=fs.existsSync(bindingPath)?JSON.parse(fs.readFileSync(bindingPath,'utf8')):{};
if(binding.server_port && binding.server_port!==19422)throw new Error('仅允许本人19422 CLI端口');
const client = new BridgeClient({...config.bridge,port:binding.server_port||config.bridge.port});
const [op, connId, value, position, countArg, videoId] = process.argv.slice(2);
async function main() {
  if (op === 'status') { console.log(JSON.stringify(await client.status())); return; }
  if (!['search', 'comments', 'replies'].includes(op) || !connId) throw new Error('仅支持固定连接的搜索与评论读取');
  if (op === 'replies' && !/^\d+$/.test(videoId || '')) throw new Error('回复读取需要已知作品ID');
  const count = Math.max(1, Math.min(20, Number(countArg) || 20));
  const cursor = Math.max(0, Number(position) || 0);
  const expression = op === 'search'
    ? `window.__bridge.search(${JSON.stringify(value)}, ${cursor}, ${count})`
    : op === 'comments' ? `window.__bridge.getComments(${JSON.stringify(value)}, ${cursor}, ${count})`
    : `window.__bridge.replies(${JSON.stringify(value)}, ${JSON.stringify(videoId)}, ${cursor}, ${count})`;
  const result = await client.call({site:'douyin.com', expression, connId, awaitPromise:true, timeout:30000});
  if (!result.ok) throw new Error(result.error || '读取失败');
  console.log(JSON.stringify(result.value));
}
main().catch(e => { console.error(e.message); process.exitCode=1; });
