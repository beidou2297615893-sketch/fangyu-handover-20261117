from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  route=self.path.split('?')[0]
  files={'/':ROOT/'outputs/simple.html','/api/state':ROOT/'outputs/state.json','/api/analysis':ROOT/'outputs/Codex分析进度.json','/api/inventory':ROOT/'outputs/CLI完整盘点.json','/api/excel':ROOT/'outputs/Excel导出进度.json','/customers.xlsx':ROOT/'outputs/客户分类清单.xlsx'}
  if route=='/customers.xlsx':
   available=[p for p in [ROOT/'outputs/客户分类清单.xlsx',ROOT/'outputs/客户分类清单_最新.xlsx'] if p.exists()]
   if available:files[route]=max(available,key=lambda p:p.stat().st_mtime)
  if route not in files or not files[route].exists():self.send_error(404);return
  data=files[route].read_bytes();self.send_response(200)
  self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if route=='/customers.xlsx' else ('text/html; charset=utf-8' if route=='/' else 'application/json; charset=utf-8'))
  if route=='/customers.xlsx':self.send_header('Content-Disposition','attachment; filename="customers.xlsx"')
  self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)
 def log_message(self,*args):pass
if __name__=='__main__':ThreadingHTTPServer(('127.0.0.1',19747),Handler).serve_forever()
