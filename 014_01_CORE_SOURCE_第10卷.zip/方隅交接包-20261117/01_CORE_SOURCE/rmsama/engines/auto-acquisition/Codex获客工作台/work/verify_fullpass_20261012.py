"""Audit source identity, immutable Codex decisions and final local export.

No platform reads, semantic classification or model calls.
"""
import collections, datetime, hashlib, json, sqlite3, subprocess, sys
from pathlib import Path
from codex_review import digest, effective_reviews
from qualify import is_recent

ROOT = Path(__file__).resolve().parents[1]
WORK, OUT = ROOT / 'work', ROOT / 'outputs'
def read(p):
    return json.loads(p.read_text('utf-8'))

manifest = read(WORK / '全量逐条复审队列_20261012.json')
with sqlite3.connect((WORK / 'campaign.sqlite3').as_uri() + '?mode=ro', uri=True) as c:
    records = {i: json.loads(d) for i,d in c.execute("select id,data from records where id like 'comment:%'")}
with sqlite3.connect((WORK / 'codex_reviews.sqlite3').as_uri() + '?mode=ro', uri=True) as c:
    for table, baseline in manifest['baseline'].items():
        assert [list(r) for r in c.execute('select id,data from '+table+' order by id')] == baseline, table
    stored = c.execute('select id,batch,data from review_fullpasses where pass_id=?', (manifest['pass_id'],)).fetchall()
    reviews = {i: json.loads(d) for i,b,d in stored}
    assert len(stored) == len(reviews) == len(manifest['ids']) == 16127
    assert {d['id']:d for d in effective_reviews(c)} == reviews
assert set(records) == set(reviews) == set(manifest['ids'])
for ident,d in reviews.items():
    r = records[ident]
    assert digest(r) == manifest['source_hashes'][ident] == d['source_hash'], ident
    assert d['record'] == r and d['id'] == ident, ident
    assert d['reviewer'] == 'Codex' and d['fullpass_id'] == manifest['pass_id']
    assert d['verdict'] in ('高意向','待确认','排除') and 0 <= d['score'] <= 100
    assert d['reason'].strip()
    for key in ('demand_evidence','budget_evidence','payment_evidence','urgent_evidence'):
        assert not d.get(key) or d[key] in r['text'], (ident,key)
    if d['verdict'] == '高意向':
        assert d['score'] >= 80 and d['demand_evidence'] and r['user_id'] and r['text'].strip() and is_recent(r['published_at'])
for batch_name in {b for i,b,d in stored}:
    batch_path = Path(batch_name)
    batch = read(batch_path)
    decisions = read(batch_path.with_name(batch_path.stem+'_decisions.json'))
    indices = {x['index'] for x in batch['comments']}
    assert len(indices) == len(batch['comments'])
    assert {d['index'] for d in decisions['decisions']} == indices
    assert len(decisions['decisions']) == len(indices) and decisions['reviewer'] == 'Codex'
    by_index = {x['index']:x for x in batch['comments']}
    for decision in decisions['decisions']:
        stored_decision = reviews[by_index[decision['index']]['record']['id']]
        for key,value in decision.items():
            assert stored_decision[key] == value
snapshot = read(WORK / '客户分类快照.json')
assert len(snapshot['rows']) == 16127 and {x['id'] for x in snapshot['rows']} == set(reviews)
assert len(snapshot['customers']) == len({x['uid'] for x in snapshot['customers']})
assert all(x['recent'] and x['uid'] and x['verdict'] in ('高意向','待确认') for x in snapshot['customers'])
for rows in snapshot['types'].values():
    assert len(rows) == len({x['uid'] for x in rows})
assert all(x['uid'] != '1899550237005519' for x in snapshot['customers']), 'Resolved procurement must not reappear'
progress = read(OUT / 'Codex全量逐条复审进度_20261012.json')
assert progress['completed'] == 16127 and progress['pending'] == 0
stop = read(WORK / 'STOP')
assert stop['user_requested_pause'] is True
config = Path('C:/Users/rmsama/.codex/automations/automation-13/automation.toml').read_text('utf-8')
assert 'status = "PAUSED"' in config
status = subprocess.run([sys.executable,'-X','utf8',str(WORK/'launch_comments.py'),'--status'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',check=True)
assert json.loads(status.stdout)['running'] is False
export = read(OUT / '本轮增量复核验收.json')
assert export['errors'] == [] and export['reviewed_total'] == 16127 and export['excel_pending'] == 0
assert export['native_filtered_tables'] == 11 and export['search_keywords'] == 420
assert export['reviews_committed_after_excel_snapshot'] == 0
target = Path(export['excel_file'])
result = dict(audited_at=datetime.datetime.now().astimezone().isoformat(),
    pass_id=manifest['pass_id'], collected_comments=16127,
    freshly_read_and_reviewed=16127, completed_batches=len({b for i,b,d in stored}), pending=0,
    comment_verdicts=dict(collections.Counter(d['verdict'] for d in reviews.values())),
    deduplicated_customer_verdicts=dict(collections.Counter(x['verdict'] for x in snapshot['customers'])),
    customer_total=len(snapshot['customers']),
    demand_types={k:dict(collections.Counter(x['verdict'] for x in rows)) for k,rows in snapshot['types'].items()},
    original_reviews_preserved=len(manifest['baseline']['reviews']),
    historical_rechecks_preserved=len(manifest['baseline']['review_rechecks']),
    original_and_historical_ledgers_byte_unchanged=True, all_source_hashes_unchanged=True,
    evidence_exact_commenter_quotes=True, every_xlsx_conclusion_matches_latest_ledger=True,
    verified_native_video_links=export['verified_customer_video_links'], native_filtered_tables=11,
    search_keywords=420, collection_paused=True, worker_running=False, automation_status='PAUSED',
    excel_file=str(target), excel_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    note='当前Codex重新逐条阅读全部16127条本地评论及已有上下文，逐条结论独立保存。待确认是证据不足或尚未明确委托，并非未分析；高意向为公开线索，不认定支付能力、马上付款或已同意联系。', errors=[])
destination = OUT / '全量重新分析验收_20261012.json'
destination.write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(result,ensure_ascii=False))
