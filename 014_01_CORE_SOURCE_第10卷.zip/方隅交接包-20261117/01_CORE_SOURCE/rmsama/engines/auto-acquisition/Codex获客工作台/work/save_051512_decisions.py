import json
from pathlib import Path
rows=[
 (1,'排除',0,'单提云端可能为方案建议，没有本人采购或制作委托。','需求未明确',''),
 (2,'排除',0,'作者回复介绍云算力单价，不是本人采购预算或买方需求。','需求未明确',''),
 (3,'高意向',88,'本人明确请求制作对口型歌曲视频并愿提供音乐，具体制作委托与数字人视频服务匹配；近期日期、来源及稳定UID可追溯，同UID无既有结论。视频1块报价不是本人预算，无付费承诺或期限。','数字人与视频','你好 能给我做对口型歌视频吗？我给你提供音乐'),
 (4,'高意向',84,'本人在数字人对口型工作流下明确询购买渠道，属于具体工具采购公开线索；近期来源及稳定UID有效，同UID无既有结论。昵称不能补餐饮用途，作者单价不是本人预算，无付款或期限证明。','数字人与视频','怎么购买？'),
]
decisions=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
out=Path(__file__).parent/'review-batches/20261011_051512_318575_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
