import json
from pathlib import Path
rows=[
(1,'排除',0,'求互助互动，未说明本人服务需求。','需求未明确',''),
(2,'排除',0,'邀请代码式内容，无采购。','需求未明确',''),
(3,'排除',0,'分享邀请码与Pro领取额度，20亿是权益而非预算，无采购。','需求未明确',''),
(4,'排除',0,'邀请代码式内容，无采购。','需求未明确',''),
(5,'排除',0,'邀请代码式内容，无采购。','需求未明确',''),
(6,'待确认',20,'表达iOS兼容障碍和羡慕，尚无具体自动化委托。','AI自动化','ios不行[捂脸]羡慕'),
(7,'待确认',35,'询AI读取短信能力，属功能兴趣，未提出本人系统委托，不实际读取短信。','AI自动化','短信也能读吗'),
(8,'排除',0,'邀请码和额度权益，非采购预算。','需求未明确',''),
(9,'排除',0,'求帮忙互动，无具体需求。','需求未明确',''),
(10,'排除',0,'邀请代码式内容，无采购。','需求未明确',''),
(11,'排除',0,'邀请代码式内容，无采购。','需求未明确',''),
]
d=[dict(index=i,verdict=v,score=s,reason=r,demand_type=t,demand_evidence=e,budget_evidence='',payment_evidence='',urgent_evidence='') for i,v,s,r,t,e in rows]
assert [r['index'] for r in d]==list(range(1,12))
p=Path('work/review-batches/20261011_044005_227910_decisions.json');p.write_text(json.dumps(dict(reviewer='Codex',decisions=d),ensure_ascii=False,indent=2),encoding='utf-8');print(p,len(d))
