import json
from pathlib import Path
rows=[
 (1,'分享平台客服答复及删重发经验，没有采购发布软件；24小时属于操作时窗不是本人委托期限。'),
 (2,'回顾隐藏重发经验和流量担忧，没有软件采购或制作委托。'),
 (3,'询平台修改时窗原因，不是发布系统需求。'),
 (4,'感谢平台教程，无本人采购需求。'),
 (5,'询原生话题颜色编辑问题，没有委托开发或发布软件需求。'),
 (6,'讲过去限流经历及感谢，没有当前采购；7天不是本人服务期限。'),
 (7,'找原生编辑按钮，属于平台操作问题，未提出软件或委托。'),
 (8,'感谢教程并回顾重发习惯，没有服务需求。'),
 (9,'询误操作后找回平台视频，属于原生账号操作，不是视频制作或软件开发委托。'),
 (10,'说明正在学习抖音原生操作并感谢，没有工具采购。'),
 (11,'感谢教程对新手的帮助，未表达具体服务需求。'),
 (12,'赞扬讲解，没有买方需求。'),
 (13,'询删除编辑对点赞评论影响，属于平台操作咨询，非软件需求。'),
 (14,'讲自身修改封面无效的经历，没有采购发布软件或委托。'),
 (15,'赞同并表情互动，无需求。'),
 (16,'评论自身限流原因，没有具体软件或制作需求。'),
 (17,'感谢分享，没有需求。'),
 (18,'询平台二次修改间隔，不是本人项目交付期限或发布软件需求。'),
 (19,'感谢主播并表情互动，没有采购。'),
 (20,'反映原生界面没有编辑按钮，没有提出开发或服务委托。'),
]
decisions=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
assert [d['index'] for d in decisions]==list(range(1,21))
out=Path(__file__).parent/'review-batches/20261011_051914_147352_decisions.json'
out.write_text(json.dumps(dict(reviewer='Codex',decisions=decisions),ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
