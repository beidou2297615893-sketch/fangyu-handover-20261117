import json
from pathlib import Path
# 当前Codex已完整逐条读取18条原文与视频；以下为逐条人工结论，仅保存。
rows=[
(1,'icccxy仅留工具二字，无本人业务问题或采购表达。'),
(2,'Litten仅留工具关键词，无本人具体需求。'),
(3,'乐一李仅留工具，无本人采购或功能说明。'),
(4,'JJC只发工具，不能从视频宣传转归团队替代需求。'),
(5,'JT仅发工具，无本人服务委托。'),
(6,'辣椒搞里头只发工具，无本人使用场景。'),
(7,'yyy只留工具关键词，无本人需求。'),
(8,'小王很哇撒仅发工具，没有具体采购表达。'),
(9,'阿吧阿吧只留工具，无法确认需求。'),
(10,'早同学仅发工具，无本人功能或委托说明。'),
(11,'赖东东仅工具关键词，无采购证据。'),
(12,'该作者只发工具，无本人业务需求。'),
(13,'桃酥不是核桃酥只留工具，无本人委托。'),
(14,'人老实话不多只发工具，没有本人具体需求。'),
(15,'工业智造NO.1仅发工具，不从行业昵称补购买身份。'),
(16,'嫣然仅发工具，无本人服务或付款表达。'),
(17,'面包说话仅发工具，无本人功能需求。'),
(18,'愛zeng只留工具，不能据此认定AI销售采购。')]
d=[dict(index=i,verdict='排除',score=0,reason=r,demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='') for i,r in rows]
(Path(__file__).parent/'review-batches/20261011_041045_457417_decisions.json').write_text(json.dumps({'reviewer':'Codex','decisions':d},ensure_ascii=False,indent=2),'utf-8')
