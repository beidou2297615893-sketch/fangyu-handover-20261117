# 抖音CLI回复控制器交接

2026-10-16：用户已授权执行已认可7类公开回复。改为Codex控制本地队列，复用本人19422 Bridge和已安装douyin-cli的post模块；不调用模型API、不修改共享运行时、不恢复采集。

实际已核验1条（汐），IAB账号上海黯淡星屿科技 / loubeidou666；真实回执outputs/回复回执_0001.json，账本SENT_VERIFIED。剩余985位，优先高意向后中等意向。原16127条分析账本不改。

当前实际阻拦：CLI Chrome3/tab896062857账号北极学长 / 80757822213；已实际预检并禁止启动和发布。IAB2/tab1的loubeidou666登录不与Chrome共享。保留两页；仅用户在CLI Chrome登录目标账号后继续。不要导出/复制会话或偷偷用旧号。

入口（均在项目目录运行，使用C:/Users/rmsama/miniconda3/python.exe -X utf8）：
- work/reply_cli_worker.py --status 或 --dry-run：只读本地队列和账本；不会发出平台请求。
- --bind <实际19422连接ID>：核验当前/self可见昵称及抖音号，再读取官方self接口验证稳定sec_uid；匹配才设置绑定。新注册必须重新核对原Chrome页，不盲试旧ID或选择其他账号。
- --start --limit 1：绑定正确后先验证最难一条真实CLI发布+回读；未通过不能声称CLI群量链路已验收。
- 代表性链路核验后 --start：独立隐藏worker串行消费队列，不需要Codex逐条点击。
- 原评论先按精确CID、UID、原文在线核验，读不到则DEFERRED；没有更改原评论或偷换为同人其他评论。楼中楼携带根CID与childCID。
- 只有原始发布回包与在线回读的CID、本文、发送者及父子关系均匹配才记SENT_VERIFIED；审核中或缺少字段严格UNKNOWN停下，人工核查不能重发。所有新发送回包和读回存work/reply-cli-raw、outputs/回复CLI回执_*.json。
- work/回复STOP.json停止回复；用户work/STOP是采集暂停，始终保留，不能当成恢复采集许可。验证码/平台限制留证一次立即停，automation-13继续PAUSED，不周期空转。

本地验收outputs/回复CLI本地验收.json已通过986人原文/UID、话术哈希、排序、21条楼中楼、已发送跳过、重复预留拒绝、互斥释放和错误账号禁止启动。在线错误账号预检outputs/回复CLI预检.json。仅本地和账号防护验收；真实CLI批量发送未验收，也没有新增发送。

上游MIT项目：https://github.com/Yht20927/douyin-cli 。本地适配器2.0与上游4.x账号协议不同，保护本地限定能力，不盲目升级。仅复用原post模块补本实例队列、账号守卫及账本；不使用上游suggest/analyze/getReply模型接口。
