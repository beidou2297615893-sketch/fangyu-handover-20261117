import json
from pathlib import Path
d={'reviewer':'Codex','decisions':[
 dict(index=1,verdict='待确认',score=15,reason='回复作者指定资料词试错，只有流程学习兴趣，无本人制作委托；作者348点不是本人预算。',demand_type='需求未明确',demand_evidence='试错',budget_evidence='',payment_evidence='',urgent_evidence=''),
 dict(index=2,verdict='排除',score=0,reason='供方向另一评论者招揽入粉丝群，非本人采购；不执行加群或联系动作。',demand_type='需求未明确',demand_evidence='',budget_evidence='',payment_evidence='',urgent_evidence='')
]}
Path('work/review-batches/20261011_010951_352425_decisions.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
