# 本机 CLI 完整盘点

发现 104 个入口、源码、下载包及副本，不等于同数量独立工具。
扫描根目录：C:\Users\rmsama、C:\积木软件工坊、C:\ai、C:\opt、C:\From_D
排除目录：.cache、.git、Cache、Caches、Code Cache、GPUCache、WeChat Files、Windows、__pycache__、miniconda3、node_modules、site-packages、xwechat_files
受保护目录等读取错误：93 个，详见 JSON。没有宣称排除目录全部扫描。

- .opencli · 用户 OpenCLI 配置/运行目录
  C:\Users\rmsama\.opencli
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\Users\rmsama\AppData\Local\fangyuWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\方隅公寓客户端\方隅公寓运营台便携版\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\customer-qa\qa-restaurant\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\customer-qa\qa-restaurant-final\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\runtime\douyin-bridge
- dy.exe · 帮助已核验 · 当前未登录
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\cli-runtime\Scripts\dy.exe
- xhs.exe · 搜索帮助已核验 · 当前未登录
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\cli-runtime\Scripts\xhs.exe
- douyin-cli-lazily · 源码候选
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\github\douyin-cli-lazily
- douyin-cli-yht · 源码候选
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\github\douyin-cli-yht
- douyin-rust · 源码候选
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\github\douyin-rust
- douyin-youhai · 源码候选
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\github\douyin-youhai
- opencli · 源码候选
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\github\opencli
- xiaohongshu-cli · 源码候选
  C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\vendor\github\xiaohongshu-cli
- douyin-cli · 源码候选
  C:\Users\rmsama\Documents\灵感心理\做梦心测_抖音迁移\work\douyin-cli
- douyin-cli-main.zip · 下载压缩包/安装包
  C:\Users\rmsama\Documents\灵感心理\抖音评论CLI\work\douyin-cli-main.zip
- douyin-cli-main · 已具备依赖的 Bridge CLI
  C:\Users\rmsama\Documents\灵感心理\抖音评论CLI\work\douyin-cli-main
- douyin-bridge · 源码候选
  C:\积木软件工坊\核心组件\versions\acquisition-frontdesk-20260918\work\runtime\douyin-bridge
- douyin-bridge · 源码候选
  C:\积木软件工坊\核心组件\versions\acquisition-messaging-dev-20260918\work\runtime\douyin-bridge
- douyin-bridge · 源码候选
  C:\积木软件工坊\核心组件\versions\acquisition-review-20260918\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260920\final-portable-runtime-check\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260920\portable-runtime-assembly-check\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260920\runtime-assembly-check\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260920-fix1\final-runtime-c83llbwz\project\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260920-fix2\final-runtime-0jlhm8mf\project\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260921\final-runtime-w0e2csnd\project\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\核心组件\work\release-20260921-channels\runtime-local-check\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓工作台_1.1.0_20260922_182352\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓工作台_1.1.0_20260924_101557\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓工作台_1.1.0_20260924_105730\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓工作台_1.1.0_20260924_111407\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓工作台_1.1.0_20260924_121045\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260924_140549\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260924_141355\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260924_142035\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260924_152857\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260924_201703\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260925_131712\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.1_20260925_132252\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.2_20260925_132830\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.3_20260925_133818\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.4_20260925_134914\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.5_20260925_141309\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\正式交付\方隅公寓本地助手_1.1.6_20260925_143808\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\网页与助手拆分\助手便携候选_20260923_094021\助手文件夹\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\网页与助手拆分\助手便携候选_20260923_094541\助手文件夹\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\网页与助手拆分\助手便携候选_20260923_095047\助手文件夹\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\网页与助手拆分\助手便携候选_20260923_100231\助手文件夹\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\网页与助手拆分\助手便携候选_20260923_100648\助手文件夹\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\outputs\网页与助手拆分\助手便携候选_20260923_125703\助手文件夹\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\app\work\runtime\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\assistant\qa-managed-install\releases\1\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\assistant\qa-managed-update\releases\1\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\assistant\qa-managed-update\releases\2\douyin-bridge
- douyin-cli · 源码候选
  C:\积木软件工坊\项目\方隅公寓客户版\work\browser-vs-http-route-20261003\upstream\douyin-cli
- xiaohongshu-cli · 源码候选
  C:\积木软件工坊\项目\方隅公寓客户版\work\browser-vs-http-route-20261003\upstream\xiaohongshu-cli
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260922_182722\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260922_182722\fangyu-apartment-clientWorkspaceApp.previous-1ffe37d9adfa4d2686c0ebd36750ddd0\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260922_182834\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260922_182834\fangyu-apartment-clientWorkspaceApp.previous-4955295c548d4297ab33d54d80855af0\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_101750\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_101750\fangyu-apartment-clientWorkspaceApp.previous-44c8a8351653420c932d2e574d807fa1\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_102128\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_102128\fangyu-apartment-clientWorkspaceApp.previous-839a08b124304519a025c458c61f7fdc\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_102220\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_102220\fangyu-apartment-clientWorkspaceApp.previous-d7acadf80bd7456abf3d32aaa6186a1d\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_105946\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\packaging\qa-install-20260924_105946\fangyu-apartment-clientWorkspaceApp.previous-4699618b9db14a209d3c59719b3fa950\douyin-bridge
- xhs.exe · 命令入口，待运行核验
  C:\积木软件工坊\项目\方隅公寓客户版\work\qa-cli-source-20260926\site\bin\xhs.exe
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\qa-install-115\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\qa-install-115\fangyu-apartment-clientWorkspaceApp.previous-378007a5abe4409588f27b418c4b0261\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\qa-install-116-final\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\qa-install-116-final\fangyu-apartment-clientWorkspaceApp.previous-49ba7aed481e4800ada34a3777e30a5c\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\候选包_1.1.7_20260925_150216\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\助手模式与测试矩阵整理_20260925\qa-install-full-114\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\方隅公寓客户版\work\安装升级一致性修复_20260925\qa-install-full-20260925\fangyu-apartment-clientWorkspaceApp\douyin-bridge
- jackwener__OpenCLI.zip · 下载压缩包/安装包
  C:\积木软件工坊\项目\方隅公寓客户版\work\开源整合\archives\jackwener__OpenCLI.zip
- Yht20927__douyin-cli.zip · 下载压缩包/安装包
  C:\积木软件工坊\项目\方隅公寓客户版\work\开源整合\archives\Yht20927__douyin-cli.zip
- Yht20927__xiaohongshu-cli.zip · 下载压缩包/安装包
  C:\积木软件工坊\项目\方隅公寓客户版\work\开源整合\archives\Yht20927__xiaohongshu-cli.zip
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.0_20260920_183141\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.1_20260920_223025\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.1_20260920_224028\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.1_20260920_224153\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.1_20260920_224742\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.2_20260921_103646\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.3_20260921_110312\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.3_20260921_110825\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\outputs\正式交付\我的获客工作台_1.0.3_20260921_111601\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\app\work\runtime\douyin-bridge
- opencli · 源码候选
  C:\积木软件工坊\项目\自用工作台\work\app\work\runtime\opencli
- opencli-guarded · 源码候选
  C:\积木软件工坊\项目\自用工作台\work\app\work\runtime\opencli-guarded
- opencli-guarded-v2 · 源码候选
  C:\积木软件工坊\项目\自用工作台\work\app\work\runtime\opencli-guarded-v2
- .opencli · 用户 OpenCLI 配置/运行目录
  C:\积木软件工坊\项目\自用工作台\work\opencli-build\verification-home\.opencli
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\failed-builds\我的获客工作台_1.0.0_20260920_182736\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\failed-builds\我的获客工作台_1.0.0_20260920_183034\便携客户端\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260920_183346\owner-workbenchWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260920_183346\owner-workbenchWorkspaceApp.previous-f12cb33eeabf44398bb9067d0137e82d\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260920_224951\owner-workbenchWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260920_224951\owner-workbenchWorkspaceApp.previous-5d2c18eaf07a4cc9a88f2ac558766c93\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260921_104020\owner-workbenchWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260921_104020\owner-workbenchWorkspaceApp.previous-5960b81c279b48e583b314375f98fe11\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260921_111829\owner-workbenchWorkspaceApp\douyin-bridge
- douyin-bridge · 已具备依赖的 Bridge CLI
  C:\积木软件工坊\项目\自用工作台\work\packaging\qa-install-20260921_111829\owner-workbenchWorkspaceApp.previous-faba7d0f1841492cb5b853f41f52270b\douyin-bridge
- OpenCLI 用户运行时 · 帮助/doctor 已核验 · 浏览器扩展未连接
  C:\Users\rmsama\.opencli\node_modules\@jackwener\opencli