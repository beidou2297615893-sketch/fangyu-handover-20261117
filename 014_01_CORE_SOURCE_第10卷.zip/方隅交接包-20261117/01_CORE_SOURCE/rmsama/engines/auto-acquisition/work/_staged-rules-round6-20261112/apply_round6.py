# -*- coding: utf-8 -*-
"""Apply staged round-6 business_fit.py to live. No-op without --i-understand-live-apply.
Does not touch sending, ledger, STOP, or collection runner files.
"""
import argparse, hashlib, json, shutil, sys
from datetime import datetime
from pathlib import Path

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
STAGED=R/'_staged-rules-round6-20261112'
BACKUP=R/'_backup-filter-fix-20261112'/'round6'
LIVE=FB/'business-fit'/'business_fit.py'
STAGED_FILE=STAGED/'business-fit'/'business_fit.py'

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--i-understand-live-apply', action='store_true')
    args=parser.parse_args()
    if not STAGED_FILE.is_file() or not LIVE.is_file():
        print('missing file', file=sys.stderr); return 1
    print('live', sha256(LIVE))
    print('staged', sha256(STAGED_FILE))
    if not args.i_understand_live_apply:
        print('Refusing to modify live files. Re-run with --i-understand-live-apply after confirming sending is stopped.')
        return 2
    BACKUP.mkdir(parents=True, exist_ok=True)
    shutil.copy2(LIVE, BACKUP/'business_fit.py')
    shutil.copy2(STAGED_FILE, LIVE)
    report={
        'time': datetime.now().isoformat(),
        'before': sha256(BACKUP/'business_fit.py'),
        'after': sha256(LIVE),
        'staged': sha256(STAGED_FILE),
        'backup_dir': str(BACKUP),
        'same_as_staged': sha256(LIVE)==sha256(STAGED_FILE),
        'note': 'Incremental only: video unit keywords 小公寓/单身公寓/精品公寓. Floor still 3000. Collection/ledger/send untouched.',
    }
    (BACKUP/'change-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8')
    print('applied', report['after'])
    return 0

if __name__=='__main__':
    raise SystemExit(main())
