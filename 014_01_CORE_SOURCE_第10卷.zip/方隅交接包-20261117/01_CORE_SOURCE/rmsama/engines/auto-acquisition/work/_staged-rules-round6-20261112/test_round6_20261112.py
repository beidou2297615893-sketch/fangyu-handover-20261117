# -*- coding: utf-8 -*-
"""Round 6 (2026-11-12): incremental video-gate leak close. Does not replace rounds 1-5."""
import sys, time, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'business-fit'))
sys.path.insert(0, str(ROOT / 'recency-priority'))
import business_fit as f

def row(comment, post, **extra):
    data = {
        'comment_text': comment,
        'post_body': post,
        'platform': 'douyin',
        'role': 'demand',
        'published_at_unix': time.time() - 86400 * 8,
        'video_id': extra.pop('video_id', 'v-r6'),
    }
    data.update(extra)
    return data

class Round6(unittest.TestCase):
    def test_keeps_round5_floor_and_label(self):
        self.assertEqual(f.VIDEO_RENT_FLOOR, 3000)
        self.assertEqual(f.REASON_LABELS['low_price_video_budget_mismatch'], '低价视频-预算不符')

    def test_small_apartment_form_now_gated(self):
        post = '一个人带一只小金毛 勇闯上海 1200 小公寓'
        info = f.video_listed_rent(row('在哪', post))
        self.assertEqual(info['state'], 'below_floor', info)
        self.assertTrue(any(p['amount'] == 1200 for p in info['prices']), info)
        s = f.screen(row('在哪', post))
        self.assertFalse(s['eligible_candidate'])
        self.assertIn('low_price_video_budget_mismatch', s['exclusion_reasons'])

    def test_bachelor_and_boutique_apartment_units(self):
        for post, amt in [('临安单身公寓850 拎包入住', 850), ('精品公寓只要1500 一室', 1500)]:
            with self.subTest(post=post):
                info = f.video_listed_rent(row('这是哪里', post))
                self.assertEqual(info['state'], 'below_floor', info)
                self.assertTrue(any(p['amount'] == amt for p in info['prices']), info)

    def test_own_budget_and_high_price_still_not_video_gated(self):
        post = '勇闯上海 1200 小公寓'
        s = f.screen(row('预算3500，这是哪里', post))
        self.assertNotIn('low_price_video_budget_mismatch', s['exclusion_reasons'])
        s2 = f.screen(row('在哪', '上海古北 月租8500 精品公寓'))
        self.assertNotIn('low_price_video_budget_mismatch', s2['exclusion_reasons'])

    def test_round5_guards_still_hold(self):
        # 几百 / 押金 / 混合价 不得因本轮扩单元词而误关
        self.assertNotEqual(f.video_listed_rent(row('在哪', '几百整租民用水电 #杭州租房'))['state'], 'below_floor')
        self.assertNotEqual(f.video_listed_rent(row('在哪', '押金850，月租5000 一室一厅'))['state'], 'below_floor')
        mixed = f.video_listed_rent(row('在哪', '一室2000，两室5000，都有'))
        self.assertEqual(mixed['state'], 'mixed', mixed)
        s = f.screen(row('有没有单间出租', '今天路过拍了一下这个小区的绿化#生活'))
        self.assertTrue(s['eligible_candidate'], s)

if __name__ == '__main__':
    unittest.main()
