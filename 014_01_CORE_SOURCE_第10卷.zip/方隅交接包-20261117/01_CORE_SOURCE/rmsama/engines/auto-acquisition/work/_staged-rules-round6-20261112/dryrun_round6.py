# -*- coding: utf-8 -*-
import importlib.util, json, sys, time
from pathlib import Path

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
ST=R/'_staged-rules-round6-20261112'
OUT=ST/'temp-output'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ST/'recency-priority'))

def load(name, path):
    spec=importlib.util.spec_from_file_location(name, path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

old=load('bf_old', FB/'business-fit'/'business_fit.py')
new=load('bf_new', ST/'business-fit'/'business_fit.py')

def text(row):
    c=row.get('classification') or {}
    return row.get('comment_text') or row.get('text') or c.get('comment_text') or ''

cur=json.loads((FB/'recency-priority'/'daily-priority'/'current.json').read_text(encoding='utf-8'))
qpath=Path(cur['platforms']['douyin']['queue'])
sendable=set()
with qpath.open(encoding='utf-8') as f:
    for line in f:
        if line.strip():
            sendable.add(str(json.loads(line).get('comment_id') or ''))
print('current queue', qpath.name, 'n', len(sendable), 'updated', cur.get('updated_at'))

gated_videos={}
newly=[]
borderline_videos={}
parseable=set(); total=0; t0=time.time()
with (FB/'douyin-semantic-repair-v5'/'all-pool-business-fit.jsonl').open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        row=json.loads(line)
        total+=1
        vid=str(row.get('video_id') or '')
        info=new.video_listed_rent(row)
        if info.get('prices'):
            parseable.add(vid)
        if info.get('state')=='below_floor':
            rec=gated_videos.setdefault(vid, {
                'video_id': vid,
                'post': (row.get('post_body') or '')[:200],
                'quote': info.get('quote'),
                'prices': [p['amount'] for p in info.get('prices') or []],
                'comments': 0, 'newly': 0, 'in_queue': 0, 'samples': [],
            })
            rec['comments']+=1
        elif info.get('borderline') or info.get('state')=='mixed':
            borderline_videos.setdefault(vid, {
                'video_id': vid,
                'post': (row.get('post_body') or '')[:180],
                'state': info.get('state'),
                'borderline': info.get('borderline'),
                'quote': info.get('quote'),
            })
        b=old.screen(row)
        s=new.screen(row)
        if b['eligible_candidate'] and not s['eligible_candidate']:
            item={
                'comment_id': row.get('comment_id'),
                'video_id': vid,
                'text': text(row),
                'in_sendable': str(row.get('comment_id') or '') in sendable,
                'labels': s.get('exclusion_reason_labels'),
                'quote': (s.get('video_listed_rent') or {}).get('quote'),
                'post': (row.get('post_body') or '')[:160],
            }
            newly.append(item)
            if vid in gated_videos:
                gated_videos[vid]['newly']+=1
                if item['in_sendable']:
                    gated_videos[vid]['in_queue']+=1
                if len(gated_videos[vid]['samples'])<3:
                    gated_videos[vid]['samples'].append(item['text'])

print('pool', total, 'elapsed', round(time.time()-t0,2))
print('parseable videos', len(parseable), 'gated below floor', len(gated_videos))
print('newly excluded vs live r5', len(newly), 'in current sendable', sum(1 for x in newly if x['in_sendable']))
print('borderline videos', len(borderline_videos))
ranked=sorted(gated_videos.values(), key=lambda v: (-v['in_queue'], -v['newly'], -v['comments']))
# highlight new unit quotes
print('--- newly excluded samples ---')
for x in newly[:15]:
    print((x['text'] or '')[:40], '|', x['quote'], '|', (x['post'] or '').replace('\n',' ')[:80], '| queue' if x['in_sendable'] else '|')
print('--- 10 gated (prefer new-unit / in-queue) ---')
shown=0
preferred=[v for v in ranked if any(s in str(v.get('quote')) for s in ('小公寓','单身公寓','精品公寓'))]
for v in preferred+ranked:
    if v in preferred or shown>=10:
        if shown>=10 and v not in preferred:
            break
    if shown>=12:
        break
    print(' prices', v['prices'], 'quote', v['quote'], 'comments', v['comments'], 'newly', v['newly'], 'in_queue', v['in_queue'])
    print(' ', (v['post'] or '').replace('\n',' ')[:150])
    shown+=1

report={
    'pool': total,
    'current_queue': str(qpath),
    'current_queue_count': len(sendable),
    'updated_at': cur.get('updated_at'),
    'parseable_videos': len(parseable),
    'gated_videos': len(gated_videos),
    'newly_excluded': len(newly),
    'newly_in_sendable': sum(1 for x in newly if x['in_sendable']),
    'borderline_videos': len(borderline_videos),
    'all_newly': newly,
    'gated_samples': (preferred+ranked)[:12],
}
(OUT/'dryrun-round6-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('wrote', OUT/'dryrun-round6-report.json')
