# -*- coding: utf-8 -*-
"""Append a small 闽清 set to Fuzhou store in collection-config-fixed.json.
Does not edit the currently running plan (plan digest must stay). Next new_round will pick them up.
"""
import argparse, hashlib, json, shutil, sys
from datetime import datetime
from pathlib import Path

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
IND=R/'fangyu-douyin-independent'
CFG=IND/'collection-config-fixed.json'
BACKUP=R/'_backup-filter-fix-20261112'/'round6'
WORDS=[
    '福州闽清租房','福州闽清求租','福州闽清整租','福州闽清月租','福州闽清一居室',
    '闽清租房','闽清求租','闽清整租','闽清月租','闽清一居室',
]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--i-understand-live-apply', action='store_true')
    args=parser.parse_args()
    cfg=json.loads(CFG.read_text(encoding='utf-8-sig'))
    store=next(s for s in cfg['stores'] if s.get('store_id')=='福州白湖亭方隅服务公寓')
    have=set(store['keywords'])
    add=[w for w in WORDS if w not in have]
    print('fuzhou keywords now', len(store['keywords']), 'to_add', add)
    if not args.i_understand_live_apply:
        print('dry, not written')
        return 0 if add or True else 0
    BACKUP.mkdir(parents=True, exist_ok=True)
    shutil.copy2(CFG, BACKUP/'collection-config-fixed.json')
    store['keywords']=list(store['keywords'])+add
    # keep rule_source note short
    note=' + round6 闽清 10 words 2026-11-12 (next new_round only; running plan unchanged)'
    if '闽清 10 words' not in str(cfg.get('rule_source','')):
        cfg['rule_source']=str(cfg.get('rule_source') or '')+note
    CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
    print('wrote', len(add), 'words, fuzhou now', len(store['keywords']))
    print('backup', BACKUP/'collection-config-fixed.json')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
