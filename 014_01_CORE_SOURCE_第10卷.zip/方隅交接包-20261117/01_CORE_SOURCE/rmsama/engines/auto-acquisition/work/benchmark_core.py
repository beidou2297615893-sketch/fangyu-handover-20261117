import sys,time,json,tempfile,csv,io
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from core import Core
out=ROOT/'work'/'performance';out.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=out) as d:
 core=Core(d,ROOT/'src/resources');user=core.handle('bootstrap',{'username':'benchmark','password':'[REDACTED:assigned_secret]'})['user']
 content='platform,source_id,title,author,text,demo\n'+''.join(f'xiaohongshu,benchmark-{i},【合成测试】租房咨询,合成用户{i},计划入住想预约看房,true\n' for i in range(10000))
 start=time.perf_counter();first=core.handle('import_csv',{'content':content},user);elapsed=time.perf_counter()-start
 start=time.perf_counter();repeat=core.handle('import_csv',{'content':content},user);dedup_elapsed=time.perf_counter()-start
 start=time.perf_counter();export=core.handle('export_csv',{},user);export_elapsed=time.perf_counter()-start
 assert first['imported']==10000 and repeat['duplicates']==10000
 records=list(csv.DictReader(io.StringIO(export['content'].lstrip('\ufeff'))));assert len(records)==10000
 report={'fixture':'10000合成演示记录，非平台抓取','imported':first['imported'],'duplicateSkipped':repeat['duplicates'],'exported':len(records),'importSeconds':round(elapsed,3),'dedupeSeconds':round(dedup_elapsed,3),'exportSeconds':round(export_elapsed,3),'databaseBytes':core.store.path.stat().st_size,'networkCalls':0}
 (out/'10000-record-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(report,ensure_ascii=False))
