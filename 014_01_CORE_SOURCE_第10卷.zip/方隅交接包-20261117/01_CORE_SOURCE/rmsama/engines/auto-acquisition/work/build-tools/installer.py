"""User-level self extracting installer. ZIP payload is appended at build time."""
from pathlib import Path
import os, sys, zipfile, subprocess, base64, threading, tkinter as tk, json, re, uuid, shutil
from tkinter import messagebox

TITLE='方隅公寓运营台'
TARGET=Path(os.environ['LOCALAPPDATA'])/'FangyuWorkspaceApp'
EXECUTABLE=TITLE+'.exe'
APP_ID='fangyu'
WEBVIEW2_URL='https://developer.microsoft.com/microsoft-edge/webview2/'

def webview2_version():
    import winreg
    key=r'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
        for flag in (winreg.KEY_WOW64_32KEY,winreg.KEY_WOW64_64KEY):
            try:
                with winreg.OpenKey(hive,key,0,winreg.KEY_READ|flag) as handle:value=str(winreg.QueryValueEx(handle,'pv')[0])
                if int(value.split('.')[0])>=86:return value
            except (OSError,ValueError):pass
    return None

def metadata(archive):
    global TITLE,TARGET,EXECUTABLE,APP_ID
    with zipfile.ZipFile(archive) as z: config=json.loads(z.read('company.json').decode('utf-8-sig'))
    APP_ID=config.get('id','')
    if not re.fullmatch(r'[a-z][a-z0-9_-]{1,40}',APP_ID): raise ValueError('企业标识必须为 2 至 41 位 ASCII 小写字母、数字、下划线或短横线')
    name=config.get('name','')
    if not isinstance(name,str) or not name.strip() or len(name)>80 or re.search(r'[<>:"/\\|?*\x00-\x1f]',name):raise ValueError('企业名称不能用于安全文件名')
    TITLE=name+'运营台'
    runtime=config.get('runtime',{})
    EXECUTABLE=runtime.get('executable',TITLE+'.exe')
    if not isinstance(EXECUTABLE,str) or re.search(r'[<>:"/\\|?*\x00-\x1f]',EXECUTABLE) or not EXECUTABLE.lower().endswith('.exe'):raise ValueError('程序入口必须是当前目录中的 EXE 文件名')
    TARGET=Path(os.environ['LOCALAPPDATA'])/(APP_ID+'WorkspaceApp')
    return config

def ps(script):
    encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
    subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],check=True,
                   creationflags=0x08000000,stdout=subprocess.PIPE,stderr=subprocess.PIPE)

def quote(text): return "'"+str(text).replace("'","''")+"'"

def extract(archive):
    metadata(archive)
    parent=Path(os.environ['LOCALAPPDATA']).resolve()
    target=TARGET.resolve()
    if target.parent!=parent: raise ValueError('安装目录超出当前用户目录')
    staging=parent/(APP_ID+'WorkspaceApp.staging-'+uuid.uuid4().hex)
    backup=parent/(APP_ID+'WorkspaceApp.previous-'+uuid.uuid4().hex)
    staging.mkdir()
    base=staging.resolve()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            destination=(base/item.filename).resolve()
            if not destination.is_relative_to(base) or ':' in item.filename: raise ValueError('安装包路径无效')
        if z.testzip():raise ValueError('安装包完整性校验失败')
        z.extractall(base)
    if not (base/EXECUTABLE).is_file():raise ValueError('安装包缺少程序入口')
    # Uninstaller script validates the exact expected directory before recursive removal.
    uninstall=r'''$expected=Join-Path $env:LOCALAPPDATA '__DIRECTORY__'
$target=[IO.Path]::GetFullPath($PSScriptRoot)
if ($target -ne [IO.Path]::GetFullPath($expected)) { throw '卸载路径验证失败' }
Add-Type -AssemblyName System.Windows.Forms
$ok=[System.Windows.Forms.MessageBox]::Show('删除软件程序？业务数据和账号资料将保留。请先关闭软件。',__CAPTION__,'YesNo')
if ($ok -ne 'Yes') { exit }
$shortcut=Join-Path ([Environment]::GetFolderPath('Desktop')) __SHORTCUT__
if (Test-Path -LiteralPath $shortcut) { Remove-Item -LiteralPath $shortcut -Force }
Remove-Item -LiteralPath $target -Recurse -Force
'''
    uninstall=uninstall.replace('__DIRECTORY__',APP_ID+'WorkspaceApp').replace('__CAPTION__',quote('卸载'+TITLE)).replace('__SHORTCUT__',quote(TITLE+'.lnk'))
    (base/'卸载软件.ps1').write_text(uninstall,encoding='utf-8-sig')
    (base/'卸载软件.cmd').write_text('@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0卸载软件.ps1"\r\n',encoding='gbk')
    moved=False
    try:
        if target.exists():os.replace(target,backup);moved=True
        os.replace(staging,target)
    except Exception:
        if moved and not target.exists():os.replace(backup,target)
        raise
    exe=target/EXECUTABLE
    script="$w=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$w.CreateShortcut((Join-Path $d "+quote(TITLE+'.lnk')+")); $s.TargetPath="+quote(exe)+"; $s.WorkingDirectory="+quote(target)+"; $s.Save()"
    ps(script)
    if moved:(target/'previous-version.txt').write_text(str(backup),encoding='utf-8')
    return exe

def main():
    if '--verify-payload' in sys.argv:
        output=Path(sys.argv[sys.argv.index('--verify-payload')+1])
        metadata(sys.executable)
        with zipfile.ZipFile(sys.executable) as archive:
            bad=archive.testzip()
            if bad: raise RuntimeError(bad)
            output.write_text('verified '+str(len(archive.infolist()))+' files',encoding='utf-8')
        return
    archive_path=sys.executable if getattr(sys,'frozen',False) else sys.argv[1]
    try: metadata(archive_path)
    except Exception as ex:
        error_root=tk.Tk();error_root.withdraw();messagebox.showerror('安装包无效',str(ex));error_root.destroy();return
    root=tk.Tk();root.iconbitmap(str(Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[2]/'src/resources'))/'brand.ico'));root.title(TITLE+' · 安装');root.geometry('620x365');root.configure(bg='#f6f7f8');root.resizable(False,False)
    tk.Label(root,text=TITLE,font=('Microsoft YaHei UI',22,'bold'),bg='#f6f7f8',fg='#33465d').pack(pady=(28,12))
    tk.Label(root,text='安装到当前用户，无需管理员权限。\n包含本地工作台与平台工具；账号由您自行连接。',font=('Microsoft YaHei UI',11),bg='#f6f7f8').pack()
    tk.Label(root,text=str(TARGET),font=('Microsoft YaHei UI',9),bg='#f6f7f8',wraplength=570).pack(pady=16)
    status=tk.StringVar(value='安装前请先退出正在运行的软件。')
    tk.Label(root,textvariable=status,bg='#f6f7f8',font=('Microsoft YaHei UI',10)).pack()
    button=tk.Button(root,text='安装到此电脑',bg='#33465d',fg='white',font=('Microsoft YaHei UI',12),width=22)
    button.pack(pady=14)
    version=webview2_version()
    tk.Label(root,text=('已检测到 WebView2 '+version) if version else '需要先安装免费的 Microsoft Edge WebView2 Runtime',font=('Microsoft YaHei UI',9),bg='#f6f7f8',fg='#33465d').pack()
    def runtime_link():
        import webbrowser
        webbrowser.open(WEBVIEW2_URL)
    tk.Button(root,text='Microsoft 官方运行时下载页',command=runtime_link,relief='flat',bg='#f6f7f8',fg='#33465d').pack()
    def finished(exe,error):
        if error:
            status.set('安装未完成');button.config(state='normal');messagebox.showerror('安装失败',error);return
        status.set('安装完成，桌面快捷方式已创建。')
        button.config(text='打开运营台',state='normal',command=lambda:os.startfile(exe))
    def work():
        try: exe=extract(archive_path); error=None
        except Exception as e: exe=None;error=str(e)
        root.after(0,lambda:finished(exe,error))
    def start():
        if not webview2_version():
            messagebox.showinfo('缺少桌面运行时','此独立桌面客户端需要免费的 WebView2 Runtime。\n请点击下方 Microsoft 官方下载页，安装后再次点击“安装到此电脑”。\n无需购买服务，也不会回退到浏览器网页。');return
        button.config(state='disabled');status.set('正在解压安装，请稍候……');threading.Thread(target=work,daemon=True).start()
    button.config(command=start);root.mainloop()

if __name__=='__main__':main()
