"""Compose an independently branded customer edition from the verified core bundle."""
import argparse,json,re,shutil,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def main():
    parser=argparse.ArgumentParser(description='按企业配置组装独立客户软件')
    parser.add_argument('--config',required=True); parser.add_argument('--name');parser.add_argument('--id');parser.add_argument('--platform',help='已安装适配器的 id')
    args=parser.parse_args(); config=json.loads(Path(args.config).read_text('utf-8-sig'))
    if args.name:config['name']=args.name
    if args.id:config['id']=args.id
    if args.platform:config['platform']=args.platform
    platform=config.get('platform','xiaohongshu')
    if not re.fullmatch('[a-z][a-z0-9_-]{1,40}',platform) or not (ROOT/'src/resources/adapters'/(platform+'.json')).is_file():raise SystemExit('平台适配器尚未安装，请先添加并验证对应manifest')
    if not re.fullmatch('[a-z][a-z0-9_-]{1,40}',config.get('id','')): raise SystemExit('id需为小写英文数字及连字符，2—41字符')
    if any(c in config.get('name','') for c in '<>:"/\\|?*') or not config.get('name'):raise SystemExit('企业名含不允许的文件名字符')
    source=ROOT/'outputs/方隅公寓客户端/方隅公寓运营台便携版'
    if not (source/'方隅公寓运营台.exe').exists():raise SystemExit('请先运行 build.py 构建核心运行时')
    bundled_manifest=source/'_internal/resources/adapters'/(platform+'.json')
    if not bundled_manifest.is_file():raise SystemExit('该平台尚未进入基础运行时，请先重新构建并验证基础包')
    dest=ROOT/'outputs/客户软件'/config['id']
    if dest.exists():raise SystemExit('同名客户交付目录已存在，换ID或人工保留旧版后再构建')
    shutil.copytree(source,dest)
    exe=config['name']+'运营台.exe'; (dest/'方隅公寓运营台.exe').rename(dest/exe)
    config['runtime']={'executable':exe}
    (dest/'company.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),'utf-8')
    (dest/'启动说明.txt').write_text('双击 '+exe+'。首次创建管理员；不同客户ID对应独立本地数据库。平台仍需自行连接。\n','utf-8-sig')
    archive=dest.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in dest.rglob('*'):
            if p.is_file(): z.write(p,str(p.relative_to(dest)))
    print(json.dumps({'directory':str(dest),'zip':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False))
if __name__=='__main__':main()
