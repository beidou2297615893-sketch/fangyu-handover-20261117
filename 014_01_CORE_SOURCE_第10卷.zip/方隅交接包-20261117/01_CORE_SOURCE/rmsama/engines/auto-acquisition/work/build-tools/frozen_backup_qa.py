"""Portable backup restore QA through HTTP; no platform calls or real user data."""
from pathlib import Path
import argparse, base64, hashlib, http.cookiejar, json, shutil, subprocess, time
import urllib.request, urllib.error, uuid, zipfile

ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--exe',required=True);parser.add_argument('--source',action='store_true');args=parser.parse_args()
directory=ROOT/'work/frozen-qa'/('backup-transfer-'+uuid.uuid4().hex[:8]);directory.mkdir(parents=True)
processes=[];clients=[]
evidence={'dataDirectory':str(directory),'executable':args.exe,'mode':'source' if args.source else 'frozen','checks':{}}

class Client:
    def __init__(self,data):
        self.data=data;data.mkdir()
        command=([args.exe,str(ROOT/'src/app.py')] if args.source else [args.exe])+['--no-browser','--data-dir',str(data)]
        self.proc=subprocess.Popen(command,creationflags=0x08000000);processes.append(self.proc)
        for _ in range(100):
            if self.proc.poll() is not None:raise RuntimeError('App exited before ready')
            if (data/'running.json').exists():break
            time.sleep(.2)
        self.url=json.loads((data/'running.json').read_text('utf-8'))['url']
        self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        clients.append(self)
    def call(self,action,data=None):
        request=urllib.request.Request(self.url+'/api',json.dumps({'action':action,'data':data or {}}).encode(),headers={'Content-Type':'application/json','X-Local-App':'1','Origin':self.url})
        with self.opener.open(request,timeout=30) as response:return json.load(response)
    def asset(self,asset_id):
        with self.opener.open(self.url+'/asset/'+asset_id,timeout=10) as response:return response.read()
    def save(self,entity,record):return self.call('save',{'entity':entity,'record':record})

try:
    source=Client(directory/'source')
    source.call('bootstrap',{'username':'qa-original-admin','password':'[REDACTED:assigned_secret]','company_name':'备份迁移测试'})
    content='这是本地合成验收资料，不含客户数据。\n'.encode('utf-8')
    asset=source.call('upload_asset',{'name':'synthetic-material.txt','base64':base64.b64encode(content).decode('ascii'),'kind':'验收合成资料'})
    assert source.asset(asset['id'])==content
    account=source.save('accounts',{'name':'未连接的验收账号','platform':'xiaohongshu'})
    task=source.save('tasks',{'name':'未运行的验收任务','platform':'xiaohongshu','keywords':['验收占位'],'account_id':account['id']})
    backup=source.call('backup');backup_path=Path(backup['path'])
    assert backup_path.suffix=='.zip' and backup['asset_count']==1
    with zipfile.ZipFile(backup_path) as archive:
        assert archive.testzip() is None
        assert any(name.startswith('assets/') for name in archive.namelist())
        assert not any(name.startswith('accounts/') or 'cookies' in name.lower() for name in archive.namelist())
    evidence['checks']['uploadAndCompleteZipBackup']='passed'
    destination=Client(directory/'destination')
    destination.call('bootstrap',{'username':'qa-temp-admin','password':'[REDACTED:assigned_secret]'})
    backups=destination.data/'backups';backups.mkdir(exist_ok=True)
    copied=backups/backup_path.name;shutil.copy2(backup_path,copied)
    restored=destination.call('restore',{'path':str(copied),'password':'[REDACTED:assigned_secret]'})
    assert restored['requires_platform_login'] is True
    try:destination.call('list',{'entity':'assets'})
    except urllib.error.HTTPError as error:assert error.code in (400,401)
    else:raise AssertionError('restore did not revoke old session')
    destination.call('login',{'username':'qa-original-admin','password':'[REDACTED:assigned_secret]'})
    assert destination.asset(asset['id'])==content
    assets=destination.call('list',{'entity':'assets'})
    restored_asset=next(x for x in assets if x['id']==asset['id'])
    assert Path(restored_asset['path']).resolve().is_relative_to((destination.data/'assets').resolve())
    accounts=destination.call('list',{'entity':'accounts'})
    assert next(x for x in accounts if x['id']==account['id'])['status']=='login_required'
    tasks=destination.call('list',{'entity':'tasks'})
    assert next(x for x in tasks if x['id']==task['id'])['status']=='paused'
    evidence['checks'].update(restoreIntoFreshDataDirectory='passed',originalAdminRelogin='passed',assetHttpBytesAndMigratedPath='passed',platformLoginRequired='passed',tasksPaused='passed',sessionRevoked='passed')
    evidence['assetSha256']=hashlib.sha256(content).hexdigest();evidence['backup']=str(backup_path)
    for client in clients:assert client.call('shutdown')['ok'] is True
    for process in processes:assert process.wait(timeout=10)==0
    evidence['checks']['bothHostsShutdown']='passed'
finally:
    for process in processes:
        if process.poll() is None:process.terminate();process.wait(timeout=10)
    name='source-backup-transfer-qa.json' if args.source else 'frozen-backup-transfer-qa.json'
    (ROOT/'work/build'/name).write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(evidence,ensure_ascii=False))
