"""Installer transaction tests in temporary directories; never writes real AppData."""
import importlib.util, tempfile, os, json, zipfile
import re
from pathlib import Path
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('installer',Path(__file__).with_name('installer.py'))
installer=importlib.util.module_from_spec(spec);spec.loader.exec_module(installer)

with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    def payload(name='client',evil=False,version=b'v1'):
        output=root/(name.replace('/','_').replace('\\','_')+'.zip')
        with zipfile.ZipFile(output,'w') as z:
            z.writestr('company.json',json.dumps({'id':name,'name':'示例商户','runtime':{'executable':'app.exe'}}))
            z.writestr('app.exe',version)
            if evil:z.writestr('../outside.txt','not allowed')
        return output
    with patch.dict(os.environ,{'LOCALAPPDATA':tmp}),patch.object(installer,'ps'):
        for company_id in ('ab','fangyu','company_2','restaurant-a','a'+'b'*40):
            assert re.fullmatch(r'[a-z][a-z0-9_-]{1,40}',company_id)
            installer.metadata(payload(name=company_id))
        for company_id in ('a','ACompany','a'+'b'*41,'company space'):
            try:installer.metadata(payload(name=company_id))
            except ValueError:pass
            else:raise AssertionError('invalid company ID accepted')
        first=payload()
        entry=installer.extract(first)
        assert entry.read_bytes()==b'v1'
        updated=payload(version=b'v2')
        installer.extract(updated)
        assert entry.read_bytes()==b'v2'
        previous=Path((entry.parent/'previous-version.txt').read_text('utf-8'))
        assert (previous/'app.exe').read_bytes()==b'v1'
        third=payload(version=b'v3')
        original=installer.os.replace
        def fail_new(source,destination):
            if '.staging-' in str(source):raise PermissionError('simulated locked install')
            return original(source,destination)
        with patch.object(installer.os,'replace',side_effect=fail_new):
            try:installer.extract(third)
            except PermissionError:pass
            else:raise AssertionError('expected transaction failure')
        assert entry.read_bytes()==b'v2','previous installation must survive failed replacement'
        for bad in (payload(name='../invalid'),payload(name='evil',evil=True)):
            try:installer.extract(bad)
            except ValueError:pass
            else:raise AssertionError('unsafe package accepted')
        assert not (root/'outside.txt').exists()
print('PASS: first install, brand metadata, backup update, rollback, invalid ID and traversal')
