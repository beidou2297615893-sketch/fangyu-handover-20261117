"""Generate one real login QR in an isolated directory; never scan or complete login."""
from pathlib import Path
import os, subprocess, time, json, uuid
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]
directory=ROOT/'work/frozen-qa'/('qr-'+uuid.uuid4().hex[:8]);directory.mkdir(parents=True)
qr=directory/'login.png';env=os.environ.copy()
env.update(HOME=str(directory),USERPROFILE=str(directory),XDG_CONFIG_HOME=str(directory/'.config'),APPDATA=str(directory/'AppData/Roaming'),LOCALAPPDATA=str(directory/'AppData/Local'),WORKSPACE_QR_PATH=str(qr),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
exe=ROOT/'outputs/方隅公寓客户端/方隅公寓运营台便携版/platform-cli/platform-cli.exe'
with (directory/'stdout.log').open('wb') as out,(directory/'stderr.log').open('wb') as err:
    process=subprocess.Popen([str(exe),'xiaohongshu','login','--qrcode'],env=env,cwd=directory,stdout=out,stderr=err,creationflags=0x08000000)
    try:
        deadline=time.monotonic()+60
        while time.monotonic()<deadline and process.poll() is None:
            if qr.exists() and qr.stat().st_size>100:break
            time.sleep(.25)
        assert qr.exists(),'QR not generated; inspect isolated logs'
        with Image.open(qr) as img:
            img.verify()
        with Image.open(qr) as img:size=list(img.size)
    finally:
        if process.poll() is None:process.terminate();process.wait(timeout=10)
evidence={'platform':'xiaohongshu','mode':'frozen-real-qr-generated-not-scanned','png':str(qr),'dimensions':size,'loginCompleted':False,'isolatedDirectory':str(directory),'processStopped':process.poll() is not None}
(ROOT/'work/build/frozen-qr-qa.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(evidence,ensure_ascii=False))
