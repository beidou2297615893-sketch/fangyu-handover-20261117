"""Exercise a frozen edition entirely in explicit disposable project data."""
from pathlib import Path
import argparse, json, subprocess, time, urllib.request, http.cookiejar, uuid
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--exe',required=True);parser.add_argument('--id',required=True);parser.add_argument('--name',required=True);parser.add_argument('--templates',type=int,default=4);parser.add_argument('--industry');parser.add_argument('--booked-label');args=parser.parse_args()
data=ROOT/'work/frozen-qa'/(args.id+'-'+uuid.uuid4().hex[:8]);data.mkdir(parents=True)
evidence={'id':args.id,'dataDirectory':str(data),'executable':args.exe,'checks':{}}
process=subprocess.Popen([args.exe,'--no-browser','--data-dir',str(data)],creationflags=0x08000000)
cookies=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies))
try:
    for _ in range(100):
        if process.poll() is not None:raise RuntimeError('frozen application exited: '+str(process.returncode))
        if (data/'running.json').exists():break
        time.sleep(.2)
    url=json.loads((data/'running.json').read_text('utf-8'))['url']
    def call(action,body=None):
        request=urllib.request.Request(url+'/api',json.dumps({'action':action,'data':body or {}}).encode('utf-8'),headers={'Content-Type':'application/json','X-Local-App':'1','Origin':url})
        with opener.open(request,timeout=10) as response:return json.load(response)
    status=call('status');assert status['initialized'] is False
    assert status['company']['id']==args.id and status['company']['name']==args.name
    if args.industry:assert status['company']['industry']==args.industry
    evidence['checks']['freshStatusAndBrand']='passed';evidence['company']=status['company']
    call('bootstrap',{'username':'qa-admin','password':'[REDACTED:assigned_secret]','company_name':args.name})
    assert call('status')['initialized'] is True
    templates=call('list',{'entity':'templates'});assert len(templates)==args.templates,len(templates)
    if args.booked_label:
        tenant=call('dashboard')['tenant']
        workflow=tenant['business_rules']['workflow']
        assert workflow['bookedLabel']==args.booked_label
        evidence['checks']['industryWorkflow']='passed';evidence['workflow']=workflow
    evidence['checks']['bootstrapAndSeedTemplates']='passed';evidence['templateCount']=len(templates)
    record='platform,source_id,title\nxiaohongshu,frozen-qa-1,想预约看房\n'
    assert call('import_csv',{'content':record})['imported']==1
    assert call('import_csv',{'content':record})['duplicates']==1
    assert 'frozen-qa-1' in call('export_csv')['content']
    evidence['checks']['csvImportDedupeExport']='passed'
    assert len(call('list',{'entity':'leads'}))==1
    assert call('shutdown')['ok'] is True
    assert process.wait(timeout=10)==0
    evidence['checks']['gracefulShutdown']='passed'
finally:
    if process.poll() is None:process.terminate();process.wait(timeout=10)
    (ROOT/'work/build'/('frozen-qa-'+args.id+'.json')).write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(evidence,ensure_ascii=False))
