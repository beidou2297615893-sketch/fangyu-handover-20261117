"""Real native-window single-instance and shutdown smoke, isolated test database."""
import argparse,ctypes,http.cookiejar,json,subprocess,sys,time,urllib.request,uuid
from ctypes import wintypes
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--exe');args=parser.parse_args()
directory=ROOT/'work/desktop-qa'/('instance-'+uuid.uuid4().hex[:8]);directory.mkdir(parents=True)
command=([args.exe] if args.exe else [sys.executable,str(ROOT/'src/app.py')])+['--data-dir',str(directory)]
def windows(pid):
    found=[];user32=ctypes.windll.user32
    user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    user32.IsWindowVisible.argtypes=[wintypes.HWND]
    user32.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    def visit(handle,_):
        owner=wintypes.DWORD();user32.GetWindowThreadProcessId(handle,ctypes.byref(owner))
        if owner.value==pid and user32.IsWindowVisible(handle):
            title=ctypes.create_unicode_buffer(256);user32.GetWindowTextW(handle,title,256)
            if '运营台' in title.value:found.append({'handle':int(handle),'title':title.value})
        return True
    callback=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)(visit)
    user32.EnumWindows(callback,0);return found
log=(directory/'process.log').open('wb');process=subprocess.Popen(command,stdout=log,stderr=log,creationflags=0x08000000)
evidence={'dataDirectory':str(directory),'mode':'frozen' if args.exe else 'source'}
try:
    for _ in range(100):
        if process.poll() is not None:raise RuntimeError('native host exited early')
        running_path=directory/'running.json'
        running=json.loads(running_path.read_text('utf-8')) if running_path.exists() else {}
        found=windows(running.get('pid',process.pid))
        if found and running:break
        time.sleep(.2)
    assert len(found)==1,found
    running=json.loads((directory/'running.json').read_text('utf-8'));assert running['mode']=='desktop'
    duplicate=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000,timeout=15)
    assert duplicate.returncode==0
    after=windows(running['pid']);assert after==found
    opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def call(action,data=None):
        req=urllib.request.Request(running['url']+'/api',json.dumps({'action':action,'data':data or {}}).encode(),headers={'Content-Type':'application/json','X-Local-App':'1'})
        with opener.open(req,timeout=10) as res:return json.load(res)
    call('bootstrap',{'username':'native-qa','password':'[REDACTED:assigned_secret]'})
    call('shutdown');assert process.wait(timeout=15)==0
    assert not windows(running['pid'])
    evidence.update(nativeWindows=found,duplicateExit=duplicate.returncode,sameWindowRetained=True,shutdownExit=0,windowClosed=True)
finally:
    if process.poll() is None:process.terminate();process.wait(timeout=5)
    log.close()
    (ROOT/'work/build'/('desktop-instance-'+evidence['mode']+'.json')).write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(evidence,ensure_ascii=False))
