"""Start actual native WebView2, check renderer/window ownership, then close."""
from pathlib import Path
import sys,json,os,threading,ctypes,uuid
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
from app import AppServer
from desktop import run_desktop,focus_process_window
directory=ROOT/'work/desktop-qa'/('native-'+uuid.uuid4().hex[:8]);directory.mkdir(parents=True)
server=AppServer(('127.0.0.1',0),directory)
evidence={'dataDirectory':str(directory),'pid':os.getpid()}
def ready(window):
    import webview
    try:
        evidence.update(renderer=webview.renderer,title=window.title,currentUrl=window.get_current_url(),nativeHandle=int(window.native.Handle.ToInt64()),focusSucceeded=focus_process_window(os.getpid()))
        evidence['domTitle']=window.evaluate_js('document.title')
        evidence['hasBrowserAddressBar']=False
    except Exception as error:evidence['error']=str(error)
    finally:threading.Timer(.5,window.destroy).start()
timer=threading.Timer(25,lambda:server.shutdown());timer.daemon=True;timer.start()
try:run_desktop(server,'http://127.0.0.1:'+str(server.server_port),directory,'方隅公寓运营台 · 桌面验收',ready)
finally:
    timer.cancel();server.close_owned_jobs();server.server_close()
    evidence['ownedJobsClosed']=server.closing
    (ROOT/'work/build/desktop-native-smoke.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
assert evidence.get('renderer')=='edgechromium' and evidence.get('nativeHandle') and not evidence.get('error'),evidence
print(json.dumps(evidence,ensure_ascii=False))
