from pathlib import Path
import sys,json,threading,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
from app import AppServer
from desktop import run_desktop
folder=ROOT/'work/desktop-download-qa';folder.mkdir(exist_ok=True)
server=AppServer(('127.0.0.1',0),folder/'data');result={};started=False
expected='\ufeff姓名,备注\r\n本地验收,合成资料\r\n'
target=folder/'native-export.csv'
def ready(window):
 global started
 if started:return
 started=True
 try:
  from System import Action
  def setup():
   engine=window.native.browser.webview.CoreWebView2
   engine.DownloadStarting.__isub__(window.native.browser.on_download_starting)
   def download(sender,args):
    args.ResultFilePath=str(target);args.Handled=True
   engine.DownloadStarting.__iadd__(download)
   window._qa_download=download
  window.native.Invoke(Action(setup))
  window.evaluate_js('(()=>{const b=new Blob(['+json.dumps(expected)+'],{type:"text/csv;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="native-export.csv";a.click()})()')
  for _ in range(100):
   if target.exists() and target.read_bytes()==expected.encode():break
   time.sleep(.1)
  result.update(saved=target.exists(),bytesMatch=target.exists() and target.read_bytes()==expected.encode(),path=str(target))
 except Exception as e:result['error']=str(e)
 finally:window.destroy()
try:run_desktop(server,'http://127.0.0.1:'+str(server.server_port),folder/'data','本地文件保存验收',ready)
finally:
 server.server_close();(ROOT/'work/build/desktop-download-qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(result);assert result.get('bytesMatch'),result

