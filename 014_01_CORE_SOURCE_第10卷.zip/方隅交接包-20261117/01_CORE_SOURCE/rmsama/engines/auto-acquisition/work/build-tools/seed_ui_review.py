"""Seed only the isolated desktop-ui-qa HTTP instance; never run platform actions."""
import csv
import http.cookiejar
import io
import json
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = 'http://127.0.0.1:18766'
MARK = '【界面验收样例】'


def main():
    launcher = (ROOT / 'work/build-tools/desktop_ui_qa.py').read_text('utf-8')
    assert "directory=ROOT/'work/desktop-ui-qa'" in launcher
    assert "AppServer(('127.0.0.1',18766),directory)" in launcher
    client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def api(action, data=None):
        assert action in {'login', 'dashboard', 'list', 'save', 'import_csv'}
        request = urllib.request.Request(BASE + '/api', json.dumps({'action': action, 'data': data or {}}).encode(), {'Content-Type': 'application/json', 'X-Local-App': '1'})
        with client.open(request, timeout=15) as response:
            result = json.load(response)
        if isinstance(result, dict) and result.get('error'):
            raise RuntimeError(result['error'])
        return result

    auth = api('login', {'username': 'qa-local', 'password': '[REDACTED:assigned_secret]'})
    assert auth['user']['username'] == 'qa-local'
    tenant = api('dashboard')['tenant']
    assert '方隅' in tenant['name'], 'Unexpected tenant; no writes performed'
    existing = api('list', {'entity': 'accounts'})
    accounts = []
    for name in ['公寓主号', '门店服务号']:
        label = MARK + name
        record = next((r for r in existing if r.get('name') == label), None)
        if not record:
            record = api('save', {'entity': 'accounts', 'record': {'name': label, 'platform': 'xiaohongshu', 'status': 'login_required'}})
        accounts.append(record)
    tasks = api('list', {'entity': 'tasks'})
    task_ids = []
    for keyword, target in [('地铁租房', 1000), ('一居室', 500), ('短租公寓', 300)]:
        name = MARK + keyword
        record = next((r for r in tasks if r.get('name') == name), None)
        if not record:
            record = api('save', {'entity': 'tasks', 'record': {'name': name, 'platform': 'xiaohongshu', 'account_id': accounts[0]['id'], 'scope': 'search', 'keywords': [keyword], 'excludes': [], 'status': 'paused', 'target_count': target, 'daily_limit': 30, 'time_start': '09:00', 'time_end': '18:00', 'unknown_policy': 'keep'}})
        task_ids.append(record['id'])
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=['platform', 'source_id', 'title', 'author', 'text', 'source_type', 'demo'])
    writer.writeheader()
    for i, (name, text) in enumerate([('林同学', '预算2500，想下周入住，离地铁近吗？'), ('陈女士', '想了解一居室的房型和租金，周末可以看房吗？'), ('周先生', '需要短租三个月，请问目前有房吗？')], 1):
        writer.writerow({'platform': 'xiaohongshu', 'source_id': f'ui-review-synthetic-{i}', 'title': MARK + '公寓咨询', 'author': MARK + name, 'text': MARK + text, 'source_type': 'comment', 'demo': 'true'})
    imported = api('import_csv', {'content': output.getvalue()})
    leads = [r for r in api('list', {'entity': 'leads'}) if str(r.get('source_id', '')).startswith('ui-review-synthetic-')]
    print(json.dumps({'tenant': tenant['name'], 'import': imported, 'accounts': [r['id'] for r in accounts], 'paused_tasks': task_ids, 'leads': [{'id': r['id'], 'author': r['author'], 'demo': r.get('demo')} for r in leads]}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
