"""Reproducible local, unsigned bundles; no account or customer data copied."""
from pathlib import Path
import subprocess, sys, shutil, json, hashlib, datetime

ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'work'/'build'
OUT=ROOT/'outputs/方隅公寓客户端'
APP='方隅公寓运营台'
DEST=OUT/'方隅公寓运营台便携版'
PYTHON=ROOT/'work/vendor/cli-runtime/Scripts/python.exe'

def run(args, name):
    WORK.mkdir(parents=True,exist_ok=True)
    with (WORK/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([str(a) for a in args],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f'{name} failed: {WORK/(name+".log")}')
    print(name+' completed',flush=True)

def freeze(entry,name,console,collect=()):
    args=[PYTHON,'-m','PyInstaller','--noconfirm','--clean','--onedir',
          '--name',name,'--distpath',WORK/'dist','--workpath',WORK/'pyinstaller',
          '--specpath',WORK,'--paths',ROOT/'src','--console' if console else '--windowed']
    for module in collect: args.extend(['--collect-all',module])
    if not console:
        args.extend(['--add-data',str(ROOT/'src/web')+';web','--add-data',str(ROOT/'src/resources')+';resources'])
        args.extend(['--icon',str(ROOT/'src/resources/brand.ico')])
    args.append(entry)
    run(args,name)

def main():
    cli_only='--cli-only' in sys.argv
    app_only='--app-only' in sys.argv
    if not app_only:
        freeze(ROOT/'src/platform_cli.py','platform-cli',True,('xhs_cli','weibo_cli','camoufox','rich','playwright','qrcode','PIL','browserforge'))
    if not cli_only: freeze(ROOT/'src/app.py',APP,False,('webview','pythonnet','clr_loader'))
    if cli_only: return
    DEST.mkdir(parents=True,exist_ok=True)
    shutil.copytree(WORK/'dist'/APP,DEST,dirs_exist_ok=True)
    shutil.copytree(WORK/'dist/platform-cli',DEST/'platform-cli',dirs_exist_ok=True)
    bridge=ROOT/'work/runtime/douyin-bridge'
    if bridge.exists():
        bridge_destination=DEST/'douyin-bridge'
        resolved_destination=bridge_destination.resolve()
        if resolved_destination.parent!=DEST.resolve() or resolved_destination.name!='douyin-bridge':
            raise ValueError('Bridge destination escaped portable package')
        if bridge_destination.is_symlink():raise ValueError('Refusing to replace symlinked bridge destination')
        if bridge_destination.exists():shutil.rmtree(bridge_destination)
        shutil.copytree(bridge,bridge_destination)
    company_file=ROOT/'company.json'
    kuaishou=ROOT/'work/runtime/kuaishou-bridge'
    if kuaishou.exists():
        kuaishou_destination=DEST/'kuaishou-bridge'
        resolved=kuaishou_destination.resolve()
        if resolved.parent!=DEST.resolve() or resolved.name!='kuaishou-bridge' or kuaishou_destination.is_symlink():
            raise ValueError('Kuaishou destination escaped portable package')
        if kuaishou_destination.exists():shutil.rmtree(kuaishou_destination)
        shutil.copytree(kuaishou,kuaishou_destination)
    if company_file.exists():
        company=json.loads(company_file.read_text('utf-8-sig'))
        company.setdefault('runtime',{}).setdefault('executable',APP+'.exe')
        (DEST/'company.json').write_text(json.dumps(company,ensure_ascii=False,indent=2),encoding='utf-8')
    notices=ROOT/'outputs/开源组件与能力核验.md'
    if notices.exists(): shutil.copy2(notices,DEST/notices.name)
    (DEST/'启动说明.txt').write_text('双击 方隅公寓运营台.exe 打开独立桌面客户端。首次启动按界面创建管理员。\n需要 Windows 10/11、.NET Framework 4.6.2以上及免费的 Microsoft Edge WebView2 Runtime。\n缺少WebView2时前往 https://developer.microsoft.com/microsoft-edge/webview2/ 下载安装；本软件不会回退为浏览器页面，并非在所有Windows电脑完全离线免依赖运行。\n本软件及数据仅在本机运行；平台功能需使用自己的账号完成连接。\n安装包未签名。禁止将示例图片作为真实房源宣传。\n',encoding='utf-8-sig')
    rows=[]
    for p in sorted(DEST.rglob('*.exe')):
        rows.append({'file':str(p.relative_to(DEST)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (WORK/'build-manifest.json').write_text(json.dumps({'builtAt':datetime.datetime.now().isoformat(),'files':rows},ensure_ascii=False,indent=2),encoding='utf-8')
    print(str(DEST),flush=True)

if __name__=='__main__': main()
