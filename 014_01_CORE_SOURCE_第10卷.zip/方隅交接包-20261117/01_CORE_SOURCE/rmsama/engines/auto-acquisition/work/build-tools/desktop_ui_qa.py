"""Synthetic local QA login, native window retained for visual inspection."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
from app import AppServer
from desktop import run_desktop
directory=ROOT/'work/desktop-ui-qa';directory.mkdir(exist_ok=True)
server=AppServer(('127.0.0.1',18766),directory)
initialized=False
def ready(window):
    global initialized
    if initialized:return
    initialized=True
    action='login' if server.core.handle('status')['initialized'] else 'bootstrap'
    payload={'action':action,'data':{'username':'qa-local','password':'[REDACTED:assigned_secret]','company_name':'方隅公寓'}}
    script="fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Local-App':'1'},body:"+json.dumps(json.dumps(payload))+"}).then(r=>r.json()).then(x=>{if(x.error)throw Error(x.error);location.reload()})"
    window.evaluate_js(script)
try:run_desktop(server,'http://127.0.0.1:18766',directory,'方隅公寓运营台 · 原生界面验收',ready)
finally:server.close_owned_jobs();server.server_close()
