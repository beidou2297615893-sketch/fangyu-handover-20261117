from pathlib import Path
import subprocess, shutil, zipfile, hashlib, json
ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'work/build'
PYTHON=ROOT/'work/vendor/cli-runtime/Scripts/python.exe'
PORTABLE=ROOT/'outputs/方隅公寓客户端/方隅公寓运营台便携版'
NAME='方隅公寓运营台_安装程序'
WORK.mkdir(parents=True,exist_ok=True)
args=[str(PYTHON),'-m','PyInstaller','--noconfirm','--clean','--onefile','--windowed','--name',NAME,
      '--icon',str(ROOT/'src/resources/brand.ico'),'--add-data',str(ROOT/'src/resources/brand.ico')+';.', '--distpath',str(WORK/'installer-dist'),'--workpath',str(WORK/'installer-work'),'--specpath',str(WORK),str(ROOT/'work/build-tools/installer.py')]
with (WORK/'installer.log').open('w',encoding='utf-8') as log:
    subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
payload=WORK/'application-payload.zip'
with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in PORTABLE.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(PORTABLE).as_posix())
output=ROOT/'outputs/方隅公寓客户端'/(NAME+'.exe')
shutil.copy2(WORK/'installer-dist'/(NAME+'.exe'),output)
with output.open('ab') as dest,payload.open('rb') as source:shutil.copyfileobj(source,dest)
with zipfile.ZipFile(output) as z:
    bad=z.testzip()
    if bad: raise RuntimeError('Corrupt archive: '+bad)
probe=WORK/'installer-payload-probe.txt'
if probe.exists(): probe.unlink()
subprocess.run([str(output),'--verify-payload',str(probe)],check=True,timeout=120)
if not probe.exists():raise RuntimeError('Frozen installer failed to verify embedded payload')
manifest={'file':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'zipIntegrity':'passed','signed':False}
(WORK/'installer-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False),flush=True)
