

# --- ROUND5-20261112: video-level rent below brand floor gates comments without own budget ---
# Floor follows the current comment-budget hard gate: whole-home monthly below 3000 is out.
# Source: rules/预算时效交叉筛选纠正.md and rules/意向分级与预算口径-20261105.md
# and business_fit.budget()/screen(); exact per-store starting prices are documented as unconfirmed.
VIDEO_RENT_FLOOR=3000
REASON_LABELS['low_price_video_budget_mismatch']='低价视频-预算不符'
_R5_PREFIX=r'(?:月租|房租|租金|整租价|租了|租的是|现在租|只要|仅需|低至|现价|定价)'
_R5_UNIT=r'(?:开间|单间|一室(?:一厅)?|两室(?:一厅)?|一居(?:室)?|两居(?:室)?|套一|套二|整租|次卧|主卧|一室户)'
_R5_MONTH=r'(?:/月|一个月|每月|元/月|元一个月|块/月|块一个月)'
_R5_SKIP_PRE=re.compile(r'(?:押金|水电|电费|水费|网费|物业(?:费)?|停车|车位|中介费|首付|工资|以前|之前|原来|曾经|去年|当年|过去).{0,8}$')
_R5_SKIP_POST=re.compile(r'(?:米|平|㎡|平方|平米|层|号线|号|年|天|分钟|公里|度)')
_R5_PER=re.compile(r'每人|人均|一人|床位|一个床')
def _r5_post(row):
    c=row.get('classification') or {}; meta=c.get('original_metadata') or {}
    parts=[]
    for key in ('post_body','post_title','post_text','video_title','video_desc','caption','aweme_desc','desc','hashtags','video_tags','tags'):
        val=row.get(key) or meta.get(key)
        if val:
            if isinstance(val,(list,tuple)):
                parts.append(' '.join(str(x) for x in val if x))
            else:
                parts.append(str(val))
    return '\n'.join(parts)
def _r5_amount_from_match(group):
    parsed=number(group)
    if parsed is None:
        return None
    return parsed
def video_listed_rent(row):
    """Parse clearly stated whole-home monthly rents from the video's own text/tags."""
    post=_r5_post(row)
    if not post:
        return dict(state='unverified',floor=VIDEO_RENT_FLOOR,prices=[],quote=None,borderline=None)
    found=[]
    # prefix + amount, e.g. 月租850 / 租了850 / 租金1200/月
    for m in re.finditer(_R5_PREFIX+r'\s*('+N+r')\s*('+_R5_MONTH+r'|元|块)?', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R5_SKIP_PRE.search(pre):
            continue
        amt=_r5_amount_from_match(m.group(1))
        if amt is None or amt<100 or amt>20000:
            continue
        tail=post[m.end():m.end()+6]
        if _R5_SKIP_POST.match(tail):
            continue
        kind='per_person' if _R5_PER.search(pre) or _R5_PER.search(tail) else 'whole_home'
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    # amount + monthly suffix, e.g. 1200/月  800/月  850元一个月
    for m in re.finditer(r'('+N+r')\s*('+_R5_MONTH+r')', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R5_SKIP_PRE.search(pre):
            continue
        if _R5_PER.search(pre):
            kind='per_person'
        else:
            kind='whole_home'
        amt=_r5_amount_from_match(m.group(1))
        if amt is None or amt<100 or amt>20000:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    # amount immediately before or after a unit type: 850 开间 / 开间850 / 一室一厅1350
    for m in re.finditer(r'('+N+r')\s*(?:元|块)?\s*('+_R5_UNIT+r')', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R5_SKIP_PRE.search(pre) or _R5_SKIP_POST.match(tail):
            continue
        amt=_r5_amount_from_match(m.group(1))
        if amt is None or amt<100 or amt>20000:
            continue
        kind='per_person' if _R5_PER.search(pre) or '床位' in m.group(2) else 'whole_home'
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    for m in re.finditer(r'('+_R5_UNIT+r')\s*(?:只要|仅需|低至|仅|才)?\s*('+N+r')(?!\s*(?:米|平|㎡|层|号|年|天))', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R5_SKIP_PRE.search(pre):
            continue
        amt=_r5_amount_from_match(m.group(2))
        if amt is None or amt<100 or amt>20000:
            continue
        kind='per_person' if _R5_PER.search(pre) or '床位' in m.group(1) else 'whole_home'
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    # de-dup similar quotes
    uniq=[]
    seen=set()
    for item in found:
        key=(round(item['amount'],2), item['kind'])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(item)
    whole=[x for x in uniq if x['kind']=='whole_home']
    other=[x for x in uniq if x['kind']!='whole_home']
    borderline=None
    if not whole:
        if other:
            borderline='per_bed_or_per_person'
        return dict(state='unverified',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=None,borderline=borderline)
    lows=[x for x in whole if x['amount']<VIDEO_RENT_FLOOR]
    highs=[x for x in whole if x['amount']>=VIDEO_RENT_FLOOR]
    if lows and highs:
        return dict(state='mixed',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=lows[0]['quote']+'|'+highs[0]['quote'],borderline='mixed_prices')
    if lows and not highs:
        return dict(state='below_floor',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=lows[0]['quote'],borderline=None)
    return dict(state='at_or_above',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=highs[0]['quote'] if highs else None,borderline=None)

def _r5_own_budget_at_or_above_floor(fit):
    b=fit.get('budget') or {}
    if b.get('state') in ('budget_3000_3999_unverified','budget_at_least_4000'):
        return True
    for e in b.get('evidence') or []:
        if not (e.get('usable') or e.get('explicit_budget')):
            continue
        val=e.get('minimum') if e.get('minimum') is not None else e.get('nominal_amount')
        if val is not None and val>=VIDEO_RENT_FLOOR:
            return True
    return False

_screen_r4=screen
def screen(row, now=None):
    out=_screen_r4(row, now)
    info=video_listed_rent(row)
    out['video_listed_rent']=info
    if info.get('state')!='below_floor':
        return out
    if _r5_own_budget_at_or_above_floor(out):
        return out
    reasons=list(out['exclusion_reasons'])
    if 'low_price_video_budget_mismatch' not in reasons:
        reasons.append('low_price_video_budget_mismatch')
    out.update(exclusion_reasons=reasons,
               exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],
               eligible_candidate=False,eligible_priority=False,
               candidate_state='excluded',
               lead_intent='low',lead_intent_label='低意向',commercial_fit='very_low',
               video_gate_quote=info.get('quote'))
    return out
# --- end ROUND5-20261112 ---
