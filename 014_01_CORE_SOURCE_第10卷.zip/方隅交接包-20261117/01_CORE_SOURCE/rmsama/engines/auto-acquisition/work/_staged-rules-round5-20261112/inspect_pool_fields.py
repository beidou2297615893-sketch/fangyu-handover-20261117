# -*- coding: utf-8 -*-
import json
from collections import Counter
from pathlib import Path
FB=Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029")
pool=FB/"douyin-semantic-repair-v5"/"all-pool-business-fit.jsonl"
key_hits=Counter()
n=0
interesting=[]
first=None
with pool.open(encoding="utf-8") as f:
    for line in f:
        if not line.strip():
            continue
        r=json.loads(line)
        n+=1
        if first is None:
            first=sorted(r.keys())
            cls=r.get("classification")
            print("ALL KEYS", first)
            print("classification keys", sorted(cls.keys()) if isinstance(cls, dict) else type(cls))
        for k,v in r.items():
            if v not in (None,"",[],{}):
                key_hits[k]+=1
        for nest in ("classification","local_recheck","commercial_fit","source_observations","media_context","evidence"):
            obj=r.get(nest)
            if isinstance(obj, dict):
                for k,v in obj.items():
                    if v not in (None,"",[],{}):
                        key_hits[f"{nest}.{k}"]+=1
        blob=" ".join(str(r.get(k) or "") for k in ("post_body","post_title","post_text","comment_text"))
        if "850" in blob and len(interesting)<8:
            interesting.append({k:r.get(k) for k in ("comment_id","comment_text","post_body","post_title","post_text","video_id","source_keyword","media_context")})
print("N", n)
print("--- nonempty field counts ---")
for k,c in sorted(key_hits.items(), key=lambda x:-x[1]):
    if any(s in k.lower() for s in ("post","title","tag","caption","video","desc","cover","aweme","body","source_keyword","media","topic")):
        print(f" {c:6d} {k}")
print("--- 850 samples ---")
for it in interesting:
    print(it)
