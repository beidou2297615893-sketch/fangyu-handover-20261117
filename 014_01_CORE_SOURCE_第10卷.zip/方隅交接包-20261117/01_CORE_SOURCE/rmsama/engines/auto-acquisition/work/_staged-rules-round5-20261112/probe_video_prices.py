# -*- coding: utf-8 -*-
import json, sys, re
from collections import Counter
from pathlib import Path
R=Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work")
FB=R/"fangyu-text-business-20261029"
ST=R/"_staged-rules-round5-20261112"
sys.path.insert(0, str(FB/"business-fit"))
sys.path.insert(0, str(FB/"recency-priority"))
import business_fit as f

pool=FB/"douyin-semantic-repair-v5"/"all-pool-business-fit.jsonl"

# How current advertised_rent works on known example
ex="上城区 东站地铁口260米 850 开间一室一厅+衣帽间 小情侣住了2年 换新房子 刚搬走几天 包网包物业#杭州租房 #东站租房 #彭埠租房 #开启工作模式 #随时看房拎包入住"
print("CURRENT advertised_rent on 850 example:", f.advertised_rent({"post_body":ex,"platform":"douyin"}))
print("CURRENT advertised_rent 租了850:", f.advertised_rent({"post_body":"这间房子租了850","platform":"douyin"}))
print("CURRENT advertised_rent 月租850:", f.advertised_rent({"post_body":"月租850 开间","platform":"douyin"}))
print("CURRENT advertised_rent 一室一厅1350:", f.advertised_rent({"post_body":"杭州一室一厅1350的小屋","platform":"douyin"}))

# scan pool uniqueness by video
videos={}
n=0
where_re=re.compile(r"在哪|哪里|哪儿|哪个位置|哪个小区|哪个区|什么位置|什么地方|地址|定位|这是哪")
with pool.open(encoding="utf-8") as fobj:
    for line in fobj:
        if not line.strip():
            continue
        r=json.loads(line)
        n+=1
        vid=str(r.get("video_id") or "")
        post=r.get("post_body") or ""
        if vid not in videos:
            parsed=f.advertised_rent({"post_body":post,"platform":"douyin"})
            videos[vid]={"post":post,"n":0,"where":0,"parsed":parsed,"comments":[]}
        videos[vid]["n"]+=1
        t=r.get("comment_text") or ""
        if where_re.search(t):
            videos[vid]["where"]+=1
            if len(videos[vid]["comments"])<3:
                videos[vid]["comments"].append(t)

print("pool comments", n, "unique videos", len(videos))
with_parse=sum(1 for v in videos.values() if v["parsed"])
print("videos with current advertised_rent", with_parse)
# below 3000 by current parser
below=[]
for vid,v in videos.items():
    rents=v["parsed"]
    if not rents: continue
    states=[p["budget"]["state"] for p in rents]
    # use evidence amounts
    amts=[]
    for p in rents:
        for e in p["budget"].get("evidence") or []:
            if e.get("nominal_amount"):
                amts.append(e["nominal_amount"])
    if amts and max(amts)<3000:
        below.append((vid, amts, v["post"][:80], v["n"], v["where"], v["comments"]))
print("videos all parsed amounts <3000 (current parser)", len(below))
for item in below[:8]:
    print(" ", item[1], "comments", item[3], "where", item[4], item[2].replace("\n"," ")[:100])

# count post_body with raw low numbers near rental words
raw=0
samples=[]
amt=re.compile(r"(?:租了|月租|租金|房租|只要|仅需|低至)?\s*(\d{3,5}|[一二两三四五六七八九][百千][一二两三四五六七八九]?|[1-9](?:\.\d+)?[kK])\s*(?:/月|一个月|每月|元|块)?")
for vid,v in videos.items():
    post=v["post"]
    if re.search(r"(850|1200|1k|八百|一千|开间.{0,6}\d{3,4}|\d{3,4}\s*开间|\d{3,4}\s*/月|租了\s*\d{3,4})", post, re.I):
        raw+=1
        if len(samples)<10:
            samples.append((vid, post.replace("\n"," ")[:140], v["n"], v["where"], v["comments"], bool(v["parsed"])))
print("videos with raw low-price-like patterns", raw)
for s in samples:
    print(" parsed" if s[5] else " UNPARSED", "n", s[2], "where", s[3], s[1])
