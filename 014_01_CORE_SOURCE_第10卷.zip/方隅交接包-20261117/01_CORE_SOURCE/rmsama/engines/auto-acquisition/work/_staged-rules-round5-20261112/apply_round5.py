# -*- coding: utf-8 -*-
"""Apply staged round-5 business_fit.py to the live path.

Safety: does nothing unless --i-understand-live-apply is passed.
Backs up the live file first, then copies the staged copy in.
Do not run it while a send batch is in progress.
"""
import argparse, hashlib, json, shutil, sys
from datetime import datetime
from pathlib import Path

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
STAGED=R/'_staged-rules-round5-20261112'
BACKUP=R/'_backup-filter-fix-20261112'/'round5'
LIVE=FB/'business-fit'/'business_fit.py'
STAGED_FILE=STAGED/'business-fit'/'business_fit.py'

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--i-understand-live-apply', action='store_true')
    args=parser.parse_args()
    if not STAGED_FILE.is_file() or not LIVE.is_file():
        print('missing file', file=sys.stderr); return 1
    print('live', sha256(LIVE))
    print('staged', sha256(STAGED_FILE))
    if not args.i_understand_live_apply:
        print('Refusing to modify live files. Re-run with --i-understand-live-apply after confirming sending is stopped.')
        return 2
    BACKUP.mkdir(parents=True, exist_ok=True)
    shutil.copy2(LIVE, BACKUP/'business_fit.py')
    # also keep renderer snapshot, unchanged
    rend=FB/'douyin-semantic-repair-v5'/'base_renderer.py'
    if rend.is_file():
        shutil.copy2(rend, BACKUP/'base_renderer.py')
    shutil.copy2(STAGED_FILE, LIVE)
    report={
        'time': datetime.now().isoformat(),
        'before': sha256(BACKUP/'business_fit.py'),
        'after': sha256(LIVE),
        'staged': sha256(STAGED_FILE),
        'backup_dir': str(BACKUP),
        'same_as_staged': sha256(LIVE)==sha256(STAGED_FILE),
    }
    (BACKUP/'change-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8')
    print('applied', report['after'])
    print('wrote', BACKUP/'change-report.json')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
