# -*- coding: utf-8 -*-
"""Read-only verify after live apply. No ledger writes, no sending."""
import hashlib, json, sqlite3, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
LIVE=FB/'business-fit'/'business_fit.py'
STAGED=R/'_staged-rules-round5-20261112'/'business-fit'/'business_fit.py'
CUR=FB/'recency-priority'/'daily-priority'/'current.json'
LEDGER=R/'shared-acquisition-ledger'/'shared.sqlite3'
SHANGHAI=timezone(timedelta(hours=8))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

live=sha(LIVE)
staged=sha(STAGED)
print('live_sha', live)
print('staged_sha', staged)
print('live_matches_staged', live==staged)

cur=json.loads(CUR.read_text(encoding='utf-8'))
updated=cur.get('updated_at')
print('current.updated_at raw', updated)
# convert to Shanghai
try:
    dt=datetime.fromisoformat(updated.replace('Z','+00:00')).astimezone(SHANGHAI)
    print('current.updated_at Asia/Shanghai', dt.strftime('%Y-%m-%d %H:%M:%S'), 'Asia/Shanghai')
except Exception as e:
    print('parse updated_at failed', e)

code_sha=((cur.get('platforms') or {}).get('douyin') or {}).get('commercial_fit',{}).get('code_sha256') or (cur.get('commercial_fit') or {}).get('code_sha256')
# also search recursively
def find_sha(obj, acc=None):
    acc=acc or []
    if isinstance(obj, dict):
        if 'code_sha256' in obj:
            acc.append(obj['code_sha256'])
        for v in obj.values():
            find_sha(v, acc)
    elif isinstance(obj, list):
        for v in obj:
            find_sha(v, acc)
    return acc
shas=find_sha(cur)
print('code_sha256 values in current.json', shas)
print('queue_built_with_live', live in shas)

qpath=Path(cur['platforms']['douyin']['queue'])
print('queue', qpath.name, 'full', qpath)
rows=[]
with qpath.open(encoding='utf-8') as f:
    for line in f:
        if line.strip():
            rows.append(json.loads(line))
print('queue_rows', len(rows))

# full brand name
def blob(r):
    parts=[]
    for k in ('text','reply','reply_text','message','body','rendered','draft','content','final_text','payload'):
        v=r.get(k)
        if v:
            parts.append(str(v))
    # nested
    for nest in ('render','rendered','drafts','reply_payload'):
        v=r.get(nest)
        if isinstance(v, dict):
            parts.append(json.dumps(v, ensure_ascii=False))
        elif v and not isinstance(v, (list,dict)):
            parts.append(str(v))
    return '\n'.join(parts)

# inspect keys once
if rows:
    print('row_keys', sorted(rows[0].keys()))

missing_full=0
has_fangyu=0
short_only=0
for r in rows:
    t=blob(r)
    # also search all string values
    if not t:
        t=' '.join(str(v) for v in r.values() if isinstance(v,str))
    if '方隅公寓' in t:
        has_fangyu+=1
    else:
        missing_full+=1
        if '方隅' in t:
            short_only+=1
print('full_name_方隅公寓', has_fangyu, 'missing_full', missing_full, 'short_only_方隅', short_only)

# earlier leftover phrases from r4/r4b
phrases=['你要哪个位置的喃','你要哪边的','你想要哪块的','你在哪个区找','你要什么位置','你想租哪里的房子']
earlier=0
hits=[]
for r in rows:
    txt=r.get('comment_text') or r.get('text') or ''
    for p in phrases:
        if p in txt:
            earlier+=1
            hits.append((p, txt[:80]))
            break
print('earlier_class1_leftovers', earlier, hits[:5])

# new gate leftovers: comments under clearly 850-style shouldn't remain if no own budget
# just report if any of the dry-run newly-excluded ids are still in queue
report_path=R/'_staged-rules-round5-20261112'/'temp-output'/'dryrun-round5-report.json'
if report_path.is_file():
    dry=json.loads(report_path.read_text(encoding='utf-8'))
    new_ids={str(x.get('comment_id')) for x in dry.get('all_newly') or []}
    qids={str(r.get('comment_id')) for r in rows}
    still=sorted(new_ids & qids)
    print('dryrun_newly_still_in_queue', len(still), still[:10])

# ledger overlap read-only
overlap={'sent':0,'unknown':0,'reserved':0}
ids=[str(r.get('comment_id')) for r in rows if r.get('comment_id')]
if ids:
    uri=f'file:{LEDGER.as_posix()}?mode=ro'
    conn=sqlite3.connect(uri, uri=True)
    try:
        qmarks=','.join('?'*len(ids))
        # leads
        try:
            rows_db=conn.execute(f"SELECT comment, status FROM leads WHERE platform=? AND comment IN ({qmarks})", ['douyin', *ids]).fetchall()
        except Exception:
            rows_db=conn.execute(f"SELECT comment, status FROM leads WHERE comment IN ({qmarks})", ids).fetchall()
        for comment, status in rows_db:
            st=(status or '').lower()
            if st in overlap:
                overlap[st]+=1
            elif 'send' in st or st in ('replied','done','success'):
                overlap['sent']+=1
        # reservations
        try:
            res=conn.execute(f"SELECT comment, status FROM reservations WHERE comment IN ({qmarks})", ids).fetchall()
            for comment, status in res:
                overlap['reserved']+=1
        except Exception as e:
            print('reservations query skip', type(e).__name__)
    finally:
        conn.close()
print('ledger_overlap', overlap)
print('overlap_zero', all(v==0 for v in overlap.values()))
