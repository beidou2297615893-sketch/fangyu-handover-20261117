# -*- coding: utf-8 -*-
"""Round 5 (2026-11-12): video-level rent below the brand floor gates comments without their own budget."""
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'business-fit'))
sys.path.insert(0, str(ROOT / 'recency-priority'))
import business_fit as f

FLOOR = 3000

def row(comment, post, **extra):
    data = {
        'comment_text': comment,
        'post_body': post,
        'platform': 'douyin',
        'role': 'demand',
        'published_at_unix': time.time() - 86400 * 8,
        'video_id': extra.pop('video_id', 'v-low-850'),
    }
    data.update(extra)
    return data


class Round5(unittest.TestCase):
    def test_floor_matches_current_budget_gate(self):
        self.assertEqual(f.VIDEO_RENT_FLOOR, FLOOR)
        self.assertEqual(f.REASON_LABELS['low_price_video_budget_mismatch'], '低价视频-预算不符')

    def test_parses_common_video_price_forms(self):
        cases = {
            '上城区 东站地铁口260米 850 开间一室一厅+衣帽间 #杭州租房': 850,
            '这间房子租了850': 850,
            '大兴800/月 首月免费 整租': 800,
            '一个人带一只小金毛 勇闯上海 1200 小公寓': None,  # 小公寓 is not a unit keyword; covered below if needed
            '月租1200': 1200,
            '房租八百五': 850,
            '租金1k/月': 1000,
            '杭州一室一厅1350的小屋': 1350,
            '开间850 包网包物业': 850,
        }
        # 1200 小公寓: no unit keyword; allow either unverified or parsed if we later add 小公寓. For now document.
        got = f.video_listed_rent(row('在哪', '一个人带一只小金毛 勇闯上海 1200 小公寓'))
        # Not required to catch 小公寓 without a unit/month word; main listing forms must work.
        for post, expected in cases.items():
            if expected is None:
                continue
            with self.subTest(post=post):
                info = f.video_listed_rent(row('在哪', post))
                self.assertEqual(info['state'], 'below_floor', info)
                self.assertTrue(any(p['amount'] == expected for p in info['prices']), info)

    def test_where_comments_under_low_price_video_excluded(self):
        post = '上城区 东站地铁口260米 850 开间一室一厅+衣帽间 包网包物业#杭州租房'
        for comment in ['在哪', '这是哪里？', '哪个小区', '在哪个位置', '哪里呀']:
            with self.subTest(comment=comment):
                s = f.screen(row(comment, post))
                self.assertFalse(s['eligible_candidate'], s)
                self.assertIn('low_price_video_budget_mismatch', s['exclusion_reasons'])
                self.assertIn('低价视频-预算不符', s['exclusion_reason_labels'])

    def test_own_budget_at_or_above_floor_still_counts(self):
        post = '这间房子租了850，开间一室一厅'
        s = f.screen(row('预算5000求租，这是哪里', post))
        self.assertNotIn('low_price_video_budget_mismatch', s['exclusion_reasons'])
        self.assertTrue(s['eligible_candidate'] or 'budget_' in str(s.get('verification_required')), s)
        s2 = f.screen(row('预算3500，想租，在哪', post))
        self.assertNotIn('low_price_video_budget_mismatch', s2['exclusion_reasons'])

    def test_high_price_or_unpriced_video_not_gated(self):
        s = f.screen(row('这是哪里', '上海古北 月租8500 一室一厅'))
        self.assertNotIn('low_price_video_budget_mismatch', s['exclusion_reasons'])
        s2 = f.screen(row('上海租哪里合适呀', '分享一下今天的探店日常#上海生活'))
        self.assertNotIn('low_price_video_budget_mismatch', s2['exclusion_reasons'])
        self.assertTrue(s2['eligible_candidate'], s2)
        s3 = f.screen(row('有没有单间出租', '附近好房推荐，欢迎咨询'))
        self.assertNotIn('low_price_video_budget_mismatch', s3['exclusion_reasons'])
        self.assertTrue(s3['eligible_candidate'], s3)

    def test_deposit_utilities_parking_not_treated_as_rent(self):
        for post in ['押金850，月租5000 一室一厅', '电费850怎么算的，房租4500', '地上地下停车位仅500/月 一室一厅4500起']:
            with self.subTest(post=post):
                info = f.video_listed_rent(row('在哪', post))
                self.assertNotEqual(info['state'], 'below_floor', info)

    def test_per_bed_and_mixed_prices_are_borderline_not_gated(self):
        bed = f.video_listed_rent(row('在哪', '床位800一个月，上下铺'))
        self.assertNotEqual(bed['state'], 'below_floor', bed)
        mixed = f.video_listed_rent(row('在哪', '一室2000，两室5000，都有，随时看房'))
        self.assertEqual(mixed['state'], 'mixed', mixed)
        s = f.screen(row('这是哪里', '一室2000，两室5000，都有，随时看房'))
        self.assertNotIn('low_price_video_budget_mismatch', s['exclusion_reasons'])

    def test_vague_hundreds_or_thousands_are_not_a_listed_rent(self):
        # "几百整租" must not parse as 100; "近千/月" must not parse as 1000.
        for post in ['几百整租民用水电 免费停车 被坑了吗？#杭州租房', '近千/月的小单间分享', '几千整租值得吗']:
            with self.subTest(post=post):
                info = f.video_listed_rent(row('在哪', post))
                self.assertNotEqual(info['state'], 'below_floor', info)
                self.assertFalse(info.get('prices'), info)
        s = f.screen(row('在临平哪里', '几百整租民用水电 免费停车 被坑了吗？#杭州租房'))
        self.assertNotIn('low_price_video_budget_mismatch', s['exclusion_reasons'])

    def test_existing_where_demand_without_low_price_video_kept(self):
        for comment in ['养狗狗租哪里？', '哪里有房子租', '附近有房子租吗']:
            with self.subTest(comment=comment):
                s = f.screen(row(comment, '今天路过拍了一下这个小区的绿化#生活'))
                self.assertNotIn('low_price_video_budget_mismatch', s['exclusion_reasons'])
                self.assertTrue(s['eligible_candidate'], s)


if __name__ == '__main__':
    unittest.main()
