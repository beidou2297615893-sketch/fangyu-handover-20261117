# -*- coding: utf-8 -*-
"""Read-only: print lines in live collection entry files that name rules, keywords, stores, windows."""
from pathlib import Path
from datetime import datetime

R=Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work")
IND=R/"fangyu-douyin-independent"
FB=R/"fangyu-text-business-20261029"
keys=("keyword","csv",".json","store","辐射","门店","城市","福州","杭州","闽清","上海","北京","成都",
      "30","60","7","window","retention","recent","scope","plan","word","search","budget","3000",
      "path","WORDS","KEYWORD","csv_path","wordlist","rotation","rotate","group","外地","cutoff",
      "mother","slot","reply","qualification","policy","radiation","city","minqing","fuzhou")

files=[
    IND/"current_collection.py",
    IND/"continue_collection.py",
    IND/"new_round.py",
    IND/"collection_startup.py",
    IND/"collection_confirmed_scope.py",
    IND/"auto_collect.py",
    IND/"current_collection.py",
]
# also list json status files (safe names only)
status_files=[
    IND/"active-runner.json",
    IND/"current-collection-status.json",
    IND/"current-collection-supervisor.json",
    IND/"classification-handoff-status.json",
]

def show_file(path, extra=()):
    print("\n========", path, "========")
    if not path.is_file():
        print("MISSING"); return
    print("mtime", datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"), "size", path.stat().st_size)
    text=path.read_text(encoding="utf-8", errors="replace")
    pats=tuple(k.lower() for k in keys)+extra
    for i,line in enumerate(text.splitlines(),1):
        low=line.lower()
        if any(p in low or p in line for p in pats):
            s=line.rstrip()
            # skip huge line
            if len(s)>240: s=s[:240]+"..."
            # skip comments that are just separators
            print(f"{i:4d}|{s}")

for p in files:
    show_file(p)

print("\n======== status json (redact identity) ========")
skip=("cookie","cookies","session","token","authorization","password","secret","sec_uid","mstoken","identity","web_protect")
for p in status_files:
    print("\n--", p.name, "--")
    if not p.is_file():
        print("MISSING"); continue
    print("mtime", datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"))
    try:
        data=__import__("json").loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print("not json", e); continue
    def brief(o, prefix="", depth=0):
        if depth>4: return
        if isinstance(o, dict):
            for k,v in o.items():
                if any(s in k.lower() for s in skip):
                    print(f"{prefix}{k}=<redacted>")
                    continue
                if isinstance(v, (dict,list)):
                    if isinstance(v, list) and v and not isinstance(v[0], (dict,list)):
                        print(f"{prefix}{k}=list[{len(v)}] sample={v[:8]}")
                    else:
                        print(f"{prefix}{k}:")
                        brief(v, prefix+"  ", depth+1)
                else:
                    s=str(v)
                    if len(s)>200: s=s[:200]+"..."
                    print(f"{prefix}{k}={s}")
        elif isinstance(o, list):
            print(f"{prefix}list[{len(o)}]")
            if o: brief(o[0], prefix+"  [0].", depth+1)
    brief(data)
