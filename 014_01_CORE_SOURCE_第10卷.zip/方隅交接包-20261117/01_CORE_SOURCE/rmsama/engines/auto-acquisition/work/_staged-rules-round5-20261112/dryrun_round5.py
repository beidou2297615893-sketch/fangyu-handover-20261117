# -*- coding: utf-8 -*-
import importlib.util, json, sys, time
from collections import defaultdict
from pathlib import Path

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
ST=R/'_staged-rules-round5-20261112'
OUT=ST/'temp-output'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ST/'recency-priority'))

def load(name, path):
    spec=importlib.util.spec_from_file_location(name, path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

old=load('bf_old', FB/'business-fit'/'business_fit.py')
new=load('bf_new', ST/'business-fit'/'business_fit.py')

def text(row):
    c=row.get('classification') or {}
    return row.get('comment_text') or row.get('text') or c.get('comment_text') or ''

cur=json.loads((FB/'recency-priority'/'daily-priority'/'current.json').read_text(encoding='utf-8'))
qpath=Path(cur['platforms']['douyin']['queue'])
sendable=set()
with qpath.open(encoding='utf-8') as f:
    for line in f:
        if line.strip():
            sendable.add(str(json.loads(line).get('comment_id') or ''))
print('current queue', qpath.name, 'n', len(sendable), 'updated', cur.get('updated_at'))

gated_videos={}
newly=[]
borderline_videos={}
parseable_videos=set()
total=0
t0=time.time()
with (FB/'douyin-semantic-repair-v5'/'all-pool-business-fit.jsonl').open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        row=json.loads(line)
        total+=1
        vid=str(row.get('video_id') or '')
        info=new.video_listed_rent(row)
        if info.get('prices'):
            parseable_videos.add(vid)
        if info.get('state')=='below_floor':
            rec=gated_videos.setdefault(vid, {
                'video_id': vid,
                'post': (row.get('post_body') or '')[:200],
                'quote': info.get('quote'),
                'prices': [p['amount'] for p in info.get('prices') or []],
                'comments': 0,
                'newly': 0,
                'in_queue': 0,
                'samples': [],
            })
            rec['comments']+=1
        elif info.get('borderline') or info.get('state')=='mixed':
            borderline_videos.setdefault(vid, {
                'video_id': vid,
                'post': (row.get('post_body') or '')[:180],
                'state': info.get('state'),
                'borderline': info.get('borderline'),
                'quote': info.get('quote'),
                'prices': info.get('prices'),
            })
        b=old.screen(row)
        s=new.screen(row)
        if b['eligible_candidate'] and not s['eligible_candidate']:
            item={
                'comment_id': row.get('comment_id'),
                'video_id': vid,
                'text': text(row),
                'in_sendable': str(row.get('comment_id') or '') in sendable,
                'reasons': s.get('exclusion_reasons'),
                'labels': s.get('exclusion_reason_labels'),
                'quote': (s.get('video_listed_rent') or {}).get('quote'),
                'post': (row.get('post_body') or '')[:160],
            }
            newly.append(item)
            if vid in gated_videos:
                gated_videos[vid]['newly']+=1
                if item['in_sendable']:
                    gated_videos[vid]['in_queue']+=1
                if len(gated_videos[vid]['samples'])<3:
                    gated_videos[vid]['samples'].append(item['text'])

print('pool', total, 'elapsed', round(time.time()-t0,2))
print('unique videos with parseable listed rent', len(parseable_videos))
print('videos gated below floor', len(gated_videos))
print('newly excluded comments', len(newly), 'in current sendable', sum(1 for x in newly if x['in_sendable']))
print('borderline videos', len(borderline_videos))

# 10 gated video samples, prefer those with more comments / in queue
ranked=sorted(gated_videos.values(), key=lambda v: (-v['in_queue'], -v['newly'], -v['comments']))
print('--- 10 gated videos ---')
for v in ranked[:10]:
    post=v['post'].replace('\n',' ')
    print(f" prices={v['prices']} quote={v['quote']} comments={v['comments']} newly={v['newly']} in_queue={v['in_queue']}")
    print(f"  {post[:160]}")
    if v['samples']:
        print('  comments:', ' | '.join(v['samples']))

print('--- newly excluded in current queue ---')
qnew=[x for x in newly if x['in_sendable']]
for x in qnew[:20]:
    print(x['comment_id'], x['text'][:80], '|', x['quote'], '|', (x['post'] or '').replace('\n',' ')[:80])

print('--- borderline samples ---')
for i,v in enumerate(list(borderline_videos.values())[:12],1):
    print(i, v['state'], v['borderline'], v['quote'], (v['post'] or '').replace('\n',' ')[:140])

report={
    'pool': total,
    'current_queue': str(qpath),
    'current_queue_count': len(sendable),
    'updated_at': cur.get('updated_at'),
    'parseable_videos': len(parseable_videos),
    'gated_videos': len(gated_videos),
    'newly_excluded': len(newly),
    'newly_in_sendable': sum(1 for x in newly if x['in_sendable']),
    'borderline_videos': len(borderline_videos),
    'gated_samples': ranked[:10],
    'queue_new_samples': qnew[:30],
    'borderline_samples': list(borderline_videos.values())[:20],
    'all_newly': newly,
}
(OUT/'dryrun-round5-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('wrote', OUT/'dryrun-round5-report.json')
