# -*- coding: utf-8 -*-
import json, sqlite3
from pathlib import Path
from collections import Counter
R=Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work")
FB=R/"fangyu-text-business-20261029"
LEDGER=R/"shared-acquisition-ledger"/"shared.sqlite3"
cur=json.loads((FB/"recency-priority"/"daily-priority"/"current.json").read_text(encoding="utf-8"))
q=Path(cur["platforms"]["douyin"]["queue"])
ids=[]
with q.open(encoding="utf-8") as f:
    for line in f:
        if line.strip():
            ids.append(str(json.loads(line).get("comment_id") or ""))
ids=[x for x in ids if x]
uri="file:"+LEDGER.as_posix()+"?mode=ro"
conn=sqlite3.connect(uri, uri=True)
qmarks=",".join("?"*len(ids))
# all distinct lead statuses in whole ledger (counts only)
print("all leads status counts:")
for r in conn.execute("SELECT status, count(*) FROM leads GROUP BY status"):
    print(" ", r)
print("all reservations status counts:")
for r in conn.execute("SELECT status, count(*) FROM reservations GROUP BY status"):
    print(" ", r)
rows=conn.execute("SELECT comment, status, source, operator, review_time, substr(evidence,1,180) FROM leads WHERE comment IN (%s) AND status='unverified'" % qmarks, ids).fetchall()
print("unverified in this queue", len(rows))
sources=Counter(); operators=Counter()
for comment, status, source, operator, review_time, ev in rows:
    sources[source]+=1
    operators[operator]+=1
print("sources", sources)
print("operators", operators)
print("samples:")
for rec in rows[:5]:
    comment, status, source, operator, review_time, ev=rec
    print(" ", comment, "source=", source, "operator=", operator, "review_time=", review_time, "evidence=", ev)
# exact unknown / sent in this queue
for st in ("unknown","sent","replied","done","success","failed","unverified"):
    n=conn.execute("SELECT count(*) FROM leads WHERE comment IN (%s) AND status=?" % qmarks, [*ids, st]).fetchone()[0]
    print("queue leads status", st, n)
conn.close()
# also compare with previous queue file if still on disk
prev=FB/"recency-priority"/"daily-priority"
# list recent douyin queues
qs=sorted(prev.glob("douyin-*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)[:8]
print("recent queues:")
for p in qs:
    print(" ", p.name, p.stat().st_mtime, p.stat().st_size)
