# -*- coding: utf-8 -*-
"""Apply staged round-4 rule files to the live paths.

Safety: this script does nothing unless you pass --i-understand-live-apply.
It backs up the live files first, then copies the staged copies in.
Do not run it while a send batch is in progress: watch_increment.py will
rebuild daily-priority when the live files change.
"""
import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

R = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB = R / 'fangyu-text-business-20261029'
STAGED = R / '_staged-rules-round4-20261111'
BACKUP = R / '_backup-filter-fix-20261111' / 'round4'

LIVE = {
    'business_fit.py': FB / 'business-fit' / 'business_fit.py',
    'base_renderer.py': FB / 'douyin-semantic-repair-v5' / 'base_renderer.py',
}
STAGED_FILES = {
    'business_fit.py': STAGED / 'business-fit' / 'business_fit.py',
    'base_renderer.py': STAGED / 'douyin-semantic-repair-v5' / 'base_renderer.py',
}

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description='Apply staged round-4 rules to live files after backup.')
    parser.add_argument('--i-understand-live-apply', action='store_true',
                        help='Required. Without this flag the script only prints a dry plan and exits 2.')
    args = parser.parse_args()

    for name, path in STAGED_FILES.items():
        if not path.is_file():
            print('missing staged file:', path, file=sys.stderr)
            return 1
    for name, path in LIVE.items():
        if not path.is_file():
            print('missing live file:', path, file=sys.stderr)
            return 1

    before = {str(path): sha256(path) for path in LIVE.values()}
    staged = {name: sha256(path) for name, path in STAGED_FILES.items()}
    print('live business_fit.py', before[str(LIVE['business_fit.py'])])
    print('live base_renderer.py', before[str(LIVE['base_renderer.py'])])
    print('staged business_fit.py', staged['business_fit.py'])
    print('staged base_renderer.py', staged['base_renderer.py'])

    if not args.i_understand_live_apply:
        print('Refusing to modify live files. Re-run with --i-understand-live-apply after the current send batch finishes.')
        return 2

    BACKUP.mkdir(parents=True, exist_ok=True)
    for name, path in LIVE.items():
        dest = BACKUP / name
        shutil.copy2(path, dest)
        print('backed up', path, '->', dest, sha256(dest))

    after_plan = {}
    for name, dest in LIVE.items():
        src = STAGED_FILES[name]
        shutil.copy2(src, dest)
        after_plan[str(dest)] = sha256(dest)
        print('copied', src, '->', dest, after_plan[str(dest)])

    report = {
        'time': datetime.now().isoformat(),
        'before': before,
        'after': after_plan,
        'staged': staged,
        'backup_dir': str(BACKUP),
        'same_as_staged': {name: after_plan[str(LIVE[name])] == staged[name] for name in LIVE},
    }
    report_path = BACKUP / 'change-report.json'
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8')
    print('wrote', report_path)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
