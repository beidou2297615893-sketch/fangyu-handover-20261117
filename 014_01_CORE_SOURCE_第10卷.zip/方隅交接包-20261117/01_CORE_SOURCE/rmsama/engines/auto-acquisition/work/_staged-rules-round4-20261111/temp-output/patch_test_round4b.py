# -*- coding: utf-8 -*-
from pathlib import Path
p = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_staged-rules-round4-20261111\test_round4_20261111.py')
t = p.read_text(encoding='utf-8')
old = "        '有的 你打算租哪里的房子 可以帮你推荐一下[比心]',\n    ],"
new = (
    "        '有的 你打算租哪里的房子 可以帮你推荐一下[比心]',\n"
    "        '你要哪个位置的喃',\n"
    "        '你要哪边的',\n"
    "        '你想要哪块的',\n"
    "        '你在哪个区找',\n"
    "        '你要什么位置',\n"
    "    ],"
)
if old not in t:
    raise SystemExit('exclude block not found')
t = t.replace(old, new, 1)
old2 = "    '马上淡季了，我想现在找房便宜点',\n]"
new2 = "    '马上淡季了，我想现在找房便宜点',\n    '哪里有房子租',\n]"
if old2 not in t:
    raise SystemExit('keep block not found')
t = t.replace(old2, new2, 1)
p.write_text(t, encoding='utf-8')
print('ok')
