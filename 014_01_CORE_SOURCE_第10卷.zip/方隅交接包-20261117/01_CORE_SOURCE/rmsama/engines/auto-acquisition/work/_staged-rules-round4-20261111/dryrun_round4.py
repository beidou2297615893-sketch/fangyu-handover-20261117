# -*- coding: utf-8 -*-
"""Read-only dry-run of staged round-4 business_fit against the live pool.
Writes only into the staged temp-output directory. Does not touch live files.
"""
import importlib.util
import json
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

R = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB = R / 'fangyu-text-business-20261029'
ST = R / '_staged-rules-round4-20261111'
OUT = ST / 'temp-output'
OUT.mkdir(exist_ok=True)

sys.path.insert(0, str(ST / 'recency-priority'))

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

baseline = load_module('business_fit_baseline', ST / 'business-fit' / 'business_fit_baseline.py')
staged = load_module('business_fit_staged', ST / 'business-fit' / 'business_fit.py')

CLASSES = ('reverse_q', 'solicit_looking', 'dating', 'chat_advice', 'supply_offer')
CLASS_LABELS = {
    'reverse_q': '反问别人想租哪里',
    'solicit_looking': '问有没有人找房（供给招客）',
    'dating': '交友/找搭子非租房',
    'chat_advice': '点评/闲聊/劝人/讲开销',
    'supply_offer': '自有房/转租/招租供给',
}

def text_of(row):
    c = row.get('classification') or {}
    return row.get('comment_text') or row.get('text') or c.get('comment_text') or ''

# current not_sent/sendable set: daily-priority queue after ledger exclusion
cur = json.loads((FB / 'recency-priority' / 'daily-priority' / 'current.json').read_text(encoding='utf-8'))
qinfo = cur['platforms']['douyin']
qpath = Path(qinfo['queue'])
sendable_ids = set()
sendable_rows = []
with qpath.open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        row = json.loads(line)
        cid = str(row.get('comment_id') or '')
        sendable_ids.add(cid)
        sendable_rows.append(row)

pool_path = FB / 'douyin-semantic-repair-v5' / 'all-pool-business-fit.jsonl'
newly = {k: [] for k in CLASSES}
already = {k: [] for k in CLASSES}
borderline_keeps = []
keep_examples_hit = []
KEEP_MARKERS = [
    '有人转租吗', '有没有单间出租', '有没有房子租', '附近有房子租吗',
    '我想找室友一起合租', '你在哪里找的房', '上海租哪里合适', '养狗狗租哪里',
    '有搭子合租', '有没有女生合租的，想找个女搭子', '多少钱？小姐姐',
    'Hello，小姐姐',
]

total = 0
base_eligible = 0
staged_eligible = 0
newly_total = 0
t0 = time.time()

with pool_path.open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        row = json.loads(line)
        total += 1
        t = text_of(row)
        b = baseline.screen(row)
        s = staged.screen(row)
        if b['eligible_candidate']:
            base_eligible += 1
        if s['eligible_candidate']:
            staged_eligible += 1
        flags = s.get('r4_evidence') or {}
        classes_hit = [k for k in CLASSES if flags.get(k)]
        if b['eligible_candidate'] and not s['eligible_candidate']:
            newly_total += 1
            rec = {
                'comment_id': row.get('comment_id'),
                'text': t,
                'classes': classes_hit,
                'reasons': s.get('exclusion_reasons'),
                'labels': s.get('exclusion_reason_labels'),
                'in_sendable': str(row.get('comment_id') or '') in sendable_ids,
                'published_at': row.get('published_at'),
            }
            if classes_hit:
                for k in classes_hit:
                    newly[k].append(rec)
            else:
                newly.setdefault('other', []).append(rec)
        elif classes_hit and not s['eligible_candidate']:
            rec = {
                'comment_id': row.get('comment_id'),
                'text': t,
                'classes': classes_hit,
                'reasons': s.get('exclusion_reasons'),
                'in_sendable': str(row.get('comment_id') or '') in sendable_ids,
            }
            for k in classes_hit:
                already[k].append(rec)
        elif s['eligible_candidate']:
            # kept despite looking similar
            if any(m in t for m in KEEP_MARKERS) or (flags and s['eligible_candidate']):
                if any(m in t for m in (
                    '租哪里', '有人找房', '搭子', '暖被窝', '小姐姐', '赶紧退',
                    '有点悬', '不吵架', '开销', '有房出租', '自建房', '有需要租',
                    '我这有', '分租',
                )):
                    borderline_keeps.append({
                        'comment_id': row.get('comment_id'),
                        'text': t,
                        'r4_flags': flags or None,
                        'in_sendable': str(row.get('comment_id') or '') in sendable_ids,
                    })

# also explicitly record kept marker hits
for row in sendable_rows:
    t = text_of(row)
    if any(m in t for m in KEEP_MARKERS):
        s = staged.screen(row)
        keep_examples_hit.append({
            'comment_id': row.get('comment_id'),
            'text': t,
            'eligible': s['eligible_candidate'],
            'reasons': s.get('exclusion_reasons'),
            'r4': s.get('r4_evidence'),
        })

def summarize(bucket):
    out = {}
    for k in list(CLASSES) + (['other'] if 'other' in bucket else []):
        items = bucket.get(k) or []
        in_q = [x for x in items if x.get('in_sendable')]
        samples = []
        seen_text = set()
        for x in in_q + [i for i in items if not i.get('in_sendable')]:
            key = x['text']
            if key in seen_text:
                continue
            seen_text.add(key)
            samples.append({
                'comment_id': x.get('comment_id'),
                'text': x.get('text'),
                'in_sendable': x.get('in_sendable'),
                'labels': x.get('labels') or x.get('reasons'),
            })
            if len(samples) >= 5:
                break
        out[k] = {
            'label': CLASS_LABELS.get(k, k),
            'newly_excluded': len(items) if bucket is newly else None,
            'count': len(items),
            'in_current_sendable_queue': len(in_q),
            'samples': samples,
        }
    return out

# unique newly excluded (an item can hit 2 classes)
unique_new = {}
for k, items in newly.items():
    for x in items:
        unique_new[str(x.get('comment_id'))] = x
unique_new_in_q = [x for x in unique_new.values() if x.get('in_sendable')]

report = {
    'generated_at_local': time.strftime('%Y-%m-%d %H:%M:%S'),
    'timezone': 'Asia/Shanghai UTC+8',
    'pool_file': str(pool_path),
    'pool_rows': total,
    'elapsed_sec': round(time.time() - t0, 3),
    'baseline_eligible': base_eligible,
    'staged_eligible': staged_eligible,
    'newly_excluded_unique': len(unique_new),
    'newly_excluded_in_current_sendable': len(unique_new_in_q),
    'current_sendable': {
        'file': str(qpath),
        'count': qinfo.get('count'),
        'loaded': len(sendable_ids),
        'updated_at_utc': cur.get('updated_at'),
        'excluded_by_current_ledger': qinfo.get('excluded_by_current_ledger'),
        'note': 'daily-priority 当前队列，已在生成时扣除账本 sent/unknown/reserved。本轮发送中的 842 条批次未改动。',
    },
    'newly_excluded_by_class': summarize(newly),
    'already_excluded_but_matched_r4': {k: {'count': len(v), 'in_sendable': sum(1 for x in v if x.get('in_sendable'))} for k, v in already.items()},
    'borderline_keeps_in_pool_sample': borderline_keeps[:30],
    'keep_markers_in_current_queue': keep_examples_hit,
}

# write full newly lists too
(OUT / 'dryrun-round4-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
(OUT / 'dryrun-round4-newly-excluded.jsonl').write_text(
    '\n'.join(json.dumps(x, ensure_ascii=False) for x in unique_new.values()) + ('\n' if unique_new else ''),
    encoding='utf-8',
)

# human-readable summary
lines = []
lines.append(f"全池 {total} 条，基线可入队 {base_eligible}，新规则可入队 {staged_eligible}，新排除（去重）{len(unique_new)}，其中当前可发队列里 {len(unique_new_in_q)} 条。")
lines.append(f"当前可发队列：{qpath.name}，{len(sendable_ids)} 条，生成时间 {cur.get('updated_at')}（UTC）。")
lines.append('')
for k in CLASSES:
    info = report['newly_excluded_by_class'][k]
    lines.append(f"【{info['label']}】新排除 {info['count']}，当前可发队列中 {info['in_current_sendable_queue']}")
    for i, s in enumerate(info['samples'], 1):
        flag = '【在可发队列】' if s['in_sendable'] else ''
        lines.append(f"  {i}. {flag}{s['text']}")
    lines.append('')
lines.append('【临界保留】')
for x in borderline_keeps[:20]:
    flag = '【在可发队列】' if x['in_sendable'] else ''
    lines.append(f"  - {flag}{x['text']}")
(OUT / 'dryrun-round4-summary.txt').write_text('\n'.join(lines), encoding='utf-8')
print('\n'.join(lines))
print('wrote', OUT / 'dryrun-round4-report.json')
print('wrote', OUT / 'dryrun-round4-newly-excluded.jsonl')
print('wrote', OUT / 'dryrun-round4-summary.txt')
