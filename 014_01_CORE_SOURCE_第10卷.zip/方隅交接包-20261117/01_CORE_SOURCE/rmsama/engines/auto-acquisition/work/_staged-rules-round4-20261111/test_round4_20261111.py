"""Round 4 (2026-11-11): local exclusions for reverse-Q, solicit-looking, dating, chat/advice, extra supply."""
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'business-fit'))
sys.path.insert(0, str(ROOT / 'recency-priority'))
sys.path.insert(0, str(ROOT / 'douyin-semantic-repair-v5'))
import business_fit as f

def row(text):
    return {'comment_text': text, 'platform': 'douyin', 'role': 'demand', 'published_at_unix': time.time() - 86400 * 8}

EXCLUDE = {
    'reverse_q': [
        '准备租哪里呀[黄脸祈祷]',
        '你要哪里的房子',
        '想要哪里的',
        '想租哪里的[再见]',
        '需要哪里的',
        '看你需要哪里的房子 区域不同价格不一样',
        '想租哪里自己去找小区啊，保安都可以办的[尬笑][尬笑][尬笑]',
        '嘉定~宝山~松江~奉贤~青浦 你要哪里的[玫瑰]',
        '有的 你打算租哪里的房子 可以帮你推荐一下[比心]',
        '你要哪个位置的喃',
        '你要哪边的',
        '你想要哪块的',
        '你在哪个区找',
        '你要什么位置',
        '你想租哪里的房子？城区的可以吗',
    ],
    'solicit_looking': [
        '杭州上城区有人找房子吗',
        '徐汇有人找房子吗',
    ],
    'dating': [
        '暖被窝的小姐姐',
        '找女搭子',
        '暖被窝的床搭子在哪儿',
        '天冷了，静安区有没有暖被窝的小姐姐[捂脸]',
        '安亭有没有？找个80后的女搭子[捂脸]',
        '搭子你在哪里嘛[捂脸]',
    ],
    'chat_advice': [
        '赶紧退吧，现在好找房子',
        '找个稳定的租客也不容易，你想续租，他要涨价，大概率就是不想租给你了！[微笑]',
        '这个价格估计有点悬',
        '住一起不吵架吗[呲牙]',
        '0，福州还是适合本地人，如果要租房吃饭还有其他开销的话，加起来要比我现在一个月多花好多钱[听歌]',
    ],
    'supply_offer': [
        '有房出租',
        '自建房有需要租房的吗',
        '我这有，预算多少',
        '嘉定马陆新的自建房，下个月装修完了，有需要租房的吗[看][看]',
        '我这有，在嘉定西这附近预算多少钱找',
        '金牛有需要租房的吗',
        '通州西潞苑有没有合租的小姐姐，我胆大租了一个两居的，分租一间[黑脸][黑脸][黑脸]还没找到工作[捂脸]',
    ],
}

# Items from suspect-in-send-queue-1409.json that are non-customers.
FROM_1409 = [
    '准备租哪里呀[黄脸祈祷]',
    '找个稳定的租客也不容易，你想续租，他要涨价，大概率就是不想租给你了！[微笑]',
    '赶紧退吧，现在好找房子',
    '0，福州还是适合本地人，如果要租房吃饭还有其他开销的话，加起来要比我现在一个月多花好多钱[听歌]',
    '杭州上城区有人找房子吗',
]

KEEP = [
    '有人转租吗',
    '有没有单间出租',
    '有没有房子租',
    '附近有房子租吗',
    '我想找室友一起合租',
    '你在哪里找的房  可以推荐我吗？',
    '附近有房子租吗？刚来路过问一句',
    '想找个室友合租，还没找到房',
    '我在杨浦，想找个女生合租',
    '我自己租的房子太贵了想换',
    '我家有两只猫，想找个室友合租',
    '想找个房租，做四个人的员工宿舍',
    '这是在哪里租的？我也想租',
    '我想找个一居室，你们在哪找的房',
    '求租一个单间',
    '上海租哪里合适呀[抱紧自己][抱紧自己]',
    '养狗狗租哪里？',
    '有搭子合租的吗',
    '有没有女生合租的，想找个女搭子[不看]',
    '多少钱？小姐姐',
    'Hello，小姐姐，方便问问这个房子是哪个小区吗？',
    '求房东直租',
    '有没有个人转租啊',
    '你好，我想找房子，你们可以帮我找吗',
    '马上淡季了，我想现在找房便宜点',
    '哪里有房子租',
]


class Round4(unittest.TestCase):
    def test_reverse_questions_excluded(self):
        for t in EXCLUDE['reverse_q']:
            with self.subTest(t=t):
                flags = f.r4_flags(t)
                self.assertTrue(flags['reverse_q'] or f.r3_flags(t)['advice'] or f.advice_not_self(t), flags)
                s = f.screen(row(t))
                self.assertFalse(s['eligible_candidate'], s)
                self.assertIn('advice_not_self_demand', s['exclusion_reasons'])

    def test_solicit_looking_excluded(self):
        for t in EXCLUDE['solicit_looking']:
            with self.subTest(t=t):
                self.assertTrue(f.r4_flags(t)['solicit_looking'])
                s = f.screen(row(t))
                self.assertFalse(s['eligible_candidate'])
                self.assertIn('solicit_people_looking', s['exclusion_reasons'])
                self.assertIn('供给方：询问是否有人找房', s['exclusion_reason_labels'])

    def test_dating_excluded(self):
        for t in EXCLUDE['dating']:
            with self.subTest(t=t):
                self.assertTrue(f.r4_flags(t)['dating'], f.r4_flags(t))
                s = f.screen(row(t))
                self.assertFalse(s['eligible_candidate'])
                self.assertIn('seeking_buddy_or_dating', s['exclusion_reasons'])
                self.assertIn('交友/找搭子非租房', s['exclusion_reason_labels'])

    def test_chat_advice_excluded(self):
        for t in EXCLUDE['chat_advice']:
            with self.subTest(t=t):
                self.assertTrue(f.r4_flags(t)['chat_advice'] or f.advice_not_self(t) or f.r3_flags(t)['advice'], f.r4_flags(t))
                s = f.screen(row(t))
                self.assertFalse(s['eligible_candidate'])
                self.assertIn('advice_not_self_demand', s['exclusion_reasons'])

    def test_supply_excluded(self):
        for t in EXCLUDE['supply_offer']:
            with self.subTest(t=t):
                s = f.screen(row(t))
                self.assertFalse(s['eligible_candidate'], s)
                self.assertTrue(
                    f.listing_ad(t) or f.r4_flags(t)['supply_offer'] or f.r3_flags(t)['own_home_roommate'],
                    (f.listing_ad(t), f.r4_flags(t), s['exclusion_reasons']),
                )
                self.assertTrue(
                    any(x in s['exclusion_reasons'] for x in ('listing_ad_or_agent', 'own_home_seeking_roommate', 'solicit_people_looking')),
                    s['exclusion_reasons'],
                )

    def test_1409_non_customers_excluded(self):
        for t in FROM_1409:
            with self.subTest(t=t):
                s = f.screen(row(t))
                self.assertFalse(s['eligible_candidate'], s)

    def test_demand_kept(self):
        for t in KEEP:
            with self.subTest(t=t):
                s = f.screen(row(t))
                self.assertFalse(s['exclusion_reasons'], (t, s['exclusion_reasons'], f.r4_flags(t)))
                self.assertTrue(s['eligible_candidate'], (t, s))

    def test_labels(self):
        self.assertEqual(f.REASON_LABELS['seeking_buddy_or_dating'], '交友/找搭子非租房')
        self.assertEqual(f.REASON_LABELS['solicit_people_looking'], '供给方：询问是否有人找房')


if __name__ == '__main__':
    unittest.main()
