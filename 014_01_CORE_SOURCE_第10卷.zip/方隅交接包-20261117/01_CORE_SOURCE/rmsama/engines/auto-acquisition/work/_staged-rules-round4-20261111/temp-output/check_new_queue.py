# -*- coding: utf-8 -*-
import json, sqlite3
from pathlib import Path
from datetime import datetime, timezone, timedelta

R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
cur=json.loads((FB/'recency-priority'/'daily-priority'/'current.json').read_text(encoding='utf-8'))
d=cur['platforms']['douyin']
qpath=Path(d['queue'])
rows=[]
with qpath.open(encoding='utf-8') as f:
    for line in f:
        if line.strip():
            rows.append(json.loads(line))

def text(r):
    c=r.get('classification') or {}
    return r.get('comment_text') or r.get('text') or c.get('comment_text') or ''
def draft(r):
    rep=r.get('reply') or {}
    return rep.get('draft_text') or rep.get('text') or r.get('draft') or ''

TZ=timezone(timedelta(hours=8))
def as_bj(s):
    if not s: return None
    dt=datetime.fromisoformat(s.replace('Z','+00:00'))
    return dt.astimezone(TZ).strftime('%Y-%m-%d %H:%M:%S')

print('QUEUE', qpath.name)
print('declared_count', d.get('count'), 'loaded', len(rows))
print('updated_at_utc', cur.get('updated_at'))
print('updated_at_beijing', as_bj(cur.get('updated_at')))
print('queue_mtime_beijing', datetime.fromtimestamp(qpath.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S'))
print('excluded_by_current_ledger', d.get('excluded_by_current_ledger'))
print('excluded_by_latest_business_fit', d.get('excluded_by_latest_business_fit'))

missing_brand=[(r.get('comment_id'), text(r)[:60], draft(r)[:100]) for r in rows if '方隅公寓' not in (draft(r) or '')]
print('missing_fangyu_full_name', len(missing_brand))
for x in missing_brand:
    print('  MISSING', x)

gang=[(r.get('comment_id'), text(r)[:60], draft(r)[:80]) for r in rows if '刚来路' in (draft(r) or '')]
print('draft_contains_刚来路', len(gang))
for x in gang:
    print('  ', x)

FROM_1409 = [
 '准备租哪里呀[黄脸祈祷]',
 '找个稳定的租客也不容易，你想续租，他要涨价，大概率就是不想租给你了！[微笑]',
 '赶紧退吧，现在好找房子',
 '0，福州还是适合本地人，如果要租房吃饭还有其他开销的话，加起来要比我现在一个月多花好多钱[听歌]',
 '杭州上城区有人找房子吗',
]
R4_24 = [
 '有的 你打算租哪里的房子 可以帮你推荐一下[比心]',
 '想租哪里自己去找小区啊，保安都可以办的[尬笑][尬笑][尬笑]',
 '嘉定~宝山~松江~奉贤~青浦 你要哪里的[玫瑰]',
 '需要哪里的',
 '想要哪里的',
 '看你需要哪里的房子 区域不同价格不一样',
 '你要哪里的房子',
 '准备租哪里呀[黄脸祈祷]',
 '杭州上城区有人找房子吗',
 '找个拼床搭子',
 '宝山一号线女搭子有吗[抠鼻]',
 '搭子你在哪里嘛[捂脸]',
 '安亭有没有？找个80后的女搭子[捂脸]',
 '天冷了，静安区有没有暖被窝的小姐姐[捂脸]',
 '暖被窝的床搭子在哪儿',
 '0，福州还是适合本地人，如果要租房吃饭还有其他开销的话，加起来要比我现在一个月多花好多钱[听歌]',
 '赶紧退吧，现在好找房子',
 '找个稳定的租客也不容易，你想续租，他要涨价，大概率就是不想租给你了！[微笑]',
 '这个价格估计有点悬',
 '住一起不吵架吗[呲牙]',
 '通州西潞苑有没有合租的小姐姐，我胆大租了一个两居的，分租一间[黑脸][黑脸][黑脸]还没找到工作[捂脸]',
 '金牛有需要租房的吗',
 '我这有，在嘉定西这附近预算多少钱找',
 '嘉定马陆新的自建房，下个月装修完了，有需要租房的吗[看][看]',
]
R3_EXCLUDE = [
 '一个个说该退押金的，下次自己租一套满意的房子稳定下来，房东通知你下个月就搬走看你要不要违约金',
 '想租哪里的[再见]',
 '还去看看中介店租金吧！！[呲牙][呲牙][呲牙]',
 '杨浦区找个女的合租，不要男的，我自己租的房子，非中介，谢谢！',
 '要40间。长期住。需独立卫浴。洗衣机 有房源的联系我',
 '想问一下都是在哪里遇到这样的房子的，中介吗？还是app',
]
R2_ADS = [
 '金桥可以让我帮忙找房子哦[看]','西江湾路白领公寓有人需要租吗，低价转租','我是刚入职没多久的，双流东升想租房的可以找我，可以帮忙搬家',
 '新人入职中介，需要租房的可以找我没有套路不骗人','有人要租房吗？没找到合适的工作，打算转租出去[苦涩]','谁想租房找我呀','成华有人租的没我需要转租',
 '有房出租','台江鼓楼租房正规中介，需要私我，有中介费','想问一下浦东新区还有人要租房吗，在曹路附近的，我这边有转租的','临平没有人需要租吗[流泪]',
 '九亭找房可以找我[舔屏]','有的，，，具体在哪个位置，我们这边可以提供房源，全网价格价值最优','松江有房出租','上海大学附近想租房的找我，个人房直租无中介费',
 '中原这片有人租嘛？中原路殷行路附近 2室一厅，有天井','萧山区可以加我，我是良心中介','在滨江做中介有没有人想加我一下',
 '彭浦新村， 哦有房可以出租','浦东五洲大道附近有要租房的可以看看我主页，无中介费','泗泾地铁站附近一室 直租 3000有要的吗',
 '武候立交内2.5环旁小套二房东自己出租，无中介。可以吗','有没有朋友需要中介服务的，可打折',
]
R2_ADVICE = [
 '马上淡季了，你现在找房子应该也很找到便宜点的',
 '我北京的房子很容易就出租了，几乎当天就能签合同',
 '建议厨房和卧室中间不要弄帘子',
 '您好博主，我不租房子我可以帮你养猫咪',
]
KEEP = [
 '有人转租吗','有没有单间出租','有没有房子租','附近有房子租吗','我想找室友一起合租',
 '你在哪里找的房  可以推荐我吗？','附近有房子租吗？刚来路过问一句','想找个室友合租，还没找到房',
 '我在杨浦，想找个女生合租','上海租哪里合适呀[抱紧自己][抱紧自己]','养狗狗租哪里？','有搭子合租的吗',
 '有没有女生合租的，想找个女搭子[不看]','多少钱？小姐姐','Hello，小姐姐，方便问问这个房子是哪个小区吗？',
 '求租一个单间','求房东直租',
]

def exact_or_contains(lst):
    found=[]
    for t in lst:
        for r in rows:
            if text(r)==t:
                found.append((t, r.get('comment_id')))
    return found

def show(label, lst):
    found=exact_or_contains(lst)
    print(f'{label}: {len(found)}')
    for x in found:
        print('  HIT', x)
    return found

show('1409_five_in_queue', FROM_1409)
show('r4_24_in_queue', R4_24)
show('r3_exclude_in_queue', R3_EXCLUDE)
show('r2_ads_in_queue', R2_ADS)
show('r2_advice_in_queue', R2_ADVICE)

# also scan drafts/text for known leftover patterns from r1-r3
pattern_hits=[]
import re
bad_pat=re.compile(r'有房出租$|我是(?:中介|房东)|谁想租房找我|低价转租|可以提供房源|暖被窝|找女搭子|赶紧退吧|有人找房子吗|准备租哪里呀')
for r in rows:
    t=text(r)
    if bad_pat.search(t):
        pattern_hits.append((r.get('comment_id'), t))
print('extra_bad_pattern_hits', len(pattern_hits))
for x in pattern_hits:
    print('  ', x)

print('--- keep cases ---')
# presence in queue, pending, and recent all-pool
pend=[]
with (FB/'douyin-semantic-repair-v5'/'pending-candidates.jsonl').open(encoding='utf-8') as f:
    for line in f:
        if line.strip():
            pend.append(json.loads(line))
pool_texts=None
# only scan pool texts for keep presence, read comment_text only
keep_in_pool={t:False for t in KEEP}
with (FB/'douyin-semantic-repair-v5'/'all-pool-business-fit.jsonl').open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        rec=json.loads(line)
        tt=text(rec)
        for t in KEEP:
            if tt==t:
                keep_in_pool[t]=True

qids=set(str(r.get('comment_id') or '') for r in rows)
pend_ids=set(str(p.get('comment_id') or '') for p in pend)
for t in KEEP:
    in_q=[r.get('comment_id') for r in rows if text(r)==t]
    in_p=[p.get('comment_id') for p in pend if text(p)==t]
    print(f"  queue={bool(in_q)} pending={bool(in_p)} pool={keep_in_pool[t]} | {t} | qids={in_q}")

print('pending', len(pend), 'queue', len(rows))
pend_only=[p for p in pend if str(p.get('comment_id') or '') not in qids]
print('pending_not_in_queue', len(pend_only))
for p in pend_only:
    print('  pending-only', p.get('comment_id'), text(p)[:100])

# ledger read-only overlap
ledger=R/'shared-acquisition-ledger'/'shared.sqlite3'
print('ledger_exists', ledger.exists(), ledger)
overlap={'sent':[], 'unknown':[], 'reserved':[], 'other':[]}
if ledger.exists():
    uri='file:'+str(ledger).replace('\\','/')+'?mode=ro'
    con=sqlite3.connect(uri, uri=True)
    try:
        tables=list(con.execute("SELECT name FROM sqlite_master WHERE type='table'"))
        print('ledger_tables', [t[0] for t in tables])
        # find likely status table
        for (name,) in tables:
            cols=[r[1] for r in con.execute(f'PRAGMA table_info({name})')]
            print('  table', name, cols)
    finally:
        con.close()

# print a few queue rows for sanity
print('--- queue texts ---')
for i,r in enumerate(rows,1):
    print(f"{i:2d} {r.get('comment_id')} {text(r)[:80]} || {draft(r)[:60]}")
