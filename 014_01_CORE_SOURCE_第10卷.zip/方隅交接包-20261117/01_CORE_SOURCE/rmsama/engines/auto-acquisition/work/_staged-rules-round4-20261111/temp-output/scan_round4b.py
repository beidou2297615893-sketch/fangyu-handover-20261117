# -*- coding: utf-8 -*-
import importlib.util, json, sys, time
from pathlib import Path
R=Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work')
FB=R/'fangyu-text-business-20261029'
ST=R/'_staged-rules-round4-20261111'
OUT=ST/'temp-output'
sys.path.insert(0, str(ST/'recency-priority'))

def load(name, path):
    spec=importlib.util.spec_from_file_location(name, path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

old=load('bf_old', FB/'business-fit'/'business_fit.py')
new=load('bf_new', ST/'business-fit'/'business_fit.py')

def text(row):
    c=row.get('classification') or {}
    return row.get('comment_text') or row.get('text') or c.get('comment_text') or ''

cur=json.loads((FB/'recency-priority'/'daily-priority'/'current.json').read_text(encoding='utf-8'))
qpath=Path(cur['platforms']['douyin']['queue'])
sendable=set()
with qpath.open(encoding='utf-8') as f:
    for line in f:
        if line.strip():
            sendable.add(str(json.loads(line).get('comment_id') or ''))
print('current queue', qpath.name, 'n', len(sendable), 'updated', cur.get('updated_at'))

newly=[]; kept_similar=[]; total=0; t0=time.time()
with (FB/'douyin-semantic-repair-v5'/'all-pool-business-fit.jsonl').open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        row=json.loads(line)
        total+=1
        t=text(row)
        b=old.screen(row)
        s=new.screen(row)
        flags=s.get('r4_evidence') or {}
        rec={'comment_id':row.get('comment_id'),'text':t,'in_sendable':str(row.get('comment_id') or '') in sendable,'reasons':s.get('exclusion_reasons'),'r4':flags}
        if b['eligible_candidate'] and not s['eligible_candidate']:
            newly.append(rec)
        elif s['eligible_candidate'] and any(k in t for k in ('你要哪','你想要哪','你在哪个区','什么位置','哪个位置','哪边的','哪块的','租哪里','哪里有房子')):
            kept_similar.append(rec)

print('pool', total, 'elapsed', round(time.time()-t0,2))
print('newly_excluded', len(newly), 'in_current_queue', sum(1 for x in newly if x['in_sendable']))
print('--- newly excluded ---')
for x in sorted(newly, key=lambda z: (not z['in_sendable'])):
    print(('Q' if x['in_sendable'] else ' '), x['comment_id'], x['text'][:140], '|', x['r4'])
print('--- kept similar ---')
for x in kept_similar[:20]:
    print(('Q' if x['in_sendable'] else ' '), x['comment_id'], x['text'][:140])
report={'pool':total,'current_queue':qpath.name,'newly_excluded':len(newly),'newly_in_current_queue':sum(1 for x in newly if x['in_sendable']),'items':newly,'kept_similar':kept_similar}
(OUT/'dryrun-round4b-new-catches.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('wrote', OUT/'dryrun-round4b-new-catches.json')
