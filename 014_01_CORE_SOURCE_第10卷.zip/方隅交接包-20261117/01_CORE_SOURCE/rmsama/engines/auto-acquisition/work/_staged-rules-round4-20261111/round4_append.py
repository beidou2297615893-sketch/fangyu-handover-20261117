

# --- ROUND4-20261111: reverse-Q, solicit-looking, dating, chat/advice, extra supply ---
REASON_LABELS['seeking_buddy_or_dating']='交友/找搭子非租房'
REASON_LABELS['solicit_people_looking']='供给方：询问是否有人找房'
_R4_SELF=r'推荐我|我也想|我也要找|求租|求房|求整租|求合租|求单间|求推荐|我想租|我要租|我想找|我要找|正在找|在找房|帮我找|租哪里合适|有没有(?:单间|房子|房源)|有人转租|附近有房子租|我想找室友|预算\d|预算[一二三四五六七八九十百千万]'
_R4_REVERSE=[
 r'(?:你|你们|看你)(?:现在|还)?(?:要|想要|需要|打算|准备)哪里的?(?:房子?)?',
 r'(?:你|你们)(?:打算|准备)租哪里',
 r'准备租哪里',
 r'想租哪里自己去找',
 r'^(?:想要|需要)哪里的(?:房子?)?(?:\[[^\]]*\])?[吗嘛么呀啊呢？?！!\s]*$',
]
_R4_SOLICIT=r'(?:有人|有没有人)(?:在)?找房子?(?:吗|嘛|么|没|不|？|\?)'
_R4_DATING_ALWAYS=r'暖被窝|床搭子'
_R4_DATING=r'(?:找(?:个|一个)?(?:\d+后的)?(?:女|男)搭子)|(?:女|男)搭子|搭子你在哪里'
_R4_CHAT=r'赶紧退吧|赶紧退[吧啊呀]?|稳定的租客也不容易|这个价格估计有点悬|(?<![没不])有点悬|住一起不吵架吗|租房吃饭还有其他开销|适合本地人.{0,24}开销'
_R4_SUPPLY=[
 r'自建房.{0,24}有需要租|自建房.{0,16}(?:出租|装修完)',
 r'(?<![我还])有需要租房的吗|(?<![我还])有需要租的吗',
 r'我这(?:里|边)?有[，,](?:在)?.{0,24}预算多少',
 r'(?:我.{0,16})?(?:租了|租的)(?:一个|套|个)?(?:两居|两室|三居|三室).{0,20}分租',
]
_screen_r3=screen
def r4_flags(t):
    t=t or ''
    self=bool(re.search(_R4_SELF,t))
    rev=None
    for p in _R4_REVERSE:
        m=re.search(p,t)
        if m:
            if re.search(r'租哪里合适|(?:狗狗|猫猫|带宠物)租哪里',t) and not re.search(r'你要哪里|你打算租哪|准备租哪|想要哪里|需要哪里的|看你需要哪里|想租哪里自己去找',t):
                continue
            if self and not re.search(r'你要哪里|你打算租哪|看你需要哪里|想租哪里自己去找|准备租哪里',m.group()):
                continue
            rev=m.group(); break
    sol=None
    m=re.search(_R4_SOLICIT,t)
    if m and not re.search(r'一起找|合租|转租',t[max(0,m.start()-4):m.end()+4]):
        sol=m.group()
    dat=None
    m=re.search(_R4_DATING_ALWAYS,t)
    if m:
        dat=m.group()
    else:
        m=re.search(_R4_DATING,t)
        if m and not re.search(r'合租|室友',t):
            dat=m.group()
    chat=None
    m=re.search(_R4_CHAT,t)
    if m and not self:
        chat=m.group()
    sup=None
    for p in _R4_SUPPLY:
        m=re.search(p,t)
        if m:
            if re.search(r'我这(?:里|边)?有预算\d',t) and '预算多少' not in m.group():
                continue
            sup=m.group(); break
    return dict(reverse_q=rev,solicit_looking=sol,dating=dat,chat_advice=chat,supply_offer=sup)
def screen(row, now=None):
    out=_screen_r3(row,now)
    c=row.get('classification') or {}
    t=row.get('comment_text') or row.get('text') or c.get('comment_text') or ''
    f=r4_flags(t);reasons=list(out['exclusion_reasons'])
    if f['reverse_q'] and 'advice_not_self_demand' not in reasons:
        reasons.append('advice_not_self_demand')
        if not out.get('advice_evidence'):
            out['advice_evidence']=f['reverse_q']
    if f['solicit_looking'] and 'solicit_people_looking' not in reasons:
        reasons.append('solicit_people_looking')
        if not out.get('listing_ad_evidence'):
            out['listing_ad_evidence']=f['solicit_looking']
    if f['dating'] and 'seeking_buddy_or_dating' not in reasons:
        reasons.append('seeking_buddy_or_dating')
    if f['chat_advice'] and 'advice_not_self_demand' not in reasons:
        reasons.append('advice_not_self_demand')
        if not out.get('advice_evidence'):
            out['advice_evidence']=f['chat_advice']
    if f['supply_offer']:
        if re.search(r'分租|租了(?:一个|套|个)?(?:两居|两室|三居|三室)',f['supply_offer']) and 'own_home_seeking_roommate' not in reasons:
            reasons.append('own_home_seeking_roommate')
        elif 'listing_ad_or_agent' not in reasons and 'own_home_seeking_roommate' not in reasons:
            reasons.append('listing_ad_or_agent')
            if not out.get('listing_ad_evidence'):
                out['listing_ad_evidence']=f['supply_offer']
    changed=reasons!=out['exclusion_reasons']
    if changed:
        if reasons and 'not_supported_customer_demand' not in reasons and any(x in reasons for x in ('advice_not_self_demand','solicit_people_looking','seeking_buddy_or_dating','listing_ad_or_agent','own_home_seeking_roommate')):
            reasons.append('not_supported_customer_demand')
        out.update(exclusion_reasons=reasons,exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],
                   eligible_candidate=False,eligible_priority=False,
                   candidate_state='excluded')
        out.update(lead_intent='non_customer',lead_intent_label='非求租客户',commercial_fit='very_low')
    out['r4_evidence']={k:v for k,v in f.items() if v} or None
    return out
# --- end ROUND4-20261111 ---
