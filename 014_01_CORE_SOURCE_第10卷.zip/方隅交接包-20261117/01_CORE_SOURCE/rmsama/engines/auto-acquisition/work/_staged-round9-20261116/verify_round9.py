# -*- coding: utf-8 -*-
from pathlib import Path
import hashlib, py_compile
live = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\business-fit\business_fit.py")
py_compile.compile(str(live), doraise=True)
text=live.read_text(encoding='utf-8')
h=hashlib.sha256(live.read_bytes()).hexdigest()
print("SHA", h)
print("HAS_R9", "ROUND9-20261116" in text and "CITY_RENT_FLOOR" in text)
print("HAS_R8", "end ROUND8-20261115" in text)
print("SH_FLOOR", "上海':2800" in text or "上海': 2800" in text)
