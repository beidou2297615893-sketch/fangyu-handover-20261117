# -*- coding: utf-8 -*-
from pathlib import Path
import hashlib, shutil
live = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\business-fit\business_fit.py")
backup_dir = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_backup-filter-fix-20261116\round9")
backup_dir.mkdir(parents=True, exist_ok=True)
h=hashlib.sha256(live.read_bytes()).hexdigest()
print("LIVE_SHA", h)
expected="c1a886fcf6537e8518b8bf7043f00780f36b11d7fbfc4eee938b385f39be0359"
if h!=expected:
    print("LIVE_SHA_CHANGED")
    raise SystemExit(2)
dest=backup_dir/"business_fit.py"
shutil.copy2(live, dest)
print("BACKUP", dest, hashlib.sha256(dest.read_bytes()).hexdigest())
