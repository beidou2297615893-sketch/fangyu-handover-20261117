﻿$path = "C:\Users\rmsama\agent-tools\5a70e4f8-344d-4a4a-80d0-b678e53e5711.txt"
$i = 0
Get-Content $path | ForEach-Object {
  $i++
  if ($i -le 95) {
    $line = $_
    if ($line.Length -gt 400) { $line = $line.Substring(0,400) + "..." }
    Write-Output ("{0}|{1}" -f $i, $line)
  }
}
