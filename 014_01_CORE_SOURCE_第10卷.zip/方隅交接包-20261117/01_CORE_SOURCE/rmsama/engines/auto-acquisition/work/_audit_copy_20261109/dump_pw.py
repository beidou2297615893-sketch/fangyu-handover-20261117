﻿from pathlib import Path
p = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_progress_window.py")
text = p.read_text(encoding="utf-8")
# print with line numbers around feedback / poll / continue
lines = text.splitlines()
for i, line in enumerate(lines, 1):
    if i <= 140 or "feedback" in line or "last_result" in line or "poll" in line or "continue" in line.lower() or "waiter" in line:
        if i <= 160 or any(k in line for k in ("feedback","last_result","poll","continue","waiter","caption","halt")):
            print(f"{i}|{line}")
print("---TOTAL", len(lines))
