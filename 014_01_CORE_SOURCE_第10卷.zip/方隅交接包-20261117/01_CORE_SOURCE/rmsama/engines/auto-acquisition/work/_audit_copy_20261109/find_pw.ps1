﻿# find progress window / related pids
Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe'" |
  Where-Object { $_.CommandLine -match 'collection_progress|continue_collection|wait|fangyu-douyin' } |
  Select-Object ProcessId, Name, @{n='CL';e={ if ($_.CommandLine.Length -gt 180) { $_.CommandLine.Substring(0,180) } else { $_.CommandLine } }} |
  Format-List
Write-Host '---49448---'
Get-Process -Id 49448 -ErrorAction SilentlyContinue | Format-List Id,ProcessName,StartTime
Write-Host '---47840---'
Get-CimInstance Win32_Process -Filter "ProcessId=47840" | Select-Object ProcessId,Name,CommandLine | Format-List
