﻿from pathlib import Path
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
p = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_progress_window.py")
lines = p.read_text(encoding="utf-8").splitlines()
for i, line in enumerate(lines, 1):
    if i >= 108:
        print(f"{i}|{line}")
print("---")
cc = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\continue_collection.py")
clines = cc.read_text(encoding="utf-8").splitlines()
for i, line in enumerate(clines, 1):
    if "现有暂停" in line or "prepare_scope" in line or "def continue" in line or "ValueError" in line or "return " in line:
        print(f"cc{i}|{line}")
