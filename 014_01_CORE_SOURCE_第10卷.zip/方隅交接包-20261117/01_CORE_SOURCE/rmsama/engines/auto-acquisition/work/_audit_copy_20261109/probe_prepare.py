﻿import sys, traceback
from pathlib import Path
ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
sys.path.insert(0, str(ROOT))
from continue_collection import confirmation_event, read
from runner_ledger_adapter import gate
from collection_confirmed_scope import confirmable, prepare_scope
import sqlite3
from contextlib import closing
active = read(ROOT/"active-runner.json")
plan = read(ROOT/active["plan"])
halt = gate(ROOT/"runtime/collection.sqlite3", plan["account_uid"], plan["scan_id"])["halt"]
print("halt", halt)
cid = confirmation_event(halt)
print("cid", cid)
with closing(sqlite3.connect((ROOT/"runtime/collection.sqlite3").resolve().as_uri()+"?mode=ro", uri=True)) as db:
    db.row_factory = sqlite3.Row
    event = db.execute("SELECT * FROM attempts WHERE request_id=?", (halt["request_id"],)).fetchone()
    print("confirmable", confirmable(event))
    print("event keys", list(event.keys()) if event else None)
    if event:
        for k in ("request_id","state","error","detail","status","kind"):
            if k in event.keys():
                print(k, event[k])
        # print a few more useful
        d = dict(event)
        for k,v in d.items():
            if k in ("spec","response","result","error","status","state","kind","request_id"):
                s=str(v)
                print(k, s[:300])
try:
    prepare_scope(ROOT/"runtime/collection.sqlite3", plan, cid, "douyin-probe-readonly", "probe", active.get("identity"))
except Exception as e:
    print("prepare_scope_error", type(e).__name__, e)
