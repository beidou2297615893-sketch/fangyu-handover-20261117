﻿import json, sqlite3
from pathlib import Path
from contextlib import closing
ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
active = json.loads((ROOT/"active-runner.json").read_text(encoding="utf-8"))
plan = json.loads((ROOT/active["plan"]).read_text(encoding="utf-8"))
print("plan keys", sorted(plan.keys()))
for k in ("stores","keywords","search_terms","scope","store_id","scan_id","account_uid"):
    if k in plan: print(k, str(plan[k])[:500])
dbp = ROOT/"runtime/collection.sqlite3"
with closing(sqlite3.connect(dbp.resolve().as_uri()+"?mode=ro", uri=True)) as db:
    # look for search term tracking tables
    tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    print("tables", tables)
    for t in tables:
        if any(x in t.lower() for x in ("search","term","store","keyword","tried","scope")):
            cols = [r[1] for r in db.execute(f"PRAGMA table_info({t})")]
            n = db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            print(f"TABLE {t} n={n} cols={cols}")
            rows = db.execute(f"SELECT * FROM {t} LIMIT 5").fetchall()
            for r in rows: print(" ", r)
