﻿import json, sys
from pathlib import Path
from contextlib import closing
import sqlite3
ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
sys.path.insert(0, str(ROOT))
from continue_collection import running, continue_active, confirmation_event
from runner_ledger_adapter import gate
a = json.loads((ROOT/"active-runner.json").read_text(encoding="utf-8"))
p = json.loads((ROOT/a["plan"]).read_text(encoding="utf-8"))
w = json.loads((ROOT/"collection-wait-state.json").read_text(encoding="utf-8"))
print("runner", a.get("pid"), running(a.get("pid")))
print("waiter", w.get("pid"), running(w.get("pid")))
print("progress_window_alive", running(21216))
with closing(sqlite3.connect((ROOT/"runtime/collection.sqlite3").resolve().as_uri()+"?mode=ro", uri=True)) as db:
    added = db.execute("select count(*) from entities e join attempts a on a.request_id=e.first_request where e.kind='comments' and json_extract(a.spec,'$.scan_id')=?", (p["scan_id"],)).fetchone()[0]
    pages = db.execute("select count(*) from scan_pages where scan_id=?", (p["scan_id"],)).fetchone()[0]
print("added", added, "pages", pages)
halt = gate(ROOT/"runtime/collection.sqlite3", p["account_uid"], p["scan_id"])["halt"]
cid = confirmation_event(halt)
print("halt", halt.get("state"), "cid", cid)
msg = continue_active(cid)
print("continue_msg=", msg)
