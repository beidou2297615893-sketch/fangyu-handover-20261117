﻿import json, sqlite3, hashlib
from pathlib import Path
from datetime import datetime
B = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
a = json.loads((B/"active-runner.json").read_text(encoding="utf-8"))
p = json.loads((B/a["plan"]).read_text(encoding="utf-8"))
h = json.loads((B/"classification-handoff-status.json").read_text(encoding="utf-8"))
uri = (B/"runtime/collection.sqlite3").as_uri()+"?mode=ro"
with sqlite3.connect(uri, uri=True) as c:
    pages = c.execute("select count(*) from scan_pages where scan_id=?", (p["scan_id"],)).fetchone()[0]
    added = c.execute(
        "select count(*) from entities e join attempts a on a.request_id=e.first_request where e.kind=? and json_extract(a.spec,'$.scan_id')=?",
        ("comments", p["scan_id"]),
    ).fetchone()[0]
scanned = 0
known = False
for line in (B/a["stdout"]).read_text(encoding="utf-8", errors="replace").splitlines():
    try: ev=json.loads(line)
    except Exception: continue
    if ev.get("state")=="page_committed" and ev.get("kind")=="comments":
        rc = ev.get("recent_counts")
        if isinstance(rc, dict) and rc:
            known = True
            scanned += sum(int(rc.get(k) or 0) for k in rc)
visible = h.get("visible_business_pool") or {}
leads = None
if visible.get("file") and visible.get("sha256"):
    content = Path(visible["file"]).read_bytes()
    if hashlib.sha256(content).hexdigest() == visible["sha256"]:
        leads = sum(1 for line in content.decode("utf-8-sig").splitlines() if line.strip())
cand = h.get("pending_candidates_count")
raw = a.get("continued_at") or a.get("started_at")
dt = datetime.fromisoformat(raw)
hours = max((datetime.now(dt.tzinfo) - dt).total_seconds()/3600, 1e-6)
elapsed_min = int((datetime.now(dt.tzinfo) - dt).total_seconds()//60)
print(json.dumps({
  "pages": pages,
  "added": added,
  "scanned": scanned if known else None,
  "leads": leads,
  "candidates": cand,
  "elapsed_min": elapsed_min,
  "rate_added_per_hour": round(added/hours,1),
  "rate_scan_per_hour": round(scanned/hours,1) if known else None,
  "ingest_ratio_pct": round(100*added/scanned,1) if known and scanned else None,
  "runner_pid": a.get("pid"),
  "runner_status": a.get("status"),
}, ensure_ascii=False, indent=2))
