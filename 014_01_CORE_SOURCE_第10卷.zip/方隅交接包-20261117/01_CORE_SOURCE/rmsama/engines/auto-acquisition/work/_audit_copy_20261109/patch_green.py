﻿from pathlib import Path

pw = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_progress_window.py")
cc = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\continue_collection.py")

# --- continue_collection: surface specific ValueError ---
cct = cc.read_text(encoding="utf-8")
old_cc = """        except ValueError:
            return '现有暂停无法安全恢复。请查看进度和回执。'"""
new_cc = """        except ValueError as e:
            detail = str(e)
            if 'no untried search terms' in detail:
                return ('现有暂停无法安全恢复：部分门店搜索词已全部用尽，'
                        '不能按验证后继续安全开新范围。请确认后换词或重启采集（不会自动重启）。')
            if 'confirmed event no longer matches' in detail:
                return '现有暂停无法安全恢复：暂停事件已变化，请刷新进度后再试。'
            if 'does not allow human verification continuation' in detail:
                return '现有暂停无法安全恢复：当前暂停类型不支持验证后继续。'
            if 'effective halt remains' in detail:
                return '现有暂停无法安全恢复：新范围仍有暂停原因。请查看进度和回执。'
            return '现有暂停无法安全恢复。请查看进度和回执。'"""
if old_cc not in cct:
    raise SystemExit('continue_collection ValueError block not found')
cc.write_text(cct.replace(old_cc, new_cc, 1), encoding="utf-8")

# --- progress window: visible feedback + halt-aware help + waiter last_result ---
pwt = pw.read_text(encoding="utf-8")

old_feedback = """feedback=tk.StringVar()
feedback_label=tk.Label(w,textvariable=feedback,wraplength=940,font=('Microsoft YaHei UI',11))
feedback_label.pack()
actions=tk.Frame(w);actions.pack(pady=12,before=summary_label)
help_label=tk.Label(w,text='请先在浏览器完成验证码，再点绿色按钮。会跳过上一条结果未知的记录继续采集。',font=('Microsoft YaHei UI',11),wraplength=950)
help_label.pack(pady=4,before=summary_label)
feedback_label.pack(before=summary_label)"""

new_feedback = """feedback=tk.StringVar()
feedback_label=tk.Label(w,textvariable=feedback,wraplength=940,font=('Microsoft YaHei UI',13,'bold'),fg='#0f172a',justify='left')
feedback_label.pack()
actions=tk.Frame(w);actions.pack(pady=12,before=summary_label)
help_label=tk.Label(w,text='请先在浏览器完成验证码，再点绿色按钮。会跳过上一条结果未知的记录继续采集。',font=('Microsoft YaHei UI',11),wraplength=950,justify='left')
help_label.pack(pady=4,before=summary_label)
feedback_label.pack(before=summary_label)

def _paint_feedback(msg):
 feedback.set(msg or '')
 bad=any(k in (msg or '') for k in ('无法','失败','仍待','未能','请确认','请查看','需核实','仍在'))
 ok=any(k in (msg or '') for k in ('已从原断点继续','正在核对'))
 if bad and not (msg or '').startswith('正在核对'):
  feedback_label.configure(fg='#b91c1c',font=('Microsoft YaHei UI',13,'bold'))
 elif ok:
  feedback_label.configure(fg='#166534',font=('Microsoft YaHei UI',13,'bold'))
 else:
  feedback_label.configure(fg='#0f172a',font=('Microsoft YaHei UI',13,'bold'))"""

if old_feedback not in pwt:
    raise SystemExit('progress window feedback block not found')
pwt = pwt.replace(old_feedback, new_feedback, 1)

old_click = """def continue_clicked():
 continue_button.configure(state='disabled')
 feedback.set('正在核对采集状态和原断点…')
 result=executor.submit(continue_active,confirmed_event)
 def check():
  if not result.done():
   w.after(100,check)
   return
  try:feedback.set(result.result())
  except Exception:feedback.set('无法完成本地核对。请查看采集日志。')
  finally:continue_button.configure(state='normal')
 w.after(100,check)"""

new_click = """def continue_clicked():
 continue_button.configure(state='disabled')
 _paint_feedback('正在核对采集状态和原断点…')
 result=executor.submit(continue_active,confirmed_event)
 def check():
  if not result.done():
   w.after(100,check)
   return
  try:_paint_feedback(result.result())
  except Exception:_paint_feedback('无法完成本地核对。请查看采集日志。')
  finally:continue_button.configure(state='normal')
 w.after(100,check)"""

if old_click not in pwt:
    raise SystemExit('continue_clicked block not found')
pwt = pwt.replace(old_click, new_click, 1)

# After confirmed_event=... and button configure, update help + show waiter last_result
old_btn = """  confirmed_event=confirmation_event(halt)
  if not feedback.get().startswith('正在核对'):
   caption='正在采集' if live else ('验证已完成，继续采集' if confirmed_event else '继续采集')
   continue_button.configure(text=caption,state='disabled' if live or (halt and not confirmed_event) else 'normal')
  nickname=a.get('account_nickname','Aliie✨');baseline=a.get('batch_baseline',35588)"""

new_btn = """  confirmed_event=confirmation_event(halt)
  if not feedback.get().startswith('正在核对'):
   caption='正在采集' if live else ('验证已完成，继续采集' if confirmed_event else '继续采集')
   continue_button.configure(text=caption,state='disabled' if live or (halt and not confirmed_event) else 'normal')
   if live:
    help_label.configure(text='采集进行中。关闭本窗口不会停止采集。')
   elif halt and halt.get('state')=='verification_required':
    help_label.configure(text='请先在浏览器完成验证码，再点绿色按钮。会跳过上一条需验证的记录继续采集。')
   elif halt and halt.get('state')=='unknown':
    help_label.configure(text='上一页结果未知（多为超时）。点绿色按钮会尝试跳过该页开新范围继续；若提示无法安全恢复，需要你确认后换词或重启，不会自动重启。')
   elif halt:
    help_label.configure(text='采集已暂停。若按钮可点，点绿色按钮尝试继续；否则请查看回执。')
   else:
    help_label.configure(text='采集已停止。可点绿色按钮尝试继续（若仍有可采范围）。')
   last=waiter.get('last_result') or ''
   if (not live) and last and not feedback.get().startswith('正在核对') and feedback.get()!=last:
    # keep a successful continue message; otherwise surface waiter outcome so click does not look dead
    if not feedback.get() or any(k in feedback.get() for k in ('无法','失败','请确认','请查看','需核实')) or not feedback.get():
     if not feedback.get() or feedback.get() in ('',):
      _paint_feedback(last)
     elif '无法安全恢复' in last and '无法安全恢复' not in feedback.get():
      _paint_feedback(last)
  nickname=a.get('account_nickname','Aliie✨');baseline=a.get('batch_baseline',35588)"""

if old_btn not in pwt:
    raise SystemExit('confirmed_event button block not found')
pwt = pwt.replace(old_btn, new_btn, 1)

pw.write_text(pwt, encoding="utf-8")
print('patched ok')
print('pw', __import__('hashlib').sha256(pw.read_bytes()).hexdigest())
print('cc', __import__('hashlib').sha256(cc.read_bytes()).hexdigest())
# syntax check
import py_compile
py_compile.compile(str(pw), doraise=True)
py_compile.compile(str(cc), doraise=True)
print('syntax ok')
