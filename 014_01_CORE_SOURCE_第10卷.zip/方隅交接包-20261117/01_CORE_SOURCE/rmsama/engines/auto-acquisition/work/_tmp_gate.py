﻿import json, sys
from pathlib import Path
ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
sys.path.insert(0, str(ROOT))
from continue_collection import running, confirmation_event, continuation_action, last_state, read
from runner_ledger_adapter import gate
active = read(ROOT/"active-runner.json")
print("active_pid", active.get("pid"), "running?", running(active.get("pid")))
print("leases", list(ROOT.glob("runner-lease-*.json")))
plan = read(ROOT/active["plan"])
directory = ROOT/active["directory"]
control = read(directory/"control.json")
print("control.stopped", control.get("stopped"), "pending", control.get("pending"))
g = gate(ROOT/"runtime/collection.sqlite3", plan["account_uid"], plan["scan_id"])
print("gate keys", {k:g.get(k) for k in g if k!='halt'})
halt = g.get("halt")
print("halt", halt)
print("confirmation_event", confirmation_event(halt))
terminal = last_state(ROOT/active["stdout"])
print("terminal", terminal)
print("action", continuation_action(control, terminal, (directory/"STOP").exists(), False))
print("stdout_mtime", (ROOT/active["stdout"]).stat().st_mtime)
