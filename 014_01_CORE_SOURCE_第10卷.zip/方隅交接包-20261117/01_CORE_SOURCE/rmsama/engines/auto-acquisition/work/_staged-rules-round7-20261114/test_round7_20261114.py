# -*- coding: utf-8 -*-
"""Round 7 (2026-11-14): daily/low-price caption leaks; all comments under cheap videos out."""
import sys, time, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parent
LIVE = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029')
sys.path.insert(0, str(ROOT / 'business-fit'))
sys.path.insert(0, str(LIVE / 'recency-priority'))
import business_fit as f

def row(comment, post, **extra):
    data = {
        'comment_text': comment,
        'post_body': post,
        'platform': 'douyin',
        'role': 'demand',
        'published_at_unix': time.time() - 86400 * 8,
        'video_id': extra.pop('video_id', 'v-r7'),
    }
    data.update(extra)
    return data

class Round7(unittest.TestCase):
    def test_floor_unchanged(self):
        self.assertEqual(f.VIDEO_RENT_FLOOR, 3000)

    def test_daily_rates_gated(self):
        cases = [
            ('这个房子一天只要二十块钱', 20*30),
            ('一天只要20块', 20*30),
            ('每天20元', 20*30),
            ('日租20', 20*30),
            ('房租20元/天', 20*30),
        ]
        for post, monthly in cases:
            with self.subTest(post=post):
                info = f.video_listed_rent(row('还有房间吗', post))
                self.assertEqual(info['state'], 'below_floor', info)
                self.assertTrue(any(abs(p['amount']-monthly)<1 for p in info['prices']), info)

    def test_missed_monthly_forms_gated(self):
        cases = [
            ('和好朋友一起住上海AB套1800 互不打扰', 1800),
            ('公寓直租1450 双地铁1号线', 1450),
            ('北京小一居室，1450月付，自家公寓', 1450),
            ('上海2300租到的小家全貌展示', 2300),
            ('成都租的1300➕的小窝', 1300),
            ('1200公寓 拎包入住', 1200),
            ('1200 小房子', 1200),
            ('#1000块能租个什么样的房', 1000),
            ('不要再问我800块能不能租一室一厅了', 800),
        ]
        for post, amt in cases:
            with self.subTest(post=post):
                info = f.video_listed_rent(row('还在吗', post))
                self.assertEqual(info['state'], 'below_floor', info)
                self.assertTrue(any(p['amount']==amt for p in info['prices']), info)

    def test_all_comments_under_cheap_video_out_including_high_budget(self):
        post = '这个房子一天只要二十块钱'
        s = f.screen(row('还有房间吗', post))
        self.assertFalse(s['eligible_candidate'])
        self.assertIn('low_price_video_budget_mismatch', s['exclusion_reasons'])
        s2 = f.screen(row('我想租房，预算4500', post))
        self.assertFalse(s2['eligible_candidate'])
        self.assertIn('low_price_video_budget_mismatch', s2['exclusion_reasons'])

    def test_round6_examples_still_gated(self):
        info = f.video_listed_rent(row('在哪', '一个人带一只小金毛 勇闯上海 1200 小公寓'))
        self.assertEqual(info['state'], 'below_floor', info)
        info2 = f.video_listed_rent(row('在哪', '月租850'))
        self.assertEqual(info2['state'], 'below_floor', info2)

    def test_high_price_and_false_friends_not_gated(self):
        keep = [
            '上海古北 月租8500 精品公寓',
            '在上海月薪11000，你舍得住带阳台的房子吗？',
            '昨天装了一个电信300M宽带花了300一年贵了吗？#杭州租房',
            '距离14号线郭庄子地铁站900m，通勤方便',
            '一室一厅一卫一厨一阳台，大概48平方',
            '短租押金500元，注意是押金，不是租金。',
            '月薪7k双休在杭州的30平小家 我真的很喜欢我现在的小屋 每天下班回家进到房间都感觉很幸福',
            '租房押金不退？打这3个电话一告一个准',
        ]
        for post in keep:
            with self.subTest(post=post):
                info = f.video_listed_rent(row('在哪', post))
                self.assertNotEqual(info['state'], 'below_floor', info)

    def test_mixed_and_hundreds_phrase_still_safe(self):
        self.assertNotEqual(f.video_listed_rent(row('在哪', '几百整租民用水电 #杭州租房'))['state'], 'below_floor')
        mixed = f.video_listed_rent(row('在哪', '一室2000，两室5000，都有'))
        self.assertEqual(mixed['state'], 'mixed', mixed)

if __name__ == '__main__':
    unittest.main()
