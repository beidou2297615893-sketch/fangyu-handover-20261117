# -*- coding: utf-8 -*-
import py_compile, json, hashlib, pathlib
r = pathlib.Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
py_compile.compile(str(r / "new_round.py"), doraise=True)
py_compile.compile(str(r / "current_collection.py"), doraise=True)
cfg = json.loads((r / "collection-config-fixed.json").read_text(encoding="utf-8-sig"))
stores = cfg["stores"]
en = [s for s in stores if s.get("collect_enabled", True)]
dis = [s for s in stores if not s.get("collect_enabled", True)]
print("COMPILE_OK")
print("ORDER")
for s in stores:
    print(s["store_id"], s.get("tier"), s.get("collect_enabled"), len(s["keywords"]))
print("N", len(stores), "EN", len(en), "DIS", len(dis))
print("SHA_CFG", hashlib.sha256((r / "collection-config-fixed.json").read_bytes()).hexdigest())
print("SHA_NR", hashlib.sha256((r / "new_round.py").read_bytes()).hexdigest())
print("SHA_CC", hashlib.sha256((r / "current_collection.py").read_bytes()).hexdigest())
print("HAS_SOURCE", "2026-11-15 store-tier" in (cfg.get("rule_source") or ""))
nr = (r / "new_round.py").read_text(encoding="utf-8")
cc = (r / "current_collection.py").read_text(encoding="utf-8")
print("NR_HAS_GATE", "collect_enabled" in nr and "没有已启用的门店" in nr)
print("CC_HAS_GATE", "collect_enabled" in cc and "没有已启用的门店" in cc)
