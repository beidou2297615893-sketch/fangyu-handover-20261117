# -*- coding: utf-8 -*-
from __future__ import annotations
import json, hashlib, shutil, datetime, sys
from pathlib import Path

ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
STAGED = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_staged-store-tier-20261115")
BACKUP = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_backup-store-tier-20261115")
CONFIG = ROOT / "collection-config-fixed.json"

TIER = {
    "上海古北方隅服务公寓": ("高", 1, True),
    "上海中骏广场方隅服务公寓": ("高", 1, True),
    "FUNLIVE·上海天璟方隅服务公寓": ("高", 1, True),
    "上海会展方隅国际公寓": ("高", 1, True),
    "杭州余杭方隅公寓": ("高", 1, True),
    "上海浦江方隅服务公寓": ("高", 1, True),
    "北京未来云城方隅公寓": ("中", 2, True),
    "杭州东站方隅公寓": ("中", 2, True),
    "上海龙柏方隅服务公寓": ("中", 2, True),
    "北京天璟方隅公寓": ("中", 2, True),
    "上海联航路云涛公寓": ("低", 3, False),
    "北京沙河方隅服务公寓": ("低", 3, False),
    "福州白湖亭方隅服务公寓": ("低", 3, False),
    "杭州青山湖方隅服务公寓": ("低", 3, False),
    "成都高新西方隅服务公寓": ("低", 3, False),
}

def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main() -> int:
    expansion = json.loads((STAGED / "high-store-keyword-expansion-20261115.json").read_text(encoding="utf-8"))
    BACKUP.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(CONFIG.read_text(encoding="utf-8-sig"))
    if "2026-11-15 store-tier" in (cfg.get("rule_source") or ""):
        print("CONFIG_ALREADY_APPLIED", sha256(CONFIG))
        return 0
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = BACKUP / f"collection-config-fixed.json.bak-before-apply-{stamp}"
    shutil.copy2(CONFIG, dest)
    print("BACKUP", dest, sha256(CONFIG))
    unknown = [st.get("store_id") for st in cfg["stores"] if st.get("store_id") not in TIER]
    if unknown:
        print("UNKNOWN_STORES", unknown)
        return 4
    added_counts = {}
    for st in cfg["stores"]:
        sid = st["store_id"]
        tier, prio, enabled = TIER[sid]
        st["tier"] = tier
        st["priority"] = prio
        st["collect_enabled"] = enabled
        before = len(st["keywords"])
        have = set(st["keywords"])
        extra = []
        for kw in expansion.get(sid, []):
            if kw not in have:
                extra.append(kw)
                have.add(kw)
        if extra:
            st["keywords"] = list(st["keywords"]) + extra
        added_counts[sid] = {"tier": tier, "enabled": enabled, "before": before, "added": len(extra), "after": len(st["keywords"])}
    cfg["stores"] = sorted(cfg["stores"], key=lambda s: (s["priority"], -len(s["keywords"]), s["store_id"]))
    note = "2026-11-15 store-tier: 高档优先、中档随后、低档 collect_enabled=false 隔离；高档门店补周边求租词。不启动采集，不改当前计划。"
    src = cfg.get("rule_source") or ""
    cfg["rule_source"] = (src + " | " + note).strip(" |")
    cfg["store_tier_source"] = "official-html snapshot 2026-10-29; start-rent tiers high>=4500 mid>=3000 low<3000"
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print("WROTE", CONFIG, sha256(CONFIG))
    enabled = [s for s in cfg["stores"] if s.get("collect_enabled", True)]
    isolated = [s for s in cfg["stores"] if not s.get("collect_enabled", True)]
    print("ENABLED", [(s["store_id"], s["tier"], len(s["keywords"])) for s in enabled])
    print("ISOLATED", [(s["store_id"], s["tier"], len(s["keywords"])) for s in isolated])
    print("ADDED", json.dumps(added_counts, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    sys.exit(main())
