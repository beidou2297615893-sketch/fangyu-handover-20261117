# -*- coding: utf-8 -*-
"""Apply store-tier isolation and high-store keyword expansion to the NEXT collection config.
Does not start collection, does not rewrite the active plan, does not touch the ledger.
"""
from __future__ import annotations
import json, hashlib, shutil, datetime, sys
from pathlib import Path

ROOT = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent")
STAGED = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_staged-store-tier-20261115")
BACKUP = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_backup-store-tier-20261115")
CONFIG = ROOT / "collection-config-fixed.json"
NEW_ROUND = ROOT / "new_round.py"
CURRENT = ROOT / "current_collection.py"

TIER = {
    "上海古北方隅服务公寓": ("高", 1, True),
    "上海中骏广场方隅服务公寓": ("高", 1, True),
    "FUNLIVE·上海天璟方隅服务公寓": ("高", 1, True),
    "上海会展方隅国际公寓": ("高", 1, True),
    "杭州余杭方隅公寓": ("高", 1, True),
    "上海浦江方隅服务公寓": ("高", 1, True),
    "北京未来云城方隅公寓": ("中", 2, True),
    "杭州东站方隅公寓": ("中", 2, True),
    "上海龙柏方隅服务公寓": ("中", 2, True),
    "北京天璟方隅公寓": ("中", 2, True),
    "上海联航路云涛公寓": ("低", 3, False),
    "北京沙河方隅服务公寓": ("低", 3, False),
    "福州白湖亭方隅服务公寓": ("低", 3, False),
    "杭州青山湖方隅服务公寓": ("低", 3, False),
    "成都高新西方隅服务公寓": ("低", 3, False),
}

NR_OLD = "        stores = [dict(st, keywords=sorted([k for k in st['keywords'] if k not in words], key=lambda k: k in recent)) for st in plan['stores']]\n        if not all(st['keywords'] for st in stores): say('排除后有门店没有关键词，已停止。'); db.rollback(); return 1\n"
NR_NEW = "        plan_stores = [st for st in plan['stores'] if st.get('collect_enabled', True)]\n        if not plan_stores:\n            say('没有已启用的门店，已停止。'); db.rollback(); return 1\n        stores = [dict(st, keywords=sorted([k for k in st['keywords'] if k not in words], key=lambda k: k in recent)) for st in plan_stores]\n        if not all(st['keywords'] for st in stores): say('排除后有门店没有关键词，已停止。'); db.rollback(); return 1\n"

CC_OLD = "    cfg=copy.deepcopy(config)\n    cfg['stores']=[dict(st,keywords=sorted((k for k in st['keywords'] if k not in blocked_words),key=lambda k:k in searched)) for st in cfg['stores']]\n    if any(not st['keywords'] for st in cfg['stores']):raise StartupBlocked('部分门店没有可安全轮换的关键词，已保留未知记录。')\n"
CC_NEW = "    cfg=copy.deepcopy(config)\n    cfg['stores']=[st for st in cfg['stores'] if st.get('collect_enabled', True)]\n    if not cfg['stores']:\n        raise StartupBlocked('没有已启用的门店，已保留未知记录。')\n    cfg['stores']=[dict(st,keywords=sorted((k for k in st['keywords'] if k not in blocked_words),key=lambda k:k in searched)) for st in cfg['stores']]\n    if any(not st['keywords'] for st in cfg['stores']):raise StartupBlocked('部分门店没有可安全轮换的关键词，已保留未知记录。')\n"

def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main() -> int:
    for p in (CONFIG, NEW_ROUND, CURRENT):
        if not p.is_file():
            print("MISSING", p)
            return 1
    expansion = json.loads((STAGED / "high-store-keyword-expansion-20261115.json").read_text(encoding="utf-8"))
    BACKUP.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    for p in (CONFIG, NEW_ROUND, CURRENT):
        dest = BACKUP / f"{p.name}.bak-{stamp}"
        shutil.copy2(p, dest)
        print("BACKUP", dest, sha256(p))

    # patch python
    nr = NEW_ROUND.read_text(encoding="utf-8")
    cc = CURRENT.read_text(encoding="utf-8")
    if "collect_enabled" in nr and "plan_stores" in nr:
        print("new_round.py already patched")
    else:
        if NR_OLD not in nr:
            print("NEW_ROUND_PATTERN_MISSING")
            return 2
        NEW_ROUND.write_text(nr.replace(NR_OLD, NR_NEW, 1), encoding="utf-8")
        print("PATCHED new_round.py", sha256(NEW_ROUND))
    if "collect_enabled" in cc and "没有已启用的门店" in cc:
        print("current_collection.py already patched")
    else:
        if CC_OLD not in cc:
            print("CURRENT_PATTERN_MISSING")
            return 3
        CURRENT.write_text(cc.replace(CC_OLD, CC_NEW, 1), encoding="utf-8")
        print("PATCHED current_collection.py", sha256(CURRENT))

    cfg = json.loads(CONFIG.read_text(encoding="utf-8-sig"))
    unknown = [st.get("store_id") for st in cfg["stores"] if st.get("store_id") not in TIER]
    if unknown:
        print("UNKNOWN_STORES", unknown)
        return 4
    added_counts = {}
    for st in cfg["stores"]:
        sid = st["store_id"]
        tier, prio, enabled = TIER[sid]
        st["tier"] = tier
        st["priority"] = prio
        st["collect_enabled"] = enabled
        before = len(st["keywords"])
        have = set(st["keywords"])
        extra = []
        for kw in expansion.get(sid, []):
            if kw not in have:
                extra.append(kw)
                have.add(kw)
        if extra:
            st["keywords"] = list(st["keywords"]) + extra
        added_counts[sid] = {"tier": tier, "enabled": enabled, "before": before, "added": len(extra), "after": len(st["keywords"])}
    cfg["stores"] = sorted(cfg["stores"], key=lambda s: (s["priority"], -len(s["keywords"]), s["store_id"]))
    note = "2026-11-15 store-tier: 高档优先、中档随后、低档 collect_enabled=false 隔离；高档门店补周边求租词。不启动采集，不改当前计划。"
    src = cfg.get("rule_source") or ""
    if "2026-11-15 store-tier" not in src:
        cfg["rule_source"] = (src + " | " + note).strip(" |")
    cfg["store_tier_source"] = "official-html snapshot 2026-10-29; start-rent tiers high>=4500 mid>=3000 low<3000"
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print("WROTE", CONFIG, sha256(CONFIG))
    enabled = [s for s in cfg["stores"] if s.get("collect_enabled", True)]
    isolated = [s for s in cfg["stores"] if not s.get("collect_enabled", True)]
    print("ENABLED", [(s["store_id"], s["tier"], len(s["keywords"])) for s in enabled])
    print("ISOLATED", [(s["store_id"], s["tier"], len(s["keywords"])) for s in isolated])
    print("ADDED", json.dumps(added_counts, ensure_ascii=False))
    # compile check
    import py_compile
    py_compile.compile(str(NEW_ROUND), doraise=True)
    py_compile.compile(str(CURRENT), doraise=True)
    print("COMPILE_OK")
    return 0

if __name__ == "__main__":
    sys.exit(main())
