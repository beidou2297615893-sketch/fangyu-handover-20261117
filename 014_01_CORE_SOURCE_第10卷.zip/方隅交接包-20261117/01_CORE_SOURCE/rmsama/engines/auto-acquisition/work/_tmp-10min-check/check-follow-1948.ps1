$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Write-Output ("NOW=" + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"))
$ci = (Get-Item "C:\Users\rmsama\Documents\ChatGPT\*\work\fangyu-douyin-independent").FullName
$work = (Get-Item -LiteralPath $ci).Parent.FullName

function Show-LogTail([string]$p, [int]$n) {
  if (-not (Test-Path -LiteralPath $p)) { Write-Output ("MISSING_LOG|" + $p); return }
  $i = Get-Item -LiteralPath $p
  Write-Output ("-- LOG " + $p + " mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length + " --")
  $lines = Get-Content -LiteralPath $p -Tail $n -Encoding UTF8 -ErrorAction SilentlyContinue
  foreach ($line in $lines) {
    $t = [string]$line
    if ($t -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "<redacted-sensitive-line>"; continue }
    if ($t.Length -gt 400) { $t = $t.Substring(0,400) }
    Write-Output $t
  }
}

$round = "20261116-160218"
Write-Output ("===ROUND " + $round + "===")
$newRun = Join-Path $ci ("runner-live-round-" + $round)
Write-Output ("RUNNER_DIR_EXISTS=" + (Test-Path -LiteralPath $newRun))
if (Test-Path -LiteralPath $newRun) {
  Get-ChildItem -LiteralPath $newRun -Force | Sort-Object LastWriteTime -Descending | Select-Object -First 12 | ForEach-Object {
    Write-Output ("{0}|mtime={1}|len={2}" -f $_.Name, $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"), $(if ($_.PSIsContainer) {"DIR"} else {$_.Length}))
  }
  $ctrl = Join-Path $newRun "control.json"
  if (Test-Path -LiteralPath $ctrl) {
    $i = Get-Item $ctrl
    Write-Output ("control.json mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length)
    $raw = Get-Content -LiteralPath $ctrl -Raw -Encoding UTF8
    if ($raw -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "CONTROL_REDACTED" }
    else {
      if ($raw.Length -gt 1500) { $raw = $raw.Substring(0,1500) }
      Write-Output $raw
    }
  }
}
Show-LogTail (Join-Path $ci ("runner-round-" + $round + "-stdout.log")) 15
Show-LogTail (Join-Path $ci ("runner-round-" + $round + "-stderr.log")) 10

Write-Output "===SUPERVISOR_STATUS_FILE==="
$sup = Join-Path $ci "current-collection-supervisor.json"
if (Test-Path $sup) {
  $i = Get-Item $sup
  Write-Output ("mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length)
  Get-Content -LiteralPath $sup -Raw -Encoding UTF8
}

Write-Output "===WINDOWS_ALL==="
$wins = Get-Process | Where-Object { $_.MainWindowTitle }
Write-Output ("VISIBLE_WINDOW_COUNT=" + @($wins).Count)
$hits = 0
foreach ($p in ($wins | Sort-Object ProcessName)) {
  $title = [string]$p.MainWindowTitle
  if ($title.Length -gt 100) { $title = $title.Substring(0,100) }
  $mark = ""
  if ($title -match "抖音|采集|验证|验证码|获客|发送|queue|方隅|Douyin|douyin") { $mark = "HIT|"; $hits++ }
  Write-Output ($mark + "WIN|pid=" + $p.Id + "|name=" + $p.ProcessName + "|start=" + $p.StartTime.ToString("yyyy-MM-dd HH:mm:ss") + "|title=" + $title)
}
Write-Output ("DOUYIN_LIKE_HITS=" + $hits)

Write-Output "===SEND_HINTS==="
$ctrlDir = Join-Path $work "douyin-local-control"
Get-ChildItem -LiteralPath $ctrlDir -Force -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -match "status|active|queue|receipt|batch|send" } |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 20 |
  ForEach-Object {
    Write-Output ("{0}|mtime={1}|len={2}" -f $_.Name, $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"), $(if ($_.PSIsContainer) {"DIR"} else {$_.Length}))
  }

Write-Output "DONE"
