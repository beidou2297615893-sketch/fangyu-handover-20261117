﻿$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Write-Output ("NOW=" + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"))

$targetPid = 29764
$proc = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $targetPid)
if (-not $proc) { Write-Output "PROC_DEAD" } else {
  Write-Output ("NAME=" + $proc.Name)
  Write-Output ("EXE=" + $proc.ExecutablePath)
  Write-Output ("PPID=" + $proc.ParentProcessId)
  Write-Output ("CMD=" + $proc.CommandLine)
  $gp = Get-Process -Id $targetPid -ErrorAction SilentlyContinue
  if ($gp) {
    Write-Output ("START=" + $gp.StartTime.ToString("yyyy-MM-dd HH:mm:ss"))
    Write-Output ("TITLE=" + $gp.MainWindowTitle)
    Write-Output ("HWND=" + $gp.MainWindowHandle)
    Write-Output ("RESPONDING=" + $gp.Responding)
  }
}

$ci = (Get-Item "C:\Users\rmsama\Documents\ChatGPT\*\work\fangyu-douyin-independent").FullName
$work = (Get-Item -LiteralPath $ci).Parent.FullName
$deskRoot = (Get-Item -LiteralPath $work).Parent.FullName
Write-Output ("CI=" + $ci)
Write-Output ("DESKROOT=" + $deskRoot)

Write-Output "===RELATED_EXES==="
Get-CimInstance Win32_Process | Where-Object {
  $nm = [string]$_.Name
  $ex = [string]$_.ExecutablePath
  $cl = [string]$_.CommandLine
  ($ex -match "FangyuDesktopDirect|fangyu-douyin|employee") -or ($nm -match "FangyuDesktopDirect") -or ($cl -match "FangyuDesktopDirect-20261114")
} | ForEach-Object {
  $cl = [string]$_.CommandLine
  if ($cl.Length -gt 400) { $cl = $cl.Substring(0,400) }
  Write-Output ("PROC|pid=" + $_.ProcessId + "|ppid=" + $_.ParentProcessId + "|name=" + $_.Name + "|exe=" + $_.ExecutablePath + "|cmd=" + $cl)
}

Write-Output "===DESK_DIRS==="
Get-ChildItem -LiteralPath $deskRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  Write-Output ("DIR|" + $_.Name + "|mtime=" + $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"))
}

Write-Output "===BRIDGE==="
$bridge = $null
Get-ChildItem -LiteralPath $deskRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  $p = Join-Path $_.FullName "data\bridge.json"
  if (Test-Path -LiteralPath $p) { $script:bridge = $p }
}
Write-Output ("BRIDGE_FILE=" + $bridge + " exists=" + [bool]($bridge -and (Test-Path -LiteralPath $bridge)))

$js = @'
const fs=require('node:fs');
const {BridgeClient}=require('../runtime/douyin-bridge/lib/client/bridge-client');
(async()=>{
  const cfgPath=process.argv[2];
  const want=process.argv[3];
  const cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8'));
  const bridge=new BridgeClient({...cfg.bridge,reuseConnections:false});
  const st=await bridge.status();
  const list=(st.connections&&st.connections['douyin.com'])||[];
  const sites=st.connections?Object.keys(st.connections):[];
  const out={sites,count:list.length,wanted:want,wanted_alive:false,items:[]};
  for (const c of list) {
    const item={id:c.id,alive:!!c.alive};
    if (c.title) item.title=String(c.title).slice(0,80);
    if (c.url) item.url=String(c.url).slice(0,120);
    if (c.attached!=null) item.attached=c.attached;
    out.items.push(item);
    if (c.id===want && c.alive) out.wanted_alive=true;
  }
  console.log(JSON.stringify(out));
})().catch(e=>{console.error('BRIDGE_STATUS_FAIL:'+String(e&&e.message?e.message:e).slice(0,200)); process.exit(1);});
'@
$jsPath = Join-Path $ci "_tmp-bridge-status-1948.cjs"
$utf8 = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($jsPath, $js, $utf8)
$want = "16d21410-3e51-4347-aa56-dca6e4fcce32"
$node = "C:\Program Files\nodejs\node.exe"
if ($bridge) {
  $out = & $node $jsPath $bridge $want 2>&1
  Write-Output ("NODE_EXIT=" + $LASTEXITCODE)
  $t = [string]($out -join "`n")
  if ($t -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "REDACTED_SENSITIVE" } else {
    if ($t.Length -gt 4000) { $t = $t.Substring(0,4000) }
    Write-Output $t
  }
} else {
  Write-Output "NO_BRIDGE_FILE"
}
Remove-Item -LiteralPath $jsPath -Force -ErrorAction SilentlyContinue

Write-Output "===SCREENSHOT==="
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinShot1948 {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@
Add-Type -AssemblyName System.Drawing
$shotDir = "C:\Users\rmsama\AppData\Local\Temp\douyin-10min-check-1948"
if (-not (Test-Path $shotDir)) { New-Item -ItemType Directory -Path $shotDir | Out-Null }
$gp = Get-Process -Id $targetPid -ErrorAction SilentlyContinue
if ($gp -and $gp.MainWindowHandle -ne [IntPtr]::Zero) {
  $hwnd = $gp.MainWindowHandle
  Write-Output ("VISIBLE=" + [WinShot1948]::IsWindowVisible($hwnd) + " ICONIC=" + [WinShot1948]::IsIconic($hwnd))
  $rect = New-Object WinShot1948+RECT
  [void][WinShot1948]::GetWindowRect($hwnd, [ref]$rect)
  $w = $rect.Right - $rect.Left
  $h = $rect.Bottom - $rect.Top
  Write-Output ("RECT=" + $rect.Left + "," + $rect.Top + "," + $w + "x" + $h)
  if ($w -gt 10 -and $h -gt 10) {
    $bmp = New-Object System.Drawing.Bitmap $w, $h
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $g.GetHdc()
    $ok = [WinShot1948]::PrintWindow($hwnd, $hdc, 2)
    $g.ReleaseHdc($hdc)
    $g.Dispose()
    $shot = Join-Path $shotDir "workbench-29764.png"
    $bmp.Save($shot, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Output ("SHOT_OK=" + $ok + " PATH=" + $shot + " LEN=" + (Get-Item $shot).Length)
  } else {
    Write-Output "RECT_TOO_SMALL"
  }
} else {
  Write-Output "NO_HWND"
}

Write-Output "DONE"
