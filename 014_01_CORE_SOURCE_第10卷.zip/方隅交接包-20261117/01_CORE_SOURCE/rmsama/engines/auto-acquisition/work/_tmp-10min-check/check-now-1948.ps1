$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ci = (Get-Item "C:\Users\rmsama\Documents\ChatGPT\*\work\fangyu-douyin-independent").FullName
Write-Output ("NOW=" + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"))
Write-Output ("CI=" + $ci)

function Show-SafeJson([string]$p) {
  if (-not (Test-Path -LiteralPath $p)) { Write-Output ("MISSING|" + $p); return }
  Write-Output ("-- " + $p + " --")
  $i = Get-Item -LiteralPath $p
  Write-Output ("mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length)
  try { $s = Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json } catch { Write-Output "PARSE_FAIL"; return }
  $skip = @("cookie","cookies","token","authorization","password","secret","session","credential","headers","set-cookie")
  function Emit-Val([string]$prefix, $v, [int]$depth) {
    if ($depth -gt 4) { Write-Output ($prefix + "=<nested>"); return }
    if ($null -eq $v) { Write-Output ($prefix + "=null"); return }
    if ($v -is [System.Management.Automation.PSCustomObject] -or $v -is [System.Collections.IDictionary]) {
      foreach ($sp in $v.PSObject.Properties) {
        $sk = [string]$sp.Name
        $skl = $sk.ToLower()
        $sb = $false
        foreach ($x in $skip) { if ($skl -like ("*" + $x + "*")) { $sb = $true; break } }
        if ($sb) { Write-Output ($prefix + "." + $sk + "=<redacted>"); continue }
        Emit-Val ($prefix + "." + $sk) $sp.Value ($depth+1)
      }
    } elseif ($v -is [System.Collections.IEnumerable] -and -not ($v -is [string])) {
      $n = 0
      foreach ($item in $v) { $n++; if ($n -le 12) { Emit-Val ($prefix + "[" + ($n-1) + "]") $item ($depth+1) } }
      Write-Output ($prefix + "_count=" + $n)
    } else {
      $vs = [string]$v
      if ($vs.Length -gt 400) { $vs = $vs.Substring(0,400) }
      Write-Output ($prefix + "=" + $vs)
    }
  }
  foreach ($prop in $s.PSObject.Properties) {
    $k = [string]$prop.Name
    $kl = $k.ToLower()
    $blocked = $false
    foreach ($x in $skip) { if ($kl -like ("*" + $x + "*")) { $blocked = $true; break } }
    if ($blocked) { Write-Output ($k + "=<redacted>"); continue }
    Emit-Val $k $prop.Value 0
  }
}

function Show-LogTail([string]$p, [int]$n) {
  if (-not (Test-Path -LiteralPath $p)) { Write-Output ("MISSING_LOG|" + $p); return }
  $i = Get-Item -LiteralPath $p
  Write-Output ("-- LOG " + $p + " mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length + " --")
  $lines = Get-Content -LiteralPath $p -Tail $n -Encoding UTF8 -ErrorAction SilentlyContinue
  foreach ($line in $lines) {
    $t = [string]$line
    if ($t -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "<redacted-sensitive-line>"; continue }
    if ($t.Length -gt 400) { $t = $t.Substring(0,400) }
    Write-Output $t
  }
}

Write-Output "===PROCESSES==="
Get-CimInstance Win32_Process | Where-Object {
  $cl = [string]$_.CommandLine
  $nm = [string]$_.Name
  ($cl -match "current_collection|auto_continue|collection_stop_popup|strict-bridge|batch_reply|employee-start|control\.py|new_round|runner\.cjs|send_cli|watch_increment|ensure_text_worker|fangyu-douyin|collection_popup") -or
  (($nm -match "node|python") -and ($cl -match "douyin|fangyu"))
} | Sort-Object CreationDate | ForEach-Object {
  $cl = [string]$_.CommandLine
  if ($cl.Length -gt 350) { $cl = $cl.Substring(0,350) }
  $st = ""
  try { $st = ([Management.ManagementDateTimeConverter]::ToDateTime($_.CreationDate)).ToString("yyyy-MM-dd HH:mm:ss") } catch { $st = [string]$_.CreationDate }
  Write-Output ("PROC|pid=" + $_.ProcessId + "|ppid=" + $_.ParentProcessId + "|name=" + $_.Name + "|start=" + $st + "|cmd=" + $cl)
}

Write-Output "===KEY_JSON==="
Show-SafeJson (Join-Path $ci "active-runner.json")
Show-SafeJson (Join-Path $ci "current-collection-status.json")
Show-SafeJson (Join-Path $ci "auto-collect-status.json")
Show-SafeJson (Join-Path $ci "batch-runner-status.json")
Show-SafeJson (Join-Path $ci "batch-context.json")

Write-Output "===LATEST_FILES==="
Get-ChildItem -LiteralPath $ci -Force -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -match "^(plan-round-|runner-live-round-|identity-round-|strict-proof-round-|runner-round-).*20261116" -or $_.Name -match "^(active-runner|current-collection|batch-runner|auto-collect)" } |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 30 |
  ForEach-Object {
    Write-Output ("{0}|mtime={1}|len={2}" -f $_.Name, $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"), $(if ($_.PSIsContainer) {"DIR"} else {$_.Length}))
  }

$arPath = Join-Path $ci "active-runner.json"
$roundId = $null
if (Test-Path -LiteralPath $arPath) {
  try {
    $ar = Get-Content -LiteralPath $arPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($ar.round) { $roundId = [string]$ar.round }
    elseif ($ar.round_id) { $roundId = [string]$ar.round_id }
    elseif ($ar.dir) { if ([string]$ar.dir -match "runner-live-round-(.+)$") { $roundId = $Matches[1] } }
    elseif ($ar.path) { if ([string]$ar.path -match "runner-live-round-(.+)$") { $roundId = $Matches[1] } }
  } catch {}
}
if (-not $roundId) {
  $latestPlan = Get-ChildItem -LiteralPath $ci -Filter "plan-round-20261116-*.json" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($latestPlan -and $latestPlan.Name -match "plan-round-(.+)\.json") { $roundId = $Matches[1] }
}
Write-Output ("ROUND_ID=" + $roundId)
if ($roundId) {
  Show-SafeJson (Join-Path $ci ("identity-round-" + $roundId + ".json"))
  Show-SafeJson (Join-Path $ci ("strict-proof-round-" + $roundId + ".json"))
  Show-SafeJson (Join-Path $ci ("plan-round-" + $roundId + ".json"))
  Show-LogTail (Join-Path $ci ("runner-round-" + $roundId + "-stdout.log")) 30
  Show-LogTail (Join-Path $ci ("runner-round-" + $roundId + "-stderr.log")) 30
  Show-LogTail (Join-Path $ci ("runner-round-" + $roundId + "-validation.log")) 20
  $newRun = Join-Path $ci ("runner-live-round-" + $roundId)
  Write-Output ("RUNNER_DIR_EXISTS=" + (Test-Path -LiteralPath $newRun))
  if (Test-Path -LiteralPath $newRun) {
    Get-ChildItem -LiteralPath $newRun -Force | Sort-Object LastWriteTime -Descending | Select-Object -First 15 | ForEach-Object {
      Write-Output ("{0}|mtime={1}|len={2}" -f $_.Name, $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"), $(if ($_.PSIsContainer) {"-"} else {$_.Length}))
    }
    $ctrl = Join-Path $newRun "control.json"
    if (Test-Path -LiteralPath $ctrl) { Show-SafeJson $ctrl }
  }
}

Write-Output "===WATCH_PIDS==="
foreach ($pidX in @(20232,41992,43216,48276,38596,54364,30948,63380,54208,44344,5304,44624,17280)) {
  $p = Get-Process -Id $pidX -ErrorAction SilentlyContinue
  if ($p) { Write-Output ("ALIVE|" + $pidX + "|" + $p.ProcessName + "|" + $p.StartTime.ToString("yyyy-MM-dd HH:mm:ss")) } else { Write-Output ("DEAD|" + $pidX) }
}

Write-Output "===STOP_FLAGS==="
foreach ($f in @("auto-collect.stop","collect.stop","send.stop")) {
  $p = Join-Path $ci $f
  if (Test-Path -LiteralPath $p) {
    $i = Get-Item -LiteralPath $p
    Write-Output ("FLAG|" + $f + "|mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + "|len=" + $i.Length)
  } else {
    Write-Output ("NOFLAG|" + $f)
  }
}

Write-Output "===ALERT_SCAN==="
if ($roundId) {
  $rounds = @($roundId)
} else {
  $rounds = @("20261116-160218")
}
foreach ($round in $rounds) {
  $p = Join-Path $ci ("runner-round-" + $round + "-stdout.log")
  if (-not (Test-Path -LiteralPath $p)) { Write-Output ("MISSING_ALERT|" + $round); continue }
  $i = Get-Item -LiteralPath $p
  Write-Output ("-- ALERT " + $round + " mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length + " --")
  $hits = Select-String -LiteralPath $p -Pattern "2484|challenge|captcha|验证码|你搜得太多|halt|safety_pause|identity_error|ledger_invalid|ledger_unknown|paused" -AllMatches
  if (-not $hits) {
    Write-Output "NO_ALERT_HITS"
  } else {
    Write-Output ("HIT_COUNT=" + @($hits).Count)
    $hits | Select-Object -Last 25 | ForEach-Object {
      $t = [string]$_.Line
      if ($t.Length -gt 320) { $t = $t.Substring(0,320) }
      Write-Output ("L" + $_.LineNumber + "|" + $t)
    }
  }
}

Write-Output "===DONE==="
