$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ci = (Get-Item "C:\Users\rmsama\Documents\ChatGPT\*\work\fangyu-douyin-independent").FullName
$work = (Get-Item -LiteralPath $ci).Parent.FullName
$deskRoot = (Get-Item -LiteralPath $work).Parent.FullName
Write-Output ("NOW=" + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"))

function Show-LogTail([string]$p, [int]$n) {
  if (-not (Test-Path -LiteralPath $p)) { Write-Output ("MISSING_LOG|" + $p); return }
  $i = Get-Item -LiteralPath $p
  Write-Output ("-- LOG " + $p + " mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " len=" + $i.Length + " --")
  $lines = Get-Content -LiteralPath $p -Tail $n -Encoding UTF8 -ErrorAction SilentlyContinue
  foreach ($line in $lines) {
    $t = [string]$line
    if ($t -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "<redacted-sensitive-line>"; continue }
    if ($t.Length -gt 400) { $t = $t.Substring(0,400) }
    Write-Output $t
  }
}

Write-Output "===AUTO_CONTINUE_LOG==="
Show-LogTail (Join-Path $work "douyin-local-control\auto-continue.log") 40

Write-Output "===SUPERVISOR_LOG==="
Show-LogTail (Join-Path $ci "current-collection-supervisor.log") 20

Write-Output "===LOCAL_CONTROL_STATUS==="
foreach ($f in @("status.json","active.json")) {
  $p = Join-Path $work "douyin-local-control\$f"
  if (-not (Test-Path $p)) { Write-Output ("MISSING|" + $p); continue }
  $i = Get-Item $p
  Write-Output ("-- $f mtime=" + $i.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + " --")
  $raw = Get-Content -LiteralPath $p -Raw -Encoding UTF8
  if ($raw -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "REDACTED"; continue }
  if ($raw.Length -gt 1500) { $raw = $raw.Substring(0,1500) }
  Write-Output $raw
}

Write-Output "===DESK_PROCS==="
Get-CimInstance Win32_Process | Where-Object {
  $cl = [string]$_.CommandLine
  $nm = [string]$_.Name
  ($cl -match "采集台|自动获客|ChatGPT|electron|strict-bridge|douyin") -or ($nm -match "electron|chrome|msedge|Cursor|采集")
} | ForEach-Object {
  $cl = [string]$_.CommandLine
  if ($cl -match "(?i)cookie|authorization|password|secret|credential") { $cl = "<redacted-cmd>" }
  elseif ($cl.Length -gt 220) { $cl = $cl.Substring(0,220) }
  $st = ""
  try { $st = (Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue).StartTime.ToString("yyyy-MM-dd HH:mm:ss") } catch {}
  Write-Output ("PROC|pid=" + $_.ProcessId + "|ppid=" + $_.ParentProcessId + "|name=" + $_.Name + "|start=" + $st + "|cmd=" + $cl)
}

Write-Output "===DESK_PATHS==="
Get-ChildItem -LiteralPath $deskRoot -Directory -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -match "抖音|采集|获客" } |
  ForEach-Object { Write-Output ("DIR|" + $_.Name + "|mtime=" + $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")) }

# write no-BOM js into CI temp name
$js = @"
const fs=require('node:fs');
const {BridgeClient}=require('../runtime/douyin-bridge/lib/client/bridge-client');
(async()=>{
  const cfgPath=process.argv[2];
  const want=process.argv[3];
  const cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8'));
  const bridge=new BridgeClient({...cfg.bridge,reuseConnections:false});
  const st=await bridge.status();
  const list=(st.connections&&st.connections['douyin.com'])||[];
  const sites=st.connections?Object.keys(st.connections):[];
  const out={sites,count:list.length,wanted:want,wanted_alive:false,items:[]};
  for (const c of list) {
    const item={id:c.id,alive:!!c.alive};
    if (c.title) item.title=String(c.title).slice(0,80);
    if (c.url) item.url=String(c.url).slice(0,120);
    if (c.attached!=null) item.attached=c.attached;
    out.items.push(item);
    if (c.id===want && c.alive) out.wanted_alive=true;
  }
  console.log(JSON.stringify(out));
})().catch(e=>{console.error('BRIDGE_STATUS_FAIL:'+String(e&&e.message?e.message:e).slice(0,200)); process.exit(1);});
"@
$jsPath = Join-Path $ci "_tmp-bridge-status-1753.cjs"
$utf8 = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($jsPath, $js, $utf8)
$bridge = Join-Path $deskRoot "抖音自用采集台\data\bridge.json"
$plan = Get-Content -LiteralPath (Join-Path $ci "plan-round-20261116-165419.json") -Raw -Encoding UTF8 | ConvertFrom-Json
$node = "C:\Program Files\nodejs\node.exe"
Write-Output "===BRIDGE_STATUS==="
Write-Output ("JS=" + $jsPath)
Write-Output ("BRIDGE_FILE=" + $bridge + " exists=" + (Test-Path -LiteralPath $bridge))
$out = & $node $jsPath $bridge $plan.connection_id 2>&1
Write-Output ("NODE_EXIT=" + $LASTEXITCODE)
$t = [string]($out -join "`n")
if ($t -match "(?i)cookie|authorization|password|secret|set-cookie|credential") { Write-Output "REDACTED_SENSITIVE" } else {
  if ($t.Length -gt 4000) { $t = $t.Substring(0,4000) }
  Write-Output $t
}
Remove-Item -LiteralPath $jsPath -Force -ErrorAction SilentlyContinue

Write-Output "===WINDOWS==="
try {
  Get-Process | Where-Object { $_.MainWindowTitle } | ForEach-Object {
    $title = [string]$_.MainWindowTitle
    if ($title -match "抖音|采集|验证|验证码|获客|发送|queue|方隅") {
      Write-Output ("WIN|pid=" + $_.Id + "|name=" + $_.ProcessName + "|title=" + $title.Substring(0, [Math]::Min(80, $title.Length)) + "|start=" + $_.StartTime.ToString("yyyy-MM-dd HH:mm:ss"))
    }
  }
} catch { Write-Output "WINDOW_ENUM_FAIL" }

Write-Output "DONE"
