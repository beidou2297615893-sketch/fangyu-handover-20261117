"""On Start/Continue, read submitted unknown receipts before the approved queue.

A click of 启动／继续 authorizes this read. The unknown item itself is never
published again. It becomes sent only when our reply is already visible.
It is preserved only when the read finishes the whole thread and confirms
that our reply is absent. A failed or unfinished read isolates that one
receipt: it stays unknown, is not resent, and does not block the other
approved items. Captcha, identity, reservation, and account holds still
stop the whole line.
"""
import re

SKIP_LIMIT = 12
SKIP_PAUSE = f'连续{SKIP_LIMIT}条被拒绝或跳过，已暂停。请检查已登录页面和平台提示后再点启动／继续。'
LIVE_STOPS = {
    'captcha': '抖音当前要求安全验证，请在已登录页面完成验证，再点启动／继续。',
    'rate_limit': '抖音当前提示操作频繁或已限流，请等平台解除限制后再点启动／继续。',
    'identity': '当前账号身份无法核验，请确认已登录正确账号后再点启动／继续。',
    'page_unresponsive': '已登录的抖音页面没有响应，请刷新该页面，加载完成后再点启动／继续。',
}

def current_stop(value):
    """Use fresh structured signals. The adapter's generic 3002123 hint is not evidence."""
    value = value or {}
    error = str(value.get('error') or '')
    if error.startswith('CURRENT_GATE:') and error[13:] in LIVE_STOPS:
        return error[13:]
    receipt = value.get('receipt') or {}
    message = str(receipt.get('message') or '')
    if re.search(r'请求过于频繁|操作(过于|太)?频繁|访问(过于|太)?频繁|too many requests|rate limit', message, re.I) or _http_status_number(error)==429:
        return 'rate_limit'
    if re.search(r'请.{0,8}完成.{0,6}验证|需要安全验证|captcha required', message, re.I):
        return 'captcha'
    if _contains(error, 'no polling client','no active douyin','fixed connection unavailable',
                 'connection mismatch','econnrefused','failed to fetch','request timeout','只读核对连接未返回'):
        return 'page_unresponsive'
    if _contains(error, *_IDENTITY_MARKERS, 'batch account binding missing'):
        return 'identity'
    return None
AUDIT_SOURCE = 'explicit_start_continue'
MARK_KEPT = 'kept, not resent'
MARK_SENT = 'confirmed_sent_from_read_only_check'
ABSENCE_CONDITION = 'read-only check completed and confirmed no own reply'

_IDENTITY_MARKERS = (
    'identity not verified',
    'identity changed',
    'task account mismatch',
    'account mismatch',
    '账号不匹配',
    '账号核对',
)


def build_verify_command(node, adapter, video, cid):
    """Read-only CLI. The reply text stays in the attempt file, not on argv."""
    if not str(video).isdigit() or not str(cid).isdigit():
        raise RuntimeError('目标编号无效')
    return [str(node), str(adapter), '--verify-own-reply', str(video), str(cid)]


BLOCKED_REASONS = frozenset({
    'bad_args', 'control_lock', 'runner_locked', 'lock_uncertain', 'account_mismatch',
    'stop_marker', 'captcha', 'reserved', 'no_submitted', 'no_items', 'read_incomplete',
    'identity', 'rate_limit', 'page_unresponsive', 'consecutive_skips', 'checked',
})
ERROR_TYPES = frozenset({
    'timeout', 'spawn_error', 'non_json_output', 'http_status', 'login_or_identity',
    'network', 'pagination_incomplete', 'missing_param', 'cli_reported_error', 'other',
})
CLI_ERROR_CODES = frozenset({
    'none', 'timeout', 'spawn', 'non_json', 'http', 'identity', 'network',
    'pagination', 'missing_param', 'cli_reported', 'other',
})
KNOWN_PLATFORM_CODES = frozenset({0, 2053, 2055, 2147, 2209, 3056, 3220, 3002123})
STAGES = frozenset({
    'adapter', 'command', 'cli_timeout', 'cli_spawn', 'cli_output', 'cli_result',
    'cli_identity', 'read_exception', 'read_result', 'own_reply_check', 'gate', 'other',
})
READ_REASONS = frozenset({
    'no_video_detail', 'video_unverified', 'comments_status', 'scan_budget',
    'read_timeout', 'target_not_visible', 'reply_list_unavailable', 'incomplete',
    'missing',
})
_HTTP_RE = re.compile(r'(?i)\bhttp(?:/\d(?:\.\d)?)?\s+(\d{3})\b')
_HTTP_FIELD_RE = re.compile(r'(?i)\bhttp_status\s*[=:]\s*(\d{3})\b')


def _as_text(value):
    if value is None:
        return ''
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return str(value)


def _http_status_number(*parts):
    for part in parts:
        if isinstance(part, dict):
            number = part.get('http_status')
            if isinstance(number, int) and 100 <= number <= 599:
                return number
            continue
        text = _as_text(part)
        match = _HTTP_RE.search(text) or _HTTP_FIELD_RE.search(text)
        if match:
            number = int(match.group(1))
            if 100 <= number <= 599:
                return number
    return None


def _platform_code(*parts):
    for part in parts:
        if not isinstance(part, dict):
            continue
        receipt = part.get('receipt') if isinstance(part.get('receipt'), dict) else {}
        for number in (receipt.get('status_code'), part.get('comments_status'), part.get('status_code')):
            if isinstance(number, int) and number in KNOWN_PLATFORM_CODES:
                return number
    return None


def _contains(text, *needles):
    lowered = _as_text(text).lower()
    return any(needle.lower() in lowered for needle in needles)


def _bounded_int(value):
    """A platform status code. Anything else, including bools and free text, is dropped."""
    if isinstance(value, bool):
        return None
    if isinstance(value, str) and re.fullmatch(r'-?\d{1,9}', value):
        value = int(value)
    if isinstance(value, int) and -999999999 <= value <= 999999999:
        return value
    return None


def read_reason(diagnosis):
    """Whitelist the reader subreason. Anything else is missing, never copied text."""
    if not isinstance(diagnosis, dict):
        return 'missing'
    reason = diagnosis.get('reason')
    if isinstance(reason, str) and reason in READ_REASONS and reason != 'missing':
        return reason
    if diagnosis.get('read_timeout') is True:
        return 'read_timeout'
    if diagnosis.get('no_video_detail') is True:
        return 'no_video_detail'
    return 'missing'


def classify_diagnostic(stage, hint='', text='', value=None, diagnosis=None):
    """Map a read failure to fixed codes. Source text is not copied into the result."""
    stage = stage if stage in STAGES else 'other'
    hint = _as_text(hint)
    blob = '\n'.join(_as_text(part) for part in (hint, text))
    if isinstance(value, dict):
        blob += '\n' + _as_text(value.get('error'))
    http_status = _http_status_number(value, text, hint)
    platform = _platform_code(value, diagnosis)
    identity = _contains(blob, *_IDENTITY_MARKERS)
    timeout = stage == 'cli_timeout' or hint == 'TimeoutExpired' or _contains(blob, 'timeout', '超时', 'timed out') \
        or (isinstance(diagnosis, dict) and (diagnosis.get('read_timeout') is True
                                            or diagnosis.get('reason') == 'read_timeout'))
    spawn = stage == 'cli_spawn' or hint in ('OSError', 'FileNotFoundError', 'PermissionError')
    non_json = value is None and stage in ('cli_output', 'cli_result') or hint == 'JSONDecodeError'
    missing = stage == 'command' or hint in ('VerifyModeMissing', 'missing_param') or _contains(blob, '目标编号无效')
    network = _contains(blob, 'econnrefused', 'econnreset', 'failed to fetch', 'fetch failed',
                        'no polling client', 'no active douyin', 'connection unavailable',
                        '网络请求失败', 'http request failed')
    pagination = stage == 'read_result' and hint in ('scan_budget', 'reply_list_unavailable', 'target_not_visible', 'incomplete')
    if isinstance(diagnosis, dict):
        if diagnosis.get('incomplete') is True or diagnosis.get('reason') in (
                'scan_budget', 'reply_list_unavailable', 'target_not_visible', 'incomplete'):
            pagination = True
        if diagnosis.get('own_reply_state') == 'not_found' and diagnosis.get('check_complete') is not True:
            pagination = True
    if timeout:
        error_type, cli_error_code = 'timeout', 'timeout'
    elif spawn:
        error_type, cli_error_code = 'spawn_error', 'spawn'
    elif non_json:
        error_type, cli_error_code = 'non_json_output', 'non_json'
    elif http_status is not None:
        error_type, cli_error_code = 'http_status', 'http'
    elif identity:
        error_type, cli_error_code = 'login_or_identity', 'identity'
    elif network:
        error_type, cli_error_code = 'network', 'network'
    elif pagination:
        error_type, cli_error_code = 'pagination_incomplete', 'pagination'
    elif missing:
        error_type, cli_error_code = 'missing_param', 'missing_param'
    elif isinstance(value, dict) and value.get('status') not in (None, 'own_reply_check'):
        error_type = 'cli_reported_error'
        cli_error_code = platform if platform is not None else 'cli_reported'
    elif platform is not None and stage == 'read_result':
        error_type, cli_error_code = 'cli_reported_error', platform
    else:
        error_type, cli_error_code = 'other', 'none' if stage == 'own_reply_check' else 'other'
    if error_type not in ERROR_TYPES:
        error_type = 'other'
    if cli_error_code not in CLI_ERROR_CODES and cli_error_code not in KNOWN_PLATFORM_CODES:
        cli_error_code = 'other'
    complete = pagination_complete(diagnosis) if error_type not in ('pagination_incomplete', 'timeout') else False
    detail_status = _bounded_int(diagnosis.get('detail_status')) if isinstance(diagnosis, dict) else None
    comments_status = _bounded_int(diagnosis.get('comments_status')) if isinstance(diagnosis, dict) else None
    return sanitize_diagnostic({
        'stage': stage,
        'error_type': error_type,
        'http_status': http_status,
        'cli_error_code': cli_error_code,
        'pagination_complete': complete,
        'reason': read_reason(diagnosis),
        'detail_status': detail_status,
        'comments_status': comments_status,
    })


def sanitize_diagnostic(supplied):
    """Drop every field that is not a fixed code or a numeric HTTP status."""
    if not isinstance(supplied, dict):
        supplied = {}
    error_type = supplied.get('error_type')
    stage = supplied.get('stage')
    http_status = supplied.get('http_status')
    cli_error_code = supplied.get('cli_error_code')
    if error_type not in ERROR_TYPES:
        error_type = 'other'
    if stage not in STAGES:
        stage = 'other'
    if not isinstance(http_status, int) or not 100 <= http_status <= 599:
        http_status = None
    if cli_error_code not in CLI_ERROR_CODES and cli_error_code not in KNOWN_PLATFORM_CODES:
        cli_error_code = 'other'
    reason = supplied.get('reason')
    if reason not in READ_REASONS:
        reason = 'missing'
    return {
        'stage': stage,
        'error_type': error_type,
        'http_status': http_status,
        'cli_error_code': cli_error_code,
        'pagination_complete': supplied.get('pagination_complete') is True,
        'reason': reason,
        'detail_status': _bounded_int(supplied.get('detail_status')),
        'comments_status': _bounded_int(supplied.get('comments_status')),
    }


def pagination_complete(diagnosis):
    if not isinstance(diagnosis, dict):
        return False
    return diagnosis.get('check_complete') is True and diagnosis.get('incomplete') is not True \
        and diagnosis.get('read_timeout') is not True and diagnosis.get('own_reply_state') in ('found', 'not_found')


def diagnostic_from_read(diagnosis):
    if isinstance(diagnosis, dict) and isinstance(diagnosis.get('diagnostic'), dict):
        return sanitize_diagnostic(diagnosis['diagnostic'])
    reason = diagnosis.get('reason') if isinstance(diagnosis, dict) else ''
    return classify_diagnostic('read_result', reason, diagnosis=diagnosis if isinstance(diagnosis, dict) else None)


def diagnosis_from_cli(value, stderr=''):
    """Anything other than a finished own-reply check is an incomplete read."""
    if not isinstance(value, dict):
        diagnosis = {'own_reply_state': 'unchecked', 'reason': 'verify_failed', 'submission_attempted': False}
        diagnosis['diagnostic'] = classify_diagnostic('cli_output', 'JSONDecodeError', stderr, None, diagnosis)
        return diagnosis
    if value.get('status') != 'own_reply_check':
        error = _as_text(value.get('error'))
        identity = _contains(error, *_IDENTITY_MARKERS)
        diagnosis = {'own_reply_state': 'unchecked', 'submission_attempted': False, 'reason': 'verify_failed'}
        stop = current_stop(value)
        if stop:
            diagnosis['_stop'] = stop
        diagnosis['diagnostic'] = classify_diagnostic(
            'cli_identity' if identity else 'cli_result', '', stderr, value, diagnosis)
        return diagnosis
    diagnosis = dict(value.get('diagnosis') or {})
    diagnosis['submission_attempted'] = value.get('submission_attempted') is True or diagnosis.get('submission_attempted') is True
    diagnosis.pop('_stop', None)
    if diagnosis.get('current_gate') in LIVE_STOPS:
        diagnosis['_stop'] = diagnosis['current_gate']
    diagnosis['diagnostic'] = classify_diagnostic('own_reply_check', '', stderr, value, diagnosis)
    return diagnosis


def select_stuck(rows, prefix, preserved, submitted, receipts, isolated=None):
    reserved, captcha, pending = [], [], []
    unsubmitted = []
    preserved = set(preserved or [])
    isolated = set(isolated or [])
    submitted = submitted or {}
    receipts = receipts or {}
    for row in rows or []:
        token = str(row.get('token') or '')
        if not prefix or not token.startswith(prefix):
            continue
        cid = str(row.get('comment') or '')
        if row.get('status') == 'reserved':
            reserved.append(cid)
            continue
        if row.get('status') != 'unknown' or not cid or cid in preserved or cid in isolated:
            continue
        stamp = submitted.get(cid)
        if not stamp:
            unsubmitted.append(cid)
            continue
        receipt = receipts.get(cid) if isinstance(receipts.get(cid), dict) else {}
        inner = receipt.get('receipt') if isinstance(receipt.get('receipt'), dict) else {}
        item = {
            'cid': cid,
            'status_code': inner.get('status_code'),
            'submitted_at': str(stamp),
            'attempt_id': row.get('token'),
            'receipt': receipt,
        }
        pending.append(item)
    pending.sort(key=lambda item: item['submitted_at'])
    return {'reserved': reserved, 'captcha': captcha, 'pending': pending, 'unsubmitted': unsubmitted}


def own_reply_matches(diagnosis, attempt, target_cid, attempt_id):
    if not isinstance(diagnosis, dict) or diagnosis.get('own_reply_state') != 'found':
        return False
    own = diagnosis.get('own_reply')
    reply = (attempt or {}).get('reply') if isinstance(attempt, dict) else None
    draft = (reply or {}).get('draft_text') if isinstance(reply, dict) else None
    cid = str((own or {}).get('cid') or '')
    return bool(attempt_id) and bool(draft) and cid.isdigit() \
        and own.get('text') == draft and own.get('sec_uid') == attempt.get('account_uid') \
        and bool(attempt.get('account_uid')) and str(own.get('reply_id')) == str(target_cid)


def absence_confirmed(diagnosis):
    """True only after a finished thread read that did not find our reply.

    Incomplete pagination, timeouts, missing reply pages, a hidden target,
    or a platform error are not confirmation that the reply is absent.
    """
    if not isinstance(diagnosis, dict) or diagnosis.get('_stop') == 'identity':
        return False
    if diagnosis.get('own_reply_state') != 'not_found' or diagnosis.get('check_complete') is not True:
        return False
    if diagnosis.get('target_present') is not True:
        return False
    if diagnosis.get('read_timeout') is True or diagnosis.get('incomplete') is True:
        return False
    if diagnosis.get('submission_attempted') is not False:
        return False
    if diagnosis.get('comments_status', 0) not in (0, None):
        return False
    return True


def classify(diagnosis, attempt, item):
    if not isinstance(diagnosis, dict):
        return 'unchecked'
    stop = diagnosis.get('_stop')
    diagnostic = diagnostic_from_read(diagnosis)
    if stop not in LIVE_STOPS:
        if diagnostic['http_status'] == 429:
            stop = 'rate_limit'
        elif diagnostic['error_type'] in ('timeout', 'network') or diagnosis.get('read_timeout') is True:
            stop = 'page_unresponsive'
    if stop in LIVE_STOPS:
        return 'stop_' + stop
    if diagnosis.get('submission_attempted') is True:
        return 'unchecked'
    if own_reply_matches(diagnosis, attempt, item['cid'], item.get('attempt_id')):
        return 'found'
    if absence_confirmed(diagnosis):
        return 'not_found'
    return 'unchecked'


def unresolved_blockers(rows, preserved, prefix, isolated=None):
    """Same stop the runner uses: a new unknown or reservation is not sendable.

    Preserved and isolated comments are already decided. They are not resent
    and they do not block the rest of the queue.
    """
    preserved = set(map(str, preserved or []))
    isolated = set(map(str, isolated or []))
    skipped = preserved | isolated
    return [row for row in rows or []
            if str(row.get('token') or '').startswith(prefix or '')
            and row.get('status') in ('unknown', 'reserved')
            and not (row.get('status') == 'unknown' and str(row.get('comment') or '') in skipped)]


def receipt_blocks_queue(status, cid, preserved, isolated):
    """None when this ledger row may stay while the approved queue continues."""
    if status == 'reserved':
        return 'reserved'
    if status == 'unknown' and str(cid) not in set(map(str, preserved or [])) \
            and str(cid) not in set(map(str, isolated or [])):
        return 'unknown'
    return None


def may_launch_sender(resolution, send_allowed):
    """A per-item isolation does not override an account or platform hold."""
    if send_allowed is not True:
        return False
    if not isinstance(resolution, dict) or not resolution.get('continue_queue'):
        return False
    if resolution.get('action') == 'diagnose':
        return False
    return True


def approved_targets_after_resolution(queue_items, ledger_rows):
    """Send only rows that are already in the approved queue and have no ledger record."""
    used_comments = {str(row.get('comment')) for row in ledger_rows or []}
    used_customers = {str(row.get('customer')) for row in ledger_rows or [] if row.get('customer')}
    return [item for item in queue_items or []
            if str(item.get('cid')) not in used_comments and str(item.get('uid') or '') not in used_customers]


def runner_script_after_resolution(resolution, previous_status):
    """None means do not start a sender. A resolved start uses the approved-queue runner.

    Captcha / hold / identity stops already set continue_queue=False in resolve_on_start.
    Do not route ordinary blocked/unknown leftovers to the captcha-only resume script.
    """
    if not resolution.get('continue_queue'):
        return None
    return 'batch_reply_runner.py'


def _result(summary, *, continue_queue, action, wrote=False, auth=None, records=None,
            status=None, handled=False):
    return {
        'summary': summary,
        'continue_queue': continue_queue,
        'handled': handled,
        'wrote': wrote,
        'auth': auth,
        'records': list(records or []),
        'status': status,
        'start_sender': False,
        'submission_attempted': False,
        'action': action,
    }


def diagnose_argv_action(args):
    """Exact diagnose flag only. Any extra, duplicate, or near-spelling never starts a send."""
    exact = '--diagnose-unknown'
    args = list(args or [])
    def near(token):
        if not isinstance(token, str) or token == exact:
            return False
        folded = token.lower().replace('_', '')
        return 'diagnos' in folded
    if any(token == exact for token in args):
        return 'diagnose' if args == [exact] else 'reject'
    if any(near(token) for token in args):
        return 'reject'
    return 'start'


def inspect_task_locks(paths, open_lock):
    """Check locks that already exist. Never creates one. Unknown blocks a free result."""
    state = 'free'
    for path in paths:
        if path is None or not path.exists() or not path.is_file():
            continue
        try:
            result = open_lock(path)
        except OSError:
            return 'unknown'
        if result == 'unknown':
            return 'unknown'
        if result == 'busy':
            state = 'busy'
        elif result != 'free':
            return 'unknown'
    return state


def _gate(state):
    if state.get('lock_uncertain'):
        return '锁状态无法确认，已停线。'
    if state.get('runner_busy'):
        return '已有回复任务运行中，请先等待当前任务停止。'
    if not state.get('runner_account') or state.get('identity_uid') != state.get('runner_account'):
        return '当前账号与任务账号不一致，已停线。没有改动未知记录，也没有继续发送。'
    stop = state.get('stop_marker')
    if stop:
        return '任务仍有停止标记，已停线。没有跳过未知记录，也没有继续发送。'
    return None


def _sent_evidence(item, attempt, diagnosis):
    own = diagnosis['own_reply']
    return {
        'status': 'sent',
        'automatic_retry': False,
        'submission_attempted': False,
        'verified_by': 'read_only_own_reply',
        'receipt': {
            'status_code': 0,
            'cid': own['cid'],
            'text': attempt['reply']['draft_text'],
            'sec_uid': attempt['account_uid'],
            'reply_id': item['cid'],
            'success_basis': 'read_only_reply_visible',
        },
        'prior_status_code': item.get('status_code'),
        'prior_receipt': (item.get('receipt') or {}).get('receipt'),
        'diagnosis_state': 'found',
    }


def _event(item, kind, action, now):
    kept = action == 'preserve'
    event = {
        'at': now,
        'source': AUDIT_SOURCE,
        'user_statement': '用户点击启动／继续',
        'mark': MARK_KEPT if kept else MARK_SENT,
        'note': MARK_KEPT if kept else '只读核对看到本账号回复，记为已发送；本次未重发',
        'status_code': item.get('status_code'),
        'own_reply_state': kind,
        'skip_unknown_comments': [item['cid']] if kept else [],
        'submission_attempted': False,
        'automatic_retry': False,
        'user_confirmed': True,
        'account_checked': True,
    }
    if kept:
        event['absence_condition'] = ABSENCE_CONDITION
    return event


def _auth(auth, item, kind, action, now):
    body = dict(auth or {})
    preserved = list(body.get('preserve_unknown_comments') or [])
    if action == 'preserve' and item['cid'] not in preserved:
        preserved.append(item['cid'])
    body['preserve_unknown_comments'] = sorted(preserved)
    body['events'] = list(body.get('events') or []) + [_event(item, kind, action, now)]
    return body


def _status(summary, continue_queue, action):
    return {
        'status': 'ready_after_previous_check' if continue_queue else 'blocked',
        'reason': summary,
        'automatic_retry': False,
        'submission_attempted': False,
        'resolution': action,
    }


def _read(hooks, item, attempt):
    try:
        diagnosis = hooks['read_reply'](item, attempt)
    except Exception as exc:
        return {'own_reply_state': 'unchecked', 'reason': 'verify_failed', 'submission_attempted': False,
                'diagnostic': classify_diagnostic('read_exception', type(exc).__name__,
                                                getattr(exc, 'stderr', None) or '')}
    if not isinstance(diagnosis, dict):
        return {'own_reply_state': 'unchecked', 'reason': 'verify_failed', 'submission_attempted': False,
                'diagnostic': classify_diagnostic('read_result', 'unchecked')}
    return diagnosis


def _audit_diagnostic(auth, diagnostic, now):
    """Record the failed read without adding the comment to the preserve list."""
    body = dict(auth or {})
    body['preserve_unknown_comments'] = list((auth or {}).get('preserve_unknown_comments') or [])
    body['events'] = list((auth or {}).get('events') or []) + [{
        'at': now,
        'source': 'unknown_read_diagnostic',
        'stage': diagnostic['stage'],
        'error_type': diagnostic['error_type'],
        'http_status': diagnostic['http_status'],
        'cli_error_code': diagnostic['cli_error_code'],
        'pagination_complete': diagnostic['pagination_complete'],
        'reason': diagnostic.get('reason'),
        'detail_status': diagnostic.get('detail_status'),
        'comments_status': diagnostic.get('comments_status'),
        'submission_attempted': False,
    }]
    return body


def _isolate(auth, item, now, diagnostic=None):
    """Keep one unfinished receipt unknown. Do not call that confirmation it was never sent."""
    body = dict(auth or {})
    isolated = list(body.get('isolated_unknown_comments') or [])
    if item['cid'] not in isolated:
        isolated.append(item['cid'])
    body['isolated_unknown_comments'] = sorted(isolated)
    body['preserve_unknown_comments'] = list((auth or {}).get('preserve_unknown_comments') or [])
    event = {
        'at': now,
        'source': 'unknown_read_isolated',
        'user_statement': '用户点击启动／继续',
        'mark': 'isolated, not resent',
        'note': '只读核对没有完成，这条保持未知，不重发',
        'own_reply_state': 'unchecked',
        'isolated_comments': [item['cid']],
        'submission_attempted': False,
        'automatic_retry': False,
        'user_confirmed': True,
        'account_checked': True,
    }
    if isinstance(item.get('status_code'), int) and not isinstance(item.get('status_code'), bool):
        event['status_code'] = item['status_code']
    if isinstance(diagnostic, dict):
        for key in ('stage', 'error_type', 'http_status', 'cli_error_code', 'pagination_complete',
                    'reason', 'detail_status', 'comments_status'):
            if key in diagnostic:
                event[key] = diagnostic[key]
    body['events'] = list(body.get('events') or []) + [event]
    return body


def _stop(summary, auth=None, records=None, diagnostic=None, now=None, blocked_reason='read_incomplete'):
    if blocked_reason not in BLOCKED_REASONS:
        blocked_reason = 'read_incomplete'
    if diagnostic is not None:
        diagnostic = sanitize_diagnostic(diagnostic)
        auth = _audit_diagnostic(auth, diagnostic, now or '')
    wrote = auth is not None or bool(records)
    status = _status(summary, False, 'stop')
    status['blocked_reason'] = blocked_reason
    if diagnostic is not None:
        status['diagnostic'] = diagnostic
    return _result(summary, continue_queue=False, action='stop', wrote=wrote, auth=auth,
                   records=records, status=status, handled=False)


def resolve_on_start(state, hooks):
    """Resolve submitted unknowns, then say whether the approved queue may start."""
    gate = _gate(state)
    if gate:
        if state.get('lock_uncertain'):
            reason = 'lock_uncertain'
        elif state.get('runner_busy'):
            reason = 'runner_locked'
        elif not state.get('runner_account') or state.get('identity_uid') != state.get('runner_account'):
            reason = 'account_mismatch'
        else:
            reason = 'stop_marker'
        return _stop(gate, blocked_reason=reason)
    if not state.get('prefix'):
        return _stop('任务批次无法核验，已停线。没有改动未知记录，也没有继续发送。', blocked_reason='stop_marker')
    auth_body = state.get('auth') or {}
    selection = select_stuck(
        state.get('rows'), state.get('prefix'),
        auth_body.get('preserve_unknown_comments'),
        state.get('submitted'), state.get('receipts'),
        auth_body.get('isolated_unknown_comments'))
    if selection['reserved']:
        return _stop('仍有未完成的发送预留，已停线。没有跳过未知记录，也没有继续发送。', blocked_reason='reserved')

    auth = dict(auth_body)
    changed = False
    records = []
    now = hooks['now']()
    skips = 0
    for cid in selection['unsubmitted']:
        auth = _isolate(auth, {'cid': cid}, now, {'reason': 'missing', 'pagination_complete': False})
        changed = True
        skips += 1
        if skips >= SKIP_LIMIT:
            return _stop(SKIP_PAUSE, auth, records, blocked_reason='consecutive_skips')
    if not selection['pending']:
        if not changed:
            return _result('没有待核对的已提交未知记录。', continue_queue=True, action='none')
        summary = '有未能确认是否发出的未知记录，已原样跳过，不重发。其余已审队列可以继续。'
        return _result(summary, continue_queue=True, action='resolved', wrote=True, auth=auth,
                       status=_status(summary, True, 'resolved'), handled=True) | {'consecutive_skips':skips}

    attempts = state.get('attempts') or {}
    for item in selection['pending']:
        diagnosis = _read(hooks, item, attempts.get(item['cid']))
        kind = classify(diagnosis, attempts.get(item['cid']), item)
        if kind.startswith('stop_'):
            reason = kind[5:]
            return _stop(LIVE_STOPS[reason], auth if changed else state.get('auth'), records,
                         diagnostic_from_read(diagnosis), now, reason)
        if kind == 'found':
            evidence = _sent_evidence(item, attempts[item['cid']], diagnosis)
            if evidence.get('status') != 'sent' or evidence.get('submission_attempted') is not False:
                raise RuntimeError('只读核对不能重发')
            task = dict(attempts[item['cid']])
            task.setdefault('comment_id', item['cid'])
            task['attempt_id'] = item['attempt_id']
            records.append({'task': task, 'result': evidence})
            auth = _auth(auth, item, 'found', 'record_sent', now)
            skips = 0
            changed = True
            continue
        if kind == 'not_found':
            auth = _auth(auth, item, 'not_found', 'preserve', now)
        else:
            auth = _isolate(auth, item, now, diagnostic_from_read(diagnosis))
        changed = True
        skips += 1
        if skips >= SKIP_LIMIT:
            return _stop(SKIP_PAUSE, auth, records, blocked_reason='consecutive_skips')

    summary = '已提交的未知记录已只读核对。看到本账号回复的记为已发送；完整核对后没有回复的保持未知并跳过。没核对完的保持原样，不重发，也不挡住其余已审队列。'
    return _result(summary, continue_queue=True, action='resolved', wrote=True, auth=auth,
                   records=records, status=_status(summary, True, 'resolved'), handled=True) | {'consecutive_skips':skips}


def _diagnose_report(blocked_reason, items=None):
    if blocked_reason not in BLOCKED_REASONS:
        blocked_reason = 'read_incomplete'
    report = _result('blocked:' + blocked_reason, continue_queue=False, action='diagnose')
    report['blocked_reason'] = blocked_reason
    report['items'] = list(items or [])
    report['preserve_unchanged'] = True
    return report


def diagnose_unknown(state, hooks):
    """Reuse the start-path read and classification. Never preserve, record, or continue."""
    if state.get('lock_uncertain'):
        return _diagnose_report('lock_uncertain')
    if state.get('runner_busy'):
        return _diagnose_report('runner_locked')
    if not state.get('runner_account') or state.get('identity_uid') != state.get('runner_account'):
        return _diagnose_report('account_mismatch')
    if state.get('stop_marker') or not state.get('prefix'):
        return _diagnose_report('stop_marker')
    selection = select_stuck(
        state.get('rows'), state.get('prefix'),
        (state.get('auth') or {}).get('preserve_unknown_comments'),
        state.get('submitted'), state.get('receipts'))
    if selection['reserved']:
        return _diagnose_report('reserved')
    if selection['unsubmitted']:
        return _diagnose_report('no_submitted')
    if not selection['pending']:
        return _diagnose_report('no_items')
    items = []
    attempts = state.get('attempts') or {}
    blocked_reason = 'checked'
    for item in selection['pending']:
        diagnosis = _read(hooks, item, attempts.get(item['cid']))
        kind = classify(diagnosis, attempts.get(item['cid']), item)
        observed = diagnostic_from_read(diagnosis)
        items.append({
            'kind': kind,
            'own_reply_state': diagnosis.get('own_reply_state') if isinstance(diagnosis, dict) else 'unchecked',
            'reason': observed.get('reason'),
            'diagnostic': observed,
        })
        if kind.startswith('stop_'):
            blocked_reason = kind[5:]
        elif kind not in ('found', 'not_found') and blocked_reason == 'checked':
            blocked_reason = 'read_incomplete'
    return _diagnose_report(blocked_reason, items)


def control_lock_result(diagnose_only):
    """Lock failure is an enumerated block. Diagnose never asks for a status write."""
    payload = {
        'action': 'diagnose' if diagnose_only else 'blocked',
        'blocked_reason': 'control_lock',
        'error_type': 'other',
        'stage': 'gate',
        'http_status': None,
        'cli_error_code': 'other',
        'continue_queue': False,
        'wrote': False,
        'records': [],
    }
    return payload, not diagnose_only


def commit_resolution(result, savers):
    """Write the ledger outcome and the preserve audit. Never starts a sender."""
    if result.get('start_sender'):
        raise RuntimeError('核对流程不能自行启动发送')
    records = result.get('records') or []
    for record in records:
        evidence = record.get('result') or {}
        if evidence.get('status') != 'sent' or evidence.get('submission_attempted') is not False \
                or evidence.get('automatic_retry') is not False:
            raise RuntimeError('只读核对不能把上一笔写成未发送或重发')
    if not result.get('wrote'):
        if result.get('status') is not None and savers.get('status'):
            savers['status'](result['status'])
        return
    for record in records:
        savers['record'](record['task'], record['result'])
    if result.get('auth') is not None:
        savers['auth'](result['auth'])
    if result.get('status') is not None and savers.get('status'):
        savers['status'](result['status'])
