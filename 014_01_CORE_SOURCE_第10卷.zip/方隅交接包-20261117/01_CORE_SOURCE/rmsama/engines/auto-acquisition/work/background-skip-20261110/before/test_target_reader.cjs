const assert = require('node:assert/strict');
const vm = require('node:vm');
const {buildPageCheck, readTarget} = require('./target_reader.cjs');
(async()=>{
 let calls=0;
 const browser={__bridge:{getDetail:async()=>({status_code:0,aweme_detail:{aweme_id:'1'}}),
   getComments:async(video,cursor)=>{calls++; return {status_code:0,comments:[{cid:String(cursor+10),aweme_id:'1'}],cursor:cursor+1,has_more:1};}}};
 const client={call:async options=>({ok:true,connection:'connection',value:await vm.runInNewContext(options.expression,{window:browser,setTimeout,clearTimeout})})};
 const result=await readTarget(client,'connection','1','13',{budgetMs:1000});
 assert.equal(result.target_present,true);
 assert.equal(calls,4);
 assert.equal(result.pages,4);
 // A stalled read must release the browser polling loop; no long pagination loop inside it.
 browser.__bridge.getComments=()=>new Promise(()=>{});
 const timed=await vm.runInNewContext(buildPageCheck('1','13',0,false,10),{window:browser,setTimeout,clearTimeout});
 assert.equal(timed.read_timeout,true);
 assert.equal(timed.target_present,undefined);
 // Explicit platform response must be returned, never converted to a timeout or a success.
 browser.__bridge.getComments=async()=>({status_code:3002123});
 const blocked=await readTarget(client,'connection','1','13');
 assert.equal(blocked.comments_status,3002123);
 assert.notEqual(blocked.target_present,true);
 console.log('target reader: split pagination, bounded stall, platform response PASS');
})().catch(e=>{console.error(e);process.exitCode=1;});
