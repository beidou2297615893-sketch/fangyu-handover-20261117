'use strict';

// Only examine the fixed page's visible verification UI, never comment text or credentials.
function visiblePageGate() {
 if (/^\/ucenter\/security(?:\/|$)/i.test(location.pathname)) return 'captcha';
 const visible = element => {
  const style = getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0'
      && rect.width > 0 && rect.height > 0;
 };
 const widgets = document.querySelectorAll('iframe[src*="rmc.bytedance.com"],iframe[src*="captcha"],iframe[src*="verifycenter"],#captcha_container,#verify-center,[id^="captcha-verify"]');
 if (Array.from(widgets).some(visible)) return 'captcha';
 for (const box of document.querySelectorAll('[role="dialog"],[role="alert"],[role="status"],[class*="toast"],[class*="Toast"]')) {
  if (!visible(box)) continue;
  const message=(box.innerText || '').trim();
  if (/操作(过于|太)?频繁|请求(过于|太)?频繁|访问(过于|太)?频繁|too many requests/i.test(message)) return 'rate_limit';
  if (/请.{0,8}完成.{0,6}验证|拖动滑块|安全验证|captcha required/i.test(message)) return 'captcha';
 }
 return 'ready';
}
async function assertPageReady(client, connId) {
 if (!connId) throw Error('CURRENT_GATE:page_unresponsive');
 let response;
 try {
  response = await client.call({site:'douyin.com',connId,timeout:10000,expression:'('+visiblePageGate.toString()+')()'});
 } catch {
  throw Error('CURRENT_GATE:page_unresponsive');
 }
 if (!response || !response.ok || response.connection !== connId) throw Error('CURRENT_GATE:page_unresponsive');
 if (response.value === 'captcha' || response.value === 'rate_limit') throw Error('CURRENT_GATE:'+response.value);
 if (response.value !== 'ready') throw Error('CURRENT_GATE:page_unresponsive');
}
function responseGate(raw) {
 if (!raw || raw.status_code == 0) return '';
 const message=String(raw.status_msg || raw.message || '');
 if (Number(raw.status_code)===429 || /操作(过于|太)?频繁|请求(过于|太)?频繁|访问(过于|太)?频繁|too many requests/i.test(message)) return 'rate_limit';
 if (/请.{0,8}完成.{0,6}验证|需要安全验证|captcha required/i.test(message)) return 'captcha';
 return '';
}
module.exports={assertPageReady,responseGate};
