"""自动续跑：发送暂停后代替手动点“启动／继续”。只调用与面板按钮完全相同的 control.py，不改账本/队列/授权。
只在可安全续跑的暂停(平台拒绝单条/回执未知/只读超时)后续跑；验证码、账号不符、用户暂停、无进展过多次则停手。"""
import json, time, subprocess, sys, datetime, pathlib
C = pathlib.Path(__file__).resolve().parent
ROOT = C.parents[1]
PY = r'C:\Users\rmsama\miniconda3\python.exe'
LOG = C / 'auto-continue.log'
STATE = C / 'auto-continue-state.json'
STOPFILE = C / 'auto-continue.stop'
OK = ('不会自动重发', '存在结果未知', '回执未知', '只读超时', '暂跳过', '目标评论核验未完成', '目标视频或评论列表无法核验', '平台目标核验未完成', '重新检查超时', 'queue_partial')
HARD = ('验证码', 'captcha', '账号不匹配', '账号不符', '未核验', '身份不符', '身份异常')
def log(m):
    with LOG.open('a', encoding='utf-8') as f: f.write(f"{datetime.datetime.now():%m-%d %H:%M:%S} {m}\n")
def rj(p):
    try: return json.loads(p.read_text(encoding='utf-8-sig'))
    except Exception: return {}
def busy():
    out = subprocess.run(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | % CommandLine"], capture_output=True, text=True, creationflags=0x08000000).stdout
    return any(k in out for k in ('control.py', 'batch_reply_runner.py', 'send_cli_once'))
def held():
    sys.path.insert(0, str(C))
    try:
        import importlib, send_hold; importlib.reload(send_hold); return send_hold.hold_reason()
    except Exception as e: return f'hold check failed {e}'
def main():
    noprog = 0; last_sent = None; cool = 60
    log('自动续跑已启动')
    while True:
        if STOPFILE.exists(): log('发现 auto-continue.stop，退出'); return
        time.sleep(20)
        if busy(): continue
        task = rj(C/'active.json').get('task')
        if not task: continue
        st = rj(pathlib.Path(task)/'batch-runner-status.json')
        status = st.get('status',''); reason = (st.get('reason') or '')
        if status in ('queue_complete','queue_empty'): continue
        if status not in ('blocked','queue_partial','unknown','stopped'): continue
        h = held()
        if h: log(f'用户/系统暂停中，不续跑：{h}'); time.sleep(300); continue
        if any(k in reason for k in HARD) and not any(k in reason for k in ('不会自动重发','存在结果未知')):
            log(f'停线类暂停，不自动续跑，需人工：{reason[:160]}'); time.sleep(300); continue
        if not (status=='queue_partial' or any(k in reason for k in OK)):
            log(f'未识别的暂停，不续跑：{status} {reason[:160]}'); time.sleep(300); continue
        sent = st.get('confirmed_sent')
        if last_sent is not None and sent is not None and sent <= last_sent: noprog += 1
        else: noprog = 0
        last_sent = sent
        if noprog >= 5:
            log(f'连续5次续跑无新增成功，疑似平台限流，停 30 分钟'); time.sleep(1800); noprog = 0; continue
        wait = min(cool * (2 ** noprog), 600)
        log(f'检测到可续跑暂停（{status}，累计{sent}）：{reason[:120]}；{wait}s 后自动点启动')
        time.sleep(wait)
        if busy(): continue
        subprocess.Popen([PY, str(C/'control.py')], cwd=str(ROOT), creationflags=0x08000000)
        log('已自动启动／继续')
        time.sleep(30)
if __name__ == '__main__':
    try: main()
    except Exception as e: log(f'异常退出 {e!r}')