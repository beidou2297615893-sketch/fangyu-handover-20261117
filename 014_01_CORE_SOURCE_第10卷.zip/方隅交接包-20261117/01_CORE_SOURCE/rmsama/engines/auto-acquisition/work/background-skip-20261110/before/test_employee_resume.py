import unittest
from pathlib import Path
from unittest.mock import Mock
import sys
import control
import unknown_resolution as rec

def fixture(code=3002123):
    return dict(prefix='batch-', runner_account='a', identity_uid='a', submitted={'123':'now'},
        receipts={'123':{'receipt':{'status_code':code}}}, auth={'events':[]},
        rows=[{'token':'batch-1','comment':'123','status':'unknown'}],
        attempts={'123':{'account_uid':'a','reply':{'draft_text':'test'}}})

def read(state='not_found', **kw):
    return dict(own_reply_state=state, target_present=True, check_complete=True,
                submission_attempted=False, **kw)

def resolve(d):
    return rec.resolve_on_start(fixture(), {'now':lambda:'now','read_reply':lambda *args:d})

class EmployeeResume(unittest.TestCase):
    def test_prior_code_does_not_override_completed_read(self):
        result=resolve(read())
        self.assertTrue(result['continue_queue'])
        self.assertEqual(['123'],result['auth']['preserve_unknown_comments'])
        self.assertFalse(result['submission_attempted'])
    def test_matching_reply_is_confirmed_without_resubmitting(self):
        result=resolve(read('found',own_reply=dict(cid='987',reply_id='123',sec_uid='a',text='test')))
        self.assertEqual([('sent',False)],[(row['result']['status'],row['result']['submission_attempted']) for row in result['records']])
    def test_incomplete_thread_separately_isolated(self):
        r=resolve(read('unchecked', incomplete=True))
        self.assertTrue(r['continue_queue'])
        self.assertEqual(r['auth']['isolated_unknown_comments'],['123'])
        self.assertEqual(r['auth']['preserve_unknown_comments'],[])
    def test_live_challenge_rate_identity_or_dead_page_remains_pending(self):
        for reason in ('captcha','rate_limit','identity','page_unresponsive'):
            with self.subTest(reason=reason):
                result=resolve({'_stop':reason,'own_reply_state':'unchecked'})
                self.assertEqual(result['status']['blocked_reason'],reason)
                self.assertFalse(result['continue_queue'])
                self.assertNotIn('123',(result['auth'] or {}).get('preserve_unknown_comments',[]))
                if reason=='page_unresponsive': self.assertIn('刷新',result['summary'])
    def test_timeout_without_prompt_and_http429(self):
        for diag, reason in [(rec.diagnosis_from_cli({'status':'not_sent','error':'HTTP 429'}),'rate_limit'),
                  (rec.diagnosis_from_cli({'status':'not_sent','error':'Request timeout — no polling client connected'}),'page_unresponsive')]:
            self.assertEqual(resolve(diag)['status']['blocked_reason'],reason)
    def test_startup_does_not_scan_a_long_streak(self):
        state=fixture()
        for i in range(13):
            cid=str(i+200)
            state['rows'].append({'comment':cid,'token':'batch-'+cid,'status':'unknown'})
            state['submitted'][cid]='now'
        count=[]
        result=rec.resolve_on_start(state,{'now':lambda:'now','read_reply':lambda *a: count.append(1) or read()})
        self.assertFalse(result['continue_queue'])
        self.assertEqual(len(count),12)
        self.assertEqual(len(result['auth']['preserve_unknown_comments']),12)

    def test_only_explicit_button_or_exact_legacy_panel(self):
        exe=Path(sys.executable)
        panel=control.P/'panel.py'
        pyw=exe.with_name('pythonw.exe')
        def parent(script=panel, image=pyw, extra=''):
            return {'ExecutablePath':str(image),'CommandLine':f'"{image}" "{script}"{extra}'}
        for value,ok in [(parent(),True),(parent(control.P/'auto_continue.py'),False),
              (parent(control.P.parent/'panel.py'),False),(parent(extra=' --panel.py'),False),
              (parent(image=pyw.parent.parent/'pythonw.exe'),False),({},False),(None,False)]:
            self.assertEqual(control.employee_start([],lambda:value),ok)
        for exc in [PermissionError(),ProcessLookupError()]:
            self.assertFalse(control.employee_start([],Mock(side_effect=exc)))
        self.assertTrue(control.employee_start(['--employee-start'],lambda:None))
        self.assertFalse(control.employee_start(['--employee-start','x'],lambda:parent()))
    def test_existing_approved_queue_is_reused(self):
        self.assertTrue(control.reuse_current_queue({'prepared_by':'douyin-classification-ready-v1','authorized':True,'account_uid':'u','items':[{}]},'u',{'status':'blocked'}))
        self.assertFalse(control.reuse_current_queue({'prepared_by':'douyin-classification-ready-v1','authorized':True,'account_uid':'u','items':[{}]},'u',{'status':'queue_complete'}))

if __name__=='__main__': unittest.main()
