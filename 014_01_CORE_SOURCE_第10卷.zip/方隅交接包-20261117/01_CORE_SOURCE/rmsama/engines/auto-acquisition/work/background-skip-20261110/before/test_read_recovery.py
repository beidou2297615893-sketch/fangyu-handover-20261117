import pathlib
import tempfile
import unittest
from unittest.mock import Mock
from read_recovery import recover_preflight


class ReadRecoveryTests(unittest.TestCase):
    def invoke(self, folder, read, **kwargs):
        return recover_preflight(pathlib.Path(folder), 'expected', read, Mock(), Mock(),
            probe=kwargs.pop('probe', Mock(return_value={'account_uid':'expected','connection_id':'new'})),
            ensure=Mock(),sleep=Mock(),**kwargs)

    def test_transport_recovers_locally_and_uses_new_binding(self):
        read=Mock(side_effect=[{'status':'not_sent','error':'Request timeout'},
                               {'status':'target_check','diagnosis':{'target_present':True}}])
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(self.invoke(folder,read)['status'],'target_check')
            self.assertIn('new',(pathlib.Path(folder)/'cli-current-binding.json').read_text())
        self.assertEqual(read.call_count,2)

    def test_unknown_submission_and_platform_prompt_are_never_retried(self):
        for response in ({'status':'unknown','error':'Request timeout'},
            {'status':'not_sent','error':'Request timeout','receipt':{'status_code':3002123}},
            {'status':'target_check','diagnosis':{'comments_status':3002123}}):
            with self.subTest(response=response),tempfile.TemporaryDirectory() as folder:
                read=Mock(return_value=response)
                self.assertEqual(self.invoke(folder,read),response)
                self.assertEqual(read.call_count,1)

    def test_changed_account_never_continues(self):
        read=Mock(return_value={'status':'not_sent','error':'Request timeout'})
        with tempfile.TemporaryDirectory() as folder,self.assertRaisesRegex(RuntimeError,'账号已变化'):
            self.invoke(folder,read,probe=Mock(return_value={'account_uid':'different'}))
        self.assertEqual(read.call_count,1)

    def test_persistent_disconnect_is_bounded(self):
        read=Mock(return_value={'status':'not_sent','error':'Request timeout'})
        with tempfile.TemporaryDirectory() as folder,self.assertRaisesRegex(RuntimeError,'本地已自动恢复'):
            self.invoke(folder,read)
        self.assertEqual(read.call_count,6)


if __name__=='__main__':unittest.main()
