"""Local evidence-only commercial screening. Never changes historical intent or receipts.

Amounts describe the commenter's current monthly housing budget only. No source-post
price, IP location, historical rent or unrelated number becomes a customer condition.
"""
import re
import sys
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'recency-priority'))
import recency
import retention30

VERSION = 'fangyu-commercial-fit-v4.3-20261106'
N = r'(?:\d+(?:\.\d+)?(?:[kK百千万元](?:\d)?)?|[零一二两三四五六七八九十百千万]+)'
AMOUNT = re.compile(r'(?P<a>'+N+r')\s*(?:(?P<sep>到|至|[-~—～])\s*(?P<b>'+N+r'))?\s*(?P<tail>以内|以下|左右|上下|多|以上|起|封顶|最多)?')
DIGITS = dict(zip('零一二三四五六七八九两', [0,1,2,3,4,5,6,7,8,9,2]))

def number(raw):
    raw = raw.lower().replace('元','')
    m = re.fullmatch(r'(\d+(?:\.\d+)?)([k百千万])?(\d)?', raw)
    if m:
        unit = {'百':100, 'k':1000, '千':1000, '万':10000}.get(m[2], 1)
        return float(m[1])*unit + (int(m[3])*unit/10 if m[3] else 0)
    total = 0; digit = 0; last_unit = 1
    for ch in raw:
        if ch in DIGITS: digit = DIGITS[ch]
        elif ch in '十百千万':
            unit = {'十':10,'百':100,'千':1000,'万':10000}[ch]
            total += (digit or 1)*unit; digit = 0; last_unit = unit
        else: return None
    # Spoken 一千三/一万五 abbreviate the next place; 一千三百 remains exact.
    return total + digit*(last_unit/10 if last_unit >= 100 and digit and '零' not in raw else 1)

def budget(text, rental_context=False):
    evidence=[]
    # 一两千/三四千 are intervals, not concatenated Chinese numbers.
    normalized=re.sub(r'(?<!\d)(\d{1,2})[,，](\d{3})(?!\d)',r'\1\2',text)
    normalized=re.sub(r'([一二两三四五六七八九])([一二两三四五六七八九])(百|千|万)',r'\1\3到\2\3',normalized)
    for m in AMOUNT.finditer(normalized):
        a,b=number(m['a']),number(m['b']) if m['b'] else None
        if a is None: continue
        if b is not None and a<100:
            unit=re.search(r'([kK百千万])(?:\d)?$',m['b'])
            if unit and not re.search(r'[kK百千万元]',m['a']):
                a *= {'百':100,'千':1000,'万':10000,'k':1000}[unit[1].lower()]
        pre=normalized[max(0,m.start()-24):m.start()]; post=normalized[m.end():m.end()+15]
        if re.match(r'米(?:离|距|到|远|近|路|外|内)',post):continue
        if post.startswith('米') and re.search(r'地铁|距离|相距|离.{0,6}$',pre):continue
        # Restrict to monetary slots; years, room counts, days, floors are not prices.
        if re.match(r'(?:年|月(?!租|预算|房租)|天|个|人|室|居|楼|平|号线)',post) and not re.match(r'月(?:租|预算|房租)',post): continue
        prefix_budget=bool(re.search(r'(?:预算|封顶|上限|最多|最高|可以加到|能加到|加到|提高到)(?:[是为在大概约就只有能给不超过最多上限到：: ]|(?:不含|不算|除去?)(?:水电(?:费)?|电费|水费)){0,10}$',pre))
        explicit=prefix_budget or (a>=100 and bool(re.match(r'(?:元|块|米)?\s*预算',post)))
        local_clause=re.split(r'[，,。；;！？!?]',pre)[-1]
        current_clause=re.split(r'有没有|想找|想租|要租|求租|想换|求推荐|预算',local_clause)[-1]
        excluded=not prefix_budget and (bool(re.search(r'(?:押金|水电|电费|水费|中介费|工资|收入|买房|首付|房东报价|房源报价).{0,8}$',local_clause)) or bool(re.search(r'(?:以前|之前|原来|曾经|去年|现在住|目前住).{0,8}$',current_clause)))
        monetary=bool(re.match(r'(?:元|块|米|[kK]|/月|每月|一个月|一月|月租)',post) or re.search(r'[百千万元kK]',m['a']+(m['b'] or '')) or (a>=100 and (rental_context or re.search(r'求租|找房|想找|整租|预算|想租|要租',text))))
        scoped=explicit or (monetary and bool(re.search(r'求租|想租|要租|找房|想找|整租|短租|长租|租金|房租|月租|以内|上限',local_clause+post)))
        # A bare amount under a known rental post is ambiguous, never confirmed low.
        if not scoped:
            if monetary and not excluded and ((a>=100 and a<3000 and rental_context) or re.fullmatch(r'\s*'+re.escape(m.group())+r'(?:元|块|米|/月)?[?？!！。 ]*',normalized)):
                evidence.append(dict(quote=m.group(),minimum=min(a,b) if b is not None else a,maximum=max(a,b) if b is not None else a,scope='ambiguous_amount',usable=False))
            continue
        if excluded: continue
        if not explicit and re.search(r'太贵|好贵|这么贵|这么便宜|好便宜|真的假的|真有|这(?:个|套)房',local_clause+post): continue
        lo,hi=sorted([a,b]) if b is not None else (a,a)
        tail=m['tail'] or ''
        if tail=='多': hi=(int(a/1000)+1)*1000-1 if a>=1000 else None
        if tail in ('以上','起'): hi=None
        if post.startswith('+'):hi=None
        if tail in ('左右','上下'): lo=None;hi=None
        scope='whole_home_monthly'; usable=True
        if re.match(r'(?:/(?:天|日|周|年)|每天|每日|每周|每年|一天|一周|一年)',post) or re.search(r'日租|每天|每日|每周|每年',pre[-8:]):
            scope='non_monthly_rate';usable=False
        elif re.search(r'每人|人均|一人',pre[-8:]):
            scope='per_person_monthly';usable=False
            persons=re.search(r'([两二三四五六七八九十\d]+)人',normalized)
            if persons and re.search(r'整租',normalized):
                count=number(persons[1]);lo=lo*count if lo is not None else None;hi=hi*count if hi is not None else None
                scope='whole_home_from_explicit_people';usable=True
        elif re.search(r'合租|单间|床位|次卧|主卧',text) and not re.search(r'不合租|不要合租|整租',text):
            scope='shared_room_monthly';usable=False
        evidence.append(dict(quote=m.group(),nominal_amount=a,minimum=lo,maximum=hi,scope=scope,usable=usable,explicit_budget=explicit))
    usable=[e for e in evidence if e['usable']]
    caps=[e['maximum'] for e in usable if e['maximum'] is not None]
    # Multiple incompatible current amounts are not resolved by picking the cheapest.
    if len(usable)>1:
        return dict(state='budget_conflict_unverified',evidence=evidence,monthly_minimum=None,monthly_maximum=None)
    if not usable: return dict(state='budget_unverified',evidence=evidence,monthly_minimum=None,monthly_maximum=None)
    e=usable[0];lo,hi=e['minimum'],e['maximum']
    state='below_3000' if hi is not None and hi<3000 else ('budget_3000_3999_unverified' if hi is not None and hi<4000 else ('budget_at_least_4000' if lo is not None and lo>=4000 else 'budget_unverified'))
    return dict(state=state,evidence=evidence,monthly_minimum=lo,monthly_maximum=hi)

def advertised_rent(row):
    metadata=(row.get('classification') or {}).get('original_metadata') or {}
    post=row.get('post_body') or metadata.get('post_body')
    if not post:
        post='\n'.join(str(row.get(key) or '') for key in ('post_title','post_text'))
    prices=[]
    for match in re.finditer(r'(?:月租|房租|租金|整租价)(?:\s|[：:￥¥]|只要|只需|仅需|才|低至|最低|仅){0,8}',post):
        if re.search(r'以前|之前|过去|去年|曾经',post[max(0,match.start()-8):match.start()]):
            continue
        amount=AMOUNT.match(post,match.end())
        if not amount:
            continue
        quote=post[match.start():amount.end()]
        parsed=budget('预算'+amount.group(),True)
        if parsed['evidence']:
            prices.append({'quote':quote,'budget':parsed})
    if row.get('platform') == 'douyin':
        # Caption unit prices remain source evidence, never the customer's budget.
        for match in re.finditer(r'(?:整租|转租|出租|一室(?:一厅)?|两室(?:一厅)?|一居(?:室)?|两居(?:室)?|套一|套二|单间|开间)(?P<gap>[^\d，,。；;]{0,8})', post):
            pre=post[max(0,match.start()-12):match.end()]
            if re.search(r'以前|之前|去年|曾经|工资|押金|水电|中介费|预算|首付', pre):continue
            amount=AMOUNT.match(post,match.end())
            if not amount:continue
            parsed=budget('预算'+amount.group(),True)
            if not any(e.get('nominal_amount',0)>=100 for e in parsed['evidence']):continue
            tail=post[amount.end():amount.end()+5]
            if re.match(r'平|㎡|平方|平米|米|人|室|厅|号|楼|层|年|月|天|分钟|公里',tail):continue
            if re.match(r'/(?:天|日|周|年)|每天|每日|每周|每年|一天|一周|一年',tail):continue
            quote=post[match.start():amount.end()]
            if not any(p['quote']==quote for p in prices):prices.append({'quote':quote,'budget':parsed,'scope':'advertised_rental_unit_caption'})
    return prices

# --- LISTING-AD-20261111: the commenter is advertising listings / acting as agent ---
REASON_LABELS={'listing_ad_or_agent':'房源广告/中介'}
_AD_DEMAND=r'求租|求房|求整租|求合租|求单间|求一[个套间]|想租|要租|我在找|在找房|正在找|找房子?中|蹲(?:一|个|房)|预算|有没有|有吗|有嘛|有么|有房吗|谁有|哪里有|帮忙找|求推荐|有合适的|合适的(?:可以)?私|想找|找个|找一个|[租找](?:个|一个|一套)?(?:房|套一|单间|整租|合租|一室|两室)[，,。 ！!]|租房[，,。 ！!]|\S{0,4}附近租房'
_AD_STRONG=[
 r'(?:还|请问|你好|您好|宝子|亲)?(?:还)?(?:需要|要|在)(?:找房|租房|房子)(?:吗|嘛|么|不|没)',
 r'还在找房(?:吗|嘛|么)',
 r'(?:各区|全区|全城|多区|各个区|全市|市区|主城区)(?:都)?有(?:房|房源|好房)',
 r'(?<![谁哪求])(?:有|大量|海量)(?:大量|很多|好多|海量|各种|优质|一手|真实|个人)?房源(?![吗嘛么呢？?的])',
 r'房源(?:多|充足|很多|丰富|齐全|多多)',
 r'手(?:上|里|头)有(?:房|很多|好多|大量)',
 r'我是(?:中介|房东|二房东|经纪人|房产|租房管家|管家)|本人(?:是)?(?:中介|房东|二房东|经纪人)',
 r'招租|(?:我|本人|房东|个人|急)(?:家)?(?:还)?(?:有)?(?:房子?|单间|一间|次卧|主卧|套一|套二)?(?:出租|转租)(?![吗嘛么呢啊呀？?的])|(?<![有找求])(?:房屋|房源|单间|整租|主卧|次卧)出租(?![吗嘛么呢？?的])',
 r'(?<![有找求想要收接谁个])转租(?![吗嘛么呢？?的])',
 r'有人(?:要|需要)(?:吗|嘛|不)|要不要[，,。！!？?]|需要(?:的话)?可以联系我',
 r'有没有(?:人)?(?:想|要|需要)(?:租|找)',
 r'(?<!说)不收(?:中介费|杂费|服务费)(?![的吗嘛])',
 r'(?:旁边|附近|这边|地段)[^，。,]{0,4}考虑(?:吗|嘛|不)',
 r'想租出去|要租出去|我挂\d|我这(?:里|边)[^，。,]{0,8}房源|需要了解一下吗',
 r'房东直租找我|直租找我|找我(?:租|看房|拿房)',
 r'新人中介|干中介的|我(?:是)?做中介|中介(?:小哥|小姐姐|小妹)(?:一枚)?|能接受中介吗|中介加我|对中介合作',
]
_AD_CONTACT=r'私信我|私我|滴滴我|欢迎(?:私信|咨询|来撩|滴滴|看房)|需要的?(?:朋友|宝子|姐妹|小伙伴|话)?(?:可以)?(?:私|滴|找我|联系)|有需要(?:的)?(?:可以)?(?:私|滴|找我|联系)|联系我|加我|看我主页|主页(?:有|看)|vx|VX|v我|V我|微信'
_AD_WEAK=r'无中介费|免中介费?|0中介|零中介|不收中介费|没有中介费|房东直租|个人直租|随时看房|实图实价|价格美丽|性价比超?高|欢迎'
def listing_ad(text):
    """Evidence string when the commenter offers listings / agency; None for customer demand."""
    t=text or ''
    demand=bool(re.search(_AD_DEMAND,t))
    for p in _AD_STRONG:
        m=re.search(p,t)
        if m:
            # A customer asking "有房源吗/谁有房源" never matches; a pure customer request with
            # only an offer-like fragment (e.g. 我在找房，房东直租找我也行) keeps demand.
            if re.search(r'转租|出租',m.group()) and not re.search(r'我|本人|急|家',m.group()) and re.search(r'(?:有没有|有|找|求|想|要)\S{0,2}$',t[max(0,m.start()-5):m.start()]):continue
            if demand and not re.search(r'需要|还在找房|各区|全区|全城|大量|海量|房源(?:多|充足|丰富)|我是|本人|招租|中介|有没有|不收|考虑|租出去|我挂|个人转租|我转租|急转租|[卧间屋源]出租|有人|要不要|联系我|我这',m.group()):continue
            return m.group()
    contact=re.search(_AD_CONTACT,t);weak=re.findall(_AD_WEAK,t)
    if contact and weak and not demand:return contact.group()+'|'+weak[0]
    if len(set(weak))>=2 and not demand:return '|'.join(dict.fromkeys(weak))
    return None
# --- end LISTING-AD-20261111 ---

# --- LISTING-AD-R2-20261111: agent / sublet-supplier / advice phrasing missed in round 1 ---
REASON_LABELS['advice_not_self_demand']='非本人找房需求（劝告/科普/房东经验）'
_R2_SELF=r'(?:只|能不能|我想|我要)租|我(?:想|要|在|正在|准备|也想|还在)[^，。,？?]{0,4}?(?:租|找)(?!房的)|我(?:想|要)找|求租|求房|求整租|求合租|求单间|求推荐|求房东|蹲房|预算|帮我找|我们(?:想|要)租'
_R2_AGENT=[
 r'(?<![找个])正规中介|入职中介|新人入职中介|新人中介|(?:我|本人)就是中介|(?:我|本人)(?:是|在)?(?:做|干)中介|中介公司的|我们(?:是|这边是)?中介(?!费)|(?:我们|我)(?:这边|这里)?可以提供房源|房源[^，。,]{0,6}(?:最优|最低价|最便宜)',
 r'(?:个人房|个人|房东)直租[^，。,？?]{0,8}(?:找我|私我|联系我)',
 r'(?<![有的])(?:想|要|需要)?(?:租房|找房)的?(?:都|就)?(?:可以)?(?:直接)?(?:找我|私我|联系我|私信我|滴我)',
 r'可以让我帮(?:忙|你)?找|我(?:可以)?帮(?:你|你们|大家|宝子)们?(?:找|看房)',
 r'(?:低价|半价|便宜|折价|原价|急|亏本)转租|转租出去|(?:我|我们)(?:这边|这里)?(?:需要|打算|想|要|准备)转租(?![吗嘛么呢？?一个间套的])|我这(?:里|边)有(?:转租|房(?!吗)|单间|次卧|主卧|空房)',
 r'有人(?:要|需要|想)(?:租|租房)(?:的)?(?:吗|嘛|么|没|不)|有人租的没|没有?人(?:要|需要|想)租',
 r'(?<![哪谁找求没里儿])有房子?出租(?![吗嘛么呢？?的没不])',
 r'(?:租房|房源)[^，。,]{0,6}需要(?:的)?(?:可以)?私(?:我|信)',
 r'我是[^，。,]{0,4}中介(?!费)|(?<![找个去])做中介|我认识的中介|需要中介服务|有需[求要]的?(?:都)?(?:可以)?(?:来|直接)?(?:找我|私我|联系我)',
 r'(?<![哪谁找求没里儿])有房子?外?可以出租|(?<![哪谁找求没里儿])有房外出租|(?:房东|我)自己出租|看看?我(?:的)?主页|直连房东|帮你少走弯路|有要的(?:吗|嘛|没)',
 r'来我这(?:里|边)?(?:问|看)|我这(?:里|边)?都(?:是)?实图实价|需要推荐吗|(?<!有没有)中介[^？?吗]{0,14}可以推荐(?:[。！!，,]|$)',
]
_R2_ADVICE=r'(?<![给求有些点下家])建议(?!我|一下|吗|你们)(?![^，。]{0,8}(?:哪|吗|呢|？|\?))|(?:不租|租不起|不住)[^。]{0,12}帮你(?:养|照顾)|帮你(?:养|照顾)[^。]{0,12}(?:不租|租不起|不住)|(?:房子[^。，？?]{0,8}|半个月|当天就?)(?:很容易就)?(?:租出去了|就?出租了)(?![吗嘛么没呢？?])|^(?:马上|快|现在)(?:就)?(?:要)?(?:到)?淡季|(?:淡季|旺季)[^。]{0,10}(?:便宜|好找|贵|难找)|你(?:现在|这时候|这个时候|最好|应该|可以先|得)(?:去)?(?:找房|租房|找房子)|建议(?:你(?!们)|楼主|博主|大家|宝子)'
_listing_ad_r1=listing_ad
def listing_ad(text):
    t=text or ''
    for p in _R2_AGENT:
        m=re.search(p,t)
        if m:
            if re.search(r'不要中介|有中介吗|中介太坑|中介坑|讨厌中介|不找中介',t) and '我' not in m.group():continue
            return m.group()
    m=re.search(r'有人租(?:吗|嘛|么|不)',t)
    if m and re.search(r'\d{3,}|[室厅]|独卫|卫生间|包水|押|无中介费|减|租到|只能租',t):return m.group()
    return _listing_ad_r1(t)
def advice_not_self(text):
    t=text or ''
    m=re.search(_R2_ADVICE,t)
    if m and not re.search(_R2_SELF,t):return m.group()
    return None
# --- end LISTING-AD-R2-20261111 ---

def screen(row, now=None):
    c=row.get('classification') or {};meta=c.get('original_metadata') or {};source_class=row.get('source_classification') or {}
    t=row.get('comment_text') or row.get('text') or c.get('comment_text') or ''
    role=row.get('role') or c.get('role') or c.get('original_role') or 'unknown'
    original_intent=row.get('interest_at_comment') or row.get('interest') or c.get('interest') or c.get('original_intent') or row.get('original_interest')
    b=budget(t,bool(role=='demand' or row.get('post_body') or meta.get('post_body') or c.get('topics') or row.get('pools')))
    source_rents=advertised_rent(row)
    reasons=[];holds=[]
    reopening=bool(re.search(r'但|还想|还要|还在找|想换|要换|重新找|再找|有推荐|求租|求房',t))
    ended=bool(re.search(r'已经租到|已租到|租好了|租到了|找到房了|不找了|不租了|已签约|签好合同|决定租.{0,10}了',t)) and not reopening
    speaker_supply=bool(re.search(r'(?:^|[，,。；;])\s*(?:我有房|本人出租|我是房东|我这(?:里|边)有房|(?:本人)?(?:房东直租|房东出租|房源出租|招室友|找室友|转租))',t))
    supply=role in ('supply','discussion','unrelated') or (speaker_supply and not re.search(r'求租|想租|要租|自己找房|还在找房',t))
    ad_evidence=listing_ad(t)
    if ad_evidence:supply=True
    advice_evidence=None if ad_evidence else advice_not_self(t)
    if advice_evidence:supply=True
    explicit_demand=bool(re.search(r'求租|想租|要租|正在找房|找房|找整租|准备租|预算',t))
    demand=role=='demand' or (role=='unknown' and explicit_demand and not supply)
    if ad_evidence: reasons.append('listing_ad_or_agent')
    if advice_evidence: reasons.append('advice_not_self_demand')
    if supply: reasons.append('not_supported_customer_demand')
    if ended or (row.get('demand_state') or source_class.get('demand_state') or c.get('demand_state')) in ('ended','completed','inactive'):reasons.append('demand_ended')
    if (row.get('demand_state') or source_class.get('demand_state') or c.get('demand_state')) in ('historical','future'):holds.append('demand_time_state_requires_confirmation')
    if not t:holds.append('original_comment_text_missing')
    flags=meta.get('context_flags') or {}
    conflict=flags.get('source_conflict') if isinstance(flags,dict) else 'source_conflict' in flags
    if row.get('source_error') or row.get('source_version_conflict') or meta.get('source_version_conflict') or conflict:reasons.append('source_error_or_conflict')
    boundary=row.get('contact_boundaries') or c.get('contact_boundaries') or meta.get('contact_boundaries')
    if row.get('platform')=='douyin':
        identity_limited=bool(row.get('effective_contact_policy')=='identity_restricted' or re.search(r'中介勿扰|不要中介(?!费)|不想要中介|只找房东|个人房东|只要个人',t))
        private_only=bool(re.search(r'不要私信|别私信',t))
        broad_text=re.sub(r'(?:中介|二房东|经纪人|房产中介|没有)(?:请)?勿扰','',t)
        if re.search(r'勿扰|不要联系|别联系|不住公寓|不租公寓',broad_text) or row.get('brand_recommendation_allowed') is False:
            reasons.append('contact_or_brand_restricted')
        if row.get('effective_contact_policy') in ('restricted','do_not_contact'):
            reasons.append('contact_identity_restricted')
        if identity_limited:holds.append('contact_identity_requires_confirmation')
        if private_only:holds.append('public_reply_scope_requires_confirmation')
        if boundary and boundary not in ('allow','unknown') and not identity_limited and not private_only:
            holds.append('contact_scope_requires_confirmation')
    else:
        if re.search(r'勿扰|不要私信|别私信|不要联系|别联系|不要中介(?!费)|不住公寓|不租公寓',t) or row.get('brand_recommendation_allowed') is False:reasons.append('contact_or_brand_restricted')
        if boundary and boundary not in ('allow','unknown'):reasons.append('contact_boundary')
        if row.get('effective_contact_policy') in ('identity_restricted','restricted','do_not_contact'):reasons.append('contact_identity_restricted')
    if row.get('region_conflict') or row.get('geography_status') in ('mismatch','out_of_coverage') or row.get('store_match_status')=='mismatch':reasons.append('known_region_conflict')
    if b['state']=='below_3000':reasons.append('whole_home_monthly_budget_below_3000')
    if b['state']=='budget_3000_3999_unverified':holds.append('budget_3000_3999_requires_confirmation')
    if b['state']=='budget_conflict_unverified':holds.append('conflicting_budget_requires_confirmation')
    explicit_compatible_budget=(b['state']=='budget_at_least_4000' and
                               any(e.get('explicit_budget') and e['usable'] for e in b['evidence']))
    if source_rents and not explicit_compatible_budget:
        if all(price['budget']['state']=='below_3000' for price in source_rents):
            reasons.append('source_post_advertised_rent_below_3000')
        elif any(any(e.get('nominal_amount',float('inf'))<3000 for e in price['budget']['evidence']) for price in source_rents):
            holds.append('source_post_low_rent_range_requires_confirmation')
    if any(e.get('nominal_amount',float('inf'))<3000 and (e['maximum'] is None or not e['usable']) for e in b['evidence']):holds.append('low_amount_scope_or_ceiling_unverified')
    if any(e['scope']=='ambiguous_amount' for e in b['evidence']):holds.append('standalone_rental_amount_requires_confirmation')
    if not demand:holds.append('demand_role_unverified')
    if row.get('needs_currentness_review'):holds.append('currentness_review_required')
    # Location and current-need confirmations remain evidence, not mandatory flags.
    location_verified=bool(row.get('target_store_match_verified') or row.get('store_match_verified') or row.get('gubei_match_verified'))
    current_verified=bool(row.get('current_need_confirmed') or row.get('current_need_verified') or c.get('current_need_confirmed'))
    if not location_verified:holds.append('location_unverified')
    if not current_verified:holds.append('current_need_unverified')
    if b['state'] in ('budget_unverified','budget_conflict_unverified'):holds.append('budget_unverified')
    age_band=recency.key(row,now)[0]
    if row.get('platform')=='douyin' and not recency.within_douyin_active_window(row,now):
        reasons.append('outside_douyin_active_30_day_window')
    if row.get('platform')=='xiaohongshu' and retention30.enabled('xiaohongshu') and not recency.within_douyin_active_window(row,now):
        reasons.append('outside_active_30_day_window')
    if age_band>=5:holds.append('comment_age_old_or_unknown_deprioritized')
    hard_hold=any(x in holds for x in ('budget_3000_3999_requires_confirmation','conflicting_budget_requires_confirmation','standalone_rental_amount_requires_confirmation','low_amount_scope_or_ceiling_unverified','demand_role_unverified','demand_time_state_requires_confirmation','currentness_review_required','original_comment_text_missing','source_post_low_rent_range_requires_confirmation','contact_identity_requires_confirmation','public_reply_scope_requires_confirmation','contact_scope_requires_confirmation'))
    eligible=not reasons and not hard_hold
    clear_request=bool(re.search(r'求租|求房|想租|要租|正在找房|找房|找整租|准备租|预算|想找.{0,8}(?:房|一居|两居)|(?:租|找)(?:一个|个|一套).{0,8}(?:房|公寓)|有.{0,8}(?:房子|房源|一室|两室).{0,5}(?:吗|嘛|么)',t))
    low_budget=any(reason in reasons for reason in ('whole_home_monthly_budget_below_3000','source_post_advertised_rent_below_3000'))
    if low_budget:
        intent='low'
    elif supply:
        intent='non_customer'
    elif ended:
        intent='ended'
    elif reasons or hard_hold:
        intent='uncertain'
    elif original_intent in ('uncertain','unknown'):
        intent='uncertain'
    elif demand and clear_request:
        intent='super_high' if explicit_compatible_budget and age_band<=1 else 'high'
    elif demand:
        intent='medium'
    else:
        intent='uncertain'
    eligible=eligible and intent in ('medium','high','super_high')
    priority=eligible and intent in ('high','super_high') and age_band<5
    labels={'super_high':'超高意向','high':'高意向','medium':'中意向','low':'低意向',
            'uncertain':'待核意向','non_customer':'非求租客户','ended':'需求已结束'}
    fit=intent if intent in ('high','super_high') else ('very_low' if reasons else 'unverified')
    return dict(version=VERSION,commercial_fit=fit,lead_intent=intent,lead_intent_label=labels[intent],
                eligible_candidate=eligible,eligible_priority=priority,
                candidate_state='excluded' if reasons else ('pending_verification' if hard_hold or not eligible else ('priority' if priority else 'generic_inquiry_non_priority')),
                exclusion_reasons=reasons,exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],listing_ad_evidence=ad_evidence,advice_evidence=advice_evidence,verification_required=list(dict.fromkeys(holds)),budget=b,
                source_advertised_rents=source_rents,demand_role=role,demand_supported=demand,
                location_verified=location_verified,current_need_verified=current_verified,
                original_intent=original_intent,original_intent_preserved=True,
                customer_budget_from_comment_only=True,source_post_price_is_separate_filter=True,
                ip_is_not_exact_target_store=True,send_authorized=False)

# --- ROUND3-20261111: roommate supply, rhetorical/complaint, bulk & weak-demand holds ---
REASON_LABELS['advice_not_self_demand']='非本人找房需求（劝告/科普/反问他人/房东经验）'
REASON_LABELS['own_home_seeking_roommate']='供给方：自有房找室友/分租出去'
REASON_LABELS['bulk_enterprise_manual_followup']='批量/企业需求-人工跟进'
REASON_LABELS['weak_demand_no_auto_reply']='需求弱-不自动回'
_R3_ADVICE=r'劝你|奉劝|一个个说|下次自己租|看你要不要|(?:还|就|先|多)?去看看中介|^(?:你|你们)?(?:想|要)(?:租|找)(?:哪|什么)[^，。,]{0,4}[？?]?(?:\[[^\]]*\])*$'
_R3_OWN_HOME=r'我(?:自己)?租的房子|房子是我(?:自己)?(?:租|买)的|我(?:自己)?(?:有|租了|买了)(?:一套|套|个|一个)?(?:房子|两居|三居|两室|三室|大房子)|我住的(?:房子|这套)|我家(?:有|还有)(?:一间|空)|我(?:这边|这里)?(?:有|租了)(?:个|一个|一套)?(?:两室|三室|两居|三居|两房|三房)|空出(?:一间|个)?(?:房|次卧|主卧)|(?:次卧|主卧|一间房?)(?:空着|空出来)'
_R3_ROOMMATE=r'找(?:个|一个|位|一位)?[^，。,]{0,6}(?:合租|室友|舍友)|招(?:个|一个)?(?:室友|合租|舍友)|(?:合租|室友)[^，。,]{0,4}(?:私我|联系我|滴我)'
_R3_BULK=r'(?:要|需要|租|找|收)\s*(?:\d{2,}|[五六七八九]|[一二三四五六七八九]?十[一二三四五六七八九]?|几十|上百)\s*(?:间|套|个房间)|(?:员工宿舍|企业|公司宿舍|公司包租|整栋|批量)[^。]{0,12}(?:\d{2,}间|\d{2,}个人|几十|上百|多间|多套|整栋)|批量(?:租|收)房'
_R3_WEAK=r'(?:在|从)?哪(?:里|儿)(?:遇到|找到|找的|租到|租的)|怎么找到的|是中介吗[^。]{0,6}(?:还是|app|APP)|还是(?:app|APP|软件|平台)'
_R3_STRONG_DEMAND=r'推荐(?:我|一下)|我也想|求租|求房|想租|要租|我要找|我想找|正在找|在找房|预算|有没有[^，。]{0,10}(?:房|单间|一居|两居|套)|找房|帮我找|搬家|到期'
_screen_r2=screen
def r3_flags(t):
    t=t or ''
    own=bool(re.search(_R3_OWN_HOME,t)) and bool(re.search(_R3_ROOMMATE,t))
    adv=None
    m=re.search(_R3_ADVICE,t)
    if m and not re.search(_R2_SELF,t):adv=m.group()
    bulk=re.search(_R3_BULK,t)
    weak=re.search(_R3_WEAK,t) if not re.search(_R3_STRONG_DEMAND,t) else None
    return dict(own_home_roommate=own,advice=adv,bulk=bulk.group() if bulk else None,weak=weak.group() if weak else None)
def screen(row, now=None):
    out=_screen_r2(row,now)
    c=row.get('classification') or {}
    t=row.get('comment_text') or row.get('text') or c.get('comment_text') or ''
    f=r3_flags(t);reasons=list(out['exclusion_reasons']);holds=list(out['verification_required'])
    if f['own_home_roommate'] and 'own_home_seeking_roommate' not in reasons:reasons.append('own_home_seeking_roommate')
    if f['advice'] and not out.get('advice_evidence') and not out.get('listing_ad_evidence'):
        reasons.append('advice_not_self_demand');out['advice_evidence']=f['advice']
    manual=[]
    if f['bulk'] and not reasons:holds.append('bulk_enterprise_manual_followup');manual.append(REASON_LABELS['bulk_enterprise_manual_followup'])
    if f['weak'] and not reasons:holds.append('weak_demand_no_auto_reply');manual.append(REASON_LABELS['weak_demand_no_auto_reply'])
    changed=reasons!=out['exclusion_reasons'] or holds!=out['verification_required']
    if changed:
        if reasons and 'not_supported_customer_demand' not in reasons and any(x in reasons for x in ('own_home_seeking_roommate','advice_not_self_demand')):reasons.append('not_supported_customer_demand')
        out.update(exclusion_reasons=reasons,exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],verification_required=list(dict.fromkeys(holds)),
                   eligible_candidate=False,eligible_priority=False,
                   candidate_state='excluded' if reasons else 'pending_verification')
        if reasons:out.update(lead_intent='non_customer',lead_intent_label='非求租客户',commercial_fit='very_low')
        else:out.update(lead_intent='uncertain',lead_intent_label='待核意向',commercial_fit='unverified')
    out['manual_followup']=manual or None
    out['r3_evidence']={k:v for k,v in f.items() if v} or None
    return out
# --- end ROUND3-20261111 ---

def apply(row):
    out=dict(row);fit=screen(row);out['commercial_fit']=fit
    out['commercial_pending_eligible']=fit['eligible_candidate']
    out['commercial_priority']=fit['eligible_priority']
    if not fit['eligible_candidate']:
        prior=dict(row.get('reply') or {})
        if prior.get('draft_text'):out['prior_draft_before_business_fit']=prior
        out['reply']=dict(prior,draft_text=None,status='commercial_fit_hold',business_fit_reasons=fit['exclusion_reasons']+fit['verification_required'],send_authorized=False)
        out['pending_candidate']=False
    return out


# --- ROUND4-20261111: reverse-Q, solicit-looking, dating, chat/advice, extra supply ---
REASON_LABELS['seeking_buddy_or_dating']='交友/找搭子非租房'
REASON_LABELS['solicit_people_looking']='供给方：询问是否有人找房'
_R4_SELF=r'推荐我|我也想|我也要找|求租|求房|求整租|求合租|求单间|求推荐|我想租|我要租|我想找|我要找|正在找|在找房|帮我找|租哪里合适|有没有(?:单间|房子|房源)|有人转租|附近有房子租|我想找室友|预算\d|预算[一二三四五六七八九十百千万]'
_R4_REVERSE=[
 r'(?:你|你们|看你)(?:现在|还)?(?:要|想要|需要|打算|准备|想租|要租)(?:哪里|哪儿|哪边|哪块|哪个)(?:位置|地方|区域|区|地段|房子?)?',
 r'(?:你|你们|看你)(?:现在|还)?(?:要|想要|需要|打算|准备)(?:什么|什么样的)(?:位置|地方|区域|区|地段)',
 r'(?:你|你们)(?:现在|还|也)?(?:想|要|准备|打算)?在(?:哪个|哪边|哪块|什么)(?:区|位置|地方|区域|地段)?找(?!的)',
 r'(?:你|你们)(?:打算|准备)租哪里',
 r'准备租哪里',
 r'想租哪里自己去找',
 r'^(?:想要|需要)哪里的(?:房子?)?(?:\[[^\]]*\])?[吗嘛么呀啊呢？?！!\s]*$',
]
_R4_REVERSE_FORCE=r'你要哪|你想要哪|你需要哪|你想租哪|你要租哪|看你需要哪|你要什么位置|你要什么地方|你要什么区域|你要什么地段|你在哪个区找|你在哪边找|你在哪块找|你打算租哪|想租哪里自己去找|准备租哪里' 
_R4_SOLICIT=r'(?:有人|有没有人)(?:在)?找房子?(?:吗|嘛|么|没|不|？|\?)'
_R4_DATING_ALWAYS=r'暖被窝|床搭子'
_R4_DATING=r'(?:找(?:个|一个)?(?:\d+后的)?(?:女|男)搭子)|(?:女|男)搭子|搭子你在哪里'
_R4_CHAT=r'赶紧退吧|赶紧退[吧啊呀]?|稳定的租客也不容易|这个价格估计有点悬|(?<![没不])有点悬|住一起不吵架吗|租房吃饭还有其他开销|适合本地人.{0,24}开销'
_R4_SUPPLY=[
 r'自建房.{0,24}有需要租|自建房.{0,16}(?:出租|装修完)',
 r'(?<![我还])有需要租房的吗|(?<![我还])有需要租的吗',
 r'我这(?:里|边)?有[，,](?:在)?.{0,24}预算多少',
 r'(?:我.{0,16})?(?:租了|租的)(?:一个|套|个)?(?:两居|两室|三居|三室).{0,20}分租',
]
_screen_r3=screen
def r4_flags(t):
    t=t or ''
    self=bool(re.search(_R4_SELF,t))
    rev=None
    for p in _R4_REVERSE:
        m=re.search(p,t)
        if m:
            if re.search(r'租哪里合适|(?:狗狗|猫猫|带宠物)租哪里|哪里有房子租',t) and not re.search(_R4_REVERSE_FORCE,t):
                continue
            if self and not re.search(_R4_REVERSE_FORCE,m.group()):
                continue
            rev=m.group(); break
    sol=None
    m=re.search(_R4_SOLICIT,t)
    if m and not re.search(r'一起找|合租|转租',t[max(0,m.start()-4):m.end()+4]):
        sol=m.group()
    dat=None
    m=re.search(_R4_DATING_ALWAYS,t)
    if m:
        dat=m.group()
    else:
        m=re.search(_R4_DATING,t)
        if m and not re.search(r'合租|室友',t):
            dat=m.group()
    chat=None
    m=re.search(_R4_CHAT,t)
    if m and not self:
        chat=m.group()
    sup=None
    for p in _R4_SUPPLY:
        m=re.search(p,t)
        if m:
            if re.search(r'我这(?:里|边)?有预算\d',t) and '预算多少' not in m.group():
                continue
            sup=m.group(); break
    return dict(reverse_q=rev,solicit_looking=sol,dating=dat,chat_advice=chat,supply_offer=sup)
def screen(row, now=None):
    out=_screen_r3(row,now)
    c=row.get('classification') or {}
    t=row.get('comment_text') or row.get('text') or c.get('comment_text') or ''
    f=r4_flags(t);reasons=list(out['exclusion_reasons'])
    if f['reverse_q'] and 'advice_not_self_demand' not in reasons:
        reasons.append('advice_not_self_demand')
        if not out.get('advice_evidence'):
            out['advice_evidence']=f['reverse_q']
    if f['solicit_looking'] and 'solicit_people_looking' not in reasons:
        reasons.append('solicit_people_looking')
        if not out.get('listing_ad_evidence'):
            out['listing_ad_evidence']=f['solicit_looking']
    if f['dating'] and 'seeking_buddy_or_dating' not in reasons:
        reasons.append('seeking_buddy_or_dating')
    if f['chat_advice'] and 'advice_not_self_demand' not in reasons:
        reasons.append('advice_not_self_demand')
        if not out.get('advice_evidence'):
            out['advice_evidence']=f['chat_advice']
    if f['supply_offer']:
        if re.search(r'分租|租了(?:一个|套|个)?(?:两居|两室|三居|三室)',f['supply_offer']) and 'own_home_seeking_roommate' not in reasons:
            reasons.append('own_home_seeking_roommate')
        elif 'listing_ad_or_agent' not in reasons and 'own_home_seeking_roommate' not in reasons:
            reasons.append('listing_ad_or_agent')
            if not out.get('listing_ad_evidence'):
                out['listing_ad_evidence']=f['supply_offer']
    changed=reasons!=out['exclusion_reasons']
    if changed:
        if reasons and 'not_supported_customer_demand' not in reasons and any(x in reasons for x in ('advice_not_self_demand','solicit_people_looking','seeking_buddy_or_dating','listing_ad_or_agent','own_home_seeking_roommate')):
            reasons.append('not_supported_customer_demand')
        out.update(exclusion_reasons=reasons,exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],
                   eligible_candidate=False,eligible_priority=False,
                   candidate_state='excluded')
        out.update(lead_intent='non_customer',lead_intent_label='非求租客户',commercial_fit='very_low')
    out['r4_evidence']={k:v for k,v in f.items() if v} or None
    return out
# --- end ROUND4-20261111 ---


# --- ROUND5-20261112: video-level rent below brand floor gates comments without own budget ---
# Floor follows the current comment-budget hard gate: whole-home monthly below 3000 is out.
# Source: rules/预算时效交叉筛选纠正.md and rules/意向分级与预算口径-20261105.md
# and business_fit.budget()/screen(); exact per-store starting prices are documented as unconfirmed.
VIDEO_RENT_FLOOR=3000
REASON_LABELS['low_price_video_budget_mismatch']='低价视频-预算不符'
_R5_PREFIX=r'(?:月租|房租|租金|整租价|租了|租的是|现在租|只要|仅需|低至|现价|定价)'
_R5_UNIT=r'(?:开间|单间|一室(?:一厅)?|两室(?:一厅)?|一居(?:室)?|两居(?:室)?|套一|套二|整租|次卧|主卧|一室户|小公寓|单身公寓|精品公寓)'
# ROUND6-20261112: also parse 1200 小公寓 / 单身公寓 / 精品公寓 as listed whole-home rent (known leak).
_R5_MONTH=r'(?:/月|一个月|每月|元/月|元一个月|块/月|块一个月)'
_R5_SKIP_PRE=re.compile(r'(?:押金|水电|电费|水费|网费|物业(?:费)?|停车|车位|中介费|首付|工资|以前|之前|原来|曾经|去年|当年|过去).{0,8}$')
_R5_SKIP_POST=re.compile(r'(?:米|平|㎡|平方|平米|层|号线|号|年|天|分钟|公里|度)')
_R5_PER=re.compile(r'每人|人均|一人|床位|一个床')
def _r5_post(row):
    c=row.get('classification') or {}; meta=c.get('original_metadata') or {}
    parts=[]
    for key in ('post_body','post_title','post_text','video_title','video_desc','caption','aweme_desc','desc','hashtags','video_tags','tags'):
        val=row.get(key) or meta.get(key)
        if val:
            if isinstance(val,(list,tuple)):
                parts.append(' '.join(str(x) for x in val if x))
            else:
                parts.append(str(val))
    return '\n'.join(parts)
def _r5_amount_from_match(group, pre=''):
    raw=(group or '').strip()
    if not raw:
        return None
    # Bare 十/百/千/万 are not prices (几百整租, 近千/月). 八百/一千 remain valid.
    if re.fullmatch(r'[十百千万]', raw):
        return None
    if pre and re.search(r'(?:好几|大约|差不多|[几数近约])$', pre):
        return None
    parsed=number(raw)
    if parsed is None:
        return None
    return parsed
def video_listed_rent(row):
    """Parse clearly stated whole-home monthly rents from the video's own text/tags."""
    post=_r5_post(row)
    if not post:
        return dict(state='unverified',floor=VIDEO_RENT_FLOOR,prices=[],quote=None,borderline=None)
    found=[]
    # prefix + amount, e.g. 月租850 / 租了850 / 租金1200/月
    for m in re.finditer(_R5_PREFIX+r'\s*('+N+r')\s*('+_R5_MONTH+r'|元|块)?', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R5_SKIP_PRE.search(pre):
            continue
        amt=_r5_amount_from_match(m.group(1), pre)
        if amt is None or amt<100 or amt>20000:
            continue
        tail=post[m.end():m.end()+6]
        if _R5_SKIP_POST.match(tail):
            continue
        kind='per_person' if _R5_PER.search(pre) or _R5_PER.search(tail) else 'whole_home'
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    # amount + monthly suffix, e.g. 1200/月  800/月  850元一个月
    for m in re.finditer(r'('+N+r')\s*('+_R5_MONTH+r')', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R5_SKIP_PRE.search(pre):
            continue
        if _R5_PER.search(pre):
            kind='per_person'
        else:
            kind='whole_home'
        amt=_r5_amount_from_match(m.group(1), pre)
        if amt is None or amt<100 or amt>20000:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    # amount immediately before or after a unit type: 850 开间 / 开间850 / 一室一厅1350
    for m in re.finditer(r'('+N+r')\s*(?:元|块)?\s*('+_R5_UNIT+r')', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R5_SKIP_PRE.search(pre) or _R5_SKIP_POST.match(tail):
            continue
        amt=_r5_amount_from_match(m.group(1), pre)
        if amt is None or amt<100 or amt>20000:
            continue
        kind='per_person' if _R5_PER.search(pre) or '床位' in m.group(2) else 'whole_home'
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    for m in re.finditer(r'('+_R5_UNIT+r')\s*(?:只要|仅需|低至|仅|才)?\s*('+N+r')(?!\s*(?:米|平|㎡|层|号|年|天))', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R5_SKIP_PRE.search(pre):
            continue
        amt=_r5_amount_from_match(m.group(2), pre)
        if amt is None or amt<100 or amt>20000:
            continue
        kind='per_person' if _R5_PER.search(pre) or '床位' in m.group(1) else 'whole_home'
        found.append(dict(quote=m.group().strip(),amount=amt,kind=kind))
    # de-dup similar quotes
    uniq=[]
    seen=set()
    for item in found:
        key=(round(item['amount'],2), item['kind'])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(item)
    whole=[x for x in uniq if x['kind']=='whole_home']
    other=[x for x in uniq if x['kind']!='whole_home']
    borderline=None
    if not whole:
        if other:
            borderline='per_bed_or_per_person'
        return dict(state='unverified',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=None,borderline=borderline)
    lows=[x for x in whole if x['amount']<VIDEO_RENT_FLOOR]
    highs=[x for x in whole if x['amount']>=VIDEO_RENT_FLOOR]
    if lows and highs:
        return dict(state='mixed',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=lows[0]['quote']+'|'+highs[0]['quote'],borderline='mixed_prices')
    if lows and not highs:
        return dict(state='below_floor',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=lows[0]['quote'],borderline=None)
    return dict(state='at_or_above',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=highs[0]['quote'] if highs else None,borderline=None)

def _r5_own_budget_at_or_above_floor(fit):
    b=fit.get('budget') or {}
    if b.get('state') in ('budget_3000_3999_unverified','budget_at_least_4000'):
        return True
    for e in b.get('evidence') or []:
        if not (e.get('usable') or e.get('explicit_budget')):
            continue
        val=e.get('minimum') if e.get('minimum') is not None else e.get('nominal_amount')
        if val is not None and val>=VIDEO_RENT_FLOOR:
            return True
    return False

_screen_r4=screen
def screen(row, now=None):
    out=_screen_r4(row, now)
    info=video_listed_rent(row)
    out['video_listed_rent']=info
    if info.get('state')!='below_floor':
        return out
    if _r5_own_budget_at_or_above_floor(out):
        return out
    reasons=list(out['exclusion_reasons'])
    if 'low_price_video_budget_mismatch' not in reasons:
        reasons.append('low_price_video_budget_mismatch')
    out.update(exclusion_reasons=reasons,
               exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],
               eligible_candidate=False,eligible_priority=False,
               candidate_state='excluded',
               lead_intent='low',lead_intent_label='低意向',commercial_fit='very_low',
               video_gate_quote=info.get('quote'))
    return out
# --- end ROUND5-20261112 ---

# --- ROUND7-20261114: more low-price caption forms; all comments under cheap videos are out ---
# Daily/weekly listed rates convert to a monthly equivalent for the 3000 floor.
# Missed monthly forms: 月付 / 直租1450 / AB套1800 / 1200公寓 / 2300租到的 / 1000块能租.
# Own-budget exception removed: a comment under a below-floor video is excluded even if it writes 4500.
_R7_SKIP_PRE=re.compile(r'(?:押金|水电|电费|水费|网费|物业(?:费)?|停车|车位|中介费|首付|工资|月薪|收入|宽带|以前|之前|原来|曾经|去年|当年|过去|一年|每年).{0,8}$')
_R7_SKIP_POST=re.compile(r'(?:米|平|㎡|平方|平米|层|号线|号|年|分钟|公里|度|倍|M|m)')
def _r7_amt(raw, pre='', lo=10, hi=20000):
    amt=_r5_amount_from_match(raw, pre)
    if amt is None or amt<lo or amt>hi:
        return None
    return amt
def _r7_extra(post):
    found=[]
    # 一天只要二十块钱 / 每天20元 / 日租20 / 一晚只需30
    for m in re.finditer(r'(?:一天|每日|每天|一晚|每晚|一夜|日租)(?:[^。\n]{0,8}?(?:只要|仅需|低至|才|仅))?\s*('+N+r')\s*(?:元|块钱|块)?', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R7_SKIP_PRE.search(pre) or _R7_SKIP_POST.match(tail):
            continue
        amt=_r7_amt(m.group(1), pre, 10, 1000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt*30,raw=amt,period='day',kind='whole_home'))
    # 20元/天  房租20元/日
    for m in re.finditer(r'('+N+r')\s*(?:元|块钱|块)?\s*/\s*(?:天|日|晚)', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R7_SKIP_PRE.search(pre):
            continue
        amt=_r7_amt(m.group(1), pre, 10, 1000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt*30,raw=amt,period='day',kind='whole_home'))
    # 100元/周
    for m in re.finditer(r'('+N+r')\s*(?:元|块钱|块)?\s*/\s*周', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R7_SKIP_PRE.search(pre):
            continue
        amt=_r7_amt(m.group(1), pre, 10, 5000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt*4,raw=amt,period='week',kind='whole_home'))
    # 1450月付
    for m in re.finditer(r'('+N+r')\s*月付', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R7_SKIP_PRE.search(pre) or _R7_SKIP_POST.match(tail):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    # 公寓直租1450 / 直租1450
    for m in re.finditer(r'(?:公寓)?直租\s*('+N+r')', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R7_SKIP_PRE.search(pre) or _R7_SKIP_POST.match(tail):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    # 2300租到的小家
    for m in re.finditer(r'('+N+r')\s*(?:元|块)?\s*就?租到', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R7_SKIP_PRE.search(pre):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    # 租的1300（避免“刚租好”）
    for m in re.finditer(r'(?<![刚])租的\s*('+N+r')', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R7_SKIP_PRE.search(pre) or _R7_SKIP_POST.match(tail):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    # AB套1800 / 套1800
    for m in re.finditer(r'套\s*('+N+r')(?!\s*(?:米|平|㎡|层|号))', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R7_SKIP_PRE.search(pre) or _R7_SKIP_POST.match(tail):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    # 1200公寓 / 1200 小房子 / 1200小家
    for m in re.finditer(r'('+N+r')\s*(?:元|块)?\s*(?:公寓|小房子|小家)', post):
        pre=post[max(0,m.start()-16):m.start()]
        tail=post[m.end():m.end()+6]
        if _R7_SKIP_PRE.search(pre) or _R7_SKIP_POST.match(tail):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    # 1000块能租 / 800块能不能租一室一厅
    for m in re.finditer(r'('+N+r')\s*(?:元|块钱|块)\s*(?:能*不能?租|就能租|能租|租到|租个)', post):
        pre=post[max(0,m.start()-16):m.start()]
        if _R7_SKIP_PRE.search(pre):
            continue
        amt=_r7_amt(m.group(1), pre, 100, 20000)
        if amt is None:
            continue
        found.append(dict(quote=m.group().strip(),amount=amt,period='month',kind='whole_home'))
    return found
_video_listed_rent_r6=video_listed_rent
def video_listed_rent(row):
    info=_video_listed_rent_r6(row)
    post=_r5_post(row)
    extra=_r7_extra(post) if post else []
    if not extra:
        return info
    uniq=list(info.get('prices') or [])
    seen=set((round(x['amount'],2), x.get('kind'), x.get('period')) for x in uniq)
    for item in extra:
        key=(round(item['amount'],2), item.get('kind'), item.get('period'))
        if key in seen:
            continue
        seen.add(key)
        uniq.append(item)
    whole=[x for x in uniq if x.get('kind')=='whole_home']
    other=[x for x in uniq if x.get('kind')!='whole_home']
    borderline=info.get('borderline')
    if not whole:
        if other:
            borderline=borderline or 'per_bed_or_per_person'
        return dict(state='unverified',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=None,borderline=borderline)
    lows=[x for x in whole if x['amount']<VIDEO_RENT_FLOOR]
    highs=[x for x in whole if x['amount']>=VIDEO_RENT_FLOOR]
    if lows and highs:
        return dict(state='mixed',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=lows[0]['quote']+'|'+highs[0]['quote'],borderline='mixed_prices')
    if lows and not highs:
        return dict(state='below_floor',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=lows[0]['quote'],borderline=None)
    return dict(state='at_or_above',floor=VIDEO_RENT_FLOOR,prices=uniq,quote=highs[0]['quote'] if highs else None,borderline=None)

_screen_r6=screen
def screen(row, now=None):
    out=_screen_r6(row, now)
    info=video_listed_rent(row)
    out['video_listed_rent']=info
    if info.get('state')!='below_floor':
        return out
    reasons=list(out['exclusion_reasons'])
    if 'low_price_video_budget_mismatch' not in reasons:
        reasons.append('low_price_video_budget_mismatch')
    out.update(exclusion_reasons=reasons,
               exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],
               eligible_candidate=False,eligible_priority=False,
               candidate_state='excluded',
               lead_intent='low',lead_intent_label='低意向',commercial_fit='very_low',
               video_gate_quote=info.get('quote'))
    return out
# --- end ROUND7-20261114 ---


# --- ROUND8-20261115: comments under a video also reveal a cheap listing ---
# CLI still cannot see the picture or spoken audio. If any comment under the
# same video clearly states a whole-home price/budget below the 3000 floor
# (including daily/weekly converted, and colloquial 几百/一千多/一两千/两千多),
# every comment under that video is excluded, including ones with no price or
# a higher own budget. Call prepare_low_price_comment_videos() on the full
# comment set for those videos before screen()/apply(); otherwise this gate
# does not fire. Raw collection and the ledger are not modified here.
REASON_LABELS['low_price_comment_video']='低价评论-整视频不符'
_LOW_PRICE_COMMENT_VIDEOS={}
_R8_SKIP=re.compile(r'押金|水电|电费|水费|网费|物业(?:费)?|停车|车位|中介费|首付|工资|月薪|收入|宽带|以前|之前|原来|曾经|去年')
_R8_HUNDREDS=re.compile(r'(?:预算|房租|租金|月租|整租|就|才|只要|仅需).{0,8}(?:大)?几百(?:块钱|块|元)?(?!米|平|㎡|万|人)|(?:大)?几百(?:块钱|块|元)(?:钱)?(?:的)?(?:预算|房租|租金|月租|整租|能租|租得|租个|房子)?')
_R8_1TO2K=re.compile(r'(?:预算|房租|租金|月租|整租|就|才|只要|仅需).{0,8}(一两千|一千多|两千多)')

def _r8_video_key(row):
    if not isinstance(row, dict):
        return None
    c=row.get('classification') or {}
    meta=c.get('original_metadata') or {} if isinstance(c, dict) else {}
    for src in (row, meta, c if isinstance(c, dict) else {}):
        if not isinstance(src, dict):
            continue
        val=src.get('video_id') or src.get('aweme_id') or src.get('item_id')
        if val:
            return str(val)
    return None

def _r8_comment_text(row):
    if not isinstance(row, dict):
        return ''
    c=row.get('classification') or {}
    return (row.get('comment_text') or row.get('text') or (c.get('comment_text') if isinstance(c, dict) else '') or '')

def _r8_plausible_monthly(amt):
    if amt is None:
        return True
    try:
        amt=float(amt)
    except (TypeError, ValueError):
        return False
    if amt<100 or amt>=VIDEO_RENT_FLOOR:
        return False
    # 300.500 typo / per-sqm 85.04, but keep 1.2k already converted to 1200.
    if abs(amt-round(amt))>0.01 and amt<1000:
        return False
    return True

def _r8_negating_context(t):
    return bool(re.search(r'降了|降价|房租降|降\s*(?:\d+|[一二三四五六七八九十百千]+)|便宜了|贵了|少了|超出|总价|买房|首付|也可以买|每平|／m|/m2|平方租金|11月租|8月租', t))

def comment_low_price_signal(text):
    """Return {quote, amount, kind} when a comment itself marks the video as below-floor."""
    t=text or ''
    if not t.strip():
        return None
    negated=_r8_negating_context(t)
    b=budget(t, True)
    if b.get('state')=='below_3000':
        ev=next((e for e in (b.get('evidence') or []) if e.get('usable')), None)
        quote=(ev or {}).get('quote') or t[:40]
        amt=b.get('monthly_maximum')
        if amt is None:
            amt=(ev or {}).get('maximum') or (ev or {}).get('nominal_amount')
        # A decrease / purchase / month-name parse must not mark the whole video.
        if (not negated or (re.search(r'预算', t) and not re.search(r'降了|降价|房租降|降\s*(?:\d+|[一二三四五六七八九十百千]+)', t))) and _r8_plausible_monthly(amt) and not re.search(r'降了|降价|房租降|降\s*(?:\d+|[一二三四五六七八九十百千]+)|少了|超出|总价|买房', t):
            return dict(quote=str(quote).strip(), amount=amt, kind='comment_budget')
    extra=_r7_extra(t)
    lows=[x for x in extra if x.get('kind')=='whole_home' and x.get('amount') is not None and x['amount']<VIDEO_RENT_FLOOR]
    highs=[x for x in extra if x.get('kind')=='whole_home' and x.get('amount') is not None and x['amount']>=VIDEO_RENT_FLOOR]
    if lows and not highs and _r8_plausible_monthly(lows[0]['amount']) and not re.search(r'降了|降价|房租降|降\s*(?:\d+|[一二三四五六七八九十百千]+)|少了|超出|总价|买房', t):
        return dict(quote=lows[0]['quote'], amount=lows[0]['amount'], kind='comment_listed_or_daily')
    if _R8_SKIP.search(t) and not re.search(r'预算|月租|房租|租金|整租', t):
        return None
    if re.search(r'降了|降价|房租降|降\s*(?:\d+|[一二三四五六七八九十百千]+)|便宜了|贵了|少了|超出', t):
        return None
    m=_R8_HUNDREDS.search(t)
    if m and not re.search(r'米|平|㎡|平方', m.group()):
        return dict(quote=m.group().strip(), amount=None, kind='colloquial_hundreds')
    m=_R8_1TO2K.search(t)
    if m:
        return dict(quote=m.group().strip(), amount=None, kind='colloquial_1to2k')
    return None

def prepare_low_price_comment_videos(rows):
    """Index videos that already have a below-floor comment. Replaces any previous index."""
    global _LOW_PRICE_COMMENT_VIDEOS
    flagged={}
    protected=set()
    for row in rows or []:
        vid=_r8_video_key(row)
        if not vid:
            continue
        cap=video_listed_rent(row)
        if cap.get('state') in ('at_or_above','mixed'):
            protected.add(vid)
        sig=comment_low_price_signal(_r8_comment_text(row))
        if sig and vid not in flagged:
            flagged[vid]=dict(sig, comment_id=str(row.get('comment_id') or ''))
    for vid in protected:
        flagged.pop(vid, None)
    _LOW_PRICE_COMMENT_VIDEOS=flagged
    return flagged

def prepare_low_price_comment_videos_from_jsonl(path, only_video_ids=None):
    """Stream a jsonl comment file so daily resort can use siblings already dropped from pending."""
    import json
    global _LOW_PRICE_COMMENT_VIDEOS
    wanted=set(str(x) for x in only_video_ids) if only_video_ids is not None else None
    flagged={}
    protected=set()
    p=Path(path)
    if not p.exists():
        _LOW_PRICE_COMMENT_VIDEOS={}
        return flagged
    with p.open(encoding='utf-8-sig') as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                row=json.loads(line)
            except Exception:
                continue
            vid=_r8_video_key(row)
            if not vid:
                continue
            if wanted is not None and vid not in wanted:
                continue
            cap=video_listed_rent(row)
            if cap.get('state') in ('at_or_above','mixed'):
                flagged.pop(vid, None)
                protected.add(vid)
                continue
            if vid in flagged or vid in protected:
                continue
            sig=comment_low_price_signal(_r8_comment_text(row))
            if sig:
                flagged[vid]=dict(sig, comment_id=str(row.get('comment_id') or ''))
    for vid in list(flagged):
        if vid in protected:
            flagged.pop(vid, None)
    _LOW_PRICE_COMMENT_VIDEOS=flagged
    return flagged

def clear_low_price_comment_videos():
    global _LOW_PRICE_COMMENT_VIDEOS
    _LOW_PRICE_COMMENT_VIDEOS={}

def low_price_comment_video(row):
    vid=_r8_video_key(row)
    if not vid:
        return None
    return _LOW_PRICE_COMMENT_VIDEOS.get(vid)

_screen_r7=screen
def screen(row, now=None):
    out=_screen_r7(row, now)
    info=low_price_comment_video(row)
    if not info:
        return out
    reasons=list(out['exclusion_reasons'])
    if 'low_price_comment_video' not in reasons:
        reasons.append('low_price_comment_video')
    if 'low_price_video_budget_mismatch' not in reasons:
        reasons.append('low_price_video_budget_mismatch')
    out.update(exclusion_reasons=reasons,
               exclusion_reason_labels=[REASON_LABELS[x] for x in reasons if x in REASON_LABELS],
               eligible_candidate=False,eligible_priority=False,
               candidate_state='excluded',
               lead_intent='low',lead_intent_label='低意向',commercial_fit='very_low',
               video_gate_quote=out.get('video_gate_quote') or info.get('quote'),
               video_gate_source=out.get('video_gate_source') or 'comment')
    return out
# --- end ROUND8-20261115 ---
