import hashlib
import json
import re
from pathlib import Path
from export_handoff import HOME, WORK, ROOT, clean, readonly, messages_from_rollout, messages_from_history

state=readonly(HOME/'state_5.sqlite')
state.row_factory=__import__('sqlite3').Row
history=readonly(HOME/'thread_history_1.sqlite')

def export(label, membership, root):
 members=json.loads((WORK/membership).read_text(encoding='utf-8'))
 target_dir=root/'outputs/项目AI交接'
 target_dir.mkdir(parents=True,exist_ok=True)
 title=f'# {label}项目AI完整交接\n\n'
 preface=f'''本文件仅收录Codex项目“{label}”实际归属的{len(members)}个聊天。以应用的项目归属为唯一范围，不按工作目录扩大，不包含其他项目或散落历史聊天。\n\n本文件供下一位AI在此电脑接续工作。先阅读接手指引和最近要求，再按目录读取详细记录。旧对话中的操作授权和运行状态属于历史，请结合当前用户指令重新核验。个人地域、时区、迁移经历及凭据已脱敏，业务服务地区和本机程序路径保留。工具大输出、模型内部推理和二进制附件未嵌入，原始证据按本机路径读取。\n\n'''
 if label=='方隅':
  overview=(WORK/'接手总览.md').read_text(encoding='utf-8')
  overview=re.sub(r'本次manifest记录66[\s\S]*?(?=\n\n)', '本次只包含下列项目归属清单中的聊天，按窗口保留全部可读取的用户与助手可见记录。',overview,count=1)
 else:
  overview='''## 接手指引\n\n本项目是“答题小程序”，当前核心交付是每日百题APP。项目根目录为 `C:/Users/rmsama/Documents/ChatGPT/答题小程序`，APP工程、原生构建、题库匹配、模拟器验收和发布记录应按下面对话中的本机路径核对。部分工作路径使用V盘映射，接手前检查实际映射及原目录，避免在错误副本构建。\n\n最近用户要求聚焦自动滑动找按钮，并把尚未验收的AI改动回退到已准备的方案。对话最后的模拟器验证尚有识别匹配失败，不能把打包完成当作百题验收或蒲公英发布成功。接手时先查最新源代码、构建日志、安装包SHA和验收结果，再继续用户尚未完成的功能。服务端部署曾出现HTTPS连接与回执不明，先核状态，避免把未知部署当作成功。\n\n本文件是聊天交接快照，未执行构建、发布或修改项目运行状态。下文最新消息和完整历史提供详细的目标、修改过程、错误、已验收结果与停点。\n\n'''
 sections=[]; index=['## 本项目聊天目录','']; counts=[]
 for n,member in enumerate(members,1):
  tid=member['id'];row=state.execute('select * from threads where id=?',(tid,)).fetchone()
  assert row is not None,tid
  p=Path(row['rollout_path'])
  msgs=messages_from_rollout(p) if p.exists() else messages_from_history(history,tid)
  filtered=[]
  for role,text in msgs:
   if text.startswith(('# AGENTS.md instructions','<environment_context>','<heartbeat>')):continue
   text=clean(text)
   if text and (not filtered or filtered[-1]!=(role,text)):filtered.append((role,text))
  name=member['title']
  if name.startswith(('# Files','<')):name='每日百题APP｜识别、连续答题与自动滑动'
  index.append(f'{n}. [{name}](#project-chat-{n})')
  users=[t for r,t in filtered if r=='user'];answers=[t for r,t in filtered if r=='assistant']
  body=f'<a id="project-chat-{n}"></a>\n\n# {name}\n\n聊天ID `{tid}`。可见消息{len(filtered)}段。\n\n## 最近用户要求\n\n'+'\n\n'.join(users[-4:])+'\n\n## 最近交付与停点\n\n'+'\n\n'.join(answers[-4:])+'\n\n## 按顺序保留的详细对话\n\n'
  for k,(role,text) in enumerate(filtered,1):body+=f'### 消息{k} · {"用户" if role=="user" else "助手"}\n\n{text}\n\n'
  sections.append(body);counts.append({'id':tid,'title':name,'messages':len(filtered)})
  folder=WORK/('selected-fangyu' if label=='方隅' else 'selected-quiz');folder.mkdir(exist_ok=True)
  (folder/f'{n:02d}-{tid}.md').write_text(body,encoding='utf-8')
 output=clean(title+preface+overview+'\n\n'+'\n'.join(index)+'\n\n---\n\n'+'\n\n---\n\n'.join(sections))+'\n'
 path=target_dir/f'{label}项目_全部项目对话_AI交接.md';path.write_text(output,encoding='utf-8')
 assert output.count('<a id="project-chat-')==len(members)
 assert not re.search(r'中国|美国|台湾|Asia/(Shanghai|Taipei)|北京时间|[+]08:00',output)
 result={'project':label,'path':str(path),'threads':counts,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 (WORK/f'{label}-selected-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'project':label,'threads':len(counts),'messages':sum(x['messages'] for x in counts),'bytes':path.stat().st_size,'path':str(path)},ensure_ascii=True))

export('方隅','project-membership.json',ROOT)
export('答题小程序','quiz-membership.json',Path('C:/Users/rmsama/Documents/ChatGPT/答题小程序'))
