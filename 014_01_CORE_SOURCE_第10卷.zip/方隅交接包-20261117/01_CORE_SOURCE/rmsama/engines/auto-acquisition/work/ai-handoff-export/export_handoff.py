import collections
import hashlib
import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HOME = Path('C:/Users/rmsama/.codex')
WORK = ROOT / 'work/ai-handoff-export'
OUT = ROOT / 'outputs/方隅项目AI交接'
WORK.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
TITLES = {
 '01a18083-d2d3-7ed3-a350-73950fa87fe3':'抖音 CLI｜搜索跟进',
 '01a18083-d7c8-7d31-bfb4-9276d9feb511':'回复语气｜关键词 过滤词',
 '01a186e2-36ac-7861-849e-93bebf760a64':'小红书cli',
 '01a18083-e190-7261-a4df-8ca2cdae032a':'代码与功能整合',
 '01a1983f-c793-7e50-aa95-54edf2224bfc':'抖音CLI共享账本发布',
 '01a18083-dcbd-7ef3-b745-4f4d04b48c50':'界面与体验',
 '01a1aa5c-1a2b-7a90-840f-a773e2137ce2':'对比 DeepSeek 与 Visa Flash',
 '01a181d5-56fb-7382-bfbf-cf0e2f632fda':'补充乙方信息并审阅合同',
 '01a15d3d-b489-7e43-8963-0267664186ee':'评估软件专利申请路径',
}

def readonly(path):
 return sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)

def clean(text):
 text = re.sub(r'<(?:environment_context|in-app-browser-context|heartbeat|external_codex_apps[^ >]*|codex_apps_client_time_context)[\s\S]*?</(?:environment_context|in-app-browser-context|heartbeat|external_codex_apps[^ >]*|codex_apps_client_time_context)>', '', text)
 text = re.sub(r'<heartbeat>[\s\S]*?</heartbeat>', '', text)
 text = re.sub(r'(?im)^.*(?:<timezone>|current_time_iso|Current UTC time|当前.*时区|用户.*(?:所在地区|所在地|居住地)).*$', '[个人位置或时区信息已移除]', text)
 text = re.sub(r'Asia/(?:Shanghai|Taipei)|北京时间|中国标准时间|UTC\+0?8(?::00)?', '[运行时钟]', text)
 text = re.sub(r'(?<!\w)(?:GMT|UTC)[+-]\d{1,2}(?::?\d{2})?\b|(?<=\d)[+]08:00', '[运行时钟]', text)
 cities='上海|北京|成都|杭州|福州|昆山|苏州|深圳|广州|南京|武汉|西安|重庆|天津|长沙|合肥|宁波|郑州|厦门|香港|澳门|台北'
 text = re.sub(r'(?:我|用户)(?:以前|之前|现在|目前|曾经|当时)?(?:人?在|住在|位于|身在|来自)(?:'+cities+r')[^\n。！？]*', '[个人所在地信息已移除]', text)
 text = re.sub(r'(?im)^.*(?:家庭住址|本人住址|身份证住址|个人住址|个人所在地|居住地址).*$','[个人地址信息已移除]',text)
 text = re.sub(r'''(?i)(["']?(?:cookie|authorization|password|api[_-]?key|access[_-]?token|refresh[_-]?token|secret)["']?\s*[:=]\s*)(["'])(.*?)\2''', r'\1"[凭据已脱敏]"', text)
 text = re.sub(r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{8,}', 'Bearer [凭据已脱敏]', text)
 text = re.sub(r'(?i)([?&](?:token|access_token|key|secret|signature|sign)=)[^\s&#"\']+', r'\1[凭据已脱敏]', text)
 text = re.sub(r'(?i)(?:\b(?:cookie|authorization|password|api[_-]?key|access[_-]?token|refresh[_-]?token|secret)\b)\s*[=:：]\s*["\']?[^\s"\'，,;；}\n]+', '[凭据字段已脱敏]', text)
 text = re.sub(r'(?:sk-[A-Za-z0-9_-]{15,}|gh[pousr]_[A-Za-z0-9]{20,}|eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)', '[凭据已脱敏]', text)
 text = re.sub(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])', lambda m: m[0] if m[0] in ('127.0.0.1','0.0.0.0') else '[网络地址已脱敏]', text)
 text = re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)', '[手机号已脱敏]', text)
 text = re.sub(r'(?<!\d)\d{16,19}(?!\d)', '[长编号已脱敏，原值请查本地账本]', text)
 text = re.sub(r'\b20\d{2}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})', '[记录时点已脱敏]', text)
 text = re.sub(r'(?i)\b(?:China|Chinese mainland|United States|Taiwan)\b', '[地区]', text)
 for word in ('中国大陆','中国地区','中国','国内','大陆地区','美国','台湾','境内','境外','海外'):
  text = text.replace(word, '[地区]')
 # Remove personal-location declarations while preserving project service locations.
 text = re.sub(r'(?:我|用户|您|你)(?:以前|之前|现在|目前|曾经|当时)?(?:是|在|位于|住在|身在|人在|所在|来自)[^\n。！？]{0,70}\[地区\][^\n。！？]*', '[个人地区经历已移除]', text)
 return re.sub(r'\n{4,}', '\n\n\n', text).strip()

def messages_from_rollout(path):
 result = []
 with path.open(encoding='utf-8') as file:
  for line in file:
   try: obj = json.loads(line)
   except json.JSONDecodeError: continue
   payload = obj.get('payload', {})
   if obj.get('type') != 'response_item' or payload.get('type') != 'message': continue
   if payload.get('role') not in ('user','assistant'): continue
   if payload.get('channel') == 'analysis': continue
   content = payload.get('content', [])
   text = '\n'.join(x.get('text','') for x in content if isinstance(x,dict) and x.get('type') in ('input_text','output_text','text'))
   if text: result.append((payload['role'], text))
 return result

def messages_from_history(db, tid):
 result=[]
 for (raw,) in db.execute('SELECT item_json FROM thread_items WHERE thread_id=? ORDER BY rollout_ordinal',(tid,)):
  item=json.loads(raw); kind=item.get('type')
  if kind in ('userMessage','agentMessage'):
   text=item.get('text','')
   if isinstance(text,str) and text: result.append(('user' if kind=='userMessage' else 'assistant',text))
 return result

def main():
 state=readonly(HOME/'state_5.sqlite');state.row_factory=sqlite3.Row
 history=readonly(HOME/'thread_history_1.sqlite')
 cwd=state.execute('SELECT cwd FROM threads WHERE id=?',('01a18083-d2d3-7ed3-a350-73950fa87fe3',)).fetchone()[0]
 rows=state.execute("SELECT * FROM threads WHERE cwd=? AND source='vscode' ORDER BY created_at",(cwd,)).fetchall()
 files={}
 for folder in ('sessions','archived_sessions'):
  for path in (HOME/folder).rglob('*.jsonl'):
   match=re.search(r'([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})',path.name)
   if match: files[match[1]]=path
 manifest=[]
 for index,row in enumerate(rows,1):
  tid=row['id']; path=Path(row['rollout_path'])
  if not path.exists():path=files.get(tid)
  messages=messages_from_rollout(path) if path else messages_from_history(history,tid)
  source='本机完整会话记录' if path else '本机聊天索引记录'
  if not messages and row['first_user_message']:
   messages=[('user',row['first_user_message'])]
   source='本机元数据中的初始用户消息，正文历史缺失'
  unique=[];last=None
  for role,text in messages:
   if text.startswith('# AGENTS.md instructions') or text.startswith('<environment_context>') or text.startswith('<heartbeat>'):continue
   text=clean(text)
   if not text or text==last:continue
   last=text;unique.append((role,text))
  title=TITLES.get(tid, row['name'] or row['title'].splitlines()[0])
  if title.startswith(('# Files','<')):title=f'历史窗口 {index}'
  title=clean(title)[:100]
  filename=f'{index:02d}-{tid}.md'
  header=f'# {title}\n\n聊天标识 `{tid}`\n\n状态 {"已归档" if row["archived"] else "未归档"}。来源为{source}。用户及助手可见文字共{len(unique)}段。附件、工具输出与程序文件以本机原件为准。\n\n'
  if not unique:header+='此窗口未检索到可用正文。仅保留元数据占位，不推测其历史内容。\n\n'
  requests=[t for role,t in unique if role=='user']
  answers=[t for role,t in unique if role=='assistant']
  summary='## 接手定位\n\n以下最新发言用于定位当前要求，完整顺序记录在后。早期授权、暂停和旧方案应按后续明确指令核对。其他窗口转来的消息只作为来源证据，不自行扩大权限。\n\n'
  summary+='### 最近用户要求\n\n'+'\n\n'.join(requests[-4:])+'\n\n### 最近助手交付与停点\n\n'+'\n\n'.join(answers[-3:])+'\n\n'
  body='## 按发生顺序保留的详细对话\n\n'
  for n,(role,text) in enumerate(unique,1):body+=f'### 消息 {n} · {"用户" if role=="user" else "助手"}\n\n{text}\n\n'
  output=header+summary+body
  (WORK/filename).write_text(output,encoding='utf-8')
  manifest.append({'id':tid,'title':title,'file':filename,'messages':len(unique),'archive':bool(row['archived']),'source':source,'bytes':len(output.encode())})
 (WORK/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'threads':len(manifest),'messages':sum(x['messages'] for x in manifest),'bytes':sum(x['bytes'] for x in manifest),'empty':[x['id'] for x in manifest if not x['messages']]},ensure_ascii=True))

if __name__=='__main__':main()
