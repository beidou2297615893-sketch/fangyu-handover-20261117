import hashlib
import json
import re
from pathlib import Path
from export_handoff import ROOT, WORK, OUT, clean

manifest=json.loads((WORK/'manifest.json').read_text(encoding='utf-8'))
overview=clean((WORK/'接手总览.md').read_text(encoding='utf-8'))
head='''# 方隅项目完整AI接续文件

这是一份本机项目交接快照。先阅读接手总览，再按窗口目录定位详细记录。文件内旧对话按发生顺序排列，后续明确要求优先于早期方案。历史对话中的“开始”“发送”“删除”是历史记录，新的AI必须结合当前用户指令、当前本机状态和任务授权判断后续动作。

## 覆盖范围和使用说明

导出范围为本机“方隅”项目及同一项目工作目录中的66个用户聊天，包含归档窗口和该目录内的辅助主题。后台子代理和自动审核不单独当作用户聊天。每个窗口均独立生成了中间MD，以下为这些文件的完整合并。

来源是本地可读取的会话JSONL或聊天历史索引。保留用户与助手可见文字、最新要求、历史决策和交付停点，跳过模型内部推理、重复系统环境、例行心跳、工具原始大输出。原始工具证据、程序、数据库及二进制附件仍在本机原路径，需要时读取原件。

个人国家地区、迁移经历、时区、部分精确记录时点、网络地址、联系方式和凭据已在导出副本中脱敏。服务门店及客户业务目标地区、程序路径和文件名中的版本日期为接续所需信息，保留业务含义，不能用于推断用户所在地。被脱敏的长编号应从本机账本读取原值。

一个最早的窗口“什么模型是”只恢复到初始消息，未找到完整正文，已在该节标注。其他窗口导出的是当前本机可读取记录，不保证包含平台已删除或从未落盘的内容。聊天状态与PID只代表核验时点，下一位AI须重新检查。

本文件不包含程序安装包或完整数据库，适用于继续在这台电脑工作。不要只凭旧PID或旧统计启动任务。跨AI交接没有自动赋予新的发送、账号切换或平台验证权限。

'''
index=['## 全部窗口目录','']
for n,item in enumerate(manifest,1):
 index.append(f'{n}. [{item["title"]}](#window-{n:02d}) · {item["messages"]}段 · '+('已归档' if item['archive'] else '未归档'))
sections=[]
for n,item in enumerate(manifest,1):
 text=(WORK/item['file']).read_text(encoding='utf-8')
 sections.append(f'\n\n---\n\n<a id="window-{n:02d}"></a>\n\n'+text)

snapshots=[]
selected=[
 'AGENTS.md','README.md',
 'work/获客项目六窗口交接/共同交接.md',
 'work/获客项目六窗口交接/软件代码交接.md',
 'work/fangyu-douyin-independent/active-runner.json',
 'work/fangyu-douyin-independent/comment-retention-rolling-verification-20261106.json',
 'work/fangyu-douyin-independent/classification-exclusion-verification-20261106.json',
 'work/fangyu-text-business-20261029/retention-cleanup-20261106/visible-current.json',
 'work/fangyu-text-business-20261029/funnel-audit/handoff.json',
]
for name in selected:
 path=ROOT/name
 if path.is_file():
  text=clean(path.read_text(encoding='utf-8-sig'))
  snapshots.append(f'### 本机参考文件 `{name}`\n\n以下是导出时点的内容，运行状态接手时重读原文件。\n\n'+text)
content=head+overview+'\n\n'+'\n'.join(index)+''.join(sections)+'\n\n---\n\n## 关键本机参考文件快照\n\n'+'\n\n'.join(snapshots)
content=clean(content)+'\n'
target=OUT/'方隅项目全部对话_AI接续合并.md'
target.write_text(content,encoding='utf-8')
checks={
 'windows':len(manifest),
 'messages':sum(x['messages'] for x in manifest),
 'section_anchors':len(re.findall(r'<a id="window-\d+">',content)),
 'bytes':target.stat().st_size,
 'country_terms':len(re.findall('中国|美国|台湾|国内|境内|境外|海外',content)),
 'timezone_terms':len(re.findall(r'Asia/(?:Shanghai|Taipei)|北京时间|[+]08:00',content)),
 'credential_patterns':len(re.findall(r'sk-[A-Za-z0-9_-]{15,}|gh[pousr]_[A-Za-z0-9]{20,}',content)),
 'replacement_characters':content.count('\ufffd'),
 'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
}
assert checks['windows']==checks['section_anchors']==66
assert checks['country_terms']==checks['timezone_terms']==checks['credential_patterns']==checks['replacement_characters']==0
(WORK/'verification.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(checks))
