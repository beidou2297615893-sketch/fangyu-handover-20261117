# 本地获客工作台

Windows 独立桌面客户端，使用原生窗口承载本机工作台，不把工作台打开在浏览器标签页中。核心独立于平台 CLI 和行业资料，当前首个交付配置为方隅公寓，以小红书为主，抖音复用用户已实际使用的专用 Bridge CLI。

## 启动与桌面运行

安装后双击桌面入口，或双击便携目录内的主程序；首次启动创建管理员，之后使用员工账号登录。客户端需要免费的 Microsoft Edge WebView2 Runtime；客户不需要安装 Python 或 Node。缺少桌面运行时会提示启动失败，不会退回外部浏览器展示工作台。当前窗口关闭会停止本客户端拥有的任务与连接服务；重新打开不会自动恢复采集。

界面严格依据已指定原图：05 总览、03 线索与转化、04 回复模板与物料、01 员工登录。首页采用四项统计、任务与账号双栏、线索处理表及员工服务条；统计排除演示数据。

抖音、快手的平台网页和连接脚本仍需要 Chrome 或 Edge 等外部浏览器，平台原帖也可能在外部浏览器打开；这与工作台本身的独立桌面窗口是两回事。平台账号连接、真实采集和发送仍需各客户独立验收。

## 结构

- `src/core`：SQLite、租户与员工、检索规则、意向分级、回复审批与发送状态机。
- `src/resources/adapters`：平台命令合同；命令启动检查不等于账号登录或真实发送验收。
- `src/resources/companies`：公寓、餐饮、摄影、美业配置。真实业务字段留空等待客户填写。
- `src/web`：员工操作界面；`src/app.py`：仅回环地址的本地服务；`src/desktop.py`：WebView2 独立桌面窗口；`src/bridge.py`：独立抖音连接服务。
- `company.json`：本安装包的企业配置；不同 `id` 使用不同本地数据目录。
- `work/build-tools`：构建、安装器和客户版本组装脚本。
- `work/vendor/github`：已下载的 GitHub 源码与受限研究项目；研究项目不等于安装包组件。
- `outputs/核心组件`：可复用源码包、冻结清单和复用说明。
- `outputs/方隅公寓客户端`：方隅安装程序、便携版和员工说明；当前保留包为旧版未认可。
- `outputs/UI审核`：下一版截图预审，用户认可前不重新构建安装包。

## 开发与验证

```powershell
python src/app.py --data-dir work/dev-data
work/vendor/cli-runtime/Scripts/python.exe -m unittest discover -s tests -v
work/runtime/douyin-bridge/node.exe tests/test_bridge_strict_routing.cjs
work/runtime/douyin-bridge/node.exe tests/test_kuaishou_bridge.cjs
python work/build-tools/test_installer.py
python work/build-tools/build.py
python work/build-tools/build_installer.py
```

构建使用项目内 `work/vendor/cli-runtime` 的 Python/PyInstaller，不依赖客户电脑安装 Python/Node。

## 复用核心交付新客户

先复制对应行业 JSON，修改 `id/name/platform/profile/templates/intentRules/profileSchema`。`id` 一旦交付不要随意改变，否则会变成本机另一份独立数据。

```powershell
python work/build-tools/build_customer.py --config src/resources/companies/restaurant.json --name "示例餐厅" --id sample-restaurant --platform douyin
```

该命令复制已验证运行时，生成独立配置和可搬运 ZIP；不会复制客户业务数据库、管理员密码或平台凭证。先构建方隅基础运行时，再执行客户组装。

新平台使用 manifest 与 `Adapters` 中的明确字段映射。员工输入只进入参数数组，不拼接 shell。新增 CLI 后须验证许可证、输出结构、账号隔离、超时与实际平台能力，不能只改一个名称就宣称支持。

## 边界

固定模板和规则不调用付费 AI。没有默认管理员密码。真实平台登录由客户操作，未执行任何真实评论或私信验收。没有后台无限采集；检索按批次保存进度。已审批回复可在管理员明确授权后形成有限顺序队列，遇异常停止，结果不明不自动重试。

快手已复用用户本机专用 CLI 的纯代码，完成只读评论桥接加固与接入：员工提供作品链接后读取公开评论。当前不支持快手关键词搜索或发送回复，真实平台登录与采集仍待验收。该组件来自用户自有 private/UNLICENSED 项目，不是 GitHub MIT 开源项目；来源说明见 src/resources/licenses/快手自有代码来源与授权范围.md。另行下载的 tamnd 快手 CLI 仍只是页面脚手架。MediaCrawler 的非商业许可版本只保留在研究区，不进入商业包。跨电脑多人同步不在本地单机版本内。

视觉资产由同项目独立任务设计，未经型号/内容验收和合入检查的试图不进入正式包。

2026-09-17 更新：完整ZIP备份携带物料；有限连续采集每次最多50批，满足目标/日上限/异常/无更多时停止；跨行业workflow定义转化阶段和统计名称。可通过声明standard_json/isolated_home/isolation_guard并安装manifest接入新的标准JSON CLI，真实平台仍需独立验证。

界面基准：仅原图 05 / 03 / 04 / 01。导航与房子标记使用 Tabler Icons 3.41.1 官方线性图标，MIT 许可保留于 `src/resources/licenses/Tabler-icons-MIT.txt`。
