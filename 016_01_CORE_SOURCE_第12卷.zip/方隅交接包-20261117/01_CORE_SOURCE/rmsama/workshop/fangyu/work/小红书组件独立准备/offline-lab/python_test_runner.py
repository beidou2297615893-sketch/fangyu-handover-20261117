from pathlib import Path
import socket,sys,os,runpy

ROOT=Path(__file__).resolve().parent.parent
def audit(event,args):
 if event in {'socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.startfile'}:
  raise PermissionError('OFFLINE_PREPARATION: '+event+' disabled')
sys.addaudithook(audit)
sys.dont_write_bytecode=True
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
if sys.argv[1:]==['--guard-check']:
 try:socket.create_connection(('127.0.0.1',1),timeout=.1)
 except PermissionError:print('offline network guard verified')
 else:raise AssertionError('network guard failed')
else:
 import pytest
 raise SystemExit(pytest.main(sys.argv[1:]))
