import asyncio
import unittest
from contextlib import asynccontextmanager
from urllib.parse import parse_qs, urlsplit

from app.browser.identity import Identity
from app.browser.xhs_fetcher import (
    FEED_API,
    SEARCH_API,
    SEARCH_API_LEGACY,
    USER_ME_API,
    FAVORITE_ALL_API,
    FAVORITE_BOARDS_API,
    _favorite_notes,
    _xhs_page_failure,
    _xhs_search_value,
    fetch_xhs_search,
    fetch_xhs_note_detail,
    fetch_xhs_self_profile,
    fetch_xhs_favorite_boards,
    fetch_xhs_favorites,
)


class _Response:
    url = f"https://edith.xiaohongshu.com{FEED_API}"
    status = 200

    async def json(self):
        return {
            "data": {
                "items": [{
                    "id": "note-1",
                    "note_card": {"note_id": "note-1", "title": "fixture"},
                }],
            },
        }


class _Page:
    def __init__(self):
        self.response = _Response()
        self.listeners = []

    def on(self, event, listener):
        if event == "response":
            self.listeners.append(listener)

    async def goto(self, *_args, **_kwargs):
        # Queue async event handlers without awaiting them, reproducing the
        # scheduling race seen when a temporary page closes quickly. The
        # synchronous response inbox still captures the exact response.
        for listener in self.listeners:
            result = listener(self.response)
            if asyncio.iscoroutine(result):
                asyncio.create_task(result)


class _Manager:
    def __init__(self):
        self.page = _Page()

    @asynccontextmanager
    async def visible_page(self, _identity):
        yield self.page


class XhsFetcherResponseTests(unittest.TestCase):
    def test_favorite_response_shapes_are_normalized(self):
        self.assertEqual(_favorite_notes({"notes": [{"note_id": "n1"}]}),
                         [{"note_id": "n1"}])
        self.assertEqual(_favorite_notes({"items": [{"id": "n2"}]}),
                         [{"id": "n2"}])

    def test_favorite_boards_and_notes_are_captured_before_page_release(self):
        class Response:
            status = 200

            def __init__(self, path):
                self.url = "https://edith.xiaohongshu.com" + path

            async def json(self):
                if FAVORITE_BOARDS_API in self.url:
                    return {"data": {"boards": [{"id": "b1", "name": "选题库", "total": 1}]}}
                return {"data": {"notes": [{"note_id": "n1", "display_title": "收藏样本",
                                               "xsec_token": "token-1"}]}}

        class Locator:
            first = None

            def __init__(self, page, label):
                self.first = self
                self.page, self.label = page, label

            async def is_visible(self, **_kwargs):
                return self.label in {"收藏", "选题库"}

            async def click(self):
                path = FAVORITE_BOARDS_API if self.label == "收藏" else FAVORITE_ALL_API
                await self.page.emit(Response(path))

        class Page:
            url = "about:blank"

            def __init__(self):
                self.listeners = []

            def on(self, event, listener):
                if event == "response":
                    self.listeners.append(listener)

            async def emit(self, response):
                for listener in list(self.listeners):
                    result = listener(response)
                    if asyncio.iscoroutine(result):
                        await result

            async def goto(self, url, **_kwargs):
                self.url = url

            def get_by_text(self, label, **_kwargs):
                return Locator(self, label)

        class Interaction:
            async def scroll_step(self, *_args):
                return None

        class Manager:
            def __init__(self):
                self.page = Page()
                self.xhs_interaction = Interaction()

            @asynccontextmanager
            async def visible_page(self, _identity):
                yield self.page

        async def scenario():
            identity = Identity(account_id=1, profile_dir="fixture", platform="xhs")
            boards, error = await fetch_xhs_favorite_boards(
                Manager(), identity, "user-1", settle_ms=50)
            self.assertEqual(error, "")
            self.assertEqual(boards[0]["id"], "b1")

            manager = Manager()
            # All-favorites is emitted from the same 收藏 control for this fixture.
            original = manager.page.get_by_text
            def locator(label, **kwargs):
                value = original(label, **kwargs)
                if label == "收藏":
                    async def click():
                        await manager.page.emit(Response(FAVORITE_ALL_API))
                    value.click = click
                return value
            manager.page.get_by_text = locator
            notes, error = await fetch_xhs_favorites(
                manager, identity, "user-1", max_scrolls=0)
            self.assertEqual(error, "")
            self.assertEqual(notes[0]["note_id"], "n1")
            self.assertEqual(notes[0]["xsec_source"], "pc_user")

        asyncio.run(scenario())

    def test_search_values_normalize_time_and_human_readable_likes(self):
        self.assertEqual(
            _xhs_search_value({"note_card": {"time": 1_700_000_000_000}}, "time"),
            1_700_000_000,
        )
        self.assertEqual(
            _xhs_search_value({"note_card": {
                "interact_info": {"liked_count": "1.2万"},
            }}, "likes"),
            12_000,
        )

    def test_waited_detail_response_is_parsed_before_page_is_released(self):
        async def scenario():
            identity = Identity(
                account_id=1, profile_dir="fixture", platform="xhs",
                identity_mode="native")
            detail, error = await fetch_xhs_note_detail(
                _Manager(), identity, "note-1")
            self.assertEqual(error, "")
            self.assertEqual(detail["note_id"], "note-1")

        asyncio.run(scenario())

    def test_detail_uses_ssr_card_when_page_does_not_emit_feed(self):
        class Page:
            url = "about:blank"

            def on(self, *_args):
                return None

            async def goto(self, url, **_kwargs):
                self.url = url

            async def evaluate(self, _script, note_id):
                return (
                    '{"noteId":"' + note_id
                    + '","title":"fixture","imageList":[{"url":"cover"}]}'
                )

        class Manager:
            @asynccontextmanager
            async def visible_page(self, _identity):
                yield Page()

        async def scenario():
            identity = Identity(
                account_id=1, profile_dir="fixture", platform="xhs",
                identity_mode="native")
            detail, error = await fetch_xhs_note_detail(
                Manager(), identity, "note-ssr")
            self.assertEqual(error, "")
            self.assertEqual(detail["note_id"], "note-ssr")
            self.assertEqual(detail["image_list"][0]["url"], "cover")

        asyncio.run(scenario())

    def test_self_profile_arms_user_me_wait_before_opening_homepage(self):
        class Response:
            url = f"https://edith.xiaohongshu.com{USER_ME_API}"
            status = 200

            async def json(self):
                return {"data": {
                    "guest": False,
                    "user_id": "fixture-user",
                    "red_id": "fixture-red",
                    "nickname": "fixture-name",
                }}

        class Locator:
            first = None

            def __init__(self):
                self.first = self

            async def is_visible(self, **_kwargs):
                return False

        class Page:
            def __init__(self):
                self.url = "about:blank"
                self.response = Response()
                self.listeners = []
                self.gotos = []

            def on(self, event, listener):
                if event == "response":
                    self.listeners.append(listener)

            async def goto(self, url, **_kwargs):
                self.gotos.append(url)
                self.assert_waiter_was_armed = len(self.listeners) >= 2
                self.url = "https://www.xiaohongshu.com/explore"
                for listener in self.listeners:
                    result = listener(self.response)
                    if asyncio.iscoroutine(result):
                        asyncio.create_task(result)

            def get_by_text(self, *_args, **_kwargs):
                return Locator()

        class Manager:
            def __init__(self):
                self.page = Page()

            @asynccontextmanager
            async def visible_page(self, _identity):
                yield self.page

        async def scenario():
            manager = Manager()
            identity = Identity(
                account_id=1, profile_dir="fixture", platform="xhs",
                identity_mode="native")
            profile, error = await fetch_xhs_self_profile(
                manager, identity, timeout_ms=100)

            self.assertEqual(error, "")
            self.assertEqual(profile["user_id"], "fixture-user")
            self.assertTrue(manager.page.assert_waiter_was_armed)
            self.assertEqual(
                manager.page.gotos, ["https://www.xiaohongshu.com/"])

        asyncio.run(scenario())

    def test_unrelated_api_responses_do_not_masquerade_as_user_me(self):
        class Response:
            url = "https://edith.xiaohongshu.com/api/sns/web/v1/config"
            status = 200

            async def json(self):
                return {"data": {}}

        class Locator:
            first = None

            def __init__(self):
                self.first = self

            async def is_visible(self, **_kwargs):
                return False

        class Page:
            url = "about:blank"

            def __init__(self):
                self.listeners = []

            def on(self, event, listener):
                if event == "response":
                    self.listeners.append(listener)

            async def goto(self, *_args, **_kwargs):
                self.url = "https://www.xiaohongshu.com/explore"
                for listener in self.listeners:
                    result = listener(Response())
                    if asyncio.iscoroutine(result):
                        await result

            def get_by_text(self, *_args, **_kwargs):
                return Locator()

            async def evaluate(self, *_args, **_kwargs):
                return None

        class Manager:
            @asynccontextmanager
            async def visible_page(self, _identity):
                yield Page()

        async def scenario():
            identity = Identity(
                account_id=1, profile_dir="fixture", platform="xhs",
                identity_mode="native")
            profile, error = await fetch_xhs_self_profile(
                Manager(), identity, timeout_ms=1)
            self.assertEqual(profile, {})
            self.assertEqual(error, "no_user_me_xhr")

        asyncio.run(scenario())

    def test_search_accepts_v2_and_legacy_v1_responses(self):
        class Locator:
            first = None

            def __init__(self, page):
                self.first = self
                self.page = page

            async def wait_for(self, **_kwargs):
                return None

            async def press(self, key):
                if key == "Enter":
                    self.page.enter_pressed = True
                    self.page.search_listener_armed = (
                        len(self.page.listeners) >= 2)
                    await self.page.emit_response()

        class LoginLocator:
            first = None

            def __init__(self):
                self.first = self

            async def is_visible(self, **_kwargs):
                return False

        class Interaction:
            async def type_short(self, locator, text):
                locator.page.typed_text = text

            async def scroll_step(self, *_args, **_kwargs):
                return None

        class Response:
            status = 200

            def __init__(self, path):
                self.url = f"https://edith.xiaohongshu.com{path}"

            async def json(self):
                return {"data": {"items": [{
                    "id": "note-v2",
                    "model_type": "note",
                    "note_card": {"display_title": "fixture"},
                    "xsec_token": "fixture-token",
                }]}}

        class Page:
            def __init__(self, path):
                self.url = "about:blank"
                self.response = Response(path)
                self.listeners = []
                self.visited_urls = []
                self.enter_pressed = False
                self.search_listener_armed = False
                self.typed_text = ""

            def on(self, event, listener):
                if event == "response":
                    self.listeners.append(listener)

            async def emit_response(self):
                for listener in list(self.listeners):
                    result = listener(self.response)
                    if asyncio.iscoroutine(result):
                        await result

            async def goto(self, url, **_kwargs):
                self.url = url
                self.visited_urls.append(url)
                if "/search_result?" in url:
                    await self.emit_response()

            def locator(self, _selector):
                return Locator(self)

            def get_by_text(self, *_args, **_kwargs):
                return LoginLocator()

        class Manager:
            def __init__(self, path):
                self.page = Page(path)
                self.xhs_interaction = Interaction()

            @asynccontextmanager
            async def visible_page(self, _identity):
                yield self.page

        async def scenario(path, *, search_sort="general", content_type="all"):
            manager = Manager(path)
            identity = Identity(
                account_id=1, profile_dir="fixture", platform="xhs",
                identity_mode="native")
            items, error = await fetch_xhs_search(
                manager, identity, "防晒霜", set(), max_scrolls=0,
                search_sort=search_sort, content_type=content_type)
            self.assertEqual(error, "")
            self.assertEqual([item["id"] for item in items], ["note-v2"])
            self.assertGreaterEqual(len(manager.page.listeners), 2)
            return manager

        for path in (SEARCH_API, SEARCH_API_LEGACY):
            with self.subTest(path=path):
                manager = asyncio.run(scenario(path))
                self.assertEqual(manager.page.typed_text, "防晒霜")
                self.assertTrue(manager.page.search_listener_armed)
                self.assertTrue(manager.page.enter_pressed)

        filters = (
            ("latest", "images", "time_descending", "image"),
            ("most_liked", "video", "popularity_descending", "video"),
        )
        for search_sort, content_type, expected_sort, expected_type in filters:
            with self.subTest(search_sort=search_sort, content_type=content_type):
                manager = asyncio.run(scenario(
                    SEARCH_API, search_sort=search_sort,
                    content_type=content_type))
                query = parse_qs(urlsplit(manager.page.url).query)
                self.assertEqual(query["keyword"], ["防晒霜"])
                self.assertEqual(query["sort"], [expected_sort])
                self.assertEqual(query["note_type"], [expected_type])
                self.assertEqual(manager.page.typed_text, "")
                self.assertFalse(manager.page.enter_pressed)

    def test_page_failure_requires_an_explicit_login_or_verification_signal(self):
        class Locator:
            first = None

            def __init__(self, visible=False):
                self.first = self
                self.visible = visible

            async def is_visible(self, **_kwargs):
                return self.visible

        class Page:
            def __init__(self, url, login_visible=False):
                self.url = url
                self.login_visible = login_visible

            def get_by_text(self, *_args, **_kwargs):
                return Locator(self.login_visible)

        async def scenario():
            self.assertEqual(
                await _xhs_page_failure(Page(
                    "https://www.xiaohongshu.com/search_result?keyword=fixture")),
                "",
            )
            self.assertTrue((await _xhs_page_failure(Page(
                "https://www.xiaohongshu.com/login"))).startswith("logged_out:"))
            self.assertTrue((await _xhs_page_failure(Page(
                "https://www.xiaohongshu.com/website-login/captcha"))).startswith("captcha:"))
            self.assertTrue((await _xhs_page_failure(Page(
                "https://www.xiaohongshu.com/explore", True))).startswith("logged_out:"))

        asyncio.run(scenario())

    def test_detail_reports_security_page_as_risk_instead_of_expired_token(self):
        class Locator:
            first = None

            def __init__(self, text=""):
                self.first = self
                self.text = text

            async def is_visible(self, **_kwargs):
                return False

            async def inner_text(self, **_kwargs):
                return self.text

        class Page:
            def __init__(self):
                self.url = "about:blank"

            def on(self, *_args):
                return None

            async def goto(self, _url, **_kwargs):
                self.url = (
                    "https://www.xiaohongshu.com/website-login/captcha"
                    "?redirectPath=fixture")

            async def evaluate(self, *_args):
                return "{}"

            def get_by_text(self, *_args, **_kwargs):
                return Locator()

            def locator(self, _selector):
                return Locator("请求太频繁，请一分钟后再试")

        class Manager:
            @asynccontextmanager
            async def visible_page(self, _identity):
                yield Page()

        async def scenario():
            identity = Identity(
                account_id=1, profile_dir="fixture", platform="xhs",
                identity_mode="native")
            detail, error = await fetch_xhs_note_detail(
                Manager(), identity, "note-risk")
            self.assertIsNone(detail)
            self.assertTrue(error.startswith("captcha:"), error)

        asyncio.run(scenario())


if __name__ == "__main__":
    unittest.main()
