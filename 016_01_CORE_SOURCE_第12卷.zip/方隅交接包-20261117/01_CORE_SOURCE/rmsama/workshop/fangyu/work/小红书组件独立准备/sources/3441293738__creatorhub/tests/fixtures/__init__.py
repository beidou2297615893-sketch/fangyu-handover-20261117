"""Local-only integration fixtures."""
