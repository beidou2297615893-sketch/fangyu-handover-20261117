"""Pure offline proposal, not a production DB importer or platform executor.

Seam: propose_page(page, expected_scope, known_rows, manual_grades).
No IO, clock, network, model call or product dependency is created here.
The integrator owns atomic insertion and checkpoint acknowledgement.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib


def _key(scope, comment_id):
    return (scope['tenant'], scope['account'], 'xiaohongshu', comment_id)


def _comment_time(value):
    if type(value) not in (int, float) or value <= 0:
        return None
    if value > 100_000_000_000:
        value /= 1000
    try:
        return datetime.fromtimestamp(value, timezone.utc)
    except (ValueError, OverflowError, OSError):
        return None


def propose_page(page, expected_scope, known_rows, manual_grades, *, since=None):
    """Return append/link/analysis proposals without mutating any caller data.

    known_rows is keyed by tenant+account+platform+stable comment ID, not nickname.
    Existing raw records must remain available as task links. AI grades and manual
    grades are separate; this prototype never proposes overwriting either one.
    """
    required = ('tenant', 'account', 'task')
    if (not isinstance(expected_scope, dict)
            or any(not expected_scope.get(k) for k in required)
            or page.get('scope') != expected_scope):
        raise ValueError('scope mismatch; no import or checkpoint allowed')
    if not page.get('note_id') or not isinstance(page.get('comments'), list):
        raise ValueError('missing note or comment page')
    if since is not None and (not isinstance(since, datetime) or since.tzinfo is None):
        raise ValueError('since must be timezone aware')
    result = {'new_raw_comments': [], 'task_links': [], 'analysis_candidates': [],
              'unresolved_rows': [], 'conflicts': [], 'proposed_cursor': page.get('next_cursor'),
              'has_more': page.get('has_more'), 'checkpoint_committed': False,
              'manual_grades_unchanged': deepcopy(manual_grades)}
    encountered = {}
    linked = set()
    for raw in page['comments']:
        if not isinstance(raw, dict) or not raw.get('id') or not isinstance(raw.get('content'), str):
            result['unresolved_rows'].append(deepcopy(raw))
            continue
        key = _key(expected_scope, raw['id'])
        if key not in linked:
            result['task_links'].append({'comment_key': key, 'task': expected_scope['task'],
                                         'note_id': page['note_id']})
            linked.add(key)
        old = encountered.get(key, known_rows.get(key))
        if old is not None:
            if old['content'] != raw['content']:
                result['conflicts'].append({'comment_key': key, 'observed_raw': deepcopy(raw)})
            continue
        encountered[key] = raw
        time = _comment_time(raw.get('create_time'))
        result['new_raw_comments'].append({'comment_key': key, 'raw': deepcopy(raw),
                                           'note_id': page['note_id'],
                                           'created_at_utc': time.isoformat() if time else None})
        # Missing timestamps remain unknown and cannot masquerade as fresh demand.
        if since is not None and (time is None or time < since):
            continue
        result['analysis_candidates'].append({'comment_key': key, 'content': raw['content'],
                                              'content_sha256': hashlib.sha256(raw['content'].encode()).hexdigest(),
                                              'manual_override_active': key in manual_grades})
    result['page_requires_review'] = bool(result['unresolved_rows'] or result['conflicts'])
    return result


def check_model_candidate(candidate, immutable_comment_text):
    """Validate evidence without interpreting an invalid output as 'no intent'."""
    if not isinstance(candidate, dict) or candidate.get('status') not in ('intent', 'no_intent', 'insufficient'):
        return {'accepted': False, 'state': 'analysis_failed', 'raw_comment_retained': True}
    evidence = candidate.get('evidence')
    if candidate['status'] == 'intent' and (not isinstance(evidence, str) or not evidence.strip()
                                           or evidence not in immutable_comment_text):
        return {'accepted': False, 'state': 'analysis_failed', 'raw_comment_retained': True}
    return {'accepted': True, 'state': candidate['status'], 'raw_comment_retained': True}
