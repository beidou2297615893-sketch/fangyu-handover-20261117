import asyncio
import json
import tempfile
import unittest
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import app.db as db
from app.config import Config, EngineConfig
from app.engine.monitor import MonitorEngine
from app.risk import OperationKind
from app.models import (
    AccountActionTask,
    AccountRiskState,
    CommentRule,
    CommentTask,
    DmConversation,
    DouyinAccount,
    PublishTask,
    RiskEvent,
)
from sqlmodel import select


class _BrowserStub:
    def __init__(self):
        self._locks = {}
        self.identity_calls = 0
        self.anon_calls = 0

    def lock_for(self, key):
        return self._locks.setdefault(key, asyncio.Lock())

    def identity_for(self, _account):
        self.identity_calls += 1
        return None

    def anon_identity(self):
        self.anon_calls += 1
        return None


class WriteGateTests(unittest.TestCase):
    def setUp(self):
        self.previous_engine = db._engine
        self.tmp = tempfile.TemporaryDirectory()
        db.init_db(str(Path(self.tmp.name) / "gates.db"))
        self.cfg = Config(engine=EngineConfig(
            media_dir=str(Path(self.tmp.name) / "media"),
            profiles_dir=str(Path(self.tmp.name) / "profiles"),
            quiet_hours_enabled=False,
            comment_daily_cap_per_account=10,
            comment_hourly_cap_per_account=1,
            comment_min_gap_seconds=60,
            action_daily_cap_per_account=10,
            action_hourly_cap_per_account=1,
            action_min_gap_seconds=60,
            comment_risk_cooldown_seconds=3600,
        ))

    def tearDown(self):
        if db._engine is not None:
            db._engine.dispose()
        db._engine = self.previous_engine
        self.tmp.cleanup()

    def _account(self, platform="douyin"):
        with db.get_session() as session:
            account = DouyinAccount(
                platform=platform, nickname="fixture", status="active",
                storage_state='{"cookies": []}',
            )
            session.add(account)
            session.commit()
            session.refresh(account)
            return account.id

    def _cookie_account(self):
        account_id = self._account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.storage_state = json.dumps({
                "cookies": [{"domain": ".douyin.com", "name": "sid_tt",
                             "value": "fixture-cookie"}],
            })
            session.add(account)
            session.commit()
        return account_id

    def _comment_task(self, account_id):
        with db.get_session() as session:
            task = CommentTask(
                platform="douyin", account_id=account_id,
                aweme_id="fixture-work", target_comment_id="fixture-comment",
                target_nick="visitor", target_text="hello",
                content="thanks", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            return task.id

    def _xhs_comment_task(self, account_id):
        with db.get_session() as session:
            task = CommentTask(
                platform="xhs", account_id=account_id,
                aweme_id="fixture-note", xsec_token="fixture-token",
                target_comment_id="fixture-comment", target_nick="visitor",
                target_text="hello", content="thanks", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            return task.id

    def _action_task(self, account_id):
        with db.get_session() as session:
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="follow",
                target_uid="fixture-user", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            return task.id

    def _xhs_dm_task(self, account_id):
        with db.get_session() as session:
            task = AccountActionTask(
                platform="xhs", account_id=account_id, action="send_dm",
                target_uid="fixture-user", content="唯一消息",
                status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            return task.id

    def _publish_task(self, account_id, *, platform="douyin"):
        with db.get_session() as session:
            task = PublishTask(
                platform=platform,
                account_id=account_id,
                media_type="images",
                media_json="[]",
                status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            return task.id

    def test_manual_comment_execution_keeps_task_queued_outside_active_window(self):
        account_id = self._account()
        task_id = self._comment_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine._in_active_window = lambda *_args: False

        result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "pending")

    def test_manual_action_execution_uses_same_write_gate(self):
        account_id = self._account()
        task_id = self._action_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine._in_active_window = lambda *_args: False

        result = asyncio.run(engine.execute_action_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "pending")

    def test_risk_pause_blocks_and_persists_until_cleared(self):
        account_id = self._account()
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine.risk.record_failure(
            account_id, OperationKind.COMMENT, "HTTP 429")

        message = engine._comment_gate_error(account_id)
        self.assertIn("暂停至", message)
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            self.assertIsNotNone(account.write_paused_until)
        engine.risk.clear_account(account_id)
        # Manual risk clearance does not erase normal inter-operation pacing.
        self.assertEqual(engine.risk.preflight(
            account_id, OperationKind.COMMENT).signal, "operation_pacing")
        with patch("app.risk._utcnow", return_value=datetime.utcnow() + timedelta(seconds=26)):
            self.assertEqual(engine._comment_gate_error(account_id), "")

    def test_publish_outside_active_window_stays_pending(self):
        account_id = self._account()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine._in_active_window = lambda *_args: False

        result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "pending")

    def test_publish_during_risk_pause_stays_pending(self):
        account_id = self._account()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine.risk.record_failure(
            account_id, OperationKind.COMMENT, "HTTP 429")

        result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "pending")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNotNone(task.next_allowed_at)

    def test_publish_with_missing_account_fails_before_browser_use(self):
        browser = _BrowserStub()
        task_id = self._publish_task(999999)
        engine = MonitorEngine(self.cfg, browser)

        result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        self.assertEqual(browser.identity_calls, 0)
        self.assertEqual(browser.anon_calls, 0)
        with db.get_session() as session:
            self.assertEqual(session.get(PublishTask, task_id).status, "failed")

    def test_douyin_api_publish_mode_fails_without_opening_browser(self):
        self.cfg.engine.douyin_publish_mode = "api"
        browser = _BrowserStub()
        account_id = self._account()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, browser)
        publish = AsyncMock(side_effect=AssertionError(
            "unsupported API mode must not submit through browser"))

        with patch("app.engine.monitor.publish_douyin", publish):
            result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        self.assertIn("上传鉴权", result["error"])
        self.assertEqual(browser.identity_calls, 0)
        publish.assert_not_awaited()

    def test_publish_with_bad_proxy_is_deferred_for_recovery(self):
        account_id = self._account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.proxy = "http://bad.example:8000"
            account.proxy_status = "bad"
            session.add(account)
            session.commit()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "pending")
            self.assertGreater(task.next_allowed_at, datetime.utcnow())

    def test_successful_comment_blocks_immediate_cross_feature_write(self):
        account_id = self._account()
        comment_id = self._comment_task(account_id)
        action_id = self._action_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def sent(*_args, **_kwargs):
            return True, ""

        with patch("app.engine.monitor.post_comment_browser", sent):
            first = asyncio.run(engine.execute_comment_task(comment_id))
        second = asyncio.run(engine.execute_action_task(action_id))

        self.assertTrue(first["ok"])
        self.assertFalse(second["ok"])
        with db.get_session() as session:
            task = session.get(AccountActionTask, action_id)
            self.assertEqual(task.status, "pending")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNotNone(task.next_allowed_at)

    def test_dm_risk_response_does_not_retry_through_browser(self):
        account_id = self._account()
        with db.get_session() as session:
            session.add(DmConversation(
                account_id=account_id,
                conv_id="conv-fixture",
                conv_short_id="short-fixture",
                ticket="ticket-fixture",
            ))
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                conv_id="conv-fixture", target_uid="target", content="hello",
                status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        engine = MonitorEngine(self.cfg, _BrowserStub())
        browser_calls = 0

        async def api_risk(*_args, **_kwargs):
            return False, "HTTP 429"

        async def browser_retry(*_args, **_kwargs):
            nonlocal browser_calls
            browser_calls += 1
            return True, ""

        with patch("app.engine.monitor.send_dm_api", api_risk), \
                patch("app.engine.monitor.send_dm", browser_retry):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertFalse(result["ok"])
        self.assertEqual(browser_calls, 0)
        with db.get_session() as session:
            self.assertEqual(session.get(AccountActionTask, task_id).status, "pending")

    def test_douyin_api_comment_success_skips_browser(self):
        account_id = self._cookie_account()
        task_id = self._comment_task(account_id)
        self.cfg.engine.douyin_write_mode = "api"
        browser = _BrowserStub()
        def native_gate(*_args, **_kwargs):
            raise AssertionError("API mode must not require browser gate")
        browser.native_write_gate_error = native_gate
        engine = MonitorEngine(self.cfg, browser)
        browser_calls = []

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def post_comment(self, *_args, **_kwargs):
                return True, "comment-api", ""

        async def unexpected_browser(*_args, **_kwargs):
            browser_calls.append(True)
            return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.post_comment_browser", unexpected_browser):
            result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(browser_calls, [])
        self.assertEqual(engine.browser.identity_calls, 0)
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "api")
            self.assertEqual(task.result, "comment-api")

    def test_douyin_api_uncertain_comment_does_not_fallback(self):
        account_id = self._cookie_account()
        task_id = self._comment_task(account_id)
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        browser_calls = []

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def post_comment(self, *_args, **_kwargs):
                return False, "", "write_uncertain:network:TimeoutError"

        async def unexpected_browser(*_args, **_kwargs):
            browser_calls.append(True)
            return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.post_comment_browser", unexpected_browser):
            result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertFalse(result["ok"])
        self.assertEqual(browser_calls, [])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertEqual(task.method, "api")
            self.assertTrue(task.error.startswith("write_uncertain:"))

    def test_douyin_hybrid_comment_rejection_uses_browser_fallback(self):
        account_id = self._cookie_account()
        task_id = self._comment_task(account_id)
        self.cfg.engine.douyin_write_mode = "hybrid"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        browser_calls = []

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def post_comment(self, *_args, **_kwargs):
                return False, "", "api_rejected:status_code=8 频繁操作"

        async def browser_fallback(*_args, **_kwargs):
            browser_calls.append(True)
            return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.post_comment_browser", browser_fallback):
            result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(len(browser_calls), 1)
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "browser_fallback")

    def test_douyin_api_follow_success_updates_task_without_browser(self):
        account_id = self._cookie_account()
        task_id = self._action_task(account_id)
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def set_follow_state(self, *_args, **_kwargs):
                return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.do_follow", AsyncMock(side_effect=AssertionError("browser"))):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(engine.browser.identity_calls, 0)
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "api")

    def test_douyin_api_dm_success_skips_browser(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            session.add(DmConversation(
                account_id=account_id, conv_id="conv-api",
                conv_short_id="42", ticket="ticket-api",
            ))
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                conv_id="conv-api", target_uid="target", content="hello",
                status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def send_dm(self, *args, **kwargs):
                self.args, self.kwargs = args, kwargs
                return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.send_dm", AsyncMock(side_effect=AssertionError("browser"))):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(engine.browser.identity_calls, 0)
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "api")

    def test_douyin_api_dm_creates_and_persists_missing_conversation(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.uid = "987654"
            account.sec_uid = "self-sec"
            session.add(account)
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                target_uid="123456", target_sec_uid="target-sec",
                target_nick="visitor", content="hello", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = []

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def create_dm_conversation(self, *args, **kwargs):
                calls.append(("create", args, kwargs))
                return ({
                    "conv_id": "conv-created", "conv_short_id": "42",
                    "conv_type": 1, "ticket": "ticket-created",
                }, "")

            async def send_dm(self, *args, **kwargs):
                calls.append(("send", args, kwargs))
                return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.send_dm", AsyncMock(
                    side_effect=AssertionError("browser must not open"))):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual([call[0] for call in calls], ["create", "send"])
        self.assertEqual(calls[0][1], ("123456", "987654"))
        self.assertEqual(calls[1][1],
                         ("conv-created", "42", "ticket-created", "hello"))
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            conv = session.exec(select(DmConversation).where(
                DmConversation.account_id == account_id,
                DmConversation.conv_id == "conv-created")).one()
            self.assertEqual(task.status, "done")
            self.assertEqual(task.conv_id, "conv-created")
            self.assertEqual(conv.peer_uid, "123456")
            self.assertEqual(conv.peer_sec_uid, "target-sec")
            self.assertEqual(conv.conv_short_id, "42")
            self.assertEqual(conv.ticket, "ticket-created")
            self.assertEqual(json.loads(conv.raw_json)["self_uid"], "987654")

    def test_douyin_api_dm_resolves_visible_id_before_create(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.uid = "510601289795662"
            session.add(account)
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                target_uid="66790575681", content="你好", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = []

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def resolve_user_identifier(self, value):
                calls.append(("resolve", value))
                return ({
                    "uid": "3928976331901290",
                    "sec_uid": "MS4wLjABtarget",
                    "nickname": "HP惠普暗影精灵(直播版)",
                }, "")

            async def create_dm_conversation(self, *args, **kwargs):
                calls.append(("create", args, kwargs))
                return ({
                    "conv_id": "0:1:510601289795662:3928976331901290",
                    "conv_short_id": "7687444007923778105",
                    "conv_type": 1,
                    "ticket": "ticket-created",
                }, "")

            async def send_dm(self, *args, **kwargs):
                calls.append(("send", args, kwargs))
                return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.send_dm", AsyncMock(
                    side_effect=AssertionError("browser must not open"))):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(calls[0], ("resolve", "66790575681"))
        self.assertEqual(calls[1][1],
                         ("3928976331901290", "510601289795662"))
        self.assertEqual(calls[2][1][0],
                         "0:1:510601289795662:3928976331901290")
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.target_uid, "3928976331901290")
            self.assertEqual(task.target_sec_uid, "MS4wLjABtarget")
            self.assertEqual(task.target_nick, "HP惠普暗影精灵(直播版)")

    def test_douyin_hybrid_dm_resolution_failure_never_falls_back_or_sends(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.uid = "510601289795662"
            session.add(account)
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                target_uid="66790575681", content="你好", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "hybrid"
        browser = _BrowserStub()
        engine = MonitorEngine(self.cfg, browser)

        class FakeClient:
            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def resolve_user_identifier(self, value):
                self.value = value
                return None, "未找到完全匹配的抖音号"

            async def create_dm_conversation(self, *_args, **_kwargs):
                raise AssertionError("unresolved visible ID must not create")

            async def send_dm(self, *_args, **_kwargs):
                raise AssertionError("unresolved visible ID must not send")

        with patch("app.engine.monitor.DouyinClient", FakeClient), \
                patch("app.engine.monitor.send_dm", AsyncMock(
                    side_effect=AssertionError("must not browser-fallback"))):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertFalse(result["ok"])
        self.assertEqual(browser.identity_calls, 1)
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "failed")
            self.assertEqual(
                task.error,
                "target_resolution_failed:未找到完全匹配的抖音号")

    def test_douyin_api_dm_create_timeout_syncs_before_send(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.uid = "987654"
            session.add(account)
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                target_uid="123456", target_sec_uid="target-sec",
                content="hello", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = []

        class FakeClient:
            last_error = ""

            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def create_dm_conversation(self, *args, **kwargs):
                calls.append("create")
                return None, "write_uncertain:network:TimeoutError"

            async def fetch_dm_conversations(self):
                calls.append("sync")
                return [{
                    "conv_id": "conv-confirmed", "conv_short_id": "84",
                    "ticket": "ticket-confirmed", "peer_uid": "123456",
                    "peer_sec_uid": "target-sec", "peer_nickname": "visitor",
                }]

            async def send_dm(self, *args, **kwargs):
                calls.append("send")
                return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(calls, ["create", "sync", "send"])
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.conv_id, "conv-confirmed")

    def test_douyin_api_dm_repairs_existing_conversation_without_self_uid(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            session.add(DmConversation(
                account_id=account_id, platform="douyin",
                conv_id="conv-partial", peer_sec_uid="target-sec",
            ))
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                conv_id="conv-partial", target_sec_uid="target-sec",
                content="hello", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = []

        class FakeClient:
            last_error = ""

            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def fetch_dm_conversations(self):
                calls.append("sync")
                return [{
                    "conv_id": "conv-partial", "conv_short_id": "84",
                    "ticket": "ticket-repaired", "peer_uid": "123456",
                    "peer_sec_uid": "target-sec", "peer_nickname": "visitor",
                }]

            async def fetch_self_profile(self):
                raise AssertionError("existing conversations do not need self uid")

            async def create_dm_conversation(self, *_args, **_kwargs):
                raise AssertionError("existing conversations must not be recreated")

            async def send_dm(self, *args, **kwargs):
                calls.append(("send", args, kwargs))
                return True, ""

        with patch("app.engine.monitor.DouyinClient", FakeClient):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertTrue(result["ok"])
        self.assertEqual(calls[0], "sync")
        self.assertEqual(calls[1][0], "send")
        self.assertEqual(calls[1][1],
                         ("conv-partial", "84", "ticket-repaired", "hello"))
        with db.get_session() as session:
            conversation = session.exec(select(DmConversation).where(
                DmConversation.account_id == account_id,
                DmConversation.conv_id == "conv-partial")).one()
            self.assertEqual(conversation.peer_uid, "123456")
            self.assertEqual(conversation.conv_short_id, "84")
            self.assertEqual(conversation.ticket, "ticket-repaired")

    def test_douyin_api_dm_unconfirmed_create_timeout_stays_uncertain(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.uid = "987654"
            session.add(account)
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                target_uid="123456", target_sec_uid="target-sec",
                content="hello", status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())

        class FakeClient:
            last_error = ""

            def __init__(self, *_args, **_kwargs):
                pass

            @asynccontextmanager
            async def session_scope(self):
                yield self

            async def create_dm_conversation(self, *args, **kwargs):
                return None, "write_uncertain:network:TimeoutError"

            async def fetch_dm_conversations(self):
                return []

            async def send_dm(self, *args, **kwargs):
                raise AssertionError("unconfirmed create must not send")

        with patch("app.engine.monitor.DouyinClient", FakeClient):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertEqual(task.error,
                             "write_uncertain:network:TimeoutError")
            self.assertIsNone(task.scheduled_at)

    def test_douyin_api_dm_json_receipt_marks_task_done_without_browser(self):
        account_id = self._cookie_account()
        with db.get_session() as session:
            session.add(DmConversation(
                account_id=account_id, conv_id="conv-json",
                conv_short_id="42", ticket="ticket-json",
            ))
            task = AccountActionTask(
                platform="douyin", account_id=account_id, action="send_dm",
                conv_id="conv-json", target_uid="target", content="hello",
                status="pending",
            )
            session.add(task)
            session.commit()
            session.refresh(task)
            task_id = task.id
        self.cfg.engine.douyin_write_mode = "api"
        engine = MonitorEngine(self.cfg, _BrowserStub())
        session = AsyncMock()
        session.post.return_value = SimpleNamespace(
            status_code=200,
            content=b'{"cmd":100,"status_code":0,"error_desc":""}',
        )
        with patch("app.platforms.douyin.client.AsyncSession", return_value=session), \
                patch("app.engine.monitor.send_dm", AsyncMock(
                    side_effect=AssertionError("browser must not open"))):
            result = asyncio.run(engine.execute_action_task(task_id))
        self.assertTrue(result["ok"])
        self.assertEqual(session.post.await_count, 1)
        self.assertEqual(engine.browser.identity_calls, 0)
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "api")
            self.assertEqual(task.error, "")
            self.assertIsNotNone(task.done_at)

    def test_xhs_dm_uncertain_is_not_retried_or_recorded_as_risk_failure(self):
        account_id = self._account(platform="xhs")
        task_id = self._xhs_dm_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def ambiguous(*_args, **kwargs):
            kwargs["on_submit"]()
            with db.get_session() as session:
                self.assertEqual(
                    session.get(AccountActionTask, task_id).error,
                    "write_submitted:browser",
                )
            return False, "write_uncertain:发送后连接中断"

        with patch("app.engine.monitor.send_dm", ambiguous):
            result = asyncio.run(engine.execute_action_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(AccountActionTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertEqual(task.method, "browser")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNone(task.done_at)
            self.assertEqual(session.exec(select(RiskEvent)).all(), [])

    def test_publish_risk_response_returns_task_to_pending(self):
        account_id = self._account()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def rejected(*_args, **_kwargs):
            return False, "", "HTTP 429"

        with patch("app.engine.monitor.publish_douyin", rejected):
            result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "pending")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNotNone(task.next_allowed_at)
            self.assertGreater(task.next_allowed_at, datetime.utcnow())

    def test_publish_auth_expiry_keeps_task_pending_and_invalidates_account(self):
        account_id = self._account()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def logged_out(*_args, **_kwargs):
            return False, "", "logged_out"

        with patch("app.engine.monitor.publish_douyin", logged_out):
            result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            account = session.get(DouyinAccount, account_id)
            self.assertEqual(task.status, "pending")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNotNone(task.next_allowed_at)
            self.assertEqual(account.status, "invalid")

    def test_xhs_publish_uncertain_is_not_retried_or_recorded_as_done(self):
        account_id = self._account(platform="xhs")
        task_id = self._publish_task(account_id, platform="xhs")
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = []

        async def ambiguous(*_args, **kwargs):
            calls.append(kwargs)
            kwargs["on_submit"]()
            with db.get_session() as session:
                self.assertEqual(
                    session.get(PublishTask, task_id).error,
                    "write_submitted:browser")
            return False, "", "write_uncertain:发布后连接中断"

        with patch("app.engine.monitor.publish_xhs", ambiguous):
            result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        self.assertEqual(calls[0]["mode"], "browser")
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertIsNone(task.done_at)
            self.assertIsNone(task.scheduled_at)

    def test_xhs_api_submit_marker_prevents_replay_after_adapter_exception(self):
        self.cfg.engine.xhs_publish_mode = "api"
        account_id = self._account(platform="xhs")
        task_id = self._publish_task(account_id, platform="xhs")
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = []

        async def interrupted(*_args, **kwargs):
            calls.append(kwargs)
            kwargs["on_submit"]()
            with db.get_session() as session:
                self.assertEqual(session.get(PublishTask, task_id).error,
                                 "write_submitted:api")
            raise TimeoutError("connection timeout")

        with patch("app.engine.monitor.publish_xhs", interrupted):
            result = asyncio.run(engine.publish_task(task_id))
            replay = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        self.assertTrue(result["error"].startswith("write_uncertain:"))
        self.assertFalse(replay["ok"])
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["mode"], "api")
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertIsNone(task.done_at)
            self.assertIsNone(task.scheduled_at)
            self.assertIsNone(task.next_allowed_at)
            self.assertEqual(session.exec(select(RiskEvent)).all(), [])

    def test_xhs_api_pre_submit_network_failure_keeps_existing_backoff(self):
        self.cfg.engine.xhs_publish_mode = "api"
        account_id = self._account(platform="xhs")
        task_id = self._publish_task(account_id, platform="xhs")
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def interrupted(*_args, **_kwargs):
            raise TimeoutError("connection timeout")

        with patch("app.engine.monitor.publish_xhs", interrupted):
            result = asyncio.run(engine.publish_task(task_id))
        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "pending")
            self.assertGreater(task.next_allowed_at, datetime.utcnow())
            self.assertEqual([e.outcome for e in session.exec(select(RiskEvent)).all()],
                             ["network"])

    def test_xhs_api_cancellation_records_uncertain_and_releases_inflight_task(self):
        self.cfg.engine.xhs_publish_mode = "api"
        account_id = self._account(platform="xhs")
        task_id = self._publish_task(account_id, platform="xhs")
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def cancelled(*_args, **kwargs):
            kwargs["on_submit"]()
            raise asyncio.CancelledError()

        with patch("app.engine.monitor.publish_xhs", cancelled):
            with self.assertRaises(asyncio.CancelledError):
                asyncio.run(engine.publish_task(task_id))
        self.assertNotIn(task_id, engine._publishing)
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertIsNone(task.next_allowed_at)

    def test_xhs_api_structured_failure_reaches_risk_gate_before_text_serialization(self):
        from app.platforms.xhs.client import XhsApiError
        self.cfg.engine.xhs_publish_mode = "api"
        account_id = self._account(platform="xhs")
        task_id = self._publish_task(account_id, platform="xhs")
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def rejected(*_args, **kwargs):
            self.assertTrue(kwargs["preserve_error"])
            return False, "", XhsApiError("fixture", category="network", status_code=503)

        with patch("app.engine.monitor.publish_xhs", rejected):
            result = asyncio.run(engine.publish_task(task_id))
        self.assertEqual(result["error"], "fixture")
        self.assertIsInstance(result["error"], str)
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "pending")
            self.assertEqual(task.error, "fixture")
            self.assertGreater(task.next_allowed_at, datetime.utcnow())
            self.assertEqual([e.outcome for e in session.exec(select(RiskEvent)).all()],
                             ["network"])

    def test_xhs_api_lost_response_end_to_end_is_submitted_only_once(self):
        self.cfg.engine.xhs_publish_mode = "api"
        account_id = self._account(platform="xhs")
        task_id = self._publish_task(account_id, platform="xhs")
        media = Path(self.tmp.name) / "fixture.jpg"
        media.write_bytes(b"image fixture")
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.storage_state = '{"cookies":[{"name":"a1","value":"fixture"}]}'
            task = session.get(PublishTask, task_id)
            task.media_json = json.dumps([str(media)])
            task.visibility = "private"
            session.add(account)
            session.add(task)
            session.commit()
        engine = MonitorEngine(self.cfg, _BrowserStub())

        def response_lost(*_args, **kwargs):
            with db.get_session() as session:
                self.assertEqual(session.get(PublishTask, task_id).error,
                                 "write_submitted:api")
            payload = json.loads(kwargs["data"])
            self.assertEqual(payload["common"]["privacy_info"]["type"], 1)
            raise TimeoutError("connection timeout")

        with patch("app.platforms.xhs.creator_sign.available", return_value=True), \
                patch("app.platforms.xhs.creator_api.Session") as transport, \
                patch("app.platforms.xhs.creator_api.XhsCreatorApi.upload_media", return_value={
                    "fileIds": "fixture", "width": 10, "height": 20}), \
                patch("app.platforms.xhs.creator_sign.generate_xs_xs_common",
                      return_value=("xs", 123, "common")), \
                patch("app.platforms.xhs.creator_sign.generate_x_rap_param", return_value="rap"):
            transport.return_value.post.side_effect = response_lost
            result = asyncio.run(engine.publish_task(task_id))
            replay = asyncio.run(engine.publish_task(task_id))
            transport.assert_called_once()
            transport.return_value.post.assert_called_once()
            transport.return_value.close.assert_called_once()

        self.assertFalse(result["ok"])
        self.assertTrue(result["error"].startswith("write_uncertain:"))
        self.assertFalse(replay["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertEqual(session.exec(select(RiskEvent)).all(), [])

    def test_disabled_risk_controller_does_not_defer_rejected_publish(self):
        self.cfg.risk_control.enabled = False
        account_id = self._account()
        task_id = self._publish_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def rejected(*_args, **_kwargs):
            return False, "", "HTTP 429"

        with patch("app.engine.monitor.publish_douyin", rejected):
            result = asyncio.run(engine.publish_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(PublishTask, task_id)
            account = session.get(DouyinAccount, account_id)
            self.assertEqual(task.status, "failed")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNone(account.write_paused_until)

    def test_disabled_risk_controller_ignores_existing_compatibility_pause(self):
        account_id = self._account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.write_paused_until = datetime.utcnow() + timedelta(hours=1)
            account.write_pause_reason = "legacy risk pause"
            session.add(account)
            session.commit()
        self.cfg.risk_control.enabled = False
        engine = MonitorEngine(self.cfg, _BrowserStub())

        self.assertEqual(engine._write_pause_error(account_id), "")

    def test_comment_at_daily_cap_remains_queued(self):
        self.cfg.engine.comment_daily_cap_per_account = 1
        account_id = self._account()
        with db.get_session() as session:
            session.add(CommentTask(
                platform="douyin",
                account_id=account_id,
                aweme_id="already-sent",
                content="done",
                status="done",
                done_at=datetime.utcnow(),
            ))
            session.commit()
        task_id = self._comment_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "pending")
            self.assertIsNone(task.scheduled_at)
            self.assertIsNotNone(task.next_allowed_at)

    def test_startup_recovers_interrupted_write_tasks(self):
        account_id = self._account()
        now = datetime(2026, 8, 7, 1, 0, 0)
        with db.get_session() as session:
            comment = CommentTask(
                account_id=account_id, aweme_id="fixture", content="fixture",
                status="doing")
            action = AccountActionTask(
                account_id=account_id, action="follow", status="doing")
            publish = PublishTask(
                account_id=account_id, media_json="[]", status="publishing")
            submitted_comment = CommentTask(
                platform="xhs", account_id=account_id, aweme_id="submitted-note",
                content="submitted", status="doing",
                error="write_submitted:browser")
            submitted_publish = PublishTask(
                platform="xhs", account_id=account_id, media_json="[]",
                status="publishing", error="write_submitted:browser")
            submitted_action = AccountActionTask(
                platform="xhs", account_id=account_id, action="send_dm",
                target_uid="fixture-user", content="唯一消息", status="doing",
                error="write_submitted:browser")
            session.add(comment)
            session.add(action)
            session.add(publish)
            session.add(submitted_comment)
            session.add(submitted_publish)
            session.add(submitted_action)
            session.commit()
            comment_id, action_id, publish_id = comment.id, action.id, publish.id
            submitted_comment_id = submitted_comment.id
            submitted_publish_id = submitted_publish.id
            submitted_action_id = submitted_action.id

        engine = MonitorEngine(self.cfg, _BrowserStub())
        recovered = engine.recover_interrupted_tasks(now=now)

        self.assertEqual(recovered, 6)
        with db.get_session() as session:
            rows = [
                session.get(CommentTask, comment_id),
                session.get(AccountActionTask, action_id),
                session.get(PublishTask, publish_id),
            ]
            for row in rows:
                self.assertEqual(row.status, "uncertain")
                self.assertIsNone(row.scheduled_at)
            submitted_rows = [
                session.get(CommentTask, submitted_comment_id),
                session.get(PublishTask, submitted_publish_id),
                session.get(AccountActionTask, submitted_action_id),
            ]
            for row in submitted_rows:
                self.assertEqual(row.status, "uncertain")
                self.assertIsNone(row.scheduled_at)
                self.assertIn("重启", row.error)

    def test_legacy_active_window_check_uses_account_timezone(self):
        self.cfg.engine.quiet_hours_enabled = True
        account_id = self._account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.timezone_id = "America/New_York"
            session.add(account)
            session.commit()
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine.risk._in_active_window = (
            lambda account, _now: account.timezone_id == "America/New_York")

        self.assertTrue(engine._in_active_window(account_id))

    def test_legacy_daily_counter_uses_account_local_midnight(self):
        account_id = self._account()
        with db.get_session() as session:
            account = session.get(DouyinAccount, account_id)
            account.timezone_id = "America/New_York"
            session.add(account)
            session.commit()
        engine = MonitorEngine(self.cfg, _BrowserStub())
        expected = engine.risk._local_day_start_utc(
            engine._load_account(account_id), datetime.utcnow())

        self.assertEqual(engine._today_start(account_id), expected)

    def test_self_comment_filter_prefers_account_ids(self):
        raw = {"user": {"uid": "self-uid", "nickname": "changed"}}
        self.assertTrue(MonitorEngine._is_self_comment(
            raw, "old-name", acc_uid="self-uid"))
        self.assertFalse(MonitorEngine._is_self_comment(
            {"user": {"uid": "other", "nickname": "visitor"}},
            "owner", acc_uid="self-uid"))

    def test_rule_persists_source_text_for_strict_reply_targeting(self):
        account_id = self._account()
        with db.get_session() as session:
            rule = CommentRule(
                platform="douyin", mode="auto_reply", target_kind="self",
                account_id=account_id, templates='["收到啦"]',
                max_per_run=1, daily_cap=1, min_gap_seconds=60,
            )
            session.add(rule)
            session.commit()
            session.refresh(rule)
            rule_id = rule.id

        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def discover(*_args):
            return ([{
                "aweme_id": "fixture-work",
                "target_comment_id": "fixture-comment",
                "target_nick": "visitor",
                "source_text": "hello from visitor",
                "ctx": {"nick": "visitor"},
            }], "")

        engine._discover_targets = discover
        result = asyncio.run(engine.run_comment_rule(rule_id))

        self.assertTrue(result["ok"])
        with db.get_session() as session:
            task = session.exec(select(CommentTask).where(
                CommentTask.rule_id == rule_id)).one()
            self.assertEqual(task.target_text, "hello from visitor")

    def test_concurrent_comment_rule_discovery_rechecks_read_budget_in_lock(self):
        account_id = self._account()
        rule_ids = []
        with db.get_session() as session:
            for _ in range(2):
                rule = CommentRule(
                    platform="douyin", mode="auto_reply", target_kind="self",
                    account_id=account_id, templates='["ok"]',
                    max_per_run=1, daily_cap=10, min_gap_seconds=60,
                )
                session.add(rule)
                session.commit()
                session.refresh(rule)
                rule_ids.append(rule.id)
        engine = MonitorEngine(self.cfg, _BrowserStub())
        calls = 0

        async def discover(*_args):
            nonlocal calls
            calls += 1
            await asyncio.sleep(0.02)
            return [], ""

        engine._discover_targets = discover

        async def scenario():
            return await asyncio.gather(*(
                engine.run_comment_rule(rule_id) for rule_id in rule_ids))

        results = asyncio.run(scenario())

        self.assertEqual(calls, 1)
        self.assertEqual(sum(
            1 for result in results if result.get("next_allowed_at")), 1)

    def test_xhs_manual_mode_keeps_draft_without_api_call(self):
        account_id = self._account(platform="xhs")
        task_id = self._xhs_comment_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())
        engine.cfg.engine.xhs_comment_write_mode = "manual"

        def unexpected_api(*_args, **_kwargs):
            raise AssertionError("XHS direct comment API must stay disabled by default")

        engine._xhs_client = unexpected_api
        result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertFalse(result["ok"])
        self.assertIn("未调用评论发布接口", result["error"])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "draft")
            self.assertEqual(task.method, "manual")

    def test_xhs_comment_defaults_to_browser_page_write(self):
        from app.platforms.xhs.browser_writes import XhsWriteOutcome

        account_id = self._account(platform="xhs")
        task_id = self._xhs_comment_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        def unexpected_api(*_args, **_kwargs):
            raise AssertionError("default browser mode must not construct API client")

        engine._xhs_client = unexpected_api

        async def posted(*_args, **_kwargs):
            return XhsWriteOutcome("success", result="comment-fixture")

        with patch("app.engine.monitor.comment_xhs_browser", posted):
            result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertTrue(result["ok"])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "browser")
            self.assertEqual(task.result, "comment-fixture")

    def test_xhs_comment_uncertain_stops_without_retry(self):
        from app.platforms.xhs.browser_writes import XhsWriteOutcome

        account_id = self._account(platform="xhs")
        task_id = self._xhs_comment_task(account_id)
        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def ambiguous(*_args, **kwargs):
            kwargs["on_submit"]()
            with db.get_session() as session:
                self.assertEqual(
                    session.get(CommentTask, task_id).error,
                    "write_submitted:browser")
            return XhsWriteOutcome("uncertain", error="发送后连接中断")

        with patch("app.engine.monitor.comment_xhs_browser", ambiguous):
            result = asyncio.run(engine.execute_comment_task(task_id))

        self.assertFalse(result["ok"])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "uncertain")
            self.assertEqual(task.method, "browser")
            self.assertIsNone(task.done_at)
            self.assertIsNone(task.scheduled_at)

    def test_xhs_rule_creates_review_draft_then_auto_publishes_after_approval(self):
        self.cfg.engine.xhs_comment_write_mode = "api"
        account_id = self._account(platform="xhs")
        with db.get_session() as session:
            rule = CommentRule(
                platform="xhs", mode="auto_reply", target_kind="self",
                account_id=account_id, templates='["收到"]',
                max_per_run=1, daily_cap=1, min_gap_seconds=60,
            )
            session.add(rule)
            session.commit()
            session.refresh(rule)
            rule_id = rule.id

        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def discover(*_args):
            return ([{
                "aweme_id": "fixture-note",
                "target_comment_id": "fixture-comment",
                "target_nick": "visitor",
                "source_text": "hello from visitor",
                "ctx": {"nick": "visitor"},
            }], "")

        engine._discover_targets = discover
        result = asyncio.run(engine.run_comment_rule(rule_id))

        self.assertTrue(result["ok"])
        self.assertTrue(result["review"])
        self.assertFalse(result["manual_only"])
        with db.get_session() as session:
            task = session.exec(select(CommentTask).where(
                CommentTask.rule_id == rule_id)).one()
            self.assertEqual(task.status, "draft")
            task_id = task.id
            task.status = "pending"  # fixture:等价于人工点击“通过”
            session.add(task)
            session.commit()

        class _XhsClientStub:
            async def post_comment(self, *_args, **_kwargs):
                return {"comment": {"id": "fixture-sent"}}

        engine._xhs_client = lambda *_args, **_kwargs: _XhsClientStub()
        deferred = asyncio.run(engine.execute_comment_task(task_id))
        self.assertFalse(deferred["ok"])
        # A completed discovery read also paces the subsequent approved write.
        with db.get_session() as session:
            state = session.get(AccountRiskState, account_id)
            state.operation_not_before = datetime.utcnow() - timedelta(seconds=1)
            task = session.get(CommentTask, task_id)
            task.next_allowed_at = state.operation_not_before
            session.add(state); session.add(task); session.commit()
        sent = asyncio.run(engine.execute_comment_task(task_id))
        self.assertTrue(sent["ok"])
        with db.get_session() as session:
            task = session.get(CommentTask, task_id)
            self.assertEqual(task.status, "done")
            self.assertEqual(task.method, "api")

    def test_xhs_review_switch_false_enqueues_automatic_publish(self):
        self.cfg.engine.xhs_comment_review_before_publish = False
        account_id = self._account(platform="xhs")
        with db.get_session() as session:
            rule = CommentRule(
                platform="xhs", mode="auto_reply", target_kind="self",
                account_id=account_id, templates='["收到"]',
                max_per_run=1, daily_cap=1, min_gap_seconds=60,
            )
            session.add(rule)
            session.commit()
            session.refresh(rule)
            rule_id = rule.id

        engine = MonitorEngine(self.cfg, _BrowserStub())

        async def discover(*_args):
            return ([{
                "aweme_id": "fixture-note",
                "target_comment_id": "fixture-comment",
                "target_nick": "visitor",
                "source_text": "hello from visitor",
                "ctx": {"nick": "visitor"},
            }], "")

        engine._discover_targets = discover
        result = asyncio.run(engine.run_comment_rule(rule_id))
        self.assertTrue(result["ok"])
        self.assertFalse(result["review"])
        with db.get_session() as session:
            task = session.exec(select(CommentTask).where(
                CommentTask.rule_id == rule_id)).one()
            self.assertEqual(task.status, "pending")


if __name__ == "__main__":
    unittest.main()
