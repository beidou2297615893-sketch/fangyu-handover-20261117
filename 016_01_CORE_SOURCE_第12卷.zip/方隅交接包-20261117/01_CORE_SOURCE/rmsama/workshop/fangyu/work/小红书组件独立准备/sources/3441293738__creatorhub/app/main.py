"""FastAPI 入口。对应逆向 cmd/server/main.go + internal/router。"""
from __future__ import annotations

import asyncio
import hashlib
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
import uuid
from contextlib import asynccontextmanager
from ipaddress import ip_address
from pathlib import Path
from typing import Any, Dict
from urllib.parse import urlencode, urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from datetime import date, datetime, time, timedelta, timezone
import uuid as _uuid

from fastapi import Body, FastAPI, HTTPException, Request, UploadFile, File
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field as PydanticField, StrictInt, ValidationError
from sqlalchemy import delete, func, or_, update
from sqlmodel import select

from .browser import (BrowserManager, cookie_string_to_state,
                      interactive_login, interactive_creator_login,
                      interactive_xhs_login, interactive_xhs_creator_login,
                      interactive_ks_login, interactive_ks_creator_login,
                      interactive_channels_login, interactive_channels_creator_login,
                      fetch_self_profile, fetch_xhs_self_profile,
                      fetch_xhs_note_detail, fetch_xhs_comments,
                       fetch_xhs_favorite_boards,
                      fetch_ks_self_profile,
                      fetch_channels_self_profile,
                      fetch_account_works, fetch_follows, fetch_dm_conversations,
                      fetch_dm_history, fetch_douyin_account_works_api)
from .browser.backends import (
    ACCOUNT_BROWSER_BACKENDS, LOCAL_BACKEND, fingerprint_seed_u32,
    parse_extra_launch_args,
)
from .browser.ip_fingerprint import derive_ip_fingerprint
from .browser.runtime_catalog import (
    discover_chromium_runtimes,
    runtime_metadata,
)
from .platforms.douyin import (
    DouyinClient,
    cookie_from_state as douyin_cookie_from_state,
    parse_aweme,
    parse_danmaku,
    parse_self_user,
    safe_title,
)
from .config import load_config
from .db import get_session, init_db
from .account_merge import (
    cleanup_merged_profiles,
    duplicate_xhs_account_ids,
    reconcile_xhs_accounts,
)
from .account_lifecycle import active_account_task, retire_account_tasks
from .platforms.douyin import resolve_sec_uid, resolve_aweme_id, looks_like_video
from .platforms.xhs import (resolve_note as xhs_resolve_note,
                  resolve_user as xhs_resolve_user,
                  looks_like_note as xhs_looks_like_note,
                  parse_self_user as parse_xhs_self_user,
                  XhsApiClient, XhsApiError, cookie_str_from_state, has_a1,
                  has_creator_cookies)
from .platforms.kuaishou import (resolve_ks_user_id, resolve_ks_photo_id,
                  looks_like_photo as ks_looks_like_photo,
                  parse_self_user as parse_ks_self_user,
                  MANAGE_URL as KS_MANAGE_URL)
from .platforms.channels import parse_self_user as parse_channels_self_user
from .engine import Downloader, MonitorEngine
from .engine.share_downloader import (
    clean_platform_share_target,
    ShareDownloadError,
    ShareDownloader,
    ShareLinkError,
    detect_platform,
    extract_share_urls,
    normalize_share_text,
    require_share_urls,
)
from .models import (ContentRecord, CommentRecord, CommentRule, CommentTask,
                     CommentWatch, DanmakuWatch, DanmakuRecord,
                     DouyinAccount, MonitorTarget,
                     NotificationChannel, ProxyPool, BrowserRuntime, PublishTask,
                     AccountWork, FollowEdge, DmConversation, DmMessage,
                      DmAutoReplyRule, DmMonitorState,
                      AccountActionTask, AccountStatSnapshot,
                      ShareDownloadRecord, AccountRiskState, RiskEvent, RiskAdminAudit,
                      KeywordCollectionJob, KeywordCollectionContent,
                       KeywordCollectionComment, AccountOperationLog,
                       GroupConversation, GroupMember, GroupSnapshot,
                       GroupMemberEvent, LiveLead, WebhookSubscription,
                       WebhookEvent)
from .event_center import dispatch_event, dispatch_pending, emit_event
from .group_snapshots import ingest_group_snapshot
from .operations import record_account_operation
from .notifier import CHANNEL_TYPES, send_one
from .profiles import (allocate_profile_dir, ensure_identity, migrate_identities,
                       assign_proxy_from_pool,
                       release_proxy_reservation, reserve_proxy_from_pool,
                       seed_proxy_pool)
from .risk import (OperationKind, RiskCategory, RiskController,
                   classify_platform_error)
from .risk_admin import (RiskSettingsError, apply_risk_settings,
                         export_risk_settings, load_persisted_risk_settings,
                         save_risk_settings)
from .settings import get_setting, set_setting
from .engine_settings import (EngineSettingsPatch, export_engine_settings,
                              load_persisted_engine_settings, save_engine_settings)
from .transport_matrix import (
    build_transport_matrix,
    douyin_client_environment,
    resolve_transport,
)
from .scheduling import parse_schedule, utc_iso
from .engine.cadence import row_deadline
from .local_access import LocalAccessMiddleware
from .submissions import submit_once, replay_if_exists
from .notification_config import parse_config, redact_config, merge_config, redact_detail
from .windowing import (CHROMIUM_WINDOW_CLASSES, EXPLORER_WINDOW_CLASSES,
                        bring_window_to_front,
                        capture_window_snapshot)

import json

cfg = load_config()
browser: BrowserManager | None = None
engine: MonitorEngine | None = None
im_receiver = None      # ImReceiverManager(私信实时接收)
login_tasks: Dict[str, dict] = {}
# 用户手动打开的账号浏览器窗口(account_id -> BrowserContext),留引用防 GC、便于复用/清理
open_browsers: Dict[int, Any] = {}
_file_manager_lock = threading.Lock()
_share_download_sem = asyncio.Semaphore(2)
_follow_sync_jobs: Dict[str, dict] = {}
_follow_sync_tasks: Dict[str, asyncio.Task] = {}
_webhook_delivery_task: asyncio.Task | None = None


_ACTIVE_LOGIN_STATUSES = {"opening", "waiting", "verification", "persisted"}


def _login_task_state(*, status: str, platform: str,
                      creator: bool, account_id: int | None,
                      **details) -> dict:
    """Build a login task update without dropping its conflict metadata."""
    return {
        "status": status,
        "platform": platform,
        "creator": bool(creator),
        "account_id": account_id,
        **details,
    }


def _active_login_task() -> tuple[str, dict] | None:
    """Return the most recently started interactive login that still owns a window."""
    for task_id, state in reversed(list(login_tasks.items())):
        if str(state.get("status") or "") in _ACTIVE_LOGIN_STATUSES:
            return task_id, state
    return None


def _active_open_browser_account_ids() -> list[int]:
    return [
        account_id for account_id, lease in open_browsers.items()
        if bool(getattr(lease, "active", True))
    ]


def _login_scope_label(platform: str, creator: bool) -> str:
    label = {
        "xhs": "小红书",
        "kuaishou": "快手",
        "shipinhao": "视频号",
        "douyin": "抖音",
    }.get(platform, platform or "平台")
    return f"{label}创作者" if creator else label


async def _reuse_or_reject_interactive_login(
        platform: str, creator: bool, account_id: int | None = None,
) -> dict | None:
    """Refocus duplicate login clicks; reject a different login instead of queueing forever."""
    open_account_ids = _active_open_browser_account_ids()
    if open_account_ids:
        account_text = "、".join(str(value) for value in open_account_ids[:4])
        raise HTTPException(
            409,
            "已有账号浏览器窗口打开"
            f"（账号 {account_text}），扫码登录会被可见窗口队列阻塞。"
            "请先关闭已打开的指纹浏览器窗口，再点击添加账号。",
        )

    active = _active_login_task()
    if active is None:
        return None
    task_id, state = active
    same_login = (
        str(state.get("platform") or "") == platform
        and bool(state.get("creator")) == bool(creator)
        and state.get("account_id") == account_id
    )
    if not same_login:
        active_label = _login_scope_label(
            str(state.get("platform") or ""), bool(state.get("creator")))
        raise HTTPException(
            409,
            f"已有{active_label}扫码登录窗口正在等待操作。"
            "请先在该窗口完成登录或将其关闭，再启动新的登录。",
        )

    # A repeated click usually means the existing Chromium window is behind the
    # dashboard. Raise it instead of creating a second task that waits forever.
    snapshot = capture_window_snapshot(CHROMIUM_WINDOW_CLASSES)
    title_hint = _login_scope_label(platform, creator).replace("创作者", "")
    await asyncio.to_thread(
        bring_window_to_front, snapshot, CHROMIUM_WINDOW_CLASSES,
        title_hint, 1.0,
    )
    return {
        "task_id": task_id,
        "status": state.get("status", "waiting"),
        "reused": True,
        "hint": "已有扫码登录窗口，已尝试将它切换到前台",
    }


class _OpenBrowserLease:
    """Keep the unified account/network guard until a headed context closes."""

    def __init__(self, context, guard, close_callback=None, page=None):
        self.context = context
        self.guard = guard
        self.close_callback = close_callback
        self.page = page
        self._released = False
        self._closed = False
        self._release_lock = asyncio.Lock()
        self._close_lock = asyncio.Lock()

    @property
    def active(self) -> bool:
        return not self._released and not self._closed

    async def release(self) -> None:
        async with self._release_lock:
            if self._released:
                return
            self._released = True
            await self.guard.__aexit__(None, None, None)

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closed = True
            try:
                if self.close_callback is not None:
                    await self.close_callback()
                else:
                    await self.context.close()
            finally:
                await self.release()


async def _release_open_browser(account_id: int, lease: _OpenBrowserLease) -> None:
    try:
        await lease.close()
    finally:
        if open_browsers.get(account_id) is lease:
            open_browsers.pop(account_id, None)


def _persist_native_ua(account_id: int, ua: str) -> None:
    """Persist the UA observed from an account's native Chromium context."""
    value = str(ua or "").strip()
    if not account_id or not value:
        return
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account and account.identity_mode == "native" and account.ua != value:
            account.ua = value
            session.add(account)
            session.commit()


def _browser_backend_status(requested: str, runtime_id: str = "") -> dict:
    """Call the runtime-aware manager while keeping lightweight test adapters."""
    checker = browser.backend_status
    try:
        return checker(requested, runtime_id)
    except TypeError:
        return checker(requested)


def _browser_runtime_dict(runtime: BrowserRuntime) -> dict:
    path = Path(runtime.executable_path)
    return {
        "id": runtime.id,
        "runtime_id": runtime.runtime_id,
        "name": runtime.name,
        "backend": runtime.backend,
        "version": runtime.version,
        "major": (runtime.version.split(".", 1)[0]
                  if runtime.version else ""),
        "executable_path": runtime.executable_path,
        "platform": runtime.platform,
        "allow_headless": runtime.allow_headless,
        "enabled": runtime.enabled,
        "is_default": runtime.is_default,
        "status": runtime.status,
        "last_error": runtime.last_error,
        "available": path.is_file(),
        "file_sha256": runtime.file_sha256,
        "last_checked_at": (runtime.last_checked_at.isoformat()
                            if runtime.last_checked_at else None),
        "created_at": (runtime.created_at.isoformat()
                       if runtime.created_at else None),
    }


def _browser_runtime_executable_candidates() -> list[str]:
    """Return explicitly configured executable paths without assuming a drive."""
    values = [
        str(cfg.engine.fingerprint_chromium_path or "").strip(),
        os.environ.get("CREATORHUB_FINGERPRINT_CHROMIUM_PATH", "").strip(),
    ]
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        normalized = os.path.normcase(str(Path(value).expanduser().resolve()))
        if normalized not in seen:
            seen.add(normalized)
            result.append(value)
    return result


def _browser_runtime_scan_roots() -> list[str]:
    """Resolve configured, environment and portable project-local scan roots."""
    values: list[str] = []
    configured = str(cfg.engine.fingerprint_chromium_root or "").strip()
    if configured:
        values.append(configured)
    env_roots = os.environ.get(
        "CREATORHUB_FINGERPRINT_CHROMIUM_ROOTS", "").strip()
    if env_roots:
        values.extend(part.strip() for part in env_roots.split(os.pathsep))
    # Portable deployments can put browser archives beside or inside the
    # project. Only existing narrow directories are considered; no disk-wide
    # scan is performed.
    workspace = Path.cwd()
    for candidate in (
        workspace / "browsers",
        workspace / "browser",
        workspace / "data" / "browsers",
        workspace.parent / "browsers",
    ):
        if candidate.is_dir():
            values.append(str(candidate))
    for executable in _browser_runtime_executable_candidates():
        path = Path(executable).expanduser()
        if path.parent.is_dir():
            values.append(str(path.parent))

    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        resolved = str(Path(value).expanduser().resolve())
        normalized = os.path.normcase(resolved)
        if normalized not in seen:
            seen.add(normalized)
            result.append(resolved)
    return result


def _seed_browser_runtimes() -> list[dict]:
    """Import configured/discovered runtimes and return manager specifications."""
    discovered: dict[str, dict] = {}
    configured_paths = _browser_runtime_executable_candidates()
    for configured_path in configured_paths:
        try:
            item = runtime_metadata(configured_path)
            discovered[item["runtime_id"]] = item
        except (OSError, ValueError) as exc:
            print(f"[startup] 指纹内核路径不可用: {exc}")
    for root in _browser_runtime_scan_roots():
        try:
            for item in discover_chromium_runtimes(root):
                discovered[item["runtime_id"]] = item
        except (OSError, ValueError) as exc:
            print(f"[startup] 指纹内核扫描失败 ({root}): {exc}")

    with get_session() as session:
        existing = {
            row.runtime_id: row
            for row in session.exec(select(BrowserRuntime)).all()
        }
        configured_runtime_id = ""
        for runtime_id, item in discovered.items():
            row = existing.get(runtime_id)
            if row is None:
                row = BrowserRuntime(
                    runtime_id=runtime_id,
                    name=item["name"],
                    version=item["version"],
                    executable_path=item["executable_path"],
                    platform=cfg.engine.fingerprint_chromium_platform,
                    allow_headless=cfg.engine.fingerprint_chromium_allow_headless,
                    file_sha256=item["file_sha256"],
                )
                session.add(row)
                existing[runtime_id] = row
            else:
                row.version = item["version"]
                row.executable_path = item["executable_path"]
                row.file_sha256 = item["file_sha256"]
                if not row.name:
                    row.name = item["name"]
                session.add(row)
            if any(os.path.normcase(item["executable_path"])
                   == os.path.normcase(str(Path(path).expanduser().resolve()))
                   for path in configured_paths):
                configured_runtime_id = runtime_id
        session.commit()

        rows = session.exec(select(BrowserRuntime).order_by(BrowserRuntime.id)).all()
        default = next(
            (row for row in rows if row.is_default and row.enabled), None)
        if default is None:
            default = next(
                (row for row in rows
                 if row.runtime_id == configured_runtime_id and row.enabled), None)
        if default is None:
            default = next((row for row in rows if row.enabled), None)
        if default is not None:
            for row in rows:
                wanted = row.id == default.id
                if row.is_default != wanted:
                    row.is_default = wanted
                    session.add(row)
            session.commit()
        return [_browser_runtime_dict(row) for row in rows]


@asynccontextmanager
async def lifespan(app: FastAPI):
    global browser, engine, im_receiver, _webhook_delivery_task
    init_db(cfg.db_path)
    try:
        with get_session() as session:
            merged_accounts = reconcile_xhs_accounts(session)
        if merged_accounts:
            cleanup_merged_profiles(merged_accounts, cfg.engine.profiles_dir)
            print(
                f"[startup] 已自动合并 {len(merged_accounts)} 条重复的小红书登录记录")
    except Exception as e:
        print(f"[startup] 小红书账号自动合并失败(不影响启动): {e!r}")
    if load_persisted_risk_settings(cfg):
        print("[startup] 已加载风控中心保存的运行时规则")
    if load_persisted_engine_settings(cfg):
        print("[startup] 已加载设置页保存的采集与运行配置")
    try:
        repaired = _backfill_danmaku_records()
        if repaired:
            print(f"[startup] 已补齐 {repaired} 条弹幕的时间/用户字段")
    except Exception as e:
        print(f"[startup] 弹幕存量字段补齐失败（不影响启动）: {e!r}")
    try:
        restored = _backfill_share_download_history()
        if restored:
            print(f"[startup] 已从本地下载目录补录 {restored} 条链接下载历史")
    except Exception as e:
        print(f"[startup] 链接下载历史补录失败（不影响启动）: {e!r}")
    # config.yaml 里配的 proxies 导入数据库代理池(之后统一在页面管理)
    try:
        seeded = seed_proxy_pool(cfg)
        if seeded:
            print(f"[startup] 已从 config.yaml 导入 {seeded} 条代理到代理池")
    except Exception as e:
        print(f"[startup] 代理池导入失败(不影响启动): {e!r}")
    # 存量账号补齐设备/网络画像(profile_dir / UA / 指纹 / 代理),防多账号关联
    try:
        n = migrate_identities(cfg)
        if n:
            print(f"[startup] 已为 {n} 个存量账号补齐画像(profile/UA/指纹/代理)")
    except Exception as e:
        print(f"[startup] 账号画像迁移失败(不影响启动): {e!r}")
    try:
        runtime_specs = _seed_browser_runtimes()
    except Exception as e:
        print(f"[startup] 浏览器内核目录导入失败(不影响启动): {e!r}")
        runtime_specs = []
    default_runtime_id = next(
        (item["runtime_id"] for item in runtime_specs
         if item.get("is_default") and item.get("enabled")), "")
    browser = BrowserManager(
        cfg.engine.user_agent, cfg.engine.profiles_dir,
        cfg.engine.max_live_contexts, native_ua_callback=_persist_native_ua,
        xhs_browser_mode=cfg.engine.xhs_browser_mode,
        xhs_cdp_idle_seconds=cfg.engine.xhs_cdp_idle_seconds,
        resident_sessions=cfg.engine.resident_browser_sessions,
        session_idle_seconds=cfg.engine.browser_session_idle_seconds,
        native_write_gate_enabled=cfg.engine.native_write_gate_enabled,
        native_write_require_system_chrome=cfg.engine.native_write_require_system_chrome,
        native_write_require_verified_proxy=cfg.engine.native_write_require_verified_proxy,
        native_write_proxy_max_age_seconds=cfg.engine.native_write_proxy_max_age_seconds,
        browser_exit_probe_url=cfg.engine.browser_exit_probe_url,
        browser_backend=cfg.engine.browser_backend,
        fingerprint_chromium_path=(
            "" if runtime_specs else cfg.engine.fingerprint_chromium_path),
        fingerprint_chromium_allow_headless=(
            cfg.engine.fingerprint_chromium_allow_headless),
        fingerprint_chromium_platform=(
            cfg.engine.fingerprint_chromium_platform),
        fingerprint_chromium_runtimes=runtime_specs,
        fingerprint_default_runtime_id=default_runtime_id)
    await browser.start()
    engine = MonitorEngine(cfg, browser)
    startup_now = datetime.utcnow()
    pruned_risk_events = engine._prune_risk_events_if_due(startup_now)
    if pruned_risk_events:
        print(f"[startup] 已清理 {pruned_risk_events} 条过期风控事件")
    recovered = engine.recover_interrupted_tasks()
    if recovered:
        print(f"[startup] 已恢复 {recovered} 条中断的写任务")
    engine.start()
    from .engine.im_receiver import ImReceiverManager
    im_receiver = ImReceiverManager(browser)
    publisher = getattr(im_receiver, "publish", None)
    if callable(publisher):
        engine.set_dm_event_sink(publisher)
    async def webhook_delivery_loop():
        while True:
            try:
                await dispatch_pending(20)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                print(f"[webhook] 事件投递循环异常: {exc!r}")
            await asyncio.sleep(15)
    _webhook_delivery_task = asyncio.create_task(webhook_delivery_loop())
    yield
    if _webhook_delivery_task:
        _webhook_delivery_task.cancel()
        await asyncio.gather(_webhook_delivery_task, return_exceptions=True)
        _webhook_delivery_task = None
    follow_tasks = [task for task in _follow_sync_tasks.values()
                    if not task.done()]
    for task in follow_tasks:
        task.cancel()
    if follow_tasks:
        await asyncio.gather(*follow_tasks, return_exceptions=True)
    if im_receiver:
        await im_receiver.stop_all()
    if engine:
        await engine.stop()
    if browser:
        await browser.stop()


app = FastAPI(title="CreatorHub", lifespan=lifespan)
app.add_middleware(LocalAccessMiddleware)
WEB_DIR = Path(__file__).parent / "web"


def _xhs_browser_reads_enabled() -> bool:
    """Whether the configured browser implementation supports page reads."""
    return bool(
        cfg.engine.xhs_read_mode == "browser"
        and browser is not None
        and callable(getattr(browser, "visible_page", None))
    )


def _direct_request_ua(identity) -> str:
    resolver = getattr(browser, "direct_request_user_agent", None)
    if callable(resolver):
        return resolver(identity)
    return str(getattr(identity, "ua", "") or cfg.engine.user_agent)


# ─────────── 扫码登录(真实浏览器) ───────────
def _storage_has_cookie(state: str, name: str) -> bool:
    try:
        cookies = json.loads(state or "{}").get("cookies") or []
    except (TypeError, ValueError, json.JSONDecodeError):
        return False
    return any(
        str(item.get("name") or "") == name
        and bool(str(item.get("value") or ""))
        for item in cookies if isinstance(item, dict)
    )


def _xhs_has_read_login_state(state: str) -> bool:
    """Main-site XHS reads require web_session; creator cookies are separate."""
    return _storage_has_cookie(state, "web_session")


async def _xhs_profile(state: str, proxy: str = "", *,
                       detailed: bool = False, user_agent: str = ""):
    """用签名直连 API 拿小红书账号资料(me 身份 + otherinfo 昵称/头像/粉丝)。
    返回 (user dict, error)。error == "logged_out" 表示登录态失效。"""
    cookie_str = cookie_str_from_state(state)
    if not has_a1(cookie_str):
        return {}, "logged_out"
    client = XhsApiClient(cookie_str, user_agent or cfg.engine.user_agent,
                          timeout=cfg.engine.request_timeout_seconds, proxy=proxy)
    try:
        me = await client.self_info()
    except XhsApiError as exc:
        if detailed:
            return {}, exc
        return {}, "logged_out" if exc.category == "auth" else exc.category
    except Exception as e:
        print(f"[xhs_profile] self_info 失败: {e!r}")
        return ({}, e) if detailed else ({}, "error")
    if not me or me.get("guest") is True or not me.get("user_id"):
        return {}, "logged_out"
    merged = dict(me)
    try:
        other = await client.user_info(me["user_id"])
        if other:
            merged = {**other, **me}      # me 提供身份,otherinfo 提供 basic_info/粉丝
    except Exception as exc:
        category, _signal = classify_platform_error(exc)
        if detailed and category in {
                RiskCategory.RISK, RiskCategory.AUTH, RiskCategory.NETWORK}:
            return {}, exc
    return merged, ""


async def _fetch_channels_profile_with_retry(identity, attempts: int = 3) -> tuple[dict, str]:
    """视频号扫码后的会话传播窗口内重试，避免一次跳登录页就误判失效。"""
    result: tuple[dict, str] = ({}, "logged_out")
    for attempt in range(max(1, attempts)):
        if attempt:
            await asyncio.sleep(1.5 * attempt)
        result = await fetch_channels_self_profile(browser, identity)
        profile, error = result
        if profile or error != "logged_out":
            break
    return result


async def _run_account_read(account_id: int, kind: OperationKind, key: str,
                            operation, *, empty_result,
                            unexpected_detail: str = "",
                            allow_invalid_probe: bool = False):
    """Run one account-bound API read through the engine's unified gates."""
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    guarded_empty = empty_result
    if unexpected_detail and isinstance(empty_result, dict):
        guarded_empty = dict(empty_result)
        guarded_empty["_guard_error"] = True
    payload, error = await engine.guarded_read_pair(
        account_id, kind, key, operation, empty_result=guarded_empty,
        allow_invalid_probe=allow_invalid_probe)
    guard_error = False
    if isinstance(payload, dict):
        payload = dict(payload)
        guard_error = bool(payload.pop("_guard_error", False))
    error_text = str(error or "")
    if error_text.startswith("risk_deferred:"):
        deferred = ({key: value for key, value in empty_result.items()
                     if not str(key).startswith("_")}
                    if isinstance(empty_result, dict) else {})
        deferred.update({
            "skipped": True,
            "reason": error_text.split(":", 1)[-1],
        })
        return None, deferred
    if unexpected_detail and guard_error and error:
        raise HTTPException(500, unexpected_detail)
    return (payload, None) if not error else (payload, error_text)


async def _enrich_account_profile(account_id: int, state: str, *,
                                  detailed: bool = False):
    """用登录态拉取账号资料；默认返回旧的状态字符串，详细模式附带原始错误。"""
    def _done(status: str, error=""):
        return (status, error) if detailed else status

    if not state:
        return _done("error", "error")
    with get_session() as s:
        a0 = s.get(DouyinAccount, account_id)
        if not a0:
            return _done("error", "error")
        platform = a0.platform
        creator_state = a0.creator_storage_state if a0 else ""
        proxy = (a0.proxy or "") if a0 else ""
        dy_transport = (resolve_transport(cfg, "douyin", "account_profile", a0)
                        if platform == "douyin" else None)
        identity = (None if dy_transport and
                    dy_transport["effective_mode"] == "api"
                    else browser.identity_for(a0) if browser is not None else None)

    if platform != "douyin" and browser is None:
        return _done("error", "browser_unavailable")

    # XHS 创作者号:用创作平台「我的信息」拿资料 + 判活(www 接口对创作态拿不到)
    if platform == "xhs" and creator_state:
        from .platforms.xhs import creator_profile, creator_check
        profile_error = ""
        if detailed:
            prof, profile_error = await creator_profile(
                creator_state, proxy=proxy, preserve_error=True)
        else:
            prof = await creator_profile(creator_state, proxy=proxy)
        if prof and (prof.get("nickname") or prof.get("douyin_id")):
            with get_session() as s:
                acc = s.get(DouyinAccount, account_id)
                if acc:
                    if prof.get("nickname"):
                        acc.nickname = prof["nickname"]
                    acc.sec_uid = prof.get("sec_uid") or acc.sec_uid
                    acc.douyin_id = prof.get("douyin_id") or acc.douyin_id
                    acc.avatar = prof.get("avatar") or acc.avatar
                    acc.follower_count = prof.get("follower_count") or acc.follower_count
                    acc.aweme_count = prof.get("aweme_count") or acc.aweme_count
                    acc.status = "active"
                    s.add(acc); s.commit()
            return _done("ok")
        if profile_error:
            category, _signal = classify_platform_error(profile_error)
            if category in {
                    RiskCategory.RISK, RiskCategory.AUTH,
                    RiskCategory.NETWORK}:
                status = "invalid" if category == RiskCategory.AUTH else "error"
                return _done(status, profile_error)
        check_error = ""
        if detailed:
            chk, check_error = await creator_check(
                creator_state, proxy=proxy, preserve_error=True)
        else:
            chk = await creator_check(creator_state, proxy=proxy)
        if chk is True:
            with get_session() as s:
                acc = s.get(DouyinAccount, account_id)
                if acc:
                    acc.status = "active"
                    s.add(acc); s.commit()
            return _done("ok")
        if check_error:
            category, _signal = classify_platform_error(check_error)
            if category in {
                    RiskCategory.RISK, RiskCategory.AUTH,
                    RiskCategory.NETWORK}:
                status = "invalid" if category == RiskCategory.AUTH else "error"
                return _done(status, check_error)
        if chk is None:
            return _done("error", check_error or profile_error or "error")
        with get_session() as s:
            acc = s.get(DouyinAccount, account_id)
            if acc:
                acc.status = "invalid"
                s.add(acc); s.commit()
        return _done("invalid", check_error or "logged_out")

    try:
        if platform == "xhs":
            # Default to the account browser so profile checks keep the same
            # UA/TLS/Client-Hints/profile that created the login cookies.
            if _xhs_browser_reads_enabled():
                u, err = await fetch_xhs_self_profile(browser, identity)
            else:
                u, err = await _xhs_profile(
                    state, proxy, detailed=detailed,
                    user_agent=_direct_request_ua(identity))
        elif platform == "kuaishou":
            u, err = await fetch_ks_self_profile(browser, identity)
        elif platform == "shipinhao":
            # 视频号扫码授权后，服务端会话偶尔要数秒才在新页面中生效。
            # 单次打开被重定向到登录页不能立即把刚添加的账号判为失效。
            u, err = await _fetch_channels_profile_with_retry(identity)
        else:
            mode = dy_transport["effective_mode"]
            u, err = None, ""
            if mode in {"api", "hybrid"}:
                cookie = douyin_cookie_from_state(state)
                if not cookie:
                    err = "api_missing_cookie"
                else:
                    try:
                        client = DouyinClient(
                            cookie, a0.ua or cfg.engine.user_agent,
                            timeout=cfg.engine.request_timeout_seconds,
                            proxy=proxy, **douyin_client_environment(a0))
                        async with client.session_scope():
                            u = await client.fetch_self_profile()
                            if not u and a0.sec_uid:
                                u = await client.fetch_profile(a0.sec_uid)
                        err = client.last_error or ("" if u else "empty_response")
                    except Exception as exc:
                        err = exc
            if not u and mode == "hybrid":
                if browser is None:
                    return _done("error", err or "browser_unavailable")
                u, browser_err = await fetch_self_profile(browser, identity)
                err = browser_err or err
            elif not u and mode == "browser":
                if browser is None:
                    return _done("error", "browser_unavailable")
                u, err = await fetch_self_profile(browser, identity)
    except Exception as exc:
        category, _signal = classify_platform_error(exc)
        status = "invalid" if detailed and category == RiskCategory.AUTH else "error"
        return _done(status, exc)
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            return _done("error", "error")
        if u:
            if platform == "xhs":
                p = parse_xhs_self_user(u)
            elif platform == "kuaishou":
                p = parse_ks_self_user(u)
            elif platform == "shipinhao":
                p = parse_channels_self_user(u)
            else:
                p = parse_self_user(u)
            if p.get("nickname"):
                acc.nickname = p["nickname"]
            acc.sec_uid = p.get("sec_uid") or acc.sec_uid
            acc.douyin_id = p.get("douyin_id") or acc.douyin_id
            acc.avatar = p.get("avatar") or acc.avatar
            if platform == "kuaishou":
                # 快手资料接口会明确返回 0；不能用 ``or`` 保留旧值，否则
                # 取消关注、删光作品等场景会让账号卡片一直显示过期数据。
                acc.follower_count = int(p.get("follower_count") or 0)
                acc.following_count = int(p.get("following_count") or 0)
                acc.aweme_count = int(p.get("aweme_count") or 0)
                acc.total_favorited = int(p.get("total_favorited") or 0)
                acc.gender = str(p.get("gender") or "")
            else:
                acc.follower_count = p.get("follower_count") or acc.follower_count
                acc.aweme_count = p.get("aweme_count") or acc.aweme_count
            acc.status = "active"
            s.add(acc); s.commit()
            return _done("ok")
        if (err == "logged_out" or
                getattr(err, "category", None) == RiskCategory.AUTH.value):
            acc.status = "invalid"
            s.add(acc); s.commit()
            return _done("invalid", err or "logged_out")
    return _done("error", err or "error")


def _merge_prelogin_fingerprint_fields(
        generated: dict, detected: dict | None,
        overrides: dict | None) -> dict:
    """Merge an IP-derived baseline with the user's first-login choices."""
    detected = detected or {}
    merged = dict(generated)
    merged.update({
        "fp_source_ip": detected.get("source_ip", ""),
        "fp_country": detected.get("country", ""),
        "fp_region": detected.get("region", ""),
        "fp_city": detected.get("city", ""),
        "fp_platform": "",
        "fp_platform_version": "",
        "fp_brand": "",
        "fp_brand_version": "",
        "fp_hardware_concurrency": 0,
        "fp_gpu_vendor": "",
        "fp_gpu_renderer": "",
        "fp_accept_languages": "",
        "fp_disable_spoofing": "",
        "fp_language_mode": "auto",
        "fp_timezone_mode": "auto",
        "fp_viewport_mode": "auto",
        "fp_location_mode": "auto",
        "fp_geolocation_permission": "allow",
        "fp_webrtc_mode": "conceal",
        "fp_extra_args": "",
    })
    if detected:
        for name in ("fp_seed", "timezone_id", "locale", "viewport_w",
                     "viewport_h", "geo_lat", "geo_lon"):
            if name in detected:
                merged[name] = detected[name]
    if not overrides:
        return merged

    for name in (
        "fp_seed", "fp_platform", "fp_platform_version", "fp_brand",
        "fp_brand_version", "fp_hardware_concurrency", "fp_gpu_vendor",
        "fp_gpu_renderer", "fp_disable_spoofing", "fp_language_mode",
        "fp_timezone_mode", "fp_viewport_mode", "fp_location_mode",
        "fp_geolocation_permission", "fp_webrtc_mode", "fp_extra_args",
    ):
        merged[name] = overrides[name]

    # Automatic groups keep the values derived from the selected egress IP.
    # Custom groups replace only their own settings.
    if overrides["fp_language_mode"] == "custom":
        merged["locale"] = overrides["locale"]
        merged["fp_accept_languages"] = overrides["fp_accept_languages"]
    if overrides["fp_timezone_mode"] == "custom":
        merged["timezone_id"] = overrides["timezone_id"]
    if overrides["fp_viewport_mode"] == "custom":
        merged["viewport_w"] = overrides["viewport_w"]
        merged["viewport_h"] = overrides["viewport_h"]
    if overrides["fp_location_mode"] == "custom":
        for name in ("fp_source_ip", "fp_country", "fp_region", "fp_city",
                     "geo_lat", "geo_lon"):
            merged[name] = overrides[name]
    return merged


async def _run_login(task_id: str, creator: bool = False, account_id: int | None = None,
                     platform: str = "douyin", proxy_choice: str = "auto",
                     browser_backend: str = "default",
                     browser_runtime_id: str = "",
                     fingerprint_overrides: dict | None = None):
    """扫码登录。多账号隔离模型:一账号=一持久 profile。
    - 传 account_id:登录进该账号自己的 profile(重新登录/补创作者登录)。
    - 不传:用「临时 profile」登录,**只有登录成功才建账号**;关窗/超时/取消都不留残号。"""
    import os
    import shutil
    from .browser import Identity, generate_identity_fields
    login_tasks[task_id] = _login_task_state(
        status="waiting", platform=platform, creator=creator,
        account_id=account_id)
    fresh_account = account_id is None
    tmp_profile = ""
    proxy_reservation_key = ""
    new_fields = None
    fingerprint_fields = None
    is_fingerprint_environment = False
    login_environment = {}
    nm = ("小红书账号" if platform == "xhs"
          else "快手账号" if platform == "kuaishou"
          else "视频号账号" if platform == "shipinhao"
          else "创作者账号" if creator else "扫码账号")
    try:
        # 1) 准备画像 + identity(新建账号此时不写库,只用临时 profile)
        if account_id:
            with get_session() as s:
                acc = s.get(DouyinAccount, account_id)
                if not acc:
                    login_tasks[task_id] = _login_task_state(
                        status="error", platform=platform, creator=creator,
                        account_id=account_id, error="账号不存在")
                    return
                ensure_identity(acc, cfg, session=s, assign_proxy=False)
                s.add(acc); s.commit(); s.refresh(acc)
                identity = browser.identity_for(acc)
                acc_id = acc.id
        else:
            acc_id = None
            new_fields = generate_identity_fields()
            tmp_profile = allocate_profile_dir(cfg.engine.profiles_dir)
            # 登录前选定代理:具体地址 / auto(占用最少) / 空(不用代理)
            choice = (proxy_choice or "").strip()
            if choice.lower() in ("", "none"):
                proxy = ""
            elif choice.lower() == "auto":
                with get_session() as s:
                    proxy_reservation_key = task_id
                    proxy = reserve_proxy_from_pool(s, cfg, proxy_reservation_key)
            else:
                from .browser.manager import normalize_proxy
                proxy = normalize_proxy(choice)
            requested_backend = str(browser_backend or "default").strip().lower()
            if requested_backend not in ACCOUNT_BROWSER_BACKENDS:
                requested_backend = "default"
            # Internal callers cannot opt Xiaohongshu back into a fingerprint
            # runtime after the public API validation below.  Keep one native
            # system-Chrome identity surface for login and subsequent tasks.
            if platform == "xhs":
                requested_backend = LOCAL_BACKEND
                browser_runtime_id = ""
                fingerprint_overrides = None
            backend_status = getattr(browser, "backend_status", None)
            effective_backend = ""
            if callable(backend_status):
                effective_backend = _browser_backend_status(
                    requested_backend, browser_runtime_id).get("name", "")
            is_fingerprint_environment = (
                effective_backend == "fingerprint_chromium")
            if is_fingerprint_environment:
                geo = await _proxy_geo(proxy, timeout=6)
                if geo and geo.get("ip"):
                    fingerprint_fields = derive_ip_fingerprint(
                        task_id,
                        geo.get("ip", ""),
                        country=geo.get("country", ""),
                        region=geo.get("region", ""),
                        city=geo.get("city", ""),
                        timezone_id=geo.get("timezone", ""),
                        latitude=geo.get("lat") or 0.0,
                        longitude=geo.get("lon") or 0.0,
                    )
                new_fields = _merge_prelogin_fingerprint_fields(
                    new_fields, fingerprint_fields, fingerprint_overrides)
            identity = Identity(
                account_id=None, profile_dir=tmp_profile, identity_mode="native",
                browser_backend=requested_backend,
                browser_runtime_id=str(browser_runtime_id or "").strip(),
                platform=platform,
                proxy=proxy, ua="", viewport_w=new_fields["viewport_w"],
                viewport_h=new_fields["viewport_h"], timezone_id=new_fields["timezone_id"],
                locale=new_fields["locale"], fp_seed=new_fields["fp_seed"],
                fp_platform=new_fields.get("fp_platform", ""),
                fp_platform_version=new_fields.get("fp_platform_version", ""),
                fp_brand=new_fields.get("fp_brand", ""),
                fp_brand_version=new_fields.get("fp_brand_version", ""),
                fp_hardware_concurrency=new_fields.get(
                    "fp_hardware_concurrency", 0),
                fp_gpu_vendor=new_fields.get("fp_gpu_vendor", ""),
                fp_gpu_renderer=new_fields.get("fp_gpu_renderer", ""),
                fp_accept_languages=new_fields.get(
                    "fp_accept_languages", ""),
                fp_disable_spoofing=new_fields.get(
                    "fp_disable_spoofing", ""),
                fp_language_mode=new_fields.get("fp_language_mode", "auto"),
                fp_timezone_mode=new_fields.get("fp_timezone_mode", "auto"),
                fp_viewport_mode=new_fields.get("fp_viewport_mode", "auto"),
                fp_location_mode=new_fields.get("fp_location_mode", "auto"),
                fp_geolocation_permission=new_fields.get(
                    "fp_geolocation_permission", "allow"),
                fp_webrtc_mode=new_fields.get("fp_webrtc_mode", "conceal"),
                fp_extra_args=new_fields.get("fp_extra_args", ""),
                geo_lat=new_fields.get("geo_lat", 0.0),
                geo_lon=new_fields.get("geo_lon", 0.0))

        # 登录轮询返回可诊断但不含代理凭据的实际运行环境。浏览器或版本回退
        # 一眼可见，避免把平台验证误判成单纯的 Cookie/二维码问题。
        login_environment = browser.environment_snapshot(identity, headless=False)
        login_tasks[task_id] = _login_task_state(
            status="waiting", platform=platform, creator=creator,
            account_id=account_id, environment=login_environment)

        # 2) 在统一账号/网络入口内扫码，避免与后台任务并行占用 profile。
        @asynccontextmanager
        async def _login_guard():
            if engine is None:
                yield None
                return
            async with engine.operation_guard(
                    account_id, OperationKind.LOGIN,
                    fallback_key=f"login:{task_id}",
                    operation_target=identity) as guarded:
                yield guarded

        async with _login_guard():
            if platform == "xhs":
                reauth_options = {"force_reauth": True} if account_id else {}
                if creator:
                    ok, state_json, nickname = await interactive_xhs_creator_login(
                        browser, identity, **reauth_options)
                else:
                    async def _xhs_verification_status(url: str) -> None:
                        verification = (
                            "/website-login/captcha" in str(url).lower()
                            or "error_code=300012" in str(url).lower()
                        )
                        login_tasks[task_id] = _login_task_state(
                            status=("verification" if verification else "waiting"),
                            platform=platform,
                            creator=creator, account_id=account_id,
                            hint=(("当前账号 Profile 收到小红书设备安全验证；"
                                   "自动任务已暂停，请只在当前可见窗口按平台提示"
                                   "完成人工验证；系统不会自动重试或绕过验证页")
                                  if verification else
                                  "设备验证页已解除，请在当前小红书页面完成登录"),
                            environment=login_environment,
                        )
                    reauth_options["status_callback"] = _xhs_verification_status
                    ok, state_json, nickname = await interactive_xhs_login(
                        browser, identity, timeout_seconds=300,
                        **reauth_options)
            elif platform == "kuaishou":
                reauth_options = {"force_reauth": True} if account_id else {}
                if creator:
                    ok, state_json, nickname = await interactive_ks_creator_login(
                        browser, identity, **reauth_options)
                else:
                    ok, state_json, nickname = await interactive_ks_login(
                        browser, identity, **reauth_options)
            elif platform == "shipinhao":
                reauth_options = {"force_reauth": True} if account_id else {}
                ok, state_json, nickname = await interactive_channels_login(
                    browser, identity, **reauth_options)
            elif creator:
                reauth_options = {"force_reauth": True} if account_id else {}
                ok, state_json, nickname = await interactive_creator_login(
                    browser, identity, **reauth_options)
            else:
                reauth_options = {"force_reauth": True} if account_id else {}
                ok, state_json, nickname = await interactive_login(
                    browser, identity, **reauth_options)

        # 浏览器已经完成实际后端选择；此时快照能反映系统 Chrome 或真实回退。
        login_environment = browser.environment_snapshot(identity, headless=False)
        temporary_identity_key = identity.key

        # 3) 仅在成功时落库
        if ok and state_json:
            is_xhs = platform == "xhs"
            observed_profile = {}
            if is_xhs and not creator:
                raw_observed = getattr(
                    identity, "observed_login_profile", {}) or {}
                if isinstance(raw_observed, dict):
                    observed_profile = parse_xhs_self_user(raw_observed)
            with get_session() as s:
                if account_id:
                    acc = s.get(DouyinAccount, acc_id)
                else:
                    acc = DouyinAccount(
                        platform=platform,
                        nickname=(observed_profile.get("nickname")
                                  or nickname or nm),
                        sec_uid=observed_profile.get("sec_uid", ""),
                        douyin_id=observed_profile.get("douyin_id", ""),
                        avatar=observed_profile.get("avatar", ""),
                        follower_count=observed_profile.get(
                            "follower_count", 0),
                        aweme_count=observed_profile.get("aweme_count", 0),
                        status="active",
                        profile_dir=tmp_profile, proxy=identity.proxy,
                        browser_backend=identity.browser_backend,
                        browser_runtime_id=identity.browser_runtime_id,
                        identity_mode="native", ua=identity.ua or "",
                        viewport_w=new_fields["viewport_w"],
                        viewport_h=new_fields["viewport_h"],
                        timezone_id=new_fields["timezone_id"], locale=new_fields["locale"],
                        fp_seed=new_fields["fp_seed"],
                        fp_source_ip=new_fields.get("fp_source_ip", ""),
                        fp_country=new_fields.get("fp_country", ""),
                        fp_region=new_fields.get("fp_region", ""),
                        fp_city=new_fields.get("fp_city", ""),
                        fp_generated_at=(datetime.utcnow()
                                         if is_fingerprint_environment else None),
                        fp_platform=new_fields.get("fp_platform", ""),
                        fp_platform_version=new_fields.get(
                            "fp_platform_version", ""),
                        fp_brand=new_fields.get("fp_brand", ""),
                        fp_brand_version=new_fields.get("fp_brand_version", ""),
                        fp_hardware_concurrency=new_fields.get(
                            "fp_hardware_concurrency", 0),
                        fp_gpu_vendor=new_fields.get("fp_gpu_vendor", ""),
                        fp_gpu_renderer=new_fields.get("fp_gpu_renderer", ""),
                        fp_accept_languages=new_fields.get(
                            "fp_accept_languages", ""),
                        fp_disable_spoofing=new_fields.get(
                            "fp_disable_spoofing", ""),
                        fp_language_mode=new_fields.get(
                            "fp_language_mode", "auto"),
                        fp_timezone_mode=new_fields.get(
                            "fp_timezone_mode", "auto"),
                        fp_viewport_mode=new_fields.get(
                            "fp_viewport_mode", "auto"),
                        fp_location_mode=new_fields.get(
                            "fp_location_mode", "auto"),
                        fp_geolocation_permission=new_fields.get(
                            "fp_geolocation_permission", "allow"),
                        fp_webrtc_mode=new_fields.get(
                            "fp_webrtc_mode", "conceal"),
                        fp_extra_args=new_fields.get("fp_extra_args", ""),
                        geo_lat=new_fields.get("geo_lat", 0.0),
                        geo_lon=new_fields.get("geo_lon", 0.0))
                    s.add(acc); s.commit(); s.refresh(acc); acc_id = acc.id
                if creator:
                    acc.creator_storage_state = state_json
                    if not is_xhs and not acc.storage_state:
                        acc.storage_state = state_json
                elif platform == "kuaishou":
                    # 当前快手 passToken 会在 cp.kuaishou.com 自动换取创作会话；
                    # 一次主站扫码同时可读取和发布，不再要求用户重复扫“创作者登录”。
                    acc.storage_state = state_json
                    acc.creator_storage_state = state_json
                elif platform == "shipinhao":
                    # 视频号一套登录态即读取又发布,两处都写
                    acc.storage_state = state_json
                    acc.creator_storage_state = state_json
                else:
                    acc.storage_state = state_json
                if nickname:
                    acc.nickname = nickname
                if observed_profile:
                    acc.nickname = (
                        observed_profile.get("nickname") or acc.nickname)
                    acc.sec_uid = (
                        observed_profile.get("sec_uid") or acc.sec_uid)
                    acc.douyin_id = (
                        observed_profile.get("douyin_id") or acc.douyin_id)
                    acc.avatar = observed_profile.get("avatar") or acc.avatar
                    acc.follower_count = (
                        observed_profile.get("follower_count")
                        or acc.follower_count)
                    acc.aweme_count = (
                        observed_profile.get("aweme_count")
                        or acc.aweme_count)
                if acc.identity_mode == "native" and identity.ua:
                    acc.ua = identity.ua
                acc.status = "active"
                s.add(acc); s.commit()

            if fresh_account and platform == "xhs":
                # Promote the successful temporary login session to the new
                # durable account id without closing/reopening Chromium.
                rebound = getattr(browser, "rebind_context", None)
                if callable(rebound):
                    await rebound(temporary_identity_key, acc_id)
                identity.account_id = acc_id

            # 登录态已经持久化且账号已经落库：立即通知前端把账号显示出来。
            # 完整资料抓取可能还需数秒，不能让它阻塞“扫码成功”的交互反馈。
            login_tasks[task_id] = _login_task_state(
                status="persisted", platform=platform, creator=creator,
                account_id=acc_id,
                nickname=nickname or nm,
                hint="扫码已确认，正在校验登录态并同步账号资料",
                environment=login_environment,
            )

            if is_xhs and not creator:
                # 主站登录已经给出 user/me（或二维码完成信号）。保留当前
                # 账号浏览器会话，缺失资料可在同一会话中按需补全。
                profile_status = (
                    "ok" if observed_profile.get("sec_uid")
                    else "deferred")
            else:
                profile_status = await _enrich_account_profile(
                    acc_id, state_json)   # best-effort
            # 主站与创作平台可能被用户分别从顶部入口登录。资料同步拿到
            # user_id/red_id 后即可权威判断是否为同一个小红书账号，并把
            # 两份登录态自动折叠到稳定的旧账号 id。
            if is_xhs:
                with get_session() as s:
                    duplicate_ids = duplicate_xhs_account_ids(s, acc_id)
                if len(duplicate_ids) > 1:
                    await _close_runtime_accounts(duplicate_ids)
                    with get_session() as s:
                        merged_accounts = reconcile_xhs_accounts(
                            s, account_id=acc_id)
                    if merged_accounts:
                        cleanup_merged_profiles(
                            merged_accounts, cfg.engine.profiles_dir)
                        for merge in merged_accounts:
                            if acc_id == merge.removed_id:
                                acc_id = merge.kept_id

            with get_session() as s:
                acc = s.get(DouyinAccount, acc_id)
                login_tasks[task_id] = _login_task_state(
                    status="confirmed", platform=platform, creator=creator,
                    account_id=acc_id,
                    nickname=acc.nickname if acc else (nickname or nm),
                    profile_status=profile_status,
                    environment=login_environment)
        else:
            if fresh_account and tmp_profile:   # 没建账号,清理临时 profile
                try:
                    await browser.close_context(identity.key)
                except Exception:
                    pass
                shutil.rmtree(tmp_profile, ignore_errors=True)
            login_tasks[task_id] = _login_task_state(
                status="expired", platform=platform, creator=creator,
                account_id=account_id, environment=login_environment)
    except Exception as e:
        traceback.print_exc()
        if fresh_account and tmp_profile:
            try:
                await browser.close_context(identity.key)
            except Exception:
                pass
            shutil.rmtree(tmp_profile, ignore_errors=True)
        login_tasks[task_id] = _login_task_state(
            status="error", platform=platform, creator=creator,
            account_id=account_id, error=f"{type(e).__name__}: {e}",
            environment=login_environment)
    finally:
        if proxy_reservation_key:
            release_proxy_reservation(proxy_reservation_key)


def _validate_login_browser_backend(
        value: str, runtime_id: str = "", *,
        platform: str = "") -> tuple[str, str]:
    requested = str(value or "default").strip().lower()
    runtime_id = str(runtime_id or "").strip()
    if requested not in ACCOUNT_BROWSER_BACKENDS:
        raise HTTPException(400, "浏览器环境取值无效")
    status = _browser_backend_status(requested, runtime_id)
    if not status["available"]:
        raise HTTPException(400, f"浏览器环境不可用：{status['detail']}")
    if str(platform or "").lower() == "xhs" \
            and status.get("name") != LOCAL_BACKEND:
        raise HTTPException(
            400,
            "小红书仅支持系统 Chrome/CDP 原生环境；指纹内核会造成环境不一致",
        )
    return requested, runtime_id


def _validate_prelogin_fingerprint(
        value: dict[str, Any] | None, browser_backend: str,
        browser_runtime_id: str) -> dict | None:
    """Validate optional first-login settings with the normal editor rules."""
    if value is None:
        return None
    status = _browser_backend_status(browser_backend, browser_runtime_id)
    if status.get("name") != "fingerprint_chromium":
        raise HTTPException(400, "仅指纹浏览器环境支持登录前指纹配置")
    if len(json.dumps(value, ensure_ascii=False)) > 12000:
        raise HTTPException(400, "登录前指纹配置超过长度限制")
    try:
        body = AccountFingerprintUpdateIn(**value)
    except ValidationError as exc:
        raise HTTPException(400, "登录前指纹配置格式无效") from exc
    return _validate_fingerprint_update(body)


@app.post("/api/login/browser/start")
async def login_browser_start(proxy: str = "auto", browser_backend: str = "default",
                              browser_runtime_id: str = "",
                              fingerprint: dict[str, Any] | None = None):
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id)
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("douyin", False)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="douyin", creator=False, account_id=None)
    asyncio.create_task(_run_login(
        task_id, proxy_choice=proxy, browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开浏览器窗口,请在其中点击“登录”并用抖音 App 扫码"}


@app.post("/api/login/creator/start")
async def login_creator_start(proxy: str = "auto", browser_backend: str = "default",
                              browser_runtime_id: str = "",
                              fingerprint: dict[str, Any] | None = None):
    """创作中心登录(用于自有账号评论模式;其登录态同样可用于公开抓取)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id)
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("douyin", True)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="douyin", creator=True, account_id=None)
    asyncio.create_task(_run_login(
        task_id, creator=True, proxy_choice=proxy,
        browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开创作中心窗口,请在其中扫码登录你的抖音号"}


@app.post("/api/login/xhs/start")
async def login_xhs_start(proxy: str = "auto", browser_backend: str = "default",
                          browser_runtime_id: str = "",
                          fingerprint: dict[str, Any] | None = None):
    """小红书扫码登录(用于监控/读取)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id, platform="xhs")
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("xhs", False)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="xhs", creator=False, account_id=None)
    asyncio.create_task(_run_login(
        task_id, platform="xhs", proxy_choice=proxy,
        browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开小红书官网首页,请在窗口中点击登录并用小红书 App 扫码"}


@app.post("/api/login/xhs-creator/start")
async def login_xhs_creator_start(proxy: str = "auto", browser_backend: str = "default",
                                  browser_runtime_id: str = "",
                                  fingerprint: dict[str, Any] | None = None):
    """小红书「创作服务平台」登录(用于发布/已发布列表)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id, platform="xhs")
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("xhs", True)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="xhs", creator=True, account_id=None)
    asyncio.create_task(_run_login(
        task_id, creator=True, platform="xhs", proxy_choice=proxy,
        browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开小红书创作平台窗口,请扫码登录(发布用)"}


@app.post("/api/login/kuaishou/start")
async def login_ks_start(proxy: str = "auto", browser_backend: str = "default",
                         browser_runtime_id: str = "",
                         fingerprint: dict[str, Any] | None = None):
    """快手扫码登录(用于监控/读取)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id)
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("kuaishou", False)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="kuaishou", creator=False,
        account_id=None)
    asyncio.create_task(_run_login(
        task_id, platform="kuaishou", proxy_choice=proxy,
        browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开快手窗口,请在其中用快手 App 扫码登录"}


@app.post("/api/login/kuaishou-creator/start")
async def login_ks_creator_start(proxy: str = "auto", browser_backend: str = "default",
                                 browser_runtime_id: str = "",
                                 fingerprint: dict[str, Any] | None = None):
    """快手「创作者服务平台」登录(用于发布)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id)
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("kuaishou", True)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="kuaishou", creator=True,
        account_id=None)
    asyncio.create_task(_run_login(
        task_id, creator=True, platform="kuaishou", proxy_choice=proxy,
        browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开快手创作平台窗口,请扫码登录(发布用)"}


@app.post("/api/login/shipinhao/start")
async def login_channels_start(proxy: str = "auto", browser_backend: str = "default",
                               browser_runtime_id: str = "",
                               fingerprint: dict[str, Any] | None = None):
    """视频号扫码登录(读取/发布共用,微信扫码)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    browser_backend, browser_runtime_id = _validate_login_browser_backend(
        browser_backend, browser_runtime_id)
    fingerprint_overrides = _validate_prelogin_fingerprint(
        fingerprint, browser_backend, browser_runtime_id)
    reused = await _reuse_or_reject_interactive_login("shipinhao", False)
    if reused is not None:
        return reused
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform="shipinhao", creator=False,
        account_id=None)
    asyncio.create_task(_run_login(
        task_id, platform="shipinhao", proxy_choice=proxy,
        browser_backend=browser_backend,
        browser_runtime_id=browser_runtime_id,
        fingerprint_overrides=fingerprint_overrides))
    return {"task_id": task_id, "status": "opening",
            "hint": "已打开视频号助手窗口,请用微信扫码登录"}


@app.get("/api/login/browser/poll")
async def login_browser_poll(task_id: str):
    info = login_tasks.get(task_id)
    if not info:
        raise HTTPException(404, "task 不存在")
    if info.get("status") in ("confirmed", "error", "expired"):
        # 终态:取走后清理
        login_tasks.pop(task_id, None)
    return info


class CookieIn(BaseModel):
    cookie: str
    nickname: str = ""
    platform: str = "douyin"            # douyin | xhs


@app.post("/api/login/cookie")
async def login_cookie(body: CookieIn):
    """Cookie 粘贴兜底登录:转成浏览器登录态。"""
    platform = body.platform if body.platform in ("douyin", "xhs", "kuaishou") else "douyin"
    state = cookie_string_to_state(body.cookie, platform)
    with get_session() as s:
        acc = DouyinAccount(
            nickname=body.nickname or "Cookie账号", platform=platform,
            identity_mode="native", cookie=body.cookie.strip(), storage_state=state)
        s.add(acc); s.commit(); s.refresh(acc)
        # 分配画像(profile/UA/指纹/代理):Cookie 会在首次开持久 profile 时桥接注入
        ensure_identity(acc, cfg, session=s, assign_proxy=True)
        s.add(acc); s.commit(); s.refresh(acc)
        return {"account_id": acc.id, "nickname": acc.nickname}


@app.get("/api/overview/summary")
async def overview_summary(platform: str = "douyin"):
    if platform not in {"douyin", "xhs", "kuaishou", "shipinhao"}:
        raise HTTPException(422, "平台类型无效")
    with get_session() as session:
        def count(model, *conditions):
            return int(session.exec(select(func.count()).select_from(model).where(
                model.platform == platform, *conditions)).one())
        return {
            "platform": platform,
            "accounts": count(DouyinAccount),
            "monitors": count(MonitorTarget, MonitorTarget.enabled == True),  # noqa:E712
            "downloaded": count(ContentRecord, ContentRecord.download_status == "done"),
            "comments": count(CommentRecord),
        }


@app.get("/api/accounts")
async def list_accounts(platform: str | None = None):
    risk_controller = engine.risk if engine else RiskController(cfg)
    with get_session() as s:
        all_accounts = s.exec(select(DouyinAccount)).all()
        profile_keys: dict[int, str] = {}
        profile_counts: dict[str, int] = {}
        for account in all_accounts:
            if not account.id or not account.profile_dir:
                continue
            normalized = os.path.normcase(str(
                Path(account.profile_dir).expanduser().resolve()))
            profile_keys[account.id] = normalized
            profile_counts[normalized] = profile_counts.get(normalized, 0) + 1
        q = select(DouyinAccount)
        if platform:
            q = q.where(DouyinAccount.platform == platform)
        accs = s.exec(q).all()
        out = []
        for a in accs:
            profile_key = profile_keys.get(a.id or 0, "")
            risk_state = s.get(AccountRiskState, a.id) if a.id else None
            next_write_at = risk_controller.next_write_at(a.id) if a.id else None
            used = len(s.exec(select(MonitorTarget.id)
                              .where(MonitorTarget.account_id == a.id)).all())
            environment = None
            environment_check = None
            if browser is not None:
                try:
                    account_identity = browser.identity_for(a)
                    environment = browser.environment_snapshot(
                        account_identity, headless=False)
                    check_status = getattr(
                        browser, "environment_check_status", None)
                    if callable(check_status):
                        environment_check = check_status(account_identity)
                except Exception:
                    environment = None
                    environment_check = None
            has_creator = (
                bool(a.creator_storage_state)
                or (a.platform in ("kuaishou", "douyin", "shipinhao")
                    and bool(a.storage_state))
                or (a.platform == "xhs" and has_creator_cookies(a.storage_state))
            )
            has_read_login = (
                _xhs_has_read_login_state(a.storage_state)
                if a.platform == "xhs" else bool(a.storage_state)
            )
            out.append({
                "id": a.id, "platform": a.platform, "nickname": a.nickname, "status": a.status,
                "sec_uid": a.sec_uid, "douyin_id": a.douyin_id, "avatar": a.avatar,
                "follower_count": a.follower_count,
                "following_count": a.following_count,
                "aweme_count": a.aweme_count,
                "total_favorited": a.total_favorited,
                "gender": a.gender,
                "has_creator": has_creator,
                "has_read_login": has_read_login,
                "kind": "creator" if has_creator else "fetch",
                "has_storage": has_read_login,
                "login_type": "cookie" if a.cookie else "scan",
                "monitor_count": used,
                # 风控隔离画像
                "proxy": _mask_proxy(a.proxy),
                "proxy_status": a.proxy_status,
                "has_proxy": bool(a.proxy),
                "exit_ip": a.exit_ip,
                "exit_country": a.exit_country,
                "exit_asn": a.exit_asn,
                "exit_timezone": a.exit_timezone,
                "exit_checked_at": (a.exit_checked_at.isoformat()
                                    if a.exit_checked_at else None),
                "write_paused_until": (a.write_paused_until.isoformat()
                                        if a.write_paused_until else None),
                "write_pause_reason": a.write_pause_reason,
                "identity_mode": a.identity_mode,
                "browser_backend": a.browser_backend,
                "browser_runtime_id": a.browser_runtime_id,
                "fingerprint_id": (a.fp_seed or "")[:12],
                "fingerprint_ip": a.fp_source_ip,
                "fingerprint_country": a.fp_country,
                "fingerprint_region": a.fp_region,
                "fingerprint_city": a.fp_city,
                "fingerprint_timezone": a.timezone_id,
                "fingerprint_locale": a.locale,
                "fingerprint_generated_at": (
                    a.fp_generated_at.isoformat() if a.fp_generated_at else None),
                "fingerprint_ip_matches_exit": bool(
                    a.fp_source_ip and a.exit_ip and a.fp_source_ip == a.exit_ip),
                "risk_level": risk_state.risk_level if risk_state else 0,
                "risk_cooldown_until": (
                    risk_state.cooldown_until.isoformat()
                    if risk_state and risk_state.cooldown_until else None),
                "risk_signal": risk_state.last_risk_reason if risk_state else "",
                "next_write_at": (next_write_at.isoformat()
                                  if next_write_at else None),
                "ua": a.ua,
                "profile_dir": a.profile_dir,
                "profile_isolated": bool(
                    profile_key and profile_counts.get(profile_key) == 1),
                "profile_isolation_id": (
                    hashlib.sha256(profile_key.encode("utf-8")).hexdigest()[:10]
                    if profile_key else ""),
                "environment": environment,
                "environment_check": environment_check,
                "created_at": a.created_at.isoformat() if a.created_at else None,
            })
        return out


# ─────────── 统一任务队列 ───────────
_QUEUE_TYPES = {
    "collections", "publishes", "comments", "actions",
    "monitor_downloads", "collection_downloads",
}
_QUEUE_STATES = {"active", "pending", "running", "blocked", "failed", "completed", "all"}
_QUEUE_RUNNING = {"running", "publishing", "doing", "downloading"}
_QUEUE_FAILED = {"failed", "partial", "uncertain"}
_QUEUE_COMPLETED = {"done", "canceled", "skipped"}


def _queue_iso(value: datetime | None) -> str | None:
    return value.isoformat(timespec="seconds") + "Z" if value else None


def _queue_state(status: str, *, blocked_reason: str = "",
                 next_allowed_at: datetime | None = None) -> str:
    status = str(status or "").lower()
    if status in _QUEUE_FAILED:
        return "failed"
    if status in _QUEUE_COMPLETED:
        return "completed"
    if blocked_reason or (next_allowed_at and next_allowed_at > datetime.utcnow()):
        return "blocked"
    if status in _QUEUE_RUNNING:
        return "running"
    return "pending"


def _queue_keywords(value: str) -> str:
    try:
        values = json.loads(value or "[]")
    except (TypeError, ValueError):
        values = []
    if isinstance(values, list):
        text = "、".join(str(item).strip() for item in values if str(item).strip())
        if text:
            return text
    return str(value or "").strip() or "未命名关键词任务"


@app.get("/api/task-queue")
async def list_task_queue(platform: str | None = None, queue_type: str = "",
                          state: str = "active", q: str = "", page: int = 1,
                          page_size: int = 20):
    """Return persistent jobs from every worker queue in one normalized view."""
    platform = str(platform or "").strip().lower()
    if platform == "all":
        platform = ""
    queue_type = str(queue_type or "").strip().lower()
    state = str(state or "active").strip().lower()
    if queue_type and queue_type not in _QUEUE_TYPES:
        raise HTTPException(400, "未知队列类型")
    if state not in _QUEUE_STATES:
        raise HTTPException(400, "未知队列状态")
    q_text = str(q or "").strip()[:200]
    q_folded = q_text.casefold()
    page = max(1, int(page or 1))
    page_size = max(1, min(int(page_size or 20), 100))
    include_completed = state in {"completed", "all"}

    with get_session() as session:
        accounts = {row.id: row for row in session.exec(select(DouyinAccount)).all()}
        targets = {row.id: row for row in session.exec(select(MonitorTarget)).all()}
        jobs = {row.id: row for row in session.exec(select(KeywordCollectionJob)).all()}
        items: list[dict[str, Any]] = []

        def account_name(account_id: int | None) -> str:
            account = accounts.get(account_id)
            return (account.nickname or account.douyin_id or account.sec_uid) if account else ""

        def add(*, queue: str, queue_label: str, row_id: int | None,
                row_platform: str, account_id: int | None, title: str, detail: str,
                status: str, created_at: datetime | None,
                source_tab: str, scheduled_at: datetime | None = None,
                schedule_is_utc: bool = True,
                blocked_reason: str = "", blocked_signal: str = "",
                next_allowed_at: datetime | None = None, error: str = "") -> None:
            queue_state = _queue_state(
                status, blocked_reason=blocked_reason,
                next_allowed_at=next_allowed_at)
            items.append({
                "key": f"{queue}:{row_id}",
                "queue_type": queue,
                "queue_label": queue_label,
                "id": row_id,
                "platform": row_platform,
                "account_id": account_id,
                "account_name": account_name(account_id),
                "title": str(title or "未命名任务")[:500],
                "detail": str(detail or "")[:1000],
                "status": str(status or "pending"),
                "state": queue_state,
                "scheduled_at": (_queue_iso(scheduled_at) if schedule_is_utc
                                 else scheduled_at.isoformat() if scheduled_at else None),
                "schedule_needs_confirmation": bool(scheduled_at and not schedule_is_utc),
                "created_at": _queue_iso(created_at),
                "next_allowed_at": _queue_iso(next_allowed_at),
                "blocked_reason": str(blocked_reason or "")[:1000],
                "blocked_signal": str(blocked_signal or "")[:120],
                "error": str(error or "")[:1000],
                "source_tab": source_tab,
            })

        task_specs = (
            (KeywordCollectionJob,
             ["pending", "running", "failed", "partial"], ["done", "canceled"]),
            (PublishTask,
             ["draft", "pending", "publishing", "failed", "uncertain"], ["done", "canceled"]),
            (CommentTask,
             ["draft", "pending", "doing", "failed", "uncertain"], ["done", "canceled"]),
            (AccountActionTask,
             ["draft", "pending", "doing", "failed", "uncertain"], ["done", "canceled"]),
            (ContentRecord,
             ["pending", "downloading", "failed"], ["done"]),
            (KeywordCollectionContent,
             ["pending", "downloading", "failed"], ["done", "skipped"]),
        )
        loaded: dict[type, list[Any]] = {}
        for model, current_statuses, finished_statuses in task_specs:
            status_column = (model.download_status
                             if model in {ContentRecord, KeywordCollectionContent}
                             else model.status)
            active_statuses = [value for value in current_statuses
                               if value not in _QUEUE_FAILED]
            failed_statuses = [value for value in current_statuses
                               if value in _QUEUE_FAILED]
            rows = list(session.exec(
                select(model).where(status_column.in_(active_statuses)).order_by(
                    model.created_at.desc())).all())
            # 活动任务必须完整展示；历史失败/完成记录只取每类最近 1000 条，
            # 避免长期运行后“已完成”筛选一次性加载全部媒体记录。
            if failed_statuses:
                rows.extend(session.exec(
                    select(model).where(status_column.in_(failed_statuses)).order_by(
                        model.created_at.desc()).limit(1000)).all())
            if include_completed:
                rows.extend(session.exec(
                    select(model).where(status_column.in_(finished_statuses)).order_by(
                        model.created_at.desc()).limit(1000)).all())
            loaded[model] = rows

        for row in loaded[KeywordCollectionJob]:
            collection_title = (_queue_keywords(row.keywords)
                                if row.source_type == "keyword"
                                else row.source_name or row.source_type or "采集任务")
            add(
                queue="collections", queue_label="内容采集", row_id=row.id,
                row_platform=row.platform, account_id=row.account_id,
                title=collection_title,
                detail=(f"{row.current_step or '等待执行'} · 已采集 {row.content_count} 个作品 / "
                        f"{row.comment_count} 条评论"),
                status=row.status, created_at=row.created_at,
                scheduled_at=row.started_at, source_tab="collections",
                blocked_reason=row.blocked_reason, blocked_signal=row.blocked_signal,
                next_allowed_at=row.next_allowed_at, error=row.error)

        for row in loaded[PublishTask]:
            add(
                queue="publishes", queue_label="内容发布", row_id=row.id,
                row_platform=row.platform, account_id=row.account_id,
                title=row.title or row.desc or f"{row.media_type} 发布任务",
                detail=row.desc if row.title else (row.topics or row.media_type),
                status=row.status, created_at=row.created_at,
                scheduled_at=row.scheduled_at, source_tab="publish",
                schedule_is_utc=row.scheduled_at_is_utc,
                blocked_reason=row.blocked_reason, blocked_signal=row.blocked_signal,
                next_allowed_at=row.next_allowed_at, error=row.error)

        for row in loaded[CommentTask]:
            target = f"回复 {row.target_nick}" if row.target_nick else f"作品 {row.aweme_id}"
            add(
                queue="comments", queue_label="自动评论", row_id=row.id,
                row_platform=row.platform, account_id=row.account_id,
                title=row.content or "待发送评论", detail=target,
                status=row.status, created_at=row.created_at,
                scheduled_at=row.scheduled_at, source_tab="autocomment",
                blocked_reason=row.blocked_reason, blocked_signal=row.blocked_signal,
                next_allowed_at=row.next_allowed_at, error=row.error)

        action_labels = {"follow": "关注", "unfollow": "取关", "send_dm": "发送私信"}
        for row in loaded[AccountActionTask]:
            action_label = action_labels.get(row.action, row.action or "账号动作")
            target = row.target_nick or row.target_uid or row.target_sec_uid or "目标账号"
            add(
                queue="actions", queue_label="账号动作", row_id=row.id,
                row_platform=row.platform, account_id=row.account_id,
                title=f"{action_label} · {target}", detail=row.content,
                status=row.status, created_at=row.created_at,
                scheduled_at=row.scheduled_at, source_tab="hub",
                blocked_reason=row.blocked_reason, blocked_signal=row.blocked_signal,
                next_allowed_at=row.next_allowed_at, error=row.error)

        for row in loaded[ContentRecord]:
            target = targets.get(row.target_id)
            account_id = target.account_id if target else None
            target_name = ((target.alias or target.nickname or target.keyword)
                           if target else "作品监控")
            add(
                queue="monitor_downloads", queue_label="监控下载", row_id=row.id,
                row_platform=row.platform, account_id=account_id,
                title=row.desc or f"作品 {row.aweme_id}", detail=target_name,
                status=row.download_status, created_at=row.created_at,
                source_tab="monitors", error=row.error)

        for row in loaded[KeywordCollectionContent]:
            job = jobs.get(row.job_id)
            add(
                queue="collection_downloads", queue_label="采集下载", row_id=row.id,
                row_platform=row.platform,
                account_id=job.account_id if job else None,
                title=row.desc or f"作品 {row.aweme_id}",
                detail=f"关键词：{row.keyword}" if row.keyword else "关键词采集媒体",
                status=row.download_status, created_at=row.created_at,
                source_tab="collections", error=row.error)

    if platform:
        items = [item for item in items if item["platform"] == platform]
    if queue_type:
        items = [item for item in items if item["queue_type"] == queue_type]
    if q_folded:
        def matches(item: dict[str, Any]) -> bool:
            haystack = " ".join(str(item.get(key) or "") for key in (
                "queue_label", "title", "detail", "account_name", "status",
                "blocked_reason", "blocked_signal", "error", "platform"))
            return q_folded in haystack.casefold()
        items = [item for item in items if matches(item)]

    summary = {name: 0 for name in (
        "total", "active", "pending", "running", "blocked", "failed", "completed")}
    summary["total"] = len(items)
    for item in items:
        item_state = item["state"]
        summary[item_state] += 1
        if item_state in {"pending", "running", "blocked"}:
            summary["active"] += 1

    if state == "active":
        filtered = [item for item in items if item["state"] in {"pending", "running", "blocked"}]
    elif state == "all":
        filtered = items
    else:
        filtered = [item for item in items if item["state"] == state]

    state_rank = {"running": 0, "blocked": 1, "pending": 2, "failed": 3, "completed": 4}

    def sort_key(item: dict[str, Any]) -> tuple[int, float]:
        timestamp = item.get("scheduled_at") or item.get("created_at") or ""
        try:
            epoch = datetime.fromisoformat(timestamp.rstrip("Z")).timestamp()
        except (TypeError, ValueError):
            epoch = 0.0
        rank = state_rank.get(item["state"], 9)
        if item["state"] in {"failed", "completed"}:
            epoch = -epoch
        return rank, epoch

    filtered.sort(key=sort_key)
    total = len(filtered)
    pages = max(1, (total + page_size - 1) // page_size)
    page = min(page, pages)
    start = (page - 1) * page_size
    return {
        "items": filtered[start:start + page_size],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": pages,
        "summary": summary,
        "history_limit_per_queue": 1000,
        "generated_at": _queue_iso(datetime.utcnow()),
    }


class TaskResolutionIn(BaseModel):
    outcome: str
    note: str = PydanticField(min_length=1, max_length=500)


@app.post("/api/task-queue/{queue_type}/{task_id}/resolve")
async def resolve_task_result(queue_type: str, task_id: int,
                              body: TaskResolutionIn, request: Request):
    """Record a human platform-result check; never execute or retry a write."""
    actor = _require_risk_admin(request)
    model = {"publishes": PublishTask, "comments": CommentTask,
             "actions": AccountActionTask}.get(queue_type)
    if model is None or body.outcome not in {"done", "canceled"}:
        raise HTTPException(422, "仅支持将写操作核对为已完成或取消，不会自动重试")
    note = body.note.strip()
    if not note:
        raise HTTPException(422, "请填写平台核对说明")
    with get_session() as session:
        row = session.get(model, task_id)
        if row is None:
            raise HTTPException(404, "任务不存在")
        if row.status != "uncertain":
            raise HTTPException(409, "只有结果待确认的任务可以人工核对")
        account_id, previous_error = row.account_id, row.error
        result = session.exec(update(model).where(
            model.id == task_id, model.status == "uncertain").values(
                status=body.outcome, scheduled_at=None,
                done_at=datetime.utcnow() if body.outcome == "done" else None,
                error="已人工核对：" + note,
                blocked_reason="", blocked_signal="", blocked_operation="",
                blocked_at=None, next_allowed_at=None))
        if result.rowcount != 1:
            raise HTTPException(409, "任务状态已变化，请刷新后再核对")
        session.add(RiskAdminAudit(
            action="task_result_resolved", account_id=account_id, actor=actor,
            detail=json.dumps({"queue_type": queue_type, "task_id": task_id,
                               "outcome": body.outcome, "note": note,
                               "previous_error": previous_error[:1000]}, ensure_ascii=False)))
        session.commit()
    return {"ok": True, "status": body.outcome}


# ─────────── 风控中心 ───────────
def _risk_iso(value: datetime | None) -> str | None:
    return value.isoformat(timespec="seconds") + "Z" if value else None


def _risk_admin_required() -> bool:
    return bool(os.environ.get("CREATORHUB_ADMIN_TOKEN", "").strip())


def _require_risk_admin(request: Request) -> str:
    expected = os.environ.get("CREATORHUB_ADMIN_TOKEN", "").strip()
    supplied = request.headers.get("X-CreatorHub-Admin-Token", "").strip()
    if expected and not secrets.compare_digest(expected.encode(), supplied.encode()):
        raise HTTPException(403, "需要风控管理口令")
    actor = request.headers.get("X-CreatorHub-Actor", "").strip()[:64]
    if actor:
        return actor
    host = request.client.host if request.client else "local"
    return f"local-ui@{host}"[:64]


def _risk_config_diff(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    changes = {}
    for section in ("risk_control", "schedule"):
        old, new = before.get(section, {}), after.get(section, {})
        section_changes = {
            key: {"before": old.get(key), "after": new.get(key)}
            for key in sorted(set(old) | set(new)) if old.get(key) != new.get(key)
        }
        if section_changes:
            changes[section] = section_changes
    return changes


def _record_risk_admin_audit(action: str, *, actor: str,
                             account_id: int | None = None,
                             detail: dict[str, Any] | None = None) -> None:
    with get_session() as session:
        session.add(RiskAdminAudit(
            action=action, account_id=account_id, actor=actor,
            detail=json.dumps(detail or {}, ensure_ascii=False)[:8000],
        ))
        session.commit()


def _risk_task_rollups(session, account_ids: list[int]) -> dict[int, dict[str, Any]]:
    result = {account_id: {
        "collections": 0, "publishes": 0, "comments": 0, "actions": 0,
        "total": 0, "blocked": 0, "blocked_signals": {},
        "next_allowed_at": None, "latest_block_reason": "",
        "latest_blocked_at": None,
    } for account_id in account_ids}
    if not account_ids:
        return result
    specs = (
        (KeywordCollectionJob, "collections", ["pending", "running"]),
        (PublishTask, "publishes", ["pending", "publishing"]),
        (CommentTask, "comments", ["pending", "doing"]),
        (AccountActionTask, "actions", ["pending", "doing"]),
    )
    for model, key, statuses in specs:
        rows = session.exec(select(model).where(
            model.account_id.in_(account_ids), model.status.in_(statuses))).all()
        for row in rows:
            item = result[row.account_id]
            item[key] += 1
            item["total"] += 1
            reason = str(getattr(row, "blocked_reason", "") or "")
            if not reason:
                continue
            item["blocked"] += 1
            signal = str(getattr(row, "blocked_signal", "") or "deferred")
            item["blocked_signals"][signal] = item["blocked_signals"].get(signal, 0) + 1
            next_at = getattr(row, "next_allowed_at", None)
            if next_at and (item["next_allowed_at"] is None
                            or next_at < item["next_allowed_at"]):
                item["next_allowed_at"] = next_at
            blocked_at = getattr(row, "blocked_at", None)
            if blocked_at and (item["latest_blocked_at"] is None
                               or blocked_at > item["latest_blocked_at"]):
                item["latest_blocked_at"] = blocked_at
                item["latest_block_reason"] = reason
    return result


def _account_risk_view(account: DouyinAccount, now: datetime, *,
                       state: AccountRiskState | None,
                       latest_event: RiskEvent | None,
                       queued: dict[str, Any]) -> dict[str, Any]:
    risk_level = state.risk_level if state else 0
    reason = state.last_risk_reason if state else ""
    cooldown_until = state.cooldown_until if state else None
    status_code, status_label, status_tone = "normal", "正常", "success"
    if state and state.manual_review_required:
        status_code, status_label, status_tone = "verification_required", "待人工验证", "danger"
        reason = state.manual_review_reason or "请在账号浏览器中处理验证，然后人工解除暂停"
    elif account.status == "invalid":
        status_code, status_label, status_tone = "auth_invalid", "登录失效", "danger"
        reason = "账号登录态已失效，需要重新登录"
    elif account.proxy_status in {"bad", "auth_error", "blocked", "drifted"}:
        status_code, status_label, status_tone = "proxy_error", "代理异常", "danger"
        reason = account.write_pause_reason or "账号绑定代理不可用或出口发生漂移"
    elif cooldown_until and cooldown_until > now:
        if "出口组熔断" in reason:
            status_code, status_label = "network_circuit", "网络熔断"
        else:
            status_code, status_label = "cooldown", "风险冷却"
        status_tone = "danger"
    elif risk_level > 0:
        status_code, status_label, status_tone = "recovering", "渐进恢复", "warn"
        reason = reason or "冷却已结束，等待轻量探测确认账号恢复"
    elif account.write_paused_until and account.write_paused_until > now:
        status_code, status_label, status_tone = "write_paused", "写入暂停", "warn"
        reason = account.write_pause_reason or "账号写操作暂时停用"
    elif state and state.retry_not_before and state.retry_not_before > now:
        status_code, status_label, status_tone = "network_backoff", "网络退避", "warn"
        reason = "网络异常后等待再尝试"
    elif state and state.session_rest_until and state.session_rest_until > now:
        reason = "连续操作后的正常休息，任务保留在队列中"
    elif state and state.operation_not_before and state.operation_not_before > now:
        reason = "正常操作间隔，任务保留在队列中"
    elif status_code == "normal":
        reason = "未检测到风险信号"

    recovery_successes = state.recovery_successes if state else 0
    recovery_target = max(1, cfg.risk_control.recovery_successes)
    next_probe = None
    if risk_level > 0 and not (state and state.manual_review_required):
        if cooldown_until and cooldown_until > now:
            next_probe = cooldown_until
        elif state and (state.last_recovery_at or state.last_operation_at):
            anchor = max(value for value in (
                state.last_recovery_at, state.last_operation_at) if value is not None)
            next_probe = anchor + timedelta(
                seconds=cfg.risk_control.recovery_probe_gap_seconds)
        else:
            next_probe = now

    if account.douyin_id:
        platform_account_id = account.douyin_id
        platform_account_id_label = {
            "douyin": "抖音号", "xhs": "小红书号",
            "kuaishou": "快手号", "shipinhao": "视频号",
        }.get(account.platform, "账号 ID")
    else:
        platform_account_id = account.sec_uid
        platform_account_id_label = {
            "douyin": "sec_uid", "xhs": "user_id",
            "kuaishou": "user_id", "shipinhao": "finder_id",
        }.get(account.platform, "账号 ID")
    return {
        "account_id": account.id,
        "platform_account_id": platform_account_id,
        "platform_account_id_label": platform_account_id_label,
        "nickname": account.nickname,
        "platform": account.platform,
        "account_status": account.status,
        "status": status_code,
        "status_label": status_label,
        "status_tone": status_tone,
        "risk_level": risk_level,
        "reason": reason,
        "cooldown_until": _risk_iso(cooldown_until),
        "cooldown_remaining_seconds": max(
            0, int((cooldown_until - now).total_seconds()))
            if cooldown_until else 0,
        "next_probe_at": _risk_iso(next_probe),
        "recovery_successes": recovery_successes,
        "recovery_target": recovery_target,
        "last_risk_at": _risk_iso(state.last_risk_at if state else None),
        "last_operation_at": _risk_iso(state.last_operation_at if state else None),
        "manual_review_required": bool(state and state.manual_review_required),
        "retry_not_before": _risk_iso(state.retry_not_before if state else None),
        "operation_not_before": _risk_iso(state.operation_not_before if state else None),
        "session_rest_until": _risk_iso(state.session_rest_until if state else None),
        "session_operation_count": state.session_operation_count if state else 0,
        "last_operation_kind": latest_event.operation_kind if latest_event else "",
        "proxy": _mask_proxy(account.proxy),
        "proxy_status": account.proxy_status,
        "network_key": latest_event.network_key if latest_event else "",
        "queued_tasks": {
            key: queued[key] for key in (
                "collections", "publishes", "comments", "actions", "total")
        },
        "blocked_tasks": queued["blocked"],
        "blocked_signals": queued["blocked_signals"],
        "task_next_allowed_at": _risk_iso(queued["next_allowed_at"]),
        "latest_block_reason": queued["latest_block_reason"],
    }


def _risk_account_views(session, accounts: list[DouyinAccount],
                        now: datetime) -> list[dict[str, Any]]:
    ids = [account.id for account in accounts]
    states = {row.account_id: row for row in session.exec(
        select(AccountRiskState).where(AccountRiskState.account_id.in_(ids))
    ).all()} if ids else {}
    latest_events: dict[int, RiskEvent] = {}
    if ids:
        for event in session.exec(select(RiskEvent).where(
                RiskEvent.account_id.in_(ids)).order_by(
                    RiskEvent.occurred_at.desc())).all():
            latest_events.setdefault(event.account_id, event)
    rollups = _risk_task_rollups(session, ids)
    return [_account_risk_view(
        account, now, state=states.get(account.id),
        latest_event=latest_events.get(account.id), queued=rollups[account.id])
        for account in accounts]


@app.get("/api/risk-control/config")
async def get_risk_control_config():
    payload = export_risk_settings(cfg)
    payload["admin_token_required"] = _risk_admin_required()
    return payload


class RiskSettingsIn(BaseModel):
    risk_control: Dict[str, Any]
    schedule: Dict[str, Any]


@app.put("/api/risk-control/config")
async def put_risk_control_config(body: RiskSettingsIn, request: Request):
    actor = _require_risk_admin(request)
    before = export_risk_settings(cfg)
    try:
        apply_risk_settings(cfg, body.model_dump())
    except RiskSettingsError as exc:
        raise HTTPException(400, str(exc)) from exc
    save_risk_settings(cfg)
    if engine is not None:
        engine.risk.update_policy(cfg.risk_control)
    after = export_risk_settings(cfg)
    _record_risk_admin_audit(
        "policy_updated", actor=actor,
        detail={"changes": _risk_config_diff(before, after)})
    after["admin_token_required"] = _risk_admin_required()
    return after


@app.get("/api/risk-control/accounts")
async def list_risk_control_accounts(platform: str | None = None):
    now = datetime.utcnow()
    with get_session() as session:
        query = select(DouyinAccount)
        if platform:
            query = query.where(DouyinAccount.platform == platform)
        accounts = session.exec(query.order_by(DouyinAccount.id)).all()
        return _risk_account_views(session, accounts, now)


@app.get("/api/risk-control/summary")
async def get_risk_control_summary(platform: str | None = None):
    now = datetime.utcnow()
    local_now = datetime.now().astimezone()
    today = local_now.replace(hour=0, minute=0, second=0, microsecond=0) \
        .astimezone(timezone.utc).replace(tzinfo=None)
    with get_session() as session:
        query = select(DouyinAccount)
        if platform:
            query = query.where(DouyinAccount.platform == platform)
        accounts = session.exec(query).all()
        rows = _risk_account_views(session, accounts, now)
        ids = [account.id for account in accounts]
        risk_today = 0
        if ids:
            risk_today = len(session.exec(select(RiskEvent.id).where(
                RiskEvent.account_id.in_(ids),
                RiskEvent.outcome == RiskCategory.RISK.value,
                RiskEvent.occurred_at >= today,
            )).all())
    counts = {
        key: sum(1 for row in rows if row["status"] == key)
        for key in ("normal", "cooldown", "recovering", "auth_invalid",
                    "proxy_error", "network_circuit", "write_paused",
                    "verification_required", "network_backoff")
    }
    return {
        "total": len(rows),
        "counts": counts,
        "abnormal": sum(1 for row in rows if row["status"] != "normal"),
        "risk_events_today": risk_today,
        "blocked_tasks": sum(row["blocked_tasks"] for row in rows),
        "policy_enabled": cfg.risk_control.enabled,
        "mode": cfg.risk_control.mode,
        "sampled_at": _risk_iso(now),
    }


@app.get("/api/risk-control/accounts/{account_id}/events")
async def list_account_risk_events(account_id: int, limit: int = 80):
    limit = max(1, min(200, limit))
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if not account:
            raise HTTPException(404, "账号不存在")
        events = session.exec(select(RiskEvent).where(
            RiskEvent.account_id == account_id).order_by(
                RiskEvent.occurred_at.desc()).limit(limit)).all()
        return {
            "account": {"id": account.id, "nickname": account.nickname,
                        "platform": account.platform},
            "events": [{
                "id": event.id,
                "operation_kind": event.operation_kind,
                "outcome": event.outcome,
                "signal": event.signal,
                "detail": event.detail,
                "network_key": event.network_key,
                "occurred_at": _risk_iso(event.occurred_at),
            } for event in events],
        }


@app.post("/api/risk-control/accounts/{account_id}/probe")
async def probe_account_risk(account_id: int, request: Request):
    actor = _require_risk_admin(request)
    result = await refresh_account_profile(account_id)
    woken = 0
    skipped = bool(isinstance(result, dict) and result.get("skipped"))
    if engine is not None and not skipped:
        with get_session() as session:
            state = session.get(AccountRiskState, account_id)
            account = session.get(DouyinAccount, account_id)
            recovered = bool(state is not None and state.risk_level == 0
                             and account and account.status == "active"
                             and account.proxy_status not in {
                                 "bad", "auth_error", "blocked", "drifted"})
        if recovered:
            woken = engine._wake_deferred_tasks(account_id)
    _record_risk_admin_audit(
        "manual_probe", actor=actor, account_id=account_id,
        detail={"skipped": skipped,
                "reason": result.get("reason", "") if isinstance(result, dict) else "",
                "woken_tasks": woken})
    return {"ok": True, "result": result, "woken_tasks": woken}


class RiskClearIn(BaseModel):
    confirmed: bool = False
    reason: str = ""


@app.post("/api/risk-control/accounts/{account_id}/clear")
async def clear_account_risk(account_id: int, body: RiskClearIn, request: Request):
    actor = _require_risk_admin(request)
    reason = body.reason.strip()
    if not body.confirmed or len(reason) < 3:
        raise HTTPException(400, "解除前需要确认并填写至少 3 个字符的原因")
    with get_session() as session:
        if not session.get(DouyinAccount, account_id):
            raise HTTPException(404, "账号不存在")
        state = session.get(AccountRiskState, account_id)
        before = {
            "risk_level": state.risk_level if state else 0,
            "cooldown_until": _risk_iso(state.cooldown_until if state else None),
            "last_risk_reason": state.last_risk_reason if state else "",
            "manual_review_required": bool(state and state.manual_review_required),
            "manual_review_reason": state.manual_review_reason if state else "",
        }
    controller = engine.risk if engine else RiskController(cfg)
    controller.clear_account(account_id, reason=reason, actor=actor)
    woken = engine._wake_deferred_tasks(account_id) if engine else 0
    _record_risk_admin_audit(
        "account_risk_cleared", actor=actor, account_id=account_id,
        detail={"reason": reason, "before": before, "woken_tasks": woken})
    return {"ok": True, "woken_tasks": woken}


@app.get("/api/risk-control/audit")
async def list_risk_admin_audit(limit: int = 100):
    limit = max(1, min(300, limit))
    with get_session() as session:
        rows = session.exec(select(RiskAdminAudit).order_by(
            RiskAdminAudit.created_at.desc()).limit(limit)).all()
        return [{
            "id": row.id, "action": row.action, "account_id": row.account_id,
            "actor": row.actor, "detail": json.loads(row.detail or "{}"),
            "created_at": _risk_iso(row.created_at),
        } for row in rows]


@app.get("/api/accounts/{account_id}/environment")
async def account_browser_environment(account_id: int):
    """Return redacted browser-backend diagnostics for one account."""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:
            raise HTTPException(404, "账号不存在")
        identity = browser.identity_for(account)
    return browser.environment_snapshot(identity, headless=False)


@app.get("/api/browser-backends")
async def list_browser_backends():
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    return browser.backend_catalog()


def _register_runtime_with_manager(runtime: BrowserRuntime | dict) -> None:
    if browser is None:
        return
    item = (_browser_runtime_dict(runtime)
            if isinstance(runtime, BrowserRuntime) else runtime)
    browser.register_fingerprint_runtime(
        item["runtime_id"], item["executable_path"],
        allow_headless=bool(item.get("allow_headless", False)),
        platform=str(item.get("platform") or "auto"),
        version=str(item.get("version") or ""),
        label=str(item.get("name") or ""),
        enabled=bool(item.get("enabled", True)),
    )


def _upsert_browser_runtime(
        session, item: dict, *, name: str = "",
        platform: str = "auto", allow_headless: bool = False,
        enable_new: bool = True) -> tuple[BrowserRuntime, bool]:
    row = session.exec(select(BrowserRuntime).where(
        BrowserRuntime.runtime_id == item["runtime_id"])).first()
    created = row is None
    if row is None:
        row = BrowserRuntime(
            runtime_id=item["runtime_id"],
            enabled=enable_new,
            platform=platform,
            allow_headless=allow_headless,
        )
    row.name = str(name or row.name or item["name"]).strip()[:120]
    row.version = item["version"]
    row.executable_path = item["executable_path"]
    row.file_sha256 = item["file_sha256"]
    row.platform = str(row.platform or platform or "auto")
    row.last_error = ""
    if not row.status:
        row.status = "unknown"
    session.add(row)
    session.commit()
    session.refresh(row)
    return row, created


def _runtime_account_ids(session, runtime_id: str, *, followers: bool = False) -> list[int]:
    rows = session.exec(select(DouyinAccount)).all()
    ids = []
    for account in rows:
        if account.id is None:
            continue
        selected = str(account.browser_runtime_id or "").strip()
        if selected == runtime_id or (followers and not selected):
            effective = (browser.effective_browser_backend(account)
                         if browser is not None else account.browser_backend)
            if effective == "fingerprint_chromium":
                ids.append(account.id)
    return ids


async def _close_runtime_accounts(account_ids: list[int]) -> None:
    for account_id in set(account_ids):
        lease = open_browsers.pop(account_id, None)
        if lease is not None:
            try:
                await lease.close()
            except Exception:
                pass
        if browser is not None:
            try:
                await browser.close_context(account_id)
            except Exception:
                pass


class BrowserRuntimeAddIn(BaseModel):
    executable_path: str
    name: str = ""
    platform: str = "auto"
    allow_headless: bool = False


class BrowserRuntimeScanIn(BaseModel):
    root: str = ""


class BrowserRuntimeUpdateIn(BaseModel):
    name: str | None = None
    enabled: bool | None = None
    is_default: bool | None = None
    allow_headless: bool | None = None


@app.get("/api/browser-runtimes")
async def list_browser_runtimes():
    roots = _browser_runtime_scan_roots()
    with get_session() as session:
        rows = session.exec(select(BrowserRuntime).order_by(
            BrowserRuntime.is_default.desc(), BrowserRuntime.id)).all()
        return {
            "root": roots[0] if roots else "",
            "scan_roots": roots,
            "default_runtime_id": next(
                (row.runtime_id for row in rows if row.is_default), ""),
            "runtimes": [_browser_runtime_dict(row) for row in rows],
        }


@app.post("/api/browser-runtimes")
async def add_browser_runtime(body: BrowserRuntimeAddIn):
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    platform = str(body.platform or "auto").strip().lower()
    if platform not in {"auto", "windows", "linux", "macos"}:
        raise HTTPException(400, "内核平台取值无效")
    try:
        item = runtime_metadata(body.executable_path)
    except (OSError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc
    with get_session() as session:
        row, created = _upsert_browser_runtime(
            session, item, name=body.name, platform=platform,
            allow_headless=body.allow_headless)
        rows = session.exec(select(BrowserRuntime)).all()
        if not any(candidate.is_default for candidate in rows):
            row.is_default = True
            session.add(row)
            session.commit()
            session.refresh(row)
        payload = _browser_runtime_dict(row)
    _register_runtime_with_manager(payload)
    if payload["is_default"]:
        browser.set_default_fingerprint_runtime(payload["runtime_id"])
    return {"ok": True, "created": created, "runtime": payload}


@app.post("/api/browser-runtimes/scan")
async def scan_browser_runtimes(body: BrowserRuntimeScanIn | None = None):
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    requested_root = str(body.root if body else "").strip()
    roots = ([str(Path(requested_root).expanduser().resolve())]
             if requested_root else _browser_runtime_scan_roots())
    if not roots:
        raise HTTPException(400, "请先配置内核目录或输入扫描目录")
    discovered_by_id: dict[str, dict] = {}
    errors = []
    for root in roots:
        try:
            for item in discover_chromium_runtimes(root):
                discovered_by_id[item["runtime_id"]] = item
        except (OSError, ValueError) as exc:
            errors.append(f"{root}: {exc}")
    if requested_root and errors:
        raise HTTPException(400, errors[0])
    discovered = list(discovered_by_id.values())
    payloads = []
    created_count = 0
    with get_session() as session:
        for item in discovered:
            row, created = _upsert_browser_runtime(
                session, item,
                platform=cfg.engine.fingerprint_chromium_platform,
                allow_headless=cfg.engine.fingerprint_chromium_allow_headless)
            payloads.append(_browser_runtime_dict(row))
            created_count += int(created)
        rows = session.exec(select(BrowserRuntime).order_by(BrowserRuntime.id)).all()
        if rows and not any(row.is_default and row.enabled for row in rows):
            default = next((row for row in rows if row.enabled), None)
            if default is not None:
                for row in rows:
                    row.is_default = row.id == default.id
                    session.add(row)
                session.commit()
                payloads = [_browser_runtime_dict(row) for row in session.exec(
                    select(BrowserRuntime).where(
                        BrowserRuntime.runtime_id.in_(
                            [item["runtime_id"] for item in discovered]))).all()]
        default_id = next(
            (row.runtime_id for row in session.exec(select(BrowserRuntime)).all()
             if row.is_default and row.enabled), "")
    for payload in payloads:
        _register_runtime_with_manager(payload)
    if default_id:
        browser.set_default_fingerprint_runtime(default_id)
    return {
        "ok": True, "root": roots[0], "roots": roots,
        "found": len(discovered), "created": created_count,
        "runtimes": payloads, "errors": errors,
    }


@app.put("/api/browser-runtimes/{runtime_id}")
async def update_browser_runtime(runtime_id: str, body: BrowserRuntimeUpdateIn):
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    old_default = ""
    close_ids: list[int] = []
    with get_session() as session:
        row = session.exec(select(BrowserRuntime).where(
            BrowserRuntime.runtime_id == runtime_id)).first()
        if row is None:
            raise HTTPException(404, "内核运行时不存在")
        old_default = next((candidate.runtime_id for candidate in session.exec(
            select(BrowserRuntime)).all() if candidate.is_default), "")
        if body.name is not None:
            row.name = str(body.name or "").strip()[:120] or row.name
        if body.allow_headless is not None:
            row.allow_headless = bool(body.allow_headless)
        if body.enabled is not None:
            row.enabled = bool(body.enabled)
        if body.is_default:
            row.enabled = True
            for candidate in session.exec(select(BrowserRuntime)).all():
                candidate.is_default = candidate.runtime_id == runtime_id
                session.add(candidate)
        elif not row.enabled and row.is_default:
            replacement = session.exec(select(BrowserRuntime).where(
                BrowserRuntime.runtime_id != runtime_id,
                BrowserRuntime.enabled == True).order_by(  # noqa: E712
                    BrowserRuntime.id)).first()
            row.is_default = False
            if replacement is not None:
                replacement.is_default = True
                session.add(replacement)
        session.add(row)
        session.commit()
        rows = session.exec(select(BrowserRuntime)).all()
        payload = _browser_runtime_dict(session.exec(select(BrowserRuntime).where(
            BrowserRuntime.runtime_id == runtime_id)).first())
        default_id = next(
            (candidate.runtime_id for candidate in rows
             if candidate.is_default and candidate.enabled), "")
        close_ids = _runtime_account_ids(
            session, runtime_id,
            followers=(old_default == runtime_id or default_id == runtime_id))
    _register_runtime_with_manager(payload)
    if default_id:
        browser.set_default_fingerprint_runtime(default_id)
    elif browser.default_fingerprint_runtime_id == runtime_id:
        browser.clear_default_fingerprint_runtime()
    await _close_runtime_accounts(close_ids)
    return {"ok": True, "runtime": payload,
            "default_runtime_id": default_id}


@app.post("/api/browser-runtimes/{runtime_id}/test")
async def test_browser_runtime(runtime_id: str):
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as session:
        row = session.exec(select(BrowserRuntime).where(
            BrowserRuntime.runtime_id == runtime_id)).first()
        if row is None:
            raise HTTPException(404, "内核运行时不存在")
        payload = _browser_runtime_dict(row)
    _register_runtime_with_manager(payload)
    checked_at = datetime.utcnow()
    try:
        result = await browser.probe_fingerprint_runtime(
            runtime_id, Path(cfg.engine.profiles_dir) / "_runtime_probes")
    except Exception as exc:
        detail = f"{type(exc).__name__}: {exc}"[:500]
        with get_session() as session:
            row = session.exec(select(BrowserRuntime).where(
                BrowserRuntime.runtime_id == runtime_id)).first()
            if row is not None:
                row.status = "bad"
                row.last_error = detail
                row.last_checked_at = checked_at
                session.add(row)
                session.commit()
        raise HTTPException(400, detail) from exc
    with get_session() as session:
        row = session.exec(select(BrowserRuntime).where(
            BrowserRuntime.runtime_id == runtime_id)).first()
        if row is not None:
            row.status = "ok"
            row.last_error = ""
            row.last_checked_at = checked_at
            session.add(row)
            session.commit()
    return result


@app.delete("/api/browser-runtimes/{runtime_id}")
async def delete_browser_runtime(runtime_id: str):
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as session:
        row = session.exec(select(BrowserRuntime).where(
            BrowserRuntime.runtime_id == runtime_id)).first()
        if row is None:
            raise HTTPException(404, "内核运行时不存在")
        bound = session.exec(select(DouyinAccount).where(
            DouyinAccount.browser_runtime_id == runtime_id)).all()
        if bound:
            raise HTTPException(
                409, f"仍有 {len(bound)} 个账号绑定此内核，请先切换账号环境")
        was_default = row.is_default
        session.delete(row)
        session.commit()
        replacement = session.exec(select(BrowserRuntime).where(
            BrowserRuntime.enabled == True).order_by(  # noqa: E712
                BrowserRuntime.id)).first()
        if was_default and replacement is not None:
            replacement.is_default = True
            session.add(replacement)
            session.commit()
        default_id = replacement.runtime_id if was_default and replacement else next(
            (candidate.runtime_id for candidate in session.exec(
                select(BrowserRuntime)).all() if candidate.is_default), "")
        follower_ids = _runtime_account_ids(
            session, runtime_id, followers=was_default)
    browser.unregister_fingerprint_runtime(runtime_id)
    if default_id:
        browser.set_default_fingerprint_runtime(default_id)
    await _close_runtime_accounts(follower_ids)
    return {"ok": True, "default_runtime_id": default_id}


def _account_fingerprint_payload(account: DouyinAccount) -> dict:
    return {
        "account_id": account.id,
        "fingerprint_id": (account.fp_seed or "")[:12],
        "seed": account.fp_seed,
        "engine_seed": fingerprint_seed_u32(account.fp_seed),
        "source_ip": account.fp_source_ip,
        "country": account.fp_country,
        "region": account.fp_region,
        "city": account.fp_city,
        "timezone": account.timezone_id,
        "locale": account.locale,
        "accept_languages": account.fp_accept_languages,
        "viewport": f"{account.viewport_w}x{account.viewport_h}",
        "viewport_w": account.viewport_w,
        "viewport_h": account.viewport_h,
        "geo": ({"latitude": account.geo_lat, "longitude": account.geo_lon}
                if account.geo_lat or account.geo_lon else None),
        "geo_lat": account.geo_lat,
        "geo_lon": account.geo_lon,
        "platform": account.fp_platform,
        "platform_version": account.fp_platform_version,
        "brand": account.fp_brand,
        "brand_version": account.fp_brand_version,
        "hardware_concurrency": account.fp_hardware_concurrency,
        "gpu_vendor": account.fp_gpu_vendor,
        "gpu_renderer": account.fp_gpu_renderer,
        "disable_spoofing": [
            value for value in account.fp_disable_spoofing.split(",") if value],
        "language_mode": account.fp_language_mode,
        "timezone_mode": account.fp_timezone_mode,
        "viewport_mode": account.fp_viewport_mode,
        "location_mode": account.fp_location_mode,
        "geolocation_permission": account.fp_geolocation_permission,
        "webrtc_mode": account.fp_webrtc_mode,
        "extra_args": account.fp_extra_args,
        "actual_ua": account.ua,
        "generated_at": (account.fp_generated_at.isoformat()
                         if account.fp_generated_at else None),
        "browser_backend": account.browser_backend,
        "browser_runtime_id": account.browser_runtime_id,
        "exit_ip": account.exit_ip,
        "ip_matches_exit": bool(
            account.fp_source_ip and account.exit_ip
            and account.fp_source_ip == account.exit_ip),
    }


@app.get("/api/accounts/{account_id}/fingerprint")
async def account_fingerprint(account_id: int):
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:
            raise HTTPException(404, "账号不存在")
        return _account_fingerprint_payload(account)


class AccountFingerprintUpdateIn(BaseModel):
    seed: str
    source_ip: str = ""
    country: str = ""
    region: str = ""
    city: str = ""
    timezone: str = "Asia/Shanghai"
    locale: str = "zh-CN"
    accept_languages: str = ""
    viewport_w: int = 1280
    viewport_h: int = 800
    geo_lat: float = 0.0
    geo_lon: float = 0.0
    platform: str = ""
    platform_version: str = ""
    brand: str = ""
    brand_version: str = ""
    hardware_concurrency: int = 0
    gpu_vendor: str = ""
    gpu_renderer: str = ""
    disable_spoofing: list[str] = PydanticField(default_factory=list)
    language_mode: str = "auto"
    timezone_mode: str = "auto"
    viewport_mode: str = "auto"
    location_mode: str = "auto"
    geolocation_permission: str = "allow"
    webrtc_mode: str = "conceal"
    extra_args: str = ""


def _validate_fingerprint_update(body: AccountFingerprintUpdateIn) -> dict:
    seed = str(body.seed or "").strip()
    if not seed or len(seed) > 128:
        raise HTTPException(400, "指纹种子长度必须为 1 到 128 个字符")
    source_ip = str(body.source_ip or "").strip()
    if source_ip:
        try:
            source_ip = str(ip_address(source_ip))
        except ValueError as exc:
            raise HTTPException(400, "指纹来源 IP 格式无效") from exc
    timezone_id = str(body.timezone or "").strip()
    try:
        ZoneInfo(timezone_id)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise HTTPException(400, "请输入有效的 IANA 时区") from exc
    locale = str(body.locale or "").strip()
    if not re.fullmatch(r"[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*", locale):
        raise HTTPException(400, "语言格式无效，例如 zh-CN 或 en-US")
    accepted = str(body.accept_languages or "").strip()
    if len(accepted) > 160 or any(ord(char) < 32 for char in accepted):
        raise HTTPException(400, "Accept-Language 格式无效")
    if not 320 <= body.viewport_w <= 7680 \
            or not 240 <= body.viewport_h <= 4320:
        raise HTTPException(400, "窗口尺寸超出允许范围")
    if not -90 <= body.geo_lat <= 90 or not -180 <= body.geo_lon <= 180:
        raise HTTPException(400, "地理坐标超出允许范围")
    platform = str(body.platform or "").strip().lower()
    if platform not in {"", "windows", "linux", "macos"}:
        raise HTTPException(400, "操作系统类型取值无效")
    version_pattern = r"[0-9A-Za-z._-]{0,40}"
    platform_version = str(body.platform_version or "").strip()
    brand_version = str(body.brand_version or "").strip()
    if not re.fullmatch(version_pattern, platform_version) \
            or not re.fullmatch(version_pattern, brand_version):
        raise HTTPException(400, "平台或浏览器版本格式无效")
    brand = str(body.brand or "").strip()
    if len(brand) > 40 or (brand and not re.fullmatch(r"[\w .-]+", brand)):
        raise HTTPException(400, "浏览器品牌格式无效")
    if body.hardware_concurrency != 0 \
            and not 1 <= body.hardware_concurrency <= 256:
        raise HTTPException(400, "CPU 核心数必须为 1 到 256，0 表示自动")
    gpu_vendor = str(body.gpu_vendor or "").strip()
    gpu_renderer = str(body.gpu_renderer or "").strip()
    if len(gpu_vendor) > 160 or len(gpu_renderer) > 240 \
            or any(ord(char) < 32 for char in gpu_vendor + gpu_renderer):
        raise HTTPException(400, "GPU 指纹文本格式无效")
    allowed_spoofing = {"font", "audio", "canvas", "clientrects", "gpu"}
    disabled = []
    for value in body.disable_spoofing:
        name = str(value or "").strip().lower()
        if name not in allowed_spoofing:
            raise HTTPException(400, f"未知指纹模块: {name}")
        if name not in disabled:
            disabled.append(name)
    modes = {
        "fp_language_mode": (body.language_mode, {"auto", "custom"}, "语言模式"),
        "fp_timezone_mode": (body.timezone_mode, {"auto", "custom"}, "时区模式"),
        "fp_viewport_mode": (body.viewport_mode, {"auto", "custom"}, "窗口模式"),
        "fp_location_mode": (body.location_mode, {"auto", "custom"}, "位置模式"),
        "fp_geolocation_permission": (
            body.geolocation_permission, {"ask", "allow", "deny"}, "地理位置权限"),
        "fp_webrtc_mode": (body.webrtc_mode, {"conceal", "allow"}, "WebRTC 模式"),
    }
    normalized_modes = {}
    for field_name, (raw_value, allowed, label) in modes.items():
        selected = str(raw_value or "").strip().lower()
        if selected not in allowed:
            raise HTTPException(400, f"{label}取值无效")
        normalized_modes[field_name] = selected
    extra_args = str(body.extra_args or "").strip()
    try:
        parse_extra_launch_args(extra_args)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    def _short(value: str, field: str) -> str:
        result = str(value or "").strip()
        if len(result) > 100:
            raise HTTPException(400, f"{field}长度超过限制")
        return result
    result = {
        "fp_seed": seed,
        "fp_source_ip": source_ip,
        "fp_country": _short(body.country, "国家/地区"),
        "fp_region": _short(body.region, "区域"),
        "fp_city": _short(body.city, "城市"),
        "timezone_id": timezone_id,
        "locale": locale,
        "fp_accept_languages": accepted,
        "viewport_w": body.viewport_w,
        "viewport_h": body.viewport_h,
        "geo_lat": body.geo_lat,
        "geo_lon": body.geo_lon,
        "fp_platform": platform,
        "fp_platform_version": platform_version,
        "fp_brand": brand,
        "fp_brand_version": brand_version,
        "fp_hardware_concurrency": body.hardware_concurrency,
        "fp_gpu_vendor": gpu_vendor,
        "fp_gpu_renderer": gpu_renderer,
        "fp_disable_spoofing": ",".join(disabled),
        "fp_extra_args": extra_args,
    }
    result.update(normalized_modes)
    return result


@app.put("/api/accounts/{account_id}/fingerprint")
async def update_account_fingerprint(
        account_id: int, body: AccountFingerprintUpdateIn):
    fields = _validate_fingerprint_update(body)
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:
            raise HTTPException(404, "账号不存在")
        for name, value in fields.items():
            setattr(account, name, value)
        account.fp_generated_at = datetime.utcnow()
        session.add(account)
        session.commit()
        session.refresh(account)
        payload = _account_fingerprint_payload(account)
    lease = open_browsers.pop(account_id, None)
    if lease is not None:
        try:
            await lease.close()
        except Exception:
            pass
    if browser is not None:
        await browser.close_context(account_id)
    return {"ok": True, "fingerprint": payload}


@app.post("/api/accounts/{account_id}/fingerprint/from-ip")
async def generate_account_fingerprint_from_ip(account_id: int):
    """Probe the current egress and persist a stable, locality-aligned device."""
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:
            raise HTTPException(404, "账号不存在")
        proxy = account.proxy or ""
        fallback = {
            "ip": account.exit_ip,
            "country": account.exit_country or account.fp_country,
            "region": account.fp_region,
            "city": account.fp_city,
            "timezone": account.exit_timezone or account.timezone_id,
            "lat": account.geo_lat,
            "lon": account.geo_lon,
        }

    geo = await _proxy_geo(proxy)
    if not geo or not geo.get("ip"):
        geo = fallback if fallback.get("ip") else None
    if not geo:
        raise HTTPException(400, "未取得当前出口 IP，请先确认代理可用后重试")

    try:
        fields = derive_ip_fingerprint(
            account_id,
            geo.get("ip", ""),
            country=geo.get("country", ""),
            region=geo.get("region", ""),
            city=geo.get("city", ""),
            timezone_id=geo.get("timezone", ""),
            latitude=geo.get("lat") or 0.0,
            longitude=geo.get("lon") or 0.0,
            fallback_timezone=fallback.get("timezone") or "Asia/Shanghai",
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:
            raise HTTPException(404, "账号不存在")
        account.fp_seed = fields["fp_seed"]
        account.fp_source_ip = fields["source_ip"]
        account.fp_country = fields["country"]
        account.fp_region = fields["region"]
        account.fp_city = fields["city"]
        account.fp_generated_at = datetime.utcnow()
        account.timezone_id = fields["timezone_id"]
        account.locale = fields["locale"]
        account.viewport_w = fields["viewport_w"]
        account.viewport_h = fields["viewport_h"]
        account.geo_lat = fields["geo_lat"]
        account.geo_lon = fields["geo_lon"]
        # “按 IP 自动生成”同时恢复内核的种子派生值；之后仍可在编辑器逐项覆盖。
        account.fp_platform = ""
        account.fp_platform_version = ""
        account.fp_brand = ""
        account.fp_brand_version = ""
        account.fp_hardware_concurrency = 0
        account.fp_gpu_vendor = ""
        account.fp_gpu_renderer = ""
        account.fp_accept_languages = ""
        account.fp_disable_spoofing = ""
        account.fp_language_mode = "auto"
        account.fp_timezone_mode = "auto"
        account.fp_viewport_mode = "auto"
        account.fp_location_mode = "auto"
        account.fp_geolocation_permission = "allow"
        account.fp_webrtc_mode = "conceal"
        account.fp_extra_args = ""
        session.add(account)
        session.commit()
        session.refresh(account)
        payload = _account_fingerprint_payload(account)

    # A running context was created with the old engine seed/timezone.  Release
    # both user-opened and background contexts before returning the new device.
    lease = open_browsers.pop(account_id, None)
    if lease is not None:
        try:
            await lease.close()
        except Exception:
            pass
    if browser is not None:
        await browser.close_context(account_id)
    return {"ok": True, "fingerprint": payload}


class AccountBrowserBackendIn(BaseModel):
    browser_backend: str
    browser_runtime_id: str = ""


@app.put("/api/accounts/{account_id}/browser-backend")
async def set_account_browser_backend(
        account_id: int, body: AccountBrowserBackendIn):
    """Select an account runtime and close any context using the old one."""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    requested = str(body.browser_backend or "").strip().lower()
    runtime_id = str(body.browser_runtime_id or "").strip()
    if requested not in ACCOUNT_BROWSER_BACKENDS:
        raise HTTPException(400, "浏览器后端取值无效")
    status = _browser_backend_status(requested, runtime_id)
    if not status["available"]:
        raise HTTPException(
            400, f"浏览器后端不可用:{status['detail']}")

    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:
            raise HTTPException(404, "账号不存在")
        if account.platform == "xhs" and status.get("name") != LOCAL_BACKEND:
            raise HTTPException(
                400,
                "小红书账号仅支持系统 Chrome/CDP 原生环境，不能切换到指纹内核",
            )

    # A user-held headed context owns the same profile and must be released
    # before switching its runtime executable.
    lease = open_browsers.pop(account_id, None)
    if lease is not None:
        try:
            await lease.close()
        except Exception:
            pass

    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if account is None:  # pragma: no cover - guarded above; handles races
            raise HTTPException(404, "账号不存在")
        account.browser_backend = requested
        account.browser_runtime_id = (
            runtime_id if requested == "fingerprint_chromium" else "")
        session.add(account)
        session.commit()
        session.refresh(account)
        identity = browser.identity_for(account)

    await browser.close_context(account_id)
    environment = browser.environment_snapshot(identity, headless=False)
    return {
        "ok": True,
        "browser_backend": requested,
        "browser_runtime_id": identity.browser_runtime_id,
        "effective_backend": status["name"],
        "environment": environment,
    }


def _mask_proxy(proxy: str) -> str:
    """脱敏展示代理(隐藏账号密码)。"""
    if not proxy:
        return ""
    try:
        from urllib.parse import urlparse
        u = urlparse(proxy if "://" in proxy else "http://" + proxy)
        host = u.hostname or ""
        port = f":{u.port}" if u.port else ""
        auth = "***@" if u.username else ""
        return f"{u.scheme}://{auth}{host}{port}"
    except Exception:
        return "***"


@app.delete("/api/accounts/{account_id}")
async def del_account(account_id: int):
    pdir = ""
    shared_profile = False
    runtime_cleanup_error = ""
    counts = {"canceled_tasks": 0, "disabled_rules": 0, "disabled_monitors": 0}
    if any(state.get("account_id") == account_id
           and state.get("status") in _ACTIVE_LOGIN_STATUSES
           for state in login_tasks.values()):
        raise HTTPException(409, "该账号正在登录，请先完成或关闭登录窗口")
    lock_for = getattr(browser, "lock_for", None)
    lock = lock_for(f"acc:{account_id}") if callable(lock_for) else asyncio.Lock()
    if lock.locked():
        raise HTTPException(409, "该账号有操作正在执行，请等待完成后删除")
    async with lock:
        with get_session() as s:
            acc = s.get(DouyinAccount, account_id)
            if acc:
                active = active_account_task(s, account_id)
                if active:
                    raise HTTPException(409, active)
                pdir = acc.profile_dir or ""
                if pdir:
                    key = os.path.normcase(str(Path(pdir).expanduser().resolve()))
                    shared_profile = any(
                        other.profile_dir and os.path.normcase(str(
                            Path(other.profile_dir).expanduser().resolve())) == key
                        for other in s.exec(select(DouyinAccount).where(
                            DouyinAccount.id != account_id)).all())
                counts = retire_account_tasks(s, account_id)
                risk_state = s.get(AccountRiskState, account_id)
                if risk_state:
                    s.delete(risk_state)
                # Keep task/content history and RiskEvent audit records. The
                # independent ID reservation prevents reassignment to new users.
                s.delete(acc)
                s.commit()
        for manager in (getattr(engine, "dm_automation", None), im_receiver):
            stop_account = getattr(manager, "stop_account", None)
            if callable(stop_account):
                try:
                    await stop_account(account_id)
                except Exception:
                    runtime_cleanup_error = "账号已删除；后台监听清理失败，已保留 Profile，请重启服务后清理"
        await _close_runtime_accounts([account_id])
    # 删号同时清理其持久 profile(释放磁盘);代理回到池里(占用计数自然下降)
    profile_removed = False
    profile_cleanup_error = runtime_cleanup_error
    if pdir:
        root = Path(cfg.engine.profiles_dir).expanduser().resolve()
        candidate = Path(pdir).expanduser().resolve()
        try:
            candidate.relative_to(root)
            managed = candidate != root
        except ValueError:
            managed = False
        if runtime_cleanup_error:
            pass
        elif shared_profile:
            profile_cleanup_error = "其他账号仍使用此 Profile，已保留目录"
        elif managed:
            try:
                if candidate.exists():
                    shutil.rmtree(candidate)
                profile_removed = True
            except OSError as exc:
                profile_cleanup_error = str(exc)[:240]
        else:
            profile_cleanup_error = "Profile 不在受管目录内，已跳过磁盘清理"
    return {
        "ok": True,
        "profile_removed": profile_removed,
        "profile_cleanup_error": profile_cleanup_error,
        **counts,
    }


@app.post("/api/accounts/{account_id}/refresh-profile")
async def refresh_account_profile(account_id: int):
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        state = acc.storage_state or acc.creator_storage_state
        platform = acc.platform
        creator_state = acc.creator_storage_state or ""
        profile_transport = (resolve_transport(
            cfg, "douyin", "account_profile", acc)
            if platform == "douyin" else None)
    manual_browser = open_browsers.get(account_id)
    if (manual_browser is not None
            and bool(getattr(manual_browser, "active", True))
            and (profile_transport is None or profile_transport["opens_browser"])):
        return {
            "ok": True,
            "skipped": True,
            "reason": "该账号浏览器窗口仍开着，请先关闭窗口再刷新资料",
            "blocked_by": "open_browser",
        }
    if not state:
        raise HTTPException(400, "该账号无浏览器登录态(Cookie 粘贴账号可能不含完整态),无法拉取资料")

    async def _refresh_profile():
        return await _enrich_account_profile(
            account_id, state, detailed=True)

    res, outcome = await _run_account_read(
        account_id, OperationKind.READ_LIGHT,
        f"refresh-profile:{account_id}", _refresh_profile,
        empty_result={"ok": True}, allow_invalid_probe=True)
    if isinstance(outcome, dict):
        return outcome
    if res == "invalid":
        raise HTTPException(400, "登录态已失效,请点「重新登录」")
    if res != "ok":
        tag = ("[xhs_self_profile]" if platform == "xhs"
               else "[ks_self_profile]" if platform == "kuaishou"
               else "[self_profile]")
        raise HTTPException(400, f"未能获取账号资料:请看服务端控制台 {tag} 那行日志"
                                 "(含它实际看到的请求),把它发我即可定位")
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        has_read_login = (
            _xhs_has_read_login_state(acc.storage_state)
            if acc and acc.platform == "xhs"
            else bool(acc and acc.storage_state)
        )
        has_creator_login = bool(acc and (
            acc.creator_storage_state
            or (acc.platform in ("kuaishou", "douyin", "shipinhao")
                and acc.storage_state)
            or (acc.platform == "xhs" and has_creator_cookies(acc.storage_state))
        ))
        return {"ok": True, "nickname": acc.nickname, "platform": acc.platform,
                "douyin_id": acc.douyin_id, "sec_uid": acc.sec_uid,
                "status": acc.status,
                "login_scope": ("creator" if platform == "xhs" and creator_state
                                  else "read"),
                "has_read_login": has_read_login,
                "has_creator": has_creator_login}


@app.post("/api/accounts/{account_id}/relogin/start")
async def relogin_start(account_id: int, scope: str = "auto"):
    """重新登录:更新原账号的登录态(账号是创作者号则走创作中心)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        platform = acc.platform
        requested_scope = str(scope or "auto").strip().lower()
        if requested_scope not in {"auto", "read", "creator"}:
            raise HTTPException(400, "登录范围取值无效")
        if platform == "xhs" and requested_scope != "auto":
            is_creator = requested_scope == "creator"
        else:
            is_creator = bool(acc.creator_storage_state)

    reused = await _reuse_or_reject_interactive_login(
        platform, is_creator, account_id)
    if reused is not None:
        reused["login_scope"] = "creator" if is_creator else "read"
        return reused

    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        # 重登会清空旧认证 Cookie；完成扫码校验前账号不应继续显示“正常”。
        other_scope_available = (
            platform == "xhs" and (
                (not is_creator and bool(acc.creator_storage_state))
                or (is_creator and _xhs_has_read_login_state(acc.storage_state))
            )
        )
        if not other_scope_available:
            acc.status = "invalid"
        s.add(acc)
        s.commit()
    task_id = uuid.uuid4().hex
    login_tasks[task_id] = _login_task_state(
        status="opening", platform=platform, creator=is_creator,
        account_id=account_id)
    asyncio.create_task(_run_login(task_id, creator=is_creator, account_id=account_id,
                                   platform=platform))
    return {"task_id": task_id, "status": "opening",
            "login_scope": "creator" if is_creator else "read",
            "hint": "已打开浏览器窗口,请扫码重新登录该账号"}


# ─────────── 本账号管理:作品 ───────────
def _work_dict(w: AccountWork) -> dict:
    return {
        "id": w.id, "platform": w.platform, "account_id": w.account_id,
        "item_id": w.item_id, "desc": w.desc, "media_type": w.media_type,
        "cover_url": w.cover_url, "create_time": w.create_time,
        "like_count": w.like_count, "comment_count": w.comment_count,
        "collect_count": w.collect_count, "share_count": w.share_count,
        "play_count": w.play_count, "status": w.status,
        "fetched_at": w.fetched_at.isoformat() if w.fetched_at else None,
    }


@app.get("/api/account-works")
async def list_account_works(account_id: int, limit: int = 200):
    with get_session() as s:
        q = (select(AccountWork).where(AccountWork.account_id == account_id)
             .order_by(AccountWork.create_time.desc()).limit(limit))
        return [_work_dict(w) for w in s.exec(q).all()]


@app.post("/api/accounts/{account_id}/works/sync")
async def sync_account_works(account_id: int):
    """打开账号自己的主页,拦截抓取本账号已发布作品,落库(upsert)。"""
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        if acc.status == "invalid":
            raise HTTPException(400, "账号登录态已失效")
        if engine._proxy_bad(acc):
            raise HTTPException(400, "账号代理不可用")
        platform = acc.platform
        uid = acc.sec_uid or ""
        transport = (resolve_transport(cfg, "douyin", "account_works", acc)
                     if platform == "douyin" else None)
        effective_mode = transport["effective_mode"] if transport else "browser"
        if browser is None and effective_mode in {"browser", "hybrid"}:
            raise HTTPException(503, "浏览器未就绪")
        identity = (None if platform == "douyin" and effective_mode == "api"
                    else browser.identity_for(acc))
        direct_ua = (identity.ua if identity is not None
                     else (acc.ua or cfg.engine.user_agent))
        direct_environment = douyin_client_environment(
            identity if identity is not None else acc)
        source = "api" if effective_mode == "api" else "browser"
    async def _fetch():
        nonlocal source
        if platform == "douyin" and effective_mode in {"api", "hybrid"}:
            cookie = douyin_cookie_from_state(acc.storage_state or acc.creator_storage_state or "")
            api_items, api_err = await fetch_douyin_account_works_api(
                cookie, direct_ua, uid,
                timeout=cfg.engine.request_timeout_seconds, proxy=acc.proxy or "",
                environment=direct_environment)
            if api_items or effective_mode == "api" or api_err == "empty":
                source = "api"
                return api_items, api_err
            print(f"[dy-account-works] API 空响应({api_err}),回退浏览器")
            source = "browser_fallback"
        else:
            source = "browser"
        return await fetch_account_works(browser, identity, platform, uid)

    items, err = await engine.guarded_read_pair(
        account_id, OperationKind.READ_LIGHT, f"account-works:{account_id}",
        _fetch, empty_result=[])
    if err.startswith("risk_deferred:"):
        return {"ok": True, "fetched": 0, "added": 0, "skipped": True,
                "reason": err.split(":", 1)[-1], "source": "deferred",
                "configured_mode": (transport["configured_mode"]
                                    if transport else "browser")}
    if not items:
        if err and err.startswith("missing_uid"):
            raise HTTPException(400, err.split(":", 1)[-1])
        raise HTTPException(400, f"未抓到作品:{err or '可能登录态失效/无公开作品'}"
                                 "(详情见服务端控制台日志)")
    now = datetime.utcnow()
    added = 0
    with get_session() as s:
        for w in items:
            existing = s.exec(select(AccountWork).where(
                AccountWork.account_id == account_id,
                AccountWork.item_id == w["item_id"])).first()
            if existing:
                for k, v in w.items():
                    setattr(existing, k, v)
                existing.fetched_at = now
                s.add(existing)
            else:
                s.add(AccountWork(platform=platform, account_id=account_id,
                                  fetched_at=now, **w))
                added += 1
        s.commit()
    return {"ok": True, "fetched": len(items), "added": added,
            "source": source,
            "configured_mode": (transport["configured_mode"]
                                if transport else "browser")}


# ─────────── 本账号数据分析(B4:粉丝/作品/互动趋势 + 单篇作品表)───────────
@app.get("/api/account-stats/{account_id}")
async def account_stats(account_id: int, days: int = 30):
    """返回该账号近 days 天的每日快照趋势 + 当前本账号作品的单篇互动明细。
    快照由引擎在账号体检/作品健康时写入(见 EngineConfig.work_health_*)。"""
    days = max(1, min(days, 180))
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        snaps = s.exec(select(AccountStatSnapshot)
                       .where(AccountStatSnapshot.account_id == account_id)
                       .order_by(AccountStatSnapshot.date.desc()).limit(days)).all()
        works = s.exec(select(AccountWork)
                       .where(AccountWork.account_id == account_id)
                       .order_by(AccountWork.create_time.desc()).limit(50)).all()
    trend = [{"date": x.date, "follower_count": x.follower_count,
              "aweme_count": x.aweme_count, "total_like": x.total_like,
              "total_comment": x.total_comment, "total_play": x.total_play}
             for x in reversed(snaps)]
    latest = trend[-1] if trend else {}
    prev = trend[-2] if len(trend) >= 2 else {}
    fans_delta = (latest.get("follower_count", 0) - prev.get("follower_count", 0)
                  if prev else 0)
    return {
        "account": {"id": acc.id, "platform": acc.platform, "nickname": acc.nickname,
                    "follower_count": acc.follower_count, "aweme_count": acc.aweme_count},
        "fans_delta": fans_delta,
        "trend": trend,
        "works": [_work_dict(w) for w in works],
    }


# ─────────── 本账号管理:作品评论(抖音直连分页 / 小红书客户端 / 快手拦截)───────────
@app.get("/api/account-works/{work_id}/comments")
async def list_work_comments(work_id: int, limit: int = 300):
    with get_session() as s:
        w = s.get(AccountWork, work_id)
        if not w:
            raise HTTPException(404, "作品不存在")
        item_id = w.item_id
        rows = s.exec(select(CommentRecord).where(
            CommentRecord.watch_id == 0,
            CommentRecord.aweme_id == item_id)
            .order_by(CommentRecord.id.desc()).limit(limit)).all()
        return [_comment_dict(c) for c in rows]


@app.post("/api/account-works/{work_id}/comments/sync")
async def sync_work_comments(work_id: int):
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    with get_session() as s:
        w = s.get(AccountWork, work_id)
        if not w:
            raise HTTPException(404, "作品不存在")
        platform, item_id = w.platform, w.item_id
        account_id, xsec_token = w.account_id, w.xsec_token
    res = await engine.sync_work_comments(account_id, platform, item_id, xsec_token)
    if not res.get("ok") and not res.get("added"):
        raise HTTPException(400, f"抓评论失败:{res.get('error') or '未知'}"
                                 "(详情见服务端控制台日志)")
    return res


# ─────────── 本账号管理:作品弹幕(抖音创作者中心)───────────
@app.get("/api/account-works/{work_id}/danmaku")
async def list_work_danmaku(work_id: int, limit: int = 300):
    with get_session() as s:
        w = s.get(AccountWork, work_id)
        if not w:
            raise HTTPException(404, "作品不存在")
        rows = s.exec(select(DanmakuRecord).where(
            DanmakuRecord.watch_id == 0,
            DanmakuRecord.aweme_id == w.item_id)
            .order_by(DanmakuRecord.id.desc()).limit(limit)).all()
        return [_danmaku_dict(row) for row in rows]


@app.post("/api/account-works/{work_id}/danmaku/sync")
async def sync_work_danmaku(work_id: int):
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    with get_session() as s:
        w = s.get(AccountWork, work_id)
        if not w:
            raise HTTPException(404, "作品不存在")
        platform, item_id, account_id = w.platform, w.item_id, w.account_id
    res = await engine.sync_work_danmaku(account_id, platform, item_id)
    if not res.get("ok") and not res.get("added"):
        raise HTTPException(400, f"抓弹幕失败:{res.get('error') or '未知'}"
                                 "(详情见服务端控制台日志)")
    return res


# ─────────── 本账号管理:关注 / 粉丝 ───────────
def _follow_dict(f: FollowEdge) -> dict:
    return {
        "id": f.id, "platform": f.platform, "account_id": f.account_id,
        "direction": f.direction, "uid": f.uid, "sec_uid": f.sec_uid,
        "nickname": f.nickname, "avatar": f.avatar, "signature": f.signature,
        "is_mutual": f.is_mutual, "is_following": f.is_following,
        "fetched_at": f.fetched_at.isoformat() if f.fetched_at else None,
    }


@app.get("/api/follows")
async def list_follows(account_id: int, direction: str = "following",
                       page: int = 1, page_size: int = 50,
                       query: str = ""):
    if direction not in ("following", "fan"):
        raise HTTPException(400, "direction 仅支持 following | fan")
    page = max(1, int(page or 1))
    page_size = max(1, min(int(page_size or 50), 200))
    query = " ".join(str(query or "").strip().split())[:100]
    filters = [FollowEdge.account_id == account_id,
               FollowEdge.direction == direction]
    if query:
        match = f"%{query}%"
        filters.append(or_(FollowEdge.nickname.like(match),
                           FollowEdge.uid.like(match),
                           FollowEdge.sec_uid.like(match),
                           FollowEdge.signature.like(match)))
    with get_session() as s:
        total = int(s.exec(select(func.count(FollowEdge.id)).where(
            *filters)).one() or 0)
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(page, pages)
        rows = s.exec(
            select(FollowEdge).where(*filters)
            .order_by(FollowEdge.id.desc())
            .offset((page - 1) * page_size).limit(page_size)).all()
        synced_at = s.exec(select(func.max(FollowEdge.fetched_at)).where(
            FollowEdge.account_id == account_id,
            FollowEdge.direction == direction)).one()
    return {
        "items": [_follow_dict(row) for row in rows],
        "total": total, "page": page, "page_size": page_size,
        "pages": pages,
        "synced_at": synced_at.isoformat() if synced_at else None,
    }


@app.get("/api/follows/{edge_id}")
async def get_follow(edge_id: int, account_id: int):
    with get_session() as s:
        row = s.get(FollowEdge, edge_id)
        if not row or row.account_id != account_id:
            raise HTTPException(404, "关注关系不存在")
        return _follow_dict(row)


def _replace_follow_snapshot(account_id: int, platform: str, direction: str,
                             users: list[dict], now: datetime,
                             progress=None) -> tuple[int, int]:
    incoming: dict[str, dict] = {}
    for user in users:
        uid = str(user.get("uid") or "")
        if uid:
            incoming[uid] = user
    with get_session() as s:
        known = set(s.exec(select(FollowEdge.uid).where(
            FollowEdge.account_id == account_id,
            FollowEdge.direction == direction)).all())
        # Delete + insert stays in one transaction: readers keep seeing the old
        # snapshot until the complete replacement commits, and failures roll back.
        s.execute(delete(FollowEdge).where(
            FollowEdge.account_id == account_id,
            FollowEdge.direction == direction))
        mappings = []
        total = len(incoming)
        for index, (uid, user) in enumerate(incoming.items(), 1):
            mappings.append({
                "platform": platform, "account_id": account_id,
                "direction": direction, "uid": uid,
                "sec_uid": str(user.get("sec_uid") or ""),
                "nickname": str(user.get("nickname") or ""),
                "avatar": str(user.get("avatar") or ""),
                "signature": str(user.get("signature") or ""),
                "is_mutual": bool(user.get("is_mutual")),
                "is_following": bool(user.get("is_following")),
                "raw_json": str(user.get("raw_json") or ""),
                "fetched_at": now, "created_at": now,
            })
            if len(mappings) >= 1000 or index == total:
                s.bulk_insert_mappings(FollowEdge, mappings)
                mappings.clear()
                if progress is not None:
                    progress({"phase": "saving", "saved": index,
                              "fetched": total})
        s.commit()
    return sum(1 for uid in incoming if uid not in known), total


async def _sync_follows_impl(account_id: int, direction: str = "following",
                             progress=None):
    if direction not in ("following", "fan"):
        raise HTTPException(400, "direction 仅支持 following | fan")

    def report(**changes):
        if progress is not None:
            progress(changes)

    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        platform = acc.platform
        uid = acc.sec_uid or ""
        operation = "following_list" if direction == "following" else "followers_list"
        transport = (resolve_transport(cfg, "douyin", operation, acc)
                     if platform == "douyin" else None)
        effective_mode = (transport["effective_mode"] if transport else "browser")
        if effective_mode == "unavailable":
            raise HTTPException(
                409,
                f"当前读取方式与{('关注' if direction == 'following' else '粉丝')}列表不兼容："
                f"{transport.get('reason') or transport.get('note') or '该通道不可用'}")
        if browser is None and effective_mode in {"browser", "hybrid"}:
            raise HTTPException(503, "浏览器未就绪")
        if platform == "douyin" and effective_mode in {"api", "hybrid"} \
                and engine is None:
            raise HTTPException(503, "抖音 API 读取引擎未就绪")
        identity = (None if platform == "douyin" and effective_mode == "api"
                    else browser.identity_for(acc))
        known: set[str] = set()
    # API-only/browser-only are hard routing decisions. Hybrid's API attempt and
    # page fallback share one READ_HEAVY guard so the fallback is not blocked by
    # the API attempt's own minimum interval.
    users, err = [], ""
    source = "api" if effective_mode == "api" else "browser"

    async def _fetch_follow_snapshot():
        nonlocal source
        direct_err = ""
        if platform == "douyin" and effective_mode in {"api", "hybrid"}:
            report(phase="fetching", source="api")
            try:
                if progress is None:
                    direct_users, direct_err = (
                        await engine._fetch_douyin_follows_direct_locked(
                            account_id, direction))
                else:
                    def direct_progress(update):
                        report(phase="fetching", source="api", **update)

                    direct_users, direct_err = (
                        await engine._fetch_douyin_follows_direct_locked(
                            account_id, direction, progress=direct_progress))
            except Exception as e:
                direct_users, direct_err = [], repr(e)
            # “empty”表示结构有效的空列表；empty_body/网络/解析错误不是有效快照。
            if direct_users or direct_err == "empty":
                source = "api"
                return direct_users, direct_err
            if effective_mode == "api":
                source = "api"
                return [], direct_err or "empty_response"
            print(f"[follow] douyin direct 空({direct_err}),回退浏览器拦截")

        source = "browser_fallback" if effective_mode == "hybrid" else "browser"
        report(phase="fetching", source=source)
        browser_users, browser_err = await fetch_follows(
            browser, identity, platform, uid, direction, known)
        if browser_users:
            return browser_users, ""
        return browser_users, (browser_err or direct_err)

    if engine is not None:
        users, err = await engine.guarded_read_pair(
            account_id, OperationKind.READ_HEAVY,
            f"follows-sync:{account_id}:{direction}",
            _fetch_follow_snapshot, empty_result=[])
    else:
        users, err = await _fetch_follow_snapshot()

    if err.startswith("risk_deferred:"):
        return {"ok": True, "fetched": 0, "added": 0,
                "skipped": True, "reason": err.split(":", 1)[-1],
                "source": "deferred",
                "configured_mode": (transport["configured_mode"]
                                    if transport else "browser")}
    if err and err.startswith("missing_uid"):
        raise HTTPException(400, err.split(":", 1)[-1])
    if err and err.startswith("logged_out"):
        raise HTTPException(400, "登录态已失效,请点「重新登录」")
    # 只有明确解析到平台的有效空列表("empty")才允许清空旧快照。超时、空 body、
    # 未命中接口等不确定结果必须保留旧数据，并把真实失败显示给前端。
    if err and err != "empty":
        label = "关注" if direction == "following" else "粉丝"
        raise HTTPException(502, f"{label}同步未取得有效列表，已保留原数据：{err}")
    now = datetime.utcnow()
    report(phase="saving", fetched=len(users), saved=0)
    added, stored = await asyncio.to_thread(
        _replace_follow_snapshot, account_id, platform, direction,
        users, now, progress)
    return {"ok": True, "fetched": len(users), "stored": stored,
            "added": added, "complete": True,
            "source": source,
            "configured_mode": (transport["configured_mode"]
                                 if transport else "browser")}


@app.post("/api/accounts/{account_id}/follows/sync")
async def sync_follows(account_id: int, direction: str = "following"):
    return await _sync_follows_impl(account_id, direction)


def _follow_sync_job_view(job: dict) -> dict:
    view = dict(job)
    expected = max(0, int(view.get("expected_total") or 0))
    fetched = max(0, int(view.get("fetched") or 0))
    if view.get("status") == "completed":
        percent = 100
    elif expected:
        percent = min(99, int(fetched * 100 / expected))
    else:
        percent = None
    view["percent"] = percent
    view["cancelable"] = (view.get("status") in {"queued", "running"}
                          and view.get("phase") != "saving")
    return view


async def _run_follow_sync_job(job_id: str):
    job = _follow_sync_jobs[job_id]

    def update(changes: dict):
        job.update(changes)
        job["updated_at"] = datetime.utcnow().isoformat()

    update({"status": "running", "phase": "fetching"})
    try:
        result = await _sync_follows_impl(
            int(job["account_id"]), str(job["direction"]), progress=update)
        if result.get("skipped"):
            update({"status": "deferred", "phase": "deferred",
                    "error": str(result.get("reason") or "同步暂缓"),
                    "result": result,
                    "completed_at": datetime.utcnow().isoformat()})
            return
        update({"status": "completed", "phase": "completed",
                "fetched": int(result.get("fetched") or 0),
                "saved": int(result.get("stored") or 0),
                "added": int(result.get("added") or 0),
                "source": result.get("source") or "",
                "result": result, "completed_at": datetime.utcnow().isoformat()})
    except asyncio.CancelledError:
        update({"status": "canceled", "phase": "canceled",
                "completed_at": datetime.utcnow().isoformat()})
    except HTTPException as exc:
        update({"status": "failed", "phase": "failed",
                "error": str(exc.detail),
                "completed_at": datetime.utcnow().isoformat()})
    except Exception as exc:
        update({"status": "failed", "phase": "failed",
                "error": repr(exc),
                "completed_at": datetime.utcnow().isoformat()})


@app.post("/api/accounts/{account_id}/follows/sync-jobs", status_code=202)
async def start_follow_sync_job(account_id: int,
                                direction: str = "following"):
    if direction not in ("following", "fan"):
        raise HTTPException(400, "direction 仅支持 following | fan")
    with get_session() as s:
        account = s.get(DouyinAccount, account_id)
        if not account:
            raise HTTPException(404, "账号不存在")
        expected_total = (account.following_count if direction == "following"
                          else account.follower_count)
    for existing in reversed(list(_follow_sync_jobs.values())):
        if (existing.get("account_id") == account_id
                and existing.get("direction") == direction
                and existing.get("status") in {"queued", "running"}):
            return _follow_sync_job_view(existing)
    completed = [key for key, value in _follow_sync_jobs.items()
                 if value.get("status") in {"completed", "failed", "canceled"}]
    for key in completed[:-100]:
        _follow_sync_jobs.pop(key, None)
        _follow_sync_tasks.pop(key, None)
    now = datetime.utcnow().isoformat()
    job_id = uuid.uuid4().hex
    job = {
        "id": job_id, "account_id": account_id, "direction": direction,
        "status": "queued", "phase": "queued", "pages": 0,
        "fetched": 0, "saved": 0, "added": 0,
        "expected_total": max(0, int(expected_total or 0)),
        "source": "", "error": "", "created_at": now,
        "updated_at": now, "completed_at": None,
    }
    _follow_sync_jobs[job_id] = job
    task = asyncio.create_task(_run_follow_sync_job(job_id))
    _follow_sync_tasks[job_id] = task
    task.add_done_callback(lambda _task, key=job_id:
                           _follow_sync_tasks.pop(key, None))
    return _follow_sync_job_view(job)


@app.get("/api/follow-sync-jobs/{job_id}")
async def get_follow_sync_job(job_id: str):
    job = _follow_sync_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "同步任务不存在")
    return _follow_sync_job_view(job)


@app.get("/api/accounts/{account_id}/follows/sync-job")
async def get_latest_follow_sync_job(account_id: int,
                                     direction: str = "following"):
    for job in reversed(list(_follow_sync_jobs.values())):
        if (job.get("account_id") == account_id
                and job.get("direction") == direction):
            return _follow_sync_job_view(job)
    return {"status": "idle", "account_id": account_id,
            "direction": direction}


@app.post("/api/follow-sync-jobs/{job_id}/cancel")
async def cancel_follow_sync_job(job_id: str):
    job = _follow_sync_jobs.get(job_id)
    if not job:
        raise HTTPException(404, "同步任务不存在")
    if job.get("status") not in {"queued", "running"}:
        return _follow_sync_job_view(job)
    if job.get("phase") == "saving":
        raise HTTPException(409, "数据正在提交，不能中途取消")
    job["status"] = "canceling"
    job["updated_at"] = datetime.utcnow().isoformat()
    task = _follow_sync_tasks.get(job_id)
    if task:
        task.cancel()
    return _follow_sync_job_view(job)


# ─────────── 本账号管理:私信 ───────────
def _conv_dict(c: DmConversation) -> dict:
    return {
        "id": c.id, "platform": c.platform, "account_id": c.account_id,
        "conv_id": c.conv_id, "peer_uid": c.peer_uid, "peer_sec_uid": c.peer_sec_uid,
        "peer_nickname": c.peer_nickname, "peer_avatar": c.peer_avatar,
        "last_text": c.last_text, "last_time": c.last_time,
        "unread_count": c.unread_count,
        "fetched_at": c.fetched_at.isoformat() if c.fetched_at else None,
    }


@app.get("/api/dm/conversations")
async def list_dm_conversations(account_id: int, limit: int = 200):
    with get_session() as s:
        q = (select(DmConversation).where(DmConversation.account_id == account_id)
             .order_by(DmConversation.last_time.desc()).limit(limit))
        return [_conv_dict(c) for c in s.exec(q).all()]


@app.get("/api/dm/messages")
async def list_dm_messages(account_id: int, conv_id: str, limit: int = 200):
    with get_session() as s:
        q = (select(DmMessage).where(DmMessage.account_id == account_id,
                                     DmMessage.conv_id == conv_id)
             .order_by(DmMessage.create_time.asc()).limit(limit))

        def _card(m):
            if not m.raw_json:
                return None
            try:
                value = json.loads(m.raw_json)
                return value if isinstance(value, dict) and value.get("kind") else None
            except Exception:
                return None
        return [{"id": m.id, "direction": m.direction, "text": m.text,
                 "msg_type": m.msg_type, "create_time": m.create_time,
                 "card": _card(m)}
                for m in s.exec(q).all()]


@app.post("/api/accounts/{account_id}/dm/sync")
async def sync_dm(account_id: int):
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        platform = acc.platform
        dm_transport = (resolve_transport(cfg, "douyin", "dm_sync", acc)
                        if platform == "douyin" else None)
        if dm_transport and dm_transport["effective_mode"] == "unavailable":
            raise HTTPException(409, dm_transport["reason"] or "当前私信同步通道不可用")
        effective_mode = (dm_transport["effective_mode"]
                          if dm_transport else "browser")
        if browser is None and effective_mode == "browser":
            raise HTTPException(503, "浏览器未就绪")
        identity = (browser.identity_for(acc)
                    if browser is not None and effective_mode != "api" else None)
        state = acc.storage_state or acc.creator_storage_state or ""
        ua = acc.ua or cfg.engine.user_agent
        proxy = acc.proxy or ""
        direct_environment = douyin_client_environment(acc)
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    if platform == "xhs":
        result = await engine.poll_xhs_dm_now(account_id)
        if not result.get("ok"):
            raise HTTPException(400, result.get("error") or "私信同步失败")
        cached_conversations = 0
        if result.get("skipped"):
            with get_session() as session:
                cached_conversations = len(session.exec(select(DmConversation.id).where(
                    DmConversation.account_id == account_id)).all())
        return {
            "ok": True,
            "fetched": int(result.get("conversations") or cached_conversations),
            "added": int(result.get("messages") or 0),
            "messages": int(result.get("messages") or 0),
            "queued": int(result.get("queued") or 0),
            "drafts": int(result.get("drafts") or 0),
            "skipped": bool(result.get("skipped")),
            "cached": bool(result.get("skipped") and cached_conversations),
            "reason": result.get("reason") or "",
        }
    source = "api" if effective_mode == "api" else "browser"

    async def _fetch_conversations():
        nonlocal source
        api_error = ""
        if platform == "douyin" and effective_mode in {"api", "hybrid"}:
            cookie = douyin_cookie_from_state(state)
            if not cookie:
                api_error = "api_missing_cookie"
            else:
                client = DouyinClient(
                    cookie, ua, timeout=cfg.engine.request_timeout_seconds,
                    proxy=proxy, **direct_environment)
                async with client.session_scope():
                    direct = await client.fetch_dm_conversations()
                api_error = client.last_error or ""
                if direct or not api_error:
                    source = "api"
                    return direct, ""
            if effective_mode == "api":
                source = "api"
                return [], api_error or "empty_response"
        if browser is None or identity is None:
            return [], api_error or "browser_unavailable"
        source = "browser_fallback" if effective_mode == "hybrid" else "browser"
        conversations, browser_error = await fetch_dm_conversations(
            browser, identity, platform)
        return conversations, browser_error or api_error

    convs, err = await engine.guarded_read_pair(
        account_id, OperationKind.READ_HEAVY, f"dm:{account_id}",
        _fetch_conversations, empty_result=[])
    if err.startswith("risk_deferred:"):
        return {"ok": True, "fetched": 0, "added": 0, "skipped": True,
                "reason": err.split(":", 1)[-1]}
    if err and err.startswith("logged_out"):
        raise HTTPException(400, "登录态已失效,请点「重新登录」")
    # 小红书网页端私信未开放(entry visible=false)等硬限制:直接把原因回给前端
    if not convs and err:
        raise HTTPException(400, err)
    now = datetime.utcnow()
    with get_session() as s:
        # 快照式替换:清掉旧会话(含历史误抓的 JS 模块垃圾),写入本次抓到的
        for old in s.exec(select(DmConversation).where(
                DmConversation.account_id == account_id)).all():
            s.delete(old)
        # 会话最后一条消息也快照式重写(仅 last:<conv> 这条,历史记录由按需抓取补)
        for old in s.exec(select(DmMessage).where(
                DmMessage.account_id == account_id,
                DmMessage.msg_id.like("last:%"))).all():
            s.delete(old)
        msgs = 0
        for c in convs:
            s.add(DmConversation(platform=platform, account_id=account_id,
                                 fetched_at=now, **c))
            # get_message_by_init 已带每会话最后一条消息:落成 thread 里的一条,
            # 让「点开会话」不再空。方向由 last_sender_uid==self_uid 判定。
            meta = {}
            try:
                meta = json.loads(c.get("raw_json") or "{}")
            except Exception:
                meta = {}
            if c.get("last_text"):
                direction = ("out" if meta.get("last_sender_uid")
                             and meta.get("last_sender_uid") == meta.get("self_uid")
                             else "in")
                s.add(DmMessage(
                    platform=platform, account_id=account_id, conv_id=c["conv_id"],
                    msg_id="last:" + c["conv_id"], direction=direction,
                    msg_type="text", text=c["last_text"],
                    create_time=c.get("last_time") or 0))
                msgs += 1
        # 顺带存账号自身 uid(= IM device_id,实时接收 WS 要用);从任一会话的 self_uid 取
        self_uid = ""
        for c in convs:
            try:
                self_uid = (json.loads(c.get("raw_json") or "{}")).get("self_uid", "")
            except Exception:
                self_uid = ""
            if self_uid:
                break
        if self_uid:
            acc2 = s.get(DouyinAccount, account_id)
            if acc2 and acc2.uid != self_uid:
                acc2.uid = self_uid
                s.add(acc2)
        s.commit()
    return {"ok": True, "fetched": len(convs), "added": len(convs),
            "messages": msgs, "source": source,
            "configured_mode": (dm_transport["configured_mode"]
                                if dm_transport else "browser")}


@app.get("/api/dm/stream")
async def dm_stream(account_id: int):
    """私信实时事件流(SSE)。前端打开 DM 面板时订阅;订阅即为该账号拉起 frontier-im
    WS 长连接,新消息实时推来(也已入库)。最后一个订阅断开时自动停连。"""
    if im_receiver is None:
        raise HTTPException(503, "实时接收未就绪")
    q = await im_receiver.subscribe(account_id)

    async def gen():
        try:
            yield "retry: 3000\nevent: ready\ndata: {}\n\n"
            while True:
                try:
                    evt = await asyncio.wait_for(q.get(), timeout=25)
                    yield f"data: {json.dumps(evt, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"     # 心跳,防代理断流
        except asyncio.CancelledError:
            pass
        finally:
            im_receiver.unsubscribe(account_id, q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.post("/api/accounts/{account_id}/dm/conversations/{conv_id:path}/mark-read")
async def mark_dm_read(account_id: int, conv_id: str):
    """标记会话已读:清本地未读计数(红点)。"""
    with get_session() as s:
        conv = s.exec(select(DmConversation).where(
            DmConversation.account_id == account_id,
            DmConversation.conv_id == conv_id)).first()
        if conv and conv.unread_count:
            conv.unread_count = 0
            s.add(conv); s.commit()
    return {"ok": True}


@app.post("/api/accounts/{account_id}/dm/conversations/{conv_id:path}/fetch-history")
async def fetch_dm_conversation_history(account_id: int, conv_id: str,
                                        cursor: int = 0, debug: bool = False):
    """无头抓单个会话历史消息(imapi get_by_conversation,纯 cookie),落库 DmMessage。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        platform = acc.platform
        identity = browser.identity_for(acc)
        conv = s.exec(select(DmConversation).where(
            DmConversation.account_id == account_id,
            DmConversation.conv_id == conv_id)).first()
        if not conv:
            raise HTTPException(404, "会话不存在(先同步会话列表)")
        short_id, self_uid = conv.conv_short_id, ""
        try:
            self_uid = (json.loads(conv.raw_json or "{}")).get("self_uid", "")
        except Exception:
            pass
    if platform == "douyin" and not short_id:
        raise HTTPException(400, "该会话缺 conversation_short_id,请重新同步会话列表")
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    async def _fetch_history():
        return await fetch_dm_history(
            browser, identity, platform, conv_id, short_id,
            conv_type=1, cursor=cursor, debug=debug,
            peer_uid=conv.peer_uid, self_uid=self_uid)
    read_guard = (engine.guarded_interactive_read_pair if platform == "xhs"
                  else engine.guarded_read_pair)
    parsed, err = await read_guard(
        account_id, OperationKind.READ_HEAVY,
        f"dm-history:{account_id}:{conv_id}", _fetch_history,
        empty_result={})
    if err.startswith("risk_deferred:"):
        return {"ok": True, "messages": 0, "added": 0, "skipped": True,
                "reason": err.split(":", 1)[-1]}
    if err:
        raise HTTPException(400, err)
    msgs = parsed.get("messages", [])
    added = 0
    with get_session() as s:
        # 按会话快照重写:拉到消息就清掉该会话旧消息(含 last:<conv> 占位、旧错时间戳),
        # 再插本次窗口。get_by_conversation 每次返回最近一窗,快照式最简单且能纠正旧数据。
        if msgs and platform != "xhs":
            for old in s.exec(select(DmMessage).where(
                    DmMessage.account_id == account_id,
                    DmMessage.conv_id == conv_id)).all():
                s.delete(old)
        seen = set()
        for m in msgs:
            mid = m.get("server_msg_id") or ""
            if not mid or mid in seen:
                continue
            seen.add(mid)
            direction = (str(m.get("direction") or "") if platform == "xhs" else
                         "out" if self_uid and m.get("sender_uid") == self_uid else "in")
            card = m.get("card")
            existing = s.exec(select(DmMessage).where(
                DmMessage.account_id == account_id,
                DmMessage.conv_id == conv_id,
                DmMessage.msg_id == mid)).first()
            if existing is None:
                existing = DmMessage(platform=platform, account_id=account_id,
                                     conv_id=conv_id, msg_id=mid)
                added += 1
            existing.direction = direction
            existing.msg_type = ("video" if card else
                                 "text" if m.get("text") else str(m.get("msg_type") or ""))
            existing.text = m.get("text") or ""
            existing.create_time = int(m.get("create_time") or 0)
            if platform == "xhs":
                existing.raw_json = json.dumps({
                    "store_id": int(m.get("store_id") or 0),
                    "sender_uid": m.get("sender_uid") or "",
                    "receiver_uid": m.get("receiver_uid") or "",
                    "group_chat": bool(m.get("group_chat")),
                    "content": m.get("content"),
                }, ensure_ascii=False)
            else:
                existing.raw_json = json.dumps(card, ensure_ascii=False) if card else ""
            s.add(existing)
        s.commit()
    out = {"ok": True, "fetched": len(msgs), "added": added,
           "next_cursor": parsed.get("next_cursor"), "has_more": parsed.get("has_more")}
    if debug:   # 非文本消息(分享视频=8/图片=27/语音=17...)回原始 content,标定字段用
        out["media_samples"] = [
            {"msg_type": m.get("msg_type"), "text": m.get("text"),
             "content": m.get("content")}
            for m in msgs if m.get("msg_type") not in (7, 0)]
    return out


# ─────────── 本账号管理:计数汇总(账号管理面板徽章,纯查库不触发抓取)───────────
@app.get("/api/hub/summary")
async def hub_summary(account_id: int):
    with get_session() as s:
        def _n(q):
            return len(s.exec(q).all())
        return {
            "works": _n(select(AccountWork.id)
                        .where(AccountWork.account_id == account_id)),
            "following": _n(select(FollowEdge.id)
                            .where(FollowEdge.account_id == account_id,
                                   FollowEdge.direction == "following")),
            "fans": _n(select(FollowEdge.id)
                       .where(FollowEdge.account_id == account_id,
                              FollowEdge.direction == "fan")),
            "dm": _n(select(DmConversation.id)
                     .where(DmConversation.account_id == account_id)),
        }


# ─────────── 本账号管理:写操作队列(取关/回关/发私信)───────────
class ActionIn(BaseModel):
    account_id: int
    action: str                 # follow | unfollow | send_dm
    target_uid: str = ""
    target_sec_uid: str = ""
    target_nick: str = ""
    conv_id: str = ""
    content: str = ""
    run_now: bool = False        # True=立即执行;False=入队(引擎节流后执行)


class DmAutoReplyRuleIn(BaseModel):
    account_id: int
    name: str = "自动回复"
    enabled: bool = True
    match_mode: str = "keywords"
    keywords: list[str] = PydanticField(default_factory=list)
    exclude_keywords: list[str] = PydanticField(default_factory=list)
    reply_templates: list[str] = PydanticField(default_factory=list)
    review_before_send: bool = True
    min_delay_seconds: int = 75
    max_delay_seconds: int = 300
    cooldown_seconds: int = 21600
    max_message_age_seconds: int = 1800


class DmActionEditIn(BaseModel):
    content: str


def _clean_string_list(values: list[str], *, limit: int, item_limit: int) -> list[str]:
    cleaned: list[str] = []
    seen: set[str] = set()
    for value in values[:limit]:
        text = " ".join(str(value or "").strip().split())[:item_limit]
        key = text.casefold()
        if text and key not in seen:
            seen.add(key); cleaned.append(text)
    return cleaned


def _dm_rule_dict(rule: DmAutoReplyRule) -> dict:
    def load(raw: str) -> list:
        try:
            value = json.loads(raw or "[]")
            return value if isinstance(value, list) else []
        except Exception:
            return []
    return {
        "id": rule.id, "platform": rule.platform, "account_id": rule.account_id,
        "name": rule.name, "enabled": rule.enabled, "match_mode": rule.match_mode,
        "keywords": load(rule.keywords),
        "exclude_keywords": load(rule.exclude_keywords),
        "reply_templates": load(rule.reply_templates),
        "review_before_send": rule.review_before_send,
        "min_delay_seconds": rule.min_delay_seconds,
        "max_delay_seconds": rule.max_delay_seconds,
        "cooldown_seconds": rule.cooldown_seconds,
        "max_message_age_seconds": rule.max_message_age_seconds,
        "created_at": rule.created_at.isoformat() if rule.created_at else None,
        "updated_at": rule.updated_at.isoformat() if rule.updated_at else None,
    }


def _apply_rule_input(rule: DmAutoReplyRule, body: DmAutoReplyRuleIn) -> None:
    if body.match_mode not in {"all", "keywords"}:
        raise HTTPException(400, "match_mode 仅支持 all | keywords")
    keywords = _clean_string_list(body.keywords, limit=30, item_limit=80)
    excludes = _clean_string_list(body.exclude_keywords, limit=30, item_limit=80)
    templates = _clean_string_list(body.reply_templates, limit=20, item_limit=500)
    if body.match_mode == "keywords" and not keywords:
        raise HTTPException(400, "关键词模式至少填写一个关键词")
    if not templates:
        raise HTTPException(400, "至少填写一条回复模板")
    rule.name = str(body.name or "自动回复").strip()[:80]
    rule.enabled = bool(body.enabled)
    rule.match_mode = body.match_mode
    rule.keywords = json.dumps(keywords, ensure_ascii=False)
    rule.exclude_keywords = json.dumps(excludes, ensure_ascii=False)
    rule.reply_templates = json.dumps(templates, ensure_ascii=False)
    rule.review_before_send = bool(body.review_before_send)
    rule.min_delay_seconds = max(15, min(3600, int(body.min_delay_seconds)))
    rule.max_delay_seconds = max(
        rule.min_delay_seconds, min(7200, int(body.max_delay_seconds)))
    rule.cooldown_seconds = max(300, min(604800, int(body.cooldown_seconds)))
    rule.max_message_age_seconds = max(
        60, min(86400, int(body.max_message_age_seconds)))
    rule.updated_at = datetime.utcnow()


@app.get("/api/dm/auto-reply-rules")
async def list_dm_auto_reply_rules(account_id: int):
    with get_session() as session:
        rows = session.exec(select(DmAutoReplyRule).where(
            DmAutoReplyRule.account_id == account_id
        ).order_by(DmAutoReplyRule.id.asc())).all()
        return [_dm_rule_dict(row) for row in rows]


@app.post("/api/dm/auto-reply-rules")
async def create_dm_auto_reply_rule(body: DmAutoReplyRuleIn, request: Request = None):
    with get_session() as session:
        def create():
            account = session.get(DouyinAccount, body.account_id)
            if not account or account.platform != "xhs":
                raise HTTPException(404, "小红书账号不存在")
            rule = DmAutoReplyRule(account_id=body.account_id, platform="xhs")
            _apply_rule_input(rule, body)
            session.add(rule); session.flush()
            return _dm_rule_dict(rule)
        payload, _ = submit_once(session, request=request, scope="dm-rule", body=body, create=create)
        return payload


@app.put("/api/dm/auto-reply-rules/{rule_id}")
async def update_dm_auto_reply_rule(rule_id: int, body: DmAutoReplyRuleIn):
    with get_session() as session:
        rule = session.get(DmAutoReplyRule, rule_id)
        if not rule:
            raise HTTPException(404, "规则不存在")
        if rule.account_id != body.account_id:
            raise HTTPException(400, "规则与账号不匹配")
        _apply_rule_input(rule, body)
        session.add(rule); session.commit(); session.refresh(rule)
        return _dm_rule_dict(rule)


@app.delete("/api/dm/auto-reply-rules/{rule_id}")
async def delete_dm_auto_reply_rule(rule_id: int):
    with get_session() as session:
        rule = session.get(DmAutoReplyRule, rule_id)
        if not rule:
            raise HTTPException(404, "规则不存在")
        session.delete(rule); session.commit()
    return {"ok": True}


@app.post("/api/accounts/{account_id}/dm/automation/poll-now")
async def poll_xhs_dm_automation_now(account_id: int):
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    result = await engine.poll_xhs_dm_now(account_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error") or "私信检查失败")
    return result


@app.get("/api/accounts/{account_id}/dm/automation/status")
async def xhs_dm_automation_status(account_id: int):
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if not account or account.platform != "xhs":
            raise HTTPException(404, "小红书账号不存在")
        state = session.exec(select(DmMonitorState).where(
            DmMonitorState.account_id == account_id,
            DmMonitorState.platform == "xhs",
        )).first()
        enabled_rules = len(session.exec(select(DmAutoReplyRule.id).where(
            DmAutoReplyRule.account_id == account_id,
            DmAutoReplyRule.enabled == True,  # noqa: E712
        )).all())
    runtime = (engine.dm_automation.realtime_status(account_id)
               if engine is not None else {})
    return {
        "ok": True,
        "scope": "account",
        "new_conversations": True,
        "monitor_enabled": bool(cfg.engine.xhs_dm_monitor_enabled),
        "auto_reply_enabled": bool(cfg.engine.xhs_dm_auto_reply_enabled),
        "enabled_rules": enabled_rules,
        "baseline_initialized": bool(state and state.baseline_initialized),
        "baseline_at": state.baseline_at.isoformat() if state and state.baseline_at else None,
        "last_poll_at": state.last_poll_at.isoformat() if state and state.last_poll_at else None,
        "last_push_at": state.last_push_at.isoformat() if state and state.last_push_at else None,
        "last_error": state.last_error if state else "",
        "fallback_interval_seconds": int(cfg.engine.xhs_dm_fallback_interval_seconds),
        "realtime": runtime,
    }


def _action_dict(t: AccountActionTask) -> dict:
    return {
        "id": t.id, "platform": t.platform, "account_id": t.account_id,
        "action": t.action, "target_uid": t.target_uid, "target_nick": t.target_nick,
        "conv_id": t.conv_id,
        "content": t.content, "status": t.status, "result": t.result,
        "method": t.method,
        "source_msg_id": t.source_msg_id, "source_rule_id": t.source_rule_id,
        "scheduled_at": t.scheduled_at.isoformat() if t.scheduled_at else None,
        "error": t.error, "created_at": t.created_at.isoformat() if t.created_at else None,
        "done_at": t.done_at.isoformat() if t.done_at else None,
    }


async def _exec_action(task_id: int) -> tuple[bool, str]:
    """立即执行一条写操作:委托引擎(带每账号串行锁,避免同号并发开窗)。"""
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    res = await engine.execute_action_task(task_id)
    return bool(res.get("ok")), (res.get("error") or "")


@app.get("/api/account-actions")
async def list_account_actions(account_id: int | None = None, limit: int = 100):
    with get_session() as s:
        q = select(AccountActionTask)
        if account_id:
            q = q.where(AccountActionTask.account_id == account_id)
        q = q.order_by(AccountActionTask.id.desc()).limit(limit)
        return [_action_dict(t) for t in s.exec(q).all()]


@app.post("/api/account-actions")
async def create_account_action(body: ActionIn, request: Request = None):
    if body.action not in ("follow", "unfollow", "send_dm"):
        raise HTTPException(400, "action 仅支持 follow | unfollow | send_dm")
    if body.action == "send_dm" and not body.content.strip():
        raise HTTPException(400, "发私信需填写内容")
    if not (body.target_uid or body.target_sec_uid):
        raise HTTPException(400, "缺目标用户")
    with get_session() as s:
        def create():
            acc = s.get(DouyinAccount, body.account_id)
            if not acc:
                raise HTTPException(404, "账号不存在")
            t = AccountActionTask(
                platform=acc.platform, account_id=body.account_id, action=body.action,
                target_uid=body.target_uid, target_sec_uid=body.target_sec_uid,
                target_nick=body.target_nick, conv_id=body.conv_id,
                content=body.content.strip(), status="pending")
            s.add(t); s.flush()
            return {"ok": True, "id": t.id, "ran": False}
        payload, created = submit_once(s, request=request, scope="account-action",
                                       body=body, create=create)
    # The durable receipt already exists before any external write. An HTTP
    # retry returns that task and never executes its run_now a second time.
    detail = ""
    if created and body.run_now:
        try:
            _, detail = await _exec_action(payload["id"])
        except HTTPException as exc:
            detail = str(exc.detail)
    with get_session() as s:
        task = s.get(AccountActionTask, payload["id"])
        payload.update(status=task.status if task else "deleted",
                       ran=bool(task and task.status == "done"),
                       method=(task.method if task else ""),
                       execution_error=detail or (task.error if task else ""))
    return payload


@app.post("/api/account-actions/{task_id}/run-now")
async def run_account_action(task_id: int):
    ok, detail = await _exec_action(task_id)
    if not ok:
        raise HTTPException(400, f"执行失败:{detail}")
    with get_session() as session:
        task = session.get(AccountActionTask, task_id)
        return {"ok": True, "method": task.method if task else ""}


@app.put("/api/account-actions/{task_id}")
async def edit_account_action(task_id: int, body: DmActionEditIn):
    content = " ".join(str(body.content or "").strip().split())[:500]
    if not content:
        raise HTTPException(400, "私信内容为空")
    with get_session() as session:
        task = session.get(AccountActionTask, task_id)
        if not task:
            raise HTTPException(404, "任务不存在")
        if task.action != "send_dm" or task.status not in {"draft", "pending"}:
            raise HTTPException(400, "仅可编辑未执行的私信任务")
        task.content = content
        session.add(task); session.commit(); session.refresh(task)
        return _action_dict(task)


@app.post("/api/account-actions/{task_id}/approve")
async def approve_account_action(task_id: int):
    with get_session() as session:
        task = session.get(AccountActionTask, task_id)
        if not task:
            raise HTTPException(404, "任务不存在")
        if task.status != "draft":
            raise HTTPException(400, "该任务不是待审核草稿")
        task.status = "pending"
        task.scheduled_at = max(task.scheduled_at or datetime.utcnow(), datetime.utcnow())
        session.add(task); session.commit(); session.refresh(task)
        return _action_dict(task)


@app.post("/api/account-actions/{task_id}/cancel")
async def cancel_account_action(task_id: int):
    with get_session() as s:
        t = s.get(AccountActionTask, task_id)
        if not t:
            raise HTTPException(404, "任务不存在")
        if t.status in ("done", "doing"):
            raise HTTPException(400, "该任务已执行,无法取消")
        t.status = "canceled"; s.add(t); s.commit()
    return {"ok": True}


_PLATFORM_HOST = {"douyin": "douyin.com", "xhs": "xiaohongshu.com",
                  "kuaishou": "kuaishou.com", "shipinhao": "weixin.qq.com"}
_XHS_USER_ME_API = "/api/sns/web/v2/user/me"


def _platform_url_allowed(platform: str, value: str) -> bool:
    expected = _PLATFORM_HOST.get(platform, "").casefold()
    try:
        parsed = urlsplit(str(value or "").strip())
        host = (parsed.hostname or "").casefold()
    except (TypeError, ValueError):
        return False
    return bool(
        expected and parsed.scheme in {"http", "https"}
        and (host == expected or host.endswith("." + expected))
    )


def _xhs_open_auth_response_handler(evidence: dict):
    """Collect authoritative XHS login evidence while the headed page loads."""
    async def on_response(response):
        try:
            parsed = urlsplit(str(response.url or ""))
            host = (parsed.hostname or "").lower()
            if not (host == "xiaohongshu.com"
                    or host.endswith(".xiaohongshu.com")):
                return
            if parsed.path.rstrip("/").lower() != _XHS_USER_ME_API:
                return
            evidence["seen"] = True
            if int(response.status) != 200:
                return
            payload = await response.json()
            data = payload.get("data") if isinstance(payload, dict) else None
            if not isinstance(data, dict):
                return
            if data.get("guest") is True:
                evidence["guest"] = True
                return
            if data.get("user_id") or data.get("red_id"):
                evidence["authenticated"] = True
        except Exception:
            return
    return on_response


async def _opened_page_login_state(page, platform: str,
                                   xhs_evidence: dict | None = None) -> str:
    """Classify the opened page without turning transient UI into auth loss."""
    current_url = str(getattr(page, "url", "") or "").lower()
    if platform == "xhs_creator":
        if "passport" in current_url:
            return "logged_out"
        try:
            parsed = urlsplit(current_url)
            path = parsed.path.rstrip("/").lower()
            host = (parsed.hostname or "").lower()
        except (TypeError, ValueError):
            path, host = "", ""
        if path == "/login" or path.startswith("/login/"):
            return "logged_out"
        if host == "creator.xiaohongshu.com" and current_url:
            return "authenticated"
        return "unconfirmed"
    if platform == "xhs":
        evidence = xhs_evidence or {}
        if "/website-login/captcha" in current_url \
                or "error_code=300012" in current_url:
            return "verification"
        if "passport" in current_url:
            return "logged_out"
        try:
            path = urlsplit(current_url).path.rstrip("/")
        except (TypeError, ValueError):
            path = ""
        if path == "/login" or path.startswith("/login/"):
            return "logged_out"
        if evidence.get("authenticated"):
            return "authenticated"
        if evidence.get("guest"):
            return "logged_out"
        # The XHS header can briefly render an exact "登录" button before
        # user/me resolves.  A button alone is not proof that the session died;
        # profile refresh remains the authoritative fallback.
        return "unconfirmed"

    logged_out = (
        "passport" in current_url
        or "/login" in current_url
        or "login.html" in current_url
    )
    if not logged_out:
        try:
            logged_out = await page.get_by_text(
                "登录", exact=True).first.is_visible(timeout=1500)
        except Exception:
            logged_out = False
    return "logged_out" if logged_out else "authenticated"


@app.post("/api/accounts/{account_id}/open-browser")
async def open_account_browser(
        account_id: int, url: str = "", environment_check: bool = False):
    """用该账号登录态弹出一个真实浏览器窗口。默认停在平台首页;传 url 则停在该地址
    (仅允许本平台域名,用于「查看」视频号作品/管理页等需登录态才能打开的页面)。
    留给用户手动操作(查看/收发私信、F12 抓接口、手动维护等)。关闭窗口即落盘 Cookie。
    小红书复用账号专属常驻 Context；手动窗口只占用当前账号 Profile，不长期占用
    共享网络出口或全局可视操作锁，因此不同账号/平台窗口可以并存。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        platform = acc.platform
        identity = browser.identity_for(acc)
        has_read_login = (
            _xhs_has_read_login_state(acc.storage_state)
            if platform == "xhs" else bool(acc.storage_state)
        )
        has_creator_login = bool(acc.creator_storage_state)
        open_scope = (
            "creator" if platform == "xhs" and not has_read_login
            and has_creator_login else "read"
        )
        states = [acc.storage_state or "", acc.creator_storage_state or ""]
    home = {"xhs": ("https://creator.xiaohongshu.com/"
                     if open_scope == "creator"
                     # /user/profile/me 不再稳定触发 user/me，可能把有效登录态
                     # 显示成“未确认”。首页会加载权威的当前用户接口。
                     else "https://www.xiaohongshu.com/"),
            "kuaishou": "https://www.kuaishou.com/",
            "shipinhao": "https://channels.weixin.qq.com/platform"}.get(
                platform, "https://www.douyin.com/")
    # 传了 url 且属于本平台域名 -> 停在该地址(否则回首页,防被当跳转开任意站)
    tgt = (url or "").strip()
    if _platform_url_allowed(platform, tgt):
        home = tgt
        if platform == "xhs":
            try:
                open_scope = (
                    "creator" if (urlsplit(home).hostname or "").lower()
                    == "creator.xiaohongshu.com" else "read")
            except (TypeError, ValueError):
                open_scope = "read"

    # Repeated clicks should raise/navigate the already-owned account window,
    # not tear down and cold-start the same Profile again.
    old = open_browsers.get(account_id)
    if old is not None and old.active:
        old_page = getattr(old, "page", None)
        try:
            if old_page is not None and not old_page.is_closed():
                check_opened = False
                foreground_page = old_page
                if environment_check:
                    check_opener = getattr(
                        browser, "open_environment_check", None)
                    if callable(check_opener):
                        check_page = await check_opener(
                            identity, context=old.context, force=True,
                            bring_to_front=True)
                        check_opened = check_page is not None
                        if check_page is not None:
                            foreground_page = check_page
                elif tgt:
                    await old_page.goto(
                        home, wait_until="domcontentloaded", timeout=30000)
                await foreground_page.bring_to_front()
                return {
                    "ok": True,
                    "reused": True,
                    "logged_out": False,
                    "login_state": "unconfirmed",
                    "login_scope": open_scope,
                    "environment_check_only": environment_check,
                    "environment_check_opened": check_opened,
                    "environment_check_error": "",
                    "environment_check": None,
                }
        except Exception:
            pass
        open_browsers.pop(account_id, None)
        try:
            await old.close()
        except Exception:
            pass
    # 持久 profile 只在"首次空目录"才注入登录态;为防 profile 里 Cookie 缺失/过期导致
    # 打开后未登录,这里用 DB 里已知的登录态 Cookie 再注入一次(覆盖刷新)。
    from .browser.manager import _sanitize_cookies
    cookies = []
    for st in states:
        if st:
            try:
                cookies.extend(json.loads(st).get("cookies") or [])
            except Exception:
                pass

    @asynccontextmanager
    async def _open_guard():
        # A manually-opened window must reserve only its own account Profile.
        # Holding operation_guard for the whole window lifetime also holds the
        # shared network-exit semaphore; two direct-connect accounts would then
        # look like the browser supports only one window. Production managers
        # expose lock_for(); the fallback keeps lightweight integrations
        # compatible.
        lock_factory = getattr(browser, "lock_for", None)
        if callable(lock_factory):
            async with lock_factory(f"acc:{account_id}"):
                yield identity
            return
        if engine is None:
            yield identity
            return
        async with engine.operation_guard(
                account_id, OperationKind.LOGIN,
                fallback_key=f"open-browser:{account_id}",
                operation_target=identity) as guarded:
            yield guarded

    @asynccontextmanager
    async def _startup_visible_guard():
        # Window startup/navigation is brief and still serialized for XHS so
        # focus and native-page setup cannot race. Once the page is ready the
        # global gate is released; the account-specific Profile lock remains.
        if platform == "xhs":
            async with browser.visible_action(
                    identity, keep_context=True):
                yield
            return
        yield

    guard = _open_guard()
    await guard.__aenter__()
    startup_guard = _startup_visible_guard()
    startup_entered = False
    logged_out = False
    login_state = "unconfirmed"
    check_opened = False
    check_error = ""
    check_page = None
    try:
        await startup_guard.__aenter__()
        startup_entered = True
        ctx = await browser.open_headed(identity)
        if cookies:
            try:
                await ctx.add_cookies(_sanitize_cookies(cookies))
            except Exception as e:
                print(f"[open-browser] 注入 Cookie 失败: {e!r}")
        check_opener = getattr(browser, "open_environment_check", None)
        if environment_check:
            if not callable(check_opener):
                raise RuntimeError("当前浏览器管理器未启用环境检测")
            check_page = await check_opener(
                identity, context=ctx, force=True, bring_to_front=True)
            if check_page is None:
                raise RuntimeError("环境检测仅适用于 Fingerprint Chromium")
            page = check_page
            check_opened = True
        else:
            # 新 Profile 或环境签名发生变化时，额外打开 BrowserScan 标签；
            # 检测页失败不影响账号平台页和登录态检查。
            if callable(check_opener):
                try:
                    check_page = await check_opener(identity, context=ctx)
                    check_opened = check_page is not None
                except Exception as check_exc:
                    check_error = f"{type(check_exc).__name__}: {check_exc}"
                    print(f"[environment-check] 自动打开失败: {check_exc!r}")
            page = (await browser.new_page(identity, block_media=False)
                    if platform == "xhs" else await ctx.new_page())
            xhs_evidence: dict = {}
            if platform == "xhs" and open_scope == "read":
                page.on("response", _xhs_open_auth_response_handler(xhs_evidence))
            await page.goto(home, wait_until="domcontentloaded", timeout=30000)
            try:
                # Give the async response callback a short opportunity to parse
                # user/me.  This is stronger than inspecting the first rendered
                # header frame, which is often still the anonymous skeleton.
                await page.wait_for_timeout(2500 if platform == "xhs" else 1000)
            except Exception:
                pass
            login_state = await _opened_page_login_state(
                page, ("xhs_creator" if platform == "xhs"
                       and open_scope == "creator" else platform), xhs_evidence)
            logged_out = login_state == "logged_out"
            if logged_out or (platform == "xhs" and login_state == "authenticated"):
                with get_session() as s:
                    opened_account = s.get(DouyinAccount, account_id)
                    if opened_account:
                        other_scope_available = (
                            platform == "xhs" and logged_out and (
                                (open_scope == "read" and has_creator_login)
                                or (open_scope == "creator" and has_read_login)
                            )
                        )
                        if not other_scope_available:
                            opened_account.status = (
                                "invalid" if logged_out else "active")
                        s.add(opened_account)
                        s.commit()
            if platform == "xhs":
                try:
                    await page.bring_to_front()
                except Exception:
                    pass
    except BaseException as e:
        if startup_entered:
            await startup_guard.__aexit__(type(e), e, e.__traceback__)
        await guard.__aexit__(type(e), e, e.__traceback__)
        if not isinstance(e, Exception):
            raise
        raise HTTPException(500, f"打开浏览器失败: {e!r}")
    try:
        await startup_guard.__aexit__(None, None, None)
    except BaseException as e:
        await guard.__aexit__(type(e), e, e.__traceback__)
        raise
    close_callback = (
        (lambda: browser.close_context(identity.key))
        if platform == "xhs" else None
    )
    lease = _OpenBrowserLease(
        ctx, guard, close_callback=close_callback, page=page)
    open_browsers[account_id] = lease
    try:                       # 用户手动关窗后,从登记表移除
        ctx.on("close", lambda *_: asyncio.create_task(
            _release_open_browser(account_id, lease)))
        if platform == "xhs":
            page.on("close", lambda *_: asyncio.create_task(
                _release_open_browser(account_id, lease)))
    except Exception:
        pass
    check_status = None
    status_reader = getattr(browser, "environment_check_status", None)
    if callable(status_reader):
        try:
            check_status = status_reader(identity)
        except Exception:
            pass
    return {"ok": True, "logged_out": logged_out,
            "login_state": login_state, "login_scope": open_scope,
            "environment_check_only": environment_check,
            "environment_check_opened": check_opened,
            "environment_check_error": check_error,
            "environment_check": check_status}


@app.post("/api/accounts/{account_id}/environment-check")
async def open_account_environment_check(account_id: int):
    """在账号自己的独立指纹 Profile 中手动打开 BrowserScan。"""
    return await open_account_browser(account_id, environment_check=True)


# ─────────── 账号代理(风控隔离)───────────
class ProxyIn(BaseModel):
    proxy: str = ""


def _reset_account_exit_baseline(acc) -> None:
    """A proxy assignment starts a new browser-egress baseline generation."""
    acc.exit_ip = ""
    acc.exit_country = ""
    acc.exit_asn = ""
    acc.exit_timezone = ""
    acc.exit_proxy_signature = ""
    acc.exit_checked_at = None


@app.put("/api/accounts/{account_id}/proxy")
async def set_account_proxy(account_id: int, body: ProxyIn):
    """手动设置/清空账号专属代理。改后会关掉该账号常驻 context,下次用新代理重开。"""
    from .browser.manager import _parse_proxy, normalize_proxy
    p = (body.proxy or "").strip()
    if p and not _parse_proxy(p):
        raise HTTPException(400, "代理格式无法解析,示例:http://user:pass@host:port 或 socks5://host:port")
    p = normalize_proxy(p)
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        acc.proxy = p
        acc.proxy_status = "unknown"
        _reset_account_exit_baseline(acc)
        s.add(acc); s.commit()
    if browser:
        await browser.close_context(account_id)
    return {"ok": True, "proxy": _mask_proxy(p)}


@app.post("/api/accounts/{account_id}/clear-write-pause")
async def clear_account_write_pause(account_id: int, body: RiskClearIn,
                                    request: Request):
    """Compatibility alias for the audited risk-center clear action."""
    return await clear_account_risk(account_id, body, request)


@app.post("/api/accounts/{account_id}/assign-proxy")
async def assign_account_proxy(account_id: int):
    """从代理池(config.proxies)给该账号分配一条占用最少的代理。"""
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        p = assign_proxy_from_pool(s, cfg)
        if not p:
            raise HTTPException(400, "代理池为空(请在 config.yaml 的 proxies 里配置)")
        acc.proxy = p
        acc.proxy_status = "unknown"
        _reset_account_exit_baseline(acc)
        s.add(acc); s.commit()
    if browser:
        await browser.close_context(account_id)
    return {"ok": True, "proxy": _mask_proxy(p)}


def _proxy_probe_status(status_code: int) -> str:
    """Map a proxy probe response to a persisted health state."""
    if 200 <= status_code < 400:
        return "ok"
    if status_code == 407:
        return "auth_error"
    if status_code in {403, 429}:
        return "blocked"
    return "bad"


def _proxy_status_ok(status_code: int) -> bool:
    return _proxy_probe_status(status_code) == "ok"


def _proxy_status_from_detail(ok: bool, detail: str) -> str:
    if ok:
        return "ok"
    text = str(detail or "")
    for code in (407, 403, 429):
        if f"HTTP {code}" in text:
            return _proxy_probe_status(code)
    return "bad"


async def _probe_proxy(url: str, platform: str = "douyin", timeout: float = 15):
    """经代理实连一次目标站,返回 (ok, detail)。"""
    import httpx
    if not url:
        return False, "未配置代理"
    test_url = ("https://www.xiaohongshu.com/" if platform == "xhs"
                else "https://www.kuaishou.com/" if platform == "kuaishou"
                else "https://channels.weixin.qq.com/" if platform == "shipinhao"
                else "https://www.douyin.com/")
    try:
        async with httpx.AsyncClient(proxy=url, timeout=timeout, follow_redirects=True) as cli:
            r = await cli.get(test_url)
        return _proxy_status_ok(r.status_code), f"HTTP {r.status_code}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _parse_ipinfo(j: dict) -> dict:
    lat = lon = 0.0
    loc = str(j.get("loc") or "")
    if "," in loc:
        try:
            lat, lon = (float(value) for value in loc.split(",", 1))
        except (TypeError, ValueError):
            lat = lon = 0.0
    return {"ip": j.get("ip", ""), "country": j.get("country", ""),
            "region": j.get("region", ""), "city": j.get("city", ""),
            "isp": j.get("org", ""), "timezone": j.get("timezone", ""),
            "lat": lat, "lon": lon}


def _parse_ipapi(j: dict) -> dict:
    if j.get("status") != "success":
        return {}
    return {"ip": j.get("query", ""),
            "country": j.get("countryCode") or j.get("country", ""),
            "region": j.get("regionName", ""), "city": j.get("city", ""),
            "isp": j.get("isp", ""), "timezone": j.get("timezone", ""),
            "lat": j.get("lat") or 0.0, "lon": j.get("lon") or 0.0}


async def _proxy_geo(proxy_url: str, timeout: float = 8) -> dict | None:
    """经代理查出口 IP/归属地/时区/坐标；空代理表示宿主直连。"""
    import httpx
    sources = [
        ("https://ipinfo.io/json", _parse_ipinfo),
        ("http://ip-api.com/json/?lang=zh-CN&fields=status,country,countryCode,regionName,city,lat,lon,timezone,isp,query",
         _parse_ipapi),
    ]
    try:
        client_options = {"timeout": timeout, "follow_redirects": True}
        if proxy_url:
            client_options["proxy"] = proxy_url
        async with httpx.AsyncClient(**client_options) as cli:
            for url, parser in sources:
                try:
                    g = parser((await cli.get(url)).json())
                    if g and g.get("ip"):
                        return g
                except Exception:
                    continue
    except Exception:
        pass
    return None


def _geo_text(g: dict | None) -> str:
    if not g:
        return ""
    loc = " · ".join([x for x in (g.get("country"), g.get("region"), g.get("city")) if x])
    parts = [p for p in (g.get("ip"), loc, g.get("isp")) if p]
    return "  ".join(parts)


async def _detect_proxy(raw: str) -> dict:
    """自动判别代理类型(HTTP / SOCKS5)与是否需要认证。
    对同一 host:port 依次试 [按输入协议 或 http+socks5] × [免密 / 带密(若输入含账密)],
    取第一个连通的组合。返回判别结果 + 推荐的规范化地址 + 浏览器兼容性。"""
    from urllib.parse import urlparse
    raw = (raw or "").strip()
    if not raw:
        return {"ok": False, "error": "请先填代理地址"}
    has_scheme = "://" in raw
    u = urlparse(raw if has_scheme else "http://" + raw)
    host, port = u.hostname, u.port
    if not host or not port:
        return {"ok": False, "error": "地址需含 host:port"}
    user, pwd = u.username, u.password
    cred = f"{user}:{pwd}@" if user else ""
    # 候选协议:输入已带则只测它,否则 http 与 socks5 都试
    if has_scheme and u.scheme in ("http", "https", "socks5", "socks5h"):
        schemes = [u.scheme]
    else:
        schemes = ["http", "socks5"]

    tried = []
    found = None   # (scheme, auth_mode, url)
    for sch in schemes:
        # 先试免密
        url0 = f"{sch}://{host}:{port}"
        ok, detail = await _probe_proxy(url0, timeout=8)
        tried.append({"scheme": sch, "auth": "none", "ok": ok, "detail": detail})
        if ok:
            found = (sch, "none", url0)
            break
        # 免密不通且输入带账密 -> 再试带密
        if cred:
            url1 = f"{sch}://{cred}{host}:{port}"
            ok1, detail1 = await _probe_proxy(url1, timeout=8)
            tried.append({"scheme": sch, "auth": "required", "ok": ok1, "detail": detail1})
            if ok1:
                found = (sch, "required", url1)
                break

    if not found:
        return {"ok": False, "error": "所有组合都连不通(可能是 IP 未加白名单/需账号密码/代理已失效)",
                "tried": tried, "need_auth_hint": not cred}

    sch, auth_mode, url = found
    is_socks = sch.startswith("socks")
    browser_ok = not (is_socks and auth_mode == "required")  # Patchright 不支持带密 SOCKS5
    geo = await _proxy_geo(url)              # 经该代理查出口 IP 归属地
    return {
        "ok": True, "scheme": sch, "auth": auth_mode,
        "recommend": url, "browser_ok": browser_ok, "tried": tried,
        "geo": geo, "geo_text": _geo_text(geo),
        "note": ("HTTP 代理,浏览器与直连都支持" if not is_socks
                 else ("免密 SOCKS5,浏览器与直连都支持" if browser_ok
                       else "带密 SOCKS5:小红书直连/下载可用,但浏览器抓取/登录不支持(建议改用该节点的 HTTP 端口)")),
    }


class ProxyDetectIn(BaseModel):
    url: str


@app.post("/api/proxies/detect")
async def detect_proxy(body: ProxyDetectIn):
    return await _detect_proxy(body.url)


@app.post("/api/accounts/assign-proxies-all")
async def assign_proxies_all():
    """给所有「尚未配置代理」的账号从池里批量分配(占用最少优先,均衡)。
    池里代理不够时,分到没有为止,返回还差多少。"""
    assigned, names, pool_empty = 0, [], False
    with get_session() as s:
        accs = [a.id for a in s.exec(select(DouyinAccount)).all() if not a.proxy]
    remaining = []
    for aid in accs:
        with get_session() as s:
            acc = s.get(DouyinAccount, aid)
            if not acc or acc.proxy:
                continue
            p = assign_proxy_from_pool(s, cfg)   # 每次重算占用,保持均衡
            if not p:
                pool_empty = True
                remaining.append(aid)
                continue
            acc.proxy = p
            acc.proxy_status = "unknown"
            _reset_account_exit_baseline(acc)
            s.add(acc); s.commit()
            assigned += 1
        if browser:
            await browser.close_context(aid)
    if pool_empty and assigned == 0:
        raise HTTPException(400, "代理池为空,请先在「代理池」添加代理")
    return {"ok": True, "assigned": assigned, "unassigned": len(remaining)}


@app.post("/api/accounts/{account_id}/test-proxy")
async def test_account_proxy(account_id: int):
    """用 native 账号的真实 BrowserContext 验证代理出口并建立基线。"""
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "账号不存在")
        proxy = acc.proxy or ""
        platform = acc.platform
        identity_mode = acc.identity_mode
        identity = browser.identity_for(acc) if browser else None
    if not proxy:
        return {"ok": False, "detail": "该账号未配置代理(将走宿主真实 IP)"}
    browser_exit = None
    if identity_mode == "native" and browser is not None and identity is not None:
        try:
            # 强制下次 context 使用数据库中最新的代理配置。
            await browser.close_context(account_id)
            browser_exit = await browser.probe_browser_exit(identity)
            ok = True
            detail = f"Browser IP {browser_exit['ip']}"
        except Exception as exc:
            ok = False
            detail = f"Browser probe failed: {exc}"
    else:
        ok, detail = await _probe_proxy(proxy, platform)
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if acc:
            if ok and browser_exit:
                signature = browser.proxy_signature(proxy)
                same_generation = bool(acc.exit_proxy_signature) \
                    and acc.exit_proxy_signature == signature
                drift = same_generation and any((
                    bool(acc.exit_ip and acc.exit_ip != browser_exit["ip"]),
                    bool(acc.exit_country and browser_exit["country"]
                         and acc.exit_country != browser_exit["country"]),
                    bool(acc.exit_asn and browser_exit["asn"]
                         and acc.exit_asn != browser_exit["asn"]),
                ))
                if drift:
                    acc.proxy_status = "drifted"
                    detail = (
                        f"浏览器出口漂移: 基线 {acc.exit_ip or '-'} / "
                        f"{acc.exit_asn or '-'}, 当前 {browser_exit['ip']} / "
                        f"{browser_exit['asn'] or '-'}")
                    ok = False
                else:
                    acc.proxy_status = "ok"
                    acc.exit_ip = browser_exit["ip"]
                    acc.exit_country = browser_exit["country"]
                    acc.exit_asn = browser_exit["asn"]
                    acc.exit_timezone = browser_exit["timezone"]
                    acc.exit_proxy_signature = signature
                    acc.exit_checked_at = datetime.utcnow()
            else:
                acc.proxy_status = _proxy_status_from_detail(ok, detail)
            s.add(acc); s.commit()
    return {"ok": ok, "detail": detail, "proxy": _mask_proxy(proxy),
            "browser_exit": browser_exit}


# ─────────── 代理池(提前配置,账号关联使用)───────────
class PoolProxyIn(BaseModel):
    url: str
    label: str = ""
    note: str = ""
    enabled: bool = True
    geo: Dict[str, Any] | None = None       # 判别得到的归属地(可选,建库时一并写入)


class PoolProxyUpdate(BaseModel):
    url: str | None = None
    label: str | None = None
    note: str | None = None
    enabled: bool | None = None


def _is_mainland(country: str, region: str, city: str) -> bool:
    if country not in ("中国", "China", "CN"):
        return False
    blob = (region or "") + (city or "")
    return not any(x in blob for x in ("香港", "澳门", "澳門", "台湾", "台灣",
                                       "Hong Kong", "Macau", "Taiwan"))


def _geo_loc(p) -> str:
    return " · ".join([x for x in (p.country, p.region, p.city) if x])


def _pool_dict(p: ProxyPool, used: int = 0) -> dict:
    return {
        "id": p.id, "label": p.label, "url": _mask_proxy(p.url),
        "url_full": p.url, "enabled": p.enabled, "status": p.status,
        "note": p.note, "used_by": used,
        "exit_ip": p.exit_ip, "country": p.country, "region": p.region,
        "city": p.city, "isp": p.isp,
        "geo_loc": _geo_loc(p), "is_mainland": _is_mainland(p.country, p.region, p.city),
        "geo_checked": bool(p.exit_ip),
        "last_checked_at": p.last_checked_at.isoformat() if p.last_checked_at else None,
    }


@app.get("/api/proxies")
async def list_proxies():
    with get_session() as s:
        rows = s.exec(select(ProxyPool).order_by(ProxyPool.id)).all()
        used = {}
        for a in s.exec(select(DouyinAccount)).all():
            if a.proxy:
                used[a.proxy] = used.get(a.proxy, 0) + 1
        return [_pool_dict(p, used.get(p.url, 0)) for p in rows]


@app.post("/api/proxies")
async def add_proxy(body: PoolProxyIn):
    from .browser.manager import _parse_proxy, normalize_proxy
    url = (body.url or "").strip()
    if not url or not _parse_proxy(url):
        raise HTTPException(400, "代理格式无法解析,示例:http://user:pass@host:port 或 socks5://host:port")
    url = normalize_proxy(url)
    with get_session() as s:
        if s.exec(select(ProxyPool).where(ProxyPool.url == url)).first():
            raise HTTPException(409, "该代理已在池中")
        g = body.geo or {}
        p = ProxyPool(url=url, label=body.label.strip(), note=body.note.strip(),
                      enabled=body.enabled,
                      exit_ip=g.get("ip", ""), country=g.get("country", ""),
                      region=g.get("region", ""), city=g.get("city", ""),
                      isp=g.get("isp", ""))
        s.add(p); s.commit(); s.refresh(p)
        return _pool_dict(p)


class ProxyImportIn(BaseModel):
    text: str = ""        # 多行,每行一个代理(可带 # 注释、空行)


@app.post("/api/proxies/import")
async def import_proxies(body: ProxyImportIn):
    """批量粘贴多行导入代理池。每行一个,支持 # 注释/空行,自动校验+去重。"""
    from .browser.manager import _parse_proxy, normalize_proxy
    added = skipped = invalid = 0
    invalid_lines = []
    with get_session() as s:
        existing = {p.url for p in s.exec(select(ProxyPool)).all()}
        seen = set(existing)
        for raw in (body.text or "").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            # 允许 "备注,地址" 或 "备注 地址" 形式;否则整行当地址
            label, url = "", line
            for sep in (",", "\t", " | ", " "):
                if sep in line:
                    a, b = line.split(sep, 1)
                    if _parse_proxy(b.strip()):
                        label, url = a.strip(), b.strip()
                    break
            url = normalize_proxy(url.strip())
            if not _parse_proxy(url):
                invalid += 1
                if len(invalid_lines) < 8:
                    invalid_lines.append(line[:60])
                continue
            if url in seen:
                skipped += 1
                continue
            s.add(ProxyPool(url=url, label=label))
            seen.add(url)
            added += 1
        if added:
            s.commit()
    return {"ok": True, "added": added, "skipped": skipped, "invalid": invalid,
            "invalid_samples": invalid_lines}


@app.put("/api/proxies/{pid}")
async def update_proxy(pid: int, body: PoolProxyUpdate):
    from .browser.manager import _parse_proxy, normalize_proxy
    with get_session() as s:
        p = s.get(ProxyPool, pid)
        if not p:
            raise HTTPException(404, "代理不存在")
        if body.url is not None:
            url = body.url.strip()
            if not url or not _parse_proxy(url):
                raise HTTPException(400, "代理格式无法解析")
            p.url = normalize_proxy(url)
        if body.label is not None:
            p.label = body.label.strip()
        if body.note is not None:
            p.note = body.note.strip()
        if body.enabled is not None:
            p.enabled = body.enabled
        s.add(p); s.commit(); s.refresh(p)
        return _pool_dict(p)


@app.delete("/api/proxies/{pid}")
async def del_proxy(pid: int):
    with get_session() as s:
        p = s.get(ProxyPool, pid)
        if not p:
            return {"ok": True}
        used = len(s.exec(select(DouyinAccount.id)
                          .where(DouyinAccount.proxy == p.url)).all())
        s.delete(p); s.commit()
    return {"ok": True, "still_used_by": used}


@app.post("/api/proxies/{pid}/test")
async def test_proxy_entry(pid: int):
    with get_session() as s:
        p = s.get(ProxyPool, pid)
        if not p:
            raise HTTPException(404, "代理不存在")
        url = p.url
    ok, detail = await _probe_proxy(url)
    geo = await _proxy_geo(url) if ok else None
    geo_text = _geo_text(geo)
    with get_session() as s:
        p = s.get(ProxyPool, pid)
        if p:
            p.status = _proxy_status_from_detail(ok, detail)
            p.last_checked_at = datetime.utcnow()
            if geo:                            # 归属地写入结构化字段(供「地区」列展示)
                p.exit_ip = geo.get("ip", "") or p.exit_ip
                p.country = geo.get("country", "") or p.country
                p.region = geo.get("region", "") or p.region
                p.city = geo.get("city", "") or p.city
                p.isp = geo.get("isp", "") or p.isp
            s.add(p); s.commit()
    return {"ok": ok, "detail": detail, "geo": geo, "geo_text": geo_text}


@app.get("/api/proxies/options")
async def proxy_options():
    """供账号/登录「选代理」下拉用:返回全部代理(启用优先,含停用并标记)。
    手动选可选任意一条;auto/批量分配仍只用启用的(见 assign_proxy_from_pool)。"""
    with get_session() as s:
        rows = s.exec(select(ProxyPool)
                      .order_by(ProxyPool.enabled.desc(), ProxyPool.id)).all()
        used = {}
        for a in s.exec(select(DouyinAccount)).all():
            if a.proxy:
                used[a.proxy] = used.get(a.proxy, 0) + 1
        return [{"id": p.id, "label": p.label or _mask_proxy(p.url),
                 "url": p.url, "masked": _mask_proxy(p.url),
                 "status": p.status, "enabled": p.enabled,
                 "used_by": used.get(p.url, 0)} for p in rows]


# ─────────── 全局设置 ───────────
QUALITY_CHOICES = {"highest", "1080", "720", "540", "lowest"}


class SettingsIn(BaseModel):
    download_dir: str | None = None
    video_quality: str | None = None
    # 大模型 API 文案生成(自动评论用;OpenAI 兼容接口)
    ai_enabled: bool | None = None
    ai_base_url: str | None = None
    ai_api_key: str | None = None        # 留空=不改(避免误清空已存的 key)
    ai_model: str | None = None
    ai_prompt: str | None = None
    ai_temperature: str | None = None


def _settings_dict() -> dict:
    return {
        "download_dir": get_setting("download_dir", cfg.engine.media_dir),
        "video_quality": get_setting("video_quality", "highest"),
        "ai_enabled": get_setting("ai_enabled", "0") == "1",
        "ai_base_url": get_setting("ai_base_url", ""),
        "ai_model": get_setting("ai_model", ""),
        "ai_prompt": get_setting("ai_prompt", ""),
        "ai_temperature": get_setting("ai_temperature", "0.9"),
        # 不回传明文 key,只告知是否已配置
        "ai_api_key_set": bool(get_setting("ai_api_key", "")),
    }


@app.get("/api/settings")
async def get_settings():
    return _settings_dict()


@app.get("/api/settings/engine")
async def get_engine_settings():
    return export_engine_settings(cfg)


@app.get("/api/settings/transport-matrix")
async def get_transport_matrix():
    """Expose actual route support plus account-level isolation diagnostics."""
    with get_session() as session:
        accounts = session.exec(
            select(DouyinAccount).order_by(DouyinAccount.id)).all()
        return build_transport_matrix(cfg, accounts)


@app.put("/api/settings/engine", openapi_extra={
    "requestBody": {"content": {"application/json": {
        "schema": EngineSettingsPatch.model_json_schema()}}}})
async def put_engine_settings(body: Any = Body(...)):
    try:
        result = save_engine_settings(cfg, body)
    except ValidationError as exc:
        # Validate here so rejected NaN/Infinity and accidental secret fields
        # never get echoed in JSON error details (or break JSON serialization).
        details = exc.errors(include_url=False, include_context=False, include_input=False)
        for detail in details:
            detail["loc"] = ["body", *detail["loc"]]
        raise HTTPException(422, details) from exc
    except Exception:
        raise HTTPException(503, "设置尚未保存，请稍后重试；原有配置保持不变") from None
    # Downloader snapshots its timeout at construction. Change the shared
    # instance for future downloads; already-created HTTP clients keep theirs.
    downloader = getattr(engine, "downloader", None)
    if downloader is not None and "download_timeout_seconds" in body:
        downloader.timeout = cfg.engine.download_timeout_seconds
    # BrowserManager snapshots native write-gate values at construction. Keep
    # those hot-reloadable switches in sync when they are edited from the UI;
    # other browser executable/profile settings intentionally remain restart-only.
    if browser is not None:
        for key in (
                "native_write_gate_enabled",
                "native_write_require_system_chrome",
                "native_write_require_verified_proxy",
                "native_write_proxy_max_age_seconds"):
            if key in body and hasattr(browser, key):
                setattr(browser, key, getattr(cfg.engine, key))
    return result


@app.put("/api/settings")
async def put_settings(body: SettingsIn):
    if body.download_dir is not None:
        path = body.download_dir.strip()
        if path:
            try:
                Path(path).expanduser().mkdir(parents=True, exist_ok=True)
            except Exception as e:
                raise HTTPException(400, f"目录不可用: {e}")
        set_setting("download_dir", path)
    if body.video_quality is not None:
        q = body.video_quality.strip() or "highest"
        if q not in QUALITY_CHOICES:
            raise HTTPException(400, f"画质取值无效: {q}")
        set_setting("video_quality", q)
    if body.ai_enabled is not None:
        set_setting("ai_enabled", "1" if body.ai_enabled else "0")
    if body.ai_base_url is not None:
        set_setting("ai_base_url", body.ai_base_url.strip())
    if body.ai_model is not None:
        set_setting("ai_model", body.ai_model.strip())
    if body.ai_prompt is not None:
        set_setting("ai_prompt", body.ai_prompt)
    if body.ai_temperature is not None:
        set_setting("ai_temperature", (body.ai_temperature or "0.9").strip())
    if body.ai_api_key:    # 仅在传了非空值时更新,留空=保留原 key
        set_setting("ai_api_key", body.ai_api_key.strip())
    return _settings_dict()


class AiTestIn(BaseModel):
    # 可选覆盖(便于保存前先测);留空则用已保存设置。key 留空=用已存的
    base_url: str | None = None
    api_key: str | None = None
    model: str | None = None
    prompt: str | None = None
    temperature: str | None = None


@app.post("/api/settings/ai-test")
async def ai_test(body: AiTestIn):
    """用当前(或传入的)AI 配置做一次最小生成,验证连通性。返回 {ok, sample/error}。"""
    from .engine import compose
    ai = {
        "base_url": body.base_url if body.base_url is not None else get_setting("ai_base_url", ""),
        "api_key": body.api_key if body.api_key else get_setting("ai_api_key", ""),
        "model": body.model if body.model is not None else get_setting("ai_model", ""),
        "prompt": body.prompt if body.prompt is not None else get_setting("ai_prompt", ""),
        "temperature": body.temperature or get_setting("ai_temperature", "0.9"),
        "timeout": 25,
    }
    if not (ai["base_url"] and ai["api_key"] and ai["model"]):
        raise HTTPException(400, "请先填写 Base URL / 模型,并保存或填入 API Key")
    ctx = {"source_text": "这条视频拍得太治愈了,期待更新!", "nick": "测试用户",
           "kw": "", "platform": "douyin", "mode": "auto_reply"}
    try:
        text = await compose.generate(ctx, ai)
        return {"ok": True, "sample": text}
    except Exception as e:
        msg = str(e) or e.__class__.__name__
        return {"ok": False, "error": f"{msg}(检查 Base URL / Key / 模型 / 网络/代理)"}


# ─────────── 通用分享链接下载 ───────────
class ShareLinksIn(BaseModel):
    share_text: str
    limit: int = 10


class ShareDownloadIn(BaseModel):
    share_text: str
    download: bool = True             # False = 只请求远端并解析作品信息
    all_links: bool = False           # False = 只处理 link_index 指定的一条
    link_index: int = 0
    quality: str = "highest"
    output_dir: str | None = None
    save_metadata: bool = True
    save_thumbnail: bool = True
    save_subtitles: bool = False
    max_filesize_mb: int = 0          # 0 = 不限制
    account_id: int | None = None     # 可选：复用已登录账号 Cookie / UA / 代理
    proxy: str = ""                   # 显式填写时优先于账号代理


def _share_input(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise HTTPException(400, "请粘贴分享链接或完整分享文案")
    if len(value) > 100_000:
        raise HTTPException(400, "分享内容过长（最多 100000 个字符）")
    return value


def _write_account_cookie_file(account_id: int | None) -> tuple[str, str, str]:
    """把 Patchright storage_state 临时转换为 yt-dlp 可读的 Netscape Cookie 文件。

    返回 (cookie_file, account_proxy, account_ua)。调用方必须在使用后删除 cookie_file。
    """
    if account_id is None:
        return "", "", ""
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc:
            raise HTTPException(404, "下载所选账号不存在")
        state_text = acc.storage_state or acc.creator_storage_state or ""
        raw_cookie = acc.cookie or ""
        platform = acc.platform
        account_proxy = acc.proxy or ""
        account_ua = acc.ua or ""

    try:
        state = json.loads(state_text or "{}")
    except Exception:
        state = {}
    cookies = list(state.get("cookies") or [])
    if not cookies and raw_cookie:
        default_domain = {
            "xhs": ".xiaohongshu.com",
            "kuaishou": ".kuaishou.com",
            "shipinhao": ".weixin.qq.com",
        }.get(platform, ".douyin.com")
        for part in raw_cookie.split(";"):
            name, sep, value = part.strip().partition("=")
            if sep and name:
                cookies.append({
                    "name": name, "value": value, "domain": default_domain,
                    "path": "/", "secure": True, "expires": 0,
                })
    if not cookies:
        raise HTTPException(400, "所选账号没有可复用的 Cookie 登录态")

    fh = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n",
        prefix="creatorhub-share-", suffix=".cookies.txt", delete=False,
    )
    try:
        fh.write("# Netscape HTTP Cookie File\n")
        for cookie in cookies:
            name = str(cookie.get("name") or "").replace("\t", "").replace("\n", "")
            value = str(cookie.get("value") or "").replace("\t", "").replace("\n", "")
            domain = str(cookie.get("domain") or "").strip()
            if not name or not domain:
                continue
            include_subdomains = "TRUE" if domain.startswith(".") else "FALSE"
            path = str(cookie.get("path") or "/").replace("\t", "")
            secure = "TRUE" if cookie.get("secure") else "FALSE"
            expires_raw = cookie.get("expires") or cookie.get("expirationDate") or 0
            try:
                expires = max(0, int(float(expires_raw)))
            except (TypeError, ValueError):
                expires = 0
            fh.write(
                f"{domain}\t{include_subdomains}\t{path}\t{secure}\t"
                f"{expires}\t{name}\t{value}\n"
            )
    finally:
        fh.close()
    return fh.name, account_proxy, account_ua


def _share_file_role(path: Path) -> str:
    name = path.name.lower()
    suffix = path.suffix.lower()
    if name.endswith(".info.json"):
        return "metadata"
    if ".cover." in name:
        return "thumbnail"
    if suffix in {".jpg", ".jpeg", ".png", ".webp", ".avif"}:
        return "media"
    if suffix in {".srt", ".vtt", ".ass", ".lrc", ".ttml"}:
        return "subtitle"
    if suffix in {
        ".mp4", ".mkv", ".webm", ".mov", ".flv", ".avi", ".m4v",
        ".mp3", ".m4a", ".aac", ".opus", ".ogg", ".wav", ".flac",
    }:
        return "media"
    if suffix in {".json", ".description"}:
        return "metadata"
    return "other"


_SHARE_HISTORY_META_KEYS = {
    "id", "title", "description", "uploader", "uploader_id", "channel",
    "duration", "timestamp", "upload_date", "view_count", "like_count",
    "comment_count", "thumbnail", "webpage_url", "original_url",
    "extractor", "extractor_key", "ext", "format", "format_id",
    "width", "height", "platform", "media_type", "media_count",
}


def _compact_share_metadata(metadata: Any) -> dict:
    """只保留历史列表需要的字段，避免把 yt-dlp 的完整响应重复写进数据库。"""
    if not isinstance(metadata, dict):
        return {}
    return {
        key: value for key, value in metadata.items()
        if key in _SHARE_HISTORY_META_KEYS
    }


def _save_share_download_history(
    *,
    source_url: str,
    platform: str,
    account_id: int | None,
    item: dict,
) -> int:
    metadata = _compact_share_metadata(item.get("metadata"))
    files = item.get("files") if isinstance(item.get("files"), list) else []
    media_files = [file for file in files if file.get("role") == "media"]
    status = "done" if item.get("ok") else "failed"
    record = ShareDownloadRecord(
        platform=platform or str(metadata.get("platform") or detect_platform(source_url)),
        source_url=source_url,
        account_id=account_id,
        item_id=str(metadata.get("id") or ""),
        title=str(metadata.get("title") or ""),
        author=str(metadata.get("uploader") or metadata.get("channel") or ""),
        media_type=str(metadata.get("media_type") or ""),
        media_count=int(metadata.get("media_count") or len(media_files)),
        cover_url=str(metadata.get("thumbnail") or ""),
        status=status,
        output_dir=str(item.get("output_dir") or ""),
        files_json=json.dumps(files, ensure_ascii=False, default=str),
        metadata_json=json.dumps(metadata, ensure_ascii=False, default=str),
        error=str(item.get("error") or ""),
    )
    with get_session() as s:
        s.add(record)
        s.commit()
        s.refresh(record)
        return int(record.id or 0)


def _backfill_share_download_history() -> int:
    """从已有的 ``*.info.json`` 补录旧下载，升级后历史列表不会是空的。"""
    default_root = get_setting("download_dir", cfg.engine.media_dir) or cfg.engine.media_dir
    share_root = Path(default_root).expanduser() / "share"
    if not share_root.is_dir():
        return 0

    restored = 0
    # 防止用户把超大归档目录设成下载目录时启动扫描失控。
    for info_path in list(share_root.rglob("*.info.json"))[:5000]:
        try:
            metadata_raw = json.loads(info_path.read_text(encoding="utf-8"))
            if not isinstance(metadata_raw, dict):
                continue
            metadata = _compact_share_metadata(metadata_raw)
            item_id = str(metadata.get("id") or "")
            source_url = str(
                metadata.get("webpage_url")
                or metadata.get("original_url")
                or ""
            )
            if not item_id and not source_url:
                continue

            with get_session() as s:
                query = select(ShareDownloadRecord.id)
                if item_id:
                    query = query.where(ShareDownloadRecord.item_id == item_id)
                else:
                    query = query.where(ShareDownloadRecord.source_url == source_url)
                if s.exec(query.limit(1)).first() is not None:
                    continue

            prefix = f"{item_id}_" if item_id else info_path.name[:-10]
            files = []
            for path in sorted(info_path.parent.iterdir()):
                if not path.is_file() or path.suffix.lower() in {".part", ".ytdl"}:
                    continue
                # 原生抖音目录可能含多个作品，只关联相同作品 ID 前缀的文件。
                if item_id and not path.name.startswith(prefix):
                    continue
                try:
                    relative = path.relative_to(share_root).as_posix()
                    size = path.stat().st_size
                except OSError:
                    continue
                files.append({
                    "name": path.name,
                    "path": str(path.resolve()),
                    "relative_path": relative,
                    "size": size,
                    "role": _share_file_role(path),
                })

            platform = str(metadata.get("platform") or detect_platform(source_url))
            _save_share_download_history(
                source_url=source_url,
                platform=platform,
                account_id=None,
                item={
                    "ok": True,
                    "output_dir": str(info_path.parent.resolve()),
                    "metadata": metadata,
                    "files": files,
                },
            )
            restored += 1
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    return restored


def _share_history_dict(record: ShareDownloadRecord) -> dict:
    try:
        files = json.loads(record.files_json or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        files = []
    if not isinstance(files, list):
        files = []
    try:
        metadata = json.loads(record.metadata_json or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        metadata = {}
    if not isinstance(metadata, dict):
        metadata = {}
    media_files = [item for item in files if isinstance(item, dict) and item.get("role") == "media"]
    first_file = media_files[0] if media_files else (files[0] if files and isinstance(files[0], dict) else {})

    def number(value: Any) -> int:
        try:
            return int(float(value or 0))
        except (TypeError, ValueError):
            return 0

    description = str(record.title or metadata.get("title") or metadata.get("description") or "")
    create_time = number(metadata.get("timestamp"))
    if not create_time:
        upload_date = str(metadata.get("upload_date") or "")
        if len(upload_date) == 8 and upload_date.isdigit():
            try:
                create_time = int(datetime.strptime(upload_date, "%Y%m%d").timestamp())
            except ValueError:
                create_time = 0
    local_path = str(first_file.get("path") or "") if isinstance(first_file, dict) else ""
    quality = str(metadata.get("format") or metadata.get("format_id") or "")
    return {
        "id": record.id,
        "platform": record.platform,
        "source_url": record.source_url,
        "account_id": record.account_id,
        "item_id": record.item_id,
        "title": record.title,
        "author": record.author,
        "media_type": record.media_type,
        "media_count": record.media_count,
        "cover_url": record.cover_url,
        "status": record.status,
        "output_dir": record.output_dir,
        "files": files if isinstance(files, list) else [],
        "metadata": metadata if isinstance(metadata, dict) else {},
        "error": record.error,
        "created_at": record.created_at.isoformat() if record.created_at else "",
        # 与「作品监控」列表兼容的展示字段，方便链接下载历史复用同一套作品表格。
        "aweme_id": record.item_id,
        "desc": description,
        "create_time": create_time,
        "quality": quality,
        "like_count": number(metadata.get("like_count")),
        "comment_count": number(metadata.get("comment_count")),
        "duration": number(metadata.get("duration")),
        "download_status": record.status,
        "local_path": local_path,
    }


def _native_aweme_metadata(aweme, source_url: str) -> dict:
    platform = str(getattr(aweme, "platform", "") or "douyin")
    platform_name = "Xhs" if platform == "xhs" else platform.title()
    return {
        "id": aweme.aweme_id,
        "title": aweme.desc or aweme.aweme_id,
        "description": aweme.desc,
        "uploader": aweme.author_name,
        "duration": aweme.duration,
        "timestamp": aweme.create_time,
        "like_count": aweme.like_count,
        "comment_count": aweme.comment_count,
        "thumbnail": aweme.cover,
        "webpage_url": source_url,
        "original_url": source_url,
        "extractor": f"creatorhub:{platform}",
        "extractor_key": f"CreatorHub{platform_name}",
        "ext": "jpg" if aweme.media_type == "images" else "mp4",
        "format": aweme.quality_label,
        "platform": platform,
        "media_type": aweme.media_type,
        "media_count": len(aweme.medias),
    }


async def _douyin_native_share(
    source_url: str,
    *,
    account_id: int | None,
    output_root: Path,
    quality: str,
    should_download: bool,
    save_metadata: bool,
    save_thumbnail: bool,
    proxy: str,
    user_agent: str,
) -> dict | None:
    """用 CreatorHub 自带抖音接口兜底 yt-dlp 尚未支持的 /note/、/slides/。

    返回 None 表示它不是可解析的抖音单作品链接，应继续走通用提取器。
    """
    if account_id is None:
        return None
    aweme_id = await resolve_aweme_id(source_url, user_agent)
    if not aweme_id:
        return None

    with get_session() as s:
        account = s.get(DouyinAccount, account_id)
        if not account or account.platform != "douyin":
            return None
        state = account.storage_state or account.creator_storage_state or ""
        raw_cookie = account.cookie or ""
    cookie = douyin_cookie_from_state(state) or raw_cookie
    client = DouyinClient(cookie, user_agent,
                          timeout=cfg.engine.request_timeout_seconds,
                          proxy=proxy,
                          **douyin_client_environment(account))
    raw = await client.fetch_video_detail(aweme_id)
    if not raw:
        raise ShareDownloadError(
            "已识别到抖音作品 ID，但所选账号未能读取作品详情；"
            "请检查账号登录态或更换抖音账号"
        )
    aweme = parse_aweme(raw, quality if quality != "audio" else "highest")
    if not aweme:
        raise ShareDownloadError("抖音作品详情已读取，但没有找到可下载的视频或图片")

    # 原生直链下载器不做音频转码；仅音频请求继续交给 yt-dlp/ffmpeg。
    if quality == "audio" and aweme.media_type == "video":
        return None

    metadata = _native_aweme_metadata(aweme, source_url)
    if not should_download:
        return {
            "ok": True,
            "url": source_url,
            "metadata": metadata,
            "warnings": [],
        }

    downloader = Downloader(
        str(output_root),
        user_agent,
        timeout=max(30.0, cfg.engine.request_timeout_seconds),
    )
    ok, _local_path, error = await downloader.download_aweme(
        aweme, base_dir=str(output_root), proxy=proxy
    )
    if not ok:
        raise ShareDownloadError(error or "抖音媒体下载失败")

    target_dir = output_root / safe_title(aweme.author_name or "unknown")
    title = safe_title(aweme.desc) or aweme.aweme_id
    if save_metadata:
        info_path = target_dir / f"{aweme.aweme_id}_{title}.info.json"
        payload = {
            **metadata,
            "media": [
                {"url": media.url, "kind": media.kind, "ext": media.ext,
                 "index": media.index}
                for media in aweme.medias
            ],
            "raw": raw,
        }
        info_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )

    # 视频封面单独保存；图文作品的图片本身已经全部下载。
    if save_thumbnail and aweme.media_type == "video" and aweme.cover:
        import httpx
        from .browser.manager import normalize_proxy

        cover_path = target_dir / f"{aweme.aweme_id}_{title}.cover.jpg"
        headers = {"User-Agent": user_agent, "Referer": "https://www.douyin.com/"}
        try:
            async with httpx.AsyncClient(
                timeout=max(30.0, cfg.engine.request_timeout_seconds),
                follow_redirects=True,
                headers=headers,
                proxy=normalize_proxy(proxy) or None,
            ) as http:
                await downloader._download_one(http, aweme.cover, cover_path)
        except Exception:
            pass

    files = []
    for path in sorted(target_dir.glob(f"{aweme.aweme_id}_*")):
        if not path.is_file() or path.suffix.lower() in {".part", ".ytdl"}:
            continue
        files.append({
            "name": path.name,
            "path": str(path.resolve()),
            "relative_path": path.relative_to(output_root).as_posix(),
            "size": path.stat().st_size,
            "role": _share_file_role(path),
        })
    if not any(item["role"] == "media" for item in files):
        raise ShareDownloadError("抖音作品解析成功，但本地没有生成媒体文件")
    return {
        "ok": True,
        "job_id": f"douyin_{aweme.aweme_id}",
        "url": source_url,
        "output_dir": str(target_dir.resolve()),
        "metadata": metadata,
        "files": files,
        "progress": {"status": "finished"},
        "warnings": [],
    }


async def _xhs_native_share(
    source_url: str,
    *,
    account_id: int | None,
    output_root: Path,
    quality: str,
    should_download: bool,
    save_metadata: bool,
    save_thumbnail: bool,
    proxy: str,
) -> dict | None:
    """Read XHS note metadata in the selected account browser, then fetch CDN media."""
    if account_id is None or not _xhs_browser_reads_enabled():
        return None
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if not account or account.platform != "xhs":
            return None
        identity = browser.identity_for(account)

    from .browser.manager import normalize_proxy
    if normalize_proxy(proxy) != normalize_proxy(identity.proxy):
        raise ShareDownloadError(
            "小红书链接下载必须复用账号已绑定代理；请先在账号环境中配置代理，"
            "不要在下载页临时切换出口"
        )

    async def _read_note():
        final_url = source_url
        host = (urlsplit(source_url).hostname or "").lower()
        if host == "xhslink.com" or host.endswith(".xhslink.com"):
            try:
                async with browser.visible_page(
                        identity, url=source_url) as page:
                    await page.wait_for_timeout(800)
                    final_url = str(page.url or source_url)
            except Exception as exc:
                return None, f"小红书短链解析失败: {exc}"
        ref = await xhs_resolve_note(final_url, _direct_request_ua(identity))
        if ref is None:
            return None, "没有从链接识别到小红书笔记 ID"
        card, read_error = await fetch_xhs_note_detail(
            browser,
            identity,
            ref.note_id,
            xsec_token=ref.xsec_token,
            xsec_source=ref.xsec_source or "pc_feed",
            block_media=cfg.engine.block_media_resources,
        )
        return {
            "card": card or {},
            "note_id": ref.note_id,
            "final_url": final_url,
        }, read_error

    payload, outcome = await _run_account_read(
        account_id,
        OperationKind.READ_HEAVY,
        f"share-xhs:{account_id}",
        _read_note,
        empty_result={"card": {}, "note_id": "", "final_url": source_url},
    )
    if isinstance(outcome, dict):
        raise ShareDownloadError(
            f"小红书账号读取正在冷却: {outcome.get('reason') or '稍后重试'}")
    if outcome:
        raise ShareDownloadError(f"小红书笔记读取失败: {outcome}")

    from .platforms.xhs import parse_note_detail as parse_xhs_note_detail
    note_id = str(payload.get("note_id") or "")
    card = payload.get("card") or {}
    aweme = parse_xhs_note_detail(card, {"note_id": note_id})
    if not aweme or not aweme.medias:
        raise ShareDownloadError("小红书笔记已打开，但没有取得可下载的图片或视频")

    # 不把账号 Cookie 回退给 yt-dlp 直连页面；这样才不会在同一登录态下
    # 突然切换 TLS/HTTP2 指纹。
    if quality == "audio" and aweme.media_type == "video":
        raise ShareDownloadError(
            "小红书账号浏览器模式暂不执行音频提取，请选择视频画质下载"
        )

    actual_ua = _direct_request_ua(identity)
    metadata = _native_aweme_metadata(
        aweme, str(payload.get("final_url") or source_url))
    if not should_download:
        return {
            "ok": True,
            "url": source_url,
            "metadata": metadata,
            "warnings": [],
        }

    downloader = Downloader(
        str(output_root), actual_ua,
        timeout=max(30.0, cfg.engine.download_timeout_seconds),
    )
    ok, _local_path, error = await downloader.download_aweme(
        aweme, base_dir=str(output_root), proxy=identity.proxy or "")
    if not ok:
        raise ShareDownloadError(error or "小红书媒体下载失败")

    target_dir = output_root / safe_title(aweme.author_name or "unknown")
    title = safe_title(aweme.desc) or aweme.aweme_id
    if save_metadata:
        info_path = target_dir / f"{aweme.aweme_id}_{title}.info.json"
        info_path.write_text(
            json.dumps({
                **metadata,
                "media": [
                    {"url": media.url, "kind": media.kind,
                     "ext": media.ext, "index": media.index}
                    for media in aweme.medias
                ],
                "raw": card,
            }, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )

    if save_thumbnail and aweme.media_type == "video" and aweme.cover:
        import httpx
        cover_path = target_dir / f"{aweme.aweme_id}_{title}.cover.jpg"
        try:
            async with httpx.AsyncClient(
                    timeout=max(30.0, cfg.engine.download_timeout_seconds),
                    follow_redirects=True,
                    headers={
                        "User-Agent": actual_ua,
                        "Referer": "https://www.xiaohongshu.com/",
                    },
                    proxy=normalize_proxy(identity.proxy) or None) as http:
                await downloader._download_one(http, aweme.cover, cover_path)
        except Exception:
            pass

    files = []
    for path in sorted(target_dir.glob(f"{aweme.aweme_id}_*")):
        if not path.is_file() or path.suffix.lower() in {".part", ".ytdl"}:
            continue
        files.append({
            "name": path.name,
            "path": str(path.resolve()),
            "relative_path": path.relative_to(output_root).as_posix(),
            "size": path.stat().st_size,
            "role": _share_file_role(path),
        })
    if not any(item["role"] == "media" for item in files):
        raise ShareDownloadError("小红书笔记解析成功，但本地没有生成媒体文件")
    return {
        "ok": True,
        "job_id": f"xhs_{aweme.aweme_id}",
        "url": source_url,
        "output_dir": str(target_dir.resolve()),
        "metadata": metadata,
        "files": files,
        "progress": {"status": "finished"},
        "warnings": [],
    }


@app.post("/api/share-download/links")
async def parse_share_links(body: ShareLinksIn):
    """只做本地文本清洗和链接提取，不访问分享站点。"""
    text = _share_input(body.share_text)
    limit = max(1, min(int(body.limit or 10), 20))
    normalized = normalize_share_text(text)
    links = extract_share_urls(normalized, limit=limit)
    return {
        "ok": bool(links),
        "normalized_text": normalized,
        "links": [item.to_dict() for item in links],
        "count": len(links),
    }


@app.post("/api/share-download")
async def share_download(body: ShareDownloadIn):
    """解析分享文案，并下载媒体/封面/字幕/元数据，或只读取作品信息。"""
    text = _share_input(body.share_text)
    try:
        normalized = normalize_share_text(text)
        links = require_share_urls(normalized, limit=10)
    except ShareLinkError as exc:
        raise HTTPException(400, str(exc))

    if body.all_links:
        selected = links
    else:
        if body.link_index < 0 or body.link_index >= len(links):
            raise HTTPException(400, f"link_index 超出范围（共识别到 {len(links)} 条链接）")
        selected = [links[body.link_index]]
    if body.max_filesize_mb < 0 or body.max_filesize_mb > 1024 * 100:
        raise HTTPException(400, "max_filesize_mb 需为 0～102400")

    default_root = get_setting("download_dir", cfg.engine.media_dir) or cfg.engine.media_dir
    output_root = Path(body.output_dir.strip()).expanduser() if body.output_dir and body.output_dir.strip() \
        else Path(default_root).expanduser() / "share"
    try:
        output_root.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        raise HTTPException(400, f"下载目录不可用：{exc}")

    cookie_file = ""
    try:
        cookie_file, account_proxy, account_ua = _write_account_cookie_file(body.account_id)
        proxy = body.proxy.strip() or account_proxy
        user_agent = account_ua or cfg.engine.user_agent
        downloader = ShareDownloader(
            output_root,
            user_agent=user_agent,
            timeout=cfg.engine.request_timeout_seconds,
        )
        results = []
        async with _share_download_sem:
            for link in selected:
                try:
                    item = None
                    if link.platform == "douyin":
                        item = await _douyin_native_share(
                            link.url,
                            account_id=body.account_id,
                            output_root=output_root,
                            quality=body.quality,
                            should_download=body.download,
                            save_metadata=body.save_metadata,
                            save_thumbnail=body.save_thumbnail,
                            proxy=proxy,
                            user_agent=user_agent,
                        )
                    elif link.platform == "xhs":
                        item = await _xhs_native_share(
                            link.url,
                            account_id=body.account_id,
                            output_root=output_root,
                            quality=body.quality,
                            should_download=body.download,
                            save_metadata=body.save_metadata,
                            save_thumbnail=body.save_thumbnail,
                            proxy=proxy,
                        )
                    if item is not None:
                        pass
                    elif body.download:
                        item = await downloader.download(
                            link.url,
                            quality=body.quality,
                            save_metadata=body.save_metadata,
                            save_thumbnail=body.save_thumbnail,
                            save_subtitles=body.save_subtitles,
                            proxy=proxy,
                            cookie_file=cookie_file,
                            max_filesize_mb=body.max_filesize_mb,
                        )
                    else:
                        item = await downloader.inspect(
                            link.url, proxy=proxy, cookie_file=cookie_file
                        )
                    item["input_platform"] = link.platform
                except ShareDownloadError as exc:
                    item = {
                        "ok": False,
                        "url": link.url,
                        "input_platform": link.platform,
                        "error": str(exc),
                    }
                if body.download:
                    try:
                        item["history_id"] = _save_share_download_history(
                            source_url=link.url,
                            platform=link.platform,
                            account_id=body.account_id,
                            item=item,
                        )
                    except Exception as exc:
                        item.setdefault("warnings", []).append(
                            f"下载已处理，但历史记录写入失败：{exc}"
                        )
                results.append(item)
    finally:
        if cookie_file:
            try:
                Path(cookie_file).unlink(missing_ok=True)
            except OSError:
                pass

    return {
        "ok": bool(results) and all(item.get("ok") for item in results),
        "normalized_text": normalized,
        "links": [item.to_dict() for item in links],
        "results": results,
    }


@app.get("/api/share-download/history")
async def get_share_download_history(limit: int = 100, platform: str = ""):
    limit = max(1, min(int(limit or 100), 500))
    with get_session() as s:
        query = select(ShareDownloadRecord)
        if platform.strip():
            query = query.where(ShareDownloadRecord.platform == platform.strip())
        rows = s.exec(
            query.order_by(ShareDownloadRecord.created_at.desc()).limit(limit)
        ).all()
        return [_share_history_dict(row) for row in rows]


class ShareHistoryBatchDeleteIn(BaseModel):
    ids: list[int]


@app.post("/api/share-download/history/batch-delete")
async def delete_share_download_history_batch(body: ShareHistoryBatchDeleteIn):
    """批量删除链接下载历史记录，不清理本地媒体文件。"""
    ids = {int(value) for value in (body.ids or []) if int(value) > 0}
    if len(ids) > 200:
        raise HTTPException(400, "单次最多删除 200 条历史记录")
    if not ids:
        return {"ok": True, "deleted": 0}
    with get_session() as s:
        rows = s.exec(
            select(ShareDownloadRecord).where(ShareDownloadRecord.id.in_(ids))
        ).all()
        for record in rows:
            s.delete(record)
        s.commit()
    return {"ok": True, "deleted": len(rows)}


def _share_history_files(record: ShareDownloadRecord) -> list[dict]:
    try:
        files = json.loads(record.files_json or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        files = []
    return [item for item in files if isinstance(item, dict)] if isinstance(files, list) else []


def _share_history_local_path(
    record: ShareDownloadRecord,
    media_index: int | None = None,
) -> Path | None:
    files = _share_history_files(record)
    candidates = [item for item in files if item.get("role") == "media"]
    if media_index is not None:
        if media_index < 0 or media_index >= len(candidates):
            return None
        candidates = [candidates[media_index]]
    if not candidates:
        candidates = files
    for item in candidates:
        raw = str(item.get("path") or "").strip()
        if not raw:
            continue
        try:
            path = Path(raw).expanduser().resolve(strict=True)
        except (OSError, RuntimeError):
            continue
        if path.is_file() or path.is_dir():
            return path
    if media_index is None and record.output_dir:
        try:
            path = Path(record.output_dir).expanduser().resolve(strict=True)
            if path.is_dir():
                return path
        except (OSError, RuntimeError):
            pass
    return None


def _require_local_action(request: Request, action: str = "reveal") -> None:
    """仅允许本机 CreatorHub 页面触发文件管理器操作。"""
    def is_loopback(host: str) -> bool:
        host = host.split("%", 1)[0].casefold()
        if host == "localhost":
            return True
        try:
            return ip_address(host).is_loopback
        except ValueError:
            return False

    client_host = request.client.host if request.client else ""
    page_host = request.url.hostname or ""
    try:
        origin = urlsplit(request.headers.get("origin", ""))
        same_origin = (origin.scheme == request.url.scheme and
                       (origin.hostname or "").casefold() == page_host.casefold() and
                       origin.port == request.url.port)
    except ValueError:
        same_origin = False
    local_action = request.headers.get("x-creatorhub-local-action") == action
    if not is_loopback(client_host) or not is_loopback(page_host) or \
            not same_origin or not local_action:
        raise HTTPException(403, "仅允许从本机 CreatorHub 页面执行文件操作")


@app.get("/api/share-download/history/{record_id}/media/{media_index}")
async def share_download_history_media(record_id: int, media_index: int):
    """返回链接下载历史中的本地媒体，供作品预览复用。"""
    with get_session() as s:
        record = s.get(ShareDownloadRecord, record_id)
        if not record:
            raise HTTPException(404, "下载历史不存在")
        path = _share_history_local_path(record, media_index)
    if not path or not path.is_file():
        raise HTTPException(404, "本地媒体不存在")
    return FileResponse(
        path,
        filename=path.name,
        content_disposition_type="inline",
        headers={"Cache-Control": "private, no-cache"},
    )


@app.get("/api/share-download/history/{record_id}/preview")
async def share_download_history_preview(record_id: int):
    """返回链接下载历史的本地媒体地址，供前端复用作品预览弹窗。"""
    with get_session() as s:
        record = s.get(ShareDownloadRecord, record_id)
        if not record:
            raise HTTPException(404, "下载历史不存在")
        files = _share_history_files(record)
        media_files = [item for item in files if item.get("role") == "media"]
        medias = []
        for index, item in enumerate(media_files):
            raw = str(item.get("path") or "").strip()
            if not raw:
                continue
            try:
                path = Path(raw).expanduser().resolve(strict=True)
            except (OSError, RuntimeError):
                continue
            if not path.is_file():
                continue
            kind = "image" if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp", ".avif"} else "video"
            medias.append({
                "kind": kind,
                "url": f"/api/share-download/history/{record_id}/media/{index}",
            })
        media_type = record.media_type or ("images" if medias and medias[0]["kind"] == "image" else "video")
        video = next((item for item in medias if item["kind"] == "video"), None)
        return {
            "id": record.id,
            "desc": record.title or record.item_id,
            "media_type": media_type,
            "cover_url": record.cover_url,
            "medias": medias,
            "local_url": video["url"] if video else "",
        }


@app.post("/api/share-download/history/{record_id}/reveal")
async def reveal_share_download_history(record_id: int, request: Request):
    """在服务所在电脑的文件管理器中打开链接下载目录或定位文件。"""
    _require_local_action(request)
    with get_session() as s:
        record = s.get(ShareDownloadRecord, record_id)
        if not record:
            raise HTTPException(404, "下载历史不存在")
        path = _share_history_local_path(record)
    if not path:
        raise HTTPException(404, "本地文件不存在")
    try:
        await asyncio.to_thread(_reveal_in_file_manager, path)
    except OSError as e:
        raise HTTPException(500, f"打开文件夹失败:{e}") from e
    return {"ok": True}


@app.delete("/api/share-download/history/{record_id}")
async def delete_share_download_history(record_id: int):
    """只删除历史行，不删除磁盘里的媒体文件。"""
    with get_session() as s:
        record = s.get(ShareDownloadRecord, record_id)
        if not record:
            raise HTTPException(404, "下载历史不存在")
        s.delete(record)
        s.commit()
    return {"ok": True}


# ─────────── 监控目标 ───────────
def _meta_text(value: str | None, max_len: int) -> str:
    """清理用于界面管理的分组名/别名。"""
    return " ".join((value or "").strip().split())[:max_len]


def _meta_tags(value: list[str] | None) -> list[str] | None:
    """清理、去重标签；None 表示更新时不修改。"""
    if value is None:
        return None
    result: list[str] = []
    seen: set[str] = set()
    for raw in value:
        tag = " ".join(str(raw or "").strip().split())[:24]
        key = tag.casefold()
        if not tag or key in seen:
            continue
        seen.add(key)
        result.append(tag)
        if len(result) >= 12:
            break
    return result


def _load_meta_tags(raw: str | None) -> list[str]:
    """兼容 JSON 与早期手工逗号分隔格式。"""
    if not raw:
        return []
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return _meta_tags([str(item) for item in data]) or []
    except (TypeError, ValueError, json.JSONDecodeError):
        pass
    return _meta_tags(str(raw).replace("，", ",").split(",")) or []


def _dump_meta_tags(tags: list[str] | None) -> str:
    return json.dumps(tags or [], ensure_ascii=False, separators=(",", ":"))


def _meta_matches(item: MonitorTarget | CommentWatch, group_name: str, tag: str) -> bool:
    if group_name and item.group_name != group_name:
        return False
    if tag and tag not in _load_meta_tags(item.tags):
        return False
    return True


# ─────────── 抖音 / 小红书关键词批量采集 ───────────
class KeywordCollectionIn(BaseModel):
    platform: str = "douyin"
    account_id: int
    source_type: str = "keyword"
    source_ref: str = ""
    source_name: str = ""
    keywords: list[str] = PydanticField(default_factory=list)
    max_contents_per_keyword: int = 20
    max_pages_per_keyword: int = 12
    stagnant_pages: int = 3
    search_sort: str = "general"
    publish_time: str = "all"
    content_type: str = "all"
    min_likes: int = 0
    min_comments: int = 0
    max_comments_per_content: int = 20
    include_replies: bool = False
    download_media: bool = False
    video_quality: str = "highest"
    download_dir: str = ""


def _validated_collection_input(body: KeywordCollectionIn) \
        -> tuple[str, list[str], str, str, dict]:
    """校验创建/编辑共用的任务配置并返回规范化值。"""
    platform = body.platform.strip().lower()
    if platform not in {"douyin", "xhs"}:
        raise HTTPException(400, "关键词批量采集仅支持抖音或小红书")
    source_type = body.source_type.strip().lower() or "keyword"
    if source_type not in {"keyword", "favorite_all", "favorite_board", "creator"}:
        raise HTTPException(400, "采集来源须为关键词、创作者主页、全部收藏或指定收藏夹")
    if source_type in {"favorite_all", "favorite_board"} and platform != "xhs":
        raise HTTPException(400, "收藏来源仅支持小红书")
    source_ref = body.source_ref.strip()
    source_name = body.source_name.strip()
    if source_type == "favorite_board" and not source_ref:
        raise HTTPException(400, "指定收藏夹采集必须提供收藏夹 ID")
    if source_type == "creator" and not source_ref:
        raise HTTPException(400, "创作者主页采集必须提供用户 ID")
    if len(source_ref) > 200 or len(source_name) > 120:
        raise HTTPException(400, "采集来源标识或名称过长")
    keywords = _collection_keywords(body.keywords)
    if source_type == "keyword":
        if not keywords:
            raise HTTPException(400, "请至少填写一个关键词")
        if len(keywords) > 20:
            raise HTTPException(400, "单个任务最多包含 20 个关键词")
        if any(len(value) > 80 for value in keywords):
            raise HTTPException(400, "单个关键词不能超过 80 个字符")
    else:
        keywords = []
        source_name = source_name or ("全部收藏" if source_type == "favorite_all" else
                                      "收藏夹" if source_type == "favorite_board" else
                                      f"创作者 {source_ref}")
    if not 1 <= body.max_contents_per_keyword <= 100:
        raise HTTPException(400, "每个关键词作品数须为 1~100")
    if not 1 <= body.max_pages_per_keyword <= 40:
        raise HTTPException(400, "每个关键词采集深度须为 1~40 页")
    if not 1 <= body.stagnant_pages <= 8:
        raise HTTPException(400, "连续无新结果停止阈值须为 1~8 页")
    search_sort = body.search_sort.strip().lower()
    if search_sort not in {"general", "latest", "most_liked"}:
        raise HTTPException(400, "搜索排序须为综合、最新发布或最多点赞")
    publish_time = body.publish_time.strip().lower()
    if publish_time not in {"all", "day", "week", "half_year"}:
        raise HTTPException(400, "发布时间筛选值无效")
    content_type = body.content_type.strip().lower()
    if content_type not in {"all", "video", "images"}:
        raise HTTPException(400, "内容类型筛选值无效")
    if not 0 <= body.min_likes <= 2_000_000_000:
        raise HTTPException(400, "最低点赞数须为非负整数")
    if not 0 <= body.min_comments <= 2_000_000_000:
        raise HTTPException(400, "最低评论数须为非负整数")
    if not 0 <= body.max_comments_per_content <= 200:
        raise HTTPException(400, "每个作品评论数须为 0~200")
    quality = body.video_quality.strip() or "highest"
    if quality not in QUALITY_CHOICES:
        raise HTTPException(400, f"画质取值无效: {quality}")
    download_dir = body.download_dir.strip()
    if download_dir:
        try:
            Path(download_dir).expanduser().mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            raise HTTPException(400, f"下载目录不可用: {exc}")
    options = {
        "source_type": source_type,
        "source_ref": source_ref,
        "source_name": source_name,
        "max_pages_per_keyword": body.max_pages_per_keyword,
        "stagnant_pages": body.stagnant_pages,
        "search_sort": search_sort,
        "publish_time": publish_time,
        "content_type": content_type,
        "min_likes": body.min_likes,
        "min_comments": body.min_comments,
    }
    return platform, keywords, quality, download_dir, options


def _collection_keywords(values: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        # API 调用者也可把多行或逗号分隔内容放进一个数组项。
        expanded = str(raw or "").replace("，", ",").replace("\r", "\n")
        for line in expanded.replace("\n", ",").split(","):
            value = line.strip()
            key = value.casefold()
            if value and key not in seen:
                seen.add(key)
                out.append(value)
    return out


def _collection_error_for_display(value: str) -> str:
    """把采集异常压缩成适合页面展示的短文案，原始值仍保留供诊断/导出。"""
    output = []
    for raw_line in str(value or "").splitlines():
        line = " ".join(raw_line.split()).strip()
        if not line:
            continue
        lowered = line.lower()
        if "targetclosederror" in lowered or "has been closed" in lowered:
            keyword = line.split(":", 1)[0].strip()
            prefix = f"{keyword}：" if keyword else ""
            line = f"{prefix}采集窗口已关闭，请点击“续跑”并保持窗口开启"
        elif len(line) > 220:
            line = line[:219].rstrip() + "…"
        output.append(line)
    return "\n".join(output[-8:])


def _collection_job_dict(job: KeywordCollectionJob) -> dict:
    try:
        keywords = json.loads(job.keywords or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        keywords = []
    source_type = str(job.source_type or "keyword")
    total_keywords = len(keywords) if source_type == "keyword" else 1
    planned = total_keywords * max(0, job.max_contents_per_keyword)
    processed_keywords = min(
        total_keywords, max(0, int(job.processed_keyword_count or 0)))
    current_item_total = max(0, int(job.current_item_total or 0))
    current_item_index = min(
        current_item_total, max(0, int(job.current_item_index or 0)))
    if job.status == "done":
        progress_percent = 100
    elif total_keywords:
        current_fraction = (
            current_item_index / current_item_total
            if current_item_total and processed_keywords < total_keywords
            else 0
        )
        progress_percent = min(
            100, round((processed_keywords + current_fraction)
                       * 100 / total_keywords))
    else:
        progress_percent = 0
    return {
        "id": job.id, "platform": job.platform, "account_id": job.account_id,
        "source_type": source_type, "source_ref": job.source_ref,
        "source_name": job.source_name,
        "keywords": keywords,
        "max_contents_per_keyword": job.max_contents_per_keyword,
        "max_pages_per_keyword": job.max_pages_per_keyword,
        "stagnant_pages": job.stagnant_pages,
        "search_sort": job.search_sort,
        "publish_time": job.publish_time,
        "content_type": job.content_type,
        "min_likes": job.min_likes,
        "min_comments": job.min_comments,
        "max_comments_per_content": job.max_comments_per_content,
        "include_replies": job.include_replies,
        "download_media": job.download_media,
        "video_quality": job.video_quality,
        "download_dir": job.download_dir,
        "status": job.status, "current_keyword": job.current_keyword,
        "current_step": job.current_step,
        "processed_keyword_count": processed_keywords,
        "total_keyword_count": total_keywords,
        "current_item_index": current_item_index,
        "current_item_total": current_item_total,
        "progress_percent": progress_percent,
        "content_count": job.content_count, "comment_count": job.comment_count,
        "planned_content_count": planned, "error_count": job.error_count,
        "error": _collection_error_for_display(job.error),
        "error_detail": job.error,
        "cancel_requested": job.cancel_requested,
        "created_at": job.created_at.isoformat() if job.created_at else None,
        "started_at": job.started_at.isoformat() if job.started_at else None,
        "finished_at": job.finished_at.isoformat() if job.finished_at else None,
    }


_COLLECTION_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".avif", ".gif"}
_COLLECTION_VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}
_COLLECTION_MEDIA_EXTS = _COLLECTION_IMAGE_EXTS | _COLLECTION_VIDEO_EXTS


def _collection_remote_medias(row: KeywordCollectionContent) -> list[dict]:
    """Return normalized remote media records saved by the collector."""
    try:
        raw_items = json.loads(row.media_json or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        raw_items = []
    if not isinstance(raw_items, list):
        return []
    medias = []
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        url = str(item.get("url") or "").strip()
        if not url:
            continue
        ext = str(item.get("ext") or "").strip().lower().lstrip(".")
        kind = str(item.get("kind") or "").strip().lower()
        if kind not in {"image", "video"}:
            kind = "image" if f".{ext}" in _COLLECTION_IMAGE_EXTS else "video"
        medias.append({"url": url, "kind": kind, "ext": ext})
    return medias


def _collection_local_path(row: KeywordCollectionContent) -> Path | None:
    if not row.local_path:
        return None
    try:
        path = Path(row.local_path).expanduser().resolve(strict=True)
    except (OSError, RuntimeError):
        return None
    return path if path.is_file() or path.is_dir() else None


def _collection_media_sort_key(path: Path) -> tuple[int, str]:
    match = re.search(r"_(\d+)\.[^.]+$", path.name)
    return (int(match.group(1)) if match else -1, path.name.casefold())


def _collection_local_media_paths(row: KeywordCollectionContent) -> list[Path]:
    """Resolve downloaded media without mixing files from another work."""
    path = _collection_local_path(row)
    if not path:
        return []
    if path.is_file():
        try:
            return [path] if path.suffix.lower() in _COLLECTION_MEDIA_EXTS and path.stat().st_size > 0 else []
        except OSError:
            return []
    prefix = f"{row.aweme_id}_"
    try:
        candidates = [
            child for child in path.iterdir()
            if child.is_file() and child.name.startswith(prefix)
            and child.suffix.lower() in _COLLECTION_MEDIA_EXTS
            and child.stat().st_size > 0
        ]
    except OSError:
        return []
    return sorted(candidates, key=_collection_media_sort_key)


def _collection_content_dict(row: KeywordCollectionContent) -> dict:
    if row.platform == "xhs":
        query = urlencode({
            "xsec_token": row.xsec_token,
            "xsec_source": row.xsec_source or "pc_search",
        }) if row.xsec_token else ""
        url = f"https://www.xiaohongshu.com/explore/{row.aweme_id}"
        if query:
            url += "?" + query
    else:
        url = f"https://www.douyin.com/video/{row.aweme_id}"
    local_files = _collection_local_media_paths(row)
    remote_medias = _collection_remote_medias(row)
    try:
        file_size = sum(path.stat().st_size for path in local_files)
    except OSError:
        file_size = 0
    return {
        "id": row.id, "job_id": row.job_id, "platform": row.platform,
        "keyword": row.keyword, "aweme_id": row.aweme_id, "desc": row.desc,
        "author_name": row.author_name, "author_id": row.author_id,
        "media_type": row.media_type, "create_time": row.create_time,
        "cover_url": row.cover_url, "like_count": row.like_count,
        "comment_count": row.comment_count,
        "collected_comment_count": row.collected_comment_count,
        "download_status": row.download_status, "local_path": row.local_path,
        "xsec_token": row.xsec_token, "xsec_source": row.xsec_source,
        "error": row.error, "url": url,
        "local_exists": bool(local_files),
        "media_count": len(local_files) or len(remote_medias),
        "file_size": file_size,
        "preview_available": bool(local_files or remote_medias or row.cover_url),
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }


def _collection_comment_dict(row: KeywordCollectionComment, content=None) -> dict:
    payload = {
        "id": row.id, "job_id": row.job_id, "content_id": row.content_id,
        "aweme_id": row.aweme_id, "comment_id": row.comment_id,
        "text": row.text, "user_nickname": row.user_nickname,
        "user_sec_uid": row.user_sec_uid, "ip_label": row.ip_label,
        "like_count": row.like_count, "create_time": row.create_time,
        "reply_to": row.reply_to,
    }
    if content is not None:
        payload["source_keyword"] = content.keyword or ""
        payload["source_desc"] = content.desc or ""
    else:
        payload["source_keyword"] = ""
        payload["source_desc"] = ""
    return payload


def _collection_comment_query(session, job_id: int, *, content_id: int | None = None,
                              q: str = "", ip_label: str = "",
                              user_sec_uid: str = "", dedupe_users: bool = False):
    """Build the shared comment query used by the modal and Excel export."""
    job = session.get(KeywordCollectionJob, job_id)
    if not job:
        raise HTTPException(404, "采集任务不存在")
    conditions = [KeywordCollectionComment.job_id == job_id]
    if content_id is not None:
        content = session.get(KeywordCollectionContent, content_id)
        if not content or content.job_id != job_id:
            raise HTTPException(404, "采集作品不存在")
        conditions.append(KeywordCollectionComment.content_id == content_id)
    text_query = (q or "").strip()[:200]
    region_query = (ip_label or "").strip()[:64]
    sec_uid_query = (user_sec_uid or "").strip()[:128]
    if text_query:
        conditions.append(KeywordCollectionComment.text.contains(text_query))
    if region_query:
        conditions.append(KeywordCollectionComment.ip_label.contains(region_query))
    if sec_uid_query:
        conditions.append(KeywordCollectionComment.user_sec_uid.contains(sec_uid_query))
    if dedupe_users:
        conditions.append(func.coalesce(KeywordCollectionComment.user_sec_uid, "") != "")
        ranked = select(
            KeywordCollectionComment.id.label("comment_id"),
            func.row_number().over(
                partition_by=KeywordCollectionComment.user_sec_uid,
                order_by=(KeywordCollectionComment.create_time.desc(),
                          KeywordCollectionComment.id.desc()),
            ).label("user_rank"),
        ).where(*conditions).subquery()
        statement = (select(KeywordCollectionComment)
                     .join(ranked, KeywordCollectionComment.id == ranked.c.comment_id)
                     .where(ranked.c.user_rank == 1))
    else:
        statement = select(KeywordCollectionComment).where(*conditions)
    return job, statement


def _collection_comment_payloads(session, rows):
    content_ids = {row.content_id for row in rows if row.content_id is not None}
    content_map = {}
    if content_ids:
        content_map = {
            row.id: row for row in session.exec(
                select(KeywordCollectionContent)
                .where(KeywordCollectionContent.id.in_(content_ids))
            ).all()
        }
    return [_collection_comment_dict(row, content_map.get(row.content_id)) for row in rows]


@app.get("/api/accounts/{account_id}/xhs/favorite-boards")
async def list_xhs_favorite_boards(account_id: int):
    """List the signed-in account's XHS favorite boards without exposing cookies."""
    if browser is None or engine is None:
        raise HTTPException(503, "采集引擎未就绪")
    with get_session() as session:
        account = session.get(DouyinAccount, account_id)
        if (not account or account.platform != "xhs" or account.status != "active"
                or not account.storage_state):
            raise HTTPException(400, "请选择有效的小红书登录账号")
        identity = browser.identity_for(account)
        user_id = account.sec_uid
        cookie = cookie_str_from_state(account.storage_state)
        proxy = account.proxy or ""

    async def read_boards():
        if (cfg.engine.xhs_read_mode == "browser"
                and callable(getattr(browser, "visible_page", None))):
            return await fetch_xhs_favorite_boards(browser, identity, user_id)
        if not has_a1(cookie):
            return [], "小红书登录态缺少 a1，请重新扫码登录"
        client = XhsApiClient(
            cookie, (browser.direct_request_user_agent(identity)
                     if callable(getattr(browser, "direct_request_user_agent", None))
                     else identity.ua),
            timeout=cfg.engine.request_timeout_seconds, proxy=proxy)
        async with client.session_scope():
            return await client.favorite_boards(user_id), ""

    boards, error = await engine.guarded_interactive_read_pair(
        account_id, OperationKind.READ_HEAVY,
        f"favorite-boards:{account_id}", read_boards, empty_result=[])
    if error.startswith("risk_deferred:"):
        raise HTTPException(429, error.split(":", 1)[-1])
    if error and not boards:
        raise HTTPException(400, error)
    return [{
        "id": str(value.get("id") or value.get("board_id") or ""),
        "name": str(value.get("name") or value.get("title") or "未命名收藏夹"),
        "total": int(value.get("total") or value.get("note_count") or 0),
        "images": value.get("images") or [],
    } for value in boards if value.get("id") or value.get("board_id")]


@app.post("/api/collections")
async def create_keyword_collection(body: KeywordCollectionIn, request: Request = None):
    with get_session() as session:
        def create():
            platform, keywords, quality, download_dir, options = _validated_collection_input(body)
            account = session.get(DouyinAccount, body.account_id)
            if (not account or account.platform != platform
                    or account.status != "active" or not account.storage_state):
                raise HTTPException(400, "所选账号不存在、登录态失效或与平台不匹配")
            job = KeywordCollectionJob(
                platform=platform, account_id=body.account_id,
                keywords=json.dumps(keywords, ensure_ascii=False),
                max_contents_per_keyword=body.max_contents_per_keyword,
                **options,
                max_comments_per_content=body.max_comments_per_content,
                include_replies=body.include_replies,
                download_media=body.download_media,
                video_quality=quality, download_dir=download_dir,
            )
            session.add(job); session.flush()
            return _collection_job_dict(job)
        payload, created = submit_once(session, request=request, scope="collection", body=body, create=create)
    if engine and created:
        engine.enqueue_collection_job(payload["id"])
        record_account_operation(
            platform=payload["platform"], account_id=payload["account_id"],
            task_type="collection", task_id=payload["id"], action="queued",
            status="pending", target=payload.get("source_name") or
            "、".join(payload.get("keywords") or []), channel="queue")
    return payload


@app.put("/api/collections/{job_id}")
async def update_keyword_collection(job_id: int, body: KeywordCollectionIn):
    """修改已结束任务的配置；历史作品/评论保留，续跑时按任务去重。"""
    platform, keywords, quality, download_dir, options = _validated_collection_input(body)
    with get_session() as session:
        job = session.get(KeywordCollectionJob, job_id)
        if not job:
            raise HTTPException(404, "采集任务不存在")
        if platform != job.platform:
            raise HTTPException(400, "采集任务创建后不能变更平台")
        if job.status in {"pending", "running"}:
            raise HTTPException(409, "等待或执行中的任务请先取消，再编辑配置")
        account = session.get(DouyinAccount, body.account_id)
        if (not account or account.platform != platform
                or account.status != "active" or not account.storage_state):
            raise HTTPException(400, "所选账号不存在、登录态失效或与平台不匹配")

        job.account_id = body.account_id
        job.keywords = json.dumps(keywords, ensure_ascii=False)
        job.max_contents_per_keyword = body.max_contents_per_keyword
        for field, value in options.items():
            setattr(job, field, value)
        job.max_comments_per_content = body.max_comments_per_content
        job.include_replies = body.include_replies
        job.download_media = body.download_media
        job.video_quality = quality
        job.download_dir = download_dir
        job.current_keyword = ""
        job.current_step = "配置已更新，可点击续跑"
        job.processed_keyword_count = 0
        job.current_item_index = 0
        job.current_item_total = 0
        job.cancel_requested = False
        session.add(job); session.commit(); session.refresh(job)
        payload = _collection_job_dict(job)
    record_account_operation(
        platform=payload["platform"], account_id=payload["account_id"],
        task_type="collection", task_id=payload["id"], action="configured",
        status=payload["status"], target=payload.get("source_name") or
        "、".join(payload.get("keywords") or []), channel="api")
    return payload


@app.get("/api/collections")
async def list_keyword_collections(platform: str | None = None, limit: int = 100):
    limit = max(1, min(limit, 300))
    with get_session() as session:
        stmt = select(KeywordCollectionJob)
        if platform in {"douyin", "xhs"}:
            stmt = stmt.where(KeywordCollectionJob.platform == platform)
        rows = session.exec(
            stmt.order_by(KeywordCollectionJob.created_at.desc()).limit(limit)).all()
        return [_collection_job_dict(row) for row in rows]


@app.get("/api/collections/{job_id}")
async def get_keyword_collection(job_id: int):
    with get_session() as session:
        job = session.get(KeywordCollectionJob, job_id)
        if not job:
            raise HTTPException(404, "采集任务不存在")
        return _collection_job_dict(job)


@app.get("/api/collections/{job_id}/contents")
async def list_keyword_collection_contents(job_id: int, keyword: str = "",
                                           page: int = 1, page_size: int = 20):
    page = max(1, page)
    page_size = max(1, min(page_size, 100))
    with get_session() as session:
        if not session.get(KeywordCollectionJob, job_id):
            raise HTTPException(404, "采集任务不存在")
        filters = [KeywordCollectionContent.job_id == job_id]
        if keyword:
            filters.append(KeywordCollectionContent.keyword == keyword)
        count_stmt = select(func.count(KeywordCollectionContent.id)).where(*filters)
        total = int(session.exec(count_stmt).one() or 0)
        rows = session.exec(
            select(KeywordCollectionContent).where(*filters)
            .order_by(KeywordCollectionContent.created_at.desc())
            .offset((page - 1) * page_size).limit(page_size)
        ).all()
        return {
            "items": [_collection_content_dict(row) for row in rows],
            "page": page, "page_size": page_size, "total": total,
            "pages": max(1, (total + page_size - 1) // page_size),
        }


def _get_collection_content(session, job_id: int,
                            content_id: int) -> KeywordCollectionContent:
    row = session.get(KeywordCollectionContent, content_id)
    if not row or row.job_id != job_id:
        raise HTTPException(404, "采集作品不存在")
    return row


@app.get("/api/collections/{job_id}/contents/{content_id}/media")
async def keyword_collection_content_media(job_id: int, content_id: int):
    """Return local-first media URLs for the collection result preview."""
    with get_session() as session:
        row = _get_collection_content(session, job_id, content_id)
        local_paths = _collection_local_media_paths(row)
        remote_medias = _collection_remote_medias(row)
        local_medias = [{
            "kind": "image" if path.suffix.lower() in _COLLECTION_IMAGE_EXTS else "video",
            "url": f"/api/collections/{job_id}/contents/{content_id}/local-media/{index}",
        } for index, path in enumerate(local_paths)]
        local_video = next(
            (item for item in local_medias if item["kind"] == "video"), None)
        has_local_images = any(item["kind"] == "image" for item in local_medias)
        medias = local_medias if has_local_images else remote_medias
        return {
            "id": row.id, "platform": row.platform, "desc": row.desc,
            "media_type": row.media_type, "cover_url": row.cover_url,
            "local_path": row.local_path, "medias": medias,
            "local_url": local_video["url"] if local_video else "",
            "source_url": (f"https://www.xiaohongshu.com/explore/{row.aweme_id}"
                           if row.platform == "xhs"
                           else f"https://www.douyin.com/video/{row.aweme_id}"),
        }


@app.api_route(
    "/api/collections/{job_id}/contents/{content_id}/local-media/{media_index}",
    methods=["GET", "HEAD"],
)
async def keyword_collection_local_media(job_id: int, content_id: int,
                                         media_index: int):
    """Stream a downloaded collection media file for inline browser preview."""
    with get_session() as session:
        row = _get_collection_content(session, job_id, content_id)
        paths = _collection_local_media_paths(row)
    if media_index < 0 or media_index >= len(paths):
        raise HTTPException(404, "本地媒体不存在")
    path = paths[media_index]
    return FileResponse(
        path,
        filename=path.name,
        content_disposition_type="inline",
        headers={"Cache-Control": "private, no-cache"},
    )


@app.post("/api/collections/{job_id}/contents/{content_id}/reveal")
async def reveal_keyword_collection_content(job_id: int, content_id: int,
                                            request: Request):
    """Reveal a downloaded collection file (or its gallery directory)."""
    _require_local_action(request)
    with get_session() as session:
        row = _get_collection_content(session, job_id, content_id)
        path = _collection_local_path(row)
    if not path:
        raise HTTPException(404, "本地文件不存在")
    try:
        await asyncio.to_thread(_reveal_in_file_manager, path)
    except OSError as exc:
        raise HTTPException(500, f"打开文件夹失败：{exc}") from exc
    return {"ok": True}


@app.post("/api/collections/{job_id}/contents/{content_id}/open")
async def open_keyword_collection_content(job_id: int, content_id: int,
                                          request: Request):
    """Open the downloaded media in the operating system's default application."""
    _require_local_action(request, "open")
    with get_session() as session:
        row = _get_collection_content(session, job_id, content_id)
        media_paths = _collection_local_media_paths(row)
        path = media_paths[0] if media_paths else _collection_local_path(row)
    if not path:
        raise HTTPException(404, "本地文件不存在")
    try:
        await asyncio.to_thread(_open_local_path, path)
    except OSError as exc:
        raise HTTPException(500, f"打开文件失败：{exc}") from exc
    return {"ok": True}


@app.get("/api/collections/{job_id}/comments")
async def list_keyword_collection_comments(job_id: int, content_id: int | None = None,
                                           q: str = "", ip_label: str = "",
                                           user_sec_uid: str = "",
                                           dedupe_users: bool = False,
                                           paginate: bool = False, page: int = 1,
                                           page_size: int = 50, limit: int = 300):
    limit = max(1, min(limit, 1000))
    page = max(1, page)
    page_size = max(1, min(page_size, 200))
    with get_session() as session:
        job, statement = _collection_comment_query(
            session, job_id, content_id=content_id, q=q, ip_label=ip_label,
            user_sec_uid=user_sec_uid, dedupe_users=dedupe_users)
        ordering = (KeywordCollectionComment.create_time.desc(),
                    KeywordCollectionComment.id.desc())
        if not paginate:
            rows = session.exec(statement.order_by(*ordering).limit(limit)).all()
            return _collection_comment_payloads(session, rows)
        total = int(session.exec(
            select(func.count()).select_from(statement.subquery())
        ).one())
        pages = max(1, (total + page_size - 1) // page_size)
        rows = session.exec(
            statement.order_by(*ordering)
            .offset((page - 1) * page_size)
            .limit(page_size)
        ).all()
        return {
            "items": _collection_comment_payloads(session, rows),
            "total": total, "page": page, "page_size": page_size,
            "pages": pages, "has_prev": page > 1, "has_next": page < pages,
            "job_id": job_id, "content_id": content_id,
        }


@app.post("/api/collections/{job_id}/cancel")
async def cancel_keyword_collection(job_id: int):
    with get_session() as session:
        job = session.get(KeywordCollectionJob, job_id)
        if not job:
            raise HTTPException(404, "采集任务不存在")
        if job.status in {"done", "partial", "failed", "canceled"}:
            return _collection_job_dict(job)
        job.cancel_requested = True
        if job.status == "pending":
            job.status = "canceled"
            job.current_step = "已取消"
            job.finished_at = datetime.utcnow()
        else:
            job.current_step = "正在安全停止"
        session.add(job); session.commit(); session.refresh(job)
        payload = _collection_job_dict(job)
    record_account_operation(
        platform=payload["platform"], account_id=payload["account_id"],
        task_type="collection", task_id=payload["id"], action="cancel_requested",
        status=payload["status"], target=payload.get("source_name") or
        "、".join(payload.get("keywords") or []), channel="api")
    return payload


@app.post("/api/collections/{job_id}/retry")
async def retry_keyword_collection(job_id: int):
    with get_session() as session:
        job = session.get(KeywordCollectionJob, job_id)
        if not job:
            raise HTTPException(404, "采集任务不存在")
        if job.status in {"pending", "running"}:
            raise HTTPException(409, "任务仍在等待或执行中")
        job.status = "pending"
        job.current_keyword = ""
        job.current_step = "等待继续"
        job.processed_keyword_count = 0
        job.current_item_index = 0
        job.current_item_total = 0
        job.error_count = 0
        job.error = ""
        job.cancel_requested = False
        job.started_at = None
        job.finished_at = None
        session.add(job); session.commit(); session.refresh(job)
        payload = _collection_job_dict(job)
    if engine:
        engine.enqueue_collection_job(job_id)
    record_account_operation(
        platform=payload["platform"], account_id=payload["account_id"],
        task_type="collection", task_id=payload["id"], action="requeued",
        status="pending", target=payload.get("source_name") or
        "、".join(payload.get("keywords") or []), channel="queue")
    return payload


@app.delete("/api/collections/{job_id}")
async def delete_keyword_collection(job_id: int):
    with get_session() as session:
        job = session.get(KeywordCollectionJob, job_id)
        if not job:
            return {"ok": True, "deleted": 0}
        if job.status == "running":
            raise HTTPException(409, "请先取消正在执行的任务")
        for row in session.exec(
                select(KeywordCollectionComment)
                .where(KeywordCollectionComment.job_id == job_id)).all():
            session.delete(row)
        for row in session.exec(
                select(KeywordCollectionContent)
                .where(KeywordCollectionContent.job_id == job_id)).all():
            session.delete(row)
        session.delete(job); session.commit()
    return {"ok": True, "deleted": 1}


@app.get("/api/collections/{job_id}/export.xlsx")
async def export_keyword_collection(job_id: int, content_id: int | None = None,
                                    q: str = "", ip_label: str = "",
                                    user_sec_uid: str = "",
                                    dedupe_users: bool = False):
    with get_session() as session:
        job, statement = _collection_comment_query(
            session, job_id, content_id=content_id, q=q, ip_label=ip_label,
            user_sec_uid=user_sec_uid, dedupe_users=dedupe_users)
        comments = session.exec(statement.order_by(
            KeywordCollectionComment.aweme_id,
            KeywordCollectionComment.create_time.desc(),
            KeywordCollectionComment.id.desc())).all()
        filters = [("评论范围", "当前作品" if content_id is not None else "全部作品")]
        if (q or "").strip():
            filters.append(("评论关键词", (q or "").strip()))
        if (ip_label or "").strip():
            filters.append(("地区", (ip_label or "").strip()))
        if (user_sec_uid or "").strip():
            filters.append(("用户 sec_uid", (user_sec_uid or "").strip()))
        if dedupe_users:
            filters.append(("用户去重", "按 sec_uid 保留最新评论"))
        all_filtered_statement = _collection_comment_query(
            session, job_id, content_id=content_id, q=q, ip_label=ip_label,
            user_sec_uid=user_sec_uid, dedupe_users=False)[1]
        lead_comments = session.exec(all_filtered_statement.order_by(
            KeywordCollectionComment.create_time.desc(),
            KeywordCollectionComment.id.desc())).all()
        has_filters = bool((q or "").strip() or (ip_label or "").strip()
                           or (user_sec_uid or "").strip()
                           or content_id is not None or dedupe_users)
        if has_filters:
            referenced_ids = {row.content_id for row in lead_comments}
            if referenced_ids:
                contents = session.exec(
                    select(KeywordCollectionContent)
                    .where(KeywordCollectionContent.job_id == job_id)
                    .where(KeywordCollectionContent.id.in_(referenced_ids))
                    .order_by(KeywordCollectionContent.keyword,
                              KeywordCollectionContent.create_time.desc())
                ).all()
            else:
                contents = []
        else:
            contents = session.exec(
                select(KeywordCollectionContent)
                .where(KeywordCollectionContent.job_id == job_id)
                .order_by(KeywordCollectionContent.keyword,
                          KeywordCollectionContent.create_time.desc())).all()
        from .reporting import build_keyword_collection_report
        payload = build_keyword_collection_report(
            job, contents, comments, filters=filters,
            lead_comments=lead_comments)
    return _report_download(payload, f"keyword-collection-{job_id}")


class TargetIn(BaseModel):
    url_or_secuid: str                       # 抖音/小红书主页链接 或 小红书关键词
    platform: str = "douyin"                # douyin | xhs
    target_kind: str = "creator"            # creator | keyword(仅小红书)
    account_id: int | None = None
    interval_seconds: int = 300
    initial_backfill_count: int | None = None
    download_dir: str = ""
    video_quality: str = ""
    download_enabled: bool = True
    media_filter: str = "all"
    max_scrolls: int = 0
    max_items_per_scan: int = 0
    record_media_filter: str = "all"
    min_like_count: int = 0
    min_comment_count: int = 0
    recent_days: int = 0
    include_keywords: list[str] = PydanticField(default_factory=list)
    exclude_keywords: list[str] = PydanticField(default_factory=list)
    alias: str = ""
    group_name: str = ""
    tags: list[str] = PydanticField(default_factory=list)


class TargetUpdate(BaseModel):
    download_dir: str | None = None
    interval_seconds: int | None = None
    initial_backfill_count: int | None = None
    video_quality: str | None = None
    download_enabled: bool | None = None
    media_filter: str | None = None
    max_scrolls: int | None = None
    max_items_per_scan: int | None = None
    record_media_filter: str | None = None
    min_like_count: int | None = None
    min_comment_count: int | None = None
    recent_days: int | None = None
    include_keywords: list[str] | None = None
    exclude_keywords: list[str] | None = None
    account_id: int | None = None
    alias: str | None = None
    group_name: str | None = None
    tags: list[str] | None = None


def _validate_monitor_strategy(*, max_scrolls: int | None,
                               max_items_per_scan: int | None,
                               record_media_filter: str | None,
                               min_like_count: int | None,
                               min_comment_count: int | None,
                               recent_days: int | None) -> None:
    if max_scrolls is not None and not 0 <= max_scrolls <= 30:
        raise HTTPException(400, "抓取深度须为 0~30；0 表示使用平台默认值")
    if max_items_per_scan is not None and not 0 <= max_items_per_scan <= 100:
        raise HTTPException(400, "每轮作品上限须为 0~100；0 表示使用平台默认值")
    if record_media_filter is not None and record_media_filter not in (
            "all", "video", "images"):
        raise HTTPException(400, "作品类型筛选须为 all、video 或 images")
    if min_like_count is not None and not 0 <= min_like_count <= 1_000_000_000:
        raise HTTPException(400, "最低点赞数须为 0~1000000000")
    if min_comment_count is not None and not 0 <= min_comment_count <= 1_000_000_000:
        raise HTTPException(400, "最低评论数须为 0~1000000000")
    if recent_days is not None and not 0 <= recent_days <= 3650:
        raise HTTPException(400, "发布时间范围须为 0~3650 天；0 表示不限")


def _clean_platform_target_input(value: str, platform: str) -> str:
    """复用分享链接下载的清洗器，返回当前平台的第一条有效链接或原始 ID。"""
    target_input, detected_links = clean_platform_share_target(value, platform)
    if detected_links and not any(
            item.platform == platform for item in detected_links):
        platform_name = {
            "douyin": "抖音", "xhs": "小红书", "kuaishou": "快手",
        }.get(platform, platform)
        detected_names = {
            "douyin": "抖音", "xhs": "小红书", "kuaishou": "快手",
            "generic": "其他站点",
        }
        names = "、".join(dict.fromkeys(
            detected_names.get(item.platform, item.platform)
            for item in detected_links
        ))
        raise HTTPException(
            400,
            f"分享文案中识别到{names}链接，但当前页面是{platform_name}；"
            f"请粘贴{platform_name}链接或完整分享文案",
        )
    return target_input


def _ensure_creator_monitor_available(session, *, platform: str, sec_uid: str,
                                     account_id: int | None,
                                     exclude_id: int | None = None) -> None:
    """主页监控按执行账号去重；暂停的任务仍占用该账号的目标。"""
    query = select(MonitorTarget).where(
        MonitorTarget.platform == platform, MonitorTarget.sec_uid == sec_uid)
    if account_id:
        query = query.where(MonitorTarget.account_id == account_id)
    else:
        # 兼容历史数据中的 0：与 None 都表示匿名执行。
        query = query.where(or_(MonitorTarget.account_id.is_(None),
                                MonitorTarget.account_id == 0))
    if exclude_id is not None:
        query = query.where(MonitorTarget.id != exclude_id)
    if session.exec(query).first():
        detail = "该账号已存在此主页的监控" if account_id else "该主页的匿名监控已存在"
        raise HTTPException(409, detail)


@app.post("/api/monitors")
async def add_monitor(body: TargetIn):
    platform = body.platform if body.platform in ("douyin", "xhs", "kuaishou") else "douyin"
    sec_uid = keyword = xsec_token = ""
    kind = "creator"

    if platform == "xhs" and body.target_kind == "keyword":
        kind = "keyword"
        keyword = body.url_or_secuid.strip()
        if not keyword:
            raise HTTPException(400, "请输入要监控的搜索关键词")
    else:
        target_input = _clean_platform_target_input(body.url_or_secuid, platform)

    if platform == "xhs" and kind != "keyword":
        ref = await xhs_resolve_user(target_input, cfg.engine.user_agent)
        if not ref:
            raise HTTPException(400, "无法解析小红书 user_id,请粘贴完整分享文案、创作者主页链接 / xhslink 短链 / 24 位 user_id")
        sec_uid, xsec_token = ref.user_id, ref.xsec_token
    elif platform == "kuaishou":
        sec_uid = await resolve_ks_user_id(target_input, cfg.engine.user_agent)
        if not sec_uid:
            raise HTTPException(400, "无法解析快手 user_id,请粘贴完整分享文案、创作者主页链接 / v.kuaishou.com 短链 / user_id")
    elif platform == "douyin":
        sec_uid = await resolve_sec_uid(target_input, cfg.engine.user_agent)
        if not sec_uid:
            raise HTTPException(400, "无法解析 sec_uid,请粘贴完整分享文案、主页链接 / v.douyin.com 短链 / sec_uid")

    dl = body.download_dir.strip()
    if not 1 <= body.interval_seconds <= 86400:
        raise HTTPException(400, "监控间隔须为 1~86400 秒")
    if body.media_filter not in ("all", "video", "images"):
        raise HTTPException(400, "媒体筛选须为 all、video 或 images")
    _validate_monitor_strategy(
        max_scrolls=body.max_scrolls,
        max_items_per_scan=body.max_items_per_scan,
        record_media_filter=body.record_media_filter,
        min_like_count=body.min_like_count,
        min_comment_count=body.min_comment_count,
        recent_days=body.recent_days)
    if dl:
        try:
            Path(dl).expanduser().mkdir(parents=True, exist_ok=True)
        except Exception as e:
            raise HTTPException(400, f"下载目录不可用: {e}")
    with get_session() as s:
        if platform == "douyin":
            if not body.account_id:
                raise HTTPException(
                    400, "抖音作品监控必须选择已登录账号,匿名抓取可能返回陈旧或残缺作品")
            monitor_acc = s.get(DouyinAccount, body.account_id)
            if (not monitor_acc or monitor_acc.platform != "douyin"
                    or monitor_acc.status != "active"):
                raise HTTPException(400, "所选抖音账号不存在或登录态已失效")
        elif body.account_id:
            monitor_acc = s.get(DouyinAccount, body.account_id)
            if not monitor_acc or monitor_acc.platform != platform:
                raise HTTPException(400, "所选账号不存在或与监控平台不匹配")
        if kind == "keyword":
            dup = s.exec(select(MonitorTarget).where(MonitorTarget.platform == platform)
                         .where(MonitorTarget.keyword == keyword)).first()
            if dup:
                raise HTTPException(409, "该监控目标已存在")
        else:
            _ensure_creator_monitor_available(
                s, platform=platform, sec_uid=sec_uid, account_id=body.account_id)
        q = body.video_quality.strip()
        if q and q not in QUALITY_CHOICES:
            raise HTTPException(400, f"画质取值无效: {q}")
        backfill_count = (cfg.engine.monitor_initial_backfill_count
                          if body.initial_backfill_count is None
                          else body.initial_backfill_count)
        if backfill_count < -1 or backfill_count > 1000:
            raise HTTPException(400, "首次回填数须为 -1(尽可能全量)或 0~1000")
        t = MonitorTarget(platform=platform, target_kind=kind, keyword=keyword,
                          sec_uid=sec_uid, xsec_token=xsec_token,
                          nickname=("#" + keyword) if kind == "keyword" else "",
                          alias=_meta_text(body.alias, 60),
                          group_name=_meta_text(body.group_name, 40),
                          tags=_dump_meta_tags(_meta_tags(body.tags)),
                          account_id=body.account_id or None,
                          interval_seconds=body.interval_seconds, download_dir=dl,
                          initial_backfill_count=backfill_count, video_quality=q,
                          download_enabled=body.download_enabled,
                          media_filter=body.media_filter,
                          max_scrolls=body.max_scrolls,
                          max_items_per_scan=body.max_items_per_scan,
                          record_media_filter=body.record_media_filter,
                          min_like_count=body.min_like_count,
                          min_comment_count=body.min_comment_count,
                          recent_days=body.recent_days,
                          include_keywords=_dump_meta_tags(
                              _meta_tags(body.include_keywords)),
                          exclude_keywords=_dump_meta_tags(
                              _meta_tags(body.exclude_keywords)))
        s.add(t); s.commit(); s.refresh(t)
        return _target_dict(t)


@app.put("/api/monitors/{tid}")
async def update_monitor(tid: int, body: TargetUpdate):
    with get_session() as s:
        t = s.get(MonitorTarget, tid)
        if not t:
            raise HTTPException(404)
        if body.download_dir is not None:
            dl = body.download_dir.strip()
            if dl:
                try:
                    Path(dl).expanduser().mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    raise HTTPException(400, f"下载目录不可用: {e}")
            t.download_dir = dl
        if body.interval_seconds is not None:
            if not 1 <= body.interval_seconds <= 86400:
                raise HTTPException(400, "监控间隔须为 1~86400 秒")
            t.interval_seconds = body.interval_seconds
        if body.initial_backfill_count is not None:
            if t.last_scan_at is not None:
                raise HTTPException(400, "首次历史回填仅能在第一次扫描前修改")
            if body.initial_backfill_count < -1 or body.initial_backfill_count > 1000:
                raise HTTPException(400, "首次回填数须为 -1 或 0~1000")
            t.initial_backfill_count = body.initial_backfill_count
        if body.video_quality is not None:
            q = body.video_quality.strip()
            if q and q not in QUALITY_CHOICES:
                raise HTTPException(400, f"画质取值无效: {q}")
            t.video_quality = q
        if body.download_enabled is not None:
            t.download_enabled = body.download_enabled
        if body.media_filter is not None:
            if body.media_filter not in ("all", "video", "images"):
                raise HTTPException(400, "媒体筛选须为 all、video 或 images")
            t.media_filter = body.media_filter
        _validate_monitor_strategy(
            max_scrolls=body.max_scrolls,
            max_items_per_scan=body.max_items_per_scan,
            record_media_filter=body.record_media_filter,
            min_like_count=body.min_like_count,
            min_comment_count=body.min_comment_count,
            recent_days=body.recent_days)
        if body.max_scrolls is not None:
            t.max_scrolls = body.max_scrolls
        if body.max_items_per_scan is not None:
            t.max_items_per_scan = body.max_items_per_scan
        if body.record_media_filter is not None:
            t.record_media_filter = body.record_media_filter
        if body.min_like_count is not None:
            t.min_like_count = body.min_like_count
        if body.min_comment_count is not None:
            t.min_comment_count = body.min_comment_count
        if body.recent_days is not None:
            t.recent_days = body.recent_days
        if body.include_keywords is not None:
            t.include_keywords = _dump_meta_tags(_meta_tags(body.include_keywords))
        if body.exclude_keywords is not None:
            t.exclude_keywords = _dump_meta_tags(_meta_tags(body.exclude_keywords))
        if body.account_id is not None:
            acc = s.get(DouyinAccount, body.account_id)
            if not acc or acc.platform != t.platform or acc.status != "active":
                raise HTTPException(400, "账号不存在、登录态失效或与监控平台不匹配")
            if t.target_kind != "keyword":
                _ensure_creator_monitor_available(
                    s, platform=t.platform, sec_uid=t.sec_uid,
                    account_id=body.account_id, exclude_id=t.id)
            t.account_id = body.account_id
        if body.alias is not None:
            t.alias = _meta_text(body.alias, 60)
        if body.group_name is not None:
            t.group_name = _meta_text(body.group_name, 40)
        if body.tags is not None:
            t.tags = _dump_meta_tags(_meta_tags(body.tags))
        s.add(t); s.commit(); s.refresh(t)
        return _target_dict(t)


@app.get("/api/monitors")
async def list_monitors(platform: str | None = None):
    with get_session() as s:
        q = select(MonitorTarget)
        if platform:
            q = q.where(MonitorTarget.platform == platform)
        ts = s.exec(q).all()
        counts = dict(s.exec(select(ContentRecord.target_id, func.count(ContentRecord.id))
                             .where(ContentRecord.target_id.in_([t.id for t in ts]))
                             .group_by(ContentRecord.target_id)).all()) if ts else {}
        out = []
        for t in ts:
            d = _target_dict(t)
            d["content_count"] = counts.get(t.id, 0)
            out.append(d)
        return out


@app.post("/api/monitors/{tid}/toggle")
async def toggle_monitor(tid: int):
    with get_session() as s:
        t = s.get(MonitorTarget, tid)
        if not t:
            raise HTTPException(404)
        t.enabled = not t.enabled
        s.add(t); s.commit()
        return {"enabled": t.enabled}


@app.post("/api/monitors/{tid}/run-now")
async def run_now(tid: int):
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    return await engine.scan_target(tid)


@app.delete("/api/monitors/{tid}")
async def del_monitor(tid: int):
    with get_session() as s:
        t = s.get(MonitorTarget, tid)
        if t:
            s.delete(t); s.commit()
    return {"ok": True}


@app.get("/api/monitors/{tid}/contents")
async def target_contents(tid: int):
    with get_session() as s:
        rows = s.exec(select(ContentRecord)
                      .where(ContentRecord.target_id == tid)
                      .order_by(ContentRecord.create_time.desc())).all()
        return _content_records(s, rows)


def _content_capture_bounds(start: datetime | None, end: datetime | None):
    def utc(value):
        return value.astimezone(timezone.utc).replace(tzinfo=None) if value and value.tzinfo else value
    start, end = utc(start), utc(end)
    if start and end and start >= end:
        raise HTTPException(400, "抓取时间范围需满足开始早于结束")
    return start, end


def _content_ordering(sort: str):
    if sort == "captured_desc":
        return ContentRecord.created_at.desc(), ContentRecord.id.desc()
    if sort == "captured_asc":
        return ContentRecord.created_at.asc(), ContentRecord.id.asc()
    if sort == "create_asc":
        return ContentRecord.create_time.asc(), ContentRecord.id.asc()
    if sort == "likes_desc":
        return ContentRecord.like_count.desc(), ContentRecord.id.desc()
    if sort == "comments_desc":
        return ContentRecord.comment_count.desc(), ContentRecord.id.desc()
    return ContentRecord.create_time.desc(), ContentRecord.id.desc()


@app.get("/api/contents")
async def all_contents(limit: int = 100, platform: str | None = None,
                       target_id: int | None = None, group_name: str = "",
                       tag: str = "", q: str = "", media_type: str = "",
                       download_status: str = "", min_like_count: int = 0,
                       min_comment_count: int = 0, sort: str = "create_desc",
                       page: int = 1, page_size: int = 10,
                       paginate: bool = False,
                       captured_from: datetime | None = None,
                       captured_before: datetime | None = None):
    """Return monitored works, optionally as a filtered paginated result.

    The legacy list response remains the default for older callers.  The web
    UI opts into the object response with ``paginate=true`` so it can show a
    stable total while filters are applied in SQL rather than in the browser.
    """
    limit = max(1, min(limit, 1000))
    page = max(1, page)
    page_size = max(1, min(page_size, 200))
    start, end = _content_capture_bounds(captured_from, captured_before)
    with get_session() as s:
        selected_target = s.get(MonitorTarget, target_id) if target_id is not None else None
        selected_source = (_content_source(target_id, platform or (selected_target.platform if selected_target else ""), selected_target)
                           if target_id is not None else None)
        stmt = select(ContentRecord)
        if platform:
            stmt = stmt.where(ContentRecord.platform == platform)
        if target_id is not None:
            stmt = stmt.where(ContentRecord.target_id == target_id)
        stmt = _report_window(stmt, ContentRecord, start, end)
        text_query = q.strip()
        if text_query:
            stmt = stmt.where(or_(ContentRecord.desc.contains(text_query),
                                  ContentRecord.aweme_id.contains(text_query)))
        if media_type in ("video", "images"):
            stmt = stmt.where(ContentRecord.media_type == media_type)
        if download_status:
            stmt = stmt.where(ContentRecord.download_status == download_status)
        if min_like_count > 0:
            stmt = stmt.where(ContentRecord.like_count >= min_like_count)
        if min_comment_count > 0:
            stmt = stmt.where(ContentRecord.comment_count >= min_comment_count)
        group_name, tag = _meta_text(group_name, 40), _meta_text(tag, 24)
        if group_name or tag:
            target_query = select(MonitorTarget)
            if platform:
                target_query = target_query.where(MonitorTarget.platform == platform)
            targets = s.exec(target_query).all()
            eligible_ids = [t.id for t in targets if t.id is not None
                            and _meta_matches(t, group_name, tag)]
            if not eligible_ids:
                if not paginate:
                    return []
                return {"items": [], "total": 0, "page": page,
                        "page_size": page_size, "pages": 1,
                        "has_prev": page > 1, "has_next": False, "source": selected_source}
            stmt = stmt.where(ContentRecord.target_id.in_(eligible_ids))

        ordering = _content_ordering(sort)
        if not paginate:
            rows = s.exec(stmt.order_by(*ordering).limit(limit)).all()
            return _content_records(s, rows)

        total = int(s.exec(select(func.count()).select_from(stmt.subquery())).one())
        pages = max(1, (total + page_size - 1) // page_size)
        rows = s.exec(stmt.order_by(*ordering)
                      .offset((page - 1) * page_size)
                      .limit(page_size)).all()
        return {
            "items": _content_records(s, rows),
            "source": selected_source,
            "total": total, "page": page, "page_size": page_size,
            "pages": pages, "has_prev": page > 1, "has_next": page < pages,
        }


@app.get("/api/stats/series")
async def stats_series(platform: str | None = None, days: int = 7):
    """近 N 天每天采集到的新作品 / 新评论计数(按入库时间 created_at 分桶),供总览图表用。"""
    from datetime import timedelta
    days = max(1, min(days, 31))
    today = datetime.utcnow().date()
    labels = [(today - timedelta(days=days - 1 - i)).isoformat() for i in range(days)]
    index = {d: i for i, d in enumerate(labels)}

    def bucket(model) -> list[int]:
        counts = [0] * days
        with get_session() as s:
            q = select(model.created_at)
            if platform:
                q = q.where(model.platform == platform)
            for ts in s.exec(q).all():
                if not ts:
                    continue
                key = (ts.date().isoformat() if hasattr(ts, "date") else str(ts)[:10])
                i = index.get(key)
                if i is not None:
                    counts[i] += 1
        return counts

    return {"days": labels, "contents": bucket(ContentRecord),
            "comments": bucket(CommentRecord)}


@app.get("/api/reports/monitor.xlsx")
async def export_monitor_report(
    platform: str | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
    group_name: str = "",
    tag: str = "",
    data_types: str = "all",
):
    """Export filtered monitoring records as a formatted Excel workbook.

    ``start_date`` and ``end_date`` filter by record collection time.  The
    workbook also keeps each platform timestamp as a separate detail column.
    """
    if start_date and end_date and start_date > end_date:
        raise HTTPException(400, "开始日期不能晚于结束日期")

    requested = {
        item.strip().lower()
        for item in (data_types or "all").split(",")
        if item.strip()
    }
    aliases = {"works": "contents", "content": "contents", "comments": "comments", "comment": "comments", "danmakus": "danmaku"}
    requested = {aliases.get(item, item) for item in requested}
    allowed = {"all", "contents", "comments", "danmaku"}
    if not requested or not requested <= allowed:
        raise HTTPException(400, "data_types 只能是 all、contents、comments、danmaku 的逗号组合")
    include_all = "all" in requested
    include_contents = include_all or "contents" in requested
    include_comments = include_all or "comments" in requested
    include_danmaku = include_all or "danmaku" in requested

    platform = platform.strip() if platform else None
    group_name, tag = _meta_text(group_name, 40), _meta_text(tag, 24)
    window_start = datetime.combine(start_date, time.min) if start_date else None
    # Use an exclusive upper bound so the complete end date is included.
    window_end = (
        datetime.combine(end_date + timedelta(days=1), time.min)
        if end_date else None
    )

    def in_window(statement, model):
        if window_start:
            statement = statement.where(model.created_at >= window_start)
        if window_end:
            statement = statement.where(model.created_at < window_end)
        return statement

    with get_session() as s:
        target_stmt = select(MonitorTarget).order_by(MonitorTarget.id.asc())
        if platform:
            target_stmt = target_stmt.where(MonitorTarget.platform == platform)
        targets = s.exec(target_stmt).all()
        if group_name or tag:
            targets = [t for t in targets if _meta_matches(t, group_name, tag)]
        target_ids = [t.id for t in targets if t.id is not None]

        watch_stmt = select(CommentWatch).order_by(CommentWatch.id.asc())
        danmaku_watch_stmt = select(DanmakuWatch).order_by(DanmakuWatch.id.asc())
        if platform:
            watch_stmt = watch_stmt.where(CommentWatch.platform == platform)
            danmaku_watch_stmt = danmaku_watch_stmt.where(DanmakuWatch.platform == platform)
        watches = s.exec(watch_stmt).all()
        danmaku_watches = s.exec(danmaku_watch_stmt).all()
        if group_name or tag:
            watches = [w for w in watches if _meta_matches(w, group_name, tag)]
            danmaku_watches = [w for w in danmaku_watches if _meta_matches(w, group_name, tag)]
        watch_ids = [w.id for w in watches if w.id is not None]
        danmaku_watch_ids = [w.id for w in danmaku_watches if w.id is not None]

        contents = []
        if include_contents and (not (group_name or tag) or target_ids):
            statement = select(ContentRecord).order_by(
                ContentRecord.created_at.desc(), ContentRecord.id.desc()
            )
            if platform:
                statement = statement.where(ContentRecord.platform == platform)
            if group_name or tag:
                statement = statement.where(ContentRecord.target_id.in_(target_ids))
            statement = in_window(statement, ContentRecord)
            contents = s.exec(statement).all()

        comments = []
        if include_comments and (not (group_name or tag) or watch_ids):
            statement = select(CommentRecord).order_by(
                CommentRecord.created_at.desc(), CommentRecord.id.desc()
            )
            if platform:
                statement = statement.where(CommentRecord.platform == platform)
            if group_name or tag:
                statement = statement.where(CommentRecord.watch_id.in_(watch_ids))
            statement = in_window(statement, CommentRecord)
            comments = s.exec(statement).all()

        danmaku = []
        if include_danmaku and (not (group_name or tag) or danmaku_watch_ids):
            statement = select(DanmakuRecord).order_by(
                DanmakuRecord.created_at.desc(), DanmakuRecord.id.desc()
            )
            if platform:
                statement = statement.where(DanmakuRecord.platform == platform)
            if group_name or tag:
                statement = statement.where(DanmakuRecord.watch_id.in_(danmaku_watch_ids))
            statement = in_window(statement, DanmakuRecord)
            danmaku = s.exec(statement).all()

    from .reporting import REPORT_MIME, build_monitor_report

    payload = build_monitor_report(
        platform=platform or "",
        period_start=start_date,
        period_end=end_date,
        targets=targets,
        contents=contents,
        watches=watches,
        comments=comments,
        danmaku_watches=danmaku_watches,
        danmaku=danmaku,
        generated_at=datetime.now(),
    )
    filename = f"creatorhub_monitor_report_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    return StreamingResponse(
        iter([payload]),
        media_type=REPORT_MIME,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(payload)),
        },
    )


def _report_bounds(
    start_date: date | None,
    end_date: date | None,
) -> tuple[datetime | None, datetime | None]:
    if start_date and end_date and start_date > end_date:
        raise HTTPException(400, "开始日期不能晚于结束日期")
    start = datetime.combine(start_date, time.min) if start_date else None
    end = (
        datetime.combine(end_date + timedelta(days=1), time.min)
        if end_date else None
    )
    return start, end


def _report_window(stmt, model, start: datetime | None, end: datetime | None):
    if start:
        stmt = stmt.where(model.created_at >= start)
    if end:
        stmt = stmt.where(model.created_at < end)
    return stmt


def _report_download(payload: bytes, prefix: str):
    from .reporting import REPORT_MIME

    filename = f"creatorhub_{prefix}_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    return StreamingResponse(
        iter([payload]),
        media_type=REPORT_MIME,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(payload)),
        },
    )


@app.get("/api/reports/share-download-history.xlsx")
async def export_share_download_history_report(
    platform: str | None = None,
    q: str = "",
    media_type: str = "",
    status: str = "",
    full: bool = False,
):
    from .reporting import build_share_history_report

    platform = platform.strip() if platform else None
    q, media_type, status = q.strip(), media_type.strip(), status.strip()
    if full:
        q = media_type = status = ""
    if media_type not in {"", "video", "images"}:
        media_type = ""
    if status not in {"", "done", "failed"}:
        status = ""

    with get_session() as s:
        statement = select(ShareDownloadRecord).order_by(
            ShareDownloadRecord.created_at.desc(), ShareDownloadRecord.id.desc()
        )
        if platform:
            statement = statement.where(ShareDownloadRecord.platform == platform)
        if media_type:
            statement = statement.where(ShareDownloadRecord.media_type == media_type)
        if status:
            statement = statement.where(ShareDownloadRecord.status == status)
        source_rows = s.exec(statement).all()

    needle = q.casefold()
    records = []
    for record in source_rows:
        item = _share_history_dict(record)
        if needle:
            searchable = " ".join(
                str(item.get(key) or "")
                for key in ("title", "desc", "author", "item_id", "source_url", "error")
            ).casefold()
            if needle not in searchable:
                continue
        # _share_history_dict serializes this field for the JSON API; keep the
        # datetime object here so Excel receives a real date cell.
        item["created_at"] = record.created_at
        records.append(item)

    payload = build_share_history_report(
        records,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform),
            ("搜索", q),
            ("媒体类型", media_type),
            ("下载状态", status),
        ]),
    )
    return _report_download(payload, "share_download_history")


def _report_filter_pairs(pairs: list[tuple[str, Any]]) -> list[tuple[str, Any]]:
    return [(label, value if value not in (None, "") else "全部")
            for label, value in pairs]


@app.get("/api/reports/monitors.xlsx")
async def export_monitors_report(
    platform: str | None = None,
    q: str = "",
    group_name: str = "",
    tag: str = "",
    full: bool = False,
):
    from .reporting import build_targets_report

    platform = platform.strip() if platform else None
    q, group_name, tag = q.strip(), _meta_text(group_name, 40), _meta_text(tag, 24)
    if full:
        q = group_name = tag = ""
    with get_session() as s:
        stmt = select(MonitorTarget).order_by(MonitorTarget.id.asc())
        if platform:
            stmt = stmt.where(MonitorTarget.platform == platform)
        targets = s.exec(stmt).all()
        if group_name or tag:
            targets = [t for t in targets if _meta_matches(t, group_name, tag)]
        if q:
            needle = q.casefold()
            targets = [t for t in targets if needle in " ".join(
                [t.alias or "", t.nickname or "", t.keyword or "", t.sec_uid or "",
                 t.group_name or "", t.tags or ""]
            ).casefold()]
        target_ids = [t.id for t in targets if t.id is not None]
        content_stmt = select(ContentRecord)
        if platform:
            content_stmt = content_stmt.where(ContentRecord.platform == platform)
        if group_name or tag or q:
            content_stmt = content_stmt.where(ContentRecord.target_id.in_(target_ids))
        contents = s.exec(content_stmt).all() if target_ids or not (group_name or tag or q) else []

    payload = build_targets_report(
        targets,
        contents,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform), ("搜索", q), ("分组", group_name), ("标签", tag),
        ]),
    )
    return _report_download(payload, "monitors")


@app.get("/api/reports/comment-watches.xlsx")
async def export_comment_watches_report(
    platform: str | None = None,
    q: str = "",
    group_name: str = "",
    tag: str = "",
    full: bool = False,
):
    from .reporting import build_watches_report

    platform = platform.strip() if platform else None
    q, group_name, tag = q.strip(), _meta_text(group_name, 40), _meta_text(tag, 24)
    if full:
        q = group_name = tag = ""
    with get_session() as s:
        stmt = select(CommentWatch).order_by(CommentWatch.id.asc())
        if platform:
            stmt = stmt.where(CommentWatch.platform == platform)
        watches = s.exec(stmt).all()
        if group_name or tag:
            watches = [w for w in watches if _meta_matches(w, group_name, tag)]
        if q:
            needle = q.casefold()
            watches = [w for w in watches if needle in " ".join(
                [w.title or "", w.aweme_id or "", w.sec_uid or "", w.alias or "",
                 w.group_name or "", w.tags or ""]
            ).casefold()]

    payload = build_watches_report(
        watches,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform), ("搜索", q), ("分组", group_name), ("标签", tag),
        ]),
    )
    return _report_download(payload, "comment_watches")


@app.get("/api/reports/danmaku-watches.xlsx")
async def export_danmaku_watches_report(
    platform: str | None = None,
    q: str = "",
    group_name: str = "",
    tag: str = "",
    full: bool = False,
):
    from .reporting import build_danmaku_watches_report

    platform = platform.strip() if platform else None
    q, group_name, tag = q.strip(), _meta_text(group_name, 40), _meta_text(tag, 24)
    if full:
        q = group_name = tag = ""
    with get_session() as s:
        stmt = select(DanmakuWatch).order_by(DanmakuWatch.id.asc())
        if platform:
            stmt = stmt.where(DanmakuWatch.platform == platform)
        watches = s.exec(stmt).all()
        if group_name or tag:
            watches = [w for w in watches if _meta_matches(w, group_name, tag)]
        if q:
            needle = q.casefold()
            watches = [w for w in watches if needle in " ".join(
                [w.title or "", w.aweme_id or "", w.sec_uid or "", w.alias or "",
                 w.group_name or "", w.tags or ""]
            ).casefold()]

    payload = build_danmaku_watches_report(
        watches,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform), ("搜索", q), ("分组", group_name), ("标签", tag),
        ]),
    )
    return _report_download(payload, "danmaku_watches")


@app.get("/api/reports/contents.xlsx")
async def export_contents_report(
    platform: str | None = None,
    target_id: int | None = None,
    group_name: str = "",
    tag: str = "",
    q: str = "",
    media_type: str = "",
    download_status: str = "",
    min_like_count: int = 0,
    min_comment_count: int = 0,
    sort: str = "create_desc",
    start_date: date | None = None,
    end_date: date | None = None,
    full: bool = False,
    captured_from: datetime | None = None,
    captured_before: datetime | None = None,
):
    from .reporting import build_contents_report

    if full:
        target_id = None
        group_name = tag = q = media_type = download_status = ""
        min_like_count = min_comment_count = 0
        sort = "create_desc"
        start = end = None
        captured_from = captured_before = None
    else:
        start, end = _report_bounds(start_date, end_date)
    captured_from, captured_before = _content_capture_bounds(captured_from, captured_before)
    platform = platform.strip() if platform else None
    group_name, tag, q = _meta_text(group_name, 40), _meta_text(tag, 24), q.strip()
    with get_session() as s:
        target_stmt = select(MonitorTarget)
        if platform:
            target_stmt = target_stmt.where(MonitorTarget.platform == platform)
        if target_id is not None:
            target_stmt = target_stmt.where(MonitorTarget.id == target_id)
        targets = s.exec(target_stmt).all()
        eligible_ids = None
        if group_name or tag:
            eligible_ids = [t.id for t in targets if t.id is not None
                            and _meta_matches(t, group_name, tag)]

        stmt = select(ContentRecord)
        if platform:
            stmt = stmt.where(ContentRecord.platform == platform)
        if target_id is not None:
            stmt = stmt.where(ContentRecord.target_id == target_id)
        if eligible_ids is not None:
            stmt = stmt.where(ContentRecord.target_id.in_(eligible_ids))
        if q:
            stmt = stmt.where(or_(ContentRecord.desc.contains(q),
                                  ContentRecord.aweme_id.contains(q)))
        if media_type in ("video", "images"):
            stmt = stmt.where(ContentRecord.media_type == media_type)
        if download_status:
            stmt = stmt.where(ContentRecord.download_status == download_status)
        if min_like_count > 0:
            stmt = stmt.where(ContentRecord.like_count >= min_like_count)
        if min_comment_count > 0:
            stmt = stmt.where(ContentRecord.comment_count >= min_comment_count)
        stmt = _report_window(stmt, ContentRecord, start, end)
        stmt = _report_window(stmt, ContentRecord, captured_from, captured_before)
        ordering = _content_ordering(sort)
        contents = s.exec(stmt.order_by(*ordering)).all()
        if eligible_ids is not None:
            targets = [t for t in targets if t.id in eligible_ids]

    payload = build_contents_report(
        contents,
        targets,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform), ("来源监控", target_id), ("分组", group_name),
            ("标签", tag), ("搜索", q), ("媒体类型", media_type),
            ("下载状态", download_status), ("最低点赞", min_like_count or ""),
            ("最低评论", min_comment_count or ""), ("排序", sort),
            ("采集开始", start_date.isoformat() if start_date else ""),
            ("采集结束", end_date.isoformat() if end_date else ""),
            ("抓取起点 UTC（含）", captured_from.isoformat() if captured_from else ""),
            ("抓取终点 UTC（不含）", captured_before.isoformat() if captured_before else ""),
        ]),
    )
    return _report_download(payload, "contents")


@app.get("/api/reports/comments.xlsx")
async def export_comments_report(
    platform: str | None = None,
    watch_id: int | None = None,
    aweme_id: str | None = None,
    group_name: str = "",
    tag: str = "",
    q: str = "",
    ip_label: str = "",
    reply_type: str = "",
    min_like_count: int = 0,
    sort: str = "latest",
    start_date: date | None = None,
    end_date: date | None = None,
    full: bool = False,
    captured_from: datetime | None = None,
    captured_before: datetime | None = None,
):
    from .reporting import build_comments_report

    if full:
        watch_id = aweme_id = None
        group_name = tag = q = ip_label = reply_type = ""
        min_like_count = 0
        sort = "latest"
        start = end = None
        captured_from = captured_before = None
    else:
        start, end = _report_bounds(start_date, end_date)
    captured_from, captured_before = _content_capture_bounds(captured_from, captured_before)
    platform = platform.strip() if platform else None
    group_name, tag, q = _meta_text(group_name, 40), _meta_text(tag, 24), q.strip()
    ip_label = ip_label.strip()[:64]
    with get_session() as s:
        watch_stmt = select(CommentWatch)
        if platform:
            watch_stmt = watch_stmt.where(CommentWatch.platform == platform)
        if watch_id is not None:
            watch_stmt = watch_stmt.where(CommentWatch.id == watch_id)
        watches = s.exec(watch_stmt).all()
        eligible_ids = None
        if group_name or tag:
            eligible_ids = [w.id for w in watches if w.id is not None
                            and _meta_matches(w, group_name, tag)]

        stmt = _watch_record_filter(select(CommentRecord), CommentRecord, watch_id)
        if platform:
            stmt = stmt.where(CommentRecord.platform == platform)
        if aweme_id:
            stmt = stmt.where(CommentRecord.aweme_id == aweme_id)
        if eligible_ids is not None:
            stmt = stmt.where(CommentRecord.watch_id.in_(eligible_ids))
        if q:
            stmt = stmt.where(or_(CommentRecord.text.contains(q),
                                  CommentRecord.user_nickname.contains(q),
                                  CommentRecord.user_sec_uid.contains(q),
                                  CommentRecord.ip_label.contains(q),
                                  CommentRecord.aweme_id.contains(q)))
        if ip_label:
            stmt = stmt.where(CommentRecord.ip_label.contains(ip_label))
        if reply_type == "top":
            stmt = stmt.where(CommentRecord.reply_to == "")
        elif reply_type == "reply":
            stmt = stmt.where(CommentRecord.reply_to != "")
        if min_like_count > 0:
            stmt = stmt.where(CommentRecord.like_count >= min_like_count)
        stmt = _report_window(stmt, CommentRecord, start, end)
        stmt = _report_window(stmt, CommentRecord, captured_from, captured_before)
        ordering = _watch_record_ordering(CommentRecord, sort)
        comments = s.exec(stmt.order_by(*ordering)).all()
        if eligible_ids is not None:
            watches = [w for w in watches if w.id in eligible_ids]

    payload = build_comments_report(
        comments,
        watches,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform), ("评论监控", watch_id), ("作品ID", aweme_id),
            ("分组", group_name), ("标签", tag), ("搜索", q),
            ("地区", ip_label),
            ("评论类型", reply_type), ("最低点赞", min_like_count or ""),
            ("排序", sort), ("采集开始", start_date.isoformat() if start_date else ""),
            ("采集结束", end_date.isoformat() if end_date else ""),
            ("抓取起点 UTC（含）", captured_from.isoformat() if captured_from else ""),
            ("抓取终点 UTC（不含）", captured_before.isoformat() if captured_before else ""),
        ]),
    )
    return _report_download(payload, "comments")


@app.get("/api/reports/danmaku.xlsx")
async def export_danmaku_report(
    platform: str | None = None,
    watch_id: int | None = None,
    aweme_id: str | None = None,
    group_name: str = "",
    tag: str = "",
    q: str = "",
    min_video_time_ms: int = 0,
    max_video_time_ms: int = 0,
    min_like_count: int = 0,
    sort: str = "video_asc",
    start_date: date | None = None,
    end_date: date | None = None,
    full: bool = False,
    captured_from: datetime | None = None,
    captured_before: datetime | None = None,
):
    from .reporting import build_danmaku_report

    if full:
        watch_id = aweme_id = None
        group_name = tag = q = ""
        min_video_time_ms = max_video_time_ms = min_like_count = 0
        sort = "video_asc"
        start = end = None
        captured_from = captured_before = None
    else:
        start, end = _report_bounds(start_date, end_date)
    captured_from, captured_before = _content_capture_bounds(captured_from, captured_before)
    platform = platform.strip() if platform else None
    group_name, tag, q = _meta_text(group_name, 40), _meta_text(tag, 24), q.strip()
    with get_session() as s:
        watch_stmt = select(DanmakuWatch)
        if platform:
            watch_stmt = watch_stmt.where(DanmakuWatch.platform == platform)
        if watch_id is not None:
            watch_stmt = watch_stmt.where(DanmakuWatch.id == watch_id)
        watches = s.exec(watch_stmt).all()
        eligible_ids = None
        if group_name or tag:
            eligible_ids = [w.id for w in watches if w.id is not None
                            and _meta_matches(w, group_name, tag)]

        stmt = _watch_record_filter(select(DanmakuRecord), DanmakuRecord, watch_id)
        if platform:
            stmt = stmt.where(DanmakuRecord.platform == platform)
        if aweme_id:
            stmt = stmt.where(DanmakuRecord.aweme_id == aweme_id)
        if eligible_ids is not None:
            stmt = stmt.where(DanmakuRecord.watch_id.in_(eligible_ids))
        if q:
            stmt = stmt.where(or_(DanmakuRecord.text.contains(q),
                                  DanmakuRecord.user_id.contains(q),
                                  DanmakuRecord.user_nickname.contains(q)))
        if min_video_time_ms > 0:
            stmt = stmt.where(DanmakuRecord.video_time_ms >= min_video_time_ms)
        if max_video_time_ms > 0:
            stmt = stmt.where(DanmakuRecord.video_time_ms <= max_video_time_ms)
        if min_like_count > 0:
            stmt = stmt.where(DanmakuRecord.like_count >= min_like_count)
        stmt = _report_window(stmt, DanmakuRecord, start, end)
        stmt = _report_window(stmt, DanmakuRecord, captured_from, captured_before)
        ordering = _watch_record_ordering(DanmakuRecord, sort)
        danmaku = s.exec(stmt.order_by(*ordering)).all()
        if eligible_ids is not None:
            watches = [w for w in watches if w.id in eligible_ids]

    payload = build_danmaku_report(
        danmaku,
        watches,
        filters=_report_filter_pairs([
            ("导出范围", "当前平台全部记录" if full else "当前筛选结果"),
            ("平台", platform), ("弹幕监控", watch_id), ("作品ID", aweme_id),
            ("分组", group_name), ("标签", tag), ("搜索", q),
            ("视频内起点(ms)", min_video_time_ms or ""),
            ("视频内终点(ms)", max_video_time_ms or ""),
            ("最低点赞", min_like_count or ""), ("排序", sort),
            ("采集开始", start_date.isoformat() if start_date else ""),
            ("采集结束", end_date.isoformat() if end_date else ""),
            ("抓取起点 UTC（含）", captured_from.isoformat() if captured_from else ""),
            ("抓取终点 UTC（不含）", captured_before.isoformat() if captured_before else ""),
        ]),
    )
    return _report_download(payload, "danmaku")


def _target_dict(t: MonitorTarget) -> dict:
    return {
        "id": t.id, "platform": t.platform, "target_kind": t.target_kind,
        "keyword": t.keyword,
        "sec_uid": t.sec_uid, "nickname": t.nickname, "avatar": t.avatar,
        "alias": t.alias, "group_name": t.group_name,
        "tags": _load_meta_tags(t.tags),
        "enabled": t.enabled, "interval_seconds": t.interval_seconds,
        "initial_backfill_count": t.initial_backfill_count,
        "download_dir": t.download_dir, "video_quality": t.video_quality,
        "download_enabled": t.download_enabled, "media_filter": t.media_filter,
        "max_scrolls": t.max_scrolls,
        "max_items_per_scan": t.max_items_per_scan,
        "record_media_filter": t.record_media_filter,
        "min_like_count": t.min_like_count,
        "min_comment_count": t.min_comment_count,
        "recent_days": t.recent_days,
        "include_keywords": _load_meta_tags(t.include_keywords),
        "exclude_keywords": _load_meta_tags(t.exclude_keywords),
        "account_id": t.account_id,
        "last_scan_at": t.last_scan_at.isoformat() if t.last_scan_at else None,
        "next_auto_run_at": utc_iso(row_deadline(t, cfg, kind="monitor")),
        "last_error": t.last_error,
    }


def _content_source(target_id: int, platform: str, target: MonitorTarget | None = None) -> dict:
    """Public attribution only; never serialize a task's account/token/config."""
    if target is None or target.platform != platform:
        return {"id": target_id, "name": f"已删除任务 #{target_id}" if target_id > 0 else "未关联任务",
                "platform": platform, "deleted": target_id > 0, "target_kind": "",
                "group_name": "", "tags": []}
    base = ("#" + target.keyword if target.target_kind == "keyword"
            else target.nickname or target.sec_uid[:12] or f"任务 #{target.id}")
    name = f"{target.alias} · {base}" if target.alias and target.alias != base else base
    return {"id": target.id, "name": name, "platform": target.platform,
            "deleted": False, "target_kind": target.target_kind,
            "group_name": target.group_name, "tags": _load_meta_tags(target.tags)}


def _content_records(session, rows) -> list[dict]:
    ids = {row.target_id for row in rows}
    targets = {t.id: t for t in session.exec(select(MonitorTarget).where(
        MonitorTarget.id.in_(ids))).all()} if ids else {}
    return [_content_dict(row, _content_source(row.target_id, row.platform, targets.get(row.target_id)))
            for row in rows]


def _content_dict(r: ContentRecord, source: dict | None = None) -> dict:
    captured = r.created_at
    if captured:
        captured = (captured.astimezone(timezone.utc) if captured.tzinfo
                    else captured.replace(tzinfo=timezone.utc))
    return {
        "id": r.id, "platform": r.platform, "target_id": r.target_id,
        "aweme_id": r.aweme_id, "desc": r.desc, "media_type": r.media_type,
        "quality": r.quality, "create_time": r.create_time, "cover_url": r.cover_url,
        "like_count": r.like_count, "comment_count": r.comment_count,
        "duration": r.duration, "retry_count": r.retry_count,
        "download_status": r.download_status, "local_path": r.local_path, "error": r.error,
        "captured_at": captured.isoformat() if captured else None,
        "source": source or _content_source(r.target_id, r.platform),
    }


def _content_local_path(rec: ContentRecord) -> Path | None:
    if not rec.local_path:
        return None
    try:
        path = Path(rec.local_path).expanduser().resolve(strict=True)
        return path if path.is_file() or path.is_dir() else None
    except (OSError, RuntimeError):
        return None


def _content_local_media_path(rec: ContentRecord) -> Path | None:
    """Return the downloaded single-file media for a content record, if usable."""
    path = _content_local_path(rec)
    try:
        return path if path and path.is_file() and path.stat().st_size > 0 else None
    except OSError:
        return None


def _reveal_in_file_manager(path: Path):
    """Open a directory or select a file in the host OS file manager."""
    target = str(path)
    if sys.platform == "win32":
        with _file_manager_lock:
            folder = path if path.is_dir() else path.parent
            snapshot = capture_window_snapshot(EXPLORER_WINDOW_CLASSES)
            if path.is_dir():
                os.startfile(target)  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["explorer.exe", "/select,", target])
            bring_window_to_front(snapshot, EXPLORER_WINDOW_CLASSES,
                                  title_hint=folder.name, timeout=2.5)
        return
    if sys.platform == "darwin":
        args = ["open", target] if path.is_dir() else ["open", "-R", target]
    else:
        args = ["xdg-open", target if path.is_dir() else str(path.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)


def _open_local_path(path: Path):
    """Open a local media file with the host OS default application."""
    target = str(path)
    if sys.platform == "win32":
        os.startfile(target)  # type: ignore[attr-defined]
        return
    args = ["open", target] if sys.platform == "darwin" else ["xdg-open", target]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)


@app.get("/api/contents/{cid}/media")
async def content_media(cid: int):
    """返回一条作品/笔记的媒体直链列表,供前端预览(图集/视频)。"""
    with get_session() as s:
        rec = s.get(ContentRecord, cid)
        if not rec:
            raise HTTPException(404, "记录不存在")
        try:
            medias = json.loads(rec.media_json or "[]")
        except Exception:
            medias = []
        local_media = _content_local_media_path(rec)
        return {
            "id": rec.id, "platform": rec.platform, "desc": rec.desc,
            "media_type": rec.media_type, "cover_url": rec.cover_url,
            "local_path": rec.local_path, "medias": medias,
            "local_url": f"/api/contents/{rec.id}/local-media" if local_media else "",
        }


@app.api_route("/api/contents/{cid}/local-media", methods=["GET", "HEAD"])
async def content_local_media(cid: int):
    """Stream downloaded media from the recorded path, including HTTP Range support."""
    with get_session() as s:
        rec = s.get(ContentRecord, cid)
        if not rec:
            raise HTTPException(404, "记录不存在")
        path = _content_local_media_path(rec)
    if not path:
        raise HTTPException(404, "本地媒体不存在")
    return FileResponse(
        path,
        filename=path.name,
        content_disposition_type="inline",
        headers={"Cache-Control": "private, no-cache"},
    )


@app.post("/api/contents/{cid}/reveal")
async def reveal_content_file(cid: int, request: Request):
    """在服务所在电脑的文件管理器中打开本地目录或定位文件。"""
    _require_local_action(request)
    with get_session() as s:
        rec = s.get(ContentRecord, cid)
        if not rec:
            raise HTTPException(404, "记录不存在")
        path = _content_local_path(rec)
    if not path:
        raise HTTPException(404, "本地文件不存在")
    try:
        await asyncio.to_thread(_reveal_in_file_manager, path)
    except OSError as e:
        raise HTTPException(500, f"打开文件夹失败:{e}") from e
    return {"ok": True}


@app.post("/api/contents/{cid}/retry-download")
async def retry_download(cid: int):
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    return await engine.retry_download(cid)


def _delete_content_files(rec: ContentRecord):
    """只删除该作品自己的文件(按 aweme_id 前缀),不动作者文件夹其它内容。"""
    if not rec.local_path:
        return 0
    p = Path(rec.local_path)
    folder = p if p.is_dir() else p.parent
    if not folder.exists():
        return 0
    n = 0
    for f in folder.glob(f"{rec.aweme_id}_*"):
        try:
            f.unlink(); n += 1
        except Exception:
            pass
    return n


@app.delete("/api/contents/{cid}")
async def del_content(cid: int, with_file: bool = True):
    removed = 0
    with get_session() as s:
        rec = s.get(ContentRecord, cid)
        if not rec:
            raise HTTPException(404, "记录不存在")
        if with_file:
            removed = _delete_content_files(rec)
        s.delete(rec); s.commit()
    return {"ok": True, "files_removed": removed}


class IdsIn(BaseModel):
    ids: list[int]
    with_file: bool = True


@app.post("/api/contents/batch-delete")
async def batch_del_contents(body: IdsIn):
    deleted = removed = 0
    with get_session() as s:
        for cid in body.ids:
            rec = s.get(ContentRecord, cid)
            if not rec:
                continue
            if body.with_file:
                removed += _delete_content_files(rec)
            s.delete(rec); deleted += 1
        s.commit()
    return {"ok": True, "deleted": deleted, "files_removed": removed}


# ─────────── 评论监控(独立实体)───────────
class WatchIn(BaseModel):
    url_or_id: str                       # 视频/笔记链接、主页链接、id
    platform: str = "douyin"            # douyin | xhs
    kind: str = "auto"                  # auto | video(单条视频/笔记) | user(账号/创作者)
    mode: str = "public"               # public | creator(仅抖音 user)
    account_id: int | None = None
    interval_seconds: int = 600
    recent_works: int = 0
    recent_days: int = 0
    max_scrolls: int = 0
    alias: str = ""
    group_name: str = ""
    tags: list[str] = PydanticField(default_factory=list)


class WatchUpdate(BaseModel):
    enabled: bool | None = None
    interval_seconds: int | None = None
    mode: str | None = None
    account_id: int | None = None
    recent_works: int | None = None
    recent_days: int | None = None
    max_scrolls: int | None = None
    alias: str | None = None
    group_name: str | None = None
    tags: list[str] | None = None


def _watch_dict(w: CommentWatch) -> dict:
    return {
        "id": w.id, "platform": w.platform,
        "kind": w.kind, "aweme_id": w.aweme_id, "sec_uid": w.sec_uid,
        "title": w.title, "avatar": w.avatar, "mode": w.mode,
        "alias": w.alias, "group_name": w.group_name,
        "tags": _load_meta_tags(w.tags),
        "account_id": w.account_id, "interval_seconds": w.interval_seconds,
        "recent_works": w.recent_works, "recent_days": w.recent_days,
        "max_scrolls": w.max_scrolls,
        "enabled": w.enabled, "comment_count": w.comment_count,
        "last_scan_at": w.last_scan_at.isoformat() if w.last_scan_at else None,
        "next_auto_run_at": utc_iso(row_deadline(w, cfg, kind="comment_watch")),
        "last_error": w.last_error,
    }


@app.get("/api/comment-watches")
async def list_watches(platform: str | None = None):
    with get_session() as s:
        q = select(CommentWatch)
        if platform:
            q = q.where(CommentWatch.platform == platform)
        watches = s.exec(q).all()
        counts = dict(s.exec(select(CommentRecord.watch_id, func.count(CommentRecord.id))
                             .where(CommentRecord.watch_id.in_([w.id for w in watches]))
                             .group_by(CommentRecord.watch_id)).all()) if watches else {}
        return [dict(_watch_dict(w), comment_count=counts.get(w.id, 0)) for w in watches]


@app.post("/api/comment-watches")
async def add_watch(body: WatchIn):
    platform = body.platform if body.platform in ("douyin", "xhs", "kuaishou") else "douyin"
    aweme_id = sec_uid = xsec_token = ""
    title = ""
    target_input = _clean_platform_target_input(body.url_or_id, platform)

    if not 1 <= body.interval_seconds <= 86400:
        raise HTTPException(400, "监控间隔须为 1~86400 秒")
    if not 0 <= body.recent_works <= 50:
        raise HTTPException(400, "近期作品数须为 0~50，0 表示跟随全局设置")
    if not 0 <= body.recent_days <= 365:
        raise HTTPException(400, "近期天数须为 0~365，0 表示跟随全局设置")
    if not 0 <= body.max_scrolls <= 50:
        raise HTTPException(400, "抓取深度须为 0~50，0 表示跟随全局设置")
    if platform == "xhs":
        kind = body.kind
        if kind == "auto":
            note_ref = None
            if xhs_looks_like_note(target_input) or "://" in target_input:
                note_ref = await xhs_resolve_note(target_input, cfg.engine.user_agent)
            if note_ref:
                kind = "video"
                aweme_id, xsec_token = note_ref.note_id, note_ref.xsec_token
            else:
                kind = "user"
        if kind == "video":
            if not aweme_id:
                ref = await xhs_resolve_note(target_input, cfg.engine.user_agent)
                if not ref:
                    raise HTTPException(400, "无法解析小红书笔记,请粘贴完整分享文案、explore 笔记链接 / xhslink 短链 / 24 位 note_id")
                aweme_id, xsec_token = ref.note_id, ref.xsec_token
            title = "笔记 " + aweme_id
        else:
            ref = await xhs_resolve_user(target_input, cfg.engine.user_agent)
            if not ref:
                raise HTTPException(400, "无法解析小红书创作者,请粘贴完整分享文案、主页链接 / xhslink 短链 / 24 位 user_id")
            sec_uid, xsec_token = ref.user_id, ref.xsec_token
        mode = "public"
    elif platform == "kuaishou":
        kind = body.kind
        if kind == "auto":
            if ks_looks_like_photo(target_input) or "://" in target_input:
                aweme_id = await resolve_ks_photo_id(target_input, cfg.engine.user_agent) or ""
            kind = "video" if aweme_id else "user"
        if kind == "video":
            if not aweme_id:
                aweme_id = await resolve_ks_photo_id(target_input, cfg.engine.user_agent)
            if not aweme_id:
                raise HTTPException(400, "无法解析快手作品 id,请粘贴完整分享文案、作品链接 / v.kuaishou.com 短链 / photo_id")
            title = "作品 " + aweme_id
        else:
            sec_uid = await resolve_ks_user_id(target_input, cfg.engine.user_agent)
            if not sec_uid:
                raise HTTPException(400, "无法解析快手 user_id,请粘贴完整分享文案、主页链接 / 短链 / user_id")
        mode = "public"
    else:
        kind = body.kind
        if kind == "auto":
            aweme_id = await resolve_aweme_id(target_input, cfg.engine.user_agent) or ""
            kind = "video" if aweme_id else "user"
        if kind == "video":
            if not aweme_id:
                aweme_id = await resolve_aweme_id(target_input, cfg.engine.user_agent)
            if not aweme_id:
                raise HTTPException(400, "无法解析视频 id,请粘贴完整分享文案、作品链接 / 短链 / 数字 id")
            title = "视频 " + aweme_id
        else:
            sec_uid = await resolve_sec_uid(target_input, cfg.engine.user_agent)
            if not sec_uid:
                raise HTTPException(400, "无法解析 sec_uid,请粘贴完整分享文案、主页链接 / 短链 / sec_uid")
        mode = body.mode if body.mode in ("public", "creator") else "public"
        if mode == "creator":
            if kind != "user":
                raise HTTPException(400, "创作中心模式只能用于「账号」类型")
            with get_session() as s:
                acc = s.get(DouyinAccount, body.account_id) if body.account_id else None
                has_creator = bool(acc and acc.creator_storage_state)
            if not has_creator:
                raise HTTPException(400, "创作中心模式需要选择一个已“创作者登录”的账号")

    with get_session() as s:
        if kind == "video":
            dup = s.exec(select(CommentWatch).where(CommentWatch.platform == platform)
                         .where(CommentWatch.aweme_id == aweme_id)).first()
        else:
            dup = s.exec(select(CommentWatch).where(CommentWatch.platform == platform)
                         .where(CommentWatch.sec_uid == sec_uid)
                         .where(CommentWatch.mode == mode)).first()
        if dup:
            raise HTTPException(409, "已存在相同的评论监控")
        w = CommentWatch(platform=platform, kind=kind, aweme_id=aweme_id, sec_uid=sec_uid,
                          xsec_token=xsec_token, mode=mode, account_id=body.account_id,
                          interval_seconds=body.interval_seconds, title=title,
                          recent_works=body.recent_works,
                          recent_days=body.recent_days,
                          max_scrolls=body.max_scrolls,
                          alias=_meta_text(body.alias, 60),
                          group_name=_meta_text(body.group_name, 40),
                          tags=_dump_meta_tags(_meta_tags(body.tags)))
        s.add(w); s.commit(); s.refresh(w)
        return _watch_dict(w)


@app.put("/api/comment-watches/{wid}")
async def update_watch(wid: int, body: WatchUpdate):
    with get_session() as s:
        w = s.get(CommentWatch, wid)
        if not w:
            raise HTTPException(404)
        if body.interval_seconds is not None and not 1 <= body.interval_seconds <= 86400:
            raise HTTPException(400, "监控间隔须为 1~86400 秒")
        if body.enabled is not None:
            w.enabled = body.enabled
        if body.interval_seconds is not None:
            w.interval_seconds = body.interval_seconds
        if body.recent_works is not None:
            if not 0 <= body.recent_works <= 50:
                raise HTTPException(400, "近期作品数须为 0~50")
            w.recent_works = body.recent_works
        if body.recent_days is not None:
            if not 0 <= body.recent_days <= 365:
                raise HTTPException(400, "近期天数须为 0~365")
            w.recent_days = body.recent_days
        if body.max_scrolls is not None:
            if not 0 <= body.max_scrolls <= 50:
                raise HTTPException(400, "抓取深度须为 0~50")
            w.max_scrolls = body.max_scrolls
        if body.mode is not None and body.mode not in ("public", "creator"):
            raise HTTPException(400, "评论来源须为 public 或 creator")
        new_mode = body.mode if body.mode is not None else w.mode
        new_account_id = body.account_id if body.account_id is not None else w.account_id
        if body.account_id is not None:
            acc = s.get(DouyinAccount, body.account_id)
            if not acc or acc.platform != w.platform or acc.status != "active":
                raise HTTPException(400, "账号不存在、登录态失效或与评论监控平台不匹配")
            w.account_id = body.account_id
        if new_mode == "creator":
            if w.platform != "douyin" or w.kind != "user":
                raise HTTPException(400, "创作中心模式仅支持抖音账号类型评论监控")
            acc = s.get(DouyinAccount, new_account_id) if new_account_id else None
            if not acc or not acc.creator_storage_state:
                raise HTTPException(400, "创作中心模式需要绑定已完成创作者登录的抖音账号")
        if body.mode is not None:
            w.mode = new_mode
        if body.alias is not None:
            w.alias = _meta_text(body.alias, 60)
        if body.group_name is not None:
            w.group_name = _meta_text(body.group_name, 40)
        if body.tags is not None:
            w.tags = _dump_meta_tags(_meta_tags(body.tags))
        s.add(w); s.commit(); s.refresh(w)
        return _watch_dict(w)


@app.delete("/api/comment-watches/{wid}")
async def del_watch(wid: int, with_comments: bool = False):
    with get_session() as s:
        w = s.get(CommentWatch, wid)
        if not w:
            return {"ok": True}
        if with_comments:
            for c in s.exec(select(CommentRecord).where(CommentRecord.watch_id == wid)).all():
                s.delete(c)
        s.delete(w); s.commit()
    return {"ok": True}


@app.post("/api/comment-watches/{wid}/scan-now")
async def scan_watch_now(wid: int):
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    return await engine.scan_comment_watch(wid)


# ─────────── 评论 / 弹幕记录来源 ───────────
def _watch_source(watch_id: int | None, platform: str, model, watch=None) -> dict:
    label = "评论" if model is CommentWatch else "弹幕"
    module = "comments" if model is CommentWatch else "danmaku"
    wid = watch_id or 0
    missing = watch is None or watch.platform != platform
    base = "" if missing else (watch.title or watch.aweme_id or watch.sec_uid[:12] or f"任务 #{wid}")
    name = (f"已删除{label}任务 #{wid}" if wid > 0 else f"未关联{label}监控") if missing else (
        f"{watch.alias} · {base}" if watch.alias and watch.alias != base else base)
    return {"id": wid, "module": module, "platform": platform, "name": name,
            "deleted": missing and wid > 0, "unassigned": wid <= 0,
            "kind": "" if missing else watch.kind,
            "group_name": "" if missing else watch.group_name,
            "tags": [] if missing else _load_meta_tags(watch.tags)}


def _selected_watch_source(session, model, watch_id, platform):
    if watch_id is None:
        return None
    watch = session.get(model, watch_id) if watch_id > 0 else None
    return _watch_source(watch_id, platform or (watch.platform if watch else ""), model, watch)


def _watch_record_filter(stmt, model, watch_id):
    if watch_id is None:
        return stmt
    if watch_id < 0:
        raise HTTPException(400, "来源监控编号应为非负整数")
    if watch_id == 0:
        return stmt.where(or_(model.watch_id == 0, model.watch_id.is_(None)))
    return stmt.where(model.watch_id == watch_id)


def _watch_record_ordering(model, sort):
    if sort == "captured_asc":
        return model.created_at.asc(), model.id.asc()
    if sort == "captured_desc":
        return model.created_at.desc(), model.id.desc()
    if model is CommentRecord:
        if sort == "oldest":
            return model.create_time.asc(), model.id.asc()
        if sort == "likes_desc":
            return model.like_count.desc(), model.id.desc()
        return model.create_time.desc(), model.id.desc()
    if sort == "video_desc":
        return model.video_time_ms.desc(), model.id.desc()
    return model.video_time_ms.asc(), model.id.asc()


def _watch_captured_at(value):
    if value is None:
        return None
    return (value.astimezone(timezone.utc) if value.tzinfo
            else value.replace(tzinfo=timezone.utc)).isoformat()


def _watch_records(session, rows, model):
    ids = {row.watch_id for row in rows if row.watch_id and row.watch_id > 0}
    watches = {w.id: w for w in session.exec(select(model).where(model.id.in_(ids))).all()} if ids else {}
    serialize = _comment_dict if model is CommentWatch else _danmaku_dict
    return [serialize(row, _watch_source(row.watch_id, row.platform, model, watches.get(row.watch_id)))
            for row in rows]


# ─────────── 评论数据 ───────────
def _comment_dict(c: CommentRecord, watch_source: dict | None = None) -> dict:
    return {
        "id": c.id, "watch_id": c.watch_id, "aweme_id": c.aweme_id,
        "comment_id": c.comment_id, "text": c.text, "user_nickname": c.user_nickname,
        "user_sec_uid": c.user_sec_uid, "ip_label": c.ip_label,
        "like_count": c.like_count, "create_time": c.create_time,
        "is_reply": bool(c.reply_to),
        "platform": c.platform, "captured_at": _watch_captured_at(c.created_at),
        "watch_source": watch_source or _watch_source(c.watch_id, c.platform, CommentWatch),
    }


@app.get("/api/comments")
async def list_comments(limit: int = 100, watch_id: int | None = None,
                        aweme_id: str | None = None, platform: str | None = None,
                        group_name: str = "", tag: str = "", q: str = "",
                        ip_label: str = "",
                        reply_type: str = "", min_like_count: int = 0,
                        sort: str = "latest", page: int = 1,
                        page_size: int = 10, paginate: bool = False,
                        captured_from: datetime | None = None,
                        captured_before: datetime | None = None):
    """Return captured comments with optional SQL filters and pagination."""
    limit = max(1, min(limit, 1000))
    page = max(1, page)
    page_size = max(1, min(page_size, 200))
    start, end = _content_capture_bounds(captured_from, captured_before)
    with get_session() as s:
        selected_source = _selected_watch_source(s, CommentWatch, watch_id, platform)
        stmt = _watch_record_filter(select(CommentRecord), CommentRecord, watch_id)
        stmt = _report_window(stmt, CommentRecord, start, end)
        if platform is not None:
            stmt = stmt.where(CommentRecord.platform == platform)
        if aweme_id is not None:
            stmt = stmt.where(CommentRecord.aweme_id == aweme_id)
        text_query = q.strip()
        region_query = ip_label.strip()[:64]
        if text_query:
            stmt = stmt.where(or_(CommentRecord.text.contains(text_query),
                                  CommentRecord.user_nickname.contains(text_query),
                                  CommentRecord.user_sec_uid.contains(text_query),
                                  CommentRecord.ip_label.contains(text_query),
                                  CommentRecord.aweme_id.contains(text_query)))
        if region_query:
            stmt = stmt.where(CommentRecord.ip_label.contains(region_query))
        if reply_type == "top":
            stmt = stmt.where(CommentRecord.reply_to == "")
        elif reply_type == "reply":
            stmt = stmt.where(CommentRecord.reply_to != "")
        if min_like_count > 0:
            stmt = stmt.where(CommentRecord.like_count >= min_like_count)
        group_name, tag = _meta_text(group_name, 40), _meta_text(tag, 24)
        if group_name or tag:
            watch_query = select(CommentWatch)
            if platform:
                watch_query = watch_query.where(CommentWatch.platform == platform)
            watches = s.exec(watch_query).all()
            eligible_ids = [w.id for w in watches if w.id is not None
                            and _meta_matches(w, group_name, tag)]
            if not eligible_ids:
                if not paginate:
                    return []
                return {"items": [], "total": 0, "page": page,
                        "page_size": page_size, "pages": 1,
                        "has_prev": page > 1, "has_next": False, "watch_source": selected_source}
            stmt = stmt.where(CommentRecord.watch_id.in_(eligible_ids))
        ordering = _watch_record_ordering(CommentRecord, sort)
        if not paginate:
            rows = s.exec(stmt.order_by(*ordering).limit(limit)).all()
            return _watch_records(s, rows, CommentWatch)

        total = int(s.exec(select(func.count()).select_from(stmt.subquery())).one())
        pages = max(1, (total + page_size - 1) // page_size)
        rows = s.exec(stmt.order_by(*ordering)
                      .offset((page - 1) * page_size)
                      .limit(page_size)).all()
        return {
            "items": _watch_records(s, rows, CommentWatch), "watch_source": selected_source,
            "total": total, "page": page, "page_size": page_size,
            "pages": pages, "has_prev": page > 1, "has_next": page < pages,
        }


@app.delete("/api/comments/{cmid}")
async def del_comment(cmid: int):
    with get_session() as s:
        c = s.get(CommentRecord, cmid)
        if c:
            s.delete(c); s.commit()
    return {"ok": True}


@app.post("/api/comments/batch-delete")
async def batch_del_comments(body: IdsIn):
    deleted = 0
    with get_session() as s:
        for cid in body.ids:
            c = s.get(CommentRecord, cid)
            if c:
                s.delete(c); deleted += 1
        s.commit()
    return {"ok": True, "deleted": deleted}


@app.delete("/api/comments")
async def clear_comments(watch_id: int | None = None):
    with get_session() as s:
        q = select(CommentRecord)
        if watch_id is not None:
            q = q.where(CommentRecord.watch_id == watch_id)
        rows = s.exec(q).all()
        for c in rows:
            s.delete(c)
        s.commit()
        return {"ok": True, "deleted": len(rows)}


class DanmakuWatchIn(BaseModel):
    url_or_id: str
    platform: str = "douyin"
    kind: str = "auto"              # auto | video | user
    mode: str = "public"            # public | creator
    account_id: int | None = None
    interval_seconds: int = 0       # 0=跟随全局扫描间隔
    recent_works: int = 0           # 0=跟随全局弹幕作品数
    recent_days: int = 0             # 0=跟随全局弹幕时间范围
    max_scrolls: int = 0             # 0=跟随全局弹幕加载轮次
    time_start_ms: int = 0
    time_end_ms: int = 0
    probe_step_seconds: float = 0.0  # 0=跟随全局时间轴步长
    include_keywords: list[str] = PydanticField(default_factory=list)
    exclude_keywords: list[str] = PydanticField(default_factory=list)
    min_text_length: int = 0
    max_text_length: int = 0
    min_like_count: int = 0
    max_records_per_scan: int = 0  # 0=跟随全局
    max_records_total: int = 0     # 0=跟随全局
    alias: str = ""
    group_name: str = ""
    tags: list[str] = PydanticField(default_factory=list)


class DanmakuWatchUpdate(BaseModel):
    enabled: bool | None = None
    interval_seconds: int | None = None
    mode: str | None = None
    account_id: int | None = None
    recent_works: int | None = None
    recent_days: int | None = None
    max_scrolls: int | None = None
    time_start_ms: int | None = None
    time_end_ms: int | None = None
    probe_step_seconds: float | None = None
    include_keywords: list[str] | None = None
    exclude_keywords: list[str] | None = None
    min_text_length: int | None = None
    max_text_length: int | None = None
    min_like_count: int | None = None
    max_records_per_scan: int | None = None
    max_records_total: int | None = None
    alias: str | None = None
    group_name: str | None = None
    tags: list[str] | None = None


def _danmaku_watch_dict(w: DanmakuWatch) -> dict:
    return {
        "id": w.id, "platform": w.platform, "kind": w.kind,
        "aweme_id": w.aweme_id, "sec_uid": w.sec_uid,
        "title": w.title, "avatar": w.avatar, "mode": w.mode,
        "alias": w.alias, "group_name": w.group_name,
        "tags": _load_meta_tags(w.tags),
        "account_id": w.account_id, "interval_seconds": w.interval_seconds,
        "effective_interval_seconds": w.interval_seconds or cfg.engine.scan_interval_seconds,
        "uses_global_interval": w.interval_seconds == 0,
        "recent_works": w.recent_works, "recent_days": w.recent_days,
        "max_scrolls": w.max_scrolls, "enabled": w.enabled,
        "effective_recent_works": w.recent_works or cfg.engine.danmaku_recent_works,
        "effective_recent_days": w.recent_days or cfg.engine.danmaku_recent_days,
        "effective_max_scrolls": w.max_scrolls or cfg.engine.danmaku_max_scrolls,
        "time_start_ms": w.time_start_ms, "time_end_ms": w.time_end_ms,
        "probe_step_seconds": w.probe_step_seconds,
        "effective_probe_step_seconds": w.probe_step_seconds or cfg.engine.danmaku_probe_step_seconds,
        "effective_max_probe_points": cfg.engine.danmaku_max_probe_points,
        "include_keywords": _load_meta_tags(w.include_keywords),
        "exclude_keywords": _load_meta_tags(w.exclude_keywords),
        "min_text_length": w.min_text_length, "max_text_length": w.max_text_length,
        "min_like_count": w.min_like_count,
        "max_records_per_scan": w.max_records_per_scan,
        "max_records_total": w.max_records_total,
        "effective_max_records_per_scan": w.max_records_per_scan or cfg.engine.danmaku_max_records_per_scan,
        "effective_max_records_total": w.max_records_total or cfg.engine.danmaku_max_records_total,
        "danmaku_count": w.danmaku_count,
        "last_scan_at": w.last_scan_at.isoformat() if w.last_scan_at else None,
        "next_auto_run_at": utc_iso(row_deadline(w, cfg, kind="danmaku")),
        "last_error": w.last_error,
    }


def _parse_stored_danmaku(row: DanmakuRecord) -> dict | None:
    if not row.raw_json:
        return None
    try:
        raw = json.loads(row.raw_json)
    except Exception:
        return None
    return parse_danmaku(raw, row.aweme_id or "")


def _backfill_danmaku_records() -> int:
    """用 raw_json 修复接口改版前已入库的 offset_time/user_id 等字段。"""
    repaired = 0
    with get_session() as s:
        rows = s.exec(select(DanmakuRecord)).all()
        for row in rows:
            parsed = _parse_stored_danmaku(row)
            if not parsed:
                continue
            changed = False
            for name in ("aweme_id", "user_id", "user_nickname", "video_time_ms",
                         "create_time", "like_count", "is_blocked"):
                current = getattr(row, name)
                value = parsed.get(name)
                if (not current) and value not in (None, "", 0, False):
                    setattr(row, name, value)
                    changed = True
            if changed:
                s.add(row)
                repaired += 1
        if repaired:
            s.commit()
    return repaired


def _danmaku_dict(row: DanmakuRecord, watch_source: dict | None = None) -> dict:
    parsed = _parse_stored_danmaku(row)
    user_id = row.user_id or (parsed or {}).get("user_id", "")
    user_nickname = row.user_nickname or (parsed or {}).get("user_nickname", "")
    point = max(0, int(row.video_time_ms or (parsed or {}).get("video_time_ms", 0) or 0))
    return {
        "id": row.id, "watch_id": row.watch_id, "aweme_id": row.aweme_id,
        "danmaku_id": row.danmaku_id, "text": row.text,
        "user_id": user_id, "user_nickname": user_nickname,
        "video_time_ms": point, "video_time": point / 1000,
        "create_time": row.create_time, "like_count": row.like_count,
        "is_blocked": row.is_blocked, "source": row.source,
        "created_at": row.created_at.isoformat() if row.created_at else None,
        "platform": row.platform, "captured_at": _watch_captured_at(row.created_at),
        "watch_source": watch_source or _watch_source(row.watch_id, row.platform, DanmakuWatch),
    }


@app.get("/api/danmaku-watches")
async def list_danmaku_watches(platform: str | None = None):
    with get_session() as s:
        q = select(DanmakuWatch).order_by(DanmakuWatch.id.desc())
        if platform:
            q = q.where(DanmakuWatch.platform == platform)
        watches = s.exec(q).all()
        counts = dict(s.exec(select(DanmakuRecord.watch_id, func.count(DanmakuRecord.id))
                             .where(DanmakuRecord.watch_id.in_([w.id for w in watches]))
                             .group_by(DanmakuRecord.watch_id)).all()) if watches else {}
        return [dict(_danmaku_watch_dict(w), danmaku_count=counts.get(w.id, 0)) for w in watches]


@app.post("/api/danmaku-watches")
async def add_danmaku_watch(body: DanmakuWatchIn):
    if body.platform != "douyin":
        raise HTTPException(400, "短视频弹幕监控当前仅支持抖音")
    target_input = _clean_platform_target_input(body.url_or_id, "douyin")
    if body.interval_seconds != 0 and not 1 <= body.interval_seconds <= 86400:
        raise HTTPException(400, "监控间隔须为 1~86400 秒,或填 0 跟随全局")
    if not 0 <= body.recent_works <= 50:
        raise HTTPException(400, "近期作品数须为 0~50")
    if not 0 <= body.recent_days <= 365:
        raise HTTPException(400, "近期天数须为 0~365")
    if not 0 <= body.max_scrolls <= 50:
        raise HTTPException(400, "抓取轮次须为 0~50")
    if body.time_start_ms < 0 or body.time_start_ms > 86_400_000:
        raise HTTPException(400, "视频起始时间须为 0~86400 秒")
    if body.time_end_ms < 0 or body.time_end_ms > 86_400_000:
        raise HTTPException(400, "视频结束时间须为 0~86400 秒")
    if body.time_end_ms and body.time_end_ms < body.time_start_ms:
        raise HTTPException(400, "视频结束时间须不早于起始时间")
    if body.probe_step_seconds != 0 and not 0.25 <= body.probe_step_seconds <= 30:
        raise HTTPException(400, "时间扫描步长须为 0 或 0.25~30 秒")
    if not 0 <= body.min_text_length <= 200 or not 0 <= body.max_text_length <= 200:
        raise HTTPException(400, "文本长度过滤须为 0~200")
    if body.max_text_length and body.max_text_length < body.min_text_length:
        raise HTTPException(400, "最大文本长度须不小于最小文本长度")
    if body.min_like_count < 0:
        raise HTTPException(400, "最少点赞数不能小于 0")
    if not 0 <= body.max_records_per_scan <= 100_000:
        raise HTTPException(400, "单轮记录上限须为 0~100000")
    if not 0 <= body.max_records_total <= 1_000_000:
        raise HTTPException(400, "总记录上限须为 0~1000000")

    aweme_id = sec_uid = ""
    kind = body.kind
    if kind == "auto":
        aweme_id = await resolve_aweme_id(target_input, cfg.engine.user_agent) or ""
        kind = "video" if aweme_id else "user"
    if kind not in ("video", "user"):
        raise HTTPException(400, "监控对象类型须为 video 或 user")
    mode = body.mode if body.mode in ("public", "creator") else "public"
    title = ""
    if kind == "video":
        if not aweme_id:
            aweme_id = await resolve_aweme_id(target_input, cfg.engine.user_agent)
        if not aweme_id:
            raise HTTPException(400, "无法解析视频 id,请粘贴完整分享文案、作品链接、短链或数字 id")
        title = "视频 " + aweme_id
    else:
        sec_uid = await resolve_sec_uid(target_input, cfg.engine.user_agent)
        if not sec_uid:
            raise HTTPException(400, "无法解析 sec_uid,请粘贴完整分享文案、账号主页、短链或 sec_uid")
        title = "账号 " + sec_uid[:12]

    if mode == "creator":
        with get_session() as s:
            acc = s.get(DouyinAccount, body.account_id) if body.account_id else None
            if not acc or acc.platform != "douyin" or not acc.creator_storage_state:
                raise HTTPException(400, "创作中心弹幕模式需要选择已完成创作者登录的抖音账号")
            if kind == "user" and acc.sec_uid and acc.sec_uid != sec_uid:
                raise HTTPException(400, "创作中心账号与监控账号不一致")

    with get_session() as s:
        q = select(DanmakuWatch).where(
            DanmakuWatch.platform == "douyin",
            DanmakuWatch.kind == kind,
            DanmakuWatch.mode == mode)
        q = q.where(DanmakuWatch.aweme_id == aweme_id if kind == "video"
                    else DanmakuWatch.sec_uid == sec_uid)
        if s.exec(q).first():
            raise HTTPException(409, "已存在相同的弹幕监控")
        watch = DanmakuWatch(
            platform="douyin", kind=kind, aweme_id=aweme_id, sec_uid=sec_uid,
            title=title, mode=mode, account_id=body.account_id,
            interval_seconds=body.interval_seconds,
            recent_works=body.recent_works, recent_days=body.recent_days,
            max_scrolls=body.max_scrolls,
            time_start_ms=body.time_start_ms, time_end_ms=body.time_end_ms,
            probe_step_seconds=body.probe_step_seconds,
            include_keywords=_dump_meta_tags(_meta_tags(body.include_keywords)),
            exclude_keywords=_dump_meta_tags(_meta_tags(body.exclude_keywords)),
            min_text_length=body.min_text_length, max_text_length=body.max_text_length,
            min_like_count=body.min_like_count,
            max_records_per_scan=body.max_records_per_scan,
            max_records_total=body.max_records_total,
            alias=_meta_text(body.alias, 60),
            group_name=_meta_text(body.group_name, 40),
            tags=_dump_meta_tags(_meta_tags(body.tags)))
        s.add(watch)
        s.commit()
        s.refresh(watch)
        return _danmaku_watch_dict(watch)


@app.put("/api/danmaku-watches/{wid}")
async def update_danmaku_watch(wid: int, body: DanmakuWatchUpdate):
    with get_session() as s:
        watch = s.get(DanmakuWatch, wid)
        if not watch:
            raise HTTPException(404, "弹幕监控不存在")
        if body.interval_seconds is not None and body.interval_seconds != 0 \
                and not 1 <= body.interval_seconds <= 86400:
            raise HTTPException(400, "监控间隔须为 1~86400 秒,或填 0 跟随全局")
        if body.recent_works is not None and not 0 <= body.recent_works <= 50:
            raise HTTPException(400, "近期作品数须为 0~50")
        if body.recent_days is not None and not 0 <= body.recent_days <= 365:
            raise HTTPException(400, "近期天数须为 0~365")
        if body.max_scrolls is not None and not 0 <= body.max_scrolls <= 50:
            raise HTTPException(400, "抓取轮次须为 0~50")
        current_start = body.time_start_ms if body.time_start_ms is not None else watch.time_start_ms
        current_end = body.time_end_ms if body.time_end_ms is not None else watch.time_end_ms
        current_step = body.probe_step_seconds if body.probe_step_seconds is not None else watch.probe_step_seconds
        current_min_len = body.min_text_length if body.min_text_length is not None else watch.min_text_length
        current_max_len = body.max_text_length if body.max_text_length is not None else watch.max_text_length
        current_min_like = body.min_like_count if body.min_like_count is not None else watch.min_like_count
        current_scan_cap = body.max_records_per_scan if body.max_records_per_scan is not None else watch.max_records_per_scan
        current_total_cap = body.max_records_total if body.max_records_total is not None else watch.max_records_total
        if current_start < 0 or current_start > 86_400_000 or current_end < 0 or current_end > 86_400_000:
            raise HTTPException(400, "视频时间范围须为 0~86400 秒")
        if current_end and current_end < current_start:
            raise HTTPException(400, "视频结束时间须不早于起始时间")
        if current_step != 0 and not 0.25 <= current_step <= 30:
            raise HTTPException(400, "时间扫描步长须为 0 或 0.25~30 秒")
        if not 0 <= current_min_len <= 200 or not 0 <= current_max_len <= 200:
            raise HTTPException(400, "文本长度过滤须为 0~200")
        if current_max_len and current_max_len < current_min_len:
            raise HTTPException(400, "最大文本长度须不小于最小文本长度")
        if current_min_like < 0:
            raise HTTPException(400, "最少点赞数不能小于 0")
        if not 0 <= current_scan_cap <= 100_000 or not 0 <= current_total_cap <= 1_000_000:
            raise HTTPException(400, "记录上限超出范围")
        new_mode = body.mode if body.mode is not None else watch.mode
        if new_mode not in ("public", "creator"):
            raise HTTPException(400, "弹幕来源须为 public 或 creator")
        new_account_id = body.account_id if body.account_id is not None else watch.account_id
        if new_mode == "creator":
            acc = s.get(DouyinAccount, new_account_id) if new_account_id else None
            if not acc or acc.platform != "douyin" or not acc.creator_storage_state:
                raise HTTPException(400, "创作中心弹幕模式需要绑定已完成创作者登录的抖音账号")
            if watch.kind == "user" and acc.sec_uid and watch.sec_uid \
                    and acc.sec_uid != watch.sec_uid:
                raise HTTPException(400, "创作中心账号与监控账号不一致")
        if body.enabled is not None:
            watch.enabled = body.enabled
        if body.interval_seconds is not None:
            watch.interval_seconds = body.interval_seconds
        if body.mode is not None:
            watch.mode = new_mode
        if body.account_id is not None:
            watch.account_id = body.account_id
        if body.recent_works is not None:
            watch.recent_works = body.recent_works
        if body.recent_days is not None:
            watch.recent_days = body.recent_days
        if body.max_scrolls is not None:
            watch.max_scrolls = body.max_scrolls
        if body.time_start_ms is not None:
            watch.time_start_ms = body.time_start_ms
        if body.time_end_ms is not None:
            watch.time_end_ms = body.time_end_ms
        if body.probe_step_seconds is not None:
            watch.probe_step_seconds = body.probe_step_seconds
        if body.include_keywords is not None:
            watch.include_keywords = _dump_meta_tags(_meta_tags(body.include_keywords))
        if body.exclude_keywords is not None:
            watch.exclude_keywords = _dump_meta_tags(_meta_tags(body.exclude_keywords))
        if body.min_text_length is not None:
            watch.min_text_length = body.min_text_length
        if body.max_text_length is not None:
            watch.max_text_length = body.max_text_length
        if body.min_like_count is not None:
            watch.min_like_count = body.min_like_count
        if body.max_records_per_scan is not None:
            watch.max_records_per_scan = body.max_records_per_scan
        if body.max_records_total is not None:
            watch.max_records_total = body.max_records_total
        if body.alias is not None:
            watch.alias = _meta_text(body.alias, 60)
        if body.group_name is not None:
            watch.group_name = _meta_text(body.group_name, 40)
        if body.tags is not None:
            watch.tags = _dump_meta_tags(_meta_tags(body.tags))
        s.add(watch)
        s.commit()
        s.refresh(watch)
        return _danmaku_watch_dict(watch)


@app.delete("/api/danmaku-watches/{wid}")
async def delete_danmaku_watch(wid: int, with_records: bool = False):
    with get_session() as s:
        watch = s.get(DanmakuWatch, wid)
        if not watch:
            return {"ok": True}
        deleted = 0
        if with_records:
            rows = s.exec(select(DanmakuRecord).where(
                DanmakuRecord.watch_id == wid)).all()
            for row in rows:
                s.delete(row)
            deleted = len(rows)
        s.delete(watch)
        s.commit()
        return {"ok": True, "records_deleted": deleted}


@app.post("/api/danmaku-watches/{wid}/scan-now")
async def scan_danmaku_watch_now(wid: int):
    if engine is None:
        raise HTTPException(503, "引擎未就绪")
    result = await engine.scan_danmaku_watch(wid)
    if not result.get("ok") and not result.get("new_danmaku"):
        raise HTTPException(400, result.get("error") or "弹幕抓取失败")
    return result


@app.get("/api/danmaku")
async def list_danmaku(limit: int = 100, watch_id: int | None = None,
                       aweme_id: str | None = None, platform: str | None = None,
                       group_name: str = "", tag: str = "", q: str = "",
                       min_video_time_ms: int = 0, max_video_time_ms: int = 0,
                       min_like_count: int = 0, sort: str = "video_asc",
                       page: int = 1, page_size: int = 10,
                       paginate: bool = False,
                       captured_from: datetime | None = None,
                       captured_before: datetime | None = None):
    limit = max(1, min(limit, 1000))
    page = max(1, page)
    page_size = max(1, min(page_size, 200))
    start, end = _content_capture_bounds(captured_from, captured_before)
    with get_session() as s:
        selected_source = _selected_watch_source(s, DanmakuWatch, watch_id, platform)
        stmt = _watch_record_filter(select(DanmakuRecord), DanmakuRecord, watch_id)
        stmt = _report_window(stmt, DanmakuRecord, start, end)
        if platform:
            stmt = stmt.where(DanmakuRecord.platform == platform)
        if aweme_id:
            stmt = stmt.where(DanmakuRecord.aweme_id == aweme_id)
        text_query = q.strip()
        if text_query:
            stmt = stmt.where(or_(DanmakuRecord.text.contains(text_query),
                                  DanmakuRecord.user_id.contains(text_query),
                                  DanmakuRecord.user_nickname.contains(text_query)))
        if min_video_time_ms > 0:
            stmt = stmt.where(DanmakuRecord.video_time_ms >= min_video_time_ms)
        if max_video_time_ms > 0:
            stmt = stmt.where(DanmakuRecord.video_time_ms <= max_video_time_ms)
        if min_like_count > 0:
            stmt = stmt.where(DanmakuRecord.like_count >= min_like_count)
        group_name, tag = _meta_text(group_name, 40), _meta_text(tag, 24)
        if group_name or tag:
            watch_query = select(DanmakuWatch)
            if platform:
                watch_query = watch_query.where(DanmakuWatch.platform == platform)
            watches = s.exec(watch_query).all()
            ids = [w.id for w in watches if w.id is not None
                   and _meta_matches(w, group_name, tag)]
            if not ids:
                if not paginate:
                    return []
                return {
                    "items": [], "total": 0, "page": page,
                    "page_size": page_size, "pages": 1,
                    "has_prev": page > 1, "has_next": False, "watch_source": selected_source,
                }
            stmt = stmt.where(DanmakuRecord.watch_id.in_(ids))
        ordering = _watch_record_ordering(DanmakuRecord, sort)
        if not paginate:
            rows = s.exec(stmt.order_by(*ordering).limit(limit)).all()
            return _watch_records(s, rows, DanmakuWatch)

        total = int(s.exec(select(func.count()).select_from(stmt.subquery())).one())
        pages = max(1, (total + page_size - 1) // page_size)
        rows = s.exec(
            stmt.order_by(*ordering)
            .offset((page - 1) * page_size)
            .limit(page_size)
        ).all()
        return {
            "items": _watch_records(s, rows, DanmakuWatch), "watch_source": selected_source,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": pages,
            "has_prev": page > 1,
            "has_next": page < pages,
        }


@app.delete("/api/danmaku/{did}")
async def delete_danmaku(did: int):
    with get_session() as s:
        row = s.get(DanmakuRecord, did)
        if row:
            s.delete(row)
            s.commit()
    return {"ok": True}


@app.post("/api/danmaku/batch-delete")
async def batch_delete_danmaku(body: IdsIn):
    deleted = 0
    with get_session() as s:
        for did in body.ids:
            row = s.get(DanmakuRecord, did)
            if row:
                s.delete(row)
                deleted += 1
        s.commit()
    return {"ok": True, "deleted": deleted}


@app.delete("/api/danmaku")
async def clear_danmaku(watch_id: int | None = None):
    with get_session() as s:
        q = select(DanmakuRecord)
        if watch_id is not None:
            q = q.where(DanmakuRecord.watch_id == watch_id)
        rows = s.exec(q).all()
        for row in rows:
            s.delete(row)
        s.commit()
        return {"ok": True, "deleted": len(rows)}


# ─────────── 发布(创作平台)+ 跨平台转发 ───────────
UPLOAD_DIR = Path("./data/uploads")


@app.post("/api/publish/upload")
async def publish_upload(files: list[UploadFile] = File(...)):
    """上传图集/视频文件,返回本地路径列表(供创建发布任务用)。"""
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    saved = []
    for f in files:
        ext = Path(f.filename or "").suffix or ".bin"
        name = f"{_uuid.uuid4().hex}{ext}"
        dest = UPLOAD_DIR / name
        with open(dest, "wb") as out:
            while chunk := await f.read(1 << 20):
                out.write(chunk)
        saved.append({"path": str(dest), "name": f.filename})
    return {"files": saved}


class PublishIn(BaseModel):
    account_id: int
    media_type: str = "images"            # images | video
    title: str = ""
    desc: str = ""
    topics: str = ""
    location: str = ""                    # 视频号:位置 POI(可选)
    media_paths: list[str] = []
    visibility: str = "public"            # 抖音:public | friends | private
    allow_save: bool = True               # 抖音:是否允许他人保存
    scheduled_at: str | None = None       # ISO 带偏移；无偏移按账号时区，空=尽快发


class PublishUpdate(BaseModel):
    account_id: int | None = None
    title: str | None = None
    desc: str | None = None
    topics: str | None = None
    location: str | None = None
    visibility: str | None = None
    allow_save: bool | None = None
    scheduled_at: str | None = None


def _publish_dict(t: PublishTask) -> dict:
    result_url = t.result_url or ""
    if t.platform == "kuaishou" and t.status == "done":
        try:
            result_path = urlsplit(result_url).path.lower()
        except (TypeError, ValueError):
            result_path = ""
        # 旧任务把发布表单地址存成结果地址；列表输出时即时修正，历史记录
        # 无需重新发布即可打开真正的作品管理页。
        if not result_url or "/article/publish/" in result_path:
            result_url = KS_MANAGE_URL
    return {
        "id": t.id, "platform": t.platform, "account_id": t.account_id,
        "media_type": t.media_type, "title": t.title, "desc": t.desc,
        "topics": t.topics, "location": t.location,
        "status": t.status, "result_url": result_url,
        "visibility": t.visibility, "allow_save": t.allow_save,
        "error": t.error, "media_count": len(json.loads(t.media_json or "[]")),
        "source_platform": t.source_platform, "source_content_id": t.source_content_id,
        "scheduled_at": (utc_iso(t.scheduled_at) if t.scheduled_at_is_utc
                         else t.scheduled_at.isoformat() if t.scheduled_at else None),
        "schedule_needs_confirmation": bool(t.scheduled_at and not t.scheduled_at_is_utc),
        "next_allowed_at": utc_iso(t.next_allowed_at),
        "blocked_reason": t.blocked_reason,
        "created_at": utc_iso(t.created_at),
    }


def _parse_when(s: str | None, timezone_name: str = "Asia/Shanghai") -> datetime | None:
    try:
        return parse_schedule(s, timezone_name)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/api/publish")
async def list_publish(platform: str | None = None):
    with get_session() as s:
        q = select(PublishTask)
        if platform:
            q = q.where(PublishTask.platform == platform)
        rows = s.exec(q.order_by(PublishTask.id.desc())).all()
        return [_publish_dict(t) for t in rows]


@app.post("/api/publish")
async def add_publish(body: PublishIn, request: Request = None):
    with get_session() as s:
        def create():
            if body.media_type not in ("images", "video"):
                raise HTTPException(400, "media_type 须为 images 或 video")
            acc = s.get(DouyinAccount, body.account_id)
            if not acc or acc.platform not in ("xhs", "kuaishou", "douyin", "shipinhao"):
                raise HTTPException(400, "请选择一个已登录的抖音 / 小红书 / 快手 / 视频号账号")
            if acc.platform == "xhs":
                from .platforms.xhs.media import validate_publish_files
                try:
                    paths = validate_publish_files(body.media_type, body.media_paths)
                except ValueError as exc:
                    raise HTTPException(422, str(exc)) from exc
            else:
                paths = [p for p in body.media_paths if Path(p).is_file()]
                if not paths:
                    raise HTTPException(400, "没有可用的媒体文件,请先上传")
            pname = {"kuaishou": "快手", "douyin": "抖音",
                     "shipinhao": "视频号"}.get(acc.platform, "小红书")
            if acc.platform in ("kuaishou", "douyin", "shipinhao"):
                if not (acc.creator_storage_state or acc.storage_state):
                    raise HTTPException(400, f"该{pname}账号不可发布:请先在账号页完成登录")
            elif not (acc.creator_storage_state or has_creator_cookies(acc.storage_state)):
                raise HTTPException(400, "该账号不可发布:请对该号完成「小红书扫码登录」或「创作者登录」")
            vis = body.visibility if body.visibility in ("public", "friends", "private") else "public"
            t = PublishTask(
                platform=acc.platform, account_id=body.account_id, media_type=body.media_type,
                title=body.title.strip()[:20], desc=body.desc, topics=body.topics,
                location=(body.location or "").strip()[:60],
                visibility=vis, allow_save=bool(body.allow_save),
                media_json=json.dumps(paths),
                scheduled_at=_parse_when(body.scheduled_at, acc.timezone_id),
            )
            s.add(t); s.flush()
            return _publish_dict(t)
        payload, _ = submit_once(s, request=request, scope="publish", body=body, create=create)
        return payload


@app.put("/api/publish/{tid}")
async def update_publish(tid: int, body: PublishUpdate):
    with get_session() as s:
        t = s.get(PublishTask, tid)
        if not t:
            raise HTTPException(404)
        if t.status not in ("draft", "pending", "failed", "canceled"):
            raise HTTPException(400, f"任务状态为 {t.status},不可编辑")
        if t.scheduled_at and not t.scheduled_at_is_utc and "scheduled_at" not in body.model_fields_set:
            raise HTTPException(422, "请确认预约时间，或明确清空时间选择尽快发布")
        if body.account_id is not None:
            acc = s.get(DouyinAccount, body.account_id)
            if not acc or acc.platform != t.platform or acc.status != "active":
                raise HTTPException(400, "发布账号不存在、登录态失效或与任务平台不匹配")
            t.account_id = body.account_id
        if body.title is not None:
            t.title = body.title.strip()[:20]
        if body.desc is not None:
            t.desc = body.desc
        if body.topics is not None:
            t.topics = body.topics.strip()
        if body.location is not None:
            t.location = body.location.strip()[:60]
        if body.visibility is not None:
            if body.visibility not in ("public", "friends", "private"):
                raise HTTPException(400, "可见范围须为 public、friends 或 private")
            t.visibility = body.visibility
        if body.allow_save is not None:
            t.allow_save = body.allow_save
        if "scheduled_at" in body.model_fields_set:
            account = s.get(DouyinAccount, t.account_id) if t.account_id else None
            t.scheduled_at = _parse_when(body.scheduled_at, account.timezone_id if account else "Asia/Shanghai")
            t.scheduled_at_is_utc = True
        if t.status in ("draft", "failed", "canceled"):
            t.status = "pending"
            t.error = ""
        s.add(t); s.commit(); s.refresh(t)
        return _publish_dict(t)


@app.post("/api/publish/{tid}/run-now")
async def run_publish(tid: int):
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    return await engine.publish_task(tid)


@app.delete("/api/publish/{tid}")
async def del_publish(tid: int):
    with get_session() as s:
        t = s.get(PublishTask, tid)
        if t:
            if t.status in ("publishing", "uncertain"):
                raise HTTPException(409, "任务正在执行或结果待核对，请先确认平台结果")
            s.delete(t); s.commit()
    return {"ok": True}


def _first_val(d: dict, *keys, default=""):
    for k in keys:
        v = d.get(k)
        if v not in (None, "", 0, []):
            return v
    return default


async def _xhs_account_uid(state: str, proxy: str = "", *,
                           detailed: bool = False, user_agent: str = ""):
    """拿到该账号自己的 user_id(self_info → 创作平台资料兜底)。"""
    from .platforms.xhs import XhsApiClient, cookie_str_from_state, has_a1, creator_profile
    cookie = cookie_str_from_state(state)
    if has_a1(cookie):
        try:
            client = XhsApiClient(cookie, user_agent or cfg.engine.user_agent,
                                  timeout=cfg.engine.request_timeout_seconds, proxy=proxy)
            me = await client.self_info()
            uid = str((me or {}).get("user_id") or "")
            if uid:
                return (uid, "") if detailed else uid
        except Exception as exc:
            category, _signal = classify_platform_error(exc)
            if detailed and category in {
                    RiskCategory.RISK, RiskCategory.AUTH, RiskCategory.NETWORK}:
                return "", exc
    try:
        if detailed:
            prof, profile_error = await creator_profile(
                state, proxy=proxy, preserve_error=True)
        else:
            prof = await creator_profile(state, proxy=proxy)
            profile_error = ""
    except Exception as exc:
        if detailed:
            return "", exc
        raise
    if detailed and profile_error:
        return "", profile_error
    uid = (prof or {}).get("sec_uid") or ""
    return (uid, "") if detailed else uid


def _imgs_of(n: dict) -> list:
    out = []
    for it in (n.get("images_list") or n.get("imageList") or []):
        if isinstance(it, dict):
            u = it.get("url") or it.get("url_default") or it.get("urlDefault") or ""
            if u:
                out.append(u)
    return out


@app.get("/api/publish/published")
async def list_published_notes(account_id: int):
    """拉取「已发布作品列表」。
    优先用「读取登录态」打开自己的 www 主页(token 对预览/评论有效);
    没有读取态时回退创作平台「笔记管理」(能显示,但视频预览/评论可能不可用)。"""
    if browser is None:
        raise HTTPException(503, "浏览器未就绪")
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc or acc.platform != "xhs":
            raise HTTPException(400, "请选择一个已登录的小红书账号")
        read_state = acc.storage_state or ""
        creator_state = acc.creator_storage_state or ""
        proxy = acc.proxy or ""
        if not (read_state or creator_state):
            raise HTTPException(400, "该账号未登录,请先在账号页扫码登录")
    from .browser import fetch_xhs_notes, fetch_creator_published
    from .platforms.xhs import parse_note_brief

    async def _fetch_published_notes():
        def _payload(items, good_tokens=False, error_category=""):
            payload = {
                "notes": items,
                "total": len(items),
                "good_tokens": good_tokens,
            }
            if error_category:
                payload["_error_category"] = error_category
            return payload

        def _failure(error):
            category, _signal = classify_platform_error(error)
            return _payload([], error_category=category.value), error

        with get_session() as s:
            current = s.get(DouyinAccount, account_id)
            identity = browser.identity_for(current)
        out, good = [], False
        if read_state:
            uid = str(current.sec_uid or "") if current else ""
            uid_error = ""
            if not uid and _xhs_browser_reads_enabled():
                profile, uid_error = await fetch_xhs_self_profile(
                    browser, identity)
                if profile:
                    uid = str(
                        (parse_xhs_self_user(profile) or {}).get("sec_uid")
                        or "")
            elif not uid:
                uid, uid_error = await _xhs_account_uid(
                    read_state, proxy, detailed=True)
            if uid_error:
                category, _signal = classify_platform_error(uid_error)
                if category in {
                        RiskCategory.RISK, RiskCategory.AUTH,
                        RiskCategory.NETWORK}:
                    return _failure(uid_error)
            if uid:
                try:
                    items, _a, read_error = await fetch_xhs_notes(
                        browser, identity, uid, set())
                except Exception as exc:
                    category, _signal = classify_platform_error(exc)
                    if category in {
                            RiskCategory.RISK, RiskCategory.AUTH,
                            RiskCategory.NETWORK}:
                        return _failure(exc)
                    items, read_error = [], exc
                if read_error:
                    category, _signal = classify_platform_error(read_error)
                    if category in {
                            RiskCategory.RISK, RiskCategory.AUTH,
                            RiskCategory.NETWORK}:
                        return _failure(read_error)
                for raw in items[:80]:
                    b = parse_note_brief(raw)
                    if not b:
                        continue
                    card = raw.get("note_card") or raw
                    interact = card.get("interact_info") or {}
                    out.append({
                        "note_id": b["note_id"],
                        "title": b.get("title") or "(无标题)",
                        "type": b.get("type") or "normal",
                        "cover": b.get("cover") or "",
                        "images": [],
                        "like": interact.get("liked_count") or 0,
                        "time": card.get("time") or 0,
                        "xsec_token": b.get("xsec_token") or "",
                        "xsec_source": "pc_feed",
                    })
                good = bool(out)
        error = ""
        if not out:   # 回退:创作平台笔记管理(显示用)
            try:
                notes, error = await fetch_creator_published(browser, identity)
            except Exception as exc:
                category, _signal = classify_platform_error(exc)
                if category in {
                        RiskCategory.RISK, RiskCategory.AUTH,
                        RiskCategory.NETWORK}:
                    return _failure(exc)
                raise
            for n in notes[:80]:
                imgs = _imgs_of(n)
                vi = n.get("video_info") or {}
                cover = (imgs[0] if imgs else
                         (vi.get("cover") if isinstance(vi, dict) else ""))
                out.append({
                    "note_id": str(_first_val(n, "id", "noteId", "note_id")),
                    "title": _first_val(
                        n, "display_title", "title", "desc", default="(无标题)"),
                    "type": _first_val(n, "type", "noteType", default="normal"),
                    "cover": cover or "", "images": imgs,
                    "like": _first_val(n, "likes", "likeCount", default=0),
                    "time": _first_val(n, "time", "postTime", default=0),
                    "xsec_token": _first_val(n, "xsec_token", default=""),
                    "xsec_source": _first_val(
                        n, "xsec_source", default="pc_note_detail"),
                })
        if error:
            category, _signal = classify_platform_error(error)
            return _payload(
                out, good, error_category=category.value), error
        return _payload(out, good), ""

    payload, outcome = await _run_account_read(
        account_id, OperationKind.READ_LIGHT, f"published:{account_id}",
        _fetch_published_notes,
        empty_result={"notes": [], "total": 0, "good_tokens": False},
        unexpected_detail="读取已发布作品失败")
    if isinstance(outcome, dict):
        return outcome
    error_category = payload.pop("_error_category", "")
    if error_category == RiskCategory.AUTH.value or "logged_out" in (outcome or ""):
        raise HTTPException(400, "登录态已失效,请对该账号点「重新登录」")
    if error_category in {
            RiskCategory.RISK.value, RiskCategory.NETWORK.value}:
        raise HTTPException(400, f"读取已发布作品失败:{outcome}")
    return payload


@app.get("/api/publish/note-media")
async def publish_note_media(account_id: int, note_id: str,
                             xsec_token: str = "", xsec_source: str = "pc_note_detail"):
    """取一条小红书笔记的完整媒体(图集/视频),供「已发布作品」预览。"""
    from .platforms.xhs import XhsApiClient, XhsApiError, cookie_str_from_state, has_a1, parse_note_detail
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc or acc.platform != "xhs":
            raise HTTPException(400, "账号无效")
        state = acc.storage_state or acc.creator_storage_state or ""
        proxy = acc.proxy or ""
        identity = browser.identity_for(acc) if browser is not None else None
    cookie = cookie_str_from_state(state)
    if not has_a1(cookie):
        raise HTTPException(400, "登录态缺少 a1")

    no_media = "拿不到该笔记的媒体(xsec_token 对 feed 接口无效)"

    async def _fetch_note_media():
        if _xhs_browser_reads_enabled() and identity is not None:
            card, read_error = await fetch_xhs_note_detail(
                browser, identity, note_id,
                xsec_token=xsec_token, xsec_source=xsec_source,
                block_media=cfg.engine.block_media_resources)
            if read_error:
                category, _signal = classify_platform_error(read_error)
                if not card or category in {
                        RiskCategory.RISK, RiskCategory.AUTH,
                        RiskCategory.NETWORK}:
                    return None, read_error
        else:
            client = XhsApiClient(
                cookie,
                (_direct_request_ua(identity)
                 if browser is not None and identity is not None
                 else cfg.engine.user_agent),
                timeout=cfg.engine.request_timeout_seconds, proxy=proxy)
            try:
                card = await client.note_detail(
                    note_id, xsec_token=xsec_token, xsec_source=xsec_source)
            except XhsApiError as exc:
                return None, exc
        aw = parse_note_detail(card or {}, {"note_id": note_id})
        if not aw or not aw.medias:
            return None, no_media
        return {
            "media_type": aw.media_type,
            "desc": aw.desc,
            "cover_url": aw.cover or "",
            "medias": [{
                "url": media.url,
                "kind": media.kind,
                "ext": media.ext,
                "index": media.index,
            } for media in aw.medias],
        }, ""

    payload, outcome = await _run_account_read(
        account_id, OperationKind.READ_HEAVY,
        f"note-media:{account_id}:{note_id}", _fetch_note_media,
        empty_result={
            "media_type": "", "desc": "", "cover_url": "", "medias": []},
        unexpected_detail="取笔记失败")
    if isinstance(outcome, dict):
        return outcome
    if outcome == no_media:
        raise HTTPException(400, no_media)
    if outcome:
        raise HTTPException(400, f"取笔记失败:{outcome}")
    return payload


@app.get("/api/publish/note-comments")
async def publish_note_comments(account_id: int, note_id: str,
                                xsec_token: str = "", xsec_source: str = "pc_note_detail"):
    """拉取一条小红书笔记的评论(一级 + 子评论拍平)。"""
    from .platforms.xhs import (XhsApiClient, XhsApiError, cookie_str_from_state, has_a1,
                      parse_comment as parse_xhs_comment, flatten_comments)
    with get_session() as s:
        acc = s.get(DouyinAccount, account_id)
        if not acc or acc.platform != "xhs":
            raise HTTPException(400, "账号无效")
        state = acc.storage_state or acc.creator_storage_state or ""
        proxy = acc.proxy or ""
        identity = browser.identity_for(acc) if browser is not None else None
    cookie = cookie_str_from_state(state)
    if not has_a1(cookie):
        raise HTTPException(400, "登录态缺少 a1")

    async def _fetch_note_comments():
        if _xhs_browser_reads_enabled() and identity is not None:
            raw, read_error = await fetch_xhs_comments(
                browser, identity, note_id, set(),
                xsec_token=xsec_token, xsec_source=xsec_source,
                max_scrolls=cfg.engine.comment_max_scrolls,
                block_media=cfg.engine.block_media_resources)
            if read_error:
                category, _signal = classify_platform_error(read_error)
                if not raw or category in {
                        RiskCategory.RISK, RiskCategory.AUTH,
                        RiskCategory.NETWORK}:
                    return None, read_error
            parsed = [item for item in
                      (parse_xhs_comment(value)
                       for value in flatten_comments(raw)) if item]
            parsed.sort(
                key=lambda comment: comment.get("create_time") or 0,
                reverse=True)
            return {
                "comments": parsed,
                "total": len(parsed),
                "has_more": False,
            }, ""
        client = XhsApiClient(
            cookie,
            (_direct_request_ua(identity)
             if browser is not None and identity is not None
             else cfg.engine.user_agent),
            timeout=cfg.engine.request_timeout_seconds, proxy=proxy)
        async with client.session_scope():
            # Token refresh and both comment levels share this bounded session.
            tok, src = xsec_token, xsec_source
            try:
                item = await client.note_detail_raw(
                    note_id, xsec_token=xsec_token, xsec_source=xsec_source)
                fresh_token = (item.get("xsec_token") or
                               ((item.get("note_card") or {}).get("xsec_token")))
                if fresh_token:
                    tok, src = fresh_token, "pc_feed"
            except XhsApiError as exc:
                if exc.category in {"risk", "auth", "network"}:
                    return None, exc
            except Exception as exc:
                category, _signal = classify_platform_error(exc)
                if category in {
                        RiskCategory.RISK, RiskCategory.AUTH,
                        RiskCategory.NETWORK}:
                    return None, exc
                raise
            try:
                data = await client.collect_note_comments(
                    note_id, xsec_token=tok, xsec_source=src,
                    max_comments=200,
                    max_requests=max(1, min(20, cfg.engine.comment_max_scrolls)),
                    include_replies=True,
                    request_interval=max(0.5, cfg.engine.xhs_item_gap_seconds))
            except XhsApiError as exc:
                return None, exc
        raw = data.get("comments") or []
        comments = [
            comment for comment in (
                parse_xhs_comment(item) for item in flatten_comments(raw))
            if comment
        ]
        comments.sort(
            key=lambda comment: comment.get("create_time") or 0, reverse=True)
        return {
            "comments": comments,
            "total": len(comments),
            "has_more": bool(data.get("has_more")),
        }, ""

    payload, outcome = await _run_account_read(
        account_id, OperationKind.READ_HEAVY,
        f"note-comments:{account_id}:{note_id}", _fetch_note_comments,
        empty_result={"comments": [], "total": 0, "has_more": False},
        unexpected_detail="取评论失败")
    if isinstance(outcome, dict):
        return outcome
    if outcome:
        raise HTTPException(400, f"取评论失败:{outcome}")
    return payload


class RepostIn(BaseModel):
    account_id: int
    scheduled_at: str | None = None
    # 转发前可编辑的笔记信息;为 None 时沿用作品原始内容
    title: str | None = None
    desc: str | None = None
    topics: str | None = None
    visibility: str = "public"           # 抖音:public | friends | private
    allow_save: bool = True              # 抖音:是否允许他人保存
    media_order: list[StrictInt] | None = None  # 剔除/调序后保留的图片原始序号(按新顺序);None=全部原序


async def _repost_content(cid: int, body: RepostIn, target_platform: str, request: Request = None):
    """把已下载作品转成目标平台(xhs / douyin / shipinhao)的发布任务。"""
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    with get_session() as s:
        def create():
            rec = s.get(ContentRecord, cid)
            if not rec:
                raise HTTPException(404, "作品不存在")
            if rec.download_status != "done":
                raise HTTPException(400, "该作品尚未下载完成,无法转发")
            acc = s.get(DouyinAccount, body.account_id)
            if not acc or acc.platform != target_platform:
                raise HTTPException(400, "请选择与目标平台匹配的已登录账号")
            if target_platform in ("douyin", "shipinhao"):
                if not (acc.creator_storage_state or acc.storage_state):
                    raise HTTPException(400, "请先在账号页完成登录")
            elif not (acc.creator_storage_state or has_creator_cookies(acc.storage_state)):
                raise HTTPException(400, "请先完成小红书扫码登录或创作者登录")
            try:
                tid = engine.create_relay_publish(
                    cid, body.account_id, target_platform=target_platform,
                    title=body.title, desc=body.desc, topics=body.topics,
                    visibility=body.visibility if body.visibility in ("public", "friends", "private") else "public",
                    allow_save=bool(body.allow_save), media_order=body.media_order,
                    scheduled_at=_parse_when(body.scheduled_at, acc.timezone_id), session=s)
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc
            if not tid:
                raise HTTPException(400, "未找到该作品的本地文件,无法转发")
            return {"ok": True, "task_id": tid}
        payload, _ = submit_once(s, request=request, scope=f"repost:{target_platform}:{cid}",
                                 body=body, create=create)
        return payload


@app.post("/api/contents/{cid}/repost-xhs")
async def repost_to_xhs(cid: int, body: RepostIn, request: Request = None):
    """把一条已下载的抖音作品转成小红书发布任务。"""
    return await _repost_content(cid, body, "xhs", request)


@app.post("/api/contents/{cid}/repost-douyin")
async def repost_to_douyin(cid: int, body: RepostIn, request: Request = None):
    """把一条已下载的小红书作品转成抖音发布任务(反向转发)。"""
    return await _repost_content(cid, body, "douyin", request)


@app.post("/api/contents/{cid}/repost-shipinhao")
async def repost_to_channels(cid: int, body: RepostIn, request: Request = None):
    """把一条已下载的抖音作品转成视频号发布任务。"""
    return await _repost_content(cid, body, "shipinhao", request)


# ─────────── 自动评论(规则 + 任务)───────────
class CommentRuleIn(BaseModel):
    platform: str = "douyin"
    name: str = ""
    mode: str = "auto_reply"            # auto_reply | auto_comment
    account_id: int
    target_kind: str = "self"          # reply: self|work ; comment: keyword|creator
    target: str = ""                   # 关键词,或 创作者/作品 的链接/id
    templates: list[str] = []
    use_ai: bool = False
    require_review: bool = False
    reply_filter: str = ""
    skip_keywords: str = ""
    daily_cap: int = 20
    min_gap_seconds: int = 90
    max_per_run: int = 5
    interval_seconds: int = 1800
    enabled: bool = False


class CommentRuleUpdate(BaseModel):
    name: str | None = None
    templates: list[str] | None = None
    use_ai: bool | None = None
    require_review: bool | None = None
    reply_filter: str | None = None
    skip_keywords: str | None = None
    daily_cap: int | None = None
    min_gap_seconds: int | None = None
    max_per_run: int | None = None
    interval_seconds: int | None = None
    enabled: bool | None = None
    # 改目标(任一非空则重新解析)。account_id 可单独改。
    account_id: int | None = None
    mode: str | None = None
    target_kind: str | None = None
    target: str | None = None


def _rule_dict(r: CommentRule) -> dict:
    return {
        "id": r.id, "platform": r.platform, "name": r.name, "mode": r.mode,
        "account_id": r.account_id, "target_kind": r.target_kind,
        "keyword": r.keyword, "sec_uid": r.sec_uid, "aweme_id": r.aweme_id,
        "templates": json.loads(r.templates or "[]"), "use_ai": r.use_ai,
        "require_review": r.require_review,
        "reply_filter": r.reply_filter, "skip_keywords": r.skip_keywords,
        "daily_cap": r.daily_cap, "min_gap_seconds": r.min_gap_seconds,
        "max_per_run": r.max_per_run, "interval_seconds": r.interval_seconds,
        "enabled": r.enabled, "last_error": r.last_error,
        "last_run_at": r.last_run_at.isoformat() if r.last_run_at else None,
        "next_auto_run_at": utc_iso(row_deadline(r, cfg, kind="comment_rule")),
    }


async def _resolve_rule_target(platform: str, mode: str, target_kind: str, target: str):
    """把 mode/target_kind/target 解析成 (kind, sec_uid, aweme_id, keyword, xsec_token)。
    解析失败抛 HTTPException。POST 与 PUT(改目标)共用。"""
    sec_uid = aweme_id = keyword = xsec_token = ""
    if mode == "auto_comment":
        kind = target_kind if target_kind in ("keyword", "creator") else "keyword"
        if kind == "keyword":
            keyword = (target or "").strip()
            if not keyword:
                raise HTTPException(400, "请填写要评论的搜索关键词")
            if platform in ("douyin", "kuaishou"):
                pn = "快手" if platform == "kuaishou" else "抖音"
                raise HTTPException(400, f"{pn}暂不支持关键词发现,请用「创作者」模式")
        else:
            if platform == "xhs":
                ref = await xhs_resolve_user(target, cfg.engine.user_agent)
                if not ref:
                    raise HTTPException(400, "无法解析小红书创作者(主页链接 / xhslink / user_id)")
                sec_uid, xsec_token = ref.user_id, ref.xsec_token
            elif platform == "kuaishou":
                sec_uid = await resolve_ks_user_id(target, cfg.engine.user_agent)
                if not sec_uid:
                    raise HTTPException(400, "无法解析快手创作者(主页链接 / 短链 / user_id)")
            else:
                sec_uid = await resolve_sec_uid(target, cfg.engine.user_agent)
                if not sec_uid:
                    raise HTTPException(400, "无法解析 sec_uid(主页链接 / 短链 / sec_uid)")
    else:
        kind = target_kind if target_kind in ("self", "work") else "self"
        if kind == "work":
            if platform == "xhs":
                ref = await xhs_resolve_note(target, cfg.engine.user_agent)
                if not ref:
                    raise HTTPException(400, "无法解析小红书笔记(explore 链接 / xhslink / note_id)")
                aweme_id, xsec_token = ref.note_id, ref.xsec_token
            elif platform == "kuaishou":
                aweme_id = await resolve_ks_photo_id(target, cfg.engine.user_agent)
                if not aweme_id:
                    raise HTTPException(400, "无法解析快手作品 id(作品链接 / 短链 / photo_id)")
            else:
                aweme_id = await resolve_aweme_id(target, cfg.engine.user_agent)
                if not aweme_id:
                    raise HTTPException(400, "无法解析作品 id(作品链接 / 短链 / 数字 id)")
    return kind, sec_uid, aweme_id, keyword, xsec_token


def _task_dict(t: CommentTask) -> dict:
    return {
        "id": t.id, "platform": t.platform, "rule_id": t.rule_id,
        "account_id": t.account_id, "aweme_id": t.aweme_id,
        "target_comment_id": t.target_comment_id, "target_nick": t.target_nick,
        "target_text": getattr(t, "target_text", ""),
        "content": t.content, "status": t.status, "result": t.result,
        "error": t.error, "method": t.method,
        "scheduled_at": t.scheduled_at.isoformat() if t.scheduled_at else None,
        "next_allowed_at": utc_iso(t.next_allowed_at),
        "blocked_reason": t.blocked_reason,
        "done_at": t.done_at.isoformat() if t.done_at else None,
        "created_at": t.created_at.isoformat() if t.created_at else None,
    }


@app.get("/api/comment-rules")
async def list_comment_rules(platform: str | None = None):
    with get_session() as s:
        q = select(CommentRule)
        if platform:
            q = q.where(CommentRule.platform == platform)
        return [_rule_dict(r) for r in s.exec(q.order_by(CommentRule.id.desc())).all()]


@app.post("/api/comment-rules")
async def add_comment_rule(body: CommentRuleIn, request: Request = None):
    with get_session() as s:
        previous = replay_if_exists(s, request=request, scope="comment-rule", body=body)
        if previous is not None:
            return previous
    platform = body.platform if body.platform in ("douyin", "xhs", "kuaishou") else "douyin"
    mode = body.mode if body.mode in ("auto_reply", "auto_comment") else "auto_reply"
    templates = [t.strip() for t in body.templates if t.strip()]
    if not templates:
        raise HTTPException(400, "请至少配置一条文案模板(AI 生成失败时回退用)")
    _pn = {"xhs": "小红书", "kuaishou": "快手"}.get(platform, "抖音")
    with get_session() as s:
        acc = s.get(DouyinAccount, body.account_id)
        if not acc or acc.platform != platform:
            raise HTTPException(400, f"请选择一个已登录的{_pn}账号")
        if not (acc.storage_state or acc.creator_storage_state):
            raise HTTPException(400, "该账号未登录,发评论需要登录态")

    kind, sec_uid, aweme_id, keyword, xsec_token = await _resolve_rule_target(
        platform, mode, body.target_kind, body.target)

    with get_session() as s:
        def create():
            r = CommentRule(
                platform=platform, name=body.name or ("自动回复" if mode == "auto_reply" else "自动评论"),
                mode=mode, account_id=body.account_id, target_kind=kind,
                keyword=keyword, sec_uid=sec_uid, aweme_id=aweme_id, xsec_token=xsec_token,
                templates=json.dumps(templates, ensure_ascii=False), use_ai=body.use_ai,
                require_review=body.require_review,
                reply_filter=body.reply_filter.strip(), skip_keywords=body.skip_keywords.strip(),
                daily_cap=max(0, body.daily_cap), min_gap_seconds=max(1, body.min_gap_seconds),
                max_per_run=max(1, body.max_per_run),
                interval_seconds=max(60, body.interval_seconds), enabled=body.enabled)
            s.add(r); s.flush()
            return _rule_dict(r)
        payload, _ = submit_once(s, request=request, scope="comment-rule", body=body, create=create)
        return payload


@app.put("/api/comment-rules/{rid}")
async def update_comment_rule(rid: int, body: CommentRuleUpdate):
    with get_session() as s:
        r = s.get(CommentRule, rid)
        if not r:
            raise HTTPException(404)
        platform = r.platform

    # 改账号:校验平台一致 + 已登录
    if body.account_id is not None:
        with get_session() as s:
            acc = s.get(DouyinAccount, body.account_id)
            if not acc or acc.platform != platform:
                raise HTTPException(400, "账号无效或与规则平台不一致")
            if not (acc.storage_state or acc.creator_storage_state):
                raise HTTPException(400, "该账号未登录,发评论需要登录态")

    # 改目标:mode/target_kind/target 任一传入则整体重解析
    new_target = None
    if body.mode is not None or body.target_kind is not None or body.target is not None:
        with get_session() as s:
            r = s.get(CommentRule, rid)
            mode = body.mode if body.mode in ("auto_reply", "auto_comment") else r.mode
            tk = body.target_kind if body.target_kind is not None else r.target_kind
            tgt = body.target if body.target is not None else ""
        new_target = (mode, *await _resolve_rule_target(platform, mode, tk, tgt))

    with get_session() as s:
        r = s.get(CommentRule, rid)
        if not r:
            raise HTTPException(404)
        if body.account_id is not None:
            r.account_id = body.account_id
        if new_target is not None:
            r.mode, r.target_kind, r.sec_uid, r.aweme_id, r.keyword, r.xsec_token = new_target
        if body.name is not None:
            r.name = body.name
        if body.templates is not None:
            tps = [t.strip() for t in body.templates if t.strip()]
            if not tps:
                raise HTTPException(400, "文案模板不能为空")
            r.templates = json.dumps(tps, ensure_ascii=False)
        if body.use_ai is not None:
            r.use_ai = body.use_ai
        if body.require_review is not None:
            r.require_review = body.require_review
        if body.reply_filter is not None:
            r.reply_filter = body.reply_filter.strip()
        if body.skip_keywords is not None:
            r.skip_keywords = body.skip_keywords.strip()
        if body.daily_cap is not None:
            r.daily_cap = max(0, body.daily_cap)
        if body.min_gap_seconds is not None:
            r.min_gap_seconds = max(1, body.min_gap_seconds)
        if body.max_per_run is not None:
            r.max_per_run = max(1, body.max_per_run)
        if body.interval_seconds is not None:
            r.interval_seconds = max(60, body.interval_seconds)
        if body.enabled is not None:
            r.enabled = body.enabled
        s.add(r); s.commit(); s.refresh(r)
        return _rule_dict(r)


@app.delete("/api/comment-rules/{rid}")
async def del_comment_rule(rid: int, with_tasks: bool = True):
    with get_session() as s:
        r = s.get(CommentRule, rid)
        if not r:
            return {"ok": True}
        if with_tasks:
            for t in s.exec(select(CommentTask).where(CommentTask.rule_id == rid)).all():
                s.delete(t)
        s.delete(r); s.commit()
    return {"ok": True}


@app.post("/api/comment-rules/{rid}/run-now")
async def run_comment_rule_now(rid: int):
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    return await engine.run_comment_rule(rid)


@app.get("/api/comment-tasks")
async def list_comment_tasks(platform: str | None = None, rule_id: int | None = None,
                             status: str | None = None, limit: int = 200):
    with get_session() as s:
        q = select(CommentTask)
        if platform:
            q = q.where(CommentTask.platform == platform)
        if rule_id is not None:
            q = q.where(CommentTask.rule_id == rule_id)
        if status:
            q = q.where(CommentTask.status == status)
        rows = s.exec(q.order_by(CommentTask.id.desc()).limit(limit)).all()
        return [_task_dict(t) for t in rows]


@app.post("/api/comment-tasks/{tid}/run-now")
async def run_comment_task_now(tid: int):
    if not engine:
        raise HTTPException(503, "引擎未就绪")
    with get_session() as s:
        t = s.get(CommentTask, tid)
        if not t:
            raise HTTPException(404)
        if t.status not in ("pending", "failed"):
            raise HTTPException(400, f"任务状态为 {t.status}")
        t.status = "pending"; t.scheduled_at = None; t.error = ""
        s.add(t); s.commit()
    return await engine.execute_comment_task(tid)


@app.post("/api/comment-tasks/{tid}/cancel")
async def cancel_comment_task(tid: int):
    with get_session() as s:
        t = s.get(CommentTask, tid)
        if not t:
            raise HTTPException(404)
        if t.status in ("draft", "pending", "failed"):
            t.status = "canceled"
            s.add(t); s.commit()
    return {"ok": True}


class IdsIn2(BaseModel):
    ids: list[int] = []


class TaskContentIn(BaseModel):
    content: str


@app.put("/api/comment-tasks/{tid}")
async def edit_comment_task(tid: int, body: TaskContentIn):
    """编辑草稿/待发任务的文案(草稿审核时人工微调用)。"""
    content = (body.content or "").strip()
    if not content:
        raise HTTPException(400, "文案不能为空")
    with get_session() as s:
        t = s.get(CommentTask, tid)
        if not t:
            raise HTTPException(404)
        if t.status not in ("draft", "pending", "failed"):
            raise HTTPException(400, f"任务状态为 {t.status},不可编辑")
        t.content = content[:200]
        s.add(t); s.commit(); s.refresh(t)
        return _task_dict(t)


def _approve_one(s, t) -> bool:
    """把 draft 任务转为 pending(通过审核)。返回是否改动。"""
    if t and t.status == "draft":
        # Approval changes review state, not the generated spacing/appointment.
        t.status = "pending"; t.error = ""
        s.add(t)
        return True
    return False


@app.post("/api/comment-tasks/{tid}/approve")
async def approve_comment_task(tid: int):
    """通过单条草稿:draft -> pending,引擎随后按节流自动发出。"""
    with get_session() as s:
        t = s.get(CommentTask, tid)
        if not t:
            raise HTTPException(404)
        if not _approve_one(s, t):
            raise HTTPException(400, f"任务状态为 {t.status},非草稿")
        s.commit()
    return {"ok": True}


class CommentBatchApproveIn(BaseModel):
    ids: list[int] = PydanticField(default_factory=list, max_length=500)
    platform: str
    account_id: int | None = None


@app.post("/api/comment-tasks/batch-approve")
async def batch_approve_comment_tasks(body: CommentBatchApproveIn):
    """Only approve an explicit, scope-checked selection, atomically."""
    if body.platform not in {"douyin", "xhs", "kuaishou", "shipinhao"}:
        raise HTTPException(422, "平台类型无效")
    ids = list(dict.fromkeys(body.ids))
    if not ids or any(value <= 0 for value in ids):
        raise HTTPException(422, "请选择明确的草稿 ID；空列表不会审核任何任务")
    n = 0
    with get_session() as s:
        rows = s.exec(select(CommentTask).where(CommentTask.id.in_(ids))).all()
        if len(rows) != len(ids) or any(
                t.status != "draft" or t.platform != body.platform
                or (body.account_id is not None and t.account_id != body.account_id)
                for t in rows):
            raise HTTPException(409, "所选草稿的状态或平台/账号范围已变化，本批次未审核，请刷新后重选")
        for t in rows:
            if _approve_one(s, t):
                n += 1
        s.commit()
    return {"ok": True, "approved": n}


@app.delete("/api/comment-tasks/{tid}")
async def del_comment_task(tid: int):
    with get_session() as s:
        t = s.get(CommentTask, tid)
        if t:
            if t.status in ("doing", "uncertain"):
                raise HTTPException(409, "任务正在执行或结果待核对，请先确认平台结果")
            s.delete(t); s.commit()
    return {"ok": True}


@app.post("/api/comment-tasks/batch-delete")
async def batch_del_comment_tasks(body: IdsIn2):
    n = 0
    with get_session() as s:
        for tid in body.ids:
            t = s.get(CommentTask, tid)
            if t:
                if t.status in ("doing", "uncertain"):
                    raise HTTPException(409, f"任务 #{tid} 正在执行或结果待核对，本批次未删除")
                s.delete(t); n += 1
        s.commit()
    return {"ok": True, "deleted": n}


# ─────────── 统一运营工作台 / 事件中心 ───────────
@app.get("/api/account-operations")
async def list_account_operations(account_id: int | None = None,
                                  platform: str = "", task_type: str = "",
                                  limit: int = 200):
    limit = max(1, min(int(limit or 200), 1000))
    with get_session() as session:
        stmt = select(AccountOperationLog)
        if account_id is not None:
            stmt = stmt.where(AccountOperationLog.account_id == account_id)
        if platform:
            stmt = stmt.where(AccountOperationLog.platform == platform)
        if task_type:
            stmt = stmt.where(AccountOperationLog.task_type == task_type)
        rows = session.exec(stmt.order_by(
            AccountOperationLog.created_at.desc()).limit(limit)).all()
    return [{
        "id": row.id, "platform": row.platform, "account_id": row.account_id,
        "task_type": row.task_type, "task_id": row.task_id,
        "action": row.action, "target": row.target, "channel": row.channel,
        "status": row.status, "risk_signal": row.risk_signal,
        "detail": row.detail, "duration_ms": row.duration_ms,
        "created_at": _queue_iso(row.created_at),
    } for row in rows]


@app.get("/api/accounts/workbench")
async def accounts_workbench(platform: str = ""):
    with get_session() as session:
        stmt = select(DouyinAccount)
        if platform:
            stmt = stmt.where(DouyinAccount.platform == platform)
        accounts = session.exec(stmt.order_by(DouyinAccount.id)).all()
        account_ids = [account.id for account in accounts]
        rollups = {account_id: {
            "total": 0, "pending": 0, "running": 0,
            "blocked": 0, "failed": 0} for account_id in account_ids}
        task_specs = (
            (KeywordCollectionJob, {"pending"}, {"running"}),
            (PublishTask, {"draft", "pending"}, {"publishing"}),
            (CommentTask, {"draft", "pending"}, {"doing"}),
            (AccountActionTask, {"draft", "pending"}, {"doing"}),
        )
        for model, pending_states, running_states in task_specs:
            rows = session.exec(select(model).where(
                model.account_id.in_(account_ids),
                model.status.in_(list(pending_states | running_states | _QUEUE_FAILED)))).all()
            for row in rows:
                value = rollups[row.account_id]
                value["total"] += 1
                if row.status in _QUEUE_FAILED:
                    value["failed"] += 1
                elif (getattr(row, "blocked_reason", "")
                      or (getattr(row, "next_allowed_at", None)
                          and row.next_allowed_at > datetime.utcnow())):
                    value["blocked"] += 1
                elif row.status in running_states:
                    value["running"] += 1
                else:
                    value["pending"] += 1
        latest: dict[int, AccountOperationLog] = {}
        for row in session.exec(select(AccountOperationLog).order_by(
                AccountOperationLog.created_at.desc()).limit(2000)).all():
            latest.setdefault(row.account_id, row)
        unread = {account.id: int(session.exec(select(func.sum(
            DmConversation.unread_count)).where(
                DmConversation.account_id == account.id)).one() or 0)
                  for account in accounts}
    open_ids = set(_active_open_browser_account_ids())
    return [{
        "account_id": account.id, "platform": account.platform,
        "nickname": account.nickname, "avatar": account.avatar,
        "status": account.status, "proxy_status": account.proxy_status,
        "browser_open": account.id in open_ids,
        "unread_dm": unread.get(account.id, 0),
        "tasks": rollups.get(account.id, {
            "total": 0, "pending": 0, "running": 0, "blocked": 0, "failed": 0}),
        "last_operation": ({
            "action": latest[account.id].action,
            "status": latest[account.id].status,
            "detail": latest[account.id].detail,
            "created_at": _queue_iso(latest[account.id].created_at),
        } if account.id in latest else None),
    } for account in accounts]


@app.get("/api/dm/inbox")
async def aggregate_dm_inbox(platform: str = "", unread_only: bool = False,
                             limit: int = 200):
    with get_session() as session:
        stmt = select(DmConversation)
        if platform:
            stmt = stmt.where(DmConversation.platform == platform)
        if unread_only:
            stmt = stmt.where(DmConversation.unread_count > 0)
        rows = session.exec(stmt.order_by(
            DmConversation.last_time.desc()).limit(max(1, min(limit, 1000)))).all()
        accounts = {row.id: row for row in session.exec(select(DouyinAccount)).all()}
    items = []
    for row in rows:
        try:
            raw = json.loads(row.raw_json or "{}")
        except (TypeError, ValueError):
            raw = {}
        account = accounts.get(row.account_id)
        items.append({
            "id": row.id, "platform": row.platform, "account_id": row.account_id,
            "account_name": account.nickname if account else "",
            "conv_id": row.conv_id, "peer_uid": row.peer_uid,
            "peer_nickname": row.peer_nickname, "peer_avatar": row.peer_avatar,
            "last_text": row.last_text, "last_time": row.last_time,
            "unread_count": row.unread_count,
            "group_chat": bool(raw.get("group_chat") or raw.get("conversation_type") == "group"),
        })
    return {"items": items, "unread": sum(item["unread_count"] for item in items)}


class GroupMemberIn(BaseModel):
    member_id: str = ""
    user_id: str = ""
    uid: str = ""
    nickname: str = ""
    avatar: str = ""
    role: str = "member"


class GroupSnapshotIn(BaseModel):
    platform: str
    account_id: int
    group_id: str
    group_name: str = ""
    members: list[GroupMemberIn] = PydanticField(default_factory=list)


@app.post("/api/group-snapshots")
async def create_group_snapshot(body: GroupSnapshotIn):
    platform = body.platform.strip().lower()
    group_id = body.group_id.strip()
    if platform not in {"douyin", "xhs", "kuaishou"} or not group_id:
        raise HTTPException(422, "平台或群 ID 无效")
    with get_session() as session:
        account = session.get(DouyinAccount, body.account_id)
        if not account or account.platform != platform:
            raise HTTPException(400, "账号不存在或与平台不匹配")
    try:
        result = ingest_group_snapshot(
            platform=platform, account_id=body.account_id,
            group_id=group_id, group_name=body.group_name.strip(),
            members=[value.model_dump() for value in body.members])
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    record_account_operation(
        platform=platform, account_id=body.account_id,
        task_type="group_snapshot", task_id=result["snapshot_id"],
        action="snapshot", status="done", target=body.group_name or group_id,
        channel="api", detail=(f"成员 {result['member_count']}，新增 {len(result['joined'])}，"
                               f"退出 {len(result['left'])}，变化 {len(result['changed'])}"))
    return result


@app.get("/api/groups")
async def list_groups(account_id: int | None = None, platform: str = ""):
    with get_session() as session:
        stmt = select(GroupConversation)
        if account_id is not None:
            stmt = stmt.where(GroupConversation.account_id == account_id)
        if platform:
            stmt = stmt.where(GroupConversation.platform == platform)
        rows = session.exec(stmt.order_by(GroupConversation.last_snapshot_at.desc())).all()
    return [{"id": row.id, "platform": row.platform, "account_id": row.account_id,
             "group_id": row.group_id, "name": row.name,
             "member_count": row.member_count,
             "last_snapshot_at": _queue_iso(row.last_snapshot_at)} for row in rows]


@app.get("/api/groups/{group_id}/members")
async def list_group_members(group_id: str, account_id: int,
                             active_only: bool = True):
    with get_session() as session:
        stmt = select(GroupMember).where(
            GroupMember.group_id == group_id,
            GroupMember.account_id == account_id)
        if active_only:
            stmt = stmt.where(GroupMember.active == True)  # noqa:E712
        rows = session.exec(stmt.order_by(GroupMember.nickname, GroupMember.member_id)).all()
    return [{"member_id": row.member_id, "nickname": row.nickname,
             "avatar": row.avatar, "role": row.role, "active": row.active,
             "first_seen_at": _queue_iso(row.first_seen_at),
             "last_seen_at": _queue_iso(row.last_seen_at),
             "left_at": _queue_iso(row.left_at)} for row in rows]


@app.get("/api/groups/{group_id}/events")
async def list_group_member_events(group_id: str, account_id: int, limit: int = 200):
    with get_session() as session:
        rows = session.exec(select(GroupMemberEvent).where(
            GroupMemberEvent.group_id == group_id,
            GroupMemberEvent.account_id == account_id).order_by(
                GroupMemberEvent.created_at.desc()).limit(max(1, min(limit, 1000)))).all()
    return [{"id": row.id, "snapshot_id": row.snapshot_id,
             "member_id": row.member_id, "change_type": row.change_type,
             "before": json.loads(row.before_json or "{}"),
             "after": json.loads(row.after_json or "{}"),
             "created_at": _queue_iso(row.created_at)} for row in rows]


class LiveLeadIn(BaseModel):
    platform: str = "douyin"
    account_id: int
    room_id: str
    user_id: str
    nickname: str = ""
    source_event: str = "comment"
    content: str = ""
    tags: list[str] = PydanticField(default_factory=list)
    score: int = 0
    occurred_at: datetime | None = None


class LiveLeadUpdate(BaseModel):
    status: str | None = None
    assignee: str | None = None
    note: str | None = None
    tags: list[str] | None = None
    score: int | None = None


@app.post("/api/live-leads")
async def create_live_lead(body: LiveLeadIn):
    if not body.room_id.strip() or not body.user_id.strip():
        raise HTTPException(422, "直播间 ID 和用户 ID 必填")
    with get_session() as session:
        account = session.get(DouyinAccount, body.account_id)
        if not account or account.platform != body.platform:
            raise HTTPException(400, "账号不存在或与平台不匹配")
        row = LiveLead(
            platform=body.platform, account_id=body.account_id,
            room_id=body.room_id.strip(), user_id=body.user_id.strip(),
            nickname=body.nickname.strip(), source_event=body.source_event.strip(),
            content=body.content.strip(),
            tags=json.dumps(_collection_keywords(body.tags), ensure_ascii=False),
            score=max(0, min(int(body.score or 0), 100)),
            occurred_at=body.occurred_at)
        session.add(row); session.commit(); session.refresh(row)
        lead_id = row.id
    emit_event("live.lead.created", {"lead_id": lead_id, **body.model_dump(mode="json")},
               aggregate_type="live_lead", aggregate_id=str(lead_id))
    return {"id": lead_id, "status": "new"}


@app.get("/api/live-leads")
async def list_live_leads(platform: str = "", account_id: int | None = None,
                          status: str = "", limit: int = 200):
    with get_session() as session:
        stmt = select(LiveLead)
        if platform:
            stmt = stmt.where(LiveLead.platform == platform)
        if account_id is not None:
            stmt = stmt.where(LiveLead.account_id == account_id)
        if status:
            stmt = stmt.where(LiveLead.status == status)
        rows = session.exec(stmt.order_by(
            LiveLead.created_at.desc()).limit(max(1, min(limit, 1000)))).all()
    return [{"id": row.id, "platform": row.platform, "account_id": row.account_id,
             "room_id": row.room_id, "user_id": row.user_id,
             "nickname": row.nickname, "source_event": row.source_event,
             "content": row.content, "tags": json.loads(row.tags or "[]"),
             "score": row.score, "status": row.status, "assignee": row.assignee,
             "note": row.note, "occurred_at": _queue_iso(row.occurred_at),
             "updated_at": _queue_iso(row.updated_at)} for row in rows]


@app.patch("/api/live-leads/{lead_id}")
async def update_live_lead(lead_id: int, body: LiveLeadUpdate):
    with get_session() as session:
        row = session.get(LiveLead, lead_id)
        if not row:
            raise HTTPException(404, "直播线索不存在")
        if body.status is not None:
            if body.status not in {"new", "following", "won", "lost"}:
                raise HTTPException(422, "线索状态无效")
            row.status = body.status
        if body.assignee is not None:
            row.assignee = body.assignee.strip()[:120]
        if body.note is not None:
            row.note = body.note.strip()[:2000]
        if body.tags is not None:
            row.tags = json.dumps(_collection_keywords(body.tags), ensure_ascii=False)
        if body.score is not None:
            row.score = max(0, min(int(body.score), 100))
        row.updated_at = datetime.utcnow()
        session.add(row); session.commit(); session.refresh(row)
        status = row.status
    emit_event("live.lead.updated", {"lead_id": lead_id, "status": status},
               aggregate_type="live_lead", aggregate_id=str(lead_id))
    return {"ok": True, "id": lead_id, "status": status}


@app.get("/api/browser-grid")
async def browser_grid():
    open_ids = set(_active_open_browser_account_ids())
    with get_session() as session:
        accounts = session.exec(select(DouyinAccount).order_by(DouyinAccount.id)).all()
        running = {row.account_id for row in session.exec(select(KeywordCollectionJob).where(
            KeywordCollectionJob.status == "running")).all()}
    return [{"account_id": row.id, "platform": row.platform,
             "nickname": row.nickname, "avatar": row.avatar,
             "account_status": row.status, "proxy_status": row.proxy_status,
             "browser_status": ("open" if row.id in open_ids else
                                "worker" if row.id in running else "closed"),
             "open_url": f"/api/accounts/{row.id}/open-browser"} for row in accounts]


class BatchStopItem(BaseModel):
    queue_type: str
    id: int


class BatchStopIn(BaseModel):
    items: list[BatchStopItem] = PydanticField(default_factory=list)
    account_ids: list[int] = PydanticField(default_factory=list)
    platform: str = ""


@app.post("/api/task-queue/batch-stop")
async def batch_stop_tasks(body: BatchStopIn):
    specs = {"collections": KeywordCollectionJob, "publishes": PublishTask,
             "comments": CommentTask, "actions": AccountActionTask}
    requested = {(item.queue_type, item.id) for item in body.items}
    stopped: list[dict] = []
    skipped: list[dict] = []
    with get_session() as session:
        candidates = []
        if requested:
            for queue_type, task_id in requested:
                model = specs.get(queue_type)
                row = session.get(model, task_id) if model else None
                candidates.append((queue_type, row, task_id))
        else:
            if not body.account_ids and not body.platform:
                raise HTTPException(422, "请选择任务，或指定账号/平台范围")
            for queue_type, model in specs.items():
                stmt = select(model)
                if body.account_ids:
                    stmt = stmt.where(model.account_id.in_(body.account_ids))
                if body.platform:
                    stmt = stmt.where(model.platform == body.platform)
                for row in session.exec(stmt).all():
                    candidates.append((queue_type, row, row.id))
        for queue_type, row, task_id in candidates:
            if row is None:
                skipped.append({"queue_type": queue_type, "id": task_id,
                                "reason": "任务不存在"})
                continue
            if queue_type == "collections" and row.status == "running":
                row.cancel_requested = True
                row.current_step = "正在安全停止"
            elif row.status in {"pending", "draft", "failed", "partial"}:
                row.status = "canceled"
                if hasattr(row, "cancel_requested"):
                    row.cancel_requested = True
                if hasattr(row, "current_step"):
                    row.current_step = "已取消"
                if hasattr(row, "scheduled_at"):
                    row.scheduled_at = None
                if hasattr(row, "finished_at"):
                    row.finished_at = datetime.utcnow()
            else:
                skipped.append({"queue_type": queue_type, "id": task_id,
                                "reason": f"状态 {row.status} 不支持安全停止"})
                continue
            session.add(row)
            stopped.append({"queue_type": queue_type, "id": task_id,
                            "account_id": row.account_id, "platform": row.platform,
                            "status": row.status})
        session.commit()
    for item in stopped:
        record_account_operation(
            platform=item["platform"], account_id=item["account_id"],
            task_type=item["queue_type"], task_id=item["id"],
            action="batch_stop", status=item["status"], channel="api")
    return {"ok": True, "stopped": stopped, "skipped": skipped,
            "stopped_count": len(stopped), "skipped_count": len(skipped)}


class WebhookSubscriptionIn(BaseModel):
    name: str = ""
    url: str
    secret: str = ""
    event_types: list[str] = PydanticField(default_factory=lambda: ["*"])
    enabled: bool = True


class WebhookSubscriptionUpdate(BaseModel):
    name: str | None = None
    url: str | None = None
    secret: str | None = None
    event_types: list[str] | None = None
    enabled: bool | None = None


def _validate_webhook_url(value: str) -> str:
    value = value.strip()
    try:
        parsed = urlsplit(value)
    except ValueError as exc:
        raise HTTPException(422, "Webhook URL 无效") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(422, "Webhook URL 必须是完整的 HTTP(S) 地址")
    if parsed.username or parsed.password or len(value) > 2000:
        raise HTTPException(422, "Webhook URL 不能包含账号密码且长度须合理")
    return value


def _webhook_subscription_dict(row: WebhookSubscription) -> dict:
    return {"id": row.id, "name": row.name, "url": row.url,
            "secret_configured": bool(row.secret),
            "event_types": json.loads(row.event_types or "[]"),
            "enabled": row.enabled, "created_at": _queue_iso(row.created_at),
            "updated_at": _queue_iso(row.updated_at)}


@app.get("/api/webhooks")
async def list_webhooks():
    with get_session() as session:
        rows = session.exec(select(WebhookSubscription).order_by(
            WebhookSubscription.created_at.desc())).all()
    return [_webhook_subscription_dict(row) for row in rows]


@app.post("/api/webhooks")
async def create_webhook(body: WebhookSubscriptionIn):
    with get_session() as session:
        row = WebhookSubscription(
            name=body.name.strip() or "Webhook", url=_validate_webhook_url(body.url),
            secret=body.secret, event_types=json.dumps(
                _collection_keywords(body.event_types) or ["*"]), enabled=body.enabled)
        session.add(row); session.commit(); session.refresh(row)
        return _webhook_subscription_dict(row)


@app.patch("/api/webhooks/{webhook_id}")
async def update_webhook(webhook_id: int, body: WebhookSubscriptionUpdate):
    with get_session() as session:
        row = session.get(WebhookSubscription, webhook_id)
        if not row:
            raise HTTPException(404, "Webhook 不存在")
        if body.name is not None:
            row.name = body.name.strip()[:120]
        if body.url is not None:
            row.url = _validate_webhook_url(body.url)
        if body.secret is not None:
            row.secret = body.secret
        if body.event_types is not None:
            row.event_types = json.dumps(_collection_keywords(body.event_types) or ["*"])
        if body.enabled is not None:
            row.enabled = body.enabled
        row.updated_at = datetime.utcnow()
        session.add(row); session.commit(); session.refresh(row)
        return _webhook_subscription_dict(row)


@app.delete("/api/webhooks/{webhook_id}")
async def delete_webhook(webhook_id: int):
    with get_session() as session:
        row = session.get(WebhookSubscription, webhook_id)
        if row:
            session.delete(row); session.commit()
    return {"ok": True}


@app.get("/api/webhook-events")
async def list_webhook_events(status: str = "", limit: int = 200):
    with get_session() as session:
        stmt = select(WebhookEvent)
        if status:
            stmt = stmt.where(WebhookEvent.status == status)
        rows = session.exec(stmt.order_by(
            WebhookEvent.created_at.desc()).limit(max(1, min(limit, 1000)))).all()
    return [{"id": row.id, "event_type": row.event_type,
             "aggregate_type": row.aggregate_type, "aggregate_id": row.aggregate_id,
             "payload": json.loads(row.payload_json or "{}"), "status": row.status,
             "attempts": row.attempts, "delivered_count": row.delivered_count,
             "last_error": row.last_error, "created_at": _queue_iso(row.created_at),
             "delivered_at": _queue_iso(row.delivered_at)} for row in rows]


@app.post("/api/webhook-events/{event_id}/dispatch")
async def dispatch_webhook_event(event_id: int):
    result = await dispatch_event(event_id)
    if not result.get("ok") and result.get("error") == "事件不存在":
        raise HTTPException(404, result["error"])
    return result


@app.post("/api/webhook-events/dispatch-pending")
async def dispatch_pending_webhook_events(limit: int = 20):
    results = await dispatch_pending(limit)
    return {"ok": all(value.get("ok") for value in results), "results": results}


# ─────────── 通知渠道 ───────────
class ChannelIn(BaseModel):
    name: str = ""
    type: str
    config: Dict[str, Any] = {}
    enabled: bool = True


class ChannelUpdate(BaseModel):
    name: str | None = None
    config: Dict[str, Any] | None = None
    enabled: bool | None = None


def _channel_dict(c: NotificationChannel) -> dict:
    config = parse_config(c.config)
    return {"id": c.id, "name": c.name, "type": c.type,
            "enabled": c.enabled, "config": redact_config(c.type, config)}


@app.get("/api/notifications")
async def list_channels():
    with get_session() as s:
        return [_channel_dict(c) for c in s.exec(select(NotificationChannel)).all()]


@app.post("/api/notifications")
async def add_channel(body: ChannelIn):
    if body.type not in CHANNEL_TYPES:
        raise HTTPException(400, f"渠道类型须为 {CHANNEL_TYPES}")
    with get_session() as s:
        c = NotificationChannel(name=body.name or body.type, type=body.type,
                                config=json.dumps(merge_config({}, body.config)), enabled=body.enabled)
        s.add(c); s.commit(); s.refresh(c)
        return _channel_dict(c)


@app.put("/api/notifications/{cid}")
async def update_channel(cid: int, body: ChannelUpdate):
    with get_session() as s:
        c = s.get(NotificationChannel, cid)
        if not c:
            raise HTTPException(404)
        if body.name is not None:
            c.name = body.name
        if body.config is not None:
            c.config = json.dumps(merge_config(parse_config(c.config), body.config))
        if body.enabled is not None:
            c.enabled = body.enabled
        s.add(c); s.commit(); s.refresh(c)
        return _channel_dict(c)


@app.delete("/api/notifications/{cid}")
async def del_channel(cid: int):
    with get_session() as s:
        c = s.get(NotificationChannel, cid)
        if c:
            s.delete(c); s.commit()
    return {"ok": True}


@app.post("/api/notifications/{cid}/test")
async def test_channel(cid: int):
    with get_session() as s:
        c = s.get(NotificationChannel, cid)
        if not c:
            raise HTTPException(404)
        ch_type, cfg = c.type, json.loads(c.config or "{}")
    ok, detail = await send_one(ch_type, cfg, "CreatorHub · 测试通知",
                                "这是一条测试消息,收到说明渠道配置正常 ✓")
    return {"ok": ok, "detail": redact_detail(ch_type, cfg, detail)}


# ─────────── 前端 ───────────
@app.get("/", response_class=HTMLResponse)
async def index():
    html = (WEB_DIR / "index.html").read_text(encoding="utf-8")
    if os.environ.get("CREATORHUB_DESKTOP") == "1":
        html = html.replace('data-guide-base="https://3441293738.github.io/creatorhub/guide/"',
                            'data-guide-base="/guide/"')
    # Version all local UI assets, including pre-paint appearance boot and CSS.
    try:
        for asset in ("app.js", "submissions.js", "appearance.js", "appearance.css", "workspace-ui.js", "workbench.js", "workbench.css"):
            ver = int((WEB_DIR / asset).stat().st_mtime)
            html = html.replace(f"/static/{asset}", f"/static/{asset}?v={ver}")
    except Exception:
        pass
    # 首页(含内联 CSS)禁缓存:否则 webview 缓存旧 HTML,改了样式也不生效
    return HTMLResponse(html, headers={
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache", "Expires": "0"})


app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")


@app.get("/health")
async def health():
    return {"status": "ok"}
