import unittest
from copy import deepcopy
from datetime import datetime, timezone, timedelta
from incremental_handoff_adapter import propose_page, check_model_candidate

SCOPE={'tenant':'synthetic-company','account':'synthetic-account','task':'synthetic-task'}
def row(ident,content='正在找两居室',at=1792635600000):
    return {'id':ident,'content':content,'create_time':at,'user_info':{'user_id':'same-synthetic-author'},'extra':'retained'}
def page(rows,scope=None):
    return {'scope':deepcopy(scope or SCOPE),'note_id':'synthetic-note','comments':rows,
            'next_cursor':'synthetic-next','has_more':True}
def key(ident):return ('synthetic-company','synthetic-account','xiaohongshu',ident)

class IncrementalHandoffTests(unittest.TestCase):
    def test_existing_comment_remains_linked_and_new_comments_not_deduped_by_author(self):
        known={key('old'):row('old')}; manual={key('new1'):'human-confirmed-grade'}
        input_page=page([row('old'),row('new1'),row('new1'),row('new2')]); snapshot=deepcopy(input_page)
        result=propose_page(input_page,SCOPE,known,manual)
        self.assertEqual(len(result['new_raw_comments']),2)
        self.assertEqual(len(result['task_links']),3)
        self.assertEqual(len(result['analysis_candidates']),2)
        self.assertEqual(result['manual_grades_unchanged'],manual)
        self.assertTrue(result['analysis_candidates'][0]['manual_override_active'])
        self.assertEqual(input_page,snapshot)
        self.assertEqual(result['new_raw_comments'][0]['raw']['extra'],'retained')
    def test_wrong_account_page_rejected_before_proposal(self):
        wrong={**SCOPE,'account':'another-synthetic-account'}
        with self.assertRaises(ValueError):propose_page(page([row('a')],wrong),SCOPE,{}, {})
    def test_empty_scope_rejected(self):
        with self.assertRaises(ValueError):propose_page(page([]),{}, {}, {})
    def test_conflicting_comment_content_is_held_without_overwriting(self):
        known={key('old'):row('old','original')}
        result=propose_page(page([row('old','changed')]),SCOPE,known,{})
        self.assertTrue(result['page_requires_review'])
        self.assertEqual(known[key('old')]['content'],'original')
        self.assertEqual(result['new_raw_comments'],[])
        self.assertFalse(result['checkpoint_committed'])
    def test_unresolvable_row_preserved_in_review_bucket(self):
        raw={'content':'没有稳定编号的原始评论','create_time':None}
        result=propose_page(page([raw]),SCOPE,{}, {})
        self.assertEqual(result['unresolved_rows'],[raw])
        self.assertTrue(result['page_requires_review'])
    def test_exact_timestamp_window_and_unknown_time_do_not_fabricate_freshness(self):
        since=datetime(2026,10,22,1,0,tzinfo=timezone.utc)
        rows=[row('fresh',at=1792631700000),row('old',at=1792629900000),row('unknown',at=None)]
        result=propose_page(page(rows),SCOPE,{}, {},since=since)
        self.assertEqual(len(result['new_raw_comments']),3)
        self.assertEqual([r['comment_key'][-1] for r in result['analysis_candidates']],['fresh'])
    def test_naive_time_filter_rejected(self):
        with self.assertRaises(ValueError):propose_page(page([]),SCOPE,{}, {},since=datetime(2026,10,22))
    def test_bad_model_result_not_projected_to_no_intent_and_raw_survives(self):
        result=check_model_candidate({},'客户的原始需求')
        self.assertEqual(result['state'],'analysis_failed')
        self.assertTrue(result['raw_comment_retained'])
        self.assertFalse(result['accepted'])
    def test_invented_evidence_rejected_and_literal_evidence_accepted(self):
        self.assertFalse(check_model_candidate({'status':'intent','evidence':'预算一万'},'正在找两居室')['accepted'])
        self.assertTrue(check_model_candidate({'status':'intent','evidence':'两居室'},'正在找两居室')['accepted'])

if __name__=='__main__':unittest.main(verbosity=2)
