"""抖音 / 小红书关键词批量采集流水线。"""
from __future__ import annotations

import asyncio
import json
import math
import random
import time
from pathlib import Path

from sqlalchemy import func
from sqlmodel import select

from ..browser import (
    fetch_comments,
    fetch_douyin_search,
    fetch_videos,
    fetch_xhs_comments,
    fetch_xhs_favorites,
    fetch_xhs_note_detail,
    fetch_xhs_notes,
    fetch_xhs_search,
)
from ..db import get_session
from ..models import (
    KeywordCollectionComment,
    KeywordCollectionContent,
    KeywordCollectionJob,
)
from ..platforms.douyin import (
    DouyinClient,
    cookie_from_state as douyin_cookie_from_state,
    parse_aweme,
    parse_comment,
    safe_title,
)
from ..platforms.douyin.extract import Aweme
from ..platforms.xhs import (
    XhsApiClient,
    cookie_str_from_state,
    flatten_comments as flatten_xhs_comments,
    has_a1,
    parse_comment as parse_xhs_comment,
    parse_note_brief,
    parse_note_detail,
)
from ..risk import classify_platform_error, RiskCategory
from ..transport_matrix import douyin_client_environment


def _loads_keywords(raw: str) -> list[str]:
    try:
        values = json.loads(raw or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    return [str(value).strip() for value in values if str(value).strip()]


def _media_json(aweme: Aweme) -> str:
    return json.dumps([
        {"url": media.url, "kind": media.kind, "ext": media.ext,
         "index": media.index}
        for media in aweme.medias
    ], ensure_ascii=False)


def _author_id(raw: dict, platform: str) -> str:
    if platform == "douyin":
        author = raw.get("author") or {}
        return str(author.get("sec_uid") or author.get("uid") or "")
    card = raw.get("note_card") or raw
    user = card.get("user") or {}
    return str(user.get("user_id") or user.get("userid") or user.get("id") or "")


_XHS_SEARCH_SORT = {
    "general": "general",
    "latest": "time_descending",
    "most_liked": "popularity_descending",
}
_XHS_NOTE_TYPE = {"all": 0, "video": 1, "images": 2}
_XHS_TIME_SECONDS = {
    "day": 86400,
    "week": 7 * 86400,
    "half_year": 180 * 86400,
}


def _xhs_count(value) -> int:
    text = str(value or "").strip().replace("+", "")
    try:
        if "万" in text:
            return int(float(text.replace("万", "")) * 10_000)
        if "亿" in text:
            return int(float(text.replace("亿", "")) * 100_000_000)
        return int(float(text))
    except (TypeError, ValueError):
        return 0


def _sort_xhs_search_items(items: list[dict], search_sort: str) -> list[dict]:
    """Keep general ranking stable and make explicit XHS sorts deterministic."""
    if search_sort == "latest":
        return sorted(
            items,
            key=lambda item: int((parse_note_brief(item) or {}).get("create_time") or 0),
            reverse=True,
        )
    if search_sort == "most_liked":
        def likes(item: dict) -> int:
            card = item.get("note_card") or item
            interact = card.get("interact_info") or {}
            return _xhs_count(interact.get("liked_count") or interact.get("likedCount"))
        return sorted(items, key=likes, reverse=True)
    return list(items)


def _xhs_content_matches(aweme: Aweme, job: KeywordCollectionJob,
                         *, now: int | None = None) -> bool:
    if job.content_type != "all" and aweme.media_type != job.content_type:
        return False
    if aweme.like_count < max(0, int(job.min_likes or 0)):
        return False
    if aweme.comment_count < max(0, int(job.min_comments or 0)):
        return False
    window = _XHS_TIME_SECONDS.get(job.publish_time)
    if window and aweme.create_time:
        if aweme.create_time < int(now or time.time()) - window:
            return False
    return True


class KeywordCollector:
    """执行单个持久化采集任务；调度与账号风控由 MonitorEngine 负责。"""

    def __init__(self, cfg, browser, downloader):
        self.cfg = cfg
        self.browser = browser
        self.downloader = downloader

    async def _xhs_gap(self, seconds: float) -> None:
        base = max(0.0, float(seconds or 0.0))
        if not base:
            return
        jitter = min(1.0, max(
            0.0, float(self.cfg.engine.xhs_request_jitter or 0.0)))
        await asyncio.sleep(base * random.uniform(1.0, 1.0 + jitter))

    def _xhs_browser_reads_enabled(self) -> bool:
        return bool(
            self.cfg.engine.xhs_read_mode == "browser"
            and callable(getattr(self.browser, "visible_page", None))
        )

    def _direct_request_ua(self, identity) -> str:
        resolver = getattr(self.browser, "direct_request_user_agent", None)
        if callable(resolver):
            return resolver(identity)
        return str(getattr(identity, "ua", "") or self.cfg.engine.user_agent)

    def _result(self, job_id: int, *, stopped: bool = False) -> dict:
        contents, comments = self._refresh_counts(job_id)
        final = self._job(job_id)
        return {
            "canceled": False,
            "stopped": stopped,
            "errors": final.error_count if final else 0,
            "contents": contents,
            "comments": comments,
        }

    @staticmethod
    def _job(job_id: int) -> KeywordCollectionJob | None:
        with get_session() as session:
            return session.get(KeywordCollectionJob, job_id)

    @staticmethod
    def _cancel_requested(job_id: int) -> bool:
        job = KeywordCollector._job(job_id)
        return not job or job.cancel_requested or job.status == "canceled"

    @staticmethod
    def _progress(job_id: int, *, keyword: str | None = None,
                  step: str | None = None,
                  processed_keyword_count: int | None = None,
                  current_item_index: int | None = None,
                  current_item_total: int | None = None) -> None:
        with get_session() as session:
            job = session.get(KeywordCollectionJob, job_id)
            if not job:
                return
            if keyword is not None:
                job.current_keyword = keyword
            if step is not None:
                job.current_step = step
            if processed_keyword_count is not None:
                job.processed_keyword_count = max(0, processed_keyword_count)
            if current_item_index is not None:
                job.current_item_index = max(0, current_item_index)
            if current_item_total is not None:
                job.current_item_total = max(0, current_item_total)
            session.add(job)
            session.commit()

    @staticmethod
    def _record_error(job_id: int, message: str) -> None:
        message = str(message or "").strip()
        if not message:
            return
        with get_session() as session:
            job = session.get(KeywordCollectionJob, job_id)
            if not job:
                return
            job.error_count += 1
            lines = [line for line in (job.error or "").splitlines() if line]
            lines.append(message[:360])
            job.error = "\n".join(lines[-8:])[:2400]
            session.add(job)
            session.commit()

    @staticmethod
    def _mark_account_invalid(account_id: int) -> None:
        """搜索页明确出现登录墙时同步账号状态，避免继续把旧 Cookie 当作可用。"""
        from ..models import DouyinAccount
        with get_session() as session:
            account = session.get(DouyinAccount, account_id)
            if account and account.status != "invalid":
                account.status = "invalid"
                session.add(account)
                session.commit()

    @staticmethod
    def _refresh_counts(job_id: int) -> tuple[int, int]:
        with get_session() as session:
            contents = int(session.exec(
                select(func.count(KeywordCollectionContent.id))
                .where(KeywordCollectionContent.job_id == job_id)
            ).one() or 0)
            comments = int(session.exec(
                select(func.count(KeywordCollectionComment.id))
                .where(KeywordCollectionComment.job_id == job_id)
            ).one() or 0)
            job = session.get(KeywordCollectionJob, job_id)
            if job:
                job.content_count = contents
                job.comment_count = comments
                session.add(job)
                session.commit()
        return contents, comments

    async def _discover_douyin(self, account, keyword: str,
                               job: KeywordCollectionJob,
                               client: DouyinClient | None = None,
                               context=None) -> tuple[list[dict], str]:
        identity = self.browser.identity_for(account)
        mode = str(getattr(self.cfg.engine, "douyin_read_mode", "hybrid") or "hybrid")
        if mode in {"api", "hybrid"} and client is not None:
            try:
                items, error = await client.search_awemes(
                    keyword,
                    max_results=job.max_contents_per_keyword,
                    max_pages=job.max_pages_per_keyword,
                    search_sort=job.search_sort,
                    publish_time=job.publish_time,
                    content_type=job.content_type,
                    min_likes=job.min_likes,
                    min_comments=job.min_comments,
                )
                if items or mode == "api":
                    return items, ("抖音搜索接口失败: " + error if error else "")
                if error:
                    print(f"[dy-search] API 空响应({error}),回退浏览器")
            except Exception as exc:
                if mode == "api":
                    return [], f"抖音搜索接口异常: {exc!r}"
                print(f"[dy-search] API 异常({type(exc).__name__}),回退浏览器")
        return await fetch_douyin_search(
            self.browser, identity, keyword,
            max_results=job.max_contents_per_keyword,
            max_scrolls=job.max_pages_per_keyword,
            stagnant_limit=job.stagnant_pages,
            search_sort=job.search_sort,
            publish_time=job.publish_time,
            content_type=job.content_type,
            min_likes=job.min_likes,
            min_comments=job.min_comments,
            captcha_wait_seconds=self.cfg.engine.douyin_captcha_wait_seconds,
            block_media=self.cfg.engine.block_media_resources,
            context=context,
        )

    async def _discover_douyin_creator(
            self, account, job: KeywordCollectionJob,
            client: DouyinClient | None) -> tuple[list[dict], str]:
        mode = str(getattr(self.cfg.engine, "douyin_read_mode", "hybrid") or "hybrid")
        if mode in {"api", "hybrid"} and client is not None:
            try:
                values = await client.fetch_all_video_list(
                    job.source_ref,
                    max_pages=job.max_pages_per_keyword,
                    count=min(20, job.max_contents_per_keyword))
                if values or mode == "api":
                    return values[:job.max_contents_per_keyword], ""
            except Exception as exc:
                if mode == "api":
                    return [], f"抖音创作者作品读取失败: {exc}"
        values, _author, error = await fetch_videos(
            self.browser, self.browser.identity_for(account), job.source_ref, set(),
            max_scrolls=job.max_pages_per_keyword,
            block_media=self.cfg.engine.block_media_resources)
        return values[:job.max_contents_per_keyword], error

    async def _discover_xhs(self, client: XhsApiClient, keyword: str,
                            job: KeywordCollectionJob) -> tuple[list[dict], str]:
        found: dict[str, dict] = {}
        pages = max(1, min(40, int(job.max_pages_per_keyword or 1)))
        needs_local_filter = bool(
            job.publish_time != "all" or job.min_likes or job.min_comments)
        candidate_limit = (pages * 20 if needs_local_filter
                           else job.max_contents_per_keyword)
        stagnant = 0
        try:
            for page in range(1, pages + 1):
                raw_items = await client.search_notes(
                    keyword,
                    page=page,
                    page_size=20,
                    sort=_XHS_SEARCH_SORT.get(job.search_sort, "general"),
                    note_type=_XHS_NOTE_TYPE.get(job.content_type, 0),
                )
                before = len(found)
                for raw in raw_items:
                    brief = parse_note_brief(raw)
                    if brief:
                        found.setdefault(brief["note_id"], raw)
                    if len(found) >= candidate_limit:
                        break
                stagnant = stagnant + 1 if len(found) == before else 0
                if len(found) >= candidate_limit:
                    break
                if not raw_items or stagnant >= max(1, int(job.stagnant_pages or 1)):
                    break
                await self._xhs_gap(0.6)
        except Exception as exc:
            return _sort_xhs_search_items(
                list(found.values()), job.search_sort), f"小红书搜索失败: {exc}"
        return _sort_xhs_search_items(list(found.values()), job.search_sort), ""

    async def _discover_xhs_browser(
            self, identity, keyword: str, job: KeywordCollectionJob
            ) -> tuple[list[dict], str]:
        values, error = await fetch_xhs_search(
            self.browser,
            identity,
            keyword,
            set(),
            max_scrolls=max(1, min(40, int(job.max_pages_per_keyword or 1))),
            stagnant_limit=max(1, min(8, int(job.stagnant_pages or 1))),
            search_sort=job.search_sort,
            content_type=job.content_type,
            block_media=self.cfg.engine.block_media_resources,
        )
        return _sort_xhs_search_items(values, job.search_sort), error

    async def _discover_xhs_favorites_browser(
            self, identity, account,
            job: KeywordCollectionJob) -> tuple[list[dict], str]:
        values, error = await fetch_xhs_favorites(
            self.browser, identity, str(getattr(account, "sec_uid", "") or ""),
            board_id=job.source_ref if job.source_type == "favorite_board" else "",
            board_name=job.source_name,
            max_scrolls=max(1, min(40, int(job.max_pages_per_keyword or 1))),
            stagnant_limit=max(1, min(8, int(job.stagnant_pages or 1))),
        )
        return values, error

    async def _discover_xhs_favorites_api(
            self, client: XhsApiClient, job: KeywordCollectionJob) -> tuple[list[dict], str]:
        found: dict[str, dict] = {}
        cursor = ""
        pages = max(1, min(40, int(job.max_pages_per_keyword or 1)))
        try:
            for page in range(pages):
                data = await client.favorite_notes(
                    board_id=(job.source_ref if job.source_type == "favorite_board" else ""),
                    cursor=cursor, page_size=min(50, job.max_contents_per_keyword))
                values = data.get("notes") or data.get("items") or []
                before = len(found)
                for raw in values:
                    brief = parse_note_brief(raw)
                    if brief:
                        raw.setdefault("xsec_source", "pc_user")
                        found.setdefault(brief["note_id"], raw)
                    if len(found) >= job.max_contents_per_keyword:
                        break
                if len(found) >= job.max_contents_per_keyword:
                    break
                next_cursor = str(data.get("cursor") or data.get("next_cursor") or "")
                has_more = bool(data.get("has_more"))
                if len(found) == before or not has_more or not next_cursor or next_cursor == cursor:
                    break
                cursor = next_cursor
                if page + 1 < pages:
                    await self._xhs_gap(0.6)
        except Exception as exc:
            return list(found.values()), f"小红书收藏读取失败: {exc}"
        return list(found.values()), ""

    async def _discover_xhs_creator_browser(
            self, identity, job: KeywordCollectionJob) -> tuple[list[dict], str]:
        values, _author, error = await fetch_xhs_notes(
            self.browser, identity, job.source_ref, set(),
            max_scrolls=max(1, min(40, job.max_pages_per_keyword)),
            block_media=self.cfg.engine.block_media_resources,
            ssr_fallback=True)
        return values[:job.max_contents_per_keyword], error

    async def _discover_xhs_creator_api(
            self, client: XhsApiClient, job: KeywordCollectionJob) -> tuple[list[dict], str]:
        found: dict[str, dict] = {}
        cursor = ""
        try:
            for page in range(max(1, min(40, job.max_pages_per_keyword))):
                data = await client.notes_by_creator(
                    job.source_ref, cursor=cursor,
                    page_size=min(30, job.max_contents_per_keyword),
                    xsec_source="pc_feed")
                values = data.get("notes") or []
                for raw in values:
                    brief = parse_note_brief(raw)
                    if brief:
                        raw.setdefault("xsec_source", "pc_feed")
                        found.setdefault(brief["note_id"], raw)
                    if len(found) >= job.max_contents_per_keyword:
                        break
                next_cursor = str(data.get("cursor") or data.get("next_cursor") or "")
                if (len(found) >= job.max_contents_per_keyword or not data.get("has_more")
                        or not next_cursor or next_cursor == cursor):
                    break
                cursor = next_cursor
                if page + 1 < job.max_pages_per_keyword:
                    await self._xhs_gap(0.6)
        except Exception as exc:
            return list(found.values()), f"小红书创作者作品读取失败: {exc}"
        return list(found.values()), ""

    async def _materialize_xhs(self, client: XhsApiClient, raw: dict) \
            -> tuple[Aweme | None, dict, str]:
        brief = parse_note_brief(raw)
        if not brief:
            return None, {}, "搜索结果缺少 note_id"
        card = {}
        error = ""
        try:
            card = await client.note_detail(
                brief["note_id"], xsec_token=brief.get("xsec_token", ""),
                xsec_source=brief.get("xsec_source") or "pc_search")
        except Exception as exc:
            error = f"详情抓取失败: {exc}"
        aweme = parse_note_detail(card, brief) if card else None
        if aweme is None:
            aweme = Aweme(
                aweme_id=brief["note_id"], desc=brief.get("title", ""),
                create_time=int(brief.get("create_time") or 0), author_name="",
                media_type="video" if brief.get("type") == "video" else "images",
            )
            aweme.platform = "xhs"
            aweme.cover = brief.get("cover") or ""
        return aweme, {"brief": brief, "card": card}, error

    async def _materialize_xhs_browser(self, identity, raw: dict) \
            -> tuple[Aweme | None, dict, str]:
        brief = parse_note_brief(raw)
        if not brief:
            return None, {}, "搜索结果缺少 note_id"
        card, error = await fetch_xhs_note_detail(
            self.browser,
            identity,
            brief["note_id"],
            xsec_token=brief.get("xsec_token", ""),
            xsec_source=brief.get("xsec_source") or "pc_search",
            block_media=self.cfg.engine.block_media_resources,
        )
        aweme = parse_note_detail(card or {}, brief) if card else None
        if aweme is None:
            aweme = Aweme(
                aweme_id=brief["note_id"], desc=brief.get("title", ""),
                create_time=int(brief.get("create_time") or 0), author_name="",
                media_type="video" if brief.get("type") == "video" else "images",
            )
            aweme.platform = "xhs"
            aweme.cover = brief.get("cover") or ""
        return aweme, {"brief": brief, "card": card or {}}, error

    @staticmethod
    def _upsert_content(job: KeywordCollectionJob, keyword: str, aweme: Aweme,
                        author_id: str, xsec_token: str, xsec_source: str,
                        detail_error: str) \
            -> KeywordCollectionContent:
        with get_session() as session:
            row = session.exec(
                select(KeywordCollectionContent)
                .where(KeywordCollectionContent.job_id == job.id)
                .where(KeywordCollectionContent.keyword == keyword)
                .where(KeywordCollectionContent.aweme_id == aweme.aweme_id)
            ).first()
            if row is None:
                row = KeywordCollectionContent(
                    job_id=job.id, platform=job.platform, keyword=keyword,
                    aweme_id=aweme.aweme_id,
                )
            row.desc = aweme.desc
            row.author_name = aweme.author_name
            row.author_id = author_id
            row.media_type = aweme.media_type
            row.create_time = aweme.create_time
            row.cover_url = aweme.cover or ""
            row.like_count = aweme.like_count
            row.comment_count = aweme.comment_count
            row.media_json = _media_json(aweme)
            row.xsec_token = xsec_token
            row.xsec_source = xsec_source
            row.error = detail_error
            if job.download_media and aweme.medias and row.download_status != "done":
                row.download_status = "pending"
            elif job.download_media and not aweme.medias:
                row.download_status = "failed"
                row.error = detail_error or "未取得媒体地址"
            elif not job.download_media:
                row.download_status = "skipped"
            session.add(row)
            session.commit()
            session.refresh(row)
            return row

    async def _download(self, job: KeywordCollectionJob,
                        content: KeywordCollectionContent, aweme: Aweme,
                        proxy: str) -> None:
        if not job.download_media or not aweme.medias or content.download_status == "done":
            return
        with get_session() as session:
            row = session.get(KeywordCollectionContent, content.id)
            if row:
                row.download_status = "downloading"
                session.add(row)
                session.commit()
        root = Path(job.download_dir).expanduser() if job.download_dir else \
            Path(self.cfg.engine.media_dir) / "keyword-collections"
        base_dir = root / f"job_{job.id}" / safe_title(content.keyword)
        routed_proxy = proxy if self.cfg.engine.route_download_via_proxy else ""
        ok, local_path, error = await self.downloader.download_aweme(
            aweme, str(base_dir), routed_proxy)
        with get_session() as session:
            row = session.get(KeywordCollectionContent, content.id)
            if row:
                row.download_status = "done" if ok else "failed"
                row.local_path = local_path
                if error:
                    row.error = (row.error + "; " if row.error else "") + error
                session.add(row)
                session.commit()
        if not ok:
            self._record_error(
                job.id,
                f"{content.keyword}/{content.aweme_id}: 媒体下载失败: "
                f"{error or '下载器未返回成功状态'}",
            )

    async def _douyin_comments(self, account, client: DouyinClient,
                                aweme: Aweme, limit: int,
                                include_replies: bool,
                                context=None) -> tuple[list[dict], str]:
        if limit <= 0:
            return [], ""
        mode = str(getattr(
            self.cfg.engine, "douyin_read_mode", "hybrid") or "hybrid").lower()
        if mode not in {"api", "hybrid", "browser"}:
            mode = "hybrid"
        error = ""
        raw: list[dict] = []
        if mode in {"api", "hybrid"}:
            try:
                raw = await client.fetch_all_comments(
                    aweme.aweme_id,
                    max_pages=max(1, min(20, math.ceil(limit / 20))),
                    with_replies=include_replies,
                    max_reply_pages=max(1, min(8, math.ceil(limit / 20))),
                )
            except Exception as exc:
                error = f"评论接口失败: {exc}"
        parsed = [item for item in (parse_comment(value) for value in raw) if item]
        if not include_replies:
            parsed = [item for item in parsed if not item.get("reply_to")]

        if mode == "api":
            # API-only 必须保持通道纯净：空 body、验证码、网络和解析失败都直接
            # 返回给任务，绝不偷偷打开页面。作品明确有评论时才把空结果记为异常。
            if not parsed and aweme.comment_count > 0 and not error:
                error = ("评论接口失败: "
                         f"{getattr(client, 'last_error', '') or 'empty_response'}")
            return self._dedupe_comments(parsed, limit), error

        # browser 模式从第一步就走页面；hybrid 仅在直连接口被静默降级时回退。
        if mode == "browser" or (not parsed and aweme.comment_count > 0):
            identity = self.browser.identity_for(account)
            fallback, browser_error = await fetch_comments(
                self.browser, identity, aweme.aweme_id, set(),
                max_scrolls=max(2, min(20, math.ceil(limit / 12))),
                block_media=self.cfg.engine.block_media_resources,
                context=context,
            )
            parsed = [item for item in (parse_comment(value) for value in fallback) if item]
            if not include_replies:
                parsed = [item for item in parsed if not item.get("reply_to")]
            error = "" if parsed else (browser_error or error)
        return self._dedupe_comments(parsed, limit), error

    async def _xhs_comments(self, client: XhsApiClient, note_id: str,
                            xsec_token: str, xsec_source: str, limit: int,
                            include_replies: bool) -> tuple[list[dict], str]:
        if limit <= 0:
            return [], ""
        parsed: list[dict] = []
        error = ""
        try:
            page = await client.collect_note_comments(
                note_id, xsec_token=xsec_token,
                xsec_source=xsec_source or "pc_search",
                max_comments=limit,
                max_requests=max(1, min(20, math.ceil(limit / 10) + 1)),
                include_replies=include_replies,
                request_interval=max(0.5, self.cfg.engine.xhs_item_gap_seconds))
            parsed = [item for item in (
                parse_xhs_comment(value) for value in page["comments"]) if item]
        except Exception as exc:
            error = f"评论抓取失败: {exc}"
        if not include_replies:
            parsed = [item for item in parsed if not item.get("reply_to")]
        return self._dedupe_comments(parsed, limit), error

    async def _xhs_comments_browser(
            self, identity, note_id: str, xsec_token: str, xsec_source: str,
            limit: int,
            include_replies: bool) -> tuple[list[dict], str]:
        if limit <= 0:
            return [], ""
        raw, error = await fetch_xhs_comments(
            self.browser,
            identity,
            note_id,
            set(),
            xsec_token=xsec_token,
            xsec_source=xsec_source or "pc_search",
            max_scrolls=max(1, min(20, math.ceil(limit / 10) + 1)),
            block_media=self.cfg.engine.block_media_resources,
        )
        values = flatten_xhs_comments(raw) if include_replies else raw
        parsed = [item for item in
                  (parse_xhs_comment(value) for value in values) if item]
        if not include_replies:
            parsed = [item for item in parsed if not item.get("reply_to")]
        return self._dedupe_comments(parsed, limit), error

    @staticmethod
    def _dedupe_comments(values: list[dict], limit: int) -> list[dict]:
        found: dict[str, dict] = {}
        for value in values:
            cid = str(value.get("comment_id") or "")
            if cid:
                found.setdefault(cid, value)
            if len(found) >= limit:
                break
        return list(found.values())[:limit]

    @staticmethod
    def _persist_comments(job_id: int, content_id: int, platform: str,
                          aweme_id: str, comments: list[dict]) -> int:
        with get_session() as session:
            known = set(session.exec(
                select(KeywordCollectionComment.comment_id)
                .where(KeywordCollectionComment.job_id == job_id)
                .where(KeywordCollectionComment.content_id == content_id)
            ).all())
            added = 0
            for item in comments:
                cid = str(item.get("comment_id") or "")
                if not cid or cid in known:
                    continue
                known.add(cid)
                session.add(KeywordCollectionComment(
                    job_id=job_id, content_id=content_id, platform=platform,
                    aweme_id=aweme_id, comment_id=cid,
                    text=item.get("text") or "",
                    user_nickname=item.get("user_nickname") or "",
                    user_sec_uid=item.get("user_sec_uid") or "",
                    ip_label=item.get("ip_label") or "",
                    like_count=int(item.get("like_count") or 0),
                    create_time=int(item.get("create_time") or 0),
                    reply_to=item.get("reply_to") or "",
                ))
                added += 1
            content = session.get(KeywordCollectionContent, content_id)
            if content:
                content.collected_comment_count = len(known)
                session.add(content)
            session.commit()
        return added

    async def run(self, job_id: int, account) -> dict:
        job = self._job(job_id)
        if not job:
            raise RuntimeError("采集任务不存在")
        keywords = _loads_keywords(job.keywords)
        if job.source_type in {"favorite_all", "favorite_board", "creator"}:
            default_name = ("全部收藏" if job.source_type == "favorite_all" else
                            "收藏夹" if job.source_type == "favorite_board" else
                            f"创作者 {job.source_ref}")
            keywords = [job.source_name or default_name]
        if not keywords:
            raise RuntimeError("采集任务没有可执行来源")

        identity = self.browser.identity_for(account)
        proxy = account.proxy or ""
        douyin_client = None
        xhs_client = None
        if job.platform == "douyin":
            douyin_client = DouyinClient(
                douyin_cookie_from_state(account.storage_state), identity.ua,
                timeout=self.cfg.engine.request_timeout_seconds, proxy=proxy,
                **douyin_client_environment(identity))
        elif not self._xhs_browser_reads_enabled():
            cookie = cookie_str_from_state(account.storage_state)
            if not has_a1(cookie):
                raise RuntimeError("小红书登录态缺少 a1，请重新扫码登录")
            xhs_client = XhsApiClient(
                cookie, self._direct_request_ua(identity),
                timeout=self.cfg.engine.request_timeout_seconds, proxy=proxy)

        if job.platform == "douyin":
            mode = str(getattr(
                self.cfg.engine, "douyin_read_mode", "hybrid") or "hybrid").lower()
            if mode == "api":
                # 纯 API：只创建 HTTP session，不启动 Chromium，也不给后续评论
                # 路径传 page context。失败由任务记录，不做隐式浏览器回退。
                self._progress(job_id, step="启动抖音 API 采集")
                async with douyin_client.session_scope():
                    return await self._run_keywords(
                        job_id, job, account, keywords, proxy,
                        douyin_client=douyin_client, context=None)

            # browser/hybrid：抖音可能针对无头搜索返回验证码中间页，因此复用一次
            # 临时可见 context；hybrid 同时保留 HTTP session 供 API 优先路径使用。
            self._progress(job_id, step="启动抖音可见采集窗口")
            async with self.browser.temporary_headed_context(identity) as context:
                if mode == "browser":
                    return await self._run_keywords(
                        job_id, job, account, keywords, proxy,
                        douyin_client=douyin_client, context=context)
                async with douyin_client.session_scope():
                    return await self._run_keywords(
                        job_id, job, account, keywords, proxy,
                        douyin_client=douyin_client, context=context)
        if xhs_client is not None:
            async with xhs_client.session_scope():
                return await self._run_keywords(
                    job_id, job, account, keywords, proxy,
                    xhs_client=xhs_client, identity=identity)
        return await self._run_keywords(
            job_id, job, account, keywords, proxy,
            xhs_client=xhs_client, identity=identity)

    async def _run_keywords(self, job_id: int, job: KeywordCollectionJob,
                            account, keywords: list[str], proxy: str,
                             douyin_client: DouyinClient | None = None,
                             xhs_client: XhsApiClient | None = None,
                             context=None, identity=None) -> dict:

        browser_reads = self._xhs_browser_reads_enabled()
        self._progress(
            job_id,
            processed_keyword_count=0,
            current_item_index=0,
            current_item_total=0,
        )
        for keyword_index, keyword in enumerate(keywords):
            if self._cancel_requested(job_id):
                return {"canceled": True, "errors": self._job(job_id).error_count}
            if job.platform == "douyin" and keyword_index:
                gap = max(0.0, float(self.cfg.engine.douyin_keyword_gap_seconds))
                if gap:
                    await asyncio.sleep(gap * random.uniform(1.0, 1.35))
            elif job.platform == "xhs" and keyword_index:
                await self._xhs_gap(
                    self.cfg.engine.xhs_keyword_gap_seconds)
            self._progress(
                job_id,
                keyword=keyword,
                step="搜索作品",
                processed_keyword_count=keyword_index,
                current_item_index=0,
                current_item_total=0,
            )
            if job.platform == "douyin":
                if job.source_type == "creator":
                    raw_items, search_error = await self._discover_douyin_creator(
                        account, job, douyin_client)
                else:
                    raw_items, search_error = await self._discover_douyin(
                        account, keyword, job, client=douyin_client,
                        context=context)
            elif browser_reads:
                if job.source_type in {"favorite_all", "favorite_board"}:
                    raw_items, search_error = await self._discover_xhs_favorites_browser(
                        identity, account, job)
                elif job.source_type == "creator":
                    raw_items, search_error = await self._discover_xhs_creator_browser(
                        identity, job)
                else:
                    raw_items, search_error = await self._discover_xhs_browser(
                        identity, keyword, job)
            else:
                if job.source_type in {"favorite_all", "favorite_board"}:
                    raw_items, search_error = await self._discover_xhs_favorites_api(
                        xhs_client, job)
                elif job.source_type == "creator":
                    raw_items, search_error = await self._discover_xhs_creator_api(
                        xhs_client, job)
                else:
                    raw_items, search_error = await self._discover_xhs(
                        xhs_client, keyword, job)
            if search_error:
                self._record_error(job_id, f"{keyword}: {search_error}")
                if "登录态已失效" in search_error:
                    self._mark_account_invalid(account.id)
                category, _ = classify_platform_error(search_error)
                if category in {
                        RiskCategory.RISK, RiskCategory.AUTH, RiskCategory.NETWORK}:
                    # 风险/登录态/网络异常后停止后续关键词，避免一次任务继续放大信号。
                    break
            if not raw_items:
                self._progress(
                    job_id,
                    processed_keyword_count=keyword_index + 1,
                    current_item_index=0,
                    current_item_total=0,
                )
                continue

            candidates = (raw_items[:job.max_contents_per_keyword]
                          if job.platform == "douyin" else raw_items)
            accepted = 0
            for index, raw in enumerate(candidates, 1):
                if self._cancel_requested(job_id):
                    return {"canceled": True, "errors": self._job(job_id).error_count}
                self._progress(
                    job_id, keyword=keyword,
                    step=f"处理作品 {index}/{len(candidates)}",
                    processed_keyword_count=keyword_index,
                    current_item_index=index,
                    current_item_total=len(candidates),
                )
                if job.platform == "xhs" and index > 1:
                    await self._xhs_gap(self.cfg.engine.xhs_item_gap_seconds)
                detail_error = ""
                detail_raw = raw
                source = ""
                if job.platform == "douyin":
                    aweme = parse_aweme(raw, job.video_quality or "highest")
                    if aweme is None and raw.get("aweme_id"):
                        author = raw.get("author") or {}
                        aweme = Aweme(
                            aweme_id=str(raw.get("aweme_id")),
                            desc=(raw.get("desc") or "").strip(),
                            create_time=int(raw.get("create_time") or 0),
                            author_name=author.get("nickname") or "",
                            media_type="images" if raw.get("images") else "video",
                        )
                        detail_error = "未取得媒体地址"
                    token = ""
                elif browser_reads:
                    aweme, parts, detail_error = \
                        await self._materialize_xhs_browser(identity, raw)
                    brief = parts.get("brief") or {}
                    card = parts.get("card") or {}
                    detail_raw = card or raw
                    token = brief.get("xsec_token") or ""
                    source = brief.get("xsec_source") or (
                        "pc_feed" if job.source_type == "creator" else
                        "pc_user" if job.source_type != "keyword" else "pc_search")
                else:
                    aweme, parts, detail_error = await self._materialize_xhs(xhs_client, raw)
                    brief = parts.get("brief") or {}
                    card = parts.get("card") or {}
                    detail_raw = card or raw
                    token = brief.get("xsec_token") or ""
                    source = brief.get("xsec_source") or (
                        "pc_feed" if job.source_type == "creator" else
                        "pc_user" if job.source_type != "keyword" else "pc_search")
                if job.platform == "xhs" and detail_error:
                    category, _ = classify_platform_error(detail_error)
                    if category in {
                            RiskCategory.RISK, RiskCategory.AUTH,
                            RiskCategory.NETWORK}:
                        note_id = str(
                            (parts.get("brief") or {}).get("note_id") or "")
                        self._record_error(
                            job_id, f"{keyword}/{note_id}: {detail_error}")
                        return self._result(job_id, stopped=True)
                if aweme is None:
                    self._record_error(job_id, f"{keyword}: 无法解析一条搜索结果")
                    continue
                if job.platform == "xhs" and not _xhs_content_matches(aweme, job):
                    continue

                current = self._job(job_id)
                content = self._upsert_content(
                    current, keyword, aweme, _author_id(detail_raw, job.platform),
                    token, source, detail_error)
                accepted += 1
                if detail_error:
                    self._record_error(
                        job_id, f"{keyword}/{aweme.aweme_id}: {detail_error}")
                self._refresh_counts(job_id)

                if job.download_media:
                    self._progress(job_id, keyword=keyword, step=f"下载作品 {index}")
                    await self._download(current, content, aweme, proxy)

                if job.max_comments_per_content > 0:
                    self._progress(job_id, keyword=keyword, step=f"抓取评论 {index}")
                    if job.platform == "douyin":
                        comments, comment_error = await self._douyin_comments(
                            account, douyin_client, aweme,
                            job.max_comments_per_content, job.include_replies,
                            context=context)
                    elif browser_reads:
                        comments, comment_error = await self._xhs_comments_browser(
                            identity, aweme.aweme_id, token, source,
                            job.max_comments_per_content, job.include_replies)
                    else:
                        comments, comment_error = await self._xhs_comments(
                            xhs_client, aweme.aweme_id, token, source,
                            job.max_comments_per_content, job.include_replies)
                    self._persist_comments(
                        job_id, content.id, job.platform, aweme.aweme_id, comments)
                    if comment_error:
                        self._record_error(
                            job_id, f"{keyword}/{aweme.aweme_id}: {comment_error}")
                        if job.platform == "xhs" and classify_platform_error(
                                comment_error)[0] in {
                                RiskCategory.RISK, RiskCategory.AUTH,
                                RiskCategory.NETWORK}:
                            return self._result(job_id, stopped=True)
                self._refresh_counts(job_id)
                if job.platform != "xhs":
                    await asyncio.sleep(0.4)
                if accepted >= job.max_contents_per_keyword:
                    break

            self._progress(
                job_id,
                processed_keyword_count=keyword_index + 1,
                current_item_index=0,
                current_item_total=0,
            )

        return self._result(job_id)
