// Connected reply workspace. Preview examples remain confined to reply.mjs.
import {renderDelivery,bindDelivery} from './reply-delivery.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=name=>`<img class="rp-icon" src="/assets/${name}" alt="">`;
const actor=s=>`${s.user}|${s.storeId||''}`;
const matches=(s,value)=>value?.actor?.username===s.user&&value?.actor?.storeId===s.storeId;
const active=s=>s.connection==='connected'&&Boolean(s.session)&&s.page==='reply';
const statusLabels={draft:'草稿已保存 · 未发送',approved:'已核对 · 未发送',sent:'已有发送记录',unknown:'发送结果待核对',copied:'已复制 · 未确认发送',superseded:'历史草稿'};
function model(state){
  if(!state.replyLive||state.replyLive.actor!==actor(state))state.replyLive={actor:actor(state),status:'idle',items:[],stats:{},tab:'pending',groupBy:'post',query:'',page:1,generation:0,selectedId:'',leadId:'',text:'',accountId:'',busy:false,pending:null,error:'',detail:null,collapsedGroups:[]};
  return state.replyLive;
}
const selected=v=>v.detail?.comments?.find(row=>row.id===v.leadId);
function customerRow(p,v){return `<button type="button" class="rp-comment ${v.selectedId===p.id?'is-selected':''}" data-live-customer="${esc(p.id)}" aria-pressed="${v.selectedId===p.id}"><img class="rp-avatar" src="/assets/approved-icon-user-round.svg" alt=""><span class="rp-comment-copy"><strong>${esc(p.name)}</strong><span>${esc(p.quote)}</span></span><span class="rp-badge rp-${['urgent','high','medium','low','muted'].includes(p.tone)?p.tone:'muted'}">${esc(p.level)}</span><span class="rp-status ${p.replied?'is-replied':''}">${esc(p.contactLabel)}</span></button>`;}
function groups(v){
  if(v.groupBy!=='post')return `<section class="rp-post rp-flat-post"><div class="rp-flat-title">${v.groupBy==='intent'?'按意向查看':'按时间查看'}<span>本页 ${v.items.length} 位客户</span></div>${v.items.map(p=>customerRow(p,v)).join('')}</section>`;
  const posts=new Map();
  for(const p of v.items){const key=JSON.stringify([p.platform,p.postUrl||p.postTitle||p.id]);if(!posts.has(key))posts.set(key,[]);posts.get(key).push(p);}
  return [...posts].map(([key,items])=>{const p=items[0],closed=v.collapsedGroups.includes(key);return `<section class="rp-post ${closed?'is-collapsed':''}"><div class="rp-post-heading"><img class="rp-post-thumbnail" src="/assets/tabler-external-link.svg" alt="来源帖子"><div class="rp-post-name"><div><strong>${esc(p.postTitle||'帖子标题未提供')}</strong></div><span>${esc(p.channel)}<i>·</i>本页 ${items.length} 位客户${items.some(p=>p._outsidePage)?' · 含指定客户':''}</span></div><button type="button" class="rp-icon-button rp-collapse ${closed?'is-closed':''}" data-live-collapse="${esc(key)}" aria-label="${closed?'展开':'收起'}帖子客户" aria-expanded="${!closed}">${icon('tabler-chevron-down.svg')}</button></div>${closed?'':`<div class="rp-comment-list">${items.map(p=>customerRow(p,v)).join('')}</div>`}</section>`;}).join('');
}
function choose(v,id){const row=v.detail?.comments?.find(row=>row.id===id);v.leadId=row?.id||'';v.text=row?.draft?.text||'';v.accountId=row?.draft?.review_account_id||row?.accounts?.[0]?.id||'';v.dirty=false;}
function accept(state,v,result){
  if(!matches(state,result)||result.customerId!==v.selectedId)throw new Error('员工、门店或客户范围已变化，请重新载入。');
  v.detail=result;choose(v,result.comments?.some(row=>row.id===v.leadId)?v.leadId:result.comments?.[0]?.id);
  const pending=result.comments?.find(row=>row.pendingRequestId);
  if(pending)v.pending={customerId:result.customerId,leadId:pending.id,requestId:pending.pendingRequestId};
}
export function renderConnected(state){
  const v=model(state),row=selected(v),person=v.detail?.item;
  const counts={pending:Math.max(0,(v.stats.total||0)-(v.stats.replied||0)),replied:v.stats.replied||0,all:v.stats.total||0};
  const toolbar=`<div class="rp-toolbar"><div class="rp-tabs" role="tablist" aria-label="回复状态">${[['pending','待处理'],['replied','已回复'],['all','全部']].map(([id,label])=>`<button type="button" role="tab" aria-selected="${v.tab===id}" class="rp-tab ${v.tab===id?'is-active':''}" data-live-tab="${id}">${label}<span>${counts[id]}</span></button>`).join('')}</div><label class="rp-group"><select data-live-group aria-label="排列方式">${[['post','按帖子'],['intent','按意向'],['time','按时间']].map(([id,label])=>`<option value="${id}" ${v.groupBy===id?'selected':''}>${label}</option>`).join('')}</select></label><label class="rp-search">${icon('fy-icon-07-search.png')}<input id="reply-search" type="search" data-live-search value="${esc(v.query)}" maxlength="100" placeholder="搜索评论或用户名…" aria-label="搜索评论或用户名"></label></div>`;
  const list=groups(v);
  let editor=`<div class="rp-empty"><strong>${v.detailLoading?'正在读取原评论与草稿':'选择客户后，逐条选择原评论'}</strong><span>草稿和核对记录均不代表已发送。</span></div>`;
  if(row&&person)editor=`<div class="rp-person-summary"><img class="rp-detail-avatar" src="/assets/approved-icon-user-round.svg" alt=""><div class="rp-detail-copy"><div class="rp-person-title"><strong>${esc(person.name)}</strong><span class="rp-badge">${esc(person.level)}</span><button type="button" class="rp-text-link" data-live-source>查看源帖</button></div><p>${esc(row.text.length>240?row.text.slice(0,240)+'…':row.text)}</p>${row.text.length>240?'<button type="button" class="rp-text-link" data-live-full-comment>查看完整原评论</button>':''}</div></div><div class="rp-persona-controls"><label>原评论<select data-live-comment ${v.busy||v.pending?'disabled':''}>${v.detail.comments.map((c,i)=>`<option value="${esc(c.id)}" ${c.id===v.leadId?'selected':''}>${i+1}. ${esc(c.text.slice(0,48))}</option>`).join('')}</select></label><label>核对账号<select data-live-account ${v.busy||v.pending?'disabled':''}><option value="">请选择本人账号</option>${row.accounts.map(a=>`<option value="${esc(a.id)}" ${a.id===v.accountId?'selected':''}>${esc(a.name)}</option>`).join('')}</select></label></div><div class="rp-evidence"><span>来源：${esc(row.postTitle)} · ${esc(row.publishedAt||'时间未提供')}</span><span>${esc((row.draft?.status==='approved'&&!row.reviewCurrent?'审核来源需重核 · 未发送':statusLabels[row.draft?.status])||'尚无草稿 · 未发送')} ${row.draft?`· 版本 ${row.draft.version}`:''}</span><span>${esc(row.reason||(!row.accounts.length?'可保存草稿；逐条核对前需本人同平台账号。':'核对只记录草稿内容与账号，真实发送须再次完整核对并明确授权，当前平台与设备守卫仍生效。'))}</span></div><div class="rp-composer"><textarea id="connected-reply-draft" data-live-draft aria-label="回复草稿" maxlength="1000" ${v.busy||v.pending||!row.canSave?'disabled':''} placeholder="粘贴或填写已核实的回复内容，不自动生成房价或承诺…">${esc(v.text)}</textarea><span class="rp-char-count"><span data-live-count>${v.text.length}</span> / 1000</span></div><div class="rp-draft-tools"><button type="button" data-live-tone>IP与口吻</button><button type="button" data-live-copy>复制内容</button><span class="rp-saved">${v.dirty?'有未保存修改':row.draft?'草稿已从后台恢复':''}</span></div><div class="rp-editor-actions"><button type="button" class="rp-primary" data-live-review ${v.busy||v.dirty||!row.canReview||!v.accountId||v.pending?'disabled':''}>逐条核对草稿</button><button type="button" class="rp-secondary" data-live-save ${v.busy||!row.canSave||!v.text.trim()||v.pending?'disabled':''}>保存草稿</button></div>`;
  return `<div class="reply-page">${toolbar}${renderDelivery(state,v)}<div role="status" class="rp-evidence"><span>本机员工可见历史 · 当前门店 ${esc(state.storeId)} · 历史未绑定门店的来源保留原归属</span>${v.error?`<span role="alert">${esc(v.error)}</span>`:''}${v.recoveryText?`<span>原操作提交文字（保留供人工核对）：</span><blockquote>${esc(v.recoveryText)}</blockquote>`:''}${v.pending?'<span>上次操作结果待核对，暂不重复保存或审核。</span><button type="button" data-live-check>核对上次操作</button>':''}<button type="button" data-live-reload ${v.busy?'disabled':''}>重新读取</button></div><div class="rp-workspace"><div class="rp-posts"><div class="rp-flat-title">${v.status==='loading'?'正在读取真实客户':`可见客户 ${v.total||0} 位`}<span>第 ${v.page} / ${Math.max(1,v.pages||0)} 页</span></div>${list||`<div class="rp-empty"><strong>${v.status==='error'?'客户暂未加载':v.status==='loading'?'正在加载…':'当前没有符合条件的客户'}</strong><span>可切换全部或重新读取。</span></div>`}<div class="rp-editor-actions"><button type="button" class="rp-secondary" data-live-page="-1" ${v.page<=1||v.busy?'disabled':''}>上一页</button><button type="button" class="rp-secondary" data-live-page="1" ${v.page>=(v.pages||0)||v.busy?'disabled':''}>下一页</button></div></div><aside class="rp-editor" aria-label="回复编辑">${editor}</aside></div></div>`;
}
async function load(state,ctx,v,{customerId}={}){
  const generation=++v.generation,scope=actor(state);v.status='loading';v.error='';v.detail=null;v.leadId='';v.text='';v.dirty=false;v.pending=null;v.busy=false;ctx.update(()=>{});
  const owns=()=>active(state)&&state.replyLive===v&&generation===v.generation&&scope===actor(state);
  try{
    const result=await ctx.replyCustomers({query:v.query,filter:v.tab,sort:v.groupBy,page:v.page,pageSize:20});
    if(!owns())return;
    if(!matches(state,result.customers))throw new Error('员工或门店已变化，请重新载入。');
    Object.assign(v,{items:result.customers.items,total:result.customers.total,stats:result.customers.stats,pages:result.customers.pages,page:result.customers.page,status:'ready'});
    const chosen=customerId||v.selectedId;
    v.selectedId=customerId||(v.items.some(row=>row.id===chosen)?chosen:v.items[0]?.id||'');
    v.detail=null;v.leadId='';v.text='';v.dirty=false;
    if(v.selectedId){v.detailLoading=true;ctx.update(()=>{});const detail=await ctx.replyRead({storeId:state.storeId,customerId:v.selectedId});if(!owns())return;accept(state,v,detail.replyWorkspace);if(customerId&&!v.items.some(row=>row.id===customerId))v.items.unshift({...detail.replyWorkspace.item,_outsidePage:true});}
  }catch(error){if(owns()){v.status='error';v.error=error.message;ctx.replyError(error);}}
  finally{if(owns()){v.detailLoading=false;ctx.update(()=>{});}}
}
async function selectCustomer(state,ctx,v,id){
  const generation=++v.generation,scope=actor(state);v.selectedId=id;v.detail=null;v.detailLoading=true;v.error='';ctx.update(()=>{});
  const owns=()=>active(state)&&state.replyLive===v&&generation===v.generation&&scope===actor(state);
  try{const result=await ctx.replyRead({storeId:state.storeId,customerId:id});if(owns())accept(state,v,result.replyWorkspace);}
  catch(error){if(owns()){v.error=error.message;ctx.replyError(error);}}
  finally{if(owns()){v.detailLoading=false;ctx.update(()=>{});}}
}
async function mutate(state,ctx,v,review=false){
  const row=selected(v);if(!row||v.busy||v.pending)return false;
  const scope=actor(state),requestId=crypto.randomUUID(),customerId=v.selectedId,leadId=row.id;
  const generation=v.generation;
  const ownsView=()=>active(state)&&state.replyLive===v&&scope===actor(state)&&v.generation===generation&&v.selectedId===customerId&&v.leadId===leadId;
  const ownsAttempt=()=>ownsView()&&v.pending?.requestId===requestId;
  const payload={storeId:state.storeId,customerId,leadId,sourceDigest:row.sourceDigest,expectedVersion:row.draft?.version||0,expectedReplyId:row.draft?.id||'',requestId,...(review?{accountId:v.accountId,confirmed:true}:{text:v.text})};
  v.busy=true;v.error='';v.pending={customerId,leadId,requestId};ctx.update(()=>{});
  try{
    const result=await (review?ctx.replyReview(payload):ctx.replySave(payload));
    if(!ownsAttempt())return false;
    v.pending=null;accept(state,v,result.replyWorkspace);ctx.toast(review?'草稿已逐条核对，尚未发送。':'草稿已保存，尚未发送。');return true;
  }catch(error){if(ownsAttempt()){if(!['RESULT_UNCONFIRMED','REPLY_RESULT_UNCONFIRMED'].includes(error.code))v.pending=null;v.error=error.message;ctx.replyError(error);}return false;}
  finally{if(ownsView()&&(!v.pending||v.pending.requestId===requestId)){v.busy=false;ctx.update(()=>{});}}
}
async function checkPending(state,ctx,v){
  if(v.busy||!v.pending)return;
  const scope=actor(state),generation=v.generation,pending={...v.pending};
  const ownsView=()=>active(state)&&state.replyLive===v&&scope===actor(state)&&v.generation===generation&&v.selectedId===pending.customerId;
  const ownsAttempt=()=>ownsView()&&v.pending?.requestId===pending.requestId;
  v.busy=true;ctx.update(()=>{});
  try{
    const result=await ctx.replyCheck({storeId:state.storeId,...pending});if(!ownsAttempt())return;
    accept(state,v,result.replyWorkspace);
    if(['accepted','observed','not_found','not_applied','rejected','changed'].includes(result.replyWorkspace.receipt?.state)){
      v.pending=null;v.recoveryText=result.replyWorkspace.receipt?.attemptText||'';
      v.error=result.replyWorkspace.receipt?.state==='changed'?'原评论或草稿版本已变化，旧操作已关闭。保留当前草稿；请逐条重核，旧审核不代表当前来源有效。':'请逐条核对当前后台正文和版本，尚未发送。';
    }else v.error='后台尚未确认原操作，请保留当前记录，不要重复保存。';
  }catch(error){if(ownsAttempt()){v.error=error.message;ctx.replyError(error);}}
  finally{if(ownsView()&&(!v.pending||v.pending.requestId===pending.requestId)){v.busy=false;ctx.update(()=>{});}}
}
let currentScope='';
export function syncConnected(state,ctx){
  if(!active(state)){currentScope='';return;}
  const v=model(state);
  if(currentScope!==actor(state)||v.status==='idle'){currentScope=actor(state);v.status='scheduled';queueMicrotask(()=>{const id=state.selectedCustomer||state.replyDelivery?.customerIds?.[0];delete state.selectedCustomer;if(active(state)&&state.replyLive===v)load(state,ctx,v,{customerId:id});});}
}
export function bindConnected(root,ctx){
  const state=ctx.state,v=model(state);
  root.querySelector('[data-live-tone]')?.addEventListener('click',()=>ctx.openToneTools?.());
  const discard=fn=>{if(v.busy||v.pending){ctx.toast('请先核对当前操作结果。');return;}if(v.dirty)ctx.modal({title:'有未保存修改',html:'<p>切换后将重新读取后台草稿，未保存文字会丢失。</p>',confirmLabel:'放弃修改并继续',onConfirm:fn});else fn();};
  bindDelivery(root,ctx,v,id=>discard(()=>selectCustomer(state,ctx,v,id)));
  root.querySelector('[data-live-reload]')?.addEventListener('click',()=>discard(()=>load(state,ctx,v)));
  root.querySelectorAll('[data-live-collapse]').forEach(el=>el.addEventListener('click',()=>{const key=el.dataset.liveCollapse;v.collapsedGroups=v.collapsedGroups.includes(key)?v.collapsedGroups.filter(k=>k!==key):[...v.collapsedGroups,key];ctx.update(()=>{});}));
  root.querySelectorAll('[data-live-tab]').forEach(el=>el.addEventListener('click',()=>discard(()=>{v.tab=el.dataset.liveTab;v.page=1;load(state,ctx,v);})));
  root.querySelector('[data-live-group]')?.addEventListener('change',e=>discard(()=>{v.groupBy=e.target.value;v.page=1;load(state,ctx,v);}));
  const search=root.querySelector('[data-live-search]');
  search?.addEventListener('change',e=>{const query=e.target.value;discard(()=>{v.query=query;v.page=1;load(state,ctx,v);});});
  root.querySelectorAll('[data-live-page]').forEach(el=>el.addEventListener('click',()=>discard(()=>{v.page+=Number(el.dataset.livePage);load(state,ctx,v);})));
  root.querySelectorAll('[data-live-customer]').forEach(el=>el.addEventListener('click',()=>discard(()=>selectCustomer(state,ctx,v,el.dataset.liveCustomer))));
  root.querySelector('[data-live-comment]')?.addEventListener('change',e=>{const id=e.target.value;discard(()=>{choose(v,id);ctx.update(()=>{});});});
  root.querySelector('[data-live-account]')?.addEventListener('change',e=>{if(v.busy||v.pending)return;v.accountId=e.target.value;ctx.update(()=>{});});
  root.querySelector('[data-live-draft]')?.addEventListener('input',e=>{if(v.busy||v.pending||!selected(v)?.canSave)return;v.text=e.target.value;v.dirty=v.text!==(selected(v)?.draft?.text||'');root.querySelector('[data-live-count]').textContent=v.text.length;root.querySelector('[data-live-save]').disabled=v.busy||!selected(v)?.canSave||!v.text.trim()||Boolean(v.pending);root.querySelector('[data-live-review]').disabled=v.busy||v.dirty||!selected(v)?.canReview||!v.accountId||Boolean(v.pending);});
  root.querySelector('[data-live-copy]')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(v.text);ctx.toast('内容已复制，尚未确认发送。');}catch{root.querySelector('[data-live-draft]')?.select();ctx.toast('已选中文字，可手动复制。');}});
  root.querySelector('[data-live-save]')?.addEventListener('click',()=>mutate(state,ctx,v));
  root.querySelector('[data-live-review]')?.addEventListener('click',()=>{const row=selected(v);if(!row?.canReview||v.dirty||!v.accountId||v.pending)return;const account=row.accounts.find(a=>a.id===v.accountId);ctx.modal({title:'逐条核对草稿',html:`<p>原评论：</p><blockquote style="max-height:40vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere">${esc(row.text)}</blockquote><p>账号：${esc(account?.name)}</p><blockquote class="rp-confirm-quote">${esc(v.text)}</blockquote><p>确认后仅保存审核记录，不会发送到平台。</p>`,confirmLabel:'确认本条草稿与账号',onConfirm:()=>mutate(state,ctx,v,true)});});
  root.querySelector('[data-live-check]')?.addEventListener('click',()=>checkPending(state,ctx,v));
  root.querySelector('[data-live-full-comment]')?.addEventListener('click',()=>ctx.modal({title:'完整原评论',html:`<blockquote style="max-height:55vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere">${esc(selected(v)?.text)}</blockquote>`,confirmLabel:'知道了'}));
  root.querySelector('[data-live-source]')?.addEventListener('click',()=>{const row=selected(v);const hosts={xiaohongshu:['www.xiaohongshu.com','xiaohongshu.com'],douyin:['www.douyin.com','douyin.com']};try{const url=new URL(row.postUrl);if(url.protocol!=='https:'||url.username||url.password||url.port||!hosts[row.platform]?.includes(url.hostname))throw new Error();window.open(url.href,'_blank','noopener');}catch{ctx.toast('源帖地址尚未核对，保留原评论来源。');}});
}
