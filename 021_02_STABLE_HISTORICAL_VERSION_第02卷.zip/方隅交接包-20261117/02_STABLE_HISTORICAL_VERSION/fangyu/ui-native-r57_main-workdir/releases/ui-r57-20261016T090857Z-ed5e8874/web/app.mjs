import './canvas-fit.mjs';
import {createBackend} from './backend.mjs';
import * as acquire from './pages/acquire.mjs';
import * as presets from './pages/presets.mjs';
import * as reply from './pages/reply.mjs';
import * as customers from './pages/customers.mjs';
const app=document.getElementById('app');
const initialPage=location.hash.slice(1)||'login';
const backend=createBackend();
const state={page:'login',store:'',user:'',scenario:'normal',connection:'loading',session:null,stores:[],catalog:{search:[],intent:[]},selection:null,capabilities:{presets:false},rememberedUsername:'',busy:false};
const pages={acquire,presets,reply,customers};
const titles={acquire:['获客截流','发现真实租房需求'],reply:['意向回复','从社交平台，看见真实的租房需求'],customers:['客户工作台','每条线索都有来源，每次交接都有回执。'],presets:['门店获客预设','选好门店，搜索与意向规则自动配套'],accounts:['平台账号','连接平台账号，继续渠道运营']};
let cleanup,toastTimer,lastFocus;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(file,cls='')=>`<img class="icon ${cls}" src="/assets/${file}" alt="">`;
function navigate(page){if(!titles[page]&&page!=='login')page='acquire';if(state.connection!=='preview'&&!state.session)page='login';state.page=page;if(location.hash!=='#'+page)history.replaceState(null,'','#'+page);render();window.scrollTo({top:0,behavior:'instant'});}
function toast(text){clearTimeout(toastTimer);const n=document.getElementById('toast');n.textContent=text;n.hidden=false;toastTimer=setTimeout(()=>n.hidden=true,3500);}
function update(mutator){const focused=document.activeElement;const key=focused?.id;const start=focused?.selectionStart;const end=focused?.selectionEnd;mutator(state);render();if(key){const n=document.getElementById(key);if(n){n.focus({preventScroll:true});if(typeof start==='number'&&n.setSelectionRange){try{n.setSelectionRange(start,end);}catch{}}}}}
function modal({title,html,onConfirm,confirmLabel='确定'}){const d=document.getElementById('modal');lastFocus=document.activeElement;d.innerHTML=`<div class="modal-header"><h2 id="modal-title">${esc(title)}</h2><button class="modal-close" aria-label="关闭">${icon('tabler-x.svg')}</button></div><div class="modal-content">${html}</div><div class="modal-actions"><button class="modal-cancel">${onConfirm?'取消':'关闭'}</button>${onConfirm?`<button class="primary modal-confirm">${esc(confirmLabel)}</button>`:''}</div>`;d.querySelector('.modal-close').onclick=()=>d.close();d.querySelector('.modal-cancel').onclick=()=>d.close();if(onConfirm)d.querySelector('.modal-confirm').onclick=async()=>{const result=await onConfirm();if(result!==false)d.close();};if(!d.open)d.showModal();d.onclose=()=>lastFocus?.isConnected&&lastFocus.focus();d.onclick=e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}};}
const viewModel=state;
function acceptBootstrap(result){
  state.connection='connected';state.session=result.session||null;state.user=result.session?.user?.username||'';
  state.rememberedUsername=result.rememberedUsername||'';state.stores=Array.isArray(result.stores)?result.stores:[];
  state.catalog={search:Array.isArray(result.catalog?.search)?result.catalog.search:[],intent:Array.isArray(result.catalog?.intent)?result.catalog.intent:[]};state.selection=result.selection||null;state.capabilities=result.capabilities||{presets:false};state.notice=result.notice||'';
  const store=state.stores.find(item=>item.id===state.selection?.storeId)||state.stores[0];
  state.storeId=store?.id||'';state.store=store?.name||'';
  const old=state.presets;state.presets={search:state.selection?.searchPresetId||state.catalog.search[0]?.id||'',intent:state.selection?.intentPresetId||state.catalog.intent[0]?.id||'',tab:old?.tab||'presets',showWords:old?.showWords||false,showRules:old?.showRules||false};
  if(state.acquire&&store)state.acquire.region=store.region;
}
function showActionError(error){if(['AUTH_REQUIRED','unauthenticated','session_expired'].includes(error?.code)){state.session=null;state.user='';state.stores=[];state.store='';state.storeId='';state.capabilities={presets:false};navigate('login');}toast(error?.message||'操作未完成，请稍后重试。');}
async function selectStore(storeId){
  if(state.busy)return;
  state.busy=true;render();
  try{acceptBootstrap(await backend.selectStore(storeId));}
  catch(error){showActionError(error);}
  finally{state.busy=false;render();}
}
async function applyPreset(){
  if(state.busy||!state.capabilities.presets)return;
  const choice={storeId:state.storeId,searchPresetId:state.presets.search,intentPresetId:state.presets.intent,expectedRevision:state.selection?.revision};
  state.busy=true;render();
  try{acceptBootstrap(await backend.applyPreset(choice));const store=state.stores.find(item=>item.id===state.storeId);const search=state.catalog.search.find(item=>item.id===state.presets.search);const intent=state.catalog.intent.find(item=>item.id===state.presets.intent);state.acquire??={region:store?.region||'',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};if(['running','paused'].includes(state.acquire.status)){state.acquire.records.unshift({text:'已应用门店预设，本次采集演示结束',status:'已停止'});Object.assign(state.acquire,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null});}Object.assign(state.acquire,{region:store?.region||'',searchPreset:search?.name||'',intentPreset:intent?.name||''});navigate('acquire');toast('门店预设已保存并应用；采集仍为示例演示');}
  catch(error){showActionError(error);}
  finally{state.busy=false;render();}
}
async function logout(){if(state.busy)return false;state.busy=true;try{acceptBootstrap(await backend.logout());state.acquire=undefined;state.reply=undefined;state.customers=undefined;navigate('login');if(state.notice)toast(state.notice);return true;}catch(error){showActionError(error);return false;}finally{state.busy=false;render();}}
const actions={update,navigate,toast,modal,selectStore,applyPreset};
const ctx={viewModel,actions,state:viewModel,...actions};
function navButton(page,label,img){return `<button class="nav-btn ${state.page===page?'active':''}" data-nav="${page}" ${state.page===page?'aria-current="page"':''}>${icon(img)}<span>${label}</span></button>`;}
function shell(content){const management=state.page==='presets';const nav=management?`${navButton('presets','获客规则','approved-icon-search.svg')}<button class="nav-btn" data-info="口吻方案">${icon('icon-message-square-more.svg')}<span>IP与口吻</span></button>${navButton('accounts','账号与团队','approved-icon-user-round.svg')}<hr class="nav-divider"><button class="nav-btn" data-info="工作台设置">${icon('approved-icon-settings.svg')}<span>设置</span></button>${navButton('acquire','返回工作台','tabler-home.svg')}`:`${navButton('acquire','获客','approved-icon-search.svg')}${navButton('reply','回复','icon-message-square-more.svg')}${navButton('customers','客户','approved-icon-user-round.svg')}<hr class="nav-divider">${navButton('accounts','账号','approved-icon-user-round.svg')}${navButton('presets','管理','approved-icon-settings.svg')}`;
return `<div class="shell" data-current="${state.page}"><aside class="sidebar"><div class="brand"><span class="brand-mark"><img src="/assets/fy-approved-official-logo.png" alt="方隅公寓官方标志"></span><div class="brand-copy"><strong>方隅工作台</strong><span>渠道运营</span></div></div><nav class="side-nav" aria-label="主导航">${nav}</nav><img class="side-photo" src="/assets/sidebar-approved-photo.png" alt="阳光中的公寓建筑"><div class="side-quote"><strong>让更多人</strong><br>住进更好的城市生活</div></aside><div class="hero-photo"><img src="/assets/fy-approved-header-apartment.png" alt=""></div><header class="topbar ${management||state.page==='customers'?'has-date':''}">${management?'<time class="topbar-date">2026年10月16日　星期五</time><span class="topbar-divider"></span>':''}<button class="bell" aria-label="通知">${icon('fy-icon-58-bell.png')}</button><button class="account-button" aria-label="${esc(state.user||'演示账号')}账号菜单"><img class="avatar" src="/assets/portrait-man-1.png" alt="账号头像"><span>${esc(state.user||'演示账号')}</span>${icon('tabler-chevron-down.svg')}</button>${state.page==='customers'?'<span class="topbar-divider"></span><time class="topbar-date">2026-10-16　周五</time>':''}</header>${state.page==='reply'?'<div class="date-label">2026-10-16</div>':''}${management||state.page==='reply'||state.page==='customers'?'<div class="hero-quote">好房子<br>让生活更靠近理想</div>':''}<main class="main"><div class="page-heading"><h1>${titles[state.page][0]}</h1><p>${titles[state.page][1]}</p></div>${state.page==='acquire'?'<div class="top-stats"><div><span>新增客户</span><strong>128</strong></div><div><span>高意向</span><strong>36</strong></div><div><span>已回复</span><strong>12</strong></div></div>':''}<section id="page-content">${content}</section><footer class="page-footer">${state.connection==='preview'?'界面预览 · 示例数据':'登录与门店预设已接入 · 其他业务为示例数据'}&nbsp;&nbsp; 2026-10-16</footer></main></div>`;}
function login(){const preview=state.connection==='preview',waiting=state.connection==='loading';return `<main class="login-page"><section class="login-photo" aria-label="方隅公寓"><img src="/assets/login-approved-photo.png" alt="暖阳透过落地窗，洒在公寓客厅"><div class="login-caption">让每一次咨询，都有回应。<small>— 方隅公寓</small></div></section><section class="login-form-wrap"><span class="demo-pill">${preview?'演示界面':'员工登录'}</span><div class="login-wordmark" aria-label="方隅公寓，高档一居租方隅"><div class="login-wordmark-top"><span class="login-wordmark-mark"><img src="/assets/fy-approved-official-logo.png" alt="方隅官方标志"></span><strong>方隅公寓</strong></div><small>高档一居租方隅</small></div><h1>欢迎回来</h1><form class="login-form" id="login-form"><label class="field-label" for="login-name">员工用户名</label><div class="login-input">${icon('fy-icon-16-user.png')}<input id="login-name" autocomplete="username" value="${esc(state.rememberedUsername)}" placeholder="请输入用户名" aria-describedby="login-error" ${waiting?'disabled':''}></div><label class="field-label" for="login-pass">密码</label><div class="login-input">${icon('fy-icon-43-lock.png')}<input id="login-pass" type="password" autocomplete="current-password" aria-label="密码" ${waiting?'disabled':''}><button type="button" class="password-eye" aria-label="显示密码">${icon('fy-icon-45-eye.png')}</button></div><div class="login-options"><label class="remember"><input id="login-remember" type="checkbox" ${state.rememberedUsername||preview?'checked':''}>记住用户名</label><button type="button" id="forgot-password">忘记密码？联系管理员。</button></div><button class="login-submit" type="submit" ${waiting?'disabled':''}>${waiting?'正在连接…':'登录工作台'} ${icon('icon-arrow-right.svg')}</button><div class="login-meta"><span><i class="service-dot"></i>${preview?'演示服务已就绪':waiting?'正在连接本地服务':state.connection==='error'?'服务连接待重试':'本地服务已连接'}</span><span><button type="button" id="login-help">使用帮助</button>│&nbsp; v1.0</span></div><p id="login-error" class="login-error" aria-live="polite">${esc(state.connectionError||'')}</p></form></section></main>`;}
function accounts(){return `<div class="account-grid">${['小红书','抖音'].map((p,i)=>`<article class="card account-card"><div class="account-platform">${p}</div><span class="account-state">演示账号 · 已连接</span><h3 style="margin-top:24px">${esc(state.store||'待分配门店')} · 渠道账号</h3><p>当前门店：${esc(state.store||'待分配门店')}</p><p>账号用于搜索、查看客户来源与人工回复。</p><button class="primary" data-account="${i}">查看账号</button><button data-account="${i}">切换账号</button></article>`).join('')}</div>`;}
function tools(){return `<details class="preview-tools"><summary>预览状态</summary><div><span>仅演示数据</span><button data-scenario="normal">正常</button><button data-scenario="empty">空数据</button><button data-scenario="loading">加载中</button><button data-scenario="error">失败与重试</button><button data-scenario="long">长评论</button><button data-nav="login">返回登录</button></div></details>`;}
async function submitLogin(event){
  event.preventDefault();
  const name=document.getElementById('login-name'),password=document.getElementById('login-pass'),error=document.getElementById('login-error'),button=document.querySelector('.login-submit');
  const username=name.value.trim();
  if(!username){error.textContent=state.connection==='preview'?'请输入演示用户名':'请输入员工用户名';name.focus();return;}
  if(state.connection==='preview'){state.user=username;state.store||='古北店';navigate('acquire');toast('欢迎回来，已进入界面预览');return;}
  if(!password.value){error.textContent='请输入密码';password.focus();return;}
  if(state.busy)return;
  state.busy=true;button.disabled=true;error.textContent='正在验证账号…';
  try{
    if(state.connection==='error'){const boot=await backend.bootstrap();if(!boot)throw new Error('当前服务未提供员工登录，请从桌面方隅工作台打开。');acceptBootstrap(boot);}
    acceptBootstrap(await backend.login({username,password:password.value,rememberUsername:document.getElementById('login-remember').checked}));
    password.value='';state.connectionError='';navigate('acquire');toast(state.store?'登录成功，门店：'+state.store:'登录成功，门店待管理员分配');
  }catch(failure){error.textContent=failure.message||'登录未完成，请稍后重试。';password.value='';password.focus();}
  finally{state.busy=false;if(button.isConnected)button.disabled=false;}
}
function render(){
  cleanup?.();cleanup=undefined;document.body.dataset.page=state.page;
  const mod=pages[state.page];
  if(state.page==='login'){
    app.innerHTML=login()+tools();
    document.getElementById('login-form').addEventListener('submit',submitLogin);
    document.querySelector('.password-eye').onclick=()=>{const i=document.getElementById('login-pass');i.type=i.type==='password'?'text':'password';document.querySelector('.password-eye').setAttribute('aria-label',i.type==='text'?'隐藏密码':'显示密码');};
    document.getElementById('forgot-password').onclick=()=>modal({title:'联系管理员',html:'<p>如需重置员工账号，请联系门店管理员。</p>'+ (state.connection==='preview'?'<p class="muted">当前为界面演示，无需输入真实账号或密码。</p>':'<p class="muted">请使用已开通的方隅员工账号登录。</p>')});
    document.getElementById('login-help').onclick=()=>modal({title:'使用帮助',html:state.connection==='preview'?'<p>填写任意演示用户名即可预览工作台。</p><p>可依次查看获客、回复、客户和门店预设。所有操作仅改变本地演示状态。</p>':'<p>使用管理员分配的员工账号与密码登录。勾选“记住用户名”只保存用户名，不保存密码。</p><p>登录后可选择并保存门店获客预设；采集、回复与客户页面仍为示例数据。</p>'});
  }else{
    app.innerHTML=shell(mod?mod.render(state):accounts())+tools();
    if(mod?.bind)cleanup=mod.bind(document.getElementById('page-content'),ctx);
    document.querySelector('.bell').onclick=()=>modal({title:'工作提醒',html:'<p>待回复客户 <strong>12</strong> 位，建议优先查看超高意向和高意向客户。</p><p class="muted">此处为示例提醒。</p>',confirmLabel:'查看意向回复',onConfirm:()=>navigate('reply')});
    document.querySelector('.account-button').onclick=()=>modal({title:(state.user||'演示账号')+' · 渠道运营',html:`<p>当前门店：${esc(state.store||'待管理员分配')}</p><p>${state.connection==='preview'?'演示账号的操作仅保留在当前预览。':'登录与门店预设已接入；采集、回复与客户数据仍为示例。'}</p>`,confirmLabel:state.connection==='preview'?'退出预览':'退出登录',onConfirm:()=>state.connection==='preview'?navigate('login'):logout()});
    document.querySelectorAll('[data-account]').forEach(b=>b.onclick=()=>modal({title:'平台账号',html:'<p>此处仍为平台账号示例。</p><p>真实扫码登录和账号切换将在后续步骤接入。</p>'}));
    document.querySelectorAll('[data-info]').forEach(b=>b.onclick=()=>modal({title:b.dataset.info,html:b.dataset.info==='口吻方案'?'<p>租房顾问 · 亲切</p><p>真实自然地回应客户问题，邀请进一步沟通。</p>':'<p>当前门店和界面方案已准备就绪。</p>'}));
  }
  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
  document.querySelectorAll('[data-scenario]').forEach(b=>b.onclick=()=>{state.scenario=b.dataset.scenario;if(state.scenario==='normal'){state.reply=undefined;state.customers=undefined;}render();toast({normal:'已还原正常示例',empty:'查看空数据状态',loading:'查看加载状态',error:'查看失败与重试',long:'查看长评论状态'}[state.scenario]);});
  document.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',e=>{if(!a.getAttribute('href').startsWith('#')){e.preventDefault();modal({title:'查看源帖',html:'<p>本地预览展示来源信息，不打开真实平台。</p>'});}}));
}
window.addEventListener('hashchange',()=>navigate(location.hash.slice(1)||'login'));
window.addEventListener('error',e=>console.error('Workbench:',e.message));
render();
backend.bootstrap().then(result=>{
  if(result){acceptBootstrap(result);navigate(state.session?initialPage:'login');if(state.notice)toast(state.notice);}
  else{state.connection='preview';state.store='古北店';state.user='小林';navigate(initialPage);}
}).catch(error=>{state.connection='error';state.connectionError=error.message;navigate('login');});
