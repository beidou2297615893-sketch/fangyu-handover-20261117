// Only login and store presets cross this interface. Collection and sending remain examples.
export class WorkbenchError extends Error {
  constructor(message, code='request_failed') { super(message); this.name='WorkbenchError'; this.code=code; }
}

export function createBackend(fetcher=globalThis.fetch.bind(globalThis)) {
  let csrfToken='';
  let mode='loading';
  async function request(action, data) {
    const bootstrap=action==='bootstrap';
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),20000);
    try {
      const response=await fetcher(bootstrap?'/api/workbench/bootstrap':'/api/workbench',bootstrap
        ? {method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal}
        : {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Fangyu-CSRF':csrfToken},body:JSON.stringify({action,data}),signal:controller.signal});
      // The static design preview deliberately has no business interface.
      if(bootstrap&&response.status===404) { mode='preview'; return null; }
      let result;
      try { result=await response.json(); }
      catch { throw new WorkbenchError('本地服务返回异常，请关闭工作台后重新打开。','invalid_response'); }
      if(result?.csrfToken)csrfToken=result.csrfToken;
      if(!response.ok||result?.ok!==true)throw new WorkbenchError(result?.error?.message||'操作未完成，请稍后重试。',result?.error?.code||'request_failed');
      if(bootstrap)mode='connected';
      return result;
    } catch(error) {
      if(error instanceof WorkbenchError)throw error;
      if(error?.name==='AbortError')throw new WorkbenchError('连接超时，请稍后重试。','timeout');
      throw new WorkbenchError('暂时无法连接本地服务，请稍后重试。','connection_failed');
    } finally { clearTimeout(timeout); }
  }
  return {get mode(){return mode;},bootstrap:()=>request('bootstrap'),login:data=>request('login',data),logout:()=>request('logout',{}),selectStore:storeId=>request('select_store',{storeId}),applyPreset:data=>request('apply_preset',data)};
}
