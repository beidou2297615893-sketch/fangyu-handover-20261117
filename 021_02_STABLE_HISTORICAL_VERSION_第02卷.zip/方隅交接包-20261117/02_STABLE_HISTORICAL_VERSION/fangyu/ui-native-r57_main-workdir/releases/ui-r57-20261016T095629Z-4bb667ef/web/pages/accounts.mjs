// Keep the approved two-card layout; the existing runtime owns login and identity checks.
const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const slots=[{id:'xhs',name:'小红书',aliases:['xhs','xiaohongshu']},{id:'douyin',name:'抖音',aliases:['douyin','dy']}];
function platforms(state){return slots.map(slot=>{
  const live=state.platform?.platforms?.find(row=>slot.aliases.includes(row.id));
  const accountId=state.platformAccountSelections?.[live?.id]||live?.accountId,account=state.platform?.accounts?.find(row=>row.id===accountId);
  return {...slot,...live,accountId,status:account?.status||live?.status,requiresReview:account?.requiresReview??account?.requires_review??live?.requiresReview,displayName:slot.name,account,accountName:account?.name||account?.platformNickname||account?.platform_nickname||live?.accountName||'尚未绑定平台账号'};
});}
function status(row,state){
  if(state.platformLoading&&!state.platform)return '正在读取';
  if(!state.platform)return '状态待读取';
  if(!row.enabled)return '未开通';
  const device=state.platform.device||{};
  if(device.bound===false)return '工作台未绑定';
  if(['held','blocked','paused','review_required'].includes(device.state)||row.requiresReview)return '暂停 · 待核验';
  return ({ready:'已连接',connected:'已连接',online:'已连接',logging_in:'连接中',waiting_login:'等待扫码',checking:'核对中',held:'暂停 · 待核验',blocked:'暂停 · 待核验',login_required:'需要登录',disconnected:'未连接',failed:'连接未完成',unverified:'待核验'})[row.status]||'状态待核验';
}
export function render(state){
  if(state.connection==='preview')return `<div class="account-grid">${slots.map((row,index)=>`<article class="card account-card"><div class="account-platform">${row.name}</div><span class="account-state">演示账号 · 已连接</span><h3 style="margin-top:24px">${escape(state.store)} · 渠道账号</h3><p>当前门店：${escape(state.store)}</p><p>账号用于搜索、查看客户来源与人工回复。</p><button class="primary" data-account-preview="${index}">查看账号</button><button data-account-preview="${index}">切换账号</button></article>`).join('')}</div>`;
  return `<div class="account-grid">${platforms(state).map(row=>{
    const label=status(row,state),connected=label==='已连接';
    return `<article class="card account-card"><div class="account-platform">${row.displayName}</div><span class="account-state ${connected?'':'badge medium'}" role="status">${escape(label)}</span><h3 style="margin-top:24px">${escape(row.accountName)}</h3><p>当前门店：${escape(state.store||'待管理员分配')}</p><p>${escape(state.platformError||row.message||state.platform?.device?.message||(row.enabled?'请先检查平台连接状态。':'当前企业尚未开通此平台。'))}</p><button class="primary" data-account-view="${escape(row.id)}" ${state.platformLoading?'disabled':''}>${state.platformLoading?'读取中…':'查看账号'}</button><button data-account-connect="${escape(row.id)}" ${!row.enabled||!row.canConnect||!state.platformActionsReady||state.busy?'disabled':''}>${row.accountId?'重新连接':'连接账号'}</button></article>`;
  }).join('')}</div>`;
}
export function bind(root,ctx){
  function details(platformId){
    const row=platforms(ctx.state).find(item=>item.id===platformId);if(!row)return;
    const choices=(ctx.state.platform?.accounts||[]).filter(item=>row.aliases.includes(item.platform));
    const dialog=ctx.modal({title:row.displayName+' · '+row.accountName,html:`<p>连接状态：${escape(status(row,ctx.state))}</p><p>${escape(ctx.state.platformError||row.message||ctx.state.platform?.device?.message||'当前尚未取得连接回执。')}</p>${choices.length?`<label for="platform-account-choice">门店平台账号</label><select id="platform-account-choice">${choices.map(item=>`<option value="${escape(item.id)}" ${item.id===row.accountId?'selected':''}>${escape(item.name||item.platformNickname||item.id)}</option>`).join('')}</select>`:''}<p class="muted">此处显示当前门店的真实平台状态。</p>${row.enabled?'<button type="button" id="platform-prepare-device">准备本机连接</button>':''}`,confirmLabel:'刷新状态',onConfirm:async()=>{await ctx.actions.refreshPlatform();details(platformId);return false;}});
    dialog.querySelector('#platform-prepare-device')?.addEventListener('click',async()=>{await ctx.actions.preparePlatform();if(dialog.open)details(platformId);});
    dialog.querySelector('#platform-account-choice')?.addEventListener('change',event=>{const id=event.target.value;ctx.update(state=>{state.platformAccountSelections??={};state.platformAccountSelections[row.id]=id;});details(platformId);});
  }
  for(const button of root.querySelectorAll('[data-account-preview]'))button.onclick=()=>ctx.modal({title:'平台账号',html:'<p>此处仍为平台账号示例。</p><p>演示预览不会触发真实扫码或账号切换。</p>'});
  for(const button of root.querySelectorAll('[data-account-view]'))button.onclick=()=>details(button.dataset.accountView);
  for(const button of root.querySelectorAll('[data-account-connect]'))button.onclick=()=>ctx.actions.connectAccount?.(button.dataset.accountConnect);
  return ()=>{};
}
