const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const icon=name=>`<img class="mr-icon" src="/assets/${name}" alt="" aria-hidden="true">`;
const list=value=>Array.isArray(value)?value:[];
const scope=state=>JSON.stringify([state.user||'',state.storeId||'']);
const disabledIntent=item=>!item||item.disabled===true||item.enabled===false||(item.id==='rental-evidence'&&item.assessmentEnabled!==true);
function ui(state){
  state.managementRules??={};
  if(state.managementRules.actor!==scope(state))state.managementRules={actor:scope(state),storeChoice:state.storeId||'',phase:'idle',message:''};
  return state.managementRules;
}
function eligibleWords(material,searchId){
  return list(material?.keywords).filter(word=>word.eligible===true&&list(word.bindings).some(binding=>list(binding.presetIds).includes(searchId)&&(!binding.materialKey||binding.materialKey===material.key)));
}
function view(state){
  const p=state.presets||{},current=state.materials?.currentSelection,stores=list(state.stores),searches=list(state.catalog?.search),intents=list(state.catalog?.intent);
  const searchId=p.search??state.selection?.searchPresetId??'',intentId=p.intent??state.selection?.intentPresetId??'';
  const search=searches.find(item=>item.id===searchId),intent=intents.find(item=>item.id===intentId);
  const materialKey=p.materialKey||current?.materialKey||'',material=list(state.materials?.materials).find(item=>item.key===materialKey);
  const eligible=eligibleWords(material,searchId),stored=list(p.keywordIds).length?list(p.keywordIds):list(current?.selectedKeywordIds);
  const ids=stored.length?[...stored]:eligible.slice(0,100).map(word=>word.id);
  const selected=eligible.filter(word=>ids.includes(word.id));
  const actorMatches=current?.storeId===state.storeId&&current.materialKey===materialKey&&stores.some(store=>store.id===state.storeId);
  const invalidIds=ids.some(id=>!list(material?.keywords).some(word=>word.id===id&&word.eligible===true));
  const ready=state.connection==='connected'&&Boolean(state.storeId&&state.capabilities?.presets&&material&&actorMatches&&search&&!disabledIntent(intent)&&selected.length&&ids.length<=100&&!invalidIds);
  return {p,current,stores,searches,intents,searchId,intentId,search,intent,materialKey,material,eligible,ids,selected,ready};
}
function notice(state,v,u){
  if(state.connection==='loading'||state.busy)return u.phase==='saving'?'正在保存…':'正在加载…';
  if(u.message)return u.message;
  if(state.workspaceError)return '门店资料暂未加载';
  if(!v.stores.length)return '暂未分配门店';
  if(!state.storeId)return '请选择门店';
  if(!v.material||!v.search)return '门店方案待加载';
  if(disabledIntent(v.intent))return '请选择已开放的意向方案';
  if(!v.selected.length)return '当前方案暂无可用词';
  if(v.ids.length>100)return '本次选词超过100个，请在门店预设调整';
  return '';
}
function choice(item,current,kind,busy,index){
  const disabled=busy||(kind==='intent'&&disabledIntent(item));
  return `<label class="mr-choice ${current===item.id?'is-selected':''} ${disabled?'is-disabled':''}" for="mr-${kind}-${index}"><input id="mr-${kind}-${index}" type="radio" name="mr-${kind}" data-mr-${kind} value="${escape(item.id)}" ${current===item.id?'checked':''} ${disabled?'disabled':''}><span>${escape(item.name||item.id)}${kind==='intent'&&disabledIntent(item)?'（未启用）':''}</span></label>`;
}
export function render(state){
  const u=ui(state),v=view(state),busy=Boolean(state.busy||u.phase==='saving'||u.phase==='switching'),message=notice(state,v,u);
  const rule=state.materials?.intentRule||{},summary=state.materials?.rulesSummary||{};
  // Public bootstrap exposes draft signals and price status, but no unified exclusion field.
  // These overview controls disclose source state; they do not edit collection filters.
  const activeRule=v.intent?.assessmentEnabled===true&&rule.enabled===true;
  const priceVerified=summary.priceVerified===true&&rule.currentPricesVerified===true&&v.material?.priceVerified===true;
  const evidenceText=activeRule?'查看当前判断依据':'中央规则未启用';
  const availableIntents=v.intents.filter(item=>['standard','recent','rental-evidence'].includes(item.id)||!disabledIntent(item));
  return `<div class="management-rules" data-management-rules>
    <section class="mr-card mr-store-bar" aria-label="当前门店">
      <div class="mr-store-heading"><h2>当前门店</h2><span class="mr-neutral">按门店保存</span></div>
      <div class="mr-store-controls"><label class="mr-store-select" for="mr-store-choice">${icon('tabler-upgrade-pin.svg')}<select id="mr-store-choice" data-mr-store aria-label="当前门店" ${busy||!v.stores.length?'disabled':''}><option value="" ${!u.storeChoice?'selected':''} disabled>选择门店</option>${v.stores.map(store=>`<option value="${escape(store.id)}" ${u.storeChoice===store.id?'selected':''}>${escape(store.name||store.id)}</option>`).join('')}</select>${icon('tabler-chevron-down.svg')}</label><button type="button" class="mr-switch" data-mr-switch ${busy||!u.storeChoice||u.storeChoice===state.storeId?'disabled':''}>${icon('fy-icon-63-refresh.png')}切换门店</button></div>
    </section>
    <div class="mr-columns">
      <section class="mr-card mr-column" aria-label="搜索方案">
        <header class="mr-card-heading">${icon('approved-icon-search.svg')}<h2>搜索方案</h2></header>
        <div class="mr-column-content">
          <section class="mr-field"><h3>搜索模式</h3><div class="mr-choices" role="group" aria-label="搜索模式">${v.searches.map((item,index)=>choice(item,v.searchId,'search',busy,index)).join('')||'<span class="mr-empty">暂无搜索方案</span>'}</div></section>
          <section class="mr-field"><h3>覆盖方向</h3><div class="mr-tags">${v.selected.slice(0,3).map(word=>`<span title="${escape(word.keyword)}">${escape(word.keyword)}</span>`).join('')||'<span class="mr-empty">当前方案暂无可用词</span>'}</div></section>
          <section class="mr-field"><h3>排除内容</h3><button type="button" class="mr-overview" data-mr-detail="exclude">未提供统一排除项${icon('tabler-chevron-down.svg')}</button></section>
        </div>
        <button type="button" class="mr-card-summary" data-mr-detail="words">${icon('approved-icon-search.svg')}<span>${v.selected.length?escape(v.search?.name||'搜索方案')+' · '+v.selected.length+'个搜索词':'查看当前搜索方案'}</span></button>
      </section>
      <section class="mr-card mr-column" aria-label="客户判断">
        <header class="mr-card-heading">${icon('tabler-upgrade-user.svg')}<h2>客户判断</h2></header>
        <div class="mr-column-content">
          <section class="mr-field"><h3>意向方案</h3><div class="mr-choices" role="group" aria-label="意向方案">${availableIntents.map((item,index)=>choice(item,v.intentId,'intent',busy,index)).join('')||'<span class="mr-empty">暂无意向方案</span>'}</div></section>
          <section class="mr-field"><h3>判断依据</h3><button type="button" class="mr-overview" data-mr-detail="evidence">${evidenceText}${icon('tabler-chevron-down.svg')}</button></section>
          <section class="mr-field"><h3>预算依据</h3><div class="mr-budget"><button type="button" class="mr-overview" data-mr-detail="budget">门店预算规则${icon('tabler-chevron-down.svg')}</button><span class="mr-budget-state ${priceVerified?'is-verified':''}">${priceVerified?'资料已核价':'待核实'}</span></div></section>
        </div>
        <button type="button" class="mr-card-summary" data-mr-detail="evidence">${icon('tabler-upgrade-user.svg')}<span>${activeRule?'查看当前判断规则':'沿用历史意向偏好'}</span></button>
      </section>
    </div>
    <section class="mr-card mr-save-bar" aria-label="方案保存"><div class="mr-save-copy"><strong><span>当前方案：</span>${escape(v.search?.name||'待选择')} · ${escape(v.intent?.name||'待选择')}</strong><span class="mr-status" role="${u.phase==='error'?'alert':'status'}" aria-live="polite">${escape(message)}</span></div><button type="button" class="mr-save" data-mr-save ${busy||!v.ready?'disabled':''}>${icon('tabler-upgrade-file.svg')}${u.phase==='saving'?'保存中…':'保存方案'}</button></section>
  </div>`;
}
function details(state,kind){
  const v=view(state),rule=state.materials?.intentRule||{},summary=state.materials?.rulesSummary||{};
  if(kind==='exclude')return {title:'排除内容',html:'<p>当前门店资料未提供统一排除项。</p><p>此页不会新增或修改采集过滤规则。</p>'};
  if(kind==='words')return {title:'当前搜索方案',html:`<p>${escape(v.search?.name||'暂未选择')} · ${v.selected.length}个搜索词</p><div class="mr-detail-words">${v.selected.map(word=>`<span>${escape(word.keyword)}</span>`).join('')||'当前方案暂无可用词。'}</div>${v.eligible.length>100?'<p>本次最多使用100个，其余源词保留在门店资料中。</p>':''}`};
  if(kind==='budget')return {title:'预算依据',html:`<p>${summary.priceVerified===true&&rule.currentPricesVerified===true&&v.material?.priceVerified===true?'门店资料已核价。':'门店价格尚未核实，预算匹配保持待确认。'}</p>${list(rule.budgetPrinciples).slice(0,3).map(text=>`<p>${escape(text)}</p>`).join('')}`};
  return {title:'判断依据',html:`<p>${escape(v.intent?.description||'当前意向方案暂无详细说明。')}</p><p>${v.intent?.assessmentEnabled===true&&rule.enabled===true?'以下为当前规则来源。':'中央租房与预算规则尚未启用；以下仅为资料中的草稿依据。'}</p>${list(rule.signals).slice(0,3).map(text=>`<p>${escape(text)}</p>`).join('')}`};
}
export function bind(root,ctx){
  let disposed=false;
  const boundUser=ctx.state.user||'';
  const boundScope=scope(ctx.state);
  const change=fn=>ctx.update(state=>{fn(ui(state),state);});
  const canMutate=()=>!disposed&&scope(ctx.state)===boundScope&&!ctx.state.busy&&!['saving','switching'].includes(ui(ctx.state).phase);
  root.querySelector('[data-mr-store]')?.addEventListener('change',event=>{if(canMutate())change(u=>{u.storeChoice=event.target.value;u.message='';});});
  root.querySelector('[data-mr-switch]')?.addEventListener('click',async()=>{
    if(!canMutate())return;
    const v=view(ctx.state),id=ui(ctx.state).storeChoice;
    if(!id||id===ctx.state.storeId||!v.stores.some(store=>store.id===id))return;
    if(typeof ctx.actions?.selectStore!=='function'){change(u=>{u.phase='error';u.message='切换暂不可用';});return;}
    change(u=>{u.phase='switching';u.message='';});
    try{await ctx.actions.selectStore(id);if((ctx.state.user||'')===boundUser&&ctx.state.storeId!==id)change(u=>{u.phase='error';u.message='门店尚未切换，请核对后重试';});}
    catch(error){if((ctx.state.user||'')===boundUser)change(u=>{u.phase='error';u.message=error?.message||'门店切换失败';});}
    finally{if((ctx.state.user||'')===boundUser&&ui(ctx.state).phase==='switching')change(u=>{u.phase='idle';});}
  });
  root.querySelectorAll('[data-mr-search]').forEach(input=>input.addEventListener('click',()=>{
    if(!canMutate())return;
    const v=view(ctx.state),id=input.value;
    if(!v.searches.some(item=>item.id===id)||!v.material)return;
    change((u,state)=>{state.presets??={};Object.assign(state.presets,{search:id,materialKey:v.material.key,keywordIds:eligibleWords(v.material,id).slice(0,100).map(word=>word.id)});u.phase='idle';u.message='';});
  }));
  root.querySelectorAll('[data-mr-intent]').forEach(input=>input.addEventListener('click',()=>{
    if(!canMutate())return;
    const option=view(ctx.state).intents.find(item=>item.id===input.value);
    if(disabledIntent(option))return;
    change((u,state)=>{state.presets??={};state.presets.intent=option.id;u.phase='idle';u.message='';});
  }));
  root.querySelectorAll('[data-mr-detail]').forEach(button=>button.addEventListener('click',()=>{
    if(disposed||scope(ctx.state)!==boundScope)return;
    const info=details(ctx.state,button.dataset.mrDetail);
    ctx.modal?.({...info,confirmLabel:'知道了'});
  }));
  root.querySelector('[data-mr-save]')?.addEventListener('click',async()=>{
    if(!canMutate())return;
    const v=view(ctx.state);if(!v.ready)return;
    if(typeof ctx.actions?.applyPreset!=='function'){change(u=>{u.phase='error';u.message='保存暂不可用';});return;}
    const expected={actor:scope(ctx.state),storeId:ctx.state.storeId,search:v.searchId,intent:v.intentId,revision:ctx.state.selection?.revision??0};
    change((u,state)=>{state.presets??={};Object.assign(state.presets,{search:v.searchId,intent:v.intentId,materialKey:v.materialKey,keywordIds:[...v.ids]});u.phase='saving';u.message='';});
    try{
      const result=await ctx.actions.applyPreset();
      if(scope(ctx.state)!==expected.actor)return;
      const saved=ctx.state.selection,confirmed=saved?.storeId===expected.storeId&&saved.searchPresetId===expected.search&&saved.intentPresetId===expected.intent&&Number(saved.revision)>expected.revision;
      change(u=>{u.phase=confirmed||result===true||result?.ok===true?'saved':'error';u.message=u.phase==='saved'?'方案已保存':'保存结果待确认，请核对状态';});
    }catch(error){if(scope(ctx.state)===expected.actor)change(u=>{u.phase='error';u.message=error?.message||'保存失败，请稍后重试';});}
  });
  return ()=>{disposed=true;};
}

