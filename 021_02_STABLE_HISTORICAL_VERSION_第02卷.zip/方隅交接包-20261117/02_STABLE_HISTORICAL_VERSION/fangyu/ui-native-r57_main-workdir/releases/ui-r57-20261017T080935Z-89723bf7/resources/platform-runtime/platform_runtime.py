"""Explicit customer account/collection adapter over the preserved r55 runtime.

No platform or cloud action starts during construction. A verified frontend
principal is required for every public operation. The original AppServer,
AssistantService and BusinessExecutor types retain their authority checks.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import threading
import time


COMPANY_ID = 'fangyu-apartment-client'
DIRECTORY = Path(__file__).resolve().parent
_BROWSER_LOGIN_HELPER_SHA = 'D6AE06D517DDBB08EEB9059E759A402EBA02CFB56950F263539D2BC3FAB06E5C'


def _browser_login_helper_valid(path):
    """Recheck the one frozen source helper immediately before child launch."""
    from core.runtime_license_policy import _plain, _file_hash
    expected = DIRECTORY / 'vendor-src/assistant/browser_login_window.py'
    try:
        if Path(path) != expected:
            return False
        checked = _plain(expected, expected.parent)
        return _file_hash(checked).upper() == _BROWSER_LOGIN_HELPER_SHA
    except (OSError, ValueError, TypeError):
        return False


class PlatformRuntimeError(ValueError):
    def __init__(self, code, message, status=409, *, mutation_committed=False):
        super().__init__(message)
        self.code, self.status = code, status
        self.mutation_committed = mutation_committed


def _load(name, path, **values):
    previous = sys.modules.get(name)
    if previous is not None:
        if Path(previous.__file__).resolve() != path.resolve():
            raise PlatformRuntimeError('RUNTIME_IMPORT_CONFLICT', '已有运行组件来源不同，请独立重开开发后台', 503)
        if any(getattr(previous,key,None) != value for key,value in values.items()):
            raise PlatformRuntimeError('RUNTIME_PROJECT_CONFLICT', '运行组件已绑定其他工程，请独立重开开发后台', 503)
        return previous
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    module.__dict__.update(values)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


def _modules(project):
    source = project / 'work/ui-runtime-r55/src'
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))
    _load('account_connections', DIRECTORY / 'vendor-src/account_connections.py',
          __FANGYU_SOURCE_ROOT__=str(source))
    _load('assistant.employee_distribution', DIRECTORY / 'vendor-src/assistant/employee_distribution.py')
    _load('assistant.business', DIRECTORY / 'vendor-src/assistant/business.py')
    _load('assistant.dy_browser_login', DIRECTORY / 'vendor-src/assistant/dy_browser_login.py')
    _load('assistant.douyin_connection_service', DIRECTORY / 'vendor-src/assistant/douyin_connection_service.py',
        __FANGYU_SOURCE_ROOT__=str(source),
        __FANGYU_DOUYIN_REVIEW_PATH__=str(DIRECTORY / 'vendor-src/douyin-connection-review.json'))
    app = _load('app', DIRECTORY / 'vendor-src/app.py',
                __FANGYU_SOURCE_ROOT__=str(source),
                __FANGYU_RUNTIME_ROOT__=str(project / 'work/app/work/runtime'),
                __FANGYU_GUARDED_CLI_RUNTIME_ROOT__=str(project / 'work/overnight-platforms-20261014/runtime-integration-candidate/guarded-cli'),
                __FANGYU_DOUYIN_RUNTIME_ROOT__=str(project / 'work/ui-runtime-r55/work/runtime/douyin-bridge'))
    _load('assistant.runner', DIRECTORY / 'vendor-src/assistant/runner.py')
    _load('assistant.browser_login_window', DIRECTORY / 'vendor-src/assistant/browser_login_window.py')
    _load('assistant.browser_login_service', DIRECTORY / 'vendor-src/assistant/browser_login_service.py')
    _load('assistant.xhs_browser_login', DIRECTORY / 'vendor-src/assistant/xhs_browser_login.py')
    service = _load('assistant.service', DIRECTORY / 'vendor-src/assistant/service.py')
    return app, service


class PlatformRuntime:
    def __init__(self, project_root, core=None, company=None, data_dir=None, *, cloud_factory=None):
        self.project = Path(project_root).resolve()
        if core is not None:
            raise PlatformRuntimeError('CORE_OWNERSHIP', '平台运行库需拥有同一原始 Core，请由后台复用 runtime.core', 503)
        if company is None:
            company = json.loads((self.project / 'work/app/company.json').read_text('utf-8-sig'))
        company = deepcopy(company)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        if (not isinstance(company, dict) or company.get('id') != COMPANY_ID
                or company.get('edition') != 'customer' or company.get('personalMode') is not False
                or company.get('authMode') != 'managed' or not isinstance(managed, dict)
                or not managed.get('environment_id') or not managed.get('endpoint')):
            raise PlatformRuntimeError('CUSTOMER_CONFIG_REQUIRED', '只能使用当前方隅客户员工配置', 503)
        self.data_dir = Path(data_dir).resolve() if data_dir is not None else (
            Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) / (COMPANY_ID + 'Workspace')).resolve()
        self._instance_lock = None
        self._acquire_instance_lock()
        try:
            app, service = _modules(self.project)
            self.server = app.AppServer(('127.0.0.1', 0), self.data_dir,
                employee_workspace=True, trusted_company=company,
                defer_startup_recovery=True, defer_platform_setup=True)
        except BaseException:
            self._release_instance_lock()
            raise
        self.core = self.server.core
        self.server.update_startup_gate = None
        self.server.update_startup_pending = False
        self.server.explicit_local_actions = True
        self.server.browser_login_enabled = True
        self.server.browser_login_helper_path = DIRECTORY / 'vendor-src/assistant/browser_login_window.py'
        self.server.browser_login_helper_validator = _browser_login_helper_valid
        options = {'cloud_factory': cloud_factory} if cloud_factory is not None else {}
        try:
            self.service = service.AssistantService(self.server, explicit_local=True, **options)
        except BaseException:
            try:
                self.server.close_owned_jobs()
                self.server.server_close()
            finally:
                self._release_instance_lock()
            raise
        self.server.assistant_service = self.service
        self.integrations = self.server.integrations
        self.lock = threading.RLock()
        self.closed = False
        self.started = False
        self._platform_setup = False
        self._runs = {}
        self._run_lock = threading.RLock()

    def _acquire_instance_lock(self):
        self.data_dir.mkdir(parents=True,exist_ok=True)
        stream = (self.data_dir / 'instance.lock').open('a+b')
        try:
            import msvcrt
            stream.seek(0)
            if not stream.read(1):
                stream.write(b'1')
                stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        except (OSError,ImportError):
            stream.close()
            raise PlatformRuntimeError('WORKSPACE_IN_USE','当前员工工作台已在其他进程中打开，请先正常退出原工作台',409) from None
        self._instance_lock = stream

    def _release_instance_lock(self):
        stream, self._instance_lock = self._instance_lock, None
        if stream is None:
            return
        try:
            import msvcrt
            stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
        finally:
            stream.close()

    def _principal(self, user):
        if self.closed:
            raise PlatformRuntimeError('RUNTIME_CLOSED', '工作台正在关闭，请重新打开', 503)
        expected_tenant = 'cloud-' + hashlib.sha256((
            self.server.company['managedWorkspace']['environment_id'] + '\n' + COMPANY_ID).encode()).hexdigest()[:24]
        saved = self.core.store.get('users', user.get('id')) if isinstance(user, dict) else None
        if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('development_local_only') is True or saved.get('role') not in ('operator','admin')
                or saved.get('tenant_id') != expected_tenant
                or any(saved.get(key) != user.get(key) for key in ('id','tenant_id','username','role'))):
            raise PlatformRuntimeError('AUTH_REQUIRED', '请先使用当前企业员工账号登录', 401)
        return {**self.core._public(saved),'_workbench_store_id':user.get('_workbench_store_id','')}

    def _device(self, user):
        saved = self.service.vault.read()
        device = self.service.device or (saved or {}).get('device') or {}
        owner = device.get('owner')
        if owner and owner != user['username']:
            return {'state': 'other_owner', 'bound': False,
                    'message': '这台电脑已绑定其他员工，请管理员核对设备归属'}
        state = self.service.state
        bound = bool(saved and saved.get('state') == 'bound' and device.get('id'))
        messages = {'unbound':'请连接当前员工电脑', 'pending':'电脑绑定等待确认',
                    'binding':'正在连接当前电脑', 'offline':'电脑已绑定，等待企业连接',
                    'online':'企业连接已确认', 'held':'企业连接保持安全暂停',
                    'revoked':'设备授权已撤回，请管理员核对', 'error':'设备连接未完成，请手动重试',
                    'stopped':'设备连接已停止，请手动重试'}
        reason=getattr(self.service,'employee_release_reason','')
        message=messages.get(state,'设备连接待核对')
        if state=='held' and reason in ('ROLE_INELIGIBLE','POLICY_DISABLED','VERSION_MISMATCH'):
            message={'ROLE_INELIGIBLE':'本机已绑定，当前管理员设备许可尚待开通',
                     'POLICY_DISABLED':'本机已绑定，企业设备许可尚待开通',
                     'VERSION_MISMATCH':'本机已绑定，请更新到当前允许的平台运行版本'}[reason]
        return {'state':state, 'bound':bound, 'message':message,
                'reasonCode':reason if reason in ('ROLE_INELIGIBLE','POLICY_DISABLED','VERSION_MISMATCH',
                    'DEVICE_REVOKED','OWNER_INACTIVE','DEVICE_OFFLINE','ALLOWED') else ''}

    def _prepare_for_connection(self, user):
        """One explicit connect click prepares this employee's own runtime.

        Preparation may enroll a device and start its existing heartbeat. It
        does not create a platform account, open a login or collect anything.
        A subsequent status read must confirm the authenticated lease.
        """
        device = self._device(user)
        if (not self._platform_setup or not device['bound']
                or self.service.executor is None or self.service.state in ('unbound','offline','stopped','error')):
            self.prepare(user)
        deadline=time.monotonic()+6
        while (self.service.state in ('binding','offline','unbound')
                and self.service.thread is not None and self.service.thread.is_alive()
                and time.monotonic()<deadline):
            self.service.stop_event.wait(.05)
        self._executor(user)

    def _executor(self, user, *, online=True):
        user = self._principal(user)
        device = self._device(user)
        executor = self.service.executor
        if (not device['bound'] or executor is None or self.service.closed
                or self.service.state not in (('online',) if online else ('online','held'))
                or executor.core is not self.core or executor.owner != user['username']
                or executor.tenant != user['tenant_id'] or executor.user_id != user['id']):
            raise PlatformRuntimeError('DEVICE_NOT_READY', device['message'])
        session = getattr(executor, '_xhs_app_session', None)
        if session is None:
            raise PlatformRuntimeError('DEVICE_SESSION_UNAVAILABLE', '设备员工会话尚未确认')
        try:
            session.check()
        except Exception:
            raise PlatformRuntimeError('DEVICE_SESSION_UNAVAILABLE', '设备员工会话尚未确认') from None
        runtime=self.server.company.get('runtime') or {}
        if (online and runtime.get('workbench_source_release')=='fangyu-admin-local-v1'
                and not self.core._employee_release_allowed()):
            raise PlatformRuntimeError('DEVICE_LEASE_UNCONFIRMED','当前本机平台许可尚未确认，请等待设备状态刷新')
        return executor

    def _account(self, user, ident):
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
            raise PlatformRuntimeError('INVALID_INPUT','平台账号编号无效',400)
        try:
            account=self.core._get('accounts',ident,user['tenant_id'])
            self.core._account_access(user,account)
            if user.get('role') == 'admin' and (account.get('cloud_owner') != user['username']
                    or not user.get('_workbench_store_id') or account.get('store_id') != user['_workbench_store_id']):
                raise ValueError('账号不属于当前管理员与门店')
            self.core.require_platform(account.get('platform'))
            return account
        except ValueError:
            raise PlatformRuntimeError('ACCOUNT_FORBIDDEN','账号不存在或不属于当前员工',403) from None

    def _task(self, user, ident):
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
            raise PlatformRuntimeError('INVALID_INPUT','采集任务编号无效',400)
        try:
            task=self.core._get('tasks',ident,user['tenant_id'])
            self.core._task_access(user,task,user['tenant_id'])
            if user.get('role') == 'admin' and (task.get('cloud_owner') != user['username']
                    or not user.get('_workbench_store_id') or task.get('store_id') != user['_workbench_store_id']):
                raise ValueError('任务未绑定当前管理员与门店')
            return task
        except ValueError:
            raise PlatformRuntimeError('TASK_FORBIDDEN','任务不存在或不属于当前员工',403) from None

    def _readiness(self, user, account=None):
        device = self._device(user)
        if not device['bound'] or self.service.state != 'online' or self.service.executor is None:
            return 'device_not_ready', device['message']
        runtime=self.server.company.get('runtime') or {}
        if (runtime.get('workbench_source_release')=='fangyu-admin-local-v1'
                and not self.core._employee_release_allowed()):
            return 'device_lease_unconfirmed','当前本机平台许可尚未确认，请等待设备状态刷新'
        if account and account.get('platform') not in self.server.company.get('platforms', []):
            return 'platform_forbidden', '当前企业未开放此平台'
        if account and account.get('platform') == 'xiaohongshu':
            runtime = self.server.company.get('runtime') or {}
            if runtime.get('xiaohongshu_automation') == 'hold' and not self.core._employee_release_allowed() and not self.core._page_read_allowed():
                return 'platform_held', '小红书平台操作保持原有安全暂停，请先核对企业平台许可'
        if self.core.remote_safety_hold:
            return 'platform_held', '企业服务尚未确认平台操作，已保留现有账号与断点'
        if account and account.get('platform') == 'xiaohongshu':
            from core.account_safety import account_review_view
            review = account_review_view(self.data_dir / 'accounts' / user['tenant_id'] / account['id'] / 'platform-activity.jsonl')
            if review.get('requires_review'):
                return 'account_review_required', '账号存在待复核的安全提醒，已停止平台操作'
        return '', ''

    def snapshot(self, user):
        user = self._principal(user)
        from assistant.business import account_view
        accounts = self.core.handle('list', {'entity':'accounts'}, user)
        tasks = self.core.handle('list', {'entity':'tasks'}, user)
        if user.get('role') == 'admin':
            selected=user.get('_workbench_store_id')
            accounts=[row for row in accounts if selected and row.get('cloud_owner')==user['username']
                and row.get('store_id') == selected]
            tasks=[row for row in tasks if selected and row.get('cloud_owner')==user['username']
                and row.get('store_id')==selected]
        tasks.sort(key=lambda row:(str(row.get('updated_at','')),str(row.get('created_at',''))), reverse=True)
        projected = []
        for account in accounts:
            code, message = self._readiness(user, account)
            projected.append({**account_view(account), 'name':str(account.get('platform_nickname') or account.get('name') or '')[:100],
                'requiresReview':code == 'account_review_required', 'canConnect':not code,
                'message':message, 'reasonCode':code})
        platforms = []
        for platform, name in (('xiaohongshu','小红书'),('douyin','抖音')):
            allowed = platform in self.server.company.get('platforms', [])
            account = next((row for row in projected if row['platform'] == platform), None)
            code, message = self._readiness(user, {'id':account['id'] if account else '', 'platform':platform}) if allowed else (
                'platform_forbidden','当前企业未开放此平台')
            platforms.append({'id':platform,'name':name,'enabled':allowed,
                'accountId':account['id'] if account else '', 'accountName':account['name'] if account else '',
                'status':account.get('status','disconnected') if account else 'disconnected',
                'requiresReview':bool(account and account['requiresReview']),
                'canConnect':not code, 'message':message, 'reasonCode':code})
        task = tasks[0] if tasks else None
        progress = (self.core.task_progress(task['id']) or {}) if task else {}
        continuous = self.core.continuous.status(task) if task and task.get('continuous_enabled') else {}
        local_thread=self._runs.get(task['id']) if task else None
        active = bool(task and (task['id'] in self.core.running or task['id'] in self.core.sequences
            or continuous.get('inflight') or local_thread is not None and local_thread.is_alive()))
        account = (next((row for row in accounts if row['id'] == task.get('account_id')), None) if task else
                   next((row for row in accounts if row.get('status') == 'ready'), accounts[0] if accounts else None))
        code, message = self._readiness(user, account)
        if not code and (not account or account.get('status') != 'ready'):
            code, message = 'account_not_ready','请先连接并核实当前平台账号'
        status = 'running' if active else (task.get('status','idle') if task else 'idle')
        if not active and task and status != 'paused':
            terminal=progress.get('state')
            sequence=task.get('sequence_status')
            if terminal in ('completed','failed','paused','stopped'):
                status=terminal
            elif sequence in ('completed','failed','stopped'):
                status=sequence
        counts = {'read':0,'added':0,'analyzed':0,'duplicates':0}
        for target, field in (('read','read'),('added','imported'),('duplicates','duplicates')):
            value = progress.get(field, continuous.get(field, 0))
            if type(value) is int and value >= 0:
                counts[target] = value
        if task:
            visible_leads = [row for row in self.core.store.list('leads',user['tenant_id'])
                if row.get('task_id') == task['id'] and not row.get('demo')]
            counts['added'] = len(visible_leads)
            counts['analyzed'] = sum(1 for row in visible_leads if isinstance(row.get('manual_intent') or row.get('ai_intent'),dict)
                and (row.get('manual_intent') or row.get('ai_intent')).get('status') in ('graded','uncertain','unrelated'))
        if not active and status != 'paused' and progress.get('state') == 'failed':
            status = 'failed'
            message = message or '本批采集未完成，已保存内容与原断点保留，请核对账号或平台许可'
        raw_workspace = {'accounts':projected,'tasks':[{key:row[key] for key in (
            'id','name','platform','account_id','status','scope','created_at','updated_at','continuous_enabled') if key in row} for row in tasks[:100]]}
        return {'device':self._device(user), 'platforms':platforms,'accounts':projected,
            'acquisition':{'taskId':task['id'] if task else '', 'status':status,
                'phase':progress.get('stage','idle'), 'counts':counts,'records':[],'recent':[],
                'canStart':not code and not active, 'canPause':active,
                'canResume':bool(task and status == 'paused' and not code),
                'message':message or ('正在采集，等待真实后台返回' if active else '已暂停，原断点保留' if status == 'paused'
                    else '本批采集已完成，已保存真实结果' if status == 'completed' else '请选择条件后开始采集'),
                'reasonCode':code},
            'capabilities':{'accounts':True,'collection':not code,'automaticAI':False,
                'automaticReply':False,'remoteCommands':False,'automaticUpdates':False},
            'rawWorkspace':raw_workspace}

    def prepare(self, user):
        user = self._principal(user)
        if self._device(user)['state'] == 'other_owner':
            raise PlatformRuntimeError('DEVICE_OWNER_MISMATCH', '这台电脑已绑定其他员工，请管理员核对')
        with self.lock:
            if not self._platform_setup:
                self.server._configure_bundled()
                self._platform_setup = True
            if not self._device(user)['bound']:
                from assistant.employee_workspace import pair
                pair(self.server, user)
            else:
                self.service.start()
            self.started = True
        return self.snapshot(user)

    def create_account(self, user, data):
        user = self._principal(user)
        if (type(data) is not dict or set(data) != {'platform','name'}
                or data.get('platform') not in self.server.company.get('platforms', [])):
            raise PlatformRuntimeError('PLATFORM_FORBIDDEN', '请选择当前企业已开放的平台', 403)
        if not isinstance(data['name'],str) or not 1 <= len(data['name'].strip()) <= 100 or any(ord(char)<32 for char in data['name']):
            raise PlatformRuntimeError('INVALID_INPUT','请填写1至100字的账号名称',400)
        self._prepare_for_connection(user)
        executor = self._executor(user, online=False)
        if data['platform'] == 'xiaohongshu':
            code,message=self._readiness(user,{'id':'','platform':'xiaohongshu'})
            if code:
                raise PlatformRuntimeError(code.upper(),message)
            result = self._execute(executor,user,'account_create',data)
        else:
            result = self.service.create_account_slot(data)
        row = result.get('account') if isinstance(result,dict) and isinstance(result.get('account'),dict) else result
        ident = row.get('id') if isinstance(row,dict) else None
        if not isinstance(ident,str):
            raise PlatformRuntimeError('ACCOUNT_RESULT_UNCONFIRMED','账号记录已提交，结果需刷新核对，请勿重复创建',503,mutation_committed=None)
        if user.get('role') == 'admin':
            record=self.core._get('accounts',ident,user['tenant_id'])
            selected=user.get('_workbench_store_id')
            if (not selected or record.get('cloud_owner') != user['username']
                    or record.get('store_id') not in (None,'',selected)):
                raise PlatformRuntimeError('ACCOUNT_SCOPE_UNCONFIRMED','新账号归属未核实，请保留原结果核对',503,mutation_committed=True)
            record['store_id']=selected
            self.core.store.put('accounts',record)
        self._account(user,ident)
        return {'result':{'accountId':ident,'status':'created','message':'账号记录已创建，请连接并核实平台身份'}, **self.snapshot(user)}

    def connect_account(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'accountId'}:
            raise PlatformRuntimeError('INVALID_INPUT', '连接账号参数无效', 400)
        self._prepare_for_connection(user)
        account = self._account(user,data['accountId'])
        code, message = self._readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        if account['platform'] == 'xiaohongshu':
            result = self.service.start_account_login(account['id'])
        elif account['platform'] == 'douyin':
            result = self.service.douyin_connection('start', {'account_id':account['id']})
        else:
            raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','此平台尚未接入当前账号连接界面')
        if account['platform'] == 'xiaohongshu':
            result=self._login_result(user,result)
        else:
            result=self._douyin_result(result)
        return {'result':result, **self.snapshot(user)}

    @staticmethod
    def _douyin_result(value):
        value=value if isinstance(value,dict) else {}
        state=value.get('state','unknown')
        confirmed=(state=='ready' and value.get('platform_login_confirmed') is True
                   and value.get('binding_verified') is True)
        messages={'ready':'抖音平台身份已核实，请按采集条件开始',
                  'waiting_login':'请在抖音窗口完成本人登录，然后检查连接',
                  'checking':'正在核实抖音登录状态',
                  'choose_window':'抖音窗口归属未确认，请保留本次打开的登录窗口',
                  'disconnected':'抖音登录窗口未连接，请重新连接',
                  'failed':'抖音登录未完成，请核对本次登录窗口'}
        message=value.get('message')
        message=message[:1000] if isinstance(message,str) else ''
        # An unverified ready claim never supplies a success message.
        if state=='ready' and not confirmed:message='抖音平台身份尚未核实，请检查连接'
        return {'id':'','status':'ready' if confirmed else state if state in messages and state!='ready' else 'unknown',
                'platformLoginConfirmed':confirmed,'bindingVerified':confirmed,
                'windowOpen':value.get('owned_window_active') is True,
                'persistentBrowser':value.get('owned_window_active') is True,
                'errorCode':value.get('error_code') if value.get('error_code')=='LOGIN_WINDOW_PROCESS_FAILED' else '',
                'message':message or messages.get(state,'抖音连接结果尚未确认，请检查连接')}

    def check_account(self, user, data):
        """Read only the current employee/store account's actual platform state."""
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'accountId'}:
            raise PlatformRuntimeError('INVALID_INPUT','检查账号参数无效',400)
        self._prepare_for_connection(user)
        account=self._account(user,data['accountId'])
        code,message=self._readiness(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message)
        if account['platform']=='douyin':
            result=self._douyin_result(self.service.douyin_connection('status',{'account_id':account['id']}))
        elif account['platform']=='xiaohongshu':
            pending=self.service.retry_existing_account_login(account['id'])
            if pending is not None:
                return {'result':self._login_result(user,pending),**self.snapshot(user)}
            value=self._execute(self._executor(user),user,'account_status',{'account_id':account['id']})
            confirmed=isinstance(value,dict) and value.get('status')=='ready'
            result={'id':'','status':'ready' if confirmed else 'disconnected',
                    'message':'小红书平台身份已核实' if confirmed else '小红书身份尚未核实，请连接本人账号'}
        else:raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','此平台尚未接入账号检查')
        return {'result':result,**self.snapshot(user)}

    def account_job(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'jobId'}:
            raise PlatformRuntimeError('INVALID_INPUT','账号进度参数无效',400)
        self._owned_job(user,data['jobId'])
        result=self._login_result(user,self.service.account_job_status(data['jobId']),data['jobId'])
        return {'result':result, **self.snapshot(user)}

    def cancel_account(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'jobId'}:
            raise PlatformRuntimeError('INVALID_INPUT','取消登录参数无效',400)
        self._owned_job(user,data['jobId'])
        result=self._login_result(user,self.service.cancel_account_login(data['jobId']),data['jobId'])
        return {'result':result, **self.snapshot(user)}

    def _login_result(self, user, value, ident=None):
        """Only the canonical owned job projection crosses the local gateway."""
        if not isinstance(value,dict):
            raise PlatformRuntimeError('LOGIN_RESULT_UNCONFIRMED','登录任务结果需刷新核对，请勿重复打开登录',503,mutation_committed=None)
        nested=value.get('login_job')
        if isinstance(nested,str):
            ident=nested
            self._owned_job(user,ident)
            value=self.service.account_job_status(ident)
        elif isinstance(nested,dict):
            ident=nested.get('id') or nested.get('job_id') or nested.get('jobId')
            value=nested
        else:
            ident=ident or value.get('id') or value.get('jobId')
        if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
            raise PlatformRuntimeError('LOGIN_RESULT_UNCONFIRMED','登录任务编号需刷新核对，请勿重复打开登录',503,mutation_committed=None)
        job=self._owned_job(user,ident)
        state=value.get('status',job.get('status','unknown'))
        state=state if state in ('pending','running','completed','cancelled','failed','ready','unknown') else 'unknown'
        phase=value.get('phase',job.get('phase',''))
        phase=phase if isinstance(phase,str) and re.fullmatch(r'[a-z0-9_]{1,80}',phase) else ''
        messages={'pending':'登录正在准备，请稍候','running':'请在弹出的平台窗口完成登录',
            'completed':'平台登录检查已完成，请核对账号状态','cancelled':'登录已取消，已有账号资料保留',
            'failed':'登录未完成，请核对弹出的平台窗口后手动重试','ready':'平台账号已核实',
            'unknown':'登录结果需核对，请先刷新原登录任务'}
        window_open=value.get('window_open') is True
        result={'id':ident,'status':state,'phase':phase,'message':messages[state],
                'windowOpen':window_open,'persistentBrowser':value.get('persistent_browser') is True}
        if window_open and state=='failed':
            result['message']='浏览器已保留，请完成网页登录或验证后，再点登录检查；不会另开窗口'
        elif window_open and state in ('running','pending'):
            result['message']='浏览器已保留，请在窗口完成本人登录或网页验证；无需赶时间'
        elif window_open and state=='completed':
            result['message']='平台登录检查已完成，浏览器保持打开；请核对账号状态'
        if state == 'running' and value.get('qr_ready') is True:
            image=self._owned_qr(job,ident)
            if image:
                result['qrUrl']=image
                result['message']='请使用平台手机应用扫描二维码，并在手机上确认登录'
        return result

    def _owned_qr(self, job, ident):
        # Caller has just rechecked the job's account/employee/device scope.
        # Never resolve a frontend path or return the stored private file path.
        if not re.fullmatch(r'[a-f0-9]{24,32}',ident):
            return None
        folder=self.data_dir/'work'
        expected=folder/(ident+'.png')
        if job.get('qr_path') != str(expected):
            return None
        try:
            for path in (folder,expected):
                attrs=path.lstat()
                if path.is_symlink() or getattr(attrs,'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
                    return None
            if expected.resolve().parent != folder.resolve() or not 32 < expected.stat().st_size <= 512*1024:
                return None
            content=expected.read_bytes()
            if not content.startswith(b'\x89PNG\r\n\x1a\n') or len(content)>512*1024:
                return None
            return 'data:image/png;base64,'+base64.b64encode(content).decode('ascii')
        except OSError:
            return None

    def _owned_job(self, user, ident):
        job = self.server.jobs.get(ident) if isinstance(ident,str) else None
        if not job or job.get('kind') != 'assistant_account_login':
            raise PlatformRuntimeError('JOB_NOT_FOUND','登录任务不存在或已经结束',404)
        self._account(user,job.get('account_id'))
        self._executor(user,online=False)
        return job

    def _execute(self, executor, user, action, data):
        allowed = {'account_create','account_status','task_save','task_run','task_stop','task_resume',
                   'continuous_start','continuous_resume','continuous_pause','continuous_status',
                   'reply_queue_send'}
        if action not in allowed:
            raise PlatformRuntimeError('ACTION_FORBIDDEN','此批次未开放该操作',403)
        return executor({'owner':user['username'], 'principal':{'username':user['username'],'role':user['role']},
                         'action':action,'data':data})

    def reply_guard(self,user,account_id):
        user=self._principal(user)
        executor=self._executor(user)
        account=self._account(user,account_id)
        code,message=self._readiness(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message)
        self.server._platform_execution_guard(account['platform'])
        executor._guard_platform_qa_command('reply_queue_send',{})
        self.core._public_reply_guard(account['platform'])
        executor._claim_xhs_account(account)
        return executor

    def start_reply_queue(self,user,queue_id):
        user=self._principal(user)
        queue=self.core._get('reply_queues',queue_id,user['tenant_id'])
        self.core.reviewed_reply_queues._access(queue,user)
        executor=self.reply_guard(user,queue['account_id'])
        return self._execute(executor,user,'reply_queue_send',{'queue_id':queue_id,'authorized':True})

    def _task_input(self, data):
        allowed = {'platform','accountId','keywords','region','city','area','dailyLimit','targetCount',
                   'commentDateRange','intentMode','dateFrom','dateTo','excludes','taskName','time','rentalAssessment','storeId'}
        if type(data) is not dict or set(data) - allowed or not {'platform','accountId','keywords'} <= set(data):
            raise PlatformRuntimeError('INVALID_INPUT','采集条件需重新核对',400)
        if (data['platform'] not in self.server.company.get('platforms', []) or
                not isinstance(data['keywords'],list) or not 1 <= len(data['keywords']) <= 100
                or any(not isinstance(word,str) or not 1 <= len(word.strip()) <= 80 for word in data['keywords'])):
            raise PlatformRuntimeError('INVALID_INPUT','请选择已开放平台和有效搜索词',400)
        for key,default,maximum in (('dailyLimit',20,1000),('targetCount',100,10000)):
            number=data.get(key,default)
            if type(number) is not int or not 1 <= number <= maximum:
                raise PlatformRuntimeError('INVALID_INPUT','采集数量范围无效',400)
        for key in ('region','city','area','taskName'):
            if key in data and (not isinstance(data[key],str) or len(data[key])>100 or any(ord(char)<32 for char in data[key])):
                raise PlatformRuntimeError('INVALID_INPUT','采集条件格式无效',400)
        if data.get('intentMode','all') not in ('all','AB','A'):
            raise PlatformRuntimeError('INVALID_INPUT','意向筛选范围无效',400)
        context = data.get('rentalAssessment')
        if context is not None and (not isinstance(context, dict)
                or set(context) != {'enabled','storeId','ruleVersion','materialKey'}
                or context['enabled'] is not True
                or not isinstance(context['storeId'],str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',context['storeId'])
                or not isinstance(context['ruleVersion'],str) or not 1<=len(context['ruleVersion'])<=160
                or context['materialKey'] is not None and (not isinstance(context['materialKey'],str)
                    or not 1<=len(context['materialKey'])<=160)):
            raise PlatformRuntimeError('INVALID_INPUT','租房判断上下文需重新核对',400)
        excludes=data.get('excludes',[])
        if not isinstance(excludes,list) or any(not isinstance(word,str) or len(word)>100 for word in excludes):
            raise PlatformRuntimeError('INVALID_INPUT','排除词需为文本列表',400)
        date_from, date_to = data.get('dateFrom',''), data.get('dateTo','')
        if 'time' in data:
            selected = data['time']
            if selected == '24h':
                raise PlatformRuntimeError('TIME_PRECISION_UNAVAILABLE', '当前采集组件按日期筛选，暂不能精确筛选过去24小时，请选择近3天、7天或30天', 422)
            if selected not in ('3d','7d','30d','all'):
                raise PlatformRuntimeError('TIME_RANGE_INVALID','此时间范围尚未接入，请重新选择',400)
            if selected != 'all':
                today = datetime.now(timezone(timedelta(hours=8))).date()
                date_from = (today - timedelta(days=int(selected[:-1])-1)).isoformat()
                date_to = today.isoformat()
            else:
                date_from = date_to = ''
        try:
            if date_from:
                datetime.strptime(date_from,'%Y-%m-%d')
            if date_to:
                datetime.strptime(date_to,'%Y-%m-%d')
            if date_from and date_to and date_from>date_to:
                raise ValueError('range')
        except (TypeError,ValueError):
            raise PlatformRuntimeError('INVALID_INPUT','采集时间范围无效',400) from None
        return {'name':data.get('taskName') or '工作台关键词采集', 'platform':data['platform'],
            'account_id':data['accountId'],'keywords':list(dict.fromkeys(word.strip() for word in data['keywords'])),
            'scope':'search_comments','continuous_enabled':False,'daily_limit':data.get('dailyLimit',20),
            'target_count':data.get('targetCount',100),'comment_date_range':data.get('commentDateRange','all'),
            'region':data.get('region',''),'city':data.get('city',''),'area':data.get('area',''),
            'date_from':date_from,'date_to':date_to,
            'excludes':data.get('excludes',[]),'intent_mode':data.get('intentMode','all')}

    def task_save(self, user, data):
        user = self._principal(user)
        task = self._task_input(data)
        executor = self._executor(user)
        account = self._account(user,task['account_id'])
        code,message=self._readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        saved=self._execute(executor,user,'task_save',task)
        return {'result':{'taskId':saved['id'],'status':'ready','accepted':False}, **self.snapshot(user)}

    def start_acquisition(self, user, data):
        user = self._principal(user)
        task = self._task_input(data)
        executor = self._executor(user)
        account = self._account(user,task['account_id'])
        code, message = self._readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        if account.get('status') != 'ready':
            raise PlatformRuntimeError('ACCOUNT_NOT_READY','请先连接并核实平台账号')
        with self._run_lock:
            if any(thread.is_alive() for thread in self._runs.values()):
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，请先暂停或等待本批结束')
            saved = self._execute(executor,user,'task_save',task)
            if data.get('storeId'):
                with self.core.lock:
                    record=self.core._get('tasks',saved['id'],user['tenant_id'])
                    record['store_id']=data['storeId']
                    self.core.store.put('tasks',record)
            if data.get('rentalAssessment'):
                self._remember_rental_context(user, saved['id'], data['rentalAssessment'])
            return self._start_task(executor,user,saved['id'])

    def _remember_rental_context(self, user, task_id, values):
        """Host-supplied context from its freshly authorized store selection.

        The HTTP gateway never accepts this field from a client. The material
        key is provenance, not permission; only the host's opaque store ID is
        attached to a newly saved task belonging to this employee.
        """
        task=self._task(user,task_id)
        context={'id':task_id,'tenant_id':user['tenant_id'],'owner':user['username'],
            'store_id':values['storeId'],'rule_version':values['ruleVersion'],
            'material_key':values['materialKey'],'enabled':True,'assessment_status':'pending',
            'created_at':datetime.now(timezone.utc).isoformat()}
        try:
            with self.core.lock,self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                fresh=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    ('tasks',task_id,user['tenant_id'])).fetchone()
                if not fresh:
                    raise PlatformRuntimeError('TASK_FORBIDDEN','任务归属已变化',403)
                task=json.loads(fresh['body'])
                self.core._task_access(user,task,user['tenant_id'])
                task['store_id']=values['storeId']
                for entity,record in (('tasks',task),('rental_task_context_v1',context)):
                    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                        (entity,record['id'],user['tenant_id'],json.dumps(record,ensure_ascii=False,allow_nan=False)))
        except Exception:
            error=PlatformRuntimeError('RENTAL_CONTEXT_UNCONFIRMED','任务已保存，判断上下文未确认；请核对原任务，不要重复采集',503,mutation_committed=True)
            error.task_id=task_id
            raise error from None

    def _start_task(self, executor, user, ident):
        with self._run_lock:
            if any(thread.is_alive() for thread in self._runs.values()):
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，请先暂停或等待本批结束')
            executor._explicit_task_ids.add(ident)
            def run():
                try:
                    # Original single-batch path retains claim, first-search,
                    # execution guard, account lock and Core safety policy.
                    self._execute(executor,user,'task_run',{'task_id':ident,'max_batches':1})
                except Exception:
                    self.core._set_task_progress(ident,'failed','failed')
                else:
                    callback=getattr(self,'_rental_after_import',None)
                    if callback is not None:
                        context=self.core.store.get('rental_task_context_v1',ident)
                        if context and context.get('enabled') is True:
                            try:
                                callback(user,ident)
                                state='completed'
                            except Exception:
                                # Collection already succeeded. Grading has a
                                # separate retry path and must not restart it.
                                state='retry_required'
                            self.core.store.put('rental_task_context_v1',
                                {**context,'assessment_status':state,
                                 'assessed_at':datetime.now(timezone.utc).isoformat()})
            thread = threading.Thread(target=run,name='explicit-workbench-collection',daemon=True)
            self._runs[ident] = thread
            try:
                thread.start()
            except BaseException:
                error=PlatformRuntimeError('COLLECTION_RESULT_UNCONFIRMED','任务已保存，启动结果需按原任务核对，请勿重新提交',503,mutation_committed=True)
                error.task_id=ident
                raise error from None
        try:
            return {'result':{'taskId':ident,'status':'submitted','accepted':True,'maxBatches':1}, **self.snapshot(user)}
        except Exception:
            error=PlatformRuntimeError('COLLECTION_RESULT_UNCONFIRMED','任务已提交，结果需按原任务核对，请勿重新提交',503,mutation_committed=True)
            error.task_id=ident
            raise error from None

    def pause_acquisition(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'taskId'}:
            raise PlatformRuntimeError('INVALID_INPUT','暂停任务参数无效',400)
        executor = self._executor(user,online=False)
        self._task(user,data['taskId'])
        result = self._execute(executor,user,'task_stop',{'task_id':data['taskId']})
        state=result.get('status','paused') if isinstance(result,dict) else 'paused'
        return {'result':{'taskId':data['taskId'],'status':state if state in ('paused','stopped','cancelled') else 'paused',
                          'accepted':True}, **self.snapshot(user)}

    def resume_acquisition(self, user, data):
        user = self._principal(user)
        if type(data) is not dict or set(data) != {'taskId'}:
            raise PlatformRuntimeError('INVALID_INPUT','继续任务参数无效',400)
        executor = self._executor(user)
        task = self._task(user,data['taskId'])
        account = self._account(user,task.get('account_id'))
        code, message = self._readiness(user,account)
        if code:
            raise PlatformRuntimeError(code.upper(),message)
        with self._run_lock:
            if any(thread.is_alive() for thread in self._runs.values()):
                raise PlatformRuntimeError('COLLECTION_BUSY','已有采集正在处理，请先暂停或等待本批结束')
            self._execute(executor,user,'task_resume',{'task_id':task['id']})
            return self._start_task(executor,user,task['id'])

    def close(self):
        with self.lock:
            if self.closed and self._instance_lock is None:
                return
            self.closed = True
        try:
            self.server.close_owned_jobs()
            self.server.server_close()
            for thread in tuple(self._runs.values()):
                if thread is not threading.current_thread() and thread.is_alive():
                    thread.join(8)
            if any(thread.is_alive() for thread in self._runs.values()):
                # Keep the compatible workspace lock until the process/worker
                # actually exits; another backend must not race final writes.
                raise PlatformRuntimeError('RUNTIME_STOPPING','本批采集尚在退出，暂时保留工作区独占锁',503)
        finally:
            if not any(thread.is_alive() for thread in self._runs.values()):
                self._release_instance_lock()


__all__ = ['PlatformRuntime', 'PlatformRuntimeError']
