"""Persistent owned XHS login window over the original candidate coordinator.

The browser is a human workspace. Each immutable candidate gets one bounded
status check; only the original identity, cloud claim and journal commit can
mark an account ready. A failed check never starts an automatic retry.
"""
import json
import os
from pathlib import Path
import secrets
import stat
import subprocess
import sys
import threading
import time

from core.adapters import account_execution_lock
from .browser_login_coordinator import BrowserLoginCoordinator
from .browser_session_commit import account_revision, commit_browser_session, recover_browser_session
from .browser_login_service import (
    _snapshot, _staging_scope, _profile_scope, _cleanup_staging, _stop_helper,
    _candidate_status_failure, _candidate_status_exception, _message)
from .business import xiaohongshu_held
from .login_outcome import classify_login_failure


def _signal(staging, name):
    path = staging / name
    if name not in {'focus.flag', 'capture.flag'}:
        raise ValueError('browser_signal_invalid')
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(fd)
    except FileExistsError:
        if path.is_symlink(): raise ValueError('browser_signal_invalid')


def _candidate(staging, path):
    """Read a bounded nonsecret candidate marker, never trust arbitrary paths."""
    try:
        info = os.lstat(path)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
                info.st_size > 1024 or
                getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
            return None
        data = json.loads(path.read_text('ascii'))
        attempt = data.get('attempt') if type(data) is dict else None
        if (set(data) != {'version', 'attempt', 'candidate'} or type(data['version']) is not int or data['version'] != 1 or
                type(attempt) is not int or not 1 <= attempt <= 999999 or
                path.name != 'candidate-%06d.ready.json' % attempt or
                data['candidate'] != 'attempt-%06d' % attempt):
            return None
        root = staging / data['candidate']
        cookie = root / '.xiaohongshu-cli/cookies.json'
        for part in (root, cookie.parent, cookie):
            info = os.lstat(part)
            if (part.is_symlink() or
                    getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                return None
        return attempt, root, cookie
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def _ack(staging, attempt, status):
    path = staging / ('result-%06d.json' % attempt)
    payload = json.dumps({'version': 1, 'attempt': attempt, 'status': status}).encode('ascii')
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(payload); stream.flush(); os.fsync(stream.fileno())


def _window_authorized(service, user, account_id):
    """Local read-only liveness; a visible window is never a cloud poller."""
    server=service.server
    if (service.closed or service.stop_event.is_set() or server.closing or
            service.state in {'revoked','unbound'} or
            (service.device or {}).get('owner') != user['username']):
        return False
    with server.core.lock:
        actor=server.core.store.get('users', user['id'])
        account=server.core.store.get('accounts', account_id)
        if (not actor or actor.get('disabled') or actor.get('cloud_bound') is not True or
                any(actor.get(key) != user.get(key) for key in ('id','tenant_id','username','role')) or
                not account or account.get('tenant_id') != user['tenant_id']):
            return False
        try: server.core._account_access(actor, account)
        except Exception: return False
    return True


def _status_shape(payload):
    """Fixed types/booleans only; never persist identity or response content."""
    def kind(value):
        return {dict:'dict',list:'list',str:'str',int:'int',float:'float',bool:'bool',
                type(None):'null'}.get(type(value),'other')
    outer=payload if type(payload) is dict else {}
    data=outer.get('data',outer)
    data=data if type(data) is dict else {}
    profile=data.get('user')
    user=profile if type(profile) is dict else {}
    uid=user.get('id') or user.get('user_id') or user.get('red_id')
    nickname=user.get('nickname') or user.get('nick_name')
    return {'payload_type':kind(payload),'ok_type':kind(outer.get('ok')),
        'ok_true':outer.get('ok') is True,'envelope_data_type':kind(outer.get('data')),
        'authenticated_type':kind(data.get('authenticated')),
        'authenticated_true':data.get('authenticated') is True,
        'user_type':kind(profile),'guest_type':kind(user.get('guest')),
        'guest_true':user.get('guest') is True,'uid_type':kind(uid),
        'uid_present':bool(uid),'nickname_type':kind(nickname),
        'nickname_known':type(nickname) is str and bool(nickname.strip()) and nickname.strip()!='Unknown'}


def _record_status_shape(server, account_dir, staging, job_id, attempt, payload):
    try:
        if (staging.name != job_id or type(attempt) is not int or not 1<=attempt<=999999 or
                not _staging_scope(server.core.store.directory,account_dir,staging)):
            return
        path=staging.parent/(job_id+'.shape-%06d.json'%attempt)
        fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600)
        with os.fdopen(fd,'w',encoding='ascii') as stream:
            json.dump({'version':1,'attempt':attempt,'status_shape':_status_shape(payload)},
                      stream,separators=(',',':'))
    except OSError:
        pass


def start_persistent_login(service, account_id, helper_path, *, allow_new=True, fresh_check=False):
    if type(allow_new) is not bool or type(fresh_check) is not bool:
        raise ValueError('browser_login_mode_invalid')
    server = service.server
    if (service.closed or service.state != 'online' or server.closing or
            server.core.remote_safety_hold or xiaohongshu_held(server)):
        raise ValueError('浏览器登录当前不可用')
    if getattr(sys, 'frozen', False):
        raise ValueError('当前保留浏览器登录仅适用于已核验的本机源码工作台')
    helper = Path(helper_path).resolve()
    if not helper.is_file() or helper != Path(__file__).with_name('browser_login_window.py').resolve():
        raise ValueError('浏览器登录助手来源未确认')
    validator = getattr(server, 'browser_login_helper_validator', None)
    if not callable(validator) or validator(helper) is not True:
        raise ValueError('浏览器登录助手校验未通过')
    user = service._local_user()
    with server.core.lock:
        account = server.core._get('accounts', str(account_id or ''), user['tenant_id'])
        server.core._account_access(user, account)
        if account.get('platform') != 'xiaohongshu':
            raise ValueError('当前浏览器登录只支持小红书账号')
    account_dir = server.core.store.directory / 'accounts' / user['tenant_id'] / account['id']
    server.core.adapters.require_account_safe('xiaohongshu', account_dir)
    with server.job_lock:
        for pending in server.jobs.values():
            done = pending.get('worker_done')
            if (pending.get('kind') == 'assistant_account_login' and
                    pending.get('account_id') == account['id'] and
                    pending.get('persistent_browser') is True and
                    isinstance(done, threading.Event) and not done.is_set()):
                process=pending.get('process')
                if process is not None and process.poll() is not None:
                    continue
                if not allow_new and (pending.get('window_open') is not True or process is None):
                    continue
                staging = account_dir / 'work/browser-login' / pending['id']
                if staging.is_dir() and _staging_scope(server.core.store.directory, account_dir, staging):
                    _signal(staging, 'focus.flag')
                    if (fresh_check and pending.get('status') == 'completed') or pending.get('status') == 'failed' or (pending.get('status') == 'running' and
                            pending.get('phase') in {'waiting_browser', 'waiting_manual_check'}):
                        pending.update(status='running', phase='waiting_browser', error_code='', error='')
                        _signal(staging, 'capture.flag')
                return {'login_job': pending['id'], 'mode': 'browser', 'window_open': True,
                        'reused': True, 'account': {k: account.get(k) for k in ('id','name','platform','status')}}
        if not allow_new:
            return None
        job_id = secrets.token_hex(12)
        job = {'id': job_id, 'kind': 'assistant_account_login', 'mode': 'browser',
               'persistent_browser': True, 'window_open': False,
               'account_id': account['id'], 'owner_id': user['id'], 'tenant_id': user['tenant_id'],
               'status': 'running', 'phase': 'opening_browser', 'error_code': '',
               'worker_done': threading.Event()}
        server.jobs[job_id] = job

    def worker():
        proc = None
        staging = account_dir / 'work/browser-login' / job_id
        profile = account_dir / 'xhs-browser-profile'
        job['cancel_file'] = str(staging / 'cancel.flag')
        seen = set()
        try:
            if not _staging_scope(server.core.store.directory, account_dir, staging) or not _profile_scope(
                    server.core.store.directory, account_dir, profile):
                raise ValueError('profile_path_invalid')
            staging.mkdir(parents=True, exist_ok=False)
            server.core.adapters._guard_platform('xiaohongshu')
            from .owned_helper_process import login_helper_argv
            import app
            command = login_helper_argv(staging, staging/'cancel.flag', profile)
            if validator(helper) is not True:
                raise ValueError('helper_unverified')
            argv = [command.argv[0], '-B', str(helper), *command.argv[2:], '--keep-open']
            proc = subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=str(app.ROOT),
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                env={**os.environ, 'FANGYU_LOGIN_SOURCE_ROOT': str(app.ROOT)})
            job.update(process=proc, window_open=True, phase='waiting_browser')
            while proc.poll() is None:
                if job.get('status') == 'cancelled' or not _window_authorized(service, user, account['id']):
                    _stop_helper(proc, job)
                    if job.get('status') != 'completed':
                        job.update(status='cancelled', phase='cancelled', error_code='cancelled')
                    break
                for marker in sorted(staging.glob('candidate-*.ready.json')):
                    candidate = _candidate(staging, marker)
                    if candidate is None or candidate[0] in seen:
                        continue
                    attempt, candidate_root, cookie = candidate
                    seen.add(attempt)
                    job.update(status='running', phase='verifying_identity', error_code='', error='')
                    diagnostic = None
                    with account_execution_lock(account_dir):
                        connection = server.account_connections.locks.setdefault(account['id'], threading.Lock())
                        with connection:
                            recovered = recover_browser_session(server.core.store, account_dir, account['id'], user['tenant_id'])
                            if recovered not in ('clean', 'old_restored', 'new_kept'):
                                raise ValueError('recovery_required')
                            initial = _snapshot(service, user, account['id'], account_dir)
                            def snapshot(): return _snapshot(service, user, account['id'], account_dir)
                            def status(_candidate_root):
                                nonlocal diagnostic
                                started = time.time()
                                try:
                                    value=server.core.adapters.execute('xiaohongshu', ['status','--json'],
                                        account_dir, timeout=35, candidate_home=candidate_root)
                                    _record_status_shape(server,account_dir,staging,job_id,attempt,value)
                                    return value
                                except Exception as error:
                                    evidence = classify_login_failure(b'', account_dir/'platform-activity.jsonl', started, kind='status')
                                    diagnostic = _candidate_status_failure(evidence) or _candidate_status_exception(error)
                                    return {'authenticated': False}
                            def claim(uid):
                                try:
                                    service._claim_xhs_account({**initial['_account'], 'platform_uid': uid})
                                    return True
                                except Exception: return False
                            def commit(_candidate_root, decision, original):
                                # Cloud identity verification refreshes its
                                # local cache. Complete that fresh check BEFORE
                                # the original journal opens a SQLite writer.
                                checked = snapshot()
                                if (not checked.get('exists') or any(checked.get(key) for key in
                                        ('access_revoked','cloud_paused','safety_paused')) or
                                        checked.get('revision') != original['revision']):
                                    return False
                                def guard():
                                    # Read only while commit_browser_session
                                    # owns its write transaction; never call the
                                    # cloud identity cache writer recursively.
                                    if (job.get('status') != 'running' or service.closed or
                                            service.stop_event.is_set() or server.closing or
                                            proc.poll() is not None or (staging/'cancel.flag').exists() or
                                            service.state != 'online' or server.core.remote_safety_hold or
                                            xiaohongshu_held(server)):
                                        return False
                                    actor = server.core.store.get('users', user['id'])
                                    current_account = server.core.store.get('accounts', account['id'])
                                    if (not actor or actor.get('disabled') or not actor.get('cloud_bound') or
                                            any(actor.get(key) != user.get(key) for key in ('id','tenant_id','username','role')) or
                                            not current_account or account_revision(current_account) != original['revision']):
                                        return False
                                    try:
                                        server.core._account_access(actor, current_account)
                                        server.core.adapters.require_account_safe('xiaohongshu', account_dir)
                                    except Exception:
                                        return False
                                    return True
                                with server.core.lock:
                                    result = commit_browser_session(server.core.store, account_dir,
                                        original['_account'], decision, cookie, guard)
                                job['commit_code'] = result
                                if result == 'recovery_required':
                                    service._pause_xhs_identity(original['_account'], 'session_recovery_required',
                                        '会话恢复待管理员检查；相关任务已暂停')
                                return result == 'committed'
                            coordinator = BrowserLoginCoordinator(stage=lambda: candidate_root,
                                status=status, local_accounts=lambda: server.core.store.list('accounts',user['tenant_id']),
                                claim=claim, commit=commit, discard=lambda _candidate: None,
                                current=snapshot, cancelled=lambda: (job.get('status') == 'cancelled' or
                                    proc.poll() is not None or (staging/'cancel.flag').exists()),
                                deadline=time.monotonic()+45, expected_revision=initial.get('revision'))
                            outcome = coordinator.run()
                    completed = outcome.state == 'completed'
                    if completed:
                        job.update(status='completed', phase='completed', error_code='', error='')
                    elif job.get('status') != 'cancelled':
                        code, message = diagnostic or (outcome.code, _message(outcome.code))
                        if code in {'verification_required', 'not_authenticated'}:
                            message = '请在保留的电脑网页中完成本人登录或验证码，再手动核对连接'
                        job.update(status='failed', phase='waiting_manual_check', error_code=code, error=message)
                    _ack(staging, attempt, 'completed' if completed else 'failed')
                    # Each candidate is immutable and used once. The owned
                    # WebView profile remains; no automatic recapture/retry.
                    cookie.unlink(missing_ok=True)
                time.sleep(.2)
            if job.get('status') == 'running':
                job.update(status='cancelled', phase='cancelled', error_code='cancelled',
                           error='网页登录窗口已由本人关闭，本次未新增连接')
        except Exception:
            if job.get('status') not in {'completed','cancelled'}:
                job.update(status='failed', phase='stopped', error_code='browser_login_failed',
                           error='网页登录未完成；请核对本机组件后重试')
        finally:
            if proc is not None and proc.poll() is None:
                _stop_helper(proc, job)
            job.update(window_open=False)
            job.pop('process', None)
            if staging.exists():
                try: _cleanup_staging(server.core.store.directory, account_dir, staging)
                except OSError: job['cleanup_code'] = 'cleanup_failed'
            # Fixed, credential-free outcome remains after disposable
            # candidate cleanup; never serialize the account or raw error.
            try:
                if _staging_scope(server.core.store.directory, account_dir, staging):
                    outcome_path=staging.parent/(job_id+'.job.json')
                    outcome={'version':1,'status':job.get('status'),'phase':job.get('phase'),
                             'error_code':job.get('error_code',''),'attempts_checked':len(seen),
                             'window_open':False}
                    fd=os.open(outcome_path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                    with os.fdopen(fd,'w',encoding='ascii') as stream:
                        json.dump(outcome,stream,separators=(',',':'))
            except OSError:
                pass
            job['worker_done'].set()

    try:
        threading.Thread(target=worker, name='assistant-persistent-browser-login', daemon=True).start()
    except Exception:
        with server.job_lock: server.jobs.pop(job_id, None)
        raise ValueError('浏览器登录任务未能启动') from None
    return {'login_job': job_id, 'mode': 'browser', 'window_open': True,
            'account': {k: account.get(k) for k in ('id','name','platform','status')}}
