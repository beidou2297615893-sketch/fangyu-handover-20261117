// The approved UI talks to the same local workbench through this small interface.
export class WorkbenchError extends Error {
  constructor(message, code='request_failed') { super(message); this.name='WorkbenchError'; this.code=code; }
}

export function createBackend(fetcher=globalThis.fetch.bind(globalThis),{timeoutMs=90000}={}) {
  let csrfToken='';
  let mode='loading';
  let unconfirmed=false;
  let unconfirmedAction='',unconfirmedRequestId='',unconfirmedDeliveryId='',unconfirmedStoreId='';
  function unknown(action,data){unconfirmed=true;unconfirmedAction=action;unconfirmedRequestId=data?.requestId||'';unconfirmedDeliveryId=data?.id||'';unconfirmedStoreId=data?.storeId||'';}
  async function runtimeStatus(){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.min(timeoutMs,10000));
    try{
      const response=await fetcher('/__workbench_status',{method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal});
      if(!response.ok)throw new WorkbenchError('运行版本暂不可读，请刷新版本状态。','runtime_metadata_unavailable');
      const value=await response.json();
      if(!value||typeof value.release!=='string'||!value.release.length||value.release.length>160||!/[A-Za-z0-9_-]/.test(value.release)||!/^[A-Za-z0-9_-]+$/.test(value.release)
        ||!['production','fixture'].includes(value.profile)||!['stable','development'].includes(value.mode)||typeof value.instanceId!=='string'||!/^[a-f0-9]{32}$/.test(value.instanceId))
        throw new WorkbenchError('运行元数据尚未核对，请刷新后查看。','runtime_metadata_invalid');
      return {release:value.release,profile:value.profile,mode:value.mode,instanceId:value.instanceId};
    }catch(error){if(error instanceof WorkbenchError)throw error;throw new WorkbenchError('暂时无法读取本机运行版本，请刷新重试。','runtime_metadata_unavailable');}
    finally{clearTimeout(timer);}
  }
  async function request(action, data) {
    const bootstrap=action==='bootstrap';
    const get=bootstrap||['platform','account_job','customers','customer_detail'].includes(action);
    const read=get||['customer_export','customer_handoff_read','reply_read','reply_check','reply_delivery_status'].includes(action);
    if(!read&&unconfirmed)throw new WorkbenchError('上次操作结果尚未确认，请先核对状态。','RESULT_UNCONFIRMED');
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),timeoutMs);
    try {
      const url=bootstrap?'/api/workbench/bootstrap':action==='platform'?'/api/workbench/platform':action==='account_job'?'/api/workbench/account-job?jobId='+encodeURIComponent(data.jobId):action==='customers'?'/api/workbench/customers?'+new URLSearchParams(data).toString():action==='customer_detail'?'/api/workbench/customer?id='+encodeURIComponent(data.id):'/api/workbench';
      const response=await fetcher(url,get
        ? {method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal}
        : {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Fangyu-CSRF':csrfToken},body:JSON.stringify({action,data}),signal:controller.signal});
      // The static design preview deliberately has no business interface.
      if(bootstrap&&response.status===404) { mode='preview'; return null; }
      let result;
      try { result=await response.json(); }
      catch { if(!read)unknown(action,data);throw new WorkbenchError(read?'本地服务返回异常，请稍后重新核对。':'操作结果尚未确认，正在核对状态。',read?'invalid_response':'RESULT_UNCONFIRMED'); }
      if(result?.csrfToken)csrfToken=result.csrfToken;
      if(!response.ok||result?.ok!==true){if(action==='customer_handoff_save'&&result?.error?.code==='HANDOFF_RESULT_UNCONFIRMED')unknown(action,data);throw new WorkbenchError(result?.error?.message||'操作未完成，请稍后重试。',result?.error?.code||'request_failed');}
      if(bootstrap){mode='connected';unconfirmed=false;}
      if(action==='reply_check'&&['reply_save','reply_review'].includes(unconfirmedAction)
        &&data?.requestId===unconfirmedRequestId&&['accepted','observed','not_applied','rejected','not_found','changed'].includes(result.replyWorkspace?.receipt?.state))unconfirmed=false;
      if(action==='customer_handoff_read'&&unconfirmedAction==='customer_handoff_save'&&data?.storeId===unconfirmedStoreId&&data?.id===unconfirmedDeliveryId&&data?.requestId===unconfirmedRequestId&&result.handoff?.id===data.id&&result.handoff?.receipt?.requestId===unconfirmedRequestId&&['accepted','not_found'].includes(result.handoff.receipt.state))unconfirmed=false;
      if(action==='reply_delivery_status'&&((unconfirmedAction==='reply_delivery_prepare'&&result.delivery?.prepareRequestId===unconfirmedRequestId)||(unconfirmedAction==='reply_delivery_start'&&result.delivery?.id===unconfirmedDeliveryId&&(result.delivery?.requestId===unconfirmedRequestId||result.delivery?.state==='prepared'))||(unconfirmedAction==='reply_delivery_cancel'&&result.delivery?.id===unconfirmedDeliveryId&&['cancelled','stopped','completed','interrupted'].includes(result.delivery?.state))))unconfirmed=false;
      return result;
    } catch(error) {
      if(error instanceof WorkbenchError)throw error;
      if(!read){unknown(action,data);throw new WorkbenchError('操作结果尚未确认，正在核对状态。','RESULT_UNCONFIRMED');}
      if(error?.name==='AbortError')throw new WorkbenchError('连接超时，暂时无法核对上次操作。','timeout');
      throw new WorkbenchError('暂时无法连接本地服务，请稍后重新核对。','connection_failed');
    } finally { clearTimeout(timeout); }
  }
  return {runtimeStatus,handoffRead:data=>request('customer_handoff_read',data),handoffSave:data=>request('customer_handoff_save',data),get mode(){return mode;},get unconfirmed(){return unconfirmed;},deliveryPrepare:data=>request('reply_delivery_prepare',data),deliveryStart:data=>request('reply_delivery_start',data),deliveryStatus:data=>request('reply_delivery_status',data),deliveryCancel:data=>request('reply_delivery_cancel',data),replyRead:data=>request('reply_read',data),replySave:data=>request('reply_save',data),replyReview:data=>request('reply_review',data),replyCheck:data=>request('reply_check',data),bootstrap:()=>request('bootstrap'),platform:()=>request('platform'),accountJob:jobId=>request('account_job',{jobId}),customers:data=>request('customers',data),customerDetail:id=>request('customer_detail',{id}),exportCustomers:data=>request('customer_export',data),login:data=>request('login',data),logout:()=>request('logout',{}),selectStore:storeId=>request('select_store',{storeId}),applyPreset:data=>request('apply_preset',data),refreshAssessments:data=>request('refresh_assessments',data),openDevelopment:()=>request('open_development',{}),preparePlatform:()=>request('platform_prepare',{}),createAccount:data=>request('account_create',data),connectAccount:accountId=>request('account_connect',{accountId}),checkAccount:accountId=>request('account_check',{accountId}),cancelAccount:jobId=>request('account_cancel',{jobId}),startAcquisition:data=>request('acquisition_start',data),pauseAcquisition:taskId=>request('acquisition_pause',{taskId}),resumeAcquisition:taskId=>request('acquisition_resume',{taskId})};
}
