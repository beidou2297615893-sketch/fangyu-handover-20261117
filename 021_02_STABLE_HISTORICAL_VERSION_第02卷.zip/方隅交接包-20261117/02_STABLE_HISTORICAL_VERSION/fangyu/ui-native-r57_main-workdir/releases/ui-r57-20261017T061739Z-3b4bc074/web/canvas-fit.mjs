const sizes={login:[1487,1058],acquire:[1585,992],reply:[1585,992],customers:[1586,992],presets:[1586,992],accounts:[1585,992]};
function start(){
  const app=document.getElementById('app');if(!app)return;
  let queued=false,contentChanged=false,lastPage='';
  const post=message=>{if(parent!==window)parent.postMessage(message,location.origin);};
  function measure(){
    queued=false;
    const page=document.body.dataset.page;if(!Object.hasOwn(sizes,page))return;
    document.documentElement.style.setProperty('--canvas-height',sizes[page][1]+'px');
    if(contentChanged){contentChanged=false;if(page!==lastPage){lastPage=page;post({type:'fangyu-canvas-change',page});}}
    requestAnimationFrame(()=>post({type:'fangyu-canvas-size',page,
      viewportWidth:innerWidth,viewportHeight:innerHeight,
      contentHeight:Math.max(Math.ceil(app.getBoundingClientRect().height-.01),document.documentElement.scrollHeight)}));
  }
  function queue(changed=false){contentChanged ||= changed;if(!queued){queued=true;requestAnimationFrame(measure);}}
  window.addEventListener('message',event=>{
    if(event.source!==parent||event.origin!==location.origin||event.data?.type!=='fangyu-canvas-viewport')return;
    const y=event.data.layoutY;if(!Number.isFinite(y)||y<1)return;
    document.documentElement.style.setProperty('--layout-y',String(y));queue();
  });
  new MutationObserver(()=>queue(true)).observe(app,{childList:true,subtree:true,characterData:true});
  new ResizeObserver(()=>queue()).observe(app);
  window.addEventListener('resize',()=>queue());document.fonts?.ready.then(()=>queue());queue(true);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
