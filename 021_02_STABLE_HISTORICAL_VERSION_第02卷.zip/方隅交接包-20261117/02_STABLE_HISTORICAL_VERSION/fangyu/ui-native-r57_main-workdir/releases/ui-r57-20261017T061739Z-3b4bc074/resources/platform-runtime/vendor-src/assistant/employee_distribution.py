"""Portable employee distribution: identity is enrolled on the destination PC.

This public bundle marker selects a validated runtime; it grants no platform
permission. The authenticated enterprise heartbeat is the authority for work.
There is deliberately no development-machine SID, permit, device ID or expiry.
"""
from .private_evaluation import COMPANY_ID, ENVIRONMENT_ID, ENDPOINT, EXE_NAME, SOURCE_SHA256
import hashlib
from pathlib import Path
import sys

VERSION = '1.1.8-pilot.1'
UPDATE_CHANNEL = 'employee-pilot'
UPDATE_BASE = 'https://fh6-d5ga45c0ddae7008c-1439321968.tcloudbaseapp.com/fangyu-employee-pilot/v1/'
UPDATE_TARGET = 'fangyu-employee-pilot-update.zip'
TRUSTED_ROOT_SHA256 = '612acf8e3eba346e6b231855125c014f1ab818c778b2975987d0ef947dfbee9f'
WORKBENCH_SOURCE_SHA256 = '70d6e5c797cc993f0d5b23b12affc943f099065c420f72d38c927ab9d81d04b3'
WORKBENCH_EXE_SHA256 = '3dfdd20b3fe8132e1a4e33355c99ef904a672d2f174f73e7deaea69352d1e49d'
WORKBENCH_TREE_SHA256 = '2382b984fc3ba35145d6849c13994e661161578e3f6a0810c89f4548c2566bb6'


def workbench_source_config_valid(config):
    """Pinned local r57 route only; a marker never grants a device lease.

    Keep the original employee package policy unchanged. The explicit host
    disables remote commands and uses the same authenticated 45-second lease.
    """
    if getattr(sys, 'frozen', False) or not isinstance(config, dict):
        return False
    runtime = config.get('runtime')
    if (not isinstance(runtime, dict)
            or runtime.get('workbench_source_release') != 'fangyu-admin-local-v1'
            or config.get('platforms') != ['xiaohongshu', 'douyin']
            or runtime.get('cli_source_sha256') != WORKBENCH_SOURCE_SHA256
            or runtime.get('public_send_hold') is not True):
        return False
    # Reuse every identity, transport, version and hold check from the fixed
    # one-platform package. Only this source host's platform set is different.
    selected = {**config, 'platforms': ['xiaohongshu'],
                'runtime': {**runtime, 'cli_source_sha256': SOURCE_SHA256}}
    return portable_employee_source_valid(selected)


def pinned_update_feed_valid(feed):
    """Accept only the employee channel and its bundled public trust anchor."""
    expected = {'enabled': True, 'metadata_url': UPDATE_BASE + 'metadata/',
                'targets_url': UPDATE_BASE + 'targets/', 'target': UPDATE_TARGET,
                'channel': UPDATE_CHANNEL}
    if not isinstance(feed, dict) or set(feed) != set(expected) | {'trusted_root'}:
        return False
    if any(feed.get(key) != value for key, value in expected.items()):
        return False
    try:
        root = Path(feed['trusted_root'])
        if (not root.is_absolute() or root.name != 'root.json'
                or root.parent.name != 'update-trust' or root.is_symlink()
                or not root.is_file() or not 100 <= root.stat().st_size <= 262144):
            return False
        return hashlib.sha256(root.read_bytes()).hexdigest() == TRUSTED_ROOT_SHA256
    except (OSError, TypeError, ValueError):
        return False


def portable_employee_source_valid(config):
    if not isinstance(config, dict):
        return False
    runtime = config.get('runtime')
    managed = config.get('managedWorkspace')
    feed = config.get('updateFeed')
    return bool(
        config.get('id') == COMPANY_ID
        and config.get('edition') == 'customer'
        and config.get('personalMode') is False
        and config.get('authMode') == 'managed'
        and config.get('releaseVersion') == VERSION
        and config.get('platforms') == ['xiaohongshu']
        and isinstance(managed, dict)
        and managed.get('environment_id') == ENVIRONMENT_ID
        and managed.get('endpoint') == ENDPOINT
        and isinstance(runtime, dict)
        and runtime.get('role') == 'local_assistant_only'
        and runtime.get('ui_entry') == 'employee_workspace'
        and runtime.get('executable') == EXE_NAME
        and runtime.get('xiaohongshu_read_transport') == 'guarded_cli_v1'
        and runtime.get('cli_source_sha256') == SOURCE_SHA256
        and runtime.get('release_approved') is False
        and runtime.get('xiaohongshu_automation') == 'hold'
        and runtime.get('portable_employee_release') is True
        and not any(key in runtime for key in (
            'private_evaluation', 'private_evaluation_session_id', 'platform_qa_device_id'))
        and (feed is None or isinstance(feed, dict) and feed.get('enabled') is False)
    )


def runtime_config_valid(config):
    if workbench_source_config_valid(config):
        return True
    if portable_employee_source_valid(config):
        return True
    if not isinstance(config, dict) or not pinned_update_feed_valid(config.get('updateFeed')):
        return False
    # The immutable bundled company stays held; only the fixed installation's
    # independently pinned update policy may be overlaid at runtime.
    return portable_employee_source_valid({**config, 'updateFeed': {'enabled': False}})


def packaged_workspace(config, packaged=False):
    return bool(packaged and runtime_config_valid(config))
