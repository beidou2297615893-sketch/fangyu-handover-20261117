const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const asset = name => `/assets/${name}`;
const icon = (name, cls='') => `<img class="acquire-icon ${cls}" src="${asset(name)}" alt="" aria-hidden="true">`;
let progressTimer = null;

function model(state) {
  if(state.connection==='preview')state.store ||= '古北店';
  const assignedStore=state.stores?.find(item=>item.id===state.storeId);
  state.acquire ??= {region:state.connection==='preview'?'上海 · 长宁区':assignedStore?.region||'',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  const a=state.acquire;
  if(a.run&&a.run.store!==state.store){
    if(['running','paused'].includes(a.status))a.records.unshift({text:`${a.run.store} · 已切换门店，本次演示结束`,status:'已停止'});
    Object.assign(a,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null,region:state.connection==='preview'?(state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区'):assignedStore?.region||''});
  }
  return state.acquire;
}
const phase = a => ({idle:'待开始',running:['搜索中','读取中','分析中','即将完成'][a.stage] || '采集中',paused:'已暂停',completed:'已完成',failed:'采集已中断'})[a.status];
const selected = (value, expected) => value === expected ? ' selected' : '';
const option = (text,value) => `<option${selected(value,text)}>${escape(text)}</option>`;

export function render(state) {
  if(state.connection!=='preview')return renderConnected(state);
  const a = model(state);
  const active = a.status === 'running';
  const locked = ['running','paused'].includes(a.status);
  const recent = [{name:'小雨',copy:'长宁 · 预算3500 · 下月入住',intent:'超高意向',time:'10 分钟前',avatar:'portrait-woman-1.png',id:'rain'}, {name:'陈先生',copy:'九号线附近 · 一居',intent:'高意向',time:'28 分钟前',avatar:'portrait-man-1.png',id:'chen'}];
  return `<div class="acquire-page" data-page-acquire>
    <section class="acquire-card acquire-launch" aria-label="获客范围">
      <div class="acquire-fields">
        <label class="acquire-field"><span>门店</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-store aria-label="选择门店" ${locked||state.busy?'disabled':''}>${state.connection==='preview'?['古北店','浦江店','徐汇店'].map(x=>option(x,state.store)).join(''):(state.stores||[]).map(item=>`<option value="${escape(item.id)}"${selected(state.storeId,item.id)}>${escape(item.name)}</option>`).join('')||'<option value="">待管理员分配门店</option>'}</select></div></label>
        <label class="acquire-field"><span>区域</span><div class="acquire-select-wrap">${icon('tabler-upgrade-pin.svg')}<select data-acquire-region aria-label="选择区域" ${locked?'disabled':''}>${['上海 · 长宁区','上海 · 闵行区','上海 · 徐汇区','上海 · 全市'].map(x=>option(x,a.region)).join('')}</select></div></label>
        <label class="acquire-field"><span>时间</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-time aria-label="选择时间范围" ${locked?'disabled':''}>${['最近7天','最近3天','最近24小时','最近30天'].map(x=>option(x,a.time)).join('')}</select></div></label>
        <button class="acquire-start" data-acquire-start ${active?'disabled':''}>${icon('icon-play-filled.svg')}<span>${a.status === 'paused'?'继续获客':a.status === 'failed'?'重新开始':a.status === 'completed'?'再次获客':'开始获客'}</span></button>
      </div>
      <div class="acquire-launch-bottom"><button class="acquire-platform" data-acquire-platform aria-label="选择获客平台" ${locked?'disabled':''}>${escape(a.platforms.join(' · '))}</button><button class="acquire-link" data-acquire-presets>更换门店预设 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
    </section>
    <section class="acquire-card acquire-progress" aria-label="采集进度">
      <div class="acquire-card-heading"><h2>采集进度</h2><button class="acquire-link" data-acquire-records>查看记录 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
      <div class="acquire-stages"><ol>${['搜索','读取','分析','完成'].map((name,index)=>`<li class="${index===a.stage?'current ':''}${(a.status==='completed'||index<a.stage)?'complete ':''}"><span class="acquire-stage-dot">${(a.status==='completed'||index<a.stage)?icon('tabler-upgrade-check.svg'):''}</span><span>${name}</span></li>`).join('')}</ol><span class="acquire-status ${escape(a.status)}" aria-live="polite">${escape(phase(a))}</span></div>
      <div class="acquire-progress-bottom"><div class="acquire-metrics">${[['已读',a.read],['新增',a.added],['已分析',a.analyzed],['重复',a.duplicates]].map(([label,count])=>`<div><span>${label}</span><strong>${count}</strong></div>`).join('<i aria-hidden="true">·</i>')}</div><button class="acquire-pause" data-acquire-pause ${!['running','paused','failed'].includes(a.status)?'disabled':''}>${icon(a.status==='paused'||a.status==='failed'?'icon-play-filled.svg':'fy-icon-54-pause.png')}<span>${a.status==='paused'?'继续':a.status==='failed'?'重试':'暂停'}</span></button></div>
      ${a.status==='failed'?'<p class="acquire-inline-error" role="alert">本次采集已暂停。可重试继续演示，已有结果会保留。</p>':''}
    </section>
    <section class="acquire-card acquire-recent" aria-label="最新意向">
      <div class="acquire-card-heading"><h2>最新意向</h2><button class="acquire-link" data-acquire-customers>查看客户清单 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
      <div class="acquire-recent-list">${recent.map(person=>`<button class="acquire-person" data-acquire-person="${person.id}"><img class="acquire-avatar" src="${asset(person.avatar)}" alt=""><strong>${person.name}</strong><span class="acquire-person-copy">${person.copy}</span><span class="acquire-intent">${person.intent}</span><time>${person.time}</time><img class="acquire-person-next" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>`).join('')}</div>
    </section>
  </div>`;
}

export function bind(root,ctx) {
  if(ctx.state.connection!=='preview')return bindConnected(root,ctx);
  clearTimeout(progressTimer);
  const mount = root.querySelector('[data-page-acquire]');
  if (!mount) return () => {};
  const {state} = ctx;
  const a = model(state);
  const change = fn => ctx.update(s => fn(model(s),s));
  root.querySelector('[data-acquire-store]').addEventListener('change',event => {if(state.connection!=='preview'){if(event.target.value)ctx.actions.selectStore(event.target.value);return;}change((a,s)=>{s.store=event.target.value;a.region=s.store==='浦江店'?'上海 · 闵行区':s.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区';});});
  root.querySelector('[data-acquire-region]').addEventListener('change',event => change(a=>{a.region=event.target.value;}));
  root.querySelector('[data-acquire-time]').addEventListener('change',event => change(a=>{a.time=event.target.value;}));
  root.querySelector('[data-acquire-presets]').addEventListener('click',()=>ctx.navigate('presets'));
  root.querySelector('[data-acquire-customers]').addEventListener('click',()=>ctx.navigate('customers'));
  root.querySelector('[data-acquire-platform]').addEventListener('click',()=>ctx.modal({title:'选择获客平台',html:`<div class="acquire-platform-options"><label><input type="checkbox" id="acquire-platform-xhs" ${a.platforms.includes('小红书')?'checked':''}> 小红书</label><label><input type="checkbox" id="acquire-platform-dy" ${a.platforms.includes('抖音')?'checked':''}> 抖音</label></div><p class="modal-note">所选平台将用于本次界面演示。</p>`,confirmLabel:'确认选择',onConfirm:()=>{
    const choices=[['acquire-platform-xhs','小红书'],['acquire-platform-dy','抖音']].filter(([id])=>document.getElementById(id)?.checked).map(([,name])=>name);
    if(!choices.length){ctx.toast('请至少选择一个平台');return false;}
    change(a=>{a.platforms=choices;});
  }}));
  const start = () => change(a=>{
    if(a.status==='paused'||a.status==='failed'){a.status='running';return;}
    Object.assign(a,{status:'running',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0});
    a.run={store:state.store,region:a.region,time:a.time};
    a.records.unshift({text:`${state.store} · ${a.time} · 开始采集`,status:'已开始'});
  });
  root.querySelector('[data-acquire-start]').addEventListener('click',start);
  root.querySelector('[data-acquire-pause]').addEventListener('click',()=>change(a=>{a.status=a.status==='running'?'paused':'running';}));
  root.querySelector('[data-acquire-records]').addEventListener('click',()=>ctx.modal({title:'采集记录',html:`<div class="acquire-records"><p>${escape(state.store)} · ${escape(a.region)} · ${escape(a.time)}</p><div class="acquire-record-summary"><strong>${escape(phase(a))}</strong><span>已读 ${a.read} · 新增 ${a.added} · 已分析 ${a.analyzed} · 重复 ${a.duplicates}</span></div>${a.records.length?a.records.map(record=>`<div class="acquire-record-row"><span>${escape(record.text)}</span><b>${escape(record.status)}</b></div>`).join(''):'<p class="modal-note">尚无本次采集记录，点击“开始获客”查看演示流程。</p>'}</div>`,confirmLabel:a.status==='running'?'模拟采集中断':'关闭',onConfirm:()=>{if(a.status==='running')change(a=>{a.status='failed';a.records.unshift({text:'模拟网络中断，进度保留',status:'可重试'});});}}));
  for(const button of root.querySelectorAll('[data-acquire-person]'))button.addEventListener('click',()=>{ctx.update(s=>{s.selectedCustomer=button.dataset.acquirePerson;});ctx.navigate('customers');});
  if(a.status==='running'){
    progressTimer=setTimeout(()=>{
      if(!mount.isConnected)return;
      change(a=>{
        if(a.status!=='running')return;
        a.tick++;
        a.stage=Math.min(3,Math.floor(a.tick/2));
        if(a.tick>=2){a.read=Math.min(128,(a.tick-1)*22);a.added=Math.min(36,Math.round(a.read*.28125));a.duplicates=Math.max(0,a.read-a.added);}
        if(a.tick>=4)a.analyzed=Math.min(a.added,(a.tick-3)*12);
        if(a.tick>=7){a.status='completed';a.stage=3;a.analyzed=a.added;a.records.unshift({text:`${a.run?.store||state.store} · 本次新增 ${a.added} 条意向线索`,status:'已完成'});}
      });
    },1250);
  }
  return ()=>{clearTimeout(progressTimer);progressTimer=null;};
}

const count=value=>Number.isSafeInteger(value)&&value>=0?value:'—';
const livePhase=value=>({search:0,searching:0,read:1,reading:1,collect:1,collecting:1,save:2,saving:2,complete:3,completed:3,finished:3})[value]??(Number.isInteger(value)&&value>=0&&value<=3?value:-1);
const liveStatus=value=>({idle:'待开始',queued:'等待执行',running:'采集中',pausing:'正在暂停',paused:'已暂停',resuming:'正在恢复',completed:'已完成',failed:'未完成',blocked:'已暂停 · 待核验',held:'已暂停 · 待核验',unconfirmed:'结果待核对',cancelled:'已取消',stopped:'已停止'})[value]||'状态待核验';
function unknownStart(state){return Boolean(state.acquisitionAttempt?.unconfirmed||['submitted','unconfirmed'].includes(state.platform?.lastRequest?.state));}
function visibleAcquisition(state,live){const last=state.platform?.lastRequest;return unknownStart(state)&&(!last?.job?.taskId||last.job.taskId!==live.taskId)?{...live,taskId:last?.job?.taskId||'',taskScope:null,status:'unconfirmed',phase:null,counts:{},records:[],canPause:false,canResume:false}:live;}
function liveModel(state){
  const store=state.stores?.find(item=>item.id===state.storeId),platforms=(state.platform?.platforms||[]).filter(row=>row.enabled);
  state.acquire??={region:store?.region||'',time:'最近7天'};
  const draft=state.acquire;draft.region??=store?.region||'';draft.time||='最近7天';
  if(unknownStart(state)){const conditions=state.acquisitionAttempt?.payload||state.platform?.lastRequest?.conditions||{};draft.region=typeof conditions.region==='string'?conditions.region:'';draft.time=typeof conditions.time==='string'?conditions.time:'';if(conditions.platform)draft.selectedPlatform=conditions.platform;}
  if(!platforms.some(row=>row.id===draft.selectedPlatform))draft.selectedPlatform=platforms[0]?.id||'';
  const platform=platforms.find(row=>row.id===draft.selectedPlatform);
  return {draft,store,platform,platforms,accountId:state.platformAccountSelections?.[platform?.id]||platform?.accountId||'',live:visibleAcquisition(state,state.platform?.acquisition||{})};
}
const activeStatuses=['running','queued','pausing','resuming','stopping'];
const canResumeTask=(state,live)=>Boolean(state.storeId&&live.taskScope?.storeId===state.storeId
  &&live.taskId&&live.canResume&&['paused','stopped'].includes(live.status));
function matchesTaskScope(state,current){
  const {draft,platform,accountId,live}=current,scope=live.taskScope;
  const words=state.selection?.applied?.selectedKeywords,days={'最近3天':3,'最近7天':7,'最近30天':30}[draft.time];
  if(!scope||!days||!Array.isArray(words)||!words.length||words.some(word=>typeof word!=='string'))return false;
  const keywords=[...new Set(words.map(word=>word.trim()))];
  const today=new Date(Date.now()+8*60*60*1000).toISOString().slice(0,10);
  const from=new Date(Date.parse(today+'T00:00:00Z')-(days-1)*86400000).toISOString().slice(0,10);
  return scope.storeId===state.storeId&&scope.platform===platform?.id&&scope.accountId===accountId
    &&scope.region===(draft.region||'')&&scope.dateFrom===from&&scope.dateTo===today
    &&JSON.stringify(scope.keywords)===JSON.stringify(keywords)&&scope.scope==='search_comments'
    &&scope.city===''&&scope.area===''&&scope.commentDateRange==='all'&&scope.intentMode==='all'
    &&Array.isArray(scope.excludes)&&scope.excludes.length===0&&scope.dailyLimit===20&&scope.targetCount===100;
}
function taskCaption(state,live){
  const scope=live.taskScope,platform={xiaohongshu:'小红书',douyin:'抖音'}[scope?.platform]||'原平台';
  const store=state.stores?.find(row=>row.id===scope?.storeId)?.name||'原门店';
  const date=/^\d{4}-\d{2}-\d{2}$/;
  const time=scope&&date.test(scope.dateFrom)&&date.test(scope.dateTo)?`${scope.dateFrom} 至 ${scope.dateTo}`
    :scope&&scope.dateFrom===''&&scope.dateTo===''?'全部时间':'原时间条件';
  return `${platform} · ${store} · ${time}`;
}
function recentPeople(state){const live=visibleAcquisition(state,state.platform?.acquisition||{});return live.status==='unconfirmed'?[]:Array.isArray(live.recent)?live.recent:[];}
function renderConnected(state){
  const current=liveModel(state),{draft,store,platform,accountId,live}=current,status=live.status||'unknown',stage=livePhase(live.phase),counts=live.counts||{};
  const timeRanges=Array.isArray(state.platform?.capabilities?.timeRanges)?state.platform.capabilities.timeRanges:[];
  const unconfirmed=unknownStart(state),last=state.platform?.lastRequest,pauseUnknown=Boolean(unconfirmed&&last?.requestId===(state.acquisitionAttempt?.payload?.requestId||last.requestId)&&last.job?.taskId&&live.canPause),locked=state.busy||unconfirmed||activeStatuses.includes(status)||status==='paused',taskResume=Boolean(!unconfirmed&&canResumeTask(state,live)),resume=Boolean(taskResume&&matchesTaskScope(state,current)),startAllowed=Boolean(!state.busy&&(unconfirmed||resume||!locked));
  const statusMessage=state.platformError?'状态暂未更新：'+state.platformError:unconfirmed?(last?.message||'上次开始采集的结果尚未确认，操作编号与原条件已保留；请核对有归属的任务，不能重复发起。'):live.message||state.platform?.device?.message||(!state.platform?'正在读取真实采集状态…':'');
  const message=[statusMessage,timeRanges.length&&!timeRanges.includes('最近24小时')?'当前支持最近7天、3天或30天；最近24小时暂不可用。':''].filter(Boolean).join(' ');
  return `<div class="acquire-page" data-page-acquire>
    <section class="acquire-card acquire-launch" aria-label="获客范围"><div class="acquire-fields">
      <label class="acquire-field"><span>门店</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-store aria-label="选择门店" ${locked?'disabled':''}>${!state.storeId?'<option value="" selected disabled>请选择门店</option>':''}${(state.stores||[]).map(item=>`<option value="${escape(item.id)}"${selected(state.storeId,item.id)}>${escape(item.name)}</option>`).join('')||'<option value="">待管理员分配门店</option>'}</select></div></label>
      <label class="acquire-field"><span>区域</span><div class="acquire-select-wrap">${icon('tabler-upgrade-pin.svg')}<select data-acquire-region aria-label="选择区域" ${locked?'disabled':''}>${draft.region?`<option>${escape(draft.region)}</option>`:`<option value="">${unconfirmed?'上次区域待核对':'门店区域待配置'}</option>`}</select></div></label>
      <label class="acquire-field"><span>时间</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-time aria-label="选择时间范围" title="以后台实际支持的日期范围为准；最近24小时暂不可用" ${locked?'disabled':''}>${!draft.time?'<option value="" selected disabled>上次条件待核对</option>':''}${['最近7天','最近3天','最近24小时','最近30天'].map(item=>`<option${selected(draft.time,item)}${timeRanges.includes(item)?'':' disabled'}>${escape(item)}</option>`).join('')}</select></div></label>
      <button class="acquire-start" data-acquire-start ${startAllowed?'':'disabled'}>${icon('icon-play-filled.svg')}<span>${state.busy?'处理中…':unconfirmed?'核对采集状态':resume?'继续获客':status==='completed'?'再次获客':'开始获客'}</span></button>
    </div><div class="acquire-launch-bottom"><button class="acquire-platform" data-acquire-platform aria-label="选择获客平台" ${locked?'disabled':''}>${escape(platform?.name||'平台尚未开通')}</button><button class="acquire-link" data-acquire-presets ${unconfirmed?'disabled':''}>更换门店预设 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div></section>
    <section class="acquire-card acquire-progress" aria-label="采集进度"><div class="acquire-card-heading"><h2>采集进度</h2><button class="acquire-link" data-acquire-records>查看记录 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
      <div class="acquire-stages"><ol>${['搜索','读取','保存','完成'].map((name,index)=>`<li class="${index===stage?'current ':''}${stage>index||status==='completed'?'complete ':''}"><span class="acquire-stage-dot">${stage>index||status==='completed'?icon('tabler-upgrade-check.svg'):''}</span><span>${name}</span></li>`).join('')}</ol><span class="acquire-status ${escape(status)}" aria-live="polite">${escape(state.platformLoading&&!state.platform?'正在读取':liveStatus(status))}</span></div>
      <div class="acquire-progress-bottom"><div class="acquire-metrics">${[['已读',counts.read],['新增',counts.added],['已分析',counts.analyzed],['重复',counts.duplicates]].map(([label,value])=>`<div><span>${label}</span><strong>${count(value)}</strong></div>`).join('<i aria-hidden="true">·</i>')}</div><button class="acquire-pause" data-acquire-pause title="${escape(taskResume?'继续原任务：'+taskCaption(state,live):'暂停当前任务')}" ${!state.busy&&(unconfirmed?pauseUnknown:(live.canPause||taskResume))?'':'disabled'}>${icon(taskResume?'icon-play-filled.svg':'fy-icon-54-pause.png')}<span>${taskResume?'继续':status==='pausing'?'暂停中':'暂停'}</span></button></div>
      ${message?`<p class="acquire-inline-error" role="status">${escape(message)}</p>`:''}
    </section>
    <section class="acquire-card acquire-recent" aria-label="最新意向"><div class="acquire-card-heading"><h2>最新意向</h2><button class="acquire-link" data-acquire-customers>查看客户清单 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div><div class="acquire-recent-list">${recentPeople(state).map((person,index)=>`<button class="acquire-person" data-live-acquire-person="${index}"><img class="acquire-avatar" src="/assets/approved-icon-user-round.svg" alt=""><strong>${escape(person.name||person.authorName||'平台客户')}</strong><span class="acquire-person-copy">${escape(person.copy||person.text||person.content||'')}</span><span class="acquire-intent">${escape(person.intent||person.level||'尚未分析')}</span><time>${escape(person.time||person.createdAt||'')}</time><img class="acquire-person-next" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>`).join('')||'<p class="muted">暂无本门店的真实采集结果。</p>'}</div></section>
  </div>`;
}
function bindConnected(root,ctx){
  clearTimeout(progressTimer);progressTimer=null;
  const {state}=ctx,{draft,live,platforms}=liveModel(state);
  root.querySelector('[data-acquire-store]')?.addEventListener('change',event=>{if(event.target.value)ctx.actions.selectStore(event.target.value);});
  root.querySelector('[data-acquire-region]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.region=event.target.value;}));
  root.querySelector('[data-acquire-time]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.time=event.target.value;}));
  root.querySelector('[data-acquire-presets]')?.addEventListener('click',()=>ctx.navigate('presets'));
  root.querySelector('[data-acquire-customers]')?.addEventListener('click',()=>ctx.navigate('customers'));
  root.querySelector('[data-acquire-platform]')?.addEventListener('click',()=>ctx.modal({title:'选择获客平台',html:`<div class="acquire-platform-options">${platforms.map(row=>`<label><input type="radio" name="live-acquire-platform" value="${escape(row.id)}" ${draft.selectedPlatform===row.id?'checked':''}> ${escape(row.name)}</label>`).join('')||'<p>当前企业尚未开通采集平台。</p>'}</div><p class="modal-note">仅使用当前门店已授权并核验的平台账号。</p>`,confirmLabel:'确认选择',onConfirm:()=>{const value=document.querySelector('input[name="live-acquire-platform"]:checked')?.value;if(!value)return false;ctx.update(s=>{s.acquire.selectedPlatform=value;});}}));
  root.querySelector('[data-acquire-start]')?.addEventListener('click',()=>{
    if(state.busy)return;
    if(unknownStart(state))return ctx.actions.verifyAcquisition?.();
    const current=liveModel(state);
    if(canResumeTask(state,current.live)&&matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(current.live.taskId);
    if(activeStatuses.includes(current.live.status)||current.live.status==='paused')return;
    return ctx.actions.startAcquisition?.();
  });
  root.querySelector('[data-acquire-pause]')?.addEventListener('click',()=>{
    if(state.busy)return;
    const current=liveModel(state),live=current.live,last=state.platform?.lastRequest;
    if(unknownStart(state)){
      if(last?.job?.taskId&&last.requestId===(state.acquisitionAttempt?.payload?.requestId||last.requestId)&&live.canPause)
        return ctx.actions.pauseAcquisition?.(last.job.taskId);
      return;
    }
    if(!canResumeTask(state,live))return live.canPause?ctx.actions.pauseAcquisition?.(live.taskId):undefined;
    if(matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(live.taskId);
    const taskId=live.taskId,actor=JSON.stringify([state.user,state.storeId]),scope=JSON.stringify(live.taskScope);
    return ctx.modal({title:'继续原任务',html:`<p>${escape(taskCaption(state,live))}</p>`,confirmLabel:'继续原任务',onConfirm:()=>{
      const fresh=liveModel(state).live;
      if(state.busy||unknownStart(state)||actor!==JSON.stringify([state.user,state.storeId])
          ||fresh.taskId!==taskId||!canResumeTask(state,fresh)||JSON.stringify(fresh.taskScope)!==scope)return false;
      return ctx.actions.resumeAcquisition?.(taskId);
    }});
  });
  root.querySelector('[data-acquire-records]')?.addEventListener('click',()=>ctx.modal({title:'采集记录',html:`<div class="acquire-records"><p>${escape(taskCaption(state,live))}</p><div class="acquire-record-summary"><strong>${escape(liveStatus(live.status))}</strong><span>已读 ${count(live.counts?.read)} · 新增 ${count(live.counts?.added)} · 已分析 ${count(live.counts?.analyzed)} · 重复 ${count(live.counts?.duplicates)}</span></div>${(Array.isArray(live.records)?live.records:[]).map(record=>`<div class="acquire-record-row"><span>${escape(record.text||record.message||'')}</span><b>${escape(record.status||'')}</b></div>`).join('')||'<p class="modal-note">当前没有可显示的真实采集记录。</p>'}</div>`,confirmLabel:'刷新状态',onConfirm:async()=>{await ctx.actions.refreshPlatform();return false;}}));
  for(const button of root.querySelectorAll('[data-live-acquire-person]'))button.onclick=()=>{const person=recentPeople(state)[Number(button.dataset.liveAcquirePerson)];if(person)ctx.modal({title:person.name||person.authorName||'采集结果',html:`<p>${escape(person.copy||person.text||person.content||'暂无正文')}</p><p class="muted">${escape(person.intent||person.level||'尚未分析')}</p>`});};
  return ()=>{clearTimeout(progressTimer);progressTimer=null;};
}
