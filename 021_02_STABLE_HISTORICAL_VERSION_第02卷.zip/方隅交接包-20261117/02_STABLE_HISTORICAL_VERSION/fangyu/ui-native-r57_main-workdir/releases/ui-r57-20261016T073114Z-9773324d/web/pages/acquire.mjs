const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const asset = name => `/assets/${name}`;
const icon = (name, cls='') => `<img class="acquire-icon ${cls}" src="${asset(name)}" alt="" aria-hidden="true">`;
let progressTimer = null;

function model(state) {
  state.store ||= '古北店';
  state.acquire ??= {region:'上海 · 长宁区',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  const a=state.acquire;
  if(a.run&&a.run.store!==state.store){
    if(['running','paused'].includes(a.status))a.records.unshift({text:`${a.run.store} · 已切换门店，本次演示结束`,status:'已停止'});
    Object.assign(a,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null,region:state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区'});
  }
  return state.acquire;
}
const phase = a => ({idle:'待开始',running:['搜索中','读取中','分析中','即将完成'][a.stage] || '采集中',paused:'已暂停',completed:'已完成',failed:'采集已中断'})[a.status];
const selected = (value, expected) => value === expected ? ' selected' : '';
const option = (text,value) => `<option${selected(value,text)}>${escape(text)}</option>`;

export function render(state) {
  const a = model(state);
  const active = a.status === 'running';
  const locked = ['running','paused'].includes(a.status);
  const recent = [{name:'小雨',copy:'长宁 · 预算3500 · 下月入住',intent:'超高意向',time:'10 分钟前',avatar:'portrait-woman-1.png',id:'rain'}, {name:'陈先生',copy:'九号线附近 · 一居',intent:'高意向',time:'28 分钟前',avatar:'portrait-man-1.png',id:'chen'}];
  return `<div class="acquire-page" data-page-acquire>
    <section class="acquire-card acquire-launch" aria-label="获客范围">
      <div class="acquire-fields">
        <label class="acquire-field"><span>门店</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-store aria-label="选择门店" ${locked?'disabled':''}>${['古北店','浦江店','徐汇店'].map(x=>option(x,state.store)).join('')}</select></div></label>
        <label class="acquire-field"><span>区域</span><div class="acquire-select-wrap">${icon('tabler-upgrade-pin.svg')}<select data-acquire-region aria-label="选择区域" ${locked?'disabled':''}>${['上海 · 长宁区','上海 · 闵行区','上海 · 徐汇区','上海 · 全市'].map(x=>option(x,a.region)).join('')}</select></div></label>
        <label class="acquire-field"><span>时间</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-time aria-label="选择时间范围" ${locked?'disabled':''}>${['最近7天','最近3天','最近24小时','最近30天'].map(x=>option(x,a.time)).join('')}</select></div></label>
        <button class="acquire-start" data-acquire-start ${active?'disabled':''}>${icon('icon-play-filled.svg')}<span>${a.status === 'paused'?'继续获客':a.status === 'failed'?'重新开始':a.status === 'completed'?'再次获客':'开始获客'}</span></button>
      </div>
      <div class="acquire-launch-bottom"><button class="acquire-platform" data-acquire-platform aria-label="选择获客平台" ${locked?'disabled':''}>${escape(a.platforms.join(' · '))}</button><button class="acquire-link" data-acquire-presets>更换门店预设 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
    </section>
    <section class="acquire-card acquire-progress" aria-label="采集进度">
      <div class="acquire-card-heading"><h2>采集进度</h2><button class="acquire-link" data-acquire-records>查看记录 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
      <div class="acquire-stages"><ol>${['搜索','读取','分析','完成'].map((name,index)=>`<li class="${index===a.stage?'current ':''}${(a.status==='completed'||index<a.stage)?'complete ':''}"><span class="acquire-stage-dot">${(a.status==='completed'||index<a.stage)?icon('tabler-upgrade-check.svg'):''}</span><span>${name}</span></li>`).join('')}</ol><span class="acquire-status ${escape(a.status)}" aria-live="polite">${escape(phase(a))}</span></div>
      <div class="acquire-progress-bottom"><div class="acquire-metrics">${[['已读',a.read],['新增',a.added],['已分析',a.analyzed],['重复',a.duplicates]].map(([label,count])=>`<div><span>${label}</span><strong>${count}</strong></div>`).join('<i aria-hidden="true">·</i>')}</div><button class="acquire-pause" data-acquire-pause ${!['running','paused','failed'].includes(a.status)?'disabled':''}>${icon(a.status==='paused'||a.status==='failed'?'icon-play-filled.svg':'fy-icon-54-pause.png')}<span>${a.status==='paused'?'继续':a.status==='failed'?'重试':'暂停'}</span></button></div>
      ${a.status==='failed'?'<p class="acquire-inline-error" role="alert">本次采集已暂停。可重试继续演示，已有结果会保留。</p>':''}
    </section>
    <section class="acquire-card acquire-recent" aria-label="最新意向">
      <div class="acquire-card-heading"><h2>最新意向</h2><button class="acquire-link" data-acquire-customers>查看客户清单 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
      <div class="acquire-recent-list">${recent.map(person=>`<button class="acquire-person" data-acquire-person="${person.id}"><img class="acquire-avatar" src="${asset(person.avatar)}" alt=""><strong>${person.name}</strong><span class="acquire-person-copy">${person.copy}</span><span class="acquire-intent">${person.intent}</span><time>${person.time}</time><img class="acquire-person-next" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>`).join('')}</div>
    </section>
  </div>`;
}

export function bind(root,ctx) {
  clearTimeout(progressTimer);
  const mount = root.querySelector('[data-page-acquire]');
  if (!mount) return () => {};
  const {state} = ctx;
  const a = model(state);
  const change = fn => ctx.update(s => fn(model(s),s));
  root.querySelector('[data-acquire-store]').addEventListener('change',event => change((a,s)=>{s.store=event.target.value;a.region=s.store==='浦江店'?'上海 · 闵行区':s.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区';}));
  root.querySelector('[data-acquire-region]').addEventListener('change',event => change(a=>{a.region=event.target.value;}));
  root.querySelector('[data-acquire-time]').addEventListener('change',event => change(a=>{a.time=event.target.value;}));
  root.querySelector('[data-acquire-presets]').addEventListener('click',()=>ctx.navigate('presets'));
  root.querySelector('[data-acquire-customers]').addEventListener('click',()=>ctx.navigate('customers'));
  root.querySelector('[data-acquire-platform]').addEventListener('click',()=>ctx.modal({title:'选择获客平台',html:`<div class="acquire-platform-options"><label><input type="checkbox" id="acquire-platform-xhs" ${a.platforms.includes('小红书')?'checked':''}> 小红书</label><label><input type="checkbox" id="acquire-platform-dy" ${a.platforms.includes('抖音')?'checked':''}> 抖音</label></div><p class="modal-note">所选平台将用于本次界面演示。</p>`,confirmLabel:'确认选择',onConfirm:()=>{
    const choices=[['acquire-platform-xhs','小红书'],['acquire-platform-dy','抖音']].filter(([id])=>document.getElementById(id)?.checked).map(([,name])=>name);
    if(!choices.length){ctx.toast('请至少选择一个平台');return false;}
    change(a=>{a.platforms=choices;});
  }}));
  const start = () => change(a=>{
    if(a.status==='paused'||a.status==='failed'){a.status='running';return;}
    Object.assign(a,{status:'running',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0});
    a.run={store:state.store,region:a.region,time:a.time};
    a.records.unshift({text:`${state.store} · ${a.time} · 开始采集`,status:'已开始'});
  });
  root.querySelector('[data-acquire-start]').addEventListener('click',start);
  root.querySelector('[data-acquire-pause]').addEventListener('click',()=>change(a=>{a.status=a.status==='running'?'paused':'running';}));
  root.querySelector('[data-acquire-records]').addEventListener('click',()=>ctx.modal({title:'采集记录',html:`<div class="acquire-records"><p>${escape(state.store)} · ${escape(a.region)} · ${escape(a.time)}</p><div class="acquire-record-summary"><strong>${escape(phase(a))}</strong><span>已读 ${a.read} · 新增 ${a.added} · 已分析 ${a.analyzed} · 重复 ${a.duplicates}</span></div>${a.records.length?a.records.map(record=>`<div class="acquire-record-row"><span>${escape(record.text)}</span><b>${escape(record.status)}</b></div>`).join(''):'<p class="modal-note">尚无本次采集记录，点击“开始获客”查看演示流程。</p>'}</div>`,confirmLabel:a.status==='running'?'模拟采集中断':'关闭',onConfirm:()=>{if(a.status==='running')change(a=>{a.status='failed';a.records.unshift({text:'模拟网络中断，进度保留',status:'可重试'});});}}));
  for(const button of root.querySelectorAll('[data-acquire-person]'))button.addEventListener('click',()=>{ctx.update(s=>{s.selectedCustomer=button.dataset.acquirePerson;});ctx.navigate('customers');});
  if(a.status==='running'){
    progressTimer=setTimeout(()=>{
      if(!mount.isConnected)return;
      change(a=>{
        if(a.status!=='running')return;
        a.tick++;
        a.stage=Math.min(3,Math.floor(a.tick/2));
        if(a.tick>=2){a.read=Math.min(128,(a.tick-1)*22);a.added=Math.min(36,Math.round(a.read*.28125));a.duplicates=Math.max(0,a.read-a.added);}
        if(a.tick>=4)a.analyzed=Math.min(a.added,(a.tick-3)*12);
        if(a.tick>=7){a.status='completed';a.stage=3;a.analyzed=a.added;a.records.unshift({text:`${a.run?.store||state.store} · 本次新增 ${a.added} 条意向线索`,status:'已完成'});}
      });
    },1250);
  }
  return ()=>{clearTimeout(progressTimer);progressTimer=null;};
}
