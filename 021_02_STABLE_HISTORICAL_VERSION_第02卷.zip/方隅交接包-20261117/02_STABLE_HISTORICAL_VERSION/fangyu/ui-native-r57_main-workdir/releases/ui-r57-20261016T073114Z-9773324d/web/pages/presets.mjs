const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const icon = name => `<img src="/assets/${name}" alt="" aria-hidden="true">`;
function model(state){state.store||='古北店';state.presets??={search:'精准获客',intent:'标准意向',tab:'presets',showWords:false,showRules:false};return state.presets;}
const words = store => store==='浦江店'?['浦江租房','附近一居','地铁通勤','周边商圈']:store==='徐汇店'?['徐汇租房','附近一居','地铁通勤','周边商圈']:['古北租房','附近一居','地铁通勤','周边商圈'];

export function render(state){
  const p=model(state),store=state.store;
  return `<div class="presets-page" data-page-presets>
    <div class="presets-tabs" role="tablist" aria-label="门店获客设置"><button role="tab" data-preset-tab="presets" aria-selected="${p.tab==='presets'}">门店预设</button><button role="tab" data-preset-tab="rules" aria-selected="${p.tab==='rules'}">规则说明</button></div>
    ${p.tab==='rules'?`<section class="preset-card preset-rules-page"><h2>规则说明</h2><p>搜索预设决定寻找哪些租房需求，意向预设决定优先处理哪些咨询。</p><div><h3>搜索预设</h3><p>精准获客：围绕门店附近的一居室、商圈与地铁通勤需求。通勤拓展：扩大到相邻区域及交通沿线。</p><h3>意向预设</h3><p>标准意向：综合租房需求、预算、区域与入住时间。优先近期入住：优先显示一个月内计划入住的咨询。</p><h3>回复建议</h3><p>超高 / 高意向建议人工回复，中意向可批量准备回复。所有动作均由用户确认。</p></div><button class="preset-secondary" data-preset-tab="presets">返回门店预设</button></section>`:`
    <section class="preset-card preset-store-card">
      <div class="preset-store-heading"><h2>选择门店</h2><p>选择门店后，将自动匹配该门店的搜索与意向预设</p></div>
      <div class="preset-stores">${[['古北店','古北核心区 · 成熟居住圈'],['浦江店','浦江新城 · 潜力发展区']].map(([name,description])=>`<button class="preset-store ${store===name?'selected':''}" data-preset-store="${name}" aria-pressed="${store===name}"><span class="preset-store-radio"></span><span><strong>${name}</strong><small>${description}</small></span><img src="/assets/fy-scene-01-apartment.png" alt="" aria-hidden="true"></button>`).join('')}<select class="preset-more-stores" data-preset-more aria-label="更多门店"><option value="">更多门店</option><option value="徐汇店" ${store==='徐汇店'?'selected':''}>徐汇店</option></select></div>
      <p class="preset-current-store">${icon('tabler-upgrade-pin.svg')}<span>当前门店：<strong>${escape(store)}</strong></span></p>
    </section>
    <section class="preset-card preset-plan-card">
      <div class="preset-columns">
        <section class="preset-column"><div class="preset-column-heading">${icon('approved-icon-search.svg')}<div><h2>搜索预设</h2><p>围绕本店位置，匹配附近租房需求</p></div></div>
          <select class="preset-plan-select" data-preset-search aria-label="搜索预设">${['精准获客','通勤拓展'].map(name=>`<option value="${name}"${p.search===name?' selected':''}>${escape(store)} · ${name}</option>`).join('')}</select>
          <div class="preset-choice-row" role="group" aria-label="搜索方案">${['精准获客','通勤拓展'].map(name=>`<button class="preset-choice ${p.search===name?'selected':''}" data-preset-search-choice="${name}" aria-pressed="${p.search===name}"><span>${p.search===name?icon('tabler-upgrade-check.svg'):''}</span>${name}</button>`).join('')}</div>
          <h3 class="preset-coverage-title">覆盖方向</h3><div class="preset-tags">${(p.search==='通勤拓展'?[...words(store).slice(0,2),'沿线通勤','相邻区域']:words(store)).map(word=>`<span>${word}</span>`).join('')}</div>
          <button class="preset-link" data-preset-words aria-expanded="${p.showWords}">查看完整搜索词库 <img class="preset-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>
          ${p.showWords?`<div class="preset-expanded"><h4>${escape(store)} · ${p.search}词库</h4><p>${[...words(store),store.replace('店','')+'找房','精装一居','近期入住','预算3500','近地铁租房','可养宠物'].map(escape).join('　')}</p></div>`:''}
        </section>
        <section class="preset-column"><div class="preset-column-heading">${icon('tabler-upgrade-user.svg')}<div><h2>意向预设</h2><p>自动识别租房需求与入住意向</p></div></div>
          <select class="preset-plan-select" data-preset-intent aria-label="意向预设">${['标准意向','优先近期入住'].map(name=>`<option value="${name}"${p.intent===name?' selected':''}>${escape(store)} · ${name}</option>`).join('')}</select>
          <div class="preset-choice-row" role="group" aria-label="意向方案">${['标准意向','优先近期入住'].map(name=>`<button class="preset-choice ${p.intent===name?'selected':''}" data-preset-intent-choice="${name}" aria-pressed="${p.intent===name}"><span>${p.intent===name?icon('tabler-upgrade-check.svg'):''}</span>${name}</button>`).join('')}</div>
          <div class="preset-intent-table"><div><strong>超高 / 高意向</strong><span>建议人工回复</span></div><div><strong>中意向</strong><span>可批量回复</span></div></div>
          <button class="preset-link" data-preset-rules aria-expanded="${p.showRules}">查看完整判断规则 <img class="preset-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>
          ${p.showRules?`<div class="preset-expanded"><h4>${p.intent}判断规则</h4><p>明确表达租房需求，并给出区域、预算或入住时间时优先显示。${p.intent==='优先近期入住'?'计划在一个月内入住的咨询优先。':'结合门店覆盖区域与一居需求，区分意向程度。'}超高及高意向由人工核对后回复。</p></div>`:''}
        </section>
      </div>
      <div class="preset-plan-footer"><div class="preset-combination"><span class="preset-combination-icon">${icon('tabler-upgrade-file.svg')}</span><div><strong>${escape(store)} · ${p.search} · ${p.intent}</strong><p>已选择该组合，应用后将按此预设进行内容采集与意向判断</p></div></div><button class="preset-apply" data-preset-apply>${icon('icon-play-filled.svg')}使用此预设</button></div>
    </section>`}
  </div>`;
}

export function bind(root,ctx){
  const change=fn=>ctx.update(state=>fn(model(state),state));
  for(const button of root.querySelectorAll('[data-preset-tab]'))button.addEventListener('click',()=>change(p=>{p.tab=button.dataset.presetTab;}));
  for(const button of root.querySelectorAll('[data-preset-store]'))button.addEventListener('click',()=>change((p,state)=>{state.store=button.dataset.presetStore;}));
  root.querySelector('[data-preset-more]')?.addEventListener('change',event=>{if(event.target.value)change((p,state)=>{state.store=event.target.value;});});
  root.querySelector('[data-preset-search]')?.addEventListener('change',event=>change(p=>{p.search=event.target.value;}));
  root.querySelector('[data-preset-intent]')?.addEventListener('change',event=>change(p=>{p.intent=event.target.value;}));
  for(const button of root.querySelectorAll('[data-preset-search-choice]'))button.addEventListener('click',()=>change(p=>{p.search=button.dataset.presetSearchChoice;}));
  for(const button of root.querySelectorAll('[data-preset-intent-choice]'))button.addEventListener('click',()=>change(p=>{p.intent=button.dataset.presetIntentChoice;}));
  root.querySelector('[data-preset-words]')?.addEventListener('click',()=>change(p=>{p.showWords=!p.showWords;}));
  root.querySelector('[data-preset-rules]')?.addEventListener('click',()=>change(p=>{p.showRules=!p.showRules;}));
  root.querySelector('[data-preset-apply]')?.addEventListener('click',()=>{
    const p=model(ctx.state);
    ctx.update(state=>{state.acquire??={region:'上海 · 长宁区',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};if(['running','paused'].includes(state.acquire.status)){state.acquire.records.unshift({text:`${state.acquire.run?.store||state.store} · 已应用新预设，本次演示结束`,status:'已停止'});Object.assign(state.acquire,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null});}state.acquire.region=state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区';state.acquire.searchPreset=p.search;state.acquire.intentPreset=p.intent;});
    ctx.navigate('acquire');ctx.toast(`已应用${ctx.state.store} · ${p.search} · ${p.intent}`);
  });
  return ()=>{};
}
