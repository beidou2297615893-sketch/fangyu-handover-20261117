"""Device enrollment and outbound worker lifecycle; no inbound remote control port."""
import json
import hashlib
import logging
import os
import subprocess
import re
import secrets
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

from integrations import protect
from .business import BusinessExecutor, xiaohongshu_held
from .runner import AssistantRunner, Journal
from .transport import CloudTransport, CloudError
from .login_outcome import classify_login_failure
from .employee_distribution import runtime_config_valid as employee_runtime_config_valid
from core.account_safety import record_manual_signal, summarize_activity, account_review_view
from core.adapters import Adapters, AdapterBusy, account_execution_lock
from core import CoreError


class AccountLoginError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


class DeviceVault:
    def __init__(self, directory, environment_id, company_id):
        self.path = Path(directory) / 'device.dpapi'
        self.identity = {'environment_id': environment_id, 'company_id': company_id}

    def read(self):
        if not self.path.exists():
            return None
        value = json.loads(protect(self.path.read_bytes(), decrypt=True))
        if any(value.get(k) != v for k, v in self.identity.items()):
            raise ValueError('设备绑定属于另一个企业，不能复用')
        if value.get('state') not in ('pending', 'bound'):
            raise ValueError('设备绑定记录损坏')
        if not re.fullmatch(r'[A-Za-z0-9_-]{40,100}', value.get('token', '')):
            raise ValueError('设备凭证损坏')
        return value

    def write(self, value):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        encrypted = protect(json.dumps({**value, **self.identity}).encode('utf-8'))
        temporary = self.path.with_suffix('.tmp')
        with temporary.open('wb') as stream:
            stream.write(encrypted)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, self.path)


class AssistantService:
    def __init__(self, server, cloud_factory=CloudTransport, executor_factory=BusinessExecutor, *, explicit_local=False):
        if type(explicit_local) is not bool:raise ValueError('本机显式操作模式无效')
        self.explicit_local=explicit_local
        config = server.company['managedWorkspace']
        self.server = server
        self.directory = server.core.store.directory / 'assistant'
        self.environment_id = config['environment_id']
        self.company_id = server.company['id']
        self.endpoint = config['endpoint']
        self.vault = DeviceVault(self.directory, self.environment_id, self.company_id)
        self.cloud_factory = cloud_factory
        self.executor_factory = executor_factory
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.executor = None
        self.binding = False
        self.closed = False
        self.state = 'unbound'
        self.device = None
        self.contact_sync_error = ''
        self.manual_owned_read_start=getattr(server,"manual_owned_read_start",False) is True
        self._manual_snapshot_binding=None
        self._manual_snapshot_at=None
        if not self.manual_owned_read_start and not explicit_local:self._remove_stale_login_qr()
        saved = self.vault.read()
        if saved:
            self.state = 'pending' if saved['state'] == 'pending' else 'offline'
            self.device = saved.get('device')

    def _remove_stale_login_qr(self):
        # No login jobs survive a process restart; retain every non-login file.
        work = self.server.core.store.directory / 'work'
        if not work.is_dir():
            return
        try:
            paths = list(work.iterdir())
        except OSError:
            logging.exception('Could not inspect stale login QR artifacts')
            return
        for path in paths:
            if re.fullmatch(r'[0-9a-f]{24}\.(?:png|error\.json)', path.name):
                try:
                    path.unlink()
                except OSError:
                    logging.exception('Could not remove stale login QR artifact')

    def _cloud(self):
        return self.cloud_factory(self.endpoint, self.environment_id, self.company_id)

    def _pause_xhs_identity(self, account, status, message):
        with self.server.core.lock:
            current = self.server.core.store.get('accounts', account['id'])
            if current:
                if status == 'check_required' and current.get('status') == 'login_required':
                    # A phone report is not evidence that the computer session recovered.
                    status = 'login_required'
                    message = '电脑登录需要更新；已请求停止平台操作，请先核对手机，再为此账号重新登录'
                current['status'] = status
                self.server.core.store.put('accounts', current)
                for task in self.server.core.store.list('tasks', current['tenant_id']):
                    if task.get('account_id') == account['id']:
                        task.update(status='paused', last_message=message)
                        self.server.core.store.put('tasks', task)

    def _claim_xhs_account(self, account):
        uid = str(account.get('platform_uid') or '').strip()
        if account.get('platform') != 'xiaohongshu' or not uid:
            raise CoreError('小红书账号身份无法核对，停止平台操作')
        try:
            saved = self.vault.read()
        except Exception:
            logging.exception('Could not read device binding for Xiaohongshu identity check')
            self._pause_xhs_identity(account, 'identity_cloud_unavailable', '企业设备绑定不可用，相关任务已暂停')
            raise CoreError('企业设备绑定不可用，停止小红书平台操作') from None
        if not saved or saved.get('state') != 'bound':
            self._pause_xhs_identity(account, 'identity_cloud_unavailable', '企业设备未绑定，相关任务已暂停')
            raise CoreError('本地助手尚未绑定企业电脑，停止小红书平台操作')
        cloud = None
        uid_hash = hashlib.sha256(uid.encode('utf-8')).hexdigest()
        try:
            cloud = self._cloud()
            response = cloud.call('device_account_claim', {
                'account_id': account['id'],
                'uid_hash': uid_hash,
            }, saved['token'])
            if response.get('claimed') is not True:
                raise CoreError('企业账号身份未确认，停止小红书平台操作')
        except CloudError as error:
            if error.status == 409:
                try:
                    # A deleted local account can leave a conservative cloud claim.
                    # Rebind only within this device, after confirming the old
                    # account record is absent. The cloud update is atomic.
                    prior = cloud.call('device_account_lookup', {'uid_hash': uid_hash}, saved['token']).get('account_id')
                    if prior and prior != account['id'] and self.server.core.store.get('accounts', prior) is None:
                        rebound = cloud.call('device_account_claim', {
                            'account_id': account['id'], 'uid_hash': uid_hash,
                            'replaces_account_id': prior,
                        }, saved['token'])
                        if rebound.get('claimed') is True:
                            return
                except CloudError as recovery_error:
                    if recovery_error.status != 409:
                        message='企业账号身份校验暂不可用，相关任务已暂停'
                        self._pause_xhs_identity(account, 'identity_cloud_unavailable', message)
                        raise CoreError(message) from None
                except Exception:
                    logging.exception('Cloud Xiaohongshu identity rebind failed')
                    message='企业账号身份校验暂不可用，相关任务已暂停'
                    self._pause_xhs_identity(account, 'identity_cloud_unavailable', message)
                    raise CoreError(message) from None
                message='小红书身份与企业登记冲突；相关任务已暂停，请管理员核对其他电脑、重复记录或扫码账号'
                self._pause_xhs_identity(account, 'duplicate_identity_remote', message)
                raise CoreError(message) from None
            message='企业账号身份校验暂不可用，相关任务已暂停'
            self._pause_xhs_identity(account, 'identity_cloud_unavailable', message)
            raise CoreError(message) from None
        except Exception:
            logging.exception('Cloud Xiaohongshu identity check failed')
            message='企业账号身份校验暂不可用，相关任务已暂停'
            self._pause_xhs_identity(account, 'identity_cloud_unavailable', message)
            raise CoreError(message) from None
        finally:
            if cloud:
                cloud.close()

    def _identity_observation_availability(self):
        from .xhs_identity_policy import XhsIdentityObservationPolicy
        policy=getattr(self.server,'_xhs_identity_policy',None)
        value=(policy.describe() if type(policy) is XhsIdentityObservationPolicy else
               dict(status='unsupported',reason='source_scope_unavailable',
                    purpose='identity_observation',read_only=True,account_ready=False))
        # Description only selects the explicit UI entry; the worker freshly
        # checks the original DeviceSession, account, materials and OS locks.
        with self.lock:
            online=(self.state=='online' and not self.closed and self.executor is not None
                    and bool((self.device or {}).get('owner')))
        if value['status']=='available' and not online:
            value.update(status='blocked',reason='device_not_online')
        if value['status']=='available' and self.server.core.remote_safety_hold:
            value.update(status='blocked',reason='remote_hold')
        return value

    def _session_recovery_availability(self):
        from .xhs_session_policy import XhsSessionRecoveryPolicy
        policy=getattr(self.server,'_xhs_session_policy',None)
        return policy.describe() if type(policy) is XhsSessionRecoveryPolicy else {
            'status':'unsupported','reason':'source_scope_unavailable','purpose':'session_recovery'}

    def bilibili_setup(self, operation, data):
        from .bilibili_setup_service import BilibiliSetupService
        with self.lock:
            if getattr(self,'_bilibili_setup_stopping',False):
                raise ValueError('本机配置服务正在关闭')
            setup=getattr(self,'_bilibili_setup_service',None)
            if setup is None:
                setup=BilibiliSetupService(self)
                self._bilibili_setup_service=setup
        # Original synchronous GET / process cleanup runs outside service and
        # account connection locks, so status and cancel can enter concurrently.
        return setup.execute(operation,data)

    def _cancel_bilibili_setups(self,*,permanent=False,account_id=None):
        with self.lock:setup=getattr(self,'_bilibili_setup_service',None)
        if setup is not None:setup.cancel_all(permanent=permanent,account_id=account_id)

    def _account_slot_capabilities(self):
        from core.entitlements import capability_summary
        from .xhs_app_context import _DeviceSession
        blocked={'platforms':[],'canAddAccount':False,'canCreateAccountSlot':False}
        try:
            with self.server.core.lock:
                with self.lock:
                    executor=self.executor
                    if (self.closed or self.stop_event.is_set() or self.server.closing
                            or self.state not in ('online','held') or type(executor) is not BusinessExecutor):
                        return blocked
                user=self._local_user(read_only=True)
                session=getattr(executor,'_xhs_app_session',None)
                if type(session) is not _DeviceSession or session.service is not self:
                    return blocked
                session.check()
                summary=capability_summary(self.server.core._policy(),
                    self.server.core.store.list('accounts',user['tenant_id']))
                return {**summary,'canCreateAccountSlot':True}
        except (ValueError,CoreError,OSError):
            return blocked

    def wechat_preview(self,operation,data):
        from .wechat_preview_service import WechatPreviewService
        return WechatPreviewService(self).execute(operation,data)

    def douyin_connection(self,operation,data):
        from .douyin_connection_service import DouyinConnectionService
        with self.lock:
            helper=getattr(self,'_douyin_connection_service',None)
            if helper is None:
                helper=DouyinConnectionService(self);self._douyin_connection_service=helper
        return helper.execute(operation,data)

    def status(self):
        from .douyin_connection_service import douyin_connection_availability
        douyin_connection=douyin_connection_availability(self)
        from .wechat_preview_service import availability
        wechat_preview=availability(self)
        from .bilibili_setup_service import bilibili_setup_availability
        bilibili_setup=bilibili_setup_availability(self)
        slot_capabilities=self._account_slot_capabilities()
        slot_platforms=[platform for platform in slot_capabilities['platforms']
            if platform in ('douyin','zhihu','wechat_channels','bilibili','kuaishou','weibo')]
        slot_available=(slot_capabilities['canCreateAccountSlot'] and
                        slot_capabilities['canAddAccount'] and bool(slot_platforms))
        account_slot_create={'purpose':'account_slot_create',
            'status':'available' if slot_available else 'blocked',
            'reason':('bound_local_record_only' if slot_available else
                      'device_not_bound' if not slot_capabilities['canCreateAccountSlot'] else
                      'platforms_unavailable' if not slot_platforms else 'account_limit_reached'),
            'allowed_platforms':slot_platforms,'can_add_account':slot_capabilities['canAddAccount']}
        session_recovery=self._session_recovery_availability()
        identity_observation=self._identity_observation_availability()
        public_site=self.server.company.get('publicSiteUrl') or ''
        candidate=public_site or (self.server.company.get('managedWorkspace') or {}).get('endpoint') or ''
        if not isinstance(candidate,str):candidate=''
        parsed=urlparse(candidate)
        workspace_url=(candidate if parsed.scheme=='https' and parsed.hostname and not parsed.username
                       and not parsed.password and not parsed.query and not parsed.fragment else '')
        company_runtime=self.server.company.get('runtime') or {}
        core_runtime=(getattr(self.server.core,'deployment_config',{}) or {}).get('runtime') or {}
        local_hold=(isinstance(company_runtime,dict) and company_runtime.get('xiaohongshu_automation')=='hold'
                    or isinstance(core_runtime,dict) and core_runtime.get('xiaohongshu_automation')=='hold')
        effective_hold=xiaohongshu_held(self.server) or self.state=='held'
        # Pairing is a local UI capability, never a grant to run platform work.
        # The cloud heartbeat still controls the employee read lease.
        pairing_allowed=(local_hold and (
            self.server.company.get('id')=='fangyu-apartment-client'
            and self.server.company.get('releaseVersion')=='1.1.7-qa.1'
            or employee_runtime_config_valid(self.server.company)
            and employee_runtime_config_valid(self.server.core.deployment_config)))
        offline_user=None
        try:
            offline_user=self._offline_safety_user()
        except ValueError:
            pass
        with self.lock:
            owner=(self.device or {}).get('owner') or ''
            tenant='cloud-'+hashlib.sha256((self.environment_id+'\n'+self.company_id).encode()).hexdigest()[:24]
            contact_journal=getattr(self.server.core,'contact_journal',None)
            contact_status=(contact_journal.status(tenant,owner) if owner and contact_journal else
                            {'total':0,'unsynced':0,'needs_identity':0})
            contact_status['sync_error']=self.contact_sync_error
            safety_available=(self.state in ('online','held','offline')
                              and self.executor is not None
                              and bool((self.device or {}).get('owner'))) or (
                                  offline_user is not None and self.executor is None
                                  and self.state in ('offline','error','stopped')
                                  and (self.device or {}).get('owner')==offline_user['username'])
            manual_snapshot_current=self._manual_snapshot_current() if self.manual_owned_read_start else False
            return {'state': self.state, 'device': self.device,
                    'startup_mode':'manual_owned_read' if self.manual_owned_read_start else 'automatic',
                    'manual_read':{'status':'held','reason':'execution_authority_not_activated' if manual_snapshot_current else 'authority_snapshot_unavailable',
                        'automatic_tasks':False,'automatic_analysis':False,'contact_sync':False,
                        'permission_snapshot_observed':manual_snapshot_current,
                        'snapshot_at':self._manual_snapshot_at if manual_snapshot_current else None,
                        'platform_actions_allowed':False} if self.manual_owned_read_start else None,
                    'account_slot_create':account_slot_create,
                    'identity_observation':identity_observation,
                    'session_recovery':session_recovery,
                    'bilibili_setup':bilibili_setup,
                    'douyin_connection':douyin_connection,
                    'wechat_preview':wechat_preview,
                    'contact_events':contact_status,
                    'reply_trial':{'active':bool(self.server.core.reply_trial.value and time.monotonic()<self.server.core.reply_trial.deadline),
                        'remaining_seconds':max(0,int(self.server.core.reply_trial.deadline-time.monotonic()))},
                    'login_method': 'browser' if getattr(self.server,'browser_login_enabled',False) else 'qr',
                    'xhs_read_transport': 'page' if getattr(self.server,'xhs_page_runtime',None) is not None else 'cli',
                    'xhs_page_read_mode': ('natural' if getattr(getattr(self.server,'xhs_page_runtime',None),'natural_mode',False)
                                           else 'legacy'),
                    'binding': self.binding, 'running': bool(self.thread and self.thread.is_alive()),
                    'account_safety_available': safety_available,
                    'pairingAllowed': pairing_allowed,
                    'platform_qa': bool(company_runtime.get('platform_qa_device_id')),
                    'safety_hold': effective_hold, 'workspace_url': workspace_url,
                    'hold_reason': 'local' if effective_hold and local_hold else 'cloud' if self.state=='held' else
                                   'remote_unconfirmed' if getattr(self.server.core,'remote_safety_hold',False) else '',
                    'workspace_is_test': bool(workspace_url and not public_site)}

    def _state(self, value):
        with self.lock:
            self.state = value

    def _contact_sync_state(self,error):
        with self.lock:self.contact_sync_error=error

    def bind(self, code):
        code = str(code).strip()
        if not re.fullmatch(r'[A-Za-z0-9_-]{40,100}', code):
            raise ValueError('请复制网页生成的完整连接码')
        with self.lock:
            if self.closed or self.binding:
                raise ValueError('助手正在关闭或绑定，请稍后重试')
            saved = self.vault.read()
            if saved and saved['state'] == 'bound':
                raise ValueError('此助手已绑定员工，不能替换身份')
            if saved and saved['code'] != code:
                raise ValueError('上次绑定尚未确认，请使用原连接码重试')
            if not saved:
                saved = {'state': 'pending', 'token': secrets.token_urlsafe(48), 'code': code}
                # Persist BEFORE enrollment: retry after a lost response uses the same token.
                self.vault.write(saved)
            self.binding = True
            self.state = 'binding'
        cloud = None
        try:
            cloud = self._cloud()
            response = cloud.call('device_enroll', {'device_token': saved['token'],
                'version': self.server.company.get('releaseVersion', 'unknown')}, code)
            raw = response.get('device', {})
            if not isinstance(raw.get('id'), str) or not raw['id'] or not isinstance(raw.get('owner'), str) or not raw['owner'] or raw.get('revoked'):
                raise ValueError('企业服务返回了无效的设备身份')
            device = {k: raw.get(k) for k in ('id', 'name', 'owner', 'version', 'last_seen')}
            self.vault.write({'state': 'bound', 'token': saved['token'], 'device': device})
            with self.lock:
                self.device = device
                self.state = 'offline'
        except Exception:
            self._state('pending')
            raise
        finally:
            if cloud:
                cloud.close()
            with self.lock:
                self.binding = False
        self.start()
        return self.status()

    def replace_pending(self, code):
        """Only replace a pending code after asking cloud whether it already enrolled."""
        code = str(code).strip()
        if not re.fullmatch(r'[A-Za-z0-9_-]{40,100}', code):
            raise ValueError('请复制网页生成的完整新连接码')
        with self.lock:
            if self.closed or self.binding:
                raise ValueError('助手正在关闭或绑定')
            saved = self.vault.read()
            if not saved:
                return self.bind(code)
            if saved['state'] != 'pending':
                raise ValueError('助手已经绑定，不能更换员工')
            if saved['code'] == code:
                return self.bind(code)
            self.binding = True
        cloud = None
        try:
            cloud = self._cloud()
            try:
                response = cloud.call('device_identity', {}, saved['token'])
            except CloudError as error:
                if error.status != 401:
                    raise
                # This token was never enrolled or has been revoked. A fresh
                # code gets a fresh device token; the old encrypted code leaves disk.
                self.vault.path.unlink()
                self._state('unbound')
            else:
                raw = response.get('device', {})
                if not raw.get('id') or not raw.get('owner') or raw.get('revoked'):
                    raise ValueError('企业服务返回了无效的设备身份')
                device = {k: raw.get(k) for k in ('id', 'name', 'owner', 'version', 'last_seen')}
                self.vault.write({'state': 'bound', 'token': saved['token'], 'device': device})
                with self.lock:
                    self.device = device
                    self.state = 'offline'
        finally:
            if cloud:
                cloud.close()
            with self.lock:
                self.binding = False
        current = self.vault.read()
        if current and current['state'] == 'bound':
            self.start()
            return self.status()
        return self.bind(code)

    def start(self):
        with self.lock:
            if self.closed or (self.thread and self.thread.is_alive()):
                return
            saved = self.vault.read()
            if not saved or saved['state'] != 'bound':
                return
            self.server.core.remote_safety_hold=True
            if self.manual_owned_read_start:
                self.state='held'
                return  # No executor/session, Journal, Runner, AI, poll or sync worker.
            self.stop_event.clear()
            self.thread = threading.Thread(target=self._run, args=(saved,), name='assistant-poll', daemon=True)
            self.thread.start()

    def _manual_snapshot_current(self):
        if not self.manual_owned_read_start or self.closed or self._manual_snapshot_binding is None:
            return False
        try:
            if type(self._manual_snapshot_at) is not int or not 0<=time.time()-self._manual_snapshot_at<=45:
                return False
            from .xhs_app_context import _session_snapshot
            return _session_snapshot(self,self.vault.read())==self._manual_snapshot_binding
        except Exception:
            return False

    def manual_permission_snapshot(self):
        """Explicit pure cloud snapshot; never a platform grant or lease."""
        if not self.manual_owned_read_start or self.closed:
            raise ValueError('手动设备身份核对不可用')
        self._offline_safety_user()  # Existing owner read; never revive a disabled user.
        with self.lock:
            saved=self.vault.read()
            if (not saved or saved.get('state')!='bound'
                    or (saved.get('device') or {}).get('id')!=(self.device or {}).get('id')
                    or (saved.get('device') or {}).get('owner')!=(self.device or {}).get('owner')):
                raise ValueError('本机设备绑定无法核实')
        from .xhs_app_context import _session_snapshot
        expected_binding=_session_snapshot(self,saved)
        cloud=None
        try:
            cloud=self._cloud()
            response=cloud.device_permission_snapshot(saved['token'])
            raw=response.get('device')
            if (not isinstance(raw,dict) or raw.get('id')!=saved['device'].get('id')
                    or raw.get('owner')!=saved['device'].get('owner') or raw.get('revoked') is True):
                raise ValueError('企业设备身份无法核实')
            with self.lock:
                if self.closed or self.vault.read()!=saved:
                    raise ValueError('本机设备绑定已变化')
                if _session_snapshot(self,self.vault.read())!=expected_binding:
                    raise ValueError('本机设备绑定已变化')
                self._manual_snapshot_binding=expected_binding
                self._manual_snapshot_at=response['snapshot_at']
                self.state='held'
            # Snapshot facts do not enter the original executor/lease lifecycle.
            self.server.core.remote_safety_hold=True
            return {'purpose':'manual_owned_read','status':'held',
                'reason':'execution_authority_not_activated','permission_snapshot_observed':True,
                'snapshot_at':response['snapshot_at'],
                'platform_actions_allowed':False,'automatic_tasks':False}
        except Exception:
            with self.lock:
                self._manual_snapshot_binding=None
                self._manual_snapshot_at=None
            self.server.core.remote_safety_hold=True
            raise ValueError('设备身份或完整许可未确认，平台操作保持暂停') from None
        finally:
            if cloud:cloud.close()

    def _pause_platform_work(self, executor, state='held'):
        with self.server.core.lock:
            self.server.core.qa_continuous_device_id=''
            self.server.core.qa_continuous_until_monotonic=0.0
            self.server.core.qa_continuous_max_batches=2
            self.server.core.employee_release_device_id=''
            self.server.core.employee_release_until_monotonic=0.0
        with self.server.core.lock:self.server.core.remote_safety_hold=True
        self._state(state)
        self._cancel_bilibili_setups()
        with self.server.job_lock:
            recovery_jobs=[job for job in self.server.jobs.values()
                if job.get('purpose')=='session_recovery' and not job['worker_done'].is_set()]
        from .xhs_session_worker import cancel_session_recovery
        for job in recovery_jobs:cancel_session_recovery(self,job)
        with self.server.job_lock:
            login_processes=[]
            for job in self.server.jobs.values():
                if (job.get('kind')=='assistant_account_login' and job.get('status')=='running'
                        and job.get('purpose')!='session_recovery'):
                    if job.get('persistent_browser') is True and state in {'held','offline'}:
                        # A temporary cloud pause revokes all platform leases
                        # above, but does not close the person's CAPTCHA page.
                        job.update(status='failed', phase='waiting_manual_check',
                            error='平台操作已暂停；本人网页登录窗口保持打开，连接恢复后可手动核对',
                            error_code='cloud_safety_hold')
                        continue
                    job.update(status='cancelled',error='企业云端已暂停平台操作；扫码结果待人工核实',error_code='cloud_safety_hold')
                    if job.get('process'):login_processes.append(job['process'])
        for process in login_processes:
            if process.poll() is None:
                try:process.terminate()
                except OSError:pass
        # Core.handle may hold the business lock throughout a platform call.
        # Terminate the owned process first, then wait to mark the task paused.
        self.server.core.adapters.abort_active()
        executor.stop_owned_tasks()

    def _qa_continuous_heartbeat(self, executor, allowed, remaining, poll_started, max_batches=2):
        core=self.server.core
        qa_device=(self.server.company.get('runtime') or {}).get('platform_qa_device_id','')
        # Bound the lease to the start of the authenticated poll. A delayed
        # response cannot create a fresh 45-second window after it arrives.
        deadline=poll_started+min(45,remaining) if allowed and qa_device else 0.0
        with core.lock:
            was_active=bool(core.qa_continuous_device_id)
            downgraded=was_active and core.qa_continuous_max_batches==0 and max_batches!=0
            if deadline>time.monotonic() and not core.remote_safety_hold:
                core.qa_continuous_device_id=qa_device
                core.qa_continuous_until_monotonic=deadline
                core.qa_continuous_max_batches=0 if type(max_batches) is int and max_batches==0 else 2
                stop_current=downgraded
            else:
                core.qa_continuous_device_id=''
                core.qa_continuous_until_monotonic=0.0
                core.qa_continuous_max_batches=2
                stop_current=was_active
        if stop_current:
            core.adapters.abort_active()
            executor.stop_owned_tasks()

    def _employee_release_heartbeat(self, executor, allowed, seconds, poll_started):
        core=self.server.core
        device=(self.device or {}).get('id','')
        # An authenticated poll's start time bounds the lease even if the
        # response is delayed. No local config value can renew it.
        deadline=poll_started+seconds if allowed and device else 0.0
        with core.lock:
            was_active=bool(core.employee_release_device_id)
            if deadline>time.monotonic() and not core.remote_safety_hold:
                core.employee_release_device_id=device
                core.employee_release_until_monotonic=deadline
                stop_current=False
            else:
                core.employee_release_device_id=''
                core.employee_release_until_monotonic=0.0
                stop_current=was_active
        if stop_current:
            core.adapters.abort_active()
            executor.stop_owned_tasks()

    def _qa_continuous_watchdog(self, executor):
        core=self.server.core
        while not self.stop_event.wait(.5):
            with core.lock:
                expired=bool(core.qa_continuous_device_id and time.monotonic()>=core.qa_continuous_until_monotonic)
                if expired:
                    core.qa_continuous_device_id=''
                    core.qa_continuous_until_monotonic=0.0
                    core.qa_continuous_max_batches=2
                employee_expired=bool(core.employee_release_device_id
                    and time.monotonic()>=core.employee_release_until_monotonic)
                if employee_expired:
                    core.employee_release_device_id=''
                    core.employee_release_until_monotonic=0.0
            if expired or employee_expired:
                core.adapters.abort_active()
                executor.stop_owned_tasks()

    def _resume_platform_work(self):
        self.server.core.remote_safety_hold=False
        self._state('online')

    def _reply_trial_heartbeat(self,executor,value,poll_started):
        core=self.server.core
        device=(self.server.company.get('runtime') or {}).get('platform_qa_device_id','')
        with core.lock:
            core.reply_trial.heartbeat(value,device,executor.owner,poll_started)

    def _run(self, saved):
        cloud = journal = runner = None
        try:
            # A provisional native update may create the assistant thread before
            # its window is proven ready, but must not contact cloud or run work.
            startup_gate=getattr(self.server,'update_startup_gate',None)
            while startup_gate is not None and not startup_gate.wait(.1):
                if self.stop_event.is_set():return
            if self.stop_event.is_set():return
            qa_device=(self.server.company.get('runtime') or {}).get('platform_qa_device_id','')
            portable_requested=((self.server.company.get('runtime') or {}).get('portable_employee_release') is True
                or (self.server.core.deployment_config.get('runtime') or {}).get('portable_employee_release') is True)
            portable_employee=(employee_runtime_config_valid(self.server.company)
                               and employee_runtime_config_valid(self.server.core.deployment_config))
            if qa_device and saved['device']['id']!=qa_device:
                raise ValueError('本机绑定与指定内部验收设备不一致，平台操作保持暂停')
            cloud = self._cloud()
            journal = Journal(self.directory / ('explicit-local-executions.sqlite3' if self.explicit_local else 'executions.sqlite3'))
            executor = self.executor_factory(self.server, self.environment_id, self.company_id, saved['device']['owner'])
            if isinstance(executor, BusinessExecutor):
                executor.account_claim = self._claim_xhs_account
                if not self.explicit_local:
                    from .ai_worker import AIWorker
                    self.ai_worker=AIWorker(executor)
                    self.ai_worker.start()
            with self.lock:
                self.executor = executor
            if type(executor) is BusinessExecutor:
                from .xhs_app_context import bind_executor_session
                bind_executor_session(self,executor,saved)
            runner = AssistantRunner(cloud, saved['token'], journal, executor,
                                     version=self.server.company.get('releaseVersion', 'unknown'),
                                     on_revoke=lambda:self._pause_platform_work(executor,'revoked'),
                                     on_hold=lambda:self._pause_platform_work(executor),
                                     on_resume=self._resume_platform_work,
                                     require_release_state=True,initial_hold=True,
                                     contact_sync_autostart=not self.explicit_local,
                                     accept_commands=not self.explicit_local,
                                     platform_qa_device_id=qa_device,
                                     on_permissions=getattr(executor,'sync_permissions',lambda value:None),
                                     contact_journal=getattr(self.server.core,'contact_journal',None),
                                     contact_tenant=getattr(executor,'tenant',''),contact_owner=saved['device']['owner'],
                                     on_contact_sync=self._contact_sync_state,
                                     on_qa_continuous=lambda allowed,remaining,started:self._qa_continuous_heartbeat(
                                         executor,allowed,remaining,started,runner.qa_continuous_max_batches),
                                     portable_employee_release=portable_requested,
                                     employee_device_id=saved['device']['id'] if portable_employee else '',
                                     workbench_source_release=((self.server.company.get('runtime') or {}).get(
                                         'workbench_source_release','') if employee_runtime_config_valid(self.server.company) else ''),
                                     on_employee_release=lambda allowed,seconds,started:self._employee_release_heartbeat(
                                         executor,allowed,seconds,started))
            if qa_device or portable_requested:
                if qa_device:
                    runner.on_reply_trial=lambda value,started:self._reply_trial_heartbeat(executor,value,started)
                threading.Thread(target=self._qa_continuous_watchdog,args=(executor,),name='qa-continuous-watchdog',daemon=True).start()
            backoff = 1
            while not self.stop_event.is_set():
                try:
                    delay = runner.step()
                    self.employee_release_reason=getattr(runner,'employee_release_reason','')
                    self._state('held' if runner.hold_active else 'online')
                    backoff = 1
                except CloudError as error:
                    if error.status in (401, 403):
                        self._state('revoked')
                        break
                    # The worker may still be collecting when its control plane
                    # disconnects. Stop locally before waiting for reconnection.
                    self._pause_platform_work(executor,'offline')
                    runner.hold_active=True;runner.hold_notified=True
                    delay = backoff
                    backoff = min(30, backoff * 2)
                except Exception:
                    logging.exception('Assistant polling step failed')
                    self._pause_platform_work(executor,'offline')
                    runner.hold_active=True;runner.hold_notified=True
                    delay = backoff
                    backoff = min(30, backoff * 2)
                self.stop_event.wait(delay)
        except Exception:
            logging.exception('Assistant startup failed')
            self._state('error')
        finally:
            if getattr(self,'ai_worker',None):self.ai_worker.close()
            with self.server.core.lock:
                self.server.core.qa_continuous_device_id=''
                self.server.core.qa_continuous_until_monotonic=0.0
                self.server.core.employee_release_device_id=''
                self.server.core.employee_release_until_monotonic=0.0
            self.server.core.remote_safety_hold=True
            if self.executor:
                self.executor.stop_owned_tasks()
            if runner:
                runner.close()
            if journal:
                journal.close()
            if cloud:
                cloud.close()
            with self.lock:
                self.executor = None
                if self.state not in ('revoked', 'error'):
                    self.state = 'stopped'

    def _local_user(self,*,read_only=False):
        with self.lock:
            executor = self.executor
            owner = (self.device or {}).get('owner')
        if not executor or not owner:
            raise ValueError('助手尚未在线，请先完成电脑连接')
        tenant='cloud-'+hashlib.sha256((self.environment_id+'\n'+self.company_id).encode()).hexdigest()[:24]
        ident=hashlib.sha256((tenant+'\n'+owner).encode()).hexdigest()
        saved=self.server.core.store.get('users',ident)
        if (not saved or saved.get('username')!=owner or saved.get('tenant_id')!=tenant
                or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('role') not in ('admin','operator')):
            raise ValueError('本机绑定身份尚未核实')
        verified=self.server.integrations.verify_identity(saved,expected_user=saved)
        if not verified or verified.get('role')!=saved['role']:
            raise ValueError('本机绑定身份已变化')
        command={'owner': owner, 'principal': {'username': owner, 'role': verified['role']}}
        return executor.principal(command,read_only=True) if read_only else executor.principal(command)

    def _offline_safety_user(self):
        """Read only a previously bound device owner's cached local identity."""
        with self.lock:
            owner=(self.device or {}).get('owner')
            state=self.state
            unavailable=self.executor is not None or self.closed
        if (unavailable or state not in (('offline','error','stopped','held') if self.manual_owned_read_start else ('offline','error','stopped'))
                or not isinstance(owner,str) or not owner):
            raise ValueError('助手尚未恢复安全记录访问')
        try:
            saved=self.vault.read()
        except Exception:
            raise ValueError('本机设备绑定无法核实，安全记录暂不可用') from None
        if (not saved or saved.get('state')!='bound'
                or (saved.get('device') or {}).get('owner')!=owner):
            raise ValueError('本机设备归属无法核实，安全记录暂不可用')
        tenant='cloud-'+hashlib.sha256((self.environment_id+'\n'+self.company_id).encode()).hexdigest()[:24]
        user_id=hashlib.sha256((tenant+'\n'+owner).encode()).hexdigest()
        core=self.server.core
        if not hasattr(core,'lock') or not hasattr(core,'store'):
            raise ValueError('本机账号记录尚不可用')
        with core.lock:
            user=core.store.get('users',user_id)
        if (not user or user.get('tenant_id')!=tenant or user.get('username')!=owner
                or not user.get('cloud_bound') or user.get('disabled')):
            raise ValueError('本机员工归属无法核实，安全记录暂不可用')
        return core._public(user)

    def _safety_user(self, *, read_only=False):
        with self.lock:
            connected=self.executor is not None
            state=self.state
        if connected and state not in ('online','held','offline'):
            raise ValueError('设备状态不可用，安全记录暂不可访问')
        return self._local_user(read_only=read_only) if connected else self._offline_safety_user()

    def workspace_state(self):
        with self.lock:
            connected=self.state in ('online','held','offline') and self.executor is not None
        if not connected:
            try:
                user=self._offline_safety_user()
            except ValueError:
                return {'ready': False, 'accounts': [], 'tasks': [], 'message': '助手尚未在线，完成电脑连接后再读取账号'}
            with self.server.core.lock:
                accounts=[{**{key:account[key] for key in ('id','name','platform','status') if key in account},
                           **account_review_view(self.server.core.store.directory/'accounts'/user['tenant_id']/account['id']/'platform-activity.jsonl')}
                          for account in self.server.core.store.list('accounts',user['tenant_id'])
                          if account.get('platform')=='xiaohongshu'
                          and account.get('cloud_owner')==user['username']]
            return {'ready':False,'accounts':accounts[:100],'tasks':[],
                    'account_count':len(accounts),'task_count':0,
                    'message':'企业连接未恢复，仅可记录已有账号的安全提醒'}
        user = self._local_user()
        result = self.executor({'owner': user['username'], 'principal': {'username': user['username'], 'role': user['role']}, 'action': 'workspace_state', 'data': {}})
        return {'ready': True, **result,'capabilities':self._account_slot_capabilities()}

    def _account_activity_path(self, account_id, *, read_only=False):
        user = self._safety_user(read_only=read_only)
        account = self.server.core._get('accounts', str(account_id or ''), user['tenant_id'])
        self.server.core._account_access(user, account)
        if account.get('platform') != 'xiaohongshu':
            raise ValueError('当前只记录小红书账号安全事件')
        return self.server.core.store.directory / 'accounts' / user['tenant_id'] / account['id'] / 'platform-activity.jsonl'

    def account_safety_status(self, account_id):
        # A safety read must never create, rewrite, or revive its principal.
        return summarize_activity(self._account_activity_path(account_id, read_only=True))

    def record_account_signal(self, account_id, kind, revision=None):
        if kind not in ('phone_verification', 'unexpected_logout', 'review_completed'):
            raise ValueError('不支持此账号安全事件')
        if kind=='review_completed' and (type(revision) is not int or revision<0):
            raise ValueError('请先刷新账号安全记录，再确认人工复核')
        if kind=='review_completed':
            with self.lock:
                if self.state not in ('online','held') or self.executor is None:
                    raise ValueError('请等待企业连接恢复后再确认人工复核')
        path = self._account_activity_path(account_id)
        if kind == 'review_completed':
            # A review must not erase an in-flight request that could still
            # complete or fail after the employee clicks the button.
            channel = 'xiaohongshu:' + str(path.parent.resolve())
            adapters = self.server.core.adapters
            with self.server.job_lock:
                if any(job.get('kind') == 'assistant_account_login'
                       and job.get('account_id') == account_id and job.get('status') == 'running'
                       for job in self.server.jobs.values()):
                    raise ValueError('该账号仍在扫码登录，请等待操作结束后再确认复核')
                with adapters.channel_guard:
                    channel_lock = adapters.channel_locks.setdefault(channel, threading.Lock())
                if not channel_lock.acquire(blocking=False):
                    raise ValueError('该账号仍在执行平台操作，请等待结束后再确认复核')
                try:
                    try:
                        with account_execution_lock(path.parent):
                            record_manual_signal(path, kind, expected_revision=revision)
                    except AdapterBusy:
                        raise ValueError('该账号仍在另一助手进程执行平台操作，请等待结束后再确认复核') from None
                finally:
                    channel_lock.release()
        else:
            with self.server.job_lock:
                recovery_jobs=[job for job in self.server.jobs.values()
                    if job.get('purpose')=='session_recovery' and job.get('account_id')==account_id
                    and not job['worker_done'].is_set()]
            if recovery_jobs:
                from .xhs_session_worker import cancel_session_recovery
                with self.server.core.lock:
                    record_manual_signal(path,kind)
                    for job in recovery_jobs:cancel_session_recovery(self,job)
            else:record_manual_signal(path,kind)
            # The log blocks future requests, but a CLI process may already be
            # waiting on a response. Stop that account immediately and mark
            # its running sequence paused before a later batch can start.
            login_processes=[]
            with self.server.job_lock:
                for job in self.server.jobs.values():
                    if (job.get('kind')=='assistant_account_login'
                            and job.get('account_id')==account_id and job.get('status')=='running'
                            and job.get('purpose')!='session_recovery'):
                        job.update(status='cancelled',error='账号出现安全提醒；扫码已停止，结果待人工核实',
                                   error_code='account_safety_signal')
                        if job.get('process'):login_processes.append(job['process'])
            for process in login_processes:
                if process.poll() is None:
                    try:process.terminate()
                    except OSError:logging.exception('Could not stop account login after safety signal')
            self.server.core.adapters.abort_account(path.parent)
            user=self._safety_user()
            with self.server.core.lock:
                account=self.server.core._get('accounts',account_id,user['tenant_id'])
                active=[task['id'] for task in self.server.core.store.list('tasks',user['tenant_id'])
                        if task.get('account_id')==account_id
                        and (task['id'] in self.server.core.running or task['id'] in self.server.core.sequences)]
            for task_id in active:
                try:self.server.core.handle('cancel_task',{'id':task_id},user)
                except CoreError:logging.exception('Could not mark account task stopped after safety signal')
            self._pause_xhs_identity(account,'check_required','账号出现安全提醒；已请求停止平台操作，请先在手机核实后复核')
        return summarize_activity(path)

    def create_account_slot(self, data):
        """Explicit local record only; the original account save grants no login."""
        from .xhs_app_context import _DeviceSession
        if (not isinstance(data,dict) or set(data)!={'name','platform'}
                or not isinstance(data['name'],str) or not 1<=len(data['name'].strip())<=100
                or any(ord(char)<32 or ord(char)==127 for char in data['name'])
                or data['platform'] not in ('douyin','zhihu','wechat_channels','bilibili','kuaishou','weibo')):
            raise ValueError('请提供已接入平台与1—100字账号名称；此入口仅创建非小红书账号记录')
        core=self.server.core
        with core.lock:
            with self.lock:
                executor=self.executor
                if (self.closed or self.stop_event.is_set() or self.server.closing
                        or self.state not in ('online','held') or type(executor) is not BusinessExecutor):
                    raise ValueError('本机员工连接尚未确认，请先连接当前电脑')
            user=self._local_user(read_only=True)
            session=getattr(executor,'_xhs_app_session',None)
            if type(session) is not _DeviceSession or session.service is not self:
                raise ValueError('当前设备绑定尚未确认，请重新连接当前电脑')
            session.check()
            try:
                created=executor({'owner':user['username'],
                    'principal':{'username':user['username'],'role':user['role']},
                    'action':'account_create','data':{'name':data['name'].strip(),'platform':data['platform']}})
            except (CoreError,ValueError):
                raise
            except Exception:
                logging.exception('Account record creation outcome is unknown')
                return {'purpose':'account_slot_create','status':'outcome_unknown',
                    'error':'账号记录结果未确认，请先刷新账号目录核对，勿自动重试',
                    'account_ready':False,'credentials_verified':False,'platform_requests_started':False,
                    'mutation_committed':None,'auto_retry':False,'refresh_required':True}
        message=('账号记录已创建；哔哩哔哩自动登录尚未接通，凭据需另行按当前受控流程核对。'
                 if created['platform']=='bilibili' else
                 '账号记录已创建；尚未登录或验证凭据，请按该平台当前接入流程另行核对。')
        return {'purpose':'account_slot_create','status':'created','account':created,
                'account_ready':False,'credentials_verified':False,'platform_requests_started':False,
                'mutation_committed':True,'auto_retry':False,'message':message}

    def start_new_account_login(self):
        if self.server.core.remote_safety_hold:
            raise ValueError('企业云端未确认平台操作可用，扫码登录暂缓')
        if xiaohongshu_held(self.server):
            raise ValueError('小红书自动化登录暂缓；第三方 CLI 候选尚未完成验收')
        if self.state!='online':
            raise ValueError('企业服务未确认在线，暂不能扫码登录')
        user = self._local_user()
        name = '登录中的小红书账号'
        # A failed or timed-out scan must not consume another account slot on retry.
        with self.server.core.lock:
            pending = [item for item in self.server.core.store.list('accounts', user['tenant_id'])
                       if item.get('platform') == 'xiaohongshu'
                       and item.get('cloud_owner') == user['username']
                       and item.get('name') == name
                       and item.get('status') in ('logging_in', 'login_required')]
        if pending:
            return self.start_account_login(pending[-1]['id'])
        created = self.executor({'owner': user['username'], 'principal': {'username': user['username'], 'role': user['role']}, 'action': 'account_create', 'data': {'name': name, 'platform': 'xiaohongshu'}})
        try:
            return self.start_account_login(created['id'])
        except Exception:
            # The CLI failed before a job existed; this placeholder has no login data.
            try:
                self.delete_account(created['id'])
            except Exception:
                logging.exception('Could not remove a newly created login placeholder')
            raise

    def delete_account(self, account_id):
        user = self._local_user()
        account_id = str(account_id or '')
        account = self.server.core._get('accounts', account_id, user['tenant_id'])
        self.server.core._account_access(user, account)
        self._cancel_bilibili_setups(account_id=account_id)
        connection_lock = self.server.account_connections.locks.setdefault(account_id, threading.Lock())
        with self.server.job_lock:
            recovery_jobs=[job for job in self.server.jobs.values()
                if job.get('purpose')=='session_recovery' and job.get('account_id')==account_id
                and not job['worker_done'].is_set()]
        from .xhs_session_worker import cancel_session_recovery
        for job in recovery_jobs:cancel_session_recovery(self,job)
        with connection_lock, self.server.job_lock:
            for job in self.server.jobs.values():
                if (job.get('kind') != 'assistant_account_login' or job.get('account_id') != account_id
                        or not (job.get('status') == 'running' or job.get('window_open') is True)
                        or job.get('purpose')=='session_recovery'):
                    continue
                if job.get('mode')=='browser' and job.get('phase')=='cleaning_candidate':
                    continue
                job.update(status='cancelled', error='账号已移除，扫码登录已取消')
                process = job.get('process')
                if process and process.poll() is None:
                    if job.get('mode')=='browser':
                        from .browser_login_service import _cancel_marker
                        _cancel_marker(job)
                        try:process.wait(timeout=3)
                        except subprocess.TimeoutExpired:process.terminate()
                    else:process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill(); process.wait(timeout=3)
            return self.executor({'owner': user['username'], 'principal': {'username': user['username'], 'role': user['role']}, 'action': 'account_delete', 'data': {'account_id': account_id}})

    def start_account_identity_observation(self, account_id):
        if not isinstance(account_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',account_id):
            raise ValueError('账号标识无效')
        from .xhs_identity_worker import start_identity_observation
        value=start_identity_observation(self,account_id)
        return {**value,'purpose':'identity_observation','read_only':True,
                'account_ready':False,'pending_manual_review':False}

    def start_account_login(self, account_id):
        from .xhs_session_policy import XhsSessionRecoveryPolicy
        policy=getattr(self.server,'_xhs_session_policy',None)
        if type(policy) is XhsSessionRecoveryPolicy and policy.describe()['status']!='unsupported':
            from .xhs_session_worker import start_session_recovery
            return start_session_recovery(self,account_id)
        if getattr(self.server,'browser_login_enabled',False):
            from .browser_login_service import start_browser_account_login
            return start_browser_account_login(self,account_id,self.server.browser_login_helper_path)
        if self.server.core.remote_safety_hold:
            raise ValueError('企业云端未确认平台操作可用，扫码登录暂缓')
        if xiaohongshu_held(self.server):
            raise ValueError('小红书自动化登录暂缓；第三方 CLI 候选尚未完成验收')
        if self.state!='online':
            raise ValueError('企业服务未确认在线，暂不能扫码登录')
        user = self._local_user()
        account = self.server.core._get('accounts', str(account_id or ''), user['tenant_id'])
        if account.get('platform') != 'xiaohongshu':
            raise ValueError('当前助手登录入口只支持小红书账号')
        with self.server.job_lock:
            for pending in self.server.jobs.values():
                if pending.get('kind') == 'assistant_account_login' and pending.get('account_id') == account['id'] and pending.get('status') == 'running':
                    return {'login_job': pending['id'], 'account': {k: account.get(k) for k in ('id','name','platform','status')}}
            account_dir = self.server.core.store.directory / 'accounts' / user['tenant_id'] / account['id']
            channel = 'xiaohongshu:' + str(account_dir.resolve())
            adapters = self.server.core.adapters
            with adapters.channel_guard:
                channel_lock = adapters.channel_locks.setdefault(channel, threading.Lock())
            if not channel_lock.acquire(blocking=False):
                raise ValueError('该账号仍在采集、发送或检查状态，请等待操作结束后再扫码')
            try:
                spec = self.server.core.handle('account_login_spec', {'id': account['id']}, user)
                job_id = secrets.token_hex(12)
                qr_dir = self.server.core.store.directory / 'work'
                qr_dir.mkdir(exist_ok=True)
                qr_path = qr_dir / (job_id + '.png')
                job = {'id': job_id, 'kind': 'assistant_account_login', 'account_id': account['id'],
                       'status': 'running', 'phase': 'starting_process', 'qr_path': str(qr_path)}
                self.server.jobs[job_id] = job
            except Exception:
                channel_lock.release()
                raise
        def login_run_locked():
            proc = None
            login_stdout = b''
            login_started_at = None
            channel_reserved = True
            outcome_recorded = False
            try:
                with self.server.job_lock:
                    if job['status'] == 'cancelled':
                        return
                    if self.state!='online' or xiaohongshu_held(self.server):
                        raise AccountLoginError('cloud_safety_hold','企业云端未确认平台操作可用，扫码登录已停止')
                    if self.server.closing:
                        raise ValueError('软件正在退出')
                    if not self.server.core.store.get('accounts', account['id']):
                        raise ValueError('账号已移除，扫码登录已取消')
                    self.server.core.adapters._guard_platform('xiaohongshu')
                    login_started_at = time.time()
                    proc = subprocess.Popen(spec['argv'], env={**os.environ, **spec['env'], 'WORKSPACE_QR_PATH': str(qr_path)}, cwd=spec['cwd'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                    job['process'] = proc
                    job['phase'] = 'waiting_for_scan'
                try:
                    login_stdout, _ = proc.communicate(timeout=max(45,min(300,int(spec.get('timeout',255)))))
                except subprocess.TimeoutExpired:
                    proc.kill(); proc.communicate()
                    raise AccountLoginError('scan_timeout', '扫码或手机验证超时，登录已停止；请检查手机提示，暂勿连续重试')
                if proc.returncode:
                    if qr_path.with_suffix('.error.json').is_file():
                        raise AccountLoginError('qr_generation_failed', '二维码生成失败，请检查本机数据目录权限')
                    failure = classify_login_failure(login_stdout,
                        activity_path=(spec.get('env') or {}).get('WORKSPACE_ACTIVITY_LOG'),
                        started_at=login_started_at)
                    if failure['code'] != 'cli_exit_nonzero' or failure['http_status'] is not None:
                        raise AccountLoginError(failure['code'], failure['message'])
                    raise AccountLoginError('cli_exit_nonzero', '电脑端登录未完成（退出码 %s），失败原因尚未确认；请先查看账号记录' % proc.returncode)
                job['phase'] = 'verifying_identity'
                Adapters._record_cli_outcome(spec, ['login'], 'completed', proc.returncode)
                outcome_recorded = True
                channel_lock.release()
                channel_reserved = False
                connection_lock = self.server.account_connections.locks.setdefault(account['id'], threading.Lock())
                with connection_lock:
                    if job['status'] == 'cancelled':
                        return
                    result = self.server.core.handle('account_check', {'id': account['id']}, user)
                    if result.get('verified') is not True:
                        if result.get('account', {}).get('status') == 'identity_mismatch':
                            raise AccountLoginError('identity_mismatch', '扫码登录的是另一个小红书账号；此账号记录及其任务已暂停。请用原账号重新扫码，或为新账号另建记录')
                        if result.get('account', {}).get('status') == 'duplicate_identity':
                            raise AccountLoginError('duplicate_identity', '同一小红书账号已有另一条本机记录；相关任务已暂停，请管理员清理重复记录后重新核对')
                        raise AccountLoginError('identity_unverified', '扫码流程结束，但本机尚未验证账号身份；请检查手机提示，暂勿连续重试')
                    try:
                        self._claim_xhs_account(result['account'])
                    except CoreError as error:
                        current = self.server.core.store.get('accounts', account['id'])
                        code = 'remote_identity_conflict' if current and current.get('status') == 'duplicate_identity_remote' else 'cloud_identity_unavailable'
                        raise AccountLoginError(code, str(error)) from None
                    job.update(status='completed', phase='completed')
            except Exception as ex:
                if job['status'] == 'cancelled':
                    return
                current = self.server.core.store.get('accounts', account['id'])
                if current and current.get('status') == 'logging_in':
                    current['status'] = 'login_required'; self.server.core.store.put('accounts', current)
                code = ex.code if isinstance(ex, AccountLoginError) else (
                    'process_start_failed' if job['phase'] == 'starting_process' else
                    'identity_check_failed' if job['phase'] == 'verifying_identity' else 'login_unexpected')
                logging.error('Assistant login failed: phase=%s code=%s error_type=%s',
                              job['phase'], code, type(ex).__name__)
                job.update(status='failed', error=str(ex) if isinstance(ex, AccountLoginError)
                           else '本地登录流程出错；请记录错误码并联系管理员核查', error_code=code)
            finally:
                try:
                    if not outcome_recorded or job.get('status') != 'completed':
                        Adapters._record_cli_outcome(
                            spec, ['login'],
                            'completed' if job.get('status') == 'completed' else
                            'timeout' if job.get('error_code') == 'scan_timeout' else
                            job['error_code'] if job.get('status') == 'failed' and job.get('error_code') in {
                                'verification_required','ip_blocked','not_authenticated','signature_error',
                                'api_error','unsupported_operation','protocol_error','transport_error'} else
                            'process_failed' if job.get('status') == 'failed' else 'cancelled',
                            proc.returncode if proc else None)
                except OSError:
                    logging.exception('Could not record assistant login outcome')
                finally:
                    if channel_reserved:
                        channel_lock.release()
                job.pop('process', None)
                for path in (qr_path, qr_path.with_suffix('.error.json')):
                    try:
                        path.unlink(missing_ok=True)
                    except OSError:
                        logging.exception('Could not remove finished assistant login QR artifact')
        def login_run():
            entered=False
            try:
                with account_execution_lock(account_dir):
                    entered=True
                    login_run_locked()
            except (AdapterBusy,OSError) as error:
                if entered:
                    logging.error('Assistant account lock release failed: error_type=%s',type(error).__name__)
                    return
                if job['status'] != 'cancelled':
                    busy=isinstance(error,AdapterBusy)
                    job.update(status='failed', phase='account_busy' if busy else 'account_lock_unavailable',
                               error_code='account_busy' if busy else 'account_lock_unavailable',
                               error='该账号正在另一助手进程执行操作；本次未启动扫码' if busy else
                               '账号目录暂时无法加锁；本次未启动扫码，请检查本机数据目录')
                    current=self.server.core.store.get('accounts',account['id'])
                    if current and current.get('status')=='logging_in':
                        current['status']='login_required';self.server.core.store.put('accounts',current)
                channel_lock.release()
        try:
            threading.Thread(target=login_run, name='assistant-account-login', daemon=True).start()
        except Exception:
            channel_lock.release()
            with self.server.job_lock:
                self.server.jobs.pop(job_id, None)
            current = self.server.core.store.get('accounts', account['id'])
            if current and current.get('status') == 'logging_in':
                current['status'] = 'login_required'; self.server.core.store.put('accounts', current)
            raise
        return {'login_job': job_id, 'account': {k: account.get(k) for k in ('id','name','platform','status')}}

    def account_job_status(self, job_id):
        job = self.server.jobs.get(str(job_id or ''))
        if not job or job.get('kind') != 'assistant_account_login':
            raise ValueError('登录任务不存在')
        if job.get('purpose')=='identity_observation':
            return self._identity_observation_job_status(job)
        if job.get('purpose')=='session_recovery':
            user=self._local_user(read_only=True)
            with self.server.core.lock:
                account=self.server.core._get('accounts',job.get('account_id'),user['tenant_id'])
                self.server.core._account_access(user,account)
            from .xhs_session_worker import session_recovery_status
            return session_recovery_status(self,user,account,job)
        status = job['status']
        qr_ready = False
        if status == 'running' and job.get('qr_path'):
            try:
                qr_ready = Path(job['qr_path']).stat().st_size > 32
            except OSError:
                # The worker may remove the QR between two status polls.
                pass
        phase = 'qr_ready' if status == 'running' and qr_ready and job.get('phase') == 'waiting_for_scan' else job.get('phase', 'unknown')
        return {'status': status, 'phase': phase, 'error_code': job.get('error_code', ''),
                'error': job.get('error', ''), 'qr_ready': qr_ready,
                'mode': 'browser' if job.get('mode')=='browser' else 'qr',
                'window_open': job.get('window_open') is True,
                'persistent_browser': job.get('persistent_browser') is True,
                'cleanup_code': job.get('cleanup_code','')}

    def _identity_observation_job_status(self, job):
        from .xhs_identity_worker import identity_observation_status
        user=self._local_user(read_only=True)
        with self.server.core.lock:
            account=self.server.core._get('accounts',job.get('account_id'),user['tenant_id'])
            self.server.core._account_access(user,account)
        value=identity_observation_status(self,user,account,job=job)
        states={'unknown','in_progress','pending_manual_review','needs_login',
                'verification_required','cancelled','failed'}
        state=value.get('observation_state')
        if state not in states:state='unknown'
        with self.server.job_lock:
            if self.server.jobs.get(job.get('id')) is not job:
                raise ValueError('身份核对任务不存在')
            done=job.get('worker_done')
            completed=isinstance(done,threading.Event) and done.is_set()
            status=job.get('status')
            status=status if status in {'running','completed','failed','cancelled'} else 'failed'
            if not completed or state=='in_progress':
                # The getter may have observed pending cleanup just before
                # worker_done changed. Keep polling for the next exact view.
                state='in_progress'
                status='running'
        identity=None
        stamp=None
        if completed and status=='completed' and state=='pending_manual_review':
            raw=value.get('observed_identity')
            if (type(raw) is dict and set(raw)=={'id','nickname','guest'}
                    and raw.get('guest') is False and isinstance(raw.get('id'),str)
                    and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',raw['id'])
                    and isinstance(raw.get('nickname'),str) and len(raw['nickname'])<=160):
                identity={key:raw[key] for key in ('id','nickname','guest')}
                raw_stamp=value.get('observed_at')
                if type(raw_stamp) in (int,float) and 0<raw_stamp<253402300800:
                    stamp=raw_stamp
            if identity is None or stamp is None:
                state='unknown'
                identity=None
                stamp=None
        messages={
            'unknown':'尚未取得可展示的身份核对结果，原账号状态保持不变',
            'in_progress':'正在只读核对页面身份，原资源收尾后显示结果',
            'pending_manual_review':'页面身份已读取，仍待人工核对；账号尚未确认就绪',
            'needs_login':'页面没有可核对的已登录身份，请按原登录流程处理',
            'verification_required':'平台要求电脑端验证，本次身份观测已结束',
            'cancelled':'身份观测已取消，原账号与风险记录保持不变',
            'failed':'身份观测未完成，原账号与风险记录保持不变',
        }
        return {'login_job':job['id'],'mode':'browser','purpose':'identity_observation',
                'status':status,'phase':state,'observation_state':state,
                'pending_manual_review':state=='pending_manual_review',
                'observed_identity':identity,'observed_at':stamp,
                'account_ready':False,'read_only':True,'message':messages[state],
                'error_code':state if state in {'needs_login','verification_required','cancelled','failed'} else '',
                'error':messages[state] if status=='failed' else '',
                'qr_ready':False,'cleanup_code':'physical_cleanup_pending' if not completed else ''}

    def cancel_account_login(self, job_id):
        from .browser_login_service import cancel_browser_job
        user=self._local_user()
        job=self.server.jobs.get(str(job_id or ''))
        if not job or job.get('kind')!='assistant_account_login' or job.get('mode')!='browser':
            raise ValueError('浏览器登录任务不存在')
        connection_lock=self.server.account_connections.locks.setdefault(job.get('account_id'),threading.Lock())
        if job.get('purpose')=='session_recovery':
            from .xhs_session_worker import cancel_session_recovery
            # Do not wait behind Coordinator's connection lock/cloud call:
            # this fresh original actor can signal cancellation before commit.
            with self.server.core.lock:
                account=self.server.core.store.get('accounts',job.get('account_id'))
                if job.get('owner_id')!=user['id'] or job.get('tenant_id')!=user['tenant_id']:
                    raise ValueError('无权取消该账号登录')
                if account:self.server.core._account_access(user,account)
            result=cancel_session_recovery(self,job)
            done=job['worker_done'].is_set()
            if done:
                from .xhs_session_worker import session_recovery_status
                return {**session_recovery_status(self,user,account,job),
                    'code':'already_finished','cancel_requested':False}
            return {'status':'running','mode':'browser',
                'purpose':'session_recovery','code':'already_finished' if done else 'cancel_requested',
                'cancel_requested':result=='requested','cleanup_confirmed':done,
                'session_committed':False}
        if job.get('purpose')=='identity_observation':
            from .xhs_identity_worker import cancel_identity_observation
            # Never take job_lock before the original Core/runtime short
            # locks: cancellation and Native Resume/publish share that order.
            with connection_lock:
                with self.server.core.lock:
                    account=self.server.core.store.get('accounts',job.get('account_id'))
                    if (job.get('owner_id')!=user.get('id') or job.get('tenant_id')!=user.get('tenant_id')):
                        raise ValueError('无权取消该账号身份核对')
                    if account:
                        self.server.core._account_access(user,account)
                result=cancel_identity_observation(self,job)
                return {'status':'cancelled' if result=='requested' else job.get('status'),
                        'mode':'browser','purpose':'identity_observation',
                        'account_ready':False,'read_only':True,
                        'code':'cancelled' if result=='requested' else 'already_finished'}
        with connection_lock,self.server.job_lock:
            job=self.server.jobs.get(str(job_id or ''))
            if not job or job.get('kind')!='assistant_account_login' or job.get('mode')!='browser':
                raise ValueError('浏览器登录任务不存在')
            account=self.server.core.store.get('accounts',job.get('account_id'))
            if account:
                if account.get('tenant_id')!=user.get('tenant_id'):
                    raise ValueError('无权取消该账号登录')
                self.server.core._account_access(user,account)
            elif job.get('owner_id')!=user.get('id'):
                raise ValueError('无权取消该账号登录')
            if (job.get('status')=='running' or job.get('window_open') is True) and job.get('phase')!='cleaning_candidate':
                cancel_browser_job(self,job)
            return {'status':'cancelled' if job.get('status')=='cancelled' else job.get('status'),
                    'mode':'browser','code':'cancelled' if job.get('status')=='cancelled' else
                    'completion_pending' if job.get('phase')=='cleaning_candidate' else 'already_finished'}

    def stop(self, timeout=30):
        helper=getattr(self,'_douyin_connection_service',None)
        if helper is not None:helper.close()
        with self.lock:self._bilibili_setup_stopping=True
        self._cancel_bilibili_setups(permanent=True)
        from .browser_login_service import cancel_browser_job
        with self.server.job_lock:
            browser_jobs=[job for job in self.server.jobs.values()
                          if job.get('kind')=='assistant_account_login' and job.get('mode')=='browser'
                          and (job.get('status')=='running' or job.get('window_open') is True) and (job.get('purpose') in ('identity_observation','session_recovery')
                              or job.get('phase')!='cleaning_candidate')]
        for job in browser_jobs:
            if job.get('purpose')=='session_recovery':
                from .xhs_session_worker import cancel_session_recovery
                cancel_session_recovery(self,job)
                continue
            connection_lock=self.server.account_connections.locks.setdefault(job['account_id'],threading.Lock())
            with connection_lock:
                if job.get('status')=='running' or job.get('window_open') is True:
                    if job.get('purpose')=='identity_observation':
                        from .xhs_identity_worker import cancel_identity_observation
                        cancel_identity_observation(self,job)
                    else:cancel_browser_job(self,job)
        if getattr(self,'ai_worker',None):self.ai_worker.close()
        with self.lock:
            self.closed = True
            self.stop_event.set()
            executor, thread = self.executor, self.thread
        if executor:
            executor.stop_owned_tasks()
        if thread and thread is not threading.current_thread():
            thread.join(timeout)
        return not (thread and thread.is_alive())


