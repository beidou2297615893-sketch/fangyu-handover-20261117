import './canvas-fit.mjs';
import {createBackend} from './backend.mjs';
import * as acquire from './pages/acquire.mjs';
import * as presets from './pages/presets.mjs';
import * as reply from './pages/reply.mjs';
import * as customers from './pages/customers.mjs';
import * as platformAccounts from './pages/accounts.mjs';
import * as rules from './pages/management-rules.mjs';
import * as tone from './pages/management-tone.mjs';
import {customerControls,customerQuery,actorMatches as customerActorMatches} from './pages/customers-data.mjs';
import {openToneTools,openSettings,localDates,versionLabel} from './pages/management-tools.mjs';
import {createPaneScroll} from './pane-scroll.mjs';
const app=document.getElementById('app');
const initialPage=location.hash.slice(1)||'login';
const backend=createBackend();
const state={page:'login',store:'',user:'',scenario:'normal',connection:'loading',session:null,stores:[],catalog:{search:[],intent:[]},selection:null,capabilities:{presets:false},rememberedUsername:'',busy:false,platform:null,platformLoading:false,platformError:'',platformActionsReady:true};
const paneScroll=createPaneScroll(app,()=>state);
const pages={acquire,presets,reply,customers,rules,tone,accounts:platformAccounts};
const titles={acquire:['获客截流','发现真实租房需求'],reply:['意向回复','从社交平台，看见真实的租房需求'],customers:['客户工作台','每条线索都有来源，每次交接都有回执。'],presets:['门店获客预设','确认门店资料，配套搜索与客户判断规则'],rules:['获客规则',''],tone:['IP与口吻',''],accounts:['平台与账号','软件自动准备，你只需登录平台账号']};
let cleanup,toastTimer,lastFocus;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(file,cls='')=>`<img class="icon ${cls}" src="/assets/${file}" alt="">`;
function navigate(page){if(!titles[page]&&page!=='login')page='acquire';if(state.connection!=='preview'&&!state.session)page='login';state.page=page;if(location.hash!=='#'+page)history.replaceState(null,'','#'+page);render();window.scrollTo({top:0,behavior:'instant'});}
function toast(text){clearTimeout(toastTimer);const n=document.getElementById('toast');n.textContent=text;n.hidden=false;toastTimer=setTimeout(()=>n.hidden=true,3500);}
function update(mutator){const focused=document.activeElement;const key=focused?.id;const attr=['data-customer-sort','data-customer-filter','data-customer-filter-value','data-customer-page','data-customer-row','data-customer-check','data-customer-check-all','data-customer-action','data-customer-export','data-customer-evidence','data-customer-source'].find(name=>focused?.hasAttribute?.(name));const selector=key?'#'+CSS.escape(key):attr?`[${attr}="${CSS.escape(focused.getAttribute(attr))}"]`:'';const start=focused?.selectionStart;const end=focused?.selectionEnd;mutator(state);if(render()===false)return;if(selector){const n=document.querySelector(selector);if(n){n.focus({preventScroll:true});if(typeof start==='number'&&n.setSelectionRange){try{n.setSelectionRange(start,end);}catch{}}}}}
function modal({title,html,onConfirm,confirmLabel='确定',canClose}){
  const d=document.getElementById('modal'),owner={};d.__modalOwner=owner;if(!d.open)lastFocus=document.activeElement;const restoreFocus=lastFocus;
  const current=()=>d.__modalOwner===owner;
  const close=()=>{if(current()&&canClose?.()!==false)d.close();};
  d.innerHTML=`<div class="modal-header"><h2 id="modal-title">${esc(title)}</h2><button class="modal-close" aria-label="关闭">${icon('tabler-x.svg')}</button></div><div class="modal-content">${html}</div><div class="modal-actions"><button class="modal-cancel">${onConfirm?'取消':'关闭'}</button>${onConfirm?`<button class="primary modal-confirm">${esc(confirmLabel)}</button>`:''}</div>`;
  d.querySelector('.modal-close').onclick=close;d.querySelector('.modal-cancel').onclick=close;
  if(onConfirm)d.querySelector('.modal-confirm').onclick=async()=>{if(!current())return;const result=await onConfirm();if(result!==false)close();};
  if(!d.open)d.showModal();
  d.oncancel=e=>{if(!current()||canClose?.()===false)e.preventDefault();};
  d.onclose=()=>current()&&restoreFocus?.isConnected&&restoreFocus.focus();
  d.onclick=e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)close();}};return d;
}
const viewModel=state;
let runtimeMetadataGeneration=0;
function updateRuntimeLabels(){
  const dates=localDates();document.querySelectorAll('[data-local-date]').forEach(node=>{node.textContent=dates[node.dataset.localDate]||dates.iso;});
  document.querySelectorAll('[data-runtime-version]').forEach(node=>{node.textContent=versionLabel(state);node.title=state.runtimeMetadata?.value?.release||state.runtimeMetadata?.error||'';});
}
async function refreshRuntimeStatus(){
  if(state.connection==='preview')return false;const generation=++runtimeMetadataGeneration;
  state.runtimeMetadata={status:'loading'};
  try{const value=await backend.runtimeStatus();if(generation!==runtimeMetadataGeneration)return false;state.runtimeMetadata={status:'ready',value};return true;}
  catch(error){if(generation===runtimeMetadataGeneration)state.runtimeMetadata={status:'error',error:error.message};return false;}
  finally{if(generation===runtimeMetadataGeneration)updateRuntimeLabels();}
}
function acceptBootstrap(result){
  const previousActor=state.user+'|'+(state.storeId||'');
  state.connection='connected';state.session=result.session||null;state.user=result.session?.user?.username||'';
  state.rememberedUsername=result.rememberedUsername||'';state.stores=Array.isArray(result.stores)?result.stores:[];
  state.workspaceError=result.workspaceError||null;
  state.catalog={search:Array.isArray(result.catalog?.search)?result.catalog.search:[],intent:Array.isArray(result.catalog?.intent)?result.catalog.intent:[]};state.selection=result.selection||null;state.materials=result.materials||null;state.assessmentReport=result.assessment||null;state.capabilities=result.capabilities||{presets:false};state.notice=result.notice||'';
  const store=state.stores.find(item=>item.id===state.selection?.storeId);
  state.storeId=store?.id||'';state.store=store?.name||'';
  const old=state.presets;state.presets={search:state.selection?.searchPresetId||state.catalog.search[0]?.id||'',intent:state.selection?.intentPresetId||state.catalog.intent[0]?.id||'',tab:old?.tab||'presets',showWords:old?.showWords||false,showRules:old?.showRules||false,materialKey:state.materials?.currentSelection?.materialKey||'',keywordIds:[...(state.materials?.currentSelection?.selectedKeywordIds||[])]};
  if(state.acquire&&store)state.acquire.region=store.region;
  if(previousActor!==state.user+'|'+state.storeId){state.platform=null;state.platformError='';state.platformAccountSelections={};state.acquisitionAttempt=null;state.customerView=null;state.customerDetail=null;state.customerSelectionFilter='';state.replyLive=null;state.replyDelivery=null;state.replyBatchIds=null;state.customerHandoff=null;state.toneTool=null;state.tonePreferences=null;state.tonePreferencesError='';state.tonePreferencesLoading=false;state.toneDraft=null;toneReadGeneration++;toneScopeGeneration++;state.tonePreferenceReadActor='' ;state.settingsTool=null;state.workspaceRefreshError='';document.getElementById('modal')?.close();}
}
function showActionError(error){if(['AUTH_REQUIRED','unauthenticated','session_expired'].includes(error?.code)){state.customerHandoff=null;state.toneTool=null;state.tonePreferences=null;state.tonePreferencesError='';state.tonePreferencesLoading=false;state.toneDraft=null;toneReadGeneration++;toneScopeGeneration++;state.tonePreferenceReadActor='' ;state.settingsTool=null;state.workspaceRefreshError='';document.getElementById('modal')?.close();state.session=null;state.user='';state.stores=[];state.store='';state.storeId='';state.capabilities={presets:false};navigate('login');}toast(error?.message||'操作未完成，请稍后重试。');}
async function reloadWorkspace(){
  if(state.busy)return false;const expected=actorKey(),attempt={};state.workspaceRefreshAttempt=attempt;state.busy=true;render();
  try{const result=await backend.bootstrap();if(expected!==actorKey())return false;acceptBootstrap(result);state.workspaceRefreshError='';if(!state.session)navigate('login');toast(state.notice||'门店资料已重新加载。');return true;}
  catch(error){if(expected===actorKey()){state.workspaceRefreshError=error.message;showActionError(error);}return false;}
  finally{if(state.workspaceRefreshAttempt===attempt){state.workspaceRefreshAttempt=null;state.busy=false;render();}}
}
function finishApplied(){
  const store=state.stores.find(item=>item.id===state.storeId),search=state.catalog.search.find(item=>item.id===state.presets.search),intent=state.catalog.intent.find(item=>item.id===state.presets.intent);
  state.acquire??={region:store?.region||'',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  if(['running','paused'].includes(state.acquire.status)){state.acquire.records.unshift({text:'已应用门店预设，本次采集演示结束',status:'已停止'});Object.assign(state.acquire,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null});}
  Object.assign(state.acquire,{region:store?.region||'',searchPreset:search?.name||'',intentPreset:intent?.name||''});state.customerView=null;state.customerDetail=null;navigate('acquire');toast(state.assessmentReport?.status==='retry_required'?'门店预设已应用；客户重新评估待重试，可在判断规则中重新评估。':'中央配置已加载；选词和显示偏好已保存在本机，点击开始后才会采集');
}
async function verifyPending(){
  let pending=state.pendingAction;
  acceptBootstrap(await backend.bootstrap());
  if(pending?.platformOperation){
    if(state.session&&(state.user!==pending.username||state.storeId!==pending.storeId)){state.pendingAction=null;state.platform=null;toast('账号或门店已变化，请在原账号与门店核对上次操作。');if(state.user!==pending.username)navigate('login');return;}
    if(!state.session){state.pendingAction=null;navigate('login');return;}
    const actor=actorKey(),result=await backend.platform();if(actor!==actorKey())return;
    if(!result.platform)throw new Error('真实平台状态尚未确认。');
    if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return;}
    acceptPlatformSnapshot(result.platform);state.platformError='';
    if(pending.action==='acquisition_start'&&state.pendingAction?.action==='acquisition_start')pending=state.pendingAction;
    if(pending.action==='acquisition_start'){
      const last=result.platform.lastRequest;
      if(last?.requestId!==pending.requestId||!['accepted','rejected'].includes(last.state)){pending.unconfirmed=true;state.pendingAction=pending;if(state.acquisitionAttempt)state.acquisitionAttempt.unconfirmed=true;toast(last?.requestId===pending.requestId&&last.message?last.message:'上次采集结果尚未确认，请继续核对；原操作编号和条件已保留。');return;}
      state.pendingAction=null;state.acquisitionAttempt=null;toast(last.state==='accepted'?'已核对上次采集已受理，当前进度以真实回执为准。':'已核对上次采集未受理：'+(last.message||'请确认条件后再开始。'));return;
    }
    state.pendingAction=null;toast('已核对当前真实状态，请确认后继续；未重复提交操作。');return;
  }
  state.pendingAction=null;
  if(pending?.action!=='login'&&pending?.username&&state.session&&state.user!==pending.username){state.loginError='账号状态已变化，请重新登录后核对门店预设。';navigate('login');return;}
  if(pending?.action==='login'){
    if(state.session?.user?.username===pending.username){state.loginDraft=undefined;state.loginError='';navigate('acquire');toast('已核对登录成功');}
    else{state.loginError=state.session?'已核对：当前仍为账号 '+state.user+'，本次登录尚未确认，请重新登录。':'已核对：尚未登录，请重新输入密码后尝试。';navigate('login');}
  }else if(pending?.action==='apply_preset'){
    const saved=state.selection,choice=pending.choice;
    if(saved?.storeId===choice.storeId&&saved.searchPresetId===choice.searchPresetId&&saved.intentPresetId===choice.intentPresetId&&saved.revision>choice.expectedRevision)finishApplied();
    else{if(!state.session)navigate('login');toast('已载入当前预设，请确认选择后再应用。');}
  }else if(pending?.action==='logout'){
    if(!state.session){state.loginDraft=undefined;navigate('login');toast('已核对退出登录');}
    else toast('已核对：账号仍在登录，可重新退出。');
  }else{if(!state.session)navigate('login');toast('已载入当前门店与预设，请确认后继续。');}
}
async function recoverAction(error){
  if(error?.code==='RESULT_UNCONFIRMED'){
    if(state.pendingAction)state.pendingAction.unconfirmed=true;
    toast('操作结果尚未确认，正在核对，请稍候…');
    try{await verifyPending();}catch(failure){if(failure.code==='AUTH_REQUIRED')showActionError(failure);state.loginError='上次操作结果尚未确认，请点击登录按钮先核对状态。';toast('暂时无法核对；再次操作时会先核对状态，不会重复提交。');}
  }else if(error?.code==='PRESET_REVISION_CONFLICT'){
    state.pendingAction=null;
    try{acceptBootstrap(await backend.bootstrap());toast('预设已在其他窗口变更，已载入最新内容，请重新选择后应用。');}catch(failure){showActionError(failure);}
  }else{state.pendingAction=null;showActionError(error);}
}
async function selectStore(storeId){
  if(state.busy)return;state.busy=true;render();
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return;}state.pendingAction={action:'select_store',username:state.user};acceptBootstrap(await backend.selectStore(storeId));state.pendingAction=null;}
  catch(error){await recoverAction(error);}
  finally{state.busy=false;render();}
}
async function applyPreset(){
  if(state.busy||!state.capabilities.presets)return;
  const choice={storeId:state.storeId,searchPresetId:state.presets.search,intentPresetId:state.presets.intent,expectedRevision:state.selection?.revision};
  if(state.presets.materialKey){Object.assign(choice,{materialKey:state.presets.materialKey,keywordIds:[...(state.presets.keywordIds||[])],expectedMaterialRevision:state.materials?.currentSelection?.revision||0,expectedCatalogDigest:state.materials?.digest,confirmMaterialBinding:true});}
  state.busy=true;render();
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return;}state.pendingAction={action:'apply_preset',choice,username:state.user};acceptBootstrap(await backend.applyPreset(choice));state.pendingAction=null;finishApplied();}
  catch(error){await recoverAction(error);}
  finally{state.busy=false;render();}
}
async function refreshAssessments(){
  if(state.busy||!state.session||!state.selection?.applied?.rentalAssessmentEnabled)return;
  state.busy=true;render();
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return;}const actor=actorKey();state.pendingAction={action:'refresh_assessments',username:state.user};const result=await backend.refreshAssessments({storeId:state.storeId,expectedRevision:state.selection.revision});if(actor!==actorKey())return;acceptBootstrap(result);state.pendingAction=null;state.customerView=null;state.customerDetail=null;toast('现有客户已按当前租房与预算规则重新评估；原评级保留在历史中。');}
  catch(error){await recoverAction(error);}
  finally{state.busy=false;render();}
}
async function logout(){
  if(state.busy)return false;state.busy=true;
  try{if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return !state.session;}state.pendingAction={action:'logout',username:state.user};acceptBootstrap(await backend.logout());state.pendingAction=null;state.loginDraft=undefined;state.acquire=undefined;state.reply=undefined;state.customers=undefined;navigate('login');if(state.notice)toast(state.notice);return true;}
  catch(error){await recoverAction(error);return !state.session;}
  finally{state.busy=false;render();}
}
let platformTimer,platformScope='',platformGeneration=0,platformFlight,manualPlatformGeneration=0;
const actorKey=()=>JSON.stringify([state.user,state.storeId||'']);
function acceptPlatformSnapshot(platform){
  state.platform=platform;const last=platform?.lastRequest;
  if(!last?.requestId||!['submitted','unconfirmed'].includes(last.state))return;
  if(state.acquisitionAttempt?.payload?.requestId!==last.requestId){
    const conditions=last.conditions&&typeof last.conditions==='object'?last.conditions:{};
    state.acquisitionAttempt={actor:actorKey(),payload:{...conditions,requestId:last.requestId},unconfirmed:true,recovered:true};
    state.acquire??={};state.acquire.region=typeof conditions.region==='string'?conditions.region:'';state.acquire.time=typeof conditions.time==='string'?conditions.time:'';state.acquire.selectedPlatform=conditions.platform||'';
    if(conditions.platform&&conditions.accountId){state.platformAccountSelections??={};state.platformAccountSelections[conditions.platform]=conditions.accountId;}
  }else state.acquisitionAttempt.unconfirmed=true;
  state.pendingAction={action:'acquisition_start',platformOperation:true,username:state.user,storeId:state.storeId,requestId:last.requestId,unconfirmed:true};
}
function platformActorMatches(platform,expected=actorKey()){return Boolean(platform?.actor&&JSON.stringify([platform.actor.username,platform.actor.storeId||''])===expected);}
async function reconcilePlatformActor(expected){
  if(actorKey()!==expected)return;
  state.platform=null;state.platformError='账号或门店状态已变化，正在重新核对身份。';document.getElementById('modal')?.close();
  try{const boot=await backend.bootstrap();if(actorKey()!==expected)return;acceptBootstrap(boot);state.pendingAction=null;navigate(state.session?state.page:'login');toast('账号或门店状态已变化，请确认当前身份后继续。');}
  catch(error){if(actorKey()===expected){state.platformError=error.message;showActionError(error);}}
}
function pollingScope(){return state.connection==='connected'&&state.session&&['accounts','acquire'].includes(state.page)&&document.visibilityState!=='hidden'?actorKey()+'|'+state.page:'';}
async function refreshPlatform({manual=false}={}){
  if(manual){
    if(state.connection!=='connected'||!state.session)return null;
    const expected=actorKey(),attempt=++manualPlatformGeneration,generation=platformGeneration;
    const current=()=>expected===actorKey()&&attempt===manualPlatformGeneration&&generation===platformGeneration;
    state.platformLoading=true;
    try{const result=await backend.platform();if(!current())return null;if(!result?.platform)throw new Error('平台状态返回不完整，请稍后核对。');if(!platformActorMatches(result.platform,expected)){await reconcilePlatformActor(expected);return null;}acceptPlatformSnapshot(result.platform);state.platformError='';state.platformUpdatedAt=Date.now();return result.platform;}
    catch(error){if(current()){state.platformError=error.message;if(error.code==='AUTH_REQUIRED')showActionError(error);}return null;}
    finally{if(current()){state.platformLoading=false;render();}}
  }
  const scope=pollingScope();if(!scope)return null;
  if(platformFlight?.scope===scope)return platformFlight.promise;
  const generation=platformGeneration,actor=actorKey();
  state.platformLoading=true;if(!state.platform)render();
  const promise=(async()=>{
    try{
      const result=await backend.platform();
      if(generation!==platformGeneration||scope!==pollingScope())return null;
      if(!result?.platform||typeof result.platform!=='object')throw new Error('平台状态返回不完整，请稍后核对。');
      if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return null;}
      acceptPlatformSnapshot(result.platform);state.platformError='';state.platformUpdatedAt=Date.now();return result.platform;
    }catch(error){
      if(generation!==platformGeneration||scope!==pollingScope())return null;
      state.platformError=error.message||'平台状态暂未更新。';
      if(error.code==='AUTH_REQUIRED')showActionError(error);
      return null;
    }finally{
      if(platformFlight?.promise===promise)platformFlight=null;
      if(generation===platformGeneration&&scope===pollingScope()){
        state.platformLoading=false;if(!document.activeElement?.matches('#page-content select,#page-content input'))render();clearTimeout(platformTimer);
        platformTimer=setTimeout(()=>refreshPlatform(),state.platformError?7000:3500);
      }
    }
  })();
  platformFlight={scope,promise};return promise;
}
function syncPlatformPolling(){
  const scope=pollingScope();if(scope===platformScope)return;
  clearTimeout(platformTimer);platformScope=scope;platformGeneration++;state.platformLoading=false;
  if(scope)queueMicrotask(()=>{if(scope===pollingScope())refreshPlatform();});
}
let customerScope='',customerGeneration=0,customerDetailGeneration=0,customerTimer,customerResolve;
let customerSearchCompositionActor='',customerRenderPending=false;
const customerActor=()=>({username:state.user,storeId:state.storeId});
const customerActive=()=>state.connection==='connected'&&state.session&&state.page==='customers';
function setCustomerSearchComposing(value){
  customerSearchCompositionActor=value&&customerActive()?actorKey():'';
  if(!customerSearchCompositionActor&&customerRenderPending){customerRenderPending=false;update(()=>{});}
}
async function loadCustomers(query=customerQuery(state)){
  if(!customerActive())return null;
  const actor=actorKey(),generation=++customerGeneration,params={...customerQuery(state),...query};
  const controls=customerControls(state),selectionFilter=JSON.stringify([params.query,params.filter]);
  if(state.customerSelectionFilter&&state.customerSelectionFilter!==selectionFilter){controls.checkedIds=[];controls.selectedId='';state.customerDetail=null;}
  state.customerSelectionFilter=selectionFilter;
  if(!customerActorMatches(state,state.customerView))state.customerView={actor:customerActor(),status:'loading',items:[],stats:{}};
  state.customerLoading=true;update(()=>{});
  clearTimeout(customerTimer);customerResolve?.(null);
  return new Promise(resolve=>{
    customerResolve=resolve;
    customerTimer=setTimeout(async()=>{
      try{
        if(state.capabilities.customers!==true)throw new Error('客户功能尚未装入当前后台，请正常重开已验证的工作台版本。');
        const result=await backend.customers(params);
        if(generation!==customerGeneration||actor!==actorKey()||!customerActive())return;
        if(!customerActorMatches(state,result.customers)){
          await reconcilePlatformActor(actor);
          if(generation!==customerGeneration||actor!==actorKey()||!customerActive())return;
          throw new Error('客户范围回执不一致，请重新加载。');
        }
        state.customerView={...result.customers,status:'ready'};
        controls.page=result.customers.page||1;
        if(!result.customers.items?.some(row=>row.id===controls.selectedId))controls.selectedId=result.customers.items?.[0]?.id||'';
        const selected=controls.selectedId;
        if(selected)loadCustomerDetail(selected);else state.customerDetail=null;
      }catch(error){
        if(generation!==customerGeneration||actor!==actorKey()||!customerActive())return;
        state.customerView={actor:customerActor(),status:'error',items:[],stats:{},error:error.message};
        state.customerDetail=null;showActionError(error);
      }finally{
        if(generation===customerGeneration&&actor===actorKey()){state.customerLoading=false;update(()=>{});}
        if(customerResolve===resolve)customerResolve=null;resolve(null);
      }
    },200);
  });
}
async function loadCustomerDetail(id){
  const actor=actorKey(),generation=++customerDetailGeneration;
  if(!customerActive()||!customerActorMatches(state,state.customerView)||!state.customerView.items?.some(row=>row.id===id))return null;
  state.customerDetail={actor:customerActor(),id,status:'loading'};update(()=>{});
  try{
    const result=await backend.customerDetail(id);
    if(generation!==customerDetailGeneration||actor!==actorKey()||!customerActive()||customerControls(state).selectedId!==id)return null;
    if(!customerActorMatches(state,result.customer)){
      await reconcilePlatformActor(actor);
      if(generation!==customerDetailGeneration||actor!==actorKey()||!customerActive()||customerControls(state).selectedId!==id)return null;
      throw new Error('客户详情范围回执不一致，请重新选择客户。');
    }
    if(result.customer.id!==id||result.customer.item?.id!==id)throw new Error('客户详情回执不一致，请重新选择客户。');
    state.customerDetail={...result.customer,status:'ready'};
  }catch(error){
    if(generation===customerDetailGeneration&&actor===actorKey()&&customerActive()){state.customerDetail={actor:customerActor(),id,status:'error',error:error.message};showActionError(error);}
  }finally{if(generation===customerDetailGeneration&&actor===actorKey()&&customerActive())update(()=>{});}
}
function syncCustomerLoading(){
  const scope=customerActive()?actorKey():'';
  if(scope===customerScope)return;
  customerScope=scope;customerGeneration++;customerDetailGeneration++;clearTimeout(customerTimer);customerResolve?.(null);customerResolve=null;
  if(scope)queueMicrotask(()=>{if(customerActive()&&scope===customerScope)loadCustomers();});
}
async function exportCustomers(payload){
  if(state.customerExporting||!customerActive()||!customerActorMatches(state,state.customerView))return false;
  if(state.customerLoading){toast('客户筛选正在更新，请稍后再导出。');return false;}
  const actor=actorKey();state.customerExporting=true;
  try{
    const result=await backend.exportCustomers(payload),file=result.file;
    if(actor!==actorKey())return false;
    if(!customerActorMatches(state,file)){await reconcilePlatformActor(actor);return false;}
    const mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    if(file.contentType!==mime||typeof file.filename!=='string'||file.filename.length>150||/[\\/\x00-\x1f]/.test(file.filename)||!file.filename.endsWith('.xlsx')||typeof file.dataBase64!=='string'||file.dataBase64.length>16000000)throw new Error('Excel文件回执无效，请重新导出。');
    const binary=atob(file.dataBase64);if(!binary.startsWith('PK\x03\x04'))throw new Error('Excel内容格式不完整，请重新导出。');
    const bytes=Uint8Array.from(binary,char=>char.charCodeAt(0)),url=URL.createObjectURL(new Blob([bytes],{type:mime}));
    // The fitted workbench lives in a same-origin iframe. Start downloads from
    // its outer document so embedded browsers can surface the save operation.
    let downloadDocument=document;
    try{if(window.parent!==window&&window.parent.location.origin===location.origin)downloadDocument=window.parent.document;}catch{}
    const link=downloadDocument.createElement('a');link.href=url;link.download=file.filename;downloadDocument.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
    toast(`已生成${file.rowCount}位客户的Excel，交给浏览器下载。`);return true;
  }catch(error){if(actor===actorKey())showActionError(error);return false;}
  finally{state.customerExporting=false;update(()=>{});}
}
function openCustomerSource(id){
  const detail=state.customerDetail;
  if(!customerActorMatches(state,detail)||detail.status!=='ready'||detail.id!==id||detail.item?.id!==id)return;
  const allowed={'xiaohongshu':['xiaohongshu.com','www.xiaohongshu.com'],'douyin':['douyin.com','www.douyin.com'],'zhihu':['zhihu.com','www.zhihu.com'],'bilibili':['bilibili.com','www.bilibili.com'],'weibo':['weibo.com'],'kuaishou':['kuaishou.com','www.kuaishou.com'],'wechat_channels':['channels.weixin.qq.com','video.weixin.qq.com']};
  try{const url=new URL(detail.item.postUrl);if(url.protocol!=='https:'||url.username||url.password||url.port||!allowed[detail.item.platform]?.includes(url.hostname))throw new Error();window.open(url.href,'_blank','noopener');}
  catch{toast('这条客户记录的源帖地址尚未核对，已保留来源证据。');}
}
function openCustomerReply(id){
  const detail=state.customerDetail;
  if(!customerActive()||!customerActorMatches(state,detail)||detail.status!=='ready'||detail.id!==id||detail.item?.id!==id)return;
  state.selectedCustomer=id;state.replyLive=null;navigate('reply');
}
function openCustomerBatch(ids){
  if(!customerActive()||!customerActorMatches(state,state.customerView)||state.customerLoading)return;
  if(!Array.isArray(ids)||!ids.length||ids.length>20||new Set(ids).size!==ids.length){toast('每批请选择1至20位客户，逐条选择原评论和草稿。');return;}
  state.replyBatchIds=[...ids];state.replyLive=null;state.selectedCustomer=ids[0];navigate('reply');
}
async function showDevelopmentLink(){
  if(state.busy)return false;state.busy=true;
  try{
    const actor=actorKey(),result=await backend.openDevelopment();if(actor!==actorKey())return false;if(!platformActorMatches({actor:result.actor},actor)){await reconcilePlatformActor(actor);return false;}
    const url=new URL(result.developmentURL,location.origin);
    if(!['127.0.0.1','localhost','[::1]'].includes(url.hostname)||!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('网页调试地址无效，请重新生成。');
    modal({title:'打开网页调试',html:`<p>网页与桌面使用同一真实后台。此链接单次有效，${esc(result.expiresIn||30)} 秒后过期。</p><p><a href="${esc(url.href)}" target="_blank" rel="noopener">打开网页调试</a></p><input aria-label="网页调试地址" value="${esc(url.href)}" readonly>`});
  }catch(error){showActionError(error);}
  finally{state.busy=false;}
  return false;
}
function acquireStats(){
  const snapshot=state.platform?.acquisition,last=state.platform?.lastRequest,number=value=>Number.isSafeInteger(value)&&value>=0?value:'—',unknown=state.acquisitionAttempt?.unconfirmed||['submitted','unconfirmed'].includes(last?.state),attributed=last?.job?.taskId&&last.job.taskId===snapshot?.taskId;
  const values=state.connection==='preview'?[128,36,12]:unknown&&!attributed?['—','—','—']:[number(snapshot?.counts?.added),number(snapshot?.summary?.highIntent),number(snapshot?.summary?.replied)];
  return `<div class="top-stats">${['新增客户','高意向','已回复'].map((label,index)=>`<div><span>${label}</span><strong>${values[index]}</strong></div>`).join('')}</div>`;
}
async function runPlatformOperation(action,data={}){
  if(state.busy)return null;const actor=actorKey();state.busy=true;render();
  try{
    if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return null;}
    state.pendingAction={action,platformOperation:true,username:state.user,storeId:state.storeId,requestId:data.requestId};
    const calls={platform_prepare:()=>backend.preparePlatform(),account_create:()=>backend.createAccount(data),account_connect:()=>backend.connectAccount(data.accountId),account_check:()=>backend.checkAccount(data.accountId),account_cancel:()=>backend.cancelAccount(data.jobId),acquisition_start:()=>backend.startAcquisition(data),acquisition_pause:()=>backend.pauseAcquisition(data.taskId),acquisition_resume:()=>backend.resumeAcquisition(data.taskId)};
    const result=await calls[action]();
    if(actor!==actorKey())return null;
    if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return null;}
    state.pendingAction=null;if(result.platform){acceptPlatformSnapshot(result.platform);state.platformError='';state.platformUpdatedAt=Date.now();}return result;
  }catch(error){const unknown=['RESULT_UNCONFIRMED','REQUEST_UNCONFIRMED','COLLECTION_RESULT_UNCONFIRMED'].includes(error.code)||(action==='acquisition_start'&&error.code==='PLATFORM_ACTION_FAILED');if(unknown&&state.pendingAction){state.pendingAction.unconfirmed=true;if(action==='acquisition_start'&&state.acquisitionAttempt)state.acquisitionAttempt.unconfirmed=true;error.code='RESULT_UNCONFIRMED';}if(actor===actorKey())await recoverAction(error);return null;}
  finally{state.busy=false;render();}
}
async function preparePlatform(){const result=await runPlatformOperation('platform_prepare');if(result)toast(result.platform?.device?.message||'本机连接准备状态已更新。');return result;}
let toneReadGeneration=0,toneScopeGeneration=0;
async function readTonePreferences(){
  if(state.connection!=='connected'||!state.session||!state.storeId)return null;
  const actor=actorKey(),generation=++toneReadGeneration;state.tonePreferenceReadActor=actor;state.tonePreferencesLoading=true;state.tonePreferencesError='';
  try{
    const result=await backend.tonePreferencesRead({storeId:state.storeId}),value=result.preferences;
    if(actor!==actorKey()||generation!==toneReadGeneration)return null;
    if(!platformActorMatches(value,actor)||!Number.isSafeInteger(value.revision)||value.revision<0)throw new Error('口吻方案归属未核对，请重新读取。');
    if(platformActorMatches(state.tonePreferences,actor)&&state.tonePreferences.revision>value.revision)return state.tonePreferences;
    state.tonePreferences=value;return value;
  }catch(error){if(actor===actorKey()&&generation===toneReadGeneration){state.tonePreferencesError=error.message;showActionError(error);}return null;}
  finally{if(actor===actorKey()&&generation===toneReadGeneration){state.tonePreferencesLoading=false;render();}}
}
async function saveTonePreferences(choice){
  if(state.busy||!state.storeId)return null;
  if(backend.unconfirmed||state.pendingAction?.unconfirmed){await verifyPending();return null;}
  const actor=actorKey(),storeId=state.storeId,scopeGeneration=toneScopeGeneration;
  const current=()=>actor===actorKey()&&scopeGeneration===toneScopeGeneration;
  toneReadGeneration++;state.tonePreferencesLoading=false;state.tonePreferencesError='';
  try{
    const result=await backend.tonePreferencesSave({storeId,...choice}),value=result.preferences;
    if(!current())return null;
    if(!platformActorMatches(value,actor))throw new Error('口吻方案归属未核对，请重新读取。');
    if(platformActorMatches(state.tonePreferences,actor)&&state.tonePreferences.revision>value.revision)throw new Error('口吻方案已有更新，请重新读取已保存方案。');
    toneReadGeneration++;state.tonePreferencesLoading=false;
    state.tonePreferences=value;return value;
  }catch(error){
    if(!current())return null;
    if(error.code==='RESULT_UNCONFIRMED'){
      try{
        const bootstrap=await backend.bootstrap();if(!current())return null;acceptBootstrap(bootstrap);if(!current())return null;
        const value=await readTonePreferences();
        if(!current())return null;
        if(value?.revision===choice.expectedRevision+1&&['identity','tone','salutation','focus'].every(k=>JSON.stringify(value[k])===JSON.stringify(choice[k]))){state.tonePreferencesError='';return value;}
      }catch{}
    }
    if(current()){state.tonePreferencesError=error.message;showActionError(error);}return null;
  }
}
async function checkAccount(platformId){
  if(state.busy)return null;
  if(!state.storeId){chooseWorkStore('accounts');return null;}
  const row=platformRow(platformId),id=state.platformAccountSelections?.[platformId]||row?.accountId;
  if(!id){toast('请先连接这个平台的账号。');return null;}
  const result=await runPlatformOperation('account_check',{accountId:id});
  if(result)toast(result.job?.message||'账号检查完成，请查看当前状态。');
  return result;
}
function chooseWorkStore(nextPage){
  if(!state.session){navigate('login');return;}
  if(!state.stores?.length){toast(state.notice||'当前账号的门店目录暂不可读，请刷新门店资料。');return;}
  modal({title:'选择本次使用的门店',html:`<label for="work-store-choice">门店</label><select id="work-store-choice">${state.stores.map(row=>`<option value="${esc(row.id)}">${esc(row.name)}</option>`).join('')}</select>`,confirmLabel:'使用这家门店',onConfirm:async()=>{const id=document.getElementById('work-store-choice')?.value;await selectStore(id);if(state.storeId!==id)return false;navigate(nextPage);return true;}});
}
async function startAcquisition(){
  if(state.busy)return null;
  if(!state.storeId){chooseWorkStore('acquire');return null;}
  if(!state.platform||state.platformError)await refreshPlatform({manual:true});
  const platform=state.platform?.platforms?.find(row=>row.id===state.acquire?.selectedPlatform),accountId=state.platformAccountSelections?.[platform?.id]||platform?.accountId;
  if(!platform?.enabled){navigate('accounts');toast('请先连接本次使用的平台账号。');return null;}
  const account=state.platform?.accounts?.find(row=>row.id===accountId&&row.platform===platform.id);
  if(!state.platform?.device?.bound||!accountId||account?.status!=='ready'||!platform.canConnect){
    navigate('accounts');
    toast(account?.message||platform.message||state.platform?.acquisition?.message||'请先连接并核实本次使用的平台账号。');return null;
  }
  if(!state.selection?.applied){
    const current=state.materials?.currentSelection,material=state.materials?.materials?.find(row=>row.key===current?.materialKey);
    const eligible=(material?.keywords||[]).filter(row=>row.eligible&&row.bindings?.some(binding=>binding.presetIds?.includes('precise')));
    if(!eligible.length){toast('这家门店暂没有可用的搜索词，请先查看门店预设。');navigate('presets');return null;}
    state.presets={...state.presets,materialKey:material.key,keywordIds:eligible.slice(0,100).map(row=>row.id),search:'precise',intent:'standard'};
    await applyPreset();if(!state.selection?.applied)return null;
    if(eligible.length>100)toast('本批使用100个搜索词，其余搜索词仍保留在门店方案中。');
  }
  const actor=actorKey(),choice={storeId:state.storeId,expectedRevision:state.selection?.revision,platform:platform.id,accountId,region:state.acquire?.region||'',time:state.acquire?.time||'最近7天'};
  if(!state.acquisitionAttempt||state.acquisitionAttempt.actor!==actor||!state.acquisitionAttempt.unconfirmed){state.acquisitionAttempt={actor,payload:{...choice,requestId:crypto.randomUUID()},unconfirmed:false};}
  const result=await runPlatformOperation('acquisition_start',state.acquisitionAttempt.payload);
  if(result){state.acquisitionAttempt=null;toast('采集请求已提交，进度以真实回执为准。');}
  else if(!state.acquisitionAttempt?.unconfirmed&&!backend.unconfirmed&&!state.pendingAction?.unconfirmed)state.acquisitionAttempt=null;
  return result;
}
function ownedUnconfirmedTask(taskId){const last=state.platform?.lastRequest;return Boolean(state.acquisitionAttempt?.unconfirmed&&last?.requestId===state.acquisitionAttempt.payload.requestId&&['submitted','unconfirmed'].includes(last.state)&&last.job?.taskId===taskId&&state.platform?.acquisition?.canPause);}
async function pauseAcquisition(taskId){
  if(!ownedUnconfirmedTask(taskId)){const result=await runPlatformOperation('acquisition_pause',{taskId});if(result)toast('暂停请求已提交，正在核对任务状态。');return result;}
  if(state.busy)return null;const actor=actorKey();state.busy=true;render();
  try{
    if(backend.unconfirmed)await verifyPending();
    if(actor!==actorKey()||!state.platform?.acquisition?.canPause||(!ownedUnconfirmedTask(taskId)&&state.platform?.acquisition?.taskId!==taskId))return null;
    const result=await backend.pauseAcquisition(taskId);if(actor!==actorKey())return null;if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return null;}
    if(result.platform){acceptPlatformSnapshot(result.platform);state.platformError='';}toast(state.acquisitionAttempt?.unconfirmed?'已请求暂停有归属回执的任务；开始操作仍保留核对状态。':'暂停请求已提交，正在核对任务状态。');return result;
  }catch(error){if(actor===actorKey()){if(error.code==='RESULT_UNCONFIRMED')await recoverAction(error);else showActionError(error);}return null;}
  finally{state.busy=false;render();}
}
async function resumeAcquisition(taskId){const result=await runPlatformOperation('acquisition_resume',{taskId});if(result)toast('恢复请求已提交，正在核对任务状态。');return result;}
async function verifyAcquisition(){if(state.busy)return;state.busy=true;render();try{await verifyPending();}catch(error){showActionError(error);}finally{state.busy=false;render();}}
function platformRow(platformId){return state.platform?.platforms?.find(row=>row.id===platformId);}
function safeQrUrl(value){
  if(typeof value!=='string')return '';
  if(/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(value)&&value.length<3000000)return value;
  try{const url=new URL(value,location.origin);return url.origin===location.origin&&url.pathname.startsWith('/api/workbench/')?url.href:'';}catch{return '';}
}
function showAccountJob(job,platformId,actor){
  if(actor!==actorKey()||state.page!=='accounts')return;
  const jobId=job?.id||job?.jobId,key=jobId||'platform:'+platformId;
  const needsContinue=value=>platformId==='xiaohongshu'&&value?.status==='failed'&&value?.windowOpen===true;
  const dialog=modal({title:'平台账号连接',html:'<p id="account-job-message" role="status">正在读取连接回执…</p><img id="account-job-qr" width="256" height="256" alt="平台登录二维码" hidden><p id="account-job-browser" class="muted">请在本次打开的平台浏览器完成本人登录与网页验证码；身份核验通过后才显示已连接。</p><button type="button" id="account-job-cancel"'+(jobId?'':' hidden')+'>取消本次连接</button>',confirmLabel:needsContinue(job)?'继续登录并检查':jobId?'刷新状态':'检查连接',onConfirm:async()=>{await check();return false;}});
  dialog.dataset.accountJob=key;const modalOwner=dialog.__modalOwner;let timer,closed=false,checking=false,latestJob=job;
  const owns=()=>!closed&&dialog.open&&dialog.__modalOwner===modalOwner&&state.page==='accounts'&&dialog.dataset.accountJob===key&&document.getElementById('account-job-message')&&actor===actorKey();
  function display(value){
    if(!owns())return;latestJob=value;const done=['completed','succeeded','failed','cancelled','stopped'].includes(value?.status);
    document.getElementById('account-job-message').textContent=value?.message||(typeof value?.error==='string'?value.error:value?.error?.message)||(done?'连接操作已返回，请核对账号状态。':'连接进行中，请在平台登录窗口完成确认。');
    const rowFeedback=state.accountPage;if(rowFeedback?.scope===JSON.stringify([state.connection,state.user||'',state.storeId||''])){rowFeedback.feedback[platformId]=document.getElementById('account-job-message').textContent;rowFeedback.failures??={};rowFeedback.failures[platformId]=['failed','cancelled','stopped'].includes(value?.status);}
    const browser=document.getElementById('account-job-browser');
    if(browser)browser.textContent=value?.windowOpen===true?'平台浏览器仍保持打开，可在其中手动登录或完成网页验证码；再次切回请点原来的登录按钮。':value?.persistentBrowser===true&&value?.windowOpen===false?'平台浏览器已关闭，登录资料仍保留；请点原来的登录按钮继续。':'请在本次打开的平台浏览器完成本人登录与网页验证码；身份核验通过后才显示已连接。';
    const image=document.getElementById('account-job-qr'),url=safeQrUrl(value?.qrUrl||value?.qr_url);image.hidden=!url;if(url)image.src=url;else image.removeAttribute('src');
    document.getElementById('account-job-cancel').disabled=!jobId||(done&&value?.windowOpen!==true)||state.busy;
    document.getElementById('account-job-cancel').textContent=done&&value?.windowOpen===true?'关闭登录窗口':'取消本次连接';
    const confirm=dialog.querySelector?.('.modal-confirm');if(confirm)confirm.textContent=needsContinue(value)?'继续登录并检查':jobId?'刷新状态':'检查连接';
    if(done){clearTimeout(timer);refreshPlatform();}return done;
  }
  async function check(){
    if(!owns()||checking)return;checking=true;clearTimeout(timer);
    try{if(needsContinue(latestJob)){await connectAccount(platformId);return;}const result=jobId?await backend.accountJob(jobId):await checkAccount(platformId);if(!owns())return;if(!result){document.getElementById('account-job-message').textContent='本次检查未取得回执，请查看账号页的原因后重试。';return;}if(!platformActorMatches(result.platform,actor)){await reconcilePlatformActor(actor);return;}if(!display(result.job)&&jobId)timer=setTimeout(check,2500);}
    catch(error){if(owns()){document.getElementById('account-job-message').textContent='连接状态暂未更新：'+error.message;if(error.code==='AUTH_REQUIRED')showActionError(error);}}
    finally{checking=false;}
  }
  document.getElementById('account-job-cancel').onclick=async()=>{if(!jobId||!owns())return;const result=await runPlatformOperation('account_cancel',{jobId});if(owns()){if(result?.job)display(result.job);else await check();}};
  dialog.addEventListener('close',()=>{closed=true;clearTimeout(timer);},{once:true});
  if(!display(job)&&jobId)timer=setTimeout(check,1200);
}
async function connectAccount(platformId,accountId){
  if(state.busy)return null;
  if(!state.storeId){chooseWorkStore('accounts');return null;}
  const actor=actorKey(),current=()=>actor===actorKey();
  let row=platformRow(platformId);
  if(!state.platform||state.platformError){await refreshPlatform({manual:true});if(!current())return null;row=platformRow(platformId);}
  if(!row?.enabled){toast(row?.message||'当前平台尚未开通，请刷新账号状态核对。');return;}
  if(!state.platform?.device?.bound||!row.canConnect){
    const prepared=await preparePlatform();if(!prepared||!current())return null;
    row=platformRow(platformId);
    if(!row?.enabled||!row.canConnect){toast(row?.message||state.platform?.device?.message||'本机连接尚未就绪，请查看当前状态。');return;}
  }
  accountId||=state.platformAccountSelections?.[platformId]||row.accountId;
  if(!accountId){
    modal({title:'添加'+(row.name||'平台')+'账号',html:'<label for="new-platform-account-name">账号备注名</label><input id="new-platform-account-name" placeholder="例如：门店渠道账号" autocomplete="off">',confirmLabel:'添加并连接',onConfirm:async()=>{if(!current())return false;const name=document.getElementById('new-platform-account-name').value.trim();if(!name){toast('请输入账号备注名。');return false;}const result=await runPlatformOperation('account_create',{platform:platformId,name});if(!result||!current())return false;const createdId=result.job?.accountId||result.accountId||platformRow(platformId)?.accountId;if(!createdId){toast('账号已添加，请刷新后核对账号记录。');return false;}await connectAccount(platformId,createdId);return true;}});return null;
  }
  const result=await runPlatformOperation('account_connect',{accountId});if(result&&current()){if(state.page==='accounts')showAccountJob(result.job,platformId,actor);else toast('连接请求已提交，请在账号页核对状态。');return result;}return null;
}
const actions={openToneTools:()=>openToneTools(ctx),openSettings:()=>openSettings(ctx),reloadWorkspace,logout,refreshSettingsPlatform:()=>refreshPlatform({manual:true}),refreshRuntimeStatus,replyEditor:()=>document.querySelector('[data-live-draft]'),hasUnconfirmed:()=>backend.unconfirmed||Boolean(state.pendingAction?.unconfirmed),handoffAction:(kind,data)=>({read:backend.handoffRead,save:backend.handoffSave}[kind])(data),update,navigate,toast,modal,selectStore,applyPreset,refreshAssessments,refreshPlatform,showDevelopmentLink,preparePlatform,connectAccount,checkAccount,readTonePreferences,saveTonePreferences,startAcquisition,pauseAcquisition,resumeAcquisition,verifyAcquisition,loadCustomers,loadCustomerDetail,exportCustomers,openCustomerSource,openCustomerReply,openCustomerBatch,setCustomerSearchComposing,replyCustomers:data=>backend.customers(data),replyRead:data=>backend.replyRead(data),replySave:data=>backend.replySave(data),replyReview:data=>backend.replyReview(data),replyCheck:data=>backend.replyCheck(data),deliveryAction:(kind,data)=>({prepare:backend.deliveryPrepare,start:backend.deliveryStart,status:backend.deliveryStatus,cancel:backend.deliveryCancel}[kind])(data),replyError:showActionError};
const ctx={viewModel,actions,state:viewModel,...actions};
function navButton(page,label,img){return `<button class="nav-btn ${state.page===page?'active':''}" data-nav="${page}" ${state.page===page?'aria-current="page"':''}>${icon(img)}<span>${label}</span></button>`;}
function shell(content){const dates=localDates();if(state.connection==='connected'&&state.session&&!state.storeId)content=`<div role="status"><p class="login-error">${esc(state.notice||state.capabilities?.reason||'请到管理页明确选择已授权门店分组。')}</p></div>`+content;if(state.workspaceError)content=`<div role="alert"><p class="login-error">${esc(state.workspaceError.message)}</p><button type="button" id="reload-workspace" ${state.busy?'disabled':''}>重新加载门店资料</button></div>`+content;const management=['presets','rules','tone','accounts'].includes(state.page);const nav=management?`${navButton('rules','获客规则','approved-icon-search.svg')}${navButton('tone','IP与口吻','icon-message-square-more.svg')}${navButton('accounts','平台与账号','approved-icon-user-round.svg')}<hr class="nav-divider"><button class="nav-btn" data-info="工作台设置">${icon('approved-icon-settings.svg')}<span>设置</span></button>${navButton('acquire','返回工作台','tabler-home.svg')}`:`${navButton('acquire','获客','approved-icon-search.svg')}${navButton('reply','回复','icon-message-square-more.svg')}${navButton('customers','客户','approved-icon-user-round.svg')}<hr class="nav-divider">${navButton('accounts','账号','approved-icon-user-round.svg')}${navButton('rules','管理','approved-icon-settings.svg')}`;
return `<div class="shell" data-current="${state.page}"><aside class="sidebar"><div class="brand"><span class="brand-mark"><img src="/assets/fy-approved-official-logo.png" alt="方隅公寓官方标志"></span><div class="brand-copy"><strong>方隅工作台</strong><span>渠道运营</span></div></div><nav class="side-nav" aria-label="主导航">${nav}</nav><img class="side-photo" src="/assets/sidebar-approved-photo.png" alt="阳光中的公寓建筑"><div class="side-quote"><strong>让更多人</strong><br>住进更好的城市生活</div></aside><div class="hero-photo"><img src="/assets/fy-approved-header-apartment.png" alt=""></div><header class="topbar ${management||state.page==='customers'?'has-date':''}">${management?`<time class="topbar-date" data-local-date="long">${dates.long}</time><span class="topbar-divider"></span>`:''}<button class="bell" aria-label="通知">${icon('fy-icon-58-bell.png')}</button><button class="account-button" aria-label="${esc(state.user||'演示账号')}账号菜单"><img class="avatar" src="/assets/portrait-man-1.png" alt="账号头像"><span>${esc(state.user||'演示账号')}</span>${icon('tabler-chevron-down.svg')}</button>${state.page==='customers'?`<span class="topbar-divider"></span><time class="topbar-date" data-local-date="short">${dates.short}</time>`:''}</header>${state.page==='reply'?`<div class="date-label" data-local-date="iso">${dates.iso}</div>`:''}${management||state.page==='reply'||state.page==='customers'?'<div class="hero-quote">好房子<br>让生活更靠近理想</div>':''}<main class="main"><div class="page-heading"><h1>${titles[state.page][0]}</h1><p>${titles[state.page][1]}</p></div>${state.page==='acquire'?acquireStats():''}<section id="page-content">${content}</section><footer class="page-footer">${state.connection==='preview'?'界面预览 · 示例数据':'方隅工作台'}&nbsp;&nbsp; <time data-local-date="iso">${dates.iso}</time></footer></main></div>`;}
function login(){const preview=state.connection==='preview',waiting=state.connection==='loading';return `<main class="login-page"><section class="login-photo" aria-label="方隅公寓"><img src="/assets/login-approved-photo.png" alt="暖阳透过落地窗，洒在公寓客厅"><div class="login-caption">让每一次咨询，都有回应。<small>— 方隅公寓</small></div></section><section class="login-form-wrap"><span class="demo-pill">${preview?'演示界面':'员工登录'}</span><div class="login-wordmark" aria-label="方隅公寓，高档一居租方隅"><div class="login-wordmark-top"><span class="login-wordmark-mark"><img src="/assets/fy-approved-official-logo.png" alt="方隅官方标志"></span><strong>方隅公寓</strong></div><small>高档一居租方隅</small></div><h1>欢迎回来</h1><form class="login-form" id="login-form"><label class="field-label" for="login-name">员工用户名</label><div class="login-input">${icon('fy-icon-16-user.png')}<input id="login-name" autocomplete="username" value="${esc(state.loginDraft?.username??state.rememberedUsername)}" placeholder="请输入用户名" aria-describedby="login-error" ${waiting?'disabled':''}></div><label class="field-label" for="login-pass">密码</label><div class="login-input">${icon('fy-icon-43-lock.png')}<input id="login-pass" type="password" autocomplete="current-password" aria-label="密码" ${waiting?'disabled':''}><button type="button" class="password-eye" aria-label="显示密码">${icon('fy-icon-45-eye.png')}</button></div><div class="login-options"><label class="remember"><input id="login-remember" type="checkbox" ${(state.loginDraft?.rememberUsername??Boolean(state.rememberedUsername||preview))?'checked':''}>记住用户名</label><button type="button" id="forgot-password">忘记密码？联系管理员。</button></div><button class="login-submit" type="submit" ${waiting||state.busy?'disabled':''}>${waiting?'正在连接…':state.busy?'正在验证…':backend.unconfirmed?'核对登录状态':'登录工作台'} ${icon('icon-arrow-right.svg')}</button><div class="login-meta"><span><i class="service-dot"></i>${preview?'演示服务已就绪':waiting?'正在连接本地服务':state.connection==='error'?'服务连接待重试':'本地服务已连接'}</span><span><button type="button" id="login-help">使用帮助</button>│&nbsp; <span data-runtime-version title="${esc(state.runtimeMetadata?.value?.release||'')}">${esc(versionLabel(state))}</span></span></div><p id="login-error" class="login-error" aria-live="polite">${esc(state.loginError||state.connectionError||'')}</p></form></section></main>`;}
function tools(){if(state.connection!=='preview')return '';return `<details class="preview-tools"><summary>预览状态</summary><div><span>${state.connection==='preview'?'仅演示数据':(state.capabilities.customers?'仅切换回复页示例':'仅切换回复与客户示例')}</span><button data-scenario="normal">正常</button><button data-scenario="empty">空数据</button><button data-scenario="loading">加载中</button><button data-scenario="error">失败与重试</button><button data-scenario="long">长评论</button><button data-nav="login">返回登录</button></div></details>`;}
async function submitLogin(event){
  event.preventDefault();if(state.busy)return;
  const name=document.getElementById('login-name'),password=document.getElementById('login-pass'),error=document.getElementById('login-error');
  const username=name.value.trim();state.loginDraft={username,rememberUsername:document.getElementById('login-remember').checked};
  if(backend.unconfirmed||state.pendingAction?.unconfirmed){state.busy=true;error.textContent='正在核对上次操作结果，请稍候…';try{await verifyPending();}catch{state.loginError='暂时无法核对，请稍后点击登录按钮再次核对。';}finally{state.busy=false;render();}return;}
  if(!username){error.textContent=state.connection==='preview'?'请输入演示用户名':'请输入员工用户名';name.focus();return;}
  if(state.connection==='preview'){state.user=username;state.store||='古北店';navigate('acquire');toast('欢迎回来，已进入界面预览');return;}
  if(!password.value){error.textContent='请输入密码';password.focus();return;}
  state.busy=true;document.querySelector('.login-submit').disabled=true;error.textContent='正在验证账号，请稍候…';state.loginError='';
  try{
    if(state.connection==='error'){const boot=await backend.bootstrap();if(!boot)throw new Error('当前服务未提供员工登录，请从桌面方隅工作台打开。');acceptBootstrap(boot);}
    state.pendingAction={action:'login',username};
    acceptBootstrap(await backend.login({username,password:password.value,rememberUsername:state.loginDraft.rememberUsername}));
    state.pendingAction=null;state.loginDraft=undefined;password.value='';state.connectionError='';navigate('acquire');toast(state.notice||(state.store?'登录成功，门店：'+state.store:'登录成功，请到管理页选择已授权门店分组'));
  }catch(failure){if(failure?.code==='RESULT_UNCONFIRMED'){password.value='';await recoverAction(failure);}else{state.pendingAction=null;state.loginError=failure.message||'登录未完成，请稍后重试。';}}
  finally{password.value='';state.busy=false;render();if(state.page==='login')document.getElementById('login-pass')?.focus();}
}
function render(){
  // Preserve the actual IME input node while list/detail responses update data.
  // Navigation or an identity change must always render immediately.
  if(customerSearchCompositionActor===actorKey()&&customerActive()){customerRenderPending=true;return false;}
  customerSearchCompositionActor='';customerRenderPending=false;
  paneScroll.save();
  cleanup?.();cleanup=undefined;document.body.dataset.page=state.page;
  const mod=pages[state.page];
  if(state.page==='login'){
    app.innerHTML=login()+tools();
    document.getElementById('login-form').addEventListener('submit',submitLogin);
    document.querySelector('.password-eye').onclick=()=>{const i=document.getElementById('login-pass');i.type=i.type==='password'?'text':'password';document.querySelector('.password-eye').setAttribute('aria-label',i.type==='text'?'隐藏密码':'显示密码');};
    document.getElementById('forgot-password').onclick=()=>modal({title:'联系管理员',html:'<p>如需重置员工账号，请联系门店管理员。</p>'+ (state.connection==='preview'?'<p class="muted">当前为界面演示，无需输入真实账号或密码。</p>':'<p class="muted">请使用已开通的方隅员工账号登录。</p>')});
    document.getElementById('login-help').onclick=()=>modal({title:'使用帮助',html:state.connection==='preview'?'<p>填写任意演示用户名即可预览工作台。</p><p>可依次查看获客、回复、客户和门店预设。所有操作仅改变本地演示状态。</p>':'<p>使用已开通的管理员或员工账号与密码登录。管理员需明确选择云端已绑定门店分组。勾选“记住用户名”只保存用户名，不保存密码。</p><p>登录后可保存门店预设，查看平台连接、采集状态与本机可见客户，并导出Excel；回复页可逐条保存与核对草稿，发送需另行完整核对并明确授权；当前平台暂停与许可约束继续生效。</p>'});
  }else{
    app.innerHTML=shell(mod?mod.render(state):'')+tools();
    if(mod?.bind)cleanup=mod.bind(document.getElementById('page-content'),ctx);
    document.getElementById('reload-workspace')?.addEventListener('click',reloadWorkspace);
    document.querySelector('.bell').onclick=()=>modal({title:'工作提醒',html:state.connection==='preview'?'<p>待回复客户 <strong>12</strong> 位，建议优先查看超高意向和高意向客户。</p><p class="muted">此处为示例提醒。</p>':'<p>请在回复页查看当前员工可见客户，选择原评论后保存与核对草稿。</p><p>真实发送需完整核对并明确授权，且须满足平台与设备条件。</p>',confirmLabel:'查看意向回复',onConfirm:()=>navigate('reply')});
    document.querySelector('.account-button').onclick=()=>{modal({title:(state.user||'演示账号')+' · 渠道运营',html:`<p>当前门店：${esc(state.store||'待管理员分配')}</p><p>${state.connection==='preview'?'演示账号的操作仅保留在当前预览。':'当前显示真实登录、门店、平台、本机客户和回复草稿；草稿核对不代表已发送。'}</p>${state.connection==='preview'?'':'<p><button type="button" id="open-development">打开网页调试</button></p>'}`,confirmLabel:state.connection==='preview'?'退出预览':'退出登录',onConfirm:()=>state.connection==='preview'?navigate('login'):logout()});document.getElementById('open-development')?.addEventListener('click',showDevelopmentLink);};
    document.querySelectorAll('[data-info]').forEach(b=>b.onclick=()=>b.dataset.info==='口吻方案'?openToneTools(ctx):openSettings(ctx));
  }
  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
  document.querySelectorAll('[data-scenario]').forEach(b=>b.onclick=()=>{state.scenario=b.dataset.scenario;if(state.scenario==='normal'){state.reply=undefined;state.customers=undefined;}render();toast({normal:'已还原正常示例',empty:'查看空数据状态',loading:'查看加载状态',error:'查看失败与重试',long:'查看长评论状态'}[state.scenario]);});
  app.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',e=>{if(!a.getAttribute('href').startsWith('#')){e.preventDefault();modal({title:'查看源帖',html:'<p>本地预览展示来源信息，不打开真实平台。</p>'});}}));
  paneScroll.restore();
  syncPlatformPolling();
  syncCustomerLoading();
  reply.sync(state,ctx);
  if(state.page==='reply'&&state.session&&state.storeId&&!platformActorMatches(state.tonePreferences,actorKey())&&!state.tonePreferencesLoading&&state.tonePreferenceReadActor!==actorKey())queueMicrotask(readTonePreferences);
}
document.addEventListener('visibilitychange',syncPlatformPolling);
document.addEventListener('visibilitychange',updateRuntimeLabels);
window.addEventListener('focus',updateRuntimeLabels);
window.addEventListener('hashchange',()=>navigate(location.hash.slice(1)||'login'));
window.addEventListener('error',e=>console.error('Workbench:',e.message));
render();
backend.bootstrap().then(result=>{
  if(result){acceptBootstrap(result);navigate(state.session?(initialPage==='login'?'acquire':initialPage):'login');if(state.notice)toast(state.notice);}
  else{state.connection='preview';state.store='古北店';state.user='小林';navigate(initialPage);}
}).catch(error=>{state.connection='error';state.connectionError=error.message;navigate('login');}).finally(()=>{if(state.connection!=='preview')refreshRuntimeStatus();});
