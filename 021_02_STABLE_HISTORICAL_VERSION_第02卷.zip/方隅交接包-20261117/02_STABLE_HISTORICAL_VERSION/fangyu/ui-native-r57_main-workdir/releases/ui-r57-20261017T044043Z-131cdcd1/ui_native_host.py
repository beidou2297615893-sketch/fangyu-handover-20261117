"""WebView2 stable snapshot and editable local UI over one employee backend."""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit, parse_qs
import uuid
import http.client
import hmac
import importlib.util
import re
import secrets
from http.cookies import SimpleCookie

SCHEMA = 'fangyu_native_ui_release_v1'
COMPANY_ID = 'fangyu-apartment-client'
CSP = ("default-src 'self'; connect-src 'none'; img-src 'self' data:; "
       "style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; "
       "object-src 'none'; frame-src 'self'; form-action 'none'; base-uri 'none'")
MIME = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
        '.mjs': 'text/javascript; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
        '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.woff2': 'font/woff2'}
API_ACTIONS = frozenset(('login', 'logout', 'select_store', 'apply_preset', 'open_development',
    'platform_prepare', 'account_create', 'account_connect', 'account_cancel',
    'acquisition_start', 'acquisition_pause', 'acquisition_resume', 'customer_export', 'refresh_assessments',
    'reply_read', 'reply_save', 'reply_review', 'reply_check', 'reply_delivery_prepare',
    'reply_delivery_start','reply_delivery_status','reply_delivery_cancel','customer_handoff_read','customer_handoff_save'))
SESSION_COOKIE = 'fangyu_workbench_r57'


class UIHostError(RuntimeError):
    pass


class RuntimeRequestError(ValueError):
    def __init__(self, code, message, status):
        super().__init__(message)
        self.code, self.status = code, status


def checked_path(path: Path, *, directory=False):
    """Reject links/reparse points before touching public release files."""
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise UIHostError('界面文件路径不能是链接或重定向。')
    info = path.stat()
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise UIHostError('界面目录不存在。')
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise UIHostError('界面文件必须是独立的普通文件。')
    return info


def read_public(path: Path, expected_hash=None, expected_size=None):
    before = checked_path(path)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        body = stream.read()
        ended = os.fstat(stream.fileno())
    after = checked_path(path)
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns)
    if not identity(before) == identity(opened) == identity(ended) == identity(after):
        raise UIHostError('界面文件在检查时发生变化，请重新打开。')
    digest = hashlib.sha256(body).hexdigest().upper()
    if ((expected_hash is not None and digest != expected_hash.upper())
            or (expected_size is not None and len(body) != expected_size)):
        raise UIHostError('界面文件校验失败，请重新固化界面版本。')
    return body


def verify_release(root: Path, manifest_sha256: str):
    root = Path(root).absolute()
    checked_path(root, directory=True)
    raw = read_public(root / 'RELEASE.json', manifest_sha256)
    manifest = json.loads(raw)
    if (manifest.get('schema') != SCHEMA or manifest.get('company_id') != COMPANY_ID
            or type(manifest.get('files')) is not list):
        raise UIHostError('界面版本清单不匹配。')
    files = {}
    for entry in manifest['files']:
        name = entry.get('path', '')
        relative = PurePosixPath(name)
        if (not name or relative.is_absolute() or '..' in relative.parts
                or '\\' in name or ':' in name or name in files
                or relative.as_posix() != name
                or not (name.startswith('web/') or name.startswith('resources/')
                        or name in ('ui_native_host.py', 'workbench_backend.py', 'customer_workbench.py',
                                    'store_materials.py','store_materials_catalog.json','rental_assessment.py','reply_workbench.py','reply_delivery.py'))):
            raise UIHostError('界面版本包含无效文件名。')
        if (type(entry.get('size')) is not int or entry['size'] < 0
                or not isinstance(entry.get('sha256'), str)
                or len(entry['sha256']) != 64):
            raise UIHostError('界面版本文件记录不完整。')
        read_public(root / name, entry['sha256'], entry['size'])
        files[name] = entry
    required = {'ui_native_host.py', 'web/index.html', 'web/app.mjs', 'web/styles.css'}
    if not required.issubset(files):
        raise UIHostError('界面版本缺少入口或样式。')
    actual = set()
    for tree in ('web', 'resources'):
        checked_path(root / tree, directory=True)
        for item in (root / tree).rglob('*'):
            checked_path(item, directory=item.is_dir())
            if item.is_file():
                actual.add(item.relative_to(root).as_posix())
    actual.add('ui_native_host.py')
    if (root / 'workbench_backend.py').exists():
        checked_path(root / 'workbench_backend.py')
        actual.add('workbench_backend.py')
    if (root / 'customer_workbench.py').exists():
        checked_path(root / 'customer_workbench.py')
        actual.add('customer_workbench.py')
    for extra in ('store_materials.py','store_materials_catalog.json','rental_assessment.py','reply_workbench.py','reply_delivery.py'):
        if (root / extra).exists():
            checked_path(root / extra)
            actual.add(extra)
    if actual != set(files):
        raise UIHostError('界面版本文件集合与清单不一致。')
    return manifest, files


class StaticServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, root, files, *, backend=None, cookie_name=SESSION_COOKIE, runtime=None):
        self.root = Path(root)
        self.runtime = runtime
        self.backend = backend
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', cookie_name):
            raise UIHostError('本地会话名称无效。')
        self.session_cookie = cookie_name
        self.mode = 'stable'
        self.csrf_token = secrets.token_urlsafe(32)
        self.csp = CSP.replace("connect-src 'none'", "connect-src 'self'") if backend else CSP
        self.login_failures = []
        self.api_lock = runtime.api_lock if runtime else threading.RLock()
        self.public = {'/' + name[4:]: entry for name, entry in files.items()
                       if name.startswith('web/') and Path(name).suffix in MIME}
        self.public['/'] = self.public['/index.html']
        self.counters = {'static': 0, 'blocked': 0}
        super().__init__(('127.0.0.1', 0), StaticHandler)

    def read_static(self, path):
        entry = self.public.get(path)
        if entry is None:
            raise FileNotFoundError(path)
        return (read_public(self.root / entry['path'], entry['sha256'], entry['size']),
                MIME[Path(entry['path']).suffix])


class DevelopmentServer(StaticServer):
    """Serve only editable public UI source; reuse the stable API transport."""
    def __init__(self, root, files, *, source_root, assets_root, **kwargs):
        self.source_root = Path(source_root).absolute()
        self.assets_root = Path(assets_root).absolute()
        checked_path(self.source_root, directory=True)
        super().__init__(root, files, **kwargs)
        self.mode = 'development'

    def read_static(self, path):
        name = 'index.html' if path == '/' else path.lstrip('/')
        relative = PurePosixPath(name)
        parts = relative.parts
        if (not parts or relative.is_absolute() or relative.as_posix() != name
                or any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', part) for part in parts)
                or any(re.search(r'(?i)(credential|secret|cookie|password|vault|token)', part) for part in parts)):
            raise FileNotFoundError(path)
        code = {'.html', '.css', '.js', '.mjs'}
        images = {'.png', '.webp', '.jpg', '.jpeg', '.svg', '.woff2'}
        if len(parts) == 1 and relative.suffix in code:
            target = self.source_root / name
        elif len(parts) == 2 and parts[0] == 'pages' and relative.suffix in code:
            target = self.source_root / name
        elif len(parts) >= 2 and parts[0] == 'assets' and relative.suffix in images:
            target = self.source_root / name
            if not target.exists():
                target = self.assets_root.joinpath(*parts[1:])
        else:
            raise FileNotFoundError(path)
        return read_public(target), MIME[relative.suffix]


class StaticHandler(BaseHTTPRequestHandler):
    server_version = 'FangyuUI'
    sys_version = ''

    def log_message(self, *_):
        pass

    def finish_response(self, status, body=b'', content_type='text/plain; charset=utf-8', *, cookie=None, location=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Security-Policy', self.server.csp)
        if cookie is not None:
            self.send_header('Set-Cookie', cookie)
        if location is not None:
            self.send_header('Location', location)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Connection', 'close')
        self.end_headers()
        if self.command != 'HEAD' and body:
            self.wfile.write(body)
        self.close_connection = True

    def reject(self, status=403):
        self.server.counters['blocked'] += 1
        self.finish_response(status, '此入口仅提供本机工作台页面。'.encode('utf-8'))

    def api_response(self, status, value, *, cookie=None):
        self.finish_response(status, json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8'),
                             'application/json; charset=utf-8', cookie=cookie)

    def session_token(self):
        try:
            cookies = SimpleCookie(self.headers.get('Cookie', ''))
            name = self.server.session_cookie
            value = cookies[name].value if name in cookies else ''
            return value if re.fullmatch(r'[A-Za-z0-9_-]{1,256}', value) else ''
        except Exception:
            return ''

    def dispatch_api(self, action, data):
        with self.server.api_lock:
            try:
                if self.server.runtime is not None and self.server.runtime.closed:
                    raise RuntimeRequestError('BACKEND_CLOSED', '本地服务已关闭。', 503)
                if action == 'login':
                    now = time.monotonic()
                    self.server.login_failures = [stamp for stamp in self.server.login_failures if now-stamp < 300]
                    if len(self.server.login_failures) >= 10:
                        return self.api_response(429, {'ok': False, 'error': {'code': 'LOGIN_RATE_LIMIT', 'message': '登录尝试较多，请5分钟后再试。'}})
                if action == 'open_development':
                    if data or self.server.runtime is None:
                        raise RuntimeRequestError('ACTION_FORBIDDEN', '当前入口不能打开开发页面。', 403)
                    result = self.server.runtime.open_development(self.session_token())
                else:
                    result = dict(self.server.backend.dispatch(action, data, token=self.session_token()))
                token = result.pop('token', None)
                max_age = result.pop('cookie_max_age', None)
                cookie = None
                if action == 'login' and token:
                    if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,256}', token):
                        raise UIHostError('登录会话响应无效。')
                    cookie = self.server.session_cookie + '=' + token + '; Path=/; HttpOnly; SameSite=Strict'
                    if isinstance(max_age, (int, float)) and math.isfinite(max_age):
                        cookie += '; Max-Age=' + str(max(1, min(int(max_age), 30*86400)))
                    self.server.login_failures = []
                elif action == 'logout':
                    cookie = self.server.session_cookie + '=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'
                self.api_response(200, {'ok': True, **result, 'csrfToken': self.server.csrf_token}, cookie=cookie)
            except Exception as error:
                known = isinstance(getattr(error, 'code', None), str)
                status = getattr(error, 'status', 400) if known else 503
                if type(status) is not int or status not in (400, 401, 403, 404, 409, 422, 429, 503):
                    status = 400
                # An unavailable service is not a rejected employee credential.
                # Keep the existing limit for confirmed authentication failures.
                if action == 'login' and status == 401:
                    self.server.login_failures.append(time.monotonic())
                self.api_response(status, {'ok': False, 'error': {
                    'code': error.code if known else 'WORKBENCH_UNAVAILABLE',
                    'message': str(error) if known else '暂时无法完成操作，请稍后重试。'}})

    def do_POST(self):
        origin = 'http://127.0.0.1:' + str(self.server.server_port)
        if (self.server.backend is None or self.path != '/api/workbench'
                or self.headers.get('Host') != origin[7:]
                or self.headers.get('Origin') != origin
                or self.headers.get('Upgrade') or self.headers.get('Transfer-Encoding')
                or self.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json'
                or not hmac.compare_digest(self.headers.get('X-Fangyu-CSRF', ''), self.server.csrf_token)):
            return self.reject()
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 1 <= size <= 16384:
                return self.reject(413)
            value = json.loads(self.rfile.read(size))
            if (not isinstance(value, dict) or set(value) - {'action', 'data'}
                    or value.get('action') not in API_ACTIONS or not isinstance(value.get('data'), dict)):
                return self.reject()
        except (ValueError, UnicodeError, TypeError):
            return self.reject(400)
        self.dispatch_api(value['action'], value['data'])

    def do_GET(self):
        expected_host = '127.0.0.1:' + str(self.server.server_port)
        if self.headers.get('Host') != expected_host or self.headers.get('Upgrade'):
            return self.reject()
        try:
            parsed = urlsplit(self.path)
            path = unquote(parsed.path, errors='strict')
        except (ValueError, UnicodeError):
            return self.reject()
        if (parsed.scheme or parsed.netloc or '\\' in path or '\x00' in path
                or any(part in ('.', '..') for part in path.split('/'))):
            return self.reject()
        if path == '/favicon.ico':
            return self.finish_response(204)
        if path == '/__workbench_status' and self.server.runtime is not None and not parsed.query:
            return self.api_response(200, self.server.runtime.public_status(self.server))
        if path == '/__open' and self.server.runtime is not None and self.server.mode == 'development':
            if self.command != 'GET':
                return self.finish_response(405)
            try:
                query = parse_qs(parsed.query, strict_parsing=True)
                if set(query) != {'ticket'} or len(query['ticket']) != 1:
                    return self.reject(400)
                token = self.server.runtime.consume_ticket(query['ticket'][0])
                cookie = self.server.session_cookie + '=' + token + '; Path=/; HttpOnly; SameSite=Strict'
                return self.finish_response(303, cookie=cookie, location='/')
            except RuntimeRequestError as error:
                return self.api_response(error.status, {'ok': False, 'error': {'code': error.code, 'message': str(error)}})
            except (ValueError, UnicodeError):
                return self.reject(400)
            except Exception:
                return self.api_response(503, {'ok': False, 'error': {'code': 'WORKBENCH_UNAVAILABLE', 'message': '暂时无法确认员工登录，请返回工作台重试。'}})
        if path == '/api/workbench/bootstrap' and self.server.backend is not None and not parsed.query:
            return self.dispatch_api('bootstrap', {})
        if path == '/api/workbench/platform' and self.server.backend is not None and not parsed.query:
            return self.dispatch_api('platform_snapshot', {})
        if path in ('/api/workbench/customers', '/api/workbench/customer') and self.server.backend is not None:
            try:
                query = parse_qs(parsed.query, strict_parsing=True, keep_blank_values=True) if parsed.query else {}
                allowed = ({'query', 'filter', 'sort', 'sortDirection', 'page', 'pageSize'}
                           if path.endswith('/customers') else {'id'})
                if set(query) - allowed or any(len(values) != 1 for values in query.values()):
                    return self.reject(400)
                data = {key: values[0] for key, values in query.items()}
                if path.endswith('/customer'):
                    if set(data) != {'id'} or not re.fullmatch(r'[0-9a-f]{64}', data['id']):
                        return self.reject(400)
                else:
                    for key in ('page', 'pageSize'):
                        if key in data:
                            if not re.fullmatch(r'[1-9][0-9]{0,5}', data[key]):
                                return self.reject(400)
                            data[key] = int(data[key])
                return self.dispatch_api('customers' if path.endswith('/customers') else 'customer_detail', data)
            except (ValueError, UnicodeError):
                return self.reject(400)
        if path == '/api/workbench/account-job' and self.server.backend is not None:
            try:
                query = parse_qs(parsed.query, strict_parsing=True)
                if (set(query) != {'jobId'} or len(query['jobId']) != 1
                        or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', query['jobId'][0])):
                    return self.reject(400)
                return self.dispatch_api('account_job', {'jobId': query['jobId'][0]})
            except ValueError:
                return self.reject(400)
        try:
            body, mime = self.server.read_static(path)
        except FileNotFoundError:
            return self.reject(403 if path.startswith('/api') else 404)
        except (OSError, UIHostError):
            return self.finish_response(503, '界面资源校验失败，请关闭后重新打开。'.encode('utf-8'))
        self.server.counters['static'] += 1
        self.finish_response(200, body, mime)

    do_HEAD = do_GET
    do_PUT = reject
    do_PATCH = reject
    do_DELETE = reject
    do_OPTIONS = reject
    do_CONNECT = reject
    do_TRACE = reject


def create_state_directory(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    checked_path(root, directory=True)
    return root


def verify_backend_dependencies(root, files, project):
    """Read-only hash checks; never construct a Core or access customer records."""
    if 'workbench_backend.py' not in files:
        return None
    dependency = files.get('resources/backend-dependencies.json')
    if dependency is None:
        raise UIHostError('登录组件缺少依赖清单。')
    config = json.loads(read_public(root / dependency['path'], dependency['sha256'], dependency['size']))
    if config.get('schema') != 'fangyu-existing-login-components-v1':
        raise UIHostError('登录组件依赖清单不匹配。')
    source = project / 'work/ui-runtime-r55/src'
    expected = set()
    for item in config.get('files', []):
        name = item.get('path', '')
        relative = PurePosixPath(name)
        if (not name or relative.is_absolute() or '..' in relative.parts or '\\' in name
                or ':' in name or relative.as_posix() != name or relative.suffix != '.py'
                or name in expected):
            raise UIHostError('登录组件包含无效路径。')
        read_public(source / name, item['sha256'], item['size'])
        expected.add(name)
    actual = {path.relative_to(source).as_posix() for path in source.rglob('*.py')}
    if not expected or actual != expected:
        raise UIHostError('已有登录组件发生变化，请重新核验本版本。')
    return source


def create_backend(root, files, *, project_root, data_dir=None, company=None):
    """Reuse the pinned customer components without importing app/main or schedulers."""
    entry = files.get('workbench_backend.py')
    if entry is None:
        return None
    project = Path(project_root).absolute()
    source = verify_backend_dependencies(root, files, project)
    sys.path.insert(0, str(source))
    # Load the pinned r57 role-preserving adapter before any business import.
    integration_entry = files.get('resources/platform-runtime/vendor-src/integrations.py')
    if integration_entry:
        integration_path = root / integration_entry['path']
        previous = sys.modules.get('integrations')
        if previous is not None and Path(previous.__file__).resolve() != integration_path.resolve():
            raise UIHostError('已有身份组件来源不同，请独立重开候选验收。')
        if previous is None:
            child = importlib.util.module_from_spec(importlib.util.spec_from_loader('integrations',loader=None))
            child.__file__ = str(integration_path)
            sys.modules['integrations'] = child
            raw = read_public(integration_path,integration_entry['sha256'],integration_entry['size'])
            exec(compile(raw,child.__file__,'exec'),child.__dict__)
    module_name = 'fangyu_workbench_backend'
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader(module_name, loader=None))
    module.__file__ = str(root / entry['path'])
    sys.modules[module_name] = module
    raw = read_public(root / entry['path'], entry['sha256'], entry['size'])
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    extra = {}
    if any(name in files for name in ('store_materials.py','store_materials_catalog.json','rental_assessment.py')):
        if not all(name in files for name in ('store_materials.py','store_materials_catalog.json','rental_assessment.py')):
            raise UIHostError('门店词库和判断模块不完整，请重新固化。')
        loaded = {}
        for filename in ('store_materials.py','rental_assessment.py'):
            item=files[filename]
            name='fangyu_'+Path(filename).stem
            child=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
            child.__file__=str(root/item['path'])
            sys.modules[name]=child
            source_bytes=read_public(root/item['path'],item['sha256'],item['size'])
            exec(compile(source_bytes,child.__file__,'exec'),child.__dict__)
            loaded[filename]=child
        catalog=files['store_materials_catalog.json']
        extra['materials_factory']=lambda core: loaded['store_materials.py'].StoreMaterials(
            core,root/catalog['path'],expected_sha256=catalog['sha256'])
        extra['rental_factory']=loaded['rental_assessment.py'].RentalAssessmentService
    customer_entry = files.get('customer_workbench.py')
    if customer_entry is not None:
        customer_name = 'fangyu_customer_workbench'
        customer_module = importlib.util.module_from_spec(importlib.util.spec_from_loader(customer_name, loader=None))
        customer_module.__file__ = str(root / customer_entry['path'])
        sys.modules[customer_name] = customer_module
        customer_raw = read_public(root / customer_entry['path'], customer_entry['sha256'], customer_entry['size'])
        exec(compile(customer_raw, customer_module.__file__, 'exec'), customer_module.__dict__)
        extra['customer_factory'] = customer_module.CustomerWorkbench
    reply_entry = files.get('reply_workbench.py')
    if reply_entry is not None:
        reply_module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_reply_workbench',loader=None))
        reply_module.__file__ = str(root/reply_entry['path'])
        raw = read_public(root/reply_entry['path'],reply_entry['sha256'],reply_entry['size'])
        exec(compile(raw,reply_module.__file__,'exec'),reply_module.__dict__)
        extra['reply_factory'] = reply_module.ReplyWorkbench
    delivery_entry=files.get('reply_delivery.py')
    if delivery_entry is not None:
        delivery_module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_reply_delivery',loader=None))
        delivery_module.__file__=str(root/delivery_entry['path'])
        raw=read_public(root/delivery_entry['path'],delivery_entry['sha256'],delivery_entry['size'])
        exec(compile(raw,delivery_module.__file__,'exec'),delivery_module.__dict__)
        extra['delivery_factory']=delivery_module.ReplyDelivery
    platform_entry = files.get('resources/platform-runtime/platform_runtime.py')
    if platform_entry is not None:
        platform_name = 'fangyu_platform_runtime'
        platform_module = importlib.util.module_from_spec(importlib.util.spec_from_loader(platform_name, loader=None))
        platform_module.__file__ = str(root / platform_entry['path'])
        sys.modules[platform_name] = platform_module
        platform_raw = read_public(root / platform_entry['path'], platform_entry['sha256'], platform_entry['size'])
        exec(compile(platform_raw, platform_module.__file__, 'exec'), platform_module.__dict__)
        extra['platform_factory'] = platform_module.PlatformRuntime
    return module.WorkbenchBackend(project_root=project, data_dir=data_dir, company=company, **extra)


class SharedRuntime:
    """One backend instance with stable and editable same-origin HTTP surfaces."""
    def __init__(self, root, files, state_root, *, project_root, release_id,
                 profile='production', source_root=None, assets_root=None,
                 data_dir=None, company=None, backend_factory=None, clock=time.monotonic):
        if profile not in ('production', 'fixture') or (profile == 'fixture' and backend_factory is None):
            raise UIHostError('测试运行必须显式提供隔离后台。')
        self.root, self.files = Path(root), files
        self.project = Path(project_root).absolute()
        self.state_root = Path(state_root).absolute()
        self.profile, self.release_id = profile, str(release_id)
        self.instance_id = uuid.uuid4().hex
        self.source_root = Path(source_root) if source_root else self.project / 'work/ui-approved-implementation/ui-preview'
        self.assets_root = Path(assets_root) if assets_root else self.project / 'work/ui-runtime-r56/src/web/workspace/assets'
        self.data_dir, self.company = data_dir, company
        self.backend_factory = backend_factory or (lambda **kwargs: create_backend(self.root, self.files, **kwargs))
        self.clock = clock
        self.api_lock = threading.RLock()
        self.backend = self.stable = self.development = None
        self.threads = []
        self.mutex = None
        self.closed = False
        self.tickets = {}

    def start(self):
        if self.closed or self.backend is not None:
            raise UIHostError('本地服务不能重复启动。')
        try:
            if self.profile == 'production' and os.name == 'nt':
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p)
                kernel.CreateMutexW.restype = ctypes.c_void_p
                self.mutex = kernel.CreateMutexW(None, False, 'Local\\Fangyu.Backend.R57.production')
                if not self.mutex or ctypes.get_last_error() == 183:
                    raise UIHostError('方隅真实后台已经运行，请使用当前服务。')
            self.backend = self.backend_factory(project_root=self.project, data_dir=self.data_dir, company=self.company)
            cookie = SESSION_COOKIE if self.profile == 'production' else SESSION_COOKIE + '_fixture_' + self.instance_id[:12]
            self.stable = StaticServer(self.root, self.files, backend=self.backend, cookie_name=cookie, runtime=self)
            self.development = DevelopmentServer(self.root, self.files, source_root=self.source_root,
                assets_root=self.assets_root, backend=self.backend, cookie_name=cookie, runtime=self)
            for server in (self.stable, self.development):
                thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .1}, daemon=True)
                thread.start()
                self.threads.append((server, thread))
            create_state_directory(self.state_root)
            self.write_active()
            return self
        except Exception:
            self.close()
            raise

    def write_active(self):
        value = {'schema': 'fangyu-shared-runtime-v1', 'instanceId': self.instance_id,
                 'pid': os.getpid(), 'profile': self.profile, 'mode': 'shared-runtime',
                 'release': self.release_id, 'stablePort': self.stable.server_port,
                 'developmentPort': self.development.server_port}
        target = self.state_root / 'active.json'
        temporary = target.with_name('active.' + uuid.uuid4().hex + '.tmp')
        with temporary.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2))
        os.replace(temporary, target)

    def public_status(self, server):
        return {'instanceId': self.instance_id, 'profile': self.profile,
                'mode': server.mode, 'release': self.release_id}

    def _confirmed_employee(self, token):
        if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,256}', token):
            raise RuntimeRequestError('AUTH_REQUIRED', '请先登录员工账号。', 401)
        result = self.backend.dispatch('bootstrap', {}, token=token)
        user = (result.get('session') or {}).get('user') or {}
        if user.get('role') not in ('operator', 'admin'):
            raise RuntimeRequestError('AUTH_REQUIRED', '请先登录有效的员工账号。', 401)
        stores = result.get('stores') or []
        return {'username': user.get('username', ''),
                'storeId': (result.get('selection') or {}).get('storeId', '')}

    def open_development(self, token):
        with self.api_lock:
            actor = self._confirmed_employee(token)
            now = self.clock()
            self.tickets = {key: value for key, value in self.tickets.items() if value[0] > now}
            if len(self.tickets) >= 128:
                raise RuntimeRequestError('TOO_MANY_LINKS', '开发链接较多，请稍后重试。', 429)
            ticket = secrets.token_urlsafe(32)
            self.tickets[ticket] = (now + 30, token)
            return {'developmentURL': 'http://127.0.0.1:' + str(self.development.server_port) +
                    '/__open?ticket=' + ticket, 'expiresIn': 30, 'actor': actor}

    def consume_ticket(self, ticket):
        with self.api_lock:
            if not re.fullmatch(r'[A-Za-z0-9_-]{32,100}', ticket):
                raise RuntimeRequestError('LINK_EXPIRED', '开发链接已失效，请重新打开。', 410)
            value = self.tickets.pop(ticket, None)
            if value is None or value[0] <= self.clock():
                raise RuntimeRequestError('LINK_EXPIRED', '开发链接已失效，请重新打开。', 410)
            self._confirmed_employee(value[1])
            return value[1]

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.tickets.clear()
        for server, thread in self.threads:
            server.shutdown()
            thread.join(timeout=3)
        for server in (self.stable, self.development):
            if server is not None:
                server.server_close()
        try:
            with self.api_lock:
                if self.backend is not None:
                    self.backend.close()
        finally:
            if self.mutex is not None:
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
                kernel.CloseHandle(self.mutex)
                self.mutex = None
            target = self.state_root / 'active.json'
            try:
                if json.loads(target.read_text('utf-8')).get('instanceId') == self.instance_id:
                    target.unlink()
            except (OSError, ValueError):
                pass


def http_self_test(root, files):
    """Exercise the real loopback handler; no window or business modules involved."""
    server = StaticServer(root, files)
    worker = threading.Thread(target=server.serve_forever,
                              kwargs={'poll_interval': .05}, daemon=True)
    worker.start()
    checks = []
    def request(method, path, expected, *, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=4)
        try:
            connection.request(method, path, headers=headers or {})
            response = connection.getresponse()
            body = response.read()
            assert response.status == expected, (method, path, response.status)
            assert response.getheader('Content-Security-Policy') == CSP
            checks.append({'method': method, 'path': path, 'status': response.status})
            return body
        finally:
            connection.close()
    try:
        body = request('GET', '/', 200)
        assert body == read_public(Path(root) / 'web/index.html')
        request('HEAD', '/app.mjs', 200)
        for path in sorted(server.public):
            request('GET', path, 200)
        request('GET', '/api', 403)
        request('POST', '/api', 403)
        request('PUT', '/index.html', 403)
        request('OPTIONS', '/', 403)
        request('GET', '/RELEASE.json', 404)
        request('GET', '/ui_native_host.py', 404)
        request('GET', '/%2e%2e/RELEASE.json', 403)
        request('GET', '/assets/%2e%2e/%2e%2e/RELEASE.json', 403)
        request('GET', '/', 403, headers={'Host': 'external.invalid'})
        request('GET', '/', 403, headers={'Upgrade': 'websocket'})
        return {'status': 'PASS', 'checks': len(checks), 'public_urls': len(server.public),
                'business_app_imported': 'app' in sys.modules,
                'native_windows_opened': 0, 'requests': checks}
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=3)


def write_status(path: Path, stage: str, **extra):
    # Only lifecycle and public DOM metrics; never form values or customer content.
    value = {'schema': 'fangyu_native_ui_status_v1', 'stage': stage, 'pid': os.getpid(),
             'time_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **extra}
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temporary, path)


DOM_PROBE = """(() => {
    const outerDoc = document.documentElement;
    const frame = document.getElementById('workspace-frame');
    const content = frame ? frame.contentDocument : document;
    const contentWindow = frame ? frame.contentWindow : window;
    const doc = content?.documentElement;
    const app = content?.getElementById('app');
    const images = [...(content?.images || [])];
    const page = content?.body?.dataset.page || '';
    const rect = frame?.getBoundingClientRect();
    const viewport = (win, element) => ({width: win?.innerWidth || 0,
        height: win?.innerHeight || 0, client_width: element?.clientWidth || 0,
        client_height: element?.clientHeight || 0, scroll_width: element?.scrollWidth || 0,
        scroll_height: element?.scrollHeight || 0, device_pixel_ratio: win?.devicePixelRatio || 0});
    return {
        page, ready_state: content?.readyState || 'loading',
        app_children: app?.children.length || 0,
        primary_present: !!content?.querySelector(page === 'login' ? '#login-form' : '.shell'),
        font_status: content?.fonts?.status || 'unsupported',
        images: {total: images.length, pending: images.filter(i => !i.complete).length,
                 failed: images.filter(i => i.complete && i.naturalWidth === 0).length},
        viewport: viewport(window, outerDoc),
        content_viewport: viewport(contentWindow, doc),
        fit: frame ? {enabled: true, x: rect.x, y: rect.y, right: rect.right,
            bottom: rect.bottom, width: rect.width, height: rect.height,
            layout_width: frame.offsetWidth, layout_height: frame.offsetHeight,
            scale_x: rect.width / frame.offsetWidth, scale_y: rect.height / frame.offsetHeight,
            covers_viewport: Math.abs(rect.x) <= 1 && Math.abs(rect.y) <= 1
                && Math.abs(rect.right - innerWidth) <= 1
                && Math.abs(rect.bottom - innerHeight) <= 1}
            : {enabled: false}
    };
})()"""


def validate_dom_report(report, expected_page):
    """Validate a read-only WebView2 probe; an HTML load alone is insufficient."""
    if not isinstance(report, dict):
        raise UIHostError('界面渲染状态不可读取。')
    expected_pages = (expected_page,) if isinstance(expected_page, str) else expected_page
    if (report.get('page') not in expected_pages or report.get('app_children', 0) < 1
            or not report.get('primary_present')):
        raise UIHostError('界面模块未完成渲染。')
    if report.get('ready_state') != 'complete' or report.get('font_status') != 'loaded':
        raise UIHostError('界面文档或字体尚未完成加载。')
    images = report.get('images', {})
    if images.get('pending', 1) or images.get('failed', 1):
        raise UIHostError('界面图片尚未完整加载。')
    viewport = report.get('viewport', {})
    if min(viewport.get('width', 0), viewport.get('height', 0)) <= 0:
        raise UIHostError('界面内容尺寸无效。')
    if viewport.get('scroll_width', 0) > viewport['width'] + 1:
        raise UIHostError('界面内容出现横向溢出。')
    fit = report.get('fit', {})
    if fit.get('enabled'):
        numeric = ('x', 'y', 'right', 'bottom', 'width', 'height',
                   'layout_width', 'layout_height', 'scale_x', 'scale_y')
        if any(type(fit.get(key)) not in (int, float)
               or not math.isfinite(fit[key]) for key in numeric):
            raise UIHostError('界面缩放尺寸无效。')
        if (min(fit[key] for key in ('width', 'height', 'layout_width',
                                    'layout_height', 'scale_x', 'scale_y')) <= 0
                or abs(fit['scale_x'] - fit['scale_y']) > .003):
            raise UIHostError('界面未按相同比例缩放。')
        if (fit['x'] < -1 or fit['y'] < -1 or fit['right'] > viewport['width'] + 1
                or fit['bottom'] > viewport['height'] + 1
                or viewport.get('scroll_height', 0) > viewport['height'] + 1):
            raise UIHostError('缩放后的完整界面超出窗口。')
        if (fit.get('covers_viewport') is not True or abs(fit['x']) > 1
                or abs(fit['y']) > 1 or abs(fit['right'] - viewport['width']) > 1
                or abs(fit['bottom'] - viewport['height']) > 1):
            raise UIHostError('界面没有填满当前窗口。')
        content = report.get('content_viewport', {})
        if (min(content.get('width', 0), content.get('height', 0)) <= 0
                or content.get('scroll_width', 0) > content['width'] + 1
                or content.get('scroll_height', 0) > content['height'] + 1):
            raise UIHostError('界面画布仍有未显示的内容。')
    return report


def inspect_native_dom(window, expected_page, timeout=10):
    # pywebview 6.2's loaded handlers run on a worker thread. Keep evaluate_js
    # here, outside native.Invoke/WinForms UI callbacks, so its result can return.
    deadline = time.monotonic() + timeout
    report = None
    while True:
        report = window.evaluate_js(DOM_PROBE)
        try:
            return validate_dom_report(report, expected_page)
        except UIHostError as error:
            if ((isinstance(report, dict) and report.get('images', {}).get('failed', 0))
                    or time.monotonic() >= deadline):
                raise UIHostError(str(error)) from error
            time.sleep(.1)


XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'


def _native_download_origin(stable_url):
    parsed = urlsplit(stable_url)
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1'
            or not parsed.port or parsed.netloc != '127.0.0.1:' + str(parsed.port)):
        raise UIHostError('桌面下载来源不是本机稳定界面。')
    return parsed.scheme, parsed.netloc


def _native_same_origin(value, origin):
    try:
        parsed = urlsplit(str(value))
        return (parsed.scheme, parsed.netloc) == origin
    except (TypeError, ValueError):
        return False


def _native_own_blob(value, origin):
    value = str(value)
    if not value.startswith('blob:'):
        return False
    try:
        blob = urlsplit(value[5:])
        return ((blob.scheme, blob.netloc) == origin and not blob.query and not blob.fragment
                and re.fullmatch(r'/[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', blob.path)
                is not None)
    except ValueError:
        return False


def _native_xlsx_name(value):
    import ntpath
    name = ntpath.basename(str(value))
    if (not name or len(name) > 180 or name != name.strip()
            or not name.lower().endswith('.xlsx') or name.lower() == '.xlsx'
            or any(character in '<>:"/\\|?*' or ord(character) < 32
                   or ord(character) == 127 or '\u202a' <= character <= '\u202e'
                   or '\u2066' <= character <= '\u2069' for character in name)
            or name.split('.')[0].upper() in {'CON', 'PRN', 'AUX', 'NUL',
                *(f'COM{number}' for number in range(1, 10)),
                *(f'LPT{number}' for number in range(1, 10))}):
        return None
    return name


def native_navigation_handler(stable_url):
    """Keep navigation on the stable origin; only its UUID blobs may download."""
    origin = _native_download_origin(stable_url)

    def guard(sender, args):
        try:
            target = str(args.Uri)
            if target == 'about:blank' or _native_same_origin(target, origin):
                return
            if (_native_own_blob(target, origin)
                    and _native_same_origin(sender.Source, origin)):
                return
        except Exception:
            pass
        args.Cancel = True
    return guard


def native_xlsx_download_handler(stable_url, owner, winforms):
    """Permit an XLSX blob only after the employee chooses a native save path.

    Reuses pywebview's WinForms SaveFileDialog approach, without changing its
    process-wide ALLOW_DOWNLOADS=False policy. Nothing here writes a file.
    """
    origin = _native_download_origin(stable_url)

    def download(sender, args):
        args.Cancel = True
        args.Handled = True
        dialog = None
        try:
            operation = args.DownloadOperation
            name = _native_xlsx_name(args.ResultFilePath)
            if (not _native_same_origin(sender.Source, origin)
                    or not _native_own_blob(operation.Uri, origin)
                    or str(operation.MimeType).lower() != XLSX_MIME or not name):
                return
            dialog = winforms.SaveFileDialog()
            dialog.Title = '保存客户 Excel'
            dialog.Filter = 'Excel 工作簿 (*.xlsx)|*.xlsx'
            dialog.DefaultExt = 'xlsx'
            dialog.AddExtension = True
            dialog.CheckPathExists = True
            dialog.ValidateNames = True
            dialog.OverwritePrompt = True
            dialog.RestoreDirectory = True
            dialog.FileName = name
            if dialog.ShowDialog(owner) != winforms.DialogResult.OK:
                return
            import ntpath
            chosen = str(dialog.FileName)
            drive, tail = ntpath.splitdrive(chosen)
            if (not drive or not ntpath.isabs(chosen) or ':' in tail
                    or not _native_xlsx_name(chosen)):
                return
            args.ResultFilePath = chosen
            args.Cancel = False
        except Exception:
            # Cancellation is the only safe fallback; never use a browser default.
            args.Cancel = True
        finally:
            if dialog is not None:
                try:
                    dialog.Dispose()
                except Exception:
                    args.Cancel = True
    return download


def attach_native_download_policy(window, stable_url, *, winforms=None):
    """Run on WinForms UI thread after CoreWebView2 has initialized."""
    if winforms is None:
        from webview.platforms.edgechromium import WinForms as winforms
    browser = window.native.browser
    core = browser.webview.CoreWebView2
    download = native_xlsx_download_handler(stable_url, browser.form, winforms)
    navigation = native_navigation_handler(stable_url)
    # Fail closed if the installed pywebview event binding cannot be replaced.
    core.DownloadStarting.__iadd__(download)
    default_removed = False
    try:
        core.DownloadStarting.__isub__(browser.on_download_starting)
        default_removed = True
        browser.webview.NavigationStarting.__iadd__(navigation)
    except Exception as error:
        if default_removed:
            core.DownloadStarting.__iadd__(browser.on_download_starting)
        core.DownloadStarting.__isub__(download)
        raise UIHostError('无法准备桌面 Excel 保存入口。') from error
    # Keep Python delegates alive for this window only.
    window._fangyu_ui_download_handler = download
    window._fangyu_ui_navigation_guard = navigation
    return True


def native_window(root, files, state_root, initial_page='login', *, project_root, release_id, data_dir=None):
    import webview
    state_root = create_state_directory(state_root)
    storage = create_state_directory(state_root / 'webview2')
    logs = create_state_directory(state_root / 'launches')
    status_path = logs / (uuid.uuid4().hex + '.json')
    write_status(status_path, 'verified')
    mutex = None
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p)
        kernel.CreateMutexW.restype = ctypes.c_void_p
        mutex = kernel.CreateMutexW(None, False, 'Local\\Fangyu.UIReview.R57')
        if not mutex:
            raise UIHostError('无法准备界面窗口，请稍后重试。')
        if ctypes.get_last_error() == 183:
            kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
            kernel.CloseHandle(mutex)
            raise UIHostError('方隅新界面已经打开，请查看已有窗口。')
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Fangyu.Workbench.UIReview.R57')
    server = None
    backend = None
    runtime = None
    try:
        runtime = SharedRuntime(root, files, state_root, project_root=project_root,
                                release_id=release_id, data_dir=data_dir).start()
        server, backend = runtime.stable, runtime.backend
        url = 'http://127.0.0.1:' + str(server.server_port) + '/#' + initial_page
        window = webview.create_window('方隅工作台', url=url, width=1440, height=960,
            min_size=(720, 480), background_color='#F2FAFB', text_select=True, zoomable=False)
        accepted = {'renderer': False, 'loaded': False, 'error': None, 'dom': None}

        def initialized(renderer):
            accepted['renderer'] = renderer == 'edgechromium'
            return accepted['renderer']

        def loaded():
            if accepted['loaded'] or accepted['error']:
                return
            try:
                if not accepted['renderer']:
                    raise UIHostError('需要 WebView2 桌面运行时。')
                from System import Action
                def attach():
                    attach_native_download_policy(window, url)
                window.native.Invoke(Action(attach))
                accepted['dom'] = inspect_native_dom(window,
                    ('login', 'acquire', 'reply', 'customers', 'presets', 'accounts') if backend else initial_page)
                if accepted['error']:
                    raise accepted['error']
                accepted['loaded'] = True
                write_status(status_path, 'native_ready', port=server.server_port,
                             development_port=runtime.development.server_port,
                             instance_id=runtime.instance_id, release_id=release_id,
                             renderer='edgechromium', dom=accepted['dom'],
                             native_xlsx_download='guarded_save_dialog',
                             business_connected=backend is not None,
                             connected_features=['employee_login', 'store_presets', 'platform_accounts', 'collection', 'customers', 'customer_export', 'reply_drafts', 'reply_review', 'explicit_reply_delivery', 'reviewed_reply_batch', 'reply_delivery_status_cancel', 'customer_internal_handoff'] if backend else [])
            except Exception as error:
                accepted['error'] = error
                window.destroy()

        window.events.initialized += initialized
        window.events.loaded += loaded
        webview.settings['ALLOW_DOWNLOADS'] = False
        write_status(status_path, 'opening', port=server.server_port,
                     development_port=runtime.development.server_port,
                     instance_id=runtime.instance_id, release_id=release_id)
        startup_finished = threading.Event()
        def startup_monitor():
            if not startup_finished.wait(45) and not accepted['loaded']:
                accepted['error'] = UIHostError('界面加载超时，请关闭后重新打开。')
                try:
                    window.destroy()
                except Exception:
                    pass
        watchdog = threading.Thread(target=startup_monitor, daemon=True)
        watchdog.start()
        icon = root / 'resources' / 'brand.ico'
        try:
            webview.start(gui='edgechromium', debug=False, private_mode=False,
                          storage_path=str(storage), icon=str(icon) if icon.is_file() else None)
        finally:
            startup_finished.set()
        if accepted['error']:
            raise accepted['error']
        if not accepted['renderer'] or not accepted['loaded']:
            raise UIHostError('WebView2 窗口未完成加载，请确认桌面运行时可用。')
        write_status(status_path, 'closed', requests=server.counters,
                     renderer='edgechromium', dom=accepted['dom'],
                     business_connected=backend is not None,
                     connected_features=['employee_login', 'store_presets', 'platform_accounts', 'collection', 'customers', 'customer_export', 'reply_drafts', 'reply_review', 'explicit_reply_delivery', 'reviewed_reply_batch', 'reply_delivery_status_cancel', 'customer_internal_handoff'] if backend else [])
        return 0
    except Exception as error:
        write_status(status_path, 'failed', error_type=type(error).__name__,
                     error=str(error) if isinstance(error, UIHostError) else None)
        raise
    finally:
        if runtime is not None:
            runtime.close()
        if mutex is not None:
            kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
            kernel.CloseHandle(mutex)


def serve_runtime(root, files, state_root, *, project_root, release_id, stop_event=None, **kwargs):
    """Headless lifecycle for the same backend and two UI surfaces."""
    runtime = SharedRuntime(root, files, state_root, project_root=project_root,
                            release_id=release_id, **kwargs).start()
    try:
        print(json.dumps({'status': 'running', **runtime.public_status(runtime.stable),
                          'stableURL': 'http://127.0.0.1:' + str(runtime.stable.server_port) + '/',
                          'developmentURL': 'http://127.0.0.1:' + str(runtime.development.server_port) + '/'}, ensure_ascii=False), flush=True)
        try:
            (stop_event or threading.Event()).wait()
        except KeyboardInterrupt:
            pass
        return 0
    finally:
        runtime.close()


def main(release_root, manifest_sha256, state_root, argv=None, *, project_root=None, data_dir=None):
    parser = argparse.ArgumentParser(description='方隅工作台本地界面')
    parser.add_argument('--check', action='store_true', help='仅核验资源和原生依赖，不打开窗口')
    parser.add_argument('--self-test', action='store_true', help='核验静态HTTP及业务隔离，不打开窗口')
    parser.add_argument('--serve', action='store_true', help='仅运行同一真实后台与网页服务，不打开桌面窗口')
    parser.add_argument('--project-root', help='明确指定本客户项目根目录')
    parser.add_argument('--page', choices=('login', 'acquire', 'reply', 'customers', 'presets'), default='login')
    options = parser.parse_args(argv)
    manifest, files = verify_release(Path(release_root), manifest_sha256)
    project = Path(options.project_root).absolute() if options.project_root else (Path(project_root).absolute() if project_root else None)
    if 'workbench_backend.py' in files:
        if project is None:
            raise UIHostError('启动器需明确指定方隅客户项目目录。')
        verify_backend_dependencies(Path(release_root), files, project)
    if options.self_test:
        print(json.dumps(http_self_test(Path(release_root), files), ensure_ascii=False))
        return 0
    if options.check:
        import webview
        report = {'status': 'PASS', 'release_id': manifest['release_id'], 'files': len(files),
                  'webview_version': importlib.metadata.version('pywebview'),
                  'native_windows_opened': 0, 'business_app_imported': False}
        print(json.dumps(report, ensure_ascii=False))
        return 0
    if options.serve:
        if project is None:
            raise UIHostError('网页服务需明确指定方隅客户项目目录。')
        return serve_runtime(Path(release_root), files, Path(state_root), project_root=project,
                             release_id=manifest['release_id'], data_dir=data_dir)
    if project is None:
        raise UIHostError('桌面启动器需明确指定方隅客户项目目录。')
    return native_window(Path(release_root), files, Path(state_root), options.page,
                         project_root=project, release_id=manifest['release_id'], data_dir=data_dir)


def notify_error(error):
    message = str(error) if isinstance(error, UIHostError) else '界面未能启动，请查看本版本的启动状态。'
    if os.name == 'nt':
        ctypes.windll.user32.MessageBoxW(None, message, '方隅工作台 · 打开提示', 0x10)
    else:
        print(message, file=sys.stderr)
