"""Local rental evidence assessments, kept separate from historical grades.

Standard-library, deterministic initial rules; not a calibrated language model.
The pure evaluator never calls a provider. Persisted assessments require the
service's current tenant/employee/task/source checks.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import re
import unicodedata
from decimal import Decimal, InvalidOperation

RULE_VERSION = "2026-10-16-intent-budget-income-draft-v2"
ENTITY = "rental_assessments_v1"
TZ = timezone(timedelta(hours=8))
_OWN = re.compile(r"我(?:自己|本人|们|俩)?|本人|咱们")
_OTHER = re.compile(r"朋友|同事|别人|网友|客户|房东|他|她")
_NEED = re.compile(r"求租|找房|想.{0,12}租|要.{0,8}租|找.{0,14}(?:一居|两居|三居|公寓|房)|考虑换租|换租|租个|共同整租|短租.{0,8}(?:公寓|房)|想要.{0,12}(?:一居|两居|三居|公寓)")
_SUPPLY = re.compile(r"转租|出租|招租|我是房东|房源发布")
_VIEW = re.compile(r"看房|约看|看这套|看一下房")
_ROOM = re.compile(r"一居|两居|三居|四居|单间|一室|两室|三室|整租|Studio", re.I)
_PLACE = re.compile(r"虹桥|徐泾东|龙柏|天璟|季乐路|蟠中路|蟠臻路|会展中心|金汇路|古北|浦江|[一-鿿]{1,7}(?:路|区|站|商圈)")
_QUOTE = re.compile(r'“[^”]*”|‘[^’]*’|「[^」]*」|『[^』]*』|"[^"\n]*"')

def _stamp(value=None):
    if value is None:
        return datetime.now(TZ)
    if isinstance(value, datetime):
        return value.astimezone(TZ) if value.tzinfo is not None else None
    if isinstance(value, str):
        try:
            d = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return d.astimezone(TZ) if d.tzinfo is not None else None
        except ValueError:
            return None
    return None

def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()

def _clauses(text):
    masked = list(text)
    for m in _QUOTE.finditer(text):
        masked[m.start():m.end()] = " " * (m.end()-m.start())
    visible = "".join(masked)
    result, subject = [], "self"
    for m in re.finditer(r"[^，,。！？!?；;\n]+", visible):
        v = m.group(); own = list(_OWN.finditer(v)); other = list(_OTHER.finditer(v))
        if own and (not other or own[-1].start() > other[-1].start()):
            subject = "self"
        elif other:
            subject = "third_party"
        result.append({"text":v, "quote":text[m.start():m.end()], "start":m.start(),
                       "end":m.end(), "subject":subject})
    return result

def _evidence(source, clause, signal, explanation):
    return {"signal_id":signal, "source_id":source.get("source_id"),
            "quote":clause["quote"], "start":clause["start"], "end":clause["end"],
            "offset_unit":"unicode_codepoint", "polarity":"affirmed",
            "subject":clause["subject"], "time_status":"current", "explanation":explanation}

def _empty_budget():
    return {"raw_quote":None, "amount_min":None, "amount_max":None, "limit_kind":"unknown",
            "currency":None, "currency_raw":None, "period":"unknown", "cost_scope":"unknown",
            "allocation":"unknown", "occupants":None, "monthly_unit_rent_cap":None,
            "annual_equivalent_monthly":None, "constraints":[], "comparable":False,
            "normalization_formula":None, "normalization_label":"Unknown", "missing_fields":[], "evidence":[]}

_HISTORICAL = re.compile(r"去年|以前|曾经|过去|上次|之前|租过|找过|看过")
_CURRENT = re.compile(r"现在|目前|仍|还在|还找|这次|重新|再约")
_CLOSED = re.compile(r"已经租好|已租好|已经租到|已租到|已经找好|已找好|不找了|不再找|现在不租|不是找房|没有租房需求")
_NEGATED_NEED = re.compile(r"不想.{0,4}租|不打算.{0,5}租|不准备.{0,5}租|不需要.{0,5}(?:租|房)|没打算.{0,5}租|不是.{0,3}(?:求租|想租|找房)")
_CANCEL = re.compile(r"取消|不去看|不想看|不看房|不签|不准备签|还没决定签|没有预约|没约好")
_CONTRACT = re.compile(r"(?:准备|决定|想|确认|要).{0,5}(?:签.{0,5}(?:租约|租赁合同)|交.{0,4}押金|订这套)|这套我要租|发.{0,5}(?:租约|租赁合同)")
_LOW = re.compile(r"只是.{0,5}(?:了解|看看)|只想.{0,5}了解|提前了解|明年.{0,8}(?:搬|租)|以后有需要|暂时看看|长期计划")
_CONDITIONAL = re.compile(r"如果|假如|要是|倘若|等.{0,8}(?:涨工资|有钱)")
_COMMERCIAL = re.compile(r"月租.{0,8}(?:多少|预算)|租金.{0,6}(?:多少|询问)|有.{0,4}空房|还有房|能租|怎么付款|押一付|能.{0,3}养猫")

def _event_days(text, published):
    """Conservative original-post date ranges; never anchor to collection time."""
    if published is None:
        return None
    anchor = published.date()
    for word, n in (("大后天",3),("后天",2),("明天",1),("今天",0)):
        if word in text:
            day=anchor+timedelta(days=n);return day,day
    if "下周" in text or "下星期" in text:
        first=anchor+timedelta(days=7-anchor.weekday());return first,first+timedelta(days=6)
    if "这周" in text or "本周" in text:
        return anchor,anchor+timedelta(days=6-anchor.weekday())
    week=re.search(r"(?:周|星期)([一二三四五六日天末])",text)
    if week:
        n={"一":0,"二":1,"三":2,"四":3,"五":4,"六":5,"日":6,"天":6,"末":5}[week[1]]
        first=anchor+timedelta(days=(n-anchor.weekday())%7)
        return first,first+timedelta(days=1 if week[1]=="末" else 0)
    md=re.search(r"(?:(\d{4})年)?(\d{1,2})月(?:(\d{1,2})[日号]|(底))",text)
    if md:
        try:
            year=int(md[1] or anchor.year);month=int(md[2])
            if md[4]:
                nxt=datetime(year+1,1,1) if month==12 else datetime(year,month+1,1)
                day=(nxt-timedelta(days=1)).date()
            else:day=datetime(year,month,int(md[3])).date()
            return day,day
        except ValueError:return None
    if "月底" in text:
        nxt=datetime(anchor.year+1,1,1) if anchor.month==12 else datetime(anchor.year,anchor.month+1,1)
        day=(nxt-timedelta(days=1)).date();return day,day
    days=re.search(r"(\d{1,2})天内",text)
    if days:return anchor,anchor+timedelta(days=int(days[1]))
    return None

def _valid_action(clause, published, instant):
    text=clause["text"]
    if clause["subject"]!="self" or (_HISTORICAL.search(text) and not _CURRENT.search(text)):
        return False,None
    if _CANCEL.search(text) and not re.search(r"重新|再约|现在.{0,5}(?:约|看)",text):return False,None
    if _CONDITIONAL.search(text) and not re.search(r"如果有(?:空)?房|有房的话",text):return False,None
    if _CONTRACT.search(text):return True,None
    if not _VIEW.search(text):return False,None
    days=_event_days(text,published)
    if days and days[1] < instant.date():return False,days
    confirmed=bool(re.search(r"已约好|已预约|预约成功|约好了",text))
    recent=published is not None and timedelta(0)<=instant-published<=timedelta(days=7)
    return bool(days is not None or confirmed and recent),days

_NUM = r"(?:[0-9０-９]{1,8}(?:[.．][0-9０-９]{1,4})?\s*[kKＫｋ万千]?|[一二两三四五六七八九十百千万]{1,10})"
_MONEY = re.compile(r"(?P<lo>"+_NUM+r")(?:\s*[-~～至到]\s*(?P<hi>"+_NUM+r"))?")

def _amount(raw):
    value=unicodedata.normalize("NFKC",raw).replace(" ","")
    try:
        if re.fullmatch(r"\d+(?:\.\d+)?[kK万千]?",value):
            mult={"k":1000,"K":1000,"万":10000,"千":1000}.get(value[-1],1)
            amount=Decimal(value[:-1] if mult!=1 else value)*mult
        else:
            digits={"一":1,"二":2,"两":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9}
            total=0;section=0;number=0
            for char in value:
                if char in digits:number=digits[char]
                elif char in ("十","百","千"):
                    section+=(number or 1)*{"十":10,"百":100,"千":1000}[char];number=0
                elif char=="万":total+=(section+number or 1)*10000;section=0;number=0
                else:return None
            # Colloquial 一万五 / 三千五 leaves omitted denomination ambiguous.
            if len(value)>1 and value[-1] in digits and any(c in value[:-1] for c in "百千万") and not value.endswith("零"+value[-1]):return None
            amount=Decimal(total+section+number)
        if not 0<=amount<=100000000:return None
        return int(amount) if amount==amount.to_integral_value() else float(amount)
    except (ValueError,InvalidOperation):return None

def _currency(text, full):
    def found(value):
        return [code for pattern,code in ((r"人民币|\bRMB\b|\bCNY\b","CNY"),(r"美元|\bUSD\b","USD"),(r"港币|港元|\bHKD\b","HKD"),(r"日元|\bJPY\b","JPY")) if re.search(pattern,value,re.I)]
    codes=found(text) or found(full)
    return codes[0] if len(codes)==1 else None

def _period(text):
    if re.search(r"总(?:价|预算|额)|三晚|两晚|几晚|\d+晚",text):return "stay_total"
    if re.search(r"/年|每年|年租|年房租|年预算|年度|一年",text):return "year"
    if re.search(r"/月|每月|月租|月房租|月薪|月收入",text):return "month"
    if re.search(r"/晚|每晚",text):return "night"
    if re.search(r"/天|每天|日租",text):return "day"
    if re.search(r"/周|每周",text):return "week"
    return "unknown"

def _occupants(text):
    m=re.search(r"([1-9一二两三四五六七八九])(?:个)?人",text)
    if not m:return None
    return int(m[1]) if m[1].isdigit() else {"一":1,"二":2,"两":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9}[m[1]]

def _budget(source, own):
    result=_empty_budget();full="；".join(c["text"] for c in own)
    occupants=_occupants(full);carry=False
    for c in own:
        v=c["text"]
        if _HISTORICAL.search(v) and not _CURRENT.search(v):continue
        cue=re.search(r"预算|(?:房租|租金|月租|年租).{0,12}(?:最多|上限|不超|不能超过|以内)",v)
        if cue:carry=True
        if not cue and not (carry and re.search(r"最多|上限|改为|而是",v)):continue
        if "收入" in v and "预算" not in v:continue
        begin=cue.start() if cue else 0
        for m in _MONEY.finditer(v,begin):
            left=v[begin:m.start()]
            neg=list(re.finditer(r"不是|不考虑|并非",left));revision=list(re.finditer(r"而是|改为|改到|现在",left))
            if neg and (not revision or neg[-1].start()>revision[-1].start()):continue
            lo=_amount(m["lo"]);hi=_amount(m["hi"]) if m["hi"] else lo
            if lo is None or hi is None or lo>hi:continue
            near=v[max(begin,m.start()-18):m.end()+12]
            cap=bool(re.search(r"最多|上限|不超|不能超过|以内|以下",near))
            kind="range" if m["hi"] else "upper_cap" if cap else "approximate"
            period=_period(v)
            scope="all_in" if re.search(r"全包|包水电|包网|包物业|含水电|总入住",v) else "deposit" if "押金" in v and "房租" not in v else "rent_only" if re.search(r"房租|月租|租金|年租|租房预算",v) else "unknown"
            allocation="whole_unit" if re.search(r"整套|整租",v) or "不是人均" in v else "per_person" if re.search(r"每人|人均|各自",v) else "whole_unit" if re.search(r"整套|共同整租",full) else "unknown"
            currency=_currency(v,full)
            constraint={"raw_quote":c["quote"],"amount_min":lo if kind=="range" else None,"amount_max":hi,
                        "limit_kind":kind,"currency":currency,"period":period,"cost_scope":scope,
                        "allocation":allocation,"occupants":occupants,"monthly_unit_cap":None,
                        "annual_equivalent_monthly":None,"formula":None,"normalization_label":"User-provided",
                        "evidence":_evidence(source,c,"BUDGET","客户预算原话，计价口径独立于意向")}
            if currency=="CNY" and scope=="rent_only" and kind in ("upper_cap","range"):
                if period=="month" and allocation=="whole_unit":constraint["monthly_unit_cap"]=hi
                if period=="month" and allocation=="per_person" and occupants and re.search(r"共同整租|整租|合租",full) and re.search(r"每人|各自",v):
                    constraint["monthly_unit_cap"]=hi*occupants;constraint["formula"]=f"{hi}*{occupants}={hi*occupants}";constraint["normalization_label"]="Calculated"
                if period=="year" and allocation=="whole_unit":
                    avg=Decimal(str(hi))/12;constraint["annual_equivalent_monthly"]=int(avg) if avg==avg.to_integral_value() else float(round(avg,2))
                    constraint["formula"]=f"{hi}/12={constraint['annual_equivalent_monthly']}";constraint["normalization_label"]="Calculated"
            result["constraints"].append(constraint)
            # One numeric budget per clause; different time/cost limits remain separate.
            break
    constraints=result["constraints"]
    if not constraints:return result
    monthly=[c for c in constraints if c["period"]=="month"]
    selected=(monthly or constraints)[-1]
    for key in ("raw_quote","amount_min","amount_max","limit_kind","currency","period","cost_scope","allocation","occupants"):
        result[key]=selected[key]
    caps=[c["monthly_unit_cap"] for c in constraints if c["monthly_unit_cap"] is not None]
    result["monthly_unit_rent_cap"]=min(caps) if caps else None
    annual=[c["annual_equivalent_monthly"] for c in constraints if c["annual_equivalent_monthly"] is not None]
    result["annual_equivalent_monthly"]=min(annual) if annual else None
    result["normalization_formula"]=selected["formula"];result["normalization_label"]=selected["normalization_label"]
    result["evidence"]=[c["evidence"] for c in constraints]
    result["missing_fields"]=[key for key in ("currency","period","cost_scope","allocation") if result[key] in (None,"unknown")]
    if selected["allocation"]=="per_person" and selected["monthly_unit_cap"] is None:result["missing_fields"].append("joint_allocation_or_occupants")
    result["comparable"]=bool(result["monthly_unit_rent_cap"] is not None and not result["missing_fields"])
    return result

def _income(source, own):
    full="；".join(c["text"] for c in own)
    for c in own:
        v=c["text"]
        if _HISTORICAL.search(v) and not _CURRENT.search(v):continue
        if re.search(r"家庭|夫妻|我们家|爸妈|朋友|老板|收入证明|发票|税点",v):continue
        cue=re.search(r"(?:我(?:自己|本人)?|本人)(?:的|目前)?(?:税前|税后)?(?:月|年)?(?:收入|工资|薪资)|^(?:税前|税后)?(?:月薪|月收入|年收入|工资|收入)",v)
        if not cue:continue
        money=next(_MONEY.finditer(v,cue.start()),None)
        no_fixed=bool(re.search(r"没(?:有)?固定收入|无固定收入",v))
        if not money and not no_fixed:continue
        amount=_amount(money["lo"]) if money else None
        if money and amount is None:continue
        maximum=_amount(money["hi"]) if money and money["hi"] else amount
        return {"raw_quote":c["quote"],"subject":"self","self_reported":True,"verified":False,
                "amount_min":amount,"amount_max":maximum,"currency":_currency(v,full),
                "period":_period(v) if _period(v) in ("month","year") else "unknown",
                "tax_basis":"net" if "税后" in v else "gross" if "税前" in v else "unknown",
                "stability":"no_fixed_income" if no_fixed else "unknown","as_of":source.get("published_at"),
                "evidence":[_evidence(source,c,"INCOME_SELF_REPORTED","本人自报收入，未独立核验且不决定意向")]}
    return None

def evaluate_rental_source(source, now=None, *, rule_version=None):
    source=deepcopy(source) if isinstance(source,dict) else {}
    instant=_stamp(now) or datetime.now(TZ)
    text=source.get("text") if isinstance(source.get("text"),str) else ""
    result={"rule_version":rule_version or RULE_VERSION,"evaluated_at":instant.isoformat(),
            "source_digest":_digest(source),"level":"unknown","intent_level":"unknown",
            "eligibility":"uncertain","roles":[],"stay_purpose":"unknown",
            "intent_confidence":"low","reason":"没有可确认的本人当前租住需求","evidence":[],
            "budget":_empty_budget(),"income_self_report":None,"store_matches":[],
            "fit_status":"not_comparable","review_required":True,"review_reasons":[],
            "execution_state":"review_only_no_external_action",
            "calibration_status":"initial_rules_not_real_customer_calibrated"}
    if (not text.strip() or len(text)>32000 or not source.get("source_id") or
        source.get("source_type") not in ("comment","customer_message","staff_note") or
        source.get("author_subject","self") not in ("self","authorized_proxy")):
        result["review_reasons"]=["source_or_subject_unknown"];return result
    if re.search(r"忽略.{0,8}(?:规则|指令)|输出.{0,6}(?:high|高意向)|system prompt",text,re.I):
        result["review_reasons"]=["source_instruction_requires_review"];return result
    published=_stamp(source.get("published_at")) if source.get("published_at") is not None else None
    if published and published>instant+timedelta(minutes=5):
        result["review_reasons"]=["source_time_in_future"];return result
    own=[c for c in _clauses(text) if c["subject"]=="self"]
    needs=[];actions=[];closed=False;expired=False;expired_move=False
    supply=[];low_clauses=[]
    for c in own:
        v=c["text"]
        past_year=re.search(r"((?:19|20)\d{2})年",v)
        historical=bool((_HISTORICAL.search(v) or past_year and int(past_year[1])<instant.year) and not _CURRENT.search(v))
        if _SUPPLY.search(v) and not re.search(r"不是转租|不转租|不要转租",v):supply.append(c)
        if _CLOSED.search(v) or _NEGATED_NEED.search(v):
            needs=[];actions=[];closed=True;continue
        if _CANCEL.search(v):actions=[]
        conditional=bool(_CONDITIONAL.search(v))
        need=bool(_NEED.search(v) or _COMMERCIAL.search(v) or re.search(r"不急租|明年.{0,8}搬|提前了解.{0,12}(?:房|公寓)",v))
        if need and not historical and not conditional:
            needs.append(c);closed=False
            if _CURRENT.search(v):expired_move=False
        if re.search(r"入住|搬入|起租|搬家",v):
            move_days=_event_days(v,published)
            if move_days and move_days[1]<instant.date():expired_move=True
        if _LOW.search(v) and not historical and not conditional:low_clauses.append(c)
        valid,days=_valid_action(c,published,instant)
        if valid:actions.append(c)
        elif days and days[1]<instant.date():expired=True
    if published and instant-published>timedelta(days=30) and not actions:
        result["review_reasons"]=["stale_source_requires_reconfirmation"];return result
    if expired_move or expired and published and published.date()<instant.date():
        result["review_reasons"]=["expired_action_requires_reconfirmation"];return result
    if not needs:
        if supply or closed or re.search(r"求酒店|酒店推荐|景点怎么走|餐厅推荐|门票",text):
            result.update(eligibility="non_target",roles=["housing_supplier"] if supply else ["tourist_hotel_seeker"] if re.search(r"求酒店|酒店推荐",text) else [],reason="供房/其他用途或租住需求已解决、否定")
        result["review_reasons"]=["no_personal_rental_need"];return result
    relevant="；".join(c["text"] for c in own)
    specificity=bool(_ROOM.search(relevant) or _PLACE.search(relevant))
    level="high" if actions and specificity else "low" if low_clauses else "medium"
    result["budget"]=_budget(source,own)
    result["income_self_report"]=_income(source,own)
    result.update(level=level,intent_level=level,eligibility="rental_seeker",roles=["rental_seeker"]+(["housing_supplier"] if supply else []),
                  stay_purpose="short_stay_apartment" if re.search(r"(?:住|短租).{0,3}(?:两晚|三晚|\d+晚|几天)",relevant) else "residential_rental",
                  reason="本人明确租住需求"+("并有当前具体推进动作" if level=="high" else "，当前明确只了解/远期计划" if level=="low" else "，尚无可确认的当前具体推进动作"),
                  evidence=[_evidence(source,c,"ROLE_SEEK","本人租住需求") for c in needs]+[_evidence(source,c,"VIEWING_ACTION" if _VIEW.search(c["text"]) else "CONTRACT_ACTION","具体推进动作") for c in actions],
                  review_reasons=["property_price_and_store_mapping_unverified"]+(["source_published_time_unknown"] if published is None else []))
    return result


class RentalAssessmentPermissionError(PermissionError):
    code="RENTAL_ASSESSMENT_FORBIDDEN"
    status=403
    mutation_committed=False


class RentalAssessmentService:
    """Server-only persisted-source seam; no client text and no provider calls.

    store_id is trusted Backend context, not an identity grant. The original
    Core remains the task/account authority. Historical unbound rows remain
    explicitly unknown. Version+source hashes retain prior sidecar assessments.
    """
    def __init__(self,core,company,*,rule_version=None,store_id=None,clock=None):
        company=deepcopy(company) if isinstance(company,dict) else {}
        managed=company.get("managedWorkspace") or {}
        if (company.get("id")!="fangyu-apartment-client" or company.get("edition")!="customer"
            or company.get("personalMode") is not False or company.get("authMode")!="managed"
            or not isinstance(managed.get("environment_id"),str) or not managed["environment_id"]):
            raise RentalAssessmentPermissionError("租房判断需要可信方隅企业配置")
        if store_id is not None and (not isinstance(store_id,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}",store_id)):
            raise RentalAssessmentPermissionError("门店范围格式无效")
        version=rule_version or RULE_VERSION
        if not isinstance(version,str) or not version or len(version)>180:
            raise ValueError("规则版本格式无效")
        self.core=core;self.company=company;self.store_id=store_id;self.rule_version=version
        self.clock=clock or (lambda:datetime.now(TZ))
        self.tenant="cloud-"+hashlib.sha256((managed["environment_id"]+"\n"+company["id"]).encode()).hexdigest()[:24]

    def _get(self,db,entity,ident):
        if not isinstance(ident,str) or not ident or len(ident)>180:return None
        row=db.execute("SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?",(entity,ident,self.tenant)).fetchone()
        return json.loads(row["body"]) if row else None

    def _actor(self,db,user):
        current=self._get(db,"users",user.get("id")) if isinstance(user,dict) else None
        keys=("id","tenant_id","username","role","cloud_bound")
        if (not current or current.get("disabled") or current.get("cloud_bound") is not True
            or current.get("development_local_only") is True or current.get("role") not in ("operator","admin")
            or current.get("tenant_id")!=self.tenant or not current.get("username")
            or any(current.get(k)!=user.get(k) for k in keys)):
            raise RentalAssessmentPermissionError("当前员工身份或企业范围已变化")
        return current

    def _scope(self,db,user,lead):
        if (not isinstance(lead,dict) or lead.get("tenant_id")!=self.tenant
            or lead.get("cloud_owner") not in (None,"",user["username"])):
            raise RentalAssessmentPermissionError("只能判断当前员工自己的来源评论")
        task=self._get(db,"tasks",lead.get("task_id"))
        if not task:
            if not lead.get("cloud_owner"):
                raise RentalAssessmentPermissionError("历史来源无可核实员工归属或来源任务")
            return None,None,["task_identity_unknown"]
        if task.get("tenant_id")!=self.tenant or task.get("cloud_owner")!=user["username"]:
            raise RentalAssessmentPermissionError("来源任务不属于当前员工")
        try:self.core._task_access(user,task,self.tenant)
        except (ValueError,PermissionError) as exc:
            raise RentalAssessmentPermissionError("原任务或账号权限已变化") from exc
        context=self._get(db,"rental_task_context_v1",task["id"])
        if context and (context.get("owner")!=user["username"] or context.get("tenant_id")!=self.tenant):
            raise RentalAssessmentPermissionError("来源判断上下文归属无效")
        values=[v for v in (task.get("store_id"),lead.get("store_id"),(context or {}).get("store_id")) if v not in (None,"")]
        if any(not isinstance(v,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}",v) for v in values):
            return task,None,["store_identity_unknown"]
        if values and (len(set(values))!=1 or self.store_id is not None and values[0]!=self.store_id):
            raise RentalAssessmentPermissionError("来源不属于当前门店范围")
        # A source-only label is insufficient to claim its unbound historical task.
        bound=bool(task.get("store_id") or (context or {}).get("store_id"))
        issues=[] if bound and values else ["unverified_historical_scope"]
        if not lead.get("cloud_owner"):issues.insert(0,"legacy_lead_owner_unverified")
        return task,values[0] if values and bound else None,issues

    def _source(self,lead,task,store_id,issues):
        source={"text":lead.get("text") if isinstance(lead.get("text"),str) else "",
                "source_id":lead.get("source_id"),"source_type":lead.get("source_type"),
                "author_subject":"self" if lead.get("author_id") or lead.get("author") else "unclear",
                "published_at":lead.get("published_at"),"collected_at":lead.get("created_at"),"history":[],
                "persisted_scope":{"tenant_id":self.tenant,"owner":lead.get("cloud_owner"),
                                   "lead_id":lead.get("id"),"task_id":(task or {}).get("id"),
                                   "store_id":store_id,"issues":issues}}
        return source

    @staticmethod
    def _unknown(source,version,instant,issue):
        result=evaluate_rental_source(source,now=instant,rule_version=version)
        result.update(level="unknown",intent_level="unknown",eligibility="uncertain",intent_confidence="unknown",
                      reason="来源、范围或当前有效性尚未核实，需重新判断；旧等级仅保留历史",
                      evidence=[],review_required=True)
        result["review_reasons"]=list(dict.fromkeys([issue,*result.get("review_reasons",[])]))
        return result

    def _ident(self,actor,lead_id,source):
        return _digest(["rental-assessment-v1",self.tenant,actor["username"],lead_id,self.rule_version,_digest(source)])

    def _assess_rows(self,db,actor,rows):
        instant=_stamp(self.clock()) or datetime.now(TZ)
        summary={"assessed":0,"written":0,"reused":0,"levels":{k:0 for k in ("high","medium","low","unknown")},
                 "rule_version":self.rule_version,"scope":"employee-local-comment-assessments",
                 "historical_grades_rewritten":False,"provider_requests_started":False}
        for lead in rows:
            if lead.get("source_type")!="comment":continue
            task,store_id,issues=self._scope(db,actor,lead)
            source=self._source(lead,task,store_id,issues)
            result=self._unknown(source,self.rule_version,instant,issues[0]) if issues else evaluate_rental_source(source,now=instant,rule_version=self.rule_version)
            result.update(lead_id=lead["id"],task_id=(task or {}).get("id"),store_id=store_id,
                          scope="employee-local-comment-assessments")
            ident=self._ident(actor,lead["id"],source)
            previous=self._get(db,ENTITY,ident)
            # Check identity/source again while holding the same Core lock/transaction.
            current=self._get(db,"leads",lead["id"])
            fresh_actor=self._actor(db,actor)
            fresh_task,fresh_store,fresh_issues=self._scope(db,fresh_actor,current)
            if _digest(self._source(current,fresh_task,fresh_store,fresh_issues))!=result["source_digest"]:
                raise RentalAssessmentPermissionError("来源或门店范围在判断期间已变化")
            comparable=lambda a:{k:v for k,v in a.items() if k!="evaluated_at"}
            if previous and comparable(previous.get("assessment",{}))==comparable(result):
                summary["reused"]+=1
            else:
                record={"id":ident,"tenant_id":self.tenant,"owner":actor["username"],"lead_id":lead["id"],
                        "task_id":(task or {}).get("id"),"store_id":store_id,"rule_version":self.rule_version,
                        "source_digest":result["source_digest"],"created_at":instant.isoformat(),"assessment":result}
                db.execute("INSERT OR REPLACE INTO records VALUES(?,?,?,?)",(ENTITY,ident,self.tenant,json.dumps(record,ensure_ascii=False,allow_nan=False)))
                summary["written"]+=1
            summary["assessed"]+=1;summary["levels"][result["intent_level"]]+=1
        summary["unknown"]=summary["levels"]["unknown"]
        return summary

    def assess_task(self,user,task_id):
        with self.core.lock,self.core.store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            actor=self._actor(db,user);task=self._get(db,"tasks",task_id)
            if not task or task.get("cloud_owner")!=actor["username"]:
                raise RentalAssessmentPermissionError("任务不存在或不属于当前员工")
            try:self.core._task_access(actor,task,self.tenant)
            except (ValueError,PermissionError) as exc:raise RentalAssessmentPermissionError("任务权限已变化") from exc
            rows=[json.loads(r["body"]) for r in db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=?",("leads",self.tenant)).fetchall()]
            rows=[r for r in rows if r.get("task_id")==task_id and r.get("cloud_owner") in (None,"",actor["username"])]
            return self._assess_rows(db,actor,rows)

    def assess_visible(self,user):
        with self.core.lock,self.core.store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            actor=self._actor(db,user);visible=[]
            for r in db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=?",("leads",self.tenant)).fetchall():
                lead=json.loads(r["body"])
                if lead.get("cloud_owner") not in (None,"",actor["username"]):continue
                try:self._scope(db,actor,lead)
                except RentalAssessmentPermissionError:continue
                visible.append(lead)
            return self._assess_rows(db,actor,visible)

    def read_assessment(self,user,lead_id):
        with self.core.lock,self.core.store.connect() as db:
            actor=self._actor(db,user);lead=self._get(db,"leads",lead_id)
            task,store_id,issues=self._scope(db,actor,lead)
            source=self._source(lead,task,store_id,issues);instant=_stamp(self.clock()) or datetime.now(TZ)
            if issues:return self._unknown(source,self.rule_version,instant,issues[0])
            record=self._get(db,ENTITY,self._ident(actor,lead_id,source))
            if record is None:
                rows=db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=?",(ENTITY,self.tenant)).fetchall()
                if any((v:=json.loads(r["body"])).get("lead_id")==lead_id and v.get("owner")==actor["username"] for r in rows):
                    return self._unknown(source,self.rule_version,instant,"source_or_rule_changed_requires_refresh")
                return None
            if (record.get("owner")!=actor["username"] or record.get("lead_id")!=lead_id
                or record.get("rule_version")!=self.rule_version or record.get("source_digest")!=_digest(source)):
                return self._unknown(source,self.rule_version,instant,"assessment_record_unverified")
            fresh=evaluate_rental_source(source,now=instant,rule_version=self.rule_version)
            if fresh["intent_level"]!=record["assessment"].get("intent_level"):
                return self._unknown(source,self.rule_version,instant,"assessment_time_window_changed")
            return deepcopy(record["assessment"])
