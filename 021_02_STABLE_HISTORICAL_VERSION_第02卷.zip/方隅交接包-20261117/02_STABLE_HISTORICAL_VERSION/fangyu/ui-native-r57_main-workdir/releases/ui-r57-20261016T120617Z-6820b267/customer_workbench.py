"""Employee-local customer history over preserved, pinned r55 modules.

This interface performs local reads and in-memory XLSX generation only. Its
store context identifies the authenticated employee's current cloud context;
legacy history without a store binding is never relabelled as verified store data.
"""
import base64
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import io
import re
import sys
from pathlib import Path
from types import SimpleNamespace

from core import CoreError
from core.service_plans import ProductAccessError, require_feature

COMPANY_ID = 'fangyu-apartment-client'
SCOPE = 'employee-local-history'
DEPENDENCY_SHA256 = {
    'assistant/customer_list.py':'96D2F8206409408820CD98396B92A456E499B294FDA522B7EE14ED931AA3DE66',
    'assistant/business.py':'9329EE393D8C6CC4AFD48843C441E7501A30900F366C90586E1BCBDCD97F81BD',
    'assistant/ai_workflow.py':'9EF2B344F1EC2ED94ED3283D9AF9E63DAB82834AC4280FC7358131DD561CF12A',
    'xlsxwriter/__init__.py':'F81B0587E6FC5A979724A31CD288753E722D4EA29D0BF2310B5F50FE93BF13D3',
    'xlsxwriter/workbook.py':'4B4A3820B4877EF31920CE13630D66AABF4AED5E9F9C7A7A7E27694276B7E2F9',
    'xlsxwriter/worksheet.py':'DB89556547C80594596BC9E264AF9B9AC4453713748CFC7D09B052DFA05AA1AD',
}
FILTERS = frozenset(('all','high','medium','pending','replied'))
SORTS = frozenset(('intent','reply','time','post'))
LEVELS = {'super_high':('超高意向',3,'urgent'), 'high':('高意向',2,'high'),
          'medium':('中意向',1,'medium'), 'low':('低意向',0,'low'),
          'very_low':('极低意向',-1,'muted')}
CONTACT_LABELS = {'sent':'已回复', 'external_reported':'已登记联系',
    'unknown':'发送结果待确认', 'copied':'已复制，未确认发送',
    'legacy_sent_unverified':'历史发送记录未确认', 'uncontacted':'未回复'}
PLATFORMS = {'xiaohongshu':'小红书','douyin':'抖音','zhihu':'知乎',
    'wechat_channels':'视频号','bilibili':'哔哩哔哩','kuaishou':'快手','weibo':'微博'}
QUERY_FIELDS = frozenset(('query','filter','sort','sortDirection','page','pageSize'))
KEY = re.compile(r'[0-9a-f]{64}\Z')
STORE = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')


class CustomerWorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


def _fail(code, message, status=400):
    raise CustomerWorkbenchError(code, message, status)


def _text(value, limit=2000):
    if not isinstance(value, str):
        return ''
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)[:limit]


def _epoch(value):
    if type(value) in (int,float):
        return value if 0 <= value <= 253402300799 else 0
    if not isinstance(value,str):
        return 0
    try:
        parsed = datetime.fromisoformat(value.replace('Z','+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.timestamp()
    except (ValueError, OverflowError, OSError):
        return 0


def _time(value):
    stamp = _epoch(value)
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat(timespec='seconds') if stamp else ''


def _load_preserved(path, name):
    module = sys.modules.get(name)
    if module is not None:
        if Path(module.__file__).resolve() != path.resolve():
            _fail('CUSTOMER_DEPENDENCY', '客户历史组件来源需核对', 503)
        return module
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return module


class CustomerWorkbench:
    def __init__(self, core, company, project_root):
        self.core, self.company = core, deepcopy(company)
        managed = self.company.get('managedWorkspace') if isinstance(self.company,dict) else None
        if (not isinstance(self.company,dict) or self.company.get('id') != COMPANY_ID
                or self.company.get('edition') != 'customer' or self.company.get('personalMode') is not False
                or self.company.get('authMode') != 'managed' or not isinstance(managed,dict)
                or not isinstance(managed.get('environment_id'),str) or not managed['environment_id']):
            _fail('CUSTOMER_CONFIG', '客户历史需要当前企业员工配置', 503)
        self.tenant = 'cloud-'+hashlib.sha256((managed['environment_id']+'\n'+COMPANY_ID).encode()).hexdigest()[:24]
        self.source = Path(project_root).resolve()/'work/ui-runtime-r55/src'
        for relative, expected in DEPENDENCY_SHA256.items():
            path = self.source/relative
            try:
                digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
            except OSError:
                _fail('CUSTOMER_DEPENDENCY', '客户历史组件暂不可读', 503)
            if digest != expected:
                _fail('CUSTOMER_DEPENDENCY', '客户历史组件校验未通过', 503)
        # Load the exact old implementation without replacing the optional
        # platform runtime's separately assembled assistant.business module.
        self.history_type = _load_preserved(self.source/'assistant/customer_list.py',
            'assistant._r57_customer_history').CustomerHistory
        self.access_function = _load_preserved(self.source/'assistant/business.py',
            'assistant._r57_customer_business').BusinessExecutor._lead_access

    def _actor(self, user, store_id):
        if not isinstance(user,dict) or not isinstance(store_id,str) or not STORE.fullmatch(store_id):
            _fail('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        saved = self.core.store.get('users', user.get('id'))
        if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('development_local_only') is True or saved.get('role') != 'operator'
                or saved.get('tenant_id') != self.tenant
                or any(saved.get(key) != user.get(key) for key in ('id','tenant_id','username','role','cloud_bound'))
                or not isinstance(saved.get('username'),str) or not saved['username']):
            _fail('AUTH_REQUIRED', '员工身份已变化，请重新登录', 401)
        return saved, {'username':saved['username'], 'storeId':store_id}

    def _history(self, user, store_id):
        access = SimpleNamespace(core=self.core, tenant=self.tenant)
        def lead_access(actor, lead, task_cache=None):
            self.access_function(access, actor, lead, task_cache=task_cache)
            # r55 does not create a store field for historical leads/tasks.
            # Explicit bindings, if present, must never be silently reassigned.
            task = (task_cache or {}).get(lead.get('task_id')) or {}
            for record in (lead, task):
                explicit = record.get('store_id')
                if explicit not in (None,'') and explicit != store_id:
                    raise CoreError('此客户来源不属于当前门店上下文')
        return self.history_type(self.core,self.tenant,user['username'],lead_access=lead_access)

    def _options(self, data, export=False):
        if not isinstance(data,dict) or set(data)-QUERY_FIELDS-({'selectedIds'} if export else set()):
            _fail('INVALID_INPUT', '客户筛选参数无效')
        query = data.get('query','')
        selected, sort, direction = data.get('filter','all'),data.get('sort','intent'),data.get('sortDirection','desc')
        page, size = data.get('page',1),data.get('pageSize',20)
        if (not isinstance(query,str) or len(query)>100
                or not isinstance(selected,str) or selected not in FILTERS
                or not isinstance(sort,str) or sort not in SORTS
                or not isinstance(direction,str) or direction not in ('asc','desc')
                or type(page) is not int or not 1<=page<=1000000
                or type(size) is not int or size not in (20,50)):
            _fail('INVALID_INPUT', '客户筛选、排序或分页参数无效')
        return {'query':query.strip().casefold(),'filter':selected,'sort':sort,
                'sortDirection':direction,'page':page,'pageSize':size}

    @staticmethod
    def _representative_source(person):
        """A quoted comment, judgement, and source must come from one record."""
        comments = person.get('comments') or []
        comment = next((comment for comment in comments
            if comment['lead_id']==person.get('representative_intent_lead_id')), None)
        comment = comment or (comments[0] if comments else None)
        if comment is None:
            post = person.get('primary_post') or {}
            return {}, person.get('latest_comment') or '', post.get('title') or '帖子标题未提供', post.get('note_url') or ''
        lead = comment.get('lead') or {}
        post = next((post for post in person.get('posts',[])
                     if post.get('post_key')==comment.get('post_key')),{})
        return (comment.get('intent') or {}, comment.get('text') or '',
                lead.get('content_title') or lead.get('title') or post.get('title') or '帖子标题未提供',
                comment.get('note_url') or post.get('note_url') or '')

    def _project(self, person, detail=False):
        comments = person.get('comments') or []
        intent, quote, post_title, post_url = self._representative_source(person)
        level_key = self.history_type._top_level(person)
        graded = LEVELS.get(level_key)
        label,rank,tone = graded if graded else (
            '不相关' if level_key=='unrelated' else '未分级',None,'muted')
        facts = intent.get('key_info') if isinstance(intent.get('key_info'),list) else []
        need = ' · '.join(_text(fact.get('value'),80) for fact in facts
            if isinstance(fact,dict) and fact.get('type') in ('budget','move_in','commute','room_type','location')
            and isinstance(fact.get('value'),str) and fact['value'].strip())
        evidence = [_text(value,500) for value in (intent.get('evidence') or [])
                    if isinstance(value,str) and value.strip()] if isinstance(intent.get('evidence'),list) else []
        reason = _text(intent.get('reason'),500)
        if reason and reason not in evidence:
            evidence.insert(0,reason)
        state = person['contact_state']
        replied = state=='sent'
        result = {'id':person['author_key'], 'name':_text(person.get('nickname'),300) or '昵称未提供',
            'need':need or '需求信息尚未整理', 'level':label, 'rank':rank, 'tone':tone,
            'contactAt':_time(person.get('last_contact_at')), 'contactLabel':CONTACT_LABELS.get(state,'联系状态待确认'),
            'contactState':state, 'replied':replied, 'channel':PLATFORMS.get(person['platform'],'来源平台未提供'),
            'platform':person['platform'], 'postTitle':_text(post_title,500),
            'postUrl':_text(post_url,2048), 'quote':_text(quote,32000),
            'nextStep':'查看联系记录' if replied else '核对原评论与发送结果' if state=='unknown' else '查看需求后人工回复',
            'evidence':evidence[:9]}
        if detail:
            result['comments'] = [{'id':comment['lead_id'], 'text':_text(comment.get('text'),32000),
                'publishedAt':_text(comment.get('published_at'),100),
                'postTitle':_text((comment.get('lead') or {}).get('content_title') or (comment.get('lead') or {}).get('title'),500),
                'postUrl':_text(comment.get('note_url'),2048)} for comment in comments]
        return result

    def _matching(self, user, store_id, options):
        history = self._history(user,store_id)
        people = history._build(user)
        rows = []
        query = options['query']
        for person in people.values():
            item = self._project(person)
            if query and query not in (' '.join((item['name'],item['need'],item['channel'],item['level'],
                    str(person.get('author_id') or ''),*(str(comment.get('text') or '')+' '+str(comment.get('note_url') or '')
                    for comment in person['comments'])))).casefold():
                continue
            rows.append((person,item))
        stats = {'total':len(rows), 'high':sum(item['rank'] is not None and item['rank']>=2 for _,item in rows),
                 'replied':sum(item['replied'] for _,item in rows), 'handoff':None}
        selected = options['filter']
        rows = [(person,item) for person,item in rows if selected=='all'
            or selected=='high' and item['rank'] is not None and item['rank']>=2
            or selected=='medium' and item['rank']==1
            or selected=='pending' and not item['replied']
            or selected=='replied' and item['replied']]
        # Every sort applies to the full permitted result before paging.
        rows.sort(key=lambda pair:pair[1]['id'])
        rows.sort(key=lambda pair:_epoch(pair[0].get('latest_published_at') or pair[0].get('last_comment_at')),reverse=True)
        sort = options['sort']
        def key(pair):
            person,item = pair
            if sort=='intent': return item['rank'] if item['rank'] is not None else -2
            if sort=='reply': return (item['replied'],_epoch(person.get('last_contact_at')))
            if sort=='time': return _epoch(person.get('latest_published_at') or person.get('last_comment_at'))
            return (item['platform'],item['postTitle'].casefold())
        rows.sort(key=key, reverse=options['sortDirection']=='desc')
        return rows, stats

    def list(self, user, store_id, data):
        options = self._options(data)
        with self.core.lock:
            actor, public = self._actor(user,store_id)
            rows, stats = self._matching(actor,store_id,options)
            total = len(rows)
            pages = (total+options['pageSize']-1)//options['pageSize']
            page = min(options['page'], max(1,pages))
            start = (page-1)*options['pageSize']
            return {'actor':public,'scope':SCOPE,'items':[item for _,item in rows[start:start+options['pageSize']]],
                'stats':stats,'total':total,'page':page,'pageSize':options['pageSize'],'pages':pages}

    def detail(self, user, store_id, ident):
        if not isinstance(ident,str) or not KEY.fullmatch(ident):
            _fail('INVALID_INPUT','客户编号无效')
        with self.core.lock:
            actor, public = self._actor(user,store_id)
            try:
                person = self._history(actor,store_id).customer_detail(ident,actor)
            except CoreError:
                _fail('CUSTOMER_UNAVAILABLE','客户不存在或不在当前可见范围',404)
            return {'actor':public,'scope':SCOPE,'id':ident,'item':self._project(person,detail=True)}

    def export(self, user, store_id, data):
        options = self._options(data,export=True)
        selected = data.get('selectedIds')
        if selected is not None and (not isinstance(selected,list) or not 1<=len(selected)<=100
                or any(not isinstance(value,str) or not KEY.fullmatch(value) for value in selected)
                or len(set(selected))!=len(selected)):
            _fail('INVALID_INPUT','请选择至多100个不重复的客户编号')
        with self.core.lock:
            actor, public = self._actor(user,store_id)
            if user.get('can_export') is False or actor.get('can_export') is False:
                _fail('EXPORT_FORBIDDEN','当前员工没有导出权限',403)
            try:
                require_feature(self.company,'export')
            except ProductAccessError as error:
                _fail('EXPORT_FORBIDDEN',str(error),403)
            rows, _ = self._matching(actor,store_id,options)
            if selected is not None:
                selected_set = set(selected)
                rows = [pair for pair in rows if pair[1]['id'] in selected_set]
                if len(rows)!=len(selected_set):
                    _fail('EXPORT_SCOPE_CHANGED','所选客户已失权或不再符合筛选，本次未生成文件',409)
            if len(rows)>3000:
                _fail('EXPORT_LIMIT','当前筛选超过3000位客户，请缩小范围后导出',409)
            content = self._xlsx([self._export_item(person,item) for person,item in rows])
            return {'actor':public,'scope':SCOPE,'filename':'方隅客户清单.xlsx',
                'contentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'rowCount':len(rows),'dataBase64':base64.b64encode(content).decode('ascii')}

    def _export_item(self, person, display):
        """Export complete stored strings, independently of UI display limits."""
        intent, quote, post_title, post_url = self._representative_source(person)
        facts = intent.get('key_info') if isinstance(intent.get('key_info'),list) else []
        need = ' · '.join(fact['value'] for fact in facts if isinstance(fact,dict)
            and fact.get('type') in ('budget','move_in','commute','room_type','location')
            and isinstance(fact.get('value'),str) and fact['value'].strip())
        evidence = [value for value in intent.get('evidence',[]) if isinstance(value,str) and value.strip()] \
            if isinstance(intent.get('evidence'),list) else []
        reason = intent.get('reason')
        if isinstance(reason,str) and reason and reason not in evidence:
            evidence.insert(0,reason)
        return {**display,'name':person.get('nickname') or '昵称未提供',
            'postTitle':post_title,'postUrl':post_url,
            'need':need or '需求信息尚未整理',
            'quote':quote,
            'evidence':evidence}

    def _xlsx(self, items):
        writer = importlib.import_module('xlsxwriter')
        if (writer.__version__!='3.2.9'
                or Path(writer.__file__).resolve()!=(self.source/'xlsxwriter/__init__.py').resolve()):
            _fail('CUSTOMER_DEPENDENCY','本机Excel组件来源或版本需核对',503)
        columns = [('id','本机客户编号'),('name','客户昵称'),('need','已保存需求'),('level','已保存意向'),
            ('contactLabel','联系记录'),('contactAt','最近明确联系时间UTC'),('channel','平台'),
            ('postTitle','原帖标题'),('postUrl','原帖链接'),('quote','原评论'),('evidence','已保存判断依据')]
        cells = []
        for item in items:
            row = []
            for field,_ in columns:
                value = '\n'.join(item[field]) if isinstance(item[field],list) else str(item[field])
                if len(value)>32767:
                    _fail('EXPORT_CELL_LIMIT','原评论或已保存字段超过Excel单元格上限，本次未生成文件，请缩小或核对范围',409)
                try:
                    value.encode('utf-8')
                except UnicodeError:
                    _fail('EXPORT_ENCODING','原保存字段包含不可编码内容，本次未生成文件',409)
                row.append(value)
            cells.append(row)
        stream = io.BytesIO()
        workbook = writer.Workbook(stream, {'in_memory':True,'strings_to_formulas':False,
            'strings_to_urls':False,'strings_to_numbers':False})
        sheet = workbook.add_worksheet('客户清单')
        header = workbook.add_format({'bold':True,'text_wrap':True})
        body = workbook.add_format({'text_wrap':True,'valign':'top'})
        for column,(_,label) in enumerate(columns):
            sheet.write_string(0,column,label,header)
        for row,values in enumerate(cells,1):
            for column,value in enumerate(values):
                if sheet.write_string(row,column,value,body)!=0:
                    workbook.close()
                    _fail('EXPORT_ENCODING','Excel字段未能完整写入，本次未生成文件',409)
        sheet.freeze_panes(1,2)
        sheet.set_column(0,len(columns)-1,24)
        if items: sheet.autofilter(0,0,len(items),len(columns)-1)
        notice = workbook.add_worksheet('范围说明')
        notice.set_column(0,0,100)
        notice.write_string(0,0,'本机员工可见客户历史；历史门店归属未接入。')
        notice.write_string(1,0,'仅导出当前身份和筛选范围；复制、发送未知及旧未确认记录不计为已回复。')
        notice.write_string(2,0,'本文件不代表已对外发送、已完成交接、真实成交或到账。')
        workbook.close()
        return stream.getvalue()
