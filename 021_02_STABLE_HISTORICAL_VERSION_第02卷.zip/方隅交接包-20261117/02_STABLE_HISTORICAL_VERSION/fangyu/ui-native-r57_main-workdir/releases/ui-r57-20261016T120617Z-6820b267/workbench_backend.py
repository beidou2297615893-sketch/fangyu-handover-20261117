"""Narrow customer login and local preset preferences over the existing core.

The host pins/imports the legacy source before loading this module. Optional
platform assembly reuses the guarded employee runtime without task recovery.
"""
import hashlib
import json
import os
import re
import threading
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from core.engine import Core
from integrations import Integrations, IntegrationError, EmployeeLoginRequired
from assistant.ai_workflow import LocalAIWorkflow
from assistant.intent_rule_management import IntentRuleManagement


COMPANY_ID = 'fangyu-apartment-client'
ENTITY = 'ui_workbench_preferences_v1'
STORE_ID = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')
ACTIONS = frozenset({'bootstrap', 'login', 'logout', 'select_store', 'apply_preset'})
PLATFORM_ACTIONS = frozenset({'platform_snapshot', 'platform_prepare', 'account_create',
    'account_connect', 'account_job', 'account_cancel', 'acquisition_start',
    'acquisition_pause', 'acquisition_resume'})
CUSTOMER_ACTIONS = frozenset({'customers', 'customer_detail', 'customer_export'})
REQUEST_ENTITY = 'ui_workbench_platform_requests_v1'
SEARCH_IDS = frozenset({'precise', 'commute'})
INTENT_IDS = frozenset({'standard', 'recent'})


class WorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


class _ProfileIntegrations(Integrations):
    """Retain the verified public me projection without a second cloud request."""
    def _cloud(self, config, user, operation, **data):
        try:
            result = super()._cloud(config, user, operation, **data)
        except IntegrationError as error:
            if operation == 'me':
                # Legacy verify_identity intentionally returns None for any
                # IntegrationError. Preserve its safe HTTP classification so a
                # temporary outage cannot be mistaken for revoked authority.
                self.last_verification_error = error
            raise
        if operation == 'me':
            self.last_verified_profile = deepcopy(result.get('user'))
        return result


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _deny_cloud(*args, **kwargs):
    raise WorkbenchError('ACTION_NOT_AVAILABLE', '当前批次未接入 AI 或发送', 403)


class WorkbenchBackend:
    def __init__(self, project_root, data_dir=None, company=None, *, core_factory=Core,
                 integrations_factory=_ProfileIntegrations, workflow_factory=LocalAIWorkflow,
                 rules_factory=IntentRuleManagement, platform_factory=None, customer_factory=None):
        self.project_root = Path(project_root).resolve()
        if company is None:
            try:
                company = json.loads((self.project_root / 'work/app/company.json').read_text('utf-8-sig'))
            except (OSError, ValueError):
                raise WorkbenchError('CONFIG_UNAVAILABLE', '企业登录配置暂不可读，请联系管理员', 503) from None
        company = deepcopy(company)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        if (not isinstance(company, dict) or company.get('id') != COMPANY_ID
                or company.get('edition') != 'customer' or company.get('personalMode') is not False
                or company.get('authMode') != 'managed' or not isinstance(managed, dict)
                or not managed.get('environment_id') or not managed.get('endpoint')):
            raise WorkbenchError('CONFIG_INVALID', '此入口需要方隅客户企业登录配置', 503)
        self.company = company
        self.data_dir = Path(data_dir).resolve() if data_dir is not None else (
            Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) /
            (COMPANY_ID + 'Workspace')).resolve()
        self.lock = threading.RLock()
        self.platform_runtime = (platform_factory(project_root=self.project_root,
            data_dir=self.data_dir, company=deepcopy(company)) if platform_factory else None)
        self.core = self.platform_runtime.core if self.platform_runtime else core_factory(self.data_dir,
            self.project_root / 'work/ui-runtime-r55/src/resources', defer_startup_recovery=True)
        self.core.deployment_config = deepcopy(company)
        self.integrations = integrations_factory(self.core)
        self.customer_workbench = (customer_factory(self.core, deepcopy(company), self.project_root)
                                   if customer_factory else None)
        self.workflow = workflow_factory(self.core, _deny_cloud, company=deepcopy(company))
        self.rules_factory = rules_factory
        self.closed = False

    def close(self):
        if not self.closed:
            self.closed = True
            if self.platform_runtime is not None:
                self.platform_runtime.close()
            else:
                self.core.adapters.close()

    def _remembered(self):
        row = self.core.store.get(ENTITY, 'remembered-username')
        return row.get('username', '') if row and row.get('tenant_id') == COMPANY_ID else ''

    def _remember(self, username):
        self.core.store.put(ENTITY, {'id': 'remembered-username', 'tenant_id': COMPANY_ID,
                                    'username': username, 'updated_at': _stamp()})

    def _identity(self, token):
        user = self.core.session(token)
        if not user or user.get('cloud_bound') is not True or user.get('role') != 'operator':
            raise WorkbenchError('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        # Every API request refreshes authority; an earlier cached me result
        # cannot authorize a later store selection or local write.
        self.integrations.identity_cache.pop(user['id'], None)
        self.integrations.last_verified_profile = None
        self.integrations.last_verification_error = None
        verified = self.integrations.verify_identity(user)
        failure = self.integrations.last_verification_error
        if failure is not None and getattr(failure, 'http_status', None) not in (401, 403):
            raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                 '企业身份服务暂不可用，已保留本机登录，请稍后手动重试', 503)
        if not verified or verified.get('role') != 'operator':
            raise WorkbenchError('AUTH_REQUIRED', '员工登录已失效，请重新登录', 401)
        profile = self.integrations.last_verified_profile
        if profile is None:  # Allows a factory using the original integration.
            config = self.integrations._read(verified['tenant_id'])
            profile = self.integrations._cloud(config, verified, 'me').get('user')
        if (not isinstance(profile, dict) or profile.get('username') != verified['username']
                or profile.get('role') != 'operator' or profile.get('disabled')):
            raise WorkbenchError('AUTH_REQUIRED', '员工身份需重新核对', 401)
        return verified, profile

    def _stores(self, profile):
        ident = profile.get('store_id')
        if not isinstance(ident, str) or not STORE_ID.fullmatch(ident):
            return []
        # Cloud provides only an opaque group id. Never infer a Chinese name,
        # address, other stores or permission from the former demo choices.
        return [{'id': ident, 'name': ident, 'description': '企业已分配门店', 'region': ''}]

    def _preference_id(self, user):
        return _digest(['workbench-preset-v1', COMPANY_ID, user['tenant_id'], user['username']])

    def _load_selection(self, user, stores, db=None):
        ident = self._preference_id(user)
        if db is None:
            row = self.core.store.get(ENTITY, ident)
        else:
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (ENTITY, ident, user['tenant_id'])).fetchone()
            row = json.loads(found['body']) if found else None
        if row and (row.get('owner') != user['username'] or row.get('tenant_id') != user['tenant_id']
                    or row.get('company_id') != COMPANY_ID):
            raise WorkbenchError('PREFERENCE_SCOPE_INVALID', '门店预设归属无法核对', 409)
        revision = row.get('revision', 0) if row else 0
        if type(revision) is not int or revision < 0:
            raise WorkbenchError('PREFERENCE_INVALID', '门店预设版本无法核对', 409)
        allowed = {store['id'] for store in stores}
        selection = {'storeId': stores[0]['id'] if stores else '', 'searchPresetId': 'precise',
                     'intentPresetId': 'standard', 'revision': revision, 'applied': None, 'savedAt': None}
        if row and row.get('storeId') in allowed:
            if row.get('searchPresetId') not in SEARCH_IDS or row.get('intentPresetId') not in INTENT_IDS:
                raise WorkbenchError('PREFERENCE_INVALID', '门店预设方案无法核对', 409)
            for key in selection:
                selection[key] = deepcopy(row.get(key, selection[key]))
        return selection

    def _catalog(self, user=None):
        selected, library, policy = [], None, None
        if user:
            library = self.workflow.keyword_state(user, {'mode': 'read', 'city': '', 'area': ''})['library']
            if library:
                selected = list(library.get('selected') or [])
            policy = self.rules_factory(self.core, user['tenant_id'], user['username'],
                                       self.company).execute('intent_rules_get', {}, user)['summary']
        defaults = [word for word in self.company.get('keywords', [])
                    if isinstance(word, str) and 0 < len(word.strip()) <= 80]
        # An existing explicitly cleared selection must remain empty. Public
        # templates are offered only when no regional library exists at all.
        base = selected if library is not None else defaults or ['附近租房', '一居室租房']
        source = 'existing_keyword_selection' if library is not None else 'company_defaults' if defaults else 'general_apartment_template'
        reference = ({'id': library['id'], 'revision': library['revision'],
                      'region': deepcopy(library.get('request') or {})} if library else None)
        search = [{'id': 'precise', 'name': '精准获客', 'keywords': list(dict.fromkeys(base)),
                   'source': source, 'libraryReference': reference},
                  {'id': 'commute', 'name': '通勤拓展',
                   'keywords': list(dict.fromkeys([*base, '地铁通勤', '沿线租房'])),
                   'source': source, 'templateSupplement': ['地铁通勤', '沿线租房'],
                   'libraryReference': reference}]
        policy_ref = ({'revision': policy['revision'], 'digest': policy['digest'],
                       'validationVersion': policy['validation_version']} if policy else None)
        intent = [{'id': 'standard', 'name': '标准意向',
                   'description': '沿用既有意向判断规则，保存本机选择偏好', 'policyReference': policy_ref},
                  {'id': 'recent', 'name': '优先近期入住',
                   'description': '保存近期入住优先偏好，保留既有规则和历史评级', 'policyReference': policy_ref}]
        return {'search': search, 'intent': intent}

    def _bootstrap(self, token='', *, identity=None):
        user, profile, notice = None, None, ''
        if identity is not None:
            user, profile = identity
        elif token:
            try:
                user, profile = self._identity(token)
            except WorkbenchError as error:
                if error.code == 'AUTH_SERVICE_UNAVAILABLE':
                    raise
                notice = '登录已失效或企业身份暂未确认，请重新登录'
        stores = self._stores(profile) if profile else []
        selection = self._load_selection(user, stores) if user else {
            'storeId': '', 'searchPresetId': 'precise', 'intentPresetId': 'standard',
            'revision': 0, 'applied': None, 'savedAt': None}
        result = {'session': {'user': {'username': user['username'], 'role': user['role']}} if user else None,
                  'rememberedUsername': self._remembered(), 'stores': stores,
                  'selection': selection, 'catalog': self._catalog(user),
                  'capabilities': {'presets': bool(user and stores),
                      'platforms': self.platform_runtime is not None,
                      'customers': self.customer_workbench is not None,
                      'reason': '' if user and stores else '请管理员先分配门店' if user else '请先登录'},
                  'notice': notice}
        return result

    def _save_selection(self, user, stores, data, *, apply):
        if not stores or data.get('storeId') not in {row['id'] for row in stores}:
            raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
        catalog = self._catalog(user)
        if apply and (data.get('searchPresetId') not in SEARCH_IDS or data.get('intentPresetId') not in INTENT_IDS):
            raise WorkbenchError('PRESET_INVALID', '请选择有效的搜索和意向预设')
        if 'expectedRevision' in data and (type(data['expectedRevision']) is not int or data['expectedRevision'] < 0):
            raise WorkbenchError('REVISION_INVALID', '预设版本格式无效')
        if apply and 'expectedRevision' not in data:
            raise WorkbenchError('REVISION_REQUIRED', '应用预设前需要当前版本')
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._load_selection(user, stores, db)
            expected = data.get('expectedRevision', current['revision'])
            if expected != current['revision']:
                raise WorkbenchError('PRESET_REVISION_CONFLICT', '预设已在其他窗口更新，请重新读取', 409)
            if not apply and current['storeId'] == data['storeId']:
                return
            value = {**current, 'storeId': data['storeId'], 'revision': current['revision'] + 1,
                     'savedAt': _stamp()}
            if apply:
                value.update(searchPresetId=data['searchPresetId'], intentPresetId=data['intentPresetId'])
                search = next(row for row in catalog['search'] if row['id'] == data['searchPresetId'])
                intent = next(row for row in catalog['intent'] if row['id'] == data['intentPresetId'])
                value['applied'] = {'selectedKeywords': list(search['keywords']),
                    'keywordSource': search['source'], 'libraryReference': search['libraryReference'],
                    'templateSupplement': search.get('templateSupplement', []),
                    'policyReference': intent['policyReference'],
                    'intentPreference': intent['id'], 'appliedAt': value['savedAt'],
                    'startsCollection': False, 'changesIntentPolicy': False}
            else:
                value['applied'] = None
            record = {**value, 'id': self._preference_id(user), 'tenant_id': user['tenant_id'],
                      'owner': user['username'], 'company_id': COMPANY_ID}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (ENTITY, record['id'], record['tenant_id'], json.dumps(record, ensure_ascii=False, allow_nan=False)))

    def _platform_state(self, user, profile=None):
        actor = {'username': user['username'], 'storeId': (profile or {}).get('store_id', '')}
        if self.platform_runtime is None:
            return {'actor': actor, 'available': False, 'device': {'state': 'unavailable', 'bound': False,
                'message': '当前版本的平台后台尚未就绪'}, 'accounts': [], 'platforms': [],
                'acquisition': {'taskId': '', 'status': 'idle', 'canStart': False,
                                'canPause': False, 'canResume': False}}
        result = dict(self.platform_runtime.snapshot(user))
        result.pop('rawWorkspace', None)
        result['actor'] = actor
        result['available'] = True
        result.setdefault('capabilities', {})['timeRanges'] = ['最近7天', '最近3天', '最近30天']
        head = self.core.store.get(REQUEST_ENTITY, _digest(['head', user['tenant_id'], user['username']]))
        if head and head.get('tenant_id') == user['tenant_id'] and head.get('owner') == user['username']:
            result['lastRequest'] = {key: deepcopy(head[key]) for key in
                ('requestId', 'storeId', 'state', 'conditions', 'job', 'code', 'message') if key in head}
        return result

    def _request_record(self, user, request_id):
        ident = _digest([user['tenant_id'], user['username'], request_id])
        value = self.core.store.get(REQUEST_ENTITY, ident)
        if value and (value.get('tenant_id') != user['tenant_id'] or value.get('owner') != user['username']):
            raise WorkbenchError('REQUEST_SCOPE_INVALID', '操作回执归属无法核对', 409)
        return ident, value

    def _save_request(self, user, record):
        head = {**record, 'id': _digest(['head', user['tenant_id'], user['username']])}
        self.core.store.put_many(REQUEST_ENTITY, [record, head])

    @staticmethod
    def _public_platform_job(value):
        if not isinstance(value, dict):
            raise WorkbenchError('PLATFORM_RESPONSE_INVALID', '平台回执格式需核对', 503)
        raw = value.get('result', value)
        if not isinstance(raw, dict):
            return {}
        allowed = ('id', 'jobId', 'accountId', 'taskId', 'status', 'state', 'message',
                   'phase', 'qrUrl', 'accepted', 'maxBatches')
        return {key: deepcopy(raw[key]) for key in allowed if key in raw}

    def _platform_dispatch(self, action, data, token):
        fields = {'platform_snapshot': set(), 'platform_prepare': set(),
            'account_create': {'platform', 'name'}, 'account_connect': {'accountId'},
            'account_job': {'jobId'}, 'account_cancel': {'jobId'},
            'acquisition_start': {'storeId', 'expectedRevision', 'platform', 'accountId',
                                  'region', 'time', 'requestId'},
            'acquisition_pause': {'taskId'}, 'acquisition_resume': {'taskId'}}[action]
        if not isinstance(data, dict) or set(data) - fields:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        with self.lock:
            user, profile = self._identity(token)
            if action == 'platform_snapshot':
                return {'platform': self._platform_state(user, profile)}
            if self.platform_runtime is None:
                raise WorkbenchError('PLATFORM_UNAVAILABLE', '当前版本的平台后台尚未就绪', 503)
            if action == 'platform_prepare':
                job = self.platform_runtime.prepare(user)
            elif action == 'account_create':
                platform, name = data.get('platform'), data.get('name', '')
                if platform not in self.company.get('platforms', []):
                    raise WorkbenchError('PLATFORM_NOT_ENABLED', '企业尚未开通此平台', 403)
                if not isinstance(name, str) or len(name.strip()) > 80:
                    raise WorkbenchError('INPUT_INVALID', '请输入80字以内的账号名称')
                job = self.platform_runtime.create_account(user, {'platform': platform, 'name': name.strip()})
            elif action in ('account_connect', 'account_job', 'account_cancel', 'acquisition_pause', 'acquisition_resume'):
                key = 'accountId' if action == 'account_connect' else 'jobId' if action.startswith('account_') else 'taskId'
                ident = data.get(key)
                if not isinstance(ident, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}', ident):
                    raise WorkbenchError('INPUT_INVALID', '请先选择有效的账号或任务')
                method = {'account_connect': 'connect_account', 'account_job': 'account_job',
                    'account_cancel': 'cancel_account', 'acquisition_pause': 'pause_acquisition',
                    'acquisition_resume': 'resume_acquisition'}[action]
                job = getattr(self.platform_runtime, method)(user, {key: ident})
            else:
                stores = self._stores(profile)
                if data.get('storeId') not in {store['id'] for store in stores}:
                    raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
                selection = self._load_selection(user, stores)
                if type(data.get('expectedRevision')) is not int or data['expectedRevision'] != selection['revision']:
                    raise WorkbenchError('PRESET_REVISION_CONFLICT', '门店预设已更新，请重新读取', 409)
                applied = selection.get('applied')
                if not isinstance(applied, dict) or not applied.get('selectedKeywords'):
                    raise WorkbenchError('PRESET_REQUIRED', '请先选择并应用有搜索词的门店预设', 409)
                current = next(row for row in self._catalog(user)['search'] if row['id'] == selection['searchPresetId'])
                if (applied.get('selectedKeywords') != current['keywords']
                        or applied.get('libraryReference') != current['libraryReference']):
                    raise WorkbenchError('PRESET_STALE', '搜索词库已变化，请重新应用门店预设', 409)
                platform, account = data.get('platform'), data.get('accountId')
                if platform not in self.company.get('platforms', []):
                    raise WorkbenchError('PLATFORM_NOT_ENABLED', '企业尚未开通此平台', 403)
                if not isinstance(account, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}', account):
                    raise WorkbenchError('ACCOUNT_REQUIRED', '请先选择已连接的平台账号')
                if data.get('time') not in ('最近7天', '最近3天', '最近24小时', '最近30天'):
                    raise WorkbenchError('TIME_INVALID', '请选择有效的时间范围')
                if not isinstance(data.get('region', ''), str) or len(data.get('region', '')) > 100:
                    raise WorkbenchError('REGION_INVALID', '地区格式无效')
                request_id = data.get('requestId')
                if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}', request_id):
                    raise WorkbenchError('REQUEST_ID_REQUIRED', '请重新发起本次采集操作')
                ident, prior = self._request_record(user, request_id)
                head = self.core.store.get(REQUEST_ENTITY, _digest(['head', user['tenant_id'], user['username']]))
                if (head and head.get('tenant_id') == user['tenant_id'] and head.get('owner') == user['username']
                        and head.get('state') in ('submitted', 'unconfirmed') and head.get('requestId') != request_id):
                    raise WorkbenchError('REQUEST_UNCONFIRMED', '上次采集结果尚未确认，请先核对当前任务；不会另起重复采集', 409)
                signature = _digest(data)
                if prior:
                    if prior.get('signature') != signature:
                        raise WorkbenchError('REQUEST_CONFLICT', '同一操作编号的条件已经变化', 409)
                    if prior.get('state') == 'accepted':
                        return {'platform': self._platform_state(user, profile), 'job': deepcopy(prior['job'])}
                    if prior.get('state') == 'rejected':
                        raise WorkbenchError(prior['code'], prior['message'], prior.get('status', 409))
                    raise WorkbenchError('REQUEST_UNCONFIRMED', '上次操作尚未确认，请先查看任务状态；不会重复发起', 409)
                record = {'id': ident, 'tenant_id': user['tenant_id'], 'owner': user['username'],
                    'requestId': request_id, 'storeId': data['storeId'], 'signature': signature,
                    'conditions': {key: deepcopy(data.get(key, '')) for key in
                        ('storeId', 'platform', 'accountId', 'region', 'time', 'expectedRevision')},
                    'state': 'submitted', 'created_at': _stamp()}
                self._save_request(user, record)
                payload = {'platform': platform, 'accountId': account, 'region': data.get('region', ''),
                    'time': {'最近7天': '7d', '最近3天': '3d', '最近24小时': '24h', '最近30天': '30d'}[data['time']],
                    'keywords': list(applied['selectedKeywords']), 'intentMode': 'all'}
                try:
                    job = self._public_platform_job(self.platform_runtime.start_acquisition(user, payload))
                except Exception as error:
                    rejected = getattr(error, 'mutation_committed', None) is False and isinstance(getattr(error, 'code', None), str)
                    uncertain = {**record, 'state': 'rejected' if rejected else 'unconfirmed',
                        'code': getattr(error, 'code', 'PLATFORM_ACTION_FAILED'),
                        'status': getattr(error, 'status', 409),
                        'message': str(error) if rejected else '本次未取得成功回执，请先核对任务状态'}
                    task_id = getattr(error, 'task_id', '')
                    if isinstance(task_id, str) and re.fullmatch(r'[A-Za-z0-9_-]{1,160}', task_id):
                        uncertain['job'] = {'taskId': task_id, 'status': 'unconfirmed'}
                    self._save_request(user, uncertain)
                    if not rejected:
                        raise WorkbenchError('REQUEST_UNCONFIRMED', '采集结果尚未确认，请先核对当前任务；不会自动重复发起', 409) from None
                    raise
                self._save_request(user, {**record, 'state': 'accepted', 'job': deepcopy(job)})
            return {'platform': self._platform_state(user, profile), 'job': self._public_platform_job(job)}

    def _customer_dispatch(self, action, data, token):
        fields = {'customers': {'query', 'filter', 'sort', 'sortDirection', 'page', 'pageSize'},
            'customer_detail': {'id'},
            'customer_export': {'query', 'filter', 'sort', 'sortDirection', 'selectedIds'}}[action]
        if not isinstance(data, dict) or set(data) - fields:
            raise WorkbenchError('INPUT_INVALID', '客户查询参数无效')
        with self.lock:
            user, profile = self._identity(token)
            if self.customer_workbench is None:
                raise WorkbenchError('CUSTOMERS_UNAVAILABLE', '客户功能尚未装入当前后台，请正常重开已验证的工作台版本', 503)
            stores = self._stores(profile)
            if not stores:
                raise WorkbenchError('STORE_REQUIRED', '请管理员先分配门店', 403)
            actor = dict(user)
            # This permission is not persisted by legacy Integrations. Use the
            # fresh, trusted enterprise profile on every export.
            if 'can_export' in profile:
                actor['can_export'] = profile['can_export']
            if action == 'customers':
                return {'customers': self.customer_workbench.list(actor, stores[0]['id'], data)}
            if action == 'customer_detail':
                if set(data) != {'id'}:
                    raise WorkbenchError('INPUT_INVALID', '请选择有效客户')
                return {'customer': self.customer_workbench.detail(actor, stores[0]['id'], data['id'])}
            return {'file': self.customer_workbench.export(actor, stores[0]['id'], data)}

    def dispatch(self, action, data, token=''):
        if self.closed:
            raise WorkbenchError('BACKEND_CLOSED', '工作台已关闭', 503)
        if action in CUSTOMER_ACTIONS:
            try:
                return self._customer_dispatch(action, data, token)
            except WorkbenchError:
                raise
            except Exception as error:
                code, status = getattr(error, 'code', None), getattr(error, 'status', 400)
                if isinstance(code, str) and type(status) is int and status in (400, 401, 403, 404, 409, 422, 429, 503):
                    raise WorkbenchError(code, str(error), status) from None
                raise WorkbenchError('CUSTOMERS_UNAVAILABLE', '客户资料暂不可读，请稍后重新加载', 503) from None
        if action in PLATFORM_ACTIONS:
            try:
                return self._platform_dispatch(action, data, token)
            except WorkbenchError:
                raise
            except Exception as error:
                code = getattr(error, 'code', None)
                status = getattr(error, 'status', 400)
                if isinstance(code, str) and type(status) is int and status in (400, 401, 403, 409, 422, 429, 503):
                    raise WorkbenchError(code, str(error), status) from None
                raise WorkbenchError('PLATFORM_ACTION_FAILED', '平台操作未取得确认，请查看当前状态后再处理', 503) from None
        if action not in ACTIONS:
            raise WorkbenchError('ACTION_FORBIDDEN', '当前批次未开放此操作', 403)
        allowed = {'bootstrap': set(), 'login': {'username', 'password', 'rememberUsername'},
                   'logout': set(), 'select_store': {'storeId', 'expectedRevision'},
                   'apply_preset': {'storeId', 'searchPresetId', 'intentPresetId', 'expectedRevision'}}[action]
        if not isinstance(data, dict) or set(data) - allowed:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        with self.lock:
            try:
                if action == 'bootstrap':
                    return self._bootstrap(token)
                if action == 'login':
                    name, password = data.get('username'), data.get('password')
                    if (not isinstance(name, str) or not 0 < len(name.strip()) <= 80
                            or not isinstance(password, str) or not 0 < len(password) <= 256
                            or type(data.get('rememberUsername', False)) is not bool):
                        raise WorkbenchError('LOGIN_INPUT_INVALID', '请输入员工用户名和密码')
                    entered = self.integrations.enter({'username': name.strip(), 'password': password}, employee_only=True)
                    try:
                        identity = self._identity(entered['token'])
                    except Exception:
                        self.core.handle('logout', {'token': entered['token']})
                        raise
                    self._remember(name.strip() if data.get('rememberUsername') else '')
                    return {**self._bootstrap(identity=identity), 'token': entered['token'],
                            'cookie_max_age': entered.get('cookie_max_age')}
                if action == 'logout':
                    user = self.core.session(token)
                    cloud_unconfirmed = False
                    try:
                        if user and user.get('cloud_bound'):
                            self.integrations.handle('cloud_logout', {}, user)
                    except IntegrationError:
                        cloud_unconfirmed = True
                    finally:
                        self.core.handle('logout', {'token': token})
                    result = self._bootstrap()
                    if cloud_unconfirmed:
                        result['notice'] = '已退出本机；云端退出回执暂未确认，不会自动重试'
                    return result
                user, profile = self._identity(token)
                stores = self._stores(profile)
                self._save_selection(user, stores, data, apply=action == 'apply_preset')
                return self._bootstrap(identity=(user, profile))
            except EmployeeLoginRequired:
                raise WorkbenchError('EMPLOYEE_ONLY', '请使用企业员工账号登录；管理员请使用管理后台', 403) from None
            except IntegrationError as error:
                if getattr(error, 'http_status', None) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '账号或企业会话无效，请核对后重新登录', 401) from None
                raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                     '企业登录服务暂不可用，已保留本机状态，请稍后手动重试', 503) from None
