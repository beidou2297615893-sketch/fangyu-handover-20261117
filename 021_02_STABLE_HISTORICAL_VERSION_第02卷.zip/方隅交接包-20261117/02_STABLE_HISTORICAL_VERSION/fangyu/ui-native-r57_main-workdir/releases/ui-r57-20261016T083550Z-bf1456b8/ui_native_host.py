"""方隅界面验收用 WebView2 宿主。仅提供固化的静态文件，不加载业务 App。"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit
import uuid
import http.client

SCHEMA = 'fangyu_native_ui_release_v1'
COMPANY_ID = 'fangyu-apartment-client'
CSP = ("default-src 'self'; connect-src 'none'; img-src 'self' data:; "
       "style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; "
       "object-src 'none'; frame-src 'self'; form-action 'none'; base-uri 'none'")
MIME = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
        '.mjs': 'text/javascript; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
        '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.woff2': 'font/woff2'}


class UIHostError(RuntimeError):
    pass


def checked_path(path: Path, *, directory=False):
    """Reject links/reparse points before touching public release files."""
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise UIHostError('界面文件路径不能是链接或重定向。')
    info = path.stat()
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise UIHostError('界面目录不存在。')
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise UIHostError('界面文件必须是独立的普通文件。')
    return info


def read_public(path: Path, expected_hash=None, expected_size=None):
    before = checked_path(path)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        body = stream.read()
        ended = os.fstat(stream.fileno())
    after = checked_path(path)
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns)
    if not identity(before) == identity(opened) == identity(ended) == identity(after):
        raise UIHostError('界面文件在检查时发生变化，请重新打开。')
    digest = hashlib.sha256(body).hexdigest().upper()
    if ((expected_hash is not None and digest != expected_hash.upper())
            or (expected_size is not None and len(body) != expected_size)):
        raise UIHostError('界面文件校验失败，请重新固化界面版本。')
    return body


def verify_release(root: Path, manifest_sha256: str):
    root = Path(root).absolute()
    checked_path(root, directory=True)
    raw = read_public(root / 'RELEASE.json', manifest_sha256)
    manifest = json.loads(raw)
    if (manifest.get('schema') != SCHEMA or manifest.get('company_id') != COMPANY_ID
            or type(manifest.get('files')) is not list):
        raise UIHostError('界面版本清单不匹配。')
    files = {}
    for entry in manifest['files']:
        name = entry.get('path', '')
        relative = PurePosixPath(name)
        if (not name or relative.is_absolute() or '..' in relative.parts
                or '\\' in name or ':' in name or name in files
                or relative.as_posix() != name
                or not (name.startswith('web/') or name.startswith('resources/')
                        or name == 'ui_native_host.py')):
            raise UIHostError('界面版本包含无效文件名。')
        if (type(entry.get('size')) is not int or entry['size'] < 0
                or not isinstance(entry.get('sha256'), str)
                or len(entry['sha256']) != 64):
            raise UIHostError('界面版本文件记录不完整。')
        read_public(root / name, entry['sha256'], entry['size'])
        files[name] = entry
    required = {'ui_native_host.py', 'web/index.html', 'web/app.mjs', 'web/styles.css'}
    if not required.issubset(files):
        raise UIHostError('界面版本缺少入口或样式。')
    actual = set()
    for tree in ('web', 'resources'):
        checked_path(root / tree, directory=True)
        for item in (root / tree).rglob('*'):
            checked_path(item, directory=item.is_dir())
            if item.is_file():
                actual.add(item.relative_to(root).as_posix())
    actual.add('ui_native_host.py')
    if actual != set(files):
        raise UIHostError('界面版本文件集合与清单不一致。')
    return manifest, files


class StaticServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, root, files):
        self.root = Path(root)
        self.public = {'/' + name[4:]: entry for name, entry in files.items()
                       if name.startswith('web/') and Path(name).suffix in MIME}
        self.public['/'] = self.public['/index.html']
        self.counters = {'static': 0, 'blocked': 0}
        super().__init__(('127.0.0.1', 0), StaticHandler)


class StaticHandler(BaseHTTPRequestHandler):
    server_version = 'FangyuUI'
    sys_version = ''

    def log_message(self, *_):
        pass

    def finish_response(self, status, body=b'', content_type='text/plain; charset=utf-8'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Security-Policy', CSP)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Connection', 'close')
        self.end_headers()
        if self.command != 'HEAD' and body:
            self.wfile.write(body)
        self.close_connection = True

    def reject(self, status=403):
        self.server.counters['blocked'] += 1
        self.finish_response(status, '此界面仅提供本地演示页面。'.encode('utf-8'))

    def do_GET(self):
        expected_host = '127.0.0.1:' + str(self.server.server_port)
        if self.headers.get('Host') != expected_host or self.headers.get('Upgrade'):
            return self.reject()
        try:
            parsed = urlsplit(self.path)
            path = unquote(parsed.path, errors='strict')
        except (ValueError, UnicodeError):
            return self.reject()
        if (parsed.scheme or parsed.netloc or '\\' in path or '\x00' in path
                or any(part in ('.', '..') for part in path.split('/'))):
            return self.reject()
        if path == '/favicon.ico':
            return self.finish_response(204)
        entry = self.server.public.get(path)
        if entry is None:
            return self.reject(403 if path.startswith('/api') else 404)
        try:
            body = read_public(self.server.root / entry['path'], entry['sha256'], entry['size'])
        except (OSError, UIHostError):
            return self.finish_response(503, '界面资源校验失败，请关闭后重新打开。'.encode('utf-8'))
        self.server.counters['static'] += 1
        self.finish_response(200, body, MIME[Path(entry['path']).suffix])

    do_HEAD = do_GET
    do_POST = reject
    do_PUT = reject
    do_PATCH = reject
    do_DELETE = reject
    do_OPTIONS = reject
    do_CONNECT = reject
    do_TRACE = reject


def create_state_directory(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    checked_path(root, directory=True)
    return root


def http_self_test(root, files):
    """Exercise the real loopback handler; no window or business modules involved."""
    server = StaticServer(root, files)
    worker = threading.Thread(target=server.serve_forever,
                              kwargs={'poll_interval': .05}, daemon=True)
    worker.start()
    checks = []
    def request(method, path, expected, *, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=4)
        try:
            connection.request(method, path, headers=headers or {})
            response = connection.getresponse()
            body = response.read()
            assert response.status == expected, (method, path, response.status)
            assert response.getheader('Content-Security-Policy') == CSP
            checks.append({'method': method, 'path': path, 'status': response.status})
            return body
        finally:
            connection.close()
    try:
        body = request('GET', '/', 200)
        assert body == read_public(Path(root) / 'web/index.html')
        request('HEAD', '/app.mjs', 200)
        for path in sorted(server.public):
            request('GET', path, 200)
        request('GET', '/api', 403)
        request('POST', '/api', 403)
        request('PUT', '/index.html', 403)
        request('OPTIONS', '/', 403)
        request('GET', '/RELEASE.json', 404)
        request('GET', '/ui_native_host.py', 404)
        request('GET', '/%2e%2e/RELEASE.json', 403)
        request('GET', '/assets/%2e%2e/%2e%2e/RELEASE.json', 403)
        request('GET', '/', 403, headers={'Host': 'external.invalid'})
        request('GET', '/', 403, headers={'Upgrade': 'websocket'})
        return {'status': 'PASS', 'checks': len(checks), 'public_urls': len(server.public),
                'business_app_imported': 'app' in sys.modules,
                'native_windows_opened': 0, 'requests': checks}
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=3)


def write_status(path: Path, stage: str, **extra):
    # Only lifecycle and public DOM metrics; never form values or customer content.
    value = {'schema': 'fangyu_native_ui_status_v1', 'stage': stage, 'pid': os.getpid(),
             'time_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **extra}
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temporary, path)


DOM_PROBE = """(() => {
    const outerDoc = document.documentElement;
    const frame = document.getElementById('workspace-frame');
    const content = frame ? frame.contentDocument : document;
    const contentWindow = frame ? frame.contentWindow : window;
    const doc = content?.documentElement;
    const app = content?.getElementById('app');
    const images = [...(content?.images || [])];
    const page = content?.body?.dataset.page || '';
    const rect = frame?.getBoundingClientRect();
    const viewport = (win, element) => ({width: win?.innerWidth || 0,
        height: win?.innerHeight || 0, client_width: element?.clientWidth || 0,
        client_height: element?.clientHeight || 0, scroll_width: element?.scrollWidth || 0,
        scroll_height: element?.scrollHeight || 0, device_pixel_ratio: win?.devicePixelRatio || 0});
    return {
        page, ready_state: content?.readyState || 'loading',
        app_children: app?.children.length || 0,
        primary_present: !!content?.querySelector(page === 'login' ? '#login-form' : '.shell'),
        font_status: content?.fonts?.status || 'unsupported',
        images: {total: images.length, pending: images.filter(i => !i.complete).length,
                 failed: images.filter(i => i.complete && i.naturalWidth === 0).length},
        viewport: viewport(window, outerDoc),
        content_viewport: viewport(contentWindow, doc),
        fit: frame ? {enabled: true, x: rect.x, y: rect.y, right: rect.right,
            bottom: rect.bottom, width: rect.width, height: rect.height,
            layout_width: frame.offsetWidth, layout_height: frame.offsetHeight,
            scale_x: rect.width / frame.offsetWidth, scale_y: rect.height / frame.offsetHeight}
            : {enabled: false}
    };
})()"""


def validate_dom_report(report, expected_page):
    """Validate a read-only WebView2 probe; an HTML load alone is insufficient."""
    if not isinstance(report, dict):
        raise UIHostError('界面渲染状态不可读取。')
    if (report.get('page') != expected_page or report.get('app_children', 0) < 1
            or not report.get('primary_present')):
        raise UIHostError('界面模块未完成渲染。')
    if report.get('ready_state') != 'complete' or report.get('font_status') != 'loaded':
        raise UIHostError('界面文档或字体尚未完成加载。')
    images = report.get('images', {})
    if images.get('pending', 1) or images.get('failed', 1):
        raise UIHostError('界面图片尚未完整加载。')
    viewport = report.get('viewport', {})
    if min(viewport.get('width', 0), viewport.get('height', 0)) <= 0:
        raise UIHostError('界面内容尺寸无效。')
    if viewport.get('scroll_width', 0) > viewport['width'] + 1:
        raise UIHostError('界面内容出现横向溢出。')
    fit = report.get('fit', {})
    if fit.get('enabled'):
        numeric = ('x', 'y', 'right', 'bottom', 'width', 'height',
                   'layout_width', 'layout_height', 'scale_x', 'scale_y')
        if any(type(fit.get(key)) not in (int, float)
               or not math.isfinite(fit[key]) for key in numeric):
            raise UIHostError('界面缩放尺寸无效。')
        if (min(fit[key] for key in ('width', 'height', 'layout_width',
                                    'layout_height', 'scale_x', 'scale_y')) <= 0
                or abs(fit['scale_x'] - fit['scale_y']) > .003):
            raise UIHostError('界面未按相同比例缩放。')
        if (fit['x'] < -1 or fit['y'] < -1 or fit['right'] > viewport['width'] + 1
                or fit['bottom'] > viewport['height'] + 1
                or viewport.get('scroll_height', 0) > viewport['height'] + 1):
            raise UIHostError('缩放后的完整界面超出窗口。')
        content = report.get('content_viewport', {})
        if (min(content.get('width', 0), content.get('height', 0)) <= 0
                or content.get('scroll_width', 0) > content['width'] + 1
                or content.get('scroll_height', 0) > content['height'] + 1):
            raise UIHostError('界面画布仍有未显示的内容。')
    return report


def inspect_native_dom(window, expected_page, timeout=10):
    # pywebview 6.2's loaded handlers run on a worker thread. Keep evaluate_js
    # here, outside native.Invoke/WinForms UI callbacks, so its result can return.
    deadline = time.monotonic() + timeout
    report = None
    while True:
        report = window.evaluate_js(DOM_PROBE)
        try:
            return validate_dom_report(report, expected_page)
        except UIHostError as error:
            if ((isinstance(report, dict) and report.get('images', {}).get('failed', 0))
                    or time.monotonic() >= deadline):
                raise UIHostError(str(error)) from error
            time.sleep(.1)


def native_window(root, files, state_root, initial_page='login'):
    import webview
    state_root = create_state_directory(state_root)
    storage = create_state_directory(state_root / 'webview2')
    logs = create_state_directory(state_root / 'launches')
    status_path = logs / (uuid.uuid4().hex + '.json')
    write_status(status_path, 'verified')
    mutex = None
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p)
        kernel.CreateMutexW.restype = ctypes.c_void_p
        mutex = kernel.CreateMutexW(None, False, 'Local\\Fangyu.UIReview.R57')
        if not mutex:
            raise UIHostError('无法准备界面窗口，请稍后重试。')
        if ctypes.get_last_error() == 183:
            kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
            kernel.CloseHandle(mutex)
            raise UIHostError('方隅新界面已经打开，请查看已有窗口。')
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Fangyu.Workbench.UIReview.R57')
    server = None
    server_thread = None
    try:
        server = StaticServer(root, files)
        server_thread = threading.Thread(target=server.serve_forever,
                                         kwargs={'poll_interval': .15}, daemon=True)
        server_thread.start()
        url = 'http://127.0.0.1:' + str(server.server_port) + '/#' + initial_page
        window = webview.create_window('方隅工作台', url=url, width=1440, height=960,
            min_size=(720, 480), background_color='#F2FAFB', text_select=True, zoomable=False)
        accepted = {'renderer': False, 'loaded': False, 'error': None, 'dom': None}

        def initialized(renderer):
            accepted['renderer'] = renderer == 'edgechromium'
            return accepted['renderer']

        def loaded():
            if accepted['loaded'] or accepted['error']:
                return
            try:
                if not accepted['renderer']:
                    raise UIHostError('需要 WebView2 桌面运行时。')
                from System import Action
                origin = urlsplit(url)

                def guard(_sender, args):
                    target = urlsplit(str(args.Uri))
                    if target.scheme == 'about' and target.path == 'blank':
                        return
                    if (target.scheme, target.netloc) != (origin.scheme, origin.netloc):
                        args.Cancel = True

                def attach():
                    window.native.browser.webview.NavigationStarting.__iadd__(guard)
                window.native.Invoke(Action(attach))
                window._fangyu_ui_navigation_guard = guard
                accepted['dom'] = inspect_native_dom(window, initial_page)
                if accepted['error']:
                    raise accepted['error']
                accepted['loaded'] = True
                write_status(status_path, 'native_ready', port=server.server_port,
                             renderer='edgechromium', dom=accepted['dom'],
                             business_connected=False)
            except Exception as error:
                accepted['error'] = error
                window.destroy()

        window.events.initialized += initialized
        window.events.loaded += loaded
        webview.settings['ALLOW_DOWNLOADS'] = False
        write_status(status_path, 'opening', port=server.server_port)
        startup_finished = threading.Event()
        def startup_monitor():
            if not startup_finished.wait(45) and not accepted['loaded']:
                accepted['error'] = UIHostError('界面加载超时，请关闭后重新打开。')
                try:
                    window.destroy()
                except Exception:
                    pass
        watchdog = threading.Thread(target=startup_monitor, daemon=True)
        watchdog.start()
        icon = root / 'resources' / 'brand.ico'
        try:
            webview.start(gui='edgechromium', debug=False, private_mode=False,
                          storage_path=str(storage), icon=str(icon) if icon.is_file() else None)
        finally:
            startup_finished.set()
        if accepted['error']:
            raise accepted['error']
        if not accepted['renderer'] or not accepted['loaded']:
            raise UIHostError('WebView2 窗口未完成加载，请确认桌面运行时可用。')
        write_status(status_path, 'closed', requests=server.counters,
                     renderer='edgechromium', dom=accepted['dom'],
                     business_connected=False)
        return 0
    except Exception as error:
        write_status(status_path, 'failed', error_type=type(error).__name__,
                     error=str(error) if isinstance(error, UIHostError) else None)
        raise
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        if server_thread is not None:
            server_thread.join(timeout=3)
        if mutex is not None:
            kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
            kernel.CloseHandle(mutex)


def main(release_root, manifest_sha256, state_root, argv=None):
    parser = argparse.ArgumentParser(description='方隅工作台本地界面')
    parser.add_argument('--check', action='store_true', help='仅核验资源和原生依赖，不打开窗口')
    parser.add_argument('--self-test', action='store_true', help='核验静态HTTP及业务隔离，不打开窗口')
    parser.add_argument('--page', choices=('login', 'acquire', 'reply', 'customers', 'presets'), default='login')
    options = parser.parse_args(argv)
    manifest, files = verify_release(Path(release_root), manifest_sha256)
    if options.self_test:
        print(json.dumps(http_self_test(Path(release_root), files), ensure_ascii=False))
        return 0
    if options.check:
        import webview
        report = {'status': 'PASS', 'release_id': manifest['release_id'], 'files': len(files),
                  'webview_version': importlib.metadata.version('pywebview'),
                  'native_windows_opened': 0, 'business_app_imported': False}
        print(json.dumps(report, ensure_ascii=False))
        return 0
    return native_window(Path(release_root), files, Path(state_root), options.page)


def notify_error(error):
    message = str(error) if isinstance(error, UIHostError) else '界面未能启动，请查看本版本的启动状态。'
    if os.name == 'nt':
        ctypes.windll.user32.MessageBoxW(None, message, '方隅工作台 · 打开提示', 0x10)
    else:
        print(message, file=sys.stderr)
