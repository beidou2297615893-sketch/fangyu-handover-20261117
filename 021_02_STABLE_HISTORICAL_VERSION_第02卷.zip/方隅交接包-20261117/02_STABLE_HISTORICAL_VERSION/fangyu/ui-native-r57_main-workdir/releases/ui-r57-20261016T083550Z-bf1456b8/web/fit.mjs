// A fixed design viewport keeps the approved composition at every window size.
const sizes={login:[1487,1058],acquire:[1585,992],reply:[1585,992],customers:[1586,992],presets:[1586,992],accounts:[1585,992]};
const frame=document.getElementById('workspace-frame');
const route=value=>Object.hasOwn(sizes,value)?value:'login';
let page=route(location.hash.slice(1)),[width,height]=sizes[page];
let measuredHeight=height;
function fit(){
  const scale=Math.min(innerWidth/width,innerHeight/measuredHeight);
  const x=Math.max(0,(innerWidth-width*scale)/2);
  const y=Math.max(0,(innerHeight-measuredHeight*scale)/2);
  frame.style.width=width+'px';frame.style.height=measuredHeight+'px';
  frame.style.transform=`translate(${x}px,${y}px) scale(${scale})`;
  document.body.dataset.page=page;
  document.body.dataset.scale=String(scale);
}
window.addEventListener('resize',fit);
window.visualViewport?.addEventListener('resize',fit);
window.addEventListener('message',event=>{
  if(event.source!==frame.contentWindow||event.origin!==location.origin)return;
  const message=event.data;
  if(message?.type!=='fangyu-canvas-size'||!Object.hasOwn(sizes,message.page))return;
  const changed=message.page!==page;
  page=message.page;[width,height]=sizes[page];
  if(changed)measuredHeight=height;
  // Discard dimensions measured at the previous route's virtual viewport.
  if(message.viewportWidth===width&&Number.isFinite(message.contentHeight)){
    measuredHeight=Math.max(height,Math.ceil(message.contentHeight));
  }
  fit();frame.dataset.ready='true';
  if(location.hash!=='#'+page)history.replaceState(null,'','#'+page);
});
window.addEventListener('hashchange',()=>{
  const next=route(location.hash.slice(1));
  if(next===page)return;
  page=next;[width,height]=sizes[page];measuredHeight=height;fit();
  // Keep the existing document, draft state and focused controls alive.
  frame.contentWindow.location.hash=page;
});
fit();
frame.src='/canvas.html#'+page;
