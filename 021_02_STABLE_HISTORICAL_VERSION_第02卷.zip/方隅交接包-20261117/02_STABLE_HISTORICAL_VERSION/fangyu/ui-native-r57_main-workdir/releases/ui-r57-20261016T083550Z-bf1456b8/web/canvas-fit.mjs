const sizes={login:[1487,1058],acquire:[1585,992],reply:[1585,992],customers:[1586,992],presets:[1586,992],accounts:[1585,992]};
const app=document.getElementById('app');
let queued=false;
function measure(){
  queued=false;
  const page=document.body.dataset.page;
  if(!Object.hasOwn(sizes,page))return;
  const [,height]=sizes[page];
  document.documentElement.style.setProperty('--canvas-height',height+'px');
  requestAnimationFrame(()=>{
    const contentHeight=Math.max(height,Math.ceil(app.getBoundingClientRect().height-.01));
    if(parent!==window)parent.postMessage({type:'fangyu-canvas-size',page,viewportWidth:innerWidth,contentHeight},location.origin);
  });
}
function queue(){if(!queued){queued=true;requestAnimationFrame(measure);}}
new MutationObserver(queue).observe(app,{childList:true,subtree:true,characterData:true});
new ResizeObserver(queue).observe(app);
window.addEventListener('resize',queue);
document.fonts?.ready.then(queue);
queue();
