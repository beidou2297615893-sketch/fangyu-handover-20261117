// Approved preparation card and two platform rows; existing actions own login and checks.
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slots=[{id:'xiaohongshu',name:'小红书',aliases:['xhs','xiaohongshu'],description:'笔记与评论获客'},{id:'douyin',name:'抖音',aliases:['douyin','dy'],description:'视频与评论获客'}];
// The local authoring helper inserts the existing project's vector paths.
const brandPaths={xiaohongshu:'M22.405 9.879c.002.016.01.02.07.019h.725a.797.797 0 0 0 .78-.972.794.794 0 0 0-.884-.618.795.795 0 0 0-.692.794c0 .101-.002.666.001.777zm-11.509 4.808c-.203.001-1.353.004-1.685.003a2.528 2.528 0 0 1-.766-.126.025.025 0 0 0-.03.014L7.7 16.127a.025.025 0 0 0 .01.032c.111.06.336.124.495.124.66.01 1.32.002 1.981 0 .01 0 .02-.006.023-.015l.712-1.545a.025.025 0 0 0-.024-.036zM.477 9.91c-.071 0-.076.002-.076.01a.834.834 0 0 0-.01.08c-.027.397-.038.495-.234 3.06-.012.24-.034.389-.135.607-.026.057-.033.042.003.112.046.092.681 1.523.787 1.74.008.015.011.02.017.02.008 0 .033-.026.047-.044.147-.187.268-.391.371-.606.306-.635.44-1.325.486-1.706.014-.11.021-.22.03-.33l.204-2.616.022-.293c.003-.029 0-.033-.03-.034zm7.203 3.757a1.427 1.427 0 0 1-.135-.607c-.004-.084-.031-.39-.235-3.06a.443.443 0 0 0-.01-.082c-.004-.011-.052-.008-.076-.008h-1.48c-.03.001-.034.005-.03.034l.021.293c.076.982.153 1.964.233 2.946.05.4.186 1.085.487 1.706.103.215.223.419.37.606.015.018.037.051.048.049.02-.003.742-1.642.804-1.765.036-.07.03-.055.003-.112zm3.861-.913h-.872a.126.126 0 0 1-.116-.178l1.178-2.625a.025.025 0 0 0-.023-.035l-1.318-.003a.148.148 0 0 1-.135-.21l.876-1.954a.025.025 0 0 0-.023-.035h-1.56c-.01 0-.02.006-.024.015l-.926 2.068c-.085.169-.314.634-.399.938a.534.534 0 0 0-.02.191.46.46 0 0 0 .23.378.981.981 0 0 0 .46.119h.59c.041 0-.688 1.482-.834 1.972a.53.53 0 0 0-.023.172.465.465 0 0 0 .23.398c.15.092.342.12.475.12l1.66-.001c.01 0 .02-.006.023-.015l.575-1.28a.025.025 0 0 0-.024-.035zm-6.93-4.937H3.1a.032.032 0 0 0-.034.033c0 1.048-.01 2.795-.01 6.829 0 .288-.269.262-.28.262h-.74c-.04.001-.044.004-.04.047.001.037.465 1.064.555 1.263.01.02.03.033.051.033.157.003.767.009.938-.014.153-.02.3-.06.438-.132.3-.156.49-.419.595-.765.052-.172.075-.353.075-.533.002-2.33 0-4.66-.007-6.991a.032.032 0 0 0-.032-.032zm11.784 6.896c0-.014-.01-.021-.024-.022h-1.465c-.048-.001-.049-.002-.05-.049v-4.66c0-.072-.005-.07.07-.07h.863c.08 0 .075.004.075-.074V8.393c0-.082.006-.076-.08-.076h-3.5c-.064 0-.075-.006-.075.073v1.445c0 .083-.006.077.08.077h.854c.075 0 .07-.004.07.07v4.624c0 .095.008.084-.085.084-.37 0-1.11-.002-1.304 0-.048.001-.06.03-.06.03l-.697 1.519s-.014.025-.008.036c.006.01.013.008.058.008 1.748.003 3.495.002 5.243.002.03-.001.034-.006.035-.033v-1.539zm4.177-3.43c0 .013-.007.023-.02.024-.346.006-.692.004-1.037.004-.014-.002-.022-.01-.022-.024-.005-.434-.007-.869-.01-1.303 0-.072-.006-.071.07-.07l.733-.003c.041 0 .081.002.12.015.093.025.16.107.165.204.006.431.002 1.153.001 1.153zm2.67.244a1.953 1.953 0 0 0-.883-.222h-.18c-.04-.001-.04-.003-.042-.04V10.21c0-.132-.007-.263-.025-.394a1.823 1.823 0 0 0-.153-.53 1.533 1.533 0 0 0-.677-.71 2.167 2.167 0 0 0-1-.258c-.153-.003-.567 0-.72 0-.07 0-.068.004-.068-.065V7.76c0-.031-.01-.041-.046-.039H17.93s-.016 0-.023.007c-.006.006-.008.012-.008.023v.546c-.008.036-.057.015-.082.022h-.95c-.022.002-.028.008-.03.032v1.481c0 .09-.004.082.082.082h.913c.082 0 .072.128.072.128V11.19s.003.117-.06.117h-1.482c-.068 0-.06.082-.06.082v1.445s-.01.068.064.068h1.457c.082 0 .076-.006.076.079v3.225c0 .088-.007.081.082.081h1.43c.09 0 .082.007.082-.08v-3.27c0-.029.006-.035.033-.035l2.323-.003c.098 0 .191.02.28.061a.46.46 0 0 1 .274.407c.008.395.003.79.003 1.185 0 .259-.107.367-.33.367h-1.218c-.023.002-.029.008-.028.033.184.437.374.871.57 1.303a.045.045 0 0 0 .04.026c.17.005.34.002.51.003.15-.002.517.004.666-.01a2.03 2.03 0 0 0 .408-.075c.59-.18.975-.698.976-1.313v-1.981c0-.128-.01-.254-.034-.38 0 .078-.029-.641-.724-.998z',douyin:'M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z'};
const scope=s=>JSON.stringify([s.connection,s.user||'',s.storeId||'']);
function model(s){const key=scope(s);if(s.accountPage?.scope!==key)s.accountPage={scope:key,pending:'',feedback:{},failures:{}};return s.accountPage;}
function currentPlatform(s){const p=s.platform;return s.connection==='connected'&&s.session?.user?.username===s.user&&p?.actor?.username===s.user&&p.actor.storeId===s.storeId?p:null;}
function platforms(s){
  const p=currentPlatform(s);
  return slots.map(slot=>{const live=p?.platforms?.find(r=>slot.aliases.includes(r.id)),accountId=s.platformAccountSelections?.[live?.id]||live?.accountId,account=p?.accounts?.find(r=>r.id===accountId&&slot.aliases.includes(r.platform));return {...slot,...live,accountId,account,displayName:slot.name,status:account?.status||live?.status,message:account?.message||live?.message,requiresReview:account?.requiresReview??account?.requires_review??live?.requiresReview,accountName:account?.name||account?.platformNickname||account?.platform_nickname||live?.accountName||'尚未连接'};});
}
function status(row,s){
  if(s.connection==='preview')return '待登录';
  const p=currentPlatform(s);if(s.platformLoading&&!p)return '正在读取';if(!p||s.platformError)return '状态待读取';if(row.enabled===false)return '未开通';if(row.enabled!==true)return '状态待读取';
  const d=p.device||{};if(['held','blocked','paused','review_required'].includes(d.state)||row.requiresReview)return '暂停 · 待核验';if(!d.bound)return '待准备';if(d.state!=='online')return '电脑待连接';
  if(model(s).failures?.[row.id])return '待重新检查';
  if(['ready','connected','online'].includes(row.status))return row.account?'已连接':'待核验';
  return ({logging_in:'连接中',waiting_login:'等待扫码',checking:'核对中',held:'暂停 · 待核验',blocked:'暂停 · 待核验',login_required:'待登录',disconnected:'待连接',failed:'连接未完成',unverified:'待核验'})[row.status]||'待登录';
}
function preparation(s,pending=model(s).pending){
  const p=currentPlatform(s),d=p?.device;
  if(pending==='prepare')return {label:'准备中…',ready:false,message:'正在检查当前电脑的连接环境'};
  if(s.connection==='preview')return {label:'待准备',ready:false,message:'自动检查连接环境，准备好后再登录平台'};
  if(!p||s.platformError)return {label:s.platformLoading?'正在读取':'待读取',ready:false,message:s.platformError||'自动检查连接环境，准备好后再登录平台'};
  if(d?.bound&&d.state==='online')return {label:'已准备',ready:true,message:'本机连接已确认，可以选择平台登录'};
  return {label:['held','blocked','paused'].includes(d?.state)?'待核验':d?.state==='binding'?'准备中':'待准备',ready:false,message:d?.message||'自动检查连接环境，准备好后再登录平台'};
}
function brand(id){const path=brandPaths[id],shape=id==='douyin'?`<path d="${path}" fill="#25f4ee" transform="translate(-.7 -.1)"/><path d="${path}" fill="#fe2c55" transform="translate(.7 .5)"/><path d="${path}" fill="#fff"/>`:`<path d="${path}" fill="#fff"/>`;return `<span aria-hidden="true" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;border-radius:21px;background:${id==='douyin'?'#101214':'#ff2442'};flex-shrink:0"><svg viewBox="0 0 24 24" style="width:${id==='douyin'?51:69}px;height:${id==='douyin'?58:69}px">${shape}</svg></span>`;}
const textButton='border:0;background:transparent;padding:3px 6px;color:#087d91;font-size:15px;white-space:nowrap';
const primary='background:#007e89;color:#fff;border:1px solid #007e89;border-radius:8px;font-size:22px;font-weight:600;height:63px;padding:0 24px;white-space:nowrap';
const chip=(text,ok=false,neutral=false)=>`<span role="status" style="display:inline-block;padding:6px 20px;border-radius:24px;background:${ok?'#e5f8f3':neutral?'#eef4f8':'#fff1dc'};color:${ok?'#087f75':neutral?'#8399af':'#a45d15'};font-size:18px;line-height:1.4;font-weight:500;white-space:nowrap">${escape(text)}</span>`;
export function render(s){
  const ui=model(s),rows=platforms(s),prep=preparation(s),busy=s.busy||Boolean(ui.pending),preview=s.connection==='preview',active=rows.some(r=>status(r,s)==='已连接')?3:prep.ready?2:1;
  const steps=['一键准备','登录平台','开始获客'].map((text,i)=>`${i?'<span aria-hidden="true" style="color:#8aa5bc;font-size:30px">›</span>':''}<span style="display:flex;align-items:center;gap:15px;white-space:nowrap;color:${active===i+1?'#007f8d':'#708bac'}"><b style="width:38px;height:38px;border-radius:50%;display:grid;place-items:center;font-size:22px;background:${active===i+1?'#008693':'#eff5f9'};border:1px solid #dae6ee;color:${active===i+1?'#fff':'#718aa8'}">${i+1}</b>${text}</span>`).join('');
  return `<div class="platform-accounts-page" style="display:flex;flex-direction:column;gap:calc(16px * var(--space-y,1))">
    <section class="card" style="display:grid;grid-template-columns:98px minmax(0,1fr) 260px;gap:24px;align-items:center;min-height:calc(230px * var(--space-y,1));padding:calc(36px * var(--space-y,1)) 30px;background:#ffffffd9">
      <span aria-hidden="true" style="height:98px;width:98px;display:grid;place-items:center;border-radius:50%;background:#e7f8f7;color:#008292"><svg viewBox="0 0 64 64" width="55" height="55" fill="none" stroke="currentColor" stroke-width="4"><circle cx="14" cy="34" r="9"/><circle cx="41" cy="13" r="7"/><circle cx="43" cy="51" r="7"/><path d="m21 28 14-10M22 39l14 8"/></svg></span>
      <div style="min-width:0"><div style="display:flex;align-items:center;gap:18px;margin-bottom:8px"><h2 style="margin:0;font-size:30px">准备当前电脑</h2>${chip(prep.label,prep.ready,true)}</div><p role="status" style="margin:0 0 28px;color:#7189a6;font-size:19px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${escape(s.platformError||(ui.failures?.prepare?ui.feedback.prepare:prep.message))}">${escape(s.platformError||(ui.failures?.prepare?ui.feedback.prepare:prep.message))}</p><div style="display:flex;align-items:center;gap:36px;font-size:20px">${steps}</div></div>
      <button type="button" data-account-prepare style="${primary}" ${busy?'disabled':''}>${ui.pending==='prepare'?'正在准备…':prep.ready?'检查本机':'一键准备'}</button>
    </section>
    <section class="card" style="padding:calc(26px * var(--space-y,1)) 28px;min-height:calc(538px * var(--space-y,1));background:#ffffffec">
      <h2 style="display:flex;align-items:center;gap:18px;font-size:30px;margin:0 0 16px">平台账号${preview?'<span style="font-size:15px;color:#8198af;font-weight:400">登录状态为示例</span>':''}</h2>
      <div style="display:grid;gap:12px">${rows.map(row=>{
        const label=status(row,s),connected=label==='已连接',pending=ui.pending?.endsWith(':'+row.id),feedback=s.platformError||((pending||ui.failures?.[row.id])?ui.feedback[row.id]:'')||row.message||(!connected?ui.feedback[row.id]:'')||(!prep.ready?'准备完成后，再登录'+row.displayName:connected?'账号身份已经核验':'扫码登录'+row.displayName);
        return `<article style="display:grid;grid-template-columns:80px minmax(165px,1fr) minmax(190px,1fr) minmax(245px,1.25fr) 214px;align-items:center;gap:24px;min-height:calc(130px * var(--space-y,1));padding:calc(19px * var(--space-y,1)) 20px;border:1px solid #dfebf2;border-radius:10px;background:#fff">
          ${brand(row.id==='xhs'?'xiaohongshu':row.id==='dy'?'douyin':row.id)}<div><h3 style="font-size:27px;margin:0 0 4px">${row.displayName}</h3><p style="font-size:18px;margin:0;color:#7b92aa">${escape(row.description)}</p></div>
          <div style="border-left:1px solid #e5edf3;border-right:1px solid #e5edf3;padding:0 28px;min-width:0"><span style="display:block;font-size:17px;color:#8196af;margin-bottom:5px">当前账号</span><strong style="font-size:21px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="${escape(row.accountName)}">${escape(row.accountName)}</strong></div>
          <div style="min-width:0">${chip(pending?ui.pending.startsWith('check:')?'核对中':'连接中':label,connected&&!pending)}<p role="status" style="margin:7px 0 0;color:#7189a6;font-size:17px;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden" title="${escape(feedback)}">${escape(feedback)}</p></div>
          <div style="display:flex;flex-direction:column;gap:7px"><button type="button" data-account-connect="${escape(row.id)}" ${busy?'disabled':''} style="height:58px;border:1px solid #00a1be;background:#fff;color:#00849a;font-size:20px;font-weight:600">${ui.pending==='connect:'+row.id?'处理中…':row.enabled===false?'查看原因':row.id==='douyin'?(connected?'重新连接':'连接抖音'):connected?'重新登录':'登录'+row.displayName}</button><div style="display:flex;justify-content:space-between"><button type="button" data-account-check="${escape(row.id)}" ${busy?'disabled':''} style="${textButton}">${ui.pending==='check:'+row.id?'正在检查…':'检查连接'}</button><button type="button" data-account-view="${escape(row.id)}" style="${textButton}">查看</button></div></div>
        </article>`;
      }).join('')}</div>
      <div style="margin-top:24px;padding:20px 24px;border:1px solid #e3eef4;background:#f5fafdf2;border-radius:10px;display:flex;gap:25px;align-items:center"><span aria-hidden="true" style="width:32px;height:32px;display:grid;place-items:center;border:3px solid #153b65;border-radius:50%;color:#153b65;font-size:22px;font-weight:600">i</span><strong style="font-size:26px;white-space:nowrap">下一步</strong><p style="margin:0;color:#768fa9;font-size:17px">先点一键准备，再选择平台登录。连接结果显示在平台旁；失败时可检查连接或重新登录。</p></div>
    </section>
  </div>`;
}
export function bind(root,ctx){
  const state=ctx.state;
  async function run(kind,platformId){
    const ui=model(state),key=scope(state),pending=kind==='prepare'?'prepare':kind+':'+platformId;
    if(ui.pending||state.busy)return;
    if(state.connection==='preview'){ctx.modal({title:'平台账号预览',html:'<p>本页为登录前状态示例，预览不会准备电脑或连接真实平台。</p>'});return;}
    if(!state.session||!state.user){ctx.toast('请先登录工作台。');return;}
    const feedbackKey=kind==='prepare'?'prepare':platformId;
    ui.failures??={};ui.failures[feedbackKey]=false;ui.pending=pending;ui.feedback[feedbackKey]=kind==='check'?'正在核对当前账号的登录状态…':kind==='prepare'?'正在检查当前电脑的连接环境…':'正在处理平台登录，请留意连接窗口…';ctx.update(()=>{});
    try{
      const action=kind==='prepare'?ctx.actions.preparePlatform:kind==='connect'?ctx.actions.connectAccount:ctx.actions.checkAccount;
      if(typeof action!=='function')throw new Error(kind==='check'?'检查连接尚未接入，请稍后重试':'当前连接操作尚未就绪');
      const result=await action(platformId);
      if(scope(state)!==key||state.accountPage!==ui)return;
      const row=platforms(state).find(item=>item.id===platformId),prep=preparation(state,'');
      const job=result?.job;
      if(['failed','cancelled','stopped'].includes(job?.status))ui.failures[feedbackKey]=true;
      ui.feedback[feedbackKey]=kind==='prepare'?prep.message:state.platformError||job?.message||row?.message||(row&&status(row,state)==='已连接'?'账号身份已经核验，连接可用':'操作已返回，请核对平台当前状态。');
    }catch(error){if(scope(state)===key&&state.accountPage===ui){ui.failures[feedbackKey]=true;ui.feedback[feedbackKey]=(kind==='check'?'检查未完成：':kind==='prepare'?'准备未完成：':'连接未完成：')+String(error?.message||'请稍后重试');}}
    finally{if(scope(state)===key&&state.accountPage===ui){ui.pending='';ctx.update(()=>{});}}
  }
  async function details(platformId){
    const key=scope(state),row=platforms(state).find(item=>item.id===platformId);if(!row)return;
    const owns=()=>scope(state)===key&&platforms(state).find(item=>item.id===platformId)?.accountId===row.accountId;
    let safety=null;
    if(row.id==='xiaohongshu'&&row.accountId&&typeof ctx.actions.readAccountSafety==='function'){
      const result=await ctx.actions.readAccountSafety(platformId);if(!owns())return;
      safety=result?.job;
    }
    const review=safety?.reviewRequired&&Number.isSafeInteger(safety.revision)&&safety.revision>=0
      ?`<div style="margin-top:18px"><p role="status">${escape(safety.message||'请本人完成平台验证，关闭验证窗口后确认复核。')}</p><button type="button" data-account-open-verification style="${textButton}">打开验证网页</button><button type="button" data-account-confirm-review style="${textButton}" ${safety.canConfirmReview===true?'':'disabled'}>本人已完成验证，确认复核</button></div>`:'';
    const p=currentPlatform(state),choices=(p?.accounts||[]).filter(item=>row.aliases.includes(item.platform)),device=p?.device;
    const dialog=ctx.modal({title:row.displayName+' · 连接详情',html:`<div style="max-height:55vh;overflow:auto;overflow-wrap:anywhere"><p>当前账号：${escape(row.accountName)}</p><p>连接状态：${escape(status(row,state))}</p><p role="status">${escape(state.platformError||row.message||model(state).feedback[row.id]||device?.message||'尚未取得当前账号的连接回执。')}</p>${review}${choices.length?`<label for="platform-account-choice">门店平台账号</label><select id="platform-account-choice">${choices.map(item=>`<option value="${escape(item.id)}" ${item.id===row.accountId?'selected':''}>${escape(item.name||item.platformNickname||item.id)}</option>`).join('')}</select>`:''}<details style="margin-top:18px"><summary>设备与授权信息</summary><dl><dt>当前门店</dt><dd>${escape(state.store||'尚未选择')}</dd><dt>电脑状态</dt><dd>${escape(device?.message||'尚未取得回执')}</dd><dt>平台说明</dt><dd>${escape(row.message||'尚未取得回执')}</dd><dt>状态代码</dt><dd>${escape(row.reasonCode||device?.reasonCode||'未提供')}</dd></dl></details></div>`,confirmLabel:'刷新状态',onConfirm:async()=>{await ctx.actions.refreshPlatform();if(owns()&&state.page==='accounts')details(platformId);return false;}});
    dialog?.querySelector('[data-account-open-verification]')?.addEventListener('click',async()=>{
      if(!owns())return;await ctx.actions.openAccountVerification(platformId);if(owns())details(platformId);
    });
    dialog?.querySelector('[data-account-confirm-review]')?.addEventListener('click',()=>{
      if(!owns()||safety?.canConfirmReview!==true)return;
      ctx.modal({title:'确认人工复核',html:'<p>请确认本人已完成平台要求的验证，并关闭人工验证窗口。</p><p>此操作只记录人工复核；随后仍需检查连接或重新连接，不会自动继续采集。</p>',confirmLabel:'本人已完成，确认复核',onConfirm:async()=>{
        if(!owns())return false;const result=await ctx.actions.confirmAccountReview(platformId,safety.revision);
        if(owns())details(platformId);return Boolean(result);
      }});
    });
    dialog?.querySelector('#platform-account-choice')?.addEventListener('change',event=>{if(scope(state)!==key)return;const id=event.target.value;if(!choices.some(item=>item.id===id))return;ctx.update(s=>{s.platformAccountSelections??={};s.platformAccountSelections[row.id]=id;});details(platformId);});
  }
  root.querySelector('[data-account-prepare]')?.addEventListener('click',()=>run('prepare'));
  for(const button of root.querySelectorAll('[data-account-view]'))button.addEventListener('click',()=>details(button.dataset.accountView));
  for(const button of root.querySelectorAll('[data-account-connect]'))button.addEventListener('click',()=>run('connect',button.dataset.accountConnect));
  for(const button of root.querySelectorAll('[data-account-check]'))button.addEventListener('click',()=>run('check',button.dataset.accountCheck));
  return ()=>{};
}
