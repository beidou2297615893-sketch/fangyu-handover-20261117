// Only login and store presets cross this interface. Collection and sending remain examples.
export class WorkbenchError extends Error {
  constructor(message, code='request_failed') { super(message); this.name='WorkbenchError'; this.code=code; }
}

export function createBackend(fetcher=globalThis.fetch.bind(globalThis),{timeoutMs=90000}={}) {
  let csrfToken='';
  let mode='loading';
  let unconfirmed=false;
  async function request(action, data) {
    const bootstrap=action==='bootstrap';
    if(!bootstrap&&unconfirmed)throw new WorkbenchError('上次操作结果尚未确认，请先核对状态。','RESULT_UNCONFIRMED');
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),timeoutMs);
    try {
      const response=await fetcher(bootstrap?'/api/workbench/bootstrap':'/api/workbench',bootstrap
        ? {method:'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal}
        : {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Fangyu-CSRF':csrfToken},body:JSON.stringify({action,data}),signal:controller.signal});
      // The static design preview deliberately has no business interface.
      if(bootstrap&&response.status===404) { mode='preview'; return null; }
      let result;
      try { result=await response.json(); }
      catch { if(!bootstrap)unconfirmed=true;throw new WorkbenchError(bootstrap?'本地服务返回异常，请稍后重新核对。':'操作结果尚未确认，正在核对状态。',bootstrap?'invalid_response':'RESULT_UNCONFIRMED'); }
      if(result?.csrfToken)csrfToken=result.csrfToken;
      if(!response.ok||result?.ok!==true)throw new WorkbenchError(result?.error?.message||'操作未完成，请稍后重试。',result?.error?.code||'request_failed');
      if(bootstrap){mode='connected';unconfirmed=false;}
      return result;
    } catch(error) {
      if(error instanceof WorkbenchError)throw error;
      if(!bootstrap){unconfirmed=true;throw new WorkbenchError('操作结果尚未确认，正在核对状态。','RESULT_UNCONFIRMED');}
      if(error?.name==='AbortError')throw new WorkbenchError('连接超时，暂时无法核对上次操作。','timeout');
      throw new WorkbenchError('暂时无法连接本地服务，请稍后重新核对。','connection_failed');
    } finally { clearTimeout(timeout); }
  }
  return {get mode(){return mode;},get unconfirmed(){return unconfirmed;},bootstrap:()=>request('bootstrap'),login:data=>request('login',data),logout:()=>request('logout',{}),selectStore:storeId=>request('select_store',{storeId}),applyPreset:data=>request('apply_preset',data)};
}
