"""Narrow customer login and local preset preferences over the existing core.

The host pins/imports the legacy source before loading this module. There is no
AppServer, assistant worker, platform route, password database or task recovery.
"""
import hashlib
import json
import os
import re
import threading
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from core.engine import Core
from integrations import Integrations, IntegrationError, EmployeeLoginRequired
from assistant.ai_workflow import LocalAIWorkflow
from assistant.intent_rule_management import IntentRuleManagement


COMPANY_ID = 'fangyu-apartment-client'
ENTITY = 'ui_workbench_preferences_v1'
STORE_ID = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')
ACTIONS = frozenset({'bootstrap', 'login', 'logout', 'select_store', 'apply_preset'})
SEARCH_IDS = frozenset({'precise', 'commute'})
INTENT_IDS = frozenset({'standard', 'recent'})


class WorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


class _ProfileIntegrations(Integrations):
    """Retain the verified public me projection without a second cloud request."""
    def _cloud(self, config, user, operation, **data):
        try:
            result = super()._cloud(config, user, operation, **data)
        except IntegrationError as error:
            if operation == 'me':
                # Legacy verify_identity intentionally returns None for any
                # IntegrationError. Preserve its safe HTTP classification so a
                # temporary outage cannot be mistaken for revoked authority.
                self.last_verification_error = error
            raise
        if operation == 'me':
            self.last_verified_profile = deepcopy(result.get('user'))
        return result


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _deny_cloud(*args, **kwargs):
    raise WorkbenchError('ACTION_NOT_AVAILABLE', '当前批次未接入 AI、采集或发送', 403)


class WorkbenchBackend:
    def __init__(self, project_root, data_dir=None, company=None, *, core_factory=Core,
                 integrations_factory=_ProfileIntegrations, workflow_factory=LocalAIWorkflow,
                 rules_factory=IntentRuleManagement):
        self.project_root = Path(project_root).resolve()
        if company is None:
            try:
                company = json.loads((self.project_root / 'work/app/company.json').read_text('utf-8-sig'))
            except (OSError, ValueError):
                raise WorkbenchError('CONFIG_UNAVAILABLE', '企业登录配置暂不可读，请联系管理员', 503) from None
        company = deepcopy(company)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        if (not isinstance(company, dict) or company.get('id') != COMPANY_ID
                or company.get('edition') != 'customer' or company.get('personalMode') is not False
                or company.get('authMode') != 'managed' or not isinstance(managed, dict)
                or not managed.get('environment_id') or not managed.get('endpoint')):
            raise WorkbenchError('CONFIG_INVALID', '此入口需要方隅客户企业登录配置', 503)
        self.company = company
        self.data_dir = Path(data_dir).resolve() if data_dir is not None else (
            Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) /
            (COMPANY_ID + 'Workspace')).resolve()
        self.lock = threading.RLock()
        self.core = core_factory(self.data_dir,
            self.project_root / 'work/ui-runtime-r55/src/resources', defer_startup_recovery=True)
        self.core.deployment_config = deepcopy(company)
        self.integrations = integrations_factory(self.core)
        self.workflow = workflow_factory(self.core, _deny_cloud, company=deepcopy(company))
        self.rules_factory = rules_factory
        self.closed = False

    def close(self):
        if not self.closed:
            self.closed = True
            # No scheduler was started and no platform adapter was exposed.
            self.core.adapters.close()

    def _remembered(self):
        row = self.core.store.get(ENTITY, 'remembered-username')
        return row.get('username', '') if row and row.get('tenant_id') == COMPANY_ID else ''

    def _remember(self, username):
        self.core.store.put(ENTITY, {'id': 'remembered-username', 'tenant_id': COMPANY_ID,
                                    'username': username, 'updated_at': _stamp()})

    def _identity(self, token):
        user = self.core.session(token)
        if not user or user.get('cloud_bound') is not True or user.get('role') != 'operator':
            raise WorkbenchError('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        # Every API request refreshes authority; an earlier cached me result
        # cannot authorize a later store selection or local write.
        self.integrations.identity_cache.pop(user['id'], None)
        self.integrations.last_verified_profile = None
        self.integrations.last_verification_error = None
        verified = self.integrations.verify_identity(user)
        failure = self.integrations.last_verification_error
        if failure is not None and getattr(failure, 'http_status', None) not in (401, 403):
            raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                 '企业身份服务暂不可用，已保留本机登录，请稍后手动重试', 503)
        if not verified or verified.get('role') != 'operator':
            raise WorkbenchError('AUTH_REQUIRED', '员工登录已失效，请重新登录', 401)
        profile = self.integrations.last_verified_profile
        if profile is None:  # Allows a factory using the original integration.
            config = self.integrations._read(verified['tenant_id'])
            profile = self.integrations._cloud(config, verified, 'me').get('user')
        if (not isinstance(profile, dict) or profile.get('username') != verified['username']
                or profile.get('role') != 'operator' or profile.get('disabled')):
            raise WorkbenchError('AUTH_REQUIRED', '员工身份需重新核对', 401)
        return verified, profile

    def _stores(self, profile):
        ident = profile.get('store_id')
        if not isinstance(ident, str) or not STORE_ID.fullmatch(ident):
            return []
        # Cloud provides only an opaque group id. Never infer a Chinese name,
        # address, other stores or permission from the former demo choices.
        return [{'id': ident, 'name': ident, 'description': '企业已分配门店', 'region': ''}]

    def _preference_id(self, user):
        return _digest(['workbench-preset-v1', COMPANY_ID, user['tenant_id'], user['username']])

    def _load_selection(self, user, stores, db=None):
        ident = self._preference_id(user)
        if db is None:
            row = self.core.store.get(ENTITY, ident)
        else:
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (ENTITY, ident, user['tenant_id'])).fetchone()
            row = json.loads(found['body']) if found else None
        if row and (row.get('owner') != user['username'] or row.get('tenant_id') != user['tenant_id']
                    or row.get('company_id') != COMPANY_ID):
            raise WorkbenchError('PREFERENCE_SCOPE_INVALID', '门店预设归属无法核对', 409)
        revision = row.get('revision', 0) if row else 0
        if type(revision) is not int or revision < 0:
            raise WorkbenchError('PREFERENCE_INVALID', '门店预设版本无法核对', 409)
        allowed = {store['id'] for store in stores}
        selection = {'storeId': stores[0]['id'] if stores else '', 'searchPresetId': 'precise',
                     'intentPresetId': 'standard', 'revision': revision, 'applied': None, 'savedAt': None}
        if row and row.get('storeId') in allowed:
            if row.get('searchPresetId') not in SEARCH_IDS or row.get('intentPresetId') not in INTENT_IDS:
                raise WorkbenchError('PREFERENCE_INVALID', '门店预设方案无法核对', 409)
            for key in selection:
                selection[key] = deepcopy(row.get(key, selection[key]))
        return selection

    def _catalog(self, user=None):
        selected, library, policy = [], None, None
        if user:
            library = self.workflow.keyword_state(user, {'mode': 'read', 'city': '', 'area': ''})['library']
            if library:
                selected = list(library.get('selected') or [])
            policy = self.rules_factory(self.core, user['tenant_id'], user['username'],
                                       self.company).execute('intent_rules_get', {}, user)['summary']
        defaults = [word for word in self.company.get('keywords', [])
                    if isinstance(word, str) and 0 < len(word.strip()) <= 80]
        # An existing explicitly cleared selection must remain empty. Public
        # templates are offered only when no regional library exists at all.
        base = selected if library is not None else defaults or ['附近租房', '一居室租房']
        source = 'existing_keyword_selection' if library is not None else 'company_defaults' if defaults else 'general_apartment_template'
        reference = ({'id': library['id'], 'revision': library['revision'],
                      'region': deepcopy(library.get('request') or {})} if library else None)
        search = [{'id': 'precise', 'name': '精准获客', 'keywords': list(dict.fromkeys(base)),
                   'source': source, 'libraryReference': reference},
                  {'id': 'commute', 'name': '通勤拓展',
                   'keywords': list(dict.fromkeys([*base, '地铁通勤', '沿线租房'])),
                   'source': source, 'templateSupplement': ['地铁通勤', '沿线租房'],
                   'libraryReference': reference}]
        policy_ref = ({'revision': policy['revision'], 'digest': policy['digest'],
                       'validationVersion': policy['validation_version']} if policy else None)
        intent = [{'id': 'standard', 'name': '标准意向',
                   'description': '沿用既有意向判断规则，保存本机选择偏好', 'policyReference': policy_ref},
                  {'id': 'recent', 'name': '优先近期入住',
                   'description': '保存近期入住优先偏好，保留既有规则和历史评级', 'policyReference': policy_ref}]
        return {'search': search, 'intent': intent}

    def _bootstrap(self, token='', *, identity=None):
        user, profile, notice = None, None, ''
        if identity is not None:
            user, profile = identity
        elif token:
            try:
                user, profile = self._identity(token)
            except WorkbenchError as error:
                if error.code == 'AUTH_SERVICE_UNAVAILABLE':
                    raise
                notice = '登录已失效或企业身份暂未确认，请重新登录'
        stores = self._stores(profile) if profile else []
        selection = self._load_selection(user, stores) if user else {
            'storeId': '', 'searchPresetId': 'precise', 'intentPresetId': 'standard',
            'revision': 0, 'applied': None, 'savedAt': None}
        result = {'session': {'user': {'username': user['username'], 'role': user['role']}} if user else None,
                  'rememberedUsername': self._remembered(), 'stores': stores,
                  'selection': selection, 'catalog': self._catalog(user),
                  'capabilities': {'presets': bool(user and stores),
                      'reason': '' if user and stores else '请管理员先分配门店' if user else '请先登录'},
                  'notice': notice}
        return result

    def _save_selection(self, user, stores, data, *, apply):
        if not stores or data.get('storeId') not in {row['id'] for row in stores}:
            raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
        catalog = self._catalog(user)
        if apply and (data.get('searchPresetId') not in SEARCH_IDS or data.get('intentPresetId') not in INTENT_IDS):
            raise WorkbenchError('PRESET_INVALID', '请选择有效的搜索和意向预设')
        if 'expectedRevision' in data and (type(data['expectedRevision']) is not int or data['expectedRevision'] < 0):
            raise WorkbenchError('REVISION_INVALID', '预设版本格式无效')
        if apply and 'expectedRevision' not in data:
            raise WorkbenchError('REVISION_REQUIRED', '应用预设前需要当前版本')
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._load_selection(user, stores, db)
            expected = data.get('expectedRevision', current['revision'])
            if expected != current['revision']:
                raise WorkbenchError('PRESET_REVISION_CONFLICT', '预设已在其他窗口更新，请重新读取', 409)
            if not apply and current['storeId'] == data['storeId']:
                return
            value = {**current, 'storeId': data['storeId'], 'revision': current['revision'] + 1,
                     'savedAt': _stamp()}
            if apply:
                value.update(searchPresetId=data['searchPresetId'], intentPresetId=data['intentPresetId'])
                search = next(row for row in catalog['search'] if row['id'] == data['searchPresetId'])
                intent = next(row for row in catalog['intent'] if row['id'] == data['intentPresetId'])
                value['applied'] = {'selectedKeywords': list(search['keywords']),
                    'keywordSource': search['source'], 'libraryReference': search['libraryReference'],
                    'templateSupplement': search.get('templateSupplement', []),
                    'policyReference': intent['policyReference'],
                    'intentPreference': intent['id'], 'appliedAt': value['savedAt'],
                    'startsCollection': False, 'changesIntentPolicy': False}
            else:
                value['applied'] = None
            record = {**value, 'id': self._preference_id(user), 'tenant_id': user['tenant_id'],
                      'owner': user['username'], 'company_id': COMPANY_ID}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (ENTITY, record['id'], record['tenant_id'], json.dumps(record, ensure_ascii=False, allow_nan=False)))

    def dispatch(self, action, data, token=''):
        if self.closed:
            raise WorkbenchError('BACKEND_CLOSED', '工作台已关闭', 503)
        if action not in ACTIONS:
            raise WorkbenchError('ACTION_FORBIDDEN', '当前批次未开放此操作', 403)
        allowed = {'bootstrap': set(), 'login': {'username', 'password', 'rememberUsername'},
                   'logout': set(), 'select_store': {'storeId', 'expectedRevision'},
                   'apply_preset': {'storeId', 'searchPresetId', 'intentPresetId', 'expectedRevision'}}[action]
        if not isinstance(data, dict) or set(data) - allowed:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        with self.lock:
            try:
                if action == 'bootstrap':
                    return self._bootstrap(token)
                if action == 'login':
                    name, password = data.get('username'), data.get('password')
                    if (not isinstance(name, str) or not 0 < len(name.strip()) <= 80
                            or not isinstance(password, str) or not 0 < len(password) <= 256
                            or type(data.get('rememberUsername', False)) is not bool):
                        raise WorkbenchError('LOGIN_INPUT_INVALID', '请输入员工用户名和密码')
                    entered = self.integrations.enter({'username': name.strip(), 'password': password}, employee_only=True)
                    try:
                        identity = self._identity(entered['token'])
                    except Exception:
                        self.core.handle('logout', {'token': entered['token']})
                        raise
                    self._remember(name.strip() if data.get('rememberUsername') else '')
                    return {**self._bootstrap(identity=identity), 'token': entered['token'],
                            'cookie_max_age': entered.get('cookie_max_age')}
                if action == 'logout':
                    user = self.core.session(token)
                    cloud_unconfirmed = False
                    try:
                        if user and user.get('cloud_bound'):
                            self.integrations.handle('cloud_logout', {}, user)
                    except IntegrationError:
                        cloud_unconfirmed = True
                    finally:
                        self.core.handle('logout', {'token': token})
                    result = self._bootstrap()
                    if cloud_unconfirmed:
                        result['notice'] = '已退出本机；云端退出回执暂未确认，不会自动重试'
                    return result
                user, profile = self._identity(token)
                stores = self._stores(profile)
                self._save_selection(user, stores, data, apply=action == 'apply_preset')
                return self._bootstrap(identity=(user, profile))
            except EmployeeLoginRequired:
                raise WorkbenchError('EMPLOYEE_ONLY', '请使用企业员工账号登录；管理员请使用管理后台', 403) from None
            except IntegrationError as error:
                if getattr(error, 'http_status', None) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '账号或企业会话无效，请核对后重新登录', 401) from None
                raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                     '企业登录服务暂不可用，已保留本机状态，请稍后手动重试', 503) from None
