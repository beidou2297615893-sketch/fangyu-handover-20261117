param([switch]$ShowURL)
$ErrorActionPreference = 'Stop'
$activePath = Join-Path $PSScriptRoot 'state/active.json'
if (-not (Test-Path -LiteralPath $activePath -PathType Leaf)) {
    throw '请先打开桌面上的「方隅工作台」，再打开本地开发页。'
}
$active = Get-Content -LiteralPath $activePath -Raw | ConvertFrom-Json
if ($active.profile -ne 'production' -or $active.mode -ne 'shared-runtime') {
    throw '当前记录不是方隅正式本机后台，请先打开桌面工作台。'
}
$port = [int]$active.developmentPort
$stablePort = [int]$active.stablePort
if ($port -lt 1024 -or $port -gt 65535 -or $stablePort -lt 1024 -or $stablePort -gt 65535) {
    throw '本地后台端口记录无效。'
}
$developmentURL = 'http://127.0.0.1:' + $port + '/'
$stableURL = 'http://127.0.0.1:' + $stablePort + '/'
$devStatus = Invoke-RestMethod -Uri ($developmentURL + '__workbench_status') -TimeoutSec 4
$stableStatus = Invoke-RestMethod -Uri ($stableURL + '__workbench_status') -TimeoutSec 4
if ($devStatus.profile -ne 'production' -or $devStatus.mode -ne 'development' -or
    $stableStatus.mode -ne 'stable' -or $devStatus.instanceId -ne $active.instanceId -or
    $stableStatus.instanceId -ne $active.instanceId) {
    throw '网页与桌面后台身份不一致，请关闭失效开发页并重新打开工作台。'
}
if ($ShowURL) { $developmentURL } else { Start-Process -FilePath $developmentURL }
