"""Fixed 方隅 UI release entry; no business App import."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import stat
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
RELEASE = ROOT / 'releases/ui-r57-20261016T142224Z-2a659324'
MANIFEST_SHA256 = 'D5CA19948389EC80F4F195C71ABE0318A3AB475667E9F0AB112EEFA3AC38133A'
HOST_SHA256 = '4506F8BC6D3AB5A49C58EB8A1695F3663EEBB9433B51104F2A0C1E06050B24A5'

def pinned(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('界面启动路径不能是链接。')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('界面启动文件无效。')
    raw = path.read_bytes()
    after = path.stat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or hashlib.sha256(raw).hexdigest().upper() != expected):
        raise RuntimeError('界面版本校验失败，请恢复已固化版本。')
    return raw

def main():
    pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)
    source = pinned(RELEASE / 'ui_native_host.py', HOST_SHA256)
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_native_ui_host', loader=None))
    module.__file__ = str(RELEASE / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(source, module.__file__, 'exec'), module.__dict__)
    try:
        return module.main(RELEASE, MANIFEST_SHA256, ROOT / 'state', project_root=ROOT.parent.parent)
    except Exception as error:
        if any(arg in sys.argv for arg in ('--check', '--self-test')):
            raise
        module.notify_error(error)
        return 1

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        if any(arg in sys.argv for arg in ('--check', '--self-test')):
            print(json.dumps({'status': 'FAIL', 'error_type': type(error).__name__, 'message': str(error)}, ensure_ascii=False))
        elif os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, str(error), '方隅工作台 · 打开提示', 0x10)
        raise SystemExit(1)
