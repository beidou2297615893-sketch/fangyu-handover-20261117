"""Review or reversibly bind the one 方隅 desktop shortcut to this UI host.

Default is read-only. --install performs the switch; --restore RECEIPT restores
the exact previous shortcut bytes, only while our installed shortcut is intact.
"""
from pathlib import Path
import argparse
import ctypes
from contextlib import contextmanager
import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).absolute().parent
PROJECT = HERE.parent.parent
INSTALLS = HERE / 'desktop-installs'
FROZEN = HERE / 'FROZEN.json'
LAUNCHER = HERE / 'run_workbench.py'
OLD_LAUNCHER = PROJECT / 'work/ui-runtime-r55/run_workbench.py'
PYTHON = PROJECT / 'work/desktop-python/Scripts/python.exe'
PYTHONW = PROJECT / 'work/desktop-python/Scripts/pythonw.exe'
SHORTCUT = Path('C:/Users/rmsama/Desktop/方隅工作台.lnk')
OLD_ARGS = '-X utf8 -B -I "' + OLD_LAUNCHER.as_posix() + '"'
NEW_ARGS = '-X utf8 -B -I "' + LAUNCHER.as_posix() + '"'
SCHEMA = 'fangyu_native_ui_desktop_install_v1'


@contextmanager
def mutation_lock():
    """Reject concurrent changes to this one shortcut without writing lock files."""
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    kernel.CreateMutexW.restype = ctypes.c_void_p
    kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
    kernel.ReleaseMutex.restype = ctypes.c_int
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.restype = ctypes.c_int
    identity = str(SHORTCUT.absolute()).casefold().encode('utf-8')
    name = 'Local\\FangyuUiDesktopInstall_' + hashlib.sha256(identity).hexdigest()[:32]
    ctypes.set_last_error(0)
    handle = kernel.CreateMutexW(None, True, name)
    error = ctypes.get_last_error()
    if not handle:
        raise ctypes.WinError(error)
    if error == 183:  # ERROR_ALREADY_EXISTS: another install/restore owns it.
        kernel.CloseHandle(handle)
        raise ValueError('另一个方隅桌面安装或回退正在进行，请待其结束后重试。')
    try:
        yield
    finally:
        kernel.ReleaseMutex(handle)
        kernel.CloseHandle(handle)


def plain(path):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('安装路径不能是链接或重定向。')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('安装输入必须是独立普通文件。')
    return info


def read_pin(path, expected=None):
    before = plain(path)
    with Path(path).open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        ended = os.fstat(stream.fileno())
    after = plain(path)
    identity = lambda x: (x.st_dev, x.st_ino, x.st_size, x.st_mtime_ns)
    if not identity(before) == identity(opened) == identity(ended) == identity(after):
        raise ValueError('安装输入在检查时发生变化。')
    digest = hashlib.sha256(raw).hexdigest().upper()
    if expected is not None and digest != expected:
        raise ValueError('安装文件哈希已改变，保留现有文件。')
    return raw, {'size': len(raw), 'sha256': digest,
                 'file_identity': [after.st_dev, after.st_ino]}


def valid_digest(value):
    if not isinstance(value, str) or not re.fullmatch('[0-9A-F]{64}', value):
        raise ValueError('固化版本缺少有效哈希。')
    return value


def ps_quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def powershell(code):
    prefix = ("$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; "
              "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); ")
    child = subprocess.run(
        ['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', prefix + code],
        capture_output=True, encoding='utf-8', timeout=30,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if child.returncode:
        raise RuntimeError('桌面快捷方式 COM 操作失败。')
    return json.loads(child.stdout.lstrip('\ufeff'))


def shortcut_info(path):
    plain(path)
    return powershell(
        '$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut(' + ps_quote(path) + '); '
        '[ordered]@{target=$s.TargetPath;arguments=$s.Arguments;'
        'working_directory=$s.WorkingDirectory;icon=$s.IconLocation;'
        'window_style=$s.WindowStyle;description=$s.Description}|ConvertTo-Json -Compress')


def verify_shortcut(info, args):
    if (Path(info['target']) != PYTHONW or info['arguments'] != args
            or Path(info['working_directory']) != PROJECT):
        raise ValueError('桌面入口不属于预期方隅实例，保留现有快捷方式。')


def frozen_release():
    raw, frozen_pin = read_pin(FROZEN)
    report = json.loads(raw)
    release_id = report.get('release_id', '')
    if not re.fullmatch(r'ui-r57-\d{8}T\d{6}Z-[0-9a-f]{8}', release_id):
        raise ValueError('固化版本标识不匹配。')
    release = HERE / 'releases' / release_id
    if (report.get('status') != 'FROZEN' or Path(report['release']) != release
            or Path(report['launcher']) != LAUNCHER
            or Path(report['runtime']) != PYTHONW
            or report.get('business_data_access') is not False):
        raise ValueError('固化清单不属于本界面宿主。')
    _, launcher_pin = read_pin(LAUNCHER, valid_digest(report['launcher_sha256']))
    _, manifest_pin = read_pin(release / 'RELEASE.json', valid_digest(report['manifest_sha256']))
    plain(PYTHON)
    plain(PYTHONW)
    icon = release / 'resources/brand.ico'
    plain(icon)
    child = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', '-I', str(LAUNCHER), '--check'],
                           cwd=PROJECT, capture_output=True, encoding='utf-8', timeout=30,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if child.returncode:
        raise ValueError('固化界面启动器公开核验未通过。')
    check = json.loads(child.stdout)
    if (check.get('status') != 'PASS' or check.get('release_id') != release_id
            or check.get('native_windows_opened') != 0
            or check.get('business_app_imported') is not False):
        raise ValueError('启动器未返回预期的静态资源核验结果。')
    return {'release': release, 'release_id': release_id, 'icon': icon,
            'frozen_pin': frozen_pin, 'launcher_pin': launcher_pin,
            'manifest_pin': manifest_pin, 'check': check}


def write_exclusive(path, raw):
    with Path(path).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def unchanged(path, pin):
    _, fresh = read_pin(path, pin['sha256'])
    if fresh['file_identity'] != pin['file_identity']:
        raise ValueError('文件已被其他操作替换，保留两个版本。')


def plan():
    release = frozen_release()
    old_bytes, old_pin = read_pin(SHORTCUT)
    original = shortcut_info(SHORTCUT)
    if original['arguments'] == NEW_ARGS:
        verify_shortcut(original, NEW_ARGS)
        status = 'ALREADY_BOUND'
    else:
        verify_shortcut(original, OLD_ARGS)
        status = 'READY_TO_INSTALL'
    unchanged(SHORTCUT, old_pin)
    report = {'status': status, 'mode': 'read-only-plan', 'shortcut': str(SHORTCUT),
              'current': {'pin': old_pin, 'fields': original},
              'intended': {'target': str(PYTHONW), 'arguments': NEW_ARGS,
                           'working_directory': str(PROJECT), 'icon': str(release['icon']) + ',0'},
              'release_id': release['release_id'], 'public_check': release['check'],
              'original_data_reads_or_writes': 0, 'native_windows_opened': 0}
    return report, release, old_bytes, old_pin, original


def install():
    with mutation_lock():
        return _install_locked()


def _install_locked():
    report, release, original_bytes, original_pin, original_fields = plan()
    if report['status'] == 'ALREADY_BOUND':
        return {**report, 'mode': 'install', 'shortcut_changed': False}
    backup = INSTALLS / uuid.uuid4().hex
    backup.mkdir(parents=True, exist_ok=False)
    # These exact bytes are the rollback source, not a reconstructed shortcut.
    write_exclusive(backup / 'original.lnk', original_bytes)
    write_exclusive(backup / 'original.json', json_bytes({
        'shortcut': str(SHORTCUT), 'pin': original_pin, 'fields': original_fields}))
    staged = backup / 'new.lnk'
    powershell(
        '$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut(' + ps_quote(staged) + '); '
        '$s.TargetPath=' + ps_quote(PYTHONW) + '; $s.Arguments=' + ps_quote(NEW_ARGS) + '; '
        '$s.WorkingDirectory=' + ps_quote(PROJECT) + '; '
        '$s.IconLocation=' + ps_quote(str(release['icon']) + ',0') + '; '
        "$s.WindowStyle=1; $s.Description='方隅工作台 · 图片界面'; "
        '$s.Save(); @{saved=$true}|ConvertTo-Json -Compress')
    staged_fields = shortcut_info(staged)
    verify_shortcut(staged_fields, NEW_ARGS)
    _, staged_pin = read_pin(staged)
    # Recheck all pins and identities immediately before the one atomic switch.
    unchanged(FROZEN, release['frozen_pin'])
    unchanged(LAUNCHER, release['launcher_pin'])
    unchanged(release['release'] / 'RELEASE.json', release['manifest_pin'])
    unchanged(staged, staged_pin)
    unchanged(SHORTCUT, original_pin)
    os.replace(staged, SHORTCUT)
    _, actual_pin = read_pin(SHORTCUT, staged_pin['sha256'])
    actual_fields = shortcut_info(SHORTCUT)
    verify_shortcut(actual_fields, NEW_ARGS)
    if actual_fields != staged_fields:
        raise ValueError('切换后的快捷方式字段不一致，请保留备份并检查。')
    receipt_path = backup / 'receipt.json'
    receipt = {'schema': SCHEMA, 'status': 'INSTALLED',
               'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'shortcut': str(SHORTCUT), 'backup': str(backup),
               'previous': {'pin': original_pin, 'fields': original_fields},
               'current': {'pin': actual_pin, 'fields': actual_fields},
               'launcher': {'path': str(LAUNCHER), **release['launcher_pin']},
               'manifest': {'path': str(release['release'] / 'RELEASE.json'), **release['manifest_pin']},
               'release_id': release['release_id'], 'public_check': release['check'],
               'original_source_writes': 0, 'original_data_reads_or_writes': 0,
               'app_launches': 0, 'GUI_verified': False,
               'restore_command': '& ' + ps_quote(PYTHON) + ' -X utf8 -B -I '
                                  + ps_quote(Path(__file__).absolute()) + ' --restore '
                                  + ps_quote(receipt_path)}
    write_exclusive(receipt_path, json_bytes(receipt))
    restore_script = (receipt['restore_command'] + '\nexit $LASTEXITCODE\n').encode('utf-8-sig')
    write_exclusive(backup / 'restore.ps1', restore_script)
    return {**receipt, 'receipt': str(receipt_path), 'restore_script': str(backup / 'restore.ps1')}


def restore(receipt_path):
    with mutation_lock():
        return _restore_locked(receipt_path)


def _restore_locked(receipt_path):
    receipt_path = Path(receipt_path).absolute()
    if (receipt_path.name != 'receipt.json' or receipt_path.parent.parent != INSTALLS
            or not re.fullmatch('[0-9a-f]{32}', receipt_path.parent.name)):
        raise ValueError('仅可使用本宿主生成的桌面安装回执。')
    raw, receipt_pin = read_pin(receipt_path)
    receipt = json.loads(raw)
    backup = receipt_path.parent
    if (receipt.get('schema') != SCHEMA or receipt.get('status') != 'INSTALLED'
            or Path(receipt['shortcut']) != SHORTCUT or Path(receipt['backup']) != backup):
        raise ValueError('回退回执不属于唯一方隅桌面入口。')
    previous_pin = receipt['previous']['pin']
    current_pin = receipt['current']['pin']
    verify_shortcut(receipt['previous']['fields'], OLD_ARGS)
    verify_shortcut(receipt['current']['fields'], NEW_ARGS)
    original_bytes, backup_pin = read_pin(backup / 'original.lnk', valid_digest(previous_pin['sha256']))
    if shortcut_info(backup / 'original.lnk') != receipt['previous']['fields']:
        raise ValueError('原始快捷方式备份字段不一致。')
    _, current = read_pin(SHORTCUT, valid_digest(current_pin['sha256']))
    # Do not overwrite a byte-identical shortcut installed by another writer.
    if current['file_identity'] != current_pin['file_identity']:
        raise ValueError('桌面入口已被其他操作替换，未执行回退。')
    if shortcut_info(SHORTCUT) != receipt['current']['fields']:
        raise ValueError('当前桌面入口字段已改变，未执行回退。')
    staged = backup / ('restore-' + uuid.uuid4().hex + '.lnk')
    write_exclusive(staged, original_bytes)
    _, staged_pin = read_pin(staged, previous_pin['sha256'])
    if shortcut_info(staged) != receipt['previous']['fields']:
        raise ValueError('回退候选字段不一致。')
    unchanged(receipt_path, receipt_pin)
    unchanged(backup / 'original.lnk', backup_pin)
    unchanged(staged, staged_pin)
    unchanged(SHORTCUT, current_pin)
    os.replace(staged, SHORTCUT)
    _, restored_pin = read_pin(SHORTCUT, previous_pin['sha256'])
    restored_fields = shortcut_info(SHORTCUT)
    if restored_fields != receipt['previous']['fields']:
        raise ValueError('恢复后的快捷方式字段不一致。')
    result = {'schema': SCHEMA, 'status': 'RESTORED',
              'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'shortcut': str(SHORTCUT), 'receipt': str(receipt_path),
              'current': {'pin': restored_pin, 'fields': restored_fields},
              'original_data_reads_or_writes': 0, 'app_launches': 0}
    write_exclusive(backup / ('restored-' + uuid.uuid4().hex + '.json'), json_bytes(result))
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--install', action='store_true', help='备份并原子改指唯一方隅桌面入口')
    group.add_argument('--restore', metavar='RECEIPT', help='按安装回执恢复原始快捷方式字节')
    options = parser.parse_args(argv)
    if options.restore:
        result = restore(options.restore)
    elif options.install:
        result = install()
    else:
        result = plan()[0]
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({'status': 'FAIL', 'error_type': type(error).__name__,
                          'message': str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
