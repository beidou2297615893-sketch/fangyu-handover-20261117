﻿& 'C:\积木软件工坊\项目\方隅公寓客户版\work\desktop-python\Scripts\python.exe' -X utf8 -B -I 'C:\积木软件工坊\项目\方隅公寓客户版\work\ui-native-r57\install_desktop.py' --restore 'C:\积木软件工坊\项目\方隅公寓客户版\work\ui-native-r57\desktop-installs\4185106d078448aebd21012cdfc9d56c\receipt.json'
exit $LASTEXITCODE
