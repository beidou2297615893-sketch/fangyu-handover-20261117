const {chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright');
const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');const {createServer,calls}=require('./preview.cjs');
const OUT='C:/积木软件工坊/项目/方隅公寓客户版/work/ui-approved-implementation/screenshots';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1586,height:992},deviceScaleFactor:1});const errors=[],responses=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)responses.push({url:r.url(),status:r.status()});});
 try{await page.goto(origin+'/workspace');await page.waitForFunction(()=>!!window.__approvedTest,{timeout:20000});
 const preservation=await page.evaluate(()=>{const all=Array.from(document.querySelectorAll('[id]')).map(n=>n.id);return {original:window.__beforeUI.length,missing:window.__beforeUI.filter(x=>document.getElementById(x.id)!==x.node).map(x=>x.id),attrs:window.__beforeUI.filter(x=>['required','type','name'].some(k=>x.node[k]!==x[k])).map(x=>x.id),duplicates:all.filter((x,i)=>all.indexOf(x)!==i)};});assert.deepEqual(preservation.missing,[]);assert.deepEqual(preservation.attrs,[]);assert.deepEqual(preservation.duplicates,[]);
 await page.waitForTimeout(250);await page.screenshot({path:path.join(OUT,'01-login.png')});await page.evaluate(async()=>{const t=window.__approvedTest;const rows=t.populate();const a=document.getElementById('owner-account');const o=document.createElement('option');o.value='fixture_xhs';o.textContent='隔离测试账号';a.append(o);a.value=o.value;await t.openAcquisition(rows[0],false);});
 for(const [name,route,view]of [['02-acquire','tasks',null],['03-reply','leads','replies'],['04-customers','leads','customers'],['05-presets','management',null]]){
  await page.evaluate(({route,view})=>{const t=window.__approvedTest;t.show(route);if(view)t.approvedUI.customers.setView(view);t.approvedUI.sync(route);},{route,view});
  await page.waitForTimeout(200);await page.screenshot({path:path.join(OUT,name+'.png'),fullPage:false});
 }
 const navigation=await page.locator('.nav-main').innerText();
 await page.getByRole('button',{name:'浦江店',exact:false}).click();assert.match(await page.locator('.approved-branch-state').innerText(),/浦江/);
 await page.getByRole('button',{name:'服务与账号设置',exact:true}).click();assert.equal(await page.locator('#approved-existing-settings').isVisible(),true);await page.getByRole('button',{name:'门店预设',exact:true}).click();
 await page.evaluate(()=>{const t=window.__approvedTest;t.show('leads');t.approvedUI.customers.setView('customers');});
 await page.setViewportSize({width:1100,height:800});await page.screenshot({path:path.join(OUT,'06-customers-1100.png')});
 const overflow=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));
 const report={preservation,errors,responses,apiRequests:calls.length,navigation,overflow,screenshots:fs.readdirSync(OUT)};fs.writeFileSync(path.join(OUT,'../browser-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));assert.equal(errors.length,0);assert.equal(responses.length,0);assert.equal(calls.length,0);
 }finally{await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
