param([switch]$NoBrowser)
$ErrorActionPreference='Stop'
$taskAddress='http://127.0.0.1:57857'
try { $taskHealth=Invoke-RestMethod -Uri ($taskAddress+'/__previewstatus') -TimeoutSec 2 } catch { $taskHealth=$null }
if($taskHealth -and $taskHealth.app -ne 'fangyu-ui-only'){throw 'Preview port is owned by another application.'}
if(-not $taskHealth){
  $taskListener=Get-NetTCPConnection -LocalPort 57857 -State Listen -ErrorAction SilentlyContinue
  if($taskListener){throw 'Port 57857 is busy; the existing application was not changed.'}
  $taskNode=(Get-Command node.exe -ErrorAction Stop).Source
  $taskServer=Join-Path $PSScriptRoot 'server.cjs'
  $taskEvidence=Join-Path $PSScriptRoot 'evidence'
  [void][System.IO.Directory]::CreateDirectory($taskEvidence)
  $taskProcess=Start-Process -FilePath $taskNode -ArgumentList ('"'+$taskServer+'"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $taskEvidence 'server.stdout.log') -RedirectStandardError (Join-Path $taskEvidence 'server.stderr.log') -PassThru
  $taskProcess.Id | Set-Content -LiteralPath (Join-Path $taskEvidence 'server.pid') -Encoding ascii
  foreach($taskTry in 1..12){try{$taskHealth=Invoke-RestMethod -Uri ($taskAddress+'/__previewstatus') -TimeoutSec 1;break}catch{Start-Sleep -Milliseconds 200}}
  if(-not $taskHealth -or $taskHealth.app -ne 'fangyu-ui-only'){throw 'Preview did not start. See evidence/server.stderr.log.'}
}
if(-not $NoBrowser){Start-Process ($taskAddress+'/#acquire')}
Write-Output ($taskAddress+'/#acquire')
