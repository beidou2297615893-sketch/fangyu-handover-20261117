// Only the exact saved-media route is fetched. Portraits are never guessed.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const FALLBACK='/assets/approved-icon-user-round.svg',COVER='/assets/tabler-external-link.svg';
function savedMediaUrl(value,kinds){
  if(typeof value!=='string'||value.length>2048||/[\s\u0000-\u001f\u007f]/.test(value))return '';
  try{
    const url=new URL(value,location.origin),keys=[...url.searchParams.keys()];
    if(url.origin!==location.origin||url.pathname!=='/api/workbench/media'||url.hash||url.username||url.password
      ||keys.length!==3||new Set(keys).size!==3||keys.some(key=>!['storeId','leadId','kind'].includes(key))
      ||!kinds.includes(url.searchParams.get('kind'))||!(/^[A-Za-z0-9_-]{1,80}$/).test(url.searchParams.get('storeId')||'')
      ||!(/^(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})$/i).test(url.searchParams.get('leadId')||''))return '';
    return url.pathname+url.search;
  }catch{return '';}
}
let mediaScope='',generation=0,observer=null,running=0,totalBytes=0;
const cache=new Map(),pending=new Map(),queue=[],failures=new Map(),controllers=new Set();
const MAX_BYTES=8*1024*1024,MAX_ITEMS=120;
export function setCustomerMediaScope(value){
  const next=String(value||'');if(next===mediaScope)return;
  mediaScope=next;generation++;observer?.disconnect();
  for(const controller of controllers)controller.abort();controllers.clear();

  cache.clear();failures.clear();pending.clear();queue.length=0;totalBytes=0;
}
export function customerAvatarUrl(value){return savedMediaUrl(value,['author','post_author']);}
export function postCover(person,cls='',style=''){
  const url=savedMediaUrl(person?.coverUrl,['cover']);
  return `<img class="${cls}"${style?` style="${style}"`:''} src="${COVER}" alt="${url?'原帖图片加载中':'原帖未保存图片'}" decoding="async" referrerpolicy="no-referrer" data-post-cover${url?` data-saved-media="${esc(url)}" data-cover-remote`:''}>`;
}
export function customerAvatar(person,cls='',style=''){
  const url=customerAvatarUrl(person?.avatarUrl);
  return `<img class="${cls}"${style?` style="${style}"`:''} src="${FALLBACK}" alt="${url?esc((person?.name||'客户')+'的头像加载中'):''}" decoding="async" referrerpolicy="no-referrer" data-customer-avatar${url?` data-saved-media="${esc(url)}" data-avatar-remote`:''}>`;
}
function remember(key,url){
  const entry={url,size:url.length,at:Date.now()};cache.set(key,entry);totalBytes+=entry.size;
  while(cache.size>MAX_ITEMS||totalBytes>MAX_BYTES){const [old,value]=cache.entries().next().value;cache.delete(old);totalBytes-=value.size;}
  return cache.get(key)?.url||'';
}
function pump(){
  while(running<3&&queue.length){
    const job=queue.shift();if(job.generation!==generation||!job.alive.some(check=>check())){pending.delete(job.key);job.resolve('');continue;}
    running++;
    (async()=>{
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),9000);controllers.add(controller);
      try{
        const response=await fetch(job.key,{credentials:'same-origin',cache:'no-store',signal:controller.signal});
        if(!response.ok||!/^image\/(?:png|jpeg|webp)(?:;|$)/i.test(response.headers.get('content-type')||''))throw new Error('saved image unavailable');
        const blob=await response.blob();if(!blob.size||blob.size>3*1024*1024)throw new Error('saved image unavailable');
        if(job.generation!==generation)return '';
        const url=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});
        if(job.generation!==generation||typeof url!=='string'||!/^data:image\/(?:png|jpeg|webp);base64,/i.test(url))return '';
        return remember(job.key,url);
      }catch{if(job.generation===generation)failures.set(job.key,Date.now());return '';}
      finally{clearTimeout(timer);controllers.delete(controller);}
    })().then(job.resolve).finally(()=>{if(pending.get(job.key)?.promise===job.promise)pending.delete(job.key);running--;pump();});
  }
}
function request(key,alive){
  const previous=cache.get(key);if(previous&&Date.now()-previous.at>60000){cache.delete(key);totalBytes-=previous.size;}
  if(cache.has(key)){const value=cache.get(key);cache.delete(key);cache.set(key,value);return Promise.resolve(value.url);}
  if(Date.now()-(failures.get(key)||0)<15000)return Promise.resolve('');
  if(pending.has(key)){const job=pending.get(key);job.alive.push(alive);return job.promise;}
  let resolve;const promise=new Promise(done=>resolve=done),job={key,generation,resolve,promise,alive:[alive]};pending.set(key,job);
  queue.push(job);pump();return promise;
}
export function bindCustomerAvatars(root){
  observer?.disconnect();const boundGeneration=generation;
  const load=image=>{
    observer?.unobserve(image);const key=image.dataset.savedMedia;if(!key)return;
    const alive=()=>image.isConnected&&boundGeneration===generation;
    image.dataset.mediaState='loading';
    request(key,alive).then(url=>{if(!alive())return;image.dataset.mediaState=url?'ready':'unavailable';if(url){image.src=url;image.alt=image.hasAttribute('data-post-cover')?'原帖图片':'已保存的客户头像';}else{image.alt=image.hasAttribute('data-post-cover')?'原帖图片暂不可用':'';}});
  };
  if(typeof IntersectionObserver==='function')observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting)load(entry.target);},{rootMargin:'96px'});
  for(const image of root.querySelectorAll('[data-saved-media]')){
    if(cache.has(image.dataset.savedMedia)){load(image);continue;}
    if(observer)observer.observe(image);else load(image);
  }
}



