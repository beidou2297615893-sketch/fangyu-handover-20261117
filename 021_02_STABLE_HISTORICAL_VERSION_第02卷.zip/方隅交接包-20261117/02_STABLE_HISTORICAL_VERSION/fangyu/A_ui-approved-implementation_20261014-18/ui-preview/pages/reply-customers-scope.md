# 回复与客户页修改范围

独占文件：reply.mjs、reply.css、customers.mjs、customers.css，以及本范围与阶段记录。

视觉目标：outputs/新UI第三轮（完整修订）/03-意向回复.png、04-客户工作台.png。

仅实现隔离本地界面与示例交互，不调用真实采集、AI、发送、导出或客户接口，不修改其他实例。

接口：render(state) → HTML；bind(root, ctx)；ctx.update(mutator) 修改状态并重渲染。

state.reply：tab、groupBy、query、selectedId、identity、tone、draft、evidenceOpen、sentIds、savedDrafts、collapsedGroups。
state.customers：query、sort、filter、selectedId、checkedIds、evidenceOpen、handedOffIds、repliedIds。

头像约定：/assets/portrait-woman-1.png、portrait-man-1.png、portrait-woman-2.png、portrait-dog.png。由主任务集中准备合适的独立肖像资产。帖子缩略图使用已有独立公寓摄影 fy-login-apartment-photo.webp。
