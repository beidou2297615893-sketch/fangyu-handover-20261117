# 获客与门店预设 · 独立实施记录

范围：仅 acquire.mjs / acquire.css / presets.mjs / presets.css 及本记录。不修改 r55、r56、入口、真实数据或其他模块。

视觉依据：实际打开 `outputs/新UI第三轮（完整修订）/02-获客截流.png` 与 `05-门店获客预设.png`；使用现有原生 HTML/CSS、已保存 Lucide/Tabler 资产及公寓图片，按两图的表单横排、留白、四阶段进度、最新意向两行、门店卡及双列方案实现。

接口：两页均 export render(state), bind(root,ctx)。ctx 为主任务约定的 state/update/navigate/toast/modal。bind 返回清理函数；获客定时器在每次bind时清理，离开后通过mount.isConnected拒绝推进，不会叠加定时器。

state：共享store；acquire含region/time/platforms/status/stage/tick/read/added/analyzed/duplicates/records；presets含search/intent/tab/showWords/showRules。默认路由 acquire/presets/customers。

演示：仅本地状态。开始后每1250ms推进一个阶段刻度，约9秒完成；暂停/继续；查看记录可模拟中断、再重试；最新意向跳客户；预设方案/搜索词库/规则及应用预设回获客可交互。未导入真实账号/平台/模型/发送，不使用fetch。

验证：Node语法与多状态render检查PASS（idle/paused/failed/浦江组合/近期入住规则/规则tab）。待主任务 IAB 图审与交互核验，不使用Playwright/原App。文件创建不等同视觉验收或用户认可。

快速审查修正：采集中/暂停时冻结本次范围与平台；run保存本次门店范围快照，切换门店或应用新预设先结束旧演示并重置进度，避免旧进度归入新门店。两个自有模块再次Node语法检查通过。未改主任务app/server或回复/客户模块。
