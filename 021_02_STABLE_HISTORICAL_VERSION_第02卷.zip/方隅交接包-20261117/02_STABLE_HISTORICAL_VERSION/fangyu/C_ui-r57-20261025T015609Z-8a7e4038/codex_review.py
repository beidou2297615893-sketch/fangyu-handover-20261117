"""Read-only, employee/store-scoped Codex review references.

This private sidecar never grades an original lead, grants reply permission,
updates a draft, or calls a model/platform. Every review is bound to unchanged
original evidence that already passed the customer history visibility boundary.
"""
from copy import deepcopy
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat

SCHEMA = 'fangyu-codex-review-batch-v1'
SUPPLEMENTAL_SCHEMA = 'fangyu-codex-review-supplemental-v2'
MAX_BYTES = 16 * 1024 * 1024
MAX_CUSTOMERS = 3000
KEY = re.compile(r'[0-9a-f]{64}\Z')
ANCHOR_FIELDS = ('leadId','platform','authorId','taskId','storeId','text','title','parent')
REVIEW_FIELDS = {'provider','humanConfirmed','batchId','reviewedAt','intentLevel',
    'intentLabel','followUpGroup','priority','reason','evidenceLeadId','evidenceQuote',
    'leaseGroup','unknown','suggestedReply','needsConfirmation'}


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _string(value, limit, *, required=False):
    if (not isinstance(value,str) or len(value)>limit or '\x00' in value
            or required and not value.strip()):
        raise ValueError('invalid review text')
    return value


def _timestamp(value):
    value=_string(value,100,required=True)
    parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
    if parsed.tzinfo is None:raise ValueError('review timestamp has no timezone')
    return value


def _pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate JSON key')
        result[key]=value
    return result


def _reject_constant(_value):
    raise ValueError('invalid JSON constant')


def _regular(info, *, directory=False):
    if (getattr(info,'st_file_attributes',0) & 0x400
            or (not stat.S_ISDIR(info.st_mode) if directory else
                not stat.S_ISREG(info.st_mode) or info.st_nlink != 1)):
        raise ValueError('private review is not a plain local file')


def _read(directory, filename='latest.json', *, with_size=False):
    """Bounded descriptor read; reject links/reparse points and raced files."""
    folder=Path(directory)/'codex-reviews'
    path=folder/filename
    _regular(folder.lstat(),directory=True)
    before=path.lstat();_regular(before)
    if before.st_size>MAX_BYTES:raise ValueError('private review is too large')
    flags=os.O_RDONLY | getattr(os,'O_BINARY',0) | getattr(os,'O_NOFOLLOW',0)
    descriptor=os.open(path,flags)
    try:
        opened=os.fstat(descriptor);_regular(opened)
        if (opened.st_dev,opened.st_ino)!=(before.st_dev,before.st_ino):
            raise ValueError('private review changed while opening')
        with os.fdopen(descriptor,'rb',closefd=False) as stream:
            raw=stream.read(MAX_BYTES+1)
        after=os.fstat(descriptor);named=path.lstat();_regular(named)
        if (len(raw)>MAX_BYTES or len(raw)!=opened.st_size or
                (after.st_size,after.st_mtime_ns)!=(opened.st_size,opened.st_mtime_ns) or
                (named.st_dev,named.st_ino)!=(opened.st_dev,opened.st_ino)):
            raise ValueError('private review changed while reading')
    finally:
        os.close(descriptor)
    parsed=json.loads(raw.decode('utf-8-sig'),object_pairs_hook=_pairs,
        parse_constant=_reject_constant)
    return (parsed,len(raw)) if with_size else parsed


def _projection(review, anchors, batch):
    if not isinstance(review,dict) or set(review)-REVIEW_FIELDS:
        raise ValueError('invalid review projection')
    if (review.get('provider','Codex')!='Codex' or
            review.get('humanConfirmed',False) is not False or
            review.get('needsConfirmation',True) is not True or
            type(review.get('priority')) is not bool or
            review.get('intentLevel') not in ('super_high','high','medium','low',
                'very_low','uncertain','unrelated','pending')):
        raise ValueError('invalid review provenance')
    result={name:_string(review.get(name),limit,required=required) for name,limit,required in (
        ('intentLevel',40,True),('intentLabel',80,True),('followUpGroup',160,True),
        ('reason',8000,True),('evidenceLeadId',256,True),('evidenceQuote',32000,True),
        ('leaseGroup',160,True),('suggestedReply',8000,False))}
    evidence=next((anchor for anchor in anchors if anchor['leadId']==result['evidenceLeadId']),None)
    if evidence is None or result['evidenceQuote'] not in evidence['text']:
        raise ValueError('review evidence is not in its original comment')
    unknown=review.get('unknown')
    if not isinstance(unknown,list) or len(unknown)>50:
        raise ValueError('invalid pending confirmations')
    result.update(provider='Codex',humanConfirmed=False,needsConfirmation=True,
        batchId=batch['batchId'],reviewedAt=batch['reviewedAt'],
        priority=review['priority'],unknown=[_string(v,1000,required=True) for v in unknown])
    return result


def _validate(batch):
    if (batch.get('schema')!=SCHEMA or batch.get('provider')!='Codex'
            or batch.get('humanConfirmed') is not False):
        raise ValueError('unsupported review batch')
    return _validate_customers(batch,_projection)


def _validate_customers(batch, projection):
    _string(batch.get('batchId'),160,required=True)
    _timestamp(batch.get('reviewedAt'))
    customers=batch.get('customers')
    if not isinstance(customers,list) or len(customers)>MAX_CUSTOMERS:
        raise ValueError('invalid review batch size')
    result={};lead_ids=set()
    for customer in customers:
        if not isinstance(customer,dict) or set(customer)-{'customerId','platform','review','anchors'}:
            raise ValueError('invalid review customer')
        ident=customer.get('customerId');platform=customer.get('platform')
        if (not isinstance(ident,str) or not KEY.fullmatch(ident) or ident in result
                or platform not in ('xiaohongshu','douyin')):
            raise ValueError('invalid review customer identity')
        anchors=customer.get('anchors')
        if not isinstance(anchors,list) or not 1<=len(anchors)<=500:
            raise ValueError('invalid original evidence set')
        normalized=[]
        for anchor in anchors:
            if not isinstance(anchor,dict) or set(anchor)!=set(ANCHOR_FIELDS)|{'sourceDigest'}:
                raise ValueError('invalid original evidence')
            original={name:_string(anchor[name],32000 if name in ('text','title','parent') else 256,
                required=name in ('leadId','platform','authorId','storeId')) for name in ANCHOR_FIELDS}
            key=hashlib.sha256(json.dumps((platform,'uid',original['authorId']),
                ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()
            if (original['platform']!=platform or key!=ident or original['storeId']!=batch['storeId']
                    or original['leadId'] in lead_ids or anchor['sourceDigest']!=_digest(original)):
                raise ValueError('original evidence identity mismatch')
            lead_ids.add(original['leadId']);normalized.append(original)
        result[ident]={'platform':platform,'anchors':normalized,
            'review':projection(customer.get('review'),normalized,batch)}
    return result


def _supplemental_projection(review, anchors, batch):
    """Historical references only; no newly approved priority or reply draft."""
    if (not isinstance(review,dict)
            or set(review)-REVIEW_FIELDS-{'demandState','evidenceKind'}
            or review.get('provider','Codex')!='Codex'
            or review.get('humanConfirmed',False) is not False
            or review.get('needsConfirmation',True) is not True
            or review.get('priority') is not False
            or review.get('suggestedReply')!=''):
        raise ValueError('invalid supplemental review provenance')
    level=review.get('intentLevel')
    state={'high':'historical','medium':'historical','low':'historical',
        'uncertain':'unknown','unrelated':'unrelated','ended':'ended'}.get(level)
    kind=review.get('evidenceKind')
    if state is None or review.get('demandState')!=state or kind not in ('text','non_text'):
        raise ValueError('invalid supplemental demand state')
    result={name:_string(review.get(name),limit,required=required) for name,limit,required in (
        ('intentLevel',40,True),('intentLabel',80,True),('followUpGroup',160,True),
        ('reason',8000,True),('evidenceLeadId',256,True),('evidenceQuote',32000,kind=='text'),
        ('leaseGroup',160,True),('suggestedReply',8000,False))}
    evidence=next((a for a in anchors if a['leadId']==result['evidenceLeadId']),None)
    if evidence is None or result['evidenceQuote'] not in evidence['text']:
        raise ValueError('supplemental evidence is not an original comment')
    if kind=='non_text' and (result['evidenceQuote']!='' or state!='unknown'
            or any(a['text'].strip() for a in anchors)):
        raise ValueError('non-text evidence cannot claim a quote or demand')
    unknown=review.get('unknown')
    if not isinstance(unknown,list) or len(unknown)>50:
        raise ValueError('invalid supplemental confirmations')
    result.update(provider='Codex',humanConfirmed=False,needsConfirmation=True,
        batchId=batch['batchId'],reviewedAt=batch['reviewedAt'],priority=False,
        unknown=[_string(v,1000,required=True) for v in unknown],
        demandState=state,evidenceKind=kind)
    return result


def _validate_supplemental(batch):
    if (batch.get('schema')!=SUPPLEMENTAL_SCHEMA or batch.get('provider')!='Codex'
            or batch.get('humanConfirmed') is not False):
        raise ValueError('unsupported supplemental review batch')
    return _validate_customers(batch,_supplemental_projection)


def _read_reviews(core, actor, company_id, tenant_id, store_id, people, *,
        filename='latest.json', validate=_validate, reserved=None, reserved_leads=None,
        prior_bytes=0):
    """Return only references whose complete source context is still visible.

    `people` must come from the unchanged authenticated CustomerHistory build.
    Each batch and its source collections are read at most once. Counts are
    computed before user search/paging, in the
    current employee, store and platform range only.
    """
    summary={'available':False,'reviewed':0,'priority':0,'stale':0,
        'batchId':'','reviewedAt':'','notice':''}
    result={'summary':summary,'items':{},'stale':set(),
        '_customerIds':None,'_leadIds':set(),'_bytes':0,'_failed':False}
    try:
        batch,raw_size=_read(core.store.directory,filename,with_size=True)
        if not isinstance(batch,dict):raise ValueError('invalid review envelope')
        if any(batch.get(key)!=value for key,value in (
                ('companyId',company_id),('tenantId',tenant_id),
                ('owner',actor['username']),('storeId',store_id))):
            return result
        customers=validate(batch)
        lead_ids={anchor['leadId'] for row in customers.values() for anchor in row['anchors']}
        if reserved is not None and (set(customers)&reserved
                or lead_ids&(reserved_leads or set())
                or len(customers)+len(reserved)>MAX_CUSTOMERS
                or raw_size+prior_bytes>MAX_BYTES):
            raise ValueError('supplement conflicts with the primary review batch')
        result['_customerIds']=set(customers);result['_leadIds']=lead_ids;result['_bytes']=raw_size
        candidates={ident:customers[ident] for ident in people if ident in customers
            and people[ident].get('platform')==customers[ident]['platform']}
        if not candidates:return result
        summary.update(available=True,batchId=batch['batchId'],reviewedAt=batch['reviewedAt'])
        wanted={anchor['leadId'] for row in candidates.values() for anchor in row['anchors']}
        # History intentionally strips private ownership/store fields. Re-read
        # originals only after each ID passed that authenticated membership.
        leads={row['id']:row for row in core.store.list('leads',tenant_id)
            if row.get('id') in wanted and row.get('tenant_id')==tenant_id}
        task_ids={lead.get('task_id') for lead in leads.values() if lead.get('task_id')}
        tasks={row['id']:row for row in core.store.list('tasks',tenant_id)
            if row.get('id') in task_ids and row.get('tenant_id')==tenant_id}
        for ident, row in candidates.items():
            person=people[ident]
            visible={comment.get('lead_id') for comment in person.get('comments') or []}
            matches=True
            for anchor in row['anchors']:
                lead=leads.get(anchor['leadId']);task=tasks.get((lead or {}).get('task_id'),{})
                if (anchor['leadId'] not in visible or lead is None
                        or lead.get('cloud_owner') not in (None,'',actor['username'])
                        or task.get('cloud_owner') not in (None,'',actor['username'])):
                    matches=False;break
                current={'leadId':str(lead.get('id') or ''),
                    'platform':str(lead.get('platform') or ''),
                    'authorId':str(lead.get('author_id') or '').strip(),
                    'taskId':str(lead.get('task_id') or ''),
                    'storeId':str(lead.get('store_id') or task.get('store_id') or ''),
                    'text':str(lead.get('text') or ''),
                    'title':str(lead.get('content_title') or lead.get('title') or ''),
                    'parent':str(lead.get('parent_text') or '')}
                if current!=anchor:matches=False;break
            if matches:
                result['items'][ident]=deepcopy(row['review'])
                summary['reviewed']+=1
                summary['priority']+=int(row['review']['priority'])
            else:
                result['stale'].add(ident);summary['stale']+=1
        if summary['stale']:
            summary['notice']='部分复核原文已变化，请重新确认；旧回复参考已隐藏。'
    except FileNotFoundError:
        pass
    except (OSError,ValueError,TypeError,KeyError,OverflowError,RecursionError):
        result['_failed']=True;result['_customerIds']=None
        summary.update(available=False,reviewed=0,priority=0,stale=0,batchId='',reviewedAt='',
            notice='本次独立复核暂不可读取，原客户和原分析保持不变。')
        result['items'].clear();result['stale'].clear()
    return result


def read_reviews(core, actor, company_id, tenant_id, store_id, people):
    """Append one disjoint historical batch; bad supplements cannot hide v1."""
    original=_read_reviews(core,actor,company_id,tenant_id,store_id,people)
    reserved=original.pop('_customerIds');primary_bytes=original.pop('_bytes')
    reserved_leads=original.pop('_leadIds')
    original.pop('_failed')
    # A valid, same-scope primary batch owns its identities, including stale
    # entries. Supplemental data can never take their selection authority.
    if reserved is None:return original
    extra=_read_reviews(core,actor,company_id,tenant_id,store_id,people,
        filename='supplemental-v2.json',validate=_validate_supplemental,
        reserved=reserved,reserved_leads=reserved_leads,prior_bytes=primary_bytes)
    summary=original['summary'];addition=extra['summary']
    if extra['_failed']:
        message='补充复核暂不可读取，原复核和原客户保持不变。'
        summary['notice']=' '.join(v for v in (summary['notice'],message) if v)
    elif addition['available']:
        summary.update(available=True,
            supplementalReviewed=addition['reviewed'],
            supplementalBatchId=addition['batchId'],
            supplementalReviewedAt=addition['reviewedAt'])
        for name in ('reviewed','priority','stale'):summary[name]+=addition[name]
        if addition['notice'] and addition['notice'] not in summary['notice']:
            summary['notice']=' '.join(v for v in (summary['notice'],addition['notice']) if v)
        original['items'].update(extra['items']);original['stale'].update(extra['stale'])
    return original


def attach_review(item, review_result):
    """Add a separate reference without touching original analysis/permissions."""
    ident=item['id']
    if ident in review_result['items']:
        item['codexReview']=deepcopy(review_result['items'][ident])
    elif ident in review_result['stale']:
        item['codexReviewNotice']='本次复核原文已变化，请重新确认。'
    return item
