"""Explicit live child selection, original Native actor/store/device authority."""
from core.livestream_admission import LiveError,get
from core.livestream_sources import LivestreamSources,SOURCES
from core.livestream_transport import capture,control
import hashlib,time,uuid

MESSAGES={
 'LIVE_OBSERVER_MISSING':'所选直播窗口尚未准备受控接收脚本；本次没有保存消息，软件不会自动安装脚本',
 'LIVE_ROOM_MAPPING_REQUIRED':'所选直播窗口尚未取得对应房间的自然资料；请本人核对原直播页，再明确刷新窗口',
 'LIVE_ACCOUNT_UNCONFIRMED':'所选直播窗口的当前账号无法与采集账号核对；请本人核对这个窗口',
 'LIVE_SOCKET_UNCONFIRMED':'所选直播窗口尚无唯一且对应房间的直播连接；本次未接纳消息',
 'LIVE_SOURCE_CHANGED':'明确确认的直播窗口或房间资料已变化；请重新核对，不会自动换窗',
 'LIVE_TRANSPORT_MISSING':'原受控接收通道尚未接通；本次没有保存直播消息',
 'LIVE_RESULT_UNCONFIRMED':'原直播采集结果待核对；请保留原编号，不会自动重提',
}
def policy_reference(value):return {k:value[k] for k in ('tenant_id','owner','revision','digest','actor_fingerprint')}
def translate(value):
 if isinstance(value,dict) and value.get('state')=='rejected':
  code=value.get('code','LIVE_RESULT_UNCONFIRMED');return {**value,'message':MESSAGES.get(code,MESSAGES['LIVE_RESULT_UNCONFIRMED'])}
 return value
def dispatch(backend,action,data,token):
 if not isinstance(data,dict):raise LiveError('LIVE_INPUT_INVALID','直播参数需重新核对',400)
 with backend.lock:
  user,profile=backend._identity(token);store=backend._selected_store(user,profile);stores=backend._stores(profile)
  if data.get('storeId')!=store:raise LiveError('LIVE_SCOPE_FORBIDDEN','请选择当前已授权门店',403)
  def authority(db,actor,selected):
   session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
   return not backend.closed and session is not None and session['user_id']==actor['id'] and backend._load_selection(actor,stores,db)['storeId']==selected
  service=backend.core.livestream_admission()
  if action=='livestream_request_read':
   if set(data)!={'storeId','requestId'}:raise LiveError('LIVE_INPUT_INVALID','只可查询原直播采集编号',400)
   return {'livestream':service.read(user,store,data['requestId'],authority=authority)}
  from core.livestream_managed import ManagedLivestreamWindows
  managed=getattr(backend,'_livestream_managed_windows',None)
  if managed is None:
   runtime=backend.platform_runtime
   managed=ManagedLivestreamWindows(backend.core,lambda process:bool(runtime and runtime._verification_window_visible({'process':process})));backend._livestream_managed_windows=managed
  if action=='livestream_window_read':
   if set(data)!={'storeId','requestId'}:raise LiveError('LIVE_INPUT_INVALID','只可查询原直播窗口打开编号',400)
   return {'livestreamWindow':managed.read(user,store,None,data['requestId'],authority)}
  runtime=backend.platform_runtime
  if runtime is None:raise LiveError('LIVE_TRANSPORT_MISSING',MESSAGES['LIVE_TRANSPORT_MISSING'],503)
  account=runtime._account(user,data.get('accountId'))
  original={k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id','status','auth_generation','identity_revalidation_generation')}
 def guard():
  with backend.lock:
   actor,current_profile=backend._identity(token)
   if backend._selected_store(actor,current_profile)!=store or any(actor.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')):raise LiveError('LIVE_SCOPE_FORBIDDEN','员工或当前门店已变化，原结果保留',403)
   current=runtime._account(actor,account['id'])
   if any(current.get(k)!=v for k,v in original.items()):raise LiveError('LIVE_ACCOUNT_CHANGED','原账号或父窗口已变化',409)
   runtime.livestream_guard(actor,account['id'])
 from assistant.intent_rule_management import IntentRuleManagement,ENTITY as POLICY_ENTITY
 from core.intent_policy import task_analysis_rules,GUBEI_ANALYSIS_VERSION
 policy=IntentRuleManagement(backend.core,user['tenant_id'],user['username'],backend.company)
 store_row=next((v for v in stores if v['id']==store),{})
 directory=backend.core.store.directory/'accounts'/user['tenant_id']/account['id'];sources=LivestreamSources(backend.core)
 def send(operation,payload,g):return translate(control(backend.core.adapters,account,operation,payload,g,directory))
 if action=='livestream_window_prepare':
  if set(data)!={'storeId','accountId'}:raise LiveError('LIVE_INPUT_INVALID','请明确本人的采集账号',400)
  return {'livestreamWindow':managed.prepare(user,store,account,authority)}
 if action=='livestream_window_open':return {'livestreamWindow':managed.open(user,store,account,data,authority,guard)}
 if action=='livestream_sources_read':
  if set(data)-{'storeId','accountId','refreshWindows'} or type(data.get('refreshWindows',False)) is not bool:raise LiveError('LIVE_INPUT_INVALID','直播窗口读取参数无效',400)
  answer=sources.read(user,store,account,authority);answer.update(windows=[],windowsStatus='not_loaded',analysisContext={'city':store_row.get('city',''),'area':store_row.get('area',''),'notice':'按当前门店已保存规则判断；直播房间话题和客户所在地未知时不猜测匹配'})
  if data.get('refreshWindows'):
   guard();owner='live-windows:'+uuid.uuid4().hex;backend.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',owner)
   try:
    guard();value=send('connections',{'requestId':'live-windows-'+uuid.uuid4().hex},guard);guard()
    if value.get('contract')=='fangyu-live-connections-v1':answer.update(windows=value['windows'],windowsStatus='listed_unchecked')
    else:answer.update(windowsStatus='unavailable',code=value.get('code','LIVE_TRANSPORT_MISSING'),message=value.get('message',MESSAGES['LIVE_TRANSPORT_MISSING']))
   finally:backend.core.release_account_mode(account['id'],user['tenant_id'],owner)
  return {'livestreamSources':answer}
 if action=='livestream_source_select':
  if set(data)!={'storeId','accountId','webRid','liveConnId','expectedVersion','requestId','confirmed'}:raise LiveError('LIVE_SELECTION_INPUT_INVALID','只可提交本人明确选择的直播房间与窗口，不接受规则或身份凭据',400)
  snapshot=policy.snapshot(user);policy_row=backend.core.store.get(POLICY_ENTITY,policy.ident)
  local_version=GUBEI_ANALYSIS_VERSION if task_analysis_rules({'store_id':store,'city':store_row.get('city','')}) else None
  trusted={**data,'city':store_row.get('city',''),'area':store_row.get('area',''),'intentPolicySnapshot':policy_reference(snapshot),'localPromptVersion':local_version}
  def selected_authority(db,actor,selected):return authority(db,actor,selected) and get(db,POLICY_ENTITY,policy.ident,actor['tenant_id'])==policy_row
  def selected_guard():
   guard();policy.assert_snapshot(snapshot,user)
  return {'livestreamSelection':sources.select(user,store,account,trusted,selected_authority,selected_guard,lambda a,d,g:send('select',d,g))}
 if action!='livestream_capture' or set(data)!={'storeId','accountId','sourceId','expectedVersion','requestId','timeoutMs','confirmed'}:raise LiveError('LIVE_INPUT_INVALID','请先明确确认直播房间与窗口，再开始一次有界读取',400)
 source=sources.resolve(user,store,account,data,authority)
 try:
  if policy_reference(policy.snapshot(user))!=source.get('intentPolicySnapshot'):raise ValueError('changed')
 except ValueError:raise LiveError('LIVE_RULES_CHANGED','门店意向规则已变化，请重新确认直播来源；旧采集与分析编号保留',409) from None
 policy_row=backend.core.store.get(POLICY_ENTITY,policy.ident)
 if source.get('city')!=store_row.get('city','') or source.get('area')!=store_row.get('area',''):raise LiveError('LIVE_RULES_CHANGED','门店城市或区域已变化，请重新确认直播来源',409)
 def source_guard():
  guard()
  if policy_reference(policy.snapshot(user))!=source.get('intentPolicySnapshot'):raise LiveError('LIVE_RULES_CHANGED','门店意向规则已变化，保留原编号，请重新核对来源',409)
  latest=sources.resolve(user,store,account,data,authority)
  if latest!=source:raise LiveError('LIVE_SOURCE_CHANGED',MESSAGES['LIVE_SOURCE_CHANGED'],409)
 def source_authority(db,actor,selected):return authority(db,actor,selected) and get(db,SOURCES,source['id'],actor['tenant_id'])==source and get(db,POLICY_ENTITY,policy.ident,actor['tenant_id'])==policy_row
 request={'storeId':store,'accountId':account['id'],'webRid':source['webRid'],'requestId':data['requestId'],'timeoutMs':data['timeoutMs'],'confirmed':data['confirmed'],'sourceId':source['id'],'sourceVersion':source['version'],'liveConnId':source['liveConnId'],'bridgeSelectionId':source['bridgeSelectionId'],'city':source['city'],'area':source['area'],'intentPolicySnapshot':source['intentPolicySnapshot'],'localPromptVersion':source['localPromptVersion']}
 return {'livestream':service.capture(user,store,account,request,authority=source_authority,guard=source_guard,
  transport=lambda a,d,g:translate(capture(backend.core.adapters,a,d,g,directory)))}
