"""Customer-only DY continuation validation around the pinned original pipeline.

The original module and every non-DY caller remain unchanged. Only the private
DY copy's cursor validation/comparison helpers differ; collection order, guard
callbacks, checkpoints and comment mapping retain the original source bytes.
"""
import hashlib
import json
from pathlib import Path
import re

# Exact reviewed cross-search continuation source; keep the original code and
# module-identity checks below, including the private-copy equality check.
_PIPELINE_SHA='0DB864A35D74C2FB2CE445580FA4B1F0AE15742103BFBBD111CE66E6C1B985EC'
_PAGES_SHA='E47571AB9367D49C1D20390CD388BCF813EE126183A4DB152D58C062A9C61CEC'
_MAX_CURSOR_BYTES=1024*1024
_installed=None


def _unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate continuation key')
        result[key]=value
    return result


def _cursor(value, page_request):
    if type(value) is not str or not value:
        return ''
    try:
        if len(value)>_MAX_CURSOR_BYTES or len(value.encode('utf-8'))>_MAX_CURSOR_BYTES:
            return ''
        # Reject duplicate keys before using the original decoder. Canonical
        # serialization retains every parent-text character and queue order.
        decoded=json.loads(value,object_pairs_hook=_unique_object)
        state,_=page_request({'next_cursor':json.dumps(decoded,ensure_ascii=False,separators=(',',':'))})
        if (type(state) is not dict or set(state)!={'v','main_cursor','main_done','replies'}
                or type(state['v']) is not int or state['v']!=1
                or type(state['main_cursor']) is not str or re.fullmatch(r'[0-9]{1,12}',state['main_cursor']) is None
                or type(state['main_done']) is not bool or type(state['replies']) is not list
                or state['main_done'] and not state['replies']):
            return ''
        for reply in state['replies']:
            if (type(reply) is not dict or set(reply)!={'cid','cursor','text'}
                    or type(reply['cid']) is not str or re.fullmatch(r'[0-9]{1,24}',reply['cid']) is None
                    or type(reply['cursor']) is not str or re.fullmatch(r'[0-9]{1,12}',reply['cursor']) is None
                    or type(reply['text']) is not str):
                return ''
        result=json.dumps(state,ensure_ascii=False,separators=(',',':'),sort_keys=True,allow_nan=False)
        return result if len(result.encode('utf-8'))<=_MAX_CURSOR_BYTES else ''
    except (ValueError,TypeError,KeyError,UnicodeError,RecursionError,OverflowError):
        return ''


def install(project_root):
    """Install once into this customer's original engine, or fail closed."""
    global _installed
    from core import engine, pipeline, douyin_pages
    project=Path(project_root).resolve()
    source=project/'work/ui-runtime-r55/src/core/pipeline.py'
    pages=source.with_name('douyin_pages.py')
    if (Path(pipeline.__file__).resolve()!=source.resolve()
            or Path(engine.__file__).resolve()!=source.with_name('engine.py').resolve()
            or Path(douyin_pages.__file__).resolve()!=pages.resolve()
            or not source.resolve().is_relative_to(project)
            or not pages.resolve().is_relative_to(project)):
        raise RuntimeError('抖音分页组件来源不匹配，禁止装配')
    raw=source.read_bytes()
    if (hashlib.sha256(raw).hexdigest().upper()!=_PIPELINE_SHA
            or hashlib.sha256(pages.read_bytes()).hexdigest().upper()!=_PAGES_SHA):
        raise RuntimeError('抖音分页原组件版本不匹配，禁止装配')
    original=pipeline.collect_batch
    if _installed is not None:
        if (_installed['project']!=project or _installed['original'] is not original
                or _installed['dispatcher'] is not engine.collect_batch
                or _installed['original_code'] is not original.__code__
                or _installed['page_request'] is not douyin_pages.page_request
                or _installed['page_code'] is not douyin_pages.page_request.__code__):
            raise RuntimeError('抖音分页装配已改变，禁止叠加')
        return
    if (engine.collect_batch is not original or original.__globals__ is not pipeline.__dict__
            or Path(original.__code__.co_filename).resolve()!=source.resolve()
            or douyin_pages.page_request.__globals__ is not douyin_pages.__dict__
            or Path(douyin_pages.page_request.__code__.co_filename).resolve()!=pages.resolve()):
        raise RuntimeError('抖音分页入口已改变，禁止装配')
    namespace={'__name__':'core._fangyu_douyin_pipeline','__package__':'core','__file__':str(source)}
    exec(compile(raw,str(source),'exec'),namespace)
    if namespace['collect_batch'].__code__!=original.__code__:
        raise RuntimeError('抖音分页入口与原源码不一致，禁止装配')
    page_request=douyin_pages.page_request
    normalize=lambda value:_cursor(value,page_request)
    check_page=namespace['_check_page']
    advance_page=namespace['_advance_comment_page']

    def current(value):
        if value=='':return ''
        result=normalize(value)
        if not result:raise ValueError('抖音分页断点格式无效，已保留断点')
        return result

    def history(values):
        if type(values) not in (list,tuple):raise ValueError('抖音分页历史格式无效，已保留断点')
        result=[current(value) for value in values]
        if any(not value for value in result):raise ValueError('抖音分页历史格式无效，已保留断点')
        return result

    def checked(info,cursor,label,strict=False,history_values=()):
        return check_page(info,current(cursor),label,strict,history(history_values))

    def advanced(state,info):
        if info.get('has_more') is True:
            state['cursor']=current(state.get('cursor',''))
            state['cursor_history']=history(state.get('cursor_history',[]))
        return advance_page(state,info)

    namespace['_page_cursor']=normalize
    namespace['_check_page']=checked
    namespace['_advance_comment_page']=advanced
    private_collect=namespace['collect_batch']

    def dispatch(adapters,task,checkpoint,progress=None,*,before_read=None,fixed_sources=None):
        if task.get('platform')!='douyin':
            return original(adapters,task,checkpoint,progress,before_read=before_read,fixed_sources=fixed_sources)
        # Validate saved cursors before the original adapter can perform IO.
        current(task.get('next_cursor',''))
        saved=task.get('pipeline')
        if saved is not None:
            if type(saved) is not dict:raise ValueError('抖音分页断点格式无效，已保留断点')
            current(saved.get('cursor',''));history(saved.get('cursor_history',[]))
            for reply in saved.get('reply_queue',[]):
                current(reply.get('cursor',''));history(reply.get('cursor_history',[]))
            after=saved.get('after_replies')
            if isinstance(after,dict) and after.get('has_more') is True:current(after.get('cursor'))
        return private_collect(adapters,task,checkpoint,progress,before_read=before_read,fixed_sources=fixed_sources)

    # No binding is changed until source, entry and private-copy checks pass.
    _installed={'project':project,'original':original,'original_code':original.__code__,
        'dispatcher':dispatch,'page_request':page_request,'page_code':page_request.__code__}
    engine.collect_batch=dispatch


__all__=['install']
