"""No-network adapter over host-owned authentication and transport callbacks."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import uuid


class GatewayConfigurationError(RuntimeError):
    pass


_PINS_SHA256 = '234a26e788ee717d3645732a6a7a90404aaf0e6eb59c7010f24e2f5192e50f13'


def _load_pins():
    try:
        source = Path(__file__).resolve().with_name('trusted_method_pins.py')
        raw = source.read_bytes()
        if hashlib.sha256(raw).hexdigest() != _PINS_SHA256:
            raise ValueError('pins')
        namespace = {'__name__': '_verified_gateway_method_pins'}
        exec(compile(raw, 'verified-gateway-method-pins', 'exec'), namespace)
        return namespace['get_trusted_method'], namespace['trusted_method_digest']
    except (OSError, ValueError, TypeError, KeyError, SyntaxError) as exc:
        raise GatewayConfigurationError('trusted_method_pins_changed') from exc


_method, _method_digest = _load_pins()
_CONTEXT_KEYS = {'environment_id', 'company_id', 'tenant_id', 'store_id', 'account_id',
                 'platform', 'actor', 'device_id', 'expected_revision', 'expected_rules_version'}
_SCOPE_KEYS = ('tenant_id', 'store_id', 'account_id', 'platform', 'company_id', 'actor')
_ENVELOPE_KEYS = {'contract', 'requestId', 'taskId', 'scope', 'method', 'input', 'inputDigest', 'requirements'}
_GENERATION_KEYS = {'contract', 'request_id', 'task_id', 'input_digest', 'method_id',
    'method_digest', 'scope', 'state', 'result_available', 'output', 'execution_confirmed',
    'reservation_retained', 'retry_allowed', 'read_only', 'coverage', 'submission_id'}
_OPTIONAL_METADATA = {'context_digest', 'config_revision', 'rules_version', 'requires_revalidation', 'cache_hit'}
_GENERATION_REQUIRED = _GENERATION_KEYS - {'output', 'submission_id'}
_GENERATION_KEYS |= _OPTIONAL_METADATA


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()


def _text(value, maximum=200):
    if (type(value) is not str or not value.strip() or len(value) > maximum
        or any(unicodedata.category(c) in ('Cf', 'Cs') or ord(c) < 32 for c in value)):
        raise ValueError('invalid_binding')
    return value


def _identifier(value):
    value = _text(value, 160)
    if re.fullmatch(r'[A-Za-z0-9_.:-]+', value) is None:
        raise ValueError('invalid_identifier')
    return value


def _unknown(envelope):
    key = envelope.get('requestId') if isinstance(envelope, dict) else None
    return {'requestId': key if type(key) is str and len(key) <= 160 else '', 'state': 'unknown'}


def _context(callback):
    value = callback()
    if type(value) is not dict or set(value) != _CONTEXT_KEYS:
        raise ValueError('invalid_context')
    value = json.loads(_canonical(value))
    for key in _CONTEXT_KEYS - {'expected_revision'}:
        _text(value[key])
    if type(value['expected_revision']) is not int or not 0 <= value['expected_revision'] <= 2 ** 53 - 1:
        raise ValueError('invalid_revision')
    if value['platform'] not in ('xiaohongshu', 'douyin'):
        raise ValueError('invalid_platform')
    return value


class ContentGatewayAdapter:
    def __init__(self, transport=None, trusted_context=None):
        if not callable(transport) or not callable(trusted_context):
            raise GatewayConfigurationError('host_transport_and_context_required')
        self._transport = transport
        self._trusted_context = trusted_context

    def __call__(self, envelope):
        return self._dispatch(envelope, 'content_generate')

    def status(self, envelope):
        return self._dispatch(envelope, 'content_generate_status')

    def _wire(self, envelope, context, operation):
        if type(envelope) is not dict or set(envelope) != _ENVELOPE_KEYS:
            raise ValueError('invalid_envelope')
        if envelope['contract'] != 'fangyu-content-workflow-v1':
            raise ValueError('invalid_contract')
        required = {'platformActionsAllowed': False, 'humanReviewRequired': True, 'sourceTextIsUntrustedData': True}
        if type(envelope['requirements']) is not dict or _canonical(envelope['requirements']) != _canonical(required):
            raise ValueError('invalid_requirements')
        if type(envelope['scope']) is not dict or envelope['scope'] != {k: context[k] for k in _SCOPE_KEYS}:
            raise ValueError('context_scope_mismatch')
        request_id, task_id = _identifier(envelope['requestId']), _identifier(envelope['taskId'])
        method = envelope['method']
        if type(method) is not dict:
            raise ValueError('invalid_method')
        method_id = method.get('id')
        selected_digest = _digest(method)
        trusted_method = _method(method_id, selected_digest)
        if _canonical(method) != _canonical(trusted_method):
            raise ValueError('method_changed')
        if type(envelope['input']) is not dict:
            raise ValueError('invalid_input')
        input_json = _canonical(envelope['input'])
        if len(input_json.encode('utf-8')) > 160_000:
            raise ValueError('input_too_large')
        input_digest = hashlib.sha256(input_json.encode('utf-8')).hexdigest()
        if envelope['inputDigest'] != input_digest:
            raise ValueError('input_digest_mismatch')
        return {'environment_id': context['environment_id'], 'operation': operation,
            'request_id': request_id, 'submission_id': str(uuid.uuid4()),
            'scope': deepcopy(envelope['scope']), 'task_id': task_id,
            'method_id': method_id, 'method_digest': _method_digest(method_id, selected_digest),
            'input_json': input_json, 'input_digest': input_digest,
            'expected_device_id': context['device_id'], 'expected_revision': context['expected_revision'],
            'expected_rules_version': context['expected_rules_version']}

    def _dispatch(self, envelope, operation):
        unknown = _unknown(envelope)
        try:
            before = _context(self._trusted_context)
            wire = self._wire(envelope, before, operation)
            response = None
            try:
                response = self._transport(deepcopy(wire))
            except Exception:
                pass
            after = _context(self._trusted_context)
            if before != after:
                return unknown
            return self._response(response, wire, before, unknown)
        except Exception:
            # Never log provider/context exceptions or retry generation here.
            return unknown

    @staticmethod
    def _response(response, wire, context, unknown):
        if type(response) is not dict or set(response) != {'status', 'data'} or type(response['status']) is not int or not 200 <= response['status'] <= 599:
            return unknown
        data = response['data']
        if (type(data) is not dict or data.get('contract') != 'fangyu-workspace-v1'
            or data.get('environment_id') != context['environment_id'] or data.get('company_id') != context['company_id']):
            return unknown
        generation = data.get('content_generation')
        if (type(generation) is not dict or set(generation) - _GENERATION_KEYS
            or not _GENERATION_REQUIRED <= set(generation)
            or generation['contract'] != 'fangyu-content-generation-v1'):
            return unknown
        for key in ('request_id', 'task_id', 'input_digest', 'method_id', 'method_digest', 'scope'):
            if generation[key] != wire[key]:
                return unknown
        if (generation['retry_allowed'] is not False
            or generation['read_only'] is not (wire['operation'] == 'content_generate_status')
            or type(generation['result_available']) is not bool
            or generation['execution_confirmed'] is not None and type(generation['execution_confirmed']) is not bool
            or generation['reservation_retained'] is not None and type(generation['reservation_retained']) is not bool
            or generation['coverage'] not in ('stable_request_index_v1', 'current_submission')):
            return unknown
        if generation['coverage'] == 'current_submission' and generation.get('submission_id') != wire['submission_id']:
            return unknown
        if 'requires_revalidation' in generation and generation['requires_revalidation'] is not False:
            return unknown
        if 'config_revision' in generation and (type(generation['config_revision']) is not int or generation['config_revision'] != context['expected_revision']):
            return unknown
        if 'rules_version' in generation and generation['rules_version'] != context['expected_rules_version']:
            return unknown
        if 'context_digest' in generation and generation['context_digest'] is not None and (type(generation['context_digest']) is not str or re.fullmatch(r'[a-f0-9]{64}', generation['context_digest']) is None):
            return unknown
        if 'cache_hit' in generation and type(generation['cache_hit']) is not bool:
            return unknown
        if (response['status'] == 200 and generation['state'] == 'succeeded'
            and generation['result_available'] is True and generation['execution_confirmed'] is True
            and generation['reservation_retained'] is False):
            output = generation.get('output')
            # Match the frozen workflow core's _json_size, including separator spaces.
            if type(output) is dict and len(json.dumps(output, ensure_ascii=False, allow_nan=False).encode('utf-8')) <= 120_000:
                return {'requestId': wire['request_id'], 'state': 'succeeded', 'output': json.loads(_canonical(output))}
        if (generation['state'] == 'known_not_executed' and generation['result_available'] is False
            and generation['execution_confirmed'] is False and generation['reservation_retained'] is False
            and generation.get('output') is None):
            return {'requestId': wire['request_id'], 'state': 'known_not_executed'}
        return unknown
