"""Restricted, offline pypdf adapter. Source candidate, not a frozen distribution."""
from pathlib import Path
import hashlib,importlib,importlib.abc,importlib.util,io,json,sys,threading

MAX_PAGES=100
MAX_STREAM=2*1024*1024
MAX_TOTAL=8*1024*1024
MAX_OBJECTS=10000
_lock=threading.RLock()

class PdfTextError(ValueError):
    def __init__(self,code,message):super().__init__(message);self.code=code

def _fail(code,message):raise PdfTextError(code,message)

class _PinnedPdfLoader(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def __init__(self,folder,pins):self.folder=folder;self.pins=pins
    def find_spec(self,fullname,path=None,target=None):
        if not (fullname=='pypdf' or fullname.startswith('pypdf.')):return None
        # No crypto native extensions are needed: password-protected files are refused.
        if fullname in ('pypdf._crypt_providers._cryptography','pypdf._crypt_providers._pycryptodome'):raise ImportError('PDF preview uses the standard-library fallback only')
        rel=fullname.replace('.','/')
        package=rel+'/__init__.py' in self.pins
        rel=rel+'/__init__.py' if package else rel+'.py'
        if rel not in self.pins:raise ImportError('Unlisted PDF parser module')
        return importlib.util.spec_from_loader(fullname,self,is_package=package)
    def create_module(self,spec):return None
    def exec_module(self,module):
        rel=module.__name__.replace('.','/')
        rel=rel+'/__init__.py' if module.__spec__.submodule_search_locations is not None else rel+'.py'
        path=self.folder/rel;raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=self.pins[rel]['sha256']:_fail('KNOWLEDGE_PARSER_INVALID','PDF解析组件校验未通过')
        module.__file__=str(path)
        if module.__spec__.submodule_search_locations is not None:module.__path__=[str(path.parent)]
        exec(compile(raw,str(path),'exec'),module.__dict__)

def _library():
    folder=Path(__file__).resolve().parent/'knowledge_pdf_vendor'
    pinraw=(folder/'PINS.json').read_bytes()
    if hashlib.sha256(pinraw).hexdigest()!=PINS_SHA:_fail('KNOWLEDGE_PARSER_INVALID','PDF解析组件清单校验未通过')
    pins=json.loads(pinraw)
    if any(p.name=='__pycache__' or p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&0x400 for p in folder.rglob('*')):_fail('KNOWLEDGE_PARSER_INVALID','PDF解析组件含缓存或链接路径')
    actual={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    if actual!=set(pins)|{'PINS.json'}:_fail('KNOWLEDGE_PARSER_INVALID','PDF解析组件含未列文件')
    for rel,pin in pins.items():
        path=folder/rel
        if path.is_symlink() or any(p.is_symlink() for p in path.parents):_fail('KNOWLEDGE_PARSER_INVALID','PDF解析组件路径无效')
        raw=path.read_bytes()
        if len(raw)!=pin['size'] or hashlib.sha256(raw).hexdigest()!=pin['sha256']:_fail('KNOWLEDGE_PARSER_INVALID','PDF解析组件校验未通过')
    for name,module in list(sys.modules.items()):
        if name=='pypdf' or name.startswith('pypdf.'):
            try:Path(module.__file__).resolve().relative_to(folder.resolve())
            except (ValueError,TypeError,AttributeError):_fail('KNOWLEDGE_PARSER_INVALID','已有PDF解析组件来源不同，请独立重开')
    if 'pypdf' not in sys.modules:sys.meta_path.insert(0,_PinnedPdfLoader(folder,pins))
    library=importlib.import_module('pypdf')
    filters=importlib.import_module('pypdf.filters')
    for name in ('MAX_DECLARED_STREAM_LENGTH','MAX_ARRAY_BASED_STREAM_OUTPUT_LENGTH','LZW_MAX_OUTPUT_LENGTH','RUN_LENGTH_MAX_OUTPUT_LENGTH','ZLIB_MAX_OUTPUT_LENGTH','ZLIB_MAX_RECOVERY_INPUT_LENGTH'):
        setattr(filters,name,MAX_STREAM)
    if not getattr(filters,'_knowledge_restricted',False):
        original=filters.decode_stream_data
        def limited(stream):
            chain=stream.get('/Filter',[])
            if hasattr(chain,'get_object'):chain=chain.get_object()
            if not isinstance(chain,(list,tuple)):chain=[chain]
            if len(chain)>2 or any(str(x) not in ('/FlateDecode','/Fl','/ASCIIHexDecode','/AHx','/ASCII85Decode','/A85') for x in chain):
                _fail('KNOWLEDGE_PDF_FILTER','此PDF压缩方式暂不支持，请另存为普通文字PDF')
            raw=original(stream)
            if len(raw)>MAX_STREAM:_fail('KNOWLEDGE_FILE_LIMIT','PDF展开内容过大，请拆分')
            return raw
        filters.decode_stream_data=limited;filters._knowledge_restricted=True
    return library

def _has_inline_image(data):
    # BI is an operator token, not text inside unrelated binary font streams.
    delimiters=b'\x00\t\n\f\r ()<>[]{}/%'
    index=data.find(b'BI')
    while index>=0:
        end=index+2
        if (index==0 or data[index-1] in delimiters) and (end==len(data) or data[end] in delimiters):return True
        index=data.find(b'BI',end)
    return False

def _scan_plan(pdf,reader,images,empty_pages):
    # Only a bounded RGB/gray JPEG/Flate scan subset. No image decoding occurs
    # until the original complete active-object/attachment pass has finished.
    import math,zlib
    from PIL import Image
    if len(empty_pages)>10:_fail('KNOWLEDGE_FILE_LIMIT','一次最多提取10页扫描PDF，请拆分资料')
    root=reader.trailer['/Root']
    if any(k in root for k in ('/AcroForm','/OCProperties')):_fail('KNOWLEDGE_SCAN_FORMAT','含表单或图层的扫描PDF暂不支持，请另存为普通扫描PDF')
    if not images:_fail('KNOWLEDGE_EMPTY','这些PDF页面未识别到文字或可用扫描图像，请核对原文件')
    total_pixels=0;total_expanded=0
    def value(x):return x.get_object() if isinstance(x,pdf.generic.IndirectObject) else x
    def integer(x):
        x=value(x)
        if isinstance(x,bool) or not isinstance(x,int):_fail('KNOWLEDGE_SCAN_FORMAT','扫描图像尺寸或位深无法核对')
        return int(x)
    for obj in images:
        width=integer(obj.get('/Width'));height=integer(obj.get('/Height'));bits=integer(obj.get('/BitsPerComponent'))
        color=str(value(obj.get('/ColorSpace')))
        if color not in ('/DeviceRGB','/DeviceGray') or bits not in (1,8) or color=='/DeviceRGB' and bits!=8:_fail('KNOWLEDGE_SCAN_FORMAT','扫描PDF仅支持普通RGB或灰度图像，请重新另存')
        if not 0<width<=4096 or not 0<height<=4096 or width*height>12000000:_fail('KNOWLEDGE_FILE_LIMIT','扫描图像超过4096边长或1200万像素，请缩小资料')
        if any(k in obj for k in ('/SMask','/Mask','/ImageMask','/Alternates','/OPI','/Decode')):_fail('KNOWLEDGE_SCAN_FORMAT','扫描PDF含特殊图像遮罩或解码设置，请另存为普通扫描PDF')
        channels=3 if color=='/DeviceRGB' else 1;rowbytes=(width*channels*bits+7)//8;expanded=rowbytes*height
        total_pixels+=width*height;total_expanded+=expanded
        if expanded>12*1024*1024 or total_pixels>24000000 or total_expanded>24*1024*1024:_fail('KNOWLEDGE_FILE_LIMIT','扫描图像累计展开预算超限，请拆分资料')
        data=getattr(obj,'_data',None)
        if not isinstance(data,bytes) or not data or len(data)>2*1024*1024 or expanded/max(len(data),1)>200:_fail('KNOWLEDGE_FILE_LIMIT','扫描图像长度或压缩比例超限，请重新另存')
        filters=value(obj.get('/Filter',[]));filters=filters if isinstance(filters,(list,tuple)) else [filters];filters=[str(value(x)) for x in filters]
        if filters in (['/DCTDecode'],['/DCT']):
            if bits!=8 or obj.get('/DecodeParms') is not None:_fail('KNOWLEDGE_SCAN_FORMAT','JPEG扫描设置暂不支持，请重新另存')
            try:
                with Image.open(io.BytesIO(data)) as image:
                    if image.format!='JPEG' or image.size!=(width,height) or image.mode not in ('RGB','L') or getattr(image,'n_frames',1)!=1:raise ValueError()
                    if (image.mode=='RGB')!=(color=='/DeviceRGB'):raise ValueError()
                    image.load()
            except (OSError,ValueError,Image.DecompressionBombError):_fail('KNOWLEDGE_SCAN_FORMAT','JPEG扫描图像与声明不符，请重新另存')
        elif filters in (['/FlateDecode'],['/Fl'],[]):
            parms=value(obj.get('/DecodeParms',{}))
            if parms is None:parms={}
            if not isinstance(parms,dict):_fail('KNOWLEDGE_SCAN_FORMAT','扫描压缩参数无法核对')
            predictor=integer(parms.get('/Predictor',1))
            if predictor not in (1,10,11,12,13,14,15):_fail('KNOWLEDGE_SCAN_FORMAT','扫描预测压缩设置暂不支持')
            if integer(parms.get('/Columns',width))!=width or integer(parms.get('/Colors',channels))!=channels or integer(parms.get('/BitsPerComponent',bits))!=bits:_fail('KNOWLEDGE_SCAN_FORMAT','扫描压缩参数与图像尺寸不符')
            limit=(rowbytes+(1 if predictor>=10 else 0))*height
            total_expanded+=limit-expanded
            if total_expanded>24*1024*1024:_fail('KNOWLEDGE_FILE_LIMIT','扫描图像累计展开预算超限，请拆分资料')
            if limit>12*1024*1024:_fail('KNOWLEDGE_FILE_LIMIT','扫描图像展开长度超限')
            if filters:
                try:
                    decoder=zlib.decompressobj();decoded=decoder.decompress(data,limit+1)
                    if decoder.unconsumed_tail or decoder.unused_data or not decoder.eof or len(decoded)!=limit:raise ValueError()
                except (zlib.error,ValueError):_fail('KNOWLEDGE_FILE_LIMIT','扫描图像展开长度或压缩内容异常，请重新另存')
            else:
                decoded=data
                if len(decoded)!=limit:_fail('KNOWLEDGE_SCAN_FORMAT','扫描图像字节长度无法核对')
            if predictor>=10 and any(decoded[n*(rowbytes+1)]>4 for n in range(height)):_fail('KNOWLEDGE_SCAN_FORMAT','扫描图像行压缩参数无效')
        else:_fail('KNOWLEDGE_SCAN_FORMAT','扫描PDF暂只支持JPEG或Flate图像，请重新另存')
    pages=[];raster_pixels=0
    for number in empty_pages:
        page=reader.pages[number-1]
        if float(page.get('/UserUnit',1))!=1 or integer(page.get('/Rotate',0)) not in (0,90,180,270):_fail('KNOWLEDGE_SCAN_FORMAT','扫描PDF页面单位或旋转设置暂不支持')
        width=float(page.cropbox.width);height=float(page.cropbox.height)
        if not math.isfinite(width) or not math.isfinite(height) or not 1<=width<=14400 or not 1<=height<=14400:_fail('KNOWLEDGE_FILE_LIMIT','扫描PDF页面尺寸超限')
        if integer(page.get('/Rotate',0)) in (90,270):width,height=height,width
        scale=min(2,2000/max(width,height));width=max(1,int(math.ceil(width*scale)));height=max(1,int(math.ceil(height*scale)));raster_pixels+=width*height
        if width>2000 or height>2000 or width*height>4000000 or raster_pixels>16000000:_fail('KNOWLEDGE_FILE_LIMIT','扫描PDF渲染总像素超限，请拆分资料')
        pages.append({'page':number,'width':width,'height':height})
    return {'pdfPages':len(reader.pages),'pages':pages,'imagePixels':total_pixels,'imageExpandedBytes':total_expanded,'rasterPixels':raster_pixels}

def extract(raw,scan_ocr=None):
    if not raw.startswith(b'%PDF-'):_fail('KNOWLEDGE_FORMAT','文件不是有效PDF')
    with _lock:
        pdf=_library()
        try:
            reader=pdf.PdfReader(io.BytesIO(raw),strict=True)
            if reader.is_encrypted:_fail('KNOWLEDGE_ENCRYPTED','请先另存为无密码PDF')
            if sum(len(x) for x in reader.xref.values())+len(reader.xref_objStm)>MAX_OBJECTS:_fail('KNOWLEDGE_FILE_LIMIT','PDF结构过于复杂，请拆分')
            root=reader.trailer['/Root'];pages=root['/Pages']
            if int(pages.get('/Count',0))>MAX_PAGES:_fail('KNOWLEDGE_FILE_LIMIT','一次最多导入100页PDF')
            # Walk the reachable object graph without executing actions, opening links or extracting attachments.
            seen=set();stack=[(root,0)];total=0;nodes=0;streams=[];images=[];scan_forbidden=False
            while stack:
                obj,depth=stack.pop();nodes+=1
                if nodes>50000 or depth>64:_fail('KNOWLEDGE_FILE_LIMIT','PDF结构过于复杂，请拆分')
                if isinstance(obj,pdf.generic.IndirectObject):
                    key=(obj.idnum,obj.generation)
                    if key in seen:continue
                    seen.add(key);obj=obj.get_object()
                if isinstance(obj,dict):
                    # Reject all explicit attachment representations before decoding any reachable stream.
                    kind=obj.get('/Type');subtype=obj.get('/Subtype')
                    if isinstance(kind,pdf.generic.IndirectObject):kind=kind.get_object()
                    if isinstance(subtype,pdf.generic.IndirectObject):subtype=subtype.get_object()
                    if subtype=='/FileAttachment' or kind=='/EmbeddedFile' or '/EF' in obj:
                        _fail('KNOWLEDGE_PDF_ACTIVE','含脚本、自动动作或附件的PDF暂不支持，请另存为普通文字PDF')
                    if any(k in obj for k in ('/JS','/JavaScript','/Launch','/EmbeddedFiles','/XFA','/RichMedia','/OpenAction','/AA')):_fail('KNOWLEDGE_PDF_ACTIVE','含脚本、自动动作或附件的PDF暂不支持，请另存为普通文字PDF')
                    if any(k in obj for k in ('/F','/FFilter','/FDecodeParms','/OPI','/URI')) or kind=='/Filespec' or obj.get('/Annots'):scan_forbidden=True
                    if isinstance(obj,pdf.generic.StreamObject):
                        if subtype=='/Image':images.append(obj)
                        else:streams.append(obj)
                    stack.extend((v,depth+1) for k,v in obj.items() if k!='/Parent')
                elif isinstance(obj,(list,tuple)):stack.extend((v,depth+1) for v in obj)
            # Object/attachment checks finish before content, CMap or other stream decoding.
            for stream in streams:
                data=stream.get_data();total+=len(data)
                # Inline image samples are not represented by image XObjects.
                # Reject this subset before any OS renderer can decode it.
                if str(stream.get('/Subtype'))=='/Form' and _has_inline_image(data):scan_forbidden=True
                if total>MAX_TOTAL:_fail('KNOWLEDGE_FILE_LIMIT','PDF展开内容过大，请拆分')
            blocks=[];size=0;empty_pages=[]
            for number,page in enumerate(reader.pages,1):
                if number>MAX_PAGES:_fail('KNOWLEDGE_FILE_LIMIT','一次最多导入100页PDF')
                content=page.get_contents()
                if content is not None and _has_inline_image(content.get_data()):scan_forbidden=True
                text=page.extract_text() or '';size+=len(text)
                if size>100000:_fail('KNOWLEDGE_TEXT_LIMIT','提取文字超过10万字，请拆分；本次未截断保存')
                if text.strip():blocks.append({'location':f'第{number}页','text':text})
                else:empty_pages.append(number)
            if empty_pages and images:
                if scan_ocr is None:_fail('KNOWLEDGE_SCAN_UNAVAILABLE','当前版本未装入扫描PDF提字组件；请另存为带文字PDF或导入已核对文字')
                if scan_forbidden:_fail('KNOWLEDGE_SCAN_FORMAT','含外部引用、注释或内联图像的扫描PDF暂不支持，请另存为普通扫描PDF')
                plan=_scan_plan(pdf,reader,images,empty_pages)
                try:recognized=scan_ocr(raw,plan)
                except Exception as error:_fail(getattr(error,'code','KNOWLEDGE_SCAN_UNAVAILABLE'),str(error) if hasattr(error,'code') else '本机扫描PDF提字未完成，本次未保存')
                if not isinstance(recognized,list) or len(recognized)!=len(empty_pages):_fail('KNOWLEDGE_SCAN_UNAVAILABLE','扫描PDF页序回执无法核对')
                for page,result in zip(empty_pages,recognized):
                    if result.get('page')!=page:_fail('KNOWLEDGE_SCAN_UNAVAILABLE','扫描PDF页来源无法核对')
                    text='\n'.join(result['lines']);size+=len(text)
                    if size>100000:_fail('KNOWLEDGE_TEXT_LIMIT','提取文字超过10万字，请拆分；本次未截断保存')
                    if not text.strip():_fail('KNOWLEDGE_EMPTY',f'第{page}页未提取到清晰文字，请另存清晰图片；本次未保存')
                    blocks.append({'location':f'第{page}页 · 系统提字，待核原页','text':text,'page':page,'recognition':'windows_system_ocr','ocrLanguage':result['language'],'rasterSha256':result['rasterSha256']})
                blocks.sort(key=lambda b:b.get('page') or int(__import__('re').search(r'第(\d+)页',b['location']).group(1)))
                return blocks,'含系统提字页面，可能漏字、错字或阅读顺序不同，请逐页核对原PDF；标明页序，仅预览，未自动确认门店事实或保存。附件、主动对象、外部引用和超预算资料均拒绝。'
            if not blocks:_fail('KNOWLEDGE_EMPTY','PDF没有可提取的文字或可用扫描图像，请核对原文件')
            return blocks,'仅提取PDF文字层，按PDF页序标注；图片、附件和链接目标未读取。排版、阅读顺序及文字可能与页面显示不同，请逐条核对原文件。'
        except PdfTextError:raise
        except pdf.errors.LimitReachedError:_fail('KNOWLEDGE_FILE_LIMIT','PDF展开内容过大，请拆分')
        except (ValueError,TypeError,KeyError,IndexError,RecursionError,OverflowError,pdf.errors.PyPdfError):_fail('KNOWLEDGE_FORMAT','PDF结构无法读取，请重新另存为普通文字PDF')

PINS_SHA='b026e603ad46c8af18f69b8552f300ad278fb6c48d403cd1787f13c3280095a9'
