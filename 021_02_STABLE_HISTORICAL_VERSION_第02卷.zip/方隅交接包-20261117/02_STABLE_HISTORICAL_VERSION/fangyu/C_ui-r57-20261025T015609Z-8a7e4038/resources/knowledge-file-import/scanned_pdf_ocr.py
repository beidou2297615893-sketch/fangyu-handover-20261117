"""Restricted Windows scanned-PDF preview over manifest-pinned system adapters.
No Store mutation, network, provider, user path, model or language installation.
"""
from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,tempfile,threading

SCRIPT_SHA='6f4c7b9d669ea9ecf36b810c33023f90e875d63e55ca7e05f1594a294e708e74'
LICENSE_SHA='693ec2093ced2cd46d24646644e9fca8cb3b3edce928e6df35522962e3175041'

class ScanError(RuntimeError):
    def __init__(self,code,message):super().__init__(message);self.code=code

def fail(code,message):raise ScanError(code,message)

class ScannedPdfOcr:
    def __init__(self,read_resource,job_class,checked_file,temp_dir,reserve,checked_directory):
        self.read_resource=read_resource;self.job_class=job_class;self.checked_file=checked_file
        self.temp_dir=Path(temp_dir).absolute();self.boundary=self.temp_dir.parent;self.reserve=reserve
        self.lock=threading.Lock();self.directory_guard=checked_directory
    def _directory(self,path,create=False):
        path=Path(path).absolute()
        if not path.is_relative_to(self.boundary):fail('KNOWLEDGE_SCAN_PATH','扫描PDF临时路径不属于当前资料空间')
        try:return self.directory_guard(path,create=create)
        except Exception:fail('KNOWLEDGE_SCAN_PATH','扫描PDF目录不能含链接或重定向，本次未处理')
    def __call__(self,raw,plan):
        if os.name!='nt':fail('KNOWLEDGE_SCAN_UNAVAILABLE','扫描PDF提字需要Windows系统PDF与中文提字组件；不会自动下载')
        try:
            self.read_resource('resources/knowledge-file-import/scanned_pdf_ocr.py')
            script=self.read_resource('resources/knowledge-file-import/windows_pdf_bridge.ps1')
            license=self.read_resource('resources/content-media/LICENSE-microsoft-samples.txt')
        except Exception:fail('KNOWLEDGE_PARSER_INVALID','扫描PDF组件校验未通过，本次未处理')
        if hashlib.sha256(script).hexdigest()!=SCRIPT_SHA or hashlib.sha256(license).hexdigest()!=LICENSE_SHA:fail('KNOWLEDGE_PARSER_INVALID','扫描PDF组件校验未通过')
        if not self.lock.acquire(blocking=False):fail('KNOWLEDGE_SCAN_BUSY','本机正在提取另一份扫描PDF，请稍后再试')
        try:
            buffer=ctypes.create_unicode_buffer(32768)
            if not ctypes.windll.kernel32.GetWindowsDirectoryW(buffer,len(buffer)):fail('KNOWLEDGE_SCAN_UNAVAILABLE','Windows系统位置无法核对')
            exe=Path(buffer.value)/'System32/WindowsPowerShell/v1.0/powershell.exe'
            if not exe.is_file():fail('KNOWLEDGE_SCAN_UNAVAILABLE','缺少Windows PowerShell 5系统组件，不会自动安装')
            self._directory(self.temp_dir,create=True)
            self.reserve(16*1024*1024)
            with tempfile.TemporaryDirectory(prefix='scan-',dir=self.temp_dir) as directory:
                folder=self._directory(Path(directory));source=folder/'source.pdf';helper=folder/'renderer.ps1'
                self._directory(folder)
                with source.open('xb') as f:f.write(raw)
                self._directory(folder)
                with helper.open('xb') as f:f.write(script)
                if self.checked_file(source,folder,2097152)!=raw or self.checked_file(helper,folder,100000)!=script:fail('KNOWLEDGE_PARSER_INVALID','扫描PDF临时来源发生变化')
                self._directory(folder)
                process=subprocess.Popen([str(exe),'-NoLogo','-NoProfile','-NonInteractive','-File',str(helper)],executable=str(exe),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,cwd=folder,shell=False,creationflags=subprocess.CREATE_NO_WINDOW)
                job=None
                try:
                    job=self.job_class(process)
                    try:stdout,_=process.communicate(json.dumps({'inputFile':str(source),'outputDir':str(folder),'plan':plan},ensure_ascii=False).encode('utf-8'),timeout=45)
                    except subprocess.TimeoutExpired:fail('KNOWLEDGE_SCAN_TIMEOUT','扫描PDF提字超过45秒，本次未保存；请拆分或改用清晰图片')
                    if len(stdout)>600000:fail('KNOWLEDGE_FILE_LIMIT','扫描PDF提字回执超出预算，本次未保存')
                    try:result=json.loads(stdout.decode('utf-8-sig'))
                    except (ValueError,UnicodeError):fail('KNOWLEDGE_SCAN_UNAVAILABLE','系统PDF提字未完成，本次未保存')
                    if process.returncode or result.get('status')!='ok':
                        code=result.get('code')
                        if code=='KNOWLEDGE_SCAN_LANGUAGE':fail(code,'此电脑未安装系统中文提字语言，扫描PDF暂不可用；不会自动下载，可另存带文字PDF或导入已核对文字')
                        if code in ('KNOWLEDGE_FILE_LIMIT','KNOWLEDGE_TEXT_LIMIT'):fail(code,'扫描PDF处理预算超限，本次未保存；请拆分资料')
                        fail('KNOWLEDGE_SCAN_UNAVAILABLE','系统PDF或提字组件未完成，本次未保存；请尝试较小普通扫描PDF')
                    pages=result.get('pages')
                    if not isinstance(pages,list) or len(pages)!=len(plan['pages']):fail('KNOWLEDGE_SCAN_UNAVAILABLE','扫描PDF页序回执无法核对')
                    total=0
                    for value,expected in zip(pages,plan['pages']):
                        if not isinstance(value,dict) or value.get('page')!=expected['page'] or any(type(value.get(k)) is not int or not 0<value[k]<=expected[k] for k in ('width','height')) or value.get('language')!='zh-Hans-CN' or not re.fullmatch('[a-f0-9]{64}',str(value.get('rasterSha256',''))):fail('KNOWLEDGE_SCAN_UNAVAILABLE','扫描PDF页来源或语言回执无法核对')
                        lines=value.get('lines')
                        if not isinstance(lines,list) or len(lines)>2000 or any(not isinstance(x,str) for x in lines):fail('KNOWLEDGE_SCAN_UNAVAILABLE','扫描PDF文字回执无法核对')
                        total+=sum(len(x) for x in lines)
                        if total>100000:fail('KNOWLEDGE_TEXT_LIMIT','扫描PDF文字超过10万字，请拆分；本次未保存')
                    return pages
                finally:
                    if process.poll() is None:process.kill();process.wait(timeout=3)
                    if job is not None:job.close()
        finally:self.lock.release()
