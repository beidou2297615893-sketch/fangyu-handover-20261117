﻿$ErrorActionPreference='Stop'
[Console]::InputEncoding=[Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$p=ConvertFrom-Json ([Console]::In.ReadToEnd())
$failure='KNOWLEDGE_SCAN_UNAVAILABLE'
try{
 Add-Type -AssemblyName System.Runtime.WindowsRuntime
 [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]|Out-Null
 [Windows.Storage.Streams.IRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]|Out-Null
 [Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]|Out-Null
 [Windows.Data.Pdf.PdfPageRenderOptions,Windows.Data.Pdf,ContentType=WindowsRuntime]|Out-Null
 [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]|Out-Null
 [Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]|Out-Null
 [Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]|Out-Null
 $generic=([System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'})[0]
 $action=([System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and !$_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'})[0]
 function Await($operation,$type){$task=$generic.MakeGenericMethod($type).Invoke($null,@($operation));[void]$task.Wait();return $task.Result}
 $language=@([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages|Where-Object{$_.LanguageTag -eq 'zh-Hans-CN'})[0]
 if($null -eq $language){$failure='KNOWLEDGE_SCAN_LANGUAGE';throw 'Chinese OCR unavailable'}
 $engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
 if($null -eq $engine){$failure='KNOWLEDGE_SCAN_LANGUAGE';throw 'Chinese OCR unavailable'}
 if((Get-Item -LiteralPath $p.inputFile).Length -gt 2097152 -or @($p.plan.pages).Count -gt 10){$failure='KNOWLEDGE_FILE_LIMIT';throw 'Input budget'}
 $file=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($p.inputFile)) ([Windows.Storage.StorageFile])
 $pdf=Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
 if($pdf.PageCount -ne $p.plan.pdfPages){$failure='KNOWLEDGE_FORMAT';throw 'Page count mismatch'}
 $results=@();$pixels=0;$chars=0;$rasterScale=$null
 foreach($item in $p.plan.pages){
  $number=[int]$item.page;$width=[int]$item.width;$height=[int]$item.height;$pixels+=$width*$height
  if($number -lt 1 -or $number -gt $pdf.PageCount -or $width -lt 1 -or $height -lt 1 -or $width -gt 2000 -or $height -gt 2000 -or $width*$height -gt 4000000 -or $pixels -gt 16000000){$failure='KNOWLEDGE_FILE_LIMIT';throw 'Page raster budget'}
  $out=Join-Path $p.outputDir ('page-'+$number+'.png');[IO.File]::WriteAllBytes($out,[byte[]]@())
  $page=$pdf.GetPage([uint32]($number-1))
  try{
   if($null -eq $rasterScale){
    # Destination sizes are DIPs, not physical pixels. Measure this private
    # render process once; do not alter system scaling or open a window.
    $probe=Join-Path $p.outputDir 'scale-probe.png';[IO.File]::WriteAllBytes($probe,[byte[]]@())
    try{
     $probeFile=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($probe)) ([Windows.Storage.StorageFile]);$probeStream=Await ($probeFile.OpenAsync([Windows.Storage.FileAccessMode]::ReadWrite)) ([Windows.Storage.Streams.IRandomAccessStream])
     try{$probeOptions=New-Object Windows.Data.Pdf.PdfPageRenderOptions;if($page.Size.Width -ge $page.Size.Height){$probeOptions.DestinationWidth=96}else{$probeOptions.DestinationHeight=96};$task=$action.Invoke($null,@($page.RenderToStreamAsync($probeStream,$probeOptions)));[void]$task.Wait()}finally{$probeStream.Dispose()}
     $probeStream=Await ($probeFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
     try{$probeDecoder=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($probeStream)) ([Windows.Graphics.Imaging.BitmapDecoder]);$edge=[Math]::Max($probeDecoder.PixelWidth,$probeDecoder.PixelHeight);if($edge -lt 1 -or $edge -gt 1024){$failure='KNOWLEDGE_FILE_LIMIT';throw 'Display raster scale outside bounded support'};$rasterScale=$edge/96.0;$pixels+=$probeDecoder.PixelWidth*$probeDecoder.PixelHeight;if($pixels -gt 16000000){$failure='KNOWLEDGE_FILE_LIMIT';throw 'Total raster budget'}}finally{$probeStream.Dispose()}
    }finally{if(Test-Path -LiteralPath $probe){Remove-Item -LiteralPath $probe}}
   }
   $dest=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($out)) ([Windows.Storage.StorageFile]);$stream=Await ($dest.OpenAsync([Windows.Storage.FileAccessMode]::ReadWrite)) ([Windows.Storage.Streams.IRandomAccessStream])
   try{$options=New-Object Windows.Data.Pdf.PdfPageRenderOptions;if($width -ge $height){$options.DestinationWidth=[uint32][Math]::Max(1,[Math]::Floor($width/$rasterScale))}else{$options.DestinationHeight=[uint32][Math]::Max(1,[Math]::Floor($height/$rasterScale))};$task=$action.Invoke($null,@($page.RenderToStreamAsync($stream,$options)));[void]$task.Wait()}finally{$stream.Dispose()}
   if((Get-Item -LiteralPath $out).Length -gt 12582912){$failure='KNOWLEDGE_FILE_LIMIT';throw 'Raster bytes budget'}
   $hash=[Security.Cryptography.SHA256]::Create();$read=[IO.File]::OpenRead($out);try{$rasterSha=(-join ($hash.ComputeHash($read)|ForEach-Object{$_.ToString('x2')}))}finally{$read.Dispose();$hash.Dispose()}
   $rendered=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($out)) ([Windows.Storage.StorageFile]);$stream=Await ($rendered.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
   try{
    $decoder=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    if($decoder.PixelWidth -lt 1 -or $decoder.PixelHeight -lt 1 -or $decoder.PixelWidth -gt $width -or $decoder.PixelHeight -gt $height){$failure='KNOWLEDGE_FILE_LIMIT';throw 'Raster dimensions exceed planned budget'}
    $actualWidth=$decoder.PixelWidth;$actualHeight=$decoder.PixelHeight
    $bitmap=Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    try{$recognized=Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult]);$lines=@($recognized.Lines|ForEach-Object{$_.Text});$chars+=($lines -join "`n").Length;if($chars -gt 100000){$failure='KNOWLEDGE_TEXT_LIMIT';throw 'Text budget'};$results+=@{page=$number;lines=$lines;language=$engine.RecognizerLanguage.LanguageTag;width=$actualWidth;height=$actualHeight;rasterSha256=$rasterSha}}finally{$bitmap.Dispose()}
   }finally{$stream.Dispose()}
  }finally{$page.Dispose();if(Test-Path -LiteralPath $out){Remove-Item -LiteralPath $out}}
 }
 [Console]::Out.WriteLine((@{status='ok';pages=$results;systemVersion=[Environment]::OSVersion.VersionString}|ConvertTo-Json -Depth 8 -Compress))
}catch{[Console]::Out.WriteLine((@{status='unavailable';code=$failure}|ConvertTo-Json -Compress));exit 1}
