"""Admin bridge to existing cloud rules and the pinned local TUF coordinator.

No account secrets, model requests, process control or replacement feed URLs.
The host supplies its already-authorized backend and owns normal-launch setup.
"""
from copy import deepcopy
import json
import math
import re

REMOTE_ACTIONS = frozenset({'remote_ai_config_read','remote_config_read','remote_policy_publish','remote_policy_status',
    'remote_ai_config_save','software_update_status','software_update_check',
    'software_update_download','software_update_prepare'})
CONFIG_FIELDS = frozenset({'enabled','configured','provider','model','reasoning_effort',
    'revision','rules_version','intent_policy','daily_budget_cny','usd_cny_rate',
    'price_version','price_source','last_save_id'})
EDITABLE_CONFIG = frozenset({'enabled','provider','model','reasoning_effort','intent_policy',
    'daily_budget_cny','usd_cny_rate'})
SUMMARY_COUNTS = frozenset({'stores','keywords','eligible','held','extensionStores','extensionQueries',
    'runtimeQueries','candidateQueries','runtimeHypotheses','materials','facts','rules','searchTerms',
    'replyTemplates','toneStores','toneTemplates','candidateTemplates','verifiedTemplates',
    'originalKeywords','extensionStoreQueries','totalDistinctQueries','prompts','constraints','constructedExamples'})


class RemoteManagementError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


class _UnconfiguredUpdates:
    def status(self):
        return {'status':'entry_unconfigured','feed_configured':False,'requires_restart':False,
            'installed_version':'unknown','message':'当前固定入口尚未装入可信更新管理'}


def _public_config(raw):
    config = raw.get('config', raw) if isinstance(raw, dict) else None
    if not isinstance(config, dict):
        raise RemoteManagementError('REMOTE_RESPONSE_INVALID', '云配置回执格式无效', 503)
    result = {}
    for key in CONFIG_FIELDS - {'intent_policy'}:
        value = config.get(key)
        valid = (type(value) is bool if key in ('enabled','configured') else
            type(value) is int and 0 <= value <= 2**53-1 if key == 'revision' else
            type(value) in (int,float) and math.isfinite(value) and 0 <= value <= 2**53-1
                if key in ('daily_budget_cny','usd_cny_rate') else
            value is None or isinstance(value,str) and len(value)<=500)
        if key in config and valid:
            result[key] = value
    # Preserve the production five-grade policy as well as legacy three grades.
    policy = config.get('intent_policy')
    if (isinstance(policy,dict) and set(policy) in ({'high','medium','low'},
            {'super_high','high','medium','low','very_low'})
            and all(isinstance(value,str) and len(value)<=2000 for value in policy.values())):
        result['intent_policy'] = deepcopy(policy)
    catalog=config.get('model_catalog')
    if isinstance(catalog,list) and len(catalog)<=32:
        result['model_catalog']=[{key:row[key] for key in ('id','provider','label')}
            for row in catalog if isinstance(row,dict)
            and all(isinstance(row.get(key),str) and 0<len(row[key])<=200
                    for key in ('id','provider','label'))
            and row['provider'] in ('deepseek','openai')
            and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,119}',row['id'])]
    return result


def _public_policy(raw):
    if not isinstance(raw,dict) or type(raw.get('can_publish')) is not bool or 'summary' not in raw:
        raise RemoteManagementError('REMOTE_RESPONSE_INVALID', '公司规则摘要格式无效', 503)
    from assistant.company_intent_policy import safe_projection
    return {'can_publish':raw['can_publish'],
        'summary':None if raw['summary'] is None else safe_projection(raw['summary'])}


def _public_central(raw):
    if raw is None:
        return None
    if not isinstance(raw,dict):
        raise RemoteManagementError('REMOTE_RESPONSE_INVALID', '门店版本摘要格式无效', 503)
    return {key:value for key,value in raw.items() if key in
        ('revision','catalogDigest','configDigest','storeId','materialKey','evaluatorVersion',
         'runtimeSearchRevision','runtimeSearchDigest') and isinstance(value,str) and len(value)<=200}


def _public_bundle(raw):
    if not isinstance(raw,dict):
        raise RemoteManagementError('REMOTE_RESPONSE_INVALID', '门店规则包摘要格式无效', 503)
    result = {key:value for key,value in raw.items() if
        (key in ('revision','digest') and isinstance(value,str) and len(value)<=200
         or key in ('bytes','chunkCount') and type(value) is int and 0<=value<=2**53-1)}
    if isinstance(raw.get('summary'),dict):
        result['summary'] = {key:value for key,value in raw['summary'].items() if
            (key in SUMMARY_COUNTS and type(value) is int and 0<=value<=2**53-1
             or key in ('catalogChanged','rulesEnabled','pricesVerified') and type(value) is bool)}
    return result


def _validate_config(config):
    for key,value in config.items():
        valid = (type(value) is bool if key == 'enabled' else
            value in ('deepseek','openai') if key == 'provider' else
            isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,199}',value) is not None
                if key == 'model' else
            value is None or isinstance(value,str) and len(value)<=40 if key == 'reasoning_effort' else
            type(value) in (int,float) and math.isfinite(value) and 0<=value<=2**53-1
                if key in ('daily_budget_cny','usd_cny_rate') else
            isinstance(value,dict) and set(value) in ({'high','medium','low'},
                {'super_high','high','medium','low','very_low'})
                and all(isinstance(text,str) and len(text)<=2000 for text in value.values())
                if key == 'intent_policy' else False)
        if not valid:
            raise RemoteManagementError('INPUT_INVALID','企业配置字段类型或内容无效')


def _software_status(raw):
    if not isinstance(raw, dict):
        raise RemoteManagementError('UPDATE_RESPONSE_INVALID', '可信更新状态格式无效', 503)
    return {key:value for key,value in raw.items() if
        (key in ('status','installed_version','message') and isinstance(value,str) and len(value)<=500
         or key in ('installed_release','candidate_release') and (value is None or type(value) is int and 0<=value<=2**53-1)
         or key in ('requires_restart','feed_configured') and type(value) is bool)}


class RemoteManagement:
    actions = REMOTE_ACTIONS
    error_type = RemoteManagementError

    def __init__(self, backend, *, updates_factory=None, policy_factory=None, update_entry_supported=False):
        self.backend, self.updates_factory = backend, updates_factory or _UnconfiguredUpdates
        self.policy_factory = policy_factory or self._policy_manager
        self.update_entry_supported = update_entry_supported is True

    def _update_status(self, raw):
        return {**_software_status(raw),'entry_supported':self.update_entry_supported}

    def _policy_manager(self, user, guard):
        from assistant.company_intent_policy import LocalCompanyIntentPolicy
        runtime = self.backend.platform_runtime
        device = deepcopy(runtime.service.device or {}) if runtime else {}
        if (not device.get('id') or device.get('owner') != user['username']):
            raise RemoteManagementError('POLICY_DEVICE_REQUIRED', '原管理员设备绑定待核对', 403)
        def current():
            return (guard() is True and runtime.service.device == device
                and runtime._device(user).get('bound') is True)
        return LocalCompanyIntentPolicy(self.backend.core, user['tenant_id'], user['username'],
            self.backend.company, device_id=device['id'], scope_guard=current,
            cloud=lambda actor, operation, data:self._cloud(actor, operation, **data))

    def _scope(self, token, store_id):
        user, profile = self.backend._identity(token)
        selected = self.backend._selected_store(user, profile)
        if user.get('role') != 'admin' or profile.get('role') != 'admin':
            raise RemoteManagementError('ADMIN_REQUIRED', '远程配置仅限当前企业管理员', 403)
        if selected != store_id:
            raise RemoteManagementError('STORE_FORBIDDEN', '当前门店已变化，请重新读取', 403)
        return user

    def _current(self, token, store_id, user):
        current = self._scope(token, store_id)
        if any(current.get(key) != user.get(key) for key in ('id','tenant_id','username','role')):
            raise RemoteManagementError('AUTH_REQUIRED', '管理员身份已变化，请重新读取', 403)

    def _cloud(self, user, operation, **data):
        integration = self.backend.integrations
        return integration._cloud(integration._read(user['tenant_id']), user, operation, **data)

    def dispatch(self, action, data, token=''):
        fields = ({'storeId','expected_policy_revision','idempotency_key','source_local_revision','source_local_digest'}
            if action == 'remote_policy_publish' else {'storeId','idempotency_key'}
            if action == 'remote_policy_status' else {'storeId','config','expected_revision','request_id'}
            if action == 'remote_ai_config_save' else {'storeId'})
        if (action not in REMOTE_ACTIONS or not isinstance(data, dict) or set(data) != fields
                or not isinstance(data['storeId'], str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', data['storeId'])):
            raise RemoteManagementError('INPUT_INVALID', '远程配置操作参数无效')
        with self.backend.lock:
            if self.backend.closed:
                raise RemoteManagementError('BACKEND_CLOSED', '工作台已关闭', 503)
            store_id = data['storeId']
            user = self._scope(token, store_id)
            if action == 'remote_ai_config_read':
                # Model settings must not depend on optional rules/update APIs.
                config = _public_config(self._cloud(user,'ai_config_read'))
                self._current(token,store_id,user)
                return {'configuration':config,'scope':'company',
                    'actor':{'username':user['username'],'storeId':store_id}}
            if action.startswith('software_update_'):
                coordinator = self.updates_factory()
                if action != 'software_update_status' and not self.update_entry_supported:
                    self._current(token,store_id,user)
                    return {'softwareUpdate':{**self._update_status(coordinator.status()),
                        'status':'entry_unconfigured','requires_restart':False,
                        'message':'当前固定入口尚未接入可信重开安装；未下载或安排替换'}}
                if action == 'software_update_status':
                    raw = coordinator.status()
                elif action == 'software_update_prepare':
                    raw = coordinator.request_install()
                else:
                    raw = coordinator.check(download=action=='software_update_download')
                self._current(token,store_id,user)
                return {'softwareUpdate':self._update_status(raw)}
            if action == 'remote_ai_config_save':
                config, revision, request_id = data['config'], data['expected_revision'], data['request_id']
                if (not isinstance(config,dict) or not config or set(config)-EDITABLE_CONFIG
                        or type(revision) is not int or not 0<=revision<=2**53-1
                        or not isinstance(request_id,str) or not re.fullmatch(
                            r'[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}',request_id,re.I)):
                    raise RemoteManagementError('INPUT_INVALID', '企业配置内容、版本或原请求编号无效')
                _validate_config(config)
                try:
                    encoded = json.dumps(config,ensure_ascii=False,allow_nan=False).encode('utf-8')
                    if len(encoded)>16384:raise ValueError('size')
                except (ValueError,TypeError):
                    raise RemoteManagementError('INPUT_INVALID', '企业配置必须为有限JSON数据') from None
                try:
                    raw = self._cloud(user,'ai_config_save',config=deepcopy(config),
                        expected_revision=revision,request_id=request_id)
                    public = _public_config(raw)
                except Exception as error:
                    status = getattr(error,'http_status',getattr(error,'status',None))
                    # These are explicit pre-commit rejections from the existing
                    # config transaction, never a timeout or a guessed outcome.
                    if status in (400,401,403,409):
                        code=getattr(error,'code','')
                        message=('服务器配置已更新，请刷新后重新编辑。' if status==409 else
                            '请选择服务器提供的可用模型。' if code=='AI_UNPRICED_MODEL' else
                            '管理员会话已失效，请使用已有登录重新打开。' if status==401 else
                            '当前管理员没有修改此配置的权限。' if status==403 else
                            '模型配置未被服务器接受，请核对后修改。')
                        self._current(token,store_id,user)
                        return {'configuration':None,'scope':'company','state':'rejected',
                            'mutation_committed':False,'request_id':request_id,
                            'message':message,'automaticRetry':False}
                    self._current(token,store_id,user)
                    return {'configuration':None,'scope':'company','state':'unknown',
                        'mutation_committed':None,'request_id':request_id,'automaticRetry':False}
                confirmed = public.get('revision')==revision+1 and public.get('last_save_id')==request_id
                self._current(token,store_id,user)
                return {'configuration':public,'scope':'company','request_id':request_id,
                    'state':'succeeded' if confirmed else 'unknown',
                    'mutation_committed':True if confirmed else None,'automaticRetry':False}
            if action in ('remote_policy_publish','remote_policy_status'):
                def guard():
                    self._current(token, store_id, user)
                    return True
                manager = self.policy_factory(user, guard)
                payload = {'idempotency_key':data['idempotency_key']}
                if action == 'remote_policy_publish':
                    payload.update(expected_local_revision=data['source_local_revision'],
                        expected_local_digest=data['source_local_digest'],
                        expected_policy_revision=data['expected_policy_revision'])
                result = manager.execute('intent_policy_publish' if action == 'remote_policy_publish'
                    else 'intent_policy_publish_status', payload, user)
                self._current(token, store_id, user)
                return {'publication':result, 'scope':'company'}
            sections = {}
            def section(name, read, project):
                self._current(token,store_id,user)
                try:
                    value = project(read())
                except Exception as error:
                    self._current(token,store_id,user)
                    if getattr(error,'http_status',getattr(error,'status',None)) in (400,401,403,409):
                        raise
                    sections[name] = 'unknown'
                    return None
                self._current(token,store_id,user)
                sections[name] = 'ready'
                return value
            config = section('aiConfig', lambda:self._cloud(user,'ai_config_read'), _public_config)
            policy = section('providerPolicy', lambda:self._cloud(user,'intent_policy_read'), _public_policy)
            bundle = section('ruleBundle', lambda:self._cloud(user,'rule_bundle_status'), _public_bundle)
            central = section('centralVersion', lambda:self.backend.materials.central, _public_central)
            update = section('softwareUpdate', lambda:self.updates_factory().status(), self._update_status)
            self._current(token, store_id, user)
            return {'remote':{'actor':{'username':user['username'],'storeId':store_id},
                'scope':'company_ai_and_selected_store', 'aiConfig':config,
                'providerPolicyScope':'company','ruleBundleScope':'company','centralVersionScope':'selected_store',
                'providerPolicy':policy,
                'centralVersion':central,
                'ruleBundle':bundle,
                'sections':sections,
                'softwareUpdate':update,
                'publishedToDevices':False}}
