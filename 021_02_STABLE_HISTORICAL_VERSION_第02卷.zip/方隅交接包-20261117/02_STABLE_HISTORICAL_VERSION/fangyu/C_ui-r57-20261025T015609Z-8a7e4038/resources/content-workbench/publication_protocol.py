"""Host-owned protocol digest. There is deliberately no real platform policy.

Executable upload validators are part of the host-pinned Python closure. Their
actual code/defaults are additionally bound into the protocol descriptor; a
64-character label alone cannot approve different endpoints or mappings.
"""
import hashlib,json,marshal,re,types
from urllib.parse import urlsplit

def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def _url(value):
    if not isinstance(value,str) or not 1<=len(value)<=2000:raise ValueError('protocol_url')
    p=urlsplit(value)
    if p.scheme!='https' or not p.hostname or p.username or p.password or p.fragment:raise ValueError('protocol_url')
    return value

def _code(code):
    return code.replace(co_filename='',co_firstlineno=0,co_consts=tuple(_code(v) if isinstance(v,types.CodeType) else v for v in code.co_consts))

def callable_digest(fn):
    if type(fn) is not types.FunctionType or fn.__code__.co_freevars:raise ValueError('host_function_required')
    return _digest({'code':hashlib.sha256(marshal.dumps(_code(fn.__code__))).hexdigest(),
                    'defaults':fn.__defaults__,'keywordDefaults':fn.__kwdefaults__})

def protocol_descriptor(p):
    keys={'enabled','realProtocolVerified','revision','digest','previewTokenAttribute','readUrls','create','uploadRules'}
    if (type(p) is not dict or set(p)!=keys or p['enabled'] is not True or p['realProtocolVerified'] is not True
            or not isinstance(p['revision'],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',p['revision'])
            or p['revision'].startswith('SYNTHETIC-ONLY')
            or not re.fullmatch(r'data-[a-z0-9-]{1,50}',str(p['previewTokenAttribute']))):raise ValueError('protocol_unverified')
    cp=p['create']
    if type(cp) is not dict or set(cp)!={'endpoint','requestPaths','responsePaths','successValue'}:raise ValueError('protocol_create')
    _url(cp['endpoint'])
    if urlsplit(cp['endpoint']).netloc!='creator.xiaohongshu.com':raise ValueError('protocol_create_origin')
    for group,expected in [('requestPaths',{'title','body','assetTokens'}),('responsePaths',{'success','postId','accountUid'})]:
        paths=cp[group]
        if type(paths) is not dict or set(paths)!=expected:raise ValueError('protocol_paths')
        for path in paths.values():
            if (not isinstance(path,(tuple,list)) or not 1<=len(path)<=10
                    or any(not isinstance(k,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',k) for k in path)):raise ValueError('protocol_path')
    # Require a JSON primitive success flag, not equality hooks or containers.
    if type(cp['successValue']) not in (bool,str,int) or type(cp['successValue']) is str and len(cp['successValue'])>100:raise ValueError('protocol_success')
    reads=p['readUrls'];uploads=p['uploadRules']
    if not isinstance(reads,tuple) or len(reads)>64 or len(set(reads))!=len(reads):raise ValueError('protocol_reads')
    for value in reads:_url(value)
    if not isinstance(uploads,tuple) or not 1<=len(uploads)<=8:raise ValueError('protocol_uploads')
    descriptors=[]
    for rule in uploads:
        if type(rule) is not dict or set(rule)!={'url','method','validator','decoder'} or rule['method'] not in ('POST','PUT'):raise ValueError('protocol_upload')
        descriptors.append({'url':_url(rule['url']),'method':rule['method'],
                            'validatorDigest':callable_digest(rule['validator']),'decoderDigest':callable_digest(rule['decoder'])})
    return {'revision':p['revision'],'previewTokenAttribute':p['previewTokenAttribute'],'create':cp,'readUrls':reads,'uploadRules':descriptors}

def protocol_digest(policy):return _digest(protocol_descriptor(policy))

def validate_policy(policy):
    if (not isinstance(policy,dict) or not re.fullmatch(r'[a-f0-9]{64}',str(policy.get('digest','')))
            or protocol_digest(policy)!=policy['digest']):raise ValueError('protocol_digest_changed')
    return policy
