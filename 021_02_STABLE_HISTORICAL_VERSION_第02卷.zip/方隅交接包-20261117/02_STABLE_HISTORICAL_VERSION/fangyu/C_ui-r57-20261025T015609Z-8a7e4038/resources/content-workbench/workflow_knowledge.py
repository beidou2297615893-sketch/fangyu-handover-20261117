"""Bounded in-memory documents and traceable evidence; no storage/model access."""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path


class KnowledgeError(ValueError):
    """Invalid public knowledge contract; messages contain no input content."""


class VendorIntegrityError(RuntimeError):
    """The fixed upstream closure does not match the trusted code manifest."""


# Code is the authority: editing PINS.json alongside vendor files cannot repin it.
_PIN_CONTRACT = {
    'repo': 'veeicwgy/ip-publisher',
    'commit': '2121445098d46cfa2947e3088f84b1255fa8fa13',
    'files': {
        'normalize.py': {'sourcePath': 'ip_publisher/kb/normalize.py',
                         'sha256': 'd17449da9cf2942b0e0cc1bbabe29b4793daa6af3dff67b918fd4850e8e33f93'},
        'LICENSE': {'sourcePath': 'LICENSE',
                    'sha256': 'b578bcab423726caace355bf28d4b62eaa7762c3fde9612e7de70791a510c3bb'},
    },
}


def _load_verified_vendor():
    vendor = Path(__file__).resolve().parent / 'workflow_vendor'
    try:
        pins = json.loads((vendor / 'PINS.json').read_bytes())
        if pins != _PIN_CONTRACT:
            raise ValueError('pins')
        verified = {}
        for name, expected in _PIN_CONTRACT['files'].items():
            raw = (vendor / name).read_bytes()
            if hashlib.sha256(raw).hexdigest() != expected['sha256']:
                raise ValueError('vendor')
            verified[name] = raw
        namespace = {'__name__': '_workflow_verified_ip_normalize'}
        # Execute exactly the already checked bytes, with no second source read.
        exec(compile(verified['normalize.py'], 'verified-ip-publisher/normalize.py', 'exec'), namespace)
        return namespace['normalize_text'], namespace['extract_keywords']
    except (OSError, ValueError, TypeError, KeyError, SyntaxError) as exc:
        raise VendorIntegrityError('knowledge_vendor_integrity_failed') from exc


_normalize_text, _extract_keywords = _load_verified_vendor()


def _string(value, name, maximum, *, empty=False):
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()):
        raise KnowledgeError('invalid_' + name)
    try:
        value.encode('utf-8')
    except UnicodeError as exc:
        raise KnowledgeError('invalid_' + name) from exc
    return value


def _sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def import_document(title, text, kind, source_label):
    """Return an unpersisted document with raw Python character offsets."""
    title = _string(title, 'title', 120)
    text = _string(text, 'text', 100_000)
    source_label = _string(source_label, 'source_label', 500, empty=True)
    if kind not in ('fact', 'hypothesis'):
        raise KnowledgeError('invalid_kind')
    digest = _sha(text)
    document_id = 'doc-' + digest
    chunks = []
    for index, start in enumerate(range(0, len(text), 500), start=1):
        end = min(start + 500, len(text))
        raw_chunk = text[start:end]
        chunks.append({'id': f'{document_id}:c{index:03d}', 'text': raw_chunk,
                       'start': start, 'end': end, 'sha256': _sha(raw_chunk)})
    return {'id': document_id, 'title': title, 'text': text, 'kind': kind,
            'sourceLabel': source_label, 'sha256': digest, 'chunks': chunks}


def _features(query):
    weighted = {}
    # Real pinned MIT upstream tokenizer; supplement its full Chinese runs with
    # bigrams so an unsegmented Chinese question can match a shorter passage.
    for term in _extract_keywords(query):
        weighted[term.casefold()] = 2.0
    for run in re.findall(r'[\u3400-\u9fff]+', query):
        if len(run) == 1:
            weighted[run] = max(weighted.get(run, 0), 0.5)
        else:
            for index in range(len(run) - 1):
                weighted.setdefault(run[index:index + 2], 1.0)
    return weighted


def _validate_document(document):
    if not isinstance(document, dict):
        raise KnowledgeError('invalid_document')
    title = _string(document.get('title'), 'document_title', 120)
    text = _string(document.get('text'), 'document_text', 100_000)
    _string(document.get('sourceLabel'), 'document_source_label', 500, empty=True)
    if document.get('kind') not in ('fact', 'hypothesis'):
        raise KnowledgeError('invalid_document_kind')
    digest = _sha(text)
    document_id = 'doc-' + digest
    if document.get('id') != document_id or document.get('sha256') != digest:
        raise KnowledgeError('invalid_document_digest')
    chunks = document.get('chunks')
    if not isinstance(chunks, list) or not 1 <= len(chunks) <= 500:
        raise KnowledgeError('invalid_document_chunks')
    previous_end = 0
    for number, chunk in enumerate(chunks, start=1):
        if not isinstance(chunk, dict):
            raise KnowledgeError('invalid_document_chunk')
        start, end = chunk.get('start'), chunk.get('end')
        if type(start) is not int or type(end) is not int or start != previous_end or not start < end <= len(text) or end - start > 500:
            raise KnowledgeError('invalid_document_chunk_offsets')
        expected_text = text[start:end]
        if chunk.get('id') != f'{document_id}:c{number:03d}' or chunk.get('text') != expected_text or chunk.get('sha256') != _sha(expected_text):
            raise KnowledgeError('invalid_document_chunk_digest')
        previous_end = end
    if previous_end != len(text):
        raise KnowledgeError('invalid_document_chunk_coverage')
    return title


def search(documents, query, limit=5):
    """Search only the supplied documents, returning copied original evidence."""
    if not isinstance(documents, list):
        raise KnowledgeError('invalid_documents')
    query = _string(query, 'query', 500, empty=True)
    if type(limit) is not int or not 1 <= limit <= 20:
        raise KnowledgeError('invalid_limit')
    if not query.strip():
        return []
    normalized_query = _normalize_text(query).casefold()
    features = _features(normalized_query)
    if not features:
        return []
    ranked, seen = [], set()
    for document_index, document in enumerate(documents):
        title = _validate_document(document)
        if document['id'] in seen:
            raise KnowledgeError('duplicate_document')
        seen.add(document['id'])
        normalized_title = _normalize_text(title).casefold()
        title_score = sum(weight for term, weight in features.items() if term in normalized_title)
        for chunk in document['chunks']:
            if not chunk['text'].strip():
                continue
            normalized_text = _normalize_text(chunk['text']).casefold()
            body_score = sum(weight for term, weight in features.items() if term in normalized_text)
            phrase_score = 2.0 if len(normalized_query) > 1 and normalized_query in normalized_text else 0.0
            score = body_score + title_score * 0.25 + phrase_score
            if score <= 0:
                continue
            row = {'evidenceId': chunk['id'], 'documentId': document['id'],
                   'title': title, 'text': chunk['text'], 'start': chunk['start'],
                   'end': chunk['end'], 'kind': document['kind'],
                   'score': round(score, 6), 'documentSha256': document['sha256']}
            ranked.append((score, document_index, chunk['start'], row))
    ranked.sort(key=lambda item: (-item[0], item[1], item[2]))
    return [item[3] for item in ranked[:limit]]


def check_citations(citations, evidence):
    """Resolve citations solely against the supplied current search evidence."""
    if not isinstance(citations, list) or len(citations) > 20 or not isinstance(evidence, list) or len(evidence) > 500:
        raise KnowledgeError('invalid_citations_or_evidence')
    indexed = {}
    for row in evidence:
        if not isinstance(row, dict):
            raise KnowledgeError('invalid_evidence')
        evidence_id = _string(row.get('evidenceId'), 'evidence_id', 128)
        digest = row.get('documentSha256')
        if not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest):
            raise KnowledgeError('invalid_evidence_digest')
        document_id = 'doc-' + digest
        if row.get('documentId') != document_id or not re.fullmatch(re.escape(document_id) + r':c\d{3}', evidence_id):
            raise KnowledgeError('invalid_evidence_reference')
        _string(row.get('title'), 'evidence_title', 120)
        text = _string(row.get('text'), 'evidence_text', 500)
        start, end, score = row.get('start'), row.get('end'), row.get('score')
        if type(start) is not int or type(end) is not int or start < 0 or end > 100_000 or end - start != len(text):
            raise KnowledgeError('invalid_evidence_offsets')
        if row.get('kind') not in ('fact', 'hypothesis') or type(score) not in (int, float) or score < 0 or score > 10_000 or not math.isfinite(score):
            raise KnowledgeError('invalid_evidence_metadata')
        if evidence_id in indexed:
            raise KnowledgeError('duplicate_evidence')
        indexed[evidence_id] = {key: row[key] for key in ('evidenceId', 'documentId', 'title', 'text', 'start', 'end', 'kind', 'score', 'documentSha256')}
    validated, seen = [], set()
    for citation in citations:
        quote = None
        if isinstance(citation, str):
            evidence_id = citation
        elif isinstance(citation, dict) and set(citation) <= {'evidenceId', 'quote'}:
            evidence_id = citation.get('evidenceId')
            if 'quote' in citation:
                quote = _string(citation['quote'], 'citation_quote', 500)
        else:
            raise KnowledgeError('invalid_citation')
        evidence_id = _string(evidence_id, 'citation_id', 128)
        if evidence_id not in indexed:
            raise KnowledgeError('unknown_citation')
        if evidence_id in seen:
            raise KnowledgeError('duplicate_citation')
        row = dict(indexed[evidence_id])
        if quote is not None:
            if quote not in row['text']:
                raise KnowledgeError('citation_quote_not_found')
            row['quote'] = quote
        validated.append(row)
        seen.add(evidence_id)
    return validated
