# MIT white0dew/XiaohongshuSkills @ 34d36e7a7703fdcd0b6d6d5c04028cabbabe3dde
# Complete selected methods preserved; see publishing_vendor/LICENSE-white0dew.
import json
ACTION_INTERVAL=1
class CDPError(RuntimeError):pass
SELECTORS = {
    # "上传图文" tab - must click before uploading images
    "image_text_tab": "div.creator-tab",
    "image_text_tab_text": "上传图文",
    # "上传视频" tab - must click before uploading video
    "video_tab": "div.creator-tab",
    "video_tab_text": "上传视频",
    # Upload area - the file input element for images (visible after clicking tab)
    "upload_input": ".upload-input",
    "upload_input_alt": 'input[type="file"]',
    # Title input field (visible after image upload)
    "title_input": "div.d-input input",
    "title_input_alt": 'input[placeholder*="填写标题"], input[placeholder*="标题"], input.d-text',
    # Content editor area - current creator center may expose TipTap, ProseMirror or Quill.
    "content_editor": "div.tiptap.ProseMirror",
    "content_editor_alt": 'div.ProseMirror[contenteditable="true"]',
    "content_editor_alt2": "div.ql-editor",
    "content_placeholder_text": "输入正文描述",
    # Publish button
    "publish_button": ".publish-page-publish-btn button.bg-red",
    "publish_button_text": "发布",
    "schedule_publish_button_text": "定时发布",
    "schedule_switch": ".post-time-wrapper .d-switch",
    "schedule_datetime_input": ".date-picker-container input",
    "image_preview_items": ".img-preview-area .pr",
    # Login indicator - URL-based check (redirect to /login if not logged in)
    "login_indicator": '.user-info, .creator-header, [class*="user"]',
}

class EditorMethods:
    def _find_content_editor_selector(self) -> str | None:
        """Return the best available content editor selector for the current page."""
        placeholder_literal = json.dumps(SELECTORS["content_placeholder_text"])
        selector = self._evaluate(f"""
            (() => {{
                const directSelectors = [
                    {json.dumps(SELECTORS["content_editor"])},
                    {json.dumps(SELECTORS["content_editor_alt"])},
                    {json.dumps(SELECTORS["content_editor_alt2"])},
                    "[role='textbox']",
                ];
                for (const selector of directSelectors) {{
                    const node = document.querySelector(selector);
                    if (
                        node instanceof HTMLElement &&
                        node.offsetParent !== null &&
                        node.getBoundingClientRect().width > 0 &&
                        node.getBoundingClientRect().height > 0
                    ) {{
                        return selector;
                    }}
                }}

                const placeholder = {placeholder_literal};
                const candidates = document.querySelectorAll("p[data-placeholder], div[data-placeholder]");
                for (const node of candidates) {{
                    const value = (node.getAttribute("data-placeholder") || "").trim();
                    if (!value.includes(placeholder)) {{
                        continue;
                    }}
                    let current = node;
                    for (let depth = 0; depth < 5 && current; depth += 1) {{
                        current = current.parentElement;
                        if (
                            current instanceof HTMLElement &&
                            current.getAttribute("role") === "textbox"
                        ) {{
                            return "[role='textbox']";
                        }}
                    }}
                }}
                return null;
            }})()
        """)
        return selector if isinstance(selector, str) and selector.strip() else None

    def _fill_title(self, title: str):
        """Fill in the article title."""
        print(f"[cdp_publish] Setting title: {title[:40]}...")
        self._sleep(ACTION_INTERVAL, minimum_seconds=0.25)

        for selector in (SELECTORS["title_input"], SELECTORS["title_input_alt"]):
            found = self._evaluate(f"!!document.querySelector('{selector}')")
            if found:
                escaped_title = json.dumps(title)
                self._evaluate(f"""
                    (function() {{
                        var el = document.querySelector('{selector}');
                        var nativeSetter = Object.getOwnPropertyDescriptor(
                            window.HTMLInputElement.prototype, 'value'
                        ).set;
                        el.focus();
                        nativeSetter.call(el, {escaped_title});
                        el.dispatchEvent(new Event('input', {{ bubbles: true }}));
                        el.dispatchEvent(new Event('change', {{ bubbles: true }}));
                        el.blur();
                    }})();
                """)
                print("[cdp_publish] Title set.")
                return

        raise CDPError("Could not find title input element.")

    def _fill_content(self, content: str):
        """Fill in the article body content using the current creator editor."""
        print(f"[cdp_publish] Setting content ({len(content)} chars)...")
        self._sleep(ACTION_INTERVAL, minimum_seconds=0.25)
        selector = self._find_content_editor_selector()
        if not selector:
            raise CDPError("Could not find content editor element.")

        escaped = json.dumps(content)
        placeholder_literal = json.dumps(SELECTORS["content_placeholder_text"])
        result = self._evaluate(f"""
            (() => {{
                const selector = {json.dumps(selector)};
                const placeholder = {placeholder_literal};
                let el = document.querySelector(selector);
                if (!(el instanceof HTMLElement) || el.offsetParent === null) {{
                    const candidates = document.querySelectorAll("p[data-placeholder], div[data-placeholder]");
                    for (const node of candidates) {{
                        const value = (node.getAttribute("data-placeholder") || "").trim();
                        if (!value.includes(placeholder)) {{
                            continue;
                        }}
                        let current = node;
                        for (let depth = 0; depth < 5 && current; depth += 1) {{
                            current = current.parentElement;
                            if (
                                current instanceof HTMLElement &&
                                current.getAttribute("role") === "textbox"
                            ) {{
                                el = current;
                                break;
                            }}
                        }}
                        if (el instanceof HTMLElement) {{
                            break;
                        }}
                    }}
                }}

                if (!(el instanceof HTMLElement)) {{
                    return false;
                }}

                const text = {escaped};
                const parts = text.split("\\n");
                const lines = parts.length ? parts : [""];

                el.focus();
                while (el.firstChild) {{
                    el.removeChild(el.firstChild);
                }}

                for (const line of lines) {{
                    const paragraph = document.createElement("p");
                    if (line) {{
                        paragraph.textContent = line;
                    }} else {{
                        paragraph.appendChild(document.createElement("br"));
                    }}
                    el.appendChild(paragraph);
                }}

                el.dispatchEvent(new Event("input", {{ bubbles: true }}));
                el.dispatchEvent(new Event("change", {{ bubbles: true }}));
                return true;
            }})()
        """)
        if not result:
            raise CDPError("Could not set content into creator editor.")

        print(f"[cdp_publish] Content set via selector: {selector}")
