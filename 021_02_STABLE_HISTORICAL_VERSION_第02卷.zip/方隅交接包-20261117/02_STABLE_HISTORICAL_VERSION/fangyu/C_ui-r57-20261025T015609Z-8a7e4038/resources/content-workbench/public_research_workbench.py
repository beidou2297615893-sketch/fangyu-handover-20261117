"""Public snippets enter the original account workspace only after selection."""
from copy import deepcopy
from datetime import datetime,timezone
from urllib.parse import urlsplit
import importlib,json,re

def sibling(name):return importlib.import_module('.'+name,__package__)
base=sibling('content_workbench')
digest,fail,now=base.digest,base.fail,base.now

def searches(state):
 rows=state.setdefault('publicResearch',[])
 if not isinstance(rows,list) or len(rows)>30:fail('PUBLIC_SEARCH_RECORD_INVALID','公开检索记录需要核对',409)
 for r in rows:
  if not isinstance(r,dict) or r.get('digest')!=digest({k:v for k,v in r.items() if k!='digest'}):fail('PUBLIC_SEARCH_RECORD_INVALID','公开检索来源版本需要核对',409)
 return rows

def account_binding(a):return {k:a.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','auth_generation','identity_revalidation_generation')}

def replay(wb,row,actor,account,receipt):
 return {'workspace':wb._public(row,actor,account),'result':deepcopy(receipt['result']),'receipt':{**{k:deepcopy(v) for k,v in receipt.items() if k!='result'},'found':True},'replayed':True}

def preview(wb,user,scope,data,request,input_hash,authority):
 provider=sibling('public_search_provider')
 query=provider.query_text(data['query'])
 if data['confirmedPublicQuery'] is not True:fail('PUBLIC_SEARCH_CONFIRM_REQUIRED','请本人点击联网找参考，只发送填写的公开检索词',400)
 with wb.store.connect() as db:
  db.execute('BEGIN IMMEDIATE');actor,account=wb._authorized(db,user,scope,authority,True)
  row=wb._workspace(db,scope,actor);state=wb._state(row);items=searches(state)
  old=wb._prior(row,'content_public_research_preview',request,input_hash)
  if old:return replay(wb,row,actor,account,old)
  if row['revision']!=data['expectedRevision']:fail('CONTENT_REVISION_CONFLICT','资料已更新，请重新读取后检索',409)
  clock=datetime.now(timezone.utc)
  def age(r):
   try:
    value=datetime.fromisoformat(r['createdAt']);assert value.tzinfo is not None
    return max(0,(clock-value).total_seconds())
   except Exception:fail('PUBLIC_SEARCH_RECORD_INVALID','原检索时间需要核对',409)
  same=[r for r in items if r['query']==query]
  if any(r['state']=='unknown' and not r.get('completedAt') and age(r)<30 for r in same):
   fail('PUBLIC_SEARCH_IN_PROGRESS','这组检索词的原请求仍在处理中，请稍后核对原记录',409)
  if sum(age(r)<600 for r in same)>=3:
   fail('PUBLIC_SEARCH_COOLDOWN','这组检索词十分钟内已手动搜索三次，请稍后再点击；原记录仍保留',409)
  if len(items)>=30:
   expired=next((r for r in items if age(r)>=600),None)
   if expired is None:fail('PUBLIC_SEARCH_COOLDOWN','本账号十分钟内公开搜索较多，请稍后再点击；原回执仍保留',409)
   # The original Store's archived request receipt retains the complete source
   # snapshot. Bound the active list, not the lifetime number of failed queries.
   items.remove(expired)
  frozen=account_binding(account);search={'id':digest(['public-search',row['id'],request]),'requestId':request,'query':query,
   'createdAt':now(),'state':'unknown','code':'PUBLIC_SEARCH_RESULT_UNKNOWN','provider':'ddgs-9.16.0/duckduckgo-only',
   'accountBinding':frozen,'results':[],'fullTextFetched':False,'factsVerified':False,'requiresHumanSelection':True}
  search['digest']=digest(search);items.append(search)
  wb._save(db,scope,actor,row,'content_public_research_preview',request,input_hash,{'publicResearch':deepcopy(search),'modelCalled':False,'newKnowledgeDocuments':0},authority,receipt_state='unknown')
 wb._public_research_reserved=True
 search_id=search['id'];reserved_digest=search['digest'];answer=None;error='PUBLIC_SEARCH_RESULT_UNKNOWN'
 # No Store connection or global backend lock is held across network I/O.
 try:
  invoke=getattr(wb,'public_search_provider',None)
  answer=invoke(query) if callable(invoke) else provider.search(query)
  if not isinstance(answer,dict) or answer.get('contract')!=provider.CONTRACT or answer.get('query')!=query:raise ValueError()
  error=None
 except Exception as exc:
  error=getattr(exc,'code','PUBLIC_SEARCH_RESULT_UNKNOWN')
  if not isinstance(error,str) or len(error)>80:error='PUBLIC_SEARCH_RESULT_UNKNOWN'
 with wb.store.connect() as db:
  db.execute('BEGIN IMMEDIATE');actor,account=wb._authorized(db,user,scope,authority,True)
  if account_binding(account)!=frozen:fail('CONTENT_ACCOUNT_CHANGED','内容账号身份已变化，原检索已保留，未安装外部结果',403)
  row=wb._workspace(db,scope,actor);state=wb._state(row);current=next((r for r in searches(state) if r['id']==search_id),None)
  if current is None or current['digest']!=reserved_digest:fail('PUBLIC_SEARCH_SOURCE_CHANGED','原检索快照已变化，未安装外部结果',409)
  receipt=wb._prior(row,'content_public_research_preview',request,input_hash)
  if receipt is None:fail('PUBLIC_SEARCH_RECORD_INVALID','原检索回执缺失，请保留原编号',409)
  current.pop('digest');current['completedAt']=now()
  if error is None:
   current.update(state='received',code=None,retrievedAt=answer['retrievedAt'],results=deepcopy(answer['results']),
    responseBytes=answer['responseBytes'],resultUrlsFetched=0,restrictedView=any(r['restrictedView'] for r in answer['results']))
  else:current.update(state='unknown',code=error,results=[])
  current['digest']=digest(current)
  result={'publicResearch':deepcopy(current),'modelCalled':False,'newKnowledgeDocuments':0,'resultUrlsFetched':0}
  row['revision']+=1;row['updatedAt']=now();receipt.update(state='succeeded' if error is None else 'unknown',revision=row['revision'],result=deepcopy(result))
  row['lastReceipt']={k:deepcopy(v) for k,v in receipt.items() if k!='result'};wb._write(db,scope,row)
  return {'workspace':wb._public(row,actor,account),'result':result,'receipt':{**row['lastReceipt'],'found':True}}

def operate(wb,action,data,row,state,scope,actor,db):
 items=searches(state)
 if 'searchId' in data and (not isinstance(data['searchId'],str) or not re.fullmatch('[0-9a-f]{64}',data['searchId'])):fail('PUBLIC_SEARCH_INPUT_INVALID','请选择当前账号保存的原检索记录',400)
 if action=='content_public_research_read':
  if 'searchId' not in data:return {'publicResearchHistory':[deepcopy(r) for r in items],'modelCalled':False,'externalRequests':0}
  item=next((r for r in items if r['id']==data['searchId']),None)
  if item is None:fail('PUBLIC_SEARCH_RECORD_MISSING','未找到当前账号的原检索记录',409)
  return {'publicResearch':deepcopy(item),'modelCalled':False,'externalRequests':0}
 item=next((r for r in items if r['id']==data['searchId']),None)
 if item is None or item['digest']!=data['searchDigest'] or item['state']!='received':fail('PUBLIC_SEARCH_SOURCE_CHANGED','所选来源快照已变化或仍待核对，请读取原结果',409)
 current=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('accounts',scope.account_id,scope.tenant_id)).fetchone()
 if current is None or account_binding(json.loads(current['body']))!=item['accountBinding']:fail('PUBLIC_SEARCH_SOURCE_CHANGED','内容账号身份已变化，原检索只供核对，不能直接导入',409)
 refs=data['resultRefs']
 if not isinstance(refs,list) or not 1<=len(refs)<=5 or any(not isinstance(r,dict) or set(r)!={'id','digest'} or not isinstance(r['id'],str) or not isinstance(r['digest'],str) or not re.fullmatch('ref-[0-9a-f]{64}',r['id']) or not re.fullmatch('[0-9a-f]{64}',r['digest']) for r in refs) or len({r['id'] for r in refs})!=len(refs):
  fail('PUBLIC_SEARCH_INPUT_INVALID','请勾选1至5条原检索结果，不上传标题、网址或正文',400)
 chosen=[]
 for ref in refs:
  result=next((r for r in item['results'] if r['id']==ref['id'] and r['digest']==ref['digest']),None)
  if result is None:fail('PUBLIC_SEARCH_SOURCE_CHANGED','勾选结果与原快照不符',409)
  chosen.append(result)
 documents=[];links=state.setdefault('publicResearchLinks',[])
 if not isinstance(links,list) or len(links)+len(chosen)>300:fail('PUBLIC_SEARCH_LIMIT','公开资料关联较多，请先整理',409)
 for result in chosen:
  # Stable original source+snippet identity. Query/time belong to the snapshot,
  # not the document body/label, so another query can reuse the original doc.
  document={'title':('公开检索摘要 · '+urlsplit(result['url']).hostname)[:120],
   'text':'来源网址：'+result['url']+'\n公开检索摘要，原文未抓取，内容待核实：\n'+result['snippet'],
   'kind':'hypothesis','sourceLabel':'公开检索摘要，原文未抓取'}
  saved=wb._operate('content_knowledge_import',{'document':document},row,state,scope,actor,db)
  doc=next(d for d in state['documents'] if d['id']==saved['document']['id']);doc['requiresExplicitReference']=True
  link={'searchId':item['id'],'searchDigest':item['digest'],'resultId':result['id'],'resultDigest':result['digest'],'documentId':doc['id']}
  if link not in links:links.append(link)
  documents.append({'id':doc['id'],'kind':'hypothesis','alreadyImported':saved['alreadyImported'],'requiresExplicitReference':True})
 return {'documents':documents,'sourceAssociations':[deepcopy(x) for x in links if x['searchId']==item['id']],
  'modelCalled':False,'factsVerified':False,'fullTextFetched':False,'published':False}
