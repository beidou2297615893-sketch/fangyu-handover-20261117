#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def ratio(numerator, denominator):
    if numerator is None or denominator in (None, 0):
        return None
    return numerator / denominator


def compare(value, baseline, low=0.75):
    if value is None or baseline in (None, 0):
        return None
    return "low" if value < baseline * low else "not_low"


def diagnose(data):
    exposures = data.get("exposures")
    opens = data.get("opens_or_plays")
    three = data.get("three_second_views")
    completed = data.get("completed_views")
    interactions = sum(data.get(k) or 0 for k in ("likes", "saves", "comments", "shares"))
    rates = {
        "open_rate": ratio(opens, exposures),
        "three_second_rate": ratio(three, opens),
        "completion_rate": ratio(completed, opens),
        "engagement_rate": ratio(interactions, opens),
        "profile_visit_rate": ratio(data.get("profile_visits"), opens),
        "follow_rate_from_profile": ratio(data.get("follows"), data.get("profile_visits")),
    }
    base = data.get("baseline") or {}
    comparable = base.get("comparable_posts") or 0
    note_format = data.get("format")
    comparisons = {
        "exposure": compare(exposures, base.get("median_exposures")),
        "open": compare(rates["open_rate"], base.get("median_open_rate")),
        "early_retention": compare(rates["three_second_rate"], base.get("median_three_second_rate")),
        "completion": compare(rates["completion_rate"], base.get("median_completion_rate")),
        "engagement": compare(rates["engagement_rate"], base.get("median_engagement_rate")),
    }
    order = ["exposure", "open", "early_retention", "completion", "engagement"]
    bottleneck = next((stage for stage in order if comparisons[stage] == "low"), None)
    missing = [key for key, value in rates.items() if value is None]
    warnings = []
    if comparable < 3:
        warnings.append("Fewer than three comparable baseline posts; avoid group-level conclusions.")
    if note_format in ("carousel", "image") and any(
        data.get(k) is not None for k in ("three_second_views", "completed_views")
    ):
        warnings.append("Video-only metrics present on a carousel/image post; ignore them for diagnosis.")
    if note_format == "video" and data.get("three_second_views") is None and data.get("completed_views") is None:
        warnings.append("Video post missing retention/completion metrics; early-retention diagnosis may be unsupported.")
    if bottleneck is None:
        warnings.append("No supported bottleneck found; collect missing metrics or review qualitative evidence.")
    return {
        "format": note_format,
        "rates": rates,
        "baseline_comparisons": comparisons,
        "earliest_supported_bottleneck": bottleneck,
        "missing_rates": missing,
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser(description="Calculate bounded Xiaohongshu funnel signals.")
    parser.add_argument("input", help="Path to metrics JSON")
    args = parser.parse_args()
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    print(json.dumps(diagnose(data), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

