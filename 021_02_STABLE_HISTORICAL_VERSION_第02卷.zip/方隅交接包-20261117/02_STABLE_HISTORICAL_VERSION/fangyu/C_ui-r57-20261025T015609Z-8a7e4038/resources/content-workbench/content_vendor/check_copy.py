#!/usr/bin/env python3
"""Flag Xiaohongshu copy for human review. Deterministic hints, not policy conclusions."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# Plain substrings that are almost always a problem in Xiaohongshu copy.
FLAGS = {
    "absolute_claim": ["绝对", "百分百", "100%", "全网第一", "最强", "永远", "保证"],
    "hype_phrase": ["颠覆", "炸裂", "闭眼入", "封神", "天花板"],
    "hard_cta": ["扣1", "私信领取", "评论区领取", "无偿分享"],
    "ai_voice": ["综上所述", "总的来说", "值得一提的是", "希望对你有所帮助", "在当今社会"],
    "generic_open": ["大家好呀", "今天来跟大家分享", "让我们一起", "不妨试着"],
}

# Patterns that only matter in a specific shape; bare keyword matching produces noise.
REGEX_FLAGS = {
    "ai_voice": [
        (r"随着[^。！？\n]{0,12}的(发展|普及|进步|到来)", "随着…的发展"),
        (r"本文将从[^。！？\n]{0,12}(方面|角度)", "本文将从…方面"),
        (r"首先[^。！？\n]{0,20}其次[^。！？\n]{0,20}最后", "首先…其次…最后"),
    ],
}

# Needs the content to actually contain reproducible steps; see title-craft.md.
CONDITIONAL = {
    "保姆级": "Only acceptable when the copy contains reproducible steps.",
    "手把手": "Only acceptable when the copy contains reproducible steps.",
}

LENGTH_BANDS = {"carousel": (300, 800), "video": (80, 220)}
STEP_MARKERS = ("1️⃣", "2️⃣", "步骤", "第一步", "第二步", "①", "②")


def inspect(text: str, note_format: str | None = None) -> dict:
    hits = []
    for category, phrases in FLAGS.items():
        for phrase in phrases:
            for match in re.finditer(re.escape(phrase), text, flags=re.IGNORECASE):
                hits.append({"category": category, "phrase": phrase, "offset": match.start()})
    for category, patterns in REGEX_FLAGS.items():
        for pattern, label in patterns:
            for match in re.finditer(pattern, text):
                hits.append({"category": category, "phrase": label, "offset": match.start()})

    has_steps = any(marker in text for marker in STEP_MARKERS) or bool(re.search(r"^\s*\d+[.、)]", text, re.M))
    for phrase, reason in CONDITIONAL.items():
        if phrase in text and not has_steps:
            hits.append(
                {
                    "category": "conditional_claim",
                    "phrase": phrase,
                    "offset": text.index(phrase),
                    "reason": reason,
                }
            )

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    chars = len(re.sub(r"\s", "", text))
    length_check = None
    if note_format in LENGTH_BANDS:
        low, high = LENGTH_BANDS[note_format]
        if chars < low:
            length_check = f"{chars} chars is below the {note_format} band {low}-{high}"
        elif chars > high:
            length_check = f"{chars} chars exceeds the {note_format} band {low}-{high}"

    emoji_count = len(re.findall(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]", text))

    return {
        "format": note_format,
        "characters": len(text),
        "characters_excluding_whitespace": chars,
        "nonempty_lines": len(lines),
        "emoji_count": emoji_count,
        "contains_step_markers": has_steps,
        "length_check": length_check,
        "long_lines": [{"line": i + 1, "characters": len(v)} for i, v in enumerate(lines) if len(v) > 45],
        "flags": hits,
        "note": "Flags require contextual human review; they are not legal or platform-policy conclusions.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Flag Xiaohongshu copy for review.")
    parser.add_argument("input", help="UTF-8 text file or '-' for stdin")
    parser.add_argument(
        "--format",
        choices=["carousel", "video", "image"],
        help="Enables the format-specific length band check",
    )
    args = parser.parse_args()

    text = sys.stdin.read() if args.input == "-" else Path(args.input).expanduser().read_text(encoding="utf-8")
    note_format = "carousel" if args.format == "image" else args.format
    print(json.dumps(inspect(text, note_format), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
