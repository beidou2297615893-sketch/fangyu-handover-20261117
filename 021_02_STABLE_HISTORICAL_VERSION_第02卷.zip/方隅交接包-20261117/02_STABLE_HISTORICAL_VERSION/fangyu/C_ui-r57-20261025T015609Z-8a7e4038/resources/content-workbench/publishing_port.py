"""Host-only publication port. No credentials, URL discovery, new browser or retry.

Independent central publish authority and a live original owned session are
mandatory dependencies. Only explicit host injection enables this port.
"""
from contextlib import contextmanager
from copy import deepcopy
import base64,hashlib,importlib,json,re,time,uuid
from pathlib import Path
import tempfile

def sibling(name):return importlib.import_module('.'+name,__package__) if __package__ else importlib.import_module(name)
methods=sibling('publishing_dom_methods')
CONTRACT='fangyu-content-publication-v1'

class PublishUnavailable(RuntimeError):
    code='PUBLISH_AUTHORITY_UNAVAILABLE'
    status=503

def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()

def strict_json(raw):
    def pairs(items):
        out={}
        for key,value in items:
            if key in out:raise ValueError('Duplicate JSON key')
            out[key]=value
        return out
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))

class StrictPublishJSON:
    """Pinned exact JSON mapping, supplied only after a genuine wire sample review.

    No default endpoint or tolerant ID search is guessed. JSON paths are fixed
    tuples, not expressions. This handles exact observed request/response shapes
    without executing a manifest-provided parser. Real XHS mapping remains a gate.
    """
    def __init__(self,*,endpoint,request_paths,response_paths,success_value,revision):
        from urllib.parse import urlsplit
        url=urlsplit(endpoint)
        if url.scheme!='https' or url.netloc not in ('creator.xiaohongshu.com','edith.xiaohongshu.com') or url.query or url.fragment:
            raise ValueError('Unapproved publication endpoint')
        if set(request_paths)!={'title','body','assetTokens'} or set(response_paths)!={'success','postId','accountUid'}:
            raise ValueError('Incomplete exact publication mapping')
        for path in (*request_paths.values(),*response_paths.values()):
            if not isinstance(path,tuple) or not path or any(not isinstance(k,(str,int)) or isinstance(k,bool) for k in path):raise ValueError('Invalid JSON path')
        if not isinstance(revision,str) or not revision:raise ValueError('Wire contract revision required')
        self.endpoint,self.request_paths,self.response_paths,self.success_value,self.revision=endpoint,request_paths,response_paths,success_value,revision

    @staticmethod
    def at(value,path):
        for key in path:value=value[key]
        return value

    def request_matches(self,url,method,raw,expected):
        if url!=self.endpoint or method!='POST' or not isinstance(raw,str) or len(raw)>2_000_000:return False
        try:
            body=strict_json(raw)
            return all(self.at(body,self.request_paths[k])==expected[k] for k in self.request_paths)
        except (ValueError,TypeError,KeyError,IndexError):return False

    def response(self,raw):
        try:
            if not isinstance(raw,str) or len(raw)>2_000_000:return None
            body=strict_json(raw);values={k:self.at(body,p) for k,p in self.response_paths.items()}
            if values['success']!=self.success_value or type(values['success'])!=type(self.success_value):return None
            if not re.fullmatch(r'[0-9a-f]{24}',str(values['postId'])) or not isinstance(values['accountUid'],str):return None
            return values
        except (ValueError,TypeError,KeyError,IndexError):return None

class PublicationObserver:
    """Receives ONLY this owned CDP session's events; never sends a request.

    Host wires Network.requestWillBeSent, responseReceived, loadingFinished,
    getResponseBody with their genuine transport request IDs and session IDs.
    A DOM URL, toast, old work ID or response on another request cannot succeed.
    """
    def __init__(self,codec,store):
        if not isinstance(codec,StrictPublishJSON):raise ValueError('Pinned wire codec required')
        self.codec=codec;self.store=store;self.armed=None;self.pending={};self.receipts={};self.permitted={}

    def arm(self,envelope,session_id,expected):
        if self.armed is not None:raise PublishUnavailable('Observer already armed')
        self.armed={'envelope':deepcopy(envelope),'sessionId':session_id,'expected':deepcopy(expected),'at':time.monotonic(),'nonce':uuid.uuid4().hex}
        return self.armed['nonce']

    def permit_final_request(self,*,session_id,network_request_id,url,method,post_data):
        """Called by the owned Fetch.requestPaused guard BEFORE transmission.

        The native host MUST continue this exact network ID only on True and
        fail any other create request. Observation alone cannot prevent retries.
        """
        a=self.armed
        if (not a or session_id!=a['sessionId'] or not isinstance(network_request_id,str) or not network_request_id
                or a.get('createConsumed') or not self.codec.request_matches(url,method,post_data,a['expected'])):return False
        a['createConsumed']=True;self.permitted[network_request_id]=(session_id,hashlib.sha256(post_data.encode()).hexdigest(),a['nonce'])
        return True

    def request(self,*,session_id,request_id,url,method,post_data,timestamp):
        a=self.armed
        if not a or session_id!=a['sessionId'] or not isinstance(timestamp,(int,float)) or timestamp<a['at']:return False
        if not isinstance(request_id,str) or not request_id or request_id in self.pending:return False
        if not self.codec.request_matches(url,method,post_data,a['expected']):return False
        if self.permitted.get(request_id)!=(session_id,hashlib.sha256(post_data.encode()).hexdigest(),a['nonce']):return False
        self.pending[request_id]={'sessionId':session_id,'requestBodyDigest':hashlib.sha256(post_data.encode()).hexdigest(),'armed':deepcopy(a),'responseOK':False}
        return True

    def response_received(self,*,session_id,request_id,url,status):
        row=self.pending.get(request_id)
        if row and row['sessionId']==session_id and url==self.codec.endpoint and type(status) is int and 200<=status<300:
            row['responseOK']=True

    def response_body(self,*,session_id,request_id,raw):
        row=self.pending.get(request_id)
        if not row or row['sessionId']!=session_id or row['responseOK'] is not True:return None
        result=self.codec.response(raw);env=row['armed']['envelope']
        if not result or result['accountUid']!=env['snapshot']['accountUid']:return None
        receipt={'intentId':env['intentId'],'requestId':env['requestId'],'snapshotDigest':env['snapshotDigest'],
            'accountUid':result['accountUid'],'postId':result['postId'],'verifiedNewPublication':True,
            'transportRequestId':request_id,'requestBodyDigest':row['requestBodyDigest'],
            'responseBodyDigest':hashlib.sha256(raw.encode()).hexdigest(),'observerNonce':row['armed']['nonce'],
            'wireRevision':self.codec.revision}
        publication_key=digest([env['snapshot']['scope']['tenant_id'],result['accountUid'],result['postId']])
        previous=self.store.get('content_publication_post_v1',publication_key)
        if previous and previous.get('requestId')!=env['requestId']:return None
        self.receipts[env['requestId']]=receipt;self.armed=None
        scope=env['snapshot']['scope']
        record={'id':digest([scope['tenant_id'],env['requestId'],env['intentId'],env['snapshotDigest']]),
            'tenant_id':scope['tenant_id'],'receipt':deepcopy(receipt)}
        record['recordDigest']=digest(record)
        self.store.put('content_publication_observation_v1',record)
        self.store.put('content_publication_post_v1',dict(id=publication_key,tenant_id=scope['tenant_id'],requestId=env['requestId'],postId=result['postId']))
        return deepcopy(receipt)

    def status(self,envelope):
        found=self.receipts.get(envelope['requestId'])
        if found is None:
            key=digest([envelope['snapshot']['scope']['tenant_id'],envelope['requestId'],envelope['intentId'],envelope['snapshotDigest']])
            record=self.store.get('content_publication_observation_v1',key)
            if record and record.get('recordDigest')==digest({k:v for k,v in record.items() if k!='recordDigest'}):found=record.get('receipt')
        if found and found['intentId']==envelope['intentId'] and found['snapshotDigest']==envelope['snapshotDigest']:
            return {'state':'published','receipt':deepcopy(found)}
        return {'state':'unknown'}

class OwnedDOMPublisher(methods.EditorMethods):
    """MIT editor implementation over an injected, existing owned host session.

    Session interface: binding(), evaluate(), select_image_mode(),
    set_file_input_files(), wait_uploaded(), uploaded_tokens(), form_snapshot(),
    publish_button_rect(), click_once(), wait_publication_receipt(), observer.
    The host owns DOM/CDP operation allowlists; no raw port is obtained here.
    """
    def __init__(self,session,stage_dir):
        self.session=session;self.stage_dir=Path(stage_dir)
        if not self.stage_dir.is_absolute() or not self.stage_dir.is_dir():raise PublishUnavailable('Project material directory required')
        self.clicked=set()

    def _evaluate(self,source):return self.session.evaluate(source)
    def _sleep(self,*args,**kwargs):return None

    @contextmanager
    def materialized(self,assets):
        with tempfile.TemporaryDirectory(prefix='publish-material-',dir=self.stage_dir) as directory:
            paths=[]
            for i,asset in enumerate(assets):
                head,payload=asset['dataUrl'].split(',',1)
                if head!='data:image/png;base64':raise PublishUnavailable('Only normalized original PNG blobs accepted')
                raw=base64.b64decode(payload,validate=True)
                if hashlib.sha256(raw).hexdigest()!=asset['sha256']:raise PublishUnavailable('Asset hash changed')
                path=Path(directory)/(str(i+1)+'.png');path.write_bytes(raw);paths.append(str(path))
            yield paths

    def fill(self,envelope,assets):
        if self.session.form_is_empty() is not True:raise PublishUnavailable('Existing creator draft must be reviewed before filling')
        self.session.select_image_mode(methods.SELECTORS['image_text_tab'],methods.SELECTORS['image_text_tab_text'])
        with self.materialized(assets) as paths:
            for i,path in enumerate(paths):
                self.session.set_file_input_files((methods.SELECTORS['upload_input'],methods.SELECTORS['upload_input_alt']),[path])
                self.session.wait_uploaded(i+1)
        self._fill_title(envelope['snapshot']['title']);self._fill_content(envelope['snapshot']['body'])
        tokens=self.session.uploaded_tokens()
        if not isinstance(tokens,list) or len(tokens)!=len(assets) or any(not isinstance(t,str) or not t for t in tokens):
            raise PublishUnavailable('Upload token order not verified')
        expected={'title':envelope['snapshot']['title'],'body':envelope['snapshot']['body'],'assetTokens':tokens}
        if self.session.form_snapshot()!=expected:raise PublishUnavailable('Filled form differs from approved snapshot')
        return expected

    def click(self,envelope,expected):
        key=envelope['requestId']
        if key in self.clicked:raise PublishUnavailable('Publish click already consumed')
        if self.session.form_snapshot()!=expected:raise PublishUnavailable('Form changed before click')
        rect=self.session.publish_button_rect(methods.SELECTORS['publish_button'])
        if not isinstance(rect,dict) or rect.get('enabled') is not True or any(type(rect.get(k)) not in (int,float) for k in ('x','y','width','height')) or rect['width']<=0 or rect['height']<=0:
            raise PublishUnavailable('Exact publish button not ready')
        self.session.observer.arm(envelope,self.session.binding()['ownedSessionId'],expected)
        if self.session.publication_guard_installed(self.session.observer) is not True:raise PublishUnavailable('Single-create native request guard not attached')
        self.clicked.add(key) # A transport exception must never trigger a second click.
        self.session.click_once(rect['x']+rect['width']/2,rect['y']+rect['height']/2)
        self.session.wait_publication_receipt(key)
        return self.session.observer.status(envelope)

class OwnedPublishPort:
    def __init__(self,*,store,authority,session_provider,lease_acquire,lease_release,stage_dir):
        if any(not callable(fn) for fn in (authority,session_provider,lease_acquire,lease_release)):raise ValueError('Explicit controlled host dependencies required')
        self.authority,self.sessions,self.acquire,self.release=authority,session_provider,lease_acquire,lease_release
        self.store=store;self.stage_dir=stage_dir;self.reservations={};self.observers={}

    def _grant(self,envelope,phase):
        snap=envelope['snapshot'];scope=snap['scope'];proof=self.authority(deepcopy(envelope),phase)
        expected={'contract':'fangyu-publication-capability-v1','enabled':True,'centralVerified':True,'action':'publish',
            'tenantId':scope['tenant_id'],'storeId':scope['store_id'],'accountId':scope['account_id'],
            'accountUid':snap['accountUid'],'owner':snap['owner'],'platform':'xiaohongshu',
            'intentId':envelope['intentId'],'requestId':envelope['requestId'],'snapshotDigest':envelope['snapshotDigest']}
        if not isinstance(proof,dict) or any(type(proof.get(k))!=type(v) or proof.get(k)!=v for k,v in expected.items()):
            raise PublishUnavailable('Independent central publication grant required')
        if not isinstance(proof.get('deviceId'),str) or not proof['deviceId'] or not re.fullmatch(r'[a-f0-9]{64}',str(proof.get('grantRevision',''))):raise PublishUnavailable('Bound executor proof required')
        if type(proof.get('expiresAt')) not in (float,int) or not time.time()<proof['expiresAt']<=time.time()+65:raise PublishUnavailable('Fresh single-intent grant required')
        return proof

    def _binding(self,envelope,session,expected=None):
        snap=envelope['snapshot'];scope=snap['scope'];binding=session.binding()
        if not isinstance(binding,dict) or binding.get('existingOwnedSession') is not True or any(binding.get(k)!=v for k,v in {
            'accountId':scope['account_id'],'accountUid':snap['accountUid'],'owner':snap['owner'],'platform':'xiaohongshu'}.items()):
            raise PublishUnavailable('Original live account session required')
        for name in ('ownedSessionId','sessionRevision','profileIdentityDigest','runtimeId','deviceId'):
            if not isinstance(binding.get(name),str) or not binding[name]:raise PublishUnavailable('Incomplete original session proof')
        if binding.get('creatorOrigin')!='https://creator.xiaohongshu.com':raise PublishUnavailable('Creator origin mismatch')
        if expected is not None and binding!=expected:raise PublishUnavailable('Original account session changed')
        if not isinstance(getattr(session,'observer',None),PublicationObserver):raise PublishUnavailable('Strict owned receipt observer required')
        if session.observer.store is not self.store:raise PublishUnavailable('Receipt archive must use original Store')
        if session.publication_guard_installed(session.observer) is not True:raise PublishUnavailable('Owned native single-create guard required')
        return binding

    def preflight(self,envelope):
        if envelope.get('contract')!=CONTRACT:raise PublishUnavailable('Invalid publication intent')
        grant=self._grant(envelope,'preflight');session=self.sessions(deepcopy(envelope))
        binding=self._binding(envelope,session)
        if grant['deviceId']!=binding['deviceId']:raise PublishUnavailable('Executor device mismatch')
        if grant.get('adapterRevision')!='owned-publish-port-v1' or grant.get('wireRevision')!=session.observer.codec.revision:
            raise PublishUnavailable('Publication executor/wire revision not approved')
        token=uuid.uuid4().hex
        self.reservations[token]={'envelope':deepcopy(envelope),'session':session,'binding':binding,'consumed':False}
        return token

    def dispatch(self,envelope,assets,reservation):
        r=self.reservations.get(reservation);clicked=False;leased=False
        if not r or r['consumed'] or r['envelope']!=envelope:raise PublishUnavailable('Unbound host dispatch')
        r['consumed']=True;scope=envelope['snapshot']['scope'];owner='publication:'+envelope['intentId']
        try:
            self.acquire(scope['account_id'],scope['tenant_id'],'publishing',owner);leased=True
            self._grant(envelope,'before_fill');self._binding(envelope,r['session'],r['binding'])
            driver=OwnedDOMPublisher(r['session'],self.stage_dir);expected=driver.fill(envelope,assets)
            grant=self._grant(envelope,'before_click');binding=self._binding(envelope,r['session'],r['binding'])
            if grant['deviceId']!=binding['deviceId']:raise PublishUnavailable('Executor changed')
            if grant.get('adapterRevision')!='owned-publish-port-v1' or grant.get('wireRevision')!=r['session'].observer.codec.revision:raise PublishUnavailable('Publication contract changed')
            clicked=True # Mark unknown even if the one click transport fails.
            self.observers[envelope['requestId']]=(deepcopy(envelope),r['session'].observer)
            return driver.click(envelope,expected)
        except Exception:
            return {'state':'unknown'} if clicked else {'state':'not_sent','dispatchStarted':False}
        # The account mode is released only after the original business result
        # commits a proven terminal state. Unknown survives process exit.

    def settled(self,envelope):
        scope=envelope['snapshot']['scope']
        return self.release(scope['account_id'],scope['tenant_id'],'publication:'+envelope['intentId'])

    def status(self,envelope):
        self._grant(envelope,'status')
        found=self.observers.get(envelope['requestId'])
        if not found:
            session=self.sessions(deepcopy(envelope));self._binding(envelope,session)
            return session.observer.status(envelope)
        if found[0]!=envelope:return {'state':'unknown'}
        return found[1].status(envelope)
