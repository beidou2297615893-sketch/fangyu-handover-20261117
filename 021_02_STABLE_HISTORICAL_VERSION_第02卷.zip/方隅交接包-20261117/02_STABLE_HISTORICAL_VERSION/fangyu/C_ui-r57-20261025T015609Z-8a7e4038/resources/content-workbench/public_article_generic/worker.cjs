'use strict';
// Trusted pinned parser, untrusted HTML is data only. This is not an OS sandbox.
// Initialize Node's inherited pipe handles before prohibiting network sockets.
// On Windows lazy stdio construction itself uses the Socket implementation.
const inputStream=process.stdin,outputStream=process.stdout,errorStream=process.stderr;
let attemptedNetwork=0;
const deny=()=>{attemptedNetwork++;throw new Error('PUBLIC_ARTICLE_NETWORK_FORBIDDEN');};
for(const name of ['node:http','node:https']){const m=require(name);m.request=deny;m.get=deny;}
require('node:net').Socket.prototype.connect=deny;
require('node:tls').connect=deny;
require('node:http2').connect=deny;
require('node:dgram').createSocket=deny;
const dns=require('node:dns');for(const k of Object.keys(dns))if(/^(lookup|resolve|reverse)/.test(k)&&typeof dns[k]==='function')dns[k]=deny;
if(dns.promises)for(const k of Object.keys(dns.promises))if(typeof dns.promises[k]==='function')dns.promises[k]=deny;
for(const k of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork'])require('node:child_process')[k]=deny;
require('node:worker_threads').Worker=class{constructor(){deny();}};
globalThis.fetch=deny;globalThis.WebSocket=class{constructor(){deny();}};
const {JSDOM,VirtualConsole}=require('./node_modules/jsdom');
const Readability=require('./Readability.js');
const MAX_INPUT=4100000,MAX_HTML=2000000,MAX_TEXT=64000;
function text(value,max){return String(value??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').trim().slice(0,max);}
async function main(){
 let total=0,chunks=[];
 for await(const chunk of inputStream){total+=chunk.length;if(total>MAX_INPUT)throw Error('PUBLIC_ARTICLE_LIMIT');chunks.push(chunk);}
 const input=JSON.parse(Buffer.concat(chunks).toString('utf8'));
 if(!input||Object.keys(input).sort().join(',')!=='html,url'||typeof input.html!=='string'||typeof input.url!=='string'||Buffer.byteLength(input.html,'utf8')>MAX_HTML)throw Error('PUBLIC_ARTICLE_INPUT');
 const u=new URL(input.url);if(u.protocol!=='https:'||u.username||u.password||u.port&&u.port!=='443')throw Error('PUBLIC_ARTICLE_INPUT');
 let dom;
 try{
  // jsdom's default does NOT load subresources or execute scripts. Do not set
  // runScripts or resources:"usable". Network tripwires above fail closed too.
  dom=new JSDOM(input.html,{url:input.url,virtualConsole:new VirtualConsole(),storageQuota:1});
  const doc=dom.window.document;
  if(doc.getElementsByTagName('*').length>50000)throw Error('PUBLIC_ARTICLE_LIMIT');
  for(const e of doc.querySelectorAll('[hidden],[aria-hidden="true"]'))e.remove();
  for(const e of doc.querySelectorAll('[style]'))if(/(?:display\s*:\s*none|visibility\s*:\s*hidden)/i.test(e.getAttribute('style')))e.remove();
  const article=new Readability(doc,{charThreshold:100,maxElemsToParse:50000,serializer:el=>el}).parse();
  if(!article||!article.content||typeof article.content.querySelectorAll!=='function')throw Error('PUBLIC_ARTICLE_UNAVAILABLE');
  const content=article.content;
  for(const e of content.querySelectorAll('script,style,noscript,template,iframe,object,embed,svg,form,input,button,select,textarea'))e.remove();
  for(const e of content.querySelectorAll('p,div,section,article,br,h1,h2,h3,h4,li,blockquote,tr,td'))e.appendChild(e.ownerDocument.createTextNode('\n'));
  const body=String(content.textContent||'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').split('\n').map(s=>s.replace(/[\t\r\f\v ]+/g,' ').trim()).join('\n').replace(/\n{3,}/g,'\n\n').trim();
  if(body.length>MAX_TEXT)throw Error('PUBLIC_ARTICLE_LIMIT');
  if(body.length<100||(body.length<1500&&/(?:请先登录|登录后.{0,12}阅读全文|完成验证后|access denied|enable javascript|just a moment|sign.?in required)/i.test(body)))throw Error('PUBLIC_ARTICLE_UNAVAILABLE');
  if(attemptedNetwork!==0)throw Error('PUBLIC_ARTICLE_NETWORK_FORBIDDEN');
  const output={ok:true,text:body,title:text(article.title,500),author:text(article.byline,200),publishedTimeRaw:text(article.publishedTime,120),attemptedNetwork,imagesFetched:0,scriptsExecuted:false};
  const encoded=JSON.stringify(output);if(Buffer.byteLength(encoded,'utf8')>350000)throw Error('PUBLIC_ARTICLE_LIMIT');outputStream.write(encoded);
 }finally{if(dom)dom.window.close();}
}
main().catch(e=>{const code=['PUBLIC_ARTICLE_LIMIT','PUBLIC_ARTICLE_INPUT','PUBLIC_ARTICLE_NETWORK_FORBIDDEN'].includes(e?.message)?e.message:'PUBLIC_ARTICLE_UNAVAILABLE';outputStream.write(JSON.stringify({ok:false,code,attemptedNetwork}));process.exitCode=2;});
