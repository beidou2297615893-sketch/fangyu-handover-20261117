"""Explicitly confirmed, single-dispatch publication in the ORIGINAL Store.

No scheduler, browser/session creation, platform URL discovery or implicit retry.
The host must inject a separate publication-authorized OwnedPublishPort.
"""
from copy import deepcopy
import importlib,json,re,uuid

def sibling(name):
    return importlib.import_module('.'+name,__package__) if __package__ else importlib.import_module(name)

base=sibling('content_workflow')
ContentWorkflowWorkbench=base.ContentWorkflowWorkbench
ContentScope,digest,fail,fields,ident,now=base.ContentScope,base.digest,base.fail,base.fields,base.ident,base.now
ATTEMPTS='content_publication_attempt_v1'
REQUESTS='content_publication_request_v1'
SLOTS='content_publication_slot_v1'
ACTIONS=frozenset(('content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile'))
CONTRACT='fangyu-content-publication-v1'

class ContentPublicationWorkbench(ContentWorkflowWorkbench):
    def __init__(self,store,root_dir=None,model_adapter=None,publish_port=None):
        super().__init__(store,root_dir,model_adapter)
        self.publish_port=publish_port

    @staticmethod
    def _get(db,entity,key,tenant):
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,key,tenant)).fetchone()
        if not found:return None
        try:
            row=json.loads(found['body'])
            if row['id']!=key or row['tenant_id']!=tenant or row['recordDigest']!=digest({k:v for k,v in row.items() if k!='recordDigest'}):raise ValueError()
            return row
        except (KeyError,ValueError,TypeError):fail('PUBLISH_RECORD_INVALID','发布记录需要核对，原稿已保留',409)

    @staticmethod
    def _put(db,entity,row):
        row={k:deepcopy(v) for k,v in row.items() if k!='recordDigest'};row['recordDigest']=digest(row)
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))

    @staticmethod
    def _request_key(user,key):return digest([CONTRACT,user['tenant_id'],user['username'],key])

    def _owned_attempt(self,db,user,scope,key):
        row=self._get(db,ATTEMPTS,ident(key),scope.tenant_id)
        if not row or row['scope']!=scope.checked() or row['owner']!=user['username']:
            fail('PUBLISH_NOT_FOUND','请重新选择当前账号的发布记录',404)
        return row

    def _snapshot(self,db,user,scope,workspace,account,draft_id):
        uid=account.get('platform_uid')
        if not isinstance(uid,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',uid):
            fail('PUBLISH_IDENTITY_REQUIRED','请先完成当前账号的真实身份核对',409)
        draft=self._find(workspace,'drafts',draft_id)
        packet=self._package(db,workspace,self._state(workspace),scope,draft_id)['package']
        if draft['format']!='image':fail('PUBLISH_FORMAT_UNAVAILABLE','当前受控发布端口仅支持图文；视频稿已保留',409)
        if packet['state']!='package_ready' or draft.get('assetsNeedReview'):
            fail('PUBLISH_ASSETS_REQUIRED','请先核对当前版本的图片、顺序和授权',409)
        if not 1<=len(packet['assets'])<=9 or len(draft['title'])>20 or len(draft['body'])>1000:
            fail('PUBLISH_PLATFORM_LIMIT','图文发布须为1至9张图片、标题不超过20字、正文不超过1000字',409)
        snapshot={'scope':scope.checked(),'owner':user['username'],'accountUid':uid,
            'accountNickname':account.get('platform_nickname') or account.get('display_name') or account.get('nickname') or account['id'],
            'draftId':draft_id,'draftVersion':draft['version'],'title':draft['title'],'body':draft['body'],
            'assets':[{k:deepcopy(a[k]) for k in ('id','name','mime','sha256','source')} for a in packet['assets']],
            'audit':deepcopy(draft['audit']),'packageId':packet['id']}
        snapshot['snapshotDigest']=digest(snapshot)
        return snapshot

    def _assets(self,db,scope,workspace,snapshot):
        assets=[]
        for ref in snapshot['assets']:
            value=self._asset_read(db,scope,workspace,ref['id'])
            if value['sha256']!=ref['sha256']:fail('PUBLISH_SOURCE_CHANGED','图片内容已变化，请重新审核',409)
            assets.append({**ref,'dataUrl':value['dataUrl']})
        return assets

    @staticmethod
    def _publication_public(attempt):
        if not attempt:return None
        return {k:deepcopy(attempt[k]) for k in ('id','scope','snapshot','revision','state','createdAt','updatedAt','requestId','outcome','message') if k in attempt}

    def _answer(self,attempt,*,replayed=False,available=None):
        return {'publication':self._publication_public(attempt),'replayed':replayed,
            'publicationContract':CONTRACT,'capabilities':{'canPublish':available is True,'automaticPublishing':False,
                'canPrepare':True,'canConfirm':self.publish_port is not None,
                'status':'explicit_confirmation_required' if available else 'publish_authority_or_owned_host_required'}}

    def execute(self,action,user,store_id,data,authority_check=None):
        if action not in ACTIONS:return super().execute(action,user,store_id,data,authority_check)
        common={'accountId','platform'}
        optional={
            'content_publish_prepare':({'draftId','draftVersion','expectedRevision','requestId'},{'draftId','draftVersion','expectedRevision','requestId'}),
            'content_publish_read':({'intentId','requestId'},set()),
            'content_publish_confirm':({'intentId','expectedAttemptRevision','requestId','snapshotDigest','accountUid','humanConfirmed'},
                                      {'intentId','expectedAttemptRevision','requestId','snapshotDigest','accountUid','humanConfirmed'}),
            'content_publish_reconcile':({'intentId','expectedAttemptRevision','requestId'}, {'intentId','expectedAttemptRevision','requestId'})}
        allowed,required=optional[action];fields(data,common|allowed,common|required)
        scope=ContentScope(user.get('tenant_id','') if isinstance(user,dict) else '',ident(store_id),ident(data['accountId']),data['platform']);scope.checked()
        if scope.platform!='xiaohongshu':fail('PUBLISH_PLATFORM_UNAVAILABLE','当前平台的受控发布还未验收',503)
        request_id=ident(data['requestId']) if 'requestId' in data else None
        input_hash=digest({'action':action,'scope':scope.checked(),'input':{k:v for k,v in data.items() if k!='requestId'}})
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE' if action!='content_publish_read' else 'BEGIN')
            actor,account=self._authorized(db,user,scope,authority_check,action!='content_publish_read')
            workspace=self._workspace(db,scope,actor)
            prior=self._get(db,REQUESTS,self._request_key(actor,request_id),scope.tenant_id) if request_id else None
            if action=='content_publish_read':
                if bool(data.get('intentId'))==bool(request_id):fail('CONTENT_INPUT_INVALID','请选择原发布记录或原请求编号')
                attempt=self._owned_attempt(db,actor,scope,data['intentId'] if data.get('intentId') else prior['intentId']) if data.get('intentId') or prior else None
                return self._answer(attempt,replayed=bool(prior))
            if action!='content_publish_reconcile' and prior:
                if prior['action']!=action or prior['inputDigest']!=input_hash:fail('PUBLISH_REQUEST_CONFLICT','同一请求编号的内容已变化，请核对原操作',409)
                return self._answer(self._owned_attempt(db,actor,scope,prior['intentId']),replayed=True)
            if action=='content_publish_prepare':
                if type(data['expectedRevision']) is not int or data['expectedRevision']!=workspace['revision']:
                    fail('CONTENT_REVISION_CONFLICT','内容已变化，请重新读取',409)
                snap=self._snapshot(db,actor,scope,workspace,account,ident(data['draftId']))
                if type(data['draftVersion']) is not int or data['draftVersion']!=snap['draftVersion']:fail('PUBLISH_SOURCE_CHANGED','稿件版本已变化',409)
                attempt={'id':uuid.uuid4().hex,'tenant_id':scope.tenant_id,'scope':scope.checked(),'owner':actor['username'],
                    'snapshot':snap,'state':'prepared','revision':1,'createdAt':now(),'updatedAt':now(),'outcome':None,
                    'message':'请核对发布账号、标题、正文和图片顺序；确认后才会单次发布。'}
                self._authorized(db,user,scope,authority_check,True)
                self._put(db,ATTEMPTS,attempt)
                self._put(db,REQUESTS,{'id':self._request_key(actor,request_id),'tenant_id':scope.tenant_id,
                    'action':action,'inputDigest':input_hash,'intentId':attempt['id']})
                return self._answer(attempt)
            attempt=self._owned_attempt(db,actor,scope,data['intentId'])
            if type(data['expectedAttemptRevision']) is not int or data['expectedAttemptRevision']!=attempt['revision']:
                fail('PUBLISH_REVISION_CONFLICT','发布记录已变化，请读取原结果',409)
            if action=='content_publish_confirm':
                if data['humanConfirmed'] is not True or data['snapshotDigest']!=attempt['snapshot']['snapshotDigest'] or data['accountUid']!=attempt['snapshot']['accountUid']:
                    fail('PUBLISH_CONFIRMATION_REQUIRED','请本人核对当前稿件及发布账号后确认',409)
                if attempt['state']!='prepared':fail('PUBLISH_ALREADY_DISPATCHED','原发布已启动或结果待核对，不能再次派发',409)
                fresh=self._snapshot(db,actor,scope,workspace,account,attempt['snapshot']['draftId'])
                if fresh!=attempt['snapshot']:fail('PUBLISH_SOURCE_CHANGED','稿件、审核、图片或账号已变化，请重新准备',409)
                assets=self._assets(db,scope,workspace,fresh)
            else:
                if request_id!=attempt.get('requestId'):fail('PUBLISH_ORIGINAL_KEY_REQUIRED','仅可核对原发布请求，不可换编号重发',409)
                if attempt['state'] not in ('dispatching','unknown'):return self._answer(attempt,replayed=True)
                assets=None
        # Authority/session/profile waits occur outside SQLite and the UI lock.
        if self.publish_port is None:fail('PUBLISH_HOST_UNAVAILABLE','企业发布授权和原账号发布窗口尚未接通；草稿已保留',503)
        envelope={'contract':CONTRACT,'intentId':attempt['id'],'requestId':request_id,
            'snapshot':deepcopy(attempt['snapshot']),'snapshotDigest':attempt['snapshot']['snapshotDigest']}
        if action=='content_publish_reconcile':
            outcome=self.publish_port.status(envelope)
            return self._finish(user,scope,attempt,outcome,authority_check)
        reservation=self.publish_port.preflight(envelope)
        # Recheck all local facts after the external preflight before reserving.
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            actor,account=self._authorized(db,user,scope,authority_check,True)
            workspace=self._workspace(db,scope,actor)
            current=self._owned_attempt(db,actor,scope,attempt['id'])
            existing_request=self._get(db,REQUESTS,self._request_key(actor,request_id),scope.tenant_id)
            if existing_request:
                if existing_request['action']!=action or existing_request['inputDigest']!=input_hash:fail('PUBLISH_REQUEST_CONFLICT','原请求已用于其他发布操作',409)
                return self._answer(self._owned_attempt(db,actor,scope,existing_request['intentId']),replayed=True)
            if current['state']!='prepared' or current['revision']!=attempt['revision']:fail('PUBLISH_ALREADY_DISPATCHED','原发布已启动，请读取原结果',409)
            if self._snapshot(db,actor,scope,workspace,account,current['snapshot']['draftId'])!=current['snapshot']:fail('PUBLISH_SOURCE_CHANGED','内容或账号已变化，请重新准备',409)
            slot_key=digest([CONTRACT,scope.tenant_id,scope.platform,current['snapshot']['accountUid']])
            version_key=digest([CONTRACT,'version',scope.tenant_id,current['snapshot']['draftId'],current['snapshot']['draftVersion']])
            for key in (slot_key,version_key):
                old=self._get(db,SLOTS,key,scope.tenant_id)
                if old and old.get('state')!='released':fail('PUBLISH_SLOT_BUSY','当前账号或此版稿件已有发布正在处理或待核对，不能重复发布',409)
            current.update(state='dispatching',requestId=request_id,revision=current['revision']+1,updatedAt=now(),
                slotKey=slot_key,versionKey=version_key,message='已确认，正在单次发布；断线后仅核对原结果，不会重发。')
            for key in (slot_key,version_key):self._put(db,SLOTS,{'id':key,'tenant_id':scope.tenant_id,'intentId':current['id'],'state':'reserved'})
            self._put(db,ATTEMPTS,current)
            self._put(db,REQUESTS,{'id':self._request_key(actor,request_id),'tenant_id':scope.tenant_id,'action':action,'inputDigest':input_hash,'intentId':current['id']})
            attempt=current
        try:outcome=self.publish_port.dispatch(envelope,assets,reservation)
        except Exception:outcome={'state':'unknown','message':'发布回执未确认，原稿与请求已保留；请核对原结果。'}
        return self._finish(user,scope,attempt,outcome,authority_check)

    def _finish(self,user,scope,attempt,outcome,authority_check):
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            actor,_=self._authorized(db,user,scope,authority_check,True)
            current=self._owned_attempt(db,actor,scope,attempt['id'])
            if current.get('requestId')!=attempt.get('requestId'):fail('PUBLISH_RECORD_INVALID','原发布请求不一致',409)
            if current['state'] not in ('dispatching','unknown'):return self._answer(current,replayed=True)
            state='unknown';proof=None
            if isinstance(outcome,dict) and outcome.get('state')=='published':
                proof=outcome.get('receipt')
                if isinstance(proof,dict) and all(proof.get(k)==v for k,v in {
                    'intentId':current['id'],'requestId':current['requestId'],
                    'snapshotDigest':current['snapshot']['snapshotDigest'],'accountUid':current['snapshot']['accountUid']}.items()) \
                    and re.fullmatch(r'[0-9a-f]{24}',str(proof.get('postId',''))) and proof.get('verifiedNewPublication') is True:
                    state='published'
            elif isinstance(outcome,dict) and outcome.get('state')=='not_sent' and outcome.get('dispatchStarted') is False:
                state='not_sent'
            public_proof={k:deepcopy(proof[k]) for k in ('intentId','requestId','snapshotDigest','accountUid','postId','verifiedNewPublication','transportRequestId','requestBodyDigest','responseBodyDigest','observerNonce','wireRevision') if k in proof} if state=='published' else None
            current.update(state=state,revision=current['revision']+1,updatedAt=now(),
                outcome=public_proof,
                message='发布成功，已记录本次作品。' if state=='published' else '本次尚未发出，请重新核对后准备。' if state=='not_sent' else '发布结果尚未确认，已保留原请求并暂停本账号后续发布。')
            self._put(db,ATTEMPTS,current)
            if state in ('published','not_sent'):
                for key in (current['slotKey'],current['versionKey']):
                    slot=self._get(db,SLOTS,key,scope.tenant_id)
                    if slot and slot['intentId']==current['id']:
                        slot['state']='succeeded' if state=='published' and key==current['versionKey'] else 'released';self._put(db,SLOTS,slot)
            answer=self._answer(current)
        # AccountModeLeases rechecks this committed original intent in its own
        # transaction, including after recovery in a new Core/runtime.
        settle=getattr(self.publish_port,'settled',None)
        if state in ('published','not_sent') and callable(settle):
            try:settle({'contract':CONTRACT,'intentId':current['id'],'requestId':current['requestId'],
                'snapshot':deepcopy(current['snapshot']),'snapshotDigest':current['snapshot']['snapshotDigest']})
            except Exception:pass # Persisted proof lets the next acquire recheck.
        return answer
