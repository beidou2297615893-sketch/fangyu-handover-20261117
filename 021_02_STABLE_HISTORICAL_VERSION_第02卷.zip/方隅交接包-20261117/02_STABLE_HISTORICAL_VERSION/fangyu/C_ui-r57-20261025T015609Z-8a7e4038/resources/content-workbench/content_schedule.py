"""Fixed-version content queue over the original Store and publication command.

No sender, daemon, second database, credential storage or automatic unknown retry.
The caller supplies a live authenticated session; future approval is a distinct,
explicit action, and its dispatch grant exists only in the host's RAM.
"""
from copy import deepcopy
from datetime import datetime,timezone,timedelta
import importlib,re,uuid

def sibling(name):
    return importlib.import_module('.'+name,__package__) if __package__ else importlib.import_module(name)

publication=sibling('content_publishing')
ContentPublicationWorkbench=publication.ContentPublicationWorkbench
ContentScope,digest,fail,fields,ident,now=publication.ContentScope,publication.digest,publication.fail,publication.fields,publication.ident,publication.now
CONTRACT='fangyu-content-schedule-execution-v1'
ENTITY='content_schedule_execution_v1'
REQUESTS='content_schedule_execution_request_v1'
EVENTS='content_schedule_execution_event_v1'
ACTIONS=frozenset(('content_schedule_plan','content_schedule_read','content_schedule_arm',
    'content_schedule_control','content_schedule_tick','content_schedule_reconcile'))

def parsed(value):
    if not isinstance(value,str) or len(value)>64:fail('CONTENT_SCHEDULE_TIME_INVALID','请选择含时区的执行时刻')
    try:
        stamp=datetime.fromisoformat(value.replace('Z','+00:00'))
        if stamp.tzinfo is None or stamp.utcoffset() is None:raise ValueError()
        return stamp
    except ValueError:fail('CONTENT_SCHEDULE_TIME_INVALID','请选择含时区的执行时刻')

def checked_time(value,zone):
    stamp=parsed(value)
    if zone=='Asia/Shanghai':offset=timedelta(hours=8)
    elif zone=='UTC':offset=timedelta()
    else:
        match=re.fullmatch(r'UTC([+-])(0\d|1[0-4]):([0-5]\d)',zone if isinstance(zone,str) else '')
        if not match:fail('CONTENT_SCHEDULE_TIMEZONE_INVALID','请选择北京时间、UTC或明确的固定时区偏移')
        hours,minutes=int(match[2]),int(match[3])
        if hours==14 and minutes:fail('CONTENT_SCHEDULE_TIMEZONE_INVALID','时区偏移无效')
        offset=timedelta(hours=hours,minutes=minutes)*(1 if match[1]=='+' else -1)
    if stamp.utcoffset()!=offset:fail('CONTENT_SCHEDULE_TIMEZONE_INVALID','执行时间的偏移与所选时区不一致')
    return stamp.astimezone(timezone.utc).isoformat(timespec='seconds')

class ContentScheduleWorkbench(ContentPublicationWorkbench):
    schedule_grants=None
    schedule_session_key=None

    def _owned_schedule(self,db,user,scope,key):
        row=self._get(db,ENTITY,ident(key),scope.tenant_id)
        if not row or row.get('scope')!=scope.checked() or row.get('owner')!=user['username']:
            fail('CONTENT_SCHEDULE_NOT_FOUND','请重新选择当前员工、门店和账号的计划',404)
        return row

    @staticmethod
    def _base(scope):return {'accountId':scope.account_id,'platform':scope.platform}

    @staticmethod
    def _key(user,scope,request):return digest([CONTRACT,user['tenant_id'],user['username'],scope.checked(),request])

    def _has_grant(self,row):
        return (isinstance(self.schedule_grants,dict) and isinstance(self.schedule_session_key,str)
            and self.schedule_grants.get((row['id'],row.get('approvalDigest')))==self.schedule_session_key)

    def _revoke(self,row):
        if isinstance(self.schedule_grants,dict):
            for key in list(self.schedule_grants):
                if key[0]==row['id']:self.schedule_grants.pop(key,None)

    def _event(self,db,row,code,message):
        row['eventCount']=row.get('eventCount',0)+1
        event={'id':digest([CONTRACT,row['id'],row['eventCount']]),'tenant_id':row['tenant_id'],
            'scheduleId':row['id'],'scope':row['scope'],'owner':row['owner'],'sequence':row['eventCount'],
            'at':now(),'state':row['state'],'code':code,'message':message}
        self._put(db,EVENTS,event);row['lastEvent']={k:deepcopy(v) for k,v in event.items() if k not in ('recordDigest','tenant_id','scope','owner')}
        row['updatedAt']=now()

    def _public_schedule(self,db,user,scope,row):
        public={k:deepcopy(v) for k,v in row.items() if k not in ('recordDigest','tenant_id')}
        attempt=self._owned_attempt(db,user,scope,row['intentId']) if row.get('intentId') else None
        if attempt and attempt['state'] in ('dispatching','unknown','published','not_sent'):
            public['state']={'dispatching':'unknown','unknown':'unknown','published':'published','not_sent':'not_sent'}[attempt['state']]
            public['message']=attempt['message']
        public['publication']=self._publication_public(attempt)
        public['liveSessionEnabled']=self._has_grant(row)
        public['needsSessionConfirmation']=row['state'] in ('armed','claimed') and not self._has_grant(row)
        return public

    def _answer_schedule(self,db,user,scope,row=None,replayed=False):
        result={'schedule':self._public_schedule(db,user,scope,row) if row else None,'replayed':replayed,
            'scheduleContract':CONTRACT,'capabilities':{'automaticPublishing':False,
                'dueQueue':True,'fixedVersionApproval':True,'approvedDueExecution':True,'closedAppExecution':False,'requiresExplicitArm':True,
                'requiresLiveSession':True,'transportStatus':'original_publication_guarded',
                'note':'启用仅授权本次固定计划；实际发布仍须原账号、企业授权和可用发布协议。未知结果只核对原请求。'}}
        return result

    def _remember(self,db,user,scope,request,input_hash,action,row):
        self._put(db,REQUESTS,{'id':self._key(user,scope,request),'tenant_id':scope.tenant_id,
            'action':action,'inputDigest':input_hash,'scheduleId':row['id']})

    def _expire_prepared_approval(self,db,user,scope,row):
        # This retires stale consent only; it never supplies a runtime grant,
        # claims work, releases a publication slot or replaces an original key.
        if row['state']!='armed' or row.get('stopRequested'):return False
        attempt=self._owned_attempt(db,user,scope,row['intentId']) if row.get('intentId') else None
        if not attempt or attempt['state']!='prepared':return False
        if datetime.now(timezone.utc)<=parsed(row['approval']['expiresAt']):return False
        self._revoke(row)
        row.update(state='needs_review',revision=row['revision']+1,reasonCode='CONTENT_SCHEDULE_APPROVAL_EXPIRED',
            message='休眠或关闭期间已错过本次宽限，原审批失效；请另选时间并重新确认。')
        self._event(db,row,row['reasonCode'],row['message']);self._put(db,ENTITY,row)
        return True

    def execute(self,action,user,store_id,data,authority_check=None):
        if action not in ACTIONS:return super().execute(action,user,store_id,data,authority_check)
        common={'accountId','platform'}
        optional={
            'content_schedule_read':({'scheduleId','requestId'},set()),
            'content_schedule_plan':({'scheduleId','expectedScheduleRevision','draftId','draftVersion','plannedAt','timezone','graceMinutes','requestId'},
                {'draftId','draftVersion','plannedAt','timezone','graceMinutes','requestId'}),
            'content_schedule_arm':({'scheduleId','expectedScheduleRevision','snapshotDigest','accountUid','humanConfirmed','futureExecutionConfirmed','requestId'},
                {'scheduleId','expectedScheduleRevision','snapshotDigest','accountUid','humanConfirmed','futureExecutionConfirmed','requestId'}),
            'content_schedule_control':({'scheduleId','expectedScheduleRevision','operation','requestId','humanConfirmed'},
                {'scheduleId','expectedScheduleRevision','operation','requestId'}),
            'content_schedule_tick':({'scheduleId','requestId'},{'scheduleId','requestId'}),
            'content_schedule_reconcile':({'scheduleId','requestId'},{'scheduleId','requestId'})}
        allowed,required=optional[action];fields(data,common|allowed,common|required)
        scope=ContentScope(user.get('tenant_id','') if isinstance(user,dict) else '',ident(store_id),ident(data['accountId']),data['platform']);scope.checked()
        request=ident(data['requestId']) if 'requestId' in data else None
        input_hash=digest({'action':action,'scope':scope.checked(),'input':{k:v for k,v in data.items() if k!='requestId'}})
        if action=='content_schedule_arm':return self._arm(user,scope,data,request,input_hash,authority_check)
        if action in ('content_schedule_tick','content_schedule_reconcile'):
            return self._tick(user,scope,data,request,authority_check,reconcile=action=='content_schedule_reconcile')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            actor,account=self._authorized(db,user,scope,authority_check,action!='content_schedule_read')
            workspace=self._workspace(db,scope,actor)
            if action=='content_schedule_read':
                if data.get('scheduleId') and request:fail('CONTENT_INPUT_INVALID','请选择原计划或原请求编号')
                if request:
                    prior=self._get(db,REQUESTS,self._key(actor,scope,request),scope.tenant_id)
                    row=self._owned_schedule(db,actor,scope,prior['scheduleId']) if prior else None
                    if row:self._expire_prepared_approval(db,actor,scope,row)
                    answer=self._answer_schedule(db,actor,scope,row,True)
                    answer['requestFound']=bool(prior);return answer
                if data.get('scheduleId'):
                    row=self._owned_schedule(db,actor,scope,data['scheduleId']);self._expire_prepared_approval(db,actor,scope,row)
                    answer=self._answer_schedule(db,actor,scope,row)
                    answer['events']=[self._get(db,EVENTS,digest([CONTRACT,row['id'],i]),scope.tenant_id)
                        for i in range(max(1,row.get('eventCount',0)-49),row.get('eventCount',0)+1)]
                    return answer
                rows=[]
                for entry in db.execute('SELECT id FROM records WHERE entity=? AND tenant_id=?',(ENTITY,scope.tenant_id)):
                    row=self._get(db,ENTITY,entry['id'],scope.tenant_id)
                    if row.get('scope')==scope.checked() and row.get('owner')==actor['username']:
                        self._expire_prepared_approval(db,actor,scope,row)
                        rows.append(self._public_schedule(db,actor,scope,row))
                answer=self._answer_schedule(db,actor,scope);answer['schedules']=sorted(rows,key=lambda r:(r['plannedAt'],r['id']))
                return answer
            prior=self._get(db,REQUESTS,self._key(actor,scope,request),scope.tenant_id)
            if prior:
                if prior['action']!=action or prior['inputDigest']!=input_hash:fail('CONTENT_SCHEDULE_REQUEST_CONFLICT','原计划请求的内容已变化，请核对原结果',409)
                return self._answer_schedule(db,actor,scope,self._owned_schedule(db,actor,scope,prior['scheduleId']),True)
            if action=='content_schedule_plan':
                snapshot=self._snapshot(db,actor,scope,workspace,account,ident(data['draftId']))
                if type(data['draftVersion']) is not int or data['draftVersion']!=snapshot['draftVersion']:fail('PUBLISH_SOURCE_CHANGED','稿件版本已变化，请重新核对',409)
                grace=data['graceMinutes']
                if type(grace) is not int or not 1<=grace<=1440:fail('CONTENT_SCHEDULE_TIME_INVALID','到期宽限须为1至1440分钟')
                due=checked_time(data['plannedAt'],data['timezone'])
                if data.get('scheduleId'):
                    row=self._owned_schedule(db,actor,scope,data['scheduleId']);self._revision(row,data)
                    self._editable(db,actor,scope,row)
                    self._revoke(row);row['revision']+=1
                else:
                    if 'expectedScheduleRevision' in data:fail('CONTENT_INPUT_INVALID','新计划不接受旧版本号')
                    row={'id':uuid.uuid4().hex,'tenant_id':scope.tenant_id,'scope':scope.checked(),'owner':actor['username'],
                        'revision':1,'createdAt':now(),'eventCount':0}
                row.update(state='planned',draftId=snapshot['draftId'],draftVersion=snapshot['draftVersion'],snapshot=snapshot,
                    plannedAt=due,timezone=data['timezone'],localPlannedAt=data['plannedAt'],graceMinutes=grace,
                    approval=None,approvalDigest=None,intentId=None,publishRequestId=None,message='计划已保存，尚未启用到期执行。')
                self._event(db,row,'PLAN_SAVED',row['message'])
            else:
                row=self._owned_schedule(db,actor,scope,data['scheduleId']);self._revision(row,data)
                if data['operation'] not in ('pause','cancel','recover'):fail('CONTENT_INPUT_INVALID','请选择暂停、取消或核对原领取记录')
                attempt=self._owned_attempt(db,actor,scope,row['intentId']) if row.get('intentId') else None
                uncertain=attempt and attempt['state'] in ('dispatching','unknown') or row['state']=='claimed'
                if data['operation']=='recover':
                    if data.get('humanConfirmed') is not True or row['state']!='claimed' or not attempt or attempt['state']!='prepared':
                        fail('CONTENT_SCHEDULE_ORIGINAL_KEY_REQUIRED','仅本人核对尚未派发的原领取记录后可恢复；未知结果不能重新执行',409)
                    row.update(state='paused',stopRequested=True,message='已核对原发布尚未派发并暂停旧领取；请重新启用，仍保留原发布编号。')
                elif uncertain:
                    row['stopRequested']=True;row['message']='已停止后续执行；已领取或未知的原发布请求仍须核对，不会释放或换键重发。'
                elif row['state']=='published':fail('CONTENT_SCHEDULE_TERMINAL','已发布记录不能取消或再次执行',409)
                else:row.update(state='paused' if data['operation']=='pause' else 'cancelled',message='计划已暂停，请重新核对后启用。' if data['operation']=='pause' else '计划已取消，未派发的内容不会执行。')
                self._revoke(row);row['revision']+=1
                self._event(db,row,'CLAIM_RECOVERY_CONFIRMED' if data['operation']=='recover' else 'STOP_REQUESTED' if uncertain else row['state'].upper(),row['message'])
            self._authorized(db,user,scope,authority_check,True)
            self._put(db,ENTITY,row);self._remember(db,actor,scope,request,input_hash,action,row)
            return self._answer_schedule(db,actor,scope,row)

    @staticmethod
    def _revision(row,data):
        if type(data.get('expectedScheduleRevision')) is not int or data['expectedScheduleRevision']!=row['revision']:
            fail('CONTENT_SCHEDULE_REVISION_CONFLICT','计划已变化，请重新读取后确认',409)

    def _editable(self,db,actor,scope,row):
        attempt=self._owned_attempt(db,actor,scope,row['intentId']) if row.get('intentId') else None
        if row['state']=='claimed' or attempt and attempt['state'] in ('dispatching','unknown','published'):
            fail('CONTENT_SCHEDULE_ORIGINAL_KEY_REQUIRED','原发布已领取或结果待核对，只能查询原请求，不能换计划重发',409)

    def _arm(self,user,scope,data,request,input_hash,authority_check):
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,account=self._authorized(db,user,scope,authority_check,True)
            prior=self._get(db,REQUESTS,self._key(actor,scope,request),scope.tenant_id)
            if prior:
                if prior['action']!='content_schedule_arm' or prior['inputDigest']!=input_hash:fail('CONTENT_SCHEDULE_REQUEST_CONFLICT','原启用请求已变化',409)
                # A replay never grants a newly opened session permission.
                return self._answer_schedule(db,actor,scope,self._owned_schedule(db,actor,scope,prior['scheduleId']),True)
            row=self._owned_schedule(db,actor,scope,data['scheduleId']);self._revision(row,data);self._editable(db,actor,scope,row)
            if row['state']=='cancelled':fail('CONTENT_SCHEDULE_TERMINAL','已取消计划须先另存新的待核对计划',409)
            workspace=self._workspace(db,scope,actor)
            snapshot=self._snapshot(db,actor,scope,workspace,account,row['draftId'])
            if snapshot!=row['snapshot']:fail('CONTENT_SCHEDULE_APPROVAL_STALE','稿件、审核、图片或账号已变化，请先更新计划再确认',409)
            if data['humanConfirmed'] is not True or data['futureExecutionConfirmed'] is not True or data['snapshotDigest']!=snapshot['snapshotDigest'] or data['accountUid']!=snapshot['accountUid']:
                fail('CONTENT_SCHEDULE_CONFIRMATION_REQUIRED','请本人核对固定稿件、发布账号、执行时间和到期执行授权',409)
            expires=parsed(row['plannedAt'])+timedelta(minutes=row['graceMinutes'])
            if datetime.now(timezone.utc)>expires:fail('CONTENT_SCHEDULE_APPROVAL_EXPIRED','计划已超过宽限，请另选时间并重新核对',409)
            if not isinstance(self.schedule_grants,dict) or not isinstance(self.schedule_session_key,str):
                fail('CONTENT_SCHEDULE_SESSION_REQUIRED','请在当前已登录的软件会话内重新启用计划',409)
            version=row['revision'];work_revision=workspace['revision']
            reusable=self._owned_attempt(db,actor,scope,row['intentId']) if row.get('intentId') else None
            if reusable and (reusable['state']!='prepared' or reusable['snapshot']!=snapshot or not row.get('publishRequestId')):reusable=None
        prepared={'publication':self._publication_public(reusable)} if reusable else super().execute('content_publish_prepare',user,scope.store_id,{**self._base(scope),
            'draftId':row['draftId'],'draftVersion':row['draftVersion'],'expectedRevision':work_revision,
            'requestId':'cs-prepare-'+digest([row['id'],request])},authority_check)
        intent=prepared['publication']
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,account=self._authorized(db,user,scope,authority_check,True)
            current=self._owned_schedule(db,actor,scope,row['id'])
            if current['revision']!=version:fail('CONTENT_SCHEDULE_REVISION_CONFLICT','准备期间计划已变化，未启用；请重新读取',409)
            workspace=self._workspace(db,scope,actor)
            if self._snapshot(db,actor,scope,workspace,account,current['draftId'])!=snapshot or intent['snapshot']!=snapshot:
                fail('CONTENT_SCHEDULE_APPROVAL_STALE','准备期间原内容已变化，未启用',409)
            approval={'contract':CONTRACT,'owner':actor['username'],'scope':scope.checked(),
                'scheduleId':row['id'],'scheduleRevision':version,'snapshotDigest':snapshot['snapshotDigest'],
                'accountUid':snapshot['accountUid'],'plannedAt':row['plannedAt'],'timezone':row['timezone'],
                'expiresAt':expires.isoformat(timespec='seconds'),'humanConfirmed':True,'futureExecutionConfirmed':True,'confirmedAt':now()}
            self._revoke(current)
            current.update(state='armed',revision=version+1,approval=approval,approvalDigest=digest(approval),
                intentId=intent['id'],publishRequestId=row['publishRequestId'] if reusable else 'cs-publish-'+uuid.uuid4().hex,stopRequested=False,
                message='本次固定计划已启用；仅在当前登录会话及有效宽限内领取，实际发布受原授权与协议保护。')
            self._event(db,current,'ARMED',current['message']);self._put(db,ENTITY,current)
            self._remember(db,actor,scope,request,input_hash,'content_schedule_arm',current)
            self.schedule_grants[(current['id'],current['approvalDigest'])]=self.schedule_session_key
            return self._answer_schedule(db,actor,scope,current)

    def _tick(self,user,scope,data,request,authority_check,reconcile=False):
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,account=self._authorized(db,user,scope,authority_check,True)
            row=self._owned_schedule(db,actor,scope,data['scheduleId'])
            attempt=self._owned_attempt(db,actor,scope,row['intentId']) if row.get('intentId') else None
            if reconcile:
                if not attempt or attempt['state'] not in ('dispatching','unknown'):return self._answer_schedule(db,actor,scope,row,True)
                if request!=row['publishRequestId']:fail('PUBLISH_ORIGINAL_KEY_REQUIRED','只能核对该计划的原发布请求',409)
            else:
                if self._expire_prepared_approval(db,actor,scope,row):return self._answer_schedule(db,actor,scope,row)
                if row['state']!='armed' or not self._has_grant(row) or row.get('stopRequested'):
                    return self._answer_schedule(db,actor,scope,row,True)
                current=datetime.now(timezone.utc)
                if current<parsed(row['plannedAt']):return self._answer_schedule(db,actor,scope,row,True)
                stale=None
                if current>parsed(row['approval']['expiresAt']):stale=('CONTENT_SCHEDULE_APPROVAL_EXPIRED','休眠或关闭期间已错过本次宽限，原审批失效；请另选时间并重新确认。')
                elif digest(row['approval'])!=row['approvalDigest'] or not attempt or attempt['state']!='prepared':
                    stale=('CONTENT_SCHEDULE_APPROVAL_STALE','原发布状态已变化，请核对原记录，不能重新派发。')
                else:
                    workspace=self._workspace(db,scope,actor)
                    try:fresh=self._snapshot(db,actor,scope,workspace,account,row['draftId'])
                    except Exception as error:
                        if not isinstance(getattr(error,'code',None),str):raise
                        stale=(error.code,str(error))
                    else:
                        if fresh!=row['snapshot'] or fresh!=attempt['snapshot']:stale=('CONTENT_SCHEDULE_APPROVAL_STALE','稿件、审核、图片或账号已变化，原到期审批失效，请更新计划后确认。')
                if stale:
                    self._revoke(row);row.update(state='needs_review',revision=row['revision']+1,reasonCode=stale[0],message=stale[1])
                    self._event(db,row,*stale);self._put(db,ENTITY,row);return self._answer_schedule(db,actor,scope,row)
                row.update(state='claimed',revision=row['revision']+1,claimedAt=now(),message='已领取本次到期项目，正在交给原发布流程；不会另建请求重试。')
                self._event(db,row,'CLAIMED',row['message']);self._put(db,ENTITY,row)
        error=None
        def dispatch_authority(db,actor,requested_scope,save):
            allowed=authority_check is not None and authority_check(db,actor,requested_scope,save) is True
            if not allowed:return False
            current=self._owned_schedule(db,actor,scope,row['id'])
            original=self._owned_attempt(db,actor,scope,row['intentId'])
            # Cancellation/expiry is checked again after the original external
            # preflight, while the original Store reservation is atomic. Once
            # dispatch began, allow its proof to settle even if pause was asked.
            if not reconcile and original['state']=='prepared':
                if current.get('stopRequested') or not self._has_grant(current):
                    fail('CONTENT_SCHEDULE_STOPPED','本次计划已暂停或当前会话授权已撤销，未再次派发',409)
                if current.get('approvalDigest')!=row.get('approvalDigest') or datetime.now(timezone.utc)>parsed(current['approval']['expiresAt']):
                    fail('CONTENT_SCHEDULE_APPROVAL_EXPIRED','原到期授权已变化或超期，请重新核对',409)
            return True
        try:
            call='content_publish_reconcile' if reconcile else 'content_publish_confirm'
            payload={**self._base(scope),'intentId':attempt['id'],'expectedAttemptRevision':attempt['revision'],
                'requestId':row['publishRequestId']}
            if not reconcile:payload.update(snapshotDigest=row['approval']['snapshotDigest'],accountUid=row['approval']['accountUid'],humanConfirmed=row['approval']['humanConfirmed'])
            super().execute(call,user,scope.store_id,payload,dispatch_authority)
        except Exception as caught:
            if not isinstance(getattr(caught,'code',None),str):raise
            error=caught
        finally:
            # A process loss leaves claimed persisted; it is never auto re-armed.
            if isinstance(self.schedule_grants,dict):self.schedule_grants.pop((row['id'],row.get('approvalDigest')),None)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,_=self._authorized(db,user,scope,authority_check,True)
            current=self._owned_schedule(db,actor,scope,row['id']);attempt=self._owned_attempt(db,actor,scope,row['intentId'])
            if current.get('approvalDigest')!=row.get('approvalDigest') or current.get('intentId')!=row.get('intentId'):
                return self._answer_schedule(db,actor,scope,current,True)
            state=attempt['state']
            current.update(state={'dispatching':'unknown','unknown':'unknown','published':'published','not_sent':'not_sent'}.get(state,'blocked'),
                revision=current['revision']+1,reasonCode=getattr(error,'code',None),
                message=attempt['message'] if state!='prepared' else str(error) if error else '原请求尚未派发，请本人核对后重新启用。')
            self._event(db,current,current.get('reasonCode') or current['state'].upper(),current['message'])
            self._put(db,ENTITY,current);return self._answer_schedule(db,actor,scope,current)
