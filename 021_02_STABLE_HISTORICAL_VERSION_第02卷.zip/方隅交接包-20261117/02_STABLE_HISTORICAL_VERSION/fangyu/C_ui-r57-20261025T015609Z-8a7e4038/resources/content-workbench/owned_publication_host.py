"""A dedicated write port on an EXISTING original owned WebView2 object.

No window/profile creation, port discovery, cookie copy or network API exists.
The real host supplies its existing window, identity observer and native owner.
Only fixed CDP operations and one exact intercepted create request are allowed.
"""
from copy import deepcopy
from pathlib import Path
import base64,hashlib,json,math,re,threading,time,uuid
from urllib.parse import urlsplit
try:
    from .publication_protocol import validate_policy
except ImportError:
    from publication_protocol import validate_policy

class OwnedPublicationError(RuntimeError):
    code='PUBLISH_OWNED_HOST_UNAVAILABLE';status=503

def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def strict_json(raw):
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('Duplicate key')
            result[k]=v
        return result
    if not isinstance(raw,str) or len(raw)>4_000_000:raise ValueError('Event size')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))

class OwnedPublicationCDP:
    """Native _NativeOwner/CoreWebView2 adapter, injectable only for offline QA."""
    COMMANDS=frozenset(('Page.getFrameTree','Network.enable','Network.getResponseBody','Network.setBlockedURLs','Fetch.enable','Fetch.disable',
        'Fetch.continueRequest','Fetch.failRequest','Runtime.evaluate','DOM.getDocument','DOM.querySelector','DOM.setFileInputFiles','Input.dispatchMouseEvent'))
    def __init__(self,window,*,expected_profile,observer,authority,current_envelope,read_urls=(),upload_rules=(),native=None):
        self.window=window;self.expected_profile=Path(expected_profile).resolve();self.observer=observer;self.authority=authority
        self.envelope=current_envelope;self.read_urls=frozenset(read_urls);self.upload_rules=tuple(deepcopy(upload_rules));self.native=native
        self.lock=threading.RLock();self.active=False;self.closed=False;self.refs=[];self.pending={};self.network_before_fetch={}
        self.owned_id=uuid.uuid4().hex;self.frame_id='';self.loader_id='';self.native_core=None
        self.expected_uploads=[];self.upload_requests={};self.upload_receipts=[]
        self.fetch_ids=set();self.cleanup_done=False;self.network_fenced=False;self.fetch_disabled=False

    def _core(self):
        _,core=self.native.core()
        if core is None or self.native_core is not None and not self.native.same_core(core,self.native_core):raise OwnedPublicationError('Original native core changed')
        source=urlsplit(str(core.Source))
        if source.scheme!='https' or source.netloc!='creator.xiaohongshu.com':raise OwnedPublicationError('Original creator document required')
        if Path(str(core.Environment.UserDataFolder)).resolve()!=self.expected_profile:raise OwnedPublicationError('Original account profile mismatch')
        return core

    def _task(self,method,data):
        if method not in self.COMMANDS:raise OwnedPublicationError('CDP operation forbidden')
        return self.native.invoke(lambda:self._core().CallDevToolsProtocolMethodAsync(method,json.dumps(data,separators=(',',':'),allow_nan=False)))

    @staticmethod
    def _result(task):
        if not task.Wait(10000) or task.IsCanceled or task.IsFaulted:raise OwnedPublicationError('Owned native command did not finish')
        return strict_json(str(task.Result))

    def call(self,method,data):
        if self.closed:raise OwnedPublicationError('Original owned host closed')
        return self._result(self._task(method,data))

    def attach(self):
        if self.active or self.closed:raise OwnedPublicationError('Invalid publication host state')
        if self.native is None:
            from owned_natural_reader import _NativeOwner
            self.native=_NativeOwner(self.window)
        self.native_core=self.native.invoke(self._core)
        tree=self.call('Page.getFrameTree',{})['frameTree']['frame'];self.frame_id=tree['id'];self.loader_id=tree['loaderId']
        if not self.frame_id or not self.loader_id:raise OwnedPublicationError('Owned document identity missing')
        def subscribe(name,handler):
            receiver=self.native_core.GetDevToolsProtocolEventReceiver(name)
            receiver.DevToolsProtocolEventReceived+=handler;self.refs.append((receiver,handler))
        def event(handler):
            def receive(sender,args):
                try:
                    # The receiver belongs to this fixed core. Child DevTools
                    # targets/session IDs may never impersonate its main page.
                    if str(getattr(args,'SessionId','')):return
                    value=strict_json(str(args.ParameterObjectAsJson))
                    with self.lock:
                        if self.active and not self.closed:handler(value)
                except Exception:self.closed=True;self.active=False
            return receive
        self.native.invoke(lambda:[subscribe(name,event(fn)) for name,fn in [
            ('Fetch.requestPaused',self._paused),('Network.requestWillBeSent',self._request),
            ('Network.responseReceived',self._response),('Network.loadingFinished',self._finished)]])
        self.call('Network.enable',{'maxResourceBufferSize':4_000_000,'maxTotalBufferSize':8_000_000,'maxPostDataSize':2_000_000})
        # Intercept before transmission. Exact read/upload rules are separately
        # pinned; this is never an allow-all network policy.
        self.active=True
        self.call('Fetch.enable',{'patterns':[{'urlPattern':'*','requestStage':'Request'}]})
        return self

    def expect_upload(self,sha256):
        if not re.fullmatch(r'[a-f0-9]{64}',sha256):raise OwnedPublicationError('Invalid approved upload hash')
        self.expected_uploads.append(sha256)

    def _paused(self,value):
        request=value.get('request') or {};rid=value.get('requestId');network=value.get('networkId')
        if not isinstance(rid,str) or not rid:return
        self.fetch_ids.add(rid)
        allowed=False
        if value.get('frameId')==self.frame_id:
            url=request.get('url');method=request.get('method');body=request.get('postData','')
            if url==self.observer.codec.endpoint:
                envelope=self.envelope()
                allowed=(self.authority.current_for_write(envelope) is True and self.observer.permit_final_request(
                    session_id=self.owned_id,network_request_id=network,url=url,method=method,post_data=body))
            elif method in ('GET','HEAD') and url in self.read_urls:allowed=True
            else:
                # Uploads require a host-pinned exact method, URL and validator;
                # absent real upload mapping means no upload request can pass.
                for rule in self.upload_rules:
                    if (method==rule.get('method') and url==rule.get('url') and callable(rule.get('validator'))
                            and callable(rule.get('decoder')) and self.expected_uploads and isinstance(network,str) and network
                            and network not in self.upload_requests and self.authority.current_for_upload(self.envelope()) is True
                            and rule['validator'](deepcopy(request),self.expected_uploads[0]) is True):
                        self.upload_requests[network]={'sha256':self.expected_uploads.pop(0),'url':url,'decoder':rule['decoder'],'responseOK':False}
                        allowed=True;break
        if allowed:
            if network in self.network_before_fetch:self._deliver_request(self.network_before_fetch.pop(network))
            self._task('Fetch.continueRequest',{'requestId':rid})
        else:self._task('Fetch.failRequest',{'requestId':rid,'errorReason':'BlockedByClient'})

    def _deliver_request(self,value):
        request=value['request']
        self.observer.request(session_id=self.owned_id,request_id=value['requestId'],url=request['url'],method=request['method'],post_data=request.get('postData',''),timestamp=value['_receivedAt'])

    def _request(self,value):
        if (value.get('frameId')!=self.frame_id or value.get('loaderId')!=self.loader_id or value.get('redirectResponse')
                or not isinstance(value.get('requestId'),str) or not isinstance(value.get('request'),dict)):return
        if value['request'].get('url')!=self.observer.codec.endpoint:return
        value={**value,'_receivedAt':time.monotonic()}
        if value['requestId'] in self.observer.permitted:self._deliver_request(value)
        elif len(self.network_before_fetch)<8:self.network_before_fetch[value['requestId']]=value

    def _response(self,value):
        response=value.get('response') or {}
        status=response.get('status')
        status=int(status) if type(status) in (int,float) and math.isfinite(status) and status==int(status) else None
        upload=self.upload_requests.get(value.get('requestId'))
        if upload and response.get('url')==upload['url'] and type(status) is int and 200<=status<300:upload['responseOK']=True
        self.observer.response_received(session_id=self.owned_id,request_id=value.get('requestId'),url=response.get('url'),status=status)

    def _finished(self,value):
        rid=value.get('requestId')
        if rid in self.observer.pending and self.observer.pending[rid].get('responseOK'):
            self.pending[rid]=(self._task('Network.getResponseBody',{'requestId':rid}),'create')
        elif rid in self.upload_requests and self.upload_requests[rid]['responseOK']:
            self.pending[rid]=(self._task('Network.getResponseBody',{'requestId':rid}),'upload')

    def poll(self):
        with self.lock:
            for rid,(task,kind) in list(self.pending.items()):
                if not task.IsCompleted:continue
                del self.pending[rid]
                result=self._result(task);body=result['body']
                if result.get('base64Encoded') is True:body=base64.b64decode(body,validate=True).decode('utf-8')
                if kind=='create':self.observer.response_body(session_id=self.owned_id,request_id=rid,raw=body)
                else:
                    row=self.upload_requests[rid];decoded=row['decoder'](body)
                    if (not isinstance(decoded,dict) or set(decoded)!={'success','token','sha256'} or decoded['success'] is not True
                            or decoded['sha256']!=row['sha256']):raise OwnedPublicationError('Original upload response/hash unverified')
                    token=decoded['token']
                    if not isinstance(token,str) or not token or len(token)>500:raise OwnedPublicationError('Original upload response token unverified')
                    if not any(r['networkRequestId']==rid for r in self.upload_receipts):self.upload_receipts.append({'networkRequestId':rid,'sha256':row['sha256'],'token':token,'responseBodyDigest':hashlib.sha256(body.encode()).hexdigest()})

    def evaluate(self,source):
        result=self.call('Runtime.evaluate',{'expression':source,'returnByValue':True,'awaitPromise':False})
        if result.get('exceptionDetails'):raise OwnedPublicationError('Owned editor script failed')
        return result.get('result',{}).get('value')

    def close(self):
        # Do not destroy or relaunch the original window/profile.
        if self.cleanup_done:return
        self.active=False;self.closed=True
        try:
            # Fence this original core before removing the Fetch guard. Disabling
            # interception alone could resume a queued web-page retry. This fixed
            # fence is deliberately never removed by this publication module.
            if not self.network_fenced:
                self._result(self._task('Network.setBlockedURLs',{'urls':['*']}));self.network_fenced=True
            if not self.fetch_disabled:
                for rid in tuple(self.fetch_ids):
                    try:self._result(self._task('Fetch.failRequest',{'requestId':rid,'errorReason':'BlockedByClient'}))
                    except Exception:pass # An already completed request cannot resume.
                self._result(self._task('Fetch.disable',{}));self.fetch_disabled=True
        finally:
            failed=[]
            def unsubscribe():
                for receiver,handler in self.refs:
                    try:receiver.DevToolsProtocolEventReceived-=handler
                    except Exception:failed.append((receiver,handler))
            self.native.invoke(unsubscribe);self.refs=failed
            if self.fetch_disabled:self.fetch_ids.clear()
            self.cleanup_done=self.network_fenced and self.fetch_disabled and not self.refs

class ExistingOwnedSessionRegistry:
    """Trusted host registration only; lookup never opens a browser."""
    def __init__(self,core,current_user,executor_vault,session_factory):
        self.core,self.user,self.vault,self.factory=core,current_user,executor_vault,session_factory;self.sessions={}
    def register(self,window,account_id,*,identity_observation,native=None):
        user=self.user();account=self.core.store.get('accounts',account_id) or {};vault=self.vault() or {}
        if (account.get('tenant_id')!=user.get('tenant_id') or account.get('cloud_owner')!=user.get('username') or account.get('platform')!='xiaohongshu'
                or not account.get('platform_uid') or vault.get('state')!='bound' or (vault.get('device') or {}).get('owner')!=user.get('username')):
            raise OwnedPublicationError('Original account/executor binding required')
        profile=Path(self.core.store.directory)/'accounts'/user['tenant_id']/account_id/'xhs-browser-profile'
        if not profile.is_dir() or any(p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&0x400 for p in (profile,*profile.parents)):
            raise OwnedPublicationError('Existing account profile required')
        if not callable(identity_observation):raise OwnedPublicationError('Original passive UID observation required')
        binding=dict(existingOwnedSession=True,accountId=account_id,accountUid=account['platform_uid'],owner=user['username'],platform='xiaohongshu',
            deviceId=vault['device']['id'],sessionRevision=digest(account),profileIdentityDigest=digest(str(profile.resolve())),runtimeId=self.core.continuous.runtime_id,
            creatorOrigin='https://creator.xiaohongshu.com')
        session=self.factory(window,profile,binding,identity_observation,native)
        self.sessions[account_id]=session;return session
    def __call__(self,envelope):
        key=envelope['snapshot']['scope']['account_id'];session=self.sessions.get(key)
        if session is None:raise OwnedPublicationError('No live original owned publishing window; login windows are not reused')
        session.bind_envelope(envelope);return session

class OriginalOwnedPublicationSession:
    """Fixed DOM/CDP methods on one original existing account window.

    wire_policy is a host-pinned reviewed protocol object, never browser JSON.
    With no verified create/upload/preview mapping this implementation refuses
    to attach. It does not invent a real XHS endpoint or mark a stub as ready.
    """
    def __init__(self,window,profile,binding,identity_observation,native,*,core,authority,port_module,wire_policy,stage_dir,receipt_wait_seconds=15):
        self.window,self.profile,self.expected,self.identity,self.native=window,Path(profile),deepcopy(binding),identity_observation,native
        self.core,self.authority,self.port=core,authority,port_module;self.policy=deepcopy(wire_policy);self.stage_dir=Path(stage_dir).resolve()
        self.current=None;self.transport=None;self.uploaded=[];self.clicked=set()
        if type(receipt_wait_seconds) not in (int,float) or not 0<receipt_wait_seconds<=30:raise ValueError('Bounded receipt wait required')
        self.receipt_wait_seconds=receipt_wait_seconds
        self._validate_policy()
        cp=wire_policy['create'];self.observer=port_module.PublicationObserver(port_module.StrictPublishJSON(
            endpoint=cp['endpoint'],request_paths=cp['requestPaths'],response_paths=cp['responsePaths'],success_value=cp['successValue'],revision=wire_policy['revision']),core.store)

    def _validate_policy(self):
        p=self.policy
        if (not isinstance(p,dict) or p.get('enabled') is not True or p.get('realProtocolVerified') is not True
                or not isinstance(p.get('revision'),str) or p['revision'].startswith('SYNTHETIC-ONLY')
                or not re.fullmatch(r'[a-f0-9]{64}',str(p.get('digest',''))) or not isinstance(p.get('create'),dict)
                or not isinstance(p.get('uploadRules'),tuple) or not p['uploadRules']
                or not re.fullmatch(r'data-[a-z0-9-]{1,50}',str(p.get('previewTokenAttribute','')))):
            raise OwnedPublicationError('Real publication/upload/preview protocol not reviewed; original session not attached')
        try:validate_policy(p)
        except (ValueError,TypeError):raise OwnedPublicationError('Approved actual publication protocol digest changed') from None

    def bind_envelope(self,envelope):
        s=envelope['snapshot'];scope=s['scope']
        if any(self.expected[k]!=v for k,v in {'accountId':scope['account_id'],'accountUid':s['accountUid'],'owner':s['owner']}.items()):raise OwnedPublicationError('Publication session scope mismatch')
        if self.current and self.current!=envelope and self.observer.armed is not None:raise OwnedPublicationError('Original publication is still awaiting result')
        self.current=deepcopy(envelope);self.binding()
        if self.transport is None:
            self.transport=OwnedPublicationCDP(self.window,expected_profile=self.profile,observer=self.observer,authority=self.authority,
                current_envelope=lambda:deepcopy(self.current),read_urls=self.policy.get('readUrls',()),upload_rules=self.policy['uploadRules'],native=self.native).attach()

    def binding(self):
        self._validate_policy()
        account=self.core.store.get('accounts',self.expected['accountId']) or {};proof=self.identity()
        if digest(account)!=self.expected['sessionRevision']:raise OwnedPublicationError('Original account revision changed')
        if (not isinstance(proof,dict) or proof.get('live') is not True or proof.get('verified') is not True
                or proof.get('uid')!=self.expected['accountUid'] or proof.get('windowUid')!=self.window.uid
                or proof.get('profileIdentityDigest')!=self.expected['profileIdentityDigest']
                or proof.get('accountRevision')!=self.expected['sessionRevision']):
            raise OwnedPublicationError('Original passive UID observation does not bind this live window')
        if self.transport:
            self.transport.native.invoke(self.transport._core)
            if self.transport.closed or not self.transport.active:raise OwnedPublicationError('Original owned host not active')
        return {**self.expected,'ownedSessionId':self.transport.owned_id if self.transport else 'pending-original-owned-session'}

    def evaluate(self,source):return self.transport.evaluate(source)
    def publication_guard_installed(self,observer):return bool(self.transport and self.transport.active and not self.transport.closed and observer is self.observer)
    def select_image_mode(self,selector,text):
        script='''/* PUB_EXACT_IMAGE_MODE */ (()=>{ const nodes=[...document.querySelectorAll(%s)].filter(n=>n.offsetParent!==null && n.textContent.trim()===%s);if(nodes.length!==1)return false;nodes[0].click();return true;})()'''%(json.dumps(selector),json.dumps(text))
        if self.evaluate(script) is not True:raise OwnedPublicationError('Unique original image tab not found')

    def set_file_input_files(self,selectors,paths):
        if not isinstance(paths,list) or len(paths)!=1:raise OwnedPublicationError('One approved original file per input operation')
        p=Path(paths[0]);index=len(self.uploaded)
        if (not p.is_absolute() or not p.resolve().is_relative_to(self.stage_dir) or p.is_symlink() or not p.is_file()
                or any(x.is_symlink() or getattr(x.lstat(),'st_file_attributes',0)&0x400 for x in (p,*p.parents))):raise OwnedPublicationError('Owned temporary material path required')
        raw=p.read_bytes();sha256=hashlib.sha256(raw).hexdigest()
        if index>=len(self.current['snapshot']['assets']) or sha256!=self.current['snapshot']['assets'][index]['sha256'] or not raw.startswith(b'\x89PNG\r\n\x1a\n'):
            raise OwnedPublicationError('Approved original material order/hash changed')
        chosen=None
        for selector in selectors:
            count=self.evaluate('/* PUB_FILE_INPUT_COUNT */ [...document.querySelectorAll('+json.dumps(selector)+')].filter(n=>n.tagName==="INPUT" && n.type==="file" && !n.disabled).length')
            if count==1:chosen=selector;break
        if chosen is None:raise OwnedPublicationError('Unique original upload control not found')
        document=self.transport.call('DOM.getDocument',{})['root']['nodeId']
        node=self.transport.call('DOM.querySelector',{'nodeId':document,'selector':chosen}).get('nodeId')
        if type(node) is not int or node<1:raise OwnedPublicationError('Original upload node missing')
        self.transport.expect_upload(sha256)
        self.transport.call('DOM.setFileInputFiles',{'nodeId':node,'files':[str(p)]});self.uploaded.append(sha256)

    def wait_uploaded(self,count):
        end=time.monotonic()+30
        while time.monotonic()<end:
            self.transport.poll()
            if len(self.transport.upload_receipts)>=count:
                actual=[r['sha256'] for r in self.transport.upload_receipts[:count]]
                if actual!=self.uploaded[:count]:raise OwnedPublicationError('Upload network evidence order changed')
                return
            time.sleep(.05)
        raise OwnedPublicationError('Original upload response not verified')

    def uploaded_tokens(self):return [r['token'] for r in self.transport.upload_receipts]

    def form_snapshot(self):
        attr=self.policy['previewTokenAttribute']
        script='''/* PUB_FORM_SNAPSHOT */ (()=>{const title=document.querySelector('div.d-input input');const editor=document.querySelector('div.tiptap.ProseMirror, div.ProseMirror[contenteditable="true"], div.ql-editor');const pictures=[...document.querySelectorAll('.img-preview-area .pr')];if(!title||!editor)return null;return {title:title.value,body:[...editor.children].map(n=>n.textContent).join('\\n'),assetTokens:pictures.map(n=>n.getAttribute(%s))};})()'''%json.dumps(attr)
        value=self.evaluate(script)
        if not isinstance(value,dict) or set(value)!={'title','body','assetTokens'} or value['assetTokens']!=self.uploaded_tokens():raise OwnedPublicationError('Original form text or ordered media mapping unverified')
        return value

    def form_is_empty(self):
        return self.evaluate('''/* PUB_FORM_EMPTY */ (()=>{const title=document.querySelector('div.d-input input');const editor=document.querySelector('div.tiptap.ProseMirror, div.ProseMirror[contenteditable="true"], div.ql-editor');return (!title||!title.value) && (!editor||!editor.textContent.trim()) && document.querySelectorAll('.img-preview-area .pr').length===0;})()''') is True

    def publish_button_rect(self,selector):
        return self.evaluate('''/* PUB_BUTTON_RECT */ (()=>{const n=[...document.querySelectorAll(%s)].filter(x=>x.offsetParent!==null);if(n.length!==1)return null;const e=n[0],r=e.getBoundingClientRect();return {enabled:!e.disabled&&!e.classList.contains('disabled')&&e.getAttribute('aria-disabled')!=='true',x:r.x,y:r.y,width:r.width,height:r.height};})()'''%json.dumps(selector))

    def click_once(self,x,y):
        key=self.current['requestId']
        if key in self.clicked or not all(type(v) in (int,float) and math.isfinite(v) for v in (x,y)) or not self.authority.current_for_write(self.current):raise OwnedPublicationError('Original confirmed click not authorized')
        self.clicked.add(key)
        for kind in ('mousePressed','mouseReleased'):self.transport.call('Input.dispatchMouseEvent',{'type':kind,'x':x,'y':y,'button':'left','clickCount':1})

    def wait_publication_receipt(self,key):
        end=time.monotonic()+self.receipt_wait_seconds
        while time.monotonic()<end:
            self.transport.poll()
            if self.observer.status(self.current).get('state')=='published':return
            time.sleep(.05)
