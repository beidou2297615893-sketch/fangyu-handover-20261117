"""Explicit article snapshots and original receipts in the SAME content workspace."""
from copy import deepcopy
from datetime import datetime,timezone
import importlib,re

def sibling(n):return importlib.import_module('.'+n,__package__)
base=sibling('content_workbench');digest,fail,now=base.digest,base.fail,base.now
search=sibling('public_research_workbench')

def articles(state):
 rows=state.setdefault('publicArticles',[])
 if not isinstance(rows,list) or len(rows)>20:fail('PUBLIC_ARTICLE_RECORD_INVALID','公开正文记录需要核对',409)
 for item in rows:
  if not isinstance(item,dict) or item.get('digest')!=digest({k:v for k,v in item.items() if k!='digest'}):fail('PUBLIC_ARTICLE_RECORD_INVALID','原正文版本需要核对',409)
 return rows
def _id(value):return isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value)
def _seal(item):item.pop('digest',None);item['digest']=digest(item)
def _result(item):return {'publicArticle':deepcopy(item),'modelCalled':False,'imagesFetched':0,'newKnowledgeDocuments':0}
def _selected(wb,db,scope,state,data):
 if not _id(data['searchId']) or not _id(data['searchDigest']):fail('PUBLIC_ARTICLE_SOURCE','请选择当前账号原检索中的一条来源',400)
 item=next((r for r in search.searches(state) if r['id']==data['searchId']),None)
 if item is None or item['state']!='received' or item['digest']!=data['searchDigest']:fail('PUBLIC_SEARCH_SOURCE_CHANGED','原检索来源已变化或待核对',409)
 ref=data['resultRef']
 if not isinstance(ref,dict) or set(ref)!={'id','digest'} or not isinstance(ref['id'],str) or not re.fullmatch('ref-[0-9a-f]{64}',ref['id']) or not _id(ref['digest']):fail('PUBLIC_ARTICLE_SOURCE','请只选择一条原来源，不上传网址或正文',400)
 chosen=next((r for r in item['results'] if r['id']==ref['id'] and r['digest']==ref['digest']),None)
 if chosen is None:fail('PUBLIC_SEARCH_SOURCE_CHANGED','所选来源与原检索版本不符',409)
 row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('accounts',scope.account_id,scope.tenant_id)).fetchone()
 if row is None or search.account_binding(__import__('json').loads(row['body']))!=item['accountBinding']:fail('PUBLIC_SEARCH_SOURCE_CHANGED','原来源账号身份已变化',409)
 return item,chosen

def preview(wb,user,scope,data,request,input_hash,authority):
 provider=sibling('public_article_provider')
 if data['confirmedPublicRead'] is not True:fail('PUBLIC_ARTICLE_CONFIRM','请本人明确确认只读取所选公开正文一次',400)
 with wb.store.connect() as db:
  db.execute('BEGIN IMMEDIATE');actor,account=wb._authorized(db,user,scope,authority,True);row=wb._workspace(db,scope,actor);state=wb._state(row)
  old=wb._prior(row,'content_public_article_preview',request,input_hash)
  if old:return search.replay(wb,row,actor,account,old)
  if row['revision']!=data['expectedRevision']:fail('CONTENT_REVISION_CONFLICT','内容已更新，请重新核对后读取正文',409)
  origin,chosen=_selected(wb,db,scope,state,data);url=provider.checked_url(chosen['url']);items=articles(state)
  if len(items)>=20:
   # Match the original public-search receipt archive: bound active previews,
   # never the lifetime number of successful reads. Unknowns are not evicted.
   expired=next((r for r in items if r['state'] in ('received','cancelled') and (datetime.now(timezone.utc)-datetime.fromisoformat(r['createdAt'])).total_seconds()>=600),None)
   if expired is None:fail('PUBLIC_ARTICLE_LIMIT','近期正文预览较多，请先使用已有资料或稍后再读；原编号不删除',409)
   items.remove(expired)
  same=[r for r in items if r['requestedUrl']==url]
  if any(r['state']=='unknown' for r in same):fail('PUBLIC_ARTICLE_UNKNOWN','这个来源的原读取结果仍待核对，请保留原编号，不换号重读',409)
  if sum((datetime.now(timezone.utc)-datetime.fromisoformat(r['createdAt'])).total_seconds()<600 for r in same)>=3:fail('PUBLIC_ARTICLE_COOLDOWN','此来源十分钟内已显式读取三次，请使用原记录',409)
  frozen=search.account_binding(account);article={'id':digest(['public-article',row['id'],request]),'requestId':request,'createdAt':now(),'state':'unknown','code':'PUBLIC_ARTICLE_RESULT_UNKNOWN','requestedUrl':url,'source':{'searchId':origin['id'],'searchDigest':origin['digest'],'resultRef':deepcopy(data['resultRef'])},'accountBinding':frozen,'sourceTitle':chosen['title'],'article':None,'requiresHumanConfirmation':True,'factsVerified':False}
  _seal(article);items.append(article);snapshot=article['digest']
  wb._save(db,scope,actor,row,'content_public_article_preview',request,input_hash,_result(article),authority,receipt_state='unknown')
 wb._public_article_reserved=True
 answer=None;code='PUBLIC_ARTICLE_RESULT_UNKNOWN';message='原读取结果待核对，请保留原编号，不自动重读。'
 try:
  invoke=getattr(wb,'public_article_provider',None);answer=invoke(url) if callable(invoke) else provider.fetch(url)
  if not isinstance(answer,dict) or answer.get('contract')!=provider.contract_for(url) or answer.get('requestedUrl')!=url:raise ValueError('contract')
  code=None
 except Exception as error:
  value=getattr(error,'code',None)
  if isinstance(value,str) and re.fullmatch('[A-Z0-9_]{1,80}',value):code=value;message=str(error)[:200]
 with wb.store.connect() as db:
  db.execute('BEGIN IMMEDIATE');actor,account=wb._authorized(db,user,scope,authority,True)
  if search.account_binding(account)!=frozen:fail('CONTENT_ACCOUNT_CHANGED','账号身份已变化，保留原读取编号，不安装迟到正文',403)
  row=wb._workspace(db,scope,actor);state=wb._state(row);current=next((r for r in articles(state) if r['id']==article['id']),None)
  if current is None:fail('PUBLIC_ARTICLE_SOURCE_CHANGED','原正文读取记录需要核对',409)
  receipt=wb._prior(row,'content_public_article_preview',request,input_hash)
  if receipt is None:fail('PUBLIC_ARTICLE_RECORD_INVALID','原正文读取回执缺失',409)
  if current['state']=='cancelled':return search.replay(wb,row,actor,account,receipt)
  if current['digest']!=snapshot:fail('PUBLIC_ARTICLE_SOURCE_CHANGED','原正文预览已变化，不安装迟到结果',409)
  _selected(wb,db,scope,state,data)
  current.pop('digest');current['completedAt']=now()
  if code is None:current.update(state='received',code=None,article=deepcopy(answer))
  else:current.update(state='unknown',code=code,message=message,article=None)
  _seal(current);result=_result(current)
  row['revision']+=1;row['updatedAt']=now();receipt.update(state='succeeded' if code is None else 'unknown',revision=row['revision'],result=deepcopy(result));row['lastReceipt']={k:deepcopy(v) for k,v in receipt.items() if k!='result'};wb._write(db,scope,row)
  return {'workspace':wb._public(row,actor,account),'result':result,'receipt':{**row['lastReceipt'],'found':True}}

def operate(wb,action,data,row,state,scope,actor,db):
 items=articles(state)
 if action=='content_public_article_read' and 'articleId' not in data:return {'publicArticles':[deepcopy(r) for r in items],'modelCalled':False,'externalRequests':0}
 if not _id(data['articleId']):fail('PUBLIC_ARTICLE_SOURCE','请选择原正文记录',400)
 item=next((r for r in items if r['id']==data['articleId']),None)
 if item is None:fail('PUBLIC_ARTICLE_SOURCE_CHANGED','未找到当前账号原正文记录',409)
 if action=='content_public_article_read':return _result(item)
 if data['articleDigest']!=item['digest']:fail('PUBLIC_ARTICLE_SOURCE_CHANGED','原文版本已变化，请重新预览',409)
 if data['humanConfirmed'] is not True:fail('PUBLIC_ARTICLE_CONFIRM','请本人明确确认当前预览内容',400)
 if action=='content_public_article_cancel':
  # Cancel the preview/result, not a claim that an already issued GET is undone.
  # The in-flight reader is bounded and its late content is never committed.
  item.update(state='cancelled',code='PUBLIC_ARTICLE_CANCELLED',message='预览已取消；原读取编号保留，迟到正文不会保存。',cancelledAt=now(),article=None);_seal(item)
  original=next((r for r in row.get('receipts',[]) if r['requestId']==item['requestId']),None)
  if original is None:
   saved=wb._stored(db,row,sibling('content_workflow').RECEIPT_ENTITY,item['requestId'])
   if saved is not None:original=deepcopy(saved['receipt']);row.setdefault('receipts',[]).append(original)
  if original is None:fail('PUBLIC_ARTICLE_RECORD_INVALID','原读取回执缺失，不能取消',409)
  original.update(state='cancelled',result=_result(item));return _result(item)
 if item['state']!='received' or not isinstance(item['article'],dict):fail('PUBLIC_ARTICLE_UNKNOWN','未取得可确认的正文，不导入摘要或未知内容',409)
 current=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('accounts',scope.account_id,scope.tenant_id)).fetchone()
 if current is None or search.account_binding(__import__('json').loads(current['body']))!=item['accountBinding']:fail('PUBLIC_ARTICLE_SOURCE_CHANGED','原文的采集账号身份已变化，不能作为当前资料确认',409)
 newest=next((r for r in reversed(items) if r['requestedUrl']==item['requestedUrl']),None)
 if newest is not item:fail('PUBLIC_ARTICLE_SOURCE_CHANGED','这个来源已有更新预览，请核对最新原文版本',409)
 if data['kind'] not in ('fact','hypothesis'):fail('CONTENT_INPUT_INVALID','请明确选择事实资料或待核资料',400)
 chosen=item['article'];label='公开正文 · '+('本人选择事实资料，来源仍待核实' if data['kind']=='fact' else '待核资料')
 text='原文网址：'+chosen['requestedUrl']+'\n文章标题：'+(chosen['title'] or '原文未提供')+'\n作者：'+(chosen['author'] or '原文未提供')+'\n原文时间：'+(chosen['publishedTimeRaw'] or '原文未提供')+'\n读取时间：'+chosen['retrievedAt']+'\n\n'+chosen['text']
 saved=wb._operate('content_knowledge_import',{'document':{'title':(chosen['title'] or item['sourceTitle'])[:120],'text':text,'kind':data['kind'],'sourceLabel':label}},row,state,scope,actor,db)
 document=next(d for d in state['documents'] if d['id']==saved['document']['id'])
 document['requiresExplicitReference']=True
 proof={'articleId':item['id'],'articleDigest':item['digest'],'requestedUrl':chosen['requestedUrl'],'finalUrl':chosen['url'],'rawSha256':chosen['rawSha256'],'textSha256':chosen['textSha256'],'retrievedAt':chosen['retrievedAt'],'confirmedBy':actor['username'],'sourceIsNotStoreFactByDefault':True}
 links=document.setdefault('publicArticleSources',[])
 if proof not in links:
  if len(links)>=20:fail('PUBLIC_ARTICLE_LIMIT','此资料的正文观察较多，请核对原版本',409)
  links.append(proof)
 return {'document':deepcopy(document),'alreadyImported':saved['alreadyImported'],'modelCalled':False,'source':proof}
