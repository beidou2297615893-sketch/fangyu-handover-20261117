"""No real platform endpoint/schema has been reviewed. Host stays unavailable."""
WIRE_POLICY=None
