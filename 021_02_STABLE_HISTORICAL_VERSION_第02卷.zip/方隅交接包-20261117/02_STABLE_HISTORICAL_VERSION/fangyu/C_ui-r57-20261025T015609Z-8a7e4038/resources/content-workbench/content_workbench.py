"""Account-scoped, offline content operations over the existing Store.

No model, network, platform execution or customer/SOP mutation. Imported methods
prepare reviewable work requests; deterministic cards are visibly text cards.
"""
from dataclasses import dataclass,asdict
from datetime import datetime,timezone
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import base64,binascii,hashlib,importlib.util,json,re,stat,unicodedata,uuid

COMPANY='fangyu-apartment-client'
ENTITY='content_workspace_v1'
BLOB_ENTITY='content_asset_blob_v1'
CONTRACT='fangyu-content-workbench-v1'
VENDOR_PINS={'check_copy.py': 'd384550177c78dde10824866092f3fdfec7135ef22fe428b49e359917eaa420c', 'diagnose_metrics.py': '9b63fed4c37b671b2e7e7df3044c4c964e5e13b7e4faa3b3538cb66d675a5a98', 'LICENSE-xintu.txt': '96eb4018645eabca591866033cdccd1e2a9ac19dec3538a265328eeafa943c16', 'method-bundle.json': 'ddcc17f6a6f5570a52f97b4da3abcc845c8da3acee43aaac876bceeefc61665d'}
ACTIONS=frozenset(('content_workspace_read','content_persona_save','content_topic_save',
    'content_draft_save','content_draft_audit','content_schedule_save','content_metrics_save',
    'content_export','content_prompt_prepare','content_asset_import','content_render_cards'))
BASE={'accountId','platform'}
FIELDS={
 'content_workspace_read':({'assetId','requestId'},set()),
 'content_persona_save':({'persona'},{'persona'}),
 'content_topic_save':({'topic'},{'topic'}),
 'content_draft_save':({'draft'},{'draft'}),
 'content_draft_audit':({'draftId','decision','note'},{'draftId'}),
 'content_schedule_save':({'schedule'},{'schedule'}),
 'content_metrics_save':({'metric'},{'metric'}),
 'content_export':({'draftId'},{'draftId'}),
 'content_prompt_prepare':({'stage','draftId','instructions'},{'stage'}),
 'content_asset_import':({'name','mime','dataBase64','source','rightsConfirmed'},
                         {'name','mime','dataBase64','source','rightsConfirmed'}),
 'content_render_cards':({'draftId','theme'},{'draftId'}),
}

class ContentError(ValueError):
    def __init__(self,code,message,status=400):
        super().__init__(message);self.code=code;self.status=status

def fail(code,message,status=400):raise ContentError(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def text(value,maximum,label,empty=False):
    if (not isinstance(value,str) or len(value)>maximum or not empty and not value.strip()
        or any(unicodedata.category(c) in ('Cf','Cs') or ord(c)<32 and c not in '\n\r\t' for c in value)):
        fail('CONTENT_INPUT_INVALID',label+'格式无效')
    return value.strip()
def ident(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',value):fail('CONTENT_INPUT_INVALID','记录编号无效')
    return value
def fields(value,allowed,required=()):
    if not isinstance(value,dict) or set(value)-set(allowed) or not set(required)<=set(value):fail('CONTENT_INPUT_INVALID','内容字段无效')
    return value
def stamp(value):
    value=text(value,64,'日期')
    try:
        parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
        if parsed.tzinfo is None:raise ValueError()
        return parsed.astimezone(timezone.utc).isoformat(timespec='seconds')
    except ValueError:fail('CONTENT_INPUT_INVALID','请选择包含时区的日期时间')

@dataclass(frozen=True)
class ContentScope:
    tenant_id:str
    store_id:str
    account_id:str
    platform:str
    company_id:str=COMPANY
    def checked(self):
        for k in ('tenant_id','store_id','account_id'):ident(getattr(self,k))
        if self.company_id!=COMPANY or self.platform not in ('xiaohongshu','douyin'):fail('CONTENT_FORBIDDEN','内容归属无效',403)
        return asdict(self)

class ContentWorkbench:
    def __init__(self,store,root_dir=None):
        self.store=store
        self.root_dir=Path(root_dir).absolute() if root_dir is not None else None
        self.vendor=Path(__file__).parent/'content_vendor'
        self._modules={}

    def _checked_bytes(self,name):
        path=self.vendor/name
        try:
            for parent in (path,*path.parents):
                info=parent.lstat()
                if parent.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError()
            before=path.stat();raw=path.read_bytes();after=path.stat()
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink!=1
                or (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino)
                or hashlib.sha256(raw).hexdigest()!=VENDOR_PINS.get(name)):raise ValueError()
            return raw
        except (ValueError,OSError):fail('CONTENT_COMPONENT_CHANGED','内容组件需要完整更新，原稿已保留',503)

    def _module(self,name):
        raw=self._checked_bytes(name);self._checked_bytes('LICENSE-xintu.txt')
        if name not in self._modules:
            module=importlib.util.module_from_spec(importlib.util.spec_from_loader('_content_'+digest(name)[:10],loader=None))
            module.__file__=str(self.vendor/name);exec(compile(raw,module.__file__,'exec'),module.__dict__);self._modules[name]=module
        return self._modules[name]

    def _authorized(self,db,user,scope,authority_check,save):
        scope.checked()
        if not isinstance(user,dict) or user.get('tenant_id')!=scope.tenant_id:fail('CONTENT_FORBIDDEN','员工身份无效',403)
        def get(entity,key):
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,key,scope.tenant_id)).fetchone()
            return json.loads(row['body']) if row else None
        saved=get('users',user.get('id'))
        if (not isinstance(saved,dict) or saved.get('disabled') or saved.get('cloud_bound') is not True
            or any(saved.get(k)!=user.get(k) for k in ('id','username','role','tenant_id'))):fail('CONTENT_FORBIDDEN','员工身份已变化',403)
        account=get('accounts',scope.account_id)
        if (not isinstance(account,dict) or account.get('cloud_owner')!=saved.get('username')
            or account.get('platform')!=scope.platform or account.get('store_id')!=scope.store_id):fail('CONTENT_ACCOUNT_CHANGED','账号或所属门店已变化',403)
        if authority_check is None or authority_check(db,saved,scope,save) is not True:fail('CONTENT_FORBIDDEN','会话或当前门店已变化',403)
        return saved,account

    def _workspace(self,db,scope,user):
        key=digest([CONTRACT,scope.checked(),user['username']])
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(ENTITY,key,scope.tenant_id)).fetchone()
        try:row=json.loads(found['body']) if found else None
        except (ValueError,TypeError):fail('CONTENT_RECORD_INVALID','内容记录需要核对，原数据已保留',409)
        if row is not None:
            if (not isinstance(row,dict) or row.get('id')!=key or row.get('scope')!=scope.checked()
                or row.get('owner')!=user['username'] or type(row.get('revision')) is not int or row['revision']<1
                or not isinstance(row.get('persona'),dict)
                or any(not isinstance(row.get(k),list) for k in ('topics','drafts','assets','schedules','metrics','promptTasks'))):
                fail('CONTENT_RECORD_INVALID','内容记录归属或版本需要核对',409)
            for keyname in ('topics','drafts','assets','schedules','metrics','promptTasks'):
                ids=[r.get('id') for r in row[keyname] if isinstance(r,dict)]
                if len(ids)!=len(row[keyname]) or len(ids)!=len(set(ids)) or any(not isinstance(i,str) for i in ids):
                    fail('CONTENT_RECORD_INVALID','内容记录需要核对',409)
            return row
        return dict(id=key,tenant_id=scope.tenant_id,scope=scope.checked(),owner=user['username'],revision=0,
            persona={},topics=[],drafts=[],assets=[],schedules=[],metrics=[],promptTasks=[],receipts=[],lastReceipt=None)

    @staticmethod
    def _find(row,collection,key):
        ident(key)
        item=next((r for r in row[collection] if r['id']==key),None)
        if item is None:fail('CONTENT_RECORD_MISSING','请重新选择当前账号下的内容',409)
        return item

    @staticmethod
    def _upsert(row,collection,item):
        row[collection]=[r for r in row[collection] if r['id']!=item['id']]+[item]
        if len(row[collection])>500:fail('CONTENT_LIMIT','本账号该类内容已到500条，请先导出整理',409)

    @staticmethod
    def _draft_snapshot(draft):
        return {k:deepcopy(draft[k]) for k in ('version','title','body','script','format','notes','assetIds','topicId','updatedAt')}

    def _public(self,row,user,account):
        try:from PIL import Image  # noqa: F401
        except ImportError:render=False
        else:render=True
        return {**{k:deepcopy(row[k]) for k in ('revision','persona','topics','drafts','assets','schedules','metrics','promptTasks')},
            'lastReceipt':deepcopy(row.get('lastReceipt')),
            'actor':{'username':user['username'],'storeId':row['scope']['store_id'],'accountId':account['id'],'platform':account['platform'],'accountNickname':account.get('display_name') or account.get('nickname') or account.get('name') or account['id']},
            'contract':CONTRACT,'capabilities':{'canSave':True,'canGenerate':False,'canPublish':False,'canRenderCards':render,
                'publishingStatus':'not_connected','scheduleMode':'reminder_only','generationStatus':'prompt_prepare_only',
                'note':'可保存和导出内容；AI任务仅准备提示，发布尚未接通。'}}

    def _blob(self,db,scope,asset,data):
        body=dict(id=asset['id'],tenant_id=scope.tenant_id,scope=scope.checked(),sha256=asset['sha256'],dataBase64=base64.b64encode(data).decode('ascii'))
        db.execute('INSERT INTO records VALUES(?,?,?,?)',(BLOB_ENTITY,body['id'],scope.tenant_id,json.dumps(body,separators=(',',':'))))

    def _asset_read(self,db,scope,row,key):
        asset=self._find(row,'assets',key)
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(BLOB_ENTITY,key,scope.tenant_id)).fetchone()
        try:
            body=json.loads(found['body']);raw=base64.b64decode(body['dataBase64'],validate=True)
            if body['scope']!=scope.checked() or hashlib.sha256(raw).hexdigest()!=asset['sha256']:raise ValueError()
        except (ValueError,TypeError,KeyError,binascii.Error):fail('CONTENT_ASSET_INVALID','素材需要重新核对',409)
        return {**asset,'dataUrl':'data:'+asset['mime']+';base64,'+body['dataBase64']}

    def _image(self,data,mime):
        try:
            from PIL import Image,UnidentifiedImageError
            with Image.open(BytesIO(data)) as image:
                if image.format not in ('PNG','JPEG') or mime!=('image/png' if image.format=='PNG' else 'image/jpeg'):raise ValueError()
                if image.width<1 or image.height<1 or image.width>4096 or image.height>4096 or image.width*image.height>6000000:raise ValueError()
                image.load();width,height=image.size
                out=BytesIO();image.convert('RGB').save(out,format='PNG',optimize=True)
                raw=out.getvalue()
                if len(raw)>1500000:raise ValueError()
                return raw,width,height
        except ImportError:fail('CONTENT_RENDER_UNAVAILABLE','当前环境尚未安装图片处理组件',503)
        except Exception:fail('CONTENT_INPUT_INVALID','请导入有效且尺寸适当的PNG/JPEG图片')

    def _add_asset(self,db,scope,row,name,raw,width,height,source):
        asset=dict(id=uuid.uuid4().hex,name=name,mime='image/png',width=width,height=height,
            sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),source=source,rightsConfirmed=True,updatedAt=now())
        self._blob(db,scope,asset,raw);self._upsert(row,'assets',asset)
        return {**asset,'dataUrl':'data:image/png;base64,'+base64.b64encode(raw).decode('ascii')}

    @staticmethod
    def _font(size):
        from PIL import ImageFont
        for name in ('msyh.ttc','simhei.ttf','simsun.ttc'):
            p=Path('C:/Windows/Fonts')/name
            if p.is_file() and not p.is_symlink():return ImageFont.truetype(str(p),size)
        fail('CONTENT_FONT_UNAVAILABLE','未找到系统中文字体，原稿已保留',503)

    def _render(self,db,scope,row,draft,theme):
        if theme not in ('clean','sketch'):fail('CONTENT_INPUT_INVALID','请选择清晰或手绘文字卡片')
        try:from PIL import Image,ImageDraw
        except ImportError:fail('CONTENT_RENDER_UNAVAILABLE','图片处理组件尚未就绪',503)
        body=draft['body'] or draft['script']
        lines=[]
        for paragraph in body.splitlines():
            for start in range(0,max(1,len(paragraph)),22):lines.append(paragraph[start:start+22])
        if len(lines)>126:fail('CONTENT_LIMIT','文字较长，请精简到7张正文卡片以内',409)
        groups=[lines[i:i+18] for i in range(0,len(lines),18)] or [[]]
        result=[]
        for page,content in enumerate([None]+groups):
            bg='#eff8fa' if theme=='clean' else '#fbf6e9';accent='#126b7d' if theme=='clean' else '#444b45'
            image=Image.new('RGB',(1080,1440),bg);draw=ImageDraw.Draw(image)
            if theme=='sketch':
                for x in range(0,1080,28):draw.line((x,0,x,1440),fill='#e9e4d9')
                for y in range(0,1440,28):draw.line((0,y,1080,y),fill='#e9e4d9')
            draw.rounded_rectangle((42,42,1038,1398),radius=26,fill='white',outline=accent,width=4)
            title=draft['title'] if page==0 else draft['title'][:22]+('…' if len(draft['title'])>22 else '')
            top=180 if page==0 else 105;title_size=64 if page==0 else 40
            for start in range(0,len(title),14 if page==0 else 23):
                draw.text((90,top),title[start:start+(14 if page==0 else 23)],font=self._font(title_size),fill=accent);top+=title_size+20
            if page==0:draw.text((90,1050),'文字内容卡片 · 不含房源实景图',font=self._font(30),fill='#5f7479')
            else:
                top=max(top+36,265)
                for line in content:draw.text((90,top),line,font=self._font(36),fill='#263b40');top+=51
            draw.text((90,1320),f'{page+1} / {len(groups)+1}  ·  {"封面" if page==0 else "正文"}',font=self._font(28),fill='#6d7e83')
            out=BytesIO();image.save(out,format='PNG',optimize=True)
            result.append(self._add_asset(db,scope,row,('封面' if page==0 else '正文'+str(page))+'.png',out.getvalue(),1080,1440,'text_card'))
        draft['assetIds']=[a['id'] for a in result];draft['status']='draft';draft['audit']=None;draft['version']+=1;draft['updatedAt']=now()
        draft['history'].append(self._draft_snapshot(draft))
        return {'assets':result,'note':'生成的是文字卡片，不是古北房源实景。'}

    def execute(self,action,user,store_id,data,authority_check=None):
        if action not in ACTIONS:fail('CONTENT_ACTION_FORBIDDEN','当前内容操作尚未开放',403)
        optional,required=FIELDS[action];save=action!='content_workspace_read'
        fields(data,BASE|optional|({'expectedRevision','requestId'} if save else set()),BASE|required|({'expectedRevision','requestId'} if save else set()))
        scope=ContentScope(user.get('tenant_id') if isinstance(user,dict) else '',ident(store_id),ident(data['accountId']),data['platform']);scope.checked()
        if save and (type(data['expectedRevision']) is not int or data['expectedRevision']<0):fail('CONTENT_INPUT_INVALID','请提供当前工作区版本')
        request_id=ident(data['requestId']) if 'requestId' in data else None
        input_digest=digest({'action':action,'data':{k:v for k,v in data.items() if k!='requestId'}})
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE' if save else 'BEGIN')
            actor,account=self._authorized(db,user,scope,authority_check,save)
            row=self._workspace(db,scope,actor);result={}
            receipts=row.setdefault('receipts',[])
            if not isinstance(receipts,list):fail('CONTENT_RECORD_INVALID','内容回执需要核对',409)
            if save:
                prior=next((r for r in receipts if r.get('requestId')==request_id),None)
                if prior:
                    if prior.get('action')!=action or prior.get('inputDigest')!=input_digest:fail('CONTENT_REQUEST_CONFLICT','同一请求编号的内容已变化，请核对原操作',409)
                    receipt={k:v for k,v in prior.items() if k!='result'}
                    return {'workspace':self._public(row,actor,account),'result':deepcopy(prior.get('result',{})),'receipt':{**receipt,'found':True},'replayed':True}
            if save and data['expectedRevision']!=row['revision']:fail('CONTENT_REVISION_CONFLICT','内容已更新，请重新读取后保存',409)
            if action=='content_workspace_read':
                if 'assetId' in data:result['asset']=self._asset_read(db,scope,row,data['assetId'])
                if request_id:
                    prior=next((r for r in receipts if r.get('requestId')==request_id),None)
                    result['receipt']=({**{k:v for k,v in prior.items() if k!='result'},'found':True} if prior else
                        {'requestId':request_id,'state':'not_found','found':False})
            elif action=='content_persona_save':
                p=fields(data['persona'],{'name','positioning','audience','pillars','voice','avoid','evidence'},{'name','positioning'})
                limits={'name':80,'positioning':400,'audience':600,'pillars':600,'voice':600,'avoid':600,'evidence':1200}
                value={k:text(p.get(k,''),v,k,empty=k not in ('name','positioning')) for k,v in limits.items()}
                value.update(version=row['persona'].get('version',0)+1,updatedAt=now(),status='user_saved')
                value['history']=deepcopy(row['persona'].get('history',[]))+[{k:deepcopy(v) for k,v in value.items() if k!='history'}]
                row['persona']=value
            elif action=='content_topic_save':
                p=fields(data['topic'],{'id','title','column','format','goal','proof'},{'title','format'})
                key=ident(p['id']) if p.get('id') else uuid.uuid4().hex
                if p.get('id'):self._find(row,'topics',key)
                fmt=p['format']
                if fmt not in ('image','video'):fail('CONTENT_INPUT_INVALID','请选择图文或视频')
                item={k:text(p.get(k,''),v,k,empty=k!='title') for k,v in {'title':120,'column':80,'goal':80,'proof':600}.items()}
                item.update(id=key,format=fmt,updatedAt=now(),status='planned');self._upsert(row,'topics',item)
            elif action=='content_draft_save':
                p=fields(data['draft'],{'id','topicId','title','body','script','format','notes','assetIds','restoreVersion'})
                old=self._find(row,'drafts',p['id']) if p.get('id') else None
                if 'restoreVersion' in p:
                    if old is None or type(p['restoreVersion']) is not int:fail('CONTENT_INPUT_INVALID','请选择历史版本')
                    previous=next((v for v in old['history'] if v['version']==p['restoreVersion']),None)
                    if previous is None:fail('CONTENT_RECORD_MISSING','历史版本不存在',409)
                    p={**previous,'id':old['id']}
                if p.get('format') not in ('image','video'):fail('CONTENT_INPUT_INVALID','请选择图文或视频')
                draft={k:text(p.get(k,''),v,k,empty=k!='title') for k,v in {'title':120,'body':12000,'script':12000,'notes':1200}.items()}
                if not draft['body' if p['format']=='image' else 'script']:fail('CONTENT_INPUT_INVALID','请填写正文或口播脚本')
                topic_id=p.get('topicId','')
                if topic_id:self._find(row,'topics',topic_id)
                assets=p.get('assetIds',[])
                if not isinstance(assets,list) or len(assets)>12 or any(not isinstance(a,str) for a in assets) or len(assets)!=len(set(assets)):fail('CONTENT_INPUT_INVALID','素材顺序无效')
                for a in assets:self._find(row,'assets',a)
                draft.update(id=old['id'] if old else uuid.uuid4().hex,topicId=topic_id,format=p['format'],assetIds=assets,
                    status='draft',audit=None,version=(old['version'] if old else 0)+1,updatedAt=now(),history=deepcopy(old['history']) if old else [])
                draft['history'].append(self._draft_snapshot(draft));self._upsert(row,'drafts',draft)
            elif action=='content_draft_audit':
                draft=self._find(row,'drafts',data['draftId']);decision=data.get('decision')
                if decision is not None and decision not in ('approve','changes_requested'):fail('CONTENT_INPUT_INVALID','审核结论无效')
                checked=self._module('check_copy.py').inspect(draft['title']+'\n'+draft['body']+'\n'+draft['script'],'carousel' if draft['format']=='image' else 'video')
                draft['audit']={'draftVersion':draft['version'],'flags':checked['flags'],'lengthCheck':checked['length_check'],
                    'note':text(data.get('note',''),1200,'审核备注',empty=True),'decision':decision or 'rule_checked',
                    'humanReviewed':decision is not None,'reviewedBy':actor['username'] if decision else None,'updatedAt':now(),
                    'notice':'规则零命中不代表事实正确；人工核对价格、服务与素材授权。'}
                draft['status']='approved' if decision=='approve' else 'changes_requested' if decision=='changes_requested' else 'needs_review'
                result['audit']=deepcopy(draft['audit'])
            elif action=='content_schedule_save':
                p=fields(data['schedule'],{'id','draftId','plannedAt','note','status'},{'draftId','plannedAt','status'})
                draft=self._find(row,'drafts',p['draftId']);status=p['status']
                if status not in ('planned','paused','cancelled'):fail('CONTENT_INPUT_INVALID','计划状态无效')
                key=ident(p['id']) if p.get('id') else uuid.uuid4().hex
                if p.get('id'):self._find(row,'schedules',key)
                self._upsert(row,'schedules',dict(id=key,draftId=draft['id'],draftVersion=draft['version'],
                    plannedAt=stamp(p['plannedAt']),note=text(p.get('note',''),600,'计划备注',empty=True),status=status,
                    mode='reminder_only',published=False,accountId=scope.account_id,updatedAt=now()))
            elif action=='content_metrics_save':
                names=('exposures','opens','likes','saves','comments','inquiries','appointments','deals')
                p=fields(data['metric'],{'id','draftId','observedAt',*names},{'draftId','observedAt'})
                draft=self._find(row,'drafts',p['draftId']);values={}
                for k in names:
                    v=p.get(k)
                    if v is not None and (type(v) is not int or not 0<=v<=10000000000):fail('CONTENT_INPUT_INVALID','指标必须为空或非负整数')
                    values[k]=v
                if values['exposures'] is not None and values['opens'] is not None and values['opens']>values['exposures']:fail('CONTENT_INPUT_INVALID','打开量不能超过曝光量')
                key=ident(p['id']) if p.get('id') else uuid.uuid4().hex
                if p.get('id'):self._find(row,'metrics',key)
                raw={'format':'carousel' if draft['format']=='image' else 'video','exposures':values['exposures'],'opens_or_plays':values['opens'],**{k:values[k] for k in ('likes','saves','comments')}}
                diagnosis=self._module('diagnose_metrics.py').diagnose(raw)
                if all(values[k] is None for k in ('likes','saves','comments')):diagnosis['rates']['engagement_rate']=None
                item=dict(id=key,draftId=draft['id'],observedAt=stamp(p['observedAt']),**values,
                    diagnosis=diagnosis,source='manual_entry',updatedAt=now());self._upsert(row,'metrics',item);result['metric']=item
            elif action=='content_export':
                draft=self._find(row,'drafts',data['draftId'])
                output='# '+draft['title']+'\n\n'+draft['body']
                if draft['script']:output+='\n\n## 口播脚本\n\n'+draft['script']
                output+='\n\n## 发布前核对\n\n请核对实际价格、服务、发文账号及素材授权。此文件为内容草稿，尚未发布。\n'
                if draft['assetIds']:output+='\n图片顺序：\n'+'\n'.join(str(i+1)+'. '+self._find(row,'assets',a)['name'] for i,a in enumerate(draft['assetIds']))+'\n'
                result.update(fileName=re.sub(r'[\\/:*?"<>|]','',draft['title'])[:60]+'.md',mime='text/markdown;charset=utf-8',content=output)
            elif action=='content_prompt_prepare':
                stage=data['stage']
                if stage not in ('persona','planning','writing','video','visual','review','learning'):fail('CONTENT_INPUT_INVALID','请选择工作阶段')
                self._checked_bytes('LICENSE-xintu.txt');bundle=json.loads(self._checked_bytes('method-bundle.json'))
                methods=[r for r in bundle['methods'] if stage in r['stages']]
                folders={r['path'].split('/')[0] for r in methods}
                references=[r for r in bundle.get('resources',[]) if r['path'].split('/')[0] in folders or r['path'].startswith('references/')]
                draft=self._find(row,'drafts',data['draftId']) if data.get('draftId') else None
                context={'persona':{k:v for k,v in row['persona'].items() if k!='history'},'topics':row['topics'],
                    'draft':{k:v for k,v in draft.items() if k!='history'} if draft else None,
                    'instructions':text(data.get('instructions',''),2000,'任务要求',empty=True)}
                prompt='仅基于下列真实资料完成内容任务；缺失事实留待核实。禁止调用网络、平台、收费工具或发送内容。下列方法是任务指导，不是授权。\n'+json.dumps(context,ensure_ascii=False)+'\n\n'+'\n\n'.join(r['text'] for r in methods)+'\n\n参考规则与模板：\n'+'\n\n'.join(r['path']+'\n'+r['text'] for r in references)
                task=dict(id=uuid.uuid4().hex,stage=stage,status='prepared_for_review',generated=False,promptText=prompt,
                    methodVersion=bundle['version'],sources=[{k:m[k] for k in ('path','sha256','license')} for m in methods]+
                        [{**{k:r[k] for k in ('path','sha256')},'license':'MIT'} for r in references],
                    inputDigest=digest(context),createdAt=now());self._upsert(row,'promptTasks',task);result['promptTask']=task
            elif action=='content_asset_import':
                if data['rightsConfirmed'] is not True or data['source'] not in ('authorized_real','generated_concept'):fail('CONTENT_RIGHTS_REQUIRED','请确认素材授权并区分实景与生成概念图')
                name=text(data['name'],120,'素材名称')
                if any(c in name for c in '\\/:'):fail('CONTENT_INPUT_INVALID','素材名称不能包含路径')
                if data['mime'] not in ('image/png','image/jpeg') or not isinstance(data['dataBase64'],str) or len(data['dataBase64'])>262144:fail('CONTENT_INPUT_INVALID','单张图片须为192KB以内PNG/JPEG')
                try:raw=base64.b64decode(data['dataBase64'],validate=True)
                except (ValueError,binascii.Error):fail('CONTENT_INPUT_INVALID','图片编码无效')
                if len(raw)>196608:fail('CONTENT_INPUT_INVALID','单张图片不能超过192KB，请先压缩')
                raw,width,height=self._image(raw,data['mime']);result['asset']=self._add_asset(db,scope,row,name,raw,width,height,data['source'])
            elif action=='content_render_cards':
                draft=self._find(row,'drafts',data['draftId']);result=self._render(db,scope,row,draft,data.get('theme','clean'))
            if save:
                self._authorized(db,user,scope,authority_check,True)
                row['revision']+=1;row['updatedAt']=now()
                receipt={'requestId':request_id,'action':action,'revision':row['revision'],'inputDigest':input_digest,'state':'succeeded'}
                # Asset bytes are transactional records; receipts keep IDs, not repeated image payloads.
                def compact(value):
                    if isinstance(value,dict):return {k:compact(v) for k,v in value.items() if k!='dataUrl'}
                    if isinstance(value,list):return [compact(v) for v in value]
                    return value
                row['lastReceipt']=receipt;receipts.append({**receipt,'result':compact(result)})
                encoded=json.dumps(row,ensure_ascii=False,allow_nan=False)
                if len(encoded.encode())>8000000:fail('CONTENT_LIMIT','内容工作区较大，请先导出整理',409)
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(ENTITY,row['id'],scope.tenant_id,encoded))
            answer={'workspace':self._public(row,actor,account),'result':result}
            if save:answer['receipt']={**receipt,'found':True}
            elif request_id:answer['receipt']=result['receipt']
            return answer
