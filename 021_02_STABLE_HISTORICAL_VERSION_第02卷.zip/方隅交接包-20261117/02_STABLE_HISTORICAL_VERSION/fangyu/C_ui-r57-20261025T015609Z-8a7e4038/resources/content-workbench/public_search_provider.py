"""One fixed DDGS engine. No result fetching, API key, proxy or automatic fallback."""
from pathlib import Path
from datetime import datetime,timezone
from types import SimpleNamespace
import hashlib,importlib.abc,importlib.machinery,importlib.util,json,os,re,stat,sys,threading,time,unicodedata

DEPENDENCY_PIN='5bc8fb38cf2ea7eed95f29520bcad0b145d3bf68e972df7481d81d6f26349387'
CONTRACT='fangyu-public-search-v1';MAX_BODY=1048576
_LOCK=threading.RLock();_FINDER=None

class ProviderError(ValueError):
 def __init__(self,code,message):super().__init__(message);self.code=code;self.status=400 if code=='PUBLIC_SEARCH_QUERY_INVALID' else 503

def fail(code,message):raise ProviderError(code,message)

def _read(path,expected,maximum):
 for p in (path,*path.parents):
  info=p.lstat()
  if p.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索组件路径需要核对')
 before=path.stat()
 if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or before.st_size>maximum:fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索组件文件需要核对')
 raw=path.read_bytes();after=path.stat()
 if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns) or hashlib.sha256(raw).hexdigest()!=expected:
  fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索组件校验未通过')
 return raw

class _Source(importlib.machinery.SourceFileLoader):
 def __init__(self,name,path,pin):super().__init__(name,str(path));self.pin=pin
 def get_code(self,fullname):return compile(_read(Path(self.path),self.pin,1048576),self.path,'exec',dont_inherit=True,optimize=0)

class _Native(importlib.machinery.ExtensionFileLoader):
 def __init__(self,name,path,pin):super().__init__(name,str(path));self.pin=pin
 def create_module(self,spec):
  _read(Path(self.path),self.pin,16777216)
  return super().create_module(spec)

class _Finder(importlib.abc.MetaPathFinder):
 def __init__(self,root,pins):self.root,self.pins=root,pins
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] not in ('ddgs','lxml','primp'):return None
  rel=fullname.replace('.','/');package=rel+'/__init__.py'
  native=[rel+s for s in importlib.machinery.EXTENSION_SUFFIXES if rel+s in self.pins]
  # The fixed lxml wheel contains both a Python fallback and a native module
  # for _elementpath. Match Python's normal package/native/source priority,
  # while every alternative remains pinned and extra code is rejected.
  candidates=[package] if package in self.pins else native or ([rel+'.py'] if rel+'.py' in self.pins else [])
  if len(candidates)!=1:fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索模块不在固定清单中')
  name=candidates[0];p=self.root/name;pin=self.pins[name]['sha256']
  # CPython's Windows DLL loader otherwise rejects a legitimate deeply frozen
  # release path. The extended path names this SAME checked manifest file.
  if os.name=='nt' and not name.endswith('.py') and re.match(r'^[A-Za-z]:\\',str(p)):p=Path('\\\\?\\'+str(p))
  loader=_Source(fullname,p,pin) if name.endswith('.py') else _Native(fullname,p,pin)
  return importlib.util.spec_from_file_location(fullname,p,loader=loader,submodule_search_locations=[str(p.parent)] if name.endswith('/__init__.py') else None)

def _dependencies():
 global _FINDER
 directory=Path(__file__).absolute().parent/'public_research_vendor'
 manifest=json.loads(_read(directory/'DEPENDENCY-PINS.json',DEPENDENCY_PIN,250000))
 root=directory/'runtime';pins=manifest['files']
 if manifest['contract']!='fangyu-public-search-dependencies-v1' or len(pins)!=225:fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索清单需要核对')
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 if actual!=set(pins):fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索目录有缺失或额外文件')
 expected_dirs={parent.as_posix() for name in pins for parent in Path(name).parents if parent.as_posix()!='.'}
 actual_dirs={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_dir()}
 if actual_dirs!=expected_dirs:fail('PUBLIC_SEARCH_DEPENDENCY_INVALID','公开检索目录含额外缓存或路径')
 for name,row in pins.items():_read(root/name,row['sha256'],16777216)
 if _FINDER is None:
  for name in tuple(sys.modules):
   if name.split('.')[0] in ('ddgs','lxml','primp'):fail('PUBLIC_SEARCH_DEPENDENCY_CONFLICT','公开检索依赖已被其他组件加载，请完整重开后核对')
  _FINDER=_Finder(root,pins);sys.meta_path.insert(0,_FINDER)
 elif _FINDER.root!=root or _FINDER.pins!=pins:fail('PUBLIC_SEARCH_DEPENDENCY_CONFLICT','公开检索组件版本已变化，请完整重开')
 from ddgs import DDGS
 from ddgs.engines import ENGINES
 if 'duckduckgo' not in ENGINES['text']:fail('PUBLIC_SEARCH_ENGINE_UNAVAILABLE','固定公开检索服务尚未就绪')
 return DDGS

def query_text(value):
 if not isinstance(value,str) or not 1<=len(value.strip())<=160 or any(unicodedata.category(c).startswith('C') and c not in '\n\t' for c in value):
  fail('PUBLIC_SEARCH_QUERY_INVALID','请填写160字以内的公开检索词，不包含隐藏字符')
 return ' '.join(value.split())

def restricted(value,maximum):
 if not isinstance(value,str):fail('PUBLIC_SEARCH_RESULT_INVALID','公开摘要格式无法核对')
 # Explicit review-only representation; never presented as the complete page.
 changed=len(value)>maximum
 out=[]
 for c in value[:maximum]:
  if unicodedata.category(c).startswith('C') and c not in '\n\t':out.append('�');changed=True
  else:out.append(c)
 return ''.join(out),changed

def search(query,*,response_transport=None):
 query=query_text(query)
 with _LOCK:
  DDGS=_dependencies();client=DDGS(proxy=None,timeout=8,verify=True)
  # The upstream constructor reads DDGS_PROXY. It is never used by this host.
  client._proxy=None;client.threads=1
  engines=client._get_engines('text','duckduckgo')
  if len(engines)!=1 or engines[0].name!='duckduckgo' or engines[0].search_url!='https://html.duckduckgo.com/html/':fail('PUBLIC_SEARCH_ENGINE_UNAVAILABLE','固定检索引擎发生变化')
  http=engines[0].http_client
  # Audited primp 2.0.1 setter clears both explicit and system/environment
  # proxy matcher state. Do not mutate the application's environment.
  http.client.proxy=None
  if http.client.proxy is not None:fail('PUBLIC_SEARCH_PROXY_FORBIDDEN','公开检索不允许代理转发')
  calls=[];started=time.monotonic();source_restricted=[False]
  def bounded(method,url,*args,**kwargs):
   if calls or method!='POST' or url!='https://html.duckduckgo.com/html/' or kwargs.get('data')!={'q':query,'b':'','l':'cn-zh'}:
    fail('PUBLIC_SEARCH_ROUTE_FORBIDDEN','公开检索仅允许固定单次搜索')
   calls.append({'method':method,'url':url})
   if response_transport is not None:
    status,raw=response_transport(method,url,kwargs['data'])
    if type(status) is not int or not isinstance(raw,bytes) or len(raw)>MAX_BODY:fail('PUBLIC_SEARCH_RESPONSE_LIMIT','公开搜索响应超过限制')
   else:
    # Fresh, in-memory HTTP session only; no browser/profile or persisted
    # cookies. Native stream buffers are not an OS hard memory boundary.
    response=http.client.request(method,url,*args,**kwargs,stream=True,follow_redirects=False,timeout=8,read_timeout=8)
    try:
     status=response.status_code;body=bytearray()
     for chunk in response.iter_bytes(16384):
      if len(body)+len(chunk)>MAX_BODY:fail('PUBLIC_SEARCH_RESPONSE_LIMIT','公开搜索响应超过限制')
      body.extend(chunk)
     raw=bytes(body)
    finally:response.close()
   if status!=200:fail('PUBLIC_SEARCH_UNAVAILABLE','公开检索服务暂时不可用；原请求保留，不会自动重搜')
   calls[-1].update(status=status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
   from html import unescape
   decoded=raw.decode('utf-8','replace')
   normalized=unescape(decoded)
   source_restricted[0]=any(unicodedata.category(c).startswith('C') and c not in '\n\r\t' for c in normalized) or '�' in normalized
   return SimpleNamespace(status_code=status,text=decoded,content=raw)
  http.request=bounded
  try:rows=client.text(query,region='cn-zh',safesearch='moderate',max_results=5,page=1,backend='duckduckgo')
  finally:
   # Do not retain a client -> callback -> client cycle after this one read.
   del http.request
  if not 1<=len(rows)<=5 or len(calls)!=1:fail('PUBLIC_SEARCH_NO_RESULTS','没有可核对的公开结果，可能无结果或服务要求验证；未抓取任何结果网页')
  from urllib.parse import urlsplit
  import ipaddress
  results=[]
  for r in rows:
   url=r.get('href');parts=urlsplit(url) if isinstance(url,str) else None
   if not parts or parts.scheme not in ('http','https') or not parts.hostname or parts.username or parts.password or parts.port or len(url)>2000:continue
   host=parts.hostname.casefold()
   if host in ('localhost','localhost.localdomain') or host.endswith(('.local','.localhost','.internal')):continue
   try:
    if not ipaddress.ip_address(host).is_global:continue
   except ValueError:pass
   title,a=restricted(r.get('title'),120);snippet,b=restricted(r.get('body'),1000)
   if not title.strip() or not snippet.strip():continue
   value={'url':url,'title':title,'snippet':snippet,'restrictedView':a or b or source_restricted[0],'kind':'hypothesis','fullTextFetched':False,'sourceLabel':'公开检索摘要，原文未抓取'}
   value['id']='ref-'+hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
   value['digest']=hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();results.append(value)
  if not results:fail('PUBLIC_SEARCH_NO_RESULTS','没有符合来源与摘要限制的公开结果')
  return {'contract':CONTRACT,'provider':'ddgs-9.16.0/duckduckgo-only','query':query,'retrievedAt':datetime.now(timezone.utc).isoformat(),'results':results,'externalRequests':len(calls),'responseBytes':calls[0]['bytes'],'elapsedSeconds':round(time.monotonic()-started,3),'resultUrlsFetched':0,'modelCalled':False,'fullTextFetched':False,'factsVerified':False,'budgetNotice':'逐块读取并在1MB前拒绝更多正文；原生网络缓冲不是操作系统硬内存上限','directTransport':'fixed-primp-cleared-proxy-no-redirect'}
