"""Host-only original-Store mirror of independent central publication grants.

Credentials are read from the original vault and passed to the original cloud
transport, never persisted in this mirror or exposed to browser inputs.
"""
from copy import deepcopy
import hashlib,json,re,time
try:
    from .publication_protocol import validate_policy
except ImportError:
    from publication_protocol import validate_policy

ENTITY='content_publication_authority_v1'
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
class PublicationAuthorityError(RuntimeError):
    code='PUBLISH_AUTHORITY_UNAVAILABLE';status=503

class PublicationAuthorityMirror:
    def __init__(self,*,core,current_user,selected_store,executor_vault,cloud_call,wire_policy,adapter_digest):
        if any(not callable(v) for v in (current_user,selected_store,executor_vault,cloud_call)):raise ValueError('Original host authority dependencies required')
        self.core,self.user,self.selected,self.vault,self.cloud=core,current_user,selected_store,executor_vault,cloud_call
        self.policy=deepcopy(wire_policy);self.adapter_digest=adapter_digest

    def _policy(self):
        p=self.policy
        if (not isinstance(p,dict) or p.get('enabled') is not True or p.get('realProtocolVerified') is not True
                or not isinstance(p.get('revision'),str) or p['revision'].startswith('SYNTHETIC-ONLY')
                or not re.fullmatch(r'[a-f0-9]{64}',str(p.get('digest','')))
                or not re.fullmatch(r'[a-f0-9]{64}',str(self.adapter_digest))):
            raise PublicationAuthorityError('发布协议尚未由宿主核实，已保留稿件')
        try:validate_policy(p)
        except (ValueError,TypeError):raise PublicationAuthorityError('宿主发布协议摘要已变化，已保留稿件') from None
        return p

    def _context(self,envelope):
        p=self._policy();s=envelope['snapshot'];scope=s['scope']
        with self.core.lock:
            user=self.user();saved=self.core.store.get('users',user.get('id')) or {}
            account=self.core.store.get('accounts',scope['account_id']) or {}
            if (saved.get('disabled') or saved.get('cloud_bound') is not True or saved.get('role') not in ('admin','operator')
                    or any(saved.get(k)!=user.get(k) for k in ('id','tenant_id','username','role'))
                    or saved['tenant_id']!=scope['tenant_id'] or saved['username']!=s['owner']
                    or self.selected(saved)!=scope['store_id']
                    or any(account.get(k)!=v for k,v in {'tenant_id':scope['tenant_id'],'cloud_owner':saved['username'],'store_id':scope['store_id'],
                        'platform':'xiaohongshu','platform_uid':s['accountUid']}.items())):
                raise PublicationAuthorityError('原员工、门店或平台账号归属已变化')
            self.core._account_access(saved,account)
            vault=self.vault()
            device=(vault or {}).get('device') or {}
            if (not vault or vault.get('state')!='bound' or not isinstance(vault.get('token'),str) or len(vault['token'])<32
                    or device.get('owner')!=saved['username'] or device.get('revoked') is True
                    or not isinstance(device.get('id'),str) or not device['id']):
                raise PublicationAuthorityError('原平台执行设备尚未绑定，未申请发布权限')
            return saved,account,vault,p

    def _payload(self,envelope,phase,operation=None):
        user,account,vault,policy=self._context(envelope);snap=envelope['snapshot'];scope=snap['scope']
        op=operation or ('content_publication_status' if phase=='status' else 'content_publication_authorize')
        return op,dict(phase=phase,intentId=envelope['intentId'],requestId=envelope['requestId'],snapshotDigest=envelope['snapshotDigest'],
            draftId=snap['draftId'],draftVersion=snap['draftVersion'],storeId=scope['store_id'],accountId=scope['account_id'],accountUid=snap['accountUid'],
            deviceId=vault['device']['id'],executorToken=vault['token'],wireRevision=policy['revision'],wireDigest=policy['digest'],adapterDigest=self.adapter_digest,humanConfirmed=True)

    def _record(self,envelope,response):
        proof=response.get('proof');scope=envelope['snapshot']['scope'];snapshot=envelope['snapshot']
        expected={'contract':'fangyu-publication-capability-v1','enabled':True,'centralVerified':True,'action':'publish','tenantId':scope['tenant_id'],
            'storeId':scope['store_id'],'accountId':scope['account_id'],'accountUid':snapshot['accountUid'],'owner':snapshot['owner'],
            'platform':'xiaohongshu','intentId':envelope['intentId'],'requestId':envelope['requestId'],'snapshotDigest':envelope['snapshotDigest'],
            'wireRevision':self.policy['revision'],'wireDigest':self.policy['digest'],'adapterDigest':self.adapter_digest,'adapterRevision':'owned-publish-port-v1'}
        allowed=set(expected)|{'deviceId','grantRevision','expiresAt','claimNonce','claimState'}
        if (not isinstance(proof,dict) or set(proof)!=allowed or any(type(proof.get(k))!=type(v) or proof.get(k)!=v for k,v in expected.items())
                or type(proof.get('expiresAt')) not in (int,float) or not time.time()<proof['expiresAt']<=time.time()+65
                or not re.fullmatch(r'[a-f0-9]{64}',str(proof.get('grantRevision','')))):
            raise PublicationAuthorityError('企业发布回执与原意图不一致')
        self._context(envelope) # Do not mirror into a different employee/store after transport wait.
        row=dict(id=digest([scope['tenant_id'],snapshot['owner'],envelope['requestId']]),tenant_id=scope['tenant_id'],
            envelopeDigest=digest(envelope),proof=deepcopy(proof),state=response.get('state'),receipt=deepcopy(response.get('receipt')),
            updatedAt=time.time())
        row['recordDigest']=digest(row);self.core.store.put(ENTITY,row)
        return deepcopy(proof)

    def __call__(self,envelope,phase):
        op,payload=self._payload(envelope,phase)
        try:response=self.cloud(op,payload)
        except Exception:raise PublicationAuthorityError('企业发布权限暂未取得；不自动重试') from None
        if not isinstance(response,dict):raise PublicationAuthorityError('企业发布权限回执无效')
        if phase=='before_click' and response.get('dispatchAllowed') is not True:raise PublicationAuthorityError('原发布意图已使用，不能再次点击')
        proof=self._record(envelope,response)
        if phase=='before_click' and proof.get('claimState')!='click_authorized':raise PublicationAuthorityError('原发布占用尚未核对')
        return proof

    def current_for_write(self,envelope):
        """Read only local original grant immediately inside the paused Fetch.
        No cloud wait on the native UI thread and no grant from a read receipt.
        """
        try:
            self._context(envelope);scope=envelope['snapshot']['scope']
            row=self.core.store.get(ENTITY,digest([scope['tenant_id'],envelope['snapshot']['owner'],envelope['requestId']]))
            return (bool(row) and row.get('recordDigest')==digest({k:v for k,v in row.items() if k!='recordDigest'})
                and row.get('envelopeDigest')==digest(envelope) and row.get('state')=='click_authorized'
                and row.get('proof',{}).get('action')=='publish' and row['proof'].get('claimState')=='click_authorized'
                and row['proof'].get('expiresAt',0)>time.time())
        except Exception:return False

    def current_for_upload(self,envelope):
        try:
            self._context(envelope);scope=envelope['snapshot']['scope']
            row=self.core.store.get(ENTITY,digest([scope['tenant_id'],envelope['snapshot']['owner'],envelope['requestId']]))
            return (bool(row) and row.get('recordDigest')==digest({k:v for k,v in row.items() if k!='recordDigest'})
                and row.get('envelopeDigest')==digest(envelope) and row.get('state')=='reserved'
                and row.get('proof',{}).get('action')=='publish' and row['proof'].get('expiresAt',0)>time.time())
        except Exception:return False

    def status(self,envelope):
        self(envelope,'status');scope=envelope['snapshot']['scope']
        row=self.core.store.get(ENTITY,digest([scope['tenant_id'],envelope['snapshot']['owner'],envelope['requestId']])) or {}
        if row.get('state')=='published' and isinstance(row.get('receipt'),dict):return {'state':'published','receipt':deepcopy(row['receipt'])}
        return {'state':'unknown'}

    def observe(self,envelope,receipt):
        op,payload=self._payload(envelope,'observe','content_publication_observe');payload['receipt']=deepcopy(receipt)
        response=self.cloud(op,payload)
        if not isinstance(response,dict) or response.get('state')!='published' or response.get('receipt')!=receipt:
            raise PublicationAuthorityError('原发布回执尚未同步，已保留本机观察')
        return response

    def cancel_unstarted(self,envelope):
        op,payload=self._payload(envelope,'cancel_unstarted','content_publication_cancel_unstarted')
        response=self.cloud(op,payload)
        if not isinstance(response,dict) or response.get('state')!='cancelled_unstarted':raise PublicationAuthorityError('原发布占用未解除')
        return response

def managed_port(port_module,*,core,authority,registry,stage_dir):
    """Actual injection using original Core account leases; caller pins modules.
    Only this wrapper synchronizes centrally verified receipts, never a send retry.
    """
    class ManagedOwnedPort(port_module.OwnedPublishPort):
        def dispatch(self,envelope,assets,reservation):
            result=super().dispatch(envelope,assets,reservation)
            if result.get('state')=='not_sent' and result.get('dispatchStarted') is False:
                try:authority.cancel_unstarted(envelope)
                except Exception:pass # Keep original cloud slot if release is uncertain.
            elif result.get('state')=='published':
                try:authority.observe(envelope,result['receipt'])
                except Exception:pass # Original local passive proof remains recoverable.
            return result
        def status(self,envelope):
            central=authority.status(envelope)
            if central.get('state')=='published':return central
            local=super().status(envelope)
            if local.get('state')=='published':
                try:authority.observe(envelope,local['receipt'])
                except Exception:pass
            return local
    return ManagedOwnedPort(store=core.store,authority=authority,session_provider=registry,
        lease_acquire=core.acquire_account_mode,lease_release=core.release_account_mode,stage_dir=stage_dir)

def assemble_for_backend(backend,token,*,port_module,owned_host_module,wire_policy,adapter_digest,stage_dir):
    """Concrete private Native factory using original session/cloud/vault seams.

    Caller installs returned port as backend._content_publish_port after host
    pin verification. It must unregister/rebuild on employee logout/change.
    No window is created or registered here. That still requires the original
    live owned host and a genuine passive identity observation callback.
    """
    if not isinstance(wire_policy,dict) or wire_policy.get('enabled') is not True or wire_policy.get('realProtocolVerified') is not True:
        return None,None,{'available':False,'reason':'real_publication_protocol_unverified'}
    with backend.lock:
        user,profile=backend._identity(token);scope_state={'stores':backend._stores(profile)}
        if not scope_state['stores']:raise PublicationAuthorityError('当前中央门店权限不可用')
    service=getattr(getattr(backend,'platform_runtime',None),'service',None)
    if service is None or not callable(getattr(getattr(service,'vault',None),'read',None)):
        raise PublicationAuthorityError('原平台执行设备未装入，不能另建发布设备')
    def current_user():
        actor=backend.core.session(token)
        if backend.closed:raise PublicationAuthorityError('原工作台会话已结束')
        return actor
    def selected(actor):
        with backend.lock:return backend._load_selection(actor,scope_state['stores'])['storeId']
    def cloud(operation,payload):
        with backend.lock:
            actor,fresh=backend._identity(token);stores=backend._stores(fresh)
            if backend._load_selection(actor,stores)['storeId']!=payload['storeId']:raise PublicationAuthorityError('当前门店已变化')
            scope_state['stores']=stores;config=backend.integrations._read(actor['tenant_id'])
        # Preserve original authenticated transport and its fixed cloud endpoint.
        result=backend.integrations._cloud(config,actor,operation,**payload)
        with backend.lock:
            actor,latest=backend._identity(token);stores=backend._stores(latest)
            if backend._load_selection(actor,stores)['storeId']!=payload['storeId']:raise PublicationAuthorityError('发布授权返回前门店已变化')
            scope_state['stores']=stores
        return result
    authority=PublicationAuthorityMirror(core=backend.core,current_user=current_user,selected_store=selected,
        executor_vault=service.vault.read,cloud_call=cloud,wire_policy=wire_policy,adapter_digest=adapter_digest)
    def session_factory(window,profile,binding,identity,native):
        return owned_host_module.OriginalOwnedPublicationSession(window,profile,binding,identity,native,core=backend.core,authority=authority,
            port_module=port_module,wire_policy=wire_policy,stage_dir=stage_dir)
    registry=owned_host_module.ExistingOwnedSessionRegistry(backend.core,current_user,service.vault.read,session_factory)
    return (managed_port(port_module,core=backend.core,authority=authority,registry=registry,stage_dir=stage_dir),registry,
        {'available':False,'reason':'original_owned_host_not_registered','publicationAuthority':'checked_on_explicit_confirm'})

class NativePublicationHost:
    """Private Native factory and lifetime owner. Never accepts browser config.

    Registration attaches an already existing window; no login/browser creation
    happens here. Each employee session needs its own explicit registration.
    """
    def __init__(self,backend,*,port_module,owned_host_module,wire_policy,adapter_digest,stage_dir):
        import threading
        self.backend=backend;self.port_module=port_module;self.owned_host_module=owned_host_module
        self.wire_policy=deepcopy(wire_policy);self.adapter_digest=adapter_digest;self.stage_dir=stage_dir
        self.lock=threading.RLock();self.bindings={};self.closed=False

    def for_token(self,token):
        with self.lock:
            if self.closed:raise PublicationAuthorityError('原发布宿主已关闭')
            if not isinstance(self.wire_policy,dict) or self.wire_policy.get('enabled') is not True:return None
            key=digest(token)
            if key in self.bindings:return self.bindings[key][0]
        # Assembly acquires backend.lock. Do not invert its order against logout,
        # which closes this manager while the original backend lock is held.
        binding=assemble_for_backend(self.backend,token,port_module=self.port_module,owned_host_module=self.owned_host_module,
            wire_policy=self.wire_policy,adapter_digest=self.adapter_digest,stage_dir=self.stage_dir)
        with self.lock:
            if self.closed:raise PublicationAuthorityError('原发布宿主已关闭')
            self.bindings.setdefault(key,binding)
            return self.bindings[key][0]

    def register_existing(self,token,window,account_id,*,identity_observation,native=None):
        if self.for_token(token) is None:raise PublicationAuthorityError('真实发布协议未核验，未连接平台窗口')
        with self.lock:
            if self.closed:raise PublicationAuthorityError('原发布宿主已关闭')
            registry=self.bindings[digest(token)][1]
            if registry is None:raise PublicationAuthorityError('真实发布协议未核验，未连接平台窗口')
            return registry.register(window,account_id,identity_observation=identity_observation,native=native)

    def close(self):
        with self.lock:
            self.closed=True
            for _,registry,_ in self.bindings.values():
                if registry is None:continue
                for session in registry.sessions.values():
                    if session.transport is not None:
                        try:session.transport.close()
                        except Exception:pass
                registry.sessions.clear()
            self.bindings.clear()
