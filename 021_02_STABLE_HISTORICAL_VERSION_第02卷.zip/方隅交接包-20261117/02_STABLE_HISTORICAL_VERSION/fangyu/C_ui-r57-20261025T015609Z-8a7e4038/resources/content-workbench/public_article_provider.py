"""One explicit public WeChat article; bounded text only, never browser/session.

Metadata/js_content extraction adapted from OrangeViolin/content-pipeline
976283c66d35338527a580f13edae15bb8dc9b49, MIT Copyright (c) 2026 01fish.
See public_article_vendor/LICENSE-content-pipeline.txt. Its curl/UA/image and
batch network code is not used. Generic HTML uses a separately pinned local
Readability/jsdom worker, no browser or subresources.
"""
from html.parser import HTMLParser
from urllib.parse import urlsplit,urljoin,quote
from datetime import datetime,timezone
import hashlib,http.client,html,ipaddress,re,socket,ssl,threading,time
import json,os,stat,subprocess
from pathlib import Path

CONTRACT='public-wechat-text/1'
MAX_BYTES=2_000_000
MAX_TEXT=64_000
MAX_SECONDS=10
MAX_REDIRECTS=2
HOST='mp.weixin.qq.com'
_DNS_SLOTS=threading.BoundedSemaphore(2)

class ArticleError(ValueError):
 def __init__(self,code,message,status=400):super().__init__(message);self.code=code;self.status=status
def fail(code,message,status=400):raise ArticleError(code,message,status)
def digest(raw):return hashlib.sha256(raw).hexdigest()

GENERIC_CONTRACT='public-html-text/1'
GENERIC_TREE_SHA='dcd5e51c49ffc4d468a931525aaa759f5f0c5fdb875a91e3146219698189f1a7'
GENERIC_NODE_SHA='0d0f5e39f9f3d9587bc19f73eab3c2c9c4903fd02d6dbf9c853dd81b3d95fad4'
GENERIC_NODE_BYTES=86997320
_PARSER_SLOTS=threading.BoundedSemaphore(2)

def contract_for(url):
 checked_url(url)
 return CONTRACT if _hostname(urlsplit(url))==HOST else GENERIC_CONTRACT

def _hostname(u):
 try:return u.hostname.encode('idna').decode('ascii').lower()
 except (UnicodeError,AttributeError):fail('PUBLIC_ARTICLE_URL','文章域名格式无效')

def _generic_safe(path,directory=False,directories=None):
 path=Path(path)
 for part in (path,*path.parents):
  if part!=path and directories is not None and part in directories:continue
  info=part.lstat()
  if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料路径需要完整更新',503)
  if (part!=path or directory) and directories is not None:
   if not stat.S_ISDIR(info.st_mode):fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料目录无效',503)
   directories[part]=(info.st_dev,info.st_ino,info.st_mode,getattr(info,'st_file_attributes',0))
 info=path.stat()
 if directory:
  if not stat.S_ISDIR(info.st_mode):fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析目录需要完整更新',503)
 elif not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析文件需要完整更新',503)
 return (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_nlink)

def _generic_hash(path,deadline,directories=None):
 before=_generic_safe(path,directories=directories);h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):
   if time.monotonic()>=deadline:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时，保留原编号',503)
   h.update(chunk)
 if _generic_safe(path,directories=directories)!=before:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析文件在读取中变化',503)
 return h.hexdigest(),before

def _generic_validate(node_executable,deadline):
 if node_executable is None:fail('PUBLIC_ARTICLE_PARSER_UNAVAILABLE','普通正文解析组件尚未就绪，保留原编号',503)
 root=Path(__file__).absolute().parent/'public_article_generic';node=Path(node_executable)
 if not node.is_absolute() or '..' in node.parts or node.name.lower()!='node.exe':fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析运行器来源无效',503)
 directories={};_generic_safe(root,True,directories)
 node_state=_generic_safe(node,directories=directories)
 if node_state[2]!=GENERIC_NODE_BYTES or _generic_hash(node,deadline,directories)[0]!=GENERIC_NODE_SHA:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析运行器版本需要完整更新',503)
 manifest=root/'TREE-PINS.json';state=_generic_safe(manifest,directories=directories)
 if state[2]>1000000:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料清单无效',503)
 raw=manifest.read_bytes()
 if digest(raw)!=GENERIC_TREE_SHA:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料清单需要完整更新',503)
 try:
  document=json.loads(raw);rows=document['files']
  if set(document)!={'schema','upstream','nodeSha256','totalBytes','files'} or document['schema']!='public_article_generic_tree_v1' or document['nodeSha256']!=GENERIC_NODE_SHA or type(rows) is not list or not 1<=len(rows)<=2500:raise ValueError()
  pins={}
  for row in rows:
   rel=row['path']
   if set(row)!={'path','sha256','bytes'} or type(rel) is not str or not rel or '\\' in rel or ':' in rel or any(p in ('','.','..') for p in rel.split('/')) or rel in pins or type(row['bytes']) is not int or not 0<=row['bytes']<=5000000 or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError()
   pins[rel]=row
  if sum(r['bytes'] for r in rows)!=document['totalBytes'] or document['totalBytes']>30000000:raise ValueError()
 except (ValueError,TypeError,KeyError):fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料清单无效',503)
 actual=set();snapshots={'node':node_state,'TREE-PINS.json':state}
 for path in root.rglob('*'):
  if path.is_dir():_generic_safe(path,True,directories);continue
  rel=path.relative_to(root).as_posix();actual.add(rel)
  if rel=='TREE-PINS.json':continue
  if rel not in pins:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析目录出现未列文件',503)
  value,sig=_generic_hash(path,deadline,directories);row=pins[rel]
  if sig[2]!=row['bytes'] or value!=row['sha256']:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料版本不一致',503)
  snapshots[rel]=sig
 if actual!=set(pins)|{'TREE-PINS.json'}:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料不完整',503)
 for path,expected in directories.items():
  info=path.lstat()
  if path.is_symlink() or (info.st_dev,info.st_ino,info.st_mode,getattr(info,'st_file_attributes',0))!=expected:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料目录在读取中变化',503)
  snapshots['directory:'+str(path)]=expected
 return root,node,snapshots

def _parse_generic(raw,url,node_executable,deadline):
 if not _PARSER_SLOTS.acquire(blocking=False):fail('PUBLIC_ARTICLE_PARSER_BUSY','正文解析仍在结束，请核对原编号，不自动重读',503)
 process=None;threads=[];stdout=[];stderr=[];too_large=threading.Event()
 try:
  if not isinstance(raw,bytes) or not 1<=len(raw)<=MAX_BYTES:fail('PUBLIC_ARTICLE_LIMIT','正文体积不在允许范围',413)
  try:source=raw.decode('utf-8-sig')
  except UnicodeError:fail('PUBLIC_ARTICLE_ENCODING','此网页不是目前支持的UTF-8公开正文')
  payload=json.dumps({'html':source,'url':url},ensure_ascii=False,separators=(',',':')).encode('utf-8')
  if len(payload)>4100000:fail('PUBLIC_ARTICLE_LIMIT','正文传输数据超过本次上限',413)
  root,node,before=_generic_validate(node_executable,deadline)
  if deadline-time.monotonic()<.1:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时',503)
  args=[str(node),'--max-old-space-size=128','--permission','--allow-fs-read='+str(root),'--no-addons',str(root/'worker.cjs')]
  env={'SystemRoot':os.environ.get('SystemRoot','C:\\Windows'),'WINDIR':os.environ.get('WINDIR','C:\\Windows'),'PATH':str(node.parent),'NODE_OPTIONS':'','NODE_PATH':''}
  process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=root,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  def collect(pipe,target,maximum):
   try:
    total=0
    while True:
     chunk=pipe.read(16384)
     if not chunk:break
     total+=len(chunk)
     if total>maximum:
      too_large.set()
      try:process.kill()
      except OSError:pass
      break
     target.append(chunk)
   except (OSError,ValueError):pass
  def write_input():
   try:process.stdin.write(payload);process.stdin.close()
   except (OSError,ValueError):pass
  for target,args_ in [(collect,(process.stdout,stdout,350000)),(collect,(process.stderr,stderr,16000)),(write_input,())]:
   thread=threading.Thread(target=target,args=args_,daemon=True,name='bounded-public-article-parser-pipe');threads.append(thread);thread.start()
  try:process.wait(timeout=max(.001,deadline-time.monotonic()))
  except subprocess.TimeoutExpired:fail('PUBLIC_ARTICLE_TIMEOUT','本次正文解析已超时，保留原编号，不自动重读',503)
  for thread in threads:thread.join(max(0,min(.5,deadline-time.monotonic())))
  if too_large.is_set() or any(t.is_alive() for t in threads):fail('PUBLIC_ARTICLE_LIMIT','正文解析输出超过允许范围',413)
  if time.monotonic()>=deadline:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时',503)
  _,_,after=_generic_validate(node,deadline)
  if before!=after:fail('PUBLIC_ARTICLE_PARSER_INTEGRITY','正文解析材料在读取中变化，结果未保存',503)
  try:
   value=json.loads(b''.join(stdout))
   if type(value) is not dict:raise ValueError()
  except (ValueError,UnicodeError):fail('PUBLIC_ARTICLE_PARSER_UNAVAILABLE','未取得可信的正文解析回执，原编号保留',503)
  if process.returncode!=0 or value.get('ok') is not True:
   if value.get('code')=='PUBLIC_ARTICLE_LIMIT':fail('PUBLIC_ARTICLE_LIMIT','网页结构或正文超过本次解析上限',413)
   fail('PUBLIC_ARTICLE_UNAVAILABLE','未取得无需登录可读的文章正文；登录、验证或动态网页不会绕过',503)
  if set(value)!={'ok','text','title','author','publishedTimeRaw','attemptedNetwork','imagesFetched','scriptsExecuted'} or value['attemptedNetwork']!=0 or type(value['attemptedNetwork']) is not int or value['imagesFetched']!=0 or value['scriptsExecuted'] is not False or any(type(value[k]) is not str for k in ['text','title','author','publishedTimeRaw']):fail('PUBLIC_ARTICLE_PARSER_UNAVAILABLE','正文解析回执需要核对',503)
  body=_plain(value['text'],MAX_TEXT);published=_plain(value['publishedTimeRaw'],120)
  if len(body)<100:fail('PUBLIC_ARTICLE_UNAVAILABLE','未取得可预览的文章正文',503)
  return {'contract':GENERIC_CONTRACT,'url':url,'title':_plain(value['title'],500)[:120],'author':_plain(value['author'],200),'publishedTimeRaw':published,'publishedTimeStatus':'source_value_unverified' if published else 'unknown','text':body,'rawSha256':digest(raw),'textSha256':digest(body.encode('utf-8')),'responseBytes':len(raw),'parser':'mozilla-readability-0.6.0/jsdom-30.1.3/1','imagesFetched':0,'scriptsExecuted':False,'factsVerified':False}
 except ArticleError:raise
 except (OSError,ValueError,TypeError):fail('PUBLIC_ARTICLE_PARSER_UNAVAILABLE','普通正文解析组件未就绪，原编号保留',503)
 finally:
  if process:
   if process.poll() is None:
    try:process.kill()
    except OSError:pass
   try:process.wait(timeout=2)
   except subprocess.TimeoutExpired:pass
   for pipe in (process.stdin,process.stdout,process.stderr):
    if pipe:
     try:pipe.close()
     except OSError:pass
   for thread in threads:thread.join(.5)
  _PARSER_SLOTS.release()


def checked_url(value):
 if not isinstance(value,str) or not 1<=len(value)<=2048 or any(ord(c)<33 or ord(c)==127 for c in value) or '\\' in value:
  fail('PUBLIC_ARTICLE_URL','请选择完整的HTTPS公开文章链接')
 try:u=urlsplit(value);port=u.port
 except ValueError:fail('PUBLIC_ARTICLE_URL','文章链接格式无效')
 if u.scheme!='https' or u.username is not None or u.password is not None or port not in (None,443) or not u.hostname:
  fail('PUBLIC_ARTICLE_SITE_UNSUPPORTED','只读取无需登录的HTTPS公开文章，不接受账号或非标准端口')
 host=_hostname(u)
 try:ipaddress.ip_address(host)
 except ValueError:pass
 else:fail('PUBLIC_ARTICLE_ADDRESS','文章来源必须是公开域名，不接受IP地址')
 labels=host.split('.')
 if (len(host)>253 or len(labels)<2 or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',p) for p in labels)
     or not re.fullmatch(r'(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})',labels[-1])
     or labels[-1] in ('localhost','local','localdomain','internal','intranet','lan','home','corp','test','invalid','example','onion','arpa')
     or u.netloc.lower() not in (u.hostname.lower(),u.hostname.lower()+':443')):
  fail('PUBLIC_ARTICLE_ADDRESS','文章来源不是允许的公开域名')
 if host==HOST and not re.fullmatch(r'/s(?:/[A-Za-z0-9_-]{1,200})?/?',u.path):
  fail('PUBLIC_ARTICLE_SITE_UNSUPPORTED','请选择原微信公众号公开文章链接')
 if re.search(r'%(?:0[0-9a-f]|1[0-9a-f]|7f)',value,re.I):fail('PUBLIC_ARTICLE_URL','文章链接含不支持的控制字符')
 return value

def _public_addresses(deadline,host=HOST):
 if not _DNS_SLOTS.acquire(blocking=False):fail('PUBLIC_ARTICLE_DNS_BUSY','公开地址核对仍在结束，请稍后核对原记录',503)
 done=threading.Event();box={}
 def resolve():
  try:box['addresses']=socket.getaddrinfo(host,443,type=socket.SOCK_STREAM,proto=socket.IPPROTO_TCP)
  except Exception as error:box['error']=error
  finally:_DNS_SLOTS.release();done.set()
 # Timed-out DNS resolution cannot open a socket or issue a late HTTP request.
 # At most two resolver workers exist; only the validated selected hostname is used.
 t=threading.Thread(target=resolve,daemon=True,name='bounded-public-article-dns');t.start()
 if not done.wait(max(0,min(2,deadline-time.monotonic()))):fail('PUBLIC_ARTICLE_TIMEOUT','公开地址核对超时，保留原读取编号，不自动重试',503)
 if 'error' in box:fail('PUBLIC_ARTICLE_NETWORK','公开地址暂时无法核对，保留原编号',503)
 addresses=[]
 for row in box.get('addresses',[]):
  try:ip=ipaddress.ip_address(row[4][0])
  except ValueError:fail('PUBLIC_ARTICLE_ADDRESS','公开地址核对失败',400)
  if not ip.is_global or ip.is_multicast or ip.is_loopback or ip.is_reserved or ip.is_unspecified:
   fail('PUBLIC_ARTICLE_ADDRESS','文章地址不是允许的公网地址',400)
  if str(ip) not in addresses:addresses.append(str(ip))
 if not addresses:fail('PUBLIC_ARTICLE_NETWORK','未取得允许的公开地址',503)
 return addresses

def _one(url,deadline):
 checked_url(url);host=_hostname(urlsplit(url));addresses=_public_addresses(deadline,host);address=addresses[0]
 context=ssl.create_default_context();raw=None;connection=None;timer=None
 try:
  remaining=deadline-time.monotonic()
  if remaining<=0:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时',503)
  raw=socket.create_connection((address,443),timeout=min(3,remaining))
  peer=ipaddress.ip_address(raw.getpeername()[0])
  if str(peer)!=address or not peer.is_global:fail('PUBLIC_ARTICLE_ADDRESS','文章连接地址变化，已停止读取')
  def stop():
   try:raw.shutdown(socket.SHUT_RDWR)
   except OSError:pass
  timer=threading.Timer(max(.001,deadline-time.monotonic()),stop);timer.daemon=True;timer.start()
  raw.settimeout(min(2,max(.001,deadline-time.monotonic())))
  secured=context.wrap_socket(raw,server_hostname=host);raw=secured
  connection=http.client.HTTPSConnection(host,443,timeout=2,context=context);connection.sock=secured
  u=urlsplit(url);target=quote(u.path or '/',safe="/!$&'()*+,;=:@%-._~")+('?' +quote(u.query,safe="/?!$&'()*+,;=:@%-._~") if u.query else '')
  connection.request('GET',target,headers={'Host':host,'User-Agent':'FangyuPublicReader/1.0','Accept':'text/html','Accept-Encoding':'identity','Connection':'close'})
  response=connection.getresponse();headers={k.lower():v for k,v in response.getheaders()}
  if response.status in (301,302,303,307,308):return response.status,headers,b''
  if response.status!=200:return response.status,headers,b''
  if headers.get('content-encoding','identity').lower() not in ('','identity'):fail('PUBLIC_ARTICLE_ENCODING','正文使用了不支持的压缩编码，未保存')
  size=headers.get('content-length')
  if size is not None and (not size.isdigit() or int(size)>MAX_BYTES):fail('PUBLIC_ARTICLE_LIMIT','正文超过本次读取体积上限',413)
  chunks=[];total=0
  while True:
   if time.monotonic()>=deadline:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时，保留原编号',503)
   secured.settimeout(min(2,max(.001,deadline-time.monotonic())))
   chunk=response.read1(min(16384,MAX_BYTES+1-total))
   if not chunk:break
   total+=len(chunk)
   if total>MAX_BYTES:fail('PUBLIC_ARTICLE_LIMIT','正文超过本次读取体积上限',413)
   chunks.append(chunk)
  return response.status,headers,b''.join(chunks)
 except ArticleError:raise
 except (OSError,http.client.HTTPException):fail('PUBLIC_ARTICLE_NETWORK','本次公开读取结果待核对，请保留原编号，不自动重读',503)
 finally:
  if timer:timer.cancel();timer.join(.5)
  if connection:connection.close()
  if raw:
   try:raw.close()
   except OSError:pass

class _Text(HTMLParser):
 BLOCK={'p','div','section','article','br','h1','h2','h3','h4','li','ul','ol','blockquote','table','tr','td'}
 HIDDEN={'script','style','noscript','template','svg','iframe','object','embed','form','nav'}
 def __init__(self):super().__init__(convert_charrefs=True);self.stack=[];self.body=[];self.meta={};self.values={};self.nodes=0
 def handle_starttag(self,tag,attrs):
  self.nodes+=1
  if self.nodes>50000 or len(self.stack)>64:fail('PUBLIC_ARTICLE_LIMIT','文章结构过于复杂',413)
  a=dict(attrs);node={'tag':tag,'id':a.get('id',''),'hidden':tag in self.HIDDEN,'body':a.get('id')=='js_content'}
  if tag=='meta':
   key=a.get('property',a.get('name','')).lower()
   if key in ('og:title','author','article:published_time'):self.meta.setdefault(key,a.get('content','')[:500])
  if tag not in ('br','hr','img','meta','link','input','source','wbr','embed'):self.stack.append(node)
  if tag in self.BLOCK and self._body():self.body.append('\n')
 def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs);self.handle_endtag(tag)
 def handle_endtag(self,tag):
  if tag in self.BLOCK and self._body():self.body.append('\n')
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i]['tag']==tag:del self.stack[i:];break
 def _body(self):return any(n['body'] for n in self.stack) and not any(n['hidden'] for n in self.stack)
 def handle_data(self,data):
  if any(n['hidden'] for n in self.stack):return
  if self._body():self.body.append(data)
  for n in self.stack:
   if n['id'] in ('activity-name','js_name','js_author_name','publish_time'):
    self.values.setdefault(n['id'],[]).append(data)

def _plain(value,maximum):
 value=html.unescape(value);value=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]','',value)
 value='\n'.join(re.sub(r'[ \t\r\f\v]+',' ',s).strip() for s in value.split('\n'))
 value=re.sub(r'\n{3,}','\n\n',value).strip()
 if len(value)>maximum:fail('PUBLIC_ARTICLE_LIMIT','文章文本超过本次预览长度上限',413)
 return value

def parse(raw,url):
 checked_url(url)
 if _hostname(urlsplit(url))!=HOST:fail('PUBLIC_ARTICLE_FORMAT','此来源需使用普通公开正文解析器')
 if not isinstance(raw,bytes) or not 1<=len(raw)<=MAX_BYTES:fail('PUBLIC_ARTICLE_LIMIT','正文体积不在允许范围',413)
 try:source=raw.decode('utf-8-sig');parser=_Text();parser.feed(source);parser.close()
 except UnicodeError:fail('PUBLIC_ARTICLE_ENCODING','目前只支持UTF-8公开图文文章')
 except ArticleError:raise
 except Exception:fail('PUBLIC_ARTICLE_FORMAT','未能读取文章正文结构')
 body=_plain(''.join(parser.body),MAX_TEXT)
 if len(body)<20 or (len(body)<1500 and any(x in body for x in ('环境异常','请先登录','登录后阅读全文','访问过于频繁','该内容已被发布者删除','完成验证后'))):
  fail('PUBLIC_ARTICLE_UNAVAILABLE','未取得无需登录可读的文章正文；不会绕过登录或验证')
 title=parser.meta.get('og:title') or ''.join(parser.values.get('activity-name',[]))
 if not title:
  m=re.search(r"msg_title\s*=\s*['\"](.{1,500}?)['\"]\.html\(false\)",source)
  if m:title=m.group(1)
 author=''.join(parser.values.get('js_name',[])) or ''.join(parser.values.get('js_author_name',[])) or parser.meta.get('author','')
 if not author:
  m=re.search(r"nick_name: JsDecode\(['\"]([^'\"]{1,200})['\"]\)",source)
  if m:author=m.group(1)
 published=parser.meta.get('article:published_time') or ''.join(parser.values.get('publish_time',[]))
 return {'contract':CONTRACT,'url':url,'title':_plain(title,500)[:120],'author':_plain(author,200),'publishedTimeRaw':_plain(published,120),'publishedTimeStatus':'source_value_unverified' if published else 'unknown','text':body,'rawSha256':digest(raw),'textSha256':digest(body.encode('utf-8')),'responseBytes':len(raw),'parser':'wechat-js-content/1','imagesFetched':0,'scriptsExecuted':False,'factsVerified':False}

def fetch(url,response_transport=None,*,node_executable=None):
 checked_url(url);original=url;deadline=time.monotonic()+MAX_SECONDS;hops=[]
 for n in range(MAX_REDIRECTS+1):
  if time.monotonic()>=deadline:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时',503)
  if response_transport is None:status,headers,raw=_one(url,deadline)
  else:status,headers,raw=response_transport('GET',url,{'Accept-Encoding':'identity'},MAX_BYTES,max(0,deadline-time.monotonic()))
  if time.monotonic()>=deadline:fail('PUBLIC_ARTICLE_TIMEOUT','本次公开读取已超时，保留原编号',503)
  if type(status) is not int or not isinstance(headers,dict) or not isinstance(raw,bytes):fail('PUBLIC_ARTICLE_RESPONSE','公开正文响应合同无效',503)
  headers={str(k).lower():str(v) for k,v in headers.items()}
  hops.append({'url':url,'status':status})
  if status in (301,302,303,307,308):
   if n>=MAX_REDIRECTS or not headers.get('location'):fail('PUBLIC_ARTICLE_REDIRECT','文章跳转超过允许范围')
   next_url=checked_url(urljoin(url,headers['location']))
   if _hostname(urlsplit(next_url))!=_hostname(urlsplit(original)):fail('PUBLIC_ARTICLE_REDIRECT','本次只允许同一主机的HTTPS跳转，未继续读取')
   url=next_url;continue
  if status!=200:fail('PUBLIC_ARTICLE_UNAVAILABLE','未取得无需登录的公开正文，不会重试或绕过验证',503)
  if headers.get('content-encoding','identity').lower() not in ('','identity'):fail('PUBLIC_ARTICLE_ENCODING','正文压缩编码暂不支持')
  if headers.get('content-type','').split(';')[0].strip().lower() not in ('text/html','application/xhtml+xml'):fail('PUBLIC_ARTICLE_FORMAT','所选来源未返回支持的公开图文正文')
  answer=parse(raw,url) if _hostname(urlsplit(url))==HOST else _parse_generic(raw,url,node_executable,deadline)
  answer.update(requestedUrl=original,redirects=hops,retrievedAt=datetime.now(timezone.utc).isoformat());return answer
 fail('PUBLIC_ARTICLE_REDIRECT','文章跳转超过允许范围')
