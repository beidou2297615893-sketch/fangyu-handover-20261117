"""Candidate local media jobs in the ORIGINAL Store, not a second customer DB.

The trusted host supplies ContentWorkbench and a fresh authority callback. A
browser may pass opaque upload/asset/job IDs, never paths or FFmpeg arguments.
No existing page, Native action, production record or platform is changed here.
"""
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone
import hashlib,html,importlib,json,os,re,threading,uuid
_engine=importlib.import_module('.cpu_media_engine',__package__) if __package__ else importlib.import_module('cpu_media_engine')
CpuMediaEngine,MediaError,Lease,LeaseSet,checked_file,digest,fail=(_engine.CpuMediaEngine,_engine.MediaError,
    _engine.Lease,_engine.LeaseSet,_engine.checked_file,_engine.digest,_engine.fail)

ASSETS='content_media_assets_v1';JOBS='content_media_jobs_v1';RECEIPTS='content_media_receipts_v1'
PUBLIC={'id','state','version','inputDigest','taskId','sourceTaskDigest','createdAt','updatedAt','durationMs',
        'progressMs','audio','code','output','cancelRequested','runRequestId'}
def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def ident(value):
    if not isinstance(value,str) or not re.fullmatch('[A-Za-z0-9_-]{1,160}',value):fail('MEDIA_INPUT_INVALID','媒体编号无效')
    return value
def exact(data,required):
    if not isinstance(data,dict) or set(data)!=set(required):fail('MEDIA_INPUT_INVALID','媒体参数无效')
    return data

class MediaProduction:
    def __init__(self,content,scope_type,root,ingest_root,tools):
        self.content,self.store,self.scope_type=content,content.store,scope_type
        self.root=Path(root).absolute();self.ingest=Path(ingest_root).absolute()
        self.root.mkdir(parents=True,exist_ok=True);self.ingest.mkdir(parents=True,exist_ok=True)
        for path in (self.root,self.ingest):
            for part in (path,*path.parents):
                if part.is_symlink() or getattr(part.lstat(),'st_file_attributes',0)&0x400:fail('MEDIA_PATH_DENIED','媒体目录不能是链接')
        self.engine=CpuMediaEngine(tools);self.tools=tools;self.workers={};self.lock=threading.RLock()
    def _scope(self,user,store,data):
        return self.scope_type(user['tenant_id'],ident(store),ident(data['accountId']),data['platform'])
    def _authority(self,db,user,scope,check,save):
        actor,account=self.content._authorized(db,user,scope,check,save)
        row=self.content._workspace(db,scope,actor)
        return actor,row
    @staticmethod
    def _get(db,entity,key,scope):
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,key,scope.tenant_id)).fetchone()
        if found is None:return None
        row=json.loads(found['body'])
        if row.get('scope')!=scope.checked() or row.get('recordDigest')!=digest({k:v for k,v in row.items() if k!='recordDigest'}):
            fail('MEDIA_RECORD_INVALID','媒体记录归属或完整性需核对')
        return row
    @staticmethod
    def _put(db,entity,row):
        row=deepcopy(row);row['recordDigest']=digest({k:v for k,v in row.items() if k!='recordDigest'})
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))
    def _record(self,db,entity,key,scope,actor):
        row=self._get(db,entity,ident(key),scope)
        if row is None or row.get('owner')!=actor['username'] or row.get('actorId')!=actor['id']:fail('MEDIA_RECORD_MISSING','此媒体不属于当前员工和账号')
        return row
    @staticmethod
    def _public(row):return {k:deepcopy(v) for k,v in row.items() if k in PUBLIC}
    @staticmethod
    def _asset_view(row):return {k:deepcopy(row[k]) for k in ('id','name','kind','sha256','bytes','source','rightsNote','rightsConfirmed','probe','createdAt')}
    def _receipt(self,db,actor,scope,request,action,value,job=None):
        key=digest([scope.checked(),actor['id'],ident(request)])
        old=self._get(db,RECEIPTS,key,scope);fingerprint=digest([action,value])
        if old:
            if old.get('owner')!=actor['username'] or old['action']!=action or old['inputDigest']!=fingerprint:
                fail('MEDIA_REQUEST_CONFLICT','原操作编号已用于其他媒体内容')
            return old
        if job is None:return None
        record={'id':key,'tenant_id':scope.tenant_id,'scope':scope.checked(),'owner':actor['username'],'actorId':actor['id'],
            'action':action,'requestId':request,'inputDigest':fingerprint,'targetId':job,'createdAt':now()}
        self._put(db,RECEIPTS,record);return record
    @staticmethod
    def _commit(db):
        try:db.commit()
        except Exception as exc:raise MediaError('MEDIA_RESULT_UNCONFIRMED','结果尚未确认，请读取原媒体任务',mutation_committed=None) from exc
    def _asset_path(self,asset):return self.root/'assets'/asset['id']
    def _ingest_directory(self,scope,actor):
        # Trusted upload bridge uses this exact employee/account directory.
        # A browser uploadRef is never looked up in a shared staging root.
        return self.ingest/digest([scope.checked(),actor['id']])
    def _source(self,row,task_id):
        state=row.get('workflow') or {};task=next((t for t in state.get('tasks',[]) if t.get('id')==task_id),None)
        if not task or task.get('state')!='succeeded' or not task.get('artifactId') or task.get('appliedRefs') is None:
            fail('MEDIA_SOURCE_UNAPPROVED','请先在原内容任务中确认采用脚本或制作方案')
        artifact=next((a for a in state.get('artifacts',[]) if a.get('id')==task['artifactId']),None)
        if not artifact or artifact.get('outputDigest')!=digest(artifact.get('output')):fail('MEDIA_SOURCE_CHANGED','原内容产物需重新核对')
        return digest({'task':{k:task.get(k) for k in ('id','methodId','methodDigest','sourceRevision','inputDigest','artifactId','appliedRefs')},
                       'artifactDigest':artifact['outputDigest']})
    def import_asset(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','uploadRef','name','rightsConfirmed','rightsNote','source','requestId'})
        scope=self._scope(user,store,data)
        if data['rightsConfirmed'] is not True or data['source'] not in ('authorized_real','synthetic_test','generated_concept') or not isinstance(data['rightsNote'],str) or not 1<=len(data['rightsNote'].strip())<=300:
            fail('MEDIA_RIGHTS_REQUIRED','请说明来源并确认有权使用素材')
        if not isinstance(data['name'],str) or not 1<=len(data['name'])<=80:fail('MEDIA_INPUT_INVALID','素材名称无效')
        ref=data['uploadRef']
        if not isinstance(ref,str) or not re.fullmatch('[A-Za-z0-9_-]{1,80}\.(mp4|mov|srt|txt)',ref):fail('MEDIA_PATH_DENIED','请选择本次上传的素材编号')
        with self.store.connect() as db:actor,_row=self._authority(db,user,scope,authority_check,False)
        staged=self._ingest_directory(scope,actor)
        try:raw=checked_file(staged/ref,staged,65536 if ref.endswith(('.srt','.txt')) else 67108864)
        except FileNotFoundError:fail('MEDIA_UPLOAD_MISSING','此上传不属于当前员工和账号，或已失效')
        asset_hash=hashlib.sha256(raw).hexdigest();kind='srt' if ref.endswith('.srt') else 'script' if ref.endswith('.txt') else 'video'
        signature={k:data[k] for k in ('name','rightsConfirmed','rightsNote','source')};signature.update(sha256=asset_hash,kind=kind)
        with self.store.connect() as db:
            actor,_=self._authority(db,user,scope,authority_check,False)
            prior=self._receipt(db,actor,scope,data['requestId'],'import',signature)
            if prior:return self._asset_view(self._record(db,ASSETS,prior['targetId'],scope,actor))
        aid=uuid.uuid4().hex;folder=self.root/'assets';folder.mkdir(exist_ok=True)
        target=folder/aid
        # Exclusive private file. A failed transaction can leave an unreferenced
        # owned file; it cannot install a public asset or overwrite old media.
        with target.open('xb') as out:out.write(raw)
        if kind=='video':self.tools.verify();info=self.engine.probe(target)
        else:info={}
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,row=self._authority(db,user,scope,authority_check,True)
            prior=self._receipt(db,actor,scope,data['requestId'],'import',signature)
            if prior:return self._asset_view(self._record(db,ASSETS,prior['targetId'],scope,actor))
            asset={'id':aid,'tenant_id':scope.tenant_id,'scope':scope.checked(),'owner':actor['username'],'actorId':actor['id'],
                'workspaceId':row['id'],'name':data['name'],'kind':kind,'sha256':asset_hash,'bytes':len(raw),
                'source':data['source'],'rightsNote':data['rightsNote'].strip(),'rightsConfirmed':True,'probe':info,'createdAt':now()}
            self._put(db,ASSETS,asset);self._receipt(db,actor,scope,data['requestId'],'import',signature,aid);self._commit(db)
        return self._asset_view(asset)
    def prepare(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','taskId','expectedRevision','clips','captionAssetId','audio','requestId'})
        scope=self._scope(user,store,data);tools=self.tools.verify()
        if data['audio'] not in ('mute','keep_source') or not isinstance(data['clips'],list) or not 1<=len(data['clips'])<=8:
            fail('MEDIA_INPUT_INVALID','请选择 1—8 段视频及原声处理方式')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,row=self._authority(db,user,scope,authority_check,True)
            prior=self._receipt(db,actor,scope,data['requestId'],'prepare',data)
            if prior:return self._public(self._record(db,JOBS,prior['targetId'],scope,actor))
            if type(data['expectedRevision']) is not int or row['revision']!=data['expectedRevision']:fail('MEDIA_VERSION_CONFLICT','内容工作区已变化，请重新读取')
            source=self._source(row,ident(data['taskId']));clips=[];total=0
            for item in data['clips']:
                exact(item,{'assetId','startMs','endMs'});asset=self._record(db,ASSETS,item['assetId'],scope,actor)
                if asset['kind']!='video' or any(type(item[k]) is not int for k in ('startMs','endMs')) or not 0<=item['startMs']<item['endMs']<=asset['probe']['durationMs']:
                    fail('MEDIA_INPUT_INVALID','片段起止时间须在原素材内')
                if data['audio']=='keep_source' and not asset['probe']['hasAudio']:fail('MEDIA_AUDIO_MISSING','部分片段没有原声，请选择静音或补充有原声素材')
                total+=item['endMs']-item['startMs'];clips.append({**item,'sha256':asset['sha256']})
            if not 1000<=total<=60000:fail('MEDIA_LIMIT','当前普通电脑模式每条成片限 1—60 秒')
            srt=self._record(db,ASSETS,data['captionAssetId'],scope,actor)
            if srt['kind'] not in ('srt','script'):fail('MEDIA_SUBTITLE_INVALID','请选择提供的 SRT 字幕或文字脚本')
            raw=checked_file(self._asset_path(srt),self.root,65536)
            if hashlib.sha256(raw).hexdigest()!=srt['sha256']:fail('MEDIA_INPUT_CHANGED','字幕素材已变化')
            captions=self.engine.captions(raw,total) if srt['kind']=='srt' else self.engine.script_captions(raw,total)
            snapshot={'clips':clips,'captions':captions,'captionAssetId':srt['id'],'captionSha256':srt['sha256'],
                'captionTiming':'provided_srt' if srt['kind']=='srt' else 'evenly_spaced_user_script',
                'durationMs':total,'audio':data['audio'],'tools':tools}
            job={'id':uuid.uuid4().hex,'tenant_id':scope.tenant_id,'scope':scope.checked(),'owner':actor['username'],'actorId':actor['id'],
                'workspaceId':row['id'],'taskId':data['taskId'],'sourceTaskDigest':source,'state':'prepared','version':1,
                'snapshot':snapshot,'inputDigest':digest([scope.checked(),source,snapshot]),'durationMs':total,'audio':data['audio'],
                'progressMs':0,'cancelRequested':False,'createdAt':now(),'updatedAt':now()}
            self._put(db,JOBS,job);self._receipt(db,actor,scope,data['requestId'],'prepare',data,job['id']);self._commit(db)
            return self._public(job)
    def _job_folder(self,job):
        folder=self.root/'jobs'/ident(job['id']);folder.mkdir(parents=True,exist_ok=True);return folder
    def read(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','jobId'});scope=self._scope(user,store,data)
        with self.store.connect() as db:
            actor,row=self._authority(db,user,scope,authority_check,False)
            job=self._record(db,JOBS,data['jobId'],scope,actor)
            return self._public(job)
    def query_request(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','requestId'});scope=self._scope(user,store,data)
        with self.store.connect() as db:
            actor,_row=self._authority(db,user,scope,authority_check,False)
            key=digest([scope.checked(),actor['id'],ident(data['requestId'])]);receipt=self._get(db,RECEIPTS,key,scope)
            if receipt is None:return {'requestId':data['requestId'],'state':'not_found','newRenderDispatched':False}
            if receipt['owner']!=actor['username'] or receipt['actorId']!=actor['id']:fail('MEDIA_REQUEST_CONFLICT','此操作不属于当前员工')
            is_asset=receipt['action']=='import';record=self._record(db,ASSETS if is_asset else JOBS,receipt['targetId'],scope,actor)
            return {'requestId':data['requestId'],'state':'recorded','action':receipt['action'],'inputDigest':receipt['inputDigest'],
                'target':self._asset_view(record) if is_asset else self._public(record),'newRenderDispatched':False}
    def preview(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','jobId'});scope=self._scope(user,store,data)
        with self.store.connect() as db:
            actor,_row=self._authority(db,user,scope,authority_check,False);job=self._record(db,JOBS,data['jobId'],scope,actor)
            cursor=0;clips=[]
            for clip in job['snapshot']['clips']:
                asset=self._record(db,ASSETS,clip['assetId'],scope,actor)
                clips.append({**clip,'timelineStartMs':cursor,'name':asset['name'],'source':asset['source'],'rightsConfirmed':asset['rightsConfirmed']})
                cursor+=clip['endMs']-clip['startMs']
            return {'job':self._public(job),'timeline':{'clips':clips,'captions':deepcopy(job['snapshot']['captions']),
                'captionTiming':job['snapshot']['captionTiming'],'durationMs':job['durationMs'],'width':720,'height':1280,
                'audio':job['audio'],'voiceoverGenerated':False,'speechRecognitionUsed':False}}
    def recover(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','jobId'});scope=self._scope(user,store,data)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,row=self._authority(db,user,scope,authority_check,True)
            job=self._record(db,JOBS,data['jobId'],scope,actor)
            if job['state'] not in ('running','cancel_requested'):return self._public(job)
            try:lease=Lease(self._job_folder(job)/'render.lock')
            except OSError:return {**self._public(job),'workerObserved':'live_os_lease'}
            try:
                job.update(state='cancelled' if job['cancelRequested'] else 'interrupted',code='MEDIA_INTERRUPTED',version=job['version']+1,updatedAt=now())
                self._put(db,JOBS,job);self._commit(db);return self._public(job)
            finally:lease.close()
    def start(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','jobId','expectedVersion','inputDigest','requestId'})
        scope=self._scope(user,store,data);self.tools.verify();lease=None
        try:
            with self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');actor,row=self._authority(db,user,scope,authority_check,True)
                prior=self._receipt(db,actor,scope,data['requestId'],'start',data)
                if prior:return self._public(self._record(db,JOBS,prior['targetId'],scope,actor))
                job=self._record(db,JOBS,data['jobId'],scope,actor)
                if job['state'] not in ('prepared','interrupted') or job['version']!=data['expectedVersion'] or job['inputDigest']!=data['inputDigest']:
                    fail('MEDIA_VERSION_CONFLICT','任务状态已变化，请核对原任务，不要重复启动')
                if self._source(row,job['taskId'])!=job['sourceTaskDigest']:fail('MEDIA_SOURCE_CHANGED','原制作方案已变化，请新建成片任务')
                try:lease=LeaseSet(self.root/'cpu-render.lock',self._job_folder(job)/'render.lock')
                except OSError:fail('MEDIA_BUSY','已有受控媒体任务运行，请先等它结束')
                job.update(state='running',version=job['version']+1,runRequestId=data['requestId'],cancelRequested=False,progressMs=0,updatedAt=now())
                self._put(db,JOBS,job);self._receipt(db,actor,scope,data['requestId'],'start',data,job['id']);self._commit(db)
            event=threading.Event();thread=threading.Thread(target=self._worker,args=(deepcopy(user),scope,deepcopy(job),authority_check,event,lease),daemon=True)
            with self.lock:self.workers[job['id']]=(thread,event)
            try:thread.start()
            except Exception as exc:raise MediaError('MEDIA_RESULT_UNCONFIRMED','启动结果需核对，请读取原任务再恢复',mutation_committed=True) from exc
            lease=None
            return self._public(job)
        finally:
            if lease:lease.close()
    def cancel(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','jobId','expectedVersion','inputDigest','requestId'});scope=self._scope(user,store,data)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,row=self._authority(db,user,scope,authority_check,True)
            prior=self._receipt(db,actor,scope,data['requestId'],'cancel',data)
            if prior:return self._public(self._record(db,JOBS,prior['targetId'],scope,actor))
            job=self._record(db,JOBS,data['jobId'],scope,actor)
            if job['version']!=data['expectedVersion'] or job['inputDigest']!=data['inputDigest']:fail('MEDIA_VERSION_CONFLICT','请核对当前媒体任务后取消')
            if job['state'] in ('prepared','interrupted'):job['state']='cancelled'
            elif job['state']=='running':job['state']='cancel_requested'
            else:fail('MEDIA_VERSION_CONFLICT','此媒体任务已结束或正在取消')
            job.update(cancelRequested=True,version=job['version']+1,updatedAt=now())
            self._put(db,JOBS,job);self._receipt(db,actor,scope,data['requestId'],'cancel',data,job['id']);self._commit(db)
            return self._public(job)
    def _worker(self,user,scope,job,check,event,lease):
        run=job['runRequestId'];folder=self._job_folder(job)/uuid.uuid4().hex;folder.mkdir()
        def control():
            if event.is_set():fail('MEDIA_CANCELLED','媒体任务已取消')
            with self.store.connect() as db:
                actor,row=self._authority(db,user,scope,check,False)
                current=self._record(db,JOBS,job['id'],scope,actor)
                if current.get('runRequestId')!=run or current['state'] not in ('running','cancel_requested'):fail('MEDIA_SOURCE_CHANGED','原媒体任务已变化')
                if current['cancelRequested']:fail('MEDIA_CANCELLED','媒体任务已取消')
                if self._source(row,job['taskId'])!=job['sourceTaskDigest']:fail('MEDIA_SOURCE_CHANGED','原制作方案已变化')
        def progress(seconds):
            with self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');current=self._get(db,JOBS,job['id'],scope)
                if current and current.get('runRequestId')==run and current['state']=='running':
                    current.update(progressMs=min(job['durationMs'],max(current['progressMs'],round(seconds*1000))),updatedAt=now());self._put(db,JOBS,current)
        try:
            control()
            for i,clip in enumerate(job['snapshot']['clips']):
                with self.store.connect() as db:asset=self._record(db,ASSETS,clip['assetId'],scope,user)
                raw=checked_file(self._asset_path(asset),self.root)
                if hashlib.sha256(raw).hexdigest()!=clip['sha256']:fail('MEDIA_INPUT_CHANGED','原视频素材已变化')
                (folder/f'clip{i}.mp4').write_bytes(raw)
            output,info=self.engine.render(folder,job['snapshot'],control,progress)
            control();raw=checked_file(output,folder,33554432);output_hash=hashlib.sha256(raw).hexdigest()
            final=folder/'result.mp4';output.replace(final)
            with self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');actor,row=self._authority(db,user,scope,check,True)
                current=self._record(db,JOBS,job['id'],scope,actor)
                if current.get('runRequestId')!=run or current['state']!='running' or current['cancelRequested'] or self._source(row,job['taskId'])!=job['sourceTaskDigest']:
                    fail('MEDIA_SOURCE_CHANGED','返回时账号、方案或任务已变化，成片未采用')
                current.update(state='succeeded',version=current['version']+1,progressMs=job['durationMs'],updatedAt=now(),
                    output={'mime':'video/mp4','sha256':output_hash,'bytes':len(raw),'width':720,'height':1280,'durationMs':info['durationMs'],
                            'audio':'source_audio' if job['audio']=='keep_source' else 'none','captionTiming':job['snapshot']['captionTiming'],
                            'voiceoverGenerated':False,'platformPublished':False},
                    outputRef=final.relative_to(self.root).as_posix())
                self._put(db,JOBS,current);self._commit(db)
        except Exception as error:
            with self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');current=self._get(db,JOBS,job['id'],scope)
                if current and current.get('runRequestId')==run and current['state'] in ('running','cancel_requested'):
                    current.update(state='cancelled' if current['cancelRequested'] or event.is_set() else 'failed',
                        code=getattr(error,'code','MEDIA_WORKER_FAILED'),version=current['version']+1,updatedAt=now())
                    current.pop('outputRef',None);current.pop('output',None);self._put(db,JOBS,current)
        finally:
            lease.close()
            with self.lock:self.workers.pop(job['id'],None)
    def output(self,user,store,data,authority_check):
        exact(data,{'accountId','platform','jobId'});scope=self._scope(user,store,data)
        with self.store.connect() as db:
            actor,row=self._authority(db,user,scope,authority_check,False);job=self._record(db,JOBS,data['jobId'],scope,actor)
            if job['state']!='succeeded' or not job.get('outputRef'):fail('MEDIA_OUTPUT_UNAVAILABLE','尚无可导出的已核对成片')
            raw=checked_file(self.root/job['outputRef'],self.root,33554432)
            if hashlib.sha256(raw).hexdigest()!=job['output']['sha256']:fail('MEDIA_OUTPUT_CHANGED','成片文件已变化，请保留原任务核对')
            return raw,deepcopy(job['output'])
    def close(self):
        with self.lock:workers=list(self.workers.values())
        for thread,event in workers:event.set()
        for thread,event in workers:thread.join(timeout=3)
