"""Narrow authenticated local-media bridge; no client paths or executable options."""
from pathlib import Path
from copy import deepcopy
import base64, hashlib, importlib, json, os, re, shutil, stat, sys, threading, time, uuid
from .cpu_media_engine import Tools, MediaError, checked_file, digest, fail
from .media_production import MediaProduction, ASSETS, JOBS, exact, ident, now

ACTIONS=frozenset('media_services_status media_ocr_preview media_speech_preview media_speech_cancel media_speech_save media_speech_read media_status media_upload_begin media_upload_read media_upload_chunk media_upload_complete media_upload_cancel media_prepare media_read media_preview media_start media_cancel media_recover media_request'.split())
UPLOADS='content_media_uploads_v1'
CHUNK=65536
TOOL_PINS=('09948d4cdd0650da6ff5a87577469f2a218dc2615ae379f8f734d24c49de0f73',
           'a6618e99bb58869ded3c6f37b53aa1a8d701c3591dbb7b5b317d47369c112be2',
           'd79c55e68b1131eea0cc1c47be4f572d964f28c682e143db2ad09c1e4cb07a3f')

def installed_tools():
    # Discovery is not execution. Only these audited bytes may run. No download,
    # PATH mutation, bundled GPL binary or browser-selected executable is allowed.
    found=shutil.which('ffmpeg')
    if not found:fail('MEDIA_TOOL_UNAVAILABLE','未找到已安装并核验的 FFmpeg，请联系管理员配置；不会自动下载')
    ff=Path(found).absolute();probe=ff.with_name('ffprobe.exe' if os.name=='nt' else 'ffprobe')
    font=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts/msyh.ttc'
    tools=Tools(ff,probe,font,*TOOL_PINS);tools.verify();return tools

def checked_directory(path,root,*,create=False):
    """Application path guard; not an OS sandbox or a concurrent-swap lock."""
    path=Path(os.path.abspath(os.fspath(path)));root=Path(os.path.abspath(os.fspath(root)))
    if not path.is_relative_to(root):fail('MEDIA_PATH_DENIED','媒体位置不在当前工作区')
    def parents():
        for part in (path,*path.parents):
            try:info=part.lstat()
            except FileNotFoundError:continue
            if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
                fail('MEDIA_PATH_DENIED','媒体目录及父目录不能是链接或重解析位置')
            if not stat.S_ISDIR(info.st_mode):fail('MEDIA_PATH_DENIED','媒体父目录类型不正确')
    parents()
    if create:
        path.mkdir(parents=True,exist_ok=True)
        parents()
    return path

def account_digest(account):
    return digest({k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform',
        'platform_user_id','platform_uid','platform_account_id','uid','user_id','connection_profile_id')})

def checked_upload(path,root):
    # An exclusive upload starts empty. The sealed engine intentionally rejects
    # empty assets; keep that invariant and validate this staging case here.
    path=Path(path).absolute();root=Path(root).absolute()
    if not path.is_relative_to(root):fail('MEDIA_PATH_DENIED','上传位置不在当前账号暂存区')
    for part in (path,*path.parents):
        info=part.lstat()
        if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:fail('MEDIA_PATH_DENIED','上传位置不能是链接')
    info=path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or not 0<=info.st_size<=67108864:fail('MEDIA_INPUT_INVALID','上传文件类型或大小无效')
    return checked_file(path,root,67108864) if info.st_size else b''

class NativeMedia:
    actions=ACTIONS
    def __init__(self,owner):
        self.owner=owner;self.services={};self.lock=threading.RLock()
        self.root=owner.data_dir/'content-media';self.ingest=self.root/'uploads'
    def checked_directory(self,path,*,create=False):
        return checked_directory(path,self.owner.data_dir,create=create)

    def close(self):
        if getattr(self,'windows_services',None):self.windows_services.close()
        for service in list(self.services.values()):service.close()

    def context(self,token,data):
        if (not isinstance(data,dict) or not isinstance(data.get('storeId'),str)
                or not re.fullmatch('[A-Za-z0-9_-]{1,160}',data['storeId'])
                or not isinstance(data.get('accountId'),str) or not re.fullmatch('[A-Za-z0-9_-]{1,160}',data['accountId'])
                or data.get('platform') not in ('xiaohongshu','douyin')):
            fail('MEDIA_INPUT_INVALID','请选择当前门店、平台和内容账号')
        owner=self.owner
        with owner.lock:
            user,profile=owner._identity(token);stores=owner._stores(profile)
            store=owner._load_selection(user,stores)['storeId']
            if store!=data['storeId']:fail('MEDIA_SCOPE_CHANGED','门店已变化，请重新读取视频制作')
            account=owner.core.store.get('accounts',data['accountId'])
            if (not isinstance(account,dict) or account.get('tenant_id')!=user['tenant_id']
                    or account.get('cloud_owner')!=user['username'] or account.get('store_id')!=store
                    or account.get('platform')!=data['platform']):fail('MEDIA_ACCOUNT_FORBIDDEN','此账号不属于当前员工和门店')
            owner.core._account_access(user,account);binding=account_digest(account)
        state={'stores':stores,'error':None}
        def authority(db,actor,scope,save):
            if state['error'] is not None:raise state['error']
            session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
            row=db.execute("SELECT body FROM records WHERE entity='accounts' AND id=? AND tenant_id=?",(scope.account_id,scope.tenant_id)).fetchone()
            return (not owner.closed and session is not None and session['user_id']==actor['id']
                and owner._load_selection(actor,state['stores'],db)['storeId']==scope.store_id
                and row is not None and account_digest(json.loads(row['body']))==binding)
        def fresh():
            # Called after FFmpeg, outside SQLite. A central revocation cannot
            # install output merely because the original local token still exists.
            try:
                with owner.lock:
                    actor,profile=owner._identity(token);rows=owner._stores(profile)
                    if (owner.closed or any(actor.get(k)!=user.get(k) for k in ('id','tenant_id','username','role'))
                            or store not in {r['id'] for r in rows}
                            or owner._load_selection(actor,rows)['storeId']!=store):
                        fail('MEDIA_SCOPE_CHANGED','员工或门店权限已变化，成片未采用')
                    state['stores']=rows
            except Exception as error:state['error']=error;raise
        return user,store,{k:deepcopy(v) for k,v in data.items() if k!='storeId'},authority,fresh,binding

    def service(self,user,data,token,fresh):
        key=(user['id'],hashlib.sha256(token.encode()).hexdigest(),data['accountId'],data['platform'])
        with self.lock:
            if key not in self.services:
                component=self.owner._content_component();scope_type=sys.modules[component.__module__].ContentScope
                class BoundContent(component):
                    def _workspace(inner,db,scope,actor):
                        row=super()._workspace(db,scope,actor)
                        account=db.execute("SELECT body FROM records WHERE entity='accounts' AND id=? AND tenant_id=?",(scope.account_id,scope.tenant_id)).fetchone()
                        row['_mediaAccountDigest']=account_digest(json.loads(account['body'])) if account else None
                        return row
                class BoundProduction(MediaProduction):
                    def _source(inner,row,task_id):return digest([super()._source(row,task_id),row['_mediaAccountDigest']])
                    def output(inner,actor,store,data,authority):
                        scope=inner._scope(actor,store,data)
                        with inner.store.connect() as db:
                            saved,row=inner._authority(db,actor,scope,authority,False)
                            job=inner._record(db,JOBS,data['jobId'],scope,saved)
                            if inner._source(row,job['taskId'])!=job['sourceTaskDigest']:fail('MEDIA_SOURCE_CHANGED','原账号或制作依据已变化，请保留原任务核对')
                        return super().output(actor,store,data,authority)
                self.checked_directory(self.root);self.checked_directory(self.ingest)
                service=BoundProduction(BoundContent(self.owner.core.store),scope_type,self.root,self.ingest,installed_tools())
                render=service.engine.render
                def checked_render(folder,snapshot,control,progress):
                    def checked_control():control();self.storage_limit()
                    result=render(folder,snapshot,checked_control,progress);service._render_fresh();return result
                service._render_fresh=fresh
                service.engine.render=checked_render;self.services[key]=service
            return self.services[key]

    @staticmethod
    def upload_view(row):return {k:deepcopy(row[k]) for k in ('id','requestId','name','bytes','sha256','offset','state','asset','createdAt') if k in row}
    def storage_limit(self,additional=0):
        self.checked_directory(self.root)
        total=0;count=0
        if self.root.exists():
            for path in self.root.rglob('*'):
                if path.is_symlink() or getattr(path.lstat(),'st_file_attributes',0)&0x400:fail('MEDIA_PATH_DENIED','媒体目录不能含链接')
                if path.is_file():total+=path.stat().st_size;count+=1
                if count>10000 or total+additional>1073741824:fail('MEDIA_CAPACITY','本机视频空间已满，请联系管理员整理后继续')
        if total+additional>1073741824:fail('MEDIA_CAPACITY','本机视频空间已满，请联系管理员整理后继续')
        if shutil.disk_usage(self.owner.data_dir).free<additional+67108864:fail('MEDIA_DISK_SPACE','电脑可用空间不足，请整理磁盘后继续')

    def dispatch(self,action,data,token):
        if action in ('media_services_status', 'media_ocr_preview', 'media_speech_preview', 'media_speech_cancel', 'media_speech_save', 'media_speech_read'):
            with self.lock:
                if not getattr(self,'windows_services',None):
                    from .windows_media_services import MediaServices
                    self.windows_services=MediaServices(self)
                service=self.windows_services
            return service.dispatch(action,data,token)
        user,store,request,authority,fresh,binding=self.context(token,data)
        if action=='media_status':
            exact(request,{'accountId','platform'})
            try:tools=installed_tools();available=True;message='已核验电脑现有 FFmpeg · 普通电脑模式';details=tools.verify()
            except MediaError as error:available=False;message=str(error);details=None
            if not available:return {'actor':self.actor(user,store,request),'result':{'available':False,'message':message,'assets':[],'jobs':[]}}
        service=self.service(user,request,token,fresh)
        scope=service._scope(user,store,request)
        if action=='media_status':
            with service.store.connect() as db:
                actor,_=service._authority(db,user,scope,authority,False);assets=[];jobs=[]
                for entity,dest in ((ASSETS,assets),(JOBS,jobs)):
                    for raw in db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=?',(entity,scope.tenant_id)):
                        row=json.loads(raw['body'])
                        if row.get('scope')==scope.checked() and row.get('actorId')==actor['id']:
                            row=service._record(db,entity,row['id'],scope,actor)
                            dest.append(service._asset_view(row) if entity==ASSETS else service._public(row))
                result={'available':True,'message':message,'tools':details,'assets':assets[-64:],'jobs':jobs[-32:]}
        elif action.startswith('media_upload_'):
            result=self.upload(service,user,store,request,authority,action)
        else:
            method={'media_prepare':'prepare','media_read':'read','media_preview':'preview','media_start':'start',
                'media_cancel':'cancel','media_recover':'recover','media_request':'query_request'}.get(action)
            if method is None:fail('MEDIA_ACTION_FORBIDDEN','视频制作操作未开放')
            if method in ('prepare','start'):self.storage_limit()
            if method=='prepare':
                with service.store.connect() as db:
                    count=sum(1 for raw in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(JOBS,scope.tenant_id))
                        if json.loads(raw['body']).get('scope')==scope.checked())
                    if count>=32:
                        prior=service.query_request(user,store,{k:request[k] for k in ('accountId','platform','requestId')},authority)
                        if prior['state']!='recorded':fail('MEDIA_CAPACITY','当前账号已有 32 条制作记录，请联系管理员整理')
            if method=='start':service._render_fresh=fresh
            result=getattr(service,method)(user,store,request,authority)
        return {'actor':self.actor(user,store,request),'result':result}
    @staticmethod
    def actor(user,store,data):return dict(username=user['username'],storeId=store,accountId=data['accountId'],platform=data['platform'])

    def upload(self,service,user,store,data,authority,action):
        scope=service._scope(user,store,data);base={'accountId','platform'}
        if action=='media_upload_begin':
            exact(data,base|{'requestId','name','bytes','sha256','rightsConfirmed','rightsNote','source'})
            ident(data['requestId']);name=data['name'];size=data['bytes'];sha=data['sha256']
            if not isinstance(name,str) or not 1<=len(name)<=80 or '/' in name or '\\' in name:fail('MEDIA_INPUT_INVALID','请选择本地视频、SRT 或文字脚本')
            ext=Path(name).suffix.lower()
            limit=65536 if ext in ('.srt','.txt') else 67108864 if ext in ('.mp4','.mov') else 0
            if type(size) is not int or not 1<=size<=limit or not isinstance(sha,str) or not re.fullmatch('[0-9a-f]{64}',sha):fail('MEDIA_LIMIT','视频限 64MB，SRT/文字限 64KB；格式或摘要无效')
            if data['rightsConfirmed'] is not True or data['source'] not in ('authorized_real','synthetic_test','generated_concept') or not isinstance(data['rightsNote'],str) or not 1<=len(data['rightsNote'].strip())<=300:fail('MEDIA_RIGHTS_REQUIRED','请说明素材来源并确认有权使用')
            self.storage_limit()
            with service.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');actor,_=service._authority(db,user,scope,authority,True)
                key=digest(['upload',scope.checked(),actor['id'],data['requestId']]);old=service._get(db,UPLOADS,key,scope)
                if old:
                    if old.get('requestDigest')!=digest(data):fail('MEDIA_REQUEST_CONFLICT','原上传编号对应其他内容，请核对原上传')
                    return self.upload_view(service._record(db,UPLOADS,key,scope,actor))
                reserved=0;asset_bytes=0;owner_bytes=0;asset_count=0;global_reserved=0
                for raw in db.execute('SELECT entity,body FROM records WHERE tenant_id=? AND entity IN (?,?)',(scope.tenant_id,UPLOADS,ASSETS)):
                    item=json.loads(raw['body'])
                    if raw['entity']==UPLOADS and item.get('state') in ('uploading','importing'):
                        global_reserved+=max(0,item.get('bytes',0)-item.get('offset',0))+item.get('bytes',0)
                    if item.get('actorId')!=actor['id']:continue
                    if raw['entity']==ASSETS:
                        owner_bytes+=item.get('bytes',0)
                        if item.get('scope')==scope.checked():asset_bytes+=item.get('bytes',0);asset_count+=1
                    elif item.get('state') in ('uploading','importing'):
                        owner_bytes+=item.get('bytes',0)
                        if item.get('scope')==scope.checked():reserved+=item.get('bytes',0)
                if reserved+size>134217728 or asset_bytes+reserved+size>268435456 or owner_bytes+size>536870912 or asset_count>=64:fail('MEDIA_CAPACITY','当前账号素材容量已满，请联系管理员整理')
                self.storage_limit(global_reserved+size*2)
                folder=self.checked_directory(service._ingest_directory(scope,actor),create=True);ref=uuid.uuid4().hex+ext
                with (folder/ref).open('xb'):pass
                row={'id':key,'tenant_id':scope.tenant_id,'scope':scope.checked(),'actorId':actor['id'],'owner':actor['username'],
                    **{k:data[k] for k in ('requestId','name','bytes','sha256','rightsConfirmed','rightsNote','source')},'requestDigest':digest(data),
                    'ref':ref,'offset':0,'state':'uploading','createdAt':now()}
                service._put(db,UPLOADS,row);service._commit(db);return self.upload_view(row)
        keys={'media_upload_read':{'uploadId'},'media_upload_chunk':{'uploadId','offset','chunk','sha256'},
            'media_upload_complete':{'uploadId'},'media_upload_cancel':{'uploadId'}}
        by_request=action=='media_upload_read' and set(data)==base|{'requestId'}
        exact(data,base|({'requestId'} if by_request else keys[action]))
        chunk=None
        if action=='media_upload_chunk':
            if type(data['offset']) is not int or data['offset']<0 or not isinstance(data['chunk'],str) or len(data['chunk'])>87384:fail('MEDIA_CHUNK_INVALID','上传分块无效')
            try:chunk=base64.b64decode(data['chunk'],validate=True)
            except (ValueError,TypeError):fail('MEDIA_CHUNK_INVALID','上传分块编码无效')
            if not 1<=len(chunk)<=CHUNK or hashlib.sha256(chunk).hexdigest()!=data['sha256']:fail('MEDIA_CHUNK_INVALID','上传分块摘要不一致')
        with service.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,_=service._authority(db,user,scope,authority,action!='media_upload_read')
            if by_request:
                key=digest(['upload',scope.checked(),actor['id'],ident(data['requestId'])]);row=service._get(db,UPLOADS,key,scope)
                if row is None:return {'state':'not_found','requestId':data['requestId'],'newUploadDispatched':False}
                return self.upload_view(service._record(db,UPLOADS,key,scope,actor))
            row=service._record(db,UPLOADS,data['uploadId'],scope,actor);folder=service._ingest_directory(scope,actor);path=folder/row['ref']
            if action=='media_upload_read':return self.upload_view(row)
            if action=='media_upload_cancel':
                if row['state']=='complete':fail('MEDIA_UPLOAD_COMPLETE','素材已导入，不能取消原上传')
                row['state']='cancelled';service._put(db,UPLOADS,row);service._commit(db)
                if path.exists():checked_upload(path,folder);path.unlink()
                return self.upload_view(row)
            if action=='media_upload_chunk':
                if row['state']!='uploading':fail('MEDIA_UPLOAD_STATE','请读取原上传状态')
                signature=[data['offset'],len(chunk),data['sha256']]
                if row.get('lastChunk')==signature:return self.upload_view(row)
                if data['offset']!=row['offset'] or row['offset']+len(chunk)>row['bytes']:fail('MEDIA_UPLOAD_OFFSET','上传位置已变化，请读取原上传后继续')
                checked_upload(path,folder)
                with path.open('r+b') as stream:
                    stream.truncate(row['offset']);stream.seek(row['offset']);stream.write(chunk);stream.flush();os.fsync(stream.fileno())
                row['offset']+=len(chunk);row['lastChunk']=signature;service._put(db,UPLOADS,row);service._commit(db);return self.upload_view(row)
            if row['state']=='complete':return self.upload_view(row)
            if row['state'] not in ('uploading','importing') or row['offset']!=row['bytes']:fail('MEDIA_UPLOAD_INCOMPLETE','请先完成原素材上传')
            raw=checked_file(path,folder,67108864)
            if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:fail('MEDIA_INPUT_CHANGED','完整素材摘要不一致，请重新选择原文件')
            row['state']='importing';service._put(db,UPLOADS,row);service._commit(db)
        asset=service.import_asset(user,store,{**{k:data[k] for k in base},'uploadRef':row['ref'],'requestId':'import-'+row['id'],
            **{k:row[k] for k in ('name','rightsConfirmed','rightsNote','source')}},authority)
        with service.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');actor,_=service._authority(db,user,scope,authority,True)
            row=service._record(db,UPLOADS,row['id'],scope,actor);row.update(state='complete',asset=asset)
            service._put(db,UPLOADS,row);service._commit(db)
        # Once the durable complete receipt exists, the checked private staging
        # file is redundant. Keep original user files and adopted assets intact.
        if path.exists():
            checked_file(path,folder,67108864);path.unlink()
        return self.upload_view(row)

    def video(self,token,data,range_header=''):
        exact(data,{'storeId','accountId','platform','jobId','download'})
        if data['download'] not in ('0','1'):fail('MEDIA_INPUT_INVALID','视频读取方式无效')
        user,store,request,authority,fresh,_=self.context(token,data)
        service=self.service(user,request,token,fresh)
        raw,info=service.output(user,store,{k:request[k] for k in ('accountId','platform','jobId')},authority)
        total=len(raw);headers={'Accept-Ranges':'bytes','Content-Disposition':('attachment' if data['download']=='1' else 'inline')+'; filename="video.mp4"'}
        if range_header:
            match=re.fullmatch(r'bytes=(\d+)-(\d*)',range_header)
            if not match:return 416,b'',{'Content-Range':'bytes */'+str(total)}
            if match[2] and int(match[2])-int(match[1])+1>4194304:return 416,b'',{'Content-Range':'bytes */'+str(total)}
            start=int(match[1]);end=min(int(match[2]) if match[2] else start+4194303,total-1)
            if start>=total or end<start or end-start+1>4194304:return 416,b'',{'Content-Range':'bytes */'+str(total)}
            headers['Content-Range']=f'bytes {start}-{end}/{total}';return 206,raw[start:end+1],headers
        return 200,raw,headers
