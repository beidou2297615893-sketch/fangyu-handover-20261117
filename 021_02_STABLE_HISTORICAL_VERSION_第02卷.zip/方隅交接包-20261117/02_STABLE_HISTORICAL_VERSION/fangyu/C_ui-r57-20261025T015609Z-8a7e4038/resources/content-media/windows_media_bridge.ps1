﻿$ErrorActionPreference='Stop'
[Console]::InputEncoding=[Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$p=ConvertFrom-Json ([Console]::In.ReadToEnd())
function VoiceKey($id) { $hash=[Security.Cryptography.SHA256]::Create();try{return (-join ($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($id))|ForEach-Object{$_.ToString('x2')})).Substring(0,24)}finally{$hash.Dispose()} }
function Voices($voice) {return @($voice.GetVoices()|Where-Object { $_.Id -match '\\TTS_MS_(ZH-CN_HUIHUI|EN-US_ZIRA|EN-US_DAVID)_11\.0$' })}
function VoiceLanguage($token) {if($token.Id -match 'ZH-CN_HUIHUI'){return 'zh-CN'};return 'en-US'}
function OcrTypes {
 Add-Type -AssemblyName System.Runtime.WindowsRuntime
 [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]|Out-Null
 [Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]|Out-Null
 [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]|Out-Null
 [Windows.Storage.Streams.IRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]|Out-Null
 [Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]|Out-Null
 [Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]|Out-Null
}
try {
 if($p.operation -eq 'capabilities') {
  $languages=@();$voices=@()
  try{OcrTypes;$languages=@([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages|ForEach-Object{@{id=$_.LanguageTag;name=$_.DisplayName}})}catch{}
  try{$voice=New-Object -ComObject SAPI.SpVoice;$voices=@(Voices $voice|ForEach-Object{@{id=(VoiceKey $_.Id);name=$_.GetDescription();language=(VoiceLanguage $_);version='Windows Desktop SAPI 11.0'}});[void][Runtime.InteropServices.Marshal]::ReleaseComObject($voice)}catch{}
  $result=@{status='ok';ocrLanguages=$languages;voices=$voices;systemProvided=$true;downloads=$false}
 } elseif($p.operation -eq 'ocr') {
  OcrTypes
  $asTask=([System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'})[0]
  function Await($operation,$type){$task=$asTask.MakeGenericMethod($type).Invoke($null,@($operation));[void]$task.Wait();return $task.Result}
  $languages=@([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages)
  $language=@($languages|Where-Object{$_.LanguageTag -eq 'zh-Hans-CN'})[0]
  if($null -eq $language){$language=$languages|Select-Object -First 1}
  if($null -eq $language){throw 'OCR_LANGUAGE_UNAVAILABLE'}
  $file=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($p.inputFile)) ([Windows.Storage.StorageFile])
  $stream=Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  try{
   $decoder=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
   $bitmap=Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
   try{$engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language);$recognized=Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult]);$result=@{status='ok';language=$engine.RecognizerLanguage.LanguageTag;lines=@($recognized.Lines|ForEach-Object{$_.Text});width=$bitmap.PixelWidth;height=$bitmap.PixelHeight}}finally{$bitmap.Dispose()}
  }finally{$stream.Dispose()}
 } elseif($p.operation -eq 'tts') {
  $voice=New-Object -ComObject SAPI.SpVoice
  try{
   $token=@(Voices $voice|Where-Object{(VoiceKey $_.Id) -eq $p.voiceId})[0]
   if($null -eq $token){throw 'VOICE_UNAVAILABLE'}
   $voice.Voice=$token;$voice.Rate=[int]$p.rate;$voice.Volume=90
   $audio=New-Object -ComObject SAPI.SpFileStream
   try{$audio.Format.Type=18;$audio.Open($p.outputFile,3,$false);$voice.AudioOutputStream=$audio;[void]$voice.Speak([string]$p.text,16);$audio.Close()}finally{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($audio)}
   $result=@{status='ok';voiceId=$p.voiceId;voiceName=$token.GetDescription();voiceLanguage=(VoiceLanguage $token);voiceVersion='Windows Desktop SAPI 11.0';systemVersion=[Environment]::OSVersion.VersionString;literalTextOnly=$true}
  }finally{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($voice)}
 } else {throw 'OPERATION_INVALID'}
 [Console]::Out.WriteLine(($result|ConvertTo-Json -Depth 8 -Compress))
} catch {
 [Console]::Out.WriteLine((@{status='unavailable';code='WINDOWS_MEDIA_UNAVAILABLE';type=$_.Exception.GetType().Name}|ConvertTo-Json -Compress))
 exit 1
}
