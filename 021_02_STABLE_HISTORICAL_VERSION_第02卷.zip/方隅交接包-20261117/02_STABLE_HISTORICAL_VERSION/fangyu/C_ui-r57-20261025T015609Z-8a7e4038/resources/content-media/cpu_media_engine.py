"""Bounded CPU-only FFmpeg adapter; no codecs, fonts or models are bundled."""
from pathlib import Path
from dataclasses import dataclass
import ctypes,hashlib,json,math,os,queue,re,stat,subprocess,threading,time
from PIL import Image,ImageDraw,ImageFont

class MediaError(ValueError):
    def __init__(self,code,message,*,mutation_committed=False):
        super().__init__(message);self.code=code;self.status=409;self.mutation_committed=mutation_committed
def fail(code,message):raise MediaError(code,message)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def checked_file(path,root=None,maximum=67108864,*,allow_hardlinks=False):
    path=Path(path).absolute()
    if root is not None and not path.is_relative_to(Path(root).absolute()):fail('MEDIA_PATH_DENIED','素材位置不在授权暂存区')
    for part in (path,*path.parents):
        info=part.lstat()
        if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:fail('MEDIA_PATH_DENIED','素材路径不能是链接')
    before=path.stat()
    if not stat.S_ISREG(before.st_mode) or not allow_hardlinks and before.st_nlink!=1 or not 0<before.st_size<=maximum:fail('MEDIA_INPUT_INVALID','素材文件类型或大小无效')
    raw=path.read_bytes();after=path.stat()
    if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):fail('MEDIA_INPUT_CHANGED','素材正在变化，请重新导入')
    return raw

class Lease:
    """OS byte-range lock: reopening cannot mistake another live renderer for dead."""
    def __init__(self,path):
        self.stream=open(path,'a+b');self.stream.seek(0,2)
        if not self.stream.tell():self.stream.write(b'0');self.stream.flush()
        self.stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:self.stream.close();raise
    def close(self):
        if self.stream.closed:return
        self.stream.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(self.stream.fileno(),msvcrt.LK_UNLCK,1)
        self.stream.close()

class LeaseSet:
    def __init__(self,*paths):
        self.leases=[]
        try:
            for path in paths:self.leases.append(Lease(path))
        except Exception:self.close();raise
    def close(self):
        for lease in reversed(self.leases):lease.close()
        self.leases=[]

class _WindowsJob:
    """Kill only the owned child if this application dies; cap child memory."""
    def __init__(self,process):
        self.handle=None
        if os.name!='nt':return
        from ctypes import wintypes as wt
        class BASIC(ctypes.Structure):
            _fields_=[('PerProcessUserTimeLimit',ctypes.c_longlong),('PerJobUserTimeLimit',ctypes.c_longlong),
                ('LimitFlags',wt.DWORD),('MinimumWorkingSetSize',ctypes.c_size_t),('MaximumWorkingSetSize',ctypes.c_size_t),
                ('ActiveProcessLimit',wt.DWORD),('Affinity',ctypes.c_size_t),('PriorityClass',wt.DWORD),('SchedulingClass',wt.DWORD)]
        class IO(ctypes.Structure):_fields_=[(name,ctypes.c_ulonglong) for name in ('ReadOperationCount','WriteOperationCount','OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount')]
        class LIMIT(ctypes.Structure):_fields_=[('BasicLimitInformation',BASIC),('IoInfo',IO),('ProcessMemoryLimit',ctypes.c_size_t),('JobMemoryLimit',ctypes.c_size_t),('PeakProcessMemoryUsed',ctypes.c_size_t),('PeakJobMemoryUsed',ctypes.c_size_t)]
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.CreateJobObjectW.argtypes=[ctypes.c_void_p,wt.LPCWSTR];kernel.CreateJobObjectW.restype=wt.HANDLE
        kernel.SetInformationJobObject.argtypes=[wt.HANDLE,ctypes.c_int,ctypes.c_void_p,wt.DWORD];kernel.SetInformationJobObject.restype=wt.BOOL
        kernel.AssignProcessToJobObject.argtypes=[wt.HANDLE,wt.HANDLE];kernel.AssignProcessToJobObject.restype=wt.BOOL
        kernel.CloseHandle.argtypes=[wt.HANDLE];kernel.CloseHandle.restype=wt.BOOL
        handle=kernel.CreateJobObjectW(None,None)
        if not handle:fail('MEDIA_CPU_GUARD_UNAVAILABLE','无法建立受控媒体进程')
        limits=LIMIT();limits.BasicLimitInformation.LimitFlags=0x2000|0x100;limits.ProcessMemoryLimit=1024*1024*1024
        if not kernel.SetInformationJobObject(handle,9,ctypes.byref(limits),ctypes.sizeof(limits)) or not kernel.AssignProcessToJobObject(handle,wt.HANDLE(process._handle)):
            kernel.CloseHandle(handle);fail('MEDIA_CPU_GUARD_UNAVAILABLE','无法约束媒体进程，未继续渲染')
        self.kernel,self.handle=kernel,handle
    def close(self):
        if self.handle:self.kernel.CloseHandle(self.handle);self.handle=None

@dataclass(frozen=True)
class Tools:
    ffmpeg:Path
    ffprobe:Path
    font:Path
    ffmpeg_sha:str
    ffprobe_sha:str
    font_sha:str
    def verify(self):
        for path,want in ((self.ffmpeg,self.ffmpeg_sha),(self.ffprobe,self.ffprobe_sha),(self.font,self.font_sha)):
            try:raw=checked_file(path,maximum=268435456,allow_hardlinks=True)
            except OSError:fail('MEDIA_TOOL_UNAVAILABLE','本机媒体工具或字体尚未安装，请先核验本机工具')
            if not re.fullmatch('[a-f0-9]{64}',want) or hashlib.sha256(raw).hexdigest()!=want:
                fail('MEDIA_TOOL_CHANGED','本机媒体工具已变化，需要重新核验')
        return {'ffmpeg':self.ffmpeg_sha,'ffprobe':self.ffprobe_sha,'font':self.font_sha,
                'rendererVersion':'cpu-media-candidate-v1','threads':2,'width':720,'height':1280,'fps':30}

class CpuMediaEngine:
    def __init__(self,tools):self.tools=tools
    def run(self,args,cwd,*,control=lambda:None,progress=lambda value:None,timeout=180):
        # A cancelled/revoked original job must not dispatch another process.
        control()
        process=subprocess.Popen(list(map(str,args)),executable=str(args[0]),cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0,shell=False)
        job=None;lines=queue.Queue();errors=[]
        try:
            job=_WindowsJob(process)
            def read_out():
                for raw in process.stdout:lines.put(raw)
            def read_error():
                for raw in process.stderr:
                    if len(errors)<20:errors.append(raw[-500:])
            readers=[threading.Thread(target=read_out,daemon=True),threading.Thread(target=read_error,daemon=True)]
            for thread in readers:thread.start()
            began=time.monotonic()
            while process.poll() is None:
                control()
                if time.monotonic()-began>timeout:fail('MEDIA_TIMEOUT','媒体处理超时，原素材已保留')
                while not lines.empty():
                    line=lines.get().decode('utf-8','replace').strip()
                    if line.startswith('out_time_us='):
                        try:progress(int(line.partition('=')[2])/1000000)
                        except ValueError:pass
                time.sleep(0.05)
            for thread in readers:thread.join(timeout=1)
            control()
            if process.returncode:fail('MEDIA_TOOL_FAILED','媒体处理未完成，请核对素材格式')
        finally:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=2)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=2)
            if job:job.close()
            if process.stdout:process.stdout.close()
            if process.stderr:process.stderr.close()
    def probe(self,path):
        result=subprocess.run([str(self.tools.ffprobe),'-v','error','-max_alloc','268435456','-protocol_whitelist','file,pipe',
            '-format_whitelist','mov','-enable_drefs','0','-show_streams','-show_format','-of','json',str(path)],
            executable=str(self.tools.ffprobe),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,shell=False,timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        if result.returncode or len(result.stdout)>131072:fail('MEDIA_FORMAT_INVALID','无法读取本地视频格式')
        try:
            info=json.loads(result.stdout);video=next(s for s in info['streams'] if s['codec_type']=='video')
            duration=float(info['format']['duration']);width,height=int(video['width']),int(video['height'])
            if not math.isfinite(duration) or not 0<duration<=300 or not 0<width<=4096 or not 0<height<=4096:raise ValueError()
            if info['format']['format_name'] not in ('mov,mp4,m4a,3gp,3g2,mj2',):raise ValueError()
            return {'durationMs':round(duration*1000),'width':width,'height':height,
                    'hasAudio':any(s.get('codec_type')=='audio' for s in info['streams'])}
        except (ValueError,KeyError,TypeError,StopIteration):fail('MEDIA_FORMAT_INVALID','仅接收 5 分钟以内、4K 以内的 MP4/MOV 视频')
    @staticmethod
    def captions(raw,total_ms):
        try:source=raw.decode('utf-8-sig')
        except UnicodeError:fail('MEDIA_SUBTITLE_INVALID','字幕须为 UTF-8 SRT')
        cues=[]
        def ms(value):
            h,m,s,f=map(int,re.split('[:,]',value));return ((h*60+m)*60+s)*1000+f
        for block in re.split(r'\r?\n\s*\r?\n',source.strip()):
            rows=block.splitlines()
            if len(rows)<3 or not rows[0].isdigit():fail('MEDIA_SUBTITLE_INVALID','请提供编号、时间和正文齐全的 SRT')
            match=re.fullmatch(r'(\d\d:[0-5]\d:[0-5]\d,\d{3}) --> (\d\d:[0-5]\d:[0-5]\d,\d{3})',rows[1])
            if not match:fail('MEDIA_SUBTITLE_INVALID','字幕时间格式无效')
            start,end=map(ms,match.groups());body='\n'.join(rows[2:])
            if not 0<=start<end<=total_ms or start<(cues[-1]['endMs'] if cues else 0) or len(body)>120 or not body.strip() or any(ord(c)<32 and c not in '\n\t' for c in body):
                fail('MEDIA_SUBTITLE_INVALID','字幕需在成片时长内且不能重叠，每条至多 120 字')
            cues.append({'startMs':start,'endMs':end,'text':body})
        if not 1<=len(cues)<=30:fail('MEDIA_SUBTITLE_INVALID','每条短片支持 1—30 条字幕')
        return cues
    @staticmethod
    def script_captions(raw,total_ms):
        try:source=raw.decode('utf-8-sig')
        except UnicodeError:fail('MEDIA_SUBTITLE_INVALID','文字脚本须为 UTF-8')
        lines=[line.strip() for line in source.splitlines() if line.strip()]
        if not 1<=len(lines)<=30 or any(len(line)>120 or any(ord(c)<32 for c in line) for line in lines):
            fail('MEDIA_SUBTITLE_INVALID','脚本每行作为一条字幕，限 1—30 行，每行至多 120 字')
        return [{'startMs':round(i*total_ms/len(lines)),'endMs':round((i+1)*total_ms/len(lines)),'text':line} for i,line in enumerate(lines)]
    def render(self,folder,snapshot,control,progress):
        folder=Path(folder);args=[self.tools.ffmpeg,'-hide_banner','-loglevel','error','-nostdin','-y',
            '-filter_threads','1','-filter_complex_threads','1']
        filters=[]
        for i,clip in enumerate(snapshot['clips']):
            args+=['-protocol_whitelist','file,pipe','-format_whitelist','mov','-enable_drefs','0','-hwaccel','none','-threads','2',
                   '-ss',str(clip['startMs']/1000),'-t',str((clip['endMs']-clip['startMs'])/1000),'-i',f'clip{i}.mp4']
            filters.append(f'[{i}:v]scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,setpts=PTS-STARTPTS[v{i}]')
            if snapshot['audio']=='keep_source':filters.append(f'[{i}:a]aresample=48000,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a{i}]')
        count=len(snapshot['clips']);audio=snapshot['audio']=='keep_source'
        sources=''.join(f'[v{i}]'+(f'[a{i}]' if audio else '') for i in range(count))
        filters.append(sources+f'concat=n={count}:v=1:a={1 if audio else 0}[base]'+('[aud]' if audio else ''))
        previous='base';font=ImageFont.truetype(str(self.tools.font),30)
        for i,cue in enumerate(snapshot['captions']):
            image=Image.new('RGBA',(720,220));draw=ImageDraw.Draw(image)
            lines=[]
            for paragraph in cue['text'].splitlines():
                line=''
                for char in paragraph:
                    if draw.textlength(line+char,font=font)>640:lines.append(line);line=char
                    else:line+=char
                if line:lines.append(line)
            if len(lines)>4:fail('MEDIA_SUBTITLE_INVALID','字幕过长，请分为更多时间段')
            draw.rounded_rectangle((22,10,698,210),radius=18,fill=(4,36,50,232))
            for j,line in enumerate(lines):draw.text(((720-draw.textlength(line,font=font))/2,100-len(lines)*20+j*40),line,font=font,fill='white')
            image.save(folder/f'caption{i}.png');args+=['-protocol_whitelist','file,pipe','-threads','1','-i',f'caption{i}.png']
            out=f'sub{i}';filters.append(f'[{previous}][{count+i}:v]overlay=0:950:enable=\'between(t,{cue["startMs"]/1000},{cue["endMs"]/1000})\'[{out}]');previous=out
        args+=['-filter_complex',';'.join(filters),'-map',f'[{previous}]']
        args+=['-map','[aud]','-c:a','aac','-b:a','128k'] if audio else ['-an']
        args+=['-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-r','30','-threads','2',
               '-t',str(snapshot['durationMs']/1000),'-movflags','+faststart','-progress','pipe:1','-nostats','result.partial.mp4']
        self.run(args,folder,control=control,progress=progress,timeout=min(240,30+snapshot['durationMs']/1000*3))
        output=folder/'result.partial.mp4';control();info=self.probe(output)
        if (info['width'],info['height'])!=(720,1280) or abs(info['durationMs']-snapshot['durationMs'])>100:fail('MEDIA_OUTPUT_INVALID','成片尺寸或时长未通过核对')
        self.run([self.tools.ffmpeg,'-hide_banner','-loglevel','error','-nostdin','-protocol_whitelist','file,pipe','-i','result.partial.mp4','-threads','2','-f','null','-'],folder,control=control,timeout=60)
        return output,info
