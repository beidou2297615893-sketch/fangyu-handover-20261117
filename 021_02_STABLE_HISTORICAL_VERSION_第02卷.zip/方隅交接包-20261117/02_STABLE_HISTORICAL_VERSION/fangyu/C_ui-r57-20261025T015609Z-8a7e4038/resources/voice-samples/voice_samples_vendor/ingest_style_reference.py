#!/usr/bin/env python3
"""Ingest a user's own note, caption, or script into the local style library."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_ROOT = Path.home() / ".xhs" / "style-library"


def slugify(text: str) -> str:
    cleaned = re.sub(r"[^\w\-]+", "-", text.strip().lower(), flags=re.UNICODE)
    cleaned = re.sub(r"-+", "-", cleaned).strip("-")
    return cleaned[:48] or "ref"


def load_text(path: str) -> str:
    if path == "-":
        return sys.stdin.read()
    return Path(path).read_text(encoding="utf-8")


def split_title_body(raw: str, title: str | None) -> tuple[str, str]:
    text = raw.strip()
    if title:
        return title.strip(), text

    lines = [line.rstrip() for line in text.splitlines()]
    non_empty = [line for line in lines if line.strip()]
    if not non_empty:
        return "", ""

    first = non_empty[0].strip()
    if first.startswith("#"):
        parsed_title = first.lstrip("#").strip()
        body = "\n".join(non_empty[1:]).strip()
        return parsed_title, body

    if len(first) <= 24 and len(non_empty) > 1:
        return first, "\n".join(non_empty[1:]).strip()

    return first[:24], text


def ensure_layout(root: Path, fmt: str) -> Path:
    (root / "carousel").mkdir(parents=True, exist_ok=True)
    (root / "video").mkdir(parents=True, exist_ok=True)
    index_path = root / "index.json"
    if not index_path.exists():
        index_path.write_text(json.dumps({"references": []}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return root / fmt


def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest user style reference into ~/.xhs/style-library/")
    parser.add_argument("input", nargs="?", help="UTF-8 file path or '-' for stdin")
    parser.add_argument("--file", dest="file", help="Same as the positional argument")
    parser.add_argument("--format", choices=["carousel", "video", "image"], required=True)
    parser.add_argument("--label", default="", help="Human label, e.g. 我的干货风")
    parser.add_argument("--title", default="", help="Optional title override")
    parser.add_argument("--id", default="", help="Optional stable id")
    parser.add_argument("--notes", default="", help="Optional note about this reference")
    parser.add_argument("--root", default=str(DEFAULT_ROOT), help="Style library root")
    args = parser.parse_args()

    source = args.file or args.input
    if not source:
        parser.error("Provide an input path, '--file <path>', or '-' for stdin.")

    fmt = "carousel" if args.format == "image" else args.format
    raw = load_text(source)
    if not raw.strip():
        sys.exit("Input is empty.")

    title, body = split_title_body(raw, args.title or None)
    ref_id = args.id or slugify(args.label or title or "reference")
    fmt_dir = ensure_layout(Path(args.root).expanduser(), fmt)
    record = {
        "id": ref_id,
        "format": fmt,
        "label": args.label or ref_id,
        "title": title,
        "body": body,
        "source_type": "user_upload",
        "tags": [],
        "notes": args.notes,
        "ingested_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
    }

    out_path = fmt_dir / f"{ref_id}.json"
    out_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    index_path = Path(args.root).expanduser() / "index.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    refs = [r for r in index.get("references", []) if r.get("id") != ref_id or r.get("format") != fmt]
    refs.append({"id": ref_id, "format": fmt, "label": record["label"], "path": str(out_path)})
    index["references"] = refs
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps({"saved": str(out_path), "record": record}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
