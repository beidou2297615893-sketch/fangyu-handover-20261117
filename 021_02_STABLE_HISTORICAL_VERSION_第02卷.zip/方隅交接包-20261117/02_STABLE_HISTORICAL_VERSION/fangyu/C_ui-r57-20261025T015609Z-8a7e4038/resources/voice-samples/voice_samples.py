"""Account-scoped voice references for existing SOPs; no model or delivery.

The checked-in MIT upstream parser is reused unchanged. Persistence adapts to
the product's Store transaction, rather than reading the upstream global home
directory or mixing this customer's references with the component library.
The HTTP caller still owns session/selected-store authorization.
"""
from copy import deepcopy
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import unicodedata

ENTITY = 'ui_reply_voice_samples_v1'
COMPANY = 'fangyu-apartment-client'
CONTRACT = 'fangyu-own-voice-samples-v1'
SOURCE = {'repo':'xintu1314/xhs-creator-suite',
          'commit':'babb659a96af4d8886b8f343ee8c3c3c32a66656',
          'license':'MIT', 'upstream':'xhs-note-writer/scripts/ingest_style_reference.py'}
PARSER_SHA = '3b20d9faee0669b503f6532ee71fcdcc9e481b45724b0acf6b5b6e7abb806c8a'
LICENSE_SHA = '96eb4018645eabca591866033cdccd1e2a9ac19dec3538a265328eeafa943c16'


class VoiceSampleError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.status = (403 if code in ('VOICE_FORBIDDEN','VOICE_ADMIN_REQUIRED','VOICE_ACCOUNT_CHANGED')
            else 409 if code in ('VOICE_RECORD_INVALID','VOICE_REVISION_CONFLICT','VOICE_SAMPLE_MISSING')
            else 503 if code == 'VOICE_COMPONENT_CHANGED' else 400)


def _fail(code, message):
    raise VoiceSampleError(code, message)


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
        separators=(',', ':'),allow_nan=False).encode()).hexdigest()


def _text(value, maximum, name, *, empty=False, multiline=False):
    if (not isinstance(value,str) or len(value)>maximum or not empty and not value.strip()
            or any(unicodedata.category(c) in ('Cf','Cs') or ord(c)<32 and
                (not multiline or c not in '\n\r\t') for c in value)):
        _fail('VOICE_INPUT_INVALID',name+'格式无效')
    return value


@dataclass(frozen=True)
class VoiceScope:
    tenant_id: str
    store_id: str
    account_id: str
    platform: str
    company_id: str = COMPANY

    def checked(self):
        if self.company_id != COMPANY or self.platform not in ('xiaohongshu','douyin'):
            _fail('VOICE_SCOPE_INVALID','口吻样本归属无效')
        for key in ('tenant_id','store_id','account_id'):
            value=getattr(self,key)
            if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',value):
                _fail('VOICE_SCOPE_INVALID','口吻样本归属无效')
        return asdict(self)


class VoiceSampleLibrary:
    def __init__(self, store, *, vendor_dir=None, authority_check=None):
        self.store = store
        self.authority_check = authority_check
        parser = (Path(vendor_dir) if vendor_dir is not None else
            Path(__file__).parent/'voice_samples_vendor')/'ingest_style_reference.py'
        if parser.is_symlink() or hashlib.sha256(parser.read_bytes()).hexdigest()!=PARSER_SHA:
            _fail('VOICE_COMPONENT_CHANGED','语气样本组件需要核对')
        license_file=parser.parent/'LICENSE-xintu.txt'
        if license_file.is_symlink() or hashlib.sha256(license_file.read_bytes()).hexdigest()!=LICENSE_SHA:
            _fail('VOICE_COMPONENT_CHANGED','语气样本组件许可需要核对')
        spec=importlib.util.spec_from_file_location('_fangyu_checked_voice_parser',parser)
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.parser=module

    def _authorized(self, db, user, scope, *, save=False):
        values=scope.checked()
        if not isinstance(user,dict) or user.get('tenant_id')!=scope.tenant_id:
            _fail('VOICE_FORBIDDEN','员工与口吻样本归属不一致')
        def get(entity, ident):
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (entity,ident,scope.tenant_id)).fetchone()
            return json.loads(found['body']) if found else None
        saved=get('users',user.get('id'))
        if (not isinstance(saved,dict) or saved.get('disabled') or saved.get('cloud_bound') is not True
                or any(saved.get(k)!=user.get(k) for k in ('id','username','role','tenant_id'))):
            _fail('VOICE_FORBIDDEN','员工身份已变化')
        if save and saved.get('role')!='admin':
            _fail('VOICE_ADMIN_REQUIRED','只有管理员可以维护账号语气样本')
        account=get('accounts',scope.account_id)
        if (not isinstance(account,dict) or account.get('platform')!=scope.platform
                or account.get('cloud_owner')!=saved.get('username')
                or account.get('store_id') not in (None,'',scope.store_id)):
            _fail('VOICE_ACCOUNT_CHANGED','发送账号或所属门店已变化')
        if self.authority_check is not None and self.authority_check(db,saved,scope,save) is not True:
            _fail('VOICE_FORBIDDEN','员工会话或当前门店已变化')
        return values,saved

    def _row(self,db,scope,owner):
        ident=_digest([CONTRACT,scope.checked(),owner])
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (ENTITY,ident,scope.tenant_id)).fetchone()
        try:row=json.loads(found['body']) if found else None
        except (TypeError,ValueError):_fail('VOICE_RECORD_INVALID','语气样本记录需要核对')
        if row is not None and (not isinstance(row,dict) or row.get('scope')!=scope.checked()
                or row.get('owner')!=owner or row.get('id')!=ident
                or type(row.get('revision')) is not int or row['revision']<1
                or not isinstance(row.get('samples'),list) or len(row['samples'])>30):
            _fail('VOICE_RECORD_INVALID','语气样本记录归属或版本需要核对')
        if row is not None:
            seen=set()
            for sample in row['samples']:
                if (not isinstance(sample,dict) or not isinstance(sample.get('id'),str)
                        or not re.fullmatch(r'[a-f0-9]{32}',sample['id']) or sample['id'] in seen
                        or any(not isinstance(sample.get(k),str) or len(sample[k])>maximum
                            for k,maximum in (('label',80),('title',120),('text',3000),('updated_at',80)))):
                    _fail('VOICE_RECORD_INVALID','语气样本内容需要核对')
                seen.add(sample['id'])
        return row or dict(id=ident,tenant_id=scope.tenant_id,scope=scope.checked(),owner=owner,
            revision=0,samples=[])

    @staticmethod
    def _public(row):
        return dict(contract=CONTRACT,scope=deepcopy(row['scope']),revision=row['revision'],
            count=len(row['samples']),items=[{k:deepcopy(r[k]) for k in
                ('id','label','title','text','updated_at')} for r in row['samples']],
            voice_anchor='user_library' if len(row['samples'])>=2 else 'insufficient',
            generated_reply=False,delivery_allowed=False)

    def read(self,user,scope):
        with self.store.connect() as db:
            db.execute('BEGIN')
            _,actor=self._authorized(db,user,scope)
            row=self._row(db,scope,actor['username'])
            return self._public(row)

    def save(self,user,scope,request):
        allowed={'expected_revision','label','title','text','sample_id'}
        if (not isinstance(request,dict) or set(request)-allowed
                or type(request.get('expected_revision')) is not int or request['expected_revision']<0):
            _fail('VOICE_INPUT_INVALID','请提供当前样本版本')
        label=_text(request.get('label'),80,'样本名称').strip()
        title=_text(request.get('title',''),120,'样本标题',empty=True).strip()
        original=_text(request.get('text'),3000,'本人语气样本',multiline=True)
        # An explicit title keeps the entire reply as body; short opening lines
        # must not disappear through the upstream note-title heuristic.
        parsed_title,body=self.parser.split_title_body(original,title or label)
        sample_id=request.get('sample_id') or _digest([scope.checked(),body])[:32]
        if not isinstance(sample_id,str) or not re.fullmatch(r'[a-f0-9]{32}',sample_id):
            _fail('VOICE_INPUT_INVALID','样本编号格式无效')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            _,actor=self._authorized(db,user,scope,save=True)
            row=self._row(db,scope,actor['username'])
            if request['expected_revision']!=row['revision']:
                _fail('VOICE_REVISION_CONFLICT','语气样本已更新，请重新读取')
            existing=next((r for r in row['samples'] if r['id']==sample_id),None)
            if request.get('sample_id') and existing is None:
                _fail('VOICE_SAMPLE_MISSING','原语气样本已变化')
            if existing is None and len(row['samples'])>=30:
                _fail('VOICE_LIMIT','每个发送账号最多保存30份语气样本')
            record=dict(id=sample_id,label=label,title=parsed_title,text=body,source_text=original,
                source_type='user_upload',updated_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
            row['samples']=[r for r in row['samples'] if r['id']!=sample_id]+[record]
            row['revision']+=1
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (ENTITY,row['id'],scope.tenant_id,json.dumps(row,ensure_ascii=False,allow_nan=False)))
            return self._public(row)

    def context(self,user,scope,sop_text):
        """Reference card only. The original SOP remains the outgoing draft."""
        _text(sop_text,1000,'SOP',empty=True,multiline=True)
        library=self.read(user,scope)
        references=[dict(id=r['id'],text=r['text'][:500]) for r in library['items'][-3:]]
        payload=dict(scope=scope.checked(),revision=library['revision'],sop_text=sop_text,
            references=references)
        return dict(contract=CONTRACT,revision=library['revision'],sample_count=library['count'],
            context_digest=_digest(payload),sop_text=sop_text,voice_references=references,
            use='tone_reference_only',facts_from_samples_allowed=False,
            automatic_generation=False,delivery_allowed=False,
            note='语气样本只供参考，不复制其中的客户条件、价格或承诺；发送内容仍需本人确认。')

    def context_is_current(self,user,scope,sop_text,digest):
        return (isinstance(digest,str) and
            self.context(user,scope,sop_text)['context_digest']==digest)
