"""Employee-scoped, read-only continuous follow-up screening.

This is an independent local rule screen, never a Codex/model review. Source
records, saved grades, historical reviews and reply permissions are untouched.
Only already-authorized CustomerHistory identities may enter this boundary.
"""
from collections import OrderedDict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import re
from threading import RLock

RULE_VERSION = 'gubei-continuous-followup-20261024-v3-conservative-time-evidence'
MAX_SOURCE_AGE_DAYS = 30
MAX_CACHE_CUSTOMERS = 4096
TZ = timezone(timedelta(hours=8))


def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def _stamp(value):
    if not isinstance(value,str) or not value:return None
    try:
        result=datetime.fromisoformat(value.replace('Z','+00:00'))
        return result.astimezone(TZ) if result.tzinfo is not None else None
    except (ValueError,OverflowError):return None


def _source_published_at(lead,instant):
    original=lead.get('published_at') or ''
    if 'comment_time_evidence' not in lead:return original
    from core.acquisition_sources import verified_comment_time
    checked=verified_comment_time(lead['comment_time_evidence'],original,now=instant)
    return checked.get('publishedAt','')


class PriorityFollowupScreen:
    """Bounded per-workbench cache; no writes or external/model dependencies."""
    def __init__(self, *, clock=None, rule_version=RULE_VERSION):
        self.clock=clock or (lambda:datetime.now(TZ))
        self.rule_version=rule_version
        self._cache=OrderedDict()
        self._cache_lock=RLock()

    def read(self,core,actor,tenant,store_id,people):
        # Import the preserved, separately verified evaluator at use time, so
        # the native host can keep its explicit safe module preload ordering.
        from rental_assessment import GUBEI_STORE_ID, GUBEI_EVALUATOR_VERSION
        instant=self.clock().astimezone(TZ)
        summary={'enabled':store_id==GUBEI_STORE_ID,'total':0,'reviewedPriority':0,
            'automaticPriority':0,'overlap':0,'confirmation':0,'excluded':0,'ended':0,
            'evaluated':0,'reused':0,'source':'local_rule_screen',
            'ruleVersion':self.rule_version,'asOf':instant.date().isoformat(),
            'notice':'自动筛选是本地规则初筛，需本人确认；不会替代原分析或自动发送。'}
        if not summary['enabled']:
            summary['notice']='当前门店尚未启用持续筛选规则，独立复核记录仍保留。'
            return {'items':{},'summary':summary}
        wanted={c['lead_id'] for p in people.values() for c in p.get('comments',[])}
        if not wanted:return {'items':{},'summary':summary}
        # Read only the originals that passed the authenticated history boundary.
        leads={r['id']:r for r in core.store.list('leads',tenant)
            if r.get('id') in wanted and r.get('tenant_id')==tenant
            and r.get('cloud_owner') in (None,'',actor['username'])}
        task_ids={r.get('task_id') for r in leads.values()}
        tasks={r['id']:r for r in core.store.list('tasks',tenant)
            if r.get('id') in task_ids and r.get('tenant_id')==tenant
            and r.get('cloud_owner')==actor['username']}
        contexts={r['id']:r for r in core.store.list('rental_task_context_v1',tenant)
            if r.get('id') in task_ids and r.get('tenant_id')==tenant
            and r.get('owner')==actor['username']}
        outcomes={}
        for row in core.store.list('customer_outcome_events',tenant):
            if (row.get('customerId') in people and row.get('tenant_id')==tenant
                    and row.get('owner')==actor['username'] and row.get('userId')==actor['id']
                    and row.get('storeId')==store_id
                    and row.get('platform')==people[row['customerId']].get('platform')):
                outcomes.setdefault(row['customerId'],[]).append(row)
        results={}
        for ident,person in people.items():
            sources=[]
            for comment in person.get('comments',[]):
                lead=leads.get(comment['lead_id'])
                if not lead:continue
                task=tasks.get(lead.get('task_id'),{})
                context=contexts.get(lead.get('task_id'),{})
                bindings=[v for v in (lead.get('store_id'),task.get('store_id'),context.get('store_id')) if v]
                bound=bool(bindings and all(v==store_id for v in bindings)
                    and (task.get('store_id') or context.get('store_id'))
                    and lead.get('cloud_owner')==actor['username'])
                sources.append({'leadId':lead['id'],'text':str(lead.get('text') or ''),
                    'platform':lead.get('platform'),'authorId':lead.get('author_id'),
                    'sourceType':lead.get('source_type'),'publishedAt':_source_published_at(lead,instant),
                    'originalPublishedAt':lead.get('published_at') or '',
                    'commentTimeEvidence':deepcopy(lead.get('comment_time_evidence')),
                    'createdAt':lead.get('created_at') or '', 'taskId':lead.get('task_id'),
                    'title':lead.get('content_title') or lead.get('title') or '',
                    'parent':lead.get('parent_text') or '', 'bound':bound,
                    'manual':deepcopy(lead.get('manual_intent')),
                    'ai':deepcopy(lead.get('ai_intent'))})
            sources.sort(key=lambda r:r['leadId'])
            events=sorted(outcomes.get(ident,[]),key=lambda r:(r.get('version',0),r.get('id','')))
            state={'contact':person.get('contact_state'),'outcomes':events}
            source_digest=_digest({'sources':sources,'state':state})
            scope=(tenant,actor['username'],actor.get('id'),store_id,person.get('platform'),ident)
            signature=_digest([self.rule_version,GUBEI_EVALUATOR_VERSION,
                instant.date().isoformat(),source_digest])
            with self._cache_lock:
                cached=self._cache.get(scope)
                if cached and cached[0]==signature:
                    result=deepcopy(cached[1]);self._cache.move_to_end(scope)
            if cached and cached[0]==signature:
                summary['reused']+=1
            else:
                result=self._person(sources,instant)
                revoked={r.get('targetEventId') for r in events if r.get('operation')=='revoke'}
                active=[r for r in events if r.get('operation')=='record' and r.get('id') not in revoked]
                final=next((r for r in reversed(active) if r.get('kind') in ('invalid','signed','payment')),None)
                if final:
                    result.update(status='ended' if final['kind'] in ('signed','payment') else 'excluded',
                        priority=False,hardExclude=True,
                        reason='已有人工确认的签约或回款结果' if final['kind'] in ('signed','payment') else '已有人工确认的无效或不跟进结果',unknown=[])
                elif not result['hardExclude'] and (state['contact'] not in (None,'','uncontacted','copied') or active):
                    result.update(status='confirmation',priority=False,
                        reason='已有联系或人工处理记录，请先核对当前状态，避免重复联系',
                        unknown=list(dict.fromkeys([*result['unknown'],'原联系或处理结果'])) )
                result.update(source='local_rule_screen',provider='本地规则初筛',
                    modelReview=False,humanConfirmed=False,needsConfirmation=True,
                    ruleVersion=self.rule_version,sourceDigest=source_digest,
                    asOf=instant.date().isoformat())
                with self._cache_lock:
                    self._cache[scope]=(signature,deepcopy(result));self._cache.move_to_end(scope)
                    while len(self._cache)>MAX_CACHE_CUSTOMERS:self._cache.popitem(last=False)
                summary['evaluated']+=1
            results[ident]=result
            summary['automaticPriority']+=int(result['priority'])
            if result['status'] in ('confirmation','excluded','ended'):
                summary[result['status']]+=1
        return {'items':results,'summary':summary}

    def _person(self,sources,instant):
        # New source text may revive an old ended demand. Conversely, a newer
        # end/refusal always closes the older inquiry for this customer.
        assessed=[]
        for source in sources:
            outcome=self._source(source,instant)
            published=_stamp(source['publishedAt'])
            captured=_stamp(source['createdAt'])
            manual=_stamp((source.get('manual') or {}).get('updated_at')) if isinstance(source.get('manual'),dict) else None
            order=max((v for v in (published or captured,manual) if v),default=datetime.min.replace(tzinfo=TZ))
            assessed.append((order,source['leadId'],outcome))
        assessed.sort(reverse=True,key=lambda row:(row[0],row[1]))
        if not assessed:
            return {'status':'confirmation','priority':False,'hardExclude':False,
                'reason':'未取得当前可核对的原文','unknown':['原评论与来源'],'leaseGroup':'未说明',
                'evidence':{'leadId':'','quote':'','publishedAt':''}}
        for _order,_ident,outcome in assessed:
            if (outcome['hardExclude'] or outcome['priority']
                    or '人工判断仍待确认' in outcome['unknown']):return outcome
        return assessed[0][2]

    @staticmethod
    def _source(source,instant):
        from rental_assessment import (GUBEI_STORE_ID, _gubei_lease, _v4_clauses,
            _event_days, evaluate_rental_source)
        assessment=evaluate_rental_source({'source_id':source['leadId'],
            'source_type':source['sourceType'],'author_subject':'self','text':source['text'],
            'published_at':source['publishedAt'],'post_title':source['title'],
            'persisted_scope':{'store_id':GUBEI_STORE_ID if source['bound'] else None}},now=instant)
        clauses=[c for c in _v4_clauses(source['text'],True)
            if not c['unowned_quote'] and c['speaker'] not in ('商家','客服','房东')]
        authored='；'.join(c['text'] for c in clauses if c['subject']!='third_party')
        unquoted='；'.join(c['text'] for c in clauses)
        lease=_gubei_lease(clauses)
        result={'status':'confirmation','priority':False,'hardExclude':False,
            'reason':'租住需求或当前条件尚待确认','unknown':[],
            'leaseGroup':lease['group'],
            'evidence':{'leadId':source['leadId'],'quote':source['text'][:32000],
                'publishedAt':source['publishedAt']}}
        def excluded(status,reason):
            result.update(status=status,hardExclude=True,reason=reason)
            return result
        manual=source.get('manual')
        if isinstance(manual,dict):
            if manual.get('status')=='unrelated' or (manual.get('status')=='graded' and manual.get('level') in ('low','very_low')):
                return excluded('excluded','人工判断当前不宜优先跟进，原判断保留')
            if manual.get('status')=='uncertain':result['unknown'].append('人工判断仍待确认')
        if re.search(r'不要再联系|别再联系|不许联系|不要私信|禁止联系',authored):
            return excluded('ended','本人已明确拒绝联系，请停止跟进')
        if re.search(r'已(?:经)?(?:租好|租到|找到|找好)|不找了|不租了|不用再找|没有租房需求|不再找房',authored):
            return excluded('ended','本人已说明需求结束，历史询问不再作为当前优先依据')
        if assessment.get('lifecycle') in ('declined','resolved'):
            return excluded('ended','原文已明确否定或结束当前租住需求')
        if assessment.get('lifecycle')=='not_prospect':
            return excluded('excluded','原文属于供给、转载或非本人租住用途')
        personal=bool(re.search(r'我自己|我本人|本人求租',authored))
        supply=bool(re.search(r'我是房东|招租|房源求合作|手上房源|同行合作|带客返佣|欢迎.{0,5}看房|客户.{0,6}(?:找房|求租)|(?:我有|本人).{0,8}(?:房源|出租|转租)',authored))
        if supply and not personal:return excluded('excluded','供房或同行业务信息，未见本人当前租住需求')
        demand=bool(re.search(r'求租|找房|(?:想|要|需要|准备|打算|计划|重新).{0,16}(?:租|找.{0,8}(?:房|公寓))|(?:我|本人).{0,10}(?:短租|租住|租个|租一|租两|租三|租\d)',authored))
        if re.search(r'不是来租房|不是来找房|并不是求租|并非来租|不是我.{0,4}(?:找|租)',authored):
            return excluded('excluded','原话明确不属于本人求租需求')
        if not demand:result['unknown'].append('本人当前是否确有求租需求')
        # Structured extraction can still misread a denied attribution or an
        # elliptical proxy question. Ambiguity is never positive evidence.
        clause_span=r'[^，,。！？!?；;\n]{0,12}'
        if re.search(r'(?:不是|并非)'+clause_span+r'(?:我|现在|想|要|求租|需求)|'
                r'(?:没说|没有说|不代表|不等于)'+clause_span+r'(?:想|要|租|找房)|'
                r'(?:只是|仅仅|纯粹|纯)'+clause_span+r'(?:问问|了解|路过|围观|转发)',unquoted):
            result['unknown'].append('原话含否定、转述或仅了解表述，当前本人求租尚未确认')
        if re.search(r'(?:帮|替|代|给|为)'+clause_span+r'(?:朋友|同事|家人|父母|员工|客户|别人)|'
                r'(?:朋友|同事|家人|父母|员工|客户)'+clause_span+r'(?:让我|叫我|拜托|帮问|代问)',unquoted):
            result['unknown'].append('存在代问或第三人需求，实际承租主体与授权待确认')
        intent=assessment.get('intent') or {}
        # The preserved structured evaluator is a necessary gate. Its store
        # extension's broad vocabulary alone must not override a negation,
        # third-party subject, quotation, stale date or unresolved source.
        if not (assessment.get('rental_need',{}).get('confirmed') is True
                and intent.get('rule_id') in ('R4','R5')
                and intent.get('certainty')=='clear' and intent.get('currentness')=='current'
                and assessment.get('lifecycle')=='active'):
            result['unknown'].append('原文是否构成本人当前明确求租，需进一步确认')
        if not source['bound']:result['unknown'].append('来源门店归属')
        if source['sourceType']!='comment':result['unknown'].append('当前来源尚未启用此筛选规则')
        if not re.search(r'古北|红松路|红松东路',authored):result['unknown'].append('是否接受古北门店位置')
        if re.search(r'(?:不考虑|不接受|拒绝|不选|排除|不要|不在|不租|不想去).{0,5}古北',authored):
            return excluded('excluded','本人明确不接受古北位置')
        if lease['inScope'] is False:return excluded('excluded','原文租期不在古北已确认的1至12个月范围')
        if lease['inScope'] is not True or lease['group'] in ('未说明','租期待确认'):
            result['unknown'].append('租期及对应分组')
        published=_stamp(source['publishedAt'])
        if published is None:result['unknown'].append('原始发布时间与当前是否仍在找房')
        elif published>instant+timedelta(minutes=5):result['unknown'].append('原始时间晚于当前时间')
        elif (instant.date()-published.date()).days>MAX_SOURCE_AGE_DAYS:
            result['unknown'].append('历史需求是否仍然有效')
        event=_event_days(authored,published)
        if event and event[1]<instant.date():result['unknown'].append('原文所指入住或看房时间已过，是否有新需求')
        if re.search(r'明年|以后有需要|以后有机会|暂时不找|现在不找|如果.{0,16}(?:才|再)|工作定了',authored):
            result['unknown'].append('远期计划或前置条件是否已落实')
        if result['unknown']:return result
        result.update(status='priority',priority=True,
            reason='原文有当前求租、古北位置和1至12个月租期证据，建议优先核实',
            unknown=['当前是否仍有需求、实际房源与报价需本人确认'])
        return result


def attach_priority(item,screen_result):
    """Keep legacy review and local evidence separate; merge selection only."""
    screen=screen_result['items'].get(item['id'])
    if screen is not None:item['priorityScreen']=deepcopy(screen)
    blocked=bool(screen and screen.get('hardExclude'))
    review=item.get('codexReview') or {}
    lease=screen.get('leaseGroup') if screen else None
    # A missing new duration cannot erase a known current assessment. An
    # explicit new conflict/out-of-range duration remains visible as such.
    item['followupLeaseGroup']=(lease if lease not in (None,'','未说明') else
        item.get('leaseGroup') or review.get('leaseGroup') or lease or '未说明')
    reviewed=bool(review.get('priority')) and not blocked
    automatic=bool(screen and screen.get('priority')) and not blocked
    item['priorityFollowup']=reviewed or automatic
    item['priorityBasis']=(['codex_review'] if reviewed else [])+(['local_rule_screen'] if automatic else [])
    return item
