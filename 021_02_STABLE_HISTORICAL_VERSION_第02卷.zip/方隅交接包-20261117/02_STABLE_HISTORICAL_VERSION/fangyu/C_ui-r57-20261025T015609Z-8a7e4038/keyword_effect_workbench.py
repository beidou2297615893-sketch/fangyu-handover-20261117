"""Read-only keyword evidence over the original Store, not a second CRM.

This candidate reports observed cohorts with their current judgments. Historical
source_keyword is a saved label, never proof of the query actually dispatched.
"""
from copy import copy
from datetime import date, datetime, time, timedelta, timezone
import json

from assistant.ai_workflow import effective_intent
from assistant.customer_list import _person
from core import CoreError
from core.collection_observations import OBSERVATIONS, comment_identity, digest
from core.collection_query_provenance import ENTITY as QUERY_OBSERVATIONS, valid_observation as valid_query_observation

BEIJING = timezone(timedelta(hours=8))
LEVELS = ('super_high', 'high', 'medium', 'low', 'very_low')
STATES = (*LEVELS, 'uncertain', 'unrelated', 'pending')


class KeywordEffectError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


def _fail(code, message, status=400):
    raise KeywordEffectError(code, message, status)


def _stamp(value):
    # No naive/local clock guesses and no use of publication or AI timestamps.
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed.astimezone(timezone.utc) if parsed.utcoffset() is not None else None
    except (ValueError, OverflowError):
        return None


def _judgment(value):
    if not isinstance(value, dict):
        return None
    if value.get('status') == 'graded' and value.get('level') in LEVELS:
        return value['level']
    return value['status'] if value.get('status') in ('uncertain', 'unrelated') else None


def _rate(numerator, denominator):
    return {'numerator': numerator, 'denominator': denominator,
            'value': numerator / denominator if denominator else None}


class _ReadStore:
    """Original Store get/list semantics bound to one query-only transaction."""
    def __init__(self, original, db):
        self.path, self.directory, self.db = original.path, original.directory, db

    def get(self, entity, ident):
        row = self.db.execute('SELECT body FROM records WHERE entity=? AND id=?', (entity, ident)).fetchone()
        return json.loads(row['body']) if row else None

    def list(self, entity, tenant_id=None):
        query = 'SELECT body FROM records WHERE entity=?'
        values = (entity,)
        if tenant_id is not None:
            query += ' AND tenant_id=?'
            values += (tenant_id,)
        return [json.loads(row['body']) for row in self.db.execute(query, values)]


class KeywordEffectWorkbench:
    def __init__(self, core, customers):
        if customers.core is not core:
            _fail('KEYWORD_CONFIGURATION', '词效与客户历史必须使用同一原始工作区', 503)
        self.core, self.customers = core, customers

    @staticmethod
    def _options(store_id, data):
        if (not isinstance(data, dict) or set(data) - {'storeId', 'dateFrom', 'dateTo', 'platform'}
                or data.get('storeId') != store_id):
            _fail('KEYWORD_INPUT', '请在当前门店选择词效日期范围')
        dates = []
        for key in ('dateFrom', 'dateTo'):
            value = data.get(key)
            try:
                parsed = date.fromisoformat(value)
                if parsed.isoformat() != value:
                    raise ValueError()
            except (TypeError, ValueError):
                _fail('KEYWORD_DATE', '请选择有效的开始和结束日期')
            dates.append(parsed)
        if dates[1] < dates[0] or dates[1] == date.max or (dates[1] - dates[0]).days > 365:
            _fail('KEYWORD_DATE', '一次可查看连续 1—366 天')
        platform = data.get('platform')
        if platform not in (None, 'xiaohongshu', 'douyin'):
            _fail('KEYWORD_PLATFORM', '请选择小红书或抖音')
        start = datetime.combine(dates[0], time(), BEIJING)
        end = datetime.combine(dates[1] + timedelta(days=1), time(), BEIJING)
        return start, end, platform

    def read(self, user, store_id, data):
        start, end, platform = self._options(store_id, data)
        with self.core.store.connect() as db:
            db.execute('PRAGMA query_only=ON')
            db.execute('BEGIN')
            snapshot = copy(self.core)
            snapshot.store = _ReadStore(self.core.store, db)
            customers = copy(self.customers)
            customers.core = snapshot
            actor, public_actor = customers._actor(user, store_id)
            # Existing history authorization, employee ownership and platform
            # exclusions all run against this same SQLite snapshot.
            history = customers._history(actor, store_id, platform)
            visible = history._visible(actor)
            store = snapshot.store
            valid = {}
            quality = {'unverifiedStoreCommentsExcluded': 0,
                       'unknownCollectionTimeRecordsExcluded': 0,
                       'invalidObservationRecordsExcluded': 0,
                       'provisionalIdentityComments': 0}
            task_cache, account_cache = {}, {}
            # Retirement never grants a new account or customer scope. Use
            # only this query-only snapshot's original internal observations
            # and the original Core account-deletion audit, not task drafts.
            task_observations = store.list(OBSERVATIONS, actor['tenant_id'])
            query_observations = store.list(QUERY_OBSERVATIONS, actor['tenant_id'])
            deleted_accounts = set()
            for audit in store.list('audit', actor['tenant_id']):
                detail = audit.get('detail')
                if (audit.get('tenant_id') == actor['tenant_id']
                        and audit.get('actor') == actor['username']
                        and audit.get('action') == 'account_delete'
                        and type(detail) is dict and type(detail.get('id')) is str
                        and type(detail.get('affected_tasks')) is int
                        and detail['affected_tasks'] > 0):
                    deleted_accounts.add(detail['id'])

            def retired(task):
                return task.get('account_removed') is True and task.get('account_id') == ''

            def retired_account(task, lead, observed, *, query=False):
                if not retired(task):
                    return None
                account_id = observed.get('account_id')
                if (type(account_id) is not str or not account_id
                        or account_id not in deleted_accounts
                        or store.get('accounts', account_id) is not None):
                    return None
                if query:
                    return account_id if valid_query_observation(observed, task, lead,
                        historical_account_id=account_id) else None
                try:
                    comment, note, text = comment_identity(lead, task['platform'])
                except (ValueError, KeyError):
                    return None
                if (observed.get('id') != digest([actor['tenant_id'], actor['username'], task['id'], lead['id']])
                        or observed.get('tenant_id') != actor['tenant_id']
                        or observed.get('owner') != actor['username']
                        or observed.get('task_id') != task['id']
                        or observed.get('lead_id') != lead['id']
                        or observed.get('store_id') != store_id
                        or observed.get('platform') != task.get('platform')
                        or lead.get('platform') != task.get('platform')
                        or observed.get('source_id') != lead.get('source_id')
                        or observed.get('comment_id') != comment or observed.get('note_id') != note
                        or observed.get('original_task_id') != lead.get('task_id')
                        or observed.get('original_text_sha256') != digest(text)):
                    return None
                return account_id

            retired_proof_cache = {}
            def retired_lead_has_proof(task, lead):
                key = (task['id'], lead['id'])
                if key not in retired_proof_cache:
                    retired_proof_cache[key] = any(retired_account(task, lead, row)
                        for row in task_observations
                        if row.get('task_id') == task['id'] and row.get('lead_id') == lead['id']) or any(
                        retired_account(task, lead, row, query=True)
                        for row in query_observations
                        if row.get('task_id') == task['id'] and row.get('lead_id') == lead['id'])
                return retired_proof_cache[key]

            def source_task(ident):
                if ident not in task_cache:
                    task_cache[ident] = store.get('tasks', ident)
                task = task_cache[ident]
                if (not task or task.get('tenant_id') != actor['tenant_id']
                        or task.get('store_id') != store_id
                        or task.get('cloud_owner') != actor['username']):
                    return None
                try:
                    snapshot._task_access(actor, task, actor['tenant_id'])
                except (CoreError, ValueError):
                    return None
                if retired(task):
                    return task
                aid = task.get('account_id')
                if aid not in account_cache:
                    account_cache[aid] = store.get('accounts', aid)
                account = account_cache[aid]
                if (not account or account.get('tenant_id') != actor['tenant_id']
                        or account.get('cloud_owner') != actor['username']
                        or account.get('platform') != task.get('platform')
                        or account.get('store_id') not in (None, '', store_id)):
                    return None
                return task

            for lead in visible:
                task = source_task(lead.get('task_id'))
                if (not task or lead.get('platform') != task.get('platform')
                        or lead.get('store_id') not in (None, '', store_id)
                        or retired(task) and not retired_lead_has_proof(task, lead)):
                    quality['unverifiedStoreCommentsExcluded'] += 1
                    continue
                valid[lead['id']] = lead

            # Each task/lead relationship is one observation. Multiple visits of
            # it never move the cohort from first_seen to last_seen.
            rows, observed_keys = [], set()
            for obs in task_observations:
                lead = valid.get(obs.get('lead_id'))
                # Foreign records neither contribute counts nor diagnostics.
                if not lead or obs.get('owner') != actor['username']:
                    continue
                task = source_task(obs.get('task_id'))
                if not task:
                    continue
                expected_id = digest([actor['tenant_id'], actor['username'], task['id'], lead['id']])
                try:
                    comment, note, text = comment_identity(lead, lead['platform'])
                except ValueError:
                    quality['invalidObservationRecordsExcluded'] += 1
                    continue
                if (task.get('platform') != lead['platform']
                        or obs.get('id') != expected_id
                        or (not retired_account(task, lead, obs) if retired(task)
                            else obs.get('account_id') != task.get('account_id'))
                        or obs.get('store_id') != store_id or obs.get('platform') != lead['platform']
                        or obs.get('source_id') != lead.get('source_id')
                        or obs.get('comment_id') != comment or obs.get('note_id') != note
                        or obs.get('original_task_id') != lead.get('task_id')
                        or obs.get('original_text_sha256') != digest(text)):
                    quality['invalidObservationRecordsExcluded'] += 1
                    continue
                pair = (task['id'], lead['id'])
                if pair in observed_keys:
                    quality['invalidObservationRecordsExcluded'] += 1
                    continue
                observed_keys.add(pair)
                rows.append((lead, task['id'], obs.get('first_seen_at'), 'task_observation'))

            # Old originals lacking an original-task observation can still be
            # shown by their saved created_at, explicitly labeled as fallback.
            for lead in valid.values():
                if (lead['task_id'], lead['id']) not in observed_keys:
                    rows.append((lead, lead['task_id'], lead.get('created_at'), 'original_created_at'))

            groups, included, observation_keys = {}, {}, set()
            tagged_observations = 0
            timing_sources = {'task_observation': 0, 'original_created_at': 0}
            for lead, task_id, seen, timing_source in rows:
                stamp = _stamp(seen)
                if stamp is None:
                    quality['unknownCollectionTimeRecordsExcluded'] += 1
                    continue
                if not start <= stamp < end:
                    continue
                pair = (task_id, lead['id'])
                if pair in observation_keys:
                    continue
                observation_keys.add(pair)
                included[lead['id']] = lead
                timing_sources[timing_source] += 1
                # A label on an original lead does not establish the term used
                # by a later task or any unrecorded query in a task's word list.
                keyword = lead.get('source_keyword') if task_id == lead['task_id'] else None
                if not isinstance(keyword, str) or not keyword.strip() or len(keyword) > 200 or any(ord(c) < 32 for c in keyword):
                    keyword = None
                else:
                    keyword = keyword.strip()
                if keyword is not None:
                    tagged_observations += 1
                group = groups.setdefault(keyword, {'leads': {}, 'observations': 0, 'timingSources': {'task_observation': 0, 'original_created_at': 0}})
                group['leads'][lead['id']] = lead
                group['observations'] += 1
                group['timingSources'][timing_source] += 1

            def metrics(leads):
                distribution = dict.fromkeys(STATES, 0)
                people, provisional, ai, manual, judged, manual_hit, new = set(), set(), 0, 0, 0, 0, 0
                for lead in leads.values():
                    person, temporary, _ = _person(lead)
                    people.add(person)
                    if temporary:
                        provisional.add(person)
                    ai_value, manual_value = lead.get('ai_intent'), lead.get('manual_intent')
                    has_ai = bool(lead.get('analysis_status') != 'missing_text' and str(lead.get('text') or '').strip()
                                  and _judgment(ai_value) and ai_value.get('source') != 'metadata')
                    has_manual = bool(_judgment(manual_value))
                    ai += int(has_ai)
                    manual += int(has_manual)
                    judged += int(has_ai or has_manual)
                    manual_hit += int(has_manual and _judgment(manual_value) in ('super_high', 'high', 'medium'))
                    distribution[_judgment(effective_intent(lead)) or 'pending'] += 1
                    acquired = _stamp(lead.get('created_at'))
                    new += int(acquired is not None and start <= acquired < end)
                business = {'high': distribution['super_high'] + distribution['high'],
                            'medium': distribution['medium'], 'low': distribution['low'] + distribution['very_low'],
                            **{k: distribution[k] for k in ('uncertain', 'unrelated', 'pending')}}
                return {'commentsSeen': len(leads), 'newComments': new, 'uniqueCustomers': len(people),
                        'provisionalCustomers': len(provisional), 'aiAnalyzedComments': ai,
                        'manuallyReviewedComments': manual, 'judgedComments': judged,
                        'unanalysedComments': len(leads) - judged, 'effectiveDistribution': distribution,
                        'businessDistribution': business, 'manualHitRate': _rate(manual_hit, manual),
                        'aiAnalysisCoverage': _rate(ai, len(leads))}

            total = metrics(included)
            tagged = {ident for key, group in groups.items() if key is not None for ident in group['leads']}
            untagged = set(groups.get(None, {}).get('leads', {}))
            quality['provisionalIdentityComments'] = sum(_person(v)[1] for v in included.values())
            query_groups, query_included, query_seen = {}, {}, set()
            quality['invalidQueryObservationRecordsExcluded'] = 0
            for observed in query_observations:
                lead = valid.get(observed.get('lead_id'))
                if not lead or observed.get('owner') != actor['username']:
                    continue
                task = source_task(observed.get('task_id'))
                if not task:
                    continue
                historical_account_id = retired_account(task, lead, observed, query=True) if retired(task) else None
                if (retired(task) and historical_account_id is None
                        or not valid_query_observation(observed, task, lead, historical_account_id=historical_account_id)):
                    quality['invalidQueryObservationRecordsExcluded'] += 1
                    continue
                stamp = _stamp(observed['first_seen_at'])
                if stamp is None or not start <= stamp < end or observed['id'] in query_seen:
                    continue
                query_seen.add(observed['id'])
                query_included[lead['id']] = lead
                group = query_groups.setdefault(observed['keyword'], {'leads': {}, 'observations': 0})
                group['leads'][lead['id']] = lead
                group['observations'] += 1
            query_metrics = metrics(query_included)
            query_attribution = {'schema': 'fangyu-keyword-query-effect-v1',
                'basis': 'host-requested-query-not-platform-ranking',
                'dateBasis': 'first-observed-task-comment-keyword',
                'total': {**query_metrics, 'observations': len(query_seen)},
                'groups': [{'keyword': keyword, **metrics(group['leads']), 'observations': group['observations']}
                           for keyword, group in sorted(query_groups.items())],
                'historicalLabelsNotPromoted': True, 'platformCalled': False,
                'description': '按所选日期首次记录的任务、评论与检索词关系统计；同一关系重读不重复新增。'}
            output = {'schema': 'fangyu-keyword-effect-v1', 'actor': public_actor,
                      'scope': {'storeId': store_id, 'platform': platform, 'dateFrom': data['dateFrom'],
                                'dateTo': data['dateTo'], 'timezone': 'Asia/Shanghai',
                                'startInclusive': start.isoformat(), 'endExclusive': end.isoformat()},
                      'snapshotAt': datetime.now(timezone.utc).isoformat(),
                      'judgmentBasis': 'current-snapshot-for-observed-cohort',
                      'attributionBasis': 'saved-historical-label-not-verified-dispatched-query',
                      'total': {**total, 'observations': len(observation_keys), 'timingSources': timing_sources},
                      'coverage': {'commentsWithKeywordLabel': _rate(len(tagged), len(included)),
                                   'observationsWithKeywordLabel': _rate(tagged_observations, len(observation_keys)),
                                   'unmarkedComments': len(untagged),
                                   'commentsWithBothTaggedAndUnmarkedObservations': len(tagged & untagged)},
                      'groups': [{'keyword': key, 'label': key if key is not None else '未标记',
                                  'attribution': 'saved_historical_label' if key is not None else 'unmarked',
                                  **metrics(group['leads']), 'observations': group['observations'],
                                  'timingSources': group['timingSources']}
                                 for key, group in sorted(groups.items(), key=lambda p: (p[0] is None, p[0] or ''))],
                      'quality': quality,
                      'queryAttribution': query_attribution,
                      'limitations': ['关键词是已保存的历史标签，不能证明实际搜索请求使用了该词。',
                                      '未标记不代表词无效；当前任务词表和进度不能倒推历史来源。',
                                      '同一客户可出现在多个词下，总计已全局去重，不能将分组相加。',
                                      '意向为当前判断快照；不是当日判断回放，也不是成交转化率。',
                                      '观察数是已保存的任务与评论关系，不是平台返回条数。'],
                      'readOnly': True, 'modelCalled': False, 'platformCalled': False}
            db.rollback()
        return output
