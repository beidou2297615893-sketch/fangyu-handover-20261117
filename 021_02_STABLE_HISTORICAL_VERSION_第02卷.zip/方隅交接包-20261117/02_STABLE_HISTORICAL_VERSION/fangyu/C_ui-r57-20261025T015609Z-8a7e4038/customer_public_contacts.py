"""Voluntary original-comment clues; no customer/AI/outcome/contact mutations."""
from datetime import datetime, timezone
import hashlib
import json
import re

EVENTS = 'customer_public_contact_events'
RECEIPTS = 'customer_public_contact_receipts'
BASE = {'storeId', 'customerId', 'platform'}
SAVE = BASE | {'requestId', 'expectedVersion', 'sourceDigest', 'candidateId',
               'operation', 'targetEventId', 'confirmed'}
KEY = re.compile(r'[a-f0-9]{64}\Z')
REQUEST = re.compile(r'[A-Za-z0-9_-]{8,100}\Z')
# Deliberately narrow: explicit self statement; no profile lookup, decoding,
# nickname inference, "same number" inference, or third-party contact extraction.
TOKEN_END = r'(?=$|[\s，,。；;！？!）)\]】}])'
PHONE = re.compile(r'(?:(?:我(?:的)?|本人(?:的)?)(?:手机号|手机号码|电话号码|电话|手机)|联系我|给我打电话|打我电话|加我)\s*(?:是|为|[:：,， ])*\s*(?P<value>1[3-9][0-9]{9})'+TOKEN_END, re.I)
WECHAT = re.compile(r'(?:(?:我(?:的)?|本人(?:的)?)(?:微信号|微信|vx|wechat)|加我(?:的)?(?:微信号|微信|vx|wechat))\s*(?:是|为|[:：,， ])*\s*(?P<value>[a-zA-Z][a-zA-Z0-9_-]{5,19})'+TOKEN_END, re.I)
UNSAFE = re.compile(r'''不|勿|别|非我|拒绝|没同意|他[的说]|她[的说]|朋友|同事|同学|家人|家属|妈妈|爸爸|房东|中介|对方|别人|转发|转述|引用|例如|比如|示例|模板|代发|客服|机器人|如果|假如|可能|也许|曾经|以前|旧号|已经停用|已停用|测试|吗|是否|听说|据说|诈骗|假冒|[“”‘’「」『』"']''')
# Whole-comment refusal/attribution declarations win over a self-statement in
# another sentence. Do not treat an unrelated budget "不超过" as a refusal.
COMMENT_BLOCK = re.compile(
    r'(?:不要|请勿|勿|别|禁止|谢绝|拒绝|不愿意?|不想|不接受|不需要|不方便|不允许|不希望|不准|不可|不得|不再|无需|不必|不能|无法)'
    r'[^。！？；;\r\n]{0,12}(?:联系|联络|骚扰|打扰|找我|加我|添加我|加微信|加好友|打电话|打我电话|打给我|致电|私信我|私聊我|发私信|发消息)'
    r'|(?:未同意|未授权|未经同意|未经授权)[^。！？；;\r\n]{0,12}(?:联系|联络|加我|添加|电话|微信)'
    r'|(?:不对外|不公开|禁止公开|不要公开|勿公开)[^。！？；;\r\n]{0,8}(?:电话|手机|微信|号码|联系方式)'
    r'|非本人|非我|不是(?:我(?:的|本人)?|本人)|不属于我|(?:他人|别人)(?:的)?(?:电话|手机|微信|号码|联系方式)'
    r'|(?:号码|联系方式|手机|微信|电话)[^。！？；;\r\n]{0,10}(?:撤回|撤下|收回|停用|作废|失效)'
    r'|(?:撤回|撤下|收回|停用|作废)[^。！？；;\r\n]{0,10}(?:号码|联系方式|手机|微信|电话)'
    r'|转发|转述|引用|摘录|朋友的话|他的原话|她的原话|原文如下'
    r'|(?:朋友|同事|同学|家人|房东|中介|对方|别人|他|她)(?:说|写|发来|表示|称)'
    r'|虚构|虚假|编造|瞎编|假号码|假号|随机生成|占位|样例|示例|示范|模板|测试'
    r'|昵称|网名|显示名')


class ContactError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status, self.mutation_committed = code, status, False


def fail(code, message, status=400):
    raise ContactError(code, message, status)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def recognize(text):
    """Offsets refer to Unicode code points in the unchanged original text."""
    if not isinstance(text, str) or len(text) > 20000:
        fail('PUBLIC_CONTACT_LIMIT', '原评论过长，请直接核对原评论', 413)
    if COMMENT_BLOCK.search(text):
        return []
    found = []
    for clause in re.finditer(r'[^。！？；;\r\n]+', text):
        if UNSAFE.search(clause.group()):
            continue
        for kind, pattern in (('phone', PHONE), ('wechat', WECHAT)):
            for match in pattern.finditer(clause.group()):
                start, end = (clause.start() + match.start('value'),
                              clause.start() + match.end('value'))
                # A Chinese/fullwidth period can delimit a sentence, but never
                # cut a domain into a plausible WeChat handle.
                tail = text[end:]
                if tail.lstrip().startswith(('.', '．', '@', '＠', ':', '：', '/', '\\', '?', '#', '&', '=')):
                    continue
                if len(tail) > 1 and tail[0] in '.。．' and tail[1].isascii() and tail[1].isalnum():
                    continue
                value = text[start:end]
                found.append({'kind': kind, 'value': value,
                    'span': {'start': start, 'end': end, 'text': value}})
    return sorted(found, key=lambda row: (row['span']['start'], row['kind']))


class PublicContactsWorkbench:
    def __init__(self, core, customers, outcomes_factory):
        # Reuse the original snapshot and CustomerHistory permission chain.
        self.core = core
        self.outcomes = outcomes_factory(core, customers)

    def _base(self, data, store_id, fields):
        if not isinstance(data, dict) or set(data) != fields:
            fail('PUBLIC_CONTACT_INPUT', '联系方式核对参数无效')
        self.outcomes._base(data, store_id, fields)
        if not data['customerId'] or data['platform'] not in ('xiaohongshu', 'douyin'):
            fail('PUBLIC_CONTACT_INPUT', '请选择原平台的当前可见客户')

    def _context(self, db, user, store_id, data):
        core, actor, public, source, refs = self.outcomes._context(db, user, store_id, data)
        if len(refs) > 2000:
            fail('PUBLIC_CONTACT_LIMIT', '评论数量过多，请直接核对原评论', 413)
        candidates = {}; total_text = 0; occurrences = 0
        for ref in refs:
            lead = core.store.get('leads', ref['leadId'])
            text = lead.get('text') or ''
            if not isinstance(text, str):fail('PUBLIC_CONTACT_INPUT', '原评论格式无法核对')
            total_text += len(text)
            if total_text > 200000:fail('PUBLIC_CONTACT_LIMIT', '原评论过多，请直接核对原评论', 413)
            for clue in recognize(text):
                occurrences += 1
                if occurrences > 200:fail('PUBLIC_CONTACT_LIMIT', '原文线索过多，请直接核对原评论', 413)
                cid = digest(['voluntary-original-v1', actor['id'], store_id,
                    data['customerId'], data['platform'], clue['kind'], clue['value']])
                candidate = candidates.setdefault(cid, {'id': cid, 'kind': clue['kind'],
                    'value': clue['value'], 'sources': []})
                if len(candidates) > 100:fail('PUBLIC_CONTACT_LIMIT', '原文线索过多，请直接核对原评论', 413)
                candidate['sources'].append({**ref, 'author_key': data['customerId'],
                    'commentId': lead.get('comment_id') or '', 'originalText': text,
                    'textSha256': hashlib.sha256(text.encode()).hexdigest(),
                    'span': clue['span'], 'offsetUnit': 'unicode-code-point'})
        return core, actor, public, source, candidates

    @staticmethod
    def _evidence_current(row, candidates):
        current = candidates.get(row['candidateId'])
        if current is None:return False
        keys = ('leadId', 'taskId', 'accountId', 'platform', 'author_key', 'textSha256', 'span')
        return any(all(old.get(k) == now.get(k) for k in keys)
            for old in row.get('originalCandidate', {}).get('sources', [])
            for now in current['sources'])

    def _rows(self, core, actor, store_id, data):
        scope = self.outcomes._scope(actor, store_id)
        return sorted((r for r in core.store.list(EVENTS, actor['tenant_id'])
            if self.outcomes._matches(r, scope) and r.get('customerId') == data['customerId']
            and r.get('platform') == data['platform']), key=lambda r: r['version'])

    def _request(self, core, actor, store_id, data):
        ident = digest([actor['tenant_id'], actor['id'], store_id, data['requestId']])
        prior = core.store.get(RECEIPTS, ident)
        if prior and (not self.outcomes._matches(prior, self.outcomes._scope(actor, store_id))
                or any(prior.get(k) != data[k] for k in ('customerId', 'platform'))):
            fail('PUBLIC_CONTACT_REQUEST_CONFLICT', '原操作编号已用于其他客户或范围', 409)
        return ident, prior

    def _view(self, core, actor, public, store_id, data, source, candidates, prior=None):
        rows = self._rows(core, actor, store_id, data)
        revoked = {r['targetEventId'] for r in rows if r['operation'] == 'revoke'}
        active = {r['candidateId']: r for r in rows
            if r['operation'] in ('confirm', 'reject') and r['id'] not in revoked}
        for candidate in candidates.values():
            event = active.get(candidate['id'])
            current = bool(event and self._evidence_current(event, candidates))
            candidate.update(state=event['operation'] if current else 'pending',
                eventId=event['id'] if event else None, requiresPriorRevoke=bool(event and not current))
        # Never re-expose historical original text after a source ceases to be
        # visible. The journal retains it for audit; the response derives sources
        # exclusively from the current original CustomerHistory snapshot.
        history = [{k: row[k] for k in ('id', 'version', 'candidateId', 'operation',
                    'targetEventId', 'createdAt')} | {'revoked': row['id'] in revoked,
                'withdrawn': not self._evidence_current(row, candidates),
                'kind': row.get('originalCandidate', {}).get('kind'),
                'canRevoke': row['operation'] in ('confirm', 'reject') and row['id'] not in revoked}
            for row in reversed(rows)]
        receipt = ({'requestId': data['requestId'],
            'state': prior['state'] if prior else 'not_found',
            'requestDigest': prior.get('requestDigest') if prior else None,
            'version': prior.get('version') if prior else None} if 'requestId' in data else None)
        return {'actor': {**public, 'id': actor['id']}, 'customerId': data['customerId'],
            'platform': data['platform'], 'version': rows[-1]['version'] if rows else 0,
            'sourceDigest': source, 'candidates': list(candidates.values()),
            'history': history, 'receipt': receipt, 'candidateOnly': True,
            'contactSharedFactRecorded': False, 'readOnlyRecognition': True}

    def read(self, user, store_id, data):
        self._base(data, store_id, BASE | ({'requestId'} if isinstance(data, dict) and 'requestId' in data else set()))
        with self.core.lock, self.core.store.connect() as db:
            db.execute('PRAGMA query_only=ON'); db.execute('BEGIN')
            core, actor, public, source, candidates = self._context(db, user, store_id, data)
            _, prior = self._request(core, actor, store_id, data) if 'requestId' in data else (None, None)
            return self._view(core, actor, public, store_id, data, source, candidates, prior)

    def save(self, user, store_id, data):
        self._base(data, store_id, SAVE)
        if (type(data['expectedVersion']) is not int or data['expectedVersion'] < 0
                or not isinstance(data['sourceDigest'], str) or not KEY.fullmatch(data['sourceDigest'])
                or not isinstance(data['candidateId'], str) or not KEY.fullmatch(data['candidateId'])
                or data['operation'] not in ('confirm', 'reject', 'revoke')
                or data['confirmed'] is not True
                or data['operation'] != 'revoke' and data['targetEventId'] is not None
                or data['operation'] == 'revoke' and (not isinstance(data['targetEventId'], str)
                    or not KEY.fullmatch(data['targetEventId']))):
            fail('PUBLIC_CONTACT_CONFIRM', '请逐条核对原文，并显式确认本次操作')
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            core, actor, public, source, candidates = self._context(db, user, store_id, data)
            key, prior = self._request(core, actor, store_id, data)
            signature = digest(data)
            if prior:
                if prior['requestDigest'] != signature:
                    fail('PUBLIC_CONTACT_REQUEST_CONFLICT', '原操作内容已变化，请先核对原结果', 409)
                return self._view(core, actor, public, store_id, data, source, candidates, prior)
            rows = self._rows(core, actor, store_id, data)
            version = rows[-1]['version'] if rows else 0
            if data['expectedVersion'] != version:
                fail('PUBLIC_CONTACT_VERSION_CONFLICT', '核对记录已更新，请重新读取', 409)
            if data['sourceDigest'] != source:
                fail('PUBLIC_CONTACT_SOURCE_CHANGED', '原评论或权限已变化，请重新核对', 409)
            candidate = candidates.get(data['candidateId'])
            revoked = {r['targetEventId'] for r in rows if r['operation'] == 'revoke'}
            active = [r for r in rows if r['candidateId'] == data['candidateId']
                and r['operation'] in ('confirm', 'reject') and r['id'] not in revoked]
            if data['operation'] == 'revoke':
                if len(active) != 1 or active[0]['id'] != data['targetEventId']:
                    fail('PUBLIC_CONTACT_DECISION_CONFLICT', '原核对不存在或已撤销', 409)
                # _context already revalidated the original current customer,
                # employee, store and platform. _rows restricts this event to the
                # same actor/customer. Revocation discloses no withdrawn source.
                candidate = active[0]['originalCandidate']
            else:
                if candidate is None:
                    fail('PUBLIC_CONTACT_SOURCE_CHANGED', '该线索不在当前可见原评论中', 409)
                if active:
                    fail('PUBLIC_CONTACT_DECISION_CONFLICT', '该线索已核对；需先撤销原记录', 409)
            stamp = datetime.now(timezone.utc).isoformat()
            scope = self.outcomes._scope(actor, store_id)
            row = {**data, **scope, 'id': key, 'version': version + 1,
                'createdAt': stamp, 'originalCandidate': candidate,
                'candidateOnly': True, 'contactSharedFactRecorded': False}
            prior = {**scope, 'id': key, 'customerId': data['customerId'],
                'platform': data['platform'], 'requestId': data['requestId'],
                'requestDigest': signature, 'state': 'accepted',
                'version': version + 1, 'createdAt': stamp}
            self.outcomes._insert(db, EVENTS, row)
            self.outcomes._insert(db, RECEIPTS, prior)
            return self._view(core, actor, public, store_id, data, source, candidates, prior)

    def cancel(self, user, store_id, data):
        self._base(data, store_id, BASE | {'requestId', 'requestDigest'})
        if not isinstance(data['requestDigest'], str) or not KEY.fullmatch(data['requestDigest']):
            fail('PUBLIC_CONTACT_INPUT', '原操作摘要无效')
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            core, actor, public, source, candidates = self._context(db, user, store_id, data)
            key, prior = self._request(core, actor, store_id, data)
            if prior and prior['requestDigest'] != data['requestDigest']:
                fail('PUBLIC_CONTACT_REQUEST_CONFLICT', '原操作内容不匹配', 409)
            if not prior:
                prior = {**self.outcomes._scope(actor, store_id), 'id': key,
                    'customerId': data['customerId'], 'platform': data['platform'],
                    'requestId': data['requestId'], 'requestDigest': data['requestDigest'],
                    'state': 'cancelled', 'version': None,
                    'createdAt': datetime.now(timezone.utc).isoformat()}
                self.outcomes._insert(db, RECEIPTS, prior)
            return self._view(core, actor, public, store_id, data, source, candidates, prior)
