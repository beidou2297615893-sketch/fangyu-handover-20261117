"""Manual business facts, append-only in the original Store; no send/AI hooks."""
from copy import copy
from contextlib import contextmanager
from datetime import date, datetime, timezone
import hashlib
import json
import re

EVENTS='customer_outcome_events'
RECEIPTS='customer_outcome_receipts'
STAGES=('contacted','responded','contact_shared','appointment','visited','signed','payment','invalid')
LABELS=dict(zip(STAGES,('已联系','客户回应','客户留资','已预约','已到访','已签约','已回款','无效')))
COSTS=('software','labor','channel')
KEY=re.compile(r'[a-f0-9]{64}\Z')
REQUEST=re.compile(r'[A-Za-z0-9_-]{8,100}\Z')
BASE={'storeId','customerId','platform'}
SAVE=BASE|{'requestId','expectedVersion','sourceDigest','operation','targetEventId','kind','occurredOn','fact','source','evidenceRef','amountCents','costCategory','confirmed'}

class OutcomeError(ValueError):
    def __init__(self,code,message,status=400,*,committed=False):
        super().__init__(message);self.code=code;self.status=status;self.mutation_committed=committed

def fail(code,message,status=400):raise OutcomeError(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def valid_date(value):
    try:
        d=date.fromisoformat(value)
        if d.isoformat()!=value:raise ValueError()
        return d
    except (ValueError,TypeError):fail('OUTCOME_DATE','请填写有效的事实日期')

class ReadStore:
    def __init__(self,original,db):self.directory,self.path,self.db=original.directory,original.path,db
    def get(self,entity,ident):
        row=self.db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,ident)).fetchone()
        return json.loads(row['body']) if row else None
    def list(self,entity,tenant_id=None):
        return [json.loads(row['body']) for row in self.db.execute('SELECT body FROM records WHERE entity=?'+(' AND tenant_id=?' if tenant_id else ''),(entity,tenant_id) if tenant_id else (entity,))]
    @contextmanager
    def connect(self):
        # Preserve CustomerHistory's contact-event reads within this same
        # transaction; nested reads must never commit or reopen the snapshot.
        yield self.db

class CustomerOutcomesWorkbench:
    def __init__(self,core,customers):
        if customers.core is not core:fail('OUTCOME_CONFIGURATION','客户结果必须使用原工作区',503)
        self.core,self.customers=core,customers

    def _snapshot(self,db):
        core=copy(self.core);core.store=ReadStore(self.core.store,db)
        customers=copy(self.customers);customers.core=core;customers.rental_reader=None;customers.rental_batch_reader=None
        return core,customers

    @staticmethod
    def _base(data,store_id,fields):
        if not isinstance(data,dict) or set(data)!=fields:
            fail('OUTCOME_INPUT','结果登记参数无效')
        if data.get('storeId')!=store_id:fail('OUTCOME_SCOPE_CHANGED','当前门店已变化，请回原范围核对',403)
        cid=data.get('customerId')
        if not isinstance(cid,str) or cid and not KEY.fullmatch(cid):fail('OUTCOME_INPUT','请选择当前可见客户')
        if data.get('platform') not in ('xiaohongshu','douyin',None) or (cid and data.get('platform') is None):fail('OUTCOME_INPUT','请选择客户的原平台')
        if not cid and data.get('platform') is not None:fail('OUTCOME_INPUT','投入记录按本店全部平台登记')
        if 'requestId' in data and (not isinstance(data['requestId'],str) or not REQUEST.fullmatch(data['requestId'])):fail('OUTCOME_INPUT','操作编号无效')

    def _context(self,db,user,store_id,data):
        core,customers=self._snapshot(db)
        actor,public=customers._actor(user,store_id)
        cid=data['customerId'];sources=[]
        if cid:
            actor,public,item,person=customers.detail_context(actor,store_id,cid,platform=data['platform'])
            for comment in person.get('comments',[]):
                lead=core.store.get('leads',comment['lead_id']);task=core.store.get('tasks',lead.get('task_id')) if lead else None
                if lead and task and (lead.get('store_id')==store_id or task.get('store_id')==store_id):sources.append(lead)
            if not sources:fail('OUTCOME_STORE_UNVERIFIED','原客户来源门店尚未核实，暂不能登记业务结果',403)
        signature=digest({'actor':[actor[k] for k in ('id','tenant_id','username','role','cloud_bound')],'storeId':store_id,'customerId':cid,'platform':data['platform'],'sources':sorted(sources,key=lambda row:row['id'])})
        refs=[{'leadId':lead['id'],'taskId':lead.get('task_id'),'accountId':(core.store.get('tasks',lead.get('task_id')) or {}).get('account_id'),'platform':lead.get('platform'),'sourceId':lead.get('source_id')} for lead in sorted(sources,key=lambda row:row['id'])]
        return core,actor,public,signature,refs

    @staticmethod
    def _scope(actor,store_id):return {'tenant_id':actor['tenant_id'],'owner':actor['username'],'userId':actor['id'],'storeId':store_id}
    @staticmethod
    def _matches(row,scope):return all(row.get(k)==v for k,v in scope.items())
    def _rows(self,core,scope,cid):
        rows=[r for r in core.store.list(EVENTS,scope['tenant_id']) if self._matches(r,scope) and r.get('customerId')==cid]
        return sorted(rows,key=lambda r:r['version'])
    def _request(self,core,actor,store_id,data):
        ident=digest([actor['tenant_id'],actor['id'],store_id,data['requestId']])
        prior=core.store.get(RECEIPTS,ident)
        if prior and (not self._matches(prior,self._scope(actor,store_id)) or any(prior.get(k)!=data[k] for k in ('customerId','platform'))):fail('OUTCOME_REQUEST_CONFLICT','原操作编号已用于其他客户或范围',409)
        return ident,prior
    @staticmethod
    def _insert(db,entity,row):db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))
    def _view(self,core,actor,public,store_id,data,source,prior=None):
        rows=self._rows(core,self._scope(actor,store_id),data['customerId'])
        revoked={r['targetEventId'] for r in rows if r['operation']=='revoke'}
        history=[{**r,'revoked':r['id'] in revoked} for r in reversed(rows)]
        receipt=({'requestId':data['requestId'],'state':prior['state'] if prior else 'not_found','requestDigest':prior.get('requestDigest') if prior else None,'version':prior.get('version') if prior else None} if 'requestId' in data else None)
        return {'actor':public,'customerId':data['customerId'],'platform':data['platform'],'version':rows[-1]['version'] if rows else 0,'sourceDigest':source,'history':history,'receipt':receipt,'manualEntry':True,'independentlyReconciled':False}

    def read(self,user,store_id,data):
        self._base(data,store_id,BASE|({'requestId'} if isinstance(data,dict) and 'requestId' in data else set()))
        with self.core.store.connect() as db:
            db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
            core,actor,public,source,_refs=self._context(db,user,store_id,data)
            _,prior=self._request(core,actor,store_id,data) if 'requestId' in data else (None,None)
            return self._view(core,actor,public,store_id,data,source,prior)

    def _save_input(self,data):
        if type(data['expectedVersion']) is not int or data['expectedVersion']<0 or not isinstance(data['sourceDigest'],str) or not KEY.fullmatch(data['sourceDigest']):fail('OUTCOME_INPUT','请先读取当前结果版本')
        if data['confirmed'] is not True:fail('OUTCOME_CONFIRM','请确认这是本人核对后的人工登记')
        for key,limit in (('fact',2000),('source',300),('evidenceRef',500)):
            if not isinstance(data[key],str) or len(data[key])>limit or any(ord(c)<32 and c not in '\n\t' for c in data[key]):fail('OUTCOME_INPUT','事实说明或来源过长或无效')
        if not data['fact'].strip() or not data['source'].strip():fail('OUTCOME_EVIDENCE','请填写事实说明与来源')
        valid_date(data['occurredOn'])
        if data['operation']=='revoke':
            if not isinstance(data['targetEventId'],str) or not KEY.fullmatch(data['targetEventId']) or data['kind']!='revoke' or data['amountCents'] is not None or data['costCategory'] is not None:fail('OUTCOME_INPUT','请选择要撤销的原登记')
        elif data['operation']=='record':
            if data['targetEventId'] is not None:fail('OUTCOME_INPUT','新增事实不能覆盖旧事实')
            allowed=STAGES if data['customerId'] else ('cost',)
            if data['kind'] not in allowed:fail('OUTCOME_INPUT','请选择有效结果')
            monetary=data['kind'] in ('payment','cost')
            amount=data['amountCents']
            if monetary and (type(amount) is not int or amount<0 or amount>100_000_000_000 or data['kind']=='payment' and amount==0):fail('OUTCOME_AMOUNT','金额必须为人民币整数分；回款需大于零')
            if not monetary and amount is not None:fail('OUTCOME_AMOUNT','只有实际回款或投入填写金额')
            if data['kind']=='cost' and data['costCategory'] not in COSTS or data['kind']!='cost' and data['costCategory'] is not None:fail('OUTCOME_INPUT','请选择软件、人工或渠道投入类别')
        else:fail('OUTCOME_INPUT','结果操作无效')

    def save(self,user,store_id,data):
        self._base(data,store_id,SAVE);self._save_input(data)
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            core,actor,public,source,refs=self._context(db,user,store_id,data)
            key,prior=self._request(core,actor,store_id,data);signature=digest(data)
            if prior:
                if prior['requestDigest']!=signature:fail('OUTCOME_REQUEST_CONFLICT','原操作的内容已变化，请先核对原结果',409)
                return self._view(core,actor,public,store_id,data,source,prior)
            rows=self._rows(core,self._scope(actor,store_id),data['customerId']);version=rows[-1]['version'] if rows else 0
            if data['expectedVersion']!=version:fail('OUTCOME_VERSION_CONFLICT','结果记录已更新，请保留输入并重新读取',409)
            if data['sourceDigest']!=source:fail('OUTCOME_SOURCE_CHANGED','原客户资料或权限已变化，请重新核对',409)
            if data['operation']=='revoke':
                target=next((r for r in rows if r['id']==data['targetEventId'] and r['operation']=='record'),None)
                if target is None or any(r['targetEventId']==target['id'] for r in rows if r['operation']=='revoke'):fail('OUTCOME_REVOKE_CONFLICT','原登记不存在或已撤销',409)
            stamp=datetime.now(timezone.utc).isoformat();scope=self._scope(actor,store_id)
            row={**data,**scope,'id':key,'version':version+1,'createdAt':stamp,'manualEntry':True,'independentlyReconciled':False,'currency':'CNY','customerSourceRefs':refs}
            prior={**scope,'id':key,'customerId':data['customerId'],'platform':data['platform'],'requestId':data['requestId'],'requestDigest':signature,'state':'accepted','version':version+1,'createdAt':stamp}
            self._insert(db,EVENTS,row);self._insert(db,RECEIPTS,prior)
            return self._view(core,actor,public,store_id,data,source,prior)

    def cancel(self,user,store_id,data):
        self._base(data,store_id,BASE|{'requestId','requestDigest'})
        if not isinstance(data['requestDigest'],str) or not KEY.fullmatch(data['requestDigest']):fail('OUTCOME_INPUT','原操作摘要无效')
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');core,actor,public,source,_refs=self._context(db,user,store_id,data)
            key,prior=self._request(core,actor,store_id,data)
            if prior and prior['requestDigest']!=data['requestDigest']:fail('OUTCOME_REQUEST_CONFLICT','原操作内容不匹配',409)
            if not prior:
                prior={**self._scope(actor,store_id),'id':key,'customerId':data['customerId'],'platform':data['platform'],'requestId':data['requestId'],'requestDigest':data['requestDigest'],'state':'cancelled','version':None,'createdAt':datetime.now(timezone.utc).isoformat()}
                self._insert(db,RECEIPTS,prior)
            return self._view(core,actor,public,store_id,data,source,prior)

    def report(self,user,store_id,data):
        if not isinstance(data,dict) or set(data)!={'storeId','dateFrom','dateTo'} or data['storeId']!=store_id:fail('OUTCOME_INPUT','请选择本店统计日期范围')
        start,end=valid_date(data['dateFrom']),valid_date(data['dateTo'])
        if end<start or (end-start).days>365:fail('OUTCOME_DATE','一次可查看连续1—366天')
        from assistant.customer_list import _person
        with self.core.store.connect() as db:
            db.execute('PRAGMA query_only=ON');db.execute('BEGIN');core,customers=self._snapshot(db)
            actor,public=customers._actor(user,store_id);people=set()
            for lead in customers._history(actor,store_id)._visible(actor):
                task=core.store.get('tasks',lead.get('task_id'))
                if task and (lead.get('store_id')==store_id or task.get('store_id')==store_id):people.add(_person(lead)[0])
            scope=self._scope(actor,store_id)
            rows=[r for r in core.store.list(EVENTS,actor['tenant_id']) if self._matches(r,scope) and (not r['customerId'] or r['customerId'] in people)]
            revoked={r['targetEventId'] for r in rows if r['operation']=='revoke'}
            active=[r for r in rows if r['operation']=='record' and r['id'] not in revoked and start<=valid_date(r['occurredOn'])<=end]
            cohorts={k:{r['customerId'] for r in active if r['kind']==k} for k in STAGES}
            registered=set().union(*cohorts.values());stage_rows=[];previous=None
            for kind in STAGES:
                ids=cohorts[kind];denominator=len(cohorts[previous]) if previous and kind!='invalid' else len(registered)
                numerator=len(ids & cohorts[previous]) if previous and kind!='invalid' else len(ids)
                stage_rows.append({'kind':kind,'label':LABELS[kind],'customers':len(ids),'numerator':numerator,'denominator':denominator,'rate':numerator/denominator if denominator else None,'denominatorMeaning':LABELS[previous]+'且本期也登记本结果的客户 / 本期'+LABELS[previous]+'客户' if previous and kind!='invalid' else '本期登记此结果客户 / 本期登记任一结果客户'})
                previous=kind
            payments=[r['amountCents'] for r in active if r['kind']=='payment'];costs={k:[r['amountCents'] for r in active if r['kind']=='cost' and r['costCategory']==k] for k in COSTS}
            cost_values={k:sum(v) if v else None for k,v in costs.items()};complete=all(v is not None for v in cost_values.values())
            total=sum(v for v in cost_values.values() if v is not None) if any(v is not None for v in cost_values.values()) else None
            paid=sum(payments) if payments else None
            return {'actor':public,'dateFrom':data['dateFrom'],'dateTo':data['dateTo'],'scopeNotice':'本机当前员工、当前门店；同平台跨账号按原客户去重，跨平台不推定同一人','visibleCustomers':len(people),'registeredCustomers':len(registered),'stages':stage_rows,'currency':'CNY','paymentCents':paid,'costCents':cost_values,'knownCostCents':total,'costCategoriesComplete':complete,'receiptsToSpend':paid/total if paid is not None and complete and total and total>0 else None,'roi':None,'ratioNotice':'仅已登记事实日期范围的回款/投入比；缺成本类别或零投入不计算；回款不等于利润，无已核贡献利润不计算ROI','evidenceNotice':'全部为人工登记，未独立对账；历史可撤销但保留；跳阶段不补前序记录，环节交集比例不是同期获客转化率','manualEntry':True,'independentlyReconciled':False,'readOnly':True}
