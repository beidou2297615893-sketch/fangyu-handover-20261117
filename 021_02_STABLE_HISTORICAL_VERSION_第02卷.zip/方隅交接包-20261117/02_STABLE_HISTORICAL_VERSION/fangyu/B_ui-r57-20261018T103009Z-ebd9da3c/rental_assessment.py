"""Local rental evidence assessments, kept separate from historical grades.

Standard-library, deterministic initial rules; not a calibrated language model.
The pure evaluator never calls a provider. Persisted assessments require the
service's current tenant/employee/task/source checks.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import re
import unicodedata
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

RULE_VERSION = "2026-10-18.intent-evidence-contract-draft-v4-review2-peer1"
def rule_overview():
    """Public explanation pinned to this evaluator version; no model prompt."""
    return {'engineVersion':RULE_VERSION,'source':'local_evidence_evaluator',
        'standards':[
            {'code':'R1','label':'非目标','description':'供应方、转出方、研究或非本人租住用途，不进入待回复客户。'},
            {'code':'R2','label':'已解决或已放弃','description':'需求已解决或明确否定，保留原记录，不作为普通低意向待联系。'},
            {'code':'R4','label':'高意向','description':'明确租住需求、具体条件，以及当前真实推进请求；提出约看不代表预约已确认。'},
            {'code':'R5','label':'中意向','description':'明确租住需求和具体条件，尚无当前真实推进动作。'},
            {'code':'R6','label':'低意向','description':'需求待条件触发，或明确远期了解。'},
            {'code':'R0/R3/R7/R_TIME','label':'待确认','description':'来源或原文不足、需求冲突、缺具体需求，或推进时间过期、无原始时间锚点。'}],
        'peerScreening':{'basis':'explicit_professional_brokerage_activity',
            'nicknameOrOccupationAloneExcluded':False,'personalRentalNeedPreserved':True,
            'notice':'明确替客户找房或同行合作属于业务线索；本人租住需求单独保留，不能凭昵称或职业推断。'},
        'budget':'提取客户预算原文；未获得已核同口径门店报价时，价格适配待核。',
        'income':'只记录客户自报收入，不按职业、头像或租金推断收入和支付能力。'}


ENTITY = "rental_assessments_v1"
TZ = timezone(timedelta(hours=8))
_OWN = re.compile(r"我(?:自己|本人|们|俩)?|本人|咱们")
_OTHER = re.compile(r"朋友|同事|别人|网友|客户|房东|他|她")
_NEED = re.compile(r"求租|找房|想.{0,12}租|要.{0,8}租|找.{0,14}(?:一居|两居|三居|公寓|房)|考虑换租|换租|租个|共同整租|短租.{0,8}(?:公寓|房)|想要.{0,12}(?:一居|两居|三居|公寓)")
_SUPPLY = re.compile(r"转租|出租|招租|我是房东|房源发布")
_VIEW = re.compile(r"看房|约看|看这套|看一下房")
_ROOM = re.compile(r"一居|两居|三居|四居|单间|一室|两室|三室|整租|Studio", re.I)
_PLACE = re.compile(r"虹桥|徐泾东|龙柏|天璟|季乐路|蟠中路|蟠臻路|会展中心|金汇路|古北|浦江|[一-鿿]{1,7}(?:路|区|站|商圈)")
_QUOTE = re.compile(r'“[^”]*”|‘[^’]*’|「[^」]*」|『[^』]*』|"[^"\n]*"')

def _stamp(value=None):
    if value is None:
        return datetime.now(TZ)
    if isinstance(value, datetime):
        return value.astimezone(TZ) if value.tzinfo is not None else None
    if isinstance(value, str):
        try:
            d = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return d.astimezone(TZ) if d.tzinfo is not None else None
        except ValueError:
            return None
    return None

def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()

def _clauses(text):
    masked = list(text)
    for m in _QUOTE.finditer(text):
        masked[m.start():m.end()] = " " * (m.end()-m.start())
    visible = "".join(masked)
    result, subject = [], "self"
    for m in re.finditer(r"[^，,。！？!?；;\n]+", visible):
        v = m.group(); own = list(_OWN.finditer(v)); other = list(_OTHER.finditer(v))
        if own and (not other or own[-1].start() > other[-1].start()):
            subject = "self"
        elif other:
            subject = "third_party"
        result.append({"text":v, "quote":text[m.start():m.end()], "start":m.start(),
                       "end":m.end(), "subject":subject})
    return result

def _evidence(source, clause, signal, explanation):
    return {"signal_id":signal, "source_id":source.get("source_id"),
            "quote":clause["quote"], "start":clause["start"], "end":clause["end"],
            "offset_unit":"unicode_codepoint", "polarity":"affirmed",
            "subject":clause["subject"], "time_status":"current", "explanation":explanation}

def _empty_budget():
    return {"raw_quote":None, "amount_min":None, "amount_max":None, "limit_kind":"unknown",
            "currency":None, "currency_raw":None, "period":"unknown", "cost_scope":"unknown",
            "allocation":"unknown", "occupants":None, "monthly_unit_rent_cap":None,
            "annual_equivalent_monthly":None, "constraints":[], "comparable":False,
            "normalization_formula":None, "normalization_label":"Unknown", "missing_fields":[], "evidence":[]}

_HISTORICAL = re.compile(r"去年|以前|曾经|过去|上次|之前|租过|找过|看过")
_CURRENT = re.compile(r"现在|目前|仍|还在|还找|这次|重新|再约")
_CLOSED = re.compile(r"已经租好|已租好|已经租到|已租到|已经找好|已找好|不找了|不再找|现在不租|不是找房|没有租房需求")
_NEGATED_NEED = re.compile(r"不想.{0,4}租|不打算.{0,5}租|不准备.{0,5}租|不需要.{0,5}(?:租|房)|没打算.{0,5}租|不是.{0,3}(?:求租|想租|找房)")
_CANCEL = re.compile(r"取消|不去看|不想看|不看房|不签|不准备签|还没决定签|没有预约|没约好")
_CONTRACT = re.compile(r"(?:准备|决定|想|确认|要).{0,5}(?:签.{0,5}(?:租约|租赁合同)|交.{0,4}押金|订这套)|这套我要租|发.{0,5}(?:租约|租赁合同)")
_LOW = re.compile(r"只是.{0,5}(?:了解|看看)|只想.{0,5}了解|提前了解|明年.{0,8}(?:搬|租)|以后有需要|暂时看看|长期计划")
_CONDITIONAL = re.compile(r"如果|假如|要是|倘若|等.{0,8}(?:涨工资|有钱)")
_COMMERCIAL = re.compile(r"月租.{0,8}(?:多少|预算)|租金.{0,6}(?:多少|询问)|有.{0,4}空房|还有房|能租|怎么付款|押一付|能.{0,3}养猫")

def _event_days(text, published):
    """Conservative original-post date ranges; never anchor to collection time."""
    if published is None:
        return None
    anchor = published.date()
    for word, n in (("大后天",3),("后天",2),("明天",1),("今天",0)):
        if word in text:
            day=anchor+timedelta(days=n);return day,day
    if "下周" in text or "下星期" in text:
        first=anchor+timedelta(days=7-anchor.weekday());return first,first+timedelta(days=6)
    if "这周" in text or "本周" in text:
        return anchor,anchor+timedelta(days=6-anchor.weekday())
    week=re.search(r"(?:周|星期)([一二三四五六日天末])",text)
    if week:
        n={"一":0,"二":1,"三":2,"四":3,"五":4,"六":5,"日":6,"天":6,"末":5}[week[1]]
        first=anchor+timedelta(days=(n-anchor.weekday())%7)
        return first,first+timedelta(days=1 if week[1]=="末" else 0)
    md=re.search(r"(?:(\d{4})年)?(\d{1,2})月(?:(\d{1,2})[日号]|(底))",text)
    if md:
        try:
            year=int(md[1] or anchor.year);month=int(md[2])
            if md[4]:
                nxt=datetime(year+1,1,1) if month==12 else datetime(year,month+1,1)
                day=(nxt-timedelta(days=1)).date()
            else:day=datetime(year,month,int(md[3])).date()
            return day,day
        except ValueError:return None
    if "月底" in text:
        nxt=datetime(anchor.year+1,1,1) if anchor.month==12 else datetime(anchor.year,anchor.month+1,1)
        day=(nxt-timedelta(days=1)).date();return day,day
    days=re.search(r"(\d{1,2})天内",text)
    if days:return anchor,anchor+timedelta(days=int(days[1]))
    return None

def _valid_action(clause, published, instant):
    text=clause["text"]
    if clause["subject"]!="self" or (_HISTORICAL.search(text) and not _CURRENT.search(text)):
        return False,None
    if _CANCEL.search(text) and not re.search(r"重新|再约|现在.{0,5}(?:约|看)",text):return False,None
    if _CONDITIONAL.search(text) and not re.search(r"如果有(?:空)?房|有房的话",text):return False,None
    if _CONTRACT.search(text):return True,None
    if not _VIEW.search(text):return False,None
    days=_event_days(text,published)
    if days and days[1] < instant.date():return False,days
    confirmed=bool(re.search(r"已约好|已预约|预约成功|约好了",text))
    return bool(days is not None or confirmed),days

_NUM = r"(?:[0-9０-９]{1,8}(?:[.．][0-9０-９]{1,4})?\s*[kKＫｋ万千]?|[一二两三四五六七八九十百千万]{1,10})"
_MONEY = re.compile(r"(?P<lo>"+_NUM+r")(?:\s*[-–—~～至到]\s*(?P<hi>"+_NUM+r"))?")

def _amount(raw):
    value=unicodedata.normalize("NFKC",raw).replace(" ","")
    try:
        if re.fullmatch(r"\d+(?:\.\d+)?[kK万千]?",value):
            mult={"k":1000,"K":1000,"万":10000,"千":1000}.get(value[-1],1)
            amount=Decimal(value[:-1] if mult!=1 else value)*mult
        else:
            digits={"一":1,"二":2,"两":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9}
            total=0;section=0;number=0
            for char in value:
                if char in digits:number=digits[char]
                elif char in ("十","百","千"):
                    section+=(number or 1)*{"十":10,"百":100,"千":1000}[char];number=0
                elif char=="万":total+=(section+number or 1)*10000;section=0;number=0
                else:return None
            # Colloquial 一万五 / 三千五 leaves omitted denomination ambiguous.
            if len(value)>1 and value[-1] in digits and any(c in value[:-1] for c in "百千万") and not value.endswith("零"+value[-1]):return None
            amount=Decimal(total+section+number)
        if not 0<=amount<=100000000:return None
        return int(amount) if amount==amount.to_integral_value() else float(amount)
    except (ValueError,InvalidOperation):return None

def _currency(text, full):
    def found(value):
        return [code for pattern,code in ((r"人民币|\bRMB\b|\bCNY\b","CNY"),(r"美元|\bUSD\b","USD"),(r"港币|港元|\bHKD\b","HKD"),(r"日元|\bJPY\b","JPY")) if re.search(pattern,value,re.I)]
    codes=found(text) or found(full)
    return codes[0] if len(codes)==1 else None

def _period(text):
    if re.search(r"总(?:价|预算|额)|三晚|两晚|几晚|\d+晚",text):return "stay_total"
    if re.search(r"/年|每年|年租|年房租|年预算|年度|一年",text):return "year"
    if re.search(r"/月|每(?:自然)?月|月租|月房租|月薪|月收入",text):return "month"
    if re.search(r"/晚|每晚",text):return "night"
    if re.search(r"/天|每天|日租",text):return "day"
    if re.search(r"/周|每周",text):return "week"
    return "unknown"

def _occupants(text):
    m=re.search(r"([1-9一二两三四五六七八九])(?:个)?人",text)
    if not m:return None
    return int(m[1]) if m[1].isdigit() else {"一":1,"二":2,"两":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9}[m[1]]

def _budget(source, own):
    result=_empty_budget();full="；".join(c["text"] for c in own)
    occupants=_occupants(full);carry=False
    for c in own:
        v=c["text"]
        if _HISTORICAL.search(v) and not _CURRENT.search(v):continue
        cue=re.search(r"预算|(?:房租|租金|月租|年租).{0,12}(?:最多|上限|不超|不能超过|以内)",v)
        if cue:carry=True
        if not cue and not (carry and re.search(r"最多|上限|改为|而是",v)):continue
        if "收入" in v and "预算" not in v:continue
        begin=cue.start() if cue else 0
        for m in _MONEY.finditer(v,begin):
            left=v[begin:m.start()]
            neg=list(re.finditer(r"不是|不考虑|并非",left));revision=list(re.finditer(r"而是|改为|改到|现在",left))
            if neg and (not revision or neg[-1].start()>revision[-1].start()):continue
            lo=_amount(m["lo"]);hi=_amount(m["hi"]) if m["hi"] else lo
            if lo is None or hi is None or lo>hi:continue
            near=v[max(begin,m.start()-18):m.end()+12]
            cap=bool(re.search(r"最多|上限|不超|不能超过|以内|以下",near))
            kind="range" if m["hi"] else "upper_cap" if cap else "approximate"
            period=_period(v)
            scope="all_in" if re.search(r"全包|包水电|包网|包物业|含水电|总入住",v) else "deposit" if "押金" in v and "房租" not in v else "rent_only" if re.search(r"房租|月租|租金|年租|租房预算",v) else "unknown"
            allocation="whole_unit" if re.search(r"整套|整租",v) or "不是人均" in v else "per_person" if re.search(r"每人|人均|各自",v) else "whole_unit" if re.search(r"整套|共同整租",full) else "unknown"
            currency=_currency(v,full)
            constraint={"raw_quote":c["quote"],"amount_min":lo if kind=="range" else None,"amount_max":hi,
                        "limit_kind":kind,"currency":currency,"period":period,"cost_scope":scope,
                        "allocation":allocation,"occupants":occupants,"monthly_unit_cap":None,
                        "annual_equivalent_monthly":None,"formula":None,"normalization_label":"User-provided",
                        "evidence":_evidence(source,c,"BUDGET","客户预算原话，计价口径独立于意向")}
            if currency=="CNY" and scope=="rent_only" and kind in ("upper_cap","range"):
                if period=="month" and allocation=="whole_unit":constraint["monthly_unit_cap"]=hi
                if period=="month" and allocation=="per_person" and occupants and re.search(r"共同整租|整租|合租",full) and re.search(r"每人|各自",v):
                    constraint["monthly_unit_cap"]=hi*occupants;constraint["formula"]=f"{hi}*{occupants}={hi*occupants}";constraint["normalization_label"]="Calculated"
                if period=="year" and allocation=="whole_unit":
                    avg=Decimal(str(hi))/12;constraint["annual_equivalent_monthly"]=int(avg) if avg==avg.to_integral_value() else float(round(avg,2))
                    constraint["formula"]=f"{hi}/12={constraint['annual_equivalent_monthly']}";constraint["normalization_label"]="Calculated"
            result["constraints"].append(constraint)
            # One numeric budget per clause; different time/cost limits remain separate.
            break
    constraints=result["constraints"]
    if not constraints:return result
    monthly=[c for c in constraints if c["period"]=="month"]
    selected=(monthly or constraints)[-1]
    for key in ("raw_quote","amount_min","amount_max","limit_kind","currency","period","cost_scope","allocation","occupants"):
        result[key]=selected[key]
    caps=[c["monthly_unit_cap"] for c in constraints if c["monthly_unit_cap"] is not None]
    result["monthly_unit_rent_cap"]=min(caps) if caps else None
    annual=[c["annual_equivalent_monthly"] for c in constraints if c["annual_equivalent_monthly"] is not None]
    result["annual_equivalent_monthly"]=min(annual) if annual else None
    result["normalization_formula"]=selected["formula"];result["normalization_label"]=selected["normalization_label"]
    result["evidence"]=[c["evidence"] for c in constraints]
    result["missing_fields"]=[key for key in ("currency","period","cost_scope","allocation") if result[key] in (None,"unknown")]
    if selected["allocation"]=="per_person" and selected["monthly_unit_cap"] is None:result["missing_fields"].append("joint_allocation_or_occupants")
    result["comparable"]=bool(result["monthly_unit_rent_cap"] is not None and not result["missing_fields"])
    return result

def _income(source, own):
    full="；".join(c["text"] for c in own)
    for c in own:
        v=c["text"]
        if _HISTORICAL.search(v) and not _CURRENT.search(v):continue
        if re.search(r"家庭|夫妻|我们家|爸妈|朋友|老板|收入证明|发票|税点",v):continue
        cue=re.search(r"(?:我(?:自己|本人)?|本人)(?:的|目前)?(?:税前|税后)?(?:月|年)?(?:收入|工资|薪资)|^(?:税前|税后)?(?:月薪|月收入|年收入|工资|收入)",v)
        if not cue:continue
        money=next(_MONEY.finditer(v,cue.start()),None)
        no_fixed=bool(re.search(r"没(?:有)?固定收入|无固定收入",v))
        if not money and not no_fixed:continue
        amount=_amount(money["lo"]) if money else None
        if money and amount is None:continue
        maximum=_amount(money["hi"]) if money and money["hi"] else amount
        return {"raw_quote":c["quote"],"subject":"self","self_reported":True,"verified":False,
                "amount_min":amount,"amount_max":maximum,"currency":_currency(v,full),
                "period":_period(v) if _period(v) in ("month","year") else "unknown",
                "tax_basis":"net" if "税后" in v else "gross" if "税前" in v else "unknown",
                "stability":"no_fixed_income" if no_fixed else "unknown","as_of":source.get("published_at"),
                "evidence":[_evidence(source,c,"INCOME_SELF_REPORTED","本人自报收入，未独立核验且不决定意向")]}
    return None







def _v4_clauses(text, proxy=False):
    """Keep exact spans and explicit speakers; a quotation is not the author's claim."""
    result=[]; speaker="author"; subject="beneficiary" if proxy else "author"
    quotes=[(m.start(),m.end()) for m in _QUOTE.finditer(text)]
    for m in re.finditer(r"[^，,。！？!?；;\n]+",text):
        value=m.group(); local=speaker; target=subject
        label=re.match(r"\s*(?:另一同昵称)?(?:(账号|截图|评论)([A-Za-z0-9]+)|(客户|商家|客服|房东|[A-Z])\s*[:：])",value)
        if label:
            local=("账号"+label[2]) if label[1] else label[3]
            speaker=local; target="author" if local=="客户" else local;subject=target
        if re.search(r"(?:我|本人).{0,3}(?:帮|替|代).{0,8}(?:找|租)|帮(?:我)?(?:妹妹|姐姐|朋友|同事|员工)|帮[一二两三四五六七八九\d]+位?员工|替.{0,8}(?:找|租)",value):
            target="beneficiary";subject=target
        elif re.search(r"(?:我自己|我本人|我现在|本人).{0,8}(?:租|找|换)",value) and not re.fullmatch(r"账号[A-Za-z0-9]+|[A-Z]",local):
            target="author";subject=target
        elif re.search(r"朋友|同事|妹妹|姐姐|(?:^|\s)[他她]",value) and not proxy and not _OWN.search(value):
            target="third_party"
        quoted=any(a<=m.start()<b or m.start()<=a<m.end() for a,b in quotes)
        reported=bool(quoted and not proxy)
        result.append({"text":value,"quote":value,"start":m.start(),"end":m.end(),
                       "speaker":local,"subject":target,"quoted":quoted,"unowned_quote":reported,
                       "reported_source":bool(label and label[1]=="截图")})
    return result


def _v4_evidence(source,clause,signal,published,captured,instant):
    days=_event_days(clause["text"],published)
    historical=bool((_HISTORICAL.search(clause["text"]) or re.search(r"上周|上个月|昨天.{0,4}说",clause["text"])) and not _CURRENT.search(clause["text"]))
    currentness="historical" if historical or days and days[1]<instant.date() else "current"
    relative=bool(re.search(r"今天|明天|后天|下周|这周|本周|月底|周[一二三四五六末日天]",clause["text"]))
    return {"id":f"e{clause['start']}_{signal.lower()}","signal_id":signal,
            "source_id":source.get("source_id"),"quote":clause["quote"],
            "start":clause["start"],"end":clause["end"],"offset_unit":"unicode_codepoint",
            "timestamp":published.isoformat() if published else None,"speaker":clause["speaker"],
            "subject":clause["subject"],"currentness":currentness,"time_status":currentness,
            "negation":bool(_NEGATED_NEED.search(clause["text"])),
            "polarity":"negated" if _NEGATED_NEED.search(clause["text"]) else "affirmed",
            "conditional":bool(_CONDITIONAL.search(clause["text"])),
            "quoted_or_reposted":clause["quoted"],"supports":[signal],
            "source_created_at":published.isoformat() if published else None,
            "captured_at":captured.isoformat() if captured else None,
            "independent_source_group":source.get("source_id"),
            "relative_time_resolution":("resolved_from_source_created_at" if days else "unresolved") if relative else "not_relative",
            "explanation":signal}


def _v4_empty(source,instant,published,captured,version):
    budget=_empty_budget()
    budget.update(comparisons=[],overall_fit="not_comparable",fit_reason="没有已核实且口径相同的当前报价",
                  certainty="unresolved",scenario_groups=[])
    return {"schema_version":"fangyu-lead-judgement-candidate/3","rule_version":version,"evaluator_version":RULE_VERSION,
        "source_id":source.get("source_id"),"source_created_at":published.isoformat() if published else None,
        "captured_at":captured.isoformat() if captured else None,"as_of":instant.isoformat(),"timezone":"Asia/Shanghai",
        "evaluated_at":instant.isoformat(),"source_digest":_digest(source),
        "level":"unknown","intent_level":"unknown","eligibility":"uncertain","roles":[],"stay_purpose":"unknown",
        "intent_confidence":"low","reason":"没有可确认的本人当前租住需求",
        "subjects":{"author_ref":"author","beneficiary_refs":[],"viewing_agent_refs":[],"request_ref":"request_1","identity_link_basis":"source_only_no_nickname_merge"},
        "rental_need":{"confirmed":False,"lease_type":"unknown","evidence_ids":[],"certainty":"unresolved","reason":"尚无明确租住需求"},
        "housing_desire":{"state":"none","location":None,"evidence_ids":[]},
        "role":"unknown","lifecycle":"unknown",
        "intent":{"grade":"insufficient","rule_id":"R7","reason":"没有可确认的租住证据","evidence_ids":[],"certainty":"unresolved","currentness":"unknown"},
        "historical_intent":[],"budget":budget,
        "income":{"claims":[],"target_subject_status":"unknown","certainty":"unresolved","reason":"未提供目标受益人本人收入；不从画像推断"},
        "income_self_report":None,"store_matches":[],
        "store_match":{"material_keys":[],"city_confirmed":None,"relation_basis":"unverified_text_only","unresolved_names":[],"geographic_logic":"unknown","priority":[],"physical_site_refs":[]},
        "needs_fit":{"items":[],"overall":"pending_verification","reason":"门店现行能力/价格未核实，与意向独立"},
        "contact_permission":{"status":"unknown","subject_ref":"author","channels_allowed":[],"channels_denied":[],"purpose_scope":[],"validity":"unknown","withdrawn":False,"evidence_ids":[],"host_send_authorized":False},
        "evidence":[],"conflicts":[],"missing_fields":[],"manual_review":{"needed":True,"reasons":[]},
        "next_step":"no_action","action_records":[],"authority_claims":[],"request_groups":[],
        "fit_status":"not_comparable","review_required":True,"review_reasons":[],
        "execution_state":"review_only_no_external_action","calibration_status":"deterministic_v4_not_real_customer_calibrated"}


def _v4_confirmed_allocation(clauses,needs,evidence):
    """Only two explicitly speaking beneficiaries can confirm one half each."""
    if not needs:return {}
    participants=list(dict.fromkeys(c["subject"] for c in clauses
        if re.fullmatch(r"账号[A-Za-z0-9]+|[A-Z]",c["subject"])))
    if len(participants)!=2 or any(not re.fullmatch(r"账号[A-Za-z0-9]+|[A-Z]",p) for p in participants):return {}
    ids=[]
    for person in participants:
        own=[c for c in clauses if c["subject"]==person and c["speaker"]==person]
        if not re.search(r"共同|一起|我们两人","；".join(c["text"] for c in own)):return {}
        confirmations=[c for c in own if re.search(r"各付一半|各自付一半|各承担一半",c["text"])
            and not re.search(r"(?:不|未|没有|否认).{0,8}(?:确认|各付|一半|同意)",c["text"])]
        if not confirmations:return {}
        ids.extend(evidence(c,"BUDGET_ALLOCATION") for c in confirmations)
    return {"beneficiary_refs":participants,"allocation_policy":"equal_halves_confirmed_by_each",
        "allocation_evidence_ids":list(dict.fromkeys(ids)),"share":0.5}


def _v4_budget(source,clauses,result,evidence,store_facts,instant,allocation=None):
    full="；".join(c["text"] for c in clauses);carry=False; constraints=[]
    for clause_index,c in enumerate(clauses):
        v=c["text"]
        same_subject="；".join(x["text"] for x in clauses if x["subject"]==c["subject"])
        budget_currency_context="；".join(x["text"] for x in clauses if x["subject"]==c["subject"] and re.search(r"预算|租金|房租|月租|年租|押金|首期|首次|付租月|必付费用|每自然月|[前后第][一二两三四五六七八九十\d]+个?月.{0,5}(?:最多|上限)",x["text"]) and not re.search(r"收入|工资|月薪|年包|奖金",x["text"]))
        if c["unowned_quote"] or c["speaker"] in ("商家","房东","客服"):continue
        if re.search(r"商家.{0,5}(?:报价|说)|房东.{0,5}(?:报价|说)|看到.{0,8}(?:报价|广告)|房源标价|对方报价",v):continue
        if not re.search(r"预算|我.{0,6}(?:承受|接受|上限)",v) and re.search(r"看到.{0,8}(?:年租|月租|租金|房租)|(?:想问|请问|问一下).{0,12}(?:是不是|是否|多少)|(?:月租|年租).{0,4}(?:是不是|是否)",v):continue
        rent_context=bool(re.search(r"租.{0,15}(?:一居|两居|三居|公寓)|(?:一居|两居|三居|公寓).{0,6}租|找.{0,12}(?:一居|两居|三居|房)|年租|月租|租金|房租",same_subject))
        cue=re.search(r"预算|租金|房租|月租|年租|总租金|押金|首付|首期|首次|入住.{0,5}(?:费用|支出)|必付费用|每个付租月|每人.{0,5}最多|补贴",v)
        if not cue and c["subject"]=="third_party":cue=re.search(r"合计|共同上限|总共",v)
        if not cue and rent_context:cue=re.search(r"每(?:自然)?月.{0,5}(?:最多|上限)|[前后第][一二两三四五六七八九十\d]+个?月.{0,5}(?:最多|上限)",v)
        if not cue and rent_context and _MONEY.search(v):
            cue=re.search(r"每人|人均",v)
            if not cue and _period(v)!="unknown" and _currency(v,"") is not None:
                cue=re.search(r"人民币|美元|港币|日元|欧元|元",v)
        if cue:carry=True
        if not cue and not (carry and re.search(r"最多|上限|改为|改到|而是|付租月|不能超过",v)):continue
        if re.search(r"收入|工资|年包|月薪|年薪|奖金",v) and not re.search(r"预算|租金|房租|押金",v):continue
        for m in _MONEY.finditer(v):
            lo=_amount(m["lo"]);hi=_amount(m["hi"]) if m["hi"] else lo
            if lo is None or hi is None or lo>hi or hi<100:continue
            # Modifiers attach to this amount, never to the following bound.
            prefix=re.split(r"[、：:]",v[:m.start()])[-1][-16:]
            suffix=re.split(r"[、：:]",v[m.end():])[0]
            next_money=_MONEY.search(suffix)
            if next_money:suffix=suffix[:next_money.start()]
            suffix=re.split(r"最多|至少|上限|最低|不得低于",suffix)[0]
            near=prefix+suffix
            if re.search(r"(?:不是|并非|不再是)\s*$",v[:m.start()]):continue
            hard_ceiling=bool(re.search(r"最多|上限|不超|不能超过|以内|以下|至多|封顶",near))
            hard_floor=bool(re.search(r"至少|最低|不得低于|以上",near))
            # A following explicit softness statement refers to this amount only
            # until another amount or an explicit subject change intervenes.
            soft_followup=[]
            for following in clauses[clause_index+1:]:
                if following["subject"]!=c["subject"] or _MONEY.search(following["text"]):break
                if re.search(r"(?:不是|并非)硬(?:范围|上限|限制)",following["text"]):soft_followup.append(following)
            soft=bool(re.search(r"希望|理想|目标|大约|大概|左右|可调|可以浮动|不是硬",near) or soft_followup)
            approximate=bool(re.search(r"上下|约莫",near)) and not soft_followup
            if approximate:interpretation="approximate";hardness="unknown";hard=None
            elif soft:interpretation="preferred_range" if m["hi"] else "target";hardness="confirmed_soft";hard=False
            elif hard_ceiling or hard_floor:
                interpretation="hard_interval" if m["hi"] and hard_floor and hard_ceiling else "hard_floor" if hard_floor and not hard_ceiling else "hard_ceiling";hardness="confirmed_hard";hard=True
            else:interpretation="mentioned_range" if m["hi"] else "mentioned_amount";hardness="unknown";hard=None
            period="paid_month" if "付租月" in v else _period(v)
            if period=="unknown" and re.search(r"月租|每月|/月",same_subject) and not re.search(r"押金|首期|首次",v):period="month"
            scope="subsidy_separate" if "补贴" in v and not re.search(r"预算|租金|房租",v) else "upfront" if re.search(r"首次|首期|入住.{0,5}(?:费用|支出)|首付",v) else "deposit" if "押金" in v and not re.search(r"租金|房租",v) else "annual_total" if re.search(r"总租金|年总|全年|年预算|年租|一年.{0,5}(?:租金|房租)",v) else "all_in" if re.search(r"全包|含水电|含物业|所有必付|水电.{0,5}(?:全|含)|总入住",v) else "rent_only" if re.search(r"房租|月租|租金|年租|租房预算|付租月",v) or rent_context and period in ("month","paid_month") else "unknown"
            if scope in ("deposit","upfront"):period="one_time"
            if scope=="annual_total":period="year"
            unit="per_person" if re.search(r"每人|人均|各自",v) else "whole_unit" if re.search(r"整套|整租|共同整租",v) else "unknown"
            allocated=bool(allocation and c["subject"] in allocation["beneficiary_refs"] and scope=="rent_only" and period=="month")
            if allocated:unit="per_person"
            currency=_currency(v,budget_currency_context)
            ev_id=evidence(c,"BUDGET")
            phase_match=re.search(r"前.{1,5}(?:月|个月)|后.{1,5}(?:月|个月)|第.{1,8}月",v)
            stay_match=re.search(r"(?:(\d{4})年)?(\d{1,2})月(\d{1,2})日至(\d{1,2})日",same_subject)
            stay_interval=None
            posted=_stamp(source.get("source_created_at") or source.get("published_at"))
            if stay_match and posted:
                try:
                    year=int(stay_match[1] or posted.year);month=int(stay_match[2])
                    stay_start=datetime(year,month,int(stay_match[3])).date();stay_end=datetime(year,month,int(stay_match[4])).date()
                    if stay_end>=stay_start:stay_interval={"start":stay_start.isoformat(),"end":stay_end.isoformat()}
                except ValueError:pass
            item={"id":f"budget_{len(constraints)+1}","raw":c["quote"],"subject_ref":c["subject"],
                  "currency":currency,"period":period,"cost_scope":scope,"unit_basis":unit,"people":_occupants(full),
                  "minimum":lo if m["hi"] or hard_floor else None,"maximum":hi if not hard_floor or hard_ceiling else None,
                  "amount":lo if not m["hi"] else None,"interpretation":interpretation,"hard_constraint":hard,
                  "hardness":hardness,"mentioned_amount":lo if not m["hi"] else None,
                  "mentioned_range":[lo,hi] if m["hi"] else None,
                  "applicable_phase":phase_match.group() if phase_match else "unspecified",
                  "calendar_basis":"natural_month" if "自然月" in v else "unspecified",
                  "billing_interval":stay_interval,
                  "limit_basis":"paid_month" if period=="paid_month" else "annual_total" if scope=="annual_total" else "per_period",
                  "expense_timing":"upfront" if scope in ("upfront","deposit") else "recurring" if period in ("month","paid_month","week","year") else "unknown",
                  "currentness":"historical" if _HISTORICAL.search(v) and not _CURRENT.search(v) else "current",
                  "claim_status":"third_party_report_unconfirmed" if c["subject"]=="third_party" else "source_report",
                  "allocation_evidence_ids":allocation["allocation_evidence_ids"][:] if allocated else [],
                  "allocation_share":allocation["share"] if allocated else None,
                  "normalized_monthly":None,"calculation":None,"evidence_ids":[ev_id]+[evidence(x,"BUDGET_SOFTNESS") for x in soft_followup],
                  # Read compatibility. No multiplied people or averaged annual cap.
                  "raw_quote":c["quote"],"amount_min":lo if m["hi"] else None,"amount_max":hi,
                  "limit_kind":"upper_cap" if interpretation=="hard_ceiling" else "range" if m["hi"] else "approximate",
                  "allocation":unit,"occupants":_occupants(full),"monthly_unit_cap":None,
                  "annual_equivalent_monthly":None,"formula":None,"normalization_label":"User-provided",
                  "evidence":{"signal_id":"BUDGET","source_id":source.get("source_id"),"quote":c["quote"],"start":c["start"],"end":c["end"],"offset_unit":"unicode_codepoint"}}
            if hard and period=="month" and scope=="rent_only" and unit=="whole_unit" and currency=="CNY" and interpretation=="hard_ceiling":item["monthly_unit_cap"]=hi
            # Only an explicit same-speaker revision supersedes an earlier same-basis claim.
            if re.search(r"改为|改到|现在改|改成|而是",v):
                for previous in constraints:
                    if previous["subject_ref"]==item["subject_ref"] and all(previous[k]==item[k] for k in ("currency","period","cost_scope","unit_basis")):
                        previous["currentness"]="superseded"
            constraints.append(item)
    result["constraints"]=constraints
    active=[c for c in constraints if c["currentness"]=="current" and c["cost_scope"]!="subsidy_separate" and c.get("claim_status")!="third_party_report_unconfirmed"]
    if active:
        chosen=active[-1]
        for key in ("raw_quote","amount_min","amount_max","limit_kind","currency","period","cost_scope","allocation","occupants"):result[key]=chosen[key]
        result["evidence"]=[c["evidence"] for c in active]
        result["monthly_unit_rent_cap"]=min((c["monthly_unit_cap"] for c in active if c["monthly_unit_cap"] is not None),default=None)
        result["missing_fields"]=[k for k in ("currency","period","cost_scope","unit_basis","hardness") if chosen[k] in (None,"unknown")]
        result["comparable"]=False  # Legacy true only after a complete verified comparison below.
    return _v4_compare_budget(result,active,store_facts,instant)


def _v4_budget_conflicts(budget):
    """Retain unresolved source claims; never choose a looser cap or sum people."""
    active=[c for c in budget["constraints"] if c["currentness"]=="current" and c["cost_scope"]!="subsidy_separate"]
    conflicts=[]
    for index,left in enumerate(active):
        for right in active[index+1:]:
            same_basis=all(left[k]==right[k] for k in ("subject_ref","currency","period","cost_scope","unit_basis","applicable_phase"))
            if (same_basis and left["interpretation"]==right["interpretation"]=="hard_ceiling"
                    and left["maximum"]!=right["maximum"]):
                conflicts.append({"type":"budget_unresolved_caps","constraint_ids":[left["id"],right["id"]],
                    "evidence_ids":list(dict.fromkeys(left["evidence_ids"]+right["evidence_ids"]))})
    own_per_person=[c for c in active if c["unit_basis"]=="per_person" and c.get("claim_status")!="third_party_report_unconfirmed"]
    reported=[c for c in active if c.get("claim_status")=="third_party_report_unconfirmed"]
    for claim in reported:
        if own_per_person:
            related=own_per_person+[claim]
            conflicts.append({"type":"budget_unconfirmed_shared_limit","constraint_ids":[c["id"] for c in related],
                "evidence_ids":list(dict.fromkeys(e for c in related for e in c["evidence_ids"]))})
    return conflicts


def _v4_compare_budget(result,constraints,store_facts,instant):
    """Opt-in host facts. Never take prices/fixtures from the untrusted source.

    Host must supply request basis + verified, dated, provenance-bearing quotes.
    Advanced billing/allocation without explicit per-constraint amounts stays unknown.
    """
    context=store_facts if isinstance(store_facts,dict) else {}
    request=context.get("request") if isinstance(context.get("request"),dict) else {}
    quotes=context.get("quotes") if isinstance(context.get("quotes"),list) else []
    scenario_results=[]
    if not constraints:return result
    unclear=any(c["hardness"]=="unknown" or c["currency"] is None or c["period"]=="unknown" or c["cost_scope"]=="unknown" for c in constraints)
    if not quotes:
        # Unknown hardness remains a property of the source amount. It does not
        # supply the missing verified quote or make a price comparison possible.
        unresolved_currency=all(c["currency"] is None for c in constraints)
        approximate=any(c["interpretation"]=="approximate" for c in constraints)
        result.update(overall_fit="needs_clarification" if unresolved_currency or approximate else "not_comparable",fit_reason="约数未给出精确容差" if approximate else "预算币种尚未说明" if unresolved_currency else "没有已核实且口径相同的当前报价")
        return result
    for n,fact in enumerate(quotes):
        if not isinstance(fact,dict):continue
        ref=fact.get("id") or f"quote_{n+1}";basis=fact.get("applicability",{})
        if not isinstance(basis,dict):basis={}
        start=_stamp(basis.get("effective_from"));end=_stamp(basis.get("effective_until"))
        valid=(fact.get("verified_for_comparison") is True and bool(fact.get("evidence_reference")) and
               isinstance(basis,dict) and start is not None and end is not None and start<=instant<=end and
               all(request.get(k) is not None and request.get(k)==basis.get(k) for k in ("material_key","room_type","lease_term_months")))
        results=[]
        for c in constraints:
            status="not_comparable";reason="报价来源/有效期/门店房型租期不完整或不匹配";amount=None;floor=None;missing=[];calculation=None
            if valid and c["currency"]==fact.get("currency") and c["hardness"]!="unknown":
                if c["unit_basis"]=="per_person" or c["applicable_phase"]!="unspecified":
                    explicit=fact.get("constraint_amounts",{}).get(c["id"])
                    if isinstance(explicit,dict) and explicit.get("allocation_confirmed") is True and explicit.get("phase")==c["applicable_phase"]:
                        amount=explicit.get("amount")
                        if c.get("allocation_share") is not None:
                            whole=fact.get("monthly_rent")
                            numeric=lambda value:isinstance(value,(int,float)) and not isinstance(value,bool)
                            if (not numeric(amount) or not numeric(whole) or
                                    Decimal(str(amount))!=Decimal(str(whole))*Decimal(str(c["allocation_share"]))):
                                amount=None;reason="逐人核价与双方原文确认的份额不一致，不能替换分摊约定"
                    else:reason="逐人分摊/阶段口径尚未逐项确认，不能用人数或平均值替代"
                elif c["unit_basis"]=="whole_unit" or (request.get("unit_basis")=="whole_unit" and c["subject_ref"] in ("author","beneficiary")):
                    key={"annual_total":"annual_total","upfront":"upfront_total","deposit":"deposit"}.get(c["cost_scope"])
                    if key:amount=fact.get(key)
                    elif c["period"]=="paid_month":amount=fact.get("paid_month_rent")
                    elif c["period"]=="month" and c["cost_scope"]=="rent_only":
                        if c.get("calendar_basis")=="natural_month":
                            amount,calculation=_v4_calendar_payment(c,fact)
                            if amount is None:reason="自然月须同起止日及已核实际计费、舍入规则；不能周价乘4"
                        else:amount=fact.get("monthly_rent")
                    elif c["period"]=="month" and c["cost_scope"]=="all_in":
                        amount=fact.get("monthly_all_in")
                        if amount is None:
                            floor=fact.get("known_mandatory_floor")
                            missing=fact.get("missing_costs",["mandatory_costs"])
                            if isinstance(floor,(int,float)) and not isinstance(floor,bool) and fact.get("remaining_costs_nonnegative") is True and fact.get("unverified_offsets") is False and c["hard_constraint"] is True and c["interpretation"]=="hard_ceiling" and floor>c["maximum"]:
                                status="incompatible";reason="已核必付非负下界已超硬上限；无需猜缺失费用"
                    else:reason="账期不匹配；不把周价乘4或年均数当付租月"
                else:reason="整套/人均单位口径未确认"
                if isinstance(amount,(int,float)) and not isinstance(amount,bool) and amount>=0:
                    minimum=c["minimum"] if c["interpretation"] in ("hard_floor","hard_interval") else None
                    maximum=c["maximum"] if c["interpretation"] in ("hard_ceiling","hard_interval") else None
                    if c["hard_constraint"] is True and ((minimum is not None and amount<minimum) or (maximum is not None and amount>maximum)):
                        status="incompatible";reason="同口径已核金额违反明确硬约束"
                    else:status="compatible";reason="同口径当前已核金额满足本项约束；不证明库存或支付能力"
            if c["hardness"]=="unknown" or c["currency"] is None or c["period"]=="unknown" or c["cost_scope"]=="unknown":status="needs_clarification";reason="预算硬软、币种或计价口径未说明"
            results.append(status)
            result["comparisons"].append({"constraint_id":c["id"],"store_fact_ref":ref,"applicable":valid,
                "result":status,"reason":reason,"scenario_id":ref,"phase":c["applicable_phase"],"billing_basis":c["period"],
                "compared_amount":amount,"calculation":calculation,
                "known_mandatory_floor":floor,"missing_costs":missing,"allocation_evidence_ids":c.get("allocation_evidence_ids",[])[:]})
        # One contract AND. Alternatives OR; never borrow costs across quotes.
        status="incompatible" if "incompatible" in results else "needs_clarification" if "needs_clarification" in results else "not_comparable" if "not_comparable" in results or not results else "compatible"
        scenario_results.append((ref,status))
    statuses=[s for _,s in scenario_results]
    overall="compatible" if "compatible" in statuses else "incompatible" if statuses and all(s=="incompatible" for s in statuses) else "needs_clarification" if "needs_clarification" in statuses or unclear else "not_comparable"
    result.update(overall_fit=overall,fit_reason="同报价内全部约束AND，可选报价间OR；不推断库存或支付能力",certainty="clear" if overall in ("compatible","incompatible") else "unresolved",comparable=overall in ("compatible","incompatible"))
    result["scenario_groups"]=[{"id":"alternatives_1","kind":"alternative_quotes","scenario_ids":[r for r,_ in scenario_results],"within_scenario_logic":"AND","between_scenario_logic":"OR","evidence_basis":"trusted_host_verified_quotes","results":dict(scenario_results)}]
    return result


def _v4_calendar_payment(constraint,fact):
    """One explicit source interval; no generic week-to-month normalization."""
    billing=fact.get("billing");interval=constraint.get("billing_interval")
    if not isinstance(billing,dict) or not interval:return None,None
    if any(billing.get(k)!=interval[k] for k in ("start","end")):return None,None
    if billing.get("rule")!="days/7 prorated" or billing.get("rounding")!="half_up_2_decimal":return None,None
    weekly=fact.get("weekly_rent")
    if not isinstance(weekly,(int,float)) or isinstance(weekly,bool) or weekly<0:return None,None
    try:
        days=(datetime.fromisoformat(interval["end"])-datetime.fromisoformat(interval["start"])).days+1
        if type(billing.get("charge_days")) is not int or billing["charge_days"]!=days:return None,None
        amount=(Decimal(str(weekly))*Decimal(days)/7).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP)
        return float(amount),f"{weekly}*{days}/7; half_up_2_decimal={amount}"
    except (ValueError,InvalidOperation,OverflowError):return None,None


def _v4_income(source,clauses,proxy,evidence):
    claims=[];legacy=None;carry_subject=None;full="；".join(c["text"] for c in clauses)
    for c in clauses:
        v=c["text"]
        cue=re.search(r"收入|月薪|年薪|年包|工资|薪资|奖金|住房补贴",v)
        if not cue:continue
        # Refusing income is valid missing information, never an estimate.
        if re.search(r"不(?:方便|想|愿|提供|透露)|拒绝|保密",v):continue
        subject="couple" if re.search(r"夫妻|两口|我俩",v) else "household" if re.search(r"家庭|全家|我们家",v) else c["subject"] if c["subject"] not in ("author","beneficiary") else "third_party" if c["unowned_quote"] or re.search(r"(?:我(?:的)?)?(?:朋友|同事|妹妹|姐姐|他|她).{0,8}(?:收入|工资|月薪|年薪)",v) else "author" if _OWN.search(v) or re.search(r"^(?:税前|税后)?(?:月薪|月收入|年薪|年收入)",v) else carry_subject
        if subject is None:continue
        if re.search(r"补贴|奖金",v) and not re.search(r"收入|月薪|年薪|年包|工资|薪资",v) and carry_subject:subject=carry_subject
        carry_subject=subject
        for m in _MONEY.finditer(v):
            amount=_amount(m["lo"]);maximum=_amount(m["hi"]) if m["hi"] else amount
            if amount is None or maximum is None or amount<100:continue
            near=v[max(0,m.start()-14):m.end()+6]
            component="housing_subsidy" if re.search(r"补贴",near) else "bonus" if re.search(r"奖金",near) else "salary_package" if "年包" in v else "reported_income"
            included=bool(re.search(r"包含|已含|里面.{0,4}含|已经含|含有",v))
            relation="included" if included and component in ("bonus","housing_subsidy") else "aggregate" if subject in ("couple","household") or component=="salary_package" else "unspecified"
            parent=next((x for x in reversed(claims) if x["income_subject_ref"]==subject and x["income_component"] not in ("bonus","housing_subsidy")),None)
            item={"id":f"income_{len(claims)+1}","raw":c["quote"],"speaker_ref":c["speaker"],"income_subject_ref":subject,"subject_type":subject,
                "income_component":component,"currency":_currency(v,"") or (parent["currency"] if included and parent else None),"period":_period(v) if _period(v) in ("month","year") else "year" if "年包" in v else "unknown",
                "tax_basis":"net" if "税后" in v else "gross" if "税前" in v else "unknown","minimum":amount,"maximum":maximum,"amount":amount if not m["hi"] else None,
                "source_type":"third_party_report_unconfirmed" if subject=="third_party" or c.get("reported_source") or subject not in ("author","couple","household") else "voluntary_questionnaire" if source.get("source_type")=="voluntary_questionnaire" else "voluntary_self_report",
                "verification":"unverified_not_financial_proof","evidence_ids":[evidence(c,"INCOME_REPORTED")],"component_relation":relation,
                "included_in_claim_ref":parent["id"] if included and parent else None,
                "fixed_or_variable":"variable_or_expected" if component=="bonus" or re.search(r"预计|可能|浮动",v) else "unknown","income_group_ref":subject}
            claims.append(item)
            if legacy is None and subject=="author" and not proxy and component not in ("bonus","housing_subsidy"):
                legacy={"raw_quote":c["quote"],"subject":"self","self_reported":True,"verified":False,"amount_min":amount,"amount_max":maximum,
                    "currency":item["currency"],"period":item["period"],"tax_basis":item["tax_basis"],"stability":"unknown","as_of":source.get("source_created_at") or source.get("published_at"),
                    "evidence":[{"signal_id":"INCOME_SELF_REPORTED","source_id":source.get("source_id"),"quote":c["quote"],"start":c["start"],"end":c["end"],"offset_unit":"unicode_codepoint"}]}
    target=any(c["income_subject_ref"]=="author" and not proxy for c in claims)
    return {"claims":claims,"target_subject_status":"voluntary_self_report_unverified" if target else "unknown",
            "certainty":"limited" if claims else "unresolved","reason":"仅记录逐项自报/转述及内含关系；不合计、不推测目标个人月收入或支付能力"},legacy


def _v4_context(result,text,clauses,evidence,store_facts):
    contact=result["contact_permission"]
    for c in clauses:
        v=c["text"]
        if c["unowned_quote"] or c["speaker"] in ("商家","客服","房东"):continue
        if re.search(r"别联系|不要联系|不用再联系|不同意.{0,8}联系|不想.{0,4}联系|拒绝.{0,4}联系|别私信|不要私信|别打电话|不要打电话|不同意电话|撤回.{0,5}(?:同意|授权)",v):
            channels=["phone"] if re.search(r"别打电话|不要打电话|不同意电话",v) else ["direct_message"] if re.search(r"别私信|不要私信",v) else ["all"]
            contact["channels_denied"].extend(channels);contact["evidence_ids"].append(evidence(c,"CONTACT_DENIED"));contact["withdrawn"]=bool(re.search(r"撤回",v))
        if re.search(r"(?:可以|同意|允许|只许).{0,10}(?:微信|文字联系|私信|联系我)",v) and not re.search(r"不(?:可以|同意|允许)|禁止",v):
            channel="wechat_text" if re.search(r"微信|文字",v) else "direct_message" if "私信" in v else "unspecified"
            purpose="current_contract" if re.search(r"本次合同|这次合同",v) else "current_rental_request"
            contact["channels_allowed"].append(channel);contact["purpose_scope"].append(purpose);contact["validity"]="current_request_only";contact["evidence_ids"].append(evidence(c,"CONTACT_ALLOWED"))
        if result["role"]=="proxy_renter" and re.search(r"只和我.{0,5}(?:沟通|联系).{0,5}(?:约看|看房)",v):
            contact.update(status="limited",purpose_scope=["viewing_only"],validity="current_request_only",
                           permission_label="proxy_limited_viewing_only",beneficiary_contact_permission="unknown")
            contact["evidence_ids"].append(evidence(c,"CONTACT_ALLOWED"))
    contact["channels_allowed"]=list(dict.fromkeys(contact["channels_allowed"]))
    contact["channels_denied"]=list(dict.fromkeys(contact["channels_denied"]))
    if "all" in contact["channels_denied"]:
        contact["status"]="denied";contact["channels_allowed"]=[];result["next_step"]="no_contact"
    elif contact["channels_allowed"]:contact["status"]="limited"
    elif contact["channels_denied"]:contact["status"]="limited"
    names=list(dict.fromkeys(m.group() for m in _PLACE.finditer(text)))
    cities=[city for city in ("上海","北京","杭州","苏州","南京","深圳") if city in text]
    ambiguous=[name for name in ("沙河","COSTCO","开市客","江鹏路","余杭") if name.lower() in text.lower() and not cities]
    store=result["store_match"]
    destinations=re.search(r"到\s*([A-Za-z0-9]+)\s*和\s*([A-Za-z0-9]+)\s*(?:两个)?地点",text)
    same_site_and=bool(destinations and re.search(r"同一(?:住处|房|住所).{0,20}必须",text))
    preferred=[n for n in names if re.search(re.escape(n)+r"(?:优先|首选)",text)]
    fallback=[n for n in names if re.search(re.escape(n)+r"(?:备选|其次)",text)]
    store.update(city_confirmed=cities[0] if len(cities)==1 else None,unresolved_names=ambiguous,
                 geographic_logic="AND" if same_site_and else "OR" if re.search(r"或者|或是|任选|[或/]",text) and len(names)>1 else "AND" if re.search(r"同时|都必须|既.{0,20}又",text) and len(names)>1 else "unknown",
                 priority=list(dict.fromkeys(preferred+fallback)) or ([names[0]] if names and re.search(r"优先|首选",text) else []),
                 destinations=list(destinations.groups()) if destinations else names)
    if ambiguous:result["manual_review"]["reasons"].append("geographic_name_requires_confirmation")
    # Record hard/soft needs without inventing service promises or POI distances.
    for c in clauses:
        v=c["text"]
        if c["unowned_quote"]:continue
        if re.search(r"电梯|独立厨房|养.{0,3}(?:猫|狗)|宠物|通勤|短租|个月|距离|公里",v):
            result["needs_fit"]["items"].append({"need":c["quote"],"hard_or_soft":"hard" if re.search(r"必须|一定|不能|不超过|不得",v) else "unknown",
                "subject_ref":c["subject"],"source_evidence_ids":[evidence(c,"NEEDS_FIT")],"store_fact_ref":None,"result":"pending_verification","reason":"须核对同一门店、房型、租期或实际路线；不改变租住意向"})
    if same_site_and:
        _v4_compare_routes(result,text,store_facts)


def _v4_compare_routes(result,text,store_facts):
    """Routes are verified per physical site; never union separate properties."""
    host=store_facts if isinstance(store_facts,dict) else {}
    sites=host.get("route_sites",[])
    bound=re.search(r"步行\s*(\d+(?:\.\d+)?)公里(?:内|以内)",text)
    if not bound or not isinstance(sites,list):return
    maximum=float(bound[1]);destinations=result["store_match"]["destinations"]
    instant=_stamp(result["as_of"]);statuses=[];site_results=[]
    for site in sites:
        if not isinstance(site,dict):continue
        start=_stamp(site.get("effective_from"));end=_stamp(site.get("effective_until"))
        valid=(site.get("verified_for_comparison") is True and bool(site.get("id")) and bool(site.get("evidence_reference"))
               and start is not None and end is not None and start<=instant<=end)
        routes=site.get("routes",[]) if isinstance(site.get("routes"),list) else []
        values=[]
        for destination in destinations:
            matching=[r for r in routes if isinstance(r,dict) and r.get("destination")==destination and r.get("mode")=="walk"]
            distance=matching[0].get("distance_km") if len(matching)==1 else None
            values.append(distance if valid and isinstance(distance,(int,float)) and not isinstance(distance,bool) and distance>=0 else None)
        status="incompatible" if any(v is not None and v>maximum for v in values) else "compatible" if values and all(v is not None for v in values) else "pending_verification"
        statuses.append(status);site_results.append({"physical_site_ref":site.get("id"),"result":status,"destination_logic":"AND","evidence_reference":site.get("evidence_reference") if valid else None})
        if valid:result["store_match"]["physical_site_refs"].append(site["id"])
    overall="compatible" if "compatible" in statuses else "incompatible" if host.get("route_candidates_complete") is True and statuses and all(s=="incompatible" for s in statuses) else "pending_verification"
    result["needs_fit"].update(overall=overall,physical_site_comparisons=site_results,
        reason="同一物理住处内目的地AND，候选住处间OR；路线须独立核实且时效有效")
    for item in result["needs_fit"]["items"]:
        if re.search(r"步行.{0,6}公里",item["need"]):
            item.update(result=overall,store_fact_ref="verified_physical_route_candidates" if overall!="pending_verification" else None,
                        reason=result["needs_fit"]["reason"])


def evaluate_rental_source(source, now=None, *, rule_version=None, store_facts=None):
    """Pure evidence assessment. Facts are a separate trusted-host input, never comment instructions.

    This is a conservative local implementation of the V4 contract, not a probability
    model. Missing or unsupported evidence remains unknown. Nothing here sends,
    changes a historical grade, verifies identity, or grants contact permission.
    """
    source=deepcopy(source) if isinstance(source,dict) else {}
    instant=_stamp(now) or datetime.now(TZ)
    published=_stamp(source.get("source_created_at") or source.get("published_at")) if source.get("source_created_at") or source.get("published_at") else None
    captured=_stamp(source.get("captured_at") or source.get("collected_at")) if source.get("captured_at") or source.get("collected_at") else None
    result=_v4_empty(source,instant,published,captured,rule_version or RULE_VERSION)
    text=source.get("text") if isinstance(source.get("text"),str) else ""
    invalid=(not text.strip() or len(text)>32000 or not source.get("source_id") or
             source.get("source_type") not in ("comment","customer_message","staff_note","voluntary_questionnaire") or
             source.get("author_subject","self") not in ("self","authorized_proxy") or
             source.get("truncated") is True or bool(re.search(r"原文不全|截图不全|文字不完整|截断|只看到.{0,4}想租[…\.]+",text)))
    if invalid or published and published>instant+timedelta(minutes=5):
        result["intent"].update(rule_id="R0",reason="来源、原文、主体或原始时间不足")
        result["review_reasons"]=["source_or_subject_unknown" if invalid else "source_time_in_future"]
        result["manual_review"]["reasons"]=result["review_reasons"][:]
        return result
    proxy=source.get("author_subject")=="authorized_proxy" or bool(re.search(r"(?:我|本人).{0,3}(?:帮|替|代).{0,8}(?:找|租)|帮(?:我)?(?:妹妹|姐姐|朋友|同事|员工).{0,8}(?:找|租)|帮[一二两三四五六七八九\d]+位?员工.{0,8}租|替.{0,8}(?:找|租)",text))
    clauses=_v4_clauses(text,proxy)
    repost_only=not proxy and bool(re.search(r"转发",text) and re.search(r"(?:我|本人)不(?:找|租)",text)
        and re.search(r"不参与代找|不代找|不帮.{0,4}找|不代理",text))
    owned=[c for c in clauses if not c["unowned_quote"] and c["speaker"] not in ("商家","客服","房东") and c["subject"]!="third_party"]
    ev={}
    def evidence(c,signal):
        item=_v4_evidence(source,c,signal,published,captured,instant)
        if item["id"] not in ev:ev[item["id"]]=item
        return item["id"]
    needs=[];supply=[];closed=[];actions=[];historical=[];conditional=False;future=False;unknown_time=False
    need_pattern=re.compile(_NEED.pattern+r"|(?:在|正在|还在|重新|需要).{0,8}(?:找|换)(?:一套|个|套)?.{0,8}(?:房|公寓)|(?:下周|下月|月底|马上).{0,8}(?:搬|入住)|(?:要|需要|想).{0,5}(?:住|租).{0,8}(?:公寓|一居|两居|三居|方隅)|(?:租|起租).{0,12}(?:一居|两居|三居|公寓)|找.{0,8}短住|(?:项目|出差).{0,8}住.{0,5}(?:个月|月)")
    for c in owned:
        v=c["text"]
        is_supply=bool((_SUPPLY.search(v) or re.search(r"欢迎客户|欢迎.{0,5}看房|房源多|招聘.{0,6}包住",v)) and not re.search(r"不是转租|不转租|不要转租",v))
        if is_supply:supply.append(c)
        negative=bool(_CLOSED.search(v) or _NEGATED_NEED.search(v) or re.search(r"完全不租|不再租|不找房|没有找房需求|没有租住计划|已经.{0,5}(?:签了|签好|签约)|不换房|不搬了",v))
        if negative:closed.append(c)
        # Combine ellipsis only inside the same explicit subject's source. A wish
        # to live near a restaurant alone remains a wish, not a rental request.
        subject_text="；".join(x["text"] for x in owned if x["subject"]==c["subject"])
        lease_duration=bool(re.search(r"(?:一居|两居|三居|房|公寓).{0,5}租(?:一|两|三|\d)(?:年|个月)|年租租金",v))
        scoped_rent_context=bool(re.search(r"预算|租金|月租|年租",subject_text) and
                                 re.search(r"看.{0,5}(?:一居|两居|三居|房)|看房",subject_text) and
                                 re.search(r"(?:我|本人|下月|下周).{0,15}(?:住|入住|搬)",subject_text))
        elliptical_need=scoped_rent_context and bool(re.search(r"住|入住|搬|年租|看.{0,5}(?:一居|两居|三居)",v))
        is_need=bool(need_pattern.search(v) or _COMMERCIAL.search(v) or lease_duration or elliptical_need) and not negative
        # A source quote/merchant rent, occupation and general desire never create need.
        if is_supply and not re.search(r"自己|我还|另外.{0,5}我|同时.{0,5}我",v):is_need=False
        if repost_only or re.search(r"(?:只是|仅|纯).{0,5}(?:转发|转述|研究|调研)|不是我.{0,4}(?:找|租)|我不(?:帮|代).{0,4}(?:找|租)",text) and not proxy:is_need=False
        is_historical=bool((_HISTORICAL.search(v) or re.search(r"上周|上个月|昨天.{0,4}说|昨日.{0,4}说",v)) and not _CURRENT.search(v))
        if is_need and not is_historical:
            needs.append(c);evidence(c,"RENTAL_NEED")
            # Fit contingencies (pets/room/commute) are not absence of present need.
            conditional=conditional or bool(_CONDITIONAL.search(v) and not re.search(r"现在|正在|还在|已决定|确定要",text) and not re.search(r"如果有(?:空)?房|有房的话",v))
            future=future or bool(_LOW.search(v) or re.search(r"明年|以后.{0,8}(?:租|搬)|暂时.{0,5}(?:了解|看看)|只是先",v))
        action_mention=bool(re.search(r"看房|约看|视频.{0,5}(?:看|房)|合同|签约|签租|订这套|搬入|入住",v) or needs and re.search(r"(?:明天|今天|下周|周[一二三四五六日天]).{0,10}(?:看|视频)|(?:一起去|下午|上午|晚上).{0,4}看",v))
        if action_mention and not re.search(r"本次合同|说明.{0,4}合同",v):
            merchant=c["speaker"] in ("商家","客服","房东")
            unable=bool(re.search(r"(?:不能|无法|没法|暂不|暂时不|不方便).{0,4}(?:看|约)|(?:还没|尚未|没有).{0,3}约(?:看|好|房)?",v))
            status="offered" if merchant else "cancelled" if _CANCEL.search(v) else "unknown" if unable else "completed" if re.search(r"(?:已经|上次|昨天|之前).{0,5}(?:看过|看完|签完)",v) else "confirmed" if re.search(r"已约好|约好了|已预约|预约成功|双方确认|已经约定",v) else "inquiry" if re.search(r"什么时候|何时|几时|能看房吗|可以看房吗",v) and not _event_days(v,published) else "requested"
            if status=="requested" and re.search(r"合同|签约",v) and not _CONTRACT.search(v) and not re.search(r"(?:视频|核对|核|审阅|签署).{0,5}合同|合同.{0,5}(?:发来|核对|审阅)",v) and not _event_days(v,published):status="inquiry"
            days=_event_days(v,published)
            relative=bool(re.search(r"今天|明天|后天|下周|本周|周[一二三四五六末日天]|月底",v))
            currentness="historical" if is_historical or days and days[1]<instant.date() else "unresolved" if relative and not published else "conditional" if re.search(r"核实后|确认后|满足后|如果.{0,20}再|的话.{0,8}再",v) else "current"
            aid=evidence(c,"ACTION")
            viewer=re.search(r"(妹妹|姐姐|朋友|同事|哥哥|弟弟)(?:替我|帮我|代我).{0,20}看",v)
            actor_ref="viewing_agent_"+viewer[1] if viewer else c["speaker"]
            if viewer and actor_ref not in result["subjects"]["viewing_agent_refs"]:
                result["subjects"]["viewing_agent_refs"].append(actor_ref)
                result["authority_claims"].append({"agent_ref":actor_ref,"beneficiary_ref":"author","scope":"viewing","status":"claimed",
                    "claim_source_type":"beneficiary_self_report","evidence_ids":[aid],"verification":"unconfirmed_not_legal_authority"})
            record={"id":f"action_{len(actions)+1}","request_ref":"request_1","actor_ref":actor_ref,
                    "kind":"viewing" if re.search(r"看|视频",v) else "contract" if re.search(r"合同|签|订这套",v) else "move_in",
                    "status":status,"scheduled_at":days[0].isoformat() if days else None,"evidence_ids":[aid],"currentness":currentness}
            actions.append(record)
            if currentness=="historical":historical.append(record)
            if currentness=="unresolved":unknown_time=True
    # An explicit professional request for clients is a supply-side activity.
    # Profession/nickname alone never excludes a person's own rental need.
    # Only unquoted author clauses may establish either side of this decision.
    professional=[c for c in owned if re.search(
        r"(?:我是|我做|本人是|我们是).{0,6}(?:中介|房产经纪|租赁经纪)|(?:同行|中介).{0,6}合作|(?:带客|客源).{0,6}(?:合作|返佣|佣金)",c["text"])]
    client_request=[c for c in owned if re.search(r"(?:帮|替|代).{0,6}客户.{0,8}(?:找|租|看)|客户.{0,6}(?:找房|求租|要租)",c["text"])]
    if professional and (client_request or any(re.search(r"合作|返佣|佣金",c["text"]) for c in professional)):
        personal=re.compile(r"(?:我(?:自己|本人)?|本人|我们(?:自己)?)(?:现在|目前|还在|正在|准备|计划|打算|下月|下个月|也|还)?(?:想|要|需要|在)?(?:租|找(?:一|两|三|个|套|房|公寓)|换租|搬入|入住)|(?:我自己|我本人|我们自己).{0,12}(?:租|找房|入住|换租)")
        needs=[c for c in needs if c["subject"]=="author" and personal.search(c["text"])
            and not re.search(r"(?:帮|替|代).{0,6}客户",c["text"])]
        for c in professional+client_request:
            if c not in supply:supply.append(c)
            evidence(c,"PROFESSIONAL_BROKERAGE")
    # Merchant offers are retained as offers, never customer confirmation.
    for c in clauses:
        if c["speaker"] in ("商家","客服","房东") and re.search(r"看房|约看|视频|签约",c["text"]):
            actions.append({"id":f"action_{len(actions)+1}","request_ref":"request_1","actor_ref":c["speaker"],"kind":"viewing","status":"offered","scheduled_at":None,"evidence_ids":[evidence(c,"ACTION_OFFER")],"currentness":"current"})
    result["action_records"]=actions
    if historical:
        result["historical_intent"]=[{"grade":"high","evidence_ids":a["evidence_ids"],"reason":"历史推进动作，仅作历史证据"} for a in historical if a["status"] in ("requested","confirmed","completed")]
    beneficiary="beneficiary" if proxy else "author"
    allocation=_v4_confirmed_allocation(owned,needs,evidence)
    beneficiary_refs=allocation["beneficiary_refs"] if allocation else [beneficiary] if needs else []
    result["subjects"]["beneficiary_refs"]=beneficiary_refs[:]
    result["role"]="proxy_renter" if proxy and needs else "self_renter" if needs else "supplier_or_agent" if supply else "researcher" if re.search(r"调研|研究报告|论文",text) else "unknown"
    result["request_groups"]=([{"request_ref":"request_1","beneficiary_refs":beneficiary_refs[:],"role":result["role"],"evidence_ids":[evidence(c,"RENTAL_NEED") for c in needs],"allocation_policy":allocation["allocation_policy"] if allocation else "unknown","allocation_evidence_ids":allocation["allocation_evidence_ids"][:] if allocation else []}] if needs else [])
    if supply:
        result["request_groups"].append({"request_ref":"supply_1","beneficiary_refs":[],"role":"supplier_or_agent","evidence_ids":[evidence(c,"SUPPLY") for c in supply],"allocation_policy":"not_applicable","allocation_evidence_ids":[]})
    if proxy:
        result["authority_claims"].append({"agent_ref":"author","beneficiary_ref":"beneficiary","scope":"search","status":"claimed","claim_source_type":"source_report","evidence_ids":[evidence(c,"RENTAL_NEED") for c in needs],"verification":"unconfirmed_not_legal_authority"})
        for c in owned:
            v=c["text"]
            scopes=[]
            if re.search(r"(?:同意|授权|允许).{0,6}(?:我|代).{0,5}(?:约看|看房)",v):
                scopes.append(("viewing","claimed_third_party_unconfirmed"))
            denied=re.search(r"(?:不能|不允许|未授权|无权).{0,15}(?:代签|签约|付定金|付款|支付)",v)
            if denied:
                if re.search(r"代签|签约",denied.group()):scopes.append(("signing","denied"))
                if re.search(r"付定金|付款|支付",v[denied.start():]):scopes.append(("payment","denied"))
            for scope,status in scopes:
                result["authority_claims"].append({"agent_ref":"author","beneficiary_ref":"beneficiary","scope":scope,"status":status,
                    "claim_source_type":"third_party_report" if status!="denied" else "agent_self_report",
                    "evidence_ids":[evidence(c,"AUTHORITY")],"verification":"unconfirmed_not_legal_authority"})
    for c in owned:
        if re.search(r"想住|希望.{0,8}住|住到.{0,8}附近|有点想住",c["text"]):
            result["housing_desire"]={"state":"future" if re.search(r"以后|未来|将来|有点|希望",c["text"]) else "current","location":None,"evidence_ids":[evidence(c,"HOUSING_DESIRE")]}
    result["rental_need"].update(confirmed=bool(needs),lease_type="short_stay" if re.search(r"两晚|三晚|\d+晚|短住|两天|旅游住",text) else "long_term" if "长租" in text else "month_based" if re.search(r"[一二两三四五六\d]+个月|月租",text) else "unknown",evidence_ids=[evidence(c,"RENTAL_NEED") for c in needs],certainty="clear" if needs else "unresolved")
    budget_clauses=[c for c in clauses if c in owned or (c["subject"]=="third_party" and
        re.search(r"(?:朋友|同事).{0,3}说.{0,8}(?:合计|共同上限|总共)",c["text"]))]
    result["budget"]=_v4_budget(source,budget_clauses,result["budget"],evidence,store_facts,instant,allocation)
    budget_conflicts=_v4_budget_conflicts(result["budget"])
    if budget_conflicts:
        result["conflicts"].extend(budget_conflicts)
        result["budget"].update(overall_fit="needs_clarification",comparable=False,certainty="unresolved",fit_reason="预算声明冲突或共同上限仅为未确认转述，须分别核实")
        result["manual_review"]["reasons"].append("unresolved_budget_claims")
    result["income"],result["income_self_report"]=_v4_income(source,clauses,proxy,evidence)
    _v4_context(result,text,clauses,evidence,store_facts)
    current_actions=[a for a in actions if a["currentness"]=="current" and a["status"] in ("requested","confirmed") and a["actor_ref"] not in ("商家","客服","房东")]
    specific=bool(_ROOM.search(text) or _PLACE.search(text) or re.search(r"通勤|地铁|预算|房租|租金|个月|[一二三四\d]+晚|(?:在|找|租|住)(?:[一-鿿]{2,10})(?:公寓|方隅)",text))
    conditional=conditional or bool(needs and re.search(r"如果|假如|要是|倘若",text) and re.search(r"才租|可能租|才考虑搬|调动没确定|换工作",text))
    future=future or bool(needs and re.search(r"现在只是看看|明年|只是先了解",text))
    reopened=bool(re.search(r"重新|又开始|再次|继续找|仍在找|还在找",text))
    conflict=bool(needs and closed and re.search(r"我现在.{0,8}(?:要租|找房|要找|想租)",text) and re.search(r"我现在.{0,5}(?:完全不租|不租|不找)",text) and not reopened)
    closed_final=bool(closed and (not needs or closed[-1]["start"]>needs[-1]["start"]) and not reopened)
    reasons=[]
    if conflict:
        grade,rule,lifecycle,reason="insufficient","R3","unknown","当前租住需求存在未消解的矛盾"
        result["conflicts"].append({"type":"current_rental_need","evidence_ids":[evidence(c,"NEED_CONFLICT") for c in [*needs,*closed]]})
        reasons.append("contradictory_current_need")
    elif not needs and (supply or repost_only or re.search(r"调研|竞品研究|研究报告|论文|招聘|只转发|只是转发|不是我租|不是我找|只想知道.{0,8}KTV|餐厅.{0,5}好吃|吃饭.{0,5}推荐",text)):
        grade,rule,lifecycle,reason="insufficient","R1","not_prospect","当前只有供应、研究或明确非本人租住用途"
        result["role"]="supplier_or_agent" if supply or re.search(r"招聘",text) else "researcher" if re.search(r"研究|调研|论文",text) else "non_rental"
    elif closed_final:
        resolved=bool(re.search(r"(?:已经|早就).{0,5}(?:租|签|找好)|已租|已签|已找好",text))
        grade,rule,lifecycle,reason="low","R2","resolved" if resolved else "declined","当前租住需求已解决或明确否定"
        result["role"]="self_renter" if not proxy else "proxy_renter"
    elif not needs and (supply or re.search(r"调研|研究报告|论文|招聘|不找房|不租房|只转发|只是转发|不是我租|不是我找",text)):
        grade,rule,lifecycle,reason="insufficient","R1","not_prospect","当前只有供应、研究或明确非本人租住用途"
    elif (historical and not reopened and not current_actions) or unknown_time:
        grade,rule,lifecycle,reason="insufficient","R_TIME","unknown","原行动已过或相对时间缺原始时间，需重新确认当前状态"
        reasons.append("expired_or_unanchored_action_requires_reconfirmation")
    elif needs and (conditional or future):
        grade,rule,lifecycle,reason="low","R6","conditional" if conditional else "future","租住需求尚待触发或明确远期了解"
    elif needs and current_actions and specific:
        grade,rule,lifecycle,reason="high","R4","active","明确租住需求、具体条件和当前真实推进请求；请求不等于预约确认"
    elif needs and specific:
        grade,rule,lifecycle,reason="medium","R5","active","明确租住需求和具体条件，尚无当前真实推进动作"
    elif needs:
        grade,rule,lifecycle,reason="insufficient","R7","unknown","租住语义存在，但缺少可确认的具体需求证据"
    else:
        grade,rule,lifecycle,reason="insufficient","R7","unknown","兴趣、泛问或居住愿望不足以证明当前租住需求"
    ids=list(dict.fromkeys([evidence(c,"RENTAL_NEED") for c in needs]+[i for a in current_actions for i in a["evidence_ids"]]))
    result["intent"]={"grade":grade,"rule_id":rule,"reason":reason,"evidence_ids":ids,"certainty":"unresolved" if grade=="insufficient" else "clear","currentness":"current" if lifecycle in ("active","conditional","future","resolved","declined") else "unknown"}
    legacy="unknown" if grade=="insufficient" else grade
    result.update(level=legacy,intent_level=legacy,lifecycle=lifecycle,reason=reason,
                  eligibility="rental_seeker" if needs and not closed_final else "non_target" if lifecycle in ("not_prospect","resolved","declined") else "uncertain",
                  roles=(["rental_seeker"] if needs else [])+(["housing_supplier"] if supply else []),
                  stay_purpose="short_stay_apartment" if result["rental_need"]["lease_type"]=="short_stay" else "residential_rental" if needs else "unknown")
    result["fit_status"]=result["budget"]["overall_fit"]
    reasons.extend(result["manual_review"]["reasons"])
    if published is None:reasons.append("source_published_time_unknown")
    if needs:reasons.append("property_price_and_store_mapping_unverified")
    result["review_reasons"]=list(dict.fromkeys(reasons))
    result["review_required"]=bool(result["review_reasons"] or grade=="insufficient")
    result["manual_review"]={"needed":result["review_required"],"reasons":result["review_reasons"][:]}
    result["evidence"]=list(ev.values())
    return result


class RentalAssessmentPermissionError(PermissionError):
    code="RENTAL_ASSESSMENT_FORBIDDEN"
    status=403
    mutation_committed=False


class RentalAssessmentService:
    """Server-only persisted-source seam; no client text and no provider calls.

    store_id is trusted Backend context, not an identity grant. The original
    Core remains the task/account authority. Historical unbound rows remain
    explicitly unknown. Version+source hashes retain prior sidecar assessments.
    """
    @staticmethod
    def rule_overview():
        """Expose the explanation from this exact injected evaluator module."""
        return rule_overview()

    def __init__(self,core,company,*,rule_version=None,store_id=None,clock=None):
        company=deepcopy(company) if isinstance(company,dict) else {}
        managed=company.get("managedWorkspace") or {}
        if (company.get("id")!="fangyu-apartment-client" or company.get("edition")!="customer"
            or company.get("personalMode") is not False or company.get("authMode")!="managed"
            or not isinstance(managed.get("environment_id"),str) or not managed["environment_id"]):
            raise RentalAssessmentPermissionError("租房判断需要可信方隅企业配置")
        if store_id is not None and (not isinstance(store_id,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}",store_id)):
            raise RentalAssessmentPermissionError("门店范围格式无效")
        version=rule_version or RULE_VERSION
        if not isinstance(version,str) or not version or len(version)>180:
            raise ValueError("规则版本格式无效")
        self.core=core;self.company=company;self.store_id=store_id;self.rule_version=version
        self.clock=clock or (lambda:datetime.now(TZ))
        self.tenant="cloud-"+hashlib.sha256((managed["environment_id"]+"\n"+company["id"]).encode()).hexdigest()[:24]

    def _get(self,db,entity,ident):
        if not isinstance(ident,str) or not ident or len(ident)>180:return None
        row=db.execute("SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?",(entity,ident,self.tenant)).fetchone()
        return json.loads(row["body"]) if row else None

    def _actor(self,db,user):
        current=self._get(db,"users",user.get("id")) if isinstance(user,dict) else None
        keys=("id","tenant_id","username","role","cloud_bound")
        if (not current or current.get("disabled") or current.get("cloud_bound") is not True
            or current.get("development_local_only") is True or current.get("role") not in ("operator","admin")
            or current.get("tenant_id")!=self.tenant or not current.get("username")
            or any(current.get(k)!=user.get(k) for k in keys)):
            raise RentalAssessmentPermissionError("当前员工身份或企业范围已变化")
        return current

    def _scope(self,db,user,lead):
        if (not isinstance(lead,dict) or lead.get("tenant_id")!=self.tenant
            or lead.get("cloud_owner") not in (None,"",user["username"])):
            raise RentalAssessmentPermissionError("只能判断当前员工自己的来源评论")
        task=self._get(db,"tasks",lead.get("task_id"))
        if not task:
            if not lead.get("cloud_owner"):
                raise RentalAssessmentPermissionError("历史来源无可核实员工归属或来源任务")
            return None,None,["task_identity_unknown"]
        if task.get("tenant_id")!=self.tenant or task.get("cloud_owner")!=user["username"]:
            raise RentalAssessmentPermissionError("来源任务不属于当前员工")
        try:self.core._task_access(user,task,self.tenant,db=db)
        except (ValueError,PermissionError) as exc:
            raise RentalAssessmentPermissionError("原任务或账号权限已变化") from exc
        context=self._get(db,"rental_task_context_v1",task["id"])
        if context and (context.get("owner")!=user["username"] or context.get("tenant_id")!=self.tenant):
            raise RentalAssessmentPermissionError("来源判断上下文归属无效")
        values=[v for v in (task.get("store_id"),lead.get("store_id"),(context or {}).get("store_id")) if v not in (None,"")]
        if any(not isinstance(v,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}",v) for v in values):
            return task,None,["store_identity_unknown"]
        if values and (len(set(values))!=1 or self.store_id is not None and values[0]!=self.store_id):
            raise RentalAssessmentPermissionError("来源不属于当前门店范围")
        # A source-only label is insufficient to claim its unbound historical task.
        bound=bool(task.get("store_id") or (context or {}).get("store_id"))
        issues=[] if bound and values else ["unverified_historical_scope"]
        if not lead.get("cloud_owner"):issues.insert(0,"legacy_lead_owner_unverified")
        return task,values[0] if values and bound else None,issues

    def _source(self,lead,task,store_id,issues):
        source={"text":lead.get("text") if isinstance(lead.get("text"),str) else "",
                "source_id":lead.get("source_id"),"source_type":lead.get("source_type"),
                "author_subject":"self" if lead.get("author_id") or lead.get("author") else "unclear",
                "published_at":lead.get("published_at"),"collected_at":lead.get("created_at"),"history":[],
                "persisted_scope":{"tenant_id":self.tenant,"owner":lead.get("cloud_owner"),
                                   "lead_id":lead.get("id"),"task_id":(task or {}).get("id"),
                                   "store_id":store_id,"issues":issues}}
        return source

    @staticmethod
    def _unknown(source,version,instant,issue):
        result=evaluate_rental_source(source,now=instant,rule_version=version)
        result.update(level="unknown",intent_level="unknown",eligibility="uncertain",intent_confidence="unknown",
                      reason="来源、范围或当前有效性尚未核实，需重新判断；旧等级仅保留历史",
                      evidence=[],review_required=True)
        result["intent"].update(grade="insufficient",rule_id="R0",reason=result["reason"],
                                evidence_ids=[],certainty="unresolved",currentness="unknown")
        result["rental_need"].update(confirmed=False,evidence_ids=[],certainty="unresolved",reason=result["reason"])
        result["action_records"]=[]
        result["next_step"]="no_action"
        result["review_reasons"]=list(dict.fromkeys([issue,*result.get("review_reasons",[])]))
        result["manual_review"]={"needed":True,"reasons":result["review_reasons"][:]}
        return result

    def _ident(self,actor,lead_id,source):
        # Host rule versions may deliberately stay stable while the local evaluator
        # changes. Never reuse/overwrite the old evaluator's sidecar under that ID.
        return _digest(["rental-assessment-v1",self.tenant,actor["username"],lead_id,self.rule_version,RULE_VERSION,_digest(source)])

    def _assess_rows(self,db,actor,rows):
        instant=_stamp(self.clock()) or datetime.now(TZ)
        summary={"assessed":0,"written":0,"reused":0,"levels":{k:0 for k in ("high","medium","low","unknown")},
                 "rule_version":self.rule_version,"scope":"employee-local-comment-assessments",
                 "historical_grades_rewritten":False,"provider_requests_started":False}
        for lead in rows:
            if lead.get("source_type")!="comment":continue
            task,store_id,issues=self._scope(db,actor,lead)
            source=self._source(lead,task,store_id,issues)
            result=self._unknown(source,self.rule_version,instant,issues[0]) if issues else evaluate_rental_source(source,now=instant,rule_version=self.rule_version)
            result.update(lead_id=lead["id"],task_id=(task or {}).get("id"),store_id=store_id,
                          scope="employee-local-comment-assessments")
            ident=self._ident(actor,lead["id"],source)
            previous=self._get(db,ENTITY,ident)
            # Check identity/source again while holding the same Core lock/transaction.
            current=self._get(db,"leads",lead["id"])
            fresh_actor=self._actor(db,actor)
            fresh_task,fresh_store,fresh_issues=self._scope(db,fresh_actor,current)
            if _digest(self._source(current,fresh_task,fresh_store,fresh_issues))!=result["source_digest"]:
                raise RentalAssessmentPermissionError("来源或门店范围在判断期间已变化")
            comparable=lambda a:{k:v for k,v in a.items() if k not in ("evaluated_at","as_of")}
            if previous and comparable(previous.get("assessment",{}))==comparable(result):
                summary["reused"]+=1
            else:
                record={"id":ident,"tenant_id":self.tenant,"owner":actor["username"],"lead_id":lead["id"],
                        "task_id":(task or {}).get("id"),"store_id":store_id,"rule_version":self.rule_version,
                        "source_digest":result["source_digest"],"created_at":instant.isoformat(),"assessment":result}
                db.execute("INSERT OR REPLACE INTO records VALUES(?,?,?,?)",(ENTITY,ident,self.tenant,json.dumps(record,ensure_ascii=False,allow_nan=False)))
                summary["written"]+=1
            summary["assessed"]+=1;summary["levels"][result["intent_level"]]+=1
        summary["unknown"]=summary["levels"]["unknown"]
        return summary

    def assess_task(self,user,task_id):
        with self.core.lock,self.core.store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            actor=self._actor(db,user);task=self._get(db,"tasks",task_id)
            if not task or task.get("cloud_owner")!=actor["username"]:
                raise RentalAssessmentPermissionError("任务不存在或不属于当前员工")
            try:self.core._task_access(actor,task,self.tenant,db=db)
            except (ValueError,PermissionError) as exc:raise RentalAssessmentPermissionError("任务权限已变化") from exc
            rows=[json.loads(r["body"]) for r in db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=?",("leads",self.tenant)).fetchall()]
            rows=[r for r in rows if r.get("task_id")==task_id and r.get("cloud_owner") in (None,"",actor["username"])]
            return self._assess_rows(db,actor,rows)

    def assess_visible(self,user):
        with self.core.lock,self.core.store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            actor=self._actor(db,user);visible=[]
            for r in db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=?",("leads",self.tenant)).fetchall():
                lead=json.loads(r["body"])
                if lead.get("cloud_owner") not in (None,"",actor["username"]):continue
                try:self._scope(db,actor,lead)
                except RentalAssessmentPermissionError:continue
                visible.append(lead)
            return self._assess_rows(db,actor,visible)

    def read_assessment(self,user,lead_id):
        with self.core.lock,self.core.store.connect() as db:
            actor=self._actor(db,user);lead=self._get(db,"leads",lead_id)
            task,store_id,issues=self._scope(db,actor,lead)
            source=self._source(lead,task,store_id,issues);instant=_stamp(self.clock()) or datetime.now(TZ)
            if issues:return self._unknown(source,self.rule_version,instant,issues[0])
            record=self._get(db,ENTITY,self._ident(actor,lead_id,source))
            if record is None:
                rows=db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=?",(ENTITY,self.tenant)).fetchall()
                if any((v:=json.loads(r["body"])).get("lead_id")==lead_id and v.get("owner")==actor["username"] for r in rows):
                    return self._unknown(source,self.rule_version,instant,"source_or_rule_changed_requires_refresh")
                return None
            if (record.get("owner")!=actor["username"] or record.get("lead_id")!=lead_id
                or record.get("rule_version")!=self.rule_version or record.get("source_digest")!=_digest(source)
                or record.get("assessment",{}).get("evaluator_version")!=RULE_VERSION):
                return self._unknown(source,self.rule_version,instant,"assessment_record_unverified")
            fresh=evaluate_rental_source(source,now=instant,rule_version=self.rule_version)
            if fresh["intent_level"]!=record["assessment"].get("intent_level"):
                return self._unknown(source,self.rule_version,instant,"assessment_time_window_changed")
            return deepcopy(record["assessment"])
