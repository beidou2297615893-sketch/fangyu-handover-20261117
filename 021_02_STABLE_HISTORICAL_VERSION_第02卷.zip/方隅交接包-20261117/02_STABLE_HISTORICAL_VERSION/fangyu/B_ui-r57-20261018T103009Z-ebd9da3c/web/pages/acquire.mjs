import {customerAvatar,bindCustomerAvatars} from '../avatar.mjs';
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const asset = name => `/assets/${name}`;
const icon = (name, cls='') => `<img class="acquire-icon ${cls}" src="${asset(name)}" alt="" aria-hidden="true">`;
let progressTimer = null;

function model(state) {
  if(state.connection==='preview')state.store ||= '古北店';
  const assignedStore=state.stores?.find(item=>item.id===state.storeId);
  state.acquire ??= {region:state.connection==='preview'?'上海 · 长宁区':assignedStore?.region||'',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  const a=state.acquire;
  if(a.run&&a.run.store!==state.store){
    if(['running','paused'].includes(a.status))a.records.unshift({text:`${a.run.store} · 已切换门店，本次演示结束`,status:'已停止'});
    Object.assign(a,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null,region:state.connection==='preview'?(state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区'):assignedStore?.region||''});
  }
  return state.acquire;
}
const phase = a => ({idle:'待开始',running:['搜索中','读取中','分析中','即将完成'][a.stage] || '采集中',paused:'已暂停',completed:'已完成',failed:'采集已中断'})[a.status];
const selected = (value, expected) => value === expected ? ' selected' : '';
const option = (text,value) => `<option${selected(value,text)}>${escape(text)}</option>`;

function controls(state,a,locked=false,startAllowed=true,startLabel='开始获客',timeRanges){
  const stores=state.connection==='preview'?['古北店','浦江店','徐汇店'].map(name=>({id:name,name})):state.stores||[];
  const id=state.connection==='preview'?state.store:state.storeId;
  return `<section class="acquire-card acquire-launch" aria-label="获客范围"><div class="acquire-fields">
  <label class="acquire-field"><span>门店</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-store aria-label="选择门店" ${locked?'disabled':''}>${!id?'<option value="">请选择门店</option>':''}${stores.map(x=>`<option value="${escape(x.id)}"${selected(id,x.id)}>方隅公寓 · ${escape(x.name)}</option>`).join('')}</select></div></label>
  <div class="acquire-region" aria-label="门店区域">${icon('tabler-upgrade-pin.svg')}<span>${escape(a.region||'门店区域待配置')}</span></div>
  <label class="acquire-field"><span>帖子时间</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-time aria-label="选择时间范围" ${locked?'disabled':''}>${['最近7天','最近3天','最近30天'].map(x=>`<option${selected(a.time,x)}${timeRanges&&!timeRanges.includes(x)?' disabled':''}>${x}</option>`).join('')}</select></div></label>
  <button type="button" class="acquire-start" data-acquire-start ${startAllowed?'':'disabled'}>${icon('icon-play-filled.svg')}<span>${escape(startLabel)}</span></button></div></section>`;
}
function statusRow({status,label,message='',pause=false,resume=false,enabled=false}){
  const running=['running','queued','resuming','pausing'].includes(status);
  return `<section class="acquire-card acquire-status-row ${running?'is-running':''}" data-task-status="${escape(status)}" role="status" aria-live="polite"><span class="acquire-status-icon">${icon('fy-icon-12-clock.png')}</span><div class="acquire-status-copy"><strong>${escape(label)}</strong>${message?`<span>${escape(message)}</span>`:''}</div>${pause||resume?`<button type="button" class="acquire-pause" data-acquire-pause ${enabled?'':'disabled'}>${icon(resume?'icon-play-filled.svg':'fy-icon-54-pause.png')}<span>${resume?'继续':'暂停'}</span></button>`:''}</section>`;
}
export function render(state){
  if(state.connection!=='preview')return renderConnected(state);
  const a=model(state),running=a.status==='running',resume=a.status==='paused';
  return `<div class="acquire-page" data-page-acquire>${controls(state,a,running||resume,!running,resume?'继续获客':'开始获客')}${statusRow({status:a.status,label:phase(a),pause:running,resume,enabled:true})}</div>`;
}
export function bind(root,ctx){
  if(ctx.state.connection!=='preview')return bindConnected(root,ctx);
  clearTimeout(progressTimer);const a=model(ctx.state);
  root.querySelector('[data-acquire-store]')?.addEventListener('change',e=>ctx.update(s=>{s.store=e.target.value;a.region=s.store==='浦江店'?'上海 · 闵行区':s.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区';}));
  root.querySelector('[data-acquire-time]')?.addEventListener('change',e=>{a.time=e.target.value;});
  root.querySelector('[data-acquire-start]')?.addEventListener('click',()=>ctx.update(()=>{a.status='running';}));
  root.querySelector('[data-acquire-pause]')?.addEventListener('click',()=>ctx.update(()=>{a.status=a.status==='running'?'paused':'running';}));
  return ()=>clearTimeout(progressTimer);
}

const count=value=>Number.isSafeInteger(value)&&value>=0?value:'—';
const livePhase=value=>({search:0,searching:0,read:1,reading:1,collect:1,collecting:1,save:2,saving:2,analyzing:2,complete:3,completed:3,finished:3})[value]??(Number.isInteger(value)&&value>=0&&value<=3?value:-1);
const liveStatus=value=>({idle:'待开始',queued:'等待执行',running:'采集中',pausing:'正在暂停',paused:'已暂停',resuming:'正在恢复',completed:'已完成',failed:'未完成',blocked:'已暂停 · 待核验',held:'已暂停 · 待核验',unconfirmed:'结果待核对',cancelled:'已取消',stopped:'已停止'})[value]||'状态待核验';
function unknownStart(state){return Boolean(state.acquisitionAttempt?.unconfirmed||['submitted','unconfirmed'].includes(state.platform?.lastRequest?.state));}
function visibleAcquisition(state,live){const last=state.platform?.lastRequest;return unknownStart(state)&&(!last?.job?.taskId||last.job.taskId!==live.taskId)?{...live,taskId:last?.job?.taskId||'',taskScope:null,status:'unconfirmed',phase:null,counts:{},records:[],canPause:false,canResume:false}:live;}
function liveModel(state){
  const store=state.stores?.find(item=>item.id===state.storeId),platforms=(state.platform?.platforms||[]).filter(row=>row.enabled);
  state.acquire??={region:store?.region||'',time:'最近7天'};
  const draft=state.acquire;draft.region??=store?.region||'';draft.time||='最近7天';
  if(unknownStart(state)){const conditions=state.acquisitionAttempt?.payload||state.platform?.lastRequest?.conditions||{};draft.region=typeof conditions.region==='string'?conditions.region:'';draft.time=typeof conditions.time==='string'?conditions.time:'';if(conditions.platform)draft.selectedPlatform=conditions.platform;}
  draft.selectedPlatform=state.activePlatform||'xiaohongshu';
  const platform=platforms.find(row=>row.id===draft.selectedPlatform);
  return {draft,store,platform,platforms,accountId:state.platformAccountSelections?.[platform?.id]||platform?.accountId||'',live:((!state.platform?.acquisition?.taskScope?.platform||state.platform.acquisition.taskScope.platform===(state.activePlatform||'xiaohongshu'))?visibleAcquisition(state,state.platform?.acquisition||{}):{status:'idle',counts:{}})};
}
const activeStatuses=['running','queued','pausing','resuming','stopping'];
const currentCommentPolicy=scope=>Boolean(scope&&scope.scope==='search_comments'
  &&scope.commentKeywordMode==='all'&&scope.continuousEnabled===false
  &&scope.region===''&&scope.unknownPolicy==='exclude');
const legacyTaskPolicy=live=>Boolean(live.taskScope&&!currentCommentPolicy(live.taskScope));
const canResumeTask=(state,live)=>Boolean(currentCommentPolicy(live.taskScope)&&state.storeId&&live.taskScope?.storeId===state.storeId
  &&live.taskId&&live.canResume&&['paused','stopped'].includes(live.status));
function matchesTaskScope(state,current){
  const {draft,store,platform,accountId,live}=current,scope=live.taskScope;
  const words=state.platform?.lastRequest?.job?.taskId===live.taskId&&Array.isArray(state.platform?.lastRequest?.keywordBatch)?state.platform.lastRequest.keywordBatch:state.selection?.applied?.selectedKeywords,days={'最近3天':3,'最近7天':7,'最近30天':30}[draft.time];
  if(!scope||!days||!Array.isArray(words)||!words.length||words.some(word=>typeof word!=='string'))return false;
  const keywords=[...new Set(words.map(word=>word.trim()))];
  const today=new Date(Date.now()+8*60*60*1000).toISOString().slice(0,10);
  const from=new Date(Date.parse(today+'T00:00:00Z')-(days-1)*86400000).toISOString().slice(0,10);
  return scope.storeId===state.storeId&&scope.platform===platform?.id&&scope.accountId===accountId
    &&currentCommentPolicy(scope)&&scope.region===''&&(draft.region||'')===(store?.region||'')
    &&scope.city===(store?.city||'')&&scope.area===(store?.area||'')&&scope.dateFrom===from&&scope.dateTo===today
    &&JSON.stringify(scope.keywords)===JSON.stringify(keywords)&&scope.scope==='search_comments'
    &&scope.commentDateRange==='all'&&scope.intentMode==='all'
    &&Array.isArray(scope.excludes)&&scope.excludes.length===0
    &&scope.dailyLimit===(platform?.id==='xiaohongshu'?100:20)&&scope.targetCount===100;
}
function taskCaption(state,live){
  const scope=live.taskScope,platform={xiaohongshu:'小红书',douyin:'抖音'}[scope?.platform]||'原平台';
  const store=state.stores?.find(row=>row.id===scope?.storeId)?.name||'原门店';
  const date=/^\d{4}-\d{2}-\d{2}$/;
  const time=scope&&date.test(scope.dateFrom)&&date.test(scope.dateTo)?`${scope.dateFrom} 至 ${scope.dateTo}`
    :scope&&scope.dateFrom===''&&scope.dateTo===''?'全部时间':'原时间条件';
  return `${platform} · ${store} · ${time}`;
}
function recentPeople(state){const live=visibleAcquisition(state,state.platform?.acquisition||{});return live.status==='unconfirmed'?[]:Array.isArray(live.recent)?live.recent:[];}
export function renderTaskExecution(state,live={}){
  const scope=live.taskScope;
  if(!live.taskId||!scope||scope.storeId!==state.storeId)return '<section class="acquire-execution" aria-label="当前任务执行范围"><strong>当前任务执行范围</strong><p>当前门店暂无已核对的任务条件；词库总量不代表已执行词。</p></section>';
  const words=value=>Array.isArray(value)?value.filter(v=>typeof v==='string').map(escape).join('、'):'';
  const analysis=live.analysis||{},pending=count(analysis.pending);
  const analysisStatus={running:'意向分析中',queued:'等待意向分析',pending:'等待意向分析',paused:'意向分析已暂停',blocked:'意向分析受阻',completed:'本批分析已结束',succeeded:'本批分析已结束',failed:'本批分析未完成',unknown:'分析结果待核对'}[analysis.status]||'分析状态未返回';
  const analysisReason={AI_INVALID_OUTPUT:'本批分析尚未完整确认',AI_DISABLED:'企业 AI 未启用',AI_NOT_CONFIGURED:'企业 AI 尚未配置',AI_BILLING_UNKNOWN:'原分析请求结果未确认，不会自动重复提交',verification_required:'平台要求重新验证登录'}[analysis.code]||(analysis.code?'本批分析状态待核对':'');
  const time=scope.dateFrom&&scope.dateTo?`${escape(scope.dateFrom)} 至 ${escape(scope.dateTo)}`:scope.dateFrom===''&&scope.dateTo===''?'全部时间':'未返回';
  return `<section class="acquire-execution" aria-label="当前任务执行范围"><strong>当前任务执行范围</strong><dl><dt>搜帖词</dt><dd>${words(scope.keywords)||'未返回'}</dd><dt>任务排除词</dt><dd>${Array.isArray(scope.excludes)?words(scope.excludes)||'未设置':'未返回'}</dd><dt>帖子日期</dt><dd>${time} · 评论范围：${scope.commentDateRange==='all'?'全部时间':'按原任务条件'}</dd><dt>任务目标 / 日上限</dt><dd>${count(scope.targetCount)} / ${count(scope.dailyLimit)}</dd><dt>本批待分析</dt><dd>${pending} · ${escape(analysisStatus)}${analysisReason?' · '+escape(analysisReason):''}</dd><dt>本批分析来源</dt><dd>${analysis.provider||analysis.model?escape([analysis.provider,analysis.model].filter(Boolean).join(' · ')):'尚未返回模型来源；不能把本机判断或历史评级当成本批 AI 结果'}</dd></dl><p>以上来自已保存任务条件，不表示每个词已搜索完成；待分析数使用后台回执，模型来源不代表真实调用成功。</p></section>`;
}
function renderConnected(state){
  const current=liveModel(state),{draft,live}=current,status=live.status||'idle';
  const unconfirmed=unknownStart(state),locked=state.busy||unconfirmed||activeStatuses.includes(status),taskResume=!unconfirmed&&canResumeTask(state,live),resume=taskResume&&matchesTaskScope(state,current);
  const canStart=!state.busy&&(unconfirmed||resume||(!locked&&live.canStart!==false));
  const pauseUnknown=unconfirmed&&state.platform?.lastRequest?.job?.taskId&&live.canPause;
  const failure=['failed','blocked','held','unconfirmed'].includes(status)||state.platformError;
  const message=failure?(state.platformError||live.message||'请在账号页查看平台连接状态。'):'';
  const label=state.platformLoading&&!state.platform?'正在读取':live.phase==='analyzing'&&status==='running'?'正在分析':liveStatus(status);
  return `<div class="acquire-page" data-page-acquire>${controls(state,draft,locked,canStart,unconfirmed?'核对采集状态':resume?'继续获客':status==='completed'?'再次获客':'开始获客',state.platform?.capabilities?.timeRanges||[])}${statusRow({status,label,message,pause:Boolean(live.canPause||pauseUnknown),resume:Boolean(taskResume),enabled:!state.busy&&(unconfirmed?pauseUnknown:live.canPause||taskResume)})}</div>`;
}
function bindConnected(root,ctx){
  bindCustomerAvatars(root);
  clearTimeout(progressTimer);progressTimer=null;
  const {state}=ctx,{draft,live,platforms}=liveModel(state);
  root.querySelector('[data-acquire-store]')?.addEventListener('change',event=>{if(event.target.value)ctx.actions.selectStore(event.target.value);});
  root.querySelector('[data-acquire-region]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.region=event.target.value;}));
  root.querySelector('[data-acquire-time]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.time=event.target.value;}));
  root.querySelector('[data-acquire-presets]')?.addEventListener('click',()=>ctx.navigate('presets'));
  root.querySelector('[data-acquire-customers]')?.addEventListener('click',()=>ctx.navigate('customers'));
  root.querySelector('[data-acquire-platform]')?.addEventListener('click',()=>ctx.modal({title:'选择获客平台',html:`<div class="acquire-platform-options">${platforms.map(row=>`<label><input type="radio" name="live-acquire-platform" value="${escape(row.id)}" ${draft.selectedPlatform===row.id?'checked':''}> ${escape(row.name)}</label>`).join('')||'<p>当前企业尚未开通采集平台。</p>'}</div><p class="modal-note">仅使用当前门店已授权并核验的平台账号。</p>`,confirmLabel:'确认选择',onConfirm:()=>{const value=document.querySelector('input[name="live-acquire-platform"]:checked')?.value;if(!value)return false;ctx.update(s=>{s.acquire.selectedPlatform=value;});}}));
  root.querySelector('[data-acquire-start]')?.addEventListener('click',()=>{
    if(state.busy)return;
    if(unknownStart(state))return ctx.actions.verifyAcquisition?.();
    const current=liveModel(state);
    if(canResumeTask(state,current.live)&&matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(current.live.taskId);
    if(activeStatuses.includes(current.live.status)||current.live.canStart===false)return;
    return ctx.actions.startAcquisition?.();
  });
  root.querySelector('[data-acquire-pause]')?.addEventListener('click',()=>{
    if(state.busy)return;
    const current=liveModel(state),live=current.live,last=state.platform?.lastRequest;
    if(unknownStart(state)){
      if(last?.job?.taskId&&last.requestId===(state.acquisitionAttempt?.payload?.requestId||last.requestId)&&live.canPause)
        return ctx.actions.pauseAcquisition?.(last.job.taskId);
      return;
    }
    if(!canResumeTask(state,live))return live.canPause?ctx.actions.pauseAcquisition?.(live.taskId):undefined;
    if(matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(live.taskId);
    const taskId=live.taskId,actor=JSON.stringify([state.user,state.storeId]),scope=JSON.stringify(live.taskScope);
    return ctx.modal({title:'继续原任务',html:`<p>${escape(taskCaption(state,live))}</p>`,confirmLabel:'继续原任务',onConfirm:()=>{
      const fresh=liveModel(state).live;
      if(state.busy||unknownStart(state)||actor!==JSON.stringify([state.user,state.storeId])
          ||fresh.taskId!==taskId||!canResumeTask(state,fresh)||JSON.stringify(fresh.taskScope)!==scope)return false;
      return ctx.actions.resumeAcquisition?.(taskId);
    }});
  });
  root.querySelector('[data-acquire-records]')?.addEventListener('click',()=>ctx.modal({title:'采集记录',html:`<div class="acquire-records"><p>${escape(taskCaption(state,live))}</p><div class="acquire-record-summary"><strong>${escape(liveStatus(live.status))}</strong><span>本次已读 ${count(live.counts?.read)} · 新增入库 ${count(live.counts?.added)} · 已分析 ${count(live.counts?.analyzed)} · 重复 ${count(live.counts?.duplicates)}</span></div>${(Array.isArray(live.records)?live.records:[]).map(record=>`<div class="acquire-record-row"><span>${escape(record.text||record.message||'')}</span><b>${escape(record.status||'')}</b></div>`).join('')||'<p class="modal-note">当前没有可显示的真实采集记录。</p>'}</div>`,confirmLabel:'刷新状态',onConfirm:async()=>{await ctx.actions.refreshPlatform();return false;}}));
  for(const button of root.querySelectorAll('[data-live-acquire-person]'))button.onclick=()=>{const person=recentPeople(state)[Number(button.dataset.liveAcquirePerson)];if(person)ctx.modal({title:person.name||person.authorName||'采集结果',html:`<p>${escape(person.copy||person.text||person.content||'暂无正文')}</p><p class="muted">${escape(person.intent||person.level||'尚未分析')}</p>`});};
  return ()=>{clearTimeout(progressTimer);progressTimer=null;};
}
