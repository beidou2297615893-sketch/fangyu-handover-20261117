import {businessSection,validateBusinessDocument,downloadBusinessFile} from './business-rules.mjs';
import {renderTaskExecution} from './acquire.mjs';
import {renderWorkflowSummary} from './workflow-summary.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scope=s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId,s.activePlatform||'xiaohongshu',s.session?.user?.role]);
function model(state){const key=scope(state);if(state.rulesPage?.scope!==key)state.rulesPage={scope:key,status:'idle',section:'words',tab:'current',query:'',doc:null,error:''};return state.rulesPage;}
function wordRows(doc){
  const store=doc.stores.find(row=>row.name===doc.selectedStoreName)||doc.stores[0];
  return '<h3>搜索词</h3>'+doc.groups.map(group=>{const guide=doc.categoryGuide.find(row=>row.name===group),terms=store.terms.filter(row=>row.group===group);return `<section class="br-word-row"><div><h4>${esc(group)}</h4><p>${esc(guide?.meaning||'')}</p></div><div class="br-word-tags">${terms.map(term=>`<span title="${esc(term.origin+' · '+term.statusText)}">${esc(term.word)}${term.pendingSource?'<small>资料待核</small>':''}</span>`).join('')||'<span>当前分类暂无词</span>'}</div></section>`;}).join('')+`<details><summary>词库来源与最近核查</summary><p>${esc(doc.verifiedSnapshot)}</p><p>${esc(doc.reviewStatusNote)}</p><p>${esc(store.taskUsageNote)}</p><p>${esc(doc.sourceHoldNotice)}</p>${doc.verifiedFacts.map(f=>`<p><strong>${esc(f.item)}：</strong>${esc(f.text)}</p>`).join('')}</details>`;
}
export function render(state){
  const v=model(state),doc=v.doc;let body=doc?businessSection(doc,v.tab==='meeting'?'meeting':v.section,doc.selectedStoreName):`<div class="br-empty"><p>${esc(v.error||'正在读取本店获客规则…')}</p>${v.status==='error'?'<button type="button" data-rules-reload>重新读取</button>':''}</div>`;
  if(doc&&v.tab==='current'&&v.section==='words')body=wordRows(doc);
  return `<div class="business-rules-page"><p class="br-store">方隅公寓 · ${esc(state.store||'当前门店')}</p><section class="card br-card"><header class="br-heading"><h2>本店规则</h2>${doc?.canExport?'<button type="button" class="primary" data-rules-export>导出规则</button>':''}</header><div class="br-tabs"><button type="button" data-rules-tab="current" aria-pressed="${v.tab==='current'}">现有说明</button><button type="button" data-rules-tab="meeting" aria-pressed="${v.tab==='meeting'}">会议建议</button></div><div class="br-workspace"><nav class="br-sections" aria-label="规则内容">${[['words','搜索词'],['exclude','语境排除与保留'],['intent','年租意向']].map(([key,label])=>`<button type="button" data-rules-section="${key}" aria-pressed="${v.section===key&&v.tab==='current'}">${label}</button>`).join('')}</nav><div class="br-reader"><label class="br-search"><img src="/assets/approved-icon-search.svg" alt=""><input data-rules-search type="search" value="${esc(v.query)}" placeholder="搜索规则" aria-label="搜索规则"></label><article class="br-content" data-rules-body>${body}</article></div></div><p role="status" class="br-feedback">${esc(v.status==='exporting'?'正在导出规则…':v.error)}</p></section><details class="br-advanced"><summary>规则来源与运行信息</summary>${renderWorkflowSummary(state)}${renderTaskExecution(state,state.platform?.acquisition||{})}${state.session?.user?.role==='admin'?'<button type="button" data-rules-files>管理规则文件</button>':''}</details></div>`;
}
export function bind(root,ctx){
  const state=ctx.state,v=model(state),key=v.scope,own=()=>state.page==='rules'&&scope(state)===key&&state.rulesPage===v;
  const redraw=()=>{if(own())ctx.update(()=>{});};
  async function load(){
    if(!own()||v.status==='loading')return;if(state.connection!=='connected'){v.status='error';v.error='界面预览未连接规则服务。';redraw();return;}
    v.status='loading';v.error='';redraw();
    try{const result=await ctx.readBusinessRules({storeId:state.storeId});if(!own())return;if(result.actor?.username!==state.user||result.actor?.storeId!==state.storeId)throw Error('门店或账号已变化，请重新读取。');v.doc=validateBusinessDocument(result.businessReview);v.status='ready';}
    catch(error){if(own()){v.status='error';v.error=error.message;}}finally{redraw();}
  }
  root.querySelectorAll('[data-rules-section]').forEach(b=>b.addEventListener('click',()=>{if(own()){v.section=b.dataset.rulesSection;v.tab='current';v.query='';redraw();}}));
  root.querySelectorAll('[data-rules-tab]').forEach(b=>b.addEventListener('click',()=>{if(own()){v.tab=b.dataset.rulesTab;v.query='';redraw();}}));
  root.querySelector('[data-rules-reload]')?.addEventListener('click',load);
  root.querySelector('[data-rules-search]')?.addEventListener('input',e=>{v.query=e.target.value;const q=v.query.trim().toLocaleLowerCase();root.querySelectorAll('[data-rules-body] details,[data-rules-body] tbody tr,[data-rules-body] .br-word-row').forEach(node=>{node.hidden=Boolean(q&&!node.textContent.toLocaleLowerCase().includes(q));if(q&&node.tagName==='DETAILS'&&!node.hidden)node.open=true;});});
  root.querySelector('[data-rules-files]')?.addEventListener('click',()=>{if(own()&&state.session?.user?.role==='admin')ctx.openCentralRuleFiles();});
  root.querySelector('[data-rules-export]')?.addEventListener('click',async()=>{if(!own()||v.status==='exporting'||!v.doc?.canExport)return;v.status='exporting';v.error='';redraw();try{const result=await ctx.aiRulesExport({storeId:state.storeId,format:'html'});if(own()){downloadBusinessFile(result.file,'html');ctx.toast('规则已导出。');}}catch(error){if(own())v.error=error.message;}finally{if(own()){v.status='ready';redraw();}}});
  if(v.status==='idle')queueMicrotask(load);
  return ()=>{};
}
