import {latestBusinessSection,validateLatestBusinessReview} from './business-rules-latest.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scope=s=>JSON.stringify([s.authEpoch||0,s.user||'',s.storeId||'',s.session?.user?.role||'']);
const list=a=>'<ul>'+a.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul>';
const table=(head,rows)=>'<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;text-align:left"><thead><tr>'+head.map(x=>'<th style="padding:10px">'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(v=>'<td style="padding:10px;vertical-align:top">'+esc(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';

export function validateBusinessDocument(d){
  validateLatestBusinessReview(d);
  if(!d||d.annualOnly!==true||d.fiveLevelsApproved!==false||d.fiveLevelsLiveVerified!==true
      ||!Array.isArray(d.stores)||!d.stores.length
      ||!Array.isArray(d.exclusions)||d.exclusions.length!==15
      ||!Array.isArray(d.proposedFiveLevels)||d.proposedFiveLevels.length!==5
      ||!Array.isArray(d.currentFiveLevels)||d.currentFiveLevels.length!==5)
    throw Error('获客规则还没完整读到，请稍后重试。');
  for(const s of d.stores){
    if(typeof s.name!=='string'||!Array.isArray(s.terms)||!s.counts||s.totalCount!==s.terms.length
        ||s.terms.some(t=>typeof t.word!=='string'||!d.groups.includes(t.group)))
      throw Error('门店搜索词清单不完整，请重新读取。');
  }
  return d;
}

export function businessSection(doc,section,storeName){
  validateBusinessDocument(doc);
  const latest=latestBusinessSection(doc,section||'words',storeName);
  if(latest!==null)return latest;
  if(section==='exclude')return '<h3>什么时候排除 什么时候保留</h3>'+doc.exclusions.map(x=>'<details><summary>'+esc(x.title)+'</summary><p><strong>排除或停止联系：</strong>'+esc(x.exclude)+'</p><p><strong>保留：</strong>'+esc(x.keep)+'</p><p>'+esc(x.example)+'</p></details>').join('')+'<h3>只做年租怎样筛</h3>'+table(['客户表达','处理办法'],doc.annualGuide.map(x=>[x.situation,x.handle]));
  if(section==='intent')return '<h3>目前查到的五级说明</h3><p>'+esc(doc.currentNote)+'</p>'+table(['等级','目前说明'],doc.currentFiveLevels.map(x=>[x.level,x.text]))+'<h3>会议建议的五级标准</h3><p>'+esc(doc.proposalNote)+'</p>'+table(['建议等级','怎么判断','举例'],doc.proposedFiveLevels.map(x=>[x.level,x.text,x.example]))+'<p>'+esc(doc.followUpOrder)+'</p>';
  if(section==='examples')return '<h3>评论举例怎样分意向</h3><p>'+esc(doc.examplesNote)+'</p>'+table(['评论举例','建议意向','年租情况','处理办法'],doc.examples.map(x=>[x.text,x.level,x.annual,x.action]));
  if(section==='meeting')return '<h3>尚未明确的事项</h3>'+list(doc.unknown)+'<h3>会议要确认的问题</h3>'+table(['要讨论什么','当前建议','需要定下来什么'],doc.meetingQuestions.map(x=>[x.question,x.suggestion,x.decide]));
  if(section==='checklist')return '<h3>先看四件事</h3>'+list(doc.simpleChecklist)+'<p>'+esc(doc.contactRule)+'</p><p>'+esc(doc.followUpOrder)+'</p>';
  const s=doc.stores.find(s=>s.name===storeName)||doc.stores[0];
  return '<h3>搜索词分类</h3>'+table(['分类','说明','怎样使用'],doc.categoryGuide.map(x=>[x.name,x.meaning,x.rule]))+'<h3>'+esc(s.name)+'</h3><p>原有 '+s.originalCount+' 个，后补 '+s.addedCount+' 个，合计 '+s.totalCount+' 个不同词。</p><p>词数不等于地点数。地点、分店和当前营业情况仍需确认。</p>'+doc.groups.map(g=>'<details'+(g==='租房强关联'?' open':'')+'><summary>'+esc(g)+' '+s.counts[g]+'个</summary>'+['原有资料','后来补充'].map(origin=>{const words=s.terms.filter(t=>t.group===g&&t.origin===origin);return words.length?'<h4>'+origin+'</h4><div class="wf-words">'+words.map(t=>'<span>'+esc(t.word)+'</span>').join('')+'</div>':'';}).join('')+'</details>').join('');
}

export function downloadBusinessFile(file,format='html'){
  const ppt='application/vnd.openxmlformats-officedocument.presentationml.presentation';
  const mime=format==='pptx'?ppt:'text/html;charset=utf-8';
  const filename=format==='pptx'?'方隅公寓年租获客会议.pptx':'年租获客规则完整清单.html';
  if(!file||file.mime!==mime||file.filename!==filename||typeof file.contentBase64!=='string'
      ||file.contentBase64.length>20_000_000||!/^[A-Za-z0-9+/]*={0,2}$/.test(file.contentBase64))
    throw Error('导出文件没有完整生成，请重新读取后再试。');
  const bytes=Uint8Array.from(atob(file.contentBase64),v=>v.charCodeAt(0));
  if(format==='html'){
    const html=new TextDecoder().decode(bytes);
    if(!html.startsWith('<!doctype html>')||!html.includes('方隅公寓年租获客规则')
        ||/source_id|material_key|tenant_id|SHA256|schema_version|semantic_context|providerGradeCriteria/.test(html))
      throw Error('导出内容没有整理成业务清单，未保存文件。');
  }else if(bytes[0]!==0x50||bytes[1]!==0x4b)throw Error('演示文稿不完整，未保存文件。');
  const url=URL.createObjectURL(new Blob([bytes],{type:mime}));
  let doc=document;try{if(window.parent!==window&&window.parent.location.origin===location.origin)doc=window.parent.document;}catch{}
  const link=doc.createElement('a');link.href=url;link.download=filename;doc.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}

export function openBusinessRules(ctx){
  if(ctx.state.connection!=='connected'||!ctx.state.user||!ctx.state.storeId){ctx.toast?.('请先登录并选择门店。');return;}
  const bound=scope(ctx.state),state={section:'words',storeName:'',doc:null,busy:false,error:''};
  const read=ctx.readBusinessRules||ctx.actions?.readBusinessRules;
  const exportFile=ctx.aiRulesExport||ctx.actions?.aiRulesExport;
  let dialog,owner;
  const current=()=>scope(ctx.state)===bound&&ctx.state.connection==='connected'&&dialog?.open!==false&&dialog?.__modalOwner===owner;
  function render(){
    if(scope(ctx.state)!==bound)return;
    const doc=state.doc,disabled=state.busy?'disabled':'';
    dialog=ctx.modal({title:'年租获客规则',confirmLabel:'关闭',html:'<div class="wf-rules-detail"><p role="status">'+esc(state.error||(state.busy?'正在读取获客规则…':'只读核对：现用五级已核实，会议建议待你确认。'))+'</p>'+(doc?'<div class="rp-editor-actions">'+[['words','搜索词'],['exclude','排除与保留'],['intent','五级意向'],['examples','评论举例'],['checklist','评论判断与筛选'],['meeting','会议待定']].map(([v,label])=>'<button type="button" class="rp-secondary" data-br-section="'+v+'"'+(state.section===v?' aria-pressed="true"':'')+'>'+label+'</button>').join('')+'</div><label>查看哪家店的词 <select data-br-store>'+doc.stores.map(s=>'<option'+(s.name===state.storeName?' selected':'')+'>'+esc(s.name)+'</option>').join('')+'</select></label><div data-br-body>'+businessSection(doc,state.section,state.storeName)+'</div>'+(doc.canExport?'<div class="rp-editor-actions"><button type="button" class="rp-secondary" data-br-export="pptx" '+(disabled||(!doc.canExportMeetingPpt?'disabled':''))+'>原会议PPT（较早草稿）</button><button type="button" class="rp-secondary" data-br-export="html" '+disabled+'>导出完整清单</button></div>':''):'<button type="button" class="rp-secondary" data-br-retry '+disabled+'>重新读取</button>')+'</div>'});
    owner=dialog?.__modalOwner;
    dialog?.querySelectorAll('[data-br-section]').forEach(button=>button.addEventListener('click',()=>{if(!current())return;state.section=button.dataset.brSection;render();}));
    dialog?.querySelector('[data-br-store]')?.addEventListener('change',event=>{if(!current())return;state.storeName=event.target.value;render();});
    dialog?.querySelector('[data-br-retry]')?.addEventListener('click',load);
    dialog?.querySelectorAll('[data-br-export]').forEach(button=>button.addEventListener('click',async()=>{
      if(!current()||state.busy||!doc.canExport||typeof exportFile!=='function')return;
      state.busy=true;state.error='';const format=button.dataset.brExport;render();
      try{const result=await exportFile({storeId:ctx.state.storeId,format});if(!current())return;downloadBusinessFile(result.file,format);ctx.toast?.('文件已导出，请在下载位置查看。');}
      catch(error){if(current())state.error=error.message;}
      finally{state.busy=false;if(current())render();}
    }));
  }
  async function load(){
    if(!current()||state.busy)return;
    state.busy=true;state.error='';render();
    try{if(typeof read!=='function')throw Error('当前界面还没有装入获客规则查看功能，请正常更新后重开。');
      const result=await read({storeId:ctx.state.storeId});if(!current())return;
      if(result.actor?.username!==ctx.state.user||result.actor?.storeId!==ctx.state.storeId)throw Error('员工或门店已经变化，请重新读取。');
      state.doc=validateBusinessDocument(result.businessReview);state.storeName=state.doc.selectedStoreName;
    }catch(error){if(current())state.error=error.message;}
    finally{state.busy=false;if(current())render();}
  }
  render();load();
}
