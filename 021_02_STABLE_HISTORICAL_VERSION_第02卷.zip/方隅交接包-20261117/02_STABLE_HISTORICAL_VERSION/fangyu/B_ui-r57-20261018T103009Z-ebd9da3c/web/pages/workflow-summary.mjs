import {openBusinessRules,downloadBusinessFile} from './business-rules.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const levels={super_high:'超高意向',high:'高意向',medium:'中意向',low:'低意向',very_low:'极低意向'};
const list=v=>Array.isArray(v)?v:[];
export const workflowScope=state=>JSON.stringify([state.authEpoch||0,state.user,state.storeId||'',state.session?.user?.role||'',state.activePlatform||'xiaohongshu']);
const matches=(state,value)=>value?.scope===workflowScope(state)&&value?.actor?.username===state.user&&value?.actor?.storeId===state.storeId;
export function assessmentLabel(p){return p?.intentSource==='manual'?'人工评级':p?.intentSource==='ai'?'已有 AI 分析':p?.intentSource==='rental-assessment'?'本机证据判断':'尚无本轮分析记录';}
export function evidenceSummary(p,cls=''){
  const evidence=list(p?.evidence).filter(v=>typeof v==='string'&&v.trim());
  return `<section class="wf-evidence ${cls}" aria-label="判断依据"><div><strong>为什么是${esc(p?.level||'待确认客户')}</strong><small>${esc(assessmentLabel(p))}${p?.intentRuleVersion?' · '+esc(p.intentRuleVersion):''}</small></div>${evidence.length?`<ul>${evidence.slice(0,3).map(v=>`<li>${esc(v)}</li>`).join('')}</ul>`:'<p>当前未提供判断依据；请先核对原评论，不能把历史评级视为本轮 AI 已分析。</p>'}${p?.budgetSummary?`<p>预算：${esc(p.budgetSummary)}</p>`:''}</section>`;
}
export function renderWorkflowSummary(state){
  if(state.connection!=='connected'||!state.session||!state.storeId)return '';
  const value=state.aiWorkbench,owned=matches(state,value),r=owned?value.rules:null,ready=owned?value.readiness:null;
  const words=list(r?.search).flatMap(s=>list(s.keywords));
  const provider=ready?.profile,configuration={ready:'配置就绪',configured:'配置就绪',not_configured:'待配置',disabled:'已关闭',unavailable:'配置待核对',unknown:'配置待核对'}[ready?.configurationStatus]||'配置待核对';
  return `<section class="wf-summary" aria-label="当前获客与判断规则"><div class="wf-current"><span class="wf-kicker">当前工作范围</span><strong>${esc(state.store||state.storeId)}</strong><span>${words.length?'词库配置 '+words.length+' 项（非执行数）':'词库待读取'}</span><span class="wf-ai-state">AI ${esc(configuration)}${provider?.model?' · '+esc(provider.model):''}</span><small>真实模型调用${ready?.providerSuccess==='verified'?'已核对':'尚未验证'}</small></div><div class="wf-summary-actions"><button type="button" data-wf-rules>查看获客规则</button><button type="button" data-wf-export ${!r?'disabled':''}>导出会议PPT</button>${state.session?.user?.role==='admin'?'<button type="button" data-wf-remote>远程管理与更新</button>':''}<button type="button" data-wf-refresh ${owned&&value.status==='loading'?'disabled':''}>${owned&&value.status==='loading'?'读取中…':'刷新配置'}</button></div>${owned&&value.error?`<p role="status">${esc(value.error)}</p>`:''}</section>`;
}
function criteriaHTML(criteria){return criteria&&typeof criteria==='object'?Object.entries(levels).map(([key,label])=>`<p><strong>${label}：</strong>${esc(criteria[key]||'未提供')}</p>`).join(''):'<p>尚未返回分级标准。</p>';}
export function ruleDetails(r,readiness){
  const remote=r?.providerGradeCriteria;
  return `<div class="wf-rules-detail"><p class="wf-note">企业模型使用服务器发布标准；本机标准用于本机判断，两者分别列出。</p><h3>实际搜索词与排除词</h3>${list(r?.search).map(s=>`<section><h4>${esc(s.name||s.id||'搜索方案')}</h4><div class="wf-words">${list(s.keywords).map(word=>`<span>${esc(typeof word==='string'?word:word.text||word.keyword||'')}</span>`).join('')||'尚未配置关键词'}</div><p>排除：${esc(list(s.excludeTerms).join('、')||'未配置')}</p><p>来源：${esc(({confirmed_store_materials:'已确认门店资料',central:'中央词库'})[s.source]||s.materialName||s.libraryReference?.version||'来源未提供')}</p>${list(s.sourceBindings).map(binding=>`<p>${esc(binding.keyword||'')} · 来源文件 ${esc(list(binding.sourceRefs).join('、')||'未提供')}</p>`).join('')}</section>`).join('')||'<p>当前词库尚未读取。</p>'}<h3>服务器模型分级标准</h3><p>来源：${esc(remote?.source||'未提供')} · 版本 ${esc(remote?.rulesVersion||remote?.revision||'未知')}</p>${remote?.available?criteriaHTML(remote.criteria):'<p>服务器未返回有效标准，请核对配置。</p>'}<h3>服务器已发布公司规则</h3><p>发布状态：${r?.providerPolicy?.status==='read'?'已读取发布记录':'暂未读取'} · 版本 ${esc(r?.providerPolicy?.summary?.policy_revision??'未知')}</p>${r?.providerPolicy?.policy?.criteria?criteriaHTML(r.providerPolicy.policy.criteria):'<p>当前账号未返回完整公司规则；可导出当前权限内内容。</p>'}<h3>本机证据筛选</h3>${list(r?.localAssessmentOverview?.standards).map(row=>`<p><strong>${esc(row.label||row.code)}：</strong>${esc(row.description)}</p>`).join('')||'<p>本机证据标准尚未返回。</p>'}<h3>本机分级标准</h3><p>版本 ${esc(r?.localPolicy?.summary?.revision??'未知')} · 不会自动改写服务器模型提示词</p>${criteriaHTML(r?.localPolicy?.policy?.criteria||r?.localPolicy?.summary?.criteria)}<h3>AI 配置状态</h3><p>${esc(readiness?.notice||'配置状态尚未读取；真实模型调用未验证。')}</p><p>服务器完整提示词：${r?.providerPrompt?.available?'已返回':'当前接口未提供'}</p></div>`;
}
export function bindWorkflowSummary(root,ctx){
  const scope=workflowScope(ctx.state),own=()=>scope===workflowScope(ctx.state)&&ctx.state.connection==='connected';
  const current=()=>own()&&matches(ctx.state,ctx.state.aiWorkbench)?ctx.state.aiWorkbench:null;
  root.querySelector('[data-wf-remote]')?.addEventListener('click',()=>{if(own()&&ctx.state.session?.user?.role==='admin')ctx.openRemoteManagement?.();});
  root.querySelector('[data-wf-refresh]')?.addEventListener('click',()=>{if(own())ctx.refreshAIRules?.(true);});
  root.querySelector('[data-wf-rules]')?.addEventListener('click',()=>{if(own())openBusinessRules(ctx);});
  root.querySelector('[data-wf-export]')?.addEventListener('click',async event=>{
    if(!current()?.rules)return;const button=event.currentTarget;button.disabled=true;
    try{const result=await ctx.aiRulesExport({storeId:ctx.state.storeId,format:'pptx'});if(!own())return;downloadBusinessFile(result.file,'pptx');ctx.toast('会议演示已导出，请在下载位置查看。');}
    catch(error){if(own())ctx.modal({title:'导出未完成',html:`<p role="alert">${esc(error.message)}</p>`});}finally{if(button.isConnected)button.disabled=false;}
  });
  root.querySelector('[data-wf-edit]')?.addEventListener('click',()=>{
    const v=current(),r=v?.rules,policy=r?.localPolicy?.policy;if(!r?.canManage||!policy?.criteria)return;
    const original=structuredClone(policy),revision=r.localPolicy.summary?.revision;
    const dialog=ctx.modal({title:'编辑本机意向标准',html:`<p class="wf-note">只保存本机标准，不修改服务器 AI 分级标准或提示词。</p><form id="wf-local-form">${Object.entries(levels).map(([key,label])=>`<label class="wf-rule-field">${label}<textarea name="${key}" minlength="8" maxlength="240" required>${esc(original.criteria[key]||'')}</textarea></label>`).join('')}<p id="wf-save-error" role="alert"></p></form>`,confirmLabel:'保存本机标准',onConfirm:async()=>{
      if(!own()||!current()?.rules?.canManage)return false;
      const form=dialog.querySelector('#wf-local-form');if(!form.reportValidity())return false;
      const criteria=Object.fromEntries(Object.keys(levels).map(key=>[key,form.elements.namedItem(key).value.trim()]));
      const button=dialog.querySelector('.modal-confirm');button.disabled=true;
      try{await ctx.aiLocalRulesSave({storeId:ctx.state.storeId,policy:{name:original.name,enabled:original.enabled,criteria,facts:original.facts},expected_revision:revision,idempotency_key:crypto.randomUUID()});if(!own())return false;await ctx.refreshAIRules(true);ctx.toast('本机标准已保存；服务器 AI 标准保持原版本。');return true;}
      catch(error){if(own())dialog.querySelector('#wf-save-error').textContent=error.message+'；未自动重试，请保留文字并重新读取版本核对。';return false;}
      finally{if(button.isConnected)button.disabled=false;}
    }});
  });
}
