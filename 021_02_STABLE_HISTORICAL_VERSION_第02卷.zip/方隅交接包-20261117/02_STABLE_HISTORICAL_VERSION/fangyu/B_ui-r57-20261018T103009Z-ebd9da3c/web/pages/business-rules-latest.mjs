// Pure read-only rendering. Receives the already-authorized projection, never raw data.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const list=a=>'<ul>'+a.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul>';
const table=(head,rows)=>'<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;text-align:left"><thead><tr>'+head.map(x=>'<th style="padding:10px">'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(v=>'<td style="padding:10px;vertical-align:top">'+esc(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';

export function validateLatestBusinessReview(doc){
  if(!doc||doc.currentFiveLevelsVerified!==true||doc.fiveLevelsLiveVerified!==true
      ||doc.fiveLevelsApproved!==false||doc.proposalsPublished!==false
      ||doc.annualOnlyAppliedToProvider!==false||doc.snapshotOnly!==true
      ||typeof doc.verifiedSnapshot!=='string'||!doc.verifiedSnapshot
      ||!Array.isArray(doc.verifiedFacts)||!Array.isArray(doc.comparisonRows)
      ||!Array.isArray(doc.commentSignals)||!doc.commentSignals.length
      ||!Array.isArray(doc.originalRequirements)||!doc.originalRequirements.length
      ||!Array.isArray(doc.replyCapabilities))
    throw Error('最新核查记录尚未完整读到，未采用较早说明。');
  return doc;
}

const facts=doc=>'<details open><summary>最近核实的实际情况</summary><p>'+esc(doc.verifiedSnapshot)+'</p><p>'+esc(doc.reviewStatusNote)+'</p>'+table(['核对什么','已核实的情况'],doc.verifiedFacts.map(x=>[x.item,x.text]))+'</details>';

export function latestBusinessSection(doc,section,storeName){
  validateLatestBusinessReview(doc);
  if(section==='words'){
    const store=doc.stores.find(s=>s.name===storeName)||doc.stores[0];
    return facts(doc)+'<h3>搜索词分类</h3>'+table(['分类','说明','怎样使用'],doc.categoryGuide.map(x=>[x.name,x.meaning,x.rule]))
      +'<h3>'+esc(store.name)+'</h3><p>原有 '+store.originalCount+' 条，后补 '+store.addedCount+' 条，合计 '+store.totalCount+' 条；资料待核 '+store.pendingTermCount+' 条。</p>'
      +'<p>'+esc(store.taskUsageNote)+'</p><p>'+esc(doc.sourceHoldNotice)+'</p>'
      +doc.groups.map(group=>'<details'+(group==='租房强关联'?' open':'')+'><summary>'+esc(group)+' '+store.counts[group]+'条</summary>'
        +['原有资料','后来补充'].map(origin=>{
          const words=store.terms.filter(t=>t.group===group&&t.origin===origin);
          return words.length?'<h4>'+esc(origin)+'</h4><div class="wf-words">'+words.map(t=>'<span>'+esc(t.word)+'<small style="display:block;color:'+(t.pendingSource?'#89612b':'#63766b')+'">'+esc(t.statusText)+'</small></span>').join('')+'</div>':'';
        }).join('')+'</details>').join('');
  }
  if(section==='exclude')return '<h3>什么时候排除 什么时候保留</h3><p>结合整句话判断，不把这些表达当成见词就删的排除词；本次详细写法尚未启用。</p>'
    +doc.exclusions.map(x=>'<details><summary>'+esc(x.title)+'</summary><p><strong>排除或停止联系：</strong>'+esc(x.exclude)+'</p><p><strong>保留：</strong>'+esc(x.keep)+'</p><p>'+esc(x.example)+'</p><p><strong>现在的说明：</strong>'+esc(x.current)+'</p><p>'+esc(x.statusNote)+'</p></details>').join('')
    +'<h3>只做年租怎样筛</h3>'+table(['客户表达','处理办法'],doc.annualGuide.map(x=>[x.situation,x.handle]));
  if(section==='intent')return facts(doc)+'<h3>已核实的云端原有五级</h3><p>'+esc(doc.currentNote)+'</p>'
    +table(['等级','现用说明'],doc.currentFiveLevels.map(x=>[x.level,x.text]))+'<h3>待你确认的五级建议</h3><p>'+esc(doc.proposalNote)+'</p>'
    +table(['等级','建议','例句','差别与待定处'],doc.proposedFiveLevels.map(x=>[x.level,x.text,x.example,x.difference]))+'<p>'+esc(doc.followUpOrder)+'</p>';
  if(section==='checklist')return '<h3>先看四件事</h3>'+list(doc.simpleChecklist)+'<p>'+esc(doc.contactRule)+'</p><p>'+esc(doc.followUpOrder)+'</p>'
    +'<details><summary>搜索、DeepSeek和本机各做什么</summary>'+table(['内容','准备怎样用','当前情况','待接入安排'],doc.comparisonRows.map(x=>[x.content,x.planned,x.current,x.pending]))+'</details>'
    +'<details><summary>评论怎样判断 · 完整原表达</summary>'+table(['辨认什么','原资料表达','理解方式','现用说明'],doc.commentSignals.map(x=>[x.meaning,x.phrasesText,x.condition,x.current]))+'</details>';
  if(section==='meeting')return '<h3>尚未明确的事项</h3>'+list(doc.unknown)+'<h3>需要你确定的内容</h3>'
    +table(['问题','为什么要确认','建议或待定处'],doc.meetingQuestions.map(x=>[x.question,x.suggestion,x.decide]))
    +'<details><summary>现有回复口吻的真实能力</summary>'+table(['项目','核对情况'],doc.replyCapabilities.map(x=>[x.item,x.text]))+'</details>'
    +'<h3>原资料其他具体要求</h3><p>以下只作原稿对照，不代表已经批准或实现；旧分法不能当成已生效的新五级。</p>'
    +doc.originalRequirements.map(block=>'<details><summary>'+esc(block.title)+'</summary>'+table(['原要求','原资料意思','这次怎样处理'],block.rows.map(x=>[x.title,x.text,x.handling]))+'</details>').join('')
    +'<p>'+esc(doc.meetingPptNotice)+'</p>';
  return null;
}
