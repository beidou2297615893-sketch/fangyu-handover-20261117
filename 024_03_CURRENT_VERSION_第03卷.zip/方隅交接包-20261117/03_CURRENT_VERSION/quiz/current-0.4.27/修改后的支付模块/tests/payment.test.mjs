import test from 'node:test';
import assert from 'node:assert/strict';
let api;
try { api = await import('../src/lib/payment.js'); } catch { api = null; }
test('browser cannot fabricate an available payment account', async () => {
  assert.ok(api, 'native payment helper must be implemented');
  const result = await api.getPaymentStatus();
  assert.equal(result.available, false);
  assert.deepEqual(result.plans, []);
  assert.equal(result.entitlement, null);
});
test('purchase is an explicit native request and never grants access in JavaScript', async () => {
  assert.ok(api, 'native payment helper must be implemented');
  await assert.rejects(api.purchasePlan('once'), /安卓|原生|不可用/);
});


test('membership expiry is shown in seconds while extra credits remain visible', () => {
  const expiry = Math.floor(Date.now() / 1000) + 86400;
  assert.match(api.paymentEntitlementText({entitlement:{validUntil:expiry,runCredits:0},remainingText:'剩余 0 次'}), /套餐有效至/);
  assert.match(api.paymentEntitlementText({entitlement:{validUntil:expiry,runCredits:2}}), /另有 2 次/);
  assert.equal(api.paymentEntitlementText({entitlement:{validUntil:1,runCredits:0},remainingText:'剩余 0 次'}), '剩余 0 次');
  assert.equal(api.paymentEntitlementText({entitlement:{validUntil:expiry,requiresReview:true},remainingText:'待核对'}), '待核对');
});

test('simultaneous refreshes share one native request and foreground result updates subscribers without a request', async () => {
  const previous = globalThis.window;
  const host = new EventTarget();
  let calls = 0, reply;
  host.AndroidBridge = {paymentRequest(op, payload, id) { calls++; assert.equal(op, 'refresh'); reply = value => host.onNativePaymentResponse(id, JSON.stringify(value), null); }};
  globalThis.window = host;
  try {
    const a=api.refreshPayment(), b=api.refreshPayment();
    assert.equal(a,b); assert.equal(calls,1);
    reply({remainingText:'剩余 1 次'});
    assert.equal((await a).remainingText,'剩余 1 次');
    let latest;
    const unsubscribe=api.subscribePaymentStatus(value=>{latest=value});
    host.onNativePaymentStatus(JSON.stringify({entitlement:{validUntil:2000000000,runCredits:0}}));
    assert.equal(latest.entitlement.validUntil,2000000000); assert.equal(calls,1);
    host.onNativePaymentStatus('bad JSON'); assert.equal(latest.entitlement.validUntil,2000000000);
    unsubscribe();host.onNativePaymentStatus('{}');assert.equal(latest.entitlement.validUntil,2000000000);
  } finally { if(previous===undefined)delete globalThis.window;else globalThis.window=previous; }
});


test('trial text follows the server clock and asks for a plan after 72 hours', () => {
  const started = 1_700_000_000_000;
  const active = { eligible: true, active: true, reason: 'new-device', startedAt: started, expiresAt: started + 72 * 60 * 60 * 1000, serverNow: started + 60 * 60 * 1000 };
  assert.match(api.paymentEntitlementText({ trial: active, serverNow: active.serverNow, entitlement: null }, started + 100 * 60 * 60 * 1000), /免费试用至/);
  const expired = { ...active, active: false, serverNow: started + 73 * 60 * 60 * 1000 };
  assert.equal(api.paymentEntitlementText({ trial: expired, serverNow: expired.serverNow }, 0), '72小时试用已结束，请选择周套餐或月套餐');
  assert.match(api.paymentStatusNotice({ trial: expired, entitlement: { runCredits: 0, validUntil: null } }), /72小时试用已结束/);
  assert.match(api.paymentStatusNotice({ trialStale: true, trial: active }), /不会因此被取消/);
  assert.equal(api.paymentStatusNotice({ trial: active, entitlement: { runCredits: 0, validUntil: null } }), '');
});

test('customer notices separate unfinished order, empty entitlement and pending round end', () => {
  assert.match(api.paymentStatusNotice({pendingPayment:{},entitlement:{runCredits:0,validUntil:null}}), /上笔付款尚未确认/);
  assert.match(api.paymentStatusNotice({entitlement:{runCredits:0,validUntil:null}}), /没有可用的答题权益/);
  assert.match(api.paymentStatusNotice({pendingRunEnd:true,pendingPayment:{}}), /结束状态待核对/);
  assert.equal(api.paymentStatusNotice({entitlement:{runCredits:1,validUntil:null}}),'');
  assert.equal(api.paymentStatusNotice(null),'');
});

test('empty entitlement is not described as a confirmed plan', () => {
  const empty = { entitlement: { runCredits: 0, validUntil: null }, remainingText: '套餐权益已确认' };
  const text = api.paymentEntitlementText(empty);
  assert.equal(text, '请选择周套餐或月套餐');
  assert.doesNotMatch(text, /套餐权益已确认/);
  assert.match(api.paymentStatusNotice(empty), /没有可用的答题权益/);
  assert.doesNotMatch(api.paymentStatusNotice(empty), /套餐权益已确认/);
});

test('a valid membership still shows its end date', () => {
  const expiry = Math.floor(Date.now() / 1000) + 7 * 86400;
  assert.match(api.paymentEntitlementText({ entitlement: { validUntil: expiry, runCredits: 0 }, remainingText: '套餐权益已确认' }), /套餐有效至/);
});

test('an active trial stays visible and a failed claim is not shown as one', () => {
  const started = 1_700_000_000_000;
  const active = { eligible: true, active: true, reason: 'new-device', startedAt: started, expiresAt: started + 72 * 60 * 60 * 1000, serverNow: started + 60 * 60 * 1000 };
  assert.match(api.paymentEntitlementText({ trial: active, serverNow: active.serverNow, entitlement: null }), /免费试用至/);
  const business = '试用领取没有成功。服务器暂时无法确认，试用时间没有延长。';
  const failed = api.paymentEntitlementText({
    trial: active,
    trialError: { code: 'SERVICE_UNCONFIRMED', message: business },
    remainingText: '套餐权益已确认',
    entitlement: { runCredits: 0, validUntil: null }
  });
  assert.equal(failed, business);
  assert.doesNotMatch(failed, /免费试用/);
  assert.doesNotMatch(failed, /套餐权益已确认/);
  assert.equal(api.paymentStatusNotice({
    trial: active,
    trialError: { code: 'SERVICE_UNCONFIRMED', message: business },
    entitlement: { runCredits: 0, validUntil: null }
  }), '');
});

test('network loss and a business rejection stay different', () => {
  const started = 1_700_000_000_000;
  const active = { eligible: true, active: true, reason: 'new-device', expiresAt: started + 72 * 60 * 60 * 1000, serverNow: started };
  const offline = api.paymentEntitlementText({
    trialStale: true,
    trialError: { code: 'NETWORK_UNCONFIRMED', message: '网络暂时不可用。试用时间没有延长，请稍后重试。' },
    trial: active
  });
  const business = '试用领取没有成功。服务器暂时无法确认，试用时间没有延长。';
  const rejected = api.paymentEntitlementText({
    trialError: { code: 'SERVICE_UNCONFIRMED', message: business },
    entitlement: { runCredits: 0, validUntil: null },
    remainingText: '套餐权益已确认'
  });
  assert.match(offline, /无法连接服务器确认/);
  assert.match(offline, /不会因此被取消/);
  assert.equal(rejected, business);
  assert.notEqual(offline, rejected);
  assert.match(api.paymentStatusNotice({ trialStale: true, trial: active, entitlement: { runCredits: 0, validUntil: null } }), /无法连接服务器确认/);
  assert.equal(api.paymentStatusNotice({ trialError: { code: 'SERVICE_UNCONFIRMED', message: business }, entitlement: { runCredits: 0, validUntil: null } }), '');
});

test('a rejected claim does not invent a 72 hour trial', () => {
  const now = 1_700_000_000_000;
  const business = '试用领取没有成功。服务器暂时无法确认，试用时间没有延长。';
  const failed = api.paymentEntitlementText({
    trialError: { code: 'SERVICE_UNCONFIRMED', message: business },
    entitlement: { runCredits: 0, validUntil: null },
    remainingText: '套餐权益已确认'
  }, now);
  assert.equal(failed, business);
  assert.doesNotMatch(failed, /免费试用至/);
  assert.doesNotMatch(failed, /72小时试用/);
  const blocked = {
    trial: { eligible: false, active: false, reason: 'existing-free-device', startedAt: null, expiresAt: null, serverNow: now },
    serverNow: now,
    entitlement: { runCredits: 0, validUntil: null },
    remainingText: '套餐权益已确认'
  };
  assert.equal(api.paymentEntitlementText(blocked, now), '这台设备已有旧的免费记录，不能再领取72小时试用。');
  assert.equal(api.paymentStatusNotice(blocked, now), '');
  assert.equal(api.paymentEntitlementText({
    trial: { eligible: false, active: false, reason: 'not-activated', serverNow: now },
    serverNow: now,
    remainingText: '套餐权益已确认'
  }, now), '试用还没有激活。');
});
