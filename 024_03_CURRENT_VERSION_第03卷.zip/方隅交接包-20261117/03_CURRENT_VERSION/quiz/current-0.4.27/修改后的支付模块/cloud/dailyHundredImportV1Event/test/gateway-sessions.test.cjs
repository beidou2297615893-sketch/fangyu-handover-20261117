'use strict';
const assert = require('node:assert/strict');
const { createSessions } = require('../lib/gateway-sessions.cjs');

// Mirrors @cloudbase/database 1.4.3 runTransaction: one callback attempt, and
// on DATABASE_TRANSACTION_CONFLICT only, re-invoke with times-1. times=3 runs
// the callback at most 4 times (3,2,1,0). This is not a CloudBase server.
function memoryDb() {
  const committed = new Map();
  const versions = new Map();
  const ops = [];
  const state = { hook: null, conflictsLeft: 0, missNextUpdate: false, alwaysConflictUpdates: false, attempts: 0 };
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const db = {
    committed,
    versions,
    ops,
    get attempts() { return state.attempts; },
    onceAfterRead(fn) { state.hook = fn; },
    failUpdates(n) { state.conflictsLeft = n; },
    armMissUpdate() { state.missNextUpdate = true; },
    set alwaysConflictUpdates(value) { state.alwaysConflictUpdates = value; },
    async runTransaction(fn, times = 3) {
      const attempt = async (left) => {
        state.attempts += 1;
        const base = new Map();
        const local = new Map();
        const dirty = new Map();
        const tx = {
          collection() {
            return {
              doc(id) {
                return {
                  async get() {
                    if (!base.has(id)) {
                      base.set(id, versions.get(id) || 0);
                      if (committed.has(id)) local.set(id, clone(committed.get(id)));
                    }
                    const data = local.has(id) ? { _id: id, ...local.get(id) } : null;
                    if (state.hook) {
                      const fnHook = state.hook;
                      state.hook = null;
                      const handled = await fnHook(id);
                      if (handled !== true) state.hook = fnHook;
                    }
                    return { data };
                  },
                  async set(value) {
                    if (!base.has(id)) base.set(id, versions.get(id) || 0);
                    local.set(id, clone(value));
                    dirty.set(id, 'set');
                    ops.push({ op: 'set', id, keys: Object.keys(value).sort() });
                    return { updated: 1 };
                  },
                  async update(value) {
                    ops.push({ op: 'update', id, keys: Object.keys(value).sort(), value: clone(value) });
                    if (state.alwaysConflictUpdates || state.conflictsLeft > 0) {
                      if (state.conflictsLeft > 0) state.conflictsLeft -= 1;
                      return { code: 'DATABASE_TRANSACTION_CONFLICT' };
                    }
                    if (state.missNextUpdate) {
                      state.missNextUpdate = false;
                      return { updated: 0 };
                    }
                    if (!local.has(id)) return { updated: 0 };
                    local.set(id, { ...local.get(id), ...clone(value) });
                    if (dirty.get(id) !== 'set') dirty.set(id, 'update');
                    return { updated: 1 };
                  },
                };
              },
            };
          },
        };
        try {
          const result = await fn(tx);
          for (const id of dirty.keys()) {
            if ((base.get(id) || 0) !== (versions.get(id) || 0)) {
              const error = new Error('database transaction conflict');
              error.code = 'DATABASE_TRANSACTION_CONFLICT';
              throw error;
            }
          }
          for (const id of dirty.keys()) {
            committed.set(id, clone(local.get(id)));
            versions.set(id, (versions.get(id) || 0) + 1);
          }
          return result;
        } catch (error) {
          if (left > 0 && error && error.code === 'DATABASE_TRANSACTION_CONFLICT') return attempt(left - 1);
          throw error;
        }
      };
      return attempt(times);
    },
  };
  return db;
}

const input = {
  credential: 'ignored-by-verify',
  runId: 'run-1',
  taskBinding: 'a'.repeat(64),
  source: 'free',
  deviceDigest: 'b'.repeat(64),
};

function runDoc(db) {
  const key = [...db.committed.keys()].find((item) => item.startsWith('gr-'));
  assert.equal(typeof key, 'string');
  return { key, row: db.committed.get(key) };
}

function sameExceptExpiry(before, after) {
  assert.deepEqual(
    Object.keys(after).sort(),
    Object.keys(before).sort(),
  );
  for (const key of Object.keys(before)) {
    if (key === 'expiresAt') continue;
    assert.deepEqual(after[key], before[key]);
  }
}

async function main() {
  let verifies = 0;
  const verify = async () => {
    verifies += 1;
    return { ownerId: 'owner-1', status: 'authorized', source: 'free' };
  };
  let now = 1_000_000;
  const db = memoryDb();
  const sessions = createSessions({ db, providerKey: 'test-key', verify, clock: () => now });

  const created = await sessions.exchange(input);
  assert.equal(created.used, 0);
  assert.equal(created.limit, 160);
  assert.equal(created.expiresAt, now + 3600000);
  assert.equal(created.token.length, 43);
  assert.equal(verifies, 1);

  now += 1000;
  const reused = await sessions.exchange(input);
  assert.equal(reused.expiresAt, created.expiresAt);
  assert.equal(reused.token, created.token);
  assert.equal(verifies, 2);

  now = created.expiresAt + 1;
  const beforeRenew = { ...runDoc(db).row };
  const attemptsBefore = db.attempts;
  const opsBefore = db.ops.length;
  db.failUpdates(1);
  const renewed = await sessions.exchange(input);
  assert.equal(renewed.token, created.token);
  assert.equal(renewed.used, 0);
  assert.equal(renewed.expiresAt, now + 3600000);
  assert.equal(verifies, 3);
  assert.equal(db.attempts - attemptsBefore, 2);
  const afterRenew = runDoc(db).row;
  sameExceptExpiry(beforeRenew, afterRenew);
  assert.equal(afterRenew.expiresAt, now + 3600000);
  const renewalOps = db.ops.slice(opsBefore).filter((op) => op.op === 'update');
  assert.equal(renewalOps.length, 2);
  for (const op of renewalOps) assert.deepEqual(op.value, { expiresAt: now + 3600000 });
  assert.equal(db.ops.slice(opsBefore).some((op) => op.op === 'set' && op.id.startsWith('gr-')), false);

  const { key: runKey } = runDoc(db);
  const spent = { ...db.committed.get(runKey), used: 160, expiresAt: now - 1 };
  db.committed.set(runKey, spent);
  await assert.rejects(() => sessions.exchange(input));
  assert.equal(db.committed.get(runKey).used, 160);
  assert.equal(db.committed.get(runKey).expiresAt, now - 1);

  db.committed.set(runKey, { ...spent, used: 4, state: 'closed', expiresAt: now - 1 });
  await assert.rejects(() => sessions.exchange(input));
  assert.equal(db.committed.get(runKey).state, 'closed');

  const denied = createSessions({
    db: memoryDb(),
    providerKey: 'test-key',
    verify: async () => { throw new Error('not authorized'); },
    clock: () => now,
  });
  await assert.rejects(() => denied.exchange(input));

  await testUnexpiredExhausted();
  await testConsumeCloseAndRenewKeepsUsed();
  await testOverlappingConsumes();
  await testRenewLosesToClose();
  await testRenewLosesToSpent();
  await testDeletedRunIsNotRecreated();
  await testUpdateMissDoesNotUpsert();
  await testConflictRetryIsBounded();
  await testDuplicateExchangeDoesNotWrite();
  await testMissingIndexIsNotRebuilt();
  await testForeignIndexIsRejected();
  await testFirstCreateWritesRunAndIndex();
  await testTrialSourceIsSeparateFromFree();
  await testSourceIsolation();
  await testTrialAdmissionMatrix();
  console.log('gateway-sessions.test.cjs ok');
}

async function testTrialSourceIsSeparateFromFree() {
  let now = 9_000_000;
  const db = memoryDb();
  const sessions = createSessions({
    db,
    providerKey: 'test-key',
    verify: async (value) => {
      if (value.source !== 'trial') throw new Error('unexpected source');
      return { ownerId: 'owner-1', status: 'authorized', source: 'trial' };
    },
    clock: () => now,
  });
  const trialInput = { ...input, source: 'trial', runId: 'run-trial' };
  const created = await sessions.exchange(trialInput);
  assert.equal(created.limit, 160);
  assert.equal(created.expiresAt, now + 3600000);
  assert.equal(runDoc(db).row.source, 'trial');
  const mismatch = createSessions({
    db: memoryDb(),
    providerKey: 'test-key',
    verify: async () => ({ ownerId: 'owner-1', status: 'authorized', source: 'free' }),
    clock: () => now,
  });
  await assert.rejects(() => mismatch.exchange(trialInput));
  const noDigest = createSessions({
    db: memoryDb(),
    providerKey: 'test-key',
    verify: async () => ({ ownerId: 'owner-1', status: 'authorized', source: 'trial' }),
    clock: () => now,
  });
  const { deviceDigest: _ignored, ...withoutDigest } = trialInput;
  await assert.rejects(() => noDigest.exchange(withoutDigest));
}

async function testSourceIsolation() {
  const now = 9_000_000;
  const digest = 'b'.repeat(64);
  const binding = 'a'.repeat(64);
  async function attempt(source, verified, runId) {
    const sessions = createSessions({
      db: memoryDb(),
      providerKey: 'test-key',
      verify: async () => ({ ownerId: 'owner-1', status: 'authorized', source: verified }),
      clock: () => now,
    });
    return sessions.exchange({
      credential: 'ignored-by-verify',
      runId,
      taskBinding: binding,
      source,
      deviceDigest: digest,
    });
  }
  await assert.rejects(() => attempt('paid', 'trial', 'run-paid-trial'));
  await assert.rejects(() => attempt('trial', 'free', 'run-trial-free'));
  await assert.rejects(() => attempt('free', 'trial', 'run-free-trial'));
  const credit = await attempt('paid', 'credit', 'run-paid-credit');
  assert.equal(credit.limit, 160);
  assert.equal(credit.expiresAt, now + 3600000);
  const subscription = await attempt('paid', 'subscription', 'run-paid-subscription');
  assert.equal(subscription.limit, 160);
  assert.equal(subscription.expiresAt, now + 3600000);
}

async function testTrialAdmissionMatrix() {
  const crypto = require('node:crypto');
  const now0 = 11_000_000;
  const digest = 'b'.repeat(64);
  const binding = 'a'.repeat(64);
  const owner = 'owner-1';
  function tokenForRun(runId) {
    const token = crypto.createHmac('sha256', 'test-key').update(JSON.stringify(['gateway-session-v1', owner, runId, binding])).digest('base64url');
    return { token, tokenHash: crypto.createHash('sha256').update(token, 'utf8').digest('hex') };
  }
  async function attempt(source, verified, runId, deviceDigest = digest) {
    const calls = [];
    const db = memoryDb();
    const sessions = createSessions({
      db,
      providerKey: 'test-key',
      verify: async (value) => {
        assert.equal(db.ops.length, 0);
        calls.push({
          runState: value.runState,
          source: value.source,
          runId: value.runId,
          taskBinding: value.taskBinding,
          deviceDigest: value.deviceDigest,
        });
        return { ownerId: owner, status: 'authorized', source: verified };
      },
      clock: () => now0,
    });
    const body = { credential: 'ignored-by-verify', runId, taskBinding: binding, source };
    if (deviceDigest !== undefined) body.deviceDigest = deviceDigest;
    try {
      const result = await sessions.exchange(body);
      return { ok: true, result, calls, db };
    } catch (error) {
      return { ok: false, error, calls, db };
    }
  }

  const trial = await attempt('trial', 'trial', 'run-matrix-trial');
  assert.equal(trial.ok, true);
  assert.equal(trial.calls.length, 1);
  assert.equal(trial.calls[0].runState, 'confirmed');
  assert.equal(trial.calls[0].source, 'trial');
  assert.equal(trial.calls[0].runId, 'run-matrix-trial');
  assert.equal(trial.calls[0].taskBinding, binding);
  assert.equal(trial.calls[0].deviceDigest, digest);
  assert.equal(trial.result.limit, 160);
  assert.equal(trial.result.used, 0);
  assert.equal(trial.result.expiresAt, now0 + 3600000);
  const expectedTrial = tokenForRun('run-matrix-trial');
  assert.equal(trial.result.token, expectedTrial.token);
  const trialRow = runDoc(trial.db).row;
  assert.equal(trialRow.owner, owner);
  assert.equal(trialRow.binding, binding);
  assert.equal(trialRow.tokenHash, expectedTrial.tokenHash);
  assert.equal(trialRow.source, 'trial');
  assert.equal(trialRow.used, 0);
  assert.equal(trialRow.limit, 160);

  for (const [source, verified, runId] of [
    ['trial', 'free', 'run-matrix-trial-free'],
    ['trial', 'credit', 'run-matrix-trial-credit'],
    ['paid', 'trial', 'run-matrix-paid-trial'],
  ]) {
    const denied = await attempt(source, verified, runId);
    assert.equal(denied.ok, false);
    assert.equal(denied.error.message, 'session unavailable');
    assert.equal(denied.calls.length, 1);
    assert.equal(denied.calls[0].runState, 'confirmed');
    assert.equal(denied.calls[0].source, source);
    assert.equal(denied.db.committed.size, 0);
    assert.equal(denied.db.ops.length, 0);
  }

  const credit = await attempt('paid', 'credit', 'run-matrix-paid-credit');
  assert.equal(credit.ok, true);
  assert.equal(credit.calls[0].runState, 'confirmed');
  assert.equal(credit.calls[0].source, 'paid');
  assert.equal(credit.result.limit, 160);
  assert.equal(credit.result.used, 0);
  assert.equal(credit.result.expiresAt, now0 + 3600000);
  assert.equal(runDoc(credit.db).row.source, 'paid');
  assert.equal(runDoc(credit.db).row.tokenHash, tokenForRun('run-matrix-paid-credit').tokenHash);

  const subscription = await attempt('paid', 'subscription', 'run-matrix-paid-subscription');
  assert.equal(subscription.ok, true);
  assert.equal(subscription.calls[0].runState, 'confirmed');
  assert.equal(subscription.result.limit, 160);
  assert.equal(subscription.result.expiresAt, now0 + 3600000);
  assert.equal(runDoc(subscription.db).row.source, 'paid');

  const badDigests = ['', 'b'.repeat(63), 'g'.repeat(64), 'B'.repeat(64), 'b'.repeat(65), null];
  for (let i = 0; i < badDigests.length; i += 1) {
    const denied = await attempt('trial', 'trial', 'run-matrix-bad-' + i, badDigests[i]);
    assert.equal(denied.ok, false);
    assert.equal(denied.error.message, 'session unavailable');
    assert.equal(denied.calls.length, 0);
    assert.equal(denied.db.committed.size, 0);
    assert.equal(denied.db.ops.length, 0);
  }
  const unknownSource = await attempt('gift', 'trial', 'run-matrix-gift');
  assert.equal(unknownSource.ok, false);
  assert.equal(unknownSource.calls.length, 0);
  assert.equal(unknownSource.db.committed.size, 0);

  let now = now0;
  const usedDb = memoryDb();
  const usedSessions = createSessions({
    db: usedDb,
    providerKey: 'test-key',
    verify: async (value) => {
      assert.equal(value.runState, 'confirmed');
      return { ownerId: owner, status: 'authorized', source: 'trial' };
    },
    clock: () => now,
  });
  const usedBody = { credential: 'ignored-by-verify', runId: 'run-matrix-used', taskBinding: binding, source: 'trial', deviceDigest: digest };
  const usedCreated = await usedSessions.exchange(usedBody);
  const usedDoc = runDoc(usedDb);
  const stamped = { ...usedDoc.row, used: 160 };
  usedDb.committed.set(usedDoc.key, stamped);
  const opsAtCap = usedDb.ops.length;
  const capped = await usedSessions.exchange(usedBody);
  assert.equal(capped.used, 160);
  assert.equal(capped.token, usedCreated.token);
  assert.equal(capped.expiresAt, stamped.expiresAt);
  assert.equal(usedDb.ops.length, opsAtCap);
  assert.equal(usedDb.committed.get(usedDoc.key).used, 160);
  assert.equal(usedDb.committed.get(usedDoc.key).tokenHash, stamped.tokenHash);
  assert.equal(usedDb.committed.get(usedDoc.key).binding, binding);
  assert.equal(usedDb.committed.get(usedDoc.key).owner, owner);
  await assert.rejects(() => usedSessions.consume(usedCreated.token), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(usedDb.committed.get(usedDoc.key).used, 160);
  now = stamped.expiresAt + 1;
  await assert.rejects(() => usedSessions.exchange(usedBody), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(usedDb.committed.get(usedDoc.key).used, 160);
  assert.equal(usedDb.committed.get(usedDoc.key).expiresAt, stamped.expiresAt);
  assert.equal(usedDb.committed.get(usedDoc.key).tokenHash, stamped.tokenHash);
  assert.equal(usedDb.committed.get(usedDoc.key).binding, binding);
  assert.equal(usedDb.committed.get(usedDoc.key).owner, owner);
  assert.equal(usedDb.committed.get(usedDoc.key).source, 'trial');

  now = now0;
  const renewDb = memoryDb();
  const renewSessions = createSessions({
    db: renewDb,
    providerKey: 'test-key',
    verify: async (value) => {
      assert.equal(value.runState, 'confirmed');
      assert.equal(value.source, 'trial');
      return { ownerId: owner, status: 'authorized', source: 'trial' };
    },
    clock: () => now,
  });
  const renewBody = { credential: 'ignored-by-verify', runId: 'run-matrix-renew', taskBinding: binding, source: 'trial', deviceDigest: digest };
  const renewCreated = await renewSessions.exchange(renewBody);
  const renewDoc = runDoc(renewDb);
  renewDb.committed.set(renewDoc.key, { ...renewDoc.row, used: 7 });
  now = renewDoc.row.expiresAt + 1;
  const beforeRenew = { ...renewDb.committed.get(renewDoc.key) };
  const opsBeforeRenew = renewDb.ops.length;
  const renewed = await renewSessions.exchange(renewBody);
  assert.equal(renewed.token, renewCreated.token);
  assert.equal(renewed.used, 7);
  assert.equal(renewed.expiresAt, now + 3600000);
  const afterRenew = renewDb.committed.get(renewDoc.key);
  sameExceptExpiry(beforeRenew, afterRenew);
  assert.equal(afterRenew.expiresAt, now + 3600000);
  assert.equal(afterRenew.owner, owner);
  assert.equal(afterRenew.binding, binding);
  assert.equal(afterRenew.tokenHash, beforeRenew.tokenHash);
  assert.equal(afterRenew.used, 7);
  assert.equal(afterRenew.source, 'trial');
  const renewUpdates = renewDb.ops.slice(opsBeforeRenew).filter((op) => op.op === 'update');
  assert.equal(renewUpdates.length, 1);
  assert.deepEqual(renewUpdates[0].value, { expiresAt: now + 3600000 });

  now = now0;
  const identityDb = memoryDb();
  const identitySessions = createSessions({
    db: identityDb,
    providerKey: 'test-key',
    verify: async (value) => {
      assert.equal(value.runState, 'confirmed');
      return { ownerId: owner, status: 'authorized', source: 'trial' };
    },
    clock: () => now,
  });
  const identityBody = { credential: 'ignored-by-verify', runId: 'run-matrix-identity', taskBinding: binding, source: 'trial', deviceDigest: digest };
  await identitySessions.exchange(identityBody);
  const identityDoc = runDoc(identityDb);
  const identityRow = identityDoc.row;
  now = identityRow.expiresAt + 1;
  for (const patch of [{ owner: 'owner-2' }, { binding: 'c'.repeat(64) }, { tokenHash: 'd'.repeat(64) }]) {
    identityDb.committed.set(identityDoc.key, { ...identityRow, ...patch });
    const ops = identityDb.ops.length;
    await assert.rejects(() => identitySessions.exchange(identityBody), (error) => error instanceof Error && error.message === 'session unavailable');
    const kept = identityDb.committed.get(identityDoc.key);
    assert.equal(kept.expiresAt, identityRow.expiresAt);
    assert.equal(kept.used, identityRow.used);
    assert.equal(identityDb.ops.slice(ops).some((op) => op.op === 'update' || op.op === 'set'), false);
  }
}

async function openFresh() {
  let verifies = 0;
  const verify = async () => {
    verifies += 1;
    return { ownerId: 'owner-1', status: 'authorized', source: 'free' };
  };
  let now = 5_000_000;
  const db = memoryDb();
  const sessions = createSessions({ db, providerKey: 'test-key', verify, clock: () => now });
  const created = await sessions.exchange(input);
  return {
    db,
    sessions,
    created,
    get now() { return now; },
    set now(value) { now = value; },
    verifies: () => verifies,
  };
}

async function testUnexpiredExhausted() {
  const env = await openFresh();
  const { key } = runDoc(env.db);
  const row = env.db.committed.get(key);
  env.db.committed.set(key, { ...row, used: 160 });
  const ops = env.db.ops.length;
  const got = await env.sessions.exchange(input);
  assert.equal(got.used, 160);
  assert.equal(got.expiresAt, row.expiresAt);
  assert.equal(env.db.ops.length, ops);
  assert.equal(env.db.committed.get(key).used, 160);
}

async function testConsumeCloseAndRenewKeepsUsed() {
  const env = await openFresh();
  assert.equal(await env.sessions.consume(env.created.token), true);
  assert.equal(await env.sessions.consume(env.created.token), true);
  const { key, row } = runDoc(env.db);
  assert.equal(row.used, 2);
  env.now = row.expiresAt + 1;
  const renewed = await env.sessions.exchange(input);
  assert.equal(renewed.used, 2);
  assert.equal(renewed.expiresAt, env.now + 3600000);
  assert.equal(env.db.committed.get(key).used, 2);
  assert.equal(env.db.committed.get(key).state, 'active');
  const again = await env.sessions.exchange(input);
  assert.equal(again.used, 2);
  assert.equal(again.expiresAt, renewed.expiresAt);
  await env.sessions.close(env.created.token);
  assert.equal(env.db.committed.get(key).state, 'closed');
  assert.equal(env.db.committed.get(key).used, 2);
  await assert.rejects(() => env.sessions.consume(env.created.token));
  await assert.rejects(() => env.sessions.exchange(input));
  assert.equal(env.db.committed.get(key).state, 'closed');
  assert.equal(env.db.committed.get(key).used, 2);
}

async function testOverlappingConsumes() {
  const env = await openFresh();
  const { key } = runDoc(env.db);
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    assert.equal(await env.sessions.consume(env.created.token), true);
    return true;
  });
  assert.equal(await env.sessions.consume(env.created.token), true);
  assert.equal(env.db.committed.get(key).used, 2);
  assert.equal(env.db.committed.get(key).expiresAt, env.created.expiresAt);
}

async function testRenewLosesToClose() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    assert.equal(await env.sessions.close(env.created.token), true);
    return true;
  });
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.get(key).state, 'closed');
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, 0);
}

async function testRenewLosesToSpent() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    await env.db.runTransaction(async (tx) => {
      const ref = tx.collection('daily_hundred_import_v1').doc(id);
      const current = await ref.get();
      const { _id, ...stored } = current.data;
      await ref.set({ ...stored, used: 160 });
    });
    return true;
  });
  await assert.rejects(() => env.sessions.exchange(input));
  assert.equal(env.db.committed.get(key).used, 160);
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).state, 'active');
}

async function testDeletedRunIsNotRecreated() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  env.now = row.expiresAt + 1;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    env.db.committed.delete(id);
    env.db.versions.set(id, (env.db.versions.get(id) || 0) + 1);
    return true;
  });
  await assert.rejects(() => env.sessions.exchange(input));
  assert.equal(env.db.committed.has(key), false);
  assert.equal(env.db.committed.has(indexKey), true);
}

async function testUpdateMissDoesNotUpsert() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  const ops = env.db.ops.length;
  env.db.armMissUpdate();
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  const written = env.db.ops.slice(ops);
  assert.equal(written.length, 1);
  assert.equal(written[0].op, 'update');
  assert.deepEqual(written[0].value, { expiresAt: env.now + 3600000 });
  assert.equal(written.some((op) => op.op === 'set'), false);
}

async function testConflictRetryIsBounded() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  const attempts = env.db.attempts;
  const verifies = env.verifies();
  env.db.alwaysConflictUpdates = true;
  await assert.rejects(
    () => env.sessions.exchange(input),
    (error) => error && error.code === 'DATABASE_TRANSACTION_CONFLICT',
  );
  assert.equal(env.db.attempts - attempts, 4);
  assert.equal(env.verifies(), verifies + 1);
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  assert.equal(env.db.committed.get(key).state, 'active');
}

async function testDuplicateExchangeDoesNotWrite() {
  const env = await openFresh();
  const ops = env.db.ops.length;
  let nested = 0;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    nested += 1;
    const other = await env.sessions.exchange(input);
    assert.equal(other.token, env.created.token);
    assert.equal(other.expiresAt, env.created.expiresAt);
    assert.equal(other.used, 0);
    return true;
  });
  const again = await env.sessions.exchange(input);
  assert.equal(nested, 1);
  assert.equal(again.token, env.created.token);
  assert.equal(again.expiresAt, env.created.expiresAt);
  assert.equal(env.db.ops.length, ops);
  assert.equal(runDoc(env.db).row.used, 0);
}

async function testMissingIndexIsNotRebuilt() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  env.db.committed.delete(indexKey);
  const ops = env.db.ops.length;
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.has(indexKey), false);
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  assert.equal(env.db.ops.length, ops);
}

async function testForeignIndexIsRejected() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  env.db.committed.set(indexKey, { ...env.db.committed.get(indexKey), runKey: 'gr-other' });
  const ops = env.db.ops.length;
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.get(indexKey).runKey, 'gr-other');
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  assert.equal(env.db.ops.length, ops);
}

async function testFirstCreateWritesRunAndIndex() {
  const env = await openFresh();
  const run = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  assert.equal(env.db.committed.get(indexKey).kind, 'gateway-session-v1');
  assert.equal(env.db.committed.get(indexKey).runKey, run.key);
  assert.equal(run.row.used, 0);
  assert.equal(run.row.state, 'active');
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
