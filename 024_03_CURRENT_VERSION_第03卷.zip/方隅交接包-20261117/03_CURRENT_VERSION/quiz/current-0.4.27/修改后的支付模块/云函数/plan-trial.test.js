'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {SALE,quoteFor,membershipUntil,trialExpiry,TRIAL_MS,DAY_MS}=require('./plan-rules');
const {createTrial}=require('./trial-ledger');
const {createProductionService,createInternalCore}=require('./payment-core');
const {createProductionMain,createInternalRouter}=require('./billing-event');

function memoryDb(){
  const docs=new Map();
  const flags={failWrites:0,failReads:0};
  function api(collection){
    return {doc(id){
      const key=collection+'/'+id;
      return {
        async get(){
          if(flags.failReads>0){flags.failReads--;throw Error('network');}
          if(flags.readCode){const code=flags.readCode;flags.readCode=null;return {code};}
          if(!docs.has(key))return {data:null};
          return {data:{_id:id,...JSON.parse(JSON.stringify(docs.get(key)))}};
        },
        async set(value){
          if(flags.failWrites>0){flags.failWrites--;throw Error('network');}
          if(flags.writeCode){const code=flags.writeCode;flags.writeCode=null;return {code};}
          docs.set(key,JSON.parse(JSON.stringify(value)));
          return {updated:1,upserted:[{_id:id}]};
        }
      };
    }};
  }
  return {docs,flags,runTransaction(fn){return Promise.resolve(fn({collection:api}))}};
}
const digest=name=>crypto.createHash('sha256').update(name).digest('hex');
const owner='i'+'ab'.repeat(16);
const other='i'+'cd'.repeat(16);

test('sale catalog is only the week and month plans',()=>{
  assert.deepEqual(Object.keys(SALE),['week','month']);
  assert.equal(SALE.week.fen,490);assert.equal(SALE.week.amount,'4.90');assert.equal(SALE.week.days,7);assert.equal(SALE.week.credits,0);
  assert.equal(SALE.month.fen,990);assert.equal(SALE.month.amount,'9.90');assert.equal(SALE.month.days,30);assert.equal(SALE.month.credits,0);
  assert.equal(saleOnce(),null);
  assert.equal(quoteFor('week',590).amount,'5.90');
  assert.equal(quoteFor('week',590).days,7);
  assert.equal(quoteFor('once',100).credits,1);
  assert.equal(quoteFor('week',100),null);
  function saleOnce(){return Object.hasOwn(SALE,'once')?SALE.once:null}
});

test('membership duration is exact server-side day counts and does not use a phone clock',()=>{
  const granted=1_700_000_000_000;
  assert.equal(membershipUntil(0,granted,7),granted+7*DAY_MS);
  assert.equal(membershipUntil(granted+DAY_MS,granted,30),granted+DAY_MS+30*DAY_MS);
  assert.equal(trialExpiry(granted),granted+TRIAL_MS);
  assert.equal(TRIAL_MS,72*60*60*1000);
});

test('production payment entry stays disabled',async()=>{
  assert.throws(()=>createProductionService(),/disabled/);
  const disabled=createProductionMain();
  const status=await disabled();
  assert.equal(status.statusCode,503);
  assert.match(status.body,/realPaymentsEnabled":false/);
});

test('new trial is 72 hours, idempotent, and ignores a later clock change',async()=>{
  const db=memoryDb();
  let now=1_700_000_000_000;
  const trial=createTrial({db,clock:()=>now,hasPriorFreeDevice:async()=>false});
  const device=digest('new-phone');
  const first=await trial.activate(owner,device);
  assert.equal(first.active,true);
  assert.equal(first.expiresAt-first.startedAt,TRIAL_MS);
  now+=60*60*1000;
  const retry=await trial.activate(other,device);
  assert.equal(retry.startedAt,first.startedAt);
  assert.equal(retry.expiresAt,first.expiresAt);
  assert.equal(retry.active,true);
  now=first.expiresAt-1;
  assert.equal((await trial.status(owner,device)).active,true);
  now=first.expiresAt;
  const expired=await trial.status(owner,device);
  assert.equal(expired.active,false);
  assert.equal(expired.expiresAt,first.expiresAt);
});

test('an existing free-device record does not receive another trial',async()=>{
  const db=memoryDb();
  const trial=createTrial({db,clock:()=>1000,hasPriorFreeDevice:async()=>true});
  const row=await trial.activate(owner,digest('old-phone'));
  assert.equal(row.eligible,false);
  assert.equal(row.active,false);
  assert.equal(row.reason,'existing-free-device');
  assert.equal(row.expiresAt,null);
  const again=await trial.activate(other,digest('old-phone'));
  assert.equal(again.eligible,false);
});

test('a failed write does not create a trial and a later read error does not delete one',async()=>{
  const db=memoryDb();
  db.flags.failWrites=1;
  const trial=createTrial({db,clock:()=>5000,hasPriorFreeDevice:async()=>false});
  const device=digest('flaky');
  await assert.rejects(()=>trial.activate(owner,device));
  assert.equal([...db.docs.keys()].some(key=>key.includes('trial-')),false);
  const created=await trial.activate(owner,device);
  assert.equal(created.active,true);
  db.flags.failReads=1;
  await assert.rejects(()=>trial.status(owner,device));
  const still=await trial.status(owner,device);
  assert.equal(still.startedAt,created.startedAt);
  assert.equal(still.expiresAt,created.expiresAt);
});

test('trial reserve is idempotent and stops when the server trial has expired',async()=>{
  const db=memoryDb();
  let now=10_000;
  const trial=createTrial({db,clock:()=>now,hasPriorFreeDevice:async()=>false});
  const device=digest('runner');
  const binding='ab'.repeat(32);
  await trial.activate(owner,device);
  const first=await trial.reserve(owner,device,'run-1',binding);
  const second=await trial.reserve(owner,device,'run-1',binding);
  assert.equal(first.status,'reserved');
  assert.equal(second.status,'reserved');
  assert.equal([...db.docs.keys()].filter(key=>key.includes('/run-')).length,1);
  await trial.confirm(owner,device,'run-1',binding);
  now=(await trial.status(owner,device)).expiresAt;
  await assert.rejects(()=>trial.resume(owner,device,'run-1',binding));
  await assert.rejects(()=>trial.reserve(owner,device,'run-2',binding));
});

test('cancelled payment order is not an entitlement and the same request is not a second order',async()=>{
  const db=memoryDb();
  const {publicKey,privateKey}=crypto.generateKeyPairSync('rsa',{modulusLength:2048});
  const core=createInternalCore({
    db,
    appId:'app123',sellerId:'seller123',
    privateKey:privateKey.export({type:'pkcs8',format:'pem'}).toString(),
    publicKey:publicKey.export({type:'spki',format:'pem'}).toString(),
    notifyUrl:'https://example.com/api/billing/alipay/notify',
    returnUrl:'https://example.com/api/billing/alipay/return',
    clock:()=>1_700_000_000_000
  });
  await assert.rejects(()=>core.createOrder('owner-A','req-once','once'),/unavailable/);
  const created=await core.createOrder('owner-A','req-week','week');
  assert.equal(created.amountFen,490);
  assert.match(created.checkoutUrl,/4\.90/);
  const replay=await core.createOrder('owner-A','req-week','week');
  assert.equal(replay.id,created.id);
  assert.equal(replay.amountFen,490);
  await assert.rejects(()=>core.createOrder('owner-A','req-week','month'),/unavailable/);
  const orders=[...db.docs.keys()].filter(key=>key.includes('/order-'));
  assert.equal(orders.length,1);
  assert.equal([...db.docs.values()].some(row=>row.kind==='grant'),false);
  const month=await core.createOrder('owner-A','req-month','month');
  assert.equal(month.amountFen,990);
  assert.match(month.checkoutUrl,/9\.90/);
  const ownerId='owner-old';
  const requestId='req-old-week';
  const oldId='o'+crypto.createHash('sha256').update(JSON.stringify([ownerId,requestId]),'utf8').digest('hex').slice(0,63);
  db.docs.set('daily_hundred_payment_v1/order-'+oldId,{kind:'order',orderId:oldId,owner:ownerId,requestId,plan:'week',amountFen:590,status:'pending'});
  const old=await core.createOrder(ownerId,requestId,'week');
  assert.equal(old.id,oldId);
  assert.equal(old.amountFen,590);
  assert.match(old.checkoutUrl,/5\.90/);
});

test('trial route requires the server and does not mark success by itself',async()=>{
  const db=memoryDb();
  let now=1_700_000_000_000;
  const trial=createTrial({db,clock:()=>now,hasPriorFreeDevice:async()=>false});
  const raw=Buffer.alloc(32);raw[0]=0x49;
  const token=raw.toString('base64url');
  const router=createInternalRouter({
    installation:{authenticate:async()=>owner},
    verifyTaskBinding:async()=>true,
    trial
  });
  const device=digest('route');
  const response=await router({httpMethod:'POST',path:'/api/billing/trial/activate',headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify({deviceDigest:device})});
  assert.equal(response.statusCode,200);
  const body=JSON.parse(response.body);
  assert.equal(body.active,true);
  assert.equal(body.serverNow,now);
  const missing=await router({httpMethod:'POST',path:'/api/billing/trial/activate',headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify({deviceDigest:device,forged:true})});
  assert.equal(missing.statusCode,503);
});

test('trial cancel returns 200, 409, or 503 without deleting a confirmed run',async()=>{
  const db=memoryDb();
  let now=1_700_000_000_000;
  const trial=createTrial({db,clock:()=>now,hasPriorFreeDevice:async()=>false});
  const raw=Buffer.alloc(32);raw[0]=0x49;
  const token=raw.toString('base64url');
  const router=createInternalRouter({
    installation:{authenticate:async()=>owner},
    verifyTaskBinding:async()=>true,
    trial
  });
  const device=digest('cancel-route');
  const binding='cd'.repeat(32);
  async function post(path,body){
    return router({httpMethod:'POST',path,headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify(body)});
  }
  assert.equal((await post('/api/billing/trial/activate',{deviceDigest:device})).statusCode,200);
  const deviceKey=[...db.docs.keys()].find(key=>key.includes('/trial-'));
  const deviceBefore=JSON.stringify(db.docs.get(deviceKey));
  assert.equal((await post('/api/billing/trial/reserve',{deviceDigest:device,runId:'run-open',taskBinding:binding})).statusCode,200);
  const cancelled=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-open',taskBinding:binding});
  assert.equal(cancelled.statusCode,200);
  assert.equal(JSON.parse(cancelled.body).status,'cancelled');
  const repeated=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-open',taskBinding:binding});
  assert.equal(repeated.statusCode,200);
  assert.equal(JSON.parse(repeated.body).status,'cancelled');
  assert.equal(JSON.stringify(db.docs.get(deviceKey)),deviceBefore);
  assert.equal((await post('/api/billing/trial/reserve',{deviceDigest:device,runId:'run-held',taskBinding:binding})).statusCode,200);
  assert.equal((await post('/api/billing/trial/confirm',{deviceDigest:device,runId:'run-held',taskBinding:binding})).statusCode,200);
  const heldKey=[...db.docs.keys()].find(key=>JSON.stringify(db.docs.get(key)).includes('run-held'));
  const heldBefore=JSON.stringify(db.docs.get(heldKey));
  const denied=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-held',taskBinding:binding});
  assert.equal(denied.statusCode,409);
  assert.equal(JSON.parse(denied.body).error,'trial-run-confirmed');
  assert.equal(JSON.stringify(db.docs.get(heldKey)),heldBefore);
  assert.equal(JSON.stringify(db.docs.get(deviceKey)),deviceBefore);
  assert.equal((await trial.resume(owner,device,'run-held',binding)).status,'authorized');
  assert.equal((await post('/api/billing/trial/reserve',{deviceDigest:device,runId:'run-flaky',taskBinding:binding})).statusCode,200);
  const flakyKey=[...db.docs.keys()].find(key=>JSON.stringify(db.docs.get(key)).includes('run-flaky'));
  const flakyBefore=JSON.stringify(db.docs.get(flakyKey));
  db.flags.failReads=1;
  const dropped=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-flaky',taskBinding:binding});
  assert.equal(dropped.statusCode,503);
  assert.equal(JSON.parse(dropped.body).error,'unavailable');
  db.flags.readCode='DATABASE_REQUEST_FAILED';
  const coded=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-flaky',taskBinding:binding});
  assert.equal(coded.statusCode,503);
  db.flags.readCode='DATABASE_TRANSACTION_CONFLICT';
  const conflict=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-flaky',taskBinding:binding});
  assert.equal(conflict.statusCode,503);
  db.flags.writeCode='DATABASE_REQUEST_FAILED';
  const unwritten=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-flaky',taskBinding:binding});
  assert.equal(unwritten.statusCode,503);
  assert.equal(JSON.stringify(db.docs.get(flakyKey)),flakyBefore);
  assert.equal(JSON.stringify(db.docs.get(deviceKey)),deviceBefore);
  assert.equal(JSON.stringify(db.docs.get(heldKey)),heldBefore);
  const recovered=await post('/api/billing/trial/cancel',{deviceDigest:device,runId:'run-flaky',taskBinding:binding});
  assert.equal(recovered.statusCode,200);
  assert.equal(JSON.parse(recovered.body).status,'cancelled');
});
