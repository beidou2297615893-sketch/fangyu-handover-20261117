package com.futureyyy.tijing.payment

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject

class GatewayRecoveryTest {
    @Test fun explicitEndCancelsNewPendingRunWithoutClosingOldSession() {
        assertEquals("abandon",gatewayEndAction("new","old","closed"))
        assertEquals("abandon",gatewayEndAction("new",null,null))
        assertEquals("close",gatewayEndAction("same","same","active"))
        assertEquals("clear",gatewayEndAction("same","same","closed"))
        assertEquals("blocked",gatewayEndAction("new","old","active"))
    }
    @Test fun onlyReleasedUnspentRoundWithClosedSessionMayStartFresh() {
        assertTrue(gatewayFreshStartAllowed("released","none","closed"))
        for(phase in listOf("reserving","reserved","gateway_confirming","confirmed","releasing"))
            assertFalse(gatewayFreshStartAllowed(phase,"none","closed"))
        assertFalse(gatewayFreshStartAllowed("released","unknown","closed"))
        assertFalse(gatewayFreshStartAllowed("released","none","active"))
        assertFalse(gatewayFreshStartAllowed(null,null,null))
    }
    private class Records:RunLedger {
        val rows=mutableMapOf<String,BillingRun>()
        override fun read(id:String)=rows[id]
        override fun save(run:BillingRun){rows[run.id]=run}
        override fun freeRemaining()=0
        override fun hasUnknownSubmission()=false
        override fun hasOtherUnresolvedReservation(id:String)=false
        override fun releasingIds()=emptyList<String>()
    }
    @Test fun purchaseAfterNoBalanceRetriesSameRunAndConsumesOnlyOnce() {
        val records=Records();var paid=false;var reserves=0;var confirms=0
        val remote=object:BillingTransport {
            override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject {
                if(path=="/entitlements") return JSONObject().put("runCredits",if(paid) 1 else 0).put("revision",1).put("recoverySupported",false)
                if(path=="/runs/reserve") {
                    reserves++;check(paid){"no balance"}
                    return JSONObject().put("ownerId","owner").put("runId","new").put("taskBinding",body!!.getString("taskBinding")).put("status","reserved").put("source","credit")
                }
                if(path=="/runs/new/confirm") {
                    confirms++
                    return JSONObject().put("ownerId","owner").put("runId","new").put("taskBinding",records.rows["new"]!!.binding).put("status","confirmed").put("source","credit")
                }
                error("unexpected request")
            }
        }
        val billing=RunBilling(PaymentConfig(PaymentConfig.ORIGIN,PaymentConfig.ORIGIN,true),records,remote,{BillingIdentity("owner","token")},{"signature"})
        try{billing.start("new","target.pkg","original-tijing-v1");fail("no balance must fail")}catch(_:IllegalStateException){}
        assertEquals("reserving",records.rows["new"]?.phase)
        paid=true;billing.start("new","target.pkg","original-tijing-v1")
        billing.confirmForGateway("new"){};billing.confirmForGateway("new"){}
        assertEquals(1,reserves);assertEquals(1,confirms);assertEquals(1,records.rows.size)
        assertEquals("confirmed",records.rows["new"]?.phase)
    }
    @Test fun explicitEndReleasesPendingRoundButNeverReleasesConfirmedCredit() {
        val records=Records();var cancels=0
        val row=BillingRun("new","b".repeat(64),"target.pkg","original-tijing-v1","signature","pending",phase="reserving")
        records.rows["new"]=row
        val remote=object:BillingTransport {
            override fun request(path:String,method:String,body:JSONObject?,identity:BillingIdentity?):JSONObject {
                assertEquals("/runs/new/cancel",path);cancels++
                return JSONObject().put("ownerId","owner").put("runId","new").put("taskBinding",row.binding).put("status","cancelled")
            }
        }
        val billing=RunBilling(PaymentConfig(PaymentConfig.ORIGIN,PaymentConfig.ORIGIN,true),records,remote,{BillingIdentity("owner","token")},{"signature"})
        billing.abandon("new");billing.abandon("new")
        assertEquals(1,cancels);assertEquals("released",records.rows["new"]?.phase)
        assertTrue(gatewayFreshStartAllowed(records.rows["new"]?.phase,records.rows["new"]?.submissionState,"closed"))
        records.rows["new"]=row.copy(source="credit",phase="confirmed")
        try{billing.abandon("new");fail("confirmed credit cannot be released")}catch(_:IllegalStateException){}
        assertEquals(1,cancels)
    }

    @Test fun uncertainEndPersistsIntentAndRetryNeverCreatesAnotherRun() {
        var saved="";var clears=0;var requests=0
        try { finishGatewayEnd("same","test-only-token",{saved=it},{requests++;throw IllegalStateException("lost response")},{clears++});fail("lost response must fail") } catch(_:IllegalStateException){}
        assertEquals("ending",JSONObject(saved).getString("state"));assertEquals("same",JSONObject(saved).getString("runId"));assertEquals(0,clears)
        finishGatewayEnd("same","test-only-token",{saved=it},{requests++;true},{clears++})
        assertEquals("closed",JSONObject(saved).getString("state"));assertFalse(JSONObject(saved).has("token"));assertEquals(1,clears);assertEquals(2,requests)
    }
    @Test fun failedEndResponseCannotClearCurrentRun() {
        var saved="";var cleared=false
        try { finishGatewayEnd("same","test-only-token",{saved=it},{false},{cleared=true});fail("unconfirmed end must fail") } catch(_:IllegalStateException){}
        assertEquals("ending",JSONObject(saved).getString("state"));assertFalse(cleared)
    }

}
