package com.futureyyy.tijing.payment

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class EntitlementCopyTest {
    private val now = 1_700_000_000_000L
    private val business = "试用领取没有成功。服务器暂时无法确认，试用时间没有延长。"
    private val network = "网络暂时不可用。试用时间没有延长，请稍后重试。"

    @Test fun emptyEntitlementDoesNotClaimAConfirmedPlan() {
        val samples = listOf(
            null,
            JSONObject().put("runCredits", 0),
            JSONObject().put("runCredits", 0L).put("validUntil", JSONObject.NULL),
            JSONObject().put("runCredits", 0).put("validUntil", now / 1000 - 10),
            JSONObject().put("runCredits", 0).put("validUntil", now / 1000 + 86400).put("requiresReview", true)
        )
        for (entitlement in samples) {
            val text = entitlementRemainingText(entitlement, now)
            assertFalse(text.contains("套餐权益已确认"))
            assertEquals("请选择周套餐或月套餐", text)
        }
    }

    @Test fun validMembershipShowsTheConfirmedPlan() {
        val until = now / 1000 + 86400
        assertEquals("套餐权益已确认", entitlementRemainingText(JSONObject().put("runCredits", 0).put("validUntil", until), now))
        assertEquals("剩余 3 次", entitlementRemainingText(JSONObject().put("runCredits", 3).put("validUntil", until), now))
    }

    @Test fun validTrialKeepsTheServerExpiry() {
        val expires = now + 1_000L
        val trial = JSONObject()
            .put("eligible", true)
            .put("active", true)
            .put("reason", "new-device")
            .put("startedAt", now)
            .put("expiresAt", expires)
            .put("serverNow", now + 100L)
        val view = JSONObject().put("remainingText", "套餐权益已确认")
        applyActivatedTrial(view, trial)
        assertEquals("免费试用中，到期后请选择周套餐或月套餐", view.getString("remainingText"))
        assertEquals(expires, view.getJSONObject("trial").getLong("expiresAt"))
        assertTrue(view.getJSONObject("trial").getBoolean("active"))
        assertFalse(view.has("trialError"))
    }

    @Test fun trialClaimFailureShowsTheRealError() {
        val view = JSONObject().put("remainingText", "套餐权益已确认").put("trial", JSONObject().put("active", true))
        val failure = PaymentFailure("SERVICE_UNCONFIRMED", business)
        applyTrialFailure(view, failure, JSONObject().put("active", true).put("expiresAt", now + 72 * 60 * 60 * 1000))
        assertEquals(business, view.getString("remainingText"))
        assertEquals("SERVICE_UNCONFIRMED", view.getJSONObject("trialError").getString("code"))
        assertEquals(business, view.getJSONObject("trialError").getString("message"))
        assertFalse(view.has("trial"))
        assertFalse(view.optBoolean("trialStale"))
        assertFalse(view.getString("remainingText").contains("套餐权益已确认"))
    }

    @Test fun networkAndBusinessRejectionsStayDistinct() {
        val http = billingFailure("/trial/activate", 503)
        val transport = billingTransportFailure("/trial/activate")
        assertEquals("SERVICE_UNCONFIRMED", http.first)
        assertEquals(business, http.second)
        assertEquals("NETWORK_UNCONFIRMED", transport.first)
        assertEquals(network, transport.second)
        assertNotEquals(http.second, transport.second)
        val cached = JSONObject().put("eligible", true).put("active", true).put("expiresAt", 50L).put("serverNow", 10L)
        val offline = JSONObject().put("remainingText", "套餐权益已确认")
        applyTrialFailure(offline, PaymentFailure(transport.first, transport.second), cached)
        assertTrue(offline.getBoolean("trialStale"))
        assertEquals(50L, offline.getJSONObject("trial").getLong("expiresAt"))
        assertEquals("试用状态暂时无法连接服务器确认。已获得的试用不会因此被取消，请稍后重试。", offline.getString("remainingText"))
        val rejected = JSONObject().put("remainingText", "套餐权益已确认")
        applyTrialFailure(rejected, PaymentFailure(http.first, http.second), cached)
        assertFalse(rejected.optBoolean("trialStale"))
        assertFalse(rejected.has("trial"))
        assertEquals(business, rejected.getString("remainingText"))
        val noCache = JSONObject()
        applyTrialFailure(noCache, PaymentFailure(transport.first, transport.second), null)
        assertFalse(noCache.has("trial"))
        assertFalse(noCache.optBoolean("trialStale"))
        assertEquals(network, noCache.getString("remainingText"))
    }

    @Test fun failureDoesNotForgeASeventyTwoHourTrial() {
        val denied = PaymentFailure("SERVICE_UNCONFIRMED", business)
        val failing = TrialService(object : BillingTransport {
            override fun request(path: String, method: String, body: JSONObject?, identity: BillingIdentity?): JSONObject = throw denied
        }, BillingIdentity("owner", "token"), "ab".repeat(32))
        try {
            failing.activate()
            fail("activate failure must surface")
        } catch (failure: PaymentFailure) {
            assertEquals("SERVICE_UNCONFIRMED", failure.code)
            assertEquals(business, failure.message)
            assertFalse(failure.message!!.contains("72"))
        }
        val blocked = JSONObject()
            .put("eligible", false)
            .put("active", false)
            .put("reason", "existing-free-device")
            .put("startedAt", JSONObject.NULL)
            .put("expiresAt", JSONObject.NULL)
            .put("serverNow", now)
        val returned = TrialService(object : BillingTransport {
            override fun request(path: String, method: String, body: JSONObject?, identity: BillingIdentity?): JSONObject {
                assertEquals("/trial/activate", path)
                return blocked
            }
        }, BillingIdentity("owner", "token"), "ab".repeat(32)).activate()
        assertFalse(returned.getBoolean("eligible"))
        assertFalse(returned.getBoolean("active"))
        assertTrue(returned.isNull("expiresAt"))
        val view = JSONObject().put("remainingText", "套餐权益已确认")
        applyActivatedTrial(view, returned)
        assertEquals("这台设备已有旧的免费记录，不能再领取72小时试用。", view.getString("remainingText"))
        assertTrue(view.getJSONObject("trial").isNull("expiresAt"))
        assertFalse(view.getJSONObject("trial").getBoolean("active"))
        val malformed = JSONObject().put("reason", "existing-free-device").put("serverNow", now)
        try {
            TrialService(object : BillingTransport {
                override fun request(path: String, method: String, body: JSONObject?, identity: BillingIdentity?): JSONObject = malformed
            }, BillingIdentity("owner", "token"), "ab".repeat(32)).activate()
            fail("incomplete activate response must surface")
        } catch (failure: PaymentFailure) {
            assertEquals("TRIAL_UNCONFIRMED", failure.code)
            assertEquals("这台设备已有旧的免费记录，不能再领取72小时试用。", failure.message)
        }
    }

    @Test fun unexpectedTrialFailureStaysATrialMessageAndDropsTheCache() {
        val failure = unexpectedTrialFailure()
        assertEquals("TRIAL_UNCONFIRMED", failure.code)
        assertFalse(failure.message!!.contains("付款"))
        val cached = JSONObject().put("active", true).put("expiresAt", now + 72 * 60 * 60 * 1000).put("eligible", true)
        val view = JSONObject().put("remainingText", "套餐权益已确认").put("trial", cached)
        applyTrialFailure(view, failure, cached)
        assertEquals("试用状态无法确认。试用时间没有延长。", view.getString("remainingText"))
        assertFalse(view.has("trial"))
        assertFalse(view.optBoolean("trialStale"))
        assertFalse(view.toString().contains("expiresAt"))
    }
}
