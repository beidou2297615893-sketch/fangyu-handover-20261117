package com.futureyyy.tijing.payment

import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test

class TrialCancelRetryTest {
    @Test fun trialCancelCodesStayDistinctFromPaymentAndNetworkFailures() {
        val confirmed = billingFailure("/trial/cancel", 409)
        assertEquals("TRIAL_RUN_CONFIRMED", confirmed.first)
        assertEquals("这一轮已经确认，不能取消。试用仍按原来的记录保留。", confirmed.second)
        val database = billingFailure("/trial/cancel", 503)
        assertEquals("SERVICE_UNCONFIRMED", database.first)
        assertEquals("试用记录暂时无法核对。已有记录已保留，请稍后重试。", database.second)
        val network = billingTransportFailure("/trial/cancel")
        assertEquals("NETWORK_UNCONFIRMED", network.first)
        assertEquals("网络暂时不可用。已有试用记录已保留，请稍后重试。", network.second)
        assertEquals("PAYMENT_REQUIRED", billingFailure("/orders", 402).first)
        assertEquals("SERVICE_UNCONFIRMED", billingFailure("/runs/reserve", 503).first)
        assertEquals("网络暂时不可用，已有付款记录已保留，请勿重复购买。", billingTransportFailure("/orders").second)
    }

    private class Records : RunLedger {
        val rows = mutableMapOf<String, BillingRun>()
        override fun read(id: String) = rows[id]
        override fun save(run: BillingRun) { rows[run.id] = run }
        override fun freeRemaining() = 0
        override fun hasUnknownSubmission() = false
        override fun hasOtherUnresolvedReservation(id: String) = false
        override fun releasingIds() = rows.values.filter { it.phase == "reserving" || it.phase == "releasing" }.map { it.id }
    }

    private fun run(id: String, phase: String) = BillingRun(
        id, "b".repeat(64), "target.pkg", "original-tijing-v1", "signature", "trial", phase = phase
    )

    private fun billing(records: Records) = RunBilling(
        PaymentConfig(PaymentConfig.ORIGIN, PaymentConfig.ORIGIN, true),
        records,
        object : BillingTransport {
            override fun request(path: String, method: String, body: org.json.JSONObject?, identity: BillingIdentity?) =
                error("transport is not used")
        },
        { BillingIdentity("owner", "token") },
        { "signature" }
    )

    @Test fun confirmedTrialCancelStopsRetryAndKeepsTheLocalRun() {
        val records = Records()
        records.rows["held"] = run("held", "releasing")
        records.rows["open"] = run("open", "releasing")
        var calls = 0
        val client = billing(records)
        try {
            client.recoverReleases { row ->
                calls += 1
                if (row.id == "held") reject("TRIAL_RUN_CONFIRMED", "这一轮已经确认，不能取消。试用仍按原来的记录保留。")
            }
            fail("confirmed trial must surface once")
        } catch (failure: PaymentFailure) {
            assertEquals("TRIAL_RUN_CONFIRMED", failure.code)
        }
        assertEquals(2, calls)
        assertEquals("confirmed", records.rows["held"]?.phase)
        assertEquals("released", records.rows["open"]?.phase)
        calls = 0
        client.recoverReleases { calls += 1 }
        assertEquals(0, calls)
    }

    @Test fun databaseAndNetworkFailuresRemainReleasable() {
        val records = Records()
        records.rows["flaky"] = run("flaky", "reserved")
        val client = billing(records)
        try {
            client.abandon("flaky") { reject("SERVICE_UNCONFIRMED", "试用记录暂时无法核对。已有记录已保留，请稍后重试。") }
            fail("database failure must stay pending")
        } catch (failure: PaymentFailure) {
            assertEquals("SERVICE_UNCONFIRMED", failure.code)
        }
        assertEquals("releasing", records.rows["flaky"]?.phase)
        try {
            client.abandon("flaky") { reject("NETWORK_UNCONFIRMED", "网络暂时不可用。已有试用记录已保留，请稍后重试。") }
            fail("network failure must stay pending")
        } catch (failure: PaymentFailure) {
            assertEquals("NETWORK_UNCONFIRMED", failure.code)
        }
        assertEquals("releasing", records.rows["flaky"]?.phase)
        client.abandon("flaky") {}
        assertEquals("released", records.rows["flaky"]?.phase)
    }
}
