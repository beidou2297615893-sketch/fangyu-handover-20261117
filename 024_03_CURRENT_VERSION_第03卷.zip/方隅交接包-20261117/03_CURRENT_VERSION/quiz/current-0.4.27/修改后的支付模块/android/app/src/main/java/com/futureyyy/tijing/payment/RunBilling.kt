package com.futureyyy.tijing.payment

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

data class BillingRun(val id:String,val binding:String,val target:String,val revision:String,val targetIdentity:String,
    val source:String,val phase:String="reserved",val intent:String?=null,val question:String?=null,
    val receipt:String?=null,val submissionState:String="none")
interface RunLedger { fun read(id:String):BillingRun?;fun save(run:BillingRun);fun freeRemaining():Int;fun hasUnknownSubmission():Boolean;fun hasOtherUnresolvedReservation(id:String):Boolean;fun releasingIds():List<String> }

/** Native authorization/receipt adapter. No dependency on the old answer engine or UI facts. */
class RunBilling(private val config:PaymentConfig,private val store:RunLedger,private val remote:BillingTransport,
    private val credential:()->BillingIdentity,private val installedTarget:(String)->String,
    private val trialReserve:((String,String)->Unit)?=null) {
    private val epochs=ConcurrentHashMap<String,AtomicLong>()
    private val permits=ConcurrentHashMap<String,Long>()
    private fun epoch(id:String)=epochs.getOrPut(id){AtomicLong()}
    fun invalidate(id:String) { epoch(id).incrementAndGet();permits.remove(id) }
    fun ticket(id:String)=epoch(id).get()
    private fun checkTicket(id:String,ticket:Long) { if(epoch(id).get()!=ticket)reject("RUN_CHANGED","本次任务已暂停，请重新核对后继续。") }
    private fun binding(id:String,target:String,revision:String,installed:String):String {
        require(ID.matches(id) && target.isNotBlank() && revision.isNotBlank() && revision.length<=2048)
        val out=ByteArrayOutputStream()
        DataOutputStream(out).use { data -> listOf("paid-run-v1",id,target,revision,installed).forEach { s->val b=s.toByteArray(Charsets.UTF_8);data.writeInt(b.size);data.write(b) } }
        return MessageDigest.getInstance("SHA-256").digest(out.toByteArray()).joinToString(""){"%02x".format(it)}
    }
    private fun response(row:BillingRun,op:String,status:String):Unit {
        if(!config.ready)reject("ADMISSION_DISABLED","付款后的使用权限尚未开放。")
        val owner=credential()
        val body=when(op){"reserve"->org.json.JSONObject().put("runId",row.id).put("taskBinding",row.binding);"continue","cancel"->org.json.JSONObject().put("taskBinding",row.binding);else->org.json.JSONObject()}
        val path=if(op=="reserve") "/runs/reserve" else "/runs/${row.id}/$op"
        val value=remote.request(path,"POST",body,owner)
        val after=credential()
        if(after.owner!=owner.owner || !MessageDigest.isEqual(after.token.toByteArray(),owner.token.toByteArray()) ||
            value.optString("ownerId")!=owner.owner || value.optString("runId")!=row.id || value.optString("taskBinding")!=row.binding ||
            value.optString("status")!=status || op!="cancel" && value.optString("source")!=row.source)
            reject("ADMISSION_MISMATCH","本次答题权限无法确认，请勿重复开始。")
    }
    private fun current(id:String):BillingRun {
        val row=store.read(id) ?: reject("RUN_MISSING","本次答题记录不存在，请重新准备。")
        if(installedTarget(row.target)!=row.targetIdentity)reject("TARGET_CHANGED","目标软件已变化，请结束后重新准备。")
        return row
    }
    fun start(id:String,target:String,revision:String,ticket:Long=ticket(id)) {
        checkTicket(id,ticket)
        if(store.hasUnknownSubmission())reject("PENDING_SUBMISSION","存在尚未确认的提交，请先核对，不能开始新任务。")
        if(store.hasOtherUnresolvedReservation(id))reject("PENDING_RESERVATION","上次使用记录尚未核对，请稍后重试。")
        val installed=installedTarget(target);val hash=binding(id,target,revision,installed)
        var row=store.read(id)
        if(row!=null && (row.binding!=hash || row.submissionState=="unknown"))reject("PENDING_SUBMISSION","上次提交结果尚未确认，不能重复提交。")
        if(row==null) {
            if(!config.ready)reject("PAYMENT_REQUIRED","请先确认试用或选择套餐；已付款请先核对订单。")
            row=BillingRun(id,hash,target,revision,installed,"pending",phase="reserving")
            // Persist the immutable binding before the remote request: a lost reply
            // must not orphan a reservation or permit a different task to spend it.
            store.save(row)
        }
        if(row.phase=="reserving" && row.source=="pending") {
            val owner=credential()
            val entitlement=remote.request("/entitlements",identity=owner)
            val credits=entitlement.opt("runCredits")
            val creditCount=when(credits){is Int->credits.toLong();is Long->credits;else->reject("ADMISSION_MISMATCH","本次答题权限无法确认。")}
            val usePaid=creditCount>0 || entitlement.has("validUntil") && !entitlement.isNull("validUntil")
            if(usePaid) {
                val result=remote.request("/runs/reserve","POST",org.json.JSONObject().put("runId",id).put("taskBinding",hash),owner)
                val source=result.optString("source")
                val after=credential()
                if(after.owner!=owner.owner || !MessageDigest.isEqual(after.token.toByteArray(),owner.token.toByteArray()) || result.optString("ownerId")!=owner.owner || result.optString("runId")!=id || result.optString("taskBinding")!=hash || result.optString("status")!="reserved" || source !in setOf("credit","subscription"))reject("ADMISSION_MISMATCH","本次答题权限无法确认。")
                row=row.copy(source=source,phase="reserved")
            } else {
                val admit=trialReserve ?: reject("PAYMENT_REQUIRED","72小时试用未确认或已结束，请选择周套餐或月套餐。已付款请先核对。")
                admit(id,hash)
                row=row.copy(source="trial",phase="reserved")
            }
            store.save(row)
        }
        if(row.phase=="receipt_confirmed") { response(row,"confirm","confirmed");row=row.copy(phase="confirmed");store.save(row) }
        if(row.source!="free" && row.source!="trial" && row.phase=="confirmed")response(row,"continue","authorized")
        if(row.phase !in setOf("reserved","gateway_confirming","confirmed"))reject("RUN_UNAVAILABLE","本次任务需要先核对付款记录。")
        checkTicket(id,ticket);permits[id]=ticket
    }
    /** Settle once before starting the unchanged original runner; persisted before network. */
    fun confirmForGateway(id:String,confirmFree:(BillingRun)->Unit) {
        var row=current(id)
        if(row.phase=="confirmed") return
        if(row.phase !in setOf("reserved","gateway_confirming"))reject("RUN_UNAVAILABLE","本次任务需要先核对使用记录。")
        if(row.phase=="reserved") { row=row.copy(phase="gateway_confirming");store.save(row) }
        if(row.source=="free" || row.source=="trial") confirmFree(row) else response(row,"confirm","confirmed")
        store.save(row.copy(phase="confirmed"))
    }
    /** Call only for explicit final termination; never for pause or uncertain dispatch. */
    fun abandon(id:String,beforeFreeRelease:(BillingRun)->Unit={}) {
        val row=store.read(id) ?: return
        if(row.phase=="released")return
        if(row.submissionState!="none" || row.phase !in setOf("reserved","reserving","releasing"))
            reject("PENDING_SUBMISSION","提交结果尚未确认，不能释放本次使用记录。")
        var pending=row
        if(row.phase!="releasing") { pending=row.copy(phase="releasing");store.save(pending) }
        try {
            if(pending.source=="free" || pending.source=="trial") beforeFreeRelease(pending) else response(pending,"cancel","cancelled")
        } catch(failure:PaymentFailure) {
            if(failure.code=="TRIAL_RUN_CONFIRMED") store.save(pending.copy(phase="confirmed"))
            throw failure
        }
        store.save(pending.copy(phase="released"))
    }
    fun recoverReleases(beforeFreeRelease:(BillingRun)->Unit={}) {
        var confirmed:PaymentFailure?=null
        for(id in store.releasingIds()) {
            try { abandon(id,beforeFreeRelease) }
            catch(failure:PaymentFailure) {
                if(failure.code=="TRIAL_RUN_CONFIRMED") { if(confirmed==null) confirmed=failure; continue }
                throw failure
            }
        }
        if(confirmed!=null) throw confirmed
    }
    fun beforeSubmit(id:String,intent:String,question:String,ticket:Long=ticket(id)) {
        require(ID.matches(intent) && question.isNotBlank() && question.length<=4096)
        checkTicket(id,ticket)
        if(store.hasUnknownSubmission())reject("PENDING_SUBMISSION","存在尚未确认的提交，不能再次提交。")
        val row=current(id)
        if(permits[id]!=ticket || row.submissionState=="unknown" || row.intent==intent)reject("PENDING_SUBMISSION","上次提交尚未确认，未重复提交。")
        if(row.phase !in setOf("reserved","confirmed"))reject("RUN_UNAVAILABLE","本次答题权限尚未确认。")
        store.save(row.copy(phase=if(row.phase=="reserved")"unknown" else row.phase,intent=intent,question=question,receipt=null,submissionState="unknown"))
        checkTicket(id,ticket)
    }
    fun receipt(id:String,intent:String,receipt:String,ticket:Long=ticket(id)) {
        require(receipt.isNotBlank() && receipt.length<=4096)
        checkTicket(id,ticket)
        var row=current(id)
        if(row.intent!=intent)reject("RECEIPT_MISMATCH","提交回执不属于本次操作。")
        if(row.submissionState=="receipt") {
            if(row.receipt!=receipt)reject("RECEIPT_MISMATCH","提交回执发生变化，请核对。")
            if(row.phase=="confirmed")return
        } else {
            if(row.submissionState!="unknown")reject("RECEIPT_MISMATCH","没有待核对的提交。")
            row=row.copy(phase=if(row.source=="free")"confirmed" else if(row.phase=="unknown")"receipt_confirmed" else row.phase,receipt=receipt,submissionState="receipt")
            store.save(row)
        }
        if(row.source!="free") {
            if(row.phase=="receipt_confirmed") { response(row,"confirm","confirmed");row=row.copy(phase="confirmed");store.save(row) }
            response(row,"continue","authorized")
        }
        checkTicket(id,ticket);permits[id]=ticket
    }
}
