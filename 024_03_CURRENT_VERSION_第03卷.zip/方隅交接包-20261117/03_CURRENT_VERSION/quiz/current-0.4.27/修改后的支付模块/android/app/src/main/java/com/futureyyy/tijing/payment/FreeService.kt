package com.futureyyy.tijing.payment

import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

internal object FreeDeviceDigest {
    fun derive(raw:String?):String {
        if(raw==null || !raw.matches(Regex("[0-9a-fA-F]{1,16}")))reject("DEVICE_UNAVAILABLE","设备身份无法确认。")
        val id=raw.lowercase(Locale.ROOT).padStart(16,'0')
        if(id=="0000000000000000")reject("DEVICE_UNAVAILABLE","设备身份无法确认。")
        return MessageDigest.getInstance("SHA-256").digest(("dailyhundred-free-device-v1\u0000"+id).toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
    }
}
internal class FreeService(private val transport:BillingTransport,private val identity:BillingIdentity,private val digest:String) {
    fun migrate(entries:Map<String,String>) {
        if(entries.size>3 || entries.any { !ID.matches(it.key) || it.value !in setOf("used","reserved") })reject("FREE_MIGRATION_REQUIRED","既有免费使用记录需要核对。")
        val values=JSONObject();entries.forEach { (id,state)->values.put(id,state) }
        val r=transport.request("/free/migrate","POST",JSONObject().put("deviceDigest",digest).put("legacyEntries",values),identity)
        fun count(k:String):Int { val n=r.opt(k);if(n !is Int || n !in 0..3)reject("FREE_UNCONFIRMED","免费使用状态无法确认。");return n }
        if(count("used")+count("reserved")+count("remaining")!=3)reject("FREE_UNCONFIRMED","免费使用状态无法确认。")
    }
    fun action(op:String,id:String,binding:String) {
        val expected=mapOf("reserve" to "reserved","confirm" to "confirmed","resume" to "authorized","cancel" to "cancelled")[op] ?: error("invalid operation")
        val result=transport.request("/free/$op","POST",JSONObject().put("deviceDigest",digest).put("runId",id).put("taskBinding",binding),identity)
        if(result.optString("ownerId")!=identity.owner || result.optString("runId")!=id || result.optString("taskBinding")!=binding || result.optString("source")!="free" || result.optString("status")!=expected)reject("FREE_UNCONFIRMED","免费使用状态无法确认。")
    }
}
internal class TrialService(private val transport:BillingTransport,private val identity:BillingIdentity,private val digest:String) {
    private fun number(value:Any?):Long? = when(value){is Int->value.toLong();is Long->value;else->null}
    fun activate():JSONObject {
        val result=transport.request("/trial/activate","POST",JSONObject().put("deviceDigest",digest),identity)
        if(result.opt("eligible") !is Boolean || result.opt("active") !is Boolean || number(result.opt("serverNow"))==null)reject("TRIAL_UNCONFIRMED",trialShapeMessage(result))
        if(result.getBoolean("eligible") && result.getBoolean("active")) {
            val expires=number(result.opt("expiresAt")) ?: reject("TRIAL_UNCONFIRMED",trialShapeMessage(result))
            val serverNow=number(result.opt("serverNow")) ?: reject("TRIAL_UNCONFIRMED",trialShapeMessage(result))
            if(expires<=serverNow)reject("TRIAL_UNCONFIRMED",trialShapeMessage(result))
        }
        return result
    }
    fun action(op:String,id:String,binding:String) {
        val expected=mapOf("reserve" to "reserved","confirm" to "confirmed","resume" to "authorized","cancel" to "cancelled")[op] ?: error("invalid operation")
        val result=transport.request("/trial/$op","POST",JSONObject().put("deviceDigest",digest).put("runId",id).put("taskBinding",binding),identity)
        if(result.optString("ownerId")!=identity.owner || result.optString("runId")!=id || result.optString("taskBinding")!=binding || result.optString("source")!="trial" || result.optString("status")!=expected)reject("TRIAL_UNCONFIRMED","试用授权无法确认。")
    }
}
internal fun trialShapeMessage(result:JSONObject):String {
    val reason=result.opt("reason")
    if(reason=="existing-free-device")return "这台设备已有旧的免费记录，不能再领取72小时试用。"
    if(reason=="not-activated")return "试用还没有激活。"
    return "试用状态无法确认。"
}
internal fun applyActivatedTrial(view:JSONObject,trial:JSONObject):JSONObject {
    view.put("trial",trial)
    if(trial.has("serverNow"))view.put("serverNow",trial.get("serverNow"))
    val paid=view.optJSONObject("entitlement")
    val until=paid?.opt("validUntil")
    val serverNow=trial.opt("serverNow")
    val paidActive=until is Number && serverNow is Number && until.toLong()>0L && until.toLong()*1000L>(serverNow as Number).toLong()
    if(!paidActive) {
        val active=trial.opt("active")==true
        val eligible=trial.opt("eligible")==true
        val reason=trial.optString("reason")
        view.put("remainingText",when {
            active->"免费试用中，到期后请选择周套餐或月套餐"
            eligible && reason=="new-device"->"72小时试用已结束，请选择周套餐或月套餐"
            reason=="existing-free-device"->"这台设备已有旧的免费记录，不能再领取72小时试用。"
            reason=="not-activated"->"试用还没有激活。"
            else->"请选择周套餐或月套餐"
        })
    }
    return view
}
internal fun applyTrialFailure(view:JSONObject,failure:PaymentFailure,cached:JSONObject?):JSONObject {
    view.put("trialError",JSONObject().put("code",failure.code).put("message",failure.message ?: ""))
    if(failure.code=="NETWORK_UNCONFIRMED" && cached!=null) {
        view.put("trial",cached).put("trialStale",true)
        view.put("remainingText","试用状态暂时无法连接服务器确认。已获得的试用不会因此被取消，请稍后重试。")
        return view
    }
    if(view.has("trial"))view.remove("trial")
    view.put("remainingText",failure.message ?: "试用领取没有成功。试用时间没有延长。")
    return view
}
