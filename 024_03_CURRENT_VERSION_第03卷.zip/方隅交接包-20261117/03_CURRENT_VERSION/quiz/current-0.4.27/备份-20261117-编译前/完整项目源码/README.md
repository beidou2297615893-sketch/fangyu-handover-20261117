<div align="center">

# 题镜 · TiJing

**On-device quiz copilot — screenshot → AI reads the question (screen OCR + vision model) → matches *your own* question bank → floats the answer on top of the screen.**

[English](README.md) · [简体中文](README.zh-CN.md)

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Platform](https://img.shields.io/badge/platform-Android%208.0%2B-3ddc84.svg)
![Release](https://img.shields.io/github/v/release/futureYYY/TiJing?color=orange)
![PRs](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)

<img src="docs/screenshots/01-console.png" width="240" alt="Console" /> <img src="docs/screenshots/02-run-history.png" width="240" alt="Run history" /> <img src="docs/screenshots/03-model-settings.png" width="240" alt="Model settings" />

</div>

---

## ✨ What is this

**TiJing (题镜)** is an Android accessibility + screen-capture assistant for long quiz sessions on mini-program / web question pages. It takes a screenshot of the current question, asks any OpenAI-compatible vision model to read the stem, looks the stem up in **a question bank that you supply**, and renders the answer in a floating overlay — optionally tapping the right option and confirming.

It is built as three cooperating pieces:

| Piece | Stack | Role |
|---|---|---|
| **Android app** | Kotlin, AccessibilityService, MediaProjection | capture, overlay, gesture execution |
| **Web console** | Vite + React | configuration, prompt editing, bank management, live run log |
| **Local bridge** | Node (`server.mjs`) | wires the browser console to the device over WebSocket |

Everything runs **locally**. There is no cloud backend, no account, no telemetry.

## 🎯 Features

- **Floating answer overlay** — answer card sits above the question page, never steals focus.
- **Three modes** — `Auto` (drive the run), `Manual` (assist only), `Capture` (harvest stems into a new bank).
- **Local bank matching** — normalized exact / key-phrase fuzzy match against *your* JSON bank, so most questions never touch the model.
- **Vision fallback** — when a stem is not in the bank, the configured vision model reads the screenshot and returns answer + clickable boxes.
- **Capture mode** — one-tap "next" pacing to painlessly grow your own bank from any quiz list.
- **Web console + live log** — tune prompts, endpoints and timeouts, watch each run event stream in.

## ⬇️ Download

**[⤓ TiJing-0.7.7-open.apk](https://github.com/futureYYY/TiJing/releases/latest/download/TiJing-0.7.7-open.apk)** · Android 8.0+ (API 26) · ~0.9 MB

```
SHA-256  3f4988b2fe4c5eaab22c4e604468c9c99114a0ce3b522611601b2b9a0fcff20f
```

> **The released APK contains no question bank and no API key.** You bring your own model endpoint and your own bank — see [Configuration](#-configuration).

## 🚀 Quick start

### I just want to use it

1. Install the APK and open the app.
2. Grant the permissions it asks for — **Accessibility**, **Display over other apps**, **Notifications**, then start **screen capture**.
3. Open **模型设置 / Model settings**, fill in your endpoint, model name and API key.
4. Get a question bank: import a JSON bank, or switch to **采集模式 / Capture** and let it harvest stems as you page through the questions.
5. Switch to **手动辅助 / Manual** or **自动刷题 / Auto** and hit start.

### I want to build it

Prerequisites: Node 22+, JDK 21, Android SDK 35.

```bash
# 1) web console -> dist/ -> android assets
npm install
npm run build
node scripts/sync-android-assets.mjs

# 2) Android release build
export JAVA_HOME=/path/to/jdk-21
export ANDROID_SDK_ROOT=/path/to/android-sdk
./gradlew -p android :app:assembleProdRelease   # or use your local gradle 8.7+

# optional: release signing — put these in android/local.properties (never commit it)
# RELEASE_STORE_FILE=/abs/path/release.jks
# RELEASE_STORE_PASSWORD=...
# RELEASE_KEY_ALIAS=...
# RELEASE_KEY_PASSWORD=...
```

APK output: `android/app/build/outputs/apk/prod/release/app-prod-release.apk`

Run the tests:

```bash
npm test                       # web / shared logic
./gradlew -p android :app:testProdDebugUnitTest
```

## 🔑 Configuration

TiJing speaks the **OpenAI-compatible** `POST {base}/chat/completions` contract with an `image_url` attachment. Any provider that implements it works:

| Provider | Base URL | Example model |
|---|---|---|
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini` |
| DeepSeek | `https://api.deepseek.com/v1` | `deepseek-chat` |
| Volcengine Ark | `https://ark.cn-beijing.volces.com/api/v3` | *your endpoint id* |
| Ollama (local) | `http://127.0.0.1:11434/v1` | `llava` |
| Any self-hosted gateway | `https://your-gateway/v1` | *your model* |

The API key is stored **only on the device / in your browser**, never transmitted anywhere except to the endpoint you configured.

For the web console you can also preset values in `.env.local` (copy `.env.example`):

```bash
QUIZ_API_URL=https://api.openai.com/v1
QUIZ_API_KEY=
QUIZ_MODEL=gpt-4o-mini
```

## 🏗 How it works

```
┌──────────────┐  screenshot   ┌──────────────────┐
│ quiz page    │──────────────▶│ Accessibility +  │
│ (mini program│               │ MediaProjection  │
│  / web / app)│◀──────────────│  capture service │
└──────────────┘  tap gesture  └────────┬─────────┘
                                        │  stem
                             ┌──────────▼──────────┐
                             │ local bank matcher  │  hit  ─▶ answer (no model call)
                             │ exact / key-phrase  │
                             └──────────┬──────────┘
                                        │ miss
                             ┌──────────▼──────────┐
                             │ vision model (BYOK) │
                             │ OpenAI-compatible   │
                             └──────────┬──────────┘
                                        │ answer + boxes
                             ┌──────────▼──────────┐
                             │ floating overlay    │
                             │ + optional auto-tap │
                             └─────────────────────┘
```

- `QuizAccessibilityService` performs gestures **serially** and only while the target app is foreground.
- `QuizRunCoordinator` is the state machine: paging detection, retries, pause, unbounded question numbering.
- The web console talks to the device through the local Node bridge (`server.mjs`, WebSocket) — nothing leaves your LAN.

## ❓ Why is there no built-in question bank?

By design: a question bank is **user content**. Everyone studies different material, and a bank isn't something a project can hand out on your behalf. So the open-source tree ships an **empty** `question-bank.json` placeholder (`{"questions": []}`), and so does the released APK.

That costs you nothing: the app is built around *your* bank.

- **Have a bank?** Import it from the web console (`题库管理 / Bank` → import JSON) or push it to `files/question-bank.json` on device.
- **Don't have one?** Use **Capture mode** to harvest stems while you page through a quiz, then export and fill in answers.

Bank format (minimal):

```json
{
  "questions": [
    {
      "id": "q-1",
      "question": "题干文本",
      "answer": "B",
      "answer_indices": [1],
      "options": [{ "index": 0, "text": "选项A" }, { "index": 1, "text": "选项B" }]
    }
  ]
}
```

## 🔐 Privacy

- No account, no analytics, no remote backend.
- Screenshots are sent **only** to the endpoint you configured (or not at all, on a bank hit).
- API keys live in local storage / `SharedPreferences` on your own device.

## ⚖️ License & trademark

Code is released under the [MIT License](LICENSE).

The **"题镜 / TiJing" name and logo are NOT part of the MIT grant.** You may fork, modify and redistribute the code freely, but please do not publish derivative builds under the TiJing name or branding — rename your fork. The author reserves the name and logo.

Prompt templates shipped in the source are generic and domain-neutral; if you need domain-specific wording, keep it in your own (non-committed) configuration.

## ⚠️ Disclaimer

TiJing automates screen reading and tapping on **your own device**. You are responsible for how you use it — respect the terms of service of any platform you point it at, and use it for personal study, accessibility or automation research.

## 🤝 Contributing

Issues and PRs are welcome. Good first contributions: extra bank importers, more matcher strategies, i18n, adaptive overlay layout.

<div align="center"><sub>If TiJing saves you time, a ⭐ helps others find it.</sub></div>
