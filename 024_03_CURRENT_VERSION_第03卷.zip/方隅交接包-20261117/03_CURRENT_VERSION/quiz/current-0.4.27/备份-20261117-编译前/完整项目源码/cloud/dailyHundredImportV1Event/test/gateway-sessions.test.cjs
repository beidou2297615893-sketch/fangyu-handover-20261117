'use strict';
const assert = require('node:assert/strict');
const { createSessions } = require('../lib/gateway-sessions.cjs');

// Mirrors @cloudbase/database 1.4.3 runTransaction: one callback attempt, and
// on DATABASE_TRANSACTION_CONFLICT only, re-invoke with times-1. times=3 runs
// the callback at most 4 times (3,2,1,0). This is not a CloudBase server.
function memoryDb() {
  const committed = new Map();
  const versions = new Map();
  const ops = [];
  const state = { hook: null, conflictsLeft: 0, missNextUpdate: false, alwaysConflictUpdates: false, attempts: 0 };
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const db = {
    committed,
    versions,
    ops,
    get attempts() { return state.attempts; },
    onceAfterRead(fn) { state.hook = fn; },
    failUpdates(n) { state.conflictsLeft = n; },
    armMissUpdate() { state.missNextUpdate = true; },
    set alwaysConflictUpdates(value) { state.alwaysConflictUpdates = value; },
    async runTransaction(fn, times = 3) {
      const attempt = async (left) => {
        state.attempts += 1;
        const base = new Map();
        const local = new Map();
        const dirty = new Map();
        const tx = {
          collection() {
            return {
              doc(id) {
                return {
                  async get() {
                    if (!base.has(id)) {
                      base.set(id, versions.get(id) || 0);
                      if (committed.has(id)) local.set(id, clone(committed.get(id)));
                    }
                    const data = local.has(id) ? { _id: id, ...local.get(id) } : null;
                    if (state.hook) {
                      const fnHook = state.hook;
                      state.hook = null;
                      const handled = await fnHook(id);
                      if (handled !== true) state.hook = fnHook;
                    }
                    return { data };
                  },
                  async set(value) {
                    if (!base.has(id)) base.set(id, versions.get(id) || 0);
                    local.set(id, clone(value));
                    dirty.set(id, 'set');
                    ops.push({ op: 'set', id, keys: Object.keys(value).sort() });
                    return { updated: 1 };
                  },
                  async update(value) {
                    ops.push({ op: 'update', id, keys: Object.keys(value).sort(), value: clone(value) });
                    if (state.alwaysConflictUpdates || state.conflictsLeft > 0) {
                      if (state.conflictsLeft > 0) state.conflictsLeft -= 1;
                      return { code: 'DATABASE_TRANSACTION_CONFLICT' };
                    }
                    if (state.missNextUpdate) {
                      state.missNextUpdate = false;
                      return { updated: 0 };
                    }
                    if (!local.has(id)) return { updated: 0 };
                    local.set(id, { ...local.get(id), ...clone(value) });
                    if (dirty.get(id) !== 'set') dirty.set(id, 'update');
                    return { updated: 1 };
                  },
                };
              },
            };
          },
        };
        try {
          const result = await fn(tx);
          for (const id of dirty.keys()) {
            if ((base.get(id) || 0) !== (versions.get(id) || 0)) {
              const error = new Error('database transaction conflict');
              error.code = 'DATABASE_TRANSACTION_CONFLICT';
              throw error;
            }
          }
          for (const id of dirty.keys()) {
            committed.set(id, clone(local.get(id)));
            versions.set(id, (versions.get(id) || 0) + 1);
          }
          return result;
        } catch (error) {
          if (left > 0 && error && error.code === 'DATABASE_TRANSACTION_CONFLICT') return attempt(left - 1);
          throw error;
        }
      };
      return attempt(times);
    },
  };
  return db;
}

const input = {
  credential: 'ignored-by-verify',
  runId: 'run-1',
  taskBinding: 'a'.repeat(64),
  source: 'free',
  deviceDigest: 'b'.repeat(64),
};

function runDoc(db) {
  const key = [...db.committed.keys()].find((item) => item.startsWith('gr-'));
  assert.equal(typeof key, 'string');
  return { key, row: db.committed.get(key) };
}

function sameExceptExpiry(before, after) {
  assert.deepEqual(
    Object.keys(after).sort(),
    Object.keys(before).sort(),
  );
  for (const key of Object.keys(before)) {
    if (key === 'expiresAt') continue;
    assert.deepEqual(after[key], before[key]);
  }
}

async function main() {
  let verifies = 0;
  const verify = async () => {
    verifies += 1;
    return { ownerId: 'owner-1', status: 'authorized', source: 'free' };
  };
  let now = 1_000_000;
  const db = memoryDb();
  const sessions = createSessions({ db, providerKey: 'test-key', verify, clock: () => now });

  const created = await sessions.exchange(input);
  assert.equal(created.used, 0);
  assert.equal(created.limit, 160);
  assert.equal(created.expiresAt, now + 3600000);
  assert.equal(created.token.length, 43);
  assert.equal(verifies, 1);

  now += 1000;
  const reused = await sessions.exchange(input);
  assert.equal(reused.expiresAt, created.expiresAt);
  assert.equal(reused.token, created.token);
  assert.equal(verifies, 2);

  now = created.expiresAt + 1;
  const beforeRenew = { ...runDoc(db).row };
  const attemptsBefore = db.attempts;
  const opsBefore = db.ops.length;
  db.failUpdates(1);
  const renewed = await sessions.exchange(input);
  assert.equal(renewed.token, created.token);
  assert.equal(renewed.used, 0);
  assert.equal(renewed.expiresAt, now + 3600000);
  assert.equal(verifies, 3);
  assert.equal(db.attempts - attemptsBefore, 2);
  const afterRenew = runDoc(db).row;
  sameExceptExpiry(beforeRenew, afterRenew);
  assert.equal(afterRenew.expiresAt, now + 3600000);
  const renewalOps = db.ops.slice(opsBefore).filter((op) => op.op === 'update');
  assert.equal(renewalOps.length, 2);
  for (const op of renewalOps) assert.deepEqual(op.value, { expiresAt: now + 3600000 });
  assert.equal(db.ops.slice(opsBefore).some((op) => op.op === 'set' && op.id.startsWith('gr-')), false);

  const { key: runKey } = runDoc(db);
  const spent = { ...db.committed.get(runKey), used: 160, expiresAt: now - 1 };
  db.committed.set(runKey, spent);
  await assert.rejects(() => sessions.exchange(input));
  assert.equal(db.committed.get(runKey).used, 160);
  assert.equal(db.committed.get(runKey).expiresAt, now - 1);

  db.committed.set(runKey, { ...spent, used: 4, state: 'closed', expiresAt: now - 1 });
  await assert.rejects(() => sessions.exchange(input));
  assert.equal(db.committed.get(runKey).state, 'closed');

  const denied = createSessions({
    db: memoryDb(),
    providerKey: 'test-key',
    verify: async () => { throw new Error('not authorized'); },
    clock: () => now,
  });
  await assert.rejects(() => denied.exchange(input));

  await testUnexpiredExhausted();
  await testConsumeCloseAndRenewKeepsUsed();
  await testOverlappingConsumes();
  await testRenewLosesToClose();
  await testRenewLosesToSpent();
  await testDeletedRunIsNotRecreated();
  await testUpdateMissDoesNotUpsert();
  await testConflictRetryIsBounded();
  await testDuplicateExchangeDoesNotWrite();
  await testMissingIndexIsNotRebuilt();
  await testForeignIndexIsRejected();
  await testFirstCreateWritesRunAndIndex();
  console.log('gateway-sessions.test.cjs ok');
}

async function openFresh() {
  let verifies = 0;
  const verify = async () => {
    verifies += 1;
    return { ownerId: 'owner-1', status: 'authorized', source: 'free' };
  };
  let now = 5_000_000;
  const db = memoryDb();
  const sessions = createSessions({ db, providerKey: 'test-key', verify, clock: () => now });
  const created = await sessions.exchange(input);
  return {
    db,
    sessions,
    created,
    get now() { return now; },
    set now(value) { now = value; },
    verifies: () => verifies,
  };
}

async function testUnexpiredExhausted() {
  const env = await openFresh();
  const { key } = runDoc(env.db);
  const row = env.db.committed.get(key);
  env.db.committed.set(key, { ...row, used: 160 });
  const ops = env.db.ops.length;
  const got = await env.sessions.exchange(input);
  assert.equal(got.used, 160);
  assert.equal(got.expiresAt, row.expiresAt);
  assert.equal(env.db.ops.length, ops);
  assert.equal(env.db.committed.get(key).used, 160);
}

async function testConsumeCloseAndRenewKeepsUsed() {
  const env = await openFresh();
  assert.equal(await env.sessions.consume(env.created.token), true);
  assert.equal(await env.sessions.consume(env.created.token), true);
  const { key, row } = runDoc(env.db);
  assert.equal(row.used, 2);
  env.now = row.expiresAt + 1;
  const renewed = await env.sessions.exchange(input);
  assert.equal(renewed.used, 2);
  assert.equal(renewed.expiresAt, env.now + 3600000);
  assert.equal(env.db.committed.get(key).used, 2);
  assert.equal(env.db.committed.get(key).state, 'active');
  const again = await env.sessions.exchange(input);
  assert.equal(again.used, 2);
  assert.equal(again.expiresAt, renewed.expiresAt);
  await env.sessions.close(env.created.token);
  assert.equal(env.db.committed.get(key).state, 'closed');
  assert.equal(env.db.committed.get(key).used, 2);
  await assert.rejects(() => env.sessions.consume(env.created.token));
  await assert.rejects(() => env.sessions.exchange(input));
  assert.equal(env.db.committed.get(key).state, 'closed');
  assert.equal(env.db.committed.get(key).used, 2);
}

async function testOverlappingConsumes() {
  const env = await openFresh();
  const { key } = runDoc(env.db);
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    assert.equal(await env.sessions.consume(env.created.token), true);
    return true;
  });
  assert.equal(await env.sessions.consume(env.created.token), true);
  assert.equal(env.db.committed.get(key).used, 2);
  assert.equal(env.db.committed.get(key).expiresAt, env.created.expiresAt);
}

async function testRenewLosesToClose() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    assert.equal(await env.sessions.close(env.created.token), true);
    return true;
  });
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.get(key).state, 'closed');
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, 0);
}

async function testRenewLosesToSpent() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    await env.db.runTransaction(async (tx) => {
      const ref = tx.collection('daily_hundred_import_v1').doc(id);
      const current = await ref.get();
      const { _id, ...stored } = current.data;
      await ref.set({ ...stored, used: 160 });
    });
    return true;
  });
  await assert.rejects(() => env.sessions.exchange(input));
  assert.equal(env.db.committed.get(key).used, 160);
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).state, 'active');
}

async function testDeletedRunIsNotRecreated() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  env.now = row.expiresAt + 1;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    env.db.committed.delete(id);
    env.db.versions.set(id, (env.db.versions.get(id) || 0) + 1);
    return true;
  });
  await assert.rejects(() => env.sessions.exchange(input));
  assert.equal(env.db.committed.has(key), false);
  assert.equal(env.db.committed.has(indexKey), true);
}

async function testUpdateMissDoesNotUpsert() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  const ops = env.db.ops.length;
  env.db.armMissUpdate();
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  const written = env.db.ops.slice(ops);
  assert.equal(written.length, 1);
  assert.equal(written[0].op, 'update');
  assert.deepEqual(written[0].value, { expiresAt: env.now + 3600000 });
  assert.equal(written.some((op) => op.op === 'set'), false);
}

async function testConflictRetryIsBounded() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  env.now = row.expiresAt + 1;
  const attempts = env.db.attempts;
  const verifies = env.verifies();
  env.db.alwaysConflictUpdates = true;
  await assert.rejects(
    () => env.sessions.exchange(input),
    (error) => error && error.code === 'DATABASE_TRANSACTION_CONFLICT',
  );
  assert.equal(env.db.attempts - attempts, 4);
  assert.equal(env.verifies(), verifies + 1);
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  assert.equal(env.db.committed.get(key).state, 'active');
}

async function testDuplicateExchangeDoesNotWrite() {
  const env = await openFresh();
  const ops = env.db.ops.length;
  let nested = 0;
  env.db.onceAfterRead(async (id) => {
    if (!id.startsWith('gr-')) return false;
    nested += 1;
    const other = await env.sessions.exchange(input);
    assert.equal(other.token, env.created.token);
    assert.equal(other.expiresAt, env.created.expiresAt);
    assert.equal(other.used, 0);
    return true;
  });
  const again = await env.sessions.exchange(input);
  assert.equal(nested, 1);
  assert.equal(again.token, env.created.token);
  assert.equal(again.expiresAt, env.created.expiresAt);
  assert.equal(env.db.ops.length, ops);
  assert.equal(runDoc(env.db).row.used, 0);
}

async function testMissingIndexIsNotRebuilt() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  env.db.committed.delete(indexKey);
  const ops = env.db.ops.length;
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.has(indexKey), false);
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  assert.equal(env.db.ops.length, ops);
}

async function testForeignIndexIsRejected() {
  const env = await openFresh();
  const { key, row } = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  env.db.committed.set(indexKey, { ...env.db.committed.get(indexKey), runKey: 'gr-other' });
  const ops = env.db.ops.length;
  await assert.rejects(() => env.sessions.exchange(input), (error) => error instanceof Error && error.message === 'session unavailable');
  assert.equal(env.db.committed.get(indexKey).runKey, 'gr-other');
  assert.equal(env.db.committed.get(key).expiresAt, row.expiresAt);
  assert.equal(env.db.committed.get(key).used, row.used);
  assert.equal(env.db.ops.length, ops);
}

async function testFirstCreateWritesRunAndIndex() {
  const env = await openFresh();
  const run = runDoc(env.db);
  const indexKey = [...env.db.committed.keys()].find((item) => item.startsWith('gs-'));
  assert.equal(env.db.committed.get(indexKey).kind, 'gateway-session-v1');
  assert.equal(env.db.committed.get(indexKey).runKey, run.key);
  assert.equal(run.row.used, 0);
  assert.equal(run.row.state, 'active');
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
