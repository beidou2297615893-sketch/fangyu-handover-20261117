from pathlib import Path
import argparse,hashlib,json,shutil,subprocess
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--stage',required=True);p.add_argument('--verify',action='store_true');a=p.parse_args()
source=Path(a.source).resolve();stage=Path(a.stage).resolve()
if source==stage or source in stage.parents or stage in source.parents:raise SystemExit('Source and build stage must be separate project directories')
manifest=stage/'build-source-input.json'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if a.verify:
 rows=json.loads(manifest.read_text(encoding='utf-8'))
 for row in rows:
  for root in (source,stage):
   f=root/row['path']
   if not f.is_file() or digest(f)!=row['sha256']:raise SystemExit('Source changed during build: '+row['path'])
 print('Verified unchanged source and staged inputs:',len(rows));raise SystemExit(0)
raw=subprocess.check_output(['git','-C',str(source),'ls-files','-z','-c','-o','--exclude-standard'])
names={x.decode('utf-8') for x in raw.split(b'\0') if x}
web=source/'android/app/src/main/assets/web'
if not (web/'index.html').is_file():raise SystemExit('Build and sync the web assets before the Android snapshot')
names.update(f.relative_to(source).as_posix() for f in web.rglob('*') if f.is_file())
for extra in ['work/build-android.ps1','work/snapshot-android-build.py','work/network-repositories.init.gradle']:
 if (source/extra).is_file():names.add(extra)
rows=[]
for name in sorted(names):
 rel=Path(name)
 if rel.is_absolute() or '..' in rel.parts:raise SystemExit('Unsafe source entry')
 if rel.name=='local.properties' or rel.suffix.lower() in {'.jks','.p12','.pem','.keystore','.pfx'} or (rel.name.startswith('.env') and rel.name!='.env.example'):continue
 f=source/rel
 if not f.is_file():continue
 rows.append({'path':rel.as_posix(),'sha256':digest(f)})
stage.mkdir(parents=True,exist_ok=True)
old=json.loads(manifest.read_text(encoding='utf-8')) if manifest.exists() else []
keep={r['path'] for r in rows}
for row in old:
 if row['path'] in keep:continue
 f=stage/row['path'];resolved=f.resolve()
 if stage not in resolved.parents:raise SystemExit('Refusing stale file outside build stage')
 if f.is_file():f.unlink()
for row in rows:
 dst=stage/row['path'];dst.parent.mkdir(parents=True,exist_ok=True)
 if not dst.exists() or digest(dst)!=row['sha256']:shutil.copy2(source/row['path'],dst)
manifest.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared source snapshot:',len(rows),'files')
