package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class ProjectionRecoveryTest {
    @Test fun externalOrStaleIntentCannotRequestConsent() {
        val state = ProjectionRecovery()
        assertFalse(state.open("external"))
        state.lost()
        val old = state.challenge
        state.lost()
        assertFalse(state.open(old))
        assertFalse(state.approve(state.challenge))
        assertTrue(state.open(state.challenge))
        assertFalse(state.open(state.challenge))
    }

    @Test fun cancelledConsentCanRetryButCannotRestoreWithoutAnotherGrant() {
        val state = ProjectionRecovery()
        state.lost()
        val id = state.challenge
        assertTrue(state.open(id))
        assertTrue(state.cancel(id))
        assertFalse(state.approve(id))
        assertFalse(state.restored(id))
        assertTrue(state.open(id))
        assertTrue(state.approve(id))
        assertFalse(state.approve(id))
        assertTrue(state.restored(id))
        assertEquals(ProjectionRecovery.Phase.READY, state.phase)
        state.clear()
        assertNull(state.phase)
        assertFalse(state.open(id))
    }

    @Test fun closingOrLosingProjectionInvalidatesLateConsentAndLateSetup() {
        val state = ProjectionRecovery()
        state.lost()
        val first = state.challenge
        assertTrue(state.open(first))
        state.clear()
        assertFalse(state.approve(first))
        state.lost()
        val second = state.challenge
        assertTrue(state.open(second))
        assertTrue(state.approve(second))
        state.lost()
        assertFalse(state.restored(second))
    }
}
