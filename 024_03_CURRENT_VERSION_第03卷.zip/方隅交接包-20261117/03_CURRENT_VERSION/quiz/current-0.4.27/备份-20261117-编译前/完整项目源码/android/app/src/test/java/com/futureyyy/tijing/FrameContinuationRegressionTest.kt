package com.futureyyy.tijing
import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class FrameContinuationRegressionTest {
    private val fixture=JsonParser.parseString(javaClass.getResourceAsStream("/regression/feedback53.json")!!
        .bufferedReader(Charsets.UTF_8).use{it.readText()}).asJsonObject
    private fun read(name:String):OcrHostPage = OcrHostPage.read(fixture.getAsJsonObject(name).getAsJsonArray("lines").map{
        val o=it.asJsonObject;val b=o.getAsJsonObject("box")
        VisibleQuestionReader.Node(o.get("text").asString,NormalizedBox(b.get("x").asFloat,b.get("y").asFloat,
            b.get("width").asFloat,b.get("height").asFloat))
    })
    @Test fun incompleteFeedbackMustUseExistingIndependentReaderBeforeWaitingAgain() {
        val primary=read("primary");val independent=read("independent")
        assertFalse(primary.page.graded);assertNull(primary.nextBox)
        assertTrue(independent.page.graded);assertNotNull(independent.nextBox)
        assertEquals(HostQuestionProgress(53,100),primary.page.progress)
        assertTrue(primary.needsContinuationRead(true))
    }
    @Test fun aFreshUnsubmittedQuestionDoesNotRequestContinuationRecovery() {
        assertFalse(read("primary").needsContinuationRead(false))
    }
    @Test fun alreadyCompleteContinuationDoesNotNeedAnotherReader() {
        assertFalse(read("independent").needsContinuationRead(true))
    }
    @Test fun visibleCounterDoesNotProveSubmissionStateWhenStartingMidQuiz() {
        val next=read("primary").copy(page=HostQuestionPage(HostQuestionProgress(54,100)))
        assertTrue(next.needsContinuationRead(true))
    }
    @Test fun resultsAreTerminalAndGradedPagesStillNeedTheirMissingControl() {
        assertFalse(read("primary").copy(result=true).needsContinuationRead(true))
        assertTrue(read("independent").copy(nextBox=null).needsContinuationRead(false))
    }
}
