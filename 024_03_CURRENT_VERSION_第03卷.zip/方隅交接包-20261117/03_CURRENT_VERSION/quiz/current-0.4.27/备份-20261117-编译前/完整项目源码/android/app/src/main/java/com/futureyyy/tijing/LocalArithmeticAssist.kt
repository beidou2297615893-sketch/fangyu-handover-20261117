package com.futureyyy.tijing

object LocalArithmeticAssist {
    private val leadingLabel = Regex("""^[A-Da-d][\.。、\s]+""")
    private val integer = Regex("^-?\\d+$")
    private val add = Regex("(\\d+)\\s*(?:加上|加)\\s*(\\d+)")
    private val sub = Regex("(\\d+)\\s*(?:减去|减)\\s*(\\d+)")
    private val mul = Regex("(\\d+)\\s*(?:乘以|乘|×|x|X)\\s*(\\d+)")
    private val div = Regex("(\\d+)\\s*(?:除以|除|÷)\\s*(\\d+)")
    private val multiples = Regex("哪些是\\s*(\\d+)\\s*的(?:整数)?倍")
    private val even = Regex("(\\d+)\\s*是偶数")
    private val odd = Regex("(\\d+)\\s*是奇数")

    fun answerForVision(ai: QuizModelResult): QuizModelResult? {
        multiples.find(ai.question)?.let { match ->
            val base = match.groupValues[1].toLong()
            if (base == 0L) return null
            val answers = ai.options.mapNotNull { option ->
                val number = parseNumber(option.text) ?: return@mapNotNull null
                if (number % base == 0L && option.box != null) option.index else null
            }
            if (answers.isEmpty()) return null
            return ai.copy(
                type = if (answers.size > 1) QuestionType.MULTIPLE else ai.type,
                answerIndices = answers.distinct(),
                answerSource = "local_arithmetic",
            )
        }

        even.find(ai.question)?.let { match ->
            return booleanAnswer(ai, match.groupValues[1].toLong() % 2L == 0L)
        }
        odd.find(ai.question)?.let { match ->
            return booleanAnswer(ai, match.groupValues[1].toLong() % 2L == 1L)
        }

        val expected = arithmeticValue(ai.question) ?: return null
        val answers = ai.options.mapNotNull { option ->
            val number = parseNumber(option.text) ?: return@mapNotNull null
            if (number == expected && option.box != null) option.index else null
        }.distinct()
        if (answers.size != 1) return null
        return ai.copy(
            type = QuestionType.SINGLE,
            answerIndices = answers,
            answerSource = "local_arithmetic",
        )
    }

    private fun arithmeticValue(question: String): Long? {
        add.find(question)?.let { return it.groupValues[1].toLong() + it.groupValues[2].toLong() }
        sub.find(question)?.let { return it.groupValues[1].toLong() - it.groupValues[2].toLong() }
        mul.find(question)?.let { return it.groupValues[1].toLong() * it.groupValues[2].toLong() }
        div.find(question)?.let {
            val dividend = it.groupValues[1].toLong()
            val divisor = it.groupValues[2].toLong()
            if (divisor == 0L || dividend % divisor != 0L) return null
            return dividend / divisor
        }
        return null
    }

    private fun booleanAnswer(ai: QuizModelResult, statementIsTrue: Boolean): QuizModelResult? {
        val want = if (statementIsTrue) setOf("正确", "对", "是", "真") else setOf("错误", "错", "否", "假")
        val answers = ai.options.mapNotNull { option ->
            val text = normalize(option.text)
            if (text in want && option.box != null) option.index else null
        }.distinct()
        if (answers.size != 1) return null
        return ai.copy(
            type = QuestionType.TRUE_FALSE,
            answerIndices = answers,
            answerSource = "local_arithmetic",
        )
    }

    private fun parseNumber(text: String): Long? {
        val trimmed = normalize(text)
        return if (integer.matches(trimmed)) trimmed.toLong() else null
    }

    private fun normalize(text: String): String = leadingLabel.replace(text.trim(), "").trim()
}
