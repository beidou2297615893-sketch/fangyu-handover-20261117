package com.futureyyy.tijing

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuizFinishedPageTest {
    @Test
    fun detectsSubmittedAndRedrawButtons() {
        assertTrue(QuizFinishedPage.matches("已提交：100\n重新抽取 100 题"))
        assertTrue(QuizFinishedPage.matches("得分：77 / 100"))
        assertTrue(QuizFinishedPage.matches("得分: 77 / 100"))
        assertTrue(QuizFinishedPage.matches("已提交: 100"))
    }

    @Test
    fun ignoresOrdinaryQuestionText() {
        assertFalse(QuizFinishedPage.matches("第70题 / 共100题\n18 乘以 5 的结果是多少？"))
        assertFalse(QuizFinishedPage.matches("提交答案"))
        assertFalse(QuizFinishedPage.matches(""))
    }
}
