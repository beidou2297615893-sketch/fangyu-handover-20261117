package com.futureyyy.tijing

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

/** A real railway frame with c. in an otherwise complete numeric option. */
class LowercaseOptionRegressionTest {
    private val fixture = JsonParser.parseString(javaClass.getResourceAsStream("/regression/lowercase-option.json")!!
        .bufferedReader(Charsets.UTF_8).use { it.readText() }).asJsonObject
    private val recordJson = fixture.getAsJsonObject("record")
    private val options = recordJson.getAsJsonArray("options").map {
        QuizOption(it.asJsonObject.get("index").asInt, it.asJsonObject.get("text").asString, null)
    }
    private val stem = recordJson.get("question").asString
    private val answer = recordJson.getAsJsonArray("answer_indices").map { it.asInt }
    private val bank = QuestionBankIndex.fromRecords(listOf(LocalQuestionBankRecord("recorded", stem,
        QuestionType.SINGLE, answer, options = options)))
    private val lines = fixture.getAsJsonArray("lines").map {
        val obj = it.asJsonObject;val box = obj.getAsJsonObject("box")
        VisibleQuestionReader.Node(obj.get("text").asString, NormalizedBox(box.get("x").asFloat,
            box.get("y").asFloat, box.get("width").asFloat, box.get("height").asFloat))
    }

    @Test fun lowercaseMarkerIsTheSameChoiceWithoutChangingItsNumbers() {
        assertNotNull(OcrHostPage.optionRows(lines, options))
        val resolved=bank.verifiedOcrPage(lines,46)
        assertNotNull(resolved)
        assertEquals(answer,resolved!!.answerIndices)
    }

    @Test fun aChangedNumberCannotBeFilledFromTheBank() {
        val changed=lines.map { if(it.text.startsWith("c.")) it.copy(text="c.1000,50000,20") else it }
        assertNull(OcrHostPage.optionRows(changed,options))
        assertNull(bank.verifiedOcrPage(changed,46))
    }

    @Test fun aDifferentLetterStillCannotBecomeC() {
        val changed=lines.map { if(it.text.startsWith("c.")) it.copy(text=it.text.replaceFirst("c.","d.")) else it }
        assertNull(OcrHostPage.optionRows(changed,options))
        assertNull(bank.verifiedOcrPage(changed,46))
    }
}
