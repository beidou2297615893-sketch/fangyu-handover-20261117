package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class VisibleQuestionReaderTest {
    private fun node(text: String, y: Float = 10f, x: Float = 5f, width: Float = 90f, usable: Boolean = true) =
        VisibleQuestionReader.Node(text, if (usable) NormalizedBox(x, y, width, 5f) else null)
    private fun wrap(vararg children: VisibleQuestionReader.Node) = VisibleQuestionReader.Node("", null, children.toList())
    @Test fun aValuePrecedingALetterInOcrOrderAndADuplicateBoxDoNotMoveTheAnswer() {
        val lines = listOf(node("单选",3f),node("请选择一项",15f),node("A 1",24f),
            node("3",36f,17f,2f),node("B",36.25f,10f,2f),node("C 5",49f),
            node("D7",60f,10f,10f),node("7",60.2f,17f,2f))
        val page=VisibleQuestionReader.readOcrLines(lines,29)!!
        assertEquals(listOf("1","3","5","7"),page.options.map { it.text })
        assertEquals(17f,page.options[1].box!!.x)
        assertNull(VisibleQuestionReader.readOcrLines(lines.map { if (it.text == "B") it.copy(text="C") else it },29))
    }
    @Test fun missingAlternatingLabelsRequireTwoAnchorsAtTheirActualWrappedRows() {
        val lines = listOf(node("多选题", 4f),node("下列材料如何使用？", 11f),
            node("第一行", 22f, 25f, 55f), node("选项尾部", 28f, 25f, 51f),
            node("第二组正文",40f,25f,55f),node("B",41f,9f,4f),
            node("第三组正文",54f,25f,52f),node("换行",60f,25f,50f),
            node("第四组正文",74f,25f,55f),node("D",75f,9f,4f))
        val page = VisibleQuestionReader.readOcrLines(lines, 1)!!
        assertEquals(listOf("第一行选项尾部","第二组正文","第三组正文换行","第四组正文"),page.options.map { it.text })
        assertEquals(listOf(22f,40f,54f,74f),page.options.map { it.box!!.y })
        val wrong = lines.map { if (it.text == "D") it.copy(text="C") else it }
        assertNull(VisibleQuestionReader.readOcrLines(wrong, 1))
    }
    @Test fun readsMixedLetterPunctuationAndNumericValuesFromLocalScreenshot() {
        val lines = listOf(node("岗位练习", 6f), node("1/5", 13.8f, x=85f, width=8f), node("单选题", 14.1f),
            node("1、列车进库时,限速5km/h,在离", 20f), node("停车位置() m处一度停车,然后以", 24f),
            node("限速3km/h运行至登车平台处停车", 28f), node("(A) 5", 36f), node("B 10", 44.5f), node("(C) 15", 52f), node("D) 25", 61f))
        val page = VisibleQuestionReader.readOcrLines(lines, 1)!!
        assertEquals(listOf("5","10","15","25"), page.options.map { it.text })
        assertEquals(44.5f, page.options[1].box!!.y)
        val wrongLetter = lines.toMutableList().apply { set(7, node("C 10", 44.5f)) }
        assertNull(VisibleQuestionReader.readOcrLines(wrongLetter, 1))
    }
    @Test fun ocrIgnoresInstructionEdgeAndKeepsTheStemAndOptionLocations() {
        val lines = listOf(node("多选", 6f), node("以下哪些符合规定？", 16f), node("|请选择所有正确选项,再确认答案,", 30f),
            node("A. 甲", 43f), node("B. 乙", 56f), node("|确认答案", 72f))
        val page = VisibleQuestionReader.readOcrLines(lines, 11)!!
        assertEquals("以下哪些符合规定?", page.question)
        assertEquals(listOf(43f, 56f), page.options.map { it.box!!.y })
        assertEquals(72f, page.confirmBox!!.y)
    }
    private fun page(vararg rows: VisibleQuestionReader.Node, type: Boolean = true) = wrap(
        *listOfNotNull(if (type) node("单选题", 5f) else null, node("应选择A还是B？", 12f),
            *rows, node("确认答案", 80f)).toTypedArray())
    private fun combined(type: Boolean = true) = page(node("A. 甲", 30f), node("B. 乙", 40f), type = type)

    @Test fun combinedChineseRowsAndExtraWebViewLayersNeedNoProgressOrNext() {
        val layout = requireNotNull(VisibleQuestionReader.read(wrap(wrap(combined()))))
        assertEquals("应选择A还是B？", layout.question)
        assertEquals(listOf("甲", "乙"), layout.options.map { it.text })
        assertEquals(QuestionType.SINGLE, layout.type)
        assertTrue(layout.options.all { it.screenRow && it.box != null })
    }
    @Test fun independentLetterSiblingNestedBodyWorks() {
        val root = page(wrap(node("A",30f,5f,5f),wrap(wrap(node("甲",30f,15f,70f)))),
            wrap(node("B．",40f,5f,5f),wrap(node("乙",40f,15f,70f))))
        assertEquals(listOf("甲", "乙"), VisibleQuestionReader.read(root)?.options?.map { it.text })
    }
    @Test fun unknownTypeMustStayUnknownUntilExactUserBankResolvesIt() {
        val layout = requireNotNull(VisibleQuestionReader.read(combined(type = false)))
        assertNull(layout.type)
        val bank = QuestionBankIndex.fromRecords(listOf(LocalQuestionBankRecord("a", layout.question,
            QuestionType.MULTIPLE, listOf(1), options = listOf(QuizOption(0,"甲",null),QuizOption(1,"乙",null)))))
        assertNull(bank.answerForScreen(layout.page(1,QuestionType.SINGLE)))
        assertEquals(listOf(1), bank.answerForScreen(layout.page(1,QuestionType.MULTIPLE))?.answerIndices)
    }
    @Test fun exactBankRemapsShuffledRowsButRejectsStemLetterChanges() {
        val layout = requireNotNull(VisibleQuestionReader.read(combined()))
        val bank = QuestionBankIndex.fromRecords(listOf(LocalQuestionBankRecord("a", layout.question,
            QuestionType.SINGLE, listOf(1), options = listOf(QuizOption(0,"乙",null),QuizOption(1,"甲",null)))))
        assertEquals(listOf(0), bank.answerForScreen(layout.page(1,QuestionType.SINGLE))?.answerIndices)
        assertNull(bank.answerForScreen(layout.page(1,QuestionType.SINGLE).copy(question="应选择C还是D？")))
    }
    @Test fun hiddenBlockedMissingDuplicateAndDiscontinuousOptionsAreRejected() {
        assertNull(VisibleQuestionReader.read(page(node("A. 甲",30f),node("B. 乙",40f,usable=false))))
        assertNull(VisibleQuestionReader.read(page(node("A. 甲",30f),node("B. 甲",40f))))
        assertNull(VisibleQuestionReader.read(page(node("A. 甲",30f),node("C. 丙",40f))))
        assertNull(VisibleQuestionReader.read(page(node("A.",30f),node("B. 乙",40f))))
        assertNull(VisibleQuestionReader.read(page(node("A. 甲",30f))))
    }
    @Test fun aggregateParentLabelsDoNotCountAsDuplicateOptions() {
        val root=VisibleQuestionReader.Node("A. 甲 B. 乙",null,listOf(combined()))
        assertEquals(2,VisibleQuestionReader.read(root)?.options?.size)
    }
    @Test fun tapSnapshotRejectsChangedStemTypeAndSameQuestionReorderedOptions() {
        val page = requireNotNull(VisibleQuestionReader.read(combined())).page(1,QuestionType.SINGLE)
        assertTrue(VisibleQuestionReader.sameQuestion(page,page.copy(options=page.options.map { it.copy(box=NormalizedBox(10f,60f,50f,5f)) })))
        assertFalse(VisibleQuestionReader.sameQuestion(page,page.copy(question="另一题")))
        assertFalse(VisibleQuestionReader.sameQuestion(page,page.copy(type=QuestionType.MULTIPLE)))
        assertFalse(VisibleQuestionReader.sameQuestion(page,page.copy(options=page.options.reversed().mapIndexed { i,it -> it.copy(index=i) })))
    }
    @Test fun missingConfirmAndGradedPagesNeverAuthorizeFallback() {
        assertNull(VisibleQuestionReader.read(wrap(node("单选题"),node("问题",20f),node("A.甲",30f),node("B.乙",40f))))
        assertNull(VisibleQuestionReader.read(wrap(combined(),node("下一题",90f))))
    }
}
