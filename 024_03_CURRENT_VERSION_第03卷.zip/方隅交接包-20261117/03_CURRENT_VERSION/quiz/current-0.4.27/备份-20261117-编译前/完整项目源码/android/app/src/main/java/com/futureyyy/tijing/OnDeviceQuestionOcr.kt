package com.futureyyy.tijing

import android.os.Handler
import android.os.Looper

/**
 * Reads already-visible text from the target app's accessibility tree.
 * This follows official TiJing's original path and does not load on-device OCR models.
 */
internal class OnDeviceQuestionOcr(@Suppress("UNUSED_PARAMETER") context: android.content.Context) : AutoCloseable {
    private val main = Handler(Looper.getMainLooper())

    fun readIndependent(
        @Suppress("UNUSED_PARAMETER") frame: CaptureFrame,
        lines: List<VisibleQuestionReader.Node>,
        callback: (List<VisibleQuestionReader.Node>) -> Unit,
    ) {
        main.post { callback(lines) }
    }

    fun pageFromLines(lines: List<VisibleQuestionReader.Node>, questionNo: Int): QuizModelResult? =
        VisibleQuestionReader.readOcrLines(lines, questionNo)

    fun readLines(@Suppress("UNUSED_PARAMETER") frame: CaptureFrame, callback: (List<VisibleQuestionReader.Node>) -> Unit) {
        fun deliver() {
            val target = ScreenCaptureService.instance?.currentGatewayTarget()
            val service = QuizAccessibilityService.instance
            val lines = if (target.isNullOrBlank() || service == null) emptyList()
            else service.readVisibleLineNodes(target)
            callback(lines)
        }
        if (Looper.myLooper() == Looper.getMainLooper()) deliver() else main.post { deliver() }
    }

    override fun close() {}
}
