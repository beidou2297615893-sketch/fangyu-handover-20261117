package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class ConfirmContinuityTest {
    @Test fun scrollingNeedsThreeDistinctTextsThatMoveTogether() {
        val words=listOf("司机行车安全风险辨识不充分", "司机仓促施加全常用制动", "对于列车速度控制制动时机", "信号楼值班员对于天气因素通知")
        val opts=words.mapIndexed { i,s -> QuizOption(i,s,null) }
        fun lines(dy:Float)=words.mapIndexed { i,s -> VisibleQuestionReader.Node(s.take(9),NormalizedBox(17f,34f+i*19f-dy,46f,3f)) }
        val a=ConfirmContinuity.anchors(lines(0f),opts);val b=ConfirmContinuity.anchors(lines(16f),opts)
        assertEquals(4,a.size);assertTrue(ConfirmContinuity.followedScroll(a,b-0))
        assertFalse(ConfirmContinuity.followedScroll(a,b-0-1))
        assertFalse(ConfirmContinuity.followedScroll(a,b+(2 to a.getValue(2))))
        assertTrue(ConfirmContinuity.anchors(lines(0f),opts.map { it.copy(text="正确") }).isEmpty())
    }
}
