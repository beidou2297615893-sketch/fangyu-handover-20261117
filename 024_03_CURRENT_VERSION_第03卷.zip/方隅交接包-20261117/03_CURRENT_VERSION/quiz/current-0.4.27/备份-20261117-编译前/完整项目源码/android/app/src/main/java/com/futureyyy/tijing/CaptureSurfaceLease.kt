package com.futureyyy.tijing

/** Accessed only on the capture looper. Retired surfaces can still have queued callbacks. */
internal class CaptureSurfaceLease<T : Any>(private val close: (T) -> Unit) {
    var current: T? = null
        private set

    fun owns(surface: T): Boolean = current === surface

    fun replace(next: T, attach: () -> Unit) {
        val previous = current
        try {
            attach()
        } catch (error: Exception) {
            close(next)
            throw error
        }
        current = next
        previous?.let(close)
    }

    fun clear() {
        val previous = current
        current = null
        previous?.let(close)
    }
}
