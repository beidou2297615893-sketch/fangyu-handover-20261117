package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class OcrHostPageTest {
    private fun line(text: String, y: Float, x: Float = 30f, w: Float = 20f, h: Float = 3f) =
        VisibleQuestionReader.Node(text, NormalizedBox(x, y, w, h))
    private val question = listOf(line("单选 第5题/100题", 12f), line("遇到能见度不足时，", 19f),
        line("应当如何处理？", 23f), line("A. 减速", 35f), line("B. 加速", 44f))

    @Test fun printedRuleMustBeProvenOnScreenBeforeBankDashLengthsCanBeMapped() {
        val stem="某显示器收到命令时，应显示什么？"
        val opts=listOf("——", "H", "黑屏", "999").mapIndexed { i,t -> QuizOption(i,t,line(t,35f+i*10f).box) }
        val page=QuizModelResult(1,QuestionType.SINGLE,stem,opts,emptyList(),null,null,1.0)
        val lines=listOf(line(stem,20f),line("—",35f).copy(continuousRule=true))+opts.drop(1).map{VisibleQuestionReader.Node(it.text,it.box)}
        val witnessed=OcrHostPage.observedRuleIndex(listOf(lines),page)
        assertEquals(0,witnessed)
        assertNull(OcrHostPage.observedRuleIndex(listOf(lines.map{it.copy(continuousRule=false)}),page))
        assertNull(OcrHostPage.observedRuleIndex(listOf(lines+line("—",85f).copy(continuousRule=true)),page))
        val record=LocalQuestionBankRecord("record",stem,QuestionType.SINGLE,listOf(1),options=opts.map{it.copy(text=if(it.index==0)"———" else it.text,box=null)})
        val bank=QuestionBankIndex.fromRecords(listOf(record))
        assertTrue(runCatching{bank.verifiedAnswer(page)}.isFailure)
        assertEquals(listOf(1),bank.verifiedAnswer(page.copy(physicalRuleIndex=witnessed)).answerIndices)
        val conflict=QuestionBankIndex.fromRecords(listOf(record,record.copy(id="other",answerIndices=listOf(0))))
        assertTrue(runCatching{conflict.verifiedAnswer(page.copy(physicalRuleIndex=witnessed))}.isFailure)
        for (other in listOf("-1","---", "— —", "IV", "-·-")) assertFalse(OcrHostPage.isRuleText(other))
    }

    @Test fun selectedFrameCanShowTheButtonAtADifferentPositionOrForTheFirstTime() {
        assertNull(OcrHostPage.confirmBox(question))
        val button = line("确 认 答 案", 79f)
        val selected = question + button
        assertEquals(button.box, OcrHostPage.confirmBox(selected))
        assertTrue(OcrHostPage.containsStem(selected, "遇到能见度不足时，应当如何处理？"))
        assertFalse(OcrHostPage.containsStem(selected, "另一道题"))
        assertEquals(HostQuestionProgress(5, 100), OcrHostPage.read(selected).page.progress)
    }

    @Test fun splitTextInOneButtonAndDuplicateControlsAreDistinguished() {
        val first = line("确", 60f, 30f, 2.5f)
        val rest = line("认答案", 60f, 33f, 8f)
        assertEquals(first.box, OcrHostPage.confirmBox(question + listOf(first, rest)))
        val upper = line("确认", 65f)
        assertEquals(upper.box, OcrHostPage.confirmBox(question + listOf(upper, line("答案", 69f))))
        val outlined = line("|确认答案", 67f)
        assertEquals(outlined.box, OcrHostPage.confirmBox(question + listOf(line("|请选择所有正确选项,再确认答案,", 28f), outlined)))
        assertNull(OcrHostPage.confirmBox(question + listOf(line("确认答案", 66f), line("确认答案", 74f))))
        assertNull(OcrHostPage.confirmBox(question + line("请核对后确认答案", 70f)))
        assertNull(OcrHostPage.confirmBox(question + line("确认答案", 28f)))
    }

    @Test fun unreadableChoiceMarkersCannotEraseTheNegationAtTheBeginningOfTheQuestion() {
        val noLetters = listOf(line("随机百题", 8f), line("不允许列车", 20f), line("以该速度运行。", 24f),
            line("是", 35f), line("否", 43f), line("确认答案", 70f))
        assertTrue(OcrHostPage.containsStem(noLetters, "不允许列车以该速度运行。"))
        assertFalse(OcrHostPage.containsStem(noLetters, "允许列车以该速度运行。"))
    }

    @Test fun nextAloneDoesNotProveGradingAndTheResultRequiresASecondIndependentCue() {
        val next = line("下一题", 80f)
        assertFalse(OcrHostPage.read(question + next).page.graded)
        assertNull(OcrHostPage.confirmBox(question + next))
        val reported = OcrHostPage.read(question + listOf(line("回答错误", 55f), line("正确答案：B", 60f), next))
        assertTrue(reported.page.graded)
        assertEquals(next.box, reported.nextBox)
        assertFalse(OcrHostPage.read(listOf(line("得分：100", 20f))).result)
        assertTrue(OcrHostPage.read(listOf(line("得分：100", 20f), line("答对100题", 40f), line("再来100题", 75f))).result)
    }

    @Test fun changedCanvasRelocatesOneOptionOnlyOnTheSameCompleteQuestion() {
        val original = requireNotNull(VisibleQuestionReader.readOcrLines(question, 1))
        val move = original.options.map { it.copy(box = it.box!!.copy(y = it.box.y + 5f)) }
        val b = original.options[1].copy(text = "B. " + original.options[1].text)
        val originalWithLetter = original.copy(options = listOf(original.options[0], b))
        val after = original.copy(options = move)
        assertEquals(move[1].box, OcrHostPage.freshOption(originalWithLetter, b, after))
        assertNull(OcrHostPage.freshOption(originalWithLetter, b, after.copy(options = move.reversed().mapIndexed { i,o -> o.copy(index = i) })))
        assertNull(OcrHostPage.freshOption(originalWithLetter, b, after.copy(question = original.question.replace("不足", "充足"))))
    }

    @Test fun cloudAnswerWithAWrongLocationIsLocatedOnTheActualUnnumberedCanvasRows() {
        val badBox = NormalizedBox(8f, 76f, 82f, 8f)
        val expected = listOf(QuizOption(0, "A. 正确", badBox), QuizOption(1, "B. 错误", badBox))
        val yes = VisibleQuestionReader.Node("(A)正确", NormalizedBox(10.47f, 39.92f, 18.91f, 2.89f))
        val no = VisibleQuestionReader.Node("(B)错误", NormalizedBox(11.88f, 48.44f, 17.81f, 2.19f))
        val lines = listOf(line("第2題：带少量识别误字的题干", 21f), yes, no)
        val found = requireNotNull(OcrHostPage.optionRows(lines, expected))
        assertEquals(265f, found[0].centerY * 6.4f, 2f)
        assertEquals(no.box, found[1])
        assertNull(OcrHostPage.optionRows(lines - yes, expected))
        assertNull(OcrHostPage.optionRows(lines + line("正确", 74f), expected))
    }

    @Test fun identicalTrueFalseOptionsCannotCorroborateTheWrongCloudStem() {
        val first = line("(A)正确", 40f); val second = line("(B)错误", 48f)
        val stem = "对携带易燃易爆物品进站乘车的乘客，应采取劝阻或令其离开地铁车站，不听劝阻者移送公安部门处理。"
        val noisy = listOf(line("第2題：对携带易燃易爆物品进站乘车", 20f), line("的乘客，应采取劝阻或令其离开地铁", 24f),
            line("车站，不听劝阻者移这送公安部门处", 28f), line("理。", 32f), first, second)
        assertTrue(OcrHostPage.matchesCloudStem(noisy, stem, first.box!!))
        assertFalse(OcrHostPage.matchesCloudStem(noisy, "电客列车带电进入无电区属一般E类事故。", first.box))
        assertFalse(OcrHostPage.matchesCloudStem(noisy, stem.replace("不听", "听"), first.box))
    }

    @Test fun actionVerbsAndSafetyQualifiersCannotBeChangedByACloseOcrMatch() {
        val box = line("A. 对", 60f).box!!
        for ((actual, other) in listOf("允许" to "禁止", "关闭" to "开启", "牵引" to "制动", "升" to "降")) {
            val text = "司机在完成检查并取得调度授权后，执行${actual}操作，随后再次向值班员核实并记录。"
            assertFalse(OcrHostPage.matchesCloudStem(listOf(line(text, 25f)), text.replace(actual, other), box))
        }
    }

    @Test fun independentOcrMustVerifyAnEntireQuestionWithoutCombiningPartialReadings() {
        val stem = "请核对本题完整的题干"
        val first = line("A. 正确", 50f)
        val second = line("B. 错误", 62f)
        val answer = QuizModelResult(1, QuestionType.TRUE_FALSE, stem,
            listOf(QuizOption(0,"正确",null), QuizOption(1,"错误",null)), emptyList(),null,null,1.0)
        val wrongStem = listOf(line("另一道完全不同的题干", 21f), first, second)
        val missingOption = listOf(line(stem, 21f), first)
        assertNull(OcrHostPage.verifiedRows(listOf(missingOption, wrongStem), answer))
        val valid = missingOption + second
        assertEquals(listOf(first.box, second.box), OcrHostPage.verifiedRows(listOf(wrongStem, valid), answer))
        val shifted = listOf(line(stem, 21f), line("A. 正确", 31f), line("B. 错误", 39f))
        assertNull(OcrHostPage.verifiedRows(listOf(valid, shifted), answer))
    }
}
