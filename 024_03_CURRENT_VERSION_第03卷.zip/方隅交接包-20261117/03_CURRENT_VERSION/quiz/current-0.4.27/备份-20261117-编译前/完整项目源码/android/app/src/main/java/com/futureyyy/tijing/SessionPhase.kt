package com.futureyyy.tijing

/**
 * Page-facing session label. This is separate from [ScreenCaptureService.isSessionRunning],
 * which also gates startup timeout and activity teardown.
 */
internal object SessionPhase {
    const val IDLE = "idle"
    const val READY = "ready"
    const val RUNNING = "running"
    const val RECOVERING = "recovering"

    fun describe(
        recoveryActive: Boolean,
        configReady: Boolean,
        coordinatorReady: Boolean,
        sweepActive: Boolean,
        runnerStarted: Boolean,
    ): String {
        if (recoveryActive && configReady) return RECOVERING
        if (!configReady || (!coordinatorReady && !sweepActive)) return IDLE
        if (runnerStarted || sweepActive) return RUNNING
        return READY
    }
}

/** Emits a phase only when it changes, so the page does not receive the same state twice. */
internal class SessionPhasePublisher {
    private var published: String? = null

    fun publish(phase: String): String? {
        if (phase == published) return null
        published = phase
        return phase
    }
}
