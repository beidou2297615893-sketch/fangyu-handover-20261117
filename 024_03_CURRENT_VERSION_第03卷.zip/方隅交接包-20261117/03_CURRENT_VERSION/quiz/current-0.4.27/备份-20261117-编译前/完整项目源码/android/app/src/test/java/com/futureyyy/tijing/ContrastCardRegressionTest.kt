package com.futureyyy.tijing
import java.io.DataInputStream
import java.util.zip.GZIPInputStream
import org.junit.Test
import org.junit.Assert.*

class ContrastCardRegressionTest {
    @Test fun paleRadioControlsRemainPhysicalEvidenceForCompleteOutlinedChoices() {
        for(number in listOf(48,58,63,70,81)) {
            val input=DataInputStream(GZIPInputStream(javaClass.getResourceAsStream("/regression/contrast-%03d.argb.gz".format(number))!!))
            val width=input.readInt();val height=input.readInt()
            val pixels=IntArray(width*height){input.readInt()};input.close()
            val cards=ShortChoiceCards.locate(width,height,pixels)
            assertEquals("Real frame $number has four visible full radio choices",4,cards.size)
            assertTrue(cards.zipWithNext().all{(a,b)->a.card.bottom<b.card.top})
        }
    }
}
