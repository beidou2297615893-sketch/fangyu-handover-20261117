package com.futureyyy.tijing

import kotlin.math.abs

/** Locate a contiguous, single-column series of outlined choices, independently of OCR line detection. */
internal object ShortChoiceCards {
    data class Rect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val w get() = right - left
        val h get() = bottom - top
    }
    data class Choice(val card: Rect, val text: Rect, val marker: Rect, val continuousRule: Boolean, val lines:List<Rect>)
    private data class Edge(val left:Int,val right:Int,val y:Int)

    /** A labelled one-stroke choice must have a real letter, dot and isolated straight body. */
    fun labelledRule(w:Int,h:Int,pixels:IntArray,choice:Choice,text:String):Rect? {
        if (!text.trim().matches(Regex("^[A-Z][.]\\s*[-_一—–─━―]{0,3}$")) || w.toLong()*h!=pixels.size.toLong()) return null
        val b=choice.text
        fun dark(x:Int,y:Int):Boolean { val c=pixels[y*w+x];return ((c ushr 16 and 255)*77+
            (c ushr 8 and 255)*150+(c and 255)*29)<197*256 }
        val columns=(b.left until b.right).filter{x->(b.top until b.bottom).any{y->dark(x,y)}}
        val spans=mutableListOf<IntRange>()
        for(x in columns){val last=spans.lastOrNull();if(last==null||x>last.last+1)spans+=x..x else spans[spans.lastIndex]=last.first..x}
        if(spans.size!=3)return null
        fun bounds(s:IntRange):Rect {val ys=(b.top until b.bottom).filter{y->s.any{x->dark(x,y)}};return Rect(s.first,ys.first(),s.last+1,ys.last()+1)}
        val letter=bounds(spans[0]);val dot=bounds(spans[1]);val stroke=bounds(spans[2])
        if(letter.h<12 || letter.w !in (letter.h*.35).toInt()..letter.h ||
            dot.w>maxOf(6,letter.h/4)||dot.h>maxOf(6,letter.h/4)||abs(dot.bottom-letter.bottom)>letter.h/5 ||
            stroke.w<maxOf(12,stroke.h*10)||stroke.h>maxOf(4,letter.h/8)||
            abs(stroke.top+stroke.bottom-letter.top-letter.bottom)>letter.h/2)return null
        if((stroke.top until stroke.bottom).none{y->(stroke.left until stroke.right).all{x->dark(x,y)}})return null
        return stroke
    }

    fun locate(w:Int, h:Int, pixels:IntArray): List<Choice> {
        if (w < 180 || h < 250 || w.toLong() * h != pixels.size.toLong()) return emptyList()
        fun light(x:Int,y:Int): Int {
            val c=pixels[y*w+x]
            return ((c ushr 16 and 255)*77 + (c ushr 8 and 255)*150 + (c and 255)*29) ushr 8
        }
        val step = (w / 260).coerceAtLeast(1)
        val dy = (w / 230).coerceIn(2,9)
        val edges = mutableListOf<Edge>()
        for(y in dy until h-dy) {
            var first = -1; var last = -1
            var x = step
            while(x < w-step) {
                val value=light(x,y)
                val outlined=value < 246 && light(x,y-dy)-value >= 13 && light(x,y+dy)-value >= 13
                if(outlined) { if(first<0) first=x; last=x }
                if ((!outlined && x-last>2*step || x+step>=w-step) && first>=0) {
                    if(last-first > w*0.54f) {
                        val prev=edges.lastOrNull()
                        if(prev==null || y-prev.y>dy || abs(first-prev.left)>w/15) edges+=Edge(first,last,y)
                    }
                    first=-1
                }
                x+=step
            }
        }
        fun choice(a:Edge,b:Edge):Choice? {
            val height=b.y-a.y
            if(height !in (w*0.045f).toInt()..minOf((w*0.96f).toInt(),h/2) || abs(a.left-b.left)>w/24 || abs(a.right-b.right)>w/24) return null
            val l=maxOf(a.left,b.left);val r=minOf(a.right,b.right)
            val yMid = (a.y + b.y) / 2
            fun side(from:Int, until:Int):Boolean {
                for (x in maxOf(dy,from) until minOf(w-dy,until)) {
                    if (listOf(yMid-height/5,yMid,yMid+height/5).all { y ->
                            val v=light(x,y); light(x-dy,y)-v>=12 && light(x+dy,y)-v>=12 }) return true
                }
                return false
            }
            val corner = minOf(height/2,w/20)
            if(!side(l-corner,l+step*3) || !side(r-step*3,r+corner))return null
            val margin=minOf(height*0.09f,w*0.012f).toInt().coerceAtLeast(2)
            val top=a.y+margin;val bottom=b.y-margin
            val left=l+step;val right=r-step
            if(top>=bottom || left>=right) return null
            val bg = listOf(top+(bottom-top)/12,(top+bottom)/2,bottom-(bottom-top)/12)
                .flatMap { y -> listOf(right-(right-left)/15,right-(right-left)/25,right-(right-left)/40).map { x -> light(x,y) } }
                .sorted()[4]
            if(bg<185)return null // Dark/translucent, busy or inverted cards need another recognizer.
            // Native light-gray radio outlines can be 209/255 on a white card.
            // Preserve the same 44-level background contrast and full geometry checks.
            val threshold=minOf(211,bg-44)
            val cols=IntArray(right-left)
            for(y in top until bottom) for(x in left until right) if(light(x,y)<threshold)cols[x-left]++
            val start=cols.indexOfFirst{it>=2};if(start<0)return null
            var cursor=start+1
            val splitGap=minOf(height*0.075f,w*0.009f).toInt().coerceAtLeast(3)
            var gap=0
            while(cursor<cols.size && gap<splitGap){if(cols[cursor]<2)gap++ else gap=0;cursor++}
            if(gap<splitGap)return null
            val markerEnd=cursor-gap
            val bodyStart=(cursor until cols.size).firstOrNull {cols[it]>=2}?:return null
            if(start>cols.size*0.12f || markerEnd-start !in maxOf(4,(w*0.014f).toInt())..minOf((w*0.14f).toInt(),(height*0.83f).toInt()) ||
                bodyStart-markerEnd>height || bodyStart>cols.size*0.29f)return null
            fun ink(from:Int,to:Int, yStart:Int=top, yEnd:Int=bottom):Rect? {
                var x0=to;var x1=from;var y0=bottom;var y1=top
                for(y in yStart until yEnd)for(x in from until to)if(light(x,y)<threshold){x0=minOf(x0,x);x1=maxOf(x1,x+1);y0=minOf(y0,y);y1=maxOf(y1,y+1)}
                return if(x1>x0&&y1>y0)Rect(x0,y0,x1,y1)else null
            }
            val marker=ink(left+start,left+markerEnd)?:return null
            val body=ink(left+bodyStart,right)?:return null
            // The entire body consists of a single continuous straight horizontal stroke.
            // Requiring ink in *every* column rejects spaced dashes, Morse, and numbers with a minus sign.
            val rule=body.w>=maxOf(12,body.h*12) && body.h<=maxOf(4,height/12) &&
                (body.top until body.bottom).any { y -> (body.left until body.right).all { x -> light(x,y)<threshold } } &&
                (body.left until body.right).count { x -> (body.top until body.bottom).all { y -> light(x,y)<threshold } } * 10 >= body.w * 9
            // A wrapped choice has one control and several physically separated text lines.
            // Use the control as the font-size reference; the card itself grows with its content.
            val lines = mutableListOf<Rect>()
            if (rule) lines += body else {
                val minimumGap = (marker.h*0.11f).toInt().coerceAtLeast(2)
                var firstInk = -1
                var lastInk = -1
                for (y in body.top until body.bottom) {
                    if ((body.left until body.right).none { x -> light(x,y)<threshold }) continue
                    if (firstInk >= 0 && y-lastInk > minimumGap) {
                        lines += ink(body.left,body.right,firstInk,lastInk+1) ?: return null
                        firstInk = -1
                    }
                    if (firstInk < 0) firstInk = y
                    lastInk = y
                }
                if (firstInk < 0) return null
                lines += ink(body.left,body.right,firstInk,lastInk+1) ?: return null
                if (lines.size !in 1..10 || lines.any { line ->
                        line.h !in maxOf(4,marker.h/4)..marker.h*13/10 || line.w>line.h*30 ||
                            abs(line.left-lines.first().left)>maxOf(w/35,marker.w/2)
                    }) return null
            }
            if(marker.w !in (marker.h*0.77f).toInt()..(marker.h*1.28f).toInt() ||
                abs(body.top+body.bottom-a.y-b.y)>height*0.35f || abs(marker.top+marker.bottom-a.y-b.y)>height*0.30f) return null
            val innerLeft=marker.left+marker.w/3;val innerRight=marker.right-marker.w/3
            val innerTop=marker.top+marker.h/3;val innerBottom=marker.bottom-marker.h/3
            var dark=0
            for(y in innerTop until innerBottom)for(x in innerLeft until innerRight)if(light(x,y)<threshold)dark++
            val fraction=dark.toFloat()/((innerRight-innerLeft)*(innerBottom-innerTop)).coerceAtLeast(1)
            val lettered=fraction in 0.2f..0.75f
            if(lettered && ((marker.left until marker.right).any { x -> (marker.top until marker.bottom).none { y -> light(x,y)<threshold } } ||
                (marker.top until marker.bottom).any { y -> (marker.left until marker.right).none { x -> light(x,y)<threshold } }))return null
            return Choice(Rect(l,a.y,r,b.y),body,marker,rule,lines)
        }
        val cards=edges.zipWithNext().mapNotNull{(a,b)->choice(a,b)}
        if(cards.size !in 2..10)return emptyList()
        val rules = cards.count { it.continuousRule }
        if(rules>1)return emptyList()
        val first=cards.first()
        for(i in cards.indices){val c=cards[i];if(abs(c.card.left-first.card.left)>w/40 || abs(c.card.right-first.card.right)>w/40 ||
            abs(c.marker.left-first.marker.left)>w/40 || abs(c.text.left-first.text.left)>w/35 ||
            abs(c.marker.h-first.marker.h)>maxOf(3,first.marker.h/5) || (i>0 && (c.card.top-cards[i-1].card.bottom !in 1..first.marker.h)))return emptyList()}
        // An orphan edge immediately beside the group can belong to a clipped or
        // unreadable option. Leave the original full-frame reading intact in that case.
        val used = cards.flatMap { listOf(it.card.top, it.card.bottom) }.toSet()
        if (edges.any { it.y !in used && it.y in (first.card.top-first.card.h)..(cards.last().card.bottom+first.card.h) &&
                abs(it.left-first.card.left)<w/25 }) return emptyList()
        return cards
    }
}
