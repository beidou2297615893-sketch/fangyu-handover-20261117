package com.futureyyy.tijing

/** A conservative fallback for readable WebView text; never supplies an answer. */
internal object VisibleQuestionReader {
    data class Node(val text: String, val box: NormalizedBox?, val children: List<Node> = emptyList(), val continuousRule:Boolean = false)
    private val option = Regex("""^(?:([A-Z])\s*[.、:)]|[(\[【]([A-Z])[)\]】]\s*[.、:]?)\s*(.*)$""")
    private val letter = Regex("""^[A-ZＡ-Ｚ](?:[.．、:：)）])?$""")
    private val progress = Regex("""\d+\s*/\s*\d+""")
    private val types = mapOf("单选" to QuestionType.SINGLE, "单选题" to QuestionType.SINGLE,
        "多选" to QuestionType.MULTIPLE, "多选题" to QuestionType.MULTIPLE,
        "判断" to QuestionType.TRUE_FALSE, "判断题" to QuestionType.TRUE_FALSE,
        "不定项" to QuestionType.INDEFINITE, "不定项选择题" to QuestionType.INDEFINITE)
    private val confirmLabels = setOf("确认", "确定", "确认答案", "提交", "提交答案")
    private val gradedLabels = setOf("下一题", "下题", "正确答案", "回答正确", "回答错误", "答案解析")
    private fun normalized(text: String) = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKC).trim()

    private fun typeLabel(text: String) = types[normalized(text).trim('【','】','[',']','(',')')]
    private fun marker(text: String): Pair<Int, String>? {
        val value = normalized(text)
        option.matchEntire(value)?.let { return ((it.groupValues[1] + it.groupValues[2]).single() - 'A') to it.groupValues[3] }
        return if (letter.matches(value)) (value[0] - 'A') to "" else null
    }

    /** OCR lines are geometry, not Android nodes. Allow wrapped bodies and no visible submit control. */
    fun readOcrLines(raw: List<Node>, questionNo: Int): QuizModelResult? {
        if (raw.size !in 3..250) return null
        val lines = alignNumericLabels(raw.filter { it.box != null })
        if (lines.any { normalized(it.text).removeSuffix(":").let { s -> s in gradedLabels || s.startsWith("正确答案:") } }) return null
        // A type badge and question counter can share the same OCR line.
        val typePrefix = Regex("""^\s*[\[【(]?(单选题?|多选题?|判断题?|不定项(?:选择题)?)[\]】)]?\s*[:：]?\s*""")
        val pageProgress = Regex("""^(?:第)?\s*\d+\s*(?:/|／)\s*\d+\s*(?:题)?$""")
        val footer = Regex("""^(?:\d+\s*[题題國]已作|已答\s*\d+\s*题|每题\s*\d+\s*分|上一题|剩余时间).*""")
        val groups = mutableListOf<MutableList<Node>>()
        val stems = mutableListOf<String>()
        var type: QuestionType? = null
        var confirm: NormalizedBox? = null
        for (line in lines) {
            val box = line.box!!
            var value = normalized(line.text)
            if (value.trim('|','丨',' ') in confirmLabels) { confirm = box; break }
            if (footer.matches(value)) break
            if (pageProgress.matches(value)) continue
            if (groups.isEmpty()) {
                val tag = typePrefix.find(value)
                if (tag != null) {
                    type = types[tag.groupValues[1]]
                    stems.clear()
                    value = value.removeRange(tag.range).trim()
                    if (value.isEmpty() || pageProgress.matches(value)) continue
                }
            }
            // Radios and checkboxes can be emitted as a glyph ahead of the option letter.
            if (value.trimStart('|','丨',' ').startsWith("请选择") && (value.contains("选项") || value.contains("确认"))) continue
            val labelled = value.trimStart('○','◯','□','☐','●','◉','◎',' ')
            val expected = ('A' + groups.size).toString()
            val recognized = labelled.replace(Regex("""^[O0()|]+\s*(?=[A-Z])"""), "")
                .replaceFirst(Regex("""^([A-Z])\s+\1(?=[.、:)])"""), "$1")
            val marked = marker(recognized) ?: if (recognized.startsWith(expected) && recognized.length > 1 &&
                (recognized[1].isWhitespace() || recognized[1] in ",，" || recognized[1].code in 0x3400..0x9fff)) {
                groups.size to recognized.drop(1).trimStart(',', '，', ' ')
            } else null
            if (marked != null) {
                if (marked.first != groups.size) return readColumnOptions(lines, questionNo, type)
                groups.add(mutableListOf(Node(marked.second, box)))
            } else if (groups.isEmpty()) {
                val prior = lines.lastOrNull { it.box!!.centerY < box.centerY }
                if (prior != null && box.y - (prior.box!!.y + prior.box.height) > maxOf(2.5f, box.height * 1.25f)) stems.clear()
                stems.add(value)
            } else groups.last().add(Node(value, box))
        }
        if (stems.isEmpty() || groups.size !in 2..26) return readColumnOptions(lines, questionNo, type)
        val options = groups.mapIndexed { i, parts ->
            val text = parts.joinToString("") { it.text }.trim()
            if (text.isEmpty()) return null
            val hit = parts.firstOrNull { it.text.isNotBlank() }?.box ?: return null
            QuizOption(i, text, hit)
        }
        return QuizModelResult(questionNo, type ?: QuestionType.SINGLE, stems.joinToString(""), options,
            emptyList(), confirm, null, 1.0)
    }

    /** A circle letter and its value may be detected separately in either vertical order,
     * or both as "D7" and an overlapping second "7". Never infer a missing glyph by ordinal. */
    private fun alignNumericLabels(source: List<Node>): List<Node> {
        val sorted = source.sortedBy { it.box!!.centerY }
        val digits = Regex("""^[+-]?\d+(?:[.,]\d+)?%?$""")
        val joined = Regex("""^[ (]*([A-Z])[).、: ]*([+-]?\d+(?:[.,]\d+)?%?)$""")
        val rows = mutableListOf<MutableList<Node>>()
        for (n in sorted) {
            val anchor = rows.lastOrNull()?.firstOrNull()?.box
            val box = n.box!!
            if (anchor == null || box.centerY - anchor.centerY > minOf(box.height, anchor.height)*0.44f)
                rows.add(mutableListOf())
            rows.last().add(n)
        }
        return rows.flatMap { group ->
            if (group.size != 2) return@flatMap group
            val (a,b) = group.sortedBy { it.box!!.x }
            val first = a.box!!; val second = b.box!!
            val left = normalized(a.text); val right = normalized(b.text)
            if (!digits.matches(right)) return@flatMap group
            val text = joined.matchEntire(left)
            if (text != null && text.groupValues[2] == right && second.centerX in first.x..(first.x+first.width)) {
                return@flatMap listOf(Node(text.groupValues[1]+". "+right, second))
            }
            val mark = marker(left)
            val gap = second.x - (first.x+first.width)
            if (mark != null && mark.second.isBlank() && gap >= 0 && gap <= maxOf(first.height,second.height)*4f)
                listOf(Node(('A'+mark.first).toString()+". "+right, second))
            else group
        }
    }

    /** Some OCR engines see B/D in a separate left column while A/C are lost to checkbox outlines. */
    private fun readColumnOptions(lines: List<Node>, questionNo: Int, type: QuestionType?): QuizModelResult? {
        val anchors = lines.mapNotNull { line ->
            val mark = marker(normalized(line.text).trim('|','丨',' ')) ?: return@mapNotNull null
            if (mark.second.isEmpty()) mark.first to line.box!! else null
        }
        if (anchors.size < 2 || anchors.any { it.first !in 0..7 } ||
            anchors.zipWithNext().any { (a,b) -> a.first >= b.first } ||
            anchors.maxOf { it.second.x } - anchors.minOf { it.second.x } > 4f) return null
        val labelX = anchors.map { it.second.centerX }.average().toFloat()
        val typeLine = lines.indexOfLast { typeLabel(normalized(it.text).trim('|','丨',' ')) != null }
        if (typeLine < 0) return null
        val controlAt = lines.indexOfFirst { normalized(it.text).trim('|','丨',' ') in confirmLabels }
        val content = lines.subList(typeLine + 1, if (controlAt > typeLine) controlAt else lines.size)
            .filterNot { n ->
                val s = normalized(n.text).trim('|','丨',' ')
                progress.matches(s) || (s.startsWith("请选择") && s.contains("选项")) ||
                    s.contains(Regex("""题已作答|每题\d+分""")) || anchors.any { it.second == n.box }
            }
        val optionStart = content.indexOfFirst { it.box!!.x > labelX + 2f }
        if (optionStart < 1) return null
        val stem = content.take(optionStart).joinToString("") { normalized(it.text) }
        val body = content.drop(optionStart)
        val normalRows = body.filter { it.box!!.x > labelX + 2f }
        if (normalRows.isEmpty() || normalRows.maxOf { it.box!!.x } - normalRows.minOf { it.box!!.x } > 5f) return null
        val bodyLeft = normalRows.map { it.box!!.x }.sorted()[normalRows.size / 2]
        val prefixInLabelColumn = Regex("""^([A-Z])\s+(.+)$""")
        val grouped = mutableListOf<MutableList<Node>>()
        for (line in body) {
            val previous = grouped.lastOrNull()?.lastOrNull()?.box
            val box = line.box!!
            if (previous == null || box.y - (previous.y + previous.height) > maxOf(previous.height, box.height) * 1.25f)
                grouped.add(mutableListOf())
            val row = if (box.x > labelX + 2f) line else {
                val marked = prefixInLabelColumn.matchEntire(normalized(line.text)) ?: return null
                if (kotlin.math.abs(box.x - anchors.first().second.x) > 3f ||
                    marked.groupValues[1].single() - 'A' != grouped.lastIndex || box.x + box.width < bodyLeft + 3f) return null
                line.copy(text = marked.groupValues[2], box = box.copy(x = bodyLeft, width = box.x + box.width - bodyLeft))
            }
            grouped.last().add(row)
        }
        if (grouped.size !in 2..8 || anchors.any { (index, box) ->
            val rows = grouped.getOrNull(index) ?: return@any true
            box.centerY !in (rows.first().box!!.y - 1f)..(rows.last().box!!.let { it.y + it.height } + 1f)
        }) return null
        val options = grouped.mapIndexed { index, rows ->
            QuizOption(index, rows.joinToString("") { normalized(it.text) }, rows.first().box)
        }
        return QuizModelResult(questionNo, type ?: QuestionType.SINGLE, stem, options, emptyList(),
            lines.getOrNull(controlAt)?.box, null, 1.0)
    }

    data class Layout(val type: QuestionType?, val question: String, val options: List<QuizOption>, val confirmBox: NormalizedBox) {
        fun page(questionNo: Int, resolvedType: QuestionType) = QuizModelResult(questionNo, resolvedType,
            question, options, emptyList(), confirmBox, null, 1.0)
    }

    fun sameQuestion(a: QuizModelResult, b: QuizModelResult): Boolean =
        a.question == b.question && a.type == b.type &&
            a.options.map { it.index to it.text } == b.options.map { it.index to it.text }

    fun read(root: Node): Layout? {
        // Descendant text wins over Chromium's repeated aggregate labels.
        fun leaves(node: Node): List<Node> {
            val descendants = node.children.flatMap(::leaves)
            return if (descendants.isNotEmpty()) descendants else if (node.text.isNotBlank()) listOf(node) else emptyList()
        }
        val tokens = leaves(root)
        if (tokens.size !in 4..250) return null
        if (tokens.any { normalized(it.text) in gradedLabels || it.text.startsWith("正确答案：") }) return null
        val confirmIndices = tokens.indices.filter { normalized(tokens[it].text) in confirmLabels }
        val confirmAt = confirmIndices.singleOrNull() ?: return null
        val confirmBox = tokens[confirmAt].box ?: return null
        val typeIndices = (0 until confirmAt).filter { typeLabel(tokens[it].text) != null }
        if (typeIndices.size > 1) return null
        val typeAt = typeIndices.singleOrNull() ?: -1
        val type = if (typeAt >= 0) typeLabel(tokens[typeAt].text) else null
        val first = (typeAt + 1 until confirmAt).firstOrNull { marker(tokens[it].text) != null } ?: return null
        val beforeOptions = tokens.subList(typeAt + 1, first)
        // Without a type marker, accept one complete immediately preceding stem node only.
        // The caller must establish its type by a unique exact user-bank match.
        val stemTokens = (if (typeAt >= 0) beforeOptions else beforeOptions.takeLast(1)).filterNot {
            progress.matches(normalized(it.text)) || (it.text.startsWith("请选择") && it.text.endsWith("确认答案。"))
        }
        if (stemTokens.isEmpty() || stemTokens.any { it.box == null }) return null
        val stem = stemTokens.joinToString("") { it.text.trim() }
        if (stem.isBlank()) return null
        val options = mutableListOf<QuizOption>()
        var cursor = first
        while (cursor < confirmAt) {
            val head = tokens[cursor]
            val (index, inline) = marker(head.text) ?: return null
            if (index != options.size || head.box == null) return null
            cursor++
            val parts = mutableListOf<Node>()
            if (inline.isNotBlank()) parts.add(head.copy(text = inline))
            while (cursor < confirmAt && marker(tokens[cursor].text) == null) parts.add(tokens[cursor++])
            if (parts.isEmpty() || parts.any { it.box == null }) return null
            val text = parts.joinToString("") { it.text.trim() }
            if (text.isBlank()) return null
            // A split label/body row must occupy one horizontal band. Wrapped body text is
            // allowed inside its own node, but unrelated vertical paragraphs are not options.
            val boxes = (parts + head).map { it.box!! }
            val minY = boxes.minOf { it.y }
            val maxY = boxes.maxOf { it.y + it.height }
            val tallest = boxes.maxOf { it.height }
            if (maxY - minY > tallest * 1.6f) return null
            val bodyBox = parts.last().box!!
            options.add(QuizOption(index, text, bodyBox, screenRow = true))
        }
        if (options.size !in 2..26 || options.map { normalized(it.text) }.distinct().size != options.size) return null
        val optionBoxes = options.map { it.box!! }
        if (optionBoxes.zipWithNext().any { (a, b) -> b.y < a.y + a.height * 0.5f }) return null
        if (confirmBox.y < optionBoxes.last().y) return null
        return Layout(type, stem, options, confirmBox)
    }
}
