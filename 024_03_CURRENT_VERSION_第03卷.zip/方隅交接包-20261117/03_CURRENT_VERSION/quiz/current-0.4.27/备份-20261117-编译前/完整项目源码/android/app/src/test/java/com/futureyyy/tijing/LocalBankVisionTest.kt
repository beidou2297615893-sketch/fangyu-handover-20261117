package com.futureyyy.tijing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LocalBankVisionTest {
    private fun rec(id: String, q: String, opts: List<String>, ans: List<Int>, type: QuestionType = QuestionType.SINGLE) =
        LocalQuestionBankRecord(id, q, type, ans, "", opts.mapIndexed { i, t -> QuizOption(i, t, null) })

    private fun ai(q: String, opts: List<String>, ans: List<Int>, type: QuestionType = QuestionType.SINGLE, boxes: Boolean = true) = QuizModelResult(
        1, type, q, opts.mapIndexed { i, t -> QuizOption(i, t, if (boxes) NormalizedBox(5f, 20f + i * 8f, 90f, 6f) else null) },
        ans, NormalizedBox(20f, 85f, 60f, 6f), null, 0.9, answerSource = "vision")

    private val index = QuestionBankIndex.fromRecords(listOf(
        rec("r1", "“禁停区”采用（  ）色带标识。", listOf("黄色", "红色", "白色", "黑色"), listOf(0)),
        rec("r2", "消防装备器材的检查保养应做到“三会”和“四无”。三会是指（ ）；四无是指“无积尘、无损坏、无霉变、无缺件”。", listOf("会检查", "会使用", "会保养", "会修理"), listOf(0, 1, 2), QuestionType.MULTIPLE),
        rec("r3", "列车日常运行时司机应将灯光调节至确保有效的瞭望距离。", listOf("正确", "错误"), listOf(0), QuestionType.TRUE_FALSE),
        rec("r4", "调车作业中，调车指挥人在作业前应向全体作业人员传达调车作业计划。", listOf("正确", "错误"), listOf(0), QuestionType.TRUE_FALSE),
        rec("r5", "调车作业中，调车指挥人在作业前可以不向全体作业人员传达调车作业计划。", listOf("正确", "错误"), listOf(1), QuestionType.TRUE_FALSE),
        rec("r6", "调度命令由（ ）发布。", listOf("列车调度员", "车站值班员", "司机", "乘务员"), listOf(0)),
    ))

    @Test fun screenshotTranscriptionCanUseImportedAnswerWithoutAnyModelChoice() {
        val result = index.verifiedAnswer(ai("第 ５ 题：【单选题】“禁停区”采用___色带标识？",
            listOf("（Ａ）红色", "【Ｂ】 黑色", "Ｃ、黄色", "D. 白色"), emptyList()))
        assertEquals(listOf(2), result.answerIndices)
        assertEquals("question_bank", result.answerSource)
    }

    @Test fun bankOnlyRejectsSimilarStemIncompleteOptionsAndGuessedHistory() {
        val stored = rec("a", "1.5 kV 可以送电。", listOf("金属", "木材"), listOf(1))
        val guessed = rec("g", "人工智能自答记录", listOf("甲", "乙"), listOf(0)).copy(sources = listOf("auto_fallback"))
        val bank = QuestionBankIndex.fromRecords(listOf(stored, guessed))
        for (input in listOf(ai("5 kV 可以送电。", listOf("金属", "木材"), listOf(1)),
            ai("1.5 kV 不可以送电。", listOf("金属", "木材"), listOf(1)),
            ai(stored.question, listOf("金属", "材料"), listOf(0)),
            ai(guessed.question, listOf("甲", "乙"), listOf(0)))) {
            org.junit.Assert.assertThrows(IncompleteQuestionOptions::class.java) { bank.verifiedAnswer(input) }
        }
    }

    @Test fun sensitiveNearMatchesNeverAuthorizeAutomaticOutOfBankGuesses() {
        val row = rec("x", "当电压达到15 kV时，禁止在隔离区内接近设备。", listOf("允许", "禁止"), listOf(1))
        val bank = QuestionBankIndex.fromRecords(listOf(row))
        for (text in listOf(row.question.replace("15", "1.5"), row.question.replace("禁止", "允许"), row.question.take(12))) {
            val error = org.junit.Assert.assertThrows(IncompleteQuestionOptions::class.java) { bank.verifiedAnswer(ai(text, listOf("允许", "禁止"), emptyList())) }
            org.junit.Assert.assertFalse(error is BankStemNotFound)
        }
        org.junit.Assert.assertThrows(BankStemNotFound::class.java) {
            bank.verifiedAnswer(ai("哪一种乐器有黑白琴键？", listOf("钢琴", "笛子"), emptyList()))
        }
    }

    @Test fun unlabelledWrappedOptionsAreMappedToTheirOwnScreenLocations() {
        val bank = QuestionBankIndex.fromRecords(listOf(rec("a", "下列哪一种材料导电？", listOf("干燥的木材", "铜导线"), listOf(1))))
        fun n(text: String, y: Float) = VisibleQuestionReader.Node(text, NormalizedBox(8f, y, 55f, 4f))
        val lines = listOf(n("未公开控件的练习页面", 5f), n("下列哪一种", 17f), n("材料导电？", 23f),
            n("○ 铜导线", 39f), n("○ 干燥的", 51f), n("木材", 57f), n("确认答案", 80f))
        val result = bank.verifiedOcrPage(lines, 4)!!
        assertEquals(listOf(0), result.answerIndices)
        assertEquals(39f, result.options[0].box!!.y)
        assertNull(bank.verifiedOcrPage(lines.filterNot { it.text == "木材" }, 4))
    }

    @Test fun readableScreenRequiresExactStemAndCompleteUnambiguousOptions() {
        val bank = QuestionBankIndex.fromRecords(listOf(
            rec("a", "速度超过 1.5 时应选择哪一项？", listOf("甲", "乙", "丙"), listOf(1)),
            rec("b", "速度超过 1.5 时应选择哪一项？", listOf("甲", "乙", "丁"), listOf(2)),
        ))
        val stem = "速度超过 1.5 时应选择哪一项？"
        assertEquals(listOf(0), bank.answerForScreen(ai(stem, listOf("丁", "甲", "乙"), emptyList()))?.answerIndices)
        assertNull(bank.answerForScreen(ai("速度超过 15 时应选择哪一项？", listOf("丁", "甲", "乙"), emptyList())))
        assertNull(bank.answerForScreen(ai(stem, listOf("甲", "乙"), emptyList())))
        assertNull(bank.answerForScreen(ai(stem, listOf("甲", "甲", "乙"), emptyList())))
        assertNull(bank.answerForScreen(ai(stem, listOf("甲", "乙", "丙"), emptyList(), boxes = false)))
    }

    @Test fun completeScreenRowsCanBeLocatedAfterScrolling() {
        val stem = "调度命令由（ ）发布。"
        val screen = ai(stem, listOf("车站值班员", "司机", "乘务员", "列车调度员"), emptyList(), boxes = false)
        val page = screen.copy(confirmBox = null, options = screen.options.map { it.copy(screenRow = true) })
        val hit = requireNotNull(index.answerForScreen(page))
        assertEquals(listOf(3), QuizModelParser.actionPlan(hit, 1).answerOptions.map { it.index })
        assertNull(index.answerForScreen(page.copy(options = page.options.dropLast(1))))
        assertNull(index.answerForScreen(screen))
    }

    @Test fun shuffledOptionsUseBankAnswerOnScreenBox() {
        val out = index.answerForVision(ai("单选题：“禁停区”采用（ ）色带标识。", listOf("A. 红色", "B. 黑色", "C. 黄色", "D. 白色"), listOf(0)))
        assertEquals(listOf(2), out?.answerIndices); assertEquals("question_bank", out?.answerSource)
    }

    @Test fun stemTypoStillMatches() {
        val out = index.answerForVision(ai("消防装备器材的检査保养应做到“三会”和“四无”。三会是指（ ）；四无是指“无积尘、无损坏、无霉变、无缺件”。", listOf("A. 会修理", "B. 会保养", "C. 会检查", "D. 会使用"), listOf(0)))
        assertEquals(setOf(1, 2, 3), out?.answerIndices?.toSet()); assertEquals(QuestionType.MULTIPLE, out?.type)
    }

    @Test fun trueFalseSynonymsMap() {
        assertEquals(listOf(1), index.answerForVision(ai("列车日常运行时司机应将灯光调节至确保有效的瞭望距离。", listOf("A. 错", "B. 对"), listOf(0), QuestionType.TRUE_FALSE))?.answerIndices)
    }

    @Test fun noMatchKeepsAi() {
        assertNull(index.answerForVision(ai("光合作用主要发生在植物细胞的哪个结构？", listOf("叶绿体", "线粒体", "细胞核", "液泡"), listOf(0))))
    }

    @Test fun nearDuplicatesWithoutClearLeadKeepAi() {
        assertNull(index.answerForVision(ai("调车作业中，调车指挥人在作业前应当向全体作业人员传达调车作业计划。", listOf("对", "错"), listOf(0), QuestionType.TRUE_FALSE)))
    }

    @Test fun differentOptionSetKeepsAi() {
        assertNull(index.answerForVision(ai("调度命令由（ ）发布。", listOf("列车调度员", "车站值班员", "司机", "调车长"), listOf(1))))
    }

    @Test fun missingBoxKeepsAi() {
        assertNull(index.answerForVision(ai("“禁停区”采用（ ）色带标识。", listOf("黄色", "红色", "白色", "黑色"), listOf(1), boxes = false)))
    }

    @Test fun optionlessTrueFalseBankRecordMaps() {
        val bank = QuestionBankIndex.fromRecords(listOf(LocalQuestionBankRecord("b1", "任何单位或个人未经公司有关部门同意，不得随意乱拉乱接电器设备，禁止为运营生产无关的电器设备充放电", QuestionType.TRUE_FALSE, emptyList(), "对", emptyList())))
        assertEquals(listOf(0), bank.answerForVision(ai("任何单位或个人未经公司有关部门同意，不得随意乱拉乱接电器设备，禁止为运营生产无关的电器设备充放电", listOf("A. 正确", "B. 错误"), listOf(1), QuestionType.TRUE_FALSE))?.answerIndices)
    }
    @Test fun spreadsheetNumericOptionsMap() {
        val bank = QuestionBankIndex.fromRecords(listOf(rec("n1", "巡道列车手动驾驶，限速（  ）km/h运行（遇特殊情况，按调度命令运行）。", listOf("30.0", "40.0", "45.0", "60.0"), listOf(2))))
        assertEquals(listOf(2), bank.answerForVision(ai("巡道列车手动驾驶，限速（ ）km/h运行（遇特殊情况，按调度命令运行）。", listOf("A. 30", "B. 40", "C. 45", "D. 60"), listOf(3)))?.answerIndices)
    }

    @Test fun repeatedDistractorsDoNotHideUniqueAnswer() {
        val bank = QuestionBankIndex.fromRecords(listOf(rec("d1", "当主风缸压力低于6BAR时，操作（ ）缓解总风低压导致的紧急制动", listOf("所有制动缓解旁路", "所有制动缓解旁路", "逆变器紧急启动按钮", "总风低压旁路"), listOf(3))))
        assertEquals(listOf(1), bank.answerForVision(ai("当主风缸压力低于6BAR时，操作（ ）缓解总风低压导致的紧急制动", listOf("所有制动缓解旁路", "总风低压旁路", "所有制动缓解旁路", "逆变器紧急启动按钮"), listOf(0)))?.answerIndices)
    }

    @Test fun repeatedAnswerStillFallsBack() {
        val bank = QuestionBankIndex.fromRecords(listOf(rec("d2", "重复答案", listOf("甲", "甲", "乙"), listOf(0))))
        assertNull(bank.answerForVision(ai("重复答案", listOf("甲", "乙", "甲"), listOf(0))))
    }

    @Test fun spreadsheetPercentagesMapToEquivalentScreenNumbers() {
        val bank = QuestionBankIndex.fromRecords(listOf(rec("p1", "实战演练比例应不少于（ ）。", listOf("0.3", "0.5", "0.7", "0.9"), listOf(2))))
        assertEquals(listOf(3), bank.answerForVision(ai("实战演练比例应不少于（ ）。", listOf("90%", "50%", "30%", "70%"), listOf(0)))?.answerIndices)
    }

    @Test fun decimalsAndRangesMustNotCollapseToSameOption() {
        val bank = QuestionBankIndex.fromRecords(listOf(rec("n2", "数值范围", listOf("0.3", "3"), listOf(0))))
        assertNull(bank.answerForVision(ai("数值范围", listOf("0-3", "3"), listOf(0))))
    }

    @Test fun exactStemVariantsAreResolvedByScreenOptions() {
        val bank = QuestionBankIndex.fromRecords(listOf(
            rec("v1", "列车需要动车时使用（ ）", listOf("右门旁路", "左门旁路", "门关好旁路", "逃生门旁路"), listOf(3)),
            rec("v2", "列车需要动车时使用（ ）", listOf("门关好旁路", "逃生门旁路", "门零速旁路", "开关门模式"), listOf(1)),
        ), conflictQuestions = setOf("列车需要动车时使用（ ）"))
        assertEquals(listOf(0), bank.answerForVision(ai("列车需要动车时使用（ ）", listOf("逃生门旁路", "门关好旁路", "右门旁路", "左门旁路"), listOf(1)))?.answerIndices)
        assertEquals(listOf(3), bank.answerForVision(ai("列车需要动车时使用（ ）", listOf("开关门模式", "门零速旁路", "门关好旁路", "逃生门旁路"), listOf(0)))?.answerIndices)
    }

    @Test fun sameStemAndOptionsWithConflictingAnswersCannotOverrideVision() {
        val bank = QuestionBankIndex.fromRecords(listOf(
            rec("c1", "同题冲突", listOf("甲", "乙"), listOf(0)),
            rec("c2", "同题冲突", listOf("乙", "甲"), listOf(0)),
        ))
        assertNull(bank.answerForVision(ai("同题冲突", listOf("甲", "乙"), listOf(0))))
    }
}
