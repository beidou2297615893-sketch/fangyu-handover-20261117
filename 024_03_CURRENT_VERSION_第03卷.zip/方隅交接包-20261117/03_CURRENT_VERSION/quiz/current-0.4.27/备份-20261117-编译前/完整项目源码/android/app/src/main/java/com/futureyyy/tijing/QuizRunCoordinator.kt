package com.futureyyy.tijing

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

enum class RunnerPhase {
    READY,
    CAPTURING,
    RECOGNIZING,
    SHOWING_ANSWER,
    EXECUTING,
    WAITING_PAGE_CHANGE,
    PAUSED_ERROR,
    STOPPED,
}

data class RunnerSnapshot(
    val phase: RunnerPhase,
    val questionNo: Int,
    val mode: QuizMode,
    val errorMessage: String? = null,
    val attemptCount: Int = 0,
    val maxAttempts: Int = 3,
    val elapsedMs: Long = 0L,
    val matchStatus: String? = null,
    val matchLabel: String? = null,
    val answerSource: String? = null,
    val message: String? = null,
)

interface CaptureGateway {
    fun capture(callback: (Result<CaptureFrame>) -> Unit)
    fun cancel() = Unit
}

interface ModelGateway {
    fun analyze(frame: CaptureFrame, questionNo: Int, callback: (Result<String>) -> Unit)

    /** Concurrent variant: the caller owns ordering, so an in-flight request is never cancelled. */
    fun analyzeConcurrent(frame: CaptureFrame, questionNo: Int, callback: (Result<String>) -> Unit) =
        analyze(frame, questionNo, callback)

    fun cancel() = Unit
}

data class HostQuestionProgress(val current: Int, val total: Int)

data class HostQuestionPage(
    val progress: HostQuestionProgress? = null,
    val graded: Boolean = false,
    val hasNext: Boolean = false,
)

interface GestureGateway {
    fun readQuestionStem(): String? = null
    fun readQuestionPage(): HostQuestionPage = HostQuestionPage()
    fun continueGradedPage(callback: (Boolean) -> Unit) = callback(false)
    fun continueGradedPage(box: NormalizedBox?, callback: (Boolean) -> Unit) = continueGradedPage(callback)
    fun isTargetForeground(): Boolean
    fun isFinishedPage(): Boolean = false
    fun targetUnavailableMessage(): String = "请打开题目页"
    fun resetTarget() = Unit
    fun tap(option: QuizOption, callback: (Boolean) -> Unit)
    fun tapConfirm(box: NormalizedBox?, callback: (Boolean) -> Unit)
    fun cancel()
}

interface RunnerListener {
    fun onSnapshot(snapshot: RunnerSnapshot)
    fun onAnswer(result: QuizModelResult)
    fun onError(message: String)
    fun onCompleted() = Unit
}

fun interface RunnerScheduledTask {
    fun cancel()
}

fun interface RunnerScheduler {
    fun schedule(delayMs: Long, action: () -> Unit): RunnerScheduledTask

    companion object {
        val SYSTEM: RunnerScheduler = ExecutorRunnerScheduler
    }
}

private object ExecutorRunnerScheduler : RunnerScheduler {
    private val executor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "QuizRunCoordinator").apply { isDaemon = true }
    }

    override fun schedule(delayMs: Long, action: () -> Unit): RunnerScheduledTask {
        val future = executor.schedule({ action() }, delayMs, TimeUnit.MILLISECONDS)
        return RunnerScheduledTask { future.cancel(false) }
    }
}

private enum class AutoCheckpointStage {
    ANSWERS,
    CONFIRM_BASELINE,
    CONFIRM,
    PAGE_POLL,
}

internal class ReadTransportInterrupted(message:String): IllegalStateException(message)

class QuizRunCoordinator(
    private val mode: QuizMode,
    private val startingQuestionNo: Int = 1,
    private val captureGateway: CaptureGateway,
    private val modelGateway: ModelGateway,
    private val gestureGateway: GestureGateway,
    private val listener: RunnerListener,
    private val scheduler: RunnerScheduler = RunnerScheduler.SYSTEM,
    private val screenBankAnswer: (Int) -> QuizModelResult? = { null },
    private val answerResolver: (QuizModelResult) -> QuizModelResult = { it },
    private val requireBankMatch: Boolean = false,
) {
    internal data class LocalRead(val host: OcrHostPage, val question: QuizModelResult?, val verified: QuizModelResult?,
                                  val lines:List<VisibleQuestionReader.Node> = emptyList(),
                                  val independentLines:List<VisibleQuestionReader.Node> = emptyList())
    private var questionReadings: List<List<VisibleQuestionReader.Node>> = emptyList()
    internal var frameReader: ((CaptureFrame, Int, (LocalRead) -> Unit) -> Unit)? = null
    internal var bankFirstFallback = false
    internal var reserveFallback: ((Int,String) -> Boolean)? = null
    private var lastFallbackNo: Int? = null
    private var fallbackStem: String? = null
    private var lastCandidateIdentity: String? = null
    @Synchronized internal fun questionFrameSignature(): FrameSignature? = baselineSignature
    @Synchronized internal fun currentAnswer(): QuizModelResult? = latestResult
    @Synchronized internal fun startingHostProgress(): HostQuestionProgress? = initialHostProgress
    private var phase = RunnerPhase.READY
    private var questionNo = startingQuestionNo
    private var errorMessage: String? = null
    private var generation = 0L
    private var automaticRunStarted = false
    private var initialHostProgress: HostQuestionProgress? = null
    private var unnumberedBankStem: String? = null
    private var candidateStem: String? = null
    private var verifyAfterAuthorization = false
    private var usingNodeProgress = false
    private var previousNodeWasNext = false
    private var gradedPolls = 0
    private var baselineSignature: FrameSignature? = null
    private var lastManualSignature: FrameSignature? = null
    private var pendingManualSignature: FrameSignature? = null
    private var pendingActionPlan: QuizActionPlan? = null
    private var autoCheckpointStage: AutoCheckpointStage? = null
    private var nextAnswerPosition = 0
    private var confirmTapCompleted = false
    private var confirmTapAttempts = 0
    private var unchangedPageRetries = 0
    private var stableCandidate: FrameSignature? = null
    private var pollAttempts = 0
    private var questionStartedAtMs = 0L
    private var modelAttemptCount = 0
    private var latestResult: QuizModelResult? = null
    private val scheduledTasks = mutableListOf<RunnerScheduledTask>()

    init {
        require(startingQuestionNo > 0) { "startingQuestionNo 必须大于 0" }
    }

    @Synchronized
    fun onPrimaryAction() {
        if (phase != RunnerPhase.READY) return
        if (mode == QuizMode.AUTO) automaticRunStarted = true
        beginQuestion()
    }

    @Synchronized
    fun pause() {
        invalidateCurrentWork()
        cancelGestures()
        if (phase == RunnerPhase.STOPPED) return
        errorMessage = "已暂停"
        transition(RunnerPhase.PAUSED_ERROR)
    }

    @Synchronized
    fun resume() {
        restartPausedRun()
    }

    @Synchronized
    fun resumeAfterScreenAuthorization() {
        if (phase != RunnerPhase.PAUSED_ERROR) return
        if (mode == QuizMode.AUTO && pendingActionPlan != null) {
            // A gesture dispatched before revocation may already have reached the host.
            verifyAfterAuthorization = true
            autoCheckpointStage = AutoCheckpointStage.PAGE_POLL
            if (initialHostProgress == null) unnumberedBankStem = latestResult?.question?.trim().orEmpty()
        }
        restartPausedRun()
    }

    @Synchronized
    fun retry() {
        restartPausedRun()
    }

    @Synchronized
    fun stop() {
        invalidateCurrentWork()
        automaticRunStarted = false
        clearAutoCheckpoint()
        cancelGestures()
        errorMessage = null
        if (phase != RunnerPhase.STOPPED) transition(RunnerPhase.STOPPED)
    }

    @Synchronized
    fun snapshot(): RunnerSnapshot = snapshotUnsafe()

    private fun restartPausedRun() {
        if (phase != RunnerPhase.PAUSED_ERROR) return
        errorMessage = null
        transition(RunnerPhase.READY)
        if (phase != RunnerPhase.READY) return
        if (mode == QuizMode.AUTO) {
            automaticRunStarted = true
            if (pendingActionPlan != null && autoCheckpointStage != null) {
                if (autoCheckpointStage == AutoCheckpointStage.CONFIRM && !confirmTapCompleted) {
                    confirmTapAttempts = 0
                }
                resumeAutoCheckpoint()
                return
            }
        }
        beginQuestion()
    }

    private fun resumeAutoCheckpoint() {
        invalidateCurrentWork()
        val runGeneration = generation
        cancelGestures()
        if (!ensureForeground(runGeneration)) return
        when (autoCheckpointStage) {
            AutoCheckpointStage.ANSWERS,
            AutoCheckpointStage.CONFIRM_BASELINE,
            AutoCheckpointStage.CONFIRM,
            AutoCheckpointStage.PAGE_POLL,
            -> {
                if (autoCheckpointStage == AutoCheckpointStage.PAGE_POLL) {
                    if (verifyAfterAuthorization || initialHostProgress != null || unnumberedBankStem != null || gradedPolls > 0 || multipleChoice()) {
                        restartPagePolling(runGeneration)
                        return
                    }
                    nextAnswerPosition = 0
                    confirmTapCompleted = false
                    confirmTapAttempts = 0
                    unchangedPageRetries = 0
                    autoCheckpointStage = AutoCheckpointStage.ANSWERS
                }
                transition(RunnerPhase.EXECUTING)
                if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) {
                    resumePendingActions(runGeneration)
                }
            }
            null -> beginQuestion()
        }
    }

    private fun beginQuestion() {
        invalidateCurrentWork()
        val runGeneration = generation
        errorMessage = null
        baselineSignature = null
        stableCandidate = null
        pollAttempts = 0
        questionStartedAtMs = System.currentTimeMillis()
        modelAttemptCount = 0
        latestResult = null
        questionReadings = emptyList()
        lastCandidateIdentity = null
        initialHostProgress = null
        verifyAfterAuthorization = false
        unnumberedBankStem = null
        candidateStem = null
        usingNodeProgress = false
        previousNodeWasNext = false
        gradedPolls = 0
        gestureGateway.resetTarget()

        transition(RunnerPhase.CAPTURING)
        if (!isCurrent(runGeneration, RunnerPhase.CAPTURING)) return
        if (mode == QuizMode.AUTO) {
            cancelGestures()
            captureWhenForegroundReady(runGeneration)
        } else {
            requestQuestionCapture(runGeneration)
        }
    }

    @Synchronized
    private fun captureWhenForegroundReady(runGeneration: Long, retryAttempt: Int = 0) {
        if (!isCurrent(runGeneration, RunnerPhase.CAPTURING)) return
        val foreground = readTargetForeground(runGeneration) ?: return
        if (foreground) {
            val progress = gestureGateway.readQuestionPage().progress
            if (progress != null) {
                val bankAnswer = try { screenBankAnswer(questionNo) } catch (_: Exception) { null }
                if (bankAnswer != null && gestureGateway.readQuestionPage() == HostQuestionPage(progress)) {
                    initialHostProgress = progress
                    usingNodeProgress = true
                    transition(RunnerPhase.RECOGNIZING)
                    if (isCurrent(runGeneration, RunnerPhase.RECOGNIZING)) acceptAnswer(runGeneration, null, bankAnswer)
                    return
                }
            }
            requestQuestionCapture(runGeneration)
            return
        }
        if (retryAttempt >= MAX_START_FOREGROUND_RETRIES) {
            fail(runGeneration, gestureGateway.targetUnavailableMessage())
            return
        }
        val task = try {
            scheduler.schedule(START_FOREGROUND_RETRY_DELAY_MS) {
                captureWhenForegroundReady(runGeneration, retryAttempt + 1)
            }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "前台应用检查调度失败"))
            return
        }
        if (isCurrent(runGeneration, RunnerPhase.CAPTURING)) {
            scheduledTasks += task
        } else {
            task.cancel()
        }
    }

    private fun requestQuestionCapture(runGeneration: Long) {
        val delivered = AtomicBoolean(false)
        try {
            captureGateway.capture { result ->
                if (delivered.compareAndSet(false, true)) onQuestionCaptured(runGeneration, result)
            }
        } catch (error: Exception) {
            if (delivered.compareAndSet(false, true)) fail(runGeneration, errorMessage(error, "截图失败"))
        }
    }

    @Synchronized
    private fun onQuestionCaptured(runGeneration: Long, result: Result<CaptureFrame>) {
        if (!isCurrent(runGeneration, RunnerPhase.CAPTURING)) return
        val frame = result.getOrElse { error ->
            fail(runGeneration, errorMessage(error, "截图失败"))
            return
        }
        if (finishIfResultPage(runGeneration)) return
        if (mode == QuizMode.MANUAL && !prepareManualFrame(runGeneration, frame.signature)) return
        if (mode == QuizMode.AUTO) {
            initialHostProgress = gestureGateway.readQuestionPage().progress
            gradedPolls = 0
        }
        baselineSignature = frame.signature
        transition(RunnerPhase.RECOGNIZING)
        if (!isCurrent(runGeneration, RunnerPhase.RECOGNIZING)) return
        val fromScreen = if (mode == QuizMode.AUTO) {
            try { screenBankAnswer(questionNo) } catch (_: Exception) { null }
        } else null
        if (fromScreen == null && frameReader != null && mode == QuizMode.AUTO) {
            frameReader!!.invoke(frame, questionNo) { reading -> synchronized(this) {
                if (!isCurrent(runGeneration, RunnerPhase.RECOGNIZING)) return@synchronized
                if (reading.host.result) { finishSuccessfully(runGeneration); return@synchronized }
                if (reading.host.page.graded) { fail(runGeneration, "当前题目已判分，请进入下一题后点继续。"); return@synchronized }
                questionReadings = listOf(reading.lines, reading.independentLines).filter { it.isNotEmpty() }
                if (initialHostProgress == null) initialHostProgress = reading.host.page.progress
                if (reading.verified != null) acceptAnswer(runGeneration, frame.signature, reading.verified)
                else requestModel(runGeneration, frame)
            } }
        } else if (fromScreen == null) requestModel(runGeneration, frame)
        else {
            if (initialHostProgress == null) unnumberedBankStem = fromScreen.question.trim()
            acceptAnswer(runGeneration, frame.signature, fromScreen)
        }
    }

    private fun requestModel(runGeneration: Long, frame: CaptureFrame) {
        modelAttemptCount += 1
        val delivered = AtomicBoolean(false)
        try {
            modelGateway.analyze(frame, questionNo) { result ->
                if (delivered.compareAndSet(false, true)) {
                    if (result.exceptionOrNull() is ReadTransportInterrupted && bankFirstFallback && modelAttemptCount == 1) {
                        synchronized(this) {
                            if (!isCurrent(runGeneration, RunnerPhase.RECOGNIZING)) return@synchronized
                            // No answer gesture has occurred. Re-read the foreground page once;
                            // never resubmit an answer or reuse the previous image after a network interruption.
                            transition(RunnerPhase.CAPTURING)
                            captureWhenForegroundReady(runGeneration)
                        }
                    } else onModelCompleted(runGeneration, frame.signature, result)
                }
            }
        } catch (error: Exception) {
            if (delivered.compareAndSet(false, true)) fail(runGeneration, errorMessage(error, "模型识别失败"))
        }
    }

    @Synchronized
    private fun onModelCompleted(
        runGeneration: Long,
        recognizedSignature: FrameSignature,
        result: Result<String>,
    ) {
        if (!isCurrent(runGeneration, RunnerPhase.RECOGNIZING)) return
        val raw = result.getOrElse { error ->
            fail(runGeneration, errorMessage(error, "模型识别失败"))
            return
        }
        val parsed = try {
            QuizModelParser.parse(raw, readOptionsOnly = requireBankMatch).let { transcript ->
                val rows = if (bankFirstFallback) OcrHostPage.verifiedRows(questionReadings, transcript) else null
                if (bankFirstFallback && frameReader != null && rows == null) {
                    throw IncompleteQuestionOptions("本机画面与识别题干或选项未能核对。请让本题完整显示后重试。")
                }
                val ai = if (rows != null && transcript.options.all { it.index in rows.indices }) transcript.copy(options = transcript.options.map { it.copy(box = rows[it.index]) },
                    matchSource = "device_ocr", physicalRuleIndex = OcrHostPage.observedRuleIndex(questionReadings, transcript)) else transcript
                val resolved = try { answerResolver(ai) }
                catch (miss: BankStemNotFound) {
                    if (!bankFirstFallback) throw miss
                    // Only a real stem miss can use a model answer. Conflicts, unreadable choices,
                    // unavailable storage and incomplete captures are never a reason to guess.
                    val fallback = runCatching { QuizModelParser.parse(raw, tolerateModelBoxes = true) }.getOrNull()
                    val previous = lastFallbackNo
                    if (previous != null && !(previous == questionNo && fallbackStem == ai.question) && questionNo - previous < 100)
                        throw IncompleteQuestionOptions("多道题未匹配到本机题库，已暂停自动提交。请核对导入的题库或手动作答。")
                    if (fallback == null || fallback.confidence < 0.95 || fallback.answerIndices.isEmpty() ||
                        ai.options.size < 2 || ai.options.any { it.text.isBlank() || it.box == null } || ai.options.map { it.text.trim() }.distinct().size != ai.options.size)
                        throw IncompleteQuestionOptions("没有匹配的题库答案，备用答案也不够可靠，请手动作答。")
                    fallback.copy(options = ai.options, answerSource = "vision", matchStatus = null, matchSource = ai.matchSource, matchLabel = null)
                }
                catch (error: IncompleteQuestionOptions) { throw error }
                catch (_: Exception) {
                    if (requireBankMatch) throw IncompleteQuestionOptions("读取题库失败，本题尚未提交。请回到知题检查题库后重试。")
                    ai
                }
                if (requireBankMatch && resolved.answerSource != "question_bank" && !(bankFirstFallback && resolved.answerSource == "vision" && resolved !== ai)) {
                    throw IncompleteQuestionOptions("题库未能核对本题答案，本题尚未提交。请核对题干和选项后重试。")
                }
                // Local resolvers return a replacement; model-provided source labels
                // cannot turn a zero-confidence visual answer into a trusted one.
                if (mode == QuizMode.AUTO && ai.confidence == 0.0 && resolved === ai) {
                    throw IncompleteQuestionOptions("本次识别结果不确定。请检查题目画面后，再点重试。")
                }
                resolved
            }
        } catch (error: Exception) {
            if (finishIfResultPage(runGeneration)) return
            if (error is MissingQuestionOptions && mode == QuizMode.AUTO && initialHostProgress != null) {
                val expectedPage = HostQuestionPage(initialHostProgress)
                val local = runCatching {
                    if (gestureGateway.readQuestionPage() == expectedPage) screenBankAnswer(questionNo) else null
                }.getOrNull()
                if (local != null && runCatching { gestureGateway.readQuestionPage() }.getOrNull() == expectedPage) {
                    acceptAnswer(runGeneration, recognizedSignature, local)
                    return
                }
            }
            val message = if (error is MissingQuestionOptions || error is IncompleteQuestionOptions) error.message.orEmpty()
                else if (requireBankMatch) "本机未能读全本题，备用识别也没有读清题干和选项。请显示完整题目后重试。"
                else "模型未返回完整的答题结果，请检查题目画面后重试。"
            fail(runGeneration, message)
            return
        }

        acceptAnswer(runGeneration, recognizedSignature, parsed)
    }

    private fun acceptAnswer(runGeneration: Long, recognizedSignature: FrameSignature?, parsed: QuizModelResult) {
        if (mode == QuizMode.MANUAL) {
            lastManualSignature = requireNotNull(recognizedSignature)
            pendingManualSignature = null
            transition(RunnerPhase.SHOWING_ANSWER)
            notifyAnswer(parsed)
            if (isCurrent(runGeneration, RunnerPhase.SHOWING_ANSWER)) {
                transition(RunnerPhase.READY)
            }
            return
        }

        val plan = try {
            QuizModelParser.actionPlan(parsed, questionNo)
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "答案动作无效"))
            return
        }
        if (bankFirstFallback && parsed.answerSource == "vision") {
            val number = initialHostProgress?.current ?: questionNo
            if (runCatching { reserveFallback?.invoke(number, parsed.question) != false }.getOrDefault(false).not()) {
                fail(runGeneration, "本轮已用过备用答案，或无法保存本轮记录。请核对题库或手动作答。")
                return
            }
            lastFallbackNo = questionNo
            fallbackStem = parsed.question
        }
        if (frameReader != null && initialHostProgress == null) unnumberedBankStem = parsed.question.trim()
        replaceAutoCheckpoint(plan)
        transition(RunnerPhase.SHOWING_ANSWER)
        notifyAnswer(parsed)
        if (!isCurrent(runGeneration, RunnerPhase.SHOWING_ANSWER)) return
        transition(RunnerPhase.EXECUTING)
        if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) resumePendingActions(runGeneration)
    }

    private fun prepareManualFrame(runGeneration: Long, signature: FrameSignature): Boolean {
        val pending = pendingManualSignature
        if (pending != null && pending.hammingDistance(signature) <= MANUAL_SAME_PAGE_DISTANCE) {
            pendingManualSignature = signature
            return true
        }

        val previous = lastManualSignature
        if (previous != null) {
            if (previous.hammingDistance(signature) <= MANUAL_SAME_PAGE_DISTANCE) {
                fail(runGeneration, MANUAL_SAME_PAGE_MESSAGE)
                return false
            }
            questionNo += 1
        }
        pendingManualSignature = signature
        return true
    }

    private fun resumePendingActions(runGeneration: Long) {
        val plan = pendingActionPlan
            ?: run {
                fail(runGeneration, "缺少待执行答案")
                return
            }
        when (autoCheckpointStage) {
            AutoCheckpointStage.ANSWERS -> executeAnswer(runGeneration, plan)
            AutoCheckpointStage.CONFIRM_BASELINE -> captureConfirmBaseline(runGeneration, plan)
            AutoCheckpointStage.CONFIRM -> {
                if (confirmTapCompleted) {
                    beginPagePolling(runGeneration)
                } else {
                    executeConfirm(runGeneration, plan)
                }
            }

            AutoCheckpointStage.PAGE_POLL -> {
                nextAnswerPosition = 0
                confirmTapCompleted = false
                confirmTapAttempts = 0
                autoCheckpointStage = AutoCheckpointStage.ANSWERS
                executeAnswer(runGeneration, plan)
            }
            null -> fail(runGeneration, "缺少执行检查点")
        }
    }

    private fun executeAnswer(runGeneration: Long, plan: QuizActionPlan) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        if (nextAnswerPosition >= plan.answerOptions.size) {
            autoCheckpointStage = AutoCheckpointStage.CONFIRM_BASELINE
            captureConfirmBaseline(runGeneration, plan)
            return
        }
        if (!ensureForeground(runGeneration)) return
        val option = plan.answerOptions[nextAnswerPosition]
        val delivered = AtomicBoolean(false)
        try {
            gestureGateway.tap(option) { success ->
                if (delivered.compareAndSet(false, true)) {
                    onAnswerTapCompleted(runGeneration, plan, success)
                }
            }
        } catch (error: Exception) {
            if (delivered.compareAndSet(false, true)) fail(runGeneration, errorMessage(error, "点击答案失败"))
        }
    }

    @Synchronized
    private fun onAnswerTapCompleted(
        runGeneration: Long,
        plan: QuizActionPlan,
        success: Boolean,
    ) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        if (!success) {
            fail(runGeneration, "已找到答案，但无法确认选项在当前屏幕的位置。请让题目和选项完整显示后重试。")
            return
        }
        nextAnswerPosition += 1
        executeAnswer(runGeneration, plan)
    }

    private fun captureConfirmBaseline(runGeneration: Long, plan: QuizActionPlan) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        if (!ensureForeground(runGeneration)) return
        if (usingNodeProgress) {
            val host = gestureGateway.readQuestionPage()
            if (host.progress != null || host.graded) {
                autoCheckpointStage = AutoCheckpointStage.CONFIRM
                executeConfirm(runGeneration, plan, host)
                return
            }
            usingNodeProgress = false
        }
        val delivered = AtomicBoolean(false)
        try {
            captureGateway.capture { result ->
                if (delivered.compareAndSet(false, true)) {
                    onConfirmBaselineCaptured(runGeneration, plan, result)
                }
            }
        } catch (error: Exception) {
            if (delivered.compareAndSet(false, true)) {
                fail(runGeneration, errorMessage(error, "确认前截图失败"))
            }
        }
    }

    @Synchronized
    private fun onConfirmBaselineCaptured(
        runGeneration: Long,
        plan: QuizActionPlan,
        result: Result<CaptureFrame>,
    ) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        if (autoCheckpointStage != AutoCheckpointStage.CONFIRM_BASELINE) return
        val frame = result.getOrElse { error ->
            fail(runGeneration, errorMessage(error, "确认前截图失败"))
            return
        }
        baselineSignature = frame.signature
        autoCheckpointStage = AutoCheckpointStage.CONFIRM
        executeConfirm(runGeneration, plan)
    }

    private fun executeConfirm(runGeneration: Long, plan: QuizActionPlan, observedPage: HostQuestionPage? = null) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        if (!ensureForeground(runGeneration)) return
        val host = observedPage ?: gestureGateway.readQuestionPage()
        val start = initialHostProgress
        val changedNumber = start != null && host.progress != null && host.progress != start
        if (changedNumber && host.progress != HostQuestionProgress(start.current + 1, start.total)) {
            fail(runGeneration, "题号已变，请回到原题或下一题后点继续。")
            return
        }
        if (host.graded || changedNumber) {
            if (host.graded) gradedPolls = 1
            if (start != null && host.progress != null) usingNodeProgress = true
            beginPagePolling(runGeneration)
            return
        }
        if (host.progress == null && finishIfResultPage(runGeneration)) return
        confirmTapAttempts += 1
        val delivered = AtomicBoolean(false)
        try {
            gestureGateway.tapConfirm(plan.confirmBox) { success ->
                if (delivered.compareAndSet(false, true)) onConfirmTapCompleted(runGeneration, success)
            }
        } catch (error: Exception) {
            if (delivered.compareAndSet(false, true)) retryConfirm(runGeneration, plan)
        }
    }

    @Synchronized
    private fun onConfirmTapCompleted(runGeneration: Long, success: Boolean) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        if (!success) {
            retryConfirm(runGeneration, pendingActionPlan)
            return
        }
        confirmTapCompleted = true
        autoCheckpointStage = AutoCheckpointStage.PAGE_POLL
        beginPagePolling(runGeneration)
    }

    private fun retryConfirm(runGeneration: Long, plan: QuizActionPlan?) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        val pendingPlan = plan ?: run {
            fail(runGeneration, "缺少待执行答案")
            return
        }
        if (confirmTapAttempts >= MAX_CONFIRM_TAP_ATTEMPTS) {
            fail(runGeneration, "未能确认本题已提交。若仍在本题，请核对已选选项，让确认按钮显示并可点后重试。")
            return
        }
        val task = try {
            scheduler.schedule(CONFIRM_RETRY_DELAY_MS) {
                executeConfirm(runGeneration, pendingPlan)
            }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "确认重试调度失败"))
            return
        }
        if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) {
            scheduledTasks += task
        } else {
            task.cancel()
        }
    }

    private fun beginPagePolling(runGeneration: Long) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        autoCheckpointStage = AutoCheckpointStage.PAGE_POLL
        stableCandidate = null
        previousNodeWasNext = false
        pollAttempts = 0
        transition(RunnerPhase.WAITING_PAGE_CHANGE)
        if (isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) {
            schedulePoll(runGeneration, FIRST_POLL_DELAY_MS)
        }
    }

    private fun restartPagePolling(runGeneration: Long) {
        if (generation != runGeneration) return
        stableCandidate = null
        previousNodeWasNext = false
        pollAttempts = 0
        transition(RunnerPhase.WAITING_PAGE_CHANGE)
        if (isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) {
            schedulePoll(runGeneration, FIRST_POLL_DELAY_MS)
        }
    }

    private fun schedulePoll(
        runGeneration: Long,
        delayMs: Long,
        captureAttempt: Int = 1,
    ) {
        if (!isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) return
        val task = try {
            scheduler.schedule(delayMs) { runPagePoll(runGeneration, captureAttempt) }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "换页检测调度失败"))
            return
        }
        if (isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) {
            scheduledTasks += task
        } else {
            task.cancel()
        }
    }

    @Synchronized
    private fun runPagePoll(runGeneration: Long, captureAttempt: Int = 1) {
        if (!isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) return
        if (!ensureForeground(runGeneration)) return
        if (usingNodeProgress) {
            val host = gestureGateway.readQuestionPage()
            if (host.progress != null || host.graded || host.hasNext) {
                handlePagePoll(runGeneration, host, null)
                return
            }
            if (finishIfResultPage(runGeneration)) return
            // An unreadable node tree needs a real frame. Keep the original
            // numbered-question checkpoint; a changed layout alone cannot count.
            previousNodeWasNext = false
        }
        val delivered = AtomicBoolean(false)
        try {
            captureGateway.capture { result ->
                if (delivered.compareAndSet(false, true)) {
                    onPollCaptured(runGeneration, result, captureAttempt)
                }
            }
        } catch (error: Exception) {
            if (delivered.compareAndSet(false, true)) {
                onPollCaptured(runGeneration, Result.failure(error), captureAttempt)
            }
        }
    }

    @Synchronized
    private fun onPollCaptured(
        runGeneration: Long,
        result: Result<CaptureFrame>,
        captureAttempt: Int,
    ) {
        if (!isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) return
        val frame = result.getOrElse { error ->
            if (mode == QuizMode.AUTO && captureAttempt < MAX_AUTO_CAPTURE_ATTEMPTS) {
                schedulePoll(runGeneration, CAPTURE_RETRY_DELAY_MS, captureAttempt + 1)
            } else {
                fail(runGeneration, errorMessage(error, "换页截图失败"))
            }
            return
        }
        val host = gestureGateway.readQuestionPage()
        val reader = frameReader
        if (reader != null && host.progress == null && !host.graded) {
            reader.invoke(frame, questionNo) { reading -> synchronized(this) {
                if (!isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) return@synchronized
                if (reading.host.result) finishSuccessfully(runGeneration)
                else if (initialHostProgress == null && unnumberedBankStem != null && reading.verified != null && !reading.host.page.graded) {
                    val identity = listOf(reading.verified.question.trim()) + reading.verified.options.map { it.text.trim() }
                    val original = latestResult?.let { listOf(it.question.trim()) + it.options.map { o -> o.text.trim() } }
                    val changed = original != null && original != identity && reading.verified.question.trim() != unnumberedBankStem
                    val key = if (changed) identity.joinToString("\u001f") else null
                    if (key != null && lastCandidateIdentity == key) advanceAfterPageChange(runGeneration)
                    else { lastCandidateIdentity = key; handlePagePoll(runGeneration, reading.host.page, frame.signature, unnumberedBankStem, reading.host.nextBox) }
                } else handlePagePoll(runGeneration, reading.host.page, frame.signature, reading.verified?.question ?: (if (gradedPolls > 0) reading.question?.question ?: reading.host.stem else null), reading.host.nextBox)
            } }
        } else handlePagePoll(runGeneration, host, frame.signature)
    }

    private fun handlePagePoll(runGeneration: Long, host: HostQuestionPage, signature: FrameSignature?, frameStem: String? = null, nextBox: NormalizedBox? = null) {
        pollAttempts += 1
        val start = initialHostProgress
        if (verifyAfterAuthorization && (host.graded || host.hasNext)) {
            fail(runGeneration, "当前题目已判分，请手动进入下一题后点继续。")
            return
        }
        if (host.graded || (gradedPolls > 0 && host.hasNext && (host.progress == start || host.progress == null))) {
            stableCandidate = null
            previousNodeWasNext = false
            if (++gradedPolls > MAX_POLL_ATTEMPTS) {
                fail(runGeneration, "已提交答案，未能进入下一题")
                return
            }
            gestureGateway.continueGradedPage(nextBox) {
                synchronized(this) {
                    if (isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) {
                        schedulePoll(runGeneration, FIRST_POLL_DELAY_MS)
                    }
                }
            }
            return
        }
        if ((start != null || unnumberedBankStem != null) && host.progress == null && finishIfResultPage(runGeneration)) return
        val currentStem = if (unnumberedBankStem != null) {
            frameStem?.trim() ?: runCatching { gestureGateway.readQuestionStem()?.trim() }.getOrNull()
        } else null
        val changedEnough = if (start != null) {
            host.progress == HostQuestionProgress(start.current + 1, start.total)
        } else {
            (unnumberedBankStem == null || (!unnumberedBankStem.isNullOrEmpty() && !currentStem.isNullOrEmpty() && currentStem != unnumberedBankStem)) &&
                signature != null && (baselineSignature?.hammingDistance(signature) ?: 0) >= PAGE_CHANGE_DISTANCE
        }
        if (signature == null || (start != null && host.progress != null)) {
            if (changedEnough && previousNodeWasNext) {
                advanceAfterPageChange(runGeneration)
                return
            }
            previousNodeWasNext = changedEnough
        } else if (changedEnough) {
            val previous = stableCandidate
            if (previous != null && candidateStem == currentStem && previous.hammingDistance(signature) <= STABLE_FRAME_DISTANCE) {
                advanceAfterPageChange(runGeneration)
                return
            }
            stableCandidate = signature
            candidateStem = currentStem
        } else {
            stableCandidate = null
        }

        if (pollAttempts >= MAX_POLL_ATTEMPTS) {
            if (verifyAfterAuthorization) {
                fail(runGeneration, "录屏已恢复，请手动完成当前题并进入下一题，再点继续。")
                return
            }
            if (unnumberedBankStem != null) {
                fail(runGeneration, "已提交，尚未确认换题。请切到下一题后点继续。")
                return
            }
            if (gradedPolls > 0 || (start != null && host.progress != start) ||
                !retryConfirmAfterUnchangedPage(runGeneration)
            ) {
                fail(runGeneration, "页面长时间未变化")
            }
        } else {
            schedulePoll(runGeneration, SUBSEQUENT_POLL_DELAY_MS)
        }
    }

    private fun multipleChoice() =
        latestResult?.type == QuestionType.MULTIPLE || latestResult?.type == QuestionType.INDEFINITE

    private fun retryConfirmAfterUnchangedPage(runGeneration: Long): Boolean {
        if (mode != QuizMode.AUTO) return false
        val plan = pendingActionPlan ?: return false

        // dispatchGesture completing only means the stroke was delivered, not that the
        // option was selected. Re-tap answers, then confirm, instead of a disabled button.
        if (unchangedPageRetries >= MAX_UNCHANGED_PAGE_RETRIES) return false
        unchangedPageRetries += 1
        // Replaying a checked multi-select row toggles it off.
        nextAnswerPosition = if (multipleChoice()) plan.answerOptions.size else 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
        autoCheckpointStage = AutoCheckpointStage.ANSWERS
        stableCandidate = null
        pollAttempts = 0
        transition(RunnerPhase.EXECUTING)
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return true
        retryAnswers(runGeneration, plan)
        return true
    }

    private fun retryAnswers(runGeneration: Long, plan: QuizActionPlan) {
        if (!isCurrent(runGeneration, RunnerPhase.EXECUTING)) return
        val task = try {
            scheduler.schedule(CONFIRM_RETRY_DELAY_MS) {
                executeAnswer(runGeneration, plan)
            }
        } catch (error: Exception) {
            fail(runGeneration, errorMessage(error, "答案重试调度失败"))
            return
        }
        if (isCurrent(runGeneration, RunnerPhase.EXECUTING)) {
            scheduledTasks += task
        } else {
            task.cancel()
        }
    }

    private fun advanceAfterPageChange(runGeneration: Long) {
        if (!isCurrent(runGeneration, RunnerPhase.WAITING_PAGE_CHANGE)) return
        clearAutoCheckpoint()
        questionNo += 1
        transition(RunnerPhase.READY)
        if (
            mode == QuizMode.AUTO && automaticRunStarted &&
            isCurrent(runGeneration, RunnerPhase.READY)
        ) {
            if (finishIfResultPage(runGeneration)) return
            beginQuestion()
        }
    }

    private fun replaceAutoCheckpoint(plan: QuizActionPlan) {
        pendingActionPlan = plan
        autoCheckpointStage = AutoCheckpointStage.ANSWERS
        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
        unchangedPageRetries = 0
    }

    private fun clearAutoCheckpoint() {
        pendingActionPlan = null
        autoCheckpointStage = null
        nextAnswerPosition = 0
        confirmTapCompleted = false
        confirmTapAttempts = 0
        unchangedPageRetries = 0
    }

    private fun ensureForeground(runGeneration: Long): Boolean {
        if (mode != QuizMode.AUTO) return true
        val foreground = readTargetForeground(runGeneration) ?: return false
        if (!foreground) fail(runGeneration, gestureGateway.targetUnavailableMessage())
        return foreground
    }

    private fun readTargetForeground(runGeneration: Long): Boolean? = try {
        gestureGateway.isTargetForeground()
    } catch (error: Exception) {
        fail(runGeneration, errorMessage(error, "前台应用检查失败"))
        null
    }

    private fun finishIfResultPage(runGeneration: Long): Boolean {
        if (mode != QuizMode.AUTO) return false
        if (generation != runGeneration || phase == RunnerPhase.STOPPED) return false
        val finished = try {
            gestureGateway.isFinishedPage()
        } catch (_: Exception) {
            false
        }
        if (!finished) return false
        finishSuccessfully(runGeneration)
        return true
    }

    private fun finishSuccessfully(runGeneration: Long) {
        if (generation != runGeneration || phase == RunnerPhase.STOPPED) return
        invalidateCurrentWork()
        automaticRunStarted = false
        clearAutoCheckpoint()
        cancelGestures()
        errorMessage = null
        if (phase != RunnerPhase.STOPPED) transition(RunnerPhase.STOPPED)
        try { listener.onCompleted() } catch (_: Exception) { /* retain completed coordinator state */ }
    }

    private fun fail(runGeneration: Long, message: String) {
        if (generation != runGeneration || phase == RunnerPhase.STOPPED) return
        invalidateCurrentWork()
        if (mode == QuizMode.AUTO) cancelGestures()
        errorMessage = message
        transition(RunnerPhase.PAUSED_ERROR)
        try {
            listener.onError(message)
        } catch (_: Exception) {
            // Listener failures do not resume or advance the run.
        }
    }

    private fun invalidateCurrentWork() {
        generation += 1
        try {
            captureGateway.cancel()
        } catch (_: Exception) {
            // Generation checks still make a late capture callback inert.
        }
        try {
            modelGateway.cancel()
        } catch (_: Exception) {
            // Generation checks still make a late model callback inert.
        }
        scheduledTasks.forEach { task ->
            try {
                task.cancel()
            } catch (_: Exception) {
                // Generation checks still make already-dispatched tasks inert.
            }
        }
        scheduledTasks.clear()
    }

    private fun cancelGestures() {
        try {
            gestureGateway.cancel()
        } catch (_: Exception) {
            // State invalidation prevents late gesture callbacks from advancing.
        }
    }

    private fun transition(next: RunnerPhase) {
        phase = next
        val snapshot = snapshotUnsafe()
        try {
            listener.onSnapshot(snapshot)
        } catch (_: Exception) {
            // UI listeners are observers and do not own state progression.
        }
    }

    private fun notifyAnswer(result: QuizModelResult) {
        latestResult = result
        try {
            listener.onAnswer(result)
        } catch (_: Exception) {
            // UI listeners are observers and do not own state progression.
        }
    }

    private fun isCurrent(runGeneration: Long, expectedPhase: RunnerPhase): Boolean =
        generation == runGeneration && phase == expectedPhase

    private fun snapshotUnsafe() = RunnerSnapshot(
        phase = phase,
        questionNo = questionNo,
        mode = mode,
        errorMessage = errorMessage,
        attemptCount = modelAttemptCount,
        maxAttempts = MAX_AUTO_CAPTURE_ATTEMPTS,
        elapsedMs = if (questionStartedAtMs == 0L) 0L
        else (System.currentTimeMillis() - questionStartedAtMs).coerceAtLeast(0L),
        matchStatus = latestResult?.matchStatus,
        matchLabel = latestResult?.matchLabel,
        answerSource = latestResult?.answerSource,
        message = when (phase) {
            RunnerPhase.CAPTURING -> "正在截图"
            RunnerPhase.RECOGNIZING -> "正在识别"
            RunnerPhase.SHOWING_ANSWER -> "已得到最终选项"
            RunnerPhase.EXECUTING -> "正在执行答案"
            RunnerPhase.WAITING_PAGE_CHANGE -> "等待进入下一题"
            RunnerPhase.PAUSED_ERROR -> errorMessage
            else -> null
        },
    )

    private fun errorMessage(error: Throwable, fallback: String): String =
        error.message?.takeIf { it.isNotBlank() } ?: fallback

    companion object {
        const val FIRST_POLL_DELAY_MS = 650L
        const val SUBSEQUENT_POLL_DELAY_MS = 450L
        const val CAPTURE_RETRY_DELAY_MS = 500L
        const val START_FOREGROUND_RETRY_DELAY_MS = 250L
        const val MAX_START_FOREGROUND_RETRIES = 4
        const val CONFIRM_RETRY_DELAY_MS = 350L
        const val MAX_CONFIRM_TAP_ATTEMPTS = 3
        const val MAX_UNCHANGED_PAGE_RETRIES = 2
        const val MAX_AUTO_CAPTURE_ATTEMPTS = 3
        const val MAX_POLL_ATTEMPTS = 12
        const val PAGE_CHANGE_DISTANCE = 18
        const val STABLE_FRAME_DISTANCE = 8
        const val MANUAL_SAME_PAGE_DISTANCE = 8
        const val MANUAL_SAME_PAGE_MESSAGE = "页面似乎未进入下一题，请确认后重试"
    }
}
