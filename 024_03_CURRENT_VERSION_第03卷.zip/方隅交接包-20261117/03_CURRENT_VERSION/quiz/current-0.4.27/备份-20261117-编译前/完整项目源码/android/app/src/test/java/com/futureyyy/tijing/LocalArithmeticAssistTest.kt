package com.futureyyy.tijing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LocalArithmeticAssistTest {
    private fun ai(
        q: String,
        opts: List<String>,
        ans: List<Int>,
        type: QuestionType = QuestionType.SINGLE,
        boxes: Boolean = true,
    ) = QuizModelResult(
        1,
        type,
        q,
        opts.mapIndexed { i, t -> QuizOption(i, t, if (boxes) NormalizedBox(5f, 20f + i * 8f, 90f, 6f) else null) },
        ans,
        NormalizedBox(20f, 85f, 60f, 6f),
        null,
        0.9,
        answerSource = "vision",
    )

    @Test
    fun singleMultiplicationOverridesPartialAi() {
        val out = LocalArithmeticAssist.answerForVision(
            ai("18 乘以 4 的结果是多少？", listOf("A. 72", "B. 73", "C. 90", "D. 71"), listOf(2)),
        )
        assertEquals(listOf(0), out?.answerIndices)
        assertEquals("local_arithmetic", out?.answerSource)
    }

    @Test
    fun integerMultiplesSelectAllMatches() {
        val out = LocalArithmeticAssist.answerForVision(
            ai("下列数中，哪些是 217 的整数倍？", listOf("434", "651", "435", "652"), listOf(0), QuestionType.SINGLE),
        )
        assertEquals(listOf(0, 1), out?.answerIndices)
        assertEquals(QuestionType.MULTIPLE, out?.type)
    }

    @Test
    fun evenNumberMapsTrueFalseOptions() {
        val out = LocalArithmeticAssist.answerForVision(
            ai("1178 是偶数。", listOf("A. 正确", "B. 错误"), listOf(1), QuestionType.TRUE_FALSE),
        )
        assertEquals(listOf(0), out?.answerIndices)
        val odd = LocalArithmeticAssist.answerForVision(
            ai("1169 是偶数。", listOf("正确", "错误"), listOf(0), QuestionType.TRUE_FALSE),
        )
        assertEquals(listOf(1), odd?.answerIndices)
    }

    @Test
    fun missingOptionBoxKeepsAi() {
        assertNull(
            LocalArithmeticAssist.answerForVision(
                ai("18 乘以 4 的结果是多少？", listOf("72", "73", "90", "71"), listOf(2), boxes = false),
            ),
        )
    }

    @Test
    fun unmatchedOptionsKeepAi() {
        assertNull(
            LocalArithmeticAssist.answerForVision(
                ai("18 乘以 4 的结果是多少？", listOf("70", "71", "73", "74"), listOf(1)),
            ),
        )
    }
}
