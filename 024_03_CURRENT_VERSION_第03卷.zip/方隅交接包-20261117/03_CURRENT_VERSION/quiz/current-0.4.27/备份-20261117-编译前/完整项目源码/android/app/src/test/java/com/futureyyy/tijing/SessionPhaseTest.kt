package com.futureyyy.tijing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SessionPhaseTest {
    @Test fun preparedCoordinatorIsNotRunning() {
        assertEquals(
            SessionPhase.READY,
            SessionPhase.describe(
                recoveryActive = false,
                configReady = true,
                coordinatorReady = true,
                sweepActive = false,
                runnerStarted = false,
            ),
        )
    }

    @Test fun runnerOrSweepIsRunning() {
        assertEquals(
            SessionPhase.RUNNING,
            SessionPhase.describe(false, true, true, false, true),
        )
        assertEquals(
            SessionPhase.RUNNING,
            SessionPhase.describe(false, true, false, true, false),
        )
    }

    @Test fun recoveryOutranksPreparedAndRunning() {
        assertEquals(
            SessionPhase.RECOVERING,
            SessionPhase.describe(true, true, true, false, true),
        )
        assertEquals(
            SessionPhase.RECOVERING,
            SessionPhase.describe(true, true, true, false, false),
        )
    }

    @Test fun missingConfigOrStaleRunnerIsIdle() {
        assertEquals(SessionPhase.IDLE, SessionPhase.describe(false, false, false, false, false))
        assertEquals(SessionPhase.IDLE, SessionPhase.describe(true, false, false, false, true))
        assertEquals(SessionPhase.IDLE, SessionPhase.describe(false, true, false, false, true))
    }

    @Test fun publisherSkipsDuplicatesAndKeepsOrder() {
        val publisher = SessionPhasePublisher()
        assertEquals(SessionPhase.READY, publisher.publish(SessionPhase.READY))
        assertNull(publisher.publish(SessionPhase.READY))
        assertEquals(
            listOf(SessionPhase.RUNNING, SessionPhase.RECOVERING, SessionPhase.RUNNING, SessionPhase.IDLE),
            listOf(
                publisher.publish(SessionPhase.RUNNING),
                publisher.publish(SessionPhase.RECOVERING),
                publisher.publish(SessionPhase.RUNNING),
                publisher.publish(SessionPhase.IDLE),
            ),
        )
        assertNull(publisher.publish(SessionPhase.IDLE))
    }
}
