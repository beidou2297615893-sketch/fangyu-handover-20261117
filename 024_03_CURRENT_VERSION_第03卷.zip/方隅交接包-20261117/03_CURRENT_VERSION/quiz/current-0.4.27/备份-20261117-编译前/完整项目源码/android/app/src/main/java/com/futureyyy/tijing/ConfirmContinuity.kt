package com.futureyyy.tijing

/** For revealing a control after option selection only. These anchors never choose an answer. */
internal object ConfirmContinuity {
    private fun key(s:String) = simpleSpelling(OcrHostPage.compact(s)).filter { it.isLetterOrDigit() }
    fun anchors(lines:List<VisibleQuestionReader.Node>, options:List<QuizOption>):Map<Int,Float> {
        val words = options.map { key(it.text) }
        val found = mutableMapOf<Int,Float>()
        for (line in lines) {
            val y = line.box?.centerY ?: continue
            val text = key(line.text)
            if (text.length < 8) continue
            val owners = words.indices.filter { idx -> text.windowed(8).any { it in words[idx] } }
            if (owners.size == 1) found.merge(owners.single(), y, ::maxOf)
        }
        return if (found.toSortedMap().values.zipWithNext().all { (a,b) -> b > a }) found else emptyMap()
    }

    fun followedScroll(before:Map<Int,Float>?, after:Map<Int,Float>):Boolean {
        if (before == null) return false
        val shifts = before.mapNotNull { (i,y) -> after[i]?.let { y - it } }
        return shifts.size >= 3 && shifts.all { it >= 1f } && shifts.maxOrNull()!! - shifts.minOrNull()!! <= 7f
    }
}
