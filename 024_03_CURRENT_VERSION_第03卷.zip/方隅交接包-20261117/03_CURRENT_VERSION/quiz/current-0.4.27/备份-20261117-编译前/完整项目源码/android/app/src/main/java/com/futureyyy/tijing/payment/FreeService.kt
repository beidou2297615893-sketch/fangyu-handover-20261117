package com.futureyyy.tijing.payment

import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

internal object FreeDeviceDigest {
    fun derive(raw:String?):String {
        if(raw==null || !raw.matches(Regex("[0-9a-fA-F]{1,16}")))reject("DEVICE_UNAVAILABLE","设备身份无法确认。")
        val id=raw.lowercase(Locale.ROOT).padStart(16,'0')
        if(id=="0000000000000000")reject("DEVICE_UNAVAILABLE","设备身份无法确认。")
        return MessageDigest.getInstance("SHA-256").digest(("dailyhundred-free-device-v1\u0000"+id).toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
    }
}
internal class FreeService(private val transport:BillingTransport,private val identity:BillingIdentity,private val digest:String) {
    fun migrate(entries:Map<String,String>) {
        if(entries.size>3 || entries.any { !ID.matches(it.key) || it.value !in setOf("used","reserved") })reject("FREE_MIGRATION_REQUIRED","既有免费使用记录需要核对。")
        val values=JSONObject();entries.forEach { (id,state)->values.put(id,state) }
        val r=transport.request("/free/migrate","POST",JSONObject().put("deviceDigest",digest).put("legacyEntries",values),identity)
        fun count(k:String):Int { val n=r.opt(k);if(n !is Int || n !in 0..3)reject("FREE_UNCONFIRMED","免费使用状态无法确认。");return n }
        if(count("used")+count("reserved")+count("remaining")!=3)reject("FREE_UNCONFIRMED","免费使用状态无法确认。")
    }
    fun action(op:String,id:String,binding:String) {
        val expected=mapOf("reserve" to "reserved","confirm" to "confirmed","resume" to "authorized","cancel" to "cancelled")[op] ?: error("invalid operation")
        val result=transport.request("/free/$op","POST",JSONObject().put("deviceDigest",digest).put("runId",id).put("taskBinding",binding),identity)
        if(result.optString("ownerId")!=identity.owner || result.optString("runId")!=id || result.optString("taskBinding")!=binding || result.optString("source")!="free" || result.optString("status")!=expected)reject("FREE_UNCONFIRMED","免费使用状态无法确认。")
    }
}
internal class TrialService(private val transport:BillingTransport,private val identity:BillingIdentity,private val digest:String) {
    private fun number(value:Any?):Long? = when(value){is Int->value.toLong();is Long->value;else->null}
    fun activate():JSONObject {
        val result=transport.request("/trial/activate","POST",JSONObject().put("deviceDigest",digest),identity)
        if(result.opt("eligible") !is Boolean || result.opt("active") !is Boolean || number(result.opt("serverNow"))==null)reject("TRIAL_UNCONFIRMED","试用状态无法确认。")
        if(result.getBoolean("eligible") && result.getBoolean("active")) {
            val expires=number(result.opt("expiresAt")) ?: reject("TRIAL_UNCONFIRMED","试用状态无法确认。")
            val serverNow=number(result.opt("serverNow")) ?: reject("TRIAL_UNCONFIRMED","试用状态无法确认。")
            if(expires<=serverNow)reject("TRIAL_UNCONFIRMED","试用状态无法确认。")
        }
        return result
    }
    fun action(op:String,id:String,binding:String) {
        val expected=mapOf("reserve" to "reserved","confirm" to "confirmed","resume" to "authorized","cancel" to "cancelled")[op] ?: error("invalid operation")
        val result=transport.request("/trial/$op","POST",JSONObject().put("deviceDigest",digest).put("runId",id).put("taskBinding",binding),identity)
        if(result.optString("ownerId")!=identity.owner || result.optString("runId")!=id || result.optString("taskBinding")!=binding || result.optString("source")!="trial" || result.optString("status")!=expected)reject("TRIAL_UNCONFIRMED","试用授权无法确认。")
    }
}
