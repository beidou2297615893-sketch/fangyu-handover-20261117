package com.futureyyy.tijing

import com.google.gson.JsonParser
import org.junit.Assert.assertEquals
import org.junit.Test

class TableBankImportTest {
    private fun questions(name: String, bytes: ByteArray) =
        JsonParser.parseString(TableBankImport.toBankJson(name, bytes)).asJsonObject.getAsJsonArray("questions").map { it.asJsonObject }

    private fun fixture(name: String) = javaClass.classLoader!!.getResourceAsStream(name)!!.readBytes()

    private fun assertTiny(name: String) {
        val q = questions(name, fixture(name))
        assertEquals(4, q.size)
        assertEquals("[0]", q[0].getAsJsonArray("answer_indices").toString())
        assertEquals("黄色", q[0].getAsJsonArray("options")[0].asJsonObject.get("text").asString)
        assertEquals("[0,1,3]", q[1].getAsJsonArray("answer_indices").toString())
        assertEquals("对", q[2].get("answer_text").asString)
        assertEquals("3", q[3].getAsJsonArray("options")[2].asJsonObject.get("text").asString)
    }

    @Test fun xlsxWithOptionNumberHeaders() = assertTiny("tiny.xlsx")

    @Test fun legacyXls() = assertTiny("tiny.xls")

    @Test fun csvGbkAndTabText() {
        val csv = "题干,选项A,选项B,答案\n\"甲,乙\",对,错,B\n".toByteArray(charset("GB18030"))
        assertEquals("甲,乙", questions("a.csv", csv).single().get("question").asString)
        val txt = "题目\t选项1\t选项2\t正确答案\n一加一\t1\t2\tB\n".toByteArray()
        assertEquals("[1]", questions("a.txt", txt).single().getAsJsonArray("answer_indices").toString())
    }

    @Test fun sameStemOptionVariantsArePreservedForScreenMapping() {
        val csv = "题干,选项A,选项B,答案\n相同题干,甲,乙,A\n相同题干,丙,甲,B\n".toByteArray()
        val q = questions("variants.csv", csv)
        assertEquals(2, q.size)
        assertEquals("[0]", q[0].getAsJsonArray("answer_indices").toString())
        assertEquals("[1]", q[1].getAsJsonArray("answer_indices").toString())
    }
}
