# 屏幕恢复期间拦截普通启动

ChatGPT [Grok 17] 裁决：通过，冻结本项修改。这是代码审查通过，不是实机验收。

检查当时 phase 已经非空的普通启动会被 Activity 拒绝。Activity 检查之后才进入恢复的窗口，仍由 ScreenCaptureService.onStartCommand 的原有返回处理。没有新增请求回执。

## ScreenCaptureService.kt

在 isCaptureReady() 与 isSessionRunning() 之间增加：

```kotlin
fun isProjectionRecoveryActive(): Boolean = projectionRecovery.phase != null
```

## MainActivity.kt

continuePendingFloatingSession：待启动配置和进行中检查之后、权限申请之前：

```kotlin
if (ScreenCaptureService.instance?.isProjectionRecoveryActive() == true) {
    cancelPendingFloatingSession("请先恢复本次屏幕共享，或关闭浮窗")
    return
}
```

REQUEST_FLOATING_CAPTURE：用户取消处理之后、startSession 之前：

```kotlin
if (ScreenCaptureService.instance?.isProjectionRecoveryActive() == true) {
    // 这份普通授权不保存，也不改成恢复请求。
    cancelPendingFloatingSession("请先恢复本次屏幕共享，或关闭浮窗")
    return
}
```

cancelPendingFloatingSession 不调用 ScreenCaptureService.stop()，也不清除 ProjectionRecovery。

## 测试

2026-11-15 04:18:16，subst W: 上 testProdReleaseUnitTest：27 个 XML，183 个测试，0 失败，0 错误，0 跳过。
ProjectionRecoveryTest 3 个通过，只覆盖状态机。没有设备。
