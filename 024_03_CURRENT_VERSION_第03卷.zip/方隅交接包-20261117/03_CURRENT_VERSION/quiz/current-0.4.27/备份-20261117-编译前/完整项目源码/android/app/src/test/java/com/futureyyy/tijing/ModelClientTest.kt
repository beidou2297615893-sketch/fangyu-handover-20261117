package com.futureyyy.tijing

import java.net.InetAddress
import java.net.ServerSocket
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelClientTest {
    @Test
    fun rateLimitDoesNotReplaySubmittedImageAndEmptyProviderResponseCannotSucceed() {
        val calls = AtomicInteger()
        ServerSocket(0, 8, InetAddress.getByName("127.0.0.1")).use { server ->
            val fixture = thread(isDaemon = true, name = "model-http-fixture") {
                repeat(2) {
                    server.accept().use { socket ->
                        socket.soTimeout = 5000
                        val reader = socket.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                        var remaining = 0
                        while (true) {
                            val line = reader.readLine() ?: error("Request ended before HTTP headers")
                            if (line.isEmpty()) break
                            if (line.substringBefore(':').equals("Content-Length", ignoreCase = true)) {
                                remaining = line.substringAfter(':').trim().toInt()
                            }
                        }
                        val buffer = CharArray(2048)
                        while (remaining > 0) {
                            val count = reader.read(buffer, 0, minOf(remaining, buffer.size))
                            check(count > 0)
                            remaining -= count
                        }
                        val first = calls.incrementAndGet() == 1
                        val status = if (first) "429 Too Many Requests" else "200 OK"
                        val body = if (first) """{"error":"rate limit"}""" else """{"choices":[]}"""
                        socket.getOutputStream().bufferedWriter(Charsets.US_ASCII).use { writer ->
                            writer.write("HTTP/1.1 $status\r\nContent-Length: " + body.length +
                                "\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n" + body)
                        }
                    }
                }
            }
            val payload = JSONObject().put("endpoint", "http://127.0.0.1:" + server.localPort)
                .put("apiKey", "local-fixture").put("retryCount", 2).toString()
            fun failure(check: Boolean): String {
                val message = CompletableFuture<String>()
                ModelClient.requestAsync(payload, connectionCheck = check) { result ->
                    message.complete(result.exceptionOrNull()?.message.orEmpty())
                }
                return message.get(5, TimeUnit.SECONDS)
            }
            assertTrue(failure(false).contains("429"))
            assertEquals(1, calls.get())
            assertTrue(failure(true).contains("未返回识别内容"))
            assertEquals(2, calls.get())
            fixture.join(5000)
        }
    }
}