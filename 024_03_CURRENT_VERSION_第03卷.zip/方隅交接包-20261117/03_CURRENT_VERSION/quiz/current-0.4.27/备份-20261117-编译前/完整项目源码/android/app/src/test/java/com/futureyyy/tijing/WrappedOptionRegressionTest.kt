package com.futureyyy.tijing

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

/** A real railway screenshot whose B marker was centered on the second text line. */
class WrappedOptionRegressionTest {
    private val fixture = JsonParser.parseString(javaClass.getResourceAsStream("/regression/wrapped-option.json")!!
        .bufferedReader(Charsets.UTF_8).use { it.readText() }).asJsonObject
    private val recordJson = fixture.getAsJsonObject("record")
    private val options = recordJson.getAsJsonArray("options").map {
        QuizOption(it.asJsonObject.get("index").asInt, it.asJsonObject.get("text").asString, null)
    }
    private val stem = recordJson.get("question").asString
    private val answer = recordJson.getAsJsonArray("answer_indices").map { it.asInt }
    private val bank = QuestionBankIndex.fromRecords(listOf(LocalQuestionBankRecord("recorded", stem,
        QuestionType.SINGLE, answer, options = options)))
    private val lines = fixture.getAsJsonArray("lines").map {
        val obj = it.asJsonObject;val box = obj.getAsJsonObject("box")
        VisibleQuestionReader.Node(obj.get("text").asString, NormalizedBox(box.get("x").asFloat,
            box.get("y").asFloat, box.get("width").asFloat, box.get("height").asFloat))
    }

    @Test fun centeredMarkerDoesNotSplitOneWrappedOptionIntoTwoChoices() {
        val rows = OcrHostPage.optionRows(lines, options)
        assertNotNull("Complete visible B text must form one row", rows)
        val firstBodyLine = lines.single { it.text.startsWith("接触网电连接线下垂") }
        assertEquals(firstBodyLine.box, rows!![1])
        val resolved = bank.verifiedOcrPage(lines, 11)
        assertNotNull("The local bank must match this complete on-screen question", resolved)
        assertEquals(answer, resolved!!.answerIndices)
        assertEquals("question_bank", resolved.answerSource)
    }

    @Test fun aDifferentMarkerCannotBeSilentlyMergedIntoThePreviousOption() {
        val changed = lines.map { if (it.text.startsWith("B. 网冲突")) it.copy(text = it.text.replaceFirst("B.", "C.")) else it }
        assertNull(OcrHostPage.optionRows(changed, options))
        assertNull(bank.verifiedOcrPage(changed, 11))
    }

    @Test fun aMissingContinuationCannotBeFilledFromTheBank() {
        val incomplete = lines.filterNot { it.text == "灼伤" }
        assertNull(OcrHostPage.optionRows(incomplete, options))
        assertNull(bank.verifiedOcrPage(incomplete, 11))
    }
}
