package com.futureyyy.tijing

import android.graphics.Rect

/**
 * Decides whether a confirmation / next-question control is actually tappable.
 * A sliver left at the very bottom of a long page is treated as not usable,
 * so the runner can scroll the target page and try again.
 */
internal object ConfirmReveal {
    const val MIN_VISIBLE_HEIGHT = 24
    const val MAX_SCROLLS = 3
    const val SCROLL_DELAY_MS = 700L
    const val NAV_RESERVE_PX = 24

    fun deepestMatches(parents: List<Int>, matching: List<Int>): List<Int> {
        val ancestors = mutableSetOf<Int>()
        for (index in matching) {
            var parent = parents[index]
            while (parent >= 0 && ancestors.add(parent)) parent = parents[parent]
        }
        return matching.filterNot(ancestors::contains)
    }

    fun isUsable(
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
        screenHeight: Int,
        navReserve: Int = NAV_RESERVE_PX,
    ): Boolean {
        if (screenHeight <= 0) return false
        val width = right - left
        val height = bottom - top
        if (width <= 0 || height <= 0) return false
        if (height < MIN_VISIBLE_HEIGHT) return false
        val centerY = top + height / 2f
        val minCenter = MIN_VISIBLE_HEIGHT / 2f
        if (centerY < minCenter) return false
        if (centerY > screenHeight - navReserve - minCenter) return false
        return true
    }

    fun isUsable(bounds: Rect, screenHeight: Int, navReserve: Int = NAV_RESERVE_PX): Boolean {
        return isUsable(bounds.left, bounds.top, bounds.right, bounds.bottom, screenHeight, navReserve)
    }
}
