package com.futureyyy.tijing
import java.io.DataInputStream
import java.util.zip.GZIPInputStream
import org.junit.Test
import org.junit.Assert.*

class LabelledStrokeRegressionTest {
    private val input=DataInputStream(GZIPInputStream(javaClass.getResourceAsStream("/regression/contrast-048.argb.gz")!!))
    private val width=input.readInt();private val height=input.readInt()
    private val pixels=IntArray(width*height){input.readInt()}.also{input.close()}
    private val card=ShortChoiceCards.locate(width,height,pixels).first()
    private fun rule(p:IntArray=pixels,text:String="A.—"):ShortChoiceCards.Rect? {
        val method=ShortChoiceCards::class.java.declaredMethods.singleOrNull{it.name=="labelledRule"}?:return null
        return method.invoke(ShortChoiceCards,width,height,p,card,text) as? ShortChoiceCards.Rect
    }
    @Test fun actualLabelledSingleStrokeCanCorroborateChineseOne() {
        assertTrue(OcrHostPage.isRuleOption("A.一",0))
        val stroke=rule();assertNotNull(stroke)
        assertTrue(stroke!!.w>=10*stroke.h)
        assertTrue(stroke.left>card.text.left && stroke.right<=card.text.right)
    }
    @Test fun aDisjointDashCannotBeFilledAsOneContinuousStroke() {
        val stroke=rule();assertNotNull(stroke)
        val changed=pixels.clone();val x=(stroke!!.left+stroke.right)/2
        for(y in stroke.top until stroke.bottom)changed[y*width+x]=0xffffffff.toInt()
        assertNull(rule(changed))
    }
    @Test fun numericTextCannotBeDiscardedEvenWhenTheSamePixelsContainAStroke() {
        assertNull(rule(text="A.1"))
        assertNull(rule(text="A.-5"))
    }
}
