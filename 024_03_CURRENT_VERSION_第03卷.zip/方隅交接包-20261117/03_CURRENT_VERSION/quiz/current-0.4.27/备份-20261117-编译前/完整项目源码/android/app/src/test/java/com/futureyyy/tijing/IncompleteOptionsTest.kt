package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class IncompleteOptionsTest {
    // Actual Daily1.xlsx / Sheet2 / 1415. Source incorrectly labels the ABC answer SINGLE.
    private val stem = "在《关于“7.11”12 号线中春路车场1244 车冒进信号事故的情况通报》（沪地铁安〔2020〕255 号）中，此次事故的原因为（  ）。"
    private val texts = listOf("司机行车安全风险辨识不充分，在轨面湿滑情况下出场联络线运行作业速度总体偏高", "司机仓促施加全常用制动叠加轨面湿滑诱发列车防滑功能启动", "对于列车速度控制、制动时机、制动方式等驾驶习惯缺乏分析、指导、纠偏机制，导致部分司机养成运行速度偏高、全常用制动调速等不良驾驶习惯", "信号楼值班员对于天气因素通知不到位")
    private fun options(text: List<String>) = text.mapIndexed { i, t -> QuizOption(i, t, NormalizedBox(5f, 20f + i * 10f, 90f, 8f)) }
    private fun record(text: List<String> = texts) = LocalQuestionBankRecord("每日1.xlsx:Sheet2:1415", stem, QuestionType.SINGLE, listOf(0, 1, 2), options = options(text))
    private fun page(text: List<String> = texts, question: String = stem) = QuizModelResult(1, QuestionType.MULTIPLE, question, options(text), listOf(0, 1), NormalizedBox(5f, 85f, 90f, 8f), null, 0.9)

    @Test fun importedMistypedQuestionStillRejectsStrictSubsets() {
        val bank = QuestionBankIndex.fromRecords(listOf(record()))
        assertThrows(IncompleteQuestionOptions::class.java) { bank.requireCompleteVisionOptions(page(texts.take(2))) }
        assertThrows(IncompleteQuestionOptions::class.java) { bank.requireCompleteVisionOptions(page(listOf(texts[2], texts[0]))) }
        bank.requireCompleteVisionOptions(page(texts.reversed()))
        assertEquals(setOf(1, 2, 3), bank.answerForVision(page(texts.reversed()))?.answerIndices?.toSet())
    }

    @Test fun completeIndependentVariantAndUnrelatedNewQuestionRemainAllowed() {
        val two = record(texts.take(2)).copy(id = "two", answerIndices = listOf(0))
        val bank = QuestionBankIndex.fromRecords(listOf(record(), two))
        bank.requireCompleteVisionOptions(page(texts.take(2)))
        bank.requireCompleteVisionOptions(page(listOf("新增甲", "新增乙")))
        bank.requireCompleteVisionOptions(page(texts.take(2), question = "另一个合法新题"))
        bank.requireCompleteVisionOptions(page(listOf(texts[0], texts[0])))
    }

    @Test fun automaticPlanRejectsSingleOptionAndIndexHolesWithoutChangingManualParser() {
        val one = page(texts.take(1)).copy(answerIndices = listOf(0))
        assertThrows(IncompleteQuestionOptions::class.java) { QuizModelParser.actionPlan(one, 1) }
        val hole = page(texts.take(2)).copy(options = options(texts.take(2)).mapIndexed { i, o -> o.copy(index = i * 2) }, answerIndices = listOf(0))
        assertThrows(IncompleteQuestionOptions::class.java) { QuizModelParser.actionPlan(hole, 1) }
        assertEquals(2, QuizModelParser.actionPlan(page(texts.take(2)).copy(options = options(texts.take(2)).reversed()), 1).answerOptions.size)
        val raw = """{"question_type":"single","question":"手动一项","options":[{"index":0,"text":"甲"}],"answer_indices":[0],"confidence":0.9}"""
        assertEquals(1, QuizModelParser.parse(raw).options.size)
    }

    @Test fun resolverGuardPausesBeforeAnyTapAndRetryRetainsQuestionNumber() {
        val frame = CaptureFrame("fixture", FrameSignature.fromBits(BooleanArray(FrameSignature.BIT_COUNT)))
        val taps = mutableListOf<Int>(); val numbers = mutableListOf<Int>(); var reject = true; var confirms = 0
        val runner = QuizRunCoordinator(QuizMode.AUTO,
            captureGateway = object : CaptureGateway { override fun capture(callback: (Result<CaptureFrame>) -> Unit) = callback(Result.success(frame)) },
            modelGateway = object : ModelGateway { override fun analyze(frame: CaptureFrame, questionNo: Int, callback: (Result<String>) -> Unit) {
                numbers.add(questionNo)
                callback(Result.success("""{"question_type":"single","question":"原题","options":[{"index":0,"text":"甲","box":[5,20,90,8]},{"index":1,"text":"乙","box":[5,40,90,8]}],"answer_indices":[0],"confidence":0.9}"""))
            } },
            gestureGateway = object : GestureGateway {
                override fun isTargetForeground() = true
                override fun tap(option: QuizOption, callback: (Boolean) -> Unit) { taps.add(option.index); callback(true) }
                override fun tapConfirm(box: NormalizedBox?, callback: (Boolean) -> Unit) { confirms++; callback(true) }
                override fun cancel() {}
            },
            listener = object : RunnerListener { override fun onSnapshot(snapshot: RunnerSnapshot) {}; override fun onAnswer(result: QuizModelResult) {}; override fun onError(message: String) {} },
            scheduler = RunnerScheduler { _, _ -> RunnerScheduledTask {} },
            answerResolver = { if (reject) throw IncompleteQuestionOptions() else it })
        runner.onPrimaryAction()
        assertEquals(RunnerPhase.PAUSED_ERROR, runner.snapshot().phase)
        assertTrue(taps.isEmpty()); assertEquals(0, confirms)
        assertTrue(runner.snapshot().errorMessage!!.contains("全部选项"))
        assertEquals(1, runner.snapshot().questionNo)
        reject = false; runner.retry()
        assertEquals(listOf(1, 1), numbers); assertEquals(listOf(0), taps); assertEquals(1, confirms)
    }

    @Test fun zeroConfidencePureVisionCannotForgeLocalSourceButLocalCorrectionAndManualStillWork() {
        for ((mode, replace, source) in listOf(Triple(QuizMode.AUTO, false, "vision"),
            Triple(QuizMode.AUTO, false, "question_bank"), Triple(QuizMode.AUTO, true, "vision"),
            Triple(QuizMode.MANUAL, false, "vision"))) {
            var confirms = 0
            val frame = CaptureFrame("fixture", FrameSignature.fromBits(BooleanArray(FrameSignature.BIT_COUNT)))
            val runner = QuizRunCoordinator(mode,
                captureGateway = object : CaptureGateway { override fun capture(callback: (Result<CaptureFrame>) -> Unit) = callback(Result.success(frame)) },
                modelGateway = object : ModelGateway { override fun analyze(frame: CaptureFrame, questionNo: Int, callback: (Result<String>) -> Unit) {
                    callback(Result.success("""{"question_type":"single","question":"题目","options":[{"index":0,"text":"甲","box":[5,20,90,8]},{"index":1,"text":"乙","box":[5,40,90,8]}],"answer_indices":[0],"confidence":0,"answer_source":"$source"}"""))
                } },
                gestureGateway = object : GestureGateway { override fun isTargetForeground() = true
                    override fun tap(option: QuizOption, callback: (Boolean) -> Unit) = callback(true)
                    override fun tapConfirm(box: NormalizedBox?, callback: (Boolean) -> Unit) { confirms++; callback(true) }
                    override fun cancel() {} },
                listener = object : RunnerListener { override fun onSnapshot(snapshot: RunnerSnapshot) {}; override fun onAnswer(result: QuizModelResult) {}; override fun onError(message: String) {} },
                scheduler = RunnerScheduler { _, _ -> RunnerScheduledTask {} },
                answerResolver = { if (replace) it.copy(answerIndices = listOf(1), answerSource = "question_bank") else it })
            runner.onPrimaryAction()
            if (mode == QuizMode.MANUAL) assertEquals(RunnerPhase.READY, runner.snapshot().phase)
            else if (replace) { assertEquals(1, confirms); assertEquals(RunnerPhase.WAITING_PAGE_CHANGE, runner.snapshot().phase) }
            else { assertEquals(0, confirms); assertEquals(RunnerPhase.PAUSED_ERROR, runner.snapshot().phase); assertTrue(runner.snapshot().errorMessage!!.contains("不确定")) }
        }
    }
}
