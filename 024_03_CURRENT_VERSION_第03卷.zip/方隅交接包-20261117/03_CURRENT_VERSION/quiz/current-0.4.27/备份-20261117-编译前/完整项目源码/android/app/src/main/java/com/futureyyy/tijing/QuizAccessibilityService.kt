package com.futureyyy.tijing

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.accessibilityservice.GestureDescription
import java.util.ArrayDeque
import java.util.Collections
import java.util.IdentityHashMap
import java.util.concurrent.atomic.AtomicBoolean

class QuizAccessibilityService : AccessibilityService() {
    private data class PendingGesture(
        val description: GestureDescription,
        val targetPackage: String,
        val bounds: Rect,
        val completion: (Boolean) -> Unit,
    )

    private val gestureHandler = Handler(Looper.getMainLooper())
    private val gestureLock = Any()
    private val pendingGestures = ArrayDeque<PendingGesture>()
    private val foregroundTargetMemory = ForegroundTargetMemory()
    private var inFlightGesture: PendingGesture? = null

    @Volatile
    private var destroyed = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        synchronized(gestureLock) { destroyed = false }
        instance = this
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        rememberKnownActiveWindowTargets()
        debugGesture("service-connected")
    }

    @Suppress("DEPRECATION")
    private fun captureDisplayMetrics() = android.util.DisplayMetrics().also {
        val manager = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
        manager.defaultDisplay.getRealMetrics(it)
    }

    fun tapNormalized(nx: Float, ny: Float): Boolean {
        return tapNormalizedAsync(nx, ny) {}
    }

    fun tapNormalized(nx: Float, ny: Float, targetPackage: String): Boolean {
        return tapNormalizedAsync(nx, ny, targetPackage) {}
    }

    fun tapNormalizedAsync(nx: Float, ny: Float, completion: (Boolean) -> Unit): Boolean {
        return tapNormalizedAsync(nx, ny, DEFAULT_TARGET_PACKAGE, completion)
    }

    fun tapNormalizedAsync(
        nx: Float,
        ny: Float,
        targetPackage: String,
        completion: (Boolean) -> Unit,
    ): Boolean {
        val finish = singleCompletion(completion)
        debugGesture("tap-request target=$targetPackage nx=$nx ny=$ny")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            debugGesture("tap-rejected-sdk")
            return reject(finish)
        }
        if (!nx.isFinite() || !ny.isFinite() || nx !in 0f..1f || ny !in 0f..1f) {
            debugGesture("tap-rejected-coordinates")
            return reject(finish)
        }
        if (!isEligibleTargetPackage(targetPackage)) {
            debugGesture("tap-rejected-target")
            return reject(finish)
        }
        if (!isTargetForeground(targetPackage)) {
            debugGesture("tap-rejected-foreground")
            return reject(finish)
        }
        val metrics = captureDisplayMetrics()
        val x = nx * metrics.widthPixels
        val y = ny * metrics.heightPixels
        return enqueueTap(x, y, targetPackage, finish)
    }

    private var gestureEpoch = 0L

    private fun tapModelBox(box: NormalizedBox?, targetPackage: String, finish: (Boolean) -> Unit) {
        if (box == null) finish(false)
        else tapNormalizedAsync(box.centerX / 100f, box.centerY / 100f, targetPackage, finish)
    }

    fun tapSubmit(targetPackage: String, completion: (Boolean) -> Unit, onNoVisibleLabel: () -> Unit) {
        tapLabeledControl(SUBMIT_LABELS, targetPackage, singleCompletion(completion), onNoVisibleLabel)
    }

    private fun tapLabeledControl(
        labels: Set<String>, targetPackage: String, finish: (Boolean) -> Unit,
        onNoVisibleLabel: (() -> Unit)? = null, attempt: Int = 0,
    ) {
        fun missing() { if (onNoVisibleLabel != null && attempt == 0) onNoVisibleLabel() else finish(false) }
        val root = findTargetRoot(targetPackage) ?: return missing()
        val nodes = arrayListOf(root)
        try {
            val parentIndices = mutableListOf(-1)
            val matchingIndices = mutableListOf<Int>()
            var index = 0
            while (index < nodes.size) {
                if (nodes.size > CONFIRM_SNAP_MAX_NODES) { missing(); return }
                val node = nodes[index]
                val text = node.text?.toString()?.let(OcrHostPage::label)
                val description = node.contentDescription?.toString()?.let(OcrHostPage::label)
                if (text in labels || description in labels) matchingIndices.add(index)
                for (childIndex in 0 until node.childCount) {
                    val child = node.getChild(childIndex) ?: continue
                    nodes.add(child)
                    parentIndices.add(index)
                }
                index++
            }
            // Chromium may expose the label on the control and a text descendant.
            // Distinct buttons remain ambiguous even when they share the same text.
            val visibleMatches = matchingIndices.filter { nodes[it].isVisibleToUser }
            val matches = ConfirmReveal.deepestMatches(parentIndices, visibleMatches.ifEmpty { matchingIndices }).map(nodes::get)
            val control = matches.singleOrNull()
            if (control == null) {
                if (matches.isEmpty() || visibleMatches.isEmpty()) missing() else finish(false)
                return
            }
            var ancestor = nodes.indexOf(control)
            while (ancestor >= 0) {
                if (!nodes[ancestor].isEnabled) { finish(false); return }
                ancestor = parentIndices[ancestor]
            }
            val rect = Rect().also(control::getBoundsInScreen)
            if (control.isVisibleToUser && ConfirmReveal.isUsable(rect, captureDisplayMetrics().heightPixels)) {
                enqueueTap(rect.exactCenterX(), rect.exactCenterY(), targetPackage, finish)
                return
            }
            // A short WebView text run can sit inside a full-size button. Its text
            // height alone need not trigger a scroll away from the visible button.
            if (onNoVisibleLabel != null && control.isVisibleToUser && rect.height() > 0 && rect.height() < ConfirmReveal.MIN_VISIBLE_HEIGHT) {
                missing(); return
            }
            revealNode(control, targetPackage, attempt, finish) {
                tapLabeledControl(labels, targetPackage, finish, onNoVisibleLabel, attempt + 1)
            }
        } finally {
            recycleNodes(nodes)
        }
    }

    private fun revealNode(
        node: AccessibilityNodeInfo, targetPackage: String, attempt: Int,
        finish: (Boolean) -> Unit, readAgain: () -> Unit,
    ) {
        if (attempt >= ConfirmReveal.MAX_SCROLLS || !isTargetForeground(targetPackage)) {
            finish(false)
            return
        }
        val epoch = gestureEpoch
        val afterScroll: (Boolean) -> Unit = { ok ->
            if (!ok) finish(false)
            else gestureHandler.postDelayed({
                if (!destroyed && epoch == gestureEpoch && isTargetForeground(targetPackage)) readAgain()
                else finish(false)
            }, ConfirmReveal.SCROLL_DELAY_MS)
        }
        val shown = attempt == 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN.id)
        if (shown) afterScroll(true)
        else if (!scrollTargetForward(targetPackage, afterScroll)) finish(false)
    }

    internal fun scrollTargetForward(targetPackage: String, completion: (Boolean) -> Unit): Boolean {
        val root = findTargetRoot(targetPackage) ?: return false
        val visited = ArrayList<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        try {
            while (queue.isNotEmpty() && visited.size < CONFIRM_SNAP_MAX_NODES) {
                val node = queue.removeFirst()
                visited.add(node)
                for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
                if (!node.isScrollable) continue
                val r = Rect().also(node::getBoundsInScreen)
                val area = r.width() * r.height()
                if (area > bestArea) {
                    best = node
                    bestArea = area
                }
            }
            val target = best
            val metrics = resources.displayMetrics
            val r = if (target != null) {
                Rect().also(target::getBoundsInScreen)
            } else {
                Rect(0, 0, metrics.widthPixels, metrics.heightPixels)
            }
            if (r.height() < 80) return false
            val fromX = r.exactCenterX()
            val fromY = r.top + r.height() * 0.80f
            val toY = r.top + r.height() * 0.22f
            Log.i("ZhitiConfirm", "scroll-swipe $fromX,$fromY -> $fromX,$toY area=$bestArea")
            debugGesture("confirm-scroll-swipe $fromX,$fromY -> $fromX,$toY")
            return enqueueSwipe(fromX, fromY, fromX, toY, targetPackage, completion)
        } finally {
            recycleNodes(visited + queue)
        }
    }

    private fun enqueueSwipe(
        fromX: Float,
        fromY: Float,
        toX: Float,
        toY: Float,
        targetPackage: String,
        completion: (Boolean) -> Unit,
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        if (!isTargetForeground(targetPackage)) return false
        val path = Path().apply {
            moveTo(fromX, fromY)
            lineTo(toX, toY)
        }
        val pending = PendingGesture(
            description = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 420))
                .build(),
            targetPackage = targetPackage,
            bounds = Rect(minOf(fromX, toX).toInt(), minOf(fromY, toY).toInt(),
                maxOf(fromX, toX).toInt() + 1, maxOf(fromY, toY).toInt() + 1),
            completion = completion,
        )
        val accepted = synchronized(gestureLock) {
            if (destroyed) {
                false
            } else {
                pendingGestures.addLast(pending)
                true
            }
        }
        if (!accepted) return false
        gestureHandler.post { dispatchNextGesture() }
        return true
    }

    /** Option tap: model coordinate snapped to the nearest clickable non-submit node. */
    fun tapOptionNearAsync(
        nx: Float,
        ny: Float,
        targetPackage: String,
        completion: (Boolean) -> Unit,
    ): Boolean {
        val finish = singleCompletion(completion)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return reject(finish)
        if (!nx.isFinite() || !ny.isFinite() || nx !in 0f..1f || ny !in 0f..1f) return reject(finish)
        if (!isEligibleTargetPackage(targetPackage) || !isTargetForeground(targetPackage)) return reject(finish)
        val metrics = captureDisplayMetrics()
        val px = nx * metrics.widthPixels
        val py = ny * metrics.heightPixels
        val snapped = try {
            nearestClickableCenter(px, py, targetPackage, metrics.widthPixels, metrics.heightPixels, forConfirm = false)
        } catch (_: Exception) {
            null
        }
        debugGesture("option-near raw=$px,$py snapped=${snapped?.first},${snapped?.second}")
        return enqueueTap(snapped?.first ?: px, snapped?.second ?: py, targetPackage, finish)
    }

    fun tapOption(option: QuizOption, targetPackage: String, completion: (Boolean) -> Unit) {
        tapOption(option, targetPackage, singleCompletion(completion), 0)
    }

    private fun tapOption(option: QuizOption, targetPackage: String, completion: (Boolean) -> Unit, attempt: Int) {
        val expected = visibleQuestionSnapshot
        if (expected != null && option.screenRow) {
            val fresh = readVisibleBankQuestion(targetPackage, expected.questionNo ?: 1)
            val match = fresh?.options?.singleOrNull { it.index == option.index && it.text == option.text }
            if (fresh == null || !VisibleQuestionReader.sameQuestion(expected, fresh) || match?.box == null) {
                completion(false)
                return
            }
            val box = match.box
            tapNormalizedAsync(box.centerX / 100f, box.centerY / 100f, targetPackage, completion)
            return
        }
        // A visually identified option can still be tapped when the app exposes no text tree.
        val fallback = option.box?.takeUnless { option.screenRow || attempt > 0 }
        val root = findTargetRoot(targetPackage) ?: return tapModelBox(fallback, targetPackage, completion)
        val nodes = arrayListOf(root)
        val matches = mutableListOf<AccessibilityNodeInfo>()
        try {
            val letter = if (option.index in 0..25) ('A' + option.index).toString() else ""
            val text = option.text.trim().replaceFirst(Regex("^" + letter + """[.．、]\s*"""), "")
            val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
            while (queue.isNotEmpty() && nodes.size <= CONFIRM_SNAP_MAX_NODES) {
                val node = queue.removeFirst()
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { child -> nodes.add(child); queue.add(child) }
                }
                val label = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
                if (!OPTION_LETTER.matches(label)) continue
                val row = node.parent ?: continue
                nodes.add(row)
                for (i in 0 until row.childCount) {
                    val child = row.getChild(i) ?: continue
                    nodes.add(child)
                    val value = (child.text ?: child.contentDescription)?.toString()?.trim().orEmpty()
                    if (value.isEmpty() || OPTION_LETTER.matches(value)) continue
                    if (label.dropLast(1) == letter && value == text) matches.add(child)
                }
            }
            if (matches.size > 1) { completion(false); return }
            val target = matches.singleOrNull()
            if (target != null) {
                if (!target.isEnabled) { completion(false); return }
                val rect = Rect().also(target::getBoundsInScreen)
                if (target.isVisibleToUser && rect.width() > 0 && rect.height() >= 8) {
                    Log.i("ZhitiTap", "option label x=${rect.centerX()} y=${rect.centerY()}")
                    enqueueTap(rect.exactCenterX(), rect.exactCenterY(), targetPackage, completion)
                } else {
                    revealNode(target, targetPackage, attempt, completion) {
                        tapOption(option, targetPackage, completion, attempt + 1)
                    }
                }
                return
            }
        } finally {
            recycleNodes(nodes)
        }
        tapModelBox(fallback, targetPackage, completion)
    }

    private fun nodeLabel(node: AccessibilityNodeInfo): String {
        val own = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
        if (own.isNotEmpty() || node.childCount > 3) return own
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val label = (child.text ?: child.contentDescription)?.toString()?.trim().orEmpty()
            recycleNodes(listOf(child))
            if (label.isNotEmpty()) return label
        }
        return ""
    }

    private fun nearestClickableCenter(
        px: Float,
        py: Float,
        targetPackage: String,
        width: Int,
        height: Int,
        forConfirm: Boolean,
    ): Pair<Float, Float>? {
        val root = findTargetRoot(targetPackage) ?: return null
        val visited = ArrayList<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val screenArea = width.toFloat() * height.toFloat()
        val maxDistance = height * CONFIRM_SNAP_MAX_DISTANCE_RATIO
        var best: Rect? = null
        var bestRank = Int.MAX_VALUE
        var bestScore = Float.MAX_VALUE
        try {
            while (queue.isNotEmpty() && visited.size < CONFIRM_SNAP_MAX_NODES) {
                val node = queue.removeFirst()
                visited.add(node)
                for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
                val label = nodeLabel(node)
                val confirmLabel = forConfirm && label.length <= 6 && CONFIRM_TEXT_CANDIDATES.any(label::startsWith)
                if (!node.isVisibleToUser || !(node.isClickable || confirmLabel) || !node.isEnabled) continue
                val r = Rect().also(node::getBoundsInScreen)
                if (r.isEmpty) continue
                if (forConfirm && !ConfirmReveal.isUsable(r, height)) continue
                val area = r.width().toFloat() * r.height().toFloat()
                if (area > screenArea * CONFIRM_SNAP_MAX_AREA_RATIO) continue
                val contains = r.contains(px.toInt(), py.toInt())
                val dx = when { px < r.left -> r.left - px; px > r.right -> px - r.right; else -> 0f }
                val dy = when { py < r.top -> r.top - py; py > r.bottom -> py - r.bottom; else -> 0f }
                val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                val submitLike = label in CONFIRM_TEXT_CANDIDATES || confirmLabel
                if (!forConfirm && submitLike) continue
                val rank = when {
                    forConfirm && submitLike && (contains || distance <= maxDistance * 3) -> 0
                    contains -> 1
                    distance <= maxDistance -> 2
                    else -> continue
                }
                val score = if (contains) 0f else distance
                if (rank < bestRank || (rank == bestRank && score < bestScore)) {
                    best = r
                    bestRank = rank
                    bestScore = score
                }
            }
        } finally {
            recycleNodes(visited + queue)
        }
        return best?.let { it.exactCenterX() to it.exactCenterY() }
    }

    fun tapText(text: String): Boolean {
        return tapTextAsync(text) {}
    }

    fun tapText(text: String, targetPackage: String): Boolean {
        return tapTextAsync(text, targetPackage) {}
    }

    fun tapTextAsync(text: String, completion: (Boolean) -> Unit): Boolean {
        return tapTextAsync(text, DEFAULT_TARGET_PACKAGE, completion)
    }

    fun tapTextAsync(
        text: String,
        targetPackage: String,
        completion: (Boolean) -> Unit,
    ): Boolean {
        val finish = singleCompletion(completion)
        val query = text.trim()
        debugGesture("text-tap-request target=$targetPackage length=${query.length}")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || query.isEmpty() || !isEligibleTargetPackage(targetPackage)) {
            debugGesture("text-tap-rejected-input")
            return reject(finish)
        }
        val root = findTargetRoot(targetPackage) ?: run {
            debugGesture("text-tap-rejected-root")
            return reject(finish)
        }
        val nodesToRecycle = ArrayList<AccessibilityNodeInfo>()
        nodesToRecycle.add(root)
        val bounds = try {
            val matches = root.findAccessibilityNodeInfosByText(query).orEmpty()
            nodesToRecycle.addAll(matches)
            val node = matches.firstOrNull { candidate ->
                candidate.isVisibleToUser && (
                    candidate.text?.toString()?.trim() == query
                        || candidate.contentDescription?.toString()?.trim() == query
                    )
            } ?: run {
                debugGesture("text-tap-rejected-not-found")
                return reject(finish)
            }
            Rect().also(node::getBoundsInScreen)
        } catch (error: Exception) {
            debugGesture("text-tap-rejected-exception=${error.javaClass.simpleName}")
            return reject(finish)
        } finally {
            recycleNodes(nodesToRecycle)
        }
        if (bounds.isEmpty) {
            debugGesture("text-tap-rejected-bounds")
            return reject(finish)
        }
        val confirmLike = CONFIRM_TEXT_CANDIDATES.any { query == it || query.startsWith(it) || it.startsWith(query) }
        if (confirmLike && !ConfirmReveal.isUsable(bounds, resources.displayMetrics.heightPixels)) {
            debugGesture("text-tap-rejected-clipped")
            return reject(finish)
        }
        debugGesture("text-tap-bounds x=${bounds.exactCenterX()} y=${bounds.exactCenterY()}")
        return enqueueTap(bounds.exactCenterX(), bounds.exactCenterY(), targetPackage, finish)
    }

    private fun enqueueTap(
        x: Float,
        y: Float,
        targetPackage: String,
        completion: (Boolean) -> Unit,
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            debugGesture("enqueue-rejected-sdk")
            return reject(completion)
        }
        if (!isTargetForeground(targetPackage)) {
            debugGesture("enqueue-rejected-foreground")
            return reject(completion)
        }
        debugGesture("enqueue x=$x y=$y")
        val path = Path().apply { moveTo(x, y) }
        val pending = PendingGesture(
            description = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
                .build(),
            targetPackage = targetPackage,
            bounds = Rect(x.toInt(), y.toInt(), x.toInt() + 1, y.toInt() + 1),
            completion = completion,
        )
        val accepted = synchronized(gestureLock) {
            if (destroyed) {
                false
            } else {
                pendingGestures.addLast(pending)
                true
            }
        }
        if (!accepted) {
            debugGesture("enqueue-rejected-destroyed")
            return reject(completion)
        }
        debugGesture("enqueue-accepted")
        gestureHandler.post { dispatchNextGesture() }
        return true
    }

    fun canPerformGestures(): Boolean = !destroyed && instance === this && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    fun cancelGestures() {
        if (Looper.myLooper() == gestureHandler.looper) {
            cancelAllGestures()
        } else {
            gestureHandler.post { cancelAllGestures() }
        }
    }

    private fun dispatchNextGesture() {
        if (inFlightGesture != null) return
        val pending = synchronized(gestureLock) {
            if (pendingGestures.isEmpty()) null else pendingGestures.removeFirst()
        } ?: return
        inFlightGesture = pending
        if (!isTargetForeground(pending.targetPackage)) {
            debugGesture("foreground-rejected")
            cancelAllGestures()
            return
        }
        if (ScreenCaptureService.instance?.blocksGesture(pending.bounds) == true) {
            debugGesture("touch-point-covered")
            finishGesture(pending, false)
            return
        }
        val accepted = try {
            dispatchGesture(
                pending.description,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription) {
                        debugGesture("completed")
                        finishGesture(pending, true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription) {
                        debugGesture("cancelled")
                        finishGesture(pending, false)
                    }
                },
                gestureHandler,
            )
        } catch (error: Exception) {
            debugGesture("dispatch-exception=${error.javaClass.simpleName}")
            false
        }
        if (!accepted) {
            debugGesture("dispatch-rejected")
            finishGesture(pending, false)
        } else {
            debugGesture("dispatched")
        }
    }

    private fun finishGesture(pending: PendingGesture, succeeded: Boolean) {
        if (inFlightGesture !== pending) return
        inFlightGesture = null
        debugGesture("finished success=$succeeded")
        // A successful confirm can rebuild the WeChat window before this callback runs.
        // The foreground checks before dispatch already guard the target application.
        pending.completion(succeeded)
        dispatchNextGesture()
    }

    private fun cancelAllGestures() {
        gestureEpoch++
        val cancelled = ArrayList<PendingGesture>()
        inFlightGesture?.let(cancelled::add)
        inFlightGesture = null
        synchronized(gestureLock) {
            while (pendingGestures.isNotEmpty()) cancelled.add(pendingGestures.removeFirst())
        }
        if (cancelled.isNotEmpty()) debugGesture("cancelled count=${cancelled.size}")
        cancelled.forEach { it.completion(false) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val eventPackage = event?.packageName?.toString() ?: return
        if (
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            eventPackage != packageName &&
            eventPackage !in NON_TARGET_PACKAGES
        ) {
            foregroundTargetMemory.record(event.windowId, eventPackage)
        }
        val activeTarget = synchronized(gestureLock) {
            inFlightGesture?.targetPackage ?: pendingGestures.firstOrNull()?.targetPackage
        }
        if (eventPackage == activeTarget || eventPackage == packageName) return
        if (
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            isFocusedApplicationWindow(event.windowId)
        ) {
            debugGesture("cancelled-by-application-window")
            cancelAllGestures()
        }
    }

    override fun onInterrupt() {
        cancelGestures()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        synchronized(gestureLock) { destroyed = true }
        if (instance === this) instance = null
        cancelAllGestures()
        gestureHandler.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        synchronized(gestureLock) { destroyed = true }
        cancelAllGestures()
        gestureHandler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun isWeChatForeground(): Boolean {
        return isTargetForeground(DEFAULT_TARGET_PACKAGE)
    }

    private var visibleQuestionSnapshot: QuizModelResult? = null

    fun readBankQuestion(targetPackage: String, questionNo: Int): QuizModelResult? {
        val structured = readStructuredBankQuestion(targetPackage, questionNo)
        if (structured != null) {
            visibleQuestionSnapshot = null
            return structured
        }
        val page = readVisibleBankQuestion(targetPackage, questionNo)
        visibleQuestionSnapshot = page
        return page
    }

    private fun readVisibleBankQuestion(targetPackage: String, questionNo: Int): QuizModelResult? {
        if (!isTargetForeground(targetPackage)) return null
        val root = findTargetRoot(targetPackage) ?: return null
        val nodes = arrayListOf(root)
        val metrics = captureDisplayMetrics()
        fun snapshot(node: AccessibilityNodeInfo, depth: Int): VisibleQuestionReader.Node {
            require(depth <= 40 && nodes.size <= CONFIRM_SNAP_MAX_NODES)
            val rect = Rect().also(node::getBoundsInScreen)
            val usable = node.isVisibleToUser && node.isEnabled && rect.left >= 0 && rect.top >= 0 &&
                rect.right <= metrics.widthPixels && rect.bottom <= metrics.heightPixels &&
                rect.width() >= 4 && rect.height() >= 8 &&
                ScreenCaptureService.instance?.blocksGesture(rect) != true
            val box = if (usable) NormalizedBox(rect.left * 100f / metrics.widthPixels,
                rect.top * 100f / metrics.heightPixels, rect.width() * 100f / metrics.widthPixels,
                rect.height() * 100f / metrics.heightPixels) else null
            val children = (0 until node.childCount).mapNotNull { i ->
                node.getChild(i)?.also(nodes::add)?.let { snapshot(it, depth + 1) }
            }
            val text = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
            return VisibleQuestionReader.Node(text, box, children)
        }
        return try {
            val layout = VisibleQuestionReader.read(snapshot(root, 0)) ?: return null
            if (layout.type != null) layout.page(questionNo, layout.type)
            else {
                val bank = QuestionBankStore.get(this).index
                val candidates = listOf(QuestionType.SINGLE, QuestionType.MULTIPLE,
                    QuestionType.INDEFINITE, QuestionType.TRUE_FALSE).mapNotNull { type ->
                    val candidate = layout.page(questionNo, type)
                    bank.answerForScreen(candidate)?.let { candidate }
                }
                candidates.singleOrNull()
            }
        } catch (_: Exception) { null }
        finally { recycleNodes(nodes) }
    }

    private fun readStructuredBankQuestion(targetPackage: String, questionNo: Int): QuizModelResult? {
        if (!isTargetForeground(targetPackage)) return null
        val root = findTargetRoot(targetPackage) ?: return null
        val nodes = arrayListOf(root)
        fun children(parent: AccessibilityNodeInfo): List<AccessibilityNodeInfo> =
            (0 until parent.childCount).mapNotNull { parent.getChild(it)?.also(nodes::add) }
        fun label(node: AccessibilityNodeInfo) =
            (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
        val metrics = captureDisplayMetrics()
        fun box(node: AccessibilityNodeInfo): NormalizedBox? {
            if (!node.isVisibleToUser || !node.isEnabled) return null
            val rect = Rect().also(node::getBoundsInScreen)
            if (rect.left < 0 || rect.top < 0 || rect.right > metrics.widthPixels ||
                rect.bottom > metrics.heightPixels || rect.width() < 4 || rect.height() < 8
            ) return null
            return NormalizedBox(rect.left * 100f / metrics.widthPixels, rect.top * 100f / metrics.heightPixels,
                rect.width() * 100f / metrics.widthPixels, rect.height() * 100f / metrics.heightPixels)
        }
        try {
            val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
            var first: AccessibilityNodeInfo? = null
            var confirm: NormalizedBox? = null
            var submitFound = false
            while (queue.isNotEmpty()) {
                if (nodes.size > CONFIRM_SNAP_MAX_NODES) return null
                val node = queue.removeFirst()
                children(node).forEach(queue::add)
                val text = label(node)
                if (text in GRADED_LABELS || text in NEXT_LABELS) return null
                if (text in SUBMIT_LABELS) {
                    if (submitFound) return null
                    submitFound = true
                    confirm = box(node)
                }
                if (OPTION_LETTER.matches(text) && text.first() == 'A') {
                    if (first != null) return null
                    first = node
                }
            }
            if (!submitFound) return null
            val row = first?.parent?.also(nodes::add) ?: return null
            val group = row.parent?.also(nodes::add) ?: return null
            val card = group.parent?.also(nodes::add) ?: return null
            val before = children(card).takeWhile { it != group }
            val typeLabels = mapOf("单选" to QuestionType.SINGLE, "单选题" to QuestionType.SINGLE,
                "多选" to QuestionType.MULTIPLE, "多选题" to QuestionType.MULTIPLE,
                "判断" to QuestionType.TRUE_FALSE, "判断题" to QuestionType.TRUE_FALSE,
                "不定项" to QuestionType.INDEFINITE)
            val labels = before.map(::label).filter(String::isNotEmpty)
            val stems = labels.filterNot { it in typeLabels || PROGRESS_LABEL.matches(it) ||
                (it.startsWith("请选择") && it.endsWith("确认答案。")) }
            val stem = stems.singleOrNull() ?: return null
            val options = children(group).mapIndexed { index, item ->
                val parts = children(item).map(::label).filter(String::isNotEmpty)
                if (index > 25 || parts.size != 2 || !OPTION_LETTER.matches(parts[0]) ||
                    parts[0].first() != 'A' + index
                ) return null
                QuizOption(index, parts[1], box(item), screenRow = true)
            }
            return QuizModelResult(questionNo, labels.mapNotNull(typeLabels::get).singleOrNull() ?: return null,
                stem, options, emptyList(), confirm, null, 1.0)
        } catch (_: Exception) {
            return null
        } finally {
            recycleNodes(nodes)
        }
    }

    internal fun readVisibleLineNodes(targetPackage: String): List<VisibleQuestionReader.Node> {
        if (!isTargetForeground(targetPackage)) return emptyList()
        val root = findTargetRoot(targetPackage) ?: return emptyList()
        val nodes = arrayListOf(root)
        val metrics = captureDisplayMetrics()
        val lines = ArrayList<VisibleQuestionReader.Node>()
        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (depth > 40 || nodes.size > CONFIRM_SNAP_MAX_NODES) return
            val rect = Rect().also(node::getBoundsInScreen)
            val usable = node.isVisibleToUser && node.isEnabled && rect.left >= 0 && rect.top >= 0 &&
                rect.right <= metrics.widthPixels && rect.bottom <= metrics.heightPixels &&
                rect.width() >= 4 && rect.height() >= 8 &&
                ScreenCaptureService.instance?.blocksGesture(rect) != true
            val text = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
            if (usable && text.isNotEmpty()) {
                lines.add(
                    VisibleQuestionReader.Node(
                        text,
                        NormalizedBox(
                            rect.left * 100f / metrics.widthPixels,
                            rect.top * 100f / metrics.heightPixels,
                            rect.width() * 100f / metrics.widthPixels,
                            rect.height() * 100f / metrics.heightPixels,
                        ),
                    ),
                )
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.also(nodes::add)?.let { walk(it, depth + 1) }
            }
        }
        return try {
            walk(root, 0)
            lines
        } catch (_: Exception) {
            emptyList()
        } finally {
            recycleNodes(nodes)
        }
    }

    fun readQuestionPage(targetPackage: String): HostQuestionPage {
        val root = findTargetRoot(targetPackage) ?: return HostQuestionPage()
        val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
        val visited = ArrayList<AccessibilityNodeInfo>()
        val progress = mutableSetOf<HostQuestionProgress>()
        var hasFeedback = false
        var hasGradeDetails = false
        var hasNext = false
        try {
            while (queue.isNotEmpty() && visited.size < CONFIRM_SNAP_MAX_NODES) {
                val node = queue.removeFirst()
                visited.add(node)
                for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
                val label = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
                if (label in GRADED_LABELS) hasFeedback = true
                if (label in NEXT_LABELS && node.isVisibleToUser) hasNext = true
                if (label in NEXT_LABELS || label.startsWith("正确答案：") || label.startsWith("正确答案:")) {
                    hasGradeDetails = true
                }
                PROGRESS_LABEL.matchEntire(label)?.let {
                    val current = it.groupValues[1].toInt()
                    val total = it.groupValues[2].toInt()
                    if (current in 1..total) progress.add(HostQuestionProgress(current, total))
                }
            }
            return HostQuestionPage(progress.singleOrNull(), hasFeedback && hasGradeDetails, hasNext)
        } catch (_: Exception) {
            return HostQuestionPage()
        } finally {
            recycleNodes(visited + queue)
        }
    }

    fun continueGradedPage(targetPackage: String, completion: (Boolean) -> Unit) {
        // Recheck after the overlay has collapsed: the host may auto-advance in the interim.
        val page = readQuestionPage(targetPackage)
        if (!page.graded && !page.hasNext) {
            completion(false)
            return
        }
        tapLabeledControl(NEXT_LABELS, targetPackage, singleCompletion(completion))
    }

    fun isFinishedPage(targetPackage: String): Boolean {
        val root = findTargetRoot(targetPackage) ?: return false
        val visited = ArrayList<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val parts = StringBuilder()
        try {
            while (queue.isNotEmpty() && visited.size < 200) {
                val node = queue.removeFirst()
                visited.add(node)
                for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
                if (!node.isVisibleToUser) continue
                val label = (node.text ?: node.contentDescription)?.toString()?.trim().orEmpty()
                if (label.isNotEmpty()) {
                    if (parts.isNotEmpty()) parts.append(' ')
                    parts.append(label)
                    if (QuizFinishedPage.matches(parts.toString())) return true
                }
            }
            return QuizFinishedPage.matches(parts.toString())
        } catch (_: Exception) {
            return false
        } finally {
            recycleNodes(visited + queue)
        }
    }

    fun isTargetForeground(targetPackage: String): Boolean {
        if (!isEligibleTargetPackage(targetPackage)) return false
        val root = findTargetRoot(targetPackage)
        if (root != null) {
            recycleNodes(listOf(root))
            return true
        }
        return activeWindowIds().let { activeWindowIds ->
            val matches =
            foregroundTargetMemory.matchesTargetInAnyActiveWindow(targetPackage, activeWindowIds)
            if (!matches) debugForegroundMiss(targetPackage)
            matches
        }
    }

    fun foregroundApplicationPackage(): String? {
        val root = findForegroundApplicationRoot()
        if (root != null) {
            return try {
                root.packageName?.toString()?.takeIf(::isEligibleTargetPackage)
            } finally {
                recycleNodes(listOf(root))
            }
        }
        return rememberKnownActiveWindowTargets().firstOrNull()
    }

    private fun findTargetRoot(targetPackage: String): AccessibilityNodeInfo? {
        val activeRoot = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        }
        if (activeRoot?.packageName?.toString() == targetPackage) return activeRoot
        activeRoot?.let { recycleNodes(listOf(it)) }

        // Screen capture and overlays can temporarily make a system window active. In that
        // case, the focused application window still identifies the visible target safely.
        for (window in targetCandidateWindows()) {
            foregroundTargetMemory.recordKnownTarget(window.id, window.title)
            val root = try {
                window.root
            } catch (_: Exception) {
                null
            }
            if (root?.packageName?.toString() == targetPackage) return root
            root?.let { recycleNodes(listOf(it)) }
        }
        return null
    }

    private fun findForegroundApplicationRoot(): AccessibilityNodeInfo? {
        val activeRoot = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        }
        if (activeRoot != null && isEligibleTargetPackage(activeRoot.packageName?.toString().orEmpty())) {
            return activeRoot
        }
        activeRoot?.let { recycleNodes(listOf(it)) }

        for (window in targetCandidateWindows()) {
            foregroundTargetMemory.recordKnownTarget(window.id, window.title)
            val root = try {
                window.root
            } catch (_: Exception) {
                null
            }
            if (root != null && isEligibleTargetPackage(root.packageName?.toString().orEmpty())) {
                return root
            }
            root?.let { recycleNodes(listOf(it)) }
        }
        return null
    }

    private fun activeWindowIds(): List<Int> {
        val candidateWindows = targetCandidateWindows()
        candidateWindows.forEach { window -> foregroundTargetMemory.recordKnownTarget(window.id, window.title) }
        return candidateWindows.map { window -> window.id }
    }

    private fun rememberKnownActiveWindowTargets(): List<String> = targetCandidateWindows()
        .mapNotNull { window -> foregroundTargetMemory.recordKnownTarget(window.id, window.title) }

    private fun targetCandidateWindows() = allWindows().filter { window ->
        ForegroundWindowPolicy.includeInTargetCheck(
            isActive = window.isActive,
            isFocused = window.isFocused,
            isApplicationWindow = window.type == AccessibilityWindowInfo.TYPE_APPLICATION,
        )
    }

    private fun isFocusedApplicationWindow(windowId: Int): Boolean = allWindows().any { window ->
        window.id == windowId && ForegroundWindowPolicy.cancelsPendingGesture(
            isActive = window.isActive,
            isFocused = window.isFocused,
            isApplicationWindow = window.type == AccessibilityWindowInfo.TYPE_APPLICATION,
        )
    }

    private fun allWindows() = try {
        windows.orEmpty()
    } catch (_: Exception) {
        emptyList()
    }

    private fun debugForegroundMiss(targetPackage: String) {
        if (!BuildConfig.DEBUG) return
        val summary = allWindows().joinToString(separator = ";") { window ->
            "id=${window.id},type=${window.type},active=${window.isActive},focused=${window.isFocused},titleLength=${window.title?.length ?: 0}"
        }
        Log.i(LOG_TAG, "foreground-miss target=$targetPackage windows=[$summary]")
    }

    private fun debugGesture(event: String) {
        if (BuildConfig.DEBUG) Log.i(LOG_TAG, "gesture-$event")
    }

    private fun isEligibleTargetPackage(targetPackage: String): Boolean =
        targetPackage in KNOWN_QUIZ_TARGET_PACKAGES || (
            targetPackage.isNotBlank() &&
                targetPackage != packageName &&
                targetPackage !in NON_TARGET_PACKAGES
            )

    @Suppress("DEPRECATION")
    private fun recycleNodes(nodes: Iterable<AccessibilityNodeInfo>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return
        val recycled = Collections.newSetFromMap(
            IdentityHashMap<AccessibilityNodeInfo, Boolean>(),
        )
        nodes.forEach { node ->
            if (recycled.add(node)) runCatching { node.recycle() }
        }
    }

    private fun singleCompletion(completion: (Boolean) -> Unit): (Boolean) -> Unit {
        val completed = AtomicBoolean(false)
        return { succeeded ->
            if (completed.compareAndSet(false, true)) runCatching { completion(succeeded) }
        }
    }

    private fun reject(completion: (Boolean) -> Unit): Boolean {
        completion(false)
        return false
    }

    companion object {
        private val OPTION_LETTER = Regex("""[A-Z][.．、]""")
        private val SUBMIT_LABELS = OcrHostPage.submitLabels + "交卷"
        private val GRADED_LABELS = setOf("回答正确", "回答错误")
        private val NEXT_LABELS = setOf("下一题", "查看成绩")
        private val PROGRESS_LABEL = Regex("""([0-9]{1,5})\s*/\s*([0-9]{1,5})""")
        internal val CONFIRM_TEXT_CANDIDATES = listOf("确认", "提交", "提交答案", "确定", "下一题", "交卷")
        private const val CONFIRM_SNAP_MAX_DISTANCE_RATIO = 0.06f
        private const val CONFIRM_SNAP_MAX_NODES = 400
        private const val CONFIRM_SNAP_MAX_AREA_RATIO = 0.5f
        private const val LOG_TAG = "TiJingA11y"
        private const val DEFAULT_TARGET_PACKAGE = "com.tencent.mm"
        private const val SIMULATOR_TARGET_PACKAGE = "com.futureyyy.tijingsimulator"
        private val KNOWN_QUIZ_TARGET_PACKAGES = setOf(DEFAULT_TARGET_PACKAGE, SIMULATOR_TARGET_PACKAGE)
        private val NON_TARGET_PACKAGES = setOf(
            "android",
            "com.android.systemui",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
        )

        @Volatile
        var instance: QuizAccessibilityService? = null
    }
}
