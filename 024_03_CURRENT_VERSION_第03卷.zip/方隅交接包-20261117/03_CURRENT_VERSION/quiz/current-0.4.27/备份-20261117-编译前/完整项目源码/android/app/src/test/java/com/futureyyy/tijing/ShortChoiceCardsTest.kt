package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class ShortChoiceCardsTest {
    private val w=400
    private val h=560
    private val white=0xffffffff.toInt(); private val border=0xffcecece.toInt(); private val text=0xff242424.toInt()
    private fun image()=IntArray(w*h){white}
    private fun draw(pixels:IntArray, x:Int, y:Int, width:Int=340, body:Boolean=true, marker:Boolean=true) {
        fun rectangle(l:Int,t:Int,r:Int,b:Int,color:Int) { for(row in maxOf(0,t)..minOf(h-1,b))for(col in maxOf(0,l)..minOf(w-1,r))pixels[row*w+col]=color }
        rectangle(x,y,x+width,y,border); rectangle(x,y+49,x+width,y+49,border)
        rectangle(x,y,x,y+49,border); rectangle(x+width,y,x+width,y+49,border)
        if(marker){
            val cx=x+25;val cy=y+24
            for(row in maxOf(0,cy-12)..minOf(h-1,cy+12))for(col in cx-12..cx+12){val d=(col-cx)*(col-cx)+(row-cy)*(row-cy);if(d in 87..128)pixels[row*w+col]=text}
        }
        if(body)rectangle(x+55,y+15,x+85,y+33,text)
    }
    @Test fun croppedGlyphsMustBeBehindGenuineAlignedControlsInCompleteCards() {
        val pixels=image(); for(i in 0..3)draw(pixels,28,120+i*61)
        val found=ShortChoiceCards.locate(w,h,pixels)
        assertEquals(4,found.size)
        assertEquals(ShortChoiceCards.Rect(83,135,114,154),found[0].text)
        assertTrue(found.zipWithNext().all{(a,b)->a.text.bottom<b.text.top})
    }
    @Test fun outlinedLetterMarkersKeepTheBodyInEachRowSeparate() {
        val pixels=image()
        for (index in 0..3) {
            val top=120+index*61
            draw(pixels,28,top)
            for (y in top+19..top+29) for (x in 51..54) pixels[y*w+x]=text
        }
        val cards=ShortChoiceCards.locate(w,h,pixels)
        assertEquals(4,cards.size)
        assertTrue(cards.all { it.text.left==83 && it.marker.right<it.text.left && !it.continuousRule })
    }
    @Test fun wrappedChoiceRetainsBothLinesAndAnchorsTheClickInItsOwnCard() {
        val p=image()
        draw(p,28,90)
        draw(p,28,151,body=false)
        for (y in 152..226) for (x in 28..368) p[y*w+x]=white
        for (y in 152..226) {p[y*w+28]=border;p[y*w+368]=border}
        for (x in 28..368) p[226*w+x]=border
        for (y in 171..204) for (x in 40..65) {
            val d=(x-53)*(x-53)+(y-188)*(y-188)
            if(d in 87..128)p[y*w+x]=text
        }
        for(top in listOf(166,192)) for(y in top..top+16) for(x in 83..155)p[y*w+x]=text
        draw(p,28,238);draw(p,28,299)
        val result=ShortChoiceCards.locate(w,h,p)
        assertEquals(listOf(1,2,1,1),result.map{it.lines.size})
        assertEquals(ShortChoiceCards.Rect(83,166,156,183),result[1].lines.first())
    }

    @Test fun croppedRightBoundaryMustNotCreateAShorterCompleteGroup() {
        val p=image()
        for (i in 0..3) draw(p,28,120+i*61)
        for (y in 303 until 353) for (x in 323..369) p[y*w+x]=white
        assertTrue(ShortChoiceCards.locate(w,h,p).isEmpty())
    }

    @Test fun disjointColumnsMissingLabelsOrClippedRowsCannotRebuildAnOptionList() {
        val columns=image();for(i in 0..3){draw(columns,8,100+i*61,170);draw(columns,210,100+i*61,175)}
        assertTrue(ShortChoiceCards.locate(w,h,columns).isEmpty())
        val missing=image();for(i in 0..3)draw(missing,28,100+i*61,body=i!=2)
        assertTrue(ShortChoiceCards.locate(w,h,missing).isEmpty())
        val clipped=image();for(i in 0..3)draw(clipped,28,-15+i*61)
        assertTrue(ShortChoiceCards.locate(w,h,clipped).isEmpty())
        val bare=image();for(i in 0..3)draw(bare,28,100+i*61,marker=false)
        assertTrue(ShortChoiceCards.locate(w,h,bare).isEmpty())
    }

    @Test fun aSingleContinuousStrokeMustBeTheOnlySuchChoiceAndCannotContainAnotherGlyph() {
        val p=image();for(i in 0..3)draw(p,28,120+i*61,body=i!=0)
        fun stroke(y:Int, from:Int,to:Int) { for(x in from..to){p[y*w+x]=text;p[(y+1)*w+x]=text} }
        stroke(144,83,120)
        assertEquals(listOf(true,false,false,false),ShortChoiceCards.locate(w,h,p).map{it.continuousRule})
        for (y in 143..145) p[y*w+95]=text
        assertTrue(ShortChoiceCards.locate(w,h,p).isEmpty())
        p[143*w+95]=white
        for(y in 144..145)for(x in 96..99)p[y*w+x]=white
        assertTrue(ShortChoiceCards.locate(w,h,p).isEmpty())
        stroke(144,83,120)
        for(y in 181..216)for(x in 80..121)p[y*w+x]=white
        stroke(205,83,115)
        assertTrue(ShortChoiceCards.locate(w,h,p).isEmpty())
    }
}
