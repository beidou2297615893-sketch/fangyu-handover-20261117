package com.futureyyy.tijing

object QuizFinishedPage {
    fun matches(text: String): Boolean {
        val compact = text.replace("\\s".toRegex(), "")
        return compact.contains("重新抽取") ||
            compact.contains("已提交：") ||
            compact.contains("已提交:") ||
            compact.contains("得分：") ||
            compact.contains("得分:")
    }
}
