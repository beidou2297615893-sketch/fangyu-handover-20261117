package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class CaptureSurfaceLeaseTest {
    private data class Output(val size: Int = 1080)

    @Test fun replacementRejectsQueuedOldCallbackEvenForSameSize() {
        val closed = mutableListOf<Output>()
        val lease = CaptureSurfaceLease<Output> { closed.add(it) }
        val old = Output()
        val fresh = Output()
        lease.replace(old) {}
        lease.replace(fresh) { assertTrue(closed.isEmpty()) }
        assertFalse(lease.owns(old))
        assertTrue(lease.owns(fresh))
        assertSame(old, closed.single())
    }

    @Test fun failedAttachmentReleasesNewReaderAndAllowsShutdownOfPreviousReader() {
        val closed = mutableListOf<Output>()
        val lease = CaptureSurfaceLease<Output> { closed.add(it) }
        val old = Output()
        val next = Output()
        lease.replace(old) {}
        assertThrows(IllegalStateException::class.java) {
            lease.replace(next) { error("display stopped") }
        }
        assertSame(next, closed.single())
        assertTrue(lease.owns(old))
        lease.clear()
        lease.clear()
        assertSame(old, closed[1])
        assertEquals(2, closed.size)
        assertFalse(lease.owns(old))
    }

    @Test fun finishedRequestCannotBeSatisfiedOrTimedOutByItsRetiredSurface() {
        val lease = CaptureSurfaceLease<Output> {}
        val first = Output()
        lease.replace(first) {}
        lease.clear()
        val retry = Output()
        lease.replace(retry) {}
        assertFalse(lease.owns(first))
        assertTrue(lease.owns(retry))
    }
}
