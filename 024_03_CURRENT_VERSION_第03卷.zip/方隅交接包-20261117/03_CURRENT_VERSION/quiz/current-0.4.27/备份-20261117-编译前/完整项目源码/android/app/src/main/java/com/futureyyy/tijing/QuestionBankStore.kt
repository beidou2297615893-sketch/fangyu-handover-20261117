package com.futureyyy.tijing

import android.content.Context
import android.util.Log
import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.File
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Locale

/**
 * Writable question bank backed by app-private files. The packaged asset is only a seed:
 * copied once, never overwritten afterwards, so edits and auto-captured records survive
 * APK upgrades (they are lost only on uninstall or clearing app data).
 */
class QuestionBankStore private constructor(private val appContext: Context) {
    data class PageResult(
        val records: List<LocalQuestionBankRecord>,
        val total: Int,
        val offset: Int,
    )

    data class ImportResult(
        val ok: Boolean,
        val count: Int,
        val error: String?,
    )

    data class SaveResult(
        val ok: Boolean,
        val id: String?,
        val error: String?,
    )

    private val bankFile = File(appContext.filesDir, FILE_NAME)
    private val lock = Any()
    @Volatile
    private var cachedIndex: QuestionBankIndex? = null

    val index: QuestionBankIndex
        get() = cachedIndex ?: synchronized(lock) { cachedIndex ?: buildIndexLocked().also { cachedIndex = it } }

    fun snapshot(): List<LocalQuestionBankRecord> = synchronized(lock) { readRecordsLocked() }

    fun page(query: String, offset: Int, limit: Int): PageResult = synchronized(lock) {
        val needle = query.trim().lowercase(Locale.ROOT)
        val all = readRecordsLocked()
        val filtered = if (needle.isBlank()) all else {
            all.filter { record -> record.question.lowercase(Locale.ROOT).contains(needle) }
        }
        val from = offset.coerceIn(0, filtered.size)
        val to = (from + limit.coerceAtLeast(1)).coerceAtMost(filtered.size)
        PageResult(filtered.subList(from, to).toList(), filtered.size, from)
    }

    fun findById(id: String): LocalQuestionBankRecord? = synchronized(lock) {
        readRecordsLocked().firstOrNull { record -> record.id == id }
    }

    fun upsert(record: LocalQuestionBankRecord): Boolean = synchronized(lock) {
        val records = readRecordsLocked().toMutableList()
        val existing = records.indexOfFirst { current -> current.id == record.id }
        if (existing >= 0) records[existing] = record else records.add(record)
        writeRecordsLocked(records)
    }

    fun delete(id: String): Boolean = synchronized(lock) {
        val records = readRecordsLocked().toMutableList()
        val removed = records.removeAll { record -> record.id == id }
        if (!removed) return@synchronized false
        writeRecordsLocked(records)
    }

    /** Persists a vision-fallback answer, keyed by the normalized question text. */
    fun writeBackFallback(
        question: String,
        type: QuestionType,
        options: List<QuizOption>,
        answerIndices: List<Int>,
        answerText: String,
    ): Boolean = synchronized(lock) {
        val text = question.trim()
        if (text.isEmpty()) return@synchronized false
        val normalized = QuestionBankIndex.normalize(text)
        if (normalized.isBlank()) return@synchronized false
        val records = readRecordsLocked().toMutableList()
        val id = fallbackId(normalized)
        val existing = records.indexOfFirst { record ->
            record.id == id || QuestionBankIndex.normalize(record.question) == normalized
        }
        val record = LocalQuestionBankRecord(
            id = id,
            question = text,
            type = type,
            answerIndices = answerIndices.sorted().distinct(),
            answerText = answerText,
            options = options.map { option -> QuizOption(option.index, option.text, null) },
            anchors = emptyList(),
            sources = listOf(FALLBACK_SOURCE),
        )
        if (existing >= 0) records[existing] = record else records.add(record)
        val saved = writeRecordsLocked(records)
        if (saved) Log.i(TAG, "bank-writeback id=$id q=$text")
        saved
    }

    fun exportJson(pretty: Boolean): String = synchronized(lock) {
        val root = buildRootLocked(readRecordsLocked(), readConflictsLocked())
        if (pretty) PRETTY_GSON.toJson(root) else root.toString()
    }

    /** JSON payload for the web layer: { total, offset, records: [...] }. */
    fun pageJson(query: String, offset: Int, limit: Int): String = synchronized(lock) {
        val result = page(query, offset, limit)
        JsonObject().apply {
            addProperty("total", result.total)
            addProperty("offset", result.offset)
            add("records", JsonArray().apply {
                result.records.forEach { record -> add(recordToJson(record)) }
            })
        }.toString()
    }

    fun saveRecordJson(raw: String): SaveResult = synchronized(lock) {
        val element = try {
            JsonParser.parseString(raw)
        } catch (error: Exception) {
            return@synchronized SaveResult(false, null, "题目 JSON 解析失败")
        }
        if (!element.isJsonObject) return@synchronized SaveResult(false, null, "题目数据无效")
        val record = try {
            parseRecords(JsonArray().apply { add(element) }).firstOrNull()
        } catch (error: IllegalStateException) {
            return@synchronized SaveResult(false, null, error.message ?: "题目数据无效")
        } ?: return@synchronized SaveResult(false, null, "题目数据无效")
        if (record.question.isBlank()) return@synchronized SaveResult(false, null, "题干不能为空")
        val id = record.id.trim().ifBlank { fallbackId(QuestionBankIndex.normalize(record.question)) }
        val saved = record.copy(id = id)
        val records = readRecordsLocked().toMutableList()
        val existing = records.indexOfFirst { current -> current.id == id }
        if (existing >= 0) records[existing] = saved else records.add(saved)
        if (!writeRecordsLocked(records)) return@synchronized SaveResult(false, null, "题库写入失败")
        SaveResult(true, id, null)
    }

    fun importJson(raw: String): ImportResult = synchronized(lock) {
        val root = try {
            JsonParser.parseString(raw).asJsonObject
        } catch (error: Exception) {
            return@synchronized ImportResult(false, 0, "题库 JSON 解析失败")
        }
        val records = try {
            parseRecords(recordsArray(root))
        } catch (error: IllegalStateException) {
            return@synchronized ImportResult(false, 0, error.message ?: "题库内容无法读取")
        }
        if (records.isEmpty()) return@synchronized ImportResult(false, 0, "题库内容为空")
        val conflicts = try {
            parseConflicts(optionalArray(root, "conflicts"))
        } catch (error: IllegalStateException) {
            return@synchronized ImportResult(false, 0, error.message ?: "题库冲突记录无法读取")
        }
        if (!writeFileLocked(buildRootLocked(records, conflicts))) {
            return@synchronized ImportResult(false, 0, "题库写入失败")
        }
        ImportResult(true, records.size, null)
    }

    private fun buildIndexLocked(): QuestionBankIndex {
        val root = readRootLocked()
        val records = parseRecords(recordsArray(root))
        val conflicts = parseConflicts(root.getAsJsonArray("conflicts"))
        return QuestionBankIndex.fromRecords(records, conflicts)
    }

    /**
     * The bundled bank keeps the raw import list under `records` and the de-duplicated,
     * matchable set under `questions`; the matcher has always used `questions`.
     */
    private fun recordsArray(root: JsonObject): JsonArray {
        val questions = optionalArray(root, "questions")
        val records = optionalArray(root, "records")
        if (questions != null && questions.size() > 0) return questions
        if (records != null) return records
        if (questions != null) return questions
        bankReadError("题库缺少 questions 和 records")
    }

    private fun optionalArray(root: JsonObject, name: String): JsonArray? {
        val element = root.get(name) ?: return null
        if (element.isJsonNull) return null
        if (!element.isJsonArray) bankReadError("题库的 $name 不是数组")
        return element.asJsonArray
    }

    private fun readRecordsLocked(): List<LocalQuestionBankRecord> =
        parseRecords(recordsArray(readRootLocked()))

    private fun readRootLocked(): JsonObject {
        if (!bankFile.exists()) ensureSeeded()
        return try {
            JsonParser.parseString(bankFile.readText(Charsets.UTF_8)).asJsonObject
        } catch (error: Exception) {
            Log.e(TAG, "bank-read-failed: ${error.message}")
            throw IllegalStateException("题库文件无法读取", error)
        }
    }

    private fun ensureSeeded() {
        if (!bankFile.exists()) seedFromAsset()
    }

    private fun seedFromAsset() {
        if (bankFile.exists()) return
        try {
            val text = appContext.assets.open(SEED_ASSET).bufferedReader(Charsets.UTF_8).use { reader ->
                reader.readText()
            }
            val temp = File(appContext.filesDir, "$FILE_NAME.tmp")
            temp.writeText(text, Charsets.UTF_8)
            if (!commitTempFile(temp)) {
                Log.e(TAG, "bank-seed-failed: replace")
                writeEmptySeedIfMissing()
            }
        } catch (error: Exception) {
            Log.e(TAG, "bank-seed-failed: ${error.message}")
            writeEmptySeedIfMissing()
        }
    }

    private fun writeEmptySeedIfMissing() {
        if (bankFile.exists()) return
        val temp = File(appContext.filesDir, "$FILE_NAME.tmp")
        runCatching {
            temp.writeText("""{"schema_version":1,"questions":[]}""", Charsets.UTF_8)
            commitTempFile(temp)
        }
    }

    private fun writeRecordsLocked(records: List<LocalQuestionBankRecord>): Boolean =
        writeFileLocked(buildRootLocked(records, readConflictsLocked()))

    private fun readConflictsLocked(): Set<String> =
        parseConflicts(readRootLocked().getAsJsonArray("conflicts"))

    private fun writeFileLocked(root: JsonObject): Boolean {
        val temp = File(appContext.filesDir, "$FILE_NAME.tmp")
        return try {
            temp.writeText(root.toString(), Charsets.UTF_8)
            if (!commitTempFile(temp)) {
                false
            } else {
                cachedIndex = null
                true
            }
        } catch (error: Exception) {
            Log.e(TAG, "bank-write-failed: ${error.message}")
            if (temp.exists()) temp.delete()
            false
        }
    }

    // A completed temp file is moved onto the bank. The existing file is not deleted first.
    private fun commitTempFile(temp: File): Boolean {
        return try {
            try {
                Files.move(
                    temp.toPath(),
                    bankFile.toPath(),
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING,
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(
                    temp.toPath(),
                    bankFile.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                )
            }
            true
        } catch (error: Exception) {
            Log.e(TAG, "bank-replace-failed: ${error.message}")
            if (temp.exists()) temp.delete()
            false
        }
    }

    private fun buildRootLocked(
        records: List<LocalQuestionBankRecord>,
        conflicts: Set<String>,
    ): JsonObject = JsonObject().apply {
        addProperty("schema_version", SCHEMA_VERSION)
        add("questions", JsonArray().apply {
            records.forEach { record -> add(recordToJson(record)) }
        })
        add("conflicts", JsonArray().apply {
            conflicts.forEach { question ->
                add(JsonObject().apply { addProperty("normalized_question", question) })
            }
        })
    }

    private fun recordToJson(record: LocalQuestionBankRecord): JsonObject = JsonObject().apply {
        addProperty("id", record.id)
        addProperty("question", record.question)
        addProperty("type", record.type.jsonName())
        addProperty("answer", answerLetters(record.answerIndices))
        add("answer_indices", JsonArray().apply { record.answerIndices.forEach(::add) })
        addProperty("answer_text", record.answerText)
        add("options", JsonArray().apply {
            record.options.forEach { option ->
                add(JsonObject().apply {
                    addProperty("index", option.index)
                    addProperty("text", option.text)
                })
            }
        })
        add("anchors", JsonArray().apply { record.anchors.forEach(::add) })
        add("sources", JsonArray().apply {
            record.sources.forEach { source -> add(JsonObject().apply { addProperty("file", source) }) }
        })
    }

    private fun parseRecords(array: JsonArray?): List<LocalQuestionBankRecord> {
        if (array == null) return emptyList()
        return array.mapIndexed { index, element ->
            if (!element.isJsonObject) bankReadError("题库第${index + 1}条不是对象")
            val json = element.asJsonObject
            val idElement = json.get("id")
            if (idElement == null || idElement.isJsonNull) bankReadError("题库第${index + 1}条缺少 id")
            val questionElement = json.get("question")
            if (questionElement == null || questionElement.isJsonNull) bankReadError("题库第${index + 1}条缺少题干")
            val typeElement = json.get("type")
            val typeText = if (typeElement == null || typeElement.isJsonNull) {
                null
            } else {
                strictText(typeElement, "题库第${index + 1}条的 type 不是字符串")
            }
            LocalQuestionBankRecord(
                id = strictText(idElement, "题库第${index + 1}条的 id 不是字符串"),
                question = strictText(questionElement, "题库第${index + 1}条的题干不是字符串"),
                type = parseType(typeText),
                answerIndices = parseNumberList(json.get("answer_indices"), index, "答案编号"),
                answerText = optionalText(json.get("answer_text"), index, "answer_text"),
                options = parseOptions(json.get("options"), index),
                anchors = parseTextList(json.get("anchors"), index, "定位词"),
                sources = parseSources(json.get("sources"), index),
            )
        }
    }

    private fun parseNumberList(element: JsonElement?, recordIndex: Int, label: String): List<Int> {
        if (element == null || element.isJsonNull) return emptyList()
        if (!element.isJsonArray) bankReadError("题库第${recordIndex + 1}条的$label 无法读取")
        return element.asJsonArray.mapIndexed { itemIndex, item ->
            strictInt(item, "题库第${recordIndex + 1}条第${itemIndex + 1}个$label 不是整数")
        }
    }

    private fun parseTextList(element: JsonElement?, recordIndex: Int, label: String): List<String> {
        if (element == null || element.isJsonNull) return emptyList()
        if (!element.isJsonArray) bankReadError("题库第${recordIndex + 1}条的$label 无法读取")
        return element.asJsonArray.mapIndexed { itemIndex, item ->
            strictText(item, "题库第${recordIndex + 1}条第${itemIndex + 1}个$label 不是字符串")
        }
    }

    private fun parseOptions(element: JsonElement?, recordIndex: Int): List<QuizOption> {
        if (element == null || element.isJsonNull) return emptyList()
        if (!element.isJsonArray) bankReadError("题库第${recordIndex + 1}条的选项无法读取")
        return element.asJsonArray.mapIndexed { itemIndex, item ->
            if (!item.isJsonObject) bankReadError("题库第${recordIndex + 1}条第${itemIndex + 1}个选项无法读取")
            val option = item.asJsonObject
            val indexElement = option.get("index")
            if (indexElement == null || indexElement.isJsonNull) {
                bankReadError("题库第${recordIndex + 1}条第${itemIndex + 1}个选项缺少 index")
            }
            QuizOption(
                strictInt(indexElement, "题库第${recordIndex + 1}条第${itemIndex + 1}个选项 index 不是整数"),
                optionalText(option.get("text"), recordIndex, "选项文字"),
                null,
            )
        }
    }

    private fun optionalText(element: JsonElement?, recordIndex: Int, label: String): String {
        if (element == null || element.isJsonNull) return ""
        return strictText(element, "题库第${recordIndex + 1}条的$label 不是字符串")
    }

    private fun parseSources(element: JsonElement?, recordIndex: Int): List<String> {
        if (element == null || element.isJsonNull) return emptyList()
        if (!element.isJsonArray) bankReadError("题库第${recordIndex + 1}条的来源无法读取")
        return element.asJsonArray.mapIndexed { itemIndex, item ->
            when {
                item.isJsonPrimitive && item.asJsonPrimitive.isString -> item.asString
                item.isJsonPrimitive -> bankReadError("题库第${recordIndex + 1}条第${itemIndex + 1}个来源不是字符串")
                item.isJsonObject -> {
                    val json = item.asJsonObject
                    val file = strictSourceText(json.get("file"), recordIndex, itemIndex, "file")
                    val sheet = strictSourceText(json.get("sheet"), recordIndex, itemIndex, "sheet")
                    val row = strictSourceInt(json.get("row"), recordIndex, itemIndex)
                    val text = listOfNotNull(file, sheet, row?.toString()).joinToString(" / ")
                    if (text.isBlank()) bankReadError("题库第${recordIndex + 1}条第${itemIndex + 1}个来源无法读取")
                    text
                }
                else -> bankReadError("题库第${recordIndex + 1}条第${itemIndex + 1}个来源无法读取")
            }
        }
    }

    private fun parseConflicts(array: JsonArray?): Set<String> {
        if (array == null) return emptySet()
        return array.mapIndexed { index, element ->
            if (!element.isJsonObject) bankReadError("题库第${index + 1}条冲突记录不是对象")
            val value = element.asJsonObject.get("normalized_question")
            if (value == null || value.isJsonNull) bankReadError("题库第${index + 1}条冲突记录缺少 normalized_question")
            strictText(value, "题库第${index + 1}条冲突记录的 normalized_question 不是字符串")
        }.toSet()
    }

    private fun strictText(element: JsonElement, message: String): String {
        if (!element.isJsonPrimitive || !element.asJsonPrimitive.isString) bankReadError(message)
        return element.asString
    }

    private fun strictInt(element: JsonElement, message: String): Int {
        if (!element.isJsonPrimitive || !element.asJsonPrimitive.isNumber) bankReadError(message)
        val literal = element.asString
        if (!Regex("^-?\\d+$").matches(literal)) bankReadError(message)
        return literal.toIntOrNull() ?: bankReadError(message)
    }

    private fun strictSourceText(element: JsonElement?, recordIndex: Int, itemIndex: Int, label: String): String? {
        if (element == null || element.isJsonNull) return null
        if (!element.isJsonPrimitive || !element.asJsonPrimitive.isString) {
            bankReadError("题库第${recordIndex + 1}条第${itemIndex + 1}个来源的 $label 不是字符串")
        }
        return element.asString
    }

    private fun strictSourceInt(element: JsonElement?, recordIndex: Int, itemIndex: Int): Int? {
        if (element == null || element.isJsonNull) return null
        return strictInt(element, "题库第${recordIndex + 1}条第${itemIndex + 1}个来源的 row 不是整数")
    }

    private fun bankReadError(message: String): Nothing =
        throw IllegalStateException("$message，已停止读取，原文件未改")

    private fun fallbackId(normalizedQuestion: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(normalizedQuestion.toByteArray(Charsets.UTF_8))
        val hex = digest.take(8).joinToString("") { byte -> "%02x".format(byte) }
        return "$FALLBACK_ID_PREFIX$hex"
    }

    private fun answerLetters(indices: List<Int>): String =
        indices.sorted().joinToString(",") { index ->
            if (index in 0..25) ('A'.code + index).toChar().toString() else "#${index + 1}"
        }

    private fun QuestionType.jsonName(): String = when (this) {
        QuestionType.SINGLE -> "single"
        QuestionType.MULTIPLE -> "multiple"
        QuestionType.INDEFINITE -> "indefinite"
        QuestionType.TRUE_FALSE -> "true_false"
        QuestionType.FILL_BLANK -> "fill_blank"
    }

    private fun parseType(raw: String?): QuestionType = when (raw) {
        "multiple" -> QuestionType.MULTIPLE
        "indefinite" -> QuestionType.INDEFINITE
        "true_false" -> QuestionType.TRUE_FALSE
        "fill_blank" -> QuestionType.FILL_BLANK
        else -> QuestionType.SINGLE
    }

    init {
        ensureSeeded()
    }

    companion object {
        private const val TAG = "TiJingBank"
        private const val FILE_NAME = "question-bank.json"
        private const val SEED_ASSET = "question-bank.json"
        private const val SCHEMA_VERSION = 1
        const val FALLBACK_ID_PREFIX = "auto-"
        const val FALLBACK_SOURCE = "auto_fallback"
        private val PRETTY_GSON = GsonBuilder().setPrettyPrinting().create()

        @Volatile
        private var instance: QuestionBankStore? = null

        fun get(context: Context): QuestionBankStore =
            instance ?: synchronized(this) {
                instance ?: QuestionBankStore(context.applicationContext).also { instance = it }
            }
    }
}
