package com.futureyyy.tijing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfirmRevealTest {
    @Test
    fun traversedControlSurvivesAnUnindexedWebViewAndDuplicateAncestor() {
        // Traversal finds WebView -> button -> text even when platform text search has no hits.
        assertEquals(listOf(2), ConfirmReveal.deepestMatches(listOf(-1, 0, 1), listOf(1, 2)))
        // Two separately actionable labels must not silently become one.
        assertEquals(listOf(2, 3), ConfirmReveal.deepestMatches(listOf(-1, 0, 1, 0), listOf(1, 2, 3)))
    }

    @Test
    fun rejectsClippedNextButtonAtBottomEdge() {
        // Reproduced on the railway 5/100 result page: 「下一题」 was only 2px tall at y=614-616.
        assertFalse(ConfirmReveal.isUsable(68, 614, 252, 616, 640))
    }

    @Test
    fun acceptsFullyVisibleNextButton() {
        assertTrue(ConfirmReveal.isUsable(68, 560, 252, 600, 640))
    }

    @Test
    fun rejectsEmptyBounds() {
        assertFalse(ConfirmReveal.isUsable(0, 0, 0, 0, 640))
    }
}
