package com.futureyyy.tijing

import android.content.SharedPreferences
import java.security.MessageDigest

/** Stores only the last grant and a digest. Never stores the actual question or user answer. */
internal class FallbackAllowance(private val prefs: SharedPreferences) {
    @Synchronized fun reserve(run:String?, number:Int, stem:String):Boolean {
        if (run.isNullOrBlank() || number <= 0 || stem.isBlank()) return false
        val hash = MessageDigest.getInstance("SHA-256").digest(stem.trim().toByteArray()).joinToString("") { "%02x".format(it) }
        val next = FallbackUse(run, number, hash)
        val previous = prefs.getString("run", null)?.let { FallbackUse(it, prefs.getInt("number", 0), prefs.getString("hash", "").orEmpty()) }
        if (previous == next) return true
        if (previous != null && !previous.permits(next)) return false
        return prefs.edit().putString("run",run).putInt("number",number).putString("hash",hash).commit()
    }
}
