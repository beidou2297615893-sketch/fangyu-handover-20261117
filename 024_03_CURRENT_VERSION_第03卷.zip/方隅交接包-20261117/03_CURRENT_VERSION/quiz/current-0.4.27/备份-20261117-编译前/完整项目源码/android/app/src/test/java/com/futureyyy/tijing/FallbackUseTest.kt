package com.futureyyy.tijing

import org.junit.Assert.*
import org.junit.Test

class FallbackUseTest {
    @Test fun retryAtKnownHostProgressAfterRestartIsIdempotentButANewStemIsNot() {
        val prior = FallbackUse("round1", 7, "a")
        assertTrue(prior.permits(prior.copy()))
        assertFalse(prior.permits(prior.copy(stemHash="b")))
        assertFalse(prior.permits(prior.copy(number=1,stemHash="b")))
        assertFalse(prior.permits(prior.copy(number=106,stemHash="b")))
        assertTrue(prior.permits(prior.copy(number=107,stemHash="b")))
        assertTrue(prior.permits(prior.copy(run="new-round",number=1,stemHash="b")))
    }
}
