package com.futureyyy.tijing

import java.util.UUID

/** In-memory consent challenge. Neither a launcher intent nor a stale result can create a task. */
internal class ProjectionRecovery {
    enum class Phase { NEEDS_CONSENT, CONSENT_OPEN, RESTORING, READY }

    var phase: Phase? = null
        private set
    var challenge: String? = null
        private set

    fun lost() {
        phase = Phase.NEEDS_CONSENT
        challenge = UUID.randomUUID().toString()
    }

    fun open(id: String?): Boolean = advance(id, Phase.NEEDS_CONSENT, Phase.CONSENT_OPEN)
    fun approve(id: String?): Boolean = advance(id, Phase.CONSENT_OPEN, Phase.RESTORING)
    fun cancel(id: String?): Boolean = advance(id, Phase.CONSENT_OPEN, Phase.NEEDS_CONSENT)
    fun restored(id: String?): Boolean = advance(id, Phase.RESTORING, Phase.READY)

    private fun advance(id: String?, expected: Phase, next: Phase): Boolean {
        if (id == null || id != challenge || phase != expected) return false
        phase = next
        return true
    }

    fun clear() {
        phase = null
        challenge = null
    }
}
