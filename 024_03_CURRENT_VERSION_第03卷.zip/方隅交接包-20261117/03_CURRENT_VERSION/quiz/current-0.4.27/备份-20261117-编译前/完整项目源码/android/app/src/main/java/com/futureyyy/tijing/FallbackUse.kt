package com.futureyyy.tijing

/** Written before the first pure-model gesture; a retry on the same visible question is idempotent. */
internal data class FallbackUse(val run:String, val number:Int, val stemHash:String) {
    fun permits(next:FallbackUse):Boolean = run != next.run || this == next || next.number.toLong() - number >= 100L
}
