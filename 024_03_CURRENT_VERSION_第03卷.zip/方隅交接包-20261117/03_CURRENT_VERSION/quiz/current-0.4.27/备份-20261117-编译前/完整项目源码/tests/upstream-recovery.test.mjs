import test from 'node:test';
import assert from 'node:assert/strict';
import { sanitizeSettings } from '../src/lib/settings.js';

test('original visual automation and manual bank modes remain distinct', () => {
  const visual = sanitizeSettings({answerSource:'vision', mode:'auto'});
  assert.equal(visual.answerSource, 'vision');
  assert.equal(visual.mode, 'auto');
  const bank = sanitizeSettings({answerSource:'question_bank', mode:'auto'});
  assert.equal(bank.answerSource, 'question_bank');
  assert.equal(bank.mode, 'manual');
});
