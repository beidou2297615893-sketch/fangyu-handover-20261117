import test from 'node:test';
import assert from 'node:assert/strict';
let api;
try { api = await import('../src/lib/payment.js'); } catch { api = null; }
test('browser cannot fabricate an available payment account', async () => {
  assert.ok(api, 'native payment helper must be implemented');
  const result = await api.getPaymentStatus();
  assert.equal(result.available, false);
  assert.deepEqual(result.plans, []);
  assert.equal(result.entitlement, null);
});
test('purchase is an explicit native request and never grants access in JavaScript', async () => {
  assert.ok(api, 'native payment helper must be implemented');
  await assert.rejects(api.purchasePlan('once'), /安卓|原生|不可用/);
});


test('membership expiry is shown in seconds while extra credits remain visible', () => {
  const expiry = Math.floor(Date.now() / 1000) + 86400;
  assert.match(api.paymentEntitlementText({entitlement:{validUntil:expiry,runCredits:0},remainingText:'剩余 0 次'}), /套餐有效至/);
  assert.match(api.paymentEntitlementText({entitlement:{validUntil:expiry,runCredits:2}}), /另有 2 次/);
  assert.equal(api.paymentEntitlementText({entitlement:{validUntil:1,runCredits:0},remainingText:'剩余 0 次'}), '剩余 0 次');
  assert.equal(api.paymentEntitlementText({entitlement:{validUntil:expiry,requiresReview:true},remainingText:'待核对'}), '待核对');
});

test('simultaneous refreshes share one native request and foreground result updates subscribers without a request', async () => {
  const previous = globalThis.window;
  const host = new EventTarget();
  let calls = 0, reply;
  host.AndroidBridge = {paymentRequest(op, payload, id) { calls++; assert.equal(op, 'refresh'); reply = value => host.onNativePaymentResponse(id, JSON.stringify(value), null); }};
  globalThis.window = host;
  try {
    const a=api.refreshPayment(), b=api.refreshPayment();
    assert.equal(a,b); assert.equal(calls,1);
    reply({remainingText:'剩余 1 次'});
    assert.equal((await a).remainingText,'剩余 1 次');
    let latest;
    const unsubscribe=api.subscribePaymentStatus(value=>{latest=value});
    host.onNativePaymentStatus(JSON.stringify({entitlement:{validUntil:2000000000,runCredits:0}}));
    assert.equal(latest.entitlement.validUntil,2000000000); assert.equal(calls,1);
    host.onNativePaymentStatus('bad JSON'); assert.equal(latest.entitlement.validUntil,2000000000);
    unsubscribe();host.onNativePaymentStatus('{}');assert.equal(latest.entitlement.validUntil,2000000000);
  } finally { if(previous===undefined)delete globalThis.window;else globalThis.window=previous; }
});


test('trial text follows the server clock and asks for a plan after 72 hours', () => {
  const started = 1_700_000_000_000;
  const active = { eligible: true, active: true, reason: 'new-device', startedAt: started, expiresAt: started + 72 * 60 * 60 * 1000, serverNow: started + 60 * 60 * 1000 };
  assert.match(api.paymentEntitlementText({ trial: active, serverNow: active.serverNow, entitlement: null }, started + 100 * 60 * 60 * 1000), /免费试用至/);
  const expired = { ...active, active: false, serverNow: started + 73 * 60 * 60 * 1000 };
  assert.equal(api.paymentEntitlementText({ trial: expired, serverNow: expired.serverNow }, 0), '72小时试用已结束，请选择周套餐或月套餐');
  assert.match(api.paymentStatusNotice({ trial: expired, entitlement: { runCredits: 0, validUntil: null } }), /72小时试用已结束/);
  assert.match(api.paymentStatusNotice({ trialStale: true, trial: active }), /不会因此被取消/);
  assert.equal(api.paymentStatusNotice({ trial: active, entitlement: { runCredits: 0, validUntil: null } }), '');
});

test('customer notices separate unfinished order, empty entitlement and pending round end', () => {
  assert.match(api.paymentStatusNotice({pendingPayment:{},entitlement:{runCredits:0,validUntil:null}}), /上笔付款尚未确认/);
  assert.match(api.paymentStatusNotice({entitlement:{runCredits:0,validUntil:null}}), /没有可用的答题权益/);
  assert.match(api.paymentStatusNotice({pendingRunEnd:true,pendingPayment:{}}), /结束状态待核对/);
  assert.equal(api.paymentStatusNotice({entitlement:{runCredits:1,validUntil:null}}),'');
  assert.equal(api.paymentStatusNotice(null),'');
});
