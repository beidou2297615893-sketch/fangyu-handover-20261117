import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { dailyRunStatusText, normalizeSessionPhase, sessionCanStop } from '../src/lib/sessionPhase.js';

test('daily status keeps preparation, waiting, running, recovery, and idle apart', () => {
  assert.equal(dailyRunStatusText({ preparing: true, phase: 'running' }), '正在准备');
  assert.equal(dailyRunStatusText({ preparing: true, phase: 'ready' }), '正在准备');
  assert.equal(dailyRunStatusText({ phase: 'ready' }), '已准备，等待开始');
  assert.equal(dailyRunStatusText({ phase: 'running' }), '答题中');
  assert.equal(dailyRunStatusText({ phase: 'recovering' }), '等待屏幕共享恢复');
  assert.equal(dailyRunStatusText({ phase: 'idle' }), '未开始');
  assert.equal(dailyRunStatusText({ phase: 'unknown' }), '未开始');
  assert.equal(normalizeSessionPhase('ready'), 'ready');
  assert.equal(normalizeSessionPhase(''), 'idle');
});

test('a prepared session can be closed without being labelled as answering', () => {
  assert.equal(sessionCanStop({ phase: 'ready' }), true);
  assert.equal(dailyRunStatusText({ phase: 'ready' }), '已准备，等待开始');
  assert.equal(sessionCanStop({ phase: 'recovering' }), true);
  assert.equal(sessionCanStop({ preparing: true, phase: 'idle' }), true);
  assert.equal(sessionCanStop({ phase: 'idle' }), false);
});

test('repeated phase notifications collapse and recovery is not shown as answering', () => {
  const events = ['ready', 'ready', 'running', 'running', 'recovering', 'running', 'idle', 'idle'];
  const seen = [];
  let current = 'idle';
  for (const event of events) {
    const next = normalizeSessionPhase(event);
    if (next === current) continue;
    seen.push(dailyRunStatusText({ phase: next }));
    current = next;
  }
  assert.deepEqual(seen, ['已准备，等待开始', '答题中', '等待屏幕共享恢复', '答题中', '未开始']);
});

test('the daily page reads the separate phase and leaves isSessionRunning unchanged', () => {
  const dailyViews = fs.readFileSync(new URL('../src/DailyViews.jsx', import.meta.url), 'utf8');
  const app = fs.readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const service = fs.readFileSync(
    new URL('../android/app/src/main/java/com/futureyyy/tijing/ScreenCaptureService.kt', import.meta.url),
    'utf8',
  );
  const main = fs.readFileSync(
    new URL('../android/app/src/main/java/com/futureyyy/tijing/MainActivity.kt', import.meta.url),
    'utf8',
  );
  assert.match(dailyViews, /dailyRunStatusText\(\{ preparing: busy, phase \}\)/);
  assert.doesNotMatch(dailyViews, /active\?'答题中'/);
  assert.match(app, /onNativeFloatingSessionPhase/);
  assert.match(app, /sessionCanStop\(/);
  assert.match(service, /fun isSessionRunning\(\): Boolean =\s*!terminalStopScheduled && runtimeConfig != null && \(coordinator != null \|\| sweep != null\)/);
  assert.match(service, /SessionPhase\.describe/);
  assert.match(main, /"sessionPhase"/);
  assert.match(main, /isSessionRunning\(\)/);
});
