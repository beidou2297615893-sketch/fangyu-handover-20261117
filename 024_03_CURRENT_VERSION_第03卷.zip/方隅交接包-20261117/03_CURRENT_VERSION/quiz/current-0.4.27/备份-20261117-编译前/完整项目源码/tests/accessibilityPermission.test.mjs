import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = path => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const activity = read('android/app/src/main/java/com/futureyyy/tijing/MainActivity.kt');
const service = read('android/app/src/main/java/com/futureyyy/tijing/QuizAccessibilityService.kt');
const app = read('src/App.jsx');

// Small deterministic reproduction of the native guard order. Its source contracts below
// keep these cases tied to the shipped implementation (no Android/device side effects).
function next({ overlay = true, enabled = false, ready = false, capture = false, remaining = 20 }) {
  if (!overlay) return 'overlay-settings';
  if (!enabled && !ready) return 'accessibility-settings';
  if (!ready) return remaining > 0 ? 'wait-binding' : 'binding-error';
  return capture ? 'resume-capture' : 'capture-consent';
}
test('enabled but temporarily unbound never loops through accessibility settings', () => {
  assert.equal(next({enabled:true}), 'wait-binding');
  assert.equal(next({enabled:true,remaining:0}), 'binding-error');
  assert.equal(next({enabled:true,ready:true}), 'capture-consent');
  assert.equal(next({enabled:true,ready:true,capture:true}), 'resume-capture');
  assert.equal(next({}), 'accessibility-settings');
});
test('grant reads both Android manager and flattened secure component names', () => {
  assert.match(activity, /getEnabledAccessibilityServiceList/);
  assert.match(activity, /Settings\.Secure\.ENABLED_ACCESSIBILITY_SERVICES/);
  assert.match(activity, /ComponentName\.unflattenFromString\(it\) == expected/);
  assert.doesNotMatch(activity, /Settings\.Secure\.put|requestRebind|bindService\(/);
});
test('binding is checked independently before projection with cancellable bounded polling', () => {
  const continuation = activity.slice(activity.indexOf('private fun continuePendingFloatingSession()'), activity.indexOf('private fun openPendingSettingsPage'));
  const permission = continuation.indexOf('!hasGesturePermission()');
  const ready = continuation.indexOf('!isGestureServiceReady()');
  const projection = continuation.indexOf('projectionRequestInFlight = true');
  assert.ok(permission >= 0 && ready > permission && projection > ready);
  assert.match(activity, /generation != gestureWaitGeneration/);
  assert.match(activity, /left <= 0/);
  assert.match(activity, /GESTURE_PERMISSION_RETRIES = 20/);
  assert.match(activity, /private fun clearPendingFloatingSession\(\) \{\s*gestureWaitGeneration \+= 1\s*gestureWaitInFlight = false/);
  assert.match(activity, /无障碍已开启，但自动点击服务尚未连接/);
});
test('unbind invalidates stale service and UI refreshes without falsely completing startup', () => {
  assert.match(service, /override fun onUnbind\(intent: Intent\?\): Boolean \{[\s\S]*?destroyed = true[\s\S]*?instance === this\) instance = null/);
  assert.match(service, /fun canPerformGestures\(\): Boolean = !destroyed && instance === this/);
  assert.match(activity, /bindServiceListeners\(\)\s*notifyFloatingCapabilities\(\)/);
  assert.match(activity, /\.put\("gestureReady", isGestureServiceReady\(\)\)/);
  assert.match(app, /const capabilitiesHandler = \(\) => \{[\s\S]*?setFloatingCapabilities\(next\)/);
});
test('screen consent remains separate and live capture alone allows reuse', () => {
  assert.match(activity, /MediaProjectionConfig\.createConfigForDefaultDisplay\(\)/);
  assert.match(activity, /ScreenCaptureService\.instance\?\.isCaptureReady\(\) == true/);
  assert.match(activity, /startActivityForResult\(createScreenCaptureIntent\(\), REQUEST_FLOATING_CAPTURE\)/);
});
