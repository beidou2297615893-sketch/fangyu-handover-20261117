'use strict';
// Internal routing candidate only. The exported production entry below is
// unconditionally disabled and never initializes CloudBase or reads secrets.
const {parseTree}=require('jsonc-parser');
const PREFIX='/api/billing';
const check=v=>{if(!v)throw Error('unavailable');};
function response(statusCode,value,type='application/json'){
  return {statusCode,headers:{'content-type':type+'; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'},body:type==='application/json'?JSON.stringify(value):value,isBase64Encoded:false};
}
function exact(value,keys){check(value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===[...keys].sort().join(','));}
function wellFormed(text){for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c>=0xd800&&c<=0xdbff){if(++i>=text.length||text.charCodeAt(i)<0xdc00||text.charCodeAt(i)>0xdfff)return false;}else if(c>=0xdc00&&c<=0xdfff)return false;}return true;}
function json(raw){
  const value=JSON.parse(raw),errors=[],tree=parseTree(raw,errors,{disallowComments:true,allowTrailingComma:false});check(!errors.length&&tree?.type==='object');
  let count=0;function audit(node,depth){check(++count<=1000&&depth<=32);if(node.type==='object'){const seen=new Set();for(const p of node.children||[]){check(p.children?.length===2&&p.children[0].type==='string'&&!seen.has(p.children[0].value));seen.add(p.children[0].value);audit(p.children[1],depth+1);}}else if(node.type==='array')for(const item of node.children||[])audit(item,depth+1);}
  audit(tree,0);return value;
}
function normalize(event){
  check(event&&typeof event==='object'&&!Array.isArray(event)&&typeof event.path==='string'&&typeof event.httpMethod==='string');
  check(event.path.startsWith(PREFIX+'/')&&['GET','POST'].includes(event.httpMethod));
  const headers=Object.create(null),src=event.headers||{};check(src&&typeof src==='object'&&!Array.isArray(src)&&Object.keys(src).length<=50);
  for(const [k,v] of Object.entries(src)){check(typeof v==='string'&&!/[\r\n\0]/.test(v)&&!Object.hasOwn(headers,k.toLowerCase()));headers[k.toLowerCase()]=v;}
  if(event.multiValueHeaders!==undefined){const m=event.multiValueHeaders;check(m&&typeof m==='object'&&!Array.isArray(m)&&Object.keys(m).length===Object.keys(headers).length);for(const [k,v] of Object.entries(m))check(Array.isArray(v)&&v.length===1&&headers[k.toLowerCase()]===v[0]);}
  const text=event.body??'';check(typeof text==='string');let raw;
  if(event.isBase64Encoded===true){check(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(text));raw=Buffer.from(text,'base64');check(raw.toString('base64')===text);}
  else{check(event.isBase64Encoded===undefined||event.isBase64Encoded===false);check(wellFormed(text));raw=Buffer.from(text,'utf8');}
  check(raw.length<=32768);const decoded=new TextDecoder('utf-8',{fatal:true}).decode(raw);
  return {path:event.path,method:event.httpMethod,headers,body:decoded,rawQuery:event.rawQueryString};
}
function createProductionMain(){
  return async()=>response(503,{available:false,mode:'disabled',realPaymentsEnabled:false,taskAdmissionEnabled:false,recoverySupported:false});
}
function createInternalRouter({billing,oauth,bindings,installation,verifyTaskBinding,recoveryEnabledForOfflineTest=false,productionReady=false,pilot,trial}={}){
  async function owner(headers){
    check(installation&&typeof installation.authenticate==='function');const match=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(headers.authorization||'');check(match);
    const raw=Buffer.from(match[1],'base64url');check(raw.length===32&&raw.toString('base64url')===match[1]);
    let result;if(raw[0]===0x49)result=await installation.authenticate(match[1]);else if(raw[0]===0x42){check(recoveryEnabledForOfflineTest===true&&bindings&&typeof bindings.authenticate==='function');result=await bindings.authenticate(match[1]);}else check(false);
    check(typeof result==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(result));if(pilot)check(pilot.owner(result));return result;
  }
  function jsonBody(req){check((req.headers['content-type']||'').split(';')[0]==='application/json'&&Buffer.byteLength(req.body)<=8192);return json(req.body);}
  async function main(event){
    try{
      const req=normalize(event),path=req.path;
      if(path.startsWith(PREFIX+'/oauth/'))check(recoveryEnabledForOfflineTest===true);
      if(req.method==='GET'&&path===PREFIX+'/status')return response(200,productionReady===true?{available:true,mode:'alipay-official',realPaymentsEnabled:true,taskAdmissionEnabled:true,recoverySupported:false,synthetic:false,testing:false}:{available:false,mode:'disabled',realPaymentsEnabled:false,taskAdmissionEnabled:false,recoverySupported:false});
      if(req.method==='GET'&&path===PREFIX+'/alipay/return'){
        // A browser return is not payment evidence. Show only a fixed link;
        // never echo/query parameters or alter an order here.
        const page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>返回每日百题</title><body><p>请返回每日百题核对付款状态。</p><a href="dailyhundredapp:///payment-return">返回每日百题</a></body></html>';
        const result=response(200,page,'text/html');result.headers['content-security-policy']="default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";return result;
      }
      if(req.method==='POST'&&path===PREFIX+'/oauth/start'){check(oauth);const v=jsonBody(req);exact(v,['requestId','verifierHash']);return response(200,await oauth.start(v));}
      if(req.method==='GET'&&path===PREFIX+'/oauth/callback'){
        check(oauth&&typeof req.rawQuery==='string'&&Buffer.byteLength(req.rawQuery)<=4096);
        const values=Object.create(null);for(const [k,v] of new URLSearchParams(req.rawQuery)){check(!Object.hasOwn(values,k));values[k]=v;}
        exact(values,['state','auth_code']);await oauth.callback({state:values.state,authCode:values.auth_code});
        return response(200,'请返回软件继续。','text/plain');
      }
      if(req.method==='POST'&&[PREFIX+'/oauth/bind',PREFIX+'/oauth/restore'].includes(path)){
        check(bindings);const input=jsonBody(req);exact(input,['state','verifier']);let result;
        if(path.endsWith('/bind')){const m=/^Bearer ([A-Za-z0-9._~+\/-]{32,256})$/.exec(req.headers.authorization||'');check(m);result=await bindings.bind({...input,installationProof:m[1]});}
        else result=await bindings.restore(input);
        const identity=await bindings.authenticate(result.credential);return response(200,{installationId:identity,accessToken:result.credential});
      }
      if(req.method==='POST'&&path===PREFIX+'/oauth/ack'){check(oauth);const input=jsonBody(req);exact(input,['state','verifier']);return response(200,await oauth.ack(input));}
      if(req.method==='POST'&&path===PREFIX+'/installations'){
        check(installation&&typeof installation.register==='function'&&Buffer.byteLength(req.body)<=2048);
        const input=jsonBody(req);exact(input,['requestId','verifier']);if(pilot)check(pilot.registration(input));const registered=await installation.register(input);if(pilot)check(pilot.owner(registered.installationId));return response(201,registered);
      }
      if(req.method==='GET'&&path===PREFIX+'/entitlements'){
        const identity=await owner(req.headers);check(billing&&typeof billing.entitlements==='function');return response(200,await billing.entitlements(identity));
      }
      if(req.method==='POST'&&path===PREFIX+'/alipay/notify'){
        check(billing&&(req.headers['content-type']||'').split(';')[0]==='application/x-www-form-urlencoded');
        await billing.notify(req.body);return response(200,'success','text/plain');
      }
      if(req.method==='POST'&&path===PREFIX+'/orders'){
        const identity=await owner(req.headers),input=jsonBody(req);exact(input,['planId','clientRequestId']);check(billing);if(pilot)check(pilot.order(input));
        const row=await billing.createOrder(identity,input.clientRequestId,input.planId);
        return response(201,{...row,planId:input.planId,checkoutUrl:row.checkoutUrl||null});
      }
      const order=/^\/api\/billing\/orders\/(o[a-f0-9]{63})(\/reconcile)?$/.exec(path);
      if(order&&(req.method==='GET'&&!order[2]||req.method==='POST'&&order[2])){
        const identity=await owner(req.headers);if(req.method==='POST')exact(jsonBody(req),[]);check(billing);
        const row=order[2]?await billing.reconcileOrder(identity,order[1]):await billing.readOrder(identity,order[1]);return response(200,{...row,checkoutUrl:null});
      }
      if(req.method==='POST'&&path===PREFIX+'/runs/reserve'){
        const identity=await owner(req.headers),input=jsonBody(req);exact(input,['runId','taskBinding']);
        check(billing&&billing.admissionPolicy==='paid-only'&&typeof verifyTaskBinding==='function');
        check(await verifyTaskBinding(identity,input.runId,input.taskBinding)===true);
        return response(200,await billing.reserveRun(identity,input.runId,input.taskBinding));
      }
      if(req.method==='GET'&&path===PREFIX+'/runs/active'){
        const identity=await owner(req.headers);check(billing&&typeof billing.listActiveRuns==='function');
        return response(200,{runs:await billing.listActiveRuns(identity)});
      }
      const cancellation=/^\/api\/billing\/runs\/([A-Za-z0-9_-]{1,128})\/cancel$/.exec(path);
      if(req.method==='POST'&&cancellation){
        const identity=await owner(req.headers),input=jsonBody(req);exact(input,['taskBinding']);
        check(billing&&billing.admissionPolicy==='paid-only'&&typeof billing.cancelRun==='function'&&typeof verifyTaskBinding==='function');
        check(await verifyTaskBinding(identity,cancellation[1],input.taskBinding)===true);
        return response(200,await billing.cancelRun(identity,cancellation[1],input.taskBinding));
      }
      const run=/^\/api\/billing\/runs\/([A-Za-z0-9_-]{1,128})\/(confirm|release)$/.exec(path);
      if(req.method==='POST'&&run){
        const identity=await owner(req.headers),input=jsonBody(req);exact(input,[]);check(billing&&billing.admissionPolicy==='paid-only');
        return response(200,run[2]==='confirm'?await billing.confirmStoredRun(identity,run[1]):await billing.releaseStoredRun(identity,run[1]));
      }
      const continuation=/^\/api\/billing\/runs\/([A-Za-z0-9_-]{1,128})\/continue$/.exec(path);
      if(req.method==='POST'&&continuation){
        const identity=await owner(req.headers),input=jsonBody(req);exact(input,['taskBinding']);
        check(billing&&billing.admissionPolicy==='paid-only'&&typeof verifyTaskBinding==='function'&&await verifyTaskBinding(identity,continuation[1],input.taskBinding)===true);
        return response(200,await billing.authorizeContinueRun(identity,continuation[1],input.taskBinding));
      }
      if(req.method==='POST'&&(path===PREFIX+'/trial/activate'||path===PREFIX+'/trial/status'||path===PREFIX+'/trial/reserve'||path===PREFIX+'/trial/confirm'||path===PREFIX+'/trial/resume'||path===PREFIX+'/trial/cancel')){
        const identity=await owner(req.headers),input=jsonBody(req);check(trial);
        const action=path.slice(PREFIX.length+1);
        if(action==='trial/activate'||action==='trial/status'){
          exact(input,['deviceDigest']);
          return response(200,action==='trial/activate'?await trial.activate(identity,input.deviceDigest):await trial.status(identity,input.deviceDigest));
        }
        exact(input,['deviceDigest','runId','taskBinding']);
        check(typeof verifyTaskBinding==='function'&&await verifyTaskBinding(identity,input.runId,input.taskBinding)===true);
        const name=action.slice('trial/'.length);
        return response(200,await trial[name](identity,input.deviceDigest,input.runId,input.taskBinding));
      }
      return response(404,{error:'unavailable'});
    }catch{return event?.path===PREFIX+'/alipay/notify'?response(400,'failure','text/plain'):response(503,{error:'unavailable'});}
  }
  return main;
}
module.exports={createProductionMain,createInternalRouter};
