'use strict';
// Event-function entry is intentionally and unconditionally disabled. It does
// not initialize CloudBase, read env vars/keys, or mount injected components.
const {createProductionMain,createInternalRouter}=require('./billing-event');
const {createInternalCore}=require('./payment-core');
const {createInternalOAuthCore}=require('./oauth-core');
const {createInternalBindingCore}=require('./oauth-bindings');
const {createStableInstallation}=require('./stable-installation');
const main=createProductionMain();

// Offline/internal composition only. No HTTP request may supply these values.
// A real runtime must separately review and construct all dependencies before
// replacing the hard-disabled entry; this function is not a deployment gate.
function createInternalRuntime({db,settings,authenticateInstallation,verifyTaskBinding,now=Date.now,recoveryEnabledForOfflineTest=false,productionReady=false,pilot,freeEnabled=false,ensureFreePolicy}){
  const billing=createInternalCore({db,appId:settings.appId,sellerId:settings.sellerId,privateKey:settings.privateKey,publicKey:settings.publicKey,notifyUrl:settings.notifyUrl,returnUrl:settings.returnUrl});
  const installation=createStableInstallation({db,registrationKey:settings.registrationKey,clock:now});
  const oauth=recoveryEnabledForOfflineTest?createInternalOAuthCore({db,appId:settings.appId,privateKey:settings.privateKey,publicKey:settings.publicKey,identityKey:settings.identityKey,redirectUrl:settings.oauthRedirectUrl,now}):undefined;
  const bindings=recoveryEnabledForOfflineTest?createInternalBindingCore({db,oauth,authenticateInstallation:authenticateInstallation||installation.authenticate,credentialKey:settings.credentialKey,now}):undefined;
  const router=createInternalRouter({billing,oauth,bindings,installation,verifyTaskBinding,recoveryEnabledForOfflineTest,productionReady,pilot});
  if(!freeEnabled)return router;
  if(pilot||typeof settings.registrationKey!=='string'||typeof ensureFreePolicy!=='function')throw Error('unavailable');
  const crypto=require('node:crypto');
  const deviceKey=crypto.createHmac('sha256',Buffer.from(settings.registrationKey,'utf8')).update('dailyhundred-free-device-key-v1').digest();
  const ledger=require('./free-ledger').createLedger({db,deviceKey});deviceKey.fill(0);
  const limiter=require('./free-limiter').createFreeLimiter({db,clock:now});
  const freeRouter=require('./free-api').createFreeApi({baseRouter:router,installation,ledger,verifyTaskBinding,limiter});
  return async event=>{
    if(event&&typeof event.path==='string'&&event.path.startsWith('/api/billing/free/')){
      try{await ensureFreePolicy()}catch{return {statusCode:503,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'},body:JSON.stringify({error:'unavailable'})}}
    }
    return freeRouter(event);
  };
}
module.exports={main,createInternalRuntime};
