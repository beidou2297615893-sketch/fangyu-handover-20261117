package com.futureyyy.tijing.payment

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.futureyyy.tijing.PaidRunEvents

class DailyHundredPaidRunEvents(context:Context):PaidRunEvents {
    private val runtime=PaymentRuntime.get(context)
    private val main=Handler(Looper.getMainLooper())
    private fun perform(id:String,done:(Result<Unit>)->Unit,action:(Long)->Unit) {
        val ticket=runtime.runBilling.ticket(id)
        runtime.enqueue { val result=runCatching { action(ticket) };main.post {
            val safe=if(runtime.runBilling.ticket(id)!=ticket)Result.failure(PaymentFailure("RUN_CHANGED","任务已暂停，请重新核对。")) else result
            done(safe)
        } }
    }
    override fun beforeStart(runId:String,targetPackage:String,bankRevision:String,done:(Result<Unit>)->Unit)=
        perform(runId,done){runtime.runBilling.start(runId,targetPackage,bankRevision,it)}
    override fun beforeSubmit(runId:String,intentId:String,questionId:String,done:(Result<Unit>)->Unit)=
        perform(runId,done){runtime.runBilling.beforeSubmit(runId,intentId,questionId,it)}
    override fun onReceipt(runId:String,intentId:String,receiptId:String,done:(Result<Unit>)->Unit)=
        perform(runId,done){runtime.runBilling.receipt(runId,intentId,receiptId,it);runtime.confirmFreeOnWorker(runId)}
    override fun onStop(runId:String) { runtime.runBilling.invalidate(runId) }
    override fun onAbandon(runId:String) {
        runtime.runBilling.invalidate(runId)
        runtime.enqueue { runCatching { runtime.runBilling.abandon(runId,runtime::releaseUnpaidOnWorker) } }
    }
}
