package com.futureyyy.tijing.payment

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.UUID

/** Native-only access to the already authorized original TiJing model client. */
class GatewaySession internal constructor(val runId:String,val endpoint:String,val model:String,val apiKey:String,val expiresAt:Long) {
    override fun toString()="GatewaySession(redacted)"
}
object GatewaySessionEntry {
    private fun shortHash(value:String):String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(12)

    /**
     * Read-only diagnostic.
     * Does not create, reserve, confirm, release or close any task.
     */
    internal fun logLocalSnapshot(context:Context) {
        val app=context.applicationContext
        runCatching {
            val p=prefs(app)
            val id=p.getString("runId",null)
            val target=p.getString("target",null)
            val row=id?.let { PaymentRuntime.get(app).ledger.read(it) }
            val saved=runCatching {
                SecurePaymentStore(app).read("gateway")?.let { JSONObject(it) }
            }.getOrNull()
            val savedRun=saved?.optString("runId").orEmpty()
            val token=saved?.optString("token").orEmpty()
            val state=saved?.optString("state")?.takeIf { it.isNotBlank() } ?: if(saved!=null) "active" else "missing"
            val expiresAt=saved?.optLong("expiresAt") ?: 0L
            android.util.Log.i(
                "ZhitiSession",
                "local-snapshot " +
                    "id=${id?.let(::shortHash) ?: "missing"} " +
                    "target=${target ?: "missing"} " +
                    "ledgerFound=${row != null} " +
                    "source=${row?.source ?: "missing"} " +
                    "phase=${row?.phase ?: "missing"} " +
                    "submission=${row?.submissionState ?: "missing"} " +
                    "savedState=$state " +
                    "savedRunMatches=${savedRun.isNotBlank() && savedRun == id} " +
                    "tokenPresent=${token.isNotBlank()} " +
                    "expiresValid=${expiresAt > System.currentTimeMillis()}"
            )
        }.onFailure {
            android.util.Log.w("ZhitiSession","local-snapshot-failed type=${it.javaClass.simpleName}",it)
        }
    }
    private const val ORIGIN="https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/api/import-ai/v1/openai"
    private val lock=Any()
    private val main=Handler(Looper.getMainLooper())
    private fun prefs(context:Context)=context.applicationContext.getSharedPreferences("gateway-run-v1",Context.MODE_PRIVATE)
    fun getOrCreateRunId(context:Context,targetPackage:String):String = synchronized(lock) {
        require(targetPackage.isNotBlank() && targetPackage!=context.packageName)
        val p=prefs(context);val existing=p.getString("runId",null);val target=p.getString("target",null)
        val saved=SecurePaymentStore(context.applicationContext).read("gateway")?.let { JSONObject(it) }
        // This method is reached by the user's Start action. A released, unspent
        // reservation with a closed saved session can start a new paid round.
        if(existing!=null) {
            check(target==targetPackage) { "上次答题任务尚未结束，请先核对。" }
            val row=PaymentRuntime.get(context).ledger.read(existing)
            val freshAllowed=gatewayFreshStartAllowed(row?.phase,row?.submissionState,saved?.optString("state"))
            android.util.Log.i(
                "ZhitiSession",
                "run-selection id=${shortHash(existing)} " +
                "target=$targetPackage " +
                "ledgerFound=${row != null} " +
                "phase=${row?.phase ?: "missing"} " +
                "submission=${row?.submissionState ?: "missing"} " +
                "savedState=${saved?.optString("state") ?: "missing"} " +
                "freshAllowed=$freshAllowed"
            )
            if(!freshAllowed) return@synchronized existing
        }
        if(saved!=null && saved.optString("state")!="closed") {
            val savedRun=saved.optString("runId")
            val row=PaymentRuntime.get(context).ledger.read(savedRun)
            check(ID.matches(savedRun) && row!=null && row.target==targetPackage) { "已有答题授权需要核对，请保留记录，不要重新购买。" }
            check(p.edit().putString("runId",savedRun).putString("target",targetPackage).commit()) { "答题记录未能保存。" }
            return@synchronized savedRun
        }
        val id=UUID.randomUUID().toString();check(p.edit().putString("runId",id).putString("target",targetPackage).commit()) { "答题记录未能保存。" }
        android.util.Log.i("ZhitiSession","run-selection id=${shortHash(id)} target=$targetPackage created=true")
        id
    }
    private fun call(path:String,token:String,body:JSONObject?):JSONObject {
        val c=URL(ORIGIN+path).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=30000;c.useCaches=false;c.requestMethod="POST"
            c.setRequestProperty("Authorization","Bearer $token");c.setRequestProperty("Content-Type","application/json")
            if(body!=null) { val b=body.toString().toByteArray(Charsets.UTF_8);c.doOutput=true;c.setFixedLengthStreamingMode(b.size);c.outputStream.use { it.write(b) } }
            val code=c.responseCode
            if(code !in 200..299){
                val preview=runCatching {
                    val raw=(c.errorStream ?: c.inputStream).readBytes().toString(Charsets.UTF_8).take(240)
                    JSONObject(raw).optString("error").ifBlank { "none" }
                }.getOrDefault("unreadable")
                val requestId=sequenceOf(
                    c.getHeaderField("x-request-id"),
                    c.getHeaderField("x-tcb-traceid"),
                    c.getHeaderField("x-cloudbase-request-id"),
                    c.getHeaderField("trace-id")
                ).firstOrNull { !it.isNullOrBlank() } ?: "missing"
                android.util.Log.i("ZhitiSession","http=$code error=$preview requestId=$requestId")
                throw IllegalStateException(when(code) {
                    402 -> "答题权益不足，请先核对付款状态或选择套餐；本次任务记录已保留。"
                    403 -> "答题授权被拒绝，请先核对本次任务；不会自动重新开场。"
                    else -> "答题授权暂未确认，请保留本次任务重试；如需新一轮，请明确结束本轮后重新开始。"
                })
            }
            val out=java.io.ByteArrayOutputStream();c.inputStream.use { input->val buf=ByteArray(2048);while(true) { val n=input.read(buf);if(n<0)break;if(out.size()+n>8192)throw IllegalStateException("答题授权结果无法确认。") ;out.write(buf,0,n) } }
            return JSONObject(out.toString("UTF-8"))
        } finally { c.disconnect() }
    }
    private fun exchange(app:Context,runId:String,targetPackage:String):GatewaySession {
        val runtime=PaymentRuntime.get(app)
        val auth=runtime.gatewayAuthorizationOnWorker(runId,targetPackage)
        val row=runtime.ledger.read(runId)
        android.util.Log.i(
            "ZhitiSession",
            "exchange-preflight id=${shortHash(runId)} " +
            "target=$targetPackage " +
            "ledgerFound=${row != null} " +
            "phase=${row?.phase ?: "missing"} " +
            "submission=${row?.submissionState ?: "missing"} " +
            "authSource=${auth.source} " +
            "bindingPresent=${auth.binding.isNotBlank()} " +
            "deviceDigestPresent=${!auth.deviceDigest.isNullOrBlank()}"
        )
        val payload=JSONObject().put("runId",runId).put("taskBinding",auth.binding).put("source",auth.source)
        auth.deviceDigest?.let { payload.put("deviceDigest",it) }
        val response=call("/session",auth.token,payload);val token=response.getString("token");val expires=response.getLong("expiresAt")
        check(token.matches(Regex("[A-Za-z0-9_-]{43}"))&&response.getInt("limit")==160&&expires>System.currentTimeMillis()) { "答题授权结果无法确认。" }
        SecurePaymentStore(app).write("gateway",JSONObject().put("runId",runId).put("token",token).put("expiresAt",expires).toString())
        return GatewaySession(runId,ORIGIN,"deepseek-flash",token,expires)
    }
    fun begin(context:Context,runId:String,targetPackage:String,done:(Result<GatewaySession>)->Unit) {
        val app=context.applicationContext;val runtime=PaymentRuntime.get(app)
        runtime.enqueue { val result=runCatching {
            synchronized(lock) { val p=prefs(app);check(p.getString("runId",null)==runId && p.getString("target",null)==targetPackage) { "答题任务信息不一致。" } }
            val saved=SecurePaymentStore(app).read("gateway")?.let { JSONObject(it) }
            val savedToken=saved?.optString("token").orEmpty()
            val savedRun=saved?.optString("runId").orEmpty()
            val savedState=saved?.optString("state").orEmpty()
            val savedExp=saved?.optLong("expiresAt") ?: 0L
            if(savedState=="ending") {
                retryPendingEndOnWorker(app)
                throw IllegalStateException("上轮结束状态已核对，请再次开始新的一轮。")
            }

            if(saved!=null && savedState!="closed") {
                check(savedRun==runId) { "已有另一笔答题授权，请保留记录并先核对。" }
                if(savedToken.matches(Regex("[A-Za-z0-9_-]{43}")) && savedExp>System.currentTimeMillis()) {
                    android.util.Log.i("ZhitiSession","reuse existing session")
                    return@runCatching GatewaySession(runId,ORIGIN,"deepseek-flash",savedToken,savedExp)
                }
            }
            check(saved==null || savedRun!=runId || savedState!="closed") { "本次答题授权已结束，请先点结束答题，再核对权益并开始新的一轮。" }
            // Recover only this same server-bound run. A local expiry or an ambiguous
            // HTTP failure cannot authorize closing an old session or charging a new run.
            exchange(app,runId,targetPackage)
        };main.post { done(result) } }
    }
    internal fun hasPendingEnd(app:Context):Boolean =
        SecurePaymentStore(app).read("gateway")?.let { JSONObject(it).optString("state")=="ending" } == true
    /** Payment worker only. Retry an explicit/natural end, never create or charge a run. */
    internal fun retryPendingEndOnWorker(app:Context) {
        val j=SecurePaymentStore(app).read("gateway")?.let { JSONObject(it) } ?: return
        if(j.optString("state")!="ending")return
        endOnWorker(app,j.getString("runId"),j.getString("token"))
    }
    private fun endOnWorker(app:Context,runId:String,token:String) {
        finishGatewayEnd(runId,token,
            persist={ SecurePaymentStore(app).write("gateway",it) },
            requestClose={ call("/session/close",token,null).optBoolean("closed") },
            clearRun={ synchronized(lock) { val p=prefs(app);if(p.getString("runId",null)==runId)check(p.edit().remove("runId").remove("target").commit()) { "答题结束记录未能保存。" } } })
    }

    fun close(context:Context,session:GatewaySession,done:(Result<Unit>)->Unit) {
        val app=context.applicationContext;PaymentRuntime.get(app).enqueue { val result=runCatching {
            endOnWorker(app,session.runId,session.apiKey)
            Unit
        };main.post { done(result) } }
    }
    /** Safe recovery after process death or an uncertain close; never creates another run. */
    fun closePending(context:Context,done:(Result<Unit>)->Unit) {
        val app=context.applicationContext;val runtime=PaymentRuntime.get(app)
        runtime.enqueue { val result=runCatching {
            val p=prefs(app);val id=p.getString("runId",null) ?: return@runCatching Unit
            val saved=SecurePaymentStore(app).read("gateway")
            val j=saved?.let { JSONObject(it) }
            when(gatewayEndAction(id,j?.optString("runId"),j?.optString("state"))) {
                "close" -> {
                    endOnWorker(app,id,j!!.getString("token"))
                }
                "abandon" -> runtime.runBilling.abandon(id,runtime::releaseUnpaidOnWorker)
                "blocked" -> throw IllegalStateException("另一笔答题授权尚未结束，请先核对，记录已保留。")
            }
            synchronized(lock) { check(p.edit().remove("runId").remove("target").commit()) }
            Unit
        };main.post { done(result) } }
    }
}

/** Called only after the user explicitly ends the round. Never infer server state from a timeout. */
internal fun gatewayEndAction(runId:String,savedRun:String?,savedState:String?):String = when {
    savedRun==runId && savedState=="closed" -> "clear"
    savedRun==runId -> "close"
    savedRun==null || savedState=="closed" -> "abandon"
    else -> "blocked"
}

internal fun gatewayFreshStartAllowed(phase:String?,submissionState:String?,savedState:String?):Boolean =
    phase=="released" && submissionState=="none" && savedState=="closed"

internal fun finishGatewayEnd(runId:String,token:String,persist:(String)->Unit,requestClose:()->Boolean,clearRun:()->Unit) {
    persist(JSONObject().put("runId",runId).put("token",token).put("state","ending").toString())
    check(requestClose()) { "本轮已结束，结束状态待核对，请在支付页点核对付款状态。" }
    persist(JSONObject().put("runId",runId).put("state","closed").toString())
    clearRun()
}
