import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  nextBankCount,
  bankCountText,
  runActionForBank,
  importGate,
} from '../src/lib/bankCountState.js';

const REFUSAL = '题库文件无法读取，原文件未改。请先恢复题库或导出备份后再操作。';

test('empty bank stays importable and is not a read failure', () => {
  const next = nextBankCount({ total: 0, offset: 0, records: [] });
  assert.equal(next.readError, false);
  assert.equal(next.count, 0);
  assert.equal(bankCountText(next.count, next.readError), '尚未导入题库');
  assert.deepEqual(importGate(next), { allow: true, needsConfirm: false, error: null });
  assert.equal(runActionForBank({ active: false, readError: false, count: 0 }), 'need-import');
});

test('non-empty bank shows the count and requires replace confirmation', () => {
  const next = nextBankCount({ total: 12, offset: 0, records: [{}] });
  assert.equal(bankCountText(next.count, next.readError), '已导入 12 题');
  assert.deepEqual(importGate(next), { allow: false, needsConfirm: true, error: null });
  assert.equal(runActionForBank({ active: false, readError: false, count: 12 }), 'start');
});

test('read failure is not an empty bank and blocks import and start', () => {
  const next = nextBankCount({ ok: false, error: '题库文件无法读取，原文件未改' });
  assert.equal(next.readError, true);
  assert.equal(next.count, null);
  assert.equal(bankCountText(null, true), '题库文件无法读取，原文件未改');
  assert.equal(importGate({ readError: true, count: null }).allow, false);
  assert.equal(importGate({ readError: true, count: 0 }).error, REFUSAL);
  assert.equal(runActionForBank({ active: false, readError: true, count: null }), 'blocked');
  assert.notEqual(runActionForBank({ active: false, readError: true, count: 0 }), 'need-import');
});

test('a later successful read clears the failure state', () => {
  const failed = nextBankCount({ ok: false });
  const restored = nextBankCount({ total: 4, offset: 0, records: [] });
  assert.equal(failed.readError, true);
  assert.equal(restored.readError, false);
  assert.equal(restored.count, 4);
  assert.equal(bankCountText(restored.count, restored.readError), '已导入 4 题');
  assert.equal(runActionForBank({ active: false, ...restored }), 'start');
});

test('missing bridge result is still an empty count, and an unread count cannot import', () => {
  assert.deepEqual(nextBankCount(null), { count: 0, readError: false });
  assert.equal(bankCountText(null, false), '题库读取中');
  assert.equal(importGate({ readError: false, count: null }).error, '题库状态尚未读取，请稍后再试');
  assert.equal(runActionForBank({ active: true, readError: true, count: null }), 'stop');
});

test('packed page keeps the bank guard and the separate run status', () => {
  const html = readFileSync(
    new URL('../android/app/src/main/assets/web/index.html', import.meta.url),
    'utf8',
  );
  const script = html.match(/src="\.\/assets\/([^"]+\.js)"/);
  assert.ok(script);
  assert.match(script[1], /^index-[A-Za-z0-9_-]+\.js$/);
  const asset = readFileSync(
    new URL(`../android/app/src/main/assets/web/assets/${script[1]}`, import.meta.url),
    'utf8',
  );
  assert.match(asset, /题库文件无法读取，原文件未改/);
  assert.match(asset, /请先恢复题库或导出备份后再操作。/);
  assert.match(asset, /题库无法读取/);
  assert.match(asset, /已准备，等待开始/);
  assert.match(asset, /等待屏幕共享恢复/);
  assert.match(asset, /onNativeFloatingSessionPhase/);
});
