'use strict';
// Event HTTP gateway entry only. Configure handler=index.main, not HTTP bootstrap.
const {createEventMain}=require('./lib/event');
exports.main=createEventMain();
