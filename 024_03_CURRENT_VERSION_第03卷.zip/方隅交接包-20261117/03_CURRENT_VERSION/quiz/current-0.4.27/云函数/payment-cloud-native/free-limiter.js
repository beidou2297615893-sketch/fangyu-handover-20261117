'use strict';
const crypto=require('node:crypto');
const COLLECTION='daily_hundred_free_device_v1';
const check=x=>{if(!x)throw Error('unavailable')};
const sha=x=>crypto.createHash('sha256').update(x,'utf8').digest('hex');
// Limit only new resource-creating operations. Confirmation, release, resume,
// reads and replays bypass the budget so payment/run recovery can complete.
function createFreeLimiter({db,clock=Date.now,ownerLimit=200,globalLimit=10000}){
 check(db&&typeof db.runTransaction==='function'&&typeof clock==='function'&&Number.isSafeInteger(ownerLimit)&&ownerLimit>0&&Number.isSafeInteger(globalLimit)&&globalLimit>0);
 async function read(c,id){const r=await c.doc(id).get();check(r&&!r.code&&Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&r.data._id===id);return r.data}
 async function write(c,id,v){const r=await c.doc(id).set(v);check(r&&!r.code&&(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x?._id===id))))}
 return async function limit(owner,action,payload){
  check(typeof owner==='string'&&owner.length>0&&owner.length<=128&&['migrate','reserve','status','confirm','release','resume','cancel'].includes(action));
  if(action!=='migrate'&&action!=='reserve'&&action!=='cancel')return;
  check(payload&&typeof payload.deviceDigest==='string'&&/^[a-f0-9]{64}$/.test(payload.deviceDigest));
  if(action==='reserve'||action==='cancel')check(typeof payload.runId==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(payload.runId));
  const now=clock();check(Number.isSafeInteger(now)&&now>=0);const day=Math.floor(now/86400000),id='limit-owner-'+sha(owner),operation=sha(JSON.stringify([action==='migrate'?'migrate':'run',payload.deviceDigest,action==='migrate'?'':payload.runId]));
  await db.runTransaction(async tx=>{
   const c=tx.collection(COLLECTION),old=await read(c,id),global=await read(c,'limit-global');
   if(old)check(old.kind==='free-limit-owner'&&Number.isSafeInteger(old.day)&&old.day<=day&&Array.isArray(old.seen)&&old.seen.length<=ownerLimit&&old.seen.every(x=>/^[a-f0-9]{64}$/.test(x)));
   if(global)check(global.kind==='free-limit-global'&&Number.isSafeInteger(global.day)&&global.day<=day&&Number.isSafeInteger(global.count)&&global.count>=0);
   const seen=old&&old.day===day?old.seen:[];if(seen.includes(operation))return;
   const count=global&&global.day===day?global.count:0;check(seen.length<ownerLimit&&count<globalLimit);
   await write(c,id,{kind:'free-limit-owner',day,seen:[...seen,operation]});
   await write(c,'limit-global',{kind:'free-limit-global',day,count:count+1});
  },3);
 };
}
module.exports={createFreeLimiter};
