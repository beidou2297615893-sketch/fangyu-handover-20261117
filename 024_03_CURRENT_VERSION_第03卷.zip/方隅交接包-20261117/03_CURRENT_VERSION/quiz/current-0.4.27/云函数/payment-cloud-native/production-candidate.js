'use strict';
const {validateProductionSettings}=require('./production-config');
const {createInternalRuntime}=require('./runtime');
// Isolated preparation only; this deliberately does not replace runtime.main,
// advertise an enabled payment status, read process.env or attach a listener.
function prepareCandidate({db,env,approvedOrigin,verifyTaskBinding}){try{
  if(!db||typeof db.runTransaction!=='function'||typeof verifyTaskBinding!=='function')throw Error('invalid');
  const settings=validateProductionSettings(env,approvedOrigin);
  const handleForOffline=createInternalRuntime({db,settings,verifyTaskBinding,recoveryEnabledForOfflineTest:false});
  return Object.freeze({handleForOffline});
}catch{throw Error('payment configuration unavailable');}}
module.exports={prepareCandidate};
