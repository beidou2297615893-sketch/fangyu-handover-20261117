'use strict';
// Offline-only internal prototype; no HTTP handler, account binding or order integration.
// Never trust a principal supplied by a caller or use it to merge accounts.
const crypto=require('node:crypto');
const {parseTree}=require('jsonc-parser');
const {AlipaySdk}=require('alipay-sdk');
const COLLECTION='daily_hundred_oauth_v1', RESPONSE='alipay_system_oauth_token_response';
const fail=()=>{throw Error('oauth unavailable');};
const check=v=>{if(!v)fail();};
const sha=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
function exactKeys(obj,keys){check(obj&&typeof obj==='object'&&!Array.isArray(obj)&&Object.keys(obj).sort().join(',')===[...keys].sort().join(','));}
function verify(raw,key){
 check(typeof raw==='string'&&Buffer.byteLength(raw)<262144);
 const decoded=JSON.parse(raw),errors=[],root=parseTree(raw,errors,{disallowComments:true,allowTrailingComma:false});
 check(!errors.length&&root?.type==='object');let count=0;
 function audit(n,d){check(++count<=10000&&d<=64);if(n.type==='object'){const seen=new Set();for(const p of n.children||[]){check(p.type==='property'&&p.children?.length===2&&p.children[0].type==='string'&&!seen.has(p.children[0].value));seen.add(p.children[0].value);audit(p.children[1],d+1);}}else if(n.type==='array')for(const a of n.children||[])audit(a,d+1);}
 audit(root,0);const entries=new Map(root.children.map(p=>[p.children[0].value,p.children[1]]));check(entries.size===2&&entries.has(RESPONSE)&&entries.has('sign'));
 const body=entries.get(RESPONSE),sig=entries.get('sign');check(body.type==='object'&&sig.type==='string'&&/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(sig.value));
 const b=Buffer.from(sig.value,'base64');check(b.length>0&&b.length<=1024&&b.toString('base64')===sig.value&&crypto.verify('RSA-SHA256',Buffer.from(raw.slice(body.offset,body.offset+body.length)),key,b));
 return decoded[RESPONSE];
}
function createProductionOAuthService(){throw Error('production oauth service is disabled');}
function createInternalOAuthCore({db,appId,privateKey,publicKey,identityKey,redirectUrl,now=Date.now}){
 check(db&&typeof db.runTransaction==='function'&&typeof appId==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(appId));
 check(typeof privateKey==='string'&&typeof publicKey==='string'&&publicKey.includes('-----BEGIN PUBLIC KEY-----')&&typeof identityKey==='string'&&Buffer.byteLength(identityKey)>=32);
 const k=crypto.createPublicKey(publicKey);check(k.asymmetricKeyType==='rsa'&&k.asymmetricKeyDetails?.modulusLength>=2048);
 const u=new URL(redirectUrl);check(u.protocol==='https:'&&!u.username&&!u.password&&!u.hash&&!u.search);

 function ok(r){if(r?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:r.code});check(r&&!r.code);return r;}
 async function read(ref,id){const r=ok(await ref.get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&r.data._id===id);const {_id,...v}=r.data;return v;}
 async function write(ref,id,row){const r=ok(await ref.set(row));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x?._id===id)));}
 function requireToken(v){check(typeof v==='string'&&/^[A-Za-z0-9_-]{43}$/.test(v));}
 async function start(input){try{
   exactKeys(input,['requestId','verifierHash']);const {requestId,verifierHash}=input;requireToken(requestId);check(typeof verifierHash==='string'&&/^[a-f0-9]{64}$/.test(verifierHash));
   const state=crypto.createHmac('sha256',identityKey).update(JSON.stringify(['oauth-state-v1',appId,requestId,verifierHash])).digest('base64url');
   const id='session-'+sha(state),rid='request-'+sha(requestId),created=now();check(Number.isSafeInteger(created));
   await db.runTransaction(async tx=>{const c=tx.collection(COLLECTION),ref=c.doc(id),rref=c.doc(rid),req=await read(rref,rid);if(req){check(req.stateHash===sha(state)&&req.verifierHash===verifierHash);const old=await read(ref,id);check(old&&old.stateHash===sha(state)&&old.verifierHash===verifierHash&&now()<old.expires);return;}check(!await read(ref,id));await write(ref,id,{kind:'session',stateHash:sha(state),verifierHash,status:'pending',expires:created+600000});await write(rref,rid,{kind:'request',stateHash:sha(state),verifierHash});},3);
   let url=new URL('https://openauth.alipay.com/oauth2/publicAppAuthorize.htm');url.searchParams.set('app_id',appId);url.searchParams.set('scope','auth_base');url.searchParams.set('redirect_uri',redirectUrl);url.searchParams.set('state',state);return {state,url:url.toString()};
 }catch{fail();}}
 async function callback(input){try{
   exactKeys(input,['state','authCode']);const {state,authCode}=input;requireToken(state);check(typeof authCode==='string'&&/^[A-Za-z0-9_-]{1,512}$/.test(authCode));
   const id='session-'+sha(state),cid='code-'+sha(JSON.stringify([appId,authCode]));
   await db.runTransaction(async tx=>{let c=tx.collection(COLLECTION),ref=c.doc(id),cr=c.doc(cid),row=await read(ref,id);check(row&&row.status==='pending'&&row.stateHash===sha(state)&&now()<row.expires&&!await read(cr,cid));await write(ref,id,{...row,status:'exchanging'});await write(cr,cid,{kind:'spent-code',created:now()});},3);
   const sdk=new AlipaySdk({appId,privateKey,alipayPublicKey:publicKey,keyType:'PKCS8',signType:'RSA2',camelcase:false,gateway:'https://openapi.alipay.com/gateway.do'});
   let checked=false;sdk.checkResponseSign=(raw,responseKey)=>{check(responseKey===RESPONSE);verify(raw,k);checked=true;};
   const result=await sdk.exec('alipay.system.oauth.token',{grant_type:'authorization_code',code:authCode},{validateSign:true});
   check(checked&&result&&!result.error_response&&(!Object.hasOwn(result,'code')||result.code==='10000')&&typeof result.open_id==='string'&&/^[A-Za-z0-9_-]{1,256}$/.test(result.open_id));
   const principal=crypto.createHmac('sha256',identityKey).update(JSON.stringify([appId,result.open_id])).digest('hex');
   await db.runTransaction(async tx=>{let ref=tx.collection(COLLECTION).doc(id),row=await read(ref,id);check(row&&row.status==='exchanging'&&now()<row.expires);await write(ref,id,{...row,status:'ready',principal});},3);
   return {status:'ready'};
 }catch{fail();}}
 async function get(input,ack){try{
   exactKeys(input,['state','verifier']);let {state,verifier}=input;requireToken(state);requireToken(verifier);let id='session-'+sha(state);
   return await db.runTransaction(async tx=>{let ref=tx.collection(COLLECTION).doc(id),row=await read(ref,id);check(row&&row.stateHash===sha(state)&&now()<row.expires&&crypto.timingSafeEqual(Buffer.from(row.verifierHash,'hex'),Buffer.from(sha(verifier),'hex')));
     check(['ready','acknowledged'].includes(row.status)&&/^[a-f0-9]{64}$/.test(row.principal));
     if(ack){if(row.status==='ready')await write(ref,id,{...row,status:'acknowledged'});return {status:'acknowledged'};}return {status:'ready',principal:row.principal};},3);
 }catch{fail();}}
 return Object.freeze({start,callback,result:input=>get(input,false),ack:input=>get(input,true)});
}
module.exports={createInternalOAuthCore,createProductionOAuthService};
