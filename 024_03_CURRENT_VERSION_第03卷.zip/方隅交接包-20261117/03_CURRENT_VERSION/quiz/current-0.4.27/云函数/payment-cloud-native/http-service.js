'use strict';
// Local-only HTTP contract. No actual cloud, account provider or payment network.
const crypto=require('node:crypto');
const {parseTree}=require('jsonc-parser');
const {createOfflineSettlement}=require('./settlement-offline');
const digest=value=>crypto.createHash('sha256').update(value).digest('hex');
function createProductionService(){throw Error('production payment service is disabled');}
function createOfflineService(){
  const ledger=createOfflineSettlement();
  const alice=crypto.randomBytes(32).toString('base64url'),bob=crypto.randomBytes(32).toString('base64url');
  const credentials=new Map([[digest(alice),'owner-A'],[digest(bob),'owner-B']]);
  function owner(req){
    const match=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.headers.authorization||'');
    return match&&credentials.get(digest(match[1]));
  }
  async function body(req){
    const parts=[];let size=0;
    for await(const part of req){size+=part.length;if(size>32768)throw Error('body too large');parts.push(part);}
    return Buffer.concat(parts).toString('utf8');
  }
  function parseOrder(raw){
    const input=JSON.parse(raw),errors=[],root=parseTree(raw,errors,{disallowComments:true,allowTrailingComma:false});
    if(errors.length||root?.type!=='object')throw Error('invalid request');
    const keys=new Set();
    for(const prop of root.children||[]){const key=prop.children?.[0]?.value;if(typeof key!=='string'||keys.has(key))throw Error('duplicate field');keys.add(key);}
    return input;
  }
  function send(res,status,data,type='application/json'){
    res.writeHead(status,{'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff'});
    res.end(type==='application/json'?JSON.stringify(data):data);
  }
  async function handler(req,res){
    try{
      const url=new URL(req.url,'http://local.invalid');
      if(req.method==='POST'&&url.pathname==='/alipay/notify'){
        if((req.headers['content-type']||'').split(';')[0]!=='application/x-www-form-urlencoded')return send(res,400,'failure','text/plain');
        await ledger.settle(await body(req));return send(res,200,'success','text/plain');
      }
      if(req.method==='POST'&&url.pathname==='/orders'){
        const identity=owner(req);if(!identity)return send(res,401,{error:'unauthorized'});
        if((req.headers['content-type']||'').split(';')[0]!=='application/json')return send(res,400,{error:'invalid request'});
        const input=parseOrder(await body(req));
        if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).sort().join(',')!=='clientRequestId,planId'||input.planId!=='once'||typeof input.clientRequestId!=='string'||!/^[A-Za-z0-9_-]{1,64}$/.test(input.clientRequestId))return send(res,400,{error:'invalid request'});
        const id='o-'+digest(JSON.stringify([identity,input.clientRequestId])).slice(0,32);
        ledger.addOrder(id,identity);
        const row=ledger.snapshot().orders.find(o=>o.orderId===id&&o.owner===identity);
        return send(res,201,{id,planId:row.plan,amountFen:row.amountFen,status:row.status});
      }
      if(req.method==='GET'&&/^\/orders\/[A-Za-z0-9_-]{1,64}$/.test(url.pathname)){
        const identity=owner(req);if(!identity)return send(res,401,{error:'unauthorized'});
        const id=url.pathname.slice('/orders/'.length),row=ledger.snapshot().orders.find(o=>o.orderId===id&&o.owner===identity);
        if(!row)return send(res,404,{error:'not found'});
        return send(res,200,{id,planId:row.plan,amountFen:row.amountFen,status:row.status});
      }
      return send(res,404,{error:'not found'});
    }catch{
      if(!res.headersSent&&req.url==='/alipay/notify')return send(res,400,'failure','text/plain');
      if(!res.headersSent)return send(res,400,{error:'request unavailable'});
      res.destroy();
    }
  }
  // The test fixture exposes signing and query replay to the test runner, never via HTTP.
  return {handler,credentials:{alice,bob},makeNotice:ledger.makeNotice,makeQuery:ledger.makeQuery,prepareQuery:ledger.prepareQuery,snapshot:ledger.snapshot,close:ledger.close};
}
module.exports={createProductionService,createOfflineService};
