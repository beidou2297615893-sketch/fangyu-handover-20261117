'use strict';
// Shared account/grant transaction helpers; fixed-size account summary.
const crypto=require('node:crypto');
const sha=v=>crypto.createHash('sha256').update(v,'utf8').digest('hex');
const check=v=>{if(!v)throw Error('wallet unavailable');};
const int=v=>Number.isSafeInteger(v)&&v>=0;
const accountId=owner=>'account-'+sha(owner),grantId=order=>'grant-'+order;
function blank(owner){return {kind:'account',schema:2,owner,freeUsed:0,freeReserved:0,creditHead:null,creditTail:null,creditAvailable:0,creditReserved:0,memberUntil:0,memberFrozen:false,memberNeedsReview:false,memberRevision:0,reviewCount:0,revision:0,activeRuns:[]};}
function account(row,owner){
  check(row&&row.kind==='account'&&row.schema===2&&row.owner===owner&&int(row.freeUsed)&&int(row.freeReserved)&&row.freeUsed+row.freeReserved<=3&&int(row.creditAvailable)&&int(row.creditReserved)&&int(row.reviewCount)&&int(row.revision)&&int(row.memberUntil)&&int(row.memberRevision)&&typeof row.memberFrozen==='boolean'&&typeof row.memberNeedsReview==='boolean');
  check((row.creditHead===null)===(row.creditTail===null));
  check((row.creditHead===null)===(row.creditAvailable===0));
  check(Array.isArray(row.activeRuns)&&row.activeRuns.length<=16&&new Set(row.activeRuns).size===row.activeRuns.length&&row.activeRuns.every(x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(x)));
  for(const x of [row.creditHead,row.creditTail])check(x===null||(typeof x==='string'&&/^o[a-f0-9]{63}$/.test(x)));
  return row;
}
function grant(row,owner,order){
  check(row&&row.kind==='grant'&&row.owner===owner&&row.orderId===order&&['once','week','month'].includes(row.plan)&&['paid','review','refunded'].includes(row.state)&&int(row.grantedAt)&&int(row.used)&&int(row.reserved));
  if(row.plan==='once')check(row.used+row.reserved<=1);
  return row;
}
function createWalletIO({read,write}){
  async function load(c,owner){return account(await read(c.doc(accountId(owner)),accountId(owner))||blank(owner),owner);}
  async function loadGrant(c,owner,order){return grant(await read(c.doc(grantId(order)),grantId(order)),owner,order);}
  async function save(c,row){check(int(row.revision+1));row.revision++;await write(c.doc(accountId(row.owner)),accountId(row.owner),row);}
  async function saveGrant(c,row){await write(c.doc(grantId(row.orderId)),grantId(row.orderId),row);}
  async function appendCredit(c,a,g){
    check(g.plan==='once'&&g.state==='paid'&&g.used===0&&g.reserved===0&&g.prev===null&&g.next===null);
    if(a.creditTail){const tail=await loadGrant(c,a.owner,a.creditTail);check(tail.state==='paid'&&tail.next===null&&tail.reserved===0&&tail.used===0);tail.next=g.orderId;g.prev=tail.orderId;await saveGrant(c,tail);}
    else a.creditHead=g.orderId;
    a.creditTail=g.orderId;check(int(a.creditAvailable+1));a.creditAvailable++;
  }
  async function popCredit(c,a){
    check(a.creditHead!==null);const g=await loadGrant(c,a.owner,a.creditHead);
    check(g.plan==='once'&&g.state==='paid'&&g.prev===null&&g.used===0&&g.reserved===0);
    if(g.next){const next=await loadGrant(c,a.owner,g.next);check(next.prev===g.orderId);next.prev=null;await saveGrant(c,next);a.creditHead=next.orderId;}
    else {check(a.creditTail===g.orderId);a.creditHead=null;a.creditTail=null;}
    check(a.creditAvailable>0&&int(a.creditReserved+1));a.creditAvailable--;a.creditReserved++;
    g.prev=null;g.next=null;g.reserved=1;return g;
  }
  async function unlinkCredit(c,a,g){
    check(g.plan==='once'&&g.used===0&&g.reserved===0);
    if(g.prev){const prev=await loadGrant(c,a.owner,g.prev);check(prev.next===g.orderId);prev.next=g.next;await saveGrant(c,prev);}
    else {check(a.creditHead===g.orderId);a.creditHead=g.next;}
    if(g.next){const next=await loadGrant(c,a.owner,g.next);check(next.prev===g.orderId);next.prev=g.prev;await saveGrant(c,next);}
    else {check(a.creditTail===g.orderId);a.creditTail=g.prev;}
    check(a.creditAvailable>0);a.creditAvailable--;g.prev=null;g.next=null;
  }
  async function freeze(c,a,g){
    if(g.state!=='paid')return;
    if(g.plan==='once'&&g.used===0&&g.reserved===0)await unlinkCredit(c,a,g);
    if(g.plan==='once'&&g.reserved===1){check(a.creditReserved>0);a.creditReserved--;}
    if(g.plan!=='once'){a.memberFrozen=true;a.memberNeedsReview=true;check(int(a.memberRevision+1));a.memberRevision++;}
    check(int(a.reviewCount+1));a.reviewCount++;
    g.state='review';
  }
  return {load,loadGrant,save,saveGrant,appendCredit,popCredit,unlinkCredit,freeze};
}
module.exports={accountId,grantId,blank,account,grant,createWalletIO};
