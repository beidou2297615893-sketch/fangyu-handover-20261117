'use strict';
// Offline-only. No HTTP routes or payment integration. The integrator must supply
// a real server-side installation authenticator; never adapt an owner client field
// into this contract. The OAuth object must be the trusted internal OAuth core.
const crypto=require('node:crypto');
const COLLECTION='daily_hundred_oauth_binding_v1';
const sha=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
const check=v=>{if(!v)throw Error('binding unavailable');};
const exact=(o,ks)=>check(o&&typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).sort().join(',')===[...ks].sort().join(','));
function createProductionBindingService(){throw Error('production binding service is disabled');}
function createInternalBindingCore({db,oauth,authenticateInstallation,credentialKey,now=Date.now}){
 check(db&&typeof db.runTransaction==='function'&&oauth&&typeof oauth.result==='function');
 check(typeof credentialKey==='string'&&Buffer.byteLength(credentialKey)>=32);
 // credentialKey must be a separate cryptographically random secret, never the
 // OAuth HMAC key. Rotate only with a key-version migration strategy; emergency
 // rotation invalidates issued credentials and requires OAuth recovery again.
 function ok(r){if(r?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:r.code});check(r&&!r.code);return r;}
 async function read(ref,id){let r=ok(await ref.get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&r.data._id===id);let {_id,...row}=r.data;return row;}
 async function write(ref,id,row){let r=ok(await ref.set(row));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x?._id===id)));}
 function validateOwner(owner){check(typeof owner==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(owner));}
 async function resolve(input,bind){try{
   exact(input,bind?['state','verifier','installationProof']:['state','verifier']);
   const {state,verifier}=input;
   let owner;
   if(bind){check(typeof authenticateInstallation==='function');owner=await authenticateInstallation(input.installationProof);validateOwner(owner);}
   const identity=await oauth.result({state,verifier});check(identity?.status==='ready'&&typeof identity.principal==='string'&&/^[a-f0-9]{64}$/.test(identity.principal));
   const subject=identity.principal,tokenBytes=crypto.createHmac('sha256',credentialKey).update(JSON.stringify(['oauth-credential-v1',state,subject])).digest();
   tokenBytes[0]=0x42;const token=tokenBytes.toString('base64url');
   const subjectId='subject-'+subject,tokenId='credential-'+sha(token),created=now();check(Number.isSafeInteger(created));
   await db.runTransaction(async tx=>{
    const c=tx.collection(COLLECTION),sref=c.doc(subjectId),subjectRow=await read(sref,subjectId);let epoch;
    if(bind){
      const ownerId='owner-'+sha(owner),oref=c.doc(ownerId),ownerRow=await read(oref,ownerId);
      check(!subjectRow||(subjectRow.kind==='subject'&&subjectRow.owner===owner&&subjectRow.subject===subject));
      check(!ownerRow||(ownerRow.kind==='owner'&&ownerRow.owner===owner&&ownerRow.subject===subject));
      if(subjectRow||ownerRow){check(subjectRow&&ownerRow&&Number.isSafeInteger(ownerRow.epoch)&&ownerRow.epoch>=0);epoch=ownerRow.epoch;}
      else{epoch=0;await write(sref,subjectId,{kind:'subject',subject,owner});await write(oref,ownerId,{kind:'owner',owner,subject,epoch});}
    }else{
      check(subjectRow&&subjectRow.kind==='subject'&&subjectRow.subject===subject);owner=subjectRow.owner;validateOwner(owner);
      const ownerId='owner-'+sha(owner),oref=c.doc(ownerId),ownerRow=await read(oref,ownerId);
      check(ownerRow&&ownerRow.kind==='owner'&&ownerRow.owner===owner&&ownerRow.subject===subject&&Number.isSafeInteger(ownerRow.epoch)&&ownerRow.epoch>=0);
      // A restored account advances the epoch once per OAuth state, invalidating
      // older bound credentials and its original installation token. Replaying
      // the same state after a lost response returns the same epoch/token.
      const restoreId='restore-'+sha(state),restoreRef=c.doc(restoreId),oldRestore=await read(restoreRef,restoreId);
      if(oldRestore){check(oldRestore.kind==='restore'&&oldRestore.owner===owner&&oldRestore.subject===subject&&oldRestore.epoch===ownerRow.epoch);epoch=oldRestore.epoch;}
      else{epoch=ownerRow.epoch+1;check(Number.isSafeInteger(epoch));await write(oref,ownerId,{...ownerRow,epoch});await write(restoreRef,restoreId,{kind:'restore',owner,subject,epoch});}
      const ic=tx.collection('daily_hundred_installation_v1'),revokeId='revoked-'+sha(owner),revokeRef=ic.doc(revokeId),revoked=await read(revokeRef,revokeId);
      if(revoked)check(revoked.kind==='revoked'&&revoked.owner===owner);else await write(revokeRef,revokeId,{kind:'revoked',owner});
    }
    const tref=c.doc(tokenId),existing=await read(tref,tokenId);
    if(existing)check(existing.kind==='credential'&&existing.owner===owner&&existing.subject===subject&&existing.epoch===epoch&&Number.isSafeInteger(existing.expires)&&now()<existing.expires);
    else await write(tref,tokenId,{kind:'credential',owner,subject,epoch,expires:created+30*24*60*60*1000});
   },3);
   return {credential:token};
 }catch{throw Error('binding unavailable');}}
 async function authenticate(token){try{
   check(typeof token==='string'&&/^[A-Za-z0-9_-]{43}$/.test(token)&&Buffer.from(token,'base64url')[0]===0x42);const id='credential-'+sha(token);
   return await db.runTransaction(async tx=>{const c=tx.collection(COLLECTION),row=await read(c.doc(id),id);check(row&&row.kind==='credential'&&Number.isSafeInteger(row.epoch)&&now()<row.expires&&typeof row.subject==='string'&&/^[a-f0-9]{64}$/.test(row.subject));validateOwner(row.owner);const sid='subject-'+row.subject,oid='owner-'+sha(row.owner),subject=await read(c.doc(sid),sid),owner=await read(c.doc(oid),oid);check(subject&&subject.kind==='subject'&&subject.owner===row.owner&&subject.subject===row.subject&&owner&&owner.kind==='owner'&&owner.owner===row.owner&&owner.subject===row.subject&&owner.epoch===row.epoch);return row.owner;},3);
 }catch{throw Error('binding unavailable');}}
 return Object.freeze({bind:input=>resolve(input,true),restore:input=>resolve(input,false),authenticate});
}
module.exports={createInternalBindingCore,createProductionBindingService};
