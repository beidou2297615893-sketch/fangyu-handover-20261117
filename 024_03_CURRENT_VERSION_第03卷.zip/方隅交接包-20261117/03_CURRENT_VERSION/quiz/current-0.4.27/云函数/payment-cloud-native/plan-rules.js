'use strict';
// Sale catalog for new orders. Historical quotes stay so an already created
// order can still be checked at the amount that was stored on it.
const TRIAL_MS=72*60*60*1000;
const DAY_MS=86400000;
const SALE=Object.freeze({
  week:Object.freeze({fen:490,amount:'4.90',credits:0,days:7}),
  month:Object.freeze({fen:990,amount:'9.90',credits:0,days:30})
});
const KNOWN=Object.freeze({
  once:Object.freeze([Object.freeze({fen:100,amount:'1.00',credits:1,days:0})]),
  week:Object.freeze([
    Object.freeze({fen:490,amount:'4.90',credits:0,days:7}),
    Object.freeze({fen:590,amount:'5.90',credits:0,days:7})
  ]),
  month:Object.freeze([Object.freeze({fen:990,amount:'9.90',credits:0,days:30})])
});
function salePlan(plan){return Object.hasOwn(SALE,plan)?SALE[plan]:null}
function quoteFor(plan,fen){
  const rows=KNOWN[plan];
  if(!rows||!Number.isSafeInteger(fen))return null;
  return rows.find(row=>row.fen===fen)||null;
}
function membershipUntil(currentUntil,grantedAt,days){
  if(!Number.isSafeInteger(currentUntil)||currentUntil<0||!Number.isSafeInteger(grantedAt)||grantedAt<0||!Number.isSafeInteger(days)||days<0)throw Error('payment operation unavailable');
  const end=Math.max(currentUntil,grantedAt)+days*DAY_MS;
  if(!Number.isSafeInteger(end))throw Error('payment operation unavailable');
  return end;
}
function trialExpiry(startedAt){
  if(!Number.isSafeInteger(startedAt)||startedAt<0)throw Error('trial unavailable');
  const end=startedAt+TRIAL_MS;
  if(!Number.isSafeInteger(end))throw Error('trial unavailable');
  return end;
}
module.exports={TRIAL_MS,DAY_MS,SALE,KNOWN,salePlan,quoteFor,membershipUntil,trialExpiry};
