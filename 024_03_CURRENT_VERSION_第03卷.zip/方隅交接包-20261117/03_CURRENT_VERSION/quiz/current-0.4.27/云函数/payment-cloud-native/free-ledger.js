'use strict';
// Offline candidate only: the caller MUST authenticate the installation before
// invoking this core. Device digest is a quota key, never an authentication key.
const crypto=require('node:crypto');
const COLLECTION='daily_hundred_free_device_v1';
const check=v=>{if(!v)throw Error('free admission unavailable');};
function createLedger({db,deviceKey}){
  check(db&&typeof db.runTransaction==='function'&&Buffer.isBuffer(deviceKey)&&deviceKey.length>=32);
  const key=Buffer.from(deviceKey);
  function hmac(v){return crypto.createHmac('sha256',key).update(v,'utf8').digest('hex')}
  function deviceId(d){check(typeof d==='string'&&/^[a-f0-9]{64}$/.test(d));return 'device-'+hmac('device\0'+d)}
  function runId(d,r){check(typeof r==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(r));return 'run-'+hmac('run\0'+d+'\0'+r)}
  function validBinding(b){check(typeof b==='string'&&/^[a-f0-9]{64}$/.test(b))}
  function good(result){if(result?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:result.code});check(result&&!result.code);return result}
  async function read(c,id){const r=good(await c.doc(id).get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&r.data._id===id);const {_id,...v}=r.data;return v}
  async function write(c,id,value){const r=good(await c.doc(id).set(value));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x?._id===id)))}
  function validLedger(a){check(a&&a.kind==='free-device-v1'&&Array.isArray(a.used)&&Array.isArray(a.reserved));const ids=[...a.used,...a.reserved];check(ids.length<=3&&new Set(ids).size===ids.length&&ids.every(x=>typeof x==='string'&&/^run-[a-f0-9]{64}$/.test(x)));return a}
  function summary(a){validLedger(a);return {used:a.used.length,reserved:a.reserved.length,remaining:3-a.used.length-a.reserved.length}}
  async function migrate(d,legacy){
    const device=deviceId(d);check(legacy&&typeof legacy==='object'&&!Array.isArray(legacy));
    const entries=Object.entries(legacy);check(entries.length<=3);
    for(const [r,s] of entries){runId(d,r);check(s==='used'||s==='reserved')}
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),existing=await read(c,device);
      // Merge snapshots monotonically: never erase or downgrade a server slot.
      const a=existing?validLedger(existing):{kind:'free-device-v1',used:[],reserved:[]};
      for(const [r,s] of entries){
        const id=runId(d,r), prior=await read(c,id);
        if(a.used.includes(id)){check(prior&&prior.status==='used');continue}
        if(a.reserved.includes(id)){
          check(prior&&prior.status==='reserved');
          if(s==='used'){a.reserved=a.reserved.filter(x=>x!==id);a.used.push(id);prior.status='used';await write(c,id,prior)}
          continue;
        }
        check(!prior||prior.status==='released');check(a.used.length+a.reserved.length<3);
        a[s].push(id);await write(c,id,{kind:'legacy-run',status:s,binding:null});
      }
      await write(c,device,a);return summary(a);
    },3);
  }
  async function status(d){const device=deviceId(d);return db.runTransaction(async tx=>summary(await read(tx.collection(COLLECTION),device)),3)}
  async function reserve(d,r,b){
    const device=deviceId(d),id=runId(d,r);validBinding(b);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),a=validLedger(await read(c,device)),prior=await read(c,id);
      if(prior){check(prior.kind==='free-run'&&prior.binding===b&&prior.status==='reserved'&&a.reserved.includes(id));return {runId:r,status:'reserved'}}
      check(a.used.length+a.reserved.length<3);a.reserved.push(id);
      await write(c,id,{kind:'free-run',status:'reserved',binding:b});await write(c,device,a);
      return {runId:r,status:'reserved'};
    },3);
  }
  async function finish(d,r,b,target){
    const device=deviceId(d),id=runId(d,r);validBinding(b);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),a=validLedger(await read(c,device)),p=await read(c,id);
      check(p&&p.kind==='free-run'&&p.binding===b);
      if(p.status===target){check(target==='released'?!a.reserved.includes(id):a.used.includes(id));return {runId:r,status:target}}
      check(p.status==='reserved'&&a.reserved.includes(id));a.reserved=a.reserved.filter(x=>x!==id);
      if(target==='used')a.used.push(id);p.status=target;
      await write(c,id,p);await write(c,device,a);return {runId:r,status:target};
    },3);
  }
  async function resume(d,r,b){
    const device=deviceId(d),id=runId(d,r);validBinding(b);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),a=validLedger(await read(c,device)),p=await read(c,id);
      check(p&&p.kind==='free-run'&&p.binding===b&&p.status==='used'&&a.used.includes(id));
      return {runId:r,status:'authorized'};
    },3);
  }
  async function cancel(d,r,b){
    const device=deviceId(d),id=runId(d,r);validBinding(b);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),a=validLedger(await read(c,device)),p=await read(c,id);
      if(p){check(p.kind==='free-run'&&p.binding===b);if(p.status==='cancelled'){check(!a.reserved.includes(id)&&!a.used.includes(id));return {runId:r,status:'cancelled'}}
        check(p.status==='reserved'&&a.reserved.includes(id));a.reserved=a.reserved.filter(x=>x!==id);p.status='cancelled';await write(c,id,p);await write(c,device,a);
      }else{await write(c,id,{kind:'free-run',status:'cancelled',binding:b})}
      return {runId:r,status:'cancelled'};
    },3);
  }
  async function exists(d){
    const device=deviceId(d);
    return db.runTransaction(async tx=>{
      const row=await read(tx.collection(COLLECTION),device);
      return row!=null;
    },3);
  }
  return Object.freeze({migrate,status,reserve,resume,cancel,exists,confirm:(d,r,b)=>finish(d,r,b,'used'),release:(d,r,b)=>finish(d,r,b,'released')});
}
module.exports={createLedger};
