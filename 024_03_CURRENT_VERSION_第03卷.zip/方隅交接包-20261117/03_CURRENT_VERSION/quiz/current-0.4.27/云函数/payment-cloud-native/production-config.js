'use strict';
const crypto=require('node:crypto');
// Server-process-only preparation; no HTTP handler calls this yet. Secrets
// must come from protected deployment configuration, never from an APK/event.
function validateProductionSettings(env,approvedOrigin){try{
  const check=v=>{if(!v)throw Error('invalid');};
  check(env&&typeof env==='object'&&env.BILLING_ENABLED==='true');
  const appId=env.ALIPAY_APP_ID,sellerId=env.ALIPAY_SELLER_ID;
  check(typeof appId==='string'&&/^\d{16}$/.test(appId)&&typeof sellerId==='string'&&/^\d{16}$/.test(sellerId));
  const privateKey=env.ALIPAY_PRIVATE_KEY,providerInput=env.ALIPAY_PUBLIC_KEY;
  check(typeof privateKey==='string'&&privateKey.length<=16384&&privateKey.startsWith('-----BEGIN PRIVATE KEY-----')&&typeof providerInput==='string'&&providerInput.length<=16384);
  const appKey=crypto.createPrivateKey(privateKey);let providerKey;
  if(providerInput.startsWith('-----BEGIN PUBLIC KEY-----'))providerKey=crypto.createPublicKey(providerInput);
  else{
    const encodedKey=providerInput.replace(/[ \t\r\n]/g,'');check(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encodedKey));
    const bytes=Buffer.from(encodedKey,'base64');check(bytes.length>0&&bytes.toString('base64')===encodedKey);
    providerKey=crypto.createPublicKey({key:bytes,format:'der',type:'spki'});
  }
  check(appKey.asymmetricKeyType==='rsa'&&appKey.asymmetricKeyDetails?.modulusLength>=2048&&providerKey.asymmetricKeyType==='rsa'&&providerKey.asymmetricKeyDetails?.modulusLength>=2048);
  const appPublic=crypto.createPublicKey(appKey).export({type:'spki',format:'der'}),providerPublic=providerKey.export({type:'spki',format:'der'});
  check(!appPublic.equals(providerPublic));
  const publicKey=providerKey.export({type:'spki',format:'pem'}).toString();
  const encoded=env.BILLING_MASTER_KEY;check(typeof encoded==='string'&&/^[A-Za-z0-9+/]{43}=$/.test(encoded));
  const master=Buffer.from(encoded,'base64');check(master.length===32&&master.toString('base64')===encoded);
  const approved=new URL(approvedOrigin);check(approved.protocol==='https:'&&!approved.username&&!approved.password&&!approved.search&&!approved.hash&&approved.pathname==='/'&&approved.origin===approvedOrigin);
  const validEndpoint=(value,path)=>{check(typeof value==='string');const u=new URL(value);check(u.protocol==='https:'&&u.origin===approved.origin&&!u.username&&!u.password&&!u.search&&!u.hash&&u.pathname===path&&u.toString()===value);return value;};
  const notifyUrl=validEndpoint(env.BILLING_NOTIFY_URL,'/api/billing/alipay/notify'),returnUrl=validEndpoint(env.BILLING_RETURN_URL,'/api/billing/alipay/return');
  const derive=label=>crypto.createHmac('sha256',master).update('dailyhundred-payment-v1\0').update(label).digest('hex');
  return {appId,sellerId,privateKey,publicKey,notifyUrl,returnUrl,registrationKey:derive('registration'),identityKey:derive('identity'),credentialKey:derive('credential'),recoveryEnabled:false,admissionPolicy:'paid-only'};
}catch{throw Error('payment configuration unavailable');}}
module.exports={validateProductionSettings};
