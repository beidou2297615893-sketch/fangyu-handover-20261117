'use strict';
const crypto=require('node:crypto');
const sha=value=>crypto.createHash('sha256').update(value,'utf8').digest('hex');
const validDigest=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
const eq=(a,b)=>validDigest(a)&&validDigest(b)&&crypto.timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex'));
// Pilot is deliberately mandatory for this candidate's enabled entry.
function pilotPolicy(env,registrationKey){
 if(env.BILLING_PILOT_ENABLED!=='true'||!/^i49[a-f0-9]{30}$/.test(env.BILLING_PILOT_OWNER||'')||!validDigest(env.BILLING_PILOT_REGISTRATION_HASH)||!validDigest(env.BILLING_PILOT_ORDER_HASH)||typeof registrationKey!=='string'||Buffer.byteLength(registrationKey)<32)throw Error('pilot unavailable');
 const owner=env.BILLING_PILOT_OWNER,registrationHash=env.BILLING_PILOT_REGISTRATION_HASH,orderHash=env.BILLING_PILOT_ORDER_HASH;
 return Object.freeze({
  registration(input){if(typeof input?.requestId!=='string'||typeof input?.verifier!=='string')return false;const values=JSON.stringify([input.requestId,input.verifier]);if(!eq(sha(values),registrationHash))return false;const bytes=crypto.createHmac('sha256',Buffer.from(registrationKey,'utf8')).update('dailyhundred-installation-owner-v2\0').update(values).digest().subarray(0,16);bytes[0]=0x49;return 'i'+bytes.toString('hex')===owner},
  owner(identity){return identity===owner},
  order(input){return input?.planId==='once'&&typeof input.clientRequestId==='string'&&eq(sha(input.clientRequestId),orderHash)}
 });
}
module.exports={pilotPolicy};
