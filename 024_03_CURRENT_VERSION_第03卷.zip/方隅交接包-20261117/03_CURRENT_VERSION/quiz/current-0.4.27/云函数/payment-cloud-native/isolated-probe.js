'use strict';
// Test-only direct-invocation diagnostic. This module cannot take payments,
// access merchant keys, emit orders, create grants or call user-selected URLs.
const crypto=require('node:crypto'),https=require('node:https');
const COLLECTION='daily_hundred_payment_probe_v1';
const validEvent=e=>e&&typeof e==='object'&&!Array.isArray(e)&&Object.keys(e).length===1&&e.action==='diagnostic';
const check=v=>{if(!v)throw Error('diagnostic unavailable');};
function fixedProviderHead(){return new Promise((resolve,reject)=>{
  const req=https.request({protocol:'https:',hostname:'openapi.alipay.com',port:443,path:'/gateway.do',method:'HEAD',timeout:5000},res=>{
    res.resume();resolve(Number.isInteger(res.statusCode)&&res.statusCode>=200&&res.statusCode<=599);
  });
  req.on('timeout',()=>req.destroy(new Error('timeout')));req.on('error',reject);req.end();
});}
function createProbe({db,httpsHead=fixedProviderHead,randomId=()=>crypto.randomBytes(16).toString('hex')}){
  check(db&&typeof db.runTransaction==='function'&&typeof httpsHead==='function'&&typeof randomId==='function');
  return async function probe(event){
    if(!validEvent(event))return {paymentEnabled:false};
    let database=false,alipayTls=false;
    try{
      const suffix=randomId();check(typeof suffix==='string'&&/^[a-f0-9]{32}$/.test(suffix));const id='probe-'+suffix;
      await db.runTransaction(async tx=>{
        const ref=tx.collection(COLLECTION).doc(id),old=await ref.get();
        check(old&&!old.code&&old.data===null);
        const written=await ref.set({kind:'diagnostic',value:suffix});
        check(written&&!written.code&&(written.updated===1||(written.updated===0&&Array.isArray(written.upserted)&&written.upserted.some(x=>x?._id===id))));
        const read=await ref.get();check(read&&!read.code&&read.data?._id===id&&read.data.kind==='diagnostic'&&read.data.value===suffix);
        const deleted=await ref.remove();check(deleted&&!deleted.code&&deleted.deleted===1);
      },3);database=true;
    }catch{/* Do not emit internal errors or customer data. */}
    try{alipayTls=(await httpsHead())===true;}catch{/* Do not emit TLS details. */}
    return {paymentEnabled:false,database,alipayTls};
  };
}
// Only the platform's authenticated direct invocation is suitable for this
// diagnostic. Do not attach an HTTP trigger or function URL to this entry.
async function main(event){
  if(!validEvent(event))return {paymentEnabled:false};
  try{
    const sdk=require('@cloudbase/node-sdk'),app=sdk.init({env:sdk.SYMBOL_CURRENT_ENV});
    return await createProbe({db:app.database({throwOnCode:true,timeout:2500})})(event);
  }catch{return {paymentEnabled:false,database:false,alipayTls:false};}
}
module.exports={createProbe,main};
