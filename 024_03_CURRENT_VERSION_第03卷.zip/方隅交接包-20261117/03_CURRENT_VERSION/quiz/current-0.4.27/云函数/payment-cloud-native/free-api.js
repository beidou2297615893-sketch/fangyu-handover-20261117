'use strict';
// Offline-only wrapper; the production entry and paid-only router stay unchanged.
const crypto=require('node:crypto');
const {parseTree}=require('jsonc-parser');
const PREFIX='/api/billing/free/';
const check=x=>{if(!x)throw Error('unavailable')};
const response=(statusCode,value)=>({statusCode,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'},body:JSON.stringify(value)});
function parseObject(raw){
  check(typeof raw==='string'&&Buffer.byteLength(raw,'utf8')<=8192);
  const errors=[],tree=parseTree(raw,errors,{disallowComments:true,allowTrailingComma:false});check(!errors.length&&tree?.type==='object');
  let nodes=0;function visit(n,depth){check(++nodes<=100&&depth<=5);if(n.type==='object'){const keys=new Set();for(const p of n.children||[]){check(p.children?.length===2&&!keys.has(p.children[0].value));keys.add(p.children[0].value);visit(p.children[1],depth+1)}}else if(n.type==='array'){for(const c of n.children||[])visit(c,depth+1)}}
  visit(tree,0);return JSON.parse(raw);
}
function exact(obj,names){check(obj&&typeof obj==='object'&&!Array.isArray(obj)&&Object.keys(obj).sort().join(',')===[...names].sort().join(','))}
function createFreeApi({baseRouter,installation,ledger,verifyTaskBinding,limiter=async()=>{}}){
  check(typeof baseRouter==='function'&&installation&&typeof installation.authenticate==='function'&&ledger&&typeof verifyTaskBinding==='function');
  return async function handle(event){
    if(!event||typeof event.path!=='string'||!event.path.startsWith(PREFIX))return baseRouter(event);
    try{
      check(event.httpMethod==='POST'&&(event.isBase64Encoded===undefined||event.isBase64Encoded===false)&&event.multiValueHeaders===undefined);
      const inputHeaders=event.headers||{},headers=Object.create(null);check(inputHeaders&&typeof inputHeaders==='object'&&!Array.isArray(inputHeaders)&&Object.keys(inputHeaders).length<=50);
      for(const [key,value] of Object.entries(inputHeaders)){const k=key.toLowerCase();check(typeof value==='string'&&!Object.hasOwn(headers,k)&&!/[\r\n\0]/.test(value));headers[k]=value}
      check((headers['content-type']||'').split(';')[0].toLowerCase()==='application/json');
      const m=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(headers.authorization||'');check(m);
      const raw=Buffer.from(m[1],'base64url');check(raw.length===32&&raw[0]===0x49&&raw.toString('base64url')===m[1]);
      const owner=await installation.authenticate(m[1]);check(typeof owner==='string'&&/^i[a-f0-9]{32}$/.test(owner));
      const payload=parseObject(event.body),action=event.path.slice(PREFIX.length);
      if(action==='migrate'){
        exact(payload,['deviceDigest','legacyEntries']);await limiter(owner,action,payload);return response(200,await ledger.migrate(payload.deviceDigest,payload.legacyEntries));
      }
      if(action==='status'){
        exact(payload,['deviceDigest']);return response(200,await ledger.status(payload.deviceDigest));
      }
      check(['reserve','confirm','release','resume','cancel'].includes(action));
      exact(payload,['deviceDigest','runId','taskBinding']);
      check(typeof payload.taskBinding==='string'&&/^[a-f0-9]{64}$/.test(payload.taskBinding));
      check(await verifyTaskBinding(owner,payload.runId,payload.taskBinding)===true);
      // A newly registered installation can see the device quota, but cannot
      // claim the prior installation's active run solely via a device digest.
      const scopedBinding=crypto.createHash('sha256').update(JSON.stringify(['free-owner-binding-v1',owner,payload.taskBinding])).digest('hex');
      await limiter(owner,action,payload);const result=await ledger[action](payload.deviceDigest,payload.runId,scopedBinding);
      return response(200,{ownerId:owner,runId:result.runId,taskBinding:payload.taskBinding,source:'free',status:result.status==='used'?'confirmed':result.status});
    }catch{return response(503,{error:'unavailable'})}
  };
}
module.exports={createFreeApi};
