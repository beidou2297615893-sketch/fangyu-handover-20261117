'use strict';
// Internal SDK transaction core. Caller must verify owner and native binding.
const crypto=require('node:crypto');
const {createWalletIO}=require('./payment-wallet');
const COLLECTION='daily_hundred_payment_v1';
const sha=v=>crypto.createHash('sha256').update(v,'utf8').digest('hex');
const check=v=>{if(!v)throw Error('run unavailable');};
function valid(owner,runId,binding){check(typeof owner==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(owner)&&typeof runId==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(runId)&&(binding===null||typeof binding==='string'&&/^[a-f0-9]{64}$/.test(binding)));}
function createInternalRunCore({db,clock=Date.now,cancelLimits={ownerPerDay:100,globalPerDay:3000,total:100000}}){
  check(db&&typeof db.runTransaction==='function'&&typeof clock==='function');
  check(cancelLimits&&Object.keys(cancelLimits).sort().join(',')==='globalPerDay,ownerPerDay,total'&&
    ['ownerPerDay','globalPerDay','total'].every(k=>Number.isSafeInteger(cancelLimits[k])&&cancelLimits[k]>0)&&
    cancelLimits.ownerPerDay<=cancelLimits.globalPerDay&&cancelLimits.globalPerDay<=cancelLimits.total);
  function ok(r){if(r?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:r.code});check(r&&!r.code);return r;}
  async function read(ref,id){const r=ok(await ref.get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&typeof r.data==='object'&&!Array.isArray(r.data)&&r.data._id===id);const {_id,...v}=r.data;return v;}
  async function write(ref,id,value){const r=ok(await ref.set(value));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x?._id===id)));}
  const wallet=createWalletIO({read,write});
  const id=(owner,runId)=>'run-'+sha(JSON.stringify([owner,runId]));
  const publicRun=r=>({ownerId:r.ownerId,runId:r.runId,taskBinding:r.taskBinding,status:r.status,source:r.source});
  function checkRun(r,owner,runId,binding){check(r&&r.kind==='run'&&r.ownerId===owner&&r.runId===runId&&typeof r.taskBinding==='string'&&/^[a-f0-9]{64}$/.test(r.taskBinding)&&(binding===null||r.taskBinding===binding)&&['reserved','confirmed','released'].includes(r.status)&&['credit','subscription'].includes(r.source));return r;}
  async function checkPaid(c,a,r){
    if(r.source==='subscription')check(!a.memberFrozen&&Number.isSafeInteger(r.memberRevision)&&r.memberRevision===a.memberRevision);
    if(r.source==='credit'){const g=await wallet.loadGrant(c,a.owner,r.grantId);check(g.plan==='once'&&g.state==='paid');return g;}
    return null;
  }
  async function reserve(owner,runId,binding){
    try{
      valid(owner,runId,binding);check(binding!==null);const now=clock();check(Number.isSafeInteger(now)&&now>=0);const rid=id(owner,runId);
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),ref=c.doc(rid),prior=await read(ref,rid),a=await wallet.load(c,owner);
        if(prior){
          const r=checkRun(prior,owner,runId,binding);check(r.status!=='released'&&(r.status!=='reserved'||a.activeRuns.includes(runId)));
          // A terminal confirmed receipt is only an idempotent read, not a new
          // authorization. Reserved membership may resume only before expiry.
          if(r.status==='reserved'){await checkPaid(c,a,r);if(r.source==='subscription')check(a.memberUntil>now);}
          return publicRun(r);
        }
        check(a.activeRuns.length<16&&!a.activeRuns.includes(runId));
        let source,grantId=null,memberRevision=null;
        // Cloud admission is paid-only. The existing Android local ledger owns
        // the three free uses; re-granting them here would reset allowances.
        if(!a.memberFrozen&&a.memberUntil>now){source='subscription';memberRevision=a.memberRevision;}
        else{source='credit';const g=await wallet.popCredit(c,a);grantId=g.orderId;await wallet.saveGrant(c,g);}
        const run={kind:'run',ownerId:owner,runId,taskBinding:binding,status:'reserved',source,grantId,memberRevision};a.activeRuns.push(runId);
        await wallet.save(c,a);await write(ref,rid,run);return publicRun(run);
      },3);
    }catch{throw Error('run unavailable');}
  }
  async function finish(owner,runId,binding,status){
    try{
      valid(owner,runId,binding);check(['confirmed','released'].includes(status));const rid=id(owner,runId);
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),ref=c.doc(rid),r=checkRun(await read(ref,rid),owner,runId,binding),a=await wallet.load(c,owner);
        if(r.status===status)return publicRun(r);check(r.status==='reserved'&&a.activeRuns.includes(runId));
        let g=null;
        if(status==='confirmed')g=await checkPaid(c,a,r);
        if(r.source==='credit'){
          g=g||await wallet.loadGrant(c,owner,r.grantId);check(g.reserved===1);g.reserved=0;
          if(g.state==='paid'){check(a.creditReserved>0);a.creditReserved--;}
          if(status==='confirmed')g.used=1;
          else if(g.state==='paid')await wallet.appendCredit(c,a,g);
          await wallet.saveGrant(c,g);
        }
        r.status=status;a.activeRuns=a.activeRuns.filter(x=>x!==runId);await wallet.save(c,a);await write(ref,rid,r);return publicRun(r);
      },3);
    }catch{throw Error('run unavailable');}
  }
  // Only the native caller can know no submission was dispatched. This
  // operation supplies an atomic barrier against a delayed reserve request;
  // it is not evidence that any third-party submission did or did not happen.
  async function cancel(owner,runId,binding){
    try{
      valid(owner,runId,binding);check(binding!==null);const rid=id(owner,runId),now=clock();
      check(Number.isSafeInteger(now)&&now>=0);const day=Math.floor(now/86400000);
      const result={ownerId:owner,runId,taskBinding:binding,status:'cancelled'};
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),ref=c.doc(rid),prior=await read(ref,rid);
        if(!prior){
          // Never expire a tombstone while legacy reserve calls lack an expiry.
          // The hard total cap bounds persistent rows. Per-owner/global daily
          // quotas limit abuse; existing cancellations and releases remain usable.
          const globalId='cancel-limit-global-v1',ownerId='cancel-limit-owner-'+sha(owner);
          const globalRef=c.doc(globalId),ownerRef=c.doc(ownerId);
          const g=await read(globalRef,globalId),o=await read(ownerRef,ownerId);
          if(g)check(g.kind==='cancel-limit-global-v1'&&Number.isSafeInteger(g.day)&&g.day<=day&&Number.isSafeInteger(g.count)&&g.count>=0&&Number.isSafeInteger(g.total)&&g.total>=0);
          if(o)check(o.kind==='cancel-limit-owner-v1'&&o.owner===owner&&Number.isSafeInteger(o.day)&&o.day<=day&&Number.isSafeInteger(o.count)&&o.count>=0);
          const globalCount=g&&g.day===day?g.count:0,ownerCount=o&&o.day===day?o.count:0,total=g?.total??0;
          check(globalCount<cancelLimits.globalPerDay&&ownerCount<cancelLimits.ownerPerDay&&total<cancelLimits.total);
          // Use the same immutable document id as reserve: competing commits
          // must conflict instead of creating unrelated rows.
          await write(ref,rid,{kind:'run_cancelled',ownerId:owner,runId,taskBinding:binding});
          await write(globalRef,globalId,{kind:'cancel-limit-global-v1',day,count:globalCount+1,total:total+1});
          await write(ownerRef,ownerId,{kind:'cancel-limit-owner-v1',owner,day,count:ownerCount+1});
          return result;
        }
        if(prior.kind==='run_cancelled'){
          check(prior.ownerId===owner&&prior.runId===runId&&prior.taskBinding===binding);return result;
        }
        const r=checkRun(prior,owner,runId,binding);
        if(r.status==='released')return result;
        check(r.status==='reserved');const a=await wallet.load(c,owner);check(a.activeRuns.includes(runId));
        if(r.source==='credit'){
          const g=await wallet.loadGrant(c,owner,r.grantId);check(g.reserved===1);g.reserved=0;
          if(g.state==='paid'){check(a.creditReserved>0);a.creditReserved--;await wallet.appendCredit(c,a,g);}
          await wallet.saveGrant(c,g);
        }
        r.status='released';a.activeRuns=a.activeRuns.filter(x=>x!==runId);
        await wallet.save(c,a);await write(ref,rid,r);return result;
      },3);
    }catch{throw Error('run unavailable');}
  }
  async function listActive(owner){
    try{
      valid(owner,'placeholder',null);
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),a=await wallet.load(c,owner),rows=[];
        for(const runId of a.activeRuns){const rid=id(owner,runId),r=checkRun(await read(c.doc(rid),rid),owner,runId,null);check(r.status==='reserved');rows.push(publicRun(r));}
        return rows;
      },3);
    }catch{throw Error('run unavailable');}
  }
  async function authorizeContinue(owner,runId,binding){
    try{
      valid(owner,runId,binding);check(binding!==null);const now=clock();check(Number.isSafeInteger(now)&&now>=0);const rid=id(owner,runId);
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),r=checkRun(await read(c.doc(rid),rid),owner,runId,binding),a=await wallet.load(c,owner);
        check(r.status==='confirmed');const g=await checkPaid(c,a,r);
        if(r.source==='subscription')check(a.memberUntil>now);
        if(r.source==='credit')check(g&&g.used===1&&g.reserved===0);
        return {...publicRun(r),status:'authorized'};
      },3);
    }catch{throw Error('run unavailable');}
  }
  return Object.freeze({reserve,cancel,confirm:(o,r,b)=>finish(o,r,b,'confirmed'),release:(o,r,b)=>finish(o,r,b,'released'),confirmStored:(o,r)=>finish(o,r,null,'confirmed'),releaseStored:(o,r)=>finish(o,r,null,'released'),listActive,authorizeContinue});
}
module.exports={createInternalRunCore};
