'use strict';
// ONLY an offline cryptographic/transaction experiment. No production entry.
const crypto=require('node:crypto');
const {AlipaySdk}=require('alipay-sdk');
const {Db}=require('../../outputs/managed-import-cloudbase/node_modules/@cloudbase/database/dist/commonjs/index.js');
const {EJSON}=require('../../outputs/managed-import-cloudbase/node_modules/bson');
const {verifySignedQuery}=require('./query-verifier');
const COLLECTION='daily_hundred_payment_test_only',APP='offline-app',SELLER='offline-seller';
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
const check=(condition)=>{if(!condition)throw Error('unavailable');};
function createProductionSettlement(){throw Error('production settlement is disabled');}
function createOfflineSettlement(){
  const key=crypto.generateKeyPairSync('rsa',{modulusLength:2048,privateKeyEncoding:{type:'pkcs8',format:'pem'},publicKeyEncoding:{type:'spki',format:'pem'}});
  const sdk=new AlipaySdk({appId:APP,privateKey:key.privateKey,alipayPublicKey:key.publicKey,keyType:'PKCS8',signType:'RSA2',gateway:'https://example.invalid/gateway.do'});
  const proofMap=new WeakMap(),oldReqClass=Db.reqClass;
  const state={docs:new Map(),txs:new Map(),next:0,version:0,conflicts:0,unknown:false,queries:0,closed:false,queryResponse:null};
  function putOrder(orderId,owner){
    check(/^[A-Za-z0-9_-]{1,64}$/.test(orderId)&&/^[A-Za-z0-9_-]{1,64}$/.test(owner));
    const previous=state.docs.get('order-'+orderId);
    if(previous){check(previous.owner===owner&&previous.plan==='once'&&previous.amountFen===100);return;}
    state.docs.set('order-'+orderId,{kind:'order',orderId,owner,plan:'once',amountFen:100,status:'pending'});state.version++;
  }
  putOrder('order-A','owner-A');
  Db.reqClass=class{
    async send(action,p={}){
      check(!state.closed);
      if(action==='database.startTransaction'){const transactionId='t'+(++state.next);state.txs.set(transactionId,{docs:structuredClone(state.docs),version:state.version});return {transactionId};}
      if(action==='database.abortTransaction'){state.txs.delete(p.transactionId);return {};}
      if(action==='database.commitTransaction'){
        const tx=state.txs.get(p.transactionId);check(tx);
        if(state.conflicts){state.conflicts--;return {code:'DATABASE_TRANSACTION_CONFLICT'};}
        if(tx.version!==state.version)return {code:'DATABASE_TRANSACTION_CONFLICT'};
        state.docs=tx.docs;state.version++;state.txs.delete(p.transactionId);
        if(state.unknown){state.unknown=false;throw Error('lost reply');}return {};
      }
      check(p.collectionName===COLLECTION);const tx=state.txs.get(p.transactionId);check(tx);
      const id=JSON.parse(p.query)._id;
      if(action==='database.getDocument')return {data:{list:tx.docs.has(id)?[JSON.stringify({_id:id,...tx.docs.get(id)})]:[]}};
      if(action==='database.modifyDocument'){tx.docs.set(id,EJSON.parse(p.data));return {data:{updated:1,upsert_id:id}};}
      throw Error('unexpected');
    }
  };
  const db=new Db({throwOnCode:true});
  function parseNotice(raw){
    check(typeof raw==='string'&&Buffer.byteLength(raw)<=32768);const fields=Object.create(null);
    for(const [k,v] of new URLSearchParams(raw)){check(!Object.hasOwn(fields,k));fields[k]=v;}
    check(Object.keys(fields).sort().join(',')==='app_id,out_trade_no,seller_id,sign,sign_type,total_amount,trade_no,trade_status');
    check(fields.sign_type==='RSA2'&&fields.app_id===APP&&fields.seller_id===SELLER);
    check(fields.trade_status==='TRADE_SUCCESS'&&sdk.checkNotifySignV2(fields));
    check(/^[A-Za-z0-9_-]{1,64}$/.test(fields.out_trade_no)&&/^[A-Za-z0-9_-]{1,64}$/.test(fields.trade_no)&&/^[0-9]{1,7}\.[0-9]{2}$/.test(fields.total_amount));
    return fields;
  }
  async function applyProof(proof){
    const value=proofMap.get(proof);check(value);proofMap.delete(proof);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),orderRef=c.doc('order-'+value.orderId),tradeRef=c.doc('trade-'+hash(value.tradeNo)),grantRef=c.doc('grant-'+value.orderId);
      async function read(ref,id){const r=await ref.get();check(r&&!r.code&&Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data._id===id);const {_id,...v}=r.data;return v;}
      async function write(ref,v){const r=await ref.set(v);if(r?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:r.code});check(r&&!r.code&&r.updated===1);}
      const order=await read(orderRef,'order-'+value.orderId),trade=await read(tradeRef,'trade-'+hash(value.tradeNo)),grant=await read(grantRef,'grant-'+value.orderId);
      check(order&&order.orderId===value.orderId&&order.amountFen===value.amountFen&&order.plan==='once');
      check(!trade||trade.orderId===order.orderId);
      if(order.status==='paid'){check(trade&&grant&&grant.owner===order.owner&&grant.tradeNo===value.tradeNo);return {status:'paid'};}
      check(order.status==='pending'&&!trade&&!grant);
      await write(orderRef,{...order,status:'paid'});
      await write(tradeRef,{kind:'trade',orderId:order.orderId,tradeNo:value.tradeNo});
      await write(grantRef,{kind:'grant',orderId:order.orderId,owner:order.owner,tradeNo:value.tradeNo,credits:1});
      return {status:'paid'};
    },3);
  }
  async function settle(noticeRaw){
    try{
      check(!state.closed);const notice=parseNotice(noticeRaw);state.queries++;
      // Fixed local-only replay controlled by the fixture, never request data.
      const result=verifySignedQuery(state.queryResponse,key.publicKey);
      check(result.code==='10000'&&result.out_trade_no===notice.out_trade_no&&result.trade_no===notice.trade_no&&result.total_amount===notice.total_amount&&result.trade_status==='TRADE_SUCCESS');
      const [whole,cents]=notice.total_amount.split('.');const amountFen=Number(whole)*100+Number(cents);
      check(Number.isSafeInteger(amountFen)&&amountFen>0);
      const proof=Object.freeze({});proofMap.set(proof,{orderId:notice.out_trade_no,tradeNo:notice.trade_no,amountFen});
      return await applyProof(proof);
    }catch{throw Error('offline settlement unavailable');}
  }
  function makeNotice(overrides={}){
    const fields={app_id:APP,seller_id:SELLER,out_trade_no:'order-A',trade_no:'trade-A',total_amount:'1.00',trade_status:'TRADE_SUCCESS',sign_type:'RSA2',...overrides};
    const canonical=Object.keys(fields).filter(k=>k!=='sign_type').sort().map(k=>k+'='+fields[k]).join('&');
    fields.sign=crypto.sign('RSA-SHA256',Buffer.from(canonical),key.privateKey).toString('base64');return new URLSearchParams(fields).toString();
  }
  function makeQuery(overrides={}){
    const body=JSON.stringify({code:'10000',out_trade_no:'order-A',trade_no:'trade-A',total_amount:'1.00',trade_status:'TRADE_SUCCESS',...overrides});
    const sign=crypto.sign('RSA-SHA256',Buffer.from(body),key.privateKey).toString('base64');return '{"alipay_trade_query_response":'+body+',"sign":"'+sign+'"}';
  }
  function snapshot(){const all=[...state.docs.values()].map(x=>structuredClone(x));return {orders:all.filter(x=>x.kind==='order'),trades:all.filter(x=>x.kind==='trade'),grants:all.filter(x=>x.kind==='grant')};}
  return {settle,makeNotice,makeQuery,snapshot,addOrder:putOrder,prepareQuery:raw=>{state.queryResponse=raw;},conflicts:n=>{state.conflicts=n;},unknownCommit:()=>{state.unknown=true;},queryCount:()=>state.queries,close:()=>{state.closed=true;Db.reqClass=oldReqClass;}};
}
module.exports={createProductionSettlement,createOfflineSettlement};
