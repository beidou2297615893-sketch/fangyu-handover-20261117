'use strict';
// Server-owned 72-hour trial. The phone clock is never an input.
// A failed later read must not delete a record that was already written.
const crypto=require('node:crypto');
const {trialExpiry}=require('./plan-rules');
const COLLECTION='daily_hundred_trial_v1';
const check=v=>{if(!v)throw Error('trial unavailable');};
function createTrial({db,clock=Date.now,hasPriorFreeDevice}){
  check(db&&typeof db.runTransaction==='function'&&typeof clock==='function'&&typeof hasPriorFreeDevice==='function');
  function good(result){if(result?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:result.code});check(result&&!result.code);return result}
  async function read(c,id){const r=good(await c.doc(id).get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&r.data._id===id);const {_id,...v}=r.data;return v}
  async function write(c,id,value){const r=good(await c.doc(id).set(value));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x&&x._id===id)))}
  function digestOk(d){check(typeof d==='string'&&/^[a-f0-9]{64}$/.test(d))}
  function ownerOk(owner){check(typeof owner==='string'&&/^i[a-f0-9]{32}$/.test(owner))}
  function docId(d){return 'trial-'+crypto.createHash('sha256').update('trial-device-v1\0'+d,'utf8').digest('hex')}
  function runDoc(d,runId){check(typeof runId==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(runId));return 'run-'+crypto.createHash('sha256').update('trial-run-v1\0'+d+'\0'+runId,'utf8').digest('hex')}
  function bindingOk(b){check(typeof b==='string'&&/^[a-f0-9]{64}$/.test(b))}
  function nowOrThrow(){const now=clock();check(Number.isSafeInteger(now)&&now>=0);return now}
  function view(row,now){
    const eligible=row.eligible===true;
    const active=eligible&&Number.isSafeInteger(row.expiresAt)&&row.expiresAt>now;
    return {eligible,reason:row.reason,startedAt:row.startedAt,expiresAt:row.expiresAt,serverNow:now,active};
  }
  async function status(owner,digest){
    ownerOk(owner);digestOk(digest);const now=nowOrThrow();const row=await db.runTransaction(async tx=>read(tx.collection(COLLECTION),docId(digest)),3);
    if(!row)return {eligible:false,reason:'not-activated',startedAt:null,expiresAt:null,serverNow:now,active:false};
    check(row.kind==='trial-v1'&&row.deviceDigest===digest);return view(row,now);
  }
  async function activate(owner,digest){
    ownerOk(owner);digestOk(digest);const now=nowOrThrow();
    const prior=await hasPriorFreeDevice(digest);check(typeof prior==='boolean');
    const id=docId(digest);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),existing=await read(c,id);
      if(existing){check(existing.kind==='trial-v1'&&existing.deviceDigest===digest);return view(existing,now)}
      const row=prior
        ?{kind:'trial-v1',eligible:false,reason:'existing-free-device',deviceDigest:digest,startedAt:null,expiresAt:null,activatedBy:owner}
        :{kind:'trial-v1',eligible:true,reason:'new-device',deviceDigest:digest,startedAt:now,expiresAt:trialExpiry(now),activatedBy:owner};
      await write(c,id,row);return view(row,now);
    },3);
  }
  async function requireActive(c,digest,now){
    const row=await read(c,docId(digest));
    check(row&&row.kind==='trial-v1'&&row.deviceDigest===digest&&row.eligible===true&&Number.isSafeInteger(row.expiresAt)&&row.expiresAt>now);
    return row;
  }
  function publicRun(owner,runId,binding,status){return {ownerId:owner,runId,taskBinding:binding,source:'trial',status}}
  async function reserve(owner,digest,runId,binding){
    ownerOk(owner);digestOk(digest);bindingOk(binding);const now=nowOrThrow();const id=runDoc(digest,runId);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION);await requireActive(c,digest,now);const prior=await read(c,id);
      if(prior){check(prior.kind==='trial-run'&&prior.ownerId===owner&&prior.runId===runId&&prior.binding===binding&&prior.status==='reserved');return publicRun(owner,runId,binding,'reserved')}
      await write(c,id,{kind:'trial-run',ownerId:owner,runId,binding,status:'reserved'});
      return publicRun(owner,runId,binding,'reserved');
    },3);
  }
  async function confirm(owner,digest,runId,binding){
    ownerOk(owner);digestOk(digest);bindingOk(binding);const id=runDoc(digest,runId);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),prior=await read(c,id);
      check(prior&&prior.kind==='trial-run'&&prior.ownerId===owner&&prior.runId===runId&&prior.binding===binding);
      if(prior.status==='confirmed')return publicRun(owner,runId,binding,'confirmed');
      check(prior.status==='reserved');prior.status='confirmed';await write(c,id,prior);
      return publicRun(owner,runId,binding,'confirmed');
    },3);
  }
  async function resume(owner,digest,runId,binding){
    ownerOk(owner);digestOk(digest);bindingOk(binding);const now=nowOrThrow();const id=runDoc(digest,runId);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION);await requireActive(c,digest,now);const prior=await read(c,id);
      check(prior&&prior.kind==='trial-run'&&prior.ownerId===owner&&prior.binding===binding&&prior.status==='confirmed');
      return publicRun(owner,runId,binding,'authorized');
    },3);
  }
  async function cancel(owner,digest,runId,binding){
    ownerOk(owner);digestOk(digest);bindingOk(binding);const id=runDoc(digest,runId);
    return db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION),prior=await read(c,id);
      if(prior){
        check(prior.kind==='trial-run'&&prior.ownerId===owner&&prior.binding===binding);
        if(prior.status==='cancelled')return publicRun(owner,runId,binding,'cancelled');
        if(prior.status==='confirmed'){const error=Error('trial run confirmed');error.code='TRIAL_RUN_CONFIRMED';throw error;}
        check(prior.status==='reserved');prior.status='cancelled';await write(c,id,prior);
      }else await write(c,id,{kind:'trial-run',ownerId:owner,runId,binding,status:'cancelled'});
      return publicRun(owner,runId,binding,'cancelled');
    },3);
  }
  return Object.freeze({status,activate,reserve,confirm,resume,cancel});
}
module.exports={createTrial,COLLECTION};
