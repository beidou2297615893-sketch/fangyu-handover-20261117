'use strict';
// Offline research only: no production SDK integration and no user credentials.
const crypto=require('node:crypto');
const {parseTree}=require('jsonc-parser');
const EXPECTED='alipay_trade_query_response';
const REFUND_EXPECTED='alipay_trade_fastpay_refund_query_response';

function verifySignedResponse(raw,publicKey,expected){
  try{
    if(![EXPECTED,REFUND_EXPECTED].includes(expected))throw Error();
    if(typeof raw!=='string'||Buffer.byteLength(raw,'utf8')>262144||typeof publicKey!=='string'||!publicKey.includes('-----BEGIN PUBLIC KEY-----'))throw Error();
    const key=crypto.createPublicKey(publicKey);
    if(key.asymmetricKeyType!=='rsa'||!key.asymmetricKeyDetails||key.asymmetricKeyDetails.modulusLength<2048)throw Error();
    // Native strict parser first: JSONC must never permit comments/trailing text.
    const decoded=JSON.parse(raw),errors=[];
    const root=parseTree(raw,errors,{disallowComments:true,allowTrailingComma:false});
    if(errors.length||!root||root.type!=='object'||!decoded||typeof decoded!=='object'||Array.isArray(decoded))throw Error();
    let visited=0;
    function audit(node,depth){
      if(++visited>10000||depth>64)throw Error();
      if(node.type==='object'){
        const names=new Set();
        for(const property of node.children||[]){
          if(property.type!=='property'||!property.children||property.children.length!==2)throw Error();
          const [name,value]=property.children;
          if(name.type!=='string'||names.has(name.value))throw Error();
          names.add(name.value);audit(value,depth+1);
        }
      }else if(node.type==='array'){for(const child of node.children||[])audit(child,depth+1);}
    }
    audit(root,0);
    const properties=root.children||[];
    if(properties.length!==2)throw Error();
    const entries=new Map(properties.map(p=>[p.children[0].value,p.children[1]]));
    if(entries.size!==2||!entries.has(expected)||!entries.has('sign'))throw Error();
    const signed=entries.get(expected),signatureNode=entries.get('sign');
    if(signed.type!=='object'||signatureNode.type!=='string'||typeof signatureNode.value!=='string')throw Error();
    const signature=signatureNode.value;
    if(!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(signature))throw Error();
    const sig=Buffer.from(signature,'base64');
    if(!sig.length||sig.length>1024||sig.toString('base64')!==signature)throw Error();
    const exact=raw.slice(signed.offset,signed.offset+signed.length);
    if(!crypto.verify('RSA-SHA256',Buffer.from(exact,'utf8'),key,sig))throw Error();
    return decoded[expected];
  }catch{throw new Error('signed query verification unavailable');}
}
function verifySignedQuery(raw,publicKey){return verifySignedResponse(raw,publicKey,EXPECTED);}

let fixtureActive=false;
async function runOfflineFixture({raw,privateKey,publicKey}){
  // The transport is replaced with a fixed in-memory result for the entire call.
  // This harness cannot contact Alipay and is not suitable for concurrent use.
  if(fixtureActive||typeof raw!=='string')throw Error('offline fixture unavailable');
  const urllib=require('urllib').default,{AlipaySdk}=require('alipay-sdk'),original=urllib.request;
  fixtureActive=true;
  try{
    urllib.request=async(url,options)=>{
      const parsed=new URL(url);
      if(parsed.hostname!=='example.invalid'||parsed.searchParams.get('method')!=='alipay.trade.query')throw Error('wrong offline request');
      return {status:200,headers:{},data:raw};
    };
    const sdk=new AlipaySdk({appId:'offline-only',privateKey,alipayPublicKey:publicKey,keyType:'PKCS8',signType:'RSA2',camelcase:false,gateway:'https://example.invalid/gateway.do'});
    let checked=false;
    sdk.checkResponseSign=(response,key)=>{if(key!==EXPECTED)throw Error('wrong method');verifySignedQuery(response,publicKey);checked=true;};
    const result=await sdk.exec('alipay.trade.query',{bizContent:{outTradeNo:'test-order'}},{validateSign:true});
    if(!checked)throw Error('SDK did not invoke signature check');
    return result;
  }catch{throw new Error('offline query unavailable');}
  finally{urllib.request=original;fixtureActive=false;}
}
module.exports={verifySignedQuery,verifySignedResponse,runOfflineFixture};
