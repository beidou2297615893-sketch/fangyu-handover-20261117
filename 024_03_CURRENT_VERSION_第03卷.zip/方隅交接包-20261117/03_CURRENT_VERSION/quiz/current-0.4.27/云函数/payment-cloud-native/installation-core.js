'use strict';
// Internal short-lived enrollment; not a production entry or deployment gate.
const crypto=require('node:crypto');
const COLLECTION='daily_hundred_installation_v1',SLOTS=32768,PROBES=8,LIMIT=10,TTL=86400000;
const sha=v=>crypto.createHash('sha256').update(v,'utf8').digest('hex');
const check=v=>{if(!v)throw Error('installation unavailable');};
const safeInt=v=>Number.isSafeInteger(v)&&v>=0;
function createProductionInstallation(){throw Error('production installation service is disabled');}
function createInternalInstallationCore({db,registrationKey,clock=Date.now}){
  check(db&&typeof db.runTransaction==='function'&&typeof clock==='function'&&typeof registrationKey==='string'&&Buffer.byteLength(registrationKey)>=32);
  function ok(r){if(r?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:r.code});check(r&&!r.code);return r;}
  async function read(ref,id){const r=ok(await ref.get());check(Object.hasOwn(r,'data'));if(r.data===null)return null;check(r.data&&typeof r.data==='object'&&!Array.isArray(r.data)&&r.data._id===id);const {_id,...value}=r.data;return value;}
  async function write(ref,id,value){const r=ok(await ref.set(value));check(r.updated===1||(r.updated===0&&Array.isArray(r.upserted)&&r.upserted.some(x=>x?._id===id)));}
  function valid(t){return typeof t==='string'&&/^[A-Za-z0-9_-]{43}$/.test(t)&&Buffer.from(t,'base64url').length===32&&Buffer.from(t,'base64url').toString('base64url')===t;}
  function slotIndex(requestId,i){return (parseInt(sha(requestId).slice(0,8),16)+i)%SLOTS;}
  function derive(label,requestId,verifier){return crypto.createHmac('sha256',registrationKey).update(JSON.stringify([label,requestId,verifier])).digest();}
  function credential(requestId,verifier,index){const prefix=Buffer.alloc(2);prefix.writeUInt16BE(index);return Buffer.concat([prefix,derive('installation-credential-v1',requestId,verifier).subarray(0,30)]).toString('base64url');}
  async function register(input){
    try{
      check(input&&typeof input==='object'&&!Array.isArray(input)&&Object.keys(input).sort().join(',')==='requestId,verifier');
      const {requestId,verifier}=input;check(valid(requestId)&&valid(verifier));
      const owner=derive('installation-owner-v1',requestId,verifier).subarray(0,16).toString('hex'),now=clock();check(safeInt(now));
      const minute=Math.floor(now/60000);
      const requestDigest=sha(requestId),verifierDigest=sha(verifier);
      // Scan all candidates before allocating. A freed earlier slot must not hide
      // the same request in a later slot, or a retry could change its credential.
      // One transaction also prevents concurrent retries claiming different slots.
      const accepted=await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),policy=await read(c.doc('policy'), 'policy');
        check(policy&&policy.kind==='policy'&&policy.schema===1&&policy.enabled===true);
        let available=null,existing=null;
        for(let i=0;i<PROBES;i++){
          const index=slotIndex(requestId,i),id='slot-'+index,ref=c.doc(id),old=await read(ref,id);
          if(old){
            check(old.kind==='slot'&&safeInt(old.expiresAt)&&typeof old.tokenDigest==='string'&&typeof old.requestDigest==='string'&&typeof old.verifierDigest==='string');
            if(old.requestDigest===requestDigest){
              check(old.verifierDigest===verifierDigest);
              if(old.expiresAt>now){
                const token=credential(requestId,verifier,index);
                check(!existing&&old.tokenDigest===sha(token)&&old.owner===owner);
                existing=token;
              }
            }
          }
          if((!old||old.expiresAt<=now)&&available===null)available={index,id,ref};
        }
        if(existing)return existing;
        check(available);
        const token=credential(requestId,verifier,available.index),wr=c.doc('window'),prior=await read(wr,'window');
        if(prior)check(prior.kind==='window'&&safeInt(prior.minute)&&safeInt(prior.count)&&prior.minute<=minute);
        const count=prior&&prior.minute===minute?prior.count:0;check(count<LIMIT);
        await write(available.ref,available.id,{kind:'slot',owner,requestDigest,verifierDigest,tokenDigest:sha(token),expiresAt:now+TTL});
        await write(wr,'window',{kind:'window',minute,count:count+1});return token;
      },3);
      return {requestId,installationId:owner,accessToken:accepted,recoverySupported:false};
    }catch{throw Error('installation unavailable');}
  }
  async function authenticate(token){
    try{
      check(valid(token));const digest=sha(token),now=clock();check(safeInt(now));const index=Buffer.from(token,'base64url').readUInt16BE(0);check(index<SLOTS);
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),policy=await read(c.doc('policy'),'policy');check(policy&&policy.kind==='policy'&&policy.schema===1&&policy.enabled===true);
        const id='slot-'+index,row=await read(c.doc(id),id);
        check(row&&row.tokenDigest===digest&&row.kind==='slot'&&/^[a-f0-9]{32}$/.test(row.owner)&&safeInt(row.expiresAt)&&now<row.expiresAt);return row.owner;
      },3);
    }catch{throw Error('installation unavailable');}
  }
  async function cleanupExpired(slotIndex){
    try{
      check(Number.isInteger(slotIndex)&&slotIndex>=0&&slotIndex<SLOTS);const now=clock();check(safeInt(now));const id='slot-'+slotIndex;
      return await db.runTransaction(async tx=>{
        const c=tx.collection(COLLECTION),ref=c.doc(id),row=await read(ref,id);
        if(!row)return {removed:false};check(row.kind==='slot'&&safeInt(row.expiresAt));if(row.expiresAt>now)return {removed:false};
        const r=ok(await ref.remove());check(r.deleted===1);return {removed:true};
      },3);
    }catch{throw Error('installation unavailable');}
  }
  return Object.freeze({register,authenticate,cleanupExpired});
}
module.exports={createInternalInstallationCore,createProductionInstallation};
