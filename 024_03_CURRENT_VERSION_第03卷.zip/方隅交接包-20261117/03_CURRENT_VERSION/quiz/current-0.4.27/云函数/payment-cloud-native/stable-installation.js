'use strict';
// Internal candidate only. Persist a high-entropy token in Android Keystore;
// device identifiers are deliberately not used as authentication credentials.
const crypto=require('node:crypto');
const COLLECTION='daily_hundred_installation_v1';
const check=v=>{if(!v)throw Error('installation unavailable');};
function createStableInstallation({db,registrationKey,clock=Date.now}){
  check(db&&typeof db.runTransaction==='function'&&typeof registrationKey==='string'&&Buffer.byteLength(registrationKey)>=32&&typeof clock==='function');
  const key=Buffer.from(registrationKey,'utf8');
  const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
  const mac=(label,value)=>crypto.createHmac('sha256',key).update(label).update('\0').update(value).digest();
  const validToken=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{43}$/.test(v)&&Buffer.from(v,'base64url').length===32&&Buffer.from(v,'base64url').toString('base64url')===v;
  async function read(ref,id){const result=await ref.get();if(result?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:result.code});check(result&&!result.code&&Object.hasOwn(result,'data'));if(result.data===null)return null;check(result.data&&result.data._id===id);const {_id,...row}=result.data;return row;}
  async function write(ref,id,row){const result=await ref.set(row);if(result?.code==='DATABASE_TRANSACTION_CONFLICT')throw Object.assign(Error('conflict'),{code:result.code});check(result&&!result.code&&(result.updated===1||(result.updated===0&&Array.isArray(result.upserted)&&result.upserted.some(x=>x?._id===id))));}
  async function enabled(c,ownerId){
    const policy=await read(c.doc('policy'),'policy');check(policy&&policy.kind==='policy'&&policy.schema===1&&policy.enabled===true);
    const id='revoked-'+sha(ownerId),revoked=await read(c.doc(id),id);check(!revoked);
  }
  async function register(input){try{
    check(input&&typeof input==='object'&&!Array.isArray(input)&&Object.keys(input).sort().join(',')==='requestId,verifier');
    check(validToken(input.requestId)&&validToken(input.verifier));
    const owner=mac('dailyhundred-installation-owner-v2',JSON.stringify([input.requestId,input.verifier])).subarray(0,16);
    owner[0]=0x49; // Typed credential; routing never falls back after auth failure.
    const tag=mac('dailyhundred-installation-token-v2',owner).subarray(0,16);
    const ownerId='i'+owner.toString('hex'),requestDigest=sha(input.requestId),verifierDigest=sha(input.verifier),id='registration-'+requestDigest;
    const now=clock();check(Number.isSafeInteger(now)&&now>=0);
    await db.runTransaction(async tx=>{
      const c=tx.collection(COLLECTION);await enabled(c,ownerId);
      const ref=c.doc(id),previous=await read(ref,id);
      if(previous){check(previous.kind==='registration'&&previous.requestDigest===requestDigest&&previous.verifierDigest===verifierDigest&&previous.owner===ownerId);return;}
      const windowRef=c.doc('window-v2'),old=await read(windowRef,'window-v2'),minute=Math.floor(now/60000);
      if(old)check(old.kind==='window-v2'&&Number.isSafeInteger(old.minute)&&Number.isSafeInteger(old.count)&&old.minute<=minute);
      const count=old&&old.minute===minute?old.count:0;check(count<120);
      await write(ref,id,{kind:'registration',requestDigest,verifierDigest,owner:ownerId});
      await write(windowRef,'window-v2',{kind:'window-v2',minute,count:count+1});
    },3);
    return {requestId:input.requestId,installationId:ownerId,accessToken:Buffer.concat([owner,tag]).toString('base64url'),recoverySupported:false};
  }catch{throw Error('installation unavailable');}}
  async function authenticate(token){try{
    check(validToken(token));const data=Buffer.from(token,'base64url'),owner=data.subarray(0,16),tag=data.subarray(16);check(owner[0]===0x49);
    const expected=mac('dailyhundred-installation-token-v2',owner).subarray(0,16);check(crypto.timingSafeEqual(tag,expected));
    const ownerId='i'+owner.toString('hex');await db.runTransaction(tx=>enabled(tx.collection(COLLECTION),ownerId),3);return ownerId;
  }catch{throw Error('installation unavailable');}}
  return Object.freeze({register,authenticate});
}
module.exports={createStableInstallation};
