"""Read-only workbench board statistics, using the original pool algorithm.

This module copies the口径 of collection_progress_window._reply_status_sets
and _pool_display_counts. It does not import that file (importing it would
open the Tk progress window and could write STOP / continue). It does not
query collection.sqlite3. It does not start Bridge, collection, or send.

Numbers are only returned when the visible pool file is present and its
sha256 matches classification-handoff-status.json. A mismatch or unexpected
intent value yields status "verifying" (正在核验/更新), never a stale snapshot.
Missing sources yield status "missing"; the UI must show "—", never 0.

Time-field口径 (2026-11-14; 11-09 samples + ledger.py copy, then
confirmed by a read-only production-schema check at 15:38; see
refs/board-stats-time-fields-20261114.md):

- 今日采集 stays None: production jsonl still has no entered_at /
  pooled_at / classified_at / admitted_at. published_at,
  published_at_unix, source_observations[].observed_at and
  classification.original_metadata.published_at must not be used.
- 今日回复 stays None: writing outcome=sent only updates
  reservations.status/evidence, sets leads.status=sent and clears
  leads.review_time; there is no sent_at. reservations.created is the
  reservation time; review_time is empty after sent; summary.py's
  comment create_time is not "confirmed sent today". The legacy sends
  table has updated (TEXT) but no sent_at; do not treat sends.updated
  as confirmed-sent time (values unread; no writer found).
- 有效池加减 stays None without a prior verified snapshot.
- 累计 stays None until the today-slice fields are settled.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from hashlib import sha256
from pathlib import Path
import json
import os
import sqlite3
from contextlib import closing

BEIJING = timezone(timedelta(hours=8))
# Same default owner root as the original window (R). Overridable for tests.
DEFAULT_ROOT = Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统')
_CI = 'work/fangyu-douyin-independent'
_LEDGER = 'work/shared-acquisition-ledger/shared.sqlite3'
_LEGACY = 'Codex获客工作台/work/reply_receipts.sqlite3'
_HANDOFF = f'{_CI}/classification-handoff-status.json'
_WAIT = f'{_CI}/collection-wait-state.json'
_RECOVERY = f'{_CI}/current-collection-status.json'
_ACTIVE = f'{_CI}/active-runner.json'
_INTENT = ('medium', 'high', 'super_high')
# Confirmed enter-pool time names. None of these appears in the 11-09 samples.
# Do not fill 今日采集 until one exists and production schema is verified.
_INBOUND_TIME_KEYS = ('entered_at', 'pooled_at', 'classified_at', 'admitted_at')
# Must never slice 今日采集: comment publish time, or "seen while collecting".
_FORBIDDEN_COLLECT_KEYS = ('published_at', 'published_at_unix', 'observed_at')
# Must never slice 今日回复: no confirmed-sent timestamp.
# sends.updated exists on the legacy receipts table but is not sent time.
_FORBIDDEN_REPLY_KEYS = ('sent_at', 'review_time', 'created', 'create_time', 'updated')


def _root(root=None):
    if root is not None:
        return Path(root)
    env = os.environ.get('FANGYU_STATS_ROOT')
    return Path(env) if env else DEFAULT_ROOT


def _load_json(path: Path):
    if not path.is_file():
        return None
    try:
        if path.stat().st_size > 4 * 1024 * 1024:
            return None
        return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError, TypeError):
        return None


def _reply_status_sets(ledger: Path, legacy: Path):
    """Read-only sent/unknown sets, same SQL口径 as collection_progress_window.py."""
    sent_comments, unknown_comments = set(), set()
    sent_customers, unknown_customers = set(), set()
    if ledger.is_file():
        with closing(sqlite3.connect(ledger.as_uri() + '?mode=ro', uri=True, timeout=1.0)) as db:
            sent_comments = {str(cid) for (cid,) in db.execute(
                "SELECT comment FROM reservations WHERE platform='douyin' AND status='sent' "
                "UNION SELECT comment FROM leads WHERE platform='douyin' AND status='sent'")}
            unknown_comments = {str(cid) for (cid,) in db.execute(
                "SELECT comment FROM reservations WHERE platform='douyin' AND status='unknown' "
                "UNION SELECT comment FROM leads WHERE platform='douyin' AND status='unknown'")}
            sent_customers = {str(uid) for (uid,) in db.execute(
                "SELECT customer FROM reservations WHERE platform='douyin' AND status='sent' "
                "AND customer IS NOT NULL AND customer!='' "
                "UNION SELECT customer FROM leads WHERE platform='douyin' AND status='sent' "
                "AND customer IS NOT NULL AND customer!=''")}
            unknown_customers = {str(uid) for (uid,) in db.execute(
                "SELECT customer FROM reservations WHERE platform='douyin' AND status='unknown' "
                "AND customer IS NOT NULL AND customer!='' "
                "UNION SELECT customer FROM leads WHERE platform='douyin' AND status='unknown' "
                "AND customer IS NOT NULL AND customer!=''")}
    if legacy.is_file():
        with closing(sqlite3.connect(legacy.as_uri() + '?mode=ro', uri=True, timeout=1.0)) as db:
            for cid, uid in db.execute("SELECT cid,uid FROM sends WHERE status='SENT_VERIFIED'"):
                if cid is not None:
                    sent_comments.add(str(cid))
                if uid:
                    sent_customers.add(str(uid))
    return sent_comments, unknown_comments, sent_customers, unknown_customers


def _pool_display_counts(records, sets):
    """Split visible mid/high/super_high pool into effective / deducted-sent / unknown."""
    sent_comments, unknown_comments, sent_customers, unknown_customers = sets
    original = len(records)
    deducted_sent = unknown_count = effective = 0
    for row in records:
        cid = str(row.get('comment_id') or '')
        uid = str(row.get('customer_uid') or '')
        is_sent = (cid and cid in sent_comments) or (uid and uid in sent_customers)
        is_unknown = (cid and cid in unknown_comments) or (uid and uid in unknown_customers)
        if is_sent:
            deducted_sent += 1
        elif is_unknown:
            unknown_count += 1
        else:
            effective += 1
    return original, effective, deducted_sent, unknown_count


def _parse_time(value):
    if value is None or value == '':
        return None
    if isinstance(value, (int, float)):
        ts = float(value)
        if ts > 1e12:
            ts /= 1000.0
        try:
            return datetime.fromtimestamp(ts, BEIJING)
        except (OSError, ValueError, OverflowError):
            return None
    text = str(value).strip()
    try:
        dt = datetime.fromisoformat(text.replace('Z', '+00:00'))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=BEIJING)
    return dt.astimezone(BEIJING)


def _confirmed_inbound_field(records):
    """Name a confirmed enter-pool field if it is widely present; never forbidden keys."""
    for key in _INBOUND_TIME_KEYS:
        values = [_parse_time(row.get(key)) for row in records]
        if sum(v is not None for v in values) >= max(1, int(len(records) * 0.8)):
            return key
    return None


def _attention(root: Path):
    """Conservative flags only. Never claim 运行中 from a pid."""
    active = _load_json(root / _ACTIVE) or {}
    wait = _load_json(root / _WAIT) or {}
    recovery = _load_json(root / _RECOVERY) or {}
    if active.get('verification_required_now') is True:
        return 'verification'
    if wait.get('mode') in ('waiting_for_user_check',):
        return 'verification'
    if recovery.get('mode') in ('platform_verification',):
        return 'verification'
    if recovery.get('mode') in ('waiting_for_send',) or wait.get('mode') in (
            'waiting_for_connection', 'recovering_connection'):
        return 'paused'
    return None


def read_board_stats(root=None):
    """Return board fields. Numeric values are int or None (UI shows —)."""
    root = _root(root)
    missing = []
    handoff_path = root / _HANDOFF
    ledger = root / _LEDGER
    legacy = root / _LEGACY
    if not handoff_path.is_file():
        missing.append(str(handoff_path))
    if not ledger.is_file():
        missing.append(str(ledger))
    result = {
        'complete': False,
        'complete_statistics': False,
        'status': 'missing',
        'message': '本机状态文件不足，数字显示为 —，不会写成 0。',
        'today_collected': None,
        'today_replied': None,
        'pool_effective': None,
        'pool_delta': None,
        'total': None,
        'pool_original': None,
        'pool_deducted_sent': None,
        'pool_unknown': None,
        'today_field': None,
        'attention': _attention(root) if root.exists() else None,
        'missing_files': missing,
        'note': '有效池沿用 collection_progress_window._reply_status_sets / _pool_display_counts；'
                '不查询 collection.sqlite3；不用累计采集减累计回复倒推；'
                '今日采集不用 published_at / observed_at 凑数；'
                '今日回复不用 review_time / reservations.created / 评论 create_time / sends.updated 凑数；'
                '有效池加减无上一份已核验快照不编；累计在今日切片未定前保持 —。',
    }
    handoff = _load_json(handoff_path)
    if not isinstance(handoff, dict):
        return result
    visible = handoff.get('visible_business_pool') or {}
    pool_file, digest = visible.get('file'), visible.get('sha256')
    if not pool_file or not digest:
        result['status'] = 'verifying'
        result['message'] = '正在核验/更新'
        return result
    path = Path(pool_file)
    if not path.is_file():
        missing.append(str(path))
        result['missing_files'] = missing
        result['status'] = 'verifying'
        result['message'] = '正在核验/更新'
        return result
    try:
        raw = path.read_bytes()
        if sha256(raw).hexdigest() != digest:
            result['status'] = 'verifying'
            result['message'] = '正在核验/更新'
            result['missing_files'] = missing
            return result
        records = [json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
    except (OSError, ValueError, TypeError):
        result['status'] = 'verifying'
        result['message'] = '正在核验/更新'
        return result
    if any((row.get('commercial_fit') or {}).get('lead_intent') not in _INTENT for row in records):
        result['status'] = 'verifying'
        result['message'] = '正在核验/更新'
        return result
    try:
        sets = _reply_status_sets(ledger, legacy)
    except (OSError, sqlite3.Error, ValueError):
        result['status'] = 'verifying'
        result['message'] = '正在核验/更新'
        return result
    original, effective, deducted, unknown = _pool_display_counts(records, sets)
    # 今日四格与累计：按 2026-11-14 口径保持 None，界面显示 —。
    # 即使记录里出现 published_at / observed_at / created_at 也不切片。
    result.update(
        status='partial' if missing else 'ready',
        pool_effective=effective,
        pool_original=original,
        pool_deducted_sent=deducted,
        pool_unknown=unknown,
        total=None,
        today_collected=None,
        today_replied=None,
        pool_delta=None,
        today_field=_confirmed_inbound_field(records),
        message=(
            '有效池已按原窗口口径算出；今日采集因没有入池时间列、'
            '今日回复因账本没有确认发出时间、累计和有效池加减因缺少'
            '已核验快照或今日切片，均显示为 —。'
        ),
    )
    result['missing_files'] = missing
    return result
