"""Route the workbench start / pause / resume / ack buttons to the existing
local control channel. This is not a dry-run gate.

Start and resume call the same control.py --employee-start entry the original
progress window uses. Pause writes a STOP marker in the active runner
directory when that path is inside the owner root. Ack does not change
processes. This module must not kill or restart unrelated processes, must
not read credentials, and must not open creator.douyin.com.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from pathlib import Path
import json
import os
import subprocess
import sys

from local_progress import read_progress, ROOT as DEFAULT_ROOT

BEIJING = timezone(timedelta(hours=8))
CONTROL_PY = DEFAULT_ROOT / 'work' / 'douyin-local-control' / 'control.py'
SLASH = '\uFF0F'


def _now():
    return datetime.now(BEIJING).isoformat()


def _pythonw():
    # Prefer the interpreter already used by the original panel.
    conda = Path(os.environ.get('USERPROFILE', r'C:\Users\rmsama')) / 'miniconda3' / 'pythonw.exe'
    if conda.is_file():
        return conda
    return Path(sys.executable)


def _append_log(payload, log_dir=None):
    if log_dir is None:
        return None
    path = Path(log_dir)
    path.mkdir(parents=True, exist_ok=True)
    target = path / 'board-actions.jsonl'
    with target.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(payload, ensure_ascii=False) + '\n')
    return str(target)


def _safe_runner_directory(root, raw):
    if not raw or not isinstance(raw, str):
        return None
    base = Path(root).resolve()
    path = Path(raw)
    try:
        resolved = path.resolve()
    except OSError:
        return None
    if not resolved.is_dir():
        return None
    if not resolved.is_relative_to(base):
        return None
    for part in (resolved, *resolved.parents):
        if part.exists() and (part.is_symlink() or getattr(part.lstat(), 'st_file_attributes', 0) & 0x400):
            return None
        if part == base:
            break
    return resolved


def _start_control(action):
    if not CONTROL_PY.is_file():
        return {
            'ok': False,
            'executed': False,
            'action': action,
            'error': 'CONTROL_MISSING',
            'message': '未找到原来的本地控制程序，启动未执行。',
        }
    creation = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    try:
        proc = subprocess.Popen(
            [str(_pythonw()), str(CONTROL_PY), '--employee-start'],
            cwd=str(CONTROL_PY.parent),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creation,
        )
    except OSError as exc:
        return {
            'ok': False,
            'executed': False,
            'action': action,
            'error': 'CONTROL_UNAVAILABLE',
            'message': '无法启动原来的本地控制通道。',
            'detail': type(exc).__name__,
        }
    return {
        'ok': True,
        'executed': True,
        'action': action,
        'pid': proc.pid,
        'title': '已请求启动' + SLASH + '继续',
        'message': '已向原来的本地控制通道发出启动／继续。外部回复仍先走草稿审核，不会自动发评论或私信。',
        'channel': 'douyin-local-control/control.py --employee-start',
        'spawned_process': True,
    }


def _pause(root=None):
    root = Path(root) if root is not None else DEFAULT_ROOT
    progress = read_progress(root=root)
    active = ((progress.get('sources') or {}).get('collection_active') or {})
    data = active.get('data') if active.get('state') == 'available' else {}
    directory = _safe_runner_directory(root, (data or {}).get('directory'))
    if directory is None:
        return {
            'ok': False,
            'executed': False,
            'action': 'pause',
            'error': 'STOP_PATH_UNAVAILABLE',
            'message': '未找到可写入的采集任务目录，暂停未执行。请暂时在原来的进度窗口暂停。',
        }
    stop = directory / 'STOP'
    stop.write_text('', encoding='utf-8')
    return {
        'ok': True,
        'executed': True,
        'action': 'pause',
        'title': '已请求暂停',
        'message': '已向当前采集任务发出暂停（写入停止标记）。不会结束其他无关进程。',
        'wrote_stop': True,
    }


def dispatch_board_action(action, data=None, log_dir=None, root=None):
    if action == 'employee_start':
        action = 'start'
    if action in ('start', 'resume'):
        payload = _start_control(action)
    elif action == 'pause':
        payload = _pause(root=root)
    elif action == 'ack':
        payload = {
            'ok': True,
            'executed': False,
            'action': 'ack',
            'title': '请在原来的网页完成',
            'message': '请到原来配合采集的抖音网页里完成验证。软件不会自动继续采集或发送。',
        }
    else:
        payload = {
            'ok': False,
            'executed': False,
            'action': action,
            'error': 'UNKNOWN_ACTION',
            'message': '无法识别的主按钮动作。',
        }
    payload['at'] = _now()
    payload['copy_gate'] = False
    payload['blocked'] = payload.get('ok') is not True
    path = _append_log({k: v for k, v in payload.items() if k != 'detail'}, log_dir=log_dir)
    if path:
        payload['evidence_log'] = path
    return payload
