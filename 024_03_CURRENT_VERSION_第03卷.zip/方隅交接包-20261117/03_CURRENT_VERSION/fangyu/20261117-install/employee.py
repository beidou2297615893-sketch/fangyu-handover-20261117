# -*- coding: utf-8 -*-
"""Desktop entry for 方隅自动获客系统. Serves the approved UI and a resizable window."""
from pathlib import Path
import hashlib
import json
import os
import sys
import threading
import traceback

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
REL = ROOT / 'acceptance-release'
sys.path.insert(0, str(REL))

# Inherit the existing remembered-store state directory.
DEFAULT_STATE = Path.home() / 'AppData/Local/FangyuDesktopDirect-20261114-state'


def _state_dir():
    return Path(os.environ.get('FANGYU_CANDIDATE_STATE', str(DEFAULT_STATE)))


def _write_error(message):
    state = _state_dir()
    state.mkdir(parents=True, exist_ok=True)
    (state / 'startup-error.txt').write_text(message, encoding='utf-8')


def main():
    import ui_native_host as host
    from local_workbench import create_backend

    state = _state_dir()
    state.mkdir(parents=True, exist_ok=True)
    raw = (REL / 'RELEASE.json').read_bytes()
    manifest, files = host.verify_release(REL, hashlib.sha256(raw).hexdigest().upper())
    backend = create_backend(state / 'employee-data')
    if '--self-test' in sys.argv:
        boot = backend.dispatch('bootstrap', {})
        assert boot['localMode'] is True and boot['selection']['storeId'] and boot['session'] is None
        assert 'creator.douyin.com' not in json.dumps(boot, ensure_ascii=False)
        report = {
            'status': 'PASS',
            'backend': 'LocalWorkbench',
            'mode': 'local_direct',
            'no_mock': True,
            'authenticated': False,
            'platform_ready': False,
            'ui_opened': False,
            'release': manifest.get('release_id'),
        }
        (state / 'self-test.json').write_text(json.dumps(report, ensure_ascii=False), encoding='utf-8')
        backend.close()
        return
    host.API_ACTIONS = host.API_ACTIONS | {
        'local_drafts', 'employee_browser_open', 'employee_start',
        'employee_browser_status', 'employee_cloud_status',
        'local_progress', 'board_stats', 'board_action',
    }
    server = host.StaticServer(REL, files, backend=backend, cookie_name='fangyu_employee_candidate')
    threading.Thread(target=server.serve_forever, daemon=True).start()
    # index.html is the window-fit wrapper; canvas.html is the inner page.
    url = f'http://127.0.0.1:{server.server_port}/'
    (state / 'running.json').write_text(
        json.dumps({'url': url, 'profile': 'employee', 'install': str(ROOT)}, ensure_ascii=False),
        encoding='utf-8',
    )
    try:
        if '--serve' in sys.argv:
            threading.Event().wait()
            return
        from control_window import has_webview2_runtime, launch_control_window
        if has_webview2_runtime():
            import webview
            webview.create_window(
                '方隅自动获客系统',
                url,
                width=1280,
                height=820,
                min_size=(720, 480),
                resizable=True,
                frameless=False,
                easy_drag=False,
                text_select=True,
                zoomable=False,
                background_color='#F2FAFB',
            )
            webview.start(gui='edgechromium', private_mode=True)
        else:
            launch_control_window(url, state / 'control-browser').wait()
    finally:
        server.shutdown()
        server.server_close()
        backend.close()


if __name__ == '__main__':
    try:
        main()
    except Exception:
        _write_error(traceback.format_exc())
        sys.exit(1)
