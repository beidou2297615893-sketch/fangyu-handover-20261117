"""Employee console in installed system Edge; no runtime installation or platform access."""
from pathlib import Path
from urllib.parse import urlsplit
import os
import subprocess
import uuid


def has_webview2_runtime():
    try:
        import winreg
        suffix=r'Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
        for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
            for view in (winreg.KEY_WOW64_32KEY,winreg.KEY_WOW64_64KEY):
                try:
                    with winreg.OpenKey(hive,suffix,0,winreg.KEY_READ|view) as key:
                        version=winreg.QueryValueEx(key,'pv')[0]
                    parts=tuple(int(p) for p in version.split('.'))
                    if parts>(0,0,0,0):return True
                except (OSError,ValueError,TypeError):pass
    except ImportError:pass
    return False


def installed_edge():
    for base in (os.environ.get('ProgramFiles(x86)'),os.environ.get('ProgramFiles')):
        if base:
            path=Path(base)/'Microsoft/Edge/Application/msedge.exe'
            if path.is_file() and not path.is_symlink():return path
    raise RuntimeError('未找到微软 Edge，员工控制台暂时无法打开；未安装或修改任何系统组件。')


def plan_control_window(url,data_root,*,edge_path=None,session_id=None):
    parsed=urlsplit(url)
    if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or not parsed.port or parsed.username or parsed.password or parsed.fragment:
        raise ValueError('员工控制台只允许本机服务地址')
    base=Path(data_root).absolute()
    for p in (base,*base.parents):
        if p.exists() and (p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&0x400):raise ValueError('控制台目录不能为链接')
    marker=session_id or uuid.uuid4().hex
    if len(marker)!=32 or any(c not in '0123456789abcdef' for c in marker):raise ValueError('控制台会话标识无效')
    profile=base/marker
    executable=Path(edge_path) if edge_path is not None else installed_edge()
    argv=[str(executable),'--app='+url,'--user-data-dir='+str(profile),'--no-first-run','--no-default-browser-check','--disable-background-mode']
    return {'mode':'system-edge-app','argv':argv,'profile':profile,'url':url,'platformActionsStarted':False}


def launch_control_window(url,data_root):
    plan=plan_control_window(url,data_root)
    plan['profile'].mkdir(parents=True,exist_ok=False)
    # A fresh, exclusive profile never attaches to an employee's existing browser.
    return subprocess.Popen(plan['argv'],shell=False,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
