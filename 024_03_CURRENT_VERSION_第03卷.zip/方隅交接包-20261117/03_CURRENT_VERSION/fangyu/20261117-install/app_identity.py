"""User-visible product name and install-once store defaults for this copy."""

APP_DISPLAY_NAME = '方隅自动获客系统'

DEFAULT_STORE_NAME = '上海联航路云涛公寓'
DEFAULT_STORE_ID = 'fy_s_5d7de1ce644eabc4386eab0e'

# Historical internal exe / path names are left unchanged on purpose.
