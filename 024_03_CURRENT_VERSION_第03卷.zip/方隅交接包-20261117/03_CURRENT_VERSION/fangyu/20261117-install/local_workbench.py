"""Local desktop workbench: remembered store, board stats, start/pause, jingxuan login."""
from pathlib import Path
import json
import os
import sys
import threading

class WorkbenchError(Exception):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code = code
        self.status = status

from local_progress import read_progress
from douyin_board_stats import read_board_stats
from board_state import read_board_view
from board_actions import dispatch_board_action
from app_identity import APP_DISPLAY_NAME, DEFAULT_STORE_NAME, DEFAULT_STORE_ID
from install_store import load_saved_selection, default_store, save_install_selection

DOUYIN_PAGE_URL = 'https://www.douyin.com/jingxuan'
LOGIN_MESSAGE = (
    '请在原来配合采集的抖音网页（https://www.douyin.com/jingxuan）里完成登录。'
    '软件不会打开创作者中心，也不会另开一个未接入采集通道的浏览器。'
)


def _owner_root():
    env = os.environ.get('FANGYU_STATS_ROOT')
    return Path(env) if env else None


def _stats_payload():
    root = _owner_root()
    stats = read_board_stats(root=root) if root is not None else read_board_stats()
    view = read_board_view(root=root) if root is not None else read_board_view()
    stats['board'] = view
    return stats


def _install_dir():
    return Path(__file__).resolve().parent


class LocalWorkbench:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
        rows = json.loads((root / 'local_stores.json').read_bytes())
        self.stores = [{'id': r['id'], 'name': r['name']} for r in rows if r.get('ready') and r.get('id')]
        self.preference_path = self.data_dir / 'local-selection.json'
        chosen = default_store(self.stores)
        self.selection = {
            'storeId': chosen['id'] if chosen else (self.stores[0]['id'] if self.stores else DEFAULT_STORE_ID),
            'revision': 0,
        }
        candidates = [
            self.preference_path,
            _install_dir() / 'installation-preference.json',
            Path(os.environ.get('LOCALAPPDATA', '')) / 'FangyuDesktopDirect-20261114' / 'installation-preference.json',
        ]
        for preference in candidates:
            if preference.is_file():
                saved = load_saved_selection(preference, self.stores)
                if saved:
                    self.selection = saved
                    break

    def close(self):
        pass

    def bootstrap(self):
        store = next((r for r in self.stores if r['id'] == self.selection['storeId']), None)
        return {
            'session': None,
            'localMode': True,
            'localProfile': {'name': '本机'},
            'appName': APP_DISPLAY_NAME,
            'dailyStoreSwitch': False,
            'stores': list(self.stores),
            'selection': dict(self.selection),
            'selectedStoreName': store['name'] if store else DEFAULT_STORE_NAME,
            'capabilities': {'platforms': False},
            'fixture': False,
        }

    def _check_store(self, data):
        if type(data) is not dict or set(data) != {'storeId'} or data['storeId'] != self.selection['storeId']:
            raise WorkbenchError('INVALID_SELECTION', '请重新选择门店。', 409)

    def _browser(self, action, data):
        self._check_store(data)
        # Never open creator.douyin.com. Never spawn an isolated Edge profile
        # that would sit outside the existing collection Bridge.
        return {
            'browserState': 'use_existing_page',
            'loginVerified': False,
            'bridgeConnected': False,
            'startedOperations': [],
            'page_url': DOUYIN_PAGE_URL,
            'page_host': 'www.douyin.com',
            'opened_independent_edge_profile': False,
            'spawned_browser': False,
            'executed': False,
            'copy_gate': False,
            'message': LOGIN_MESSAGE,
        }

    def dispatch(self, action, data, token=''):
        with self.lock:
            if action == 'bootstrap':
                return self.bootstrap()
            if action == 'local_progress':
                if data != {}:
                    raise WorkbenchError('INVALID_REQUEST', '请重新打开运行状态。', 400)
                root = _owner_root()
                return read_progress(root=root) if root is not None else read_progress()
            if action == 'board_stats':
                if data != {}:
                    raise WorkbenchError('INVALID_REQUEST', '请重新打开工作台。', 400)
                return _stats_payload()
            if action == 'board_action':
                if type(data) is not dict or set(data) - {'action', 'key'} or not isinstance(data.get('action') or data.get('key'), str):
                    raise WorkbenchError('INVALID_REQUEST', '请重新打开工作台。', 400)
                log_dir = self.data_dir / 'board-action-log'
                key = data.get('action') or data.get('key')
                root = _owner_root()
                return dispatch_board_action(key, data=data, log_dir=log_dir, root=root)
            if action == 'employee_start':
                log_dir = self.data_dir / 'board-action-log'
                return dispatch_board_action('employee_start', data=data, log_dir=log_dir, root=_owner_root())
            if action in ('select_store', 'install_select_store'):
                if type(data) is not dict or set(data) - {'storeId', 'expectedRevision'} or data.get('storeId') not in {r['id'] for r in self.stores}:
                    raise WorkbenchError('INVALID_SELECTION', '请选择有效门店。', 400)
                if data.get('expectedRevision', self.selection['revision']) != self.selection['revision']:
                    raise WorkbenchError('SELECTION_CHANGED', '门店已变化，请重新选择。', 409)
                store = next(r for r in self.stores if r['id'] == data['storeId'])
                saved = save_install_selection(self.preference_path, store, revision=self.selection['revision'] + 1)
                self.selection = {'storeId': saved['storeId'], 'revision': saved['revision']}
                return self.bootstrap()
            if action in ('employee_browser_open', 'employee_browser_status'):
                return self._browser(action, data)
            if action == 'employee_cloud_status':
                self._check_store(data)
                return {
                    'authenticationConfigured': False,
                    'loginVerified': False,
                    'collectionReady': False,
                    'replyReady': False,
                    'keywords': [],
                    'approvedDrafts': [],
                    'cloudAvailable': False,
                }
            if action == 'local_drafts':
                raise WorkbenchError('LOCAL_DATA_PENDING', '本地客户数据正在接入，当前请以原程序记录为准。', 409)
            raise WorkbenchError('LOCAL_LINK_PENDING', '本机采集与回复链路待接通。', 409)


def create_backend(data_dir):
    return LocalWorkbench(data_dir)
