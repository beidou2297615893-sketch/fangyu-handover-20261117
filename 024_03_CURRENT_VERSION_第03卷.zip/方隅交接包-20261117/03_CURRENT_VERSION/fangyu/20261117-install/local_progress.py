"""Read-only JSON progress from the existing owner; no task imports or actions.

read_progress(root=...) returns source records with unrenamed JSON data, source
mtime and observation time. These snapshots do not prove process liveness.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import re

ROOT = Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统')
_SECRET = re.compile(r'cookie|token|password|passwd|authorization|credential|secret|api[_-]?key|session[_-]?(?:key|id)', re.I)
_INLINE = re.compile(r'(?i)((?:cookie|token|password|authorization|secret|api[_-]?key)\s*[:=]\s*)([^\s,;]+)')
_COLLECTION = 'work/fangyu-douyin-independent'
_REPLY = 'work/douyin-local-control'
_FIXED = {
    'collection_active': f'{_COLLECTION}/active-runner.json',
    'collection_wait': f'{_COLLECTION}/collection-wait-state.json',
    'collection_recovery': f'{_COLLECTION}/current-collection-status.json',
    'collection_progress': f'{_COLLECTION}/progress-report-state.json',
    'classification_handoff': f'{_COLLECTION}/classification-handoff-status.json',
    'reply_status': f'{_REPLY}/status.json',
    'reply_active': f'{_REPLY}/active.json',
    'reply_hold': f'{_REPLY}/douyin-send-hold.json',
}


def _safe(value):
    if isinstance(value, dict):
        return {key: '[redacted]' if _SECRET.search(str(key)) else _safe(item)
                for key, item in value.items()}
    if isinstance(value, list):
        return [_safe(item) for item in value]
    if isinstance(value, str):
        return _INLINE.sub(r'\1[redacted]', value)
    return value


def _checked(base, candidate):
    base = base.absolute()
    path = Path(candidate)
    path = path if path.is_absolute() else base / path
    if not path.resolve().is_relative_to(base.resolve()):
        raise ValueError('outside allowed source')
    for part in (path, *path.parents):
        if part.exists() and (part.is_symlink() or getattr(part.lstat(), 'st_file_attributes', 0) & 0x400):
            raise ValueError('redirected source')
        if part == base:
            break
    return path


def _record(base, relative):
    record = {'source': str(base / relative), 'kind': 'owner_json_snapshot',
              'live_process_verified': False, 'data': None}
    try:
        path = _checked(base, relative)
        before = path.stat()
        if before.st_size > 4 * 1024 * 1024:
            raise ValueError('oversized source')
        with path.open('rb') as stream:
            raw = stream.read(4 * 1024 * 1024 + 1)
        if len(raw) > 4 * 1024 * 1024:
            raise ValueError('oversized source')
        after = path.stat()
        if (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size):
            raise ValueError('source changing')
        record.update(data=_safe(json.loads(raw.decode('utf-8-sig'))),
                      modified_at=datetime.fromtimestamp(after.st_mtime, timezone.utc).isoformat(),
                      state='available')
    except FileNotFoundError:
        record['state'] = 'missing'
    except (OSError, ValueError, TypeError):
        record['state'] = 'unavailable'
    return record


def read_progress(root=ROOT):
    """Read only fixed JSONs and narrowly validated active-task status JSONs.

    Never follows plan/bridge/queue/log/business-pool paths. No original module
    is imported. Missing or unreadable status is explicit, never a zero count.
    """
    root = Path(root).absolute()
    sources = {name: _record(root, relative) for name, relative in _FIXED.items()}
    active = sources['collection_active']['data']
    if isinstance(active, dict):
        base = root / _COLLECTION
        directory = active.get('directory')
        if isinstance(directory, str) and directory:
            try:
                path = _checked(base, directory)
                sources['collection_control'] = _record(root, (path / 'control.json').relative_to(root))
            except (ValueError, OSError):
                sources['collection_control'] = {'state': 'unavailable', 'data': None}
        diagnostic = active.get('diagnostic')
        if isinstance(diagnostic, str) and diagnostic:
            try:
                path = _checked(base, diagnostic)
                if path.name != 'progress-report-state.json':
                    raise ValueError('unrecognized diagnostic')
                sources['collection_progress'] = _record(root, path.relative_to(root))
            except (ValueError, OSError):
                sources['collection_progress'] = {'state': 'unavailable', 'data': None}
    active = sources['reply_active']['data']
    if isinstance(active, dict) and isinstance(active.get('task'), str):
        try:
            task = _checked(root / 'work', active['task'])
            if task.parent != root / 'work' or not task.name.startswith('douyin-local-'):
                raise ValueError('unrecognized task')
            sources['reply_batch'] = _record(root, (task / 'batch-runner-status.json').relative_to(root))
        except (ValueError, OSError):
            sources['reply_batch'] = {'state': 'unavailable', 'data': None}
    return {'observed_at': datetime.now(timezone.utc).isoformat(), 'sources': sources,
            'coverage': 'json_status_only', 'complete_statistics': False,
            'process_liveness': 'not_checked',
            'note': '原始状态快照；完整统计仍需原窗口的分类、队列与回执归并口径。'}
