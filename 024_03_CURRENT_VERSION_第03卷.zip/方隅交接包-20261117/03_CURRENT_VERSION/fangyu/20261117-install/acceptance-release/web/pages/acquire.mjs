import {customerAvatar,bindCustomerAvatars} from '../avatar.mjs';
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const asset = name => `/assets/${name}`;
const icon = (name, cls='') => `<img class="acquire-icon ${cls}" src="${asset(name)}" alt="" aria-hidden="true">`;
let progressTimer = null;

function model(state) {
  const assignedStore=state.stores?.find(item=>item.id===state.storeId);
  state.acquire ??= {region:assignedStore?.region||'',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  return state.acquire;
}

const copyFor = (status, board={}) => {
  const defaults = {
    idle: {title:'待开始', sub:'门店已记住。点一次即可启动或继续。', action:'启动／继续', icon:'icon-play-filled.svg', key:'start'},
    running: {title:'运行中', sub:'正在按原采集与回复通道运行。外部回复仍先走草稿审核。', action:'暂停', icon:'fy-icon-54-pause.png', key:'pause'},
    paused: {title:'已安全暂停', sub:'已先停住。可再点启动／继续。', action:'启动／继续', icon:'icon-play-filled.svg', key:'resume'},
    need: {title:'抖音需要验证', sub:'请到原来的网页里完成，软件已先停住。', action:'知道了', icon:'fy-icon-49-info.png', key:'ack'},
    completed: {title:'待开始', sub:'上一轮已结束。可再点启动／继续。', action:'启动／继续', icon:'icon-play-filled.svg', key:'start'},
    failed: {title:'已安全暂停', sub:'已先停住。可再点启动／继续。', action:'启动／继续', icon:'icon-play-filled.svg', key:'resume'}
  };
  const base = defaults[status] || defaults.idle;
  return {
    title: board.title || base.title,
    sub: board.sub || base.sub,
    action: board.action || base.action,
    icon: base.icon,
    key: board.key || base.key
  };
};

export function render(state) {
  const a = model(state);
  const board = state.board || {};
  const status = board.mode || a.status || 'idle';
  const copy = copyFor(status, board);
  const store = state.store || '尚未选定门店';
  return `<div class="acquire-page home-control" data-page-acquire>
    <section class="acquire-card home-control-card" aria-label="一键获客">
      <p class="home-store">当前门店<span>${escape(store)}</span><em>已记住，日常不必来回切换</em></p>
      <h2 class="home-status" aria-live="polite">${escape(copy.title)}</h2>
      <p class="home-sub">${escape(copy.sub)}</p>
      <button class="acquire-start home-action" type="button" data-home-action="${escape(copy.key)}">${icon(copy.icon)}<span>${escape(copy.action)}</span></button>
      <p class="home-gate">外部回复默认先进入草稿审核，不会自动发评论或私信。</p>
    </section>
  </div>`;
}

export function bind(root,ctx) {
  clearTimeout(progressTimer);
  progressTimer = null;
  const mount = root.querySelector('[data-page-acquire]');
  if (!mount) return () => {};
  const button = root.querySelector('[data-home-action]');
  button?.addEventListener('click', async () => {
    if (button.disabled) return;
    const key = button.getAttribute('data-home-action') || 'start';
    button.disabled = true;
    try {
      const result = await ctx.actions.boardAction(key);
      if (result?.message) ctx.toast(result.message);
      else if (key === 'pause') ctx.toast('已请求暂停。');
      else if (key === 'ack') ctx.toast('请到原来的网页里完成验证。');
      else ctx.toast('已请求启动／继续。');
    } catch (error) {
      ctx.toast(error.message || '操作未完成，请稍后重试。');
    } finally {
      if (button.isConnected) button.disabled = false;
    }
  });
  return () => { clearTimeout(progressTimer); progressTimer = null; };
}

