﻿@echo off
setlocal
set "PYTHONW=C:\积木软件工坊\项目\方隅公寓客户版\work\desktop-python\Scripts\pythonw.exe"
set "ENTRY=C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117\employee.py"
cd /d "C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117"
if not exist "%PYTHONW%" (
  echo 未找到本机 Python 运行环境。>"%LOCALAPPDATA%\FangyuDesktopDirect-20261114-state\startup-error.txt"
  exit /b 1
)
start "" "%PYTHONW%" -X utf8 -B "%ENTRY%"
