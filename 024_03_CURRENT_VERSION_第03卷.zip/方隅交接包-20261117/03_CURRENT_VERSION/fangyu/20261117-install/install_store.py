"""Install-once store selection. Daily UI must not offer 切换门店."""
from pathlib import Path
import json
import os
import uuid

from app_identity import DEFAULT_STORE_ID, DEFAULT_STORE_NAME


def default_store(stores):
    rows = list(stores or [])
    for row in rows:
        if row.get('name') == DEFAULT_STORE_NAME and row.get('id') and row.get('id') != '':
            return {'id': row['id'], 'name': row['name']}
    for row in rows:
        if row.get('id') == DEFAULT_STORE_ID:
            return {'id': row['id'], 'name': row.get('name') or DEFAULT_STORE_NAME}
    return None


def load_saved_selection(path, stores):
    path = Path(path) if path else None
    if path is None or not path.is_file():
        return None
    try:
        candidate = json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError, TypeError):
        return None
    allowed = {r['id'] for r in stores}
    if candidate.get('storeId') not in allowed:
        return None
    revision = candidate.get('revision', 0)
    if type(revision) is not int or revision < 0:
        revision = 0
    return {'storeId': candidate['storeId'], 'revision': revision}


def save_install_selection(path, store, revision=1):
    """Write the install-time preference. Next launch should reuse this file."""
    if not store or not store.get('id') or not store.get('name'):
        raise ValueError('valid_store_required')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        'storeId': store['id'],
        'name': store['name'],
        'source': 'installer_local_preference',
        'authorizationGranted': False,
        'revision': revision,
    }
    temporary = path.with_name('selection-' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return payload
