"""Locate installed Edge if a caller needs it. Regular login must not open
creator.douyin.com or a new isolated profile; it stays on the existing
Bridge-connected ordinary Douyin page.
"""
from pathlib import Path
import os

DOUYIN_PAGE_URL = 'https://www.douyin.com/jingxuan'


def edge_executable():
    for variable in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
        base = os.environ.get(variable)
        if base:
            path = Path(base) / 'Microsoft/Edge/Application/msedge.exe'
            if path.is_file() and not path.is_symlink():
                return path
    raise ValueError('edge_dependency_not_ready')
