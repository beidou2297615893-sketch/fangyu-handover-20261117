"""Map read-only local_progress snapshots to the locked four board states.

This module does not import original collection or send runtimes, does not
check process liveness, and never treats a pid as proof of 运行中. Counts
are not computed here; the board keeps today/total/delta as —.
"""
from __future__ import annotations

from pathlib import Path

from local_progress import read_progress

SLASH = '\uFF0F'
START = '启动' + SLASH + '继续'

# Locked copy and buttons. Do not change structure or wording.
BOARDS = {
    'idle': {
        'mode': 'idle',
        'title': '待开始',
        'live': False,
        'sub': '',
        'action': START,
        'key': 'start',
        'float': None,
    },
    'running': {
        'mode': 'running',
        'title': '运行中',
        'live': True,
        'sub': '',
        'action': '暂停',
        'key': 'pause',
        'float': None,
    },
    'need': {
        'mode': 'need',
        'title': '抖音需要验证',
        'live': True,
        'sub': '请到原来的网页里完成，软件已先停住。',
        'action': '知道了',
        'key': 'ack',
        'float': 'need',
    },
    'paused': {
        'mode': 'paused',
        'title': '已安全暂停',
        'live': False,
        'sub': '连续退回后已先停住。',
        'action': START,
        'key': 'resume',
        'float': None,
    },
}

# Same verification source fields as douyin_board_stats._attention(), plus
# original wait-worker / reply blocked_reason values that also require the user.
_NEED_WAIT_MODES = ('waiting_for_user_check', 'platform_or_identity_review', 'needs_review')
_NEED_REPLY_REASONS = ('captcha', 'identity')
_REPLY_RUNNING_MESSAGE = '本地任务运行中'
_CONSECUTIVE_REASON = 'consecutive_skips'


def _source_data(sources, name):
    record = sources.get(name) or {}
    if record.get('state') != 'available':
        return {}
    data = record.get('data')
    return data if isinstance(data, dict) else {}


def _reasons_need(sources):
    reasons = []
    active = _source_data(sources, 'collection_active')
    wait = _source_data(sources, 'collection_wait')
    recovery = _source_data(sources, 'collection_recovery')
    reply = _source_data(sources, 'reply_status')
    batch = _source_data(sources, 'reply_batch')
    if active.get('verification_required_now') is True:
        reasons.append('collection_active.verification_required_now=true')
    wait_mode = wait.get('mode')
    if wait_mode in _NEED_WAIT_MODES:
        reasons.append(f'collection_wait.mode={wait_mode}')
    if recovery.get('mode') == 'platform_verification':
        reasons.append('collection_recovery.mode=platform_verification')
    if reply.get('blocked_reason') in _NEED_REPLY_REASONS:
        reasons.append(f'reply_status.blocked_reason={reply["blocked_reason"]}')
    message = str(reply.get('message') or '')
    if '要求安全验证' in message:
        reasons.append('reply_status.message=captcha')
    if '身份无法核验' in message:
        reasons.append('reply_status.message=identity')
    batch_reason = batch.get('blocked_reason') or batch.get('reason')
    if batch.get('status') == 'blocked' and batch.get('blocked_reason') in _NEED_REPLY_REASONS:
        reasons.append(f'reply_batch.blocked_reason={batch["blocked_reason"]}')
    if isinstance(batch_reason, str) and ('要求安全验证' in batch_reason or '身份无法核验' in batch_reason):
        reasons.append('reply_batch.reason=verification')
    return reasons


def _reasons_paused(sources):
    reasons = []
    reply = _source_data(sources, 'reply_status')
    batch = _source_data(sources, 'reply_batch')
    if reply.get('blocked_reason') == _CONSECUTIVE_REASON:
        reasons.append('reply_status.blocked_reason=consecutive_skips')
    message = str(reply.get('message') or '')
    if '连续' in message and '被拒绝或跳过' in message and '已暂停' in message:
        reasons.append('reply_status.message=consecutive_skip_pause')
    if batch.get('blocked_reason') == _CONSECUTIVE_REASON:
        reasons.append('reply_batch.blocked_reason=consecutive_skips')
    batch_reason = str(batch.get('reason') or '')
    if '连续' in batch_reason and '被拒绝或跳过' in batch_reason and '已暂停' in batch_reason:
        reasons.append('reply_batch.reason=consecutive_skip_pause')
    return reasons


def _reasons_reply_running(sources):
    reasons = []
    reply = _source_data(sources, 'reply_status')
    if reply.get('message') == _REPLY_RUNNING_MESSAGE:
        reasons.append('reply_status.message=本地任务运行中')
    return reasons


def _reasons_collection_running(sources):
    """Live collection signals that are not a leftover pid."""
    reasons = []
    recovery = _source_data(sources, 'collection_recovery')
    wait = _source_data(sources, 'collection_wait')
    if recovery.get('mode') == 'reconnecting':
        reasons.append('collection_recovery.mode=reconnecting')
    if wait.get('mode') == 'recovering_connection':
        reasons.append('collection_wait.mode=recovering_connection')
    return reasons


def _view(kind, evidence, float_mode=None):
    board = dict(BOARDS[kind])
    if float_mode is not None:
        board['float'] = float_mode
    elif kind == 'running':
        board['float'] = None
    board['evidence'] = list(evidence)
    board['process_liveness'] = 'not_checked'
    return board


def map_board_state(progress=None, root=None):
    """Return locked four-state fields plus optional float: need / replying.

    Priority: 需要你处理 > 已安全暂停（连续退回） > 运行中 > 待开始.
    A pid in active-runner.json or wait/reply pointers is ignored as a
    running signal.
    """
    if progress is None:
        progress = read_progress(root=root) if root is not None else read_progress()
    sources = progress.get('sources') or {}
    need = _reasons_need(sources)
    if need:
        return _view('need', need, float_mode='need')
    paused = _reasons_paused(sources)
    if paused:
        return _view('paused', paused, float_mode=None)
    reply_running = _reasons_reply_running(sources)
    collection_running = _reasons_collection_running(sources)
    if reply_running or collection_running:
        float_mode = 'replying' if reply_running else None
        return _view('running', reply_running + collection_running, float_mode=float_mode)
    ignored = []
    active = _source_data(sources, 'collection_active')
    if active.get('pid') is not None:
        ignored.append('ignored pid in collection_active (not used for 运行中)')
    return _view('idle', ignored, float_mode=None)


def read_board_view(root=None):
    root = Path(root) if root is not None else None
    progress = read_progress(root=root) if root is not None else read_progress()
    view = map_board_state(progress)
    view['observed_at'] = progress.get('observed_at')
    view['coverage'] = progress.get('coverage')
    return view
