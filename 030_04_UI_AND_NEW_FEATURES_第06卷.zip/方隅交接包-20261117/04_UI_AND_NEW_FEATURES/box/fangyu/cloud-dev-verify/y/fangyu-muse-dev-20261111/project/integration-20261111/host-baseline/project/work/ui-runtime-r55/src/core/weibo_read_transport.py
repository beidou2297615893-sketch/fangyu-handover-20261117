"""Staged Weibo reads. No production route, login, refresh or write dispatcher.

The caller supplies trusted account/identity evidence and the existing permission,
licence, account and platform guards. A user payload must not supply that evidence.
"""
from dataclasses import dataclass
from hashlib import sha256
from hmac import compare_digest
from html import unescape
import json
import os
from pathlib import Path
import re
import secrets
import stat
import time
from urllib.parse import urljoin, urlsplit

from .weibo_read_contract import AccountBinding, ReadStopped, _identifier, _items, _known_post_url, _map, _map_comments

import httpx
from weibo_cli.auth import Credential
from weibo_cli.client import WeiboClient
from weibo_cli.constants import BASE_URL, HEADERS, MOBILE_BASE_URL, MOBILE_HEADERS
from platform_cli import activity_checkpoint, record_request_event






def _no_links(path):
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if not current.exists():
            continue
        attrs = getattr(current.lstat(), 'st_file_attributes', 0)
        if current.is_symlink() or attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
            raise ReadStopped('account_path_not_isolated')


def _scope(binding, operation, *, ignore_request_id=None):
    if not isinstance(binding, AccountBinding) or binding.identity_verified is not True:
        raise ReadStopped('identity_unverified')
    for value in (binding.tenant_id, binding.account_id):
        if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', value):
            raise ReadStopped('account_binding_invalid')
    if not isinstance(binding.platform_uid, str) or not re.fullmatch(r'[1-9][0-9]{0,31}', binding.platform_uid):
        raise ReadStopped('identity_unverified')
    root = Path(binding.account_root)
    if not root.is_absolute() or '..' in root.parts or not root.is_dir():
        raise ReadStopped('account_path_not_isolated')
    _no_links(root)
    if root.name != binding.account_id or root.parent.name != binding.tenant_id:
        raise ReadStopped('account_binding_invalid')
    root = root.resolve(strict=True)
    for variable in ('HOME', 'USERPROFILE'):
        supplied = os.environ.get(variable)
        if not supplied or Path(supplied).resolve() != root:
            raise ReadStopped('account_environment_not_isolated')
    journal = root / 'platform-activity.jsonl'
    supplied = os.environ.get('WORKSPACE_ACTIVITY_LOG')
    if (os.environ.get('LEADSTUDIO_ISOLATED') != '1' or not supplied
            or Path(supplied).resolve() != journal or os.environ.get('WORKSPACE_ACTIVITY_KIND') != operation):
        raise ReadStopped('account_activity_binding_invalid')
    _no_links(journal)
    if journal.exists() and not journal.is_file():
        raise ReadStopped('account_activity_binding_invalid')
    if activity_checkpoint(ignore_request_id=ignore_request_id)[0]:
        raise ReadStopped('account_review_required')
    credential = root / '.config/weibo-cli/credential.json'
    _no_links(credential)
    if not credential.is_file() or credential.stat().st_size > 1024 * 1024:
        raise ReadStopped('saved_credential_required')
    expected = binding.credential_sha256
    if not isinstance(expected, str) or not re.fullmatch(r'[0-9a-fA-F]{64}', expected):
        raise ReadStopped('identity_credential_binding_invalid')
    raw = credential.read_bytes()
    if not compare_digest(sha256(raw).hexdigest(), expected.lower()):
        raise ReadStopped('identity_credential_changed')
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        raise ReadStopped('saved_credential_invalid') from None
    cookies = data.get('cookies') if isinstance(data, dict) else None
    if (not isinstance(cookies, dict) or not {'SUB', 'SUBP'} <= set(cookies)
            or not cookies or len(cookies) > 100
            or any(not isinstance(k, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', k)
                   or not isinstance(v, str) or not v or len(v) > 16384
                   or any(ch in v for ch in ('\r', '\n', ';')) for k, v in cookies.items())):
        raise ReadStopped('saved_credential_invalid')
    # No auth.load_credential/get_credential: even an old saved_at never refreshes.
    return Credential.from_dict(data)


class IsolatedWeiboClient(WeiboClient):
    def __init__(self, credential, binding, operation, authorize, transport, timeout,
                 post_id='', post_url='', resolve_post=None):
        super().__init__(credential, timeout=timeout, max_retries=1)
        self.binding, self.operation, self.authorize = binding, operation, authorize
        self.transport = transport
        self.deadline = time.monotonic() + timeout
        self.used = False
        self.received_payload = None
        self.normalized_items = None
        self.post_id, self.post_url = post_id, post_url
        self.resolve_post = resolve_post

    def _make_client(self, base, headers):
        return httpx.Client(base_url=base, headers=dict(headers), cookies=self.credential.cookies,
                            follow_redirects=False, trust_env=False, timeout=self._timeout,
                            transport=self.transport)

    def _build_client(self):
        return self._make_client(BASE_URL, HEADERS)

    def _build_mobile_client(self):
        return self._make_client(MOBILE_BASE_URL, MOBILE_HEADERS)

    def _check_current(self, *, ignore_request_id=None):
        self.authorize(self.binding, self.operation)
        _scope(self.binding, self.operation, ignore_request_id=ignore_request_id)
        if self.operation == 'comments' and _known_post_url(
                self.binding, self.post_id, self.resolve_post) != self.post_url:
            raise ReadStopped('known_post_source_changed')

    def _request(self, method, url, *, client=None, **kwargs):
        http = client or self.client
        parsed = urlsplit(urljoin(str(http.base_url), str(url)))
        expected = {'search': ('m.weibo.cn', '/api/container/getIndex'),
                    'comments': ('weibo.com', '/ajax/statuses/buildComments')}[self.operation]
        if (method != 'GET' or parsed.scheme != 'https' or (parsed.netloc, parsed.path) != expected
                or parsed.query or parsed.fragment or set(kwargs) != {'params'}):
            raise ReadStopped('unsupported_read_route')
        if self.used:
            raise ReadStopped('action_request_budget_exhausted')
        self._check_current()
        review, last_finished = activity_checkpoint()
        if review:
            raise ReadStopped('account_review_required')
        if last_finished:
            self._last_request_time = max(self._last_request_time, min(last_finished, time.time()))
        self._rate_limit_delay()
        self._check_current()
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise ReadStopped('action_time_budget_exhausted')
        request_id = secrets.token_hex(8)
        record_request_event('started', request_id, method)
        started = time.monotonic()
        status = 'cancelled_before_send'
        http_status = None
        try:
            self._check_current(ignore_request_id=request_id)
            remaining = self.deadline - time.monotonic()
            if remaining <= 0:
                raise ReadStopped('action_time_budget_exhausted')
            self.used = True  # One budget shared by web/mobile and consumed on any attempt.
            status = 'transport_error'
            response = http.request(method, url, params=kwargs['params'],
                                    follow_redirects=False, timeout=remaining)
            http_status = response.status_code
            if not 200 <= http_status < 300:
                status = (http_status if http_status in (401, 403, 429) or 300 <= http_status < 400
                          else 'transport_error')
                code = ('not_authenticated' if http_status == 401 else
                        'verification_required' if http_status in (403, 429) or 300 <= http_status < 400
                        else 'transport_error')
                raise ReadStopped(code)
            if len(response.content) > 8 * 1024 * 1024:
                status = 'protocol_error'
                raise ReadStopped(status)
            try:
                payload = response.json()
            except (ValueError, UnicodeError):
                status = 'protocol_error'
                raise ReadStopped(status) from None
            if not isinstance(payload, dict) or type(payload.get('ok')) is not int:
                status = 'protocol_error'
                raise ReadStopped(status)
            if payload['ok'] != 1:
                status = 'api_error'
                raise ReadStopped('not_authenticated' if payload['ok'] == -100 else 'api_error')
            # Preserve the full response before vendor _get unwraps data/max_id.
            self.received_payload = payload
            self.normalized_items = (_map(payload) if self.operation == 'search'
                                     else _map_comments(payload, self.post_id, self.post_url))
            status = http_status
            self._mark_request()
            return payload
        except ReadStopped as exc:
            if exc.code == 'protocol_error':
                status = 'protocol_error'
            raise
        except PermissionError:
            raise
        except Exception:
            raise ReadStopped('transport_error') from None
        finally:
            record_request_event('finished', request_id, method, status=status,
                                 http_status=http_status, elapsed_ms=(time.monotonic() - started) * 1000)












def execute_read(binding, operation, *, authorize, keyword='', page=1, post_id='',
                 post_url='', resolve_post=None, max_id='0', count=20, transport=None, timeout=30):
    if operation not in ('search', 'comments') or not callable(authorize):
        raise ReadStopped('unsupported_read_operation')
    if type(timeout) not in (int, float) or not 0 < timeout <= 35:
        raise ReadStopped('read_arguments_invalid')
    if operation == 'search':
        if (not isinstance(keyword, str) or not keyword.strip() or len(keyword) > 500
                or type(page) is not int or not 1 <= page <= 10000):
            raise ReadStopped('read_arguments_invalid')
    else:
        if (not isinstance(post_id, str) or not re.fullmatch(r'[1-9][0-9]{0,31}', post_id)
                or not isinstance(post_url, str)
                or post_url and not re.fullmatch(r'https://weibo\.com/[1-9][0-9]{0,31}/[A-Za-z0-9]{1,32}', post_url)
                or type(max_id) not in (str, int) or not re.fullmatch(r'0|[1-9][0-9]{0,31}', str(max_id))
                or type(count) is not int or not 1 <= count <= 100):
            raise ReadStopped('known_post_arguments_invalid')
    authorize(binding, operation)
    credential = _scope(binding, operation)
    if operation == 'comments':
        original_url = _known_post_url(binding, post_id, resolve_post)
        if post_url and post_url != original_url:
            raise ReadStopped('known_post_source_mismatch')
        post_url = original_url
    with IsolatedWeiboClient(credential, binding, operation, authorize, transport, timeout,
                            post_id=post_id, post_url=post_url, resolve_post=resolve_post) as client:
        # Genuine pinned vendor method. No command helper or refresh handler runs.
        if operation == 'search':
            client.search_weibo(keyword, page=page)
        else:
            client.get_comments(post_id, count=count, max_id=int(max_id))
        raw = client.received_payload
        items = client.normalized_items
    result = {'platform': 'weibo', 'operation': operation, 'raw': raw, 'items': items}
    if operation == 'search':
        result['requested_page'] = page
    else:
        data = raw.get('data')
        result.update(post_id=post_id, requested_max_id=str(max_id),
                      max_id=raw.get('max_id', data.get('max_id') if isinstance(data, dict) else None))
    return result
