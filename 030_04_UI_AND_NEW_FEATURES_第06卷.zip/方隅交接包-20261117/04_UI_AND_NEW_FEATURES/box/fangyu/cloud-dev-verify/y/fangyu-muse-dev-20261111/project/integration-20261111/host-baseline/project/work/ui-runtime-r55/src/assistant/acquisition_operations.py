"""Local acquisition handoffs: no platform sends, cloud ACKs, or fee calculation.

The caller supplies an authenticated principal, and this module rechecks the
persisted user. Company policy is trusted constructor configuration, never an
action payload. Business receipts require a separate, explicitly authorized
receiver. A prepared local handoff is not delivery to the resource department.
"""
from __future__ import annotations

from contextlib import nullcontext
from copy import deepcopy
import hashlib
import json
import math
import re
import time
from uuid import uuid4

from core import CoreError
from .customer_list import CustomerHistory, _person


ACTIONS = frozenset(('acquisition_overview', 'handoff_list', 'handoff_detail',
    'handoff_create', 'handoff_update', 'handoff_submit', 'handoff_receipt',
    'attribution_case_list'))
READ_ACTIONS = frozenset(('acquisition_overview', 'handoff_list', 'handoff_detail',
                         'attribution_case_list'))
HANDOFFS = 'acquisition_handoffs'
EVENTS = 'acquisition_events'
REQUESTS = 'acquisition_requests'
_ID = re.compile(r'[a-zA-Z0-9_-]{1,160}\Z')
_KEY = re.compile(r'[a-zA-Z0-9_-]{8,128}\Z')
_REF = re.compile(r'(?:evidence|consent|notice|document):[a-f0-9]{32}\Z')
_CONTACT = re.compile(r'contact:[a-f0-9]{32}\Z')
_PHONE = re.compile(r'(?<!\d)1[3-9]\d{9}(?!\d)')
_SECRET = re.compile(r'(?:\bBearer\s+|sk-[\w-]{12}|(?:cookie|password|secret|api[_-]?key)\s*[:=])', re.I)
STATUS_TEXT = {'draft': '待整理', 'ready_to_deliver': '待送达资源部',
    'accepted': '授权接收主体已确认', 'rejected': '已拒收',
    'needs_information': '待补资料', 'duplicate_pending_review': '重复客户待核对',
    'existing_customer_pending_review': '既有客户待核对',
    'withdrawn': '已撤回', 'disputed': '归属待核对'}


class AcquisitionError(CoreError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        # All AcquisitionError paths validate before commit or unwind the
        # enclosing SQLite transaction. No committed outcome raises this type.
        self.mutation_committed = False


def _fail(code, message):
    raise AcquisitionError('ACQUISITION_' + code, message)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def _digest(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()


def _text(value, label, limit=160, *, required=True):
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()) or '\x00' in value:
        _fail('INVALID_INPUT', label + '格式无效')
    value = value.strip()
    compact = re.sub(r'[\s()+.-]', '', value)
    if (re.search(r'\d{10,}', compact) or _SECRET.search(value) or
            re.search(r'(?:微信|wechat|wx|手机号|电话)\s*[:：=]', value, re.I)):
        _fail('PRIVATE_INPUT', '联系方式请使用受保护引用；请勿填写手机号、微信号或密钥')
    return value


def _ident(value, label):
    if not isinstance(value, str) or not _ID.fullmatch(value):
        _fail('INVALID_INPUT', label + '格式无效')
    return value


def _reference(value, label):
    if not isinstance(value, str) or not _REF.fullmatch(value):
        _fail('INVALID_EVIDENCE', label + '需使用已留存证据的受限引用')
    return value


class AcquisitionOperations:
    def __init__(self, core, tenant, owner, company, *, lead_access=None, owner_scope=None):
        if not isinstance(tenant, str) or not tenant or not isinstance(owner, str) or not owner:
            raise ValueError('交接记录归属无效')
        if not isinstance(company, dict) or not company.get('id'):
            raise ValueError('交接企业配置无效')
        self.core, self.tenant, self.owner = core, tenant, owner
        self.company = company
        self.company_id = company['id']
        self.lead_access = lead_access
        self._owner_scope = None
        if owner_scope is not None:
            from .self_operating_acquisition import _validated_owner_scope
            self._owner_scope = _validated_owner_scope(owner_scope, core, tenant, owner, company)
        policy = company.get('acquisitionPolicy', {})
        self.policy = deepcopy(policy) if isinstance(policy, dict) else {}

    def _row(self, db, entity, ident):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (entity, ident, self.tenant)).fetchone()
        return json.loads(row['body']) if row else None

    def _put(self, db, entity, record, *, new=False):
        statement = 'INSERT INTO records VALUES(?,?,?,?)' if new else 'UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?'
        args = (entity, record['id'], self.tenant, _canonical(record)) if new else (_canonical(record), entity, record['id'], self.tenant)
        cursor = db.execute(statement, args)
        if not new and cursor.rowcount != 1:
            _fail('NOT_FOUND', '记录不存在或无权访问')

    def _user(self, db, principal):
        if self._owner_scope is not None:
            return self._owner_scope.check(principal, db)
        if not isinstance(principal, dict) or principal.get('tenant_id') != self.tenant:
            _fail('FORBIDDEN', '交接仅限当前企业的已认证账号')
        stored = self._row(db, 'users', principal.get('id'))
        if (not stored or stored.get('username') != principal.get('username') or
                stored.get('disabled') or stored.get('tenant_id') != self.tenant or
                stored.get('role') not in ('admin', 'operator') or
                stored.get('role') != principal.get('role') or
                (stored.get('role') == 'operator' and stored.get('cloud_bound') is not True)):
            _fail('FORBIDDEN', '账号身份或权限已变化，请重新核对登录')
        return stored

    def _recipients(self):
        configured = self.policy.get('recipients')
        rows = configured if isinstance(configured, list) else [{'id': 'resource_department', 'name': '资源部'}]
        result = []
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get('id'), str) or not _ID.fullmatch(row['id']):
                continue
            name = row.get('name')
            if not isinstance(name, str) or not name.strip() or len(name) > 100 or _PHONE.search(name):
                continue
            result.append({'id': row['id'], 'name': name, 'receiver_configured': False if self._owner_scope is not None else self._has_receiver(row['id'])})
        return result

    def _has_receiver(self, recipient):
        rows = self.policy.get('receivers', {})
        if not isinstance(rows, dict):
            return False
        return any(recipient in ([value] if isinstance(value, str) else value if isinstance(value, list) else [])
                   for value in rows.values())

    def _receiver(self, user, recipient):
        if self._owner_scope is not None:
            return False
        rows = self.policy.get('receivers', {})
        value = rows.get(user['username']) if isinstance(rows, dict) else None
        return recipient in ([value] if isinstance(value, str) else value if isinstance(value, list) else [])

    def _manager(self, user):
        if self._owner_scope is not None:
            return False
        managers = self.policy.get('managers', [])
        return user.get('role') == 'admin' or (isinstance(managers, list) and user['username'] in managers)

    def _permissions(self, user):
        if self._owner_scope is not None:
            return {'can_create': True, 'can_manage': False, 'receipt_recipients': [], 'resource_receiver_configured': False}
        return {'can_create': user['username'] == self.owner and user.get('can_handoff') is not False,
                'can_manage': self._manager(user),
                'receipt_recipients': [r['id'] for r in self._recipients() if self._receiver(user, r['id'])],
                'resource_receiver_configured': any(r['receiver_configured'] for r in self._recipients())}

    def _owner_user(self, db):
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', ('users', self.tenant)).fetchall()
        owners = [json.loads(row['body']) for row in rows if json.loads(row['body']).get('username') == self.owner]
        if len(owners) != 1 or owners[0].get('disabled') or owners[0].get('cloud_bound') is not True:
            _fail('FORBIDDEN', '交接来源员工已失效，暂不能操作')
        return owners[0]

    def _lead(self, db, ident, user):
        lead = self._row(db, 'leads', ident)
        if not lead or lead.get('demo') or lead.get('tenant_id') != self.tenant or lead.get('cloud_owner') not in (None, '', self.owner):
            _fail('NOT_FOUND', '原始线索不存在或无权访问')
        owner_user = user if user['username'] == self.owner else self._owner_user(db)
        try:
            if callable(self.lead_access):
                self.lead_access(owner_user, lead)
            elif lead.get('task_id'):
                task = self.core._get('tasks', lead['task_id'], self.tenant)
                self.core._task_access(owner_user, task, self.tenant)
            elif lead.get('cloud_owner') != self.owner:
                _fail('NOT_FOUND', '原始线索缺少可核实的归属')
        except (CoreError, ValueError):
            _fail('NOT_FOUND', '原始线索不存在或无权访问')
        if self._owner_scope is not None:
            self._owner_scope.source(user, lead, db)
        return lead

    def _can_view(self, user, item):
        if self._owner_scope is not None:
            return self._owner_scope.can_view(user, item)
        return (item.get('tenant_id') == self.tenant and item.get('company_id') == self.company['id'] and
                isinstance(item.get('cloud_owner'), str) and bool(item['cloud_owner']) and
                (user['username'] == item['cloud_owner'] or self._manager(user) or self._receiver(user, item.get('recipient_id'))))

    def _source_lead(self, db, item, user):
        if user['username'] == item['cloud_owner']:
            # The source employee keeps the original lead-access gate.
            return self._lead(db, item['lead_id'], user)
        # Receiving is a distinct permission. Never impersonate the submitter or
        # require a recipient to hold the submitter's task permission. Validate
        # the persisted source scope without projecting any raw comment/contact.
        lead = self._row(db, 'leads', item['lead_id'])
        if (not lead or lead.get('demo') or lead.get('tenant_id') != self.tenant or
                lead.get('cloud_owner') not in (None, '', item['cloud_owner'])):
            _fail('NOT_FOUND', '交接来源范围需核对，暂不能读取或接收')
        return lead

    def _item(self, db, ident, user):
        item = self._row(db, HANDOFFS, ident)
        if not item or not self._can_view(user, item):
            _fail('NOT_FOUND', '交接记录不存在或无权访问')
        self._source_lead(db, item, user)
        self._events(db, item)
        return item

    def _all(self, db, user, *, event_index=None):
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (HANDOFFS, self.tenant)).fetchall()
        event_index = self._event_index(db) if event_index is None else event_index
        items = []
        for row in rows:
            item = json.loads(row['body'])
            if not self._can_view(user, item):
                continue
            try:
                self._source_lead(db, item, user)
            except AcquisitionError:
                continue
            self._events(db, item, event_index=event_index)
            items.append(item)
        return sorted(items, key=lambda item: (item['updated_at'], item['id']), reverse=True)

    def _event_index(self, db):
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (EVENTS, self.tenant)).fetchall()
        grouped = {}
        for row in rows:
            event = json.loads(row['body'])
            grouped.setdefault(event.get('handoff_id'), []).append(event)
        return grouped

    def _events(self, db, item, *, event_index=None):
        grouped = self._event_index(db) if event_index is None else event_index
        events = sorted(grouped.get(item['id'], []), key=lambda event: event['sequence'])
        previous = ''
        for index, event in enumerate(events, 1):
            unhashed = {key: value for key, value in event.items() if key != 'chain_hash'}
            if (event.get('cloud_owner') != item['cloud_owner'] or event.get('sequence') != index or
                    event.get('previous_hash') != previous or event.get('chain_hash') != _digest(unhashed)):
                _fail('AUDIT_CONFLICT', '交接审计记录需核对，未继续操作')
            previous = event['chain_hash']
        snapshot = {key: value for key, value in item.items() if key != 'last_event_hash'}
        if (len(events) != item['revision'] or previous != item.get('last_event_hash') or
                (events and events[-1].get('snapshot_hash') != _digest(snapshot))):
            _fail('AUDIT_CONFLICT', '交接版本与审计记录不一致，未继续操作')
        return events

    def _recipient(self, value):
        value = _ident(value, '接收方')
        row = next((row for row in self._recipients() if row['id'] == value), None)
        if not row:
            _fail('RECIPIENT_REQUIRED', '请由管理员配置明确的资源部接收方')
        return row

    def _consent(self, value):
        if not isinstance(value, dict) or set(value) != {'status', 'evidence_reference', 'notice_version'} or value.get('status') != 'granted':
            _fail('CONSENT_REQUIRED', '请先登记客户对指定接收方及用途的明确同意证据')
        if not isinstance(value['evidence_reference'], str) or not re.fullmatch(r'consent:[a-f0-9]{32}', value['evidence_reference']):
            _fail('CONSENT_REQUIRED', '客户同意证据需使用明确的同意记录引用')
        return {'status': 'granted', 'evidence_reference': value['evidence_reference'],
                'notice_version': _text(value['notice_version'], '告知版本', 80),
                'evidence_source': 'operator_recorded', 'independently_verified': False}

    def _contact(self, db, reference, lead, recipient, purpose, consent, *, source_owner=None):
        source_owner = self.owner if source_owner is None else source_owner
        uid, platform = lead.get('author_id'), lead.get('platform')
        derived = f'platform:{platform}:{uid}' if isinstance(uid, str) and _ID.fullmatch(uid) and isinstance(platform, str) and _ID.fullmatch(platform) else ''
        if reference in (None, ''):
            if not derived:
                _fail('IDENTITY_REQUIRED', '客户身份待核实，暂不能建立可联系交接')
            reference = derived
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                          ('acquisition_consent_withdrawals', self.tenant)).fetchall()
        for row in rows:
            prior = json.loads(row['body'])
            # A consent UUID names one authorization within this tenant. Changing
            # lead, owner, recipient or purpose cannot revive withdrawn evidence.
            if prior.get('consent_reference') == consent.get('evidence_reference'):
                _fail('CONSENT_REQUIRED', '客户已撤回这份授权，不能复用旧同意证据重新交接')
        if isinstance(reference, str) and reference.startswith('platform:'):
            if not derived or reference != derived:
                _fail('CONTACT_INVALID', '平台联系方式与原始客户身份不一致')
            return derived
        if not isinstance(reference, str) or not _CONTACT.fullmatch(reference):
            _fail('CONTACT_INVALID', '联系方式必须使用受保护引用，不接受手机号或微信明文')
        row = self._row(db, 'acquisition_contacts', reference)
        if row is None:
            row = self._row(db, 'acquisition_contacts', reference.split(':', 1)[1])
        contact_consent = row.get('consent') if isinstance(row, dict) else None
        if (not row or row.get('tenant_id') != self.tenant or row.get('cloud_owner') != source_owner or row.get('lead_id') != lead['id'] or
                row.get('recipient_id') != recipient or row.get('purpose') != purpose or row.get('revoked_at') or
                row.get('storage_scope') != 'local_current_windows_user' or
                not isinstance(contact_consent, dict) or contact_consent.get('status') != 'granted' or
                contact_consent.get('evidence_reference') != consent.get('evidence_reference') or
                contact_consent.get('notice_version') != consent.get('notice_version') or
                not row.get('encrypted_payload')):
            _fail('CONTACT_INVALID', '联系方式引用的归属、用途或客户授权已失效')
        if self._owner_scope is not None:
            self._owner_scope.check(db=db, record=row)
        return reference

    def _fields(self, db, data, lead):
        recipient = self._recipient(data.get('recipient_id'))
        purpose = _text(data.get('purpose'), '交接用途', 100)
        consent = self._consent(data.get('consent'))
        reference = self._contact(db, data.get('contact_reference'), lead, recipient['id'], purpose, consent)
        return {'recipient_id': recipient['id'], 'recipient_name': recipient['name'], 'purpose': purpose,
                'consent': consent, 'contact_reference': reference}

    def _withdrawal_index(self, db):
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                          ('acquisition_consent_withdrawals', self.tenant)).fetchall()
        grouped = {}
        for row in rows:
            entry = json.loads(row['body'])
            if not isinstance(entry, dict):
                _fail('AUDIT_CONFLICT', '客户授权撤回台账需核对，未继续操作')
            grouped.setdefault(entry.get('consent_reference'), []).append(entry)
        return grouped

    def _current_authorization(self, db, item, *, withdrawal_index=None):
        """Project current scope metadata; never decrypt or rewrite history.

        A granted snapshot is an operator's recorded consent, not a verified
        signature. A tenant-wide permanent withdrawal always takes precedence.
        """
        def result(state, reason, source, stamp=None):
            labels = {'granted': '当前授权有效（本机登记）',
                      'withdrawn': '当前联系方式授权已撤回',
                      'unavailable': '当前联系方式授权待核对'}
            return {'state': state, 'status_text': labels[state], 'reason_code': reason,
                    'source': source, 'revoked_at': stamp if type(stamp) in (int, float) and math.isfinite(stamp) and stamp >= 0 else None,
                    'validation_scope': 'local_consent_and_storage_metadata',
                    'independently_verified': False}

        consent = item.get('consent') or {}
        reference = consent.get('evidence_reference')
        index = self._withdrawal_index(db) if withdrawal_index is None else withdrawal_index
        withdrawals = index.get(reference, [])
        if withdrawals:
            if any(entry.get('tenant_id') != self.tenant for entry in withdrawals):
                return result('unavailable', 'withdrawal_scope_conflict', 'withdrawal_ledger')
            timestamps = [entry.get('occurred_at') for entry in withdrawals
                          if type(entry.get('occurred_at')) in (int, float) and math.isfinite(entry['occurred_at'])]
            return result('withdrawn', 'consent_withdrawn', 'withdrawal_ledger', max(timestamps) if timestamps else None)
        if consent.get('status') != 'granted' or not isinstance(reference, str) or not re.fullmatch(r'consent:[a-f0-9]{32}', reference):
            return result('unavailable', 'recorded_consent_not_granted', 'handoff_snapshot')

        lead = self._row(db, 'leads', item['lead_id'])
        if (not lead or lead.get('demo') or lead.get('tenant_id') != self.tenant or
                lead.get('cloud_owner') not in (None, '', item['cloud_owner']) or
                any(lead.get(key) != item.get('source', {}).get(key) for key in ('platform', 'author_id'))):
            return result('unavailable', 'source_identity_changed', 'current_source_record')
        contact_reference = item.get('contact_reference')
        if isinstance(contact_reference, str) and contact_reference.startswith('platform:'):
            uid, platform = lead.get('author_id'), lead.get('platform')
            if (isinstance(uid, str) and _ID.fullmatch(uid) and isinstance(platform, str) and _ID.fullmatch(platform) and
                    contact_reference == f'platform:{platform}:{uid}'):
                return result('granted', 'recorded_scope_active', 'current_source_and_withdrawal_ledger')
            return result('unavailable', 'contact_reference_mismatch', 'current_source_record')
        if not isinstance(contact_reference, str) or not _CONTACT.fullmatch(contact_reference):
            return result('unavailable', 'contact_reference_unavailable', 'protected_contact')
        contact = self._row(db, 'acquisition_contacts', contact_reference)
        if contact is None:
            contact = self._row(db, 'acquisition_contacts', contact_reference.split(':', 1)[1])
        saved_consent = contact.get('consent') if isinstance(contact, dict) else None
        if (not contact or contact.get('tenant_id') != self.tenant or contact.get('cloud_owner') != item['cloud_owner'] or
                contact.get('lead_id') != item['lead_id'] or contact.get('recipient_id') != item['recipient_id'] or
                contact.get('purpose') != item['purpose'] or not isinstance(saved_consent, dict) or
                saved_consent.get('evidence_reference') != reference or saved_consent.get('notice_version') != consent.get('notice_version')):
            return result('unavailable', 'contact_scope_mismatch', 'protected_contact')
        if self._owner_scope is not None:
            try:
                self._owner_scope.check(db=db, record=contact)
            except CoreError:
                return result('unavailable', 'contact_scope_mismatch', 'protected_contact')
        if contact.get('revoked_at') or saved_consent.get('status') == 'withdrawn':
            return result('withdrawn', 'protected_contact_withdrawn', 'protected_contact', contact.get('revoked_at'))
        if (saved_consent.get('status') != 'granted' or contact.get('storage_scope') != 'local_current_windows_user' or
                not contact.get('encrypted_payload')):
            return result('unavailable', 'protected_contact_unavailable', 'protected_contact')
        return result('granted', 'recorded_scope_active', 'protected_contact_and_withdrawal_ledger')

    def _require_current_authorization(self, db, item):
        authorization = self._current_authorization(db, item)
        if authorization['state'] != 'granted':
            code = 'CONSENT_REQUIRED' if authorization['reason_code'] in ('consent_withdrawn', 'recorded_consent_not_granted') else 'CONTACT_INVALID'
            _fail(code, authorization['status_text'] + '，不能再次交付或确认接收')

    def _customer_display_name(self, db, item, actor):
        """Optional current nickname, never a saved identity or contact proof."""
        if not actor:
            return None
        try:
            trusted_actor = self._user(db, actor)
            if not self._can_view(trusted_actor, item):
                return None
            lead = self._source_lead(db, item, trusted_actor)
            source = item.get('source') or {}
            if (lead.get('id') != item.get('lead_id') or lead.get('tenant_id') != self.tenant or
                    lead.get('cloud_owner') != item.get('cloud_owner') or
                    any(not isinstance(source.get(key), str) or not source[key].strip() or
                        lead.get(key) != source[key] for key in ('platform', 'author_id'))):
                return None
            name = _text(lead.get('author'), '客户显示名称', limit=160)
            # Normalize ONLY for privacy checks. Safe nicknames retain their
            # original fullwidth/emoji presentation; source records are untouched.
            import unicodedata
            checked = unicodedata.normalize('NFKC', name)
            checked = ''.join(char for char in checked if unicodedata.category(char) not in ('Cc', 'Cf', 'Cs'))
            _text(checked, '客户显示名称', limit=160)
            number_scan = ''.join(char for char in checked if unicodedata.category(char)[0] not in ('P', 'Z'))
            if re.search(r'\d{7,}', number_scan):
                return None
            return name
        except AcquisitionError:
            # An unavailable source or unsafe nickname is an absent optional
            # label, never a new authorization or an error that rewrites history.
            return None

    def _public(self, db, item, actor=None, *, withdrawal_index=None, history_events=None):
        value = deepcopy(item)
        value.pop('customer_display_name', None)
        name = self._customer_display_name(db, item, actor)
        if name is not None:
            value['customer_display_name'] = name
        value['status_text'] = STATUS_TEXT.get(item['status'], '待核对')
        value['local_only'] = True
        value['cross_machine_verified'] = False
        authorization = self._current_authorization(db, item, withdrawal_index=withdrawal_index)
        value['current_authorization'] = authorization
        value['current_consent_valid'] = authorization['state'] == 'granted'
        events = self._events(db, item) if history_events is None else history_events
        value['historical_resource_receipt_verified'] = any(
            event.get('action') == 'handoff_receipt' and event.get('status') == 'accepted' and
            event.get('actor') != item['submitted_by'] for event in events)
        # Compatibility: this remains an accepted, independently recorded receipt
        # fact. Current business eligibility is separate from that historical ACK.
        value['resource_receipt_verified'] = item['status'] == 'accepted' and item.get('receipt', {}).get('verified') is True
        value['eligible_for_delivery'] = value['current_consent_valid'] and item['status'] == 'ready_to_deliver' and item['qualification'] == 'qualified'
        value['eligible_for_attribution'] = False  # No real attribution/settlement adjudication is configured.
        if not value['current_consent_valid']:
            prefix = '历史接收已确认' if value['historical_resource_receipt_verified'] else value['status_text']
            value['status_text'] = prefix + '；' + authorization['status_text']
        value['settlement'] = {'status': 'not_configured', 'amount_cents': None, 'policy_status': 'candidate'}
        owner = bool(actor and actor['username'] == item['cloud_owner'] and actor.get('can_handoff') is not False)
        reviewer = bool(actor and self._manager(actor) and actor['username'] != item['submitted_by'])
        value['permissions'] = {
            'can_edit': owner and item['status'] in ('draft', 'needs_information', 'rejected'),
            'can_submit': owner and value['current_consent_valid'] and item['status'] == 'draft' and item['qualification'] == 'qualified',
            'can_withdraw': owner and item['status'] != 'withdrawn',
            'can_dispute': owner and item['status'] != 'withdrawn',
            'can_receipt': bool(actor and actor['username'] != item['submitted_by'] and
                                self._receiver(actor, item['recipient_id']) and value['current_consent_valid'] and item['status'] == 'ready_to_deliver'),
            'can_review': reviewer and (item['status'] in ('duplicate_pending_review', 'existing_customer_pending_review', 'disputed') or
                                        item.get('qualification') in ('duplicate', 'existing_customer'))}
        if self._owner_scope is not None:
            self._owner_scope.check(actor, db, item)
            value.pop('owner_acquisition_scope', None)
            value.pop('customer_display_name', None)
            value['permissions'] = {key: False for key in value['permissions']}
            value['eligible_for_delivery'] = False
            value['resource_receipt_verified'] = False
            value['historical_resource_receipt_verified'] = False
        return value

    def _result(self, db, item, actor=None, *, history_events=None, **extra):
        if self._owner_scope is not None:
            self._owner_scope.check(actor, db, item)
        return {'item': self._public(db, item, actor, history_events=history_events), 'id': item['id'], 'revision': item['revision'],
                'local_only': True, 'cross_machine_verified': False, **extra}

    def _append(self, db, item, user, action):
        stamp = int(time.time())
        item['updated_at'] = stamp
        event = {'id': uuid4().hex, 'tenant_id': self.tenant, 'cloud_owner': item['cloud_owner'],
                 'company_id': self.company['id'], 'handoff_id': item['id'],
                 'sequence': item['revision'], 'actor_id': user['id'], 'actor': user['username'],
                 'action': action, 'server_recorded_at': stamp, 'status': item['status'],
                 'snapshot_hash': _digest({k: v for k, v in item.items() if k != 'last_event_hash'}),
                 'previous_hash': item.get('last_event_hash', '')}
        event['chain_hash'] = _digest(event)
        self._put(db, EVENTS, event, new=True)
        item['last_event_hash'] = event['chain_hash']

    def _write_access(self, user, item=None):
        source_owner = item['cloud_owner'] if item is not None else self.owner
        if user['username'] != source_owner or user.get('can_handoff') is False:
            _fail('FORBIDDEN', '仅来源员工可以整理和提交自己的交接记录')

    def execute(self, action, data, user):
        if action not in ACTIONS or not isinstance(data, dict):
            _fail('INVALID_INPUT', '交接操作或参数无效')
        if self._owner_scope is not None:
            self._owner_scope.require_action(action)
        common = {'id', 'expected_revision', 'idempotency_key'}
        fields = {'lead_id', 'recipient_id', 'purpose', 'consent', 'contact_reference'}
        allowed = {
            'acquisition_overview': set(), 'handoff_list': {'status', 'offset', 'limit', 'customer_lead_id'},
            'attribution_case_list': {'offset', 'limit'}, 'handoff_detail': {'id'},
            'handoff_create': fields | {'idempotency_key'},
            'handoff_update': common | (fields - {'lead_id'}) | {'operation', 'qualification', 'reason_code', 'evidence_reference'},
            'handoff_submit': common,
            'handoff_receipt': common | {'decision', 'reason_code', 'evidence_reference'}}
        if set(data) - allowed[action]:
            _fail('INVALID_INPUT', '交接参数包含未授权字段；身份与时间由服务端核对')
        with getattr(self.core, 'lock', nullcontext()):
            if self.company.get('id') != self.company_id:
                _fail('FORBIDDEN', '企业配置已变化，请重新初始化当前交接服务')
            configured_policy = self.company.get('acquisitionPolicy', {})
            self.policy = deepcopy(configured_policy) if isinstance(configured_policy, dict) else {}
            with self.core.store.connect() as db:
                db.execute('BEGIN' if action in READ_ACTIONS else 'BEGIN IMMEDIATE')
                actor = self._user(db, user)
                if action in READ_ACTIONS:
                    return self._read(db, action, data, actor)
                if action == 'handoff_receipt':
                    item = self._item(db, _ident(data.get('id'), '交接编号'), actor)
                    if not self._receiver(actor, item['recipient_id']) or actor['username'] == item['submitted_by']:
                        _fail('RECEIVER_REQUIRED', '需独立授权的资源部接收主体确认，提交人不能自行确认接收')
                elif action == 'handoff_update' and data.get('operation') == 'review':
                    if not self._manager(actor):
                        _fail('MANAGER_REQUIRED', '归属冲突需有权审核人独立核对')
                elif action in ('handoff_update', 'handoff_submit'):
                    item = self._item(db, _ident(data.get('id'), '交接编号'), actor)
                    self._write_access(actor, item)
                else:
                    self._write_access(actor)
                key = data.get('idempotency_key')
                if not isinstance(key, str) or not _KEY.fullmatch(key):
                    _fail('IDEMPOTENCY_REQUIRED', '请提供稳定的操作编号，避免重复提交')
                request_id = _digest((self.tenant, self.owner, actor['id'], action, key))
                old_request = self._row(db, REQUESTS, request_id)
                payload_hash = _digest(data)
                if old_request:
                    if old_request['payload_hash'] != payload_hash:
                        _fail('IDEMPOTENCY_CONFLICT', '同一操作编号的内容已变化，请先核对原操作')
                    current = self._item(db, old_request['handoff_id'], actor)
                    return self._result(db, current, actor, replayed=True, original_revision=old_request['revision'])
                if action == 'handoff_create':
                    lead = self._lead(db, _ident(data.get('lead_id'), '原始线索编号'), actor)
                    values = self._fields(db, data, lead)
                    stamp = int(time.time())
                    item = {'id': uuid4().hex, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                        'company_id': self.company['id'], 'lead_id': lead['id'], 'customer_key': _person(lead)[0],
                        'source': {'platform': lead.get('platform'), 'author_id': lead.get('author_id'),
                                   'comment_id': lead.get('comment_id'), 'task_id': lead.get('task_id'),
                                   'original_text_hash': _digest(lead.get('text', ''))},
                        **values, 'status': 'draft', 'qualification': 'unreviewed',
                        'attribution_status': 'unconfirmed', 'policy_status': 'candidate',
                        'submitted_by': actor['username'], 'created_at': stamp, 'updated_at': stamp,
                        'revision': 1, 'delivery_status': 'not_submitted', 'receipt': {}, 'last_event_hash': ''}
                    if self._owner_scope is not None:
                        item['owner_acquisition_scope'] = self._owner_scope.binding(db)
                    self._append(db, item, actor, action)
                    self._put(db, HANDOFFS, item, new=True)
                else:
                    item = self._item(db, _ident(data.get('id'), '交接编号'), actor)
                    if type(data.get('expected_revision')) is not int or data['expected_revision'] != item['revision']:
                        _fail('REVISION_CONFLICT', '交接记录已变化，请重新读取后再操作')
                    if action == 'handoff_update':
                        self._update(db, item, data, actor)
                    elif action == 'handoff_submit':
                        self._submit(db, item, actor)
                    else:
                        self._receipt(db, item, data, actor)
                    item['revision'] += 1
                    self._append(db, item, actor, action)
                    self._put(db, HANDOFFS, item)
                self._put(db, REQUESTS, {'id': request_id, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                    'handoff_id': item['id'], 'actor_id': actor['id'], 'payload_hash': payload_hash,
                    'revision': item['revision']}, new=True)
                message = ('交接已在本机登记，尚未送达资源部；接收回执须由授权接收主体确认'
                           if action == 'handoff_submit' else '本机交接记录已保存；归属及结算仍需业务核对')
                return self._result(db, item, actor, replayed=False, message=message)

    def _update(self, db, item, data, actor):
        operation = data.get('operation', 'edit')
        if operation == 'review':
            if actor['username'] == item['submitted_by']:
                _fail('REVIEWER_REQUIRED', '来源员工不能自行解除归属冲突，需另一位有权审核人核对')
            if set(data) - {'id', 'expected_revision', 'idempotency_key', 'operation', 'reason_code', 'evidence_reference'}:
                _fail('INVALID_INPUT', '独立核对不能同时改写交接内容')
            if item['status'] not in ('duplicate_pending_review', 'existing_customer_pending_review', 'disputed') and item.get('qualification') not in ('duplicate', 'existing_customer'):
                _fail('INVALID_STATE', '此交接没有待审核的归属冲突')
            reason = data.get('reason_code')
            if reason not in ('reviewed_unique', 'not_qualified', 'needs_information'):
                _fail('INVALID_INPUT', '请记录独立核对结果及证据')
            item['review'] = {'actor_id': actor['id'], 'recorded_at': int(time.time()), 'reason_code': reason,
                              'evidence_reference': _reference(data.get('evidence_reference'), '独立核对证据')}
            item['qualification'] = 'qualified' if reason == 'reviewed_unique' else reason
            item['status'] = 'draft' if reason == 'reviewed_unique' else 'needs_information' if reason == 'needs_information' else 'rejected'
            item['attribution_status'] = 'unconfirmed'
            item['delivery_status'] = 'not_submitted'
            return
        if operation in ('withdraw', 'dispute'):
            if set(data) - {'id', 'expected_revision', 'idempotency_key', 'operation', 'reason_code', 'evidence_reference'}:
                _fail('INVALID_INPUT', '撤回或争议不能同时改写交接内容')
            if item['status'] == 'withdrawn':
                _fail('INVALID_STATE', '交接已撤回，请核对原记录')
            reason = data.get('reason_code')
            if reason not in ('customer_withdrew', 'incorrect_information', 'duplicate', 'existing_customer', 'ownership_conflict'):
                _fail('INVALID_INPUT', '请明确撤回或争议原因')
            if operation == 'dispute':
                item['status'] = 'disputed'
                item['attribution_status'] = 'disputed'
                item['dispute'] = {'reason_code': reason, 'evidence_reference': _reference(data.get('evidence_reference'), '争议证据')}
            else:
                if reason == 'customer_withdrew':
                    self._withdraw_consent(db, item, actor)
                    item['consent']['status'] = 'withdrawn'
                item['status'] = 'withdrawn'
                item['attribution_status'] = 'withdrawn_pending_review'
                item['withdrawal_reason'] = reason
            return
        if operation != 'edit' or item['status'] not in ('draft', 'needs_information', 'rejected'):
            _fail('INVALID_STATE', '提交后的交接不能直接改写，请撤回或登记争议')
        changed_fields = {'recipient_id', 'purpose', 'consent', 'contact_reference'} & set(data)
        if changed_fields:
            lead = self._source_lead(db, item, actor)
            consent = {key: item['consent'][key] for key in ('status', 'evidence_reference', 'notice_version')}
            merged = {key: data.get(key, item.get(key)) for key in ('recipient_id', 'purpose', 'contact_reference')}
            merged['consent'] = data.get('consent', consent)
            item.update(self._fields(db, merged, lead))
        if 'qualification' in data:
            value = data['qualification']
            if value not in ('unreviewed', 'qualified', 'needs_information', 'duplicate', 'existing_customer'):
                _fail('INVALID_INPUT', '线索核验状态无效')
            if item.get('qualification') in ('duplicate', 'existing_customer') and value == 'qualified' and not self._manager(actor):
                _fail('MANAGER_REQUIRED', '重复或既有客户需有权审核人复核，不能自行解除')
            item['qualification'] = value
            if value in ('duplicate', 'existing_customer'):
                item['qualification_evidence'] = _reference(data.get('evidence_reference'), '去重核对证据')
                item['attribution_status'] = value + '_pending_review'
        item['status'] = 'draft'

    def _withdraw_consent(self, db, item, actor):
        """Revoke protected values and index withdrawn consent in this transaction."""
        stamp = time.time()
        withdrawal = {'id': uuid4().hex, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
            'lead_id': item['lead_id'], 'recipient_id': item['recipient_id'], 'purpose': item['purpose'],
            'consent_reference': item['consent']['evidence_reference'], 'actor': actor['username'],
            'occurred_at': stamp}
        self._put(db, 'acquisition_consent_withdrawals', withdrawal, new=True)
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                          ('acquisition_contacts', self.tenant)).fetchall()
        for row in rows:
            contact = json.loads(row['body'])
            consent = contact.get('consent')
            if (contact.get('tenant_id') != self.tenant or contact.get('cloud_owner') != self.owner or
                    contact.get('lead_id') != item['lead_id'] or contact.get('recipient_id') != item['recipient_id'] or
                    contact.get('purpose') != item['purpose'] or contact.get('revoked_at') or
                    not isinstance(consent, dict) or consent.get('evidence_reference') != item['consent']['evidence_reference'] or
                    consent.get('notice_version') != item['consent']['notice_version']):
                continue
            if type(contact.get('revision')) is not int or contact['revision'] < 1:
                _fail('CONTACT_INVALID', '联系方式撤回版本需核对，交接尚未修改')
            contact.update(revision=contact['revision'] + 1, revoked_at=stamp,
                           consent={**consent, 'status': 'withdrawn'}, encrypted_payload='')
            self._put(db, 'acquisition_contacts', contact)
            event = {'id': uuid4().hex, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                'contact_id': contact['id'], 'lead_id': contact['lead_id'], 'actor': actor['username'],
                'kind': 'revoked', 'reason_code': 'customer_withdrew', 'source_handoff_id': item['id'],
                'occurred_at': stamp, 'revision': contact['revision']}
            self._put(db, 'acquisition_contact_events', event, new=True)

    def _submit(self, db, item, actor):
        if item['status'] != 'draft' or item['qualification'] != 'qualified':
            _fail('QUALIFICATION_REQUIRED', '请先核实线索有效性；重复、既有客户与缺资料不能直接提交')
        if item['consent'].get('status') != 'granted':
            _fail('CONSENT_REQUIRED', '客户同意已撤回，未提交交接')
        self._require_current_authorization(db, item)
        lead = self._lead(db, item['lead_id'], actor)
        self._contact(db, item['contact_reference'], lead, item['recipient_id'], item['purpose'], item['consent'])
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (HANDOFFS, self.tenant)).fetchall()
        for row in rows:
            other = json.loads(row['body'])
            if (other['id'] != item['id'] and other.get('company_id') == self.company['id'] and
                    other.get('customer_key') == item['customer_key'] and
                    other.get('status') in ('ready_to_deliver', 'accepted', 'disputed')):
                _fail('DUPLICATE_REVIEW', '同企业已有此客户的交接，请先核对重复及归属')
        item['status'] = 'ready_to_deliver'
        item['delivery_status'] = 'local_only'
        item['submitted_at'] = int(time.time())

    def _receipt(self, db, item, data, actor):
        if item['status'] != 'ready_to_deliver':
            _fail('INVALID_STATE', '此交接不在等待接收状态，请先读取最新版本')
        decision = data.get('decision')
        states = {'accept': 'accepted', 'reject': 'rejected', 'needs_information': 'needs_information',
                  'duplicate': 'duplicate_pending_review', 'existing_customer': 'existing_customer_pending_review'}
        if decision not in states:
            _fail('INVALID_INPUT', '接收决定无效')
        self._require_current_authorization(db, item)
        evidence = _reference(data.get('evidence_reference'), '资源部接收或拒收证据')
        if decision == 'accept':
            lead = self._source_lead(db, item, actor)
            if item['consent'].get('status') != 'granted':
                _fail('CONSENT_REQUIRED', '客户授权已失效，不能确认接收')
            self._contact(db, item['contact_reference'], lead, item['recipient_id'], item['purpose'], item['consent'], source_owner=item['cloud_owner'])
        else:
            reasons = {'reject': ('not_qualified', 'outside_service_area'), 'needs_information': ('needs_information',),
                       'duplicate': ('duplicate',), 'existing_customer': ('existing_customer',)}
            if data.get('reason_code') not in reasons[decision]:
                _fail('INVALID_INPUT', '拒收或待补资料必须有明确原因与证据')
        item['status'] = states[decision]
        item['delivery_status'] = 'acknowledged_locally'
        item['receipt'] = {'decision': decision, 'actor_id': actor['id'], 'actor': actor['username'],
            'recipient_id': item['recipient_id'], 'recorded_at': int(time.time()), 'verified': True,
            'source': 'authorized_local_principal', 'evidence_reference': evidence,
            'reason_code': data.get('reason_code') if decision != 'accept' else None}
        if decision in ('duplicate', 'existing_customer'):
            item['attribution_status'] = states[decision]

    def _read(self, db, action, data, actor):
        if action == 'handoff_detail':
            item = self._item(db, _ident(data.get('id'), '交接编号'), actor)
            events = self._events(db, item)
            return self._result(db, item, actor, history_events=events, events=events)
        event_index = self._event_index(db)
        items = self._all(db, actor, event_index=event_index)
        withdrawal_index = self._withdrawal_index(db)
        projections = {item['id']: self._public(db, item, actor, withdrawal_index=withdrawal_index,
                                              history_events=event_index.get(item['id'], [])) for item in items}
        counts = {status: sum(item['status'] == status for item in items) for status in STATUS_TEXT}
        counts.update(accepted_current_authorized=sum(item['status'] == 'accepted' and projections[item['id']]['current_consent_valid'] for item in items),
                      accepted_historical=sum(projection['historical_resource_receipt_verified'] for projection in projections.values()),
                      authorization_withdrawn=sum(projection['current_authorization']['state'] == 'withdrawn' for projection in projections.values()),
                      authorization_unavailable=sum(projection['current_authorization']['state'] == 'unavailable' for projection in projections.values()))
        common = {'counts': counts, 'total': len(items), 'local_only': True, 'cross_machine_verified': False,
                  'recipients': self._recipients(), 'permissions': self._permissions(actor),
                  'policy_status': 'candidate', 'message': '本机交接记录；未接入跨电脑业务同步与真实结算'}
        if action == 'acquisition_overview':
            people, high, comments = set(), set(), 0
            pending_contact = awaiting_response = responded = unverified_contacts = 0
            if actor['username'] == self.owner:
                history = CustomerHistory(self.core, self.tenant, self.owner, lead_access=self.lead_access)
                records = history._build(actor)
                for identity, person in records.items():
                    comments += person['comment_count']
                    people.add(identity)
                    qualified_intent = history._top_level(person) in ('high', 'super_high')
                    if qualified_intent:
                        high.add(identity)
                    state = person['contact_state']
                    observed = person['incoming_reply_status'] == 'observed'
                    # A UID's earlier sent record must not hide another reply's
                    # unresolved outcome. Keep current sending/unknown rows held
                    # until their own recorded terminal result also agrees.
                    uncertain = person['uncertain_contact'] or any(
                        reply.get('status') in ('sending', 'unknown')
                        for comment in person['comments'] for reply in comment['reply_history'])
                    pending_contact += int(qualified_intent and state == 'uncontacted' and not uncertain)
                    awaiting_response += int(state == 'sent' and not observed and not uncertain)
                    responded += int(observed)
                    unverified_contacts += int(uncertain or state in ('unknown', 'legacy_sent_unverified', 'external_reported', 'copied'))
            return {**common, 'counts': {**counts, 'comments': comments, 'customers': len(people),
                    'high_intent_customers': len(high), 'pending_contact': pending_contact,
                    'awaiting_response': awaiting_response, 'responded': responded,
                    'unverified_contacts': unverified_contacts},
                    'source': 'local_existing_customer_history_and_handoffs',
                    'pending_contact_scope': 'high_or_super_high_without_recorded_contact_or_uncertainty',
                    'response_scope': 'existing_local_evidence;unobserved_does_not_mean_no_reply',
                    'recent': [{'id': item['id'], 'label': projections[item['id']]['status_text'], 'at': item['updated_at']} for item in items[:12]],
                    'limitations': ['待联系仅计高/超高意向且无已记录联系或未知发送的客户。',
                                    '待回应表示已有发送记录但本机尚无回应证据，不代表平台上确实未回信。',
                                    '交接是本机运营记录；未接入跨电脑送达及公司订单/结算系统。'],
                    'revenue_verified': False, 'revenue_cents': None, 'settlement_cents': None}
        status = data.get('status', 'all')
        if status != 'all' and status not in STATUS_TEXT:
            _fail('INVALID_INPUT', '交接筛选状态无效')
        if action == 'attribution_case_list':
            items = [item for item in items if item.get('attribution_status') != 'unconfirmed']
        else:
            if 'customer_lead_id' in data:
                selected_lead_id = _ident(data['customer_lead_id'], '当前客户线索编号')
                if (actor['username'] != self.owner and not self._manager(actor) and
                        not any(item['cloud_owner'] == self.owner and item['lead_id'] == selected_lead_id
                                for item in items)):
                    _fail('NOT_FOUND', '当前客户线索不存在或无权访问')
                lead = self._lead(db, selected_lead_id, actor)
                platform, uid = lead.get('platform'), lead.get('author_id')
                same_identity = (isinstance(platform, str) and _ID.fullmatch(platform) and
                                 isinstance(uid, str) and _ID.fullmatch(uid))
                # The current accessible lead supplies identity; request fields
                # cannot select another employee, platform or author scope.
                items = [item for item in items if item['lead_id'] == lead['id'] or
                         (same_identity and projections[item['id']]['source'].get('platform') == platform and
                          projections[item['id']]['source'].get('author_id') == uid)]
            if status != 'all':
                items = [item for item in items if item['status'] == status]
        offset, limit = data.get('offset', 0), data.get('limit', 50)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 100:
            _fail('INVALID_INPUT', '交接分页参数无效')
        result = {**common, 'total': len(items), 'items': [projections[item['id']] for item in items[offset:offset + limit]]}
        if action == 'handoff_list' and 'customer_lead_id' in data:
            result['customer_scope_lead_id'] = lead['id']
        return result
