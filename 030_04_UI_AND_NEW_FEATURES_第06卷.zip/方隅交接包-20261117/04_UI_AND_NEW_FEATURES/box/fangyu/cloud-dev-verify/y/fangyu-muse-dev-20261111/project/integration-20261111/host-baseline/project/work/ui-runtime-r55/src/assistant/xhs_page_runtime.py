"""Opt-in, account-bound lifecycle for the owned Xiaohongshu page helper.

This module is only attached by the source QA launch flag. It deliberately
holds the original account lock on the batch owner thread until confirmed
Job shutdown. The production Native factory remains unavailable by default.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit
from uuid import uuid4

from core.account_safety import summarize_activity
from core.adapters import AdapterAuthRequired, AdapterSafetyRequired, PageUnavailable
from core.page_errors import PAGE_ERROR_MESSAGES
from xhs_page_transport import PageTransportError, XhsPageTransport
from .xhs_batch_scope import collection_scope, first_search_scope


_KINDS = {'status': 'status', 'search': 'search', 'comments': 'comments',
          'sub_comments': 'sub-comments'}
_SOURCES = {'pc_search', 'pc_note', 'pc_user', 'pc_feed'}
_ERROR_MESSAGES = {
    'verification_required': '本次采集请求被拒绝，账号需核对；已保留断点',
    'identity_mismatch': '页面登录身份与已绑定账号不一致，已停止采集',
    'not_authenticated': '小红书页面登录已失效，请核对账号',
    'helper_alive': '采集窗口尚未退出，账号窗口暂不能切换',
    'invalid_result': '页面返回结构无效，已停止采集',
    'platform_rejected': '平台拒绝本次页面请求，已保留断点',
    'page_rejected': '页面请求未完成，已保留断点',
    'timeout': '页面请求超时，结果需核实，已停止采集',
    'document_changed': '采集页面已跳转，身份需要重新核对',
}


def _safe_text(value, limit=2048):
    return isinstance(value, str) and 0 < len(value) <= limit and not any(ord(c) < 32 or ord(c) == 127 for c in value)


def _page_diagnostic(raw):
    """Persist only fixed process facts, never helper text or platform content."""
    if not isinstance(raw, dict) or raw.get('stage') not in ('connect', 'call'):
        return None
    result = {'stage': raw['stage']}
    for key in ('return_code', 'doc_epoch', 'task_epoch'):
        value = raw.get(key)
        if type(value) is int and -(2**31) <= value <= 2**53 - 1:
            result[key] = value
    if type(raw.get('failure_received')) is bool:
        result['failure_received'] = raw['failure_received']
    code = raw.get('failure_code')
    if type(code) is str and code in (set(PAGE_ERROR_MESSAGES) | {'', 'not_authenticated',
            'identity_mismatch', 'verification_required'}):
        result['failure_code'] = code
    phase = raw.get('phase')
    if type(phase) is str and phase in ('connecting', 'issued', 'navigating', 'observing', 'invalidated'):
        result['phase'] = phase
    return result


def _options(args, start, allowed):
    found = {}
    i = start
    while i < len(args):
        key = args[i]
        if key == '--json' and key in allowed and key not in found:
            found[key] = True; i += 1
        elif key in allowed and key not in found and i + 1 < len(args) and isinstance(args[i+1], str):
            found[key] = args[i+1]; i += 2
        else:
            raise ValueError('页面采集命令参数不符合固定契约')
    if '--json' not in found:
        raise ValueError('页面采集命令缺少 JSON 契约')
    return found


def _request(args, *, natural_mode=False):
    """Parse only the four pre-existing, fixed read command forms."""
    if not isinstance(args, (list, tuple)) or not args or not all(isinstance(x, str) for x in args):
        raise ValueError('页面采集命令无效')
    action = args[0]
    if action == 'status' and list(args) == ['status', '--json']:
        return 'status', {}
    if action == 'search' and len(args) in ((5,7) if natural_mode else (5,)):
        opts = _options(args, 2, {'--json', '--page'} | ({'--range-checkpoint'} if natural_mode else set()))
        if {'--json','--page'}.issubset(opts) and _safe_text(args[1], 100 if natural_mode else 200) and re.fullmatch(r'[1-9]\d{0,8}', opts['--page']):
            params={'keyword':args[1],'page':int(opts['--page'])}
            if '--range-checkpoint' in opts:
                from xhs_natural_search import validate_range
                raw=opts['--range-checkpoint']
                if len(raw)>4_000_000:raise ValueError('搜索断点无效')
                value=json.loads(raw)
                validate_range(value,keyword=args[1])
                params['range_checkpoint']=value
            return 'search',params
    if action == 'comments' and len(args) >= 3:
        opts = _options(args, 2, {'--json', '--cursor'})
        parsed = urlsplit(args[1])
        if (parsed.scheme != 'https' or parsed.hostname not in ('www.xiaohongshu.com', 'xiaohongshu.com')
                or parsed.port not in (None, 443) or parsed.username or parsed.password or parsed.fragment):
            raise ValueError('笔记链接不属于固定小红书域名')
        match = re.fullmatch((r'/(?:explore|search_result)/([0-9a-f]{24})/?' if natural_mode
                             else r'/explore/([A-Za-z0-9]{1,128})/?'), parsed.path)
        query = parse_qsl(parsed.query, keep_blank_values=True, strict_parsing=True)
        if not match or (not natural_mode and (len(query) != 2 or
                {key for key, _ in query} != {'xsec_token', 'xsec_source'})):
            raise ValueError('笔记链接缺少可信来源参数')
        values = dict(query)
        if natural_mode and (len(args[1]) > 8192 or len(query) > 16 or len(values) != len(query)
                or any(len(k) > 64 or len(v) > 2048 for k,v in query)
                or parsed.hostname != 'www.xiaohongshu.com'):
            raise ValueError('笔记来源参数无效')
        source = values.get('xsec_source', '')
        if not _safe_text(values.get('xsec_token')) or source not in (_SOURCES | {''} if natural_mode else _SOURCES):
            raise ValueError('笔记来源参数无效')
        cursor = opts.get('--cursor', '')
        if not isinstance(cursor, str) or len(cursor) > 512 or any(ord(c) < 32 or ord(c) == 127 for c in cursor):
            raise ValueError('评论游标无效')
        params = {'note_id': match.group(1), 'cursor': cursor,
                  'source_token': values['xsec_token'], 'xsec_source': source}
        if natural_mode: params['note_url'] = args[1]
        return 'comments', params
    if action == 'sub-comments' and len(args) >= 4:
        opts = _options(args, 3, {'--json', '--cursor', '--xsec-token', '--xsec-source'} |
                        ({'--note-url'} if natural_mode else set()))
        cursor = opts.get('--cursor', '')
        if (not re.fullmatch(r'[A-Za-z0-9]{1,128}', args[1]) or
                not re.fullmatch(r'[A-Za-z0-9]{1,128}', args[2]) or
                not _safe_text(opts.get('--xsec-token')) or opts.get('--xsec-source', '') not in
                (_SOURCES | {''} if natural_mode else _SOURCES) or
                len(cursor) > 512 or any(ord(c) < 32 or ord(c) == 127 for c in cursor)):
            raise ValueError('楼中楼页面参数无效')
        params = {'note_id': args[1], 'root_comment_id': args[2], 'cursor': cursor,
                  'source_token': opts['--xsec-token'], 'xsec_source': opts.get('--xsec-source', '')}
        if natural_mode:
            _, checked = _request(['comments', opts.get('--note-url',''), '--json'], natural_mode=True)
            if checked['note_id'] != args[1] or checked['source_token'] != params['source_token'] or checked['xsec_source'] != params['xsec_source']:
                raise ValueError('楼中楼笔记来源不一致')
            params['note_url'] = checked['note_url']
        return 'sub_comments', params
    raise ValueError('此页面采集路线只允许固定只读命令')


def _data(envelope, action, bound_uid, *, natural_mode=False):
    """Accept the bridge's three documented axios/API/raw envelope shapes."""
    if action == 'search' and isinstance(envelope,dict) and envelope.get('_transport') == 'natural_dom':
        if not natural_mode:raise PageTransportError('invalid_result')
        try:
            from xhs_natural_search import validate_result
            validate_result(envelope)
        except (ValueError,TypeError):raise PageTransportError('invalid_result') from None
        return envelope
    payload = envelope
    for _ in range(4):
        if not isinstance(payload, dict):
            raise PageTransportError('invalid_result')
        if ('status' in payload and payload['status'] != 200 or
                'code' in payload and payload['code'] != 0 or
                payload.get('success') is False or payload.get('_page_error') is not None):
            raise PageTransportError('platform_rejected')
        if action == 'status':
            candidates = [payload]
            for key in ('user', 'user_info', 'basic_info'):
                if isinstance(payload.get(key), dict): candidates.append(payload[key])
            uids = {user['user_id'] for user in candidates if _safe_text(user.get('user_id'), 256)}
            if uids:
                if uids != {bound_uid}:
                    raise PageTransportError('identity_mismatch')
                if any(user.get('guest') is True or user.get('is_guest') is True for user in candidates):
                    raise PageTransportError('invalid_result')
                nickname = next((name for user in candidates
                    for name in (user.get('nickname'), user.get('nick_name')) if _safe_text(name, 256)), '')
                if not nickname:
                    raise PageTransportError('invalid_result')
                profile = {'id': next(iter(uids)), 'nickname': nickname, 'guest': False}
                for key in ('avatar', 'image', 'avatar_url'):
                    image = next((user[key] for user in candidates if isinstance(user.get(key), str)), None)
                    if image is not None: profile[key] = image
                return {'data': {'authenticated': True, 'user': profile}}
        else:
            key = 'items' if action == 'search' else 'comments'
            if key in payload:
                if not isinstance(payload[key], list) or not isinstance(payload.get('has_more'), bool):
                    raise PageTransportError('invalid_result')
                if action in ('comments', 'sub_comments') and not isinstance(payload.get('cursor', ''), str):
                    raise PageTransportError('invalid_result')
                return {'data': payload}
        payload = payload.get('data')
    raise PageTransportError('invalid_result')


class _Entry:
    def __init__(self):
        self.lock = threading.RLock()
        self.transport = None
        self.bound_uid = ''
        self.login_reserved = False
        self.verification_hold = False
        self.stop_requested = False
        self.batch_scope = None
        self.lifecycle_wake = threading.Event()


class XhsPageRuntime:
    def __init__(self, core, helper_factory, *, transport_factory=XhsPageTransport, clock=time.time, sleeper=time.sleep,
                 natural_mode=False, owned_helper_factory=None, app_context_factory=None):
        if type(natural_mode) is not bool:
            raise ValueError('invalid_read_mode')
        self.natural_mode = natural_mode
        self.core = core
        self.helper_factory = helper_factory
        self.owned_helper_factory = owned_helper_factory
        self.app_context_factory = app_context_factory
        self.transport_factory = transport_factory
        self.clock = clock
        self.sleeper = sleeper
        self.lock = threading.Lock()
        self.entries = {}
        self.jobs = {}
        self.closed = False

    def collection_scope(self,user,task,execution_guard=None):
        return collection_scope(self,user,task,execution_guard)

    def first_search_scope(self,user,task,execution_guard=None):
        return first_search_scope(self,user,task,execution_guard)

    def has_pending_batch(self,task_id):
        with self.lock:
            scope=self.jobs.get(task_id)
            return scope is not None and scope.task_id==task_id

    def _entry(self, account_dir):
        lexical = Path(account_dir).absolute()
        root = lexical.resolve()
        base = (self.core.store.directory / 'accounts').resolve()
        if (os.path.normcase(str(lexical)) != os.path.normcase(str(root)) or
                not root.is_relative_to(base) or len(root.relative_to(base).parts) != 2 or
                any(part.is_symlink() or (hasattr(part, 'is_junction') and part.is_junction())
                    for part in (lexical, *lexical.parents))):
            raise AdapterSafetyRequired('页面采集账号目录无效')
        with self.lock:
            return root, self.entries.setdefault(root, _Entry())

    def _account(self, root):
        tenant, account_id = root.relative_to((self.core.store.directory / 'accounts').resolve()).parts
        account = self.core.store.get('accounts', account_id)
        if (not isinstance(account, dict) or account.get('tenant_id') != tenant or
                account.get('platform') != 'xiaohongshu' or account.get('id') != account_id or
                account.get('status') != 'ready' or account.get('requires_review') is True):
            raise AdapterSafetyRequired('当前小红书账号未满足页面采集前提')
        uid = account.get('platform_uid')
        if not _safe_text(uid, 256):
            raise AdapterSafetyRequired('小红书账号缺少已核对的身份标识')
        self.core._platform_execution_guard('xiaohongshu')
        self.core.adapters.require_account_safe('xiaohongshu', root)
        return tenant, account_id, uid

    @staticmethod
    def _append(path, event):
        payload = (json.dumps(event, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')
        handle = os.open(path, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try:
            if os.write(handle, payload) != len(payload):
                raise OSError('平台活动记录写入不完整')
            os.fsync(handle)
        finally:
            os.close(handle)

    def _last_finished(self, path):
        if not path.exists():
            return 0.0
        latest = 0.0
        with path.open('r', encoding='utf-8') as stream:
            for line in stream:
                try: event = json.loads(line)
                except ValueError: continue
                if isinstance(event, dict) and event.get('stage') in ('finished', 'cli_finished'):
                    at = event.get('at')
                    if type(at) in (float, int): latest = max(latest, float(at))
        return latest

    def _guard(self, root, event, context):
        action = context.get('action')
        call_id = context.get('call_id')
        if action not in _KINDS or not _safe_text(call_id, 100):
            return False
        with self.lock:
            entry=self.entries.get(root)
            scope=entry.batch_scope if entry is not None else None
        if scope is None:return False
        scope.check()
        path = root / 'platform-activity.jsonl'
        if event == 'before_open':
            self._account(root)
            return True
        if event == 'before_call':
            self._account(root)
            delay = 1.0 - (self.clock() - self._last_finished(path))
            if delay > 0:
                self.sleeper(delay)
                self._account(root)
            self._append(path, {'at': self.clock(), 'request_id': call_id, 'stage': 'started',
                                'kind': _KINDS[action],
                                'method': 'BROWSER' if self.natural_mode else 'POST' if action == 'search' else 'GET'})
            return True
        if event == 'after_result':
            outcome = context.get('outcome')
            attempted = context.get('network_attempted') is True
            status = 200 if outcome == 'ok' else 461 if outcome == 'verification_required' else 401 if outcome == 'not_authenticated' else (
                'cancelled_before_send' if not attempted else
                'protocol_error' if outcome in ('invalid_result', 'identity_mismatch', 'document_changed') else
                'api_error' if outcome in ('platform_rejected', 'page_rejected', 'axios_rejected') else
                'transport_error')
            if self.natural_mode and outcome == 'ok':
                # This describes a logical browser read, not a fabricated HTTP
                # response from a fixed API endpoint. Request bodies stay native.
                status = 'page_read_complete'
            record = {'at': self.clock(), 'request_id': call_id, 'stage': 'finished',
                      'kind': _KINDS[action], 'status': status, 'elapsed_ms': 0}
            diagnostic = _page_diagnostic(context.get('diagnostic'))
            if (self.natural_mode and outcome == 'search_scroll_unavailable' and
                    diagnostic and diagnostic.get('failure_received') is True and
                    diagnostic.get('failure_code') == 'search_scroll_unavailable'):
                record['status'] = 'page_local_error'
            if self.natural_mode and outcome != 'ok' and diagnostic is not None:
                record['page_diagnostic'] = diagnostic
            self._append(path, record)
            # A new phone signal while the request ran invalidates its result.
            if outcome == 'ok' and summarize_activity(path)['state'] == 'review_required':
                return False
            return True
        return False

    def execute(self, account_dir, args, job_id=None):
        try: action, params = _request(args, natural_mode=self.natural_mode)
        except (ValueError, TypeError): raise PageUnavailable('invalid_request') from None
        if self.owned_helper_factory is None:
            raise AdapterSafetyRequired('页面 Native 生命周期尚待本机许可与运行来源核对')
        root, entry = self._entry(account_dir)
        with self.lock:scope=entry.batch_scope
        if scope is None:raise AdapterSafetyRequired('页面 Native 接线尚无原认证批次范围')
        scope.check()
        with entry.lock:
            with self.lock:
                if self.closed or entry.login_reserved or entry.stop_requested:
                    raise AdapterSafetyRequired('账号浏览器正在切换，页面采集暂不可用')
            tenant, account_id, uid = self._account(root)
            if entry.transport and entry.bound_uid != uid:
                self._close_locked(entry)
            if entry.transport and entry.verification_hold:
                # Only an explicit later call after the existing account review
                # gate cleared may end the visible verification page.
                self._close_locked(entry)
                entry.verification_hold = False
            if job_id and job_id != scope.task_id:
                raise AdapterSafetyRequired('页面请求必须使用原批次任务编号')
            try:
                if entry.transport is None:
                    with self.lock:
                        if self.closed or entry.login_reserved or entry.stop_requested:
                            raise AdapterSafetyRequired('账号浏览器正在切换，页面采集暂不可用')
                        def scoped_factory(spec_path):
                            scope.check()
                            if spec_path.parent.parent.parent.parent.resolve()!=root:
                                raise AdapterSafetyRequired('私有spec不属于原账号')
                            # Legacy one-argument Popen factory fails before spawn.
                            # No device/runtime/license approval is manufactured here.
                            return self.owned_helper_factory(spec_path,owned_scope=scope)
                        entry.transport = self.transport_factory(root, tenant, account_id, uid,
                            lambda event, context: self._guard(root, event, context), scoped_factory,
                            **({'natural_mode': True} if self.natural_mode else {}))
                        entry.bound_uid = uid
                    with self.lock:
                        if self.closed or entry.login_reserved or entry.stop_requested:
                            raise AdapterSafetyRequired('页面采集已取消')
                    first = entry.transport.open()
                    if action == 'status':
                        return _data(first, 'status', uid, natural_mode=self.natural_mode)
                with self.lock:
                    if self.closed or entry.login_reserved or entry.stop_requested:
                        raise AdapterSafetyRequired('账号浏览器正在切换，页面采集暂不可用')
                envelope = entry.transport.call(action, call_id=uuid4().hex, **params)
                return _data(envelope, action, uid, natural_mode=self.natural_mode)
            except PageTransportError as exc:
                diagnostic = _page_diagnostic(getattr(entry.transport, 'last_failure_diagnostic', None))
                if self.natural_mode and diagnostic and diagnostic['stage'] == 'connect':
                    # Connection exits happen before before_call/after_result;
                    # retain them once without inventing a platform request.
                    self._append(root / 'platform-activity.jsonl', {
                        'at': self.clock(), 'request_id': uuid4().hex, 'stage': 'finished',
                        'kind': 'status', 'status': 'cancelled_before_send', 'elapsed_ms': 0,
                        'page_diagnostic': diagnostic})
                if exc.code == 'verification_required':
                    entry.verification_hold = True
                else:
                    try: self._close_locked(entry)
                    except PageTransportError: pass
                if exc.code == 'not_authenticated':
                    raise AdapterAuthRequired(_ERROR_MESSAGES[exc.code]) from None
                if exc.code in ('verification_required', 'identity_mismatch'):
                    raise AdapterSafetyRequired(_ERROR_MESSAGES[exc.code]) from None
                raise PageUnavailable(exc.code) from None

    def _close_locked(self, entry):
        if entry.transport is None:
            return
        if not getattr(entry.transport, 'opened', True) and getattr(entry.transport,'process',None) is None:
            # A cancellation can race with construction before any process or
            # profile is opened; there is then nothing external to release.
            entry.transport = None
            entry.bound_uid = ''
            return
        entry.transport.close()
        entry.transport = None
        entry.bound_uid = ''

    def close_account(self, account_dir, *, expected_scope=None):
        _root, entry = self._entry(account_dir)
        with self.lock:
            if expected_scope is not None and entry.batch_scope is not expected_scope:
                return 'scope_changed'
            entry.stop_requested = True
            transport = entry.transport
            scope = entry.batch_scope
            if scope is not None:
                scope.user_cancelled = True
        if transport is not None:
            transport.request_stop()
        if scope is not None:
            entry.lifecycle_wake.set()
            return 'requested'
        with entry.lock:
            self._close_locked(entry)
            with self.lock:
                entry.stop_requested = False

    def begin_login(self, account_dir):
        """Reserve the browser profile until the old login worker really exits."""
        _root, entry = self._entry(account_dir)
        with self.lock:
            if entry.batch_scope is not None:
                raise AdapterSafetyRequired('原采集窗口尚未确认关闭，暂不能打开登录')
            if entry.login_reserved == 'login':
                raise AdapterSafetyRequired('该账号登录窗口尚未退出')
            entry.login_reserved = 'closing'
            transport = entry.transport
        if transport is not None:
            transport.request_stop()
        with entry.lock:
            with self.lock:
                if entry.login_reserved == 'login':
                    raise AdapterSafetyRequired('该账号登录窗口尚未退出')
            try:
                self._close_locked(entry)
            except Exception:
                # Keep reservation: a live helper may still own the profile.
                raise
            with self.lock:
                entry.login_reserved = 'login'
        return entry

    def finish_login(self, account_dir, reservation):
        _root, entry = self._entry(account_dir)
        with entry.lock:
            if entry is reservation:
                entry.login_reserved = False

    def cancel(self, job_id):
        with self.lock:
            scope = self.jobs.get(job_id)
            if scope is None or scope.task_id != job_id:
                return False
            if scope.finished and not scope.result_released:
                # Stop only this pending logical result, never a later Job.
                scope.user_cancelled = True
                return True
            entry = self.entries.get(scope.root)
            if entry is None or entry.batch_scope is not scope:
                return False
        # A late old task cancellation cannot stop a new scope on this profile.
        return self.close_account(scope.root, expected_scope=scope) == 'requested'

    def abort_active(self):
        with self.lock: roots = list(self.entries)
        for root in roots: self.close_account(root)
        return len(roots)

    def abort_account(self, account_dir):
        self.close_account(account_dir)
        return 1

    def close(self):
        self.closed = True
        return self.abort_active()
