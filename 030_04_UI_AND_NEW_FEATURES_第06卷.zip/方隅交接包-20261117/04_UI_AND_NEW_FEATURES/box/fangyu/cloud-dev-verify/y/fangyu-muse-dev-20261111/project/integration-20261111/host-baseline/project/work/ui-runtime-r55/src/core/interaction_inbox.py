"""Local views and reversible dispositions over existing immutable XHS events.

No platform transport, model, customer creation or original-event write exists
here. State and immutable request receipts commit in one original Store txn.
"""
from copy import deepcopy
from datetime import datetime,timezone
import hashlib,json,re
from urllib.parse import urlsplit

EVENTS='acquisition_interaction_events_v1'
STATES='interaction_inbox_states_v1'
RECEIPTS='interaction_inbox_receipts_v1'
ACTIONS=frozenset(('interaction_inbox_read','interaction_inbox_state_save','interaction_inbox_request_read'))
BASE={'storeId','accountId','platform'}
TYPES={'mentions':'评论和提及','likes':'点赞和收藏','connections':'新增关注'}
STATES_LABEL={'new':'待查看','follow_up':'待跟进','viewed':'已查看','ignored':'已忽略'}
ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
REQUEST=re.compile(r'[A-Za-z0-9_-]{16,80}\Z')
HASH=re.compile(r'[a-f0-9]{64}\Z')

class InboxError(ValueError):
    def __init__(self,code,message,status=400):
        super().__init__(message);self.code,self.status=code,status

def fail(code,message,status=400):raise InboxError(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def ident(value):
    if not isinstance(value,str) or not ID.fullmatch(value):fail('INTERACTION_INPUT_INVALID','请选择有效的账号或互动记录')
    return value
def read(db,entity,key,tenant):
    row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,key,tenant)).fetchone()
    return json.loads(row['body']) if row else None
def put(db,entity,row,replace=False):
    db.execute(('INSERT OR REPLACE' if replace else 'INSERT')+' INTO records VALUES(?,?,?,?)',
        (entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))

def public_note(raw):
    for name in ('note_info','note','item_info'):
        item=raw.get(name)
        if not isinstance(item,dict):continue
        found=item.get('note_id') or item.get('id')
        value=item.get('note_url') or item.get('url')
        if isinstance(value,str) and len(value)<=2048:
            try:
                url=urlsplit(value);match=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]+)/?',url.path)
                if (url.scheme=='https' and url.hostname in ('xiaohongshu.com','www.xiaohongshu.com')
                    and url.port in (None,443) and not url.username and not url.password and not url.fragment and match):
                    if found and found!=match[1]:return ''
                    found=match[1]
            except ValueError:return ''
        if isinstance(found,str) and re.fullmatch(r'[A-Za-z0-9]{1,128}',found):
            return 'https://www.xiaohongshu.com/explore/'+found
    return ''

def original(event):
    raw=event.get('raw') if isinstance(event.get('raw'),dict) else {}
    url=public_note(raw)
    if event.get('type')!='mentions':
        return '',None,url,'interaction_no_comment','这条通知是点赞、收藏或关注，没有评论正文；软件不会据此补写需求。'
    item=raw.get('comment_info',raw.get('comment'))
    if not isinstance(item,dict):return '',None,url,'comment_missing','平台通知没有提供完整评论，当前受控链没有按这条通知补全文的能力；仅保留实际通知。'
    key=item.get('id') or item.get('comment_id')
    text=item.get('content') or item.get('text')
    author=(item.get('user_info') or item.get('user') or {}).get('user_id') if isinstance(item.get('user_info',item.get('user',{})),dict) else None
    if not isinstance(key,str) or not ID.fullmatch(key):return '',None,url,'comment_identity_missing','通知缺少稳定评论编号，不能核对具体原评论。'
    if not isinstance(text,str) or not text.strip() or len(text)>3000 or '\x00' in text:
        return '',None,url,'comment_text_missing','通知没有提供评论正文，不能用笔记摘要或其他人的文字代替。'
    if not author or author!=event.get('author_id') or event.get('text_source')!='explicit_comment' or event.get('text')!=text:
        return '',None,url,'comment_author_unconfirmed','通知作者与评论正文的归属尚不能一致核对。'
    if not url:return '',None,'','comment_source_missing','通知未提供可核对的原帖来源，暂不作为客户需求。'
    return text,key,url,'available','已保留通知作者本人的评论原文；是否符合租房需求仍按原分析结果判断。'

class InteractionInbox:
    def __init__(self,core):self.core,self.store=core,core.store

    def _authorized(self,db,user,store_id,account_id,authority,save):
        saved=read(db,'users',user.get('id'),user.get('tenant_id')) or {}
        if (saved.get('disabled') or saved.get('cloud_bound') is not True
            or saved.get('role') not in ('operator','admin')
            or any(saved.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))):
            fail('INTERACTION_FORBIDDEN','当前员工身份已变化，请重新读取互动记录',403)
        account=read(db,'accounts',account_id,user['tenant_id']) or {}
        if (account.get('cloud_owner')!=saved['username'] or account.get('store_id')!=store_id
            or account.get('platform')!='xiaohongshu' or not isinstance(account.get('platform_uid'),str) or not account['platform_uid']):
            fail('INTERACTION_ACCOUNT_CHANGED','账号不属于当前员工或门店，或原账号身份尚未核对',403)
        self.core._account_access(saved,account)
        scope=dict(tenant_id=user['tenant_id'],owner=user['username'],user_id=user['id'],
            store_id=store_id,account_id=account_id,platform='xiaohongshu',platform_uid=account['platform_uid'])
        if not callable(authority) or authority(db,saved,scope,save) is not True:
            fail('INTERACTION_FORBIDDEN','当前会话或门店权限已变化，请保留原操作核对',403)
        return scope,account

    def _events(self,db,scope,event_id=None):
        # Filter tenant/employee/store/account/UID and original task/page before
        # decoding. No full tenant scan or customer-per-event history scan.
        sql="""SELECT e.body FROM records e JOIN records t ON t.entity='tasks'
            AND t.id=json_extract(e.body,'$.scope.task_id') AND t.tenant_id=e.tenant_id
            JOIN records p ON p.entity='source_item_evidence_v1'
            AND p.id=json_extract(e.body,'$.page_evidence_id') AND p.tenant_id=e.tenant_id
            WHERE e.entity=? AND e.tenant_id=?
            AND json_extract(e.body,'$.scope.tenant_id')=?
            AND json_extract(e.body,'$.scope.owner')=? AND json_extract(e.body,'$.scope.store_id')=?
            AND json_extract(e.body,'$.scope.account_id')=? AND json_extract(e.body,'$.scope.platform_uid')=?
            AND json_extract(e.body,'$.scope.platform')='xiaohongshu'
            AND json_extract(t.body,'$.cloud_owner')=? AND json_extract(t.body,'$.store_id')=?
            AND json_extract(t.body,'$.account_id')=? AND json_extract(t.body,'$.platform')='xiaohongshu'
            AND json_extract(t.body,'$.source_kind')='own_interactions'
            AND json_extract(p.body,'$.scope')=json_extract(e.body,'$.scope')"""
        args=[EVENTS,scope['tenant_id'],scope['tenant_id'],scope['owner'],scope['store_id'],scope['account_id'],scope['platform_uid'],scope['owner'],scope['store_id'],scope['account_id']]
        if event_id:sql+=' AND e.id=?';args.append(event_id)
        result=[]
        for found in db.execute(sql,args):
            row=json.loads(found['body']);event=row.get('event',{})
            if (not isinstance(event,dict) or event.get('type') not in TYPES or not isinstance(event.get('event_id'),str)
                or row.get('id')!=digest([scope['tenant_id'],scope['owner'],scope['account_id'],'xiaohongshu',event['type'],event['event_id']])):
                fail('INTERACTION_RECORD_INVALID','互动来源记录需要核对，原始内容已保留',409)
            result.append(row)
        if event_id and not result:fail('INTERACTION_NOT_FOUND','互动记录不存在或不在当前账号和门店范围',404)
        return result

    def _states(self,db,scope):
        found=db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=? AND json_extract(body,'$.scopeKey')=?",(STATES,scope['tenant_id'],digest(scope)))
        result={}
        for row in (json.loads(x['body']) for x in found):
            if (row.get('id')!=digest([digest(scope),row.get('eventId')]) or row.get('tenant_id')!=scope['tenant_id']
                or type(row.get('version')) is not int or not 1<=row['version']<=2147483646
                or row.get('state') not in STATES_LABEL or row.get('previousState') not in STATES_LABEL
                or row.get('updatedBy')!=scope['user_id']):
                fail('INTERACTION_RECORD_INVALID','互动处理记录版本需要核对，原数据已保留',409)
            result[row['eventId']]=row
        return result

    def _links(self,db,scope,rows):
        wanted=[key for row in rows for _,key,_,status,_ in [original(row['event'])] if status=='available']
        if not wanted:return {}
        found=db.execute("""SELECT r.body FROM unique_leads u JOIN records r ON r.entity='leads'
            AND r.id=u.lead_id AND r.tenant_id=u.tenant_id LEFT JOIN records t ON t.entity='tasks'
            AND t.id=json_extract(r.body,'$.task_id') AND t.tenant_id=r.tenant_id
            WHERE u.tenant_id=? AND u.platform='xiaohongshu'
            AND u.source_id IN (SELECT 'comment:'||value FROM json_each(?))
            AND COALESCE(NULLIF(json_extract(r.body,'$.cloud_owner'),''),json_extract(t.body,'$.cloud_owner'))=?
            AND COALESCE(NULLIF(json_extract(r.body,'$.store_id'),''),json_extract(t.body,'$.store_id'))=?""",
            (scope['tenant_id'],json.dumps(list(set(wanted))),scope['owner'],scope['store_id']))
        return {v.get('comment_id'):v for v in (json.loads(x['body']) for x in found)}

    def _view(self,row,state,links):
        event=row['event'];body,key,url,status,reason=original(event);source_hash=digest(row)
        if state and (state.get('eventDigest')!=source_hash or state.get('state') not in STATES_LABEL):
            fail('INTERACTION_SOURCE_CHANGED','互动原始来源已变化，处理记录保留，请核对原记录',409)
        lead=links.get(key) or {}
        linked=bool(body and lead.get('text')==body and lead.get('author_id')==event.get('author_id')
            and lead.get('source_id')=='comment:'+key and public_note({'note_info':{'note_url':lead.get('note_url') or lead.get('url')}})==url)
        disposition=(state or {}).get('state','new')
        author=event.get('author')
        if not isinstance(author,str) or not author.strip():author='通知中未提供昵称'
        author=''.join(c for c in author[:160] if ord(c)>=32 and ord(c)!=127)
        customer_key=None
        if linked:
            # Lazy import reuses the original customer identity rule after Core
            # initialization. A platform UID is not the customer page's key.
            from assistant.customer_list import _person
            customer_key=_person(lead)[0]
        return dict(id=row['id'],eventDigest=source_hash,type=event['type'],typeLabel=TYPES[event['type']],
            actorName=author,observedAt=row.get('observed_at',''),sourceUrl=url,
            sourceLabel='小红书本人'+TYPES[event['type']]+'通知',commentText=body,
            originalCommentStatus=status,originalCommentReason=reason,
            baseline=event.get('disposition')=='baseline',hasOriginalComment=bool(body),
            linkedLeadId=lead.get('id') if linked else None,linkedCustomerId=customer_key,
            state=disposition,stateLabel=STATES_LABEL[disposition],version=(state or {}).get('version',0),
            restoreState=(state or {}).get('previousState','new') if disposition=='ignored' else None,
            updatedAt=(state or {}).get('updatedAt'),canEditOriginal=False,canFetchMissing=False)

    def execute(self,action,user,store_id,data,*,authority_check):
        if action not in ACTIONS:fail('INTERACTION_ACTION_INVALID','此互动操作尚未开放')
        optional={'interaction_inbox_read':{'type','state','page','pageSize'},
            'interaction_inbox_state_save':{'eventId','eventDigest','expectedVersion','state','requestId'},
            'interaction_inbox_request_read':{'eventId','requestId'}}[action]
        required=BASE if action=='interaction_inbox_read' else BASE|optional
        if (not isinstance(data,dict) or set(data)-BASE-optional or not required<=set(data)
            or data.get('storeId')!=store_id or data.get('platform')!='xiaohongshu'):
            fail('INTERACTION_INPUT_INVALID','请核对当前门店、账号和互动操作')
        ident(store_id);ident(data['accountId']);save=action=='interaction_inbox_state_save'
        if action!='interaction_inbox_read':
            ident(data['eventId'])
            if not isinstance(data['requestId'],str) or not REQUEST.fullmatch(data['requestId']):fail('INTERACTION_INPUT_INVALID','请保留有效的原操作编号')
        if save and (type(data['expectedVersion']) is not int or data['expectedVersion']<0
            or not isinstance(data['eventDigest'],str) or not HASH.fullmatch(data['eventDigest'])
            or not isinstance(data['state'],str) or data['state'] not in {*STATES_LABEL,'restore'}):fail('INTERACTION_INPUT_INVALID','请核对处理状态、原记录和当前版本')
        try:
            with self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE' if save else 'BEGIN')
                scope,account=self._authorized(db,user,store_id,data['accountId'],authority_check,save)
                rows=self._events(db,scope,data.get('eventId'))
                states=self._states(db,scope);links=self._links(db,scope,rows)
                if action=='interaction_inbox_read':
                    answer=self._list(scope,rows,states,links,data)
                else:
                    row=rows[0];current=self._view(row,states.get(row['id']),links)
                    receipt_id=digest([scope['tenant_id'],scope['owner'],scope['user_id'],data['requestId']])
                    prior=read(db,RECEIPTS,receipt_id,scope['tenant_id'])
                    replayed=prior is not None
                    if prior and (prior.get('scope')!=scope or prior.get('eventId')!=row['id']):
                        fail('INTERACTION_REQUEST_CONFLICT','原操作不属于当前互动范围，请回到原账号核对',409)
                    if save:
                        input_hash=digest(data)
                        if prior and prior['inputDigest']!=input_hash:fail('INTERACTION_REQUEST_CONFLICT','同一操作编号的内容已变化，请核对原操作',409)
                        if not prior:
                            if current['version']!=data['expectedVersion']:fail('INTERACTION_VERSION_CONFLICT','该互动已被另一窗口处理，请保留选择并读取当前状态',409)
                            if current['eventDigest']!=data['eventDigest']:fail('INTERACTION_SOURCE_CHANGED','原互动证据已变化，请读取原记录核对',409)
                            target=data['state'];old=states.get(row['id']) or {}
                            if target=='restore':
                                if current['state']!='ignored':fail('INTERACTION_RESTORE_INVALID','只有已忽略记录可以恢复',409)
                                target=old.get('previousState','new')
                            previous=current['state'] if target=='ignored' and current['state']!='ignored' else old.get('previousState','new')
                            state=dict(id=digest([digest(scope),row['id']]),tenant_id=scope['tenant_id'],scopeKey=digest(scope),
                                eventId=row['id'],eventDigest=current['eventDigest'],version=current['version']+1,
                                state=target,previousState=previous,updatedAt=stamp(),updatedBy=scope['user_id'])
                            item=self._view(row,state,links)
                            prior=dict(id=receipt_id,tenant_id=scope['tenant_id'],scope=scope,eventId=row['id'],
                                requestId=data['requestId'],inputDigest=input_hash,state='accepted',version=state['version'],
                                result=item,createdAt=stamp())
                            put(db,STATES,state,replace=True);put(db,RECEIPTS,prior)
                            current=item
                    # Original receipt is historical. Do not replace a newer state
                    # with an old successful response when recovering an old key.
                    receipt={'requestId':data['requestId'],'state':'accepted' if prior else 'not_found',
                        'eventId':row['id'],'version':prior['version'] if prior else None,
                        'originalResult':deepcopy(prior['result']) if prior else None}
                    answer=dict(item=current,receipt=receipt,replayed=replayed,scopeKey=digest(scope))
                fresh_scope,_=self._authorized(db,user,store_id,data['accountId'],authority_check,save)
                if fresh_scope!=scope:fail('INTERACTION_ACCOUNT_CHANGED','处理期间账号身份已变化，原操作未提交',403)
            return answer
        except InboxError:raise
        except Exception:
            if save:fail('INTERACTION_RESULT_UNCONFIRMED','处理结果暂未确认，请保留原操作编号查询，不要改号重复保存',503)
            fail('INTERACTION_READ_UNCONFIRMED','互动记录暂时无法核对，请保留当前账号稍后查询',503)

    def _list(self,scope,rows,states,links,data):
        kind,state=data.get('type','all'),data.get('state','all')
        page,size=data.get('page',1),data.get('pageSize',30)
        if (not isinstance(kind,str) or not isinstance(state,str) or kind not in {'all',*TYPES} or state not in {'all',*STATES_LABEL}
            or type(page) is not int or not 1<=page<=1000000 or type(size) is not int or not 1<=size<=100):
            fail('INTERACTION_INPUT_INVALID','互动筛选或分页条件无效')
        views=[self._view(row,states.get(row['id']),links) for row in rows]
        filtered=[v for v in views if (kind=='all' or v['type']==kind) and (state=='all' or v['state']==state)]
        filtered.sort(key=lambda v:(v['observedAt'],v['id']),reverse=True)
        stats=dict(totalEvents=len(views),filteredEvents=len(filtered),withOriginalCommentEvents=sum(v['hasOriginalComment'] for v in views),
            pendingEvidenceEvents=sum(v['type']=='mentions' and not v['hasOriginalComment'] for v in views),
            linkedCommentCount=len({v['linkedLeadId'] for v in views if v['linkedLeadId']}),
            linkedCustomerCount=len({v['linkedCustomerId'] for v in views if v['linkedCustomerId']}),
            byType={k:sum(v['type']==k for v in views) for k in TYPES},
            byState={k:sum(v['state']==k for v in views) for k in STATES_LABEL})
        return dict(items=filtered[(page-1)*size:page*size],stats=stats,total=len(filtered),page=page,pageSize=size,
            hasMore=page*size<len(filtered),scopeKey=digest(scope),
            notice='这里只整理已保存的本人互动；互动数、原评论数与关联客户数分别统计。点赞和关注不代表租房意向。')
