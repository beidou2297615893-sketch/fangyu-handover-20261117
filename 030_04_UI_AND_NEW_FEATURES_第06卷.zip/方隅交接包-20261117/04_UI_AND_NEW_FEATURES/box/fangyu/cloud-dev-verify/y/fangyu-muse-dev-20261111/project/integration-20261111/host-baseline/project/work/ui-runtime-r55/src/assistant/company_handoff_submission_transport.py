"""Fixed one-request submit/status transport; no refresh or automatic retry."""
from copy import deepcopy
import re

from .company_handoff_status_transport import CompanyHandoffStatusTransport, CompanyHandoffStatusTransportError

ACTION = 'acquisition_handoff_submit'
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')


class CompanyHandoffSubmissionTransportError(ValueError):
    def __init__(self, code, message, status=503, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_SUBMISSION_TRANSPORT_' + code
        self.status, self.mutation_committed = status, mutation_committed


def _fail(code, message, status=503, *, mutation=False):
    raise CompanyHandoffSubmissionTransportError(code, message, status, mutation)


class CompanyHandoffSubmissionTransport(CompanyHandoffStatusTransport):
    def _submission_capture(self, actor, margin, *, dispatched=False):
        try:
            return self._capture(actor, margin)
        except CompanyHandoffStatusTransportError as error:
            _fail('SESSION_REQUIRED' if error.code.endswith('_SESSION_REQUIRED') else 'BINDING_CHANGED',
                '当前原公司连接或本人范围需核对，请保留原提交编号', 409,
                mutation=None if dispatched else False)

    def __call__(self, actor, operation, data):
        if (operation != ACTION or not isinstance(data, dict)
                or set(data) != {'environment_id', 'operation', 'channel_id', 'expected_revision', 'idempotency_key'}
                or data.get('operation') != ACTION or data.get('environment_id') != self.environment_id
                or not isinstance(data.get('channel_id'), str) or not _CHANNEL.fullmatch(data['channel_id'])
                or type(data.get('expected_revision')) is not int or not 1 <= data['expected_revision'] < 9007199254740991
                or not isinstance(data.get('idempotency_key'), str) or not _HEX.fullmatch(data['idempotency_key'])):
            _fail('INVALID_REQUEST', '公司提交须来自原准备和固定原号，不能附带联系人或新公司范围', 400)
        before = self._submission_capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], deepcopy(data), before['token'])
        except Exception:
            _fail('RESULT_UNKNOWN', '公司原提交尚未确认，请保留原号只读核对；未自动重发', mutation=None)
        after = self._submission_capture(actor, 0, dispatched=True)
        if after != before:
            _fail('BINDING_CHANGED', '提交返回时公司连接或本人范围已变化，请保留原号', 409, mutation=None)
        fields = {'contract', 'environment_id', 'company_id', 'item', 'replayed', 'server_recorded',
            'platform_delivery_verified', 'attribution_confirmed', 'settlement_active'}
        if (not isinstance(result, dict) or set(result) != fields or result.get('contract') != 'fangyu-workspace-v1'
                or result.get('environment_id') != self.environment_id or result.get('company_id') != self.company_id
                or not isinstance(result.get('item'), dict) or type(result.get('replayed')) is not bool
                or result.get('server_recorded') is not True
                or any(result.get(key) is not False for key in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))):
            _fail('RESULT_UNKNOWN', '公司提交回执身份或格式需核对，原号继续保留', mutation=None)
        if self._submission_capture(actor, 0, dispatched=True) != before:
            _fail('BINDING_CHANGED', '返回时原公司连接已变化，请保留原提交编号', 409, mutation=None)
        return {key: deepcopy(result[key]) for key in ('item', 'replayed')}

    def read_status(self, actor, operation, data):
        if (operation != 'acquisition_handoff_operation_status' or not isinstance(data, dict)
                or set(data) != {'operation_action', 'idempotency_key'} or data.get('operation_action') != ACTION
                or not isinstance(data.get('idempotency_key'), str) or not _HEX.fullmatch(data['idempotency_key'])):
            _fail('INVALID_REQUEST', '原提交查询只接受已保存的动作和原编号', 400)
        before = self._submission_capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], {'environment_id': self.environment_id, 'operation': operation,
                **deepcopy(data)}, before['token'])
        except Exception:
            _fail('READ_UNAVAILABLE', '公司原提交暂不可读，原编号继续保留；本次未重发')
        after = self._submission_capture(actor, 0)
        if after != before:
            _fail('BINDING_CHANGED', '原提交查询期间公司连接或本人范围已变化', 409)
        fields = {'contract', 'environment_id', 'company_id', 'operation_receipt', 'read_only', 'mutation_committed', 'auto_retry'}
        if (not isinstance(result, dict) or set(result) != fields or result.get('contract') != 'fangyu-workspace-v1'
                or result.get('environment_id') != self.environment_id or result.get('company_id') != self.company_id
                or not isinstance(result.get('operation_receipt'), dict) or result.get('read_only') is not True
                or result.get('mutation_committed') is not False or result.get('auto_retry') is not False):
            _fail('READ_UNAVAILABLE', '原公司提交回执身份或格式需核对，原编号继续保留')
        if self._submission_capture(actor, 0) != before:
            _fail('BINDING_CHANGED', '返回时原公司连接已变化，请保留原提交编号', 409)
        return {key: deepcopy(result[key]) for key in ('operation_receipt', 'read_only', 'mutation_committed', 'auto_retry')}
