"""Read-only Windows trust APIs. No UI, online certificate fetch or launch."""
import ctypes as c
from ctypes import wintypes as w
import hashlib,uuid

class TrustError(ValueError):
    pass

class GUID(c.Structure):
    _fields_=[('bytes',c.c_ubyte*16)]
class FILEINFO(c.Structure):
    _fields_=[('cbStruct',w.DWORD),('path',w.LPCWSTR),('handle',w.HANDLE),('subject',c.c_void_p)]
class TRUSTDATA(c.Structure):
    _fields_=[('cbStruct',w.DWORD),('callback',c.c_void_p),('sip',c.c_void_p),('ui',w.DWORD),('revocation',w.DWORD),('choice',w.DWORD),('file',c.POINTER(FILEINFO)),('action',w.DWORD),('state',w.HANDLE),('url',w.LPCWSTR),('flags',w.DWORD),('context',w.DWORD),('settings',c.c_void_p)]
class PROVIDERCERT(c.Structure):
    _fields_=[('cbStruct',w.DWORD),('cert',c.c_void_p)]
class CERTCONTEXT(c.Structure):
    _fields_=[('encoding',w.DWORD),('data',c.POINTER(c.c_ubyte)),('size',w.DWORD),('info',c.c_void_p),('store',w.HANDLE)]
class USAGE(c.Structure):
    _fields_=[('count',w.DWORD),('oids',c.POINTER(c.c_char_p))]
class USAGEMATCH(c.Structure):
    _fields_=[('type',w.DWORD),('usage',USAGE)]
class CHAINPARA(c.Structure):
    _fields_=[('cbSize',w.DWORD),('usage',USAGEMATCH),('issuance',USAGEMATCH),('urlTimeout',w.DWORD),('freshness',w.BOOL),('freshnessTime',w.DWORD),('resync',c.c_void_p),('strong',c.c_void_p),('strongFlags',w.DWORD)]
class TRUSTSTATUS(c.Structure):
    _fields_=[('error',w.DWORD),('info',w.DWORD)]
class CHAINELEMENT(c.Structure):
    _fields_=[('cbSize',w.DWORD),('cert',c.c_void_p),('trust',TRUSTSTATUS),('revocation',c.c_void_p),('issuance',c.c_void_p),('application',c.c_void_p),('extended',w.LPCWSTR)]
class SIMPLECHAIN(c.Structure):
    _fields_=[('cbSize',w.DWORD),('trust',TRUSTSTATUS),('count',w.DWORD),('elements',c.POINTER(c.POINTER(CHAINELEMENT)))]
class CHAINCONTEXT(c.Structure):
    _fields_=[('cbSize',w.DWORD),('trust',TRUSTSTATUS),('count',w.DWORD),('chains',c.POINTER(c.POINTER(SIMPLECHAIN)))]

def _dll(name):
    return c.WinDLL(name,winmode=0x800,use_last_error=True) # System32 only

def microsoft_signature(path,handle):
    """Embedded Authenticode + machine chain, offline revocation cache only.

    The caller holds the exact regular disk file against write/delete. An
    unavailable/uncached trust chain is a refusal, never a synthetic Valid.
    """
    wintrust=_dll('wintrust.dll');crypt=_dll('crypt32.dll')
    wintrust.WinVerifyTrust.argtypes=[w.HWND,c.POINTER(GUID),c.POINTER(TRUSTDATA)];wintrust.WinVerifyTrust.restype=c.c_long
    wintrust.WTHelperProvDataFromStateData.argtypes=[w.HANDLE];wintrust.WTHelperProvDataFromStateData.restype=c.c_void_p
    wintrust.WTHelperGetProvSignerFromChain.argtypes=[c.c_void_p,w.DWORD,w.BOOL,w.DWORD];wintrust.WTHelperGetProvSignerFromChain.restype=c.c_void_p
    wintrust.WTHelperGetProvCertFromChain.argtypes=[c.c_void_p,w.DWORD];wintrust.WTHelperGetProvCertFromChain.restype=c.POINTER(PROVIDERCERT)
    crypt.CertGetNameStringW.argtypes=[c.c_void_p,w.DWORD,w.DWORD,c.c_void_p,w.LPWSTR,w.DWORD];crypt.CertGetNameStringW.restype=w.DWORD
    crypt.CertGetCertificateChain.argtypes=[w.HANDLE,c.c_void_p,c.c_void_p,w.HANDLE,c.POINTER(CHAINPARA),w.DWORD,c.c_void_p,c.POINTER(c.POINTER(CHAINCONTEXT))];crypt.CertGetCertificateChain.restype=w.BOOL
    crypt.CertFreeCertificateChain.argtypes=[c.POINTER(CHAINCONTEXT)]
    action=GUID((c.c_ubyte*16).from_buffer_copy(uuid.UUID('00aac56b-cd44-11d0-8cc2-00c04fc295ee').bytes_le))
    file=FILEINFO(c.sizeof(FILEINFO),str(path),handle,None)
    # No UI; revoke the chain except root, fetch only cached URL material.
    data=TRUSTDATA(c.sizeof(TRUSTDATA),None,None,2,0,1,c.pointer(file),1,None,None,0x1000|0x80,0,None)
    chain=c.POINTER(CHAINCONTEXT)()
    def attr(cert,oid):
        value=c.create_unicode_buffer(1024);raw=c.c_char_p(oid.encode('ascii'))
        n=crypt.CertGetNameStringW(cert,3,0,c.cast(raw,c.c_void_p),value,len(value))
        if not 1<n<=1024:raise TrustError('certificate_name_unavailable')
        return value.value
    def record(cert):
        context=c.cast(cert,c.POINTER(CERTCONTEXT)).contents
        if not 1<=context.size<=65536:raise TrustError('certificate_size')
        return {'commonName':attr(cert,'2.5.4.3'),'organization':attr(cert,'2.5.4.10'),'country':attr(cert,'2.5.4.6'),'certificateSha256':hashlib.sha256(c.string_at(context.data,context.size)).hexdigest()}
    try:
        status=wintrust.WinVerifyTrust(w.HWND(-1),c.byref(action),c.byref(data))
        if status!=0:raise TrustError('authenticode_'+format(status&0xffffffff,'08x'))
        provider=wintrust.WTHelperProvDataFromStateData(data.state)
        signer=wintrust.WTHelperGetProvSignerFromChain(provider,0,False,0) if provider else None
        cert=wintrust.WTHelperGetProvCertFromChain(signer,0) if signer else None
        if not cert or not cert.contents.cert:raise TrustError('authenticode_signer_unavailable')
        leaf=record(cert.contents.cert)
        if (leaf['commonName'],leaf['organization'],leaf['country'])!=('Microsoft Corporation','Microsoft Corporation','US'):raise TrustError('publisher_not_microsoft')
        context=c.cast(cert.contents.cert,c.POINTER(CERTCONTEXT)).contents
        oids=(c.c_char_p*1)(b'1.3.6.1.5.5.7.3.3');para=CHAINPARA();para.cbSize=c.sizeof(para);para.usage=USAGEMATCH(0,USAGE(1,oids));para.urlTimeout=1000
        # HCCE_LOCAL_MACHINE=1: a self-signed CurrentUser trusted root cannot
        # authorize a fake Microsoft leaf. Disable AIA/root updates as well.
        flags=0x4|0x100|0x40000000|0x80000000
        if not crypt.CertGetCertificateChain(w.HANDLE(1),cert.contents.cert,None,context.store,c.byref(para),flags,None,c.byref(chain)):raise TrustError('machine_chain_unavailable')
        if not chain or chain.contents.trust.error or chain.contents.count!=1:raise TrustError('machine_chain_'+format(chain.contents.trust.error if chain else 0xffffffff,'08x'))
        simple=chain.contents.chains[0].contents
        if simple.trust.error or not 2<=simple.count<=8:raise TrustError('machine_chain_not_trusted')
        chain_rows=[record(simple.elements[i].contents.cert) for i in range(simple.count)]
        root=chain_rows[-1]
        if root['organization']!='Microsoft Corporation' or root['country']!='US' or root['commonName'] not in ('Microsoft Root Certificate Authority 2010','Microsoft Root Certificate Authority 2011','Microsoft Root Certificate Authority 2020','Microsoft Identity Verification Root Certificate Authority 2020'):raise TrustError('root_not_microsoft')
        return {'publisher':leaf,'chain':chain_rows,'authenticodeResult':0,'machineChainError':0,'revocation':'cache_only_chain_excluding_root','networkRetrieval':False,'ui':False}
    finally:
        if chain:crypt.CertFreeCertificateChain(chain)
        data.action=2
        wintrust.WinVerifyTrust(w.HWND(-1),c.byref(action),c.byref(data))
