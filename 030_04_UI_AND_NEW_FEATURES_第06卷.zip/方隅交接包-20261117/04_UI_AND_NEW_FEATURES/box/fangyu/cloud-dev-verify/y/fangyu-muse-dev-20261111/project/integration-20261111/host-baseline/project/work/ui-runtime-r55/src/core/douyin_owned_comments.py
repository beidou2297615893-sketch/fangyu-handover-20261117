"""One original owned Douyin main comment page; account authority stays original."""
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import re
import threading
from pathlib import Path
from .adapters import account_execution_lock, AdapterBusy, _BilibiliOwnedCleanupPending
from .douyin_comments_policy import DouyinCommentsPolicy, _digest
from .runtime_license_policy import _plain


class _DouyinCommentCleanupPending(_BilibiliOwnedCleanupPending):
    """Reuse the original permission-independent exact-process finish."""


@dataclass(frozen=True)
class _DouyinCommentOrigin:
    """Private receipt facts only: no action/active call, no new execution grant."""
    manager: object
    owned: object
    bridge_process: object
    executor: object
    session: object
    device: str
    account_id: str
    account_digest: str
    directory: Path
    window_facts: tuple
    files: tuple


def receipt_origin_current(reads, entry, account, policy):
    from assistant.douyin_connection_service import _binding
    origin = entry.get('_douyin_comment_origin')
    if type(origin) is not _DouyinCommentOrigin or type(policy) is not DouyinCommentsPolicy:
        return False
    try:
        server = policy._server
        binding = _binding(server.assistant_service, account['id'])
        if (reads.core is not server.core or origin.manager is not server.account_connections
                or origin.manager.owned.get(account['id']) is not origin.owned
                or tuple(origin.owned.get(k) for k in ('marker','state_path')) != origin.window_facts
                or origin.owned['process'].poll() is not None
                or server.bridge.processes.get(reads.tenant) is not origin.bridge_process
                or origin.bridge_process.poll() is not None or server.bridge.external(reads.tenant)
                or binding[1] is not origin.executor or binding[2] is not origin.session
                or binding[3] != origin.device or origin.device != reads.device_id
                or origin.account_id != account['id'] or _digest(binding[4]) != origin.account_digest):
            return False
        policy.current_review()
        for path, root, digest in origin.files:
            if _plain(path,root) != path or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                return False
        return True
    except (ValueError,RuntimeError,OSError,KeyError,TypeError):
        return False


class _DouyinCommentsCall:
    def __init__(self, reads, entry, user, account, task, policy, revision):
        from assistant.douyin_connection_service import _binding, _ACTOR
        server = policy._server
        current, executor, session, device, selected, stored = _binding(server.assistant_service, account['id'])
        if (reads.core is not server.core or reads.tenant != executor.tenant
                or reads.owner != executor.owner or reads.device_id != device
                or current['id'] != user['id'] or selected != account
                or account.get('status') != 'ready'
                or type(account.get('platform_uid')) is not str
                or re.fullmatch(r'[0-9]{1,160}', account['platform_uid']) is None
                or not account['platform_uid'].strip('0')
                or not account.get('conn_id') or task.get('next_cursor') not in ('', None)
                or not 1 <= task['daily_limit'] <= 20):
            raise ValueError('douyin_owned_comment_scope_unconfirmed')
        self.reads, self.entry, self.policy, self.server = reads, entry, policy, server
        self.task, self.thread, self.active = task, threading.current_thread(), True
        self.user_id, self.executor, self.session, self.device = user['id'], executor, session, device
        self.account_id, self.account = account['id'], _digest(account)
        self.actor = _digest({k: stored.get(k) for k in _ACTOR})
        self.uid, self.conn, self.revision = account['platform_uid'], account['conn_id'], revision
        self.material_snapshot = policy._snapshot()
        self.manager = server.account_connections
        self.owned = self.manager.owned.get(self.account_id)
        self.bridge_process = server.bridge.processes.get(reads.tenant)
        self.window_facts = ({k: self.owned.get(k) for k in ('marker', 'state_path')}
                             if self.owned is not None else None)
        self.bridge_config = server.bridge.root(reads.tenant) / 'config.json'
        self.bridge_config_hash = hashlib.sha256(self.bridge_config.read_bytes()).hexdigest()
        self.directory = server.core.store.directory / 'accounts' / reads.tenant / self.account_id
        window_root = self.directory / 'managed-window'
        self.window_spec = _plain(window_root / 'window.json', self.directory)
        self.script = _plain(server.bridge.root(reads.tenant) / '工作台_抖音连接.user.js',
                             server.core.store.directory)
        self.window_spec_hash = hashlib.sha256(self.window_spec.read_bytes()).hexdigest()
        self.script_hash = hashlib.sha256(self.script.read_bytes()).hexdigest()
        spec = json.loads(self.window_spec.read_text('utf8'))
        if (spec.get('platform') != 'douyin' or spec.get('marker') != self.owned.get('marker')
                or Path(spec.get('profile','')) != window_root / 'profile'
                or spec.get('state_path') != self.owned.get('state_path')
                or Path(spec.get('config','')) != self.bridge_config
                or Path(spec.get('script','')) != self.script):
            raise ValueError('douyin_owned_comment_profile_unconfirmed')
        match = re.fullmatch(r'https://www\.douyin\.com/video/([0-9]{1,24})', task['note_url'])
        if match is None: raise ValueError('douyin_owned_comment_source_unconfirmed')
        self.args = [str(server.bridge.runtime / 'cli.js'), 'comment-page', match.group(1),
            '--count', str(task['daily_limit']), '--cursor', '0', '--conn-id', self.conn,
            '--no-store', '--no-log']

    def check(self, adapters=None, platform=None, args=None, directory=None, job_id=None):
        from assistant.douyin_connection_service import _binding, _ACTOR
        if (not self.active or self.thread is not threading.current_thread()
                or type(self.policy) is not DouyinCommentsPolicy
                or self.server.account_connections is not self.manager
                or self.server.core is not self.reads.core
                or self.owned is None or self.manager.owned.get(self.account_id) is not self.owned
                or self.owned['process'].poll() is not None
                or {k: self.owned.get(k) for k in ('marker', 'state_path')} != self.window_facts
                or self.bridge_process is None
                or self.server.bridge.processes.get(self.reads.tenant) is not self.bridge_process
                or self.bridge_process.poll() is not None
                or self.server.bridge.external(self.reads.tenant)
                or hashlib.sha256(self.bridge_config.read_bytes()).hexdigest() != self.bridge_config_hash
                or _plain(self.window_spec,self.directory) != self.window_spec
                or _plain(self.script,self.server.core.store.directory) != self.script
                or hashlib.sha256(self.window_spec.read_bytes()).hexdigest() != self.window_spec_hash
                or hashlib.sha256(self.script.read_bytes()).hexdigest() != self.script_hash):
            raise ValueError('douyin_owned_comment_scope_changed')
        if adapters is not None and (adapters is not self.server.core.adapters or platform != 'douyin'
                or args != self.args or Path(directory) != self.directory
                or job_id != self.entry['operation_id']):
            raise ValueError('douyin_owned_comment_call_changed')
        current, executor, session, device, account, stored = _binding(self.server.assistant_service, self.account_id)
        with self.reads._lock:
            if (self.entry.get('cancelled') or not self.entry.get('running')
                    or not any(item is self.entry for item in self.reads._operations.values())
                    or executor is not self.executor or session is not self.session or device != self.device
                    or current['id'] != self.user_id or _digest(account) != self.account
                    or _digest({k: stored.get(k) for k in _ACTOR}) != self.actor):
                raise ValueError('douyin_owned_comment_scope_changed')
        self.policy.current_review()
        if self.policy._snapshot() != self.material_snapshot:
            raise ValueError('douyin_owned_comment_transport_changed')
        return account

    def check_spec(self, spec):
        """Validate original generated argv/cwd/env at the final spawn boundary."""
        root = self.directory.resolve()
        bridge = self.bridge_config.parent
        expected = {'HOME':str(root),'USERPROFILE':str(root),'XDG_CONFIG_HOME':str(root/'.config'),
            'APPDATA':str(root/'AppData'/'Roaming'),'LOCALAPPDATA':str(root/'AppData'/'Local'),
            'LEADSTUDIO_ISOLATED':'1','PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8',
            'DOUYIN_CONFIG':str(bridge/'config.json'),'DOUYIN_LOG_DIR':str(bridge/'logs'),
            'DOUYIN_STORAGE_DIR':str(bridge/'storage')}
        if (type(spec) is not dict or set(spec) != {'argv','env','cwd'}
                or spec['argv'] != [str(self.server.bridge.runtime/'node.exe')] + self.args
                or spec['cwd'] != str(root) or spec['env'] != expected):
            raise ValueError('douyin_owned_comment_transport_changed')

    @contextmanager
    def launch(self):
        # Preserve original receipt order reads -> Core, then adapter lifecycle.
        with self.reads._lock, self.server.core.lock:
            self.check()
            yield

    def identity(self):
        from account_connections import verify_douyin
        from assistant.douyin_connection_service import _identity
        self.check()
        revision = self.policy.resolve()
        if revision is None or revision['revision'] != self.revision:
            raise ValueError('douyin_comment_component_changed')
        items = self.server.bridge.connections(self.reads.tenant)
        self.check()
        matches = [item for item in items if item.get('id') == self.conn]
        if (len(matches) != 1 or matches[0].get('alive') is not True
                or type(self.owned.get('marker')) is not str
                or '#workbench-account=' + self.owned['marker'] not in matches[0].get('url', '')):
            raise ValueError('douyin_owned_comment_window_changed')
        self.check()
        raw = verify_douyin(self.server.bridge, self.reads.tenant, self.conn)
        # Original verify_douyin folds both authenticated and getComments
        # capability into authenticated=True; it deliberately omits capable.
        identity = _identity(raw)
        self.check()
        if identity['uid'] != self.uid:
            raise ValueError('douyin_owned_comment_identity_changed')


@contextmanager
def owned_comments(reads, entry, user, account, task, policy):
    if type(policy) is not DouyinCommentsPolicy or policy._server.core is not reads.core:
        raise ValueError('douyin_comment_component_pending')
    revision = policy.resolve()
    if revision is None: raise ValueError('douyin_comment_component_pending')
    call = _DouyinCommentsCall(reads, entry, user, account, task, policy, revision['revision'])
    lock = call.manager.locks.setdefault(account['id'], threading.Lock())
    if not lock.acquire(blocking=False): raise AdapterBusy('本人窗口正在核对，本次未读取')
    try:
        with account_execution_lock(call.directory):
            call.identity()
            task['_douyin_comments_call'] = call
            try:
                yield
            except _DouyinCommentCleanupPending as pending:
                # Keep the original account lease/lock and exact registry until
                # physical exit is confirmed, even after authority is revoked.
                while not pending.finish(): threading.Event().wait(0.1)
                raise RuntimeError('抖音本次原子进程已安全收尾，结果未确认') from None
            else:
                call.identity()
                entry['_douyin_comment_origin'] = _DouyinCommentOrigin(call.manager, call.owned,
                    call.bridge_process, call.executor, call.session, call.device, call.account_id,
                    call.account, call.directory, tuple(call.window_facts[k] for k in ('marker','state_path')),
                    ((call.window_spec,call.directory,call.window_spec_hash),
                        (call.script,call.server.core.store.directory,call.script_hash),
                        (call.bridge_config,call.server.core.store.directory,call.bridge_config_hash)))
            finally:
                task.pop('_douyin_comments_call', None)
    finally:
        call.active = False
        lock.release()
