"""Owner-only search-selection provenance, never a platform permission grant.

The five-field caller supplies IDs only. The original search module resolves
the locator privately; the original comments action executes exactly once.
Only safe provenance is appended inside the original archive transaction.
"""
from copy import deepcopy
import json
import math
import re
import time

from core import CoreError
from .self_operating_acquisition import OwnerAcquisitionError
from .platform_receipt_archive import SOURCES, BATCHES, RECEIPTS, _hash, _safe_text

ENTITY = 'owner_keyword_source_traces'
READ = 'owner_keyword_comments'
GET = 'owner_keyword_source_trace_get'
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_REQUEST = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{7,127}\Z')
_NOTE = re.compile(r'[a-f0-9]{24}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_ACTOR = ('id', 'tenant_id', 'username', 'role', 'cloud_bound', 'personal_owner')
_ACCOUNT = ('id', 'tenant_id', 'cloud_owner', 'platform', 'platform_uid', 'conn_id')
_FALSE = ('auto_retry', 'platform_requests_started', 'platform_reply_verified',
          'customer_identity_verified', 'resource_receipt_verified',
          'cross_machine_verified', 'attribution_confirmed', 'real_platform_verified')
_ROW = frozenset(('schema', 'id', 'tenant_id', 'cloud_owner', 'instance_id', 'account_id',
    'account_digest', 'actor_digest', 'search_request_id', 'comment_request_id', 'post_id',
    'search_operation_id', 'search_result_digest', 'search_purpose_revision',
    'search_source_revision', 'keyword_digest', 'keyword_label', 'keyword_label_redacted',
    'batch_id', 'archive_receipt_id', 'read_operation_id', 'comment_input_digest',
    'comment_batch_digest', 'lead_ids', 'created_at',
    'record_digest'))


class OwnerKeywordTraceError(OwnerAcquisitionError):
    """Uses the existing typed owner HTTP error envelope and unknown semantics."""
    def __init__(self, code, message, *, mutation_committed=False):
        super().__init__(message, mutation_committed=mutation_committed)
        self.code = 'OWNER_KEYWORD_TRACE_' + code


def _fail(code, message, *, unknown=False):
    raise OwnerKeywordTraceError(code, message, mutation_committed=None if unknown else False)


def _actor(user):
    return _hash({key: user.get(key) for key in _ACTOR})


def _account(account):
    return _hash({key: account.get(key) for key in _ACCOUNT})


def _label(keyword):
    # Search locators and secrets never become a provenance display label.
    if re.search(r'https?://|xsec_|cookie|password|secret|api[_-]?key|Bearer', keyword, re.I):
        return '', True
    return _safe_text(keyword, 200)


def _valid_row(row):
    if (type(row) is not dict or set(row) != _ROW or row['schema'] != 'owner_keyword_source_trace_v1'
            or any(type(row[k]) is not str or not 1 <= len(row[k]) <= 160
                   or re.search(r'[\x00-\x1f\x7f]', row[k]) for k in
                   ('tenant_id', 'cloud_owner', 'instance_id', 'account_id'))
            or any(type(row[k]) is not str or not _ID.fullmatch(row[k]) for k in
                   ('search_operation_id', 'read_operation_id'))
            or any(type(row[k]) is not str or not _HEX.fullmatch(row[k]) for k in
                ('id', 'account_digest', 'actor_digest', 'search_result_digest',
                 'search_purpose_revision', 'search_source_revision', 'keyword_digest',
                 'batch_id', 'archive_receipt_id', 'comment_input_digest',
                 'comment_batch_digest', 'record_digest'))
            or any(type(row[k]) is not str or not _REQUEST.fullmatch(row[k]) for k in
                ('search_request_id', 'comment_request_id'))
            or type(row['post_id']) is not str or not _NOTE.fullmatch(row['post_id'])
            or type(row['lead_ids']) is not list or not 1 <= len(row['lead_ids']) <= 20
            or len(set(row['lead_ids'])) != len(row['lead_ids'])
            or any(type(x) is not str or not _HEX.fullmatch(x) for x in row['lead_ids'])
            or type(row['keyword_label']) is not str or len(row['keyword_label']) > 200
            or type(row['keyword_label_redacted']) is not bool
            or _label(row['keyword_label'])[0] != row['keyword_label']
            or type(row['created_at']) not in (int, float) or not math.isfinite(row['created_at'])
            or row['created_at'] < 1577836800
            or row['id'] != _hash([row['tenant_id'], row['cloud_owner'], row['instance_id'],
                                  row['account_id'], row['comment_request_id']])
            or _hash({k: v for k, v in row.items() if k != 'record_digest'}) != row['record_digest']):
        _fail('RECORD_HELD', '原关键词出处记录需核对；未改变来源或评级')
    return row


class OwnerKeywordSourceTrace:
    ACTIONS = frozenset((READ, GET))

    def __init__(self, workspace):
        from .self_operating_read import OwnerReadWorkspace
        from .owner_single_keyword_search import OwnerSingleKeywordSearch
        from .self_operating_archive import OwnerSourceArchive
        if (type(workspace) is not OwnerReadWorkspace
                or type(workspace._keyword_search) is not OwnerSingleKeywordSearch
                or type(workspace._archive) is not OwnerSourceArchive
                or workspace._reads is None):
            _fail('SCOPE_REQUIRED', '关键词出处须由当前原自营读取实例建立')
        self.workspace = workspace
        self.core, self.store = workspace.server.core, workspace.server.core.store
        self.instance_id = workspace.instance.check()['selfOperatingRead']['instance_id']
        # Private RAM only: each original comments ID can dispatch at most once.
        self._bindings = {}

    def describe(self):
        # Route presence only; never implies a reviewed search/comments purpose.
        return dict(contract='owner_keyword_source_trace_v1', available=True,
            limit=20, auto_retry=False, permission_grant=False, real_platform_verified=False)

    def _current(self, token, account_id, *, metadata=False):
        w = self.workspace
        if (getattr(w, '_keyword_source_trace', None) is not self
                or w.server._self_operating_reads is not w or w.server.core is not self.core
                or w.instance.check()['selfOperatingRead']['instance_id'] != self.instance_id):
            _fail('SCOPE_CHANGED', '关键词出处的本人实例已变化；保留原编号')
        user = w._actor(token)
        account = w._account(user, account_id, cleanup=metadata)
        return user, account

    def execute(self, token, action, data):
        if type(data) is not dict or action not in self.ACTIONS:
            _fail('INVALID_INPUT', '只支持原关键词选中评论与只读出处核对')
        if action == GET:
            return self._get(token, data)
        fields = {'account_id', 'search_request_id', 'post_id', 'request_id', 'limit'}
        if (set(data) != fields or type(data.get('account_id')) is not str
                or not _ID.fullmatch(data['account_id']) or type(data['limit']) is not int
                or data['limit'] != 20 or type(data['post_id']) is not str
                or not _NOTE.fullmatch(data['post_id'])
                or any(type(data[k]) is not str or not _REQUEST.fullmatch(data[k])
                       for k in ('search_request_id', 'request_id'))
                or data['search_request_id'] == data['request_id']):
            _fail('INVALID_INPUT', '只接受原账号、原搜索作品与一次首20条评论编号')
        w = self.workspace
        with w._lock:
            user, account = self._current(token, data['account_id'], metadata=True)
            if data['request_id'] in self._bindings:
                _fail('LOOKUP_REQUIRED', '原评论编号已有关键词绑定，请只核对原评论；未重发', unknown=True)
            with w._reads._lock:
                if data['request_id'] in w._reads._operations:
                    _fail('REQUEST_EXISTS', '原评论编号已被使用，请核对原号；未重发', unknown=True)
            reservation = w._reads.owner_xhs_prepare(
                {'account_id': data['account_id'], 'request_id': data['request_id']},
                self.core._public(user))
            try:
                user, account = self._current(token, data['account_id'])
                selected = w._keyword_search.capture_selection(token, data['account_id'],
                    data['search_request_id'], data['post_id'])
            except (CoreError, ValueError, RuntimeError, OSError):
                # The original service can attest only this newly reserved
                # pre-dispatch refusal. Never reject after delegation starts.
                if reservation is not None:
                    w._reads.owner_xhs_reject(reservation)
                _fail('ORIGIN_HELD', '原搜索、选中作品或当前用途需核对；未启动评论')
            binding = {'data': deepcopy(data), 'actor_digest': _actor(user),
                'account_digest': _account(account), 'selected': selected}
            self._bindings[data['request_id']] = binding
        # Never hold the workspace lock across synchronous platform transport:
        # original status/cancel must enter from another request thread.
        # Search capture has closed its frame; comments owns all original guards.
        try:
            result = w.dispatch(token, 'product_action', {'action': 'platform_read_comments',
                'data': {'account_id': data['account_id'], 'request_id': data['request_id'],
                         'reference': selected['reference'], 'limit': 20}})
            with w._lock:
                if self._bindings.get(data['request_id']) is not binding:
                    _fail('ORIGIN_CHANGED', '原评论关键词绑定变化，请只核对原号', unknown=True)
                fresh = w._keyword_search.capture_selection(token, data['account_id'],
                    data['search_request_id'], data['post_id'])
                if fresh != selected:
                    _fail('ORIGIN_CHANGED', '评论返回时原搜索出处变化，请核对原评论编号', unknown=True)
                self._current(token, data['account_id'])
                return result['result']
        except Exception:
            _fail('COMMENTS_UNKNOWN', '原评论结果或出处未确认，请只核对原评论编号；未重发', unknown=True)

    def store_archive(self, db, snapshot, batch_id, lead_ids, receipt_id, stamp, actor):
        """Called only by the sealed owner scope inside original archive SQL."""
        w = self.workspace
        saved, account, token = w._archive._scope.check(actor)
        if db.in_transaction is not True:
            _fail('TRANSACTION_REQUIRED', '关键词出处必须与原来源同事务保存')
        request = snapshot.get('request_id')
        binding = self._bindings.get(request)
        if binding is None:
            return  # Old/manual references remain explicitly unlinked on GET.
        if (binding['data']['account_id'] != account['id'] or binding['actor_digest'] != _actor(saved)
                or binding['account_digest'] != _account(account)
                or snapshot.get('origin', {}).get('account_id') != account['id']
                or snapshot.get('result', {}).get('platform') != 'xiaohongshu'
                or snapshot['result'].get('action') != 'comments'
                or any(item.get('post_id') != binding['data']['post_id']
                       for item in snapshot['result'].get('items', []))):
            _fail('ORIGIN_CHANGED', '原评论与搜索选中出处不一致，本批未保存')
        try:
            selected = w._keyword_search.capture_selection(token, account['id'],
                binding['data']['search_request_id'], binding['data']['post_id'])
        except (CoreError, ValueError, RuntimeError, OSError):
            _fail('ORIGIN_HELD', '原搜索已取消、过期或用途变化，本批未保存')
        if selected != binding['selected']:
            _fail('ORIGIN_CHANGED', '原搜索回显已变化，本批未保存')
        label, redacted = _label(selected['keyword'])
        row = dict(schema='owner_keyword_source_trace_v1',
            id=_hash([saved['tenant_id'], saved['username'], self.instance_id, account['id'], request]),
            tenant_id=saved['tenant_id'], cloud_owner=saved['username'], instance_id=self.instance_id,
            account_id=account['id'], account_digest=_account(account), actor_digest=_actor(saved),
            search_request_id=binding['data']['search_request_id'], comment_request_id=request,
            post_id=binding['data']['post_id'], search_operation_id=selected['search_operation_id'],
            search_result_digest=selected['search_result_digest'],
            search_purpose_revision=selected['search_purpose_revision'],
            search_source_revision=selected['search_source_revision'], keyword_digest=_hash(selected['keyword']),
            keyword_label=label, keyword_label_redacted=redacted, batch_id=batch_id,
            archive_receipt_id=receipt_id, read_operation_id=snapshot['operation_id'],
            comment_input_digest=snapshot['origin']['input_digest'],
            comment_batch_digest=_hash([snapshot['origin'], snapshot['result_digest'], snapshot['operation_id']]),
            lead_ids=list(lead_ids), created_at=stamp)
        row['record_digest'] = _hash(row)
        _valid_row(row)
        existing = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (ENTITY, row['id'], saved['tenant_id'])).fetchone()
        if existing:
            old = _valid_row(json.loads(existing['body']))
            if {k: v for k, v in old.items() if k not in ('created_at', 'record_digest')} != {
                    k: v for k, v in row.items() if k not in ('created_at', 'record_digest')}:
                _fail('RECORD_CONFLICT', '原出处编号已有不同记录；不能覆盖')
        else:
            db.execute('INSERT INTO records VALUES(?,?,?,?)',
                (ENTITY, row['id'], saved['tenant_id'], json.dumps(row, ensure_ascii=False,
                    sort_keys=True, separators=(',', ':'), allow_nan=False)))
        # Both frames have current checks after capture, and original owned_receipt
        # has its final cancellation/identity check before the same SQL commit.
        w._archive._scope.check(actor, account)

    def _source_identity_proof(self, db, token, user, account, lead):
        """Reuse fixed source identity, never grant contact/attribution authority."""
        from .self_operating_acquisition import OwnerAcquisition
        acquisition = self.workspace._acquisition
        if type(acquisition) is not OwnerAcquisition or acquisition._current(token) != user:
            _fail('SOURCE_REQUIRED', '本人原来源核对范围已变化')
        acquisition._load_source_identity(db, user, account['id'], lead['id'])

    def _trace_archive_proof(self, db, user, account, row):
        """Prove this new comments archive separately from the immutable source."""
        archive = self.workspace._archive._archive
        batch = archive._row(db, BATCHES, row['batch_id'])
        receipt = archive._row(db, RECEIPTS, row['archive_receipt_id'])
        if (not batch or not receipt or row['batch_id'] != _hash([user['tenant_id'],
                user['username'], self.instance_id, account['id'], row['comment_request_id']])
                or batch.get('cloud_owner') != user['username']
                or batch.get('device_id') != self.instance_id
                or batch.get('actor') != archive._actor(user)
                or batch.get('input_digest') != row['comment_input_digest']
                or batch.get('batch_digest') != row['comment_batch_digest']
                or type(batch.get('source_count')) is not int
                or batch['source_count'] != len(row['lead_ids'])
                or batch.get('lead_ids') != row['lead_ids']
                or receipt.get('state') != 'succeeded'
                or receipt.get('batch_id') != row['batch_id']
                or receipt.get('payload_digest') != _hash([account['id'], row['comment_request_id']])):
            _fail('SOURCE_REQUIRED', '这次关键词出处的原评论批或成功回执需核对')
        result = archive._receipt_view(receipt, user)
        if (result.get('state') != 'succeeded' or result.get('lead_ids') != row['lead_ids']
                or result.get('accepted_count') != len(row['lead_ids'])):
            _fail('SOURCE_REQUIRED', '这次关键词出处的原保存数量或主体需核对')

    def _get(self, token, data):
        if (set(data) != {'account_id', 'lead_id', 'limit', 'cursor'} or type(data.get('account_id')) is not str
                or not _ID.fullmatch(data['account_id']) or type(data.get('lead_id')) is not str
                or not _HEX.fullmatch(data['lead_id']) or type(data['limit']) is not int
                or data['limit'] != 20):
            _fail('INVALID_INPUT', '出处只读核对须使用本人原账号与保存来源编号')
        cursor = data['cursor']
        if cursor is None:
            after, cutoff = '', time.time()
        elif (type(cursor) is dict and set(cursor) == {'schema', 'after', 'cutoff'}
                and cursor['schema'] == 'owner_keyword_trace_cursor_v1'
                and type(cursor['after']) is str and _HEX.fullmatch(cursor['after'])
                and type(cursor['cutoff']) in (int, float) and math.isfinite(cursor['cutoff'])
                and 0 < cursor['cutoff'] <= time.time()
                and len(json.dumps(cursor, ensure_ascii=True)) <= 256):
            after, cutoff = cursor['after'], cursor['cutoff']
        else:
            _fail('CURSOR_HELD', '出处分页位置需核对，请明确重新核对首页')
        w = self.workspace
        with w._lock:
            user, account = self._current(token, data['account_id'], metadata=True)
            with w._archive._scope.metadata_call(token, account), self.core.lock, self.store.connect() as db:
                lead = w._archive._archive._row(db, 'leads', data['lead_id'])
                source = w._archive._archive._row(db, SOURCES,
                    _hash([user['tenant_id'], lead.get('source_uid')])) if lead else None
                if (not lead or not source or lead.get('cloud_owner') != user['username']
                        or source.get('cloud_owner') != user['username']
                        or source.get('lead_id') != data['lead_id']
                        or source.get('account_id') != account['id']
                        or source.get('device_id') != self.instance_id
                        or lead.get('readonly_archive') is not True or lead.get('can_reply') is not False):
                    _fail('SOURCE_REQUIRED', '此来源没有匹配本人的原账号归档证据')
                rows, scanned, last, source_checked = [], 0, after, False
                candidates = db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? AND id>? ORDER BY id LIMIT 200',
                    (ENTITY, user['tenant_id'], after)).fetchall()
                for raw in candidates:
                    last, scanned = raw['id'], scanned + 1
                    row = _valid_row(json.loads(raw['body']))
                    if row['id'] != last or row['tenant_id'] != user['tenant_id']:
                        _fail('RECORD_HELD', '出处分页原记录需核对；未改变来源或评级')
                    if row['created_at'] > cutoff:
                        continue
                    if (row['cloud_owner'] == user['username'] and row['instance_id'] == self.instance_id
                            and row['account_id'] == account['id'] and row['account_digest'] == _account(account)
                            and row['actor_digest'] == _actor(user) and data['lead_id'] in row['lead_ids']):
                        if not source_checked:
                            self._source_identity_proof(db, token, user, account, lead)
                            source_checked = True
                        if row['post_id'] != source.get('post_id'):
                            _fail('SOURCE_REQUIRED', '这次关键词出处与原评论作品不一致')
                        self._trace_archive_proof(db, user, account, row)
                        rows.append({k: deepcopy(row[k]) for k in ('id', 'search_request_id',
                            'comment_request_id', 'post_id', 'keyword_digest', 'keyword_label',
                            'keyword_label_redacted', 'batch_id', 'created_at')})
                        if len(rows) == 20:
                            break
                more = bool(db.execute('SELECT id FROM records WHERE entity=? AND tenant_id=? AND id>? LIMIT 1',
                    (ENTITY, user['tenant_id'], last)).fetchone())
                next_cursor = dict(schema='owner_keyword_trace_cursor_v1', after=last, cutoff=cutoff) if more else None
                w._archive._scope.check(user, account)
                return dict(contract='owner_keyword_source_trace_v1',
                    state='linked' if rows else ('unlinked' if cursor is None and not more else 'page_empty'),
                    account_id=account['id'], lead_id=data['lead_id'], items=rows,
                    scanned_count=scanned,
                    page=dict(has_more=more, next_cursor=next_cursor, cutoff=cutoff, limit=20, scan_limit=200),
                    read_only=True, mutation_committed=False,
                    local_only=True, storage_scope='this_device', source_verification='transport_reported_only',
                    **{key: False for key in _FALSE})
