"""Pure argv builders for the two account-owned XHS helpers.

These builders do not launch processes or authorize an account. The callers'
existing release, profile, account, and cancellation gates remain mandatory.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import stat
import sys


_SOURCE_PAGE = Path(__file__).resolve().parents[1] / 'xhs_page_window.py'
_SOURCE_LOGIN = Path(__file__).resolve().with_name('browser_login_window.py')
_SOURCE_WEIBO = Path(__file__).resolve().parents[1] / 'platform_cli.py'
_PYTHON = re.compile(r'python(?:w|\d+(?:\.\d+)?)?\.exe', re.IGNORECASE)


class OwnedHelperArgvError(ValueError):
    """Fixed code only; never embeds a path or credential."""


@dataclass(frozen=True)
class OwnedHelperCommand:
    argv: tuple[str, ...]
    cwd: str


def _path(value: Path) -> str:
    if (not isinstance(value, Path) or not value.is_absolute() or
            not value.name or any(part in ('.', '..') for part in value.parts) or
            any(ord(char) < 32 or ord(char) == 127 for char in str(value))):
        raise OwnedHelperArgvError('helper_path_invalid')
    return str(value)


def _entry() -> tuple[Path, bool]:
    current = Path(sys.executable)
    if not current.is_absolute() or not current.is_file():
        raise OwnedHelperArgvError('helper_executable_invalid')
    frozen = getattr(sys, 'frozen', False) is True
    if frozen:
        if current.suffix.lower() != '.exe':
            raise OwnedHelperArgvError('helper_executable_invalid')
    elif not _PYTHON.fullmatch(current.name):
        raise OwnedHelperArgvError('helper_source_only')
    return current, frozen


def weibo_helper_argv(*, probe: bool = False) -> OwnedHelperCommand:
    if type(probe) is not bool:raise OwnedHelperArgvError('helper_mode_invalid')
    executable,frozen=_entry()
    mode='--owned-weibo-ipc-helper'
    if frozen:
        argv=(str(executable),mode)
        cwd=executable.parent
    else:
        if not _SOURCE_WEIBO.is_file():raise OwnedHelperArgvError('helper_source_missing')
        argv=(str(executable),'-I','-B',_path(_SOURCE_WEIBO),mode)
        cwd=_SOURCE_WEIBO.parent
    if probe:argv+=('--probe-ipc',)
    return OwnedHelperCommand(argv,_path(cwd))


def page_helper_argv(spec_path: Path, profile_dir: Path) -> OwnedHelperCommand:
    """Expose only the profile already validated by the private page spec."""
    spec = _path(spec_path)
    if spec_path.name != 'spec.json':
        raise OwnedHelperArgvError('helper_path_invalid')
    profile = _path(profile_dir)
    if (len(spec_path.parents) < 4 or
            profile_dir != spec_path.parents[3] / 'xhs-browser-profile'):
        raise OwnedHelperArgvError('helper_argument_invalid')
    executable, frozen = _entry()
    if frozen:
        return OwnedHelperCommand((str(executable), '--owned-xhs-page-helper',
                                   '--bridge-spec', spec, '--profile-dir', profile),
                                  str(executable.parent))
    if not _SOURCE_PAGE.is_file():
        raise OwnedHelperArgvError('helper_source_missing')
    return OwnedHelperCommand((str(executable), str(_SOURCE_PAGE),
                               '--bridge-spec', spec, '--profile-dir', profile),
                              str(_SOURCE_PAGE.parent))


def login_helper_argv(staging_dir: Path, cancel_file: Path, profile_dir: Path,
                      *, natural_identity: bool = False) -> OwnedHelperCommand:
    """The live login argv contains paths and one fixed feature bit only."""
    stage, cancel, profile = (_path(staging_dir), _path(cancel_file), _path(profile_dir))
    if (type(natural_identity) is not bool or cancel_file.parent != staging_dir or
            cancel_file.name != 'cancel.flag' or
            profile_dir.name != 'xhs-browser-profile'):
        raise OwnedHelperArgvError('helper_argument_invalid')
    executable, frozen = _entry()
    entry = [str(executable), '--owned-xhs-login-helper'] if frozen else [str(executable)]
    if not frozen:
        if not _SOURCE_LOGIN.is_file():
            raise OwnedHelperArgvError('helper_source_missing')
        entry.append(str(_SOURCE_LOGIN))
    argv = entry + ['--live', '--staging-dir', stage, '--cancel-file', cancel,
                    '--profile-dir', profile]
    if natural_identity:
        argv.append('--natural-identity')
    return OwnedHelperCommand(tuple(argv), str(executable.parent if frozen else
                                        _SOURCE_LOGIN.parent))


def tracked_reply_helper_argv(spec_path: Path) -> OwnedHelperCommand:
    spec=_path(spec_path)
    if spec_path.name!='spec.json' or spec_path.parent.parent.name!='tracked-reply':
        raise OwnedHelperArgvError('helper_argument_invalid')
    executable,frozen=_entry()
    if frozen:
        return OwnedHelperCommand((str(executable),'--owned-xhs-tracked-reply-helper',
                                   '--spec',spec),str(executable.parent))
    return OwnedHelperCommand((str(executable),'-m','assistant.tracked_reply_window_helper',
                               '--spec',spec),str(Path(__file__).resolve().parents[1]))


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate')
        value[key] = item
    return value


def _reject_constant(_value):
    raise ValueError('nonfinite')


def _file_info(path: Path):
    info = os.lstat(path)
    if (stat.S_ISLNK(info.st_mode) or
            getattr(info, 'st_file_attributes', 0) &
            getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0) or
            (hasattr(path, 'is_junction') and path.is_junction())):
        raise ValueError('reparse')
    return info


def read_login_outcome(staging_dir: Path) -> bytes | None:
    """Read one fixed sibling marker after the owned login child has exited.

    The caller owns the child-exit check and current account/job authorization.
    No file contents or path are returned on any invalid state.
    """
    try:
        _path(staging_dir)
        if (not re.fullmatch(r'[a-f0-9]{24}', staging_dir.name) or
                staging_dir.parent.name != 'browser-login' or
                staging_dir.parent.parent.name != 'work' or
                not re.fullmatch(r'[a-f0-9]{32}', staging_dir.parents[2].name) or
                staging_dir.parents[4].name != 'accounts'):
            return None
        marker = staging_dir.parent / (staging_dir.name + '.outcome.json')
        directory_ids = {}
        for part in (staging_dir, *staging_dir.parents):
            try:
                info = _file_info(part)
            except FileNotFoundError:
                if part == staging_dir:
                    continue  # Successful helper cleanup may remove the job directory.
                return None
            if not stat.S_ISDIR(info.st_mode):
                return None
            directory_ids[part] = (info.st_dev, info.st_ino)
        before = _file_info(marker)
        if (not stat.S_ISREG(before.st_mode) or
                not 1 <= before.st_size <= 1024 or before.st_nlink != 1):
            return None
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
        descriptor = os.open(marker, flags)
        with os.fdopen(descriptor, 'rb') as stream:
            opened = os.fstat(stream.fileno())
            if (not stat.S_ISREG(opened.st_mode) or opened.st_size != before.st_size or
                    (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino)):
                return None
            raw = stream.read(1025)
        after = _file_info(marker)
        if (len(raw) != before.st_size or len(raw) > 1024 or
                (after.st_dev, after.st_ino, after.st_size) !=
                (before.st_dev, before.st_ino, before.st_size)):
            return None
        for part, identity in directory_ids.items():
            current = _file_info(part)
            if (current.st_dev, current.st_ino) != identity:
                return None
        data = json.loads(raw.decode('ascii'), object_pairs_hook=_unique_object,
                          parse_constant=_reject_constant)
        if (type(data) is not dict or set(data) != {'version', 'helper_outcome'} or
                type(data['version']) is not int or data['version'] != 1 or
                type(data['helper_outcome']) is not str):
            return None
        from .browser_login_window import _RECORDED_OUTCOMES
        if data['helper_outcome'] not in _RECORDED_OUTCOMES:
            return None
        return data['helper_outcome'].encode('ascii')
    except (OSError, ValueError, TypeError, IndexError, UnicodeError, ImportError):
        return None
