"""Own-or-borrow the fixed-port local OpenCLI 1.8.8 daemon.

Only /status is requested. Never shuts down a service via HTTP or kills a PID
reported by a remote endpoint. Source contract: OpenCLI src/daemon.ts /status,
src/browser/daemon-lifecycle.ts compiled daemon.js launch, constants.ts:19825.
Borrowed services are reported read-only; callers must enforce this for writes.
"""
import errno
import http.client
import json
import os
from pathlib import Path
import subprocess
import threading
import time
from urllib.parse import urlencode

PORT = 19825
VERSION = '1.8.8'
RUNTIME = Path(__file__).resolve().parents[2] / 'opencli-build/runtime'


class OpenCLIBridgeError(RuntimeError):
    pass


def _context(value):
    if not isinstance(value, str) or not value.strip() or value != value.strip() or len(value) > 256 or any(ord(c) < 32 for c in value):
        raise OpenCLIBridgeError('请选择明确的OpenCLI浏览器配置ID')
    return value


def _read_status(context_id=None):
    """No proxy, redirect, external URL or fallback profile is permitted."""
    suffix = '?' + urlencode({'contextId': _context(context_id)}) if context_id is not None else ''
    connection = http.client.HTTPConnection('127.0.0.1', PORT, timeout=3)
    try:
        try:
            connection.request('GET', '/status' + suffix, headers={'X-OpenCLI': '1'})
        except TimeoutError as exc:
            raise OpenCLIBridgeError('连接本机OpenCLI服务超时（19825端口，3秒）；未启动或替换任何服务，请稍后重试') from exc
        response = connection.getresponse()
        raw = response.read(1024 * 1024 + 1)
        if response.status != 200 or len(raw) > 1024 * 1024:
            raise OpenCLIBridgeError('19825端口已被不兼容服务占用')
        data = json.loads(raw)
        if (not isinstance(data, dict) or data.get('ok') is not True
                or data.get('daemonVersion') != VERSION or data.get('port') != PORT
                or type(data.get('pid')) is not int or data['pid'] <= 0
                or not isinstance(data.get('profiles'), list)):
            raise OpenCLIBridgeError('19825端口服务不兼容，需要OpenCLI ' + VERSION)
        for profile in data['profiles']:
            if not isinstance(profile, dict):
                raise OpenCLIBridgeError('OpenCLI配置列表格式无效')
            _context(profile.get('contextId'))
            if not isinstance(profile.get('extensionConnected'), bool):
                raise OpenCLIBridgeError('OpenCLI连接状态格式无效')
        return data
    except ConnectionRefusedError:
        return None
    except TimeoutError as exc:
        raise OpenCLIBridgeError('本机OpenCLI状态响应超时（3秒）；服务状态未知，未启动或替换任何服务') from exc
    except OSError as exc:
        if exc.errno == errno.ECONNREFUSED or getattr(exc, 'winerror', None) == 10061:
            return None
        raise OpenCLIBridgeError('19825端口响应异常，未启动或替换任何服务') from exc
    except (ValueError, http.client.HTTPException) as exc:
        raise OpenCLIBridgeError('19825端口返回无效OpenCLI状态') from exc
    finally:
        connection.close()


class OpenCLIBridge:
    def __init__(self, data_dir, runtime=None):
        self.home = Path(data_dir).resolve() / 'opencli-home'
        self.runtime = Path(runtime or RUNTIME).resolve()
        self._lock = threading.RLock()
        self._process = None
        self._closed = False

    def _environment(self):
        env = dict(os.environ)
        for key in list(env):
            if key.upper().startswith('OPENCLI_') or key.upper() in {'NODE_OPTIONS', 'NODE_PATH'}:
                env.pop(key)
        env.update(HOME=str(self.home), USERPROFILE=str(self.home),
                   OPENCLI_CONFIG_DIR=str(self.home / '.opencli'),
                   XDG_CONFIG_HOME=str(self.home / '.config'),
                   APPDATA=str(self.home / 'AppData/Roaming'),
                   LOCALAPPDATA=str(self.home / 'AppData/Local'), CI='1')
        return env

    def _view(self, data):
        if data is None:
            return {'state': 'stopped', 'owned': False, 'readOnly': True, 'profiles': []}
        owned = bool(self._process and self._process.poll() is None and self._process.pid == data['pid'])
        profiles = [dict(row) for row in data['profiles'] if row['extensionConnected'] is True]
        return {'state': 'ready' if profiles else 'no-extension', 'owned': owned,
                'readOnly': not owned, 'profiles': profiles, 'pid': data['pid'],
                'daemonVersion': data['daemonVersion'], 'port': PORT}

    def status(self):
        with self._lock:
            return self._view(_read_status())

    def start(self, tenant=None):
        # Compatibility parameter only: isolation is set by constructor data_dir.
        return self.ensure_started()

    def connections(self, tenant=None):
        # Read-only discovery, never starts a daemon or guesses a default profile.
        return [{'id': row['contextId'], 'alive': True,
                 'title': '知乎窗口 ' + row['contextId'], 'url': ''}
                for row in self.status()['profiles']]

    def ensure_started(self, timeout=5):
        """Serialize creation/closure; fixed runtime only, no package installation."""
        with self._lock:
            if self._closed:
                raise OpenCLIBridgeError('OpenCLI管理器已关闭')
            data = _read_status()
            if data is not None:
                return self._view(data)
            if self._process and self._process.poll() is None:
                raise OpenCLIBridgeError('本项目OpenCLI进程仍在启动，尚未返回状态')
            node, script = self.runtime / 'node.exe', self.runtime / 'dist/src/daemon.js'
            if not node.is_file() or not script.is_file():
                raise OpenCLIBridgeError('本项目OpenCLI运行文件尚未装配')
            self.home.mkdir(parents=True, exist_ok=True)
            self._process = subprocess.Popen([str(node), str(script)], shell=False,
                cwd=str(self.runtime), env=self._environment(), stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            deadline = time.monotonic() + min(15, max(0, timeout))
            try:
                while time.monotonic() <= deadline:
                    if self._process.poll() is not None:
                        raise OpenCLIBridgeError('本项目OpenCLI进程启动失败，未替换已有服务')
                    data = _read_status()
                    if data is not None:
                        if data['pid'] != self._process.pid:
                            raise OpenCLIBridgeError('19825端口在启动期间被其他进程占用')
                        return self._view(data)
                    time.sleep(0.1)
                raise OpenCLIBridgeError('本项目OpenCLI启动超时')
            except Exception:
                self._stop_owned()
                raise

    def require_profile(self, context_id, for_write=False):
        """Check exact online context; never uses persisted/default profile aliases."""
        context_id = _context(context_id)
        with self._lock:
            if self._closed:
                raise OpenCLIBridgeError('OpenCLI管理器已关闭')
            data = _read_status(context_id)
            if (data is None or data.get('contextId') != context_id
                    or data.get('extensionConnected') is not True
                    or data.get('profileDisconnected') is True
                    or data.get('profileRequired') is True
                    or not any(p['contextId'] == context_id and p['extensionConnected'] is True for p in data['profiles'])):
                raise OpenCLIBridgeError('指定浏览器配置未连接；不会切换到其他账号')
            view = self._view(data)
            if for_write and view['readOnly']:
                raise OpenCLIBridgeError('现有OpenCLI服务非本项目启动，仅允许只读操作')
            return {**view, 'contextId': context_id, 'cliArgs': ['--profile', context_id]}

    def _stop_owned(self):
        process, self._process = self._process, None
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)

    def close(self):
        with self._lock:
            self._closed = True
            self._stop_owned()
