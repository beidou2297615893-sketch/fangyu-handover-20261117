"""Bounded read seam over the existing guarded platform adapters.

This module never logs in, sends messages, installs tools, changes manifests,
or grants a platform entitlement.  Its host must retain the same instance for
in-flight cancellation.  Operation receipts are volatile, not cross-machine
or restart recovery evidence.  Account status is a stored observation only.
"""
from copy import deepcopy
from contextlib import contextmanager, ExitStack
import hashlib
import json
from pathlib import Path
import re
import shutil
import threading
import time
import unicodedata
from urllib.parse import parse_qs, urlencode, urlsplit
from uuid import uuid4

from .adapters import AdapterAuthRequired, AdapterBusy, AdapterSafetyRequired, PageUnavailable, account_execution_lock
from .page_errors import PageOperationFailure
from . import wechat_channels

READ_ACTIONS = {
    'platform_read_self':'self',
    'platform_read_self_status':'self_status',
    'platform_read_search': 'search', 'platform_read_comments': 'comments',
    'platform_read_content': 'content', 'platform_read_status': 'status',
    'platform_read_cancel': 'cancel',
}
ROUTES = {
    'xiaohongshu': ('search', 'comments', 'content'),
    'douyin': ('search', 'comments'), 'zhihu': ('search', 'comments'),
    'weibo': ('search', 'comments'),  # Candidate only; production guard/license still hold.
    'wechat_channels': ('search', 'comments'), 'kuaishou': ('comments',),
    # Only the fixed local helper is routed; no install or browser-cookie fallback.
    'bilibili': ('search','comments'),
}
_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9:_-]{0,255}')
_REQUEST = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{7,127}')
_MAX_PAGE_BYTES = 1024 * 1024
_MAX_CACHE_BYTES = 8 * 1024 * 1024
_STATES = {'ready', 'unverified', 'connected_unverified', 'login_required', 'expired',
           'credential_present', 'session_recovery_required', 'identity_unverified',
           'duplicate_identity', 'logging_in'}
_MESSAGES = {
    'completed': '已读取本批来源；不代表客户意向或成交已确认。',
    'cancelled': '本地读取结果已取消；已发出的只读请求可能仍完成。',
    'policy_blocked': '当前服务端权益未开放此平台。',
    'guard_hold': '现有平台安全门禁已暂停读取，请先核实。',
    'license_pending': '此读取路线的商业使用许可尚未确认。',
    'not_installed': '已配置的读取运行链尚未完整安装或接线。',
    'unsupported': '此平台尚无已接入的此项只读能力。',
    'account_unverified': '账号或会话身份尚未完成此读取路线的核实。',
    'contract_pending': '此读取路线尚未完成原有搜索契约验证。',
    'busy': '此账号已有操作，本次未新增平台读取。',
    'protocol_hold': '读取结果无法可靠关联来源，已暂停且不自动重试。',
    'timeout_hold': '读取超时，已暂停且不自动重试。',
    'read_hold': '读取未完成，需核实原连接；不会自动重试或输出原始异常。',
    'scope_hold': '读取时的员工、设备或许可范围已变化，请先核实原操作。',
}


class ReadAccessError(ValueError):
    mutation_committed = False


class ReadContractError(ValueError):
    pass


def _text(value, maximum, *, empty=False):
    if (not isinstance(value, str) or len(value) > maximum
            or any(ord(c) < 32 or ord(c) == 127 for c in value)
            or (not empty and not value.strip())):
        raise ReadContractError('读取参数或结果不符合约定')
    return value


def _ident(value):
    if not isinstance(value, str) or not _ID.fullmatch(value):
        raise ReadContractError('来源标识缺失或无效')
    return value


def _normalize_display_text(value, maximum):
    """Bound display-only NFKC; retain controls for the archive privacy gate."""
    if not isinstance(value, str) or len(value) > maximum:
        raise ReadContractError('来源显示字段无效')
    value = unicodedata.normalize('NFKC', value)
    if len(value) > maximum:
        raise ReadContractError('来源显示字段无效')
    return value


def _display_text(value, maximum):
    value = _normalize_display_text(value, maximum)
    return re.sub(r'[\x00-\x20\x7f]+', ' ', value).strip()


def _digest(parts):
    return hashlib.sha256(json.dumps(parts, ensure_ascii=False,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()


def source_reference(platform, value):
    """Return a canonical post id and a narrowly accepted source URL.

    Signing context is retained only for the known note/nonce query fields.
    It never participates in the stable source UID.
    """
    _text(value, 2048)
    if platform == 'wechat_channels':
        ref = wechat_channels.video_reference(value)
        oid = ref.get('object_id')
        if not isinstance(oid, str) or not re.fullmatch(r'[0-9]{1,40}', oid):
            raise ReadContractError('视频号需明确作品ID，不能猜测分享链接身份')
        nonce = ref.get('nonce_id', '')
        _text(nonce, 512, empty=True)
        return oid, wechat_channels.reference(oid, nonce)
    try:
        parsed = urlsplit(value)
        if parsed.port or parsed.username or parsed.password:
            raise ValueError
    except ValueError:
        raise ReadContractError('来源地址不安全') from None
    patterns = {
        'xiaohongshu': (('www.xiaohongshu.com', 'xiaohongshu.com'), r'/explore/([A-Za-z0-9_-]{1,160})'),
        'douyin': (('www.douyin.com', 'douyin.com'), r'/video/([0-9]{1,40})'),
        'kuaishou': (('www.kuaishou.com',), r'/short-video/([A-Za-z0-9_-]{1,160})'),
        'zhihu': (('www.zhihu.com',), r'/(?:question/[0-9]+/)?answer/([0-9]{1,40})'),
        'bilibili': (('www.bilibili.com',), r'/video/(BV[A-Za-z0-9]{10})/?'),
    }
    if platform not in patterns:
        raise ReadContractError('未知来源平台')
    hosts, pattern = patterns[platform]
    match = re.fullmatch(pattern, parsed.path)
    if parsed.scheme != 'https' or parsed.hostname not in hosts or not match:
        raise ReadContractError('来源链接与平台不符')
    query = {}
    if platform == 'xiaohongshu':
        for name in ('xsec_token', 'xsec_source'):
            values = parse_qs(parsed.query).get(name, [])
            if values:
                if len(values) != 1:
                    raise ReadContractError('来源上下文无效')
                query[name] = _text(values[0], 512)
    url = 'https://' + hosts[0] + parsed.path
    return match.group(1), url + ('?' + urlencode(query) if query else '')


def normalize_sources(platform, rows, *, _owned_weibo_source=None):
    """All-or-nothing, stable post-scoped identities; no inferred member UID."""
    if not isinstance(rows, list) or len(rows) > 1000:
        raise ReadContractError('读取页超出约定或不是列表')
    if platform == 'weibo':
        # A source URL cannot supply Weibo's numeric MID. Only this private,
        # live owned capability may bind raw id/bid/user to a permalink.
        from assistant.owned_weibo_host import OwnedWeiboSourceAuthority
        if type(_owned_weibo_source) is not OwnedWeiboSourceAuthority:
            raise ReadContractError('微博需可信宿主原帖范围，不能从链接推断正文标识')
        rows = deepcopy(rows)
        _owned_weibo_source.begin(rows)
    result, seen = [], {}
    for row in rows:
        if not isinstance(row, dict) or row.get('platform') != platform:
            raise ReadContractError('来源平台不匹配')
        kind = row.get('source_type')
        if kind not in ('note', 'comment'):
            raise ReadContractError('来源类型不匹配')
        post_id, url = (_owned_weibo_source.reference(row) if platform == 'weibo'
                        else source_reference(platform, row.get('note_url') or row.get('url')))
        if kind == 'note' and row.get('source_id'):
            declared = str(row['source_id'])
            if platform == 'zhihu' and declared.startswith('answer:'):
                declared = declared[7:]
            if declared != post_id:
                raise ReadContractError('正文标识与来源地址不一致')
        ident = _ident(str(row.get('comment_id') or '')) if kind == 'comment' else post_id
        author_id = row.get('author_id') or ''
        if author_id:
            author_id = _ident(str(author_id))
        body = row.get('text', '')
        if not isinstance(body, str) or len(body) > 32000:
            raise ReadContractError('来源正文缺失或过大')
        body = _normalize_display_text(body, 32000)
        # Multiline source text is legitimate; no raw envelope/error is copied.
        item = {
            'platform': platform, 'source_type': kind,
            'source_uid': platform + ':' + _digest([kind, post_id, ident]),
            'post_id': post_id, 'source_id': ident,
            'comment_id': ident if kind == 'comment' else '',
            'url': url, 'text': body,
            'title': _display_text(row.get('title') or body[:100], 1000),
            'author': _display_text(row.get('author') or '', 300),
            'author_id': author_id,
            'author_uid': platform + ':author:' + _digest([author_id]) if author_id else '',
            'author_identity': 'platform_id' if author_id else 'not_provided',
            'region': _text(_normalize_display_text(row.get('region') or '', 200), 200, empty=True),
            'published_at': _text(_normalize_display_text(row.get('published_at') or '', 100), 100, empty=True),
            'parent_id': _text(str(row.get('parent_id') or ''), 256, empty=True),
            'content_status': 'provided' if body else 'not_provided',
            'evidence_level': 'transport_reported',
        }
        prior = seen.get(item['source_uid'])
        if prior is not None:
            # Different valid signing/nonce contexts do not change content
            # identity; preserve the first usable link on an identical source.
            if ({k: v for k, v in prior.items() if k != 'url'}
                    != {k: v for k, v in item.items() if k != 'url'}):
                raise ReadContractError('同页同来源标识对应不同内容')
            continue
        seen[item['source_uid']] = item
        result.append(item)
    if platform == 'weibo':
        _owned_weibo_source.finish()
    return result


def _page_info(task):
    raw = task.get('_page_info')
    raw = raw if isinstance(raw, dict) else {}
    more = raw.get('has_more')
    cursor = raw.get('cursor', '')
    if (more is not None and type(more) is not bool) or not isinstance(cursor, str):
        raise ReadContractError('分页标记无法识别')
    _text(cursor, 512, empty=True)
    return {'has_more': more, 'cursor': cursor,
            'bounded': raw.get('bounded') is True,
            'pagination_verified': more is not None}


def _runtime_present(manifest, operation):
    """Presence only, not authentication or live protocol validation.

    A PATH node executable alone cannot prove a relative CLI script was
    bundled. The host must have resolved its reviewed entry scripts.
    """
    executable = manifest.get('executable')
    if not isinstance(executable, str) or not shutil.which(executable):
        return False
    prefix = manifest.get('prefix_args') or []
    if not isinstance(prefix, list):
        return False
    arguments = list(prefix)
    field = {'search': 'search_args', 'comments': 'comments_args'}.get(operation)
    if field:
        configured = manifest.get(field) or []
        if not isinstance(configured, list):
            return False
        arguments += configured
    for argument in arguments:
        if not isinstance(argument, str):
            return False
        if argument.lower().endswith(('.js', '.mjs', '.cjs')):
            path = Path(argument)
            if not path.is_absolute() or not path.is_file():
                return False
    return True


class PlatformReadService:
    def __init__(self, core, tenant, owner, *, license_policy=None,
                 license_policy_provider=None, execution_guard=None,
                 device_id='', archive_scope_guard=None, retain_search_raw=False,
                 owned_weibo_host=None, douyin_comments_policy=None, wechat_preview_policy=None,
                 owner_archive_scope=None,douyin_search_policy=None,owner_keyword_search_scope=None,owner_channels_preview_scope=None,
                 owner_douyin_scope=None,owner_xhs_request_scope=None):
        if not isinstance(tenant, str) or not tenant or not isinstance(owner, str) or not owner:
            raise ReadAccessError('读取需要固定企业与员工归属')
        self.core, self.tenant, self.owner = core, tenant, owner
        if ((license_policy_provider is not None and not callable(license_policy_provider))
                or (execution_guard is not None and not callable(execution_guard))
                or (archive_scope_guard is not None and not callable(archive_scope_guard))
                or not isinstance(device_id, str) or len(device_id) > 160):
            raise ReadAccessError('读取门禁必须由可信服务端提供')
        self.license_policy = dict(license_policy or {})
        self.license_policy_provider = license_policy_provider
        self.execution_guard = execution_guard
        # Only the authenticated host may provide these. Legacy read-only hosts
        # may omit them, but their receipts cannot be archived as owned evidence.
        self.device_id, self.archive_scope_guard = device_id, archive_scope_guard
        if owner_archive_scope is not None:
            from assistant.self_operating_archive import _OwnerArchiveScope
            if (type(owner_archive_scope) is not _OwnerArchiveScope
                    or owner_archive_scope.core is not core
                    or owner_archive_scope.instance_id != device_id):
                raise ReadAccessError('自营归档需要可信本机实例范围')
        self._owner_archive_scope = owner_archive_scope
        if owner_keyword_search_scope is not None:
            from assistant.owner_single_keyword_search import _OwnerSearchScope
            if type(owner_keyword_search_scope) is not _OwnerSearchScope or owner_keyword_search_scope.core is not core:
                raise ReadAccessError("本人搜索须原私有范围")
        self._owner_keyword_search_scope=owner_keyword_search_scope
        if owner_channels_preview_scope is not None:
            from assistant.owner_channels_read import _OwnerChannelsScope
            if (type(owner_channels_preview_scope) is not _OwnerChannelsScope
                    or owner_channels_preview_scope.core is not core
                    or owner_channels_preview_scope.instance_id()!=device_id):
                raise ReadAccessError('视频号仅接本机 owner v2 exact 私有范围')
        self._owner_channels_preview_scope=owner_channels_preview_scope
        self._owner_channels_preview_archive_scope=None
        if owner_douyin_scope is not None:
            from assistant.owner_douyin_read import _OwnerDouyinScope
            if type(owner_douyin_scope) is not _OwnerDouyinScope or owner_douyin_scope.core is not core:
                raise ReadAccessError('自营抖音须原私有本人范围')
        self._owner_douyin_scope=owner_douyin_scope
        self._owner_douyin_archive_scope=None
        if owner_xhs_request_scope is not None:
            from assistant.self_operating_read import _OwnerXhsRequestScope
            if (type(owner_xhs_request_scope) is not _OwnerXhsRequestScope
                    or owner_xhs_request_scope.core is not core
                    or owner_xhs_request_scope.workspace.instance.check()['selfOperatingRead']['instance_id']!=device_id):
                raise ReadAccessError('本人请求需要固定本机私有范围')
        self._owner_xhs_request_scope=owner_xhs_request_scope
        self._lock, self._operations = threading.RLock(), {}
        # Only the original live _read may lend its exact lease to this thread.
        # Receipt getters never establish this private context.
        self._owned_read_context = threading.local()
        self._cached_bytes = 0
        if type(retain_search_raw) is not bool:
            raise ReadAccessError('原搜索留存只能由可信宿主启用')
        self._retain_search_raw = retain_search_raw
        if owned_weibo_host is not None:
            from assistant.owned_weibo_host import OwnedWeiboHostCandidate
            if type(owned_weibo_host) is not OwnedWeiboHostCandidate:
                raise ReadAccessError('微博原帖能力只能来自可信宿主，不接收JSON或权限标志')
            owned_weibo_host.attach_reads(self)
        self._owned_weibo_host = owned_weibo_host
        if douyin_comments_policy is not None:
            from .douyin_comments_policy import DouyinCommentsPolicy
            if (type(douyin_comments_policy) is not DouyinCommentsPolicy
                    or douyin_comments_policy._server.core is not core):
                raise ReadAccessError('抖音指定视频用途只能由可信原宿主提供')
        self._douyin_comments_policy = douyin_comments_policy
        if douyin_search_policy is not None:
            from .douyin_search_policy import DouyinSearchPolicy
            if type(douyin_search_policy) is not DouyinSearchPolicy or douyin_search_policy._server.core is not core:
                raise ReadAccessError('抖音首作品页用途只能由可信原宿主提供')
        self._douyin_search_policy=douyin_search_policy
        if wechat_preview_policy is not None:
            from .wechat_preview_policy import WechatPreviewPolicy
            if type(wechat_preview_policy) is not WechatPreviewPolicy or wechat_preview_policy._server.core is not core:
                raise ReadAccessError('视频号预览只能由原可信宿主提供')
        self._wechat_preview_policy=wechat_preview_policy

    def _weibo_binding(self, account):
        host = self._owned_weibo_host
        if host is None:
            raise ReadAccessError('微博owned宿主尚未连接')
        parent = host.current_parent_scope()
        if (host._server.core is not self.core or parent.tenant_id != self.tenant
                or parent.owner_id != self.owner or parent.device_id != self.device_id
                or parent.account_id != account['id']):
            raise ReadAccessError('微博当前宿主与原账号范围不一致')
        binding = host.current_binding()
        from core.weibo_read_contract import AccountBinding
        if (type(binding) is not AccountBinding or binding.identity_verified is not True
                or binding.tenant_id != self.tenant or binding.account_id != account['id']
                or binding.account_root != parent.account_root
                or binding.platform_uid != str(account.get('platform_uid') or '')):
            raise ReadAccessError('微博当前子进程身份与选定账号不一致')
        host.live_authority(binding, 'search')
        return binding

    def _weibo_scope_bytes(self, account, operation, *, binding=None):
        """Freeze current child scope privately; never issue scope from old raw."""
        from core.owned_search_post_index import _valid_scope
        current_binding = self._weibo_binding(account)
        if binding is not None and current_binding != binding:
            raise ReadAccessError('微博读取时的子进程身份或凭据已变化')
        binding = current_binding
        scope = self._owned_weibo_host.live_authority(binding, operation)
        if (not _valid_scope(scope) or scope.tenant_id != self.tenant
                or scope.owner_id != self.owner or scope.device_id != self.device_id
                or scope.account_id != account['id'] or scope.account_root != binding.account_root
                or scope.platform_uid != binding.platform_uid
                or scope.credential_sha256 != binding.credential_sha256):
            raise ReadAccessError('微博当前原始凭据或权限范围无法确认')
        frozen = json.dumps({'tenant': scope.tenant_id, 'owner': scope.owner_id,
            'device': scope.device_id, 'account': scope.account_id,
            'root': str(scope.account_root), 'uid': scope.platform_uid,
            'credential_sha256': scope.credential_sha256,
            'permission_revision': scope.permission_revision,
            'identity_verified': binding.identity_verified}, ensure_ascii=False,
            sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
        if not 1 <= len(frozen) <= _MAX_PAGE_BYTES:
            raise ReadAccessError('微博私有范围超出本会话上限')
        return frozen

    def _check_weibo_scope(self, entry, account, operation):
        original = entry.get('_weibo_scope')
        if (type(original) is not bytes or entry.get('_weibo_scope_size') != len(original)
                or self._weibo_scope_bytes(account, operation) != original):
            raise ReadAccessError('微博原读取的身份、凭据或权限范围已变化')
        return original

    def _discard_weibo_scope(self, entry):
        self._cached_bytes -= entry.pop('_weibo_scope_size', 0)
        for name in ('_weibo_scope_pending', '_weibo_scope'):
            entry.pop(name, None)

    def _discard_self_origin(self,entry):
        encoded=entry.pop('_self_origin_anchor',None)
        self._cached_bytes-=entry.pop('_self_origin_anchor_size',0)
        if encoded is not None:
            # Failed/cancelled results cannot retain a registration scope grant.
            try:entry['origin']=json.loads(encoded)['original_origin']
            except (ValueError,TypeError,KeyError):entry['origin']={}

    def _save_self_origin(self,entry,registered,encoded):
        with self._lock:
            if (type(encoded) is not bytes or not 1<=len(encoded)<=_MAX_PAGE_BYTES
                    or entry.get('cancelled') or '_self_origin_anchor' in entry
                    or self._cached_bytes+len(encoded)>_MAX_CACHE_BYTES):
                raise ReadContractError('本人核实原范围已取消或超出本会话上限')
            entry['_self_origin_anchor']=encoded
            entry['_self_origin_anchor_size']=len(encoded)
            self._cached_bytes+=len(encoded)
            entry['origin']=deepcopy(registered)

    def _save_weibo_scope(self, entry, frozen):
        with self._lock:
            if (entry.get('cancelled') or '_weibo_scope_size' in entry
                    or self._cached_bytes + len(frozen) > _MAX_CACHE_BYTES):
                raise ReadContractError('微博私有范围已取消或超出本会话上限')
            entry['_weibo_scope_pending'] = frozen
            entry['_weibo_scope_size'] = len(frozen)
            self._cached_bytes += len(frozen)

    def _weibo_source(self, account, output, *, binding=None):
        from assistant.owned_weibo_host import OwnedWeiboSourceAuthority
        current_binding = self._weibo_binding(account)
        if binding is not None and current_binding != binding:
            raise ReadAccessError('微博原输出不能重授新的子进程范围')
        binding = current_binding
        return OwnedWeiboSourceAuthority.for_trusted_transport(binding, output,
            live_authority=self._owned_weibo_host.live_authority,
            resolve_post=self._owned_weibo_host.resolve_post if output.get('operation') == 'comments' else None)

    def _discard_search_raw(self, entry):
        self._cached_bytes -= entry.pop('_search_raw_size', 0)
        for name in ('_search_raw_pending', '_search_raw', '_search_raw_digest'):
            entry.pop(name, None)

    def _search_raw_sink(self, entry):
        """Server-created task callback, called only by the owned transport mapper."""
        def capture(platform, raw, rows, page):
            with self._lock:
                if entry.get('cancelled') or '_search_raw_size' in entry:
                    raise ReadContractError('原搜索已取消或重复返回，保持暂停')
                output = {'platform': platform, 'operation': 'search', 'raw': raw,
                          'items': rows, 'requested_page': page}
                encoded = json.dumps(output, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False).encode('utf-8')
                if len(encoded) > _MAX_PAGE_BYTES or self._cached_bytes + len(encoded) > _MAX_CACHE_BYTES:
                    raise ReadContractError('原搜索留存超出本会话上限')
                # Pending bytes already count toward the shared RAM budget.
                # They are never a resolvable receipt while the read is running.
                entry['_search_raw_pending'] = encoded
                entry['_search_raw_size'] = len(encoded)
                self._cached_bytes += len(encoded)
        return capture

    @contextmanager
    def owned_search_receipt(self, account_id, request_id, user, device_id):
        """Private successful search snapshot; current scope is checked under lock."""
        if (not isinstance(request_id, str) or not _REQUEST.fullmatch(request_id)
                or not device_id or device_id != self.device_id):
            raise ReadAccessError('原搜索设备或编号需重新核对')
        data = {'account_id': account_id}
        with self._lock:
            saved, account = self._authorize(data, user)
            entry = self._operations.get(request_id)
            result = entry.get('response') if isinstance(entry, dict) else None
            raw_bytes = entry.get('_search_raw') if isinstance(entry, dict) else None
            if (not entry or entry['account_id'] != account_id or entry.get('running')
                    or entry.get('cancelled') or not isinstance(result, dict)
                    or result.get('code') != 'completed' or result.get('action') != 'search'
                    or result.get('operation_id') != entry.get('operation_id')
                    or result.get('platform') != account.get('platform')
                    or result.get('limit_exceeded') is not False or type(raw_bytes) is not bytes):
                raise ReadAccessError('原搜索未确认、已取消或缺少宿主原响应')
            origin = entry.get('origin') or {}
            if (not origin.get('archive_scope_verified') or not self._archive_scope_valid()
                    or not origin.get('account_uid') or self._origin_error(entry, saved, account)
                    or self._availability(account, 'search') != 'ready_for_guarded_read'):
                raise ReadAccessError('原搜索账号、设备、许可或安全门禁已变化')
            if any(item.get('id') != account_id and item.get('platform') == account['platform']
                    and item.get('platform_uid') == origin['account_uid']
                    for item in self.core.store.list('accounts', self.tenant)):
                raise ReadAccessError('原搜索平台身份存在重复账号')
            raw_digest = hashlib.sha256(raw_bytes).hexdigest()
            if raw_digest != entry.get('_search_raw_digest'):
                raise ReadAccessError('原搜索留存需人工核对')
            original_weibo_scope = (self._check_weibo_scope(entry, account, 'search')
                                    if account['platform'] == 'weibo' else None)
            output = json.loads(raw_bytes)
            owned_source = self._weibo_source(account, output) if account['platform'] == 'weibo' else None
            if (output.get('platform') != account['platform'] or output.get('operation') != 'search'
                    or not isinstance(output.get('items'), list)
                    or normalize_sources(account['platform'], output['items'],
                        _owned_weibo_source=owned_source) != result.get('items')):
                raise ReadAccessError('原搜索与公开来源不一致')
            result_digest = _digest(result)
            snapshot = {'request_id': request_id, 'operation_id': entry['operation_id'],
                        'observed_at': entry['observed_at'], 'origin': deepcopy(origin),
                        'result': deepcopy(result), 'result_digest': result_digest,
                        'transport_result': output,
                        'raw_response_sha256': hashlib.sha256(json.dumps(output['raw'], ensure_ascii=False,
                            sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()}
            yield snapshot
            fresh_user, fresh_account = self._authorize(data, user)
            if (entry.get('cancelled') or entry.get('running') or
                    self._origin_error(entry, fresh_user, fresh_account) or not self._archive_scope_valid()
                    or self._availability(fresh_account, 'search') != 'ready_for_guarded_read'
                    or _digest(entry.get('response')) != result_digest
                    or entry.get('_search_raw') != raw_bytes
                    or entry.get('_search_raw_digest') != raw_digest):
                raise ReadAccessError('原搜索提交前来源或授权已变化')
            if owned_source is not None:
                if self._check_weibo_scope(entry, fresh_account, 'search') != original_weibo_scope:
                    raise ReadAccessError('原搜索提交前私有凭据范围已变化')
                # Credential/identity scope is not part of public origin JSON;
                # the same private capability must recheck it after the yield.
                owned_source.finish()

    def _archive_scope_valid(self):
        if not self.device_id or self.archive_scope_guard is None:
            return False
        try: return self.archive_scope_guard() is True
        except Exception: return False

    def _license_digest(self, platform=None, operation=None):
        if platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
            scope=self._owner_channels_preview_scope
            frame,_=scope.check()
            return _digest(['owner_channels_single_local_session_preview_v1',frame['revision']])
        if platform=='douyin' and self._owner_douyin_scope is not None:
            selected=self._owner_douyin_scope.resolve() if operation=='comments' else None
            return _digest(['owner_douyin_connection_video_comments_v1',selected.get('revision') if selected else None])
        try:
            policy = (self.license_policy_provider() if self.license_policy_provider
                      is not None else self.license_policy)
        except Exception:
            policy = None
        if platform=='douyin' and operation=='search' and self._douyin_search_policy is not None:
            selected=self._douyin_search_policy.resolve()
            previous=policy if isinstance(policy,dict) else {}
            return _digest(['douyin_owned_keyword_search_page',previous.get('revision'),
                selected.get('revision') if selected else None])
        if platform == 'wechat_channels' and self._wechat_preview_policy is not None:
            selected=self._wechat_preview_policy.resolve()
            return _digest(['wechat_channels_single_session_preview',selected.get('revision') if selected else None])
        if platform == 'douyin' and self._douyin_comments_policy is not None:
            selected = self._douyin_comments_policy.resolve()
            previous = policy if isinstance(policy, dict) else {}
            return _digest(['douyin_owned_video_comments', previous.get('revision'),
                            selected.get('revision') if selected else None])
        if not isinstance(policy, dict):
            return _digest(['unavailable'])
        # No free-form configuration, credential, or exception is copied.
        revision = policy.get('revision')
        revision = revision if type(revision) in (str, int) else None
        return _digest([{name: policy.get(name) is True for name in sorted(ROUTES)}, revision])

    def _origin(self, user, account, input_digest, operation=None):
        if account['platform']=='wechat_channels' and self._owner_channels_preview_scope is not None:
            scope=self._owner_channels_preview_scope;scope.check(account)
            return {'actor':{k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')},
                'device_id':self.device_id,'account_id':account['id'],'platform':'wechat_channels',
                'account_uid':str(account.get('platform_uid') or ''),
                'account_binding_digest':_digest({k:account.get(k) for k in
                    ('id','tenant_id','cloud_owner','platform','platform_uid','conn_id','status','revision','updated_at')}),
                'connection_digest':_digest([account.get('conn_id') or '']),
                'license_digest':self._license_digest('wechat_channels','comments'),
                'input_digest':input_digest,'archive_scope_verified':False,'read_operation':'comments'}
        actor = {name: user.get(name) for name in
                 ('id', 'tenant_id', 'username', 'role', 'cloud_bound')}
        account_identity = {name: account.get(name) for name in
            ('id', 'tenant_id', 'cloud_owner', 'platform', 'platform_uid', 'conn_id',
             'status', 'revision', 'updated_at')}
        owner_search=(account['platform']=='xiaohongshu' and operation=='search'
                      and self._owner_keyword_search_scope is not None)
        owner_douyin=(account['platform']=='douyin' and operation=='comments' and self._owner_douyin_scope is not None)
        result = {'actor': actor, 'device_id': self.device_id,
                'account_id': account['id'], 'platform': account['platform'],
                'account_uid': str(account.get('platform_uid') or ''),
                'account_binding_digest': _digest(account_identity),
                'connection_digest': _digest([account.get('conn_id') or '']),
                'license_digest': self._license_digest(account['platform'],operation), 'input_digest': input_digest,
                'archive_scope_verified': False if owner_search or owner_douyin else self._archive_scope_valid()}
        if account['platform']=='douyin' and operation=='search' and self._douyin_search_policy is not None:
            result['read_operation']='search'
        if owner_search or owner_douyin:
            result['read_operation']='search' if owner_search else 'comments'
        elif self._owner_archive_scope is not None:
            result['owner_archive_binding'] = self._owner_archive_scope.origin_digest(user, account)
        return result

    def _origin_error(self, entry, user, account):
        if account['platform']=='wechat_channels' and self._owner_channels_preview_scope is not None:
            try:current=self._owner_channels_preview_scope.entry_current(entry,user,account)
            except (ValueError,RuntimeError,OSError):return 'scope_hold'
            return None if current else 'scope_hold'
        if '_owner_douyin_binding' in entry:
            if self._owner_douyin_scope is None:return 'scope_hold'
            try:current=self._owner_douyin_scope.entry_current(entry,user,account)
            except (ValueError,RuntimeError,OSError):return 'scope_hold'
            if not current:return 'scope_hold'
        if account['platform']=='wechat_channels' and self._wechat_preview_policy is not None and '_wechat_preview_origin' in entry:
            from assistant.wechat_preview_service import receipt_current
            if not receipt_current(self,entry,account,self._wechat_preview_policy):return 'scope_hold'
        if account['platform']=='douyin' and self._douyin_comments_policy is not None:
            response=entry.get('response') or {}
            if ('_douyin_comment_origin' in entry or response.get('action')=='comments' and response.get('code')=='completed'):
                from .douyin_owned_comments import receipt_origin_current
                if not receipt_origin_current(self,entry,account,self._douyin_comments_policy):return 'scope_hold'
        if account['platform']=='douyin' and self._douyin_search_policy is not None:
            response=entry.get('response') or {}
            if ('_douyin_search_origin' in entry or response.get('action')=='search' and response.get('code')=='completed'):
                from .douyin_owned_search import receipt_origin_current
                if not receipt_origin_current(self,entry,account,self._douyin_search_policy):return 'scope_hold'
        if entry.get('_owner_keyword_search') is True:
            if self._owner_keyword_search_scope is None:return 'scope_hold'
            try:current=self._owner_keyword_search_scope.entry_current(entry,user,account)
            except (ValueError,RuntimeError,OSError):return 'scope_hold'
            if not current:return 'scope_hold'
        original = entry.get('origin')
        if not isinstance(original, dict):
            return 'scope_hold'
        current = self._origin(user, account, original['input_digest'],original.get('read_operation'))
        if (current['actor'] != original['actor'] or
                current['account_binding_digest'] != original['account_binding_digest']):
            return 'account_unverified'
        if (current.get('owner_archive_binding') != original.get('owner_archive_binding') or
                current['device_id'] != original['device_id'] or
                current['license_digest'] != original['license_digest'] or
                original['archive_scope_verified'] and not current['archive_scope_verified']):
            return 'scope_hold'
        return None

    @contextmanager
    def owned_receipt(self, account_id, request_id, user, device_id):
        """Internal only: lock a completed owned comment receipt through commit.

        Callers must finish their SQLite writes *inside* this context, before
        the surrounding transaction commits. It never starts/retries a read.
        Originals remain volatile; a durable archive receipt owns restart replay.
        """
        if (not isinstance(request_id, str) or not _REQUEST.fullmatch(request_id)
                or not device_id or device_id != self.device_id):
            raise ReadAccessError('原读取设备或编号需重新核对')
        data = {'account_id': account_id}
        with self._lock:
            saved, account = self._authorize(data, user)
            entry = self._operations.get(request_id)
            result = entry.get('response') if isinstance(entry, dict) else None
            if (not entry or entry['account_id'] != account_id or entry.get('running')
                    or entry.get('cancelled') or not isinstance(result, dict)
                    or result.get('code') != 'completed' or result.get('action') != 'comments'
                    or result.get('limit_exceeded') is not False
                    or result.get('archive_available') is not True
                    or result.get('archive_request_id') != request_id
                    or result.get('archive_account_id') != account_id):
                raise ReadAccessError('原评论读取未确认、已取消或不在归档范围')
            origin = entry.get('origin') or {}
            if (not origin.get('archive_scope_verified') or not self._archive_scope_valid()
                    or not origin.get('account_uid') or self._origin_error(entry, saved, account)
                    or self._availability(account, 'comments') != 'ready_for_guarded_read'):
                raise ReadAccessError('原读取账号、设备、许可或安全门禁已变化')
            try: _ident(origin['account_uid'])
            except ReadContractError:
                raise ReadAccessError('原读取平台身份缺少可靠标识') from None
            # This pure duplicate check does not call the older identity helper,
            # which may mutate account status or pause tasks when it rejects.
            if any(item.get('id') != account_id and item.get('platform') == account['platform']
                    and item.get('platform_uid') == origin['account_uid']
                    for item in self.core.store.list('accounts', self.tenant)):
                raise ReadAccessError('原平台身份存在重复账号，归档保持暂停')
            original_weibo_scope = (self._check_weibo_scope(entry, account, 'comments')
                                    if account['platform'] == 'weibo' else None)
            snapshot = {'request_id': request_id, 'operation_id': entry['operation_id'],
                'observed_at': entry['observed_at'], 'origin': deepcopy(origin),
                'result': deepcopy(result), 'result_digest': _digest(result)}
            yield snapshot
            fresh_user, fresh_account = self._authorize(data, user)
            if (entry.get('cancelled') or entry.get('running') or
                    self._origin_error(entry, fresh_user, fresh_account) or
                    not self._archive_scope_valid() or
                    self._availability(fresh_account, 'comments') != 'ready_for_guarded_read'
                    or _digest(entry.get('response')) != snapshot['result_digest']):
                raise ReadAccessError('归档提交前原来源或授权已变化，本批未保存')
            if (original_weibo_scope is not None and
                    self._check_weibo_scope(entry, fresh_account, 'comments') != original_weibo_scope):
                raise ReadAccessError('原评论提交前私有凭据范围已变化')

    @contextmanager
    def owned_douyin_receipt(self,account_id,request_id,user,device_id,scope):
        # Independent sealed local storage: never turn original Dy preview
        # flags into XHS archive authority and never start another read.
        from assistant.owner_douyin_source_archive import _OwnerDouyinArchiveScope
        if (type(scope) is not _OwnerDouyinArchiveScope or scope is not self._owner_douyin_archive_scope
                or scope.reads is not self or scope.instance_id!=device_id
                or device_id!=self.device_id or type(request_id) is not str or not _REQUEST.fullmatch(request_id)):
            raise ReadAccessError('原本人抖音保存范围未绑定')
        with self._lock:
            saved,account=self._authorize({'account_id':account_id},user)
            entry=self._operations.get(request_id)
            if not entry:raise ReadAccessError('原抖音读取编号未确认')
            scope.snapshot_check(entry,saved,account)
            origin=entry.get('origin')
            if (type(origin) is not dict or origin.get('platform')!='douyin'
                    or origin.get('device_id')!=device_id or origin.get('account_id')!=account_id
                    or self._origin_error(entry,saved,account)
                    or self._availability(account,'comments')!='ready_for_guarded_read'):
                raise ReadAccessError('原抖音读取身份或许可已变化')
            snapshot={'request_id':request_id,'operation_id':entry['operation_id'],
                'observed_at':entry['observed_at'],'origin':deepcopy(origin),
                'result':deepcopy(entry['response']),'result_digest':_digest(entry['response'])}
            yield snapshot
            fresh,latest=self._authorize({'account_id':account_id},user)
            if self._operations.get(request_id) is not entry:
                raise ReadAccessError('原抖音读取绑定已变化')
            scope.snapshot_check(entry,fresh,latest)
            if (self._origin_error(entry,fresh,latest)
                    or self._availability(latest,'comments')!='ready_for_guarded_read'
                    or _digest(entry.get('response'))!=snapshot['result_digest']):
                raise ReadAccessError('原抖音来源提交前已变化，本批未保存')

    @contextmanager
    def owned_channels_preview_snapshot(self,account_id,request_id,user,scope):
        # Storage of a bounded local transport preview is a separate exact
        # purpose. It never grants UID identity or the generic archive path.
        from assistant.owner_channels_preview_archive import _OwnerChannelsPreviewArchiveScope
        if (type(scope) is not _OwnerChannelsPreviewArchiveScope
                or scope is not self._owner_channels_preview_archive_scope
                or scope.reads is not self or scope.core is not self.core
                or type(request_id) is not str or not _REQUEST.fullmatch(request_id)):
            raise ReadAccessError('原本人视频号预览保存范围未绑定')
        scope.check()
        context=getattr(scope.service._tls,'context',None)
        if (context is None or context['user']!=user or context['account']['id']!=account_id):
            raise ReadAccessError('本机预览快照缺少原本人保存上下文')
        with self._lock:
            with scope.capture(context['token'],account_id,request_id,user) as snapshot:
                yield snapshot

    def _authorize(self, data, user):
        if not isinstance(user, dict) or not isinstance(user.get('id'), str):
            raise ReadAccessError('读取需要有效员工身份')
        saved = self.core.store.get('users', user['id'])
        identity = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
        if (not isinstance(saved, dict) or saved.get('disabled')
                or any(saved.get(k) != user.get(k) for k in identity)
                or saved.get('tenant_id') != self.tenant or saved.get('username') != self.owner):
            raise ReadAccessError('员工身份或归属已变化')
        account = self.core._get('accounts', data.get('account_id'), self.tenant)
        self.core._account_access(saved, account)
        if account.get('platform') not in ROUTES:
            raise ReadAccessError('此账号平台不在读取范围')
        return saved, account

    @staticmethod
    def _response(platform, action, code, *, operation_id='', items=None, page=None):
        status = ('completed' if code == 'completed' else 'cancelled' if code == 'cancelled'
                  else 'held' if code.endswith('_hold') or code == 'busy' else 'restricted')
        return {'schema_version': 1, 'platform': platform, 'action': action,
                'status': status, 'code': code, 'message': _MESSAGES[code],
                'operation_id': operation_id, 'items': items or [],
                'page': page or {'has_more': None, 'cursor': '', 'bounded': True,
                                'pagination_verified': False},
                'auto_retry': False, 'platform_writes': False,
                'real_platform_verified': False, 'receipt_scope': 'this_process_only',
                'archive_available': False, 'archive_request_id': '', 'archive_account_id': '',
                'reply_target_verified': False}

    def _license_approved(self, platform, operation=None):
        if platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
            if operation!='comments':return False
            try:self._owner_channels_preview_scope.check();return True
            except (ValueError,RuntimeError,OSError):return False
        if platform=='douyin' and self._owner_douyin_scope is not None:
            return operation=='comments' and self._owner_douyin_scope.resolve() is not None
        if platform == 'wechat_channels' and operation in ('search','comments') and self._wechat_preview_policy is not None:
            return self._wechat_preview_policy.resolve() is not None
        if platform == 'douyin' and operation == 'comments' and self._douyin_comments_policy is not None:
            return self._douyin_comments_policy.resolve() is not None
        if platform=='douyin' and operation=='search' and self._douyin_search_policy is not None:
            return self._douyin_search_policy.resolve() is not None
        if self.license_policy_provider is None:
            return self.license_policy.get(platform) is True
        try: policy = self.license_policy_provider()
        except Exception: return False
        return isinstance(policy, dict) and policy.get(platform) is True

    def _read_status_allowed(self,account,operation):
        platform=account['platform']
        if platform=='douyin' and self._owner_douyin_scope is not None:
            return operation=='comments' and account.get('status')=='ready'
        accepted=(('ready',) if platform=='xiaohongshu' or platform=='weibo' and operation!='self'
                  else ('ready','unverified','connected_unverified'))
        if account.get('status') in accepted:return True
        if platform!='bilibili' or account.get('status')!='login_required':return False
        # A confirmed original own binding is a fact, never a permission. The
        # slot remains login_required and every original read guard still runs.
        with self.core.lock:
            current=self.core._get('accounts',account['id'],self.tenant)
            if (current!=account or current.get('cloud_owner')!=self.owner
                    or current.get('requires_review') not in (None,False)
                    or current.get('risk_state') not in (None,'','normal','safe')):
                return False
            from .bilibili_owned_setup import confirmed_bilibili_binding
            return confirmed_bilibili_binding(self.core,current,self.owner,self.device_id) is not None

    def _availability(self, account, operation):
        """Read stored/configured readiness only; never probe a login session."""
        platform = account['platform']
        if platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
            if operation!='comments':return 'unsupported'
            try:
                self._owner_channels_preview_scope.check(account)
                manifest=self.core.adapters.manifest(platform)
                if manifest.get('transport')!='wx_channel_http':return 'not_installed'
                if account.get('status')!='connected_unverified' or not account.get('bound_client_id'):
                    return 'account_unverified'
            except (ValueError,RuntimeError,OSError):return 'guard_hold'
            return 'ready_for_guarded_read'
        owned_self=platform=='weibo' and operation=='self'
        if operation not in ROUTES[platform] and not owned_self:return 'unsupported'
        if platform=='weibo':
            uid=account.get('platform_uid')
            registered=(isinstance(uid,str) and re.fullmatch(r'[1-9][0-9]{0,31}',uid) is not None)
            if owned_self:
                # Unknown UID is precisely what this original self observation
                # may verify. A nonempty invalid stored UID is not unknown.
                if (account.get('status') not in ('ready','unverified','connected_unverified')
                        or not (uid is None or uid=='' or registered)):
                    return 'account_unverified'
            elif account.get('status')!='ready' or not registered:
                return 'account_unverified'
        if not self._license_approved(platform, operation): return 'license_pending'
        try: self.core.require_platform(platform)
        except ValueError: return 'policy_blocked'
        try: self.core._platform_execution_guard(platform)
        except ValueError: return 'guard_hold'
        if self.execution_guard is not None:
            try:
                if self.execution_guard(platform) is False: return 'guard_hold'
            except Exception: return 'guard_hold'
        if platform=='weibo':
            # This route is the owned host, not a generic CLI adapter manifest.
            if self._owned_weibo_host is None:return 'not_installed'
            try:self._owned_weibo_host._require_connected()
            except Exception:return 'guard_hold'
            return 'ready_for_guarded_read'
        manifest = next((m for m in self.core.adapters.manifests() if m['id'] == platform), {})
        if not manifest.get('available'): return 'not_installed'
        if platform=='bilibili':
            from .bilibili_read import configured
            if not configured(manifest):return 'not_installed'
        if platform != 'wechat_channels' and (not manifest.get('isolation_guard') or not _runtime_present(manifest, operation)):
            return 'not_installed'
        if not self._read_status_allowed(account,operation):return 'account_unverified'
        if platform in ('douyin', 'kuaishou', 'zhihu') and not account.get('conn_id'): return 'account_unverified'
        if platform=='douyin' and self._owner_douyin_scope is not None:
            try:self._owner_douyin_scope.check(account)
            except (ValueError,RuntimeError,OSError):return 'scope_hold'
        dy_policy=(self._douyin_comments_policy if operation=='comments' else self._douyin_search_policy if operation=='search' else None)
        if platform=='douyin' and dy_policy is not None:
            uid = account.get('platform_uid')
            if (account.get('status') != 'ready' or type(uid) is not str
                    or re.fullmatch(r'[0-9]{1,160}',uid) is None or not uid.strip('0')):
                return 'account_unverified'
            try:
                from assistant.douyin_connection_service import _binding
                current = _binding(dy_policy._server.assistant_service,account['id'])
                owned = dy_policy._server.account_connections.owned.get(account['id'])
                if current[3] != self.device_id or current[4] != account or not owned or owned['process'].poll() is not None:
                    return 'account_unverified'
            except Exception:return 'guard_hold'
        if platform == 'wechat_channels' and self._wechat_preview_policy is not None:
            if account.get('status')!='connected_unverified' or not account.get('bound_client_id'):
                return 'account_unverified'
            try:
                from assistant.wechat_preview_service import _binding
                current=_binding(self._wechat_preview_policy._server.assistant_service,account['id'])
                if current[3]!=self.device_id or current[4]!=account:return 'scope_hold'
            except Exception:return 'guard_hold'
        if platform == 'zhihu' and not callable(self.core.adapters.profile_checker): return 'not_installed'
        if platform == 'xiaohongshu' and operation == 'content' and self.core.adapters.xhs_page_runtime is not None:
            return 'unsupported'
        if (operation == 'search' and platform != 'wechat_channels' and manifest.get('search_verified') is not True
                and not (platform=='douyin' and self._douyin_search_policy is not None)):
            if platform=='xiaohongshu' and self._owner_keyword_search_scope is not None:
                try:self._owner_keyword_search_scope.check(account)
                except (ValueError,RuntimeError,OSError):return 'contract_pending'
            else:return 'contract_pending'
        return 'ready_for_guarded_read'

    def _owner_xhs_binding(self,saved,account,key):
        scope=self._owner_xhs_request_scope
        if scope is None or scope.reads is not self:raise ReadAccessError('本人请求元数据范围未绑定')
        return scope.binding(saved,account,key)

    def owner_xhs_prepare(self,data,user):
        # A valid original key is captured BEFORE the helper's execution guard.
        # Only this exact private service can later attest a pre-dispatch reject.
        # The pre-existing page purpose keeps its original lifecycle.
        # Only a normal CLI dispatch can create these exact process facts.
        if self.core.adapters.xhs_page_runtime is not None:return None
        saved,account=self._authorize(data,user)
        key=data.get('request_id')
        if type(key) is not str or not _REQUEST.fullmatch(key):raise ReadAccessError('读取需有效的请求编号')
        binding=self._owner_xhs_binding(saved,account,key)
        with self._lock:
            prior=self._operations.get(key)
            if prior is not None:
                if prior.get('_owner_binding')!=binding:raise ReadAccessError('请求编号属于另一本人或账号')
                return None
            if len(self._operations)>=1000:raise ReadAccessError('本会话读取记录已满，请先完成已有请求')
            entry={'account_id':account['id'],'fingerprint':None,'cancelled':False,
                'operation_id':'r22-'+uuid4().hex,'running':False,'_owner_preflight':True,
                '_owner_binding':binding,'_owner_request_id':key}
            from .adapters import _OwnerXhsReadJob
            entry['_owner_job']=_OwnerXhsReadJob(self._owner_xhs_request_scope,self,entry,binding)
            self._operations[key]=entry
            return entry

    def owner_xhs_reject(self,entry):
        # Not a missing lookup inference: trusted dispatcher caught a refusal on
        # this newly reserved exact entry before Adapter/lease dispatch began.
        with self._lock:
            if (self._operations.get(entry.get('_owner_request_id')) is not entry
                    or not entry.get('_owner_preflight')):return
            job=entry['_owner_job']
            if job.adapter_started or job.lease_acquired or job.spawn_attempted or job.process is not None:return
            entry['_owner_preflight']=False
            entry['response']=self._response('xiaohongshu','comments','scope_hold',operation_id=entry['operation_id'])
            job.worker_done=True

    def owner_xhs_metadata(self,action,data,user):
        if (action not in ('owner_xhs_read_status','owner_xhs_read_cancel')
                or type(data) is not dict or set(data)!={'account_id','request_id'}):
            raise ReadAccessError('本人请求核对只接账号与原请求编号')
        saved,account=self._authorize(data,user)
        key=data['request_id']
        if type(key) is not str or not _REQUEST.fullmatch(key):raise ReadAccessError('读取需有效的请求编号')
        binding=self._owner_xhs_binding(saved,account,key)
        job=None
        with self._lock:
            entry=self._operations.get(key)
            if entry is not None and entry.get('_owner_binding')!=binding:
                raise ReadAccessError('请求编号属于另一本人或账号')
            if action=='owner_xhs_read_cancel':
                if entry is None:
                    if len(self._operations)>=1000:raise ReadAccessError('本会话读取记录已满')
                    entry={'account_id':account['id'],'fingerprint':None,'cancelled':True,
                        'operation_id':'','running':False,'_owner_binding':binding,'_owner_request_id':key}
                    self._operations[key]=entry
                else:entry['cancelled']=True
                job=entry.get('_owner_job')
            else:job=entry.get('_owner_job') if entry is not None else None
        if action=='owner_xhs_read_cancel' and job is not None:job.cancel()
        with self._lock:
            clean=job.cleanup_confirmed() if job is not None else False
            state='unknown'
            if job is not None:
                if clean:
                    state=('cancelled' if entry['cancelled'] else 'completed'
                        if isinstance(entry.get('response'),dict) and entry['response'].get('code')=='completed' else 'held')
                elif job.cleanup_pending:state='cleanup_pending'
                elif entry.get('running') or entry.get('_owner_preflight'):state='running'
            return {'purpose':'owner_xhs_comment_request_metadata_v1','request_id':key,
                'state':state,'cleanup_confirmed':clean,'cancel_requested':bool(entry and entry.get('cancelled')),
                'auto_retry':False,'platform_requests_started':False,'result_available':False,'result':None}

    def execute(self, action, data, user):
        if action not in READ_ACTIONS or not isinstance(data, dict):
            raise ReadAccessError('只支持已接入的只读操作')
        operation = READ_ACTIONS[action]
        allowed = {'account_id', 'request_id'}
        if operation == 'search': allowed |= {'keyword', 'cursor', 'page', 'limit'}
        if operation in ('comments', 'content'): allowed |= {'reference', 'cursor', 'page', 'limit'}
        if set(data) - allowed:
            raise ReadAccessError('读取不接收命令、目录、身份或权限参数')
        saved, account = self._authorize(data, user)
        platform = account['platform']
        if operation == 'status':
            state = account.get('status')
            return {'schema_version': 1, 'platform': platform,
                    'stored_status': state if state in _STATES else 'unknown',
                    'status_evidence': 'stored_account_record', 'live_checked': False,
                    'supported_reads': list(ROUTES[platform]), 'dm_supported': False,
                    'platform_writes': False, 'account_uid_known': bool(account.get('platform_uid')),
                    'read_availability': {name: self._availability(account, name)
                                          for name in (('self','search','comments','content')
                                              if platform=='weibo' else ('search','comments','content'))},
                    'readiness_evidence': 'stored_status_and_local_configuration_only',
                    'real_platform_verified': False}
        key = data.get('request_id')
        if not isinstance(key, str) or not _REQUEST.fullmatch(key):
            raise ReadAccessError('读取需有效的请求编号')
        self_status=operation=='self_status'
        if self_status:operation='self'
        if operation=='self' and platform!='weibo':
            return self._response(platform,operation,'unsupported')
        if operation == 'cancel':
            with self._lock:
                entry = self._operations.get(key)
                if entry and entry['account_id'] != account['id']:
                    raise ReadAccessError('请求编号属于另一账号')
                if entry is None:
                    if len(self._operations) >= 1000:
                        raise ReadAccessError('本会话读取记录已满，请先完成已有请求')
                    self._operations[key] = {'account_id': account['id'], 'cancelled': True,
                                             'fingerprint': None, 'operation_id': ''}
                else:
                    entry['cancelled'] = True
                    self._discard_search_raw(entry)
                    self._discard_weibo_scope(entry)
                    self._discard_self_origin(entry)
            if entry and entry.get('running'):
                # Never abort_active: other accounts/jobs belong to other work.
                try: self.core.adapters.cancel(entry['operation_id'])
                except (ValueError, RuntimeError, OSError): pass
            result=self._response(platform, operation, 'cancelled')
            if platform=='wechat_channels' and (self._wechat_preview_policy is not None or self._owner_channels_preview_scope is not None):
                result.update(cancel_requested=True,cleanup_confirmed=not (entry and entry.get('running')))
            return result
        try:
            if operation=='self':
                keyword=reference=cursor=''
                page,limit=1,0
            else:
                limit, page = data.get('limit', 20), data.get('page', 1)
                if type(limit) is not int or not 1 <= limit <= 100 or type(page) is not int or not 1 <= page <= 100:
                    raise ReadContractError('单批数量或页码无效')
                cursor = _text(data.get('cursor', ''), 512, empty=True)
                keyword = _text(data.get('keyword', ''), 200) if operation == 'search' else ''
                if platform == 'weibo' and operation == 'comments':
                    reference = data.get('reference')
                    if not isinstance(reference, str) or not re.fullmatch(r'[1-9][0-9]{0,31}', reference):
                        raise ReadContractError('微博评论仅接收原owned搜索的数字mid')
                else:
                    reference = source_reference(platform, data.get('reference'))[1] if operation != 'search' else ''
                if cursor and not (platform == 'wechat_channels' or operation == 'comments' and platform in ('xiaohongshu', 'douyin')):
                    raise ReadContractError('此只读路线尚未接入游标继续读取')
                if page != 1 and not (operation == 'search' and platform in ('xiaohongshu', 'douyin')):
                    raise ReadContractError('此只读路线尚未接入指定页码')
        except ReadContractError:
            raise ReadAccessError('读取范围参数无效') from None
        fingerprint = _digest([operation, account['id'], keyword, reference, cursor, page, limit])
        with self._lock:
            prior = self._operations.get(key)
            claimed=(platform=='xiaohongshu' and operation=='comments'
                and self.core.adapters.xhs_page_runtime is None
                and self._owner_xhs_request_scope is not None and prior is not None
                and prior.get('_owner_preflight') is True and not prior.get('cancelled'))
            if claimed:
                if prior.get('_owner_binding')!=self._owner_xhs_binding(saved,account,key):
                    raise ReadAccessError('请求编号属于另一本人或账号')
                origin=self._origin(saved,account,fingerprint,operation)
                prior.update(fingerprint=fingerprint,running=True,_owner_preflight=False)
                prior['origin']=origin
                prior['observed_at']=time.time()
                entry=prior
            if prior and not claimed:
                if prior['account_id'] != account['id']:
                    raise ReadAccessError('请求编号属于另一账号')
                if prior['fingerprint'] is not None and prior['fingerprint'] != fingerprint:
                    raise ReadAccessError('同一请求编号不能用于不同读取范围')
                if prior['cancelled']:
                    return self._response(platform, operation, 'cancelled',operation_id=prior['operation_id'])
                if prior['fingerprint'] != fingerprint:
                    raise ReadAccessError('同一请求编号不能用于不同读取范围')
                if 'response' in prior or prior.get('response_hold') is True:
                    if operation=='self':
                        # Replays are reads of the original entry, never another
                        # self observation, even after an unknown result.
                        scope_error=self._origin_error(prior,saved,account)
                        if scope_error:return self._response(platform,operation,scope_error,
                                                             operation_id=prior['operation_id'])
                        if isinstance(prior.get('response'),dict) and prior['response'].get('code')=='completed':
                            try:self._check_weibo_scope(prior,account,'search')
                            except Exception:return self._response(platform,operation,'scope_hold',
                                                                  operation_id=prior['operation_id'])
                        result=(deepcopy(prior['response']) if 'response' in prior else
                                self._response(platform,operation,'protocol_hold',operation_id=prior['operation_id']))
                        result['cached']=True
                        return result
                    if platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
                        # The owner facade alone may publish cached content
                        # under original OS+single-channel live-client checks.
                        return self._response(platform,operation,'scope_hold',operation_id=prior['operation_id'])
                    availability = self._availability(account, operation)
                    if availability != 'ready_for_guarded_read':
                        return self._response(platform, operation, availability,
                                              operation_id=prior['operation_id'])
                    scope_error = self._origin_error(prior, saved, account)
                    if scope_error:
                        return self._response(platform, operation, scope_error,
                                              operation_id=prior['operation_id'])
                    if (platform == 'weibo' and isinstance(prior.get('response'), dict)
                            and prior['response'].get('code') == 'completed'):
                        try: self._check_weibo_scope(prior, account, operation)
                        except Exception:
                            return self._response(platform, operation, 'scope_hold',
                                                  operation_id=prior['operation_id'])
                    result = (deepcopy(prior['response']) if 'response' in prior else
                              self._response(platform, operation, 'protocol_hold', operation_id=prior['operation_id']))
                    result['cached'] = True
                    return result
                return self._response(platform, operation, 'busy',operation_id=prior['operation_id'])
            if not claimed:
                if len(self._operations) >= 1000:
                    raise ReadAccessError('本会话读取记录已满，请先完成已有请求')
                if self_status:
                    # Missing status cannot start/restore an observation. The exact
                    # self key is tombstoned so a late submit stays cancelled.
                    self._operations[key]={'account_id':account['id'],'fingerprint':fingerprint,
                                           'cancelled':True,'operation_id':'','running':False}
                    return self._response(platform,operation,'cancelled')
                entry = {'account_id': account['id'], 'fingerprint': fingerprint,
                         'cancelled': False, 'operation_id': 'r22-' + uuid4().hex, 'running': True}
                entry['origin'] = self._origin(saved, account, fingerprint,operation)
                entry['observed_at'] = time.time()
                self._operations[key] = entry
        ident = entry['operation_id']
        try:
            if platform=='xiaohongshu' and operation=='search' and self._owner_keyword_search_scope is not None:
                self._owner_keyword_search_scope.bind_entry(entry,saved,account)
            if platform=='douyin' and operation=='comments' and self._owner_douyin_scope is not None:
                self._owner_douyin_scope.bind_entry(entry,saved,account)
            if platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
                self._owner_channels_preview_scope.bind_entry(entry,saved,account)
            result = self._read(saved, account, operation, data, entry, keyword, reference, cursor, page, limit)
        except Exception:
            # A lease-release or unexpected post-read failure must not turn a
            # replay into another read or expose transport/config exceptions.
            result = self._response(platform, operation, 'read_hold', operation_id=ident)
        finally:
            with self._lock:
                entry['running'] = False
                if entry.get('_owner_job') is not None:entry['_owner_job'].worker_done=True
        with self._lock:
            if entry['cancelled']:
                result = self._response(platform, operation, 'cancelled', operation_id=ident)
            retain_raw = (operation == 'search' and result.get('code') == 'completed'
                          and result.get('limit_exceeded') is False and not entry['cancelled'])
            if not retain_raw:
                self._discard_search_raw(entry)
            retain_scope = (platform == 'weibo' and result.get('code') == 'completed'
                            and result.get('limit_exceeded') is False and not entry['cancelled'])
            if not retain_scope:
                self._discard_weibo_scope(entry)
            if not (operation=='self' and result.get('code')=='completed' and not entry['cancelled']):
                self._discard_self_origin(entry)
            size = len(json.dumps(result, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
            if size > _MAX_PAGE_BYTES or self._cached_bytes + size > _MAX_CACHE_BYTES:
                result = self._response(platform, operation, 'protocol_hold', operation_id=ident)
                size = len(json.dumps(result, ensure_ascii=False).encode('utf-8'))
                self._discard_search_raw(entry)
                self._discard_weibo_scope(entry)
                self._discard_self_origin(entry)
                retain_raw = False
                retain_scope = False
            raw_bytes = entry.pop('_search_raw_pending', None)
            if retain_raw and raw_bytes is not None:
                entry['_search_raw'] = raw_bytes
                entry['_search_raw_digest'] = hashlib.sha256(raw_bytes).hexdigest()
            scope_bytes = entry.pop('_weibo_scope_pending', None)
            if retain_scope and scope_bytes is not None:
                entry['_weibo_scope'] = scope_bytes
            if self._cached_bytes + size <= _MAX_CACHE_BYTES:
                entry['response'] = deepcopy(result)
                self._cached_bytes += size
            else:
                # The compact tombstone prevents an exhausted cache from
                # retaining another envelope or replaying another read.
                entry['response_hold'] = True
        if (platform=='weibo' and operation=='search' and result.get('code')=='completed'
                and result.get('limit_exceeded') is False):
            try:self._owned_weibo_host.capture_search(key)
            except Exception:
                self.execute('platform_read_cancel',{'account_id':account['id'],'request_id':key},saved)
                return self._response(platform,operation,'protocol_hold',operation_id=ident)
        return result

    def _read(self, user, account, operation, data, entry, keyword, reference, cursor, page, limit):
        platform, ident = account['platform'], entry['operation_id']
        response = lambda code: self._response(platform, operation, code, operation_id=ident)
        availability = self._availability(account, operation)
        if availability != 'ready_for_guarded_read': return response(availability)
        if platform == 'xiaohongshu':
            try: self.core._require_customer_xhs_identity(account, self.tenant)
            except ValueError: return response('account_unverified')
        directory = self.core.store.directory / 'accounts' / self.tenant / account['id']
        task = {'id': ident, '_account_dir': str(directory), '_conn_id': account.get('conn_id'),
                'keywords': [keyword], 'note_url': reference, 'next_cursor': cursor,
                'next_page': page, 'daily_limit': limit, 'max_pages': 1,
                'comment_depth': 'all', 'search_pages': 1}
        owner_job=entry.get('_owner_job')
        if owner_job is not None:task['_owner_xhs_job']=owner_job
        if platform=='bilibili':task['_expected_platform_uid']=account.get('platform_uid') or ''
        if operation == 'search' and self._retain_search_raw:
            task['_owned_search_raw_sink'] = self._search_raw_sink(entry)
        leased, account_context = False, ExitStack()
        owned_context = None
        previous_context = getattr(self._owned_read_context, 'context', None)
        if platform == 'weibo' and previous_context is not None:
            return response('busy')
        try:
            self.core.acquire_account_mode(account['id'], self.tenant, 'collection', ident)
            leased = True
            if owner_job is not None:owner_job.lease_acquired=True;owner_job.mode_released=False
            if platform == 'weibo':
                with self._lock:
                    # _operations is keyed by request_id, not operation_id.
                    if (entry.get('account_id') != account['id'] or not entry.get('running')
                            or not any(value is entry for value in self._operations.values())):
                        raise AdapterBusy('微博读取上下文已失效')
                    owned_context = (entry, threading.get_ident())
                    self._owned_read_context.context = owned_context
            if entry['cancelled']: return response('cancelled')
            # Recheck authoritative identity/rights immediately before transport.
            _, fresh = self._authorize(data, user)
            if (not self._read_status_allowed(fresh,operation) or fresh.get('conn_id') != account.get('conn_id')
                    or fresh.get('platform_uid') != account.get('platform_uid')):
                return response('account_unverified')
            availability = self._availability(fresh, operation)
            if availability != 'ready_for_guarded_read': return response(availability)
            scope_error = self._origin_error(entry, user, fresh)
            if scope_error: return response(scope_error)
            owned_source = None
            original_weibo_scope = None
            if platform == 'weibo':
                account_context.enter_context(account_execution_lock(directory))
                if operation=='self':
                    # Original _read owns this exact lease/TLS/OS lock. Its IPC
                    # child borrows only this owning thread's live entry.
                    observed=self._owned_weibo_host.execute('self',{'request_id':data['request_id']})
                    if entry['cancelled']:return response('cancelled')
                    if (type(observed) is not dict or observed.get('status')!='identity_observed'
                            or observed.get('production_available') is not False
                            or observed.get('real_platform_verified') is not False
                            or observed.get('auto_retry') is not False):
                        return response('read_hold')
                    self._owned_weibo_host._require_connected()
                    current_user,current=self._authorize(data,user)
                    registered_origin=self._origin(current_user,current,entry['fingerprint'])
                    anchor=self._owned_weibo_host._consume_owned_self_origin(entry,data['request_id'],
                        deepcopy(entry['origin']),registered_origin)
                    self._save_self_origin(entry,registered_origin,anchor)
                    # Binding reads the genuine returned identity receipt; a
                    # changed credential cannot be rebound to this observation.
                    self._save_weibo_scope(entry,self._weibo_scope_bytes(current,'search'))
                    result=response('completed')
                    result.update(identity_observed=True,account_uid_known=True,limit_exceeded=False,
                        message='本次本人账号身份已核实；读取许可与客户身份仍须分别核对。')
                    return result
                binding = self._weibo_binding(fresh)
                original_weibo_scope = self._weibo_scope_bytes(fresh, operation, binding=binding)
                if operation == 'comments':
                    # Fail before any child read when the original source is
                    # absent, cancelled, changed or belongs to another scope.
                    self._owned_weibo_host.resolve_post(binding, reference)
                output = self._owned_weibo_host.execute_owned_read(operation,
                    keyword=keyword, numeric_mid=reference, count=limit, _binding=binding)
                if (not isinstance(output, dict) or output.get('operation') != operation
                        or operation == 'comments' and output.get('post_id') != reference):
                    raise ReadContractError('微博owned返回与原操作不一致')
                owned_source = self._weibo_source(fresh, output, binding=binding)
                output = owned_source._owned_output_copy()
                rows = output['items']
                if operation == 'search':
                    if not self._retain_search_raw:
                        raise ReadContractError('微博搜索必须保留原owned响应')
                    task['_owned_search_raw_sink'](platform, output['raw'], rows, output['requested_page'])
                task['_page_info'] = {'has_more': None, 'bounded': True}
            elif platform=='douyin' and operation=='comments' and self._owner_douyin_scope is not None:
                from assistant.owner_douyin_read import owned_comments
                task['comment_depth']='main'
                with owned_comments(self,entry,user,fresh,task,self._owner_douyin_scope):
                    rows=self.core.adapters.comments(platform,task)
                if len(rows)>limit:raise ReadContractError('本人首评论页数量超界')
                task['_page_info']['bounded']=True
            elif platform == 'douyin' and operation == 'comments' and self._douyin_comments_policy is not None:
                from .douyin_owned_comments import owned_comments
                with owned_comments(self,entry,user,fresh,task,self._douyin_comments_policy):
                    rows = self.core.adapters.comments(platform,task)
                task['_page_info']['bounded']=True
            elif platform=='douyin' and operation=='search' and self._douyin_search_policy is not None:
                if limit>20 or cursor or page!=1:return response('protocol_hold')
                from .douyin_owned_search import owned_search
                with owned_search(self,entry,user,fresh,task,self._douyin_search_policy):
                    rows=self.core.adapters.search(platform,task)
            elif platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
                if operation!='comments' or limit>20 or cursor or page!=1:return response('protocol_hold')
                from assistant.owner_channels_read import owned_channels_read
                with owned_channels_read(self,entry,user,fresh,task,self._owner_channels_preview_scope):
                    if self._owner_channels_preview_archive_scope is not None:
                        from assistant.owner_channels_preview_archive import _OwnerChannelsPreviewArchiveScope
                        storage_scope=self._owner_channels_preview_archive_scope
                        if type(storage_scope) is not _OwnerChannelsPreviewArchiveScope:
                            raise ReadAccessError('原本人视频号保存占用范围需核对')
                        # The original manager/account OS lock is now held.
                        # An earlier dispatch check cannot substitute for this.
                        call=task.get('_wechat_preview_call')
                        storage_scope.read_gate(call,entry,user,fresh)
                    rows=self.core.adapters.comments(platform,task)
                    # Validate all observed rows, including unseen rows, before
                    # clipping. No undisplayed body enters receipt/cache/DB/log.
                    all_normalized=normalize_sources(platform,rows)
                    expected_post=source_reference(platform,reference)[0]
                    if any(item['post_id']!=expected_post for item in all_normalized):
                        raise ReadContractError('原视频号作品来源不一致')
                    del all_normalized
                    task['_owner_channels_observed_count']=len(rows)
                    rows=rows[:limit]
                task['_page_info']={'has_more':None,'cursor':'','bounded':True}
            elif platform=='wechat_channels' and self._wechat_preview_policy is not None:
                if limit>20 or cursor or page!=1:return response('protocol_hold')
                from assistant.wechat_preview_service import preview_read
                with preview_read(self,entry,fresh,task,self._wechat_preview_policy):
                    rows=getattr(self.core.adapters,operation)(platform,task)
                rows=rows[:limit]
                task['_page_info']={'has_more':None,'cursor':'','bounded':True}
            elif platform=='bilibili':
                from .bilibili_read import read
                rows=read(self.core.adapters,operation,task)
            elif operation == 'content':
                payload = self.core.adapters.execute(platform, ['read', reference, '--json'], str(directory), ident)
                raw = payload.get('data', payload) if isinstance(payload, dict) else None
                items = raw.get('items') if isinstance(raw, dict) else None
                if not isinstance(items, list) or len(items) != 1:
                    raise ReadContractError('正文读取结果不明确')
                item = items[0]; card = item.get('note_card') if isinstance(item, dict) else None
                post_id, _ = source_reference(platform, reference)
                if not isinstance(card, dict) or str(item.get('id') or card.get('note_id')) != post_id:
                    raise ReadContractError('正文对应另一来源')
                author = card.get('user') if isinstance(card.get('user'), dict) else {}
                rows = [{'platform': platform, 'source_type': 'note', 'url': reference,
                         'text': card.get('desc', ''), 'title': card.get('title', ''),
                         'author': author.get('nickname', ''), 'author_id': author.get('user_id', '')}]
                task['_page_info'] = {'has_more': False, 'bounded': True}
            elif platform=='xiaohongshu' and operation=='search' and self._owner_keyword_search_scope is not None:
                from assistant.owner_single_keyword_search import owned_keyword_search
                with owned_keyword_search(self,entry,user,fresh,task,self._owner_keyword_search_scope):
                    rows=self.core.adapters.search(platform,task)
            else:
                # verification=False is deliberate: do not bypass search_verified.
                rows = getattr(self.core.adapters, operation)(platform, task)
            if entry['cancelled']: return response('cancelled')
            _, fresh = self._authorize(data, user)
            if (not self._read_status_allowed(fresh,operation) or fresh.get('conn_id') != account.get('conn_id')
                    or fresh.get('platform_uid') != account.get('platform_uid')):
                return response('account_unverified')
            availability = self._availability(fresh, operation)
            if availability != 'ready_for_guarded_read': return response(availability)
            scope_error = self._origin_error(entry, user, fresh)
            if scope_error: return response(scope_error)
            result = self._response(platform, operation, 'completed', operation_id=ident,
                                   items=normalize_sources(platform, rows,
                                       _owned_weibo_source=owned_source), page=_page_info(task))
            if operation != 'search':
                expected_post = reference if platform == 'weibo' else source_reference(platform, reference)[0]
                if any(item['post_id'] != expected_post for item in result['items']):
                    raise ReadContractError('评论或正文返回了另一作品的来源')
            if platform=='wechat_channels' and self._wechat_preview_policy is not None:
                result.update(purpose='wechat_channels_single_session_preview',source_verification='transport_reported_only',
                    identity_verified=False,account_isolation=False,account_ready=False)
            if platform=='douyin' and operation=='search' and self._douyin_search_policy is not None:
                result.update(purpose='douyin_owned_keyword_search_page',source_verification='transport_reported_only')
            result['observed_count'] = len(result['items'])
            result['requested_limit'] = limit
            result['limit_exceeded'] = len(result['items']) > limit
            if platform=='wechat_channels' and self._owner_channels_preview_scope is not None:
                from assistant.owner_channels_read import PURPOSE
                result.update(purpose=PURPOSE,authenticated=False,verified=False,identity_verified=False,
                    account_isolation=False,account_ready=False,source_verification='transport_reported_only',
                    observed_count=task['_owner_channels_observed_count'],displayed_count=len(result['items']),
                    limit_exceeded=task['_owner_channels_observed_count']>limit)
            # Authenticated server observation, never a client permission grant.
            # Saving still locks the original and repeats every current check.
            can_archive = (not (platform=='wechat_channels' and (self._wechat_preview_policy is not None or self._owner_channels_preview_scope is not None)) and operation == 'comments' and entry['origin']['archive_scope_verified']
                and ((user.get('cloud_bound') is True and user.get('role') in ('operator', 'admin'))
                     or self._owner_archive_scope is not None
                        and entry['origin'].get('owner_archive_binding')
                        == self._owner_archive_scope.origin_digest(user, fresh))
                and bool(entry['origin']['account_uid']) and 1 <= len(result['items']) <= min(limit, 100)
                and all(item['source_type'] == 'comment' and item['text'].strip()
                        and len(item['text']) <= 3000 for item in result['items']))
            if can_archive:
                try: _ident(entry['origin']['account_uid'])
                except ReadContractError: can_archive = False
            if can_archive:
                result.update(archive_available=True, archive_request_id=data['request_id'],
                              archive_account_id=account['id'])
            if original_weibo_scope is not None:
                if self._weibo_scope_bytes(fresh, operation, binding=binding) != original_weibo_scope:
                    raise ReadAccessError('微博完成前原读取凭据或权限已变化')
                self._save_weibo_scope(entry, original_weibo_scope)
            return result
        except AdapterBusy: return response('busy')
        except AdapterAuthRequired: return response('account_unverified')
        except AdapterSafetyRequired: return response('guard_hold')
        except (TimeoutError,): return response('timeout_hold')
        except (PageUnavailable, PageOperationFailure) as exc:
            return response('timeout_hold' if exc.code in ('timeout', 'connect_timeout') else 'read_hold')
        except (ReadContractError, TypeError, KeyError): return response('protocol_hold')
        except (ValueError, RuntimeError, OSError):
            return response('cancelled' if platform=='wechat_channels' and self._wechat_preview_policy is not None and entry['cancelled'] else 'read_hold')
        finally:
            if operation=='self' and self._owned_weibo_host is not None:
                self._owned_weibo_host._child_state.self_anchor=None
            try:
                account_context.close()
            finally:
                if owned_context is not None:
                    self._owned_read_context.context = previous_context
                if leased and owner_job is not None:
                    if ((not owner_job.spawn_attempted or owner_job.process is not None and owner_job.process_finished)
                            and (not owner_job.lock_entered or owner_job.lock_exited)
                            and (not owner_job.channel_acquired or owner_job.channel_released)):
                        owner_job.mode_released=(self.core.release_account_mode(account['id'],self.tenant,ident) is True)
                elif leased:
                    # A child not yet confirmed dead remains owned and leased.
                    # Existing cancel/close retains it in the job registry.
                    with self.core.adapters.lifecycle_lock:
                        child = self.core.adapters.job_processes.get(ident)
                        child_alive = child is not None and child.poll() is None
                    if not child_alive:
                        self.core.release_account_mode(account['id'], self.tenant, ident)
