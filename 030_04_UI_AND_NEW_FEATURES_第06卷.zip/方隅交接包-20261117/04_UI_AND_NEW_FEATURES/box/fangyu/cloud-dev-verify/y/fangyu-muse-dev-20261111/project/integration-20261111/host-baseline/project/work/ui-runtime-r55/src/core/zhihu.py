"""OpenCLI Zhihu read contracts; explicit profiles, no identity guessing."""
import re
from datetime import datetime

def profile_id(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}',value):
        raise ValueError('请先绑定明确的知乎浏览器窗口')
    return value

def answer_url(value):
    if not isinstance(value,str):raise ValueError('请填写知乎回答完整链接')
    match=re.fullmatch(r'https://www\.zhihu\.com/(?:question/\d+/)?answer/(\d+)(?:[?#][^\s]*)?',value)
    if not match:raise ValueError('请填写知乎回答链接，例如 https://www.zhihu.com/question/问题ID/answer/回答ID')
    return match.group(1)

def search_args(task):
    query=' '.join(task.get('keywords') or []).strip()
    if not query:raise ValueError('请填写知乎检索关键词')
    return ['--profile',profile_id(task.get('_conn_id')),'zhihu','search',query,
            '--type','answer','--limit',str(min(50,max(1,int(task.get('daily_limit',20))))),'-f','json']

def comment_args(task):
    answer_url(task.get('note_url'))
    return ['--profile',profile_id(task.get('_conn_id')),'zhihu','answer-comments',task['note_url'],
            '--limit',str(min(100,max(1,int(task.get('daily_limit',20))))),
            '--replies-limit','10' if task.get('comment_depth','all')=='all' else '0','--order','latest','-f','json']

def map_search(payload):
    if not isinstance(payload,list):raise ValueError('知乎搜索输出结构不匹配，停止导入')
    result=[]
    for row in payload:
        if not isinstance(row,dict) or row.get('type')!='answer':raise ValueError('知乎搜索返回了非回答数据')
        ident=answer_url(row.get('url'))
        if not isinstance(row.get('title'),str):raise ValueError('知乎回答缺少标题')
        result.append({'platform':'zhihu','source_id':'answer:'+ident,'url':row['url'],
                       'title':row['title'],'text':'','author':str(row.get('author') or ''),
                       'author_id':'','published_at':'','source_type':'note','stage':'待核实回答'})
    return result

def map_comments(payload,note_url):
    answer_url(note_url)
    if not isinstance(payload,list):raise ValueError('知乎评论输出结构不匹配，停止导入')
    by_id={}
    for row in payload:
        if not isinstance(row,dict) or not re.fullmatch(r'\d+',str(row.get('id',''))) or not isinstance(row.get('content'),str):
            raise ValueError('知乎评论缺少有效标识或正文')
        ident=str(row['id'])
        if ident in by_id:raise ValueError('知乎评论出现重复标识')
        by_id[ident]=row
    result=[]
    for ident,row in by_id.items():
        parent=str(row.get('parent_id') or '')
        stamp=row.get('created_at');published=''
        if isinstance(stamp,str) and stamp:
            try:published=datetime.fromisoformat(stamp.replace('Z','+00:00')).isoformat(timespec='seconds')
            except ValueError:pass
        if isinstance(stamp,(int,float)) and not isinstance(stamp,bool) and stamp>0:
            try:published=datetime.fromtimestamp(stamp).isoformat(timespec='seconds')
            except (ValueError,OSError,OverflowError):pass
        # OpenCLI currently returns names, not stable member IDs or regions.
        result.append({'platform':'zhihu','source_id':'comment:'+ident,'comment_id':ident,
                       'note_url':note_url,'url':note_url.split('#')[0]+'#comment-'+ident,
                       'title':row['content'][:100],'text':row['content'],'author':str(row.get('author') or ''),
                       'author_id':'','region':'','published_at':published,'source_type':'comment',
                       'stage':'待核实评论','parent_id':parent,'parent_text':by_id.get(parent,{}).get('content',''),
                       'comment_level':2 if parent else 1})
    return result
