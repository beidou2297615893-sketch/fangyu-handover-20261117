"""Freeze a local origin for a future explicit company register operation.

This module never dispatches or queries a company operation. A local upload ACK
has no historical device/environment binding; it is not a company receipt.
"""
from copy import deepcopy
import hashlib
import json
import math
import re
import time

from core import CoreError
from core.contact_journal import KINDS
from .acquisition_operations import AcquisitionOperations, AcquisitionError, HANDOFFS, STATUS_TEXT, _digest
from .business_reconciliation import LocalBusinessReconciliation, BusinessReconciliationError

PREPARE = 'company_handoff_prepare'
GET = 'company_handoff_preparation_get'
ORIGINS = 'company_handoff_preparations'
CONTRACT = 'company_handoff_preparation_v1'
CLOUD_ACTION = 'acquisition_channel_register'
_IDENT = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_MEMBER = re.compile(r'[A-Za-z0-9_.@-]{3,80}\Z')
_ENV = re.compile(r'[A-Za-z0-9_-]{3,100}\Z')
_KEY = re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_UUID = re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z')
_QUALIFICATIONS = frozenset(('unreviewed', 'qualified', 'not_qualified', 'needs_information', 'duplicate', 'existing_customer'))
_ROW_FIELDS = frozenset(('id', 'version', 'tenant_id', 'cloud_owner', 'company_id', 'environment_id', 'device_id',
    'actor_id', 'handoff_id', 'handoff_revision', 'idempotency_key', 'input_hash', 'origin_id', 'state',
    'cloud_idempotency_key', 'expected_cloud_channel_id', 'cloud_payload_hash', 'source_event_id',
    'source_event_kind', 'source_sequence', 'source_payload_hash', 'source_chain_hash', 'source_acked_at',
    'source_window_hash', 'binding_hash', 'created_at', 'record_hash'))


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


def _raw(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _match(value, pattern):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


class CompanyHandoffPreparationError(CoreError):
    def __init__(self, code, message, status=400, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_PREPARATION_' + code
        self.status = status
        self.mutation_committed = mutation_committed


def _fail(code, message, status=400):
    raise CompanyHandoffPreparationError(code, message, status)


class CompanyHandoffPreparation:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access):
        workspace = company.get('managedWorkspace') if isinstance(company, dict) else None
        environment = workspace.get('environment_id') if isinstance(workspace, dict) else None
        company_id = company.get('id') if isinstance(company, dict) else None
        if (not _match(owner, _MEMBER) or not _match(company_id, _IDENT) or not _match(environment, _ENV)
                or not _match(device_id, _IDENT) or not callable(scope_guard) or not callable(lead_access)
                or tenant != 'cloud-' + _raw(environment + '\n' + company_id)[:24]):
            raise ValueError('公司交接准备需要可信员工、企业环境、设备与当前原评论权限')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.company_id, self.environment_id, self.device_id = company_id, environment, device_id
        self._fixed_device = device_id
        self.scope_guard, self.lead_access = scope_guard, lead_access
        self._bridge = LocalBusinessReconciliation(core, tenant, owner, company, device_id=device_id,
            scope_guard=self._scope_ok, lead_access=lead_access, cloud_read=self._no_cloud)

    @staticmethod
    def _no_cloud(*args, **kwargs):
        raise AssertionError('Company preparation has no cloud transport')

    def _scope_ok(self):
        workspace = self.company.get('managedWorkspace')
        return (self.company.get('id') == self.company_id and isinstance(workspace, dict)
            and workspace.get('environment_id') == self.environment_id and self.device_id == self._fixed_device
            and self.scope_guard() is True)

    def _scope(self):
        try:
            valid = self._scope_ok()
        except Exception:
            valid = False
        if not valid:
            _fail('SCOPE_CHANGED', '员工、企业环境或设备范围已变化，请重新打开准备结果', 409)

    def _helper(self):
        return AcquisitionOperations(self.core, self.tenant, self.owner, self.company, lead_access=self.lead_access)

    def _read_state(self, db, handoff_id, user):
        self._scope()
        helper = self._helper()
        try:
            actor = helper._user(db, user)
            if actor.get('username') != self.owner or actor.get('cloud_bound') is not True:
                _fail('FORBIDDEN', '只能核对当前本人有权的交接准备', 403)
            item = helper._row(db, HANDOFFS, handoff_id)
            if (not item or item.get('cloud_owner') != self.owner or item.get('company_id') != self.company_id
                    or item.get('tenant_id') != self.tenant):
                _fail('FORBIDDEN', '交接不存在或不属于当前本人', 403)
            helper._write_access(actor, item)
            item = helper._item(db, handoff_id, actor)
            lead = helper._lead(db, item['lead_id'], actor)
            authorization = helper._current_authorization(db, item)
        except AcquisitionError as error:
            _fail('AUDIT_CONFLICT' if error.code == 'ACQUISITION_AUDIT_CONFLICT' else 'FORBIDDEN',
                '本机交接来源、授权或当前权限需核对', 409 if error.code == 'ACQUISITION_AUDIT_CONFLICT' else 403)
        except CompanyHandoffPreparationError:
            raise
        except (CoreError, ValueError, TypeError, KeyError):
            _fail('FORBIDDEN', '本机交接来源或当前权限已变化', 403)
        if (type(item.get('revision')) is not int or item['revision'] < 1 or item.get('status') not in STATUS_TEXT
                or item.get('qualification') not in _QUALIFICATIONS):
            _fail('AUDIT_CONFLICT', '本机交接版本或状态需核对', 409)
        source = item.get('source')
        matched = (isinstance(source, dict) and lead.get('platform') == 'xiaohongshu'
            and _match(lead.get('author_id'), _IDENT) and _match(lead.get('comment_id'), _IDENT)
            and isinstance(lead.get('text'), str) and bool(lead['text'].strip())
            and all(source.get(key) == lead.get(key) for key in ('platform', 'author_id', 'comment_id', 'task_id'))
            and source.get('original_text_hash') == _digest(lead['text']))
        self._scope()
        return {'actor': deepcopy(actor), 'item': deepcopy(item), 'lead': deepcopy(lead),
            'authorization': deepcopy(authorization), 'source_matched': matched,
            'fingerprint': _hash({'actor': actor, 'item': item, 'lead': lead, 'company': self.company,
                                 'authorization': authorization})}

    def _journal_state(self, db, lead):
        """Freeze the owned lead window and recheck the selected full reply chain.

        This is a same-transaction reread of the mature ContactJournal integrity
        algorithm. The public receipt API is also checked before the write lock.
        """
        rows = db.execute('''SELECT e.*,a.acked_at FROM contact_events e
            LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
            WHERE e.tenant_id=? AND e.cloud_owner=? ORDER BY e.sequence''', (self.tenant, self.owner)).fetchall()
        relevant, decoded = [], {}
        try:
            for row in rows:
                event = json.loads(row['payload'])
                decoded[row['event_id']] = event
                if event.get('lead', {}).get('id') == lead['id']:
                    relevant.append(row)
            if not relevant:
                return {'selected': None, 'hash': _hash([])}
            selected = relevant[-1]
            chain_rows = [row for row in rows if row['reply_id'] == selected['reply_id']]
            for row in {row['event_id']: row for row in relevant + chain_rows}.values():
                event = decoded[row['event_id']]
                previous = db.execute('SELECT chain_hash FROM contact_events WHERE sequence<? ORDER BY sequence DESC LIMIT 1',
                    (row['sequence'],)).fetchone()
                previous = previous['chain_hash'] if previous else '0'*64
                chain = _raw(row['previous_hash']+'\n'+self.tenant+'\n'+self.owner+'\n'+row['event_id']+'\n'+row['payload_hash'])
                if (row['kind'] not in KINDS or event.get('event_id') != row['event_id']
                        or event.get('kind') != row['kind'] or event.get('lead', {}).get('id') != lead['id']
                        or event.get('reply', {}).get('id') != row['reply_id']
                        or _raw(row['payload']) != row['payload_hash'] or _hash(event) != row['payload_hash']
                        or previous != row['previous_hash'] or chain != row['chain_hash']
                        or not _match(row['event_id'], _UUID) or row['provisional'] != 0 or row['syncable'] != 1
                        or (row['acked_at'] is not None and (type(row['acked_at']) not in (int, float)
                            or not math.isfinite(row['acked_at']) or row['acked_at'] < 0))):
                    raise ValueError('owned source chain conflict')
            event = decoded[selected['event_id']]
            exact_source = all(event['lead'].get(key) == str(lead.get(key) or '')
                for key in ('platform', 'author_id', 'comment_id', 'text', 'task_id'))
            public_window = [{key: row[key] for key in ('sequence', 'event_id', 'reply_id', 'kind',
                'payload_hash', 'previous_hash', 'chain_hash', 'acked_at')} for row in relevant +
                [entry for entry in chain_rows if entry not in relevant]]
            return {'selected': dict(selected), 'event': event, 'exact_source': exact_source, 'hash': _hash(public_window)}
        except (ValueError, TypeError, KeyError):
            _fail('AUDIT_CONFLICT', '本人不可变来源或完整联系链需核对，未继续准备', 409)

    def _record_id(self, handoff_id):
        return _hash(['company-handoff-preparation-v1', self.tenant, self.company_id, self.owner, handoff_id])

    def _row(self, db, handoff_id):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (ORIGINS, self._record_id(handoff_id), self.tenant)).fetchone()
        if not row:
            return None
        try:
            value = json.loads(row['body'])
            unsigned = {key: entry for key, entry in value.items() if key != 'record_hash'}
            if (set(value) != _ROW_FIELDS or value['record_hash'] != _hash(unsigned) or value['version'] != 1
                    or value['id'] != self._record_id(handoff_id) or value['handoff_id'] != handoff_id
                    or value['tenant_id'] != self.tenant or value['cloud_owner'] != self.owner
                    or value['company_id'] != self.company_id or value['environment_id'] != self.environment_id
                    or value['device_id'] != self.device_id):
                raise ValueError('origin scope or integrity conflict')
            if value['state'] != 'prepared':
                _fail('ORIGIN_STATE_UNKNOWN', '原准备状态需核对，不能改编号重新准备', 409)
            for field in ('origin_id', 'cloud_idempotency_key', 'cloud_payload_hash', 'input_hash',
                          'source_payload_hash', 'source_chain_hash', 'source_window_hash', 'binding_hash'):
                if not _match(value[field], _HEX):
                    raise ValueError('origin digest invalid')
            origin_id = _hash(['company-handoff-prepare-v1', self.tenant, self.company_id, self.owner, value['idempotency_key']])
            cloud_key = _hash(['company-handoff-cloud-register-v1', origin_id])
            if (not _match(value['idempotency_key'], _KEY) or value['origin_id'] != origin_id
                    or value['cloud_idempotency_key'] != cloud_key
                    or value['expected_cloud_channel_id'] != 'hc_'+_hash([self.company_id, self.owner, CLOUD_ACTION, cloud_key])
                    or value['source_event_kind'] not in KINDS or not _match(value['source_event_id'], _UUID)
                    or type(value['handoff_revision']) is not int or value['handoff_revision'] < 1
                    or type(value['source_sequence']) is not int or value['source_sequence'] < 1
                    or type(value['created_at']) is not int or value['created_at'] < 0
                    or type(value['source_acked_at']) not in (int, float) or not math.isfinite(value['source_acked_at'])
                    or value['source_acked_at'] < 0):
                raise ValueError('origin record invalid')
            return value
        except CompanyHandoffPreparationError:
            raise
        except (ValueError, KeyError, TypeError):
            _fail('ORIGIN_CONFLICT', '原准备范围或完整性需核对，不能更换编号继续', 409)

    def _cloud_payload(self, snapshot, event_id, key):
        item, lead = snapshot['item'], snapshot['lead']
        consent = item.get('consent') or {}
        return {'environment_id': self.environment_id, 'operation': CLOUD_ACTION,
            'source_event_id': event_id, 'recipient_id': item['recipient_id'], 'purpose': item['purpose'],
            'consent': {field: consent.get(field) for field in ('status', 'evidence_reference', 'notice_version')},
            'contact_reference': 'platform:'+lead['platform']+':'+lead['author_id'],
            'qualification': 'qualified', 'idempotency_key': key}

    def _binding(self, snapshot):
        return _hash({'item': snapshot['item'], 'lead': snapshot['lead']})

    def _blocked(self, snapshot, window, origin):
        item = snapshot['item']
        if not origin:
            return 'not_prepared'
        if item['status'] != 'ready_to_deliver':
            return 'handoff_not_ready'
        if item['qualification'] != 'qualified':
            return 'not_qualified'
        if snapshot['authorization']['state'] != 'granted':
            return 'consent_unavailable'
        if not snapshot['source_matched']:
            return 'source_changed'
        selected = window['selected']
        if not selected:
            return 'source_unavailable'
        if not window['exact_source']:
            return 'source_changed'
        if selected['acked_at'] is None:
            return 'source_ack_missing'
        if (item['revision'] != origin['handoff_revision'] or self._binding(snapshot) != origin['binding_hash']
                or window['hash'] != origin['source_window_hash'] or selected['event_id'] != origin['source_event_id']
                or _hash(self._cloud_payload(snapshot, origin['source_event_id'], origin['cloud_idempotency_key'])) != origin['cloud_payload_hash']):
            return 'source_changed'
        return None

    def _result(self, snapshot, window, origin, *, read_only, replayed=False):
        blocked = self._blocked(snapshot, window, origin)
        source_state = ('changed' if blocked == 'source_changed' else 'unavailable'
            if not snapshot['source_matched'] or not window['selected'] or not window.get('exact_source') else 'matched')
        return {'contract': CONTRACT, 'local_only': True, 'storage_scope': 'this_device', 'cross_machine_verified': False,
            'operation_action': PREPARE, 'idempotency_key': origin['idempotency_key'] if origin else None,
            'operation_id': origin['origin_id'] if origin else None, 'state': 'prepared' if origin else 'not_prepared',
            'origin': ({'origin_id': origin['origin_id'], 'local_handoff_revision': origin['handoff_revision'],
                'cloud_operation_action': CLOUD_ACTION, 'cloud_idempotency_key': origin['cloud_idempotency_key'],
                'expected_cloud_channel_id': origin['expected_cloud_channel_id'], 'cloud_payload_hash': origin['cloud_payload_hash'],
                'source_event_kind': origin['source_event_kind'], 'source_ack_recorded': True,
                'source_cloud_binding_verified': False, 'created_at': origin['created_at']} if origin else None),
            'current': {'handoff_id': snapshot['item']['id'], 'revision': snapshot['item']['revision'],
                'status': snapshot['item']['status'], 'qualification': snapshot['item']['qualification'],
                'consent_state': snapshot['authorization']['state'], 'source_state': source_state,
                'preparation_usable': origin is not None and blocked is None, 'blocked_reason': blocked},
            'read_only': read_only, 'mutation_committed': not read_only, 'replayed': replayed, 'refresh_required': True,
            'no_dispatch': True, 'no_dispatch_scope': 'this_preparation_only', 'previous_company_dispatch_status': 'unknown',
            'cloud_requests_started': False, 'platform_requests_started': False, 'provider_requests_started': False,
            'contacts_modified': False, 'handoffs_modified': False, 'ratings_modified': False, 'auto_retry': False}

    def _get(self, handoff_id, user):
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN')
            snapshot = self._read_state(db, handoff_id, user)
            origin = self._row(db, handoff_id)
            window = self._journal_state(db, snapshot['lead'])
            if origin and origin['actor_id'] != snapshot['actor']['id']:
                _fail('ORIGIN_CONFLICT', '原准备主体已变化，不能按新身份接续', 409)
        # Fresh connection sees changes committed during the first read.
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN')
            after = self._read_state(db, handoff_id, user)
            fresh_origin = self._row(db, handoff_id)
            fresh_window = self._journal_state(db, after['lead'])
        self._scope()
        if (after['fingerprint'] != snapshot['fingerprint'] or fresh_window['hash'] != window['hash'] or fresh_origin != origin):
            _fail('CURRENT_CHANGED', '来源、授权或准备记录读取期间已变化，请重新核对', 409)
        return self._result(after, fresh_window, fresh_origin, read_only=True)

    @staticmethod
    def _commit(db):
        db.commit()

    def _prepare(self, data, user):
        handoff_id = data['handoff_id']
        # Mature exact source and full ContactJournal receipt before the write lock.
        try:
            self._bridge._snapshot(handoff_id, user)
        except BusinessReconciliationError as error:
            _fail('SOURCE_CHANGED' if error.code.endswith('SOURCE_CONFLICT') else 'FORBIDDEN',
                '原评论身份、版本或当前权限需核对，未继续准备', 409 if error.status == 409 else 403)
        # Existing origins, including unreadable states, are never bypassed by
        # a new key. Replays are validated again under the SQLite write lock.
        self._get(handoff_id, user)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN')
            snapshot = self._read_state(db, handoff_id, user)
            window = self._journal_state(db, snapshot['lead'])
        selected = window['selected']
        if selected:
            try:
                self._bridge._owned_event(selected['event_id'], snapshot)
            except BusinessReconciliationError:
                _fail('AUDIT_CONFLICT', '本人不可变来源与完整联系链需核对，未继续准备', 409)
        commit_attempted = False
        try:
            with self.core.lock, self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                fresh = self._read_state(db, handoff_id, user)
                fresh_window = self._journal_state(db, fresh['lead'])
                if fresh['fingerprint'] != snapshot['fingerprint'] or fresh_window['hash'] != window['hash']:
                    _fail('CURRENT_CHANGED', '来源、授权或版本准备期间已变化，未保存新准备', 409)
                origin = self._row(db, handoff_id)
                if origin:
                    if (origin['idempotency_key'] != data['idempotency_key'] or origin['actor_id'] != fresh['actor']['id']):
                        _fail('ORIGIN_EXISTS', '此交接已有原准备，请读取原结果，不能换编号重新准备', 409)
                    if origin['input_hash'] != _hash(data):
                        _fail('IDEMPOTENCY_CONFLICT', '原准备编号的输入已变化，请先读取原结果', 409)
                    replayed = True
                else:
                    for row in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (ORIGINS, self.tenant)):
                        other = json.loads(row['body'])
                        if other.get('cloud_owner') == self.owner and other.get('idempotency_key') == data['idempotency_key']:
                            _fail('IDEMPOTENCY_CONFLICT', '原准备编号已绑定另一交接，不能复用', 409)
                    item = fresh['item']
                    if item['revision'] != data['expected_revision']:
                        _fail('REVISION_CONFLICT', '交接版本已变化，请读取最新版本后再准备', 409)
                    if item['status'] != 'ready_to_deliver' or item['qualification'] != 'qualified':
                        _fail('NOT_READY', '请先核对有效性并将本机交接整理为待送达', 409)
                    if fresh['authorization']['state'] != 'granted':
                        _fail('CONSENT_REQUIRED', '当前客户授权已撤回或待核对，未继续准备', 409)
                    if not fresh['source_matched'] or not selected or not window.get('exact_source'):
                        _fail('SOURCE_REQUIRED', '请先保存与当前原评论身份和正文一致的本人来源事件', 409)
                    if item['contact_reference'] != 'platform:'+fresh['lead']['platform']+':'+fresh['lead']['author_id']:
                        _fail('CONTACT_UNSUPPORTED', '公司交接准备目前只支持原平台身份，本机联系方式不能跨电脑传递', 409)
                    if selected['acked_at'] is None:
                        _fail('SOURCE_ACK_REQUIRED', '最新本人来源尚未归档，请先归档来源后再准备', 409)
                    origin_id = _hash(['company-handoff-prepare-v1', self.tenant, self.company_id, self.owner, data['idempotency_key']])
                    cloud_key = _hash(['company-handoff-cloud-register-v1', origin_id])
                    origin = {'id': self._record_id(handoff_id), 'version': 1, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                        'company_id': self.company_id, 'environment_id': self.environment_id, 'device_id': self.device_id,
                        'actor_id': fresh['actor']['id'], 'handoff_id': handoff_id, 'handoff_revision': item['revision'],
                        'idempotency_key': data['idempotency_key'], 'input_hash': _hash(data), 'origin_id': origin_id, 'state': 'prepared',
                        'cloud_idempotency_key': cloud_key, 'expected_cloud_channel_id': 'hc_'+_hash([self.company_id, self.owner, CLOUD_ACTION, cloud_key]),
                        'cloud_payload_hash': _hash(self._cloud_payload(fresh, selected['event_id'], cloud_key)),
                        'source_event_id': selected['event_id'], 'source_event_kind': selected['kind'], 'source_sequence': selected['sequence'],
                        'source_payload_hash': selected['payload_hash'], 'source_chain_hash': selected['chain_hash'],
                        'source_acked_at': selected['acked_at'], 'source_window_hash': fresh_window['hash'],
                        'binding_hash': self._binding(fresh), 'created_at': int(time.time())}
                    origin['record_hash'] = _hash(origin)
                    db.execute('INSERT INTO records VALUES(?,?,?,?)', (ORIGINS, origin['id'], self.tenant, _json(origin)))
                    replayed = False
                check = self._read_state(db, handoff_id, user)
                check_window = self._journal_state(db, check['lead'])
                if check['fingerprint'] != fresh['fingerprint'] or check_window['hash'] != fresh_window['hash']:
                    _fail('CURRENT_CHANGED', '来源或授权准备期间已变化，未保存新准备', 409)
                self._scope()
                commit_attempted = True
                self._commit(db)
            # A committed local origin cannot be called uncommitted after a late race.
            confirmed = self._get(handoff_id, user)
            with self.core.lock, self.core.store.connect() as db:
                post = self._read_state(db, handoff_id, user)
                post_window = self._journal_state(db, post['lead'])
            if (post['fingerprint'] != fresh['fingerprint'] or post_window['hash'] != fresh_window['hash']
                    or confirmed['operation_id'] != origin['origin_id']):
                _fail('CURRENT_CHANGED', '本机原准备可能已保存，当前来源已变化，请读取原结果', 409)
            self._scope()
            return self._result(post, post_window, origin, read_only=False, replayed=replayed)
        except CompanyHandoffPreparationError as error:
            if commit_attempted:
                error.mutation_committed = None
            raise
        except Exception:
            raise CompanyHandoffPreparationError('RESULT_UNKNOWN' if commit_attempted else 'SAVE_FAILED',
                '本机准备结果暂不确定，请按原交接读取准备结果' if commit_attempted else '本机准备暂不可用，未保存新准备',
                409 if commit_attempted else 503, None if commit_attempted else False) from None

    def execute(self, action, data, user):
        allowed = {'handoff_id', 'expected_revision', 'idempotency_key'} if action == PREPARE else {'handoff_id'}
        if (action not in (PREPARE, GET) or not isinstance(data, dict) or set(data) != allowed
                or not _match(data.get('handoff_id'), _HANDOFF)
                or (action == PREPARE and (type(data.get('expected_revision')) is not int
                    or not 1 <= data['expected_revision'] <= 9007199254740991 or not _match(data.get('idempotency_key'), _KEY)))):
            _fail('INVALID_INPUT', '准备参数无效；企业、设备、来源与云编号由本机可信记录核对')
        self._scope()
        return self._prepare(deepcopy(data), user) if action == PREPARE else self._get(data['handoff_id'], user)
