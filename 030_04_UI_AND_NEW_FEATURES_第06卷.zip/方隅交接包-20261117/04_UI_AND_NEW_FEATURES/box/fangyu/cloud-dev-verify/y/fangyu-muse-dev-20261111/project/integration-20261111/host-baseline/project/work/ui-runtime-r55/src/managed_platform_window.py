"""Owned platform window. Profiles and bridge transport stay inside this instance."""
import json, sys, urllib.request, threading
from pathlib import Path
from urllib.parse import urlparse

class Relay:
    def __init__(self, config, platform, state_path=None):
        self._bridge=config['bridge'];self._platform=platform;self._window=None;self._state_path=state_path
    def dispatch(self, options, request_id, document_id):
        # pywebview recreates its Promise callback table after navigation. Keep
        # long-poll delivery outside that table and never deliver across documents.
        if not isinstance(request_id,str) or len(request_id)>100 or not isinstance(document_id,str) or len(document_id)>100:
            raise ValueError('无效连接请求标识')
        def work():
            try:payload={'ok':True,'value':self.request(options)}
            except Exception as exc:payload={'ok':False,'error':str(exc)}
            js="(function(){var r=window.__workbenchRelay;if(r&&r.documentId==="+json.dumps(document_id)+"){var f=r.pending["+json.dumps(request_id)+"];if(f)f("+json.dumps(payload,ensure_ascii=True)+");}})()"
            try:self._window.evaluate_js(js)
            except Exception:pass  # Closed or replaced documents own no callbacks.
        threading.Thread(target=work,daemon=True).start()
        return None
    def request(self, options):
        origin=urlparse(self._window.get_current_url() or '')
        if origin.scheme!='https' or origin.hostname!='www.'+self._platform+'.com':
            raise ValueError('平台页面已离开，请返回平台首页')
        url=urlparse(str(options.get('url','')))
        allowed={'/api/connect','/api/poll','/api/result','/api/disconnect','/api/update'}
        if url.hostname!='127.0.0.1' or url.port!=self._bridge['port'] or url.path not in allowed:
            raise ValueError('不允许此连接请求')
        method=options.get('method','GET').upper()
        if method not in ('GET','POST'):raise ValueError('请求方法无效')
        raw=options.get('data');data=str(raw).encode() if raw is not None else None
        if data and len(data)>2097152:raise ValueError('请求过大')
        req=urllib.request.Request(url.geturl(),data=data,method=method,headers={'Content-Type':'application/json','Authorization':'Bearer '+self._bridge['token']})
        with urllib.request.urlopen(req,timeout=36 if url.path=='/api/poll' else 10) as response:
            text=response.read(4194304).decode('utf-8')
            if url.path=='/api/connect' and response.status==200 and self._state_path:
                ident=json.loads(text).get('id')
                if ident:
                    path=Path(self._state_path);temp=path.with_suffix('.tmp')
                    temp.write_text(json.dumps({'conn_id':ident}),'utf-8');temp.replace(path)
            return {'status':response.status,'responseText':text}

def injection(script, marker):
    # No bridge secret is exposed to the remote page; the relay adds it natively.
    script=script.replace("url: location.href", "url: location.href + "+json.dumps('#workbench-account='+marker))
    prefix="""if (!window.__workbenchManaged) { window.__workbenchManaged=true;
var unsafeWindow=window;
var relayState=window.__workbenchRelay={documentId:Date.now()+':'+Math.random(),pending:{},serial:0};
var GM_xmlhttpRequest=function(options){
 var serial={url:options.url,method:options.method||'GET',data:options.data};
 var id=String(++relayState.serial),done=false;
 var timer=setTimeout(function(){finish({ok:false,error:'连接请求超时'},true)},String(options.url).indexOf('/api/poll')>=0?(options.timeout||35000):10000);
 function finish(r,timedOut){if(done)return;done=true;clearTimeout(timer);delete relayState.pending[id];
  if(r.ok){options.onload&&options.onload(r.value)}else if(timedOut&&options.ontimeout){options.ontimeout()}else{options.onerror&&options.onerror(r.error)}
 }
 relayState.pending[id]=finish;
 try{window.pywebview.api.dispatch(serial,id,relayState.documentId).catch(function(e){finish({ok:false,error:String(e)})})}catch(e){finish({ok:false,error:String(e)})}
};
"""
    return prefix+script+'\n}'

def main(spec_path=None):
    entry=Path(spec_path or sys.argv[1])
    if json.loads(entry.read_text('utf-8')).get('window_kind')=='livestream-child/1':
        import hashlib
        source=Path(__file__).with_name('managed_live_window.py')
        body=source.read_bytes()
        if not source.is_file() or source.is_symlink() or hashlib.sha256(body).hexdigest()!='2e7f564f3a440ed6372a7d97b10fa20b0fe3f1b1678e191a728f1a48346a9682':raise ValueError('直播窗口组件版本未核对')
        namespace={'__file__':str(source),'__name__':'fangyu_managed_live_child'}
        exec(compile(body,str(source),'exec'),namespace)
        return namespace['main'](entry)
    import webview
    spec=json.loads(Path(spec_path or sys.argv[1]).read_text('utf-8'))
    config=json.loads(Path(spec['config']).read_text('utf-8'))
    raw=Path(spec['script']).read_text('utf-8')
    token=config['bridge']['token'];raw=raw.replace(token,'')
    relay=Relay(config,spec['platform'],spec.get('state_path'))
    window=webview.create_window('登录'+('抖音' if spec['platform']=='douyin' else '快手')+' · '+spec['name'], 'https://www.'+spec['platform']+'.com/',js_api=relay,width=1180,height=820)
    relay._window=window
    def loaded():
        current=urlparse(window.get_current_url() or '')
        if current.scheme=='https' and current.hostname=='www.'+spec['platform']+'.com':
            window.evaluate_js(injection(raw,spec['marker']))
    window.events.loaded+=loaded
    webview.start(gui='edgechromium',private_mode=False,storage_path=spec['profile'])
if __name__=='__main__':main()
