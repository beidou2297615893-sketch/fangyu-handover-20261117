"""Offline-ready coordinator for a candidate browser session.

This module neither reads a browser nor invokes a platform, cloud, or Core API.
The caller supplies those operations and owns the account/channel/process locks.
Callbacks must never log or return credentials.  Only fixed result codes escape.
"""

from dataclasses import dataclass
from typing import Callable, Mapping, Any
import json
import math
from pathlib import Path
import tempfile
import time
from core.engine import evaluate_xhs_identity


@dataclass(frozen=True)
class LoginResult:
    state: str
    code: str
    cleanup_code: str = ''


class CookieCandidateError(RuntimeError):
    """A fixed code only; filesystem paths and credentials never escape."""


# Exact mirror of pinned xhs_cli.qr_login.BROWSER_EXPORT_COOKIE_NAMES.
_COOKIE_NAMES = frozenset({
    'a1', 'webId', 'web_session', 'web_session_sec', 'id_token',
    'websectiga', 'sec_poison_id', 'xsecappid', 'gid',
    'abRequestId', 'webBuild', 'loadts',
})
_REQUIRED_NAMES = frozenset({'a1', 'webId', 'web_session'})


class CookieCandidate:
    """Temporary isolated HOME for the pinned CLI's status command."""

    def __init__(self, parent: Path, cookies: Mapping[str, str], now: float | None = None):
        if (not isinstance(cookies, Mapping) or not _REQUIRED_NAMES.issubset(cookies)
                or not set(cookies).issubset(_COOKIE_NAMES)):
            raise CookieCandidateError('candidate_invalid')
        clean = {}
        total_bytes = 0
        for key, value in cookies.items():
            if (not isinstance(key, str) or not isinstance(value, str)
                    or not value or any(ord(ch) < 32 or ord(ch) == 127 or ch == ';' for ch in value)):
                raise CookieCandidateError('candidate_invalid')
            try:
                size = len(value.encode('utf-8'))
            except UnicodeError:
                raise CookieCandidateError('candidate_invalid') from None
            total_bytes += len(key.encode('utf-8')) + size
            if size > 8192 or total_bytes > 32768:
                raise CookieCandidateError('candidate_invalid')
            clean[key] = value
        saved_at = time.time() if now is None else now
        if type(saved_at) not in (int, float) or not math.isfinite(saved_at):
            raise CookieCandidateError('candidate_invalid')
        # The caller must choose a private per-installation work directory.
        # The candidate never touches the account's active HOME.
        try:
            self._tempdir = tempfile.TemporaryDirectory(prefix='browser-candidate-', dir=parent)
            self.root = Path(self._tempdir.name)
            config = self.root / '.xiaohongshu-cli'
            config.mkdir()
            cookie_file = config / 'cookies.json'
            with cookie_file.open('x', encoding='utf-8') as stream:
                json.dump({**clean, 'saved_at': saved_at}, stream)
            cookie_file.chmod(0o600)
        except Exception:
            if hasattr(self, '_tempdir'):
                try:
                    self._tempdir.cleanup()
                except Exception:
                    pass
            raise CookieCandidateError('stage_failed') from None

    def cleanup(self):
        try:
            self._tempdir.cleanup()
        except Exception:
            raise CookieCandidateError('cleanup_failed') from None


class BrowserLoginCoordinator:
    """Fail closed until one candidate passes identity, local and cloud gates."""

    def __init__(self, *, stage: Callable[[], Any], status: Callable[[Any], Mapping],
                 local_accounts: Callable[[], list], claim: Callable[[str], bool],
                 commit: Callable[[Any, Mapping, Mapping], bool], discard: Callable[[Any], None],
                 current: Callable[[], Mapping], cancelled: Callable[[], bool],
                 deadline: float, clock: Callable[[], float] = time.monotonic,
                 expected_revision=None):
        self.stage, self.status = stage, status
        self.local_accounts, self.claim, self.commit = local_accounts, claim, commit
        self.discard, self.current, self.cancelled = discard, current, cancelled
        self.deadline, self.clock = deadline, clock
        self.expected_revision = expected_revision

    def _gate(self, original: Mapping) -> str | None:
        if self.cancelled():
            return 'cancelled'
        if self.clock() >= self.deadline:
            return 'timeout'
        now = self.current()
        if not now.get('exists'):
            return 'account_deleted'
        if now.get('cloud_paused'):
            return 'cloud_paused'
        if now.get('safety_paused'):
            return 'safety_paused'
        if now.get('access_revoked'):
            return 'access_revoked'
        if now.get('revision') != original.get('revision'):
            return 'account_changed'
        return None

    def run(self) -> LoginResult:
        holder = {}
        try:
            result = self._run_steps(holder)
        except Exception:
            # Never include callback exception text: it may contain a URL,
            # browser secret, UID, or path.
            result = LoginResult('failed', 'operation_failed')
        cleanup_code = ''
        if holder.get('candidate') is not None:
            try:
                self.discard(holder['candidate'])
            except Exception:
                cleanup_code = 'cleanup_failed'
        return LoginResult(result.state, result.code, cleanup_code)

    def _run_steps(self, holder: dict) -> LoginResult:
        original = self.current()
        if not original.get('exists'):
            return LoginResult('stopped', 'account_deleted')
        if original.get('cloud_paused'):
            return LoginResult('stopped', 'cloud_paused')
        if original.get('safety_paused'):
            return LoginResult('stopped', 'safety_paused')
        if original.get('access_revoked'):
            return LoginResult('stopped', 'access_revoked')
        if (original.get('platform') != 'xiaohongshu' or not original.get('id')
                or original.get('revision') is None):
            return LoginResult('failed', 'account_state_unavailable')
        if (self.expected_revision is not None
                and original.get('revision') != self.expected_revision):
            return LoginResult('stopped', 'account_changed')
        if self.cancelled():
            return LoginResult('cancelled', 'cancelled')
        if self.clock() >= self.deadline:
            return LoginResult('stopped', 'timeout')

        candidate = self.stage()
        holder['candidate'] = candidate
        if candidate is None:
            return LoginResult('failed', 'stage_failed')
        blocked = self._gate(original)
        if blocked:
            return self._blocked(blocked)

        payload = self.status(candidate)
        blocked = self._gate(original)
        if blocked:
            return self._blocked(blocked)
        if not isinstance(payload, Mapping):
            return LoginResult('failed', 'identity_unverified')
        if 'ok' in payload and payload['ok'] is not True:
            return LoginResult('failed', 'identity_unverified')
        data = payload.get('data', payload)
        if not isinstance(data, Mapping) or data.get('authenticated') is not True:
            return LoginResult('failed', 'identity_unverified')
        profile = data.get('user')
        if not isinstance(profile, Mapping):
            return LoginResult('failed', 'identity_unverified')
        if 'guest' in profile and type(profile['guest']) is not bool:
            return LoginResult('failed', 'identity_unverified')
        nickname = profile.get('nickname') or profile.get('nick_name')
        uid = profile.get('id') or profile.get('user_id') or profile.get('red_id')
        if not isinstance(nickname, str) or not isinstance(uid, str):
            return LoginResult('failed', 'identity_unverified')
        # Core's account_check uses this same pure decision; candidate login
        # does not maintain a second nickname, UID, or duplicate rule.
        decision = evaluate_xhs_identity(original, data, self.local_accounts())
        if not decision['verified']:
            code = decision['status']
            if code not in ('identity_mismatch', 'duplicate_identity'):
                code = 'identity_unverified'
            return LoginResult('failed', code)
        blocked = self._gate(original)
        if blocked:
            return self._blocked(blocked)

        # The caller passes an in-memory copy with the verified UID to the
        # existing service cloud claim; no account data is persisted yet.
        if self.claim(decision['uid']) is not True:
            return LoginResult('failed', 'cloud_claim_failed')
        blocked = self._gate(original)
        if blocked:
            return self._blocked(blocked)

        # The callback must compare the original revision under account lock,
        # then atomically commit session and account metadata or roll both back.
        if self.commit(candidate, decision, original) is not True:
            return LoginResult('failed', 'commit_failed')
        return LoginResult('completed', 'completed')

    @staticmethod
    def _blocked(code: str) -> LoginResult:
        return LoginResult('cancelled' if code == 'cancelled' else 'stopped', code)
