"""Machine Evergreen file trust, separate from any page/actor/session grant.

No renderer, process, browser, account, network request or installer is opened.
The consuming app must pin this module, windows_authenticode and its own
helper/PYZ/SDK artifacts before calling. Returned private evidence is not an
HTTP proof and does not prove native memory bytes or authorize collection.
"""
from dataclasses import dataclass
from pathlib import Path
import ctypes as c
from ctypes import wintypes as w
import hashlib,json,os,re,sys,time,winreg
if __package__:
    from .windows_authenticode import microsoft_signature,TrustError
else:
    from windows_authenticode import microsoft_signature,TrustError

# Conservative actually observed/read-only tested floor. The official/SDK
# minimum needed merely to instantiate a control is not app acceptance.
MINIMUM_VERIFIED_VERSION=(155,0,4283,62)
_SEAL=object()
_RUNTIME_GUID='{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
_FILES=('msedgewebview2.exe','msedge.dll','msedge_elf.dll')
_MACHINE_WRITERS=frozenset(('S-1-5-18','S-1-5-32-544','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464'))
_WRITE=0x40000000|0x10000000|0x10000|0x40000|0x80000|0x2|0x4|0x10|0x40|0x100

class DependencyReviewRequired(ValueError):
    def __init__(self,code):self.code=code;super().__init__(code)
def _fail(code):raise DependencyReviewRequired(code)
def _digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def _version(value):
    if type(value) is str and re.fullmatch(r'(?:0|[1-9][0-9]{0,5})(?:\.(?:0|[1-9][0-9]{0,5})){3}',value):return tuple(map(int,value.split('.')))
    _fail('SYSTEM_WEBVIEW2_VERSION_INVALID')
def _version_text(value):return '.'.join(map(str,value))
def _path(value):
    p=Path(value)
    if not p.is_absolute() or not re.fullmatch(r'[A-Za-z]:',p.drive) or any(x in ('.','..') for x in p.parts) or any(x in str(p) for x in ('\x00','\r','\n')) or ':' in str(p)[2:]:_fail('SYSTEM_WEBVIEW2_PATH_INVALID')
    # Do not resolve an unknown link and then approve its target.
    for q in (*reversed(p.parents),p):
        try:st=q.lstat()
        except OSError:_fail('SYSTEM_WEBVIEW2_PATH_UNAVAILABLE')
        if q.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:_fail('SYSTEM_WEBVIEW2_REPARSE')
    return p

class FILETIME(c.Structure):_fields_=[('low',w.DWORD),('high',w.DWORD)]
class FILEFACT(c.Structure):
    _fields_=[('attributes',w.DWORD),('created',FILETIME),('accessed',FILETIME),('written',FILETIME),('volume',w.DWORD),('sizeHigh',w.DWORD),('sizeLow',w.DWORD),('links',w.DWORD),('indexHigh',w.DWORD),('indexLow',w.DWORD)]
class _Apis:
    def __init__(self):
        if os.name!='nt':_fail('SYSTEM_WEBVIEW2_WINDOWS_REQUIRED')
        self.kernel=c.WinDLL('kernel32.dll',winmode=0x800,use_last_error=True)
        self.kernel.CreateFileW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.c_void_p,w.DWORD,w.DWORD,w.HANDLE];self.kernel.CreateFileW.restype=w.HANDLE
        self.kernel.GetFileInformationByHandle.argtypes=[w.HANDLE,c.POINTER(FILEFACT)];self.kernel.GetFileInformationByHandle.restype=w.BOOL
        self.kernel.GetFinalPathNameByHandleW.argtypes=[w.HANDLE,w.LPWSTR,w.DWORD,w.DWORD];self.kernel.GetFinalPathNameByHandleW.restype=w.DWORD
        self.kernel.CloseHandle.argtypes=[w.HANDLE];self.kernel.CloseHandle.restype=w.BOOL
        self.kernel.LocalFree.argtypes=[w.HANDLE];self.kernel.LocalFree.restype=w.HANDLE

class _HeldFile:
    def __init__(self,apis,path,*,directory=False,owned=False):
        self.apis=apis;self.path=_path(path);self.handle=None;self.directory=directory
        access=0x80 if directory else 0x80000000;share=3 if directory else 1
        self.handle=apis.kernel.CreateFileW(str(self.path),access,share,None,3,0x00200000|(0x02000000 if directory else 0x08000000),None)
        if self.handle in (None,c.c_void_p(-1).value):self.handle=None;_fail('SYSTEM_WEBVIEW2_FILE_BUSY')
        try:
            self.initial=self.facts()
            if owned and self.initial['links']!=1:_fail('OWNED_WEBVIEW_MATERIAL_HARDLINK')
            if directory!=(bool(self.initial['attributes']&0x10)):_fail('SYSTEM_WEBVIEW2_FILE_TYPE')
        except BaseException:self.close();raise
    def facts(self):
        if not self.handle:_fail('SYSTEM_WEBVIEW2_EVIDENCE_CLOSED')
        f=FILEFACT();name=c.create_unicode_buffer(32768)
        if not self.apis.kernel.GetFileInformationByHandle(self.handle,c.byref(f)):_fail('SYSTEM_WEBVIEW2_FILE_IDENTITY')
        n=self.apis.kernel.GetFinalPathNameByHandleW(self.handle,name,len(name),0)
        final=name.value[4:] if name.value.startswith('\\\\?\\') else name.value
        if not 0<n<len(name) or final.casefold()!=str(self.path).casefold() or f.attributes&0x400:_fail('SYSTEM_WEBVIEW2_PATH_CHANGED')
        value={'volume':int(f.volume),'fileIndex':(int(f.indexHigh)<<32)|f.indexLow,'links':int(f.links),'attributes':int(f.attributes)}
        if not self.directory:value.update(bytes=(int(f.sizeHigh)<<32)|f.sizeLow,lastWrite=(int(f.written.high)<<32)|f.written.low)
        return value
    def hash(self):
        initial=self.facts();h=hashlib.sha256()
        with self.path.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
        if initial!=self.facts() or initial!=self.initial:_fail('SYSTEM_WEBVIEW2_FILE_CHANGED')
        return h.hexdigest()
    def close(self):
        if self.handle:self.apis.kernel.CloseHandle(self.handle);self.handle=None

def _known_roots():
    from uuid import UUID
    shell=c.WinDLL('shell32.dll',winmode=0x800);ole=c.WinDLL('ole32.dll',winmode=0x800)
    shell.SHGetKnownFolderPath.argtypes=[c.c_void_p,w.DWORD,w.HANDLE,c.POINTER(c.c_void_p)];shell.SHGetKnownFolderPath.restype=c.c_long;ole.CoTaskMemFree.argtypes=[c.c_void_p]
    roots=[]
    for identifier in ('905e63b6-c1bf-494e-b29c-65b732d3d21a','7c5a40ef-a0fb-4bfc-874a-c0f2e0b9fa8e'):
        g=(c.c_ubyte*16).from_buffer_copy(UUID(identifier).bytes_le);raw=c.c_void_p()
        if shell.SHGetKnownFolderPath(g,0,None,c.byref(raw))!=0:_fail('SYSTEM_WEBVIEW2_INSTALL_ROOT_UNAVAILABLE')
        try:path=_path(c.wstring_at(raw));roots.append(path/'Microsoft/EdgeWebView/Application')
        finally:ole.CoTaskMemFree(raw)
    return tuple(dict.fromkeys(roots))

def _registry_candidates():
    values=[];key=r'SOFTWARE\Microsoft\EdgeUpdate\Clients'+'\\'+_RUNTIME_GUID
    for view in (winreg.KEY_WOW64_32KEY,winreg.KEY_WOW64_64KEY):
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,key,0,winreg.KEY_READ|view) as h:
                version,vt=winreg.QueryValueEx(h,'pv');location,lt=winreg.QueryValueEx(h,'location');name,nt=winreg.QueryValueEx(h,'name')
                if any(t!=winreg.REG_SZ for t in (vt,lt,nt)) or name!='Microsoft Edge WebView2 Runtime':_fail('SYSTEM_WEBVIEW2_REGISTRY_INVALID')
                values.append({'hive':'HKLM','view':view,'key':key,'version':_version_text(_version(version)),'location':str(_path(location))})
        except FileNotFoundError:continue
        except OSError:_fail('SYSTEM_WEBVIEW2_REGISTRY_UNAVAILABLE')
    if not values:_fail('SYSTEM_WEBVIEW2_MACHINE_INSTALL_REQUIRED')
    return values

def _acl(path,apis):
    """Conventional Program Files alone is insufficient if Users can replace it."""
    adv=c.WinDLL('advapi32.dll',winmode=0x800,use_last_error=True)
    adv.GetNamedSecurityInfoW.argtypes=[w.LPWSTR,w.DWORD,w.DWORD,c.POINTER(c.c_void_p),c.c_void_p,c.POINTER(c.c_void_p),c.c_void_p,c.POINTER(c.c_void_p)];adv.GetNamedSecurityInfoW.restype=w.DWORD
    adv.ConvertSidToStringSidW.argtypes=[c.c_void_p,c.POINTER(c.c_void_p)];adv.ConvertSidToStringSidW.restype=w.BOOL
    adv.GetAce.argtypes=[c.c_void_p,w.DWORD,c.POINTER(c.c_void_p)];adv.GetAce.restype=w.BOOL
    adv.GetSecurityDescriptorLength.argtypes=[c.c_void_p];adv.GetSecurityDescriptorLength.restype=w.DWORD
    owner=c.c_void_p();dacl=c.c_void_p();sd=c.c_void_p()
    def sid(value):
        text=c.c_void_p()
        if not adv.ConvertSidToStringSidW(value,c.byref(text)):_fail('SYSTEM_WEBVIEW2_ACL_INVALID')
        try:return c.wstring_at(text)
        finally:apis.kernel.LocalFree(text)
    status=adv.GetNamedSecurityInfoW(str(path),1,5,c.byref(owner),None,c.byref(dacl),None,c.byref(sd))
    if status or not owner or not dacl or not sd:_fail('SYSTEM_WEBVIEW2_ACL_UNAVAILABLE')
    try:
        owner_name=sid(owner)
        if owner_name not in _MACHINE_WRITERS:_fail('SYSTEM_WEBVIEW2_UNTRUSTED_OWNER')
        header=c.string_at(dacl,8);count=int.from_bytes(header[4:6],'little')
        if count>128:_fail('SYSTEM_WEBVIEW2_ACL_INVALID')
        for i in range(count):
            ace=c.c_void_p()
            if not adv.GetAce(dacl,i,c.byref(ace)):_fail('SYSTEM_WEBVIEW2_ACL_INVALID')
            raw=c.string_at(ace,8);kind,flags=raw[0],raw[1];mask=int.from_bytes(raw[4:8],'little')
            if flags&8:continue # inherit-only is not access to this actual directory
            if kind in (5,9,11,13) and mask&_WRITE:_fail('SYSTEM_WEBVIEW2_ACL_COMPLEX_WRITE')
            if kind==0 and mask&_WRITE and sid(c.c_void_p(ace.value+8)) not in _MACHINE_WRITERS:_fail('SYSTEM_WEBVIEW2_USER_WRITABLE')
        size=adv.GetSecurityDescriptorLength(sd)
        if not 1<=size<=65536:_fail('SYSTEM_WEBVIEW2_ACL_INVALID')
        return {'path':str(path),'owner':owner_name,'descriptorSha256':hashlib.sha256(c.string_at(sd,size)).hexdigest()}
    finally:apis.kernel.LocalFree(sd)

class VERSIONINFO(c.Structure):
    _fields_=[(n,w.DWORD) for n in ('signature','structure','fileMS','fileLS','productMS','productLS','flagsMask','flags','os','type','subtype','dateMS','dateLS')]
def _file_metadata(path):
    dll=c.WinDLL('version.dll',winmode=0x800);unused=w.DWORD()
    dll.GetFileVersionInfoSizeW.argtypes=[w.LPCWSTR,c.POINTER(w.DWORD)];dll.GetFileVersionInfoSizeW.restype=w.DWORD
    dll.GetFileVersionInfoW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.c_void_p];dll.GetFileVersionInfoW.restype=w.BOOL
    dll.VerQueryValueW.argtypes=[c.c_void_p,w.LPCWSTR,c.POINTER(c.c_void_p),c.POINTER(w.UINT)];dll.VerQueryValueW.restype=w.BOOL
    size=dll.GetFileVersionInfoSizeW(str(path),c.byref(unused))
    if not 1<=size<=1000000:_fail('SYSTEM_WEBVIEW2_PE_VERSION')
    data=c.create_string_buffer(size);value=c.c_void_p();length=w.UINT()
    if not dll.GetFileVersionInfoW(str(path),0,size,data) or not dll.VerQueryValueW(data,'\\',c.byref(value),c.byref(length)) or length.value<c.sizeof(VERSIONINFO):_fail('SYSTEM_WEBVIEW2_PE_VERSION')
    info=c.cast(value,c.POINTER(VERSIONINFO)).contents
    if info.signature!=0xfeef04bd:_fail('SYSTEM_WEBVIEW2_PE_VERSION')
    file_version=(info.fileMS>>16,info.fileMS&65535,info.fileLS>>16,info.fileLS&65535)
    product_version=(info.productMS>>16,info.productMS&65535,info.productLS>>16,info.productLS&65535)
    if not dll.VerQueryValueW(data,'\\VarFileInfo\\Translation',c.byref(value),c.byref(length)) or not 4<=length.value<=256 or length.value%4:_fail('SYSTEM_WEBVIEW2_PE_TRANSLATION')
    translations=c.string_at(value,length.value);strings=[]
    for i in range(0,len(translations),4):
        language=int.from_bytes(translations[i:i+2],'little');codepage=int.from_bytes(translations[i+2:i+4],'little');entry={}
        for key in ('OriginalFilename','ProductName','CompanyName','FileVersion','ProductVersion'):
            selector='\\StringFileInfo\\'+format(language,'04x')+format(codepage,'04x')+'\\'+key
            if not dll.VerQueryValueW(data,selector,c.byref(value),c.byref(length)) or not 1<length.value<=512:_fail('SYSTEM_WEBVIEW2_PE_METADATA')
            entry[key]=c.wstring_at(value,length.value-1)
        strings.append(entry)
    return {'fixedFileVersion':file_version,'fixedProductVersion':product_version,'strings':strings}

def _check_pe_metadata(name,metadata,version):
    expected_product='Microsoft Edge WebView2' if name=='msedgewebview2.exe' else 'Microsoft Edge'
    if metadata['fixedFileVersion']!=version or metadata['fixedProductVersion']!=version:_fail('SYSTEM_WEBVIEW2_PE_REGISTRY_MISMATCH')
    for entry in metadata['strings']:
        if (entry['OriginalFilename'].casefold()!=name.casefold() or entry['CompanyName']!='Microsoft Corporation'
                or entry['ProductName']!=expected_product or _version(entry['FileVersion'])!=version
                or _version(entry['ProductVersion'])!=version):_fail('SYSTEM_WEBVIEW2_PE_PRODUCT_MISMATCH')

@dataclass(frozen=True,slots=True)
class OwnedRuntimePin:
    path: Path
    sha256: str
    size: int
    role: str

def _sdk_version(loader,folder):
    # Explicit absolute fixed loader; sibling and System32 only, no PATH/CWD.
    dll=c.WinDLL(str(loader),winmode=0x100|0x800,use_last_error=True);fn=dll.GetAvailableCoreWebView2BrowserVersionString
    fn.argtypes=[w.LPCWSTR,c.POINTER(c.c_void_p)];fn.restype=c.c_long;raw=c.c_void_p();ole=c.WinDLL('ole32.dll',winmode=0x800);ole.CoTaskMemFree.argtypes=[c.c_void_p]
    try:
        if fn(str(folder) if folder is not None else None,c.byref(raw))!=0 or not raw:_fail('SYSTEM_WEBVIEW2_SDK_UNAVAILABLE')
        return _version(c.wstring_at(raw)) # beta/dev suffix is deliberately not accepted
    finally:
        if raw:ole.CoTaskMemFree(raw)
        import _ctypes
        _ctypes.FreeLibrary(dll._handle)

class _SystemWebView2Evidence:
    __slots__=('_seal','_policy','_held','_facts','_binding','verified_at','_closed')
    def __init__(self,seal,policy,held,facts):
        if seal is not _SEAL:_fail('SYSTEM_WEBVIEW2_EVIDENCE_INVALID')
        self._seal=seal;self._policy=policy;self._held=held;self._facts=facts;self._binding=_digest(facts);self.verified_at=time.time();self._closed=False
    @property
    def runtime_exe_path(self):return Path(self._facts['runtimeFiles'][0]['path'])
    @property
    def browser_executable_folder(self):return self.runtime_exe_path.parent
    @property
    def version(self):return tuple(self._facts['version'])
    @property
    def sha256(self):return self._facts['runtimeFiles'][0]['sha256']
    @property
    def identity(self):return dict(self._facts['runtimeFiles'][0]['identity'])
    @property
    def materials(self):return tuple((f['path'],f['sha256'].upper(),'webview_runtime') for f in self._facts['runtimeFiles'])
    def describe(self):
        # Return a detached description; callers cannot turn this dict back into
        # a live object. Never emit approved/collection/session/browser flags.
        return json.loads(json.dumps({'contract':'machine_webview2_file_trust_v1','version':self.version,'verifiedAt':self.verified_at,'facts':self._facts,'nativeLoadedBytesVerified':False,'naturalPageTested':False,'collectionAuthorized':False,'sessionAuthorized':False,'platformVerified':False}))
    def check_current(self):
        if self._closed or self._seal is not _SEAL or type(self._policy) is not SystemWebView2Policy:_fail('SYSTEM_WEBVIEW2_EVIDENCE_CLOSED')
        current=self._policy.verify()
        try:
            if current._binding!=self._binding:_fail('SYSTEM_WEBVIEW2_CHANGED')
            for file in self._held:
                if file.facts()!=file.initial:_fail('SYSTEM_WEBVIEW2_FILE_CHANGED')
        finally:current.close()
        return self
    def close(self):
        if not self._closed:
            self._closed=True
            for f in reversed(self._held):f.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass

class SystemWebView2Policy:
    def __init__(self,owned_pins,*,minimum_version=MINIMUM_VERIFIED_VERSION,mode='compiled'):
        if type(owned_pins) is not tuple or not 4<=len(owned_pins)<=8192 or any(type(v) is not OwnedRuntimePin for v in owned_pins):_fail('OWNED_WEBVIEW_MATERIAL_INVALID')
        if type(minimum_version) is not tuple or len(minimum_version)!=4 or any(type(v) is not int or not 0<=v<=999999 for v in minimum_version) or minimum_version<MINIMUM_VERIFIED_VERSION:_fail('SYSTEM_WEBVIEW2_COMPATIBILITY_FLOOR')
        if mode not in ('compiled','source'):_fail('OWNED_WEBVIEW_MATERIAL_INVALID')
        roles=[v.role for v in owned_pins];required={'sdk_loader','sdk_core','sdk_winforms'}
        if mode=='source':required|={'policy_source','authenticode_source','helper_source'}
        elif 'helper_exe_with_embedded_pyz' in roles:required.add('helper_exe_with_embedded_pyz')
        else:required|={'helper_exe','pyz'}
        if not required<=set(roles) or any(roles.count(n)!=1 for n in required) or len({str(p.path).casefold() for p in owned_pins})!=len(owned_pins):_fail('OWNED_WEBVIEW_MATERIAL_INCOMPLETE')
        for p in owned_pins:
            if type(p.sha256) is not str or not re.fullmatch('[0-9a-fA-F]{64}',p.sha256) or type(p.size) is not int or p.size<0 or type(p.path) is not Path and not isinstance(p.path,Path):_fail('OWNED_WEBVIEW_MATERIAL_INVALID')
        # In an original reviewed frozen helper, the entire helper EXE pin
        # covers the embedded PYZ bytes too. Do not invent a second extraction
        # or loaded-code approval scheme here. The consumer's original owner
        # must bind those reviewed EXE/PYZ origins before accepting this token.
        actual_sources={'policy_source':Path(__file__).absolute(),'authenticode_source':Path(microsoft_signature.__code__.co_filename).absolute()}
        for role,path in actual_sources.items():
            if role in roles and next(p.path for p in owned_pins if p.role==role).absolute()!=path:_fail('OWNED_WEBVIEW_MATERIAL_ORIGIN')
        for pin in owned_pins:
            if pin.role in ('helper_exe','helper_exe_with_embedded_pyz') and pin.path.suffix.casefold()!='.exe':_fail('OWNED_WEBVIEW_MATERIAL_ORIGIN')
        for role,name in (('sdk_core','Microsoft.Web.WebView2.Core.dll'),('sdk_winforms','Microsoft.Web.WebView2.WinForms.dll')):
            if next(p.path for p in owned_pins if p.role==role).name!=name:_fail('OWNED_WEBVIEW_SDK_ORIGIN')
        self._pins=owned_pins;self._minimum=minimum_version;self._mode=mode
    def verify(self):
        if any(k.upper().startswith('WEBVIEW2_') and v for k,v in os.environ.items()):_fail('SYSTEM_WEBVIEW2_ENVIRONMENT_OVERRIDE')
        apis=_Apis();held=[];facts={'minimum':self._minimum,'mode':self._mode,'ownedFiles':[],'runtimeFiles':[],'directoryAcl':[]}
        directories={}
        def hold(path,owned=False):
            path=_path(path)
            for directory in reversed(path.parents):
                if str(directory).casefold() not in directories:
                    h=_HeldFile(apis,directory,directory=True);held.append(h);directories[str(directory).casefold()]=h
            h=_HeldFile(apis,path,owned=owned);held.append(h);return h
        try:
            for pin in self._pins:
                file=hold(pin.path,True);value=file.hash()
                if value!=pin.sha256.lower() or file.initial['bytes']!=pin.size:_fail('OWNED_WEBVIEW_MATERIAL_CHANGED')
                facts['ownedFiles'].append({'path':str(file.path),'role':pin.role,'sha256':value,'identity':file.initial})
            loader=next(p.path for p in self._pins if p.role=='sdk_loader')
            if loader.name.casefold()!='webview2loader.dll':_fail('OWNED_WEBVIEW_SDK_LOADER_INVALID')
            roots=_known_roots();registry=_registry_candidates();default=_sdk_version(loader,None);selected=[]
            for candidate in registry:
                location=Path(candidate['location'])
                if location not in roots:_fail('SYSTEM_WEBVIEW2_INSTALL_ROOT_UNTRUSTED')
                version=_version(candidate['version'])
                if version==default:selected.append(candidate)
            if not selected:_fail('SYSTEM_WEBVIEW2_SDK_REGISTRY_MISMATCH')
            first=selected[0];version=_version(first['version']);folder=Path(first['location'])/first['version'];_path(folder)
            if version<self._minimum:_fail('SYSTEM_WEBVIEW2_UNSUPPORTED_VERSION')
            if _sdk_version(loader,folder)!=version:_fail('SYSTEM_WEBVIEW2_SDK_REGISTRY_MISMATCH')
            facts.update(version=version,registry=registry,sdkVersion=default)
            # ACL-check the known Program Files root through the version folder.
            program_files=Path(first['location']).parents[2]
            acl_dirs=[program_files]
            cursor=program_files
            for part in folder.relative_to(program_files).parts:cursor=cursor/part;acl_dirs.append(cursor)
            for directory in acl_dirs:
                if str(directory).casefold() not in directories:
                    h=_HeldFile(apis,directory,directory=True);held.append(h);directories[str(directory).casefold()]=h
                facts['directoryAcl'].append(_acl(directory,apis))
            for name in _FILES:
                file=hold(folder/name);metadata=_file_metadata(file.path);_check_pe_metadata(name,metadata,version)
                value=file.hash()
                try:signature=microsoft_signature(file.path,file.handle)
                except TrustError as e:_fail('SYSTEM_WEBVIEW2_SIGNATURE_'+str(e))
                if file.initial!=file.facts():_fail('SYSTEM_WEBVIEW2_FILE_CHANGED')
                facts['runtimeFiles'].append({'path':str(file.path),'identity':file.initial,'version':version,'signedPeMetadata':metadata,'sha256':value,'signature':signature})
            # Signature/hash construction does not grant an update race. The
            # exact old task will fail check_current, while a new explicit call
            # may accept a newer Microsoft patch without a new fixed hash.
            if _registry_candidates()!=registry:_fail('SYSTEM_WEBVIEW2_REGISTRY_CHANGED')
            if [_acl(Path(item['path']),apis) for item in facts['directoryAcl']]!=facts['directoryAcl']:_fail('SYSTEM_WEBVIEW2_ACL_CHANGED')
            for file in held:
                if file.initial!=file.facts():_fail('SYSTEM_WEBVIEW2_FILE_CHANGED')
            return _SystemWebView2Evidence(_SEAL,self,held,facts)
        except BaseException:
            for file in reversed(held):file.close()
            raise
