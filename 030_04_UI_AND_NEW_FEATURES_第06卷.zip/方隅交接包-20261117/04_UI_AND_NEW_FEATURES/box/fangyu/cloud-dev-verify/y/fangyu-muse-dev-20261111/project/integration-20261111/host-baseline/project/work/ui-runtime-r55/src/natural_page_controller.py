"""Pure, opt-in state boundary for one owned XHS natural-page helper.

The caller supplies native navigation, CDP-correlated responses, and the
existing private IPC. Importing this module cannot open a window or request
the platform. The caller must use the opt-in owned natural mode.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import json
import re
from urllib.parse import parse_qs, quote, urlsplit

from xhs_page_transport import _natural_identity_error
from xhs_natural_search import validate_result, validate_range
from xhs_search_range import validate_checkpoint


MAX_BODY = 4 * 1024 * 1024
_ID = re.compile(r"[A-Za-z0-9_-]{1,100}\Z")
_NOTE_ID = re.compile(r"[0-9a-f]{24}\Z")
_SOURCES = {"", "pc_search", "pc_note", "pc_feed", "pc_user"}
_ACTIONS = {"status", "search", "comments", "sub_comments"}
_API = {
    "getMe": ("GET", "/api/sns/web/v2/user/me"),
    "search": ("POST", "/api/sns/web/v1/search/notes"),
    "comments": ("GET", "/api/sns/web/v2/comment/page"),
    "sub_comments": ("GET", "/api/sns/web/v2/comment/sub/page"),
}


class NaturalPageError(RuntimeError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _text(value: object, limit: int) -> bool:
    return isinstance(value, str) and 0 < len(value) <= limit and not any(
        ord(c) < 32 or ord(c) == 127 for c in value
    )


def _url_parts(value: object, host: str):
    if not isinstance(value, str) or len(value) > 8192:
        raise NaturalPageError("route_invalid")
    try:
        parsed = urlsplit(value)
        if (parsed.scheme != "https" or parsed.hostname != host or
                parsed.port not in (None, 443) or parsed.username or
                parsed.password or parsed.fragment):
            raise ValueError
        query = parse_qs(parsed.query, keep_blank_values=True, max_num_fields=16)
        if any(len(k) > 64 or len(v) != 1 or len(v[0]) > 2048
               for k, v in query.items()):
            raise ValueError
        return parsed, query
    except (TypeError, ValueError):
        raise NaturalPageError("route_invalid") from None


def _note_source(url: object):
    parsed, query = _url_parts(url, "www.xiaohongshu.com")
    match = re.fullmatch(r"/(?:explore|search_result)/([0-9a-f]{24})/?", parsed.path)
    token = query.get("xsec_token", [""])[0]
    source = query.get("xsec_source", [""])[0]
    if not match or not _text(token, 2048) or source not in _SOURCES:
        raise NaturalPageError("source_invalid")
    return match.group(1), token, source


def _json_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_key")
        result[key] = value
    return result


def _reject_constant(_value):
    raise ValueError("nonfinite")


@dataclass(frozen=True)
class ObservedResponse:
    """Evidence provided by the owned CDP binder, never by webpage JS."""

    kind: str
    method: str
    url: str
    request_id: str
    loader_id: str
    frame_id: str
    doc_epoch: int
    task_epoch: int
    body: bytes
    http_status: int | None = None


class NaturalPageController:
    """One in-flight logical call; physical documents and SPA routes stay distinct.

    ``post(path, payload)`` is the authenticated native IPC adapter.
    ``navigate(url)`` is an owned top-level WebView2 navigation only. The
    controller does not synthesize page API calls, scrolling, or pagination.
    """

    def __init__(self, *, post, navigate, session_token: str, bound_uid: str,
                 doc_epoch: int = 1, identity_observation=False):
        if (not callable(post) or not callable(navigate) or
                not _text(session_token, 512) or not isinstance(bound_uid,str)
                or not (_text(bound_uid, 256) or identity_observation is True and bound_uid=='')
                or type(identity_observation) is not bool):
            raise NaturalPageError("invalid_scope")
        if type(doc_epoch) is not int or doc_epoch < 1:
            raise NaturalPageError("invalid_scope")
        self.post = post
        self.navigate = navigate
        self.session_token = session_token
        self.bound_uid = bound_uid
        self.identity_observation = identity_observation
        self.doc_epoch = doc_epoch
        self.route_revision = 0
        self.phase = "idle"
        self.command = None
        self.target_url = ""
        self.loader_id = ""
        self.frame_id = ""
        self.identity_verified = False
        self.used_call_ids = set()
        self.used_request_ids = set()
        self.last_task_epoch = 0
        self.sources = OrderedDict()
        self.observed_roots = {}
        self.next_cursors = {}
        self.early_response = None
        self.replay_expected_cursor = None
        self.replay_seen_cursors = set()
        self.root_main_expected_cursor = None
        self.sub_replay_expected_cursor = None
        self.sub_replay_seen_cursors = set()

    def _post(self, path: str, payload: dict):
        try:
            packet = {"session_token": self.session_token, **payload}
            if len(json.dumps(packet, ensure_ascii=True, allow_nan=False).encode("utf-8")) > MAX_BODY:
                self.phase = "failed"
                raise NaturalPageError("response_oversize")
            result = self.post(path, packet)
            if not isinstance(result, dict) or result.get("ok") is not True:
                raise ValueError
            return result
        except NaturalPageError:
            raise
        except Exception:
            self.phase = "failed"
            raise NaturalPageError("ipc_failed") from None

    def remember_dom_rows(self, rows: object, *, doc_epoch: int, task_epoch: int,
                          route_revision: int) -> dict:
        """Keep only observed signed links; DOM gives no pagination conclusion."""
        if (self.phase != "identity_verified" or not self.command or
                self.command["action"] != "search" or doc_epoch != self.doc_epoch or
                task_epoch != self.command["task_epoch"] or
                route_revision != self.route_revision or
                not self._route_matches(self.current_url, history=True) or
                not isinstance(rows, list) or
                len(rows) > 40):
            raise NaturalPageError("observation_denied")
        staged = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            try:
                note_id, token, source = _note_source(row.get("url"))
            except NaturalPageError:
                continue
            if row.get("note_id") != note_id or row.get("xsec_token") != token or (
                    row.get("xsec_source", "") != source):
                continue
            observed = (row["url"], token, source)
            if note_id in staged and staged[note_id] != observed:
                raise NaturalPageError("source_mismatch")
            staged[note_id] = observed
        for note_id, source in staged.items():
            self._remember_source(note_id, source)
        return {"code": "pagination_unknown", "signed_count": len(staged)}

    def _remember_source(self, note_id: str, source: tuple) -> None:
        if self.sources.get(note_id) != source:
            self.next_cursors = {key: value for key, value in self.next_cursors.items()
                                 if key[1] != note_id or key[3] == source[0]}
            self.observed_roots.pop(note_id, None)
        self.sources[note_id] = source
        self.sources.move_to_end(note_id)
        while len(self.sources) > 512:
            evicted, _ = self.sources.popitem(last=False)
            self.next_cursors = {key: value for key, value in self.next_cursors.items()
                                 if key[1] != evicted}
            self.observed_roots.pop(evicted, None)

    def submit_dom_search(self, rows: object, range_info: object, *,
                          doc_epoch: int, task_epoch: int,
                          route_revision: int) -> str:
        """Submit only an identity-gated, scoped DOM batch and honest range marker."""
        if (self.phase != "identity_verified" or not self.command or
                self.command["action"] != "search" or doc_epoch != self.doc_epoch or
                task_epoch != self.command["task_epoch"] or
                route_revision != self.route_revision or
                not self._route_matches(self.current_url, history=True)):
            raise NaturalPageError("observation_denied")
        envelope = {"code": 0, "_transport": "natural_dom",
                    "data": {"items": rows, "range": range_info}}
        try:
            data = validate_result(envelope)
            validate_range(data["range"], keyword=self.command["params"]["keyword"])
        except (TypeError, ValueError):
            raise NaturalPageError("invalid_response") from None
        staged = {row["note_id"]: (row["url"], row["xsec_token"],
                                    row["xsec_source"]) for row in data["items"]}
        self._post("/result", {"doc_epoch": self.doc_epoch,
                   "call_id": self.command["call_id"],
                   "task_epoch": self.command["task_epoch"], "envelope": envelope})
        for note_id, source in staged.items():
            self._remember_source(note_id, source)
        self.phase = "idle"
        self.command = None
        self.early_response = None
        return "submitted"

    def accept_command(self, command: object) -> str:
        if self.phase != "idle":
            raise NaturalPageError("busy")
        if not isinstance(command, dict) or set(command) != {"action", "call_id", "task_epoch", "params"}:
            raise NaturalPageError("invalid_command")
        action, call_id, task_epoch, params = (command[k] for k in
                                                ("action", "call_id", "task_epoch", "params"))
        if (action not in _ACTIONS or self.identity_observation and action!='status' or not isinstance(call_id, str) or
                not _ID.fullmatch(call_id) or call_id in self.used_call_ids or
                type(task_epoch) is not int or task_epoch <= self.last_task_epoch or
                not isinstance(params, dict)):
            raise NaturalPageError("invalid_command")
        route = "home" if action == "status" else "search" if action == "search" else "note"
        target = self._target(action, params)
        self.used_call_ids.add(call_id)
        self.last_task_epoch = task_epoch
        self.command = command
        self.target_url = target
        self.early_response = None
        same_doc = self._same_document_continuation(action, params)
        self.replay_expected_cursor = ("" if action == "comments" and
                                       bool(params["cursor"]) and not same_doc else None)
        self.replay_seen_cursors = set()
        self.root_main_expected_cursor = "" if action == "sub_comments" else None
        self.sub_replay_expected_cursor = None
        self.sub_replay_seen_cursors = set()
        if same_doc:
            self.phase = "identity_verified"
            return "observing_same_document"
        self.phase = "navigating"
        self._post("/begin_navigation", {"doc_epoch": self.doc_epoch,
                    "call_id": call_id, "task_epoch": task_epoch, "route_kind": route})
        try:
            self.navigate(target)
        except Exception:
            self.phase = "failed"
            raise NaturalPageError("navigation_failed") from None
        return "navigation_started"

    def _target(self, action: str, params: dict) -> str:
        if self.identity_observation and action!='status':
            raise NaturalPageError('invalid_command')
        if action == "status":
            if params:
                raise NaturalPageError("invalid_command")
            return "https://www.xiaohongshu.com/explore"
        if action == "search":
            if (set(params) not in ({"keyword", "page"},
                                    {"keyword", "page", "rangeCheckpoint"}) or
                    not _text(params.get("keyword"), 200) or
                    type(params.get("page")) is not int or params["page"] < 1):
                raise NaturalPageError("invalid_command")
            if "rangeCheckpoint" in params:
                try:
                    checkpoint = validate_checkpoint(params["rangeCheckpoint"])
                    if checkpoint["keyword"] != params["keyword"]:
                        raise ValueError
                except (TypeError, ValueError):
                    raise NaturalPageError("invalid_command") from None
            return ("https://www.xiaohongshu.com/search_result/?keyword="
                    + quote(params["keyword"], safe="") + "&source=web_explore_feed")
        allowed = {"noteId", "cursor", "token", "source"}
        if action == "sub_comments":
            allowed.add("rootCommentId")
        supplied = set(params)
        if (supplied not in (allowed, allowed | {"noteUrl"}) or
                not isinstance(params.get("cursor"), str) or
                len(params["cursor"]) > 512 or any(ord(c) < 32 or ord(c) == 127
                                                  for c in params["cursor"])):
            raise NaturalPageError("invalid_command")
        note_id = params.get("noteId")
        source = self.sources.get(note_id)
        note_url = params.get("noteUrl")
        if note_url is not None:
            try:
                actual_id, actual_token, actual_source = _note_source(note_url)
            except NaturalPageError:
                raise NaturalPageError("source_mismatch") from None
            observed = (note_url, actual_token, actual_source)
            if (actual_id != note_id or actual_token != params.get("token") or
                    actual_source != params.get("source")):
                raise NaturalPageError("source_mismatch")
            source = observed
        if (not isinstance(note_id, str) or not _NOTE_ID.fullmatch(note_id) or
                source is None or params.get("token") != source[1] or
                params.get("source") != source[2] or
                (action == "sub_comments" and not _text(params.get("rootCommentId"), 128))):
            raise NaturalPageError("source_mismatch")
        cursor = params["cursor"]
        cursor_key = (action, note_id, params.get("rootCommentId", ""), source[0])
        known_cursor = self.next_cursors.get(cursor_key)
        if cursor and known_cursor != cursor and not (known_cursor is None and note_url is not None):
            raise NaturalPageError("pagination_unavailable")
        self._remember_source(note_id, source)
        return source[0]

    def _same_document_continuation(self, action: str, params: dict) -> bool:
        if action not in ("comments", "sub_comments"):
            return False
        cursor_key = (action, params.get("noteId"), params.get("rootCommentId", ""),
                      self.target_url)
        known_cursor = (bool(params["cursor"]) and
                        self.next_cursors.get(cursor_key) == params["cursor"])
        roots = self.observed_roots.get(params.get("noteId"), {})
        known_root = (action == "sub_comments" and
                      params.get("rootCommentId") in roots and
                      roots[params["rootCommentId"]] is not False and
                      (not params["cursor"] or
                       roots[params["rootCommentId"]] == params["cursor"]))
        return (action in ("comments", "sub_comments") and
                (known_cursor or known_root) and
                self.identity_verified and self.loader_id and self.frame_id and
                self._route_matches(self.current_url, history=True))

    @property
    def current_url(self) -> str:
        return getattr(self, "_current_url", "")

    def _route_matches(self, url: str, *, history: bool = False) -> bool:
        try:
            parsed, query = _url_parts(url, "www.xiaohongshu.com")
            target, target_query = _url_parts(self.target_url, "www.xiaohongshu.com")
            if self.command["action"] == "search":
                return (parsed.path in (("/search_result/", "/search_result") if history
                                        else ("/search_result/",)) and
                        query.get("keyword") == target_query.get("keyword") and
                        query.get("source") == target_query.get("source") and
                        (history or query == target_query))
            if self.command["action"] == "status":
                return parsed.path == "/explore" and (history or query == target_query)
            if history:
                # Only after the native initial navigation and the same CDP
                # main-frame loader are established. The site can add source
                # or reshape query in SPA history; never rewrite the signed
                # URL/source pair originally observed in the DOM cache.
                observed = re.fullmatch(r"/(?:explore|search_result)/([0-9a-f]{24})/?",
                                        target.path)
                current = re.fullmatch(r"/(?:explore|search_result)/([0-9a-f]{24})/?",
                                       parsed.path)
                return bool(observed and current and observed.group(1) == current.group(1))
            return parsed.path == target.path and query == target_query
        except NaturalPageError:
            return False

    def physical_navigation(self, uri: str, *, redirected: bool = False) -> bool:
        if self.phase != "navigating" or redirected or not self._route_matches(uri):
            if self.command and self.phase not in ("cancelled", "failed"):
                self._post("/invalidate", {"doc_epoch": self.doc_epoch})
            self.phase = "failed"
            return False
        self._post("/invalidate", {"doc_epoch": self.doc_epoch,
                   "call_id": self.command["call_id"],
                   "task_epoch": self.command["task_epoch"]})
        self.phase = "invalidated"
        return True

    def document_ready(self, *, doc_epoch: int, loader_id: str, frame_id: str, uri: str) -> None:
        if (self.phase != "invalidated" or type(doc_epoch) is not int or
                doc_epoch <= self.doc_epoch or not _text(loader_id, 128) or
                not _text(frame_id, 128) or not self._route_matches(uri, history=True)):
            raise NaturalPageError("document_changed")
        old = self.doc_epoch
        self._post("/rebind", {"old_epoch": old, "new_epoch": doc_epoch,
                   "call_id": self.command["call_id"],
                   "task_epoch": self.command["task_epoch"]})
        self.doc_epoch = doc_epoch
        self.loader_id, self.frame_id = loader_id, frame_id
        self._current_url = uri
        self.identity_verified = False
        self.observed_roots.clear()
        self.route_revision = 0
        self.phase = "observing"

    def history_changed(self, uri: str) -> None:
        if self.phase not in ("observing", "identity_verified") or not self._route_matches(uri, history=True):
            self.phase = "failed"
            raise NaturalPageError("document_changed")
        self._current_url = uri
        self.route_revision += 1

    def _response_valid(self, observed: ObservedResponse, *, replay_main=False,
                        replay_sub=False, root_recovery=False) -> bool:
        if (not isinstance(observed, ObservedResponse) or not self.command or
                observed.doc_epoch != self.doc_epoch or
                observed.task_epoch != self.command["task_epoch"] or
                observed.loader_id != self.loader_id or observed.frame_id != self.frame_id or
                not _text(observed.request_id, 128) or
                observed.request_id in self.used_request_ids or
                not isinstance(observed.body, bytes) or len(observed.body) > MAX_BODY):
            return False
        expected = _API.get(observed.kind)
        if expected is None or observed.method != expected[0]:
            return False
        try:
            parsed, query = _url_parts(observed.url, "edith.xiaohongshu.com")
        except NaturalPageError:
            return False
        if parsed.path != expected[1]:
            return False
        if observed.kind in ("getMe", "search"):
            return not query
        params = self.command["params"]
        if query.get("note_id") != [params["noteId"]]:
            return False
        if replay_main:
            return (observed.kind == "comments" and self.command["action"] == "comments" and
                    isinstance(query.get("cursor", [""])[0], str) and
                    len(query.get("cursor", [""])[0]) <= 512)
        if root_recovery:
            return (observed.kind == "comments" and
                    self.command["action"] == "sub_comments" and
                    len(query.get("cursor", [""])) == 1 and
                    len(query.get("cursor", [""])[0]) <= 512)
        if replay_sub:
            return (observed.kind == "sub_comments" and
                    self.command["action"] == "sub_comments" and
                    len(query.get("cursor", [""])) == 1 and
                    len(query.get("cursor", [""])[0]) <= 512 and
                    (query.get("root_comment_id") == [params["rootCommentId"]] or
                     query.get("comment_id") == [params["rootCommentId"]]))
        if query.get("cursor", [""]) != [params["cursor"]]:
            return False
        if observed.kind == "sub_comments":
            return (query.get("root_comment_id") == [params["rootCommentId"]] or
                    query.get("comment_id") == [params["rootCommentId"]])
        return True

    def passive_response(self, observed: ObservedResponse) -> str:
        if self.phase not in ("observing", "identity_verified") or not self._response_valid(observed):
            raise NaturalPageError("response_denied")
        if (self.command["action"] == "comments" and self.replay_expected_cursor is not None
                and self.replay_expected_cursor != self.command["params"]["cursor"]
                and observed.kind == "comments"):
            raise NaturalPageError("response_denied")
        if (self.command["action"] == "sub_comments" and
                observed.kind == "sub_comments" and not self.root_ready(
                    self.command["params"]["noteId"],
                    self.command["params"]["rootCommentId"])):
            raise NaturalPageError("response_denied")
        if observed.kind != "getMe" and observed.kind != self.command["action"]:
            raise NaturalPageError("response_denied")
        if (type(observed.http_status) is int and observed.http_status >= 400):
            # The fixed status is enough to stop; do not need to surface an
            # HTML verification page or a vendor response body to the parent.
            envelope = {"_http_status": observed.http_status}
        else:
            try:
                envelope = json.loads(observed.body.decode("utf-8"),
                                      object_pairs_hook=_json_pairs,
                                      parse_constant=_reject_constant)
            except (UnicodeError, ValueError, TypeError, RecursionError):
                raise NaturalPageError("invalid_response") from None
        if not isinstance(envelope, dict):
            raise NaturalPageError("invalid_response")
        self.used_request_ids.add(observed.request_id)
        if observed.kind == "getMe":
            identity_error = ("verification_required" if observed.http_status in (461, 471)
                              else "not_authenticated" if observed.http_status == 401
                              else "platform_rejected" if type(observed.http_status) is int
                                   and observed.http_status >= 400
                              else _natural_identity_error(envelope, self.bound_uid,
                                  identity_observation=self.identity_observation))
            if identity_error:
                # The parent is the authoritative identity gate. Submit the
                # same observed envelope so its pending call fails promptly;
                # never mark this helper document verified locally.
                try:
                    self._post("/identity", {"doc_epoch": self.doc_epoch,
                               "call_id": self.command["call_id"],
                               "task_epoch": self.command["task_epoch"],
                               "envelope": envelope})
                except NaturalPageError:
                    pass
                self.phase = "failed"
                raise NaturalPageError(identity_error)
            if self.identity_verified:
                # The native website refreshes getMe during a search/note read.
                # Its scoped, new response must still match the bound account;
                # no second parent identity/result submission is needed.
                return "identity_confirmed"
            self._post("/identity", {"doc_epoch": self.doc_epoch,
                       "call_id": self.command["call_id"],
                       "task_epoch": self.command["task_epoch"], "envelope": envelope})
            self.identity_verified = True
            self.phase = "identity_verified"
            if self.command["action"] == "status":
                self._submit(envelope)
                return "submitted"
            if self.early_response is not None:
                early = self.early_response
                self.early_response = None
                self._submit(early)
                return "submitted"
            return "identity_verified"
        if observed.kind == "search" and not (
                envelope.get("success") is False or
                (type(envelope.get("code")) is int and envelope["code"] != 0) or
                (type(envelope.get("_http_status")) is int and
                 envelope["_http_status"] >= 400)):
            # Search API can be observed but its pagination shape does not
            # establish the DOM range. Only submit_dom_search commits rows.
            return "search_observed"
        if not self.identity_verified:
            if self.early_response is not None:
                raise NaturalPageError("response_denied")
            self.early_response = envelope
            return "awaiting_identity"
        self._submit(envelope)
        return "submitted"

    def consume_comment_replay(self, observed: ObservedResponse) -> str:
        """Advance only a real same-document main-comment cursor chain in RAM."""
        if (self.phase != "identity_verified" or not self.command or
                self.command["action"] != "comments" or
                self.replay_expected_cursor is None or
                self.replay_expected_cursor == self.command["params"]["cursor"] or
                not self._response_valid(observed, replay_main=True)):
            raise NaturalPageError("response_denied")
        try:
            _, query = _url_parts(observed.url, "edith.xiaohongshu.com")
            actual_cursor = query.get("cursor", [""])[0]
        except NaturalPageError:
            raise NaturalPageError("response_denied") from None
        if (actual_cursor != self.replay_expected_cursor or
                observed.request_id in self.used_request_ids):
            raise NaturalPageError("response_denied")
        self.used_request_ids.add(observed.request_id)
        if type(observed.http_status) is int and observed.http_status >= 400:
            self._submit({"_http_status": observed.http_status})
            return "rejected"
        try:
            envelope = json.loads(observed.body.decode("utf-8"),
                                  object_pairs_hook=_json_pairs,
                                  parse_constant=_reject_constant)
        except (UnicodeError, ValueError, TypeError, RecursionError):
            raise NaturalPageError("invalid_response") from None
        if not isinstance(envelope, dict):
            raise NaturalPageError("invalid_response")
        if (envelope.get("success") is False or
                (type(envelope.get("code")) is int and envelope["code"] != 0)):
            self._submit(envelope)
            return "rejected"
        data = envelope
        for _ in range(4):
            if not isinstance(data, dict) or "comments" in data:
                break
            data = data.get("data")
        if (not isinstance(data, dict) or not isinstance(data.get("comments"), list) or
                type(data.get("has_more")) is not bool):
            raise NaturalPageError("invalid_response")
        next_cursor = data.get("cursor") if data["has_more"] else None
        if not data["has_more"]:
            raise NaturalPageError("pagination_unavailable")
        if (not _text(next_cursor, 512) or next_cursor == actual_cursor or
                next_cursor in self.replay_seen_cursors):
            raise NaturalPageError("invalid_response")
        self.replay_seen_cursors.add(actual_cursor)
        self.replay_expected_cursor = next_cursor
        return ("desired_cursor_ready" if next_cursor == self.command["params"]["cursor"]
                else "replay_advanced")

    def remember_main_roots(self, observed: ObservedResponse) -> str:
        """Use current-document natural main GET only as sub-root evidence."""
        if (self.phase != "identity_verified" or not self.command or
                self.command["action"] != "sub_comments" or
                not self._response_valid(observed, root_recovery=True)):
            raise NaturalPageError("response_denied")
        _, query = _url_parts(observed.url, "edith.xiaohongshu.com")
        actual_cursor = query.get("cursor", [""])[0]
        if actual_cursor != self.root_main_expected_cursor:
            raise NaturalPageError("response_denied")
        self.used_request_ids.add(observed.request_id)
        if type(observed.http_status) is int and observed.http_status >= 400:
            self._submit({"_http_status": observed.http_status})
            return "rejected"
        try:
            envelope = json.loads(observed.body.decode("utf-8"),
                                  object_pairs_hook=_json_pairs,
                                  parse_constant=_reject_constant)
        except (UnicodeError, ValueError, TypeError, RecursionError):
            raise NaturalPageError("invalid_response") from None
        if not isinstance(envelope, dict):
            raise NaturalPageError("invalid_response")
        if (envelope.get("success") is False or
                (type(envelope.get("code")) is int and envelope["code"] != 0)):
            self._submit(envelope)
            return "rejected"
        data = envelope
        for _ in range(4):
            if not isinstance(data, dict) or "comments" in data:
                break
            data = data.get("data")
        if (not isinstance(data, dict) or not isinstance(data.get("comments"), list) or
                len(data["comments"]) > 200 or type(data.get("has_more")) is not bool):
            raise NaturalPageError("invalid_response")
        next_cursor = data.get("cursor") if data["has_more"] else None
        if data["has_more"] and (not _text(next_cursor, 512) or
                                  next_cursor == actual_cursor):
            raise NaturalPageError("invalid_response")
        note_id = self.command["params"]["noteId"]
        self._record_main_roots(note_id, data["comments"])
        self.root_main_expected_cursor = next_cursor
        root_id = self.command["params"]["rootCommentId"]
        if (self.can_expand_root(note_id, root_id) and
                self.command["params"]["cursor"] and
                self.sub_replay_expected_cursor is None):
            inline = self.observed_roots[note_id][root_id]
            self.sub_replay_expected_cursor = inline if isinstance(inline, str) else ""
        return ("root_observed" if self.can_expand_root(
                    note_id, root_id)
                else "root_unobserved")

    def _record_main_roots(self, note_id: str, comments: list) -> None:
        staged = {}
        for item in comments:
            if not isinstance(item, dict):
                raise NaturalPageError("invalid_response")
            candidate = item.get("id", item.get("comment_id"))
            if not isinstance(candidate, str) or not _text(candidate, 128):
                continue
            inline = item.get("sub_comment_cursor")
            embedded = item.get("sub_comments")
            resume = (item.get("sub_comment_has_more") is True and
                      isinstance(embedded, list) and bool(embedded) and
                      all(isinstance(child, dict) and child.get("id")
                          for child in embedded) and _text(inline, 512) and
                      not any(char.isspace() for char in inline))
            staged[candidate] = inline if resume else None
        roots = self.observed_roots.setdefault(note_id, {})
        roots.update(staged)
        while len(roots) > 2000:
            roots.pop(next(iter(roots)))

    def root_ready(self, note_id: str, root_comment_id: str) -> bool:
        if not self.can_expand_root(note_id, root_comment_id):
            return False
        cursor = self.command["params"].get("cursor")
        next_key = ("sub_comments", note_id, root_comment_id, self.target_url)
        known_cursor = self.next_cursors.get(next_key)
        return (not cursor or self.observed_roots[note_id][root_comment_id] == cursor or
                (known_cursor is not None and known_cursor == cursor) or
                (self.sub_replay_expected_cursor is not None and
                 self.sub_replay_expected_cursor == cursor))

    def can_expand_root(self, note_id: str, root_comment_id: str) -> bool:
        return (self.phase == "identity_verified" and self.command is not None and
                self.command["action"] == "sub_comments" and
                self.command["params"]["noteId"] == note_id and
                self.command["params"]["rootCommentId"] == root_comment_id and
                root_comment_id in self.observed_roots.get(note_id, {}) and
                self.observed_roots[note_id][root_comment_id] is not False and
                self._route_matches(self.current_url, history=True))

    def consume_sub_replay(self, observed: ObservedResponse) -> str:
        """Follow only natural same-root child cursors; never submit replay pages."""
        if (not self.command or self.command["action"] != "sub_comments" or
                not self.can_expand_root(self.command["params"]["noteId"],
                                         self.command["params"]["rootCommentId"]) or
                self.sub_replay_expected_cursor is None or
                self.sub_replay_expected_cursor == self.command["params"]["cursor"] or
                not self._response_valid(observed, replay_sub=True)):
            raise NaturalPageError("response_denied")
        _, query = _url_parts(observed.url, "edith.xiaohongshu.com")
        actual_cursor = query.get("cursor", [""])[0]
        if (actual_cursor != self.sub_replay_expected_cursor or
                observed.request_id in self.used_request_ids):
            raise NaturalPageError("response_denied")
        self.used_request_ids.add(observed.request_id)
        if type(observed.http_status) is int and observed.http_status >= 400:
            self._submit({"_http_status": observed.http_status})
            return "rejected"
        try:
            envelope = json.loads(observed.body.decode("utf-8"),
                                  object_pairs_hook=_json_pairs,
                                  parse_constant=_reject_constant)
        except (UnicodeError, ValueError, TypeError, RecursionError):
            raise NaturalPageError("invalid_response") from None
        if not isinstance(envelope, dict):
            raise NaturalPageError("invalid_response")
        if (envelope.get("success") is False or
                (type(envelope.get("code")) is int and envelope["code"] != 0)):
            self._submit(envelope)
            return "rejected"
        data = envelope
        for _ in range(4):
            if not isinstance(data, dict) or "comments" in data:
                break
            data = data.get("data")
        if (not isinstance(data, dict) or not isinstance(data.get("comments"), list) or
                type(data.get("has_more")) is not bool):
            raise NaturalPageError("invalid_response")
        if not data["has_more"]:
            raise NaturalPageError("pagination_unavailable")
        next_cursor = data.get("cursor")
        if (not _text(next_cursor, 512) or next_cursor == actual_cursor or
                next_cursor in self.sub_replay_seen_cursors):
            raise NaturalPageError("invalid_response")
        self.sub_replay_seen_cursors.add(actual_cursor)
        self.sub_replay_expected_cursor = next_cursor
        return ("desired_cursor_ready" if next_cursor == self.command["params"]["cursor"]
                else "replay_advanced")

    def _submit(self, envelope: dict) -> None:
        action = self.command["action"]
        if action == "search" and envelope.get("_transport") == "natural_dom":
            raise NaturalPageError("invalid_response")
        if action != "status":
            data = envelope
            for _ in range(4):
                if not isinstance(data, dict) or "items" in data or "comments" in data:
                    break
                data = data.get("data")
            key = "items" if action == "search" else "comments"
            # Platform errors still go to the parent for fixed 461/471 handling.
            rejected = (envelope.get("success") is False or
                        (type(envelope.get("code")) is int and envelope["code"] != 0) or
                        (type(envelope.get("_http_status")) is int and envelope["_http_status"] >= 400))
            if not rejected:
                if (not isinstance(data, dict) or not isinstance(data.get(key), list) or
                        type(data.get("has_more")) is not bool or
                        (action != "search" and data["has_more"] and
                         not _text(data.get("cursor"), 512))):
                    raise NaturalPageError("invalid_response")
                if action in ("comments", "sub_comments"):
                    note_id = self.command["params"]["noteId"]
                    prior_cursor = self.command["params"]["cursor"]
                    next_cursor = data.get("cursor", "") if data["has_more"] else ""
                    if next_cursor and next_cursor == prior_cursor:
                        raise NaturalPageError("invalid_response")
                    cursor_key = (action, note_id,
                                  self.command["params"].get("rootCommentId", ""),
                                  self.target_url)
                    self.next_cursors[cursor_key] = next_cursor
                    if action == "comments":
                        self._record_main_roots(note_id, data["comments"])
        self._post("/result", {"doc_epoch": self.doc_epoch,
                   "call_id": self.command["call_id"],
                   "task_epoch": self.command["task_epoch"], "envelope": envelope})
        self.phase = "idle"
        self.command = None
        self.early_response = None
        self.replay_expected_cursor = None
        self.replay_seen_cursors.clear()
        self.root_main_expected_cursor = None
        self.sub_replay_expected_cursor = None
        self.sub_replay_seen_cursors.clear()

    def cancel(self) -> None:
        """Stop accepting evidence; owner closes the window/process separately."""
        self.phase = "cancelled"
        self.command = None
        self.early_response = None
        self.replay_expected_cursor = None
        self.replay_seen_cursors.clear()
        self.root_main_expected_cursor = None
        self.sub_replay_expected_cursor = None
        self.sub_replay_seen_cursors.clear()
        self.sources.clear()
        self.observed_roots.clear()
        self.next_cursors.clear()


__all__ = ["NaturalPageController", "NaturalPageError", "ObservedResponse"]
