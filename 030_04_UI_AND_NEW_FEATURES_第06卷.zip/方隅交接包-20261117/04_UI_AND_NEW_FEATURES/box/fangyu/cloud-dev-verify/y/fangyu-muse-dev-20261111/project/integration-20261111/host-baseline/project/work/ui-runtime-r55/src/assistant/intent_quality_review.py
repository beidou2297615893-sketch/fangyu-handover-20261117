"""Local prediction-blinded quality review; no model/platform/business mutation.

The prediction is the stored software output after local policy, not the raw
provider verdict. New batch hashes do not prove its historical model input.
Labels never rewrite leads, AI/manual intent, contacts or handoffs.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import random
import re
import secrets

from core import CoreError
from core.intent_policy import normalize_policy, policy_digest, facts_summary
from core.service_plans import require_feature, ProductAccessError
from .ai_workflow import LEAD_CONTEXT_FIELDS, TASK_CONTEXT_FIELDS, model_metadata
from .platform_receipt_archive import _safe_text

BATCHES = 'intent_quality_batches'
SAMPLES = 'intent_quality_samples'
LABELS = 'intent_quality_labels'
HISTORY = 'intent_quality_label_history'
OPERATIONS = 'intent_quality_operations'
CREATE = 'intent_quality_batch_create'
LABEL = 'intent_quality_label'
STATUS = 'intent_quality_operation_status'
ACTIONS = frozenset((CREATE, LABEL, STATUS, 'intent_quality_batch_get',
                     'intent_quality_summary', 'intent_quality_batch_list'))
MUTATIONS = frozenset((CREATE, LABEL))
LEVELS = frozenset(('super_high', 'high', 'medium', 'low', 'very_low', 'uncertain', 'unrelated'))
LEVEL_ORDER = ('super_high', 'high', 'medium', 'low', 'very_low', 'uncertain', 'unrelated')
STRONG = frozenset(('super_high', 'high'))
FRAME_COUNTS = ('visible_comments', 'eligible_ai', 'missing_text', 'missing_ai', 'invalid_ai',
                'duplicate_units', 'source_conflicts', 'missing_source_identity', 'invalid_source_display', 'cohort_excluded')
_KEY = re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_ID = re.compile(r'[a-f0-9]{64}\Z')
_LOCAL = {'local_only': True, 'storage_scope': 'this_device', 'cross_machine_verified': False,
          'platform_requests_started': False, 'provider_requests_started': False,
          'ratings_modified': False, 'contacts_modified': False, 'handoffs_modified': False,
          'auto_retry': False, 'real_platform_verified': False}


class IntentQualityReviewError(CoreError):
    def __init__(self, code, message, *, mutation_committed=False):
        super().__init__(message)
        self.code = 'INTENT_QUALITY_' + code
        self.mutation_committed = mutation_committed


def _fail(code, message):
    raise IntentQualityReviewError(code, message)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


def _integer(value, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        _fail('INVALID_INPUT', '数量或版本格式无效')
    return value


def _id(value):
    if not isinstance(value, str) or not _ID.fullmatch(value):
        _fail('INVALID_INPUT', '请核对已保存的抽检编号')
    return value


def _text(value, maximum, required=False):
    if not isinstance(value, str) or len(value) > maximum or required and not value.strip():
        _fail('INVALID_INPUT', '抽检文字格式或长度无效')
    safe, changed = _safe_text(value, maximum)
    if changed:
        _fail('PRIVATE_TEXT', '抽检标注不要填写联系方式、凭据或受保护信息')
    return safe.strip()


def _timestamp(value):
    if not isinstance(value, str) or len(value) > 50:
        _fail('RECORD_INVALID', '抽检保存时间需核对')
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            raise ValueError('timezone required')
    except ValueError:
        _fail('RECORD_INVALID', '抽检保存时间需核对')
    return value


class IntentQualityReview:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access):
        if (not isinstance(tenant, str) or not tenant or not isinstance(owner, str) or not owner
                or not isinstance(company, dict) or not isinstance(company.get('id'), str)
                or not isinstance(device_id, str) or not device_id or len(device_id) > 160
                or not callable(scope_guard) or not callable(lead_access)):
            raise ValueError('抽检需要可信员工、设备、企业与原评论权限门禁')
        self.core, self.store = core, core.store
        self.tenant, self.owner, self.company = tenant, owner, company
        self.device_id, self.scope_guard, self.lead_access = device_id, scope_guard, lead_access

    def _get(self, db, entity, ident):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (entity, ident, self.tenant)).fetchone()
        if not row:
            return None
        value = json.loads(row['body'])
        if not isinstance(value, dict) or value.get('id') != ident or value.get('tenant_id') != self.tenant:
            _fail('RECORD_INVALID', '抽检保存范围需核对')
        return value

    def _put(self, db, entity, value, *, new=False):
        if new:
            db.execute('INSERT INTO records VALUES(?,?,?,?)', (entity, value['id'], self.tenant, _json(value)))
        else:
            changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                                 (_json(value), entity, value['id'], self.tenant)).rowcount
            if changed != 1:
                _fail('RECORD_INVALID', '抽检原记录需核对')

    @staticmethod
    def _actor(user):
        return {key: user.get(key) for key in ('id', 'tenant_id', 'username', 'role', 'cloud_bound')}

    def _principal(self, db, user):
        saved = self._get(db, 'users', user.get('id')) if isinstance(user, dict) else None
        if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('role') not in ('operator', 'admin') or saved.get('username') != self.owner
                or self._actor(saved) != self._actor(user)):
            _fail('FORBIDDEN', '当前抽检员工身份或归属已变化')
        try:
            valid = self.scope_guard() is True
        except Exception:
            valid = False
        if not valid:
            _fail('SCOPE_CHANGED', '当前抽检设备或员工范围需核对')
        return saved

    def _owned(self, record, actor):
        if (not isinstance(record, dict) or record.get('cloud_owner') != self.owner
                or record.get('device_id') != self.device_id or record.get('company_id') != self.company['id']
                or record.get('actor') != self._actor(actor)):
            _fail('FORBIDDEN', '原抽检的员工或设备范围需核对')
        return record

    def _base(self, ident, actor):
        return {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                'device_id': self.device_id, 'company_id': self.company['id'], 'actor': self._actor(actor)}

    def _access(self, db, lead, actor):
        if (not isinstance(lead, dict) or lead.get('demo') or lead.get('tenant_id') != self.tenant
                or lead.get('cloud_owner') not in (None, '', self.owner)):
            return False
        if lead.get('task_id'):
            task = self._get(db, 'tasks', lead['task_id'])
            if not task or task.get('cloud_owner') != self.owner:
                return False
        elif lead.get('cloud_owner') != self.owner:
            return False
        try:
            self.lead_access(actor, lead)
        except (CoreError, ValueError, PermissionError):
            return False
        return True

    def _context(self, db):
        ident = policy_digest(['intent-policy-v1', self.tenant, self.owner])
        record = self._get(db, 'intent_rule_policies', ident)
        policy = normalize_policy(record.get('policy') if record else {})
        revision = record.get('revision', 0) if record else 0
        if (type(revision) is not int or revision < 0 or record and record.get('digest') != policy_digest(policy)):
            _fail('RECORD_INVALID', '本机规则版本需核对')
        active = [(item['id'], facts_summary({**policy, 'facts': [item]})['usable_fact_count'])
                  for item in policy['facts']]
        return {'digest': _hash([revision, policy_digest(policy), active]),
                'revision': revision, 'policy_digest': policy_digest(policy)}

    @staticmethod
    def _prediction(ai):
        if not isinstance(ai, dict) or ai.get('status') not in ('graded', 'uncertain', 'unrelated'):
            return None
        level = ai.get('level')
        meta = model_metadata(ai)
        if (ai['status'] == 'graded' and level not in LEVELS - {'uncertain', 'unrelated'}
                or ai['status'] != 'graded' and level is not None or not meta
                or not isinstance(ai.get('rules_version'), str) or not 1 <= len(ai['rules_version']) <= 160
                or not isinstance(ai.get('reason'), str) or len(ai['reason']) > 3000
                or not isinstance(ai.get('evidence'), list) or len(ai['evidence']) > 30
                or any(not isinstance(value, str) or len(value) > 3000 for value in ai['evidence'])):
            return None
        try:
            _timestamp(ai.get('analyzed_at'))
        except IntentQualityReviewError:
            return None
        matching = ai.get('property_match')
        matching_state = matching.get('state', 'unknown') if isinstance(matching, dict) else 'unknown'
        if matching_state not in ('unknown', 'needs_facts', 'needs_review', 'candidate'):
            return None
        return {'level': level if ai['status'] == 'graded' else ai['status'],
                'matching_state': matching_state,
                'provider': meta['provider'], 'model': meta['model'], 'rules_version': ai['rules_version'],
                'local_policy_revision': ai.get('local_policy_revision'),
                'local_policy_digest': ai.get('local_policy_digest')}

    def _source(self, db, lead):
        task = self._get(db, 'tasks', lead['task_id']) if lead.get('task_id') else None
        fields = {key: lead.get(key) for key in (*LEAD_CONTEXT_FIELDS, 'platform', 'source_type', 'source_uid',
                  'source_id', 'comment_id', 'parent_id', 'target_comment_id', 'target_author_id')}
        return _hash([fields, {key: task.get(key) for key in TASK_CONTEXT_FIELDS} if task else None])

    def _unit(self, lead):
        platform = lead.get('platform')
        uid = lead.get('source_uid')
        if isinstance(platform, str) and isinstance(uid, str) and re.fullmatch(re.escape(platform) + r':[a-f0-9]{64}', uid):
            return uid
        if not isinstance(lead.get('comment_id'), str) or not lead['comment_id']:
            return None
        from core.platform_reads import source_reference
        try:
            post, _ = source_reference(platform, lead.get('note_url') or lead.get('url') or '')
        except ValueError:
            return None
        return platform + ':' + _hash(['comment', post, lead['comment_id']])

    def _frame(self, db, actor, cohort):
        counts = {name: 0 for name in FRAME_COUNTS}
        candidates = {}
        for row in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', ('leads', self.tenant)):
            lead = json.loads(row['body'])
            if not self._access(db, lead, actor) or lead.get('source_type') not in (None, 'comment'):
                continue
            counts['visible_comments'] += 1
            if not isinstance(lead.get('text'), str) or not lead['text'].strip() or len(lead['text']) > 3000:
                counts['missing_text'] += 1; continue
            ai = lead.get('ai_intent')
            if not ai:
                counts['missing_ai'] += 1; continue
            prediction = self._prediction(ai)
            if prediction is None:
                counts['invalid_ai'] += 1; continue
            unit = self._unit(lead)
            if not unit:
                counts['missing_source_identity'] += 1; continue
            display = {}
            invalid_display = False
            for name, field, maximum in (('text', 'text', 3000), ('parent_text', 'parent_text', 3000),
                                         ('post_title', 'content_title', 1000)):
                raw = lead.get(field, '')
                if raw is None:
                    raw = ''
                if not isinstance(raw, str) or len(raw) > maximum:
                    invalid_display = True; break
                display[name] = _safe_text(raw, maximum)[0]
            if invalid_display:
                counts['invalid_source_display'] += 1; continue
            snapshot = {'lead_id': lead['id'], 'unit': unit, 'source_digest': self._source(db, lead),
                'ai_digest': _hash(ai), 'prediction': prediction,
                'manual_evidence_digest': _hash(lead.get('manual_intent')),
                'display': display}
            candidates.setdefault(unit, []).append(snapshot)
        frame = []
        for unit in sorted(candidates):
            group = sorted(candidates[unit], key=lambda item: item['lead_id'])
            counts['duplicate_units'] += len(group) - 1
            if len({_hash([item['source_digest'], item['ai_digest']]) for item in group}) > 1:
                counts['source_conflicts'] += 1; continue
            # Resolve all versions of a comment before selecting high outputs;
            # filtering first could hide a conflicting lower prediction.
            if cohort == 'high_ai' and group[0]['prediction']['level'] not in STRONG:
                counts['cohort_excluded'] += 1; continue
            frame.append(group[0])
        counts['eligible_ai'] = len(frame)
        return frame, counts

    def _batch(self, db, ident, actor):
        return self._batch_schema(self._owned(self._get(db, BATCHES, _id(ident)), actor))

    def _batch_schema(self, batch):
        try:
            _id(batch['id'])
            if (batch['cohort'] not in ('all_ai', 'high_ai') or batch['revision'] != 1
                    or not isinstance(batch['sample_ids'], list) or len(set(batch['sample_ids'])) != len(batch['sample_ids'])
                    or not isinstance(batch['frame_counts'], dict) or set(batch['frame_counts']) != set(FRAME_COUNTS)
                    or not isinstance(batch['context'], dict)
                    or set(batch['context']) != {'digest', 'revision', 'policy_digest'}):
                raise ValueError('invalid batch')
            _integer(batch['limit'], 1, 100)
            _integer(len(batch['sample_ids']), 0, batch['limit'])
            _integer(batch['frame_count'], len(batch['sample_ids']), 10000000)
            for value in batch['frame_counts'].values():
                _integer(value, 0, 10000000)
            if batch['frame_counts']['eligible_ai'] != batch['frame_count']:
                raise ValueError('invalid frame count')
            for ident in batch['sample_ids']:
                _id(ident)
            _id(batch['context']['digest']); _id(batch['context']['policy_digest'])
            _integer(batch['context']['revision'], 0, 1000000)
            _timestamp(batch['created_at'])
        except (KeyError, TypeError, ValueError, IntentQualityReviewError):
            _fail('RECORD_INVALID', '原抽检批次需核对')
        return batch

    def _samples(self, db, batch):
        values = []
        for ident in batch['sample_ids']:
            row = self._get(db, SAMPLES, ident)
            if (not row or row.get('batch_id') != batch['id'] or row.get('display_digest') != _hash(row.get('display'))
                    or row.get('prediction_digest') != _hash(row.get('prediction'))):
                _fail('RECORD_INVALID', '原抽检样本需核对')
            try:
                for field in ('cloud_owner', 'device_id', 'company_id', 'actor'):
                    if row.get(field) != batch.get(field):
                        raise ValueError('sample owner changed')
                if (not isinstance(row['lead_id'], str) or not row['lead_id']
                        or not isinstance(row['unit'], str) or len(row['unit']) > 100
                        or row['id'] != _hash([batch['id'], row['unit']])
                        or set(row['display']) != {'text', 'parent_text', 'post_title'}
                        or set(row['prediction']) != {'level', 'matching_state', 'provider', 'model',
                            'rules_version', 'local_policy_revision', 'local_policy_digest'}
                        or row['prediction']['level'] not in LEVELS
                        or row['prediction']['matching_state'] not in ('unknown','needs_facts','needs_review','candidate')
                        or not model_metadata(row['prediction'])):
                    raise ValueError('sample shape changed')
                for field, maximum in (('text',3000),('parent_text',3000),('post_title',1000)):
                    if _safe_text(row['display'][field],maximum)[0] != row['display'][field]:
                        raise ValueError('unsafe stored display')
                _integer(row['revision'],0,1000000)
                for field in ('source_digest','ai_digest','manual_evidence_digest'):
                    _id(row[field])
            except Exception:
                _fail('RECORD_INVALID', '原抽检样本需核对')
            values.append(row)
        return values

    def _saved_label(self, db, sample, batch, actor):
        label = self._get(db, LABELS, sample['id'])
        if sample['revision'] == 0 and label is None and sample.get('label_digest') is None:
            return None
        try:
            self._owned(label, actor)
            if (label['batch_id'] != batch['id'] or label['sample_id'] != sample['id']
                    or label['revision'] != sample['revision'] or label['revision'] < 1
                    or label['human_level'] not in LEVELS or label['self_search'] not in ('yes','no','uncertain')
                    or label['matching'] not in ('matches','mismatch','insufficient')
                    or label['source_digest'] != sample['source_digest'] or label['ai_digest'] != sample['ai_digest']
                    or label['context_digest'] != batch['context']['digest']
                    or sample.get('label_digest') != _hash(label)):
                raise ValueError('label changed')
            if (_text(label['reason'],500,True) != label['reason'] or _text(label['quote'],300) != label['quote']
                    or label['quote'] and label['quote'] not in sample['display']['text']
                    or label['human_level'] in STRONG and (label['self_search'] != 'yes' or not label['quote'])):
                raise ValueError('unsafe label')
            _timestamp(label['created_at'])
            history = self._get(db,HISTORY,_hash([sample['id'],label['revision']]))
            if history != {**label,'id':_hash([sample['id'],label['revision']])}:
                raise ValueError('history changed')
        except Exception:
            _fail('RECORD_INVALID', '原人工标注版本或文字需核对')
        return label

    def _state(self, db, sample, actor):
        lead = self._get(db, 'leads', sample['lead_id'])
        if not self._access(db, lead, actor):
            return 'unavailable'
        if (self._unit(lead) != sample['unit'] or self._source(db, lead) != sample['source_digest']
                or _hash(lead.get('ai_intent')) != sample['ai_digest']):
            return 'stale'
        return 'current'

    def _create(self, db, data, actor):
        _integer(data['limit'], 1, 100)
        if data['cohort'] not in ('all_ai', 'high_ai'):
            _fail('INVALID_INPUT', '请选择全部软件意向或高意向抽检组')
        frame, counts = self._frame(db, actor, data['cohort'])
        context = self._context(db)
        seed = secrets.token_hex(32)
        chosen = random.Random(int(seed, 16)).sample(frame, min(data['limit'], len(frame)))
        ident = _hash([self.tenant, self.owner, self.device_id, data['idempotency_key'], 'batch'])
        batch = {**self._base(ident, actor), 'revision': 1, 'cohort': data['cohort'], 'limit': data['limit'],
            'frame_count': len(frame), 'frame_counts': counts,
            'frame_digest': _hash([[row['unit'], row['source_digest'], row['ai_digest']] for row in frame]),
            'selection_algorithm': 'server_seeded_random_without_replacement_v1', 'selection_seed': seed,
            'context': context, 'sample_ids': [], 'created_at': datetime.now(timezone.utc).isoformat()}
        for original in chosen:
            sid = _hash([ident, original['unit']])
            sample = {**self._base(sid, actor), **deepcopy(original), 'batch_id': ident, 'revision': 0,
                      'display_digest': _hash(original['display']), 'prediction_digest': _hash(original['prediction'])}
            self._put(db, SAMPLES, sample, new=True)
            batch['sample_ids'].append(sid)
        self._put(db, BATCHES, batch, new=True)
        for sample in self._samples(db, batch):
            if self._state(db, sample, actor) != 'current':
                _fail('SOURCE_CHANGED', '创建抽检时原评论或软件输出已变化')
        return {'batch_id': ident, 'limit': data['limit'], 'cohort': data['cohort'],
                'sample_count': len(chosen), 'frame_count': len(frame)}

    def _label(self, db, data, actor):
        batch = self._batch(db, data['batch_id'], actor)
        sample = next((row for row in self._samples(db, batch) if row['id'] == _id(data['sample_id'])), None)
        if sample is None:
            _fail('FORBIDDEN', '样本不属于本批抽检')
        if self._state(db, sample, actor) != 'current':
            _fail('SOURCE_CHANGED', '原评论或软件输出已变化，暂不能写入当前抽检')
        if self._context(db)['digest'] != batch['context']['digest']:
            _fail('CONTEXT_CHANGED', '本机规则或资料有效期已变化，请核对原批次')
        if _integer(data['expected_revision'], 0, 1000000) != sample['revision']:
            _fail('REVISION_CONFLICT', '标注版本已变化，请读取原样本')
        if (not isinstance(data['human_level'],str) or data['human_level'] not in LEVELS
                or data['self_search'] not in ('yes', 'no', 'uncertain')
                or data['matching'] not in ('matches', 'mismatch', 'insufficient')):
            _fail('INVALID_INPUT', '人工标注选项无效')
        reason, quote = _text(data['reason'], 500, True), _text(data['quote'], 300)
        if quote and quote not in sample['display']['text']:
            _fail('QUOTE_INVALID', '标注依据须是冻结的本人评论原文')
        if data['human_level'] in STRONG and (data['self_search'] != 'yes' or not quote):
            _fail('QUOTE_REQUIRED', '高意向须确认本人找房，并引用本人评论原文')
        revision = sample['revision'] + 1
        label = {**self._base(sample['id'], actor), 'batch_id': batch['id'], 'sample_id': sample['id'],
            'revision': revision, 'human_level': data['human_level'], 'self_search': data['self_search'],
            'matching': data['matching'], 'reason': reason, 'quote': quote,
            'created_at': datetime.now(timezone.utc).isoformat(), 'source_digest': sample['source_digest'],
            'ai_digest': sample['ai_digest'], 'context_digest': batch['context']['digest']}
        old = self._get(db, LABELS, sample['id'])
        self._saved_label(db,sample,batch,actor)
        self._put(db, LABELS, label, new=old is None)
        self._put(db, HISTORY, {**label, 'id': _hash([sample['id'], revision])}, new=True)
        sample['revision'] = revision
        sample['label_digest'] = _hash(label)
        self._put(db, SAMPLES, sample)
        if self._state(db, sample, actor) != 'current' or self._context(db)['digest'] != batch['context']['digest']:
            _fail('SOURCE_CHANGED', '标注提交前原来源或本机规则已变化')
        return {'batch_id': batch['id'], 'sample_id': sample['id'], 'revision': revision}

    def _opid(self, action, key):
        if not isinstance(action,str) or action not in MUTATIONS or not isinstance(key, str) or not _KEY.fullmatch(key):
            _fail('INVALID_INPUT', '请核对原操作动作与编号')
        return _hash([self.tenant, self.owner, self.device_id, action, key])

    def _receipt(self, row, actor, replayed=True):
        self._owned(row, actor)
        if row.get('state') not in ('succeeded', 'cancelled') or row.get('operation_action') not in MUTATIONS:
            _fail('RECORD_INVALID', '原抽检操作回执需核对')
        self._opid(row['operation_action'], row.get('idempotency_key'))
        if row['id'] != self._opid(row['operation_action'], row['idempotency_key']):
            _fail('RECORD_INVALID', '原抽检操作编号需核对')
        result = {}
        if row['state'] == 'succeeded':
            result = row.get('result')
            expected = ({'batch_id', 'limit', 'cohort', 'sample_count', 'frame_count'}
                        if row['operation_action'] == CREATE else {'batch_id', 'sample_id', 'revision'})
            if not isinstance(result, dict) or set(result) != expected:
                _fail('RECORD_INVALID', '原抽检结果字段需核对')
            _id(result['batch_id'])
            if row['operation_action'] == CREATE:
                _integer(result['limit'], 1, 100); _integer(result['sample_count'], 0, result['limit'])
                _integer(result['frame_count'], result['sample_count'], 10000000)
                if result['cohort'] not in ('all_ai', 'high_ai'):
                    _fail('RECORD_INVALID', '原抽检组需核对')
            else:
                _id(result['sample_id']); _integer(result['revision'], 1, 1000000)
        return {**deepcopy(result), **_LOCAL, 'operation_action': row['operation_action'],
                'idempotency_key': row['idempotency_key'], 'operation_id': row['id'],
                'state': 'succeeded' if row['state'] == 'succeeded' else 'not_committed',
                'mutation_committed': row['state'] == 'succeeded', 'replayed': replayed,
                'refresh_required': True, 'cancellation_tombstone': row['state'] == 'cancelled'}

    def _operation(self, db, action, data, actor):
        original_action = data['operation_action'] if action == STATUS else action
        ident = self._opid(original_action, data['idempotency_key'])
        previous = self._get(db, OPERATIONS, ident)
        if previous:
            result = self._receipt(previous, actor)
            if action == STATUS:
                return result
            if previous['state'] != 'succeeded':
                _fail('CANCELLED', '原编号已阻止迟到提交，请核对原操作')
            if previous.get('payload_digest') != _hash(data):
                _fail('KEY_CONFLICT', '原编号已绑定另一份抽检内容')
            return result
        if action == STATUS:
            row = {**self._base(ident, actor), 'operation_action': original_action,
                   'idempotency_key': data['idempotency_key'], 'state': 'cancelled'}
        else:
            result = self._create(db, data, actor) if action == CREATE else self._label(db, data, actor)
            row = {**self._base(ident, actor), 'operation_action': action, 'idempotency_key': data['idempotency_key'],
                   'state': 'succeeded', 'payload_digest': _hash(data), 'result': result}
        self._put(db, OPERATIONS, row, new=True)
        return self._receipt(row, actor, replayed=action == STATUS)

    def _get_batch(self, db, data, actor):
        batch = self._batch(db, data['batch_id'], actor)
        context_stale = self._context(db)['digest'] != batch['context']['digest']
        samples = []
        for sample in self._samples(db, batch):
            state = self._state(db, sample, actor)
            value = {'sample_id': sample['id'], 'revision': sample['revision'],
                     'source_state': state, 'context_stale': context_stale}
            if state == 'current':
                display = sample['display']
                value.update(text=display['text'], context_public={key: display[key] for key in ('parent_text', 'post_title')},
                             label=None)
                label = self._saved_label(db,sample,batch,actor)
                if label:
                    value['label'] = {key: label[key] for key in ('revision', 'human_level', 'self_search', 'matching', 'reason', 'quote')}
            samples.append(value)
        return {**_LOCAL, 'batch_id': batch['id'], 'revision': batch['revision'], 'name': '软件意向抽检',
            'cohort': batch['cohort'], 'prediction_hidden': True,
            'blind_scope': 'prediction_only;reviewer_may_have_seen_before',
            'evaluation_scope': 'current_stored_output_vs_current_frozen_source',
            'prediction_stage': 'post_local_policy', 'prediction_input_binding': 'legacy_unverified',
            'model_profile_live_checked': False, 'sample_count': len(samples), 'frame_count': batch['frame_count'],
            'frame_counts': batch['frame_counts'], 'created_at': batch['created_at'], 'samples': samples}

    @staticmethod
    def _metrics(pairs, recall_estimable):
        decided = [(sample, label) for sample, label in pairs
                   if label['human_level'] != 'uncertain' and label['self_search'] != 'uncertain']
        software_decided = [(sample,label) for sample,label in decided if sample['prediction']['level'] != 'uncertain']
        agreement = sum(sample['prediction']['level'] == label['human_level'] for sample, label in software_decided)
        matrix = [[0] * len(LEVEL_ORDER) for _ in LEVEL_ORDER]
        for sample,label in pairs:
            matrix[LEVEL_ORDER.index(sample['prediction']['level'])][LEVEL_ORDER.index(label['human_level'])] += 1
        tp = fp = fn = 0
        matching_total = matching_agree = 0
        for sample, label in decided:
            predicted = sample['prediction']['level'] in STRONG
            gold = label['human_level'] in STRONG and label['self_search'] == 'yes'
            tp += int(predicted and gold); fp += int(predicted and not gold); fn += int(not predicted and gold)
            if sample['prediction'].get('matching_state') == 'candidate' and label['matching'] in ('matches', 'mismatch'):
                matching_total += 1; matching_agree += int(label['matching'] == 'matches')
        return {'decisive_denominator': len(decided), 'undecided_labels': len(pairs) - len(decided),
            'labeled_pair_count':len(pairs), 'agreement_denominator':len(software_decided),
            'agreement_count': agreement, 'agreement_rate': agreement / len(software_decided) if software_decided else None,
            'software_abstention_count':len(decided)-len(software_decided),
            'software_decided_count':len(software_decided),
            'software_coverage':len(software_decided)/len(decided) if decided else None,
            'confusion_matrix':{'levels':list(LEVEL_ORDER),'rows':matrix,
                'matrix_scope':'all_labeled_pairs;human_uncertain_not_correct_or_wrong',
                'axes':'rows_software_columns_human'},
            'high_precision_denominator': tp + fp, 'high_precision': tp / (tp + fp) if tp + fp else None,
            'high_recall_denominator': tp + fn if recall_estimable else None,
            'high_recall': tp / (tp + fn) if recall_estimable and tp + fn else None,
            'recall_estimable': recall_estimable, 'true_positive': tp, 'false_positive': fp,
            'recall_scope':'frozen_sample_only;not_population_or_conversion' if recall_estimable else 'not_estimable_in_high_ai_cohort',
            'false_negative': fn if recall_estimable else None,
            'matching': {'decisive_denominator': matching_total,
                'agreement_rate': matching_agree / matching_total if matching_total else None,
                'scope': 'decisive_candidate_subset;not_inventory_or_customer_qualification'}}

    def _summary(self, db, data, actor):
        batch = self._batch(db, data['batch_id'], actor)
        context_stale = self._context(db)['digest'] != batch['context']['digest']
        samples = self._samples(db, batch)
        historical, current, comparisons = [], [], []
        stale = unavailable = labeled = 0
        for sample in samples:
            state = self._state(db, sample, actor)
            stale += int(state == 'stale'); unavailable += int(state == 'unavailable')
            label = self._saved_label(db,sample,batch,actor)
            if not label:
                continue
            labeled += 1
            # Preserve historical measurements, but never compare an inaccessible
            # source for this actor. Its historical label is retained in storage.
            if state != 'unavailable':
                historical.append((sample, label))
                comparisons.append({'sample_id':sample['id'],'prediction_level':sample['prediction']['level'],
                    'human_level':label['human_level'],'source_state':state,'context_stale':context_stale})
            if state == 'current' and not context_stale:
                current.append((sample, label))
        recall = batch['cohort'] == 'all_ai'
        return {**_LOCAL, 'batch_id': batch['id'], 'cohort': batch['cohort'], 'sample_count': len(samples),
            'frame_count': batch['frame_count'], 'frame_counts': batch['frame_counts'], 'labeled_count': labeled,
            'unlabeled_count': len(samples) - labeled, 'stale_count': stale, 'unavailable_count': unavailable,
            'context_stale_count': len(samples) if context_stale else 0,
            'historical': self._metrics(historical, recall), 'current': self._metrics(current, recall),
            'comparisons':comparisons,
            'metrics_scope': 'this_frozen_local_comment_sample',
            'evaluation_scope': 'current_stored_output_vs_current_frozen_source',
            'prediction_stage': 'post_local_policy', 'prediction_input_binding': 'legacy_unverified',
            'model_profile_live_checked': False, 'human_labels_independently_verified': False,
            'conversion_rate': None, 'orders_verified': False, 'revenue_verified': False,
            'revenue_cents': None, 'settlement_cents': None}

    def _list(self, db, data, actor):
        offset, limit = _integer(data['offset'], 0, 10000000), _integer(data['limit'], 1, 20)
        items = []
        for row in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (BATCHES, self.tenant)):
            batch = json.loads(row['body'])
            if (batch.get('cloud_owner') != self.owner or batch.get('company_id') != self.company['id']
                    or (batch.get('actor') or {}).get('id') != actor['id']):
                continue
            self._batch_schema(batch)
            items.append({'batch_id': batch['id'], 'cohort': batch['cohort'],
                          'sample_count': len(batch['sample_ids']), 'created_at': batch['created_at'],
                          'scope_matches': batch.get('device_id') == self.device_id and batch.get('actor') == self._actor(actor)})
        items.sort(key=lambda value: (value['created_at'], value['batch_id']), reverse=True)
        return {**_LOCAL, 'items': items[offset:offset + limit], 'total': len(items)}

    def execute(self, action, data, user):
        allowed = {CREATE: {'limit', 'cohort', 'idempotency_key'}, LABEL: {'batch_id', 'sample_id', 'expected_revision',
            'human_level', 'self_search', 'matching', 'reason', 'quote', 'idempotency_key'},
            STATUS: {'operation_action', 'idempotency_key'}, 'intent_quality_batch_get': {'batch_id'},
            'intent_quality_summary': {'batch_id'}, 'intent_quality_batch_list': {'offset', 'limit'}}
        if not isinstance(action,str) or action not in ACTIONS or not isinstance(data, dict) or set(data) != allowed[action]:
            _fail('INVALID_INPUT', '抽检参数仅接受规定字段，不接受原评论或预测')
        try:
            encoded=_json(data).encode('utf-8')
        except (ValueError,TypeError):
            _fail('INVALID_INPUT','抽检参数格式无效')
        if len(encoded) > 12000:
            _fail('INVALID_INPUT','抽检资料过长')
        try:
            with self.core.lock:
                with self.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE')
                    actor = self._principal(db, user)
                    if action == CREATE:
                        require_feature(self.company, 'intent_analysis')
                    if action in MUTATIONS or action == STATUS:
                        result = self._operation(db, action, data, actor)
                    elif action == 'intent_quality_batch_get':
                        result = self._get_batch(db, data, actor)
                    elif action == 'intent_quality_summary':
                        result = self._summary(db, data, actor)
                    else:
                        result = self._list(db, data, actor)
                    self._principal(db, user)
                    if action == CREATE:
                        require_feature(self.company, 'intent_analysis')
                    if action in MUTATIONS and result['replayed'] is False:
                        batch=self._batch(db,result['batch_id'],actor)
                        if self._context(db)['digest'] != batch['context']['digest']:
                            _fail('CONTEXT_CHANGED','提交前本机规则或资料有效期已变化')
                        for sample in self._samples(db,batch):
                            if action == CREATE or sample['id'] == result.get('sample_id'):
                                if self._state(db,sample,actor) != 'current':
                                    _fail('SOURCE_CHANGED','提交前原评论或软件输出已变化')
                                self._saved_label(db,sample,batch,actor)
            return result
        except IntentQualityReviewError:
            raise
        except ProductAccessError:
            _fail('ENTITLEMENT', '新建抽检需有效意向分析权益；历史记录与本机人工标注仍可核对')
        except Exception:
            raise IntentQualityReviewError('STORAGE_UNKNOWN', '抽检保存或读取结果未确认，请保留原操作编号',
                                           mutation_committed=None) from None
