"""Typed, bounded livestream admission into the existing employee Store.

Only a host-owned transport may supply originals. Browser requests never carry
frames, identity proofs, observations or a transport selector. Digests here are
local consistency checks, not cryptographic platform attestations.
"""
from copy import deepcopy
from datetime import datetime,timezone
import hashlib,json,re
from uuid import uuid4

REQUESTS='livestream_capture_requests_v1'
OBSERVATIONS='livestream_message_observations_v1'
CONFLICTS='livestream_message_conflicts_v1'
CONTRACT='fangyu-live-admission-v1'
ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
REQUEST=re.compile(r'[A-Za-z0-9_-]{16,80}\Z')
UINT=re.compile(r'[1-9][0-9]{0,19}\Z')

class LiveError(ValueError):
 def __init__(self,code,message,status=409):super().__init__(message);self.code,self.status=code,status
def fail(code,message,status=409):raise LiveError(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def number(value):return isinstance(value,str) and bool(UINT.fullmatch(value)) and int(value)<=18446744073709551615
def stamp():return datetime.now(timezone.utc).isoformat()
def get(db,entity,ident,tenant):
 row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,ident,tenant)).fetchone()
 return json.loads(row['body']) if row else None
def put(db,entity,row):db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))
def binding(account):return {k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id','status','auth_generation','identity_revalidation_generation')}

class LivestreamAdmission:
 def __init__(self,core):self.core,self.store=core,core.store
 def _actor(self,db,user,store,authority,account=None):
  saved=get(db,'users',user.get('id'),user.get('tenant_id'))
  if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
      or saved.get('development_local_only') is True or saved.get('role') not in ('admin','operator')
      or any(saved.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
      or not callable(authority) or authority(db,saved,store) is not True):
   fail('LIVE_SCOPE_FORBIDDEN','员工或当前门店授权已变化；原请求保留',403)
  if account is not None:
   current=get(db,'accounts',account['id'],saved['tenant_id'])
   if (not current or binding(current)!=binding(account) or current.get('cloud_owner')!=saved['username']
       or current.get('store_id')!=store or current.get('platform')!='douyin' or current.get('status')!='ready'
       or not number(current.get('platform_uid')) or not ID.fullmatch(str(current.get('conn_id') or ''))):
    fail('LIVE_ACCOUNT_CHANGED','直播采集账号或固定窗口已变化；未接纳新消息',403)
   self.core._account_access(saved,current)
  return saved
 def _key(self,user,request):return digest([CONTRACT,user['tenant_id'],user['id'],request])
 def _view(self,row):
  fields=('requestId','state','accountId','webRid','createdAt','finishedAt','counts','code','message','complete','sourceType','stage','sourceId','sourceVersion','liveConnId','taskId','analysis','gap','gapObservedAt','gapEndUnknown')
  result={**{k:deepcopy(row[k]) for k in fields if k in row},'commentReplyAllowed':False}
  if row.get('taskId'):
   task=self.store.get('tasks',row['taskId']);job=self.store.get('ai_jobs',row['taskId']) or {}
   if task and all(task.get(k)==row.get(v) for k,v in (('tenant_id','tenant_id'),('cloud_owner','owner'),('store_id','storeId'),('livestream_collection_account_id','accountId'))):
    leads=[self.store.get('leads',k) for k in row.get('importedLeadIds',[])]
    pending=sum(1 for lead in leads if lead and not (lead.get('manual_intent') or lead.get('ai_intent')))
    result['analysis']={'status':job.get('status','pending'),'code':job.get('code',''),'message':job.get('message','已进入原意向分析队列；企业AI未就绪或结果待核时保留原请求'),'pending':pending,'analyzed':len(leads)-pending}
    result['counts']={**result.get('counts',{}),'pendingAnalysis':pending,'analyzed':len(leads)-pending}
  return result
 def read(self,user,store,request,*,authority):
  if not isinstance(request,str) or not REQUEST.fullmatch(request):fail('LIVE_INPUT_INVALID','请保留原直播采集编号',400)
  with self.store.connect() as db:
   self._actor(db,user,store,authority);row=get(db,REQUESTS,self._key(user,request),user['tenant_id'])
   if row is None:return {'requestId':request,'state':'not_started','message':'未找到原采集回执；不会自动开始或更换编号','commentReplyAllowed':False}
   if row.get('storeId')!=store or row.get('owner')!=user['username'] or row.get('ownerId')!=user['id']:fail('LIVE_SCOPE_FORBIDDEN','原直播采集不属于当前员工门店',403)
   return {**self._view(row),'replayed':True}
 def capture(self,user,store,account,data,*,authority,guard,transport):
  if (not isinstance(data,dict) or set(data)!={'storeId','accountId','webRid','requestId','timeoutMs','confirmed','sourceId','sourceVersion','liveConnId','bridgeSelectionId','city','area','intentPolicySnapshot','localPromptVersion'}
      or data['storeId']!=store or data['accountId']!=account.get('id') or data['confirmed'] is not True
      or not isinstance(data['requestId'],str) or not REQUEST.fullmatch(data['requestId'])
      or not number(data['webRid']) or type(data['timeoutMs']) is not int or not 100<=data['timeoutMs']<=20000
      or not isinstance(data.get('city'),str) or not data['city'].strip().removesuffix('市').strip() or len(data['city'])>80 or not isinstance(data.get('area'),str) or len(data['area'])>80
      or not callable(guard) or not callable(transport)):
   fail('LIVE_INPUT_INVALID','请确认本人账号、直播间和一次有界采集；不接受消息或验证凭据上传',400)
  tenant=user['tenant_id'];key=self._key(user,data['requestId']);signature=digest([data,binding(account)])
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self._actor(db,user,store,authority,account)
   old=get(db,REQUESTS,key,tenant)
   if old:
    if old.get('signature')!=signature or old.get('storeId')!=store:fail('LIVE_ORIGINAL_INPUT_CHANGED','原直播采集条件已变化；请保留原编号',409)
    return {**self._view(old),'replayed':True}
   for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(REQUESTS,tenant)):
    pending=json.loads(item['body'])
    if (pending.get('owner')==user['username'] and pending.get('storeId')==store and pending.get('accountId')==account['id']
        and pending.get('webRid')==data['webRid'] and pending.get('state')=='unknown'):
     fail('LIVE_ORIGINAL_UNKNOWN','这个账号和直播间的原采集结果待核对；请查询原编号，不会重新读取',409)
  # The existing atomic mode gate precedes capability checks and every CLI read.
  guard();owner='live:'+key;self.core.acquire_account_mode(account['id'],tenant,'collection',owner)
  try:
   guard()
   with self.store.connect() as db:
    db.execute('BEGIN IMMEDIATE');self._actor(db,user,store,authority,account)
    old=get(db,REQUESTS,key,tenant)
    if old:
     if old.get('signature')!=signature:fail('LIVE_ORIGINAL_INPUT_CHANGED','原编号条件已变化',409)
     return {**self._view(old),'replayed':True}
    for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(REQUESTS,tenant)):
     pending=json.loads(item['body'])
     if (pending.get('owner')==user['username'] and pending.get('storeId')==store and pending.get('accountId')==account['id'] and pending.get('webRid')==data['webRid'] and pending.get('state')=='unknown'):
      fail('LIVE_ORIGINAL_UNKNOWN','原直播采集结果待核对，请查询原编号',409)
    row={'id':key,'tenant_id':tenant,'owner':user['username'],'ownerId':user['id'],'storeId':store,
     'accountId':account['id'],'accountBinding':binding(account),'webRid':data['webRid'],'requestId':data['requestId'],
     'signature':signature,'sourceId':data['sourceId'],'sourceVersion':data['sourceVersion'],'liveConnId':data['liveConnId'],'stage':'reading','state':'unknown','sourceType':'livestream_chat','complete':False,'createdAt':stamp(),
     'code':'LIVE_RESULT_UNKNOWN','message':'原直播采集结果待核对；不会自动重连或重提'}
    put(db,REQUESTS,row)
   guard()
   result=transport(account,data,guard)
   guard()
   if isinstance(result,dict) and result.get('state')=='rejected':
    code=result.get('code','LIVE_RESULT_UNCONFIRMED');message=result.get('message','原直播采集结果待核对，请保留原编号')
    with self.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');self._actor(db,user,store,authority,account);current=get(db,REQUESTS,key,tenant)
     if current==row:
      current.update(code=code,message=message,stage='held')
      if code=='LIVE_STREAM_GAP':
       # Observation time is not a guessed platform message/gap start time.
       current.update(gap=True,gapObservedAt=stamp(),gapEndUnknown=True,
        message='直播连接在本次采集中断，存在未接收消息的缺口；原结果待核对，不会自动重连或重新采集')
      put(db,REQUESTS,current)
    fail(code,message,409)
   if isinstance(result,dict) and result.get('state')=='not_integrated' and result.get('contract')==CONTRACT:
    with self.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');self._actor(db,user,store,authority,account)
     row=get(db,REQUESTS,key,tenant);row.update(state='blocked',finishedAt=stamp(),code='LIVE_TRANSPORT_MISSING',message='受控浏览器尚未提供直播原始帧通道；没有接收平台消息，也未接通真实直播采集')
     put(db,REQUESTS,row)
    return self._view(row)
   return self._admit(user,store,account,data,row,result,authority,guard)
  finally:self.core.release_account_mode(account['id'],tenant,owner)
 def _admit(self,user,store,account,data,receipt,result,authority,guard):
  if (not isinstance(result,dict) or result.get('contract')!=CONTRACT or result.get('state')!='received'
      or result.get('requestId')!=data['requestId'] or result.get('accountUid')!=account['platform_uid']
      or result.get('parentConnId')!=account['conn_id'] or result.get('connId')!=data['liveConnId'] or result.get('selectionId')!=data['bridgeSelectionId'] or result.get('webRid')!=data['webRid']
      or not number(result.get('internalRoomId')) or (result.get('observerKind')=='cdp' and (not all(isinstance(result.get(k),str) and 1<=len(result[k])<=160 for k in ('targetId','wsRequestId')) or 'documentId' in result or 'socketId' in result))
      or (result.get('observerKind')=='page-websocket' and (not all(isinstance(result.get(k),str) and 1<=len(result[k])<=160 for k in ('documentId','socketId')) or not result['socketId'].startswith(result['documentId']+':socket:') or 'targetId' in result or 'wsRequestId' in result or result.get('roomUrl')!='https://live.douyin.com/'+data['webRid']))
      or result.get('observerKind') not in ('cdp','page-websocket') or result.get('complete') is not False or not isinstance(result.get('messages'),list) or len(result['messages'])>200):
   fail('LIVE_FRAME_SCOPE_INVALID','直播原始帧与本人账号、房间或原请求不符；原结果待核对',409)
  incoming=[]
  for item in result['messages']:
   if (not isinstance(item,dict) or set(item)!={'id','roomId','userId','nickname','text','publishedAt'}
       or not number(item['id']) or not number(item['userId']) or item['roomId']!=result['internalRoomId']
       or not isinstance(item['text'],str) or not item['text'].strip() or len(item['text'])>3000
       or not isinstance(item['nickname'],str) or len(item['nickname'])>100 or not isinstance(item['publishedAt'],str)):
    fail('LIVE_MESSAGE_INVALID','直播消息缺少稳定编号、原文或房间依据；整批未接纳',409)
   if item['publishedAt']:
    try:
     when=datetime.fromisoformat(item['publishedAt'].replace('Z','+00:00'))
     if when.tzinfo is None or not 2000<=when.year<=2100:raise ValueError()
    except ValueError:fail('LIVE_MESSAGE_TIME_INVALID','直播消息来源时间无法核对；不以接收时间冒充发送时间',409)
   incoming.append(item)
  guard();tenant=user['tenant_id'];task_id=str(uuid4());imported=[];counts={'imported':0,'linkedExisting':0,'observations':0,'conflicts':0,'receivedMessages':len(incoming),'pendingAnalysis':0};observed=stamp()
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');actor=self._actor(db,user,store,authority,account)
   current=get(db,REQUESTS,receipt['id'],tenant)
   if current!=receipt:fail('LIVE_REQUEST_CHANGED','原采集回执已变化；本次未接纳消息',409)
   mode=get(db,'account_modes',account['id'],tenant)
   if not mode or mode.get('status')!='active' or mode.get('mode')!='collection' or mode.get('owner')!='live:'+receipt['id'] or mode.get('runtime_id')!=self.core.continuous.leases.runtime_id:fail('LIVE_MODE_CHANGED','账号采集占用已变化；未接纳消息',409)
   for item in incoming:
    source='live-chat:'+item['roomId']+':'+item['id']
    found=db.execute('SELECT r.body FROM unique_leads u JOIN records r ON r.entity=? AND r.id=u.lead_id AND r.tenant_id=u.tenant_id WHERE u.tenant_id=? AND u.platform=? AND u.source_id=?',('leads',tenant,'douyin',source)).fetchone()
    lead=json.loads(found['body']) if found else None
    facts={'roomId':item['roomId'],'messageId':item['id'],'webRid':data['webRid'],'userId':item['userId'],'text':item['text'],'publishedAt':item['publishedAt'],'sourceTimeStatus':'provided' if item['publishedAt'] else 'unknown'}
    if lead is not None:
     if lead.get('cloud_owner')!=actor['username'] or lead.get('store_id')!=store:continue
     original=deepcopy(lead.get('live_source',{}).get('original'))
     if isinstance(original,dict):original.setdefault('sourceTimeStatus','provided' if original.get('publishedAt') else 'unknown')
     if original!=facts:
      conflict={'id':digest([tenant,receipt['id'],source,facts]),'tenant_id':tenant,'cloud_owner':actor['username'],'store_id':store,'account_id':account['id'],'request_id':data['requestId'],'source_id':source,'lead_id':lead['id'],'incoming':deepcopy(facts),'observed_at':observed}
      if get(db,CONFLICTS,conflict['id'],tenant) is None:put(db,CONFLICTS,conflict);counts['conflicts']+=1
      continue
     counts['linkedExisting']+=1
    else:
     lead={'id':str(uuid4()),'tenant_id':tenant,'cloud_owner':actor['username'],'store_id':store,'platform':'douyin','source_id':source,
      'source_type':'livestream_chat','task_id':task_id,'author_id':item['userId'],'author':item['nickname'],'text':item['text'],'title':'直播间聊天原文',
      'url':'https://live.douyin.com/'+data['webRid'],'note_url':'','content_title':'直播间 '+data['webRid']+' 聊天消息（非视频评论；房间话题未提供）','published_at':item['publishedAt'],'created_at':observed,
      'reply_status':'未回复','analysis_status':'pending','stage':'待核实直播需求','grade':'C',
      'live_source':{'contract':CONTRACT,'original':deepcopy(facts),'requestId':data['requestId'],'accountId':account['id'],
       'accountUid':account['platform_uid'],'connId':account['conn_id'],'parentConnId':account['conn_id'],'liveConnId':data['liveConnId'],'sourceId':data['sourceId'],'sourceVersion':data['sourceVersion'],'observerKind':result['observerKind'],**({k:result[k] for k in ('targetId','wsRequestId')} if result['observerKind']=='cdp' else {k:result[k] for k in ('documentId','socketId','observerVersion','roomUrl','wsOrigin','wsPath')}),'observedAt':observed}}
     self.core.require_platform('douyin');self.core._validate_lead(lead);self.core._classify(lead,tenant)
     db.execute('INSERT INTO unique_leads VALUES(?,?,?,?)',(tenant,'douyin',source,lead['id']));put(db,'leads',lead);counts['imported']+=1;counts['pendingAnalysis']+=1;imported.append(lead['id'])
    observation={'id':digest([tenant,actor['username'],store,account['id'],data['requestId'],source]),'tenant_id':tenant,'cloud_owner':actor['username'],'store_id':store,'account_id':account['id'],'request_id':data['requestId'],'source_id':source,'lead_id':lead['id'],'originalDigest':digest(facts),'observed_at':observed}
    if get(db,OBSERVATIONS,observation['id'],tenant) is None:put(db,OBSERVATIONS,observation);counts['observations']+=1
   if imported:
    # Original tasks + original AIWorker queue, committed with the new leads.
    # This typed task cannot be run as a video-comment/search task.
    task={'id':task_id,'tenant_id':tenant,'cloud_owner':actor['username'],'store_id':store,'account_id':'','livestream_collection_account_id':account['id'],'platform':'douyin','scope':'livestream_chat','livestream_only':True,'livestream_source_id':data['sourceId'],'livestream_source_version':data['sourceVersion'],'livestream_request_id':data['requestId'],'livestream_intent_policy':deepcopy(data['intentPolicySnapshot']),'livestream_local_prompt_version':data['localPromptVersion'],'city':data['city'],'area':data['area'],'name':'直播聊天意向分析','status':'ready','keywords':[],'excludes':[],'note_url':'','continuous_enabled':False,'created_at':observed,'updated_at':observed}
    put(db,'tasks',task)
    put(db,'ai_jobs',{'id':task_id,'tenant_id':tenant,'task_id':task_id,'owner':actor['username'],'store_id':store,'status':'pending','code':'','pending':len(imported),'retry_count':0,'message':'直播聊天已进入原意向分析队列','updated_at':observed})
    current.update(taskId=task_id,importedLeadIds=imported)
   current.update(state='received',stage='saved',finishedAt=stamp(),counts=counts,code='LIVE_LOCAL_CAPTURE_SAVED',message='本次有界直播聊天已保存；不代表完整直播历史，不提供评论回复',complete=False)
   put(db,REQUESTS,current)
  return self._view(current)
