"""One owned WebView2 window for a pre-authorized, already journaled reply.

The helper never submits a comment. Its result is evidence from a passive CDP
observer, scoped to one immutable approved reply and one account profile.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import stat
import sys
import time

from .native_contact_observer import NativeContactError, NativeContactObserver
from .tracked_reply_window import ReplyWindowSpec, _note_url


def read_spec(path):
    path=Path(path)
    if (path.name!='spec.json' or path.is_symlink() or path.stat().st_size>8192 or
            getattr(os.lstat(path),'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
        raise ValueError('reply_spec_invalid')
    raw=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(raw,dict) or set(raw)!={'scope','note_url','profile_dir'}:
        raise ValueError('reply_spec_invalid')
    scope=raw['scope']
    if not isinstance(scope,dict) or set(scope)!=set(ReplyWindowSpec.__dataclass_fields__):
        raise ValueError('reply_spec_invalid')
    spec=ReplyWindowSpec(**scope)
    note_url=raw['note_url']
    if not _note_url(note_url,spec.note_id):raise ValueError('reply_note_invalid')
    profile=Path(raw['profile_dir'])
    if (not profile.is_absolute() or profile.name!='xhs-browser-profile'
            or path.parent.parent.parent.parent!=profile.parent
            or profile.is_symlink()):
        raise ValueError('reply_profile_invalid')
    for candidate in (profile.parent,profile,path.parent,path.parent.parent,path.parent.parent.parent):
        if candidate.is_symlink() or (hasattr(candidate,'is_junction') and candidate.is_junction()):
            raise ValueError('reply_profile_invalid')
    return spec,note_url,profile


def run(spec_path):
    spec,note_url,profile=read_spec(spec_path)
    import webview
    outcome={'outcome':'unknown','platform_comment_id':'','snapshot_hash':'',
             'reason':'window_closed'}
    window=webview.create_window('小红书 · 仅回复已审核评论',note_url,
                                 width=900,height=740,js_api=None,hidden=True)
    observer=NativeContactObserver(window,spec=spec)
    state={'attached':False}
    def attach_after_loaded():
        if state['attached']:return
        try:
            observer.attach();state['attached']=True
            window.show()
        except NativeContactError:
            outcome['reason']='observer_unavailable'
            window.destroy()
    def loaded():
        # CDP attach waits for UI Invoke, so never block pywebview's event thread.
        import threading
        threading.Thread(target=attach_after_loaded,name='owned-reply-attach',daemon=True).start()
    def watch():
        deadline=time.monotonic()+300
        while time.monotonic()<deadline:
            if state['attached']:
                try:observations=observer.poll()
                except NativeContactError:
                    outcome['reason']='observer_unavailable';window.destroy();return
                for item in observations:
                    if (item.get('content')!=spec.expected_content or
                            item.get('account_uid')!=spec.account_uid or
                            item.get('note_id')!=spec.note_id or
                            item.get('target_comment_id')!=spec.target_comment_id):
                        outcome['reason']='observation_mismatch';window.destroy();return
                    if item.get('outcome')=='sent' and item.get('platform_comment_id'):
                        outcome.update(outcome='sent',platform_comment_id=item['platform_comment_id'],
                                       snapshot_hash=item['snapshot_hash'],reason='matched_platform_success')
                    elif item.get('outcome')=='failed':
                        outcome['reason']='platform_rejected'
                    else:outcome['reason']='platform_result_unknown'
                    window.destroy();return
            time.sleep(.1)
        outcome['reason']='window_timeout';window.destroy()
    window.events.loaded+=loaded
    try:
        import threading
        threading.Thread(target=watch,name='owned-reply-observer',daemon=True).start()
        webview.start(gui='edgechromium',private_mode=False,storage_path=str(profile),debug=False)
    except Exception:outcome['reason']='window_failed'
    finally:observer.close()
    return outcome


def main(argv=None):
    argv=sys.argv[1:] if argv is None else argv
    if len(argv)!=2 or argv[0]!='--spec':return 2
    try:
        path=Path(argv[1]);result=run(path)
        marker=path.parent/'outcome.json'
        temp=path.parent/'outcome.tmp'
        with temp.open('x',encoding='utf-8') as stream:
            json.dump(result,stream,separators=(',',':'))
            stream.flush();os.fsync(stream.fileno())
        os.replace(temp,marker)
        return 0
    except Exception:return 2


if __name__=='__main__':raise SystemExit(main())
