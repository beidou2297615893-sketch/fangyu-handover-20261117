"""Review candidate: actual parent authority and private Weibo source normalization.

No runtime is installed by this module. Its public facade remains held by the
actual production guard. The owned child uses the original app namespace and
dispatch. Weibo component review and a verified packaged binary are still missing.
The source capability is host-only, never constructed from an HTTP/RPC body.
"""
from copy import deepcopy
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
from pathlib import Path
import re
import secrets
import threading

from assistant.employee_workspace import require_owner
from core.platform_reads import _REQUEST, _digest as _read_fingerprint
from core.runtime_license_policy import RuntimeLicensePolicy
from core.service_plans import require_feature
from core.owned_search_post_index import OwnedSearchScope, _valid_scope
from core.weibo_read_contract import AccountBinding, _items, _map, _map_comments, _known_post_url

_IDENTITY = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
_ACCOUNT = ('id', 'tenant_id', 'cloud_owner', 'platform', 'platform_uid', 'conn_id',
            'status', 'revision', 'updated_at')
_ID = re.compile(r'[A-Za-z0-9_.-]{1,128}')
_MID = re.compile(r'[1-9][0-9]{0,31}')
_MAX_PRIVATE_OUTPUT = 1024 * 1024


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def _fingerprint(value):
    return sha256(_canonical(value)).hexdigest()


class HostRouteStopped(ValueError):
    """Only a fixed code crosses the public boundary; no raw exception text."""
    def __init__(self, code):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True, repr=False)
class CurrentParentScope:
    tenant_id: str
    owner_id: str
    device_id: str
    company_id: str
    environment_id: str
    account_id: str
    account_root: Path
    account_revision: str
    permission_revision: int


class OwnedWeiboHostCandidate:
    """Trusted Python host only; account/actor are selected before any client data.

    This implements the real parent half of a future live IPC guard. It does
    not accept authorization functions, review dictionaries, runtime permits,
    identity proof, credentials, raw posts or receipts from the caller.
    """
    def __init__(self, server, actor, account_id):
        if (type(actor) is not dict or not isinstance(account_id, str)
                or not _ID.fullmatch(account_id)):
            raise HostRouteStopped('parent_selection_invalid')
        self._server, self._actor, self._account_id = server, deepcopy(actor), account_id
        self._assistant = getattr(server, 'assistant_service', None)
        self._executor = getattr(self._assistant, 'executor', None)
        self._review_policy = getattr(server, '_runtime_license_policy', None)
        self._reads, self._receipt_adapter = None, None
        self._identity_receipt_id = None
        self._registration_handoff = None
        self._child_state = threading.local()
        self._owned_shutdown = None
        self._owned_shutdown_phase = 'idle'
        self._initial = self._read_parent()

    def _read_parent(self):
        server, selected = self._server, self._actor
        try:
            with server.core.lock:
                saved = server.core.store.get('users', selected.get('id'))
                if (type(saved) is not dict or saved.get('disabled')
                        or saved.get('development_local_only') is True
                        or saved.get('role') not in ('operator', 'admin')
                        or saved.get('cloud_bound') is not True
                        or any(saved.get(k) != selected.get(k) for k in _IDENTITY)):
                    raise HostRouteStopped('parent_actor_changed')
                account = server.core._get('accounts', self._account_id, saved['tenant_id'])
                server.core._account_access(saved, account)
                if account.get('platform') != 'weibo':
                    raise HostRouteStopped('parent_account_changed')
                assistant = getattr(server, 'assistant_service', None)
                if assistant is not self._assistant or assistant is None:
                    raise HostRouteStopped('parent_executor_changed')
                own = require_owner(server, saved)
                with assistant.lock:
                    executor, device = assistant.executor, dict(assistant.device or {})
                    if (executor is not self._executor or executor is None
                            or assistant.state not in ('online', 'held')
                            or executor.owner != saved['username'] or executor.tenant != saved['tenant_id']):
                        raise HostRouteStopped('parent_executor_changed')
                    if device.get('id') != own.get('device_id') or device.get('owner') != saved['username']:
                        raise HostRouteStopped('parent_device_changed')
                    binding = assistant.vault.read()
                    company = server.company
                    environment = (company.get('managedWorkspace') or {}).get('environment_id')
                    if (type(binding) is not dict or not environment or not company.get('id')
                            or binding.get('state') != 'bound' or binding.get('company_id') != company['id']
                            or binding.get('environment_id') != environment):
                        raise HostRouteStopped('parent_company_changed')
                    enrolled = binding.get('device') or {}
                    if (enrolled.get('id') != device.get('id')
                            or enrolled.get('owner') != saved['username']):
                        raise HostRouteStopped('parent_device_changed')
                    if (hasattr(self, '_initial') and device.get('id') != self._initial.device_id):
                        raise HostRouteStopped('parent_device_changed')
                    policy = getattr(server, '_runtime_license_policy', None)
                    if (type(policy) is not RuntimeLicensePolicy or policy is not self._review_policy
                            or policy._server is not server):
                        raise HostRouteStopped('runtime_review_authority_unavailable')
                    # Invoke the existing implementation; an arbitrary server
                    # field {'weibo': True} cannot become a component review.
                    component = RuntimeLicensePolicy.resolve(policy)
                    entitlement = require_feature(company, 'acquisition')
                    tenant, owner = saved['tenant_id'], saved['username']
                    if any(not isinstance(v, str) or not _ID.fullmatch(v)
                           for v in (tenant, owner, account['id'])):
                        raise HostRouteStopped('parent_selection_invalid')
                    root = Path(server.core.store.directory).resolve() / 'accounts' / tenant / account['id']
                    account_revision = _fingerprint({k: account.get(k) for k in _ACCOUNT})
                    permission_revision = int(_fingerprint([
                        {k: saved.get(k) for k in _IDENTITY}, device.get('id'),
                        company['id'], environment, entitlement, component,
                        company.get('runtime') or {}, company.get('releaseVersion'),
                        company.get('edition'), company.get('authMode')]), 16)
                    return CurrentParentScope(tenant, owner, device['id'], company['id'],
                        environment, account['id'], root, account_revision, permission_revision)
        except HostRouteStopped:
            raise
        except Exception:
            raise HostRouteStopped('parent_authority_unavailable') from None

    def current_parent_scope(self):
        current = self._read_parent()
        if current != self._initial:
            raise HostRouteStopped('parent_scope_changed')
        return current

    def _require_connected(self):
        request_id=getattr(self._child_state,'self_request_id',None)
        if request_id is not None:
            # Every self child authority callback sees the original cancelled
            # entry; no new request or identity is installed by this check.
            with self._owned_self_admission(request_id):pass
        self.current_parent_scope()
        if self._owned_shutdown_phase == 'exit_pending':
            raise HostRouteStopped('owned_weibo_child_exit_pending')
        if self._server.core.adapters.closed:
            raise HostRouteStopped('owned_weibo_host_closed')
        try:
            self._server.core._platform_execution_guard('weibo')
            self._server._platform_execution_guard('weibo')
        except Exception:
            raise HostRouteStopped('production_weibo_unavailable') from None
        component = RuntimeLicensePolicy.resolve(self._review_policy)
        if not isinstance(component, dict) or component.get('weibo') is not True:
            raise HostRouteStopped('weibo_component_review_unavailable')
        # The existing review policy currently resolves XHS only. This source
        # candidate adds a fixed owned channel, never a component entitlement.
        from assistant.owned_weibo_ipc import fixed_runner_argv
        fixed_runner_argv()

    def complete_owned_shutdown(self):
        """Same-owner-thread completion, as the existing fixed owned helper.

        Pending retains the exact child and all original lock/lease contexts;
        no new operation or outer service finally runs before this confirms it.
        """
        if self._owned_shutdown is not None:
            self._owned_shutdown.complete()

    def owned_shutdown_status(self):
        return {'state': self._owned_shutdown_phase, 'auto_retry': False}

    def live_authority(self, binding, operation):
        if operation not in ('search', 'comments') or not isinstance(binding, AccountBinding):
            raise HostRouteStopped('owned_weibo_binding_invalid')
        parent = self.current_parent_scope()
        if (binding.identity_verified is not True or Path(binding.account_root) != parent.account_root
                or binding.tenant_id != parent.tenant_id or binding.account_id != parent.account_id):
            raise HostRouteStopped('owned_weibo_binding_invalid')
        self._require_connected()
        if self.current_binding() != binding:
            raise HostRouteStopped('owned_weibo_binding_changed')
        scope = OwnedSearchScope(parent.tenant_id, parent.owner_id, parent.device_id,
            parent.account_id, parent.account_root, binding.platform_uid,
            binding.credential_sha256, parent.permission_revision)
        if not _valid_scope(scope):
            raise HostRouteStopped('owned_weibo_scope_changed')
        return scope

    @staticmethod
    def _owned_proof_binding(proof, parent):
        """Validate the fixed owned-child proof, without installing any scope."""
        from core.weibo_read_contract import VerifiedIdentity
        if type(proof) is not dict or set(proof) != set(VerifiedIdentity.__dataclass_fields__):
            raise HostRouteStopped('owned_weibo_identity_invalid')
        if (proof.get('tenant_id') != parent.tenant_id or proof.get('owner') != parent.owner_id
                or proof.get('device_id') != parent.device_id or proof.get('account_id') != parent.account_id
                or proof.get('account_revision') != parent.account_revision
                or proof.get('license_revision') != str(parent.permission_revision)
                or not isinstance(proof.get('identity_receipt_id'), str)
                or not re.fullmatch(r'wb-self-[0-9a-f]{32}', proof['identity_receipt_id'])
                or not isinstance(proof.get('platform_uid'), str) or not _MID.fullmatch(proof['platform_uid'])
                or any(not isinstance(proof.get(key), str) or not re.fullmatch(r'[0-9a-f]{64}', proof[key])
                       for key in ('credential_sha256', 'response_sha256', 'receipt_sha256'))):
            raise HostRouteStopped('owned_weibo_identity_invalid')
        return AccountBinding(parent.account_root, parent.tenant_id, parent.account_id,
            proof['platform_uid'], proof['credential_sha256'], True)

    def _identity_from_owned_child(self, proof, *, _action='binding'):
        """Private pipe output only; a payload cannot call/register this seam."""
        self._require_connected()
        parent = self.current_parent_scope()
        binding = self._owned_proof_binding(proof, parent)
        if _action == 'observe':
            # Only self observation can reach the trusted registration decision;
            # no read/resolve is available during this identity-only action.
            return binding
        with self._server.core.lock:
            account = self._server.core._get('accounts', parent.account_id, parent.tenant_id)
            if not account.get('platform_uid'):
                raise HostRouteStopped('owned_weibo_selected_uid_registration_required')
            if str(account.get('platform_uid')) != proof['platform_uid']:
                raise HostRouteStopped('owned_weibo_selected_uid_mismatch')
            if any(item.get('id') != parent.account_id and item.get('platform') == 'weibo'
                    and str(item.get('platform_uid') or '') == proof['platform_uid']
                    for item in self._server.core.store.list('accounts', parent.tenant_id)):
                raise HostRouteStopped('owned_weibo_duplicate_identity')
        return binding

    @contextmanager
    def _owned_self_admission(self, request_id):
        """Local exact self entry, serialized with the original cancel marker.

        Lock order is reads._lock -> Core.lock. No child/network/wait runs
        inside this context. Registration and receipt installation use it as
        their commit boundary; an already committed UID event is not undone.
        """
        reads=self._reads
        if reads is None or not isinstance(request_id,str) or not _REQUEST.fullmatch(request_id):
            raise HostRouteStopped('owned_weibo_self_entry_invalid')
        with reads._lock:
            context=getattr(reads._owned_read_context,'context',None)
            entry=reads._operations.get(request_id)
            if (reads.core is not self._server.core or reads.tenant!=self._initial.tenant_id
                    or type(context) is not tuple or len(context)!=2
                    or context[1]!=threading.get_ident() or type(entry) is not dict
                    or context[0] is not entry or entry.get('account_id')!=self._account_id
                    or entry.get('fingerprint')!=_read_fingerprint(
                        ['self',self._account_id,'','','',1,0])):
                raise HostRouteStopped('owned_weibo_self_entry_invalid')
            if entry.get('cancelled'):
                raise HostRouteStopped('owned_weibo_self_cancelled')
            if not entry.get('running'):
                raise HostRouteStopped('owned_weibo_self_entry_invalid')
            yield entry

    def _register_owned_self(self, proof, *, _request_id):
        """Only observe's completed owned proof reaches this Core transaction.

        A client payload cannot call this private host seam. No authorization
        field, nickname or Cookie supplies a UID. The original Core lock/store
        pattern atomically registers or isolates duplicates and pauses tasks.
        """
        from core.engine import now
        core = self._server.core
        with self._owned_self_admission(_request_id),core.lock:
            self._require_connected()
            parent = self.current_parent_scope()
            binding = self._owned_proof_binding(proof, parent)
            account = core._get('accounts', parent.account_id, parent.tenant_id)
            core._account_access(self._actor, account)
            original_account={key:account.get(key) for key in _ACCOUNT}
            saved_uid = str(account.get('platform_uid') or '')
            duplicates = [item for item in core.store.list('accounts', parent.tenant_id)
                if item.get('id') != account['id'] and item.get('platform') == 'weibo'
                and str(item.get('platform_uid') or '') == binding.platform_uid]
            status = ('identity_mismatch' if saved_uid and saved_uid != binding.platform_uid
                else 'duplicate_identity' if duplicates else 'ready')
            if status == 'ready' and saved_uid == binding.platform_uid and account.get('status') == 'ready':
                return None  # Same immutable scope: no revision handoff needed.
            changed = [account, *duplicates] if status == 'duplicate_identity' else [account]
            updates, timestamp = [], now()
            for item in changed:
                revision = item.get('revision', 0)
                if type(revision) is not int or revision < 0:
                    raise HostRouteStopped('owned_weibo_registration_revision_invalid')
                item.update(status=status, checked_at=timestamp, updated_at=timestamp, revision=revision + 1)
                if item is account and status == 'ready':
                    item['platform_uid'] = binding.platform_uid
                updates.append(('accounts', item))
            if status != 'ready':
                ids = {item['id'] for item in changed}
                for task in core.store.list('tasks', parent.tenant_id):
                    if task.get('account_id') in ids:
                        task.update(status='paused', last_message='微博身份冲突，需重新核对原账号')
                        updates.append(('tasks', task))
            core.store.put_records(updates)  # Original cross-entity transaction.
            self._identity_receipt_id, self._receipt_adapter, self._registration_handoff = None, None, None
            if status != 'ready':
                raise HostRouteStopped('owned_weibo_duplicate_identity' if status == 'duplicate_identity'
                    else 'owned_weibo_selected_uid_mismatch')
            expected = replace(parent, account_revision=_fingerprint({key: account.get(key) for key in _ACCOUNT}))
            current = self._read_parent()
            if current != expected:
                # Registration is a historical self observation, not permission
                # to read with a changed owner/device/licence. No receipt granted.
                raise HostRouteStopped('owned_weibo_registration_scope_changed')
            self._initial = current
            # Private same-thread evidence of this exact Core transaction;
            # never part of child handoff arguments or a client receipt.
            self._child_state.registration_accounts=(deepcopy(original_account),
                {key:account.get(key) for key in _ACCOUNT})
            transition = {'original_identity': deepcopy(proof),
                'new_account_revision': current.account_revision,
                'registration_id': 'wb-reg-' + secrets.token_hex(16)}
            self._registration_handoff = _canonical(transition)
            return deepcopy(transition)

    def _guard_registration_handoff(self, arguments):
        self._require_connected()
        parent = self.current_parent_scope()
        if (self._registration_handoff is None or type(arguments) is not dict
                or _canonical(arguments) != self._registration_handoff
                or arguments.get('new_account_revision') != parent.account_revision):
            raise HostRouteStopped('owned_weibo_registration_handoff_invalid')
        original = arguments['original_identity']
        unchanged = ('tenant_id', 'owner', 'device_id', 'account_id', 'license_revision')
        values = (parent.tenant_id, parent.owner_id, parent.device_id, parent.account_id,
                  str(parent.permission_revision))
        if any(original.get(key) != value for key, value in zip(unchanged, values)):
            raise HostRouteStopped('owned_weibo_registration_scope_changed')

    @contextmanager
    def _owned_child_identity(self, binding):
        """Scoped resolver callback inside this owned, verified child exchange.

        The genuine child transport calls its original _scope before asking
        for an original post, and again at the final wire boundary. Outside
        this synchronous resolver callback, current_binding always rereads the
        child identity receipt and exact saved credential; there is no cache.
        """
        if getattr(self._child_state, 'binding', None) is not None:
            raise HostRouteStopped('owned_weibo_identity_context_nested')
        self._require_connected()
        parent = self.current_parent_scope()
        self._child_state.binding, self._child_state.parent = binding, parent
        try:
            yield
            self._require_connected()
            if self.current_parent_scope() != parent:
                raise HostRouteStopped('owned_weibo_scope_changed')
        finally:
            self._child_state.binding, self._child_state.parent = None, None

    def current_binding(self):
        """Read the original self receipt and current credential in the owned child."""
        self._require_connected()
        active = getattr(self._child_state, 'binding', None)
        if active is not None:
            if self.current_parent_scope() != self._child_state.parent:
                raise HostRouteStopped('owned_weibo_scope_changed')
            return active
        if self._identity_receipt_id is None:
            raise HostRouteStopped('owned_weibo_self_observation_required')
        from assistant.owned_weibo_ipc import OwnedWeiboIPC
        result = OwnedWeiboIPC(self).binding(self._identity_receipt_id)
        if result['transport_result'] is not None or result['identity']['identity_receipt_id'] != self._identity_receipt_id:
            raise HostRouteStopped('owned_weibo_identity_invalid')
        return self._identity_from_owned_child(result['identity'])

    def execute_owned_read(self, operation, *, keyword='', numeric_mid='', count=20, _binding=None):
        """Fixed child calls the genuine transport once; no Cookie/CLI fallback."""
        if operation not in ('search', 'comments'):
            raise HostRouteStopped('owned_weibo_arguments_invalid')
        self._require_connected()
        binding = self.current_binding()
        if _binding is not None and binding != _binding:
            raise HostRouteStopped('owned_weibo_binding_changed')
        from assistant.owned_weibo_ipc import OwnedWeiboIPC
        result = OwnedWeiboIPC(self).read(operation, binding, self._identity_receipt_id,
            keyword=keyword, numeric_mid=numeric_mid, count=count)
        if self._identity_from_owned_child(result['identity']) != binding:
            raise HostRouteStopped('owned_weibo_binding_changed')
        output = result['transport_result']
        if (type(output) is not dict or output.get('platform') != 'weibo'
                or output.get('operation') != operation or len(_canonical(output)) > _MAX_PRIVATE_OUTPUT):
            raise HostRouteStopped('owned_weibo_transport_contract_hold')
        return output

    def observe_owned_identity(self, *, _request_id=None):
        if getattr(self._child_state,'self_request_id',None) is not None:
            raise HostRouteStopped('owned_weibo_self_context_nested')
        with self._owned_self_admission(_request_id):self._require_connected()
        from core.adapters import account_execution_lock
        from assistant.owned_weibo_ipc import OwnedWeiboIPC
        parent = self.current_parent_scope()
        self._child_state.self_anchor=None
        self._child_state.registration_accounts=None
        self._child_state.self_request_id=_request_id
        # Retain the original OS lock across completed self -> Core transaction
        # -> receipt handoff. Each fixed child owns its own original lease.
        try:
            with account_execution_lock(parent.account_root):
                result = OwnedWeiboIPC(self).observe()
                with self._owned_self_admission(_request_id):
                    if result['transport_result'] is not None:
                        raise HostRouteStopped('owned_weibo_identity_invalid')
                    self._identity_from_owned_child(result['identity'], _action='observe')
                    original_identity=deepcopy(result['identity'])
                    transition = self._register_owned_self(result['identity'],_request_id=_request_id)
                if transition is not None:
                    result = OwnedWeiboIPC(self).handoff()
                    original = transition['original_identity']
                    if (result['transport_result'] is not None
                            or any(result['identity'].get(key) != original[key]
                                for key in ('platform_uid', 'credential_sha256', 'response_sha256'))
                            or result['identity']['identity_receipt_id'] == original['identity_receipt_id']):
                        raise HostRouteStopped('owned_weibo_registration_handoff_invalid')
                with self._owned_self_admission(_request_id) as entry:
                    binding = self._identity_from_owned_child(result['identity'])
                    def parent_json(value):
                        fields=asdict(value);fields['account_root']=str(value.account_root);return fields
                    self._child_state.self_anchor=_canonical({'request_id':_request_id,
                        'operation_id':entry['operation_id'],'thread_id':threading.get_ident(),
                        'before_parent':parent_json(parent),'after_parent':parent_json(self.current_parent_scope()),
                        'original_identity':original_identity,'final_identity':deepcopy(result['identity']),
                        'transition':deepcopy(transition),'accounts':self._child_state.registration_accounts})
                    self._identity_receipt_id = result['identity']['identity_receipt_id']
                    self._receipt_adapter = None
        finally:
            # A failed/cancelled handoff installs no retryable transition or
            # new identity receipt. Already committed historical UID events
            # and any earlier identity receipt are not silently rolled back.
            self._registration_handoff = None
            self._child_state.registration_accounts=None
            self._child_state.self_request_id=None
        return {'identity_receipt_id': self._identity_receipt_id, 'platform_uid': binding.platform_uid,
            'status': 'identity_observed', 'production_available': False,
            'real_platform_verified': False, 'auto_retry': False}

    def _consume_owned_self_origin(self,entry,request_id,original,current):
        """Only this live _read may consume its exact verified self transition."""
        encoded=getattr(self._child_state,'self_anchor',None)
        self._child_state.self_anchor=None
        self._require_connected()
        context=getattr(self._reads._owned_read_context,'context',None) if self._reads else None
        if (type(encoded) is not bytes or len(encoded)>_MAX_PRIVATE_OUTPUT
                or type(context) is not tuple or len(context)!=2
                or context[0] is not entry or context[1]!=threading.get_ident()
                or self._reads._operations.get(request_id) is not entry or not entry.get('running')
                or entry.get('cancelled')):
            raise HostRouteStopped('owned_weibo_self_origin_invalid')
        anchor=json.loads(encoded)
        parent=self.current_parent_scope()
        fields=asdict(parent);fields['account_root']=str(parent.account_root)
        if (anchor['request_id']!=request_id or anchor['operation_id']!=entry['operation_id']
                or anchor['thread_id']!=threading.get_ident() or anchor['after_parent']!=fields
                or any(anchor['before_parent'][key]!=fields[key] for key in fields if key!='account_revision')
                or any(original[key]!=current[key] for key in original
                       if key not in ('account_binding_digest','account_uid'))):
            raise HostRouteStopped('owned_weibo_self_scope_changed')
        first,last=anchor['original_identity'],anchor['final_identity']
        if (last['identity_receipt_id']!=self._identity_receipt_id
                or any(first[key]!=last[key] for key in ('platform_uid','credential_sha256','response_sha256'))):
            raise HostRouteStopped('owned_weibo_self_identity_changed')
        transition=anchor['transition']
        if transition is None:
            if original!=current or anchor['before_parent']!=fields or first!=last:
                raise HostRouteStopped('owned_weibo_self_origin_changed')
        else:
            accounts=anchor['accounts']
            if (type(accounts) is not list or len(accounts)!=2
                    or transition['original_identity']!=first
                    or transition['new_account_revision']!=fields['account_revision']
                    or first['identity_receipt_id']==last['identity_receipt_id']):
                raise HostRouteStopped('owned_weibo_self_registration_invalid')
            before,after=accounts
            if (original['account_binding_digest']!=_fingerprint(before)
                    or current['account_binding_digest']!=_fingerprint(after)
                    or anchor['before_parent']['account_revision']!=_fingerprint(before)
                    or fields['account_revision']!=_fingerprint(after)
                    or any(before[key]!=after[key] for key in before
                           if key not in ('platform_uid','status','revision','updated_at'))
                    or type(before['revision']) is not int or after['revision']!=before['revision']+1
                    or after['status']!='ready' or before['platform_uid'] not in ('',None,first['platform_uid'])
                    or after['platform_uid']!=first['platform_uid']
                    or current['account_uid']!=first['platform_uid']
                    or original['account_uid']!=str(before['platform_uid'] or '')):
                raise HostRouteStopped('owned_weibo_self_registration_invalid')
        # Keep the immutable before/after origins and original proof hashes in
        # the service RAM budget, without retaining raw proof or granting scope.
        return _canonical({'original_origin':original,'registered_origin':current,
            'original_identity_sha256':_fingerprint(first),'registered_identity_sha256':_fingerprint(last),
            'registration_handoff_sha256':_fingerprint(transition)})

    def attach_reads(self, reads):
        parent = self.current_parent_scope()
        if (getattr(reads, 'core', None) is not self._server.core
                or getattr(reads, 'tenant', None) != parent.tenant_id
                or getattr(reads, 'owner', None) != parent.owner_id
                or getattr(reads, 'device_id', None) != parent.device_id
                or self._reads is not None and self._reads is not reads):
            raise HostRouteStopped('owned_weibo_read_service_mismatch')
        self._reads = reads

    def _post_adapter(self):
        self._require_connected()
        if self._reads is None:
            raise HostRouteStopped('owned_weibo_read_service_required')
        binding = self.current_binding()
        scope = self.live_authority(binding, 'search')
        if self._receipt_adapter is None:
            from assistant.owned_search_receipt_adapter import OwnedSearchReceiptAdapter, TrustedOwnedSearchReceipt
            @contextmanager
            def original_search(selected, request_id):
                # Same actual service/lock/original request, never a JSON receipt.
                current = self.live_authority(selected, 'search')
                with self._reads.owned_search_receipt(self._account_id, request_id,
                        self._actor, self._initial.device_id) as snapshot:
                    yield TrustedOwnedSearchReceipt(current, snapshot, snapshot['transport_result'],
                                                   snapshot['raw_response_sha256'])
                self.live_authority(selected, 'search')
            self._receipt_adapter = OwnedSearchReceiptAdapter(scope,
                live_authority=self.live_authority, owned_search_receipt=original_search)
        return binding, self._receipt_adapter

    def capture_search(self, request_id):
        binding, adapter = self._post_adapter()
        adapter.capture_owned_search(binding, request_id)

    def resolve_post(self, binding, numeric_mid):
        current, adapter = self._post_adapter()
        if current != binding:
            raise HostRouteStopped('owned_weibo_binding_changed')
        return adapter.resolve_post(binding, numeric_mid)

    def execute(self, action, data):
        fields = {'self': {'request_id'}, 'search': {'request_id', 'keyword'},
                  'comments': {'request_id', 'search_request_id', 'numeric_mid'}}
        if (action not in fields or type(data) is not dict or set(data) != fields[action]
                or not isinstance(data.get('request_id'), str) or not _REQUEST.fullmatch(data['request_id'])):
            raise HostRouteStopped('owned_weibo_arguments_invalid')
        if action == 'search' and (not isinstance(data['keyword'], str)
                or not data['keyword'].strip() or len(data['keyword']) > 500
                or any(ord(ch) < 32 or ord(ch) == 127 for ch in data['keyword'])):
            raise HostRouteStopped('owned_weibo_arguments_invalid')
        if action == 'comments' and (not isinstance(data['numeric_mid'], str)
                or not _MID.fullmatch(data['numeric_mid']) or not isinstance(data['search_request_id'], str)
                or not _REQUEST.fullmatch(data['search_request_id'])):
            raise HostRouteStopped('owned_weibo_arguments_invalid')
        try:
            self._require_connected()
        except HostRouteStopped as error:
            return {'schema_version': 1, 'platform': 'weibo', 'action': action,
                    'status': 'held', 'code': error.code, 'connected': False,
                    'auto_retry': False, 'platform_writes': False, 'real_platform_verified': False}
        try:
            if action == 'self':
                return self.observe_owned_identity(_request_id=data['request_id'])
            if self._reads is None:
                raise HostRouteStopped('owned_weibo_read_service_required')
            body = {'account_id': self._account_id, 'request_id': data['request_id']}
            if action == 'search':
                body['keyword'] = data['keyword']
                result = self._reads.execute('platform_read_search', body, self._actor)
                return result
            # Caller names the original search, but cannot supply its raw/hash.
            with self._reads.owned_search_receipt(self._account_id, data['search_request_id'],
                    self._actor, self._initial.device_id) as original:
                binding = self.current_binding()
                source = OwnedWeiboSourceAuthority.for_trusted_transport(binding,
                    original['transport_result'], live_authority=self.live_authority)
                ids = {str(post.get('idstr') or post.get('id')) for post in source.original_posts()}
                if data['numeric_mid'] not in ids:
                    raise HostRouteStopped('owned_weibo_original_required')
            self.capture_search(data['search_request_id'])
            body['reference'] = data['numeric_mid']
            return self._reads.execute('platform_read_comments', body, self._actor)
        except HostRouteStopped as error:
            code = error.code
        except Exception:
            code = 'owned_weibo_read_hold'
        return {'schema_version': 1, 'platform': 'weibo', 'action': action,
                'status': 'held', 'code': code, 'connected': False,
                'auto_retry': False, 'platform_writes': False, 'real_platform_verified': False}


class OwnedWeiboSourceAuthority:
    """Private immutable successful transport output used only by the host.

    Search originals come from the exact raw output; comments originals come
    from the current owned index/receipt resolver. This is not a runtime grant.
    normalize_sources consumes this capability, never a caller's URL/post dict.
    """
    @classmethod
    def for_trusted_transport(cls, binding, output, *, live_authority, resolve_post=None):
        if not isinstance(binding, AccountBinding) or not callable(live_authority):
            raise HostRouteStopped('owned_weibo_binding_invalid')
        instance = cls()
        instance._binding, instance._authority, instance._resolver = binding, live_authority, resolve_post
        try:
            encoded = _canonical(output)
            if len(encoded) > _MAX_PRIVATE_OUTPUT:
                raise HostRouteStopped('owned_weibo_output_limit')
            instance._output = json.loads(encoded)
            instance._scope = live_authority(binding, instance._output.get('operation'))
            instance._check_current()
            instance._prepare()
            instance._check_current()
            return instance
        except HostRouteStopped:
            raise
        except Exception:
            raise HostRouteStopped('owned_weibo_original_invalid') from None

    def _check_current(self):
        output, binding, scope = self._output, self._binding, self._scope
        try:
            current = self._authority(binding, output.get('operation'))
        except Exception:
            raise HostRouteStopped('owned_weibo_authority_unavailable') from None
        if (not _valid_scope(scope) or current != scope
                or binding.identity_verified is not True or Path(binding.account_root) != scope.account_root
                or binding.tenant_id != scope.tenant_id or binding.account_id != scope.account_id
                or binding.platform_uid != scope.platform_uid
                or not isinstance(binding.credential_sha256, str)
                or binding.credential_sha256.lower() != scope.credential_sha256):
            raise HostRouteStopped('owned_weibo_scope_changed')

    def _prepare(self):
        output, binding = self._output, self._binding
        operation, raw = output.get('operation'), output.get('raw')
        if (output.get('platform') != 'weibo' or operation not in ('search', 'comments')
                or type(raw) is not dict or type(raw.get('ok')) is not int or raw['ok'] != 1
                or type(output.get('items')) is not list or len(output['items']) > 1000):
            raise HostRouteStopped('owned_weibo_original_invalid')
        self._posts = {}
        if operation == 'search':
            if type(output.get('requested_page')) is not int or output['requested_page'] != 1:
                raise HostRouteStopped('owned_weibo_original_invalid')
            rows = _map(raw)
            for post in _items(raw, 'search'):
                mid = str(post.get('idstr') or post.get('id') or '')
                if not _MID.fullmatch(mid):
                    raise HostRouteStopped('owned_weibo_original_invalid')
                _known_post_url(binding, mid, lambda selected, numeric, p=post: p)
                frozen = _canonical(post)
                if mid in self._posts and self._posts[mid] != frozen:
                    raise HostRouteStopped('owned_weibo_original_conflict')
                self._posts[mid] = frozen
        else:
            mid = output.get('post_id')
            if not isinstance(mid, str) or not _MID.fullmatch(mid) or not callable(self._resolver):
                raise HostRouteStopped('owned_weibo_original_required')
            post = self._resolve(mid)
            self._posts[mid] = _canonical(post)
            url = _known_post_url(binding, mid, lambda selected, numeric: post)
            for comment in _items(raw, 'comments'):
                # _map_comments supplies the requested MID. Explicit raw
                # relationship evidence must agree BEFORE that projection.
                for record in (comment, comment.get('user')):
                    if type(record) is not dict:
                        raise HostRouteStopped('owned_weibo_comment_identity_conflict')
                    aliases = [str(record[key]) for key in ('idstr', 'id') if key in record]
                    if aliases and any(not _MID.fullmatch(value) or value != aliases[0] for value in aliases):
                        raise HostRouteStopped('owned_weibo_comment_identity_conflict')
                status = comment.get('status')
                if status is None:
                    continue  # Missing relationship stays owned-request scoped.
                if type(status) is not dict:
                    raise HostRouteStopped('owned_weibo_comment_source_mismatch')
                identifiers = [str(status[key]) for key in ('idstr', 'id') if key in status]
                if any(value != mid for value in identifiers):
                    raise HostRouteStopped('owned_weibo_comment_source_mismatch')
            rows = _map_comments(raw, mid, url)
        if output['items'] != rows:
            raise HostRouteStopped('owned_weibo_output_mismatch')
        self._rows = rows

    def _resolve(self, mid):
        self._check_current()
        try:
            post = self._resolver(self._binding, mid)
        except Exception:
            raise HostRouteStopped('owned_weibo_original_unavailable') from None
        self._check_current()
        return post

    def begin(self, rows):
        self._check_current()
        if rows != self._rows:
            raise HostRouteStopped('owned_weibo_output_mismatch')

    def reference(self, row):
        self._check_current()
        mid = row.get('post_id')
        if not isinstance(mid, str) or not _MID.fullmatch(mid) or mid not in self._posts:
            raise HostRouteStopped('owned_weibo_original_required')
        if self._output['operation'] == 'comments' and _canonical(self._resolve(mid)) != self._posts[mid]:
            raise HostRouteStopped('owned_weibo_original_changed')
        post = json.loads(self._posts[mid])
        url = _known_post_url(self._binding, mid, lambda selected, numeric: post)
        if row.get('url') != url or row.get('note_url', url) != url:
            raise HostRouteStopped('owned_weibo_output_mismatch')
        self._check_current()
        return mid, url

    def finish(self):
        if self._output['operation'] == 'comments':
            for mid, original in self._posts.items():
                if _canonical(self._resolve(mid)) != original:
                    raise HostRouteStopped('owned_weibo_original_changed')
        self._check_current()

    def original_posts(self):
        if self._output['operation'] != 'search':
            raise HostRouteStopped('owned_weibo_original_required')
        self._check_current()
        posts = [json.loads(original) for original in self._posts.values()]
        self._check_current()
        return posts

    def _owned_output_copy(self):
        """Host-only exact frozen output for RAM retention; never a public DTO."""
        self._check_current()
        output = deepcopy(self._output)
        self._check_current()
        return output
