"""Pure safe DTO normalization; owner authorization remains in the old bridge."""
from copy import deepcopy
import re
from .business_reconciliation import LocalBusinessReconciliation, MISSING_EVIDENCE
from .owner_company_receipt_bridge import _fail, _exact, _integer, _match

ACTION='owner_company_receipt_business_get'
CAP={'contract':'owner_business_reconciliation_v1','available':True,'owner_scope_only':True,
     'read_only':True,'company_reported_only':True,'financial_receipt_verified':False,
     'cooperation_policy_verified':False,'auto_retry':False}
HEX=re.compile(r'[a-f0-9]{64}\Z')
SUBJECT=re.compile(r'su_[a-f0-9]{32}\Z')
REF=re.compile(r'(?:evidence|document):[a-f0-9]{32}\Z')
FIELDS=frozenset(('contract','action','package_id','row_id','case_id','claim_id','channel_id',
 'channel_revision','business_revision','association','orders','missing_evidence','read_only',
 'mutation_committed','auto_retry','financial_receipt_verified','cooperation_policy_verified'))
ASSOCIATION=frozenset(('state','company_customer_binding_hash','reported_by_subject','report_mapping_version',
 'binding_revision','binding_evidence_reference','independently_verified','current_company_authorization'))
BASE=frozenset(('financial_cash_authority_not_integrated','commission_payment_authority_not_integrated',
 'cooperation_policy_not_verified','company_customer_identity_not_independently_verified'))

def normalize(value,frame,channel,offset,limit):
    _exact(value,FIELDS)
    if (value['contract']!=CAP['contract'] or value['action']!=ACTION or
        any(value[k]!=frame[k] for k in ('package_id','row_id')) or
        any(value[k]!=channel[k] for k in ('case_id','claim_id','channel_id')) or
        not _integer(value['channel_revision'],channel['revision']) or
        not _integer(value['business_revision'],0) or
        any(value[k] is not expected for k,expected in {'read_only':True,'mutation_committed':False,
            'auto_retry':False,'financial_receipt_verified':False,'cooperation_policy_verified':False}.items())):
        _fail('BUSINESS_BINDING_CONFLICT','公司经营回显未绑定当前本人原行')
    association=value['association'];_exact(association,ASSOCIATION)
    if association['independently_verified'] is not False or type(association['current_company_authorization']) is not bool:
        _fail('BUSINESS_BINDING_CONFLICT','公司报录不能替代独立身份核验')
    if association['state']=='not_reported':
        if (value['business_revision']!=0 or any(association[k] is not None for k in
            ('company_customer_binding_hash','reported_by_subject','binding_evidence_reference')) or
            type(association['report_mapping_version']) is not int or association['report_mapping_version']!=0 or
            type(association['binding_revision']) is not int or association['binding_revision']!=0):
            _fail('BUSINESS_BINDING_CONFLICT')
    elif association['state']=='authenticated_company_report':
        if (not _match(association['company_customer_binding_hash'],HEX) or
            not _match(association['reported_by_subject'],SUBJECT) or
            association['reported_by_subject']==channel['sender_subject_id'] or
            not _integer(association['report_mapping_version'],1) or
            type(association['binding_revision']) is not int or association['binding_revision']!=1 or
            value['business_revision']<1 or not _match(association['binding_evidence_reference'],REF)):
            _fail('BUSINESS_BINDING_CONFLICT')
    else:_fail('BUSINESS_BINDING_CONFLICT')
    # This mature method is a pure DTO validator: it never references self,
    # constructs a company session, loads source IDs, or calls execute/_snapshot.
    orders=LocalBusinessReconciliation._orders(None,value['orders'],offset,limit)
    if association['state']=='not_reported' and orders['total_linked']!=0:
        _fail('BUSINESS_BINDING_CONFLICT')
    evidence=value['missing_evidence']
    expected=BASE|({'company_customer_binding_not_recorded'} if association['state']=='not_reported' else set())
    if type(evidence) is not list or len(evidence)!=len(set(evidence)) or set(evidence)!=expected:
        _fail('BUSINESS_BINDING_CONFLICT','公司经营缺失证据范围不符')
    return {**deepcopy(value),'orders':orders}
