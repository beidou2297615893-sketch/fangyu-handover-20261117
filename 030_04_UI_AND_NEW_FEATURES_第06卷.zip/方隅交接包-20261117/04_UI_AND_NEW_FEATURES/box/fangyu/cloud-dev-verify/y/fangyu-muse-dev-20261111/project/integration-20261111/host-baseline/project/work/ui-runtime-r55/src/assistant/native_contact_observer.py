"""Passive CDP adapter for one caller-supplied, owned WebView2 note window.

There is no browser discovery, navigation, login, cookie read or POST method.
Only the matched XHS reply request invokes getRequestPostData. No raw CDP
packet, header, cookie, authorization value, or response body is returned.
"""
from __future__ import annotations

import json
from threading import RLock

from owned_natural_reader import _NativeOwner

from .tracked_reply_window import ReplyWindowSpec,TrackedReplyWindow,_json,_note_url,MAX_BODY


class NativeContactError(RuntimeError):
    def __init__(self,code):
        self.code=code
        super().__init__(code)


class NativeContactObserver:
    def __init__(self,window,*,spec:ReplyWindowSpec,native=None):
        if window is None or not isinstance(spec,ReplyWindowSpec):
            raise NativeContactError('owned_window_scope_invalid')
        self.window=window
        self.tracked=TrackedReplyWindow(spec)
        self.native=native
        self.lock=RLock()
        self.attached=False;self.closed=False;self.error_code=''
        self._pending_post=[];self._pending_body=[];self._refs=None

    def attach(self):
        if self.closed or self.attached:raise NativeContactError('native_state_invalid')
        try:
            self.native=self.native or _NativeOwner(self.window)
            self.native.invoke(self._attach_ui)
            for task in (self._enable_task,self._frame_task):
                if not task.Wait(10000) or task.IsCanceled or task.IsFaulted:
                    raise NativeContactError('native_cdp_unavailable')
            tree=_json(str(self._frame_task.Result),8192)
            frame=(tree or {}).get('frameTree',{}).get('frame',{})
            if (not isinstance(frame,dict) or not self.tracked.bind_document(
                    frame.get('url'),frame.get('id'),frame.get('loaderId'))):
                raise NativeContactError('native_document_unverified')
        except NativeContactError:
            self.close();raise
        except Exception:
            self.close();raise NativeContactError('native_cdp_unavailable') from None
        self.attached=True
        return self

    def _attach_ui(self):
        control,core=self.native.core()
        if core is None or not _note_url(str(core.Source),self.tracked.spec.note_id):
            raise NativeContactError('native_document_unverified')
        receivers=[]
        def subscribe(name,handler):
            receiver=core.GetDevToolsProtocolEventReceiver(name)
            receiver.DevToolsProtocolEventReceived+=handler
            receivers.append((receiver,handler))

        def navigation(_sender,args):
            with self.lock:
                # Never cancel a human's navigation. Stop observing immediately.
                self.tracked.invalidate('navigation_changed')
                self.error_code='navigation_changed'
                self._pending_post.clear();self._pending_body.clear()

        def request(_sender,args):
            with self.lock:
                if self.closed or self.error_code:return
                matched=self.tracked.request(str(args.ParameterObjectAsJson),str(args.SessionId))
                if matched and matched[1]=='post':
                    try:
                        task=core.CallDevToolsProtocolMethodAsync('Network.getRequestPostData',
                             json.dumps({'requestId':matched[0]},separators=(',',':')))
                        self._pending_post.append((matched[0],task))
                    except Exception:
                        self.tracked.request_post_data(matched[0],'{}')
                        self.error_code='post_data_unavailable'

        def response(_sender,args):
            with self.lock:
                if not self.closed and not self.error_code:
                    self.tracked.response(str(args.ParameterObjectAsJson),str(args.SessionId))

        def finished(_sender,args):
            with self.lock:
                if self.closed or self.error_code:return
                rid=self.tracked.finished(str(args.ParameterObjectAsJson),str(args.SessionId))
                if rid:
                    try:
                        task=core.CallDevToolsProtocolMethodAsync('Network.getResponseBody',
                             json.dumps({'requestId':rid},separators=(',',':')))
                        self._pending_body.append((rid,task))
                    except Exception:self.tracked.body_unavailable(rid)

        def failed(_sender,args):
            with self.lock:
                if self.closed or self.error_code:return
                event=_json(str(args.ParameterObjectAsJson),8192)
                if event:self.tracked.body_unavailable(event.get('requestId'))

        control.NavigationStarting+=navigation
        try:
            subscribe('Network.requestWillBeSent',request)
            subscribe('Network.responseReceived',response)
            subscribe('Network.loadingFinished',finished)
            subscribe('Network.loadingFailed',failed)
            # Global POST capture stays disabled; request data is read only
            # after method, URL, document and account scope have matched.
            self._enable_task=core.CallDevToolsProtocolMethodAsync('Network.enable',
                json.dumps({'maxResourceBufferSize':MAX_BODY,'maxTotalBufferSize':MAX_BODY*2,
                            'maxPostDataSize':0},separators=(',',':')))
            self._frame_task=core.CallDevToolsProtocolMethodAsync('Page.getFrameTree','{}')
        except Exception:
            control.NavigationStarting-=navigation
            for receiver,handler in receivers:
                receiver.DevToolsProtocolEventReceived-=handler
            raise NativeContactError('native_cdp_unavailable') from None
        self._refs=(control,navigation,receivers)

    def poll(self):
        if not self.attached or self.closed:raise NativeContactError('native_state_invalid')
        try:source=self.native.invoke(lambda:str(self.native.core()[1].Source))
        except Exception:
            self.tracked.invalidate('owned_window_changed')
            raise NativeContactError('owned_window_changed') from None
        with self.lock:
            if self.error_code or self.tracked.invalid or not _note_url(source,self.tracked.spec.note_id):
                self.tracked.invalidate('document_changed')
                raise NativeContactError(self.error_code or 'document_changed')
            post_ready=[(rid,task) for rid,task in self._pending_post if task.IsCompleted]
            body_ready=[(rid,task) for rid,task in self._pending_body if task.IsCompleted]
            self._pending_post=[(rid,task) for rid,task in self._pending_post if not task.IsCompleted]
            self._pending_body=[(rid,task) for rid,task in self._pending_body if not task.IsCompleted]
            for rid,task in post_ready:
                if task.IsCanceled or task.IsFaulted:
                    self.tracked.request_post_data(rid,'{}')
                    self.error_code='post_data_unavailable'
                    continue
                try:self.tracked.request_post_data(rid,str(task.Result))
                except Exception:
                    self.tracked.request_post_data(rid,'{}')
                    self.error_code='post_data_unavailable'
            for rid,task in body_ready:
                if task.IsCanceled or task.IsFaulted:self.tracked.body_unavailable(rid)
                else:
                    try:self.tracked.response_body(rid,str(task.Result))
                    except Exception:self.tracked.body_unavailable(rid)
            if self.error_code or self.tracked.invalid:
                raise NativeContactError(self.error_code or self.tracked.invalid)
            return self.tracked.drain()

    def close(self):
        with self.lock:
            if self.closed:return
            self.closed=True
            refs,self._refs=self._refs,None
            self._pending_post.clear();self._pending_body.clear()
            self.tracked.invalidate('closed')
        if refs is None:return
        control,navigation,receivers=refs
        def detach():
            control.NavigationStarting-=navigation
            for receiver,handler in receivers:
                receiver.DevToolsProtocolEventReceived-=handler
        try:self.native.invoke(detach)
        except Exception:pass
