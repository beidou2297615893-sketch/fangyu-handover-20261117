"""Explicit source schedules over the original collector loop and Runtime.

Store rows are plans/CAS coordinates, never device or App authorization. Only
the current Native session supplies a volatile grant; reopening cannot run it.
"""
from copy import deepcopy
from dataclasses import dataclass
import json,math,re,time
from uuid import uuid4
from .acquisition_sources import PRESETS,SourceError,digest,capabilities

EXECUTIONS='acquisition_source_execution_v2'
SCHEMA='acquisition-execution/2'

@dataclass(frozen=True)
class ExecutionSpec:
    tenant: str
    owner: str
    store: str
    account: str
    platform: str
    preset: str
    preset_version: int
    interval_minutes: int
    config_digest: str
    account_binding: str

    def body(self):return dict(self.__dict__)

def account_binding(account):
    return digest({k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid')})

class SourceScheduler:
    def __init__(self,runtime):
        self.runtime=runtime;self.core=runtime.core;self.grants={};self.clock=time.time
        # Recovery is a state transition only. It never mints an App grant or
        # changes tasks/cursors, including on a planned normal close/reopen.
        stamp=self.clock()
        for row in self.core.store.list(EXECUTIONS):
            changed=False
            if row.get('state') in ('waiting','running'):
                row['suspended_state']=row['state']
                due=row.get('next_run_epoch') if row.get('state')=='waiting' else row.get('claimed_due_epoch')
                if due is not None:row['suspended_due_epoch']=due
                row.update(enabled=False,state='needs_confirmation',next_run_epoch=None,
                    message='工作台已重新打开，请核对原账号、门店和频率后继续',version=row['version']+1)
                changed=True
            due=row.get('suspended_due_epoch')
            if (row.get('state')=='needs_confirmation' and row.get('suspended_state')=='running'
                    and type(due) in (int,float) and math.isfinite(due) and row.get('interrupted_due_epoch')!=due):
                if not changed:row['version']+=1
                row.update(interrupted_due_epoch=due,recovery_observed_epoch=stamp,
                    message='上一轮读取在关闭时尚未确认；请核对原任务和断点，不会自动另建任务')
                changed=True
            elif (row.get('state')=='needs_confirmation' and row.get('suspended_state')!='running' and type(due) in (int,float)
                    and math.isfinite(due) and due<=stamp and row.get('missed_due_epoch')!=due):
                interval=row.get('spec',{}).get('interval_minutes',0)
                if not changed:row['version']+=1
                row.update(missed_due_epoch=due,missed_observed_epoch=stamp,
                    missed_intervals=int((stamp-due)//(interval*60))+1 if type(interval) is int and interval>0 else 1,
                    message='工作台关闭或离线期间已错过定期检查；原任务和断点保留，请本人确认后继续')
                changed=True
            if changed:self.core.store.put(EXECUTIONS,row)

    @staticmethod
    def owned(row,user,store):
        return row and (row.get('tenant_id'),row.get('owner'),row.get('store_id'))==(user['tenant_id'],user['username'],store)

    @staticmethod
    def public(row):
        return {'id':row['id'],'version':row['version'],'accountId':row['spec']['account'],
            'presetId':row['spec']['preset'],'presetVersion':row['spec']['preset_version'],
            'intervalMinutes':row['spec']['interval_minutes'],'enabled':row['enabled'],'state':row['state'],
            'nextRunEpoch':row.get('next_run_epoch'),'taskId':row.get('task_id') or row.get('last_task_id'),'runs':row.get('runs',0),
            'message':row['message'],'requestId':row['request_id'],'sessionOnly':True,
            'platform':row['spec']['platform'],'storeId':row['spec']['store'],'schema':SCHEMA,'found':True}

    def read(self,user,data):
        if type(data) is not dict or set(data)-{'storeId','requestId'} or data.get('storeId')!=user.get('_workbench_store_id'):
            raise SourceError('SOURCE_SCOPE_CHANGED','请先选择当前授权门店',403)
        items=[self.public(row) for row in self.core.store.list(EXECUTIONS) if self.owned(row,user,data['storeId'])]
        result={'items':items,'automaticExecution':'current_confirmed_session_only'}
        if 'requestId' in data:
            result['receipt']=next((row for row in items if row['requestId']==data['requestId']),
                {'requestId':data['requestId'],'found':False,'state':'not_found'})
        return result

    def enable(self,user,data,grant,authority_check):
        allowed={'storeId','accountId','presetId','presetVersion','intervalMinutes','confirmed','expectedVersion','requestId','id'}
        if (type(data) is not dict or set(data)-allowed or data.get('storeId')!=user.get('_workbench_store_id')
                or data.get('confirmed') is not True or type(data.get('expectedVersion')) is not int
                or data['expectedVersion']<0 or type(data.get('intervalMinutes')) is not int
                or not 30<=data['intervalMinutes']<=10080 or type(data.get('presetVersion')) is not int
                or not isinstance(data.get('requestId'),str) or not re.fullmatch('[A-Za-z0-9_-]{16,80}',data['requestId'])):
            raise SourceError('SOURCE_EXECUTION_INVALID','请明确确认账号、门店和30分钟至7天的检查频率')
        account=self.runtime._account(user,data.get('accountId'));self.runtime._executor(user)
        code,message=self.runtime._collection_readiness(user,account)
        if code:raise SourceError(code.upper(),message,409)
        ident=data.get('id') or digest([SCHEMA,user['tenant_id'],user['username'],data['storeId'],data['requestId']])
        if not isinstance(ident,str) or not re.fullmatch('[A-Za-z0-9_-]{1,160}',ident):raise SourceError('SOURCE_EXECUTION_INVALID','计划编号无效')
        input_digest=digest(data)
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            def get(entity,key):
                raw=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,key)).fetchone()
                return json.loads(raw['body']) if raw else None
            actor=get('users',user['id'])
            if (not actor or actor.get('disabled') or actor.get('cloud_bound') is not True
                    or authority_check(db,actor,data['storeId'],True) is not True):
                raise SourceError('SOURCE_EXECUTION_FORBIDDEN','员工或门店会话已变化',403)
            old=get(EXECUTIONS,ident)
            if old and not self.owned(old,user,data['storeId']):raise SourceError('SOURCE_EXECUTION_FORBIDDEN','计划不在当前门店范围',403)
            if old and old['request_id']==data['requestId']:
                if old['input_digest']!=input_digest:raise SourceError('SOURCE_REQUEST_CONFLICT','原操作内容已变化，请核对原计划',409)
                # A receipt replay never renews the volatile authorization.
                return self.public(old)
            if (old or {}).get('version',0)!=data['expectedVersion']:raise SourceError('SOURCE_EXECUTION_VERSION','计划已变化，请刷新后重新确认',409)
            if old and old['state']=='running':raise SourceError('SOURCE_EXECUTION_BUSY','本轮正在读取，请等待原结果',409)
            if old and old.get('task_creation_state')=='creating' and not old.get('task_id'):
                raise SourceError('SOURCE_TASK_UNCONFIRMED','原任务创建结果尚未核对，原操作已保留；不会另建任务',409)
            preset=get(PRESETS,data.get('presetId'));fresh=get('accounts',account['id'])
            if (not self.owned(preset,user,data['storeId']) or preset.get('version')!=data['presetVersion']
                    or preset.get('account_id')!=account['id'] or fresh!=account
                    or account.get('platform')!='xiaohongshu' or account.get('status')!='ready'
                    or account.get('requires_review') or not account.get('platform_uid')
                    or not capabilities(preset['platform'])[preset['config']['kind']]['canStart']):
                raise SourceError('SOURCE_EXECUTION_CHANGED','原预设、账号或登录状态已变化，请重新核对',409)
            spec=ExecutionSpec(user['tenant_id'],user['username'],data['storeId'],account['id'],account['platform'],
                preset['id'],preset['version'],data['intervalMinutes'],digest(preset['config']),account_binding(account))
            same=bool(old and all(old['spec'].get(k)==v for k,v in spec.body().items() if k!='interval_minutes'))
            if old and old.get('task_id') and not same:
                raise SourceError('SOURCE_TASK_CONFIRMATION_REQUIRED','原任务和断点保留；请先核对原来源与账号，不会改成另一任务',409)
            row={'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],'store_id':data['storeId'],
                'schema':SCHEMA,'spec':spec.body(),'request_id':data['requestId'],'input_digest':input_digest,
                'version':data['expectedVersion']+1,'enabled':True,'state':'waiting',
                'runtime_id':self.core.continuous.runtime_id,'next_run_epoch':self.clock()+data['intervalMinutes']*60,
                'cycle':old.get('cycle',1) if same else 1,'task_id':old.get('task_id') if same else None,
                'last_task_id':old.get('last_task_id') if same else None,
                'runs':old.get('runs',0) if same else 0,'message':'已开启定期检查；只在当前工作台会话内运行'}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(EXECUTIONS,ident,user['tenant_id'],json.dumps(row,ensure_ascii=False)))
            self.grants[ident]=(row['version'],grant)
        self.core.continuous.start_scheduler();self.core.continuous._wake.set()
        return self.public(row)

    def pause(self,user,data):
        if (type(data) is not dict or set(data)!={'storeId','id','expectedVersion'}
                or type(data.get('expectedVersion')) is not int or data.get('storeId')!=user.get('_workbench_store_id')):
            raise SourceError('SOURCE_EXECUTION_INVALID','请核对原检查计划')
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');raw=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(EXECUTIONS,data['id'])).fetchone();row=json.loads(raw['body']) if raw else None
            if not self.owned(row,user,data['storeId']):raise SourceError('SOURCE_EXECUTION_FORBIDDEN','计划不在当前门店范围',403)
            if row['version']!=data['expectedVersion']:raise SourceError('SOURCE_EXECUTION_VERSION','计划已变化，请刷新后暂停',409)
            row.update(enabled=False,state='paused',next_run_epoch=None,version=row['version']+1,message='定期检查已暂停；原任务和断点保留')
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(row,ensure_ascii=False),EXECUTIONS,row['id']));self.grants.pop(row['id'],None)
        return self.public(row)

    def tick(self,epoch):
        due=sorted((r for r in self.core.store.list(EXECUTIONS) if r.get('enabled') and r.get('state')=='waiting'
            and r.get('runtime_id')==self.core.continuous.runtime_id and r.get('next_run_epoch',float('inf'))<=epoch),key=lambda r:(r['next_run_epoch'],r['id']))
        if not due:return False
        candidate=due[0];ident=candidate['id'];claim=uuid4().hex
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');raw=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(EXECUTIONS,ident)).fetchone();row=json.loads(raw['body']) if raw else None
            if row!=candidate:return True
            row.update(state='running',claim=claim,claimed_due_epoch=row['next_run_epoch'],next_run_epoch=None)
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(row,ensure_ascii=False),EXECUTIONS,ident))
        error=None;result=None
        try:
            version,grant=self.grants.get(ident,(None,None))
            if version!=row['version'] or not callable(grant):raise SourceError('SOURCE_SESSION_EXPIRED','工作台会话已失效，请本人重新确认',401)
            def active_grant():
                current=self.core.store.get(EXECUTIONS,ident)
                if (not current or current.get('claim')!=claim or current.get('state')!='running'
                        or current.get('version')!=row['version'] or not current.get('enabled')
                        or self.grants.get(ident)!=(version,grant)):
                    raise SourceError('SOURCE_EXECUTION_CHANGED','原计划已暂停，任务和断点保留',409)
                return grant()
            actor=active_grant()
            def bind_task(task_id):
                # Store the original Core-generated ID before any platform read.
                # A crash before this acknowledgement is never auto-replayed.
                with self.core.lock,self.core.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE');raw=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(EXECUTIONS,ident)).fetchone();current=json.loads(raw['body']) if raw else None
                    if (not current or current.get('claim')!=claim or current['state']!='running'
                            or current['version']!=row['version']):raise SourceError('SOURCE_EXECUTION_CHANGED','原计划已暂停，任务保留',409)
                    current['task_creation_state']='bound' if task_id else 'creating'
                    current['creation_claim']=claim
                    if task_id:current['task_id']=task_id
                    db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(current,ensure_ascii=False),EXECUTIONS,ident))
            result=self.runtime.run_scheduled_source_page(actor,row['spec'],row.get('task_id'),active_grant,bind_task)
        except Exception as exc:error=exc
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');raw=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(EXECUTIONS,ident)).fetchone();current=json.loads(raw['body']) if raw else None
            if not current or current.get('claim')!=claim:return True
            if current['state']!='running' or current['version']!=row['version']:return True
            if error is not None:
                current.update(enabled=False,state='needs_confirmation',next_run_epoch=None,
                    message='本轮已暂停，原任务和断点保留；请核对员工会话、账号和企业许可后继续')
                self.grants.pop(ident,None)
            else:
                current.update(state='waiting',runs=current.get('runs',0)+1,
                    next_run_epoch=max(epoch,self.clock())+row['spec']['interval_minutes']*60,
                    message='本轮已保存，等待下次检查；未完成的原任务沿断点继续')
                if result.get('exhausted') and result.get('kind')!='own_interactions':
                    current.update(cycle=current['cycle']+1,last_task_id=current['task_id'],task_id=None)
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(current,ensure_ascii=False),EXECUTIONS,ident))
        return True

    def close(self):
        # Serialize the read/transition with tick's bind_task and final commit.
        # Otherwise this shutdown snapshot can erase a just-saved original task
        # ID or its "creating" marker, making recovery lose its original key.
        with self.core.lock:
            self.grants.clear()
            for row in self.core.store.list(EXECUTIONS):
                if row.get('runtime_id')==self.core.continuous.runtime_id and row.get('state') in ('waiting','running'):
                    row['suspended_state']=row['state']
                    due=row.get('next_run_epoch') if row.get('state')=='waiting' else row.get('claimed_due_epoch')
                    if due is not None:row['suspended_due_epoch']=due
                    row['suspended_at_epoch']=self.clock()
                    row.update(enabled=False,state='needs_confirmation',next_run_epoch=None,version=row['version']+1,
                        message='工作台已关闭；重新打开后请本人确认再运行')
                    self.core.store.put(EXECUTIONS,row)
