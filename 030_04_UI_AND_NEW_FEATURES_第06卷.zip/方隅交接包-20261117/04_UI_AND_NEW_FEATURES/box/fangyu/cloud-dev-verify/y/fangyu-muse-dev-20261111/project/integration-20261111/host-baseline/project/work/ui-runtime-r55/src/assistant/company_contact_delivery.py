"""Explicit company contact release over an owned, durable local attempt.

Status never repairs an attempt or decrypts contacts. A new publish first proves
the current provider/retention/claim permissions, then commits its opaque intent,
then uses the existing audited local decrypt exactly once. Values exist in RAM.
"""
from copy import deepcopy
import json
import re
import time

from core import CoreError
from .acquisition_contacts import AcquisitionContacts
from .business_reconciliation import LocalBusinessReconciliation
from .company_handoff_preparation import _hash, _raw, _json
from .company_handoff_receiver import CompanyHandoffReceiver, _int, _matches
from .company_handoff_original_status import _ENVELOPE, _RECEIPT, _ORIGINAL, _CURRENT, _STATES
from .company_contact_delivery_transport import (PUBLISH as CLOUD_PUBLISH, REVEAL as CLOUD_REVEAL,
    STATUS as CLOUD_STATUS, HANDOFF_WITHDRAW, HANDOFF_STATUS, valid_delivery)

PUBLISH = 'company_contact_publish'
REVEAL = 'company_contact_reveal'
WITHDRAW = 'company_contact_withdraw'
GET = 'company_contact_operation_get'
WRITES = frozenset((PUBLISH, REVEAL, WITHDRAW))
ACTIONS = WRITES | {GET}
ATTEMPTS = 'company_contact_delivery_attempts'
CONTRACT = 'local_company_contact_delivery_v1'
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_REF = re.compile(r'contact:[a-f0-9]{32}\Z')
_VERSION = re.compile(r'[A-Za-z0-9_-]{8,96}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_ROW = frozenset(('id', 'version', 'tenant_id', 'cloud_owner', 'company_id', 'environment_id',
    'device_id', 'actor_id', 'channel_id', 'operation_action', 'expected_revision', 'contact_version',
    'contact_reference', 'expected_contact_revision', 'contact_record_hash', 'source_binding_hash',
    'consent_reference', 'notice_version', 'cloud_idempotency_key', 'cloud_metadata_hash', 'input_hash',
    'state', 'created_at', 'updated_at', 'revision', 'record_hash'))
_INPUT = ('channel_id', 'operation_action', 'expected_revision', 'contact_version', 'contact_reference',
    'expected_contact_revision', 'contact_record_hash', 'source_binding_hash', 'consent_reference', 'notice_version')


class CompanyContactDeliveryError(CoreError):
    def __init__(self, code, message, status=409, *, mutation=False):
        super().__init__(message)
        self.code = 'COMPANY_CONTACT_DELIVERY_' + code
        self.status, self.mutation_committed = status, mutation


def _fail(code, message, status=409, *, mutation=False):
    raise CompanyContactDeliveryError(code, message, status, mutation=mutation)


class CompanyContactDelivery:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard,
                 cloud_contact, cloud_read, cloud_withdraw, lead_access, contact_crypt=None, clock=None):
        if not all(callable(v) for v in (cloud_contact, cloud_read, cloud_withdraw, lead_access)):
            raise ValueError('公司联系方式需要可信的当前连接和来源权限')
        self.receiver = CompanyHandoffReceiver(core, tenant, owner, company, device_id=device_id,
            scope_guard=scope_guard, cloud_read=cloud_read, cloud_receipt=cloud_withdraw, clock=clock)
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.company_id, self.environment_id, self.device_id = self.receiver.company_id, self.receiver.environment_id, device_id
        self.clock = clock or time.time
        self.cloud_contact, self.cloud_withdraw = cloud_contact, cloud_withdraw
        self.contacts = AcquisitionContacts(core, tenant, owner, company, lead_access=lead_access, crypt=contact_crypt)
        self.evidence = LocalBusinessReconciliation(core, tenant, owner, company, device_id=device_id,
            scope_guard=scope_guard, lead_access=lead_access, cloud_read=cloud_read)
        self.lead_access = lead_access

    def _snapshot(self, user):
        try:
            snap = self.receiver._snapshot(user)
        except Exception:
            _fail('AUTH_REQUIRED', '当前本人、公司或电脑绑定需核对', 403)
        snap['scope'] = _hash([self.company, self.device_id, snap['actor']])
        return snap

    def _fence(self, snap, user):
        if self._snapshot(user)['scope'] != snap['scope']:
            _fail('BINDING_CHANGED', '当前本人、公司或设备已变化，请保留原号')

    def _ident(self, action, channel):
        return _hash(['company-contact-local-intent-v1', self.tenant, self.environment_id,
            self.company_id, self.owner, action, channel])

    def _key(self, action, channel):
        return _hash(['company-contact-cloud-intent-v1', self.tenant, self.environment_id,
            self.company_id, self.owner, action, channel])

    @staticmethod
    def _cloud_action(action):
        return {PUBLISH: CLOUD_PUBLISH, REVEAL: CLOUD_REVEAL, WITHDRAW: HANDOFF_WITHDRAW}[action]

    def _row(self, db, action, channel, actor):
        raw = db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',
            (ATTEMPTS, self._ident(action, channel))).fetchone()
        if not raw:
            return None
        try:
            row = json.loads(raw['body'])
            fixed = dict(id=self._ident(action, channel), version=1, tenant_id=self.tenant, cloud_owner=self.owner,
                company_id=self.company_id, environment_id=self.environment_id, device_id=self.device_id,
                actor_id=actor['id'], operation_action=action, channel_id=channel,
                cloud_idempotency_key=self._key(action, channel))
            if (not isinstance(row, dict) or set(row) != _ROW or raw['tenant_id'] != self.tenant
                    or any(type(row[k]) is not type(v) or row[k] != v for k, v in fixed.items())
                    or row['record_hash'] != _hash({k: v for k, v in row.items() if k != 'record_hash'})
                    or row['input_hash'] != _hash({k: row[k] for k in _INPUT})
                    or row['state'] not in ('unknown', 'recorded') or not _int(row['revision'], 1)
                    or not _int(row['expected_revision'], 1) or not _int(row['created_at'], 1577836800)
                    or not _int(row['updated_at'], row['created_at'])
                    or not _matches(row['source_binding_hash'], _HEX)
                    or not _matches(row['cloud_metadata_hash'], _HEX)):
                raise ValueError('attempt mismatch')
            if action == PUBLISH:
                if (not _matches(row['contact_reference'], _REF) or not _int(row['expected_contact_revision'], 1)
                        or row['contact_version'] != row['contact_reference'][8:] + '_' + str(row['expected_contact_revision'])
                        or not _matches(row['contact_record_hash'], _HEX)
                        or not _matches(row['consent_reference'], re.compile(r'consent:[a-f0-9]{32}\Z'))
                        or not _matches(row['notice_version'], re.compile(r'[A-Za-z0-9_-]{1,160}\Z'))):
                    raise ValueError('contact mismatch')
            elif action == REVEAL:
                if (not _matches(row['contact_version'], _VERSION) or not _int(row['expected_contact_revision'], 1)
                        or any(row[k] is not None for k in ('contact_reference', 'contact_record_hash', 'consent_reference', 'notice_version'))):
                    raise ValueError('release mismatch')
            elif any(row[k] is not None for k in ('contact_version', 'expected_contact_revision', 'contact_reference',
                                                  'contact_record_hash', 'consent_reference', 'notice_version')):
                raise ValueError('withdraw mismatch')
            return row
        except Exception:
            _fail('ATTEMPT_CONFLICT', '原联系方式操作元数据需核对，不能换号、修补或重发')

    @staticmethod
    def _put(db, row, previous=None):
        row = {k: v for k, v in row.items() if k != 'record_hash'}
        row['record_hash'] = _hash(row)
        if previous is None:
            db.execute('INSERT INTO records VALUES(?,?,?,?)', (ATTEMPTS, row['id'], row['tenant_id'], _json(row)))
        else:
            changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=? AND body=?',
                (_json(row), ATTEMPTS, row['id'], row['tenant_id'], _json(previous)))
            if changed.rowcount != 1:
                _fail('ATTEMPT_CONFLICT', '原联系方式操作范围已变化，请保留原号')
        return row

    def _detail(self, snap, user, channel):
        self._fence(snap, user)
        try:
            raw, safe = self.receiver._detail(self.receiver._snapshot(user), user, channel)
        except Exception:
            _fail('READ_UNAVAILABLE', '公司当前原渠道或读取权限需核对', 503)
        self._fence(snap, user)
        return raw, safe

    def _call(self, snap, user, operation, data, *, write=False, withdrawal=False):
        self._fence(snap, user)
        try:
            answer = (self.cloud_withdraw if withdrawal else self.cloud_contact)(deepcopy(snap['actor']), operation, deepcopy(data))
        except Exception:
            _fail('RESULT_UNKNOWN' if write else 'READ_UNAVAILABLE',
                '原操作尚未确认，请按原号核对，未自动重发', 503, mutation=None if write else False)
        try:
            self._fence(snap, user)
        except Exception:
            _fail('BINDING_CHANGED', '返回时本人或公司范围已变化，请保留原号', mutation=None if write else False)
        return answer

    def _contact_status(self, snap, user, action, channel, row=None):
        data = dict(channel_id=channel, operation_action=self._cloud_action(action),
            idempotency_key=row['cloud_idempotency_key'] if row else self._key(action, channel))
        answer = self._call(snap, user, CLOUD_STATUS, data)
        if (not isinstance(answer, dict) or set(answer) != {'delivery', 'read_only', 'mutation_committed', 'auto_retry'}
                or answer['read_only'] is not True or answer['mutation_committed'] is not False or answer['auto_retry'] is not False
                or not valid_delivery(answer['delivery'], snap['actor'], CLOUD_STATUS, data)):
            _fail('INVALID_RECEIPT', '公司联系方式纯读回执需核对')
        # The server's anchored vault independently identifies the contact
        # version. Local unkeyed row checksums cannot establish original input.
        contact = answer['delivery']['contact']
        if row and (action == REVEAL or answer['delivery']['state'] == 'recorded'):
            if not contact or contact['contact_version'] != row['contact_version']:
                _fail('ATTEMPT_CONFLICT', '公司原联系方式版本与本机原号不一致，未修补或重发')
            if action == REVEAL:
                # Frozen vault lifecycle: publish revision 1, reveal does not
                # mutate it, one explicit vault withdrawal advances it by one.
                # A handoff-only withdrawal leaves that revision unchanged.
                original_revision = contact['revision'] - (1 if contact['revoked_at'] is not None else 0)
                if row['expected_contact_revision'] != original_revision:
                    _fail('ATTEMPT_CONFLICT', '公司原查看修订与本机原号不一致，未修补或重发')
        return deepcopy(answer['delivery'])

    @staticmethod
    def _metadata(delivery):
        return _hash({k: v for k, v in delivery.items() if k != 'contact_values'})

    def _contact_record(self, db, ref, actor):
        raw = db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',
            ('acquisition_contacts', ref[8:])).fetchone()
        try:
            record = json.loads(raw['body']) if raw else None
            lead_raw = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('leads', record['lead_id'], self.tenant)).fetchone() if record else None
            lead = json.loads(lead_raw['body']) if lead_raw else None
            if (not record or raw['tenant_id'] != self.tenant or record.get('id') != ref[8:]
                    or record.get('tenant_id') != self.tenant or record.get('cloud_owner') != self.owner
                    or record.get('storage_scope') != 'local_current_windows_user'
                    or not _int(record.get('revision'), 1) or record.get('revoked_at') is not None
                    or not lead or lead.get('tenant_id') != self.tenant or lead.get('cloud_owner') != self.owner
                    or not isinstance(record.get('encrypted_payload'), str) or not record['encrypted_payload']
                    or not isinstance(record.get('consent'), dict) or set(record['consent']) != {'status', 'evidence_reference', 'notice_version'}
                    or record['consent']['status'] != 'granted'):
                raise ValueError('contact unavailable')
            self.lead_access(actor, lead)
            self.contacts._check_withdrawal(record['consent'], db)
            return deepcopy(record), deepcopy(lead)
        except Exception:
            _fail('CONTACT_UNAVAILABLE', '本机联系方式、来源或同意已变化，未解密')

    def _source(self, db, ref, actor, raw, expected_contact_revision):
        record, lead = self._contact_record(db, ref, actor)
        try:
            event, event_hash = self.evidence._owned_event(raw['source_event_id'], {'lead': lead})
        except Exception:
            _fail('SOURCE_UNAVAILABLE', '本机原来源完整记录或当前客户绑定需核对，未解密')
        source = raw['source']
        if (record['revision'] != expected_contact_revision or raw['source_owner'] != self.owner
                or source['device_id'] != self.device_id or raw['recipient_id'] != record['recipient_id']
                or raw['purpose'] != record['purpose'] or raw['consent']['status'] != 'granted'
                or any(raw['consent'][k] != record['consent'][k] for k in ('evidence_reference', 'notice_version'))
                or not _matches(record['consent']['evidence_reference'], re.compile(r'consent:[a-f0-9]{32}\Z'))
                or not _matches(record['consent']['notice_version'], re.compile(r'[A-Za-z0-9_-]{1,160}\Z'))
                or any(source[k] != lead.get(k) for k in ('platform', 'author_id', 'comment_id'))
                or source['source_lead_hash'] != _raw(lead['id']) or source['original_text_hash'] != _raw(lead['text'])
                or raw['current_consent_valid'] is not True or raw['status'] not in ('submitted', 'accepted', 'draft')):
            _fail('SOURCE_MISMATCH', '本机联系人与公司原来源、接收方、用途或同意不一致，未解密')
        return record, _hash([raw, event_hash])

    def _require(self, action, raw, delivery, data):
        if raw['revision'] != data['expected_revision']:
            _fail('STALE_REVISION', '公司原渠道版本已变化，请明确刷新后核对')
        if action == WITHDRAW:
            if raw['source_owner'] != self.owner or raw['permissions']['can_withdraw'] is not True:
                _fail('WITHDRAW_FORBIDDEN', '当前公司来源撤回权限需核对', 403)
            return
        permission = 'can_publish' if action == PUBLISH else 'can_reveal'
        if (delivery['state'] != 'not_recorded' or delivery['permissions'][permission] is not True
                or delivery['provider_configured'] is not True or delivery['current_consent_valid'] is not True
                or delivery['current_channel_status'] != raw['status']):
            _fail('NOT_AVAILABLE', '公司联系方式配置、同意或当前权限尚未确认，未解密或提交')
        if action == PUBLISH and (delivery['retention_configured'] is not True or delivery['channel_binding_state'] != 'unbound'):
            _fail('NOT_AVAILABLE', '公司保留期限或原渠道占用尚未确认，未解密或提交')
        if action == REVEAL and (not delivery['contact'] or delivery['contact']['contact_version'] != data['contact_version']
                or delivery['contact']['revision'] != data['expected_contact_revision'] or not delivery['contact_available']):
            _fail('CONTACT_CHANGED', '公司联系方式原版本已变化，未请求解密')

    def _withdraw_status(self, snap, user, channel, row=None):
        key = row['cloud_idempotency_key'] if row else self._key(WITHDRAW, channel)
        answer = self._call(snap, user, HANDOFF_STATUS, {'operation_action': HANDOFF_WITHDRAW, 'idempotency_key': key}, withdrawal=True)
        rec = answer.get('operation_receipt') if isinstance(answer, dict) else None
        if (not isinstance(answer, dict) or set(answer) != _ENVELOPE or answer['read_only'] is not True
                or answer['mutation_committed'] is not False or answer['auto_retry'] is not False
                or not isinstance(rec, dict) or set(rec) != _RECEIPT or rec['contract'] != 'handoff_operation_receipt_v1'
                or rec['storage_scope'] != 'company_server_ledger' or rec['authenticated_actor'] != self.owner
                or rec['operation_action'] != HANDOFF_WITHDRAW or rec['idempotency_key'] != key
                or rec['state'] not in ('unknown', 'recorded') or rec['read_only'] is not True
                or rec['mutation_committed'] is not False or rec['auto_retry'] is not False
                or not _int(rec['observed_at'], 1577836800)
                or any(rec[k] is not False for k in ('platform_delivery_verified', 'settlement_active', 'financial_receipt_verified', 'cooperation_policy_verified'))
                or rec['verified_cash_cents'] is not None or rec['verified_paid_commission_cents'] is not None):
            _fail('INVALID_RECEIPT', '公司撤回原号纯读回执需核对')
        if rec['state'] == 'unknown':
            if any(rec[k] is not None for k in ('original_execution_confirmed', 'original_operation', 'current_handoff')):
                _fail('INVALID_RECEIPT', '缺失原号不能证明原操作未执行')
        else:
            original, current = rec['original_operation'], rec['current_handoff']
            if (row is None or rec['original_execution_confirmed'] is not True or not isinstance(original, dict) or set(original) != _ORIGINAL
                    or original['payload_hash'] != _hash(dict(environment_id=self.environment_id, operation=HANDOFF_WITHDRAW,
                        channel_id=channel, expected_revision=row['expected_revision'], idempotency_key=key, reason_code='customer_withdrew'))
                    or original['channel_id'] != channel or original['revision'] != row['expected_revision'] + 1
                    or original['historical_status'] != 'withdrawn' or not _int(original['occurred_at'], 1577836800)
                    or original['occurred_at'] > rec['observed_at'] or original['historical_event_self_hash_verified'] is not True
                    or original['full_historical_chain_verified'] is not False or not isinstance(current, dict) or set(current) != _CURRENT
                    or current['channel_id'] != channel or not _int(current['revision'], original['revision'])
                    or current['status'] not in _STATES or type(current['current_consent_valid']) is not bool
                    or type(current['historical_resource_receipt_recorded']) is not bool
                    or current['receipt_evidence_independently_verified'] is not False
                    or current['status'] == 'withdrawn' and current['current_consent_valid']):
                _fail('INVALID_RECEIPT', '公司撤回历史与原号、当前状态不一致')
        rec = deepcopy(rec)
        if rec['original_operation']:
            rec['original_operation'].pop('payload_hash')
        return rec

    def _result(self, action, snap, safe, row, delivery=None, receipt=None, *, requested=False, read_only=True):
        cloud_state = delivery['state'] if delivery else receipt['state'] if receipt else None
        state = 'recorded' if cloud_state == 'recorded' else 'unknown' if row or cloud_state == 'unknown' else 'not_attempted'
        return dict(contract=CONTRACT, action=action, read_only=read_only,
            mutation_committed=False if read_only else True, storage_scope='local_bridge_company_server_contact_vault',
            observed_at=int(self.clock()), channel_id=safe['channel_id'], state=state,
            attempt={k: row[k] for k in ('state', 'operation_action', 'cloud_idempotency_key', 'contact_version',
                'expected_revision', 'expected_contact_revision', 'created_at', 'updated_at')} if row else None,
            delivery=deepcopy(delivery), current=deepcopy(safe), withdrawal_receipt=deepcopy(receipt),
            cloud_requested=requested, auto_retry=False, plaintext_cached=False, cross_machine_delivery_verified=False,
            platform_requests_started=False, ai_provider_called=False, financial_receipt_verified=False,
            verified_cash_cents=None, verified_paid_commission_cents=None)

    def _get(self, action, snap, user, channel, row):
        delivery = self._contact_status(snap, user, action, channel, row) if action != WITHDRAW else None
        receipt = self._withdraw_status(snap, user, channel, row) if action == WITHDRAW else None
        _, safe = self._detail(snap, user, channel)
        self._fence(snap, user)
        return self._result(GET, snap, safe, row, delivery, receipt, requested=True)

    def execute(self, action, data, user):
        allowed = {'channel_id', 'operation_action'} if action == GET else {'channel_id', 'expected_revision'}
        if action == PUBLISH:
            allowed |= {'contact_reference', 'expected_contact_revision'}
        elif action == REVEAL:
            allowed |= {'contact_version', 'expected_contact_revision'}
        if (action not in ACTIONS or not isinstance(data, dict) or set(data) != allowed
                or not _matches(data.get('channel_id'), _CHANNEL)
                or action == GET and data.get('operation_action') not in WRITES
                or action != GET and not _int(data.get('expected_revision'), 1)
                or action in (PUBLISH, REVEAL) and not _int(data.get('expected_contact_revision'), 1)
                or action == PUBLISH and not _matches(data.get('contact_reference'), _REF)
                or action == REVEAL and not _matches(data.get('contact_version'), _VERSION)):
            _fail('INVALID_REQUEST', '公司联系方式只接受固定原渠道、版本及联系人引用', 400)
        operation = data['operation_action'] if action == GET else action
        snap, channel = self._snapshot(user), data['channel_id']
        with self.core.lock, self.core.store.connect() as db:
            row = self._row(db, operation, channel, snap['actor'])
        if action == GET or row is not None:
            return self._get(operation, snap, user, channel, row)
        # No plaintext or attempt exists until this pure read proves availability.
        delivery = self._contact_status(snap, user, action, channel) if action != WITHDRAW else None
        raw, safe = self._detail(snap, user, channel)
        self._require(action, raw, delivery, data)
        stamp = int(self.clock())
        if not _int(stamp, 1577836800):
            _fail('CLOCK_UNAVAILABLE', '当前本机时间需核对')
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._fence(snap, user)
            existing = self._row(db, action, channel, snap['actor'])
            if existing is None:
                record, binding = self._source(db, data['contact_reference'], snap['actor'], raw,
                    data['expected_contact_revision']) if action == PUBLISH else (None, _hash(raw))
                row = dict(id=self._ident(action, channel), version=1, tenant_id=self.tenant, cloud_owner=self.owner,
                    company_id=self.company_id, environment_id=self.environment_id, device_id=self.device_id,
                    actor_id=snap['actor']['id'], channel_id=channel, operation_action=action,
                    expected_revision=data['expected_revision'], contact_version=(record['id'] + '_' + str(record['revision'])
                        if record else data.get('contact_version')), contact_reference=data.get('contact_reference'),
                    expected_contact_revision=data.get('expected_contact_revision'), contact_record_hash=_hash(record) if record else None,
                    source_binding_hash=binding, consent_reference=record['consent']['evidence_reference'] if record else None,
                    notice_version=record['consent']['notice_version'] if record else None,
                    cloud_idempotency_key=self._key(action, channel), cloud_metadata_hash=self._metadata(delivery) if delivery else _hash(None),
                    state='unknown', created_at=stamp, updated_at=stamp, revision=1)
                row['input_hash'] = _hash({k: row[k] for k in _INPUT})
                row = self._put(db, row)
                db.commit()
        if existing is not None:
            return self._get(action, snap, user, channel, existing)
        try:
            # Every post-claim failure remains unknown; no error code permits replay.
            self._fence(snap, user)
            fresh_delivery = self._contact_status(snap, user, action, channel, row) if action != WITHDRAW else None
            fresh_raw, _ = self._detail(snap, user, channel)
            self._require(action, fresh_raw, fresh_delivery, data)
            if _hash(fresh_raw) != _hash(raw) or action != WITHDRAW and self._metadata(fresh_delivery) != row['cloud_metadata_hash']:
                _fail('CURRENT_CHANGED', '公司当前来源或联系方式条件已变化，请保留原号')
            body = dict(channel_id=channel, expected_revision=row['expected_revision'], idempotency_key=row['cloud_idempotency_key'])
            if action == PUBLISH:
                with self.core.lock, self.core.store.connect() as db:
                    current, binding = self._source(db, row['contact_reference'], snap['actor'], fresh_raw, row['expected_contact_revision'])
                    if (_hash(current) != row['contact_record_hash'] or binding != row['source_binding_hash']
                            or self._row(db, action, channel, snap['actor']) != row):
                        _fail('CONTACT_CHANGED', '解密前本机联系人或原来源已变化')
                revealed = self.contacts.execute('contact_read', {'contact_reference': row['contact_reference'], 'reveal': True}, snap['actor'])
                values = revealed.get('contact')
                with self.core.lock, self.core.store.connect() as db:
                    current, binding = self._source(db, row['contact_reference'], snap['actor'], fresh_raw, row['expected_contact_revision'])
                    if _hash(current) != row['contact_record_hash'] or binding != row['source_binding_hash']:
                        _fail('CONTACT_CHANGED', '解密后本机联系人或原来源已变化')
                latest = self._contact_status(snap, user, action, channel, row)
                latest_raw, _ = self._detail(snap, user, channel)
                self._require(action, latest_raw, latest, data)
                if _hash(latest_raw) != _hash(raw) or self._metadata(latest) != row['cloud_metadata_hash']:
                    _fail('CURRENT_CHANGED', '提交前公司当前来源或联系方式条件已变化')
                with self.core.lock, self.core.store.connect() as db:
                    self._fence(snap, user)
                    current, binding = self._source(db, row['contact_reference'], snap['actor'], latest_raw, row['expected_contact_revision'])
                    if (_hash(current) != row['contact_record_hash'] or binding != row['source_binding_hash']
                            or self._row(db, action, channel, snap['actor']) != row):
                        _fail('CONTACT_CHANGED', '提交前本机联系人或原操作已变化')
                body.update(contact_version=row['contact_version'], consent_reference=row['consent_reference'],
                    notice_version=row['notice_version'], phone=values.get('phone', ''), wechat=values.get('wechat', ''))
            elif action == REVEAL:
                body.update(contact_version=row['contact_version'], expected_contact_revision=row['expected_contact_revision'])
            else:
                body['reason_code'] = 'customer_withdrew'
            with self.core.lock, self.core.store.connect() as db:
                self._fence(snap, user)
                if self._row(db, action, channel, snap['actor']) != row:
                    _fail('ATTEMPT_CONFLICT', '提交前原联系方式操作已变化，请保留原号')
            answer = self._call(snap, user, self._cloud_action(action), body, write=True, withdrawal=action == WITHDRAW)
            if action == WITHDRAW:
                fields = {'item', 'replayed', 'server_recorded', 'platform_delivery_verified', 'attribution_confirmed', 'settlement_active'}
                if (not isinstance(answer, dict) or set(answer) != fields or type(answer['replayed']) is not bool
                        or answer['server_recorded'] is not True or any(answer[k] is not False for k in
                            ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))):
                    _fail('INVALID_RECEIPT', '公司撤回回执需核对')
                safe = self.receiver._item(answer['item'], channel)
                if safe['status'] != 'withdrawn' or safe['current_consent_valid'] or safe['revision'] != row['expected_revision'] + 1:
                    _fail('INVALID_RECEIPT', '公司撤回原版本回执不一致')
                receipt = self._withdraw_status(snap, user, channel, row)
                if receipt['state'] != 'recorded':
                    _fail('INVALID_RECEIPT', '公司撤回原号尚未确认')
                delivery = None
                replayed = answer['replayed']
            else:
                if (not isinstance(answer, dict) or set(answer) != {'delivery', 'read_only', 'mutation_committed', 'auto_retry'}
                        or not valid_delivery(answer.get('delivery'), snap['actor'], self._cloud_action(action), body)
                        or any(type(answer[k]) is not type(answer['delivery'][k]) or answer[k] != answer['delivery'][k]
                            for k in ('read_only', 'mutation_committed', 'auto_retry')) or answer['delivery']['state'] != 'recorded'):
                    _fail('INVALID_RECEIPT', '公司联系方式原号回执需核对')
                delivery, receipt, replayed = deepcopy(answer['delivery']), None, answer['delivery']['replayed']
                _, safe = self._detail(snap, user, channel)
                if action == REVEAL and not replayed and (not safe['current_consent_valid'] or safe['status'] not in ('submitted', 'accepted')):
                    _fail('CURRENT_CHANGED', '返回联系方式前公司同意已变化，未返回受保护内容')
            self._fence(snap, user)
            with self.core.lock, self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                self._fence(snap, user)
                if self._row(db, action, channel, snap['actor']) != row:
                    _fail('ATTEMPT_CONFLICT', '原联系方式操作已变化，请保留原号')
                recorded = dict(row, state='recorded', updated_at=int(self.clock()), revision=row['revision'] + 1)
                row = self._put(db, recorded, row)
            self._fence(snap, user)
            # This first invocation persisted its local intent/confirmation even
            # if the server returned an already recorded metadata-only result.
            return self._result(action, snap, safe, row, delivery, receipt, requested=True, read_only=False)
        except Exception:
            _fail('RESULT_UNKNOWN', '本次原操作尚未确认；只可核对原号，暂勿再次发布或解密', 503, mutation=None)
