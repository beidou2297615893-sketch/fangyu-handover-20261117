"""Read-only wx_channel HTTP contract. Connection is not account authentication."""
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode, urlsplit, parse_qs
from wechat_channels_connection import local_get

PLATFORM = 'wechat_channels'


def unwrap(payload):
    if not isinstance(payload, dict) or payload.get('code') != 0:
        raise RuntimeError('视频号接口失败：' + str(payload.get('message', '响应格式不兼容') if isinstance(payload, dict) else '响应格式不兼容'))
    value = payload.get('data')
    for _ in range(4):
        if not isinstance(value, dict): raise RuntimeError('视频号数据结构不兼容')
        for key in ('errCode', 'ret', 'retcode'):
            if key in value and value[key] not in (0, '0'): raise RuntimeError('视频号平台返回错误：' + str(value.get('errMsg', value[key])))
        base = value.get('BaseResponse')
        if isinstance(base, dict) and base.get('Ret', 0) not in (0, '0'): raise RuntimeError('视频号平台请求未成功')
        if isinstance(value.get('data'), dict): value = value['data']
        else: return value
    raise RuntimeError('视频号响应嵌套异常')


def video_reference(value):
    value = str(value or '').strip()
    if re.fullmatch(r'[0-9]{1,40}', value): return {'object_id': value}
    parsed = urlsplit(value)
    if parsed.scheme=='wxchannels' and parsed.netloc=='video' and re.fullmatch(r'/[0-9]{1,40}',parsed.path):
        return {'object_id':parsed.path[1:],'nonce_id':(parse_qs(parsed.query).get('nonce_id') or [''])[0]}
    if parsed.scheme != 'https' or parsed.hostname not in ('channels.weixin.qq.com', 'finder.video.qq.com', 'weixin.qq.com') or parsed.username or parsed.password or parsed.port:
        raise ValueError('请提供视频号数字视频 ID 或有效的微信视频号 HTTPS 分享链接')
    query = parse_qs(parsed.query)
    oid = (query.get('object_id') or query.get('objectId') or query.get('feedId') or [''])[0]
    nonce = (query.get('nonce_id') or query.get('objectNonceId') or [''])[0]
    return {'object_id': oid, 'nonce_id': nonce} if oid else {'url': value}


def reference(oid, nonce=''):
    return 'wxchannels://video/' + str(oid) + '?' + urlencode({'nonce_id': str(nonce)})


def page_info(data):
    cursor = data.get('lastBuffer', '')
    if not isinstance(cursor, (str, int)): raise RuntimeError('视频号分页标记格式不兼容')
    flag = data.get('continueFlag', data.get('downContinueFlag'))
    more = bool(cursor) if flag is None else flag not in (0, '0', False)
    if more and not cursor: raise RuntimeError('视频号声称还有下一页但没有分页标记')
    return {'has_more': more, 'cursor': str(cursor)}


def timestamp(value):
    if value in (None, ''): return ''
    try: return datetime.fromtimestamp(float(value), timezone.utc).isoformat()
    except (ValueError, TypeError, OSError, OverflowError): return str(value)


class Client:
    def __init__(self, account_dir, cancelled=lambda: False, *, _preview_call=None):
        if not account_dir: raise RuntimeError('视频号采集必须选择绑定账号')
        config = json.loads((Path(account_dir) / 'wechat_channels.json').read_text('utf-8'))
        self.endpoint = config.get('endpoint', '')
        self.bound = config.get('bound_client_id', '')
        self.cancelled = cancelled
        self._get=local_get
        if _preview_call is not None:
            from assistant.owner_channels_read import _OwnerChannelsCall
            if type(_preview_call) is _OwnerChannelsCall:
                if _preview_call.reads is None or Path(account_dir)!=_preview_call.directory:
                    raise ValueError('owner_preview_scope_invalid')
                _preview_call.check();self._get=_preview_call.local_get
                self._owner_preview_call=_preview_call
            else:
                from assistant.wechat_preview_service import _WechatPreviewCall
                if (type(_preview_call) is not _WechatPreviewCall or _preview_call.reads is None
                        or Path(account_dir)!=_preview_call.directory):raise ValueError('preview_scope_invalid')
                _preview_call.check();self._get=_preview_call.local_get
        if not self.bound: raise RuntimeError('请先绑定唯一视频号客户端；当前不支持多账号')

    def check(self, capability=None):
        if self.cancelled(): raise RuntimeError('采集已取消')
        data = unwrap(self._get(self.endpoint, '/api/channels/status', timeout=5))
        clients = data.get('client_list')
        if data.get('clients') != 1 or not isinstance(clients, list) or len(clients) != 1:
            raise RuntimeError('视频号必须只连接一个客户端，多客户端或断开时停止采集')
        client = clients[0]
        if client.get('remote_addr') != self.bound: raise RuntimeError('视频号客户端已变化，请重新确认并绑定')
        if client.get('fresh') is not True or client.get('api_ready') is not True: raise RuntimeError('视频号客户端未就绪，请打开视频号页面')
        if capability and client.get('supports_' + capability) is not True: raise RuntimeError('当前视频号页面不支持此读取接口')
        return {'connected': True, 'authenticated': False, 'verified': False, 'status': 'connected_unverified', 'message': '本地单一客户端已连接，可试采集；微信身份未验证'}

    def get(self, path, params, capability):
        self.check(capability)
        payload = self._get(self.endpoint, path + '?' + urlencode({k: v for k, v in params.items() if v != ''}), timeout=65)
        # Discard uncertain results if the single client changed during the request.
        self.check(capability)
        return unwrap(payload)

    def search(self, task):
        data = self.get('/api/channels/feed/search', {'keyword': ' '.join(task.get('keywords', [])), 'next_marker': task.get('next_cursor', '')}, 'search')
        items = data.get('objectList', data.get('object'))
        if not isinstance(items, list): raise RuntimeError('视频号搜索响应缺少视频列表，不能当作零结果')
        task['_page_info'] = page_info(data)
        if task['_page_info']['has_more'] and task['_page_info']['cursor']==task.get('next_cursor',''): raise RuntimeError('视频号分页游标未前进，已停止')
        rows = []
        for item in items:
            if not isinstance(item, dict) or not item.get('id'): raise RuntimeError('视频号搜索条目缺少视频 ID')
            contact = item.get('contact') or {}
            text = (item.get('objectDesc') or {}).get('description', '')
            rows.append({'platform': PLATFORM, 'source_id': str(item['id']), 'source_type': 'note', 'title': text, 'text': text, 'author': contact.get('nickname', ''), 'author_id': contact.get('username', ''), 'published_at': timestamp(item.get('createtime')), 'region': '', 'url': reference(item['id'], item.get('objectNonceId', ''))})
        return rows

    def comments(self, task):
        owner=getattr(self,'_owner_preview_call',None)
        if owner is not None:owner.check_spec(task)
        ref = video_reference(task.get('note_url'))
        if not ref.get('object_id') or not ref.get('nonce_id'):
            data = self.get('/api/channels/feed/profile', ref, 'profile')
            obj = data.get('object')
            if not isinstance(obj, dict) or not obj.get('id') or not obj.get('objectNonceId'): raise RuntimeError('未能从视频详情解析 ID 与 nonce，不能读取评论')
            ref = {'object_id': str(obj['id']), 'nonce_id': str(obj['objectNonceId'])}
        data = self.get('/api/channels/feed/comment/list', {**ref, 'next_marker': task.get('next_cursor', '')}, 'comment')
        items = data.get('commentInfo')
        if not isinstance(items, list): raise RuntimeError('视频号响应缺少评论列表，不能当作零结果')
        task['_page_info'] = page_info(data)
        if task['_page_info']['has_more'] and task['_page_info']['cursor']==task.get('next_cursor',''): raise RuntimeError('视频号分页游标未前进，已停止')
        rows = []
        def append(item, parent=''):
            if not isinstance(item, dict) or not item.get('commentId'): raise RuntimeError('视频号评论缺少来源 ID')
            region = item.get('ipRegionInfo') or {}
            region = region.get('regionText', '') if isinstance(region, dict) else ''
            text = item.get('content', '')
            rows.append({'platform': PLATFORM, 'source_id': str(ref['object_id']) + ':comment:' + str(item['commentId']), 'comment_id': str(item['commentId']), 'parent_id': parent or str(item.get('replyCommentId') or ''), 'source_type': 'comment', 'text': text, 'title': text[:100], 'author': item.get('nickname', ''), 'author_id': item.get('username', ''), 'published_at': timestamp(item.get('createtime')), 'region': region, 'note_url': reference(ref['object_id'], ref['nonce_id']), 'url': reference(ref['object_id'], ref['nonce_id']), 'comment_level': 2 if parent else 1})
            # Only returned nested comments; do not claim all replies were fetched.
            if not parent:
                for child in item.get('levelTwoComment') or []: append(child, str(item['commentId']))
        for item in items: append(item)
        return rows
