"""One fixed own search page; separately reviewed internal or host-bound customer purpose."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import sys
from .runtime_license_policy import _plain, _file_hash
from .douyin_comments_policy import _digest

_PURPOSE='douyin_owned_keyword_search_page'
_SOURCE=Path(__file__).resolve().parents[1]
_LIMITS={'first_page_only':True,'max_items':20,'offset':0,'search':True,
    'comments':False,'reply':False,'dm':False,'platform_identity_before_after':True,
    'real_platform_verified':False,'production_approval':False,'distribution_approval':False}

class DouyinSearchPolicy:
    def __init__(self,server,*,review_sha=None):
        if review_sha is not None and (type(review_sha) is not str or re.fullmatch(r'[0-9A-F]{64}',review_sha) is None):
            raise ValueError('douyin_search_component_pending')
        self._server=server
        self._review_sha=review_sha
        self._self_hash=_file_hash(Path(__file__)).upper()

    def _snapshot(self):
        from bridge import BridgeManager
        server=self._server
        customer=getattr(server,'_customer_distribution_purpose',lambda purpose:None)(_PURPOSE)
        if customer is not None:
            try:
                from assistant.customer_read_lease import current as current_read_lease
            except ImportError:raise ValueError('douyin_search_component_pending') from None
            if current_read_lease(server,_PURPOSE) is not True:
                raise ValueError('douyin_search_component_pending')
        scope='customer_distribution_read' if customer is not None else 'internal_self_use_read'
        if ((getattr(sys,'frozen',False) and customer is None) or not server.employee_workspace_mode
                or getattr(server,'self_operating_read',False)
                or getattr(server,'_self_operating_reads',None) is not None
                or Path(server.core.resources_dir)!=_SOURCE/'resources'
                or type(server.bridge) is not BridgeManager
                or server.bridge.runtime!=_SOURCE.parent/'work/runtime/douyin-bridge'
                or server._runtime_license_usage_scope(scope)!=scope
                or server.company.get('id')!='fangyu-apartment-client' or server.closing):
            raise ValueError('douyin_search_component_pending')
        runtime=server.bridge.runtime
        if any((runtime/'node_modules'/name).exists() for name in ('bufferutil','utf-8-validate')):
            raise ValueError('douyin_search_component_pending')
        manifest=server.core.adapters.manifest('douyin')
        original=[str(runtime/'cli.js'),'search','{keyword}','--count','{limit}',
            '--conn-id','{conn_id}','--no-store']
        if (manifest.get('search_args')!=original or Path(manifest.get('executable',''))!=runtime/'node.exe'
                or manifest.get('prefix_args') not in (None,[]) or manifest.get('env') not in (None,{})
                or manifest.get('mapper')!='douyin_bridge' or manifest.get('isolation_guard') is not True
                or manifest.get('search_verified') is not False):
            raise ValueError('douyin_search_component_pending')
        return deepcopy({'company':server.company['id'],'runtime':str(runtime),'purpose':_PURPOSE,
            'scope':scope,'executable':str(runtime/'node.exe'),
            'args':[str(runtime/'cli.js'),'search','{keyword}','--offset','0','--count','{limit}',
                '--conn-id','{conn_id}','--no-store','--no-log']})

    def current_review(self):
        customer=getattr(self._server,'_customer_distribution_purpose',lambda purpose:None)(_PURPOSE)
        if customer is not None:
            self._snapshot()
            return customer['revision']
        if (self._review_sha is None or _file_hash(_plain(Path(__file__),_SOURCE)).upper()!=self._self_hash
                or _file_hash(_plain(_SOURCE/'resources/douyin-owned-search/review.json',_SOURCE)).upper()!=self._review_sha):
            raise ValueError('douyin_search_component_pending')
        return self._review_sha

    def resolve(self):
        customer=getattr(self._server,'_customer_distribution_purpose',lambda purpose:None)(_PURPOSE)
        if customer is not None:
            try:
                snapshot=self._snapshot()
                return {'purpose':_PURPOSE,'revision':_digest([customer['revision'],snapshot])}
            except (ValueError,TypeError,KeyError,OSError):return None
        if self._review_sha is None:return None
        try:
            snapshot=self._snapshot();self.current_review()
            record=json.loads((_SOURCE/'resources/douyin-owned-search/review.json').read_text('utf8'))
            if (type(record) is not dict or set(record)!={'schema','purpose','scope','company_id','limits','materials','evidence'}
                    or type(record['schema']) is not int or record['schema']!=1
                    or record['purpose']!=_PURPOSE or record['scope']!='internal_self_use_read'
                    or record['company_id']!=snapshot['company'] or type(record['limits']) is not dict
                    or record['limits']!=_LIMITS or any(type(record['limits'][k]) is not type(v) for k,v in _LIMITS.items())
                    or type(record['materials']) is not list or not record['materials']):
                raise ValueError('douyin_search_component_pending')
            facts=[];seen=set()
            for item in record['materials']:
                if (type(item) is not dict or set(item)!={'root','path','sha256','bytes','role'}
                        or item['root'] not in ('source','douyin_runtime') or type(item['path']) is not str
                        or '\\' in item['path'] or ':' in item['path']
                        or any(p in ('','.','..') for p in item['path'].split('/'))
                        or (item['root'],item['path']) in seen or type(item['sha256']) is not str
                        or re.fullmatch(r'[0-9A-F]{64}',item['sha256']) is None
                        or type(item['bytes']) is not int or item['bytes']<0 or type(item['role']) is not str):
                    raise ValueError('douyin_search_component_pending')
                root=_SOURCE if item['root']=='source' else self._server.bridge.runtime
                path=_plain(root/item['path'],root);before=path.stat()
                if before.st_size!=item['bytes'] or _file_hash(path).upper()!=item['sha256']:
                    raise ValueError('douyin_search_component_pending')
                after=path.stat()
                if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
                    raise ValueError('douyin_search_component_pending')
                seen.add((item['root'],item['path']));facts.append(item)
            required={('source',p) for p in ('core/douyin_search_policy.py','core/douyin_owned_search.py',
                'core/platform_reads.py','core/adapters.py','assistant/product_workspace.py',
                'assistant/douyin_connection_service.py','account_connections.py','bridge.py')}
            required|={('douyin_runtime',p) for p in ('node.exe','cli.js','lib/commands/search.js',
                'lib/commands/index.js','scripts/douyin.user.js')}
            if not required<=seen or snapshot!=self._snapshot():raise ValueError('douyin_search_component_pending')
            self.current_review()
            return {'purpose':_PURPOSE,'revision':_digest([self._review_sha,facts,snapshot])}
        except (ValueError,TypeError,KeyError,OSError):return None
