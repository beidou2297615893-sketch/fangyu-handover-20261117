"""Owned WebView2 login window with one job-owned candidate staging.

Only --offline is exercised in QA. The caller must run its current safety
guard before launching --live with a fresh, job-owned candidate tempHOME.
New callers explicitly select an account-owned persistent WebView2 profile;
legacy callers without --profile-dir retain a disposable private profile.
The opt-in natural route observes the page's own getMe before staging; the
legacy route still leaves identity verification to the parent's CLI status.
"""

from __future__ import annotations

import argparse
from contextlib import nullcontext
import json
import os
from http.server import ThreadingHTTPServer
from pathlib import Path
import secrets
import re
import stat
import sys
from threading import Event, Lock, Thread
import tempfile
from urllib.parse import urlsplit

if __package__:
    from .auth_candidate import (
        CandidateRejected, XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES,
        extract_scoped_cookies, extract_xhs_candidate,
    )
    from .cli_staging import discard_cli_candidate, stage_cli_candidate_once, validate_job_paths
    from .offline_webview_probe import HERE, PROBE_NAME, make_handler
    from .owned_webview2_cookies import read_owned_window_cookies
    from .login_natural_proof import NaturalProofError, PROOF_NAME, read_spec, write_proof
    from .native_login_observer import NativeLoginObserver, NativeLoginError
else:
    from auth_candidate import (
        CandidateRejected, XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES,
        extract_scoped_cookies, extract_xhs_candidate,
    )
    from cli_staging import discard_cli_candidate, stage_cli_candidate_once, validate_job_paths
    from offline_webview_probe import HERE, PROBE_NAME, make_handler
    from owned_webview2_cookies import read_owned_window_cookies
    # Direct script mode starts with only this directory on sys.path.
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from assistant.login_natural_proof import NaturalProofError, PROOF_NAME, read_spec, write_proof
    from assistant.native_login_observer import NativeLoginObserver, NativeLoginError


XHS_ENTRY_URL = "https://www.xiaohongshu.com/explore"
QA_PERSISTENT_NAME = "__qa_persistent"
WINDOW_TIMEOUT_SECONDS = 240
AUTH_CHECK_INTERVAL_SECONDS = 0.8
WEB_PROFILE_NAME = 'xhs-browser-profile'

# Fixed, credential-free evidence survives cleanup of the candidate job.
_RECORDED_OUTCOMES = frozenset({
    'candidate_staged_unverified', 'candidate_staged_natural_verified',
    'cancelled', 'closed', 'timeout', 'safety_hold',
    'cookie_missing', 'cookie_shape_invalid', 'cookie_domain_mismatch',
    'cookie_not_secure', 'cookie_duplicate_or_empty', 'cookie_expiry_invalid',
    'cookie_expiry_missing', 'cookie_expired', 'cookie_oversize', 'cookies_oversize',
    'origin_invalid', 'origin_mismatch', 'candidate_capture_failed', 'window_failed',
    'reader_timeout', 'reader_failed', 'reader_url_failed', 'reader_import_failed',
    'reader_form_failed', 'reader_browser_failed', 'reader_control_failed',
    'reader_identity_failed', 'reader_uninitialized', 'owned_window_invalid',
    'staging_exists', 'staging_write_failed', 'staging_cleanup_failed',
    'profile_path_invalid',
    'natural_identity_unverified', 'natural_proof_invalid',
    'natural_proof_write_failed', 'native_cdp_unavailable',
    'native_initial_source_invalid', 'native_pending',
    'verification_required', 'not_authenticated',
})


def record_live_outcome(staging_root: Path, code: str) -> bool:
    """Record only an enumerated outcome for a validated account-owned job."""
    if code not in _RECORDED_OUTCOMES or not isinstance(staging_root, Path):
        return False
    try:
        if (not staging_root.is_absolute() or not staging_root.is_dir()
                or not re.fullmatch(r'[a-f0-9]{24}', staging_root.name)
                or staging_root.parent.name != 'browser-login'
                or staging_root.parent.parent.name != 'work'
                or not re.fullmatch(r'[a-f0-9]{32}', staging_root.parent.parent.parent.name)):
            return False
        for part in (staging_root, *staging_root.parents):
            attrs = getattr(os.lstat(part), 'st_file_attributes', 0)
            if part.is_symlink() or attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
                return False
        output = staging_root.parent / (staging_root.name + '.outcome.json')
        payload = json.dumps({'version': 1, 'helper_outcome': code}, separators=(',', ':')).encode('utf-8')
        fd = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
        return True
    except (OSError, ValueError, TypeError):
        return False

# Read only the visible navigation DOM in this owned window. A guest login
# button, a cookie, or another person's profile link is not an auth signal.
# The profile id must be concrete ("me" and login redirects do not qualify).
OWN_PROFILE_MARKER_JS = r"""(() => {
  if (location.origin !== 'https://www.xiaohongshu.com') return false;
  const visible = (node) => {
    const style = getComputedStyle(node);
    const rect = node.getBoundingClientRect();
    return style.display !== 'none' && style.visibility === 'visible' &&
      Number(style.opacity) > 0 && rect.width > 0 && rect.height > 0;
  };
  return Array.from(document.querySelectorAll('a[href]')).some((link) => {
    if (!visible(link)) return false;
    const nav = link.closest('nav, aside, [role="navigation"], [class*="side-bar"], [class*="sidebar"]');
    if (!nav || !visible(nav)) return false;
    const label = (link.innerText || link.getAttribute('aria-label') || '').trim();
    if (label !== '我' && label !== '我的') return false;
    const target = new URL(link.getAttribute('href'), location.href);
    return target.origin === location.origin &&
      /^\/user\/profile\/[A-Za-z0-9]{8,64}\/?$/.test(target.pathname);
  });
})()"""


def _is_xhs_origin(url: str) -> bool:
    try:
        parsed = urlsplit(url)
        return (parsed.scheme == "https" and parsed.hostname == "www.xiaohongshu.com"
                and parsed.port in (None, 443) and not parsed.username
                and not parsed.password)
    except (TypeError, ValueError):
        return False


def _persistent_profile_path(staging_root: Path, profile_dir: Path) -> Path:
    """Accept only this account's fixed XHS profile, never a job or user profile."""
    try:
        expected = staging_root.parent.parent.parent / WEB_PROFILE_NAME
        if (not profile_dir.is_absolute() or profile_dir != expected
                or staging_root.parent.name != 'browser-login'
                or staging_root.parent.parent.name != 'work'):
            raise CandidateRejected('profile_path_invalid')
        for part in (expected.parent, expected):
            if (part.is_symlink() or hasattr(part, 'is_junction') and part.is_junction()
                    or part.exists() and getattr(os.lstat(part), 'st_file_attributes', 0)
                       & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                raise CandidateRejected('profile_path_invalid')
        if expected.exists() and not expected.is_dir():
            raise CandidateRejected('profile_path_invalid')
        return expected
    except (IndexError, OSError, ValueError, TypeError):
        raise CandidateRejected('profile_path_invalid') from None


class LoginWindowController:
    def __init__(self, *, mode: str, initial_url: str, staging_root: Path,
                 cancel_file: Path, guard=None, qa_tokens: tuple[str, str] | None = None,
                 natural_observer=None, before_navigation=None):
        self.mode = mode
        self.initial_url = initial_url
        self.staging_root = staging_root
        self.cancel_file = cancel_file
        self.guard = guard
        self.qa_tokens = qa_tokens
        self.window = None
        self.lock = Lock()
        self.finished = Event()
        self.phase = "waiting_for_user"
        self.finish_count = 0
        self.stage_path: Path | None = None
        self.qa_verified = False
        self.natural_observer = natural_observer
        self.before_navigation = before_navigation
        self.natural_evidence = None
        self.natural_cookies = None

    def attach(self, window):
        self.window = window

    def _guard_current(self) -> bool:
        if self.guard is None:
            return True
        try:
            return self.guard() is True
        except Exception:
            return False

    def finish(self):
        """Produce one candidate; natural mode requires current native evidence."""
        with self.lock:
            if self.phase != "waiting_for_user":
                return
            self.phase = "capturing"
            self.finish_count += 1
        if self.cancel_file.exists():
            self._close_with("cancelled")
            return
        if not self._guard_current():
            self._close_with("safety_hold")
            return
        try:
            current_url = self.window.get_current_url()
            if self.mode == "offline":
                if current_url != self.initial_url:
                    raise CandidateRejected("origin_mismatch")
                names = frozenset({PROBE_NAME, QA_PERSISTENT_NAME})
            else:
                if not _is_xhs_origin(current_url):
                    raise CandidateRejected("origin_mismatch")
                names = XHS_COOKIE_NAMES
            raw = read_owned_window_cookies(
                self.window, expected_url=current_url, allowed_names=names, timeout_s=10,
            )
            if self.mode == "offline":
                cookies = extract_scoped_cookies(
                    raw, current_url=current_url, expected_host="127.0.0.1", scheme="http",
                    allowed_names=names, required_names=names,
                    allowed_cookie_domains=frozenset({"127.0.0.1"}),
                )
                by_name = {item.name: item for item in raw if item.name in names}
                if (set(by_name) != names or not by_name[PROBE_NAME].is_session
                        or by_name[QA_PERSISTENT_NAME].is_session
                        or not all(item.httponly for item in by_name.values())):
                    raise CandidateRejected("qa_cookie_metadata_invalid")
            else:
                cookies = extract_xhs_candidate(raw, current_url=current_url)
            evidence = None
            if self.natural_observer is not None:
                evidence = self.natural_observer.bind_candidate(cookies)
                if evidence is None:
                    raise CandidateRejected('natural_identity_unverified')
            if self.cancel_file.exists():
                raise CandidateRejected("cancelled")
            if not self._guard_current():
                raise CandidateRejected("safety_hold")
            path = stage_cli_candidate_once(
                cookies, staging_root=self.staging_root, cancel_file=self.cancel_file,
                allowed_names=names,
                required_names=names if self.mode == "offline" else XHS_REQUIRED_NAMES,
            )
            with self.lock:
                if self.phase != "capturing":
                    discard_cli_candidate(path)
                    return
                self.stage_path = path
            if self.natural_observer is not None:
                if not self.natural_observer.evidence_current(evidence, cookies):
                    raise CandidateRejected('natural_identity_unverified')
                write_proof(self.staging_root, path, evidence)
                if (self.cancel_file.exists() or not self._guard_current()
                        or not self.natural_observer.evidence_current(evidence, cookies)):
                    raise CandidateRejected('natural_identity_unverified')
            if self.mode == "offline" and self.qa_tokens is not None:
                self._qa_check_stage()
            with self.lock:
                if self.phase != "capturing":
                    discard_cli_candidate(path)
                    return
                self.phase = ("candidate_staged_natural_verified" if evidence is not None
                              else "candidate_staged_unverified")
            self.finished.set()
            self._destroy_window()
        except CandidateRejected as exc:
            self._close_with(exc.code)
        except NaturalProofError as exc:
            self._close_with(exc.code)
        except Exception:
            self._close_with("candidate_capture_failed")

    def check_authenticated(self) -> bool:
        """Inspect only this window's same-origin visible navigation; never log in."""
        if self.mode != "live" or self.window is None:
            return False
        with self.lock:
            if self.phase != "waiting_for_user":
                return False
        if self.cancel_file.exists():
            self.cancel()
            return False
        if not self._guard_current():
            self._close_with("safety_hold")
            return False
        if self.natural_observer is not None:
            code = self.natural_observer.poll()
            if code == 'identity_observed':
                self.finish()
                return self.phase == 'candidate_staged_natural_verified'
            if code not in ('pending', 'guest_waiting', 'awaiting_cookie_proof',
                            'document_untrusted'):
                self._close_with(code if code in ('verification_required',
                                                  'not_authenticated')
                                 else 'natural_identity_unverified')
            return False
        try:
            before = self.window.get_current_url()
            if not _is_xhs_origin(before):
                return False
            marker = self.window.evaluate_js(OWN_PROFILE_MARKER_JS)
            if marker is not True or self.window.get_current_url() != before:
                return False
        except Exception:
            # Loading, navigation and unsupported DOM states remain pending.
            return False
        if self.cancel_file.exists():
            self.cancel()
            return False
        self.finish()
        return True

    def watch_authenticated(self):
        if self.natural_observer is not None:
            try:
                if not self.window.events.shown.wait(15):
                    raise NativeLoginError('native_pending')
                self.natural_observer.attach()
                if self.finished.is_set():
                    return
                if self.before_navigation is not None:
                    self.before_navigation(self.window,self.natural_observer)
                if self.finished.is_set() or self.cancel_file.exists() or not self._guard_current():
                    self._close_with('cancelled');return
                self.window.load_url(self.initial_url)
            except NativeLoginError as error:
                self._close_with(error.code)
                return
            except Exception:
                self._close_with('native_cdp_unavailable')
                return
        while not self.finished.wait(AUTH_CHECK_INTERVAL_SECONDS):
            self.check_authenticated()

    def _qa_check_stage(self):
        """Synthetic QA only; verifies format, never a platform identity."""
        path = self.stage_path
        if path is None or self.qa_tokens is None:
            raise CandidateRejected("qa_stage_missing")
        payload = json.loads(path.read_text(encoding="utf-8"))
        if (set(payload) != {PROBE_NAME, QA_PERSISTENT_NAME, "saved_at"}
                or payload.get(PROBE_NAME) != self.qa_tokens[0]
                or payload.get(QA_PERSISTENT_NAME) != self.qa_tokens[1]
                or not isinstance(payload.get("saved_at"), (int, float))):
            raise CandidateRejected("qa_stage_mismatch")
        self.qa_verified = True
        discard_cli_candidate(path)
        with self.lock:
            self.stage_path = None

    def _destroy_window(self):
        if self.window is not None:
            try:
                self.window.destroy()
            except Exception:
                pass

    def _close_with(self, code: str):
        with self.lock:
            if self.phase not in {"waiting_for_user", "capturing"} and not (
                self.phase == "candidate_staged_unverified" and not self.finished.is_set()
            ):
                return
            self.phase = code
        self.cleanup()
        if self.natural_observer is not None:
            self.natural_observer.cancel()
        self.finished.set()
        self._destroy_window()

    def cancel(self):
        self._close_with("cancelled")

    def on_closed(self):
        with self.lock:
            if self.phase in {"waiting_for_user", "capturing"}:
                self.phase = "closed"
        if self.phase != "candidate_staged_unverified":
            if self.phase != 'candidate_staged_natural_verified':
                self.cleanup()
        self.finished.set()

    def cleanup(self):
        with self.lock:
            path, self.stage_path = self.stage_path, None
        try:
            discard_cli_candidate(path)
            if self.natural_observer is not None:
                (self.staging_root / PROOF_NAME).unlink(missing_ok=True)
        except CandidateRejected:
            with self.lock:
                self.phase = "staging_cleanup_failed"

    def timeout(self):
        if not self.finished.wait(WINDOW_TIMEOUT_SECONDS):
            self._close_with("timeout")

    def watch_cancel(self):
        while not self.finished.wait(0.3):
            if self.cancel_file.exists():
                self.cancel()
                return


def run_login_window(*, mode: str, staging_root: Path, cancel_file: Path,
                     profile_dir: Path | None = None,
                     guard=None, qa_auto_finish: bool = False,
                     natural_identity: bool = False, before_navigation=None) -> str:
    """Run one browser window, returning only a fixed status code."""
    if mode not in {"offline", "live"}:
        return "mode_invalid"
    if mode == "live" and qa_auto_finish:
        return "qa_mode_invalid"
    if natural_identity and (mode != 'live' or profile_dir is None):
        return 'mode_invalid'
    try:
        validate_job_paths(staging_root, cancel_file)
    except CandidateRejected as exc:
        return exc.code
    if cancel_file.exists():
        return "cancelled"
    if (staging_root / ".xiaohongshu-cli").exists():
        return "staging_exists"
    persistent_profile = mode == 'live' and profile_dir is not None
    natural_spec = None
    if natural_identity:
        try:
            natural_spec = read_spec(staging_root)
        except NaturalProofError as error:
            return error.code
    if persistent_profile:
        try:
            profile_dir = _persistent_profile_path(staging_root, profile_dir)
        except CandidateRejected as exc:
            return exc.code
    if mode == "live" and guard is not None and not callable(guard):
        return "guard_required"
    if guard is not None:
        try:
            if guard() is not True:
                return "safety_hold"
        except Exception:
            return "safety_hold"

    # Import only after mode/path checks; offline QA stays on localhost.
    import webview
    from webview.menu import Menu, MenuAction

    server = None
    thread = None
    qa_tokens = None
    if mode == "offline":
        qa_tokens = (secrets.token_urlsafe(24), secrets.token_urlsafe(24))
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(*qa_tokens))
        server.daemon_threads = True
        thread = Thread(target=server.serve_forever, name="owned-login-qa-http", daemon=True)
        thread.start()
        initial_url = f"http://127.0.0.1:{server.server_port}/"
    else:
        initial_url = XHS_ENTRY_URL

    observer = (NativeLoginObserver(None, job_id=natural_spec['job_id'],
                                    bound_uid=natural_spec['bound_uid'])
                if natural_spec is not None else None)
    controller = LoginWindowController(mode=mode, initial_url=initial_url,
                                       staging_root=staging_root, cancel_file=cancel_file,
                                       guard=guard,
                                       qa_tokens=qa_tokens if qa_auto_finish else None,
                                       natural_observer=observer,before_navigation=before_navigation)
    menu = [Menu("账号操作", [MenuAction("取消", controller.cancel)])]
    code = "window_failed"
    try:
        window = webview.create_window(
            "请用手机扫码；网页显示本人账号后自动核对",
            'about:blank' if natural_identity else initial_url,
            width=760, height=700, js_api=None, menu=menu,
        )
        controller.attach(window)
        if observer is not None:
            observer.window = window
        window.events.closed += controller.on_closed
        if qa_auto_finish:
            # Python QA callback, no webpage JS bridge or real login.
            window.events.loaded += controller.finish
        Thread(target=controller.timeout, name="owned-login-timeout", daemon=True).start()
        Thread(target=controller.watch_cancel, name="owned-login-cancel", daemon=True).start()
        if mode == "live":
            Thread(target=controller.watch_authenticated,
                   name="owned-login-auth-marker", daemon=True).start()
        # New live callers reuse their account-owned profile. Legacy live
        # callers and offline QA use disposable private profiles in the job.
        # Candidate credentials always stay in the separate job staging path.
        if persistent_profile:
            profile_dir.mkdir(mode=0o700, exist_ok=True)
            _persistent_profile_path(staging_root, profile_dir)
        profile_context = (nullcontext(profile_dir) if persistent_profile else
                           tempfile.TemporaryDirectory(prefix="owned-login-profile-", dir=staging_root))
        with profile_context as profile_root:
            storage_path = Path(profile_root) if persistent_profile else Path(profile_root) / 'profile'
            webview.start(gui="edgechromium", private_mode=not persistent_profile,
                          storage_path=str(storage_path), debug=False)
        code = controller.phase
    except Exception:
        code = "window_failed"
    finally:
        controller.finished.set()
        if observer is not None:
            observer.close()
        if code not in ("candidate_staged_unverified", 'candidate_staged_natural_verified'):
            controller.cleanup()
        if server is not None:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
    if qa_auto_finish:
        return ("qa_finish_once_ok" if controller.qa_verified
                and controller.finish_count == 1 and controller.stage_path is None
                and code == "candidate_staged_unverified" else "qa_finish_failed")
    return code


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Owned browser login preparation")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--offline", action="store_true")
    mode.add_argument("--live", action="store_true")
    parser.add_argument("--staging-dir", type=Path)
    parser.add_argument("--cancel-file", type=Path)
    parser.add_argument("--profile-dir", type=Path)
    parser.add_argument("--qa-auto-finish", action="store_true")
    parser.add_argument('--natural-identity', action='store_true')
    args = parser.parse_args(argv)
    if args.live:
        if args.staging_dir is None or args.cancel_file is None:
            code = "arguments_invalid"
        else:
            code = run_login_window(mode="live", staging_root=args.staging_dir,
                                    cancel_file=args.cancel_file, profile_dir=args.profile_dir,
                                    natural_identity=args.natural_identity)
    elif (args.staging_dir is not None or args.cancel_file is not None
          or args.profile_dir is not None or args.natural_identity):
        code = "arguments_invalid"
    else:
        with tempfile.TemporaryDirectory(prefix="offline-login-job-", dir=HERE) as root:
            job = Path(root)
            code = run_login_window(mode="offline", staging_root=job,
                                    cancel_file=job / "cancel.flag",
                                    qa_auto_finish=args.qa_auto_finish)
    if args.live and args.staging_dir is not None:
        record_live_outcome(args.staging_dir, code)
    print(code)
    return 0 if code in {"candidate_staged_unverified",
                         'candidate_staged_natural_verified', "qa_finish_once_ok"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
