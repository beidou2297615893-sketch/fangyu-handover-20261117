"""Local private strategy snapshots for the existing single-batch task runner.

Creating a task never invokes an adapter. Gateway callers must use project_task
for every externally visible strategy task and guard_task_action before mutation
or execution. The core's existing platform/account/runtime guards still apply.
"""
import hashlib
import json
import math
import re
import time
from copy import deepcopy
from datetime import datetime

from .acquisition_strategy import (AcquisitionStrategy, StrategyError, StrategyBusy,
                                   StrategyPermissionError, _integer, _text)


TASK_OPERATIONS = 'strategy_task_operations'
ACTIONS = frozenset({'strategy_task_create', 'strategy_task_get', 'strategy_task_status'})
SUPPORTED_PLATFORMS = frozenset({'xiaohongshu', 'douyin', 'zhihu', 'wechat_channels'})


def _hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, allow_nan=False,
                                    sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _operation_key(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,128}', value):
        raise StrategyError('幂等键必须为8到128位字母、数字、下划线或连字符')
    return value


def is_strategy_task(task):
    return isinstance(task, dict) and isinstance(task.get('strategy_source'), dict)


_PROGRESS_STATES = frozenset({'running', 'completed', 'failed', 'paused', 'stopped', 'waiting', 'idle', 'ready'})
_PROGRESS_STAGES = frozenset({'preparing', 'searching', 'reading_comments', 'filtering', 'saving',
                             'waiting', 'completed', 'stopped', 'failed', 'paused'})
_ANALYSIS_STATES = frozenset({'pending', 'running', 'ready', 'paused', 'completed', 'stopped', 'waiting', 'idle'})
_COMPLETION_COUNTS = ('read', 'filtered', 'duplicates', 'imported', 'deferred', 'remaining', 'batches')
_COMPLETION_STOPS = frozenset({'batch_limit', 'range_exhausted', 'target_reached', 'daily_limit',
    'three_empty_batches', 'user_paused', 'task_paused', 'operator_disabled', 'execution_failed'})
_AI_CODES = frozenset({'AI_INVALID_INPUT', 'AI_INVALID_OUTPUT', 'AI_BILLING_UNKNOWN',
    'AI_UNPRICED_MODEL', 'AI_TENANT_MISMATCH', 'AI_ADMIN_REQUIRED', 'AI_PROVIDER_TIMEOUT',
    'AI_PROVIDER_UNAVAILABLE', 'AI_PROVIDER_BODY_TOO_LARGE', 'AI_PROVIDER_INVALID_RESPONSE',
    'AI_LEDGER_CONFLICT', 'AI_PROVIDER_BALANCE', 'AI_PROVIDER_AUTH', 'AI_DAILY_BUDGET',
    'AI_NOT_CONFIGURED', 'AI_DISABLED', 'AI_PROVIDER_REJECTED', 'AI_IN_PROGRESS',
    'AI_TRANSACTION_UNAVAILABLE', 'AI_SERVICE_UNAVAILABLE', 'AI_UNAVAILABLE', 'AI_AUTH_REQUIRED',
    'AI_CONTEXT_REQUIRED', 'AI_CONFIG_CHANGED'})


def _safe_counts(value, fields):
    return {key: value[key] for key in fields
            if type(value.get(key)) is int and 0 <= value[key] <= 2 ** 53 - 1}


def _safe_enum(value, allowed, default='unknown'):
    return value if isinstance(value, str) and value in allowed else default


def project_strategy_progress(value):
    """Pure public projection: never expose source URLs or worker free text."""
    if not isinstance(value, dict) or not value:
        return {}
    state = _safe_enum(value.get('state'), _PROGRESS_STATES)
    stage = _safe_enum(value.get('stage'), _PROGRESS_STAGES)
    result = {'state': state, 'stage': stage, **_safe_counts(value, (
        'read', 'imported', 'batch_read', 'discovered_notes', 'browsed_notes', 'revision'))}
    messages = {'preparing': '后台采集准备中', 'searching': '后台采集正在检索',
                'reading_comments': '后台采集正在读取评论', 'filtering': '后台采集正在筛选',
                'saving': '后台采集正在保存', 'waiting': '后台采集等待下一批',
                'completed': '后台采集本批已完成', 'stopped': '后台采集本批已停止',
                'failed': '后台采集已暂停，请核对账号或采集许可', 'paused': '后台采集已暂停'}
    result['message'] = messages.get(stage, '后台采集状态待核对')
    if state == 'failed':
        result.update(error_code='collection_failed', message=messages['failed'])
    run_id = value.get('run_id')
    if isinstance(run_id, str) and re.fullmatch('[a-f0-9]{32}', run_id):
        result['run_id'] = run_id
    for key in ('elapsed_seconds', 'started_at_epoch'):
        number = value.get(key)
        if type(number) in (int, float) and math.isfinite(number) and 0 <= number < 10 ** 12:
            result[key] = number
    for key in ('started_at', 'updated_at'):
        stamp = value.get(key)
        if isinstance(stamp, str) and 10 < len(stamp) <= 40:
            try:
                datetime.fromisoformat(stamp)
            except ValueError:
                continue
            result[key] = stamp
    return result


def project_strategy_analysis(value):
    """Pure public analysis counters with fixed status/code explanations."""
    if not isinstance(value, dict) or not value:
        return {}
    status = _safe_enum(value.get('status'), _ANALYSIS_STATES)
    raw_code = value.get('code')
    code = _safe_enum(raw_code, _AI_CODES, 'AI_UNAVAILABLE' if raw_code else '')
    result = {'status': status, 'code': code, **_safe_counts(value, (
        'pending', 'excluded_missing_text', 'last_analyzed', 'retry_count', 'saved_total', 'analyzed_total'))}
    result['message'] = ('后台意向分析正在处理已保存评论' if status == 'running' else
                         '后台意向分析本批已完成' if status in ('ready', 'completed') else
                         '后台意向分析已暂停，已保存评论保留' if status in ('paused', 'stopped') else
                         '后台意向分析等待处理，已保存评论保留' if status in ('pending', 'waiting', 'idle') else
                         '后台意向分析状态待核对，已保存评论保留')
    if code == 'AI_CONTEXT_REQUIRED':
        result['message'] = '请补充意向分析资料，已保存评论保留'
    elif code in ('AI_INVALID_INPUT', 'AI_INVALID_OUTPUT', 'AI_BILLING_UNKNOWN', 'AI_LEDGER_CONFLICT'):
        result['message'] = '后台意向分析结果或记录待核对，已保存评论保留'
    retry_after = value.get('retry_after')
    if type(retry_after) in (int, float) and math.isfinite(retry_after) and 0 <= retry_after < 10 ** 12:
        result['retry_after'] = retry_after
    return result


class StrategyTasks:
    def __init__(self, core, tenant, owner, company):
        self.core, self.tenant, self.owner = core, tenant, owner
        self.strategy = AcquisitionStrategy(core, tenant, owner, company)

    def _authorize(self, user, private=False):
        with self.strategy._transaction() as db:
            manager = self.strategy._authorize(db, user, private)
            if user.get('cloud_bound') is not True:
                raise StrategyPermissionError('策略任务需要已绑定的员工身份')
        return manager

    def _task(self, task_id, user):
        self._authorize(user)
        task = self.core._get('tasks', task_id, self.tenant)
        self.core._task_access(user, task, self.tenant)
        source = task.get('strategy_source')
        if (not isinstance(source, dict) or source.get('strategy_id') != self.strategy.ident
                or task.get('cloud_owner') != self.owner or source.get('owner') != self.owner):
            raise StrategyPermissionError('策略任务归属不一致')
        return task

    def _find_task(self, operation, db=None):
        # Core owns creation ids. A persisted source operation id recovers the
        # small crash window between Core._save and our bounded task receipt.
        tasks = (self.core.store.list('tasks', self.tenant) if db is None else
                 [json.loads(row['body']) for row in db.execute(
                     'SELECT body FROM records WHERE entity=? AND tenant_id=?',
                     ('tasks', self.tenant)).fetchall()])
        candidates = [task for task in tasks
                      if is_strategy_task(task) and task['strategy_source'].get('operation_id') == operation['id']]
        if len(candidates) > 1:
            raise StrategyBusy('策略创建出现多个快照，请停止并核实')
        return candidates[0] if candidates else None

    def _status(self, data, user):
        """Read back one local creation; cancel absence atomically, never a lease.

        BEGIN IMMEDIATE is shared with create's operation insert, so an absent
        result cannot race a delayed first request into creating a second task.
        A preparing record is always unknown unless its unique task persisted.
        """
        if set(data) != {'idempotency_key'}:
            raise StrategyError('策略任务核对仅接受原操作编号')
        key = _operation_key(data['idempotency_key'])
        op_id = _hash(['strategy-task-v1', self.tenant, self.owner, key])
        with self.core.lock:
            with self.strategy._transaction() as db:
                manager = self.strategy._authorize(db, user)
                if user.get('cloud_bound') is not True:
                    raise StrategyPermissionError('策略任务需要已绑定的员工身份')
                row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                                 (TASK_OPERATIONS, op_id, self.tenant)).fetchone()
                operation = json.loads(row['body']) if row else None
                if operation is None:
                    # Retain the same deterministic id for every late create.
                    operation = {'id': op_id, 'tenant_id': self.tenant, 'owner': self.owner,
                                 'request_hash': None, 'task_id': None, 'phase': 'cancelled'}
                    self.strategy._put(db, TASK_OPERATIONS, operation)
                if (operation.get('id') != op_id or operation.get('tenant_id') != self.tenant
                        or operation.get('owner') != self.owner):
                    raise StrategyPermissionError('策略任务核对归属不一致')
                try:
                    task = self._find_task(operation, db)
                except StrategyBusy:
                    task, ambiguous = None, True
                else:
                    ambiguous = False
                task_id = task.get('id') if task else None
                source = task.get('strategy_source', {}) if task else {}
                valid_task = (task is not None and isinstance(task_id, str)
                              and task.get('tenant_id') == self.tenant
                              and task.get('cloud_owner') == self.owner
                              and source.get('owner') == self.owner
                              and source.get('strategy_id') == self.strategy.ident
                              and operation.get('task_id') in (None, task_id))
                state = ('known_saved' if valid_task else
                         'not_committed' if task is None and not ambiguous
                         and operation.get('phase') in ('cancelled', 'failed') else 'unknown')
            result = {'operation_action': 'strategy_task_create', 'idempotency_key': key,
                      'state': state, 'mutation_committed': {'known_saved': True,
                          'not_committed': False, 'unknown': None}[state],
                      'platform_requests_started': False, 'readback_only': True,
                      'storage_scope': 'this_device', 'cross_machine_verified': False,
                      'can_retry_with_new_key': state == 'not_committed' and manager,
                      # Status recovery uses the saved task, not a recreated payload.
                      'replay_same_key_allowed': False}
            if state == 'known_saved':
                # Re-authorize and re-read after the transaction before exposing.
                result.update(task_id=task_id, task=self.project_task(task_id, user))
            return result

    def project_task(self, task, user):
        """Re-read and whitelist; stored words, checkpoints and errors stay private."""
        task = self._task(task.get('id') if isinstance(task, dict) else task, user)
        source = task['strategy_source']
        result = {key: deepcopy(task[key]) for key in (
            'id', 'name', 'platform', 'account_id', 'scope', 'status', 'exhausted',
            'accumulated', 'daily_limit', 'target_count', 'created_at', 'updated_at',
            'last_run', 'sequence_status', 'sequence_batches') if key in task}
        # A newly saved Core task has no stored accumulated field. Read the
        # actual local records, using the same task/tenant count as the runner;
        # missing or stale stored counters must not become an invented zero.
        with self.core.lock:
            result['accumulated'] = sum(lead.get('task_id') == task['id']
                for lead in self.core.store.list('leads', self.tenant))
            # Counting can outlive the original authorization. The list reader
            # has closed its connection before reusing the mature authorization;
            # compare privately so a changed account/version never yields an old DTO.
            current = self._task(task['id'], user)
            if _hash(current) != _hash(task):
                raise StrategyBusy('原任务或账号绑定已变化，请重新核对当前记录')
        result.update(keywords=[], keywords_private=True, continuous_enabled=False,
                      last_message='后台策略采集已暂停，请核对账号或采集许可' if task.get('status') == 'paused'
                      else '后台策略本批已完成' if task.get('exhausted') else '后台策略快照已保存，按单批断点执行',
                      strategy={'id': source['strategy_id'], 'revision': source['revision'],
                                'keyword_count': source['keyword_count'],
                                'city': source['city'], 'area': source['area'],
                                'storage_scope': 'this_device', 'cross_machine_verified': False})
        batch = task.get('last_batch')
        if isinstance(batch, dict):
            result['last_batch'] = {key: batch[key] for key in (
                'read', 'filtered', 'duplicates', 'imported', 'deferred', 'completed_at') if key in batch}
        return result

    def project_completion(self, task_id, user, summary, *, original_binding, completion,
                           continuation_guard, scope_held):
        """Project one committed Core result; eligibility never dispatches or renews.

        The source is the existing Core summary and persisted original run, not
        a client estimate. ``remaining`` is comment import capacity. Snapshot
        slot counters remain separate and never estimate HTTP calls or clients.
        """
        from core import CoreError
        from core.adapters import AdapterSafetyRequired
        binding_fields = ('id', 'account_id', 'platform', 'scope', 'keywords',
                          'continuous_enabled', 'strategy_source')
        with self.core.lock:
            task = self._task(task_id, user)
            binding = {key: deepcopy(task[key]) for key in binding_fields if key in task}
            if binding != original_binding:
                raise StrategyBusy('原任务、账号或私有来源已变化，本批结果需按原记录核对')
            original_task_hash = _hash(task)
            if not isinstance(summary, dict):
                raise StrategyBusy('本批结果摘要待核对，不会自动继续')
            values = _safe_counts(summary, _COMPLETION_COUNTS)
            run_id = summary.get('run_id')
            if (len(values) != len(_COMPLETION_COUNTS) or values['batches'] not in (0, 1)
                    or not isinstance(run_id, str) or not re.fullmatch('[a-f0-9]{32}', run_id)
                    or type(summary.get('exhausted')) is not bool
                    or type(summary.get('can_continue')) is not bool
                    or summary.get('stop_reason') not in _COMPLETION_STOPS
                    or values['read'] < values['filtered'] + values['duplicates'] + values['imported']):
                raise StrategyBusy('本批结果计数或原运行编号待核对，不会自动继续')
            public = {'run_id': run_id, **values, 'exhausted': summary['exhausted'],
                      'can_continue': False, 'stop_reason': summary['stop_reason']}
            saved = (task.get('last_result') or {}).get('summary')
            fields = tuple(public)
            progress = self.core.task_progress(task_id) or {}
            if (not isinstance(saved, dict) or any(saved.get(key) != summary.get(key) for key in fields)
                    or progress.get('run_id') != run_id
                    or task.get('sequence_batches') != values['batches']
                    or bool(task.get('exhausted')) != public['exhausted']):
                raise StrategyBusy('本批摘要与原任务运行记录不一致，请核对原记录')
            if values['batches'] == 1:
                batch = task.get('last_batch') or {}
                if (batch.get('run_id') != run_id or any(batch.get(key) != values[key]
                        for key in ('read', 'filtered', 'duplicates', 'imported', 'deferred'))):
                    raise StrategyBusy('本批摘要与已保存批次不一致，请核对原记录')
            source = task['strategy_source']; words = task.get('keywords')
            total = source.get('keyword_count')
            done = (task.get('pipeline') or {}).get('keyword_index')
            if (type(total) is not int or not 1 <= total <= 100 or not isinstance(words, list)
                    or len(words) != total or source.get('snapshot_hash') != _hash(words)
                    or type(done) is not int or not 0 <= done <= total):
                raise StrategyBusy('本批私有快照进度待核对，不会自动继续')
            if (not isinstance(completion, dict) or type(completion.get('finished')) is not bool
                    or (completion['finished'] and (not public['exhausted'] or done != total))):
                raise StrategyBusy('本批完成记录待核对，不会自动继续')
            reason = 'execution_stopped'
            if completion['finished'] or public['exhausted']:
                reason = 'snapshot_finished'
            elif values['remaining'] == 0:
                reason = 'local_limit_reached'
            elif public['stop_reason'] == 'batch_limit' and summary['can_continue']:
                try:
                    continuation_guard()
                    account = self.core._get('accounts', task['account_id'], self.tenant)
                    self.core._account_access(user, account)
                    if account.get('status') != 'ready' or account.get('platform') != task.get('platform'):
                        reason = 'account_unavailable'
                    elif scope_held():
                        reason = 'scope_changed'
                    else:
                        self.core.require_platform(task['platform'])
                        self.core._platform_execution_guard(task['platform'])
                        directory = self.core.store.directory / 'accounts' / self.tenant / account['id']
                        self.core.adapters.require_account_safe(task['platform'], directory)
                        continuation_guard()  # fresh policy/actor after activity reading
                        public['can_continue'] = True
                        reason = 'eligible'
                except AdapterSafetyRequired:
                    reason = 'activity_review_required'
                except StrategyPermissionError:
                    reason = 'permission_changed'
                except StrategyBusy:
                    # The exact current policy/lease is read only to explain the
                    # refusal; no expired lease is released or replaced here.
                    with self.strategy._transaction() as db:
                        policy = self.strategy._load(db)
                    lease = policy.get('lease') or {}
                    expiry = lease.get('expires_at')
                    reason = ('lease_expired' if type(expiry) in (int, float)
                              and math.isfinite(expiry) and expiry <= time.time() else 'policy_changed')
                except (CoreError, OSError, ValueError):
                    reason = 'scope_changed'
            projected = self.project_task(task_id, user)
            if public['can_continue']:
                try:
                    continuation_guard()
                    if scope_held():
                        public['can_continue'] = False; reason = 'scope_changed'
                    else:
                        account = self.core._get('accounts', task['account_id'], self.tenant)
                        self.core._account_access(user, account)
                        if account.get('status') != 'ready' or account.get('platform') != task['platform']:
                            public['can_continue'] = False; reason = 'account_unavailable'
                        else:
                            self.core.adapters.require_account_safe(task['platform'],
                                self.core.store.directory / 'accounts' / self.tenant / account['id'])
                            continuation_guard()
                except AdapterSafetyRequired:
                    public['can_continue'] = False; reason = 'activity_review_required'
                except (CoreError, StrategyError, OSError, ValueError):
                    public['can_continue'] = False; reason = 'policy_changed'
            # These reads come after every eligibility callback. A late source
            # or actor change must not relabel a previously committed run.
            current = self._task(task_id, user)
            if _hash(current) != original_task_hash:
                raise StrategyBusy('本批投影期间原任务已变化，请按原记录核对')
            safe_completion = {'finished': completion['finished']}
            if not completion['finished']:
                safe_completion['reason'] = _safe_enum(completion.get('reason'),
                    {'lease_not_active', 'snapshot_not_exhausted', 'permission_changed'})
            safe_completion.update(_safe_counts(completion, ('quota_consumed', 'revision', 'queries_remaining')))
            safe_completion.update(keyword_count=total, completed_keyword_count=done,
                                   remaining_keyword_count=total-done, continuation_reason=reason)
            return {'task': projected, 'summary': public, 'strategy_completion': safe_completion}

    def _validate_snapshot(self, task, lease):
        source = task.get('strategy_source') or {}
        words = task.get('keywords')
        if (not isinstance(words, list) or not 1 <= len(words) <= 100
                or task.get('scope') != 'search_comments' or task.get('continuous_enabled') is not False
                or source.get('snapshot_hash') != _hash(words)
                or source.get('keyword_count') != len(words)
                or not isinstance(lease, dict) or source.get('lease_id') != lease.get('id')
                or words != [item['keyword'] for item in lease['keywords']]):
            raise StrategyBusy('私有采集快照或租约已变化，请停止并核实')

    def guard_task_action(self, task, action, data, user):
        """Apply at every existing gateway/core mutation route for these tasks."""
        task = self._task(task.get('id') if isinstance(task, dict) else task, user)
        if action in ('task_stop', 'cancel_task'):
            return task
        if action not in ('task_run', 'run_task_sequence'):
            raise StrategyPermissionError('后台策略快照已冻结，不能编辑、恢复或持续重扫')
        self._authorize(user, True)
        expected = {'task_id', 'max_batches'} if action == 'task_run' else {'id', 'max_batches'}
        ident_key = 'task_id' if action == 'task_run' else 'id'
        if (not isinstance(data, dict) or set(data) != expected or data.get(ident_key) != task['id']
                or type(data.get('max_batches')) is not int or data['max_batches'] != 1):
            raise StrategyError('后台策略任务仅允许明确指定 max_batches=1 的单批执行')
        with self.core.lock:
            # Refresh before opening the policy transaction; _task authorizes
            # through its own transaction and must not nest a SQLite writer.
            task = self._task(task['id'], user)
            with self.strategy._transaction() as db:
                self.strategy._authorize(db, user, True)
                policy = self.strategy._load(db)
                lease = policy.get('lease')
                self._validate_snapshot(task, lease)
                source = task['strategy_source']
                expiry = lease.get('expires_at')
                if (policy.get('enabled') is not True
                        or type(source.get('revision')) is not int
                        or type(policy.get('revision')) is not int
                        or source['revision'] + 1 != policy['revision']
                        or type(expiry) not in (int, float) or not math.isfinite(expiry)
                        or expiry <= time.time()):
                    raise StrategyBusy('后台策略或原租约已失效，请核实；不会自动重建或重放')
        if task.get('status') == 'paused' or task.get('exhausted'):
            raise StrategyBusy('该快照已暂停或完成，不能自动重放')
        return task

    def execute(self, action, data, user):
        if action not in ACTIONS or not isinstance(data, dict):
            raise StrategyError('后台策略任务操作无效')
        if action == 'strategy_task_status':
            return self._status(data, user)
        if action == 'strategy_task_get':
            if set(data) != {'task_id'} or not isinstance(data['task_id'], str):
                raise StrategyError('策略任务查询参数无效')
            return {'task': self.project_task(data['task_id'], user), 'platform_requests_started': False}
        allowed = {'expected_revision', 'idempotency_key', 'platform', 'account_id', 'name', 'batch_size'}
        if set(data) - allowed or not {'expected_revision', 'idempotency_key', 'platform', 'account_id'} <= set(data):
            raise StrategyError('策略任务参数越界；检索词与执行配置由后台提供')
        try:
            if len(json.dumps(data, ensure_ascii=False, allow_nan=False).encode()) > 8192:
                raise StrategyError('策略任务请求过大')
        except (TypeError, ValueError) as exc:
            raise StrategyError('策略任务参数格式无效') from exc
        self._authorize(user, True)
        revision = _integer(data['expected_revision'], 0, 2 ** 53 - 1, '策略版本')
        size = _integer(data.get('batch_size', 20), 1, 100, '快照数量')
        key = _operation_key(data['idempotency_key'])
        platform = data['platform']
        if not isinstance(platform, str) or platform not in SUPPORTED_PLATFORMS:
            raise StrategyError('当前平台未支持关键词到评论任务')
        account_id = data['account_id']
        if not isinstance(account_id, str) or not account_id or len(account_id) > 128:
            raise StrategyError('执行账号格式无效')
        name = _text(data.get('name', '后台策略采集'), 100, '任务名称')
        request = {'expected_revision': revision, 'idempotency_key': key, 'platform': platform,
                   'account_id': account_id, 'name': name, 'batch_size': size}
        digest = _hash(request)
        op_id = _hash(['strategy-task-v1', self.tenant, self.owner, key])
        with self.core.lock:
            with self.strategy._transaction() as db:
                self.strategy._authorize(db, user, True)
                row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                                 (TASK_OPERATIONS, op_id, self.tenant)).fetchone()
                operation = json.loads(row['body']) if row else None
                if operation:
                    if (operation.get('id') != op_id or operation.get('tenant_id') != self.tenant
                            or operation.get('owner') != self.owner):
                        raise StrategyPermissionError('策略任务创建归属不一致')
                    if operation.get('phase') == 'cancelled':
                        raise StrategyBusy('原操作已核对为未提交，迟到创建已阻止；请刷新后使用新编号')
                    if operation.get('request_hash') != digest:
                        raise StrategyError('幂等键已用于不同策略任务请求')
                    if operation.get('phase') == 'failed':
                        raise StrategyBusy('此前创建已停止，请核对后使用新的请求标识')
                else:
                    self.core.require_platform(platform)
                    account = self.core._get('accounts', account_id, self.tenant)
                    self.core._account_access(user, account)
                    if account.get('platform') != platform or account.get('cloud_owner') != self.owner:
                        raise StrategyPermissionError('执行账号与策略归属或平台不一致')
                    operation = {'id': op_id, 'tenant_id': self.tenant, 'owner': self.owner,
                                 'request_hash': digest, 'task_id': None, 'phase': 'preparing'}
                    self.strategy._put(db, TASK_OPERATIONS, operation)
            old = self._find_task(operation)
            if old:
                if old.get('strategy_source', {}).get('operation_id') != op_id:
                    raise StrategyBusy('策略任务标识冲突，请停止并核实')
                return {'task': self.project_task(old, user), 'replayed': True,
                        'platform_requests_started': False}
            if operation.get('phase') != 'preparing':
                raise StrategyBusy('策略任务记录缺失，请停止并核实')
            # A retry of a preparing operation never silently recreates an orphan.
            if row:
                raise StrategyBusy('策略快照创建结果待核实，租约不会自动重放')
            lease = None
            try:
                lease = self.strategy.reserve_batch(user, revision, 'task-reserve-' + op_id, size)
                summary = self.strategy.execute('strategy_get', {}, user)
                words = [item['keyword'] for item in lease['keywords']]
                source = {'strategy_id': self.strategy.ident, 'owner': self.owner,
                          'revision': revision, 'lease_id': lease['lease_id'], 'operation_id': op_id,
                          'snapshot_hash': _hash(words), 'keyword_count': len(words),
                          'city': summary['city'], 'area': summary['area']}
                record = {'name': name, 'platform': platform, 'account_id': account_id,
                          'scope': 'search_comments', 'keywords': words, 'cloud_owner': self.owner,
                          'comment_keyword_mode': 'all', 'continuous_enabled': False,
                          'search_pages': 1, 'daily_limit': 1000, 'target_count': 10000,
                          'strategy_source': source, 'status': 'ready'}
                created = self.core.handle('save', {'entity': 'tasks', 'record': record}, user)
            except Exception:
                # _save can persist the task before its audit write fails. Do not
                # release a lease if any task with this id could have executed.
                if not self._find_task(operation):
                    if lease is not None:
                        self.strategy.complete_batch(user, lease['lease_id'], 'task-cancel-' + op_id,
                                                     outcome='cancelled_before_execution')
                    operation['phase'] = 'failed'
                    self.core.store.put(TASK_OPERATIONS, operation)
                raise
            operation['phase'] = 'ready'
            operation['task_id'] = created['id']
            self.core.store.put(TASK_OPERATIONS, operation)
            return {'task': self.project_task(created['id'], user), 'replayed': False,
                    'platform_requests_started': False}

    def finish_exhausted(self, task_id, user):
        """Trusted post-run hook; only a fully committed snapshot spends slots."""
        task = self._task(task_id, user)
        # Reading one's committed result survives withdrawal of management
        # capability. The lease must remain untouched without that capability.
        if not self._authorize(user):
            return {'finished': False, 'reason': 'permission_changed'}
        source = task['strategy_source']
        with self.strategy._transaction() as db:
            self.strategy._authorize(db, user, True)
            value = self.strategy._load(db)
            if not value.get('lease'):
                return {'finished': False, 'reason': 'lease_not_active'}
            self._validate_snapshot(task, value['lease'])
            index = (task.get('pipeline') or {}).get('keyword_index')
            if (task.get('exhausted') is not True or task.get('status') != 'ready'
                    or type(index) is not int or index != source['keyword_count']):
                return {'finished': False, 'reason': 'snapshot_not_exhausted'}
        summary = self.strategy.complete_batch(user, source['lease_id'],
                                              'task-complete-' + source['operation_id'])
        return {'finished': True, 'quota_consumed': summary['quota_consumed'],
                'revision': summary['revision'], 'queries_remaining': summary['queries_remaining']}
