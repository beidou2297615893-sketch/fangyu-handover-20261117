"""Private, live, original-reviewed-queue capability; no persisted send grant."""
from contextvars import ContextVar
from contextlib import contextmanager,closing
from dataclasses import dataclass,field
from pathlib import Path
import hashlib,json,secrets,sqlite3,time,threading
from urllib.parse import urlsplit
_SEAL=object();_CURRENT=ContextVar('owned_reviewed_reply',default=None)
PURPOSE='reviewed_reply'
class ReplyPolicyError(ValueError):pass
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def file_digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(account):return {k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id','auth_generation','identity_revalidation_generation')}
def actor_identity(user):return {k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound','can_reply','permission_revision','disabled','_workbench_store_id')}
def _within(root,relative):
 p=(root/relative).resolve()
 if not isinstance(relative,str) or Path(relative).is_absolute() or not p.is_relative_to(root) or p==root or not p.is_file():raise ReplyPolicyError('受控回复组件路径无效')
 return p
@dataclass(eq=False)
class _Registration:
 seal:object
 root:Path
 manifest:dict
 manifest_digest:str
 transport:object
 def check(self):
  if self.seal is not _SEAL or digest(self.manifest)!=self.manifest_digest or not callable(self.transport):raise ReplyPolicyError('受控回复组件授权无效')
  m=self.manifest
  if (m.get('version')!=1 or m.get('protocol')!='reviewed-reply-v1' or m.get('helperFlag')!='--owned-xhs-reviewed-reply' or not isinstance(m.get('sources'),dict) or not m['sources']):raise ReplyPolicyError('受控回复协议尚未核验')
  for relative,expected in {m.get('executable'):m.get('executableSha256'),**m['sources']}.items():
   if not isinstance(expected,str) or len(expected)!=64 or file_digest(_within(self.root,relative))!=expected:raise ReplyPolicyError('受控回复组件摘要已变化，请更新后再操作')
  # Optional complete runtime closure is independently pinned by the host.
  tree=m.get('runtimeTree')
  if tree is not None:
   if not isinstance(tree,dict) or not tree:raise ReplyPolicyError('受控回复运行目录尚未核验')
   for relative,expected in tree.items():
    if file_digest(_within(self.root,relative))!=expected:raise ReplyPolicyError('受控回复运行文件已变化')
def verify_registration(root,manifest,transport):
 value=_Registration(_SEAL,Path(root).resolve(),json.loads(json.dumps(manifest)),digest(manifest),transport);value.check();return value
def register(core,root,manifest,transport,*,expected_manifest_digest):
 if not isinstance(expected_manifest_digest,str) or digest(manifest)!=expected_manifest_digest:raise ReplyPolicyError('受控回复材料与已审源码摘要不一致')
 value=verify_registration(root,manifest,transport);core._reviewed_reply_registration=value;return value
def consume_budget(database,tenant,customer,reply_id,attempt_id,request_digest):
 """The commit precedes wire_allow. Any crash after it stays unknown forever."""
 with closing(sqlite3.connect(str(database),timeout=20)) as db:
  db.execute('CREATE TABLE IF NOT EXISTS reviewed_reply_budget (customer_key TEXT PRIMARY KEY, tenant TEXT NOT NULL, reply_id TEXT NOT NULL, attempt_id TEXT NOT NULL, request_digest TEXT NOT NULL, state TEXT NOT NULL, consumed_at REAL NOT NULL)')
  db.execute('BEGIN IMMEDIATE');key=digest([tenant,'xiaohongshu',customer])
  if db.execute('SELECT 1 FROM reviewed_reply_budget WHERE customer_key=?',(key,)).fetchone():raise ReplyPolicyError('该客户已有发送或未知记录，禁止再次发送')
  db.execute('INSERT INTO reviewed_reply_budget VALUES(?,?,?,?,?,?,?)',(key,tenant,reply_id,attempt_id,request_digest,'unknown',time.time()))
  db.commit()
def consume_followup_budget(database,tenant,target,reply_id,attempt_id,request_digest):
 # Only the source resolver supplies target; callers cannot select an arbitrary turn key.
 key=digest([tenant,target['platform'],target['accountUid'],target['customerUid'],target['noteId'],target['incomingCommentId']])
 with closing(sqlite3.connect(str(database),timeout=20)) as db:
  db.execute('CREATE TABLE IF NOT EXISTS reviewed_followup_budget_v1 (turn_key TEXT PRIMARY KEY, tenant TEXT NOT NULL, target_id TEXT NOT NULL, reply_id TEXT NOT NULL, attempt_id TEXT NOT NULL, request_digest TEXT NOT NULL, state TEXT NOT NULL, consumed_at REAL NOT NULL)')
  db.execute('BEGIN IMMEDIATE')
  if db.execute('SELECT 1 FROM reviewed_followup_budget_v1 WHERE turn_key=?',(key,)).fetchone():raise ReplyPolicyError('该入站回合已有发送或未知记录，禁止再次发送')
  db.execute('INSERT INTO reviewed_followup_budget_v1 VALUES(?,?,?,?,?,?,?,?)',(key,tenant,target['id'],reply_id,attempt_id,request_digest,'unknown',time.time()));db.commit()
@dataclass(frozen=True,slots=True)
class _PreparedWire:
 seal:object
 request_json:str
 preparation_json:str
 binding_digest:str

@dataclass(eq=False)
class ReviewedDecision:
 seal:object
 core:object
 runtime:object
 registration:object
 actor:dict
 account:dict
 home:Path
 queue_id:str
 plan_digest:str
 queue_digest:str
 executor:object
 session:object
 device_id:str
 live_guard:object
 deadline:float
 plan:dict
 active:bool=True
 local:object=field(default_factory=threading.local)
 purpose:str=PURPOSE
 _prepared_wires:dict=field(default_factory=dict,repr=False)
 _used_wires:set=field(default_factory=set,repr=False)
 _wire_lock:object=field(default_factory=threading.RLock,repr=False)
 def check(self):
  if self.seal is not _SEAL or not self.active or time.monotonic()>=self.deadline or self.runtime.closed:raise ReplyPolicyError('本批发送授权已结束；请核对原批次状态')
  self.registration.check()
  if getattr(self.core,'_reviewed_reply_registration',None) is not self.registration:raise ReplyPolicyError('受控回复注册已变化')
  config=self.core.deployment_config.get('runtime') or {}
  if self.core.remote_safety_hold or config.get('platform_qa_device_id'):raise ReplyPolicyError('远端暂停或内部只读模式禁止发送')
  user=self.runtime._principal(self.actor)
  if actor_identity(user)!=self.actor or user.get('disabled') or user.get('can_reply') is False:raise ReplyPolicyError('本批员工权限已变化')
  service=self.runtime.service
  if service.closed or service.state!='online' or service.executor is not self.executor or getattr(self.executor,'_xhs_app_session',None) is not self.session or (service.device or {}).get('id')!=self.device_id:raise ReplyPolicyError('本批设备或员工会话已变化')
  self.session.check()
  if not self.runtime._device(user).get('bound'):raise ReplyPolicyError('本批设备绑定已变化')
  require_lease=getattr(self.runtime,'require_current_reviewed_send_lease',None)
  if not callable(require_lease):raise ReplyPolicyError('当前设备尚未取得独立的审核回复发送许可')
  # This host-only method verifies the sealed lease minted by an authenticated
  # poll. A read-only lease, local UI value or deployment flag cannot satisfy it.
  require_lease(self.actor,self.account,self.device_id)
  account=self.runtime._account(user,self.account['id'])
  if identity(account)!=self.account or account.get('status')!='ready' or account.get('requires_review') or account.get('identity_recovery_pending'):raise ReplyPolicyError('本批账号身份或安全状态已变化')
  if self.home!=(self.core.store.directory/'accounts'/user['tenant_id']/account['id']).resolve():raise ReplyPolicyError('本批独立会话路径已变化')
  self.core.adapters.require_account_safe('xiaohongshu',self.home)
  queue=self.core._get('reply_queues',self.queue_id,user['tenant_id'])
  if queue.get('status') not in ('ready','awaiting_collection','running') or digest({k:queue.get(k) for k in ('id','tenant_id','reviewed','reply_ids','snapshots','account_id','authorized_by')})!=self.queue_digest:raise ReplyPolicyError('原确认队列已变化或结束')
  self.live_guard()
  return self
 def matches(self,reply,lead,account,directory):
  self.check();rows=[r for r in self.plan['items'] if r['replyId']==reply['id']]
  if len(rows)!=1:raise ReplyPolicyError('回复不属于原确认批次')
  row=rows[0]
  lead=self.core._reply_source(reply,self.runtime._principal(self.actor),account=account)
  if row.get('followupTargetId')!=reply.get('followup_target_id'):raise ReplyPolicyError('批准入站回合已改变')
  if (identity(account)!=self.account or Path(directory).resolve()!=self.home or row['text']!=reply.get('text') or row['version']!=reply.get('version') or row['leadId']!=lead['id'] or row['snapshot']!=reply.get('approval_snapshot') or row['authorId']!=str(lead.get('author_id') or '') or row.get('sourceDigest')!=digest(lead)):raise ReplyPolicyError('原批准内容、对象或账号已变化')
  return row
 def _wire_request(self,reply,lead,account,row,attempt_id):
  lead=self.core._reply_source(reply,self.runtime._principal(self.actor),account=account)
  resolved=self.core._resolved_reply_lead(lead,'comment',user=self.runtime._principal(self.actor),account=account)
  parsed=urlsplit(str(resolved.get('note_url') or ''))
  return {'attemptId':attempt_id,'expectedUid':self.account['platform_uid'],
   'noteId':parsed.path.rstrip('/').split('/')[-1],'commentId':resolved.get('comment_id'),
   'text':reply['text'],'requestDigest':digest([self.plan_digest,row,identity(account)])}
 def _wire_binding(self,reply,lead,account,row,request):
  if digest(self.plan)!=self.plan_digest:raise ReplyPolicyError('原确认计划已变化，禁止准备或使用旧发送请求')
  source=self.core._reply_source(reply,self.runtime._principal(self.actor),account=account)
  fields={k:reply.get(k) for k in ('id','tenant_id','lead_id','version','text','channel','recipient',
   'approval_snapshot','followup_target_id','followup_target_digest')}
  return digest([self.plan_digest,row,self.registration.manifest_digest,self.device_id,identity(account),digest(source),fields,request])
 def prepare_wire(self,reply,lead,account,directory):
  # Engine invokes this before its atomic send_started/reply-state commit.
  if current_decision(self.core) is not self:raise ReplyPolicyError('原队列线程未持有发送准备能力')
  row=self.matches(reply,lead,account,directory)
  if not reply.get('followup_target_id') or reply.get('status')!='approved':raise ReplyPolicyError('仅当前已审核入站回合可准备发送')
  if reply.get('followup_send_preparation') is not None or reply.get('reviewed_transport_receipt') is not None:raise ReplyPolicyError('旧发送准备或回执不得作为新尝试复用')
  from assistant.xhs_reply_worker import validate
  with self._wire_lock:
   if reply['id'] in self._prepared_wires:raise ReplyPolicyError('本条发送请求已准备，不得生成第二个尝试')
   request=self._wire_request(reply,lead,account,row,secrets.token_hex(16));validate(request)
   binding=self._wire_binding(reply,lead,account,row,request)
   preparation={'schema':'fangyu_followup_send_preparation_v1','attemptId':request['attemptId'],
    'requestDigest':request['requestDigest'],'bindingDigest':binding}
   self._prepared_wires[reply['id']]=_PreparedWire(_SEAL,json.dumps(request,ensure_ascii=False,sort_keys=True,separators=(',',':')),
    json.dumps(preparation,sort_keys=True,separators=(',',':')),binding)
   return dict(preparation)
 def _bound_wire_request(self,reply,lead,account,directory,*,take=False,expected=None):
  row=self.matches(reply,lead,account,directory)
  with self._wire_lock:
   prepared=self._prepared_wires.get(reply['id'])
   if type(prepared) is not _PreparedWire or prepared.seal is not _SEAL:raise ReplyPolicyError('本次入站回合未在原队列中准备发送')
   if take and reply['id'] in self._used_wires:raise ReplyPolicyError('本次发送尝试已使用，禁止重发')
   if not take and reply['id'] not in self._used_wires:raise ReplyPolicyError('发送准备尚未进入当前唯一尝试')
   request=json.loads(prepared.request_json);metadata=json.loads(prepared.preparation_json)
   current=self.core._get('replies',reply['id'],reply['tenant_id'])
   if (reply.get('followup_send_preparation')!=metadata or current.get('followup_send_preparation')!=metadata
       or current.get('status')!='sending' or expected is not None and request!=expected
       or self._wire_request(current,lead,account,row,request['attemptId'])!=request
       or self._wire_binding(current,lead,account,row,request)!=prepared.binding_digest):
    raise ReplyPolicyError('发送准备、正文、来源或原尝试已变化，禁止发送')
   if take:self._used_wires.add(reply['id'])
   return request
 def send(self,reply,lead,account,directory):
  row=self.matches(reply,lead,account,directory)
  if reply.get('followup_target_id'):request=self._bound_wire_request(reply,lead,account,directory,take=True)
  else:request=self._wire_request(reply,lead,account,row,secrets.token_hex(16))
  from assistant.xhs_reply_worker import validate,post_body,IDENT
  validate(request);consumed=False;post=False;followup_uncertain=False
  def authorize(stage,detail):
   nonlocal consumed,post,followup_uncertain
   self.matches(reply,self.core._get('leads',lead['id'],reply['tenant_id']),self.core._get('accounts',account['id'],reply['tenant_id']),directory)
   if reply.get('followup_target_id'):self._bound_wire_request(reply,lead,self.core._get('accounts',account['id'],reply['tenant_id']),directory,expected=request)
   if stage=='identity':
    if detail!={'method':'GET','path':'/api/sns/web/v2/user/me','query':'','body':None}:raise ReplyPolicyError('身份请求范围已变化')
   elif stage=='post':
    if consumed or detail!={'method':'POST','path':'/api/sns/web/v1/comment/post','query':'','body':post_body(request)}:raise ReplyPolicyError('发送请求范围或次数已变化')
    if reply.get('followup_target_id'):
     actor=self.runtime._principal(self.actor);target,_=self.core.followup_targets.get(reply['followup_target_id'],actor,account)
     hook=getattr(self.runtime,'consume_followup_turn',None)
     if not callable(hook):raise ReplyPolicyError('云端入站回合许可尚未接通')
     # Any timeout after this boundary is uncertain, including a local commit failure.
     followup_uncertain=True
     receipt=hook(actor,target,reply,request)
     if (not isinstance(receipt,dict) or receipt.get('schema')!='fangyu_followup_wire_consume_v1'
         or any(receipt.get(key) is not True for key in ('consumed','newlyConsumed','wire_allowed'))
         or type(receipt.get('consumedAt')) is not int or receipt['consumedAt']<=0
         or receipt.get('responseHash')!=digest({k:v for k,v in receipt.items() if k!='responseHash'})):
      raise ReplyPolicyError('云端入站回合许可回执不完整，禁止发送')
     scope=receipt.get('scope')
     expected={'owner':actor['username'],'accountId':target['accountId'],'accountUid':target['accountUid'],
       'customerUid':target['customerUid'],'platform':target['platform'],'noteId':target['noteId'],
       'incomingCommentId':target['incomingCommentId'],'observationId':target['incomingObservationId'],
       'observationPayloadHash':target['payloadHash'],'parentSentEventId':target['parentSentEventId'],
       'replyId':reply['id'],'attemptId':request['attemptId'],'requestDigest':request['requestDigest'],
       'replyTextSha256':hashlib.sha256(request['text'].encode('utf-8')).hexdigest()}
     if not isinstance(scope,dict) or any(scope.get(k)!=v for k,v in expected.items()):raise ReplyPolicyError('云端入站回合许可对象变化，禁止发送')
     consume_followup_budget(self.core.store.directory/'reviewed-reply-budget.sqlite3',reply['tenant_id'],target,reply['id'],request['attemptId'],request['requestDigest'])
    else:consume_budget(self.core.store.directory/'reviewed-reply-budget.sqlite3',reply['tenant_id'],row['authorId'],reply['id'],request['attemptId'],request['requestDigest'])
    consumed=True;post=True
   elif stage=='before_post':
    if detail!={'actualUid':self.account['platform_uid']}:raise ReplyPolicyError('实际发送身份已变化')
   elif stage!='preflight':raise ReplyPolicyError('未知发送阶段')
  try:
   result=self.registration.transport(self,request,authorize)
   if (not consumed or not post or not isinstance(result,dict) or result.get('success') is not True
       or not isinstance(result.get('platformCommentId'),str) or not IDENT.fullmatch(result['platformCommentId'])
       or result.get('platform_comment_id')!=result['platformCommentId']
       or result.get('actualUid')!=self.account['platform_uid']
       or result.get('responseSenderUid') not in (None,self.account['platform_uid'])
       or result.get('identityProofSource')!='same_client_preflight_user_me'
       or result.get('attemptId')!=request['attemptId'] or result.get('requestDigest')!=request['requestDigest']):raise RuntimeError('发送回执尚未核对，禁止重试')
   return result
  except Exception as exc:
   if not consumed and not followup_uncertain:
    from .adapters import AdapterBusy
    raise AdapterBusy('本条未放行平台发送，请核对身份及当前批次') from exc
   raise RuntimeError('发送结果未知，请人工核实，禁止自动重试') from exc
def mint(core,runtime,plan,user,live_guard):
 reg=getattr(core,'_reviewed_reply_registration',None)
 if type(reg) is not _Registration or reg.seal is not _SEAL:raise ReplyPolicyError('受控回复组件尚未核验或注册')
 actor=runtime._principal(user);executor=runtime._executor(actor,online=False);account=runtime._account(actor,plan['items'][0]['accountId'])
 if account.get('platform')!='xiaohongshu' or not account.get('platform_uid'):raise ReplyPolicyError('受控回复只允许已核对的小红书账号')
 queue=core._get('reply_queues',plan['queueId'],actor['tenant_id'])
 decision=ReviewedDecision(_SEAL,core,runtime,reg,actor_identity(actor),identity(account),(core.store.directory/'accounts'/actor['tenant_id']/account['id']).resolve(),plan['queueId'],digest(plan),digest({k:queue.get(k) for k in ('id','tenant_id','reviewed','reply_ids','snapshots','account_id','authorized_by')}),executor,getattr(executor,'_xhs_app_session',None),(runtime.service.device or {}).get('id',''),live_guard,time.monotonic()+600,json.loads(json.dumps(plan)))
 decision.check();return decision
def current_decision(core):
 value=_CURRENT.get()
 if value is None:return None
 if type(value) is not ReviewedDecision or value.seal is not _SEAL or value.core is not core:raise ReplyPolicyError('受控回复能力用途不符')
 return value.check()
@contextmanager
def reviewed_scope(value):
 if type(value) is not ReviewedDecision or value.seal is not _SEAL:raise ReplyPolicyError('必须使用原批次私有能力')
 value.check();token=_CURRENT.set(value)
 try:yield value
 finally:_CURRENT.reset(token)
