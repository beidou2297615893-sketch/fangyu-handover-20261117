"""One authenticated original-receipt read, using an existing valid session.

No login, refresh, identity probe, configuration write, business retry or send.
The session and host binding remain request-local, with a fresh return fence.
"""
from copy import deepcopy
import math
import re
import time


ACTION = 'acquisition_handoff_operation_status'
ORIGINAL = 'acquisition_channel_register'
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_TOKEN = re.compile(r'[A-Za-z0-9._~+/-]+=*\Z')


class CompanyHandoffStatusTransportError(ValueError):
    def __init__(self, code, message, status=503):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_STATUS_' + code
        self.status = status
        self.mutation_committed = False  # This status query only.


def _fail(code, message, status=503):
    raise CompanyHandoffStatusTransportError(code, message, status)


class CompanyHandoffStatusTransport:
    def __init__(self, server, user, *, environment_id, company_id, scope_guard, clock=None):
        if (not isinstance(user, dict) or not callable(scope_guard)
                or not isinstance(environment_id, str) or not isinstance(company_id, str)):
            raise ValueError('公司原操作查询需要可信本机身份')
        self.server, self.user = server, deepcopy(user)
        self.environment_id, self.company_id = environment_id, company_id
        self.scope_guard, self.clock = scope_guard, clock or time.time
        # Deliberately do not read or renew a session during construction.

    def _principal(self, actor):
        try:
            company = self.server.company
            workspace = company.get('managedWorkspace') or {}
            current = self.server.core.store.get('users', self.user['id'])
            keys = ('id', 'tenant_id', 'username', 'role')
            valid = (isinstance(actor, dict) and self.scope_guard() is True
                and isinstance(workspace, dict) and workspace.get('environment_id') == self.environment_id
                and company.get('id') == self.company_id
                and (self.server.core.deployment_config or {}).get('id') == self.company_id
                and current and current.get('cloud_bound') is True and not current.get('disabled')
                and current.get('development_local_only') is not True
                and current.get('role') in ('operator', 'admin')
                and all(current.get(key) == self.user.get(key) == actor.get(key) for key in keys))
        except Exception:
            valid = False
        if not valid:
            _fail('BINDING_CHANGED', '当前员工、企业环境或电脑已变化，请回到原范围核对', 409)

    def _capture(self, actor, margin):
        from integrations import endpoint
        self._principal(actor)
        try:
            integrations = self.server.integrations
            with integrations.lock:
                config = deepcopy(integrations._read(self.user['tenant_id']))
            cloud = config.get('cloud') if isinstance(config, dict) else None
            sessions = config.get('sessions') if isinstance(config, dict) else None
            session = sessions.get(self.user['id']) if isinstance(sessions, dict) else None
            expiry = session.get('expires') if isinstance(session, dict) else None
            token = session.get('token') if isinstance(session, dict) else None
            valid = (isinstance(cloud, dict) and cloud.get('environment_id') == self.environment_id
                and isinstance(session, dict) and session.get('username') == self.user['username']
                and type(expiry) in (int, float) and math.isfinite(expiry)
                and expiry > self.clock() + margin and isinstance(token, str)
                and 16 <= len(token) <= 8192 and _TOKEN.fullmatch(token) is not None
                and not session.get('pending_refresh'))
            address = endpoint(cloud.get('endpoint')) if valid else ''
            if not address:
                valid = False
        except Exception:
            valid = False
        if not valid:
            _fail('SESSION_REQUIRED', '原公司回执查询需要现有有效登录，请先在设置中明确连接当前公司', 409)
        self._principal(actor)
        return {'cloud': cloud, 'session': session, 'endpoint': address, 'token': token}

    def __call__(self, actor, operation, data):
        if (operation != ACTION or not isinstance(data, dict)
                or set(data) != {'operation_action', 'idempotency_key'}
                or data.get('operation_action') != ORIGINAL
                or not isinstance(data.get('idempotency_key'), str)
                or _HEX.fullmatch(data['idempotency_key']) is None):
            _fail('INVALID_REQUEST', '请按本机原准备记录核对公司操作，不能输入新编号', 400)
        before = self._capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], {
                'environment_id': self.environment_id, 'operation': ACTION, **deepcopy(data)}, before['token'])
        except Exception:
            _fail('READ_UNAVAILABLE', '原公司回执暂不可读，原准备编号继续保留；请稍后核对')
        after = self._capture(actor, 0)
        if after != before:
            _fail('BINDING_CHANGED', '查询返回时公司连接或登录已变化，请回到原范围核对', 409)
        fields = {'contract', 'environment_id', 'company_id', 'operation_receipt',
                  'read_only', 'mutation_committed', 'auto_retry'}
        if (not isinstance(result, dict) or set(result) != fields
                or result.get('contract') != 'fangyu-workspace-v1'
                or result.get('environment_id') != self.environment_id
                or result.get('company_id') != self.company_id
                or result.get('read_only') is not True or result.get('mutation_committed') is not False
                or result.get('auto_retry') is not False or not isinstance(result.get('operation_receipt'), dict)):
            _fail('READ_UNAVAILABLE', '原公司回执身份或格式需核对，原准备编号继续保留')
        self._principal(actor)
        return {key: deepcopy(result[key]) for key in ('operation_receipt', 'read_only', 'mutation_committed', 'auto_retry')}
