"""Outbound-only assistant and signed update components."""
