"""Account-only original-owner lifecycle for a status observation.

The opaque DeviceSession worker and a separate identity material decision are
required. Stored login/risk/UID facts are preserved; there is no Task or CLI
permission. Physical cleanup reuses the original batch owner's algorithm.
"""
from pathlib import Path
import stat
import threading

from core.adapters import AdapterBusy, AdapterSafetyRequired, account_execution_lock
from .xhs_batch_scope import _BatchScope


def _session_clean(root):
    # Read metadata only. An interrupted original commit needs its own recovery
    # operation; this observation never reads, imports or repairs Cookie data.
    config=Path(root)/'.xiaohongshu-cli'
    for path in (config,config/'.browser-session-commit.json',
                 config/'.browser-session-commit.json.tmp'):
        try:
            info=path.lstat()
        except FileNotFoundError:
            continue
        if path.is_symlink() or getattr(info,'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
            raise AdapterSafetyRequired('identity_session_recovery_required')
        if path!=config or not stat.S_ISDIR(info.st_mode):
            raise AdapterSafetyRequired('identity_session_recovery_required')


class _IdentityScope:
    def __init__(self,runtime,user,account,job,context):
        from .xhs_page_runtime import XhsPageRuntime
        from .xhs_identity_context import _IdentityExecutionContext
        if (type(runtime) is not XhsPageRuntime or type(context) is not _IdentityExecutionContext
                or type(job) is not dict or type(user) is not dict or type(account) is not dict
                or job.get('kind')!='assistant_account_login' or job.get('mode')!='browser'
                or job.get('purpose')!='identity_observation'
                or job.get('owner_id')!=user.get('id') or job.get('tenant_id')!=user.get('tenant_id')
                or job.get('account_id')!=account.get('id') or account.get('tenant_id')!=user.get('tenant_id')
                or account.get('platform')!='xiaohongshu'):
            raise AdapterSafetyRequired('identity_scope_unavailable')
        context.check()
        self.runtime,self.app_context,self.job=runtime,context,job
        self.thread=threading.current_thread()
        self.user_id,self.task_id=user['id'],job['id']
        self.tenant,self.account_id=user['tenant_id'],account['id']
        # task_id identifies only this original RAM worker, never a stored Task.
        self.root=runtime.core.store.directory/'accounts'/self.tenant/self.account_id
        self.entry=None
        self.entered=self.finished=self.user_cancelled=self.result_released=False
        self.retain_result=False
        self.os_lock=account_execution_lock(self.root)
        if getattr(context.claim.session.service.server,'_customer_natural_component',False):
            from .xhs_customer_account_runtime import operation_lock
            self.os_lock=operation_lock(context,self.root,self.os_lock)

    def check(self):
        if (threading.current_thread() is not self.thread or self.finished or self.user_cancelled
                or self.entry is not None and (self.entry.batch_scope is not self or self.entry.stop_requested)
                or self.job.get('status')!='running' or self.job['worker_done'].is_set()
                or self.job.get('id')!=self.task_id or self.job.get('account_id')!=self.account_id
                or self.job.get('owner_id')!=self.user_id or self.job.get('tenant_id')!=self.tenant
                or self.job.get('purpose')!='identity_observation'):
            raise AdapterSafetyRequired('identity_scope_changed')
        self.app_context.check()
        server=self.app_context.claim.session.service.server
        from .xhs_customer_account_runtime import account_runtime_matches,check_operation
        if not account_runtime_matches(server,self.runtime):
            raise AdapterSafetyRequired('account_runtime_changed')
        if getattr(server,'_customer_natural_component',False):
            check_operation(self.app_context,required=self.entered)
        core=self.runtime.core
        user=core.store.get('users',self.user_id)
        account=core._get('accounts',self.account_id,self.tenant)
        if not user or account.get('status')=='session_recovery_required':
            raise AdapterSafetyRequired('identity_session_recovery_required')
        core._account_access(user,account)
        _session_clean(self.root)

    def enter(self):
        self.check()
        self.root,entry=self.runtime._entry(self.root)
        self.entry=entry
        with self.runtime.lock:
            if (entry.batch_scope is not None or entry.login_reserved or self.runtime.closed
                    or self.task_id in self.runtime.jobs):
                raise AdapterBusy('原账号窗口仍由另一线程持有，尚不能核对身份')
            entry.batch_scope=self
            self.runtime.jobs[self.task_id]=self
        try:
            self.os_lock.__enter__()
            self.entered=True
            self.check()
            entry.lock.acquire()
        except BaseException:
            if self.entered:
                self.os_lock.__exit__(None,None,None)
                self.entered=False
            with self.runtime.lock:
                if entry.batch_scope is self:entry.batch_scope=None
                if self.runtime.jobs.get(self.task_id) is self:self.runtime.jobs.pop(self.task_id)
            raise

    # No current permission/decision check is involved in this exact original
    # transport/Job/descendants/files retry loop and account-lock release.
    finish=_BatchScope.finish
