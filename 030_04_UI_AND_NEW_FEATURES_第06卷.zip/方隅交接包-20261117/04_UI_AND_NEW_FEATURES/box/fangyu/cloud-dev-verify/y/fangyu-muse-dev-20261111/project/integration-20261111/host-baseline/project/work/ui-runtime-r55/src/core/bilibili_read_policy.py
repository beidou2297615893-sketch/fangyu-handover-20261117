"""Fixed internal-source component selection for the bounded Bilibili GET route.

This is a component/material policy, not an account, device, platform-rights or
login grant. The original host still checks those before each operation.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re

from .runtime_license_policy import _plain, _file_hash


_REVIEW_SHA = 'A4B6B7803BF29D7233D4113337FA187F2596120ECC0DAD6648F1C5CCEB4A1003'
_REVIEW_RELATIVE = 'resources/bilibili-internal-read/review.json'
_SCOPE = 'internal_self_use_read'
_ROUTE = 'bilibili_fixed_read_v1'
_COMPANY = 'fangyu-apartment-client'
_UPSTREAM = 'de127ec2f068e8f122822d9b8939737068fc4aa7'
_SOURCE = 'https://github.com/hammershock/bilibili-cli'
_SOURCE_MATERIALS = frozenset((
    'core/bilibili_read.py', 'core/bilibili_owned_setup.py', 'core/adapters.py',
    'bilibili_read_entry.py', 'bilibili_read_contract.py',
    'core/runtime_license_policy.py', 'resources/adapters/bilibili.json',
    'resources/bilibili_read_vendor/LICENSE',
    'resources/bilibili_read_vendor/bilicli/__init__.py',
    'resources/bilibili_read_vendor/bilicli/client.py',
    'resources/bilibili_read_vendor/bilicli/wbi.py',
    'resources/bilibili_read_vendor/bilicli/api/__init__.py',
    'resources/bilibili_read_vendor/bilicli/api/comment.py',
    'resources/bilibili_read_vendor/bilicli/api/search.py',
    'resources/bilibili_read_vendor/bilicli/api/video.py',
))
_DEPENDENCY_MATERIALS = frozenset((
    'Lib/site-packages/anyio-4.15.1.dist-info/METADATA',
    'Lib/site-packages/anyio-4.15.1.dist-info/licenses/LICENSE',
    'Lib/site-packages/certifi-2026.7.22.dist-info/METADATA',
    'Lib/site-packages/certifi-2026.7.22.dist-info/licenses/LICENSE',
    'Lib/site-packages/h11-0.16.0.dist-info/METADATA',
    'Lib/site-packages/h11-0.16.0.dist-info/licenses/LICENSE.txt',
    'Lib/site-packages/httpcore-1.0.9.dist-info/METADATA',
    'Lib/site-packages/httpcore-1.0.9.dist-info/licenses/LICENSE.md',
    'Lib/site-packages/httpx-0.28.1.dist-info/METADATA',
    'Lib/site-packages/httpx-0.28.1.dist-info/licenses/LICENSE.md',
    'Lib/site-packages/idna-3.20.dist-info/METADATA',
    'Lib/site-packages/idna-3.20.dist-info/licenses/LICENSE.md',
    'Lib/site-packages/typing_extensions-4.16.0.dist-info/METADATA',
    'Lib/site-packages/typing_extensions-4.16.0.dist-info/licenses/LICENSE',
))
_GET_ROUTES = {
    'self': {'method': 'GET', 'urls': ['https://api.bilibili.com/x/web-interface/nav'],
             'max_requests': 1},
    'search': {'method': 'GET', 'urls': ['https://api.bilibili.com/x/web-interface/nav',
               'https://api.bilibili.com/x/web-interface/wbi/search/type'], 'max_requests': 4},
    'comments': {'method': 'GET', 'urls': ['https://api.bilibili.com/x/web-interface/nav',
                 'https://api.bilibili.com/x/web-interface/view',
                 'https://api.bilibili.com/x/v2/reply'], 'max_requests': 4},
}
_SHA = re.compile(r'[0-9A-F]{64}')


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _source_root():
    return Path(__file__).resolve().parents[1]


class BilibiliReadPolicy:
    """Only the trusted original host constructs this fixed private policy."""
    def __init__(self, server):
        self._server = server
        self._core = server.core
        self._adapters = server.core.adapters
        self._root = _source_root()
        try:
            self._source_sha = _file_hash(_plain(self._root/'core/bilibili_read_policy.py', self._root))
        except Exception:
            self._source_sha = None

    def _snapshot(self):
        server, core, root = self._server, self._core, self._root
        if (server.core is not core or core.adapters is not self._adapters
                or getattr(server, 'closing', False) or self._adapters.closed
                or Path(core.resources_dir) != root/'resources'
                or self._adapters.root != root/'resources/adapters'):
            raise ValueError('host route changed')
        company = server.company
        if (type(company) is not dict or company.get('id') != _COMPANY
                or company.get('edition') != 'customer' or company.get('authMode') != 'managed'
                or server._runtime_license_usage_scope(_SCOPE) != _SCOPE):
            raise ValueError('different usage scope')
        manifest = self._adapters.manifest('bilibili')
        if (type(manifest) is not dict or manifest.get('available') is not True
                or manifest.get('id') != 'bilibili' or manifest.get('transport') != _ROUTE
                or manifest.get('source') != _SOURCE or manifest.get('upstream_commit') != _UPSTREAM
                or manifest.get('license') != 'MIT'):
            raise ValueError('different component route')
        return deepcopy({'company_id': company['id'], 'usage_scope': _SCOPE,
                         'manifest': manifest, 'edition': company['edition'],
                         'auth_mode': company['authMode']})

    def _materials(self, snapshot):
        root = self._root
        policy_source = _file_hash(_plain(root/'core/bilibili_read_policy.py', root))
        if not self._source_sha or policy_source != self._source_sha:
            raise ValueError('policy source changed')
        path = _plain(root/_REVIEW_RELATIVE, root)
        if _file_hash(path).upper() != _REVIEW_SHA:
            raise ValueError('fixed review changed')
        review = json.loads(path.read_text('utf-8-sig'))
        if (type(review) is not dict or set(review) != {'schema', 'company_id', 'route', 'usage_scope',
                'upstream', 'decision', 'get_routes', 'limits', 'materials', 'evidence'}
                or review['schema'] != 'bilibili_internal_component_use_v1'
                or review['company_id'] != _COMPANY or review['route'] != _ROUTE
                or review['usage_scope'] != _SCOPE
                or review['decision'] != 'internal_source_component_selected'
                or review['upstream'] != {'source': _SOURCE, 'commit': _UPSTREAM, 'license': 'MIT'}
                or review['get_routes'] != _GET_ROUTES
                or review['limits'] != {'max_page': 50, 'max_page_size': 20,
                    'max_response_bytes': 1048576, 'max_seconds': 25, 'auto_retry': False,
                    'platform_writes': False, 'real_platform_verified': False,
                    'native_loaded_bytes_verified': False}
                or type(review['materials']) is not list):
            raise ValueError('different fixed review')
        expected_paths = {('source', relative) for relative in _SOURCE_MATERIALS}
        expected_paths |= {('desktop_python', relative) for relative in _DEPENDENCY_MATERIALS}
        entries = {}
        for item in review['materials']:
            if (type(item) is not dict or set(item) != {'root', 'relative', 'sha256', 'bytes'}
                    or not isinstance(item['sha256'], str) or not _SHA.fullmatch(item['sha256'])
                    or type(item['bytes']) is not int or item['bytes'] < 0):
                raise ValueError('invalid material')
            key = (item['root'], item['relative'])
            if key not in expected_paths or key in entries:
                raise ValueError('different material set')
            entries[key] = item
        if set(entries) != expected_paths:
            raise ValueError('incomplete material set')
        python_root = Path(snapshot['manifest']['executable']).parent.parent
        proof = []
        for key in sorted(entries):
            material_root = root if key[0] == 'source' else python_root
            material = _plain(material_root/key[1], material_root)
            actual = _file_hash(material).upper()
            expected = entries[key]
            if actual != expected['sha256'] or material.stat().st_size != expected['bytes']:
                raise ValueError('material changed')
            proof.append((key, actual, expected['bytes']))
        return {'review_sha256': _REVIEW_SHA, 'source_sha256': policy_source, 'materials': proof}

    def _resolve(self):
        try:
            snapshot = self._snapshot()
            proof = self._materials(snapshot)
            from .bilibili_read import configured
            if configured(snapshot['manifest']) is not True:
                raise ValueError('component unavailable')
            if snapshot != self._snapshot() or proof != self._materials(snapshot):
                raise ValueError('current material scope changed')
            return {'bilibili': True, 'revision': _digest(['bilibili-internal-use-v1', snapshot, proof])}, 'fixed_internal_component'
        except Exception:
            return {'bilibili': False, 'revision': _digest(['bilibili-internal-use-v1', _REVIEW_SHA, False])}, 'component_or_scope_unconfirmed'

    def resolve(self):
        return self._resolve()[0]

    def describe(self):
        result, reason = self._resolve()
        return {'status': 'available' if result['bilibili'] else 'blocked', 'reason': reason,
                'purpose': 'bilibili_owned_setup', 'usage_scope': _SCOPE,
                'read_only': True, 'account_ready': False, 'real_platform_verified': False}
