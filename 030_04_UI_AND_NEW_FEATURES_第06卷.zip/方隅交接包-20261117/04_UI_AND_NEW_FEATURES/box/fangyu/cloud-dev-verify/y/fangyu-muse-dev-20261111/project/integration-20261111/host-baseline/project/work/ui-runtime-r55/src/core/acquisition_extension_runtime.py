"""Original source state machines through Core admission, filtering and Store.

No standalone executor, model, scheduler or account-directory discovery lives
here. Raw pages enter the existing durable inbox; promotion and source state
are committed by the original Store transaction after Core filtering.
"""
from copy import deepcopy
from datetime import datetime, timezone
import json

from .acquisition_extension.contracts import Scope, ReadRequest, ReadReceipt, json_digest
from .acquisition_extension.xhs_sources import ProfileSource, InteractionSource
from .acquisition_extension.guarded_port import compile_xhs_request
from .acquisition_sources import platform_time_evidence

KINDS=frozenset(('profiles','own_interactions'))
PAGES='source_item_evidence_v1'
EVENTS='acquisition_interaction_events_v1'


def account_identity(account):
    """Stable identity revision; an explicit same-UID revalidation may renew cookies.

    Each running PageWorker separately pins the full session fingerprint and
    Runtime rechecks fresh permission/hold. Display/status timestamps cannot
    change the historical identity of a saved source task.
    """
    keys=('id','tenant_id','cloud_owner','store_id','platform','platform_uid')
    if any(not isinstance(account.get(k),str) or not account[k] for k in keys):
        raise ValueError('来源采集账号身份尚未确认，未开始读取')
    return {k:account[k] for k in keys}


def bound_scope(task,account,plan):
    identity=account_identity(account)
    if identity!=plan.get('account_identity'):
        raise ValueError('来源采集账号身份已变化，原断点保留')
    return Scope(task['tenant_id'],task['cloud_owner'],task['store_id'],task['account_id'],
        account['platform_uid'],json_digest(identity),task['id'],plan['snapshot_digest'],task['platform'])


def source_for(task,plan):
    cfg=plan['config']
    if cfg['kind']=='profiles':
        return ProfileSource([item['profile'] for item in cfg['items']],
                             include_sub_comments=task.get('comment_depth','all')=='all')
    if cfg['kind']=='own_interactions':
        return InteractionSource([item['type'] for item in cfg['items']],baseline=cfg['baseline'])
    raise ValueError('此来源不属于扩展读取任务')


def controlled_args(request):
    """Strict original-worker shape, never shell text or arbitrary CLI flags."""
    compile_xhs_request(request)
    p=request.params
    if request.operation=='user_posts':
        args=['user-posts',p['user_id'],'--json']
    elif request.operation=='notifications':
        args=['notifications','--json','--type',p['type'],'--num',str(p['num'])]
    elif request.operation=='comments':
        from urllib.parse import urlsplit,urlunsplit
        url=urlsplit(p['note_url'])
        canonical=urlunsplit(('https','www.xiaohongshu.com','/explore/'+url.path.rstrip('/').split('/')[-1],url.query,''))
        args=['comments',canonical,'--json']
    elif request.operation=='sub_comments':
        from urllib.parse import urlsplit,parse_qs
        url=urlsplit(p['note_url']);token=parse_qs(url.query)['xsec_token'][0]
        args=['sub-comments',url.path.rstrip('/').split('/')[-1],p['root_comment_id'],
              '--json','--xsec-token',token]
    else:raise ValueError('此来源未授权该读取操作')
    if p.get('cursor'):args+=['--cursor',p['cursor']]
    return args


def _pipeline(task,plan,checkpoint):
    return {'source_digest':plan['snapshot_digest'],'extension':deepcopy(checkpoint),
        'keyword_index':len(plan['config']['items']) if not checkpoint['jobs'] else 0,
        'browsed_notes':len(checkpoint.get('seen_notes',[]))}


def collect_page(adapters,store,task,plan,guard,progress=None):
    guard()
    account=store.get('accounts',task['account_id']) or {}
    scope=bound_scope(task,account,plan);source=source_for(task,plan)
    before=deepcopy(task.get('pipeline'))
    checkpoint=deepcopy((before or {}).get('extension') or source.initial_checkpoint(scope))
    request=source.next_request(scope,checkpoint)
    if request is None:
        task['_pipeline_next']=_pipeline(task,plan,checkpoint)
        return []
    (progress or (lambda *a,**k:None))('searching' if request.operation in ('user_posts','notifications') else 'reading_comments')
    # This adapter requires an already registered original task PageWorker.
    receipt=adapters.source_read(task,scope,request,guard)
    guard()
    if bound_scope(task,store.get('accounts',task['account_id']) or {},plan)!=scope:
        raise ValueError('来源读取期间账号身份已变化，原回执保留')
    proposal=source.consume(scope,checkpoint,request,receipt)
    rows=[]
    for row in proposal.comments:
        item=deepcopy(row);raw=item.get('raw') or {}
        if request.operation=='notifications':raw=raw.get('comment_info',raw.get('comment',{}))
        if not isinstance(raw,dict):raw={}
        mapped=adapters.map_comments({'comments':[raw]},item['note_url'],parent_id=item.get('parent_id',''))
        exact=next((r for r in mapped if r.get('comment_id')==item['comment_id']),{})
        # Stable identity and original author text from the strict source win.
        item={**exact,**item,'source_type':'comment','url':item['note_url'],
              'comment_time_evidence':platform_time_evidence(raw.get('create_time')),
              'comment_level':2 if item.get('parent_id') else 1}
        if item['comment_time_evidence'].get('status')=='verified':
            item['published_at']=item['comment_time_evidence']['publishedAt']
        item.pop('raw',None)
        rows.append(item)
    after=_pipeline(task,plan,proposal.checkpoint)
    context={'schema':'source-page/1','scope':scope.binding(),'plan_digest':plan['snapshot_digest'],
        'pipeline_before':before,'pipeline_next':after,
        'request':{'operation':request.operation,'params':dict(request.params)},
        'receipt':{'scope_fingerprint':receipt.scope_fingerprint,'request_digest':receipt.request_digest,
            'operation':receipt.operation,'payload':receipt.payload,'evidence':receipt.evidence},
        'evidence':proposal.evidence,'unresolved':proposal.unresolved,'events':proposal.events}
    if len(json.dumps(context,ensure_ascii=False).encode('utf-8'))>16*1024*1024:
        raise ValueError('来源页证据超出保存范围，原回执与断点保留')
    context['digest']=json_digest(context)
    task['_source_page']=context;task['_pipeline_next']=after
    task['_page_info']={'has_more':bool(proposal.checkpoint['jobs']),'source_events':len(proposal.events),
        'source_unresolved':len(proposal.unresolved),'source_baseline':sum(e.get('disposition')=='baseline' for e in proposal.events)}
    return rows


def commit_page(db,context,*,task_id,tenant_id,owner,account_id,page_complete,inbox_update=None,guard=None):
    """Called only inside original insert_collection_page's BEGIN IMMEDIATE."""
    def read(entity,ident):
        row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                       (entity,ident,tenant_id)).fetchone()
        return json.loads(row['body']) if row else {}
    def put(entity,value):
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                   (entity,value['id'],tenant_id,json.dumps(value,ensure_ascii=False)))
    value=deepcopy(context);expected=value.pop('digest',None)
    if expected!=json_digest(value) or value.get('schema')!='source-page/1':
        raise ValueError('原来源页证据无法核对，未推进断点')
    task=read('tasks',task_id);account=read('accounts',account_id)
    plan=read('acquisition_source_plans_v1',task_id)
    from .acquisition_sources import digest,source_digest
    if (task.get('cloud_owner')!=owner or task.get('account_id')!=account_id
            or task.get('status')=='paused' or task.get('pipeline')!=value['pipeline_before']
            or task.get('source_ref',{}).get('digest')!=value['plan_digest']
            or plan.get('snapshot_digest')!=value['plan_digest']
            or digest([plan.get('config'),plan.get('resolved_window'),plan.get('created_at')])!=value['plan_digest']
            or source_digest(plan['config'])!=task['source_ref'].get('source_digest')
            or bound_scope(task,account,plan).binding()!=value['scope']):
        raise ValueError('来源任务、账号门店或原页已变化，未提交本页')
    if callable(guard):guard()
    scope=Scope(**value['scope']);request=ReadRequest(**value['request']);receipt=ReadReceipt(**value['receipt'])
    from .acquisition_extension.contracts import verify_receipt
    verify_receipt(scope,request,receipt)
    stamp=datetime.now(timezone.utc).isoformat()
    page_id=json_digest([scope.fingerprint,value['pipeline_before'],request.digest(scope),receipt.payload])
    if not read(PAGES,page_id):
        put(PAGES,{'id':page_id,'tenant_id':tenant_id,'scope':scope.binding(),'request':value['request'],
            'raw_page':receipt.payload,'transport_evidence':receipt.evidence,'source_evidence':value['evidence'],
            'unresolved':value['unresolved'],'observed_at':stamp})
    for event in value['events']:
        ident=json_digest([tenant_id,owner,account_id,scope.platform,event['type'],event['event_id']])
        if not read(EVENTS,ident):
            put(EVENTS,{'id':ident,'tenant_id':tenant_id,'scope':scope.binding(),'event':event,
                'page_evidence_id':page_id,'observed_at':stamp,
                'analysis_status':'pending' if event.get('disposition')=='pending_analysis' else 'interaction_only'})
    if inbox_update is not None:
        from .collection_inbox import ENTITY,binding
        current=read(ENTITY,task_id)
        if (current.get('binding')!=binding(task) or current.get('pipeline_before')!=task.get('pipeline')
                or current.get('source_page',{}).get('digest')!=expected
                or inbox_update.get('index',-1)<=current.get('index',-1)):
            raise ValueError('原来源页处理位置已变化，未推进断点')
        put(ENTITY,inbox_update)
    if page_complete:
        task.pop('source_scan_pending',None)
        task['pipeline']=value['pipeline_next']
        task['exhausted']=not task['pipeline']['extension']['jobs']
        put('tasks',task)
    if callable(guard):guard()


def source_scan(task):
    if task.get('source_kind')!='own_interactions':return 0
    value=((task.get('pipeline') or {}).get('extension') or {}).get('scan',1)
    if type(value) is not int or not 1<=value<=1000000:raise ValueError('原互动检查轮次无效')
    return value


def receipt_partition(task):
    scan=source_scan(task)
    return 'source-scan-'+str(scan) if scan else None


def next_interaction_scan(store,task,plan,expected_scan,guard):
    """One explicit CAS; a repeated scan number never starts another read."""
    if task.get('source_kind')!='own_interactions' or type(expected_scan) is not int:
        raise ValueError('请选择本人互动的明确检查轮次')
    guard();account=store.get('accounts',task['account_id']) or {};scope=bound_scope(task,account,plan)
    checkpoint=(task.get('pipeline') or {}).get('extension')
    if not checkpoint or checkpoint.get('jobs'):raise ValueError('本轮互动尚未完成，请继续原断点')
    if expected_scan!=source_scan(task)+1:raise ValueError('互动检查轮次已变化，请核对原检查结果')
    source=source_for(task,plan);result=source.start_scan(scope,checkpoint)
    updated=deepcopy(task);updated['pipeline']=_pipeline(task,plan,result);updated['exhausted']=False
    updated['status']='ready';updated['source_scan_pending']=True;updated.pop('pause_reason',None)
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        raw=db.execute("SELECT body FROM records WHERE entity='tasks' AND id=? AND tenant_id=?",(task['id'],task['tenant_id'])).fetchone()
        current=json.loads(raw['body']) if raw else {}
        if current!=task:raise ValueError('原互动任务已变化，未开始新检查')
        guard()
        db.execute("UPDATE records SET body=? WHERE entity='tasks' AND id=? AND tenant_id=?",(json.dumps(updated,ensure_ascii=False),task['id'],task['tenant_id']))
    return updated
