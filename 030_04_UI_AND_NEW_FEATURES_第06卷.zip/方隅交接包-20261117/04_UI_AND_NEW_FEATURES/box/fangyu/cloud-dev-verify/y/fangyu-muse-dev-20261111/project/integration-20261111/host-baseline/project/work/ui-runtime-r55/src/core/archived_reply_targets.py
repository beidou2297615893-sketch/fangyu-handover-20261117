"""Local reply routing proof for immutable, owned comment archives.

No platform read/send, inferred recipient, tombstone, or lead mutation lives here.
Only the retained reader's owned receipt can create a binding. Existing bindings
can be checked after restart; the original action/key are never regenerated.
"""
import hashlib
import json
import re
import time
from contextlib import nullcontext

from .page_errors import CoreError
from .platform_reads import PlatformReadService, ReadAccessError, normalize_sources
from .review_queue import require_reply_permission
from .service_plans import require_feature


BINDINGS = 'archived_comment_reply_targets'
SOURCES = 'platform_read_archive_sources'
BATCHES = 'platform_read_archive_batches'
RECEIPTS = 'platform_read_archive_receipts'
_KEY = re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}\Z')
_SOURCE_FIELDS = ('platform', 'source_id', 'source_type', 'note_url', 'url',
                  'comment_id', 'author_id', 'target_comment_id', 'target_author_id')
_ACTOR_FIELDS = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
_ORIGIN_FIELDS = ('device_id', 'account_id', 'account_uid', 'account_binding_digest',
                  'connection_digest', 'license_digest', 'input_digest')


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_encoded(value).encode('utf-8')).hexdigest()


class ArchivedReplyTargetError(CoreError):
    def __init__(self, reason, *, mutation_committed=False):
        super().__init__('原评论回复目标需核对：' + reason)
        self.reason = reason
        self.code = 'ARCHIVED_REPLY_TARGET_' + reason.upper()
        self.mutation_committed = mutation_committed


def _fail(reason):
    raise ArchivedReplyTargetError(reason)


class ArchivedReplyTargets:
    ACTIONS = frozenset({'platform_archive_reply_target_bind', 'platform_archive_reply_target_get'})

    def __init__(self, core, tenant, owner, company, *, read_service, device_id,
                 scope_guard, lead_access, license_policy_provider):
        if (not isinstance(read_service, PlatformReadService) or read_service.core is not core
                or (read_service.tenant, read_service.owner, read_service.device_id) != (tenant, owner, device_id)
                or not isinstance(company, dict) or not isinstance(company.get('id'), str) or not company['id']
                or not isinstance(company.get('managedWorkspace'), dict)
                or not isinstance(company['managedWorkspace'].get('environment_id'), str)
                or not company['managedWorkspace']['environment_id']
                or not device_id or not all(callable(value) for value in
                    (scope_guard, lead_access, license_policy_provider))):
            raise ValueError('评论路由需要同一本机服务端读取与授权范围')
        self.core, self.store, self.tenant, self.owner = core, core.store, tenant, owner
        self.company, self.read_service, self.device_id = company, read_service, device_id
        self.scope_guard, self.lead_access = scope_guard, lead_access
        self.license_policy_provider = license_policy_provider
        self.company_scope = self._company_scope()

    def install(self):
        # Internal-only registry. Core fails closed until this trusted host has
        # reattached its current scope, including after a process restart.
        with self.core.lock:
            if not hasattr(self.core, 'archived_reply_targets'):
                self.core.archived_reply_targets = {}
            self.core.archived_reply_targets[(self.tenant, self.owner)] = self
        return self

    def _company_scope(self):
        return _hash({key: self.company.get(key) for key in
                      ('id', 'managedWorkspace', 'productAccessPolicy')})

    def _principal(self, user):
        saved = self.store.get('users', user.get('id')) if isinstance(user, dict) else None
        if (not saved or saved.get('disabled') or saved.get('cloud_bound') is not True
                or saved.get('role') not in ('operator', 'admin')
                or (saved.get('tenant_id'), saved.get('username')) != (self.tenant, self.owner)
                or any(saved.get(key) != user.get(key) for key in _ACTOR_FIELDS)):
            _fail('principal_changed')
        try:
            valid = self.scope_guard() is True and self.company_scope == self._company_scope()
        except Exception:
            valid = False
        if not valid:
            _fail('scope_changed')
        return saved

    def _row(self, db, entity, ident):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (entity, ident, self.tenant)).fetchone()
        if not row:
            return None
        try:
            value = json.loads(row['body'])
        except (ValueError, TypeError):
            _fail('record_invalid')
        if not isinstance(value, dict) or (value.get('id'), value.get('tenant_id')) != (ident, self.tenant):
            _fail('record_invalid')
        return value

    def _binding_id(self, lead_id):
        return _hash([self.tenant, self.owner, self.device_id, lead_id])

    def _binding_record(self, record, lead_id):
        if record is None:
            return None
        fields = {'id', 'tenant_id', 'cloud_owner', 'device_id', 'lead_id', 'actor',
                  'company_scope', 'origin', 'source_digest', 'recipient', 'read_request_id',
                  'idempotency_key', 'operation_action', 'created_at', 'binding_digest',
                  'archive_batch_id', 'archive_batch_digest', 'archive_receipt_id', 'archive_receipt_digest'}
        if (set(record) != fields or record.get('id') != self._binding_id(lead_id)
                or record.get('lead_id') != lead_id or record.get('cloud_owner') != self.owner
                or record.get('device_id') != self.device_id
                or record.get('operation_action') != 'platform_archive_reply_target_bind'
                or any(not isinstance(record.get(key), str) or not _KEY.fullmatch(record[key])
                       for key in ('read_request_id', 'idempotency_key'))
                or not isinstance(record.get('actor'), dict) or not isinstance(record.get('origin'), dict)):
            _fail('record_invalid')
        return record

    def _source(self, db, lead_id, actor):
        lead = self._row(db, 'leads', lead_id)
        if (not lead or lead.get('cloud_owner') != self.owner or lead.get('demo')):
            _fail('source_forbidden')
        try:
            self.lead_access(actor, lead)
            require_reply_permission(self.core, actor, lead)
        except ValueError:
            _fail('reply_permission_changed')
        if lead.get('readonly_archive') is not True or lead.get('source_type') != 'comment':
            _fail('archive_contract_required')
        if lead.get('platform') != 'xiaohongshu':
            _fail('comment_contract_unavailable')
        source_id = _hash([self.tenant, lead.get('source_uid')])
        source = self._row(db, SOURCES, source_id)
        if (not source or source.get('lead_id') != lead_id or source.get('cloud_owner') != self.owner
                or source.get('device_id') != self.device_id
                or (source.get('actor_id'), source.get('actor_role')) != (actor['id'], actor['role'])):
            _fail('source_scope_changed')
        if (source.get('source_uid') != lead.get('source_uid') or source.get('platform') != lead.get('platform')
                or source.get('lead_source_digest') != _hash({key: lead.get(key) for key in _SOURCE_FIELDS})
                or source.get('lead_text_hash') != _hash(lead.get('text') or '')):
            _fail('source_changed')
        if (source.get('reply_target_verified') is not False or source.get('real_platform_verified') is not False
                or source.get('evidence_level') != 'transport_reported' or source.get('storage_scope') != 'this_device'):
            _fail('source_changed')
        if (source.get('author_identity') != 'platform_id'
                or any(not isinstance(source.get(key), str) or not _ID.fullmatch(source[key])
                       for key in ('post_id', 'comment_id', 'author_id', 'account_id', 'account_uid'))):
            _fail('original_identity_missing')
        return lead, source

    def _ready(self, actor, lead, source, *, allow_reply_mode=False):
        try:
            require_feature(self.company, 'acquisition')
            require_reply_permission(self.core, actor, lead)
            account = self.core._get('accounts', source['account_id'], self.tenant)
            self.core._account_access(actor, account)
            policy = self.license_policy_provider()
        except ValueError:
            _fail('permission_or_account_changed')
        if not isinstance(policy, dict) or policy.get('xiaohongshu') is not True:
            _fail('license_unavailable')
        origin = self.read_service._origin(actor, account, source['input_digest'])
        if (origin['actor'] != {key: actor.get(key) for key in _ACTOR_FIELDS}
                or any(origin.get(key) != source.get(key) for key in _ORIGIN_FIELDS)
                or origin.get('archive_scope_verified') is not True):
            _fail('origin_changed')
        if self.read_service._availability(account, 'comments') != 'ready_for_guarded_read':
            _fail('runtime_held')
        manifest = self.core.adapters.manifest('xiaohongshu')
        if not manifest.get('reply_contract_verified') or not manifest.get('isolation_guard'):
            _fail('comment_contract_unavailable')
        if any(item.get('id') != account['id'] and item.get('platform') == 'xiaohongshu'
               and item.get('platform_uid') == source['account_uid']
               for item in self.store.list('accounts', self.tenant)):
            _fail('account_identity_conflict')
        mode = self.core.account_mode_status(account['id'], self.tenant)
        if mode.get('status') == 'active':
            # Own current send lease is validated by Core; the routing proof is
            # read-only and must never acquire or clear a competing lease.
            from .continuous import process_alive
            if process_alive(mode.get('pid')) and (not allow_reply_mode or mode.get('mode') != 'replies'):
                _fail('account_busy')
        try:
            self.core.adapters.require_account_safe('xiaohongshu',
                self.store.directory / 'accounts' / self.tenant / account['id'])
        except Exception:
            _fail('account_risk_held')
        return account, origin

    def _archive_proof(self, db, actor, lead_id, batch_id, *, expected_batch_digest=None, receipt_id=None):
        batch = self._row(db, BATCHES, batch_id)
        if (not batch or batch.get('cloud_owner') != self.owner or batch.get('device_id') != self.device_id
                or batch.get('actor') != {key: actor.get(key) for key in _ACTOR_FIELDS}
                or lead_id not in batch.get('lead_ids', [])
                or expected_batch_digest is not None and batch.get('batch_digest') != expected_batch_digest):
            _fail('archive_chain_changed')
        if receipt_id is None:
            ids = []
            for raw in db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=?',
                                  (RECEIPTS, self.tenant)).fetchall():
                try:
                    value = json.loads(raw['body'])
                except (TypeError, ValueError):
                    continue
                if isinstance(value, dict) and value.get('batch_id') == batch_id:
                    ids.append(raw['id'])
            if not ids:
                _fail('archive_chain_changed')
            receipt_id = sorted(ids)[0]
        receipt = self._row(db, RECEIPTS, receipt_id)
        if (not receipt or receipt.get('batch_id') != batch_id or receipt.get('state') != 'succeeded'):
            _fail('archive_chain_changed')
        from assistant.platform_receipt_archive import PlatformReceiptArchive, ReceiptArchiveError
        archive = PlatformReceiptArchive(self.core, self.tenant, self.owner, self.company,
            read_service=self.read_service, device_id=self.device_id, scope_guard=self.scope_guard)
        try:
            public = archive._receipt_view(receipt, actor)
        except ReceiptArchiveError:
            _fail('archive_chain_changed')
        if public.get('lead_ids') != batch.get('lead_ids') or public.get('accepted_count') != batch.get('source_count'):
            _fail('archive_chain_changed')
        return {'archive_batch_id': batch_id, 'archive_batch_digest': _hash(batch),
                'archive_receipt_id': receipt_id, 'archive_receipt_digest': _hash(receipt)}

    def _validated(self, db, lead_id, actor, binding=None, *, allow_reply_mode=False):
        actor = self._principal(actor)
        lead, source = self._source(db, lead_id, actor)
        account, origin = self._ready(actor, lead, source, allow_reply_mode=allow_reply_mode)
        if binding is not None:
            proof = {key: value for key, value in binding.items() if key != 'binding_digest'}
            if (binding.get('binding_digest') != _hash(proof)
                    or binding.get('source_digest') != _hash(source)
                    or binding.get('company_scope') != self.company_scope
                    or binding.get('actor') != origin['actor'] or binding.get('origin') != origin
                    or binding.get('recipient') != self._recipient(source)):
                _fail('binding_stale')
            archive_proof = self._archive_proof(db, actor, lead_id, binding.get('archive_batch_id'),
                                              receipt_id=binding.get('archive_receipt_id'))
            if any(binding.get(key) != value for key, value in archive_proof.items()):
                _fail('archive_chain_changed')
        return lead, source, account, origin

    @staticmethod
    def _recipient(source):
        url = 'https://www.xiaohongshu.com/explore/' + source['post_id']
        return {'platform': 'xiaohongshu', 'comment_id': source['comment_id'], 'note_url': url, 'url': url}

    def resolve(self, lead, channel, user=None, account=None):
        if channel != 'comment':
            _fail('comment_only')
        with self.core.lock, self.store.connect() as db:
            binding = self._binding_record(self._row(db, BINDINGS, self._binding_id(lead['id'])), lead['id'])
            if not binding:
                _fail('not_bound')
            actor = user or self.store.get('users', binding.get('actor', {}).get('id'))
            current, _, actual_account, _ = self._validated(db, lead['id'], actor, binding, allow_reply_mode=True)
            if current != lead:
                _fail('lead_snapshot_changed')
            if account is not None and account != actual_account:
                _fail('original_account_required')
            return {**binding['recipient'], 'binding_id': binding['id'],
                    'binding_digest': binding['binding_digest'],
                    'account_binding_digest': binding['origin']['account_binding_digest']}

    def _contact_source(self, lead, user, account, *, db):
        """Private identity for manual evidence; preserves all routing guards."""
        binding = self._binding_record(self._row(db, BINDINGS, self._binding_id(lead['id'])), lead['id'])
        if not binding:
            _fail('not_bound')
        current, source, actual_account, _ = self._validated(db, lead['id'], user, binding, allow_reply_mode=True)
        if current != lead or actual_account != account:
            _fail('original_source_or_account_changed')
        return {key: source[key] for key in ('author_id', 'comment_id', 'post_id')}

    def _view(self, lead_id, state, reason, binding=None, *, committed=False, read_only=True):
        return {'lead_id': lead_id, 'platform': 'xiaohongshu', 'channel': 'comment',
                'state': state, 'reason': reason, 'binding_id': binding['id'] if binding else None,
                'operation_action': 'platform_archive_reply_target_bind' if binding else None,
                'idempotency_key': binding['idempotency_key'] if binding else None,
                'routing_source_matched': state == 'bound', 'can_prepare_comment_reply': state == 'bound',
                'send_allowed': False, 'send_requires_existing_confirmation': True,
                'read_only': read_only, 'mutation_committed': committed, 'refresh_required': not read_only,
                'local_only': True, 'storage_scope': 'this_device', 'cross_machine_verified': False,
                'real_platform_verified': False, 'platform_requests_started': False,
                'provider_requests_started': False, 'auto_retry': False}

    def execute(self, action, data, user):
        if action not in self.ACTIONS or not isinstance(data, dict):
            _fail('invalid_input')
        bind = action == 'platform_archive_reply_target_bind'
        expected = {'lead_id', 'read_request_id', 'idempotency_key'} if bind else {'lead_id'}
        if (set(data) != expected or not isinstance(data.get('lead_id'), str)
                or not _ID.fullmatch(data['lead_id'])
                or bind and any(not isinstance(data.get(key), str) or not _KEY.fullmatch(data[key])
                                for key in ('read_request_id', 'idempotency_key'))):
            _fail('invalid_input')
        actor = self._principal(user)
        lead_id, ident = data['lead_id'], self._binding_id(data['lead_id'])
        try:
            # Only binding enters owned_receipt. Keep the same reads -> Core
            # order through its final checks and the surrounding DB commit.
            with (self.read_service._lock if bind else nullcontext()),self.core.lock,self.store.connect() as db:
                if bind:
                    db.execute('BEGIN IMMEDIATE')
                # Ownership checks precede public absence/stale projection.
                lead = self._row(db, 'leads', lead_id)
                if not lead or lead.get('cloud_owner') != self.owner:
                    _fail('source_forbidden')
                try:
                    self.lead_access(actor, lead)
                except ValueError:
                    _fail('source_forbidden')
                prior = self._binding_record(self._row(db, BINDINGS, ident), lead_id)
                if not bind or prior:
                    if bind and (prior.get('idempotency_key') != data['idempotency_key']
                            or prior.get('read_request_id') != data['read_request_id']):
                        _fail('key_conflict')
                    if prior is None:
                        return self._view(lead_id, 'not_bound', 'not_bound')
                    try:
                        self._validated(db, lead_id, actor, prior)
                    except ArchivedReplyTargetError as exc:
                        return self._view(lead_id, 'stale', exc.reason, prior, read_only=not bind)
                    return self._view(lead_id, 'bound', 'local_route_matched', prior,
                                      committed=bind, read_only=not bind)
                _, source, _, origin = self._validated(db, lead_id, actor)
                with self.read_service.owned_receipt(source['account_id'], data['read_request_id'], actor, self.device_id) as snapshot:
                    items = snapshot['result'].get('items')
                    if (snapshot['operation_id'] != source['read_operation_id'] or snapshot['origin'] != origin
                            or snapshot['observed_at'] != source.get('observed_at')
                            or not isinstance(items, list) or normalize_sources('xiaohongshu', items) != items):
                        _fail('receipt_source_mismatch')
                    matched = [item for item in items if item.get('source_uid') == source['source_uid']]
                    if len(matched) != 1:
                        _fail('receipt_source_mismatch')
                    item = matched[0]
                    from assistant.platform_receipt_archive import _safe_text
                    safe, _ = _safe_text(item['text'], 3000)
                    if (any(item.get(key) != source.get(key) for key in
                            ('platform', 'post_id', 'comment_id', 'author_id', 'author_identity'))
                            or _hash(item['text']) != source['original_text_hash']
                            or _hash(safe) != source['safe_text_hash']):
                        _fail('receipt_source_mismatch')
                    batch_id = _hash([self.tenant, self.owner, self.device_id, source['account_id'], data['read_request_id']])
                    batch_digest = _hash([snapshot['origin'], snapshot['result_digest'], snapshot['operation_id']])
                    archive_proof = self._archive_proof(db, actor, lead_id, batch_id, expected_batch_digest=batch_digest)
                    record = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                              'device_id': self.device_id, 'lead_id': lead_id, 'actor': origin['actor'],
                              'company_scope': self.company_scope, 'origin': origin,
                              'source_digest': _hash(source), 'recipient': self._recipient(source),
                              'read_request_id': data['read_request_id'], 'idempotency_key': data['idempotency_key'],
                              'operation_action': action, 'created_at': time.time(), **archive_proof}
                    record['binding_digest'] = _hash(record)
                    db.execute('INSERT INTO records VALUES(?,?,?,?)', (BINDINGS, ident, self.tenant, _encoded(record)))
                    self._validated(db, lead_id, actor, record)
                self._validated(db, lead_id, actor, record)
            return self._view(lead_id, 'bound', 'local_route_matched', record, committed=True, read_only=False)
        except ArchivedReplyTargetError:
            raise
        except ReadAccessError:
            raise ArchivedReplyTargetError('receipt_unavailable') from None
        except Exception:
            raise ArchivedReplyTargetError('storage_unknown', mutation_committed=None if bind else False) from None
