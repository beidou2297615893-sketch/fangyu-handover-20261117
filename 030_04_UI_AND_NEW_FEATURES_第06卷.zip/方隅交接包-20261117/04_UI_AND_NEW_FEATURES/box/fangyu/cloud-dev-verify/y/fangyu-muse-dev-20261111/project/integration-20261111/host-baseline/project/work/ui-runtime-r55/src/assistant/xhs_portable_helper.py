"""Parent-side fixed argv/material binding only, never actor/purpose authority."""
from dataclasses import dataclass
from pathlib import Path
import re
from portable_helper_package import verify_package

class PortableHelperUnavailable(ValueError):pass

class PortableHelperBinding:
    def __init__(self,executable,expected_manifest_sha256):
        if not isinstance(executable,Path) or type(expected_manifest_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_manifest_sha256):raise PortableHelperUnavailable('portable_helper_review_required')
        self.executable_path=executable
        self.manifest_sha256=expected_manifest_sha256
        self.manifest,self._sha,self._files=verify_package(executable,expected_manifest_sha256)
    def validate(self):
        try:
            _,sha,files=verify_package(self.executable_path,self.manifest_sha256)
            return sha==self._sha and files==self._files
        except (OSError,ValueError,TypeError):return False
    def executable(self,value,owner_sid,current_sid):
        if owner_sid!=current_sid or str(Path(value).absolute()).casefold()!=str(self.executable_path).casefold() or not self.validate():raise PortableHelperUnavailable('portable_helper_binding_changed')
        return str(self.executable_path)
    @property
    def expected_files(self):
        # Original parent must retain its own _FileLease/image/Job/origin proof.
        return ((str(self.executable_path.parent/'HELPER-PACKAGE.json'),self.manifest_sha256),)+tuple((str(self.executable_path.parent/rel),sha) for rel,sha,_ in self._files)
    def command(self,spec_path,profile_dir):
        from assistant.owned_helper_process import OwnedHelperCommand
        if not self.validate() or not isinstance(spec_path,Path) or not isinstance(profile_dir,Path) or not spec_path.is_absolute() or spec_path.name!='spec.json' or len(spec_path.parents)<4 or profile_dir!=spec_path.parents[3]/'xhs-browser-profile':raise PortableHelperUnavailable('portable_helper_arguments_invalid')
        return OwnedHelperCommand((str(self.executable_path),'--owned-xhs-page-helper','--bridge-spec',str(spec_path),'--profile-dir',str(profile_dir),'--package-sha256',self.manifest_sha256),str(self.executable_path.parent))
