"""Current source interpreter identity only, never a component-use review.

No diagnostic project path, bootstrap, developer capability or CLI grant.
Frozen deployment and WebView2/.NET loaded-module evidence are unavailable in
this first slice. A pre-resume process cannot prove future browser DLL loads.
"""
import hashlib
import os
from pathlib import Path
import sys

class RuntimeMaterialUnavailable(ValueError):
    def __init__(self):
        super().__init__('page_runtime_material_unavailable')


def _checked_path(path):
    # Mechanical reparse guard, retained from the reviewed production helper.
    # It does not import that helper's diagnostic bootstrap or authority.
    path = Path(path).absolute()
    for part in (path, *path.parents):
        if part.is_symlink() or (part.exists() and
                getattr(part.lstat(), 'st_file_attributes', 0) & 0x400):
            raise RuntimeMaterialUnavailable()
    return path


def digest(path):
    value = hashlib.sha256()
    with _checked_path(Path(path)).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def fixed_interpreter():
    # The actual App executable is the source of this material. An arbitrary
    # argv or HTTP-supplied executable cannot select another interpreter.
    if getattr(sys, 'frozen', False) is True or os.name != 'nt':
        raise RuntimeMaterialUnavailable()
    shim = _checked_path(Path(sys.executable))
    if shim.name.casefold() not in ('python.exe', 'pythonw.exe'):
        raise RuntimeMaterialUnavailable()
    configuration = _checked_path(shim.parent.parent / 'pyvenv.cfg')
    homes = [line.partition('=')[2].strip() for line in configuration.read_text('utf-8').splitlines()
             if line.partition('=')[0].strip().casefold() == 'home']
    if len(homes) != 1 or not Path(homes[0]).is_absolute():
        raise RuntimeMaterialUnavailable()
    alias = Path(sys._base_executable).absolute()
    base = _checked_path(alias.resolve(strict=True))
    expected = _checked_path((Path(homes[0]) / shim.name.casefold()).resolve(strict=True))
    if base != expected or base == shim.resolve() or not base.is_file():
        raise RuntimeMaterialUnavailable()
    return shim, alias, base, configuration


def fixed_loaded_source(value):
    """Normalize only this verified interpreter's known installation alias.

    Do not resolve arbitrary source/package/reparse paths. The alias, actual
    base and pyvenv home are the exact existing fixed_interpreter binding.
    """
    path = Path(value).absolute()
    if getattr(sys,'frozen',False) is True:
        # Real paths only. PYZ/entry code origins are independently checked by
        # the fixed package validator, never normalized into pretend .py files.
        checked=_checked_path(path)
        if not checked.is_file():raise RuntimeMaterialUnavailable()
        return checked
    shim, alias, base, configuration = fixed_interpreter()
    try:
        relative = path.relative_to(alias.parent)
    except ValueError:
        return _checked_path(path)
    if alias.parent != base.parent:
        allowed = (relative.parts and relative.parts[0].casefold() in ('lib', 'dlls'))
        allowed = allowed or relative.name.casefold() in (
            'python.exe', 'pythonw.exe', 'python3.dll',
            'python' + str(sys.version_info.major) + str(sys.version_info.minor) + '.dll')
        target = _checked_path(base.parent / relative)
        if not allowed or path.resolve(strict=True) != target or alias.resolve(strict=True) != base:
            raise RuntimeMaterialUnavailable()
        return target
    return _checked_path(path)


def current_token_user():
    """Reuse the strict bounded TokenUser reader; never apply a QA capability."""
    from . import owner
    from .image import NativeProcessImageBinding
    from ctypes import wintypes
    kernel, advapi = owner.native_apis()
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    result = {'handles_closed': True}
    value = NativeProcessImageBinding._token_sid(
        kernel, advapi, kernel.GetCurrentProcess(), owner, result)
    if result['handles_closed'] is not True or not owner.valid_sid(value):
        raise RuntimeMaterialUnavailable()
    return value
