"""Original natural candidate -> Coordinator -> one original journal commit.

Only one explicit login job uses this private purpose. The original outer OS
lock stays held after inner Native Scope.finish. No child result is a grant.
"""
from dataclasses import dataclass
import hashlib
import secrets
import threading
import time

from core.adapters import account_execution_lock,AdapterSafetyRequired
from .browser_login_coordinator import BrowserLoginCoordinator
from .browser_session_commit import account_revision,commit_browser_session,recover_browser_session
from .browser_login_service import (_staging_scope,_profile_scope,_cleanup_staging,
    _cancel_marker,_record_browser_outcome,_helper_failure,_message,_Stopped)
from .login_natural_proof import create_spec,verified_status,SPEC_NAME,PROOF_NAME
from .xhs_session_context import (mint_session_worker,session_worker_call,
    _SessionWorkerClaim,record_session_completion)
from .xhs_session_scope import _SessionScope
from .xhs_session_policy import XhsSessionRecoveryPolicy
from .xhs_session_transport import SessionRecoveryTransport
from .owned_xhs_native.provider import OwnedXhsNativeProvider

_CANDIDATE_SEAL=object()


@dataclass(frozen=True,slots=True,repr=False)
class _SessionCandidate:
    seal:object
    scope:object
    decision:object
    staging:object
    files:tuple
    uid:str

    def check(self):
        if self.seal is not _CANDIDATE_SEAL or type(self.scope) is not _SessionScope:
            raise AdapterSafetyRequired('session_candidate_changed')
        self.scope.require_candidate()
        self.decision._current()
        root=self.scope.runtime.core.store.directory
        if not _staging_scope(root,self.scope.root,self.staging):
            raise AdapterSafetyRequired('session_candidate_changed')
        for path,sha in self.files:
            if (path.is_symlink() or not path.is_file()
                    or hashlib.sha256(path.read_bytes()).digest()!=sha):
                raise AdapterSafetyRequired('session_candidate_changed')
        value=verified_status(self.staging,self.files[0][0])
        if value is None or value['data']['user']['id']!=self.uid:
            raise AdapterSafetyRequired('natural_proof_invalid')


def _snapshot(service,context,scope,decision):
    context.check()
    if scope is not None and scope.finished:scope.require_candidate()
    decision._current()
    claim,core=context.claim,service.server.core
    with core.lock:
        account=core._get('accounts',claim.account_id,claim.session.executor.tenant)
        core.adapters.require_account_safe('xiaohongshu',
            core.store.directory/'accounts'/account['tenant_id']/account['id'])
        return {'id':account['id'],'platform':account['platform'],'exists':True,
            'access_revoked':False,'cloud_paused':False,'safety_paused':False,
            'platform_uid':account.get('platform_uid'),'tenant_id':account['tenant_id'],
            'revision':account_revision(account),'_account':dict(account)}


def start_session_recovery(service,account_id):
    from .service import AssistantService
    from .xhs_page_runtime import XhsPageRuntime
    if type(service) is not AssistantService:raise AdapterSafetyRequired('session_service_unavailable')
    server,core=service.server,service.server.core
    user=service._local_user(read_only=True)
    with core.lock:
        account=core._get('accounts',str(account_id or ''),user['tenant_id'])
        core._account_access(user,account)
        from .xhs_customer_account_runtime import runtime_for,account_runtime_matches
        runtime=runtime_for(server)
        policy=getattr(server,'_xhs_session_policy',None)
        factory=getattr(runtime,'owned_session_factory',None)
        if (account.get('platform')!='xiaohongshu' or type(runtime) is not XhsPageRuntime
                or not account_runtime_matches(server,runtime) or not runtime.natural_mode
                or runtime.closed or type(policy) is not XhsSessionRecoveryPolicy
                or policy.resolve() is None or type(factory) is not OwnedXhsNativeProvider
                or factory._server is not server or factory.session_factory is not factory):
            raise AdapterSafetyRequired('session_component_review_unavailable')
        account_dir=core.store.directory/'accounts'/user['tenant_id']/account['id']
        core.adapters.require_account_safe('xiaohongshu',account_dir)
    # No job_lock -> Core/runtime inversion in the new purpose.
    with server.job_lock:
        if any(other.get('kind')=='assistant_account_login'
                and other.get('account_id')==account['id']
                and (other.get('status')=='running' or
                    isinstance(other.get('worker_done'),threading.Event)
                    and not other['worker_done'].is_set()) for other in server.jobs.values()):
            raise AdapterSafetyRequired('session_previous_worker_closing')
    # Original reservation may finish an idle old transport; no business or
    # job lock is held across its physical close.
    reservation=runtime.begin_login(account_dir)
    job={'id':secrets.token_hex(12),'kind':'assistant_account_login','mode':'browser',
                'purpose':'session_recovery','owner_id':user['id'],'tenant_id':user['tenant_id'],
                'account_id':account['id'],'status':'running','phase':'opening_browser',
                'worker_done':threading.Event(),'_session_runtime':runtime,
                '_session_reservation':reservation}
    try:
        claim=mint_session_worker(service,user,account,job)
        decision=policy.resolve()
        if decision is None:raise AdapterSafetyRequired('session_component_review_unavailable')
    except BaseException:
        with server.job_lock:
            if server.jobs.get(job['id']) is job:server.jobs.pop(job['id'])
        runtime.finish_login(account_dir,reservation)
        raise

    def run():
        scope=None
        staging=account_dir/'work/browser-login'/job['id']
        profile=account_dir/'xhs-browser-profile'
        outer=None
        outer_entered=False
        committed=False
        outcome_code='browser_login_failed'
        try:
            with session_worker_call(claim) as context:
                outer=account_execution_lock(account_dir)
                if getattr(server,'_customer_natural_component',False):
                    from .xhs_customer_account_runtime import operation_lock
                    outer=operation_lock(context,account_dir,outer)
                outer.__enter__();outer_entered=True
                connection=server.account_connections.locks.setdefault(account['id'],threading.Lock())
                with connection:
                    recovered=recover_browser_session(core.store,account_dir,account['id'],user['tenant_id'])
                if recovered not in ('clean','old_restored','new_kept'):raise _Stopped('recovery_required')
                initial=_snapshot(service,context,None,decision)
                if not _staging_scope(core.store.directory,account_dir,staging):raise _Stopped('staging_path_invalid')
                if not _profile_scope(core.store.directory,account_dir,profile):raise _Stopped('profile_path_invalid')
                staging.mkdir(parents=True,exist_ok=False)
                create_spec(staging,job_id=job['id'],bound_uid=initial.get('platform_uid') or None)
                scope=_SessionScope(runtime,user,account,job,context,reservation)
                scope.enter()
                try:
                    def guard(event,facts):
                        if (facts.get('action') not in ('status','session_recovery')
                                or facts.get('tenant_id')!=scope.tenant
                                or facts.get('account_id')!=scope.account_id):
                            raise AdapterSafetyRequired('session_action_denied')
                        scope.check();decision._current()
                    transport=SessionRecoveryTransport(scope.root,scope.tenant,scope.account_id,
                        str(account.get('platform_uid') or ''),guard,
                        lambda path:factory(path,owned_scope=scope),natural_mode=True,_session_scope=scope)
                    scope.entry.transport=transport
                    with server.job_lock:job.update(cancel_file=transport.cancel_file,phase='waiting_browser')
                    code=transport.open()
                finally:
                    scope.entry.stop_requested=True
                    scope.entry.lifecycle_wake.set()
                    with server.job_lock:job['phase']='cleaning_candidate'
                    scope.finish()
                # Exact Native owner confirms Job + descendants + leases + IPC
                # exited before this original coordinator can stage or claim.
                context.check();scope.require_candidate();decision._current()
                if code!='candidate_staged_natural_verified':
                    if code in ('cancelled','closed'):raise _Stopped('cancelled')
                    _record_browser_outcome(account_dir,job['id'],code.encode('ascii'))
                    raise _Stopped(_helper_failure(code.encode('ascii')))
                cookie=staging/'.xiaohongshu-cli/cookies.json'
                value=verified_status(staging,cookie)
                if value is None:raise _Stopped('natural_proof_invalid')
                candidate=_SessionCandidate(_CANDIDATE_SEAL,scope,decision,staging,
                    tuple((path,hashlib.sha256(path.read_bytes()).digest()) for path in
                        (cookie,staging/SPEC_NAME,staging/PROOF_NAME)),value['data']['user']['id'])
                candidate.check()
                def current():
                    candidate.check()
                    return _snapshot(service,context,scope,decision)
                def status_candidate(stage):
                    if stage!=staging:raise _Stopped('natural_proof_invalid')
                    candidate.check()
                    return verified_status(staging,cookie) or {'authenticated':False}
                def cloud_claim(uid):
                    with core.lock:
                        candidate.check()
                        with runtime.lock:
                            scope._retained_candidate_locked()
                            context.check()
                            with server.job_lock:
                                if job.get('status')!='running' or uid!=candidate.uid or job.get('_session_claim_once'):
                                    raise _Stopped('cloud_claim_failed')
                                job['_session_claim_once']=True
                    service._claim_xhs_account({**initial['_account'],'platform_uid':uid})
                    candidate.check()
                    return True
                def commit(stage,identity,original):
                    nonlocal committed
                    with core.lock:
                        candidate.check()
                        with runtime.lock:
                            scope._retained_candidate_locked()
                            context.check()
                            with server.job_lock:
                                if job.get('status')!='running' or stage!=staging or job.get('_session_commit_once'):
                                    raise _Stopped('commit_failed')
                                job['_session_commit_once']=True
                        def fresh_guard():
                            candidate.check()
                            now=_snapshot(service,context,scope,decision)
                            return now['revision']==original['revision'] and job.get('status')=='running'
                        # Original journaling, candidate validation, DB CAS and
                        # rollback. No replacement UID/ready persistence.
                        result=commit_browser_session(core.store,account_dir,original['_account'],
                            identity,cookie,fresh_guard)
                        job['commit_code']=result
                        if result=='committed':
                            committed=True
                            record_session_completion(context,scope,identity)
                        elif result=='recovery_required':
                            service._pause_xhs_identity(original['_account'],'session_recovery_required',
                                '会话恢复待管理员检查；相关任务已暂停')
                        return committed
                with connection:
                    coordinator=BrowserLoginCoordinator(stage=lambda:staging,status=status_candidate,
                        local_accounts=lambda:core.store.list('accounts',user['tenant_id']),
                        claim=cloud_claim,commit=commit,discard=lambda stage:None,current=current,
                        cancelled=lambda:job.get('status')=='cancelled',deadline=claim.deadline,
                        expected_revision=initial['revision'])
                    outcome=coordinator.run()
                if outcome.state!='completed':raise _Stopped(outcome.code)
                outcome_code='completed'
        except _Stopped as error:outcome_code=error.code
        except Exception:outcome_code='cancelled' if job.get('status')=='cancelled' else 'browser_login_failed'
        finally:
            # Physical and candidate cleanup do not require an active actor.
            if scope is not None and scope.entered and not scope.finished:
                scope.entry.stop_requested=True;scope.entry.lifecycle_wake.set();scope.finish()
            while staging.exists():
                try:_cleanup_staging(core.store.directory,account_dir,staging)
                except OSError:
                    with server.job_lock:job.update(phase='cleaning_candidate',cleanup_code='cleanup_failed')
                    time.sleep(.2)
                else:job.pop('cleanup_code',None)
            if scope is not None and scope.finished:scope.release_result()
            while True:
                try:runtime.finish_login(account_dir,reservation);break
                except Exception:time.sleep(.2)
            if outer_entered:outer.__exit__(None,None,None)
            with server.job_lock:
                if committed and outcome_code=='completed' and job.get('status')=='running':
                    job.update(status='completed',phase='completed',error_code='',error='')
                else:
                    cancelled=job.get('status')=='cancelled' or outcome_code=='cancelled'
                    job.update(status='cancelled' if cancelled else 'failed',phase='cancelled' if cancelled else 'stopped',
                        error_code='cancelled' if cancelled else outcome_code,error=_message(outcome_code))
                job['worker_done'].set()
    try:threading.Thread(target=run,name='assistant-natural-session-recovery',daemon=True).start()
    except BaseException:
        with server.job_lock:
            if server.jobs.get(job['id']) is job:server.jobs.pop(job['id'])
        runtime.finish_login(account_dir,reservation)
        raise
    return {'login_job':job['id'],'mode':'browser','purpose':'session_recovery',
        'session_committed':False,'cleanup_confirmed':False,
        'account':{key:account.get(key) for key in ('id','name','platform','status')}}


def cancel_session_recovery(service,job):
    server=service.server
    runtime=job.get('_session_runtime')
    with server.core.lock:
        with runtime.lock:
            with server.job_lock:
                claim=job.get('_session_claim')
                if (server.jobs.get(job.get('id')) is not job or job.get('purpose')!='session_recovery'
                        or type(claim) is not _SessionWorkerClaim or claim.job is not job
                        or claim.session.service is not service):raise AdapterSafetyRequired('session_cancel_changed')
                if job['worker_done'].is_set():return 'already_finished'
                completion=job.get('_session_completion')
                from .xhs_session_context import _SessionCompletion
                if (type(completion) is _SessionCompletion and completion.claim is claim
                        and job.get('commit_code')=='committed'):
                    return 'committed_cleanup_pending'
                job.update(status='cancelled',phase='cancelled',error_code='cancelled',error=_message('cancelled'))
                scope=runtime.jobs.get(job['id'])
                if type(scope) is _SessionScope and scope.job is job:
                    scope.user_cancelled=True
                    if scope.entry is not None and scope.entry.batch_scope is scope:
                        scope.entry.stop_requested=True;scope.entry.lifecycle_wake.set()
                        if scope.entry.transport is not None:scope.entry.transport.request_stop()
    _cancel_marker(job)
    return 'requested'


def session_recovery_status(service,user,account,job):
    server=service.server
    core=server.core
    core._account_access(user,account)
    with server.job_lock:
        if (server.jobs.get(job.get('id')) is not job or job.get('purpose')!='session_recovery'
                or job.get('owner_id')!=user['id'] or job.get('tenant_id')!=user['tenant_id']
                or job.get('account_id')!=account['id']):raise ValueError('无权访问该登录任务')
        claim=job.get('_session_claim')
        done=job['worker_done'].is_set()
        status=job.get('status') if done else 'running'
        complete=done and status=='completed'
    if type(claim) is not _SessionWorkerClaim:raise ValueError('登录任务范围无法核对')
    claim.check(result=complete,_metadata=not complete)
    return {'login_job':job['id'],'mode':'browser','purpose':'session_recovery',
        'status':status,'phase':job.get('phase') if done else 'closing_browser'
            if job.get('phase')=='cleaning_candidate' else job.get('phase','opening_browser'),
        'session_committed':complete,'cleanup_confirmed':done,'qr_ready':False,
        'cleanup_code':job.get('cleanup_code','') if done else 'physical_cleanup_pending',
        'account_ready':False,
        'error_code':job.get('error_code','') if done else '',
        'error':job.get('error','') if done else '',
        'message':'登录已保存，采集资格仍以账号与安全状态为准' if complete else
            '正在登录或确认资源收尾' if not done else _message(job.get('error_code','browser_login_failed'))}
