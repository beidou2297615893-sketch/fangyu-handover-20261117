"""Windows native WebView2 shell. Never falls back to an external browser."""
import ctypes
from ctypes import wintypes
import logging
import os
import threading
import time
from pathlib import Path
from urllib.parse import urlparse
import sys


def focus_process_window(pid):
    """Activate only a visible top-level window owned by the locked app process."""
    if os.name!='nt' or not isinstance(pid,int) or pid<=0:return False
    user32=ctypes.windll.user32
    user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    user32.IsWindowVisible.argtypes=[wintypes.HWND]
    user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
    user32.SetForegroundWindow.argtypes=[wintypes.HWND]
    matches=[]
    callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    def visitor(handle,_):
        owner=wintypes.DWORD();user32.GetWindowThreadProcessId(handle,ctypes.byref(owner))
        if owner.value==pid and user32.IsWindowVisible(handle):matches.append(handle);return False
        return True
    callback=callback_type(visitor)
    user32.EnumWindows(callback,0)
    if not matches:return False
    user32.ShowWindow(matches[0],9)
    user32.SetForegroundWindow(matches[0])
    return True


def show_desktop_error(message):
    logging.error('Desktop startup failed: %s',message)
    if os.name=='nt':
        ctypes.windll.user32.MessageBoxW(None,'本地客户端未能启动。\n\n请确认已安装 Microsoft Edge WebView2 Runtime，并查看工作台日志。\n\n'+str(message),'客户端启动失败',0x10)


def request_owner_close_retry(code):
    """Original main stays alive/locked; only a real Retry triggers a recheck.

    This is a diagnostic fallback for a startup failure or interrupted event
    loop. Normal visible-window closure uses pywebview's closing veto instead.
    Neither button asserts physical closure. Cancel only keeps this reminder.
    """
    safe_codes={'OWNED_RESOURCES_CLEANUP_PENDING','NATIVE_CLOSED_EVENT_PENDING',
        'ORIGINAL_SERVER_THREAD_PENDING','ORIGINAL_LOGIN_CLEANUP_UNCONFIRMED',
        'ORIGINAL_NATIVE_CLEANUP_UNCONFIRMED','ORIGINAL_CUSTODY_CLEANUP_UNCONFIRMED'}
    diagnostic=code if code in safe_codes else 'OWNER_CLOSE_PENDING'
    while True:
        try:
            if os.name=='nt':
                choice=ctypes.windll.user32.MessageBoxW(None,
                    '原工作台尚未完成收尾，原进程与锁保持。\n\n'
                    '点“重试”仅重新核对原资源；取消会保留本提醒，不会强制退出或发送。\n\n'+diagnostic,
                    '方隅工作台 · 收尾待核对',0x35)
                if choice==4:return
            else:
                # Source developer entry only; no absent input means idle.
                if input('Original resources held. Type retry to recheck: ').strip()=='retry':return
        except (KeyboardInterrupt,EOFError):
            logging.warning('Owner close retry input unavailable; original main lock retained')
            time.sleep(1)


def run_desktop(server,url,data_dir,title,ready_callback=None,ready_timeout=None):
    import webview
    if os.name=='nt':ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LocalWorkspace.'+server.company['id'])
    stop_lock=threading.Lock();stopped=False
    owner_mode=bool(getattr(server,'self_operating_read',False))
    owner_mutex=getattr(server,'_owner_instance_mutex',None) if owner_mode else None
    def stop_owned():
        nonlocal stopped
        with stop_lock:
            if stopped:return True
            if owner_mode:
                if server.close_owned_jobs() is not True:return False
                stopped=True
            else:stopped=True
        try:
            if not owner_mode:server.close_owned_jobs()
        finally:server.shutdown()
        return True
    webview.settings['ALLOW_DOWNLOADS']=True
    window=webview.create_window(title,url=url,width=1440,height=960,min_size=(1000,680),background_color='#F6F7F8',text_select=True,zoomable=False)
    startup={'ready':False,'checking':False,'error':None,'deadline':None}
    startup_lock=threading.Lock()
    def attach_navigation_guard():
        if getattr(window,'_workspace_navigation_guard',None):return
        origin=urlparse(url)
        def guard(sender,args):
            target=urlparse(str(args.Uri))
            if target.scheme=='about' and target.path=='blank':return
            if target.scheme=='blob':
                blob_origin=urlparse(target.path)
                if (blob_origin.scheme,blob_origin.netloc)==(origin.scheme,origin.netloc):return
            if (target.scheme,target.netloc)==(origin.scheme,origin.netloc):return
            args.Cancel=True
            if bool(getattr(args,'IsUserInitiated',False)) and target.scheme in ('http','https'):
                import webbrowser
                webbrowser.open(str(args.Uri))
        from System import Action
        def register():window.native.browser.webview.NavigationStarting.__iadd__(guard)
        window.native.Invoke(Action(register))
        window._workspace_navigation_guard=guard
    renderer_state={'accepted':False}
    def check_renderer(renderer):
        renderer_state['accepted']=renderer=='edgechromium'
        return renderer_state['accepted']
    window.events.initialized+=check_renderer
    if owner_mode:
        def closing():
            # pywebview's locked closing Event maps False to FormClosing.Cancel.
            return stop_owned()
        def closed():
            if owner_mutex is not None:owner_mutex.native_closed(window)
            stop_owned()
        window.events.closing+=closing
        window.events.closed+=closed
    else:window.events.closed+=stop_owned
    def on_loaded():
        with startup_lock:
            if startup['ready'] or startup['checking'] or startup['error']:return
            startup['checking']=True
            if startup['deadline'] is not None:startup['deadline']=time.monotonic()+10
        try:
            if not renderer_state['accepted']:
                raise RuntimeError('需要 WebView2 桌面运行时，不使用旧浏览器替代')
            attach_navigation_guard()
            if ready_callback:ready_callback(window)
            with startup_lock:
                if startup['error']:return
                startup['ready']=True
                startup['checking']=False
        except Exception as error:
            with startup_lock:startup['error']=error;startup['checking']=False
            logging.exception('Native desktop readiness failed')
            try:window.destroy()
            except Exception:logging.exception('Could not close failed native window')
    window.events.loaded+=on_loaded
    server_thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.2},daemon=True)
    if owner_mutex is not None:owner_mutex.bind_desktop(window,server_thread)
    server_thread.start()
    if ready_callback and ready_timeout:startup['deadline']=time.monotonic()+ready_timeout
    def monitor():
        while not stopped:
            if startup['deadline'] is not None:
                with startup_lock:
                    timed_out=(not startup['ready'] and not startup['error']
                               and time.monotonic()>=startup['deadline'])
                    if timed_out:startup['error']=TimeoutError('原生窗口未在限定时间内完成加载，更新保持待恢复')
                if timed_out:
                    window._workspace_startup_cancelled=True
                    try:window.destroy()
                    except Exception:logging.exception('Could not close timed-out native window')
                    return
            if (server.closing and not owner_mode) or not server_thread.is_alive():
                try:window.destroy()
                except Exception:pass
                return
            time.sleep(.2)
    monitor_thread=threading.Thread(target=monitor,daemon=True)
    if owner_mutex is not None:owner_mutex.bind_monitor(monitor_thread)
    monitor_thread.start()
    try:
        resource_root=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
        icon=resource_root/'resources/brand.ico'
        if owner_mutex is not None:owner_mutex.native_creation_submitted(window)
        webview.start(gui='edgechromium',debug=False,private_mode=False,storage_path=str(Path(data_dir)/'webview2'),icon=str(icon) if icon.exists() else None)
        if startup['error']:raise startup['error']
        if not renderer_state['accepted']:raise RuntimeError('需要 WebView2 桌面运行时，不使用旧浏览器替代')
        if ready_callback and not startup['ready']:
            raise RuntimeError('原生窗口尚未完成加载，更新保持待恢复')
    finally:
        stop_owned();server_thread.join(timeout=6)
