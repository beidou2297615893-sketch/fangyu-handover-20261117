"""Explicit own Bili credential -> nav observation -> separate confirmed binding.

This host-only object grants no permission. Original host/session/component guards
remain required; file/UID persistence does not mark an account ready or clear risk.
"""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import re
import threading
import time

from bilibili_read_contract import owned_credential,project_owned_identity,_number
from .adapters import account_execution_lock,_BilibiliOwnedCleanupPending
from .bilibili_read import configured
from .service_plans import require_feature

class OwnedSetupError(ValueError):pass

def _need(condition,message='B站本人配置范围已变更，请重新核对'):
    if not condition:raise OwnedSetupError(message)

def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()

def _actor(value):
    # Business.principal refreshes _record.updated_at during routine polling.
    # Exclude only record timestamps; preserve every identity/permission field.
    return _digest({k:v for k,v in value.items() if k not in ('created_at','updated_at')})

def _account_identity(value):
    return _digest({k:value.get(k) for k in ('id','tenant_id','platform','cloud_owner','platform_uid')})

def _binding_id(tenant,account_id):
    return 'bili-owned-'+hashlib.sha256((tenant+'\n'+account_id).encode('utf-8')).hexdigest()

def confirmed_bilibili_binding(core,account,owner,device_id):
    """Private original confirmation facts, without component/GET permission.

    No request DTO or arbitrary login_required + hand-filled UID can establish
    this record. The caller must still run original actor/device/risk/feature,
    component policy and original GET/nav guards.
    """
    try:
        _need(type(account) is dict and account.get('platform')=='bilibili'
              and account.get('cloud_owner')==owner and type(device_id) is str and bool(device_id))
        tenant=account['tenant_id'];ident=_binding_id(tenant,account['id'])
        marker=core.store.get('bilibili_bindings',ident)
        fields={'id','tenant_id','account_id','actor_id','device_id','platform_uid','credential_sha256',
                'schema_version','route','purpose','setup_id','actor_digest','account_digest'}
        _need(type(marker) is dict and set(marker)==fields and marker['id']==ident and marker['tenant_id']==tenant
              and marker['account_id']==account['id'] and marker['device_id']==device_id
              and type(marker['schema_version']) is int and marker['schema_version']==1
              and marker['route']=='bilibili_fixed_read_v1' and marker['purpose']=='owned_credential_setup'
              and type(marker['setup_id']) is str and re.fullmatch(r'[0-9a-f]{32}',marker['setup_id'])
              and marker['platform_uid']==account.get('platform_uid') and marker['account_digest']==_account_identity(account))
        uid=marker['platform_uid'];_need(type(uid) is str and str(_number(uid))==uid)
        actor=core.store.get('users',marker['actor_id'])
        _need(actor is not None and actor.get('tenant_id')==tenant and actor.get('username')==owner
              and actor.get('cloud_bound') is True and not actor.get('disabled')
              and marker['actor_digest']==_actor(actor))
        core._account_access(actor,account)
        home=_plain(core.store.directory/'accounts'/tenant/account['id'])
        _need(not _plain(home/'.config/bilicli/workspace-binding-pending.json').exists())
        raw=_read(home/'.config/bilicli/cookies.json')
        _need(raw is not None and hashlib.sha256(raw).hexdigest()==marker['credential_sha256'])
        return {k:marker[k] for k in ('id','setup_id','platform_uid','actor_id','device_id','route','purpose')}
    except (ValueError,KeyError,TypeError,OSError):return None

def _plain(path):
    path=Path(path)
    for component in (path,*path.parents):
        if component.exists() and (component.is_symlink() or getattr(component.stat(),'st_file_attributes',0)&1024):
            raise OwnedSetupError('B站账号目录存在未核实的路径跳转')
    return path

def _read(path):
    path=_plain(path)
    if not path.exists():return None
    _need(path.is_file() and path.stat().st_size<=65536,'B站账号配置文件需人工核对')
    with path.open('rb') as handle:raw=handle.read(65537)
    _need(len(raw)<=65536)
    return raw

def _write(path,raw,owned=None):
    path=_plain(path);temporary=_plain(path.with_name(path.name+'.tmp'))
    # A fixed sibling, never an arbitrary destination or a caller-supplied path.
    _need(not temporary.exists(),'B站账号配置仍有未完成的文件操作')
    with temporary.open('xb') as handle:
        if owned is not None:
            stat=os.fstat(handle.fileno());owned[temporary]=(stat.st_dev,stat.st_ino)
        handle.write(raw);handle.flush();os.fsync(handle.fileno())
    os.replace(temporary,path)
    if owned is not None:owned[path]=owned.pop(temporary)

class BilibiliOwnedSetup:
    def __init__(self,core,tenant,owner,company,*,device_id,scope_guard,license_policy_provider):
        _need(all(type(x) is str and 1<=len(x)<=160 for x in (tenant,owner,device_id)))
        _need(type(company) is dict and callable(scope_guard) and callable(license_policy_provider))
        self.core,self.tenant,self.owner,self.company=core,tenant,owner,company
        self.device_id,self.scope_guard,self.license_policy_provider=device_id,scope_guard,license_policy_provider
        self.lock=threading.RLock();self.entries={};self.closed=False

    def _identity(self,user,account_id):
        _need(type(user) is dict and type(account_id) is str and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',account_id))
        current=self.core.store.get('users',user.get('id'))
        _need(current is not None and current.get('tenant_id')==self.tenant
              and current.get('username')==self.owner and not current.get('disabled')
              and all(user.get(k)==current.get(k) for k in ('id','tenant_id','username','cloud_bound'))
              and user.get('role') in ('admin','operator') and current.get('role') in ('admin','operator'))
        account=self.core._get('accounts',account_id,self.tenant)
        self.core._account_access(current,account)
        _need(account.get('platform')=='bilibili' and account.get('cloud_owner')==self.owner)
        return current,account

    def _check(self,user,account_id,entry=None):
        current,account=self._identity(user,account_id)
        _need(not self.closed and not self.core.adapters.closed)
        self.core.require_platform('bilibili');require_feature(self.company,'acquisition')
        # Opaque original host checks fresh executor/DeviceSession/device/lease.
        _need(self.scope_guard(current,account) is None,'B站当前本人会话未通过原门槛')
        policy=self.license_policy_provider()
        _need(type(policy) is dict and policy.get('bilibili') is True,'B站固定组件尚未完成当前用途审查')
        _need(configured(self.core.adapters.manifest('bilibili')),'B站固定只读工具尚未就绪')
        uid=account.get('platform_uid') or ''
        _need(type(uid) is str and (not uid or str(_number(uid))==uid))
        if entry is not None:
            _need(entry['actor_id']==current['id'] and entry['actor']==_actor(current)
                  and entry['device_id']==self.device_id and entry['account']==_digest(account)
                  and not entry['stop'].is_set() and time.monotonic()<entry['expires'])
        return current,account

    def _request(self,data,fields):
        _need(type(data) is dict and set(data)==set(fields))
        ident=data.get('setup_id');account_id=data.get('account_id')
        _need(type(ident) is str and re.fullmatch(r'[0-9a-f]{32}',ident)
              and type(account_id) is str and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',account_id))
        return ident,account_id

    def _entry(self,user,ident,account_id):
        # Read/cancel binding does not reacquire platform/component permission.
        current,_=self._identity(user,account_id)
        entry=self.entries.get(ident)
        _need(entry is not None and entry['account_id']==account_id and entry['actor_id']==current['id']
              and entry['device_id']==self.device_id,'B站本人配置编号不属于当前本人或设备')
        return entry

    def _dto(self,entry):
        return {'platform':'bilibili','purpose':'owned_credential_setup','account_id':entry['account_id'],
            'setup_id':entry['id'],'state':('observing' if entry['running'] and entry['state']=='pending_confirmation' else entry['state']),
            'observed_uid':entry.get('uid','') if not entry['running'] else '',
            'nickname':entry.get('nickname','') if not entry['running'] else '', 'credential_saved':entry.get('committed',False),
            'uid_saved':entry.get('committed',False),'account_ready':False,
            'cleanup_complete':not entry['running'] and entry.get('cleanup') is None,
            'worker_active':entry['running'],'auto_retry':False,'real_platform_verified':False}

    def _self(self,entry,expected_uid):
        _need(not entry['stop'].is_set())
        try:
            result=self.core.adapters.execute('bilibili',['self','--expected-uid',expected_uid],
                entry['home'],entry['job_id'],timeout=35,bilibili_credential_input=entry['credential'],
                bilibili_stop_event=entry['stop'])
        except _BilibiliOwnedCleanupPending as pending:
            # Keep the exact process, original outer account lock and this worker
            # until physical exit. Expired permission never prevents cleanup.
            with self.lock:entry['cleanup']=pending;entry['state']='cleanup_pending'
            while not pending.finish():time.sleep(0.2)
            with self.lock:entry['cleanup']=None
            raise OwnedSetupError('B站本人核对结果未确认，进程已安全收尾') from None
        try:return project_owned_identity(result,expected_uid)
        except ValueError:raise OwnedSetupError('B站本人身份未核实或与原UID不一致，本次未保存') from None

    def observe(self,user,data):
        ident,account_id=self._request(data,('account_id','setup_id','credential'))
        try:credential=owned_credential(data['credential'])
        except ValueError:raise OwnedSetupError('请提供本人专用B站凭据，格式或大小不符合要求') from None
        with self.core.lock:
            current,account=self._check(user,account_id)
            with self.lock:
                if ident in self.entries:
                    entry=self._entry(user,ident,account_id)
                    _need(entry['input']==hashlib.sha256(credential).hexdigest(),'同一配置编号不能替换凭据')
                    return self._dto(entry)
                _need(len(self.entries)<16,'本次服务的B站配置候选已达上限，请安全结束后重新打开助手')
                previous=self.core.store.get('bilibili_bindings',_binding_id(self.tenant,account_id))
                _need(not previous or previous.get('setup_id')!=ident,'此配置编号已保存，请使用新的配置编号')
                _need(not any(x['account_id']==account_id and (x['running'] or x['state']=='pending_confirmation')
                              for x in self.entries.values()),'此账号已有配置候选，请确认或取消后再开始')
                home=_plain(self.core.store.directory/'accounts'/self.tenant/account_id)
                entry={'id':ident,'account_id':account_id,'actor_id':current['id'],'actor':_actor(current),
                    'account':_digest(account),'device_id':self.device_id,'old_uid':account.get('platform_uid') or '',
                    'credential':credential,'input':hashlib.sha256(credential).hexdigest(),'home':home,
                    'job_id':'bili-owned-'+ident,'stop':threading.Event(),'expires':time.monotonic()+300,
                    'state':'observing','running':True,'cleanup':None,'committed':False}
                self.entries[ident]=entry
        try:
            with account_execution_lock(home):
                _need(not _plain(home/'.config/bilicli/workspace-binding-pending.json').exists(),
                      '此账号有未完成的配置保存，请先人工核对')
                with self.core.lock:self._check(user,account_id,entry)
                uid,nickname=self._self(entry,entry['old_uid'])
                with self.core.lock:
                    self._check(user,account_id,entry)
                    with self.lock:
                        _need(not entry['stop'].is_set())
                        entry.update(uid=uid,nickname=nickname,state='pending_confirmation')
        except Exception:
            with self.lock:
                entry['state']='cancelled' if entry['stop'].is_set() else 'failed';entry['credential']=None
            raise OwnedSetupError('B站本人核对未完成，本次未保存；不会自动重试') from None
        finally:
            with self.lock:entry['running']=False
        with self.lock:return self._dto(entry)

    def _cleanup_files(self,entry):
        cleanup=entry.get('cleanup')
        if not isinstance(cleanup,dict):return
        # Exact recorded paths only; every independent unlink is attempted.
        errors=[]
        # Leave the read-blocking journal until independent sibling cleanup is
        # confirmed. Do not delete a same-named file replaced by another owner.
        owned=cleanup['owned'];journal=cleanup['journal']
        for path,identity in list(owned.items()):
            if path==cleanup['cookie'] or path==journal:continue
            try:
                _plain(path)
                if path.exists():
                    stat=path.stat();_need((stat.st_dev,stat.st_ino)==identity)
                    path.unlink()
                owned.pop(path,None)
            except (OSError,OwnedSetupError):errors.append(path)
        if errors:raise OwnedSetupError('B站配置已收尾但文件清理尚待确认')
        if journal in owned:
            _plain(journal)
            if journal.exists():
                stat=journal.stat();_need((stat.st_dev,stat.st_ino)==owned[journal])
                journal.unlink()
            owned.pop(journal,None)
        entry['cleanup']=None

    def _persist(self,entry,account):
        directory=_plain(entry['home']/'.config/bilicli');directory.mkdir(parents=True,exist_ok=True)
        _plain(directory)
        cookie=_plain(directory/'cookies.json');journal=_plain(directory/'workspace-binding-pending.json')
        _need(not journal.exists(),'此账号有未完成的配置保存，请先人工核对')
        old=_read(cookie);backup=_plain(directory/('.setup-'+entry['id']+'-old.json'))
        _need(not backup.exists() and not any(p.with_name(p.name+'.tmp').exists() for p in (backup,journal,cookie)))
        marker={'id':_binding_id(self.tenant,entry['account_id']),'tenant_id':self.tenant,'account_id':entry['account_id'],
                'actor_id':entry['actor_id'],'device_id':self.device_id,'platform_uid':entry['uid'],
                'credential_sha256':entry['input'],'schema_version':1,'route':'bilibili_fixed_read_v1',
                'purpose':'owned_credential_setup','setup_id':entry['id'],'actor_digest':entry['actor'],
                'account_digest':_account_identity({**account,'platform_uid':entry['uid']})}
        owned={};entry['cleanup']={'owned':owned,'journal':journal,'cookie':cookie}
        wrote=False
        try:
            if old is not None:_write(backup,old,owned)
            _write(journal,json.dumps(marker,ensure_ascii=False,sort_keys=True).encode('utf-8'),owned)
            _write(cookie,entry['credential'],owned);wrote=True
            # Account and binding marker share the original Store transaction.
            self.core.store.put_records([('accounts',{**account,'platform_uid':entry['uid']}),('bilibili_bindings',marker)])
            entry['committed']=True
        except Exception:
            # A commit method may raise after SQLite actually committed. Check
            # its exact marker before deciding whether file rollback is correct.
            entry['cleanup']['uncertain_marker']=marker
            if wrote:entry['cleanup']['rollback']=(cookie,old,entry['credential'])
            try:committed=self.core.store.get('bilibili_bindings',marker['id'])==marker
            except Exception:raise OwnedSetupError('B站保存回执尚未确认，保留本次原材料待收尾') from None
            entry['cleanup'].pop('uncertain_marker',None)
            if committed:entry['committed']=True
            elif wrote:
                try:
                    _need(_read(cookie)==entry['credential'],'B站配置被外部修改，保留原回滚材料待核对')
                    if old is None:cookie.unlink()
                    else:_write(cookie,old,owned)
                except Exception:
                    entry['cleanup'].update(rollback=(cookie,old,entry['credential']))
                    raise OwnedSetupError('B站配置保存失败，回滚尚待确认，账号保持暂停') from None
            entry['cleanup'].pop('rollback',None)
            if not committed:
                self._cleanup_files(entry)
                raise OwnedSetupError('B站配置未保存，原文件已恢复') from None
        self._cleanup_files(entry)

    def _retry_files(self,entry):
        cleanup=entry.get('cleanup')
        if not isinstance(cleanup,dict):return
        with account_execution_lock(entry['home']):
            marker=cleanup.get('uncertain_marker')
            if marker is not None:
                if self.core.store.get('bilibili_bindings',marker['id'])==marker:
                    entry['committed']=True;cleanup.pop('rollback',None)
                cleanup.pop('uncertain_marker',None)
            rollback=cleanup.get('rollback')
            if rollback:
                cookie,old,new=rollback
                temporary=cookie.with_name(cookie.name+'.tmp')
                if temporary in cleanup['owned']:
                    _plain(temporary)
                    if temporary.exists():
                        stat=temporary.stat();_need((stat.st_dev,stat.st_ino)==cleanup['owned'][temporary])
                        temporary.unlink()
                    cleanup['owned'].pop(temporary,None)
                current=_read(cookie)
                _need(current in (old,new),'B站配置被外部修改，原回滚材料保留待人工核对')
                if current!=old:
                    if old is None:cookie.unlink()
                    else:_write(cookie,old,cleanup['owned'])
                cleanup.pop('rollback',None)
            self._cleanup_files(entry)

    def confirm(self,user,data):
        ident,account_id=self._request(data,('account_id','setup_id','observed_uid','confirmed'))
        _need(data['confirmed'] is True and type(data['observed_uid']) is str,'请明确确认本次观察到的本人UID')
        with self.core.lock:
            current,account=self._identity(user,account_id)
            with self.lock:
                entry=self._entry(user,ident,account_id)
                _need(data['observed_uid']==entry.get('uid'))
                if entry['committed']:
                    _need(entry['cleanup'] is None,'配置已保存，但文件清理仍待确认')
                    return self._dto(entry)
                self._check(user,account_id,entry)
                _need(not entry['running'] and entry['state']=='pending_confirmation')
                entry.update(running=True,state='confirming')
        try:
            with account_execution_lock(entry['home']):
                cookie=entry['home']/'.config/bilicli/cookies.json';old=_read(cookie)
                with self.core.lock:self._check(user,account_id,entry)
                uid,nickname=self._self(entry,entry['uid'])
                with self.core.lock:
                    _,account=self._check(user,account_id,entry)
                    with self.core.adapters.lifecycle_lock:
                        with self.lock:
                            _need(not entry['stop'].is_set() and not self.closed and not self.core.adapters.closed)
                            _need(uid==entry['uid'] and _read(cookie)==old)
                            _need(not any(a['id']!=account_id and a.get('platform')=='bilibili'
                                          and a.get('platform_uid')==uid for a in self.core.store.list('accounts',self.tenant)),
                                  '此B站UID已绑定本企业另一个账号，请先核对')
                            self._persist(entry,account)
                            entry.update(state='saved',nickname=nickname)
        except Exception:
            with self.lock:
                entry['state']='cleanup_pending' if entry['cleanup'] is not None else (
                    'saved' if entry['committed'] else 'cancelled' if entry['stop'].is_set() else 'failed')
            raise OwnedSetupError('B站配置未完整完成，请查看本次状态；不会自动重试') from None
        finally:
            with self.lock:
                entry['running']=False;entry['credential']=None
        with self.lock:return self._dto(entry)

    def status(self,user,data):
        ident,account_id=self._request(data,('account_id','setup_id'))
        with self.core.lock:
            with self.lock:entry=self._entry(user,ident,account_id)
        if not entry['running'] and isinstance(entry['cleanup'],dict):
            self._retry_files(entry)
            with self.lock:entry['state']='saved' if entry['committed'] else 'cancelled' if entry['stop'].is_set() else 'failed'
        with self.lock:return self._dto(entry)

    def _cancel(self,entry):
        with self.core.adapters.lifecycle_lock:
            with self.lock:
                entry['stop'].set()
                if not entry['running']:
                    entry['credential']=None
                    if not entry['committed']:entry['state']='cancelled'
        self.core.adapters.cancel(entry['job_id'])
        if not entry['running'] and isinstance(entry['cleanup'],dict):
            self._retry_files(entry)
            with self.lock:entry['state']='saved' if entry['committed'] else 'cancelled'

    def cancel(self,user,data):
        ident,account_id=self._request(data,('account_id','setup_id'))
        with self.core.lock:
            with self.lock:entry=self._entry(user,ident,account_id)
            self._cancel(entry)
        with self.lock:return self._dto(entry)

    def close(self):
        with self.lock:self.closed=True;entries=list(self.entries.values())
        errors=[]
        for entry in entries:
            try:self._cancel(entry)
            except Exception:errors.append(entry['id'])
        return {'closed':True,'cleanup_complete':not errors and not any(x['running'] for x in entries)}
