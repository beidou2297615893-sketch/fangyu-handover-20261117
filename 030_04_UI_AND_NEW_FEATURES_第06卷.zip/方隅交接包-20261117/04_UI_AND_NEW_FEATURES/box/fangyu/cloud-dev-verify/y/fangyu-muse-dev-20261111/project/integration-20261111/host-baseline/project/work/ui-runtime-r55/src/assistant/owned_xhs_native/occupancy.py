"""Candidate RAM-only owner evidence adapter. No host or account integration.

Providers are internal fixed snapshot / current TokenUser readers, never HTTP
input. The raw WMI snapshot is not modified or persisted. Missing owner is the
only field that may be derived from this call's native current-user evidence.
"""
import copy
import hashlib
import json
from pathlib import Path
import re


from . import owner as OWNER, classifier as FROZEN

_PINNED = (('owner.py', '9770E5721A705F5B53ED0DCF859E192B15DE21A9235A6F6049D0868A26B0055F'), ('classifier.py', '96F8F0D3FD7BBBDDCB78FEEC44254CD4B42D2A8D31A1BA171603AAFDED6F50D3'))


def _frozen_valid():
    folder = Path(__file__).resolve().parent
    return all(hashlib.sha256((folder / name).read_bytes()).hexdigest().upper() == expected
               for name, expected in _PINNED)

_OWNER_FIELDS = {'contract', 'state', 'reason', 'owner_current', 'wmi_owner_agrees',
                 'creation_verified', 'running_before', 'running_after',
                 'token_user_verified', 'handles_closed', 'evidence_hash'}
_ROW_BINDING = ('pid', 'parent_pid', 'created', 'name', 'executable', 'command_line')


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


class _EvidenceError(ValueError):
    pass


class NativeOwnerOccupancyAdapter:
    def __init__(self, resolver=None):
        self.resolver = OWNER.NativeOwnerResolver() if resolver is None else resolver
        if not isinstance(self.resolver, OWNER.NativeOwnerResolver):
            raise ValueError('owner_evidence_unavailable')

    @staticmethod
    def _snapshot(value, current_sid):
        fields = {'current_sid', 'processes', 'complete', 'default_profiles'}
        if (not isinstance(value, dict) or set(value) not in (fields, fields - {'default_profiles'})
                or value['complete'] is not True or value['current_sid'] != current_sid
                or not isinstance(value['processes'], list) or len(value['processes']) > 4096):
            raise _EvidenceError('owner_snapshot_unavailable')
        # Copy immediately: providers cannot later mutate the first snapshot.
        snapshot = copy.deepcopy(value)
        rows = {}
        for row in snapshot['processes']:
            if (not isinstance(row, dict) or set(row) != FROZEN._FIELDS
                    or type(row['pid']) is not int or not 1 <= row['pid'] <= 0xffffffff
                    or row['pid'] in rows or type(row['parent_pid']) is not int or row['parent_pid'] < 0
                    or type(row['created']) is not int or row['created'] <= 0
                    or not isinstance(row['name'], str) or not row['name']
                    or not isinstance(row['executable'], str) or not row['executable']
                    or not isinstance(row['command_line'], str) or not row['command_line']
                    or (row['owner_sid'] is not None and not OWNER.valid_sid(row['owner_sid']))):
                raise _EvidenceError('owner_snapshot_unavailable')
            rows[row['pid']] = row
        return snapshot, rows

    def _resolve(self, row, current_sid):
        value = self.resolver.resolve(row['pid'], row['created'], current_sid=current_sid,
                                      wmi_sid=row['owner_sid'])
        if (not isinstance(value, dict) or set(value) != _OWNER_FIELDS
                or value['contract'] != 'process_token_user_evidence_v1'
                or value['state'] != 'verified' or value['reason'] != 'verified'
                or any(value[key] is not True for key in ('owner_current', 'creation_verified',
                    'running_before', 'running_after', 'token_user_verified', 'handles_closed'))
                or value['wmi_owner_agrees'] is not (None if row['owner_sid'] is None else True)
                or not isinstance(value['evidence_hash'], str)
                or re.fullmatch('[0-9a-f]{64}', value['evidence_hash']) is None):
            raise _EvidenceError('owner_evidence_unavailable')
        return value['evidence_hash']

    def classify(self, profile, *, snapshot_provider, current_sid_provider,
                 owned=None, expected_browser=None, trusted_python=None, owned_context=None):
        """Classify two fresh complete snapshots; never cache owner evidence.

        If a first fallback row disappears or changes identity/parent/argv,
        return unknown. Last snapshot still classifies every other row using
        the frozen profile / exe / Job fences. Unrelated row count may change.
        """
        counts = dict(source='incomplete', token_user_rows_verified=0,
                      complete_snapshots_checked=0, token_user_evidence_stable=None,
                      raw_metadata_saved=False)
        result = dict(contract='native_owner_occupancy_evidence_v1', state='unknown',
                      reason='owner_evidence_unavailable', fingerprint=None, owner_evidence=counts)
        first = last = first_rows = last_rows = derived = evidence = current_sid = None
        added_evidence = {}
        try:
            if not callable(snapshot_provider) or not callable(current_sid_provider):
                raise _EvidenceError('owner_evidence_unavailable')
            if not _frozen_valid():
                raise _EvidenceError('owner_frozen_source_changed')
            current_sid = current_sid_provider()
            if not OWNER.valid_sid(current_sid):
                raise _EvidenceError('owner_principal_changed')
            value = snapshot_provider()
            if current_sid_provider() != current_sid:
                raise _EvidenceError('owner_principal_changed')
            first, first_rows = self._snapshot(value, current_sid)
            value = None
            counts['complete_snapshots_checked'] = 1
            evidence = {}
            derived = copy.deepcopy(first)
            for row in derived['processes']:
                if row['owner_sid'] is None:
                    evidence[row['pid']] = self._resolve(first_rows[row['pid']], current_sid)
                    row['owner_sid'] = current_sid  # native evidence, never represented as WMI
            initial = FROZEN.classify(derived, profile, owned=owned,
                expected_browser=expected_browser, trusted_python=trusted_python)
            if initial['state'] not in ('vacant', 'occupied', 'unknown'):
                raise _EvidenceError('owner_evidence_unavailable')
            # A first blocked classification cannot be relaxed by a later page.
            if initial['state'] != 'vacant':
                result.update(state=initial['state'], reason=initial['reason'])
                return result
            value = snapshot_provider()
            if current_sid_provider() != current_sid:
                raise _EvidenceError('owner_principal_changed')
            last, last_rows = self._snapshot(value, current_sid)
            value = None
            counts['complete_snapshots_checked'] = 2
            # First repaired identity must still be observable; missing does not
            # mean the former process exited safely or the target became vacant.
            for pid, previous_hash in evidence.items():
                before, after = first_rows[pid], last_rows.get(pid)
                if (after is None or any(after[key] != before[key] for key in _ROW_BINDING)
                        or after['owner_sid'] not in (None, current_sid)):
                    raise _EvidenceError('owner_row_changed')
                if self._resolve(after, current_sid) != previous_hash:
                    raise _EvidenceError('owner_evidence_changed')
            added_rows = [row for row in last_rows.values()
                          if row['owner_sid'] is None and row['pid'] not in evidence]
            if added_rows:
                from .ready import _ReadyGuard
                if type(owned_context) is not _ReadyGuard:
                    raise _EvidenceError('owner_row_changed')
                for row in added_rows:
                    # Port only the reviewed owned-added mechanical algorithm.
                    # No diagnostic host, TLS, QA capability or cached SID map.
                    if row['pid'] in first_rows or not owned_context.validate():
                        raise _EvidenceError('owner_row_changed')
                    proof = self._resolve(row, current_sid)
                    owned_context.contains(row['pid'], row['created'])
                    if self._resolve(row, current_sid) != proof:
                        raise _EvidenceError('owner_evidence_changed')
                    owned_context.contains(row['pid'], row['created'])
                    added_evidence[row['pid']] = proof
            derived = copy.deepcopy(last)
            for row in derived['processes']:
                if row['owner_sid'] is None:
                    row['owner_sid'] = current_sid
            final = FROZEN.classify(derived, profile, owned=owned,
                expected_browser=expected_browser, trusted_python=trusted_python)
            if current_sid_provider() != current_sid:
                raise _EvidenceError('owner_principal_changed')
            if not _frozen_valid():
                raise _EvidenceError('owner_frozen_source_changed')
            if final['state'] not in ('vacant', 'occupied', 'unknown'):
                raise _EvidenceError('owner_evidence_unavailable')
            if owned_context is not None and not owned_context.validate():
                raise _EvidenceError('owner_evidence_unavailable')
            counts.update(source='wmi_and_token_user' if evidence else 'wmi_only',
                          token_user_rows_verified=len(evidence),
                          token_user_evidence_stable=True if evidence else None)
            result.update(state=final['state'], reason=final['reason'],
                fingerprint=_hash(['native_owner_occupancy_v1', final['fingerprint'],
                    [[pid, first_rows[pid]['created'], first_rows[pid]['parent_pid'], evidence[pid]]
                     for pid in sorted(evidence)]]))
            if added_evidence:
                result['fingerprint'] = _hash([result['fingerprint'],
                    'exact_owned_added_native_v1', [[pid, last_rows[pid]['created'],
                    last_rows[pid]['parent_pid'], added_evidence[pid]]
                    for pid in sorted(added_evidence)]])
            return result
        except _EvidenceError as error:
            result.update(state='unknown', reason=str(error), fingerprint=None)
            return result
        except Exception:
            result.update(state='unknown', reason='owner_evidence_unavailable', fingerprint=None)
            return result
        finally:
            # No cross-call cache, shared owner map, raw metadata receipt or IO.
            first = last = first_rows = last_rows = derived = evidence = current_sid = None
            added_evidence = None
