"""Pre-resume mechanics plus a private reviewed page provider boundary.

The App context proves provenance, not page-route licence approval. There is
no positive component policy by default; a complete private page review is
required before this provider returns its actual owned Native factory.
Private mechanical recordings may exercise _PreResumeGuard without making
that recording a production authority or WebView loaded-runtime proof.
"""
import os
from pathlib import Path
import secrets
import threading

from core.adapters import AdapterSafetyRequired
from assistant.owned_helper_process import OwnedHelperCommand, page_helper_argv
import assistant.owned_helper_process as helper_builder
import assistant.owned_native_job as job_source
from .classifier import TrustedCurrentPython
from .image import NativeProcessImageBinding
from .runtime_materials import current_token_user, digest


class _PreResumeGuard:
    """Only this fixed private type is accepted by the Job's optional seam."""
    def __init__(self, scope, spec_path, *, binding=None, image=None, decision=None):
        from assistant.xhs_batch_scope import _BatchScope
        from assistant.xhs_identity_scope import _IdentityScope
        from assistant.xhs_session_scope import _SessionScope
        from xhs_page_window import load_spec
        if type(scope) not in (_BatchScope, _IdentityScope, _SessionScope):
            raise AdapterSafetyRequired('page_creation_scope_unavailable')
        scope.check()
        spec_path = Path(spec_path)
        spec = load_spec(spec_path)
        if (spec_path.parent.parent.parent.parent.resolve() != scope.root
                or spec.tenant_id != scope.tenant or spec.account_id != scope.account_id
                or spec.profile_dir != scope.root / 'xhs-browser-profile'):
            raise AdapterSafetyRequired('page_creation_spec_changed')
        self.scope, self.thread, self.spec_path = scope, threading.current_thread(), spec_path
        from assistant.customer_natural_materials import _PortableHelperBinding
        portable = getattr(decision,'customer',None) is not None
        self.binding = (_PortableHelperBinding(decision) if portable else TrustedCurrentPython()) if binding is None else binding
        self.command = self.binding.command(spec_path,spec.profile_dir) if portable else page_helper_argv(spec_path,spec.profile_dir)
        self.image = NativeProcessImageBinding() if image is None else image
        if (type(self.binding) not in (TrustedCurrentPython, _PortableHelperBinding)
                or type(self.image) is not NativeProcessImageBinding):
            raise AdapterSafetyRequired('page_creation_material_unavailable')
        self.spec_hash = digest(spec_path)
        # Fixed source helpers only; frozen material remains held above.
        source = Path(self.command.argv[0] if portable else self.command.argv[1])
        self.source, self.source_hash = source, digest(source)
        self._sources = {path: digest(path) for path in (
            Path(__file__), Path(__file__).with_name('runtime_materials.py'),
            Path(__file__).with_name('owner.py'), Path(__file__).with_name('classifier.py'),
            Path(__file__).with_name('image.py'), Path(job_source.__file__),
            Path(helper_builder.__file__))}
        # Exact current creation environment, with inherited Python/WebView
        # override variables removed. This is not proof of future DLL loads.
        self._environment = self._environment_now()
        self.sid = current_token_user()
        self.nonce = secrets.token_hex(16)
        self.called = False
        self.image_evidence = None  # RAM-only metadata; never licence/loaded DLL proof.
        self._verified_process = None
        self._verified_handles = None
        self._resume_submitted = False

    @staticmethod
    def _environment_now():
        value = dict(os.environ)
        for key in ('PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONINSPECT', 'PYTHONPATH',
                    'WEBVIEW2_USER_DATA_FOLDER', 'WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS',
                    'WEBVIEW2_WAIT_FOR_SCRIPT_DEBUGGER', 'WEBVIEW2_PIPE_FOR_SCRIPT_DEBUGGER',
                    'WEBVIEW2_BROWSER_EXECUTABLE_FOLDER'):
            value.pop(key, None)
        value['PYTHONDONTWRITEBYTECODE'] = '1'
        return value

    @property
    def environment(self):
        return dict(self._environment)

    def _check(self, command, environment):
        if (threading.current_thread() is not self.thread or self.scope.finished
                or type(command) is not OwnedHelperCommand or command != self.command
                or digest(self.spec_path) != self.spec_hash
                or digest(self.source) != self.source_hash
                or any(digest(path) != expected for path, expected in self._sources.items())
                or type(environment) is not dict or environment != self._environment
                or self._environment_now() != self._environment
                or current_token_user() != self.sid or not self.binding.validate()):
            raise AdapterSafetyRequired('page_creation_material_changed')
        self.scope.check()

    def verify(self, process, command, environment):
        from assistant.owned_native_job import WindowsOwnedJobProcess, OwnedJobError
        if (self.called or type(process) is not WindowsOwnedJobProcess
                or process.closed or process.resumed
                or process.process is None or process.job is None):
            raise OwnedJobError('owned_binding_unconfirmed')
        self.called = True
        retained = (process.process, process.job, process.pid)
        self._check(command, environment)
        proof = self.image._capture_owned(process.process, process.pid,
            job_handle=process.job, creation_spec={'application_name':command.argv[0],
                'argv':list(command.argv), 'cwd':command.cwd, 'run_nonce':self.nonce},
            current_sid_provider=current_token_user, runtime_binding=self.binding)
        if ((process.process, process.job, process.pid) != retained
                or proof.get('state') != 'verified' or proof.get('reason') != 'verified'
                or any(proof.get(key) is not True for key in (
                    'owner_current', 'creation_verified', 'running_before', 'running_after',
                    'pid_stable', 'native_image_stable', 'fixed_runtime_matches',
                    'job_membership_verified', 'token_user_verified', 'handles_closed'))
                or proof.get('native_loaded_bytes_verified') is not False
                or proof.get('profile_vacancy_verified') is not False):
            raise OwnedJobError('owned_binding_unconfirmed')
        self._check(command, environment)
        self.image_evidence = proof
        self._verified_process = process
        self._verified_handles = retained

    def resume(self, process, thread_handle, command, environment):
        from assistant.owned_native_job import WindowsOwnedJobProcess, OwnedJobError
        # Native/image and file material reads happened outside these locks.
        # Cancellation uses this same original Core -> runtime order. Make its
        # exact-scope signal and this one ResumeThread submission atomic.
        self._check(command, environment)
        with self.scope.runtime.core.lock:
            with self.scope.runtime.lock:
                if (not self.called or self.image_evidence is None or self._resume_submitted
                        or type(process) is not WindowsOwnedJobProcess
                        or self._verified_process is not process
                        or (process.process, process.job, process.pid) != self._verified_handles
                        or process.closed or process.resumed
                        or process.process is None or process.job is None
                        or threading.current_thread() is not self.thread
                        or command != self.command or environment != self._environment):
                    raise OwnedJobError('owned_binding_unconfirmed')
                self.scope.check()
                self._resume_submitted = True
                return process.kernel.ResumeThread(thread_handle)


class OwnedXhsNativeProvider:
    """Prepared App boundary; a missing/new/CLI policy cannot launch anything."""
    def __init__(self, server, *, page_policy=None, identity_policy=None, session_policy=None):
        self._server, self._page_policy = server, page_policy
        self._identity_policy = identity_policy
        self._session_policy = session_policy

    @property
    def session_factory(self):
        from assistant.xhs_session_policy import XhsSessionRecoveryPolicy, _SessionRecoveryDecision
        if (type(self._session_policy) is not XhsSessionRecoveryPolicy
                or self._session_policy is not getattr(self._server,'_xhs_session_policy',None)):
            return None
        decision=self._session_policy.resolve()
        return self if type(decision) is _SessionRecoveryDecision and decision.policy is self._session_policy else None

    @property
    def identity_factory(self):
        from assistant.xhs_identity_policy import XhsIdentityObservationPolicy, _IdentityObservationDecision
        if (type(self._identity_policy) is not XhsIdentityObservationPolicy
                or self._identity_policy is not getattr(self._server, '_xhs_identity_policy', None)):
            return None
        decision = self._identity_policy.resolve()
        return self if type(decision) is _IdentityObservationDecision and decision.policy is self._identity_policy else None

    @property
    def factory(self):
        if self._page_policy is None:
            return None
        from assistant.xhs_page_read_policy import XhsPageReadPolicy, _PageReadDecision
        if (type(self._page_policy) is not XhsPageReadPolicy
                or self._page_policy is not getattr(self._server, '_xhs_page_read_policy', None)):
            return None
        decision = self._page_policy.resolve()
        return self if type(decision) is _PageReadDecision and decision.policy is self._page_policy else None

    def __call__(self, spec_path, *, owned_scope=None):
        from assistant.xhs_batch_scope import _BatchScope
        from assistant.xhs_app_context import _AppExecutionContext
        from assistant.xhs_identity_scope import _IdentityScope
        from assistant.xhs_session_scope import _SessionScope
        from assistant.xhs_identity_context import _IdentityExecutionContext
        identity = type(owned_scope) is _IdentityScope
        session = type(owned_scope) is _SessionScope
        from assistant.xhs_session_context import _SessionExecutionContext
        if (type(owned_scope) not in (_BatchScope, _IdentityScope, _SessionScope)
                or owned_scope.runtime.core is not self._server.core
                or type(getattr(owned_scope, 'app_context', None)) is not
                    (_SessionExecutionContext if session else _IdentityExecutionContext if identity else _AppExecutionContext)):
            raise AdapterSafetyRequired('page_app_context_unavailable')
        owned_scope.check()
        from assistant.xhs_page_read_policy import XhsPageReadPolicy, _PageReadDecision
        from assistant.owned_native_job import WindowsOwnedJobProcess, OwnedSetupPending
        from xhs_page_window import load_spec
        from .ready import _ReadyGuard
        if session:
            from assistant.xhs_session_policy import XhsSessionRecoveryPolicy, _SessionRecoveryDecision
            policy,decision_type,factory=self._session_policy,_SessionRecoveryDecision,self.session_factory
            if type(policy) is not XhsSessionRecoveryPolicy:
                raise AdapterSafetyRequired('session_component_review_unavailable')
        elif identity:
            from assistant.xhs_identity_policy import XhsIdentityObservationPolicy, _IdentityObservationDecision
            policy, decision_type, factory = self._identity_policy, _IdentityObservationDecision, self.identity_factory
            if type(policy) is not XhsIdentityObservationPolicy:
                raise AdapterSafetyRequired('identity_component_review_unavailable')
        else:
            policy, decision_type, factory = self._page_policy, _PageReadDecision, self.factory
            if type(policy) is not XhsPageReadPolicy:
                raise AdapterSafetyRequired('page_component_review_unavailable')
        if factory is not self:
            raise AdapterSafetyRequired('page_component_review_unavailable')
        decision = policy.resolve()
        spec = load_spec(Path(spec_path))
        if (type(decision) is not decision_type or decision.policy is not policy
                or spec.read_mode != 'natural'
                or spec.purpose != ('session_recovery' if session else 'identity_observation' if identity else 'collection_read')):
            raise AdapterSafetyRequired('page_component_review_unavailable')
        decision.check(owned_scope, spec, owned_scope.app_context)
        pre_resume = _PreResumeGuard(owned_scope, spec_path, decision=decision)
        ready = _ReadyGuard(self._server, decision, owned_scope, spec, pre_resume)
        try:
            process = WindowsOwnedJobProcess(pre_resume.command,
                environment=pre_resume.environment, _before_resume=pre_resume)
        except OwnedSetupPending as error:
            ready.bind(error.process)
            raise
        except Exception:
            ready.abort_before_process()
            raise
        ready.bind(process)
        return process
