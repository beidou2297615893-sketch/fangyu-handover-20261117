"""Offline wording hints only. No storage, model, authentication or sending."""
from pathlib import Path
import hashlib,types

UPSTREAM_SHA256='d384550177c78dde10824866092f3fdfec7135ef22fe428b49e359917eaa420c'
PROVENANCE={'repo':'xintu1314/xhs-creator-suite','commit':'babb659a96af4d8886b8f343ee8c3c3c32a66656',
    'path':'xhs-publish-guard/scripts/check_copy.py','license':'MIT','sha256':UPSTREAM_SHA256}

def review_saved_wording(text):
    if not isinstance(text,str) or not text.strip():
        return None
    if len(text)>5000:
        return {'status':'unavailable','eligibleForSend':False,'flags':[]}
    try:
        source=Path(__file__).parent/'_vendor_wording/check_copy.py'
        code=source.read_bytes()
        if hashlib.sha256(code).hexdigest()!=UPSTREAM_SHA256:
            raise ValueError('component changed')
        module=types.ModuleType('pinned_reply_wording')
        module.__file__=str(source)
        exec(compile(code,str(source),'exec'),module.__dict__)
        hits=module.inspect(text,note_format=None)['flags']
        return {'status':'review_required' if hits else 'no_rule_hits',
            'eligibleForSend':False,'flags':[{'category':r['category'],'phrase':r['phrase']} for r in hits[:20]],
            'textSha256':hashlib.sha256(text.encode('utf-8')).hexdigest(),'provenance':dict(PROVENANCE)}
    except (OSError,ValueError,KeyError,TypeError):
        # Hints must never prevent reading or saving a valid original draft.
        return {'status':'unavailable','eligibleForSend':False,'flags':[]}
