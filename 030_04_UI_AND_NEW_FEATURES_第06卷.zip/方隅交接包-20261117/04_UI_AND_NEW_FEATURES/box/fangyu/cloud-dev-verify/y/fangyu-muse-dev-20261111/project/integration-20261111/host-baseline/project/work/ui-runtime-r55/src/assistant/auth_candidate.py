"""Offline-only candidate policy for one newly created login window.

This module does not import the vendor CLI, read a browser profile, access the
network, or write credentials. It deliberately has no persistence function.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from http.cookies import SimpleCookie
from urllib.parse import urlsplit


# Mirrored from the pinned xiaohongshu-cli 0.6.4 qr_login.py allowlist.
XHS_COOKIE_NAMES = frozenset({
    "a1", "webId", "web_session", "web_session_sec", "id_token",
    "websectiga", "sec_poison_id", "xsecappid", "gid",
    "abRequestId", "webBuild", "loadts",
})
XHS_REQUIRED_NAMES = frozenset({"a1", "webId", "web_session"})
MAX_COOKIE_VALUE_BYTES = 8192
MAX_TOTAL_COOKIE_BYTES = 32768


class CandidateRejected(Exception):
    """Fixed, credential-free failure code only."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True, repr=False)
class OwnedCookie:
    """Cookie from this window's native manager; never repr the secret value."""

    name: str
    value: str
    domain: str
    path: str
    secure: bool
    httponly: bool
    is_session: bool
    expires: str

    def __repr__(self) -> str:
        return f"OwnedCookie(name={self.name!r}, value=<redacted>)"


def _hostname(url: str, scheme: str) -> str:
    try:
        parsed = urlsplit(url)
        host = parsed.hostname
        port = parsed.port
    except (TypeError, ValueError):
        raise CandidateRejected("origin_invalid") from None
    if parsed.scheme != scheme or not host or parsed.username or parsed.password:
        raise CandidateRejected("origin_invalid")
    if scheme == "https" and port not in (None, 443):
        raise CandidateRejected("origin_invalid")
    return host.lower()


def _cookie_expired(expires: str, now: datetime) -> bool:
    if not expires:
        return False
    try:
        expiry = parsedate_to_datetime(expires)
    except (TypeError, ValueError, OverflowError):
        raise CandidateRejected("cookie_expiry_invalid") from None
    if expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=timezone.utc)
    return expiry <= now


def extract_scoped_cookies(
    raw: list[SimpleCookie | OwnedCookie], *, current_url: str, expected_host: str,
    scheme: str, allowed_names: frozenset[str], required_names: frozenset[str],
    allowed_cookie_domains: frozenset[str], now: datetime | None = None,
    require_secure_flag: bool = True,
) -> dict[str, str]:
    """Read only allowed cookies for the exact newly opened window origin.

    The caller must own ``raw`` from that window's ``get_cookies()``. The
    function cannot prove the provenance of an arbitrary passed-in list.
    """
    host = _hostname(current_url, scheme)
    if host != expected_host.lower():
        raise CandidateRejected("origin_mismatch")
    now = now or datetime.now(timezone.utc)
    found: dict[str, str] = {}
    total = 0
    for cookie in raw:
        if isinstance(cookie, OwnedCookie):
            entries = [(cookie.name, cookie.value, cookie.domain, cookie.secure,
                        cookie.expires, cookie.is_session)]
        elif isinstance(cookie, SimpleCookie):
            entries = [(name, morsel.value, morsel["domain"], bool(morsel["secure"]),
                        morsel["expires"], not bool(morsel["expires"]))
                       for name, morsel in cookie.items()]
        else:
            raise CandidateRejected("cookie_shape_invalid")
        for name, value, raw_domain, secure, expires, is_session in entries:
            if name not in allowed_names:
                continue
            if (not isinstance(value, str) or not isinstance(raw_domain, str)
                    or type(secure) is not bool or type(is_session) is not bool):
                raise CandidateRejected("cookie_shape_invalid")
            domain = raw_domain.lower().lstrip(".")
            if domain not in allowed_cookie_domains:
                raise CandidateRejected("cookie_domain_mismatch")
            if scheme == "https" and require_secure_flag and not secure:
                raise CandidateRejected("cookie_not_secure")
            if not value or name in found:
                raise CandidateRejected("cookie_duplicate_or_empty")
            size = len(value.encode("utf-8"))
            if size > MAX_COOKIE_VALUE_BYTES:
                raise CandidateRejected("cookie_oversize")
            total += size
            if total > MAX_TOTAL_COOKIE_BYTES:
                raise CandidateRejected("cookies_oversize")
            if not is_session:
                if not isinstance(expires, str) or not expires:
                    raise CandidateRejected("cookie_expiry_missing")
                if _cookie_expired(expires, now):
                    raise CandidateRejected("cookie_expired")
            found[name] = value
    if not required_names.issubset(found):
        raise CandidateRejected("cookie_missing")
    return found


def extract_xhs_candidate(raw: list[SimpleCookie | OwnedCookie], *, current_url: str) -> dict[str, str]:
    """Candidate only; no account-directory write or platform request."""
    return extract_scoped_cookies(
        raw, current_url=current_url, expected_host="www.xiaohongshu.com",
        scheme="https", allowed_names=XHS_COOKIE_NAMES,
        required_names=XHS_REQUIRED_NAMES,
        allowed_cookie_domains=frozenset({"xiaohongshu.com", "www.xiaohongshu.com"}),
        # HTTPS origin is required above. Secure is a transmission attribute,
        # not proof of authentication: the pinned CLI exports both variants.
        require_secure_flag=False,
    )


class CandidateSession:
    """In-memory two-source identity gate, with no persistence capability."""

    def __init__(self, bound_uid: str | None):
        self._bound_uid = bound_uid.strip() if isinstance(bound_uid, str) else ""
        self._cookies: dict[str, str] | None = None
        self._browser_uid = ""
        self._cli_uid = ""
        self._state = "new"

    def __repr__(self) -> str:
        return f"CandidateSession(state={self._state!r})"

    @property
    def state(self) -> str:
        return self._state

    def capture(self, cookies: dict[str, str]) -> None:
        if self._state != "new":
            raise CandidateRejected("state_invalid")
        if not isinstance(cookies, dict):
            raise CandidateRejected("cookie_shape_invalid")
        if not XHS_REQUIRED_NAMES.issubset(cookies):
            raise CandidateRejected("cookie_missing")
        if not set(cookies).issubset(XHS_COOKIE_NAMES):
            raise CandidateRejected("cookie_name_invalid")
        total = 0
        for value in cookies.values():
            if not isinstance(value, str) or not value:
                raise CandidateRejected("cookie_shape_invalid")
            size = len(value.encode("utf-8"))
            total += size
            if size > MAX_COOKIE_VALUE_BYTES or total > MAX_TOTAL_COOKIE_BYTES:
                raise CandidateRejected("cookie_oversize")
        self._cookies = dict(cookies)
        self._state = "captured"

    @staticmethod
    def _check_identity(*, authenticated: bool, guest: bool, uid: str,
                        verification_required: bool, expires_at: datetime | None) -> str:
        if (type(authenticated) is not bool or type(guest) is not bool
                or type(verification_required) is not bool):
            raise CandidateRejected("identity_fact_invalid")
        if verification_required:
            raise CandidateRejected("verification_required")
        if expires_at is not None:
            if not isinstance(expires_at, datetime) or expires_at.tzinfo is None:
                raise CandidateRejected("identity_expiry_invalid")
            if expires_at <= datetime.now(timezone.utc):
                raise CandidateRejected("identity_expired")
        if not authenticated or guest:
            raise CandidateRejected("identity_guest")
        normalized = uid.strip() if isinstance(uid, str) else ""
        if not normalized or len(normalized) > 128:
            raise CandidateRejected("identity_missing")
        return normalized

    def browser_identity(self, *, authenticated: bool, guest: bool, uid: str,
                         verification_required: bool = False,
                         expires_at: datetime | None = None) -> None:
        if self._state != "captured":
            raise CandidateRejected("state_invalid")
        try:
            confirmed = self._check_identity(authenticated=authenticated, guest=guest, uid=uid,
                                             verification_required=verification_required,
                                             expires_at=expires_at)
            if self._bound_uid and confirmed != self._bound_uid:
                raise CandidateRejected("identity_mismatch")
        except CandidateRejected:
            self.discard()
            raise
        self._browser_uid = confirmed
        self._state = "browser_verified"

    def cli_identity(self, *, authenticated: bool, guest: bool, uid: str,
                     verification_required: bool = False,
                     expires_at: datetime | None = None) -> None:
        if self._state != "browser_verified":
            raise CandidateRejected("state_invalid")
        try:
            confirmed = self._check_identity(authenticated=authenticated, guest=guest, uid=uid,
                                             verification_required=verification_required,
                                             expires_at=expires_at)
            if confirmed != self._browser_uid:
                raise CandidateRejected("identity_mismatch")
        except CandidateRejected:
            self.discard()
            raise
        self._cli_uid = confirmed
        self._state = "ready_for_existing_account_check"

    def verified_cookie_copy(self) -> dict[str, str]:
        if self._state != "ready_for_existing_account_check" or self._cookies is None:
            raise CandidateRejected("state_invalid")
        return dict(self._cookies)

    def discard(self) -> None:
        self._cookies = None
        self._browser_uid = ""
        self._cli_uid = ""
        self._state = "discarded"
