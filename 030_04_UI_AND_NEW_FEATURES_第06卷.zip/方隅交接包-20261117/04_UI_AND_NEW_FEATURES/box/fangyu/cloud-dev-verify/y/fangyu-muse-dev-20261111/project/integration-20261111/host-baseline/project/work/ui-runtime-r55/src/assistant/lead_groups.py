"""Owner-filtered full result grouping before pagination, without signed URLs in keys."""
import hashlib
import re
from datetime import date
from urllib.parse import urlsplit
from .ai_workflow import effective_intent

LABELS={'super_high':'超高意向','high':'高意向','medium':'中等意向','low':'低意向','very_low':'极低意向',
        'pending':'待分析','uncertain':'待核实','unrelated':'不相关'}

def post_title(item):
    title=str(item.get('content_title') or '').strip()
    if title:return title[:300]
    legacy=str(item.get('title') or '').strip()
    if item.get('source_type')=='comment' or item.get('comment_id'):
        comment=str(item.get('text') or '').strip()
        if not comment or comment.startswith(legacy):return '帖子标题未提供'
    return legacy[:300] or '帖子标题未提供'

def group_value(item, by):
    if by=='note':
        url=str(item.get('note_url') or item.get('url') or '')
        parts=urlsplit(url)
        match=re.search(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9_-]+)',parts.path)
        value=match.group(1) if match else (parts.hostname or '')+parts.path
        return value or 'unknown', post_title(item)
    if by=='blogger':
        name=str(item.get('content_author') or '').strip()
        return str(item.get('content_author_id') or name or 'unknown'),name or '博主未提供'
    if by=='date':
        value=str(item.get('published_at') or '')[:10]
        try:date.fromisoformat(value)
        except ValueError:return 'unknown','时间未提供'
        return value,value
    if by=='intent':
        if (not item.get('ai_intent') and not item.get('manual_intent') and
                item.get('analysis_status')=='missing_text'):
            return 'uncertain','待核实'
        if not item.get('ai_intent') and not item.get('manual_intent') and item.get('grade') in ('A','B','C'):
            return 'legacy_'+item['grade'],'旧评分 '+item['grade']+' · 待分析'
        intent=effective_intent(item)
        value=intent.get('level') if intent.get('status')=='graded' else intent.get('status','pending')
        return value,LABELS.get(value,'待分析')
    raise ValueError('分类方式无效')

def validate_grouping(data):
    by=data.get('group_by','')
    selected=data.get('group_key','')
    offset=data.get('group_offset',0)
    if by not in ('','note','blogger','date','intent'):raise ValueError('分类方式无效')
    if type(offset) is not int or offset<0:raise ValueError('分类分页无效')
    if not isinstance(selected,str) or selected and (not by or not re.fullmatch(r'g_[a-f0-9]{32}',selected)):raise ValueError('分类参数无效')
    if 'group_limit' in data:raise ValueError('分类分页不可调整')
    return by,selected,offset

def group_rows(items,data):
    by,selected,offset=validate_grouping(data)
    result={'grouping_contract':'lead-groups-v1','group_by':by,'group_key':selected,
            'groups':[],'groups_total':0,'group_offset':offset,'group_limit':30}
    if not by:return items,result
    groups,keys={},{}
    if by=='intent' and data.get('worklist')=='all':
        # An explicit all-intent view keeps empty grades visible. It does
        # not invent comments or add them to the pending work scope.
        for value,label in LABELS.items():
            key='g_'+hashlib.sha256((by+'\n'+value).encode()).hexdigest()[:32]
            groups[key]={'key':key,'label':label,'count':0}
    for item in items:
        value,label=group_value(item,by)
        key='g_'+hashlib.sha256((by+'\n'+str(value)).encode()).hexdigest()[:32]
        keys[item['id']]=key
        groups.setdefault(key,{'key':key,'label':label,'count':0})['count']+=1
        if by=='note' and groups[key]['label']=='帖子标题未提供' and label!='帖子标题未提供':groups[key]['label']=label
    values=list(groups.values())
    if by=='date':values.sort(key=lambda g: (g['label']!='时间未提供',g['label']),reverse=True)
    if by=='intent':
        ranks={label:i for i,label in enumerate(['超高意向','高意向','中等意向','低意向','极低意向','旧评分 A · 待分析','旧评分 B · 待分析','旧评分 C · 待分析','待分析','待核实','不相关'])}
        values.sort(key=lambda g:ranks.get(g['label'],99))
    result.update(groups=values[offset:offset+30],groups_total=len(values))
    visible=[{**item,'group_key':keys[item['id']]} for item in items if not selected or keys[item['id']]==selected]
    return visible,result
