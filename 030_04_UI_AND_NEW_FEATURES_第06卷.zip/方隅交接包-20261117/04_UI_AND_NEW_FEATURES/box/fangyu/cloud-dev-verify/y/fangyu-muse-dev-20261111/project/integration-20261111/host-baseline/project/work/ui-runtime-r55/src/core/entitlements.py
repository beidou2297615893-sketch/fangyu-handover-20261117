"""Reusable server-side edition policy, independent of billing and UI state.

Read company from trusted tenant configuration, never from action payloads.
Account checks must run within the caller's tenant-scoped save transaction/lock
so simultaneous creates cannot both consume the final slot.
"""
import re


class EntitlementError(ValueError):
    pass


def _platform_id(value):
    return isinstance(value, str) and re.fullmatch(r'[a-z][a-z0-9_-]{1,63}', value) is not None


def normalize_policy(company, installed_ids):
    """Missing fields preserve legacy access; explicit invalid policy fails closed.

platforms is a nonempty whitelist when supplied. accountLimit counts account
records across platforms, including disabled records; it is not a per-platform
limit. Owner may explicitly use null. Every edition may omit the legacy field.
"""
    if not isinstance(company, dict):
        raise EntitlementError('企业能力配置格式无效')
    if isinstance(installed_ids, (str, bytes, dict)):
        raise EntitlementError('已安装平台清单格式无效')
    try:
        installed = list(installed_ids)
    except TypeError as exc:
        raise EntitlementError('已安装平台清单格式无效') from exc
    if any(not _platform_id(item) for item in installed):
        raise EntitlementError('已安装平台ID格式无效')
    installed = list(dict.fromkeys(installed))
    edition = company.get('edition', 'legacy')
    if not isinstance(edition, str) or not edition.strip():
        raise EntitlementError('版本标识格式无效')
    edition = edition.strip()
    if 'platforms' in company:
        allowed = company['platforms']
        if not isinstance(allowed, list) or not allowed or any(not _platform_id(item) for item in allowed):
            raise EntitlementError('开放平台必须为非空的平台ID列表')
        if any(item not in installed for item in allowed):
            raise EntitlementError('开放平台包含未安装或未知的平台')
        allowed = list(dict.fromkeys(allowed))
    else:
        allowed = installed.copy()
    limit = company.get('accountLimit')
    if 'accountLimit' in company:
        if limit is None and edition == 'owner':
            pass
        elif type(limit) is not int or limit <= 0:
            raise EntitlementError('账号上限必须为正整数；自用版本可设为空表示不限')
    return {'edition': edition, 'platforms': allowed, 'accountLimit': limit}


def require_platform(policy, platform_id):
    """Call on every platform operation, including existing tasks/account edits."""
    if not _platform_id(platform_id) or platform_id not in policy['platforms']:
        raise EntitlementError('当前版本未开放此平台')
    return platform_id


def check_account_limit(policy, existing_accounts, incoming_id=None):
    """Validate an addition/edit against current tenant account records.

An incoming ID only means an edit if it matches an existing account. Unknown
client-chosen IDs still consume capacity. Caller also checks record ownership.
Returns True on success; does not mutate records or delete over-limit accounts.
"""
    if not isinstance(existing_accounts, (list, tuple)) or any(not isinstance(row, dict) for row in existing_accounts):
        raise EntitlementError('当前企业账号列表格式无效')
    if incoming_id is not None and (not isinstance(incoming_id, str) or not incoming_id):
        raise EntitlementError('账号ID格式无效')
    if incoming_id is not None and any(row.get('id') == incoming_id for row in existing_accounts):
        return True
    limit = policy['accountLimit']
    if limit is not None and len(existing_accounts) >= limit:
        raise EntitlementError(f'当前版本最多可添加{limit}个账号，已达到上限')
    return True


def capability_summary(policy, existing_accounts=()):
    """UI explanation only; never replace the checks above with hidden controls."""
    count = len(existing_accounts)
    limit = policy['accountLimit']
    remaining = None if limit is None else max(0, limit - count)
    return {**policy, 'platforms': list(policy['platforms']),
            'accountCount': count, 'remainingAccounts': remaining,
            'unlimitedAccounts': limit is None,
            'canAddAccount': remaining is None or remaining > 0,
            'accountLabel': f'已添加{count}个账号 / 不限数量' if limit is None else f'已添加{count} / {limit}个账号'}
