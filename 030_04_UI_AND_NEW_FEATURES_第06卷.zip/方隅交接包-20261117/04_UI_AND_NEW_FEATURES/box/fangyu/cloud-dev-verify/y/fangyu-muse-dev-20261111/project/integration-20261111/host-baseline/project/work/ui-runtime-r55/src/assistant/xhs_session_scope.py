"""Original account/profile owner for one explicit session candidate.

The original login worker holds its outer account_execution_lock throughout.
This inner Scope uses the existing same-thread nesting and physical finish.
"""
import threading
from core.adapters import account_execution_lock,AdapterBusy,AdapterSafetyRequired
from .xhs_batch_scope import _BatchScope


class _SessionScope:
    def __init__(self,runtime,user,account,job,context,reservation):
        from .xhs_page_runtime import XhsPageRuntime
        from .xhs_session_context import _SessionExecutionContext
        if (type(runtime) is not XhsPageRuntime or type(context) is not _SessionExecutionContext
                or context.claim.job is not job or job.get('purpose')!='session_recovery'
                or job.get('_session_reservation') is not reservation
                or job.get('owner_id')!=user.get('id') or job.get('tenant_id')!=user.get('tenant_id')
                or job.get('account_id')!=account.get('id')):raise AdapterSafetyRequired('session_scope_unavailable')
        context.check()
        self.runtime,self.app_context,self.job=runtime,context,job
        self.thread=threading.current_thread()
        self.user_id,self.task_id=user['id'],job['id']
        self.tenant,self.account_id=user['tenant_id'],account['id']
        self.root=runtime.core.store.directory/'accounts'/self.tenant/self.account_id
        self.reservation,self.entry=reservation,None
        self.entered=self.finished=self.user_cancelled=self.result_released=False
        self.retain_result=True
        self.os_lock=account_execution_lock(self.root)

    def check(self):
        if (self.thread is not threading.current_thread() or self.finished or self.user_cancelled
                or self.job.get('status')!='running' or self.job['worker_done'].is_set()
                or self.job.get('_session_reservation') is not self.reservation
                or self.entry is not None and (self.entry is not self.reservation
                    or self.entry.batch_scope is not self or self.entry.stop_requested)
                or self.reservation.login_reserved!='login'):
            raise AdapterSafetyRequired('session_scope_changed')
        self.app_context.check()
        server=self.app_context.claim.session.service.server
        from .xhs_customer_account_runtime import account_runtime_matches,check_operation
        if not account_runtime_matches(server,self.runtime):
            raise AdapterSafetyRequired('account_runtime_changed')
        if getattr(server,'_customer_natural_component',False):
            check_operation(self.app_context,required=self.entered)
        self.runtime.core.adapters.require_account_safe('xiaohongshu',self.root)

    def enter(self):
        self.check()
        self.root,entry=self.runtime._entry(self.root)
        self.entry=entry
        with self.runtime.lock:
            if (entry is not self.reservation or entry.batch_scope is not None
                    or entry.login_reserved!='login' or self.runtime.closed
                    or self.task_id in self.runtime.jobs):raise AdapterBusy('原账号登录范围已变化')
            entry.batch_scope=self
            self.runtime.jobs[self.task_id]=self
        try:
            self.os_lock.__enter__()
            self.entered=True
            self.check()
            entry.lock.acquire()
        except BaseException:
            if self.entered:self.os_lock.__exit__(None,None,None);self.entered=False
            with self.runtime.lock:
                if entry.batch_scope is self:entry.batch_scope=None
                if self.runtime.jobs.get(self.task_id) is self:self.runtime.jobs.pop(self.task_id)
            raise

    finish=_BatchScope.finish

    def _retained_candidate_locked(self):
        # Caller holds the original runtime lock. This is the exact retained
        # object check, not a replacement for the fresh execution context.
        if (self.thread is not threading.current_thread() or not self.finished
                or self.entered or self.user_cancelled or self.result_released
                or self.runtime.jobs.get(self.task_id) is not self
                or self.runtime.entries.get(self.root) is not self.reservation
                or self.reservation.login_reserved!='login'
                or self.reservation.transport is not None):
            raise AdapterSafetyRequired('session_candidate_changed')

    def require_candidate(self):
        # The physical inner lock ended; the original login worker's outer OS
        # lock and exact reservation still cover Coordinator and journal CAS.
        with self.runtime.lock:
            self._retained_candidate_locked()
        self.app_context.check()
        server=self.app_context.claim.session.service.server
        from .xhs_customer_account_runtime import account_runtime_matches,check_operation
        if not account_runtime_matches(server,self.runtime):
            raise AdapterSafetyRequired('account_runtime_changed')
        if getattr(server,'_customer_natural_component',False):
            check_operation(self.app_context,required=self.entered)
        self.runtime.core.adapters.require_account_safe('xiaohongshu',self.root)

    def release_result(self):
        if self.thread is not threading.current_thread() or not self.finished:
            raise AdapterBusy('必须由原登录线程结束候选范围')
        with self.runtime.lock:
            if self.runtime.jobs.get(self.task_id) is self:self.runtime.jobs.pop(self.task_id)
            self.result_released=True
