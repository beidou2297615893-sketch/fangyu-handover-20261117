"""Actual loader/CodeType/disk-container observations; never memory approval."""
import hashlib,importlib.machinery,json,marshal,os,sys,types,zipimport
from pathlib import Path

def _constant(value):
 if isinstance(value,types.CodeType):
  return {'code':{name:getattr(value,name) for name in ('co_argcount','co_posonlyargcount','co_kwonlyargcount','co_nlocals','co_stacksize','co_flags','co_name','co_qualname','co_firstlineno')},'bytes':value.co_code.hex(),'lineTable':value.co_linetable.hex(),'exceptionTable':value.co_exceptiontable.hex(),'consts':[_constant(v) for v in value.co_consts],'names':value.co_names,'vars':value.co_varnames,'free':value.co_freevars,'cells':value.co_cellvars}
 if isinstance(value,bytes):return {'bytes':value.hex()}
 if isinstance(value,tuple):return {'tuple':[_constant(v) for v in value]}
 if isinstance(value,frozenset):return {'frozenset':sorted((_constant(v) for v in value),key=lambda v:json.dumps(v,sort_keys=True,separators=(',',':')))}
 if value is Ellipsis:return {'ellipsis':True}
 if isinstance(value,float):return {'float':value.hex()}
 if isinstance(value,complex):return {'complex':[value.real.hex(),value.imag.hex()]}
 if value is None or type(value) in (bool,int,str):return value
 raise ValueError('unsupported_code_constant')

def code_digest(code):
 if type(code) is not types.CodeType:raise ValueError('code_type_required')
 # Filename is a separate declared loader attribute. No normalization of
 # executable bytes, constants, exception tables, lines or function semantics.
 return hashlib.sha256(json.dumps(_constant(code),ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def _real_file(path):
 p=Path(path)
 if not p.is_absolute() or '..' in p.parts:raise ValueError('origin_path_invalid')
 for q in (p,*p.parents):
  s=q.lstat()
  if q.is_symlink() or getattr(s,'st_file_attributes',0)&0x400:raise ValueError('origin_reparse')
 if not p.is_file():raise ValueError('origin_file_missing')
 before=p.stat();h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 after=p.stat()
 identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)
 if identity(before)!=identity(after):raise ValueError('origin_file_changed')
 return {'path':str(p),'sha256':h.hexdigest(),'identity':{'volume':before.st_dev,'fileIndex':before.st_ino,'bytes':before.st_size,'lastWriteNs':before.st_mtime_ns,'links':before.st_nlink}}

def collect_code_origins():
 if getattr(sys,'frozen',False) is not True:raise ValueError('frozen_helper_required')
 import pyimod02_importers as pyimod
 exe=Path(sys.executable).absolute();archive=pyimod.pyz_archive
 if Path(archive._filename).absolute()!=exe or type(archive._start_offset) is not int or archive._start_offset<0:raise ValueError('pyz_container_invalid')
 containers={str(exe):_real_file(exe)};rows=[];real_python_files=[]
 for name,module in sorted(tuple(sys.modules.items())):
  if module is None:continue
  spec=getattr(module,'__spec__',None);loader=getattr(module,'__loader__',None);typename=type(loader).__module__+'.'+type(loader).__name__;file=getattr(module,'__file__',None)
  row={'module':name,'loader':typename,'declaredFile':str(file) if file else None,'declaredFileIsLoadProof':False}
  row['moduleObjectType']=type(module).__module__+'.'+type(module).__name__
  loaded_name=getattr(spec,'name',None) or getattr(module,'__name__',name)
  if type(loaded_name) is not str or (loaded_name!=name and sys.modules.get(loaded_name) is not module):raise ValueError('origin_module_alias_invalid')
  loader_name=getattr(loader,'name',loaded_name)
  if type(loader_name) is not str:raise ValueError('origin_loader_name_invalid')
  row.update(loadedName=loaded_name,loaderName=loader_name,sysModulesAlias=loaded_name!=name)
  code=None
  if type(loader) is pyimod.PyiFrozenLoader:
   if loader._pyz_archive is not archive or loader._pyz_entry_name not in archive.toc:raise ValueError('pyz_member_invalid')
   code=loader.get_code(loader_name);row.update(kind='pyinstaller_pyz' if code is not None else 'pyinstaller_namespace',container=str(exe),archiveStartOffset=archive._start_offset,member=loader._pyz_entry_name)
  elif type(loader) is pyimod.PyiFrozenEntryPointLoader:
   code=loader.get_code(loaded_name);row.update(kind='pyinstaller_entry',container=str(exe),member='__main__')
  elif type(loader) is importlib.machinery.SourceFileLoader:
   if name in ('struct','pyimod01_archive','pyimod02_importers','pyimod03_ctypes','pyimod04_pywin32') and loader.path==name+'.py':
    # The bootloader executes CArchive modules but attaches a SourceFileLoader
    # with a virtual relative path. It cannot reread module CodeType as source.
    row.update(kind='pyinstaller_bootstrap_virtual_source',container=str(exe),member=name,sourceFileExists=False,moduleCodeTypeAvailable=False)
   else:
    try:actual=_real_file(loader.path)
    except ValueError as error:
     error.origin_module=name;raise
    code=loader.get_code(loader_name);compiled=compile(Path(loader.path).read_bytes(),loader.path,'exec')
    if code_digest(code)!=code_digest(compiled):raise ValueError('source_loader_code_mismatch')
    row.update(kind='source_file',source=actual);real_python_files.append(actual['path'])
  elif type(loader) is importlib.machinery.ExtensionFileLoader:
   actual=_real_file(loader.path);row.update(kind='extension_file',source=actual);real_python_files.append(actual['path'])
  elif type(loader) is zipimport.zipimporter:
   path=str(Path(loader.archive).absolute())
   if path not in containers:containers[path]=_real_file(path)
   code=loader.get_code(loaded_name);row.update(kind='zip_code',container=path,archivePrefix=loader.prefix,member=loaded_name)
  elif loader in (importlib.machinery.BuiltinImporter,importlib.machinery.FrozenImporter):
   if hasattr(loader,'get_code'):code=loader.get_code(loaded_name)
   row.update(kind='stdlib_frozen' if loader is importlib.machinery.FrozenImporter else 'builtin')
  elif type(loader) is importlib.machinery.NamespaceLoader:
   code=loader.get_code(loaded_name);row.update(kind='pyinstaller_namespace_alias',namespacePaths=list(getattr(module,'__path__',())))
  elif type(module).__module__=='CLR' and type(module).__name__=='ModuleObject' and typename=='clr.loader.DotNetLoader':
   row.update(kind='pythonnet_namespace',pythonCodeTypeAvailable=False)
  elif loader is None:
   import typing
   special=name in ('typing.io','typing.re') and module is typing.__dict__.get(name.split('.')[1])
   bridge=name in ('clr','CLR') and file=='unknown' and sys.modules.get('clr') is module and type(module) is types.ModuleType
   resources={'CLR':'clr.py','clr':'clr.py','clr._extras':'clr.py','clr.interop':'interop.py','clr._extras.collections':'Python.Runtime.Mixins.collections.py','clr._extras.dlr':'Python.Runtime.Mixins.dlr.py'}
   embedded=name in resources and type(module) is types.ModuleType and (bridge or file is None)
   if embedded:
    from System import AppDomain
    actual=[str(a.Location) for a in AppDomain.CurrentDomain.GetAssemblies() if str(a.GetName().Name)=='Python.Runtime' and not a.IsDynamic]
    expected=Path(sys._MEIPASS)/'pythonnet/runtime/Python.Runtime.dll'
    if actual!=[str(expected)]:raise ValueError('pythonnet_container_invalid')
    if str(expected) not in containers:containers[str(expected)]=_real_file(expected)
    row.update(kind='pythonnet_embedded_python',container=str(expected),resource=resources[name],moduleCodeTypeAvailable=False)
   else:row.update(kind='stdlib_typing_alias' if special else 'namespace_or_runtime_module')
   if file:row['declaredFileExists']=Path(file).is_file()
  else:
   # Runtime hooks are real frozen code too; unknown file loaders cannot be
   # mislabeled as source. Consumer may reject unrecognized classes.
   if hasattr(loader,'get_code'):
    try:code=loader.get_code(loaded_name)
    except (ImportError,AttributeError):pass
   row.update(kind='other_loader_unapproved')
  if code is not None:
   if type(code) is not types.CodeType:raise ValueError('loader_code_type_invalid')
   row.update(codeType='CodeType',semanticCodeSha256=code_digest(code),codeFilename=code.co_filename)
  functions=[]
  for value in tuple(vars(module).values()):
   if type(value) is types.FunctionType and value.__module__==name:functions.append((value.__qualname__,code_digest(value.__code__)))
   if type(value) is type and value.__module__==name:
    for method in tuple(vars(value).values()):
     if type(method) in (staticmethod,classmethod):method=method.__func__
     if type(method) is types.FunctionType and method.__module__==name:functions.append((method.__qualname__,code_digest(method.__code__)))
  row['moduleFunctionCode']=sorted(set(functions));rows.append(row)
  if len(rows)>2048:raise ValueError('origin_count_limit')
 result={'contract':'portable_python_code_origins_v1','helperContainer':str(exe),'containers':list(containers.values()),'modules':rows,'realPythonFiles':sorted(set(real_python_files)),'codeFilenameOnlyExcludedFromDigest':True,'nativeLoadedBytesVerified':False,'purposeAuthorized':False}
 if len(json.dumps(result,separators=(',',':')).encode())>2000000:raise ValueError('origin_bytes_limit')
 return result
