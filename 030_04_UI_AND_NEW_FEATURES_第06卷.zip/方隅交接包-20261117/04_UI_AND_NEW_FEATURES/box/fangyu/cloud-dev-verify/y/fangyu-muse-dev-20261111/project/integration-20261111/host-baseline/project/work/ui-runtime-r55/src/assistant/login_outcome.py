"""Classify a failed local XHS login from bounded, already available evidence.

Only stable codes and authored messages leave this module. The CLI output and
activity records are never copied into the result or persisted here.
"""

import math
import time
from pathlib import Path

from core.adapters import _cli_json, _xhs_error_code


_LIMIT = 65536
_GENERIC = ('cli_exit_nonzero', '本机登录进程未完成；请核对账号提示，本次已暂停')
_HTTP = {
    461: ('verification_required', '小红书要求核对电脑端登录验证（HTTP 461），本次已暂停，请先核对账号提示'),
    471: ('verification_required', '小红书未放行电脑端登录验证（HTTP 471），本次已暂停，请先核对账号提示'),
    403: ('cli_exit_nonzero', '小红书未放行本次电脑端登录请求（HTTP 403），本次已暂停，请先核对账号状态'),
    429: ('cli_exit_nonzero', '小红书暂未接受本次电脑端登录请求（HTTP 429），本次已暂停，请先核对账号状态'),
}
_CLI_MESSAGES = {
    'not_authenticated': '小红书登录状态未确认，本次已暂停，请先核对账号状态',
    'verification_required': '小红书要求核对电脑端登录验证，本次已暂停，请先核对账号提示',
    'ip_blocked': '小红书限制了当前网络访问，本次已暂停，请先核对网络和账号状态',
    'signature_error': '小红书请求签名校验失败，本次已暂停，请联系管理员核对 CLI 兼容性',
    'api_error': '小红书接口返回失败，本次已暂停，请先核对账号状态',
    'unsupported_operation': '当前 CLI 不支持登录操作，本次已暂停，请联系管理员',
    'protocol_error': '小红书返回格式无效，本次已暂停，请联系管理员核查',
    'transport_error': '小红书连接失败，本次已暂停，请核对网络状态',
    'unknown_error': _GENERIC[1],
}


def _stdout_code(stdout):
    if isinstance(stdout, bytes):
        if len(stdout) > _LIMIT:
            return ''
        decoded = stdout.decode('utf-8', errors='replace')
    elif isinstance(stdout, str):
        if len(stdout.encode('utf-8', errors='replace')) > _LIMIT:
            return ''
        decoded = stdout
    else:
        return ''
    # The pinned CLI emits progress text unless --json is set. Only a complete
    # JSON document or the last nonblank line can carry a structured error.
    candidates = [decoded]
    lines = [line for line in decoded.splitlines() if line.strip()]
    if lines:
        candidates.append(lines[-1])
    for candidate in candidates:
        try:
            code = _xhs_error_code(_cli_json(candidate))
        except (TypeError, ValueError, RecursionError):
            continue
        if code in _CLI_MESSAGES:
            return code
    return ''


def _activity_http_status(activity_path, started_at, kind='login'):
    if kind not in ('login', 'status'):
        return None
    if activity_path is None or type(started_at) not in (int, float) or not math.isfinite(started_at):
        return None
    now = time.time()
    if started_at > now:
        return None
    try:
        with Path(activity_path).open('rb') as stream:
            stream.seek(0, 2)
            size = stream.tell()
            stream.seek(max(0, size - _LIMIT))
            tail = stream.read(_LIMIT)
    except (OSError, TypeError, ValueError):
        return None
    if size > _LIMIT:
        # The first line may have started before the bounded tail.
        separator = tail.find(b'\n')
        tail = tail[separator + 1:] if separator >= 0 else b''
    latest = None
    for line in tail.splitlines():
        try:
            event = _cli_json(line.decode('utf-8', errors='replace'))
        except (TypeError, ValueError, RecursionError):
            continue
        if not isinstance(event, dict) or event.get('stage') != 'finished' or event.get('kind') != kind:
            continue
        at = event.get('at')
        if type(at) not in (int, float) or not math.isfinite(at) or not started_at <= at <= now:
            continue
        status = event.get('status')
        http_status = event.get('http_status')
        if type(status) is int and status in _HTTP:
            if http_status is not None and (type(http_status) is not int or http_status != status):
                continue
            candidate = status
        elif type(status) is str and status in {'api_error', 'protocol_error', 'transport_error'} and type(http_status) is int and http_status in _HTTP:
            candidate = http_status
        else:
            continue
        if latest is None or at >= latest[0]:
            latest = (at, candidate)
    return latest[1] if latest else None


def _activity_cli_code(activity_path, started_at):
    """Only a bounded, same-run status CLI category; never event text."""
    if activity_path is None or type(started_at) not in (int, float) or not math.isfinite(started_at):
        return ''
    now = time.time()
    if started_at > now:
        return ''
    try:
        with Path(activity_path).open('rb') as stream:
            stream.seek(0, 2)
            size = stream.tell()
            stream.seek(max(0, size - _LIMIT))
            tail = stream.read(_LIMIT)
    except (OSError, TypeError, ValueError):
        return ''
    if size > _LIMIT:
        separator = tail.find(b'\n')
        tail = tail[separator + 1:] if separator >= 0 else b''
    latest = None
    for line in tail.splitlines():
        try:
            event = _cli_json(line.decode('utf-8', errors='replace'))
        except (TypeError, ValueError, RecursionError):
            continue
        if (not isinstance(event, dict) or event.get('stage') != 'cli_finished'
                or event.get('kind') != 'status'):
            continue
        at, code = event.get('at'), event.get('status')
        if (type(at) not in (int, float) or not math.isfinite(at)
                or not started_at <= at <= now or not isinstance(code, str)
                or code not in _CLI_MESSAGES):
            continue
        if latest is None or at >= latest[0]:
            latest = (at, code)
    return latest[1] if latest else ''


def classify_login_failure(stdout, activity_path=None, started_at=None, *, kind='login'):
    """Return only ``code``, ``message`` and ``http_status`` for a failed probe.

    ``started_at`` is the wall-clock timestamp captured immediately before the
    login or status process starts. Without it, older activity cannot classify
    this run. The default keeps the existing login-only caller unchanged.
    """
    status = _activity_http_status(activity_path, started_at, kind=kind)
    if status is not None:
        code, message = _HTTP[status]
        return {'code': code, 'message': message, 'http_status': status}
    if kind == 'status':
        code = _activity_cli_code(activity_path, started_at)
        if code:
            return {'code': code, 'message': _CLI_MESSAGES[code], 'http_status': None}
    code = _stdout_code(stdout)
    if code:
        return {'code': code, 'message': _CLI_MESSAGES[code], 'http_status': None}
    return {'code': _GENERIC[0], 'message': _GENERIC[1], 'http_status': None}
