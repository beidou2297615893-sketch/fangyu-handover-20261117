"""One fixed first-navigation command; no Cookie or credential IPC.

The original transport owns Job/ready/files/IPC cleanup. A child result is only
a bounded outcome code; the original parent verifies candidate SHA/HMAC and
uses the existing Coordinator after physical cleanup.
"""
import hmac
import time
from xhs_page_transport import XhsPageTransport,PageTransportError
from .browser_login_window import _RECORDED_OUTCOMES


class SessionRecoveryTransport(XhsPageTransport):
    def _run_session_recovery(self):
        gate,state=self.ready_guard,self.state
        self._guard('before_call','session_recovery','recover')
        with gate.issue():
            with state.cv:
                if (state.stopping or state.poisoned or not state.connected
                        or state.pending is not None or 'recover' in state.used_call_ids):
                    raise PageTransportError('session_navigation_denied')
                state.used_call_ids.add('recover')
                state.task_epoch_counter+=1
                state.pending={'action':'session_recovery','call_id':'recover',
                    'task_epoch':state.task_epoch_counter,'doc_epoch':state.doc_epoch,
                    'delivered':False,'result':None,'error':None}
                pending=state.pending
                state.cv.notify_all()
        deadline=self.session_scope.app_context.claim.deadline
        while True:
            # No Core/runtime permission read while the original IPC cv is held.
            self._guard('waiting_session','session_recovery','recover')
            with state.cv:
                if state.stopping or state.poisoned:raise PageTransportError('cancelled')
                if pending['result'] is not None:
                    code=pending['result']
                    state.pending=None
                    return code
                if pending['error'] is not None:raise PageTransportError(pending['error'])
                if self.process.poll() is not None:raise PageTransportError('helper_exited')
                if time.monotonic()>=deadline:raise PageTransportError('timeout')
                state.cv.wait(.1)

    def _ipc(self,path,body):
        if path in ('/bootstrap','/connect'):return super()._ipc(path,body)
        state=self.state
        with state.cv:
            if (not state.connected or not hmac.compare_digest(str(body.get('session_token','')),
                    state.session_token) or body.get('doc_epoch')!=state.doc_epoch):
                raise PageTransportError('session_denied')
            if path not in ('/poll','/session_current','/session_result'):
                raise PageTransportError('session_action_denied')
            if state.stopping or state.poisoned:return {'action':'stop'}
            pending=state.pending
            if path=='/poll':
                if pending is None or pending['delivered']:return {'action':'idle'}
                pending['delivered']=True
                return {key:pending[key] for key in ('action','call_id','task_epoch')}
            if (pending is None or not pending['delivered']
                    or body.get('call_id')!=pending['call_id']
                    or type(body.get('task_epoch')) is not int
                    or body['task_epoch']!=pending['task_epoch']):
                raise PageTransportError('session_command_changed')
            if path=='/session_current':return {'action':'continue'}
            if (set(body)!={'session_token','doc_epoch','call_id','task_epoch','code'}
                    or body.get('code') not in _RECORDED_OUTCOMES
                    or pending['result'] is not None or pending['error'] is not None):
                raise PageTransportError('session_result_denied')
            pending['result']=body['code']
            state.cv.notify_all()
            return {}
