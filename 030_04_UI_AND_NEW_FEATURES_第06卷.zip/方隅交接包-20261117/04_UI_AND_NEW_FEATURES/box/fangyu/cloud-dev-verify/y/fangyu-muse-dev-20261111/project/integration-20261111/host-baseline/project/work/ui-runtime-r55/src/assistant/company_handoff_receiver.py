"""Company receiver bridge. Local metadata never substitutes for company ACK.

Reads use the receiver's current identity and never need the source's local leads.
One durable receiver/channel attempt precedes one write; recovery is status-only.
"""
from copy import deepcopy
import hashlib
import json
import re
import sqlite3
import time

from core import CoreError
from .company_handoff_preparation import _hash, _json, _raw
from .company_handoff_original_status import _ENVELOPE, _RECEIPT, _ORIGINAL, _CURRENT, _STATES
from .company_handoff_receiver_transport import _valid, LIST as CLOUD_LIST, DETAIL as CLOUD_DETAIL, RECEIPT as CLOUD_ACTION, STATUS as CLOUD_STATUS
from .acquisition_exports import _public_label

LIST = 'company_handoff_received_list'
DETAIL = 'company_handoff_received_detail'
RECEIPT = 'company_handoff_receipt'
GET = 'company_handoff_receipt_get'
ACTIONS = frozenset((LIST, DETAIL, RECEIPT, GET))
ATTEMPTS = 'company_handoff_receiver_attempts'
CONTRACT = 'company_handoff_receiver_v1'
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_ENV = re.compile(r'[A-Za-z0-9_-]{3,100}\Z')
_REF = re.compile(r'(?:evidence|document):[a-f0-9]{32}\Z')
_UUID = re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z')
_MAX = 9007199254740991
_DECISIONS = {'accept': 'accepted', 'reject': 'rejected', 'needs_information': 'needs_information',
    'duplicate': 'duplicate_pending_review', 'existing_customer': 'existing_customer_pending_review'}
_ROW = frozenset(('id', 'version', 'tenant_id', 'cloud_owner', 'company_id', 'environment_id', 'device_id',
    'actor_id', 'channel_id', 'expected_revision', 'decision', 'reason_code', 'evidence_reference',
    'cloud_idempotency_key', 'cloud_payload_hash', 'state', 'created_at', 'updated_at', 'revision', 'record_hash'))
_ITEM = frozenset(('channel_id', 'company_id', 'source_owner', 'source_event_id', 'customer_id', 'source',
    'recipient_id', 'recipient_name', 'purpose', 'consent', 'contact_reference', 'qualification', 'status',
    'attribution_status', 'revision', 'created_at', 'updated_at', 'order_links', 'last_event_hash',
    'submitted_at', 'receipt', 'review', 'dispute', 'withdrawal_reason', 'current_consent_valid',
    'resource_receipt_auth_verified', 'platform_delivery_verified', 'contact_delivery', 'settlement', 'permissions', 'storage_scope'))


class CompanyHandoffReceiverError(CoreError):
    def __init__(self, code, message, status=409, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_RECEIVER_' + code
        self.status, self.mutation_committed = status, mutation_committed


def _fail(code, message, status=409, *, mutation=False):
    raise CompanyHandoffReceiverError(code, message, status, mutation)


def _int(value, minimum=0):
    return type(value) is int and minimum <= value <= _MAX


def _matches(value, pattern):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _label(value):
    if not isinstance(value, str) or not value or len(value) > 160:
        _fail('PRIVATE_PROJECTION', '接收方或用途标签需核对，未返回自由内容')
    try:
        label = _public_label(value)
        # The mature detector normalizes full-width/zero-width characters but
        # its single optional separator misses a contact label like 微信号：.
        if re.search(r'(?<![A-Za-z0-9_])(?:微信|wechat|weixin|wxid|wx|手机号|电话)\s*'
                r'(?:(?:号码|号|id)\s*)?[:：_]\s*[A-Za-z0-9_-]{3,}', label, re.I):
            raise ValueError('contact label')
        return label
    except Exception:
        _fail('PRIVATE_PROJECTION', '接收方或用途标签含受保护内容，未返回自由内容')


class CompanyHandoffReceiver:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, cloud_read, cloud_receipt, clock=None):
        workspace = company.get('managedWorkspace') if isinstance(company, dict) else None
        env = workspace.get('environment_id') if isinstance(workspace, dict) else None
        cid = company.get('id') if isinstance(company, dict) else None
        if (not _matches(env, _ENV) or not _matches(cid, _ID) or not _matches(device_id, _ID)
                or not isinstance(owner, str) or not owner or len(owner) > 160
                or tenant != 'cloud-' + _raw(env + '\n' + cid)[:24]
                or not all(callable(v) for v in (scope_guard, cloud_read, cloud_receipt))):
            raise ValueError('公司接收需要可信本人、公司环境、设备和现有连接')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.company_id, self.environment_id, self.device_id = cid, env, device_id
        self._fixed_device, self.scope_guard = device_id, scope_guard
        self.cloud_read, self.cloud_receipt, self.clock = cloud_read, cloud_receipt, clock or time.time

    def _scope(self):
        try:
            valid = (self.scope_guard() is True and self.company.get('id') == self.company_id
                and (self.company.get('managedWorkspace') or {}).get('environment_id') == self.environment_id
                and self.device_id == self._fixed_device)
        except Exception:
            valid = False
        if not valid:
            _fail('BINDING_CHANGED', '当前接收本人、公司或设备范围已变化，请保留原号')

    def _actor(self, db, user):
        self._scope()
        raw = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            ('users', user.get('id') if isinstance(user, dict) else None, self.tenant)).fetchone()
        actor = json.loads(raw['body']) if raw else None
        if (not actor or actor.get('disabled') or actor.get('cloud_bound') is not True
                or actor.get('development_local_only') is True or actor.get('username') != self.owner
                or actor.get('role') not in ('admin', 'operator')
                or any(actor.get(k) != user.get(k) for k in ('id', 'tenant_id', 'username', 'role'))):
            _fail('AUTH_REQUIRED', '接收本人身份或权限需核对，未冒用来源员工', 403)
        return actor

    def _snapshot(self, user):
        with self.core.lock, self.core.store.connect() as db:
            actor = self._actor(db, user)
        return {'actor': deepcopy(actor), 'scope': _hash([self.company, self.device_id,
            {k: actor.get(k) for k in ('id', 'tenant_id', 'username', 'role', 'cloud_bound', 'disabled')}])}

    def _fence(self, before, user):
        if self._snapshot(user)['scope'] != before['scope']:
            _fail('BINDING_CHANGED', '读取返回时本人或公司范围已变化，请按原号核对')

    def _record_id(self, channel):
        return _hash(['company-handoff-receiver-v1', self.tenant, self.company_id, self.owner, channel])

    def _key(self, channel):
        return _hash(['company-handoff-cloud-receipt-v1', self.tenant, self.company_id, self.owner, channel])

    def _body(self, row):
        body = dict(channel_id=row['channel_id'], expected_revision=row['expected_revision'],
            decision=row['decision'], evidence_reference=row['evidence_reference'], idempotency_key=row['cloud_idempotency_key'])
        if row['reason_code'] is not None:
            body['reason_code'] = row['reason_code']
        return body

    def _payload_hash(self, row):
        return _hash(dict(environment_id=self.environment_id, operation=CLOUD_ACTION, **self._body(row)))

    def _row(self, db, channel, actor):
        raw = db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',
            (ATTEMPTS, self._record_id(channel))).fetchone()
        if not raw:
            return None
        try:
            row = json.loads(raw['body'])
            fixed = dict(id=self._record_id(channel), version=1, tenant_id=self.tenant, cloud_owner=self.owner,
                company_id=self.company_id, environment_id=self.environment_id, device_id=self.device_id,
                actor_id=actor['id'], channel_id=channel, cloud_idempotency_key=self._key(channel))
            if (set(row) != _ROW or raw['tenant_id'] != self.tenant or any(row[k] != v for k, v in fixed.items())
                    or row['record_hash'] != _hash({k: v for k, v in row.items() if k != 'record_hash'})
                    or row['state'] not in ('unknown', 'recorded') or not _int(row['revision'], 1)
                    or not _int(row['created_at'], 1577836800) or not _int(row['updated_at'], row['created_at'])
                    or not _valid(CLOUD_ACTION, self._body(row)) or row['cloud_payload_hash'] != self._payload_hash(row)):
                raise ValueError('attempt mismatch')
            return row
        except Exception:
            _fail('ATTEMPT_CONFLICT', '原公司接收元数据需核对，不能换号或重发')

    @staticmethod
    def _put(db, row, *, new=False):
        unsigned = {k: v for k, v in row.items() if k != 'record_hash'}
        row = dict(unsigned, record_hash=_hash(unsigned))
        if new:
            db.execute('INSERT INTO records VALUES(?,?,?,?)', (ATTEMPTS, row['id'], row['tenant_id'], _json(row)))
        else:
            cursor = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (_json(row), ATTEMPTS, row['id'], row['tenant_id']))
            if cursor.rowcount != 1:
                _fail('ATTEMPT_CONFLICT', '原接收范围已变化，请保留原号')
        return row

    @staticmethod
    def _commit(db):
        db.commit()

    def _read(self, snapshot, user, operation, data):
        self._fence(snapshot, user)
        try:
            answer = self.cloud_read(deepcopy(snapshot['actor']), operation, deepcopy(data))
        except Exception:
            _fail('READ_UNAVAILABLE', '公司收件或原接收回执暂不可读，请保留原号', 503)
        self._fence(snapshot, user)
        return answer

    def _item(self, raw, channel=None):
        if isinstance(raw, dict) and 'origin_kind' in raw:
            from .owner_company_receipt_bridge import owner_channel
            if raw['origin_kind'] != 'owner_package_v1':
                _fail('INVALID_RECEIPT', '未知公司来源类型，不能套用员工字段')
            try:
                return owner_channel(raw, channel_id=channel, receiver=True)
            except CoreError:
                _fail('INVALID_RECEIPT', '公司原资料包声明或独立接收范围需核对')
        required = {'channel_id', 'company_id', 'source_owner', 'source_event_id', 'customer_id', 'source',
            'recipient_id', 'recipient_name', 'purpose', 'consent', 'contact_reference', 'qualification', 'status',
            'revision', 'created_at', 'updated_at', 'last_event_hash', 'current_consent_valid',
            'platform_delivery_verified', 'contact_delivery', 'permissions', 'storage_scope'}
        if (not isinstance(raw, dict) or not required <= set(raw) or set(raw) - _ITEM
                or not _matches(raw.get('channel_id'), _CHANNEL) or channel is not None and raw['channel_id'] != channel
                or raw.get('company_id') != self.company_id or raw.get('status') not in _STATES
                or not _int(raw.get('revision'), 1) or not _int(raw.get('created_at'), 1577836800)
                or not _int(raw.get('updated_at'), raw['created_at']) or not _matches(raw.get('last_event_hash'), _HEX)
                or raw.get('qualification') != 'qualified' or not isinstance(raw.get('source_owner'), str) or not raw['source_owner']
                or not _matches(raw.get('recipient_id'), _ID) or not _matches(raw.get('source_event_id'), _UUID)
                or raw.get('platform_delivery_verified') is not False or raw.get('contact_delivery') != 'platform_reference_only'
                or raw.get('storage_scope') != 'company_server_ledger' or type(raw.get('current_consent_valid')) is not bool):
            _fail('INVALID_RECEIPT', '公司渠道身份或当前状态未通过核对')
        source, consent, perms = raw['source'], raw['consent'], raw['permissions']
        if (not isinstance(source, dict) or set(source) != {'platform', 'author_id', 'comment_id', 'source_lead_hash',
                'device_id', 'original_text_hash', 'evidence_source', 'platform_provenance_verified'}
                or any(not _matches(source.get(k), _ID) for k in ('platform', 'author_id', 'comment_id', 'device_id'))
                or any(not _matches(source.get(k), _HEX) for k in ('source_lead_hash', 'original_text_hash'))
                or source.get('evidence_source') != 'device_report' or source.get('platform_provenance_verified') is not False
                or raw['customer_id'] != 'cu_' + hashlib.sha256((source['platform'] + ':author:' + source['author_id']).encode()).hexdigest()
                or raw['contact_reference'] != 'platform:' + source['platform'] + ':' + source['author_id']
                or not isinstance(consent, dict) or set(consent) != {'status', 'evidence_reference', 'notice_version', 'evidence_source', 'independently_verified'}
                or consent.get('status') not in ('granted', 'withdrawn') or not _matches(consent.get('evidence_reference'), re.compile(r'consent:[a-f0-9]{32}\Z'))
                or consent.get('evidence_source') != 'operator_recorded' or consent.get('independently_verified') is not False
                or not isinstance(perms, dict) or set(perms) != {'can_submit', 'can_withdraw', 'can_dispute', 'can_receipt', 'can_review'}
                or any(type(v) is not bool for v in perms.values())
                or perms['can_receipt'] and (raw['source_owner'] == self.owner or raw['status'] != 'submitted' or not raw['current_consent_valid'])
                or raw['status'] == 'withdrawn' and raw['current_consent_valid']):
            _fail('INVALID_RECEIPT', '公司当前来源、客户或接收权限未通过核对')
        receipt = raw.get('receipt')
        if receipt is not None and (not isinstance(receipt, dict) or set(receipt) != {'actor', 'recipient_id', 'decision',
                'evidence_reference', 'recorded_at', 'reason_code', 'authenticated', 'evidence_independently_verified'}
                or not isinstance(receipt.get('actor'), str) or not receipt['actor'] or receipt['actor'] == raw['source_owner']
                or receipt.get('recipient_id') != raw['recipient_id'] or receipt.get('decision') not in _DECISIONS
                or not _matches(receipt.get('evidence_reference'), _REF) or not _int(receipt.get('recorded_at'), 1577836800)
                or receipt.get('authenticated') is not True or receipt.get('evidence_independently_verified') is not False
                or not _valid(CLOUD_ACTION, dict(channel_id=raw['channel_id'], expected_revision=1,
                    decision=receipt['decision'], evidence_reference=receipt['evidence_reference'], idempotency_key='0'*64,
                    **({'reason_code': receipt['reason_code']} if receipt['reason_code'] is not None else {})))):
            _fail('INVALID_RECEIPT', '公司接收历史需核对，未包装成功')
        return dict(channel_id=raw['channel_id'], customer_scope_hash=_hash([self.company_id, raw['customer_id']]),
            source_actor_scope_hash=_hash([self.company_id, raw['source_owner']]), platform=source['platform'],
            recipient_id=raw['recipient_id'], recipient_name=_label(raw['recipient_name']), purpose=_label(raw['purpose']),
            revision=raw['revision'], status=raw['status'], current_consent_valid=raw['current_consent_valid'],
            can_receipt=perms['can_receipt'], historical_resource_receipt_recorded=bool(receipt and receipt['decision'] == 'accept'),
            receipt_evidence_independently_verified=False, contact_delivery='platform_reference_only',
            created_at=raw['created_at'], updated_at=raw['updated_at'])

    def _detail(self, snapshot, user, channel):
        answer = self._read(snapshot, user, CLOUD_DETAIL, {'channel_id': channel})
        fields = {'item', 'server_recorded', 'platform_delivery_verified', 'attribution_confirmed', 'settlement_active',
            'read_only', 'mutation_committed', 'auto_retry'}
        if (not isinstance(answer, dict) or set(answer) != fields or answer['server_recorded'] is not True
                or answer['read_only'] is not True or answer['mutation_committed'] is not False or answer['auto_retry'] is not False
                or any(answer[k] is not False for k in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))):
            _fail('INVALID_RECEIPT', '公司详情纯读格式需核对')
        return deepcopy(answer['item']), self._item(answer['item'], channel)

    def _status(self, snapshot, user, row):
        answer = self._read(snapshot, user, CLOUD_STATUS, {'operation_action': CLOUD_ACTION, 'idempotency_key': row['cloud_idempotency_key']})
        receipt = answer.get('operation_receipt') if isinstance(answer, dict) else None
        if isinstance(receipt, dict) and receipt.get('contract') == 'owner_package_receiver_operation_v1':
            if (set(answer) != _ENVELOPE or answer.get('read_only') is not True
                    or answer.get('mutation_committed') is not False or answer.get('auto_retry') is not False):
                _fail('INVALID_RECEIPT', '原资料包接收查询只允许纯读结果')
            return self._owner_status(row, receipt)
        if (not isinstance(answer, dict) or set(answer) != _ENVELOPE or answer.get('read_only') is not True
                or answer.get('mutation_committed') is not False or answer.get('auto_retry') is not False
                or not isinstance(receipt, dict) or set(receipt) != _RECEIPT
                or receipt.get('contract') != 'handoff_operation_receipt_v1' or receipt.get('read_only') is not True
                or receipt.get('mutation_committed') is not False or receipt.get('authenticated_actor') != self.owner
                or receipt.get('storage_scope') != 'company_server_ledger' or receipt.get('operation_action') != CLOUD_ACTION
                or receipt.get('idempotency_key') != row['cloud_idempotency_key'] or receipt.get('state') not in ('unknown', 'recorded')
                or not _int(receipt.get('observed_at'), 1577836800) or receipt.get('auto_retry') is not False
                or any(receipt.get(k) is not False for k in ('platform_delivery_verified', 'settlement_active', 'financial_receipt_verified', 'cooperation_policy_verified'))
                or receipt.get('verified_cash_cents') is not None or receipt.get('verified_paid_commission_cents') is not None):
            _fail('INVALID_RECEIPT', '原接收回执身份或格式需核对')
        if receipt['state'] == 'unknown':
            if any(receipt.get(k) is not None for k in ('original_execution_confirmed', 'original_operation', 'current_handoff')):
                _fail('INVALID_RECEIPT', '缺失原号不能包装已执行')
            return receipt
        original, current = receipt['original_operation'], receipt['current_handoff']
        if (receipt['original_execution_confirmed'] is not True or not isinstance(original, dict) or set(original) != _ORIGINAL
                or original['payload_hash'] != row['cloud_payload_hash'] or original['channel_id'] != row['channel_id']
                or original['revision'] != row['expected_revision'] + 1 or original['historical_status'] != _DECISIONS[row['decision']]
                or not _int(original['occurred_at'], 1577836800) or original['occurred_at'] > receipt['observed_at']
                or original['historical_event_self_hash_verified'] is not True or original['full_historical_chain_verified'] is not False
                or not isinstance(current, dict) or set(current) != _CURRENT or current['channel_id'] != row['channel_id']
                or not _int(current['revision'], original['revision']) or current['status'] not in _STATES
                or type(current['current_consent_valid']) is not bool or type(current['historical_resource_receipt_recorded']) is not bool
                or current['receipt_evidence_independently_verified'] is not False
                or current['status'] == 'withdrawn' and current['current_consent_valid']):
            _fail('INVALID_RECEIPT', '原接收历史与当前公司记录不一致')
        return receipt

    def _owner_status(self, row, receipt):
        from .owner_company_receipt_bridge import FLAGS, owner_channel, owner_flags
        fields = FLAGS | {'contract', 'authenticated_actor', 'operation_action',
            'idempotency_key', 'state', 'original_execution_confirmed',
            'original_operation', 'current_handoff'}
        if (set(receipt) != fields or receipt.get('authenticated_actor') != self.owner
                or receipt.get('operation_action') != CLOUD_ACTION
                or receipt.get('idempotency_key') != row['cloud_idempotency_key']
                or receipt.get('state') != 'recorded'
                or receipt.get('original_execution_confirmed') is not True):
            _fail('INVALID_RECEIPT', '原公司接收身份和固定原号需核对')
        try:
            owner_flags(receipt, read_only=True)
            current = owner_channel(receipt['current_handoff'], channel_id=row['channel_id'], receiver=True)
        except CoreError:
            _fail('INVALID_RECEIPT', '原资料包接收类型或公司当前范围需核对')
        original = receipt['original_operation']
        if (not isinstance(original, dict) or set(original) !=
                {'payload_hash', 'channel_id', 'revision', 'original_event_hash'}
                or original.get('payload_hash') != row['cloud_payload_hash']
                or original.get('channel_id') != row['channel_id']
                or not _int(original.get('revision'), 1)
                or original['revision'] != row['expected_revision'] + 1
                or not _matches(original.get('original_event_hash'), _HEX)
                or current['revision'] < original['revision']):
            _fail('INVALID_RECEIPT', '原接收事件未匹配本机预保存输入')
        return deepcopy(receipt)

    @staticmethod
    def _can_receipt(item):
        if item is None:
            return False
        return item['permissions']['can_receipt'] if item.get('origin_kind') == 'owner_package_v1' else item['can_receipt']

    @staticmethod
    def _same_current(current, item):
        if item.get('origin_kind') == 'owner_package_v1':
            keys = ('origin_kind', 'channel_id', 'case_id', 'claim_id', 'instance_id',
                'package_id', 'row_id', 'selection_digest', 'artifact_sha256',
                'sender_subject_id', 'recipient_id', 'purpose', 'revision', 'status',
                'consent', 'receipt', 'permissions')
            return current.get('origin_kind') == 'owner_package_v1' and all(current.get(key) == item[key] for key in keys)
        return all(current.get(key) == item[key] for key in
            ('channel_id', 'revision', 'status', 'current_consent_valid', 'historical_resource_receipt_recorded'))

    def _result(self, action, snapshot, *, item=None, row=None, receipt=None, dispatched=False,
                read_only=True, listing=None):
        state = 'list' if action == LIST else 'recorded' if receipt and receipt['state'] == 'recorded' else 'unknown' if row else 'not_attempted'
        original = None
        if receipt and receipt['state'] == 'recorded':
            original = {k: deepcopy(v) for k, v in receipt['original_operation'].items() if k != 'payload_hash'}
        owner_metadata = (bool(item and item.get('origin_kind') == 'owner_package_v1')
            or bool(listing and any(entry.get('origin_kind') == 'owner_package_v1' for entry in listing['items']))
            or bool(receipt and receipt.get('contract') == 'owner_package_receiver_operation_v1'))
        return dict(contract=CONTRACT, operation_action=action, read_only=read_only, mutation_committed=not read_only,
            storage_scope='local_bridge_company_server_ledger', local_only=False, cross_machine_verified=False,
            actor_scope_hash=_hash([self.company_id, self.owner, snapshot['actor']['id']]), observed_at=int(self.clock()),
            state=state, item=deepcopy(item), items=deepcopy(listing['items']) if listing else [],
            authorized_recipients=deepcopy(listing['authorized_recipients']) if listing else [],
            selected_recipient_id=listing['selected_recipient_id'] if listing else None,
            selection_required=listing['selection_required'] if listing else False,
            total=listing['total'] if listing else None, offset=listing['offset'] if listing else None,
            has_more=listing['has_more'] if listing else False,
            attempt={k: row[k] for k in ('state', 'expected_revision', 'decision', 'created_at', 'updated_at')}
                | {'operation_action': CLOUD_ACTION, 'idempotency_key': row['cloud_idempotency_key']} if row else None,
            original_operation=original, original_execution_confirmed=receipt['original_execution_confirmed'] if receipt else None,
            eligible_for_receipt=bool(self._can_receipt(item) and row is None), cloud_receipt_requested=dispatched,
            auto_retry=False, contact_delivery='owner_package_metadata_only' if owner_metadata else 'platform_reference_only', platform_delivery_verified=False,
            receipt_evidence_independently_verified=False, financial_receipt_verified=False, cooperation_policy_verified=False,
            settlement_active=False, verified_cash_cents=None, verified_paid_commission_cents=None,
            contacts_modified=False, local_handoffs_modified=False, platform_requests_started=False, provider_requests_started=False)

    def _get(self, action, channel, snapshot, user):
        with self.core.lock, self.core.store.connect() as db:
            row = self._row(db, channel, self._actor(db, user))
        receipt = self._status(snapshot, user, row) if row else None
        _, item = self._detail(snapshot, user, channel)
        if receipt and receipt['state'] == 'recorded':
            current = receipt['current_handoff']
            if not self._same_current(current, item):
                _fail('CURRENT_CHANGED', '原回执读取后公司状态已变化，请按同原号再次核对')
        self._fence(snapshot, user)
        return self._result(action, snapshot, item=item, row=row, receipt=receipt)

    def execute(self, action, data, user):
        if action not in ACTIONS or not isinstance(data, dict):
            _fail('INVALID_REQUEST', '不支持此公司接收操作', 400)
        snapshot = self._snapshot(user)
        if action == LIST:
            body = {'view': 'received', **deepcopy(data)}
            if set(data) - {'recipient_id', 'offset', 'limit'} or not _valid(CLOUD_LIST, body):
                _fail('INVALID_REQUEST', '只可选择有权接收范围和有限页数', 400)
            body.setdefault('offset', 0); body.setdefault('limit', 10)
            answer = self._read(snapshot, user, CLOUD_LIST, body)
            fields = {'items', 'total', 'offset', 'has_more', 'authorized_recipients', 'selected_recipient_id', 'selection_required',
                'server_recorded', 'platform_delivery_verified', 'attribution_confirmed', 'settlement_active', 'read_only', 'mutation_committed', 'auto_retry'}
            if (not isinstance(answer, dict) or set(answer) != fields or answer['read_only'] is not True or answer['mutation_committed'] is not False
                    or answer['auto_retry'] is not False or answer['server_recorded'] is not True
                    or any(answer[k] is not False for k in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))
                    or not isinstance(answer['authorized_recipients'], list) or len(answer['authorized_recipients']) > 100
                    or not isinstance(answer['items'], list) or len(answer['items']) > body['limit']
                    or type(answer['selection_required']) is not bool or answer['offset'] != body['offset'] or type(answer['offset']) is not int
                    or type(answer['has_more']) is not bool):
                _fail('INVALID_RECEIPT', '公司收件范围或分页格式未通过核对')
            ids = set(); recipients = []
            for row in answer['authorized_recipients']:
                if not isinstance(row, dict) or set(row) != {'id', 'name'} or not _matches(row['id'], _ID) or row['id'] in ids:
                    _fail('INVALID_RECEIPT', '授权接收范围需核对')
                ids.add(row['id']); recipients.append(dict(id=row['id'], name=_label(row['name'])))
            selected = body.get('recipient_id')
            if (answer['selected_recipient_id'] != selected or answer['selection_required'] != (selected is None)
                    or selected is None and (answer['items'] or answer['total'] is not None or answer['has_more'])
                    or selected is not None and (selected not in ids or not _int(answer['total']) or answer['offset'] > answer['total']
                        or answer['has_more'] != (answer['offset'] + len(answer['items']) < answer['total']))):
                _fail('INVALID_RECEIPT', '接收范围或分页边界不一致')
            items = [self._item(raw) for raw in answer['items']]
            if len({i['channel_id'] for i in items}) != len(items) or any(i['recipient_id'] != selected for i in items):
                _fail('INVALID_RECEIPT', '公司收件列表跨越所选范围')
            listing = {k: answer[k] for k in ('total', 'offset', 'has_more', 'selected_recipient_id', 'selection_required')}
            listing.update(items=items, authorized_recipients=recipients)
            self._fence(snapshot, user)
            return self._result(action, snapshot, listing=listing)
        if action in (DETAIL, GET):
            if set(data) != {'channel_id'} or not _matches(data.get('channel_id'), _CHANNEL):
                _fail('INVALID_REQUEST', '公司接收查询只接受原公司渠道编号', 400)
            return self._get(action, data['channel_id'], snapshot, user)
        body = dict(data, idempotency_key=self._key(data.get('channel_id')))
        if set(data) - {'channel_id', 'expected_revision', 'decision', 'reason_code', 'evidence_reference'} or not _valid(CLOUD_ACTION, body):
            _fail('INVALID_REQUEST', '接收决定、版本或实际证据引用需核对', 400)
        channel = data['channel_id']
        with self.core.lock, self.core.store.connect() as db:
            previous = self._row(db, channel, self._actor(db, user))
        if previous:
            if self._body(previous) != body:
                _fail('ATTEMPT_EXISTS', '已有原接收尝试，请只核对原号，不修改或重发')
            return self._get(action, channel, snapshot, user)
        raw, item = self._detail(snapshot, user, channel)
        if item['revision'] != data['expected_revision'] or not self._can_receipt(item):
            _fail('RECEIVER_REQUIRED', '公司当前版本、同意或接收权限未允许此决定', 403)
        self._fence(snapshot, user)
        commit_started = False
        try:
            with self.core.lock, self.core.store.connect() as db:
                db.execute('PRAGMA busy_timeout=0'); db.execute('BEGIN IMMEDIATE')
                actor = self._actor(db, user); previous = self._row(db, channel, actor)
                if previous:
                    db.rollback()
                else:
                    stamp = int(self.clock())
                    if not _int(stamp, 1577836800):
                        _fail('CLOCK_UNAVAILABLE', '本机可信时间需核对，未开始接收')
                    row = dict(id=self._record_id(channel), version=1, tenant_id=self.tenant, cloud_owner=self.owner,
                        company_id=self.company_id, environment_id=self.environment_id, device_id=self.device_id, actor_id=actor['id'],
                        channel_id=channel, expected_revision=data['expected_revision'], decision=data['decision'], reason_code=data.get('reason_code'),
                        evidence_reference=data['evidence_reference'], cloud_idempotency_key=self._key(channel), state='unknown',
                        created_at=stamp, updated_at=stamp, revision=1)
                    row['cloud_payload_hash'] = self._payload_hash(row)
                    row = self._put(db, row, new=True)
                    commit_started = True
                    self._commit(db)
        except Exception as error:
            if commit_started:
                _fail('RESULT_UNKNOWN', '原接收准备提交边界尚未确认，请保留原号只读核对', mutation=None)
            if isinstance(error, CompanyHandoffReceiverError):
                raise
            if isinstance(error, sqlite3.OperationalError):
                _fail('ATTEMPT_BUSY', '另一接收核对正在处理，请保留同原号读取；未重发')
            _fail('PREPARATION_UNAVAILABLE', '本机原接收准备暂不可保存，未开始公司接收', 503)
        if previous:
            if self._body(previous) != body:
                _fail('ATTEMPT_EXISTS', '另一实例已有原接收决定，请只核对原号，不修改或重发')
            return self._get(action, channel, snapshot, user)
        try:
            self._fence(snapshot, user)
            answer = self.cloud_receipt(deepcopy(actor), CLOUD_ACTION, self._body(row))
            self._fence(snapshot, user)
            if not isinstance(answer, dict) or set(answer) != {'item', 'replayed'} or type(answer['replayed']) is not bool:
                _fail('INVALID_RECEIPT', '原接收回显需核对')
            echoed = self._item(answer['item'], channel)
            actual = answer['item'].get('receipt') or {}
            if raw.get('origin_kind') == 'owner_package_v1':
                if (echoed.get('origin_kind') != 'owner_package_v1'
                        or echoed['revision'] != row['expected_revision'] + 1
                        or echoed['status'] != _DECISIONS[row['decision']]
                        or actual.get('decision') != row['decision']
                        or actual.get('reason_code') != row['reason_code']
                        or actual.get('evidence_reference') != row['evidence_reference']
                        or actual.get('revision') != echoed['revision']
                        or any(echoed[key] != raw[key] for key in ('case_id', 'claim_id',
                            'instance_id', 'package_id', 'row_id', 'selection_digest',
                            'artifact_sha256', 'sender_subject_id', 'recipient_id', 'purpose', 'consent'))):
                    _fail('INVALID_RECEIPT', '公司原资料包回显与本次明确接收决定不一致')
            elif (echoed['revision'] != row['expected_revision'] + 1 or echoed['status'] != _DECISIONS[row['decision']]
                    or actual.get('actor') != self.owner or actual.get('decision') != row['decision']
                    or actual.get('reason_code') != row['reason_code'] or actual.get('evidence_reference') != row['evidence_reference']
                    or answer['item']['source'] != raw['source'] or answer['item']['source_owner'] != raw['source_owner']
                    or answer['item']['recipient_id'] != raw['recipient_id'] or answer['item']['purpose'] != raw['purpose']
                    or answer['item']['consent'] != raw['consent']):
                _fail('INVALID_RECEIPT', '公司回显与原决定或来源不一致')
            receipt = self._status(snapshot, user, row)
            if receipt['state'] != 'recorded':
                _fail('UNKNOWN_RECEIPT', '公司原号暂未核对')
            if not self._same_current(receipt['current_handoff'], echoed):
                _fail('CURRENT_CHANGED', '原接收提交后公司状态已变化，请保留原号读取')
            self._fence(snapshot, user)
            with self.core.lock, self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE'); current = self._row(db, channel, self._actor(db, user))
                if current != row:
                    _fail('ATTEMPT_CONFLICT', '原接收元数据已变化')
                row = self._put(db, {**row, 'state': 'recorded', 'updated_at': int(self.clock()), 'revision': row['revision'] + 1})
                self._commit(db)
            self._fence(snapshot, user)
            return self._result(action, snapshot, item=echoed, row=row, receipt=receipt, dispatched=True, read_only=False)
        except Exception:
            _fail('RESULT_UNKNOWN', '公司接收结果尚未确认，请保留原号只读核对；未自动重发', mutation=None)
