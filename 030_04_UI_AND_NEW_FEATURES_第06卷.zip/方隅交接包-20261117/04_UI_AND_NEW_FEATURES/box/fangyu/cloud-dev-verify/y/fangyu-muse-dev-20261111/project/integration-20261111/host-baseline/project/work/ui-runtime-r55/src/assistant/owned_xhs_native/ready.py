"""Owned about:blank bootstrap facts and an original-owner issue barrier.

File identity/hash and loaded-source observation are not a raw memory proof.
No component policy is created here. Native calls run only under the actual
parent owner; the helper's fixed local snapshot child inherits the same Job.
"""
import copy
import ctypes
from ctypes import wintypes
from contextlib import contextmanager
import hashlib
from pathlib import Path
import threading
import time

from core.adapters import AdapterSafetyRequired
from . import owner, classifier
from .image import NativeProcessImageBinding
from .occupancy import NativeOwnerOccupancyAdapter
from .runtime_materials import _checked_path, current_token_user, digest, fixed_loaded_source

_FACT_KEYS = {'contract', 'helper_pid', 'helper_created', 'helper_image',
    'browser_pid', 'user_data_folder', 'python_modules', 'native_modules',
    'managed_assemblies', 'snapshots'}


def _deny():
    raise AdapterSafetyRequired('page_ready_sources_unconfirmed')


def _paths(value, limit):
    if type(value) not in (list, tuple) or not 0 < len(value) <= limit:
        _deny()
    found = tuple(str(fixed_loaded_source(path)) for path in value
                  if type(path) is str and path)
    if len(found) != len(value) or len(set(path.lower() for path in found)) != len(found):
        _deny()
    return found




class _FILE_INFO(ctypes.Structure):
    _fields_ = [('attributes', wintypes.DWORD), ('created', wintypes.FILETIME),
        ('accessed', wintypes.FILETIME), ('written', wintypes.FILETIME),
        ('volume', wintypes.DWORD), ('size_high', wintypes.DWORD),
        ('size_low', wintypes.DWORD), ('links', wintypes.DWORD),
        ('index_high', wintypes.DWORD), ('index_low', wintypes.DWORD)]


class _FileLease:
    """Retain exact file source, refusing writers/deleters until owned Job exit."""
    def __init__(self, path, expected, role, *, retain):
        self.path = _checked_path(Path(path))
        self.sha, self.role, self.handle = expected.upper(), role, None
        kernel = self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        signatures = {
            'CreateFileW': ([wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE], wintypes.HANDLE),
            'GetFileInformationByHandle': ([wintypes.HANDLE, ctypes.POINTER(_FILE_INFO)], wintypes.BOOL),
            'GetFinalPathNameByHandleW': ([wintypes.HANDLE, wintypes.LPWSTR,
                wintypes.DWORD, wintypes.DWORD], wintypes.DWORD),
            'SetFilePointerEx': ([wintypes.HANDLE, ctypes.c_longlong,
                ctypes.POINTER(ctypes.c_longlong), wintypes.DWORD], wintypes.BOOL),
            'ReadFile': ([wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
                ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p], wintypes.BOOL),
            'CloseHandle': ([wintypes.HANDLE], wintypes.BOOL)}
        for name, (args, result) in signatures.items():
            function = getattr(kernel, name)
            function.argtypes, function.restype = args, result
        # Register the exact object before any external handle can be acquired.
        # A constructor error must leave failed closes reachable by this owner.
        retain(self)
        handle = kernel.CreateFileW(str(self.path), 0x80000000, 1, None, 3, 0x200080, None)
        if not handle or handle == ctypes.c_void_p(-1).value:
            _deny()
        self.handle = handle
        self.identity = self._identity()
        if self._hash() != self.sha:
            _deny()

    def _identity(self):
        if self.handle is None:
            _deny()
        info, final = _FILE_INFO(), ctypes.create_unicode_buffer(32768)
        if (not self.kernel.GetFileInformationByHandle(self.handle, ctypes.byref(info))
                or info.attributes & 0x400 or info.links < 1
                or not 0 < self.kernel.GetFinalPathNameByHandleW(self.handle, final, 32768, 0) < 32768):
            _deny()
        name = final.value
        if name.startswith('\\\\?\\'):
            name = name[4:]
        if _checked_path(Path(name)) != self.path:
            _deny()
        return (int(info.volume), int(info.index_high), int(info.index_low),
                int(info.size_high), int(info.size_low), int(info.written.dwHighDateTime),
                int(info.written.dwLowDateTime))

    def _hash(self):
        if not self.kernel.SetFilePointerEx(self.handle, 0, None, 0):
            _deny()
        found, total, buffer = hashlib.sha256(), 0, ctypes.create_string_buffer(65536)
        while True:
            count = wintypes.DWORD()
            if not self.kernel.ReadFile(self.handle, buffer, len(buffer), ctypes.byref(count), None):
                _deny()
            if count.value == 0:
                break
            total += count.value
            if count.value > len(buffer) or total > 512 * 1024 * 1024:
                _deny()
            found.update(buffer.raw[:count.value])
        return found.hexdigest().upper()

    def check(self, *, hash_bytes=False):
        if self._identity() != self.identity or (hash_bytes and self._hash() != self.sha):
            _deny()

    def close(self):
        if self.handle is not None:
            if not self.kernel.CloseHandle(self.handle):
                _deny()
            self.handle = None


class _NativeReadyProbe:
    """Two source observations on retained exact process handles in original Job."""
    def __init__(self):
        self.image = NativeProcessImageBinding()
        self.handles = {}

    @staticmethod
    def _modules(kernel, handle):
        kernel.K32EnumProcessModulesEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p,
            wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), wintypes.DWORD]
        kernel.K32EnumProcessModulesEx.restype = wintypes.BOOL
        kernel.K32GetModuleFileNameExW.argtypes = [wintypes.HANDLE, wintypes.HMODULE,
            wintypes.LPWSTR, wintypes.DWORD]
        kernel.K32GetModuleFileNameExW.restype = wintypes.DWORD
        modules, needed = (wintypes.HMODULE * 2048)(), wintypes.DWORD()
        if (not kernel.K32EnumProcessModulesEx(handle, ctypes.byref(modules),
                ctypes.sizeof(modules), ctypes.byref(needed), 3)
                or not 0 < needed.value <= ctypes.sizeof(modules)
                or needed.value % ctypes.sizeof(wintypes.HMODULE)):
            _deny()
        paths = []
        for value in modules[:needed.value // ctypes.sizeof(wintypes.HMODULE)]:
            path = ctypes.create_unicode_buffer(32768)
            if not 0 < kernel.K32GetModuleFileNameExW(handle, value, path, len(path)) < len(path) - 1:
                _deny()
            paths.append(str(fixed_loaded_source(path.value)))
        # HMODULE is an enumeration value, not an owned handle to close.
        return tuple(sorted(set(paths), key=str.lower))

    def capture(self, process, pid, created, expected_image, sid, *, cim_precision=False):
        from assistant.owned_native_job import WindowsOwnedJobProcess
        if (type(process) is not WindowsOwnedJobProcess or process.closed or process.job is None
                or type(created) is not int or created <= 0):
            _deny()
        retained = (process.process, process.job, process.pid)
        kernel, advapi = self.image._native(owner)
        retained_handle = self.handles.get(pid)
        if retained_handle is None:
            handle = kernel.OpenProcess(0x410, False, pid)
            if not handle:
                _deny()
            self.handles[pid] = (kernel, handle)
        else:
            kernel, handle = retained_handle
        try:
            observations = []
            for _ in range(2):
                self.image._running(kernel, handle, owner)
                self.image._job(kernel, handle, process.job)
                identity = self.image._identity(kernel, advapi, handle, owner, classifier, {})
                # Only the browser's CIM row has the original WMI microsecond
                # rounding. The actual two Native identities remain exact.
                same_creation = (0 <= identity['created'] - created <= 9
                                 if cim_precision else identity['created'] == created)
                if (identity['pid'] != pid or not same_creation
                        or identity['sid'] != sid
                        or identity['image'] != classifier.canonical_path(expected_image)
                        or process.contains(pid, created) is not True):
                    _deny()
                observations.append((identity, self._modules(kernel, handle)))
            if (observations[0] != observations[1]
                    or (process.process, process.job, process.pid) != retained
                    or current_token_user() != sid):
                _deny()
            return observations[0]
        except Exception:
            # Keep a failed-to-close owned query handle for physical retry.
            if kernel.CloseHandle(handle):
                self.handles.pop(pid, None)
            raise

    def close(self):
        failed = False
        for pid, (kernel, handle) in tuple(self.handles.items()):
            try:
                if not kernel.CloseHandle(handle):
                    failed = True
                else:
                    self.handles.pop(pid)
            except Exception:
                failed = True
        if failed:
            _deny()


class _ReadySetupPending(RuntimeError):
    """Only this original transport/Scope retries exact pre-process resources."""
    def __init__(self, guard):
        self.guard = guard
        super().__init__('owned_ready_setup_cleanup_pending')


class _ReadyGuard:
    """Only an original owner can consume local facts or publish a page call."""
    def __init__(self, server, decision, scope, spec, pre_resume):
        from assistant.xhs_page_read_policy import _PageReadDecision
        from assistant.xhs_identity_policy import _IdentityObservationDecision
        from assistant.xhs_session_policy import _SessionRecoveryDecision
        identity = type(decision) is _IdentityObservationDecision
        session = type(decision) is _SessionRecoveryDecision
        if (type(decision) not in (_PageReadDecision, _IdentityObservationDecision, _SessionRecoveryDecision)
                or decision.policy is not getattr(server,
                    '_xhs_session_policy' if session else '_xhs_identity_policy' if identity else '_xhs_page_read_policy', None)):
            _deny()
        self.server, self.decision, self.scope, self.spec = server, decision, scope, spec
        self.pre_resume, self.thread = pre_resume, threading.current_thread()
        self.process = self.retained = self.facts = None
        self.verified_at = None
        self.issued = 0
        self.leases = []
        self.probe = _NativeReadyProbe()
        try:
            self._check()
            for path, sha, role in decision.expected_materials:
                _FileLease(path, sha, role, retain=self.leases.append)
            self._check()
        except Exception:
            try:
                self._close_files()
            except Exception:
                raise _ReadySetupPending(self) from None
            raise

    def _check(self):
        if threading.current_thread() is not self.thread:
            _deny()
        self.scope.check()
        self.decision.check(self.scope, self.spec, self.scope.app_context)
        if digest(self.pre_resume.spec_path) != self.pre_resume.spec_hash:
            _deny()
        if self.process is not None and (self.process.closed or
                (self.process.process, self.process.job, self.process.pid) != self.retained):
            _deny()

    def bind(self, process):
        from assistant.owned_native_job import WindowsOwnedJobProcess
        if self.process is not None or type(process) is not WindowsOwnedJobProcess:
            _deny()
        self.process, self.retained = process, (process.process, process.job, process.pid)
        process._page_ready_guard = self

    @property
    def bootstrap_required(self):
        # Only the new typed policy branch can populate this private field.
        return getattr(self.decision, 'customer', None) is not None

    def bootstrap(self, body):
        """Owner-thread pre-window barrier; never page/identity approval."""
        self._check()
        if (not self.bootstrap_required or type(body) is not dict
                or self.process is None or self.process.closed
                or body.get('helper_pid') != self.process.pid
                or type(body.get('helper_created')) is not int or not 1 <= body['helper_created'] <= 0xffffffffffffffff
                or body.get('spec_sha256') != self.pre_resume.spec_hash
                or self.pre_resume._verified_process is not self.process
                or self.pre_resume._verified_handles != self.retained
                or self.pre_resume._resume_submitted is not True):
            _deny()
        # The compiled bootstrap carries raw WinAPI FILETIME, while the
        # original owner and the old ready facts use .NET ticks.
        created=body['helper_created']+owner.DOTNET_FILETIME_EPOCH
        self.probe.capture(self.process, body['helper_pid'], created,
            self.pre_resume.command.argv[0], self.pre_resume.sid)
        self._check()

    def verify(self, raw):
        self._check()
        customer=getattr(self.decision,'customer',None)
        keys=_FACT_KEYS|{'code_origins'} if customer is not None else _FACT_KEYS
        if self.facts is not None or type(raw) is not dict or set(raw) != keys:
            _deny()
        raw = copy.deepcopy(raw)
        if customer is not None:
            from portable_helper_package import check_code_origins
            if (raw['contract']!='owned_blank_window_sources_v2'
                    or check_code_origins(raw['code_origins'],customer.raw['package'],customer.raw['helper_root']) is not True):
                _deny()
        if (raw['contract'] != ('owned_blank_window_sources_v2' if customer is not None else 'owned_blank_window_sources_v1')
                or type(raw['helper_pid']) is not int or type(raw['browser_pid']) is not int
                or raw['helper_pid'] == raw['browser_pid']
                or type(raw['helper_created']) is not int
                or type(raw['snapshots']) is not list or len(raw['snapshots']) != 2
                or _checked_path(Path(raw['user_data_folder'])) != self.spec.profile_dir):
            _deny()
        python = _paths(raw['python_modules'], 2048)
        native = _paths(raw['native_modules'], 2048)
        managed = _paths(raw['managed_assemblies'], 512)
        snapshots = iter(raw['snapshots'])
        browser = next((row for row in raw['snapshots'][-1].get('processes', [])
                        if row.get('pid') == raw['browser_pid']), None)
        if browser is None:
            _deny()
        sid = self.pre_resume.sid
        expected_python = self.pre_resume.binding.executable(raw['helper_image'], sid, sid)
        if classifier.canonical_path(expected_python) != classifier.canonical_path(raw['helper_image']):
            _deny()
        helper_identity, actual_native = self.probe.capture(self.process, raw['helper_pid'],
            raw['helper_created'], raw['helper_image'], sid)
        browser_identity, browser_modules = self.probe.capture(self.process, raw['browser_pid'],
            browser['created'], browser['executable'], sid, cim_precision=True)
        if (tuple(path.lower() for path in sorted(native, key=str.lower)) !=
                tuple(path.lower() for path in actual_native)
                or browser_identity['image'] not in {classifier.canonical_path(path)
                    for path, sha, role in self.decision.expected_materials
                    if role == 'webview_runtime'}):
            _deny()
        occupancy = NativeOwnerOccupancyAdapter().classify(self.spec.profile_dir,
            snapshot_provider=lambda: next(snapshots), current_sid_provider=current_token_user,
            owned=self.process.contains, expected_browser=browser['executable'],
            trusted_python=self.pre_resume.binding, owned_context=self)
        if occupancy.get('state') != 'vacant':
            _deny()
        for lease in self.leases:
            lease.check(hash_bytes=True)
        facts = {'contract': 'page_ready_sources_v1',
            'helper_pid': helper_identity['pid'], 'helper_created': helper_identity['created'],
            'helper_image': helper_identity['image'], 'browser_pid': browser_identity['pid'],
            'browser_created': browser_identity['created'], 'browser_image': browser_identity['image'],
            'user_data_folder': str(self.spec.profile_dir), 'python_modules': python,
            'native_modules': actual_native, 'browser_modules': browser_modules,
            'managed_assemblies': managed,
            'bound_materials': tuple((str(lease.path), lease.sha, lease.role, lease.identity)
                                     for lease in self.leases),
            'job_membership_verified': True, 'loaded_sources_verified': True,
            'profile_vacancy_verified': True, 'native_loaded_bytes_verified': False}
        if customer is not None:
            facts['portable_code_origins_checked']=True
            facts['helper_package_sha256']=customer.raw['manifest_sha256']
        self.decision.check_materials(facts)
        self._check()
        self.facts, self.verified_at = facts, time.monotonic()

    def validate(self):
        self._check()
        return True

    def contains(self, pid, created):
        self._check()
        if self.process.contains(pid, created) is not True:
            _deny()
        self._check()
        return True

    @contextmanager
    def issue(self):
        # Slow source/hash reads before locks; wait for IPC outside this context.
        self._check()
        if self.facts is None or (self.issued == 0 and time.monotonic() - self.verified_at > 15):
            _deny()
        for lease in self.leases:
            lease.check()
        self.decision.check_materials(self.facts)
        with self.scope.runtime.core.lock:
            with self.scope.runtime.lock:
                self._check()
                yield
                self.issued += 1

    def close_after_process(self):
        # Physical cleanup never depends on current licence/context/cancellation.
        if self.process is None or not self.process.closed:
            _deny()
        self._close_files()

    def abort_before_process(self):
        if self.process is not None:
            _deny()
        try:
            self._close_files()
        except Exception:
            raise _ReadySetupPending(self) from None

    def _close_files(self):
        failed = False
        try:
            self.probe.close()
        except Exception:
            failed = True
        for lease in self.leases:
            try:
                lease.close()
            except Exception:
                failed = True
        if failed:
            _deny()
