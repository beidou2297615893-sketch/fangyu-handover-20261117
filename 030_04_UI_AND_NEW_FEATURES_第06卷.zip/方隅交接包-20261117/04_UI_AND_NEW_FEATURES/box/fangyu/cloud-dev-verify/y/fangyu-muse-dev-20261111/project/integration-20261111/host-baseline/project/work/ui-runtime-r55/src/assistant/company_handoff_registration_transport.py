"""One explicit register HTTP request; never refresh, retry or reveal contacts."""
from copy import deepcopy
import re

from .company_handoff_status_transport import CompanyHandoffStatusTransport, CompanyHandoffStatusTransportError

ACTION = 'acquisition_channel_register'
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_UUID = re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z')
_PLATFORM = re.compile(r'platform:xiaohongshu:[A-Za-z0-9_-]{1,160}\Z')


class CompanyHandoffRegistrationTransportError(ValueError):
    def __init__(self, code, message, status=503, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_REGISTRATION_TRANSPORT_' + code
        self.status, self.mutation_committed = status, mutation_committed


def _fail(code, message, status=503, *, mutation=False):
    raise CompanyHandoffRegistrationTransportError(code, message, status, mutation)


class CompanyHandoffRegistrationTransport(CompanyHandoffStatusTransport):
    def _registration_capture(self, actor, margin, *, dispatched=False):
        try:
            return self._capture(actor, margin)
        except CompanyHandoffStatusTransportError as error:
            session = error.code.endswith('_SESSION_REQUIRED')
            _fail('SESSION_REQUIRED' if session else 'BINDING_CHANGED',
                '当前公司连接或本人范围需核对，请保留原登记编号', 409,
                mutation=None if dispatched else False)

    def __call__(self, actor, operation, data):
        fields = {'environment_id', 'operation', 'source_event_id', 'recipient_id', 'purpose',
            'consent', 'contact_reference', 'qualification', 'idempotency_key'}
        consent = data.get('consent') if isinstance(data, dict) else None
        if (operation != ACTION or not isinstance(data, dict) or set(data) != fields
                or data.get('operation') != ACTION or data.get('environment_id') != self.environment_id
                or not isinstance(data.get('idempotency_key'), str) or not _HEX.fullmatch(data['idempotency_key'])
                or not isinstance(data.get('source_event_id'), str) or not _UUID.fullmatch(data['source_event_id'])
                or not isinstance(data.get('contact_reference'), str) or not _PLATFORM.fullmatch(data['contact_reference'])
                or data.get('qualification') != 'qualified' or not isinstance(data.get('recipient_id'), str)
                or not data['recipient_id'] or not isinstance(data.get('purpose'), str) or not data['purpose'].strip()
                or not isinstance(consent, dict) or set(consent) != {'status', 'evidence_reference', 'notice_version'}
                or consent.get('status') != 'granted' or not isinstance(consent.get('evidence_reference'), str)
                or re.fullmatch(r'consent:[a-f0-9]{32}', consent['evidence_reference']) is None
                or not isinstance(consent.get('notice_version'), str) or not consent['notice_version'].strip()):
            _fail('INVALID_REQUEST', '公司登记须来自当前原准备，不能输入新编号或受保护联系方式', 400)
        before = self._registration_capture(actor, 60)
        from integrations import request_json
        # From this point even an HTTP/business error is not a no-dispatch proof.
        try:
            result = request_json(before['endpoint'], deepcopy(data), before['token'])
        except Exception:
            _fail('RESULT_UNKNOWN', '原公司登记结果尚未确认，请保留原号只读核对；未自动重发', mutation=None)
        after = self._registration_capture(actor, 0, dispatched=True)
        if after != before:
            _fail('BINDING_CHANGED', '登记返回时连接或本人范围已变化，请保留原号', 409, mutation=None)
        fields = {'contract', 'environment_id', 'company_id', 'item', 'replayed', 'server_recorded',
            'platform_delivery_verified', 'attribution_confirmed', 'settlement_active'}
        if (not isinstance(result, dict) or set(result) != fields or result.get('contract') != 'fangyu-workspace-v1'
                or result.get('environment_id') != self.environment_id or result.get('company_id') != self.company_id
                or not isinstance(result.get('item'), dict) or type(result.get('replayed')) is not bool
                or result.get('server_recorded') is not True
                or any(result.get(key) is not False for key in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))):
            _fail('RESULT_UNKNOWN', '原公司登记回执身份或格式需核对，请保留原号', mutation=None)
        try:
            self._principal(actor)
        except CompanyHandoffStatusTransportError:
            _fail('BINDING_CHANGED', '返回时员工或公司范围已变化，请保留原号', 409, mutation=None)
        return {key: deepcopy(result[key]) for key in ('item', 'replayed')}
