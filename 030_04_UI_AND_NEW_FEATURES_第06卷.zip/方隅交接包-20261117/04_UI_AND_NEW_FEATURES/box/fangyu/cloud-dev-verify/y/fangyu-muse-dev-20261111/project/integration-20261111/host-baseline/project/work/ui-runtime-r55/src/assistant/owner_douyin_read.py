"""Local owner's explicit Douyin window and one video page, never an employee grant.

The independent instance-local review is absent/pending by default. XHS's
guarded component decision does not select or authorize this Node bridge.
"""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess
import threading

from core import CoreError
from core.adapters import account_execution_lock, AdapterBusy
from core.runtime_license_policy import _plain, _file_hash

_SEAL=object()
_PURPOSE='owner_douyin_connection_video_comments_v1'
_FILE='owner-douyin-read-review.json'
_ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_UID=re.compile(r'[0-9]{1,160}\Z')
_REQUEST=re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{7,127}\Z')
_SOURCE=Path(__file__).parent.parent
_OWNER_RUNTIME_RELATIVE='app/work/runtime/dy/douyin-bridge-source-cid-v1'


def owner_runtime_root():
    """Fixed source-owned component revision; no request/env runtime selection."""
    return _SOURCE.parent/'work/runtime/dy/douyin-bridge-source-cid-v1'


_SOURCES=('app.py','assistant/self_operating_read.py','assistant/owner_douyin_read.py',
          'account_connections.py','core/adapters.py','core/platform_reads.py',
          'web/workspace/self-operating-read.mjs')
_ACTOR=('id','tenant_id','username','role','personal_owner','disabled','cloud_bound','permission_revision')
_LIMITS={'comments_page':1,'max_comments':20,'search':False,'archive':False,'AI':False,
         'reply':False,'dm':False,'auto_retry':False,'real_platform_verified':False}
_FIXED_MATERIALS=({'bytes': 86997320,
  'path': 'node.exe',
  'role': 'runtime_binary',
  'root': 'douyin_runtime',
  'sha256': '0D0F5E39F9F3D9587BC19F73EAB3C2C9C4903FD02D6DBF9C853DD81B3D95FAD4'},
 {'bytes': 148217,
  'path': 'NODE-LICENSE.txt',
  'role': 'license',
  'root': 'douyin_runtime',
  'sha256': '8CC9BB466B19FC7E7CC99D03E9DF1132021FDA8B01EEA2624C58BB372DBEF576'},
 {'bytes': 1065,
  'path': 'LICENSE',
  'role': 'license',
  'root': 'douyin_runtime',
  'sha256': '3723B8DAE8C5E727627EB68F8DBCD46DEF7132A18BF50427F689D9CD41D3F9DA'},
 {'bytes': 1003,
  'path': 'package.json',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '1E3C5EBC7877F2E7BE71067472D7283934CE593B88A837E79134FBCB94BB13AF'},
 {'bytes': 85751,
  'path': 'package-lock.json',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '994ADAF49A1C318E64C2B00365E706C6BBC9FC472C3E78C1C4D36DD23585C70A'},
 {'bytes': 7223,
  'path': 'cli.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '69BC6B924EB36D82D192D1E02D94DBFE002AE1E15A25D2EDBD88EA7FD5159520'},
 {'bytes': 2615,
  'path': 'server.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '1BBCAF66CA093137754BA2F022AE7E91045C73B42C26FC0FE8FEE34F5E5D0F5B'},
 {'bytes': 52661,
  'path': 'scripts/douyin.user.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '2E027A1CA512B57E7F32349B1D3E54CC3FF81704BEC903BA2135000927F1925D'},
 {'bytes': 7069,
  'path': 'lib/audit.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '3D98B008FC10E2BE06C4527E6D108E0AE8F81822B7F532F3D191ED2C739C3C0F'},
 {'bytes': 2950,
  'path': 'lib/client/bridge-client.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '5F317D182E43443723C439C14B808ADE963507518AA1EDDB9F5892B7ACAB5B3A'},
 {'bytes': 1960,
  'path': 'lib/commands/comment-page.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '5C6D43D923425633D2BCFFDC2AB1EE2BA6A5F1D991E864B20F3E411B24C5DB0F'},
 {'bytes': 4065,
  'path': 'lib/commands/dm.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'D13E1BBD3236588C82CB8E68CC9B6F588D9A3F298FE600F8D4C9265CD045B8C3'},
 {'bytes': 7797,
  'path': 'lib/commands/get.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '49219E653E3A08CBF3AE690FEAA7B25A87EB40B5D96894D849B3CCCEA7F903D6'},
 {'bytes': 2229,
  'path': 'lib/commands/helpers.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '05F2ABFA6B5509AAAEF3BAF0BA3CEE02AD505BEFF9D18A688E996C1694F29922'},
 {'bytes': 191,
  'path': 'lib/commands/index.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '0A89724D6249C31E4AC81BDA7A698D9BE3F177E273B5887C129C5AB35EB84685'},
 {'bytes': 5590,
  'path': 'lib/commands/post.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '3CCC6219681990B199A60CC148249400CDF6141F1197568F0FF14C6AA7313C62'},
 {'bytes': 2083,
  'path': 'lib/commands/replies.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '36C3F6D4B03948262A5EED7151404D8863BC26356482081B65D24F4C026802B2'},
 {'bytes': 1875,
  'path': 'lib/commands/search.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '6C5B7742BEFE4CFFBC30D2886DD45229E8057F67BAFEE803F87A5FEA4B0D8509'},
 {'bytes': 9948,
  'path': 'lib/memory/comments.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'BF6A345361950E0F4887C9612859A3A1AFA73E933494FAB6BDC0CF5D7D6DB581'},
 {'bytes': 7326,
  'path': 'lib/memory/corpus.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'D7185A202B6D2D96875CE3548799F8E27825C76B0F0E6EA9B2E5FEBE77B005E8'},
 {'bytes': 11619,
  'path': 'lib/memory/db.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '04AAEB5BD15BD4B7A49A5A611C605B2D509225FD4BA0834761C29ED403477870'},
 {'bytes': 6477,
  'path': 'lib/memory/events.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'BB564B5FDA3E6A8A038676BDF093F671AB74E415844767A2A23DA29ED0C368CC'},
 {'bytes': 5359,
  'path': 'lib/memory/failures.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '7A845236F23CB19165F55716807F70F8E8EFCE05059A339C10D766C7A7404FD4'},
 {'bytes': 8088,
  'path': 'lib/memory/users.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '8AAB0FE75204428A110D290C0FD8A592DB821CD4A44FE2F227ED2B16A3EA34D0'},
 {'bytes': 4339,
  'path': 'lib/memory/videos.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '9C841C4688162DFF05DFFF7E3DA9386CB4981D34678E4FACB2ED30318AB4B216'},
 {'bytes': 1550,
  'path': 'lib/miniapp-delivery-state.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '413595FE7E00C90DD2AB7B3887C4360FB9D6B23E1D43BCC320C7226C234EF091'},
 {'bytes': 12622,
  'path': 'lib/risk-control.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '827B3088CFF713681C8B62C4259CA6120100D443588D219C82AF5F81D6E33331'},
 {'bytes': 5699,
  'path': 'lib/server/registry.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '4A53DD676783E49A95EED44130409CA6274E42A2D25CD63093AA180FB5DCBDA2'},
 {'bytes': 18002,
  'path': 'lib/server/router.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '53694032009C1371A840C4DA7EAC81F164E004F83C83BE239C504AD6D62BFF93'},
 {'bytes': 6702,
  'path': 'lib/server/ws-hub.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '1F294BB1F7479BB2FBF6920521F89F1A6AB3DBA35B4F6FBB4EF50E417AFDFFFD'},
 {'bytes': 2735,
  'path': 'lib/shared/protocol.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'EE0911952FF57A052DE38F2A1DADCAD0DD87653DC58401F273537081A353CB4C'},
 {'bytes': 1181,
  'path': 'lib/shared/serialize.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '36277BB4264984E4528D1E94DCD8D7E28A6490801C60B22848D7B5707C8CFF4F'},
 {'bytes': 1753,
  'path': 'node_modules/ws/package.json',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '584CE6E7516587BA249DC910B0C04E2753F6B3F451FC3A5BC324F7735BDACC71'},
 {'bytes': 1183,
  'path': 'node_modules/ws/LICENSE',
  'role': 'license',
  'root': 'douyin_runtime',
  'sha256': '2B29DCFE0D6471F7E8C92C5FB38C9F93EDEE10330937055440192F1832B1ECEF'},
 {'bytes': 796,
  'path': 'node_modules/ws/index.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '924564D5BE26D59B9682C4263F68320E48DDE7240BD2D1AD17EC305537429DD2'},
 {'bytes': 176,
  'path': 'node_modules/ws/browser.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '010DA44ADDEA1D88B2B732540C3F1FD0CBCB28926B96623D4C64222E0EAD2D0E'},
 {'bytes': 554,
  'path': 'node_modules/ws/wrapper.mjs',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'FE154662301FD558F935F9C217FCCBE7A7DAC02FF39E648A000589403FF27C7F'},
 {'bytes': 3056,
  'path': 'node_modules/ws/lib/buffer-util.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '8B0A45739132F82E25EA13163780ABF547CCFE989267F3EB7ABB475BEEC92DA3'},
 {'bytes': 503,
  'path': 'node_modules/ws/lib/constants.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '391E823142B8B370E55A2FD32B022DEAF03B8415C56000009674EBC86A0B4F86'},
 {'bytes': 7321,
  'path': 'node_modules/ws/lib/event-target.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'C45D3C6E12D170C860C0C3F1A050AA0F864D9806632B609A1E607D675ABA128C'},
 {'bytes': 6183,
  'path': 'node_modules/ws/lib/extension.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '852564F0F6B460287043803EAE732666FB5610F676874354FC89F06AA4E986ED'},
 {'bytes': 1034,
  'path': 'node_modules/ws/lib/limiter.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'E0469D4B83F6BA764B15F80E1766B75C136FBFF68F048F4C050F0B1C7F065F69'},
 {'bytes': 14532,
  'path': 'node_modules/ws/lib/permessage-deflate.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '02C31796F0132A335D4EFE7B7ADCEBADBB69543A1CE65AE04AACCC3530E27AB9'},
 {'bytes': 17802,
  'path': 'node_modules/ws/lib/receiver.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '4879EDBF8E48D04D09783CF9C04B5E25F5A448247BB01279438DED2899747220'},
 {'bytes': 16886,
  'path': 'node_modules/ws/lib/sender.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'D0791D30C3DEFD44DCABBDDB879A901C757993FEA2C00A7FFEA01D53B23B4B77'},
 {'bytes': 4204,
  'path': 'node_modules/ws/lib/stream.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'A56FCB6E2B152097EE820B6F5410B1F71E59819B45D08D9F8BDA588FE39070EC'},
 {'bytes': 1498,
  'path': 'node_modules/ws/lib/subprotocol.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': 'BE3F6323D6F549568577DCBA9004C1479D95C65A7ABB0FE0C582875B9FAC0B7C'},
 {'bytes': 3903,
  'path': 'node_modules/ws/lib/validation.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '41CE8E83D0D434132E1704895FEDB91F6703A701B42D91C80954AB29B2845593'},
 {'bytes': 17026,
  'path': 'node_modules/ws/lib/websocket-server.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '29029A4D346800C792300DF153DF2007E9805D9D7B67B0883F9730B64F25B1C8'},
 {'bytes': 37371,
  'path': 'node_modules/ws/lib/websocket.js',
  'role': 'source_or_declared_dependency',
  'root': 'douyin_runtime',
  'sha256': '48FDB0F54C1F8CE580D3CFA2908FE7D96FE18F06F9D82306950441CB09B5DB26'},
 {'bytes': 12008,
  'path': 'bridge.py',
  'role': 'source_or_declared_dependency',
  'root': 'source',
  'sha256': 'FB2493CE874CAB828B1D40E5E4698D1223CA2EB2F7A6937F44901403B4BCC8DD'},
 {'bytes': 5199,
  'path': 'managed_platform_window.py',
  'role': 'source_or_declared_dependency',
  'root': 'source',
  'sha256': 'A41868F18FDBC6783B8C731042E0582A7C1E9D344B9D593EEF0B3BD0B0E3F5EA'},
 {'bytes': 10263,
  'path': 'core/runtime_license_policy.py',
  'role': 'license',
  'root': 'source',
  'sha256': '013C4BB952E8650F9C30DE9A9F73FD03D4C20712C8D1D8C60569432F69F6DA4A'},
 {'bytes': 1210,
  'path': 'resources/adapters/douyin.json',
  'role': 'source_or_declared_dependency',
  'root': 'source',
  'sha256': 'CF027A018A99ED47F3D55CA4A81BDA513225AB99D3E5DC295DB0890FE572BA70'},
 {'bytes': 1086,
  'path': 'resources/licenses/douyin-yht-MIT.txt',
  'role': 'license',
  'root': 'source',
  'sha256': '536BC3F02996E21CA989573111764C8A26D67DC6676E965C5D7F176A4B504ABE'},
 {'bytes': 5717,
  'path': 'resources/licenses/douyin-bridge-dependencies.json',
  'role': 'license',
  'root': 'source',
  'sha256': '821531FE8AA58D3D7BDBA8B04D72EFDA699449251D0A216873D8DEFF88EC2479'},
 {'bytes': 13045,
  'path': 'core/douyin_owned_comments.py',
  'role': 'source_or_declared_dependency',
  'root': 'source',
  'sha256': '0CF353FDA6CAEE5829C801E1416D91AFAB185499111C6B0313D801A77682F344'},
 {'bytes': 2245,
  'path': 'core/douyin_pages.py',
  'role': 'source_or_declared_dependency',
  'root': 'source',
  'sha256': 'E47571AB9367D49C1D20390CD388BCF813EE126183A4DB152D58C062A9C61CEC'},
 {'bytes': 15679,
  'path': 'assistant/douyin_connection_service.py',
  'role': 'source_or_declared_dependency',
  'root': 'source',
  'sha256': '6A9C77F86E9542082483E26C4C743996BAD5C7AA5B23E0B649D44C4F4C34B57A'})


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()


def source_revision():
    return _digest({name:_file_hash(_plain(_SOURCE/name,_SOURCE)) for name in _SOURCES})


def _binding(user,account,instance):
    return {'actor':{k:user.get(k) for k in _ACTOR},'instance_id':instance,
            'account':{k:account.get(k) for k in ('id','tenant_id','platform','cloud_owner','platform_uid','conn_id')}}


def _metadata_current(original,current):
    # Same owner/instance/account may cancel its retained old process after a
    # manual UID/conn/risk change; this can never publish content or spawn.
    return (type(original) is dict and type(original.get('actor')) is dict
            and all(original['actor'].get(k)==current['actor'].get(k)
                    for k in ('id','tenant_id','username','role','cloud_bound'))
            and original.get('instance_id')==current['instance_id']
            and type(original.get('account')) is dict
            and all(original['account'].get(k)==current['account'].get(k)
                    for k in ('id','tenant_id','platform','cloud_owner')))


def _home(path,root):
    current=Path(root)
    for part in ('',*Path(path).relative_to(root).parts):
        if part:current=current/part
        try:attrs=current.lstat()
        except FileNotFoundError:continue
        if (not stat.S_ISDIR(attrs.st_mode) or current.is_symlink()
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
            raise ValueError('本人账号目录不能链接或重定向')
    return Path(path)


class _Purpose:
    def __init__(self,helper):self.helper=helper

    def review(self,*,materials=False):
        helper=self.helper;server=helper.server;config=helper.workspace.instance.check()
        instance=config['selfOperatingRead']['instance_id']
        if (config!=server.company or config['selfOperatingRead']['schema']!='owner_read_instance_v2'
                or config['platforms']!=['xiaohongshu','douyin','wechat_channels']
                or server._runtime_license_usage_scope('internal_self_use_read')!='internal_self_use_read'):
            raise ValueError('此实例尚未选择独立三主平台自营用途')
        from bridge import BridgeManager
        runtime=owner_runtime_root()
        if type(server.bridge) is not BridgeManager or server.bridge.runtime!=runtime:
            raise ValueError('原抖音运行组件未装配')
        path=_plain(helper.workspace.instance.directory/_FILE,helper.workspace.instance.directory)
        attrs=path.stat()
        if attrs.st_size>131072 or attrs.st_nlink!=1:raise ValueError('抖音用途材料文件无效')
        raw=path.read_bytes();value=json.loads(raw)
        if (type(value) is not dict or set(value)!={'schema','purpose','scope','instance_id','company_id',
                'source_revision','runtime_relative','limits','materials','decision'}
                or type(value['schema']) is not int or value['schema']!=1
                or value['purpose']!=_PURPOSE or value['scope']!='internal_self_use_read'
                or value['instance_id']!=instance or value['company_id']!=config['id']
                or value['runtime_relative']!=_OWNER_RUNTIME_RELATIVE
                or value['limits']!=_LIMITS or type(value['materials']) is not list
                or value['materials']!=list(_FIXED_MATERIALS)):
            raise ValueError('此抖音实例用途仍待独立审查')
        decision=value['decision']
        if (type(decision) is not dict or set(decision)!={'id','reviewer','internal_technical_use',
                'production_distribution','account_authorization','real_platform_verified'}
                or type(decision['id']) is not str or not _ID.fullmatch(decision['id'])
                or type(decision['reviewer']) is not str or not 1<=len(decision['reviewer'])<=160
                or any(ord(c)<32 for c in decision['reviewer'])
                or decision['internal_technical_use'] is not True
                or decision['production_distribution'] is not False
                or decision['account_authorization'] is not False
                or decision['real_platform_verified'] is not False):
            raise ValueError('组件技术审查不能作为账号或生产批准')
        if value['source_revision']!=source_revision():raise ValueError('本用途源码版本已变化')
        if materials:
            seen=set();has_node=has_cli=has_script=has_license=False
            for item in value['materials']:
                if (type(item) is not dict or set(item)!={'root','path','sha256','bytes','role'}
                        or item['root'] not in ('source','douyin_runtime')
                        or type(item['path']) is not str or '\\' in item['path'] or ':' in item['path']
                        or any(p in ('','.','..') for p in item['path'].split('/'))
                        or (item['root'],item['path']) in seen or type(item['bytes']) is not int
                        or item['bytes']<0 or type(item['sha256']) is not str
                        or re.fullmatch(r'[0-9A-F]{64}',item['sha256']) is None
                        or item['role'] not in ('license','runtime_binary','source_or_declared_dependency')):
                    raise ValueError('抖音组件材料不符合固定约定')
                root=runtime if item['root']=='douyin_runtime' else _SOURCE
                file=_plain(root/item['path'],root);before=file.stat()
                if before.st_nlink!=1 or before.st_size!=item['bytes'] or _file_hash(file).upper()!=item['sha256']:
                    raise ValueError('抖音组件材料已变化')
                after=file.stat()
                if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(
                        after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
                    raise ValueError('读取期间抖音组件材料已变化')
                seen.add((item['root'],item['path']))
                if item['root']=='douyin_runtime':
                    has_node|=item['path']=='node.exe' and item['role']=='runtime_binary'
                    has_cli|=item['path']=='cli.js'
                    has_script|=item['path']=='scripts/douyin.user.js'
                    has_license|=item['role']=='license'
            if not all((has_node,has_cli,has_script,has_license)):
                raise ValueError('抖音 Node/桥及许可材料不完整')
            if any((runtime/'node_modules'/n).exists() for n in ('bufferutil','utf-8-validate')):
                raise ValueError('发现本用途未核的可选组件')
        manifest=server.core.adapters.manifest('douyin')
        expected=[str(runtime/'cli.js'),'comment-page','{source_id}','--count','{limit}',
                  '--cursor','{cursor}','--conn-id','{conn_id}','--no-store','--no-log']
        if (manifest.get('comments_args')!=expected or Path(manifest.get('executable',''))!=runtime/'node.exe'
                or manifest.get('prefix_args') not in (None,[]) or manifest.get('env') not in (None,{})
                or manifest.get('mapper')!='douyin_bridge' or manifest.get('paged_comments') is not True
                or manifest.get('isolation_guard') is not True):
            raise ValueError('本用途固定评论命令或环境已变化')
        if path.read_bytes()!=raw:raise ValueError('抖音用途文件读取期间变化')
        return hashlib.sha256(raw).hexdigest(),value

    def current(self,digest):
        if self.review()[0]!=digest:raise ValueError('本实例抖音用途决定已变化')


class OwnerDouyinRead:
    ACTIONS=('owner_douyin_connection_start','owner_douyin_connection_status',
             'owner_douyin_comments','owner_douyin_read_status','owner_douyin_read_cancel')

    def __init__(self,workspace):
        from .self_operating_read import OwnerReadWorkspace
        if type(workspace) is not OwnerReadWorkspace:raise ValueError('只接可信本人自营工作台')
        self.workspace=workspace;self.server=workspace.server;self.core=self.server.core
        self.purpose=_Purpose(self);self.scope=_OwnerDouyinScope(self,_SEAL)
        self._tls=threading.local();self._lock=threading.RLock();self._connection_lock=threading.Lock()
        self.pending={};self.closed=False

    def read_service_options(self):return {'owner_douyin_scope':self.scope}

    def bind_read_service(self,reads):
        from core.platform_reads import PlatformReadService
        if (type(reads) is not PlatformReadService or reads.core is not self.core
                or reads._owner_douyin_scope is not self.scope or self.scope.reads is not None
                or self.workspace._reads is not reads):raise ValueError('须绑定原本人读取服务')
        self.scope.reads=reads

    def _account(self,token,ident,*,metadata=False,reading=False):
        config=self.workspace.instance.check()
        if (config['selfOperatingRead']['schema']!='owner_read_instance_v2'
                or config['platforms']!=['xiaohongshu','douyin','wechat_channels']):
            raise CoreError('此实例未选择新的三主平台产品，不修改旧标记')
        user=self.workspace._actor(token)
        with self.core.lock:
            account=self.core._get('accounts',ident,user['tenant_id']);self.core._account_access(user,account)
            uid=account.get('platform_uid')
            if (account.get('platform')!='douyin' or account.get('cloud_owner')!=user['username']
                    or not metadata and (type(uid) is not str or not _UID.fullmatch(uid) or not uid.strip('0'))):
                raise CoreError('请先登记明确已知UID的本人抖音账号；未知身份不自动就绪')
            if not metadata:
                if (account.get('requires_review') not in (None,False)
                        or account.get('risk_state') not in (None,'','normal','safe')
                        or account.get('status') not in (('ready',) if reading else
                            ('login_required','logging_in','unverified','ready'))):
                    raise CoreError('此本人账号的身份或风险尚需核实')
                if any(a['id']!=account['id'] and a.get('platform')=='douyin' and a.get('platform_uid')==uid
                       for a in self.core.store.list('accounts',user['tenant_id'])):
                    raise CoreError('同一本人UID存在重复账号记录')
            return user,deepcopy(account)

    def _safe(self,user,account):
        directory=_home(self.core.store.directory/'accounts'/user['tenant_id']/account['id'],self.core.store.directory)
        self.core.adapters.require_account_safe('douyin',directory)
        return directory

    @contextmanager
    def _call(self,token,account,kind):
        if getattr(self._tls,'frame',None) is not None:raise CoreError('本人抖音操作不能嵌套')
        digest,_=self.purpose.review(materials=True)
        user,fresh=self._account(token,account['id'],reading=kind=='comments')
        if fresh!=account:raise CoreError('抖音操作开始前账号已变化')
        frame=(token,_binding(user,account,self.scope.instance),digest,kind)
        self._tls.frame=frame
        try:self.execution_guard();yield
        finally:
            if getattr(self._tls,'frame',None) is frame:del self._tls.frame

    def execution_guard(self):
        frame=getattr(self._tls,'frame',None)
        if self.closed or frame is None or self.core.remote_safety_hold:
            raise CoreError('此抖音操作未处于当前本人明确用途')
        token,binding,digest,kind=frame
        user,account=self._account(token,binding['account']['id'],reading=kind=='comments')
        # Connection status may legitimately save its generated conn/status;
        # its exact connection call independently controls those transitions.
        fresh=_binding(user,account,self.scope.instance)
        if kind=='connection':fresh['account']['conn_id']=binding['account']['conn_id']
        if fresh!=binding:raise CoreError('当前本人或账号身份已变化')
        self.purpose.current(digest)
        self.core.require_platform('douyin');self.core._platform_execution_guard('douyin')
        from core.service_plans import require_feature
        require_feature(self.server.company,'acquisition')
        self._safe(user,account)
        return account

    def describe(self):
        try:self.purpose.review();state='reviewed'
        except (OSError,ValueError,TypeError,KeyError):state='pending'
        return {'platform':'douyin','purpose':_PURPOSE,'status':state,'page':1,'limit':20,
                'account_ready':False,'archive_available':False,'auto_retry':False,'real_platform_verified':False}

    def _cleanup(self,ident,item):
        manager=self.server.account_connections;process=item['process']
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        if process.poll() is None:raise RuntimeError('本人窗口物理退出未确认')
        if manager.owned.get(ident) is item:
            manager.owned.pop(ident)
            for mapping in (manager.states,manager.cache,manager.identity_failures):mapping.pop(ident,None)
        with self._lock:
            if self.pending.get(ident) is item:self.pending.pop(ident)

    def close(self):
        self.closed=True
        with self._lock:items=list(self.pending.items())
        for ident,item in items:
            try:self._cleanup(ident,item)
            except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired):pass
        with self._lock:return not self.pending

    def execute(self,token,action,data):
        if (action not in self.ACTIONS or type(data) is not dict
                or set(data)!=({'account_id'} if 'connection_' in action else
                              {'account_id','request_id','reference'} if action=='owner_douyin_comments' else
                              {'account_id','request_id'})
                or type(data.get('account_id')) is not str or not _ID.fullmatch(data['account_id'])):
            raise ValueError('只接本人账号与固定抖音操作参数')
        metadata=action in ('owner_douyin_read_status','owner_douyin_read_cancel')
        user,account=self._account(token,data['account_id'],metadata=metadata,
                                   reading=action=='owner_douyin_comments')
        if metadata:
            request=data['request_id']
            if type(request) is not str or not _REQUEST.fullmatch(request):raise ValueError('原请求编号无效')
            reads=self.scope.reads
            with reads._lock:
                entry=reads._operations.get(request)
                if entry is not None and (not _metadata_current(entry.get('_owner_douyin_binding'),_binding(user,account,self.scope.instance))
                        or entry.get('account_id')!=account['id']):raise ValueError('原编号不属于当前本人账号')
                if action=='owner_douyin_read_cancel':
                    result=reads.execute('platform_read_cancel',data,user)
                    if entry is None:
                        entry=reads._operations.get(request)
                        if entry is not None:entry['_owner_douyin_binding']=_binding(user,account,self.scope.instance)
                    result.update(cancel_requested=True,cleanup_confirmed=not(entry and entry.get('running')))
                    self._account(token,account['id'],metadata=True)
                    return result
                # Current authority proves only ownership, not permission to
                # publish retained content after risk/license changes.
                running=bool(entry and entry.get('running'))
                self._account(token,account['id'],metadata=True)
                return {'platform':'douyin','purpose':_PURPOSE,'request_id':request,
                    'state':'running' if running else 'cancelled' if entry and entry.get('cancelled') else
                        'completed' if entry and (entry.get('response') or {}).get('code')=='completed' else 'unknown',
                    'cleanup_confirmed':not running,'items':[],'archive_available':False,'auto_retry':False}
        if 'connection_' in action:
            if not self._connection_lock.acquire(False):raise AdapterBusy('本人连接正在核对')
            try:
                pending=self.pending.get(account['id'])
                if pending is not None:self._cleanup(account['id'],pending)
                with self._call(token,account,'connection'),account_execution_lock(self._safe(user,account)):
                    if self.core.account_mode_status(account['id'],user['tenant_id']).get('status')=='active':
                        raise AdapterBusy('此账号已有操作')
                    call=_OwnerDouyinConnectionCall(self,token,user,account,_SEAL)
                    try:
                        manager=call.manager
                        if action=='owner_douyin_connection_start':
                            if call.owned is None or call.owned['process'].poll() is not None:
                                lock=manager.locks.setdefault(account['id'],threading.Lock())
                                if not lock.acquire(False):raise AdapterBusy('窗口正在核对')
                                try:state=manager.connect(user,account['id'],'new',_owned_call=call)
                                finally:lock.release()
                            else:state=manager.status(user,account['id'],force=True,_owned_call=call)
                        elif call.owned is None or call.owned['process'].poll() is not None:
                            state=manager.result('disconnected','')
                        else:state=manager.status(user,account['id'],force=True,_owned_call=call)
                        self.purpose.review(materials=True)
                        current=call.check();status=state.get('status');observed=None
                        if status=='ready':
                            from .douyin_connection_service import _identity
                            observed=_identity(state.get('identity'));call.owned_connection(state.get('candidates') or [],current)
                            if observed['uid']!=account['platform_uid']:raise ValueError('本人UID改变')
                        if status not in ('ready','waiting_login','checking','choose_window','failed','disconnected'):status='failed'
                        return {'platform':'douyin','purpose':_PURPOSE,'account_id':account['id'],'state':status,
                            'observed_identity':observed,'owned_window_active':bool(call.owned and call.owned['process'].poll() is None),
                            'platform_login_confirmed':status=='ready','binding_verified':status=='ready',
                            'account_ready':False,'platform_read_only':True,'auto_retry':False}
                    except Exception:
                        if call.created is not None:
                            with self._lock:self.pending[account['id']]=call.created
                            try:self._cleanup(account['id'],call.created)
                            except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired):pass
                        raise
                    finally:call.active=False
            finally:self._connection_lock.release()
        with self._call(token,account,'comments'):
            request={'account_id':account['id'],'request_id':data['request_id'],'reference':data['reference'],
                     'page':1,'cursor':'','limit':20}
            result=self.scope.reads.execute('platform_read_comments',request,user)
            if result.get('code')=='completed' and (result.get('limit_exceeded') is not False
                    or len(result.get('items',[]))>20):raise ValueError('评论数量超界，未作为一页成功结果')
            result.update(archive_available=False,archive_request_id='',archive_account_id='')
            result['local_source_archive_available']=(self.workspace._douyin_archive.can_offer(token,account['id'],data['request_id'])
                if self.workspace._douyin_archive is not None else False)
            return result


class _OwnerDouyinConnectionCall:
    def __init__(self,helper,token,user,account,seal):
        if seal is not _SEAL:raise ValueError('不接普通连接许可')
        self.helper,self.token=helper,token;self.manager=helper.server.account_connections
        self.user_id=user['id'];self.account_id=account['id'];self.uid=account['platform_uid']
        self.actor=_digest({k:user.get(k) for k in _ACTOR});self.active=True;self.thread=threading.current_thread()
        self.owned=self.manager.owned.get(self.account_id);self.created=None
        self.saved_conn=account.get('conn_id');self.accepted_conn=None

    def check(self):
        if (not self.active or self.thread is not threading.current_thread()
                or self.helper.server.account_connections is not self.manager
                or self.manager.owned.get(self.account_id) is not self.owned):raise ValueError('本人窗口绑定变化')
        self.helper.execution_guard()
        user,account=self.helper._account(self.token,self.account_id)
        if (_digest({k:user.get(k) for k in _ACTOR})!=self.actor or user['id']!=self.user_id
                or account['platform_uid']!=self.uid or account.get('conn_id') not in
                    (self.saved_conn,self.accepted_conn) and account.get('conn_id') not in ('',None)):
            raise ValueError('本人身份或连接变化')
        return account

    def before_io(self):
        # All original io=True owner call sites are outside Core/DB locks.
        self.helper.purpose.review(materials=True)
        return self.check()

    def register_owned(self,item):
        if self.manager.owned.get(self.account_id) is not item:raise ValueError('新窗口归属变化')
        self.created=item;self.owned=item;self.check()

    def owned_connection(self,items,account):
        self.check()
        if (self.owned is None or self.owned['process'].poll() is not None or len(items)!=1
                or items[0].get('id')!=account.get('conn_id') or type(self.owned.get('marker')) is not str
                or '#workbench-account='+self.owned['marker'] not in items[0].get('url','')):
            raise ValueError('原本人独立窗口未核实')
        self.accepted_conn=account['conn_id']

    def admit_identity(self,identity):
        from .douyin_connection_service import _identity
        self.check()
        if _identity(identity)['uid']!=self.uid:raise ValueError('平台UID与本人保存UID不符')


class _OwnerDouyinScope:
    def __init__(self,helper,seal):
        if seal is not _SEAL:raise ValueError('不接普通读取许可')
        self.helper=helper;self.core=helper.core;self.reads=None
        self.instance=helper.workspace.instance.check()['selfOperatingRead']['instance_id']

    def resolve(self):
        try:digest,_=self.helper.purpose.review();return {'revision':digest}
        except (ValueError,OSError,TypeError,KeyError):return None

    def check(self,account):
        current=self.helper.execution_guard()
        if current!=account:raise ValueError('本人评论读取账号变化')

    def bind_entry(self,entry,user,account):
        self.check(account);entry['_owner_douyin_binding']=_binding(user,account,self.instance)

    def entry_current(self,entry,user,account):
        if entry.get('_owner_douyin_binding')!=_binding(user,account,self.instance):return False
        self.check(account)
        origin=entry.get('_owner_douyin_origin')
        if origin is not None:return origin.current(self)
        return True


@dataclass(frozen=True)
class _OwnerDouyinOrigin:
    manager:object
    owned:object
    bridge:object
    account_id:str
    files:tuple

    def current(self,scope):
        server=scope.helper.server
        if (server.account_connections is not self.manager or self.manager.owned.get(self.account_id) is not self.owned
                or self.owned['process'].poll() is not None or server.bridge.processes.get(scope.reads.tenant) is not self.bridge
                or self.bridge.poll() is not None or server.bridge.external(scope.reads.tenant)):return False
        for path,root,digest in self.files:
            if _file_hash(_plain(path,root))!=digest:return False
        return True


class _OwnerDouyinCommentsCall:
    def __init__(self,scope,entry,user,account,task):
        self.scope,self.helper,self.server=scope,scope.helper,scope.helper.server
        self.reads,self.entry,self.task=scope.reads,entry,task
        self.active=True;self.thread=threading.current_thread();self.directory=self.helper._safe(user,account)
        self.manager=self.server.account_connections;self.account_id=account['id'];self.account=_digest(account)
        self.uid,self.conn=account['platform_uid'],account.get('conn_id')
        self.owned=self.manager.owned.get(self.account_id);self.bridge_process=self.server.bridge.processes.get(self.reads.tenant)
        if self.owned is None or self.bridge_process is None or not self.conn:raise ValueError('本人窗口与连接尚未核实')
        self.window_facts={k:self.owned.get(k) for k in ('marker','state_path')}
        self.bridge_config=self.server.bridge.root(self.reads.tenant)/'config.json'
        self.window_spec=_plain(self.directory/'managed-window/window.json',self.directory)
        self.script=_plain(self.server.bridge.root(self.reads.tenant)/'工作台_抖音连接.user.js',self.server.core.store.directory)
        self.files=tuple((p,r,_file_hash(_plain(p,r))) for p,r in
            ((self.bridge_config,self.server.core.store.directory),(self.window_spec,self.directory),
             (self.script,self.server.core.store.directory)))
        spec=json.loads(self.window_spec.read_text('utf8'))
        if (spec.get('platform')!='douyin' or spec.get('marker')!=self.owned.get('marker')
                or Path(spec.get('profile',''))!=self.directory/'managed-window/profile'
                or spec.get('state_path')!=self.owned.get('state_path') or Path(spec.get('config',''))!=self.bridge_config
                or Path(spec.get('script',''))!=self.script):raise ValueError('本人profile绑定变化')
        match=re.fullmatch(r'https://www\.douyin\.com/video/([0-9]{1,24})',task['note_url'])
        if match is None or task['daily_limit']!=20 or task.get('next_cursor') or task.get('next_page')!=1:
            raise ValueError('只支持一个明确视频的第一评论页')
        self.args=[str(self.server.bridge.runtime/'cli.js'),'comment-page',match.group(1),'--count','20',
                   '--cursor','0','--conn-id',self.conn,'--no-store','--no-log']
        scope.bind_entry(entry,user,account)

    def check(self,adapters=None,platform=None,args=None,directory=None,job_id=None):
        if not self.active or self.thread is not threading.current_thread():raise ValueError('本人评论调用已结束')
        account=self.helper.execution_guard()
        if (self.manager is not self.server.account_connections or self.manager.owned.get(self.account_id) is not self.owned
                or self.owned['process'].poll() is not None or self.server.bridge.processes.get(self.reads.tenant) is not self.bridge_process
                or self.bridge_process.poll() is not None or self.server.bridge.external(self.reads.tenant)
                or {k:self.owned.get(k) for k in self.window_facts}!=self.window_facts or _digest(account)!=self.account):
            raise ValueError('本人窗口、进程或账号变化')
        for path,root,digest in self.files:
            if _file_hash(_plain(path,root))!=digest:raise ValueError('本人连接文件变化')
        with self.reads._lock:
            if (self.entry.get('cancelled') or not self.entry.get('running')
                    or not any(item is self.entry for item in self.reads._operations.values())):raise ValueError('本次读取已取消')
        if adapters is not None and (adapters is not self.core.adapters or platform!='douyin' or args!=self.args
                or Path(directory)!=self.directory or job_id!=self.entry['operation_id']):raise ValueError('本人只读调用范围变化')
        return account

    @property
    def core(self):return self.server.core

    def validate_payload(self,payload):
        # The fixed CLI returns a direct three-field envelope. Failed or
        # malformed output cannot become an empty successful mapped page.
        if (type(payload) is not dict or set(payload)!={'comments','has_more','cursor'}
                or type(payload['comments']) is not list or len(payload['comments'])>20
                or type(payload['has_more']) is not bool or type(payload['cursor']) is not str
                or (not payload['has_more'] and payload['cursor']!='')
                or (payload['has_more'] and (not re.fullmatch(r'[0-9]{1,12}',payload['cursor'])
                                             or payload['cursor']=='0'))):
            raise ValueError('本人评论页结构、数量或下一页状态未确认')
        identifiers=set()
        for row in payload['comments']:
            if (type(row) is not dict or type(row.get('cid')) is not str
                    or not re.fullmatch(r'[0-9]{1,24}',row['cid']) or row['cid'] in identifiers
                    or row.get('parent_id')!='' or type(row.get('text')) is not str
                    or not row['text'] or len(row['text'])>3000
                    or type(row.get('region')) is not str or len(row['region'])>160
                    or type(row.get('time')) not in (int,float) or row['time']<0
                    or type(row.get('reply_count')) not in (int,float) or row['reply_count']<0
                    or row.get('children') not in (None,[])):
                raise ValueError('本人首评论页有不能明确归属的行，未静默过滤')
            author=row.get('user')
            if author is not None and (type(author) is not dict
                    or author.get('nickname') is not None and (type(author['nickname']) is not str
                                                             or len(author['nickname'])>160)
                    or author.get('uid') is not None and (type(author['uid']) not in (str,int)
                        or not re.fullmatch(r'[0-9]{1,160}',str(author['uid'])))):
                raise ValueError('本人评论行的作者字段未确认')
            identifiers.add(row['cid'])

    # These original fixed algorithms validate final argv/env and publish the
    # once-only spawn under reads -> Core. Authority above remains owner-only.
    from core.douyin_owned_comments import _DouyinCommentsCall as _Mechanical
    check_spec=_Mechanical.check_spec

    @contextmanager
    def launch(self):
        # Full fixed disk facts before the unchanged short Reads/Core gate.
        # This is not a retained native-byte or race-free spawn proof.
        self.helper.purpose.review(materials=True)
        self.check()
        with self._Mechanical.launch(self):yield

    def identity(self):
        from account_connections import verify_douyin
        from .douyin_connection_service import _identity
        self.check();self.helper.purpose.review(materials=True)
        items=self.server.bridge.connections(self.reads.tenant);self.check()
        matches=[i for i in items if i.get('id')==self.conn]
        if (len(matches)!=1 or matches[0].get('alive') is not True
                or '#workbench-account='+self.owned['marker'] not in matches[0].get('url','')):
            raise ValueError('本人的唯一原连接窗口已变化')
        observed=_identity(verify_douyin(self.server.bridge,self.reads.tenant,self.conn));self.check()
        if observed['uid']!=self.uid:raise ValueError('读取前后平台UID不一致')


@contextmanager
def owned_comments(reads,entry,user,account,task,scope):
    if type(scope) is not _OwnerDouyinScope or scope.reads is not reads:raise ValueError('须本实例原私有范围')
    call=_OwnerDouyinCommentsCall(scope,entry,user,account,task)
    lock=call.manager.locks.setdefault(account['id'],threading.Lock())
    if not lock.acquire(False):raise AdapterBusy('本人窗口正在核对')
    try:
        with account_execution_lock(call.directory):
            call.identity();task['_douyin_comments_call']=call
            try:yield
            except Exception as exc:
                from core.douyin_owned_comments import _DouyinCommentCleanupPending
                if isinstance(exc,_DouyinCommentCleanupPending):
                    while not exc.finish():threading.Event().wait(.1)
                    raise RuntimeError('本次进程已物理结束，读取结果未确认') from None
                raise
            else:
                call.identity()
                entry['_owner_douyin_origin']=_OwnerDouyinOrigin(call.manager,call.owned,call.bridge_process,
                    call.account_id,call.files)
            finally:task.pop('_douyin_comments_call',None)
    finally:call.active=False;lock.release()
