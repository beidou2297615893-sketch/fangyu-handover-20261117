"""One original DeviceSession and one explicit natural login worker.

The old account revision protects execution and commit. A separately sealed
completion records this job's committed auth generation for result reads only.
Neither a completed job nor an account DTO can mint execution authority.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import threading
import time

from .xhs_app_context import _DeviceSession, _ACTOR, _digest
from .browser_session_commit import account_revision

_SEAL=object()
_LOCAL=threading.local()
_PURPOSE='session_recovery'


class SessionContextRequired(ValueError):
    def __init__(self):super().__init__('xhs_session_context_unavailable')


@dataclass(frozen=True,slots=True,repr=False)
class _SessionCompletion:
    seal:object
    claim:object
    revision:str
    uid:str
    generation:str


@dataclass(frozen=True,slots=True,repr=False)
class _SessionWorkerClaim:
    seal:object
    session:_DeviceSession
    job:dict
    actor:bytes
    revision:str
    actor_id:str
    account_id:str
    deadline:float

    def _binding(self,*,result=False,_metadata=False):
        from app import AppServer
        if self.seal is not _SEAL or type(self.session) is not _DeviceSession:
            raise SessionContextRequired()
        self.session.check()
        service,executor=self.session.service,self.session.executor
        server,core=service.server,self.session.core
        if (type(server) is not AppServer or server.closing or core.remote_safety_hold
                or service.stop_event.is_set()):raise SessionContextRequired()
        with service.lock:
            qa=(server.company.get('runtime') or {}).get('platform_qa_device_id')
            if service.state!='online' or qa and (service.device or {}).get('id')!=qa:
                raise SessionContextRequired()
        with core.lock:
            user=core.store.get('users',self.actor_id)
            account=core._get('accounts',self.account_id,executor.tenant)
            if (not user or _digest({key:user.get(key) for key in _ACTOR})!=self.actor
                    or user.get('disabled') or user.get('cloud_bound') is not True
                    or user.get('development_local_only') is True
                    or user.get('role') not in ('operator','admin')
                    or (user.get('id'),user.get('username'),user.get('tenant_id'))!=
                        (executor.user_id,executor.owner,executor.tenant)
                    or account.get('platform')!='xiaohongshu'
                    or account.get('cloud_owner')!=executor.owner):raise SessionContextRequired()
            core._account_access(user,account)
            core.require_platform('xiaohongshu')
            executor._require_product_feature('acquisition')
            from core.platform_capabilities import platform_runtime_unavailable_reason
            if platform_runtime_unavailable_reason('xiaohongshu'):raise SessionContextRequired()
            if result:
                completion=self.job.get('_session_completion')
                if (type(completion) is not _SessionCompletion or completion.seal is not _SEAL
                        or completion.claim is not self or account_revision(account)!=completion.revision
                        or account.get('platform_uid')!=completion.uid
                        or account.get('auth_generation')!=completion.generation):raise SessionContextRequired()
            elif not _metadata and account_revision(account)!=self.revision:raise SessionContextRequired()
        self.session.check()
        return server

    def check(self,*,result=False,_metadata=False):
        server=self._binding(result=result,_metadata=_metadata)
        executor=self.session.executor
        with server.job_lock:
            if (server.jobs.get(self.job.get('id')) is not self.job
                    or self.job.get('_session_claim') is not self
                    or self.job.get('_customer_ui_revoked') is True
                    or self.job.get('kind')!='assistant_account_login' or self.job.get('mode')!='browser'
                    or self.job.get('purpose')!=_PURPOSE or self.job.get('owner_id')!=self.actor_id
                    or self.job.get('account_id')!=self.account_id
                    or self.job.get('tenant_id')!=executor.tenant
                    or not isinstance(self.job.get('worker_done'),threading.Event)):
                raise SessionContextRequired()
        self.session.check()


@dataclass(frozen=True,slots=True,repr=False)
class _SessionExecutionContext:
    seal:object
    claim:_SessionWorkerClaim
    thread:object

    def check(self):
        if (self.seal is not _SEAL or type(self.claim) is not _SessionWorkerClaim
                or self.thread is not threading.current_thread()
                or getattr(_LOCAL,'context',None) is not self):raise SessionContextRequired()
        server=self.claim.session.service.server
        if getattr(server,'_customer_natural_component',False):
            from .customer_read_lease import current
            if not current(server,'xiaohongshu_session_recovery'):raise ValueError('customer_read_lease_unavailable')
        self.claim.check()
        server,job=self.claim.session.service.server,self.claim.job
        with server.job_lock:
            if (getattr(server,'_xhs_session_contexts',{}).get(job['id']) is not self
                    or job.get('status')!='running' or job['worker_done'].is_set()
                    or time.monotonic()>=self.claim.deadline):raise SessionContextRequired()


def mint_session_worker(service,user,account,job):
    from .service import AssistantService
    from .business import BusinessExecutor
    if type(service) is not AssistantService or type(service.executor) is not BusinessExecutor:
        raise SessionContextRequired()
    session=getattr(service.executor,'_xhs_app_session',None)
    if (type(session) is not _DeviceSession or session.service is not service
            or job.get('status')!='running' or job.get('_session_claim') is not None):
        raise SessionContextRequired()
    claim=_SessionWorkerClaim(_SEAL,session,job,_digest({key:user.get(key) for key in _ACTOR}),
        account_revision(account),user['id'],account['id'],time.monotonic()+300)
    server=service.server
    runtime=job.get('_session_runtime')
    claim._binding()
    # The exact sealed claim and its RAM job are published together; controls
    # can never see an executable-purpose job whose carrier is missing.
    with server.core.lock:
        with runtime.lock:
            claim._binding()
            with server.job_lock:
                if server.jobs.get(job.get('id')) is not None:raise SessionContextRequired()
                job['_session_claim']=claim
                server.jobs[job['id']]=job
    return claim


@contextmanager
def session_worker_call(claim):
    if type(claim) is not _SessionWorkerClaim or getattr(_LOCAL,'context',None) is not None:
        raise SessionContextRequired()
    claim.check()
    server,job=claim.session.service.server,claim.job
    context=_SessionExecutionContext(_SEAL,claim,threading.current_thread())
    with server.job_lock:
        contexts=getattr(server,'_xhs_session_contexts',None)
        if type(contexts) is not dict or job['id'] in contexts:raise SessionContextRequired()
        contexts[job['id']]=context
    _LOCAL.context=context
    try:
        context.check()
        yield context
    finally:
        _LOCAL.context=None
        with server.job_lock:
            if contexts.get(job['id']) is context:contexts.pop(job['id'])


def current_session_context(core):
    context=getattr(_LOCAL,'context',None)
    if type(context) is not _SessionExecutionContext or context.claim.session.core is not core:return None
    try:context.check();return context
    except (OSError,ValueError,TypeError,KeyError,AttributeError):return None


def record_session_completion(context,scope,decision):
    """After the original commit only; cannot refresh an execution revision."""
    from .xhs_session_scope import _SessionScope
    if (type(context) is not _SessionExecutionContext or getattr(_LOCAL,'context',None) is not context
            or context.thread is not threading.current_thread() or type(scope) is not _SessionScope
            or scope.app_context is not context or not scope.finished or scope.entered):
        raise SessionContextRequired()
    claim,job=context.claim,context.claim.job
    server=claim.session.service.server
    with server.core.lock:
        with scope.runtime.lock:
            with server.job_lock:
                if (server.jobs.get(job['id']) is not job or job.get('status')!='running'
                        or job.get('commit_code')!='committed'
                        or job.get('_session_commit_once') is not True
                        or job.get('_session_completion') is not None
                        or scope.runtime.jobs.get(job['id']) is not scope):raise SessionContextRequired()
                account=server.core._get('accounts',claim.account_id,claim.session.executor.tenant)
                if (account.get('platform_uid')!=decision['uid'] or account.get('status')!='ready'
                        or not isinstance(account.get('auth_generation'),str)
                        or not account['auth_generation']):raise SessionContextRequired()
                completion=_SessionCompletion(_SEAL,claim,account_revision(account),
                    decision['uid'],account['auth_generation'])
                job['_session_completion']=completion
    return completion
