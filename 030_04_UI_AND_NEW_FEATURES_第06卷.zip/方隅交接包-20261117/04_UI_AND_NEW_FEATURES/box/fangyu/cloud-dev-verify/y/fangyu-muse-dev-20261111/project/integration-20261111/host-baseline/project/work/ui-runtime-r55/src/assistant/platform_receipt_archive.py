"""Archive already-read, employee-owned comments without any new external work.

The host supplies one retained PlatformReadService, device, and scope guard.
No client items are accepted. Source evidence, dedupe, leads, and the success
receipt commit in one workspace SQLite transaction. There is no contact event,
task, AI request, reply target inference, or cross-device delivery in this seam.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re
import time
import unicodedata
from urllib.parse import urlsplit, urlunsplit

from core import CoreError
from core.platform_reads import PlatformReadService, ReadAccessError, normalize_sources, source_reference
from core.service_plans import require_feature, ProductAccessError


RECEIPTS = 'platform_read_archive_receipts'
BATCHES = 'platform_read_archive_batches'
SOURCES = 'platform_read_archive_sources'
_KEY = re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}\Z')
_CONTACT = re.compile(
    r'(?<!\d)(?:\d[\W_]*?){7,}(?!\d)'
    r'|(?:微信|wechat|weixin|wxid|手机号|电话|(?<![A-Za-z0-9_])wx)'
    r'\s*[:：_号=]?\s*[A-Za-z0-9][A-Za-z0-9_-]{2,}'
    r'|(?:contact|platform|consent|evidence|notice|document)\s*:[A-Za-z0-9_:-]+'
    r'|(?<![A-Za-z0-9_])Bearer\s+[A-Za-z0-9_.-]+'
    r'|sk-[\w-]{12,}'
    r'|(?:cookie|password|secret|api[_-]?key)\s*[:=]\s*[^\s,;]+', re.I)


class ReceiptArchiveError(CoreError):
    def __init__(self, code, message, *, mutation_committed=False):
        super().__init__(message)
        self.code = 'PLATFORM_ARCHIVE_' + code
        self.mutation_committed = mutation_committed


def _fail(code, message):
    raise ReceiptArchiveError(code, message)


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_encoded(value).encode('utf-8')).hexdigest()


def _safe_text(value, maximum):
    if not isinstance(value, str) or len(value) > maximum:
        _fail('SOURCE_INVALID', '原评论显示字段需核对')
    text = unicodedata.normalize('NFKC', value)
    text = ''.join(char for char in text if unicodedata.category(char) not in ('Cf', 'Cs')
                   and (unicodedata.category(char) != 'Cc' or char in '\n\t'))
    safe, count = _CONTACT.subn('[联系方式或受保护信息已隐藏]', text)
    return safe, bool(count or safe != value)


def _safe_url(platform, value):
    post_id, url = source_reference(platform, value)
    parsed = urlsplit(url)
    # Signing/nonce context stays in the volatile read receipt. Persist only a
    # canonical source link and ID, never a transient platform access token.
    return post_id, urlunsplit((parsed.scheme, parsed.netloc, parsed.path, '', ''))


class PlatformReceiptArchive:
    ACTIONS = frozenset({'platform_read_archive', 'platform_read_archive_status'})

    def __init__(self, core, tenant, owner, company, *, read_service, device_id, scope_guard, owner_scope=None):
        if (not isinstance(read_service, PlatformReadService) or read_service.core is not core
                or read_service.tenant != tenant or read_service.owner != owner
                or not isinstance(device_id, str) or not device_id or len(device_id) > 160
                or not callable(scope_guard)):
            raise ValueError('归档需要同一可信读取服务、员工和设备范围')
        self.core, self.store = core, core.store
        self.tenant, self.owner, self.company = tenant, owner, company
        self.read_service, self.device_id, self.scope_guard = read_service, device_id, scope_guard
        if owner_scope is not None:
            from .self_operating_archive import _OwnerArchiveScope
            if type(owner_scope) is _OwnerArchiveScope:
                if (owner_scope.core is not core or owner_scope._reads is not read_service
                        or read_service._owner_archive_scope is not owner_scope or owner_scope.instance_id!=device_id):
                    raise ValueError('自营归档只能使用原本机读取范围')
            else:
                from .owner_douyin_source_archive import _OwnerDouyinArchiveScope
                if (type(owner_scope) is not _OwnerDouyinArchiveScope or owner_scope.core is not core
                        or owner_scope.reads is not read_service
                        or read_service._owner_douyin_archive_scope is not owner_scope
                        or owner_scope.instance_id!=device_id):
                    raise ValueError('本人抖音归档只能使用密封原本机读取范围')
        self._owner_scope = owner_scope

    def _principal(self, user):
        saved = self.store.get('users', user.get('id')) if isinstance(user, dict) else None
        if (not isinstance(saved, dict) or saved.get('disabled')
                or (self._owner_scope is None and
                    (saved.get('cloud_bound') is not True or saved.get('role') not in ('operator', 'admin')))
                or saved.get('tenant_id') != self.tenant or saved.get('username') != self.owner
                or any(user.get(key) != saved.get(key) for key in
                       ('id', 'tenant_id', 'username', 'role', 'cloud_bound'))):
            _fail('FORBIDDEN', '归档员工身份或归属已变化')
        if self._owner_scope is not None:
            try: self._owner_scope.check(saved)
            except Exception: _fail('SCOPE_CHANGED', '自营归档本人会话或原账号已变化')
        try: valid = self.scope_guard() is True
        except Exception: valid = False
        if not valid:
            _fail('SCOPE_CHANGED', '归档设备归属已变化，请核对当前连接')
        return saved

    @staticmethod
    def _actor(user):
        return {key: user.get(key) for key in ('id', 'tenant_id', 'username', 'role', 'cloud_bound')}

    def _row(self, db, entity, ident):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (entity, ident, self.tenant)).fetchone()
        if not row: return None
        try: item = json.loads(row['body'])
        except (TypeError, ValueError):
            _fail('RECORD_INVALID', '本机归档记录需人工核对')
        if (not isinstance(item, dict) or item.get('id') != ident
                or item.get('tenant_id') != self.tenant):
            _fail('RECORD_INVALID', '本机归档范围不一致')
        return item

    def _insert(self, db, entity, item):
        db.execute('INSERT INTO records VALUES(?,?,?,?)',
                   (entity, item['id'], self.tenant, _encoded(item)))

    def _receipt_id(self, key):
        if not isinstance(key, str) or not _KEY.fullmatch(key):
            _fail('INVALID_INPUT', '请保留有效的原归档编号')
        return _hash([self.tenant, self.owner, self.device_id, key])

    def _receipt_view(self, record, actor, *, replayed=True):
        if self._owner_scope is not None:
            try: self._owner_scope.check_receipt(actor, record.get('local_owner_scope'))
            except Exception: _fail('SCOPE_CHANGED', '原自营归档回执范围需核对')
        if (record.get('cloud_owner') != self.owner or record.get('device_id') != self.device_id
                or record.get('actor') != self._actor(actor)
                or record.get('state') not in ('succeeded', 'cancelled')):
            _fail('FORBIDDEN', '原归档回执主体或范围不一致')
        if record['state'] == 'cancelled':
            return {'state': 'not_committed', 'mutation_committed': False, 'replayed': True,
                    'operation_id': record['id'], 'auto_retry': False,
                    'local_only': True, 'storage_scope': 'this_device',
                    'cross_machine_verified': False, 'platform_requests_started': False}
        raw = record.get('result')
        counts = {'inserted', 'duplicate_count', 'accepted_count', 'privacy_redacted_count'}
        false_flags = {'reply_allowed', 'reply_target_verified', 'customer_identity_verified',
                       'auto_retry', 'platform_requests_started', 'cross_machine_verified',
                       'resource_receipt_verified', 'real_platform_verified'}
        allowed = counts | false_flags | {'lead_ids', 'local_only', 'storage_scope'}
        if (not isinstance(raw, dict) or set(raw) != allowed
                or any(type(raw.get(key)) is not int or not 0 <= raw[key] <= 100 for key in counts)
                or not 1 <= raw['accepted_count'] <= 100
                or raw['inserted'] + raw['duplicate_count'] != raw['accepted_count']
                or raw['privacy_redacted_count'] > raw['accepted_count']
                or any(raw.get(key) is not False for key in false_flags)
                or raw.get('local_only') is not True or raw.get('storage_scope') != 'this_device'
                or not isinstance(raw.get('lead_ids'), list)
                or len(raw['lead_ids']) != raw['accepted_count']
                or any(not isinstance(value, str) or not _ID.fullmatch(value) for value in raw['lead_ids'])
                or len(set(raw['lead_ids'])) != len(raw['lead_ids'])):
            _fail('RECORD_INVALID', '本机归档回执需核对，本次不返回自由内容')
        result = deepcopy(raw)
        result.update(state='succeeded', mutation_committed=True, replayed=replayed,
                      operation_id=record['id'], refresh_required=True)
        return result

    def _status(self, data, actor):
        if set(data) != {'idempotency_key'}:
            _fail('INVALID_INPUT', '归档核对仅接受原归档编号')
        ident = self._receipt_id(data['idempotency_key'])
        with self.core.lock, self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            record = self._row(db, RECEIPTS, ident)
            if record is None:
                from .owner_douyin_source_archive import _OwnerDouyinArchiveScope
                if type(self._owner_scope) is _OwnerDouyinArchiveScope:
                    # A new tombstone is a local write, not a metadata read.
                    self._owner_scope.require_storage_write(actor)
                record = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                          'device_id': self.device_id, 'actor': self._actor(actor),
                          'state': 'cancelled', 'created_at': time.time()}
                if self._owner_scope is not None:
                    record['local_owner_scope'] = self._owner_scope.receipt_binding(actor)
                self._insert(db, RECEIPTS, record)
            fresh = self._principal(actor)
            return self._receipt_view(record, fresh)

    def _lead_scope(self, lead, actor):
        if lead.get('cloud_owner') != self.owner or lead.get('demo'):
            _fail('SOURCE_FORBIDDEN', '原线索归属或来源范围需核对')
        if lead.get('task_id'):
            try:
                self.core._task_access(actor, self.core._get('tasks', lead['task_id'], self.tenant), self.tenant)
            except (CoreError, ValueError):
                _fail('SOURCE_FORBIDDEN', '原采集任务权限已变化，历史来源保持原样')

    def _legacy_match(self, db, item, raw_text_hash, actor):
        candidates = ('comment:' + item['comment_id'], item['comment_id'],
                      item['post_id'] + ':comment:' + item['comment_id'])
        for source_id in candidates:
            indexed = db.execute('SELECT lead_id FROM unique_leads WHERE tenant_id=? AND platform=? AND source_id=?',
                                 (self.tenant, item['platform'], source_id)).fetchone()
            if not indexed: continue
            lead = self._row(db, 'leads', indexed['lead_id'])
            if not lead or lead.get('source_type') != 'comment': continue
            try: post_id, _ = source_reference(item['platform'], lead.get('note_url') or lead.get('url'))
            except ValueError: continue
            if post_id != item['post_id'] or lead.get('comment_id') != item['comment_id']:
                continue
            if lead.get('cloud_owner') != self.owner:
                _fail('SOURCE_FORBIDDEN', '原来源已有其他归属，不能重新登记为本人客户')
            if (lead.get('demo') or lead.get('author_id') != item['author_id']
                    or _hash(lead.get('text') or '') != raw_text_hash):
                _fail('SOURCE_CONFLICT', '原来源身份或正文已变化，历史线索保持原样')
            self._lead_scope(lead, actor)
            return lead
        return None

    def _archive_item(self, db, item, snapshot, actor, stamp):
        ident = _hash([self.tenant, item['source_uid']])
        raw_hash = _hash(item['text'])
        prior = self._row(db, SOURCES, ident)
        if prior:
            if prior.get('cloud_owner') != self.owner:
                _fail('SOURCE_FORBIDDEN', '此来源已有其他归属，不能重新登记为本人客户')
            if (prior.get('source_uid') != item['source_uid'] or prior.get('platform') != item['platform']
                    or prior.get('post_id') != item['post_id'] or prior.get('comment_id') != item['comment_id']
                    or prior.get('author_id') != item['author_id'] or prior.get('original_text_hash') != raw_hash):
                _fail('SOURCE_CONFLICT', '此来源身份或正文已变化，原记录保持原样')
            lead = self._row(db, 'leads', prior['lead_id'])
            if (not lead or lead.get('cloud_owner') != self.owner or
                    _hash(lead.get('text') or '') != prior.get('lead_text_hash') or
                    _hash({key: lead.get(key) for key in
                           ('platform', 'source_id', 'source_type', 'note_url', 'url', 'comment_id', 'author_id',
                            'target_comment_id', 'target_author_id')}) != prior.get('lead_source_digest')):
                _fail('SOURCE_CONFLICT', '原归档线索已变化，请核对历史记录')
            self._lead_scope(lead, actor)
            return lead['id'], False, prior.get('privacy_redacted') is True
        safe = {}
        redacted = False
        for name, maximum in (('text', 3000), ('title', 1000), ('author', 300), ('region', 200), ('published_at', 100)):
            value = item.get(name, '')
            if name == 'published_at' and isinstance(value, str) and re.fullmatch(
                    r'\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})?)?', value):
                safe[name], changed = value, False
            else:
                safe[name], changed = _safe_text(value, maximum)
            redacted = redacted or changed
        post_id, url = _safe_url(item['platform'], item['url'])
        if post_id != item['post_id'] or not item['text'].strip():
            _fail('SOURCE_INVALID', '本批缺少可靠评论正文或作品身份')
        source_id = 'r22:' + item['source_uid'].split(':', 1)[1]
        indexed = db.execute('SELECT lead_id FROM unique_leads WHERE tenant_id=? AND platform=? AND source_id=?',
                             (self.tenant, item['platform'], source_id)).fetchone()
        if indexed:
            _fail('SOURCE_CONFLICT', '来源去重索引与归档证据不一致，请人工核对')
        lead = self._legacy_match(db, item, raw_hash, actor)
        added = lead is None
        if added:
            lead_id = _hash([self.tenant, self.owner, item['source_uid']])
            lead = {'id': lead_id, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                    'platform': item['platform'], 'source_id': source_id,
                    'source_uid': item['source_uid'], 'source_type': 'comment',
                    'text': safe['text'], 'title': safe['title'], 'author': safe['author'],
                    'region': safe['region'], 'published_at': safe['published_at'],
                    'url': url, 'note_url': url, 'parent_id': '',
                    # Original IDs remain server-side evidence. Empty routing
                    # fields make existing Core comment/DM gates reject sending.
                    'author_id': '', 'comment_id': '', 'target_comment_id': '', 'target_author_id': '',
                    'can_reply': False, 'readonly_archive': True,
                    'reply_target_status': 'not_verified', 'privacy_redacted': redacted,
                    'analysis_status': 'privacy_review_required' if redacted else 'pending',
                    'verification_status': 'pending', 'grade': 'C', 'stage': '来源待核对',
                    'reply_status': '未回复', 'created_at': stamp, 'updated_at': stamp}
            self._insert(db, 'leads', lead)
            db.execute('INSERT INTO unique_leads VALUES(?,?,?,?)',
                       (self.tenant, item['platform'], source_id, lead_id))
        origin = snapshot['origin']
        evidence = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
            'lead_id': lead['id'], 'source_uid': item['source_uid'], 'platform': item['platform'],
            'post_id': item['post_id'], 'comment_id': item['comment_id'], 'author_id': item['author_id'],
            'author_identity': item['author_identity'], 'original_text_hash': raw_hash,
            'safe_text_hash': _hash(safe['text']), 'privacy_redacted': redacted,
            'lead_text_hash': _hash(lead.get('text') or ''),
            'lead_source_digest': _hash({key: lead.get(key) for key in
                ('platform', 'source_id', 'source_type', 'note_url', 'url', 'comment_id', 'author_id',
                 'target_comment_id', 'target_author_id')}),
            'device_id': self.device_id, 'actor_id': actor['id'], 'actor_role': actor['role'],
            'account_id': origin['account_id'], 'account_uid': origin['account_uid'],
            'account_binding_digest': origin['account_binding_digest'],
            'connection_digest': origin['connection_digest'], 'license_digest': origin['license_digest'],
            'input_digest': origin['input_digest'], 'read_operation_id': snapshot['operation_id'],
            'observed_at': snapshot['observed_at'], 'created_at': stamp,
            'reply_target_verified': False, 'evidence_level': 'transport_reported',
            'real_platform_verified': False, 'storage_scope': 'this_device'}
        self._insert(db, SOURCES, evidence)
        return lead['id'], added, redacted

    def _archive(self, data, actor):
        if set(data) != {'account_id', 'read_request_id', 'idempotency_key'}:
            _fail('INVALID_INPUT', '归档只接受服务端原读取引用，不接受评论或身份内容')
        ident = self._receipt_id(data['idempotency_key'])
        if (not isinstance(data['account_id'], str) or not data['account_id'] or len(data['account_id']) > 160
                or not isinstance(data['read_request_id'], str) or not _KEY.fullmatch(data['read_request_id'])):
            _fail('INVALID_INPUT', '原读取账号或编号无效')
        payload_digest = _hash([data['account_id'], data['read_request_id']])
        # Match the retained Service/self/receipt order, including the final
        # receipt checks and SQLite commit: reads -> Core, never Core -> reads.
        with self.read_service._lock,self.core.lock,self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            prior = self._row(db, RECEIPTS, ident)
            if prior:
                if prior.get('state') == 'cancelled':
                    _fail('CANCELLED', '原归档编号已取消，本批未提交')
                if prior.get('payload_digest') != payload_digest:
                    _fail('KEY_CONFLICT', '原归档编号已绑定不同来源，请核对原操作')
                return self._receipt_view(prior, self._principal(actor))
            require_feature(self.company, 'acquisition')
            from .owner_douyin_source_archive import _OwnerDouyinArchiveScope
            receipt_context=(self.read_service.owned_douyin_receipt(data['account_id'],data['read_request_id'],actor,self.device_id,self._owner_scope)
                if type(self._owner_scope) is _OwnerDouyinArchiveScope else
                self.read_service.owned_receipt(data['account_id'],data['read_request_id'],actor,self.device_id))
            with receipt_context as snapshot:
                response = snapshot['result']
                items = response.get('items')
                if (not isinstance(items, list) or not 1 <= len(items) <= 100
                        or any(not isinstance(item, dict) or item.get('source_type') != 'comment' for item in items)
                        or type(response.get('requested_limit')) is not int
                        or not len(items) <= response['requested_limit'] <= 100):
                    _fail('SOURCE_INVALID', '原评论页数量或类型不在归档范围')
                try: normalized = normalize_sources(response['platform'], items)
                except (ValueError, TypeError, KeyError):
                    _fail('SOURCE_INVALID', '原评论来源无法可靠核对')
                if normalized != items:
                    _fail('SOURCE_INVALID', '原服务端来源快照已变化')
                batch_id = _hash([self.tenant, self.owner, self.device_id, data['account_id'], data['read_request_id']])
                batch_digest = _hash([snapshot['origin'], snapshot['result_digest'], snapshot['operation_id']])
                existing_batch = self._row(db, BATCHES, batch_id)
                if existing_batch and existing_batch.get('batch_digest') != batch_digest:
                    _fail('SOURCE_CONFLICT', '原读取编号已归档另一份来源，不能重放')
                lead_ids, inserted, privacy_count = [], 0, 0
                stamp = time.time()
                for item in items:
                    lead_id, added, redacted = self._archive_item(db, item, snapshot, actor, stamp)
                    lead_ids.append(lead_id); inserted += int(added); privacy_count += int(redacted)
                result = {'inserted': inserted, 'duplicate_count': len(items) - inserted,
                    'accepted_count': len(items), 'lead_ids': lead_ids,
                    'privacy_redacted_count': privacy_count, 'reply_allowed': False,
                    'reply_target_verified': False, 'customer_identity_verified': False,
                    'auto_retry': False, 'platform_requests_started': False, 'local_only': True,
                    'storage_scope': 'this_device', 'cross_machine_verified': False,
                    'resource_receipt_verified': False, 'real_platform_verified': False}
                if existing_batch is None:
                    self._insert(db, BATCHES, {'id': batch_id, 'tenant_id': self.tenant,
                        'cloud_owner': self.owner, 'device_id': self.device_id,
                        'actor': self._actor(actor), 'batch_digest': batch_digest,
                        'input_digest': snapshot['origin']['input_digest'],
                        'source_count': len(items), 'lead_ids': lead_ids, 'created_at': stamp})
                record = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                    'device_id': self.device_id, 'actor': self._actor(actor), 'state': 'succeeded',
                    'payload_digest': payload_digest, 'batch_id': batch_id,
                    'result': result, 'created_at': stamp}
                if self._owner_scope is not None:
                    record['local_owner_scope'] = self._owner_scope.receipt_binding(actor)
                self._insert(db, RECEIPTS, record)
                if self._owner_scope is not None:
                    self._owner_scope.store_source_trace(db, snapshot, batch_id,
                        lead_ids, ident, stamp, actor)
                self._principal(actor)
                require_feature(self.company, 'acquisition')
            # owned_receipt's final identity/permission/cancellation check ran
            # before this surrounding database context commits all four entities.
            return self._receipt_view(record, actor, replayed=False)

    def execute(self, action, data, user):
        if action not in self.ACTIONS or not isinstance(data, dict):
            _fail('INVALID_INPUT', '不支持此来源归档操作')
        if self._owner_scope is not None:
            try: self._owner_scope.require_action(action)
            except CoreError: _fail('SCOPE_CHANGED', '本机回执核对不能用于新来源归档')
        actor = self._principal(user)
        try:
            return self._status(data, actor) if action == 'platform_read_archive_status' else self._archive(data, actor)
        except ReceiptArchiveError:
            raise
        except ReadAccessError:
            # owned_receipt rejection is inside the surrounding rollback scope.
            raise ReceiptArchiveError('SOURCE_HELD', '原读取或当前权限需核对，本批未归档') from None
        except (CoreError, ProductAccessError):
            # Feature checks are before commit, and SQLite context rolls them back.
            raise ReceiptArchiveError('FEATURE_HELD', '当前采集权益未开放归档，本批未保存') from None
        except Exception:
            # A driver/commit failure must never claim a known absence. No raw
            # SQLite/transport/free text is exposed; recover by original key.
            raise ReceiptArchiveError('STORAGE_UNKNOWN', '归档提交结果未确认，请按原编号核对，暂勿重复提交',
                                      mutation_committed=None) from None
