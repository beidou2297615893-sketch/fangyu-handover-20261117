"""Explicit per-account browser profiles; never use the user's default profile."""
import os
import re
import subprocess
from pathlib import Path

PLATFORM_URLS={'douyin':'https://www.douyin.com/', 'kuaishou':'https://www.kuaishou.com/', 'zhihu':'https://www.zhihu.com/'}

def browser_executable():
    candidates=[]
    for key in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
        if os.environ.get(key):
            root=Path(os.environ[key])
            candidates.extend([root/'Google/Chrome/Application/chrome.exe',root/'Microsoft/Edge/Application/msedge.exe'])
    for path in candidates:
        if path.is_file(): return path
    raise ValueError('未找到 Chrome 或 Edge，请先安装其中一个浏览器。')

def profile_spec(data_dir, tenant, account, executable):
    for value in (tenant,account.get('id','')):
        if not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',value): raise ValueError('账号目录标识无效')
    platform=account.get('platform')
    if platform not in PLATFORM_URLS: raise ValueError('此平台请使用工作台的扫码登录入口')
    base=Path(data_dir).resolve()
    profile=(base/'accounts'/tenant/account['id']/'browser-profile').resolve()
    if not profile.is_relative_to(base): raise ValueError('账号目录越界')
    return {'profile':profile, 'argv':[str(executable),'--user-data-dir='+str(profile),
            '--no-first-run','--no-default-browser-check','--new-window',PLATFORM_URLS[platform]]}

def open_account_browser(data_dir, tenant, account):
    spec=profile_spec(data_dir,tenant,account,browser_executable())
    spec['profile'].mkdir(parents=True,exist_ok=True)
    subprocess.Popen(spec['argv'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return {'opened':True,'message':'已请求打开此账号的独立浏览器窗口。请在该窗口登录平台；首次使用需安装连接扩展。' if account.get('platform')=='zhihu' else '已请求打开此账号的独立浏览器窗口。请在该窗口登录平台；首次使用仍需安装本机连接脚本。'}
