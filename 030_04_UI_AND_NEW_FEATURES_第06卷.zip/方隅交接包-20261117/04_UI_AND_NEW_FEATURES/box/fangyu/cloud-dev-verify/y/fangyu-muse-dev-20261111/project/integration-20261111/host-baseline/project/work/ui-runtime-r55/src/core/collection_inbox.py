"""One durable fetched page; a bounded local slice admitted per existing Core run.

The queue is an internal record, never a new public entity or authority. The
original Core/Runtime checks run again before every promotion or platform read.
"""
from copy import deepcopy
import hashlib
import json

ENTITY='workbench_collection_inbox_v1'
FIELDS=('id','tenant_id','cloud_owner','store_id','platform','account_id','scope',
    'keywords','excludes','date_from','date_to','comment_keyword_mode','region',
    'city','area','unknown_policy','comment_depth','continuous_enabled','intent_mode',
    'comment_date_range','comment_date_from','comment_date_to','intent_rule_version',
    'time_start','time_end','excluded_authors','excluded_bloggers','high_intent_words',
    'medium_intent_words','negative_intent_words','blogger_unknown_policy','source_blogger',
    'note_url','daily_limit','target_count','strategy_source','source_ref')


def enabled(task):
    fixed=(type(task.get('source_ref')) is dict and task['source_ref'].get('schema')=='acquisition-source/1'
        and task['source_ref'].get('kind') in ('note_links','profiles','own_interactions') and task.get('scope')=='comments')
    return (task.get('platform')=='xiaohongshu' and (task.get('scope')=='search_comments' or fixed)
        and task.get('continuous_enabled') is False
        and task.get('comment_keyword_mode','match')=='all'
        and task.get('region','')=='' and task.get('unknown_policy','exclude')=='exclude')


def binding(task):
    value={key:task.get(key) for key in FIELDS}
    if task.get('source_kind') in ('profiles','own_interactions'):value['source_kind']=task['source_kind']
    return hashlib.sha256(json.dumps(value,
        ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def pending(store,task):
    row=store.get(ENTITY,task['id'])
    if not row or row.get('status')=='completed':return None
    if (row.get('tenant_id')!=task['tenant_id'] or row.get('binding')!=binding(task)
            or row.get('pipeline_before')!=task.get('pipeline')
            or type(row.get('items')) is not list or type(row.get('index')) is not int
            or not 0<=row['index']<len(row['items'])):
        raise ValueError('原页待处理范围已变化，已保留原记录；未读取下一页')
    return row


def stage(store,task,items):
    if pending(store,task):raise ValueError('原页尚未处理完成，不读取下一页')
    if not items:return None
    row={'id':task['id'],'tenant_id':task['tenant_id'],'owner':task.get('cloud_owner'),
        'binding':binding(task),'status':'pending','index':0,
        'items':deepcopy(items),'pipeline_before':deepcopy(task.get('pipeline')),
        'pipeline_next':deepcopy(task.get('_pipeline_next')),
        'page_info':deepcopy(task.get('_page_info',{})),
        'source_page':deepcopy(task.get('_source_page')),
        'query_page':deepcopy(task.get('_query_page')),'read_reported':False}
    store.put(ENTITY,row)
    return row


def current(row,task,remaining=None):
    task['_pipeline_next']=deepcopy(row['pipeline_next'])
    task['_page_info']=deepcopy(row['page_info'])
    if row.get('source_page') is not None:task['_source_page']=deepcopy(row['source_page'])
    task.pop('_query_page',None)
    if row.get('query_page') is not None:task['_query_page']=deepcopy(row['query_page'])
    target=max(1,int(task.get('target_count',100))-int(task.get('accumulated',0)))
    remaining=min(target,remaining) if remaining is not None else target
    return deepcopy(row['items'][row['index']:row['index']+min(50,remaining)])


def advance(row, consumed=1):
    if type(consumed) is not int or not 1<=consumed<=len(row['items'])-row['index']:
        raise ValueError('原页处理范围无效')
    value=deepcopy(row);value['index']+=consumed;value['read_reported']=True
    if value['index']==len(value['items']):
        value.update(status='completed',items=[])
    return value


def progress(store,task):
    """Opaque progress token; never expose queued comment bodies to the UI."""
    row=pending(store,task) if enabled(task) else None
    return (row['binding'],row['index']) if row else None
