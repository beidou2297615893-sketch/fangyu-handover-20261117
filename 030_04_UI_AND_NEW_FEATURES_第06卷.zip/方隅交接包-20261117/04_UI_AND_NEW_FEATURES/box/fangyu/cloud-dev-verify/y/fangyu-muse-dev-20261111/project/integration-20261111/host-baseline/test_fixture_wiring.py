"""Synthetic loopback integration: no production state, transport or launcher."""
import hashlib
import http.client
import importlib.util
import json
import socket
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / 'backend'
sys.path.insert(0, str(CANDIDATE / 'src'))
from fangyu_integration.backend import IntegrationFacade, attach_backend

spec = importlib.util.spec_from_file_location('isolated_candidate_host', CANDIDATE / 'overlay' / 'ui_native_host.py')
host = importlib.util.module_from_spec(spec)
spec.loader.exec_module(host)


class AuthError(ValueError):
    code = 'AUTH_REQUIRED'
    status = 401


class FakeBackend:
    def __init__(self):
        self.closed = False
        self.lock = threading.RLock()
        self._dispatch = self._original

    def _identity(self, token):
        if token != 'synthetic-admin':
            raise AuthError('fixture authentication required')
        return {'role': 'admin', 'username': 'synthetic'}, {}

    def _selected_store(self, user, profile):
        return 'synthetic-store'

    def _original(self, action, data, token=''):
        if action == 'login':
            return {'token': 'synthetic-admin', 'cookie_max_age': 60,
                    'session': {'user': {'role': 'admin', 'username': 'synthetic'}}}
        if action == 'bootstrap':
            return {'session': {'user': {'role': 'admin', 'username': 'synthetic'}}
                    if token == 'synthetic-admin' else None}
        raise AuthError('fixture rejects all other actions')

    def dispatch(self, action, data, token=''):
        return self._dispatch(action, data, token)

    def close(self):
        self.closed = True


class FixtureWiringTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='fixture-', dir=HERE)
        self.root = Path(self.temp.name)
        self.web = self.root / 'web'
        self.web.mkdir()
        self.data = self.root / 'data'
        self.data.mkdir()
        index = b'<!doctype html><title>synthetic fixture</title>'
        (self.web / 'index.html').write_bytes(index)
        self.files = {'web/index.html': {'path': 'web/index.html', 'size': len(index),
                                        'sha256': hashlib.sha256(index).hexdigest()}}
        self.backend = FakeBackend()
        self.calls = []
        real_connect = socket.socket.connect
        def loopback_only(sock, address):
            if not isinstance(address, tuple) or address[0] != '127.0.0.1':
                raise AssertionError('non-loopback socket forbidden')
            return real_connect(sock, address)
        self.patchers = [
            patch.object(socket.socket, 'connect', loopback_only),
            patch.object(host, 'production_workspace', side_effect=AssertionError('production fallback forbidden')),
            patch.object(host, 'create_backend', side_effect=AssertionError('real backend forbidden')),
            patch.object(host, 'make_lifecycle_log', return_value=host._NoLifecycleLog()),
        ]
        for p in self.patchers:
            p.start()
        def factory(*, project_root, data_dir, company):
            self.calls.append((project_root, data_dir, company))
            if project_root != self.root or data_dir != self.data or company is not None:
                raise AssertionError('fixture boundary changed')
            facade = IntegrationFacade(self.backend)
            if facade.dispatcher is not None or facade.cli_bridges or facade.inbox is not None:
                raise AssertionError('executor or real source unexpectedly configured')
            return attach_backend(self.backend, facade)
        self.runtime = host.SharedRuntime(self.root, self.files, self.root / 'state',
             project_root=self.root, release_id='synthetic-fixture', profile='fixture',
             source_root=self.web, assets_root=self.web, data_dir=self.data,
             backend_factory=factory).start()

    def tearDown(self):
        if hasattr(self, 'runtime'):
            self.runtime.close()
        for p in reversed(self.patchers):
            p.stop()
        self.temp.cleanup()

    def get(self, path, cookie=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.runtime.stable.server_port, timeout=3)
        conn.request('GET', path, headers={'Cookie': cookie} if cookie else {})
        response = conn.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        conn.close()
        return result

    def post(self, action, data, cookie=None, *, csrf=True, origin=True):
        server = self.runtime.stable
        headers = {'Content-Type': 'application/json',
                   'Origin': ('http://127.0.0.1:' + str(server.server_port)) if origin else 'http://invalid.example',
                   'X-Fangyu-CSRF': server.csrf_token if csrf else 'wrong'}
        if cookie:
            headers['Cookie'] = cookie
        conn = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=3)
        conn.request('POST', '/api/workbench', json.dumps({'action': action, 'data': data}), headers)
        response = conn.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        conn.close()
        return result

    def login(self):
        code, headers, _ = self.post('login', {})
        self.assertEqual(code, 200)
        return headers['Set-Cookie'].split(';', 1)[0]

    def test_fixture_factory_injected_once_and_static_surface_works(self):
        self.assertEqual(len(self.calls), 1)
        code, _, body = self.get('/')
        self.assertEqual(code, 200)
        self.assertIn(b'synthetic fixture', body)
        self.assertTrue(self.runtime.stable.session_cookie.endswith(self.runtime.instance_id[:12]))

    def test_fixture_requires_explicit_factory(self):
        with self.assertRaises(host.UIHostError):
            host.SharedRuntime(self.root, self.files, self.root / 'other-state',
                               project_root=self.root, release_id='fixture', profile='fixture')

    def test_integration_rejects_anonymous_or_wrong_store(self):
        code, _, _ = self.post('integration_status', {'storeId': 'synthetic-store'})
        self.assertEqual(code, 401)
        code, _, _ = self.post('integration_status', {'storeId': 'other-store'}, self.login())
        self.assertEqual(code, 403)

    def test_explicit_admin_read_has_no_execution_capability(self):
        code, _, raw = self.post('integration_status', {'storeId': 'synthetic-store'}, self.login())
        self.assertEqual(code, 200)
        capabilities = json.loads(raw)['capabilities']
        self.assertFalse(capabilities['execute_configured'])
        self.assertFalse(capabilities['prepare'])
        self.assertEqual(capabilities['cli'], {})
        self.assertIsNone(json.loads(raw)['catalogue'])
        self.assertIsNone(json.loads(raw)['ledger'])

    def test_execute_is_unavailable_and_origin_csrf_are_enforced(self):
        cookie = self.login()
        code, _, raw = self.post('integration_dispatch_execute', {'storeId': 'synthetic-store'}, cookie)
        self.assertEqual(code, 503)
        self.assertEqual(json.loads(raw)['error']['code'], 'INTEGRATION_DISPATCH_UNAVAILABLE')
        self.assertEqual(self.post('integration_status', {'storeId': 'synthetic-store'}, cookie, csrf=False)[0], 403)
        self.assertEqual(self.post('integration_status', {'storeId': 'synthetic-store'}, cookie, origin=False)[0], 403)


if __name__ == '__main__':
    unittest.main()

