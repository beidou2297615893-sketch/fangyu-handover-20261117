"""Pure, fail-closed correlation for a site's natural login getMe response.

No browser, CLI, filesystem or network entry point lives here. Native bindings
must call the methods with events from one owned WebView2 CDP session and must
recheck ``evidence_current`` immediately before staging/committing a candidate.
"""

from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
import json
import re
import secrets
from collections.abc import Mapping
from urllib.parse import urlsplit

from .auth_candidate import XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES


GETME = 'https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
MAX_BODY = 4 * 1024 * 1024
MAX_EVENT = 256 * 1024
MAX_EARLY_EXTRA = 128
MAX_IDENTITY_REQUESTS = 32


def _json(raw, limit):
    if not isinstance(raw, str) or len(raw) > limit:
        return None
    try:
        value = json.loads(raw, object_pairs_hook=_pairs,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (TypeError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def _site_url(value):
    try:
        parsed = urlsplit(value)
        return (parsed.scheme == 'https' and parsed.hostname == 'www.xiaohongshu.com'
                and parsed.port in (None, 443) and not parsed.username
                and not parsed.password and not parsed.fragment)
    except (TypeError, ValueError):
        return False


def _getme_url(value):
    try:
        parsed = urlsplit(value)
        return (parsed.scheme == 'https' and parsed.hostname == 'edith.xiaohongshu.com'
                and parsed.port in (None, 443) and parsed.path == '/api/sns/web/v2/user/me'
                and not parsed.query and not parsed.fragment and not parsed.username
                and not parsed.password)
    except (TypeError, ValueError):
        return False


def _safe_text(value, maximum):
    return (isinstance(value, str) and 0 < len(value) <= maximum
            and value.strip() == value
            and not any(ord(char) < 32 or ord(char) == 127 for char in value))


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('duplicate_json_key')
        result[key] = value
    return result


def _profile(body):
    try:
        envelope = json.loads(body.decode('utf-8'), object_pairs_hook=_pairs,
                              parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (UnicodeError, ValueError, TypeError):
        return None, 'identity_invalid'
    if (not isinstance(envelope, dict) or envelope.get('success') is False
            or type(envelope.get('code', 0)) is not int or envelope.get('code', 0) != 0
            or 'code' not in envelope and envelope.get('success') is not True):
        return None, 'identity_invalid'
    nodes = [envelope]
    cursor = envelope
    for _ in range(3):
        cursor = cursor.get('data') if isinstance(cursor, dict) else None
        if not isinstance(cursor, dict):
            break
        nodes.append(cursor)
    for node in tuple(nodes):
        for key in ('user', 'user_info', 'basic_info'):
            if isinstance(node.get(key), dict):
                nodes.append(node[key])
    guests = [node[key] for node in nodes for key in ('guest', 'is_guest') if key in node]
    if any(value is True for value in guests):
        return None, 'guest_profile'
    if not guests or any(value is not False for value in guests):
        return None, 'identity_invalid'
    uids = {node['user_id'] for node in nodes if _safe_text(node.get('user_id'), 256)}
    if len(uids) != 1:
        return None, 'identity_invalid'
    nickname = next((name for node in nodes for name in
                     (node.get('nickname'), node.get('nick_name'))
                     if _safe_text(name, 100) and name != 'Unknown'), None)
    if nickname is None:
        return None, 'identity_invalid'
    return {'id': next(iter(uids)), 'nickname': nickname, 'guest': False}, ''


def _request_cookies(event):
    headers = event.get('headers')
    if not isinstance(headers, dict):
        return None
    values = [value for key, value in headers.items()
              if isinstance(key, str) and key.lower() == 'cookie']
    if len(values) != 1 or not isinstance(values[0], str) or len(values[0]) > 32768:
        return None
    selected = {}
    for part in values[0].split(';'):
        if '=' not in part:
            return None
        name, value = part.strip().split('=', 1)
        if name in XHS_COOKIE_NAMES:
            if name in selected or not _safe_text(value, 8192):
                return None
            selected[name] = value
    return selected if XHS_REQUIRED_NAMES.issubset(selected) else None


@dataclass(repr=False)
class _Request:
    epoch: int
    task: int
    generation: int
    loader: str
    frame: str
    cookies: dict | None = None
    responded: bool = False
    finished: bool = False


class LoginNaturalIdentity:
    """Correlate one natural getMe and its request Cookie with one candidate.

    ``bound_uid=None`` permits first binding. Results contain only fixed codes;
    ``bind_candidate`` is the sole source of limited identity evidence.
    """

    def __init__(self, job_id: str, *, bound_uid: str | None = None):
        if not isinstance(job_id, str) or not re.fullmatch(r'[a-f0-9]{24}', job_id):
            raise ValueError('job_scope_invalid')
        if bound_uid is not None and not _safe_text(bound_uid, 256):
            raise ValueError('bound_uid_invalid')
        self.job_id = job_id
        self.bound_uid = bound_uid
        self.doc_epoch = 0
        self.task_epoch = 1
        self.generation = 0
        self.frame = ''
        self.loader = ''
        self.code = 'pending'
        self._requests = {}
        self._early = {}
        self._profile = None
        self._request_cookies = None
        self._capture_nonce = None
        self._candidate_cookies = None
        self._waiting_cookie_record = None

    def _fail(self, code):
        self.code = code
        self._requests.clear()
        self._early.clear()
        self._profile = None
        self._request_cookies = None
        self._candidate_cookies = None
        self._capture_nonce = None
        self._waiting_cookie_record = None

    def navigate(self, url: str):
        if self.code not in ('pending', 'identity_observed', 'candidate_bound',
                             'document_untrusted', 'awaiting_cookie_proof',
                             'guest_waiting'):
            return
        self.doc_epoch += 1
        self.frame = self.loader = ''
        self._requests.clear()
        self._early.clear()
        self._profile = self._request_cookies = None
        self._candidate_cookies = self._capture_nonce = None
        self._waiting_cookie_record = None
        self.code = 'pending' if _site_url(url) else 'document_untrusted'

    def change_task(self):
        self.task_epoch += 1
        self._fail('task_changed')

    def cancel(self):
        self._fail('cancelled')

    def request_will_be_sent(self, raw: str, *, session_id: str = ''):
        if session_id != '':
            return
        if self.code in ('identity_observed', 'candidate_bound', 'awaiting_cookie_proof'):
            event = _json(raw, MAX_EVENT)
            request = event.get('request') if isinstance(event, dict) else None
            if isinstance(request, dict):
                if event.get('type') == 'Document':
                    self._fail('document_changed')
                elif _getme_url(request.get('url')):
                    self._fail('identity_changed')
            return
        if self.code not in ('pending', 'guest_waiting'):
            return
        event = _json(raw, MAX_EVENT)
        if event is None:
            self._fail('event_invalid'); return
        request = event.get('request')
        if not isinstance(request, dict):
            return
        rid, loader, frame = (event.get(key) for key in ('requestId', 'loaderId', 'frameId'))
        if not all(_safe_text(value, 256) for value in (rid, loader, frame)):
            return
        if event.get('type') == 'Document':
            if self.code == 'guest_waiting':
                self._fail('document_changed'); return
            if _site_url(request.get('url')) and request.get('method') == 'GET':
                if self.frame and (self.frame != frame or self.loader != loader):
                    self._fail('document_changed'); return
                self.frame, self.loader = frame, loader
            return
        if not _getme_url(request.get('url')) or request.get('method') != 'GET':
            return
        if (self.doc_epoch < 1 or not self.frame or frame != self.frame
                or loader != self.loader or event.get('redirectResponse') is not None
                or rid in self._requests or self._requests or self._profile is not None):
            self._fail('request_scope_invalid'); return
        if self.generation >= MAX_IDENTITY_REQUESTS:
            self._fail('identity_request_limit'); return
        self.code = 'pending'
        self.generation += 1
        record = _Request(self.doc_epoch, self.task_epoch, self.generation, loader, frame)
        if rid in self._early:
            record.cookies = self._early.pop(rid)
        self._requests[rid] = record

    def request_extra_info(self, raw: str, *, session_id: str = ''):
        if self.code not in ('pending', 'awaiting_cookie_proof', 'guest_waiting') or session_id != '':
            return
        event = _json(raw, MAX_EVENT)
        if event is None:
            self._fail('event_invalid'); return
        rid = event.get('requestId')
        if not _safe_text(rid, 256):
            return
        cookies = _request_cookies(event)
        if rid in self._requests or (self._waiting_cookie_record is not None
                                     and rid == self._waiting_cookie_record[0]):
            record = (self._requests.get(rid) or self._waiting_cookie_record[1])
            if record.cookies is not None or cookies is None:
                self._fail('cookie_proof_invalid'); return
            record.cookies = cookies
            if self._waiting_cookie_record is not None and rid == self._waiting_cookie_record[0]:
                self._waiting_cookie_record = None
                self._request_cookies = cookies
                self._capture_nonce = secrets.token_hex(16)
                self.code = 'identity_observed'
        elif rid not in self._early:
            if len(self._early) >= MAX_EARLY_EXTRA:
                self._early.pop(next(iter(self._early)))
            self._early[rid] = cookies
        else:
            self._fail('cookie_proof_invalid')

    def response_received(self, raw: str, *, session_id: str = ''):
        if self.code != 'pending' or session_id != '':
            return
        event = _json(raw, MAX_EVENT)
        if event is None:
            self._fail('event_invalid'); return
        record = self._requests.get(event.get('requestId'))
        if record is None:
            return
        response = event.get('response')
        if (record.epoch != self.doc_epoch or record.task != self.task_epoch
                or event.get('frameId') != record.frame
                or event.get('loaderId') != record.loader
                or not isinstance(response, dict) or not _getme_url(response.get('url'))
                or record.responded):
            self._fail('response_scope_invalid'); return
        status = response.get('status')
        if type(status) is not int or status != 200:
            self._fail('verification_required' if status in (461, 471)
                       else 'not_authenticated' if status == 401 else 'response_rejected')
            return
        record.responded = True

    def loading_finished(self, raw: str, *, session_id: str = '') -> str | None:
        if self.code != 'pending' or session_id != '':
            return None
        event = _json(raw, MAX_EVENT)
        if event is None:
            self._fail('event_invalid'); return None
        rid = event.get('requestId')
        record = self._requests.get(rid)
        if record is None:
            return None
        size = event.get('encodedDataLength')
        if (record.epoch != self.doc_epoch or record.task != self.task_epoch
                or not record.responded or record.finished
                or type(size) not in (int, float) or not 0 <= size <= MAX_BODY):
            self._fail('body_unavailable'); return None
        record.finished = True
        return rid

    def response_body(self, request_id: str, raw: str):
        if self.code != 'pending':
            return
        record = self._requests.pop(request_id, None)
        if (record is None or not record.finished or record.epoch != self.doc_epoch
                or record.task != self.task_epoch):
            self._fail('body_stale'); return
        payload = _json(raw, MAX_BODY * 4 // 3 + 4096)
        if payload is None or type(payload.get('base64Encoded')) is not bool:
            self._fail('body_invalid'); return
        try:
            body = payload['body']
            if not isinstance(body, str):
                raise ValueError
            if payload['base64Encoded']:
                if len(body) > MAX_BODY * 4 // 3 + 4:
                    raise OverflowError
                decoded = base64.b64decode(body, validate=True)
            else:
                decoded = body.encode('utf-8')
            if len(decoded) > MAX_BODY:
                raise OverflowError
        except OverflowError:
            self._fail('body_oversize'); return
        except (KeyError, TypeError, ValueError, UnicodeError, binascii.Error):
            self._fail('body_invalid'); return
        profile, failure = _profile(decoded)
        if profile is None:
            if failure == 'guest_profile':
                # A fresh login page can first observe its guest identity and
                # then emit another natural getMe after QR login in this very
                # document. Guest evidence can never bind a candidate.
                self._early.clear()
                self._profile = self._request_cookies = None
                self._candidate_cookies = self._capture_nonce = None
                self.code = 'guest_waiting'
            else:
                self._fail(failure)
            return
        if self.bound_uid is not None and profile['id'] != self.bound_uid:
            self._fail('identity_mismatch'); return
        self._profile = profile
        if record.cookies is None:
            self._waiting_cookie_record = (request_id, record)
            self.code = 'awaiting_cookie_proof'
            return
        self._request_cookies = record.cookies
        self._capture_nonce = secrets.token_hex(16)
        self.code = 'identity_observed'

    def bind_candidate(self, cookies: Mapping[str, str]):
        if self.code != 'identity_observed' or self._profile is None:
            return None
        if (not isinstance(cookies, Mapping) or not XHS_REQUIRED_NAMES.issubset(cookies)
                or any(not _safe_text(cookies.get(name), 8192) for name in XHS_REQUIRED_NAMES)):
            self._fail('cookie_mismatch'); return None
        selected = {name: cookies.get(name) for name in self._request_cookies}
        if any(not _safe_text(value, 8192) for value in selected.values()):
            self._fail('cookie_mismatch'); return None
        if selected != self._request_cookies:
            self._fail('cookie_mismatch'); return None
        self._candidate_cookies = selected
        self.code = 'candidate_bound'
        return {'version': 1, 'job_id': self.job_id,
                'capture_nonce': self._capture_nonce,
                'document_epoch': self.doc_epoch,
                'request_generation': self.generation,
                'user': dict(self._profile)}

    def evidence_current(self, evidence: Mapping, cookies: Mapping[str, str]) -> bool:
        if (self.code != 'candidate_bound' or not isinstance(evidence, Mapping)
                or not isinstance(cookies, Mapping)):
            return False
        return (evidence.get('job_id') == self.job_id
                and evidence.get('capture_nonce') == self._capture_nonce
                and evidence.get('document_epoch') == self.doc_epoch
                and evidence.get('request_generation') == self.generation
                and evidence.get('user') == self._profile
                and {name: cookies.get(name) for name in self._candidate_cookies}
                    == self._candidate_cookies)

    def timeout(self):
        if self.code == 'pending':
            self._fail('identity_not_observed')
        elif self.code == 'awaiting_cookie_proof':
            self._fail('cookie_proof_missing')
        elif self.code == 'guest_waiting':
            self._fail('guest_profile')
        elif self.code in ('identity_observed', 'candidate_bound', 'document_untrusted'):
            self._fail('timeout')

    def result(self):
        return {'code': self.code, 'document_epoch': self.doc_epoch,
                'request_generation': self.generation}
