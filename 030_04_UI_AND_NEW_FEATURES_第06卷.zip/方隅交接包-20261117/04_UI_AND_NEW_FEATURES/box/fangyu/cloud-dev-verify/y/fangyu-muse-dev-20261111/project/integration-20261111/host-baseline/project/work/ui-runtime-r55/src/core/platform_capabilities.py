"""Read-only platform catalogue. Describing a capability never grants access.

No subprocess, platform request, cookie read, or licence inference is performed.
The existing entitlement policy and runtime guards remain authoritative.
"""
import re
import shutil
from pathlib import Path
from urllib.parse import urlsplit

from .entitlements import EntitlementError, normalize_policy

PLATFORMS = (
    ('xiaohongshu', '小红书', 'https://github.com/jackwener/xiaohongshu-cli',
     'Apache-2.0 (upstream declaration; exact distribution review pending)'),
    ('douyin', '抖音', 'https://github.com/Yht20927/douyin-cli', 'MIT'),
    ('zhihu', '知乎', 'https://github.com/jackwener/OpenCLI', 'Apache-2.0'),
    ('wechat_channels', '视频号', 'https://github.com/nobiyou/wx_channel',
     'MIT (root); bundled dependency review pending'),
    ('bilibili', '哔哩哔哩', 'https://github.com/hammershock/bilibili-cli', 'MIT (fixed source; dependency review separate)'),
    ('kuaishou', '快手', 'local_private', 'Private source; commercial rights pending'),
    ('weibo', '微博', 'https://github.com/jackwener/weibo-cli',
     'Apache-2.0 (upstream declaration; exact distribution review pending)'),
)
ACTIONS = frozenset(('search', 'read', 'comments', 'reply', 'dm', 'observe_events', 'multi_account'))
EDITION_CANDIDATES = (
    {'id': 'trial', 'name': '试用候选', 'features': ['manual_review', 'limited_collection']},
    {'id': 'professional', 'name': '个人专业候选',
     'features': ['intent_analysis', 'strategy_library', 'reviewed_reply', 'export']},
    {'id': 'team', 'name': '门店团队候选',
     'features': ['lead_handoff', 'receipt_reconciliation', 'team_permissions']},
    {'id': 'enterprise', 'name': '企业候选',
     'features': ['multi_store', 'audit', 'approved_platform_integrations']},
)


def platform_runtime_unavailable_reason(platform):
    """Fixed product integration gap; local manifests cannot grant a transport."""
    return '微博隔离读取运行链尚未接通，暂不能创建或执行真实采集任务。' if platform == 'weibo' else ''


def _source(value, fallback):
    if not isinstance(value, str) or len(value) > 500:
        return fallback
    try:
        parsed = urlsplit(value)
    except ValueError:
        return fallback
    if (parsed.scheme == 'https' and parsed.hostname == 'github.com'
            and not parsed.username and not parsed.password and not parsed.query
            and not parsed.fragment and re.fullmatch(r'/[\w.-]+/[\w.-]+/?', parsed.path)):
        return value
    return 'local_private' if not value.startswith('https://github.com/') else fallback


def _installed(manifest, app_root):
    """A manifest or the presence of Node is insufficient to install an adapter."""
    executable = manifest.get('executable')
    if not isinstance(executable, str) or not executable or not shutil.which(executable):
        return False
    if manifest.get('id')=='bilibili':
        from .bilibili_read import configured
        return configured(manifest)
    runtime = manifest.get('runtime')
    if runtime is not None:
        if not isinstance(runtime, str) or not runtime or app_root is None:
            return False
        root = Path(app_root).resolve()
        path = (root / runtime).resolve()
        if not path.is_relative_to(root) or not path.is_dir():
            return False
        # Known bridges require an actual reviewed entry file, not an empty dir.
        entry = manifest.get('args', [])
        if (not isinstance(entry, list) or not entry or not isinstance(entry[0], str)
                or entry[0] != 'cli.js' or not (path / 'cli.js').is_file()):
            return False
    if manifest.get('transport') == 'wx_channel_http':
        # A Python HTTP mapper is not the separately installed Windows service.
        return False
    return True


def capability_catalog(company, manifests=(), app_root=None):
    """Use only trusted server configuration/manifests; payloads cannot enable tools."""
    if not isinstance(company, dict):
        raise ValueError('企业配置格式无效')
    if not isinstance(manifests, (list, tuple)):
        raise ValueError('平台目录格式无效')
    known = {item[0] for item in PLATFORMS}
    by_id = {}
    for item in manifests:
        if isinstance(item, dict) and item.get('id') in known:
            by_id[item['id']] = item
    try:
        policy = normalize_policy(company, list(by_id))
        allowed = set(policy['platforms'])
        policy_error = False
    except EntitlementError:
        allowed = set()
        policy_error = True
    runtime = company.get('runtime') if isinstance(company.get('runtime'), dict) else {}
    results = []
    for identifier, name, source, licence in PLATFORMS:
        manifest = by_id.get(identifier, {})
        installed = _installed(manifest, app_root)
        supported = manifest.get('capabilities', [])
        supported = sorted({action for action in supported if isinstance(action, str) and action in ACTIONS}) \
            if isinstance(supported, list) else []
        level = manifest.get('verification_level', 'not_installed')
        level = level if isinstance(level, str) and len(level) <= 100 else 'unverified'
        search_verified = manifest.get('search_verified') is True
        # Generic verified=True and help output are deliberately not runtime proof.
        verified_actions = [action for action in supported if
                            (action == 'search' and search_verified)
                            or (action == 'reply' and manifest.get('reply_contract_verified') is True)
                            or (action == 'dm' and manifest.get('dm_contract_verified') is True)]
        unavailable = platform_runtime_unavailable_reason(identifier)
        if unavailable:
            verified_actions = []
        enabled = identifier in allowed
        guard = runtime.get(identifier + '_automation')
        held = guard in ('hold', 'disabled', 'blocked')
        status = ('policy_invalid' if policy_error else 'not_installed' if not installed
                  else 'disabled' if not enabled else 'held' if held
                  else 'contract_checked' if verified_actions else 'pending_verification')
        results.append({
            'id': identifier, 'name': name, 'adapter_present': bool(manifest),
            'installed': installed, 'enabled': enabled, 'status': status,
            'supported_actions': supported, 'verified_actions': verified_actions,
            'verify_level': 'isolated_read_transport_unavailable' if unavailable else level, 'real_verified': manifest.get('real_verified') is True and not unavailable,
            'license': manifest.get('license', licence) if isinstance(manifest.get('license', licence), str) else licence,
            'license_reviewed': manifest.get('license_reviewed') is True,
            'source': _source(manifest.get('source', source), source),
            'version': manifest.get('version', '') if isinstance(manifest.get('version', ''), str) else '',
            'operational': False, 'guard_status': 'held' if held else 'existing_guards_apply',
            'note': unavailable or '能力目录不触发登录、平台请求或收费；实际操作仍需现有权限、账号与安全门禁。',
        })
    return {
        'schema_version': 1, 'items': results, 'policy_valid': not policy_error,
        'grants_access': False,
        'edition_candidates': [dict(item, features=list(item['features']),
                                    candidate_only=True, grants_access=False, price=None)
                               for item in EDITION_CANDIDATES],
        'billing_active': False,
    }
