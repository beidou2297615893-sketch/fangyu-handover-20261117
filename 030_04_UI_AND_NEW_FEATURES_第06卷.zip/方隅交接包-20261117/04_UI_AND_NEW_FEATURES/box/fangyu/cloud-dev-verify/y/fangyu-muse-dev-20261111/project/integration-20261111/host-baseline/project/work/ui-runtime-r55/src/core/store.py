import json
import re
import sqlite3
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from urllib.parse import urlsplit
from .customer_intent_dirty import read_record,mark_change


def _xhs_note_id(value):
    """Compare note identity without an expiring xsec query token."""
    if not isinstance(value,str) or len(value)>2048:return ''
    try:
        parsed=urlsplit(value)
        port=parsed.port
    except ValueError:return ''
    if (parsed.scheme!='https' or parsed.hostname not in ('xiaohongshu.com','www.xiaohongshu.com')
            or port not in (None,443) or parsed.username or parsed.password):return ''
    match=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]+)',parsed.path)
    return match.group(1) if match else ''

class Store:
    def __init__(self, directory):
        self._scoped_write_guards=ContextVar('customer_store_write_guards_'+str(id(self)),default=())
        self.directory=Path(directory)
        self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/'workspace.sqlite3'
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS records(entity TEXT NOT NULL,id TEXT NOT NULL,tenant_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(entity,id));
                CREATE INDEX IF NOT EXISTS scope ON records(entity,tenant_id);
                CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS unique_leads(tenant_id TEXT,platform TEXT,source_id TEXT,lead_id TEXT,PRIMARY KEY(tenant_id,platform,source_id));
            ''')
    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path,timeout=30)
        db.row_factory=sqlite3.Row
        try:
            with db: yield db
        finally: db.close()
    def list(self,entity,tenant_id=None):
        with self.connect() as db:
            rows=db.execute('SELECT body FROM records WHERE entity=?'+(' AND tenant_id=?' if tenant_id is not None else ''),(entity,tenant_id) if tenant_id is not None else (entity,)).fetchall()
        return [json.loads(x['body']) for x in rows]
    def list_task_leads(self,tenant_id,task_id):
        """Prefilter a task before decoding bodies; callers retain access checks."""
        with self.connect() as db:
            rows=db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=? AND json_extract(body,'$.task_id')=?",
                            ('leads',tenant_id,task_id)).fetchall()
        return [json.loads(x['body']) for x in rows]
    def get(self,entity,id):
        with self.connect() as db:
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,id)).fetchone()
        return json.loads(row['body']) if row else None
    def put(self,entity,record):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._check_write_guards(db)
            self._put_record(db,entity,record)

    @contextmanager
    def scoped_write_guard(self,callback):
        """Trusted internal callback, scoped to this Store and execution context."""
        if not callable(callback):raise ValueError('write guard must be callable')
        token=self._scoped_write_guards.set((*self._scoped_write_guards.get(),callback))
        try:yield
        finally:self._scoped_write_guards.reset(token)

    def _check_write_guards(self,db):
        for callback in self._scoped_write_guards.get():callback(db)
    @staticmethod
    def _put_record(db,entity,record):
        before=read_record(db,entity,record['id'])
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,record['id'],record['tenant_id'],json.dumps(record,ensure_ascii=False)))
        mark_change(db,entity,before,record)
    def put_many(self,entity,records):
        """Commit related record changes together, or leave all of them unchanged."""
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._check_write_guards(db)
            for record in records:
                self._put_record(db,entity,record)
    def put_records(self,items):
        """Persist a cross-entity state transition in one transaction."""
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._check_write_guards(db)
            for entity,record in items:
                self._put_record(db,entity,record)
    def delete(self,entity,id):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            before=read_record(db,entity,id)
            db.execute('DELETE FROM records WHERE entity=? AND id=?',(entity,id))
            if entity=='leads': db.execute('DELETE FROM unique_leads WHERE lead_id=?',(id,))
            if before:mark_change(db,entity,before,None)
    def insert_lead(self,record):
        return self.insert_leads([record])==1
    def insert_leads(self,records):
        """One transaction per batch: dedupe and records commit or roll back together."""
        inserted=0
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for record in records:
                cursor=db.execute('INSERT OR IGNORE INTO unique_leads VALUES(?,?,?,?)',(record['tenant_id'],record['platform'],record['source_id'],record['id']))
                if cursor.rowcount==0: continue
                db.execute('INSERT INTO records VALUES(?,?,?,?)',('leads',record['id'],record['tenant_id'],json.dumps(record,ensure_ascii=False)))
                mark_change(db,'leads',None,record)
                inserted+=1
        return inserted

    def insert_collection_page(self,records,*,tenant_id,task_id,owner,account_id,platform,observations,
                               source_page=None,source_page_complete=False,source_inbox_update=None,source_guard=None,
                               query_page=None):
        """Atomically append originals, task observations and conflicting text.

        The existing unique_leads key spans collecting accounts. A repeated
        comment never changes its original task, text, AI result or manual grade.
        The caller may acknowledge the page only after this transaction returns.
        """
        from datetime import datetime,timezone
        from .collection_observations import OBSERVATIONS,CONFLICTS,digest,comment_identity
        if (platform not in ('xiaohongshu','douyin') or not isinstance(records,list)
                or not isinstance(observations,list) or len(records)>5000 or len(observations)>5000
                or any(not isinstance(v,str) or not v for v in (tenant_id,task_id,owner,account_id))):
            raise ValueError('采集页归属无法核对，未确认下一页')
        # Shape/source failures precede any insertion, including in a mixed page.
        identities=[comment_identity(item,platform) for item in observations]
        allowed_sources={item['source_id'] for item in observations}
        for record in records:
            if (not isinstance(record,dict) or record.get('tenant_id')!=tenant_id
                    or record.get('task_id')!=task_id or record.get('cloud_owner')!=owner
                    or record.get('platform')!=platform or record.get('source_id') not in allowed_sources):
                raise ValueError('新增评论与原采集页归属不一致，未确认下一页')
            comment_identity(record,platform)
        summary={'imported':0,'linked_existing':0,'source_conflicts':0,'observed_comments':0}
        stamp=datetime.now(timezone.utc).isoformat()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            def scoped(entity,ident):
                row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    (entity,ident,tenant_id)).fetchone()
                return json.loads(row['body']) if row else None
            task=scoped('tasks',task_id);account=scoped('accounts',account_id)
            if (not task or not account or task.get('cloud_owner')!=owner
                    or task.get('account_id')!=account_id or task.get('platform')!=platform
                    or task.get('status')=='paused'
                    or account.get('cloud_owner')!=owner or account.get('platform')!=platform):
                raise ValueError('采集任务或账号归属已变化，未确认下一页')
            new_ids=set()
            from .collection_query_provenance import validate_page,commit as commit_query
            query_page=validate_page(query_page,task)
            for record in records:
                cursor=db.execute('INSERT OR IGNORE INTO unique_leads VALUES(?,?,?,?)',
                    (tenant_id,platform,record['source_id'],record['id']))
                if cursor.rowcount:
                    db.execute('INSERT INTO records VALUES(?,?,?,?)',
                        ('leads',record['id'],tenant_id,json.dumps(record,ensure_ascii=False)))
                    mark_change(db,'leads',None,record)
                    new_ids.add(record['id']);summary['imported']+=1
            encountered=set()
            for item,(comment_id,note_id,text) in zip(observations,identities):
                found=db.execute('SELECT r.body FROM unique_leads u JOIN records r '
                    'ON r.entity=? AND r.id=u.lead_id AND r.tenant_id=u.tenant_id '
                    'WHERE u.tenant_id=? AND u.platform=? AND u.source_id=?',
                    ('leads',tenant_id,platform,item['source_id'])).fetchone()
                if not found:
                    raise ValueError('采集原文尚未完整保存，未确认下一页')
                lead=json.loads(found['body'])
                old_task=scoped('tasks',lead.get('task_id'))
                owned=(lead.get('cloud_owner')==owner or not lead.get('cloud_owner')
                    and old_task and old_task.get('cloud_owner')==owner)
                if not owned:
                    # Tenant-global deduplication must not reveal another employee.
                    continue
                old_comment,old_note,old_text=comment_identity(lead,platform)
                if (old_comment,old_note)!=(comment_id,note_id):
                    raise ValueError('已有评论与本次原帖身份不一致，未确认下一页')
                author=item.get('author_id') or ''
                old_author=lead.get('author_id') or ''
                conflict=bool(old_text.strip() and text.strip() and old_text!=text
                    or old_author and author and old_author!=author)
                ident=digest([tenant_id,owner,task_id,lead['id']])
                previous=scoped(OBSERVATIONS,ident)
                observation={**(previous or {}),'id':ident,'tenant_id':tenant_id,'owner':owner,
                    'task_id':task_id,'account_id':account_id,'store_id':task.get('store_id'),
                    'platform':platform,'lead_id':lead['id'],'source_id':item['source_id'],
                    'comment_id':comment_id,'note_id':note_id,
                    'first_seen_at':(previous or {}).get('first_seen_at',stamp),'last_seen_at':stamp,
                    'original_task_id':lead.get('task_id'),'original_text_sha256':digest(old_text),
                    'observed_text_sha256':digest(text),
                    'has_conflict':conflict or (previous or {}).get('has_conflict') is True,
                    'original_result_preserved':True,'automatic_reanalysis':False}
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (OBSERVATIONS,ident,tenant_id,json.dumps(observation,ensure_ascii=False)))
                commit_query(db,query_page,task,lead,stamp)
                if lead['id'] not in encountered:
                    encountered.add(lead['id']);summary['observed_comments']+=1
                    if lead['id'] not in new_ids and previous is None:summary['linked_existing']+=1
                if conflict:
                    conflict_id=digest([ident,text,author])
                    evidence={'id':conflict_id,'tenant_id':tenant_id,'owner':owner,'task_id':task_id,
                        'account_id':account_id,'platform':platform,'lead_id':lead['id'],
                        'comment_id':comment_id,'note_id':note_id,'observed_at':stamp,
                        'observed_text':text,'observed_author_id':author,
                        'original_text_sha256':digest(old_text),'original_author_id':old_author,
                        'state':'needs_review','original_result_preserved':True}
                    cursor=db.execute('INSERT OR IGNORE INTO records VALUES(?,?,?,?)',
                        (CONFLICTS,conflict_id,tenant_id,json.dumps(evidence,ensure_ascii=False)))
                    summary['source_conflicts']+=int(bool(cursor.rowcount))
            if source_page is not None:
                from .acquisition_extension_runtime import commit_page
                commit_page(db,source_page,task_id=task_id,tenant_id=tenant_id,owner=owner,
                    account_id=account_id,page_complete=source_page_complete,
                    inbox_update=source_inbox_update,guard=source_guard)
        return summary

    def read_customer_source_history(self,*,tenant_id,owner,store_id,lead_ids):
        """Read only selected, already-authorized comment IDs in one snapshot.

        Task/account ownership and explicit store bindings are rechecked here.
        Only display-safe source facts are returned; credential fields and note
        access URLs never cross this interface. No customer-list call uses it.
        """
        from .collection_observations import OBSERVATIONS,digest,comment_identity
        if (any(not isinstance(v,str) or not v for v in (tenant_id,owner,store_id))
                or not isinstance(lead_ids,list) or len(lead_ids)>20000
                or any(not isinstance(v,str) or not v for v in lead_ids)):
            raise ValueError('来源记录范围无法核对')
        if not lead_ids:return []
        ids=json.dumps(list(dict.fromkeys(lead_ids)),ensure_ascii=False)
        result=[]
        with self.connect() as db:
            db.execute('BEGIN')
            cache={}
            def scoped(entity,ident):
                key=(entity,ident)
                if key not in cache:
                    row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                        (entity,ident,tenant_id)).fetchone()
                    cache[key]=json.loads(row['body']) if row else None
                return cache[key]
            def source(task_id,platform):
                task=scoped('tasks',task_id)
                if (not task or task.get('cloud_owner')!=owner or task.get('store_id')!=store_id
                        or task.get('platform')!=platform):return None
                account=scoped('accounts',task.get('account_id'))
                if (not account or account.get('cloud_owner')!=owner or account.get('store_id')!=store_id
                        or account.get('platform')!=platform):return None
                return task,account
            leads={}
            found=db.execute("SELECT body FROM records WHERE entity='leads' AND tenant_id=? "
                "AND id IN (SELECT value FROM json_each(?))",(tenant_id,ids)).fetchall()
            for row in found:
                lead=json.loads(row['body']);platform=lead.get('platform')
                if (platform not in ('xiaohongshu','douyin')
                        or lead.get('store_id') not in (None,'',store_id)):
                    continue
                original=source(lead.get('task_id'),platform)
                owned=lead.get('cloud_owner')==owner or not lead.get('cloud_owner') and original is not None
                if not owned:continue
                leads[lead['id']]=lead
                if original:
                    task,account=original
                    result.append({'lead_id':lead['id'],'task_id':task['id'],'task_name':task.get('name'),
                        'account_id':account['id'],'account_nickname':account.get('platform_nickname') or account.get('name'),
                        'platform':platform,'first_seen_at':lead.get('created_at') or '',
                        'last_seen_at':lead.get('created_at') or '', 'has_conflict':False,'relation':'original'})
            # Scoped SQL prunes the entity/tenant/owner/store and selected lead
            # set before JSON decoding. It runs once for the selected customer.
            observations=db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=? '
                "AND json_extract(body,'$.owner')=? AND json_extract(body,'$.store_id')=? "
                "AND json_extract(body,'$.lead_id') IN (SELECT value FROM json_each(?))",
                (OBSERVATIONS,tenant_id,owner,store_id,ids)).fetchall()
            for row in observations:
                observation=json.loads(row['body']);lead=leads.get(observation.get('lead_id'))
                if not lead:continue
                platform=lead.get('platform');verified=source(observation.get('task_id'),platform)
                if not verified:continue
                task,account=verified
                if (observation.get('id')!=digest([tenant_id,owner,task['id'],lead['id']])
                        or observation.get('account_id')!=account['id'] or observation.get('platform')!=platform
                        or observation.get('source_id')!=lead.get('source_id')
                        or observation.get('original_task_id')!=lead.get('task_id')):
                    continue
                try:comment_id,note_id,_=comment_identity(lead,platform)
                except ValueError:continue
                if (observation.get('comment_id'),observation.get('note_id'))!=(comment_id,note_id):continue
                result.append({'lead_id':lead['id'],'task_id':task['id'],'task_name':task.get('name'),
                    'account_id':account['id'],'account_nickname':account.get('platform_nickname') or account.get('name'),
                    'platform':platform,'first_seen_at':observation.get('first_seen_at') or '',
                    'last_seen_at':observation.get('last_seen_at') or '',
                    'has_conflict':observation.get('has_conflict') is True,
                    'relation':'original' if task['id']==lead.get('task_id') else 'rediscovered'})
        return result

    def enrich_leads_missing(self,tenant_id,rows):
        """Fill display gaps; restore missing comment text only in the same identity scope."""
        from .adapters import xhs_image_url
        fields=('author_avatar_url','content_title','content_author','content_author_id',
                'content_author_avatar_url','content_cover_url','content_published_at')
        changed=0
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            def scoped(entity,ident):
                if not isinstance(ident,str) or not ident:return None
                row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                               (entity,ident,tenant_id)).fetchone()
                return json.loads(row['body']) if row else None
            for item in rows:
                identity=(tenant_id,item.get('platform'),str(item.get('source_id') or ''))
                match=db.execute('SELECT r.id,r.body FROM unique_leads u JOIN records r ON r.entity=? AND r.id=u.lead_id AND r.tenant_id=u.tenant_id WHERE u.tenant_id=? AND u.platform=? AND u.source_id=?',
                                 ('leads',*identity)).fetchone()
                if not match:continue
                if not item.get('existing_lead_id') or match['id']!=item['existing_lead_id']:continue
                record=json.loads(match['body'])
                before_record=json.loads(match['body'])
                owner=item.get('refresh_owner')
                account_id=item.get('refresh_account_id')
                original_note=_xhs_note_id(record.get('note_url'))
                current_note=_xhs_note_id(item.get('note_url'))
                old_task=scoped('tasks',record.get('task_id'))
                new_task=scoped('tasks',item.get('refresh_task_id'))
                account=scoped('accounts',account_id)
                refresh_scope=(record.get('platform')=='xiaohongshu'
                    and record.get('source_id')==item.get('source_id')
                    and isinstance(owner,str) and bool(owner)
                    and isinstance(account_id,str) and bool(account_id)
                    and record.get('cloud_owner')==owner
                    and old_task is not None and new_task is not None and account is not None
                    and old_task.get('cloud_owner')==owner and new_task.get('cloud_owner')==owner
                    and account.get('cloud_owner')==owner and account.get('platform')=='xiaohongshu'
                    and old_task.get('account_id')==account_id
                    and new_task.get('account_id')==account_id
                    and bool(original_note) and original_note==current_note)
                # Capture stored identities before filling blanks below. A newly
                # supplied ID must not justify replacing an old nonempty image.
                old_author_id=record.get('author_id')
                old_content_author_id=record.get('content_author_id')
                dirty=False
                for field in fields:
                    value=item.get(field)
                    if not record.get(field) and isinstance(value,str) and value:
                        record[field]=value;dirty=True
                if refresh_scope:
                    same_comment=(isinstance(record.get('comment_id'),str)
                        and bool(record['comment_id'])
                        and record['comment_id']==item.get('comment_id')
                        and record['source_id']=='comment:'+record['comment_id'])
                    same_author=(isinstance(old_author_id,str) and bool(old_author_id)
                        and old_author_id==item.get('author_id'))
                    fresh_text=item.get('text')
                    if (same_comment and same_author
                            and isinstance(record.get('text'),str) and not record['text'].strip()
                            and record.get('ai_intent') is None
                            and record.get('manual_intent') is None
                            and type(fresh_text) is str and 0<len(fresh_text)<=3000
                            and bool(fresh_text.strip()) and '\x00' not in fresh_text):
                        record['text']=fresh_text
                        if record.get('analysis_status')=='missing_text':
                            record['analysis_status']='pending'
                        dirty=True
                    target=item.get('target_comment_id')
                    if (same_comment and same_author and isinstance(target,str)
                            and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',target)):
                        if not record.get('target_comment_id'):
                            record['target_comment_id']=target;dirty=True
                        if record.get('target_comment_id')==target and not record.get('target_author_id'):
                            target_author=item.get('target_author_id')
                            if isinstance(target_author,str) and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',target_author):
                                record['target_author_id']=target_author;dirty=True
                    for field,old_identity,new_identity in (
                            ('author_avatar_url',old_author_id,item.get('author_id')),
                            ('content_author_avatar_url',old_content_author_id,item.get('content_author_id'))):
                        value=item.get(field)
                        if (record.get(field) and isinstance(value,str) and value!=record[field]
                                and isinstance(old_identity,str) and bool(old_identity)
                                and old_identity==new_identity and xhs_image_url(value)==value):
                            record[field]=value;dirty=True
                if dirty:
                    db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                               (json.dumps(record,ensure_ascii=False),'leads',match['id']))
                    mark_change(db,'leads',before_record,record)
                    changed+=1
        return changed
