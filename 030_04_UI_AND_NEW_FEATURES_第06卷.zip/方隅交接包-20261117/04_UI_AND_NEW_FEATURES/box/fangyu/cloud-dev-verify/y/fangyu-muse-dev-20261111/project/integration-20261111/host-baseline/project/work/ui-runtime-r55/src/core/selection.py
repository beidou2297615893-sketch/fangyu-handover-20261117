"""Task-level collection rules, independent of platform CLI implementations."""
import re

LIST_FIELDS = ('keywords', 'excludes', 'excluded_bloggers', 'excluded_authors',
               'high_intent_words', 'medium_intent_words', 'negative_intent_words')

def normalize_task_rules(record):
    for key in LIST_FIELDS:
        value = record.get(key, [])
        if isinstance(value, str):
            value = re.split(r'[,，\n]', value)
        if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
            raise ValueError('筛选词必须为文本列表')
        record[key] = list(dict.fromkeys(x.strip() for x in value if x.strip()))
    record.setdefault('intent_mode', 'all')
    if record['intent_mode'] not in ('all', 'AB', 'A'):
        raise ValueError('意向筛选必须为全部、A/B 或仅 A')
    record.setdefault('comment_keyword_mode', 'match')
    record.setdefault('comment_depth', 'all')
    if record['comment_depth'] not in ('main','all'):
        raise ValueError('评论范围必须为主评论或主评论和子评论')
    if record['comment_keyword_mode'] not in ('all', 'match'):
        raise ValueError('评论关键词处理方式无效')
    record['source_blogger'] = str(record.get('source_blogger', '')).strip()
    record.setdefault('blogger_unknown_policy', 'review')
    if record['blogger_unknown_policy'] not in ('review', 'exclude'):
        raise ValueError('未知博主处理方式无效')

def classify_intent(item, task):
    """Return None when custom rules are absent; never promote a search post."""
    if item.get('source_type') == 'note':
        return None
    if not any(task.get(k) for k in ('high_intent_words', 'medium_intent_words', 'negative_intent_words')):
        return None
    # For comment leads, intent belongs to the commenter. The source post title
    # must not turn every unrelated comment into a high-intent customer.
    text = str(item.get('text', ''))
    for key, grade, label in (('negative_intent_words', 'C', '低意向/已完成'),
                               ('high_intent_words', 'A', '高意向'),
                               ('medium_intent_words', 'B', '中意向')):
        hits = [word for word in task.get(key, []) if word in text]
        if hits:
            return {'grade': grade, 'grade_reason': '任务规则（待核实）：' + label + '；命中：' + '、'.join(hits)}
    return {'grade': 'C', 'grade_reason': '任务规则未命中；保留为待核实候选'}

def identity_decision(item, task):
    """Commenter and content creator are different identities, matched exactly."""
    commenter = {str(item.get(k, '')).strip().casefold() for k in ('author', 'author_id')} - {''}
    if commenter.intersection(x.casefold() for x in task.get('excluded_authors', [])):
        return 'exclude', '命中排除作者/评论者'
    if not task.get('excluded_bloggers'):
        return 'keep', ''
    if item.get('source_type') == 'note':
        blogger = commenter
    else:
        blogger = {str(item.get(k, '')).strip().casefold() for k in ('content_author', 'content_author_id')} - {''}
        # Explicit task input applies only to a single specified post, never search results.
        if not blogger and task.get('scope') == 'comments' and task.get('source_blogger'):
            blogger = {task['source_blogger'].casefold()}
    if not blogger:
        return ('exclude' if task.get('blogger_unknown_policy') == 'exclude' else 'review'), '来源博主未知，未确认通过博主筛选'
    if blogger.intersection(x.casefold() for x in task['excluded_bloggers']):
        return 'exclude', '命中排除博主'
    return 'keep', ''
