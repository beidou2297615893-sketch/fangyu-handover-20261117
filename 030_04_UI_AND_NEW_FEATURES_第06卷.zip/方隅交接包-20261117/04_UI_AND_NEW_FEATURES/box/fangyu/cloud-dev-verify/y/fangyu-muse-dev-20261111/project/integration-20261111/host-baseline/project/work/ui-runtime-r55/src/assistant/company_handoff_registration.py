"""One explicit original-key company registration; unknown is status-only.

The immutable preparation is never changed. The separate local attempt stores
only scope/digest metadata. A company draft is not resource delivery or cash.
"""
from copy import deepcopy
import json
import re
import time

from core import CoreError
from .company_handoff_preparation import CLOUD_ACTION, _hash, _json, _raw
from .company_handoff_original_status import CompanyHandoffOriginalStatus, CompanyHandoffOriginalStatusError
from .company_handoff_source_binding import CompanyHandoffSourceBinding, CompanyHandoffSourceBindingError

REGISTER = 'company_handoff_register'
GET = 'company_handoff_registration_get'
ATTEMPTS = 'company_handoff_registration_attempts'
CONTRACT = 'company_handoff_registration_v1'
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_MAX = 9007199254740991
_ROW_FIELDS = frozenset(('id', 'version', 'tenant_id', 'cloud_owner', 'company_id', 'environment_id',
    'device_id', 'actor_id', 'handoff_id', 'origin_id', 'handoff_revision', 'cloud_idempotency_key',
    'cloud_payload_hash', 'expected_cloud_channel_id', 'state', 'registration_source_verified',
    'created_at', 'updated_at', 'revision', 'record_hash'))


class CompanyHandoffRegistrationError(CoreError):
    def __init__(self, code, message, status=400, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_REGISTRATION_' + code
        self.status, self.mutation_committed = status, mutation_committed


def _fail(code, message, status=400, *, mutation=False):
    raise CompanyHandoffRegistrationError(code, message, status, mutation)


def _integer(value, minimum=0):
    return type(value) is int and minimum <= value <= _MAX


class CompanyHandoffRegistration:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access,
                 cloud_read, cloud_register, clock=None):
        if not callable(cloud_read) or not callable(cloud_register):
            raise ValueError('公司登记需要可信的原号读取与一次明确登记入口')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.device_id, self.cloud_read, self.cloud_register = device_id, cloud_read, cloud_register
        self.clock = clock or time.time
        options = dict(device_id=device_id, scope_guard=scope_guard, lead_access=lead_access, cloud_read=cloud_read)
        self.history = CompanyHandoffOriginalStatus(core, tenant, owner, company, **options)
        self.source = CompanyHandoffSourceBinding(core, tenant, owner, company, **options)
        self.preparation = self.history.preparation

    def _scope(self):
        try:
            self.history._scope()
        except Exception:
            _fail('SCOPE_CHANGED', '当前本人、公司环境或设备已变化，请回到原交接', 409)

    def _snapshot(self, handoff_id, user):
        try:
            return self.history._snapshot(handoff_id, user)
        except CompanyHandoffOriginalStatusError as error:
            _fail('LOCAL_CHANGED', '原准备、当前权限或完整来源需核对，请保留原号', error.status)

    def _tx_snapshot(self, db, handoff_id, user):
        """Same mature fingerprint inside the metadata CAS transaction."""
        state = self.preparation._read_state(db, handoff_id, user)
        origin = self.preparation._row(db, handoff_id)
        window = self.preparation._journal_state(db, state['lead'])
        history = self.history._historical_source(db, origin, state) if origin else None
        current = self.preparation._result(state, window, origin, read_only=True)['current']
        return dict(actor=state['actor'], origin=origin, current=current, state=state,
            fingerprint=_hash(dict(state=state['fingerprint'], window=window['hash'], origin=origin, history=history)))

    def _record_id(self, handoff_id):
        return _hash(['company-handoff-registration-v1', self.tenant, self.preparation.company_id, self.owner, handoff_id])

    def _row(self, db, snapshot):
        origin = snapshot['origin']
        if not origin:
            return None
        raw = db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',
            (ATTEMPTS, self._record_id(origin['handoff_id']))).fetchone()
        if not raw:
            return None
        try:
            row = json.loads(raw['body'])
            unsigned = {key: value for key, value in row.items() if key != 'record_hash'}
            fields = {'tenant_id': self.tenant, 'cloud_owner': self.owner, 'company_id': self.preparation.company_id,
                'environment_id': self.preparation.environment_id, 'device_id': self.device_id,
                'actor_id': snapshot['actor']['id'], 'handoff_id': origin['handoff_id'], 'origin_id': origin['origin_id'],
                'handoff_revision': origin['handoff_revision'], 'cloud_idempotency_key': origin['cloud_idempotency_key'],
                'cloud_payload_hash': origin['cloud_payload_hash'], 'expected_cloud_channel_id': origin['expected_cloud_channel_id']}
            if (raw['tenant_id'] != self.tenant or set(row) != _ROW_FIELDS or row['record_hash'] != _hash(unsigned) or row['version'] != 1
                    or row['id'] != self._record_id(origin['handoff_id']) or any(row[key] != value for key, value in fields.items())
                    or row['state'] not in ('unknown', 'recorded') or type(row['registration_source_verified']) is not bool
                    or not _integer(row['created_at'], 1577836800) or not _integer(row['updated_at'], row['created_at'])
                    or not _integer(row['revision'], 1)
                    or (row['state'] == 'unknown' and row['registration_source_verified'] is not False)):
                raise ValueError('attempt conflict')
            return row
        except Exception:
            _fail('ATTEMPT_CONFLICT', '原公司登记元数据完整性需核对，不能重新登记', 409)

    @staticmethod
    def _put(db, row, *, new=False):
        unsigned = {key: value for key, value in row.items() if key != 'record_hash'}
        value = dict(unsigned, record_hash=_hash(unsigned))
        if new:
            db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                (ATTEMPTS, value['id'], value['tenant_id'], _json(value)))
        else:
            changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (_json(value), ATTEMPTS, value['id'], value['tenant_id']))
            if changed.rowcount != 1:
                _fail('ATTEMPT_CONFLICT', '原登记范围已变化，请保留原号核对', 409)
        return value

    @staticmethod
    def _commit(db):
        db.commit()

    def _expected(self, snapshot, data):
        origin = snapshot['origin']
        if not origin:
            _fail('PREPARATION_REQUIRED', '请先保存本次交接准备，再明确登记公司草稿', 409)
        if (origin['origin_id'] != data['expected_origin_id']
                or origin['handoff_revision'] != data['expected_handoff_revision']):
            _fail('ORIGIN_CHANGED', '当前页面不是原准备版本，请读取原交接后再确认', 409)

    def _source_read(self, snapshot):
        origin = snapshot['origin']
        try:
            answer = self.cloud_read(deepcopy(snapshot['actor']), 'acquisition_source_binding_read',
                dict(event_id=origin['source_event_id'], payload_hash=origin['source_payload_hash'], expected_device_id=origin['device_id']))
            return self.source._binding(answer, origin)
        except Exception as error:
            if getattr(error, 'code', '').endswith('_SESSION_REQUIRED'):
                _fail('SESSION_REQUIRED', '请在设置中明确连接原公司，保留原准备后再核对', 409)
            _fail('SOURCE_UNAVAILABLE', '原来源公司记录不可核对，请保留原准备；未自动归档或重发', 503)

    def _status_read(self, snapshot):
        try:
            answer = self.cloud_read(deepcopy(snapshot['actor']), 'acquisition_handoff_operation_status',
                dict(operation_action=CLOUD_ACTION, idempotency_key=snapshot['origin']['cloud_idempotency_key']))
            return self.history._receipt(answer, snapshot['origin'])
        except Exception as error:
            if getattr(error, 'code', '').endswith('_SESSION_REQUIRED'):
                _fail('SESSION_REQUIRED', '请明确连接原公司后只读核对原登记，不要换编号', 409)
            _fail('STATUS_UNAVAILABLE', '原公司登记回执暂不可核对，请保留原号；未再次登记', 503)

    def _response_source(self, answer, snapshot, body):
        if not isinstance(answer, dict) or set(answer) != {'item', 'replayed'} or type(answer['replayed']) is not bool:
            _fail('WRITE_RECEIPT_INVALID', '公司登记回执需核对，请保留原号', 409, mutation=None)
        item = answer['item']
        origin = snapshot['origin']
        lead = snapshot['state']['lead']
        source = dict(platform=lead['platform'], author_id=lead['author_id'], comment_id=lead['comment_id'],
            source_lead_hash=_raw(lead['id']), device_id=self.device_id, original_text_hash=_raw(lead['text']),
            evidence_source='device_report', platform_provenance_verified=False)
        consent = item.get('consent') if isinstance(item, dict) else None
        if (not isinstance(item, dict) or item.get('channel_id') != origin['expected_cloud_channel_id']
                or item.get('company_id') != self.preparation.company_id or item.get('source_owner') != self.owner
                or item.get('source_event_id') != origin['source_event_id'] or item.get('source') != source
                or item.get('customer_id') != 'cu_'+_raw(lead['platform']+':author:'+lead['author_id'])
                or item.get('recipient_id') != body['recipient_id'] or item.get('purpose') != body['purpose']
                or item.get('contact_reference') != body['contact_reference'] or item.get('qualification') != 'qualified'
                or not isinstance(consent, dict) or any(consent.get(key) != value for key, value in body['consent'].items())
                or consent.get('evidence_source') != 'operator_recorded' or consent.get('independently_verified') is not False
                or item.get('platform_delivery_verified') is not False or item.get('storage_scope') != 'company_server_ledger'
                or item.get('contact_delivery') != 'platform_reference_only'
                or (answer['replayed'] is False and (item.get('revision') != 1 or type(item.get('revision')) is not int or item.get('status') != 'draft'))):
            _fail('WRITE_SOURCE_MISMATCH', '公司登记来源与原准备不一致，请保留原号核对', 409, mutation=None)

    def _result(self, snapshot, row, receipt=None, binding=None, *, read_only, dispatched=False, committed=False):
        base = self.history._result(snapshot, receipt)
        recorded = receipt is not None and receipt['state'] == 'recorded'
        state = 'not_attempted' if row is None else 'recorded' if recorded else 'unknown'
        matched = binding is not None and binding['state'] == 'matched'
        base.update(contract=CONTRACT, read_only=read_only, mutation_committed=committed,
            local_only=row is None, state=state, attempt=({key: row[key] for key in
                ('state', 'created_at', 'updated_at', 'registration_source_verified')} | {'attempt_id': row['id']}) if row else None,
            company_event_payload_matched=matched,
            registration_source_verified=recorded and matched and row is not None and row['registration_source_verified'],
            eligible_for_company_submit=False, can_register=row is None and snapshot['origin'] is not None and snapshot['current']['preparation_usable'],
            previous_company_dispatch_status='recorded' if recorded else 'unknown',
            cloud_register_requested=dispatched, no_dispatch=not dispatched,
            no_dispatch_scope='this_registration_get_only' if read_only else 'this_registration_call_only')
        return base

    def _recover(self, snapshot, row, user, *, read_only):
        receipt = self._status_read(snapshot)
        binding = self._source_read(snapshot)
        after = self._snapshot(snapshot['current']['handoff_id'], user)
        if after['fingerprint'] != snapshot['fingerprint']:
            _fail('LOCAL_CHANGED', '核对期间原来源、授权或本人范围已变化，请在原交接重新读取', 409)
        with self.core.lock, self.core.store.connect() as db:
            fresh = self._row(db, after)
        if fresh != row:
            _fail('ATTEMPT_CHANGED', '原登记状态读取期间已变化，请只读重新核对', 409)
        last = self._snapshot(snapshot['current']['handoff_id'], user)
        if last['fingerprint'] != after['fingerprint']:
            _fail('LOCAL_CHANGED', '返回时本人权限或原准备已变化，请在原交接重新读取', 409)
        self._scope()
        return self._result(last, row, receipt, binding, read_only=read_only)

    def execute(self, action, data, user):
        expected = {'handoff_id'} if action == GET else {'handoff_id', 'expected_origin_id', 'expected_handoff_revision'}
        if (action not in (GET, REGISTER) or not isinstance(data, dict) or set(data) != expected
                or not isinstance(data.get('handoff_id'), str) or not _HANDOFF.fullmatch(data['handoff_id'])
                or (action == REGISTER and (not isinstance(data.get('expected_origin_id'), str)
                    or not _HEX.fullmatch(data['expected_origin_id']) or not _integer(data.get('expected_handoff_revision'), 1)))):
            _fail('INVALID_INPUT', '公司登记只接受本人原交接与原准备版本，不能传入新公司编号')
        started = False
        try:
            before = self._snapshot(data['handoff_id'], user)
            with self.core.lock, self.core.store.connect() as db:
                row = self._row(db, before)
            if action == GET:
                if row:
                    return self._recover(before, row, user, read_only=True)
                after = self._snapshot(data['handoff_id'], user)
                with self.core.lock, self.core.store.connect() as db:
                    if self._row(db, after) is not None or before['fingerprint'] != after['fingerprint']:
                        _fail('ATTEMPT_CHANGED', '原准备读取期间已变化，请重新核对', 409)
                last = self._snapshot(data['handoff_id'], user)
                if last['fingerprint'] != after['fingerprint']:
                    _fail('LOCAL_CHANGED', '返回时本人权限或原准备已变化，请重新读取', 409)
                self._scope()
                return self._result(last, None, read_only=True)
            self._expected(before, data)
            if row:
                started = True  # Historical unknown must not be exposed as a new safe retry.
                return self._recover(before, row, user, read_only=False)
            if not before['current']['preparation_usable']:
                _fail('PREPARATION_BLOCKED', '当前来源、客户授权或交接条件已变化，登记保持暂停', 409)
            binding = self._source_read(before)
            if binding['state'] != 'matched':
                _fail('SOURCE_NOT_RECORDED', '公司尚未核对到原来源，请按原流程归档；本次未登记', 409)
            with self.core.lock, self.core.store.connect() as db:
                # Per-connection only: a competing mature reader may nest an
                # authorization read. Never keep a pending writer for 30s.
                db.execute('PRAGMA busy_timeout=500')
                db.execute('BEGIN IMMEDIATE')
                fresh = self._tx_snapshot(db, data['handoff_id'], user)
                if fresh['fingerprint'] != before['fingerprint']:
                    _fail('LOCAL_CHANGED', '原准备或当前授权已变化，本次未登记', 409)
                row = self._row(db, fresh)
                if row is None:
                    body = self.preparation._cloud_payload(fresh['state'], fresh['origin']['source_event_id'], fresh['origin']['cloud_idempotency_key'])
                    if _hash(body) != fresh['origin']['cloud_payload_hash']:
                        _fail('PAYLOAD_CHANGED', '原登记内容已变化，不能更换原号继续', 409)
                    now = int(self.clock())
                    origin = fresh['origin']
                    row = self._put(db, dict(id=self._record_id(data['handoff_id']), version=1, tenant_id=self.tenant,
                        cloud_owner=self.owner, company_id=self.preparation.company_id, environment_id=self.preparation.environment_id,
                        device_id=self.device_id, actor_id=fresh['actor']['id'], handoff_id=data['handoff_id'], origin_id=origin['origin_id'],
                        handoff_revision=origin['handoff_revision'], cloud_idempotency_key=origin['cloud_idempotency_key'],
                        cloud_payload_hash=origin['cloud_payload_hash'], expected_cloud_channel_id=origin['expected_cloud_channel_id'],
                        state='unknown', registration_source_verified=False, created_at=now, updated_at=now, revision=1), new=True)
                    started = True
                    self._commit(db)
                    owns_dispatch = True
                else:
                    owns_dispatch = False
                    db.rollback()  # An existing attempt needs no writer commit.
            if not owns_dispatch:
                started = True
                return self._recover(before, row, user, read_only=False)
            immediate = self._snapshot(data['handoff_id'], user)
            if immediate['fingerprint'] != before['fingerprint']:
                _fail('LOCAL_CHANGED', '提交前原准备或本人范围已变化，请保留原号核对', 409, mutation=None)
            answer = self.cloud_register(deepcopy(fresh['actor']), CLOUD_ACTION, deepcopy(body))
            self._response_source(answer, fresh, body)
            receipt = self._status_read(before)
            binding = self._source_read(before)
            if receipt['state'] != 'recorded' or binding['state'] != 'matched':
                _fail('RESULT_UNKNOWN', '原公司登记或来源证据仍待核对，请保留原号；不要再次登记', 409, mutation=None)
            after = self._snapshot(data['handoff_id'], user)
            if before['fingerprint'] != after['fingerprint']:
                _fail('LOCAL_CHANGED', '公司返回后当前来源、授权或本人范围已变化，保留原号核对', 409, mutation=None)
            with self.core.lock, self.core.store.connect() as db:
                db.execute('PRAGMA busy_timeout=500')
                db.execute('BEGIN IMMEDIATE')
                final = self._tx_snapshot(db, data['handoff_id'], user)
                if final['fingerprint'] != before['fingerprint'] or self._row(db, final) != row:
                    _fail('LOCAL_CHANGED', '登记核对期间原准备或元数据已变化，请保留原号', 409, mutation=None)
                row = self._put(db, dict(row, state='recorded', registration_source_verified=True,
                    updated_at=max(row['created_at'], int(self.clock())), revision=row['revision']+1))
                self._commit(db)
            final = self._snapshot(data['handoff_id'], user)
            if final['fingerprint'] != before['fingerprint']:
                _fail('LOCAL_CHANGED', '返回时本人范围已变化，请在原交接读取原号', 409, mutation=None)
            self._scope()
            return self._result(final, row, receipt, binding, read_only=False, dispatched=True, committed=True)
        except CompanyHandoffRegistrationError as error:
            if action == GET:
                error.mutation_committed = False
            elif started:
                error.mutation_committed = None
            raise
        except Exception:
            _fail('RESULT_UNKNOWN' if started else 'UNAVAILABLE',
                '公司原登记暂不可核对，请保留原交接编号；未自动重发', 503,
                mutation=None if action == REGISTER and started else False)
