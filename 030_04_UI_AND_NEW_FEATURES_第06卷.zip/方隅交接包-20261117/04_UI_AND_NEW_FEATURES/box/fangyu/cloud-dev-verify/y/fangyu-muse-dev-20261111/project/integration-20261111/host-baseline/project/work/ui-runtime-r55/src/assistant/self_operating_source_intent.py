"""Explicit local-owner AI over original archived receipts and cloud AI ledger.

Local and remote identities are separate. No DeviceSession, tenant migration,
platform grant, automatic login/refresh, background batch or model call at startup.
"""
from copy import deepcopy
from contextlib import contextmanager, ExitStack
import math
import re
import stat
import threading
import time

from core import CoreError
from core.service_plans import require_feature
from integrations import Integrations, IntegrationError, endpoint, request_json
from .ai_workflow import LocalAIWorkflow, digest
from .ai_attempts import AIRequestReview
from .self_operating_read import OwnerReadWorkspace, _OwnerReadInstance, _plain_directory
from .self_operating_archive import OwnerSourceArchive, _OwnerArchiveScope
from .source_intent_analysis import SourceIntentAnalysis, SourceIntentError, ACTIONS, ACTION, SOURCES, _row, _hash

_SEAL=object()
_KEY='owner_ai_cloud'
_OPERATIONS=frozenset({'ai_profile','intent_analyze','ai_attempt_status'})
_ACTOR=('id','tenant_id','username','role','cloud_bound','disabled','personal_owner',
        'development_local_only','permission_revision')
_ACCOUNT=('id','tenant_id','cloud_owner','platform','platform_uid','conn_id')
_REMOTE=('endpoint','environment_id','company_id','username','role')
_NAME=re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,127}\Z')

def _stable_actor(user):return {key:user.get(key) for key in _ACTOR}
def _archive_actor(user):return {key:user.get(key) for key in ('id','tenant_id','username','role','cloud_bound','personal_owner')}
def _account_identity(account):return {key:account.get(key) for key in _ACCOUNT}
def _hex(value):return type(value) is str and re.fullmatch(r'[0-9a-f]{64}',value) is not None

class _OwnerAIWorkflow(LocalAIWorkflow):
    # Only a namespace around the original key. All model validation, quotas,
    # aliases, attempts and writeback remain in the original LocalAIWorkflow.
    def _key(self,user,kind,payload,profile):
        return digest(['owner_remote_ai_v1',self.host_context(),super()._key(user,kind,payload,profile)])

class _OwnerAICloudScope:
    """An exact private transport scope; caller dictionaries cannot mint it."""
    def __init__(self,seal,host,binding):
        if seal is not _SEAL or type(host) is not _OwnerSourceIntentHost:
            raise IntegrationError('自营 AI 服务范围无法核对')
        self._seal,self.host,self.integrations=seal,host,host.service.integrations
        self.binding=deepcopy(binding)
        self.config={'cloud':{key:binding['remote'][key] for key in ('endpoint','environment_id')},
                     'sessions':{host.user['id']:deepcopy(binding['session'])}}

    def check(self,user,config,operation):
        if (self._seal is not _SEAL or type(self.host) is not _OwnerSourceIntentHost
                or self.host.service.integrations is not self.integrations
                or operation not in _OPERATIONS or config!=self.config):
            raise IntegrationError('本用途仅允许原 AI 资料、明确分析和原请求核对')
        self.host.check(user,feature=operation!='ai_attempt_status')
        if self.host.service._configured(self.host)!=self.binding:
            raise IntegrationError('原 AI 服务或成员会话已变化；保留原编号，不自动重发')
        return self.binding['remote']['company_id']

    def session(self):return deepcopy(self.binding['session'])

class _OwnerSourceIntentHost:
    def __init__(self,seal,service,token,user,account=None):
        if seal is not _SEAL or type(service) is not OwnerSourceIntent:
            raise SourceIntentError('自营来源分析需要可信本人范围')
        self._seal,self.service,self.token=seal,service,token
        self.server,self.core,self.executor=service.server,service.core,service
        self.user=deepcopy(user);self.account=deepcopy(account)
        self.actor=digest(_stable_actor(user));self.device_id=service.instance_id
        self.binding_id=digest(['local_owner_source_intent_v1',self.device_id,self.actor])
        self.provider=None
        self.check(user,feature=False)

    def check(self,user,*,feature=True,db=None):
        service=self.service
        if self._seal is not _SEAL or type(service) is not OwnerSourceIntent:
            raise SourceIntentError('自营来源分析范围已变化')
        current=service._current(self.token)
        saved=_row(db,'users',self.user['id'],service.tenant) if db is not None else current
        if (saved is None or digest(_stable_actor(saved))!=self.actor
                or digest(_stable_actor(current))!=self.actor or digest(_stable_actor(user))!=self.actor):
            raise SourceIntentError('原本人身份已变化，请保留原分析编号')
        if feature:
            require_feature(self.server.company,'intent_analysis')
            if self.account is None:raise SourceIntentError('新分析未绑定原读取账号')
            if self.provider is None or service._configured(self)!=self.provider.binding:
                raise SourceIntentError('分析期间原 AI 服务或成员绑定已变化')
            now=service._source_account(self.token,current,self.account['id'])
            if now!=self.account:raise SourceIntentError('分析期间原账号记录已变化')
            service.workspace.execution_guard(self.account['platform'])
            if self.account['platform']=='xiaohongshu':
                review=self.server._runtime_license_review_binding
                if review is None or not review.current(self.server.company):
                    raise SourceIntentError('当前组件用途需核对；未开始或保存新分析')
        return saved

    def check_account(self,account):
        if account!=self.account:raise SourceIntentError('新分析的当前账号快照已变化')

    def archive_binding_matches(self,receipt,account):
        schema=('local_owner_douyin_archive_v1' if account.get('platform')=='douyin' else
                'local_owner_archive_v2' if account.get('platform')=='xiaohongshu' else None)
        if schema is None:return False
        if account['platform']=='douyin':
            from core.platform_reads import _digest as archive_digest
        else:archive_digest=digest
        expected={'schema':schema,'local_instance_id':self.device_id,
            'account_id':account['id'],'account_digest':archive_digest(_account_identity(account)),
            'actor_digest':archive_digest(_archive_actor(self.user))}
        return receipt.get('local_owner_scope')==expected

    def archive_batch_matches(self,batch,sources):
        # Canonical Dy sources survive later deduplicated saves. The later
        # original successful PRA batch may legitimately have another input
        # digest, while its actor/account/selected canonical sources remain
        # bound by the surrounding immutable receipt and source checks.
        if self.account.get('platform')=='douyin':
            return (type(batch.get('source_count')) is int and 1<=batch['source_count']<=20
                    and _hex(batch.get('input_digest'))
                    and all(source.get('platform')=='douyin' for source in sources))
        return batch.get('input_digest')==sources[0].get('input_digest')

    def operation_scope(self):
        if self.account is None or self.provider is None:
            raise SourceIntentError('新分析缺少当前账号或原 AI 服务绑定')
        return {'schema':'local_owner_source_intent_v1','local_instance_id':self.device_id,
            'account_id':self.account['id'],'account_digest':digest(_account_identity(self.account)),
            'actor_digest':self.actor,'provider_binding_digest':self.service._provider_digest(self.provider.binding)}

    def check_record(self,record):
        scope=record.get('owner_source_scope')
        if (type(scope) is not dict or set(scope)!={'schema','local_instance_id','account_id',
                'account_digest','actor_digest','provider_binding_digest'}
                or scope['schema']!='local_owner_source_intent_v1' or scope['local_instance_id']!=self.device_id
                or scope['actor_digest']!=self.actor or not _hex(scope['provider_binding_digest'])):
            raise SourceIntentError('原分析的本机范围需核对',mutation_committed=None)
        account=self.service._source_account(self.token,self.check(self.user,feature=False),scope['account_id'],cleanup=True)
        if digest(_account_identity(account))!=scope['account_digest']:
            raise SourceIntentError('原分析账号身份或归属已变化',mutation_committed=None)

    def attempt_status(self,record):
        # Local saved truth remains readable after risk/component/remote expiry.
        # A changed member never queries the old member's charge/result key.
        try:
            binding=self.service._configured(self)
            if self.service._provider_digest(binding)!=record['owner_source_scope']['provider_binding_digest']:
                return None
            self.provider=_OwnerAICloudScope(_SEAL,self,binding)
            return self.service.ai.attempts.status(self.user,{'request_id':record['original_request_id']})
        except (IntegrationError,AIRequestReview):
            self.check(self.user,feature=False)
            return None

class OwnerSourceIntent:
    """Trusted construction only; explicit actions return safe original DTOs."""
    ACTIONS=ACTIONS|frozenset({'owner_source_ai_connect','owner_source_ai_status'})

    def __init__(self,workspace,archive):
        if (type(workspace) is not OwnerReadWorkspace or type(workspace.instance) is not _OwnerReadInstance
                or type(archive) is not OwnerSourceArchive or archive.workspace is not workspace
                or type(archive._scope) is not _OwnerArchiveScope or archive._archive is None
                or archive._scope._reads is not workspace._reads
                or type(workspace.server.integrations) is not Integrations
                or workspace.server.integrations.core is not workspace.server.core):
            raise SourceIntentError('自营分析必须沿可信实例与原归档服务创建')
        self.workspace,self.archive=workspace,archive
        self.server,self.core,self.instance=workspace.server,workspace.server.core,workspace.instance
        self.integrations=self.server.integrations
        self.instance_id=self.instance.check()['selfOperatingRead']['instance_id']
        self._identity=None;self._tls=threading.local()
        self.tenant=self.owner=self.user_id=None
        self.ai=_OwnerAIWorkflow(self.core,self._cloud,company=lambda:self.server.company,host_context=self._context)
        self.ai.host_context=self._context

    def _current(self,token):
        company=self.instance.check()
        if (self.server.core is not self.core or self.server._self_operating_reads is not self.workspace
                or self.workspace.instance is not self.instance or self.archive.workspace is not self.workspace
                or self.archive._scope._reads is not self.workspace._reads
                or self.server.integrations is not self.integrations
                or company['selfOperatingRead']['instance_id']!=self.instance_id
                or self.core.store.directory!=self.instance.directory/'data'
                or self.core.deployment_config.get('id')!=company['id']
                or self.core.deployment_config.get('edition')!='owner'
                or self.core.deployment_config.get('personalMode') is not True):
            raise SourceIntentError('自营分析不能接管其他工作台或旧数据')
        user=self.workspace._actor(token)
        identity=digest(_stable_actor(user))
        if self._identity is None:
            self._identity=identity
            self.tenant,self.owner,self.user_id=user['tenant_id'],user['username'],user['id']
        if identity!=self._identity:raise SourceIntentError('此分析服务的本人范围已变化')
        return user

    def _lead_access(self,user,lead):
        if lead.get('tenant_id')!=self.tenant or lead.get('cloud_owner')!=user['username']:
            raise SourceIntentError('只能分析本实例本人已归档的来源')

    def _source_account(self,token,user,ident,*,cleanup=False):
        # Only the persisted account platform chooses a fixed, sealed route;
        # HTTP fields cannot select a guard or borrow a different proof schema.
        account=self.core._get('accounts',ident,user['tenant_id'])
        platform=account.get('platform')
        if platform=='xiaohongshu':
            return self.workspace._account(user,ident,cleanup=cleanup)
        if platform=='douyin' and self.workspace._douyin is not None and self.workspace._douyin_archive is not None:
            from .owner_douyin_read import OwnerDouyinRead
            from .owner_douyin_source_archive import OwnerDouyinSourceArchive
            if (type(self.workspace._douyin) is not OwnerDouyinRead
                    or type(self.workspace._douyin_archive) is not OwnerDouyinSourceArchive
                    or self.workspace._douyin_archive.workspace is not self.workspace):
                raise SourceIntentError('原抖音分析服务范围需核对')
            current,fresh=self.workspace._douyin._account(token,ident,metadata=cleanup,reading=not cleanup)
            if _stable_actor(current)!=_stable_actor(user):raise SourceIntentError('原本人身份已变化')
            return fresh
        raise SourceIntentError('此已保存来源未接入本人明确分析；预览不能借作客户来源')

    @contextmanager
    def _source_call(self,token,account):
        if account.get('platform')=='xiaohongshu':
            with self.workspace._call(token,account):yield
        elif account.get('platform')=='douyin' and self.workspace._douyin is not None:
            # This is the original Dy purpose/account/runtime guard. It performs
            # no platform read, and cannot replace the stored source proof.
            with ExitStack() as stack:
                try:stack.enter_context(self.workspace._douyin._call(token,account,'comments'))
                except (OSError,ValueError,TypeError,KeyError):
                    raise SourceIntentError('本人抖音用途或固定材料仍待核对；未开始新的分析') from None
                yield
        else:raise SourceIntentError('当前来源平台未接入本人明确分析')

    def _private_config(self):
        root=self.core.store.directory/'private-config'
        if self.integrations.root!=root:
            raise IntegrationError('AI 配置不属于此新自营实例')
        _plain_directory(self.core.store.directory,self.instance.work_root)
        if root.exists():_plain_directory(root,self.instance.work_root)
        # No discovery, import or copying of another instance's credential file.
        for file in (self.integrations._path(self.tenant),self.integrations._path(self.tenant).with_suffix('.tmp')):
            try:attrs=file.lstat()
            except FileNotFoundError:continue
            if (file.parent!=root or not stat.S_ISREG(attrs.st_mode) or file.is_symlink()
                    or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
                    or attrs.st_nlink!=1):
                raise IntegrationError('AI 私有配置不能链接或接管其他实例文件')

    def _read_config(self):
        self._private_config()
        return self.integrations._read(self.tenant)

    def _configured(self,host):
        host.check(host.user,feature=False)
        with self.integrations.lock:config=self._read_config()
        binding=config.get(_KEY)
        if binding is None:raise IntegrationError('尚未连接 AI 服务；本机本人登录不会开通模型或额度')
        if (type(binding) is not dict or set(binding)!={'schema','local_instance_id','local_actor_digest','remote','session'}
                or binding['schema']!='owner_ai_cloud_v1' or binding['local_instance_id']!=self.instance_id
                or binding['local_actor_digest']!=host.actor or type(binding['remote']) is not dict
                or set(binding['remote'])!=set(_REMOTE) or type(binding['session']) is not dict
                or set(binding['session'])!={'token','expires','username'}):
            raise IntegrationError('原 AI 服务与本机本人绑定需核对')
        remote,session=binding['remote'],binding['session']
        if (not all(type(remote[k]) is str and remote[k] for k in _REMOTE)
                or endpoint(remote['endpoint'])!=remote['endpoint']
                or not _NAME.fullmatch(remote['environment_id']) or not _NAME.fullmatch(remote['company_id'])
                or len(remote['username'])>80 or any(ord(c)<32 or ord(c)==127 for c in remote['username'])
                or remote['role'] not in ('admin','operator') or session['username']!=remote['username']
                or type(session['token']) is not str or not 1<=len(session['token'])<=8192
                or '\r' in session['token'] or '\n' in session['token']
                or type(session['expires']) not in (int,float) or not math.isfinite(session['expires'])):
            raise IntegrationError('原 AI 服务会话格式需核对')
        if session['expires']<=time.time():raise IntegrationError('原 AI 成员会话已过期；请明确重新连接，未自动续期')
        return deepcopy(binding)

    @staticmethod
    def _provider_digest(binding):
        return digest({key:binding[key] for key in ('schema','local_instance_id','local_actor_digest','remote')})

    def _host(self):
        host=getattr(self._tls,'host',None)
        if type(host) is not _OwnerSourceIntentHost or host.service is not self:
            raise IntegrationError('AI 调用不在当前明确自营操作内')
        return host

    def _context(self):
        host=self._host();host.check(host.user,feature=False)
        if host.provider is None:raise IntegrationError('原 AI 服务绑定无法核对')
        host.provider.check(host.user,host.provider.config,'ai_attempt_status')
        remote=host.provider.binding['remote']
        return {'usage_scope':'owner_archived_source_intent','local_instance_id':self.instance_id,
            'local_actor_digest':host.actor,'environment_id':remote['environment_id'],
            'company_id':remote['company_id'],'remote_binding_digest':self._provider_digest(host.provider.binding)}

    def _cloud(self,user,operation,data):
        host=self._host()
        if host.provider is None:raise IntegrationError('AI 成员服务尚未连接')
        return self.integrations._cloud(host.provider.config,user,operation,_owner_scope=host.provider,**data)

    def _status(self,host):
        try:
            binding=self._configured(host);state='connected'
        except IntegrationError:
            with self.integrations.lock:binding=self._read_config().get(_KEY)
            state=('not_configured' if binding is None else 'expired' if type(binding) is dict
                and type(binding.get('session')) is dict and type(binding['session'].get('expires')) in (int,float)
                and math.isfinite(binding['session']['expires']) and binding['session']['expires']<=time.time()
                else 'scope_changed')
            binding=None
        host.check(host.user,feature=False)
        return {'purpose':'owner_archived_source_intent','status':state,
            'remote_company_id':binding['remote']['company_id'] if binding else None,
            'remote_username':binding['remote']['username'] if binding else None,
            'account_ready':False,'billing_verified':False,'auto_retry':False,'executes_model':False}

    def _connect(self,host,data):
        if (set(data)!={'endpoint','environment_id','company_id','username','password'}
                or any(type(data[k]) is not str for k in data)
                or not _NAME.fullmatch(data['environment_id']) or not _NAME.fullmatch(data['company_id'])
                or not 1<=len(data['username'].strip())<=80 or not 1<=len(data['password'])<=256
                or any(ord(c)<32 or ord(c)==127 for c in data['username']+data['password'])):
            raise SourceIntentError('请明确现有 AI 服务地址、环境、公司与成员账号')
        remote={key:data[key].strip() for key in ('endpoint','environment_id','company_id','username')}
        remote['endpoint']=endpoint(remote['endpoint'])
        if not remote['endpoint']:raise SourceIntentError('请填写现有服务的 HTTPS 地址')
        with self.integrations.lock:original=self._read_config()
        host.check(host.user,feature=False)
        result=request_json(remote['endpoint'],{'operation':'login','environment_id':remote['environment_id'],
            'username':remote['username'],'password':data['password']})
        profile=result.get('user');expires=result.get('expires');token=result.get('token')
        if (result.get('contract')!='fangyu-workspace-v1' or result.get('environment_id')!=remote['environment_id']
                or result.get('company_id')!=remote['company_id'] or type(profile) is not dict
                or profile.get('username')!=remote['username'] or profile.get('role') not in ('admin','operator')
                or profile.get('disabled') or type(token) is not str or not 1<=len(token)<=8192
                or '\r' in token or '\n' in token or type(expires) not in (int,float)
                or not math.isfinite(expires) or expires<=time.time()):
            raise SourceIntentError('远端公司、成员或会话尚未核实；未保存新连接')
        remote['role']=profile['role']
        binding={'schema':'owner_ai_cloud_v1','local_instance_id':self.instance_id,
            'local_actor_digest':host.actor,'remote':remote,
            'session':{'token':token,'expires':min(expires,time.time()+8*3600),'username':remote['username']}}
        with self.core.lock,self.integrations.lock:
            host.check(host.user,feature=False)
            if self._read_config()!=original:
                raise SourceIntentError('连接返回时本机配置已变化，未覆盖新配置')
            try:self.integrations._write(self.tenant,{**original,_KEY:binding})
            except Exception:
                raise SourceIntentError('本机连接保存结果待核对；请查看连接状态，未自动重试',mutation_committed=None) from None
        return self._status(host)

    def execute(self,token,action,data):
        if action not in self.ACTIONS or type(data) is not dict:
            raise SourceIntentError('不支持此自营分析操作')
        with self.workspace._lock:
            user=self._current(token)
            if getattr(self._tls,'host',None) is not None:raise SourceIntentError('明确分析不能嵌套')
            account=None
            if action==ACTION:
                ids=data.get('lead_ids')
                if type(ids) is not list or not ids or type(ids[0]) is not str:
                    raise SourceIntentError('请选择本机已归档的原评论')
                lead=self.core.store.get('leads',ids[0])
                source=self.core.store.get(SOURCES,_hash([self.tenant,lead.get('source_uid')])) if lead else None
                if not source:raise SourceIntentError('此评论未完成原来源归档，未开始分析')
                account=self._source_account(token,user,source.get('account_id'))
                if source.get('platform')!=account['platform'] or lead.get('platform')!=account['platform']:
                    raise SourceIntentError('原来源与读取账号平台不一致')
            host=_OwnerSourceIntentHost(_SEAL,self,token,user,account)
            self._tls.host=host
            try:
                if action=='owner_source_ai_connect':return self._connect(host,data)
                if action=='owner_source_ai_status':
                    if data:raise SourceIntentError('连接状态只接受空参数')
                    return self._status(host)
                if action==ACTION:
                    binding=self._configured(host)
                    host.provider=_OwnerAICloudScope(_SEAL,host,binding)
                    with self._source_call(token,account):
                        host.check(user)
                        return SourceIntentAnalysis._for_owner(host).execute(action,data,user)
                return SourceIntentAnalysis._for_owner(host).execute(action,data,user)
            finally:
                if getattr(self._tls,'host',None) is host:del self._tls.host
