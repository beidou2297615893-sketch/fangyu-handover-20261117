"""Owner-local Wx transport previews, never customer or platform identity.

Metadata does not create records. Explicit save reserves its original key and
account custody before writing bounded safe items. Only explicit reconciliation
under the real account/SQLite locks may finish a proven local non-commit.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re
import stat
import threading
import time

from core import CoreError
from core.platform_reads import PlatformReadService, _digest, normalize_sources
from .platform_receipt_archive import ReceiptArchiveError, _encoded, _hash, _safe_text, _safe_url
from .owner_channels_read import (OwnerChannelsRead, _OwnerChannelsCall, PURPOSE,
    _ID, _REQUEST, _plain_home, _plain_config, _port, _duplicates)

CONTRACT = 'owner_channels_preview_archive_v1'
SAVE = 'owner_channels_preview_save'
STATUS = 'owner_channels_preview_save_status'
RECONCILE = 'owner_channels_preview_reconcile'
PAGE = 'owner_channels_saved_preview_page'
DETAIL = 'owner_channels_saved_preview_detail'
ACTIONS = frozenset((SAVE, STATUS, RECONCILE, PAGE, DETAIL))
JOURNALS = 'owner_channels_preview_save_journals_v1'
READ_KEYS = 'owner_channels_preview_save_read_keys_v1'
BATCHES = 'owner_channels_saved_preview_batches_v1'
ITEMS = 'owner_channels_saved_preview_items_v1'
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_SEAL = object()
_SCOPE = {'kind': 'this_instance_local_preview', 'source_verification': 'transport_reported_only',
    'identity_verified': False, 'real_platform_verified': False,
    'customer_identity_verified': False, 'reply_allowed': False, 'storage_scope': 'this_device'}
_LIMITS = {'displayed_max': 20, 'history_page_max': 50, 'history_scan_max': 200,
    'local_storage': True, 'platform_requests': False, 'AI': False, 'contacts': False,
    'platform_identity_verified': False, 'auto_retry': False}
_ROOT = Path(__file__).parent.parent
_MATERIALS = ('assistant/owner_channels_preview_archive.py', 'assistant/self_operating_read.py',
    'core/platform_reads.py', 'web/workspace/self-operating-read.mjs',
    'assistant/platform_receipt_archive.py', 'assistant/owner_channels_read.py',
    'core/wechat_channels.py', 'core/adapters.py')
_COMMON = {'id', 'tenant_id', 'instance_id', 'actor_digest', 'account_id', 'caller_digest', 'record_hash'}
_JOURNAL = _COMMON | {'version', 'state', 'idempotency_key', 'read_request_id', 'payload_digest',
    'preview_digest', 'source_revision', 'preview_review_digest', 'storage_review_digest',
    'event_confirmation_digest', 'transport_binding_digest', 'batch_id', 'counts', 'created_at', 'updated_at'}
_REVERSE = _COMMON | {'kind', 'read_request_id', 'journal_id', 'key', 'payload_digest', 'created_at'}
_HEAD = _COMMON | {'kind', 'version', 'journal_id', 'key', 'updated_at'}
_BATCH = _COMMON | {'journal_id', 'preview_digest', 'event_confirmation_digest',
    'transport_binding_digest', 'counts', 'item_ids', 'created_at'}
_ITEM = _COMMON | {'batch_id', 'position', 'reported_source_digest', 'original_text_hash',
    'title', 'text', 'author', 'region', 'published_at', 'privacy_redacted', 'safe_text_hash'}
_COUNT_FIELDS = {'accepted_count', 'observed_count', 'displayed_count', 'requested_limit',
    'limit_exceeded', 'privacy_redacted_count'}
_ACTOR = ('id', 'tenant_id', 'username', 'role', 'personal_owner', 'cloud_bound')
_ACCOUNT = ('id', 'tenant_id', 'cloud_owner', 'platform')


def _fail(code, message, *, unknown=False):
    raise ReceiptArchiveError('OWNER_WX_PREVIEW_' + code, message,
        mutation_committed=None if unknown else False)


def _stamp(value):
    return type(value) in (int, float) and math.isfinite(value) and 0 <= value <= time.time()


def _hex(value):
    return type(value) is str and _HEX.fullmatch(value) is not None


def _seal_record(value):
    result = deepcopy(value)
    result['record_hash'] = _hash({k: v for k, v in result.items() if k != 'record_hash'})
    return result


def _counts(value):
    if (type(value) is not dict or set(value) != _COUNT_FIELDS
            or any(type(value[k]) is not int for k in _COUNT_FIELDS - {'limit_exceeded'})
            or not 1 <= value['accepted_count'] == value['displayed_count'] <= value['requested_limit'] <= 20
            or not value['displayed_count'] <= value['observed_count'] <= 1000
            or value['limit_exceeded'] is not (value['observed_count'] > value['requested_limit'])
            or not 0 <= value['privacy_redacted_count'] <= value['accepted_count']):
        _fail('RECORD_INVALID', '原本机预览数量或记录需核对', unknown=True)
    return deepcopy(value)


class _StoragePermit:
    def __init__(self, service):
        self.service = service

    def review(self):
        from core.runtime_license_policy import _plain
        service = self.service
        config = service.workspace.instance.check()
        path = _plain(service.workspace.instance.directory / 'owner-channels-preview-storage-review.json',
                      service.workspace.instance.directory)
        attrs = path.stat()
        if attrs.st_nlink != 1 or attrs.st_size > 16384:
            raise ValueError('本机预览保存审查文件无效')
        value = json.loads(path.read_bytes(), object_pairs_hook=_duplicates)
        if (type(value) is not dict or set(value) != {'schema', 'contract', 'scope', 'company_id',
                'instance_id', 'source_revision', 'limits', 'decision'}
                or type(value['schema']) is not int or value['schema'] != 1
                or value['contract'] != CONTRACT or value['scope'] != 'internal_owner_local_preview_storage'
                or value['company_id'] != config['id'] or value['instance_id'] != service.instance_id
                or type(value['limits']) is not dict or set(value['limits']) != set(_LIMITS)
                or any(type(value['limits'][k]) is not type(v) or value['limits'][k] != v
                       for k, v in _LIMITS.items())):
            raise ValueError('本机预览保存尚待独立技术审查')
        decision = value['decision']
        if (type(decision) is not dict or set(decision) != {'id', 'reviewer', 'internal_technical_use',
                'account_authorization', 'real_platform_verified', 'production_distribution'}
                or type(decision['id']) is not str or not _ID.fullmatch(decision['id'])
                or type(decision['reviewer']) is not str or not 1 <= len(decision['reviewer']) <= 160
                or any(ord(c) < 32 for c in decision['reviewer'])
                or decision['internal_technical_use'] is not True
                or any(decision[k] is not False for k in
                       ('account_authorization', 'real_platform_verified', 'production_distribution'))):
            raise ValueError('本机存储技术审查不能授平台身份或读权限')
        revision = _digest({name: hashlib.sha256(_plain(_ROOT / name, _ROOT).read_bytes()).hexdigest()
                            for name in _MATERIALS})
        if value['source_revision'] != revision:
            raise ValueError('本机预览保存源码版本已变化')
        return _digest(value)

    def current(self, revision):
        if self.review() != revision:
            raise ValueError('本机预览保存技术审查已变化')


class _OwnerChannelsPreviewArchiveScope:
    def __init__(self, service, seal):
        if seal is not _SEAL:
            _fail('SCOPE', '本人预览保存只接正规密封工厂')
        self.service = service
        self.workspace = service.workspace
        self.core = service.core
        self.reads = service.reads
        self.helper = self.workspace._channels
        self._tls = threading.local()

    def check(self):
        w = self.workspace
        if (type(w._channels_preview_archive) is not OwnerChannelsPreviewArchive
                or w._channels_preview_archive is not self.service
                or self.service.scope is not self or self.reads is not w._reads
                or self.reads._owner_channels_preview_archive_scope is not self
                or self.core is not w.server.core or self.helper is not w._channels
                or type(self.helper) is not OwnerChannelsRead or self.helper.scope.reads is not self.reads
                or self.reads._owner_channels_preview_scope is not self.helper.scope
                or self.core.store.directory != w.instance.directory / 'data'
                or w.server._self_operating_reads is not w
                or w.instance.check()['selfOperatingRead']['instance_id'] != self.service.instance_id):
            _fail('SCOPE', '原本人本机预览范围已变化', unknown=True)
        self.helper.scope.require_v2()

    def read_gate(self, call, entry, user, account):
        self.check()
        if (type(call) is not _OwnerChannelsCall or call.scope is not self.helper.scope
                or call.entry is not entry or call.reads is not self.reads or call.cached
                or call.thread != threading.get_ident() or not call.active):
            _fail('SCOPE', '当前读取不是原持锁本人调用', unknown=True)
        call.check()
        current = self.service._caller(call.frame['token'], account['id'])
        if current['user'] != user or current['account'] != account:
            _fail('SCOPE', '原账号读取主体已变化', unknown=True)
        self.service._require_idle(current)

    @contextmanager
    def capture(self, token, account_id, request_id, user):
        self.check()
        if getattr(self._tls, 'capture', None) is not None:
            _fail('SCOPE', '本机预览快照不能嵌套')
        account = self.helper.scope.account(user, account_id)
        entry = self.reads._operations.get(request_id)
        if type(entry) is not dict:
            _fail('SCOPE', '原视频号预览编号未确认')
        fields = entry.get('_owner_channels_input')
        if (type(fields) is not dict or set(fields) != {'account_id', 'request_id', 'reference', 'page', 'limit'}
                or fields.get('account_id') != account_id or fields.get('request_id') != request_id
                or fields.get('page') != 1 or type(fields.get('limit')) is not int or not 1 <= fields['limit'] <= 20):
            _fail('SCOPE', '原视频号预览输入范围需核对')
        port = _port(account.get('endpoint'))
        with self.helper.scope.frame(token, user, account, port, 'comments', request_id, fields):
            self._tls.capture = (entry, deepcopy(account), user, request_id)
            try:
                snapshot = self._snapshot(entry, user, account, request_id)
                yield snapshot
                if self.reads._operations.get(request_id) is not entry:
                    _fail('SCOPE', '提交前原预览编号已变化')
                latest = self.helper.scope.account(self.workspace._actor(token), account_id)
                if latest != account or self._snapshot(entry, user, latest, request_id) != snapshot:
                    _fail('SCOPE', '提交前原预览或账号来源已变化')
            finally:
                if hasattr(self._tls, 'capture'):
                    del self._tls.capture

    def _snapshot(self, entry, user, account, request_id):
        self.helper.scope.check(account)
        result = entry.get('response')
        if (entry.get('account_id') != account['id'] or entry.get('running') or entry.get('cancelled')
                or not self.helper.scope.entry_current(entry, user, account)
                or type(result) is not dict or result.get('platform') != 'wechat_channels'
                or result.get('action') != 'comments' or result.get('code') != 'completed'
                or result.get('purpose') != PURPOSE or result.get('source_verification') != 'transport_reported_only'
                or any(result.get(k) is not False for k in
                       ('archive_available', 'platform_writes', 'real_platform_verified', 'identity_verified'))
                or type(result.get('items')) is not list or not 1 <= len(result['items']) <= 20
                or normalize_sources('wechat_channels', result['items']) != result['items']
                or not _stamp(entry.get('observed_at'))):
            _fail('SCOPE', '原预览未完成、已取消、超界或来源需核对')
        counts = _counts({'accepted_count': len(result['items']), 'displayed_count': result.get('displayed_count'),
            'observed_count': result.get('observed_count'), 'requested_limit': result.get('requested_limit'),
            'limit_exceeded': result.get('limit_exceeded'), 'privacy_redacted_count': 0})
        frame = self.helper.scope._tls.frame
        origin = entry.get('origin')
        if (type(origin) is not dict or origin.get('account_id') != account['id']
                or origin.get('platform') != 'wechat_channels' or origin.get('device_id') != self.service.instance_id
                or origin.get('account_uid') not in ('', None) or origin.get('archive_scope_verified') is not False
                or origin.get('input_digest') != entry.get('fingerprint')
                or any(not _hex(origin.get(k)) for k in
                       ('account_binding_digest', 'connection_digest', 'license_digest', 'input_digest'))):
            _fail('SCOPE', '原预览证据不能作为微信身份或其他平台来源')
        directory = _plain_home(self.core.store.directory / 'accounts' / user['tenant_id'] / account['id'],
                                self.core.store.directory)
        path = directory / 'wechat_channels.json'
        _plain_config(path)
        saved = json.loads(path.read_bytes())
        if (type(saved) is not dict or set(saved) != {'endpoint', 'bound_client_id'}
                or saved['endpoint'] != account.get('endpoint')
                or saved['bound_client_id'] != account.get('bound_client_id')):
            _fail('SCOPE', '原本机连接配置与预览来源不一致')
        return {'request_id': request_id, 'operation_id': entry['operation_id'],
            'observed_at': entry['observed_at'], 'result': deepcopy(result), 'counts': counts,
            'preview_digest': _digest(result), 'source_revision': frame['sources'],
            'preview_review_digest': frame['revision'],
            'event_confirmation_digest': _hash(account.get('owner_channels_preview')),
            'transport_binding_digest': _hash(entry['_owner_channels_binding'])}


class OwnerChannelsPreviewArchive:
    ACTIONS = ACTIONS

    def __init__(self, workspace):
        from .self_operating_read import OwnerReadWorkspace
        if (type(workspace) is not OwnerReadWorkspace or type(workspace._channels) is not OwnerChannelsRead
                or type(workspace._reads) is not PlatformReadService):
            _fail('SCOPE', '视频号本机保存须绑定正规本人v2读取服务')
        self.workspace = workspace
        self.core = workspace.server.core
        self.store = self.core.store
        self.reads = workspace._reads
        self.instance_id = workspace.instance.check()['selfOperatingRead']['instance_id']
        self.permit = _StoragePermit(self)
        self.scope = _OwnerChannelsPreviewArchiveScope(self, _SEAL)
        self._tls = threading.local()
        if self.reads._owner_channels_preview_archive_scope is not None:
            _fail('SCOPE', '本人预览保存范围不能重绑')
        self.reads._owner_channels_preview_archive_scope = self.scope

    def describe(self):
        try:
            self.permit.review()
            status = 'reviewed'
        except (ValueError, CoreError, OSError, TypeError, KeyError):
            status = 'pending'
        return {'contract': CONTRACT, 'instance_id': self.workspace.instance.check()['selfOperatingRead']['instance_id'],
            'available': True, 'status': status, 'limit': 20, 'history_page_limit': 50, 'history_scan_limit': 200,
            'platform_read_only': True, 'identity_verified': False, 'platform_requests_started': False, 'auto_retry': False}

    def _caller(self, token, account_id):
        self.scope.check()
        if type(account_id) is not str or not _ID.fullmatch(account_id):
            _fail('INPUT', '请选择本人的原视频号账号')
        with self.core.lock:
            user = self.workspace._actor(token)
            account = deepcopy(self.core._get('accounts', account_id, user['tenant_id']))
            self.core._account_access(user, account)
            if (account.get('tenant_id') != user['tenant_id'] or account.get('cloud_owner') != user['username']
                    or account.get('platform') != 'wechat_channels'):
                _fail('SCOPE', '原本机预览账号不属于当前本人', unknown=True)
        actor = _hash({k: user.get(k) for k in _ACTOR})
        caller = _hash({'instance_id': self.instance_id, 'actor': {k: user.get(k) for k in _ACTOR},
                        'account': {k: account.get(k) for k in _ACCOUNT}})
        return {'token': token, 'user': user, 'account': account, 'actor_digest': actor, 'caller_digest': caller}

    def _fresh(self, context):
        value = self._caller(context['token'], context['account']['id'])
        if value['caller_digest'] != context['caller_digest']:
            _fail('SCOPE', '原保存记录的本人范围已变化', unknown=True)
        return value

    def _common(self, context, ident):
        return {'id': ident, 'tenant_id': context['user']['tenant_id'], 'instance_id': self.instance_id,
            'actor_digest': context['actor_digest'], 'account_id': context['account']['id'],
            'caller_digest': context['caller_digest']}

    def _id(self, context, kind, value=''):
        return _hash(['owner_channels_preview_' + kind + '_v1', self.instance_id,
            context['user']['tenant_id'], context['user']['id'], context['account']['id'], value])

    @staticmethod
    def _batch_id(journal_id):
        return _hash(['owner_channels_preview_batch_v1', journal_id])

    @staticmethod
    def _item_id(batch_id, position):
        return _hash(['owner_channels_preview_item_v1', batch_id, position])

    def _row(self, db, entity, ident):
        raw = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (entity, ident, self._tenant)).fetchone()
        if raw is None:
            return None
        try:
            value = json.loads(raw['body'], object_pairs_hook=_duplicates)
        except (ValueError, TypeError):
            _fail('RECORD_INVALID', '原本机记录内容无法核对', unknown=True)
        if (type(value) is not dict or value.get('id') != ident or value.get('tenant_id') != self._tenant
                or not _hex(value.get('record_hash'))
                or value['record_hash'] != _hash({k: v for k, v in value.items() if k != 'record_hash'})):
            _fail('RECORD_INVALID', '原本机记录版本或摘要不一致', unknown=True)
        return value

    @property
    def _tenant(self):
        context = getattr(self._tls, 'context', None)
        if context is None:
            _fail('SCOPE', '本人记录查询范围未建立', unknown=True)
        return context['user']['tenant_id']

    @contextmanager
    def _using(self, context):
        if getattr(self._tls, 'context', None) is not None:
            _fail('SCOPE', '本人预览保存不接受嵌套调用', unknown=True)
        self._tls.context = context
        try:
            yield
        finally:
            del self._tls.context

    def _checked(self, record, fields, context):
        if (type(record) is not dict or set(record) != fields
                or any(record.get(k) != v for k, v in self._common(context, record.get('id')).items())):
            _fail('RECORD_INVALID', '原本机保存记录不是当前本人范围', unknown=True)
        return record

    def _insert(self, db, entity, value):
        value = _seal_record(value)
        db.execute('INSERT INTO records VALUES(?,?,?,?)',
            (entity, value['id'], self._tenant, _encoded(value)))
        return value

    def _replace(self, db, entity, old, value):
        value = _seal_record(value)
        changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=? AND body=?',
            (_encoded(value), entity, old['id'], self._tenant, _encoded(old))).rowcount
        if changed != 1:
            _fail('CONFLICT', '原本机保存记录版本已变化', unknown=True)
        return value

    def _head(self, db, context):
        record = self._row(db, READ_KEYS, self._id(context, 'account_head'))
        if record is None:
            # Normal first/terminal commits always include the head. Its loss
            # beside a known caller journal is corruption, never an idle grant.
            try:
                old = db.execute('SELECT 1 FROM records WHERE entity=? AND tenant_id=? '
                    "AND json_extract(body,'$.caller_digest')=? LIMIT 1",
                    (JOURNALS, self._tenant, context['caller_digest'])).fetchone()
            except Exception:
                _fail('RECORD_INVALID', '原账号保存占用无法核对', unknown=True)
            if old is not None:
                _fail('RECORD_INVALID', '原保存占用槽缺失，请保留原号', unknown=True)
            return None
        self._checked(record, _HEAD, context)
        if (record.get('kind') != 'account_head' or type(record.get('version')) is not int
                or record['version'] < 1 or not _stamp(record.get('updated_at'))
                or (record.get('journal_id') is None) != (record.get('key') is None)
                or record['journal_id'] is not None and
                (not _hex(record['key']) or record['journal_id'] != self._id(context, 'journal', record['key']))):
            _fail('RECORD_INVALID', '原账号未决保存占用需核对', unknown=True)
        return record

    def _journal(self, db, context, key):
        record = self._row(db, JOURNALS, self._id(context, 'journal', key))
        if record is None:
            return None
        self._checked(record, _JOURNAL, context)
        if (record.get('idempotency_key') != key or not _hex(key)
                or type(record.get('read_request_id')) is not str or not _REQUEST.fullmatch(record['read_request_id'])
                or record.get('payload_digest') != _hash([context['account']['id'], record['read_request_id']])
                or type(record.get('version')) is not int
                or not _stamp(record.get('created_at')) or not _stamp(record.get('updated_at'))
                or any(not _hex(record.get(k)) for k in ('preview_digest', 'source_revision',
                    'preview_review_digest', 'storage_review_digest', 'event_confirmation_digest', 'transport_binding_digest'))
                or record.get('state') not in ('reserved', 'succeeded', 'not_committed')
                or record['version'] != (1 if record['state'] == 'reserved' else 2)):
            _fail('RECORD_INVALID', '原保存号、来源或版本无法核对', unknown=True)
        if record['state'] == 'succeeded':
            if record.get('batch_id') != self._batch_id(record['id']):
                _fail('RECORD_INVALID', '原已保存预览批需核对', unknown=True)
            _counts(record.get('counts'))
        elif record.get('batch_id') is not None or record.get('counts') is not None:
            _fail('RECORD_INVALID', '原未决保存不能伪装已落内容', unknown=True)
        reverse = self._row(db, READ_KEYS, self._id(context, 'read', record['read_request_id']))
        self._checked(reverse, _REVERSE, context)
        if (reverse.get('kind') != 'preview_read' or reverse.get('read_request_id') != record['read_request_id']
                or reverse.get('journal_id') != record['id'] or reverse.get('key') != key
                or reverse.get('payload_digest') != record['payload_digest'] or not _stamp(reverse.get('created_at'))):
            _fail('RECORD_INVALID', '原预览与保存号的唯一对应需核对', unknown=True)
        return record

    def _pending(self, db, context):
        head = self._head(db, context)
        if head is None or head['journal_id'] is None:
            return None
        journal = self._journal(db, context, head['key'])
        if journal is None or journal['id'] != head['journal_id'] or journal['state'] != 'reserved':
            _fail('RECORD_INVALID', '原未决保存占用与记录不一致', unknown=True)
        return journal

    def _require_idle(self, context, db=None):
        if db is None:
            with self.core.lock, self._using(context), self.store.connect() as connection:
                pending = self._pending(connection, context)
        else:
            pending = self._pending(db, context)
        if pending is not None:
            _fail('UNKNOWN', '原账号仍有未决本机保存，请只核对原保存号', unknown=True)

    def read_preflight(self, token, account_id):
        self._require_idle(self._caller(token, account_id))

    @contextmanager
    def _account_lock(self, context):
        from core.adapters import account_execution_lock, _account_lock_owner, AdapterBusy
        directory = self.store.directory / 'accounts' / self._tenant / context['account']['id']
        _plain_home(directory, self.store.directory)
        # Reconciliation must not recreate a missing old HOME/lock file. A
        # completed original Wx read has already made this actual lock path.
        if not directory.is_dir() or not (directory / 'platform-command.lock').is_file():
            _fail('UNKNOWN', '原账号物理锁路径待核对，请保留原保存号', unknown=True)
        _plain_config(directory / 'platform-command.lock')
        resolved = directory.resolve()
        if resolved in getattr(_account_lock_owner, 'paths', set()):
            _fail('LOCK_BUSY', '不能借同线程已持有的账号锁做新的保存证明', unknown=True)
        try:
            with account_execution_lock(directory):
                _plain_home(directory, self.store.directory)
                _plain_config(directory / 'platform-command.lock')
                if resolved not in getattr(_account_lock_owner, 'paths', set()):
                    _fail('LOCK_BUSY', '原账号实际互斥未证实', unknown=True)
                yield
        except AdapterBusy:
            _fail('LOCK_BUSY', '原账号操作仍在进行，请只核对原保存号', unknown=True)

    def _safe_items(self, snapshot, context, batch_id):
        result = []
        for position, item in enumerate(snapshot['result']['items']):
            safe = {}
            redacted = False
            for name, maximum in (('text', 3000), ('title', 1000), ('author', 300), ('region', 200), ('published_at', 100)):
                value = item.get(name, '')
                if name == 'published_at' and type(value) is str and re.fullmatch(
                        r'\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})?)?', value):
                    safe[name], changed = value, False
                else:
                    safe[name], changed = _safe_text(value, maximum)
                redacted = redacted or changed
            post_id, _ = _safe_url('wechat_channels', item['url'])
            if post_id != item['post_id'] or item.get('source_type') != 'comment' or not safe['text'].strip():
                _fail('SCOPE', '原展示评论的作品或正文不在本机保存范围')
            result.append({**self._common(context, self._item_id(batch_id, position)),
                'batch_id': batch_id, 'position': position,
                'reported_source_digest': _hash(item['source_uid']), 'original_text_hash': _hash(item['text']),
                **safe, 'privacy_redacted': redacted, 'safe_text_hash': _hash(safe['text'])})
        return result

    def _project(self, db, context, journal):
        batch = self._row(db, BATCHES, journal['batch_id'])
        self._checked(batch, _BATCH, context)
        counts = _counts(journal['counts'])
        ids = [self._item_id(batch['id'], i) for i in range(counts['accepted_count'])]
        if (batch.get('journal_id') != journal['id'] or batch.get('counts') != counts or batch.get('item_ids') != ids
                or not _stamp(batch.get('created_at')) or any(batch.get(k) != journal[k] for k in
                    ('preview_digest', 'event_confirmation_digest', 'transport_binding_digest'))):
            _fail('RECORD_INVALID', '原保存批与成功回执不一致', unknown=True)
        items = []
        for position, ident in enumerate(ids):
            value = self._row(db, ITEMS, ident)
            self._checked(value, _ITEM, context)
            if (value.get('batch_id') != batch['id'] or value.get('position') != position
                    or type(value.get('position')) is not int or type(value.get('privacy_redacted')) is not bool
                    or any(not _hex(value.get(k)) for k in ('reported_source_digest', 'original_text_hash', 'safe_text_hash'))
                    or value.get('safe_text_hash') != _hash(value.get('text'))):
                _fail('RECORD_INVALID', '原安全预览行的来源或内容已变化', unknown=True)
            safe = {}
            for name, maximum in (('text', 3000), ('title', 1000), ('author', 300), ('region', 200), ('published_at', 100)):
                text = value.get(name)
                if name == 'published_at' and type(text) is str and re.fullmatch(
                        r'\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})?)?', text):
                    clean, changed = text, False
                else:
                    clean, changed = _safe_text(text, maximum)
                if changed:
                    _fail('RECORD_INVALID', '原已保存显示内容需核对，不返回自由内容', unknown=True)
                safe[name] = clean
            if not safe['text'].strip():
                _fail('RECORD_INVALID', '原安全预览正文缺失', unknown=True)
            items.append({'item_id': ident, **safe, 'privacy_redacted': value['privacy_redacted']})
        if sum(int(item['privacy_redacted']) for item in items) != counts['privacy_redacted_count']:
            _fail('RECORD_INVALID', '原保存隐私计数不一致', unknown=True)
        return items

    def _view(self, db, context, action, key, journal, *, readonly=True):
        state = 'unknown' if journal is None or journal['state'] == 'reserved' else journal['state']
        counts = None
        if state == 'succeeded':
            self._project(db, context, journal)
            counts = _counts(journal['counts'])
        self._fresh(context)
        return {'contract': CONTRACT, 'action': action, 'account_id': context['account']['id'],
            'idempotency_key': key, 'state': state, 'record_saved': journal is not None,
            'receipt_id': None if journal is None else journal['id'],
            'batch_id': journal['batch_id'] if state == 'succeeded' else None, 'counts': counts,
            'scope': deepcopy(_SCOPE), 'mutation_committed': True if state == 'succeeded'
                else False if state == 'not_committed' else None,
            'replayed': readonly, 'read_only': readonly,
            'platform_requests_started': False, 'AI_started': False, 'auto_retry': False}

    def _summary(self, db, context, journal):
        view = self._view(db, context, STATUS, journal['idempotency_key'], journal)
        return {'receipt_id': view['receipt_id'], 'idempotency_key': view['idempotency_key'],
            'state': view['state'], 'record_saved': True, 'batch_id': view['batch_id'],
            'counts': view['counts'], 'created_at': journal['created_at']}

    def _status(self, context, key):
        with self.core.lock, self.store.connect() as db:
            db.execute('BEGIN')
            return self._view(db, context, STATUS, key, self._journal(db, context, key))

    def _head_clear(self, db, context, journal):
        head = self._head(db, context)
        if (head is None or head['journal_id'] != journal['id'] or head['key'] != journal['idempotency_key']):
            _fail('CONFLICT', '原保存占用已变化，保留原号', unknown=True)
        self._replace(db, READ_KEYS, head, {**head, 'journal_id': None, 'key': None,
            'version': head['version'] + 1, 'updated_at': time.time()})

    def _reserve(self, db, context, data, snapshot, revision):
        self._fresh(context)
        self._require_idle(context, db)
        head = self._head(db, context)
        reverse_id = self._id(context, 'read', data['read_request_id'])
        if self._row(db, READ_KEYS, reverse_id) is not None:
            _fail('CONFLICT', '这一原预览已有保存号，请核对原号', unknown=True)
        stamp = time.time()
        key = data['idempotency_key']
        journal = self._insert(db, JOURNALS, {**self._common(context, self._id(context, 'journal', key)),
            'version': 1, 'state': 'reserved', 'idempotency_key': key, 'read_request_id': data['read_request_id'],
            'payload_digest': _hash([context['account']['id'], data['read_request_id']]),
            **{k: snapshot[k] for k in ('preview_digest', 'source_revision', 'preview_review_digest',
                'event_confirmation_digest', 'transport_binding_digest')}, 'storage_review_digest': revision,
            'batch_id': None, 'counts': None, 'created_at': stamp, 'updated_at': stamp})
        self._insert(db, READ_KEYS, {**self._common(context, reverse_id), 'kind': 'preview_read',
            'read_request_id': data['read_request_id'], 'journal_id': journal['id'], 'key': key,
            'payload_digest': journal['payload_digest'], 'created_at': stamp})
        value = {**self._common(context, self._id(context, 'account_head')), 'kind': 'account_head',
            'version': 1 if head is None else head['version'] + 1, 'journal_id': journal['id'],
            'key': key, 'updated_at': stamp}
        if head is None:
            self._insert(db, READ_KEYS, value)
        else:
            self._replace(db, READ_KEYS, head, value)
        return journal

    def _save(self, context, data):
        key = data['idempotency_key']
        # Existing receipt first, before new version/purpose/preview checks.
        with self.core.lock, self.store.connect() as db:
            prior = self._journal(db, context, key)
            if prior is not None:
                if prior['payload_digest'] != _hash([context['account']['id'], data['read_request_id']]):
                    _fail('CONFLICT', '原保存号已绑定另一预览，不能重放', unknown=True)
                return self._view(db, context, SAVE, key, prior)
            self._require_idle(context, db)
        if type(data['read_request_id']) is not str or not _REQUEST.fullmatch(data['read_request_id']):
            _fail('INPUT', '请保留原视频号预览读取号')
        try:
            revision = self.permit.review()
        except (ValueError, CoreError, OSError, TypeError, KeyError):
            _fail('PERMIT_PENDING', '本机预览保存尚待独立技术审查，本次未预存')
        manager = self.workspace.server.wechat_channels
        if not manager.lock.acquire(blocking=False):
            _fail('LOCK_BUSY', '原本机连接正在读取或收尾')
        reservation_started = False
        try:
            with self._account_lock(context), self.reads._lock, self.core.lock:
                context = self._fresh(context)
                with self.reads.owned_channels_preview_snapshot(context['account']['id'], data['read_request_id'],
                                                             context['user'], self.scope) as snapshot:
                    # Validate safe projection before reserving; no raw source is persisted.
                    ident = self._id(context, 'journal', key)
                    batch_id = self._batch_id(ident)
                    safe_items = self._safe_items(snapshot, context, batch_id)
                    self.permit.current(revision)
                    reservation_started = True
                    with self.store.connect() as db:
                        db.execute('BEGIN IMMEDIATE')
                        # Another window may have committed while metadata was read.
                        prior = self._journal(db, context, key)
                        if prior is not None:
                            if prior['payload_digest'] != _hash([context['account']['id'], data['read_request_id']]):
                                _fail('CONFLICT', '原保存号已绑定另一预览', unknown=True)
                            return self._view(db, context, SAVE, key, prior)
                        journal = self._reserve(db, context, data, snapshot, revision)
                    with self.store.connect() as db:
                        db.execute('BEGIN IMMEDIATE')
                        current = self._journal(db, context, key)
                        if current != journal:
                            _fail('CONFLICT', '原准备记录已变化，不能重新保存', unknown=True)
                        self.permit.current(revision)
                        if self.scope._snapshot(self.reads._operations[data['read_request_id']], context['user'],
                                                context['account'], data['read_request_id']) != snapshot:
                            _fail('SCOPE', '原预览提交前已变化')
                        counts = deepcopy(snapshot['counts'])
                        counts['privacy_redacted_count'] = sum(int(item['privacy_redacted']) for item in safe_items)
                        ids = []
                        for item in safe_items:
                            self._insert(db, ITEMS, item)
                            ids.append(item['id'])
                        self._insert(db, BATCHES, {**self._common(context, batch_id), 'journal_id': ident,
                            **{k: journal[k] for k in ('preview_digest', 'event_confirmation_digest', 'transport_binding_digest')},
                            'counts': counts, 'item_ids': ids, 'created_at': time.time()})
                        terminal = self._replace(db, JOURNALS, journal, {**journal, 'version': 2,
                            'state': 'succeeded', 'batch_id': batch_id, 'counts': counts, 'updated_at': time.time()})
                        self._head_clear(db, context, journal)
                        self.permit.current(revision)
                        self._fresh(context)
                        if self.scope._snapshot(self.reads._operations[data['read_request_id']], context['user'],
                                                context['account'], data['read_request_id']) != snapshot:
                            _fail('SCOPE', '原预览终检变化，本批未保存')
                        result = self._view(db, context, SAVE, key, terminal, readonly=False)
                return result
        except ReceiptArchiveError:
            if reservation_started:
                _fail('UNKNOWN', '原本机保存交付未确认，只核对原号', unknown=True)
            raise
        except Exception:
            _fail('UNKNOWN', '原本机保存或物理收尾待核，只核对原号', unknown=True)
        finally:
            manager.lock.release()

    def _reconcile(self, context, key):
        with self.core.lock, self.store.connect() as db:
            prior = self._journal(db, context, key)
            if prior is None or prior['state'] != 'reserved':
                return self._view(db, context, RECONCILE, key, prior)
        try:
            with self._account_lock(context), self.core.lock, self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                self._fresh(context)
                journal = self._journal(db, context, key)
                if journal is None or journal['state'] != 'reserved':
                    return self._view(db, context, RECONCILE, key, journal)
                pending = self._pending(db, context)
                if pending != journal:
                    _fail('CONFLICT', '原保存号与账号占用不一致', unknown=True)
                batch_id = self._batch_id(journal['id'])
                if self._row(db, BATCHES, batch_id) is not None or any(
                        self._row(db, ITEMS, self._item_id(batch_id, i)) is not None for i in range(20)):
                    _fail('UNKNOWN', '原保存存在物质记录或残片，不能推断未保存', unknown=True)
                # A corrupt batch may have a wrong primary ID but still point
                # to this original journal. No such physical association may
                # be overlooked merely because the deterministic lookup missed.
                if db.execute('SELECT id FROM records WHERE entity=? AND tenant_id=? '
                        'AND (instr(body,?)>0 OR instr(body,?)>0) LIMIT 1',
                        (BATCHES, self._tenant, journal['id'], batch_id)).fetchone() is not None:
                    _fail('UNKNOWN', '原保存批有未核物质关联，保留原号和占用', unknown=True)
                # Also reject an orphan with a malformed deterministic item ID.
                if db.execute('SELECT id FROM records WHERE entity=? AND tenant_id=? AND instr(body,?)>0 LIMIT 1',
                              (ITEMS, self._tenant, batch_id)).fetchone() is not None:
                    _fail('UNKNOWN', '原预览物质关联需核对，保留占用', unknown=True)
                terminal = self._replace(db, JOURNALS, journal, {**journal, 'version': 2,
                    'state': 'not_committed', 'updated_at': time.time()})
                self._head_clear(db, context, journal)
                self._fresh(context)
                result = self._view(db, context, RECONCILE, key, terminal, readonly=False)
            return result
        except ReceiptArchiveError:
            raise
        except Exception:
            _fail('UNKNOWN', '原本机对账提交或收尾未确认，只核对原号', unknown=True)

    def _page(self, context, data):
        if type(data['limit']) is not int or not 1 <= data['limit'] <= 50:
            _fail('INPUT', '本机保存历史每页数量须为1至50')
        cursor = data['cursor']
        if cursor is None:
            cutoff, after = time.time(), ''
        elif (type(cursor) is dict and set(cursor) == {'schema', 'account_id', 'cutoff', 'after'}
                and cursor['schema'] == 'owner_channels_saved_preview_cursor_v1'
                and cursor['account_id'] == context['account']['id'] and _stamp(cursor['cutoff'])
                and _hex(cursor['after'])):
            cutoff, after = cursor['cutoff'], cursor['after']
        else:
            _fail('INPUT', '请使用当前原账号的保存历史分页位置')
        with self.core.lock, self.store.connect() as db:
            db.execute('BEGIN')
            pending = self._pending(db, context)
            pending_summary = None if pending is None else self._summary(db, context, pending)
            candidates = db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? AND id>? '
                'ORDER BY id LIMIT 200', (JOURNALS, self._tenant, after)).fetchall()
            items = []
            scanned = review = 0
            last = after
            for candidate in candidates:
                scanned += 1
                last = candidate['id']
                if not _hex(last):
                    _fail('RECORD_INVALID', '原保存历史分页位置需核对', unknown=True)
                try:
                    value = json.loads(candidate['body'], object_pairs_hook=_duplicates)
                except (ValueError, TypeError):
                    continue
                if type(value) is not dict or any(value.get(k) != v for k, v in self._common(context, last).items()):
                    continue
                if not _stamp(value.get('created_at')):
                    review += 1
                    continue
                if value['created_at'] > cutoff:
                    continue
                try:
                    if not _hex(value.get('idempotency_key')):
                        _fail('RECORD_INVALID', '原保存号需核对', unknown=True)
                    journal = self._journal(db, context, value['idempotency_key'])
                    if journal is None or journal['id'] != last:
                        _fail('RECORD_INVALID', '原保存历史引用需核对', unknown=True)
                    items.append(self._summary(db, context, journal))
                except (CoreError, ValueError, TypeError, KeyError):
                    review += 1
                    continue
                if len(items) == data['limit']:
                    break
            self._fresh(context)
            more = scanned < len(candidates) or len(candidates) == 200
            next_cursor = {'schema': 'owner_channels_saved_preview_cursor_v1', 'account_id': context['account']['id'],
                'cutoff': cutoff, 'after': last} if more else None
            return {'contract': CONTRACT, 'action': PAGE, 'account_id': context['account']['id'],
                'items': items, 'pending_save': pending_summary, 'returned_count': len(items),
                'scanned_count': scanned, 'needs_review_count': review,
                'page': {'has_more': more, 'next_cursor': next_cursor, 'cutoff': cutoff, 'snapshot_verified': False},
                'scope': deepcopy(_SCOPE), 'read_only': True, 'mutation_committed': False,
                'platform_requests_started': False, 'AI_started': False, 'auto_retry': False}

    def _detail(self, context, receipt_id):
        if not _hex(receipt_id):
            _fail('INPUT', '请选择原保存历史记录')
        with self.core.lock, self.store.connect() as db:
            db.execute('BEGIN')
            raw = self._row(db, JOURNALS, receipt_id)
            self._checked(raw, _JOURNAL, context)
            key = raw.get('idempotency_key')
            if not _hex(key) or self._id(context, 'journal', key) != receipt_id:
                _fail('RECORD_INVALID', '原保存历史号不是当前本人范围', unknown=True)
            journal = self._journal(db, context, key)
            state = 'unknown' if journal['state'] == 'reserved' else journal['state']
            items = self._project(db, context, journal) if state == 'succeeded' else []
            counts = _counts(journal['counts']) if state == 'succeeded' else None
            self._fresh(context)
            return {'contract': CONTRACT, 'action': DETAIL, 'account_id': context['account']['id'],
                'receipt_id': receipt_id, 'idempotency_key': key, 'state': state, 'counts': counts,
                'items': items, 'scope': deepcopy(_SCOPE), 'read_only': True, 'mutation_committed': False,
                'platform_requests_started': False, 'AI_started': False, 'auto_retry': False}

    def execute(self, token, action, data):
        expected = ({'account_id', 'read_request_id', 'idempotency_key'} if action == SAVE else
            {'account_id', 'idempotency_key'} if action in (STATUS, RECONCILE) else
            {'account_id', 'limit', 'cursor'} if action == PAGE else {'account_id', 'receipt_id'})
        if type(action) is not str or action not in ACTIONS or type(data) is not dict or set(data) != expected:
            _fail('INPUT', '本人预览保存仅接受固定原号或历史参数')
        context = self._caller(token, data['account_id'])
        with self._using(context):
            if action == PAGE:
                return self._page(context, data)
            if action == DETAIL:
                return self._detail(context, data['receipt_id'])
            key = data['idempotency_key']
            if not _hex(key):
                # Do not turn an existing account reservation into a fresh
                # discardable rejection merely through malformed new input.
                with self.core.lock, self.store.connect() as db:
                    self._require_idle(context, db)
                _fail('INPUT', '请保留原本机预览保存号')
            if action == STATUS:
                return self._status(context, key)
            if action == RECONCILE:
                return self._reconcile(context, key)
            return self._save(context, data)


