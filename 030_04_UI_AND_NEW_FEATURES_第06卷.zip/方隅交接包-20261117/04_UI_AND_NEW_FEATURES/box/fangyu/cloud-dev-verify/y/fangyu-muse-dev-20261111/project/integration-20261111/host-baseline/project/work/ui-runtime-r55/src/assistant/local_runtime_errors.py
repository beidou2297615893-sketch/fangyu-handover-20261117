"""Fixed local runtime failures; never contain platform responses or credentials."""

from core.page_errors import CoreError


class LocalPlatformRuntimeError(CoreError):
    """A packaging or adapter failure before a platform request can start."""

    MESSAGES = {
        'cli_runtime_invalid': '本机组件不完整，请更新工作台后重试；无需重新扫码',
        'cli_adapter_invalid': '本机组件配置未通过检查，请更新工作台后重试；无需重新扫码',
    }

    def __init__(self, code):
        self.code = code if type(code) is str and code in self.MESSAGES else 'cli_runtime_invalid'
        super().__init__(self.MESSAGES[self.code])
