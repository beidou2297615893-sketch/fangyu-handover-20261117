"""Explicit task resume after one verified same-account browser handoff."""
import hashlib
import json
import math
import re
import time
from pathlib import Path
from .xhs_page_process import plain, fingerprint
from assistant.browser_session_commit import account_revision
from assistant.xhs_cli_page_worker import LIMIT, digest as result_digest


def _unique(pairs):
    value={}
    for key,item in pairs:
        if key in value:raise ValueError('duplicate key')
        value[key]=item
    return value


def _failed_error(value):
    if (type(value) is not dict or value.get('state') not in ('received','acknowledged')
            or type(value.get('version')) is not int or value['version'] != 1
            or type(value.get('wire_allow_attempts')) is not int or value['wire_allow_attempts'] < 1
            or value.get('operation') not in ('search','comments','sub-comments','user-posts','notifications')):
        return None
    result=value.get('result')
    if (type(result) is not dict or set(result)!={'stdout','stderr','returncode'}
            or type(result.get('returncode')) is not int or result['returncode']!=1
            or type(result.get('stdout')) is not str or type(result.get('stderr')) is not str
            or result_digest(result)!=value.get('digest')):
        return None
    try:payload=json.loads(result['stdout'],object_pairs_hook=_unique)
    except (ValueError,TypeError):return None
    if (type(payload) is not dict or set(payload)!={'ok','schema_version','error'}
            or payload.get('ok') is not False or payload.get('schema_version')!='1'):return None
    error=payload.get('error')
    return error if type(error) is dict and set(error)=={'code','message'} and type(error.get('message')) is str and len(error['message'])<=512 else None


def captcha_receipt(value):
    error=_failed_error(value)
    return bool(error and error.get('code')=='verification_required' and re.fullmatch(
        r'Captcha required: type=[1-9][0-9]{0,5}, uuid=[A-Za-z0-9_-]{8,160}',error['message']))


def verification_receipt(value):
    """Only completed native CAPTCHA or explicit expired-login failures."""
    error=_failed_error(value)
    return bool(captcha_receipt(value) or error and error.get('code')=='not_authenticated'
        and error['message']=='Session expired — please re-login with: xhs login')


def receipt_folder(directory,task_id,partition=None):
    folder=plain(Path(directory)/'.workbench-page-receipts'/task_id)
    if partition is not None:
        if not isinstance(partition,str) or not re.fullmatch(r'source-scan-[1-9][0-9]{0,6}',partition):
            raise ValueError('Exact original source scan required')
        folder=plain(folder/partition)
    return folder


def failed_page(directory,task_id,scope,*,partition=None):
    """Select exactly one explicit original CAPTCHA or expired-login receipt; never infer unknowns."""
    if (not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',str(task_id))
            or not re.fullmatch(r'[a-f0-9]{64}',str(scope))):return None
    folder=receipt_folder(directory,task_id,partition)
    if not folder.is_dir():return None
    found=[]
    for path in folder.glob('*.json'):
        if not re.fullmatch(r'[a-f0-9]{64}\.json',path.name):continue
        source=plain(path).read_bytes()
        if len(source)>LIMIT+65536:return None
        value=json.loads(source,object_pairs_hook=_unique)
        # A newly completed human verification may authorize one attempt for
        # this new, known CAPTCHA receipt, including a prior verified attempt.
        # Its exact bytes and a fresh commit still gate each retry; unknowns
        # never qualify and one proof cannot authorize two wire attempts.
        if not verification_receipt(value):continue
        received=value.get('received_at')
        if (value.get('task')!=task_id or value.get('scope')!=scope or value.get('page')!=path.stem
                or not re.fullmatch(r'[a-f0-9]{64}',str(value.get('args_digest')))
                or type(received) not in (int,float) or not math.isfinite(received)
                or not 0<received<=time.time()):return None
        found.append({'task':task_id,'scope':scope,'page':path.stem,
            'args_digest':value['args_digest'],'receipt_sha256':hashlib.sha256(source).hexdigest()})
    return found[0] if len(found)==1 else None


def verified_pages(directory,task_id,scope,account,*,partition=None):
    """Use the server's committed same-UID proof, independent of old activity."""
    if account.get('status')!='ready':return {}
    try:
        proof=account.get('browser_verification_receipt')
        if (type(proof) is not dict or type(proof.get('version')) is not int or proof['version']!=1
                or proof.get('account_id')!=account.get('id') or proof.get('tenant_id')!=account.get('tenant_id')
                or not account.get('platform_uid') or account.get('platform')!='xiaohongshu'
                or proof.get('uid_sha256')!=hashlib.sha256(account['platform_uid'].encode()).hexdigest()
                or not re.fullmatch(r'[a-f0-9]{32}',str(proof.get('auth_generation')))
                or proof['auth_generation']!=account.get('auth_generation')
                or type(proof.get('at')) not in (int,float) or not math.isfinite(proof['at'])
                or not 0<=time.time()-proof['at']<=600
                or (Path(directory)/'.xiaohongshu-cli/.browser-session-commit.json').exists()):return {}
        cookie=fingerprint(directory)
        if not cookie or cookie!=proof.get('credential_sha256'):return {}
        context=failed_page(directory,task_id,scope,partition=partition)
        if not context or any(proof.get(k)!=v for k,v in context.items()):return {}
        value=json.loads(plain(receipt_folder(directory,task_id,partition)/(context['page']+'.json')).read_bytes(),object_pairs_hook=_unique)
        if value['received_at']>proof['at']:return {}
        return {context['page']:{**context,'generation':proof['auth_generation'],
            'credential_sha256':cookie,'account_revision':account_revision(account),
            'expires_at':min(time.time()+60,proof['at']+600)}}
    except (OSError,ValueError,TypeError,KeyError):return {}
