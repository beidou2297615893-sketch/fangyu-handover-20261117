"""Existing company actor: prepare, one durable order link, same-key recovery.

No customer getter, customer creation, owner staff grant or platform operation.
GET is read-only for the company ledger; it can reconcile this local journal.
"""
from copy import deepcopy
import hashlib
import json
import re
import sqlite3

from .company_handoff_receiver import CompanyHandoffReceiver, CompanyHandoffReceiverError, _fail, _hash, _json, _int
from .company_handoff_receiver_transport import CompanyHandoffReceiverTransport

PREPARE='company_handoff_order_link_prepare'
COMMIT='company_handoff_order_link'
GET='company_handoff_order_link_get'
ACTIONS=frozenset((PREPARE,COMMIT,GET))
CLOUD_PREPARE='acquisition_owner_order_link_prepare'
CLOUD_COMMIT='acquisition_handoff_order_link'
CLOUD_GET='acquisition_handoff_operation_status'
CAP={'contract':'owner_company_order_link_v1','available':True,'owner_package_only':True,
     'company_staff_only':True,'read_only_prepare':True,'financial_receipt_verified':False,
     'cooperation_policy_verified':False,'auto_retry':False}
CHANNEL=re.compile(r'hc_[a-f0-9]{64}\Z')
HEX=re.compile(r'[a-f0-9]{64}\Z')
ORDER=re.compile(r'[A-Za-z0-9_.-]{1,120}\Z')
CUSTOMER=re.compile(r'cu_[a-f0-9]{64}\Z')
REF=re.compile(r'(?:evidence|document):[a-f0-9]{32}\Z')
ENTITY='owner_company_order_link_journal_v1'
HEADS='owner_company_order_link_heads_v1'
CUSTODY='owner_company_order_link_custody_v1'
REQUEST=frozenset(('channel_id','order_no','customer_id','binding_evidence_reference','evidence_reference'))
VERSIONS=frozenset(('expected_revision','expected_business_revision','order_revision'))
JOURNAL=frozenset(('schema','id','tenant_id','company_id','environment_id','device_id','actor_id',
 'actor_scope','channel_id','order_no','sequence','idempotency_key','payload_hash','request','state',
 'created_at','updated_at','record_hash'))
PREPARATION=frozenset(('contract','action','channel_id','claim_id','package_id','row_id','order_no',
 'company_customer_binding_hash','binding_evidence_reference','evidence_reference','expected_revision',
 'expected_business_revision','order_revision','read_only','mutation_committed','auto_retry',
 'association_independently_verified'))
PROOF=frozenset(('contract','state','operation_action','idempotency_key','payload_hash','channel_id','order_no',
 'claim_id','revision','original_event_hash','reason_code','read_only','mutation_committed','auto_retry','current_handoff'))

def matched(value,pattern):
    return type(value) is str and bool(pattern.fullmatch(value))

def exact(value,fields):
    if type(value) is not dict or set(value)!=fields:
        _fail('INVALID_BUSINESS_RECEIPT','公司原业务字段需核对')

def plain_request(data):
    return (all(matched(data.get(k),p) for k,p in (('channel_id',CHANNEL),('order_no',ORDER),
        ('customer_id',CUSTOMER),('binding_evidence_reference',REF),('evidence_reference',REF))))

def seal(value):
    value={k:deepcopy(v) for k,v in value.items() if k!='record_hash'}
    return dict(value,record_hash=_hash(value))

class CompanyOwnerOrderTransport(CompanyHandoffReceiverTransport):
    """Same original session capture/fence; only three fixed business operations."""
    def __call__(self,actor,operation,data):
        if operation==CLOUD_PREPARE:
            valid=type(data) is dict and set(data)==REQUEST and plain_request(data)
        elif operation==CLOUD_COMMIT:
            valid=(type(data) is dict and set(data)==REQUEST|VERSIONS|{'idempotency_key'}
                and plain_request(data) and matched(data['idempotency_key'],HEX)
                and all(_int(data[k],0 if k=='expected_business_revision' else 1) for k in VERSIONS))
        elif operation==CLOUD_GET:
            valid=(type(data) is dict and set(data)=={'operation_action','idempotency_key'}
                and data['operation_action']==CLOUD_COMMIT and matched(data['idempotency_key'],HEX))
        else:
            return super().__call__(actor,operation,data)
        if not valid:
            _fail('INVALID_BUSINESS_REQUEST','公司业务仅接受明确原记录和版本',400)
        writing=operation==CLOUD_COMMIT
        before=self._receiver_capture(actor,60)
        from integrations import request_json
        try:
            wire_data=deepcopy(data)
            if operation==CLOUD_GET:
                wire_data['origin_kind']='owner_package_v1'
            result=request_json(before['endpoint'],dict(environment_id=self.environment_id,
                operation=operation,**wire_data),before['token'])
        except Exception:
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE',
                '公司原业务结果尚需核对，请保留原号',mutation=None if writing else False)
        after=self._receiver_capture(actor,0,dispatched=writing)
        if before!=after:
            _fail('BINDING_CHANGED','返回时原公司连接已变化',mutation=None if writing else False)
        outer={'contract','environment_id','company_id'}
        fields=({'preparation'} if operation==CLOUD_PREPARE else {'business_operation','replayed'} if writing else {'operation_receipt'})|{'read_only','mutation_committed','auto_retry'}
        if (type(result) is not dict or set(result)!=outer|fields or result.get('contract')!='fangyu-workspace-v1'
            or result.get('environment_id')!=self.environment_id or result.get('company_id')!=self.company_id
            or result.get('auto_retry') is not False or type(result.get('read_only')) is not bool
            or type(result.get('mutation_committed')) is not bool
            or not writing and (result['read_only'] is not True or result['mutation_committed'] is not False)):
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE','原公司业务回执格式需核对',mutation=None if writing else False)
        if self._receiver_capture(actor,0,dispatched=writing)!=before:
            _fail('BINDING_CHANGED','返回时原公司范围已变化',mutation=None if writing else False)
        return {k:deepcopy(v) for k,v in result.items() if k not in outer}

class CompanyOwnerOrderLink:
    def __init__(self,receiver):
        if type(receiver) is not CompanyHandoffReceiver:
            _fail('BUSINESS_SCOPE_REQUIRED','仅正规公司接收服务可以创建业务桥',403)
        self.receiver=receiver
        self.core=receiver.core

    def _identity(self,snapshot,channel,order=None):
        r=self.receiver
        return _hash(['owner-company-order-v1',r.tenant,r.company_id,r.environment_id,r.device_id,
                      snapshot['actor']['id'],snapshot['scope'],channel,order])

    def _key(self,base,sequence):
        return _hash(['owner-company-order-attempt-v1',base,sequence])

    def _saved(self,db,entity,identifier,snapshot):
        raw=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                       (entity,identifier,self.receiver.tenant)).fetchone()
        if raw is None:return None
        try:value=json.loads(raw[0])
        except Exception:_fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务日志无法解析')
        if (type(value) is not dict or value.get('record_hash')!=_hash({k:v for k,v in value.items() if k!='record_hash'})
            or value.get('tenant_id')!=self.receiver.tenant or value.get('actor_scope')!=snapshot['scope']):
            _fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务日志主体需核对')
        return value

    def _journal(self,db,key,snapshot):
        row=self._saved(db,ENTITY,key,snapshot)
        if row is None:return None
        exact(row,JOURNAL)
        r=self.receiver
        if (row['schema']!=ENTITY or row['id']!=key or row['idempotency_key']!=key
            or row['company_id']!=r.company_id or row['environment_id']!=r.environment_id
            or row['device_id']!=r.device_id or row['actor_id']!=snapshot['actor']['id']
            or not _int(row['sequence'],1) or row['state'] not in ('unknown','recorded','rejected')
            or type(row['request']) is not dict or set(row['request'])!=REQUEST|VERSIONS|{'idempotency_key'}
            or row['request']['idempotency_key']!=key or row['request']['channel_id']!=row['channel_id']
            or row['request']['order_no']!=row['order_no'] or not plain_request(row['request'])
            or row['payload_hash']!=_hash(dict(environment_id=r.environment_id,operation=CLOUD_COMMIT,**row['request']))
            or key!=self._key(self._identity(snapshot,row['channel_id'],row['order_no']),row['sequence'])):
            _fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务日志版本或请求需核对')
        return row

    def _put(self,db,entity,identifier,value):
        row=seal(value)
        prior=db.execute('SELECT tenant_id FROM records WHERE entity=? AND id=?',(entity,identifier)).fetchone()
        if prior is None:
            db.execute('INSERT INTO records VALUES(?,?,?,?)',(entity,identifier,self.receiver.tenant,_json(row)))
        else:
            if prior[0]!=self.receiver.tenant:_fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务日志跨企业冲突')
            changed=db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (_json(row),entity,identifier,self.receiver.tenant))
            if changed.rowcount!=1:_fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务日志范围已变化')
        return row

    def _sequence(self,db,snapshot,channel,order):
        base=self._identity(snapshot,channel,order)
        head=self._saved(db,HEADS,base,snapshot)
        if head is None:return base,1
        if set(head)!={'tenant_id','actor_scope','sequence','key','record_hash'} or not _int(head['sequence'],1):
            _fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务尝试头需核对')
        row=self._journal(db,head['key'],snapshot)
        if row is None or row['sequence']!=head['sequence'] or row['channel_id']!=channel or row['order_no']!=order:
            _fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务尝试链需核对')
        if row['state']!='rejected':
            _fail('ATTEMPT_EXISTS','该订单已有原尝试，请只核对原号；未知不重试',mutation=None if row['state']=='unknown' else False)
        return base,row['sequence']+1

    def _custody(self,db,snapshot,channel):
        custody=self._saved(db,CUSTODY,self._identity(snapshot,channel),snapshot)
        if custody:
            if set(custody)!={'tenant_id','actor_scope','key','channel_id','record_hash'} or custody['channel_id']!=channel:
                _fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原行业务保管号需核对')
            row=self._journal(db,custody['key'],snapshot)
            if row is None:_fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原行业务日志缺失')
            if row['state']=='unknown':_fail('ATTEMPT_EXISTS','原行还有未知业务尝试，请保留原号核对',mutation=None)

    def _proof(self,raw,row):
        if raw is None:return None,None
        exact(raw,PROOF)
        if (raw['contract']!='owner_company_order_link_operation_v1' or raw['state'] not in ('recorded','rejected')
            or raw['operation_action']!=CLOUD_COMMIT or raw['idempotency_key']!=row['idempotency_key']
            or raw['payload_hash']!=row['payload_hash'] or raw['channel_id']!=row['channel_id']
            or raw['order_no']!=row['order_no'] or raw['read_only'] is not True
            or raw['mutation_committed'] is not False or raw['auto_retry'] is not False):
            _fail('INVALID_BUSINESS_RECEIPT','原业务回执没有绑定原请求')
        item=self.receiver._item(raw['current_handoff'],row['channel_id'])
        if item.get('origin_kind')!='owner_package_v1' or item['claim_id']!=raw['claim_id']:
            _fail('INVALID_BUSINESS_RECEIPT','原业务资料行需要核对')
        expected=row['request']['expected_revision']
        if raw['state']=='recorded':
            valid=(raw['revision']==expected+1 and matched(raw['original_event_hash'],HEX)
                   and raw['reason_code'] is None and item['revision']>=raw['revision'])
        else:
            valid=(raw['revision']==expected and raw['original_event_hash'] is None
                   and type(raw['reason_code']) is str and item['revision']>=expected)
        if not valid:_fail('INVALID_BUSINESS_RECEIPT','原业务版本或确定拒绝证明需核对')
        return deepcopy(raw),item

    def _result(self,action,channel,order,key,proof=None,item=None,committed=False):
        state=proof['state'] if proof else 'unknown'
        return dict(contract='owner_company_order_link_v1',action=action,channel_id=channel,order_no=order,
            idempotency_key=key,state=state,item=deepcopy(item),original_operation={
                'payload_hash':proof['payload_hash'],'channel_id':proof['channel_id'],
                'revision':proof['revision'],'original_event_hash':proof['original_event_hash']} if proof else None,
            read_only=not committed,mutation_committed=committed,auto_retry=False,company_reported_only=True,
            financial_receipt_verified=False,cooperation_policy_verified=False,
            verified_cash_cents=None,verified_paid_commission_cents=None)

    def _confirm(self,row,proof,snapshot,user):
        self.receiver._fence(snapshot,user)
        with self.core.lock,self.core.store.connect() as db:
            db.execute('PRAGMA busy_timeout=0');db.execute('BEGIN IMMEDIATE')
            current=self._journal(db,row['idempotency_key'],snapshot)
            if current is None or current['payload_hash']!=row['payload_hash']:_fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务日志已变化')
            if current['state'] not in ('unknown',proof['state']):_fail('BUSINESS_JOURNAL_NEEDS_REVIEW','原业务终态不允许变化')
            current['state']=proof['state'];current['updated_at']=int(self.receiver.clock())
            self._put(db,ENTITY,current['id'],current)
            self.receiver._fence(snapshot,user);db.commit()

    def execute(self,action,data,user):
        if action not in ACTIONS or type(data) is not dict:_fail('INVALID_BUSINESS_REQUEST','不支持该公司业务操作',400)
        r=self.receiver;snapshot=r._snapshot(user)
        if action==PREPARE:
            exact(data,REQUEST)
            if not plain_request(data):_fail('INVALID_BUSINESS_REQUEST','请填公司既存记录编号和受限证据参考',400)
            with self.core.lock,self.core.store.connect() as db:
                self._custody(db,snapshot,data['channel_id']);base,sequence=self._sequence(db,snapshot,data['channel_id'],data['order_no'])
            answer=r._read(snapshot,user,CLOUD_PREPARE,data)
            exact(answer,{'preparation','read_only','mutation_committed','auto_retry'})
            prepared=answer['preparation'];exact(prepared,PREPARATION)
            if (prepared['contract']!='owner_company_order_link_preparation_v1' or prepared['action']!=PREPARE
                or any(prepared[k]!=data[k] for k in ('channel_id','order_no','binding_evidence_reference','evidence_reference'))
                or not matched(prepared['company_customer_binding_hash'],HEX) or not all(_int(prepared[k],0 if k=='expected_business_revision' else 1) for k in VERSIONS)
                or any(prepared[k] is not v for k,v in {'read_only':True,'mutation_committed':False,'auto_retry':False,'association_independently_verified':False}.items())
                or answer['read_only'] is not True or answer['mutation_committed'] is not False or answer['auto_retry'] is not False):
                _fail('INVALID_BUSINESS_RECEIPT','实际公司版本未通过核对')
            r._fence(snapshot,user)
            return dict(deepcopy(prepared),idempotency_key=self._key(base,sequence))
        expected={'channel_id','order_no','idempotency_key'} if action==GET else REQUEST|VERSIONS|{'idempotency_key'}
        exact(data,expected)
        if not matched(data['channel_id'],CHANNEL) or not matched(data['order_no'],ORDER) or not matched(data['idempotency_key'],HEX):
            _fail('INVALID_BUSINESS_REQUEST','请使用公司原行、原订单与原号',400)
        with self.core.lock,self.core.store.connect() as db:
            row=self._journal(db,data['idempotency_key'],snapshot)
        if action==GET:
            if row is None:return self._result(GET,data['channel_id'],data['order_no'],data['idempotency_key'])
            if row['channel_id']!=data['channel_id'] or row['order_no']!=data['order_no']:_fail('BINDING_CHANGED','原业务号不属于当前原行')
            answer=r._read(snapshot,user,CLOUD_GET,{'operation_action':CLOUD_COMMIT,'idempotency_key':row['idempotency_key']})
            exact(answer,{'operation_receipt','read_only','mutation_committed','auto_retry'})
            if answer['read_only'] is not True or answer['mutation_committed'] is not False or answer['auto_retry'] is not False:_fail('INVALID_BUSINESS_RECEIPT','原号读取边界需核对')
            proof,item=self._proof(answer['operation_receipt'],row)
            if proof:self._confirm(row,proof,snapshot,user)
            r._fence(snapshot,user)
            return self._result(GET,row['channel_id'],row['order_no'],row['idempotency_key'],proof,item)
        if not plain_request(data) or not all(_int(data[k],0 if k=='expected_business_revision' else 1) for k in VERSIONS):
            _fail('INVALID_BUSINESS_REQUEST','提交只接受已核对记录与版本',400)
        if row:
            if row['request']!=data:_fail('ATTEMPT_EXISTS','原业务号已绑定原请求，不可修改或重发')
            return self.execute(GET,{k:data[k] for k in ('channel_id','order_no','idempotency_key')},user)
        started=False
        try:
            with self.core.lock,self.core.store.connect() as db:
                db.execute('PRAGMA busy_timeout=0');db.execute('BEGIN IMMEDIATE')
                r._fence(snapshot,user);self._custody(db,snapshot,data['channel_id'])
                base,sequence=self._sequence(db,snapshot,data['channel_id'],data['order_no'])
                if data['idempotency_key']!=self._key(base,sequence):_fail('BINDING_CHANGED','请使用当前原准备返回的固定业务号')
                stamp=int(r.clock())
                row=dict(schema=ENTITY,id=data['idempotency_key'],tenant_id=r.tenant,company_id=r.company_id,
                    environment_id=r.environment_id,device_id=r.device_id,actor_id=snapshot['actor']['id'],
                    actor_scope=snapshot['scope'],channel_id=data['channel_id'],order_no=data['order_no'],sequence=sequence,
                    idempotency_key=data['idempotency_key'],payload_hash=_hash(dict(environment_id=r.environment_id,operation=CLOUD_COMMIT,**data)),
                    request=deepcopy(data),state='unknown',created_at=stamp,updated_at=stamp)
                self._put(db,ENTITY,row['id'],row)
                self._put(db,HEADS,base,dict(tenant_id=r.tenant,actor_scope=snapshot['scope'],sequence=sequence,key=row['id']))
                self._put(db,CUSTODY,self._identity(snapshot,data['channel_id']),dict(tenant_id=r.tenant,actor_scope=snapshot['scope'],key=row['id'],channel_id=data['channel_id']))
                r._fence(snapshot,user);started=True;db.commit()
        except Exception as error:
            if isinstance(error,CompanyHandoffReceiverError):raise
            _fail('RESULT_UNKNOWN' if started else 'BUSINESS_PREPARATION_UNAVAILABLE','本机原业务号尚需核对；未自动重发',mutation=None if started else False)
        try:
            r._fence(snapshot,user)
            answer=r.cloud_receipt(deepcopy(snapshot['actor']),CLOUD_COMMIT,deepcopy(data))
            r._fence(snapshot,user)
            exact(answer,{'business_operation','replayed','read_only','mutation_committed','auto_retry'})
            if type(answer['replayed']) is not bool or answer['auto_retry'] is not False:_fail('INVALID_BUSINESS_RECEIPT','公司原写结果需核对')
            proof,item=self._proof(answer['business_operation'],row)
            if proof is None:_fail('RESULT_UNKNOWN','公司原业务尚无确定回执',mutation=None)
            committed=proof['state']=='recorded' and answer['replayed'] is False
            if (answer['read_only'] is not (not committed) or answer['mutation_committed'] is not committed):
                _fail('INVALID_BUSINESS_RECEIPT','公司原写结果边界需核对')
            self._confirm(row,proof,snapshot,user)
            return self._result(COMMIT,row['channel_id'],row['order_no'],row['idempotency_key'],proof,item,committed)
        except Exception:
            _fail('RESULT_UNKNOWN','公司原业务结果未确认，请保留原号只读核对',mutation=None)
