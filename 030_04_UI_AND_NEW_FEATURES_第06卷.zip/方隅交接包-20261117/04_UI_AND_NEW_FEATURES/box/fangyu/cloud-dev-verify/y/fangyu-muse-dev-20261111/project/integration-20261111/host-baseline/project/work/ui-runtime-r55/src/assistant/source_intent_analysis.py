"""Explicit taskless AI for exact locally archived sources; no platform grant."""
from copy import deepcopy
import json
import re

from core import CoreError
from core.service_plans import require_feature
from .ai_workflow import digest, timestamp, model_metadata
from .platform_receipt_archive import SOURCES, BATCHES, RECEIPTS, _hash
from .product_receipts import ProductOperationReceipts
from .xhs_app_context import _DeviceSession

ACTIONS=frozenset({'source_intent_analyze_selected','source_intent_analysis_status'})
ACTION='source_intent_analyze_selected'
ENTITY='source_intent_analysis_operations'
PLATFORMS=frozenset({'xiaohongshu','douyin','wechat_channels'})
_SEAL=object()
_ID=re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}\Z')
_ACTOR=('id','tenant_id','username','role','cloud_bound','disabled','development_local_only','permission_revision')
_SOURCE_FIELDS=('platform','source_id','source_type','note_url','url','comment_id','author_id','target_comment_id','target_author_id')
_ACCOUNT_FIELDS=('id','tenant_id','cloud_owner','platform','platform_uid','conn_id','status','revision','updated_at')
_ARCHIVE_COUNTS=frozenset({'inserted','duplicate_count','accepted_count','privacy_redacted_count'})
_ARCHIVE_FALSE=frozenset({'reply_allowed','reply_target_verified','customer_identity_verified','auto_retry','platform_requests_started','cross_machine_verified','resource_receipt_verified','real_platform_verified'})

def _archive_result_valid(raw):
    return (isinstance(raw,dict) and set(raw)==_ARCHIVE_COUNTS|_ARCHIVE_FALSE|{'lead_ids','local_only','storage_scope'}
        and all(type(raw.get(key)) is int and 0<=raw[key]<=100 for key in _ARCHIVE_COUNTS)
        and 1<=raw['accepted_count']<=100 and raw['inserted']+raw['duplicate_count']==raw['accepted_count']
        and raw['privacy_redacted_count']<=raw['accepted_count'] and all(raw.get(key) is False for key in _ARCHIVE_FALSE)
        and raw.get('local_only') is True and raw.get('storage_scope')=='this_device'
        and isinstance(raw.get('lead_ids'),list) and len(raw['lead_ids'])==raw['accepted_count']
        and all(isinstance(value,str) and _ID.fullmatch(value) for value in raw['lead_ids'])
        and len(set(raw['lead_ids']))==len(raw['lead_ids']))

class SourceIntentError(CoreError):
    def __init__(self,message,*,mutation_committed=False):
        super().__init__(message)
        self.mutation_committed=mutation_committed

def _row(db,entity,ident,tenant):
    found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,ident,tenant)).fetchone()
    return json.loads(found['body']) if found else None

def _rows(db,entity,tenant):
    return [json.loads(item['body']) for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(entity,tenant)).fetchall()]

def _put(db,entity,row):
    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))

class _SourceIntentHost:
    def __init__(self,server,executor,user):
        from .business import BusinessExecutor
        from .service import AssistantService
        service=server.assistant_service
        session=getattr(executor,'_xhs_app_session',None)
        if (type(executor) is not BusinessExecutor or type(service) is not AssistantService
                or type(session) is not _DeviceSession or session.service is not service
                or session.executor is not executor or executor.server is not server
                or session.core is not server.core):
            raise SourceIntentError('原员工与电脑会话尚未核对，请重新连接当前公司')
        self.server,self.executor,self.service,self.session=server,executor,service,session
        self.core=server.core;self.user=deepcopy(user)
        self.actor=digest({key:user.get(key) for key in _ACTOR})
        self.device_id=(service.device or {}).get('id')
        self.check(user,feature=False)

    def check(self,user,*,feature=True,db=None):
        self.session.check()
        current=_row(db,'users',self.user['id'],self.executor.tenant) if db is not None else self.core.store.get('users',self.user['id'])
        if (not current or current.get('disabled') or current.get('cloud_bound') is not True
                or current.get('development_local_only') is True or current.get('role') not in ('operator','admin')
                or digest({key:current.get(key) for key in _ACTOR})!=self.actor
                or digest({key:user.get(key) for key in _ACTOR})!=self.actor
                or (current.get('id'),current.get('tenant_id'),current.get('username'))!=
                    (self.executor.user_id,self.executor.tenant,self.executor.owner)
                or self.service.stop_event.is_set() or self.service.closed
                or (self.service.device or {}).get('id')!=self.device_id):
            raise SourceIntentError('原员工或电脑范围已变化，请保留原编号核对')
        if feature:require_feature(self.server.company,'intent_analysis')
        return current

def _owner_host(host):
    from .self_operating_source_intent import _OwnerSourceIntentHost
    return type(host) is _OwnerSourceIntentHost

def _binding_host(host):
    return type(host) is _SourceIntentHost or _owner_host(host)

class _ArchivedSourceBinding:
    """Factory-sealed source scope; an HTTP dict cannot substitute for it."""
    def __init__(self,seal,host,ids,city,area):
        if seal is not _SEAL or not _binding_host(host):
            raise SourceIntentError('归档来源范围无法核对')
        self.seal,self.host,self.ids,self.city,self.area=seal,host,tuple(ids),city,area
        self.snapshot=None;self.operation_id=None;self.dispatched=False
        with host.core.lock,host.core.store.connect() as db:
            self.snapshot=self._load(host.user,db)
        self.leads=deepcopy(self.snapshot['leads'])
        self.context_digest=digest(self.snapshot)

    def _load(self,user,db):
        host=self.host;current=host.check(user,db=db);tenant=host.executor.tenant
        leads=[];sources=[];accounts=[]
        for ident in self.ids:
            lead=_row(db,'leads',ident,tenant)
            if not lead:raise SourceIntentError('所选原评论不存在或不属于当前员工')
            host.executor._lead_access(current,lead)
            if (lead.get('cloud_owner')!=host.executor.owner or lead.get('task_id')
                    or lead.get('demo') or lead.get('source_type')!='comment'
                    or lead.get('platform') not in PLATFORMS or lead.get('readonly_archive') is not True
                    or lead.get('can_reply') is not False or lead.get('reply_target_status')!='not_verified'
                    or any(lead.get(key) not in (None,'') for key in ('comment_id','author_id','target_comment_id','target_author_id'))
                    or lead.get('privacy_redacted') is not False or lead.get('analysis_status')=='privacy_review_required'
                    or lead.get('manual_intent') or lead.get('ai_intent')
                    or not isinstance(lead.get('text'),str) or not lead['text'].strip() or len(lead['text'])>3000
                    or not isinstance(lead.get('title'),str) or not lead['title'].strip() or len(lead['title'])>500
                    or not isinstance(lead.get('source_uid'),str)):
                raise SourceIntentError('所选评论需补上下文、核对来源或已处理，未开始新的分析')
            source=_row(db,SOURCES,_hash([tenant,lead['source_uid']]),tenant)
            if (not source or source.get('lead_id')!=ident or source.get('cloud_owner')!=host.executor.owner
                    or source.get('source_uid')!=lead['source_uid'] or source.get('platform')!=lead['platform']
                    or source.get('device_id')!=host.device_id or source.get('actor_id')!=current['id']
                    or source.get('actor_role')!=current['role'] or source.get('privacy_redacted') is not False
                    or source.get('lead_text_hash')!=_hash(lead['text']) or source.get('safe_text_hash')!=_hash(lead['text'])
                    or source.get('original_text_hash')!=_hash(lead['text'])
                    or source.get('lead_source_digest')!=_hash({key:lead.get(key) for key in _SOURCE_FIELDS})
                    or source.get('real_platform_verified') is not False or source.get('reply_target_verified') is not False
                    or source.get('evidence_level')!='transport_reported' or not source.get('account_uid')
                    or str(source['account_uid']).casefold() in ('0','unknown','null','none','-')
                    or any(not isinstance(source.get(key),str) or not re.fullmatch('[0-9a-f]{64}',source[key])
                           for key in ('account_binding_digest','connection_digest','license_digest','input_digest'))):
                raise SourceIntentError('原归档证据与当前评论不一致，未开始新的分析')
            from core.platform_reads import source_reference,_digest
            post_id,_=source_reference(lead['platform'],lead.get('note_url') or lead.get('url'))
            if (post_id!=source.get('post_id') or not isinstance(source.get('comment_id'),str)
                    or not _ID.fullmatch(source['comment_id'])
                    or lead['source_uid']!=lead['platform']+':'+_digest(['comment',post_id,source['comment_id']])):
                raise SourceIntentError('所选作品来源已变化')
            account=_row(db,'accounts',source.get('account_id'),tenant)
            if (not account or account.get('cloud_owner')!=host.executor.owner
                    or account.get('platform')!=lead['platform']
                    or str(account.get('platform_uid') or '')!=source['account_uid']
                    or account.get('requires_review') not in (None,False)
                    or account.get('risk_state') not in (None,'','normal','safe')
                    or not _owner_host(host) and _digest({key:account.get(key) for key in _ACCOUNT_FIELDS})!=source.get('account_binding_digest')
                    or _digest([account.get('conn_id') or ''])!=source.get('connection_digest')):
                raise SourceIntentError('原读取账号身份或绑定需核对，账号状态保持原样')
            host.core._account_access(current,account)
            if _owner_host(host):host.check_account(account)
            accounts.append(deepcopy(account))
            leads.append(lead);sources.append(source)
        group_fields=('platform','post_id','account_id','account_uid','account_binding_digest','connection_digest','license_digest','input_digest','read_operation_id')
        if len({digest({key:row.get(key) for key in group_fields}) for row in sources})!=1:
            raise SourceIntentError('请选择同一作品、读取账号和原归档批的评论')
        actor={key:current.get(key) for key in ('id','tenant_id','username','role','cloud_bound')}
        batch_rows=[_row(db,BATCHES,self.snapshot['batch']['id'],tenant)] if self.snapshot is not None else _rows(db,BATCHES,tenant)
        receipt_rows=[_row(db,RECEIPTS,self.snapshot['receipt']['id'],tenant)] if self.snapshot is not None else _rows(db,RECEIPTS,tenant)
        batches=[row for row in batch_rows if row is not None
                 if row.get('cloud_owner')==host.executor.owner and row.get('device_id')==host.device_id
                 and row.get('actor')==actor and type(row.get('source_count')) is int
                 and 1<=row['source_count']<=100
                 and isinstance(row.get('batch_digest'),str) and re.fullmatch('[0-9a-f]{64}',row['batch_digest'])
                 and isinstance(row.get('lead_ids'),list) and len(row['lead_ids'])==row['source_count']
                 and len(set(row['lead_ids']))==len(row['lead_ids']) and set(self.ids)<=set(row['lead_ids'])
                 and (host.archive_batch_matches(row,sources) if _owner_host(host) else
                      row.get('input_digest')==sources[0].get('input_digest'))]
        receipts=[row for row in receipt_rows if row is not None
                  if row.get('cloud_owner')==host.executor.owner and row.get('device_id')==host.device_id
                  and row.get('actor')==actor and row.get('state')=='succeeded'
                  and isinstance(row.get('payload_digest'),str) and re.fullmatch('[0-9a-f]{64}',row['payload_digest'])]
        pairs=[(batch,receipt) for batch in batches for receipt in receipts
               if receipt.get('batch_id')==batch['id']
               and _archive_result_valid(receipt.get('result'))
               and receipt['result'].get('lead_ids')==batch['lead_ids']
               and receipt['result'].get('accepted_count')==batch['source_count']
               and receipt['result'].get('reply_allowed') is False
               and receipt['result'].get('real_platform_verified') is False
               and (not _owner_host(host) or host.archive_binding_matches(receipt,accounts[0]))]
        if not pairs:raise SourceIntentError('缺少原归档批与成功回执，请保留原记录核对')
        batch,receipt=min(pairs,key=lambda pair:(pair[0]['id'],pair[1]['id']))
        return {'leads':leads,'sources':sources,'batch':batch,'receipt':receipt,
                **({'accounts':accounts} if _owner_host(host) else {})}

    def check(self,user,db=None):
        if self.seal is not _SEAL or not _binding_host(self.host):
            raise SourceIntentError('归档范围无法核对')
        if db is None:
            with self.host.core.lock,self.host.core.store.connect() as connection:
                return self.check(user,connection)
        if self._load(user,db)!=self.snapshot:
            raise SourceIntentError('原评论、来源或回执在分析期间已变化，请按原编号核对')
        return self.host.check(user,db=db)

    def register_attempt(self,user,db,attempt):
        self.check(user,db)
        record=_row(db,ENTITY,self.operation_id,self.host.executor.tenant)
        if not record or record.get('source_digest')!=self.context_digest:
            raise SourceIntentError('原来源分析编号无法核对')
        record.update(attempt_id=attempt['id'],original_request_id=attempt['request_id'])
        _put(db,ENTITY,record)

    def dispatch_check(self,user):
        self.check(user)
        self.dispatched=True

    def persist(self,workflow,user,resolved,keys,checked,profile,rules_version):
        host=self.host;written=0
        with host.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');self.check(user,db)
            for ident in checked:workflow._put_cache(user,keys[ident],resolved[ident],db=db)
            for original in self.leads:
                lead=_row(db,'leads',original['id'],host.executor.tenant)
                lead['ai_intent']={**deepcopy(resolved[lead['id']]),**model_metadata(resolved[lead['id']],profile),'rules_version':rules_version,'cache_key':keys[lead['id']],'analyzed_at':timestamp()}
                lead['analysis_status']=lead['ai_intent']['status']
                lead['content_region']=lead['ai_intent'].get('content_region') or ''
                if lead['ai_intent'].get('region_status')=='unknown':lead['verification_status']='pending'
                _put(db,'leads',lead);written+=1
            record=_row(db,ENTITY,self.operation_id,host.executor.tenant)
            record.update(analysis_committed=True,analyzed=written,cache_hits=len(self.leads)-len(checked),updated_at=timestamp())
            _put(db,ENTITY,record)
            host.check(user,db=db)
        return written

class SourceIntentAnalysis:
    def __init__(self,server,executor,user):
        self.host=_SourceIntentHost(server,executor,user)
        self.receipts=ProductOperationReceipts(server.core,executor.tenant,executor.owner)

    @classmethod
    def _for_owner(cls,host):
        if not _owner_host(host):raise SourceIntentError('自营分析需要可信本人范围')
        host.check(host.user,feature=False)
        value=cls.__new__(cls);value.host=host
        value.receipts=ProductOperationReceipts(host.core,host.executor.tenant,host.executor.owner)
        return value

    def _view(self,data,receipt,*,read_only):
        host=self.host;host.check(host.user,feature=False)
        record=host.core.store.get(ENTITY,receipt['operation_id'])
        if record and (record.get('tenant_id')!=host.executor.tenant or record.get('cloud_owner')!=host.executor.owner
                or record.get('device_id')!=host.device_id or record.get('session_binding')!=(host.binding_id if _owner_host(host) else host.session.binding.hex())
                or record.get('actor_digest')!=host.actor):
            raise SourceIntentError('原分析归属已变化，请回到原范围核对',mutation_committed=None)
        record=record or {}
        if record and _owner_host(host):host.check_record(record)
        if record and (any(type(record.get(key)) is not int or not 0<=record[key]<=20 for key in ('selected_count','analyzed','cache_hits'))
                or not 1<=record['selected_count']<=20 or type(record.get('analysis_committed')) is not bool
                or record['analyzed']>record['selected_count'] or record['cache_hits']>record['selected_count']
                or record.get('original_request_id') is not None and (not isinstance(record['original_request_id'],str)
                    or not re.fullmatch('[0-9a-fA-F-]{36}',record['original_request_id']))):
            raise SourceIntentError('本机原分析记录需核对，请保留原编号',mutation_committed=None)
        attempt_status=None;request_id=record.get('original_request_id')
        if read_only and request_id:
            attempt_status=(host.attempt_status(record) if _owner_host(host) else
                            host.executor.ai.attempts.status(host.user,{'request_id':request_id}))
        committed=record.get('analysis_committed') is True
        selected=record.get('selected_count',0);analyzed=record.get('analyzed',0);hits=record.get('cache_hits',0)
        state='succeeded' if receipt['state']=='succeeded' and committed else 'not_committed' if receipt['state'] in ('cancelled','rejected') and not committed else 'unknown'
        host.check(host.user,feature=False)
        return {'operation_action':ACTION,'idempotency_key':data['idempotency_key'],'operation_id':receipt['operation_id'],'state':state,
            'mutation_committed':True if committed else False if state=='not_committed' else None,
            'selected_count':selected,'analyzed':analyzed,'cache_hits':hits,'analysis_complete':committed and analyzed==selected,
            'original_request_id':request_id,'attempt_status':attempt_status,'refresh_required':committed,'read_only':read_only,
            'auto_retry':False,'retry_allowed':False,'billing_verified':False,'platform_requests_started':False,'tasks_created':0,
            'reply_allowed':False,'real_platform_verified':False,'local_only':True}

    def execute(self,action,data,user):
        host=self.host;host.check(user,feature=action==ACTION)
        if action=='source_intent_analysis_status':
            if set(data)!={'idempotency_key'}:raise SourceIntentError('请仅使用原分析操作编号核对')
            return self._view(data,self.receipts.status(ACTION,data['idempotency_key']),read_only=True)
        if action!=ACTION or set(data)!={'lead_ids','city','area','idempotency_key'}:
            raise SourceIntentError('来源分析参数不正确')
        ids=data['lead_ids'];city=data['city'];area=data['area']
        if (not isinstance(ids,list) or not 1<=len(ids)<=20 or any(not isinstance(value,str) or not _ID.fullmatch(value) for value in ids)
                or len(set(ids))!=len(ids) or not isinstance(city,str) or not city.strip().removesuffix('市').strip() or len(city.strip())>80
                or not isinstance(area,str) or len(area)>80 or any(ord(char)<32 or ord(char)==127 for char in city+area)):
            raise SourceIntentError('请选择同作品最多20条评论，并明确分析城市')
        # A replay is resolved by the original durable operation before looking
        # at now-rated source rows. No new binding or model call is constructed.
        with host.core.lock:
            ident=self.receipts._identity(ACTION,data['idempotency_key'])
            previous=host.core.store.get('product_operation_receipts',ident)
            if previous:
                begun=self.receipts.begin(ACTION,data['idempotency_key'],data)
                if begun['state']=='succeeded':return self._view(data,begun,read_only=False)
                raise SourceIntentError('原分析结果待核对，请保留原编号，暂勿重复提交',mutation_committed=begun['mutation_committed'])
            binding=_ArchivedSourceBinding(_SEAL,host,ids,city.strip(),area.strip())
            begun=self.receipts.begin(ACTION,data['idempotency_key'],data)
            if not begun['should_execute']:raise SourceIntentError('原分析编号已占用，请先核对原操作',mutation_committed=None)
            binding.operation_id=ident
            host.core.store.put(ENTITY,{'id':ident,'tenant_id':host.executor.tenant,'cloud_owner':host.executor.owner,
                'device_id':host.device_id,'session_binding':(host.binding_id if _owner_host(host) else host.session.binding.hex()),'actor_digest':host.actor,
                **({'owner_source_scope':host.operation_scope()} if _owner_host(host) else {}),
                'source_digest':binding.context_digest,'selected_count':len(ids),'analyzed':0,'cache_hits':0,
                'analysis_committed':False,'created_at':timestamp()})
        try:
            result=host.executor.ai.analyze_archived_source(user,binding)
            counts={'selected':len(ids),'analyzed':result['analyzed'],'cache_hits':result.get('cache_hits',0)}
            finished=self.receipts.finish({'status':'succeeded','counts':counts,'local_only':True})
        except Exception:
            # Dispatch, storage and post-commit failures preserve old fee/result
            # facts; no exception type is treated as proof of a missing write.
            try:self.receipts.fail(SourceIntentError('原分析待核对',mutation_committed=None))
            except Exception:pass
            raise SourceIntentError('本次分析结果尚未核实，请按原编号核对，暂勿重复分析',mutation_committed=None) from None
        try:
            return self._view(data,finished,read_only=False)
        except Exception:
            # Projection can fail after ratings and the success receipt commit.
            # It cannot turn the original saved fact into a known rejection.
            raise SourceIntentError('分析返回时员工或电脑已变化，请按原编号核对',mutation_committed=None) from None
