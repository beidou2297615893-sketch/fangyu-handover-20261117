"""Opt-in browser login worker for an existing customer XHS account.

The source launcher supplies a fixed helper path. This module reuses only the
current account's owned WebView2 profile, never a default browser profile,
and never starts acquisition or reply work.
"""

import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import threading
import time
import re

from core.adapters import AdapterBusy, AdapterSafetyRequired, account_execution_lock
from .browser_login_coordinator import BrowserLoginCoordinator
from .browser_session_commit import account_revision, commit_browser_session, recover_browser_session
from .business import xiaohongshu_held
from .login_outcome import classify_login_failure
from .login_natural_proof import NaturalProofError, create_spec, verified_status
from .local_runtime_errors import LocalPlatformRuntimeError


_MESSAGES = {
    'cancelled': '已取消本次浏览器登录',
    'timeout': '等待浏览器登录超时，请检查手机提示',
    'account_deleted': '账号已移除，浏览器登录已停止',
    'access_revoked': '账号访问权限已改变，登录已停止',
    'cloud_paused': '企业服务已暂停平台操作，登录已停止',
    'safety_paused': '账号有待复核的安全记录，登录已停止',
    'account_changed': '账号记录已改变，本次登录已停止',
    'identity_mismatch': '浏览器登录账号与记录不符，登录已停止',
    'duplicate_identity': '该平台身份已有另一条本机账号记录',
    'identity_unverified': '浏览器候选会话未能确认平台身份',
    'cloud_claim_failed': '企业账号身份未确认，登录已停止',
    'commit_failed': '会话提交失败，旧会话已保留或进入恢复检查',
    'cleanup_failed': '候选会话清理失败，请管理员检查本机临时目录',
    'helper_unverified': '浏览器窗口未确认登录完成，本次会话未提交',
    'browser_cookie_missing': '网页登录信息不完整，本次会话未提交；请联系维护人员核对登录接入',
    'browser_cookie_policy': '网页登录信息未通过本机校验，本次会话未提交；请联系维护人员',
    'browser_cookie_reader': '本机未能接收网页登录信息，本次会话未提交；请联系维护人员',
    'browser_window_failed': '网页登录窗口收尾失败，本次会话未提交；请联系维护人员',
    'candidate_missing': '浏览器未生成候选会话，本次会话未提交',
    'staging_path_invalid': '浏览器候选目录安全检查失败，登录已停止',
    'profile_path_invalid': '本机网页登录资料目录安全检查失败，登录已停止',
    'profile_reset_failed': '扫码账号与绑定账号不符，网页登录资料未能安全重置；请管理员检查后重试',
    'recovery_required': '原有会话需要管理员检查，登录已停止',
    'previous_login_closing': '上一个登录窗口仍在关闭，请稍后再试',
    'natural_proof_invalid': '本机网页登录身份凭据未通过核对，本次会话未提交',
    'natural_proof_write_failed': '本机网页登录身份凭据未能保存，本次会话未提交',
    'natural_identity_unverified': '本次网页登录尚未取得可核对的身份，本次会话未提交',
    'native_cdp_unavailable': '本机网页登录身份观察组件不可用，本次会话未提交',
    'verification_required': '小红书要求核对电脑端验证；本次会话未提交',
    'not_authenticated': '小红书登录状态尚未确认；本次会话未提交',
    'activity_log_failed': '本机未能保存网页登录安全记录，本次会话未提交',
    'cli_runtime_invalid': '本机组件不完整，请更新工作台后重试；无需重新扫码',
    'cli_adapter_invalid': '本机组件配置未通过检查，请更新工作台后重试；无需重新扫码',
}


def _record_browser_outcome(account_dir, job_id, code):
    """Record a fixed natural browser outcome without response or identity."""
    statuses = {b'candidate_staged_natural_verified': 'completed',
                b'verification_required': 'verification_required',
                b'not_authenticated': 'not_authenticated'}
    status = statuses.get(code)
    if status is None:
        return
    if not isinstance(job_id, str) or re.fullmatch(r'[a-f0-9]{24}', job_id) is None:
        raise _Stopped('activity_log_failed')
    payload = (json.dumps({'at': time.time(), 'stage': 'browser_finished',
                           'kind': 'login', 'request_id': job_id,
                           'status': status}, separators=(',', ':')) + '\n').encode('utf-8')
    try:
        handle = os.open(Path(account_dir) / 'platform-activity.jsonl',
                         os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try:
            if os.write(handle, payload) != len(payload):
                raise OSError('activity_record_incomplete')
            os.fsync(handle)
        finally:
            os.close(handle)
    except OSError:
        raise _Stopped('activity_log_failed') from None


def _helper_failure(code):
    """Retain only known, credential-free boundary outcomes, never stderr."""
    if code == b'cookie_missing':
        return 'browser_cookie_missing'
    if code in {b'cookie_shape_invalid', b'cookie_domain_mismatch',
                b'cookie_not_secure', b'cookie_duplicate_or_empty',
                b'cookie_expiry_invalid', b'cookie_expiry_missing',
                b'cookie_expired', b'cookie_oversize', b'cookies_oversize'}:
        return 'browser_cookie_policy'
    if code in {b'reader_timeout', b'reader_failed', b'reader_url_failed',
                b'reader_import_failed', b'reader_form_failed',
                b'reader_browser_failed', b'reader_control_failed',
                b'reader_identity_failed', b'reader_uninitialized',
                b'owned_window_invalid', b'candidate_capture_failed'}:
        return 'browser_cookie_reader'
    if code == b'window_failed':
        return 'browser_window_failed'
    if code == b'profile_path_invalid':
        return 'profile_path_invalid'
    if code in {b'natural_proof_invalid', b'natural_proof_write_failed',
                b'natural_identity_unverified', b'native_cdp_unavailable',
                b'verification_required', b'not_authenticated'}:
        return code.decode('ascii')
    return 'helper_unverified'


def _candidate_status_failure(result):
    """Convert one status probe's bounded evidence to fixed candidate text."""
    http_status = result.get('http_status')
    if http_status in (461, 471):
        return ('verification_required',
                f'小红书电脑端验证尚未完成（HTTP {http_status}）；请查看手机提示，本次会话未提交')
    if http_status == 429:
        return ('rate_limited', '小红书暂未接受本次登录状态核验（HTTP 429）；本次会话未提交')
    if http_status == 403:
        return ('status_forbidden', '小红书未放行本次登录状态核验（HTTP 403）；本次会话未提交')
    code = result.get('code')
    messages = {
        'not_authenticated': '小红书登录状态尚未确认；本次会话未提交',
        'verification_required': '小红书要求核对电脑端验证；本次会话未提交',
        'ip_blocked': '小红书限制了当前网络访问；本次会话未提交',
        'signature_error': '登录状态核验签名失败；请联系管理员，本次会话未提交',
        'api_error': '小红书登录状态核验失败；本次会话未提交',
        'unsupported_operation': '当前 CLI 不支持登录状态核验；请联系管理员',
        'protocol_error': '小红书登录状态返回格式无效；本次会话未提交',
        'transport_error': '小红书登录状态核验连接失败；本次会话未提交',
    }
    if code in messages:
        return code, messages[code]
    return None


def _candidate_status_exception(error):
    """Classify known local preflight failures without exposing exception text."""
    if isinstance(error, LocalPlatformRuntimeError):
        return error.code, _message(error.code)
    if (isinstance(error, FileNotFoundError)
            or (type(error) is RuntimeError and str(error) == '平台 CLI 未安装或路径未配置')):
        return 'cli_runtime_invalid', _message('cli_runtime_invalid')
    return None


class _Stopped(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _message(code):
    return _MESSAGES.get(code, '浏览器登录未完成，请按错误码联系管理员')


def _staging_scope(store_dir, account_dir, staging):
    """Reject redirects in every existing component before helper or cleanup."""
    try:
        store = Path(store_dir).absolute()
        account = Path(account_dir).absolute()
        candidate = Path(staging).absolute()
        if candidate.parent != account / 'work' / 'browser-login':
            return False
        if account.parent.parent.parent != store or candidate.name in ('', '.', '..'):
            return False
        paths = [store, store / 'accounts', account.parent, account,
                 account / 'work', candidate.parent, candidate]
        for path in paths:
            if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
                return False
            if path.exists():
                attrs = getattr(os.lstat(path), 'st_file_attributes', 0)
                if attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
                    return False
        return candidate.resolve().parent == (account / 'work' / 'browser-login').resolve()
    except (OSError, ValueError, RuntimeError):
        return False


def _profile_scope(store_dir, account_dir, profile):
    """Allow only the fixed profile under this one tenant/account directory."""
    try:
        store = Path(store_dir).absolute()
        account = Path(account_dir).absolute()
        selected = Path(profile).absolute()
        if selected != account / 'xhs-browser-profile' or account.parent.parent.parent != store:
            return False
        for path in (store, store / 'accounts', account.parent, account, selected):
            if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
                return False
            if path.exists() and getattr(os.lstat(path), 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
                return False
        return selected.resolve(strict=False).parent == account.resolve()
    except (OSError, ValueError, RuntimeError):
        return False


def _reset_mismatched_profile(store_dir, account_dir, profile):
    """Remove only a proven wrong-account WebView profile after its helper exited."""
    if not _profile_scope(store_dir, account_dir, profile):
        raise OSError('unsafe profile path')
    profile = Path(profile)
    if not profile.exists():
        return
    if not profile.is_dir():
        raise OSError('unsafe profile type')
    def fail_walk(error):
        raise error
    for root, dirs, files in os.walk(profile, followlinks=False, onerror=fail_walk):
        for name in (*dirs, *files):
            path = Path(root) / name
            if (path.is_symlink() or hasattr(path, 'is_junction') and path.is_junction()
                    or getattr(os.lstat(path), 'st_file_attributes', 0)
                       & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                raise OSError('unsafe profile contents')
    shutil.rmtree(profile)


def _cancel_marker(job):
    path = job.get('cancel_file')
    if path:
        try:
            marker = Path(path)
            parent = marker.parent
            if parent.is_symlink() or (hasattr(parent,'is_junction') and parent.is_junction()):
                return
            fd = os.open(marker, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
        except FileExistsError:
            pass
        except OSError:
            pass


def _cleanup_staging(store_dir, account_dir, staging):
    """Remove only this disposable candidate job; preserve the account profile."""
    if not _staging_scope(store_dir, account_dir, staging):
        raise OSError('unsafe staging path')
    config = Path(staging) / '.xiaohongshu-cli'
    if (config.is_symlink() or (hasattr(config, 'is_junction') and config.is_junction())
            or config.exists() and getattr(os.lstat(config), 'st_file_attributes', 0)
               & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
        raise OSError('unsafe candidate config')
    if config.exists():
        (config / 'cookies.json').unlink(missing_ok=True)
        shutil.rmtree(config)
    shutil.rmtree(staging)


def cancel_browser_job(service, job):
    """Request orderly close of only this service-owned helper process."""
    job.update(status='cancelled', phase='cancelled', error_code='cancelled', error=_message('cancelled'))
    _cancel_marker(job)


def _snapshot(service, user, account_id, account_dir):
    server = service.server
    base = {'id': account_id, 'platform': 'xiaohongshu', 'exists': True,
            'access_revoked': False, 'cloud_paused': False, 'safety_paused': False}
    if (service.closed or service.stop_event.is_set() or server.closing
            or service.state != 'online' or server.core.remote_safety_hold
            or xiaohongshu_held(server)):
        base['cloud_paused'] = True
    fresh_user = None
    try:
        fresh_user = service._local_user(read_only=True)
        if (fresh_user.get('id') != user.get('id')
                or fresh_user.get('tenant_id') != user.get('tenant_id')):
            base['access_revoked'] = True
    except Exception:
        base['access_revoked'] = True
    with server.core.lock:
        account = server.core.store.get('accounts', account_id)
        if not account or account.get('tenant_id') != user['tenant_id']:
            base['exists'] = False
            return base
        if fresh_user is not None:
            try:
                server.core._account_access(fresh_user, account)
            except Exception:
                base['access_revoked'] = True
        base['platform'] = account.get('platform')
        base['platform_uid'] = account.get('platform_uid')
        base['tenant_id'] = account.get('tenant_id')
        base['revision'] = account_revision(account)
        base['_account'] = dict(account)
    try:
        server.core.adapters.require_account_safe('xiaohongshu', account_dir)
    except AdapterSafetyRequired:
        base['safety_paused'] = True
    return base


def _stop_helper(proc, job, grace=3):
    _cancel_marker(job)
    try:
        proc.wait(timeout=grace)
    except (subprocess.TimeoutExpired, TimeoutError):
        try:
            proc.terminate()
            proc.wait(timeout=grace)
        except (subprocess.TimeoutExpired, TimeoutError):
            proc.kill()
            proc.wait(timeout=grace)


def start_browser_account_login(service, account_id, helper_path):
    """Create one service-owned browser job; no browser opens in this call."""
    server = service.server
    if (service.closed or service.state != 'online' or server.closing
            or server.core.remote_safety_hold or xiaohongshu_held(server)):
        raise ValueError('浏览器登录当前不可用')
    helper = Path(helper_path).resolve()
    frozen=getattr(sys,'frozen',False) is True
    bundled_helper=Path(__file__).resolve().with_name('browser_login_window.py')
    if (not helper.is_absolute() or helper.suffix.lower()!='.py' or
            (helper!=bundled_helper if frozen else not helper.is_file())):
        raise ValueError('浏览器登录助手未就绪')
    user = service._local_user()
    with server.core.lock:
        account = server.core._get('accounts', str(account_id or ''), user['tenant_id'])
        server.core._account_access(user, account)
        if account.get('platform') != 'xiaohongshu':
            raise ValueError('当前浏览器登录只支持小红书账号')
    account_dir = server.core.store.directory / 'accounts' / user['tenant_id'] / account['id']
    server.core.adapters.require_account_safe('xiaohongshu', account_dir)
    with server.job_lock:
        closing_workers = []
        for pending in server.jobs.values():
            if (pending.get('kind') == 'assistant_account_login'
                    and pending.get('account_id') == account['id']
                    and pending.get('status') == 'running'):
                return {'login_job': pending['id'], 'mode': pending.get('mode', 'qr'),
                        'account': {k: account.get(k) for k in ('id', 'name', 'platform', 'status')}}
            done = pending.get('worker_done')
            if (pending.get('kind') == 'assistant_account_login'
                    and pending.get('account_id') == account['id']
                    and pending.get('status') == 'cancelled'
                    and isinstance(done, threading.Event) and not done.is_set()):
                closing_workers.append(done)
        page_runtime = getattr(server, 'xhs_page_runtime', None)
        natural_mode = bool(page_runtime is not None and
                            getattr(page_runtime, 'natural_mode', False) is True)
        page_reservation = None
        if page_runtime is not None:
            try:
                page_reservation = page_runtime.begin_login(account_dir)
            except Exception as exc:
                raise ValueError('采集窗口尚未确认退出，请稍后再打开登录窗口') from exc
        import secrets
        job_id = secrets.token_hex(12)
        job = {'id': job_id, 'kind': 'assistant_account_login', 'mode': 'browser',
               'account_id': account['id'], 'owner_id': user['id'],
               'status': 'running', 'phase': 'opening_browser', 'error_code': '',
               'worker_done': threading.Event()}
        server.jobs[job_id] = job

    def worker():
        proc = None
        os_lock = None
        os_lock_entered = False
        completed_outcome = False
        staging = account_dir / 'work' / 'browser-login' / job_id
        profile_dir = account_dir / 'xhs-browser-profile'
        cancel_file = staging / 'cancel.flag'
        job['cancel_file'] = str(cancel_file)
        deadline = time.monotonic() + 300
        try:
            if closing_workers:
                job['phase'] = 'closing_previous_login'
                close_deadline = time.monotonic() + 8
                for done in closing_workers:
                    while not done.wait(.1):
                        if job.get('status') == 'cancelled':
                            return
                        if time.monotonic() >= close_deadline:
                            raise _Stopped('previous_login_closing')
                job['phase'] = 'opening_browser'
            if job.get('status') == 'cancelled':
                return
            os_lock = account_execution_lock(account_dir)
            os_lock.__enter__()
            os_lock_entered = True
            if job.get('status') == 'cancelled':
                return
            connection_lock = server.account_connections.locks.setdefault(account['id'], threading.Lock())
            with connection_lock:
                recovery = recover_browser_session(server.core.store, account_dir,
                                                   account['id'], user['tenant_id'])
            if recovery not in ('clean', 'old_restored', 'new_kept'):
                service._pause_xhs_identity(account, 'session_recovery_required',
                                            '会话恢复待管理员检查；相关任务已暂停')
                raise _Stopped('recovery_required')
            initial = _snapshot(service, user, account['id'], account_dir)
            for condition, code in ((not initial.get('exists'), 'account_deleted'),
                                    (initial.get('cloud_paused'), 'cloud_paused'),
                                    (initial.get('safety_paused'), 'safety_paused'),
                                    (initial.get('access_revoked'), 'access_revoked')):
                if condition:raise _Stopped(code)
            # The same static guard used by adapter execution must pass
            # before opening a login window; it performs no platform I/O.
            server.core.adapters._guard_platform('xiaohongshu')
            if not _staging_scope(server.core.store.directory, account_dir, staging):
                raise _Stopped('staging_path_invalid')
            if not _profile_scope(server.core.store.directory, account_dir, profile_dir):
                raise _Stopped('profile_path_invalid')
            staging.mkdir(parents=True, exist_ok=False)
            if not _staging_scope(server.core.store.directory, account_dir, staging):
                raise _Stopped('staging_path_invalid')
            if natural_mode:
                try:
                    create_spec(staging, job_id=job_id,
                                bound_uid=initial.get('platform_uid') or None)
                except NaturalProofError as error:
                    raise _Stopped(error.code) from None
            if job.get('status') == 'cancelled':
                _cancel_marker(job)
                return
            from .owned_helper_process import login_helper_argv
            helper_command=login_helper_argv(staging,cancel_file,profile_dir,
                                            natural_identity=natural_mode)
            proc = subprocess.Popen(
                list(helper_command.argv),
                shell=False, stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                cwd=helper_command.cwd, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                # WebView2 uses the explicit account-owned profile. Keep
                # the GUI's OS user directories intact: IME also
                # derives LocalLow from USERPROFILE. Only the separate CLI
                # status process receives the isolated candidate_home.
                env=dict(os.environ))
            job['process'] = proc
            job['phase'] = 'waiting_browser'
            while proc.poll() is None:
                current = _snapshot(service, user, account['id'], account_dir)
                reason = ('cancelled' if job.get('status') == 'cancelled' else
                          'timeout' if time.monotonic() >= deadline else
                          'account_deleted' if not current.get('exists') else
                          'access_revoked' if current.get('access_revoked') else
                          'cloud_paused' if current.get('cloud_paused') else
                          'safety_paused' if current.get('safety_paused') else
                          'account_changed' if current.get('revision') != initial.get('revision') else '')
                if reason:
                    _stop_helper(proc, job)
                    if job.get('status') != 'cancelled':
                        job.update(status='cancelled' if reason == 'cancelled' else 'failed',
                                   phase='stopped', error_code=reason, error=_message(reason))
                    return
                time.sleep(0.2)
            stdout, _ = proc.communicate(timeout=5)
            if job.get('status') == 'cancelled':
                return
            code = stdout.strip()
            if frozen or Path(sys.executable).stem.lower().startswith('pythonw'):
                # Windowed frozen Python can have sys.stdout=None. Use
                # this job's fixed, scoped result file after process exit;
                # success still requires the separate bound cookie proof.
                from .owned_helper_process import read_login_outcome
                code=read_login_outcome(staging) or b'helper_unverified'
            if natural_mode and (proc.returncode == 0 or code in
                                 (b'verification_required', b'not_authenticated')):
                _record_browser_outcome(account_dir, job_id, code)
            expected_code = (b'candidate_staged_natural_verified' if natural_mode
                             else b'candidate_staged_unverified')
            if proc.returncode != 0 or code != expected_code:
                if code in (b'cancelled', b'closed'):
                    raise _Stopped('cancelled')
                if code == b'timeout':
                    raise _Stopped('timeout')
                failure = _helper_failure(code)
                if failure != 'helper_unverified':
                    job['helper_outcome'] = code.decode('ascii')
                raise _Stopped(failure)
            cookie_path = staging / '.xiaohongshu-cli' / 'cookies.json'
            if not cookie_path.is_file():
                raise _Stopped('candidate_missing')
            job['phase'] = 'verifying_identity'
            with connection_lock:
                status_diagnostic = None

                def current():
                    return _snapshot(service, user, account['id'], account_dir)

                def claim(uid):
                    job['phase'] = 'confirming_connection'
                    try:
                        service._claim_xhs_account({**initial['_account'], 'platform_uid': uid})
                        return True
                    except Exception:
                        return False

                def commit(candidate, decision, original):
                    job['phase'] = 'saving_session'
                    def guard():
                        now = current()
                        return (job.get('status') == 'running'
                                and now.get('exists') and not now.get('access_revoked')
                                and not now.get('cloud_paused') and not now.get('safety_paused')
                                and now.get('revision') == original.get('revision'))
                    # Serialize core writers for the short atomic commit.
                    # The guard is read-only, including employee identity.
                    with server.core.lock:
                        result = commit_browser_session(server.core.store, account_dir,
                                                        original['_account'], decision, cookie_path, guard)
                    job['commit_code'] = result if result in ('committed', 'old_restored', 'recovery_required') else 'commit_failed'
                    if result == 'recovery_required':
                        service._pause_xhs_identity(original['_account'], 'session_recovery_required',
                                                    '会话恢复待管理员检查；相关任务已暂停')
                    return result == 'committed'

                def status_candidate(candidate):
                    nonlocal status_diagnostic
                    if natural_mode:
                        status = verified_status(staging, cookie_path)
                        if status is None:
                            status_diagnostic = ('natural_proof_invalid',
                                                 _message('natural_proof_invalid'))
                            return {'authenticated': False}
                        return status
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return {'authenticated': False}
                    started_at = time.time()
                    try:
                        return server.core.adapters.execute(
                            'xiaohongshu', ['status', '--json'], account_dir,
                            timeout=min(35, remaining), candidate_home=candidate)
                    except Exception as error:
                        evidence = classify_login_failure(
                            b'', account_dir / 'platform-activity.jsonl', started_at,
                            kind='status')
                        status_diagnostic = (_candidate_status_failure(evidence)
                                             or _candidate_status_exception(error))
                        return {'authenticated': False}

                coordinator = BrowserLoginCoordinator(
                    stage=lambda: staging,
                    status=status_candidate,
                    local_accounts=lambda: server.core.store.list('accounts', user['tenant_id']),
                    claim=claim, commit=commit, discard=lambda candidate: None,
                    current=current, cancelled=lambda: job.get('status') == 'cancelled',
                    deadline=deadline, expected_revision=initial['revision'])
                outcome = coordinator.run()
            if job.get('status') == 'cancelled':
                return
            if outcome.state == 'completed':
                # Do not expose success until the disposable candidate is
                # cleaned or its fixed cleanup failure is recorded.
                completed_outcome = True
                job['phase'] = 'cleaning_candidate'
            else:
                # A status request can create a new safety event, so the
                # coordinator may stop at safety_paused after the request.
                # Its current-run diagnostic explains that failure only;
                # it never changes the stopped decision or permits commit.
                diagnosis = (status_diagnostic if outcome.code in
                             ('identity_unverified', 'safety_paused', 'operation_failed') else None)
                job.update(status='failed', phase='stopped', error_code=outcome.code,
                           error=_message(outcome.code), cleanup_code=outcome.cleanup_code)
                if outcome.code == 'identity_mismatch':
                    try:
                        _reset_mismatched_profile(server.core.store.directory,
                                                  account_dir, profile_dir)
                    except OSError:
                        job.update(error_code='profile_reset_failed',
                                   error=_message('profile_reset_failed'),
                                   cleanup_code='profile_reset_failed')
                if diagnosis:
                    job.update(error_code=diagnosis[0], error=diagnosis[1])
        except _Stopped as error:
            if job.get('status') != 'cancelled':
                job.update(status='cancelled' if error.code=='cancelled' else 'failed',
                           phase='stopped', error_code=error.code, error=_message(error.code))
        except (AdapterBusy, AdapterSafetyRequired):
            if job.get('status') != 'cancelled':
                job.update(status='failed', phase='stopped', error_code='account_busy',
                           error='该账号正在执行其他操作，浏览器登录未启动')
        except LocalPlatformRuntimeError as error:
            if job.get('status') != 'cancelled':
                job.update(status='failed', phase='stopped', error_code=error.code,
                           error=_message(error.code))
        except Exception:
            if job.get('status') != 'cancelled':
                job.update(status='failed', phase='stopped', error_code='browser_login_failed',
                           error='浏览器登录未完成，请按错误码联系管理员')
        finally:
            cleanup_lock = server.account_connections.locks.setdefault(account['id'], threading.Lock())
            with cleanup_lock:
                # Cleanup stays on the original worker and keeps its OS
                # account lock until the helper and its pipes are confirmed.
                # A failed close is pending, never a finished login worker.
                while proc is not None:
                    try:
                        if proc.poll() is None:
                            _stop_helper(proc, job)
                        if proc.poll() is None:
                            raise RuntimeError('login_helper_alive')
                        for name in ('stdout', 'stderr'):
                            pipe = getattr(proc, name, None)
                            if pipe is not None and not pipe.closed:
                                pipe.close()
                    except Exception:
                        job['cleanup_code'] = 'helper_alive'
                        time.sleep(.2)
                    else:
                        break
                if job.get('cleanup_code') == 'helper_alive':
                    job.pop('cleanup_code')
                job.pop('process', None)
                try:
                    if staging.exists():
                        _cleanup_staging(server.core.store.directory, account_dir, staging)
                except OSError:
                    job['cleanup_code'] = 'cleanup_failed'
            if page_reservation is not None:
                while True:
                    try:
                        page_runtime.finish_login(account_dir, page_reservation)
                    except Exception:
                        job['cleanup_code'] = 'cleanup_failed'
                        time.sleep(.2)
                    else:
                        break
            if os_lock_entered:
                os_lock.__exit__(None, None, None)
            if completed_outcome:
                job.update(status='completed', phase='completed', error_code='', error='')
            job['worker_done'].set()

    try:
        threading.Thread(target=worker, name='assistant-browser-login', daemon=True).start()
    except Exception:
        with server.job_lock:
            server.jobs.pop(job_id, None)
        if page_reservation is not None:
            page_runtime.finish_login(account_dir, page_reservation)
        raise ValueError('浏览器登录任务未能启动') from None
    return {'login_job': job_id, 'mode': 'browser',
            'account': {k: account.get(k) for k in ('id', 'name', 'platform', 'status')}}
