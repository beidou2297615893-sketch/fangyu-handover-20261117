"""Owner-local recorded facts, voluntary protected contacts and draft handoffs.

No platform/AI/cloud grant is issued. Default employee services stay separate.
Only explicit reveal can return a contact value. Facts contain no reply text.
"""
from contextlib import contextmanager
from copy import deepcopy
import json
import math
import re
import threading
import time
import unicodedata
from uuid import uuid4

from core import CoreError
from core.platform_reads import _digest as read_digest, source_reference
from .self_operating_read import OwnerReadWorkspace, _OwnerReadInstance
from .self_operating_archive import OwnerSourceArchive, _OwnerArchiveScope
from .platform_receipt_archive import SOURCES, BATCHES, RECEIPTS, _hash as archive_hash, _safe_url as archive_safe_url
from .source_intent_analysis import _archive_result_valid
from .product_receipts import ProductOperationReceipts, ENTITY as RECEIPT_ENTITY, _hash as digest

_SEAL = object()
FACTS = 'owner_manual_contact_facts'
_ACTOR = ('id', 'tenant_id', 'username', 'role', 'cloud_bound', 'personal_owner')
_ACCOUNT = ('id', 'tenant_id', 'cloud_owner', 'platform', 'platform_uid', 'conn_id')
_LEAD = ('id', 'tenant_id', 'cloud_owner', 'platform', 'source_id', 'source_uid', 'source_type',
    'text', 'title', 'author', 'note_url', 'url', 'task_id', 'demo', 'readonly_archive',
    'can_reply', 'reply_target_status', 'privacy_redacted', 'author_id', 'comment_id',
    'target_comment_id', 'target_author_id')
_ROUTING = ('platform', 'source_id', 'source_type', 'note_url', 'url', 'comment_id',
    'author_id', 'target_comment_id', 'target_author_id')
_KEY = re.compile(r'op_[a-f0-9]{32}\Z')
_UID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
KINDS = frozenset(('draft_copied', 'contact_reported', 'customer_response_reported'))
TONES = frozenset(('official_advisor', 'professional_intermediary', 'friendly_advisor'))
_WRITES = frozenset(('owner_manual_contact_record', 'contact_create', 'contact_revoke', 'handoff_create'))
_LOCAL = {'local_only': True, 'storage_scope': 'this_device', 'auto_retry': False,
    'platform_requests_started': False, 'platform_reply_verified': False,
    'customer_identity_verified': False, 'resource_receipt_verified': False,
    'cross_machine_verified': False, 'independently_verified': False}


class OwnerAcquisitionError(CoreError):
    def __init__(self, message, *, mutation_committed=False):
        super().__init__(message)
        self.mutation_committed = mutation_committed


def _fail(message):
    raise OwnerAcquisitionError(message)


def _row(db, entity, ident, tenant):
    row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
        (entity, ident, tenant)).fetchone()
    if row is None:
        return None
    try:
        value = json.loads(row['body'])
    except (ValueError, TypeError):
        _fail('本机记录需人工核对')
    if type(value) is not dict or value.get('id') != ident or value.get('tenant_id') != tenant:
        _fail('本机记录归属不一致')
    return value


def _rows(db, entity, tenant):
    return [json.loads(row['body']) for row in db.execute(
        'SELECT body FROM records WHERE entity=? AND tenant_id=?', (entity, tenant)).fetchall()]


def _identity(value, fields):
    return {key: value.get(key) for key in fields}


def _safe_label(value, label, limit=160):
    if type(value) is not str or not value.strip() or len(value) > limit:
        _fail(label + '无效')
    checked = unicodedata.normalize('NFKC', value)
    if any(unicodedata.category(c) in ('Cc', 'Cf', 'Cs') for c in checked):
        _fail(label + '不允许隐藏字符')
    # Human-entered purpose/recipient/notice remain unverified local records.
    # Contact values and secrets must not become ordinary metadata.
    compact = ''.join(c for c in checked if c.isalnum())
    if (re.search(r'\d{7,}', compact)
            or re.search(r'(?:微信|wechat|wx|电话|手机号|cookie|password|secret|api[_-]?key)\s*[:：=]', checked, re.I)
            or re.search(r'\bBearer\s+|sk-[\w-]{12}', checked, re.I)):
        _fail('联系方式与密钥仅可使用受保护字段')
    return value.strip()


def _validated_owner_scope(scope, core, tenant, owner, company):
    if (type(scope) is not _OwnerAcquisitionScope or scope._seal is not _SEAL
            or type(scope.service) is not OwnerAcquisition
            or scope.service.core is not core or scope.service.server.company is not company
            or (scope.service.tenant, scope.service.owner) != (tenant, owner)):
        _fail('自营业务范围只能由当前可信实例创建')
    return scope


class _OwnerAcquisitionScope:
    def __init__(self, service, seal):
        if seal is not _SEAL or type(service) is not OwnerAcquisition:
            _fail('自营业务范围无法核对')
        self.service, self._seal = service, seal

    def _frame(self):
        frame = getattr(self.service._tls, 'frame', None)
        if self._seal is not _SEAL or type(frame) is not dict or frame.get('seal') is not _SEAL:
            _fail('本机业务不在当前本人操作中')
        return frame

    def check(self, user=None, db=None, record=None):
        frame = self._frame()
        if db is None:
            if frame.get('package_context') is not None:
                db = frame['package_context'].db
                return self.check(user, db, record)
            with self.service.core.store.connect() as connection:
                return self.check(user, connection, record)
        if frame.get('package_context') is not None:
            from .owner_contact_handoff_package import _validate_package_context
            _validate_package_context(frame['package_context'], self.service, db)
        current = self.service._current(frame['token'])
        stored = _row(db, 'users', current['id'], self.service.tenant)
        if (stored is None or stored.get('disabled') or stored.get('role') != 'admin'
                or stored.get('personal_owner') is not True or stored.get('cloud_bound') not in (None, False)
                or _identity(stored, _ACTOR) != _identity(frame['user'], _ACTOR)
                or _identity(current, _ACTOR) != _identity(frame['user'], _ACTOR)
                or user is not None and _identity(user, _ACTOR) != _identity(stored, _ACTOR)):
            _fail('本人身份或角色已变化，保留原业务事实')
        binding = self.service._load_source(db, stored, frame['account_id'], frame['lead_id'],
            _stored_binding=frame.get('stored_binding'),_token=frame['token'])
        if binding != frame['binding']:
            _fail('原来源身份或归属已变化，保留原编号核对')
        if record is not None and record.get('owner_acquisition_scope') != binding:
            _fail('原业务记录不属于本人的当前实例和来源')
        return stored

    def binding(self, db=None):
        self.check(db=db)
        return deepcopy(self._frame()['binding'])

    def source(self, user, lead, db=None):
        if lead.get('id') != self._frame()['lead_id']:
            _fail('不能借本人范围选择其他来源')
        self.check(user, db)

    def require_action(self, action):
        if action not in ('contact_create', 'contact_read', 'contact_revoke',
                'handoff_create', 'handoff_list', 'handoff_detail') or action != self._frame()['action']:
            _fail('本机草稿不能用于发送、提交、接收或归属审核')

    def can_view(self, user, item):
        frame = self._frame()
        return (item.get('tenant_id') == self.service.tenant and item.get('cloud_owner') == self.service.owner
            and item.get('company_id') == self.service.server.company['id']
            and item.get('lead_id') == frame['lead_id'] and item.get('status') == 'draft'
            and item.get('owner_acquisition_scope') == frame['binding'])


class _OwnerReceipts(ProductOperationReceipts):
    """Only identity/scope bridges; original begin/fail/finish/status are inherited."""
    def __init__(self, scope):
        self.scope = scope
        super().__init__(scope.service.core, scope.service.tenant, scope.service.owner)

    def _identity(self, action, key):
        if action not in _WRITES or type(key) is not str or not _KEY.fullmatch(key):
            _fail('请保留有效的本机动作与原操作编号')
        return digest([self.tenant, self.owner, action, key])

    def _read(self, db, ident, action, key):
        self.scope.check(db=db)
        record = super()._read(db, ident, action, key)
        if record is not None:
            self.scope.check(db=db, record=record)
        return record

    def _put(self, db, record, *, new=False):
        self.scope.check(db=db)
        if new:
            record['owner_acquisition_scope'] = self.scope.binding(db)
            # A durable unresolved receipt cannot be evaded by a new key.
            if record['state'] == 'started':
                for old in _rows(db, RECEIPT_ENTITY, self.tenant):
                    if (old.get('cloud_owner') == self.owner and old.get('original_action') == record['original_action']
                            and old.get('state') in ('started', 'unknown')
                            and old.get('owner_acquisition_scope', {}).get('lead_id') == record['owner_acquisition_scope']['lead_id']):
                        _fail('原本机操作结果未知，请只核对原编号，不能换号重做')
        else:
            self.scope.check(db=db, record=record)
            if record['state'] == 'succeeded' and record['original_action'] in ('contact_create', 'handoff_create'):
                record['owner_history_metadata_digest'] = self.scope.service._history_finish_digest(db, record)
        return super()._put(db, record, new=new)


class OwnerAcquisition:
    HISTORY_ACTIONS = frozenset(('owner_acquisition_history_list', 'owner_acquisition_history_detail',
        'owner_source_processing_detail', 'owner_source_locator_get'))
    ACTIONS = frozenset(('owner_manual_contact_record', 'owner_manual_contact_get',
        'contact_create', 'contact_read', 'contact_revoke', 'handoff_create',
        'handoff_list', 'handoff_detail', 'owner_acquisition_operation_status',
        'owner_handoff_package_create', 'owner_handoff_package_status', 'owner_handoff_package_download',
        'owner_handoff_followup_list', 'owner_handoff_followup_detail', 'owner_handoff_delivery_record',
        'owner_handoff_feedback_record', 'owner_handoff_followup_operation_status',
        'owner_company_receipt_login', 'owner_company_receipt_scope_get',
        'owner_company_receipt_register', 'owner_company_receipt_consent_sync',
        'owner_company_receipt_submit', 'owner_company_receipt_withdraw',
        'owner_company_receipt_operation_status', 'owner_company_receipt_channel_get',
        'owner_company_receipt_business_get', 'owner_company_receipt_logout'))

    def __init__(self, workspace, archive):
        if (type(workspace) is not OwnerReadWorkspace or type(workspace.instance) is not _OwnerReadInstance
                or type(archive) is not OwnerSourceArchive or archive.workspace is not workspace
                or type(archive._scope) is not _OwnerArchiveScope or archive._archive is None
                or archive._scope._reads is not workspace._reads):
            _fail('本机业务必须从当前可信自营实例及原归档服务创建')
        self.workspace, self.archive, self.instance = workspace, archive, workspace.instance
        self.server, self.core = workspace.server, workspace.server.core
        self.instance_id = self.instance.check()['selfOperatingRead']['instance_id']
        self._tls = threading.local()
        self._scope = _OwnerAcquisitionScope(self, _SEAL)
        self._identity = None
        self.tenant = self.owner = None
        self._packages = None
        self._followups = None
        self._company_receipts = None

    def _current(self, token):
        company = self.instance.check()
        if (self.server.core is not self.core or self.server._self_operating_reads is not self.workspace
                or self.workspace.instance is not self.instance or self.archive.workspace is not self.workspace
                or self.archive._scope._reads is not self.workspace._reads
                or self.archive._archive.core is not self.core
                or company['selfOperatingRead']['instance_id'] != self.instance_id
                or self.core.store.directory != self.instance.directory / 'data'
                or self.core.deployment_config.get('id') != company['id']
                or self.core.deployment_config.get('edition') != 'owner'
                or self.core.deployment_config.get('personalMode') is not True):
            _fail('不能接管其他实例、旧数据或员工授权')
        user = self.workspace._actor(token)
        identity = _identity(user, _ACTOR)
        if self._identity is None:
            self._identity = identity
            self.tenant, self.owner = user['tenant_id'], user['username']
        if identity != self._identity:
            _fail('本机业务的本人主体已变化')
        return user

    def _load_source_identity(self, db, user, account_id, lead_id, *, _token=None):
        tenant = user['tenant_id']
        account = _row(db, 'accounts', account_id, tenant)
        platform=account.get('platform') if account else None
        if platform=='douyin' and _token is not None:
            from .self_operating_source_intent import OwnerSourceIntent
            if type(self.workspace._intent) is not OwnerSourceIntent:_fail('原本人来源服务需核对')
            now=self.workspace._intent._source_account(_token,user,account_id,cleanup=True)
        elif platform=='xiaohongshu':
            now=self.workspace._account(user,account_id,cleanup=True)
        else:_fail('此预览或平台未接入本人客户整理')
        valid_uid=(type(account.get('platform_uid')) is str and
            (_UID.fullmatch(account['platform_uid']) if platform=='xiaohongshu' else
             re.fullmatch(r'[0-9]{1,160}',account['platform_uid']) and account['platform_uid'].strip('0')))
        if (not account or _identity(now, _ACCOUNT) != _identity(account, _ACCOUNT)
                or account.get('cloud_owner') != self.owner or not valid_uid
                or account['platform_uid'].casefold() in ('0', 'unknown', 'null', 'none', '-')):
            _fail('原本人读取账号身份需核对')
        lead = _row(db, 'leads', lead_id, tenant)
        if (not lead or lead.get('cloud_owner') != self.owner or lead.get('task_id') or lead.get('demo')
                or lead.get('platform') != platform or lead.get('source_type') != 'comment'
                or lead.get('readonly_archive') is not True or lead.get('can_reply') is not False
                or lead.get('reply_target_status') != 'not_verified'
                or any(lead.get(k) not in (None, '') for k in ('author_id', 'comment_id', 'target_comment_id', 'target_author_id'))
                or type(lead.get('source_uid')) is not str):
            _fail('只能整理本实例本人已归档的安全来源')
        source = _row(db, SOURCES, archive_hash([tenant, lead['source_uid']]), tenant)
        if (not source or source.get('lead_id') != lead_id or source.get('cloud_owner') != self.owner
                or source.get('source_uid') != lead['source_uid'] or source.get('platform') != platform
                or source.get('device_id') != self.instance_id or source.get('actor_id') != user['id']
                or source.get('actor_role') != user['role'] or source.get('account_id') != account_id
                or source.get('account_uid') != account['platform_uid']
                or source.get('connection_digest') != read_digest([account.get('conn_id') or ''])
                or source.get('lead_text_hash') != archive_hash(lead.get('text') or '')
                or source.get('safe_text_hash') != archive_hash(lead.get('text') or '')
                or source.get('lead_source_digest') != archive_hash(_identity(lead, _ROUTING))
                or source.get('privacy_redacted') != lead.get('privacy_redacted')
                or type(source.get('privacy_redacted')) is not bool
                or source.get('real_platform_verified') is not False or source.get('reply_target_verified') is not False
                or source.get('evidence_level') != 'transport_reported'
                or any(type(source.get(k)) is not str or not _HEX.fullmatch(source[k]) for k in
                    ('account_binding_digest', 'connection_digest', 'license_digest', 'input_digest', 'original_text_hash'))):
            _fail('原来源证据、隐私或账号归属需核对')
        post_id, _ = source_reference(platform, lead.get('note_url') or lead.get('url'))
        if (post_id != source.get('post_id') or type(source.get('comment_id')) is not str
                or not _UID.fullmatch(source['comment_id']) or type(source.get('author_id')) is not str
                or (source['author_id']!='' and not _UID.fullmatch(source['author_id']) if platform=='douyin' else not _UID.fullmatch(source['author_id']))
                or (platform=='douyin' and source.get('author_identity')!=('platform_id' if source['author_id'] else 'not_provided'))
                or lead['source_uid'] != platform+':' + read_digest(['comment', post_id, source['comment_id']])):
            _fail('原作品与评论来源身份已变化')
        return account, lead, source

    def _load_source(self, db, user, account_id, lead_id, *, _stored_binding=None,_token=None):
        tenant = user['tenant_id']
        account, lead, source = self._load_source_identity(db, user, account_id, lead_id,_token=_token)
        actor = _identity(user, ('id', 'tenant_id', 'username', 'role', 'cloud_bound'))
        platform=account['platform'];archive_digest=read_digest if platform=='douyin' else digest
        owner_binding = {'schema': 'local_owner_douyin_archive_v1' if platform=='douyin' else 'local_owner_archive_v2',
            'local_instance_id': self.instance_id,
            'account_id': account_id, 'account_digest': archive_digest(_identity(account, _ACCOUNT)),
            'actor_digest': archive_digest(_identity(user, _ACTOR))}
        if _stored_binding is None:
            batch_rows, receipt_rows = _rows(db, BATCHES, tenant), _rows(db, RECEIPTS, tenant)
        else:
            if (type(_stored_binding) is not dict or any(type(_stored_binding.get(k)) is not str
                    or not _HEX.fullmatch(_stored_binding[k]) for k in ('batch_id', 'receipt_id'))):
                _fail('原归档定位需核对')
            batch_rows = [_row(db, BATCHES, _stored_binding['batch_id'], tenant)]
            receipt_rows = [_row(db, RECEIPTS, _stored_binding['receipt_id'], tenant)]
            if batch_rows[0] is None or receipt_rows[0] is None:
                _fail('原归档定位不存在，保留原编号核对')
        batches = [b for b in batch_rows if b.get('cloud_owner') == self.owner
            and b.get('device_id') == self.instance_id and b.get('actor') == actor
            and type(b.get('source_count')) is int and 1 <= b['source_count'] <= 100
            and type(b.get('lead_ids')) is list and len(b['lead_ids']) == b['source_count']
            and len(set(b['lead_ids'])) == len(b['lead_ids']) and lead_id in b['lead_ids']
            and ((b['source_count']<=20 and type(b.get('input_digest')) is str and _HEX.fullmatch(b['input_digest']))
                 if platform=='douyin' else b.get('input_digest') == source['input_digest'])
            and type(b.get('batch_digest')) is str and _HEX.fullmatch(b['batch_digest'])]
        receipts = [r for r in receipt_rows if r.get('cloud_owner') == self.owner
            and r.get('device_id') == self.instance_id and r.get('actor') == actor
            and r.get('state') == 'succeeded' and r.get('local_owner_scope') == owner_binding
            and type(r.get('payload_digest')) is str and _HEX.fullmatch(r['payload_digest'])
            and _archive_result_valid(r.get('result'))]
        pairs = [(b, r) for b in batches for r in receipts if r.get('batch_id') == b['id']
            and r['result']['lead_ids'] == b['lead_ids'] and r['result']['accepted_count'] == b['source_count']]
        if not pairs:
            _fail('缺少本人原归档批和成功回执，不能手填客户归属')
        batch, receipt = min(pairs, key=lambda p: (p[0]['id'], p[1]['id']))
        return {'schema': 'local_owner_acquisition_v1', 'local_instance_id': self.instance_id,
            'actor_digest': digest(_identity(user, _ACTOR)), 'account_id': account_id,
            'account_digest': digest(_identity(account, _ACCOUNT)), 'lead_id': lead_id,
            'source_id': source['id'], 'source_digest': digest([_identity(lead, _LEAD), source]),
            'batch_id': batch['id'], 'batch_digest': digest(batch),
            'receipt_id': receipt['id'], 'receipt_digest': digest(receipt),
            'privacy_redacted': source['privacy_redacted']}

    def _source_locator(self,token,data):
        if (type(data) is not dict or set(data)!={'account_id','lead_id'}
                or type(data['account_id']) is not str or not _UID.fullmatch(data['account_id'])
                or type(data['lead_id']) is not str or not _HEX.fullmatch(data['lead_id'])):
            _fail('原笔记位置仅接受当前选中的本人账号与已保存来源')
        user=self._current(token)
        with self.core.store.connect() as db:
            db.execute('BEGIN')
            account,lead,source=self._load_source_identity(db,user,data['account_id'],data['lead_id'],_token=token)
            post_id,url=archive_safe_url(account['platform'],lead.get('note_url') or lead.get('url'))
            if post_id!=source['post_id']:
                _fail('原笔记位置与已保存来源不一致')
            fresh=self._current(token)
            if fresh!=user or self._load_source_identity(db,fresh,data['account_id'],data['lead_id'],_token=token)!=(account,lead,source):
                _fail('本人账号或当前来源已变化，请重新选中核对')
            # This is a canonical post locator only. It lends no platform,
            # customer identity, contact or original comment routing grant.
            return {'purpose':'owner_source_locator_get','account_id':account['id'],'lead_id':lead['id'],
                'canonical_url':url,'read_only':True,'mutation_committed':False,
                'platform_requests_started':False,'platform_reply_verified':False,'auto_retry':False}

    @contextmanager
    def _call(self, token, action, account_id, lead_id, *, _stored_binding=None,
            _shared_db=None, _package_context=None):
        if getattr(self._tls, 'frame', None) is not None:
            _fail('本机业务不能嵌套或借平台执行范围')
        if getattr(self.workspace._tls, 'call', None) is not None or getattr(self.archive._scope._metadata, 'call', None) is not None:
            _fail('本机业务不能借用平台或归档执行范围')
        if (self.workspace._douyin is not None and getattr(self.workspace._douyin._tls,'frame',None) is not None
                or self.workspace._douyin_archive is not None and getattr(self.workspace._douyin_archive.scope._tls,'frame',None) is not None):
            _fail('本机客户整理不能借用抖音平台或归档执行范围')
        user = self._current(token)
        if _package_context is not None or _shared_db is not None:
            from .owner_contact_handoff_package import _validate_package_context
            _validate_package_context(_package_context, self, _shared_db)
            if action != 'contact_read':
                _fail('资料包内部核对不能扩大原联系方式动作')
            binding = self._load_source(_shared_db, user, account_id, lead_id, _stored_binding=_stored_binding,_token=token)
        else:
            with self.core.store.connect() as db:
                binding = self._load_source(db, user, account_id, lead_id, _stored_binding=_stored_binding,_token=token)
        frame = {'seal': _SEAL, 'token': token, 'action': action, 'account_id': account_id,
            'lead_id': lead_id, 'user': deepcopy(user), 'binding': binding, 'stored_binding': _stored_binding}
        if _package_context is not None:
            frame['package_context'] = _package_context
        self._tls.frame = frame
        try:
            self._scope.check(user)
            yield user
        finally:
            if getattr(self._tls, 'frame', None) is frame:
                del self._tls.frame

    def _fact(self, data, user):
        key = data['idempotency_key']
        ident = digest([self.tenant, self.owner, self.instance_id, key])
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._scope.check(user, db)
            record = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                'lead_id': self._scope._frame()['lead_id'], 'kind': data['kind'], 'tone': data['tone'],
                'evidence_reference': data['evidence_reference'], 'created_at': time.time(),
                'status': data['kind'], 'owner_acquisition_scope': self._scope.binding(db)}
            record['evidence_digest'] = digest(record)
            audit = {'id': uuid4().hex, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                'actor_id': user['id'], 'action': 'owner_manual_contact_record', 'fact_id': ident,
                'lead_id': record['lead_id'], 'kind': record['kind'], 'occurred_at': time.time()}
            for entity, value in ((FACTS, record), ('audit', audit)):
                db.execute('INSERT INTO records VALUES(?,?,?,?)',
                    (entity, value['id'], self.tenant, json.dumps(value, ensure_ascii=False)))
            self._scope.check(user, db, record)
            result = self._fact_view(record)
        return result

    def _fact_view(self, record):
        self._scope.check(record=record)
        original = {k: v for k, v in record.items() if k != 'evidence_digest'}
        if record.get('evidence_digest') != digest(original) or record.get('kind') not in KINDS or record.get('tone') not in TONES:
            _fail('原人工事实需核对')
        return {k: record[k] for k in ('id', 'lead_id', 'kind', 'tone', 'evidence_reference',
            'evidence_digest', 'status', 'created_at')} | dict(_LOCAL, evidence_source='operator_recorded')

    def _history_finish_digest(self, db, receipt):
        """Same original finish transaction; hash the actually saved canonical metadata."""
        binding = receipt['owner_acquisition_scope']
        result = receipt.get('result') or {}
        if receipt['original_action'] == 'contact_create':
            reference = result.get('contact_reference')
            if type(reference) is not str or not re.fullmatch(r'contact:[a-f0-9]{32}', reference):
                _fail('原保护存储引用未确认')
            record = _row(db, 'acquisition_contacts', reference[8:], self.tenant)
            fields = ('lead_id', 'recipient_id', 'purpose', 'consent', 'revision')
            if not record or result.get('id') != record['id'] or result.get('revision') != record.get('revision'):
                _fail('原保护存储与回执未确认')
        else:
            ident = result.get('id')
            if type(ident) is not str or not _UID.fullmatch(ident):
                _fail('原草稿引用未确认')
            record = _row(db, 'acquisition_handoffs', ident, self.tenant)
            fields = ('lead_id', 'recipient_id', 'purpose', 'consent', 'contact_reference', 'revision')
            if not record or result.get('revision') != record.get('revision') or record.get('status') != 'draft':
                _fail('原草稿与回执未确认')
        if (record.get('cloud_owner') != self.owner or record.get('lead_id') != binding['lead_id']
                or record.get('owner_acquisition_scope') != binding
                or type(record.get('consent')) is not dict or record['consent'].get('status') != 'granted'
                or record.get('recipient_id') != (result.get('recipient_id') if receipt['original_action'] == 'contact_create'
                    else result.get('item', {}).get('recipient_id')) or record.get('revision') != 1):
            _fail('原保存同意范围未确认')
        contact_revision = record['revision']
        if receipt['original_action'] == 'handoff_create':
            reference = record.get('contact_reference')
            if type(reference) is not str or not re.fullmatch(r'contact:[a-f0-9]{32}', reference):
                _fail('草稿原保护引用未确认')
            contact = _row(db, 'acquisition_contacts', reference[8:], self.tenant)
            if (not contact or contact.get('owner_acquisition_scope') != binding
                    or contact.get('revision') != 1 or any(contact.get(k) != record.get(k)
                    for k in ('lead_id', 'recipient_id', 'purpose'))
                    or contact.get('consent') != {k: record['consent'].get(k)
                    for k in ('status', 'evidence_reference', 'notice_version')}
                    or set(record['consent']) != {'status', 'evidence_reference', 'notice_version',
                        'evidence_source', 'independently_verified'}
                    or record['consent']['evidence_source'] != 'operator_recorded'
                    or record['consent']['independently_verified'] is not False):
                _fail('草稿与原保护同意未确认')
            contact_revision = contact['revision']
        # No request payload, phone, WeChat, mask or encrypted bytes enter this digest.
        return digest({'source_identity_digest': digest(binding), 'contact_revision': contact_revision,
            'metadata': {key: record.get(key) for key in fields}})

    def _history_projection(self, db, user, record):
        """Read an existing protected receipt; no status(), tombstone or platform call."""
        action, key, ident = record.get('original_action'), record.get('idempotency_key'), record.get('id')
        if (record.get('tenant_id') != self.tenant or record.get('cloud_owner') != self.owner
                or action not in _WRITES or type(key) is not str or not _KEY.fullmatch(key)
                or type(ident) is not str or not _HEX.fullmatch(ident)
                or ident != digest([self.tenant, self.owner, action, key])
                or record.get('state') not in ('started', 'unknown', 'succeeded', 'rejected', 'cancelled')
                or any(type(record.get(k)) not in (int, float) or not math.isfinite(record[k])
                       or record[k] < 0 for k in ('created_at', 'updated_at'))):
            return None
        # This shell is only an honest original number/state, never a contact grant.
        item = {'operation_id': ident, 'operation_action': action, 'idempotency_key': key,
            'state': record['state'], 'created_at': record['created_at'], 'updated_at': record['updated_at'],
            'account_id': None, 'lead_id': None, 'needs_review': True,
            'result': None, 'current_authorization': 'unavailable'}
        base_fields = {'id', 'tenant_id', 'cloud_owner', 'original_action', 'idempotency_key',
            'payload_digest', 'state', 'created_at', 'updated_at', 'owner_acquisition_scope'}
        allowed = base_fields | ({'result'} if record['state'] == 'succeeded' else set())
        if action in ('contact_create', 'handoff_create') and record['state'] == 'succeeded':
            allowed.add('owner_history_metadata_digest')
        if (not base_fields <= set(record) or set(record) - allowed
                or record['payload_digest'] is None and record['state'] != 'cancelled'
                or record['payload_digest'] is not None and (type(record['payload_digest']) is not str
                    or not _HEX.fullmatch(record['payload_digest']))
                or record['state'] == 'succeeded' and type(record.get('result')) is not dict):
            return item
        stored = record.get('owner_acquisition_scope')
        if (type(stored) is not dict or stored.get('schema') != 'local_owner_acquisition_v1'
                or stored.get('local_instance_id') != self.instance_id
                or stored.get('actor_digest') != digest(_identity(user, _ACTOR))):
            return item
        account_id, lead_id = stored.get('account_id'), stored.get('lead_id')
        if (type(account_id) is not str or not _UID.fullmatch(account_id)
                or type(lead_id) is not str or not _HEX.fullmatch(lead_id)):
            return item
        try:
            with self._call(self._tls.history['token'], 'owner_acquisition_history_detail', account_id,
                            lead_id, _stored_binding=stored) as current:
                receipts = _OwnerReceipts(self._scope)
                original = receipts._read(db, ident, action, key)
                if original != record:
                    _fail('原历史回执在查询期间已变化')
                view = receipts._view(original)
                result = view.get('result')
                authorization = 'not_applicable'
                if result is not None:
                    result, authorization = self._history_protected_result(db, original, result)
                self._scope.check(current, db, record)
                if result is not None:
                    fresh_result, fresh_authorization = self._history_protected_result(db, original, view.get('result'))
                    if fresh_result != result or fresh_authorization != authorization:
                        _fail('原同意在历史投影期间已变化，保留原编号核对')
                    self._scope.check(current, db, record)
                binding = self._scope._frame()['binding']
                item.update(account_id=account_id, lead_id=lead_id, needs_review=False,
                    result=result, current_authorization=authorization)
                source = {'id': lead_id, 'account_id': account_id, 'platform':_row(db,'accounts',account_id,self.tenant)['platform'],
                    'readonly_archive': True, 'can_reply': False,
                    'privacy_redacted': binding['privacy_redacted'], 'metadata_only': True}
                selection = {'schema': 'owner_acquisition_history_selection_v1', 'company_id': self.server.company['id'],
                    'actor_id': current['id'], 'instance_id': self.instance_id, 'operation_id': ident,
                    'account_id': account_id, 'lead_id': lead_id}
                return item, source, selection
        except (CoreError, OSError, ValueError, TypeError, KeyError):
            return item

    def _history_protected_result(self, db, receipt, result):
        """Only original protected fields; current contact values/masks are never read."""
        action = receipt['original_action']
        binding = receipt['owner_acquisition_scope']
        if action == 'owner_manual_contact_record':
            ident = digest([self.tenant, self.owner, self.instance_id, receipt['idempotency_key']])
            fact = _row(db, FACTS, ident, self.tenant)
            if (fact is None or fact.get('owner_acquisition_scope') != binding
                    or fact.get('cloud_owner') != self.owner or fact.get('lead_id') != binding['lead_id']
                    or fact.get('evidence_digest') != digest({k: v for k, v in fact.items() if k != 'evidence_digest'})
                    or fact.get('kind') not in KINDS or fact.get('tone') not in TONES
                    or result.get('id') != ident):
                _fail('原人工事实与保护回执不一致')
            return result, 'not_applicable'
        if action == 'handoff_create':
            draft_id = result.get('id')
            if type(draft_id) is not str or not _UID.fullmatch(draft_id):
                _fail('原草稿引用需核对')
            draft = _row(db, 'acquisition_handoffs', draft_id, self.tenant)
            if (draft is None or draft.get('cloud_owner') != self.owner or draft.get('lead_id') != binding['lead_id']
                    or draft.get('company_id') != self.server.company['id']
                    or draft.get('owner_acquisition_scope') != binding or draft.get('status') != 'draft'
                    or draft.get('revision') != result.get('revision') or draft.get('revision') != 1
                    or draft.get('recipient_id') != result.get('item', {}).get('recipient_id')):
                _fail('原本机草稿归属需核对')
            reference = draft.get('contact_reference')
            metadata = {k: draft.get(k) for k in ('lead_id', 'recipient_id', 'purpose', 'consent', 'contact_reference', 'revision')}
        else:
            reference = result.get('contact_reference')
            metadata = None
        if type(reference) is not str or not re.fullmatch(r'contact:[a-f0-9]{32}', reference):
            _fail('原联系方式引用需核对')
        contact = _row(db, 'acquisition_contacts', reference[8:], self.tenant)
        if (contact is None or contact.get('cloud_owner') != self.owner or contact.get('lead_id') != binding['lead_id']
                or contact.get('owner_acquisition_scope') != binding or type(contact.get('revision')) is not int
                or contact['revision'] < 1 or contact.get('storage_scope') != 'local_current_windows_user'):
            _fail('原联系人归属或存储范围需核对')
        consent = contact.get('consent')
        if (type(consent) is not dict or set(consent) != {'status', 'evidence_reference', 'notice_version'}
                or consent.get('status') not in ('granted', 'withdrawn')
                or type(consent.get('evidence_reference')) is not str
                or not re.fullmatch(r'consent:[a-f0-9]{32}', consent['evidence_reference'])
                or type(consent.get('notice_version')) is not str):
            _fail('原同意结构需核对')
        _safe_label(contact.get('recipient_id'), '原接收方', 80)
        _safe_label(contact.get('purpose'), '原用途', 100)
        _safe_label(consent['notice_version'], '原告知记录', 80)
        normalized = {k: contact.get(k) for k in ('lead_id', 'recipient_id', 'purpose', 'consent')}
        normalized['consent'] = {**consent, 'status': 'granted'}
        if action == 'contact_revoke':
            if (consent['status'] != 'withdrawn' or contact.get('encrypted_payload') != ''
                    or contact.get('revoked_at') is None or result.get('revision') != contact['revision']):
                _fail('原撤回状态需核对')
            return {k: v for k, v in result.items() if k != 'contact_reference'}, 'withdrawn'
        if metadata is None:
            metadata = normalized | {'revision': result.get('revision')}
            if result.get('revision') != 1 or result.get('recipient_id') != contact['recipient_id']:
                _fail('原联系人版本或接收方需核对')
        elif (any(metadata.get(k) != normalized.get(k) for k in ('lead_id', 'recipient_id', 'purpose'))
                or type(metadata.get('consent')) is not dict
                or set(metadata['consent']) != {'status', 'evidence_reference', 'notice_version',
                    'evidence_source', 'independently_verified'}
                or metadata['consent']['evidence_source'] != 'operator_recorded'
                or metadata['consent']['independently_verified'] is not False
                or {k: metadata['consent'].get(k) for k in normalized['consent']} != normalized['consent']):
            _fail('原草稿与当前同意范围需核对')
        withdrawn = consent['status'] == 'withdrawn'
        original_revision = contact['revision'] - 1 if withdrawn else contact['revision']
        expected = receipt.get('owner_history_metadata_digest')
        if (original_revision != 1 or type(expected) is not str or not _HEX.fullmatch(expected)
                or expected != digest({'source_identity_digest': digest(binding),
                    'contact_revision': original_revision, 'metadata': metadata})):
            _fail('原同意快照缺少或已变化，保留原号核对')
        if withdrawn:
            if (type(contact.get('revoked_at')) not in (int, float) or not math.isfinite(contact['revoked_at'])
                    or contact['revoked_at'] <= 0 or contact.get('encrypted_payload') != '' or contact['revision'] < 2):
                _fail('撤回事实或密文清理需核对')
            authorization = 'withdrawn'
        elif contact.get('revoked_at') is not None or not contact.get('encrypted_payload'):
            _fail('当前保护存储需核对')
        else:
            authorization = 'granted'
        # A historical ref says where a local record is, never that it may be used.
        return result, authorization

    def _history(self, token, action, data):
        if getattr(self._tls, 'history', None) is not None:
            _fail('历史查询不能嵌套或借用其他范围')
        user = self._current(token)
        if action == 'owner_acquisition_history_detail':
            if set(data) != {'operation_id'} or type(data['operation_id']) is not str or not _HEX.fullmatch(data['operation_id']):
                _fail('历史详情仅接受固定原回执编号')
        else:
            if (set(data) != {'filter', 'limit', 'cursor'} or type(data['filter']) is not str
                    or data['filter'] not in ('all', 'pending', 'finished')
                    or type(data['limit']) is not int or not 1 <= data['limit'] <= 50):
                _fail('历史页仅接受固定筛选和1至50条请求')
            cursor = data['cursor']
            if cursor is None:
                cutoff, after = time.time(), ''
            else:
                if (type(cursor) is not dict or set(cursor) != {'schema', 'cutoff', 'after'}
                        or cursor.get('schema') != 'owner_acquisition_cursor_v1'
                        or type(cursor.get('cutoff')) not in (int, float) or not math.isfinite(cursor['cutoff'])
                        or not 0 <= cursor['cutoff'] <= time.time()
                        or type(cursor.get('after')) is not str or not _HEX.fullmatch(cursor['after'])
                        or len(json.dumps(cursor, ensure_ascii=False)) > 256):
                    _fail('历史页游标无效；只按明确刷新界限查询，不提供权限')
                cutoff, after = cursor['cutoff'], cursor['after']
        frame = {'seal': _SEAL, 'token': token, 'user': deepcopy(user)}
        self._tls.history = frame
        try:
            with self.core.store.connect() as db:
                if action == 'owner_acquisition_history_detail':
                    record = _row(db, RECEIPT_ENTITY, data['operation_id'], self.tenant)
                    projected = self._history_projection(db, user, record) if record else None
                    if not isinstance(projected, tuple):
                        _fail('原回执或来源范围待核对，保留原数据；不提供联系方式或选择范围')
                    item, source, selection = projected
                    self._current(token)
                    return {'purpose': 'owner_acquisition_history_detail', 'operation': item,
                        'source': source, 'selection': selection, **_LOCAL}
                candidates = db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? AND id>? ORDER BY id LIMIT ?',
                    (RECEIPT_ENTITY, self.tenant, after, 200)).fetchall()
                items, review_count, last = [], 0, after
                examined = 0
                for row in candidates:
                    last = row['id']; examined += 1
                    try:
                        record = json.loads(row['body'])
                        if (type(record) is not dict or record.get('id') != last
                                or type(record.get('created_at')) not in (int, float)
                                or not math.isfinite(record['created_at']) or record['created_at'] > cutoff):
                            continue
                        projected = self._history_projection(db, user, record)
                    except (CoreError, ValueError, TypeError, KeyError):
                        review_count += 1; continue
                    if projected is None:
                        continue
                    item = projected[0] if isinstance(projected, tuple) else projected
                    if item['needs_review']:
                        review_count += 1
                    if data['filter'] == 'pending' and not (item['state'] in ('started', 'unknown') or item['needs_review']):
                        continue
                    if data['filter'] == 'finished' and (item['state'] in ('started', 'unknown') or item['needs_review']):
                        continue
                    items.append(item)
                    if len(items) == data['limit']:
                        break
                self._current(token)
                more = examined < len(candidates) or len(candidates) == 200
                next_cursor = {'schema': 'owner_acquisition_cursor_v1', 'cutoff': cutoff, 'after': last} if more else None
                return {'purpose': 'owner_acquisition_history_page', 'items': items,
                    'returned_count': len(items), 'scanned_count': len(candidates),
                    'needs_review_count': review_count, 'filter': data['filter'],
                    'page': {'has_more': more, 'next_cursor': next_cursor, 'cutoff': cutoff,
                             'scope': 'this_instance_owner', 'snapshot_verified': False}, **_LOCAL}
        finally:
            if getattr(self._tls, 'history', None) is frame:
                del self._tls.history


    def _processing_manual_kind(self, db, token, user, record, item):
        """The durable protected receipt omits kind; verify its original fact anew."""
        if item['operation_action'] != 'owner_manual_contact_record' or item['state'] != 'succeeded':
            return None
        stored = record['owner_acquisition_scope']
        with self._call(token, 'owner_acquisition_history_detail', stored['account_id'],
                        stored['lead_id'], _stored_binding=stored) as current:
            original = _OwnerReceipts(self._scope)._read(db, item['operation_id'],
                item['operation_action'], item['idempotency_key'])
            if original != record:
                _fail('原人工事实回执在核对期间已变化')
            ident = digest([self.tenant, self.owner, self.instance_id, item['idempotency_key']])
            fact = _row(db, FACTS, ident, self.tenant)
            if (fact is None or fact.get('cloud_owner') != self.owner
                    or fact.get('lead_id') != stored['lead_id']
                    or fact.get('owner_acquisition_scope') != stored):
                _fail('原人工事实归属待核对')
            view = self._fact_view(fact)
            if (view['status'] != view['kind'] or item['result'].get('status') != view['kind']
                    or item['result'].get('id') != ident):
                _fail('原人工事实类别与保存状态不一致')
            self._scope.check(current, db, record)
            return view['kind']

    def _processing_detail(self, token, data):
        """Pair-scoped, bounded receipt seek. No writes, status tombstone or contact value."""
        if (set(data) != {'account_id', 'lead_id', 'limit', 'cursor'}
                or type(data['account_id']) is not str or not _UID.fullmatch(data['account_id'])
                or type(data['lead_id']) is not str or not _HEX.fullmatch(data['lead_id'])
                or type(data['limit']) is not int or not 1 <= data['limit'] <= 50):
            _fail('来源处理详情仅接受原账号、来源和1至50条请求')
        account_id, lead_id = data['account_id'], data['lead_id']
        cursor = data['cursor']
        if cursor is None:
            cutoff, after = time.time(), ''
        else:
            if (type(cursor) is not dict
                    or set(cursor) != {'schema', 'account_id', 'lead_id', 'cutoff', 'after'}
                    or cursor.get('schema') != 'owner_source_processing_cursor_v1'
                    or cursor.get('account_id') != account_id or cursor.get('lead_id') != lead_id
                    or type(cursor.get('cutoff')) not in (int, float)
                    or not math.isfinite(cursor['cutoff']) or not 0 <= cursor['cutoff'] <= time.time()
                    or type(cursor.get('after')) is not str or not _HEX.fullmatch(cursor['after'])
                    or len(json.dumps(cursor, ensure_ascii=False)) > 640):
                _fail('来源处理详情游标或原来源范围无效')
            cutoff, after = cursor['cutoff'], cursor['after']
        if (getattr(self._tls, 'history', None) is not None
                or getattr(self._tls, 'frame', None) is not None):
            _fail('来源处理详情不能借用正在执行的业务范围')
        user = self._current(token)
        # _history_projection enters the original _call itself; do not nest it.
        frame = {'seal': _SEAL, 'token': token, 'user': deepcopy(user)}
        self._tls.history = frame
        try:
            with self.core.store.connect() as db:
                binding = self._load_source(db, user, account_id, lead_id,_token=token)
                source = {'id': lead_id, 'account_id': account_id, 'platform':_row(db,'accounts',account_id,self.tenant)['platform'],
                    'readonly_archive': True, 'can_reply': False,
                    'privacy_redacted': binding['privacy_redacted'], 'metadata_only': True}
                candidates = db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? AND id>? ORDER BY id LIMIT ?',
                    (RECEIPT_ENTITY, self.tenant, after, 200)).fetchall()
                items, review_count, last, examined = [], 0, after, 0
                for row in candidates:
                    last = row['id']; examined += 1
                    try:
                        record = json.loads(row['body'])
                    except (ValueError, TypeError):
                        continue
                    if type(record) is not dict:
                        continue
                    stored = record.get('owner_acquisition_scope')
                    # Raw pair is only a routing hint. It cannot make a record visible.
                    if (type(stored) is not dict or stored.get('account_id') != account_id
                            or stored.get('lead_id') != lead_id
                            or record.get('tenant_id') != self.tenant or record.get('cloud_owner') != self.owner
                            or stored.get('schema') != 'local_owner_acquisition_v1'
                            or stored.get('local_instance_id') != self.instance_id
                            or stored.get('actor_digest') != digest(_identity(user, _ACTOR))):
                        continue
                    if (record.get('id') != last or type(record.get('created_at')) not in (int, float)
                            or not math.isfinite(record['created_at']) or record['created_at'] < 0):
                        review_count += 1; continue
                    if record['created_at'] > cutoff:
                        continue
                    projected = self._history_projection(db, user, record)
                    if (not isinstance(projected, tuple) or projected[1] != source
                            or projected[0]['account_id'] != account_id or projected[0]['lead_id'] != lead_id
                            or record.get('owner_acquisition_scope') != binding):
                        review_count += 1; continue
                    item = projected[0]
                    try:
                        kind = self._processing_manual_kind(db, token, user, record, item)
                    except (CoreError, OSError, ValueError, TypeError, KeyError):
                        review_count += 1; continue
                    items.append({**item, 'manual_kind': kind})
                    if len(items) == data['limit']:
                        break
                fresh = self._current(token)
                if (digest(_identity(fresh, _ACTOR)) != digest(_identity(user, _ACTOR))
                        or self._load_source(db, fresh, account_id, lead_id, _stored_binding=binding,_token=token) != binding):
                    _fail('本人或原来源在详情核对期间已变化')
                more = examined < len(candidates) or len(candidates) == 200
                next_cursor = {'schema': 'owner_source_processing_cursor_v1', 'account_id': account_id,
                    'lead_id': lead_id, 'cutoff': cutoff, 'after': last} if more else None
                return {'purpose': 'owner_source_processing_detail_v1', 'source': source, 'items': items,
                    'returned_count': len(items), 'scanned_count': len(candidates),
                    'needs_review_count': review_count,
                    'page': {'has_more': more, 'next_cursor': next_cursor, 'cutoff': cutoff,
                        'scope': 'this_instance_owner', 'snapshot_verified': False}, **_LOCAL}
        finally:
            if getattr(self._tls, 'history', None) is frame:
                del self._tls.history

    def execute(self, token, action, data):
        if action in ('owner_company_receipt_login', 'owner_company_receipt_scope_get',
                'owner_company_receipt_register', 'owner_company_receipt_consent_sync',
                'owner_company_receipt_submit', 'owner_company_receipt_withdraw',
                'owner_company_receipt_operation_status', 'owner_company_receipt_channel_get',
                'owner_company_receipt_business_get', 'owner_company_receipt_logout'):
            from .owner_contact_handoff_package import OwnerContactHandoffPackages
            from .owner_company_receipt_bridge import OwnerCompanyReceiptBridge
            if not self.workspace._lock.acquire(timeout=5):
                _fail('当前公司原号操作忙，请保留编号')
            try:
                with self.core.lock:
                    self._current(token)
                    if self._packages is None:
                        self._packages = OwnerContactHandoffPackages(self)
                    if self._company_receipts is None:
                        self._company_receipts = OwnerCompanyReceiptBridge(self)
                    bridge = self._company_receipts
            finally:
                self.workspace._lock.release()
            # Company I/O never holds the original workspace/core/SQLite locks.
            from .owner_company_receipt_bridge import public_owner_channels
            from .employee_workspace import public
            result = bridge.execute(token, action, data)
            try:
                return public(public_owner_channels(result, receiver=False))
            except CoreError:
                raise OwnerAcquisitionError('公司原包结果待核对，请保留原编号，暂勿重发',
                    mutation_committed=None) from None
        if action in ('owner_handoff_followup_list', 'owner_handoff_followup_detail',
                'owner_handoff_delivery_record', 'owner_handoff_feedback_record',
                'owner_handoff_followup_operation_status'):
            from .owner_contact_handoff_package import OwnerContactHandoffPackages
            from .owner_handoff_followup import OwnerHandoffFollowup
            # Preserve the original workspace -> core order continuously through
            # original receipt transactions and their same-DB proof/slot bridge.
            with self.workspace._lock, self.core.lock:
                self._current(token)
                if self._packages is None:
                    self._packages = OwnerContactHandoffPackages(self)
                if self._followups is None:
                    self._followups = OwnerHandoffFollowup(self)
                return self._followups.execute(token, action, data)
        if type(data) is not dict:
            _fail('不支持此本机业务动作')
        if action in ('owner_handoff_package_create', 'owner_handoff_package_status', 'owner_handoff_package_download'):
            from .owner_contact_handoff_package import OwnerContactHandoffPackages
            # Construction only; package locking is bounded and uses the original
            # workspace -> core -> SQLite order, not a broad outer write lock.
            if not self.workspace._lock.acquire(timeout=5.0):
                _fail('当前本机操作忙，请保留原资料包编号')
            try:
                if self._packages is None:
                    self._packages = OwnerContactHandoffPackages(self)
            finally:
                self.workspace._lock.release()
            return self._packages.execute(token, action, data)
        if action in self.HISTORY_ACTIONS:
            with self.workspace._lock, self.core.lock:
                if action == 'owner_source_locator_get':
                    return self._source_locator(token,data)
                if action == 'owner_source_processing_detail':
                    return self._processing_detail(token, data)
                return self._history(token, action, data)
        if action not in self.ACTIONS:
            _fail('不支持此本机业务动作')
        common = {'account_id', 'lead_id'}
        fields = {'owner_manual_contact_record': {'kind', 'tone', 'evidence_reference', 'confirmed', 'idempotency_key'},
            'owner_manual_contact_get': {'idempotency_key'},
            'contact_create': {'recipient_id', 'purpose', 'consent', 'phone', 'wechat', 'voluntarily_provided', 'idempotency_key'},
            'contact_read': {'contact_reference', 'reveal'},
            'contact_revoke': {'contact_reference', 'expected_revision', 'idempotency_key'},
            'handoff_create': {'recipient_id', 'purpose', 'consent', 'contact_reference', 'idempotency_key'},
            'handoff_list': {'offset', 'limit'}, 'handoff_detail': {'id'},
            'owner_acquisition_operation_status': {'operation_action', 'idempotency_key'}}[action]
        required = common | fields
        optional = {'phone', 'wechat'} if action == 'contact_create' else {'reveal'} if action == 'contact_read' else {'offset', 'limit'} if action == 'handoff_list' else set()
        if (set(data) - required or not (required - optional) <= set(data)
                or type(data.get('account_id')) is not str or not _UID.fullmatch(data['account_id'])
                or type(data.get('lead_id')) is not str or not _HEX.fullmatch(data['lead_id'])):
            _fail('本机业务仅接受当前原账号和原来源的固定参数')
        with self.workspace._lock, self.core.lock, self._call(token, action, data['account_id'], data['lead_id']) as user:
            if action in _WRITES and action != 'contact_revoke' and self._scope._frame()['binding']['privacy_redacted']:
                _fail('原来源已脱敏，新的人工事实、留资和草稿需先核对隐私')
            body = deepcopy({k: v for k, v in data.items() if k not in common})
            receipts = _OwnerReceipts(self._scope)
            if action in ('owner_acquisition_operation_status', 'owner_manual_contact_get'):
                operation = body.get('operation_action', 'owner_manual_contact_record')
                outcome = receipts.status(operation, body['idempotency_key'])
                if action == 'owner_manual_contact_get' and outcome['state'] == 'succeeded':
                    ident = digest([self.tenant, self.owner, self.instance_id, body['idempotency_key']])
                    with self.core.store.connect() as db:
                        record = _row(db, FACTS, ident, self.tenant)
                    if record is None:
                        raise OwnerAcquisitionError('原人工事实保存结果需核对', mutation_committed=None)
                    outcome['fact'] = self._fact_view(record)
                self._scope.check(user)
                return outcome | _LOCAL
            if action == 'owner_manual_contact_record':
                if (body['kind'] not in KINDS or body['tone'] not in TONES or body['confirmed'] is not True
                        or type(body['evidence_reference']) is not str
                        or not re.fullmatch(r'evidence:[a-f0-9]{32}', body['evidence_reference'])):
                    _fail('人工事实需明确口吻、动作和原证据引用；不是平台发送证明')
                service = lambda: self._fact(body, user)
            else:
                from .acquisition_contacts import AcquisitionContacts
                from .acquisition_operations import AcquisitionOperations
                if action in ('contact_create', 'handoff_create'):
                    for field, limit in (('recipient_id', 80), ('purpose', 100)):
                        body[field] = _safe_label(body[field], field, limit)
                    consent = body.get('consent')
                    if type(consent) is not dict or set(consent) != {'status', 'evidence_reference', 'notice_version'}:
                        _fail('请明确记录客户同意、告知版本、接收方和用途')
                    _safe_label(consent['notice_version'], '告知版本', 80)
                    if type(consent['evidence_reference']) is not str or not re.fullmatch(r'consent:[a-f0-9]{32}', consent['evidence_reference']):
                        _fail('同意引用不是客户签名，需保留原人工记录')
                if action == 'contact_create':
                    # A syntactically ordinary label can still equal a supplied
                    # WeChat ID; keep all supplied contact values out of metadata.
                    metadata = json.dumps({k: body[k] for k in ('recipient_id', 'purpose', 'consent', 'idempotency_key')}, ensure_ascii=False)
                    checked = unicodedata.normalize('NFKC', metadata).casefold()
                    for value in (body.get('phone', ''), body.get('wechat', '')):
                        if type(value) is str and value.strip() and unicodedata.normalize('NFKC', value.strip()).casefold() in checked:
                            _fail('手机号或微信不能出现在普通业务记录中')
                    if body.pop('voluntarily_provided') is not True:
                        _fail('仅保存客户主动提供且明确同意的联系方式')
                    body['lead_id'] = data['lead_id']
                if action in ('contact_read', 'contact_revoke'):
                    if type(body.get('contact_reference')) is not str or not re.fullmatch(r'contact:[a-f0-9]{32}', body['contact_reference']):
                        _fail('请使用原受保护联系方式引用')
                if action.startswith('contact_'):
                    contacts = AcquisitionContacts(self.core, self.tenant, self.owner, self.server.company,
                        owner_scope=self._scope)
                    params = {k: v for k, v in body.items() if not (action == 'contact_revoke' and k == 'idempotency_key')}
                    service = lambda: contacts.execute(action, params, user)
                else:
                    operations = AcquisitionOperations(self.core, self.tenant, self.owner, self.server.company,
                        owner_scope=self._scope)
                    if action == 'handoff_create':
                        body['lead_id'] = data['lead_id']
                    elif action == 'handoff_list':
                        body['customer_lead_id'] = data['lead_id']
                    service = lambda: operations.execute(action, body, user)
            if action not in _WRITES:
                result = service()
                self._scope.check(user)
                return result | _LOCAL
            begun = receipts.begin(action, body.get('idempotency_key'), body)
            if not begun['should_execute']:
                return begun | _LOCAL
            try:
                result = service()
            except Exception as error:
                try:
                    outcome = receipts.fail(error)
                except Exception:
                    raise OwnerAcquisitionError('原本机操作结果未知，请只核对原编号', mutation_committed=None) from None
                if outcome['mutation_committed'] is False:
                    raise error
                raise OwnerAcquisitionError('原本机操作结果未知，请只核对原编号', mutation_committed=None) from None
            try:
                outcome = receipts.finish(result)
            except Exception:
                # Do not fail a finished business write as though it rolled back.
                raise OwnerAcquisitionError('原本机回执保存结果未知，请只核对原编号', mutation_committed=None) from None
            return {'operation': outcome, 'result': result, **_LOCAL}
