"""Bounded, value-free display field diagnostics for successful XHS reads."""

import json
import os
import tempfile
from collections import deque
from pathlib import Path


MAX_SAMPLE = 32
MAX_QUEUE = 32
MAX_DEPTH = 2
MAX_REPORT_BYTES = 8192
FILES = {'search': 'xhs-display-search.json',
         'comments': 'xhs-display-comments.json'}

# Static paths only. Neither unrecognized keys nor any source values are saved.
SEARCH_PATHS = {
    'note_card.user.user_id': 'id',
    'note_card.user.id': 'id',
    'note_card.user.uid': 'id',
    'note_card.user.avatar': 'image',
    'note_card.user.image': 'image',
    'note_card.user.avatar_url': 'image',
    'note_card.user.avatar.url_default': 'image',
    'note_card.user.image.url_default': 'image',
    'note_card.cover': 'image',
    'note_card.cover.url_default': 'image',
    'note_card.cover.info_list.0.url': 'image',
    'note_card.image_list.0': 'image',
    'note_card.image_list.0.url_default': 'image',
    'note_card.image_list.0.info_list.0.url': 'image',
}
COMMENT_PATHS = {
    'user_info.user_id': 'id',
    'user_info.id': 'id',
    'user_info.uid': 'id',
    'user_info.avatar': 'image',
    'user_info.image': 'image',
    'user_info.avatar_url': 'image',
    'user_info.avatar.url_default': 'image',
    'user_info.image.url_default': 'image',
    'user_info.image.info_list.0.url': 'image',
}
_MISSING = object()


def _type(value):
    if value is None:
        return 'null'
    if isinstance(value, bool):
        return 'bool'
    if isinstance(value, str):
        return 'string'
    if isinstance(value, (int, float)):
        return 'number'
    if isinstance(value, dict):
        return 'object'
    if isinstance(value, list):
        return 'array'
    return 'other'


def _get(row, path):
    value = row
    for key in path.split('.'):
        if isinstance(value, dict):
            value = value.get(key, _MISSING)
        elif isinstance(value, list) and key == '0' and value:
            value = value[0]
        else:
            return _MISSING
        if value is _MISSING:
            return _MISSING
    return value


def _usable(value, kind, approve_image):
    if kind == 'image':
        return bool(approve_image(value))
    return isinstance(value, str) and bool(value.strip()) and len(value) <= 256


def _raw_rows(kind, payload):
    data = payload.get('data', payload) if isinstance(payload, dict) else payload
    field = 'items' if kind == 'search' else 'comments'
    roots = data.get(field) if isinstance(data, dict) else (data if kind == 'search' else None)
    if not isinstance(roots, list):
        return [], False
    if kind == 'search':
        return [row for row in roots[:MAX_SAMPLE] if isinstance(row, dict)], True
    queue = deque((row, 0) for row in roots[:MAX_QUEUE] if isinstance(row, dict))
    rows = []
    while queue and len(rows) < MAX_SAMPLE:
        row, depth = queue.popleft()
        rows.append(row)
        if depth >= MAX_DEPTH:
            continue
        children = row.get('sub_comments')
        if isinstance(children, list):
            room = MAX_QUEUE - len(queue) - len(rows)
            if room > 0:
                queue.extend((child, depth + 1) for child in children[:min(room, 2)]
                             if isinstance(child, dict))
    return rows, True


def build_report(kind, payload, mapped, mapping_status, approve_image):
    if kind not in FILES or mapping_status not in ('mapped', 'unrecognized'):
        raise ValueError('Unsupported diagnostic category')
    rows, recognized = _raw_rows(kind, payload)
    paths = SEARCH_PATHS if kind == 'search' else COMMENT_PATHS
    fields = {}
    for path, value_kind in paths.items():
        stat = {'present': 0, 'nonempty': 0, 'usable': 0, 'types': {}}
        for row in rows:
            value = _get(row, path)
            if value is _MISSING:
                continue
            stat['present'] += 1
            shape = _type(value)
            stat['types'][shape] = stat['types'].get(shape, 0) + 1
            if value not in (None, '', [], {}):
                stat['nonempty'] += 1
            if _usable(value, value_kind, approve_image):
                stat['usable'] += 1
        fields[path] = stat
    mapped_fields = ('author_id', 'author_avatar_url', 'cover_url') if kind == 'search' else ('author_id', 'author_avatar_url')
    mapped_counts = {field: 0 for field in mapped_fields}
    mapped_rows = mapped[:MAX_SAMPLE] if isinstance(mapped, list) else []
    for row in mapped_rows:
        if not isinstance(row, dict):
            continue
        for field in mapped_fields:
            if field.endswith('_url'):
                mapped_counts[field] += bool(approve_image(row.get(field)))
            else:
                mapped_counts[field] += isinstance(row.get(field), str) and bool(row[field].strip())
    return {'schema': 'xhs-display-v1', 'kind': kind,
            'mapping_status': mapping_status, 'raw_shape_recognized': recognized,
            'raw_sampled': len(rows), 'mapped_sampled': len(mapped_rows),
            'fields': fields, 'mapped_usable': mapped_counts}


def record_report(account_dir, kind, payload, mapped, mapping_status, approve_image):
    if kind not in FILES or not account_dir:
        return False
    root = Path(account_dir)
    if root.is_symlink() or not root.is_dir():
        return False
    report = build_report(kind, payload, mapped, mapping_status, approve_image)
    body = json.dumps(report, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    if len(body) > MAX_REPORT_BYTES:
        return False
    target = root / FILES[kind]
    if target.is_symlink():
        return False
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=root, prefix='.xhs-display-', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
        return True
    finally:
        if temporary and temporary.exists():
            temporary.unlink()
