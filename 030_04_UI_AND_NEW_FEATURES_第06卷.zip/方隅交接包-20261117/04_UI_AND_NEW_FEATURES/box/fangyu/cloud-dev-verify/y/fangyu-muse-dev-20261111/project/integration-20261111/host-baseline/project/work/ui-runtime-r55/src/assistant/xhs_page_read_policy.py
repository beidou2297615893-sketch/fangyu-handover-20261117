"""App-owned review for one source/internal, natural-page read route.

The fixed review is code-reviewed material, never a request/company switch.
Inventory/loaded provenance are separate: this grants the narrowly defined
use only; Native owner still proves its Job, owner, loaded origins and vacancy.
It makes no claim that every in-memory native byte has been verified.
"""
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sys
import threading
import time


_SEAL = object()
_REVIEW_SHA = 'D7A271E697179D4EF2656B1773C639637159E3990E3148C84F23238D3FE317CB'
_ROUTE = 'natural_page_v1'
_USE = 'internal_self_use_read'
_TASK_ACTIONS = frozenset(('task_run', 'task_resume', 'continuous_start', 'continuous_resume'))
_CORE_ACTIONS = frozenset(('run_task', 'run_task_sequence', 'resume_task',
                           'continuous_start', 'continuous_resume'))
_CALL_CORE_ACTIONS = {'task_run': frozenset(('run_task', 'run_task_sequence')),
                     'task_resume': frozenset(('resume_task', 'run_task_sequence')),
                     'continuous_start': frozenset(('continuous_start',)),
                     'continuous_resume': frozenset(('continuous_resume',)),
                     'continuous_batch': frozenset(('run_task',))}
_ROLES = frozenset(('source', 'dependency', 'native_runtime', 'managed_runtime', 'webview_runtime'))
_KNOWN_RUNTIME = frozenset(('xiaohongshu_automation', 'cli_source_sha256',
                           'release_approved', 'platform_qa_device_id'))


class PageReadReviewRequired(ValueError):
    def __init__(self):
        super().__init__('page_component_review_unavailable')


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest().upper()


def _path(value):
    from .owned_xhs_native.runtime_materials import _checked_path
    if not isinstance(value, str) or not value or not Path(value).is_absolute():
        raise PageReadReviewRequired()
    return _checked_path(value)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


@dataclass(frozen=True, slots=True, repr=False)
class _PageReadDecision:
    seal: object
    policy: object
    revision: str
    materials: tuple
    licenses: tuple
    binding: str
    route: str = _ROUTE
    usage_scope: str = _USE
    customer: object = None

    @property
    def expected_materials(self):
        return self.materials

    def _current(self):
        if self.customer is not None:
            from .customer_natural_materials import _NaturalMaterials
            if self.seal is not _SEAL or type(self.policy) is not XhsPageReadPolicy or type(self.customer) is not _NaturalMaterials:
                raise PageReadReviewRequired()
            self.customer.check(self)
            return
        if (self.seal is not _SEAL or type(self.policy) is not XhsPageReadPolicy
                or self.policy._decision is not self
                or (self.route,self.usage_scope) not in ((_ROUTE,_USE),('guarded_cli_v1','customer_distribution_read'))
                or self.policy._snapshot() != self.binding):
            raise PageReadReviewRequired()
        # Large libraries were hashed during trusted construction; Native
        # creation holds deny-write/delete handles and rehashes before ready.
        # Every call still rechecks the fixed review and this small carrier.
        self.policy._verify_revision(self)

    def check(self, scope, creation_spec, execution_context):
        from .xhs_batch_scope import _BatchScope
        from .xhs_app_context import _AppExecutionContext
        from xhs_page_window import BridgeSpec
        self._current()
        if self.customer is not None:self.customer.check_execution()
        if self.route != _ROUTE:raise PageReadReviewRequired()
        server = self.policy.server
        if (type(scope) is not _BatchScope or type(execution_context) is not _AppExecutionContext
                or scope.app_context is not execution_context or scope.runtime is not server.xhs_page_runtime
                or scope.runtime.core is not server.core or type(creation_spec) is not BridgeSpec
                or creation_spec.read_mode != 'natural' or creation_spec.tenant_id != scope.tenant
                or creation_spec.account_id != scope.account_id
                or creation_spec.profile_dir != scope.root / 'xhs-browser-profile'):
            raise PageReadReviewRequired()
        if current_read_decision(server.core) is not self:
            raise PageReadReviewRequired()
        execution_context.check()
        account = server.core._get('accounts', scope.account_id, scope.tenant)
        if creation_spec.bound_uid != str(account.get('platform_uid') or ''):
            raise PageReadReviewRequired()
        scope.check()

    def check_materials(self, facts):
        """Match owner-collected origins; child approval/proof booleans are ignored."""
        self._current()
        if self.customer is not None:
            self.customer.check_loaded(self,facts)
            return
        if self.route != _ROUTE:raise PageReadReviewRequired()
        if not isinstance(facts, dict) or facts.get('contract') != 'page_ready_sources_v1':
            raise PageReadReviewRequired()
        bound = facts.get('bound_materials')
        if not isinstance(bound, (tuple, list)) or len(bound) != len(self.materials):
            raise PageReadReviewRequired()
        if tuple(tuple(item[:3]) for item in bound if isinstance(item, (tuple, list)) and len(item) == 4) != self.materials:
            raise PageReadReviewRequired()
        loaded = set()
        for name in ('python_modules', 'native_modules', 'managed_assemblies', 'browser_modules'):
            entries = facts.get(name)
            if not isinstance(entries, (tuple, list)) or len(entries) > 8192:
                raise PageReadReviewRequired()
            for entry in entries:
                loaded.add(str(_path(entry)).casefold())
        loaded.add(str(_path(facts.get('helper_image'))).casefold())
        loaded.add(str(_path(facts.get('browser_image'))).casefold())
        # Runtime inventory must contain the actual loaded roots; SDK DLLs are
        # dependency inputs and cannot substitute for browser/.NET runtime.
        for role in ('native_runtime', 'managed_runtime', 'webview_runtime'):
            if not any(item[2] == role and str(_path(item[0])).casefold() in loaded for item in self.materials):
                raise PageReadReviewRequired()
        approved = {str(_path(item[0])).casefold() for item in self.materials}
        for name in ('python_modules', 'managed_assemblies'):
            # No arbitrary package/assembly may be imported into this route.
            if any(str(_path(entry)).casefold() not in approved for entry in facts[name]):
                raise PageReadReviewRequired()

    def _account_key(self, user, task):
        self._current()
        core = self.policy.server.core
        from .xhs_app_context import _LOCAL, _ACTOR
        call = getattr(_LOCAL, 'call', None)
        if current_read_decision(core) is not self:
            raise PageReadReviewRequired()
        session = call.executor._xhs_app_session
        current_user = core.store.get('users', call.executor.user_id)
        current_task = core._get('tasks', task['id'], call.executor.tenant)
        if (not current_user or _digest({k:current_user.get(k) for k in _ACTOR}) != _digest({k:user.get(k) for k in _ACTOR})
                or current_task.get('account_id') != task.get('account_id')):
            raise PageReadReviewRequired()
        account = core._get('accounts', current_task['account_id'], current_user['tenant_id'])
        core._task_access(current_user, current_task, current_user['tenant_id'])
        core._account_access(current_user, account)
        return (self.route, self.revision, _digest({k: account.get(k) for k in (
            'id', 'tenant_id', 'platform', 'platform_uid', 'cloud_owner', 'status',
            'requires_review', 'updated_at')}), _digest({k:user.get(k) for k in _ACTOR}),
            session.binding.hex())

    def is_verified(self, user, task):
        return self._account_key(user, task) in self.policy._verified

    def record_verified(self, scope):
        """Called only by original adapters.verify after its real search/finish."""
        from .xhs_batch_scope import _BatchScope
        if type(scope) is not _BatchScope or scope.runtime is not self.policy.server.xhs_page_runtime:
            raise PageReadReviewRequired()
        scope.require_result()
        if current_read_decision(scope.runtime.core) is not self:
            raise PageReadReviewRequired()
        core = scope.runtime.core
        user = core.store.get('users', scope.user_id)
        task = core._get('tasks', scope.task_id, scope.tenant)
        self.policy._verified.add(self._account_key(user, task))


class XhsPageReadPolicy:
    def __init__(self, server):
        self.server = server
        self._decision = None
        self._verified = set()
        self._review_path = Path(__file__).resolve().parents[1] / 'resources' / 'xhs-page-read' / 'review.json'
        # Construction alone grants nothing. Missing/changed fixed review holds.
        try:
            binding = self._snapshot()
            if _sha(_path(str(self._review_path))) != _REVIEW_SHA:
                return
            review = json.loads(self._review_path.read_text('utf-8'))
            if (review.get('schema') != 'xhs_internal_page_material_review_v1'
                    or review.get('route') != _ROUTE or review.get('usage_scope') != _USE
                    or review.get('loaded_provenance_criterion') != 'two_stable_origins_file_identity_hash'
                    or review.get('native_loaded_bytes_verified') is not False):
                return
            materials = self._entries(review.get('materials'), roles=True)
            licenses = self._entries(review.get('licenses'), roles=False)
            if set(item[2] for item in materials) != _ROLES or len(licenses) < 10:
                return
            self._decision = _PageReadDecision(_SEAL, self, _REVIEW_SHA, materials, licenses, binding)
            self._verify_materials(self._decision)
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            self._decision = None

    def _entries(self, raw, *, roles):
        if not isinstance(raw, list) or not 1 <= len(raw) <= 8192:
            raise PageReadReviewRequired()
        result = []
        source_root = Path(__file__).resolve().parents[1]
        for entry in raw:
            if not isinstance(entry, dict) or set(entry) != {'path', 'sha256', 'role'}:
                raise PageReadReviewRequired()
            value = entry['path']
            path = source_root / value[7:] if isinstance(value, str) and value.startswith('source:') else _path(value)
            path = _path(str(path))
            if isinstance(value, str) and value.startswith('source:') and not path.is_relative_to(source_root):
                raise PageReadReviewRequired()
            sha, role = entry['sha256'], entry['role']
            if (not isinstance(sha, str) or len(sha) != 64 or any(c not in '0123456789ABCDEF' for c in sha)
                    or roles and role not in _ROLES or not roles and role != 'license'):
                raise PageReadReviewRequired()
            result.append((str(path), sha, role))
        if len({str(item[0]).casefold() for item in result}) != len(result):
            raise PageReadReviewRequired()
        return tuple(result)

    def _customer_snapshot(self):
        from app import AppServer
        from .xhs_app_context import XhsAppHostContext
        module=sys.modules.get('fangyu_customer_read_distribution')
        server=self.server;authority=getattr(server,'_customer_read_authority',None)
        if (type(server) is not AppServer or not getattr(sys,'frozen',False)
                or getattr(server,'_xhs_page_read_policy',self) is not self
                or not getattr(server,'_customer_guarded_read_component',False)
                or module is None or not module.is_authority(authority)
                or authority.scope_for(server)!='customer_distribution_read'
                or type(server._xhs_app_context) is not XhsAppHostContext
                or server._xhs_app_context._server is not server
                or server.xhs_page_runtime is not None
                or server.core.adapters.xhs_page_runtime is not None or server.closing):
            raise PageReadReviewRequired()
        review=authority.runtime_license_review(server,'xiaohongshu_guarded_read')
        policy=getattr(server,'_runtime_license_policy',None)
        value=policy.resolve() if policy is not None else None
        if (not isinstance(review,dict) or not isinstance(value,dict)
                or value.get('xiaohongshu') is not True
                or server._runtime_license_usage_scope()!='customer_distribution_read'
                or server.company!=server.core.deployment_config):
            raise PageReadReviewRequired()
        own=_path(str(Path(__file__).resolve()))
        # The original policy is freshly resolved above. Its revision also
        # contains operational search_verified metadata, which may legitimately
        # change after the first read; bind the actual fixed review/artifacts.
        return _digest((server.company,str(own),_sha(own),review))

    def _snapshot(self):
        if getattr(self.server,'_customer_guarded_read_component',False):
            return self._customer_snapshot()
        from app import AppServer
        from .xhs_app_context import XhsAppHostContext
        from .xhs_page_runtime import XhsPageRuntime
        server = self.server
        runtime = getattr(server, 'xhs_page_runtime', None)
        if (type(server) is not AppServer or getattr(sys, 'frozen', False)
                or getattr(server, '_xhs_page_read_policy', self) is not self
                or server._runtime_license_usage_scope(_USE) != _USE
                or type(server._xhs_app_context) is not XhsAppHostContext
                or server._xhs_app_context._server is not server or type(runtime) is not XhsPageRuntime
                or runtime is not server.core.adapters.xhs_page_runtime
                or runtime.core is not server.core or not runtime.natural_mode or runtime.closed
                or runtime.app_context_factory is not server._xhs_app_context
                or getattr(server, 'closing', False)):
            raise PageReadReviewRequired()
        # This source review supersedes only the known third-party CLI hold.
        # New/unknown runtime controls, private/portable/customer routes are held.
        for config in (server.company, server.core.deployment_config):
            conf = config.get('runtime')
            if (config.get('id') != 'fangyu-apartment-client' or config.get('releaseVersion') != '1.1.7-qa.1'
                    or not isinstance(conf, dict) or set(conf) - _KNOWN_RUNTIME
                    or conf.get('xiaohongshu_automation') not in ('hold', 'enabled')
                    or conf.get('release_approved') not in (None, False)
                    or conf.get('xiaohongshu_automation') == 'enabled' and not conf.get('platform_qa_device_id')):
                raise PageReadReviewRequired()
        own_path = _path(str(Path(__file__).resolve()))
        return _digest((server.company, server.core.deployment_config,
                        str(own_path), _sha(own_path), str(self._review_path)))

    def _verify_revision(self, decision):
        if decision.route=='guarded_cli_v1':
            if decision.usage_scope!='customer_distribution_read' or self._customer_snapshot()!=decision.revision:
                raise PageReadReviewRequired()
            return
        if _sha(_path(str(self._review_path))) != decision.revision:
            raise PageReadReviewRequired()

    def _verify_materials(self, decision):
        self._verify_revision(decision)
        for path, sha, _ in decision.materials + decision.licenses:
            if _sha(_path(path)) != sha:
                raise PageReadReviewRequired()

    def resolve(self):
        from .xhs_customer_account_runtime import natural_collection_selected
        if natural_collection_selected(self.server):
            from .customer_natural_materials import resolve_customer
            return resolve_customer(self,_PageReadDecision,_SEAL,'xiaohongshu_natural_read')
        if getattr(self.server,'_customer_guarded_read_component',False) and self._decision is None:
            try:
                binding=self._customer_snapshot()
                self._decision=_PageReadDecision(_SEAL,self,binding,(),(),binding,'guarded_cli_v1','customer_distribution_read')
            except (OSError,ValueError,TypeError,KeyError,AttributeError):return None
        decision = self._decision
        try:
            if type(decision) is not _PageReadDecision:
                return None
            decision._current()
            return decision
        except (OSError, ValueError, TypeError, AttributeError):
            return None

    def describe(self):
        """Static route state for preflight; never an execution capability.

        A checked review permits only an explicit attempt. Account/session,
        Native loaded sources and the first search are checked in Business.
        No scope, private material paths or decision object crosses this seam.
        """
        from .xhs_customer_account_runtime import natural_collection_selected
        if natural_collection_selected(self.server):
            decision=self.resolve()
            return dict(route=_ROUTE,usage_scope='customer_distribution_read',revision=decision.revision if decision else None,
                status='checked' if decision else 'blocked',reason_codes=[] if decision else ['license_pending'])
        if getattr(self.server,'_customer_guarded_read_component',False):
            decision=self.resolve()
            return dict(route='guarded_cli_v1',usage_scope='customer_distribution_read',revision=decision.revision if decision else None,
                status='checked' if decision else 'blocked',reason_codes=[] if decision else ['license_pending'])
        from .xhs_page_runtime import XhsPageRuntime
        runtime = getattr(self.server, 'xhs_page_runtime', None)
        if type(runtime) is not XhsPageRuntime or not runtime.natural_mode:
            return None
        value = dict(route=_ROUTE, usage_scope=_USE, revision=None,
                     status='blocked', reason_codes=['license_pending'])
        try:
            self._snapshot()
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            value['reason_codes'] = ['platform_policy_hold']
            return value
        decision = self.resolve()
        if decision is not None:
            value.update(revision=decision.revision, status='checked', reason_codes=[])
        return value


def current_read_decision(core, action=None):
    """Same private read-action judgment for Business, original Core and App.

    Never relies on a global current user/HTTP read-only flag. A fresh original
    executor call, or an exact current collector claim, supplies provenance.
    Continuous short lease guards are deliberately left in their old places.
    """
    from .xhs_app_context import _LOCAL, _Call, _CollectorCall, _DeviceSession
    call = getattr(_LOCAL, 'call', None)
    try:
        if (type(call) not in (_Call, _CollectorCall) or not call.active
                or call.thread is not threading.current_thread() or call.executor.core is not core
                or action is not None and action not in _CORE_ACTIONS):
            return None
        collector = type(call) is _CollectorCall
        if not collector and call.action not in _TASK_ACTIONS:
            return None
        if action is not None and action not in _CALL_CORE_ACTIONS.get(call.action, ()):
            return None
        executor, server = call.executor, call.executor.server
        session = getattr(executor, '_xhs_app_session', None)
        if type(session) is not _DeviceSession or session.service.server is not server:
            return None
        session.check()
        if core.remote_safety_hold:
            return None
        policy = getattr(server, '_xhs_page_read_policy', None)
        if type(policy) is not XhsPageReadPolicy or getattr(core, '_xhs_page_read_policy', None) is not policy:
            return None
        decision = policy.resolve()
        if decision is None:
            return None
        if decision.customer is not None:
            decision.customer.check_execution()
        if decision.route=='guarded_cli_v1':
            from .customer_read_lease import current
            if not current(server,'xiaohongshu_guarded_read'):return None
        with core.lock:
            user = core.store.get('users', executor.user_id)
            task = core._get('tasks', call.task_id, executor.tenant)
            account = core._get('accounts', task.get('account_id'), executor.tenant)
            if (not user or user.get('disabled') or user.get('cloud_bound') is not True
                    or user.get('development_local_only') is True or user.get('role') not in ('operator', 'admin')
                    or (user.get('id'), user.get('username'), user.get('tenant_id')) != (executor.user_id, executor.owner, executor.tenant)
                    or task.get('platform') != 'xiaohongshu'
                    or task.get('status') == 'paused' and (collector or call.action == 'task_run')
                    or account.get('platform') != 'xiaohongshu' or account.get('status') != 'ready'
                    or account.get('requires_review') or not str(account.get('platform_uid') or '').strip()):
                return None
            core._task_access(user, task, executor.tenant)
            core._account_access(user, account)
            core.require_platform('xiaohongshu')
            executor._require_product_feature('acquisition')
            qa = (server.company.get('runtime') or {}).get('platform_qa_device_id')
            if qa and (session.service.state != 'online' or (session.service.device or {}).get('id') != qa):
                return None
            if collector:
                claim, generation = call.claim, call.claim.generation
                job = core.store.get('continuous_tasks', call.task_id) or {}
                if (generation.collector.core is not core or generation.session is not session
                        or generation.collector._app_generations.get(call.task_id) is not generation
                        or generation.collector._app_claims.get(call.task_id) is not claim
                        or generation.collector._stop.is_set() or not core._qa_continuous_allowed()
                        or job.get('generation_id') != generation.ident or job.get('claim_id') != claim.ident
                        or job.get('runtime_id') != generation.collector.runtime_id
                        or job.get('status') not in ('queued', 'running', 'waiting') or job.get('inflight') is not True):
                    return None
        session.check()
        return decision
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        return None
