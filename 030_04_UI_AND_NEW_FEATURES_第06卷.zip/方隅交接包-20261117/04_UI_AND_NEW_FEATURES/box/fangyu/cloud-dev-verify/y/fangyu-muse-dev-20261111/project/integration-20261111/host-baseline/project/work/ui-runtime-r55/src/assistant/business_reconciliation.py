"""Read an existing company ledger through an exact owned local source event.

Matching a source never proves that a local handoff was delivered, that a
platform received a message, or that reported/calculated money was paid.
"""
from copy import deepcopy
import hashlib
import json
import re

from core import CoreError
from .acquisition_operations import AcquisitionOperations, AcquisitionError, HANDOFFS, _digest

ACTION = 'business_reconciliation_detail'
CLOUD_ACTION = 'acquisition_reconciliation_detail'
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_CUSTOMER = re.compile(r'cu_[a-f0-9]{64}\Z')
_UUID = re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z')
_IDENT = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_ORDER = re.compile(r'[A-Za-z0-9_.-]{1,120}\Z')
_MEMBER = re.compile(r'[A-Za-z0-9_.@-]{3,80}\Z')
_CODE = re.compile(r'[a-z][a-z0-9_]{0,79}\Z')
_MAX_INTEGER = 9007199254740991
_MONEY_MAX = 100000000000
_CHANNEL_STATES = frozenset(('draft', 'submitted', 'accepted', 'rejected', 'needs_information',
    'duplicate_pending_review', 'existing_customer_pending_review', 'withdrawn', 'disputed'))
_ATTRIBUTION_STATES = frozenset(('unconfirmed', 'duplicate_pending_review',
    'existing_customer_pending_review', 'disputed', 'withdrawn_pending_review'))
_BINDING_STATES = frozenset(('matched', 'link_revision_changed', 'source_missing', 'source_conflict',
    'customer_conflict', 'order_missing', 'reverse_link_conflict', 'history_missing', 'history_conflict', 'record_invalid'))
_CALCULATIONS = frozenset(('calculated', 'unknown', 'pending_review', 'review_rejected', 'attribution_unconfirmed',
    'identity_unverified', 'policy_unconfigured', 'no_confirmed_contact', 'outside_window'))
MISSING_EVIDENCE = frozenset(('financial_cash_authority_not_integrated', 'commission_payment_authority_not_integrated',
    'cooperation_policy_not_verified', 'source_missing', 'source_conflict', 'link_revision_changed',
    'customer_conflict', 'order_missing', 'reverse_link_conflict', 'history_missing', 'history_conflict',
    'record_invalid', 'commission_policy_history_missing'))
_FINANCIAL_MISSING = frozenset(('financial_cash_authority_not_integrated',
                              'commission_payment_authority_not_integrated', 'cooperation_policy_not_verified'))
_SUMMARY_FIELDS = frozenset(('contract', 'authenticated_actor', 'read_only', 'storage_scope', 'observed_at',
    'currency', 'amount_unit', 'channel', 'orders', 'verified_cash_cents', 'verified_paid_commission_cents',
    'financial_receipt_verified', 'cooperation_policy_verified', 'missing_evidence'))
_CHANNEL_FIELDS = frozenset(('channel_id', 'revision', 'status', 'customer_id', 'source_event_id', 'source_owner',
    'current_consent_valid', 'eligible_for_delivery', 'historical_resource_receipt_recorded',
    'receipt_evidence_independently_verified', 'attribution_status', 'source'))
_SOURCE_FIELDS = frozenset(('evidence_status', 'event_id', 'payload_hash', 'owner', 'device_id', 'platform',
    'source_lead_hash', 'original_text_hash', 'author_id_hash', 'comment_id_hash', 'platform_provenance_verified'))
_ORDER_FIELDS = frozenset(('order_no', 'linked_revision', 'current_revision', 'status', 'binding_state',
    'link_revision_current', 'reported_amount_cents', 'reported_refund_cents', 'reported_net_cents',
    'reported_by', 'last_edited_by', 'admin_review_recorded', 'reviewed_by', 'distinct_review_actor_recorded',
    'recorded_calculated_commission_cents', 'calculation_status', 'calculation_policy_revision',
    'calculation_policy_snapshot_available', 'calculation_policy_current', 'verified_cash_cents',
    'verified_paid_commission_cents', 'financial_receipt_verified', 'cooperation_policy_verified', 'missing_evidence'))
_FLAGS = {'read_only': True, 'local_only': False, 'storage_scope': 'local_bridge_company_server_ledger',
    'cross_machine_verified': False, 'cloud_read_requested': True, 'platform_requests_started': False,
    'provider_requests_started': False, 'ratings_modified': False, 'contacts_modified': False,
    'handoffs_modified': False, 'orders_modified': False, 'payments_started': False, 'auto_retry': False,
    'local_cloud_handoff_correspondence_verified': False}


class BusinessReconciliationError(CoreError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code = 'BUSINESS_RECONCILIATION_' + code
        self.status = status
        self.mutation_committed = False


def _fail(code, message, status=400):
    raise BusinessReconciliationError(code, message, status)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


def _raw_hash(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def _integer(value, minimum=0, maximum=_MAX_INTEGER, nullable=False):
    if nullable and value is None:
        return None
    if type(value) is not int or not minimum <= value <= maximum:
        _fail('RECEIPT_INVALID', '公司账本数量或版本需核对，暂不显示结果', 409)
    return value


def _exact(value, keys):
    if not isinstance(value, dict) or set(value) != set(keys):
        _fail('RECEIPT_INVALID', '公司账本回执字段需核对，暂不显示结果', 409)


def _match(value, pattern):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _bool(value, nullable=False):
    if nullable and value is None:
        return
    if type(value) is not bool:
        _fail('RECEIPT_INVALID', '公司账本证据状态需核对，暂不显示结果', 409)


def _missing(value):
    if (not isinstance(value, list) or len(value) > len(MISSING_EVIDENCE)
            or any(not _match(item, _CODE) or item not in MISSING_EVIDENCE for item in value)
            or len(set(value)) != len(value) or not _FINANCIAL_MISSING.issubset(value)):
        _fail('RECEIPT_INVALID', '公司账本缺失证据项需核对，暂不显示结果', 409)


def _financial(value):
    if (value.get('verified_cash_cents') is not None or value.get('verified_paid_commission_cents') is not None
            or value.get('financial_receipt_verified') is not False
            or value.get('cooperation_policy_verified') is not False):
        _fail('RECEIPT_INVALID', '未接入权威到账凭证，不能显示已收或已付', 409)
    _missing(value.get('missing_evidence'))


class LocalBusinessReconciliation:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read):
        if (not isinstance(tenant, str) or not tenant or not _match(owner, _MEMBER)
                or not isinstance(company, dict) or not _match(company.get('id'), _IDENT)
                or not _match(device_id, _IDENT) or not callable(scope_guard)
                or not callable(lead_access) or not callable(cloud_read)):
            raise ValueError('经营对账需要可信员工、企业、设备、原评论权限与只读云入口')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.company_id, self.device_id = company['id'], device_id
        self.scope_guard, self.lead_access, self.cloud_read = scope_guard, lead_access, cloud_read

    def _scope(self):
        try:
            valid = self.company.get('id') == self.company_id and self.scope_guard() is True
        except Exception:
            valid = False
        if not valid:
            _fail('SCOPE_CHANGED', '员工、企业或设备范围已变化，请重新打开对账', 409)

    def _snapshot(self, handoff_id, user):
        self._scope()
        helper = AcquisitionOperations(self.core, self.tenant, self.owner, self.company,
                                       lead_access=self.lead_access)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN')
            try:
                actor = helper._user(db, user)
                if actor.get('username') != self.owner or actor.get('cloud_bound') is not True:
                    _fail('FORBIDDEN', '只可核对当前本人有权的本机来源', 403)
                item = helper._row(db, HANDOFFS, handoff_id)
                if (not item or item.get('cloud_owner') != self.owner
                        or item.get('company_id') != self.company_id or item.get('tenant_id') != self.tenant):
                    _fail('FORBIDDEN', '交接不存在或不属于当前本人', 403)
                item = helper._item(db, handoff_id, actor)
                lead = helper._row(db, 'leads', item.get('lead_id'))
                if not lead or lead.get('demo') or lead.get('cloud_owner') not in (None, '', self.owner):
                    _fail('FORBIDDEN', '原评论不属于当前本人或已不可读', 403)
                # The source employee is never impersonated by a receiver/admin.
                self.lead_access(actor, lead)
            except AcquisitionError as error:
                _fail('AUDIT_CONFLICT' if error.code == 'ACQUISITION_AUDIT_CONFLICT' else 'FORBIDDEN',
                      '本机交接来源或审计范围需核对', 409 if error.code == 'ACQUISITION_AUDIT_CONFLICT' else 403)
            except (CoreError, ValueError):
                _fail('FORBIDDEN', '原评论当前权限已变化，请重新核对', 403)
            source = item.get('source')
            if (not isinstance(source, dict) or lead.get('platform') != 'xiaohongshu'
                    or not _match(lead.get('author_id'), _IDENT) or not _match(lead.get('comment_id'), _IDENT)
                    or not isinstance(lead.get('text'), str) or not lead['text'].strip()
                    or any(source.get(key) != lead.get(key) for key in ('platform', 'author_id', 'comment_id', 'task_id'))
                    or source.get('original_text_hash') != _digest(lead['text'])):
                _fail('SOURCE_CONFLICT', '原评论身份或版本不匹配，暂不能对应公司账本', 409)
            self._scope()
            return {'actor': deepcopy(actor), 'item': deepcopy(item), 'lead': deepcopy(lead),
                    'fingerprint': _hash({'actor': actor, 'item': item, 'lead': lead, 'company': self.company})}

    def _owned_event(self, event_id, snapshot):
        with self.core.lock, self.core.store.connect() as db:
            exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='contact_events'").fetchone()
            row = db.execute('SELECT payload,payload_hash FROM contact_events WHERE event_id=? AND tenant_id=? AND cloud_owner=?',
                             (event_id, self.tenant, self.owner)).fetchone() if exists else None
        if not row:
            _fail('SOURCE_MISSING', '公司来源事件没有对应的本人本机证据，暂不显示对账', 409)
        try:
            event = json.loads(row['payload'])
            lead, reply = event['lead'], event['reply']
            if (event.get('event_id') != event_id or lead.get('id') != snapshot['lead']['id']
                    or not isinstance(reply.get('id'), str) or not reply['id']
                    or any(lead.get(key) != str(snapshot['lead'].get(key) or '')
                           for key in ('platform', 'author_id', 'comment_id', 'text', 'task_id'))
                    or _raw_hash(row['payload']) != row['payload_hash'] or _hash(event) != row['payload_hash']):
                raise ValueError('immutable source mismatch')
            receipt = self.core.contact_journal.receipt(self.tenant, self.owner, reply['id'], lead['id'])
            entries = [value for value in receipt['events'] if value['event_id'] == event_id]
            if (receipt.get('local_integrity') != 'ok' or len(entries) != 1
                    or entries[0].get('local_integrity') != 'ok'
                    or entries[0].get('payload_hash') != row['payload_hash']):
                raise ValueError('journal chain mismatch')
        except Exception:
            _fail('AUDIT_CONFLICT', '本机不可变来源事件或完整历史需核对，暂不显示对账', 409)
        return event, row['payload_hash']

    def _orders(self, value, offset, limit):
        _exact(value, ('items', 'total_linked', 'offset', 'limit', 'has_more'))
        total = _integer(value['total_linked'])
        _bool(value['has_more'])
        if (value['offset'] != offset or type(value['offset']) is not int
                or value['limit'] != limit or type(value['limit']) is not int
                or not isinstance(value['items'], list) or len(value['items']) != max(0, min(limit, total-offset))
                or value['has_more'] != (offset+len(value['items']) < total)):
            _fail('RECEIPT_INVALID', '公司账本分页不一致，请重新核对', 409)
        seen = set()
        for row in value['items']:
            _exact(row, _ORDER_FIELDS)
            if not _match(row['order_no'], _ORDER) or row['order_no'] in seen:
                _fail('RECEIPT_INVALID', '公司订单编号或去重需核对', 409)
            seen.add(row['order_no'])
            _integer(row['linked_revision'], 1)
            _integer(row['current_revision'], 1, nullable=True)
            _integer(row['calculation_policy_revision'], 0, nullable=True)
            if (row['status'] not in ('pending', 'confirmed', 'rejected', 'unknown')
                    or row['binding_state'] not in _BINDING_STATES or row['calculation_status'] not in _CALCULATIONS):
                _fail('RECEIPT_INVALID', '公司订单证据状态需核对', 409)
            for name in ('admin_review_recorded', 'calculation_policy_snapshot_available'):
                _bool(row[name])
            for name in ('link_revision_current', 'distinct_review_actor_recorded', 'calculation_policy_current'):
                _bool(row[name], nullable=True)
            for name in ('reported_by', 'last_edited_by', 'reviewed_by'):
                if row[name] is not None and not _match(row[name], _MEMBER):
                    _fail('RECEIPT_INVALID', '公司订单登记主体需核对', 409)
            for name in ('reported_amount_cents', 'reported_refund_cents', 'reported_net_cents',
                         'recorded_calculated_commission_cents'):
                _integer(row[name], 0, _MONEY_MAX, nullable=True)
            good = row['binding_state'] in ('matched', 'link_revision_changed')
            if good:
                amount, refund, net = (row[key] for key in ('reported_amount_cents', 'reported_refund_cents', 'reported_net_cents'))
                if (amount is None or refund is None or net is None or refund > amount or net != amount-refund
                        or row['current_revision'] is None or row['status'] == 'unknown'
                        or row['link_revision_current'] != (row['current_revision'] == row['linked_revision'])
                        or (row['binding_state'] == 'matched') != row['link_revision_current']):
                    _fail('RECEIPT_INVALID', '公司订单登记值与关联版本不一致', 409)
            elif (any(row[key] is not None for key in ('reported_amount_cents', 'reported_refund_cents',
                                                     'reported_net_cents', 'recorded_calculated_commission_cents'))
                    or row['link_revision_current'] is not None
                    or row['binding_state'] not in row['missing_evidence']):
                _fail('RECEIPT_INVALID', '订单来源有冲突，暂不能显示金额', 409)
            calculated = row['recorded_calculated_commission_cents']
            if calculated is not None and (not good or row['calculation_status'] != 'calculated' or row['status'] != 'confirmed'
                    or row['calculation_policy_snapshot_available'] is not True or row['calculation_policy_revision'] is None):
                _fail('RECEIPT_INVALID', '公司历史计算分成证据需核对', 409)
            if (row['distinct_review_actor_recorded'] and (not row['admin_review_recorded']
                    or row['reviewed_by'] is None or row['reported_by'] is None or row['last_edited_by'] is None
                    or row['reviewed_by'] in (row['reported_by'], row['last_edited_by']))
                    or row['admin_review_recorded'] and row['status'] not in ('confirmed', 'rejected')
                    or row['calculation_policy_current'] and not row['calculation_policy_snapshot_available']):
                _fail('RECEIPT_INVALID', '公司审核与政策证据相互矛盾', 409)
            _financial(row)
        return deepcopy(value)

    def _summary(self, answer, data, snapshot):
        _exact(answer, ('summary',))
        summary = answer['summary']
        _exact(summary, _SUMMARY_FIELDS)
        if (summary['contract'] != 'business_reconciliation_v1' or summary['read_only'] is not True
                or summary['storage_scope'] != 'company_server_ledger' or summary['authenticated_actor'] != self.owner
                or summary['currency'] is not None or summary['amount_unit'] != 'legacy_cents'):
            _fail('RECEIPT_INVALID', '公司账本身份或只读合同需核对', 409)
        _integer(summary['observed_at'], 1577836800)
        _financial(summary)
        channel = summary['channel']
        _exact(channel, _CHANNEL_FIELDS)
        if (channel['channel_id'] != data['channel_id'] or not _match(channel['customer_id'], _CUSTOMER)
                or channel['source_owner'] != self.owner or not _match(channel['source_event_id'], _UUID)
                or channel['status'] not in _CHANNEL_STATES or channel['attribution_status'] not in _ATTRIBUTION_STATES):
            _fail('SOURCE_CONFLICT', '公司渠道与本人来源身份不一致，暂不显示对账', 409)
        _integer(channel['revision'], 1)
        for name in ('current_consent_valid', 'eligible_for_delivery', 'historical_resource_receipt_recorded'):
            _bool(channel[name])
        if channel['receipt_evidence_independently_verified'] is not False:
            _fail('RECEIPT_INVALID', '资源部账号登记不能升级为独立证据核验', 409)
        source = channel['source']
        _exact(source, _SOURCE_FIELDS)
        if (source['evidence_status'] != 'matched' or source['event_id'] != channel['source_event_id']
                or source['owner'] != self.owner or source['device_id'] != self.device_id
                or source['platform'] != 'xiaohongshu' or source['platform_provenance_verified'] is not False
                or any(not _match(source[key], _HEX) for key in ('payload_hash', 'source_lead_hash',
                       'original_text_hash', 'author_id_hash', 'comment_id_hash'))):
            _fail('SOURCE_CONFLICT', '公司来源事件缺失或与本机范围不匹配，暂不显示对账', 409)
        event, payload_hash = self._owned_event(source['event_id'], snapshot)
        lead = event['lead']
        expected = {'payload_hash': payload_hash, 'source_lead_hash': _raw_hash(lead['id']),
                    'original_text_hash': _raw_hash(lead['text']), 'author_id_hash': _raw_hash(lead['author_id']),
                    'comment_id_hash': _raw_hash(lead['comment_id'])}
        if (any(source[key] != expected[key] for key in expected)
                or channel['customer_id'] != 'cu_'+_raw_hash('xiaohongshu:author:'+lead['author_id'])):
            _fail('SOURCE_CONFLICT', '原事件摘要或客户身份不一致；不会自动猜配', 409)
        orders = self._orders(summary['orders'], data['offset'], data['limit'])
        public_channel = {key: deepcopy(channel[key]) for key in ('channel_id', 'revision', 'status',
            'current_consent_valid', 'eligible_for_delivery', 'historical_resource_receipt_recorded',
            'receipt_evidence_independently_verified', 'attribution_status')}
        return {**_FLAGS, 'contract': 'local_business_reconciliation_v1', 'observed_at': summary['observed_at'],
            'currency': None, 'amount_unit': 'legacy_cents',
            'local_handoff': {'handoff_id': snapshot['item']['id'], 'revision': snapshot['item']['revision'],
                              'status': snapshot['item']['status']},
            'source_binding': {'status': 'matched', 'local_integrity': 'ok', 'platform_provenance_verified': False},
            'channel': public_channel, 'orders': orders, 'verified_cash_cents': None,
            'verified_paid_commission_cents': None, 'financial_receipt_verified': False,
            'cooperation_policy_verified': False, 'missing_evidence': deepcopy(summary['missing_evidence'])}

    def execute(self, action, data, user):
        if (action != ACTION or not isinstance(data, dict) or set(data)-{'handoff_id', 'channel_id', 'offset', 'limit'}
                or not _match(data.get('handoff_id'), _HANDOFF) or not _match(data.get('channel_id'), _CHANNEL)):
            _fail('INVALID_INPUT', '请从已有交接打开，并填写有效的公司交接编号')
        offset, limit = data.get('offset', 0), data.get('limit', 10)
        if type(offset) is not int or not 0 <= offset <= _MAX_INTEGER or type(limit) is not int or not 1 <= limit <= 15:
            _fail('INVALID_INPUT', '公司账本每页1至15条，页码必须是非负整数')
        data = {**data, 'offset': offset, 'limit': limit}
        before = self._snapshot(data['handoff_id'], user)
        # No DB transaction/lock is held during the one authenticated read.
        actor = {key: deepcopy(before['actor'].get(key)) for key in ('id', 'tenant_id', 'username', 'role', 'cloud_bound')}
        try:
            answer = self.cloud_read(actor, CLOUD_ACTION,
                                     {key: data[key] for key in ('channel_id', 'offset', 'limit')})
        except Exception:
            _fail('CLOUD_UNAVAILABLE', '公司账本暂不可读，请核对云连接与成员权限后再查询', 503)
        result = self._summary(answer, data, before)
        with self.core.lock:
            # The journal may await storage too. Recheck the saved actor/source
            # after that final read, immediately before the public projection.
            self._owned_event(answer['summary']['channel']['source_event_id'], before)
            after = self._snapshot(data['handoff_id'], user)
            if after['fingerprint'] != before['fingerprint']:
                _fail('SCOPE_CHANGED', '读取期间员工、来源或交接版本已变化，请重新打开对账', 409)
            self._scope()
            return result
