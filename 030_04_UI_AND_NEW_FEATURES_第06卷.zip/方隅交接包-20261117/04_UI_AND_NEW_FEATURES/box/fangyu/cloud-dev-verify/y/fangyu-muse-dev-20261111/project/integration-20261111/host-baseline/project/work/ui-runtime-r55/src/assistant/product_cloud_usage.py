"""Read a trusted cloud quota summary through the existing employee transport.

No analysis, quota-status cancellation, replay, platform call or local persistence
is performed here. A verified receipt describes service resource slots, never a
payment, a platform delivery or an unlimited entitlement.
"""
import hashlib
import math
import re


_FEATURES = frozenset(('acquisition', 'intent_analysis', 'export', 'handoff', 'strategy', 'team'))
_MAX_INTEGER = 9007199254740991
_MESSAGES = {
    'verified': '已读取云端服务资源账本；分析槽不代表平台收费、成交或到账。',
    'not_configured': '云端尚未配置套餐额度；现有试点权限不代表无限额度。',
    'not_tracked': '云端未追踪分析槽总量，无法推算剩余额度或使用百分比。',
    'period_required': '分析额度缺少可信服务周期，暂不能确认可用余额。',
    'period_inactive': '当前服务周期尚未开始或已结束，历史用量不代表当前可用额度。',
    'expired': '服务权益已到期；历史用量仍可核对，暂不能确认新的可用额度。',
    'unavailable': '云端套餐用量暂不可读；不可读不代表无限或零用量。',
    'identity_changed': '员工、设备或企业连接已变化，请在当前身份下重新读取用量。',
    'invalid_receipt': '云端套餐回执未通过核对，额度保持未知，请核实服务配置。',
}


def _empty(state):
    return {'state': state, 'message': _MESSAGES[state], 'read_only': True,
            'cloud_receipt_verified': False, 'source': 'unverified',
            'scope': 'company_server_quota_ledger', 'package': None, 'features': [],
            'analysis': {'unit': 'comment_analysis_slots', 'tracked': False,
                         'total': None, 'confirmed': None, 'reserved': None,
                         'unknown': None, 'remaining': None, 'usage_percent': None,
                         'over_limit': None, 'available_for_new_analysis': None},
            'seats': {'total': None, 'enabled': None, 'over_limit': None,
                      'scope': 'all_enabled_login_members'},
            'stores': {'total': None, 'enabled': None, 'over_limit': None,
                       'scope': 'enabled_member_store_bindings'},
            'period': {'configured': False, 'active': False, 'start_at': None, 'end_at': None},
            'payment_enabled': False, 'billing_verified': False,
            'platform_execution_verified': False}


def _capture(server, executor, supplied):
    """Current persisted principal and bound device; locks never span network IO."""
    from .business import BusinessExecutor
    from integrations import Integrations, endpoint

    if (not isinstance(supplied, dict) or supplied.get('role') not in ('operator', 'admin')
            or supplied.get('cloud_bound') is not True or supplied.get('disabled')
            or supplied.get('development_local_only') is True
            or not isinstance(executor, BusinessExecutor) or executor.server is not server
            or executor.core is not server.core):
        raise ValueError('identity')
    company = server.company
    managed = company.get('managedWorkspace') or {}
    env, company_id = managed.get('environment_id'), company.get('id')
    if (not isinstance(env, str) or not re.fullmatch(r'[A-Za-z0-9_-]{3,100}', env)
            or not isinstance(company_id, str) or not company_id
            or server.core.deployment_config.get('id') != company_id):
        raise ValueError('company')
    address = endpoint(managed.get('endpoint'))
    if not address:
        raise ValueError('connection')
    tenant = 'cloud-' + hashlib.sha256((env + '\n' + company_id).encode()).hexdigest()[:24]
    owner = supplied.get('username')
    if not isinstance(owner, str) or not owner:
        raise ValueError('owner')
    user_id = hashlib.sha256((tenant + '\n' + owner).encode()).hexdigest()
    if (supplied.get('tenant_id') != tenant or supplied.get('id') != user_id
            or executor.tenant != tenant or executor.owner != owner or executor.user_id != user_id):
        raise ValueError('scope')
    with server.core.lock:
        current = server.core.store.get('users', user_id)
        if (not current or current.get('disabled') or current.get('cloud_bound') is not True
                or current.get('development_local_only') is True
                or any(current.get(k) != supplied.get(k) for k in ('id', 'tenant_id', 'username', 'role'))):
            raise ValueError('principal')
        principal = tuple(current.get(k) for k in ('id', 'tenant_id', 'username', 'role', 'store_id', 'updated_at'))
    assistant = server.assistant_service
    with assistant.lock:
        device = dict(assistant.device or {})
        saved = assistant.vault.read()
        vault_device = (saved or {}).get('device') or {}
        if (assistant.executor is not executor or assistant.state not in ('online', 'held')
                or getattr(assistant, 'closed', False)
                or assistant.environment_id != env or assistant.company_id != company_id
                or endpoint(assistant.endpoint) != address
                or not saved or saved.get('state') != 'bound'
                or saved.get('environment_id') != env or saved.get('company_id') != company_id
                or not isinstance(saved.get('token'), str) or not saved['token']
                or not isinstance(device.get('id'), str) or not device['id'] or device.get('owner') != owner
                or vault_device.get('id') != device['id'] or vault_device.get('owner') != owner):
            raise ValueError('device')
        binding = (device['id'], device['owner'], device.get('version'),
                   hashlib.sha256(saved['token'].encode()).hexdigest())
    integrations = server.integrations
    if not isinstance(integrations, Integrations) or integrations.core is not server.core:
        raise ValueError('transport')
    with integrations.lock:
        config = integrations._read(tenant)
        cloud = config.get('cloud') or {}
        session = (config.get('sessions') or {}).get(user_id) or {}
        if (cloud.get('environment_id') != env or endpoint(cloud.get('endpoint')) != address
                or session.get('username') != owner
                or not isinstance(session.get('token'), str) or not session['token']):
            raise ValueError('session')
        # Mature remembered-login refresh may rotate tokens. Bind to its actor
        # and remembered device rather than treating every safe rotation as logout.
        session_scope = (session['username'], session.get('device_id'))
    stamp = (id(server.core), id(assistant), id(integrations), id(executor), env,
             company_id, address, principal, binding, session_scope)
    return stamp, dict(current), env, company_id


def _integer(value, nullable=False):
    if nullable and value is None:
        return None
    if type(value) is not int or not 0 <= value <= _MAX_INTEGER:
        raise ValueError('number')
    return value


def _boolean(value):
    if type(value) is not bool:
        raise ValueError('boolean')
    return value


def _project(receipt, environment_id, company_id):
    if (not isinstance(receipt, dict) or receipt.get('error')
            or receipt.get('contract') != 'fangyu-workspace-v1'
            or receipt.get('environment_id') != environment_id or receipt.get('company_id') != company_id
            or receipt.get('payment_enabled') is not False or receipt.get('billing_verified') is not False):
        raise ValueError('receipt')
    current, usage, allocation = (receipt[k] for k in ('current', 'usage', 'allocation'))
    if not all(isinstance(value, dict) for value in (current, usage, allocation)):
        raise ValueError('shape')
    configured, expired = _boolean(current['configured']), _boolean(current['expired'])
    package = current['package']
    if package not in (('experience', 'professional', 'team') if configured else ('pilot_existing',)):
        raise ValueError('package')
    features = current['features']
    if (not isinstance(features, list) or len(features) > len(_FEATURES)
            or any(not isinstance(f, str) or f not in _FEATURES for f in features)
            or len(set(features)) != len(features)):
        raise ValueError('features')
    total, seats, stores = (_integer(current[k], nullable=True)
                            for k in ('analysis_quota', 'seat_limit', 'store_limit'))
    expiry = current.get('expires_at')
    if (expiry is not None and (type(expiry) not in (int, float)
            or not math.isfinite(expiry) or not 0 < expiry <= _MAX_INTEGER)):
        raise ValueError('expiry')
    if expired and expiry is None:
        raise ValueError('expiry')
    if not configured and (total is not None or seats is not None or stores is not None or expired or expiry is not None):
        raise ValueError('pilot')
    if usage['unit'] != 'comment_analysis_slots':
        raise ValueError('unit')
    confirmed, reserved, unknown = (_integer(usage[k]) for k in ('confirmed', 'reserved', 'unknown'))
    remaining = _integer(usage['remaining'], nullable=True)
    if (unknown > reserved or confirmed + reserved > _MAX_INTEGER
            or remaining != (None if total is None else max(0, total - confirmed - reserved))):
        raise ValueError('ledger')
    members, groups = (_integer(allocation[k]) for k in ('enabled_members', 'enabled_member_store_groups'))
    if (allocation['seat_scope'] != 'all_enabled_login_members'
            or allocation['store_scope'] != 'enabled_member_store_bindings' or groups > members):
        raise ValueError('allocation')
    period_configured = _boolean(receipt['period_configured'])
    period_active = _boolean(receipt['period_active'])
    period = receipt['period']
    if period is None:
        if period_configured or period_active:
            raise ValueError('period')
        start = end = None
    else:
        if (total is None or not period_configured or not isinstance(period, dict)
                or not isinstance(period.get('id'), str)
                or re.fullmatch(r'[A-Za-z0-9_.:-]{8,128}', period['id']) is None):
            raise ValueError('period')
        start, end = _integer(period['start_at']), _integer(period['end_at'])
        if end <= start:
            raise ValueError('period')
    state = ('not_configured' if not configured else 'expired' if expired else 'not_tracked' if total is None else
             'period_required' if not period_configured else
             'period_inactive' if not period_active else 'verified')
    result = _empty(state)
    result.update(cloud_receipt_verified=True, source='trusted_cloud_service', package=package,
                  features=list(features))
    tracked = total is not None and period_configured
    usable = tracked and period_active and not expired
    result['analysis'].update(tracked=tracked, total=total,
                             confirmed=confirmed if tracked else None,
                             reserved=reserved if tracked else None,
                             unknown=unknown if tracked else None,
                             remaining=remaining if usable else None,
                             usage_percent=round((confirmed + reserved) * 100 / total, 2)
                             if usable and total else None,
                             over_limit=confirmed + reserved > total if tracked else None,
                             available_for_new_analysis=False if expired or 'intent_analysis' not in features else
                             bool(usable and remaining > 0) if total is not None else None)
    result['seats'].update(total=seats, enabled=members,
                           over_limit=members > seats if seats is not None else None)
    result['stores'].update(total=stores, enabled=groups,
                            over_limit=groups > stores if stores is not None else None)
    result['period'].update(configured=period_configured, active=period_active,
                            start_at=start, end_at=end)
    return result


def read_product_usage(server, executor, saved_user):
    """Return a safe projection; unavailable/invalid never falls back to zero."""
    try:
        before, current, environment_id, company_id = _capture(server, executor, saved_user)
    except Exception:
        return _empty('unavailable')
    try:
        receipt = executor._ai_cloud(current, 'product_entitlement_summary', {})
    except Exception:
        # Neither exception messages nor cloud payloads are included in logs/UI.
        return _empty('unavailable')
    try:
        after, _, _, _ = _capture(server, executor, saved_user)
        if before != after:
            return _empty('identity_changed')
    except Exception:
        return _empty('identity_changed')
    try:
        return _project(receipt, environment_id, company_id)
    except Exception:
        return _empty('invalid_receipt')
