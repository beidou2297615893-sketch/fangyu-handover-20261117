"""Exact frozen original event versus company device-report ledger; reads only."""
from copy import deepcopy
import re

from core import CoreError
from core.contact_journal import KINDS
from .company_handoff_original_status import CompanyHandoffOriginalStatus, CompanyHandoffOriginalStatusError

ACTION = 'company_handoff_source_binding_get'
CLOUD_READ = 'acquisition_source_binding_read'
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_MAX = 9007199254740991
_ENVELOPE = frozenset(('source_binding', 'read_only', 'mutation_committed', 'auto_retry'))
_BINDING = frozenset(('contract', 'read_only', 'storage_scope', 'observed_at', 'authenticated_actor', 'state',
    'event', 'local_chain_authority_verified', 'platform_provenance_verified', 'auto_retry'))
_EVENT = frozenset(('event_id', 'payload_hash', 'kind', 'owner', 'device_id', 'server_received_at'))


class CompanyHandoffSourceBindingError(CoreError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_SOURCE_BINDING_' + code
        self.status, self.mutation_committed = status, False


def _fail(code, message, status=400):
    raise CompanyHandoffSourceBindingError(code, message, status)


def _exact(value, fields):
    if not isinstance(value, dict) or set(value) != fields:
        _fail('RECEIPT_INVALID', '公司来源核对字段不完整，请保留原准备', 409)


def _integer(value, minimum=0):
    return type(value) is int and minimum <= value <= _MAX


class CompanyHandoffSourceBinding:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read):
        if not callable(cloud_read):
            raise ValueError('来源核对需要可信的无自动续期只读入口')
        self.owner, self.cloud_read = owner, cloud_read
        # Reuse the frozen original owned-history snapshot, never its cloud action.
        self.history = CompanyHandoffOriginalStatus(core, tenant, owner, company, device_id=device_id,
            scope_guard=scope_guard, lead_access=lead_access, cloud_read=lambda *_: None)

    def _snapshot(self, handoff_id, user):
        try:
            return self.history._snapshot(handoff_id, user)
        except CompanyHandoffOriginalStatusError as error:
            suffix = error.code.removeprefix('COMPANY_HANDOFF_ORIGINAL_STATUS_')
            _fail(suffix, '原准备、本人完整来源或当前范围需核对，未显示公司来源匹配', error.status)

    def _binding(self, answer, origin):
        _exact(answer, _ENVELOPE)
        if answer['read_only'] is not True or answer['mutation_committed'] is not False or answer['auto_retry'] is not False:
            _fail('RECEIPT_INVALID', '公司来源核对不是可信纯读结果，请保留原准备', 409)
        binding = answer['source_binding']
        _exact(binding, _BINDING)
        if (binding['contract'] != 'company_source_binding_v1' or binding['read_only'] is not True
                or binding['storage_scope'] != 'company_server_ledger' or not _integer(binding['observed_at'], 1577836800)
                or binding['authenticated_actor'] != self.owner or binding['state'] not in ('matched', 'not_recorded')
                or any(binding[field] is not False for field in ('local_chain_authority_verified', 'platform_provenance_verified', 'auto_retry'))):
            _fail('RECEIPT_INVALID', '公司来源的当前身份、范围或证据标志需核对', 409)
        if binding['state'] == 'not_recorded':
            if binding['event'] is not None:
                _fail('RECEIPT_INVALID', '未读到原来源时不能显示已有事件证据', 409)
        else:
            event = binding['event']
            _exact(event, _EVENT)
            if (event['event_id'] != origin['source_event_id'] or event['payload_hash'] != origin['source_payload_hash']
                    or event['kind'] != origin['source_event_kind'] or event['kind'] not in KINDS
                    or event['owner'] != self.owner or event['device_id'] != origin['device_id']
                    or not _integer(event['server_received_at'], 1577836800) or event['server_received_at'] > binding['observed_at']):
                _fail('SOURCE_MISMATCH', '公司保存事件与原准备的固定来源不一致，未显示匹配', 409)
        return deepcopy(binding)

    def _result(self, snapshot, binding=None):
        origin = snapshot['origin']
        state = binding['state'] if binding else 'no_origin'
        matched = state == 'matched'
        return {'contract': 'company_handoff_source_binding_v1', 'read_only': True, 'mutation_committed': False,
            'local_only': state == 'no_origin', 'storage_scope': 'local_bridge_company_server_ledger',
            'cross_machine_verified': False, 'cloud_read_requested': binding is not None,
            'observed_at': binding['observed_at'] if binding else None, 'state': state,
            'origin': {'origin_id': origin['origin_id'], 'local_handoff_revision': origin['handoff_revision']} if origin else None,
            'current_local': deepcopy(snapshot['current']),
            'source_event': {'kind': binding['event']['kind'], 'server_received_at': binding['event']['server_received_at']} if matched else None,
            'company_event_payload_matched': matched, 'source_cloud_binding_verified': False,
            'local_chain_authority_verified': False, 'platform_provenance_verified': False,
            'platform_delivery_verified': False, 'financial_receipt_verified': False, 'cooperation_policy_verified': False,
            'verified_cash_cents': None, 'verified_paid_commission_cents': None, 'settlement_active': False,
            'auto_retry': False, 'no_dispatch': True, 'no_dispatch_scope': 'this_source_query_only',
            'provider_requests_started': False, 'platform_requests_started': False,
            'contacts_modified': False, 'handoffs_modified': False, 'ratings_modified': False}

    def execute(self, action, data, user):
        if (action != ACTION or not isinstance(data, dict) or set(data) != {'handoff_id'}
                or not isinstance(data['handoff_id'], str) or not _HANDOFF.fullmatch(data['handoff_id'])):
            _fail('INVALID_INPUT', '来源核对仅接受本人已有本机交接编号')
        try:
            before = self._snapshot(data['handoff_id'], user)
            binding = None
            if before['origin']:
                origin = before['origin']
                try:
                    answer = self.cloud_read(deepcopy(before['actor']), CLOUD_READ,
                        {'event_id': origin['source_event_id'], 'payload_hash': origin['source_payload_hash'], 'expected_device_id': origin['device_id']})
                except Exception as error:
                    if getattr(error, 'code', None) == 'COMPANY_SOURCE_BINDING_READ_SESSION_REQUIRED':
                        _fail('SESSION_REQUIRED', '当前公司会话需明确重新连接，请保留原准备后再核对', 409)
                    _fail('READ_UNAVAILABLE', '公司原来源暂不可读，请保留原准备；本次未上传或重发', 503)
                binding = self._binding(answer, origin)
            after = self._snapshot(data['handoff_id'], user)
            if before['fingerprint'] != after['fingerprint']:
                _fail('LOCAL_CHANGED', '原准备、当前授权或来源读取期间已变化，请重新核对', 409)
            return self._result(after, binding)
        except CompanyHandoffSourceBindingError:
            raise
        except Exception:
            _fail('READ_UNAVAILABLE', '原准备对应公司来源暂不可读，请保留原准备', 503)
