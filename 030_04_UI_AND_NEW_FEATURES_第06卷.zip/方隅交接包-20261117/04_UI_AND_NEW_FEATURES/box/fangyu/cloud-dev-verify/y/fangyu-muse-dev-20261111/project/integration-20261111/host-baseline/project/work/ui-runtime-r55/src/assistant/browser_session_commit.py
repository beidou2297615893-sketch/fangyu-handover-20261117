"""Commit one verified browser login into one existing XHS account.

The caller holds the account's exclusive service lock throughout commit/recover.
No platform, cloud, task, or logging operation is performed here.  A small
credential-free journal bridges the SQLite transaction and filesystem renames;
these two resources cannot form a genuinely atomic transaction.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import stat
import time
from typing import Callable, Mapping

from core.adapters import xhs_image_url


_COOKIES = frozenset({
    'a1', 'webId', 'web_session', 'web_session_sec', 'id_token',
    'websectiga', 'sec_poison_id', 'xsecappid', 'gid',
    'abRequestId', 'webBuild', 'loadts',
})
_REQUIRED = frozenset({'a1', 'webId', 'web_session'})
_JOURNAL = '.browser-session-commit.json'


class _GuardRejected(Exception):
    pass


def account_revision(account: Mapping) -> str:
    """Canonical full-record revision; never return or log the record itself."""
    raw = json.dumps(account, sort_keys=True, ensure_ascii=False,
                     separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _safe_component(value: object) -> bool:
    return (isinstance(value, str) and bool(value) and value not in ('.', '..')
            and len(value) <= 128 and all(ch.isalnum() or ch in '-_' for ch in value))


def _reparse(path: Path) -> bool:
    if path.is_symlink():
        return True
    try:
        attrs = getattr(path.stat(follow_symlinks=False), 'st_file_attributes', 0)
        return bool(attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))
    except FileNotFoundError:
        return False


def _paths(store, account_dir: Path, account_id: str, tenant_id: str):
    if not _safe_component(account_id) or not _safe_component(tenant_id):
        raise ValueError('scope_invalid')
    base = Path(store.directory)
    expected = base / 'accounts' / tenant_id / account_id
    if Path(account_dir).absolute() != expected.absolute():
        raise ValueError('scope_invalid')
    config = expected / '.xiaohongshu-cli'
    for path in (base, base / 'accounts', base / 'accounts' / tenant_id,
                 expected, config, config / 'cookies.json', config / _JOURNAL):
        if _reparse(path):
            raise ValueError('scope_invalid')
    return config, config / 'cookies.json', config / _JOURNAL


def _valid_candidate(path: Path) -> bool:
    if _reparse(path) or not path.is_file() or path.stat().st_size > 65536:
        return False
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not _REQUIRED.issubset(data) or not set(data).issubset(_COOKIES | {'saved_at'}):
        return False
    stamp = data.get('saved_at')
    if type(stamp) not in (int, float) or not math.isfinite(stamp):
        return False
    total = 0
    for key in data.keys() - {'saved_at'}:
        value = data[key]
        if not isinstance(value, str) or not value or any(ord(ch) < 32 or ord(ch) == 127 or ch == ';' for ch in value):
            return False
        size = len(value.encode('utf-8'))
        total += len(key.encode('utf-8')) + size
        if size > 8192 or total > 32768:
            return False
    return True


def _controlled_candidate(account_dir: Path, source: Path) -> bool:
    """Accept only this account's isolated browser-login HOME cookie file."""
    try:
        root = account_dir.absolute()
        source = source.absolute()
        parts = source.relative_to(root).parts
        if (len(parts) < 5 or parts[:2] != ('work', 'browser-login')
                or parts[-2:] != ('.xiaohongshu-cli', 'cookies.json')
                or not all(_safe_component(part) for part in parts[2:-2])):
            return False
        if source.resolve(strict=True) != source or not source.is_file():
            return False
        # A Windows junction or another reparse point may not report as a
        # symlink. Reject every component, including the candidate itself.
        cursor = root
        for part in parts:
            cursor = cursor / part
            if _reparse(cursor):
                return False
        return True
    except (OSError, ValueError):
        return False


def _sync_dir(path: Path):
    # Windows does not allow opening directories this way.  Process-crash
    # recovery is tested; power-loss durability depends on the filesystem.
    if os.name != 'nt':
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _write_journal(path: Path, data: dict):
    temp = path.with_name(path.name + '.tmp')
    with temp.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)
    _sync_dir(path.parent)


def _read_journal(path: Path):
    if _reparse(path) or path.stat().st_size > 4096:
        raise ValueError('journal_invalid')
    data = json.loads(path.read_text(encoding='utf-8'))
    if isinstance(data,dict) and data.get('version')==2:
        if (data.get('mode') not in {'identity_only','session_replacement'} or not _safe_component(data.get('account_id'))
                or not _safe_component(data.get('tenant_id'))
                or not isinstance(data.get('nonce'),str) or len(data['nonce'])!=32
                or any(ch not in '0123456789abcdef' for ch in data['nonce'])
                or not isinstance(data.get('event'),dict)
                or type(data.get('activity_file_identity')) is not list
                or len(data['activity_file_identity'])!=2
                or any(type(value) is not int or value<0 for value in data['activity_file_identity'])
                or data['event'].get('attempt_id')!=data['nonce']):
            raise ValueError('journal_invalid')
        if data['mode']=='session_replacement' and (
                not isinstance(data.get('old_generation'),str)
                or data.get('new_generation')!=data['nonce']
                or type(data.get('old_exists')) is not bool
                or not isinstance(data.get('credential_sha256'),str)
                or len(data['credential_sha256'])!=64
                or any(ch not in '0123456789abcdef' for ch in data['credential_sha256'])):
            raise ValueError('journal_invalid')
        return data
    if (not isinstance(data, dict) or data.get('version') != 1
            or not _safe_component(data.get('account_id'))
            or not _safe_component(data.get('tenant_id'))
            or not isinstance(data.get('nonce'), str)
            or len(data['nonce']) != 32
            or any(ch not in '0123456789abcdef' for ch in data['nonce'])
            or not isinstance(data.get('old_generation'), str)
            or not isinstance(data.get('new_generation'), str)
            or data['new_generation'] != data['nonce']
            or type(data.get('old_exists')) is not bool):
        raise ValueError('journal_invalid')
    return data


def _db_account(db, account_id: str, tenant_id: str):
    row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                     ('accounts', account_id, tenant_id)).fetchone()
    return json.loads(row['body']) if row else None


def recover_browser_session(store, account_dir, account_id: str, tenant_id: str) -> str:
    """Resolve a prior interrupted commit while the caller holds the lock.

    Returns a fixed code: clean, old_restored, new_kept, or recovery_required.
    A conflict never guesses which credential belongs to a changed account.
    """
    try:
        config, active, journal_path = _paths(store, Path(account_dir), account_id, tenant_id)
        if not journal_path.exists():
            return 'clean'
        journal = _read_journal(journal_path)
        if journal['account_id'] != account_id or journal['tenant_id'] != tenant_id:
            return 'recovery_required'
        if journal['version']==2:
            # A restart never probes or claims again and never guesses ready.
            # Only clean up a transaction already committed on both resources.
            with store.connect() as db:
                account=_db_account(db,account_id,tenant_id)
            from core.xhs_identity_recovery import read_activity,scan_activity,rows_of,credential_fingerprint,digest
            raw,activity_identity=read_activity(Path(account_dir)/'platform-activity.jsonl')
            if list(activity_identity)!=journal['activity_file_identity']:return 'recovery_required'
            state=scan_activity(raw)
            events=[row for _,_,row in rows_of(raw) if row.get('stage')=='identity_revalidated'
                    and row.get('attempt_id')==journal['nonce']]
            if (account and account.get('status')=='ready'
                    and account.get('identity_revalidation_generation')==journal['nonce']
                    and not account.get('identity_recovery_pending') and not state['pending']
                    and not state['unfinished'] and events==[journal['event']]):
                if journal['mode']=='session_replacement':
                    if (account.get('auth_generation')!=journal['new_generation']
                            or credential_fingerprint(account_dir)!=journal['credential_sha256']):
                        return 'recovery_required'
                    backup=config/('.cookies.auth-backup-'+journal['nonce']+'.json')
                    staged=config/('.cookies.auth-new-'+journal['nonce']+'.json')
                    if any(_reparse(path) for path in (backup,staged)):return 'recovery_required'
                    backup.unlink(missing_ok=True);staged.unlink(missing_ok=True)
                elif digest(str(account.get('auth_generation') or '').encode())!=journal['event'].get('auth_generation_hash'):
                    return 'recovery_required'
                journal_path.unlink();_sync_dir(config)
                return 'new_kept'
            return 'recovery_required'
        backup = config / ('.cookies.auth-backup-' + journal['nonce'] + '.json')
        staged = config / ('.cookies.auth-new-' + journal['nonce'] + '.json')
        if any(_reparse(path) for path in (active, journal_path, backup, staged)):
            return 'recovery_required'
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            account = _db_account(db, account_id, tenant_id)
            if account is None or account.get('id') != account_id or account.get('tenant_id') != tenant_id:
                return 'recovery_required'
            generation = str(account.get('auth_generation') or '')
            if generation == journal['new_generation']:
                if not active.exists():
                    if not staged.exists():
                        return 'recovery_required'
                    os.replace(staged, active)
                backup.unlink(missing_ok=True)
                staged.unlink(missing_ok=True)
                journal_path.unlink()
                _sync_dir(config)
                return 'new_kept'
            if generation != journal['old_generation']:
                return 'recovery_required'
            if journal['old_exists']:
                if backup.exists():
                    os.replace(backup, active)
                else:
                    # Without the old rename target we cannot prove that an
                    # existing active file is the old credential. Stop rather
                    # than label a possibly new file as restored.
                    return 'recovery_required'
            else:
                active.unlink(missing_ok=True)
            staged.unlink(missing_ok=True)
            journal_path.unlink()
            _sync_dir(config)
            return 'old_restored'
    except Exception:
        return 'recovery_required'


def commit_identity_revalidation(store, account_dir, expected_account, decision, attempt):
    """Commit the exact identity receipt and optional verified session before ready."""
    from core.xhs_identity_recovery import IdentityAttempt,digest,scan_activity,credential_fingerprint,_plain,read_activity
    from core.account_safety import _manual_activity_lock
    if type(attempt) is not IdentityAttempt:
        return 'scope_invalid'
    try:
        account_id,tenant_id=expected_account['id'],expected_account['tenant_id']
        config,active,journal_path=_paths(store,Path(account_dir),account_id,tenant_id)
        if (decision.get('verified') is not True or decision.get('status')!='ready'
                or not isinstance(expected_account.get('platform_uid'),str)
                or not expected_account['platform_uid'] or decision.get('uid')!=expected_account['platform_uid']
                or journal_path.exists()):
            return 'recovery_required'
        raw,request_id=attempt.receipt()
        candidate=attempt.scope.candidate
        source=candidate/'.xiaohongshu-cli/cookies.json' if candidate is not None else None
        replacement=source is not None
        if replacement and (not _controlled_candidate(Path(account_dir),source)
                or not _valid_candidate(source)
                or credential_fingerprint(candidate)!=attempt.scope.candidate_hash):
            return 'candidate_changed'
        backup=config/('.cookies.auth-backup-'+attempt.attempt_id+'.json')
        staged=config/('.cookies.auth-new-'+attempt.attempt_id+'.json')
        if replacement and any(path.exists() or _reparse(path) for path in (backup,staged)):
            return 'recovery_required'
        event={'at':time.time(),'stage':'identity_revalidated','kind':'status',
            'attempt_id':attempt.attempt_id,'scope_hash':attempt.scope.binding,
            'covers_through_revision':attempt.revision,'covered_prefix_sha256':attempt.prefix,
            'receipt_start':attempt.revision,'receipt_end':len(raw),'request_id':request_id,
            'uid_hash':digest(decision['uid'].encode()),'account_revision':account_revision(expected_account),
            'auth_generation_hash':digest(str(expected_account.get('auth_generation') or '').encode()),
            'next_auth_generation_hash':digest((attempt.attempt_id if replacement else str(expected_account.get('auth_generation') or '')).encode()),
            'identity_evidence_kind':'single_status_receipt','received_at':time.time(),
            'revalidation_generation':attempt.attempt_id}
        event_raw=(json.dumps(event,separators=(',',':'))+'\n').encode()
        # Validate the same representation the packed CLI/public summary will read.
        resolved=scan_activity(raw+event_raw)
        if resolved['pending'] or resolved['unfinished']:return 'activity_changed'
        config.mkdir(parents=True,exist_ok=True)
        journal={'version':2,'mode':'session_replacement' if replacement else 'identity_only','account_id':account_id,'tenant_id':tenant_id,
                 'nonce':attempt.attempt_id,'event':event,'activity_file_identity':list(attempt.identity)}
        if replacement:
            journal.update(old_generation=str(expected_account.get('auth_generation') or ''),
                new_generation=attempt.attempt_id,old_exists=active.exists(),
                credential_sha256=attempt.scope.candidate_hash)
        _write_journal(journal_path,journal)
        pending=dict(expected_account)
        pending.update(status='identity_recovery_pending',identity_recovery_pending=attempt.attempt_id)
        if replacement:pending['auth_generation']=attempt.attempt_id
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current=_db_account(db,account_id,tenant_id)
            if current is None or account_revision(current)!=account_revision(expected_account):
                return 'account_changed'
            other=db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=? AND id<>?',
                             ('accounts',tenant_id,account_id)).fetchall()
            if any(json.loads(row['body']).get('platform')=='xiaohongshu'
                   and json.loads(row['body']).get('platform_uid')==decision['uid'] for row in other):
                return 'duplicate_identity'
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (json.dumps(pending,ensure_ascii=False),'accounts',account_id,tenant_id))
        attempt.scope.expected_revision=account_revision(pending)
        if replacement:
            # Persist pending before touching the active credential. A crash
            # leaves the journal and owned backup, never a ready account.
            attempt.receipt()
            with source.open('rb') as incoming,staged.open('xb') as outgoing:
                shutil.copyfileobj(incoming,outgoing)
                outgoing.flush();os.fsync(outgoing.fileno())
            staged.chmod(0o600);_plain(staged)
            if (not _valid_candidate(staged) or digest(staged.read_bytes())!=attempt.scope.candidate_hash
                    or credential_fingerprint(candidate)!=attempt.scope.candidate_hash):
                return 'candidate_changed'
            attempt.receipt()
            _sync_dir(config)
            if journal['old_exists']:os.replace(active,backup)
            os.replace(staged,active);_sync_dir(config)
            # The same guard now binds the just-verified active session.
            attempt.scope.active_credential=attempt.scope.candidate_hash
        with _manual_activity_lock(attempt.path):
            current_raw,_=attempt.receipt()
            if current_raw!=raw:return 'activity_changed'
            handle=os.open(attempt.path,os.O_APPEND|os.O_WRONLY|getattr(os,'O_BINARY',0))
            try:
                if os.write(handle,event_raw)!=len(event_raw):raise OSError('activity_incomplete')
                os.fsync(handle)
            finally:os.close(handle)
        if (attempt.scope.guard() is not True or time.monotonic()>=attempt.deadline
                or replacement and credential_fingerprint(candidate)!=attempt.scope.candidate_hash):return 'guard_failed'
        # Acquire the SQLite writer before the short activity-control CAS.
        # No cloud or network call is made while either lock is held.
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current=_db_account(db,account_id,tenant_id)
            if current is None or account_revision(current)!=account_revision(pending):return 'account_changed'
            with _manual_activity_lock(attempt.path):
                current_raw,current_identity=read_activity(attempt.path)
                if (current_raw!=raw+event_raw or current_identity!=attempt.identity or attempt.scope.guard() is not True
                        or time.monotonic()>=attempt.deadline
                        or replacement and credential_fingerprint(candidate)!=attempt.scope.candidate_hash):
                    return 'activity_changed'
                updated=dict(current)
                updated.pop('identity_recovery_pending',None)
                updated.update(status='ready',platform_uid=decision['uid'],
                    platform_nickname=decision['nickname'],checked_at=time.strftime('%Y-%m-%dT%H:%M:%S'),
                    identity_revalidation_generation=attempt.attempt_id)
                if decision.get('avatar'):updated['platform_avatar_url']=decision['avatar']
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                    (json.dumps(updated,ensure_ascii=False),'accounts',account_id,tenant_id))
                db.commit()
        if recover_browser_session(store,account_dir,account_id,tenant_id)!='new_kept':return 'recovery_required'
        attempt.completed=True
        return 'committed'
    except Exception:
        # Journal/pending remains fail-closed. No fresh probe, claim or task replay.
        return 'recovery_required'


def commit_browser_session(store, account_dir, expected_account: Mapping,
                           decision: Mapping, candidate_cookie_path,
                           guard: Callable[[], bool], *, verified_resume=None) -> str:
    """Return committed or a fixed failure code; never disclose credentials.

    The guard must recheck cancellation, cloud pause, claim validity and the
    service's account lock. It is called before staging and immediately before
    the database update. The caller must run recovery under that same lock
    before starting another login, even after a failed result.
    """
    journal_path = None
    staged = None
    try:
        account_id, tenant_id = expected_account['id'], expected_account['tenant_id']
        config, active, journal_path = _paths(store, Path(account_dir), account_id, tenant_id)
        if (expected_account.get('platform') != 'xiaohongshu'
                or decision.get('verified') is not True or decision.get('status') != 'ready'
                or not isinstance(decision.get('uid'), str) or not decision['uid']
                or not callable(guard)):
            return 'identity_invalid'
        bound = expected_account.get('platform_uid')
        if bound and bound != decision['uid']:
            return 'identity_mismatch'
        nickname = decision.get('nickname')
        avatar = decision.get('avatar')
        if not isinstance(nickname, str) or not nickname or nickname == 'Unknown' or len(nickname) > 100:
            return 'identity_invalid'
        if not isinstance(avatar, str) or len(avatar) > 2048 or (avatar and xhs_image_url(avatar) != avatar):
            return 'identity_invalid'
        if recover_browser_session(store, account_dir, account_id, tenant_id) != 'clean':
            return 'recovery_required'
        if guard() is not True:
            return 'guard_failed'
        if verified_resume is not None:
            from core.xhs_verified_resume import failed_page
            if (type(verified_resume) is not dict or not expected_account.get('platform_uid')
                    or failed_page(account_dir,verified_resume.get('task'),verified_resume.get('scope'))!=verified_resume):
                return 'verification_receipt_changed'
        source = Path(candidate_cookie_path)
        if not _controlled_candidate(Path(account_dir), source):
            return 'candidate_invalid'
        if not _valid_candidate(source):
            return 'candidate_invalid'
        if _reparse(active) or _reparse(journal_path):
            return 'scope_invalid'
        config.mkdir(parents=True, exist_ok=True)
        nonce = secrets.token_hex(16)
        backup = config / ('.cookies.auth-backup-' + nonce + '.json')
        staged = config / ('.cookies.auth-new-' + nonce + '.json')
        if any(path.exists() or _reparse(path) for path in (backup, staged, journal_path)):
            return 'recovery_required'
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = _db_account(db, account_id, tenant_id)
            if current is None:
                return 'account_deleted'
            if (current.get('id') != account_id or current.get('tenant_id') != tenant_id
                    or current.get('platform') != 'xiaohongshu'):
                return 'scope_invalid'
            if account_revision(current) != account_revision(expected_account):
                return 'account_changed'
            if current.get('platform_uid') and current['platform_uid'] != decision['uid']:
                return 'identity_mismatch'
            duplicate = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=? AND id<>?',
                                   ('accounts', tenant_id, account_id)).fetchall()
            if any((other := json.loads(row['body'])).get('platform') == 'xiaohongshu'
                   and other.get('platform_uid') == decision['uid'] for row in duplicate):
                return 'duplicate_identity'
            if guard() is not True:
                return 'guard_failed'
            journal = {'version': 1, 'account_id': account_id, 'tenant_id': tenant_id,
                       'nonce': nonce, 'old_generation': str(current.get('auth_generation') or ''),
                       'new_generation': nonce, 'old_exists': active.exists()}
            _write_journal(journal_path, journal)
            # The journal must exist before staging any credential file so a
            # process crash can always identify and remove a partial copy.
            # Only the new verified candidate is copied. Old credentials are
            # never read, copied, serialized, or included in the journal.
            with source.open('rb') as incoming, staged.open('xb') as outgoing:
                shutil.copyfileobj(incoming, outgoing)
                outgoing.flush()
                os.fsync(outgoing.fileno())
            staged.chmod(0o600)
            if not _valid_candidate(staged):
                raise ValueError('candidate_invalid')
            _sync_dir(config)
            if journal['old_exists']:
                os.replace(active, backup)
            os.replace(staged, active)
            _sync_dir(config)
            if guard() is not True:
                raise _GuardRejected()
            if verified_resume is not None and failed_page(account_dir,verified_resume['task'],verified_resume['scope'])!=verified_resume:
                raise _GuardRejected()
            updated = dict(current)
            updated.pop('browser_verification_receipt',None)
            if verified_resume is not None:
                updated['browser_verification_receipt']={**verified_resume,'version':1,'at':time.time(),
                    'account_id':account_id,'tenant_id':tenant_id,
                    'uid_sha256':hashlib.sha256(decision['uid'].encode()).hexdigest(),
                    'auth_generation':nonce,'credential_sha256':hashlib.sha256(active.read_bytes()).hexdigest()}
            updated.update(status='ready', checked_at=time.strftime('%Y-%m-%dT%H:%M:%S'),
                           platform_uid=decision['uid'], platform_nickname=nickname,
                           auth_generation=nonce)
            if avatar:
                updated['platform_avatar_url'] = avatar
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                       (json.dumps(updated, ensure_ascii=False), 'accounts', account_id, tenant_id))
        result = recover_browser_session(store, account_dir, account_id, tenant_id)
        return 'committed' if result == 'new_kept' else 'recovery_required'
    except _GuardRejected:
        result = recover_browser_session(store, account_dir, account_id, tenant_id)
        return 'guard_failed' if result == 'old_restored' else 'recovery_required'
    except Exception:
        # The persisted journal tells recovery which generation is authoritative.
        if journal_path is not None and journal_path.exists():
            result = recover_browser_session(store, account_dir, account_id, tenant_id)
            if result not in ('old_restored', 'new_kept'):
                return 'recovery_required'
            return 'committed' if result == 'new_kept' else 'commit_failed'
        return 'commit_failed'
    finally:
        if staged is not None and journal_path is not None and not journal_path.exists():
            try:
                staged.unlink(missing_ok=True)
            except OSError:
                pass
