"""r57 normal-launch adapter over the existing TUF/ReleaseStore transaction.

Trusted constructor inputs come only from the fixed installer/launcher. Remote
commands cannot supply paths, trust roots, probes or entry-support assertions.
The fixed launcher holds normal_launch() for the entire application lifetime.
This module never starts, ends or restarts a process, platform task or provider.
"""
from contextlib import contextmanager
import hashlib
import importlib.util
import json
import os
from pathlib import Path,PurePosixPath
import re
import stat
import sys
import uuid

from tuf.api.metadata import Metadata
from assistant.update_coordinator import _file_lock

COMPANY_ID = 'fangyu-apartment-client'
SCHEMA = 'fangyu-r57-managed-closure-v1'
GUARDED_COMPANY_FIELDS = frozenset(('id','releaseSequence','releaseVersion','runtime','edition',
    'personalMode','authMode','platforms','accountLimit','features','managedWorkspace','updateFeed',
    'acquisitionStrategy','productEntitlements'))
BINDING = 'project/work/ui-native-r57/state/production-workspace.json'
_HEX = re.compile(r'[a-fA-F0-9]{64}')


class R57UpdateError(ValueError):
    code = 'R57_UPDATE_REVIEW_REQUIRED'


def _plain(path, *, directory=False):
    path = Path(path).absolute()
    for part in (path,*path.parents):
        info = part.lstat()
        if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise R57UpdateError('可信更新路径包含链接或重定向')
    info = path.stat()
    if (directory and not stat.S_ISDIR(info.st_mode) or not directory
            and (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1)):
        raise R57UpdateError('可信更新文件必须为独立普通文件')
    return info


def _read(path,limit=4*1024*1024):
    before = _plain(path)
    if before.st_size>limit:
        raise R57UpdateError('可信更新元数据尺寸无效')
    with Path(path).open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(limit+1)
        ended = os.fstat(stream.fileno())
    after = _plain(path)
    identity = lambda value:(value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns)
    if len(raw)>limit or not identity(before)==identity(opened)==identity(ended)==identity(after):
        raise R57UpdateError('可信更新文件在校验时变化')
    return raw


def _digest(path,size):
    before = _plain(path)
    if type(size) is not int or not 0<=size<=4*1024**3 or before.st_size!=size:
        raise R57UpdateError('完整闭包文件尺寸不一致')
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        opened = os.fstat(stream.fileno())
        for block in iter(lambda:stream.read(1024*1024),b''):
            value.update(block)
        ended = os.fstat(stream.fileno())
    after = _plain(path)
    identity = lambda info:(info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)
    if not identity(before)==identity(opened)==identity(ended)==identity(after):
        raise R57UpdateError('完整闭包文件在校验时变化')
    return value.hexdigest()


def _relative(value):
    if not isinstance(value,str) or not value or len(value)>500:
        raise R57UpdateError('完整闭包文件名无效')
    path = PurePosixPath(value)
    if (path.is_absolute() or str(path)!=value or '..' in path.parts or '\\' in value or ':' in value
            or any(part.endswith((' ','.')) for part in path.parts)):
        raise R57UpdateError('完整闭包文件路径越界')
    return path


class R57ManagedEntry:
    def __init__(self,coordinator,*,state_root,binding_sha256,trusted_root_sha256,
                 bootstrap_release,bootstrap_closure_sha256):
        values = (binding_sha256,trusted_root_sha256,bootstrap_closure_sha256)
        if (any(not isinstance(value,str) or not _HEX.fullmatch(value) for value in values)
                or type(bootstrap_release) is not int or bootstrap_release<1
                or coordinator.install_root is None or coordinator.company.get('id')!=COMPANY_ID
                or coordinator.store.executable!='run_workbench.py'):
            raise R57UpdateError('r57固定更新入口参数未配置')
        self.coordinator = coordinator
        self.state_root = Path(state_root).absolute()
        self.binding_sha256 = binding_sha256.lower()
        self.trusted_root_sha256 = trusted_root_sha256.lower()
        self.bootstrap_release = bootstrap_release
        self.bootstrap_closure_sha256 = bootstrap_closure_sha256.lower()
        self._session = False
        self._selection = None

    @contextmanager
    def normal_launch(self):
        """Keep one normal launcher through apply, startup confirmation and exit."""
        if self._session:
            raise R57UpdateError('固定启动会话不能嵌套')
        with _file_lock(self.coordinator.install_root/'r57-normal-launch.lock'):
            self._session = True
            try:
                yield self
            finally:
                self._selection = None
                self._session = False

    def _require_session(self):
        if not self._session:
            raise R57UpdateError('更新仅允许在持有固定启动锁的正常重开中执行')

    def _binding(self,folder=None):
        raw = _read(self.state_root/'production-workspace.json',16384)
        if hashlib.sha256(raw).hexdigest()!=self.binding_sha256:
            raise R57UpdateError('原入口外部工作资料绑定已变化')
        if folder is not None and _read(Path(folder)/BINDING,16384)!=raw:
            raise R57UpdateError('新版本与原入口工作资料绑定不一致')

    def _attestation(self,release,*,cached=False):
        feed = self.coordinator.company.get('updateFeed') or {}
        root_raw = _read(Path(feed['trusted_root']))
        if hashlib.sha256(root_raw).hexdigest()!=self.trusted_root_sha256:
            raise R57UpdateError('固定公开更新信任根已变化')
        path = (self.coordinator.directory/'tuf/metadata/targets.json' if cached else
            self.coordinator.install_root/'r57-attestations'/f'{release}.targets.json')
        raw = _read(path)
        root,metadata = Metadata.from_bytes(root_raw),Metadata.from_bytes(raw)
        root.verify_delegate('targets',metadata)
        target = metadata.signed.targets.get(feed['target'])
        custom = target.custom if target else {}
        if (custom.get('company_id')!=COMPANY_ID or custom.get('release')!=release
                or custom.get('platform')!='windows-x64' or custom.get('channel')!=feed.get('channel','stable')
                or not isinstance(custom.get('r57_closure_sha256'),str)
                or not _HEX.fullmatch(custom['r57_closure_sha256'])):
            raise R57UpdateError('签名更新记录不属于本r57完整版本')
        # Installed metadata proves offline integrity only. Candidate freshness,
        # expiry, rollback and package hash are still checked by the coordinator.
        return custom['r57_closure_sha256'].lower(),raw

    def _save_attestation(self,release,raw):
        folder = self.coordinator.install_root/'r57-attestations'
        folder.mkdir(exist_ok=True)
        _plain(folder,directory=True)
        path = folder/f'{release}.targets.json'
        if path.exists():
            if _read(path)!=raw:
                raise R57UpdateError('已保存的版本签名记录不能被替换')
            return
        temp = folder/(uuid.uuid4().hex+'.tmp')
        try:
            with temp.open('xb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp,path)
        finally:
            temp.unlink(missing_ok=True)

    def _verify(self,folder,release,expected):
        folder = Path(folder).absolute()
        _plain(folder,directory=True)
        self._binding(folder)
        raw = _read(folder/'r57-closure.json')
        if hashlib.sha256(raw).hexdigest()!=expected:
            raise R57UpdateError('完整版本闭包与签名固定摘要不一致')
        manifest = json.loads(raw)
        if (set(manifest)!={'schema','company_id','release','release_id','manifest_sha256','company_guard','files'}
                or manifest['schema']!=SCHEMA or manifest['company_id']!=COMPANY_ID
                or type(manifest['release']) is not int or manifest['release']!=release
                or not isinstance(manifest['release_id'],str) or not 1<=len(manifest['release_id'])<=200
                or not isinstance(manifest['manifest_sha256'],str) or not _HEX.fullmatch(manifest['manifest_sha256'])
                or not isinstance(manifest['files'],list) or not 1<=len(manifest['files'])<=9998):
            raise R57UpdateError('r57完整版本闭包清单无效')
        files = set()
        folded = set()
        for item in manifest['files']:
            if (not isinstance(item,dict) or set(item)!={'path','size','sha256'}
                    or not isinstance(item['sha256'],str) or not _HEX.fullmatch(item['sha256'])):
                raise R57UpdateError('r57完整版本文件固定信息无效')
            relative = _relative(item['path'])
            name = str(relative)
            if (name in ('r57-closure.json','company.json') or name.casefold() in folded
                    or any(part.casefold() in ('private','owner-admin') for part in relative.parts)
                    or relative.suffix.casefold() in ('.sqlite','.sqlite3','.db','.dpapi','.key')):
                raise R57UpdateError('r57完整版本包含重复路径或运行私有数据')
            files.add(name)
            folded.add(name.casefold())
            if _digest(folder.joinpath(*relative.parts),item['size'])!=item['sha256'].lower():
                raise R57UpdateError('r57完整版本文件校验失败')
        required = {'run_workbench.py','ui/RELEASE.json','ui/ui_native_host.py',BINDING,
            'project/work/app/company.json'}
        if not required.issubset(files):
            raise R57UpdateError('r57完整版本缺少入口、配置或外部资料绑定')
        actual = set()
        for path in folder.rglob('*'):
            _plain(path,directory=path.is_dir())
            if path.is_file():actual.add(path.relative_to(folder).as_posix())
        if actual!=files|{'r57-closure.json','company.json'}:
            raise R57UpdateError('r57完整版本文件集合不一致')
        for path in (folder/'company.json',folder/'project/work/app/company.json'):
            company = json.loads(_read(path))
            guard = {key:company[key] for key in GUARDED_COMPANY_FIELDS if key in company}
            if (manifest['company_guard']!=guard or company.get('id')!=COMPANY_ID
                    or company.get('releaseSequence')!=release
                    or (company.get('runtime') or {}).get('executable')!='run_workbench.py'):
                raise R57UpdateError('r57公司配置或发行边界不一致')
        host_path = folder/'ui/ui_native_host.py'
        name = 'fangyu_r57_update_probe_'+uuid.uuid4().hex
        host = importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
        host.__file__ = str(host_path)
        # No application imports occur until every file has passed its pins.
        exec(compile(_read(host_path),str(host_path),'exec'),host.__dict__)
        ui_manifest,ui_files = host.verify_release(folder/'ui',manifest['manifest_sha256'])
        host.verify_backend_dependencies(folder/'ui',ui_files,folder/'project')
        if ui_manifest['release_id']!=manifest['release_id']:
            raise R57UpdateError('r57界面版本与完整闭包不一致')
        return {'release':release,'release_id':manifest['release_id'],'folder':str(folder),
            'project_root':str(folder/'project'),'ui_root':str(folder/'ui'),
            'manifest_sha256':manifest['manifest_sha256'],'closure_sha256':expected}

    def _active(self):
        active = self.coordinator.store.active()
        if not active:
            raise R57UpdateError('r57固定入口缺少已核验基线')
        release = active['release']
        expected = (self.bootstrap_closure_sha256 if release==self.bootstrap_release
            else self._attestation(release)[0])
        return self._verify(self.coordinator.store.releases/str(release),release,expected)

    def prepare_normal_launch(self,probe):
        """Apply only on ordinary reopen; probe uses the coordinator's cloned DB."""
        self._require_session()
        if self._selection is not None or not callable(probe):
            raise R57UpdateError('正常重开准备不能重复或缺少健康检查')
        self._binding()
        recovered = self.coordinator.recover_interrupted()
        if recovered['status']=='awaiting_close':
            raise R57UpdateError('工作台仍在运行，请先正常关闭')
        self._active()
        def candidate(executable,folder,cloned):
            company = json.loads(_read(folder/'company.json'))
            release = company['releaseSequence']
            expected,raw = self._attestation(release,cached=True)
            selection = self._verify(folder,release,expected)
            if probe(executable,folder,cloned,dict(selection)) is not True:
                return False
            self._save_attestation(release,raw)
            return True
        applied = self.coordinator.apply_pending_on_launch(candidate)
        if applied['status']=='awaiting_close':
            raise R57UpdateError('工作台仍在运行，请先正常关闭')
        selected = self._active()
        selected['requires_confirmation'] = applied['status']=='awaiting_confirmation'
        self._selection = dict(selected)
        return dict(selected)

    def confirm_runtime_ready(self,selection,healthcheck):
        """Host calls before workers or HTTP actions become available."""
        self._require_session()
        if (not isinstance(selection,dict) or selection!=self._selection or not callable(healthcheck)):
            raise R57UpdateError('真实启动确认不属于本次固定入口选择')
        current = self._active()
        if any(current.get(key)!=value for key,value in selection.items() if key!='requires_confirmation'):
            raise R57UpdateError('真实启动前完整版本已变化')
        if healthcheck(dict(selection)) is not True:
            raise R57UpdateError('真实本地启动尚未通过健康检查')
        self._binding(Path(selection['folder']))
        if selection['requires_confirmation']:
            return self.coordinator.confirm_healthy(selection['release'])
        return self.coordinator.status()
