"""Read-only local checks for an existing private XHS strategy batch.

This is neither a lease nor permission to dispatch. Existing actual task run
guards must execute again. No account_spec, status tombstone, login or API probe.
"""
from copy import deepcopy
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
from pathlib import Path
import re
import time

from core import CoreError
from core.account_safety import summarize_activity
from core.platform_reads import _runtime_present
from core.platform_capabilities import platform_runtime_unavailable_reason
from core.service_plans import require_feature
from .acquisition_strategy import AcquisitionStrategy, ENTITY
from .strategy_tasks import StrategyTasks, TASK_OPERATIONS

ACTION = 'acquisition_run_preflight'
CONTRACT = 'acquisition_run_preflight_v1'
BLOCK = frozenset(('task_paused','task_exhausted','task_running','task_not_ready','account_not_ready',
    'account_removed','duplicate_platform_uid','activity_review_required','account_busy',
    'strategy_management_required','strategy_disabled','lease_expired','entitlement_denied',
    'platform_policy_hold','license_pending','task_outside_schedule'))
UNKNOWN = frozenset(('not_strategy_task','snapshot_unavailable','snapshot_changed','account_identity_unavailable',
    'activity_unavailable','occupancy_unavailable','batch_configuration_unavailable','license_unavailable',
    'quota_unavailable','local_limits_unavailable','local_daily_count_unavailable','platform_unsupported','schedule_unavailable'))
NEXT_STEPS = frozenset(('check_account','review_activity','wait_for_idle','check_snapshot','check_authorization',
    'check_configuration','explicit_single_batch_confirmation'))
CHECKS = ('snapshot','account_identity','activity','occupancy','batch_configuration','entitlement','local_collection_limits')
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_MAX = 2**53-1
_FLAGS = dict(read_only=True, local_only=True, storage_scope='this_device', cross_machine_verified=False,
    mutation_committed=False, auto_retry=False, platform_requests_started=False, provider_requests_started=False,
    cloud_requests_started=False, task_started=False, account_mode_acquired=False, live_checked=False,
    real_platform_verified=False, rate_safety_verified=False, request_upper_bound=None, estimated_duration_seconds=None)


class AcquisitionRunPreflightError(CoreError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status, self.mutation_committed = 'ACQUISITION_RUN_PREFLIGHT_'+code, status, False


def _fail(code, message, status=400):
    raise AcquisitionRunPreflightError(code, message, status)


def _hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _integer(value):
    return type(value) is int and 0 <= value <= _MAX


class AcquisitionRunPreflight:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, license_policy_provider,
                 page_policy_provider=None, clock=None):
        if (not isinstance(tenant,str) or not _ID.fullmatch(tenant) or not isinstance(owner,str) or not owner
                or not isinstance(company,dict) or not isinstance(company.get('id'),str) or not company['id']
                or not isinstance(device_id,str) or not _ID.fullmatch(device_id) or not callable(scope_guard)
                or not callable(license_policy_provider)
                or page_policy_provider is not None and not callable(page_policy_provider)):
            raise ValueError('预检需要可信本人、企业、设备和只读许可来源')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.device_id, self.scope_guard, self.license_policy_provider = device_id, scope_guard, license_policy_provider
        self.page_policy_provider = page_policy_provider
        self.binding = (company['id'],device_id)
        self.clock = clock or time.time

    def _scope(self):
        try: valid = (self.company.get('id'),self.device_id) == self.binding and self.scope_guard() is True
        except Exception: valid = False
        if not valid: _fail('SCOPE_CHANGED','企业、设备或员工范围已变化，请重新预检',409)

    def _capture(self, ident, user):
        self._scope()
        strategy = AcquisitionStrategy(self.core,self.tenant,self.owner,self.company)
        with self.core.store.connect() as db:
            db.execute('BEGIN')
            try:
                manager = strategy._authorize(db,user)
                actor = self.core._get('users',user['id'],self.tenant)
                if actor.get('cloud_bound') is not True: raise ValueError('unbound actor')
            except Exception: _fail('FORBIDDEN','预检仅限本人当前已绑定身份',403)
            try: task = self.core._get('tasks',ident,self.tenant)
            except CoreError: _fail('NOT_FOUND','任务不存在或无权预检',404)
            if task.get('cloud_owner') != self.owner: _fail('NOT_FOUND','任务不存在或无权预检',404)
            self.core._task_access(actor,task,self.tenant)
            account = None
            if task.get('account_id'):
                account = self.core._get('accounts',task['account_id'],self.tenant)
                self.core._account_access(actor,account)
            accounts = self.core.store.list('accounts',self.tenant)
            saved = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (ENTITY,strategy.ident,self.tenant)).fetchone()
            policy = json.loads(saved['body']) if saved else None
            mode = self.core.account_mode_status(account['id'],self.tenant) if account else None
            source = task.get('strategy_source') or {}
            operation = None
            if isinstance(source,dict) and source.get('operation_id'):
                row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    (TASK_OPERATIONS,source['operation_id'],self.tenant)).fetchone()
                operation = json.loads(row['body']) if row else None
            jobs = [json.loads(row['body']) for row in db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    ('continuous_tasks',ident,self.tenant))]
            leads = [row for row in self.core.store.list('leads',self.tenant) if row.get('task_id')==ident]
        try: license_policy = deepcopy(self.license_policy_provider())
        except Exception: license_policy = None
        # Only the App-owned private policy can describe this separate route.
        # This DTO does not carry a decision or authorize a platform request.
        page_description = None
        if self.page_policy_provider is not None:
            from .xhs_page_read_policy import XhsPageReadPolicy
            try:
                page_policy = self.page_policy_provider()
                if (type(page_policy) is XhsPageReadPolicy and page_policy.server.core is self.core
                        and getattr(self.core, '_xhs_page_read_policy', None) is page_policy
                        and getattr(page_policy.server, '_xhs_page_read_policy', None) is page_policy):
                    page_description = page_policy.describe()
            except Exception: page_description = dict(status='blocked',reason_codes=['platform_policy_hold'])
        manifests = self.core.adapters.manifests()
        manifest = next((row for row in manifests if row.get('id')==task.get('platform')),None)
        activity_path = None; activity_hash = None; activity = None
        if account and task.get('platform') == 'xiaohongshu':
            root = (self.core.store.directory/'accounts').resolve()
            path = root/self.tenant/account['id']/'platform-activity.jsonl'
            if not _ID.fullmatch(account['id']) or not path.resolve().is_relative_to(root):
                _fail('STORAGE_UNAVAILABLE','账号活动路径需核对，未读取凭据',503)
            activity_path = path
            try:
                if path.is_file() and path.stat().st_size > 16*1024*1024: raise ValueError('activity too large')
                activity_hash = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else 'not_recorded'
                activity = summarize_activity(path)
                after_activity = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else 'not_recorded'
                if activity_hash != after_activity: _fail('SCOPE_CHANGED','账号活动记录已变化，请重新预检',409)
            except (OSError,ValueError,UnicodeError): activity_hash,activity = 'unavailable',None
        value = dict(actor=actor,manager=manager,task=task,account=account,accounts=accounts,policy=policy,
            operation=operation,mode=mode,jobs=jobs,leads=leads,manifest=manifest,
            license_policy=license_policy,page_description=page_description,activity=activity,activity_hash=activity_hash,
            company=deepcopy(self.company),deployment=deepcopy(self.core.deployment_config),
            remote_hold=bool(self.core.remote_safety_hold),running=ident in self.core.running,
            sequence=ident in self.core.sequences)
        self._scope()
        return value, _hash(value)

    def _project(self, value, now):
        task, account, policy = value['task'],value['account'],value['policy']
        platform = task.get('platform') if isinstance(task.get('platform'),str) and _ID.fullmatch(task['platform']) else None
        checks = {name:{'status':'checked','reason_codes':[]} for name in CHECKS}
        def add(check,reason):
            checks[check]['reason_codes'].append(reason)
            checks[check]['status']='blocked' if reason in BLOCK or checks[check]['status']=='blocked' else 'unknown'
        count = None; quota = dict(unit='keyword_query_slots',total=None,spent=None,reserved=None,remaining=None,platform_http_limit=None)
        source = task.get('strategy_source')
        if not isinstance(source,dict): add('snapshot','not_strategy_task')
        elif not policy or not value['operation']: add('snapshot','snapshot_unavailable')
        else:
            lease = policy.get('lease')
            try:
                if (policy.get('id') != AcquisitionStrategy(self.core,self.tenant,self.owner,self.company).ident
                        or policy.get('tenant_id') != self.tenant or policy.get('owner') != self.owner
                        or source.get('owner') != self.owner or source.get('strategy_id') != policy['id']
                        # reserve_batch commits precisely one revision after the
                        # saved request revision; comparing equality rejects every real snapshot.
                        or not _integer(source.get('revision')) or not _integer(policy.get('revision'))
                        or source['revision']+1 != policy['revision']
                        or value['operation'].get('id') != source.get('operation_id')
                        or value['operation'].get('tenant_id') != self.tenant
                        or value['operation'].get('owner') != self.owner
                        or value['operation'].get('phase') != 'ready'
                        or value['operation'].get('task_id') != task['id']): raise ValueError('snapshot scope')
                StrategyTasks(self.core,self.tenant,self.owner,self.company)._validate_snapshot(task,lease)
                count = len(task['keywords'])
                if policy.get('enabled') is not True: add('snapshot','strategy_disabled')
                expiry = lease.get('expires_at')
                if type(expiry) not in (int,float) or not math.isfinite(expiry): add('snapshot','snapshot_unavailable')
                elif expiry <= now: add('snapshot','lease_expired')
                total,spent = policy.get('total_query_quota'),policy.get('queries_spent')
                reserved = len(lease['keywords'])
                if not _integer(total) or not _integer(spent) or total < spent+reserved: add('local_collection_limits','quota_unavailable')
                else: quota.update(total=total,spent=spent,reserved=reserved,remaining=total-spent-reserved)
            except Exception: add('snapshot','snapshot_changed')
        if not value['manager']: add('snapshot','strategy_management_required')
        if task.get('status')=='paused': add('local_collection_limits','task_paused')
        elif task.get('status')!='ready': add('local_collection_limits','task_not_ready')
        if task.get('exhausted') is True: add('local_collection_limits','task_exhausted')
        start,end=task.get('time_start','00:00'),task.get('time_end','23:59')
        if not all(isinstance(stamp,str) and re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]',stamp)
                   for stamp in (start,end)):
            add('local_collection_limits','schedule_unavailable')
        else:
            current=datetime.fromtimestamp(now,timezone(timedelta(hours=8))).strftime('%H:%M')
            in_hours=start<=current<=end if start<=end else current>=start or current<=end
            if not in_hours: add('local_collection_limits','task_outside_schedule')
        if task.get('account_removed'): add('account_identity','account_removed')
        if not account or account.get('platform')!=platform: add('account_identity','account_identity_unavailable')
        else:
            if account.get('status')!='ready': add('account_identity','account_not_ready')
            uid=account.get('platform_uid')
            if not isinstance(uid,str) or not _ID.fullmatch(uid): add('account_identity','account_identity_unavailable')
            elif any(row.get('id')!=account['id'] and row.get('platform')==platform and row.get('platform_uid')==uid
                     for row in value['accounts']): add('account_identity','duplicate_platform_uid')
        if platform != 'xiaohongshu': add('batch_configuration','platform_unsupported'); add('activity','activity_unavailable')
        else:
            safety=value['activity']
            if not safety or safety.get('state')=='no_data': add('activity','activity_unavailable')
            elif safety.get('state')=='review_required': add('activity','activity_review_required')
            elif safety.get('state')!='observe': add('activity','activity_unavailable')
            manifest=value['manifest'] or {}
            page=value['page_description']
            if page is not None:
                try:
                    self.core.require_platform(platform)
                    if value['remote_hold'] or platform_runtime_unavailable_reason(platform):
                        raise ValueError('platform unavailable')
                except Exception: add('batch_configuration','platform_policy_hold')
                if (page.get('route')!='natural_page_v1' or page.get('usage_scope')!='internal_self_use_read'
                        or page.get('status')!='checked' or page.get('reason_codes')!=[]):
                    reason='license_pending' if page.get('reason_codes')==['license_pending'] else 'platform_policy_hold'
                    add('batch_configuration',reason)
                # The old executable availability/global verification describe
                # the CLI. Actual page loading and first verification occur only
                # after explicit Business entry with its fresh private context.
                # CLI isolation_guard describes the old executable. The page
                # route uses its original Scope/Native owner, rechecked at run.
                if manifest.get('mapper')!='xhs_v1':
                    add('batch_configuration','batch_configuration_unavailable')
            else:
                try: self.core.require_platform(platform); self.core._platform_execution_guard(platform)
                except Exception: add('batch_configuration','platform_policy_hold')
                license_policy=value['license_policy']
                if not isinstance(license_policy,dict) or platform not in license_policy or type(license_policy[platform]) is not bool:
                    add('batch_configuration','license_unavailable')
                elif license_policy[platform] is not True: add('batch_configuration','license_pending')
                if (manifest.get('available') is not True or manifest.get('isolation_guard') is not True
                        or manifest.get('mapper')!='xhs_v1' or manifest.get('search_verified') is not True
                        or not _runtime_present(manifest,'search') or not _runtime_present(manifest,'comments')):
                    add('batch_configuration','batch_configuration_unavailable')
        if value['running'] or value['sequence'] or any(row.get('status') in ('queued','running','waiting') for row in value['jobs']):
            add('occupancy','task_running')
        mode=value['mode']
        if not isinstance(mode,dict) or mode.get('status') not in ('idle','active','paused','running'):
            add('occupancy','occupancy_unavailable')
        elif mode.get('status')!='idle': add('occupancy','account_busy')
        try: require_feature(self.company,'acquisition',now); require_feature(self.company,'strategy',now)
        except Exception: add('entitlement','entitlement_denied')
        limits=(task.get('target_count'),task.get('daily_limit'))
        if not all(_integer(limit) and limit>0 for limit in limits): add('local_collection_limits','local_limits_unavailable')
        else:
            if len(value['leads'])>=limits[0]: add('local_collection_limits','task_exhausted')
            today=datetime.fromtimestamp(now,timezone(timedelta(hours=8))).date()
            daily=0
            for lead in value['leads']:
                try:
                    stamp=datetime.fromisoformat(str(lead.get('created_at')).replace('Z','+00:00'))
                    if stamp.tzinfo is None: raise ValueError('legacy timezone')
                    daily+=int(stamp.astimezone(timezone(timedelta(hours=8))).date()==today)
                except (ValueError,TypeError,OverflowError): add('local_collection_limits','local_daily_count_unavailable'); break
            if daily>=limits[1]: add('local_collection_limits','task_exhausted')
        for check in checks.values(): check['reason_codes']=sorted(set(check['reason_codes']))
        reasons={reason for check in checks.values() for reason in check['reason_codes']}
        blocked,unknown=sorted(reasons&BLOCK),sorted(reasons&UNKNOWN)
        state='blocked' if blocked else 'unknown' if unknown else 'eligible_for_explicit_run'
        steps=set()
        mapping={'snapshot':'check_snapshot','account_identity':'check_account','activity':'review_activity',
                 'occupancy':'wait_for_idle','batch_configuration':'check_configuration','entitlement':'check_authorization',
                 'local_collection_limits':'check_snapshot'}
        for name,check in checks.items():
            if check['reason_codes']: steps.add(mapping[name])
        if state=='eligible_for_explicit_run': steps.add('explicit_single_batch_confirmation')
        return {**_FLAGS,'contract':CONTRACT,'task_id':task['id'],'platform':platform,'task_digest':_hash(task),
            'observed_at':int(now),'state':state,'blocking_reasons':blocked,'unknown_reasons':unknown,
            'next_steps':sorted(steps),'checks':checks,
            'snapshot':dict(kind='private_strategy_single_batch',planned_keyword_count=count,max_batches=1),'quota':quota}

    def execute(self,action,data,user):
        if action!=ACTION or not isinstance(data,dict) or set(data)!={'task_id'} or not isinstance(data['task_id'],str) or not _ID.fullmatch(data['task_id']):
            _fail('INVALID_INPUT','预检只接受本人已保存的任务编号',400)
        try:
            now=self.clock()
            if type(now) not in (int,float) or not math.isfinite(now) or not 1577836800 <= now <= _MAX:
                _fail('STORAGE_UNAVAILABLE','可信时间暂不可核对，请重读预检',503)
            with self.core.lock:
                before,fingerprint=self._capture(data['task_id'],user)
                result=self._project(before,now)
                _,after=self._capture(data['task_id'],user)
                if fingerprint!=after: _fail('SCOPE_CHANGED','任务、账号、许可或活动记录已变化，请重新预检',409)
                self._scope()
                return result
        except AcquisitionRunPreflightError: raise
        except Exception: _fail('STORAGE_UNAVAILABLE','本机任务或账号记录暂不可核对，未启动采集',503)
