"""Employee-local recorded activities, never a conversion or cash funnel.

No constructors create tables, no missing records become receipts.  Historical
activity and present risks deliberately remain separate.  Every date is server
selected Shanghai UTC+8 (2020 onward, a range with no daylight saving time).
"""
from copy import deepcopy
from datetime import date, datetime, time as daytime, timedelta, timezone
import hashlib
import json
import math
import re
import time

from core import CoreError
from core.response_journal import _normalized as normalized_response
from .acquisition_operations import AcquisitionOperations, HANDOFFS, EVENTS, STATUS_TEXT, _digest
from .customer_list import _person, _post
from .self_worklist import SelfWorklist, SelfWorklistError

ACTION = 'self_daily_evidence_summary'
CONTRACT = 'self_daily_evidence_v1'
SHANGHAI = timezone(timedelta(hours=8), name='Asia/Shanghai')
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_CONTACT = {'reviewed': 'reviewed_clients', 'sent': 'sent_reported_clients',
            'external_reported': 'external_reported_clients', 'copied': 'copied_clients'}
_HANDOFF = {'handoff_create': 'handoff_saved_clients', 'handoff_submit': 'handoff_submitted_clients'}
METRICS = (*_CONTACT.values(), *_HANDOFF.values(), 'nonself_receipt_recorded_clients')
REASONS = frozenset(('journal_unreadable', 'source_unavailable', 'source_changed',
    'identity_unverified', 'date_unavailable', 'future_record', 'reply_owner_unverified',
    'handoff_audit_unavailable', 'receipt_receiver_unavailable', 'response_evidence_unavailable',
    'reply_evidence_unavailable'))
_FLAGS = dict(read_only=True, mutation_committed=False, local_only=True,
    storage_scope='this_device', cross_machine_verified=False, platform_requests_started=False,
    provider_requests_started=False, ratings_modified=False, contacts_modified=False,
    handoffs_modified=False, auto_retry=False)


class SelfDailyEvidenceError(CoreError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status, self.mutation_committed = 'SELF_DAILY_EVIDENCE_'+code, status, False


def _fail(code, message, status=400):
    raise SelfDailyEvidenceError(code, message, status)


def _hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _uid(lead):
    platform, author = lead.get('platform'), lead.get('author_id')
    return ((platform, author) if isinstance(platform, str) and _ID.fullmatch(platform)
            and isinstance(author, str) and _ID.fullmatch(author) else None)


def _epoch(value):
    """Never borrow machine timezone or coerce boolean/float legacy dates."""
    if type(value) is int and value > 0:
        return value
    if isinstance(value, str):
        try:
            stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
            if stamp.tzinfo is not None and stamp.utcoffset() is not None:
                result = stamp.timestamp()
                return int(result) if math.isfinite(result) and result > 0 else None
        except (ValueError, OverflowError, OSError):
            pass
    return None


class SelfDailyEvidence:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access, clock=None):
        self.checker = SelfWorklist(core, tenant, owner, company, device_id=device_id,
            scope_guard=scope_guard, lead_access=lead_access)
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.device_id, self.clock = device_id, clock or time.time

    def _raw(self):
        """Capture extra dependencies absent from the owner-only worklist digest."""
        with self.core.store.connect() as db:
            db.execute('BEGIN')
            journal = [dict(row) for row in db.execute('SELECT * FROM contact_events '
                'WHERE tenant_id=? AND cloud_owner=? ORDER BY sequence', (self.tenant, self.owner))]
            records = [dict(row) for row in db.execute('SELECT entity,id,body FROM records '
                'WHERE tenant_id=? AND entity IN (?,?,?) ORDER BY entity,id',
                (self.tenant, HANDOFFS, EVENTS, 'users'))]
            responses = {}
            for table in ('customer_response_observations', 'contact_response_outbox'):
                exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
                responses[table] = [dict(row) for row in db.execute('SELECT * FROM '+table+
                    ' WHERE tenant_id=? AND cloud_owner=?', (self.tenant, self.owner))] if exists else []
        result = dict(journal=journal, records=records, responses=responses)
        return result, _hash(result)

    def _period(self, data, now):
        today = datetime.fromtimestamp(now, SHANGHAI).date()
        raw = data.get('day', today.isoformat())
        try:
            chosen = date.fromisoformat(raw) if isinstance(raw, str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}', raw) else None
        except ValueError:
            chosen = None
        if chosen is None or not date(2020, 1, 1) <= chosen <= today:
            _fail('INVALID_INPUT', '日期须为2020年至今天的上海日期 YYYY-MM-DD')
        start = int(datetime.combine(chosen, daytime(), SHANGHAI).timestamp())
        return dict(day=chosen.isoformat(), timezone='Asia/Shanghai', utc_offset='+08:00',
            start_epoch=start, end_epoch_exclusive=start+86400, basis='recorded_activity')

    def _aggregate(self, state, raw, period, now):
        counts = {key: set() for key in METRICS}
        event_counts = {key: 0 for key in METRICS}
        issues = {key: set() for key in METRICS}
        checked = {key: 0 for key in METRICS}
        visible = {lead['id']: lead for leads in state['groups'].values() for lead in leads}
        replies = {reply['id']: reply for reply in state['replies']}
        journal_by_id = {}
        receipt_cache = {}

        def add(metric, lead, stamp):
            uid = _uid(lead)
            if uid is None:
                issues[metric].add('identity_unverified'); return
            stamp = stamp if type(stamp) is int and stamp > 0 else None
            if stamp is None:
                issues[metric].add('date_unavailable'); return
            if stamp > now:
                issues[metric].add('future_record'); return
            checked[metric] += 1
            if period['start_epoch'] <= stamp < period['end_epoch_exclusive']:
                counts[metric].add(uid); event_counts[metric] += 1

        for row in raw['journal']:
            metric = _CONTACT.get(row['kind'])
            try:
                event = json.loads(row['payload'])
                original, reply = event['lead'], event['reply']
                if (event.get('event_id') != row['event_id'] or event.get('kind') != row['kind']
                        or reply.get('id') != row['reply_id'] or _hash(event) != row['payload_hash']
                        or hashlib.sha256(row['payload'].encode()).hexdigest() != row['payload_hash']):
                    raise ValueError('journal mismatch')
                cache_key = (reply['id'], original['id'])
                if cache_key not in receipt_cache:
                    receipt_cache[cache_key] = self.core.contact_journal.receipt(
                        self.tenant, self.owner, *cache_key)
                receipt = receipt_cache[cache_key]
                if receipt['local_integrity'] != 'ok':
                    raise ValueError('chain mismatch')
                lead = visible.get(original['id'])
                if lead is None:
                    if metric: issues[metric].add('source_unavailable')
                    continue
                if any(original.get(name) != str(lead.get(name) or '')
                       for name in ('platform', 'author_id', 'comment_id', 'task_id', 'text')):
                    if metric: issues[metric].add('source_changed')
                    continue
                saved_reply = replies.get(reply['id'])
                if (not saved_reply or saved_reply.get('tenant_id') != self.tenant or saved_reply.get('lead_id') != lead['id']
                        or saved_reply.get('author_id') != state['actor']['id']):
                    if metric: issues[metric].add('reply_owner_unverified')
                    continue
                journal_by_id[row['event_id']] = event
                if metric: add(metric, lead, event.get('occurred_at'))
            except Exception:
                # A corrupted kind/UID cannot establish which card is complete.
                for name in _CONTACT.values(): issues[name].add('journal_unreadable')

        # A current claimed outcome without its own intact immutable kind is
        # legacy/missing evidence, not proof that the whole daily card is zero.
        evidence = {(event['reply']['id'], event['kind']) for event in journal_by_id.values()}
        expected_kinds = {'approved':'reviewed', 'sent':'sent', 'copied':'copied',
                          'external_reported':'external_reported'}
        for reply in state['replies']:
            kind = expected_kinds.get(reply.get('status'))
            if kind and reply.get('author_id') == state['actor']['id']:
                metric = _CONTACT[kind]
                if reply.get('lead_id') not in visible:
                    issues[metric].add('source_unavailable')
                elif (reply['id'], kind) not in evidence:
                    issues[metric].add('reply_evidence_unavailable')

        ops = AcquisitionOperations(self.core, self.tenant, self.owner, self.company,
            lead_access=self.checker.lead_access)
        users = {}
        items = []
        for row in raw['records']:
            item = json.loads(row['body'])
            if row['entity'] == 'users': users[item['id']] = item
            elif row['entity'] == HANDOFFS and item.get('cloud_owner') == self.owner and item.get('company_id') == self.company['id']:
                items.append(item)
        with self.core.store.connect() as db:
            event_index = ops._event_index(db)
            for item in items:
                try:
                    ops._item(db, item['id'], state['actor'])
                    history = ops._events(db, item, event_index=event_index)
                    lead = visible.get(item['lead_id'])
                    if lead is None: raise ValueError('source unavailable')
                    source = item.get('source') or {}
                    if (item.get('customer_key') != _person(lead)[0]
                            or any(source.get(name) != lead.get(name) for name in ('platform', 'author_id', 'comment_id', 'task_id'))
                            or source.get('original_text_hash') != _digest(lead.get('text', ''))):
                        for name in (*_HANDOFF.values(), 'nonself_receipt_recorded_clients'):
                            issues[name].add('source_changed')
                        continue
                    for event in history:
                        if (event.get('tenant_id') != self.tenant or event.get('company_id') != self.company['id']
                                or event.get('handoff_id') != item['id']
                                or event.get('action') not in ('handoff_create','handoff_update','handoff_submit','handoff_receipt')
                                or event.get('status') not in STATUS_TEXT
                                or event.get('action') == 'handoff_create' and event.get('status') != 'draft'
                                or event.get('action') == 'handoff_submit' and event.get('status') != 'ready_to_deliver'):
                            raise ValueError('event scope mismatch')
                        metric = _HANDOFF.get(event['action'])
                        if metric:
                            if (event.get('actor_id') != state['actor']['id'] or event.get('actor') != self.owner):
                                raise ValueError('source actor mismatch')
                            add(metric, lead, event.get('server_recorded_at'))
                        if event['action'] == 'handoff_receipt' and event['status'] == 'accepted':
                            metric = 'nonself_receipt_recorded_clients'
                            receiver = users.get(event.get('actor_id'))
                            if (not receiver or receiver.get('tenant_id') != self.tenant or receiver.get('id') == state['actor']['id']
                                    or event.get('actor') == item['submitted_by']
                                    or receiver.get('username') != event.get('actor') or receiver.get('disabled')
                                    or receiver.get('role') not in ('admin', 'operator')
                                    or receiver.get('cloud_bound') is not True
                                    or not ops._receiver(receiver, item['recipient_id'])):
                                issues[metric].add('receipt_receiver_unavailable'); continue
                            add(metric, lead, event.get('server_recorded_at'))
                except Exception:
                    for name in (*_HANDOFF.values(), 'nonself_receipt_recorded_clients'):
                        issues[name].add('handoff_audit_unavailable')

        # Current explicit observations are not immutable first-match daily events.
        response_keys, response_bad, outbox = set(), False, []
        for row in raw['responses']['customer_response_observations']:
            try:
                value = json.loads(row['body'])
                if (not isinstance(value, dict) or value.get('platform') != row['platform']
                        or value.get('comment_id') != row['comment_id']):
                    raise ValueError('response identity changed')
            except Exception:
                response_bad = True
        for row in raw['responses']['contact_response_outbox']:
            try:
                value = json.loads(row['payload'])
                normalized = normalized_response(value)
                response = normalized['response']
                post = re.search(r'/([A-Za-z0-9]{24})/?$', response['note_url'])
                if (normalized != value or _hash(value) != row['payload_hash']
                        or value['observation_id'] != row['observation_id']
                        or response['platform'] != row['platform'] or response['comment_id'] != row['comment_id']
                        or not post or post.group(1).lower() != row['post_key']):
                    raise ValueError('response outbox identity changed')
                outbox.append(value)
            except Exception:
                response_bad = True
        for key, person in state['people'].items():
            for response in person.get('incoming_replies', []):
                sent = journal_by_id.get(response.get('sent_event_id'))
                matched = (sent and sent.get('kind') == 'sent'
                        and sent['reply'].get('platform_reply_id') == response.get('platform_reply_id')
                        and response.get('target_comment_id') == response.get('platform_reply_id')
                        and _uid(sent['lead']) is not None
                        and _epoch(response.get('published_at')) is not None
                        and _epoch(sent.get('occurred_at')) is not None
                        and _epoch(response.get('published_at')) > _epoch(sent.get('occurred_at')))
                if matched and response.get('source') == 'response_check':
                    matches = [entry for entry in outbox if entry['sent_event_id'] == response.get('sent_event_id')
                        and entry['local_reply_id'] == response.get('reply_id')
                        and entry['origin_comment_id'] == sent['lead']['comment_id']
                        and entry['platform_reply_id'] == response.get('platform_reply_id')
                        and entry['response']['platform'] == sent['lead']['platform']
                        and entry['response']['author_id'] == sent['lead']['author_id']
                        and entry['response']['comment_id'] == response.get('comment_id')
                        and entry['response']['target_comment_id'] == response.get('target_comment_id')
                        and entry['response']['target_author_id'] == sent['sender'].get('platform_uid')
                        and entry['response']['text'] == response.get('text')
                        and entry['response']['published_at'] == _epoch(response.get('published_at'))
                        and _post({'id':'response', 'platform':entry['response']['platform'],
                                  'note_url':entry['response']['note_url']})[0] == _post(sent['lead'])[0]]
                    matched = len(matches) == 1
                if matched:
                    response_keys.add(_uid(sent['lead']))
                else:
                    response_bad = True
        worklist = self.checker._rows(state)
        stable_keys = {key for key, leads in state['groups'].items() if all(_uid(lead) for lead in leads)}
        risk_keys = {item['author_key'] for item in worklist if item['lane'] == 'check_record'}
        ready = {key for key, items in state['handoffs'].items()
            if key in stable_keys and any(item.get('eligible_for_delivery') is True for item in items)}
        activities = [dict(key=key, value=None if issues[key] else len(counts[key]),
            unit='unique_clients', event_count=None if issues[key] else event_counts[key],
            coverage_status='incomplete' if issues[key] else 'complete',
            checked_record_count=checked[key], reason_codes=sorted(issues[key]),
            clock_basis='local_recorded_epoch', evidence_level='local_chain_checked_record',
            authority='authorized_local_actor_current_receiver_checked' if key == 'nonself_receipt_recorded_clients'
                      else 'local_device_report') for key in METRICS]
        unsupported = [dict(key=key, value=None, reason_code=reason) for key, reason in (
            ('first_found_clients', 'first_saved_date_not_recorded'),
            ('first_qualified_clients', 'historical_assessment_not_reconstructable'),
            ('actual_customer_consent_clients', 'actual_consent_date_not_verified'),
            ('first_response_confirmed_clients', 'first_match_date_not_immutable'),
            ('verified_cash_cents', 'financial_authority_not_connected'),
            ('verified_paid_commission_cents', 'financial_authority_not_connected'))]
        current_handoff_bad = any(issues[key] & {'source_changed', 'handoff_audit_unavailable'}
            for key in (*_HANDOFF.values(), 'nonself_receipt_recorded_clients'))
        return dict(activities=activities, unsupported=unsupported,
            current=dict(basis='current_authorized_snapshot', stable_uid_clients=len(stable_keys),
                provisional_identity_clients=len(state['groups'])-len(stable_keys),
                needs_check_clients=len(risk_keys & stable_keys),
                provisional_needs_check_clients=len(risk_keys-stable_keys),
                explicit_response_observed_clients=None if response_bad else len(response_keys),
                response_coverage_status='incomplete' if response_bad else 'complete',
                response_reason_codes=['response_evidence_unavailable'] if response_bad else [],
                ready_to_deliver_clients=None if current_handoff_bad else len(ready),
                handoff_coverage_status='incomplete' if current_handoff_bad else 'complete'),
            coverage=dict(scope='currently_authorized_local_sources', complete=not any(issues.values()) and not response_bad,
                stage_missing_dates_are_not_zero=True, historical_receiver_permission_snapshot_available=False))

    def execute(self, action, data, user):
        if action != ACTION or not isinstance(data, dict) or set(data)-{'day'}:
            _fail('INVALID_INPUT', '每日进展只接受上海日期，不接受员工、来源或可信数量')
        try:
            now = self.clock()
            if type(now) not in (int, float) or not math.isfinite(now) or now <= 0:
                _fail('CLOCK_UNAVAILABLE', '本机可信日期暂不可核对，请稍后重读', 503)
            period = self._period(data, now)
            with self.core.lock:
                before = self.checker._capture(user)
                raw, raw_hash = self._raw()
                result = self._aggregate(before, raw, period, now)
                after = self.checker._capture(user)
                _, final_hash = self._raw()
                if before['fingerprint'] != after['fingerprint'] or raw_hash != final_hash:
                    _fail('SCOPE_CHANGED', '读取期间身份、来源、回执或权限已变化，请重新读取每日进展', 409)
                self.checker._scope()
                return {**_FLAGS, 'contract': CONTRACT, 'period': period, 'observed_at': int(now),
                    'scope': {'subject': 'current_actor', 'deduplication': 'platform_uid_per_stage_per_day'},
                    'is_conversion_funnel': False, 'historical_activities_do_not_prove_current_authorization': True,
                    'platform_provenance_verified': False, 'financial_receipt_verified': False, **result}
        except SelfDailyEvidenceError:
            raise
        except SelfWorklistError as exc:
            _fail('SCOPE_CHANGED' if exc.status == 409 else 'FORBIDDEN' if exc.status == 403 else 'STORAGE_UNAVAILABLE',
                  '每日进展仅限本人当前有权资料，请核对身份和本机记录后重读', exc.status)
        except Exception:
            _fail('STORAGE_UNAVAILABLE', '本机记录暂不可核对，未返回虚构零业绩，请保留记录后重试', 503)
