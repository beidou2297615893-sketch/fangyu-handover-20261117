"""Owner-only passive comment observation and durable original-key custody.

GET is metadata only. Only an explicit START saves an attempt; reviewed Native
IO follows that commit and a second creation-submission commit. Old unknown
attempts are never retired by new text, identity, permission or source errors.
"""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import threading
import time

from .self_operating_read import OwnerReadWorkspace, _OwnerReadInstance
from .self_operating_acquisition import OwnerAcquisition, OwnerAcquisitionError, _ACTOR, _ACCOUNT, _identity
from .owner_contact_observation_policy import OwnerContactObservationPolicy, _OwnerObservationDecision
from .platform_receipt_archive import BATCHES, RECEIPTS, _safe_url

CONTRACT = 'owner_web_contact_observation_v1'
PREFIX = 'owner_web_contact_observation_'
ACTIONS = frozenset(PREFIX + name for name in ('start', 'get', 'cancel'))
ATTEMPTS = 'owner_web_contact_observation_attempts_v1'
HEADS = 'owner_web_contact_observation_heads_v1'
CUSTODY = 'owner_web_contact_observation_custody_v1'
_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9:_-]{0,255}\Z')
_KEY = re.compile(r'[a-f0-9]{64}\Z')
_SEAL = object()
_COMMON = {'id', 'tenant_id', 'instance_id', 'actor_digest', 'record_hash'}
_ATTEMPT_FIELDS = _COMMON | {'base', 'sequence', 'account_id', 'lead_id', 'uid_digest',
    'account_digest', 'connection_digest', 'binding', 'draft_hash', 'review_digest',
    'created_at', 'updated_at', 'creation_submitted', 'window_created',
    'platform_requests_started', 'native_stage', 'state', 'evidence_kind', 'observed_at',
    'snapshot_hash', 'platform_comment_digest', 'sender_uid_digest', 'cleanup_state',
    'cancel_requested', 'next_intent'}
_HEAD_FIELDS = _COMMON | {'account_id', 'lead_id', 'sequence', 'key', 'predecessor', 'consumed'}
_CUSTODY_FIELDS = _COMMON | {'account_id', 'lead_id', 'sequence', 'key', 'base',
    'uid_digest', 'kind', 'active'}
_BINDING_FIELDS = {'schema', 'local_instance_id', 'actor_digest', 'account_id',
    'account_digest', 'lead_id', 'source_id', 'source_digest', 'batch_id', 'batch_digest',
    'receipt_id', 'receipt_digest', 'privacy_redacted'}
_TERMINAL = frozenset(('observed_sent', 'observed_failed', 'cancelled'))
_STAGES = ('prepared', 'creation_submitted', 'window_created', 'canonical_navigation_submitted', 'observing')


def _hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _fail(message, mutation=False):
    raise OwnerAcquisitionError(message, mutation_committed=mutation)


@dataclass(frozen=True)
class _OwnerObservationSpec:
    instance_id: str
    tenant_id: str
    actor_id: str
    owner: str
    account_id: str
    account_uid: str
    connection_digest: str
    lead_id: str
    source_id: str
    source_digest: str
    archive_batch_id: str
    archive_receipt_id: str
    idempotency_key: str
    sequence: int
    draft_hash: str
    note_id: str
    target_comment_id: str
    canonical_url: str
    account_dir: Path
    profile_dir: Path
    attempt_dir: Path
    review_digest: str


class _OwnerObservationFrame:
    def __init__(self, module, token, spec, decision, seal):
        if (seal is not _SEAL or type(module) is not OwnerWebContactObservation
                or type(spec) is not _OwnerObservationSpec
                or type(decision) is not _OwnerObservationDecision):
            _fail('本人网页观察范围未建立')
        self.module, self._token, self.spec, self.decision = module, token, spec, decision
        self._seal = seal
        self.holder = None
        self._user = None
        self._worker = None
        self._finisher = None
        self._launching = True
        self._launch_done = threading.Event()

    def check(self):
        return self.module._frame_check(self)

    @contextmanager
    def native_barrier(self, holder):
        # Slow image/file/IPC work belongs outside this narrow barrier. The
        # holder may submit one ResumeThread or issue only inside the yield.
        from .owner_contact_observation_native import _OwnerNativeAttempt
        if type(holder) is not _OwnerNativeAttempt or self.holder is not holder or holder.frame is not self:
            _fail('本人网页观察原窗口已变化', None)
        with self.module.core.lock, self.module._lock:
            self.check()
            yield

    def creation_submitted(self):
        return self.module._creation_submitted(self)

    def retain(self, holder):
        from .owner_contact_observation_native import _OwnerNativeAttempt
        with self.module.core.lock, self.module._lock:
            if (type(holder) is not _OwnerNativeAttempt or holder.frame is not self
                    or self.holder is not None or self._seal is not _SEAL or not self._launching):
                _fail('本人网页窗口持有者不一致', None)
            self.check()
            self.holder = holder

    def native_phase(self, holder, phase):
        return self.module._native_phase(self, holder, phase)

    def publish(self, holder, evidence):
        return self.module._publish(self, holder, evidence)

    def cleanup(self, holder):
        return self.module._cleanup(self, holder)


class OwnerWebContactObservation:
    ACTIONS = ACTIONS

    def __init__(self, workspace):
        if (type(workspace) is not OwnerReadWorkspace or type(workspace.instance) is not _OwnerReadInstance
                or type(workspace._acquisition) is not OwnerAcquisition):
            _fail('网页观察必须从当前本人来源工作台建立')
        self.workspace = workspace
        self.acquisition = workspace._acquisition
        self.server, self.core, self.instance = workspace.server, workspace.server.core, workspace.instance
        self._store = self.core.store
        self.instance_id = self.instance.check()['selfOperatingRead']['instance_id']
        self.policy = OwnerContactObservationPolicy(workspace)
        self._lock = threading.RLock()
        self._frames = {}
        self._closing = False

    def describe(self):
        # No import/IO to a Native runtime, no editable review boolean grant.
        available = not self._closing and self.policy.resolve() is not None and all(
            (Path(__file__).parent / name).is_file() and not (Path(__file__).parent / name).is_symlink()
            for name in ('owner_contact_observation_native.py', 'owner_contact_observation_helper.py'))
        return {'contract': CONTRACT, 'available': available, 'owner_scope_only': True,
            'passive_only': True, 'automatic_send': False,
            'manual_claim_is_platform_proof': False, 'auto_retry': False}

    def _current(self, token):
        if (self.workspace._web_contact_observation is not self
                or self.workspace._acquisition is not self.acquisition
                or self.server.core is not self.core or self.workspace.instance is not self.instance
                or self.core.store is not self._store
                or self.instance.check()['selfOperatingRead']['instance_id'] != self.instance_id):
            _fail('原本人网页观察实例已变化', None)
        return self.acquisition._current(token)

    @contextmanager
    def _readonly(self):
        path = self._store.path
        if (not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1
                or path.parent != self.instance.directory / 'data'):
            _fail('原本人数据库不存在或需核对', None)
        db = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=0)
        db.row_factory = sqlite3.Row
        try:
            db.execute('PRAGMA query_only=ON')
            yield db
        finally:
            db.close()

    def _base(self, user, account_id, lead_id):
        return _hash(['owner-xhs-comment-observation-v1', user['tenant_id'], self.instance_id,
            user['id'], user['username'], account_id, lead_id])

    @staticmethod
    def _key(base, sequence):
        return _hash(['owner-xhs-comment-observation-attempt-v1', base, sequence])

    def _saved(self, db, entity, identifier, user):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (entity, identifier, user['tenant_id'])).fetchone()
        if row is None:
            return None
        try:
            value = json.loads(row['body'])
        except (ValueError, TypeError):
            _fail('原网页观察日志无法解析，请保留原号核对', None)
        if (type(value) is not dict or value.get('id') != identifier
                or value.get('tenant_id') != user['tenant_id']
                or value.get('instance_id') != self.instance_id
                or value.get('actor_digest') != _hash(_identity(user, _ACTOR))
                or value.get('record_hash') != _hash({k:v for k,v in value.items() if k != 'record_hash'})):
            _fail('原网页观察日志归属需核对', None)
        fields = {ATTEMPTS: _ATTEMPT_FIELDS, HEADS: _HEAD_FIELDS, CUSTODY: _CUSTODY_FIELDS}[entity]
        if (set(value) != fields or type(value.get('account_id')) is not str
                or not _ID.fullmatch(value['account_id']) or type(value.get('lead_id')) is not str
                or not _ID.fullmatch(value['lead_id']) or type(value.get('sequence')) is not int
                or not 1 <= value['sequence'] <= 1000000):
            _fail('原网页观察记录结构需核对', None)
        if entity == ATTEMPTS:
            self._validate_attempt(value, user)
        elif entity == HEADS:
            base = self._base(user, value['account_id'], value['lead_id'])
            pred = value['predecessor']
            if (identifier != base or value['key'] != self._key(base, value['sequence'])
                    or type(value['consumed']) is not bool
                    or value['sequence'] == 1 and pred is not None
                    or value['sequence'] > 1 and (type(pred) is not dict or set(pred) != {
                        'key', 'sequence', 'terminal_digest', 'intent'}
                        or pred['sequence'] != value['sequence'] - 1
                        or pred['key'] != self._key(base, pred['sequence'])
                        or type(pred['terminal_digest']) is not str or not _KEY.fullmatch(pred['terminal_digest'])
                        or pred['intent'] not in ('cancel_before_creation', 'prepare_next_round'))):
                _fail('原网页观察尝试头需核对', None)
        else:
            if (value['kind'] not in ('account', 'uid') or type(value['active']) is not bool
                    or type(value['uid_digest']) is not str or not _KEY.fullmatch(value['uid_digest'])
                    or value['base'] != self._base(user, value['account_id'], value['lead_id'])
                    or value['key'] != self._key(value['base'], value['sequence'])
                    or identifier != self._custody_id(user, value['kind'], value['account_id'], value['uid_digest'])):
                _fail('原账号观察占用需核对', None)
        return value

    def _validate_attempt(self, value, user):
        base = self._base(user, value['account_id'], value['lead_id'])
        binding = value['binding']
        if (value['base'] != base or value['id'] != self._key(base, value['sequence'])
                or any(type(value[k]) is not str or not _KEY.fullmatch(value[k]) for k in
                    ('uid_digest', 'account_digest', 'connection_digest', 'draft_hash', 'review_digest'))
                or type(binding) is not dict or set(binding) != _BINDING_FIELDS
                or binding['schema'] != 'local_owner_acquisition_v1'
                or binding['local_instance_id'] != self.instance_id
                or binding['actor_digest'] != value['actor_digest']
                or binding['account_id'] != value['account_id'] or binding['lead_id'] != value['lead_id']
                or binding['account_digest'] != value['account_digest']
                or type(binding['privacy_redacted']) is not bool
                or any(type(binding[k]) is not str or not _KEY.fullmatch(binding[k]) for k in
                    ('source_id', 'source_digest', 'batch_id', 'batch_digest', 'receipt_id', 'receipt_digest'))
                or type(value['creation_submitted']) is not bool or type(value['cancel_requested']) is not bool
                or any(value[k] is not None and type(value[k]) is not bool for k in
                    ('window_created', 'platform_requests_started'))
                or value['native_stage'] not in _STAGES or value['state'] not in
                    ('prepared', 'observing', 'observed_sent', 'observed_failed', 'unknown', 'cancelled')
                or value['cleanup_state'] not in ('not_started', 'open', 'pending', 'closed', 'unknown')
                or any(type(value[k]) not in (int, float) or not 0 < value[k] < 1e12
                    for k in ('created_at', 'updated_at'))):
            _fail('原网页观察绑定或阶段需核对', None)
        if not value['creation_submitted']:
            if (value['native_stage'] != 'prepared' or value['window_created'] is not False
                    or value['platform_requests_started'] is not False
                    or value['state'] not in ('prepared', 'cancelled')):
                _fail('原网页观察创建提交证据需核对', None)
        elif value['state'] in ('prepared', 'cancelled'):
            _fail('已提交窗口创建不能当未创建取消', None)
        if (value['state'] == 'cancelled' and (value['cleanup_state'] != 'closed'
                or value['cancel_requested'] is not True)
                or value['native_stage'] in _STAGES[2:] and value['window_created'] is not True
                or value['native_stage'] in _STAGES[3:] and value['platform_requests_started'] is not True
                or value['state'] == 'observing' and value['native_stage'] not in _STAGES[2:]):
            _fail('原观察历史窗口、平台或取消证据矛盾', None)
        known = value['state'] in ('observed_sent', 'observed_failed')
        if known:
            if (value['evidence_kind'] != 'owned_cdp_matched' or value['native_stage'] != 'observing'
                    or value['window_created'] is not True or value['platform_requests_started'] is not True
                    or type(value['observed_at']) is not str or re.fullmatch(
                        r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', value['observed_at']) is None
                    or type(value['snapshot_hash']) is not str or not _KEY.fullmatch(value['snapshot_hash'])
                    or value['state'] == 'observed_sent' and (any(type(value[k]) is not str
                        or not _KEY.fullmatch(value[k]) for k in ('platform_comment_digest', 'sender_uid_digest'))
                        or value['sender_uid_digest'] != value['uid_digest'])
                    or value['state'] == 'observed_failed' and any(value[k] is not None
                        for k in ('platform_comment_digest', 'sender_uid_digest'))):
                _fail('原平台观察安全回执需核对', None)
        elif (value['evidence_kind'] != 'none' or any(value[k] is not None for k in
                ('observed_at', 'snapshot_hash', 'platform_comment_digest', 'sender_uid_digest'))):
            _fail('未知记录不能代替平台观察回执', None)
        intent = value['next_intent']
        if intent is not None and (type(intent) is not dict or set(intent) != {
                'key', 'sequence', 'terminal_digest', 'intent'} or value['state'] not in ('cancelled', 'observed_sent')
                or value['cleanup_state'] != 'closed' or intent['sequence'] != value['sequence'] + 1
                or intent['key'] != self._key(base, intent['sequence'])
                or intent['terminal_digest'] != self._terminal_digest(value)
                or intent['intent'] != ('cancel_before_creation' if value['state'] == 'cancelled' else 'prepare_next_round')):
            _fail('原新轮人工意图需核对', None)

    @staticmethod
    def _terminal_digest(value):
        return _hash({k: value[k] for k in ('id', 'base', 'sequence', 'binding', 'draft_hash',
            'review_digest', 'state', 'evidence_kind', 'observed_at', 'snapshot_hash',
            'platform_comment_digest', 'sender_uid_digest', 'creation_submitted',
            'window_created', 'platform_requests_started', 'cleanup_state')})

    def _common(self, user, identifier):
        return {'id': identifier, 'tenant_id': user['tenant_id'], 'instance_id': self.instance_id,
            'actor_digest': _hash(_identity(user, _ACTOR))}

    def _put(self, db, entity, value):
        value['record_hash'] = _hash({k: v for k, v in value.items() if k != 'record_hash'})
        old = db.execute('SELECT tenant_id FROM records WHERE entity=? AND id=?',
            (entity, value['id'])).fetchone()
        if old is not None and old['tenant_id'] != value['tenant_id']:
            _fail('原网页观察记录不能跨主体替换', None)
        body = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
        if old is None:
            db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                (entity, value['id'], value['tenant_id'], body))
        else:
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (body, entity, value['id'], value['tenant_id']))

    def _custody_id(self, user, kind, account_id, uid_digest):
        # Stable actor identifiers: changing optional actor fields or the UID
        # on an existing account must not provide a new custody namespace.
        subject = account_id if kind == 'account' else uid_digest
        return _hash(['owner-observation-custody-v1', user['tenant_id'], self.instance_id,
            user['id'], user['username'], kind, subject])

    def _custodies(self, db, user, account_id, uid_digest=None):
        kinds = ('account', 'uid') if uid_digest is not None else ('account',)
        return [self._saved(db, CUSTODY, self._custody_id(user, kind, account_id, uid_digest), user)
            for kind in kinds]

    def _hold_custody(self, db, user, row, active):
        for kind in ('account', 'uid'):
            identifier = self._custody_id(user, kind, row['account_id'], row['uid_digest'])
            prior = self._saved(db, CUSTODY, identifier, user)
            if prior is not None and prior['active'] and prior['key'] != row['id']:
                _fail('此本人账号有原观察尚待核对，请保留原号', None)
            if not active and (prior is None or prior['key'] != row['id']):
                _fail('原账号观察占用与回执不一致', None)
            value = {**self._common(user, identifier), 'account_id': row['account_id'],
                'lead_id': row['lead_id'], 'sequence': row['sequence'], 'key': row['id'],
                'base': row['base'], 'uid_digest': row['uid_digest'], 'kind': kind, 'active': active}
            self._put(db, CUSTODY, value)

    def _head(self, db, user, account_id, lead_id):
        base = self._base(user, account_id, lead_id)
        head = self._saved(db, HEADS, base, user)
        return base, 1 if head is None else head['sequence'], head

    def _next_allowed(self, db, user, row):
        intent = row['next_intent']
        if intent is None:
            return False
        head = self._saved(db, HEADS, row['base'], user)
        expected = {'key': row['id'], 'sequence': row['sequence'],
            'terminal_digest': intent['terminal_digest'], 'intent': intent['intent']}
        return bool(head is not None and head['sequence'] == intent['sequence'] and head['key'] == intent['key']
            and head['predecessor'] == expected and head['consumed'] is False
            and self._saved(db, ATTEMPTS, intent['key'], user) is None
            and not any(c is not None and c['active'] for c in self._custodies(
                db, user, row['account_id'], row['uid_digest'])))

    def _view(self, db, user, row, action, mutation=False):
        return {'contract': CONTRACT, 'action': action, 'idempotency_key': row['id'],
            'account_id': row['account_id'], 'lead_id': row['lead_id'], 'state': row['state'],
            'evidence_kind': row['evidence_kind'], 'observed_at': row['observed_at'],
            'platform_reply_verified': row['state'] == 'observed_sent',
            'local_mutation_committed': mutation, 'platform_requests_started': row['platform_requests_started'],
            'window_created': row['window_created'], 'cleanup_state': row['cleanup_state'],
            'next_attempt_allowed': self._next_allowed(db, user, row), 'automatic_send': False, 'auto_retry': False}

    def _source(self, db, user, account_id, lead_id, binding=None):
        account, lead, source = self.acquisition._load_source_identity(db, user, account_id, lead_id)
        if binding is None:
            # Only bounded candidates of this primary source's digest. Each
            # chosen pair still passes the original full archive predicates.
            candidates = db.execute('''SELECT b.id batch_id,r.id receipt_id FROM records b JOIN records r
                ON r.entity=? AND r.tenant_id=b.tenant_id
                AND json_extract(CASE WHEN json_valid(r.body) THEN r.body ELSE '{}' END,'$.batch_id')=b.id
                WHERE b.entity=? AND b.tenant_id=?
                AND json_extract(CASE WHEN json_valid(b.body) THEN b.body ELSE '{}' END,'$.input_digest')=?
                AND json_extract(CASE WHEN json_valid(r.body) THEN r.body ELSE '{}' END,'$.state')='succeeded'
                ORDER BY b.id,r.id LIMIT 21''', (RECEIPTS, BATCHES, user['tenant_id'], source['input_digest'])).fetchall()
            if not 1 <= len(candidates) <= 20:
                _fail('本人原来源的成功归档回执需核对')
            accepted = []
            for candidate in candidates:
                try:
                    accepted.append(self.acquisition._load_source(db, user, account_id, lead_id,
                        _stored_binding={'batch_id': candidate['batch_id'], 'receipt_id': candidate['receipt_id']}))
                except OwnerAcquisitionError:
                    continue
            if not accepted:
                _fail('缺少本人原成功归档证据，不能建立观察')
            binding = min(accepted, key=lambda b: (b['batch_id'], b['receipt_id']))
        elif self.acquisition._load_source(db, user, account_id, lead_id,
                _stored_binding={'batch_id': binding['batch_id'], 'receipt_id': binding['receipt_id']}) != binding:
            _fail('本次原来源或成功归档回执已变化', None)
        return account, lead, source, binding

    def _current_source(self, db, token, row=None, account_id=None, lead_id=None, decision=None):
        user = self._current(token)
        if row is not None:
            account_id, lead_id = row['account_id'], row['lead_id']
        account, lead, source, binding = self._source(db, user, account_id, lead_id,
            None if row is None else row['binding'])
        ready = self.workspace._account(user, account_id)
        if ready != account:
            _fail('本人账号当前状态已变化', None if row is not None else False)
        self.workspace._require_activity_safe(user, account)
        if row is not None and (row['actor_digest'] != _hash(_identity(user, _ACTOR))
                or row['uid_digest'] != hashlib.sha256(account['platform_uid'].encode('utf-8')).hexdigest()
                or row['account_digest'] != _hash(_identity(account, _ACCOUNT))
                or row['connection_digest'] != source['connection_digest']):
            _fail('原本人账号、会话或来源已变化，请保留原号', None)
        if decision is not None and not self.policy.current(decision):
            _fail('本人网页观察用途或材料已变化', None if row is not None else False)
        return user, account, lead, source, binding

    @staticmethod
    def _unknown(action, key, account_id=None, lead_id=None):
        return {'contract': CONTRACT, 'action': action, 'idempotency_key': key,
            'account_id': account_id, 'lead_id': lead_id, 'state': 'unknown',
            'evidence_kind': 'none', 'observed_at': None, 'platform_reply_verified': False,
            'local_mutation_committed': False, 'platform_requests_started': None,
            'window_created': None, 'cleanup_state': 'unknown', 'next_attempt_allowed': False,
            'automatic_send': False, 'auto_retry': False}

    def _get(self, token, data):
        user = self._current(token)
        pair = set(data) == {'account_id', 'lead_id'}
        if not pair and set(data) != {'idempotency_key'}:
            _fail('网页核对只接受当前来源或原编号')
        with self._readonly() as db:
            if pair:
                if any(type(data[k]) is not str or not _ID.fullmatch(data[k]) for k in ('account_id', 'lead_id')):
                    _fail('请从当前本人已保存来源核对')
                self.acquisition._load_source_identity(db, user, data['account_id'], data['lead_id'])
                base, sequence, head = self._head(db, user, data['account_id'], data['lead_id'])
                key = self._key(base, sequence)
                result = self._unknown(PREFIX + 'get', key, data['account_id'], data['lead_id'])
            else:
                key = data['idempotency_key']
                if type(key) is not str or not _KEY.fullmatch(key):
                    _fail('请保留并核对原网页观察编号')
                result = self._unknown(PREFIX + 'get', key)
            prior = self._saved(db, ATTEMPTS, key, user)
            if prior is not None:
                if pair and (prior['account_id'] != data['account_id'] or prior['lead_id'] != data['lead_id']):
                    _fail('原网页观察记录与当前来源不一致', None)
                result = self._read_view(db, user, prior, PREFIX + 'get')
            fresh = self._current(token)
            if _identity(fresh, _ACTOR) != _identity(user, _ACTOR):
                _fail('核对期间本人主体已变化', None)
            if pair:
                self.acquisition._load_source_identity(db, fresh, data['account_id'], data['lead_id'])
            return result

    def _read_view(self, db, user, row, action, mutation=False):
        # No runtime probes or writes during GET. An interrupted Native phase
        # has no recovered live holder; it cannot be reported as observing.
        value = deepcopy(row)
        with self._lock:
            frame = self._frames.get(row['id'])
            live = frame is not None and frame._worker is not None and frame._worker.is_alive()
        if value['creation_submitted'] and value['cleanup_state'] != 'closed' and not live:
            if value['state'] not in ('observed_sent', 'observed_failed'):
                value['state'] = 'unknown'
            value['cleanup_state'] = 'unknown'
        return self._view(db, user, value, action, mutation)

    @contextmanager
    def _write(self):
        # Existing original Store only. The generic records table is already
        # mature; this module has no migration or DDL even on explicit START.
        path = self._store.path
        if (not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1
                or path.parent != self.instance.directory / 'data'):
            _fail('原本人数据库需核对，已保留原观察编号', None)
        with self._store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            yield db

    @staticmethod
    def _draft_valid(value):
        return type(value) is str and bool(value.strip()) and len(value) <= 1000 and '\x00' not in value

    def _existing_start(self, db, token, user, data):
        key = data.get('idempotency_key')
        row = self._saved(db, ATTEMPTS, key, user) if type(key) is str and _KEY.fullmatch(key) else None
        if row is None:
            account_id = data.get('account_id')
            if type(account_id) is str and _ID.fullmatch(account_id):
                custody = self._custodies(db, user, account_id)[0]
                if custody is not None and custody['active']:
                    _fail('此账号有原观察尚待核对，不能以新参数放弃原号', None)
            return None
        # Record first, including malformed/changed text. Never turn an older
        # unknown or creation-submitted call into a fresh preflight false.
        if (set(data) != {'account_id', 'lead_id', 'idempotency_key', 'draft_text', 'confirmed'}
                or data.get('confirmed') is not True or data.get('account_id') != row['account_id']
                or data.get('lead_id') != row['lead_id'] or not self._draft_valid(data.get('draft_text'))
                or hashlib.sha256(data['draft_text'].encode('utf-8')).hexdigest() != row['draft_hash']):
            _fail('已有原观察编号不能换正文或来源重开，请核对原号', None)
        try:
            account, lead, source, binding = self._source(db, user, row['account_id'], row['lead_id'], row['binding'])
            if (row['uid_digest'] != hashlib.sha256(account['platform_uid'].encode('utf-8')).hexdigest()
                    or row['account_digest'] != _hash(_identity(account, _ACCOUNT))
                    or row['connection_digest'] != source['connection_digest']):
                _fail('原账号身份或会话已变化', None)
        except Exception:
            _fail('原观察来源或账号已变化，请保留原号核对', None)
        return self._read_view(db, user, row, PREFIX + 'start')

    def _start(self, token, data):
        try:
            user = self._current(token)
        except Exception:
            _fail('本人观察身份需核对，请保留已取得的原号', None)
        with self._readonly() as db:
            previous = self._existing_start(db, token, user, data)
            if previous is not None:
                return previous
        required = {'account_id', 'lead_id', 'idempotency_key', 'draft_text', 'confirmed'}
        if (set(data) != required or data.get('confirmed') is not True
                or any(type(data.get(k)) is not str or not _ID.fullmatch(data[k]) for k in ('account_id', 'lead_id'))
                or type(data.get('idempotency_key')) is not str or not _KEY.fullmatch(data['idempotency_key'])
                or not self._draft_valid(data.get('draft_text'))):
            _fail('请明确当前来源和不超过1000字的本次人工草稿')
        original = self._get(token, {'account_id': data['account_id'], 'lead_id': data['lead_id']})
        if original['idempotency_key'] != data['idempotency_key']:
            _fail('请使用当前来源返回的固定原号')
        decision = self.policy.resolve()
        if decision is None:
            _fail('本人网页评论观察用途尚未通过审核；本次未建立窗口')
        # Read-only route availability before saving a fresh attempt. No
        # dynamic imports of an arbitrary caller factory or employee grant.
        if not self.describe()['available']:
            _fail('本人网页观察组件尚未完整组装；本次未建立窗口')
        from .owner_contact_observation_native import create
        persisted = False
        frame = None
        try:
            with self.core.lock, self._lock, self._write() as db:
                user = self._current(token)
                previous = self._existing_start(db, token, user, data)
                if previous is not None:
                    return previous
                base, sequence, head = self._head(db, user, data['account_id'], data['lead_id'])
                key = self._key(base, sequence)
                if key != data['idempotency_key'] or head is not None and head['consumed']:
                    _fail('请使用当前来源合法且未消费的固定原号')
                user, account, lead, source, binding = self._current_source(db, token,
                    account_id=data['account_id'], lead_id=data['lead_id'], decision=decision)
                uid_digest = hashlib.sha256(account['platform_uid'].encode('utf-8')).hexdigest()
                if any(c is not None and c['active'] for c in self._custodies(db, user, account['id'], uid_digest)):
                    _fail('原本人账号或UID仍有观察尚待核对，不能换来源重开', None)
                if head is not None:
                    predecessor = self._saved(db, ATTEMPTS, head['predecessor']['key'], user)
                    if (predecessor is None or predecessor['next_intent'] is None
                            or not self._next_allowed(db, user, predecessor)):
                        _fail('原新轮意图或前次收尾需核对', None)
                now = time.time()
                row = {**self._common(user, key), 'base': base, 'sequence': sequence,
                    'account_id': account['id'], 'lead_id': lead['id'], 'uid_digest': uid_digest,
                    'account_digest': binding['account_digest'], 'connection_digest': source['connection_digest'],
                    'binding': binding, 'draft_hash': hashlib.sha256(data['draft_text'].encode('utf-8')).hexdigest(),
                    'review_digest': decision.review_digest, 'created_at': now, 'updated_at': now,
                    'creation_submitted': False, 'window_created': False, 'platform_requests_started': False,
                    'native_stage': 'prepared', 'state': 'prepared', 'evidence_kind': 'none', 'observed_at': None,
                    'snapshot_hash': None, 'platform_comment_digest': None, 'sender_uid_digest': None,
                    'cleanup_state': 'not_started', 'cancel_requested': False, 'next_intent': None}
                self._put(db, ATTEMPTS, row)
                head = {**self._common(user, base), 'account_id': account['id'], 'lead_id': lead['id'],
                    'sequence': sequence, 'key': key, 'predecessor': None if head is None else head['predecessor'],
                    'consumed': True}
                self._put(db, HEADS, head)
                self._hold_custody(db, user, row, True)
                self._current_source(db, token, row=row, decision=decision)
            persisted = True
            post_id, canonical_url = _safe_url('xiaohongshu', lead.get('note_url') or lead.get('url'))
            if post_id != source['post_id']:
                _fail('原笔记来源已变化', None)
            account_dir = self.instance.directory / 'data' / 'accounts' / user['tenant_id'] / account['id']
            spec = _OwnerObservationSpec(self.instance_id, user['tenant_id'], user['id'], user['username'],
                account['id'], account['platform_uid'], source['connection_digest'], lead['id'], source['id'],
                binding['source_digest'], binding['batch_id'], binding['receipt_id'], key, sequence,
                row['draft_hash'], source['post_id'], source['comment_id'], canonical_url,
                account_dir, account_dir / 'xhs-browser-profile',
                account_dir / 'work' / 'owner-contact-observation' / key, decision.review_digest)
            frame = _OwnerObservationFrame(self, token, spec, decision, _SEAL)
            frame._user = _identity(user, _ACTOR)
            with self.core.lock, self._lock:
                if key in self._frames:
                    _fail('原观察已有持有者，不能重复提交', None)
                self._frames[key] = frame
            holder = create(frame, data['draft_text'])  # RAM only; prepared is committed.
            worker = threading.Thread(target=self._work, args=(frame,), name='owner-contact-'+key[:10], daemon=False)
            finisher = threading.Thread(target=self._finish, args=(frame,), name='owner-contact-cleanup-'+key[:10], daemon=False)
            # Serialize the RAM-factory/worker handoff against cancel. The
            # caller finally below seals that the launch attempt has ended.
            with self.core.lock, self._lock:
                self._frame_check(frame)
                frame._worker, frame._finisher = worker, finisher
                worker.start()
                finisher.start()
            with self._readonly() as db:
                current = self._saved(db, ATTEMPTS, key, user)
                return self._read_view(db, user, current, PREFIX + 'start', True)
        except OwnerAcquisitionError as error:
            if persisted:
                _fail('原观察准备已保存，请按原号核对；不会自动重开', None)
            raise error
        except Exception:
            # SQL/commit/transport uncertainty never becomes a fresh false.
            _fail('原观察提交结果需按原号核对；不会自动重开', None)
        finally:
            if frame is not None:
                with self._lock:
                    frame._launching = False
                    frame._launch_done.set()

    def _work(self, frame):
        try:
            frame.holder.run()
        except Exception:
            self._remember_unknown(frame)

    def _finish(self, frame):
        # This is a local completion writer, not a Native observation worker.
        # It may confirm cleanup only AFTER joining that original worker.
        frame._worker.join()
        frame._launch_done.wait()
        try:
            if frame.holder.close() is True:
                self._cleanup(frame, frame.holder)
        except Exception:
            pass  # Keep frame/custody, original row and resources for close.

    def _remember_unknown(self, frame):
        try:
            with self.core.lock, self._lock, self._write() as db:
                row = self._saved(db, ATTEMPTS, frame.spec.idempotency_key, frame._user)
                if row is None:
                    return
                if row['state'] not in _TERMINAL and row['creation_submitted']:
                    row['state'] = 'unknown'
                if row['cleanup_state'] != 'closed':
                    row['cleanup_state'] = 'pending' if frame.holder is not None else 'unknown'
                row['updated_at'] = time.time()
                self._put(db, ATTEMPTS, row)
        except Exception:
            pass  # Never overwrite a committed receipt with invented failure.

    def _cancel(self, token, data):
        if (set(data) not in ({'idempotency_key'}, {'idempotency_key', 'prepare_next_round'})
                or 'prepare_next_round' in data and data['prepare_next_round'] is not True):
            _fail('请明确原观察编号与本次关闭或准备新轮意图')
        key = data.get('idempotency_key')
        if type(key) is not str or not _KEY.fullmatch(key):
            _fail('请保留并核对原网页观察编号')
        user = self._current(token)
        with self._readonly() as db:
            row = self._saved(db, ATTEMPTS, key, user)
            if row is None:
                return self._unknown(PREFIX + 'cancel', key)
        frame = None
        mutation = False
        try:
            with self.core.lock, self._lock, self._write() as db:
                user = self._current(token)
                row = self._saved(db, ATTEMPTS, key, user)
                if row is None:
                    _fail('原观察记录需核对', None)
                frame = self._frames.get(key)
                if data.get('prepare_next_round') is True:
                    if row['next_intent'] is not None:
                        return self._read_view(db, user, row, PREFIX + 'cancel')
                    if row['state'] != 'observed_sent' or row['cleanup_state'] != 'closed':
                        _fail('仅原可信已完成且物理关闭的评论可明确准备新一轮', None)
                    decision = self.policy.resolve()
                    if decision is None:
                        _fail('当前本人网页观察用途尚未通过；保留原完成回执', None)
                    self._current_source(db, token, row=row, decision=decision)
                    self._advance(db, user, row, 'prepare_next_round')
                    self._current_source(db, token, row=row, decision=decision)
                    mutation = True
                elif row['state'] in _TERMINAL and row['cleanup_state'] == 'closed':
                    return self._read_view(db, user, row, PREFIX + 'cancel')
                else:
                    row['cancel_requested'] = True
                    row['updated_at'] = time.time()
                    no_frame_or_finished_empty = (frame is None or not frame._launching
                        and frame.holder is None and frame._worker is None and frame._launch_done.is_set())
                    if not row['creation_submitted'] and no_frame_or_finished_empty:
                        row['state'], row['cleanup_state'] = 'cancelled', 'closed'
                        self._hold_custody(db, user, row, False)
                        self._advance(db, user, row, 'cancel_before_creation')
                    else:
                        if row['creation_submitted'] and row['state'] not in _TERMINAL:
                            row['state'] = 'unknown'
                        if row['cleanup_state'] != 'closed':
                            row['cleanup_state'] = 'pending' if frame is not None else 'unknown'
                        self._put(db, ATTEMPTS, row)
                    mutation = True
            # No control/SQL/Core lock held across Native cancel or join.
            if frame is not None and data.get('prepare_next_round') is not True and frame.holder is not None:
                if frame.holder.cancel() is True and (frame._worker is None or not frame._worker.is_alive()):
                    self._cleanup(frame, frame.holder)
            with self._readonly() as db:
                row = self._saved(db, ATTEMPTS, key, user)
                return self._read_view(db, user, row, PREFIX + 'cancel', mutation)
        except Exception:
            _fail('原观察关闭或新轮意图结果需按原号核对', None)

    def _advance(self, db, user, row, intent):
        if row['next_intent'] is not None:
            return
        head = self._saved(db, HEADS, row['base'], user)
        if (head is None or head['key'] != row['id'] or head['sequence'] != row['sequence']
                or head['consumed'] is not True or row['sequence'] >= 1000000
                or row['state'] not in ('cancelled', 'observed_sent') or row['cleanup_state'] != 'closed'
                or any(c is not None and c['active'] for c in self._custodies(
                    db, user, row['account_id'], row['uid_digest']))):
            _fail('原完成回执、账号占用或新轮序号需核对', None)
        sequence = row['sequence'] + 1
        terminal_digest = self._terminal_digest(row)
        row['next_intent'] = {'key': self._key(row['base'], sequence), 'sequence': sequence,
            'terminal_digest': terminal_digest, 'intent': intent}
        row['updated_at'] = time.time()
        self._put(db, ATTEMPTS, row)
        new_head = {**self._common(user, row['base']), 'account_id': row['account_id'], 'lead_id': row['lead_id'],
            'sequence': sequence, 'key': row['next_intent']['key'], 'consumed': False,
            'predecessor': {'key': row['id'], 'sequence': row['sequence'],
                'terminal_digest': terminal_digest, 'intent': intent}}
        self._put(db, HEADS, new_head)

    def execute(self, token, action, data):
        if action not in ACTIONS or type(data) is not dict:
            _fail('本人网页观察动作不受支持')
        return {'get': self._get, 'start': self._start, 'cancel': self._cancel}[action[len(PREFIX):]](token, data)

    def _frame_row(self, db, frame, current=True):
        if (type(frame) is not _OwnerObservationFrame or frame.module is not self or frame._seal is not _SEAL
                or self._frames.get(frame.spec.idempotency_key) is not frame or frame._user is None):
            _fail('原本人网页观察Frame未建立', None)
        spec = frame.spec
        row = self._saved(db, ATTEMPTS, spec.idempotency_key, frame._user)
        if (row is None or row['sequence'] != spec.sequence or row['account_id'] != spec.account_id
                or row['lead_id'] != spec.lead_id or row['binding']['source_id'] != spec.source_id
                or row['binding']['source_digest'] != spec.source_digest
                or row['binding']['batch_id'] != spec.archive_batch_id or row['binding']['receipt_id'] != spec.archive_receipt_id
                or row['draft_hash'] != spec.draft_hash or row['review_digest'] != spec.review_digest
                or row['uid_digest'] != hashlib.sha256(spec.account_uid.encode('utf-8')).hexdigest()
                or row['connection_digest'] != spec.connection_digest):
            _fail('原观察Frame与持久绑定不一致', None)
        if current:
            if (self._closing or row['cancel_requested'] or row['state'] in _TERMINAL
                    or row['cleanup_state'] == 'closed'):
                _fail('原观察已停止或完成，不能继续观察', None)
            frame.decision.check(frame)
            user, account, lead, source, binding = self._current_source(db, frame._token, row=row, decision=frame.decision)
            if (user['tenant_id'] != spec.tenant_id or user['id'] != spec.actor_id or user['username'] != spec.owner
                    or account['platform_uid'] != spec.account_uid or source['post_id'] != spec.note_id
                    or source['comment_id'] != spec.target_comment_id
                    or _safe_url('xiaohongshu', lead.get('note_url') or lead.get('url')) != (spec.note_id, spec.canonical_url)):
                _fail('原观察本人、笔记或目标已变化', None)
            head = self._saved(db, HEADS, row['base'], frame._user)
            custodies = self._custodies(db, frame._user, row['account_id'], row['uid_digest'])
            if (head is None or head['key'] != row['id'] or head['consumed'] is not True
                    or any(c is None or c['active'] is not True or c['key'] != row['id'] for c in custodies)):
                _fail('原观察范围或账号占用已变化', None)
        return row

    def _frame_check(self, frame):
        with self.core.lock, self._lock, self._readonly() as db:
            self._frame_row(db, frame)
        return True

    def _creation_submitted(self, frame):
        try:
            with self.core.lock, self._lock, self._write() as db:
                row = self._frame_row(db, frame)
                if row['creation_submitted']:
                    _fail('原号已经提交创建，禁止再次创建', None)
                row.update(creation_submitted=True, native_stage='creation_submitted', state='unknown',
                    window_created=None, platform_requests_started=None, cleanup_state='pending', updated_at=time.time())
                self._put(db, ATTEMPTS, row)
                self._frame_row(db, frame)
            return True
        except Exception:
            _fail('原窗口创建提交需按原号核对，不能重开', None)

    def _holder(self, frame, holder):
        from .owner_contact_observation_native import _OwnerNativeAttempt
        if (type(holder) is not _OwnerNativeAttempt or type(frame) is not _OwnerObservationFrame
                or frame.module is not self or frame.holder is not holder or holder.frame is not frame
                or self._frames.get(frame.spec.idempotency_key) is not frame):
            _fail('原本人网页窗口持有者已变化', None)
        return holder

    def _native_phase(self, frame, holder, phase):
        self._holder(frame, holder)
        if phase not in ('window_created', 'canonical_navigation_submitted', 'observing') or holder.attest_phase(phase) is not True:
            _fail('原本人网页窗口阶段未证实', None)
        try:
            with self.core.lock, self._lock, self._write() as db:
                row = self._frame_row(db, frame)
                expected = {'window_created': 'creation_submitted',
                    'canonical_navigation_submitted': 'window_created', 'observing': 'canonical_navigation_submitted'}
                if (not row['creation_submitted'] or row['native_stage'] not in (expected[phase], phase)
                        or holder._phase != phase or holder._cancelled.is_set()):
                    _fail('原窗口阶段或取消意图已变化', None)
                row.update(native_stage=phase, state='observing', window_created=True,
                    platform_requests_started=phase != 'window_created', cleanup_state='open', updated_at=time.time())
                self._put(db, ATTEMPTS, row)
                self._frame_row(db, frame)
            return True
        except Exception:
            _fail('原窗口阶段结果需按原号核对', None)

    def _publish(self, frame, holder, evidence):
        from .owner_contact_observation_native import _OwnedObservationEvidence
        self._holder(frame, holder)
        if (type(evidence) is not _OwnedObservationEvidence or evidence.valid_for(frame, holder) is not True
                or evidence.outcome not in ('sent', 'failed') or type(evidence.observed_at) is not int
                or not 0 < evidence.observed_at <= int(time.time()) + 5
                or type(evidence.snapshot_hash) is not str or not _KEY.fullmatch(evidence.snapshot_hash)
                or evidence.outcome == 'sent' and (type(evidence.platform_comment_digest) is not str
                    or not _KEY.fullmatch(evidence.platform_comment_digest)
                    or evidence.sender_uid_digest != hashlib.sha256(frame.spec.account_uid.encode('utf-8')).hexdigest())
                or evidence.outcome == 'failed' and (evidence.platform_comment_digest is not None
                    or evidence.sender_uid_digest is not None)):
            _fail('原平台观察证明未闭合，不能借人工声明升级', None)
        if holder.attest_phase('observing') is not True:
            _fail('原平台观察窗口持有者未闭合', None)
        try:
            with self.core.lock, self._lock, self._write() as db:
                row = self._frame_row(db, frame)
                if (row['native_stage'] != 'observing' or not row['creation_submitted']
                        or row['window_created'] is not True or row['platform_requests_started'] is not True
                        or evidence.observed_at < int(row['created_at'])
                        or evidence.valid_for(frame, holder) is not True):
                    _fail('原平台观察阶段或持有者已变化', None)
                observed = datetime.fromtimestamp(evidence.observed_at, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
                row.update(state='observed_'+evidence.outcome, evidence_kind='owned_cdp_matched', observed_at=observed,
                    snapshot_hash=evidence.snapshot_hash, platform_comment_digest=evidence.platform_comment_digest,
                    sender_uid_digest=evidence.sender_uid_digest, updated_at=time.time())
                # Current source/actor/materials and opaque original holder are
                # rechecked after construction, before the commit boundary.
                frame.decision.check(frame)
                self._current_source(db, frame._token, row=row, decision=frame.decision)
                if evidence.valid_for(frame, holder) is not True:
                    _fail('原观察证明已失效', None)
                self._put(db, ATTEMPTS, row)
            return True
        except Exception:
            _fail('原平台观察回执结果需按原号核对', None)

    def _cleanup(self, frame, holder):
        self._holder(frame, holder)
        # No current session/risk/purpose gate on physical cleanup. The exact
        # retained original resources and worker must actually be closed.
        if (frame._launching or not frame._launch_done.is_set()
                or frame._worker is not None and frame._worker.is_alive()) or holder.attested_closed() is not True:
            return False
        try:
            with self.core.lock, self._lock, self._write() as db:
                row = self._frame_row(db, frame, current=False)
                if row['cleanup_state'] == 'closed':
                    # A newer legitimate round may now hold this account.
                    # Old closed holders must not touch its custody again.
                    return True
                row['cleanup_state'], row['updated_at'] = 'closed', time.time()
                if row['cancel_requested'] and not row['creation_submitted']:
                    row['state'] = 'cancelled'
                elif row['state'] not in _TERMINAL and row['creation_submitted']:
                    row['state'] = 'unknown'
                if row['state'] in _TERMINAL:
                    self._hold_custody(db, frame._user, row, False)
                if row['state'] == 'cancelled':
                    self._advance(db, frame._user, row, 'cancel_before_creation')
                else:
                    self._put(db, ATTEMPTS, row)
                if holder.attested_closed() is not True:
                    _fail('原资源关闭确认已变化', None)
            # Keep the RAM frame until its local completion writer exits;
            # repeated close is safe and never reopens the original window.
            return True
        except Exception:
            return False

    def close(self):
        with self._lock:
            self._closing = True
            frames = tuple(self._frames.values())
        complete = True
        for frame in frames:
            holder = frame.holder
            if holder is None:
                # A failed RAM factory retains the durable prepared record;
                # no Native could pass creation_submitted through this frame.
                if frame._launching or not frame._launch_done.is_set() or frame._worker is not None and frame._worker.is_alive():
                    complete = False
                continue
            try:
                holder.cancel()
                for thread in (frame._worker, frame._finisher):
                    if thread is not None and thread is not threading.current_thread() and thread.ident is not None:
                        thread.join(5)
                if (any(thread is not None and thread.is_alive() for thread in (frame._worker, frame._finisher))
                        or holder.close() is not True or not self._cleanup(frame, holder)):
                    complete = False
            except Exception:
                complete = False
        return complete
