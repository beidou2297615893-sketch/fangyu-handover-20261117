"""Device-local company policy publication metadata; cloud owns published policy.

Only a verified IntentRuleManagement snapshot can be submitted. SQLite records
contain opaque scope/version/digest receipts, never policy/fact/credential data.
"""
import json
import re
import uuid
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone

from core.intent_policy import policy_digest
from .intent_rule_management import IntentRuleManagement, IntentPolicyError

ENTITY='company_intent_policy_attempts'
ACTIONS=frozenset(('intent_policy_read','intent_policy_publish','intent_policy_publish_status'))
_HEX=re.compile(r'[a-f0-9]{64}')
_KEY=re.compile(r'[A-Za-z0-9_.:-]{8,128}')
_OPAQUE=re.compile(r'[A-Za-z0-9_.:-]{1,128}')
_META=frozenset(('contract','scope','policy_revision','policy_digest','effective_facts_digest','enabled',
    'facts_as_of','facts_valid_until','usable_fact_count','incomplete_fact_count','expired_fact_count','future_fact_count',
    'source','independently_verified','inventory_verified','publication_id','publication_key','source_local_revision','source_local_digest'))

class CompanyIntentPolicyError(ValueError):
    code='COMPANY_INTENT_POLICY_REVIEW_REQUIRED'

def _error(message,*,pre=False):
    error=CompanyIntentPolicyError(message)
    if pre:error.mutation_committed=False
    return error

def _integer(value):return type(value) is int and 0<=value<=2**53-1
def _matches(pattern,value):return isinstance(value,str) and pattern.fullmatch(value) is not None
def _stamp():return datetime.now(timezone.utc).isoformat()

def _utc(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z',value):return False
    try:
        parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
        return parsed.utcoffset().total_seconds()==0
    except ValueError:return False

def safe_projection(value,*,applied=False,expected_source_revision=None,expected_source_digest=None,
                    expected_publication_key=None,expected_publication_id=None,expected_original_request_id=None):
    """Strict public cloud metadata, with optional original-local receipt bindings.

    This validates data only; a valid projection never attests cloud transport,
    current actor permissions, model execution, inventory or billing.
    """
    keys=_META|({'original_request_id'} if applied else set())
    if not isinstance(value,dict) or set(value)!=keys:raise _error('公司规则回执字段无效')
    if (value['contract']!='company_intent_policy_v1' or value['scope']!='company'
            or value['source']!='operator_recorded' or value['independently_verified'] is not False
            or value['inventory_verified'] is not False or type(value['enabled']) is not bool
            or not _integer(value['policy_revision']) or value['policy_revision']<1
            or not all(_matches(_HEX,value[k]) for k in ('policy_digest','effective_facts_digest'))
            or not all(_integer(value[k]) and value[k]<=200 for k in ('usable_fact_count','incomplete_fact_count','expired_fact_count','future_fact_count'))
            or sum(value[k] for k in ('usable_fact_count','incomplete_fact_count','expired_fact_count','future_fact_count'))>200
            or not _utc(value['facts_as_of'])
            or value['facts_valid_until'] is not None and (not _utc(value['facts_valid_until']) or value['facts_valid_until']<=value['facts_as_of'])
            or value['publication_id'] is not None and not _matches(_OPAQUE,value['publication_id'])
            or value['publication_key'] is not None and not _matches(_KEY,value['publication_key'])
            or value['source_local_revision'] is not None and not _integer(value['source_local_revision'])
            or value['source_local_digest'] is not None and not _matches(_HEX,value['source_local_digest'])
            or applied and not _matches(_KEY,value['original_request_id'])):
        raise _error('公司规则回执类型或可信范围无效')
    expected={'source_local_revision':expected_source_revision,'source_local_digest':expected_source_digest,
              'publication_key':expected_publication_key,'publication_id':expected_publication_id}
    if any(bound is not None and value[key]!=bound for key,bound in expected.items()):raise _error('公司规则回执与原本机来源不一致')
    if expected_original_request_id is not None and (not applied or value['original_request_id']!=expected_original_request_id):raise _error('分析结果与原分析编号不一致')
    return deepcopy(value)

class LocalCompanyIntentPolicy:
    def __init__(self,core,tenant,owner,company,*,cloud,device_id,scope_guard=lambda:True):
        if (not all(isinstance(v,str) and v and len(v)<=255 for v in (tenant,owner,device_id))
                or not isinstance(company,dict) or not isinstance(company.get('id'),str) or not company['id']
                or len(company['id'])>255 or not callable(cloud) or not callable(scope_guard)):
            raise _error('公司规则归属或本机接口无效',pre=True)
        self.core,self.tenant,self.owner=core,tenant,owner
        self.company=deepcopy(company);self.company_id=company['id']
        self.cloud,self.device_id,self.scope_guard=cloud,device_id,scope_guard
        self.rules=IntentRuleManagement(core,tenant,owner,company)
        self.device_digest=policy_digest(['company-policy-device-v1',device_id])

    @contextmanager
    def _transaction(self):
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');yield db

    def _get(self,db,ident):
        row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(ENTITY,ident,self.tenant)).fetchone()
        return json.loads(row['body']) if row else None

    def _put(self,db,row):
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(ENTITY,row['id'],self.tenant,
            json.dumps(row,ensure_ascii=False,separators=(',',':'),allow_nan=False)))

    def _authorize(self,db,user,*,admin=False):
        try:
            _,actor=self.rules._authorize(db,user)
        except IntentPolicyError as error:raise _error('本机员工身份或规则归属已变化',pre=True) from error
        saved=self.rules._get(db,'users',user['id'])
        if saved.get('cloud_bound') is not True:raise _error('公司规则需要已绑定的云员工身份',pre=True)
        if admin and saved.get('role')!='admin':raise _error('公司规则发布仅限已保存的管理员身份',pre=True)
        try:valid=self.scope_guard() is True
        except Exception as error:raise _error('本机设备绑定需核对',pre=True) from error
        if not valid:raise _error('本机设备绑定已变化',pre=True)
        return saved,actor

    def _source(self,db):
        try:return self.rules._load(db)
        except IntentPolicyError as error:raise _error('本机规则来源需核对',pre=True) from error

    def _owned(self,row):
        return (isinstance(row,dict) and row.get('tenant_id')==self.tenant and row.get('owner')==self.owner
                and row.get('company_digest')==policy_digest(self.company_id))

    def _scope(self,row,actor):
        if (not self._owned(row) or row.get('actor_fingerprint')!=actor or row.get('device_digest')!=self.device_digest
                or not _matches(_KEY,row.get('idempotency_key')) or not _matches(_HEX,row.get('source_local_digest'))
                or not _integer(row.get('source_local_revision')) or not _integer(row.get('expected_policy_revision'))
                or row.get('state') not in ('submitted','unknown','succeeded')):
            raise _error('原发布的员工、设备或来源范围已变化')

    def _ident(self,key):return policy_digest(['company-policy-publication-v1',self.tenant,self.owner,self.company_id,key])

    def _blocked(self,db,ident):
        rows=db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(ENTITY,self.tenant)).fetchall()
        for found in rows:
            row=json.loads(found['body'])
            if self._owned(row) and (row.get('state') in ('submitted','unknown') or row.get('current_cloud_verified') is False):
                raise _error('原公司规则发布结果待核对，请只核对原发布编号')

    def _source_matches(self,db,row):
        try:current=self._source(db)
        except CompanyIntentPolicyError:return False
        return current['revision']==row['source_local_revision'] and current['digest']==row['source_local_digest']

    def _visible(self,db,row,response,*,read_only=False):
        matches=self._source_matches(db,row)
        verified=row.get('current_cloud_verified') is True and row.get('cloud_current_state')=='succeeded'
        return {**deepcopy(response),'local_source_matches':matches,'requires_revalidation':not matches or not verified,
                'current_cloud_verified':verified,'cloud_current_state':'succeeded' if verified else 'unknown',
                **({'read_only':True} if read_only else {})}

    def snapshot(self,user):return self.execute('intent_policy_read',{},user)

    def execute(self,action,data,user):
        allowed={'intent_policy_read':set(),'intent_policy_publish':{'expected_local_revision','expected_local_digest','expected_policy_revision','idempotency_key'},
                 'intent_policy_publish_status':{'idempotency_key'}}
        if action not in ACTIONS or not isinstance(data,dict) or set(data)!=allowed[action]:raise _error('公司规则操作参数无效',pre=True)
        if action=='intent_policy_read':return self._read(user)
        key=data['idempotency_key']
        if not _matches(_KEY,key):raise _error('原公司规则发布编号格式无效',pre=True)
        if action=='intent_policy_publish':
            if (not _integer(data['expected_local_revision']) or not _integer(data['expected_policy_revision'])
                    or not _matches(_HEX,data['expected_local_digest'])):raise _error('公司规则来源版本无效',pre=True)
            return self._publish(data,user)
        return self._status(key,user)

    def _read(self,user):
        with self._transaction() as db:saved,actor=self._authorize(db,user)
        value=self.cloud(deepcopy(saved),'intent_policy_read',{})
        if not isinstance(value,dict) or type(value.get('can_publish')) is not bool or 'summary' not in value:raise _error('公司规则读取回执无效')
        summary=None if value['summary'] is None else safe_projection(value['summary'])
        with self._transaction() as db:
            current,current_actor=self._authorize(db,user)
            if actor!=current_actor:raise _error('员工身份已变化，云规则结果暂不返回')
            return {'summary':summary,'can_publish':value['can_publish'] and current['role']=='admin'}

    def _preflight(self,db,data,user):
        saved,actor=self._authorize(db,user,admin=True);source=self._source(db)
        if (source['revision']!=data['expected_local_revision'] or source['digest']!=data['expected_local_digest']):raise _error('本机规则已变化，请刷新原来源版本',pre=True)
        ident=self._ident(data['idempotency_key']);previous=self._get(db,ident)
        if previous:
            self._scope(previous,actor)
            if previous['state'] in ('submitted','unknown') or previous.get('current_cloud_verified') is False:raise _error('原发布结果待核对，未重新发布')
            fingerprint=policy_digest(data)
            if previous.get('request_digest')!=fingerprint:raise _error('原发布编号已用于不同来源或版本',pre=True)
            return saved,actor,source,ident,previous
        self._blocked(db,ident)
        return saved,actor,source,ident,None

    def _publish(self,data,user):
        with self._transaction() as db:
            saved,actor,source,ident,previous=self._preflight(db,data,user)
        original_previous=previous
        try:
            permission=self.cloud(deepcopy(saved),'intent_policy_read',{})
            if not isinstance(permission,dict) or type(permission.get('can_publish')) is not bool or 'summary' not in permission:raise _error('公司规则发布权限回执无效')
            current_summary=None if permission['summary'] is None else safe_projection(permission['summary'])
            if permission['can_publish'] is not True:raise _error('云端未授予公司规则发布权限')
            current_revision=0 if current_summary is None else current_summary['policy_revision']
            if original_previous is None and current_revision!=data['expected_policy_revision']:
                raise _error('云公司规则版本已变化，请读取当前版本再发布')
        except Exception:
            # This branch has issued only the fixed READ action, never publish.
            # Initial absence alone is insufficient: another process may have
            # submitted the same key while the permission read was in flight.
            # Recheck under the same SQLite write serialization as registration.
            if original_previous is None:
                with self._transaction() as db:
                    if self._get(db,ident) is not None:
                        raise _error('原发布记录已变化，请保留原编号核对') from None
                    self._blocked(db,ident)
                    self._authorize(db,user,admin=True)
                raise _error('公司规则摘要暂不可读或发布权限未确认；本次尚未提交发布',pre=True) from None
            raise _error('原发布的当前权限摘要暂不可核对，请保留原编号') from None
        with self._transaction() as db:
            latest_saved,latest_actor,latest_source,ident,previous=self._preflight(db,data,user)
            if previous:
                if previous!=original_previous:raise _error('同一发布操作已处理，请核对原发布结果')
                return self._visible(db,previous,previous['response'])
            if actor!=latest_actor or source['revision']!=latest_source['revision'] or source['digest']!=latest_source['digest']:raise _error('提交前规则或员工身份已变化',pre=True)
            row={'id':ident,'tenant_id':self.tenant,'owner':self.owner,'company_digest':policy_digest(self.company_id),
                 'actor_fingerprint':actor,'device_digest':self.device_digest,'idempotency_key':data['idempotency_key'],
                 'source_local_revision':source['revision'],'source_local_digest':source['digest'],
                 'expected_policy_revision':data['expected_policy_revision'],'request_digest':policy_digest(data),
                 'submission_id':str(uuid.uuid4()),'state':'submitted','created_at':_stamp()}
            self._put(db,row)
            _,check=self._authorize(db,user,admin=True)
            if check!=actor:raise _error('提交前员工身份已变化',pre=True)
        payload={'policy':deepcopy(source['policy']),'expected_policy_revision':data['expected_policy_revision'],
                 'idempotency_key':data['idempotency_key'],'source_local_revision':source['revision'],'source_local_digest':source['digest']}
        return self._dispatch(row,user,latest_saved,'intent_policy_publish',payload)

    def _status(self,key,user):
        with self._transaction() as db:
            saved,actor=self._authorize(db,user,admin=True);row=self._get(db,self._ident(key))
            if not row:raise _error('本机没有本人原公司规则发布记录',pre=True)
            self._scope(row,actor)
        return self._dispatch(row,user,saved,'intent_policy_publish_status',{'idempotency_key':row['idempotency_key']})

    def _response(self,value,row):
        if not isinstance(value,dict) or value.get('idempotency_key')!=row['idempotency_key']:raise _error('原公司规则发布回执编号无效')
        if value.get('state')=='unknown':
            if set(value)!={'state','mutation_committed','read_only','idempotency_key'} or value['mutation_committed'] is not None or value['read_only'] is not True:raise _error('原公司规则未知状态回执无效')
            return deepcopy(value)
        if (set(value)!={'state','mutation_committed','idempotency_key','publication_id','summary'}
                or value.get('state')!='succeeded' or value.get('mutation_committed') is not True
                or not _matches(_OPAQUE,value.get('publication_id'))):raise _error('原公司规则发布成功回执无效')
        summary=safe_projection(value['summary'],expected_source_revision=row['source_local_revision'],expected_source_digest=row['source_local_digest'],
            expected_publication_key=row['idempotency_key'],expected_publication_id=value['publication_id'])
        if summary['policy_revision']!=row['expected_policy_revision']+1:raise _error('发布公司版本与原请求不一致')
        return {**deepcopy(value),'summary':summary}

    def _unknown(self,row):
        with self._transaction() as db:
            current=self._get(db,row['id'])
            if (self._owned(current) and current.get('submission_id')==row['submission_id']
                    and current.get('idempotency_key')==row['idempotency_key'] and current.get('state') in ('submitted','unknown','succeeded')):
                self._put(db,{**current,'state':'succeeded' if current['state']=='succeeded' else 'unknown',
                              'current_cloud_verified':False,'cloud_current_state':'unknown','updated_at':_stamp()})

    def _dispatch(self,row,user,saved,operation,payload):
        try:
            value=self.cloud(deepcopy(saved),operation,deepcopy(payload))
            response=self._response(value,row)
            with self._transaction() as db:
                _,actor=self._authorize(db,user,admin=True)
                if actor!=row['actor_fingerprint']:raise _error('员工身份已变化，发布结果暂不返回')
                current=self._get(db,row['id']);self._scope(current,actor)
                if (current.get('submission_id')!=row['submission_id'] or current.get('request_digest')!=row['request_digest']):raise _error('原发布记录已变化，请核对原编号')
                if current.get('state')=='succeeded' and response['state']=='succeeded':
                    if current.get('response')!=response:raise _error('原发布成功记录与云回执不一致')
                known_success=current.get('state')=='succeeded'
                missing_status=known_success and response['state']=='unknown'
                updated={**current,'state':'succeeded' if known_success else response['state'],'updated_at':_stamp(),
                         'current_cloud_verified':response['state']=='succeeded','cloud_current_state':response['state']}
                if response['state']=='succeeded':updated['response']=deepcopy(response)
                self._put(db,updated)
                visible=self._visible(db,updated,current['response'] if missing_status else response,
                                      read_only=operation=='intent_policy_publish_status')
                _,recheck=self._authorize(db,user,admin=True)
                if recheck!=actor:raise _error('员工身份已变化，发布结果暂不返回')
                return visible
        except Exception as error:
            self._unknown(row)
            # Post-dispatch failures cannot advertise no cloud commit, including
            # local permission/validation errors that normally carry False.
            if hasattr(error,'mutation_committed'):
                try:del error.mutation_committed
                except (AttributeError,TypeError):raise _error('原发布结果待核对，不能推定未提交') from error
            raise
