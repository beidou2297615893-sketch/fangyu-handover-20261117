"""Explicit single local wx page binding and borrowed original preview calls."""
from contextlib import contextmanager
import hashlib,json,re,threading
from pathlib import Path
from urllib.parse import urlsplit
from core import CoreError
from core.adapters import account_execution_lock
from core.service_plans import require_feature
from core.wechat_preview_policy import WechatPreviewPolicy,_PURPOSE
from .business import BusinessExecutor
from .xhs_app_context import _DeviceSession

_ACTOR=('id','tenant_id','username','role','disabled','cloud_bound','development_local_only',
        'can_reply','permission_revision')
def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()

def _binding(service,account_id=None):
    from app import AppServer
    from .service import AssistantService
    if type(service) is not AssistantService:raise ValueError('current_scope_unavailable')
    server=service.server;core=server.core
    if (type(server) is not AppServer or server.assistant_service is not service
            or not server.employee_workspace_mode):raise ValueError('current_scope_unavailable')
    with core.lock:
        with service.lock:
            executor=service.executor;device=dict(service.device or {})
            if (service.closed or service.stop_event.is_set() or server.closing
                    or service.state!='online' or type(executor) is not BusinessExecutor):
                raise ValueError('current_scope_unavailable')
        user=service._local_user(read_only=True);stored=core.store.get('users',user.get('id'))
        session=getattr(executor,'_xhs_app_session',None)
        if (type(session) is not _DeviceSession or session.service is not service
                or session.executor is not executor or session.core is not core
                or not stored or stored.get('disabled') or stored.get('cloud_bound') is not True
                or stored.get('development_local_only') is True or stored.get('role') not in ('admin','operator')
                or (stored.get('id'),stored.get('tenant_id'),stored.get('username'))!=
                   (executor.user_id,executor.tenant,executor.owner)
                or device.get('owner')!=executor.owner or not device.get('id')
                or core.remote_safety_hold):raise ValueError('current_scope_unavailable')
        session.check()
        for config in (server.company,core.deployment_config):
            runtime=config.get('runtime') or {}
            if type(runtime) is not dict:raise ValueError('current_scope_unavailable')
            if runtime.get('wechat_channels_automation') in ('hold','disabled','blocked'):
                raise ValueError('platform_scope_held')
            qa=runtime.get('platform_qa_device_id')
            if qa not in (None,'') and (qa!=device['id'] or not core._qa_continuous_allowed()):
                raise ValueError('device_read_lease_unconfirmed')
            if runtime.get('portable_employee_release') not in (None,False):
                if (runtime.get('portable_employee_release') is not True or not core._employee_release_allowed()
                        or core.employee_release_device_id!=device['id']):
                    raise ValueError('device_read_lease_unconfirmed')
        core.require_platform('wechat_channels');server._platform_execution_guard('wechat_channels')
        require_feature(server.company,'acquisition')
        account=None
        if account_id is not None:
            account=core._get('accounts',account_id,executor.tenant);core._account_access(user,account)
            if (account.get('platform')!='wechat_channels' or account.get('cloud_owner')!=executor.owner
                    or account.get('requires_review') not in (None,False)
                    or account.get('risk_state') not in (None,'','normal','safe')
                    or account.get('status') in ('disabled','session_recovery_required')):
                raise ValueError('account_scope_held')
        session.check()
        return user,executor,session,device['id'],account,stored

class _WechatPreviewCall:
    def __init__(self,service,account_id,*,reads=None,entry=None):
        self.service=service;self.server=service.server;self.manager=self.server.wechat_channels
        self.policy=getattr(self.server,'_wechat_preview_policy',None)
        if type(self.policy) is not WechatPreviewPolicy:raise ValueError('preview_materials_pending')
        resolved=self.policy.resolve()
        if not resolved:raise ValueError('preview_materials_pending')
        user,executor,session,device,account,stored=_binding(service,account_id)
        self.revision=resolved['revision'];self.executor=executor;self.session=session;self.device=device
        self.actor=_digest({key:stored.get(key) for key in _ACTOR});self.account=_digest(account)
        self.endpoint=account.get('endpoint') or 'http://127.0.0.1:2026'
        self.user=user;self.account_id=account_id;self.tenant=executor.tenant
        self.thread=threading.current_thread();self.active=True;self.reads=reads;self.entry=entry
        self.directory=self.server.core.store.directory/'accounts'/self.tenant/account_id
        self.config=None
        if reads is not None:
            if account.get('status')!='connected_unverified':raise ValueError('page_binding_unconfirmed')
            self.config=(self.directory/'wechat_channels.json').read_bytes()
            value=json.loads(self.config)
            if (value.get('endpoint')!=account.get('endpoint')
                    or value.get('bound_client_id')!=account.get('bound_client_id')
                    or not value.get('bound_client_id')):raise ValueError('page_binding_unconfirmed')

    def check(self):
        if (not self.active or self.thread is not threading.current_thread()
                or self.server.wechat_channels is not self.manager
                or getattr(self.server,'_wechat_preview_policy',None) is not self.policy):
            raise ValueError('current_scope_unavailable')
        user,executor,session,device,account,stored=_binding(self.service,self.account_id)
        if (executor is not self.executor or session is not self.session or device!=self.device
                or _digest({key:stored.get(key) for key in _ACTOR})!=self.actor
                or _digest(account)!=self.account):raise ValueError('current_scope_unavailable')
        self.policy.current_review()
        if self.reads is not None:
            with self.reads._lock:
                if (self.entry.get('cancelled') or not self.entry.get('running')
                        or not any(x is self.entry for x in self.reads._operations.values())
                        or self.entry.get('account_id')!=self.account_id
                        or self.reads.device_id!=self.device):raise ValueError('preview_cancelled')
            if (self.directory/'wechat_channels.json').read_bytes()!=self.config:
                raise ValueError('page_binding_changed')
        return account

    def before_io(self):
        resolved=self.policy.resolve()
        if not resolved or resolved['revision']!=self.revision:raise ValueError('preview_materials_pending')
        return self.check()

    def accept_saved(self,account):
        # Called only by the original connection's controlled Core commit.
        self.account=_digest(account)
        self.endpoint=account.get('endpoint') or 'http://127.0.0.1:2026'
        self.check()

    def local_get(self,endpoint,path,timeout):
        from wechat_channels_connection import local_get
        parsed=urlsplit(path)
        if parsed.path not in ('/api/channels/status','/api/channels/feed/search',
                '/api/channels/feed/profile','/api/channels/feed/comment/list'):
            raise ValueError('preview_route_invalid')
        account=self.before_io()
        target=urlsplit(self.endpoint)
        port=target.port
        if (target.scheme!='http' or target.hostname!='127.0.0.1'
                or target.username is not None or target.password is not None
                or target.path or target.query or target.fragment or type(port) is not int
                or not 1024<=port<=65535 or self.endpoint!=f'http://127.0.0.1:{port}'):
            raise ValueError('preview_loopback_endpoint_invalid')
        if endpoint!=self.endpoint or endpoint!=(account.get('endpoint') or 'http://127.0.0.1:2026'):
            raise ValueError('page_binding_changed')
        value=local_get(endpoint,path,timeout)
        self.check()
        return value

class WechatPreviewService:
    def __init__(self,service):self.service=service
    def execute(self,operation,data):
        allowed={'account_id','port'} if operation=='configure' else {'account_id'}
        if (operation not in ('configure','check') or type(data) is not dict or set(data)!=allowed
                or type(data.get('account_id')) is not str
                or re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['account_id']) is None):
            raise ValueError('preview_request_invalid')
        if operation=='configure' and (type(data.get('port')) is not int or not 1024<=data['port']<=65535):
            raise ValueError('preview_request_invalid')
        call=_WechatPreviewCall(self.service,data['account_id']);core=self.service.server.core
        try:
            with call.manager.lock,account_execution_lock(call.directory):
                mode=core.account_mode_status(call.account_id,call.tenant)
                if mode.get('status')=='active':raise ValueError('account_in_use')
                call.check()
                original={'id':call.account_id}
                if operation=='configure':original['port']=data['port']
                state=(call.manager.configure(call.user,original,_preview_call=call) if operation=='configure'
                       else call.manager.status(call.user,original,_preview_call=call))
                call.check()
                return {'platform':'wechat_channels','purpose':_PURPOSE,'account_id':call.account_id,
                    'state':state['status'],'identity_verified':False,'account_isolation':False,
                    'account_ready':False,'platform_read_only':True,'auto_retry':False,
                    'archive_available':False,'external_tool_started':False}
        finally:call.active=False

class _WechatPreviewOrigin:
    def __init__(self,call):
        self.service=call.service;self.reads=call.reads;self.policy=call.policy
        self.executor=call.executor;self.session=call.session;self.device=call.device
        self.account_id=call.account_id;self.account=call.account;self.actor=call.actor
        self.directory=call.directory;self.config=call.config;self.revision=call.revision

def receipt_current(reads,entry,account,policy):
    origin=entry.get('_wechat_preview_origin')
    if type(origin) is not _WechatPreviewOrigin:return False
    try:
        current=_binding(policy._server.assistant_service,account['id'])
        return (origin.reads is reads and origin.policy is policy and origin.service is policy._server.assistant_service
            and current[1] is origin.executor and current[2] is origin.session and current[3]==origin.device
            and current[4]==account and _digest(account)==origin.account
            and _digest({key:current[5].get(key) for key in _ACTOR})==origin.actor
            and (origin.directory/'wechat_channels.json').read_bytes()==origin.config
            and policy.current_review() is not None)
    except (CoreError,ValueError,OSError,TypeError,KeyError):return False

def availability(service):
    value={'platform':'wechat_channels','purpose':_PURPOSE,'status':'blocked',
        'identity_verified':False,'account_isolation':False,'account_ready':False,
        'platform_read_only':True,'archive_available':False,'external_tool_started':False}
    try:
        _binding(service);policy=getattr(service.server,'_wechat_preview_policy',None)
        if type(policy) is WechatPreviewPolicy and policy.resolve():value['status']='available'
    except (CoreError,ValueError,OSError,TypeError,KeyError):pass
    return value

@contextmanager
def preview_read(reads,entry,account,task,policy):
    if type(policy) is not WechatPreviewPolicy:raise ValueError('preview_materials_pending')
    call=_WechatPreviewCall(policy._server.assistant_service,account['id'],reads=reads,entry=entry)
    if reads.core is not call.server.core:raise ValueError('current_scope_unavailable')
    try:
        with call.manager.lock,account_execution_lock(call.directory):
            call.check();task['_wechat_preview_call']=call
            yield call
            call.check()
            entry['_wechat_preview_origin']=_WechatPreviewOrigin(call)
    finally:
        task.pop('_wechat_preview_call',None);call.active=False
