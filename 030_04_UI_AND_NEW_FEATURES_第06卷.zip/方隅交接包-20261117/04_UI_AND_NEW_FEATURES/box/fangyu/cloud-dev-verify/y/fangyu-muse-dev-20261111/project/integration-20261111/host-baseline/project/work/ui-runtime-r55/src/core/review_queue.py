"""Employee-reviewed immutable reply snapshots and sequential send queues."""
import hashlib
import os
import json
import threading
import time
from .continuous import ACTIVE, process_alive, stamp


def require_reply_permission(core, user, lead=None, reply=None):
    if user.get('can_reply') is False:
        raise ValueError('当前员工没有回复权限')
    if user.get('role') == 'admin':
        return
    if not user.get('cloud_bound') or user.get('role') not in ('operator', 'employee'):
        raise ValueError('当前员工没有回复权限')
    if lead:
        owner=lead.get('cloud_owner')
        if owner and owner!=user.get('username'):
            raise ValueError('只能审核和回复自己的评论')
        if not owner:
            if not lead.get('task_id'):
                raise ValueError('评论缺少可核实的员工归属')
            task=core._get('tasks',lead['task_id'],lead['tenant_id'])
            core._task_access(user,task,lead['tenant_id'])
    if reply and reply.get('author_id') != user['id']:
        raise ValueError('只能审核自己保存的回复草稿')


def snapshot(core, reply, lead, account, user=None):
    if reply.get('followup_target_id'):
        if user is None:raise ValueError('跟进审核缺少员工身份')
        lead=core._reply_source(reply,user,account=account)
    value = {'reply_id': reply['id'], 'reply_version': int(reply.get('version', 1)),
        'text': reply['text'], 'recipient': core._reply_recipient(lead, reply.get('channel', 'comment'),user=user,account=account),
        'channel': reply.get('channel', 'comment'), 'account_id': account['id'],
        'account_platform': account.get('platform'), 'account_platform_uid': account.get('platform_uid', ''),
        'account_connection': account.get('conn_id', '')}
    if reply.get('followup_target_id'):
        value.update(followup_target_id=reply['followup_target_id'],followup_target_digest=reply['followup_target_digest'])
    value['digest'] = hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':')).encode('utf-8')).hexdigest()
    return value


class ReviewedReplyQueues:
    collection_wait_seconds = 30
    autostart = True

    def __init__(self, core,*,defer_startup_recovery=False):
        self.autostart=not defer_startup_recovery
        self.core = core
        self._workers = {}
        self._stop = threading.Event()
        if not defer_startup_recovery:
            for queue in core.store.list('reply_queues'):
                if queue.get('reviewed') and queue.get('status') in ('queued', 'awaiting_collection', 'running') and not process_alive(queue.get('pid')):
                    queue.update(status='interrupted', message='程序退出，未发送条目保留；发送结果未知的条目禁止重试', updated_at=stamp())
                    core.store.put('reply_queues', queue)

    def _access(self, queue, user):
        require_reply_permission(self.core, user)
        if user.get('role') != 'admin' and queue.get('authorized_by') != user['id']:
            raise ValueError('只能操作自己的已确认回复队列')

    def _validate(self, reply, user, tenant, account, expected=None):
        lead = self.core._reply_source(reply,user,account=account)
        require_reply_permission(self.core, user, lead, reply)
        if user.get('cloud_bound'):
            self.core._account_access(user, account)
        if reply.get('status') != 'approved' or reply.get('channel', 'comment') != 'comment':
            raise ValueError('队列仅接受已审核、未发送的评论回复；结果未知不可重试')
        self.core._check_reply_recipient(reply, lead,user=user,account=account)
        self.core._validate_reply_text(reply['text'])
        actual = snapshot(self.core, reply, lead, account,user=user)
        if reply.get('approval_snapshot') != actual:
            raise ValueError('已审核内容、评论来源或执行账号已改变，请重新审核')
        if expected is not None and actual != expected:
            raise ValueError('队列确认快照已改变，禁止发送旧内容')
        return lead, actual

    def prepare(self, data, user, tenant):
        require_reply_permission(self.core, user)
        ids = data.get('reply_ids')
        if data.get('confirmed') is not True:
            raise ValueError('请明确确认所选回复内容和执行账号')
        if not isinstance(ids, list) or not 1 <= len(ids) <= 20 or any(not isinstance(ident, str) or not ident for ident in ids) or len(set(ids)) != len(ids):
            raise ValueError('队列须包含1—20条互不重复的已确认回复ID')
        account = self.core._get('accounts', data.get('account_id'), tenant)
        confirmed = []
        for ident in ids:
            reply = self.core._get('replies', ident, tenant)
            _, value = self._validate(reply, user, tenant, account)
            confirmed.append(value)
        supplied = data.get('snapshots')
        if supplied is not None and supplied != confirmed:
            raise ValueError('确认的回复快照与当前内容不一致，请重新检查')
        queue = self.core._record({'reviewed': True, 'reply_ids': list(ids), 'snapshots': confirmed,
            'account_id': account['id'], 'authorized_by': user['id'], 'status': 'ready',
            'sent': 0, 'processed': 0, 'message': '所选回复已确认，等待明确发送'}, tenant)
        self.core.store.put('reply_queues', queue)
        self.core._audit(user, 'prepare_reply_queue', {'queue_id': queue['id'], 'count': len(ids)}, tenant)
        return queue

    def start(self, queue, data, user):
        self._access(queue, user)
        if data.get('authorized') is not True:
            raise ValueError('请明确授权发送已确认的回复队列')
        if queue.get('status') not in ('ready', 'awaiting_collection'):
            raise ValueError('队列不可重复运行；已处理或结果未知的条目不能重试')
        account = self.core._get('accounts', queue['account_id'], queue['tenant_id'])
        self.core._public_reply_guard(account.get('platform'))
        for value in queue['snapshots']:
            self._validate(self.core._get('replies', value['reply_id'], queue['tenant_id']), user, queue['tenant_id'], account, value)
        with self.core.lock:
            if queue['id'] in self._workers:
                return self.core._get('reply_queues', queue['id'], queue['tenant_id'])
            # The confirmed switch to replies also pauses owned collection. A
            # started request retains its lease until its final outcome commits.
            for task in self.core.store.list('tasks', queue['tenant_id']):
                if task.get('account_id') != account['id']:
                    continue
                job = self.core.continuous.status(task)
                if job.get('status') in ACTIVE or job.get('inflight'):
                    self.core._task_access(user, task, queue['tenant_id'])
                    self.core.continuous.pause(task)
                elif task['id'] in self.core.running:
                    self.core._task_access(user, task, queue['tenant_id'])
                    task.update(status='paused', pause_reason='user_reply_switch', last_message='已切换回复模式，等待本批结束')
                    self.core.store.put('tasks', task)
            queue.update(status='awaiting_collection', wait_expired=False, runtime_id=self.core.continuous.runtime_id,
                pid=os.getpid(), authorized_at=stamp(), message='等待采集本批结束后顺序发送', updated_at=stamp())
            self.core.store.put('reply_queues', queue)
            self._stop.clear()
            if self.autostart:
                worker = threading.Thread(target=self.process, args=(queue['id'],), name='reviewed-reply-queue', daemon=True)
                self._workers[queue['id']] = worker
                worker.start()
        return queue

    def cancel(self, queue, user):
        self._access(queue, user)
        queue.update(status='cancelled', message='后续回复已取消；正在发送的一条须等待真实结果', updated_at=stamp())
        self.core.store.put('reply_queues', queue)
        return queue

    def close(self):
        self._stop.set()
        with self.core.lock:
            for queue in self.core.store.list('reply_queues'):
                if queue.get('reviewed') and queue.get('runtime_id') == self.core.continuous.runtime_id and queue.get('status') in ('queued', 'awaiting_collection', 'running'):
                    queue.update(status='interrupted', message='程序关闭，队列不自动续发', updated_at=stamp())
                    self.core.store.put('reply_queues', queue)

    def stop_owned(self,tenant,username,reason='设备连接中断，后续回复已停止'):
        stopped=[]
        with self.core.lock:
            for queue in self.core.store.list('reply_queues',tenant):
                if not queue.get('reviewed') or queue.get('status') not in ('ready','queued','awaiting_collection','running'):
                    continue
                user=self.core.store.get('users',queue.get('authorized_by')) or {}
                if user.get('username')!=username:
                    continue
                queue.update(status='interrupted',message=reason,updated_at=stamp())
                self.core.store.put('reply_queues',queue)
                stopped.append(queue['id'])
        return stopped

    def process(self, ident):
        queue = self.core.store.get('reply_queues', ident)
        if not queue or not queue.get('reviewed'):
            return
        tenant, owner = queue['tenant_id'], 'review-queue:'+ident
        leased = False
        deadline = time.monotonic()+self.collection_wait_seconds
        try:
            while True:
                queue = self.core._get('reply_queues', ident, tenant)
                if queue['status'] != 'awaiting_collection' or self._stop.is_set():
                    return
                mode = self.core.account_mode_status(queue['account_id'], tenant)
                if mode.get('status') != 'active' or not process_alive(mode.get('pid')):
                    break
                if mode.get('mode') != 'collection':
                    raise ValueError('账号已有其他回复正在执行')
                if time.monotonic() >= deadline:
                    queue.update(wait_expired=True, message='采集本批仍在结束，已确认内容保留；结束后可继续发送', updated_at=stamp())
                    self.core.store.put('reply_queues', queue)
                    return
                self._stop.wait(.2)
            with self.core.lock:
                self.core.acquire_account_mode(queue['account_id'], tenant, 'replies', owner)
                leased = True
                queue = self.core._get('reply_queues', ident, tenant)
                if queue['status'] != 'awaiting_collection':
                    return
                queue.update(status='running', message='正在顺序发送已确认回复', updated_at=stamp())
                self.core.store.put('reply_queues', queue)
            for value in queue['snapshots']:
                with self.core.lock:
                    queue = self.core._get('reply_queues', ident, tenant)
                    if queue['status'] != 'running' or self._stop.is_set():
                        return
                    user = self.core.store.get('users', queue['authorized_by'])
                    if not user or user.get('disabled'):
                        raise ValueError('队列授权员工已停用')
                    self._access(queue, user)
                    account = self.core._get('accounts', queue['account_id'], tenant)
                    self.core._public_reply_guard(account.get('platform'))
                    reply = self.core._get('replies', value['reply_id'], tenant)
                    lead, _ = self._validate(reply, user, tenant, account, value)
                result = self.core._send_reply({'id': reply['id'], 'account_id': account['id'], 'authorized': True},
                    user, tenant, reply, lead, mode_owner=owner)
                with self.core.lock:
                    queue = self.core._get('reply_queues', ident, tenant)
                    queue['processed'] += 1
                    if result['status'] == 'sent':
                        queue['sent'] += 1
                    elif queue['status'] == 'running':
                        queue.update(status='stopped', message='发送结果未知，队列已停止，禁止自动重试' if result['status'] == 'unknown' else '本条未发送，队列已停止，请检查账号')
                    self.core.store.put('reply_queues', queue)
                    if queue['status'] != 'running':
                        return
            with self.core.lock:
                queue=self.core._get('reply_queues',ident,tenant)
                if queue.get('status')=='running':
                    queue.update(status='completed', message='已确认队列处理完成', updated_at=stamp())
                    self.core.store.put('reply_queues', queue)
        except Exception as exc:
            with self.core.lock:
                queue = self.core.store.get('reply_queues', ident)
                if queue and queue.get('status') not in ('cancelled', 'interrupted'):
                    queue.update(status='stopped', message=str(exc), updated_at=stamp())
                    self.core.store.put('reply_queues', queue)
        finally:
            if leased:
                self.core.release_account_mode(queue['account_id'], tenant, owner)
            with self.core.lock:
                self._workers.pop(ident, None)
