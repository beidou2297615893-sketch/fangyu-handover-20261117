"""Helper-local source facts after owned about:blank initialization.

No policy, account data, Cookie access or platform request. The fixed local
PowerShell reader inherits the original helper's Job and has a bounded timeout.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

from assistant.owned_xhs_native.runtime_materials import _checked_path, digest, fixed_loaded_source

_PROBE_SHA = '627458D60C3BF867248BDC91D3D8FD5A5B49489DBCEC10AE312BB1FF0ECF9D93'

def _deny():
    raise ValueError('page_ready_sources_unconfirmed')

def collect_window_facts(native, profile):
    """Helper-local only: initialized owned UI at about:blank, no platform call."""
    from System import AppDomain
    from System.Diagnostics import Process
    def window_facts():
        control, core = native.core()
        if core is None or str(core.Source) != 'about:blank':
            _deny()
        return int(core.BrowserProcessId), str(core.Environment.UserDataFolder)
    browser_pid, folder = native.invoke(window_facts)
    process = Process.GetCurrentProcess()
    try:
        pid = int(process.Id)
        created = int(process.StartTime.ToUniversalTime().Ticks)
        image = str(process.MainModule.FileName)
        native_modules = sorted({str(module.FileName) for module in process.Modules})
        managed = sorted({str(assembly.Location) for assembly in
                          AppDomain.CurrentDomain.GetAssemblies()
                          if not assembly.IsDynamic and str(assembly.Location)})
    finally:
        process.Dispose()
    code_origins = None
    if getattr(sys, 'frozen', False) is True:
        from portable_code_origins import collect_code_origins
        from portable_helper_package import verify_package, check_code_origins
        manifest, _, _ = verify_package(Path(sys.executable))
        code_origins = collect_code_origins()
        check_code_origins(code_origins, manifest, Path(sys.executable).parent)
        python = code_origins['realPythonFiles']
    else:
        python = sorted({str(fixed_loaded_source(module.__file__)) for module in
                         tuple(sys.modules.values()) if getattr(module, '__file__', None)
                         and str(module.__file__).lower().endswith(('.py', '.pyd', '.dll'))})
    if (browser_pid == pid or folder.lower() != str(profile).lower()
            or len(native_modules) > 2048 or len(managed) > 512 or len(python) > 2048):
        _deny()
    # Fixed source, no account files or stdout persistence. A timed out child is
    # still in the original helper Job and is covered by original owner cleanup.
    script = _checked_path(Path(__file__).parent / 'resources' /
                           'profile_process_native_owner_probe.ps1')
    powershell = _checked_path(Path(os.environ.get('SystemRoot', '')) /
                              'System32/WindowsPowerShell/v1.0/powershell.exe')
    if digest(script).upper() != _PROBE_SHA:
        _deny()
    snapshots = []
    for _ in range(2):
        result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive',
            '-File', str(script)], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, timeout=8, creationflags=subprocess.CREATE_NO_WINDOW,
            check=False)
        if result.returncode != 0 or len(result.stdout) > 1024 * 1024:
            _deny()
        snapshot = json.loads(result.stdout.decode('utf-8-sig'))
        if type(snapshot) is not dict or snapshot.get('complete') is not True:
            _deny()
        snapshots.append(snapshot)
    result = {'contract': 'owned_blank_window_sources_v2' if code_origins is not None else 'owned_blank_window_sources_v1', 'helper_pid': pid,
        'helper_created': created, 'helper_image': image, 'browser_pid': browser_pid,
        'user_data_folder': folder, 'python_modules': python,
        'native_modules': native_modules, 'managed_assemblies': managed,
        'snapshots': snapshots}


    if code_origins is not None:
        result['code_origins'] = code_origins
    return result
