"""Private, job-bound natural login evidence for one disposable candidate.

Only the native helper and its parent read these files. No credential, raw
response, CDP header or request ID is included in the proof.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import stat


SPEC_NAME = '.natural-proof-spec.json'
PROOF_NAME = 'natural-proof.json'
MAX_CANDIDATE = 65536
MAX_PROOF = 4096


class NaturalProofError(RuntimeError):
    def __init__(self, code='natural_proof_invalid'):
        self.code = code
        super().__init__(code)


def _private_file(path: Path, *, maximum: int) -> bytes:
    try:
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > maximum or info.st_size == 0:
            raise NaturalProofError()
        return path.read_bytes()
    except (OSError, ValueError):
        raise NaturalProofError() from None


def _write_once(path: Path, data: bytes) -> None:
    temporary = path.with_name('.natural-write-' + secrets.token_hex(12))
    try:
        fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        # Linking a complete same-directory file publishes it only if the
        # destination does not already exist; a partial proof is never visible.
        os.link(temporary, path)
        path.chmod(0o600)
    except OSError:
        raise NaturalProofError('natural_proof_write_failed') from None
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _encoded(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':')).encode('utf-8')


def _job_id(value):
    return isinstance(value, str) and re.fullmatch(r'[a-f0-9]{24}', value) is not None


def _safe_text(value, limit):
    return (isinstance(value, str) and 0 < len(value) <= limit
            and value.strip() == value
            and not any(ord(char) < 32 or ord(char) == 127 for char in value))


def create_spec(staging_root: Path, *, job_id: str,
                bound_uid: str | None) -> None:
    if (not isinstance(staging_root, Path) or staging_root.name != job_id
            or not _job_id(job_id) or staging_root.is_symlink()
            or bound_uid is not None and not _safe_text(bound_uid, 256)):
        raise NaturalProofError()
    _write_once(staging_root / SPEC_NAME, _encoded({
        'version': 1, 'job_id': job_id, 'bound_uid': bound_uid,
        'key': secrets.token_hex(32),
    }))


def read_spec(staging_root: Path) -> dict:
    if staging_root.is_symlink() or not _job_id(staging_root.name):
        raise NaturalProofError()
    try:
        value = json.loads(_private_file(staging_root / SPEC_NAME,
                                         maximum=1024).decode('utf-8'))
    except (UnicodeError, ValueError, TypeError):
        raise NaturalProofError() from None
    if (not isinstance(value, dict)
            or set(value) != {'version', 'job_id', 'bound_uid', 'key'}
            or value['version'] != 1 or value['job_id'] != staging_root.name
            or value['bound_uid'] is not None and not _safe_text(value['bound_uid'], 256)
            or not isinstance(value['key'], str)
            or re.fullmatch(r'[a-f0-9]{64}', value['key']) is None):
        raise NaturalProofError()
    return value


def _proof_payload(spec: dict, candidate_path: Path, evidence: dict) -> dict:
    user = evidence.get('user') if isinstance(evidence, dict) else None
    expected_fields = {'version', 'job_id', 'capture_nonce',
                       'document_epoch', 'request_generation', 'user'}
    if (not isinstance(evidence, dict) or set(evidence) not in
            (expected_fields, expected_fields | {'candidate_sha256'})
            or evidence['version'] != 1
            or not isinstance(user, dict) or set(user) != {'id', 'nickname', 'guest'}
            or user.get('guest') is not False
            or not all(_safe_text(user.get(key), limit) for key, limit in
                       (('id', 256), ('nickname', 100)))
            or evidence.get('job_id') != spec['job_id']
            or not isinstance(evidence.get('capture_nonce'), str)
            or re.fullmatch(r'[a-f0-9]{32}', evidence['capture_nonce']) is None
            or type(evidence.get('document_epoch')) is not int
            or evidence['document_epoch'] < 1
            or type(evidence.get('request_generation')) is not int
            or evidence['request_generation'] < 1
            or candidate_path != candidate_path.parent.parent /
                '.xiaohongshu-cli' / 'cookies.json'
            or candidate_path.parent.parent.name != spec['job_id']
            or candidate_path.parent.is_symlink()):
        raise NaturalProofError()
    if spec['bound_uid'] is not None and user['id'] != spec['bound_uid']:
        raise NaturalProofError()
    digest = hashlib.sha256(_private_file(candidate_path,
                                          maximum=MAX_CANDIDATE)).hexdigest()
    return {'version': 1, 'job_id': spec['job_id'],
            'capture_nonce': evidence['capture_nonce'],
            'document_epoch': evidence['document_epoch'],
            'request_generation': evidence['request_generation'],
            'candidate_sha256': digest, 'user': user}


def write_proof(staging_root: Path, candidate_path: Path, evidence: dict) -> None:
    spec = read_spec(staging_root)
    payload = _proof_payload(spec, candidate_path, evidence)
    signature = hmac.new(bytes.fromhex(spec['key']), _encoded(payload),
                         hashlib.sha256).hexdigest()
    _write_once(staging_root / PROOF_NAME,
                _encoded({**payload, 'hmac_sha256': signature}))


def verified_status(staging_root: Path, candidate_path: Path) -> dict | None:
    """Return only a coordinator-compatible profile if scope/digest/MAC match."""
    try:
        spec = read_spec(staging_root)
        proof = json.loads(_private_file(staging_root / PROOF_NAME,
                                         maximum=MAX_PROOF).decode('utf-8'))
        if not isinstance(proof, dict) or set(proof) != {
                'version', 'job_id', 'capture_nonce', 'document_epoch',
                'request_generation', 'candidate_sha256', 'user', 'hmac_sha256'}:
            return None
        signature = proof.pop('hmac_sha256')
        if not isinstance(signature, str) or re.fullmatch(r'[a-f0-9]{64}', signature) is None:
            return None
        expected = hmac.new(bytes.fromhex(spec['key']), _encoded(proof),
                            hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            return None
        candidate = _proof_payload(spec, candidate_path, proof)
        if candidate != proof:
            return None
        return {'data': {'authenticated': True, 'user': dict(proof['user'])}}
    except (NaturalProofError, UnicodeError, ValueError, TypeError, OSError):
        return None
