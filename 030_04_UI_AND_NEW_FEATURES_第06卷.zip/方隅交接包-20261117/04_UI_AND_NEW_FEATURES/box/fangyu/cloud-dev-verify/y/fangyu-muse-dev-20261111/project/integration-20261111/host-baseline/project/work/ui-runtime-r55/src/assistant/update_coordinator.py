"""Signed updates with a closed-application data/program transaction.

Runtime calls only check/download/queue. A stable supervisor applies the queue
on the next normal launch, while owning the application's instance.lock. It
must confirm the candidate before starting workers; an interrupted unconfirmed
boot restores the old SQLite snapshots and the old program pointer. No method
in this module launches, terminates, or restarts a process.
"""
from contextlib import contextmanager, closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import shutil
import sqlite3
import threading
import uuid

from tuf.api.metadata import Metadata
from .release import ReleaseStore
from .updates import VerifiedUpdates,require_pinned_root

EMPLOYEE_PILOT_ROOT_SHA256='612acf8e3eba346e6b231855125c014f1ab818c778b2975987d0ef947dfbee9f'
EMPLOYEE_PILOT_PREFIX=('https://fh6-d5ga45c0ddae7008c-1439321968.'
                       'tcloudbaseapp.com/fangyu-employee-pilot/v1/')
EMPLOYEE_PILOT_TARGET='fangyu-employee-pilot-update.zip'


class UpdateBusy(ValueError):
    pass


def installed_executable(install_root,company_id):
    """Read the fixed install layout, never a replaceable release or feed field."""
    default='方隅采集助手.exe'
    if not install_root:return default
    manifest=Path(install_root)/'installation.json'
    if not manifest.is_file():return default
    layout=_read_json(manifest)
    if (not isinstance(layout,dict) or set(layout)!={'company_id','executable','launcher'}
            or layout.get('company_id')!=company_id):
        raise ValueError('固定安装清单与当前客户不一致')
    for key in ('executable','launcher'):
        name=layout[key]
        if (not isinstance(name,str) or len(name)>255 or not name.lower().endswith('.exe')
                or not name[:-4] or name!=name.strip() or name[:-4].rstrip(' .')!=name[:-4]
                or any(c in name for c in '/\\:<>"|?*')
                or any(ord(c)<32 for c in name)
                or re.fullmatch(r'(con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])',name.split('.')[0],re.I)):
            raise ValueError('固定安装清单包含无效程序名称')
    return layout['executable']


def _is_reparse(path):
    """Reject links and Windows junction/reparse points in the pinned root path."""
    path=Path(path)
    if path.is_symlink():return True
    return bool(getattr(path.stat(follow_symlinks=False),'st_file_attributes',0)&0x400)


def _installed_trusted_root(install_root,value):
    if not isinstance(value,str) or not value or '\\' in value or ':' in value:
        raise ValueError('固定安装策略信任根必须是安装目录内的相对路径')
    relative=PurePosixPath(value)
    if (relative.is_absolute() or str(relative)!=value or '..' in relative.parts
            or any(part.endswith((' ','.')) for part in relative.parts)):
        raise ValueError('固定安装策略信任根必须是安装目录内的相对路径')
    root=Path(install_root)
    if not root.is_dir() or _is_reparse(root):
        raise ValueError('固定安装目录无效或包含重解析路径')
    root=root.resolve(strict=True)
    candidate=root
    for part in relative.parts:
        candidate=candidate/part
        if not candidate.exists() or _is_reparse(candidate):
            raise ValueError('固定安装策略信任根缺失或包含重解析路径')
    if not candidate.resolve(strict=True).is_relative_to(root) or not candidate.is_file():
        raise ValueError('固定安装策略信任根必须是安装目录内的普通文件')
    return str(candidate)


def load_update_policy(company,install_root):
    """Per-install public feed policy stays outside replaceable program bundles."""
    if not install_root:return company
    path=Path(install_root)/'update-config.json'
    employee=(company.get('runtime') or {}).get('portable_employee_release') is True
    if not path.is_file():
        if employee and company.get('releaseSequence',0)>=2:
            raise ValueError('员工更新引导版缺少固定受信任策略')
        return company
    policy=_read_json(path)
    if (not isinstance(policy,dict) or set(policy)!={'company_id','updateFeed'}
            or policy.get('company_id')!=company.get('id') or not isinstance(policy.get('updateFeed'),dict)):
        raise ValueError('固定启动入口更新策略与当前客户不一致')
    feed=dict(policy['updateFeed'])
    if 'trusted_root' in feed:
        feed['trusted_root']=_installed_trusted_root(install_root,feed['trusted_root'])
    if employee:
        expected={'enabled':True,'metadata_url':EMPLOYEE_PILOT_PREFIX+'metadata/',
                  'targets_url':EMPLOYEE_PILOT_PREFIX+'targets/',
                  'trusted_root':str((Path(install_root)/'update-trust/root.json').resolve()),
                  'target':EMPLOYEE_PILOT_TARGET,'channel':'employee-pilot'}
        if (company.get('updateFeed')!={'enabled':False} or feed!=expected
                or _digest(feed['trusted_root'])!=EMPLOYEE_PILOT_ROOT_SHA256):
            raise ValueError('员工更新固定地址或公开信任根与安装版本不匹配')
    return {**company,'updateFeed':feed}


def _write_json(path, value):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temp.open('w',encoding='utf-8') as stream:
            json.dump(value,stream,ensure_ascii=False,indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        temp.unlink(missing_ok=True)


def _read_json(path, default=None):
    return json.loads(Path(path).read_text('utf-8')) if Path(path).exists() else default


@contextmanager
def _file_lock(path):
    """Same byte-range lock as app.main on Windows; nonblocking on all hosts."""
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as stream:
        if stream.tell()==0:
            stream.write(b'1')
            stream.flush()
        stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as error:
            raise UpdateBusy('工作台仍在运行或更新操作正忙，请正常关闭后重开') from error
        try:
            yield
        finally:
            stream.seek(0)
            if os.name=='nt':
                msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:
                fcntl.flock(stream.fileno(),fcntl.LOCK_UN)


def _digest(path):
    hasher=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            hasher.update(block)
    return hasher.hexdigest()


def _sqlite_copy(source, destination):
    """SQLite's backup API includes committed WAL data; never copy a live file."""
    source,destination=Path(source),Path(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    with closing(sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)) as src:
        with closing(sqlite3.connect(destination)) as dest:
            src.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise ValueError('更新前数据库完整性检查失败')
            dest.commit()
    with destination.open('r+b') as stream:
        os.fsync(stream.fileno())


def _preserve_customization(previous_folder, candidate_folder):
    """Carry user-edited theme/copy/assets into a newly signed program folder."""
    previous_folder,candidate_folder=Path(previous_folder),Path(candidate_folder)
    source=previous_folder/'客户定制'
    if not source.exists():return
    if (_is_reparse(previous_folder) or _is_reparse(candidate_folder)
            or _is_reparse(source) or not source.is_dir()
            or not source.resolve().is_relative_to(previous_folder.resolve())):
        raise ValueError('旧版客户定制目录包含越界路径')
    target=candidate_folder/'客户定制'
    if target.exists() and (_is_reparse(target) or not target.is_dir()):
        raise ValueError('新版客户定制目录无效')
    total=0
    for item in source.rglob('*'):
        if _is_reparse(item) or not item.resolve().is_relative_to(source.resolve()):
            raise ValueError('旧版客户定制内容包含链接或越界路径')
        destination=target/item.relative_to(source)
        if item.is_dir():
            destination.mkdir(parents=True,exist_ok=True)
        elif item.is_file():
            total+=item.stat().st_size
            if total>512*1024*1024:
                raise ValueError('客户定制内容过大，停止自动更新并保留旧版')
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(item,destination)
        else:
            raise ValueError('旧版客户定制内容不是普通文件')


_LEGACY_APARTMENT_INTENT_KEYWORDS=(
    ('high',['预约','看房','入住','预算']),
    ('medium',['价格','租金','地址','地铁','房型']),
    ('low',['看看','了解']),
)


def _merge_company_config(current,packaged):
    """Match installer.merge_company_config without importing packaging at runtime.

    The signed package supplies release policy. Only old local business edits
    survive, and the runtime updateFeed overlay is never used as an input.
    """
    if not isinstance(current,dict) or not isinstance(packaged,dict) or current.get('id')!=packaged.get('id'):
        raise ValueError('现有程序标识不匹配，停止覆盖')
    merged=dict(current)
    for key in ('releaseVersion','releaseSequence','runtime','dataNotice','publicSiteUrl','updateFeed'):
        if key in packaged:merged[key]=packaged[key]
    if merged.get('id')=='fangyu-apartment-client':
        for key in ('edition','personalMode','authMode','platforms','accountLimit','features','managedWorkspace'):
            if key in packaged:merged[key]=packaged[key]
        if 'publicSiteUrl' not in packaged:merged.pop('publicSiteUrl',None)
        if 'updateFeed' not in packaged:merged.pop('updateFeed',None)
        existing=merged.get('intentRules')
        defaults=packaged.get('intentRules')
        if isinstance(existing,list) and isinstance(defaults,list):
            try:
                legacy=tuple((item.get('level'),item.get('keywords')) for item in existing)
                replacements={item.get('level'):item.get('keywords') for item in defaults}
                if (legacy==_LEGACY_APARTMENT_INTENT_KEYWORDS
                        and all(isinstance(replacements.get(level),list)
                                for level,_ in _LEGACY_APARTMENT_INTENT_KEYWORDS)):
                    merged['intentRules']=[{**item,'keywords':list(replacements[item['level']])}
                                           for item in existing]
            except (AttributeError,TypeError):
                pass
    merged.pop('localCliPaths',None)
    return merged


def _identifier(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}',value):
        raise ValueError('增量迁移标识无效')
    return '"'+value+'"'


def _column(column):
    if not isinstance(column,dict) or set(column)-{'name','type','nullable','default'}:
        raise ValueError('增量迁移列定义无效')
    name=_identifier(column.get('name'))
    datatype=column.get('type')
    if datatype not in ('TEXT','INTEGER','REAL','BLOB','NUMERIC'):
        raise ValueError('增量迁移列类型无效')
    nullable=column.get('nullable',True)
    if type(nullable) is not bool:
        raise ValueError('增量迁移空值约束无效')
    value=column.get('default')
    if value is None:
        default='NULL'
    elif type(value) is int:
        default=str(value)
    elif isinstance(value,str) and len(value)<=4096 and '\x00' not in value:
        default="'"+value.replace("'","''")+"'"
    else:
        raise ValueError('增量迁移默认值无效')
    if not nullable and value is None:
        raise ValueError('非空新增列必须有兼容默认值')
    return name+' '+datatype+(' NOT NULL' if not nullable else '')+' DEFAULT '+default


def migrate_additive(database, schema):
    """Only declarative schema additions; no arbitrary SQL or record rewrites."""
    with closing(sqlite3.connect(database)) as db:
        before=db.execute('PRAGMA user_version').fetchone()[0]
        if before!=schema['from']:
            raise ValueError('数据库版本与签名增量迁移起点不一致')
        try:
            db.execute('BEGIN IMMEDIATE')
            for operation in schema['operations']:
                kind=operation.get('op') if isinstance(operation,dict) else None
                if kind=='add_column' and set(operation)=={'op','table','column'}:
                    table=_identifier(operation['table'])
                    columns={row[1] for row in db.execute('PRAGMA table_info('+table+')')}
                    if not columns or operation['column'].get('name') in columns:
                        raise ValueError('新增列的原表缺失或列已存在')
                    db.execute('ALTER TABLE '+table+' ADD COLUMN '+_column(operation['column']))
                elif kind=='create_table' and set(operation)=={'op','table','columns'}:
                    table=_identifier(operation['table'])
                    columns=operation['columns']
                    if not isinstance(columns,list) or not 1<=len(columns)<=64:
                        raise ValueError('新表的列数量无效')
                    db.execute('CREATE TABLE '+table+' ('+','.join(_column(c) for c in columns)+')')
                elif kind=='create_index' and set(operation)=={'op','name','table','columns'}:
                    columns=operation['columns']
                    if not isinstance(columns,list) or not 1<=len(columns)<=16:
                        raise ValueError('新索引的列数量无效')
                    db.execute('CREATE INDEX '+_identifier(operation['name'])+' ON '+_identifier(operation['table'])
                               +' ('+','.join(_identifier(c) for c in columns)+')')
                else:
                    raise ValueError('只允许兼容的新增表、列或非唯一索引迁移')
            db.execute('PRAGMA user_version='+str(schema['to']))
            db.commit()
            if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise ValueError('增量迁移后数据库校验失败')
        except Exception:
            db.rollback()
            raise


class UpdateCoordinator:
    DATABASES=('workspace.sqlite3','assistant/executions.sqlite3')

    def __init__(self,install_root,data_dir,company,*,installed_release=None,
                 idle_check=None,allow_test_http=False,executable='方隅采集助手.exe'):
        self.data_dir=Path(data_dir).resolve()
        self.directory=self.data_dir/'assistant'/'updates'
        self.state_path=self.directory/'state.json'
        self.pending_path=self.directory/'pending.json'
        self.journal_path=self.directory/'transaction.json'
        self.install_root=Path(install_root).resolve() if install_root else None
        self.store=ReleaseStore(self.install_root,executable) if self.install_root else None
        self.company=company
        self.installed_release=installed_release
        self.idle_check=idle_check
        self.allow_test_http=allow_test_http
        self.lock=threading.RLock()

    def _active_release(self):
        active=self.store.active() if self.store else None
        if active:return active['release']
        value=self.installed_release if self.installed_release is not None else self.company.get('releaseSequence',0)
        if type(value) is not int or value<0:raise ValueError('本机递增发布序号尚未配置')
        return value

    def _state(self):
        state=_read_json(self.state_path,{})
        if type(state.get('highest_release',0)) is not int or state.get('highest_release',0)<0:
            raise ValueError('更新防回退记录损坏')
        return state

    def _save_state(self,**fields):
        state={**self._state(),**fields}
        _write_json(self.state_path,state)
        return state

    @contextmanager
    def _operation(self):
        with self.lock,_file_lock(self.directory/'operation.lock'):
            yield

    def _client(self):
        config=self.company.get('updateFeed')
        if not isinstance(config,dict) or config.get('enabled') is not True:
            return None,None
        required=('metadata_url','targets_url','trusted_root','target')
        if any(not isinstance(config.get(k),str) or not config[k].strip() for k in required):
            raise ValueError('受信任更新源缺少本机固定地址、根公钥或目标路径')
        root=Path(config['trusted_root'])
        if not root.is_absolute() or not root.is_file():
            raise ValueError('受信任根公钥必须为本机已固定的绝对路径文件')
        client=VerifiedUpdates(self.directory/'tuf',root,config['metadata_url'],config['targets_url'],
                               config.get('channel','stable'),self.allow_test_http)
        return client,config['target']

    def _schema_version(self):
        path=self.data_dir/'workspace.sqlite3'
        if not path.exists():return 0
        with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)) as db:
            return db.execute('PRAGMA user_version').fetchone()[0]

    def _compatible(self,candidate):
        custom=candidate.get('custom') or {}
        if custom.get('company_id')!=self.company.get('id'):
            raise ValueError('签名更新包不属于当前客户公司')
        minimum,maximum=custom.get('min_installed_release'),custom.get('max_installed_release')
        current=self._active_release()
        if type(minimum) is not int or type(maximum) is not int or not 0<=minimum<=current<=maximum:
            raise ValueError('签名更新包不兼容当前程序版本')
        schema=custom.get('data_schema')
        if not isinstance(schema,dict) or set(schema)!={'from','to','operations'}:
            raise ValueError('签名更新包缺少声明式数据库兼容信息')
        before,after=schema['from'],schema['to']
        if (type(before) is not int or type(after) is not int or not 0<=before<=after<=65535
                or not isinstance(schema['operations'],list) or len(schema['operations'])>128
                or before==after and schema['operations']):
            raise ValueError('签名更新包数据库兼容信息无效')
        if self._schema_version()!=before:
            raise ValueError('签名更新包不兼容本机数据库版本')
        return schema

    def status(self):
        state=self._state()
        pending=_read_json(self.pending_path,{})
        configured=isinstance(self.company.get('updateFeed'),dict) and self.company['updateFeed'].get('enabled') is True
        return {'status':state.get('status','ready' if configured else 'not_configured'),
                'installed_release':self._active_release(),
                'installed_version':self.company.get('releaseVersion','unknown'),
                'candidate_release':pending.get('release') or (state.get('staged') or {}).get('release'),
                'message':state.get('message','受信任的生产更新源尚未配置' if not configured else '可检查受信任更新'),
                'requires_restart':bool(pending),'feed_configured':configured}

    def record_background_failure(self):
        """Expose a bounded status without leaking TUF URLs or local paths."""
        with self._operation():
            if self.pending_path.exists() or self.journal_path.exists():
                return self.status()
            self._save_state(status='check_failed',
                             message='自动更新检查未完成；稍后会重试，当前工作台可继续使用')
            return self.status()

    def check(self,download=False):
        """Only local configured URLs are used; no remote-supplied URLs accepted."""
        with self._operation():
            client,target=self._client()
            if client is None:return self.status()
            if self.journal_path.exists() or self.pending_path.exists():return self.status()
            candidate=client.inspect(target)
            current=self._active_release()
            floor=max(current,self._state().get('highest_release',0))
            if candidate['release']<floor:
                raise ValueError('拒绝低于已信任发布序号的更新')
            if candidate['release']==floor:
                failed=floor>current
                self._save_state(status='update_rejected' if failed else 'up_to_date',
                                 message='此版本已失败回退，请等待更高发布序号' if failed else '当前已是受信任最新版本')
                return self.status()
            self._compatible(candidate)
            if not download:
                self._save_state(status='available',staged=None,message='已有受信任兼容更新，可下载准备',
                                 candidate_release=candidate['release'])
                result=self.status()
                result['candidate_release']=candidate['release']
                return result
            staged=client.download(candidate)
            self._save_state(status='staged',staged=staged,message='更新已校验并下载，空闲时可安排下次启动安装')
            return self.status()

    def request_install(self):
        with self._operation():
            if self.pending_path.exists():return self.status()
            if self.journal_path.exists():raise ValueError('上次更新事务尚未完成，需正常关闭后重开')
            if not callable(self.idle_check) or self.idle_check() is not True:
                return {**self.status(),'status':'busy','message':'任务、发送或扫码仍在运行，空闲后再安排更新'}
            staged=self._state().get('staged')
            if not staged:raise ValueError('尚未下载受信任更新')
            if not self.store or not self.store.active():
                raise ValueError('当前启动入口未启用独立版本目录；不能原地替换正在运行的程序')
            self._compatible(staged)
            self._verify_staged(staged)
            _write_json(self.pending_path,staged)
            self._save_state(status='pending_restart',message='已安排更新，请正常关闭工作台后从固定入口重开')
            return self.status()

    def refresh_pending(self):
        """Renew signed metadata for a queued package while the app stays open.

        A changed signed target is never silently substituted for pending bytes.
        The next ordinary check can stage its new release after the old queue is
        cleared. Failure leaves the old queue intact for another signed refresh.
        """
        with self._operation():
            pending=_read_json(self.pending_path)
            if not pending or self.journal_path.exists():
                return self.status()
            client,target=self._client()
            if client is None:
                return self.status()
            current=client.inspect(target)
            same=all(current.get(key)==pending.get(key) for key in
                     ('target','release','hashes','length','custom'))
            if same:
                self._verify_staged(pending)
                return self.status()
            queued_release=pending.get('release')
            self.pending_path.unlink(missing_ok=True)
            self._save_state(status='available' if type(queued_release) is int and current['release']>queued_release
                             else 'update_rejected',staged=None,
                             message='签名更新目标已变化，旧待安装包已取消，请重新检查')
            return self.status()

    def _verify_staged(self,staged):
        """Recheck signatures/expiry and bytes offline before any installation."""
        meta=self.directory/'tuf'/'metadata'
        feed=self.company.get('updateFeed') or {}
        pinned_root=Path(feed.get('trusted_root',''))
        if not pinned_root.is_absolute() or not pinned_root.is_file():
            raise ValueError('固定安装信任根缺失，不能应用离线更新')
        require_pinned_root(meta/'root.json',pinned_root)
        documents={role:Metadata.from_file(str(meta/(role+'.json')))
                   for role in ('root','timestamp','snapshot','targets')}
        root=documents['root'].signed
        now=datetime.now(timezone.utc)
        for role,document in documents.items():
            if document.signed.is_expired(now):raise ValueError('已下载更新的签名元数据过期，请重新检查')
            root.verify_delegate(role,document.signed_bytes,document.signatures)
        timestamp=documents['timestamp'].signed
        snapshot=documents['snapshot'].signed
        targets=documents['targets'].signed
        if timestamp.snapshot_meta.version!=snapshot.version or snapshot.meta['targets.json'].version!=targets.version:
            raise ValueError('已下载更新的签名元数据版本不一致')
        timestamp.snapshot_meta.verify_length_and_hashes((meta/'snapshot.json').read_bytes())
        snapshot.meta['targets.json'].verify_length_and_hashes((meta/'targets.json').read_bytes())
        info=targets.targets.get(staged.get('target'))
        if info is None or info.custom!=staged.get('custom') or info.hashes!=staged.get('hashes') or info.length!=staged.get('length'):
            raise ValueError('已下载更新与签名目标不一致')
        config=feed
        if (type(staged.get('release')) is not int or staged['release']!=info.custom.get('release')
                or info.custom.get('platform')!='windows-x64'
                or info.custom.get('channel')!=config.get('channel','stable')
                or staged['target']!=config.get('target')):
            raise ValueError('已下载更新发布序号、平台或固定通道不一致')
        path=Path(staged.get('path','')).resolve()
        downloads=(self.directory/'tuf'/'downloads').resolve()
        if not path.is_relative_to(downloads) or not path.is_file() or 'sha256' not in info.hashes:
            raise ValueError('已下载更新路径或摘要无效')
        with path.open('rb') as stream:
            info.verify_length_and_hashes(stream)
        return path

    def _transaction_dir(self,journal):
        ident=journal.get('id')
        if not isinstance(ident,str) or not re.fullmatch(r'[0-9a-f]{32}',ident):
            raise ValueError('更新恢复事务标识损坏')
        path=self.directory/'transactions'/ident
        if path.is_symlink() or not path.resolve().is_relative_to(self.directory.resolve()):
            raise ValueError('更新恢复事务目录越界')
        return path

    def _snapshot(self,transaction):
        backups={}
        for relative in self.DATABASES:
            source=self.data_dir/relative
            if source.exists():
                if source.is_symlink():raise ValueError('本机数据库不能是符号链接')
                backup=transaction/'backup'/relative
                _sqlite_copy(source,backup)
                backups[relative]={'sha256':_digest(backup)}
                _sqlite_copy(backup,transaction/'candidate'/relative)
        return backups

    def _replace_database(self,source,destination):
        destination=Path(destination)
        # instance.lock is already held. Checkpoint before replacing so old WAL
        # frames can never be replayed onto a different SQLite main file.
        if destination.exists():
            with closing(sqlite3.connect(destination,timeout=0)) as db:
                if db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0]:
                    raise UpdateBusy('数据库仍有活动连接，更新保持待安装')
        temp=destination.with_name(destination.name+'.update-'+uuid.uuid4().hex)
        try:
            _sqlite_copy(source,temp)
            os.replace(temp,destination)
            for suffix in ('-wal','-shm','-journal'):
                destination.with_name(destination.name+suffix).unlink(missing_ok=True)
        finally:
            temp.unlink(missing_ok=True)

    def _restore(self,journal):
        transaction=self._transaction_dir(journal)
        backups=journal.get('backups')
        if not isinstance(backups,dict) or 'workspace.sqlite3' not in backups or set(backups)-set(self.DATABASES):
            raise ValueError('更新恢复备份清单损坏')
        # Validate every backup before touching a single live database.
        for relative,record in backups.items():
            backup=transaction/'backup'/relative
            if backup.is_symlink() or not backup.resolve().is_relative_to(transaction.resolve()):
                raise ValueError('更新恢复备份路径越界')
            if _digest(backup)!=record.get('sha256'):raise ValueError('更新回退数据库备份摘要不一致')
        previous=journal.get('previous')
        if (not isinstance(previous,dict) or type(previous.get('release')) is not int or previous['release']<1
                or previous.get('previous') is not None and (type(previous['previous']) is not int
                                                             or not 0<previous['previous']<previous['release'])):
            raise ValueError('更新恢复程序指针损坏')
        if not (self.store.releases/str(previous['release'])/self.store.executable).is_file():
            raise ValueError('更新回退的上一程序版本缺失')
        for relative in backups:
            self._replace_database(transaction/'backup'/relative,self.data_dir/relative)
        self.store._write_pointer(previous)
        self.pending_path.unlink(missing_ok=True)
        self._save_state(status='rolled_back',staged=None,message='上次更新未完成，已恢复上一程序与原数据库')
        self.journal_path.unlink(missing_ok=True)

    def _recover_locked(self):
        journal=_read_json(self.journal_path)
        if not journal:return self.status()
        if journal.get('phase') not in ('preparing','committing','awaiting_confirmation'):
            raise ValueError('更新恢复事务阶段损坏')
        # A crash before commit never touched production data or its pointer.
        if journal.get('phase')=='preparing':
            self.pending_path.unlink(missing_ok=True)
            self._save_state(status='rolled_back',staged=None,message='更新准备被中断，当前程序和数据库保持原版本')
            self.journal_path.unlink(missing_ok=True)
        else:
            self._restore(journal)
        return self.status()

    def recover_interrupted(self):
        with self._operation():
            try:
                with _file_lock(self.data_dir/'instance.lock'):
                    return self._recover_locked()
            except UpdateBusy:
                return {**self.status(),'status':'awaiting_close','message':'工作台仍在运行，关闭后才可恢复更新'}

    def apply_pending_on_launch(self,healthcheck):
        """Supervisor only. healthcheck(executable, folder, cloned_data) -> bool.

        Cloned data contain the migrated databases and no pairing/platform
        credentials. A real startup must call confirm_healthy before workers.
        """
        with self._operation():
            try:
                with _file_lock(self.data_dir/'instance.lock'):
                    if self.journal_path.exists():return self._recover_locked()
                    staged=_read_json(self.pending_path)
                    if not staged:return self.status()
                    feed=self.company.get('updateFeed')
                    if not isinstance(feed,dict) or feed.get('enabled') is not True:
                        return {**self.status(),'status':'updates_disabled','message':'本机更新源已关闭，待安装包保持未应用'}
                    previous=self.store.active() if self.store else None
                    if not previous:raise ValueError('固定启动入口没有可回退的上一程序版本')
                    try:
                        schema=self._compatible(staged)
                        archive=self._verify_staged(staged)
                    except Exception:
                        self.pending_path.unlink(missing_ok=True)
                        self._save_state(status='update_rejected',staged=None,message='待安装更新已过期、损坏或不兼容，请重新检查')
                        raise
                    floor=max(previous['release'],self._state().get('highest_release',0))
                    release=staged['release']
                    if release<=floor:raise ValueError('拒绝回退或重复安装发布序号')
                    transaction=self.directory/'transactions'/uuid.uuid4().hex
                    transaction.mkdir(parents=True)
                    journal={'id':transaction.name,'release':release,'previous':previous,'phase':'preparing'}
                    _write_json(self.journal_path,journal)
                    self._save_state(highest_release=release)
                    try:
                        backups=self._snapshot(transaction)
                        candidate=transaction/'candidate'/'workspace.sqlite3'
                        if not candidate.is_file():raise ValueError('当前客户数据库缺失，不能自动迁移')
                        migrate_additive(candidate,schema)
                        def probe(executable,folder):
                            company=_read_json(folder/'company.json',{})
                            runtime=company.get('runtime') or {}
                            if (company.get('id')!=self.company['id']
                                    or type(company.get('releaseSequence')) is not int
                                    or company['releaseSequence']!=release
                                    or not isinstance(runtime,dict)
                                    or runtime.get('executable')!=self.store.executable):
                                raise ValueError('更新包企业、程序或发布序号与签名记录不一致')
                            current_runtime=self.company.get('runtime') or {}
                            if current_runtime.get('portable_employee_release') is True:
                                if (runtime.get('portable_employee_release') is not True
                                        or runtime.get('release_approved') is not False
                                        or runtime.get('xiaohongshu_automation')!='hold'
                                        or runtime.get('xiaohongshu_read_transport')!='guarded_cli_v1'
                                        or runtime.get('cli_source_sha256')!=current_runtime.get('cli_source_sha256')
                                        or company.get('releaseVersion')!=self.company.get('releaseVersion')
                                        or company.get('updateFeed')!={'enabled':False}):
                                    raise ValueError('员工更新包发行边界与当前固定工作台不一致')
                            previous_company=_read_json(
                                self.store.releases/str(previous['release'])/'company.json')
                            _write_json(folder/'company.json',
                                        _merge_company_config(previous_company,company))
                            _preserve_customization(
                                self.store.releases/str(previous['release']),folder)
                            # Keep the migration output immutable when a candidate
                            # probe creates test data or initializes its database.
                            probe_data=transaction/'probe'
                            for relative in backups:
                                _sqlite_copy(transaction/'candidate'/relative,probe_data/relative)
                            return healthcheck(executable,folder,probe_data) is True
                        folder=self.store.prepare_verified(archive,release,probe)
                        journal.update(backups=backups,phase='committing')
                        _write_json(self.journal_path,journal)
                        # Multi-file swaps recover via the durable journal if
                        # power/process interruption occurs at any boundary.
                        for relative in backups:
                            self._replace_database(transaction/'candidate'/relative,self.data_dir/relative)
                        self.store.activate_prepared(release)
                        journal['phase']='awaiting_confirmation'
                        _write_json(self.journal_path,journal)
                        self._save_state(status='awaiting_confirmation',message='新版本已准备，等待启动自检；失败会恢复上一版本')
                        return {**self.status(),'release_dir':str(folder)}
                    except Exception:
                        # Before committing no original DB was modified.
                        if journal.get('phase')=='preparing':
                            self.pending_path.unlink(missing_ok=True)
                            self._save_state(status='rolled_back',staged=None,message='更新自检失败，原程序与数据库保持可用')
                            self.journal_path.unlink(missing_ok=True)
                        else:
                            self._restore(journal)
                        raise
            except UpdateBusy:
                return {**self.status(),'status':'awaiting_close','message':'工作台仍在运行，请正常关闭后从固定入口重开'}

    def confirm_healthy(self,release):
        """Startup handshake only, before workers/platform actions are enabled.

        Confirmation writes update metadata only: it never replaces a live DB.
        Once confirmed, automatic rollback is disabled to avoid losing new work.
        """
        with self._operation():
            journal=_read_json(self.journal_path)
            if (not journal or journal.get('phase')!='awaiting_confirmation'
                    or journal.get('release')!=release or self._active_release()!=release):
                raise ValueError('新版本启动确认与待完成更新不一致')
            self._save_state(status='installed',staged=None,message='新版本启动自检通过，客户数据已保留')
            self.pending_path.unlink(missing_ok=True)
            self.journal_path.unlink(missing_ok=True)
            return self.status()
