"""Trusted product access policy. This is entitlement enforcement, not a payment API.

Draft packages describe service depth; prices and payment status are never inferred.
An absent policy preserves the existing pilot. An explicit malformed policy fails closed.
"""
import math
import time


FEATURES = frozenset({'acquisition', 'intent_analysis', 'export', 'handoff', 'strategy', 'team'})
PACKAGE_DRAFTS = (
    {'id': 'experience', 'name': '体验', 'audience': '试点评估',
     'value': '有限配额验证完整获客和交接流程', 'features': ['acquisition', 'intent_analysis', 'export', 'handoff']},
    {'id': 'professional', 'name': '专业获客', 'audience': '个人顾问与经营者',
     'value': '持续获客、规则管理、人工审核联系与可追溯交接',
     'features': ['acquisition', 'intent_analysis', 'export', 'handoff', 'strategy']},
    {'id': 'team', 'name': '团队企业', 'audience': '门店与总部',
     'value': '门店席位、统一额度、接收回执、归因与集中核对', 'features': sorted(FEATURES)},
)


class ProductAccessError(ValueError):
    pass


def access_policy(company, now=None):
    now = time.time() if now is None else now
    if not isinstance(company, dict):
        raise ProductAccessError('企业权限配置无效')
    policy = company.get('productAccessPolicy')
    if policy is None and 'productAccessPolicy' not in company:
        return {'package': 'pilot_existing', 'name': '现有试点权限', 'configured': False,
                'features': sorted(FEATURES), 'expires_at': None, 'expired': False,
                'seat_limit': None, 'store_limit': None, 'analysis_quota': None,
                'billing_period': None, 'payment_provider': 'not_configured'}
    allowed = {'package', 'name', 'features', 'expires_at', 'seat_limit', 'store_limit',
               'analysis_quota', 'billing_period'}
    if not isinstance(policy, dict) or set(policy) - allowed:
        raise ProductAccessError('企业权限配置无效')
    package = policy.get('package')
    if package not in {'experience', 'professional', 'team'}:
        raise ProductAccessError('功能版本无效')
    features = policy.get('features')
    if (not isinstance(features, list) or any(not isinstance(x, str) or x not in FEATURES for x in features)
            or len(features) != len(set(features))):
        raise ProductAccessError('功能权益配置无效')
    expires = policy.get('expires_at')
    if expires is not None and (type(expires) not in (int, float) or not math.isfinite(expires) or expires <= 0):
        raise ProductAccessError('授权到期时间无效')
    quotas = {}
    for field in ('seat_limit', 'store_limit', 'analysis_quota'):
        value = policy.get(field)
        if value is not None and (type(value) is not int or value < 0):
            raise ProductAccessError('权益额度无效')
        quotas[field] = value
    period = policy.get('billing_period')
    if period not in (None, 'month', 'quarter', 'year', 'pilot'):
        raise ProductAccessError('服务周期无效')
    name = policy.get('name') or next(x['name'] for x in PACKAGE_DRAFTS if x['id'] == package)
    if not isinstance(name, str) or len(name) > 60:
        raise ProductAccessError('版本名称无效')
    return {'package': package, 'name': name, 'configured': True, 'features': features.copy(),
            'expires_at': expires, 'expired': expires is not None and now >= expires,
            **quotas, 'billing_period': period, 'payment_provider': 'not_configured'}


def require_feature(company, feature, now=None):
    if feature not in FEATURES:
        raise ProductAccessError('未知的产品能力')
    policy = access_policy(company, now)
    if policy['expired']:
        raise ProductAccessError('当前服务授权已到期；已有记录和安全停止仍可查看')
    if feature not in policy['features']:
        raise ProductAccessError('当前版本未开放此功能，请联系企业管理员核对授权')
    return policy


def package_summary(company, now=None):
    return {'current': access_policy(company, now),
            'candidates': [{**item, 'features': item['features'].copy(), 'price': None,
                            'published': False, 'payment_enabled': False} for item in PACKAGE_DRAFTS],
            'commercial_status': 'candidate_configuration',
            'safety_protections_always_enabled': True,
            'message': '版本权益可配置；价格、充值和支付尚未接入，不代表已收费或已开通商户。'}
