"""Typed sources over the original task/store. No platform or model calls.

Fixed notes, explicit profiles and own interactions use the original guarded
Core queue. Configuration alone never grants execution authority.
"""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import hashlib,json,re
from urllib.parse import parse_qsl,urlencode,urlsplit

PLANS='acquisition_source_plans_v1'
PRESETS='acquisition_source_presets_v1'
SCHEDULES='acquisition_source_schedules_v1'
CONFIG_RECEIPTS='acquisition_source_configuration_receipts_v1'
SCHEMA='acquisition-source/1'
BINDING_SCHEMA='workbench-acquisition-source-binding/1'
_ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_HASH=re.compile(r'[a-f0-9]{64}\Z')


class SourceError(ValueError):
    mutation_committed=False
    def __init__(self,code,message,status=400):
        super().__init__(message);self.code=code;self.status=status


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def _text(value,limit=2048):
    return isinstance(value,str) and 0<len(value)<=limit and not any(ord(c)<32 or ord(c)==127 for c in value)


def _stamp(value):
    if not _text(value,64):raise SourceError('SOURCE_TIME_INVALID','请选择带时区的明确时间')
    try:value=datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError:raise SourceError('SOURCE_TIME_INVALID','请选择带时区的明确时间') from None
    if value.tzinfo is None or not 2000<=value.year<=2100:
        raise SourceError('SOURCE_TIME_INVALID','时间缺少时区或超出可核对范围')
    return value.astimezone(timezone.utc)


def normalize_window(value):
    value={'mode':'all'} if value is None else value
    if type(value) is not dict:raise SourceError('SOURCE_TIME_INVALID','评论时间条件无效')
    mode=value.get('mode')
    if mode=='all' and set(value)=={'mode'}:return {'mode':'all'}
    if mode=='rolling' and set(value)=={'mode','minutes'} and type(value['minutes']) is int and value['minutes'] in (30,60,1440):
        return dict(value)
    if mode=='absolute' and set(value)=={'mode','from','to'}:
        first,last=_stamp(value['from']),_stamp(value['to'])
        if first<last:return {'mode':mode,'from':first.isoformat(),'to':last.isoformat()}
    raise SourceError('SOURCE_TIME_INVALID','请选择全部、明确时间段或最近30分钟、1小时、24小时')


def _note(platform,value):
    if not _text(value):raise SourceError('SOURCE_LINK_INVALID','请填写完整官方帖子链接')
    value=value.strip()
    try:p=urlsplit(value);port=p.port;query=parse_qsl(p.query,keep_blank_values=True,strict_parsing=True)
    except ValueError:raise SourceError('SOURCE_LINK_INVALID','帖子链接格式无效') from None
    domains=('xiaohongshu.com','www.xiaohongshu.com') if platform=='xiaohongshu' else ('www.douyin.com','douyin.com')
    pattern=r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]{1,128})/?' if platform=='xiaohongshu' else r'/video/([0-9]{1,24})/?'
    match=re.fullmatch(pattern,p.path)
    if (p.scheme!='https' or p.hostname not in domains or p.username or p.password or port not in (None,443)
            or p.fragment or not match or len(query)>16 or len(dict(query))!=len(query)
            or any(not _text(k,64) or not _text(v,2048) for k,v in query)):
        raise SourceError('SOURCE_LINK_INVALID','仅支持完整官方帖子链接；短链接请先展开')
    ident=match.group(1)
    public=('https://www.xiaohongshu.com/explore/' if platform=='xiaohongshu' else 'https://www.douyin.com/video/')+ident
    # Retain the fixed transport's access context privately; tracking fields
    # are neither a source identity nor an instruction for the adapter.
    access={k:v for k,v in query if k in ('xsec_token','xsec_source')}
    url=public+('?' + urlencode(access) if access else '')
    if len(url)>2048:raise SourceError('SOURCE_LINK_INVALID','帖子访问上下文过长，请重新复制完整链接')
    return {'id':ident,'url':url,'public_url':public,'title':'',
        'author':'','author_id':'','published_at':'','access_context':'recorded' if access else 'not_recorded'}


def normalize_config(platform,source,comment_window=None,execution=None):
    if platform not in ('xiaohongshu','douyin') or type(source) is not dict:
        raise SourceError('SOURCE_INVALID','请选择已支持的平台与获客来源')
    kind=source.get('kind');items=[]
    if kind=='note_links' and set(source)=={'kind','links'}:
        links=source['links']
        if type(links) is not list or not 1<=len(links)<=100:
            raise SourceError('SOURCE_INVALID','每次请填写1至100条完整帖子链接')
        seen=set()
        for value in links:
            item=_note(platform,value)
            if item['id'] not in seen:items.append(item);seen.add(item['id'])
    elif kind=='profiles' and set(source)=={'kind','profiles'}:
        values=source['profiles']
        if type(values) is not list or not 1<=len(values)<=20 or any(not _text(v,2048) for v in values):
            raise SourceError('SOURCE_INVALID','请填写1至20个公开博主主页或明确编号')
        # Stored intent only. No URL is navigated and no candidate CLI runs.
        for value in values:
            value=value.strip()
            if _ID.fullmatch(value):ident=value
            else:
                try:p=urlsplit(value);port=p.port
                except ValueError:raise SourceError('SOURCE_INVALID','请填写官方公开博主主页或明确编号') from None
                pattern=r'/user/profile/([A-Za-z0-9_-]{1,160})/?' if platform=='xiaohongshu' else r'/user/([A-Za-z0-9_-]{1,160})/?'
                match=re.fullmatch(pattern,p.path)
                domains=('www.xiaohongshu.com','xiaohongshu.com') if platform=='xiaohongshu' else ('www.douyin.com','douyin.com')
                if p.scheme!='https' or p.hostname not in domains or p.username or p.password or port not in (None,443) or p.fragment or not match:
                    raise SourceError('SOURCE_INVALID','请填写官方公开博主主页或明确编号')
                ident=match.group(1)
            public=('https://www.xiaohongshu.com/user/profile/' if platform=='xiaohongshu' else 'https://www.douyin.com/user/')+ident
            if not any(item['profile_id']==ident for item in items):items.append({'profile':public,'profile_id':ident})
    elif kind=='own_interactions' and set(source)=={'kind','types','baseline'}:
        values=source['types']
        if (type(values) is not list or not values or any(v not in ('mentions','likes','connections') for v in values)
                or source['baseline'] not in ('from_now','visible_history')):
            raise SourceError('SOURCE_INVALID','请选择本人互动类型与首次历史处理方式')
        items=[{'type':v} for v in dict.fromkeys(values)]
    else:raise SourceError('SOURCE_INVALID','来源参数无效，未启动采集')
    execution={'mode':'once'} if execution is None else execution
    if type(execution) is not dict or set(execution)!={'mode'} or execution['mode']!='once':
        raise SourceError('SOURCE_SCHEDULE_NOT_STARTED','检查计划请先保存；采集仍须本人点击开始',422)
    result={'schema':SCHEMA,'platform':platform,'kind':kind,'items':items,
        'comment_window':normalize_window(comment_window),'execution':dict(execution)}
    if kind=='own_interactions':result['baseline']=source['baseline']
    return result


def source_digest(config):
    value=deepcopy(config)
    if value['kind']=='note_links':value['items']=[{'id':item['id']} for item in value['items']]
    return digest(value)


def capabilities(platform):
    return {'note_links':{'state':'integrated_pending_platform_validation' if platform=='xiaohongshu' else 'not_integrated',
        'canStart':platform=='xiaohongshu'},
        'profiles':{'state':'integrated_pending_platform_validation' if platform=='xiaohongshu' else 'not_integrated','canStart':platform=='xiaohongshu'},
        'own_interactions':{'state':'integrated_pending_platform_validation' if platform=='xiaohongshu' else 'not_integrated','canStart':platform=='xiaohongshu'},
        'scheduled':{'state':'configuration_only','canStart':False},
        'exactCommentTime':{'state':'platform_evidence_required','unknown':'separate'}}


def preview_config(platform,source,comment_window=None,execution=None):
    rows=[]
    if type(source) is dict and source.get('kind')=='note_links' and type(source.get('links')) is list:
        seen={}
        for index,value in enumerate(source['links'][:100]):
            try:
                item=_note(platform,value);prior=seen.get(item['id'])
                rows.append({'line':index+1,'status':'duplicate' if prior is not None else 'valid',
                    'duplicateOf':prior,'sourceId':item['id'],'publicUrl':item['public_url'],
                    'accessContext':item['access_context']})
                seen.setdefault(item['id'],index+1)
            except SourceError as exc:rows.append({'line':index+1,'status':'invalid','message':str(exc)})
    try:config=normalize_config(platform,source,comment_window,execution)
    except SourceError as exc:return {'canStart':False,'code':exc.code,'message':str(exc),'items':rows,'capabilities':capabilities(platform)}
    supported=capabilities(platform)[config['kind']]['canStart']
    return {'canStart':supported,'code':'' if supported else 'SOURCE_NOT_INTEGRATED',
        'message':'来源已核对，开始前仍需核对当前账号' if supported else '此来源可保存配置，受控读取尚未接通',
        'kind':config['kind'],'sourceCount':len(config['items']),'sourceDigest':source_digest(config),
        'previewDigest':digest(config),
        'commentWindow':config['comment_window'],'items':rows,'capabilities':capabilities(platform)}


def make_source_binding(record,payload):
    config=normalize_config(payload['platform'],payload['source'],payload.get('commentWindow'),payload.get('execution'))
    return {'schema':BINDING_SCHEMA,'requestId':record['requestId'],'requestRecordId':record['id'],
        'signature':record['signature'],'storeId':record['storeId'],'profileDigest':record.get('profileDigest'),
        'created_at':record['created_at'],'payloadDigest':digest(payload),'sourceDigest':source_digest(config),
        'sourceSnapshot':config}


def validate_source_binding(binding,payload):
    try:
        keys={'schema','requestId','requestRecordId','signature','storeId','profileDigest','created_at',
            'payloadDigest','sourceDigest','sourceSnapshot'}
        if type(binding) is not dict or set(binding)!=keys or binding['schema']!=BINDING_SCHEMA:return False
        if any(not isinstance(binding[k],str) or not _HASH.fullmatch(binding[k])
                for k in ('requestRecordId','signature','payloadDigest','sourceDigest')):return False
        if (not _text(binding['requestId'],80) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}',binding['requestId'])
                or binding['storeId']!=payload.get('storeId') or binding['payloadDigest']!=digest(payload)):return False
        if binding['profileDigest'] is not None and (not isinstance(binding['profileDigest'],str) or not _HASH.fullmatch(binding['profileDigest'])):return False
        _stamp(binding['created_at'])
        config=normalize_config(payload['platform'],payload['source'],payload.get('commentWindow'),payload.get('execution'))
        return config==binding['sourceSnapshot'] and source_digest(config)==binding['sourceDigest']
    except (ValueError,TypeError,KeyError,OverflowError):return False


def task_digest(task):
    from .acquisition_receipts import task_digest as original
    return digest([original(task),task.get('source_ref')])


def prepared_source_receipt(user,task,binding):
    return {'id':task['id'],'tenant_id':user['tenant_id'],'owner':user['username'],
        'store_id':task['store_id'],'platform':task['platform'],'account_id':task['account_id'],
        'binding':deepcopy(binding),'taskConditionsDigest':task_digest(task),'state':'prepared',
        'created_at':datetime.now(timezone.utc).isoformat(),'task_created_at':task['created_at']}


def matches_source_receipt(receipt,record,task):
    try:
        binding=record['requestBinding'];payload=record['launchConditions']
        if (not validate_source_binding(binding,payload) or make_source_binding(record,payload)!=binding
                or type(receipt) is not dict or receipt.get('state')!='started'
                or receipt.get('binding')!=binding or task_digest(task)!=receipt.get('taskConditionsDigest')):return False
        expected=(task['id'],record['tenant_id'],record['owner'],record['storeId'],payload['platform'],payload['accountId'])
        created,saved,started=(_stamp(record['created_at']),_stamp(receipt['created_at']),_stamp(receipt['started_at']))
        return (tuple(receipt.get(k) for k in ('id','tenant_id','owner','store_id','platform','account_id'))==expected
            and tuple(task.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','account_id'))==expected
            and receipt['task_created_at']==task['created_at']
            and task.get('source_ref',{}).get('source_digest')==binding['sourceDigest']
            and created<=saved<=started and 0<=(started-created).total_seconds()<=120)
    except (ValueError,TypeError,KeyError,OverflowError):return False


def install_plan(store,task,user,config,anchor=None):
    if not capabilities(config['platform'])[config['kind']]['canStart']:
        raise SourceError('SOURCE_NOT_INTEGRATED','此来源尚未接通受控读取，可先保存预设',422)
    anchor=_stamp(anchor) if anchor else datetime.now(timezone.utc)
    window=config['comment_window']
    resolved=({'from':(anchor-timedelta(minutes=window['minutes'])).isoformat(),'to':anchor.isoformat()}
        if window['mode']=='rolling' else {'from':window['from'],'to':window['to']} if window['mode']=='absolute' else None)
    snapshot=digest([config,resolved,anchor.isoformat()])
    ref={'schema':SCHEMA,'kind':config['kind'],'digest':snapshot,'source_digest':source_digest(config),'count':len(config['items'])}
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        def read(entity,ident):
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (entity,ident,user['tenant_id'])).fetchone()
            return json.loads(row['body']) if row else {}
        current=read('tasks',task['id']);account=read('accounts',task['account_id'])
        if (any(current.get(k)!=task.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','account_id'))
                or current.get('source_ref') or current.get('cloud_owner')!=user['username']
                or current.get('pipeline') or current.get('last_run') or current.get('accumulated')
                or current.get('next_cursor') not in (None,'') or current.get('next_page',1)!=1
                or not _text(current.get('store_id'),80) or current.get('platform')!=config['platform']
                or current.get('scope')!='comments'
                or (config['kind']=='note_links' and current.get('note_url')!=config['items'][0]['url'])
                or (config['kind']!='note_links' and (current.get('source_kind')!=config['kind'] or current.get('note_url')))
                or account.get('cloud_owner')!=user['username'] or account.get('store_id')!=current.get('store_id')
                or account.get('platform')!=config['platform']):
            raise SourceError('SOURCE_SCOPE_CHANGED','来源任务或账号门店已变化，未启动采集',409)
        plan={'id':task['id'],'task_id':task['id'],'tenant_id':user['tenant_id'],'owner':user['username'],
            'store_id':current['store_id'],'account_id':current['account_id'],'platform':current['platform'],
            'config':deepcopy(config),'source_digest':source_digest(config),'snapshot_digest':snapshot,
            'resolved_window':resolved,'created_at':anchor.isoformat()}
        if config['kind'] in ('profiles','own_interactions'):
            from .acquisition_extension_runtime import account_identity
            plan['account_identity']=account_identity(account)
        current['source_ref']=ref
        for entity,value in (('tasks',current),(PLANS,plan)):
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (entity,value['id'],user['tenant_id'],json.dumps(value,ensure_ascii=False)))
    return current


def load_plan(store,task):
    ref=task.get('source_ref')
    if ref is None:return None
    plan=store.get(PLANS,task['id']);account=store.get('accounts',task.get('account_id'))
    if (type(ref) is not dict or ref.get('schema')!=SCHEMA or not plan or not account
            or tuple(plan.get(k) for k in ('task_id','tenant_id','owner','store_id','platform','account_id'))!=
                tuple(task.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','account_id'))
            or tuple(account.get(k) for k in ('tenant_id','cloud_owner','store_id','platform'))!=
                tuple(task.get(k) for k in ('tenant_id','cloud_owner','store_id','platform'))
            or ref.get('digest')!=digest([plan.get('config'),plan.get('resolved_window'),plan.get('created_at')])
            or plan.get('snapshot_digest')!=ref.get('digest')
            or ref.get('source_digest')!=source_digest(plan['config']) or plan.get('source_digest')!=ref.get('source_digest')
            or ref.get('count')!=len(plan['config']['items']) or ref.get('kind')!=plan['config']['kind']
            or plan['config']['kind'] not in ('note_links','profiles','own_interactions')
            or not capabilities(task['platform'])[plan['config']['kind']]['canStart']):
        raise SourceError('SOURCE_SCOPE_CHANGED','原来源快照或账号归属已变化；断点保留',409)
    if plan['config']['kind'] in ('profiles','own_interactions'):
        from .acquisition_extension_runtime import account_identity
        if (task.get('source_kind')!=plan['config']['kind'] or task.get('note_url')
                or account_identity(account)!=plan.get('account_identity')):
            raise SourceError('SOURCE_SCOPE_CHANGED','来源账号身份已变化，断点保留',409)
    return plan


def platform_time_evidence(raw,now=None):
    """Lossless original create_time only; bool/float/naive/future are unknown."""
    unknown={'status':'unknown','source':'platform_create_time'}
    now=now or datetime.now(timezone.utc)
    if now.tzinfo is None:return unknown
    try:
        numeric=raw if type(raw) is int else int(raw) if type(raw) is str and re.fullmatch(r'[0-9]{1,16}',raw) else None
        if numeric is not None:
            unit='seconds' if 946684800<=numeric<=4102444800 else 'milliseconds' if 946684800000<=numeric<=4102444800000 else None
            if unit is None:return unknown
            value=datetime.fromtimestamp(numeric/(1000 if unit=='milliseconds' else 1),timezone.utc)
        elif type(raw) is str:
            value=_stamp(raw);unit='iso8601'
        else:return unknown
        if value>now.astimezone(timezone.utc):return unknown
        return {'status':'verified','source':'platform_create_time','raw':raw,'unit':unit,'publishedAt':value.isoformat()}
    except (ValueError,TypeError,OverflowError,OSError):return unknown


def verified_comment_time(evidence,published_at='',now=None):
    """Recheck retained original time; never infer an offset for naive text."""
    unknown={'status':'unknown','source':'platform_create_time'}
    if type(evidence) is not dict:return unknown
    checked=platform_time_evidence(evidence.get('raw'),now=now)
    if checked.get('status')!='verified' or checked!=evidence:return unknown
    if published_at is not None and type(published_at) is not str:return unknown
    if published_at:
        try:original=datetime.fromisoformat(published_at.replace('Z','+00:00'))
        except (ValueError,OverflowError):original=None
        if original is not None and original.tzinfo is not None and original!=_stamp(checked['publishedAt']):
            return unknown
    return checked


def comment_time_status(row,plan):
    window=plan.get('resolved_window')
    evidence=row.get('comment_time_evidence')
    if type(evidence) is not dict or evidence.get('source')!='platform_create_time':return 'unknown' if window else 'unrestricted'
    checked=platform_time_evidence(evidence.get('raw'))
    if checked.get('status')!='verified' or checked!=evidence:return 'unknown' if window else 'unrestricted'
    if not window:return 'unrestricted'
    stamp=_stamp(checked['publishedAt'])
    return 'in_range' if _stamp(window['from'])<=stamp<_stamp(window['to']) else 'outside'


def public_config(config):
    value={'kind':config['kind'],'sourceCount':len(config['items']),
        'sourceDigest':source_digest(config),'commentWindow':deepcopy(config['comment_window'])}
    if config['kind']=='note_links':value['links']=[item['public_url'] for item in config['items']]
    elif config['kind']=='profiles':value['profiles']=[item['profile'] for item in config['items']]
    else:value.update(types=[item['type'] for item in config['items']],baseline=config['baseline'])
    return value


def _configuration_view(row):
    return {key:deepcopy(row[key]) for key in ('id','name','version','platform','account_id','preset_id',
        'preset_version','interval_minutes','timezone','enabled','state','created_at','updated_at') if key in row} | (
        {'source':public_config(row['config']),'capabilities':capabilities(row['platform'])} if 'config' in row else {})


def resolve_preset(store,user,store_id,platform,account_id,source,comment_window=None,execution=None):
    """Expand an exact owned version privately; never trust redacted UI links."""
    with store.connect() as db:
        def read(entity,ident):
            raw=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,ident)).fetchone()
            return json.loads(raw['body']) if raw else None
        return _resolve_preset_records(read,user,store_id,platform,account_id,source,comment_window,execution)


def _resolve_preset_records(read,user,store_id,platform,account_id,source,comment_window=None,execution=None):
    if (type(source) is not dict or set(source)!={'kind','id','version'} or source.get('kind')!='preset'
            or not isinstance(source.get('id'),str) or not _ID.fullmatch(source['id'])
            or type(source.get('version')) is not int or source['version']<1):
        raise SourceError('SOURCE_PRESET_INVALID','请选择明确版本的已保存预设')
    row=read(PRESETS,source['id']);account=read('accounts',account_id)
    if (not row or tuple(row.get(k) for k in ('tenant_id','owner','store_id','platform','account_id'))!=(
            user['tenant_id'],user['username'],store_id,platform,account_id)
            or not account or tuple(account.get(k) for k in ('tenant_id','cloud_owner','store_id','platform'))!=(
                user['tenant_id'],user['username'],store_id,platform)):
        raise SourceError('SOURCE_CONFIG_UNAVAILABLE','原预设不在当前员工、门店或账号范围',403)
    if row.get('version')!=source['version']:
        raise SourceError('SOURCE_CONFIG_VERSION','预设已更新，请重新读取并确认当前版本',409)
    cfg=deepcopy(row['config'])
    kind=cfg.get('kind')
    if kind=='note_links':resolved={'kind':kind,'links':[item['url'] for item in cfg['items']]}
    elif kind=='profiles':resolved={'kind':kind,'profiles':[item['profile'] for item in cfg['items']]}
    elif kind=='own_interactions':resolved={'kind':kind,'types':[item['type'] for item in cfg['items']],'baseline':cfg['baseline']}
    else:raise SourceError('SOURCE_CONFIG_UNAVAILABLE','原预设来源无法核对，请重新保存',409)
    checked=normalize_config(platform,resolved,cfg.get('comment_window'),cfg.get('execution'))
    if checked!=cfg or comment_window is not None and normalize_window(comment_window)!=cfg['comment_window']:
        raise SourceError('SOURCE_PRESET_CHANGED','预设条件已变化，请先重新保存预设',409)
    if execution is not None and execution!={'mode':'once'}:
        raise SourceError('SOURCE_SCHEDULE_NOT_STARTED','检查计划仅保存配置，仍须本人点击开始',422)
    return {'source':resolved,'commentWindow':deepcopy(cfg['comment_window']),'execution':deepcopy(cfg['execution'])}


def save_configuration(store,user,store_id,data,*,schedule=False,authority_check=None):
    """Scoped optimistic config save. Never starts a scheduler or a task."""
    from uuid import uuid4
    common={'id','expectedVersion','storeId','name','requestId'}
    allowed=common|({'presetId','presetVersion','intervalMinutes','timezone'} if schedule else
        {'platform','accountId','source','commentWindow'})
    if (type(data) is not dict or set(data)-allowed or data.get('storeId')!=store_id
            or type(data.get('expectedVersion')) is not int or data['expectedVersion']<0
            or not _text(data.get('name'),100)):
        raise SourceError('SOURCE_CONFIG_INVALID','请核对配置名称、门店和版本')
    request_id=data.get('requestId')
    if request_id is not None and (not isinstance(request_id,str) or not re.fullmatch('[A-Za-z0-9_-]{16,80}',request_id)):
        raise SourceError('SOURCE_CONFIG_INVALID','请提供有效的原操作编号')
    # Public saves require requestId at the host. Trusted older callers without
    # one retain their existing behavior; no client can invoke that path.
    ident=data.get('id') or (digest(['source-config',user['tenant_id'],user['username'],store_id,schedule,request_id]) if request_id else uuid4().hex)
    if not isinstance(ident,str) or not _ID.fullmatch(ident):raise SourceError('SOURCE_CONFIG_INVALID','配置编号无效')
    config=None
    reference=not schedule and type(data.get('source')) is dict and data['source'].get('kind')=='preset'
    if not schedule and not reference:config=normalize_config(data.get('platform'),data.get('source'),data.get('commentWindow'))
    if schedule and (not isinstance(data.get('presetId'),str) or not _ID.fullmatch(data['presetId'])
            or type(data.get('intervalMinutes')) is not int or not 30<=data['intervalMinutes']<=10080
            or data.get('timezone','Asia/Shanghai')!='Asia/Shanghai' or type(data.get('presetVersion')) is not int):
        raise SourceError('SOURCE_CONFIG_INVALID','请使用明确版本预设和30分钟至7天的检查间隔')
    entity=SCHEDULES if schedule else PRESETS
    receipt_id=digest([user['tenant_id'],user['username'],store_id,entity,request_id]) if request_id else None
    input_digest=digest(data)
    stamp=datetime.now(timezone.utc).isoformat()
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        def read(kind,key):
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(kind,key)).fetchone()
            return json.loads(row['body']) if row else None
        def owned(row):
            return row and (row.get('tenant_id'),row.get('owner'),row.get('store_id'))==(user['tenant_id'],user['username'],store_id)
        def authority():
            actor=read('users',user['id'])
            if (not actor or any(actor.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                    or actor.get('cloud_bound') is not True
                    or authority_check is not None and authority_check(db,actor,store_id,True) is not True):
                raise SourceError('SOURCE_CONFIG_FORBIDDEN','当前员工或门店会话已变化',403)
        authority()
        if receipt_id:
            previous=read(CONFIG_RECEIPTS,receipt_id)
            if previous:
                if not owned(previous) or previous.get('input_digest')!=input_digest or previous.get('entity')!=entity:
                    raise SourceError('SOURCE_REQUEST_CONFLICT','同一操作编号的配置已变化，请核对原操作',409)
                previous_account=read('accounts',previous['result'].get('account_id'))
                if not previous_account or tuple(previous_account.get(k) for k in ('tenant_id','cloud_owner','store_id','platform'))!=(
                        user['tenant_id'],user['username'],store_id,previous['result'].get('platform')):
                    raise SourceError('SOURCE_CONFIG_UNAVAILABLE','原配置账号不在当前员工或门店范围',403)
                authority()
                return {**deepcopy(previous['result']),'receipt':_configuration_receipt_view(previous),'replayed':True}
        old=read(entity,ident)
        if old is not None and not owned(old):raise SourceError('SOURCE_CONFIG_UNAVAILABLE','配置不存在或不在当前授权范围',404)
        if (old or {}).get('version',0)!=data['expectedVersion']:
            raise SourceError('SOURCE_CONFIG_VERSION','配置已更新，请读取当前版本后保存',409)
        if reference:
            # Resolve under the same write transaction. A lost save receipt can
            # still replay its original result even if the source preset later
            # changes, while a new save always checks the exact owned version.
            resolved=_resolve_preset_records(read,user,store_id,data.get('platform'),data.get('accountId'),
                data['source'],data.get('commentWindow'))
            config=normalize_config(data['platform'],resolved['source'],resolved['commentWindow'])
        if schedule:
            preset=read(PRESETS,data.get('presetId'))
            if not owned(preset) or preset['version']!=data['presetVersion']:
                raise SourceError('SOURCE_CONFIG_UNAVAILABLE','预设不存在、版本已变化或不在当前门店',409)
            account_id=preset['account_id'];platform=preset['platform']
        else:account_id=data.get('accountId');platform=data.get('platform')
        account=read('accounts',account_id)
        if not account or (account.get('tenant_id'),account.get('cloud_owner'),account.get('store_id'),account.get('platform'))!=(
                user['tenant_id'],user['username'],store_id,platform):
            raise SourceError('SOURCE_CONFIG_UNAVAILABLE','采集账号不在当前员工或门店范围',403)
        row={'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],'store_id':store_id,
            'name':data['name'].strip(),'version':data['expectedVersion']+1,'account_id':account_id,'platform':platform,
            'created_at':(old or {}).get('created_at',stamp),'updated_at':stamp}
        if schedule:row.update(preset_id=preset['id'],preset_version=preset['version'],
            interval_minutes=data['intervalMinutes'],timezone='Asia/Shanghai',enabled=False,state='manual_start_only')
        else:row['config']=config
        authority()
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
            (entity,ident,user['tenant_id'],json.dumps(row,ensure_ascii=False)))
        result=_configuration_view(row)
        if receipt_id:
            receipt={'id':receipt_id,'tenant_id':user['tenant_id'],'owner':user['username'],'store_id':store_id,
                'request_id':request_id,'entity':entity,'input_digest':input_digest,'config_id':ident,
                'version':row['version'],'state':'succeeded','result':deepcopy(result),'created_at':stamp}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (CONFIG_RECEIPTS,receipt_id,user['tenant_id'],json.dumps(receipt,ensure_ascii=False)))
            result['receipt']=_configuration_receipt_view(receipt)
    return result


def _configuration_receipt_view(row):
    return {'requestId':row['request_id'],'id':row['config_id'],'version':row['version'],
        'kind':'schedule' if row['entity']==SCHEDULES else 'preset','state':row['state'],'found':True}


def read_configuration_receipt(store,user,store_id,request_id,*,schedule=False):
    if not isinstance(request_id,str) or not re.fullmatch('[A-Za-z0-9_-]{16,80}',request_id):
        raise SourceError('SOURCE_CONFIG_INVALID','请提供有效的原操作编号')
    entity=SCHEDULES if schedule else PRESETS
    ident=digest([user['tenant_id'],user['username'],store_id,entity,request_id])
    row=store.get(CONFIG_RECEIPTS,ident)
    if not row:return {'requestId':request_id,'state':'not_found','found':False}
    if (row.get('tenant_id'),row.get('owner'),row.get('store_id'),row.get('entity'))!=(
            user['tenant_id'],user['username'],store_id,entity):
        raise SourceError('SOURCE_CONFIG_FORBIDDEN','配置回执不在当前授权范围',403)
    account=store.get('accounts',row.get('result',{}).get('account_id'))
    if not account or tuple(account.get(k) for k in ('tenant_id','cloud_owner','store_id','platform'))!=(
            user['tenant_id'],user['username'],store_id,row.get('result',{}).get('platform')):
        raise SourceError('SOURCE_CONFIG_FORBIDDEN','原配置账号不在当前员工或门店范围',403)
    return _configuration_receipt_view(row)


def list_configurations(store,user,store_id,*,schedule=False):
    with store.connect() as db:
        rows=db.execute("SELECT body FROM records WHERE entity=? AND tenant_id=? AND json_extract(body,'$.owner')=? "
            "AND json_extract(body,'$.store_id')=?",(SCHEDULES if schedule else PRESETS,user['tenant_id'],user['username'],store_id)).fetchall()
    result=[]
    for raw in rows:
        row=json.loads(raw['body']);account=store.get('accounts',row.get('account_id'))
        if account and (account.get('tenant_id'),account.get('cloud_owner'),account.get('store_id'),account.get('platform'))==(
                user['tenant_id'],user['username'],store_id,row.get('platform')):result.append(_configuration_view(row))
    return sorted(result,key=lambda item:item['updated_at'],reverse=True)
