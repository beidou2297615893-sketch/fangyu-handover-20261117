"""Host-only own-profile whoami facts; never an entitlement or account write."""
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re
import threading
import time
import unicodedata
from uuid import uuid4

from opencli_bridge import OpenCLIBridge
from .adapters import account_execution_lock,_BilibiliOwnedCleanupPending
from .service_plans import require_feature
from .zhihu import profile_id

_PINS={
    'clis/zhihu/auth.js':'9CAD005EE4A32EA114ABA8A861C13C596A214CD3D25A474377C388364929026D',
    'clis/_shared/site-auth.js':'DC2BF3D99D7DB7269BE12AE9A1D3ECF2C72924D0A4420A74BEABB5B030A0D71C',
    'LICENSE':'0210B8B66CF00358242CB921BA2BE3A46DFE0190159B1B952388A3880CE1FF54',
    'package.json':'F151C56B14D1A240855BA2330BA2885B5777F4BD45797142C8F719C325C600F0',
}

class IdentityObservationError(ValueError):pass

def _need(value,message='知乎本人身份范围已变更，请重新核对'):
    if not value:raise IdentityObservationError(message)

def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),
        allow_nan=False).encode('utf8')).hexdigest()

def _actor(value):
    return _digest({k:v for k,v in value.items() if k not in ('created_at','updated_at')})

def _plain(path):
    path=Path(path)
    _need(path.is_absolute() and '..' not in path.parts)
    for current in (path,*path.parents):
        if current.exists():_need(not current.is_symlink() and not getattr(current.lstat(),'st_file_attributes',0)&1024)
    return path

def project_identity(payload):
    """Exact original upstream whoami row, never profile URL/Cookie/author UID."""
    _need(type(payload) is dict and set(payload)=={'logged_in','site','url_token','name','uid'}
        and payload['logged_in'] is True and payload['site']=='zhihu','知乎本人输出尚不可确认')
    for key in ('uid','url_token'):
        _need(type(payload[key]) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}',payload[key]),
            '知乎权威本人标识缺失')
    _need(bool(payload['uid'].strip('0')),'知乎权威本人标识缺失')
    name=payload['name']
    _need(type(name) is str and len(name)<=160 and not any(unicodedata.category(c) in ('Cc','Cs') for c in name),
        '知乎本人名称格式无效')
    return {'uid':payload['uid'],'url_token':payload['url_token'],'nickname':name}

class _ZhihuIdentityCleanupPending(_BilibiliOwnedCleanupPending):
    def __init__(self,*args):
        super().__init__(*args);self.args=('知乎本人核对进程仍待清理，请安全停止后再操作',)
    def finish(self):
        try:return super().finish()
        except Exception:return False  # Unknown poll/wait never loses ownership.

class _ZhihuIdentityCall:
    """Exact RAM call from this host; public payloads cannot provide it."""
    def __init__(self,manager,user,entry):
        self.manager,self.user,self.entry=manager,deepcopy(user),entry
        self.thread=threading.get_ident();self.active=True

    def check(self,adapters,platform,args,root,job_id):
        _need(self.active and self.thread==threading.get_ident() and adapters is self.manager.core.adapters
            and platform=='zhihu' and args==['--profile',self.entry['profile'],'zhihu','whoami','-f','json']
            and Path(root)==self.entry['home'] and job_id==self.entry['job_id'])
        self.manager._check(self.user,self.entry['account_id'],self.entry)

    @contextmanager
    def launch(self):
        # Slow component files/profile status are checked before this short commit.
        # The trusted host's scope_guard contract is a fresh no-IO authority check.
        with self.manager.core.lock:
            bridge=self.manager.bridge
            _need(bridge._lock.acquire(blocking=False),'知乎连接管理器正在操作，本次本人核对未启动')
            try:
                daemon=self.entry['daemon']
                _need(not bridge._closed and bridge._process is daemon and daemon is not None
                    and daemon.pid==self.entry['daemon_pid'] and daemon.poll() is None,
                    '知乎原拥有者进程已变更，本次本人核对未启动')
                self.manager._current(self.user,self.entry['account_id'],self.entry)
                _need(self.manager.scope_guard(*self.manager._identity(self.user,self.entry['account_id'])) is None)
                self.manager._current(self.user,self.entry['account_id'],self.entry)
                yield
            finally:bridge._lock.release()

class ZhihuOwnedIdentity:
    def __init__(self,core,tenant,owner,company,*,device_id,bridge,scope_guard,license_policy_provider):
        _need(all(type(x) is str and 1<=len(x)<=160 for x in (tenant,owner,device_id))
            and type(company) is dict and type(bridge) is OpenCLIBridge
            and callable(scope_guard) and callable(license_policy_provider))
        self.core,self.tenant,self.owner,self.company=core,tenant,owner,company
        self.device_id,self.bridge,self.scope_guard= device_id,bridge,scope_guard
        self.license_policy_provider=license_policy_provider
        self.entries={};self.lock=threading.RLock();self.closed=False

    def _identity(self,user,account_id):
        _need(type(user) is dict and type(account_id) is str and re.fullmatch(r'[A-Za-z0-9_-]{1,160}',account_id))
        current=self.core.store.get('users',user.get('id'))
        _need(current is not None and current.get('tenant_id')==self.tenant and current.get('username')==self.owner
            and current.get('cloud_bound') is True and not current.get('disabled')
            and not current.get('development_local_only') and current.get('role') in ('admin','operator')
            and all(user.get(k)==current.get(k) for k in ('id','tenant_id','username','cloud_bound')))
        account=self.core._get('accounts',account_id,self.tenant);self.core._account_access(current,account)
        _need(account.get('platform')=='zhihu' and account.get('cloud_owner')==self.owner)
        return current,account

    def _current(self,user,account_id,entry=None):
        current,account=self._identity(user,account_id)
        _need(not self.closed and not self.core.adapters.closed and not self.core.remote_safety_hold)
        self.core.require_platform('zhihu');self.core._platform_execution_guard('zhihu');require_feature(self.company,'acquisition')
        _need(account.get('requires_review') in (None,False) and account.get('risk_state') in (None,'','normal','safe'),
            '知乎账号风险需先人工核对，本次不清除风险')
        profile_id(account.get('conn_id'))
        _need(not any(row.get('platform')=='zhihu' and row.get('id')!=account_id
            and row.get('conn_id')==account['conn_id'] for row in self.core.store.list('accounts')),
            '知乎当前窗口已绑定其他账号，本次不借用其身份')
        uid=account.get('platform_uid') or ''
        _need(type(uid) is str and (not uid or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}',uid) and uid.strip('0')))
        if entry is not None:
            _need(self.entries.get(account_id) is entry and entry['actor_id']==current['id']
                and entry['actor']==_actor(current) and entry['account']==_digest(account)
                and entry['device_id']==self.device_id and not entry['stop'].is_set()
                and time.monotonic()<entry['expires'])
        return current,account

    def _configured(self):
        runtime=_plain(self.bridge.runtime);manifest=self.core.adapters.manifest('zhihu')
        _need(self.core.resources_dir is not None)
        managed=_plain(self.core.resources_dir/'opencli-managed.cjs')
        _need(manifest.get('version')=='1.8.8' and manifest.get('source')=='https://github.com/jackwener/opencli'
            and manifest.get('mapper')=='opencli_zhihu' and manifest.get('isolation_guard') is True
            and manifest.get('executable')==str(runtime/'node.exe')
            and manifest.get('prefix_args')==['--require',str(managed),str(runtime/'dist/src/main.js')],
            '知乎固定只读运行组件尚未配置')
        for path in [runtime/'node.exe',runtime/'dist/src/main.js',managed]:_need(_plain(path).is_file(),
            '知乎固定运行组件未安装；不会改用其他 OpenCLI')
        for name,digest in _PINS.items():
            path=_plain(runtime/name)
            _need(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest().upper()==digest,
                '知乎固定上游身份组件与许可材料不匹配')
        # This is only the fixed whoami route preflight. The parent component
        # policy must separately review the complete actual Node/CLI/dependency set.
        checker=self.core.adapters.profile_checker
        _need(getattr(checker,'__self__',None) is self.bridge
            and getattr(checker,'__func__',None) is OpenCLIBridge.require_profile)

    def _check(self,user,account_id,entry=None):
        self._configured()
        policy=self.license_policy_provider()
        _need(type(policy) is dict and policy.get('zhihu') is True,'知乎组件尚未通过当前本人只读用途审查')
        with self.core.lock:
            current,account=self._current(user,account_id,entry)
            _need(self.scope_guard(current,account) is None)
            profile=account['conn_id']
        # Never starts a daemon, installs an extension, or selects a default.
        with self.bridge._lock:
            status=self.bridge.status()
            _need(status.get('owned') is True and status.get('state')=='ready'
                and type(status.get('pid')) is int and sum(row.get('contextId')==profile for row in status['profiles'])==1,
                '知乎必须使用本工作台保留的唯一在线独立窗口')
            self.bridge.require_profile(profile)
            if entry is not None:
                _need(self.bridge._process is entry['daemon'] and status['pid']==entry['daemon_pid'],
                    '知乎原拥有者进程已变更，本次身份不发布')
        with self.core.lock:return self._current(user,account_id,entry)

    def _response(self,entry):
        return {'platform':'zhihu','purpose':'owned_identity_observation','account_id':entry['account_id'],
            'observation_state':entry['state'],'observed_identity':deepcopy(entry.get('identity')) if entry['done'] else None,
            'account_ready':False,'grants_access':False,'real_platform_verified':False,'auto_retry':False}

    def observe(self,user,data):
        _need(type(data) is dict and set(data)=={'account_id'})
        account_id=data['account_id'];current,account=self._check(user,account_id)
        home=_plain(self.core.store.directory/'accounts'/self.tenant/account_id)
        with self.core.lock,self.lock:
            current,account=self._current(user,account_id)
            _need(not self.entries.get(account_id) or self.entries[account_id]['done'],'知乎本人核对仍在执行或收尾')
            _need(account_id in self.entries or len(self.entries)<16,'知乎本人核对槽已满')
            entry={'account_id':account_id,'actor_id':current['id'],'actor':_actor(current),'account':_digest(account),
                'device_id':self.device_id,'profile':account['conn_id'],'home':home,'uid':account.get('platform_uid') or '',
                'daemon':self.bridge._process,'daemon_pid':getattr(self.bridge._process,'pid',None),
                'job_id':'zhihu-self-'+uuid4().hex,'stop':threading.Event(),'expires':time.monotonic()+35,
                'state':'observing_identity','done':False,'identity':None}
            self.entries[account_id]=entry
        call=_ZhihuIdentityCall(self,user,entry)
        try:
            with account_execution_lock(home):
                try:
                    payload=self.core.adapters.execute('zhihu',['--profile',entry['profile'],'zhihu','whoami','-f','json'],
                        home,entry['job_id'],timeout=30,_zhihu_identity_call=call)
                except _ZhihuIdentityCleanupPending as pending:
                    with self.lock:entry['state']='cleaning_candidate'
                    while not pending.finish():time.sleep(.05)
                    raise IdentityObservationError('知乎本人核对收尾后停止，身份尚未发布') from None
                identity=project_identity(payload)
                self._check(user,account_id,entry)
                with self.core.lock,self.lock:
                    current,account=self._current(user,account_id,entry)
                    _need(self.scope_guard(current,account) is None)
                    self._current(user,account_id,entry)
                    _need(not entry['uid'] or identity['uid']==entry['uid'],'知乎当前本人 UID 与保存绑定不一致；保留原绑定')
                    entry['identity']=identity
                    entry['state']='matching_saved_identity' if entry['uid'] else 'pending_manual_review'
        except Exception:
            with self.lock:entry['state']='cancelled' if entry['stop'].is_set() else 'failed';entry['identity']=None
            raise IdentityObservationError('知乎本人核对未完成；保留账号绑定与风险，请人工核实') from None
        finally:
            call.active=False
            with self.lock:entry['done']=True
        return self._response(entry)

    def status(self,user,data):
        _need(type(data) is dict and set(data)=={'account_id'})
        with self.core.lock,self.lock:
            current,account=self._identity(user,data['account_id']);entry=self.entries.get(data['account_id'])
            _need(entry is not None and entry['actor_id']==current['id'] and entry['device_id']==self.device_id)
            _need(entry['account']==_digest(account),'知乎账号绑定已变更，请重新核对')
            return self._response(entry)

    def cancel(self,user,data):
        _need(type(data) is dict and set(data)=={'account_id'})
        with self.core.lock,self.lock:
            current,_=self._identity(user,data['account_id']);entry=self.entries.get(data['account_id'])
            _need(entry is not None and entry['actor_id']==current['id'] and entry['device_id']==self.device_id)
            entry['stop'].set();job_id=entry['job_id']
        self.core.adapters.cancel(job_id)
        return {'cancel_requested':True,'account_id':data['account_id']}

    def close(self):
        with self.lock:
            self.closed=True;jobs=[]
            for entry in self.entries.values():
                entry['stop'].set()
                if not entry['done']:jobs.append(entry['job_id'])
        for job_id in jobs:self.core.adapters.cancel(job_id)
