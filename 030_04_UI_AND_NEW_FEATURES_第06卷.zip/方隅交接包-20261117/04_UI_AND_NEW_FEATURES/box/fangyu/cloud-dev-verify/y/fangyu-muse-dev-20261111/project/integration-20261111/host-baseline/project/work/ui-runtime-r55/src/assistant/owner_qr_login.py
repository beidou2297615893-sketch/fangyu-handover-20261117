"""Owned local XHS QR login, with no employee/cloud identity or cookie copy."""
from copy import deepcopy
import os
from pathlib import Path
import re
import stat
import struct
import subprocess
import threading
import time
from uuid import uuid4

from core import CoreError
from core.adapters import (account_execution_lock, _BilibiliOwnedCleanupPending,
                           _cli_json, _xhs_error_code, _raise_xhs_cli_error)
from core.engine import evaluate_xhs_identity, now

_KEY=re.compile(r'[a-f0-9]{24}\Z')
_MESSAGES={'starting':'正在核对本人账号及固定组件范围，尚未生成二维码。',
    'waiting_scan':'请用本人小红书手机App扫描；二维码不证明已登录。',
    'checking':'登录进程已退出，正在核对权威UID与当前账号风险。',
    'cleanup_pending':'进程退出尚未确认；保留原账号锁，不再生成二维码。',
    'completed':'本次平台状态已核对为同一已知UID；读取与归档仍分别受限。',
    'cancelled':'本次登录已取消且进程收尾已确认；没有自动重试。',
    'failed':'本次结果未确认或条件已变化；保留原风险与身份，停止自动操作。'}

class _LoginCleanupPending(_BilibiliOwnedCleanupPending):
    # Reuse the reviewed original exact-process cleanup algorithm verbatim.
    # Its mechanical finish method does not grant Bili or platform authority.
    def __init__(self,adapters,process,key,job_id):
        RuntimeError.__init__(self,'本人扫码进程仍待收尾')
        self.adapters,self.process,self.key,self.job_id=adapters,process,key,job_id

class OwnerQRLogin:
    def __init__(self,owner):
        self.owner,self.server=owner,owner.server
        self._core,self._instance=self.server.core,owner.instance
        self._jobs={}
        self._closed=False

    def _cleanup_actor(self,job):
        # Called under the original Core lock only after this exact retained
        # process physically finished. Saved ownership is a cleanup claim, not
        # a session or a renewed status/CLI/component grant.
        core=self._core
        if (self.owner.server is not self.server or self.server.core is not core
                or self.owner.instance is not self._instance
                or self.server._self_operating_reads is not self.owner
                or job.get('_physical_exit_confirmed') is not True
                or job.get('process') is not None or job.get('_owns_logging_status') is not True
                or job.get('kind')!='owner_xhs_qr_login'):
            raise CoreError('本次登录收尾归属尚未确认')
        with self.server.job_lock:
            if self._jobs.get(job['id']) is not job or self.server.jobs.get(job['id']) is not job:
                raise CoreError('本次登录收尾登记已变化')
        company=self._instance.check()
        if (self.server.company!=company or core.store.directory!=self._instance.directory/'data'
                or core.deployment_config.get('id')!=company['id']
                or core.deployment_config.get('edition')!='owner'
                or core.deployment_config.get('personalMode') is not True):
            raise CoreError('本人登录收尾实例已变化')
        claim=job.get('_cleanup_actor_claim')
        fields=('id','tenant_id','username','role','personal_owner','cloud_bound')
        saved=core.store.get('users',job['user_id'])
        if (type(claim) is not dict or set(claim)!=set(fields) or claim.get('id')!=job['user_id']
                or not saved or saved.get('disabled') or saved.get('personal_owner') is not True
                or saved.get('role')!='admin' or saved.get('cloud_bound') not in (None,False)
                or any(saved.get(k)!=claim.get(k) for k in fields)
                or self.owner._identity!=tuple(saved.get(k) for k in ('id','tenant_id','username'))):
            raise CoreError('本人登录收尾身份已变化')
        return saved

    def _lookup(self,token,job_id):
        if type(job_id) is not str or not _KEY.fullmatch(job_id):raise CoreError('本次登录编号无效')
        user=self.owner._actor(token)
        with self.server.job_lock:
            job=self._jobs.get(job_id)
            if not job or self.server.jobs.get(job_id) is not job or job['user_id']!=user['id']:
                raise CoreError('此登录不属于当前本人会话')
        self.owner._account(user,job['account_id'],cleanup=True)
        return job

    def _fresh(self,job):
        if self._closed or self.server.closing or job['_cancel'].is_set():raise CoreError('本次扫码已停止')
        user=self.owner._actor(job['_token'])
        account=self.owner._account(user,job['account_id'],checking=True,login=True)
        if (user['id']!=job['user_id'] or account.get('platform_uid')!=job['_expected_uid']
                or job.get('_snapshot') is not None and account!=job['_snapshot']):
            raise CoreError('扫码期间本人身份或账号记录已变化')
        return user,account

    def _existing(self,user,account_id,*,active_only=False):
        # A RAM handle is metadata, not a renewed platform grant. The caller
        # has already checked current actor + exact account access for cleanup.
        with self.server.job_lock:
            matches=[job for job in self._jobs.values()
                     if job['account_id']==account_id and job['user_id']==user['id']
                     and self.server.jobs.get(job['id']) is job
                     and (not active_only or not job['_done'].is_set())]
            return matches[-1] if matches else None

    def recover(self,token,data):
        if set(data)!={'account_id'}:raise CoreError('找回本次登录仅接受已有本人账号编号')
        user=self.owner._actor(token)
        account=self.owner._account(user,data['account_id'],cleanup=True)
        job=self._existing(user,account['id'])
        return {'purpose':'owner_xhs_qr_login_recovery','account_id':account['id'],
                'login_job':self._view(job) if job is not None else None,'auto_retry':False}

    def _qr_bytes(self,job):
        if job['_done'].is_set() or job['_cancel'].is_set() or job['phase']!='waiting_scan':
            raise CoreError('本次二维码已失效')
        process=job.get('process')
        if process is None or process.poll() is not None:raise CoreError('本次扫码进程已结束')
        path=job['_qr_path'];root=job['_directory']
        current=root
        for part in path.relative_to(root).parts[:-1]:
            current=current/part;attrs=current.lstat()
            if (not stat.S_ISDIR(attrs.st_mode) or current.is_symlink()
                    or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
                raise CoreError('二维码目录已变化')
        attrs=path.lstat()
        if (not stat.S_ISREG(attrs.st_mode) or path.is_symlink() or attrs.st_nlink!=1
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
                or not 32<attrs.st_size<=1048576):raise CoreError('本次二维码尚不可用')
        raw=path.read_bytes()
        if len(raw)!=attrs.st_size or raw[:16]!=b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR':raise CoreError('本次二维码格式无效')
        width,height=struct.unpack('>II',raw[16:24])
        if not 1<=width<=2048 or not 1<=height<=2048:raise CoreError('本次二维码超出范围')
        return raw

    def qr(self,token,job_id):
        job=self._lookup(token,job_id)
        user=self.owner._actor(token)
        account=self.owner._account(user,job['account_id'],checking=True,login=True)
        if account.get('platform_uid')!=job['_expected_uid']:raise CoreError('本人UID记录已变化')
        binding=self.server._runtime_license_review_binding
        if binding is None or not binding.current(self.server.company):raise CoreError('固定组件审核已变化')
        try:return self._qr_bytes(job)
        except (OSError,ValueError,UnicodeError):raise CoreError('本次二维码尚不可用') from None

    def _view(self,job):
        ready=False
        try:self._qr_bytes(job);ready=True
        except (OSError,ValueError,UnicodeError):pass
        done=job['_done'].is_set()
        phase=job['phase'] if not done or job['cleanup_confirmed'] else 'cleanup_pending'
        return {'schema_version':1,'purpose':'owner_xhs_qr_login','job_id':job['id'],
            'account_id':job['account_id'],'state':phase,'qr_ready':ready,
            'qr_url':'/owner-login-qr/'+job['id'] if ready else '',
            'cleanup_confirmed':bool(done and job['cleanup_confirmed']),
            'verified':bool(done and job['verified'] and phase=='completed'),
            'auto_retry':False,'archive_available':False,'message':_MESSAGES[phase]}

    def dispatch(self,token,operation,data):
        if operation=='account_login_recover':return self.recover(token,data)
        if operation=='account_login_start':
            if set(data)!={'account_id'}:raise CoreError('扫码仅接受已有本人账号编号')
            user=self.owner._actor(token)
            accessible=self.owner._account(user,data['account_id'],cleanup=True)
            existing=self._existing(user,accessible['id'],active_only=True)
            if existing is not None:return self._view(existing)
            account=self.owner._account(user,data['account_id'],checking=True)
            self.owner._require_activity_safe(user,account)
            with self.owner._call(token,account,checking=True):pass
            with self.server.job_lock:
                if self._closed or self.server.closing:raise CoreError('自营实例正在退出')
                for job in self._jobs.values():
                    if job['account_id']==account['id'] and not job['_done'].is_set():return self._view(job)
                if len(self._jobs)>=16:raise CoreError('本次会话登录记录已达上限；先核对已有记录')
                key=uuid4().hex[:24]
                job={'id':key,'kind':'owner_xhs_qr_login','user_id':user['id'],'account_id':account['id'],
                    'status':'running','phase':'starting','cleanup_confirmed':False,'verified':False,
                    '_token':token,'_expected_uid':account['platform_uid'],'_snapshot':deepcopy(account),
                    '_cleanup_actor_claim':{k:deepcopy(user.get(k)) for k in
                        ('id','tenant_id','username','role','personal_owner','cloud_bound')},
                    '_cancel':threading.Event(),'_done':threading.Event()}
                worker=threading.Thread(target=self._run,args=(job,),name='owner-qr-'+key,daemon=False)
                job['_thread']=worker;self._jobs[key]=job;self.server.jobs[key]=job
                try:worker.start()
                except RuntimeError:
                    job.update(status='failed',phase='failed',cleanup_confirmed=True);job['_done'].set();raise CoreError('本次登录未启动') from None
            return self._view(job)
        if set(data)!={'job_id'}:raise CoreError('本次状态或取消仅接受登录编号')
        job=self._lookup(token,data['job_id'])
        if operation=='account_login_cancel':
            # The same short lock spans the last fresh check and Popen above.
            with self.server.job_lock:
                # Only cleanup may use the current same owner's replacement
                # session. _fresh/platform calls always keep the original token.
                job['_cleanup_token']=token;job['_cancel'].set()
            # No current risk/license gate can prevent this exact cleanup.
            self.server.core.adapters.cancel(job['id'])
        return self._view(job)

    def _finish(self,job,process,key):
        pending=_LoginCleanupPending(self.server.core.adapters,process,key,job['id'])
        while True:
            try:
                with self.server.core.adapters.lifecycle_lock:
                    if self.server.core.adapters.processes.get(key) not in (None,process):
                        raise RuntimeError('本人登录进程登记已变化')
                finished=pending.finish()
            except Exception:
                # A cleanup observation failure cannot release physical
                # ownership, even if its caller's authority is gone.
                finished=False
            if finished:break
            job['phase']='cleanup_pending';threading.Event().wait(.1)
        with self.server.core.adapters.lifecycle_lock:
            # This private UUID registration was set only for this process.
            if self.server.core.adapters.processes.get(key) not in (None,process):
                raise RuntimeError('本人登录进程登记已变化')
            self.server.core.adapters.process_accounts.pop(key,None)
            if job.get('process') is process:job.pop('process',None)
            job['_physical_exit_confirmed']=True

    def _process(self,job,spec,args,timeout):
        core=self.server.core;adapters=core.adapters
        user,account=self._fresh(job)
        directory=job['_directory']
        if (spec.get('argv')!=[str(self.server.guarded_cli_executable),'xiaohongshu',*args]
                or spec.get('cwd')!=str(directory)
                or (spec.get('env') or {}).get('HOME')!=str(directory)
                or spec['env'].get('WORKSPACE_ACTIVITY_LOG')!=str(directory/'platform-activity.jsonl')):
            raise CoreError('本人扫码不使用其他命令或账号目录')
        process=None;key=uuid4().hex
        with self.owner._call(job['_token'],account,checking=True,login=True):
            # Full original runtime/material check is outside short spawn locks.
            self.owner.execution_guard('xiaohongshu')
            try:
                with core.lock,adapters.lifecycle_lock,self.server.job_lock:
                    self._fresh(job)
                    binding=self.server._runtime_license_review_binding
                    if adapters.closed or binding is None or not binding.current(self.server.company):raise CoreError('本次启动条件已变化')
                    self.owner._require_activity_safe(user,account)
                    env={**os.environ,**spec['env']}
                    if args==['login','--qrcode']:env['WORKSPACE_QR_PATH']=str(job['_qr_path'])
                    process=subprocess.Popen(spec['argv'],shell=False,env=env,cwd=spec['cwd'],
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',
                        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    # Retain it before any later registration can fail.
                    job['process']=process
                    job['_physical_exit_confirmed']=False
                    adapters.processes[key]=process;adapters.process_accounts[key]=directory.resolve()
                    adapters.job_processes[job['id']]=process
                    job['phase']='waiting_scan' if args==['login','--qrcode'] else 'checking'
                stdout,_=process.communicate(timeout=timeout)
                if type(stdout) is not str or len(stdout.encode('utf-8'))>65536:raise CoreError('本人平台输出超出固定范围')
            finally:
                if process is not None:self._finish(job,process,key)
            self._fresh(job)
            self.owner.execution_guard('xiaohongshu')
            if process.returncode:
                adapters._record_cli_outcome(spec,args,'process_failed',process.returncode,stdout)
                raise CoreError('本次平台登录或核对未完成')
            if args==['status','--json']:
                payload=_cli_json(stdout)
                code=_xhs_error_code(payload)
                if code:_raise_xhs_cli_error(code)
                if type(payload) is not dict or payload.get('ok') is False or payload.get('error') is not None:
                    raise CoreError('本次平台身份观察无效')
            else:payload=None  # Upstream QR login prints progress, not JSON.
            adapters._record_cli_outcome(spec,args,'completed',process.returncode)
            return payload

    def _run(self,job):
        core=self.server.core;confirmed=False
        try:
            user,account=self._fresh(job)
            directory=core.store.directory/'accounts'/user['tenant_id']/account['id']
            job['_directory']=directory
            with account_execution_lock(directory):
                with self.owner._call(job['_token'],account,checking=True):
                    if core.adapters.manifest('xiaohongshu').get('auth_args')!=['login','--qrcode']:
                        raise CoreError('此原适配器不支持固定二维码登录')
                    spec=core.handle('account_login_spec',{'id':account['id']},core._public(user))
                job['_snapshot']=core.store.get('accounts',account['id'])
                # Only the completed original account_login_spec can claim this
                # RAM status ownership. The original same HOME lock is retained.
                if job['_snapshot'].get('status')!='logging_in':raise CoreError('原登录状态未确认')
                job['_owns_logging_status']=True
                qr_dir=directory/'work'/'owner-login';qr_dir.mkdir(parents=True,exist_ok=True)
                job['_qr_path']=qr_dir/(job['id']+'.png')
                self._process(job,spec,['login','--qrcode'],240)
                if job['_cancel'].is_set():raise CoreError('本次已取消')
                user,account=self._fresh(job)
                with self.owner._call(job['_token'],account,checking=True,login=True):
                    manifest=core.adapters.manifest('xiaohongshu')
                    if manifest.get('status_args')!=['status','--json']:raise CoreError('状态核对路线已变化')
                    status_spec=core.adapters.account_spec('xiaohongshu',directory,['status','--json'])
                payload=self._process(job,status_spec,['status','--json'],35)
                result=payload.get('data',payload)
                if type(result) is not dict:raise CoreError('平台身份观察结构未知')
                with self.owner._call(job['_token'],account,checking=True,login=True):
                    self.owner.execution_guard('xiaohongshu')
                    with core.lock,self.server.job_lock:
                        fresh_user,current=self._fresh(job)
                        binding=self.server._runtime_license_review_binding
                        if binding is None or not binding.current(self.server.company):raise CoreError('组件审核已变化')
                        self.owner._require_activity_safe(fresh_user,current)
                        decision=evaluate_xhs_identity(current,result,core.store.list('accounts',fresh_user['tenant_id']))
                        if not decision['verified'] or decision['uid']!=job['_expected_uid']:
                            raise CoreError('平台身份尚未核实为同一已知UID')
                        current.update(status=decision['status'],checked_at=now())
                        if decision['nickname']:current['platform_nickname']=decision['nickname']
                        core.store.put('accounts',current)
                        job.update(status='completed',phase='completed',verified=True)
                confirmed=True
        except Exception:
            # Never echo vendor output, exception strings, QR URLs or credentials.
            job.update(status='cancelled' if job['_cancel'].is_set() else 'failed',
                       phase='cancelled' if job['_cancel'].is_set() else 'failed',verified=False)
        finally:
            # No permission/risk check is needed to finish physical ownership.
            if job.get('process') is not None:raise RuntimeError('本人进程未完成收尾；不能释放所有权')
            if not confirmed:
                try:
                    with core.lock:
                        user=(self._cleanup_actor(job) if job.get('_physical_exit_confirmed') is True
                              else self.owner._actor(job.get('_cleanup_token',job['_token'])))
                        current=self.owner._account(user,job['account_id'],cleanup=True)
                        snapshot=job.get('_snapshot') or {}
                        stable=('id','tenant_id','platform','platform_uid','cloud_owner','conn_id')
                        if (job.get('_owns_logging_status') is True
                                and self._jobs.get(job['id']) is job and self.server.jobs.get(job['id']) is job
                                and all(current.get(k)==snapshot.get(k) for k in stable)
                                and current.get('status')=='logging_in'):
                            # Keep every current risk/review/name/UID field. A
                            # manually changed status or stable owner is never
                            # replaced by this job's conservative cleanup.
                            current['status']='login_required';core.store.put('accounts',current)
                except (OSError,ValueError,CoreError):pass  # Preserve unknown saved state after authority loss.
            job['cleanup_confirmed']=True;job['_done'].set()

    def close(self):
        with self.server.job_lock:
            self._closed=True; jobs=list(self._jobs.values())
            for job in jobs:job['_cancel'].set()
        for job in jobs:
            self.server.core.adapters.cancel(job['id'])
        deadline=time.monotonic()+3
        for job in jobs:
            if job['_thread'] is not threading.current_thread():job['_thread'].join(max(0,deadline-time.monotonic()))
        return all(job['_done'].is_set() and job.get('cleanup_confirmed') is True
                   and not job['_thread'].is_alive() and job.get('process') is None for job in jobs)
