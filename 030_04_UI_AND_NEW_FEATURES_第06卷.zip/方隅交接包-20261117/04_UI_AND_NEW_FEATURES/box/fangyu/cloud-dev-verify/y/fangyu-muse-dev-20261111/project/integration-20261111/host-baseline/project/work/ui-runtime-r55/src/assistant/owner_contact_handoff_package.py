"""Consent-scoped, owner-local manual handoff packages.

Only the sealed download result can emit contact bytes. Normal projections are
metadata; neither generating nor writing an attachment records delivery or ACK.
"""
from contextlib import contextmanager
from copy import deepcopy
import base64
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sqlite3
import threading
import time

from core import CoreError
from .self_operating_acquisition import (OwnerAcquisition, OwnerAcquisitionError,
    _OwnerReceipts, _row, _identity, _safe_label, _ACTOR, _LOCAL, _KEY, _HEX, _UID,
    digest, RECEIPT_ENTITY)

ACTIONS = frozenset(('owner_handoff_package_create', 'owner_handoff_package_status',
    'owner_handoff_package_download'))
ENTITY = 'owner_contact_handoff_packages_v1'
CLAIMS = 'owner_contact_handoff_package_claims_v1'
PURPOSE = 'owner_contact_handoff_package_v1'
MAX_BYTES = 1048576
MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
_SEAL = object()


def _fail(message, committed=False):
    raise OwnerAcquisitionError(message, mutation_committed=committed)


class _PackagePreflightRejected(OwnerAcquisitionError):
    # Internal evidence only: never constructed from HTTP failure flags. Full
    # source/contact proofs and current session precede this no-write decision.
    def __init__(self, reason, proofs, seal):
        if seal is not _SEAL or reason not in ('usage_mismatch', 'pending_overlap', 'duplicate_contact', 'withdrawn'):
            raise ValueError('Invalid private preflight rejection')
        self.reason = reason
        self.proofs = deepcopy(proofs)
        super().__init__('本批在生成前已拒绝，没有生成文件；请核对原号后结束并修正', mutation_committed=False)


def _encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def _sha(value):
    return hashlib.sha256(value).hexdigest()


def _seal_artifact(payload):
    # This is the existing CurrentUser DPAPI boundary, never a substitute cipher.
    from integrations import protect
    return protect(_encode(payload).encode('utf-8'))


def _unseal_artifact(value):
    from integrations import protect
    try:
        result = json.loads(protect(base64.b64decode(value, validate=True), decrypt=True))
    except Exception:
        _fail('本机资料包无法解封，请使用生成时的 Windows 账户核对')
    if type(result) is not dict:
        _fail('本机资料包密封结构需核对')
    return result


class _PackageContext:
    """A private, same-thread/same-connection bridge, not an HTTP permission."""
    def __init__(self, service, db, token, user, seal):
        if seal is not _SEAL or type(service) is not OwnerContactHandoffPackages:
            _fail('资料包事务范围无法核对')
        self.service, self.db, self.token = service, db, token
        self.user, self.thread, self.seal = deepcopy(user), threading.get_ident(), seal


def _validate_package_context(context, acquisition, db):
    if (type(context) is not _PackageContext or context.seal is not _SEAL
            or context.thread != threading.get_ident() or context.db is not db
            or type(context.service) is not OwnerContactHandoffPackages
            or context.service.acquisition is not acquisition
            or acquisition._packages is not context.service):
        _fail('只能核对当前本人资料包的同连接事务')
    context.service._session(db, context.token, context.user)
    return context


class _OwnerHandoffPackageDownload:
    def __init__(self, service, token, record, seal):
        if seal is not _SEAL or type(service) is not OwnerContactHandoffPackages:
            _fail('资料包下载来源无法核对')
        self.service, self.token, self.record, self.seal = service, token, deepcopy(record), seal
        self._used = False

    def emit(self, handler):
        if (self.seal is not _SEAL or self._used
                or handler.server is not self.service.acquisition.server
                or handler.token() != self.token):
            _fail('请从当前本人页面明确下载原资料包')
        self._used = True
        self.service._emit(self, handler)


class OwnerContactHandoffPackages:
    def __init__(self, acquisition):
        if type(acquisition) is not OwnerAcquisition:
            _fail('资料包只能由原本人业务服务创建')
        self.acquisition = acquisition
        self.workspace, self.core = acquisition.workspace, acquisition.core

    def _session(self, db, token, user):
        current = self.acquisition._current(token)
        session = db.execute('SELECT user_id,expires FROM sessions WHERE token=?',
            (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
        saved = _row(db, 'users', user['id'], user['tenant_id'])
        if (session is None or session['user_id'] != user['id']
                or type(session['expires']) not in (int, float) or not math.isfinite(session['expires'])
                or session['expires'] <= time.time()
                or saved is None or saved.get('disabled') or saved.get('role') != 'admin'
                or saved.get('personal_owner') is not True or saved.get('cloud_bound') not in (None, False)
                or _identity(saved, _ACTOR) != _identity(user, _ACTOR)
                or _identity(current, _ACTOR) != _identity(user, _ACTOR)):
            _fail('本人会话或角色已变化，请重新进入后核对原资料包')
        return saved

    @contextmanager
    def _transaction(self, token, user, *, emit=False, mutating=False):
        # Same order as original owner writes/revoke/logout. Never release another
        # worker's mutex. Native calls cannot be forcibly interrupted by this budget.
        deadline = time.monotonic() + 5.0
        locks = []
        try:
            for lock in (self.workspace._lock, self.core.lock):
                if not lock.acquire(timeout=max(0.0, deadline - time.monotonic())):
                    _fail('当前本机操作忙，请保留原编号稍后核对')
                locks.append(lock)
            with self.core.store.connect() as db:
                remaining = max(1, int(max(0.0, deadline - time.monotonic()) * 1000))
                db.execute('PRAGMA busy_timeout=' + str(remaining))
                db.execute('BEGIN IMMEDIATE')
                validation_deadline = time.monotonic() + 3.0
                db.set_progress_handler(lambda: int(time.monotonic() >= validation_deadline), 1000)
                context = _PackageContext(self, db, token, user, _SEAL)
                self._session(db, token, user)
                yield db, context, validation_deadline
                db.set_progress_handler(None, 0)
        except sqlite3.Error:
            # SQLite COMMIT can raise after the started/claim write boundary.
            # Never tell the UI that a mutating transaction definitely did not
            # commit; the original key/status remains the recovery path.
            _fail('本机资料核对未完成，请保留原编号', None if emit or mutating else False)
        finally:
            for lock in reversed(locks):
                lock.release()

    def _deadline(self, deadline):
        if time.monotonic() >= deadline:
            _fail('本批核对超过本次预算，请保留原编号')

    def _selection(self, data):
        if (set(data) != {'drafts', 'recipient_id', 'purpose', 'idempotency_key', 'confirmed'}
                or data.get('confirmed') is not True or type(data.get('drafts')) is not list
                or not 1 <= len(data['drafts']) <= 50
                or type(data.get('idempotency_key')) is not str or not _KEY.fullmatch(data['idempotency_key'])):
            _fail('请明确选择 1–50 个原草稿、接收人和用途')
        recipient = _safe_label(data['recipient_id'], '接收人', 80)
        purpose = _safe_label(data['purpose'], '用途', 100)
        rows = []
        for row in data['drafts']:
            if (type(row) is not dict or set(row) != {'operation_id', 'account_id', 'lead_id', 'draft_id', 'handoff_key'}
                    or any(type(row.get(k)) is not str or not _HEX.fullmatch(row[k]) for k in ('operation_id', 'lead_id'))
                    or any(type(row.get(k)) is not str or not _UID.fullmatch(row[k]) for k in ('account_id', 'draft_id'))
                    or type(row.get('handoff_key')) is not str or not _KEY.fullmatch(row['handoff_key'])):
                _fail('请选择原历史已核对的草稿，不接受联系方式或文件路径')
            rows.append(deepcopy(row))
        if len({r['operation_id'] for r in rows}) != len(rows) or len({r['draft_id'] for r in rows}) != len(rows):
            _fail('同一草稿不能重复选择')
        rows.sort(key=lambda r: r['draft_id'])
        return rows, recipient, purpose

    def _ident(self, key):
        return digest([self.acquisition.tenant, self.acquisition.owner, self.acquisition.instance_id, PURPOSE, key])

    def _record(self, db, key, user):
        ident = self._ident(key)
        record = _row(db, ENTITY, ident, user['tenant_id'])
        if record is None:
            return None
        expected_fields = {'id', 'tenant_id', 'cloud_owner', 'actor_digest', 'company_id', 'instance_id',
            'idempotency_key', 'state', 'selection', 'selection_digest', 'recipient_id', 'handoff_purpose',
            'proofs', 'created_at', 'updated_at', 'artifact', 'encrypted_artifact'}
        if (set(record) != expected_fields or record.get('id') != ident or record.get('tenant_id') != user['tenant_id']
                or record.get('cloud_owner') != self.acquisition.owner
                or record.get('actor_digest') != digest(_identity(user, _ACTOR))
                or record.get('company_id') != self.acquisition.server.company['id']
                or record.get('instance_id') != self.acquisition.instance_id
                or record.get('idempotency_key') != key
                or record.get('state') not in ('started', 'unknown', 'succeeded', 'rejected', 'cancelled')
                or type(record.get('selection')) is not list or not 1 <= len(record['selection']) <= 50
                or record.get('selection_digest') != digest({'selection': record['selection'], 'proofs': record.get('proofs'),
                    'recipient_id': record.get('recipient_id'), 'purpose': record.get('handoff_purpose')})
                or type(record.get('proofs')) is not list or len(record['proofs']) != len(record['selection'])
                or type(record.get('encrypted_artifact')) is not str
                or record['state'] == 'succeeded' and not record['encrypted_artifact']):
            _fail('原资料包归属或记录需人工核对')
        selection, recipient, purpose = self._selection({'drafts': record['selection'],
            'recipient_id': record['recipient_id'], 'purpose': record['handoff_purpose'],
            'idempotency_key': key, 'confirmed': True})
        if (selection != record['selection'] or recipient != record['recipient_id'] or purpose != record['handoff_purpose']
                or any(type(record[k]) not in (int, float) or not math.isfinite(record[k]) or record[k] <= 0
                    for k in ('created_at', 'updated_at'))):
            _fail('原批次选集和元数据需核对')
        for selected, proof in zip(selection, record['proofs']):
            if (type(proof) is not dict or set(proof) != {'draft_id', 'contact_reference', 'binding_digest',
                    'receipt_digest', 'draft_digest', 'contact_digest'}
                    or proof['draft_id'] != selected['draft_id']
                    or type(proof['contact_reference']) is not str
                    or not re.fullmatch(r'contact:[a-f0-9]{32}', proof['contact_reference'])
                    or any(type(proof[k]) is not str or not _HEX.fullmatch(proof[k])
                        for k in ('binding_digest', 'receipt_digest', 'draft_digest', 'contact_digest'))):
                _fail('原批次核对证据需人工复核')
        if record['state'] != 'rejected' and len({p['contact_reference'] for p in record['proofs']}) != len(selection):
            _fail('原批次保护联系人出现重复')
        artifact = record['artifact']
        if record['state'] == 'succeeded':
            if (type(artifact) is not dict or set(artifact) != {'filename', 'mime', 'bytes', 'sha256', 'generated_at'}
                    or artifact['filename'] != '人工交接资料包_' + ident[:12] + '_含联系方式.xlsx'
                    or artifact['mime'] != MIME or type(artifact['bytes']) is not int or not 1 <= artifact['bytes'] <= MAX_BYTES
                    or type(artifact['sha256']) is not str or not _HEX.fullmatch(artifact['sha256'])
                    or type(artifact['generated_at']) not in (int, float) or not math.isfinite(artifact['generated_at'])
                    or artifact['generated_at'] <= 0):
                _fail('原密封产物描述需核对')
        elif artifact is not None or record['encrypted_artifact']:
            _fail('未决批次不能声称已有完整产物')
        return record

    def _put(self, db, record):
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
            (ENTITY, record['id'], record['tenant_id'], _encode(record)))

    def _proofs(self, db, context, rows, recipient, purpose, deadline, *, decrypt=False, _preflight=None):
        from .acquisition_contacts import AcquisitionContacts
        acq = self.acquisition
        proofs, values, seen = [], [], set()
        usage_mismatch = duplicate_contact = withdrawn = False
        if _preflight is _SEAL and decrypt:
            raise ValueError('Private preflight may only validate metadata')
        for selected in rows:
            self._deadline(deadline)
            if selected['operation_id'] != digest([acq.tenant, acq.owner, 'handoff_create', selected['handoff_key']]):
                _fail('原草稿和成功操作编号不一致')
            original = _row(db, RECEIPT_ENTITY, selected['operation_id'], acq.tenant)
            stored = original.get('owner_acquisition_scope') if original else None
            if (original is None or original.get('state') != 'succeeded'
                    or original.get('original_action') != 'handoff_create'
                    or original.get('cloud_owner') != acq.owner
                    or original.get('idempotency_key') != selected['handoff_key']
                    or type(stored) is not dict or stored.get('account_id') != selected['account_id']
                    or stored.get('lead_id') != selected['lead_id']
                    or stored.get('local_instance_id') != acq.instance_id
                    or stored.get('actor_digest') != digest(_identity(context.user, _ACTOR))):
                _fail('仅可使用当前本人来源的原成功草稿')
            with acq._call(context.token, 'contact_read', selected['account_id'], selected['lead_id'],
                    _stored_binding=stored, _shared_db=db, _package_context=context) as user:
                receipts = _OwnerReceipts(acq._scope)
                fresh = receipts._read(db, selected['operation_id'], 'handoff_create', selected['handoff_key'])
                if fresh != original:
                    _fail('原草稿回执在核对期间已变化')
                result, authorization = acq._history_protected_result(db, fresh, receipts._view(fresh).get('result'))
                if (authorization not in ('granted', 'withdrawn') or result.get('id') != selected['draft_id']
                        or acq._scope._frame()['binding']['privacy_redacted'] is not False
                        or authorization == 'withdrawn' and _preflight is not _SEAL):
                    _fail('原客户同意已撤回或来源需核对，不能生成或下载')
                draft = _row(db, 'acquisition_handoffs', selected['draft_id'], acq.tenant)
                if draft.get('recipient_id') != recipient or draft.get('purpose') != purpose:
                    if _preflight is not _SEAL:
                        _fail('接收人和用途必须与每份原客户同意完全一致')
                    usage_mismatch = True
                reference = draft.get('contact_reference')
                if reference in seen:
                    if _preflight is not _SEAL:
                        _fail('同一保护联系人不能用多个草稿重复加入本批')
                    duplicate_contact = True
                seen.add(reference)
                if authorization == 'withdrawn':
                    # Original protected history already proved the exact
                    # source/contact/consent snapshot, revision and empty cipher.
                    # This metadata-only rejection never calls DPAPI/contact read.
                    contact = _row(db, 'acquisition_contacts', reference[8:], acq.tenant)
                    if contact is None or contact.get('id') != reference[8:] or contact.get('tenant_id') != acq.tenant:
                        _fail('原撤回联系方式归属需核对')
                    withdrawn, payload = True, None
                else:
                    contacts = AcquisitionContacts(acq.core, acq.tenant, acq.owner, acq.server.company,
                        owner_scope=acq._scope)
                    contact, payload = contacts._package_read(reference, user, db, context, decrypt=decrypt)
                proof = {'draft_id': selected['draft_id'], 'contact_reference': reference,
                    'binding_digest': digest(acq._scope._frame()['binding']),
                    'receipt_digest': digest(original), 'draft_digest': digest(draft),
                    'contact_digest': digest(contact)}
                proofs.append(proof)
                if decrypt:
                    values.append((selected['draft_id'], selected['lead_id'], payload['phone'], payload['wechat']))
                acq._scope.check(user, db)
        self._session(db, context.token, context.user)
        self._deadline(deadline)
        if usage_mismatch or duplicate_contact or withdrawn:
            reason = 'usage_mismatch' if usage_mismatch else 'duplicate_contact' if duplicate_contact else 'withdrawn'
            raise _PackagePreflightRejected(reason, proofs, _SEAL)
        return proofs, values

    def _claim_id(self, kind, value):
        acq = self.acquisition
        return digest([acq.tenant, acq.owner, acq.instance_id, kind, value])

    def _claims(self, db, record, *, finish=False, _preflight=None):
        # Precheck every bounded draft/contact point before the first write. A
        # corrupt claim is not a proven rejection; existing unknown stays held.
        claims, pending_overlap = [], False
        for proof in record['proofs']:
            for kind, value in (('draft', proof['draft_id']), ('contact', proof['contact_reference'])):
                ident = self._claim_id(kind, value)
                old = _row(db, CLAIMS, ident, record['tenant_id'])
                if old and (set(old) != {'id', 'tenant_id', 'cloud_owner', 'instance_id', 'package_id', 'kind', 'value', 'state'}
                        or old.get('id') != ident or old.get('tenant_id') != record['tenant_id']
                        or old.get('cloud_owner') != record['cloud_owner'] or old.get('instance_id') != record['instance_id']
                        or old.get('kind') != kind or old.get('value') != value
                        or type(old.get('package_id')) is not str or not _HEX.fullmatch(old['package_id'])
                        or old.get('state') not in ('started', 'unknown', 'succeeded')):
                    _fail('原批次占用记录需核对')
                if old and old.get('package_id') != record['id'] and old.get('state') in ('started', 'unknown'):
                    pending_overlap = True
                claims.append({'id': ident, 'tenant_id': record['tenant_id'], 'cloud_owner': record['cloud_owner'],
                    'instance_id': record['instance_id'], 'package_id': record['id'], 'kind': kind,
                    'value': value, 'state': 'succeeded' if finish else 'started'})
        if pending_overlap:
            if _preflight is _SEAL and not finish:
                raise _PackagePreflightRejected('pending_overlap', record['proofs'], _SEAL)
            _fail('重叠客户的原资料包结果未知，请只核对原编号')
        for claim in claims:
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (CLAIMS, claim['id'], record['tenant_id'], _encode(claim)))

    def _xlsx(self, values, record, generated_at):
        import xlsxwriter
        expected = Path(__file__).resolve().parents[1] / 'xlsxwriter'
        if (xlsxwriter.__version__ != '3.2.9'
                or not Path(xlsxwriter.__file__).resolve().is_relative_to(expected)):
            _fail('本机 Excel 组件版本需核对')
        stream = io.BytesIO()
        workbook = xlsxwriter.Workbook(stream, {'in_memory': True, 'strings_to_formulas': False,
            'strings_to_urls': False, 'strings_to_numbers': False})
        sheet = workbook.add_worksheet('人工交接资料')
        rows = [('序号', '原草稿编号', '原来源编号', '平台', '手机号', '微信号')]
        rows += [(str(i), draft, lead, '小红书', phone, wechat)
            for i, (draft, lead, phone, wechat) in enumerate(values, 1)]
        for i, row in enumerate(rows):
            for col, value in enumerate(row):
                if sheet.write_string(i, col, value) != 0:
                    _fail('资料包内容未完整写入')
        sheet.freeze_panes(1, 0)
        sheet.set_column(0, 0, 8)
        sheet.set_column(1, 2, 38)
        sheet.set_column(3, 5, 22)
        notes = workbook.add_worksheet('核对说明')
        for i, pair in enumerate((('接收人', record['recipient_id']), ('用途', record['handoff_purpose']),
                ('生成时间', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(generated_at))),
                ('本批条数', str(len(values))),
                ('本机批次编号', record['id']), ('原生成编号', record['idempotency_key']),
                ('事实范围', '客户同意由操作者人工登记；生成和下载不证明已发送、资源部签收或成交。'),
                ('撤回提醒', '生成后撤回会禁止后续下载；已人工传出的文件需要本人联系接收人处理。'))):
            notes.write_string(i, 0, pair[0])
            notes.write_string(i, 1, pair[1])
        notes.set_column(0, 0, 22)
        notes.set_column(1, 1, 100)
        workbook.close()
        binary = stream.getvalue()
        if not 1 <= len(binary) <= MAX_BYTES:
            _fail('资料包超过本批文件大小限制')
        return binary

    def _authorization(self, db, context, record, deadline):
        if record['state'] == 'rejected':
            self._session(db, context.token, context.user)
            self._deadline(deadline)
            return {'state': 'not_applicable', 'reason_code': 'PREFLIGHT_REJECTED', 'checked_at': time.time(),
                'evidence_source': 'operator_recorded', 'independently_verified': False}
        try:
            proofs, _ = self._proofs(db, context, record['selection'], record['recipient_id'],
                record['handoff_purpose'], deadline)
            if proofs != record['proofs']:
                _fail('原来源或同意版本已变化')
            state, reason = 'current_recorded_scope', 'CURRENT_RECORDED_SCOPE'
        except CoreError:
            state, reason = 'needs_review', 'ORIGINAL_SCOPE_REVIEW'
            # Only current owner's exact private refs, with stable session; no
            # foreign identity or original exception text is projected.
            for proof in record['proofs']:
                contact = _row(db, 'acquisition_contacts', proof['contact_reference'][8:], record['tenant_id'])
                if (contact and contact.get('cloud_owner') == record['cloud_owner']
                        and contact.get('owner_acquisition_scope', {}).get('local_instance_id') == record['instance_id']
                        and contact.get('consent', {}).get('status') == 'withdrawn'):
                    state, reason = 'withdrawn', 'RECORDED_CONSENT_WITHDRAWN'
                    break
        self._session(db, context.token, context.user)
        return {'state': state, 'reason_code': reason, 'checked_at': time.time(),
            'evidence_source': 'operator_recorded', 'independently_verified': False}

    def _view(self, key, record=None, authorization=None):
        return {'purpose': PURPOSE, 'idempotency_key': key, 'instance_id': self.acquisition.instance_id,
            'package_id': record['id'] if record else None, 'state': record['state'] if record else 'unknown',
            'selected_count': len(record['selection']) if record else None,
            'draft_ids': [r['draft_id'] for r in record['selection']] if record else None,
            'selection_digest': record['selection_digest'] if record else None,
            'recipient_id': record['recipient_id'] if record else None,
            'handoff_purpose': record['handoff_purpose'] if record else None,
            'artifact': deepcopy(record['artifact']) if record else None,
            'authorization': authorization or {'state': 'not_applicable', 'reason_code': 'ORIGINAL_NUMBER_UNKNOWN',
                'checked_at': time.time(), 'evidence_source': 'operator_recorded', 'independently_verified': False},
            'needs_review': not record or record['state'] != 'succeeded'
                or authorization is None or authorization['state'] != 'current_recorded_scope',
            'generation_committed': bool(record and record['state'] == 'succeeded'), **_LOCAL}

    def _unknown(self, token, user, key):
        # If session changed, leave durable started intact (status reports it as
        # unknown). This worker never erases another unresolved claim.
        try:
            with self._transaction(token, user, mutating=True) as (db, context, deadline):
                record = self._record(db, key, user)
                if record and record['state'] == 'started':
                    record.update(state='unknown', updated_at=time.time())
                    self._put(db, record)
        except (CoreError, sqlite3.Error):
            pass

    def execute(self, token, action, data):
        if action not in ACTIONS or type(data) is not dict:
            _fail('不支持此人工交接资料包操作')
        user = self.acquisition._current(token)
        if action == 'owner_handoff_package_create':
            rows, recipient, purpose = self._selection(data)
            key = data['idempotency_key']
            with self._transaction(token, user, mutating=True) as (db, context, deadline):
                old = self._record(db, key, user)
                if old:
                    if old['selection'] != rows or old['recipient_id'] != recipient or old['handoff_purpose'] != purpose:
                        _fail('原生成编号已绑定其他选集，请先核对原号')
                    if old['state'] == 'started':
                        old = deepcopy(old); old['state'] = 'unknown'
                    return self._view(key, old, self._authorization(db, context, old, deadline))
                rejected = None
                try:
                    proofs, _ = self._proofs(db, context, rows, recipient, purpose, deadline, _preflight=_SEAL)
                except _PackagePreflightRejected as refusal:
                    rejected, proofs = refusal, refusal.proofs
                stamp = time.time()
                record = {'id': self._ident(key), 'tenant_id': user['tenant_id'], 'cloud_owner': self.acquisition.owner,
                    'actor_digest': digest(_identity(user, _ACTOR)), 'company_id': self.acquisition.server.company['id'],
                    'instance_id': self.acquisition.instance_id, 'idempotency_key': key, 'state': 'rejected' if rejected else 'started',
                    'selection': rows, 'selection_digest': digest({'selection': rows, 'proofs': proofs,
                        'recipient_id': recipient, 'purpose': purpose}), 'recipient_id': recipient,
                    'handoff_purpose': purpose, 'proofs': proofs, 'created_at': stamp, 'updated_at': stamp,
                    'artifact': None, 'encrypted_artifact': ''}
                if rejected is None:
                    try:
                        self._claims(db, record, _preflight=_SEAL)
                    except _PackagePreflightRejected as refusal:
                        rejected = refusal
                        record['state'] = 'rejected'
                # The whole current source/contact proof exists. Recheck the
                # same session before storing no-artifact/no-claim rejection.
                self._session(db, token, user)
                self._deadline(deadline)
                self._put(db, record)
                if rejected is not None:
                    return self._view(key, record, self._authorization(db, context, record, deadline))
            try:
                # Original contact DPAPI decrypt and file generation are outside
                # the final commit/output critical section. Reprove before commit.
                with self._transaction(token, user) as (db, context, deadline):
                    fresh, values = self._proofs(db, context, rows, recipient, purpose, deadline, decrypt=True)
                    if fresh != proofs:
                        _fail('生成前原同意或来源已变化')
                generated_at = time.time()
                binary = self._xlsx(values, record, generated_at)
                artifact = {'filename': '人工交接资料包_' + record['id'][:12] + '_含联系方式.xlsx',
                    'mime': MIME, 'bytes': len(binary), 'sha256': _sha(binary), 'generated_at': generated_at}
                payload = {'package_id': record['id'], 'selection_digest': record['selection_digest'],
                    'actor_digest': record['actor_digest'], 'instance_id': record['instance_id'],
                    'artifact': artifact, 'binary': base64.b64encode(binary).decode('ascii')}
                sealed = _seal_artifact(payload)
                with self._transaction(token, user, mutating=True) as (db, context, deadline):
                    current = self._record(db, key, user)
                    fresh, _ = self._proofs(db, context, rows, recipient, purpose, deadline)
                    if current != record or fresh != proofs:
                        _fail('原生成记录或客户同意已变化')
                    record.update(state='succeeded', updated_at=time.time(), artifact=artifact,
                        encrypted_artifact=base64.b64encode(sealed).decode('ascii'))
                    self._put(db, record)
                    self._claims(db, record, finish=True)
                    event = {'id': record['id'], 'tenant_id': record['tenant_id'], 'cloud_owner': record['cloud_owner'],
                        'package_id': record['id'], 'kind': 'local_package_generated',
                        'artifact_sha256': artifact['sha256'], 'selected_count': len(rows), 'occurred_at': time.time()}
                    db.execute('INSERT INTO records VALUES(?,?,?,?)',
                        ('owner_contact_handoff_package_events_v1', event['id'], event['tenant_id'], _encode(event)))
                    result = self._view(key, record, self._authorization(db, context, record, deadline))
                return result
            except Exception:
                self._unknown(token, user, key)
                raise OwnerAcquisitionError('生成结果需核对，请保留原编号，不要重新生成', mutation_committed=None) from None
        required = {'idempotency_key'} if action == 'owner_handoff_package_status' else {'idempotency_key', 'package_id', 'artifact_sha256'}
        if (set(data) != required or type(data.get('idempotency_key')) is not str
                or not _KEY.fullmatch(data['idempotency_key'])):
            _fail('请核对原资料包编号，不接受文件路径或选集重发')
        key = data['idempotency_key']
        with self._transaction(token, user) as (db, context, deadline):
            record = self._record(db, key, user)
            if action == 'owner_handoff_package_status':
                if record and record['state'] == 'started':
                    record = deepcopy(record); record['state'] = 'unknown'
                return self._view(key, record, self._authorization(db, context, record, deadline) if record else None)
            if (record is None or record['state'] != 'succeeded' or type(data['package_id']) is not str
                    or not _HEX.fullmatch(data['package_id']) or data['package_id'] != record['id']
                    or type(data['artifact_sha256']) is not str or not _HEX.fullmatch(data['artifact_sha256'])
                    or data['artifact_sha256'] != record['artifact']['sha256']):
                _fail('只能下载原编号已确认生成的同一资料包')
            if self._authorization(db, context, record, deadline)['state'] != 'current_recorded_scope':
                _fail('当前来源或客户同意需核对，资料包不可下载')
        return _OwnerHandoffPackageDownload(self, token, record, _SEAL)

    def _emit(self, download, handler):
        record, token = download.record, download.token
        user = self.acquisition._current(token)
        payload = _unseal_artifact(record['encrypted_artifact'])
        if (set(payload) != {'package_id', 'selection_digest', 'actor_digest', 'instance_id', 'artifact', 'binary'}
                or any(payload[k] != record[k] for k in ('selection_digest', 'actor_digest', 'instance_id', 'artifact'))
                or payload['package_id'] != record['id'] or type(payload['binary']) is not str):
            _fail('原资料包密封绑定需核对')
        try:
            binary = base64.b64decode(payload['binary'], validate=True)
        except ValueError:
            _fail('原资料包内容需核对')
        if (not 1 <= len(binary) <= MAX_BYTES or len(binary) != record['artifact']['bytes']
                or _sha(binary) != record['artifact']['sha256']):
            _fail('原资料包大小或摘要需核对')
        emitted = False
        old_timeout = handler.connection.gettimeout()
        try:
            with self._transaction(token, user, emit=True) as (db, context, deadline):
                if self._record(db, record['idempotency_key'], user) != record:
                    _fail('原资料包在下载前已变化')
                proofs, _ = self._proofs(db, context, record['selection'], record['recipient_id'],
                    record['handoff_purpose'], deadline)
                if proofs != record['proofs']:
                    _fail('原客户同意或来源已变化，未输出新资料')
                self._session(db, token, user)
                self._deadline(deadline)
                event_id = digest([record['id'], 'download_attempt', time.time_ns()])
                event = {'id': event_id, 'tenant_id': record['tenant_id'], 'cloud_owner': record['cloud_owner'],
                    'package_id': record['id'], 'kind': 'local_attachment_output_attempt',
                    'artifact_sha256': record['artifact']['sha256'], 'occurred_at': time.time(),
                    'browser_saved_verified': False, 'resource_receipt_verified': False}
                db.execute('INSERT INTO records VALUES(?,?,?,?)',
                    ('owner_contact_handoff_package_events_v1', event_id, record['tenant_id'], _encode(event)))
                db.set_progress_handler(None, 0)
                output_deadline = time.monotonic() + 5.0
                def remaining():
                    duration = output_deadline - time.monotonic()
                    if duration <= 0:
                        raise TimeoutError('bounded package output')
                    handler.connection.settimeout(duration)
                try:
                    remaining()
                    emitted = True  # Headers may already be observable after this point.
                    handler.send_response(200)
                    handler.send_header('Content-Type', MIME)
                    handler.send_header('Content-Length', str(len(binary)))
                    from urllib.parse import quote
                    handler.send_header('Content-Disposition', "attachment; filename*=UTF-8''" + quote(record['artifact']['filename']))
                    handler.send_header('X-Owner-Package-Id', record['id'])
                    handler.send_header('X-Owner-Package-SHA256', record['artifact']['sha256'])
                    handler.security_headers()
                    remaining(); handler.end_headers()
                    # One bounded attachment, absolute deadline checked for each chunk.
                    for offset in range(0, len(binary), 65536):
                        remaining(); handler.wfile.write(binary[offset:offset + 65536])
                    remaining(); handler.wfile.flush()
                    remaining()
                    kind = 'local_attachment_output_returned'
                except Exception:
                    if not emitted:
                        raise
                    # Catch only the output phase inside this same transaction:
                    # an interrupted write must not roll back its attempted-output
                    # metadata. A later SQLite COMMIT failure is still unknown.
                    handler.close_connection = True
                    kind = 'local_attachment_output_interrupted'
                outcome = {**event, 'id': digest([event_id, kind]), 'kind': kind, 'occurred_at': time.time()}
                db.execute('INSERT INTO records VALUES(?,?,?,?)',
                    ('owner_contact_handoff_package_events_v1', outcome['id'], record['tenant_id'], _encode(outcome)))
        except Exception:
            if not emitted:
                raise
            handler.close_connection = True
            # Never append an apparent JSON success/failure to a partial attachment.
        finally:
            try:
                handler.connection.settimeout(old_timeout)
            except OSError:
                handler.close_connection = True
