"""Owner-only source candidate: original atomic Job plus confirmed handle retention.

In-progress source candidate. No current policy is approved or real Native
verified. Importing this file creates no kernel/window.
"""
from __future__ import annotations
import copy
import json
from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
from pathlib import Path
import subprocess
import secrets
import sys
import threading
import time

from .owned_native_job import (WindowsOwnedJobProcess, OwnedJobError,
    OwnedSetupPending, STARTUPINFOEX, PROCESS_INFORMATION, EXTENDED_LIMIT,
    ACCOUNTING, _kernel)

from .owned_xhs_native import owner as OWNER, classifier as FROZEN
from .owned_xhs_native import owner, classifier
from .owned_xhs_native.classifier import TrustedCurrentPython
from .owned_xhs_native.owner import (valid_sid, native_apis, PROCESS_ACCESS,
    TOKEN_QUERY, TOKEN_USER_CLASS, WAIT_TIMEOUT)
from .owned_xhs_native.image import NativeProcessImageBinding, _BindingError
from .owned_xhs_native.ready import _NativeReadyProbe, _FileLease, _paths, _FACT_KEYS
from .owned_xhs_native.occupancy import (NativeOwnerOccupancyAdapter,
    _EvidenceError, _frozen_valid, _hash, _ROW_BINDING)
from .owned_xhs_native.runtime_materials import (_checked_path, digest,
    RuntimeMaterialUnavailable, fixed_interpreter)
import re
from .owned_xhs_native.ready import _deny


class _HeldResources:
    """Fixed owned handle kinds only; failed release stays reachable for retry."""
    _KINDS = frozenset({'job', 'process', 'thread', 'query', 'token', 'sid'})

    def __init__(self):
        self._held = {}
        self._lock = threading.RLock()
        self._accepting = True
        self._inflight = 0

    @contextmanager
    def operation(self):
        with self._lock:
            if not self._accepting:
                raise OwnedJobError('owned_cleanup_in_progress')
            self._inflight += 1
        try:
            yield
        finally:
            with self._lock:
                self._inflight -= 1

    def stop_acquiring(self):
        with self._lock:
            self._accepting = False
            return self._inflight == 0

    @property
    def quiescent(self):
        with self._lock:
            return not self._accepting and self._inflight == 0

    def acquire(self, kind, kernel, handle):
        if kind not in self._KINDS or not handle:
            raise OwnedJobError('owned_handle_invalid')
        key = (kind, int(handle.value if hasattr(handle, 'value') else handle))
        with self._lock:
            if key in self._held:
                raise OwnedJobError('owned_handle_duplicate')
            self._held[key] = (kernel, handle)
        return handle

    def release(self, kind, handle):
        key = (kind, int(handle.value if hasattr(handle, 'value') else handle))
        with self._lock:
            item = self._held.get(key)
            if item is None:
                return True
            kernel, original = item
            try:
                ok = not kernel.LocalFree(original) if kind == 'sid' else bool(kernel.CloseHandle(original))
            except Exception:
                ok = False
            if ok:
                self._held.pop(key)
            return ok

    def close_temporaries(self):
        with self._lock:
            keys = tuple(key for key in self._held if key[0] not in ('job', 'process'))
        complete = True
        for kind, handle in keys:
            complete = self.release(kind, handle) and complete
        return complete

    @property
    def empty(self):
        with self._lock:
            return not self._held


class _OwnerImageBinding(NativeProcessImageBinding):
    def __init__(self, resources):
        super().__init__()
        self.resources = resources
    def _token_sid(self, kernel, advapi, process, owner, result):
        with self.resources.operation():
            token, sid_string = wintypes.HANDLE(), ctypes.c_void_p()
            token_acquired = sid_allocated = False
            sid = None
            try:
                if not advapi.OpenProcessToken(process, owner.TOKEN_QUERY, ctypes.byref(token)) or not token.value:
                    raise _BindingError('token_open_unavailable')
                token_acquired = True
                self.resources.acquire("token", kernel, token.value)
                required = wintypes.DWORD()
                ctypes.set_last_error(0)
                ok = advapi.GetTokenInformation(token, owner.TOKEN_USER_CLASS, None, 0, ctypes.byref(required))
                if ok or ctypes.get_last_error() != 122 or not ctypes.sizeof(owner.TOKEN_USER) <= required.value <= 65536:
                    raise _BindingError('token_buffer_unavailable')
                capacity = required.value
                buffer = ctypes.create_string_buffer(capacity)
                if (not advapi.GetTokenInformation(token, owner.TOKEN_USER_CLASS, buffer, capacity, ctypes.byref(required))
                        or not ctypes.sizeof(owner.TOKEN_USER) <= required.value <= capacity):
                    raise _BindingError('token_user_unavailable')
                pointer = ctypes.cast(buffer, ctypes.POINTER(owner.TOKEN_USER)).contents.User.Sid
                start = ctypes.addressof(buffer)
                if not pointer or not start <= pointer <= start + required.value - 8:
                    raise _BindingError('sid_unavailable')
                if not advapi.ConvertSidToStringSidW(pointer, ctypes.byref(sid_string)) or not sid_string.value:
                    raise _BindingError('sid_unavailable')
                sid_allocated = True
                self.resources.acquire("sid", kernel, sid_string)
                sid = ctypes.wstring_at(sid_string)
                if not owner.valid_sid(sid):
                    raise _BindingError('sid_unavailable')
                return sid
            finally:
                closed = True
                if token_acquired:
                    closed = self.resources.release('token', token.value) and closed
                if sid_allocated:
                    closed = self.resources.release('sid', sid_string) and closed
                if not closed:
                    result['handles_closed'] = False
                    raise _BindingError('close_unconfirmed')
                sid = None

    def current_sid(self):
        kernel, advapi = OWNER.native_apis()
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        result = {'handles_closed':True}
        value = self._token_sid(kernel, advapi, kernel.GetCurrentProcess(), OWNER, result)
        if result['handles_closed'] is not True or not OWNER.valid_sid(value):
            raise RuntimeMaterialUnavailable()
        return value


class _OwnerResolver(OWNER.NativeOwnerResolver):
    def __init__(self, resources):
        super().__init__()
        self.resources = resources
    def resolve(self, pid, created, *, current_sid, wmi_sid=None):
        with self.resources.operation():
            result = dict(contract='process_token_user_evidence_v1', state='unknown', reason='metadata_unavailable',
                owner_current=None, wmi_owner_agrees=None, creation_verified=False,
                running_before=None, running_after=None, token_user_verified=False,
                handles_closed=True, evidence_hash=None)
            # Parent and source validity remain the caller's responsibility. Missing
            # creation cannot be replaced with the time of a newly opened PID.
            if (type(pid) is not int or not 1 <= pid <= 0xffffffff or type(created) is not int or created <= 0
                    or not valid_sid(current_sid) or (wmi_sid is not None and not valid_sid(wmi_sid))):
                return result
            process, token, sid_string = None, wintypes.HANDLE(), ctypes.c_void_p()
            token_acquired = sid_allocated = False
            kernel = advapi = None
            sid = None
            try:
                result['reason'] = 'native_read_unavailable'
                kernel, advapi = self.apis if self.apis is not None else native_apis()
                result['reason'] = 'process_open_unavailable'
                process = kernel.OpenProcess(PROCESS_ACCESS, False, pid)
                if not process:
                    return result
                self.resources.acquire('query', kernel, process)
                result['reason'] = 'creation_unavailable'
                first = self._creation(kernel, process)
                if first is None:
                    return result
                if not 0 <= first - created <= 9:
                    result['reason'] = 'creation_conflict'
                    return result
                result['creation_verified'] = True
                result['reason'] = 'state_unavailable'
                status = kernel.WaitForSingleObject(process, 0)
                if status not in (0, WAIT_TIMEOUT):
                    return result
                result['running_before'] = status == WAIT_TIMEOUT
                if not result['running_before']:
                    result['reason'] = 'process_not_running'
                    return result
                result['reason'] = 'token_open_unavailable'
                if not advapi.OpenProcessToken(process, TOKEN_QUERY, ctypes.byref(token)):
                    return result
                token_acquired = True
                self.resources.acquire("token", kernel, token.value)
                result['reason'] = 'token_buffer_unavailable'
                required = wintypes.DWORD()
                ctypes.set_last_error(0)
                success = advapi.GetTokenInformation(token, TOKEN_USER_CLASS, None, 0, ctypes.byref(required))
                if success or ctypes.get_last_error() != 122 or not ctypes.sizeof(owner.TOKEN_USER) <= required.value <= 65536:
                    return result
                capacity = required.value
                buffer = ctypes.create_string_buffer(capacity)
                result['reason'] = 'token_user_unavailable'
                if (not advapi.GetTokenInformation(token, TOKEN_USER_CLASS, buffer, capacity, ctypes.byref(required))
                        or not ctypes.sizeof(owner.TOKEN_USER) <= required.value <= capacity):
                    return result
                pointer = ctypes.cast(buffer, ctypes.POINTER(owner.TOKEN_USER)).contents.User.Sid
                # TokenUser's SID must lie inside the returned bounded token buffer.
                start = ctypes.addressof(buffer)
                if not pointer or not start <= pointer <= start + required.value - 8:
                    return result
                result['reason'] = 'sid_unavailable'
                if not advapi.ConvertSidToStringSidW(pointer, ctypes.byref(sid_string)) or not sid_string.value:
                    return result
                sid_allocated = True
                self.resources.acquire("sid", kernel, sid_string)
                sid = ctypes.wstring_at(sid_string)
                if not valid_sid(sid):
                    return result
                result['reason'] = 'creation_unavailable'
                last = self._creation(kernel, process)
                if last != first:
                    result['reason'] = 'creation_conflict'
                    return result
                result['reason'] = 'state_unavailable'
                status = kernel.WaitForSingleObject(process, 0)
                if status not in (0, WAIT_TIMEOUT):
                    return result
                result['running_after'] = status == WAIT_TIMEOUT
                if not result['running_after']:
                    result['reason'] = 'process_not_running'
                    return result
                result['owner_current'] = sid == current_sid
                result['wmi_owner_agrees'] = None if wmi_sid is None else sid == wmi_sid
                if result['wmi_owner_agrees'] is False:
                    result['reason'] = 'owner_conflict'
                    return result
                result.update(state='verified', reason='verified', token_user_verified=True,
                    evidence_hash=hashlib.sha256(json.dumps(['process_token_user_v1', pid, first, sid],
                        separators=(',', ':')).encode()).hexdigest())
                return result
            except Exception:
                # Keep only our pre-call phase code, never the native exception text.
                reason = result['reason'] if result['reason'] != 'verified' else 'native_read_unavailable'
                result.update(state='unknown', reason=reason, token_user_verified=False, evidence_hash=None)
                return result
            finally:
                closed = True
                if kernel is not None:
                    for handle in (token.value if token_acquired else None, process):
                        if handle:
                            try:
                                closed = self.resources.release("token" if handle == token.value and token_acquired else "query", handle) and closed
                            except Exception:
                                closed = False
                    if sid_allocated:
                        try:
                            closed = self.resources.release("sid", sid_string) and closed
                        except Exception:
                            closed = False
                result['handles_closed'] = bool(closed)
                if not closed:
                    result.update(state='unknown', reason='close_unconfirmed', token_user_verified=False, evidence_hash=None)
                sid = None


class _OwnerReadyProbe(_NativeReadyProbe):
    def __init__(self, resources):
        super().__init__()
        self.image = _OwnerImageBinding(resources)
    def capture(self, process, pid, created, expected_image, sid, *, cim_precision=False):
        with self.image.resources.operation():
            if (type(process) is not _OwnerObservationJob or process.closed or process.job is None
                    or type(created) is not int or created <= 0):
                _deny()
            retained = (process.process, process.job, process.pid)
            kernel, advapi = self.image._native(owner)
            retained_handle = self.handles.get(pid)
            if retained_handle is None:
                handle = kernel.OpenProcess(0x410, False, pid)
                if not handle:
                    _deny()
                self.handles[pid] = (kernel, handle)
            else:
                kernel, handle = retained_handle
            try:
                observations = []
                for _ in range(2):
                    self.image._running(kernel, handle, owner)
                    self.image._job(kernel, handle, process.job)
                    identity = self.image._identity(kernel, advapi, handle, owner, classifier, {})
                    # Only the browser's CIM row has the original WMI microsecond
                    # rounding. The actual two Native identities remain exact.
                    same_creation = (0 <= identity['created'] - created <= 9
                                     if cim_precision else identity['created'] == created)
                    if (identity['pid'] != pid or not same_creation
                            or identity['sid'] != sid
                            or identity['image'] != classifier.canonical_path(expected_image)
                            or process.contains(pid, created) is not True):
                        _deny()
                    observations.append((identity, self._modules(kernel, handle)))
                if (observations[0] != observations[1]
                        or (process.process, process.job, process.pid) != retained
                        or self.image.current_sid() != sid):
                    _deny()
                return observations[0]
            except Exception:
                # Keep a failed-to-close owned query handle for physical retry.
                if kernel.CloseHandle(handle):
                    self.handles.pop(pid, None)
                raise


class _OwnerOccupancyAdapter(NativeOwnerOccupancyAdapter):
    def __init__(self, resources):
        super().__init__(_OwnerResolver(resources))
    def classify(self, profile, *, snapshot_provider, current_sid_provider,
                 owned=None, expected_browser=None, trusted_python=None, owned_context=None):
        """Classify two fresh complete snapshots; never cache owner evidence.

        If a first fallback row disappears or changes identity/parent/argv,
        return unknown. Last snapshot still classifies every other row using
        the frozen profile / exe / Job fences. Unrelated row count may change.
        """
        counts = dict(source='incomplete', token_user_rows_verified=0,
                      complete_snapshots_checked=0, token_user_evidence_stable=None,
                      raw_metadata_saved=False)
        result = dict(contract='native_owner_occupancy_evidence_v1', state='unknown',
                      reason='owner_evidence_unavailable', fingerprint=None, owner_evidence=counts)
        first = last = first_rows = last_rows = derived = evidence = current_sid = None
        added_evidence = {}
        try:
            if not callable(snapshot_provider) or not callable(current_sid_provider):
                raise _EvidenceError('owner_evidence_unavailable')
            if not _frozen_valid():
                raise _EvidenceError('owner_frozen_source_changed')
            current_sid = current_sid_provider()
            if not OWNER.valid_sid(current_sid):
                raise _EvidenceError('owner_principal_changed')
            value = snapshot_provider()
            if current_sid_provider() != current_sid:
                raise _EvidenceError('owner_principal_changed')
            first, first_rows = self._snapshot(value, current_sid)
            value = None
            counts['complete_snapshots_checked'] = 1
            evidence = {}
            derived = copy.deepcopy(first)
            for row in derived['processes']:
                if row['owner_sid'] is None:
                    evidence[row['pid']] = self._resolve(first_rows[row['pid']], current_sid)
                    row['owner_sid'] = current_sid  # native evidence, never represented as WMI
            initial = FROZEN.classify(derived, profile, owned=owned,
                expected_browser=expected_browser, trusted_python=trusted_python)
            if initial['state'] not in ('vacant', 'occupied', 'unknown'):
                raise _EvidenceError('owner_evidence_unavailable')
            # A first blocked classification cannot be relaxed by a later page.
            if initial['state'] != 'vacant':
                result.update(state=initial['state'], reason=initial['reason'])
                return result
            value = snapshot_provider()
            if current_sid_provider() != current_sid:
                raise _EvidenceError('owner_principal_changed')
            last, last_rows = self._snapshot(value, current_sid)
            value = None
            counts['complete_snapshots_checked'] = 2
            # First repaired identity must still be observable; missing does not
            # mean the former process exited safely or the target became vacant.
            for pid, previous_hash in evidence.items():
                before, after = first_rows[pid], last_rows.get(pid)
                if (after is None or any(after[key] != before[key] for key in _ROW_BINDING)
                        or after['owner_sid'] not in (None, current_sid)):
                    raise _EvidenceError('owner_row_changed')
                if self._resolve(after, current_sid) != previous_hash:
                    raise _EvidenceError('owner_evidence_changed')
            added_rows = [row for row in last_rows.values()
                          if row['owner_sid'] is None and row['pid'] not in evidence]
            if added_rows:
                if type(owned_context) is not _OwnerObservationReadyGuard:
                    raise _EvidenceError('owner_row_changed')
                for row in added_rows:
                    # Port only the reviewed owned-added mechanical algorithm.
                    # No diagnostic host, TLS, QA capability or cached SID map.
                    if row['pid'] in first_rows or not owned_context.validate():
                        raise _EvidenceError('owner_row_changed')
                    proof = self._resolve(row, current_sid)
                    owned_context.contains(row['pid'], row['created'])
                    if self._resolve(row, current_sid) != proof:
                        raise _EvidenceError('owner_evidence_changed')
                    owned_context.contains(row['pid'], row['created'])
                    added_evidence[row['pid']] = proof
            derived = copy.deepcopy(last)
            for row in derived['processes']:
                if row['owner_sid'] is None:
                    row['owner_sid'] = current_sid
            final = FROZEN.classify(derived, profile, owned=owned,
                expected_browser=expected_browser, trusted_python=trusted_python)
            if current_sid_provider() != current_sid:
                raise _EvidenceError('owner_principal_changed')
            if not _frozen_valid():
                raise _EvidenceError('owner_frozen_source_changed')
            if final['state'] not in ('vacant', 'occupied', 'unknown'):
                raise _EvidenceError('owner_evidence_unavailable')
            if owned_context is not None and not owned_context.validate():
                raise _EvidenceError('owner_evidence_unavailable')
            counts.update(source='wmi_and_token_user' if evidence else 'wmi_only',
                          token_user_rows_verified=len(evidence),
                          token_user_evidence_stable=True if evidence else None)
            result.update(state=final['state'], reason=final['reason'],
                fingerprint=_hash(['native_owner_occupancy_v1', final['fingerprint'],
                    [[pid, first_rows[pid]['created'], first_rows[pid]['parent_pid'], evidence[pid]]
                     for pid in sorted(evidence)]]))
            if added_evidence:
                result['fingerprint'] = _hash([result['fingerprint'],
                    'exact_owned_added_native_v1', [[pid, last_rows[pid]['created'],
                    last_rows[pid]['parent_pid'], added_evidence[pid]]
                    for pid in sorted(added_evidence)]])
            return result
        except _EvidenceError as error:
            result.update(state='unknown', reason=str(error), fingerprint=None)
            return result
        except Exception:
            result.update(state='unknown', reason='owner_evidence_unavailable', fingerprint=None)
            return result
        finally:
            # No cross-call cache, shared owner map, raw metadata receipt or IO.
            first = last = first_rows = last_rows = derived = evidence = current_sid = None
            added_evidence = None


class _OwnerObservationPreResumeGuard:
    """Exact owner material/image barrier; no employee scope or injected factory."""
    def __init__(self, holder, spec_path, command):
        from .owned_helper_process import OwnedHelperCommand
        if type(holder) is not _OwnerNativeAttempt or type(command) is not OwnedHelperCommand:
            raise OwnedJobError('owned_binding_unconfirmed')
        holder.frame.check()
        self.holder, self.frame = holder, holder.frame
        self.spec_path, self.command = _checked_path(spec_path), command
        self.source = _checked_path(Path(__file__).with_name('owner_contact_observation_helper.py'))
        self.spec_hash, self.source_hash = digest(self.spec_path), digest(self.source)
        self.binding = TrustedCurrentPython()
        self.image = _OwnerImageBinding(holder._resources)
        self.thread = threading.current_thread()
        self.sid = self.image.current_sid()
        self.nonce = holder._nonce
        self._environment = self._environment_now()
        self.called = self._resume_submitted = False
        self.image_evidence = None
        self._verified_process = self._verified_handles = None

    @staticmethod
    def _environment_now():
        value = dict(os.environ)
        for key in ('PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONINSPECT', 'PYTHONPATH',
                'WEBVIEW2_USER_DATA_FOLDER', 'WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS',
                'WEBVIEW2_WAIT_FOR_SCRIPT_DEBUGGER', 'WEBVIEW2_PIPE_FOR_SCRIPT_DEBUGGER',
                'WEBVIEW2_BROWSER_EXECUTABLE_FOLDER'):
            value.pop(key, None)
        value['PYTHONDONTWRITEBYTECODE'] = '1'
        return value

    @property
    def environment(self):
        return dict(self._environment)

    def _check(self, command, environment):
        from .owned_helper_process import OwnedHelperCommand
        if (threading.current_thread() is not self.thread or self.holder._cancelled.is_set()
                or self.frame.holder is not self.holder
                or type(command) is not OwnedHelperCommand or command != self.command
                or digest(self.spec_path) != self.spec_hash or digest(self.source) != self.source_hash
                or type(environment) is not dict or environment != self._environment
                or self._environment_now() != self._environment
                or self.image.current_sid() != self.sid or not self.binding.validate()):
            raise OwnedJobError('owned_binding_unconfirmed')
        material = {Path(path):sha.upper() for path, sha, role in self.frame.decision.expected_materials}
        if material.get(self.source) != self.source_hash.upper() or any(
                digest(path).upper() != sha for path, sha in material.items()):
            raise OwnedJobError('owned_material_changed')
        self.frame.check()

    def verify(self, process, command, environment):
        if (self.called or type(process) is not _OwnerObservationJob or process.closed
                or process.resumed or process.process is None or process.job is None):
            raise OwnedJobError('owned_binding_unconfirmed')
        self.called = True
        retained = (process.process, process.job, process.pid)
        self._check(command, environment)
        proof = self.image._capture_owned(process.process, process.pid,
            job_handle=process.job, creation_spec={'application_name':command.argv[0],
                'argv':list(command.argv), 'cwd':command.cwd, 'run_nonce':self.nonce},
            current_sid_provider=self.image.current_sid, runtime_binding=self.binding)
        if ((process.process, process.job, process.pid) != retained
                or proof.get('state') != 'verified' or proof.get('reason') != 'verified'
                or any(proof.get(key) is not True for key in (
                    'owner_current', 'creation_verified', 'running_before', 'running_after',
                    'pid_stable', 'native_image_stable', 'fixed_runtime_matches',
                    'job_membership_verified', 'token_user_verified', 'handles_closed'))
                or proof.get('native_loaded_bytes_verified') is not False
                or proof.get('profile_vacancy_verified') is not False):
            raise OwnedJobError('owned_binding_unconfirmed')
        self._check(command, environment)
        self.image_evidence, self._verified_process, self._verified_handles = proof, process, retained

    def resume(self, process, thread_handle, command, environment):
        self._check(command, environment)
        with self.frame.native_barrier(self.holder), self.holder._control_lock:
            if (not self.called or self.image_evidence is None or self._resume_submitted
                    or type(process) is not _OwnerObservationJob or self._verified_process is not process
                    or (process.process, process.job, process.pid) != self._verified_handles
                    or process.closed or process.resumed or self.holder._cancelled.is_set()
                    or threading.current_thread() is not self.thread
                    or command != self.command or environment != self._environment):
                raise OwnedJobError('owned_binding_unconfirmed')
            self._resume_submitted = True
            return process.kernel.ResumeThread(thread_handle)


class _OwnerObservationJob(WindowsOwnedJobProcess):
    def __init__(self, command, *, environment=None, _before_resume=None):
        if type(_before_resume) is not _OwnerObservationPreResumeGuard:
            raise OwnedJobError('owned_binding_unconfirmed')
        self.resources = _before_resume.holder._resources
        self._physical_exit_verified = False
        kernel = self.kernel = _kernel()
        self.job = self.process = None
        self.pid = None
        self.returncode = None
        self.closed = False
        self.resumed = False
        job = kernel.CreateJobObjectW(None, None)
        if not job:
            raise OwnedJobError('job_unavailable')
        self.job = job
        self.resources.acquire("job", kernel, job)
        limits = EXTENDED_LIMIT()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not kernel.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            if self.resources.release("job", job):
                self.job = None
            else:
                raise OwnedSetupPending(self)
            raise OwnedJobError('job_unavailable')
        startup, info = STARTUPINFOEX(), PROCESS_INFORMATION()
        startup.StartupInfo.cb = ctypes.sizeof(startup)
        startup.StartupInfo.dwFlags, startup.StartupInfo.wShowWindow = 1, 0
        environment = dict(os.environ) if environment is None else dict(environment)
        block = ctypes.create_unicode_buffer('\0'.join(key+'='+value for key, value in
            sorted(environment.items(), key=lambda pair: pair[0].upper()))+'\0\0')
        argv = ctypes.create_unicode_buffer(subprocess.list2cmdline(command.argv))
        # Windows 10+: create directly in this Job, retaining suspension until
        # membership is confirmed. No Create->Assign gap or unsafe fallback.
        initialized = False
        try:
            size = ctypes.c_size_t()
            kernel.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
            if not 1 <= size.value <= 1024*1024:
                raise OwnedJobError('atomic_job_creation_unavailable')
            attributes = ctypes.create_string_buffer(size.value)
            startup.lpAttributeList = ctypes.cast(attributes, ctypes.c_void_p)
            if not kernel.InitializeProcThreadAttributeList(startup.lpAttributeList, 1, 0, ctypes.byref(size)):
                raise OwnedJobError('atomic_job_creation_unavailable')
            initialized = True
            jobs = (wintypes.HANDLE*1)(job)
            if not kernel.UpdateProcThreadAttribute(startup.lpAttributeList, 0, 0x2000D,
                    ctypes.cast(jobs, ctypes.c_void_p), ctypes.sizeof(jobs), None, None):
                raise OwnedJobError('atomic_job_creation_unavailable')
            created = kernel.CreateProcessW(command.argv[0], argv, None, None, False,
                0x4 | 0x400 | 0x08000000 | 0x80000, block, command.cwd,
                ctypes.byref(startup.StartupInfo), ctypes.byref(info))
        except Exception:
            if self.resources.release("job", job):
                self.job = None
            else:
                raise OwnedSetupPending(self) from None
            raise
        finally:
            if initialized:
                kernel.DeleteProcThreadAttributeList(startup.lpAttributeList)
        if not created:
            if self.resources.release("job", job):
                self.job = None
            else:
                raise OwnedSetupPending(self)
            raise OwnedJobError('owned_spawn_unavailable')
        self.process, self.pid = info.hProcess, info.dwProcessId
        self.resources.acquire("process", kernel, info.hProcess)
        self.resources.acquire("thread", kernel, info.hThread)
        try:
            membership = wintypes.BOOL()
            if (not kernel.IsProcessInJob(info.hProcess, job, ctypes.byref(membership))
                    or not membership.value):
                raise OwnedJobError('atomic_job_membership_unavailable')
            if _before_resume is not None:
                _before_resume.verify(self, command, environment)
                resumed = _before_resume.resume(self, info.hThread, command, environment)
            else:
                resumed = kernel.ResumeThread(info.hThread)
            if resumed == 0xffffffff:
                raise OwnedJobError('owned_resume_unavailable')
            self.resumed = True
        except Exception:
            try:
                self.close()
            except Exception:
                # The parent host receives the object and continues owning its
                # handles and account lock. It cannot pretend process=None.
                raise OwnedSetupPending(self) from None
            raise
        finally:
            if not self.resources.release("thread", info.hThread):
                raise OwnedSetupPending(self) from None


    def contains(self, pid, created):
        with self.resources.operation():
            if self.closed or self.job is None:
                return None
            handle = self.kernel.OpenProcess(0x1000, False, pid)
            if not handle:
                return None
            self.resources.acquire('query', self.kernel, handle)
            try:
                timestamps = [wintypes.FILETIME() for _ in range(4)]
                if not self.kernel.GetProcessTimes(handle, *(ctypes.byref(value) for value in timestamps)):
                    return None
                observed = ((int(timestamps[0].dwHighDateTime) << 32) | int(timestamps[0].dwLowDateTime)) + 504911232000000000
                if type(created) is not int or not 0 <= observed-created <= 9:
                    return None
                found = wintypes.BOOL()
                if not self.kernel.IsProcessInJob(handle, self.job, ctypes.byref(found)):
                    return None
                return bool(found.value)
            finally:
                if not self.resources.release('query', handle):
                    raise OwnedJobError('owned_query_cleanup_pending')

    def close(self):
        if self.closed:
            return True
        if not self.resources.stop_acquiring():
            raise OwnedJobError('owned_query_cleanup_pending')
        if not self._physical_exit_verified:
            if self.job is not None:
                self.terminate()
                deadline = time.monotonic() + 10
                while True:
                    accounting = ACCOUNTING()
                    if not self.kernel.QueryInformationJobObject(self.job, 1, ctypes.byref(accounting), ctypes.sizeof(accounting), None):
                        raise OwnedJobError('owned_exit_unavailable')
                    if accounting.ActiveProcesses == 0:
                        break
                    if time.monotonic() >= deadline:
                        raise OwnedJobError('owned_exit_unconfirmed')
                    time.sleep(.05)
            if self.process is not None:
                self.wait(timeout=3)
            self._physical_exit_verified = True
        complete = self.resources.close_temporaries()
        for kind in ('process', 'job'):
            value = getattr(self, kind)
            if value is not None:
                if self.resources.release(kind, value):
                    setattr(self, kind, None)
                else:
                    complete = False
        if not complete or not self.resources.empty:
            raise OwnedJobError('owned_handles_cleanup_pending')
        self.closed = True
        return True


class _OwnedObservationPort:
    """Mature loopback POST mechanism narrowed to four fixed messages."""
    def __init__(self, holder):
        self.holder = holder
        self.secret = secrets.token_hex(32)
        self.session = None
        self.sequence = -1
        self.ready = None
        self.grant = None
        self.delivered = False
        self.events = []
        self.lock = threading.RLock()
        self.server = self.thread = None
        self.closed = False

    def start(self):
        port = self
        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                self.request.settimeout(2)
                super().setup()
            def log_message(self, *_args):
                pass
            def do_POST(self):
                self.connection.settimeout(2)
                try:
                    lengths = self.headers.get_all('Content-Length') or []
                    if (self.client_address[0] != '127.0.0.1'
                            or self.path not in ('/ready', '/poll', '/observe', '/close')
                            or len(lengths) != 1 or self.headers.get('Transfer-Encoding')
                            or self.headers.get('Content-Type') != 'application/json'):
                        raise ValueError()
                    size = int(lengths[0])
                    if not 0 < size <= 1024*1024:
                        raise ValueError()
                    raw = self.rfile.read(size)
                    if len(raw) != size:
                        raise ValueError()
                    from .tracked_reply_window import _json
                    body = _json(raw.decode('utf-8'), 1024*1024)
                    if body is None:
                        raise ValueError()
                    result = port.message(self.path, body)
                    self._send(200, {'ok':True, **result})
                except Exception:
                    self._send(403, {'ok':False, 'code':'owner_observation_ipc_denied'})
            def _send(self, status, value):
                body = json.dumps(value, separators=(',', ':'), allow_nan=False).encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(body)
                self.close_connection = True
        self.server = HTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever,
            kwargs={'poll_interval':.1}, name='owner-contact-ipc', daemon=False)
        self.holder._threads.append(self.thread)
        self.thread.start()
        return 'http://127.0.0.1:'+str(self.server.server_address[1])

    def message(self, path, body):
        with self.lock:
            if self.closed or body.get('nonce') != self.holder._nonce:
                raise OwnedJobError('owned_ipc_unconfirmed')
            if path == '/ready':
                if (self.ready is not None or type(body) is not dict or set(body) != {
                        'secret', 'nonce', 'sequence', 'hwnd', 'window_nonce', 'runtime_facts'}
                        or body['sequence'] != 0 or type(body['sequence']) is not int
                        or not hmac.compare_digest(str(body['secret']), self.secret)
                        or body['window_nonce'] != self.holder._window_nonce
                        or type(body['hwnd']) is not int or not body['hwnd'] > 0
                        or type(body['runtime_facts']) is not dict):
                    raise OwnedJobError('owned_ipc_unconfirmed')
                self.ready = copy.deepcopy(body)
                self.session = secrets.token_hex(32)
                self.secret = ''
                self.sequence = 0
                return {'session_token':self.session}
            if (self.session is None or type(body.get('session_token')) is not str
                    or not hmac.compare_digest(body['session_token'], self.session)
                    or type(body.get('sequence')) is not int or body['sequence'] != self.sequence+1):
                raise OwnedJobError('owned_ipc_unconfirmed')
            if path in ('/poll', '/close'):
                if set(body) != {'session_token', 'nonce', 'sequence'}:
                    raise OwnedJobError('owned_ipc_unconfirmed')
                self.sequence = body['sequence']
                if path == '/close' or self.holder._cancelled.is_set():
                    return {'command':'close'}
                if self.grant is not None and not self.delivered:
                    self.delivered = True
                    return {'command':'activate', **self.grant}
                return {'command':'wait'}
            if (path != '/observe' or set(body) != {'session_token', 'nonce', 'sequence',
                    'phase', 'observation'} or not self.delivered or len(self.events) >= 16
                    or body['phase'] not in ('canonical_navigation_submitted', 'observing')
                    or body['observation'] is not None and type(body['observation']) is not dict):
                raise OwnedJobError('owned_ipc_unconfirmed')
            self.sequence = body['sequence']
            self.events.append(copy.deepcopy(body))
            return {}

    def take_events(self):
        with self.lock:
            rows, self.events = self.events, []
            return rows

    def issue(self, canonical_url, draft):
        with self.lock:
            if self.ready is None or self.grant is not None or self.closed:
                raise OwnedJobError('owned_ipc_unconfirmed')
            self.grant = {'canonical_url':canonical_url, 'draft_text':draft}

    def close(self):
        if self.closed:
            return True
        if self.server is not None:
            if self.thread is not None and self.thread.is_alive():
                self.server.shutdown()
            if self.thread is not None and self.thread is not threading.current_thread() and self.thread.ident is not None:
                self.thread.join(4)
            if self.thread is not None and self.thread.is_alive():
                return False
            self.server.server_close()
            if self.server.socket.fileno() != -1:
                return False
            self.server = None
        with self.lock:
            self.ready = self.grant = None
            self.events.clear()
            self.secret = self.session = ''
            self.closed = True
        return True


_EVIDENCE_SEAL = object()


class _OwnedObservationEvidence:
    """Private exact result type: original owned observer and parent proof only."""
    __slots__ = ('holder', 'outcome', 'observed_at', 'snapshot_hash',
        'platform_comment_digest', 'sender_uid_digest', '_seal', '_binding')
    def __init__(self, *args, **kwargs):
        raise OwnedJobError('owned_evidence_unavailable')

    def valid_for(self, frame, holder):
        return (getattr(self, '_seal', None) is _EVIDENCE_SEAL
            and type(holder) is _OwnerNativeAttempt and self.holder is holder
            and holder.frame is frame and holder._evidence is self
            and not holder._cancelled.is_set() and not holder._closed
            and self._binding == holder._frame_binding()
            and holder._phase == 'observing')


class _OwnerNativeAttempt:
    """RAM-only construction; explicit run owns all source-only Native resources."""
    def __init__(self, frame, draft_text):
        from .owner_web_contact_observation import _OwnerObservationFrame, _OwnerObservationSpec
        from .owner_contact_observation_policy import _OwnerObservationDecision
        if (type(frame) is not _OwnerObservationFrame or type(frame.spec) is not _OwnerObservationSpec
                or type(frame.decision) is not _OwnerObservationDecision):
            raise OwnedJobError('owned_binding_unconfirmed')
        self.frame = frame
        self._draft = draft_text
        self._cancelled = threading.Event()
        self._job = None
        self._resources = _HeldResources()
        self._closed = False
        self._control_lock = threading.RLock()
        self._running = False
        self._run_started = False
        self._worker = None
        self._close_inflight = False
        self._nonce = secrets.token_hex(16)
        self._leases = []
        self._probe = None
        self._ready = None
        self._threads = []
        self._socket = None
        self._profile_lock = None
        self._port = None
        self._window_nonce = secrets.token_hex(16)
        self._spec_lease = None
        self._hwnd = None
        self._phase = None
        self._evidence = None
        self._resources_closed = False
        self._cleanup_request = threading.Event()

    def run(self):
        with self._control_lock:
            if self._run_started or self._closed or self._close_inflight or self._cancelled.is_set():
                raise OwnedJobError('owned_native_state_invalid')
            self._running = self._run_started = True
            self._worker = threading.current_thread()
        try:
            self.frame.check()
            self._run_owned()
        finally:
            with self._control_lock:
                self._running = False
            # RLock/thread-local account ownership stays on this exact worker.
            # Only explicit cleanup requests re-enter a failed physical cleanup;
            # no platform or window creation is retried. SQL custody stays held
            # until the Module joins this worker and finalizes closed separately.
            while True:
                self._cleanup_request.clear()
                if self._close_resources_on_owner():
                    break
                self._cleanup_request.wait()

    def _correlation_owner_alias(self):
        # Pure correlator scope only. This is not a user, authorization or
        # business identity; the exact Frame keeps the original owner value.
        spec = self.frame.spec
        material = json.dumps(['fangyu.owner-contact-observation.actor.v1',
            spec.tenant_id, spec.actor_id, spec.owner], ensure_ascii=False,
            separators=(',', ':'), allow_nan=False).encode('utf-8')
        return 'owner-observation-v1:' + hashlib.sha256(material).hexdigest()

    def _reply_spec(self):
        from .tracked_reply_window import ReplyWindowSpec
        spec = self.frame.spec
        return ReplyWindowSpec(spec.tenant_id, self._correlation_owner_alias(), spec.instance_id,
            spec.account_id, spec.account_uid, spec.note_id, spec.target_comment_id,
            self._draft)

    def _frame_binding(self):
        spec = self.frame.spec
        return tuple(str(getattr(spec, field)) for field in spec.__dataclass_fields__)

    def _attest_native(self):
        if (self._ready is None or self._job is None or self._job.closed
                or self._job.poll() is not None or self._cancelled.is_set()
                or self._ready.process is not self._job or self._ready.facts is None
                or self._hwnd is None or self._port is None or self._port.closed):
            raise OwnedJobError('owned_native_unconfirmed')
        self._ready.validate()
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        user32.IsWindow.argtypes = [wintypes.HWND]
        user32.IsWindow.restype = wintypes.BOOL
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        pid = wintypes.DWORD()
        if (not user32.IsWindow(self._hwnd)
                or not user32.GetWindowThreadProcessId(self._hwnd, ctypes.byref(pid))
                or pid.value != self._job.pid
                or self._job.contains(self._ready.facts['helper_pid'], self._ready.facts['helper_created']) is not True):
            raise OwnedJobError('owned_native_unconfirmed')
        self.frame.check()
        return True

    def _run_owned(self):
        from core.adapters import account_execution_lock
        from .owned_helper_process import OwnedHelperCommand
        from .tracked_reply_window import ReplyWindowSpec
        spec = self.frame.spec
        self._reply_spec()  # Pure exact validation before creation submission.
        account = _checked_path(spec.account_dir)
        profile = _checked_path(spec.profile_dir)
        attempt = _checked_path(spec.attempt_dir)
        if (profile != account/'xhs-browser-profile' or not profile.is_dir()
                or attempt != account/'work'/'owner-contact-observation'/spec.idempotency_key
                or attempt.exists() or getattr(sys, 'frozen', False)):
            raise OwnedJobError('owned_profile_unconfirmed')
        shim, alias, base, configuration = fixed_interpreter()
        # This short original-key transaction precedes locks, files, IPC and OS.
        self.frame.creation_submitted()
        self._profile_lock = account_execution_lock(account)
        self._profile_lock.__enter__()
        attempt.mkdir(parents=True, exist_ok=False)
        _checked_path(attempt)
        self._port = _OwnedObservationPort(self)
        endpoint = self._port.start()
        scope = self._reply_spec().__dict__.copy()
        scope['expected_content'] = ''
        spec_path = attempt/'spec.json'
        value = {'contract':'owner_contact_observation_helper_v1', 'endpoint':endpoint,
            'bootstrap_secret':self._port.secret, 'nonce':self._nonce,
            'window_nonce':self._window_nonce, 'idempotency_key':spec.idempotency_key,
            'scope':scope, 'canonical_url':spec.canonical_url, 'profile_dir':str(profile)}
        with spec_path.open('x', encoding='utf-8', newline='\n') as stream:
            json.dump(value, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        self._spec_lease = None
        def retain_spec(lease):
            self._spec_lease = lease
        _FileLease(spec_path, digest(spec_path), 'private_spec', retain=retain_spec)
        source = _checked_path(Path(__file__).resolve().parents[1])
        command = OwnedHelperCommand((str(shim), '-B', '-m',
            'assistant.owner_contact_observation_helper', '--spec', str(spec_path)), str(source))
        pre = _OwnerObservationPreResumeGuard(self, spec_path, command)
        self._ready = _OwnerObservationReadyGuard(self, pre)
        try:
            self._job = _OwnerObservationJob(command, environment=pre.environment, _before_resume=pre)
        except OwnedSetupPending as error:
            self._job = error.process
            raise
        self._ready.bind(self._job)
        deadline = time.monotonic()+45
        while self._port.ready is None:
            if self._cancelled.wait(.05) or self._job.poll() is not None or time.monotonic() >= deadline:
                raise OwnedJobError('owned_blank_unconfirmed')
            self.frame.check()
        with self._port.lock:
            ready = copy.deepcopy(self._port.ready)
        self._ready.verify(ready['runtime_facts'])
        self._hwnd = ready['hwnd']
        self._phase = 'window_created'
        self._attest_native()
        self.frame.native_phase(self, self._phase)
        with self._ready.issue():
            self._port.issue(spec.canonical_url, self._draft)
        while not self._cancelled.wait(.05):
            self.frame.check()
            for event in self._port.take_events():
                phase = event['phase']
                if (phase == 'canonical_navigation_submitted' and self._phase != 'window_created'
                        or phase == 'observing' and self._phase not in ('canonical_navigation_submitted', 'observing')):
                    raise OwnedJobError('owned_phase_unconfirmed')
                self._phase = phase
                self._attest_native()
                self.frame.native_phase(self, phase)
                if event['observation'] is not None:
                    self._mint(event['observation'])
                    self.frame.publish(self, self._evidence)
                    return
            if self._job.poll() is not None:
                raise OwnedJobError('owned_window_closed_unknown')

    def _mint(self, record):
        # A standalone helper outcome.json / sent flag is never accepted.
        # Only the already authenticated original child IPC, reviewed fixed
        # observer+correlator and current retained Native proof reach this seam.
        self._attest_native()
        fields = {'tenant_id','cloud_owner','device_id','account_id','account_uid',
            'note_id','target_comment_id','content','platform_comment_id','sender_uid',
            'observed_at','outcome','snapshot_hash'}
        spec = self.frame.spec
        if (self._evidence is not None or self._phase != 'observing'
                or type(record) is not dict or set(record) != fields
                or record['tenant_id'] != spec.tenant_id
                or record['cloud_owner'] != self._correlation_owner_alias()
                or record['device_id'] != spec.instance_id or record['account_id'] != spec.account_id
                or record['account_uid'] != spec.account_uid or record['note_id'] != spec.note_id
                or record['target_comment_id'] != spec.target_comment_id
                or record['content'] != self._draft or record['outcome'] not in ('sent','failed')
                or type(record['observed_at']) is not int or record['observed_at'] <= 0
                or type(record['snapshot_hash']) is not str or re.fullmatch('[a-f0-9]{64}',record['snapshot_hash']) is None):
            raise OwnedJobError('owned_observation_unconfirmed')
        payload = {key:value for key,value in record.items() if key != 'snapshot_hash'}
        original_hash = hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,
            separators=(',', ':')).encode('utf-8')).hexdigest()
        if original_hash != record['snapshot_hash']:
            raise OwnedJobError('owned_observation_unconfirmed')
        from .tracked_reply_window import _safe_id
        if (record['outcome'] == 'sent' and (record['sender_uid'] != spec.account_uid
                or not _safe_id(record['platform_comment_id'],160))):
            raise OwnedJobError('owned_observation_unconfirmed')
        if record['outcome'] == 'failed' and (record['platform_comment_id'] or record['sender_uid']):
            raise OwnedJobError('owned_observation_unconfirmed')
        evidence = object.__new__(_OwnedObservationEvidence)
        evidence.holder, evidence.outcome = self, record['outcome']
        evidence.observed_at, evidence.snapshot_hash = record['observed_at'], record['snapshot_hash']
        evidence.platform_comment_digest = hashlib.sha256(record['platform_comment_id'].encode('utf-8')).hexdigest() if record['platform_comment_id'] else None
        evidence.sender_uid_digest = hashlib.sha256(record['sender_uid'].encode('utf-8')).hexdigest() if record['sender_uid'] else None
        evidence._seal, evidence._binding = _EVIDENCE_SEAL, self._frame_binding()
        self.frame.check()
        self._evidence = evidence

    def cancel(self):
        with self._control_lock:
            self._cancelled.set()
        return self.close()

    def close(self):
        with self._control_lock:
            if self._closed:
                return True
            self._cancelled.set()
            self._cleanup_request.set()
            if self._running or self._close_inflight or self._worker is not None and self._worker.is_alive():
                return False
            # A dead unexpected original worker may have stranded its RLock.
            # Never release it on this finisher or guess the held resources gone.
            if self._worker is not None and not self._resources_closed:
                return False
        if self._worker is None and not self._close_resources_on_owner():
            return False
        with self._control_lock:
            if (not self._resources_closed or self._profile_lock is not None
                    or not self._resources.quiescent or not self._resources.empty
                    or any(thread.is_alive() for thread in self._threads)
                    or self._worker is not None and self._worker.is_alive()):
                return False
            self._closed = True
            return True

    def _close_resources_on_owner(self):
        with self._control_lock:
            if self._resources_closed:
                return True
            self._cancelled.set()
            if (self._running or self._close_inflight
                    or self._worker is not None and threading.current_thread() is not self._worker):
                return False
            self._close_inflight = True
        try:
            if self._port is not None:
                try:
                    if not self._port.close():
                        return False
                except Exception:
                    return False
            if any(thread.is_alive() for thread in self._threads):
                return False
            if not self._resources.stop_acquiring():
                return False
            if self._job is not None:
                try:
                    self._job.close()
                except Exception:
                    return False
            # Probe query handles/file leases are never freed before Job exit.
            if self._ready is not None:
                try:
                    self._ready.close_after_process()
                except Exception:
                    return False
            elif self._probe is not None:
                try:
                    self._probe.close()
                except Exception:
                    return False
            complete = True
            for lease in self._leases + ([self._spec_lease] if self._spec_lease is not None else []):
                try:
                    lease.close()
                except Exception:
                    complete = False
            if not self._resources.close_temporaries() or not self._resources.empty:
                complete = False
            if self._socket is not None:
                try:
                    self._socket.close()
                    self._socket = None
                except Exception:
                    complete = False
            if not complete:
                return False
            if self._profile_lock is not None:
                try:
                    self._profile_lock.__exit__(None, None, None)
                    self._profile_lock = None
                except Exception:
                    return False
            with self._control_lock:
                if (self._running or any(thread.is_alive() for thread in self._threads)
                        or not self._resources.quiescent):
                    return False
                self._draft = ''
                self._resources_closed = True
            return True
        finally:
            with self._control_lock:
                self._close_inflight = False

    def attest_phase(self, phase):
        if phase not in ('window_created', 'canonical_navigation_submitted', 'observing') or self._phase != phase:
            raise OwnedJobError('owned_phase_unconfirmed')
        return self._attest_native()

    def attested_closed(self):
        with self._control_lock:
            return (self._closed and self._resources_closed and not self._running and not self._close_inflight
                and (self._worker is None or not self._worker.is_alive())
                and not any(thread.is_alive() for thread in self._threads)
                and self._resources.empty and self._resources.quiescent
                and (self._job is None or self._job.closed)
                and self._socket is None and self._profile_lock is None
                and (self._probe is None or not self._probe.handles)
                and all(lease.handle is None for lease in self._leases)
                and (self._spec_lease is None or self._spec_lease.handle is None)
                and (self._port is None or self._port.closed))


def create(frame, draft_text):
    from .owner_web_contact_observation import _OwnerObservationFrame
    from .owner_contact_observation_policy import _OwnerObservationDecision
    if type(frame) is not _OwnerObservationFrame or type(frame.decision) is not _OwnerObservationDecision:
        raise OwnedJobError('owned_binding_unconfirmed')
    if (type(draft_text) is not str or not draft_text.strip() or len(draft_text) > 1000
            or '\x00' in draft_text
            or hashlib.sha256(draft_text.encode('utf-8')).hexdigest() != frame.spec.draft_hash):
        raise OwnedJobError('owned_draft_unconfirmed')
    frame.check()
    holder = _OwnerNativeAttempt(frame, draft_text)
    frame.retain(holder)
    return holder


class _OwnerObservationReadyGuard:
    def __init__(self, holder, pre_resume):
        if type(holder) is not _OwnerNativeAttempt or type(pre_resume) is not _OwnerObservationPreResumeGuard:
            _deny()
        self.holder, self.frame = holder, holder.frame
        self.decision, self.spec = self.frame.decision, self.frame.spec
        self.pre_resume, self.thread = pre_resume, threading.current_thread()
        self.process = self.retained = self.facts = None
        self.verified_at = None
        self.issued = 0
        self.leases = holder._leases
        self.probe = holder._probe = _OwnerReadyProbe(holder._resources)
        self._check()
        for path, sha, role in self.decision.expected_materials:
            _FileLease(path, sha, role, retain=self.leases.append)
        self._check()

    def _check(self):
        if threading.current_thread() is not self.thread or self.holder._cancelled.is_set():
            _deny()
        self.frame.check()
        self.decision.check(self.frame)
        if digest(self.pre_resume.spec_path) != self.pre_resume.spec_hash:
            _deny()
        if self.process is not None and (self.process.closed or
                (self.process.process, self.process.job, self.process.pid) != self.retained):
            _deny()

    def bind(self, process):
        if self.process is not None or type(process) is not _OwnerObservationJob:
            _deny()
        self.process, self.retained = process, (process.process, process.job, process.pid)
        process._page_ready_guard = self

    def verify(self, raw):
        self._check()
        if self.facts is not None or type(raw) is not dict or set(raw) != _FACT_KEYS:
            _deny()
        raw = copy.deepcopy(raw)
        if (raw['contract'] != 'owned_blank_window_sources_v1'
                or type(raw['helper_pid']) is not int or type(raw['browser_pid']) is not int
                or raw['helper_pid'] == raw['browser_pid']
                or type(raw['helper_created']) is not int
                or type(raw['snapshots']) is not list or len(raw['snapshots']) != 2
                or _checked_path(Path(raw['user_data_folder'])) != self.spec.profile_dir):
            _deny()
        python = _paths(raw['python_modules'], 2048)
        native = _paths(raw['native_modules'], 2048)
        managed = _paths(raw['managed_assemblies'], 512)
        snapshots = iter(raw['snapshots'])
        browser = next((row for row in raw['snapshots'][-1].get('processes', [])
                        if row.get('pid') == raw['browser_pid']), None)
        if browser is None:
            _deny()
        sid = self.pre_resume.sid
        expected_python = self.pre_resume.binding.executable(raw['helper_image'], sid, sid)
        if classifier.canonical_path(expected_python) != classifier.canonical_path(raw['helper_image']):
            _deny()
        helper_identity, actual_native = self.probe.capture(self.process, raw['helper_pid'],
            raw['helper_created'], raw['helper_image'], sid)
        browser_identity, browser_modules = self.probe.capture(self.process, raw['browser_pid'],
            browser['created'], browser['executable'], sid, cim_precision=True)
        if (tuple(path.lower() for path in sorted(native, key=str.lower)) !=
                tuple(path.lower() for path in actual_native)
                or browser_identity['image'] not in {classifier.canonical_path(path)
                    for path, sha, role in self.decision.expected_materials
                    if role == 'webview_runtime'}):
            _deny()
        occupancy = _OwnerOccupancyAdapter(self.holder._resources).classify(self.spec.profile_dir,
            snapshot_provider=lambda: next(snapshots), current_sid_provider=self.pre_resume.image.current_sid,
            owned=self.process.contains, expected_browser=browser['executable'],
            trusted_python=self.pre_resume.binding, owned_context=self)
        if occupancy.get('state') != 'vacant':
            _deny()
        for lease in self.leases:
            lease.check(hash_bytes=True)
        facts = {'contract': 'page_ready_sources_v1',
            'helper_pid': helper_identity['pid'], 'helper_created': helper_identity['created'],
            'helper_image': helper_identity['image'], 'browser_pid': browser_identity['pid'],
            'browser_created': browser_identity['created'], 'browser_image': browser_identity['image'],
            'user_data_folder': str(self.spec.profile_dir), 'python_modules': python,
            'native_modules': actual_native, 'browser_modules': browser_modules,
            'managed_assemblies': managed,
            'bound_materials': tuple((str(lease.path), lease.sha, lease.role, lease.identity)
                                     for lease in self.leases),
            'job_membership_verified': True, 'loaded_sources_verified': True,
            'profile_vacancy_verified': True, 'native_loaded_bytes_verified': False}
        self.decision.check_materials(facts)
        self._check()
        self.facts, self.verified_at = facts, time.monotonic()

    def validate(self):
        self._check()
        return True

    def contains(self, pid, created):
        self._check()
        if self.process.contains(pid, created) is not True:
            _deny()
        self._check()
        return True

    @contextmanager
    def issue(self):
        self._check()
        if self.facts is None or self.issued != 0 or time.monotonic()-self.verified_at > 15:
            _deny()
        for lease in self.leases:
            lease.check()
        self.decision.check_materials(self.facts)
        with self.frame.native_barrier(self.holder), self.holder._control_lock:
            if self.holder._cancelled.is_set():
                _deny()
            yield
            self.issued += 1

    def close_after_process(self):
        if self.process is not None and not self.process.closed:
            _deny()
        failed = False
        try:
            self.probe.close()
        except Exception:
            failed = True
        for lease in self.leases:
            try:
                lease.close()
            except Exception:
                failed = True
        if failed:
            _deny()
