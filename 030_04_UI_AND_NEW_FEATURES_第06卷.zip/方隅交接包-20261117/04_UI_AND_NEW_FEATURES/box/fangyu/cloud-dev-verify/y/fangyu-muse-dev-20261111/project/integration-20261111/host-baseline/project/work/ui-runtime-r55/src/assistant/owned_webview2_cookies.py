"""Read CookieManager from one owned pywebview EdgeChromium window.

Project-owned, pinned-runtime adapter. Never patches pywebview or enumerates
browser profiles. The values stay in process memory; callers must not log them.
"""

from __future__ import annotations

from threading import Event

if __package__:
    from .auth_candidate import CandidateRejected, OwnedCookie
else:
    from auth_candidate import CandidateRejected, OwnedCookie


def read_owned_window_cookies(window, *, expected_url: str,
                              allowed_names: frozenset[str], timeout_s: float = 10.0
                              ) -> list[OwnedCookie]:
    """UI-marshalled WebView2 read, retaining each cookie's IsSession flag."""
    if not 0 < timeout_s <= 30:
        raise CandidateRejected("reader_timeout_invalid")
    try:
        current_url = window.get_current_url()
    except Exception:
        raise CandidateRejected("reader_url_failed") from None
    if current_url != expected_url:
        raise CandidateRejected("origin_mismatch")

    # These are the already-loaded Windows bindings of this specific pywebview
    # runtime. No global monkeypatch, browser-cookie3, or default Edge profile.
    try:
        from webview.platforms import edgechromium as edge
    except Exception:
        raise CandidateRejected("reader_import_failed") from None

    try:
        form = window.native
    except Exception:
        raise CandidateRejected("reader_form_failed") from None
    try:
        browser = getattr(form, "browser", None)
    except Exception:
        raise CandidateRejected("reader_browser_failed") from None
    try:
        control = getattr(form, "webview", None)
    except Exception:
        raise CandidateRejected("reader_control_failed") from None
    try:
        owned = (browser is not None
                 and getattr(browser, "pywebview_window", None) is window
                 and getattr(browser, "webview", None) is control
                 and control is not None)
    except Exception:
        raise CandidateRejected("reader_identity_failed") from None
    if not owned:
        raise CandidateRejected("owned_window_invalid")

    complete = Event()
    outcome: dict[str, object] = {"code": "reader_failed", "cookies": None}

    def collect(task):
        def on_ui():
            try:
                if task.IsCanceled or task.IsFaulted:
                    outcome["code"] = "reader_failed"
                    return
                cookies: list[OwnedCookie] = []
                for item in task.Result:
                    name = str(item.Name)
                    if name not in allowed_names:
                        continue
                    cookies.append(OwnedCookie(
                        name=name,
                        value=str(item.Value),
                        domain=str(item.Domain),
                        path=str(item.Path),
                        secure=bool(item.IsSecure),
                        httponly=bool(item.IsHttpOnly),
                        is_session=bool(item.IsSession),
                        expires="" if bool(item.IsSession) else str(
                            item.Expires.ToString("r", edge.CultureInfo.GetCultureInfo("en-US"))
                        ),
                    ))
                outcome["cookies"] = cookies
                outcome["code"] = "ok"
            except Exception:
                outcome["code"] = "reader_failed"
            finally:
                complete.set()

        try:
            # The installed pywebview adapter uses the same Invoke boundary
            # because WebView2 cookie objects must be inspected on the UI thread.
            form.Invoke(edge.Func[edge.Type](on_ui))
        except Exception:
            outcome["code"] = "reader_failed"
            complete.set()

    def begin_on_ui():
        try:
            if control.CoreWebView2 is None:
                outcome["code"] = "reader_uninitialized"
                complete.set()
                return
            task = control.CoreWebView2.CookieManager.GetCookiesAsync(expected_url)
            task.ContinueWith(
                edge.Action[edge.Task[edge.List[edge.CoreWebView2Cookie]]](collect),
                browser.syncContextTaskScheduler,
            )
        except Exception:
            outcome["code"] = "reader_failed"
            complete.set()

    try:
        form.BeginInvoke(edge.Action(begin_on_ui))
    except Exception:
        raise CandidateRejected("reader_failed") from None
    if not complete.wait(timeout_s):
        raise CandidateRejected("reader_timeout")
    if outcome["code"] != "ok":
        raise CandidateRejected(str(outcome["code"]))
    try:
        current_url = window.get_current_url()
    except Exception:
        raise CandidateRejected("reader_url_failed") from None
    if current_url != expected_url:
        raise CandidateRejected("origin_mismatch")
    cookies = outcome["cookies"]
    if not isinstance(cookies, list):
        raise CandidateRejected("reader_failed")
    return cookies
