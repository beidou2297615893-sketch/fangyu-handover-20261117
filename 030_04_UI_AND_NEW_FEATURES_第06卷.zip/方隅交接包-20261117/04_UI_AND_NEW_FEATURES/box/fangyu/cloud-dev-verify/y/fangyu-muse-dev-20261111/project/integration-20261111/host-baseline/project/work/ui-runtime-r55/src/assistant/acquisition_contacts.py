"""Consent-scoped local contacts. Payloads use the existing Windows DPAPI primitive.

This is local encrypted storage, not a cross-device delivery or resource-team ACK.
No contact value is included in audit metadata or normal list projections.
"""
import base64
import hashlib
import json
import re
import time
import uuid

from core import CoreError
from integrations import protect


def _reject(message):
    error = CoreError(message)
    # These explicit checks run before any commit, or inside the one SQLite
    # transaction. Foreign exceptions never inherit this outcome assertion.
    error.mutation_committed = False
    return error


def _text(value, label, maximum=160):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise _reject(label + '无效')
    if any(ord(char) < 32 for char in value):
        raise _reject(label + '无效')
    return value.strip()


def _mask(value):
    return value[:2] + '*' * max(4, min(10, len(value) - 4)) + value[-2:]


class AcquisitionContacts:
    ACTIONS = frozenset({'contact_create', 'contact_read', 'contact_revoke'})

    def __init__(self, core, tenant, owner, company, *, lead_access=None, crypt=None, owner_scope=None):
        self.core, self.store = core, core.store
        self.tenant, self.owner, self.company = tenant, owner, company
        self.lead_access = lead_access
        self.crypt = crypt or protect
        self._owner_scope = None
        if owner_scope is not None:
            from .self_operating_acquisition import _validated_owner_scope
            self._owner_scope = _validated_owner_scope(owner_scope, core, tenant, owner, company)

    def _owner_checkpoint(self, user, db=None, record=None):
        if self._owner_scope is not None:
            return self._owner_scope.check(user, db, record)

    def _principal(self, user):
        if self._owner_scope is not None:
            return self._owner_checkpoint(user)
        saved = self.store.get('users', user.get('id')) if isinstance(user, dict) else None
        if (not saved or saved.get('tenant_id') != self.tenant
                or saved.get('username') != self.owner or saved.get('disabled')
                or saved.get('cloud_bound') is not True
                or saved.get('role') not in ('operator', 'admin')
                or user.get('role') != saved.get('role')
                or user.get('tenant_id') != self.tenant
                or user.get('username') != self.owner):
            raise _reject('联系方式权限已失效，请核对当前员工身份')
        return saved

    def _lead(self, ident, user):
        lead = self.store.get('leads', ident)
        if (not lead or lead.get('tenant_id') != self.tenant
                or lead.get('cloud_owner') != self.owner):
            raise _reject('只能保存自己有来源证据的客户联系方式')
        if self.lead_access:
            self.lead_access(user, lead)
        if self._owner_scope is not None:
            self._owner_scope.source(user, lead)
        return lead

    def _record(self, ref, user):
        if not isinstance(ref, str) or not re.fullmatch(r'contact:[0-9a-f]{32}', ref):
            raise _reject('联系方式引用无效')
        record = self.store.get('acquisition_contacts', ref[8:])
        if (not record or record.get('tenant_id') != self.tenant
                or record.get('cloud_owner') != self.owner):
            raise _reject('联系方式不存在或无权访问')
        self._lead(record['lead_id'], user)
        self._owner_checkpoint(user, record=record)
        return record

    def _unseal(self, record):
        try:
            payload = json.loads(self.crypt(base64.b64decode(record['encrypted_payload'], validate=True), decrypt=True))
        except Exception:
            raise _reject('本机联系方式无法解密，请使用保存它的Windows账户核对') from None
        if any(payload.get(key) != record.get(key) for key in ('tenant_id', 'cloud_owner', 'lead_id', 'recipient_id', 'purpose', 'consent')):
            raise _reject('联系方式归属校验失败')
        if self._owner_scope is not None and payload.get('owner_acquisition_scope') != record.get('owner_acquisition_scope'):
            raise _reject('本机联系方式加密范围不一致')
        return payload

    def _package_read(self, reference, user, db, context, *, decrypt=False):
        """Private same-db owner package read; never a public contact permission."""
        from .owner_contact_handoff_package import _validate_package_context
        if self._owner_scope is None or type(decrypt) is not bool:
            raise _reject('资料包只能核对当前本人的原保护联系方式')
        _validate_package_context(context, self._owner_scope.service, db)
        frame = self._owner_scope._frame()
        if frame.get('package_context') is not context or frame['action'] != 'contact_read':
            raise _reject('不在当前资料包的逐来源核对范围内')
        if type(reference) is not str or not re.fullmatch(r'contact:[0-9a-f]{32}', reference):
            raise _reject('原保护联系方式引用需核对')
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            ('acquisition_contacts', reference[8:], self.tenant)).fetchone()
        if row is None:
            raise _reject('原保护联系方式不存在')
        record = json.loads(row['body'])
        if (type(record) is not dict or record.get('id') != reference[8:]
                or record.get('tenant_id') != self.tenant or record.get('cloud_owner') != self.owner
                or record.get('lead_id') != frame['lead_id'] or record.get('revoked_at') is not None
                or type(record.get('revision')) is not int or record['revision'] != 1
                or record.get('storage_scope') != 'local_current_windows_user'
                or type(record.get('consent')) is not dict or record['consent'].get('status') != 'granted'
                or not record.get('encrypted_payload')):
            raise _reject('客户当前同意或保护存储需核对')
        self._owner_checkpoint(user, db, record)
        self._check_withdrawal(record['consent'], db)
        payload = self._unseal(record) if decrypt else None
        if payload is not None and (type(payload.get('phone')) is not str or type(payload.get('wechat')) is not str
                or not (payload['phone'] or payload['wechat'])
                or payload['phone'] and not re.fullmatch(r'\+?[0-9]{7,15}', payload['phone'])
                or payload['wechat'] and not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{5,29}', payload['wechat'])):
            raise _reject('原保护联系方式内容需核对')
        self._owner_checkpoint(user, db, record)
        return record, payload

    def _view(self, record):
        view = {key: record[key] for key in ('id', 'lead_id', 'recipient_id', 'purpose',
                'masked', 'revision', 'created_at', 'revoked_at', 'storage_scope') if key in record}
        view.update(contact_reference='contact:' + record['id'],
                    consent={**record['consent'], 'evidence_source': 'operator_recorded',
                             'independently_verified': False})
        return view

    def _check_withdrawal(self, consent, db=None):
        # A consent reference identifies one recorded consent, even when the
        # caller changes the idempotency key, lead or recipient after withdrawal.
        # It is not a verified customer signature; fresh consent needs a new ref.
        if db is None:
            with self.store.connect() as connection:
                return self._check_withdrawal(consent, connection)
        rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                          ('acquisition_consent_withdrawals', self.tenant)).fetchall()
        if any(json.loads(row['body']).get('consent_reference') == consent['evidence_reference']
               for row in rows):
            raise _reject('此同意记录已撤回，请重新取得客户明确同意')

    def _audit(self, db, record, kind, actor):
        event = {'id': uuid.uuid4().hex, 'tenant_id': self.tenant,
                 'contact_id': record['id'], 'lead_id': record['lead_id'],
                 'cloud_owner': self.owner, 'actor': actor['username'],
                 'kind': kind, 'occurred_at': time.time(), 'revision': record['revision']}
        encoded = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        db.execute('INSERT INTO records VALUES(?,?,?,?)',
                   ('acquisition_contact_events', event['id'], self.tenant, encoded))

    def execute(self, action, data, user):
        if action not in self.ACTIONS or not isinstance(data, dict):
            raise _reject('不支持此联系方式操作')
        if self._owner_scope is not None:
            self._owner_scope.require_action(action)
        actor = self._principal(user)
        if action == 'contact_create':
            allowed = {'lead_id', 'recipient_id', 'purpose', 'consent', 'phone', 'wechat', 'idempotency_key'}
            if set(data) - allowed:
                raise _reject('联系方式参数无效')
            lead = self._lead(_text(data.get('lead_id'), '客户来源标识', 200), actor)
            recipient = _text(data.get('recipient_id'), '接收方标识', 80)
            purpose = _text(data.get('purpose'), '转交用途', 160)
            consent = data.get('consent')
            if (not isinstance(consent, dict) or set(consent) != {'status', 'evidence_reference', 'notice_version'}
                    or consent.get('status') != 'granted'):
                raise _reject('请先告知接收方与用途，并保存客户明确同意的证据')
            consent = {'status': 'granted', 'evidence_reference': _text(consent.get('evidence_reference'), '同意证据引用', 200),
                       'notice_version': _text(consent.get('notice_version'), '告知版本', 80)}
            if not re.fullmatch(r'consent:[0-9a-f]{32}', consent['evidence_reference']):
                raise _reject('同意证据必须使用明确的同意记录引用')
            phone, wechat = data.get('phone', ''), data.get('wechat', '')
            if not isinstance(phone, str) or not isinstance(wechat, str):
                raise _reject('请填写客户同意提供的手机号或微信号')
            phone, wechat = phone.strip(), wechat.strip()
            if not (phone or wechat):
                raise _reject('请填写客户同意提供的手机号或微信号')
            if phone and not re.fullmatch(r'\+?[0-9][0-9 ()-]{5,30}', phone):
                raise _reject('手机号格式无效')
            if phone:
                phone = ('+' if phone.startswith('+') else '') + re.sub(r'[^0-9]', '', phone)
                if not re.fullmatch(r'\+?[0-9]{7,15}', phone):
                    raise _reject('手机号格式无效')
            if wechat and not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{5,29}', wechat):
                raise _reject('微信号格式无效')
            key = _text(data.get('idempotency_key'), '操作标识', 128)
            if not re.fullmatch(r'[A-Za-z0-9_-]{8,128}', key):
                raise _reject('操作标识无效')
            ident = hashlib.sha256((self.tenant + '\n' + self.owner + '\n' + key).encode()).hexdigest()[:32]
            payload = {'tenant_id': self.tenant, 'cloud_owner': self.owner, 'lead_id': lead['id'],
                       'recipient_id': recipient, 'purpose': purpose, 'consent': consent, 'phone': phone, 'wechat': wechat}
            if self._owner_scope is not None:
                payload['owner_acquisition_scope'] = self._owner_scope.binding()
            with self.core.lock, self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                self._principal(actor)
                self._owner_checkpoint(actor, db)
                self._check_withdrawal(consent, db)
                row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                                 ('acquisition_contacts', ident, self.tenant)).fetchone()
                if row:
                    existing = json.loads(row['body'])
                    self._owner_checkpoint(actor, db, existing)
                    if existing.get('revoked_at') or self._unseal(existing) != payload:
                        raise _reject('此操作标识已有不同结果，请先核对原联系方式')
                    return self._view(existing)
                self._owner_checkpoint(actor, db)
                try:
                    sealed = self.crypt(json.dumps(payload, ensure_ascii=False).encode())
                except Exception:
                    raise _reject('安全存储不可用，未保存联系方式') from None
                record = {key: payload[key] for key in ('tenant_id', 'cloud_owner', 'lead_id', 'recipient_id', 'purpose', 'consent')}
                record.update(id=ident, encrypted_payload=base64.b64encode(sealed).decode(),
                              masked={key: _mask(value) for key, value in (('phone', phone), ('wechat', wechat)) if value},
                              revision=1, created_at=time.time(), revoked_at=None, storage_scope='local_current_windows_user')
                if self._owner_scope is not None:
                    record['owner_acquisition_scope'] = payload['owner_acquisition_scope']
                self._owner_checkpoint(actor, db, record)
                db.execute('INSERT INTO records VALUES(?,?,?,?)', ('acquisition_contacts', ident, self.tenant,
                           json.dumps(record, ensure_ascii=False)))
                self._audit(db, record, 'created', actor)
                self._owner_checkpoint(actor, db, record)
                return self._view(record)
        if action == 'contact_read':
            if set(data) - {'contact_reference', 'reveal'} or type(data.get('reveal', False)) is not bool:
                raise _reject('读取联系方式参数无效')
            record = self._record(data.get('contact_reference'), actor)
            if self._owner_scope is not None and (record.get('revoked_at') or record.get('consent', {}).get('status') != 'granted') and not data.get('reveal'):
                self._owner_checkpoint(actor, record=record)
                return self._view(record)
            if record.get('revoked_at') or record.get('consent', {}).get('status') != 'granted':
                raise _reject('客户已撤回授权，联系方式不可使用')
            self._check_withdrawal(record['consent'])
            view = self._view(record)
            if data.get('reveal'):
                with self.core.lock, self.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE')
                    fresh = self._record(data.get('contact_reference'), self._principal(actor))
                    self._owner_checkpoint(actor, db, fresh)
                    if fresh.get('revoked_at'):
                        raise _reject('客户已撤回授权，联系方式不可使用')
                    self._check_withdrawal(fresh['consent'], db)
                    payload = self._unseal(fresh)
                    view['contact'] = {key: payload[key] for key in ('phone', 'wechat') if payload[key]}
                    self._audit(db, fresh, 'revealed', actor)
                    self._owner_checkpoint(actor, db, fresh)
            return view
        if set(data) != {'contact_reference', 'expected_revision'} or type(data['expected_revision']) is not int:
            raise _reject('撤回联系方式参数无效')
        with self.core.lock, self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            record = self._record(data['contact_reference'], self._principal(actor))
            self._owner_checkpoint(actor, db, record)
            if record['revision'] != data['expected_revision']:
                raise _reject('联系方式已变化，请刷新后再核对')
            if record.get('revoked_at'):
                return self._view(record)
            stamp = time.time()
            withdrawal = {'id': uuid.uuid4().hex, 'tenant_id': self.tenant,
                'cloud_owner': self.owner, 'lead_id': record['lead_id'], 'recipient_id': record['recipient_id'],
                'purpose': record['purpose'], 'consent_reference': record['consent']['evidence_reference'],
                'actor': actor['username'], 'occurred_at': stamp}
            db.execute('INSERT INTO records VALUES(?,?,?,?)', ('acquisition_consent_withdrawals',
                withdrawal['id'], self.tenant, json.dumps(withdrawal, ensure_ascii=False)))
            rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                              ('acquisition_contacts', self.tenant)).fetchall()
            for row in rows:
                sibling = json.loads(row['body'])
                if (sibling.get('cloud_owner') != self.owner or sibling.get('revoked_at')
                        or sibling.get('consent', {}).get('evidence_reference') != withdrawal['consent_reference']):
                    continue
                sibling.update(revision=sibling['revision'] + 1, revoked_at=stamp,
                               consent={**sibling['consent'], 'status': 'withdrawn'}, encrypted_payload='')
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                           (json.dumps(sibling, ensure_ascii=False), 'acquisition_contacts', sibling['id'], self.tenant))
                self._audit(db, sibling, 'revoked', actor)
                if sibling['id'] == record['id']:
                    record = sibling
            self._owner_checkpoint(actor, db, record)
            return self._view(record)
