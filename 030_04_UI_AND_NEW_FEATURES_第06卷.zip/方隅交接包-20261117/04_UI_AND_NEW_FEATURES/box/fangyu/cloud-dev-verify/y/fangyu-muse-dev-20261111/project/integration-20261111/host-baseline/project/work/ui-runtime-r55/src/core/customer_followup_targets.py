"""Immutable, source-verified inbound turns. No caller-supplied message facts."""
from contextvars import ContextVar
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib,json,re,time
from urllib.parse import urlsplit
from .response_journal import ResponseJournal,_normalized,payload_hash
from .review_queue import require_reply_permission

_TRUSTED=ContextVar('verified_followup_draft',default=None)
ENTITY='customer_followup_targets_v1'
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def customer_id(lead):return hashlib.sha256(json.dumps((lead['platform'],'uid',lead['author_id']),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def epoch(value):
 if isinstance(value,(int,float)):return int(value)
 try:return int(datetime.fromisoformat(str(value).replace('Z','+00:00')).timestamp())
 except (ValueError,TypeError):return 0

class FollowupTargets:
 def __init__(self,core):
  self.core=core;ResponseJournal(core.store)
  with core.store.connect() as db:
   db.executescript('''CREATE TABLE IF NOT EXISTS customer_followup_targets_v1(
    id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,body TEXT NOT NULL);
    CREATE TRIGGER IF NOT EXISTS followup_target_no_update BEFORE UPDATE ON customer_followup_targets_v1
     BEGIN SELECT RAISE(ABORT,'followup target is immutable'); END;
    CREATE TRIGGER IF NOT EXISTS followup_target_no_delete BEFORE DELETE ON customer_followup_targets_v1
     BEGIN SELECT RAISE(ABORT,'followup target is immutable'); END;''')
 def _source(self,observation_id,user,store_id):
  tenant=user['tenant_id'];owner=user.get('username')
  if not owner or not store_id:raise ValueError('跟进员工或门店范围缺失')
  with self.core.store.connect() as db:
   row=db.execute('''SELECT o.*,b.observation_id blocked FROM contact_response_outbox o
    LEFT JOIN contact_response_blocks b ON b.observation_id=o.observation_id
    WHERE o.observation_id=? AND o.tenant_id=? AND o.cloud_owner=?''',(observation_id,tenant,owner)).fetchone()
  if not row or row['blocked']:raise ValueError('客户回应不存在、已被阻止或不在当前员工范围')
  body=json.loads(row['payload'])
  if _normalized(body)!=body or payload_hash(body)!=row['payload_hash']:raise ValueError('客户回应来源摘要不符')
  reply=self.core._get('replies',body['local_reply_id'],tenant)
  anchor=self.core._get('leads',reply['lead_id'],tenant)
  require_reply_permission(self.core,user,anchor)
  if anchor.get('task_id'):
   task=self.core._get('tasks',anchor['task_id'],tenant);self.core._task_access(user,task,tenant)
  else:task={}
  if (anchor.get('cloud_owner') or task.get('cloud_owner'))!=owner:raise ValueError('原客户不属于当前员工')
  if (anchor.get('store_id') or task.get('store_id')) not in (store_id,):raise ValueError('原客户不属于当前门店')
  if user.get('_workbench_store_id',user.get('store_id',store_id))!=store_id:raise ValueError('当前门店范围变化')
  account=self.core._get('accounts',reply.get('account_id'),tenant);self.core._account_access(user,account)
  if account.get('store_id')!=store_id or account.get('cloud_owner')!=owner:raise ValueError('回应账号不属于当前员工门店')
  source=self.core._reply_source(reply,user,account=account) if reply.get('followup_target_id') else anchor
  sent=self.core.contact_journal.sent_snapshot(tenant,owner,body['sent_event_id'],reply['id'],anchor['id'])
  receipt=self.core.contact_journal.receipt(tenant,owner,reply['id'],anchor['id'])
  events=receipt.get('events') or [];sents=[e for e in events if e.get('event_id')==body['sent_event_id'] and e.get('kind')=='sent']
  starts=[e for e in events if e.get('kind')=='send_started' and e.get('local_integrity')=='ok']
  with self.core.store.connect() as db:
   ledger=db.execute('SELECT event_id,kind,payload FROM contact_events WHERE tenant_id=? AND cloud_owner=? AND reply_id=? ORDER BY sequence',(tenant,owner,reply['id'])).fetchall()
  sent_index=next((i for i,e in enumerate(ledger) if e['event_id']==body['sent_event_id']),-1)
  prior_start=next((i for i in range(sent_index-1,-1,-1) if ledger[i]['kind']=='send_started'),-1)
  paired=False
  if prior_start>=0:
   start=json.loads(ledger[prior_start]['payload'])
   paired=(not any(e['kind'] in ('sent','failed','unknown','external_reported') for e in ledger[prior_start+1:sent_index])
    and start.get('sender',{}).get('account_id')==account['id']
    and start.get('reply',{}).get('id')==reply['id'] and start['reply'].get('text')==reply.get('text')
    and all(start.get('lead',{}).get(k)==source.get(k,'') for k in ('id','platform','author_id','comment_id','note_url')))
  incoming=body['response'];note=re.search(r'/([A-Za-z0-9]{24})/?$',urlsplit(incoming['note_url']).path)
  if (not paired or not sent or not sents or not starts or not any(e['occurred_at']<=sents[0]['occurred_at'] for e in starts)
   or reply.get('status')!='sent' or reply.get('platform_reply_id')!=body['platform_reply_id']
   or source.get('comment_id')!=body['origin_comment_id'] or source.get('note_url')!=incoming['note_url']
   or source.get('author_id')!=incoming['author_id'] or source.get('platform')!='xiaohongshu'
   or sent['lead'].get('comment_id')!=body['origin_comment_id'] or sent['lead'].get('note_url')!=incoming['note_url']
   or sent['lead'].get('author_id')!=incoming['author_id'] or sent['sender'].get('account_id')!=account['id']
   or sent['sender'].get('platform_uid')!=account.get('platform_uid')
   or sent['reply'].get('platform_reply_id')!=body['platform_reply_id']
   or incoming['target_comment_id']!=body['platform_reply_id'] or incoming['target_author_id']!=account.get('platform_uid')
   or incoming['author_id']==account.get('platform_uid') or incoming['comment_id'] in (source.get('comment_id'),body['platform_reply_id']) or incoming['published_at']<=max(epoch(reply.get('sent_at')),sent['occurred_at'])
   or not note or row['platform']!='xiaohongshu' or row['comment_id']!=incoming['comment_id'] or row['post_key']!=note.group(1).lower()):raise ValueError('客户回应与原成功发送、账号身份或同帖线程不能核对')
  value={'schemaVersion':1,'tenant_id':tenant,'owner':owner,'storeId':store_id,'anchorLeadId':anchor['id'],
   'customerId':customer_id(anchor),'accountId':account['id'],'accountUid':account['platform_uid'],'platform':'xiaohongshu',
   'customerUid':incoming['author_id'],'noteId':note.group(1).lower(),'noteUrl':incoming['note_url'],
   'incomingCommentId':incoming['comment_id'],'incomingText':incoming['text'],'incomingPublishedAt':incoming['published_at'],
   'incomingObservationId':observation_id,'payloadHash':row['payload_hash'],'parentLocalReplyId':reply['id'],
   'parentPlatformReplyId':body['platform_reply_id'],'parentSentEventId':body['sent_event_id']}
  value['id']=digest([tenant,store_id,value['platform'],account['id'],account['platform_uid'],incoming['author_id'],value['noteId'],incoming['comment_id']])
  anchor_source={key:anchor.get(key) for key in ('id','tenant_id','cloud_owner','store_id','task_id','platform','author_id','comment_id','note_url','text','source_type')}
  value['sourceDigest']=digest([anchor_source,value])
  return value,anchor
 def create(self,observation_id,user,store_id,customer_id=None):
  value,_=self._source(observation_id,user,store_id)
  if customer_id is not None and customer_id!=value['customerId']:raise ValueError('回应客户身份不符')
  with self.core.store.connect() as db:
   db.execute('BEGIN IMMEDIATE')
   old=db.execute('SELECT body FROM customer_followup_targets_v1 WHERE id=?',(value['id'],)).fetchone()
   if old:
    saved=json.loads(old['body'])
    if {k:v for k,v in saved.items() if k!='createdAt'}!=value:raise ValueError('跟进目标来源已变更，禁止替换')
    return saved
   value['createdAt']=time.time()
   db.execute('INSERT INTO customer_followup_targets_v1 VALUES(?,?,?,?)',(value['id'],value['tenant_id'],value['owner'],json.dumps(value,ensure_ascii=False)))
  return value
 def get(self,ident,user,account=None):
  with self.core.store.connect() as db:
   row=db.execute('SELECT body FROM customer_followup_targets_v1 WHERE id=? AND tenant_id=? AND cloud_owner=?',(ident,user['tenant_id'],user.get('username'))).fetchone()
  if not row:raise ValueError('跟进目标不存在或无权访问')
  target=json.loads(row['body']);current,anchor=self._source(target['incomingObservationId'],user,target['storeId'])
  if {k:v for k,v in target.items() if k!='createdAt'}!=current:raise ValueError('跟进目标来源或原客户记录变化，请重新核对')
  if account is not None and (account['id']!=target['accountId'] or account.get('platform_uid')!=target['accountUid']):raise ValueError('跟进必须使用收到回应的原账号')
  return target,anchor
 def resolve(self,ident,user,account=None):
  target,anchor=self.get(ident,user,account)
  return {**anchor,'comment_id':target['incomingCommentId'],'text':target['incomingText'],'note_url':target['noteUrl'],
   'parent_id':target['incomingCommentId'],'followup_target_id':target['id'],'followup_target_digest':target['sourceDigest'],
   'followup_target':target,'readonly_archive':False,'reply_source_type':'verified_customer_response'}
 def latest(self,ident,user):
  target,_=self.get(ident,user)
  return max((r for r in self.core.store.list('replies',user['tenant_id']) if r.get('followup_target_id')==target['id']),key=lambda r:(r.get('version',0),r['id']),default=None)
 def draft(self,ident,text,user):
  target,_=self.get(ident,user);self.validate_public_text(target,text);token=_TRUSTED.set((self.core,target['id']))
  try:return self.core._reply('draft_reply',{'lead_id':target['anchorLeadId'],'text':text,'channel':'comment'},user,user['tenant_id'])
  finally:_TRUSTED.reset(token)
 def validate_public_text(self,target,text):
  if not isinstance(text,str):raise ValueError('回复内容无效')
  phones=set()
  with self.core.store.connect() as db:
   observations=db.execute('SELECT payload FROM contact_response_outbox WHERE tenant_id=? AND cloud_owner=?',(target['tenant_id'],target['owner'])).fetchall()
   for row in observations:
    body=json.loads(row['payload']);incoming=body.get('response') or {}
    if incoming.get('author_id')==target['customerUid']:
     phones.update(re.findall(r'(?<![0-9])1[3-9][0-9]{9}(?![0-9])',str(incoming.get('text') or '')))
   rows=db.execute("SELECT body FROM records WHERE entity='ui_customer_followup_private_phone_v1' AND tenant_id=?",(target['tenant_id'],)).fetchall()
   for row in rows:
    body=json.loads(row['body'])
    if body.get('customerId')==target['customerId'] and body.get('owner')==target['owner'] and body.get('phone'):phones.add(body['phone'])
  compact=re.sub(r'[\s()+-]','',text)
  if any(phone in compact for phone in phones):raise ValueError('客户手机号只用于私有承接，不能写入公开评论回复')
 def trusted(self):
  value=_TRUSTED.get()
  return value[1] if value and value[0] is self.core else None
 def conflict(self,reply,lead,others):
  followup=bool(reply.get('followup_target_id'))
  key=digest([lead['tenant_id'],lead.get('platform'),str(lead.get('author_id') or '')])
  claim=self.core.store.get('ui_customer_reply_guard_v1',key)
  if claim and claim.get('state') in ('reserved','sending','unknown') and (claim.get('reply_id')!=reply.get('id') or claim.get('state')=='unknown'):return True
  if followup:
   turn=self.core.store.get('customer_followup_turn_claims_v1',digest([lead['tenant_id'],reply['followup_target_id']]))
   if turn and turn.get('state')!='released' and (turn.get('reply_id')!=reply.get('id') or turn.get('state')!='reserved'):return True
  for old in others:
   if old['id']==reply.get('id'):continue
   if old.get('status') in ('sending','unknown'):return True
   if old.get('status') in ('sent','copied') and (not followup or old.get('followup_target_id')==reply.get('followup_target_id')):return True
  return False
