"""Exact portable disk closure. Its expected SHA comes from original review."""
import hashlib,json,re,stat
from pathlib import Path

MANIFEST='HELPER-PACKAGE.json'
def _safe(path,directory=False):
 p=Path(path)
 if not p.is_absolute() or '..' in p.parts:raise ValueError('helper_path_invalid')
 for q in (p,*p.parents):
  info=q.lstat()
  if q.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('helper_reparse')
 info=p.stat()
 if directory:
  if not stat.S_ISDIR(info.st_mode):raise ValueError('helper_directory_invalid')
 elif not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise ValueError('helper_file_invalid')
 return (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_nlink)
def hash_file(path):
 before=_safe(path);h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 if before!=_safe(path):raise ValueError('helper_file_changed')
 return h.hexdigest(),before
def verify_package(executable,expected_manifest_sha=None):
 exe=Path(executable);root=exe.parent;_safe(root,True)
 if exe.name!='FangyuXhsPageHelper.exe':raise ValueError('helper_executable_invalid')
 manifest=root/MANIFEST;state=_safe(manifest)
 if not 0<state[2]<=3000000:raise ValueError('helper_manifest_invalid')
 raw=manifest.read_bytes();manifest_sha=hashlib.sha256(raw).hexdigest()
 if expected_manifest_sha is not None and manifest_sha!=expected_manifest_sha:raise ValueError('helper_manifest_changed')
 data=json.loads(raw)
 if set(data)!={'schema','entry','python','sourceModules','codeModules','entryCode','files'} or data['schema']!='portable_xhs_page_helper_v1' or data['entry']!=exe.name or type(data['files']) is not list or not 1<=len(data['files'])<=5000:raise ValueError('helper_manifest_invalid')
 pins={};facts=[]
 for row in data['files']:
  rel=row['path']
  if set(row)!={'path','sha256','bytes'} or type(rel) is not str or '\\' in rel or ':' in rel or any(p in ('','.','..','__pycache__') for p in rel.split('/')) or rel.endswith(('.pyc','.pyo')) or rel in pins or not re.fullmatch('[0-9a-f]{64}',row['sha256']) or type(row['bytes']) is not int or row['bytes']<0:raise ValueError('helper_manifest_invalid')
  pins[rel]=row
 actual=set()
 for path in root.rglob('*'):
  if path.is_dir():_safe(path,True);continue
  rel=path.relative_to(root).as_posix();actual.add(rel)
  if rel==MANIFEST:continue
  if rel not in pins:raise ValueError('helper_extra_file')
  value,sig=hash_file(path)
  if value!=pins[rel]['sha256'] or sig[2]!=pins[rel]['bytes']:raise ValueError('helper_material_changed')
  facts.append((rel,value,sig))
 if actual!=set(pins)|{MANIFEST} or _safe(manifest)!=state:raise ValueError('helper_closure_changed')
 return data,manifest_sha,tuple(facts)

def check_code_origins(origins,manifest,root):
 from portable_code_origins import code_digest
 expected=manifest['codeModules'];entry=manifest['entryCode'];root=Path(root);exe=root/manifest['entry'];python=manifest['python'];pins={r['path']:r for r in manifest['files']}
 def reject(code,item):
  error=ValueError(code);error.origin_module=item.get('module','');raise error
 if origins['contract']!='portable_python_code_origins_v1' or Path(origins['helperContainer'])!=exe:raise ValueError('helper_origin_container_invalid')
 rows=origins['modules']
 if type(rows) is not list or not 7<=len(rows)<=2048 or len({r['module'] for r in rows})!=len(rows):raise ValueError('helper_origin_modules_invalid')
 required={'__main__','portable_code_origins','portable_helper_package','xhs_page_window','xhs_natural_window','owned_natural_reader','owned_window_sources'}
 if not required.issubset({r['loadedName'] for r in rows}):raise ValueError('helper_origin_required_missing')
 if len({c['path'] for c in origins['containers']})!=len(origins['containers']) or not any(Path(c['path'])==exe for c in origins['containers']):raise ValueError('helper_origin_container_invalid')
 for container in origins['containers']:
  path=Path(container['path'])
  if not path.is_relative_to(root):raise ValueError('helper_origin_container_invalid')
  rel=path.relative_to(root).as_posix();actual,_=hash_file(path)
  if rel not in pins or actual!=pins[rel]['sha256'] or container['sha256']!=actual:raise ValueError('helper_origin_container_changed')
 for item in origins['modules']:
  kind=item['kind'];name=item['module'];digest=item.get('semanticCodeSha256')
  if kind=='pyinstaller_pyz':
   if Path(item['container'])!=exe or item['archiveStartOffset']!=python['pyzStartOffset'] or item['member'] not in expected or digest!=expected[item['member']] or item['loaderName'] not in python['pyzImportNames'].get(item['member'],[]):reject('helper_pyz_code_changed',item)
  elif kind=='pyinstaller_namespace':
   if Path(item['container'])!=exe or item['archiveStartOffset']!=python['pyzStartOffset'] or item['member'] not in python['pyzNamespaces'] or item['loaderName'] not in python['pyzImportNames'].get(item['member'],[]) or digest is not None:reject('helper_namespace_invalid',item)
  elif kind=='pyinstaller_namespace_alias':
   members=[v for v in python['pyzNamespaces'] if item['loadedName'] in python['pyzImportNames'].get(v,[])]
   paths={str(root/'_internal'/Path(*v.split('.'))) for v in members}
   if not members or digest!=python['emptyNamespaceCode'] or not item['namespacePaths'] or set(item['namespacePaths'])-paths or item['moduleFunctionCode']:reject('helper_namespace_alias_invalid',item)
  elif kind=='pyinstaller_entry':
   if name not in ('__main__','__mp_main__') or item['loadedName']!='__main__' or Path(item['container'])!=exe or digest!=entry:reject('helper_entry_code_changed',item)
  elif kind in ('source_file','extension_file'):
   source=Path(item['source']['path'])
   if not source.is_relative_to(root):reject('helper_source_outside_package',item)
   rel=source.relative_to(root).as_posix();pin=pins.get(rel);actual,_=hash_file(source)
   if pin is None or pin['sha256']!=item['source']['sha256'] or actual!=pin['sha256']:reject('helper_source_changed',item)
   if kind=='source_file' and code_digest(compile(source.read_bytes(),str(source),'exec'))!=digest:reject('helper_source_code_changed',item)
  elif kind=='zip_code':
   path=Path(item['container'])
   if not path.is_relative_to(root):reject('helper_zip_outside_package',item)
   rel=path.relative_to(root).as_posix()
   if python['zipCode'].get(rel,{}).get(item['member'])!=digest:reject('helper_zip_code_changed',item)
  elif kind=='pyinstaller_bootstrap_virtual_source':
   pin=python['bootstrapModules'].get(item['member'])
   if Path(item['container'])!=exe or item['member']!=name or pin is None or item.get('sourceFileExists') is not False or item.get('moduleCodeTypeAvailable') is not False:reject('helper_bootstrap_invalid',item)
   if any(d not in pin['functionCodeDigests'] for _,d in item['moduleFunctionCode']):reject('helper_bootstrap_code_changed',item)
  elif kind=='stdlib_frozen':
   if python['stdlibFrozenCode'].get(item['loadedName'])!=digest:reject('helper_stdlib_frozen_changed',item)
  elif kind=='builtin':
   if item['loadedName'] not in python['builtinModules'] or digest is not None:reject('helper_builtin_invalid',item)
  elif kind=='stdlib_typing_alias':
   if name not in ('typing.io','typing.re') or item['declaredFile'] is not None or digest is not None or item['moduleFunctionCode'] or not any(r['module']=='typing' and r['kind']=='pyinstaller_pyz' and r['semanticCodeSha256']==expected.get('typing') for r in origins['modules']):reject('helper_typing_alias_invalid',item)
  elif kind in ('pythonnet_namespace','pythonnet_embedded_python'):
   # Managed namespaces have no Python source/code proof. The original parent
   # must separately validate the actual managed/native assembly origins.
   namespaces={'System','System.Windows','System.Windows.Forms','System.Collections','System.Collections.Generic','System.Diagnostics','System.Drawing','System.Globalization','System.Threading','System.Threading.Tasks','System.Reflection','Microsoft','Microsoft.Win32','Microsoft.Web','Microsoft.Web.WebView2','Microsoft.Web.WebView2.Core','Microsoft.Web.WebView2.WinForms'}
   if digest is not None or not any(r['module']=='pythonnet' and r['kind']=='pyinstaller_pyz' and r['semanticCodeSha256']==expected.get('pythonnet') for r in rows):reject('helper_pythonnet_origin_invalid',item)
   if kind=='pythonnet_namespace' and (name not in namespaces or item['moduleObjectType']!='CLR.ModuleObject' or item['loader']!='clr.loader.DotNetLoader' or item.get('pythonCodeTypeAvailable') is not False):reject('helper_pythonnet_namespace_invalid',item)
   if kind=='pythonnet_namespace' and item['moduleFunctionCode']:reject('helper_pythonnet_namespace_invalid',item)
   if kind=='pythonnet_embedded_python':
    resources={'CLR':'clr.py','clr':'clr.py','clr._extras':'clr.py','clr.interop':'interop.py','clr._extras.collections':'Python.Runtime.Mixins.collections.py','clr._extras.dlr':'Python.Runtime.Mixins.dlr.py'}
    pin=python['pythonnetResources'].get(resources.get(name,''))
    if pin is None or item['moduleObjectType']!='builtins.module' or item['loader']!='builtins.NoneType' or item['declaredFile'] not in (None,'unknown') or item['resource']!=resources[name] or Path(item['container'])!=root/pin['container'] or item.get('moduleCodeTypeAvailable') is not False or any(d not in pin['functionCodeDigests'] for _,d in item['moduleFunctionCode']):reject('helper_pythonnet_embedded_invalid',item)
  else:reject('helper_loader_unapproved',item)
 return True
