"""Transactional durable UID dirty records. Uses the existing records table."""
from datetime import datetime,timezone
import json
from core.customer_intent_materials import scope,digest,source_digest

ENTITY='customer_intent_dirty_v1'

def read_record(db,entity,ident):
    row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,ident)).fetchone()
    return json.loads(row['body']) if row else None

def write_record(db,entity,value):
    # records has a global (entity,id) PK. Never let a preplaced/corrupt key
    # replace a different tenant or owner, including derived scope collisions.
    tenant=value.get('tenant_id');owner=value.get('owner',value.get('cloud_owner'))
    if not isinstance(tenant,str) or not tenant or not isinstance(value.get('id'),str):
        raise ValueError('derived_record_identity_invalid')
    old=db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',
        (entity,value['id'])).fetchone()
    if old:
        previous=json.loads(old['body'])
        if (old['tenant_id']!=tenant or previous.get('tenant_id')!=tenant or
                previous.get('id')!=value['id'] or
                previous.get('owner',previous.get('cloud_owner'))!=owner):
            raise ValueError('derived_record_foreign_scope')
        for field in ('store_id','platform','customer_id','scope'):
            if field in previous and field in value and previous[field]!=value[field]:
                raise ValueError('derived_record_scope_changed')
    if entity==ENTITY:
        value_scope=value.get('scope')
        if (not isinstance(value_scope,dict) or value_scope.get('tenant_id')!=tenant
                or value_scope.get('owner')!=owner or key(value_scope)!=value['id']):
            raise ValueError('dirty_scope_identity_invalid')
    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
        (entity,value['id'],value['tenant_id'],json.dumps(value,ensure_ascii=False)))

def key(value):return digest([ENTITY,value])

def mark_scope(db,value,reason='source_changed'):
    if value is None:return None
    ident=key(value);old=read_record(db,ENTITY,ident) or {}
    row={'id':ident,'tenant_id':value['tenant_id'],'owner':value['owner'],'scope':value,
        'generation':old.get('generation',0)+1,
        'state':'pending' if value.get('uid') else 'needs_materials','reason':reason,
        'updated_at':datetime.now(timezone.utc).isoformat()}
    write_record(db,ENTITY,row);return row

def mark_lead(db,lead,reason='source_changed',task=None):
    task=task if task is not None else read_record(db,'tasks',lead.get('task_id')) or {}
    return mark_scope(db,scope(lead,task),reason)

def mark_change(db,entity,before,after):
    if entity=='leads':
        task=read_record(db,'tasks',(after or before).get('task_id')) or {}
        if before is not None and after is not None:
            old_task=read_record(db,'tasks',before.get('task_id')) or {}
            if (source_digest(before,old_task)==source_digest(after,task) and
                    before.get('ai_intent')==after.get('ai_intent') and
                    before.get('manual_intent')==after.get('manual_intent') and
                    before.get('analysis_status')==after.get('analysis_status')):return
        scopes={}
        for lead in (before,after):
            if lead:
                value=scope(lead,read_record(db,'tasks',lead.get('task_id')) or {})
                if value:scopes[key(value)]=value
        for value in scopes.values():mark_scope(db,value)
    elif entity in ('tasks','intent_rule_policies') and before!=after:
        row=after or before
        for record in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',('leads',row['tenant_id'])).fetchall():
            lead=json.loads(record['body'])
            if entity=='tasks':
                if lead.get('task_id')!=row['id']:continue
                if before is not None and after is not None and source_digest(lead,before)==source_digest(lead,after):continue
                for task in (before,after):
                    if task:mark_lead(db,lead,task=task)
            elif lead.get('cloud_owner')==row.get('owner'):mark_lead(db,lead,'policy_changed')
