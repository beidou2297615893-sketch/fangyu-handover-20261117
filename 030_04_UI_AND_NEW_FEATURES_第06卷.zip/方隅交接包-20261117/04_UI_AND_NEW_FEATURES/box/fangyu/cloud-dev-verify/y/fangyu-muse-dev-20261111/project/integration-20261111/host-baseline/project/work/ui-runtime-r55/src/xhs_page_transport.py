"""Disabled-by-default, account-scoped IPC for an owned XHS page helper.

The opt-in source caller owns account/profile locks and supplies the existing
safety guard; the route remains disabled by default. Page read methods originate from
Yht20927/xiaohongshu-cli 5c0159768147b4151d4912c083863a23bbbebb7a
(MIT); this transport never accepts arbitrary JavaScript expressions.
"""

from __future__ import annotations

import hmac
import json
import os
import re
import secrets
import stat
import sys
import threading
import time
from contextlib import nullcontext
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from assistant.owned_native_job import WindowsOwnedJobProcess, OwnedSetupPending


_ACTIONS = frozenset(("status", "search", "comments", "sub_comments"))
_MAX_BODY = 4 * 1024 * 1024
_BEFORE_NETWORK = frozenset(("page_client_unavailable", "origin_invalid", "action_denied", "invalid_request"))
_AFTER_NETWORK = frozenset(("axios_rejected", "invalid_response", "response_oversize"))
_NATURAL_FAILURES = frozenset(('pagination_unknown', 'pagination_unavailable',
    'document_changed', 'timeout', 'invalid_response', 'not_authenticated',
    'identity_mismatch', 'verification_required', 'body_unavailable',
    'body_stale', 'response_scope_invalid', 'request_scope_invalid',
    'comment_scroll_unavailable', 'search_scroll_unavailable', 'cancelled'))


class PageTransportError(RuntimeError):
    def __init__(self, code: str, network_attempted=False):
        self.code = code
        self.network_attempted = bool(network_attempted)
        super().__init__(code)


def _text(value, limit=256):
    return isinstance(value, str) and 0 < len(value) <= limit


def _safe_path(path: Path):
    """Refuse existing reparse/symlink ancestors before creating private job data."""
    for part in (path, *path.parents):
        if not part.exists() and not part.is_symlink():
            continue
        flags = part.lstat().st_file_attributes if os.name == "nt" else 0
        if part.is_symlink() or flags & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
            raise PageTransportError("unsafe_path")


def _platform_code(envelope):
    if not isinstance(envelope, dict):
        return "invalid_result"
    values = [envelope.get("status"), envelope.get("_http_status"), envelope.get("code")]
    inner = envelope.get("data")
    if isinstance(inner, dict):
        values += [inner.get("status"), inner.get("_http_status"), inner.get("code")]
    if any(value in (401, -100) for value in values if type(value) is int):
        return "not_authenticated"
    if any(value in (461, 471, -461, -471) for value in values if type(value) is int):
        return "verification_required"
    page_error = envelope.get("_page_error")
    if page_error is None and isinstance(inner, dict):
        page_error = inner.get("_page_error")
    if page_error is not None:
        return page_error if isinstance(page_error, str) and page_error in _BEFORE_NETWORK | _AFTER_NETWORK else "page_rejected"
    if envelope.get("success") is False or (isinstance(inner, dict) and inner.get("success") is False) or any(
        type(value) is int and (value >= 400 or value < 0)
        for value in (envelope.get("status"), envelope.get("_http_status"))
    ):
        return "platform_rejected"
    if type(envelope.get("code")) is int and envelope["code"] != 0:
        return "platform_rejected"
    return ""


def _profile_uid(envelope):
    if not isinstance(envelope, dict):
        return ""
    candidates = [envelope]
    payload = envelope
    for _ in range(3):
        payload = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(payload, dict):
            break
        candidates.append(payload)
    for parent in tuple(candidates):
        for key in ("user", "user_info", "basic_info"):
            if isinstance(parent.get(key), dict):
                candidates.append(parent[key])
    for candidate in candidates:
        if _text(candidate.get("user_id")):
            return candidate["user_id"]
    return ""


def _profile_guest(envelope):
    candidates = [envelope]
    payload = envelope
    for _ in range(3):
        payload = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(payload, dict):
            break
        candidates.append(payload)
    for parent in tuple(candidates):
        for key in ("user", "user_info", "basic_info"):
            if isinstance(parent.get(key), dict):
                candidates.append(parent[key])
    return any(candidate[key] is not False for candidate in candidates
               for key in ("guest", "is_guest") if key in candidate)


def _natural_identity_error(envelope, bound_uid, *, identity_observation=False):
    """Natural getMe needs an explicit non-guest, unambiguous bound identity.

    Legacy page status keeps its existing parsing behavior. Only the opt-in
    natural path calls this stricter check.
    """
    if not isinstance(envelope, dict):
        return "identity_mismatch"
    candidates = [envelope]
    payload = envelope
    for _ in range(3):
        payload = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(payload, dict):
            break
        candidates.append(payload)
    for parent in tuple(candidates):
        for key in ("user", "user_info", "basic_info"):
            if isinstance(parent.get(key), dict):
                candidates.append(parent[key])
    guests = [candidate[key] for candidate in candidates
              for key in ("guest", "is_guest") if key in candidate]
    if not guests or any(value is not False for value in guests):
        return "not_authenticated"
    identities = [candidate["user_id"] for candidate in candidates
                  if "user_id" in candidate]
    if (not identities or any(not _text(uid) for uid in identities) or
            (len(set(identities)) != 1 if identity_observation else set(identities) != {bound_uid})
            or identity_observation and any(not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', uid) for uid in identities)):
        return "identity_mismatch"
    return ""


def _identity_observation_profile(envelope):
    """Project only an explicit, unique non-guest getMe identity, never ready."""
    error=_platform_code(envelope) or _natural_identity_error(envelope,'',identity_observation=True)
    if error:raise PageTransportError(error)
    candidates=[envelope]
    payload=envelope
    for _ in range(3):
        payload=payload.get('data') if isinstance(payload,dict) else None
        if not isinstance(payload,dict):break
        candidates.append(payload)
    for parent in tuple(candidates):
        for key in ('user','user_info','basic_info'):
            if isinstance(parent.get(key),dict):candidates.append(parent[key])
    nickname=next((value for item in candidates for value in
        (item.get('nickname'),item.get('nick_name')) if isinstance(value,str) and 0<len(value)<=160
        and not any(ord(char)<32 or ord(char)==127 for char in value)),None)
    if nickname is None:raise PageTransportError('invalid_result')
    return {'id':_profile_uid(envelope),'nickname':nickname,'guest':False}


def _page_payload(envelope):
    current = envelope
    for _ in range(4):
        if not isinstance(current, dict):
            return None
        if "items" in current or "comments" in current:
            return current
        current = current.get("data")
    return None


def _page_shape_code(action, envelope, *, natural_mode=False):
    if action == "status":
        return ""
    if action == 'search' and isinstance(envelope,dict) and envelope.get('_transport') == 'natural_dom':
        if not natural_mode:return 'invalid_response'
        try:
            from xhs_natural_search import validate_result
            validate_result(envelope)
            return ''
        except (ValueError,TypeError):return 'invalid_response'
    payload = _page_payload(envelope)
    key = "items" if action == "search" else "comments"
    if not isinstance(payload, dict) or not isinstance(payload.get(key), list) or type(payload.get("has_more")) is not bool:
        return "invalid_response"
    if action != "search" and payload["has_more"] and not _text(payload.get("cursor"), 2048):
        return "invalid_response"
    return ""


def _reject_constant(_value):
    raise ValueError("nonfinite_json")


class _State:
    def __init__(self, secret, scope):
        self.cv = threading.Condition()
        self.bootstrap_secret = secret
        self.bootstrap_request = None
        self.bootstrap_approved = False
        self.bootstrap_denied = False
        self.session_token = None
        self.scope = scope
        self.doc_epoch = None
        self.invalidated = False
        self.connected = False
        self.ready_facts = None
        self.stopping = False
        self.poisoned = False
        self.hold_reason = ""
        self.uid_verified = False
        self.pending = None
        self.used_call_ids = set()
        self.task_epoch_counter = 0


class XhsPageTransport:
    """One owned helper process and one in-flight page request per account."""

    def __init__(self, account_dir, tenant_id, account_id, bound_uid, guard, helper_factory,
                 *, connect_timeout=30.0, call_timeout=60.0, natural_mode=False,
                 identity_observation=False, _session_scope=None):
        from assistant.xhs_session_scope import _SessionScope
        if _session_scope is not None and type(_session_scope) is not _SessionScope:
            raise PageTransportError('invalid_scope')
        recovery=_session_scope is not None
        self.account_dir = Path(account_dir).absolute()
        if (not all(_text(v) for v in (tenant_id, account_id)) or
                not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", tenant_id) or
                not re.fullmatch(r"[a-f0-9]{32}", account_id) or
                not isinstance(bound_uid,str) or not (re.fullmatch(r"[A-Za-z0-9_-]{1,128}", bound_uid)
                    or (identity_observation is True or recovery) and bound_uid=='') or
                self.account_dir.name != account_id or self.account_dir.parent.name != tenant_id or
                self.account_dir.parent.parent.name != "accounts" or
                not callable(guard) or not callable(helper_factory) or
                not (0 < connect_timeout <= 60) or not (0 < call_timeout <= 120) or
                type(natural_mode) is not bool or type(identity_observation) is not bool
                or (identity_observation or recovery) and not natural_mode
                or recovery and (identity_observation or _session_scope.root!=self.account_dir
                    or _session_scope.tenant!=tenant_id or _session_scope.account_id!=account_id)):
            raise PageTransportError('invalid_scope')
        if recovery:
            _session_scope.check()
        _safe_path(self.account_dir)
        self.scope = {"tenant_id": tenant_id, "account_id": account_id, "bound_uid": bound_uid}
        self.guard = guard
        self.helper_factory = helper_factory
        self.connect_timeout = connect_timeout
        self.call_timeout = call_timeout
        self.natural_mode = natural_mode
        self.identity_observation = identity_observation
        self.session_scope = _session_scope
        if identity_observation:self.scope['purpose']='identity_observation'
        self.job_dir = self.account_dir / "work" / "xhs-page-bridge" / secrets.token_hex(12)
        if recovery:
            self.scope['purpose']='session_recovery'
            self.job_dir=self.job_dir.parent/_session_scope.task_id
        self.spec_path = self.job_dir / "spec.json"
        self.cancel_file = self.job_dir / "cancel.flag"
        self.profile_dir = self.account_dir / "xhs-browser-profile"
        self.state = _State(secrets.token_urlsafe(48), self.scope)
        self.server = None
        self.server_thread = None
        self.process = None
        self.ready_guard = None
        self.owner_thread = None
        self.setup_pending = False
        self.cleanup_completed = set()
        self.cleanup_reason = ""
        self.opened = False
        self.closed = False
        # Fixed facts only. Never copy helper stdout, platform bodies or URLs.
        self.last_failure_diagnostic = None

    @property
    def server_endpoint(self):
        if self.server is None:
            raise PageTransportError("invalid_state")
        return f"http://127.0.0.1:{self.server.server_port}"

    def _guard(self, event, action="status", call_id="open", outcome="", network_attempted=False):
        context = {**self.scope, "action": action, "call_id": call_id, "outcome": outcome,
                   "code": outcome, "network_attempted": bool(network_attempted)}
        if (event == 'after_result' and outcome != 'ok' and self.natural_mode and
                self.last_failure_diagnostic is not None):
            context['diagnostic'] = dict(self.last_failure_diagnostic)
        try:
            if self.guard(event, context) is False:
                raise PageTransportError("guard_rejected")
        except Exception:
            self.state.poisoned = True
            raise PageTransportError("guard_rejected") from None

    def open(self):
        if self.opened or self.closed:
            raise PageTransportError("invalid_state")
        self._guard("before_open", "status", "open")
        self.owner_thread = threading.current_thread()
        _safe_path(self.job_dir.parent)
        _safe_path(self.profile_dir)
        self.job_dir.mkdir(parents=True, exist_ok=False)
        _safe_path(self.job_dir)
        try:
            self.server = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        except Exception:
            self.job_dir.rmdir()
            self.closed = True
            raise PageTransportError("ipc_start_failed") from None
        self.server.daemon_threads = True
        endpoint = f"http://127.0.0.1:{self.server.server_port}"
        spec = {
            "version": 1, "endpoint": endpoint, "bootstrap_secret": self.state.bootstrap_secret,
            **self.scope, "profile_dir": str(self.profile_dir), "cancel_file": str(self.cancel_file),
        }
        if self.natural_mode:
            spec.update(version=2, read_mode='natural')
        if self.identity_observation:
            spec.update(version=3,purpose='identity_observation')
        if self.session_scope is not None:
            spec.update(version=4,purpose='session_recovery')
        try:
            descriptor = os.open(self.spec_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                json.dump(spec, stream, ensure_ascii=False, separators=(",", ":"))
        except Exception:
            self.spec_path.unlink(missing_ok=True)
            self.server.server_close()
            try:
                self.job_dir.rmdir()
            except OSError:
                pass
            self.closed = True
            raise PageTransportError("spec_failed") from None
        self.server_thread = threading.Thread(target=self.server.serve_forever, name="xhs-page-ipc", daemon=True)
        self.server_thread.start()
        try:
            self.process = self.helper_factory(self.spec_path)
        except Exception as exc:
            from assistant.owned_xhs_native.ready import _ReadySetupPending, _ReadyGuard
            if type(exc) is _ReadySetupPending:
                if type(exc.guard) is not _ReadyGuard or exc.guard.process is not None:
                    raise
                self.ready_guard = exc.guard
                self.setup_pending = self.opened = self.state.poisoned = True
                raise PageTransportError('owned_ready_setup_pending') from None
            if isinstance(exc, OwnedSetupPending):
                self.process = exc.process
                self.setup_pending = True
                self.opened = True
                self.state.poisoned = True
                raise PageTransportError('owned_setup_pending') from None
            self.state.poisoned = True
            self.server.shutdown()
            self.server.server_close()
            self.server_thread.join(timeout=2)
            self.spec_path.unlink(missing_ok=True)
            try:
                self.job_dir.rmdir()
            except OSError:
                pass
            self.closed = True
            raise PageTransportError('helper_start_failed') from None
        self.opened = True
        if type(self.process) is not WindowsOwnedJobProcess:
            self.state.poisoned = True
            raise PageTransportError("owned_process_required")
        try:
            deadline = time.monotonic() + self.connect_timeout
            while True:
                # Native/process checks run on the original owner thread,
                # outside the IPC condition and original Store/Core locks.
                self._complete_bootstrap()
                with self.state.cv:
                    if self.state.bootstrap_denied:
                        raise PageTransportError("bootstrap_denied")
                    if self.state.connected:
                        facts = self.state.ready_facts
                        self.state.ready_facts = None
                        break
                    if self.state.stopping:
                        raise PageTransportError("cancelled")
                    return_code = self.process.poll()
                    if return_code is not None:
                        self.state.poisoned = True
                        self.last_failure_diagnostic = {
                            'stage': 'connect',
                            'return_code': return_code if type(return_code) is int else None,
                            'failure_received': False, 'failure_code': '',
                            'doc_epoch': self.state.doc_epoch,
                            'task_epoch': None, 'phase': 'connecting'}
                        raise PageTransportError("helper_exited")
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        self.state.poisoned = True
                        raise PageTransportError("connect_timeout")
                    self.state.cv.wait(min(remaining, 0.1))
            if self.natural_mode:
                from assistant.owned_xhs_native.ready import _ReadyGuard
                gate = getattr(self.process, '_page_ready_guard', None)
                if type(gate) is not _ReadyGuard or gate.process is not self.process:
                    raise PageTransportError('ready_guard_required')
                self.ready_guard = gate
                if gate.bootstrap_required and not self.state.bootstrap_approved:
                    raise PageTransportError('bootstrap_denied')
                try:
                    gate.verify(facts)
                except Exception:
                    self.state.poisoned = True
                    raise PageTransportError('ready_guard_rejected') from None
            if self.session_scope is not None:
                return self._run_session_recovery()
            return self.call("status", call_id="open")
        except PageTransportError as error:
            if error.code == "verification_required":
                raise  # Keep owned page visible for explicit human verification.
            try:
                self.close(timeout=2)
            except PageTransportError:
                pass  # Still poisoned and closable when the helper remains alive.
            raise

    def call(self, action, *, call_id, keyword=None, page=None, note_id=None, cursor="", root_comment_id=None,
             source_token=None, xsec_source=None, note_url=None, range_checkpoint=None):
        if self.session_scope is not None or action not in _ACTIONS or self.identity_observation and action != 'status':
            raise PageTransportError("action_denied")
        if not _text(call_id, 100):
            raise PageTransportError("invalid_call_id")
        if action == "search":
            if not _text(keyword, 200) or type(page) is not int or not 1 <= page <= 2**53 - 1:
                raise PageTransportError("invalid_request")
            params = {"keyword": keyword, "page": page}
            if range_checkpoint is not None:
                if not self.natural_mode:raise PageTransportError('invalid_request')
                try:
                    from xhs_natural_search import validate_range
                    validate_range(range_checkpoint,keyword=keyword)
                except (ValueError,TypeError):raise PageTransportError('invalid_request') from None
                params['rangeCheckpoint'] = range_checkpoint['checkpoint']
        elif action in ("comments", "sub_comments"):
            if not _text(note_id) or not isinstance(cursor, str) or len(cursor) > 2048 or (
                action == "sub_comments" and not _text(root_comment_id)
            ) or not _text(source_token, 2048) or xsec_source not in (
                ("", "pc_search", "pc_note", "pc_user", "pc_feed") if self.natural_mode
                else ("pc_search", "pc_note", "pc_user", "pc_feed")
            ):
                raise PageTransportError("invalid_request")
            params = {"noteId": note_id, "cursor": cursor, "token": source_token}
            if self.natural_mode:
                # The native route must preserve the observed source pair;
                # legacy axios commands keep their exact existing schema.
                params["source"] = xsec_source
                if note_url is not None:
                    from urllib.parse import parse_qs
                    try:
                        parsed = urlsplit(note_url)
                        query = parse_qs(parsed.query, keep_blank_values=True, max_num_fields=16)
                        if (not isinstance(note_url, str) or len(note_url) > 8192
                                or parsed.scheme != 'https' or parsed.hostname != 'www.xiaohongshu.com'
                                or parsed.port not in (None, 443) or parsed.username or parsed.password
                                or parsed.fragment or not re.fullmatch(
                                    r'/(?:explore|search_result)/' + re.escape(note_id) + r'/?', parsed.path)
                                or query.get('xsec_token') != [source_token]
                                or query.get('xsec_source', ['']) != [xsec_source]
                                or any(len(k) > 64 or len(v) != 1 or len(v[0]) > 2048
                                       for k, v in query.items())):
                            raise ValueError
                    except (ValueError, TypeError):
                        raise PageTransportError('invalid_request') from None
                    params['noteUrl'] = note_url
            if action == "sub_comments":
                params["rootCommentId"] = root_comment_id
        else:
            params = {}
        if not self.opened or self.closed:
            raise PageTransportError("invalid_state")
        outcome = "guard_rejected"
        network_attempted = False
        started = False
        self.last_failure_diagnostic = None
        try:
            self._guard("before_call", action, call_id)
            started = True
            envelope = self._run_page(action, call_id, params, note_id, source_token, xsec_source)
            outcome = "ok"
            network_attempted = True
            return envelope
        except PageTransportError as error:
            outcome = error.code
            network_attempted = error.network_attempted
            raise
        finally:
            if started:
                self._guard("after_result", action, call_id, outcome, network_attempted)

    def _run_page(self, action, call_id, params, note_id, source_token, xsec_source):
        state = self.state
        gate = self.ready_guard
        if self.natural_mode:
            from assistant.owned_xhs_native.ready import _ReadyGuard
            if type(gate) is not _ReadyGuard or gate.process is not self.process:
                raise PageTransportError('ready_guard_required')
        try:
            with gate.issue() if gate is not None else nullcontext():
                with state.cv:
                    if state.poisoned or state.stopping:
                        raise PageTransportError("paused")
                    if state.invalidated or not state.connected:
                        raise PageTransportError("document_changed")
                    if action != "status" and not state.uid_verified:
                        raise PageTransportError("identity_unverified")
                    if state.pending is not None:
                        raise PageTransportError("busy")
                    if call_id in state.used_call_ids:
                        raise PageTransportError("replay_denied")
                    if action in ("comments", "sub_comments"):
                        source_pair = (source_token, xsec_source)
                        sources = getattr(state, "sources", None)
                        if sources is None:
                            state.sources = sources = {}
                        if note_id in sources and sources[note_id] != source_pair and not (
                                self.natural_mode and params.get('noteUrl')):
                            raise PageTransportError("source_mismatch")
                        sources[note_id] = source_pair
                    state.used_call_ids.add(call_id)
                    state.task_epoch_counter += 1
                    state.pending = {"action": action, "call_id": call_id, "params": params,
                                     "doc_epoch": state.doc_epoch, "delivered": False,
                                     "result": None, "error": None,
                                     "task_epoch": state.task_epoch_counter,
                                     "phase": "issued", "route_kind": "",
                                     "identity_verified": state.uid_verified,
                                     "network_attempted": False,
                                     "failure_received": False}
                    pending = state.pending
                    state.cv.notify_all()
        except PageTransportError:
            raise
        except Exception:
            state.poisoned = True
            raise PageTransportError('ready_guard_rejected') from None
        # IPC completion wait holds only its original condition, never Core or
        # runtime locks. Original cancellation can now stop the owned helper.
        with state.cv:
            deadline = time.monotonic() + self.call_timeout
            helper_return_code = None
            while pending["result"] is None and pending["error"] is None:
                return_code = self.process.poll()
                if return_code is not None:
                    pending["error"] = "helper_exited"
                    helper_return_code = return_code if type(return_code) is int else None
                else:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        pending["error"] = "timeout"
                    else:
                        state.cv.wait(min(remaining, 0.1))
            error = pending["error"]
            envelope = pending["result"]
            state.pending = None
            if error:
                state.poisoned = error != "document_changed" or pending["delivered"]
            else:
                error = _platform_code(envelope)
                if not error:
                    error = _page_shape_code(action, envelope, natural_mode=self.natural_mode)
                if error:
                    state.poisoned = True
                    if error == "verification_required":
                        state.hold_reason = error
                elif action == "status":
                    if self.natural_mode:
                        error = _natural_identity_error(envelope, self.scope["bound_uid"],
                            identity_observation=self.identity_observation)
                    elif _profile_guest(envelope):
                        error = "not_authenticated"
                    elif _profile_uid(envelope) != self.scope["bound_uid"]:
                        error = "identity_mismatch"
                    if error:
                        state.poisoned = True
                    else:
                        state.uid_verified = True
            if error and self.natural_mode:
                self.last_failure_diagnostic = {
                    'stage': 'call', 'return_code': helper_return_code,
                    'failure_received': pending['failure_received'],
                    'failure_code': (pending['error'] if pending['failure_received'] and
                                     pending['error'] in _NATURAL_FAILURES else ''),
                    'doc_epoch': state.doc_epoch,
                    'task_epoch': pending['task_epoch'], 'phase': pending['phase']}
        if error:
            attempted = (pending["network_attempted"] if self.natural_mode
                         else bool(pending["delivered"]))
            if error in _BEFORE_NETWORK:
                attempted = False
            elif error in _AFTER_NETWORK or error in ("verification_required", "not_authenticated"):
                attempted = True
            raise PageTransportError(error, attempted)
        return envelope

    def request_stop(self):
        """Signal cancellation without waiting for the owned helper or profile lock."""
        if self.closed:
            return "already_closed"
        if not self.opened:
            return "not_open"
        with self.state.cv:
            self.state.stopping = True
            self.state.poisoned = True
            if self.state.pending and self.state.pending["error"] is None:
                self.state.pending["error"] = "cancelled"
            self.state.cv.notify_all()
        try:
            _safe_path(self.job_dir)
            _safe_path(self.cancel_file)
            self.cancel_file.touch(exist_ok=True)
        except Exception:
            return "marker_failed"
        return "requested"

    def close(self, timeout=30.0):
        """Cooperatively stop; retain poisoned IPC if the real helper remains alive."""
        if self.closed:
            return
        from assistant.owned_xhs_native.ready import _ReadyGuard
        files_only = (self.process is None and type(self.ready_guard) is _ReadyGuard
                      and self.ready_guard.process is None and self.setup_pending)
        if (not self.opened or threading.current_thread() is not self.owner_thread
                or not files_only and type(self.process) is not WindowsOwnedJobProcess):
            raise PageTransportError("owned_shutdown_required")
        try:
            if files_only:
                self.ready_guard.abort_before_process()
            else:
                if self.process.closed is not True:
                    self.request_stop()
                    if not self.setup_pending:
                        self.process.wait(timeout=timeout)
                    self.process.close()
                if (self.process.closed is not True or self.process.process is not None
                        or self.process.job is not None):
                    raise RuntimeError("owned_exit_unconfirmed")
                gate = getattr(self.process, '_page_ready_guard', None)
                if gate is not None:
                    if type(gate) is not _ReadyGuard or gate.process is not self.process:
                        raise RuntimeError('owned_ready_cleanup_unconfirmed')
                    gate.close_after_process()
        except Exception:
            raise PageTransportError("helper_alive") from None
        # Job exit is confirmed above. Independent safe cleanup still runs when
        # another item fails; only this owning thread retries incomplete items.
        self.cleanup_reason = "cleanup_unconfirmed"
        def complete(name, cleanup):
            if name in self.cleanup_completed:
                return
            try:
                cleanup()
            except Exception:
                return
            self.cleanup_completed.add(name)

        def join_server():
            self.server_thread.join(timeout=2)
            if self.server_thread.is_alive():
                raise RuntimeError("cleanup_unconfirmed")

        def remove(path):
            _safe_path(self.job_dir)
            _safe_path(path)
            path.unlink(missing_ok=True)

        def remove_directory():
            _safe_path(self.job_dir)
            self.job_dir.rmdir()

        complete("server_shutdown", self.server.shutdown)
        complete("server_close", self.server.server_close)
        complete("server_thread", join_server)
        complete("cancel_file", lambda: remove(self.cancel_file))
        ipc_confirmed = {"server_shutdown", "server_close", "server_thread"} <= self.cleanup_completed
        if ipc_confirmed:
            # Retain this exact spec while any IPC cleanup remains uncertain.
            complete("spec_file", lambda: remove(self.spec_path))
        if {"spec_file", "cancel_file"} <= self.cleanup_completed:
            complete("job_directory", remove_directory)
        if len(self.cleanup_completed) != 6:
            raise PageTransportError("cleanup_unconfirmed")
        self.cleanup_reason = ""
        self.closed = True

    cancel = close

    def _complete_bootstrap(self):
        state = self.state
        with state.cv:
            body = state.bootstrap_request
            if body is None or state.bootstrap_approved or state.bootstrap_denied:
                return
        from assistant.owned_xhs_native.ready import _ReadyGuard
        gate = getattr(self.process, '_page_ready_guard', None)
        approved = False
        try:
            if (self.owner_thread is not threading.current_thread() or not self.natural_mode
                    or not getattr(sys, 'frozen', False) or type(gate) is not _ReadyGuard
                    or gate.process is not self.process or not gate.bootstrap_required):
                raise PageTransportError('bootstrap_denied')
            self.ready_guard = gate
            gate.bootstrap(body)
            approved = True
        except Exception:
            approved = False
        with state.cv:
            # Same original request must still own this only bootstrap turn.
            if state.bootstrap_request is not body or state.stopping or state.poisoned:
                approved = False
            state.bootstrap_approved = approved
            state.bootstrap_denied = not approved
            if not approved:
                state.poisoned = True
            state.cv.notify_all()

    def _handler(self):
        transport = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def do_POST(self):
                path = urlsplit(self.path).path
                allowed = path in (
                    "/bootstrap", "/connect", "/poll", "/result", "/invalidate", "/rebind",
                    "/begin_navigation", "/identity", "/failure")
                if not allowed and path in ("/session_current", "/session_result"):
                    from assistant.xhs_session_transport import SessionRecoveryTransport
                    from assistant.xhs_session_scope import _SessionScope
                    scope = transport.session_scope
                    allowed = (type(transport) is SessionRecoveryTransport
                        and type(scope) is _SessionScope and scope.entered and not scope.finished
                        and scope.root == transport.account_dir
                        and scope.tenant == transport.scope.get('tenant_id')
                        and scope.account_id == transport.scope.get('account_id')
                        and transport.scope.get('purpose') == 'session_recovery'
                        and scope.runtime.jobs.get(scope.task_id) is scope
                        and scope.entry is not None and scope.entry.batch_scope is scope
                        and scope.entry.transport is transport)
                if self.client_address[0] != "127.0.0.1" or not allowed:
                    return self._send(404, {"ok": False, "code": "not_found"})
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                    if not 0 < size <= _MAX_BODY:
                        return self._send(400, {"ok": False, "code": "invalid_request"})
                    body = json.loads(self.rfile.read(size), parse_constant=_reject_constant)
                    if not isinstance(body, dict):
                        raise ValueError()
                except Exception:
                    return self._send(400, {"ok": False, "code": "invalid_request"})
                try:
                    result = transport._ipc(path, body)
                except PageTransportError as error:
                    status = 503 if path == '/bootstrap' and error.code == 'parent_bind_pending' else 403
                    return self._send(status, {"ok": False, "code": error.code})
                self._send(200, {"ok": True, **result})

            def _send(self, status, payload):
                data = json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        return Handler

    def _ipc(self, path, body):
        state = self.state
        with state.cv:
            if path == "/bootstrap":
                expected = {'contract', 'secret', 'tenant_id', 'account_id', 'bound_uid',
                    'purpose', 'helper_pid', 'helper_created', 'spec_sha256'}
                if (not self.natural_mode or not getattr(sys, 'frozen', False)
                        or state.connected or state.stopping or state.poisoned
                        or set(body) != expected
                        or body.get('contract') != 'owned_xhs_helper_bootstrap_v1'
                        or type(body.get('secret')) is not str
                        or not hmac.compare_digest(body['secret'], state.bootstrap_secret)
                        or any(body.get(key) != value for key, value in self.scope.items())
                        or body.get('purpose') != self.scope.get('purpose', 'collection_read')
                        or type(body.get('helper_pid')) is not int or not 1 <= body['helper_pid'] <= 0xffffffff
                        or type(body.get('helper_created')) is not int or not 1 <= body['helper_created'] <= 0xffffffffffffffff
                        or type(body.get('spec_sha256')) is not str
                        or re.fullmatch('[0-9a-f]{64}', body['spec_sha256']) is None):
                    raise PageTransportError('bootstrap_denied')
                if state.bootstrap_request is None:
                    state.bootstrap_request = dict(body)
                    state.cv.notify_all()
                elif state.bootstrap_request != body:
                    raise PageTransportError('bootstrap_denied')
                deadline = time.monotonic() + 10
                while not state.bootstrap_approved:
                    if state.bootstrap_denied or state.stopping or state.poisoned:
                        raise PageTransportError('bootstrap_denied')
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise PageTransportError('parent_bind_pending')
                    state.cv.wait(min(remaining, .1))
                return {'contract': 'owned_xhs_helper_bootstrap_v1', 'authorized': True}
            if path == "/connect":
                if self.natural_mode and getattr(sys, "frozen", False) and not state.bootstrap_approved:
                    raise PageTransportError("bootstrap_denied")
                if state.connected or state.stopping or state.poisoned or type(body.get("doc_epoch")) is not int or body["doc_epoch"] < 1:
                    raise PageTransportError("connect_denied")
                if not hmac.compare_digest(str(body.get("secret", "")), state.bootstrap_secret) or any(
                    body.get(key) != value for key, value in self.scope.items()
                ):
                    raise PageTransportError("scope_mismatch")
                state.connected = True
                state.ready_facts = body.get('runtime_facts') if self.natural_mode else None
                state.doc_epoch = body["doc_epoch"]
                state.session_token = secrets.token_urlsafe(48)
                state.bootstrap_secret = ""
                state.cv.notify_all()
                return {"session_token": state.session_token}
            if not state.connected or not hmac.compare_digest(str(body.get("session_token", "")), state.session_token):
                raise PageTransportError("session_denied")
            pending = state.pending
            if path == '/failure':
                if (not self.natural_mode or state.stopping or state.poisoned or
                        pending is None or not pending['delivered'] or
                        (state.invalidated and pending['phase'] != 'invalidated') or
                        pending['error'] is not None or pending['result'] is not None or
                        body.get('doc_epoch') != state.doc_epoch or
                        body.get('call_id') != pending['call_id'] or
                        type(body.get('task_epoch')) is not int or
                        body['task_epoch'] != pending['task_epoch'] or
                        body.get('code') not in _NATURAL_FAILURES or
                        type(body.get('network_attempted')) is not bool):
                    raise PageTransportError('failure_denied')
                pending['error'] = body['code']
                pending['failure_received'] = True
                pending['network_attempted'] |= body['network_attempted']
                state.poisoned = True
                if body['code'] == 'verification_required':
                    state.hold_reason = 'verification_required'
                state.cv.notify_all()
                return {}
            if path == "/begin_navigation":
                route_for = {"status": "home", "search": "search",
                             "comments": "note", "sub_comments": "note"}
                if (not self.natural_mode or state.stopping or state.poisoned or state.invalidated or
                    pending is None or pending["error"] is not None or pending["result"] is not None or
                    not pending["delivered"] or pending["phase"] != "issued" or
                    body.get("doc_epoch") != state.doc_epoch or
                    body.get("call_id") != pending["call_id"] or
                    type(body.get("task_epoch")) is not int or
                    body["task_epoch"] != pending["task_epoch"] or
                    body.get("route_kind") != route_for[pending["action"]]):
                    raise PageTransportError("navigation_denied")
                pending["phase"] = "navigating"
                pending["route_kind"] = body["route_kind"]
                return {}
            if path == "/rebind":
                planned = (self.natural_mode and pending is not None and
                           pending["phase"] == "invalidated" and pending["error"] is None and
                           pending["result"] is None and pending["delivered"] and
                           body.get("call_id") == pending["call_id"] and
                           type(body.get("task_epoch")) is int and
                           body["task_epoch"] == pending["task_epoch"])
                if (not state.invalidated or (self.natural_mode and not planned) or
                    (pending is not None and not planned) or
                    body.get("old_epoch") != state.doc_epoch or
                    type(body.get("new_epoch")) is not int or
                    body["new_epoch"] <= state.doc_epoch or state.poisoned):
                    raise PageTransportError("rebind_denied")
                state.doc_epoch = body["new_epoch"]
                state.invalidated = False
                state.uid_verified = False
                if planned:
                    pending["doc_epoch"] = state.doc_epoch
                    pending["phase"] = "observing"
                    pending["identity_verified"] = False
                return {}
            if body.get("doc_epoch") != state.doc_epoch:
                raise PageTransportError("document_changed")
            if path == "/invalidate":
                state.invalidated = True
                state.uid_verified = False
                planned = (self.natural_mode and pending is not None and
                           pending["phase"] == "navigating" and
                           pending["error"] is None and pending["result"] is None and
                           body.get("call_id") == pending["call_id"] and
                           type(body.get("task_epoch")) is int and
                           body["task_epoch"] == pending["task_epoch"])
                if pending is not None:
                    if planned:
                        pending["phase"] = "invalidated"
                        pending["network_attempted"] = True
                        pending["identity_verified"] = False
                    else:
                        pending["error"] = "document_changed"
                state.cv.notify_all()
                return {}
            if path == "/identity":
                if (not self.natural_mode or state.stopping or state.poisoned or state.invalidated or
                    pending is None or pending["phase"] != "observing" or
                    pending["doc_epoch"] != state.doc_epoch or pending["error"] is not None or
                    pending["result"] is not None or body.get("call_id") != pending["call_id"] or
                    type(body.get("task_epoch")) is not int or
                    body["task_epoch"] != pending["task_epoch"] or
                    not isinstance(body.get("envelope"), dict)):
                    raise PageTransportError("identity_denied")
                envelope = body["envelope"]
                error = _platform_code(envelope)
                if not error:
                    error = _natural_identity_error(envelope, self.scope["bound_uid"],
                        identity_observation=self.identity_observation)
                if error:
                    pending["error"] = error
                    state.poisoned = True
                    if error == "verification_required":
                        state.hold_reason = error
                    state.cv.notify_all()
                    raise PageTransportError(error, pending["network_attempted"])
                pending["identity_verified"] = True
                pending["network_attempted"] = True
                state.uid_verified = True
                return {}
            if path == "/poll":
                if state.stopping:
                    return {"action": "stop"}
                if state.poisoned:
                    return {"action": "hold", **({"reason": state.hold_reason} if state.hold_reason else {})}
                if state.invalidated or state.pending is None or state.pending["delivered"]:
                    return {"action": "idle"}
                pending = state.pending
                pending["delivered"] = True
                command = {"action": pending["action"], "call_id": pending["call_id"],
                           "params": pending["params"]}
                if self.natural_mode:
                    command["task_epoch"] = pending["task_epoch"]
                return command
            pending = state.pending
            if (path != "/result" or state.stopping or state.poisoned or state.invalidated or
                pending is None or not pending["delivered"] or pending["result"] is not None or
                pending["error"] is not None or body.get("call_id") != pending["call_id"] or
                pending["doc_epoch"] != state.doc_epoch or not isinstance(body.get("envelope"), dict)):
                raise PageTransportError("result_denied")
            if self.natural_mode and (
                pending["phase"] not in ("issued", "observing") or
                not pending["identity_verified"] or
                type(body.get("task_epoch")) is not int or
                body["task_epoch"] != pending["task_epoch"]):
                raise PageTransportError("result_denied")
            if self.natural_mode:
                pending["network_attempted"] = True
            pending["result"] = body["envelope"]
            state.cv.notify_all()
            return {}


__all__ = ["XhsPageTransport", "PageTransportError"]
