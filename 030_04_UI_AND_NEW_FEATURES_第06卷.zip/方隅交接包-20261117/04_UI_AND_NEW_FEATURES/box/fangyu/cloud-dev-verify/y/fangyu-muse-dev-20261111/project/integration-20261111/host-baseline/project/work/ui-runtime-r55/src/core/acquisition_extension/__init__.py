"""Independent source candidates; importing this package performs no IO."""
