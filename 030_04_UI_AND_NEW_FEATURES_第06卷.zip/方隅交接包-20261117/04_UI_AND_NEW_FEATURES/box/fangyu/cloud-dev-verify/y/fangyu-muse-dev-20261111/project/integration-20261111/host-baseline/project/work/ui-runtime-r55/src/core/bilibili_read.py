"""Fixed narrow Bilibili route into the original guarded execute / OS-lock owner."""
import hashlib
from pathlib import Path
from bilibili_read_contract import BilibiliContractError, project

SEARCH_ARGS=['search','--keyword','{keyword}','--page','{page}','--limit','{limit}']
COMMENTS_ARGS=['comments','--bvid','{source_id}','--page','{page}','--limit','{limit}']
_FIXED_EXECUTABLE='C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\desktop-python\\Scripts\\python.exe'
_FIXED_EXECUTABLE_SHA='de13d8017f63cb63b0b5bfd2f25e69245c9196433a224856ca1abde1e24d0cb7'
_PINS={'bilibili_read_contract.py': 'a83244e10d5613d1fa2e1ae78ed6fe3b587e74578957fb3cc8a098b4e1e6a4ec', 'resources/bilibili_read_vendor/bilicli/client.py': '901871dd1426cc16113f68fbe9a5fcdd1c639678ed77873e80bd2c151855214c', 'resources/bilibili_read_vendor/bilicli/wbi.py': 'b8be9106a46eb2c8198716355902a32024bb7d68aaa0526c1f7786f326a73c66', 'resources/bilibili_read_vendor/bilicli/__init__.py': '91447944015cec709e8aa7655f7e9d64e1e4508e7023a57fe3746911c0fc6fed', 'resources/bilibili_read_vendor/bilicli/api/comment.py': '1b6e8dcb6281e57889d8c9841950f9bee2c3914d51c9915d650c11264d68c7dc', 'resources/bilibili_read_vendor/bilicli/api/search.py': 'de5e4dfa6d5fcf24cffa1e83b651203ba90625c89115eae3dffa9c909d636f83', 'resources/bilibili_read_vendor/bilicli/api/video.py': '2e20f252fd2b2d0c58866f54f1fd1ef0ba43492be8cb42e48553abdadf0cddc9', 'resources/bilibili_read_vendor/bilicli/api/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'resources/bilibili_read_vendor/LICENSE': 'cd3a5844d13ad021b2f2298dc6d1d60f20ca65333c3f3a482de1033ac09ff784', 'bilibili_read_entry.py': '9d07ab6c4849877a97e6aa48357f677e0939b3c08196282d310e33b32b82558f', 'core/bilibili_owned_setup.py': '39ac1046f08772c48079378717d54f7d95a874e5001b79d149cb452742cd98a2', 'core/adapters.py': '07c8afd3270b2e17452c6e2ad444a4820ee9809dba8d01134cebe19ff436c50a'}

def _source_root():return Path(__file__).resolve().parents[1]

def configured(manifest):
    """Static availability only; never reads cookies, imports tools or grants access."""
    root=_source_root();entry=root/'bilibili_read_entry.py'
    if (type(manifest) is not dict or manifest.get('transport')!='bilibili_fixed_read_v1'
            or manifest.get('mapper')!='standard_json' or manifest.get('account_mode')!='isolated_home'
            or manifest.get('isolation_guard') is not True
            or manifest.get('search_args')!=SEARCH_ARGS or manifest.get('comments_args')!=COMMENTS_ARGS
            or manifest.get('prefix_args')!=['-X','utf8','-B','-I','-S',str(entry)]):return False
    try:
        for relative,digest in _PINS.items():
            path=root/relative
            if not path.is_file() or any(p.is_symlink() or getattr(p.stat(),'st_file_attributes',0)&1024 for p in [path,*path.parents]):return False
            if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:return False
        executable=Path(manifest['executable'])
        return (executable==Path(_FIXED_EXECUTABLE) and hashlib.sha256(executable.read_bytes()).hexdigest()==_FIXED_EXECUTABLE_SHA
                and (executable.parent.parent/'Lib/site-packages/httpx/__init__.py').is_file())
    except (KeyError,TypeError,OSError,ValueError):return False

def read(adapters,operation,task):
    from .platform_reads import ReadContractError,source_reference
    from .adapters import AdapterAuthRequired
    manifest=adapters.manifest('bilibili')
    if operation not in ('search','comments') or not configured(manifest):raise RuntimeError('B站固定只读运行链尚未完整接线')
    if operation=='search' and manifest.get('search_verified') is not True:
        raise RuntimeError('B站只读搜索尚未完成原搜索验证')
    if task.get('next_cursor'):raise ReadContractError('B站只读分页使用明确页码')
    page=task.get('next_page',1);limit=task.get('daily_limit',20)
    if type(page) is not int or not 1<=page<=50 or type(limit) is not int or not 1<=limit<=100:
        raise ReadContractError('B站单次读取页码或数量无效')
    limit=min(limit,20)
    expected_uid=task.get('_expected_platform_uid') or ''
    if not isinstance(expected_uid,str):raise ReadContractError('B站原账号UID格式无效')
    keyword=' '.join(task.get('keywords',[]))
    reference=source_reference('bilibili',task['note_url'])[0] if operation=='comments' else ''
    args=([operation,'--keyword',keyword] if operation=='search' else [operation,'--bvid',reference])
    args+=['--page',str(page),'--limit',str(limit),'--expected-uid',expected_uid]
    # Original execute owns platform guards, exact account HOME, OS lock,
    # lifecycle registration, cancellation, timeout and process reap.
    payload=adapters.execute('bilibili',args,task.get('_account_dir'),task.get('id'),timeout=35)
    if isinstance(payload,dict) and payload.get('read_error')=='account_unverified':raise AdapterAuthRequired('B站凭据与当前账号身份尚未核实')
    if isinstance(payload,dict) and payload.get('read_error')=='read_hold':raise RuntimeError('B站读取未完成；不会自动重试')
    try:
        rows,info=project(payload,operation=operation,page=page,limit=limit,reference=reference,
                          expected_uid=expected_uid,keyword=keyword if operation=='search' else None)
        if payload.get('items')!=rows or payload.get('page')!=info:raise BilibiliContractError('投影与原响应不一致')
    except BilibiliContractError as exc:raise ReadContractError(str(exc)) from None
    task['_page_info']=info
    sink=task.get('_owned_search_raw_sink')
    if operation=='search' and callable(sink):sink('bilibili',payload['raw'],rows,page)
    return rows
