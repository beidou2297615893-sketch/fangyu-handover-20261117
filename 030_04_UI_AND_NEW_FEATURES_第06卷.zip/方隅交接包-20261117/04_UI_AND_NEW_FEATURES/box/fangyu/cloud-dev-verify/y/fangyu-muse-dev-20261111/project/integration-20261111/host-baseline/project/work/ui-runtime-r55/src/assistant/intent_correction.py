"""Atomic single-comment manual correction in the original Core records DB.

No provider, platform adapter, account login, customer copy, or network access.
Native authorizes the live selected store; this layer rechecks saved ownership,
source binding and actor in the same SQLite transaction as the correction.
"""
from copy import deepcopy
import hashlib,json,re
from .ai_workflow import LEVELS,effective_intent,timestamp
from .customer_list import _person

ENTITY='intent_corrections_v1'
ID=re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}\Z')
HEX=re.compile(r'[a-f0-9]{64}\Z')
FIELDS={'lead_id','customer_id','store_id','platform','request_id','expected_version','source_digest','status','level','reason'}
ECMA_TRIM='\t\n\v\f\r \u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff'
def trim_reason(value):return value.strip(ECMA_TRIM)

class IntentCorrectionError(ValueError):
    def __init__(self,code,message,status=409,*,mutation_committed=False):
        super().__init__(message);self.code=code;self.status=status;self.mutation_committed=mutation_committed

def fail(code,message,status=409):raise IntentCorrectionError(code,message,status)
def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def request_key(user,request):return digest((user['tenant_id'],user['id'],request))
def request_digest(data):
    """Public camelCase JSON, sorted keys, UTF-8, no whitespace, trimmed reason."""
    names={'lead_id':'leadId','customer_id':'customerId','store_id':'storeId','request_id':'requestId',
           'expected_version':'expectedVersion','source_digest':'sourceDigest'}
    return digest({names.get(k,k):trim_reason(v) if k=='reason' else v for k,v in data.items()})
def version(lead):
    return digest({k:lead.get(k) for k in ('ai_intent','manual_intent','analysis_status','analysis_error','analysis_source_digest')})
def source_digest(lead,task=None):
    return digest({'lead':{k:lead.get(k) for k in ('id','tenant_id','cloud_owner','store_id','task_id','platform','author_id',
        'comment_id','text','note_url','content_title','title','comment_time','created_at')},
        'task':{k:(task or {}).get(k) for k in ('id','tenant_id','cloud_owner','store_id','account_id','platform')}})
def intent(value):
    if not isinstance(value,dict):return None
    result={key:deepcopy(value.get(key)) for key in ('status','level','reason') if key in value}
    if isinstance(value.get('evidence'),(str,list)):result['evidence']=deepcopy(value['evidence'])
    for key in ('by','updated_at'):
        if key in value:result['updatedAt' if key=='updated_at' else key]=value[key]
    return result
def receipt(record):
    value={'requestId':record['request_id'],'state':record.get('state','saved'),'customerId':record['customer_id'],
        'leadId':record['lead_id'],'platform':record['platform'],'storeId':record['store_id'],
        'requestDigest':record['signature']}
    if value['state']=='saved':value.update(version=record['result_version'],sourceDigest=record['source_digest'])
    else:value['cancelledAt']=record['created_at']
    return value
def project(core,user,lead,data,*,record=None):
    task=core.store.get('tasks',lead.get('task_id')) if lead.get('task_id') else None
    rows=[row for row in core.store.list(ENTITY,user['tenant_id']) if row.get('state','saved')=='saved' and all(row.get(k)==v for k,v in
        (('actor_id',user['id']),('store_id',data['store_id']),('customer_id',data['customer_id']),('lead_id',lead['id']),('platform',lead['platform'])))]
    rows.sort(key=lambda row:(row['created_at'],row['id']),reverse=True)
    return {'actor':{'username':user['username'],'storeId':data['store_id']},'scope':'single-comment',
        'customerId':data['customer_id'],'leadId':lead['id'],'platform':lead['platform'],
        'version':version(lead),'sourceDigest':source_digest(lead,task),
        'aiIntent':intent(lead.get('ai_intent')),'manualIntent':intent(lead.get('manual_intent')),
        'currentIntent':intent(effective_intent(lead)),
        'history':[{'requestId':row['request_id'],'updatedAt':row['created_at'],'by':row['actor'],
                    'before':intent(row['before']),'after':intent(row['after'])} for row in rows],
        'receipt':receipt(record) if record else None}

def validate(data):
    if not isinstance(data,dict) or set(data)!=FIELDS:fail('INTENT_INPUT_INVALID','人工判断参数无效',400)
    for key in ('lead_id','store_id','request_id'):
        if not isinstance(data[key],str) or not ID.fullmatch(data[key]):fail('INTENT_INPUT_INVALID','人工判断编号无效',400)
    for key in ('customer_id','expected_version','source_digest'):
        if not isinstance(data[key],str) or not HEX.fullmatch(data[key]):fail('INTENT_INPUT_INVALID','原评论版本无法核对',400)
    if data['platform'] not in ('xiaohongshu','douyin'):fail('INTENT_INPUT_INVALID','请选择正确平台',400)
    if data['status'] not in ('graded','uncertain','unrelated') or (data['level'] not in LEVELS if data['status']=='graded' else data['level'] is not None):
        fail('INTENT_INPUT_INVALID','请选择有效意向',400)
    if not isinstance(data['reason'],str) or not 1<=len(trim_reason(data['reason']))<=300:
        fail('INTENT_INPUT_INVALID','请填写 1 至 300 字的修改理由',400)
    return {**data,'reason':trim_reason(data['reason'])}

def scoped_lead(core,user,data,db):
    current=core._get('users',user['id'],user['tenant_id'],db=db)
    if (current.get('cloud_bound') is not True or current.get('disabled') or current.get('development_local_only') is True
            or current.get('role') not in ('operator','admin') or any(current.get(k)!=user.get(k) for k in
             ('id','tenant_id','username','role','cloud_bound','permission_revision'))):
        fail('INTENT_SCOPE_CHANGED','员工身份或权限已变化，请重新读取',403)
    lead=core._get('leads',data['lead_id'],user['tenant_id'],db=db)
    task=core._get('tasks',lead['task_id'],user['tenant_id'],db=db) if lead.get('task_id') else None
    if lead.get('cloud_owner') not in (None,'',user['username']):fail('INTENT_SCOPE_CHANGED','评论不属于当前员工',403)
    if task:
        core._task_access(user,task,user['tenant_id'],db=db)
        if task.get('cloud_owner') not in (None,'',user['username']):fail('INTENT_SCOPE_CHANGED','任务不属于当前员工',403)
        if task.get('account_id'):
            account=core._get('accounts',task['account_id'],user['tenant_id'],db=db)
            if account.get('store_id') not in (None,'',data['store_id']) or account.get('platform') not in (None,'',data['platform']):
                fail('INTENT_SCOPE_CHANGED','原采集账号归属已变化，请重新核对',403)
    elif lead.get('cloud_owner')!=user['username']:
        fail('INTENT_SCOPE_CHANGED','原评论员工归属尚未核实',403)
    stores={row.get('store_id') for row in (lead,task or {}) if row.get('store_id')}
    if not stores:fail('INTENT_SOURCE_UNVERIFIED','原评论尚未核实门店归属，暂不能修改',409)
    if stores!={data['store_id']} or lead.get('platform')!=data['platform'] or (task or {}).get('platform') not in (None,'',data['platform']):
        fail('INTENT_SCOPE_CHANGED','评论不属于当前门店或平台',403)
    if _person(lead)[0]!=data['customer_id']:fail('INTENT_SCOPE_CHANGED','该评论不属于选中的客户',403)
    return lead,task

def apply(core,user,lead,data):
    """Called only by LocalAIWorkflow.correct; all writes commit together."""
    data=validate(data); key=request_key(user,data['request_id']);signature=request_digest(data)
    commit_started=False;committed=False
    try:
        with core.lock,core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current,task=scoped_lead(core,user,data,db)
            prior=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(ENTITY,key)).fetchone()
            if prior:
                previous=json.loads(prior['body'])
                if previous.get('signature')!=signature:fail('INTENT_REQUEST_CONFLICT','此操作编号已用于其他内容，请先核对原操作')
                if previous.get('state')=='cancelled':fail('INTENT_REQUEST_CANCELLED','原操作已明确取消，不会保存迟到请求；请重新读取后新建修改')
                db.rollback()
                return {'lead':current,'record':previous}
            if source_digest(current,task)!=data['source_digest']:
                fail('INTENT_SOURCE_CHANGED','原评论内容或归属已变化，请重新读取后判断')
            if version(current)!=data['expected_version']:
                fail('INTENT_VERSION_CONFLICT','分析或人工判断已更新，请重新读取后修改')
            now=timestamp();before=deepcopy(effective_intent(current))
            manual={'status':data['status'],'level':data['level'],'reason':data['reason'],
                    'by':user['username'],'updated_at':now,'correction_id':key}
            updated={**current,'manual_intent':manual}
            record={'id':key,'state':'saved','tenant_id':user['tenant_id'],'actor_id':user['id'],'actor':user['username'],
                'created_at':now,**{k:data[k] for k in ('request_id','customer_id','lead_id','platform','store_id','source_digest')},
                'signature':signature,'result_version':version(updated),'before':before,'after':manual,
                'original_ai':deepcopy(current.get('ai_intent')),'previous_manual':deepcopy(current.get('manual_intent'))}
            audit={'id':'intent-'+key,'tenant_id':user['tenant_id'],'created_at':now,'actor':user['username'],
                   'action':'intent_correct','detail':{'lead_id':current['id'],'customer_id':data['customer_id'],
                      'store_id':data['store_id'],'request_id':data['request_id'],'history_id':key}}
            for entity,row in (('leads',updated),(ENTITY,record),('audit',audit)):
                db.execute('INSERT OR REPLACE INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                    (entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))
            from core.customer_intent_dirty import mark_change
            mark_change(db,'leads',current,updated)
            commit_started=True;db.commit();committed=True
            return {'lead':updated,'record':record}
    except IntentCorrectionError:raise
    except Exception as exc:
        raise IntentCorrectionError('INTENT_RESULT_UNCONFIRMED' if commit_started else 'INTENT_SAVE_REJECTED',
            '保存结果尚未确认，请查询原操作，勿重复保存' if commit_started else '修改未保存，请重新核对当前评论与权限',
            409,mutation_committed=True if committed else None if commit_started else False) from exc

def cancel(core,user,data):
    fields={'store_id','customer_id','lead_id','platform','request_id','request_digest'}
    if not isinstance(data,dict) or set(data)!=fields:fail('INTENT_INPUT_INVALID','原操作取消参数无效',400)
    for name in ('store_id','lead_id','request_id'):
        if not isinstance(data[name],str) or not ID.fullmatch(data[name]):fail('INTENT_INPUT_INVALID','原操作编号无效',400)
    for name in ('customer_id','request_digest'):
        if not isinstance(data[name],str) or not HEX.fullmatch(data[name]):fail('INTENT_INPUT_INVALID','原操作摘要无效',400)
    if data['platform'] not in ('xiaohongshu','douyin'):fail('INTENT_INPUT_INVALID','原操作平台无效',400)
    key=request_key(user,data['request_id']);commit_started=False;committed=False
    try:
        with core.lock,core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current,_task=scoped_lead(core,user,data,db)
            prior=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(ENTITY,key)).fetchone()
            if prior:
                record=json.loads(prior['body'])
                if (record.get('signature')!=data['request_digest'] or any(record.get(k)!=data[k] for k in
                     ('customer_id','lead_id','store_id','platform'))):
                    fail('INTENT_REQUEST_CONFLICT','此编号或摘要不属于原操作，请先核对')
                db.rollback();return {'lead':current,'record':record}
            now=timestamp()
            record={'id':key,'tenant_id':user['tenant_id'],'state':'cancelled','actor_id':user['id'],'actor':user['username'],
                'created_at':now,'signature':data['request_digest'],
                **{k:data[k] for k in ('request_id','customer_id','lead_id','platform','store_id')}}
            audit={'id':'intent-cancel-'+key,'tenant_id':user['tenant_id'],'created_at':now,'actor':user['username'],
                'action':'intent_correction_cancel','detail':{'lead_id':current['id'],'customer_id':data['customer_id'],
                    'store_id':data['store_id'],'request_id':data['request_id'],'history_id':key}}
            for entity,row in ((ENTITY,record),('audit',audit)):
                db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                    (entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))
            commit_started=True;db.commit();committed=True
            return {'lead':current,'record':record}
    except IntentCorrectionError:raise
    except Exception as exc:
        raise IntentCorrectionError('INTENT_RESULT_UNCONFIRMED' if commit_started else 'INTENT_CANCEL_REJECTED',
            '取消结果尚未确认，请查询原操作，暂勿新建修改' if commit_started else '取消未完成，请核对原账号和评论',409,
            mutation_committed=True if committed else None if commit_started else False) from exc

def persist_ai_result(core,before,updated,task_snapshot):
    """CAS the actual AI write, including writers in another Core process.

The normal workflow already validates provider/policy/ownership. This final
storage check only rejects a stale lead/source snapshot; it never reissues an
analysis and never removes manual intent or old AI history.
"""
    if before.get('id')!=updated.get('id') or before.get('tenant_id')!=updated.get('tenant_id'):
        raise ValueError('AI result source identity changed')
    expected_source=source_digest(before,task_snapshot)
    with core.store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            ('leads',before['id'],before['tenant_id'])).fetchone()
        if not row:return False
        current=json.loads(row['body'])
        if current!=before or current.get('manual_intent'):return False
        task=None
        if current.get('task_id'):
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('tasks',current['task_id'],current['tenant_id'])).fetchone()
            if not found:return False
            task=json.loads(found['body'])
        if source_digest(current,task)!=expected_source:return False
        db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
            (json.dumps(updated,ensure_ascii=False),'leads',before['id'],before['tenant_id']))
        from core.customer_intent_dirty import mark_change
        mark_change(db,'leads',current,updated)
        return True
