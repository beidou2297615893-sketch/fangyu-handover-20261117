"""Bounded platform failure contract. No provider messages or auth material."""
import re
import json
from pathlib import Path

CODES={'not_authenticated','verification_required','ip_blocked','signature_error',
    'api_error','unsupported_operation','protocol_error','transport_error','unknown_error'}
MESSAGES={
    'authentication_required':'平台登录不可用，请打开原账号登录入口',
    'verification_required':'平台要求验证，请打开原账号页面处理',
    'platform_rejected':'平台暂未允许读取，已保留任务断点',
    'rate_limited':'平台暂时限制请求频率，已保留任务断点',
    'compatibility_error':'CLI与平台接口暂不兼容，已保留任务断点',
    'transport_error':'平台连接未完成，已保留任务断点',
    'protocol_error':'平台结果无法确认，已保留任务断点',
    'unknown':'本次读取未完成，已保留任务断点'}


def numeric(value):
    if type(value) is str and re.fullmatch(r'-?(?:0|[1-9][0-9]{0,9})',value):value=int(value)
    return value if type(value) is int and -(2**31)<=value<2**31 else None


def from_cli(code,diagnostics=None):
    code=code if type(code) is str and code in CODES else 'unknown_error'
    data=diagnostics if type(diagnostics) is dict else {}
    http=data.get('http_status');http=http if type(http) is int and 100<=http<=599 else None
    # These fixed enums must be emitted from explicit platform signals by the
    # adapter. Legacy verification_required (often just HTTP461) has no signal.
    signal=data.get('auth_signal')
    signal=signal if type(signal) is str and signal in ('session_expired','session_missing','captcha_challenge') else None
    if code=='not_authenticated':signal=signal if signal in ('session_expired','session_missing') else 'session_missing'
    if code=='not_authenticated':category='authentication_required'
    elif code=='verification_required' and signal=='captcha_challenge':category='verification_required'
    elif code in ('signature_error','unsupported_operation'):category='compatibility_error'
    elif code=='transport_error':category='transport_error'
    elif code=='protocol_error':category='protocol_error'
    elif http==429:category='rate_limited'
    elif code in ('verification_required','ip_blocked','api_error') or http in (403,461,471):category='platform_rejected'
    else:category='unknown'
    auth=category in ('authentication_required','verification_required')
    return {'schema':'platform-failure-v1','platform':'xiaohongshu','cli_code':code,
        'category':category,'http_status':http,'platform_code':numeric(data.get('platform_code')),
        'auth_signal':signal if auth else None,'requires_auth':auth,
        'retryable':None,'automatic_retry':False,
        'suggested_action':'open_account_login' if category=='authentication_required' else
            'open_account_page' if category=='verification_required' else
            'check_cli_compatibility' if category=='compatibility_error' else 'keep_checkpoint'}


def validated(value):
    if type(value) is not dict or value.get('schema')!='platform-failure-v1':return None
    rebuilt=from_cli(value.get('cli_code'),value)
    return rebuilt if value==rebuilt else None


def message(facts):return MESSAGES[(validated(facts) or {'category':'unknown'})['category']]


def journal_offset(spec):
    destination=(spec.get('env') or {}).get('WORKSPACE_ACTIVITY_LOG')
    if not isinstance(destination,str) or not destination:return None
    try:
        path=Path(destination)
        if path.is_symlink() or hasattr(path,'is_junction') and path.is_junction():return None
        return path.stat().st_size if path.exists() else 0
    except OSError:return None


def response_diagnostics(spec,offset,kind):
    """Read only this invocation's bounded, already-sanitized activity rows.

    Legacy CLI output omits HTTP facts. Never borrow a historical error, parse
    platform response text, or infer authentication from a numeric HTTP status.
    """
    if offset is None or type(offset) is not int or offset<0:return {}
    path=Path((spec.get('env') or {})['WORKSPACE_ACTIVITY_LOG'])
    try:
        if path.is_symlink() or hasattr(path,'is_junction') and path.is_junction():return {}
        with path.open('rb') as stream:
            stream.seek(offset);raw=stream.read(65537)
        if len(raw)>65536:return {}
        rows=[json.loads(line) for line in raw.splitlines() if line]
    except (OSError,ValueError):return {}
    starts=set();last={}
    for row in rows:
        if type(row) is not dict or row.get('kind')!=kind:continue
        request_id=row.get('request_id')
        if type(request_id) is not str or not re.fullmatch(r'[a-f0-9]{16}',request_id):continue
        if row.get('stage')=='started':starts.add(request_id)
        elif row.get('stage')=='finished' and request_id in starts:
            status=row.get('http_status',row.get('status'))
            if type(status) is int and 100<=status<=599:
                last={'http_status':status,'platform_code':numeric(row.get('platform_code'))}
    return last


class AdapterPlatformFailure(RuntimeError):
    def __init__(self,facts):
        self.platform_error=validated(facts) or from_cli('unknown_error')
        super().__init__(message(self.platform_error))
