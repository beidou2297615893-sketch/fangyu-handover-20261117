"""Dedicated entry: no platform/diagnostic/general Python CLI dispatch."""
import ctypes,hashlib,http.client,json,os,re,socket,sys,time
from ctypes import wintypes
from pathlib import Path
from portable_helper_package import verify_package,check_code_origins

def _identity():
 k=ctypes.WinDLL('kernel32.dll',winmode=0x800,use_last_error=True)
 k.GetCurrentProcess.restype=wintypes.HANDLE;k.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)];k.GetProcessTimes.restype=wintypes.BOOL
 times=[wintypes.FILETIME() for _ in range(4)]
 if not k.GetProcessTimes(k.GetCurrentProcess(),*(ctypes.byref(t) for t in times)):raise ValueError('helper_identity_unavailable')
 return os.getpid(),(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime

def _bootstrap(spec):
 from xhs_page_window import load_spec
 from urllib.parse import urlsplit
 pid,created=_identity();raw=spec.spec_path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
 body={'contract':'owned_xhs_helper_bootstrap_v1','secret':spec.bootstrap_secret,'tenant_id':spec.tenant_id,'account_id':spec.account_id,'bound_uid':spec.bound_uid,'purpose':spec.purpose,'helper_pid':pid,'helper_created':created,'spec_sha256':digest}
 packet=json.dumps(body,separators=(',',':'),ensure_ascii=True).encode();endpoint=urlsplit(spec.endpoint);deadline=time.monotonic()+10
 for attempt in range(10):
  if spec.cancel_file.exists():raise ValueError('cancelled')
  if hashlib.sha256(spec.spec_path.read_bytes()).hexdigest()!=digest or load_spec(spec.spec_path)!=spec:raise ValueError('helper_spec_changed')
  remaining=deadline-time.monotonic()
  if remaining<=0:break
  connection=http.client.HTTPConnection('127.0.0.1',endpoint.port,timeout=min(1,remaining))
  pending=False
  try:
   connection.request('POST','/bootstrap',body=packet,headers={'Content-Type':'application/json','Accept':'application/json','Connection':'close'})
   response=connection.getresponse();raw=response.read(8193)
   if len(raw)>8192:raise ValueError('helper_host_refused')
   value=json.loads(raw)
   if response.status==200 and value=={'ok':True,'contract':'owned_xhs_helper_bootstrap_v1','authorized':True}:return
   code=value.get('code') if type(value) is dict else None
   pending=response.status in (200,503) and code in ('parent_bind_pending','timeout')
   if not pending:raise ValueError('helper_host_refused')
  except (socket.timeout,TimeoutError):pending=True
  finally:connection.close()
  if pending:time.sleep(min(.1,max(0,deadline-time.monotonic())))
 raise ValueError('helper_host_timeout')

def _system_dependency(root,manifest):
 from assistant.webview_system_dependency import OwnedRuntimePin,SystemWebView2Policy
 pins={r['path']:r for r in manifest['files']};sdk=Path('_internal/webview/lib');required=[('FangyuXhsPageHelper.exe','helper_exe_with_embedded_pyz'),((sdk/'runtimes/win-x64/native/WebView2Loader.dll').as_posix(),'sdk_loader'),((sdk/'Microsoft.Web.WebView2.Core.dll').as_posix(),'sdk_core'),((sdk/'Microsoft.Web.WebView2.WinForms.dll').as_posix(),'sdk_winforms')]
 material=tuple(OwnedRuntimePin(root/rel,pins[rel]['sha256'],pins[rel]['bytes'],role) for rel,role in required)
 return SystemWebView2Policy(material,mode='compiled').verify()

def _describe(root,manifest,manifest_sha):
 import xhs_page_window,xhs_natural_window,owned_natural_reader,owned_window_sources
 from portable_code_origins import collect_code_origins
 with _system_dependency(root,manifest) as system:
  # Load only the original managed assemblies and namespace types for source
  # observation. No Form/WebView/CoreWebView2/control is constructed.
  import clr
  clr.AddReference('System.Windows.Forms')
  clr.AddReference(str(root/'_internal/webview/lib/Microsoft.Web.WebView2.Core.dll'))
  clr.AddReference(str(root/'_internal/webview/lib/Microsoft.Web.WebView2.WinForms.dll'))
  from System import AppDomain
  from System.Diagnostics import Process
  from System.Windows.Forms import Application
  from Microsoft.Web.WebView2.Core import CoreWebView2Environment
  from Microsoft.Web.WebView2.WinForms import WebView2
  managed=sorted({str(a.Location) for a in AppDomain.CurrentDomain.GetAssemblies() if not a.IsDynamic and str(a.Location)})
  facts=collect_code_origins()
  try:check_code_origins(facts,manifest,root)
  except ValueError as error:
   error.observed_origins=facts;raise
  return {'contract':'portable_xhs_helper_description_v1','helper':str(Path(sys.executable)),'packageManifestSha256':manifest_sha,'code_origins':facts,'systemDependency':system.describe(),'managedAssemblyObservations':managed,'managedAssembliesApproved':False,'pyvenvRequired':False,'nativeWindowOpened':False,'webviewInitialized':False,'naturalPageVerified':False,'purposeAuthorized':False,'accountVerified':False,'nativeLoadedBytesVerified':False}

def main(argv=None):
 args=list(sys.argv[1:] if argv is None else argv)
 if getattr(sys,'frozen',False) is not True:return 64
 if args!=['--describe']:
  if len(args)!=7 or args[0]!='--owned-xhs-page-helper' or args[1]!='--bridge-spec' or args[3]!='--profile-dir' or args[5]!='--package-sha256' or not re.fullmatch('[0-9a-f]{64}',args[6]):return 64
 window_attempted=False
 try:
  root=Path(sys.executable).absolute().parent;manifest,manifest_sha,_=verify_package(Path(sys.executable).absolute(),None if args==['--describe'] else args[6])
  if args==['--describe']:
   print(json.dumps(_describe(root,manifest,manifest_sha),ensure_ascii=True,separators=(',',':')));return 0
  from xhs_page_window import load_spec,run_window
  spec=load_spec(Path(args[2]))
  if spec.read_mode!='natural' or Path(args[4])!=spec.profile_dir:raise ValueError('helper_mode_invalid')
  _bootstrap(spec) # Mandatory before mkdir, webview/CLR or any window creation.
  if spec.cancel_file.exists():raise ValueError('cancelled')
  with _system_dependency(root,manifest) as system:
   system.check_current()
   import webview
   webview.settings['WEBVIEW2_RUNTIME_PATH']=str(system.browser_executable_folder)
   window_attempted=True;code=run_window(spec)
  print(json.dumps({'code':code},separators=(',',':')))
  return 0 if code in ('stopped','closed','cancelled','candidate_staged_natural_verified') else 1
 except Exception as error:
  # No user path, secret, supplied body or arbitrary exception is printed.
  code=str(error) if str(error) in ('helper_host_refused','helper_host_timeout','helper_spec_changed','cancelled','helper_mode_invalid') else 'helper_material_or_host_unavailable'
  output={'code':code,'nativeWindowOpened':None if window_attempted else False,'windowCreationAttempted':window_attempted}
  if args==['--describe']:
   output['descriptionFailureType']=type(error).__name__
   if type(error) is ValueError and re.fullmatch('[a-z_]{1,80}',str(error)):output['descriptionFailureCode']=str(error)
   if isinstance(error,ImportError) and re.fullmatch('[A-Za-z0-9_.]{1,160}',str(getattr(error,'name',''))):output['descriptionFailureModule']=error.name
   if re.fullmatch('[A-Za-z0-9_.]{1,160}',str(getattr(error,'origin_module',''))):output['descriptionFailureModule']=error.origin_module
   trace=error.__traceback__;frames=[]
   while trace is not None:
    frames.append({'moduleFile':Path(trace.tb_frame.f_code.co_filename).name,'function':trace.tb_frame.f_code.co_name,'line':trace.tb_lineno});trace=trace.tb_next
   output['descriptionFailureFrames']=frames
   if hasattr(error,'observed_origins'):output['unapprovedObservedOrigins']=error.observed_origins
  print(json.dumps(output,separators=(',',':')));return 65

if __name__=='__main__':raise SystemExit(main())
