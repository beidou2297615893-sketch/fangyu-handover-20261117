"""Original-owner entry seam: prepare/query, one normal-close commit, RAM receipt.

No HTTP command, second workspace, offline commit, platform permission or retry.
The original main supplies real Factory/AppServer/Owner/Core and retains its
original mutex; the independently reviewed close Module supplies authority.
"""
from copy import deepcopy
import hashlib
import os
from pathlib import Path
import re
import sys
import threading

ENTRY_INTERFACE = 'owner_primary_entry_v1'
LOADED_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest().upper()
_SEAL = object()
_LAST_RECEIPT = None
_HEX = re.compile(r'[0-9a-f]{64}\Z')


def _writer():
    from . import owner_instance_platform_upgrade_writer as writer
    from .owner_normal_close import require_reviewed_writer
    require_reviewed_writer(writer)  # Empty/unreviewed pin always remains held.
    return writer


def _bound_result(result, plan):
    summary = plan.summary()
    return (type(result) is dict
        and set(result) == {'schema', 'state', 'idempotency_key', 'instance_id',
            'company_id', 'phase', 'old_marker_sha256', 'target_marker_sha256',
            'mutation_committed', 'added_platforms', 'auto_retry',
            'platform_permissions_granted', 'process_exited_verified'}
        and result['schema'] == 'owner_instance_platform_upgrade_result_v1'
        and result['idempotency_key'] == plan.idempotency_key
        and result['instance_id'] == summary['instance_id']
        and result['company_id'] == summary['company_id']
        and result['old_marker_sha256'] == summary['source_marker_sha256']
        and result['target_marker_sha256'] == summary['target_marker_sha256']
        and result['added_platforms'] == {'douyin': 'pending', 'wechat_channels': 'pending'}
        and result['auto_retry'] is False
        and result['platform_permissions_granted'] is False
        and result['process_exited_verified'] is False)


def _held(plan):
    summary = plan.summary()
    return {'schema': 'owner_instance_platform_upgrade_result_v1', 'state': 'held',
        'idempotency_key': plan.idempotency_key, 'instance_id': summary['instance_id'],
        'company_id': summary['company_id'], 'phase': None,
        'old_marker_sha256': summary['source_marker_sha256'],
        'target_marker_sha256': summary['target_marker_sha256'],
        'mutation_committed': None,
        'added_platforms': {'douyin': 'pending', 'wechat_channels': 'pending'},
        'auto_retry': False, 'platform_permissions_granted': False,
        'process_exited_verified': False}


def open_existing_owner_entry_instance(directory, work_root, wrapper_sha, *, product):
    """Use the original Factory with its existing-only guard, never mint a pilot."""
    from .self_operating_read import open_owner_read_instance
    return open_owner_read_instance(str(directory), str(work_root), wrapper_sha,
        product=product, existing_only=True)


def query_owner_upgrade(instance, key=None):
    """Pure same-key writer GET; no Core/server/lock/platform or data initializer."""
    from .self_operating_read import _OwnerReadInstance
    if (type(instance) is not _OwnerReadInstance
            or key is not None and (type(key) is not str or not _HEX.fullmatch(key))):
        raise ValueError('ORIGINAL_INSTANCE_AND_KEY_REQUIRED')
    writer = _writer()
    if key is None:
        if instance.product != 'xiaohongshu_v1':
            raise ValueError('ORIGINAL_KEY_REQUIRED')
        key = writer.prepare_owner_platform_upgrade(instance).idempotency_key
    return writer.get_owner_platform_upgrade(instance, key)


class _OwnerUpgradeRequest:
    __slots__ = ('_seal', 'instance', 'writer', 'plan', 'metadata_recovery',
        '_pid', '_thread', '_server', '_core', '_mutex', '_consumed', '_result', '_trusted')

    def __init__(self, seal, instance, writer, plan, metadata_recovery):
        if seal is not _SEAL:
            raise ValueError('NORMAL_MAIN_REQUEST_REQUIRED')
        self._seal, self.instance, self.writer, self.plan = seal, instance, writer, plan
        self.metadata_recovery = metadata_recovery
        self._pid, self._thread = os.getpid(), threading.current_thread()
        self._server = self._core = self._mutex = None
        self._consumed = False
        self._result, self._trusted = None, False

    def _current(self):
        if (self._seal is not _SEAL or self._pid != os.getpid()
                or self._thread is not threading.current_thread()
                or _writer() is not self.writer):
            raise ValueError('NORMAL_MAIN_REQUEST_CHANGED')

    def bind_server(self, server, mutex):
        self._current()
        from .owner_normal_close import _OwnerInstanceMutex, OwnerClosePending
        if (self._server is not None or type(mutex) is not _OwnerInstanceMutex
                or mutex.instance is not self.instance or mutex._server is not server
                or server.self_operating_instance is not self.instance
                or server._owner_instance_mutex is not mutex
                or server._self_operating_reads.instance is not self.instance
                or server._self_operating_reads.server is not server
                or server.core.store.directory != self.instance.directory / 'data'
                or server.owner_metadata_recovery is not self.metadata_recovery):
            raise OwnerClosePending('ORIGINAL_SERVER_SCOPE_CHANGED')
        self._server, self._core, self._mutex = server, server.core, mutex

    def bind_metadata_recovery(self):
        self._current()
        if not self.metadata_recovery or self._server is None:
            raise ValueError('ORIGINAL_METADATA_RECOVERY_REQUIRED')
        # This independently checks exact reviewed origin plus current real
        # resources. A journal/PID/empty new Core cannot mint authority here.
        self._mutex.bind_metadata_recovery(self.plan, self.writer)

    def finish(self, capability):
        """One original-main finalizer call, before original mutex release."""
        global _LAST_RECEIPT
        self._current()
        from .owner_normal_close import (_OwnerNormalCloseCapability, _OwnerInstanceMutex,
            OwnerClosePending, owner_physical_closed)
        if capability is None:
            # Root's normal close returns no authority when no Native was
            # submitted and metadata recovery never bound. Only a truly
            # closed original main may record safe held and release normally;
            # None never authorizes a writer call or implies upgrade success.
            mutex = self._mutex
            if (type(mutex) is not _OwnerInstanceMutex or mutex.instance is not self.instance
                    or self._server is None or mutex._server is not self._server
                    or self._core is None or mutex._core is not self._core
                    or self._server.core is not self._core
                    or self._server._owner_instance_mutex is not mutex
                    or not mutex._listener_closed
                    or not mutex._normal_close_confirmed.is_set()
                    or not mutex._lifecycle_closed()
                    or mutex._native_phase != 'not_submitted'
                    or mutex._recovery_key is not None
                    or not owner_physical_closed(self._server)):
                raise OwnerClosePending('ORIGINAL_NO_SUBMISSION_CLOSE_UNCONFIRMED')
            mutex._mechanical()  # Exact seal/fd/held original lock/main-thread.
            self._consumed, self._trusted = True, False
            self._result = _held(self.plan)
            _LAST_RECEIPT = (self, deepcopy(self._result), False)
            return deepcopy(self._result)
        if (type(capability) is not _OwnerNormalCloseCapability
                or capability._mutex is not self._mutex):
            raise OwnerClosePending('ORIGINAL_CLOSE_FINALIZER_REQUIRED')
        if self._consumed:
            # A normal close retry only rechecks retained physical facts. It
            # never calls the writer a second time in this original main.
            capability._mechanical(self.instance)
            result = self._result if self._result is not None else _held(self.plan)
            _LAST_RECEIPT = (self, deepcopy(result), self._trusted)
            return deepcopy(result)
        context = capability.require_writer(self.writer)
        if (context.instance is not self.instance or context.server is not self._server
                or context.core is not self._core or context.pid != self._pid
                or context.owner_thread_id != self._thread.ident
                or context.instance_id != self.plan.summary()['instance_id']
                or context.close_mode != ('metadata_recovery' if self.metadata_recovery else 'native')
                or self.metadata_recovery and context.recovery_key != self.plan.idempotency_key):
            raise OwnerClosePending('ORIGINAL_CLOSED_SCOPE_CHANGED')
        self._consumed = True  # No hidden second commit/retry in this main.
        self._result = _held(self.plan)
        result = self.writer.commit_owner_platform_upgrade(self.plan,
            self.plan.idempotency_key, capability)
        if _bound_result(result, self.plan) and result['state'] != 'succeeded':
            self._result = deepcopy(result)
        # Check retained mechanical/account facts again; failure retains the
        # original main and mutex through the existing close-retry path.
        capability._mechanical(self.instance)
        trusted = False
        if (_bound_result(result, self.plan) and result['state'] == 'succeeded'
                and result['phase'] == 'committed' and result['mutation_committed'] is True):
            try:
                current = open_existing_owner_entry_instance(self.instance.directory,
                    self.instance.work_root, self.instance._wrapper_sha, product='primary_platforms_v2')
                check = self.writer.get_owner_platform_upgrade(current, self.plan.idempotency_key)
                trusted = _bound_result(check, self.plan) and check == result
            except (ImportError, ValueError, RuntimeError, OSError, KeyError, TypeError, AttributeError):
                trusted = False
        if not trusted:
            # Preserve valid pending/held facts; never rewrite journal or infer
            # not_committed from a failed process/finalizer/metadata read.
            if not _bound_result(result, self.plan) or result['state'] == 'succeeded':
                result = _held(self.plan)
        _LAST_RECEIPT = (self, deepcopy(result), trusted)
        self._result, self._trusted = deepcopy(result), trusted
        return deepcopy(result)


def prepare_owner_upgrade_request(instance, *, key=None, metadata_recovery=False):
    """Called only by explicit original-main flags, before actual server start."""
    global _LAST_RECEIPT
    from .self_operating_read import _OwnerReadInstance
    if (type(instance) is not _OwnerReadInstance or type(metadata_recovery) is not bool
            or key is not None and (type(key) is not str or not _HEX.fullmatch(key))
            or metadata_recovery and key is None
            or not metadata_recovery and instance.product != 'xiaohongshu_v1'):
        raise ValueError('ORIGINAL_UPGRADE_REQUEST_REQUIRED')
    writer = _writer()
    plan = writer.prepare_owner_platform_upgrade(instance, key)
    if type(plan) is not writer._UpgradePlan or plan._instance is not instance:
        raise ValueError('ORIGINAL_UPGRADE_PLAN_REQUIRED')
    if metadata_recovery:
        from .owner_normal_close import require_reviewed_writer
        plan.require_closed_origin(instance, require_reviewed_writer(writer))
    _LAST_RECEIPT = None
    return _OwnerUpgradeRequest(_SEAL, instance, writer, plan, metadata_recovery)


class _OwnerMainReceipt:
    __slots__ = ('_seal', '_request', '_result', '_trusted')

    def __init__(self, seal, request, result, trusted):
        if seal is not _SEAL:
            raise ValueError('ORIGINAL_MAIN_RECEIPT_REQUIRED')
        self._seal, self._request = seal, request
        self._result, self._trusted = deepcopy(result), trusted

    def require_completed_main(self, directory):
        request = self._request
        request._current()
        if (self._seal is not _SEAL or request.instance.directory != Path(directory)
                or not request._consumed or request._mutex is None
                or request._mutex._released is not True or not request._mutex._file.closed
                or not self._trusted):
            raise ValueError('ORIGINAL_MAIN_RELEASE_UNCONFIRMED')
        return deepcopy(self._result)

    def summary(self):
        return {'result': deepcopy(self._result), 'trusted_committed': self._trusted,
            'same_process_normal_main': True}


def take_owner_main_receipt(directory, key=None):
    """Consume this main's RAM result; running.json alone never reports upgrade."""
    global _LAST_RECEIPT
    item, _LAST_RECEIPT = _LAST_RECEIPT, None
    if item is None:
        return None
    request, result, trusted = item
    request._current()
    if (request.instance.directory != Path(directory) or not request._consumed
            or key is not None and key != request.plan.idempotency_key):
        return None
    return _OwnerMainReceipt(_SEAL, request, result, trusted)
