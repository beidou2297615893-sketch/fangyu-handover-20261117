"""Independent source/internal material review for original natural session recovery.

Only this explicit recovery decision permits its original owner to obtain a
local session candidate. Original identity/cloud-claim/journal gates remain
mandatory; collection/send/publish and customer distribution are not granted.
"""
from dataclasses import dataclass
import json
from pathlib import Path
import sys

from .xhs_page_read_policy import _path, _sha, _digest, _KNOWN_RUNTIME, _ROLES


_SEAL = object()
_REVIEW_SHA = '941D9353586DC2A01FAE47FB10023B53B5E0A7FE3C731426271716D31F610832'
_ROUTE = 'natural_session_recovery_v1'
_USE = 'natural_session_recovery'


class SessionReviewRequired(ValueError):
    def __init__(self):
        super().__init__('xhs_session_review_unavailable')


@dataclass(frozen=True, slots=True, repr=False)
class _SessionRecoveryDecision:
    seal: object
    policy: object
    revision: str
    materials: tuple
    licenses: tuple
    binding: str
    route: str = _ROUTE
    usage_scope: str = _USE
    customer: object = None

    @property
    def expected_materials(self):
        return self.materials

    def _current(self):
        if self.customer is not None:
            from .customer_natural_materials import _NaturalMaterials
            if self.seal is not _SEAL or type(self.policy) is not XhsSessionRecoveryPolicy or type(self.customer) is not _NaturalMaterials:
                raise SessionReviewRequired()
            self.customer.check(self)
            return
        if (self.seal is not _SEAL or type(self.policy) is not XhsSessionRecoveryPolicy
                or self.policy._decision is not self or self.route != _ROUTE
                or self.usage_scope != _USE or self.policy._snapshot() != self.binding):
            raise SessionReviewRequired()
        self.policy._verify_revision(self)

    def check(self, scope, creation_spec, execution_context):
        from .xhs_session_context import _SessionExecutionContext
        from .xhs_session_scope import _SessionScope
        from xhs_page_window import BridgeSpec
        from .xhs_customer_account_runtime import account_runtime_matches
        self._current()
        if self.customer is not None:self.customer.check_execution(scope)
        if (type(scope) is not _SessionScope or type(execution_context) is not _SessionExecutionContext
                or scope.app_context is not execution_context
                or not account_runtime_matches(self.policy.server,scope.runtime)
                or type(creation_spec) is not BridgeSpec
                or creation_spec.read_mode != 'natural' or creation_spec.purpose != 'session_recovery'
                or creation_spec.tenant_id != scope.tenant or creation_spec.account_id != scope.account_id
                or creation_spec.profile_dir != scope.root/'xhs-browser-profile'):
            raise SessionReviewRequired()
        if current_session_decision(self.policy.server.core) is not self:
            raise SessionReviewRequired()
        execution_context.check()
        account = self.policy.server.core._get('accounts',scope.account_id,scope.tenant)
        if creation_spec.bound_uid != str(account.get('platform_uid') or ''):
            raise SessionReviewRequired()
        scope.check()

    def check_materials(self, facts):
        """Original owner facts, not child approval booleans or full memory proof."""
        self._current()
        if self.customer is not None:
            self.customer.check_loaded(self,facts)
            return
        if not isinstance(facts,dict) or facts.get('contract')!='page_ready_sources_v1':
            raise SessionReviewRequired()
        bound=facts.get('bound_materials')
        if (not isinstance(bound,(tuple,list)) or len(bound)!=len(self.materials)
                or tuple(tuple(item[:3]) for item in bound if isinstance(item,(tuple,list)) and len(item)==4)!=self.materials):
            raise SessionReviewRequired()
        loaded=set()
        for name in ('python_modules','native_modules','managed_assemblies','browser_modules'):
            entries=facts.get(name)
            if not isinstance(entries,(tuple,list)) or len(entries)>8192:
                raise SessionReviewRequired()
            loaded.update(str(_path(entry)).casefold() for entry in entries)
        loaded.update(str(_path(facts.get(key))).casefold() for key in ('helper_image','browser_image'))
        for role in ('native_runtime','managed_runtime','webview_runtime'):
            if not any(item[2]==role and str(_path(item[0])).casefold() in loaded for item in self.materials):
                raise SessionReviewRequired()
        approved={str(_path(item[0])).casefold() for item in self.materials}
        for name in ('python_modules','managed_assemblies'):
            if any(str(_path(entry)).casefold() not in approved for entry in facts[name]):
                raise SessionReviewRequired()


class XhsSessionRecoveryPolicy:
    def __init__(self,server):
        self.server, self._decision = server, None
        self._review_path=Path(__file__).resolve().parents[1]/'resources/xhs-session-recovery/review.json'
        try:
            binding=self._snapshot()
            if _sha(_path(str(self._review_path)))!=_REVIEW_SHA:
                return
            review=json.loads(self._review_path.read_text('utf-8'))
            if (review.get('schema')!='xhs_session_material_review_v1'
                    or review.get('route')!=_ROUTE or review.get('usage_scope')!=_USE
                    or review.get('purpose')!='session_recovery'
                    or review.get('loaded_provenance_criterion')!='two_stable_origins_file_identity_hash'
                    or review.get('native_loaded_bytes_verified') is not False):
                return
            materials=self._entries(review.get('materials'),roles=True)
            licenses=self._entries(review.get('licenses'),roles=False)
            if set(item[2] for item in materials)!=_ROLES or len(licenses)<10:
                return
            self._decision=_SessionRecoveryDecision(_SEAL,self,_REVIEW_SHA,materials,licenses,binding)
            self._verify_materials(self._decision)
        except (OSError,ValueError,TypeError,KeyError,AttributeError):
            self._decision=None

    def _entries(self,raw,*,roles):
        if not isinstance(raw,list) or not 1<=len(raw)<=8192:
            raise SessionReviewRequired()
        result=[]
        source_root=Path(__file__).resolve().parents[1]
        for entry in raw:
            if not isinstance(entry,dict) or set(entry)!={'path','sha256','role'}:
                raise SessionReviewRequired()
            value=entry['path']
            path=source_root/value[7:] if isinstance(value,str) and value.startswith('source:') else _path(value)
            path=_path(str(path))
            if isinstance(value,str) and value.startswith('source:') and not path.is_relative_to(source_root):
                raise SessionReviewRequired()
            sha,role=entry['sha256'],entry['role']
            if (not isinstance(sha,str) or len(sha)!=64 or any(c not in '0123456789ABCDEF' for c in sha)
                    or roles and role not in _ROLES or not roles and role!='license'):
                raise SessionReviewRequired()
            result.append((str(path),sha,role))
        if len({str(item[0]).casefold() for item in result})!=len(result):
            raise SessionReviewRequired()
        return tuple(result)

    def _snapshot(self):
        from app import AppServer
        from .xhs_app_context import XhsAppHostContext
        from .xhs_page_runtime import XhsPageRuntime
        server=self.server
        runtime=getattr(server,'xhs_page_runtime',None)
        if (type(server) is not AppServer or getattr(sys,'frozen',False)
                or getattr(server,'_xhs_session_policy',self) is not self
                or server._runtime_license_usage_scope('internal_self_use_read')!='internal_self_use_read'
                or type(server._xhs_app_context) is not XhsAppHostContext
                or server._xhs_app_context._server is not server or type(runtime) is not XhsPageRuntime
                or runtime is not server.core.adapters.xhs_page_runtime
                or runtime.core is not server.core or not runtime.natural_mode or runtime.closed
                or runtime.app_context_factory is not server._xhs_app_context or getattr(server,'closing',False)):
            raise SessionReviewRequired()
        for config in (server.company,server.core.deployment_config):
            conf=config.get('runtime')
            if (config.get('id')!='fangyu-apartment-client' or config.get('releaseVersion')!='1.1.7-qa.1'
                    or not isinstance(conf,dict) or set(conf)-_KNOWN_RUNTIME
                    or conf.get('xiaohongshu_automation') not in ('hold','enabled')
                    or conf.get('release_approved') not in (None,False)
                    or conf.get('xiaohongshu_automation')=='enabled' and not conf.get('platform_qa_device_id')):
                raise SessionReviewRequired()
        own_path=_path(str(Path(__file__).resolve()))
        # The reused path/hash helpers are source-bound with this independent
        # carrier. Both carriers stay outside their own revision digest cycle.
        helper_path=_path(str(Path(__file__).with_name('xhs_page_read_policy.py').resolve()))
        return _digest((server.company,server.core.deployment_config,str(own_path),_sha(own_path),
            str(helper_path),_sha(helper_path),str(self._review_path)))

    def _verify_revision(self,decision):
        if _sha(_path(str(self._review_path)))!=decision.revision:
            raise SessionReviewRequired()

    def _verify_materials(self,decision):
        self._verify_revision(decision)
        for path,sha,_ in decision.materials+decision.licenses:
            if _sha(_path(path))!=sha:
                raise SessionReviewRequired()

    def resolve(self):
        if getattr(self.server,'_customer_natural_component',False):
            from .customer_natural_materials import resolve_customer
            return resolve_customer(self,_SessionRecoveryDecision,_SEAL,'xiaohongshu_session_recovery')
        try:
            if type(self._decision) is not _SessionRecoveryDecision:
                return None
            self._decision._current()
            return self._decision
        except (OSError,ValueError,TypeError,KeyError,AttributeError):
            return None

    def describe(self):
        """Static UX selection only; no actor or profile/execution approval."""
        from .xhs_page_runtime import XhsPageRuntime
        from .xhs_customer_account_runtime import runtime_for
        runtime=runtime_for(self.server)
        value=dict(status='unsupported',reason='source_scope_unavailable',
            purpose='session_recovery')
        if type(runtime) is not XhsPageRuntime or not runtime.natural_mode:
            return value
        if getattr(self.server,'_customer_natural_component',False):
            if self.resolve() is not None:
                value.update(status='available',reason='ready_for_explicit_recovery')
            else:value.update(status='blocked',reason='customer_material_review_unavailable')
            return value
        try:
            self._snapshot()
        except (OSError,ValueError,TypeError,KeyError,AttributeError):
            value['status']='blocked'
            return value
        value.update(status='blocked',reason='session_material_review_unavailable')
        if self.resolve() is not None:
            value.update(status='available',reason='ready_for_explicit_session_recovery')
        return value


def current_session_decision(core):
    from .xhs_session_context import current_session_context
    context=current_session_context(core)
    if context is None:
        return None
    server=context.claim.session.service.server
    policy=getattr(server,'_xhs_session_policy',None)
    if type(policy) is not XhsSessionRecoveryPolicy:
        return None
    return policy.resolve()
