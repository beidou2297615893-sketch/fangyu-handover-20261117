"""Local image-note drafts and conservative XHS CLI receipts; no I/O to platforms.

Upstream creator.post takes repeated --images/--topic and emits formatter_utils'
{ok, schema_version: '1', data}. It does NOT document a publish receipt field.
Only an independently verified, explicit data field may establish publication.
The caller must persist 'sending' before execution and recover it as 'unknown'.
"""
import json
import re
import html
from pathlib import Path


class PublicationError(ValueError):
    pass


def zhihu_question_url(value):
    match = re.fullmatch(r'https://www\.zhihu\.com/question/([1-9][0-9]{0,31})/?(?:\?[^\s#]*)?(?:#[^\s]*)?', str(value or '').strip())
    if not match:
        raise PublicationError('请填写知乎问题完整链接：https://www.zhihu.com/question/问题ID')
    return 'https://www.zhihu.com/question/' + match.group(1)


def build_zhihu_answer_args(draft, profile, body_path):
    from .zhihu import profile_id
    draft = normalize_draft(draft)
    if draft['platform'] != 'zhihu' or not Path(body_path).is_absolute():
        raise PublicationError('知乎回答参数无效')
    return ['--profile', profile_id(profile), 'zhihu', 'answer', draft['question_url'],
            '--file', str(body_path), '--execute', '-f', 'json']


def zhihu_answer_html(body):
    # The upstream API takes HTML; authoring is plain text, not executable markup.
    return ''.join('<p>' + html.escape(line) + '</p>' for line in body.splitlines())


def _text(value, label, limit):
    if not isinstance(value, str) or '\x00' in value:
        raise PublicationError(label + '格式无效')
    value = value.strip()
    if not value or len(value) > limit:
        raise PublicationError(f'{label}须为1—{limit}个字符')
    return value


def normalize_draft(data):
    """Return only editable fields; reject arbitrary paths/status/tenant injection.

20/1000/9/10 are this product's conservative authoring limits, not a claim
about the current platform's maximum allowance.
"""
    if not isinstance(data, dict):
        raise PublicationError('发布草稿格式无效')
    if data.get('platform') == 'zhihu':
        if data.get('asset_ids') or data.get('topics') or data.get('private'):
            raise PublicationError('知乎回答当前支持公开纯文字，不支持图片、话题或私密发布')
        return {'platform': 'zhihu', 'account_id': _text(data.get('account_id'), '发布账号', 128),
                'title': _text(data.get('title'), '本地草稿名称', 120),
                'question_url': zhihu_question_url(data.get('question_url')),
                'body': _text(data.get('body'), '回答正文', 10000),
                'asset_ids': [], 'topics': [], 'private': False}
    if data.get('platform', 'xiaohongshu') != 'xiaohongshu':
        raise PublicationError('当前图文发布仅支持小红书')
    account = _text(data.get('account_id'), '发布账号', 128)
    ids = data.get('asset_ids')
    if not isinstance(ids, list) or not 1 <= len(ids) <= 9:
        raise PublicationError('请选择1—9张图片素材')
    ids = [_text(item, '素材ID', 128) for item in ids]
    if len(set(ids)) != len(ids):
        raise PublicationError('图片素材不可重复')
    topics = data.get('topics', [])
    if not isinstance(topics, list) or len(topics) > 10:
        raise PublicationError('话题须为列表，最多10个')
    topics = list(dict.fromkeys(_text(item, '话题', 100).lstrip('#') for item in topics))
    if any(not topic or any(c.isspace() for c in topic) for topic in topics):
        raise PublicationError('话题不能为空或包含空白')
    private = data.get('private', False)
    if not isinstance(private, bool):
        raise PublicationError('可见范围必须为布尔值')
    return {'platform': 'xiaohongshu', 'account_id': account,
            'title': _text(data.get('title'), '标题', 20),
            'body': _text(data.get('body'), '正文', 1000),
            'asset_ids': ids, 'topics': topics, 'private': private}


def resolve_image_paths(draft, assets, tenant_id, assets_root):
    """Resolve trusted store rows, enforce tenant and real file containment.

assets_root is the current tenant's directory, not the all-tenant root.
"""
    draft = normalize_draft(draft)
    root = Path(assets_root).resolve()
    by_id = {row.get('id'): row for row in assets
             if isinstance(row, dict) and row.get('tenant_id') == tenant_id}
    paths = []
    for identifier in draft['asset_ids']:
        row = by_id.get(identifier)
        if not row or not isinstance(row.get('path'), str):
            raise PublicationError('图片不存在或不属于当前企业')
        path = Path(row['path']).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise PublicationError('图片必须位于当前企业素材目录且文件存在')
        if path.suffix.lower() not in {'.jpg', '.jpeg', '.png', '.webp', '.gif'}:
            raise PublicationError('发布仅接受图片素材')
        paths.append(str(path))
    return paths


def build_xhs_args(draft, image_paths):
    """Pass result to adapters.execute('xiaohongshu', ..., account_dir=...).

Never join this list into shell text. Resolve account ownership in the caller.
This only builds arguments; the upstream CLI must separately disable POST retries.
"""
    draft = normalize_draft(draft)
    if len(image_paths) != len(draft['asset_ids']):
        raise PublicationError('图片解析结果与草稿不一致')
    args = ['post', '--title', draft['title'], '--body', draft['body'], '--json']
    for path in image_paths:
        if not isinstance(path, str) or not Path(path).is_absolute() or '\x00' in path:
            raise PublicationError('图片路径必须是已解析的绝对路径')
        args.extend(['--images', path])
    for topic in draft['topics']:
        args.extend(['--topic', topic])
    if draft['private']:
        args.append('--private')
    return args


def unknown_outcome(reason='发布结果无法确认，请到平台核实；不要重复发送'):
    return {'status': 'unknown', 'message': reason, 'automatic_retry': False}


def parse_xhs_receipt(payload, returncode=0, note_id_field=None):
    """Accept the upstream envelope, never infer success from exit 0 or 'ok'.

note_id_field must come from a verified version-specific receipt contract, NOT
from an end-user request. No such contract is established by upstream fixtures.
Unknown schema/transport/error responses remain unknown after a send attempt.
"""
    if returncode != 0:
        return unknown_outcome('CLI未正常完成，发布结果需人工核实')
    if isinstance(payload, (str, bytes)):
        try:
            payload = json.loads(payload)
        except (ValueError, UnicodeError):
            return unknown_outcome('发布回执不是有效JSON，需人工核实')
    if not isinstance(payload, dict) or payload.get('ok') is not True or payload.get('schema_version') != '1':
        return unknown_outcome('发布回执失败或结构未知，需人工核实')
    data = payload.get('data')
    if not isinstance(data, dict) or not note_id_field:
        return unknown_outcome('CLI已返回，但尚无可核验的笔记ID回执契约')
    if not isinstance(note_id_field, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', note_id_field):
        raise PublicationError('回执字段配置无效')
    note_id = data.get(note_id_field)
    if not isinstance(note_id, str) or not re.fullmatch(r'[0-9a-fA-F]{24}', note_id):
        return unknown_outcome('发布回执缺少有效笔记ID，需人工核实')
    return {'status': 'published', 'note_id': note_id,
            'url': 'https://www.xiaohongshu.com/explore/' + note_id,
            'automatic_retry': False}


def recover_publication(record):
    """Process death while sending is ambiguous; recovery never queues a resend."""
    result = dict(record)
    if result.get('status') == 'sending':
        result.update(unknown_outcome('工作台在发布过程中关闭，需到平台核实结果'))
    return result
