"""Private, bounded originals from an owned successful Weibo search.

Stage only. The trusted host creates this index and retains the returned writer
capability. A comments runner receives only ``index.resolve_post``; neither the
factory nor the writer is an RPC/payload operation. The host must obtain raw
posts from its own successful search and origin IDs/digest from its owned
receipt, never from a comments request. Python object privacy is not a process
security boundary: exposing the writer to an untrusted process is unsupported.

``live_authority(binding, operation)`` must consult the host's CURRENT actor,
device, account, credential, permission and licence authority, raising on denial
and returning its freshly checked OwnedSearchScope. A fixed scope/True callback
does not satisfy that host contract. This module performs no account-file,
platform, receipt-archive, child-process or production-route IO.
"""
from collections import OrderedDict
from dataclasses import dataclass
from hmac import compare_digest
import json
import math
from pathlib import Path
import re
from threading import RLock


class OwnedPostIndexStopped(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class OwnedSearchScope:
    tenant_id: str
    owner_id: str
    device_id: str
    account_id: str
    account_root: Path
    platform_uid: str
    credential_sha256: str
    permission_revision: int


@dataclass(frozen=True)
class OwnedSearchOrigin:
    read_request_id: str
    receipt_id: str
    receipt_sha256: str


@dataclass(frozen=True)
class _OriginalPost:
    raw_json: bytes
    origin: OwnedSearchOrigin


_MID = re.compile(r'[1-9][0-9]{0,31}')
_BID = re.compile(r'[A-Za-z0-9]{1,32}')
_SHA = re.compile(r'[0-9a-f]{64}')
_SCOPE_ID = re.compile(r'[A-Za-z0-9_.-]{1,128}')


def _valid_scope(scope):
    if not isinstance(scope, OwnedSearchScope):
        return False
    identifiers = (scope.tenant_id, scope.owner_id, scope.device_id, scope.account_id)
    root = scope.account_root
    return (all(isinstance(value, str) and _SCOPE_ID.fullmatch(value) for value in identifiers)
            and isinstance(root, Path) and root.is_absolute() and '..' not in root.parts
            and root.name == scope.account_id and root.parent.name == scope.tenant_id
            and isinstance(scope.platform_uid, str) and _MID.fullmatch(scope.platform_uid)
            and isinstance(scope.credential_sha256, str) and _SHA.fullmatch(scope.credential_sha256)
            and type(scope.permission_revision) is int and scope.permission_revision >= 0)


def _valid_origin(origin):
    return (isinstance(origin, OwnedSearchOrigin)
            and all(isinstance(value, str) and _SCOPE_ID.fullmatch(value)
                    for value in (origin.read_request_id, origin.receipt_id))
            and isinstance(origin.receipt_sha256, str) and _SHA.fullmatch(origin.receipt_sha256))


def _identifier(row):
    # Same idstr/id agreement required by weibo_read_transport._known_post_url;
    # no bid fallback, numeric-URL guessing or detail GET is permitted here.
    values = [str(row[name]) for name in ('idstr', 'id') if name in row]
    if not values or not _MID.fullmatch(values[0]) or any(value != values[0] for value in values):
        raise OwnedPostIndexStopped('owned_post_source_invalid')
    return values[0]


def _json_value(value, depth=0):
    # Raw transport JSON must round-trip as an unchanged original copy.
    if depth > 32:
        raise OwnedPostIndexStopped('owned_post_source_invalid')
    if type(value) in (str, int, bool, type(None)):
        return
    if type(value) is float and math.isfinite(value):
        return
    if type(value) is list:
        for item in value:
            _json_value(item, depth + 1)
        return
    if type(value) is dict and all(type(key) is str for key in value):
        for item in value.values():
            _json_value(item, depth + 1)
        return
    raise OwnedPostIndexStopped('owned_post_source_invalid')


def _encode_original(post):
    if type(post) is not dict or type(post.get('user')) is not dict:
        raise OwnedPostIndexStopped('owned_post_source_invalid')
    mid = _identifier(post)
    _identifier(post['user'])
    if not isinstance(post.get('bid'), str) or not _BID.fullmatch(post['bid']):
        raise OwnedPostIndexStopped('owned_post_source_invalid')
    _json_value(post)
    try:
        encoded = json.dumps(post, sort_keys=True, ensure_ascii=False,
                             allow_nan=False, separators=(',', ':')).encode('utf-8')
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise OwnedPostIndexStopped('owned_post_source_invalid') from None
    return mid, encoded


class OwnedSearchPostIndex:
    """One immutable account/actor scope; comments can resolve numeric mids only."""

    def __init__(self, scope, *, live_authority, max_posts=256, max_bytes=2 * 1024 * 1024):
        if not _valid_scope(scope) or not callable(live_authority):
            raise OwnedPostIndexStopped('owned_search_scope_invalid')
        if (type(max_posts) is not int or not 1 <= max_posts <= 4096
                or type(max_bytes) is not int or not 1 <= max_bytes <= 8 * 1024 * 1024):
            raise OwnedPostIndexStopped('owned_search_capacity_invalid')
        self._scope = scope
        self._live_authority = live_authority
        self._max_posts, self._max_bytes = max_posts, max_bytes
        self._entries = OrderedDict()
        self._lock = RLock()
        self._writer_token = object()

    @classmethod
    def for_trusted_host(cls, scope, *, live_authority, max_posts=256, max_bytes=2 * 1024 * 1024):
        """Return (resolver owner, host-only writer capability), never payload IO."""
        index = cls(scope, live_authority=live_authority,
                    max_posts=max_posts, max_bytes=max_bytes)
        token = index._writer_token

        def record_owned_search(binding, raw_posts, *, origin):
            return index._record_owned_search(token, binding, raw_posts, origin)

        return index, record_owned_search

    def _check_current(self, binding, operation):
        scope = self._scope
        try:
            matching_binding = (
                binding.identity_verified is True and binding.tenant_id == scope.tenant_id
                and binding.account_id == scope.account_id and binding.platform_uid == scope.platform_uid
                and Path(binding.account_root) == scope.account_root
                and isinstance(binding.credential_sha256, str)
                and compare_digest(binding.credential_sha256.lower(), scope.credential_sha256))
        except (AttributeError, TypeError, ValueError):
            matching_binding = False
        if not matching_binding:
            raise OwnedPostIndexStopped('owned_search_binding_mismatch')
        current = self._live_authority(binding, operation)
        if not _valid_scope(current) or current != scope:
            raise OwnedPostIndexStopped('owned_search_scope_changed')

    def _record_owned_search(self, token, binding, raw_posts, origin):
        if token is not self._writer_token:
            raise OwnedPostIndexStopped('owned_search_writer_required')
        with self._lock:
            self._check_current(binding, 'search')
            if not _valid_origin(origin):
                raise OwnedPostIndexStopped('owned_search_origin_required')
            if type(raw_posts) is not list or len(raw_posts) > self._max_posts:
                raise OwnedPostIndexStopped('owned_search_capacity_exceeded')
            prepared = OrderedDict()
            for raw in raw_posts:
                mid, encoded = _encode_original(raw)
                existing = prepared.get(mid) or self._entries.get(mid)
                if existing is not None and existing.raw_json != encoded:
                    raise OwnedPostIndexStopped('duplicate_owned_post_conflict')
                prepared[mid] = existing or _OriginalPost(encoded, origin)
            if sum(len(row.raw_json) for row in prepared.values()) > self._max_bytes:
                raise OwnedPostIndexStopped('owned_search_capacity_exceeded')
            # Validate and prepare the entire batch before committing; an invalid
            # or conflicting original cannot leave a partially imported result.
            planned = self._entries.copy()
            for mid, row in prepared.items():
                planned[mid] = row
                planned.move_to_end(mid)
            total = sum(len(row.raw_json) for row in planned.values())
            while len(planned) > self._max_posts or total > self._max_bytes:
                _, evicted = planned.popitem(last=False)
                total -= len(evicted.raw_json)
            self._check_current(binding, 'search')
            self._entries = planned
            return len(prepared)

    def resolve_post(self, binding, numeric_mid):
        """Return a fresh original JSON copy, only under current identical authority."""
        with self._lock:
            self._check_current(binding, 'comments')
            if not isinstance(numeric_mid, str) or not _MID.fullmatch(numeric_mid):
                raise OwnedPostIndexStopped('owned_post_numeric_mid_required')
            row = self._entries.get(numeric_mid)
            if row is None:
                raise OwnedPostIndexStopped('owned_post_source_required')
            result = json.loads(row.raw_json)
            self._check_current(binding, 'comments')
            return result
