"""Read-only Windows process metadata; raw command lines stay in memory."""
import ctypes
import hashlib
import json
import ntpath
import os
from pathlib import Path
import re
import subprocess

from .runtime_materials import _checked_path

HERE = Path(__file__).resolve().parent
_BROWSER = {'msedgewebview2.exe', 'msedge.exe', 'chrome.exe', 'chromium.exe'}
_PYTHON = re.compile(r'python(?:w|\d+(?:\.\d+)?)?\.exe\Z', re.I)
_FIELDS = {'pid', 'parent_pid', 'created', 'name', 'executable', 'command_line', 'owner_sid'}


def _executable_key(value):
    """Exact Windows spelling for matching fixed runtime routes only."""
    if not isinstance(value, str) or not value or any(ord(c) < 32 for c in value):
        raise ValueError('executable_unavailable')
    value = value.replace('/', '\\')
    if value.startswith('\\\\?\\'):
        value = value[4:]
    drive, rest = ntpath.splitdrive(value)
    if (not re.fullmatch(r'[A-Za-z]:', drive) or not rest.startswith('\\')
            or ':' in rest or '%' in value
            or any(part in ('.', '..') or part.endswith((' ', '.')) for part in rest.split('\\') if part)):
        raise ValueError('executable_unavailable')
    return ntpath.normcase(ntpath.normpath(value))


class TrustedCurrentPython:
    """Internal fixed_interpreter/cfg/material binding, never an HTTP grant."""
    def __init__(self):
        self._binding = self._capture()

    @staticmethod
    def _capture():
        from .runtime_materials import digest, fixed_interpreter
        shim, alias, base, configuration = fixed_interpreter()
        routes = {_executable_key(str(path)): canonical_path(str(path.resolve(strict=True)))
            for path in (shim, alias, base)}
        return {'routes': routes, 'configuration_sha': digest(configuration),
            'shim_sha': digest(shim), 'base_sha': digest(base)}

    def validate(self):
        return self._capture() == self._binding

    def executable(self, value, owner_sid, current_sid):
        if owner_sid != current_sid:
            raise ValueError('executable_owner_unavailable')
        expected = self._binding['routes'].get(_executable_key(value))
        if expected is None or canonical_path(str(Path(value).resolve(strict=True))) != expected:
            raise ValueError('executable_binding_unavailable')
        return expected


def windows_argv(command_line):
    if os.name != 'nt' or not isinstance(command_line, str) or not command_line or '\0' in command_line:
        raise ValueError('argv_unavailable')
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes, kernel.LocalFree.restype = [ctypes.c_void_p], ctypes.c_void_p
    count = ctypes.c_int()
    pointer = shell.CommandLineToArgvW(command_line, ctypes.byref(count))
    if not pointer:
        raise ValueError('argv_unavailable')
    try:
        if not 1 <= count.value <= 256:
            raise ValueError('argv_unavailable')
        return [pointer[index] for index in range(count.value)]
    finally:
        kernel.LocalFree(pointer)


def canonical_path(value):
    """No substring, environment expansion, relative/ADS/reparse ambiguity."""
    if not isinstance(value, str) or not value or len(value) > 32760 or any(ord(c) < 32 for c in value):
        raise ValueError('path_unavailable')
    value = value.replace('/', '\\')
    if value.startswith('\\\\?\\'):
        value = value[4:]
    drive, rest = ntpath.splitdrive(value)
    if not re.fullmatch(r'[A-Za-z]:', drive) or not rest.startswith('\\') or ':' in rest or '%' in value:
        raise ValueError('path_unavailable')
    parts = [part for part in rest.split('\\') if part]
    if any(part in ('.', '..') or part.endswith((' ', '.')) for part in parts):
        raise ValueError('path_unavailable')
    if os.name == 'nt':
        value = str(_checked_path(Path(value)).resolve())
    return ntpath.normcase(ntpath.normpath(value))


def _profile_argument(argv):
    values = []
    for index, argument in enumerate(argv):
        for flag in ('--profile-dir', '--user-data-dir'):
            if argument == flag:
                if index+1 >= len(argv) or argv[index+1].startswith('--'):
                    raise ValueError('profile_argument_unavailable')
                values.append(argv[index+1])
            elif argument.startswith(flag+'='):
                values.append(argument[len(flag)+1:])
    if len(values) != 1:
        raise ValueError('profile_argument_missing' if not values else 'profile_argument_unavailable')
    return canonical_path(values[0])


def classify(snapshot, profile, *, owned=None, expected_browser=None, trusted_python=None):
    """Only a real Job Object membership callback can exempt this job's tree."""
    uncertain, occupied = False, False
    private = []
    try:
        target = canonical_path(str(profile))
        if (not isinstance(snapshot, dict) or set(snapshot) not in (
                    {'current_sid', 'processes', 'complete'}, {'current_sid', 'processes', 'complete', 'default_profiles'})
                or snapshot['complete'] is not True or not isinstance(snapshot['current_sid'], str)
                or not snapshot['current_sid'].startswith('S-1-') or not isinstance(snapshot['processes'], list)
                or len(snapshot['processes']) > 4096):
            raise ValueError('process_metadata_unavailable')
        processes = {}
        from assistant.customer_natural_materials import _PortableHelperBinding
        if trusted_python is not None and (
                not isinstance(trusted_python, TrustedCurrentPython) and type(trusted_python) is not _PortableHelperBinding or not trusted_python.validate()):
            raise ValueError('python_binding_unavailable')
        for row in snapshot['processes']:
            if not isinstance(row, dict) or set(row) != _FIELDS or type(row['pid']) is not int or row['pid'] <= 0:
                raise ValueError('process_metadata_unavailable')
            if row['pid'] in processes:
                raise ValueError('process_metadata_unavailable')
            processes[row['pid']] = row
        def executable_for(value, row):
            try:
                return canonical_path(value)
            except Exception:
                if trusted_python is None or not _PYTHON.fullmatch(row['name']):
                    raise
                return trusted_python.executable(value, row['owner_sid'], snapshot['current_sid'])
        def path_for(row, seen):
            if row['pid'] in seen:
                raise ValueError('process_metadata_unavailable')
            argv = windows_argv(row['command_line'])
            try:
                return _profile_argument(argv)
            except ValueError as error:
                if str(error) != 'profile_argument_missing':
                    raise
                defaults = snapshot.get('default_profiles', [])
                if not isinstance(defaults, list) or len(defaults) > 32:
                    raise ValueError('default_profile_unavailable')
                for route in defaults:
                    if (not isinstance(route, dict) or set(route) != {'executable', 'profile', 'owner_sid', 'policy_state'}):
                        raise ValueError('default_profile_unavailable')
                    if (row['owner_sid'] == route['owner_sid'] == snapshot['current_sid']
                            and canonical_path(row['executable']) == canonical_path(route['executable'])):
                        if route['policy_state'] != 'resolved':
                            raise ValueError('default_profile_unavailable')
                        return canonical_path(route['profile'])
                parent = processes.get(row['parent_pid'])
                # Chromium subprocesses may inherit their root browser profile.
                # Never infer ownership from parent PID alone or an older child.
                if (row['name'].lower() in _BROWSER and parent
                        and isinstance(parent['created'], int) and isinstance(row['created'], int)
                        and parent['created'] <= row['created'] and parent['owner_sid'] == row['owner_sid']):
                    return path_for(parent, seen | {row['pid']})
                raise
        for row in processes.values():
            name = row['name'].lower() if isinstance(row['name'], str) else ''
            relevant = name in _BROWSER or bool(_PYTHON.fullmatch(name)) or 'fangyu' in name.lower()
            if not relevant:
                continue
            try:
                if (type(row['parent_pid']) is not int or row['parent_pid'] < 0
                        or type(row['created']) is not int or row['created'] <= 0
                        or not isinstance(row['owner_sid'], str) or not row['owner_sid'].startswith('S-1-')):
                    raise ValueError('process_metadata_unavailable')
                executable = executable_for(row['executable'], row)
                if ntpath.basename(executable).lower() != name:
                    raise ValueError('process_metadata_unavailable')
                argv = windows_argv(row['command_line'])
                if executable_for(argv[0], row) != executable:
                    raise ValueError('process_metadata_unavailable')
                # A normal, fully readable unrelated Python invocation is not
                # an account-owned browser. Incomplete Python metadata is unknown.
                if _PYTHON.fullmatch(name) and not any(
                        flag in arg for arg in argv[1:]
                        for flag in ('browser_login_window.py', 'xhs_page_window.py', '--owned-xhs-', '--profile-dir', '--user-data-dir')):
                    continue
                selected = path_for(row, set())
                matches = selected == target or selected.startswith(target+'\\')
                own = owned(row['pid'], row['created']) if matches and owned is not None else False
                if own is None:
                    raise ValueError('job_membership_unavailable')
                if own is True and name == 'msedgewebview2.exe' and (
                        expected_browser is None or executable != canonical_path(str(expected_browser))):
                    raise ValueError('selected_runtime_mismatch')
                if matches and not (own is True and row['owner_sid'] == snapshot['current_sid']):
                    occupied = True
                private.append([row['pid'], row['parent_pid'], row['created'], executable, selected, row['owner_sid'], own])
            except Exception:
                uncertain = True
        if trusted_python is not None and not trusted_python.validate():
            raise ValueError('python_binding_changed')
        state = 'occupied' if occupied else 'unknown' if uncertain else 'vacant'
        digest = hashlib.sha256(json.dumps(private, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        return {'state': state, 'reason': 'existing_profile_owner' if occupied else
                'process_metadata_unavailable' if uncertain else 'profile_snapshot_vacant', 'fingerprint': digest}
    except Exception:
        return {'state': 'unknown', 'reason': 'process_metadata_unavailable', 'fingerprint': None}

