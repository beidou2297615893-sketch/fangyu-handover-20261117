"""Read process-token user evidence. Never authorize a profile or account.

Reuse the project's native TokenUser/ConvertSidToStringSidW ownership pattern.
PID, SID and token buffers remain within this call and never enter its result.
"""
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re

PROCESS_ACCESS = 0x1000 | 0x00100000  # query limited + synchronize
TOKEN_QUERY = 0x0008
TOKEN_USER_CLASS = 1
WAIT_TIMEOUT = 0x102
DOTNET_FILETIME_EPOCH = 504911232000000000


class SID_AND_ATTRIBUTES(ctypes.Structure):
    _fields_ = [('Sid', ctypes.c_void_p), ('Attributes', wintypes.DWORD)]


class TOKEN_USER(ctypes.Structure):
    _fields_ = [('User', SID_AND_ATTRIBUTES)]


def native_apis():
    if os.name != 'nt':
        raise ValueError('native_read_unavailable')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    advapi = ctypes.WinDLL('advapi32', use_last_error=True)
    signatures = [
        (kernel.OpenProcess, [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
        (kernel.GetProcessTimes, [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4, wintypes.BOOL),
        (kernel.WaitForSingleObject, [wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
        (kernel.CloseHandle, [wintypes.HANDLE], wintypes.BOOL),
        (kernel.LocalFree, [ctypes.c_void_p], ctypes.c_void_p),
        (advapi.OpenProcessToken, [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)], wintypes.BOOL),
        (advapi.GetTokenInformation, [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
            wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
        (advapi.ConvertSidToStringSidW, [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], wintypes.BOOL),
    ]
    for function, arguments, result in signatures:
        function.argtypes, function.restype = arguments, result
    return kernel, advapi


def valid_sid(value):
    return isinstance(value, str) and len(value) <= 256 and re.fullmatch(r'S-1-[0-9]+(?:-[0-9]+)+', value) is not None


class NativeOwnerResolver:
    def __init__(self, *, apis=None):
        self.apis = apis  # only an internal recording API fixture; no constructor IO

    def resolve(self, pid, created, *, current_sid, wmi_sid=None):
        result = dict(contract='process_token_user_evidence_v1', state='unknown', reason='metadata_unavailable',
            owner_current=None, wmi_owner_agrees=None, creation_verified=False,
            running_before=None, running_after=None, token_user_verified=False,
            handles_closed=True, evidence_hash=None)
        # Parent and source validity remain the caller's responsibility. Missing
        # creation cannot be replaced with the time of a newly opened PID.
        if (type(pid) is not int or not 1 <= pid <= 0xffffffff or type(created) is not int or created <= 0
                or not valid_sid(current_sid) or (wmi_sid is not None and not valid_sid(wmi_sid))):
            return result
        process, token, sid_string = None, wintypes.HANDLE(), ctypes.c_void_p()
        token_acquired = sid_allocated = False
        kernel = advapi = None
        sid = None
        try:
            result['reason'] = 'native_read_unavailable'
            kernel, advapi = self.apis if self.apis is not None else native_apis()
            result['reason'] = 'process_open_unavailable'
            process = kernel.OpenProcess(PROCESS_ACCESS, False, pid)
            if not process:
                return result
            result['reason'] = 'creation_unavailable'
            first = self._creation(kernel, process)
            if first is None:
                return result
            if not 0 <= first - created <= 9:
                result['reason'] = 'creation_conflict'
                return result
            result['creation_verified'] = True
            result['reason'] = 'state_unavailable'
            status = kernel.WaitForSingleObject(process, 0)
            if status not in (0, WAIT_TIMEOUT):
                return result
            result['running_before'] = status == WAIT_TIMEOUT
            if not result['running_before']:
                result['reason'] = 'process_not_running'
                return result
            result['reason'] = 'token_open_unavailable'
            if not advapi.OpenProcessToken(process, TOKEN_QUERY, ctypes.byref(token)):
                return result
            token_acquired = True
            result['reason'] = 'token_buffer_unavailable'
            required = wintypes.DWORD()
            ctypes.set_last_error(0)
            success = advapi.GetTokenInformation(token, TOKEN_USER_CLASS, None, 0, ctypes.byref(required))
            if success or ctypes.get_last_error() != 122 or not ctypes.sizeof(TOKEN_USER) <= required.value <= 65536:
                return result
            capacity = required.value
            buffer = ctypes.create_string_buffer(capacity)
            result['reason'] = 'token_user_unavailable'
            if (not advapi.GetTokenInformation(token, TOKEN_USER_CLASS, buffer, capacity, ctypes.byref(required))
                    or not ctypes.sizeof(TOKEN_USER) <= required.value <= capacity):
                return result
            pointer = ctypes.cast(buffer, ctypes.POINTER(TOKEN_USER)).contents.User.Sid
            # TokenUser's SID must lie inside the returned bounded token buffer.
            start = ctypes.addressof(buffer)
            if not pointer or not start <= pointer <= start + required.value - 8:
                return result
            result['reason'] = 'sid_unavailable'
            if not advapi.ConvertSidToStringSidW(pointer, ctypes.byref(sid_string)) or not sid_string.value:
                return result
            sid_allocated = True
            sid = ctypes.wstring_at(sid_string)
            if not valid_sid(sid):
                return result
            result['reason'] = 'creation_unavailable'
            last = self._creation(kernel, process)
            if last != first:
                result['reason'] = 'creation_conflict'
                return result
            result['reason'] = 'state_unavailable'
            status = kernel.WaitForSingleObject(process, 0)
            if status not in (0, WAIT_TIMEOUT):
                return result
            result['running_after'] = status == WAIT_TIMEOUT
            if not result['running_after']:
                result['reason'] = 'process_not_running'
                return result
            result['owner_current'] = sid == current_sid
            result['wmi_owner_agrees'] = None if wmi_sid is None else sid == wmi_sid
            if result['wmi_owner_agrees'] is False:
                result['reason'] = 'owner_conflict'
                return result
            result.update(state='verified', reason='verified', token_user_verified=True,
                evidence_hash=hashlib.sha256(json.dumps(['process_token_user_v1', pid, first, sid],
                    separators=(',', ':')).encode()).hexdigest())
            return result
        except Exception:
            # Keep only our pre-call phase code, never the native exception text.
            reason = result['reason'] if result['reason'] != 'verified' else 'native_read_unavailable'
            result.update(state='unknown', reason=reason, token_user_verified=False, evidence_hash=None)
            return result
        finally:
            closed = True
            if kernel is not None:
                for handle in (token.value if token_acquired else None, process):
                    if handle:
                        try:
                            closed = bool(kernel.CloseHandle(handle)) and closed
                        except Exception:
                            closed = False
                if sid_allocated:
                    try:
                        closed = not kernel.LocalFree(sid_string) and closed
                    except Exception:
                        closed = False
            result['handles_closed'] = bool(closed)
            if not closed:
                result.update(state='unknown', reason='close_unconfirmed', token_user_verified=False, evidence_hash=None)
            sid = None

    @staticmethod
    def _creation(kernel, process):
        values = [wintypes.FILETIME() for _ in range(4)]
        if not kernel.GetProcessTimes(process, *(ctypes.byref(value) for value in values)):
            return None
        return ((int(values[0].dwHighDateTime) << 32) | int(values[0].dwLowDateTime)) + DOTNET_FILETIME_EPOCH
