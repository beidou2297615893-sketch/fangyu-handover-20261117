"""Owner comment-observation purpose. Missing review never grants Native IO.

Resolving/constructing this policy is read-only. Production approval is a fixed
review binding, never a request boolean or the former employee review.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

from .self_operating_acquisition import OwnerAcquisitionError

PURPOSE = 'owner_comment_observation'
USE_CASE = 'internal_self_use_manual_comment_observation'
_SEAL = object()
_APPROVED_REVIEW_SHA = None  # No real purpose was approved in this work batch.
_HEX = re.compile(r'[a-f0-9]{64}\Z')


class _OwnerObservationDecision:
    def __init__(self, policy, review_digest, expected_materials, seal):
        if seal is not _SEAL or type(policy) is not OwnerContactObservationPolicy:
            raise OwnerAcquisitionError('本人网页观察用途未建立')
        self.policy = policy
        self.review_digest = review_digest
        self.expected_materials = tuple(expected_materials)

    def check(self, frame):
        from .owner_web_contact_observation import _OwnerObservationFrame
        if (type(frame) is not _OwnerObservationFrame or frame.decision is not self
                or frame.module.policy is not self.policy
                or frame.spec.review_digest != self.review_digest
                or not self.policy.current(self)):
            raise OwnerAcquisitionError('本人网页观察用途或材料已变化', mutation_committed=None)
        return True

    def check_materials(self, facts):
        # The original page decision's pure material predicates, under this
        # owner's separate purpose. It lends no old employee/page decision.
        from .xhs_page_read_policy import _path
        if not self.policy.current(self) or type(facts) is not dict or facts.get('contract') != 'page_ready_sources_v1':
            raise OwnerAcquisitionError('本人网页观察加载来源未闭合', mutation_committed=None)
        material = tuple((str(path), sha, role) for path, sha, role in self.expected_materials)
        bound = facts.get('bound_materials')
        if (type(bound) not in (tuple, list) or len(bound) != len(material)
                or tuple(tuple(row[:3]) for row in bound if type(row) in (tuple, list) and len(row) == 4) != material):
            raise OwnerAcquisitionError('本人网页观察材料租约不一致', mutation_committed=None)
        loaded = set()
        for name in ('python_modules', 'native_modules', 'managed_assemblies', 'browser_modules'):
            entries = facts.get(name)
            if type(entries) not in (tuple, list) or len(entries) > 8192:
                raise OwnerAcquisitionError('本人网页观察加载来源缺失', mutation_committed=None)
            loaded.update(str(_path(entry)).casefold() for entry in entries)
        loaded.add(str(_path(facts.get('helper_image'))).casefold())
        loaded.add(str(_path(facts.get('browser_image'))).casefold())
        for role in ('native_runtime', 'managed_runtime', 'webview_runtime'):
            if not any(item[2] == role and str(_path(item[0])).casefold() in loaded for item in material):
                raise OwnerAcquisitionError('本人网页观察真实运行时来源缺失', mutation_committed=None)
        approved = {str(_path(item[0])).casefold() for item in material}
        for name in ('python_modules', 'managed_assemblies'):
            if any(str(_path(entry)).casefold() not in approved for entry in facts[name]):
                raise OwnerAcquisitionError('本人网页观察含未审核加载来源', mutation_committed=None)


class OwnerContactObservationPolicy:
    def __init__(self, workspace):
        self.workspace = workspace
        self.review_path = Path(__file__).resolve().parents[1] / 'resources' / 'owner-contact-observation' / 'review.json'

    def _review(self):
        if (getattr(sys, 'frozen', False) is True or _APPROVED_REVIEW_SHA is None
                or not isinstance(_APPROVED_REVIEW_SHA, str)
                or not _HEX.fullmatch(_APPROVED_REVIEW_SHA.lower())):
            return None
        try:
            if self.review_path.is_symlink() or not self.review_path.is_file():
                return None
            raw = self.review_path.read_bytes()
            if len(raw) > 256 * 1024 or hashlib.sha256(raw).hexdigest().upper() != _APPROVED_REVIEW_SHA.upper():
                return None
            value = json.loads(raw)
        except (OSError, ValueError, TypeError):
            return None
        fields = {'contract', 'purpose', 'use_case', 'status', 'approved', 'edition', 'materials'}
        if (type(value) is not dict or set(value) != fields
                or value['contract'] != 'owner_comment_observation_review_v1'
                or value['purpose'] != PURPOSE or value['use_case'] != USE_CASE
                or value['status'] != 'approved' or value['approved'] is not True
                or value['edition'] != 'owner' or type(value['materials']) is not list
                or not 1 <= len(value['materials']) <= 256):
            return None
        materials = []
        for row in value['materials']:
            if (type(row) is not dict or set(row) != {'path', 'sha256', 'role'}
                    or type(row['path']) is not str or not Path(row['path']).is_absolute()
                    or type(row['sha256']) is not str or not _HEX.fullmatch(row['sha256'].lower())
                    or type(row['role']) is not str or not row['role']):
                return None
            materials.append((Path(row['path']), row['sha256'].upper(), row['role']))
        return hashlib.sha256(raw).hexdigest(), tuple(materials)

    def resolve(self, frame=None):
        current = self._review()
        if current is None:
            return None
        if frame is not None:
            decision = frame.decision
            if (type(decision) is not _OwnerObservationDecision or decision.policy is not self
                    or current != (decision.review_digest, decision.expected_materials)):
                raise OwnerAcquisitionError('本人网页观察原用途已变化', mutation_committed=None)
            decision.check(frame)
            return decision
        decision = _OwnerObservationDecision(self, current[0], current[1], _SEAL)
        return decision

    def current(self, decision):
        current = self._review()
        return (type(decision) is _OwnerObservationDecision and decision.policy is self
                and current is not None and current == (decision.review_digest, decision.expected_materials))
