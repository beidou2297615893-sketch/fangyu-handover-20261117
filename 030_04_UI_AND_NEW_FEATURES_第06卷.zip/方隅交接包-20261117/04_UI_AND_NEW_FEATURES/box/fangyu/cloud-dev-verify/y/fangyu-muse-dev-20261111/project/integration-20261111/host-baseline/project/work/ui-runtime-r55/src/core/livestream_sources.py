"""Explicit employee/store/account live child-window selections, original Store."""
from copy import deepcopy
from .livestream_admission import LivestreamAdmission,LiveError,fail,get,put,digest,stamp,number,ID,REQUEST,binding

SOURCES='livestream_source_selections_v1'
SELECTIONS='livestream_source_selection_requests_v1'
QUEUES='livestream_room_queues_v1'
def source_key(user,store,account,room):return digest(['page-live-source-v1',user['tenant_id'],user['id'],store,account,room])
def public(row):
 return {k:deepcopy(row[k]) for k in ('id','version','accountId','accountName','webRid','liveConnId','windowTitle','city','area','confirmedAt') if k in row}|{'accountCheck':'confirmed_at_selection','message':'已明确确认此账号与直播窗口；开始前会再次核对，不会自动选择其他窗口'}
class LivestreamSources:
 def __init__(self,core):self.core,self.store=core,core.store;self.admission=LivestreamAdmission(core)
 def read(self,user,store,account,authority):
  with self.store.connect() as db:
   self.admission._actor(db,user,store,authority,account)
   rows=[]
   for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(SOURCES,user['tenant_id'])):
    import json
    row=json.loads(item['body'])
    if row.get('ownerId')==user['id'] and row.get('owner')==user['username'] and row.get('storeId')==store and row.get('accountId')==account['id']:rows.append(public(row))
   return {'sources':sorted(rows,key=lambda r:(r['webRid'],r['id'])),'maximumConfiguredRooms':10,'tenRoomCapacityVerified':False}
 def resolve(self,user,store,account,data,authority):
  if not isinstance(data.get('sourceId'),str) or not ID.fullmatch(data['sourceId']) or type(data.get('expectedVersion')) is not int:fail('LIVE_SOURCE_REQUIRED','请先明确选择并确认直播窗口',400)
  with self.store.connect() as db:
   self.admission._actor(db,user,store,authority,account);row=get(db,SOURCES,data['sourceId'],user['tenant_id'])
   if (not row or row.get('ownerId')!=user['id'] or row.get('owner')!=user['username'] or row.get('storeId')!=store or row.get('accountId')!=account['id']):fail('LIVE_SOURCE_FORBIDDEN','直播窗口选择不属于当前账号与门店',403)
   if row.get('version')!=data['expectedVersion'] or row.get('parentAccountBinding')!=binding(account):fail('LIVE_SOURCE_CHANGED','直播来源或原账号已变化，请重新核对原窗口选择',409)
   return row
 def _queue_key(self,user,store,account,request):
  return digest(['live-room-queue-v1',user['tenant_id'],user['id'],store,account['id'],request])
 def _queue_view(self,row):
  return {k:deepcopy(row[k]) for k in ('requestId','state','stage','items','stopRequested','createdAt','finishedAt','message') if k in row}|{'maximumRooms':10,'automaticResume':False,'completeHistory':False}
 def read_queue(self,user,store,account,request,*,authority):
  if not isinstance(request,str) or not REQUEST.fullmatch(request):fail('LIVE_QUEUE_INPUT_INVALID','请保留原直播队列编号',400)
  with self.store.connect() as db:
   self.admission._actor(db,user,store,authority,account)
   row=get(db,QUEUES,self._queue_key(user,store,account,request),user['tenant_id'])
   return self._queue_view(row) if row else {'requestId':request,'state':'not_started','automaticResume':False}
 def stop_queue(self,user,store,account,request,*,authority):
  if not isinstance(request,str) or not REQUEST.fullmatch(request):fail('LIVE_QUEUE_INPUT_INVALID','请保留原直播队列编号',400)
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account)
   row=get(db,QUEUES,self._queue_key(user,store,account,request),user['tenant_id'])
   if row is None:fail('LIVE_QUEUE_NOT_FOUND','未找到本人原直播队列',404)
   if row['state']!='completed':
    row.update(stopRequested=True,message='已停止后续房间；在途结果仍须通过原授权核对，不会自动恢复')
    put(db,QUEUES,row)
   return self._queue_view(row)
 def run_queue(self,user,store,account,data,*,authority,guard,transport):
  """One explicit <=10-room request, serial original captures, no recovery loop.

  This is a host API, not an additional CLI grant. The caller must already own
  the original live read authority. No new IDs, reconnect or retry are generated.
  """
  if (not isinstance(data,dict) or set(data)!={'requestId','confirmed','rooms'}
      or data['confirmed'] is not True or not isinstance(data['requestId'],str) or not REQUEST.fullmatch(data['requestId'])
      or not isinstance(data['rooms'],list) or not 1<=len(data['rooms'])<=10):fail('LIVE_QUEUE_INPUT_INVALID','请明确确认最多10个原直播来源及其原采集编号',400)
  rooms=data['rooms']
  if any(not isinstance(r,dict) or set(r)!={'sourceId','expectedVersion','requestId','timeoutMs'}
      or not isinstance(r['sourceId'],str) or not ID.fullmatch(r['sourceId']) or type(r['expectedVersion']) is not int or r['expectedVersion']<1
      or not isinstance(r['requestId'],str) or not REQUEST.fullmatch(r['requestId']) or type(r['timeoutMs']) is not int or not 100<=r['timeoutMs']<=20000 for r in rooms):fail('LIVE_QUEUE_INPUT_INVALID','每个房间必须保留原来源版本、采集编号和有界时长',400)
  if len({r['sourceId'] for r in rooms})!=len(rooms) or len({r['requestId'] for r in rooms})!=len(rooms):fail('LIVE_QUEUE_INPUT_INVALID','同一队列不得重复房间或采集编号',400)
  key=self._queue_key(user,store,account,data['requestId']);tenant=user['tenant_id'];signature=digest([data,binding(account)])
  # Validate every source before accepting any item; use the same transaction
  # for the original queue key and its frozen source references.
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account)
   old=get(db,QUEUES,key,tenant)
   if old:
    if old.get('signature')!=signature:fail('LIVE_QUEUE_ORIGINAL_CHANGED','原队列条件已变化，请核对原编号',409)
    return self._queue_view(old)|{'replayed':True}
   import json
   for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(QUEUES,tenant)):
    prior=json.loads(item['body'])
    if prior.get('ownerId')==user['id'] and prior.get('accountId')==account['id'] and prior.get('state')=='unknown':fail('LIVE_QUEUE_ORIGINAL_UNKNOWN','原直播队列尚待核对；不会改编号重新读取',409)
   snapshots=[]
   for request in rooms:
    source=get(db,SOURCES,request['sourceId'],tenant)
    if (not source or source.get('ownerId')!=user['id'] or source.get('owner')!=user['username'] or source.get('storeId')!=store or source.get('accountId')!=account['id']):fail('LIVE_SOURCE_FORBIDDEN','直播来源不属于当前员工账号门店',403)
    if source.get('version')!=request['expectedVersion'] or source.get('parentAccountBinding')!=binding(account):fail('LIVE_SOURCE_CHANGED','原直播来源或账号版本已变化',409)
    snapshots.append(source)
   row={'id':key,'tenant_id':tenant,'ownerId':user['id'],'owner':user['username'],'storeId':store,'accountId':account['id'],'requestId':data['requestId'],'signature':signature,'state':'unknown','stage':'queued','stopRequested':False,'createdAt':stamp(),'items':[dict(r,state='queued',webRid=s['webRid']) for r,s in zip(rooms,snapshots)]}
   put(db,QUEUES,row)
  for index,(request,source) in enumerate(zip(rooms,snapshots)):
   def authorized(db,actor,current_store):
    current=get(db,QUEUES,key,tenant)
    return (authority(db,actor,current_store) is True and current is not None and current.get('signature')==signature
     and current.get('state')=='unknown' and current.get('stopRequested') is False and get(db,SOURCES,source['id'],tenant)==source)
   def current_guard():
    guard()
    with self.store.connect() as db:
     self.admission._actor(db,user,store,authorized,account)
   try:
    current_guard()
    with self.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authorized,account)
     row=get(db,QUEUES,key,tenant);row['stage']='reading';row['items'][index]['state']='reading';put(db,QUEUES,row)
    capture={'storeId':store,'accountId':account['id'],'webRid':source['webRid'],'requestId':request['requestId'],'timeoutMs':request['timeoutMs'],'confirmed':True,'sourceId':source['id'],'sourceVersion':source['version'],'liveConnId':source['liveConnId'],'bridgeSelectionId':source['bridgeSelectionId'],'city':source['city'],'area':source['area'],'intentPolicySnapshot':deepcopy(source['intentPolicySnapshot']),'localPromptVersion':source['localPromptVersion']}
    result=self.admission.capture(user,store,account,capture,authority=authorized,guard=current_guard,transport=transport)
    if result.get('state')!='received':fail('LIVE_QUEUE_ITEM_UNKNOWN','原房间结果待核对，后续房间未开始',409)
    current_guard()
    with self.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authorized,account)
     row=get(db,QUEUES,key,tenant);row['items'][index].update(state='received',result=result);put(db,QUEUES,row)
   except Exception as error:
    # Failure is not a new permission. Retain only own accepted queue receipt,
    # even when the original actor/store authority has since been revoked.
    with self.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');row=get(db,QUEUES,key,tenant)
     if row and row.get('signature')==signature:
      row.update(stage='held',message='原房间结果或授权待核对，后续房间未开始；不会自动重试')
      row['items'][index].update(state='unknown',code=getattr(error,'code','LIVE_QUEUE_STOPPED'))
      put(db,QUEUES,row)
    return self._queue_view(row)
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account)
   row=get(db,QUEUES,key,tenant)
   if row.get('stopRequested') is False and all(i['state']=='received' for i in row['items']):row.update(state='completed',stage='saved',finishedAt=stamp(),message='本次有界房间队列已处理；不代表完整直播历史')
   put(db,QUEUES,row)
  return self._queue_view(row)
 def select(self,user,store,account,data,authority,guard,transport):
  if (set(data)!={'storeId','accountId','webRid','liveConnId','expectedVersion','requestId','confirmed','city','area','intentPolicySnapshot','localPromptVersion'} or data.get('storeId')!=store or data.get('accountId')!=account['id'] or data.get('confirmed') is not True or not number(data.get('webRid')) or not isinstance(data.get('liveConnId'),str) or not ID.fullmatch(data['liveConnId']) or not isinstance(data.get('requestId'),str) or not REQUEST.fullmatch(data['requestId']) or type(data.get('expectedVersion')) is not int or data['expectedVersion']<0):fail('LIVE_SELECTION_INPUT_INVALID','请确认本人账号、房间和明确选中的直播窗口',400)
  if (not isinstance(data['city'],str) or not data['city'].strip().removesuffix('市').strip() or len(data['city'])>80 or not isinstance(data['area'],str) or len(data['area'])>80 or any(ord(c)<32 for c in data['city']+data['area'])):fail('LIVE_ANALYSIS_CONTEXT_REQUIRED','请明确直播需求判断的目标城市；区域可留空，不会猜测客户所在地',400)
  ident=source_key(user,store,account['id'],data['webRid']);key=digest(['live-select',user['tenant_id'],user['id'],data['requestId']]);signature=digest([data,binding(account)])
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account);old=get(db,SELECTIONS,key,user['tenant_id'])
   if old:
    if old.get('signature')!=signature:fail('LIVE_SELECTION_REQUEST_CHANGED','原窗口确认编号的内容已变化',409)
    current=get(db,SOURCES,ident,user['tenant_id']);return {'state':old['state'],'requestId':data['requestId'],'source':public(old['source']) if old.get('source') else None,'isCurrent':bool(current and old.get('source',{}).get('version')==current.get('version')),'message':old.get('message','原窗口确认结果待核对；不会自动重试')}
   current=get(db,SOURCES,ident,user['tenant_id'])
   if (current or {}).get('version',0)!=data['expectedVersion']:fail('LIVE_SOURCE_CHANGED','直播来源已在其他窗口修改，请重新读取后确认',409)
   if not current and len(self.read(user,store,account,authority)['sources'])>=10:fail('LIVE_ROOM_CONFIG_LIMIT','最多保存10个直播房间；真实十房容量仍待验证',409)
  guard();owner='live-source:'+key;self.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',owner)
  try:
   guard()
   with self.store.connect() as db:
    db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account)
    if get(db,SELECTIONS,key,user['tenant_id']):fail('LIVE_SELECTION_IN_PROGRESS','原窗口确认正在处理，请核对原编号',409)
    current=get(db,SOURCES,ident,user['tenant_id'])
    if (current or {}).get('version',0)!=data['expectedVersion']:fail('LIVE_SOURCE_CHANGED','直播来源已变化，请重新读取后确认',409)
    receipt={'id':key,'tenant_id':user['tenant_id'],'ownerId':user['id'],'owner':user['username'],'storeId':store,'requestId':data['requestId'],'signature':signature,'state':'unknown','createdAt':stamp()};put(db,SELECTIONS,receipt)
   value=transport(account,data,guard);guard()
   if (not isinstance(value,dict) or value.get('contract')!='fangyu-live-source-selection-v1' or value.get('state')!='selected' or value.get('parentConnId')!=account['conn_id'] or value.get('connId')!=data['liveConnId'] or value.get('accountUid')!=account['platform_uid'] or value.get('webRid')!=data['webRid'] or not isinstance(value.get('selectionId'),str) or not ID.fullmatch(value['selectionId'])):fail(value.get('code','LIVE_SELECTION_UNCONFIRMED') if isinstance(value,dict) else 'LIVE_SELECTION_UNCONFIRMED',value.get('message','当前账号与直播窗口尚未核对，原确认编号保留') if isinstance(value,dict) else '当前窗口核对回执未知',409)
   with self.store.connect() as db:
    db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account);current=get(db,SOURCES,ident,user['tenant_id'])
    if (current or {}).get('version',0)!=data['expectedVersion']:fail('LIVE_SOURCE_CHANGED','核对期间直播来源已修改，本次不覆盖',409)
    if current is None:
     import json
     configured=sum(1 for item in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(SOURCES,user['tenant_id'])) if (lambda r:r.get('ownerId')==user['id'] and r.get('storeId')==store and r.get('accountId')==account['id'])(json.loads(item['body'])))
     if configured>=10:fail('LIVE_ROOM_CONFIG_LIMIT','最多保存10个直播房间；真实十房容量仍待验证',409)
    row={'id':ident,'tenant_id':user['tenant_id'],'ownerId':user['id'],'owner':user['username'],'storeId':store,'accountId':account['id'],'accountName':account.get('platform_nickname') or account.get('name') or '当前抖音账号','webRid':data['webRid'],'liveConnId':data['liveConnId'],'windowTitle':str(value.get('title') or '直播窗口')[:200],'intentPolicySnapshot':deepcopy(data['intentPolicySnapshot']),'localPromptVersion':data['localPromptVersion'],'city':data['city'].strip(),'area':data['area'].strip(),'version':data['expectedVersion']+1,'parentAccountBinding':binding(account),'bridgeSelectionId':value['selectionId'],'confirmedAt':stamp()}
    put(db,SOURCES,row);receipt.update(state='selected',source=deepcopy(row),finishedAt=stamp());put(db,SELECTIONS,receipt)
   return {'state':'selected','source':public(row),'requestId':data['requestId'],'isCurrent':True}
  finally:self.core.release_account_mode(account['id'],user['tenant_id'],owner)
