"""Short, device-bound permits for exact reviewed replies in internal acceptance.

The authenticated cloud heartbeat is the only caller allowed to refresh this
volatile lease. A durable local attempt marker prevents replay after restart.
"""
import hashlib,re,time

IDENT=re.compile(r'[A-Za-z0-9_-]{16,80}\Z')
DIGEST=re.compile(r'[a-f0-9]{64}\Z')

class ReplyTrial:
    def __init__(self,store):
        self.store=store
        self.value=None
        self.deadline=0.0

    def heartbeat(self,value,device_id,owner,poll_started):
        self.value=None;self.deadline=0.0
        if not isinstance(value,dict) or value.get('device_id')!=device_id or value.get('owner')!=owner:return
        remaining=value.get('remaining_seconds')
        if type(value.get('expires_at')) is not int:return
        if type(remaining) is not int or not 0<remaining<=900:return
        if not IDENT.fullmatch(str(value.get('grant_id',''))) or not IDENT.fullmatch(str(value.get('account_id',''))):return
        targets=value.get('targets')
        if (not isinstance(targets,list) or not 1<=len(targets)<=2 or
                any(not isinstance(t,dict) or not IDENT.fullmatch(str(t.get('reply_id',''))) or
                    not DIGEST.fullmatch(str(t.get('snapshot_digest',''))) for t in targets) or
                len({t['reply_id'] for t in targets})!=len(targets)):return
        deadline=poll_started+min(45,remaining)
        if deadline<=time.monotonic():return
        self.value={**value,'targets':[dict(t) for t in targets]};self.deadline=deadline

    def _key(self,reply_id):
        return hashlib.sha256((self.value['grant_id']+'\n'+reply_id).encode()).hexdigest()

    def allows(self,device_id,user,reply,snapshot,proof):
        value=self.value
        if (not value or time.monotonic()>=self.deadline or value['device_id']!=device_id or
                value['owner']!=user.get('username') or value['account_id']!=snapshot.get('account_id')):return False
        if not isinstance(proof,dict) or any(proof.get(k)!=v for k,v in {
                'grant_id':value['grant_id'],'reply_id':reply['id'],'account_id':value['account_id'],
                'expires_at':value.get('expires_at'),'snapshot_digest':snapshot.get('digest')}.items()):return False
        target=next((t for t in value['targets'] if t['reply_id']==reply['id']),None)
        return bool(target and target['snapshot_digest']==snapshot.get('digest') and
                    not self.store.get('reply_trial_attempts',self._key(reply['id'])))

    def attempt(self,tenant,reply_id):
        return ('reply_trial_attempts',{'id':self._key(reply_id),'tenant_id':tenant,
            'grant_id':self.value['grant_id'],'reply_id':reply_id,'attempted_at':int(time.time())})
