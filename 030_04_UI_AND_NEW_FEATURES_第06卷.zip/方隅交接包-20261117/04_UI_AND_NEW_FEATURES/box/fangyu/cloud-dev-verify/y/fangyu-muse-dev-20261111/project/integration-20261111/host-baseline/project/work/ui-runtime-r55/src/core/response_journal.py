"""Independent append-only outbox for verified customer response observations."""
import hashlib
import json
import re
import time
from urllib.parse import urlsplit
from uuid import UUID, uuid4

from .contact_journal import _public_url


ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')


def _note_url(value):
    safe=_public_url(value)
    if not safe:return ''
    parsed=urlsplit(safe)
    if (parsed.hostname not in ('xiaohongshu.com','www.xiaohongshu.com') or
            not re.fullmatch(r'/(?:explore|search_result|discovery/item)/[A-Za-z0-9]{24}/?',parsed.path)):
        return ''
    return safe


def _normalized(observation):
    if not isinstance(observation,dict) or set(observation)!={'observation_id','sent_event_id',
            'origin_comment_id','local_reply_id','platform_reply_id','response'}:
        raise ValueError('Invalid response observation fields')
    result={}
    for key in ('observation_id','sent_event_id'):
        if not isinstance(observation[key],str):raise ValueError('Invalid response UUID')
        value=str(UUID(observation[key]))
        if value!=observation[key].lower():raise ValueError('Invalid response UUID')
        result[key]=value
    for key in ('origin_comment_id','local_reply_id','platform_reply_id'):
        value=observation[key]
        if not isinstance(value,str) or not ID.fullmatch(value.strip()):raise ValueError('Invalid response identity')
        result[key]=value.strip()
    source=observation['response']
    if not isinstance(source,dict) or set(source)!={'platform','author_id','note_url','comment_id',
            'target_comment_id','target_author_id','published_at','text'}:
        raise ValueError('Invalid response payload')
    response={}
    for key in ('platform','author_id','comment_id','target_comment_id','target_author_id'):
        value=source[key]
        if not isinstance(value,str) or not ID.fullmatch(value.strip()):raise ValueError('Invalid response identity')
        response[key]=value.strip()
    if response['platform']!='xiaohongshu':raise ValueError('Invalid response platform')
    response['note_url']=_note_url(source['note_url'])
    if not response['note_url']:raise ValueError('Invalid response post')
    value=source['published_at']
    if type(value) is not int or value<=0:raise ValueError('Invalid response time')
    response['published_at']=value
    value=source['text']
    if not isinstance(value,str) or not value.strip() or len(value)>3000:
        raise ValueError('Invalid response text')
    response['text']=value
    result['response']=response
    return result


def payload_hash(observation):
    payload=json.dumps(observation,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


class ResponseJournal:
    def __init__(self,store):
        self.store=store
        with store.connect() as db:
            db.executescript('''
              CREATE TABLE IF NOT EXISTS contact_response_outbox(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                observation_id TEXT NOT NULL UNIQUE,
                tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,
                platform TEXT NOT NULL,post_key TEXT NOT NULL,comment_id TEXT NOT NULL,
                payload TEXT NOT NULL,payload_hash TEXT NOT NULL,
                UNIQUE(tenant_id,cloud_owner,platform,post_key,comment_id));
              CREATE INDEX IF NOT EXISTS response_outbox_scope
                ON contact_response_outbox(tenant_id,cloud_owner,sequence);
              CREATE TABLE IF NOT EXISTS contact_response_acks(
                observation_id TEXT PRIMARY KEY REFERENCES contact_response_outbox(observation_id),
                acked_at REAL NOT NULL);
              CREATE TABLE IF NOT EXISTS contact_response_blocks(
                observation_id TEXT PRIMARY KEY REFERENCES contact_response_outbox(observation_id),
                reason TEXT NOT NULL,blocked_at REAL NOT NULL);
              CREATE TRIGGER IF NOT EXISTS response_outbox_no_update BEFORE UPDATE ON contact_response_outbox
                BEGIN SELECT RAISE(ABORT,'response outbox is append only'); END;
              CREATE TRIGGER IF NOT EXISTS response_outbox_no_delete BEFORE DELETE ON contact_response_outbox
                BEGIN SELECT RAISE(ABORT,'response outbox is append only'); END;
            ''')

    def record(self,tenant_id,cloud_owner,observation):
        if not all(isinstance(x,str) and x for x in (tenant_id,cloud_owner)):
            raise ValueError('Invalid response scope')
        if 'observation_id' in observation:raise ValueError('Response ID is generated locally')
        body=_normalized({'observation_id':str(uuid4()),**observation})
        response=body['response']
        post_key=re.search(r'/([A-Za-z0-9]{24})/?$',urlsplit(response['note_url']).path).group(1).lower()
        key=(tenant_id,cloud_owner,response['platform'],post_key,response['comment_id'])
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            prior=db.execute('''SELECT payload FROM contact_response_outbox WHERE tenant_id=?
                AND cloud_owner=? AND platform=? AND post_key=? AND comment_id=?''',key).fetchone()
            if prior:
                existing=json.loads(prior['payload'])
                old={k:v for k,v in existing.items() if k!='observation_id'}
                new={k:v for k,v in body.items() if k!='observation_id'}
                old['response']=dict(old['response']);new['response']=dict(new['response'])
                old['response'].pop('note_url');new['response'].pop('note_url')
                if old!=new:
                    raise ValueError('Response observation identity conflict')
                return existing['observation_id'],False
            payload=json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
            db.execute('''INSERT INTO contact_response_outbox(observation_id,tenant_id,cloud_owner,
                platform,post_key,comment_id,payload,payload_hash) VALUES(?,?,?,?,?,?,?,?)''',
                (body['observation_id'],*key,payload,payload_hash(body)))
        return body['observation_id'],True

    def pending(self,tenant_id,cloud_owner,limit=5):
        if not tenant_id or not cloud_owner:raise ValueError('Response scope missing')
        limit=min(5,max(1,int(limit)))
        with self.store.connect() as db:
            rows=db.execute('''SELECT o.payload FROM contact_response_outbox o
                LEFT JOIN contact_response_acks a ON a.observation_id=o.observation_id
                LEFT JOIN contact_response_blocks b ON b.observation_id=o.observation_id
                WHERE o.tenant_id=? AND o.cloud_owner=? AND a.observation_id IS NULL
                  AND b.observation_id IS NULL
                ORDER BY o.sequence LIMIT ?''',(tenant_id,cloud_owner,limit)).fetchall()
        return [json.loads(row['payload']) for row in rows]

    def acknowledge(self,tenant_id,cloud_owner,receipts):
        if not tenant_id or not cloud_owner:raise ValueError('Response scope missing')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for ident,digest in receipts.items():
                row=db.execute('''SELECT o.payload_hash FROM contact_response_outbox o
                    LEFT JOIN contact_response_acks a ON a.observation_id=o.observation_id
                    WHERE o.observation_id=? AND o.tenant_id=? AND o.cloud_owner=?
                      AND a.observation_id IS NULL''',(ident,tenant_id,cloud_owner)).fetchone()
                if not row or row['payload_hash']!=digest:raise ValueError('Invalid response ACK')
            for ident in receipts:
                db.execute('INSERT INTO contact_response_acks VALUES(?,?)',(ident,time.time()))

    def block(self,tenant_id,cloud_owner,ids,reason):
        if reason not in ('CONTACT_RESPONSE_UNVERIFIED','CONTACT_RESPONSE_CONFLICT','CONTACT_INVALID_INPUT'):
            raise ValueError('Invalid response block reason')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for ident in ids:
                row=db.execute('''SELECT 1 FROM contact_response_outbox WHERE observation_id=?
                    AND tenant_id=? AND cloud_owner=?''',(ident,tenant_id,cloud_owner)).fetchone()
                if not row:raise ValueError('Response block scope mismatch')
            for ident in ids:
                db.execute('INSERT OR IGNORE INTO contact_response_blocks VALUES(?,?,?)',
                           (ident,reason,time.time()))

    def status(self,tenant_id,cloud_owner):
        with self.store.connect() as db:
            row=db.execute('''SELECT COUNT(*) total,
                SUM(CASE WHEN a.observation_id IS NULL AND b.observation_id IS NULL THEN 1 ELSE 0 END) pending,
                SUM(CASE WHEN b.observation_id IS NOT NULL THEN 1 ELSE 0 END) blocked,
                SUM(CASE WHEN a.observation_id IS NOT NULL THEN 1 ELSE 0 END) uploaded
                FROM contact_response_outbox o LEFT JOIN contact_response_acks a
                ON a.observation_id=o.observation_id LEFT JOIN contact_response_blocks b
                ON b.observation_id=o.observation_id WHERE o.tenant_id=? AND o.cloud_owner=?''',
                (tenant_id,cloud_owner)).fetchone()
        return {'total':row['total'],'pending':row['pending'] or 0,
                'blocked':row['blocked'] or 0,'uploaded':row['uploaded'] or 0,'cloud_verified':False}
