"""Bounded, owned source discovery; no registration, delivery or money proof.

The opaque cursor is a consistency constraint, never an authorization token.
This module reuses the frozen detail reader's narrow source/scope checks.
"""
import base64
from copy import deepcopy
import json

from core.contact_journal import KINDS
from .acquisition_operations import _text, AcquisitionError
from .business_reconciliation import (
    LocalBusinessReconciliation, BusinessReconciliationError, _fail, _hash, _raw_hash,
    _json, _exact, _integer, _bool, _match, _HEX, _HANDOFF, _CHANNEL, _CUSTOMER,
    _UUID, _CHANNEL_STATES, _ATTRIBUTION_STATES, _CHANNEL_FIELDS, _SOURCE_FIELDS,
    _FLAGS, _MAX_INTEGER,
)

ACTION = 'business_reconciliation_candidates'
CLOUD_ACTION = 'acquisition_channel_candidates'
_DISCOVERY_FIELDS = frozenset(('contract', 'read_only', 'storage_scope', 'observed_at',
    'authenticated_actor', 'source_window_digest', 'source_results', 'scan', 'candidates',
    'local_cloud_handoff_correspondence_verified', 'financial_receipt_verified',
    'cooperation_policy_verified', 'verified_cash_cents', 'verified_paid_commission_cents'))
_CURSOR_FIELDS = frozenset(('version', 'anchor', 'latest_sequence', 'window_digest',
    'owned_index_count', 'offset', 'scope_fingerprint'))
MISSING_EVIDENCE = ['exact_local_handoff_mapping_not_integrated',
    'financial_cash_authority_not_integrated', 'commission_payment_authority_not_integrated',
    'cooperation_policy_not_verified']


def _cursor(value):
    return base64.urlsafe_b64encode(_json(value).encode()).decode().rstrip('=')


def _decode(value):
    try:
        if not isinstance(value, str) or not 1 <= len(value) <= 1800:
            raise ValueError('cursor length')
        decoded = base64.b64decode(value+'='*(-len(value) % 4), altchars=b'-_', validate=True)
        item = json.loads(decoded)
        _exact(item, _CURSOR_FIELDS)
        if _cursor(item) != value or item['version'] != 1 or type(item['version']) is not int:
            raise ValueError('cursor format')
        for name in ('anchor', 'latest_sequence'):
            _integer(item[name], 1)
        _integer(item['offset'])
        _integer(item['owned_index_count'], nullable=True)
        if (not _match(item['scope_fingerprint'], _HEX)
                or item['window_digest'] is not None and not _match(item['window_digest'], _HEX)
                or item['offset'] > 0 and (item['owned_index_count'] is None or item['window_digest'] is None)
                or item['anchor'] > item['latest_sequence']+1):
            raise ValueError('cursor constraint')
        return item
    except Exception:
        _fail('INVALID_INPUT', '候选查询页码无效，请从当前交接重新查找')


class LocalBusinessChannelCandidates(LocalBusinessReconciliation):
    """Same trusted constructor as LocalBusinessReconciliation; pure reads only."""

    def _window(self, snapshot, anchor=None):
        with self.core.lock, self.core.store.connect() as db:
            if db.execute('''SELECT 1 FROM contact_events WHERE tenant_id=? AND cloud_owner=?
                    AND NOT json_valid(payload) LIMIT 1''', (self.tenant, self.owner)).fetchone():
                _fail('AUDIT_CONFLICT', '本人来源事件存在不可读记录，不能宣称没有来源', 409)
            # No event→lead index exists yet; bounded projection is not a claim
            # that scanning a very large local scoped journal is constant time.
            clause = "e.tenant_id=? AND e.cloud_owner=? AND CASE WHEN json_valid(e.payload) THEN json_extract(e.payload,'$.lead.id') END=?"
            scope = (self.tenant, self.owner, snapshot['lead']['id'])
            latest = db.execute('SELECT MAX(e.sequence) AS latest FROM contact_events e WHERE '+clause,
                                scope).fetchone()['latest'] or 0
            anchor = latest+1 if anchor is None else anchor
            selected = db.execute('''SELECT e.sequence,e.event_id,e.kind,e.payload_hash,a.acked_at
                FROM contact_events e LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
                WHERE '''+clause+''' AND e.sequence<? ORDER BY e.sequence DESC LIMIT 6''',
                (*scope, anchor)).fetchall()
        events = {}
        for row in selected[:5]:
            event, payload_hash = self._owned_event(row['event_id'], snapshot)
            if (event.get('kind') not in KINDS or event.get('kind') != row['kind']
                    or payload_hash != row['payload_hash']):
                _fail('AUDIT_CONFLICT', '来源事件类型或版本需核对，暂不查找候选', 409)
            events[row['event_id']] = (event, payload_hash)
        sources = sorted(({'event_id': key, 'payload_hash': value[1]} for key, value in events.items()),
                         key=lambda row: row['event_id'])
        return {'anchor': anchor, 'latest': latest, 'rows': selected[:5], 'events': events,
                'sources': sources, 'digest': _hash(sources), 'older': len(selected) > 5,
                'newer': bool(latest >= anchor)}

    def _source(self, source, event_id, window):
        _exact(source, _SOURCE_FIELDS)
        event, payload_hash = window['events'][event_id]
        lead = event['lead']
        expected = {'payload_hash': payload_hash, 'source_lead_hash': _raw_hash(lead['id']),
            'original_text_hash': _raw_hash(lead['text']), 'author_id_hash': _raw_hash(lead['author_id']),
            'comment_id_hash': _raw_hash(lead['comment_id'])}
        if (source['evidence_status'] != 'matched' or source['event_id'] != event_id
                or source['owner'] != self.owner or source['device_id'] != self.device_id
                or source['platform'] != 'xiaohongshu' or source['platform_provenance_verified'] is not False
                or any(source[key] != expected[key] for key in expected)):
            _fail('SOURCE_CONFLICT', '公司来源与本人本机原事件不一致，暂不显示候选', 409)

    def _discovery(self, answer, window, offset, expected_count):
        _exact(answer, ('discovery',))
        value = answer['discovery']
        _exact(value, _DISCOVERY_FIELDS)
        if (value['contract'] != 'business_channel_discovery_v1' or value['read_only'] is not True
                or value['storage_scope'] != 'company_server_ledger' or value['authenticated_actor'] != self.owner
                or value['source_window_digest'] != window['digest']
                or any(value[name] is not False for name in ('local_cloud_handoff_correspondence_verified',
                    'financial_receipt_verified', 'cooperation_policy_verified'))
                or value['verified_cash_cents'] is not None or value['verified_paid_commission_cents'] is not None):
            _fail('RECEIPT_INVALID', '候选身份或只读证据合同需核对，暂不显示结果', 409)
        _integer(value['observed_at'], 1577836800)
        rows = value['source_results']
        if not isinstance(rows, list) or len(rows) != len(window['events']):
            _fail('RECEIPT_INVALID', '来源查询范围不完整，请重新查找', 409)
        recorded, seen = {}, set()
        for row in rows:
            _exact(row, ('event_id', 'payload_hash', 'status', 'source'))
            event_id = row['event_id']
            if (not _match(event_id, _UUID) or event_id not in window['events'] or event_id in seen
                    or row['payload_hash'] != window['events'][event_id][1]
                    or row['status'] not in ('recorded', 'not_recorded')):
                _fail('SOURCE_CONFLICT', '来源事件或查询摘要不一致，暂不显示候选', 409)
            seen.add(event_id)
            if row['status'] == 'recorded':
                self._source(row['source'], event_id, window)
                recorded[event_id] = row['source']
            elif row['source'] is not None:
                _fail('RECEIPT_INVALID', '缺失来源不能附带已核对证据', 409)
        scan = value['scan']
        _exact(scan, ('direction', 'status', 'owned_index_count', 'offset', 'scanned_count',
                      'limit', 'next_offset', 'complete'))
        _integer(scan['offset']); _integer(scan['scanned_count'], 0, 10)
        _integer(scan['owned_index_count'], nullable=True); _bool(scan['complete'])
        _integer(scan['next_offset'], nullable=True)
        if (scan['direction'] != 'newest_first' or scan['offset'] != offset
                or scan['limit'] != 10 or type(scan['limit']) is not int
                or scan['status'] not in ('partial', 'complete', 'index_unavailable', 'no_cloud_sources')
                or expected_count is not None and scan['owned_index_count'] != expected_count):
            _fail('SCOPE_CHANGED', '公司候选索引或扫描范围已变化，请重新查找', 409)
        total, size, status = scan['owned_index_count'], scan['scanned_count'], scan['status']
        if status in ('partial', 'complete'):
            if (not recorded or total is None or offset > total or size > min(10, total-offset)
                    or status == 'partial' and (size == 0 or scan['complete'] or scan['next_offset'] != offset+size
                                                or offset+size >= total)
                    or status == 'complete' and (not scan['complete'] or scan['next_offset'] is not None
                                                 or offset+size != total)):
                _fail('RECEIPT_INVALID', '候选扫描分页不一致，不能宣称查找完成', 409)
        elif (total is not None or size != 0 or scan['next_offset'] is not None or scan['complete']
                or status == 'no_cloud_sources' and recorded or status == 'index_unavailable' and not recorded):
            _fail('RECEIPT_INVALID', '候选来源与未扫描状态不一致', 409)
        candidates = value['candidates']
        if (not isinstance(candidates, list) or len(candidates) > min(5, size)
                or status not in ('partial', 'complete') and candidates):
            _fail('RECEIPT_INVALID', '候选数量或扫描证据不一致', 409)
        public, ids = [], set()
        for row in candidates:
            _exact(row, ('channel', 'recipient_name', 'created_at', 'updated_at'))
            channel = row['channel']; _exact(channel, _CHANNEL_FIELDS)
            event_id = channel['source_event_id']
            if (not _match(channel['channel_id'], _CHANNEL) or channel['channel_id'] in ids
                    or event_id not in recorded or channel['source'] != recorded[event_id]
                    or channel['source_owner'] != self.owner or channel['status'] not in _CHANNEL_STATES
                    or channel['attribution_status'] not in _ATTRIBUTION_STATES
                    or channel['customer_id'] != 'cu_'+_raw_hash('xiaohongshu:author:'+window['events'][event_id][0]['lead']['author_id'])):
                _fail('SOURCE_CONFLICT', '候选客户或原事件对应冲突，暂不显示结果', 409)
            ids.add(channel['channel_id']); _integer(channel['revision'], 1)
            for name in ('current_consent_valid', 'eligible_for_delivery', 'historical_resource_receipt_recorded'):
                _bool(channel[name])
            if (channel['receipt_evidence_independently_verified'] is not False
                    or channel['eligible_for_delivery'] and not channel['current_consent_valid']):
                _fail('RECEIPT_INVALID', '候选接收或授权证据相互矛盾', 409)
            _integer(row['created_at'], 1577836800); _integer(row['updated_at'], row['created_at'])
            try:
                name = _text(row['recipient_name'], '接收部门名称', 100)
            except AcquisitionError:
                _fail('RECEIPT_INVALID', '候选接收部门名称需核对', 409)
            public.append({**{key: deepcopy(channel[key]) for key in ('channel_id', 'revision', 'status',
                'current_consent_valid', 'eligible_for_delivery', 'historical_resource_receipt_recorded',
                'receipt_evidence_independently_verified', 'attribution_status')}, 'recipient_name': name,
                'created_at': row['created_at'], 'updated_at': row['updated_at'],
                'source_binding': {'status': 'matched', 'local_integrity': 'ok', 'platform_provenance_verified': False}})
        return value, public, len(recorded)

    def execute(self, action, data, user):
        if (action != ACTION or not isinstance(data, dict) or set(data)-{'handoff_id', 'cursor'}
                or not _match(data.get('handoff_id'), _HANDOFF)):
            _fail('INVALID_INPUT', '请从本人已有交接查找公司渠道候选')
        cursor = _decode(data['cursor']) if 'cursor' in data else None
        before = self._snapshot(data['handoff_id'], user)
        scope_fingerprint = _hash({'snapshot': before['fingerprint'], 'device_id': self.device_id})
        window = self._window(before, cursor['anchor'] if cursor else None)
        if cursor and (cursor['scope_fingerprint'] != scope_fingerprint
                or cursor['latest_sequence'] != window['latest']
                or cursor['window_digest'] is not None and cursor['window_digest'] != window['digest']):
            _fail('SCOPE_CHANGED', '来源窗口、交接或员工范围已变化，请重新查找', 409)
        offset, expected_count = (cursor['offset'], cursor['owned_index_count']) if cursor else (0, None)
        discovery, items, recorded = None, [], 0
        if window['sources']:
            # A journal read is a storage boundary too: do not call the cloud
            # with the principal captured before those reads.
            current = self._snapshot(data['handoff_id'], user)
            if _hash({'snapshot': current['fingerprint'], 'device_id': self.device_id}) != scope_fingerprint:
                _fail('SCOPE_CHANGED', '查找前本人权限或来源已变化，请重新打开交接', 409)
            actor = {key: deepcopy(before['actor'].get(key)) for key in ('id', 'tenant_id', 'username', 'role', 'cloud_bound')}
            body = {'sources': deepcopy(window['sources']), 'source_window_digest': window['digest'],
                    'scan_offset': offset, 'scan_limit': 10}
            if expected_count is not None:
                body['expected_owned_index_count'] = expected_count
            self._scope()
            try:
                answer = self.cloud_read(actor, CLOUD_ACTION, body)
            except Exception:
                _fail('CLOUD_UNAVAILABLE', '公司候选暂不可读，请核对云连接与成员权限后重试', 503)
            discovery, items, recorded = self._discovery(answer, window, offset, expected_count)
        scan = discovery['scan'] if discovery else {'status': 'not_requested', 'scanned_count': 0,
            'owned_index_count': None, 'complete': False, 'next_offset': None}
        common = {'version': 1, 'anchor': window['anchor'], 'latest_sequence': window['latest'],
            'window_digest': window['digest'], 'owned_index_count': scan['owned_index_count'],
            'offset': 0, 'scope_fingerprint': scope_fingerprint}
        next_cursor = _cursor({**common, 'offset': scan['next_offset']}) if scan['status'] == 'partial' else None
        older_cursor = (_cursor({**common, 'anchor': window['rows'][-1]['sequence'],
            'window_digest': None, 'owned_index_count': None}) if window['older'] else None)
        result = {**_FLAGS, 'contract': 'local_business_channel_candidates_v1',
            'cloud_read_requested': discovery is not None, 'observed_at': discovery['observed_at'] if discovery else None,
            'state': scan['status'] if discovery else 'no_local_sources',
            'local_handoff': {'id': before['item']['id'], 'revision': before['item']['revision'], 'status': before['item']['status']},
            'source_window': {'event_count': len(window['sources']),
                'acked_event_count': sum(row['acked_at'] is not None for row in window['rows']),
                'unacked_event_count': sum(row['acked_at'] is None for row in window['rows']),
                'has_older_local_events': window['older'], 'has_newer_local_events': window['newer']},
            'source_results': {'recorded_count': recorded, 'not_recorded_count': len(window['sources'])-recorded},
            'scan': {key: scan[key] for key in ('status', 'scanned_count', 'owned_index_count', 'complete')},
            'items': items, 'next_cursor': next_cursor, 'older_sources_cursor': older_cursor,
            'verified_cash_cents': None, 'verified_paid_commission_cents': None,
            'financial_receipt_verified': False, 'cooperation_policy_verified': False,
            'missing_evidence': deepcopy(MISSING_EVIDENCE)}
        with self.core.lock:
            # Re-run *all* source chain reads before the final saved principal
            # snapshot. Late permission changes during the last receipt read
            # must not escape through a previously valid actor snapshot.
            after_window = self._window(before, window['anchor'])
            after = self._snapshot(data['handoff_id'], user)
            if (_hash({'snapshot': after['fingerprint'], 'device_id': self.device_id}) != scope_fingerprint
                    or after_window['latest'] != window['latest']
                    or after_window['digest'] != window['digest'] or after_window['older'] != window['older']):
                _fail('SCOPE_CHANGED', '读取期间本人权限、来源窗口或交接已变化，请重新查找', 409)
            self._scope()
            return result
