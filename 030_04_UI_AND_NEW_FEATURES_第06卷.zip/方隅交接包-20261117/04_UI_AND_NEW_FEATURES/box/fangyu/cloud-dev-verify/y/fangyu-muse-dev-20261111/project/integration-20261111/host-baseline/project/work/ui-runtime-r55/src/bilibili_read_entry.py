"""Narrow source helper over fixed upstream APIs. No login/write/discovery commands."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

BASE=Path(__file__).resolve().parent
VENDOR=BASE/'resources/bilibili_read_vendor'
SITE=Path(sys.executable).parent.parent/'Lib/site-packages'
_SOURCE_PINS={'bilibili_read_contract.py': 'a83244e10d5613d1fa2e1ae78ed6fe3b587e74578957fb3cc8a098b4e1e6a4ec', 'resources/bilibili_read_vendor/bilicli/client.py': '901871dd1426cc16113f68fbe9a5fcdd1c639678ed77873e80bd2c151855214c', 'resources/bilibili_read_vendor/bilicli/wbi.py': 'b8be9106a46eb2c8198716355902a32024bb7d68aaa0526c1f7786f326a73c66', 'resources/bilibili_read_vendor/bilicli/__init__.py': '91447944015cec709e8aa7655f7e9d64e1e4508e7023a57fe3746911c0fc6fed', 'resources/bilibili_read_vendor/bilicli/api/comment.py': '1b6e8dcb6281e57889d8c9841950f9bee2c3914d51c9915d650c11264d68c7dc', 'resources/bilibili_read_vendor/bilicli/api/search.py': 'de5e4dfa6d5fcf24cffa1e83b651203ba90625c89115eae3dffa9c909d636f83', 'resources/bilibili_read_vendor/bilicli/api/video.py': '2e20f252fd2b2d0c58866f54f1fd1ef0ba43492be8cb42e48553abdadf0cddc9', 'resources/bilibili_read_vendor/bilicli/api/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'resources/bilibili_read_vendor/LICENSE': 'cd3a5844d13ad021b2f2298dc6d1d60f20ca65333c3f3a482de1033ac09ff784'}
_URLS=frozenset(('https://api.bilibili.com/x/web-interface/nav',
    'https://api.bilibili.com/x/web-interface/wbi/search/type',
    'https://api.bilibili.com/x/web-interface/view','https://api.bilibili.com/x/v2/reply'))

class AccountBindingError(ValueError):pass
class ReadHold(ValueError):pass

def _checked(path):
    path=Path(path)
    for component in [path,*path.parents]:
        if component.exists() and (component.is_symlink() or getattr(component.stat(),'st_file_attributes',0)&1024):
            raise ReadHold('unexpected file indirection')
    return path

def _json(raw):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ReadHold('duplicate JSON key')
            result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ReadHold('nonfinite JSON')))

def bootstrap():
    for relative,digest in _SOURCE_PINS.items():
        path=_checked(BASE/relative)
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ReadHold('fixed source changed')
    site=_checked(SITE)
    if not (site/'httpx/__init__.py').is_file():raise ReadHold('existing httpx dependency absent')
    sys.path.insert(0,str(site))
    for name,file,package in [('bilibili_read_contract',BASE/'bilibili_read_contract.py',False),
                              ('bilicli',VENDOR/'bilicli/__init__.py',True)]:
        spec=importlib.util.spec_from_file_location(name,file,
            submodule_search_locations=[str(file.parent)] if package else None)
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)

def make_client(expected_uid, *, credential_input=None):
    """Own HOME only; reuse upstream client/API, bound and validate the HTTP transport."""
    import httpx
    from bilicli.client import BiliClient, BASE_HEADERS
    class Client(BiliClient):
        def __init__(self):
            home=os.environ.get('HOME','')
            if (os.environ.get('LEADSTUDIO_ISOLATED')!='1' or not home
                    or home!=os.environ.get('USERPROFILE') or Path(home)!=Path.cwd()):
                raise AccountBindingError('account HOME binding absent')
            self.home=_checked(Path(home));self.cookie_file=_checked(self.home/'.config/bilicli/cookies.json')
            self.explicit_credential=credential_input
            if credential_input is not None:
                from bilibili_read_contract import owned_credential_input
                owned_credential_input(credential_input)
            elif _checked(self.home/'.config/bilicli/workspace-binding-pending.json').exists():
                raise AccountBindingError('account credential commit needs cleanup')
            self.cookie_snapshot=self._snapshot()
            self.last_view=None;self.requests=0;self.deadline=time.monotonic()+25
            super().__init__()
            if self._cookies and (not self._cookies.get('SESSDATA') or not expected_uid and credential_input is None):
                raise AccountBindingError('stored credential identity unknown')
            if not self._cookies and expected_uid:raise AccountBindingError('saved identity has no bound credential')
        def _snapshot(self):
            if self.explicit_credential is not None:return self.explicit_credential
            _checked(self.cookie_file)
            if not self.cookie_file.exists():return None
            if not self.cookie_file.is_file() or self.cookie_file.stat().st_size>65536:raise AccountBindingError('invalid cookie file')
            with self.cookie_file.open('rb') as file:raw=file.read(65537)
            if len(raw)>65536:raise AccountBindingError('invalid cookie file')
            return raw
        def _load_cookies(self):
            self._cookies={} if self.cookie_snapshot is None else _json(self.cookie_snapshot)
            if (type(self._cookies) is not dict or not all(isinstance(k,str) and isinstance(v,str)
                    and 1<=len(k)<=64 and len(v)<=8192 for k,v in self._cookies.items())):
                raise AccountBindingError('invalid credential format')
        @property
        def http(self):
            if self._http is None:
                self._http=httpx.Client(headers=BASE_HEADERS,cookies=self._cookies,timeout=8,
                                        follow_redirects=False,trust_env=False)
            return self._http
        def get(self,url,params=None,**kwargs):
            if (url not in _URLS or kwargs or self.requests>=4 or time.monotonic()>=self.deadline
                    or self._snapshot()!=self.cookie_snapshot):raise ReadHold('fixed read boundary changed')
            if self.explicit_credential is not None and (url!='https://api.bilibili.com/x/web-interface/nav' or params or self.requests):
                raise ReadHold('explicit identity permits one nav only')
            self.requests+=1
            body=bytearray()
            with self.http.stream('GET',url,params=params) as response:
                if response.status_code!=200:raise ReadHold('HTTP read not complete')
                for chunk in response.iter_bytes():
                    if len(body)+len(chunk)>1024*1024 or time.monotonic()>=self.deadline:raise ReadHold('bounded response exceeded')
                    body.extend(chunk)
            packet=_json(body)
            if type(packet) is not dict or type(packet.get('code')) is not int:raise ReadHold('API envelope absent')
            data=packet.get('data')
            # Public nav can report -101 while returning WBI keys. This exception
            # is limited to an anonymous nav result with explicit isLogin=False.
            public_nav=(url.endswith('/nav') and not self._cookies and packet['code']==-101
                        and type(data) is dict and data.get('isLogin') is False and type(data.get('wbi_img')) is dict)
            if packet['code']!=0 and not public_nav:raise ReadHold('API did not complete')
            if type(data) is not dict:raise ReadHold('API data absent')
            # The upstream APIs supply defaults. Require the original fields
            # first so a changed/missing protocol cannot become an empty success.
            if url.endswith('/search/type'):
                sizes=[data[key] for key in ('pagesize','page_size') if key in data]
                if (type(params) is not dict or not all(k in data for k in ('result','numResults','numPages'))
                        or type(data.get('page')) is not int or str(data['page'])!=str(params.get('page'))
                        or not sizes or any(type(size) is not int or str(size)!=str(params.get('ps')) for size in sizes)):
                    raise ReadHold('search response page metadata absent or changed')
            if url.endswith('/reply'):
                page_info=data.get('page')
                if (type(params) is not dict or type(page_info) is not dict or 'count' not in page_info or 'replies' not in data
                        or type(page_info.get('num')) is not int or page_info['num']!=params.get('pn')
                        or type(page_info.get('size')) is not int or page_info['size']!=params.get('ps')):
                    raise ReadHold('comment response page metadata absent or changed')
            if url.endswith('/view'):
                from bilibili_read_contract import _number
                if type(params) is not dict or data.get('bvid')!=params.get('bvid'):
                    raise ReadHold('video identity mismatch')
                _number(data.get('aid'));self.last_view=data
            return data
        def verify_identity(self):
            if not self._cookies:return ''
            data=self.get('https://api.bilibili.com/x/web-interface/nav')
            from bilibili_read_contract import _number
            if data.get('isLogin') is not True or str(_number(data.get('mid')))!=expected_uid:
                raise AccountBindingError('credential identity mismatch')
            return expected_uid
        def check_current(self):
            if self._snapshot()!=self.cookie_snapshot:raise AccountBindingError('credential changed during read')
        def post(self,*args,**kwargs):raise ReadHold('write unavailable')
        def save_cookies(self,*args,**kwargs):raise ReadHold('credential writing unavailable')
        def clear_cookies(self,*args,**kwargs):raise ReadHold('credential writing unavailable')
        def get_raw(self,*args,**kwargs):raise ReadHold('other reads unavailable')
        def get_json(self,*args,**kwargs):raise ReadHold('other reads unavailable')
    return Client()

def run_owned_self(*, expected_uid, credential_input):
    from bilibili_read_contract import _need,_number,_text,project_owned_identity
    _need(type(expected_uid) is str)
    if expected_uid:_need(str(_number(expected_uid))==expected_uid)
    with make_client(expected_uid,credential_input=credential_input) as client:
        data=client.get('https://api.bilibili.com/x/web-interface/nav')
        if data.get('isLogin') is not True:raise AccountBindingError('explicit credential not authenticated')
        uid=str(_number(data.get('mid')))
        if expected_uid and uid!=expected_uid:raise AccountBindingError('credential identity mismatch')
        if client._cookies.get('DedeUserID') not in (None,uid):raise AccountBindingError('credential UID mismatch')
        nickname=_text(data.get('uname'),160)
        result={'ok':True,'schema_version':1,'platform':'bilibili','operation':'self',
                'raw':{'isLogin':True,'mid':data['mid'],'uname':nickname},'actor_uid':uid,'nickname':nickname}
        project_owned_identity(result,expected_uid);client.check_current()
        return result

def run(operation,*,keyword='',reference='',page=1,limit=20,expected_uid=''):
    from bilibili_read_contract import _need,_number,_bvid,project
    _need(operation in ('search','comments') and type(page) is int and 1<=page<=50
          and type(limit) is int and 1<=limit<=20 and isinstance(expected_uid,str))
    if expected_uid:_need(str(_number(expected_uid))==expected_uid)
    if operation=='search':_need(isinstance(keyword,str) and 1<=len(keyword.strip())<=200)
    else:reference=_bvid(reference)
    with make_client(expected_uid) as client:
        actor_uid=client.verify_identity()
        if operation=='search':
            from bilicli.api.search import search_videos
            raw={'search':search_videos(client,keyword,page=page,page_size=20)}
        else:
            from bilicli.api.comment import get_comments
            data=get_comments(client,reference,page=page,page_size=20,sort=0)
            raw={'comments':data,'video':client.last_view}
        payload={'ok':True,'schema_version':1,'platform':'bilibili','operation':operation,
                 'requested_page':page,'requested_limit':limit,'actor_uid':actor_uid,'raw':raw}
        if operation=='search':payload['requested_keyword']=keyword
        items,info=project(payload,operation=operation,page=page,limit=limit,
                           reference=reference,expected_uid=expected_uid,keyword=keyword)
        client.check_current()
        payload.update(items=items,page=info)
        # Output is bounded as a whole, not just each API response.
        _need(len(json.dumps(payload,ensure_ascii=False,allow_nan=False).encode('utf-8'))<=1024*1024)
        return payload

def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    sub=parser.add_subparsers(dest='operation',required=True)
    for operation in ('search','comments'):
        cmd=sub.add_parser(operation,allow_abbrev=False)
        cmd.add_argument('--keyword' if operation=='search' else '--bvid',required=True)
        cmd.add_argument('--page',type=int,required=True);cmd.add_argument('--limit',type=int,required=True)
        cmd.add_argument('--expected-uid',default='')
    cmd=sub.add_parser('self',allow_abbrev=False)
    cmd.add_argument('--expected-uid',required=True)
    args=parser.parse_args()
    try:
        bootstrap()
        if args.operation=='self':
            result=run_owned_self(expected_uid=args.expected_uid,credential_input=sys.stdin.buffer.read(65537))
        else:
            result=run(args.operation,keyword=getattr(args,'keyword',''),reference=getattr(args,'bvid',''),
                       page=args.page,limit=args.limit,expected_uid=args.expected_uid)
    except Exception as exc:
        # Never expose upstream errors, URLs, credentials or private file paths.
        result={'ok':True,'read_error':'account_unverified' if isinstance(exc,AccountBindingError) else 'read_hold'}
    print(json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':')))

if __name__=='__main__':main()
