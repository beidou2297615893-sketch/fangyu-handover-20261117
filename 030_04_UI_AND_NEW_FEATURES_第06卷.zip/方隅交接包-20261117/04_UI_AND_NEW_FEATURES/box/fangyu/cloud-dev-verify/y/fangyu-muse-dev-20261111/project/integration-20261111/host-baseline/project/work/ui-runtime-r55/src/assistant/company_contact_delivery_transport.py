"""Fixed contact-vault actions over the existing company session.

Metadata status is read-only. Revealing values is an explicit audited server
operation, never a status query or an automatic replay. No session renewal.
"""
from copy import deepcopy
import re

from .company_handoff_status_transport import CompanyHandoffStatusTransport, CompanyHandoffStatusTransportError

PUBLISH = 'acquisition_contact_publish'
REVEAL = 'acquisition_contact_reveal'
WITHDRAW = 'acquisition_contact_withdraw'
STATUS = 'acquisition_contact_operation_status'
WRITES = frozenset((PUBLISH, REVEAL, WITHDRAW))
OPERATIONS = WRITES | {STATUS}
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_VERSION = re.compile(r'[A-Za-z0-9_-]{8,96}\Z')
_CONSENT = re.compile(r'consent:[a-f0-9]{32}\Z')
_FIELDS = frozenset(('contract', 'storage_scope', 'authenticated_actor', 'state', 'operation_id',
    'original_action', 'original_key', 'original_execution_confirmed', 'read_only', 'mutation_committed',
    'auto_retry', 'replayed', 'provider_configured', 'retention_configured', 'channel_binding_state', 'permissions',
    'live_kms_verified', 'contact_available', 'contact',
    'server_release_recorded', 'plaintext_replayed', 'contact_values', 'cloud_kms_requested',
    'current_consent_valid', 'current_channel_status', 'platform_provenance_verified',
    'consent_independently_verified', 'customer_contacted_verified', 'financial_receipt_verified',
    'verified_cash_cents', 'verified_paid_cents'))
_CONTACT = frozenset(('contact_version', 'revision', 'has_phone', 'has_wechat', 'created_at',
    'expires_at', 'revoked_at'))
_STATES = frozenset(('draft', 'submitted', 'accepted', 'rejected', 'needs_information',
    'duplicate_pending_review', 'existing_customer_pending_review', 'withdrawn', 'disputed'))
_MAX = 9007199254740991


class CompanyContactDeliveryTransportError(ValueError):
    def __init__(self, code, message, *, mutation=False, status=503):
        super().__init__(message)
        self.code = 'COMPANY_CONTACT_DELIVERY_TRANSPORT_' + code
        self.mutation_committed, self.status = mutation, status


def _fail(code, message, *, mutation=False, status=503):
    raise CompanyContactDeliveryTransportError(code, message, mutation=mutation, status=status)


def _match(value, pattern):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _int(value, minimum=0):
    return type(value) is int and minimum <= value <= _MAX


def _values(value):
    return (isinstance(value, dict) and set(value) == {'phone', 'wechat'}
        and all(isinstance(value[key], str) for key in value)
        and bool(value['phone'] or value['wechat'])
        and (not value['phone'] or re.fullmatch(r'\+?[0-9]{7,15}', value['phone']) is not None)
        and (not value['wechat'] or re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{5,29}', value['wechat']) is not None))


def valid_request(operation, data):
    if operation not in OPERATIONS or not isinstance(data, dict):
        return False
    fields = {'channel_id', 'idempotency_key'}
    if operation == STATUS:
        fields.add('operation_action')
    else:
        fields |= {'expected_revision', 'contact_version'}
        if operation == PUBLISH:
            fields |= {'consent_reference', 'notice_version', 'phone', 'wechat'}
        else:
            fields.add('expected_contact_revision')
    return (set(data) == fields and _match(data.get('channel_id'), _CHANNEL)
        and _match(data.get('idempotency_key'), _HEX)
        and (operation != STATUS or data.get('operation_action') in WRITES)
        and (operation == STATUS or _int(data.get('expected_revision'), 1)
             and _match(data.get('contact_version'), _VERSION))
        and (operation not in (REVEAL, WITHDRAW) or _int(data.get('expected_contact_revision'), 1))
        and (operation != PUBLISH or _match(data.get('consent_reference'), _CONSENT)
             and _match(data.get('notice_version'), _ID)
             and _values({key: data.get(key) for key in ('phone', 'wechat')})))


def valid_delivery(value, actor, operation, data):
    """Whitelist the complete DTO. Values may exist only in one new release."""
    if (not isinstance(value, dict) or set(value) != _FIELDS
            or value['contract'] != 'company_contact_delivery_v1'
            or value['storage_scope'] != 'company_server_contact_vault'
            or value['authenticated_actor'] != actor.get('username')
            or value['state'] not in ('not_recorded', 'unknown', 'recorded')
            or value['auto_retry'] is not False or value['plaintext_replayed'] is not False
            or any(value[key] is not False for key in ('live_kms_verified', 'platform_provenance_verified',
                'consent_independently_verified', 'customer_contacted_verified', 'financial_receipt_verified'))
            or any(value[key] is not None for key in ('verified_cash_cents', 'verified_paid_cents'))
            or value['current_channel_status'] not in _STATES
            or value['channel_binding_state'] not in ('unbound', 'unknown', 'recorded')
            or not isinstance(value['permissions'], dict)
            or set(value['permissions']) != {'can_publish', 'can_reveal', 'can_withdraw'}
            or any(type(v) is not bool for v in value['permissions'].values())
            or any(type(value[key]) is not bool for key in ('read_only', 'replayed', 'provider_configured', 'retention_configured',
                'contact_available', 'server_release_recorded', 'cloud_kms_requested', 'current_consent_valid'))):
        return False
    action = data['operation_action'] if operation == STATUS else operation
    missing = value['state'] == 'not_recorded'
    if missing:
        if any(value[key] is not None for key in ('operation_id', 'original_action', 'original_key',
                                                 'original_execution_confirmed')):
            return False
    elif (not _match(value['operation_id'], _HEX) or value['original_action'] != action
            or value['original_key'] != data['idempotency_key']
            or value['original_execution_confirmed'] is not (True if value['state'] == 'recorded' else None)):
        return False
    pure = operation == STATUS or value['replayed']
    if pure:
        if (value['read_only'] is not True or value['mutation_committed'] is not False
                or value['contact_values'] is not None or value['cloud_kms_requested'] is not False):
            return False
    elif value['read_only'] is not False or value['mutation_committed'] is not True or value['state'] != 'recorded':
        return False
    if value['server_release_recorded'] is not (value['state'] == 'recorded' and action == REVEAL):
        return False
    contact = value['contact']
    if contact is not None and (not isinstance(contact, dict) or set(contact) != _CONTACT
            or not _match(contact['contact_version'], _VERSION) or not _int(contact['revision'], 1)
            or type(contact['has_phone']) is not bool or type(contact['has_wechat']) is not bool
            or not _int(contact['created_at'], 1577836800) or not _int(contact['expires_at'], contact['created_at'])
            or contact['revoked_at'] is not None and not _int(contact['revoked_at'], contact['created_at'])):
        return False
    if value['contact_available'] and (contact is None or contact['revoked_at'] is not None
            or value['current_consent_valid'] is not True or value['current_channel_status'] not in ('submitted', 'accepted')):
        return False
    if ((contact is not None) != (value['channel_binding_state'] == 'recorded')
            or value['permissions']['can_publish'] and (value['provider_configured'] is not True
                or value['retention_configured'] is not True or value['channel_binding_state'] != 'unbound'
                or value['current_consent_valid'] is not True
                or value['current_channel_status'] not in ('draft', 'submitted', 'accepted'))
            or value['permissions']['can_reveal'] and (value['provider_configured'] is not True
                or value['contact_available'] is not True or value['state'] != 'not_recorded')
            or value['permissions']['can_withdraw'] and (contact is None or contact['revoked_at'] is not None)):
        return False
    if not pure and operation == REVEAL:
        return value['contact_available'] is True and _values(value['contact_values'])
    return value['contact_values'] is None


class CompanyContactDeliveryTransport(CompanyHandoffStatusTransport):
    def __init__(self, server, user, *, device_id, **kwargs):
        if not _match(device_id, _ID):
            raise ValueError('联系方式交付需要可信当前设备')
        super().__init__(server, user, **kwargs)
        self.device_id = device_id

    def _contact_capture(self, actor, margin, *, dispatched=False):
        try:
            return self._capture(actor, margin)
        except CompanyHandoffStatusTransportError:
            _fail('BINDING_CHANGED', '当前公司联系方式身份或连接需核对，请保留原号',
                  mutation=None if dispatched else False, status=409)

    def fixed_session_guard(self, actor):
        """Bind one LOCAL operation through its final HTTP projection, RAM only.

        Create this from a transport using the base host scope guard; transports
        using the returned guard may then fence every await without recursion.
        Neither the saved config/token nor this closure is a response or record.
        """
        connection = self._contact_capture(actor, 60)
        principal = deepcopy(self.server.core.store.get('users', self.user['id']))
        def current():
            try:
                return (self.server.core.store.get('users', self.user['id']) == principal
                    and self._contact_capture(actor, 0) == connection)
            except Exception:
                return False
        return current

    def __call__(self, actor, operation, data):
        if not valid_request(operation, data):
            _fail('INVALID_REQUEST', '联系方式交付只接受固定渠道、版本及原编号', status=400)
        writing = operation in WRITES
        before = self._contact_capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], dict(environment_id=self.environment_id,
                operation=operation, expected_device_id=self.device_id, **deepcopy(data)), before['token'])
        except Exception:
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE',
                '原联系方式操作尚未确认，请保留原号核对；未自动重发' if writing else '联系方式原操作暂不可读，请稍后核对',
                mutation=None if writing else False)
        after = self._contact_capture(actor, 0, dispatched=writing)
        fields = {'contract', 'environment_id', 'company_id', 'delivery', 'read_only', 'mutation_committed', 'auto_retry'}
        if (after != before or not isinstance(result, dict) or set(result) != fields
                or result.get('contract') != 'fangyu-workspace-v1' or result.get('environment_id') != self.environment_id
                or result.get('company_id') != self.company_id or result.get('auto_retry') is not False
                or not valid_delivery(result.get('delivery'), actor, operation, data)
                or any(result[key] != result['delivery'][key] or type(result[key]) is not type(result['delivery'][key])
                       for key in ('read_only', 'mutation_committed', 'auto_retry'))):
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE', '原联系方式回执身份或格式需核对，请保留原号',
                  mutation=None if writing else False)
        if self._contact_capture(actor, 0, dispatched=writing) != before:
            _fail('BINDING_CHANGED', '最终返回时公司联系方式连接已变化，请保留原号', mutation=None if writing else False)
        return {key: deepcopy(result[key]) for key in ('delivery', 'read_only', 'mutation_committed', 'auto_retry')}


HANDOFF_WITHDRAW = 'acquisition_handoff_withdraw'
HANDOFF_STATUS = 'acquisition_handoff_operation_status'


class CompanyContactWithdrawalTransport(CompanyHandoffStatusTransport):
    """Fixed privacy stop, including an unknown publish without a vault record."""
    def _withdraw_capture(self, actor, margin, *, dispatched=False):
        try:
            return self._capture(actor, margin)
        except CompanyHandoffStatusTransportError:
            _fail('BINDING_CHANGED', '公司撤回当前身份或连接需核对，请保留原号',
                  mutation=None if dispatched else False, status=409)

    def __call__(self, actor, operation, data):
        writing = operation == HANDOFF_WITHDRAW
        fields = {'channel_id', 'expected_revision', 'idempotency_key', 'reason_code'} if writing else {'operation_action', 'idempotency_key'}
        if (operation not in (HANDOFF_WITHDRAW, HANDOFF_STATUS) or not isinstance(data, dict)
                or set(data) != fields or not _match(data.get('idempotency_key'), _HEX)
                or writing and (not _match(data.get('channel_id'), _CHANNEL)
                    or not _int(data.get('expected_revision'), 1) or data.get('reason_code') != 'customer_withdrew')
                or not writing and data.get('operation_action') != HANDOFF_WITHDRAW):
            _fail('INVALID_REQUEST', '公司撤回仅允许本人原渠道、原版本和客户撤回原因', status=400)
        before = self._withdraw_capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], dict(environment_id=self.environment_id,
                operation=operation, **deepcopy(data)), before['token'])
        except Exception:
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE', '公司撤回原号尚待核对，未自动重发', mutation=None if writing else False)
        after = self._withdraw_capture(actor, 0, dispatched=writing)
        outer = {'contract', 'environment_id', 'company_id'}
        expected = outer | ({'item', 'replayed', 'server_recorded', 'platform_delivery_verified', 'attribution_confirmed', 'settlement_active'}
            if writing else {'operation_receipt', 'read_only', 'mutation_committed', 'auto_retry'})
        valid = (after == before and isinstance(result, dict) and set(result) == expected
            and result.get('contract') == 'fangyu-workspace-v1' and result.get('environment_id') == self.environment_id
            and result.get('company_id') == self.company_id)
        if valid and writing:
            valid = (type(result['replayed']) is bool and result['server_recorded'] is True
                and all(result[k] is False for k in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active')))
        elif valid:
            valid = result['read_only'] is True and result['mutation_committed'] is False and result['auto_retry'] is False
        if not valid or self._withdraw_capture(actor, 0, dispatched=writing) != before:
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE', '公司撤回回执或当前身份需核对', mutation=None if writing else False)
        return {key: deepcopy(v) for key, v in result.items() if key not in outer}
