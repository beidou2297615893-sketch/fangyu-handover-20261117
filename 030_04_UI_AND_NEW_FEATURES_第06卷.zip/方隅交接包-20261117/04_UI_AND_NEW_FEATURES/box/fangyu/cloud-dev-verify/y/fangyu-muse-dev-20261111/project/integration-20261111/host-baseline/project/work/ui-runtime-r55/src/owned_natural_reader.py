"""Owned WebView2 natural-response reader, opt-in and without a request API.

Page operations are bounded DOM reads, one fixed comment viewport scroll, or
one root-bound reply expansion, gated by an already active native call.
CDP requestId/loaderId/frameId
bind response bodies to one physical document and task. Import is inert.
"""

from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
import json
from pathlib import Path
import re
from threading import RLock
import time
from urllib.parse import parse_qs, urlsplit

from natural_page_controller import ObservedResponse, _note_source, _url_parts
from xhs_search_range import build_search_range_js, validate_search_snapshot
from xhs_dom_rows import build_wanted_dom_rows_js, validate_wanted_rows
from xhs_search_range import validate_checkpoint
from xhs_root_expander import build_root_expander_js, validate_root_expander_result


MAX_BODY = 4 * 1024 * 1024
MAX_EVENT = 256 * 1024
MAX_REQUESTS = 64
ENABLE_ARGS = json.dumps({"maxResourceBufferSize": MAX_BODY,
                          "maxTotalBufferSize": MAX_BODY * 2,
                          "maxPostDataSize": 0}, separators=(",", ":"))
DOM_SCRIPT = Path(__file__).with_name("resources").joinpath(
    "xhs-natural-dom-rows.js").read_text(encoding="utf-8")
COMMENT_SCRIPT = Path(__file__).with_name("resources").joinpath(
    "xhs-natural-comment-controls.js").read_text(encoding="utf-8")
_API = {
    ("GET", "/api/sns/web/v2/user/me"): "getMe",
    ("POST", "/api/sns/web/v1/search/notes"): "search",
    ("GET", "/api/sns/web/v2/comment/page"): "comments",
    ("GET", "/api/sns/web/v2/comment/sub/page"): "sub_comments",
}


class ReaderError(RuntimeError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _pairs(items):
    value = {}
    for key, item in items:
        if key in value:
            raise ValueError("duplicate_key")
        value[key] = item
    return value


def _reject_constant(_value):
    raise ValueError("nonfinite")


def _event(raw):
    if not isinstance(raw, str) or len(raw) > MAX_EVENT:
        return None
    try:
        value = json.loads(raw, object_pairs_hook=_pairs,
                           parse_constant=_reject_constant)
        return value if isinstance(value, dict) else None
    except (ValueError, TypeError, RecursionError):
        return None


def _same_document(expected, actual):
    try:
        first, first_q = _url_parts(expected, "www.xiaohongshu.com")
        second, second_q = _url_parts(actual, "www.xiaohongshu.com")
        return first.path == second.path and first_q == second_q
    except Exception:
        return False


def _same_note_history(expected, actual):
    try:
        note_id, _, _ = _note_source(expected)
        parsed, _ = _url_parts(actual, "www.xiaohongshu.com")
        match = re.fullmatch(r"/(?:explore|search_result)/([0-9a-f]{24})/?",
                             parsed.path)
        return bool(match and match.group(1) == note_id)
    except Exception:
        return False


def _api_kind(method, url, action, params, *, replay_main=False,
              replay_sub=False, observe_main_roots=False):
    if not isinstance(method, str):
        return ""
    try:
        parsed, query = _url_parts(url, "edith.xiaohongshu.com")
    except Exception:
        return ""
    kind = _API.get((method, parsed.path), "")
    if kind == "getMe":
        return kind if not query else ""
    if kind == "comments" and action == "sub_comments" and observe_main_roots:
        actual_cursor = query.get("cursor", [""])
        return kind if (query.get("note_id") == [params.get("noteId")] and
                        len(actual_cursor) == 1 and
                        isinstance(actual_cursor[0], str) and
                        len(actual_cursor[0]) <= 512 and
                        not any(ord(char) < 32 or ord(char) == 127
                                for char in actual_cursor[0])) else ""
    if kind != action:
        return ""
    if kind == "search":
        return kind if not query else ""
    if query.get("note_id") != [params.get("noteId")]:
        return ""
    actual_cursor = query.get("cursor", [""])
    allow_other_cursor = ((replay_main and kind == "comments" and action == "comments") or
                          (replay_sub and kind == "sub_comments" and action == "sub_comments"))
    if not allow_other_cursor and actual_cursor != [params.get("cursor")]:
        return ""
    if (allow_other_cursor and
            (len(actual_cursor) != 1 or not isinstance(actual_cursor[0], str) or
             len(actual_cursor[0]) > 512 or
             any(ord(char) < 32 or ord(char) == 127 for char in actual_cursor[0]))):
        return ""
    if kind == "sub_comments" and not (
            query.get("root_comment_id") == [params.get("rootCommentId")] or
            query.get("comment_id") == [params.get("rootCommentId")]):
        return ""
    return kind


def _comment_script(note_id, action):
    if (not isinstance(note_id, str) or not re.fullmatch(r"[0-9a-f]{24}", note_id)
            or action not in ("observe", "scroll") or
            COMMENT_SCRIPT.count("'__NOTE_ID__'") != 1 or
            COMMENT_SCRIPT.count("'__ACTION__'") != 1):
        raise ReaderError("invalid_command")
    return (COMMENT_SCRIPT.replace("'__NOTE_ID__'", "'" + note_id + "'", 1)
            .replace("'__ACTION__'", "'" + action + "'", 1))


def _validate_comment_control(value):
    bools = {"action_performed", "scroll_advanced", "has_loadmore_control",
             "at_bottom", "count_capped"}
    counts = {"scroll_top_before", "scroll_top_after", "scroll_height",
              "client_height", "parent_comment_count", "nested_reply_count",
              "loadmore_control_count", "reply_expander_count"}
    if (not isinstance(value, dict) or set(value) !=
            {"code", "scroller_kind"} | bools | counts or
            value["code"] not in {"scope_invalid", "security", "login_wall",
                                  "container_ambiguous", "scroller_ambiguous",
                                  "scroller_unavailable", "observed", "scrolled",
                                  "no_scroll_advance", "action_denied"} or
            value["scroller_kind"] not in {"none", "note_scroller", "comments_container", "comment_ancestor", "document"} or
            any(type(value[key]) is not bool for key in bools)):
        raise ReaderError("comment_control_invalid")
    for key in counts:
        limit = 10_000_000 if key in {"scroll_top_before", "scroll_top_after",
                                      "scroll_height", "client_height"} else 200
        if type(value[key]) is not int or not 0 <= value[key] <= limit:
            raise ReaderError("comment_control_invalid")
    if (value["has_loadmore_control"] != (value["loadmore_control_count"] > 0) or
            (value["code"] == "scrolled") != value["scroll_advanced"] or
            value["action_performed"] != (value["code"] == "scrolled") or
            (value["scroller_kind"] == "none" and any(value[k] for k in
                ("scroll_top_before", "scroll_top_after", "scroll_height", "client_height")))):
        raise ReaderError("comment_control_invalid")
    return value


@dataclass
class _Request:
    kind: str
    method: str
    url: str
    request_id: str
    loader_id: str
    frame_id: str
    doc_epoch: int
    task_epoch: int
    status: int | None = None
    responded: bool = False
    finished: bool = False


class _NativeOwner:
    """UI-only access to this pywebview window's WinForms/CoreWebView2."""

    def __init__(self, window):
        from webview.platforms.winforms import BrowserView
        from System import Action, Object
        self.window = window
        self.form = BrowserView.instances.get(window.uid)
        if self.form is None:
            raise ReaderError("owned_window_invalid")
        self.action_type = Action
        self.reference_equals = Object.ReferenceEquals

    def invoke(self, callback):
        if self.form.InvokeRequired:
            captured = {}
            def run():
                try:
                    captured["value"] = callback()
                except Exception as error:
                    captured["error"] = error
            self.form.Invoke(self.action_type(run))
            if "error" in captured:
                raise captured["error"]
            return captured.get("value")
        return callback()

    def core(self):
        form = self.form
        browser = form.browser
        if (form.pywebview_window is not self.window or browser is None or
                browser.pywebview_window is not self.window):
            raise ReaderError("owned_window_invalid")
        control = browser.webview
        if control is None or not self.reference_equals(control, form.webview):
            raise ReaderError("owned_window_invalid")
        return control, control.CoreWebView2

    def same_core(self, first, second):
        return self.reference_equals(first, second)


class OwnedNaturalReader:
    """Attach at about:blank, then accept only site-generated fixed API bodies.

    ``native`` is injectable for synthetic tests; production resolves the
    actual owned WinForms control. Navigation approval belongs to the caller.
    """

    def __init__(self, window, *, navigation_callback, native=None):
        if not callable(navigation_callback):
            raise ReaderError("invalid_scope")
        self.window = window
        self.navigation_callback = navigation_callback
        self.native = native
        self.lock = RLock()
        self.attached = False
        self.closed = False
        self.error_code = ""
        self._terminal_response = False
        self.doc_epoch = 1
        self.task_epoch = 0
        self.action = ""
        self.params = {}
        self.target_url = ""
        self.bound_uid = ""
        self.current_url = "about:blank"
        self.loader_id = ""
        self.frame_id = ""
        self.scroll_count = 0
        self.search_scroll_count = 0
        self.replay_main = False
        self.replay_sub = False
        self.observe_main_roots = False
        self.last_comment_control = None
        self.expanded_roots = set()
        self.observed_root_controls = {}
        self._delivered_sub = {}
        self._used_sub_grants = set()
        self._granted_cursors = set()
        self._authorized_page_cursor = None
        self._navigation_issued = False
        self._requests = {}
        self._used_ids = set()
        self._pending = []
        self._immediate = []
        self._refs = None

    def _fail(self, code):
        if not self.error_code:
            self.error_code = code

    def attach(self):
        if self.closed or self.attached:
            raise ReaderError("invalid_state")
        self.native = self.native or _NativeOwner(self.window)
        deadline = time.monotonic() + 6
        while True:
            try:
                self.native.invoke(self._attach_ui)
                break
            except ReaderError as error:
                if error.code not in ("core_pending", "initial_source_pending"):
                    raise
                if time.monotonic() >= deadline:
                    raise ReaderError("core_init_timeout") from None
                time.sleep(0.1)
        try:
            task = self._enable_task
            if not task.Wait(10000) or task.IsCanceled or task.IsFaulted:
                raise ReaderError("cdp_unavailable")
        except ReaderError:
            self.close()
            raise
        except Exception:
            self.close()
            raise ReaderError("cdp_unavailable") from None
        self.attached = True
        return self

    def runtime_sources(self, profile):
        if not self.attached or self.closed or type(self.native) is not _NativeOwner:
            raise ReaderError("owned_window_invalid")
        from owned_window_sources import collect_window_facts
        return collect_window_facts(self.native, profile)

    def _attach_ui(self):
        control, core = self.native.core()
        if core is None:
            raise ReaderError("core_pending")
        source = str(core.Source)
        if not source:
            raise ReaderError("initial_source_pending")
        if source != "about:blank":
            raise ReaderError("initial_source_invalid")
        receivers = []

        def subscribe(name, handler):
            receiver = core.GetDevToolsProtocolEventReceiver(name)
            receiver.DevToolsProtocolEventReceived += handler
            receivers.append((receiver, handler))

        def navigation(_sender, args):
            uri = str(args.Uri)
            redirected = bool(getattr(args, "IsRedirected", False))
            with self.lock:
                if self.closed or not self.action:
                    allowed = False
                else:
                    try:
                        allowed = self.navigation_callback(uri, redirected=redirected) is True
                    except Exception:
                        allowed = False
                if not allowed:
                    args.Cancel = True
                    self._fail("navigation_changed")
                    return
                self.doc_epoch += 1
                self.current_url = uri
                self.loader_id = self.frame_id = ""
                self._requests.clear()
                self._pending.clear()
                self._immediate.clear()
                self._delivered_sub.clear()
                self._used_sub_grants.clear()
                self._granted_cursors.clear()
                self._authorized_page_cursor = None
                self.expanded_roots.clear()
                self.observed_root_controls.clear()

        def on_request(_sender, args):
            with self.lock:
                self._on_request(str(args.ParameterObjectAsJson), str(args.SessionId))

        def on_response(_sender, args):
            with self.lock:
                self._on_response(str(args.ParameterObjectAsJson), str(args.SessionId))

        def on_finished(_sender, args):
            with self.lock:
                request_id = self._on_finished(str(args.ParameterObjectAsJson),
                                               str(args.SessionId))
                if request_id:
                    try:
                        task = core.CallDevToolsProtocolMethodAsync(
                            "Network.getResponseBody",
                            json.dumps({"requestId": request_id}, separators=(",", ":")))
                        self._pending.append((request_id, task))
                    except Exception:
                        self._fail("body_unavailable")

        control.NavigationStarting += navigation
        try:
            subscribe("Network.requestWillBeSent", on_request)
            subscribe("Network.responseReceived", on_response)
            subscribe("Network.loadingFinished", on_finished)
            self._enable_task = core.CallDevToolsProtocolMethodAsync("Network.enable", ENABLE_ARGS)
        except Exception:
            control.NavigationStarting -= navigation
            for receiver, handler in receivers:
                receiver.DevToolsProtocolEventReceived -= handler
            raise ReaderError("cdp_unavailable") from None
        self._refs = (control, navigation, receivers)

    def arm(self, action, params, *, doc_epoch, task_epoch, target_url, bound_uid,
            replay_main=False, replay_sub=False, observe_main_roots=False,
            identity_observation=False):
        if not self.attached or self.closed or self.error_code or self._terminal_response:
            raise ReaderError("invalid_state")
        if (action not in ("status", "search", "comments", "sub_comments") or
                not isinstance(params, dict) or type(doc_epoch) is not int or
                doc_epoch != self.doc_epoch or type(task_epoch) is not int or
                task_epoch <= self.task_epoch or not isinstance(bound_uid, str) or
                not (bound_uid or identity_observation is True and action=='status')
                or type(identity_observation) is not bool or identity_observation and action!='status'
                or not isinstance(target_url, str) or
                type(replay_main) is not bool or (replay_main and action != "comments") or
                type(replay_sub) is not bool or (replay_sub and action != "sub_comments") or
                type(observe_main_roots) is not bool or
                (observe_main_roots and action != "sub_comments")):
            raise ReaderError("invalid_command")
        if self.bound_uid and bound_uid != self.bound_uid:
            raise ReaderError("scope_mismatch")
        try:
            parsed, query = _url_parts(target_url, "www.xiaohongshu.com")
            if action == "status" and (parsed.path != "/explore" or params or query):
                raise ValueError
            if action == "search" and (
                    parsed.path != "/search_result/" or
                    set(params) not in ({"keyword", "page"},
                                        {"keyword", "page", "rangeCheckpoint"}) or
                    not isinstance(params.get("keyword"), str) or
                    not 0 < len(params["keyword"]) <= 200 or
                    type(params.get("page")) is not int or params["page"] < 1 or
                    query != {"keyword": [params["keyword"]],
                              "source": ["web_explore_feed"]}):
                raise ValueError
            if action == "search" and "rangeCheckpoint" in params:
                checkpoint = validate_checkpoint(params["rangeCheckpoint"])
                if checkpoint["keyword"] != params["keyword"]:
                    raise ValueError
            if action in ("comments", "sub_comments"):
                note_id, token, source = _note_source(target_url)
                expected = {"noteId", "cursor", "token", "source"}
                if action == "sub_comments":
                    expected.add("rootCommentId")
                if (set(params) not in (expected, expected | {"noteUrl"}) or
                        note_id != params.get("noteId") or
                        token != params.get("token") or source != params.get("source") or
                        ("noteUrl" in params and params["noteUrl"] != target_url) or
                        not isinstance(params.get("cursor"), str) or
                        len(params["cursor"]) > 512 or
                        (action == "sub_comments" and not isinstance(
                            params.get("rootCommentId"), str))):
                    raise ValueError
        except Exception:
            raise ReaderError("invalid_command") from None
        with self.lock:
            if self._requests or self._pending or self._immediate:
                raise ReaderError("busy")
            self.action, self.params = action, dict(params)
            self.task_epoch = task_epoch
            self.target_url = target_url
            self.bound_uid = bound_uid
            self.replay_main = replay_main
            self.replay_sub = replay_sub
            self.observe_main_roots = observe_main_roots
            self.last_comment_control = None
            self.scroll_count = 0
            self.search_scroll_count = 0
            self.expanded_roots.clear()
            self.observed_root_controls.clear()
            self._delivered_sub.clear()
            self._used_sub_grants.clear()
            self._granted_cursors.clear()
            self._authorized_page_cursor = None
            self._navigation_issued = False
            self._requests.clear()
            self._pending.clear()
            self._immediate.clear()

    def finish_task(self, task_epoch: int) -> None:
        """Discard settled call evidence; keep physical document for a next call."""
        if not self.attached or self.closed:
            raise ReaderError("invalid_state")
        with self.lock:
            if self.action == "" or type(task_epoch) is not int or task_epoch != self.task_epoch:
                raise ReaderError("invalid_state")
            self.action = ""
            self.params = {}
            self.target_url = ""
            self.replay_main = False
            self.replay_sub = False
            self.observe_main_roots = False
            self._requests.clear()
            self._pending.clear()
            self._immediate.clear()
            self.scroll_count = 0
            self.search_scroll_count = 0
            self.expanded_roots.clear()
            self.observed_root_controls.clear()
            self._delivered_sub.clear()
            self._used_sub_grants.clear()
            self._granted_cursors.clear()
            self._authorized_page_cursor = None
            self._navigation_issued = False

    def navigate_target(self, target_url: str) -> None:
        """Navigate the owned Core explicitly, including to its current URI."""
        with self.lock:
            if (not self.attached or self.closed or self.error_code or
                    not self.action or type(target_url) is not str or
                    target_url != self.target_url or self._navigation_issued):
                raise ReaderError("navigation_denied")
            self._navigation_issued = True
        # CoreWebView2.Navigate must run on the owned UI thread. Never hold
        # reader.lock here: NavigationStarting re-enters this reader.
        def navigate():
            _, core = self.native.core()
            if core is None:
                raise ReaderError("navigation_failed")
            core.Navigate(target_url)
        try:
            self.native.invoke(navigate)
        except Exception:
            with self.lock:
                self._fail("navigation_failed")
            raise ReaderError("navigation_failed") from None

    def _on_request(self, raw, session_id=""):
        if self.closed or self.error_code or not self.action or session_id:
            return
        event = _event(raw)
        if event is None:
            return
        request = event.get("request")
        if not isinstance(request, dict):
            return
        request_id, loader, frame = (event.get(key) for key in
                                     ("requestId", "loaderId", "frameId"))
        if not all(isinstance(value, str) and value for value in
                   (request_id, loader, frame)):
            return
        if event.get("type") == "Document":
            if not _same_document(self.target_url, request.get("url")):
                return
            if self.loader_id and (self.loader_id != loader or self.frame_id != frame):
                self._fail("document_changed")
                return
            self.loader_id, self.frame_id = loader, frame
            return
        kind = _api_kind(request.get("method"), request.get("url"),
                         self.action, self.params, replay_main=self.replay_main,
                         replay_sub=self.replay_sub,
                         observe_main_roots=self.observe_main_roots)
        if not kind:
            return
        if (event.get("redirectResponse") is not None or request_id in self._used_ids or
                request_id in self._requests or not self.loader_id or
                loader != self.loader_id or frame != self.frame_id or
                len(self._requests) >= MAX_REQUESTS):
            self._fail("request_scope_invalid")
            return
        self._used_ids.add(request_id)
        self._requests[request_id] = _Request(
            kind, request["method"], request["url"], request_id,
            loader, frame, self.doc_epoch, self.task_epoch)

    def _on_response(self, raw, session_id=""):
        if self.closed or self.error_code or session_id:
            return
        event = _event(raw)
        if event is None:
            return
        record = self._requests.get(event.get("requestId"))
        if record is None:
            return
        response = event.get("response")
        if not isinstance(response, dict):
            self._fail("response_scope_invalid")
            return
        status = response.get("status")
        if (event.get("loaderId") != record.loader_id or
                event.get("frameId") != record.frame_id or
                record.doc_epoch != self.doc_epoch or record.task_epoch != self.task_epoch or
                not _api_kind(record.method, response.get("url"),
                              self.action, self.params,
                              replay_main=self.replay_main,
                              replay_sub=self.replay_sub,
                              observe_main_roots=self.observe_main_roots) == record.kind or
                type(status) not in (int, float) or
                not float(status).is_integer() or not 100 <= status <= 599):
            self._fail("response_scope_invalid")
            return
        if status == 200 and not str(response.get("mimeType", "")).startswith("application/json"):
            self._fail("response_scope_invalid")
            return
        record.status = int(status)
        record.responded = True
        if record.status >= 400:
            # A fixed HTTP rejection is sufficient evidence to stop. The
            # page may keep its verification UI active without consuming body.
            self._requests.pop(record.request_id, None)
            self._terminal_response = True
            self._immediate.append(ObservedResponse(
                kind=record.kind, method=record.method, url=record.url,
                request_id=record.request_id, loader_id=record.loader_id,
                frame_id=record.frame_id, doc_epoch=record.doc_epoch,
                task_epoch=record.task_epoch, body=b"", http_status=record.status))

    def _on_finished(self, raw, session_id=""):
        if self.closed or self.error_code or session_id:
            return None
        event = _event(raw)
        if event is None:
            return None
        record = self._requests.get(event.get("requestId"))
        if record is None:
            return None
        size = event.get("encodedDataLength")
        if (not record.responded or record.finished or
                record.doc_epoch != self.doc_epoch or record.task_epoch != self.task_epoch or
                type(size) not in (int, float) or not 0 <= size <= MAX_BODY):
            self._fail("body_unavailable")
            return None
        record.finished = True
        return record.request_id

    def pump(self) -> list[ObservedResponse]:
        if not self.attached or self.closed:
            raise ReaderError("invalid_state")
        with self.lock:
            ready = [(rid, task) for rid, task in self._pending if task.IsCompleted]
            self._pending = [(rid, task) for rid, task in self._pending if not task.IsCompleted]
            output = list(self._immediate)
            self._immediate.clear()
        for request_id, task in ready:
            with self.lock:
                record = self._requests.pop(request_id, None)
                if (record is None or not record.finished or
                        record.doc_epoch != self.doc_epoch or
                        record.task_epoch != self.task_epoch or self.error_code):
                    continue
            try:
                if task.IsFaulted or task.IsCanceled:
                    raise ValueError
                raw = str(task.Result)
                if len(raw) > MAX_BODY * 4 // 3 + 4096:
                    raise OverflowError
                payload = json.loads(raw, object_pairs_hook=_pairs,
                                     parse_constant=_reject_constant)
                body, encoded = payload["body"], payload["base64Encoded"]
                if not isinstance(body, str) or type(encoded) is not bool:
                    raise ValueError
                body_bytes = (base64.b64decode(body, validate=True) if encoded
                              else body.encode("utf-8"))
                if len(body_bytes) > MAX_BODY:
                    raise OverflowError
            except (ValueError, TypeError, KeyError, UnicodeError, OverflowError,
                    binascii.Error, RecursionError):
                if record.status in (401, 461, 471):
                    body_bytes = b""
                else:
                    self._fail("body_unavailable")
                    continue
            observed = ObservedResponse(
                kind=record.kind, method=record.method, url=record.url,
                request_id=record.request_id, loader_id=record.loader_id,
                frame_id=record.frame_id, doc_epoch=record.doc_epoch,
                task_epoch=record.task_epoch, body=body_bytes,
                http_status=record.status)
            output.append(observed)
            with self.lock:
                if (record.kind == "sub_comments" and not self.closed and
                        record.doc_epoch == self.doc_epoch and
                        record.task_epoch == self.task_epoch and
                        len(self._delivered_sub) < MAX_REQUESTS):
                    self._delivered_sub[record.request_id] = observed
        if self.error_code:
            raise ReaderError(self.error_code)
        return output

    def document_state(self) -> dict:
        if not self.attached or self.closed:
            raise ReaderError("invalid_state")
        def read():
            _, core = self.native.core()
            if core is None:
                raise ReaderError("document_changed")
            return str(core.Source)
        try:
            source = self.native.invoke(read)
        except ReaderError:
            raise
        except Exception:
            raise ReaderError("document_changed") from None
        with self.lock:
            if source:
                self.current_url = source
            return {"doc_epoch": self.doc_epoch, "loader_id": self.loader_id,
                    "frame_id": self.frame_id, "current_url": self.current_url}

    def _script(self, script, *, max_result, expected_source):
        before = self.document_state()
        with self.lock:
            before_task = self.task_epoch
        if not expected_source(before["current_url"]):
            raise ReaderError("document_scope_invalid")
        captured = {}
        def execute():
            _, core = self.native.core()
            captured["core"] = core
            return core.ExecuteScriptAsync(script)
        try:
            task = self.native.invoke(execute)
            if not task.Wait(6000) or task.IsCanceled or task.IsFaulted:
                raise ValueError
            raw = str(task.Result)
            if len(raw) > max_result:
                raise OverflowError
            value = json.loads(raw, object_pairs_hook=_pairs,
                               parse_constant=_reject_constant)
        except OverflowError:
            raise ReaderError("dom_oversize") from None
        except Exception:
            raise ReaderError("dom_unavailable") from None
        after = self.document_state()
        def same_core():
            _, current = self.native.core()
            return self.native.same_core(captured["core"], current)
        try:
            core_unchanged = self.native.invoke(same_core)
        except Exception:
            core_unchanged = False
        with self.lock:
            task_unchanged = before_task == self.task_epoch
        if ((before["doc_epoch"], before["loader_id"], before["frame_id"]) !=
                (after["doc_epoch"], after["loader_id"], after["frame_id"]) or
                not core_unchanged or not task_unchanged or
                not expected_source(after["current_url"])):
            raise ReaderError("document_changed")
        return value

    def read_search_rows(self, *, doc_epoch, task_epoch, identity_verified):
        with self.lock:
            if (self.action != "search" or self.doc_epoch != doc_epoch or
                    self.task_epoch != task_epoch or identity_verified is not True or
                    not self.loader_id or not self.frame_id):
                raise ReaderError("observation_denied")
            keyword = self.params.get("keyword")
            expected = self.target_url
        if not isinstance(keyword, str) or not keyword or len(keyword) > 200:
            raise ReaderError("invalid_command")
        script = DOM_SCRIPT.replace("__KEYWORD_JSON__", json.dumps(keyword, ensure_ascii=True))
        def source_ok(url):
            try:
                parsed, query = _url_parts(url, "www.xiaohongshu.com")
                _, expected_q = _url_parts(expected, "www.xiaohongshu.com")
                return (parsed.path in ("/search_result", "/search_result/") and
                        query.get("keyword") == expected_q.get("keyword") and
                        query.get("source") == expected_q.get("source"))
            except Exception:
                return False
        value = self._script(script, max_result=1024 * 1024,
                             expected_source=source_ok)
        return _validate_dom_rows(value)

    def read_search_range(self, keyword, action="observe", *, doc_epoch,
                          task_epoch, identity_verified):
        with self.lock:
            if (self.action != "search" or self.doc_epoch != doc_epoch or
                    self.task_epoch != task_epoch or identity_verified is not True or
                    not self.loader_id or not self.frame_id or
                    keyword != self.params.get("keyword") or
                    action not in ("observe", "scroll") or
                    (action == "scroll" and self.search_scroll_count >= 10000)):
                raise ReaderError("observation_denied")
            expected = self.target_url
            if action == "scroll":
                self.search_scroll_count += 1
        try:
            script = build_search_range_js(action, keyword=keyword)
        except Exception:
            raise ReaderError("invalid_command") from None
        def source_ok(url):
            try:
                parsed, query = _url_parts(url, "www.xiaohongshu.com")
                _, expected_q = _url_parts(expected, "www.xiaohongshu.com")
                return (parsed.path in ("/search_result", "/search_result/") and
                        query.get("keyword") == expected_q.get("keyword") and
                        query.get("source") == expected_q.get("source"))
            except Exception:
                return False
        value = self._script(script, max_result=32768, expected_source=source_ok)
        try:
            return validate_search_snapshot(value)
        except Exception:
            raise ReaderError("search_snapshot_invalid") from None

    def read_wanted_rows(self, keyword, wanted_note_ids, *, doc_epoch,
                         task_epoch, identity_verified):
        with self.lock:
            if (self.action != "search" or self.doc_epoch != doc_epoch or
                    self.task_epoch != task_epoch or identity_verified is not True or
                    not self.loader_id or not self.frame_id or
                    keyword != self.params.get("keyword")):
                raise ReaderError("observation_denied")
            expected = self.target_url
        try:
            script = build_wanted_dom_rows_js(keyword, wanted_note_ids)
        except Exception:
            raise ReaderError("invalid_command") from None
        def source_ok(url):
            try:
                parsed, query = _url_parts(url, "www.xiaohongshu.com")
                _, expected_q = _url_parts(expected, "www.xiaohongshu.com")
                return (parsed.path in ("/search_result", "/search_result/") and
                        query.get("keyword") == expected_q.get("keyword") and
                        query.get("source") == expected_q.get("source"))
            except Exception:
                return False
        value = self._script(script, max_result=1024 * 1024,
                             expected_source=source_ok)
        try:
            return validate_wanted_rows(value, wanted_note_ids)
        except Exception:
            raise ReaderError("wanted_rows_invalid") from None

    def _note_control(self, note_id, action, *, doc_epoch, task_epoch,
                      identity_verified):
        with self.lock:
            if (self.action not in ("comments", "sub_comments") or
                    self.doc_epoch != doc_epoch or self.task_epoch != task_epoch or
                    identity_verified is not True or not self.loader_id or
                    not self.frame_id or self.params.get("noteId") != note_id):
                raise ReaderError("scroll_denied")
            expected = self.target_url
            if action == "scroll":
                self.scroll_count += 1
        script = _comment_script(note_id, action)
        value = self._script(script, max_result=4096,
                             expected_source=lambda url: _same_note_history(expected, url))
        facts = _validate_comment_control(value)
        self.last_comment_control = dict(facts)
        if facts["code"] == "security":
            raise ReaderError("verification_required")
        if facts["code"] == "login_wall":
            raise ReaderError("not_authenticated")
        if action == "observe" and facts["code"] != "observed":
            raise ReaderError("comment_control_unavailable")
        if action == "scroll" and facts["code"] not in ("scrolled", "no_scroll_advance"):
            raise ReaderError("comment_control_unavailable")
        return facts

    def observe_note_comments(self, note_id, *, doc_epoch, task_epoch,
                              identity_verified):
        return self._note_control(note_id, "observe", doc_epoch=doc_epoch,
                                  task_epoch=task_epoch,
                                  identity_verified=identity_verified)

    def scroll_note_comments(self, note_id, *, doc_epoch, task_epoch,
                             identity_verified):
        return self._note_control(note_id, "scroll", doc_epoch=doc_epoch,
                                  task_epoch=task_epoch,
                                  identity_verified=identity_verified)

    def authorize_root_page(self, observed: ObservedResponse, *, doc_epoch,
                            task_epoch, identity_verified) -> str:
        """Grant one next DOM click from this reader's actual child response."""
        with self.lock:
            if (self.action != "sub_comments" or self.doc_epoch != doc_epoch or
                    self.task_epoch != task_epoch or identity_verified is not True or
                    not self.loader_id or not self.frame_id or
                    not isinstance(observed, ObservedResponse) or
                    observed.kind != "sub_comments" or observed.http_status != 200 or
                    observed.doc_epoch != doc_epoch or observed.task_epoch != task_epoch or
                    observed.loader_id != self.loader_id or
                    observed.frame_id != self.frame_id or
                    self._delivered_sub.get(observed.request_id) is not observed or
                    observed.request_id in self._used_sub_grants):
                raise ReaderError("observation_denied")
            note_id = self.params["noteId"]
            root_id = self.params["rootCommentId"]
        try:
            parsed, query = _url_parts(observed.url, "edith.xiaohongshu.com")
            if (parsed.path != "/api/sns/web/v2/comment/sub/page" or
                    query.get("note_id") != [note_id] or
                    not (query.get("root_comment_id") == [root_id] or
                         query.get("comment_id") == [root_id])):
                raise ValueError
            envelope = json.loads(observed.body.decode("utf-8"),
                                  object_pairs_hook=_pairs,
                                  parse_constant=_reject_constant)
            if (not isinstance(envelope, dict) or envelope.get("success") is False or
                    (type(envelope.get("code")) is int and envelope["code"] != 0)):
                raise ValueError
            data = envelope
            for _ in range(4):
                if not isinstance(data, dict) or "comments" in data:
                    break
                data = data.get("data")
            if (not isinstance(data, dict) or not isinstance(data.get("comments"), list) or
                    data.get("has_more") is not True):
                raise ValueError
            next_cursor = data.get("cursor")
            request_cursor = query.get("cursor", [""])[0]
            if (not isinstance(next_cursor, str) or not 0 < len(next_cursor) <= 512 or
                    any(ord(char) < 32 or ord(char) == 127 for char in next_cursor) or
                    next_cursor == request_cursor):
                raise ValueError
        except Exception:
            raise ReaderError("observation_denied") from None
        with self.lock:
            if ((root_id, next_cursor) in self.expanded_roots or
                    next_cursor in self._granted_cursors or
                    (self._authorized_page_cursor is not None and
                     request_cursor != self._authorized_page_cursor)):
                raise ReaderError("observation_denied")
            self._used_sub_grants.add(observed.request_id)
            self._granted_cursors.add(next_cursor)
            self._authorized_page_cursor = next_cursor
        return next_cursor

    def read_or_expand_root(self, note_id, root_comment_id, action="observe", *,
                            doc_epoch, task_epoch, identity_verified,
                            fallback=None, page_cursor=""):
        """Use one root-bound DOM control; only a real CDP body can supply replies."""
        with self.lock:
            if (self.action != "sub_comments" or self.doc_epoch != doc_epoch or
                    self.task_epoch != task_epoch or identity_verified is not True or
                    not self.loader_id or not self.frame_id or
                    self.params.get("noteId") != note_id or
                    self.params.get("rootCommentId") != root_comment_id or
                    action not in ("observe", "expand") or
                    not isinstance(page_cursor, str) or len(page_cursor) > 512 or
                    any(ord(char) < 32 or ord(char) == 127 for char in page_cursor) or
                    (action == "expand" and root_comment_id not in self.observed_root_controls) or
                    (action == "expand" and (root_comment_id, page_cursor) in self.expanded_roots) or
                    (action == "expand" and self._authorized_page_cursor is not None and
                     self._authorized_page_cursor != page_cursor) or
                    (action == "expand" and self.expanded_roots and
                     self._authorized_page_cursor is None)):
                raise ReaderError("observation_denied")
            expected = self.target_url
        try:
            script = build_root_expander_js(note_id, root_comment_id, action,
                                            fallback=fallback)
            evidence_key = json.dumps(fallback, sort_keys=True,
                                      ensure_ascii=True, allow_nan=False)
        except Exception:
            raise ReaderError("invalid_command") from None
        with self.lock:
            if (action == "expand" and
                    self.observed_root_controls.get(root_comment_id) !=
                    (page_cursor, evidence_key)):
                raise ReaderError("observation_denied")
        value = self._script(script, max_result=4096,
                             expected_source=lambda url: _same_note_history(expected, url))
        try:
            facts = validate_root_expander_result(value)
        except Exception:
            raise ReaderError("root_control_invalid") from None
        if facts["code"] == "security":
            raise ReaderError("verification_required")
        if facts["code"] == "login_wall":
            raise ReaderError("not_authenticated")
        if facts["code"] == "observed" and action == "observe":
            with self.lock:
                self.observed_root_controls[root_comment_id] = (page_cursor, evidence_key)
        if facts["code"] == "expanded_once":
            with self.lock:
                self.expanded_roots.add((root_comment_id, page_cursor))
                self.observed_root_controls.pop(root_comment_id, None)
                self._authorized_page_cursor = None
        return facts

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            self._requests.clear()
            self._pending.clear()
            self._immediate.clear()
            refs = self._refs
            self._refs = None
        if refs is None:
            return
        def detach():
            control, navigation, receivers = refs
            control.NavigationStarting -= navigation
            for receiver, handler in receivers:
                receiver.DevToolsProtocolEventReceived -= handler
        try:
            self.native.invoke(detach)
        except Exception:
            raise ReaderError("cleanup_failed") from None


def _validate_dom_rows(value):
    top = {"code", "rows", "total_card_count", "untitled_card_count",
           "ambiguous_card_count", "signed_row_count",
           "source_pair_present_count", "capped"}
    if not isinstance(value, dict) or set(value) != top or value.get("code") not in (
            "rows_observed", "no_usable_rows_observed", "security", "login_wall",
            "untrusted_page"):
        raise ReaderError("dom_invalid")
    rows = value.get("rows")
    if (not isinstance(rows, list) or len(rows) > 40 or
            type(value["capped"]) is not bool or
            any(type(value[key]) is not int or not 0 <= value[key] <= 200
                for key in top - {"code", "rows", "capped"}) or
            len(rows) > value["total_card_count"] or
            (value["code"] in ("security", "login_wall", "untrusted_page") and
             (rows or value["total_card_count"]))):
        raise ReaderError("dom_invalid")
    seen = set()
    signed = paired = 0
    for row in rows:
        if not isinstance(row, dict) or set(row) != {
                "note_id", "xsec_token", "xsec_source", "title", "author",
                "url", "author_avatar_url", "cover_url"}:
            raise ReaderError("dom_invalid")
        try:
            note_id, token, source = _note_source(row["url"])
        except Exception:
            raise ReaderError("dom_invalid") from None
        if (row["note_id"] != note_id or row["xsec_token"] != token or
                row["xsec_source"] != source or note_id in seen or
                not isinstance(row["title"], str) or not row["title"] or
                len(row["title"]) > 300 or not isinstance(row["author"], str) or
                len(row["author"]) > 120):
            raise ReaderError("dom_invalid")
        seen.add(note_id)
        signed += bool(token)
        paired += bool(token and source)
        for field in ("author_avatar_url", "cover_url"):
            image = row[field]
            if not isinstance(image, str) or len(image) > 2048:
                raise ReaderError("dom_invalid")
            if image:
                try:
                    parsed = urlsplit(image)
                    host = parsed.hostname or ""
                    if (parsed.scheme != "https" or parsed.port not in (None, 443)
                            or parsed.username or parsed.password or parsed.fragment
                            or not (host == "xiaohongshu.com" or host.endswith(".xiaohongshu.com")
                                    or host == "xhscdn.com" or host.endswith(".xhscdn.com"))):
                        raise ValueError
                except ValueError:
                    raise ReaderError("dom_invalid") from None
    if ((value["code"] == "rows_observed") != bool(rows) or
            value["signed_row_count"] != signed or
            value["source_pair_present_count"] != paired):
        raise ReaderError("dom_invalid")
    return value


__all__ = ["OwnedNaturalReader", "ReaderError"]
