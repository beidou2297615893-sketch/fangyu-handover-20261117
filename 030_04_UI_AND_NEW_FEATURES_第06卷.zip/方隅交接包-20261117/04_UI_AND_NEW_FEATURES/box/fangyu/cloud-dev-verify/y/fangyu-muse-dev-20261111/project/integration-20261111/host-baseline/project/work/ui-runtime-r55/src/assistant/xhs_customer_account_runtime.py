"""Account-only natural runtime beside the original CLI collection route.

No temporary detach, extra executor or new lock table. Only the original
identity/session workers may acquire the original collection-mode lease and
account OS lock; cleanup retains their exact owner until physical shutdown.
"""
import os
from pathlib import Path
import threading

_SEAL = object()
_PURPOSES = frozenset(('identity_observation', 'session_recovery'))


def _fail():
    raise ValueError('customer_account_runtime_unavailable')


def runtime_for(server):
    from .xhs_page_runtime import XhsPageRuntime
    if not getattr(server, '_customer_natural_component', False):
        return getattr(server, 'xhs_page_runtime', None)
    runtime = getattr(server, 'xhs_account_runtime', None)
    if (type(runtime) is not XhsPageRuntime or runtime.core is not server.core
            or not runtime.natural_mode or runtime.closed
            or runtime.app_context_factory is not server._xhs_app_context
            or runtime is getattr(server, 'xhs_page_runtime', None)
            or runtime is server.core.adapters.xhs_page_runtime
            or getattr(server.core.adapters, 'xhs_account_runtime', None) is not runtime
            or getattr(server.core.adapters, '_xhs_account_cleanup_runtime', None) is not runtime):
        return None
    return runtime


def account_runtime_matches(server, runtime):
    return runtime is not None and runtime_for(server) is runtime


def natural_collection_selected(server):
    """The exact configured collector, independent of account window presence."""
    return bool(getattr(server, '_customer_natural_component', False)
        and (server.company.get('runtime') or {}).get('xiaohongshu_read_transport') == 'natural_page_v1')


def cleanup_runtime(adapters):
    """Only the retained original owner; execution selector changes cannot hide it."""
    from .xhs_page_runtime import XhsPageRuntime
    runtime = getattr(adapters, '_xhs_account_cleanup_runtime', None)
    if runtime is None:
        return None
    if type(runtime) is not XhsPageRuntime or runtime.core.adapters is not adapters:
        _fail()
    # The collection branch already cleaned this exact owned object if an
    # execution reference was aliased. Never give this function execution use.
    return None if runtime is adapters.xhs_page_runtime else runtime


def _context_parts(context):
    from .xhs_identity_context import _IdentityExecutionContext
    from .xhs_session_context import _SessionExecutionContext
    if type(context) not in (_IdentityExecutionContext, _SessionExecutionContext):
        _fail()
    context.check()
    claim = context.claim
    server = claim.session.service.server
    job = claim.job
    expected = 'identity_observation' if type(context) is _IdentityExecutionContext else 'session_recovery'
    if (not getattr(server, '_customer_natural_component', False)
            or job.get('purpose') != expected or expected not in _PURPOSES
            or job.get('account_id') != claim.account_id or job.get('owner_id') != claim.actor_id
            or runtime_for(server) is None):
        _fail()
    return server, claim, job, expected


class _AccountOperationLock:
    def __init__(self, seal, context, root, os_lock):
        if seal is not _SEAL:
            _fail()
        server, claim, job, purpose = _context_parts(context)
        expected = server.core.store.directory / 'accounts' / claim.session.executor.tenant / claim.account_id
        if Path(root) != expected:
            _fail()
        self.seal, self.context, self.root, self.os_lock = seal, context, Path(root), os_lock
        self.server, self.claim, self.job = server, claim, job
        self.owner = 'account:' + purpose + ':' + job['id']
        self.thread = threading.current_thread()
        self.entered = self.mode_acquired = False

    def __enter__(self):
        if self.seal is not _SEAL or self.thread is not threading.current_thread() or self.entered or self.mode_acquired:
            _fail()
        self.context.check()
        core = self.server.core
        core.acquire_account_mode(self.claim.account_id, self.claim.session.executor.tenant, 'collection', self.owner)
        self.mode_acquired = True
        try:
            self.os_lock.__enter__()
            self.entered = True
            self.check()
            return self
        except BaseException:
            if self.entered:
                self.os_lock.__exit__(None, None, None)
                self.entered = False
            core.release_account_mode(self.claim.account_id, self.claim.session.executor.tenant, self.owner)
            self.mode_acquired = False
            raise

    def check(self):
        if (self.seal is not _SEAL or self.thread is not threading.current_thread()
                or not self.entered or not self.mode_acquired
                or self.job.get('_customer_account_mode_lock') is not self):
            _fail()
        self.context.check()
        core = self.server.core
        mode = core.account_mode_status(self.claim.account_id, self.claim.session.executor.tenant)
        if (mode.get('status') != 'active' or mode.get('mode') != 'collection'
                or mode.get('owner') != self.owner or mode.get('pid') != os.getpid()
                or mode.get('runtime_id') != core.continuous.leases.runtime_id):
            _fail()

    def __exit__(self, kind, value, trace):
        # Cleanup never depends on a current employee/read lease or permission.
        if self.thread is not threading.current_thread():
            _fail()
        if self.entered:
            self.os_lock.__exit__(kind, value, trace)
            self.entered = False
        if self.mode_acquired:
            self.server.core.release_account_mode(self.claim.account_id,
                self.claim.session.executor.tenant, self.owner)
            self.mode_acquired = False


def operation_lock(context, root, os_lock):
    value = _AccountOperationLock(_SEAL, context, root, os_lock)
    server, claim, job, purpose = _context_parts(context)
    with server.job_lock:
        if job.get('_customer_account_mode_lock') is not None:
            _fail()
        job['_customer_account_mode_lock'] = value
    return value


def check_operation(context, *, required):
    # No recursion into context.check here: the private lock.check calls it.
    value = context.claim.job.get('_customer_account_mode_lock')
    if value is None and not required:
        return
    if type(value) is not _AccountOperationLock or value.context is not context:
        _fail()
    if not required and not value.entered:
        return
    value.check()
