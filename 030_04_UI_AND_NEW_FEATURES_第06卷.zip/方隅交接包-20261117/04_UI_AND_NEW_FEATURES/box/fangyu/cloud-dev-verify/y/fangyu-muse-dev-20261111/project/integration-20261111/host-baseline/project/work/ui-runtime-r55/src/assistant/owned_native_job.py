"""Fixed child atomically created in a kill-on-close Windows Job Object.

No existing process is assigned or terminated. If the diagnostic parent dies,
Windows closes its non-inherited job handle and kills only the owned child tree.
"""
import ctypes
from ctypes import wintypes
import os
import subprocess
import time


class OwnedJobError(RuntimeError):
    pass


class OwnedSetupPending(OwnedJobError):
    """Retain this owned process/job until shutdown is actually confirmed."""
    def __init__(self, process):
        self.process = process
        super().__init__('owned_setup_cleanup_pending')


class STARTUPINFO(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('lpReserved', wintypes.LPWSTR), ('lpDesktop', wintypes.LPWSTR),
        ('lpTitle', wintypes.LPWSTR), ('dwX', wintypes.DWORD), ('dwY', wintypes.DWORD),
        ('dwXSize', wintypes.DWORD), ('dwYSize', wintypes.DWORD), ('dwXCountChars', wintypes.DWORD),
        ('dwYCountChars', wintypes.DWORD), ('dwFillAttribute', wintypes.DWORD), ('dwFlags', wintypes.DWORD),
        ('wShowWindow', wintypes.WORD), ('cbReserved2', wintypes.WORD), ('lpReserved2', ctypes.POINTER(wintypes.BYTE)),
        ('hStdInput', wintypes.HANDLE), ('hStdOutput', wintypes.HANDLE), ('hStdError', wintypes.HANDLE)]


class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [('hProcess', wintypes.HANDLE), ('hThread', wintypes.HANDLE),
        ('dwProcessId', wintypes.DWORD), ('dwThreadId', wintypes.DWORD)]


class STARTUPINFOEX(ctypes.Structure):
    _fields_ = [('StartupInfo', STARTUPINFO), ('lpAttributeList', ctypes.c_void_p)]


class BASIC_LIMIT(ctypes.Structure):
    _fields_ = [('PerProcessUserTimeLimit', ctypes.c_longlong), ('PerJobUserTimeLimit', ctypes.c_longlong),
        ('LimitFlags', wintypes.DWORD), ('MinimumWorkingSetSize', ctypes.c_size_t),
        ('MaximumWorkingSetSize', ctypes.c_size_t), ('ActiveProcessLimit', wintypes.DWORD),
        ('Affinity', ctypes.c_size_t), ('PriorityClass', wintypes.DWORD), ('SchedulingClass', wintypes.DWORD)]


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in
        ('ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount', 'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]


class EXTENDED_LIMIT(ctypes.Structure):
    _fields_ = [('BasicLimitInformation', BASIC_LIMIT), ('IoInfo', IO_COUNTERS),
        ('ProcessMemoryLimit', ctypes.c_size_t), ('JobMemoryLimit', ctypes.c_size_t),
        ('PeakProcessMemoryUsed', ctypes.c_size_t), ('PeakJobMemoryUsed', ctypes.c_size_t)]


class ACCOUNTING(ctypes.Structure):
    _fields_ = [(name, ctypes.c_longlong) for name in
        ('TotalUserTime', 'TotalKernelTime', 'ThisPeriodTotalUserTime', 'ThisPeriodTotalKernelTime')] + [
        (name, wintypes.DWORD) for name in ('TotalPageFaultCount', 'TotalProcesses', 'ActiveProcesses', 'TotalTerminatedProcesses')]


def _kernel():
    if os.name != 'nt':
        raise OwnedJobError('windows_job_unavailable')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    signatures = {
        'CreateJobObjectW': ([ctypes.c_void_p, wintypes.LPCWSTR], wintypes.HANDLE),
        'SetInformationJobObject': ([wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD], wintypes.BOOL),
        'CreateProcessW': ([wintypes.LPCWSTR, wintypes.LPWSTR, ctypes.c_void_p, ctypes.c_void_p, wintypes.BOOL,
            wintypes.DWORD, ctypes.c_void_p, wintypes.LPCWSTR, ctypes.POINTER(STARTUPINFO), ctypes.POINTER(PROCESS_INFORMATION)], wintypes.BOOL),
        'InitializeProcThreadAttributeList': ([ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
            ctypes.POINTER(ctypes.c_size_t)], wintypes.BOOL),
        'UpdateProcThreadAttribute': ([ctypes.c_void_p, wintypes.DWORD, ctypes.c_size_t, ctypes.c_void_p,
            ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t)], wintypes.BOOL),
        'DeleteProcThreadAttributeList': ([ctypes.c_void_p], None),
        'ResumeThread': ([wintypes.HANDLE], wintypes.DWORD),
        'CloseHandle': ([wintypes.HANDLE], wintypes.BOOL),
        'WaitForSingleObject': ([wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
        'GetExitCodeProcess': ([wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
        'GetProcessTimes': ([wintypes.HANDLE, ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME),
            ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME)], wintypes.BOOL),
        'TerminateProcess': ([wintypes.HANDLE, wintypes.UINT], wintypes.BOOL),
        'TerminateJobObject': ([wintypes.HANDLE, wintypes.UINT], wintypes.BOOL),
        'OpenProcess': ([wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
        'IsProcessInJob': ([wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.BOOL)], wintypes.BOOL),
        'QueryInformationJobObject': ([wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p], wintypes.BOOL),
    }
    for name, (args, result) in signatures.items():
        getattr(kernel, name).argtypes = args
        getattr(kernel, name).restype = result
    return kernel


class WindowsOwnedJobProcess:
    def __init__(self, command, *, environment=None, _before_resume=None):
        if _before_resume is not None:
            from .owned_xhs_native.provider import _PreResumeGuard
            if type(_before_resume) is not _PreResumeGuard:
                raise OwnedJobError('owned_binding_unconfirmed')
        kernel = self.kernel = _kernel()
        self.job = self.process = None
        self.pid = None
        self.returncode = None
        self.closed = False
        self.resumed = False
        job = kernel.CreateJobObjectW(None, None)
        if not job:
            raise OwnedJobError('job_unavailable')
        self.job = job
        limits = EXTENDED_LIMIT()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not kernel.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            kernel.CloseHandle(job)
            self.job = None
            raise OwnedJobError('job_unavailable')
        startup, info = STARTUPINFOEX(), PROCESS_INFORMATION()
        startup.StartupInfo.cb = ctypes.sizeof(startup)
        startup.StartupInfo.dwFlags, startup.StartupInfo.wShowWindow = 1, 0
        environment = dict(os.environ) if environment is None else dict(environment)
        block = ctypes.create_unicode_buffer('\0'.join(key+'='+value for key, value in
            sorted(environment.items(), key=lambda pair: pair[0].upper()))+'\0\0')
        argv = ctypes.create_unicode_buffer(subprocess.list2cmdline(command.argv))
        # Windows 10+: create directly in this Job, retaining suspension until
        # membership is confirmed. No Create->Assign gap or unsafe fallback.
        initialized = False
        try:
            size = ctypes.c_size_t()
            kernel.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
            if not 1 <= size.value <= 1024*1024:
                raise OwnedJobError('atomic_job_creation_unavailable')
            attributes = ctypes.create_string_buffer(size.value)
            startup.lpAttributeList = ctypes.cast(attributes, ctypes.c_void_p)
            if not kernel.InitializeProcThreadAttributeList(startup.lpAttributeList, 1, 0, ctypes.byref(size)):
                raise OwnedJobError('atomic_job_creation_unavailable')
            initialized = True
            jobs = (wintypes.HANDLE*1)(job)
            if not kernel.UpdateProcThreadAttribute(startup.lpAttributeList, 0, 0x2000D,
                    ctypes.cast(jobs, ctypes.c_void_p), ctypes.sizeof(jobs), None, None):
                raise OwnedJobError('atomic_job_creation_unavailable')
            created = kernel.CreateProcessW(command.argv[0], argv, None, None, False,
                0x4 | 0x400 | 0x08000000 | 0x80000, block, command.cwd,
                ctypes.byref(startup.StartupInfo), ctypes.byref(info))
        except Exception:
            kernel.CloseHandle(job)  # no child was successfully created
            self.job = None
            raise
        finally:
            if initialized:
                kernel.DeleteProcThreadAttributeList(startup.lpAttributeList)
        if not created:
            kernel.CloseHandle(job)
            self.job = None
            raise OwnedJobError('owned_spawn_unavailable')
        self.process, self.pid = info.hProcess, info.dwProcessId
        try:
            membership = wintypes.BOOL()
            if (not kernel.IsProcessInJob(info.hProcess, job, ctypes.byref(membership))
                    or not membership.value):
                raise OwnedJobError('atomic_job_membership_unavailable')
            if _before_resume is not None:
                _before_resume.verify(self, command, environment)
                resumed = _before_resume.resume(self, info.hThread, command, environment)
            else:
                resumed = kernel.ResumeThread(info.hThread)
            if resumed == 0xffffffff:
                raise OwnedJobError('owned_resume_unavailable')
            self.resumed = True
        except Exception:
            try:
                self.close()
            except Exception:
                # The parent host receives the object and continues owning its
                # handles and account lock. It cannot pretend process=None.
                raise OwnedSetupPending(self) from None
            raise
        finally:
            kernel.CloseHandle(info.hThread)

    def poll(self):
        if not self.process:
            return self.returncode
        state = self.kernel.WaitForSingleObject(self.process, 0)
        if state == 0x102:
            return None
        if state != 0:
            raise OwnedJobError('owned_process_unavailable')
        value = wintypes.DWORD()
        if not self.kernel.GetExitCodeProcess(self.process, ctypes.byref(value)):
            raise OwnedJobError('owned_process_unavailable')
        self.returncode = int(value.value)
        return self.returncode

    def wait(self, timeout):
        state = self.kernel.WaitForSingleObject(self.process, max(0, int(timeout*1000)))
        if state == 0x102:
            raise TimeoutError('owned_process_timeout')
        return self.poll()

    def terminate(self):
        if not self.kernel.TerminateJobObject(self.job, 1):
            raise OwnedJobError('owned_cancel_unavailable')

    kill = terminate

    def contains(self, pid, created):
        handle = self.kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return None
        try:
            timestamps = [wintypes.FILETIME() for _ in range(4)]
            if not self.kernel.GetProcessTimes(handle, *(ctypes.byref(value) for value in timestamps)):
                return None
            observed = ((int(timestamps[0].dwHighDateTime) << 32) | int(timestamps[0].dwLowDateTime)) + 504911232000000000
            # WMI DateTime rounds native 100ns FILETIME to microseconds.
            if type(created) is not int or not 0 <= observed-created <= 9:
                return None
            found = wintypes.BOOL()
            if not self.kernel.IsProcessInJob(handle, self.job, ctypes.byref(found)):
                return None
            return bool(found.value)
        finally:
            self.kernel.CloseHandle(handle)

    def close(self):
        if self.closed:
            return
        self.terminate()
        # Retain the account lock while descendants exit. A timeout is unknown,
        # never reported as confirmed cleanup; job handle remains kill-on-close.
        deadline = time.monotonic()+10
        while True:
            accounting = ACCOUNTING()
            if not self.kernel.QueryInformationJobObject(self.job, 1, ctypes.byref(accounting), ctypes.sizeof(accounting), None):
                raise OwnedJobError('owned_exit_unavailable')
            if accounting.ActiveProcesses == 0:
                break
            if time.monotonic() >= deadline:
                raise OwnedJobError('owned_exit_unconfirmed')
            time.sleep(.05)
        self.wait(timeout=3)  # confirm the process handle as well as job count
        self.kernel.CloseHandle(self.process)
        self.kernel.CloseHandle(self.job)
        self.process = self.job = None
        self.closed = True
