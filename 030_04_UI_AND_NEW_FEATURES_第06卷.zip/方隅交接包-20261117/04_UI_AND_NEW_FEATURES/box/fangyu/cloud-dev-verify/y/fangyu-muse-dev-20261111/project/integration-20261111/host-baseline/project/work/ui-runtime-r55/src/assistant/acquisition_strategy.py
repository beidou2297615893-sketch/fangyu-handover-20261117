"""Private backend keyword strategy and bounded local scheduling.

The legacy AI keyword pool/tasks are untouched. No AI, platform or billing call.
Quotas count keyword query slots, not an unverified platform HTTP rate limit.
"""
import hashlib
import json
import re
import time
import unicodedata
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from core.platform_capabilities import capability_catalog

MAX_KEYWORDS = 50000
MAX_IMPORT_ROWS = 50000
MAX_BATCH_SIZE = 100
MAX_QUERY_QUOTA = 1000000
MAX_PAGE_SIZE = 200
MAX_PAYLOAD_BYTES = 16 * 1024 * 1024
ENTITY = 'acquisition_strategies'
OPERATIONS = 'acquisition_strategy_operations'


class StrategyError(ValueError):
    code = 'STRATEGY_INVALID'


class StrategyPermissionError(StrategyError):
    code = 'STRATEGY_FORBIDDEN'


class StrategyRevisionConflict(StrategyError):
    code = 'STRATEGY_REVISION_CONFLICT'


class StrategyBusy(StrategyError):
    code = 'STRATEGY_BUSY'


def _safe_rejection(error):
    """Mark only this atomic module's explicit validation/rollback failures.

    The shared exception classes carry no default commit claim: another service
    or a database context can raise the same type after committing its work.
    """
    error.mutation_committed = False
    return error


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _integer(value, minimum, maximum, label):
    if type(value) is not int or not minimum <= value <= maximum:
        raise _safe_rejection(StrategyError(f'{label}必须为{minimum}到{maximum}的整数'))
    return value


def _text(value, maximum, label, empty=False):
    if not isinstance(value, str) or len(value) > maximum * 3:
        raise _safe_rejection(StrategyError(f'{label}格式无效'))
    value = unicodedata.normalize('NFKC', value)
    if any(unicodedata.category(char) in ('Cc', 'Cf', 'Cs') for char in value):
        raise _safe_rejection(StrategyError(f'{label}包含控制字符'))
    value = ' '.join(value.split())
    if len(value) > maximum or (not value and not empty):
        raise _safe_rejection(StrategyError(f'{label}长度无效'))
    # Formula-like cells are rejected before import; exports need no evaluation.
    if value.startswith(('=', '+', '-', '@')):
        raise _safe_rejection(StrategyError(f'{label}不能是表格公式'))
    return value


def normalize_keywords(values):
    if not isinstance(values, list) or len(values) > MAX_IMPORT_ROWS:
        raise _safe_rejection(StrategyError(f'单次导入最多{MAX_IMPORT_ROWS}行'))
    result, seen = [], set()
    for value in values:
        if isinstance(value, str):
            value = {'keyword': value}
        if not isinstance(value, dict) or set(value) - {'keyword', 'group', 'priority', 'enabled'}:
            raise _safe_rejection(StrategyError('关键词行格式无效'))
        word = _text(value.get('keyword'), 120, '关键词')
        if re.search(r'https?://|www\.|[/\\]', word, re.I):
            raise _safe_rejection(StrategyError('关键词不能包含链接或路径'))
        key = word.casefold()
        priority = _integer(value.get('priority', 50), 0, 100, '优先级')
        enabled = value.get('enabled', True)
        if type(enabled) is not bool:
            raise _safe_rejection(StrategyError('关键词启用状态格式无效'))
        group = _text(value.get('group', ''), 40, '主题分组', empty=True)
        if key in seen:
            continue
        seen.add(key)
        result.append({'keyword': word, 'key': key, 'group': group,
                       'priority': priority, 'enabled': enabled})
    return result


class AcquisitionStrategy:
    def __init__(self, core, tenant, owner, company):
        if not isinstance(tenant, str) or not tenant or not isinstance(owner, str) or not owner:
            raise _safe_rejection(StrategyError('策略归属格式无效'))
        if not isinstance(company, dict):
            raise _safe_rejection(StrategyError('企业配置格式无效'))
        self.core, self.tenant, self.owner = core, tenant, owner
        # Trusted configuration captured at construction, never merged from data.
        self.company = deepcopy(company)
        self.ident = _digest(['acquisition-strategy-v1', tenant, owner])

    @contextmanager
    def _transaction(self):
        with self.core.lock:
            with self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                yield db

    def _authorize(self, db, user, private=False):
        if not isinstance(user, dict) or not isinstance(user.get('id'), str):
            raise _safe_rejection(StrategyPermissionError('策略需要有效的员工身份'))
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         ('users', user['id'], self.tenant)).fetchone()
        current = json.loads(row['body']) if row else None
        identity = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
        if (not isinstance(current, dict) or current.get('disabled')
                or any(current.get(key) != user.get(key) for key in identity)
                or current.get('tenant_id') != self.tenant
                or current.get('username') != self.owner
                or current.get('role') not in ('admin', 'operator')):
            raise _safe_rejection(StrategyPermissionError('员工身份或策略归属已变化'))
        policy = self.company.get('acquisitionStrategy', {})
        owners = policy.get('operatorOwners', []) if isinstance(policy, dict) else []
        valid_owners = (isinstance(owners, list) and all(isinstance(item, str) and item for item in owners))
        manager = (current['role'] == 'admin' or
                   (current.get('cloud_bound') is True and valid_owners and self.owner in owners))
        if current['role'] == 'operator' and current.get('cloud_bound') is not True:
            raise _safe_rejection(StrategyPermissionError('策略需要绑定员工身份'))
        if private and not manager:
            raise _safe_rejection(StrategyPermissionError('后台策略仅限已授权的策略管理员'))
        return manager

    def _load(self, db):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (ENTITY, self.ident, self.tenant)).fetchone()
        if not row:
            return {'id': self.ident, 'tenant_id': self.tenant, 'owner': self.owner,
                    'name': '获客后台策略', 'city': '', 'area': '', 'revision': 0,
                    'keywords': [], 'active_batch_size': 20, 'total_query_quota': 2000,
                    'queries_spent': 0, 'cursor': 0, 'cycle': 0, 'enabled': False,
                    'lease': None, 'created_at': '', 'updated_at': ''}
        value = json.loads(row['body'])
        if value.get('owner') != self.owner or value.get('tenant_id') != self.tenant:
            raise _safe_rejection(StrategyPermissionError('策略归属不一致'))
        return value

    @staticmethod
    def _put(db, entity, value):
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                   (entity, value['id'], value['tenant_id'],
                    json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))))

    def _summary(self, value, manager):
        lease = value.get('lease')
        reserved = len(lease['keywords']) if lease else 0
        return {'id': value['id'], 'name': value['name'], 'city': value['city'], 'area': value['area'],
                'revision': value['revision'], 'keyword_count': len(value['keywords']),
                'enabled_keyword_count': sum(item['enabled'] for item in value['keywords']),
                'enabled': value['enabled'], 'active_batch_size': value['active_batch_size'],
                'total_query_quota': value['total_query_quota'], 'queries_spent': value['queries_spent'],
                'queries_reserved': reserved,
                'queries_remaining': max(0, value['total_query_quota'] - value['queries_spent'] - reserved),
                'quota_unit': 'keyword_query_slots', 'cursor': value['cursor'], 'cycle': value['cycle'],
                'lease_active': bool(lease), 'can_manage': manager,
                'scheduler_only': True, 'platform_requests_started': False,
                'updated_at': value['updated_at']}

    def _operation(self, db, action, data):
        token = data.get('idempotency_key')
        if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,128}', token):
            raise _safe_rejection(StrategyError('幂等键必须为8到128位字母、数字、下划线或连字符'))
        identifier = _digest([self.ident, token])
        fingerprint = _digest([action, data])
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (OPERATIONS, identifier, self.tenant)).fetchone()
        previous = json.loads(row['body']) if row else None
        if previous:
            if previous.get('fingerprint') != fingerprint or previous.get('owner') != self.owner:
                raise _safe_rejection(StrategyError('幂等键已用于不同请求'))
            return identifier, fingerprint, previous['response']
        return identifier, fingerprint, None

    def _commit(self, db, value, operation, response):
        value['revision'] += 1
        value['updated_at'] = _stamp()
        if not value['created_at']:
            value['created_at'] = value['updated_at']
        self._put(db, ENTITY, value)
        # Store a bounded receipt, never duplicate the entire private keyword pool.
        response['revision'] = value['revision']
        response['updated_at'] = value['updated_at']
        self._put(db, OPERATIONS, {'id': operation[0], 'tenant_id': self.tenant,
                                  'owner': self.owner, 'fingerprint': operation[1],
                                  'response': response, 'created_at': value['updated_at']})
        return response

    @staticmethod
    def _check_revision(value, data):
        revision = _integer(data.get('expected_revision'), 0, 2 ** 53 - 1, '策略版本')
        if value['revision'] != revision:
            raise _safe_rejection(StrategyRevisionConflict('后台策略版本已变化，请刷新后重试'))

    @staticmethod
    def _batch(value, limit):
        active = sorted((item for item in value['keywords'] if item['enabled']),
                        key=lambda item: (-item['priority'], item['key']))
        available = max(0, value['total_query_quota'] - value['queries_spent'])
        count = min(limit, value['active_batch_size'], len(active), available)
        if not active or not count:
            return [], 0
        cursor = value['cursor'] % len(active)
        return [deepcopy(active[(cursor + index) % len(active)]) for index in range(count)], len(active)

    def execute(self, action, data, user):
        if action not in {'strategy_get', 'strategy_save', 'strategy_import',
                          'strategy_preview_batch', 'capability_catalog'}:
            raise _safe_rejection(StrategyError('后台策略操作无效'))
        if not isinstance(data, dict):
            raise _safe_rejection(StrategyError('后台策略参数格式无效'))
        try:
            if len(json.dumps(data, ensure_ascii=False, allow_nan=False).encode('utf-8')) > MAX_PAYLOAD_BYTES:
                raise _safe_rejection(StrategyError('策略请求过大，请分批导入'))
        except (ValueError, TypeError, UnicodeError) as exc:
            raise _safe_rejection(StrategyError('策略请求格式无效')) from exc
        fields = {
            'strategy_get': {'include_keywords', 'offset', 'limit'},
            'strategy_save': {'expected_revision', 'idempotency_key', 'name', 'city', 'area',
                              'active_batch_size', 'total_query_quota', 'enabled'},
            'strategy_import': {'expected_revision', 'idempotency_key', 'mode', 'keywords'},
            'strategy_preview_batch': {'limit'}, 'capability_catalog': set(),
        }
        if set(data) - fields[action]:
            raise _safe_rejection(StrategyError('后台策略含未知参数，不能修改归属或权限'))
        with self._transaction() as db:
            manager = self._authorize(db, user, action in
                                      ('strategy_save', 'strategy_import', 'strategy_preview_batch'))
            if action == 'capability_catalog':
                manifests = self.core.adapters.manifests() if getattr(self.core, 'adapters', None) else []
                return capability_catalog(self.company, manifests, Path(__file__).resolve().parents[2])
            value = self._load(db)
            if action == 'strategy_get':
                include = data.get('include_keywords', False)
                if type(include) is not bool:
                    raise _safe_rejection(StrategyError('关键词明细参数格式无效'))
                offset = _integer(data.get('offset', 0), 0, MAX_KEYWORDS, '分页位置')
                limit = _integer(data.get('limit', 100), 1, MAX_PAGE_SIZE, '分页数量')
                response = self._summary(value, manager)
                if include:
                    if not manager:
                        raise _safe_rejection(StrategyPermissionError('员工仅可查看策略范围摘要'))
                    response['keywords'] = deepcopy(value['keywords'][offset:offset + limit])
                    response['offset'] = offset
                    response['has_more'] = offset + limit < len(value['keywords'])
                return response
            if action == 'strategy_preview_batch':
                if value.get('lease'):
                    raise _safe_rejection(StrategyBusy('策略有未核实的本地租约，暂不预览下一批'))
                limit = _integer(data.get('limit', value['active_batch_size']), 1, MAX_BATCH_SIZE, '批次数量')
                keywords, _ = self._batch(value, limit)
                return {**self._summary(value, manager), 'keywords': keywords,
                        'preview_only': True, 'quota_consumed': 0}
            operation = self._operation(db, action, data)
            if operation[2] is not None:
                return deepcopy(operation[2])
            self._check_revision(value, data)
            if value.get('lease'):
                raise _safe_rejection(StrategyBusy('请先核实当前策略租约，不能同时改词库'))
            counts = {}
            if action == 'strategy_save':
                for field, maximum in (('name', 80), ('city', 40), ('area', 80)):
                    if field in data:
                        value[field] = _text(data[field], maximum, field, empty=field != 'name')
                if 'active_batch_size' in data:
                    value['active_batch_size'] = _integer(data['active_batch_size'], 1, MAX_BATCH_SIZE, '活动批次')
                if 'total_query_quota' in data:
                    quota = _integer(data['total_query_quota'], 1, MAX_QUERY_QUOTA, '总查询配额')
                    if quota < value['queries_spent']:
                        raise _safe_rejection(StrategyError('总配额不能低于已消耗数量'))
                    value['total_query_quota'] = quota
                if 'enabled' in data:
                    if type(data['enabled']) is not bool:
                        raise _safe_rejection(StrategyError('策略启用状态格式无效'))
                    value['enabled'] = data['enabled']
            else:
                mode = data.get('mode', 'append')
                if mode not in ('append', 'replace'):
                    raise _safe_rejection(StrategyError('导入模式无效'))
                imported = normalize_keywords(data.get('keywords'))
                existing = value['keywords'] if mode == 'append' else []
                seen = {item['key'] for item in existing}
                additions = [item for item in imported if item['key'] not in seen]
                if len(existing) + len(additions) > MAX_KEYWORDS:
                    raise _safe_rejection(StrategyError(f'后台策略最多{MAX_KEYWORDS}个关键词'))
                value['keywords'] = existing + additions
                # Queue topology changed; configuration edits never reset spent quota.
                value['cursor'] = 0
                counts = {'import_rows': len(data['keywords']), 'added': len(additions),
                          'duplicates': len(data['keywords']) - len(additions)}
            return self._commit(db, value, operation, {**self._summary(value, True), **counts})

    def reserve_batch(self, user, expected_revision, idempotency_key, limit=None, now=None):
        """Trusted scheduler seam, not an execute action or a platform operation."""
        data = {'expected_revision': expected_revision, 'idempotency_key': idempotency_key, 'limit': limit}
        with self._transaction() as db:
            self._authorize(db, user, True)
            value = self._load(db)
            operation = self._operation(db, 'reserve_batch', data)
            if operation[2] is not None:
                return deepcopy(operation[2])
            self._check_revision(value, data)
            if not value['enabled']:
                raise _safe_rejection(StrategyError('后台策略未启用本地调度'))
            if value.get('lease'):
                # Even expiry does not make an unknown execution safe to replay.
                raise _safe_rejection(StrategyBusy('已有租约待核实；超时不会自动重放'))
            count = _integer(value['active_batch_size'] if limit is None else limit, 1, MAX_BATCH_SIZE, '批次数量')
            keywords, active_count = self._batch(value, count)
            if not keywords:
                raise _safe_rejection(StrategyError('没有可调度关键词或总配额已耗尽'))
            epoch = time.time() if now is None else now
            if type(epoch) not in (int, float) or not 0 <= epoch < 10 ** 12:
                raise _safe_rejection(StrategyError('调度时间无效'))
            lease = {'id': uuid4().hex, 'keywords': keywords, 'created_at': epoch,
                     'expires_at': epoch + 120, 'cursor': value['cursor'], 'active_count': active_count}
            value['lease'] = lease
            return self._commit(db, value, operation,
                                {**self._summary(value, True), 'lease_id': lease['id'],
                                 'expires_at': lease['expires_at'], 'keywords': deepcopy(keywords)})

    def complete_batch(self, user, lease_id, idempotency_key, used_count=None, outcome='completed'):
        """Acknowledge known execution or conservatively spend an unknown lease.

        cancelled_before_execution spends zero; unknown spends the whole lease.
        A partial completed batch advances only its known executed prefix.
        """
        data = {'lease_id': lease_id, 'idempotency_key': idempotency_key,
                'used_count': used_count, 'outcome': outcome}
        with self._transaction() as db:
            self._authorize(db, user, True)
            value = self._load(db)
            operation = self._operation(db, 'complete_batch', data)
            if operation[2] is not None:
                return deepcopy(operation[2])
            lease = value.get('lease')
            if not isinstance(lease_id, str) or not lease or lease['id'] != lease_id:
                raise _safe_rejection(StrategyError('租约不存在或不属于当前策略'))
            if outcome not in ('completed', 'unknown', 'cancelled_before_execution'):
                raise _safe_rejection(StrategyError('租约结果无效'))
            count = len(lease['keywords'])
            used = count if used_count is None else _integer(used_count, 0, count, '已执行查询数量')
            if outcome == 'unknown':
                if used_count is not None and used_count != count:
                    raise _safe_rejection(StrategyError('结果不明必须保守消耗整批配额'))
                used = count
            elif outcome == 'cancelled_before_execution':
                if used_count not in (None, 0):
                    raise _safe_rejection(StrategyError('执行前取消不能报告已消耗配额'))
                used = 0
            position = lease['cursor'] + used
            value['cycle'] += position // lease['active_count']
            value['cursor'] = position % lease['active_count']
            value['queries_spent'] += used
            value['lease'] = None
            return self._commit(db, value, operation,
                                {**self._summary(value, True), 'outcome': outcome, 'quota_consumed': used})
