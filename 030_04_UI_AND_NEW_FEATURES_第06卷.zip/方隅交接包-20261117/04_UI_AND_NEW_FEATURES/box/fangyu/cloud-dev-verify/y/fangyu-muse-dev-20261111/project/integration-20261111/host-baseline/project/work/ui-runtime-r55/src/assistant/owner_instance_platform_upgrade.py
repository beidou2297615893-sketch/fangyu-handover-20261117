"""Read-only preparation for a same-instance owner v1 -> v2 capability upgrade.

Preparation grants no platform capability and proves no process/Native idleness.
It neither opens a database nor initializes an absent instance/data directory.
The future writer must independently revalidate under the original instance lock.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import stat

from .self_operating_read import _OwnerReadInstance, _company, _plain_directory

_PLAN_SEAL = object()
_MARKER = 'self-operating-instance.json'
_DATA_MARKER = 'owner-data-instance.json'
_DB_FILES = ('workspace.sqlite3', 'workspace.sqlite3-wal',
             'workspace.sqlite3-shm', 'workspace.sqlite3-journal')
_WRAPPER = re.compile(r'[0-9a-f]{64}\Z')


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def _plain_file(path, *, expected_size=None, optional=False):
    try:
        info = path.lstat()
    except FileNotFoundError:
        if optional:
            return None
        raise ValueError('原实例或数据标记缺失；只读准备不会初始化目录') from None
    if (not stat.S_ISREG(info.st_mode) or path.is_symlink() or info.st_nlink != 1
            or getattr(info, 'st_file_attributes', 0)
                & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)
            or expected_size is not None and info.st_size != expected_size):
        raise ValueError('原实例文件不能是链接、共享文件、重定向或不匹配标记')
    return info


class _OwnerPlatformUpgradePlan:
    """A sealed RAM-only plan, never a grant or an executable commit instruction."""
    __slots__ = ('_seal', '_instance', '_source_bytes', '_target_bytes', '_data_bytes', '_value')

    def __init__(self, seal, instance, source, target, data, value):
        if seal is not _PLAN_SEAL:
            raise ValueError('升级准备对象只能来自原只读准备')
        self._seal, self._instance = seal, instance
        self._source_bytes, self._target_bytes, self._data_bytes = source, target, data
        self._value = value

    def summary(self):
        if self._seal is not _PLAN_SEAL:
            raise ValueError('升级准备对象无效')
        return deepcopy(self._value)


def prepare_owner_platform_upgrade(instance):
    """Check an existing exact v1 instance and return a sealed, safe RAM plan.

    Interface: the calling original owner host retains its real factory instance.
    No path/identity/scope/capability parameters can replace that instance. A
    ValueError rejects absent/changed/redirected material without creating files.
    The summary is an observation; a live host can change after this call returns.
    """
    if (type(instance) is not _OwnerReadInstance
            or instance.product != 'xiaohongshu_v1'
            or type(instance._wrapper_sha) is not str
            or not _WRAPPER.fullmatch(instance._wrapper_sha)):
        raise ValueError('只读准备仅接受原工厂的合法小红书 v1 实例')
    original_company = instance.check()
    iid = original_company['selfOperatingRead']['instance_id']
    expected_company = _company(iid, instance._wrapper_sha, 'xiaohongshu_v1')
    if original_company != expected_company:
        raise ValueError('原实例、公司或 wrapper 用途不匹配')
    directory, root = Path(instance.directory), Path(instance.work_root)
    _plain_directory(directory, root)
    source_path = directory / _MARKER
    source_info = _plain_file(source_path, expected_size=len(instance._bytes))
    source = source_path.read_bytes()
    if source != instance._bytes or source_info.st_size > 8192:
        raise ValueError('原实例标记已变化')
    # Do not call prepare_data(): this path must already exist and be bound.
    data_directory = directory / 'data'
    _plain_directory(data_directory, root)
    expected_data = json.dumps({'schema': 'owner_read_data_v1', 'instance_id': iid},
                               sort_keys=True).encode()
    data_path = data_directory / _DATA_MARKER
    _plain_file(data_path, expected_size=len(expected_data))
    if data_path.read_bytes() != expected_data:
        raise ValueError('原数据标记与同一实例不匹配')
    # Metadata only: no connect, read_bytes, hash, copy, backup or SQL on a DB.
    for name in _DB_FILES:
        _plain_file(data_directory / name, optional=True)
    target_company = _company(iid, instance._wrapper_sha, 'primary_platforms_v2')
    if (target_company['id'] != original_company['id']
            or target_company['selfOperatingRead']['instance_id'] != iid):
        raise ValueError('目标能力不能改变本人实例或公司主体')
    target_value = {'schema': 'owner_read_instance_v2', 'instance_id': iid,
                    'company': target_company}
    # Match the original normal factory's marker serialization exactly.
    target = json.dumps(target_value, ensure_ascii=False, sort_keys=True).encode()
    source_sha, target_sha = _sha(source), _sha(target)
    plan_payload = {'schema': 'owner_platform_upgrade_plan_v1', 'instance_id': iid,
        'company_id': original_company['id'], 'wrapper_sha256': instance._wrapper_sha,
        'instance_directory_digest': _sha(str(directory).encode('utf-8')),
        'work_root_digest': _sha(str(root).encode('utf-8')),
        'source_marker_sha256': source_sha, 'target_marker_sha256': target_sha,
        'data_marker_sha256': _sha(expected_data),
        'from_product': 'xiaohongshu_v1', 'to_product': 'primary_platforms_v2'}
    # A final original check catches mutation during our metadata observation;
    # it is not a claim of idle or a lock-protected commit-time CAS.
    if instance.check() != original_company:
        raise ValueError('只读准备期间原实例发生变化')
    _plain_file(source_path, expected_size=len(source))
    _plain_file(data_path, expected_size=len(expected_data))
    if data_path.read_bytes() != expected_data:
        raise ValueError('只读准备期间原数据标记发生变化')
    for name in _DB_FILES:
        _plain_file(data_directory / name, optional=True)
    summary = {'schema': 'owner_platform_upgrade_prepare_v1', 'state': 'prepared_read_only',
        'instance_id': iid, 'company_id': original_company['id'],
        'from_product': 'xiaohongshu_v1', 'to_product': 'primary_platforms_v2',
        'source_marker_sha256': source_sha, 'target_marker_sha256': target_sha,
        'plan_digest': _sha(_encoded(plan_payload)),
        'added_platforms': {'douyin': 'pending', 'wechat_channels': 'pending'},
        'instance_idle_verified': False, 'database_opened': False,
        'mutation_committed': False, 'platform_permissions_granted': False}
    return _OwnerPlatformUpgradePlan(_PLAN_SEAL, instance, source, target,
                                     expected_data, summary)
