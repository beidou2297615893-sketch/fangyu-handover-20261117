"""Private App facts for the original executor call; never Native permission.

No HTTP fields, login bootstrap, process/provider or licence decision enters
this interface. The device session is captured by AssistantService._run and
cannot be rebound to a later vault token by an old executor. All checks are
local; no cloud/identity requests run while the batch holds account locks.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import threading
from uuid import uuid4


class AppContextRequired(ValueError):
    def __init__(self):
        super().__init__('xhs_app_context_unavailable')


_LOCAL = threading.local()
_SEAL = object()
_TASK_CALLS = frozenset(('task_run', 'task_resume', 'continuous_start', 'continuous_resume'))
_ACTOR = ('id', 'tenant_id', 'username', 'role', 'disabled', 'cloud_bound',
          'development_local_only', 'can_reply', 'permission_revision')
_TASK = ('id', 'tenant_id', 'platform', 'account_id', 'cloud_owner', 'strategy_source',
         'updated_at', 'scope', 'keywords', 'continuous_enabled', 'note_url', 'excludes',
         'region', 'city', 'area', 'date_from', 'date_to', 'comment_date_range',
         'comment_date_from', 'comment_date_to', 'excluded_authors', 'excluded_bloggers',
         'comment_depth', 'comment_keyword_mode', 'unknown_policy', 'blogger_unknown_policy',
         'intent_mode', 'high_intent_words', 'medium_intent_words', 'negative_intent_words',
         'daily_limit', 'target_count', 'search_pages', 'time_start', 'time_end')
_ACCOUNT = ('id', 'tenant_id', 'platform', 'platform_uid', 'cloud_owner', 'status',
            'requires_review', 'updated_at')


def _digest(value):
    try:
        return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                        separators=(',', ':'), allow_nan=False).encode()).digest()
    except (TypeError, ValueError, UnicodeError):
        raise AppContextRequired() from None


def _session_snapshot(service, saved):
    if not isinstance(saved, dict) or not isinstance(saved.get('device'), dict):
        raise AppContextRequired()
    server, device = service.server, saved['device']
    company = server.company
    if not isinstance(company, dict) or not isinstance(company.get('managedWorkspace'), dict):
        raise AppContextRequired()
    managed = company['managedWorkspace']
    token = saved.get('token')
    if (saved.get('state') != 'bound'
            or saved.get('environment_id') != service.environment_id
            or saved.get('company_id') != service.company_id
            or company.get('id') != service.company_id
            or managed.get('environment_id') != service.environment_id
            or managed.get('endpoint') != service.endpoint
            or not isinstance(token, str) or not 1 <= len(token) <= 65536
            or not device.get('id') or not device.get('owner') or device.get('revoked') is True):
        raise AppContextRequired()
    return _digest((service.environment_id, service.company_id, service.endpoint,
                    device.get('id'), device.get('owner'), hashlib.sha256(token.encode()).hexdigest(),
                    company, getattr(server.core, 'deployment_config', {})))


@dataclass(frozen=True, slots=True, repr=False)
class _DeviceSession:
    seal: object
    service: object
    executor: object
    binding: bytes
    principal: tuple
    core: object

    def check(self):
        service, executor = self.service, self.executor
        if (self.seal is not _SEAL or getattr(executor, '_xhs_app_session', None) is not self
                or (executor.owner, executor.tenant, executor.user_id) != self.principal
                or executor.core is not self.core or service.server.core is not self.core):
            raise AppContextRequired()
        current = service.vault.read()
        if _session_snapshot(service, current) != self.binding:
            raise AppContextRequired()
        with service.lock:
            device = service.device or {}
            if (getattr(service.server, 'assistant_service', None) is not service
                    or service.executor is not executor or service.closed
                    or service.state not in ('online', 'held')
                    or device.get('id') != current['device'].get('id')
                    or device.get('owner') != executor.owner
                    or device.get('revoked') is True
                    or current['device'].get('owner') != executor.owner
                    or executor.server is not service.server or executor.core is not service.server.core):
                raise AppContextRequired()


def bind_executor_session(service, executor, saved):
    """Original _run installs its bound DPAPI session; Runner still validates every poll."""
    from .business import BusinessExecutor
    from .service import AssistantService
    if (type(service) is not AssistantService or type(executor) is not BusinessExecutor
            or getattr(executor, '_xhs_app_session', None) is not None):
        raise AppContextRequired()
    binding = _session_snapshot(service, saved)
    if _session_snapshot(service, service.vault.read()) != binding:
        raise AppContextRequired()
    with service.lock:
        if service.executor is not executor or getattr(service.server, 'assistant_service', None) is not service:
            raise AppContextRequired()
        executor._xhs_app_session = _DeviceSession(_SEAL, service, executor, binding,
            (executor.owner, executor.tenant, executor.user_id), executor.core)


@dataclass(slots=True, repr=False)
class _Call:
    executor: object
    thread: object
    action: str
    task_id: str
    active: bool = True


@dataclass(frozen=True, slots=True, repr=False)
class _ContinuousGeneration:
    seal: object
    collector: object
    session: _DeviceSession
    ident: str
    actor_id: str
    task_id: str
    account_id: str
    actor: bytes
    task: bytes
    account: bytes
    state: str

    def check(self, *, admitted=True):
        if (self.seal is not _SEAL or type(self.session) is not _DeviceSession
                or admitted and self.collector._app_generations.get(self.task_id) is not self
                or admitted and self.collector._stop.is_set()):
            raise AppContextRequired()
        self.session.check()
        executor, core = self.session.executor, self.session.core
        with core.lock:
            user = core.store.get('users', self.actor_id)
            task = core._get('tasks', self.task_id, executor.tenant)
            account = core._get('accounts', self.account_id, executor.tenant)
            from core.continuous import normalize_continuous_task
            normalize_continuous_task(task)
            if (not user or _digest({k: user.get(k) for k in _ACTOR}) != self.actor
                    or _digest({k: task.get(k) for k in _TASK}) != self.task
                    or _digest({k: account.get(k) for k in _ACCOUNT}) != self.account
                    or user.get('disabled') or user.get('cloud_bound') is not True
                    or user.get('development_local_only') is True
                    or (user.get('id'), user.get('username'), user.get('tenant_id'))
                        != (executor.user_id, executor.owner, executor.tenant)
                    or user.get('role') not in ('operator', 'admin')
                    or task.get('continuous_enabled') is not True
                    or task.get('platform') != 'xiaohongshu'
                    or account.get('platform') != 'xiaohongshu'
                    or account.get('status') != 'ready'
                    or core.remote_safety_hold or not core._qa_continuous_allowed()
                    or executor._xiaohongshu_held()):
                raise AppContextRequired()
            core._task_access(user, task, executor.tenant)
            core._account_access(user, account)
            core.require_platform('xiaohongshu')
            core._platform_execution_guard('xiaohongshu')
            executor._require_product_feature('acquisition')
            with self.session.service.lock:
                if self.session.service.state != self.state:
                    raise AppContextRequired()
        self.session.check()


@dataclass(frozen=True, slots=True, repr=False)
class _ContinuousClaim:
    seal: object
    generation: _ContinuousGeneration
    ident: str

    def check(self):
        generation = self.generation
        collector = generation.collector
        with collector.core.lock:
            if (self.seal is not _SEAL or type(generation) is not _ContinuousGeneration
                    or collector._app_claims.get(generation.task_id) is not self):
                raise AppContextRequired()
            generation.check()
            job = collector.core.store.get('continuous_tasks', generation.task_id) or {}
            task = collector.core.store.get('tasks', generation.task_id) or {}
            if (job.get('runtime_id') != collector.runtime_id
                    or job.get('generation_id') != generation.ident
                    or job.get('claim_id') != self.ident
                    or job.get('status') not in ('queued', 'running', 'waiting')
                    or job.get('inflight') is not True or task.get('status') == 'paused'):
                raise AppContextRequired()


@dataclass(slots=True, repr=False)
class _CollectorCall:
    executor: object
    thread: object
    task_id: str
    claim: _ContinuousClaim
    action: str = 'continuous_batch'
    active: bool = True


def mint_continuous_generation(collector, user, task, resume):
    """Original accepted start only; immutable facts, no inherited active call."""
    call = getattr(_LOCAL, 'call', None)
    if (type(call) is not _Call or not call.active
            or call.thread is not threading.current_thread()
            or call.action != ('continuous_resume' if resume else 'continuous_start')
            or call.task_id != task.get('id') or call.executor.core is not collector.core):
        raise AppContextRequired()
    session = getattr(call.executor, '_xhs_app_session', None)
    runtime = collector.core.adapters.xhs_page_runtime
    factory = getattr(runtime, 'app_context_factory', None)
    if (type(session) is not _DeviceSession or type(factory) is not XhsAppHostContext
            or factory._server is not session.service.server):
        raise AppContextRequired()
    from .strategy_tasks import is_strategy_task
    if is_strategy_task(task):
        call.executor._strategy_tasks().guard_task_action(task, call.action,
            {'task_id': task['id']}, user)
    account = collector.core._get('accounts', task['account_id'], user['tenant_id'])
    generation = _ContinuousGeneration(_SEAL, collector, session, uuid4().hex,
        user['id'], task['id'], task['account_id'], _digest({k: user.get(k) for k in _ACTOR}),
        _digest({k: task.get(k) for k in _TASK}),
        _digest({k: account.get(k) for k in _ACCOUNT}), session.service.state)
    generation.check(admitted=False)
    return generation


def mint_continuous_claim(generation):
    if type(generation) is not _ContinuousGeneration:
        raise AppContextRequired()
    generation.check()
    return _ContinuousClaim(_SEAL, generation, uuid4().hex)


@contextmanager
def continuous_claim_call(claim):
    """A new exact worker frame; an ended HTTP/Runner frame is never transferred."""
    if type(claim) is not _ContinuousClaim:
        raise AppContextRequired()
    claim.check()
    previous = getattr(_LOCAL, 'call', None)
    current = _CollectorCall(claim.generation.session.executor, threading.current_thread(),
                             claim.generation.task_id, claim)
    _LOCAL.call = current
    try:
        claim.check()
        yield claim.check
    finally:
        # Physical scope cleanup has already run in Core._run's finally. This
        # logical frame retirement must succeed even after authority is revoked.
        current.active = False
        _LOCAL.call = previous


@contextmanager
def executor_call(executor, command):
    """Original __call__ supplies only provenance; its principal/guards still run unchanged."""
    previous = getattr(_LOCAL, 'call', None)
    data = command.get('data') or {}
    requested_task = data.get('task_id') if isinstance(data, dict) else None
    current = _Call(executor, threading.current_thread(), command.get('action'), requested_task)
    _LOCAL.call = current
    try:
        yield
    finally:
        current.active = False
        _LOCAL.call = previous


@dataclass(frozen=True, slots=True, repr=False)
class _AppExecutionContext:
    seal: object
    session: _DeviceSession
    call: _Call
    actor_id: str
    task_id: str
    account_id: str
    actor: bytes
    state: str
    safety_hold: bool

    def check(self):
        if (self.seal is not _SEAL or type(self.session) is not _DeviceSession
                or getattr(_LOCAL, 'call', None) is not self.call or not self.call.active
                or self.call.thread is not threading.current_thread()
                or self.call.executor is not self.session.executor):
            raise AppContextRequired()
        if type(self.call) is _CollectorCall:
            self.call.claim.check()
        self.session.check()
        service, executor = self.session.service, self.session.executor
        core = executor.core
        with core.lock:
            user = core.store.get('users', self.actor_id)
            task = core._get('tasks', self.task_id, executor.tenant)
            account = core._get('accounts', self.account_id, executor.tenant)
            if (not user or _digest({k: user.get(k) for k in _ACTOR}) != self.actor
                    or user.get('id') != executor.user_id or user.get('username') != executor.owner
                    or user.get('tenant_id') != executor.tenant or user.get('role') not in ('operator', 'admin')
                    or user.get('disabled') or user.get('cloud_bound') is not True
                    or user.get('development_local_only') is True
                    or task.get('account_id') != self.account_id or task.get('platform') != 'xiaohongshu'
                    or account.get('platform') != 'xiaohongshu'
                    or bool(core.remote_safety_hold) != self.safety_hold):
                raise AppContextRequired()
            core._task_access(user, task, executor.tenant)
            core._account_access(user, account)
            with service.lock:
                if service.state != self.state:
                    raise AppContextRequired()
        # Detect a session/config/device change during the local ownership reads.
        self.session.check()


class XhsAppHostContext:
    """Constructed by AppServer; capture is valid only in its exact original task call."""
    def __init__(self, server):
        self._server = server

    def capture(self, user, task):
        call = getattr(_LOCAL, 'call', None)
        collector_call = type(call) is _CollectorCall
        if (type(call) not in (_Call, _CollectorCall) or not call.active
                or not collector_call and call.action not in _TASK_CALLS
                or call.thread is not threading.current_thread()
                or call.executor.server is not self._server
                or not isinstance(call.task_id, str) or not call.task_id
                or task.get('id') != call.task_id):
            raise AppContextRequired()
        if collector_call:
            call.claim.check()
        session = getattr(call.executor, '_xhs_app_session', None)
        if type(session) is not _DeviceSession or session.service.server is not self._server:
            raise AppContextRequired()
        # The actual stored actor/ownership is checked, never a command principal body.
        context = _AppExecutionContext(_SEAL, session, call, user['id'], task['id'], task['account_id'],
            _digest({k: user.get(k) for k in _ACTOR}), session.service.state,
            bool(self._server.core.remote_safety_hold))
        context.check()
        return context
