"""Owner package declarations over a separate, RAM-only company origin session.

Company authentication verifies the source's declaration, never the remote local
package itself. This module neither borrows a staff session nor reveals contacts.
"""
from copy import deepcopy
import hashlib
import json
import math
import re
import threading
import time

from core import CoreError
from .self_operating_acquisition import (OwnerAcquisition, _ACTOR, _identity,
    _row, _safe_label, digest)
from .owner_contact_handoff_package import OwnerContactHandoffPackages
from .owner_handoff_followup import OwnerHandoffFollowup
from .acquisition_exports import _public_label

PREFIX = 'owner_company_receipt_'
CONTRACT = 'owner_company_receipt_bridge_v1'
_NAMES = ('login', 'scope_get', 'register', 'consent_sync', 'submit', 'withdraw',
    'operation_status', 'channel_get', 'business_get', 'logout')
ACTIONS = frozenset(PREFIX + name for name in _NAMES)
WRITES = frozenset('owner_origin_' + name for name in
    ('register', 'consent_sync', 'submit', 'withdraw'))
FLAGS = frozenset(('read_only', 'mutation_committed', 'auto_retry',
    'remote_original_package_verified', 'platform_delivery_verified',
    'attribution_confirmed', 'settlement_active', 'financial_receipt_verified',
    'cooperation_policy_verified'))
CHANNEL_FIELDS = frozenset(('origin_kind', 'channel_id', 'case_id', 'claim_id',
    'instance_id', 'package_id', 'row_id', 'selection_digest', 'artifact_sha256',
    'sender_subject_id', 'recipient_id', 'recipient_name', 'purpose', 'status',
    'revision', 'consent', 'receipt', 'permissions', 'authorization', 'created_at',
    'updated_at'))
OPERATION_FIELDS = frozenset(('operation_id', 'operation_action',
    'idempotency_key', 'state', 'mutation_committed', 'original_execution_confirmed',
    'input_hash', 'channel_id', 'original_revision', 'original_event_hash',
    'reason_code', 'auto_retry'))
SCOPE_FIELDS = frozenset(('kind', 'company_id', 'environment_id', 'subject_id',
    'subject_mapping_version', 'account_version', 'admission_id',
    'admission_version', 'instance_id', 'recipient_id', 'expires_at', 'mode'))
USER_FIELDS = frozenset(('username', 'access_class', 'subject_id',
    'subject_mapping_version'))
REASONS = frozenset((None, 'UNCONFIGURED', 'AUTH_SCOPE_REQUIRED',
    'ORIGIN_BINDING_CONFLICT', 'ORIGINAL_CLAIM_HELD', 'CAS_CONFLICT',
    'CONSENT_NOT_SYNCED', 'CONSENT_EXPIRED', 'CONSENT_WITHDRAWN',
    'ADMISSION_EXPIRED', 'ADMISSION_REVOKED', 'INDEPENDENT_RECEIVER_REQUIRED',
    'OPERATION_UNKNOWN', 'ROW_NEEDS_REVIEW'))
STATUSES = frozenset(('draft', 'submitted', 'accepted', 'rejected',
    'needs_information', 'duplicate_pending_review',
    'existing_customer_pending_review', 'withdrawn', 'needs_review'))
_DECISIONS = {'accept': ('accepted', (None,)),
    'reject': ('rejected', ('not_qualified', 'outside_service_area')),
    'needs_information': ('needs_information', ('needs_information',)),
    'duplicate': ('duplicate_pending_review', ('duplicate',)),
    'existing_customer': ('existing_customer_pending_review', ('existing_customer',))}
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_INSTANCE = re.compile(r'[a-f0-9]{32}\Z')
_SUBJECT = re.compile(r'su_[a-f0-9]{32}\Z')
_ADMISSION = re.compile(r'oa_[a-f0-9]{32}\Z')
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_CASE = re.compile(r'oc_[a-f0-9]{64}\Z')
_CLAIM = re.compile(r'cl_[a-f0-9]{64}\Z')
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_ENV = re.compile(r'[A-Za-z0-9_-]{3,100}\Z')
_USERNAME = re.compile(r'[A-Za-z0-9_.@-]{3,80}\Z')
_REFERENCE = re.compile(r'(?:evidence|document):[a-f0-9]{32}\Z')
_MAX = 9007199254740991


class OwnerCompanyReceiptBridgeError(CoreError):
    def __init__(self, code, message, *, mutation_committed=False):
        super().__init__(message)
        self.code = 'OWNER_COMPANY_RECEIPT_' + code
        self.mutation_committed = mutation_committed


def _fail(code='INVALID_RESULT', message='公司资料包范围或原回执需核对', *, mutation=False):
    raise OwnerCompanyReceiptBridgeError(code, message, mutation_committed=mutation)


def _exact(value, fields):
    if type(value) is not dict or set(value) != set(fields):
        _fail()
    return value


def _match(value, pattern):
    return type(value) is str and pattern.fullmatch(value) is not None


def _integer(value, minimum=0):
    return type(value) is int and minimum <= value < _MAX


def _cloud_hash(value):
    encoded = value if type(value) is str else json.dumps(value,
        sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(encoded.encode('utf-8')).hexdigest()


def _label(value, maximum):
    if (_safe_label(value, '公司安全标签', maximum) != value
            or _public_label(value) != value
            or re.search(r'https?://|www\.', value, re.I)):
        _fail()
    return value


def owner_flags(value, *, read_only=None):
    if (any(key not in value for key in FLAGS)
            or type(value['read_only']) is not bool
            or value['mutation_committed'] is not None
            and type(value['mutation_committed']) is not bool
            or any(value[key] is not False for key in FLAGS - {'read_only', 'mutation_committed'})
            or value['read_only'] and value['mutation_committed'] is not False
            or read_only is not None and value['read_only'] is not read_only):
        _fail()
    return value


def owner_consent(value):
    _exact(value, ('version', 'status', 'binding_digest', 'last_synced_at', 'valid_until'))
    if (not _integer(value['version']) or not _match(value['binding_digest'], _HEX)
            or value['status'] not in ('unconfirmed', 'granted', 'withdrawn')):
        _fail()
    first, last = value['last_synced_at'], value['valid_until']
    if value['status'] == 'unconfirmed':
        if value['version'] != 0 or first is not None or last is not None:
            _fail()
    elif value['status'] == 'granted':
        if (value['version'] < 1 or (first is None) != (last is None)
                or first is not None and (not _integer(first, 1)
                    or not _integer(last, first) or last > first + 300)
                or first is None):
            _fail()
    elif (value['version'] < 1 or not _integer(last, 1)
            or first is not None and (not _integer(first, 1) or last < first)):
        _fail()
    return value


def owner_receipt(value, channel):
    if value is None:
        return None
    _exact(value, ('channel_id', 'revision', 'decision', 'reason_code',
        'evidence_reference', 'recorded_at', 'receiver_subject_id',
        'receiver_mapping_version', 'authenticated_receiver_decision',
        'receipt_evidence_independently_verified'))
    decision = _DECISIONS.get(value['decision'])
    if (value['channel_id'] != channel['channel_id'] or not _integer(value['revision'], 1)
            or value['revision'] > channel['revision'] or decision is None
            or value['reason_code'] not in decision[1]
            or not _match(value['evidence_reference'], _REFERENCE)
            or not _integer(value['recorded_at'], 1)
            or not _match(value['receiver_subject_id'], _SUBJECT)
            or value['receiver_subject_id'] == channel['sender_subject_id']
            or not _integer(value['receiver_mapping_version'])
            or value['authenticated_receiver_decision'] is not True
            or value['receipt_evidence_independently_verified'] is not False):
        _fail()
    return value


def owner_channel(value, *, channel_id=None, receiver=False):
    _exact(value, CHANNEL_FIELDS)
    patterns = {'channel_id': _CHANNEL, 'case_id': _CASE, 'claim_id': _CLAIM,
        'instance_id': _INSTANCE, 'package_id': _HEX, 'row_id': _HEX,
        'selection_digest': _HEX, 'artifact_sha256': _HEX,
        'sender_subject_id': _SUBJECT, 'recipient_id': _ID}
    if (value['origin_kind'] != 'owner_package_v1'
            or any(not _match(value[key], pattern) for key, pattern in patterns.items())
            or channel_id is not None and value['channel_id'] != channel_id
            or value['status'] not in STATUSES or not _integer(value['revision'], 1)
            or not _integer(value['created_at'], 1)
            or not _integer(value['updated_at'], value['created_at'])):
        _fail()
    _label(value['recipient_name'], 80)
    _label(value['purpose'], 100)
    consent = owner_consent(value['consent'])
    permissions = _exact(value['permissions'], ('can_submit', 'can_withdraw',
        'can_receipt', 'can_review'))
    authorization = _exact(value['authorization'], ('state', 'company_scope',
        'checked_at', 'consent_version', 'valid_until'))
    if (any(type(flag) is not bool for flag in permissions.values())
            or authorization['state'] not in ('current_company_scope',
                'last_synced_expired', 'withdrawn', 'admission_expired',
                'admission_revoked', 'needs_review')
            or authorization['company_scope'] != 'last_synced_authenticated_sender_declaration'
            or not _integer(authorization['checked_at'], 1)
            or authorization['consent_version'] != consent['version']
            or type(authorization['consent_version']) is not int
            or authorization['valid_until'] is not None and not _integer(authorization['valid_until'], 1)
            or authorization['valid_until'] != consent['valid_until']
            or permissions['can_submit'] and (receiver or value['status'] != 'draft'
                or consent['status'] != 'granted' or authorization['state'] != 'current_company_scope')
            or permissions['can_receipt'] and (not receiver or value['status'] != 'submitted'
                or consent['status'] != 'granted' or authorization['state'] != 'current_company_scope')
            or value['status'] == 'withdrawn' and (consent['status'] != 'withdrawn'
                or permissions['can_submit'] or permissions['can_receipt'])):
        _fail()
    owner_receipt(value['receipt'], value)
    return deepcopy(value)


def public_owner_channels(value, *, receiver):
    """Alias only fully checked domain Channels at the final public boundary."""
    if type(receiver) is not bool:
        _fail('INVALID_PUBLIC_RESULT', mutation=None)
    if isinstance(value, dict):
        # The alias is created here, never accepted as an incoming grant.
        if 'source_authorization' in value:
            _fail('INVALID_PUBLIC_RESULT', mutation=None)
        # Operation/receipt envelopes may share origin_kind; the Channel-only
        # fields distinguish them without inferring any sender/receiver grant.
        if ('origin_kind' in value
                and any(key in value for key in ('consent', 'case_id', 'claim_id'))):
            try:
                checked = owner_channel(value, receiver=receiver)
            except CoreError:
                # Projection happens after execution; a bad result cannot prove
                # that an earlier write did not commit.
                _fail('INVALID_PUBLIC_RESULT', mutation=None)
            checked['source_authorization'] = checked.pop('authorization')
            return checked
        return {key: public_owner_channels(item, receiver=receiver)
                for key, item in value.items()}
    if isinstance(value, list):
        return [public_owner_channels(item, receiver=receiver) for item in value]
    return value


def owner_operation(value, action, key):
    _exact(value, OPERATION_FIELDS)
    if (not _match(value['operation_id'], _HEX) or value['operation_action'] != action
            or action not in WRITES or value['idempotency_key'] != key
            or not _match(key, _HEX) or value['state'] not in ('unknown', 'started', 'recorded', 'rejected')
            or value['auto_retry'] is not False or value['reason_code'] not in REASONS
            or value['input_hash'] is not None and not _match(value['input_hash'], _HEX)
            or value['channel_id'] is not None and not _match(value['channel_id'], _CHANNEL)):
        _fail()
    if value['state'] == 'recorded':
        if (value['mutation_committed'] is not True or value['original_execution_confirmed'] is not True
                or not _match(value['input_hash'], _HEX) or not _match(value['channel_id'], _CHANNEL)
                or not _integer(value['original_revision'], 1)
                or not _match(value['original_event_hash'], _HEX)):
            _fail()
    elif (value['original_revision'] is not None or value['original_event_hash'] is not None
            or value['state'] in ('unknown', 'started') and
                (value['mutation_committed'] is not None or value['original_execution_confirmed'] is not None)
            or value['state'] == 'rejected' and
                (value['mutation_committed'] is not False or value['original_execution_confirmed'] is not False)):
        _fail()
    return deepcopy(value)


def owner_user_scope(user, scope, *, company_id, environment_id, instance_id):
    _exact(user, USER_FIELDS)
    _exact(scope, SCOPE_FIELDS)
    if (not _match(user['username'], _USERNAME) or user['access_class'] != 'owner_origin_only'
            or not _match(user['subject_id'], _SUBJECT)
            or not _integer(user['subject_mapping_version'])
            or scope['kind'] != 'owner_origin_only_v1' or scope['company_id'] != company_id
            or scope['environment_id'] != environment_id or scope['instance_id'] != instance_id
            or scope['subject_id'] != user['subject_id']
            or scope['subject_mapping_version'] != user['subject_mapping_version']
            or type(scope['subject_mapping_version']) is not int
            or not _integer(scope['account_version'])
            or not _match(scope['admission_id'], _ADMISSION)
            or not _integer(scope['admission_version'])
            or not _match(scope['recipient_id'], _ID)
            or not _integer(scope['expires_at'], 1)
            or scope['mode'] not in ('execute', 'cleanup_only')):
        _fail()
    return deepcopy(user), deepcopy(scope)


_ATTEMPTS = 'owner_company_receipt_operations_v1'
_CUSTODY = 'owner_company_receipt_pending_v1'
_ATTEMPT_FIELDS = frozenset(('id', 'tenant_id', 'schema', 'local_company_id',
    'local_user_id', 'actor_digest', 'instance_id', 'company_id', 'environment_id',
    'subject_id', 'admission_id', 'package_id', 'row_id', 'operation_action',
    'idempotency_key', 'request', 'input_hash', 'state', 'operation', 'created_at',
    'updated_at', 'record_hash'))
_CUSTODY_FIELDS = frozenset(('id', 'tenant_id', 'schema', 'local_user_id',
    'instance_id', 'company_id', 'environment_id', 'subject_id',
    'pending_id', 'created_at', 'record_hash'))


def _saved_hash(value):
    return digest({key: field for key, field in value.items() if key != 'record_hash'})


class OwnerCompanyReceiptBridge:
    def __init__(self, acquisition):
        if (type(acquisition) is not OwnerAcquisition
                or type(acquisition._packages) is not OwnerContactHandoffPackages):
            _fail('LOCAL_SCOPE_REQUIRED', '公司资料包桥只能从当前本人原包创建')
        self.acq, self.core, self.workspace = acquisition, acquisition.core, acquisition.workspace
        if acquisition._followups is None:
            acquisition._followups = OwnerHandoffFollowup(acquisition)
        if type(acquisition._followups) is not OwnerHandoffFollowup:
            _fail()
        self.followups = acquisition._followups
        self._lock = threading.RLock()
        self._remote = None

    def _frame(self, token, package_id, row_id=None, *, fresh=False, all_rows=False, withdraw=False):
        from integrations import endpoint
        if not _match(package_id, _HEX) or row_id is not None and not _match(row_id, _HEX):
            _fail('INVALID_REQUEST')
        with self.workspace._lock, self.core.lock, self.core.store.connect() as db:
            user = self.acq._current(token)
            package = self.followups._package(db, token, user, package_id)
            row_ids = self.followups._row_ids(package)
            if row_id is not None and row_id not in row_ids:
                _fail('ORIGIN_BINDING_CONFLICT', '请使用原资料包中的原行')
            state = None
            indexes = range(len(row_ids)) if all_rows else (row_ids.index(row_id),) if row_id and (fresh or withdraw) else ()
            for index in indexes:
                authority = self.followups._row_proof(db, token, user, package, index)
                if fresh and authority['state'] != 'current_recorded_scope':
                    _fail('CONSENT_WITHDRAWN', '原行当前同意不允许新的公司来源声明')
                if row_id == row_ids[index]:
                    state = authority['state']
            manifest = self._manifest(package, user, row_ids)
            self.acq._packages._session(db, token, user)
            integrations = self.acq.server.integrations
            with integrations.lock:
                config = integrations._read(user['tenant_id'])
                cloud = config.get('cloud') if type(config) is dict else None
                environment = cloud.get('environment_id') if type(cloud) is dict else None
                address = endpoint(cloud.get('endpoint')) if type(cloud) is dict else ''
            if not _match(environment, _ENV) or not address:
                _fail('UNCONFIGURED', '请先明确配置当前可信公司的 HTTPS 工作区地址')
            return {'user': deepcopy(user), 'actor_digest': digest(_identity(user, _ACTOR)),
                'local_company_id': self.acq.server.company['id'],
                'local_user_id': user['id'], 'instance_id': self.acq.instance_id,
                'token_digest': hashlib.sha256(token.encode()).hexdigest(),
                'package_id': package_id, 'row_id': row_id,
                'package_digest': digest(package), 'manifest': manifest,
                'row_authorization': state, 'proof_mode': (fresh, all_rows, withdraw),
                'environment_id': environment, 'endpoint': address}

    def _manifest(self, package, user, row_ids):
        recipient = _label(package['recipient_id'], 80)
        purpose = _label(package['handoff_purpose'], 100)
        recipient_hash, purpose_hash = _cloud_hash(recipient), _cloud_hash(purpose)
        rows = []
        for row_id, selected, proof in zip(row_ids, package['selection'], package['proofs']):
            protected = _cloud_hash(['owner_protected_contact_source_v1',
                self.acq.server.company['id'], user['id'], self.acq.instance_id,
                proof['contact_reference']])
            rows.append({'row_id': row_id, 'draft_id': selected['draft_id'],
                'protected_contact_source_id': protected,
                'source_binding_digest': _cloud_hash({key: proof[key] for key in
                    ('binding_digest', 'receipt_digest', 'draft_digest')}),
                'consent_binding_digest': _cloud_hash({'protected_contact_source_id': protected,
                    'contact_digest': proof['contact_digest'],
                    'local_recipient_label_digest': recipient_hash,
                    'local_purpose_digest': purpose_hash})})
        rows.sort(key=lambda row: row['row_id'])
        if (not 1 <= len(rows) <= 50 or any(len({row[key] for row in rows}) != len(rows)
                for key in ('row_id', 'draft_id', 'protected_contact_source_id'))):
            _fail('ORIGIN_BINDING_CONFLICT')
        return {'instance_id': self.acq.instance_id, 'package_id': package['id'],
            'selection_digest': package['selection_digest'],
            'artifact_sha256': package['artifact']['sha256'],
            'recipient_label': recipient, 'purpose_label': purpose,
            'local_recipient_label_digest': recipient_hash,
            'local_purpose_digest': purpose_hash, 'rows': rows}

    def _fence(self, token, before, *, fresh=None, all_rows=None, withdraw=None):
        prior_fresh, prior_all, prior_withdraw = before['proof_mode']
        try:
            after = self._frame(token, before['package_id'], before['row_id'],
                fresh=prior_fresh if fresh is None else fresh,
                all_rows=prior_all if all_rows is None else all_rows,
                withdraw=prior_withdraw if withdraw is None else withdraw)
        except CoreError:
            _fail('ORIGIN_BINDING_CONFLICT', '本人原范围已变化，请保留原公司编号', mutation=None)
        if after != before:
            _fail('ORIGIN_BINDING_CONFLICT', '返回时本人、原包或公司连接已变化，请保留原号', mutation=None)
        return after

    def _session(self, frame, *, execute=False):
        remote = self._remote
        if (remote is None or any(remote.get(key) != frame[key] for key in
                ('local_company_id', 'local_user_id', 'actor_digest', 'instance_id',
                 'token_digest', 'environment_id', 'endpoint'))):
            self._remote = None
            _fail('AUTH_SCOPE_REQUIRED', '请明确登录原公司的合作来源身份')
        owner_user_scope(remote['user'], remote['scope'], company_id=remote['company_id'],
            environment_id=frame['environment_id'], instance_id=frame['instance_id'])
        if (remote['expires'] <= time.time() or execute and remote['scope']['mode'] != 'execute'):
            _fail('AUTH_SCOPE_REQUIRED', '公司受限会话需重新核对，未自动续期')
        return remote

    def _request(self, token, frame, remote, operation, body, *, fresh=None, all_rows=None):
        from integrations import request_json
        self._fence(token, frame, fresh=fresh, all_rows=all_rows)
        expected_remote = deepcopy(remote) if remote is not None else None
        expected_company = remote['company_id'] if remote else body.get('_expected_company')
        request_body = {key: value for key, value in body.items() if key != '_expected_company'}
        try:
            result = request_json(frame['endpoint'],
                {'environment_id': frame['environment_id'], 'operation': operation, **deepcopy(request_body)},
                remote['token'] if remote is not None else '')
        except Exception:
            _fail('RESULT_UNKNOWN' if operation in WRITES else 'READ_UNAVAILABLE',
                '公司结果尚未确认，请保留原号只读核对；未自动重发', mutation=None if operation in WRITES else False)
        self._fence(token, frame, fresh=fresh, all_rows=all_rows)
        if remote is not None and self._remote != expected_remote:
            _fail('AUTH_SCOPE_REQUIRED', '返回时原公司受限会话已变化，请保留原号', mutation=None if operation in WRITES else False)
        if (type(result) is not dict or result.get('contract') != 'fangyu-workspace-v1'
                or result.get('environment_id') != frame['environment_id']
                or result.get('company_id') != expected_company):
            _fail(mutation=None if operation in WRITES else False)
        return {key: deepcopy(value) for key, value in result.items()
            if key not in ('contract', 'environment_id', 'company_id')}

    def _scope_get(self, token, frame, remote):
        data = self._request(token, frame, remote, 'owner_origin_scope_get', {})
        _exact(data, {'user', 'scope', 'admission_state'} | FLAGS)
        owner_flags(data, read_only=True)
        user, scope = owner_user_scope(data['user'], data['scope'],
            company_id=remote['company_id'], environment_id=frame['environment_id'],
            instance_id=frame['instance_id'])
        if (user['username'] != remote['user']['username']
                or user['subject_id'] != remote['user']['subject_id']
                or scope['admission_id'] != remote['scope']['admission_id']
                or scope['subject_mapping_version'] != remote['scope']['subject_mapping_version']
                or scope['account_version'] != remote['scope']['account_version']
                or data['admission_state'] not in ('active', 'expired', 'revoked', 'needs_review')):
            _fail('AUTH_SCOPE_REQUIRED')
        remote['user'], remote['scope'], remote['admission_state'] = user, scope, data['admission_state']
        return data

    def _channel(self, token, frame, remote):
        data = self._request(token, frame, remote, 'owner_origin_channel_get',
            {'admission_id': remote['scope']['admission_id'],
             'package_id': frame['package_id'], 'row_id': frame['row_id']})
        _exact(data, {'admission_id', 'instance_id', 'package_id', 'row_id', 'item',
            'partial', 'reason_code'} | FLAGS)
        owner_flags(data, read_only=True)
        if (data['admission_id'] != remote['scope']['admission_id']
                or any(data[key] != frame[key] for key in ('instance_id', 'package_id', 'row_id'))
                or type(data['partial']) is not bool or data['reason_code'] not in REASONS):
            _fail()
        if data['item'] is not None:
            data['item'] = self._bound_item(data['item'], frame, remote)
        return data

    def _business_get(self, token, frame, remote, data):
        from .owner_business_view import normalize
        if not _integer(data['offset'], 0) or not _integer(data['limit'], 1) or data['limit'] > 15:
            _fail('INVALID_REQUEST', '经营核对仅接受有限原订单分页')
        channel = self._channel(token, frame, remote)['item']
        if channel is None:
            _fail('ROW_NEEDS_REVIEW', '公司原行尚不可核对经营记录')
        answer = self._request(token, frame, remote, 'owner_origin_business_get',
            {'admission_id': remote['scope']['admission_id'], 'package_id': frame['package_id'],
             'row_id': frame['row_id'], 'offset': data['offset'], 'limit': data['limit']})
        _exact(answer, {'business'} | FLAGS)
        owner_flags(answer, read_only=True)
        result = normalize(answer['business'], frame, channel, data['offset'], data['limit'])
        self._fence(token, frame)
        return result

    def _bound_item(self, item, frame, remote):
        item = owner_channel(item)
        manifest = frame['manifest']
        selected = next(row for row in manifest['rows'] if row['row_id'] == frame['row_id'])
        scope = remote['scope']
        case_id = 'oc_' + _cloud_hash(['owner_origin_case_v1', remote['company_id'],
            scope['subject_id'], frame['instance_id'], frame['package_id'], manifest['selection_digest']])
        claim_id = 'cl_' + _cloud_hash(['owner_origin_claim_v1', remote['company_id'],
            scope['subject_id'], frame['instance_id'], selected['protected_contact_source_id']])
        if (any(item[key] != frame[key] for key in ('instance_id', 'package_id', 'row_id'))
                or item['sender_subject_id'] != scope['subject_id'] or item['case_id'] != case_id
                or item['claim_id'] != claim_id
                or item['channel_id'] != 'hc_' + _cloud_hash(['owner_origin_channel_v1', claim_id])
                or item['selection_digest'] != manifest['selection_digest']
                or item['artifact_sha256'] != manifest['artifact_sha256']
                or item['recipient_id'] != scope['recipient_id']
                or item['purpose'] != manifest['purpose_label']
                or item['consent']['binding_digest'] != selected['consent_binding_digest']
                or item['permissions']['can_receipt'] is not False):
            _fail('ORIGIN_BINDING_CONFLICT')
        return item

    def _envelope(self, action, frame, remote, *, operation=None, item=None,
            partial=False, reason=None, read_only=True, mutation=False):
        flags = {key: False for key in FLAGS}
        flags.update(read_only=read_only, mutation_committed=mutation)
        return {'contract': CONTRACT, 'operation_action': action,
            'local_company_id': frame['local_company_id'], 'local_user_id': frame['local_user_id'],
            'instance_id': frame['instance_id'], 'package_id': frame['package_id'], 'row_id': frame['row_id'],
            'company_id': remote['company_id'] if remote else None,
            'environment_id': frame['environment_id'], 'user': deepcopy(remote['user']) if remote else None,
            'scope': deepcopy(remote['scope']) if remote else None,
            'admission_state': remote.get('admission_state') if remote else None,
            'operation': deepcopy(operation), 'item': deepcopy(item),
            'partial': partial, 'reason_code': reason, **flags}

    def _attempt_id(self, frame, remote, action, key):
        return digest(['owner_company_receipt_local_operation_v1', frame['local_company_id'],
            frame['local_user_id'], frame['instance_id'], remote['company_id'],
            frame['environment_id'], remote['scope']['subject_id'], action, key])

    def _custody_id(self, frame, remote):
        return digest(['owner_company_receipt_local_pending_v1', frame['local_company_id'],
            frame['local_user_id'], frame['instance_id'], remote['company_id'],
            frame['environment_id'], remote['scope']['subject_id']])

    def _attempt(self, db, frame, remote, action, key):
        ident = self._attempt_id(frame, remote, action, key)
        record = _row(db, _ATTEMPTS, ident, self.acq.tenant)
        if record is None:
            return None
        _exact(record, _ATTEMPT_FIELDS)
        expected = {'local_company_id': frame['local_company_id'],
            'local_user_id': frame['local_user_id'], 'actor_digest': frame['actor_digest'],
            'instance_id': frame['instance_id'], 'company_id': remote['company_id'],
            'environment_id': frame['environment_id'], 'subject_id': remote['scope']['subject_id'],
            'package_id': frame['package_id'], 'row_id': frame['row_id'],
            'operation_action': action, 'idempotency_key': key}
        if (record['schema'] != 'owner_company_receipt_local_operation_v1'
                or any(record.get(field) != value for field, value in expected.items())
                or not _match(record['admission_id'], _ADMISSION)
                or record['record_hash'] != _saved_hash(record)
                or type(record['request']) is not dict
                or record['input_hash'] != _cloud_hash(record['request'])
                or record['request'].get('operation') != action
                or record['request'].get('idempotency_key') != key
                or record['request'].get('environment_id') != frame['environment_id']
                or record['state'] not in ('pending', 'recorded', 'rejected')
                or not _integer(record['created_at'], 1)
                or not _integer(record['updated_at'], record['created_at'])
                or record['state'] == 'pending' and record['operation'] is not None
                or record['state'] != 'pending' and record['operation'] is None):
            _fail('ORIGIN_BINDING_CONFLICT', '原公司操作的本机绑定需核对')
        if record['operation'] is not None:
            operation = owner_operation(record['operation'], action, key)
            if operation['state'] != record['state'] or operation['input_hash'] != record['input_hash']:
                _fail()
        return record

    def _custody(self, db, frame, remote):
        ident = self._custody_id(frame, remote)
        record = _row(db, _CUSTODY, ident, self.acq.tenant)
        if record is None:
            return None
        _exact(record, _CUSTODY_FIELDS)
        expected = {'local_user_id': frame['local_user_id'], 'instance_id': frame['instance_id'],
            'company_id': remote['company_id'], 'environment_id': frame['environment_id'],
            'subject_id': remote['scope']['subject_id']}
        if (record['schema'] != 'owner_company_receipt_local_pending_v1'
                or any(record.get(key) != value for key, value in expected.items())
                or record['record_hash'] != _saved_hash(record)
                or record['pending_id'] is not None and not _match(record['pending_id'], _HEX)
                or not _integer(record['created_at'], 1)):
            _fail('ORIGIN_BINDING_CONFLICT', '原公司待核编号需核对，不能按空位重建')
        return record

    @staticmethod
    def _put(db, entity, record, *, new=False):
        record['record_hash'] = _saved_hash(record)
        encoded = json.dumps(record, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        if new:
            db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                (entity, record['id'], record['tenant_id'], encoded))
        else:
            changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (encoded, entity, record['id'], record['tenant_id']))
            if changed.rowcount != 1:
                _fail('ORIGIN_BINDING_CONFLICT')

    def _begin(self, token, frame, remote, action, key, request):
        with self.workspace._lock, self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self.acq._packages._session(db, token, frame['user'])
            previous = self._attempt(db, frame, remote, action, key)
            custody = self._custody(db, frame, remote)
            if previous is not None:
                if previous['input_hash'] != _cloud_hash(request):
                    _fail('KEY_CONFLICT', '原编号已绑定另一次输入，不能重放')
                return previous, False
            if custody is None:
                orphan = db.execute("SELECT 1 FROM records WHERE entity=? AND tenant_id=? "
                    "AND json_extract(body,'$.local_user_id')=? AND json_extract(body,'$.instance_id')=? "
                    "AND json_extract(body,'$.company_id')=? AND json_extract(body,'$.environment_id')=? "
                    "AND json_extract(body,'$.subject_id')=? AND json_extract(body,'$.state')='pending' LIMIT 1",
                    (_ATTEMPTS, self.acq.tenant, frame['local_user_id'], frame['instance_id'],
                     remote['company_id'], frame['environment_id'], remote['scope']['subject_id'])).fetchone()
                if orphan is not None:
                    _fail('ORIGIN_BINDING_CONFLICT', '原待核操作占用记录缺失，不能重新开始')
            elif custody['pending_id'] is not None:
                _fail('ORIGINAL_CLAIM_HELD', '请先只读核对原公司操作编号')
            now = int(time.time())
            record = {'id': self._attempt_id(frame, remote, action, key), 'tenant_id': self.acq.tenant,
                'schema': 'owner_company_receipt_local_operation_v1',
                'local_company_id': frame['local_company_id'], 'local_user_id': frame['local_user_id'],
                'actor_digest': frame['actor_digest'], 'instance_id': frame['instance_id'],
                'company_id': remote['company_id'], 'environment_id': frame['environment_id'],
                'subject_id': remote['scope']['subject_id'], 'admission_id': remote['scope']['admission_id'],
                'package_id': frame['package_id'], 'row_id': frame['row_id'],
                'operation_action': action, 'idempotency_key': key, 'request': deepcopy(request),
                'input_hash': _cloud_hash(request), 'state': 'pending', 'operation': None,
                'created_at': now, 'updated_at': now, 'record_hash': ''}
            initial_custody = custody is None
            if custody is None:
                custody = {'id': self._custody_id(frame, remote), 'tenant_id': self.acq.tenant,
                    'schema': 'owner_company_receipt_local_pending_v1',
                    'local_user_id': frame['local_user_id'], 'instance_id': frame['instance_id'],
                    'company_id': remote['company_id'], 'environment_id': frame['environment_id'],
                    'subject_id': remote['scope']['subject_id'], 'pending_id': None,
                    'created_at': now, 'record_hash': ''}
            custody['pending_id'] = record['id']
            self._put(db, _ATTEMPTS, record, new=True)
            self._put(db, _CUSTODY, custody, new=initial_custody)
            self.acq._packages._session(db, token, frame['user'])
            db.execute('COMMIT')
            return record, True

    def _finish(self, token, frame, remote, record, operation):
        if operation['state'] not in ('recorded', 'rejected'):
            return
        if record is None or operation['input_hash'] != record['input_hash']:
            _fail('ORIGIN_BINDING_CONFLICT', '原公司结果尚未匹配本机预保存输入')
        with self.workspace._lock, self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self.acq._packages._session(db, token, frame['user'])
            current = self._attempt(db, frame, remote, record['operation_action'], record['idempotency_key'])
            custody = self._custody(db, frame, remote)
            if current != record or custody is None:
                _fail('ORIGIN_BINDING_CONFLICT')
            if current['state'] != 'pending':
                if current['operation'] != operation:
                    _fail()
                return
            if custody['pending_id'] != current['id']:
                _fail('ORIGIN_BINDING_CONFLICT', '原待核编号归属已变化')
            current['state'], current['operation'], current['updated_at'] = operation['state'], deepcopy(operation), int(time.time())
            custody['pending_id'] = None
            self._put(db, _ATTEMPTS, current)
            self._put(db, _CUSTODY, custody)
            self.acq._packages._session(db, token, frame['user'])
            db.execute('COMMIT')

    def _unknown(self, frame, remote, action, key, record):
        return {'operation_id': _cloud_hash(['owner_origin_operation_v1', remote['company_id'],
            remote['scope']['subject_id'], frame['instance_id'], action, key]),
            'operation_action': action, 'idempotency_key': key, 'state': 'unknown',
            'mutation_committed': None, 'original_execution_confirmed': None,
            'input_hash': record['input_hash'] if record else None, 'channel_id': None,
            'original_revision': None, 'original_event_hash': None,
            'reason_code': 'OPERATION_UNKNOWN', 'auto_retry': False}

    def _write_result(self, token, action, frame, remote, cloud_action, key, record, data, *, read_only):
        _exact(data, {'operation', 'item'} | FLAGS)
        owner_flags(data, read_only=read_only)
        operation = owner_operation(data['operation'], cloud_action, key)
        if operation['operation_id'] != self._unknown(frame, remote, cloud_action, key, record)['operation_id']:
            _fail('ORIGIN_BINDING_CONFLICT')
        item = self._bound_item(data['item'], frame, remote) if data['item'] is not None else None
        if operation['state'] in ('recorded', 'rejected'):
            if record is None or operation['input_hash'] != record['input_hash']:
                _fail('ORIGIN_BINDING_CONFLICT')
            if item is not None and (operation['channel_id'] != item['channel_id']
                    or operation['state'] == 'recorded' and item['revision'] < operation['original_revision']):
                _fail('ORIGIN_BINDING_CONFLICT')
            self._finish(token, frame, remote, record, operation)
        return self._envelope(action, frame, remote, operation=operation, item=item,
            partial=item is None, reason=operation['reason_code'], read_only=read_only,
            mutation=False if read_only else operation['mutation_committed'])

    def _status(self, token, action, frame, remote, cloud_action, key):
        with self.workspace._lock, self.core.lock, self.core.store.connect() as db:
            self.acq._packages._session(db, token, frame['user'])
            record = self._attempt(db, frame, remote, cloud_action, key)
        try:
            data = self._request(token, frame, remote, 'owner_origin_operation_status',
                {'operation_action': cloud_action, 'idempotency_key': key})
            return self._write_result(token, action, frame, remote, cloud_action, key,
                record, data, read_only=True)
        except OwnerCompanyReceiptBridgeError:
            self._fence(token, frame)
            return self._envelope(action, frame, remote,
                operation=self._unknown(frame, remote, cloud_action, key, record),
                partial=True, reason='OPERATION_UNKNOWN')

    def execute(self, token, action, data):
        if action not in ACTIONS or type(data) is not dict:
            _fail('INVALID_REQUEST')
        name = action[len(PREFIX):]
        fields = {'login': {'package_id', 'company_id', 'admission_id', 'username', 'password'},
            'scope_get': {'package_id'}, 'logout': {'package_id'},
            'register': {'package_id', 'row_id', 'idempotency_key'},
            'consent_sync': {'package_id', 'row_id', 'expected_consent_version', 'idempotency_key'},
            'submit': {'package_id', 'row_id', 'expected_revision', 'expected_consent_version', 'idempotency_key'},
            'withdraw': {'package_id', 'row_id', 'expected_consent_version', 'idempotency_key'},
            'operation_status': {'package_id', 'row_id', 'operation_action', 'idempotency_key'},
            'channel_get': {'package_id', 'row_id'},
            'business_get': {'package_id', 'row_id', 'offset', 'limit'}}[name]
        # Fresh owner instances have no enterprise cloud configuration. Accept
        # an explicitly supplied connection at this same login interface; old
        # callers retain their current trusted connection without guessing.
        connection_fields = {'endpoint', 'environment_id'}
        configure = name == 'login' and bool(connection_fields & set(data))
        _exact(data, fields | connection_fields if configure else fields)
        if name == 'login':
            if (not _match(data['company_id'], _ID) or not _match(data['admission_id'], _ADMISSION)
                    or not _match(data['username'], _USERNAME) or type(data['password']) is not str
                    or not 12 <= len(data['password']) <= 256):
                _fail('INVALID_REQUEST')
            if configure:
                from integrations import endpoint, IntegrationError
                try:
                    address = endpoint(data['endpoint'])
                except (IntegrationError, TypeError, ValueError):
                    _fail('INVALID_REQUEST', '请填写当前可信公司的 HTTPS 工作区地址')
                if not address or not _match(data['environment_id'], _ENV):
                    _fail('INVALID_REQUEST', '请填写完整的公司服务入口和环境编号')
        key, cloud_action = data.get('idempotency_key'), 'owner_origin_' + name
        if key is not None and not _match(key, _HEX):
            _fail('INVALID_REQUEST')
        for field in ('expected_revision', 'expected_consent_version'):
            if field in data and not _integer(data[field], 1 if name == 'submit' else 0):
                _fail('INVALID_REQUEST')
        if name == 'operation_status' and data['operation_action'] not in WRITES:
            _fail('INVALID_REQUEST')
        if not self._lock.acquire(timeout=5):
            _fail('LOCAL_BUSY', '当前公司原号核对忙，请保留编号')
        try:
            fresh = name in ('register', 'consent_sync', 'submit')
            if configure:
                # Reuse the existing DPAPI configuration writer only after the
                # current owner/session and original package have been proved.
                # This stores no password or cooperation-origin token.
                self._remote = None
                with self.workspace._lock, self.core.lock, self.core.store.connect() as db:
                    user = self.acq._current(token)
                    self.followups._package(db, token, user, data['package_id'])
                    self.acq._packages._session(db, token, user)
                    try:
                        self.acq.server.integrations.handle('integration_save',
                            {'kind': 'cloud', 'endpoint': address,
                             'environment_id': data['environment_id']}, user)
                    except Exception:
                        _fail('RESULT_UNKNOWN', '本机公司连接保存结果需核对，请保留原资料包', mutation=None)
                    self.acq._packages._session(db, token, user)
            frame = self._frame(token, data['package_id'], data.get('row_id'),
                fresh=fresh, all_rows=name == 'register', withdraw=name == 'withdraw')
            if name == 'login':
                self._remote = None
                answer = self._request(token, frame, None, 'owner_origin_login',
                    {'username': data['username'], 'password': data['password'],
                     'admission_id': data['admission_id'], 'instance_id': frame['instance_id'],
                     '_expected_company': data['company_id']})
                _exact(answer, ('token', 'expires', 'user', 'scope'))
                user, scope = owner_user_scope(answer['user'], answer['scope'],
                    company_id=data['company_id'], environment_id=frame['environment_id'],
                    instance_id=frame['instance_id'])
                if (user['username'] != data['username'] or scope['admission_id'] != data['admission_id']
                        or not _match(answer['token'], re.compile(r'[A-Za-z0-9_-]{40,100}\Z'))
                        or not _integer(answer['expires'], 1) or answer['expires'] <= time.time()
                        or answer['expires'] > time.time() + 930
                        or scope['mode'] == 'execute' and answer['expires'] > scope['expires_at']):
                    _fail()
                remote = {key: frame[key] for key in ('local_company_id', 'local_user_id',
                    'actor_digest', 'instance_id', 'token_digest', 'environment_id', 'endpoint')}
                remote.update(company_id=data['company_id'], token=answer['token'],
                    expires=answer['expires'], user=user, scope=scope,
                    admission_state='active' if scope['mode'] == 'execute' else 'needs_review')
                self._remote = remote
                return self._envelope(action, frame, remote, read_only=False, mutation=True)
            remote = self._session(frame, execute=fresh)
            if name == 'operation_status':
                return self._status(token, action, frame, remote, data['operation_action'], key)
            if name == 'logout':
                try:
                    answer = self._request(token, frame, remote, 'owner_origin_logout', {})
                    _exact(answer, {'ok'} | FLAGS)
                    owner_flags(answer, read_only=False)
                    if answer['ok'] is not True:
                        _fail()
                finally:
                    self._remote = None
                return self._envelope(action, frame, None, read_only=False, mutation=True)
            self._scope_get(token, frame, remote)
            if name == 'scope_get':
                return self._envelope(action, frame, remote)
            if name == 'business_get':
                return self._business_get(token, frame, remote, data)
            if name == 'channel_get':
                answer = self._channel(token, frame, remote)
                return self._envelope(action, frame, remote, item=answer['item'],
                    partial=answer['partial'], reason=answer['reason_code'])
            if fresh and (remote['scope']['mode'] != 'execute' or remote['admission_state'] != 'active'):
                _fail('AUTH_SCOPE_REQUIRED')
            request = {'environment_id': frame['environment_id'], 'operation': cloud_action, 'idempotency_key': key}
            if name == 'register':
                request.update(admission_id=remote['scope']['admission_id'],
                    expected_admission_version=remote['scope']['admission_version'],
                    manifest=deepcopy(frame['manifest']), row_id=frame['row_id'])
            else:
                channel = self._channel(token, frame, remote)['item']
                if channel is None or channel['consent']['version'] != data['expected_consent_version']:
                    _fail('CAS_CONFLICT', '请明确核对当前原行同意版本')
                if name == 'submit':
                    if channel['revision'] != data['expected_revision'] or not channel['permissions']['can_submit']:
                        _fail('CAS_CONFLICT')
                    request.update(channel_id=channel['channel_id'], expected_revision=data['expected_revision'],
                        expected_consent_version=data['expected_consent_version'])
                elif name == 'consent_sync':
                    if frame['row_authorization'] != 'current_recorded_scope':
                        _fail('CONSENT_WITHDRAWN')
                    selected = next(row for row in frame['manifest']['rows'] if row['row_id'] == frame['row_id'])
                    request.update(claim_id=channel['claim_id'], expected_consent_version=data['expected_consent_version'],
                        binding_digest=selected['consent_binding_digest'], observed_at=int(time.time()))
                elif name == 'withdraw':
                    if frame['row_authorization'] != 'withdrawn':
                        _fail('ORIGIN_BINDING_CONFLICT', '须由原本机合法撤回历史发出撤回声明')
                    request.update(claim_id=channel['claim_id'], expected_consent_version=data['expected_consent_version'],
                        reason_code='owner_recorded_withdrawal')
            if len(json.dumps(request, ensure_ascii=False, separators=(',', ':')).encode('utf-8')) > 50000:
                _fail('INVALID_REQUEST')
            record, dispatch = self._begin(token, frame, remote, cloud_action, key, request)
            if not dispatch:
                return self._status(token, action, frame, remote, cloud_action, key)
            try:
                answer = self._request(token, frame, remote, cloud_action,
                    {field: value for field, value in request.items() if field not in ('environment_id', 'operation')},
                    fresh=fresh, all_rows=name == 'register')
                return self._write_result(token, action, frame, remote, cloud_action, key, record,
                    answer, read_only=False)
            except OwnerCompanyReceiptBridgeError:
                self._fence(token, frame)
                return self._envelope(action, frame, remote,
                    operation=self._unknown(frame, remote, cloud_action, key, record),
                    partial=True, reason='OPERATION_UNKNOWN', read_only=False, mutation=None)
        finally:
            self._lock.release()
