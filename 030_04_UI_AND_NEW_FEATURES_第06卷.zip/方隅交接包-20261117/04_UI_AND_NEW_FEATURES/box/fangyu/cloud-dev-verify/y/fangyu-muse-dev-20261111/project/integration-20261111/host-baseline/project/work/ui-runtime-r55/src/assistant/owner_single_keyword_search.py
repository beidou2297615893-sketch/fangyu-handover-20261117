"""Exact owner single-keyword purpose; no global search approval or tasks.

The original pinned component review stays necessary and unchanged. A separate
fixed instance-local purpose file is also required. Missing purpose is pending;
the current comments-only pilot review cannot authorize it.
"""
from contextlib import contextmanager, nullcontext
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import stat
import threading
import time
from urllib.parse import urlencode

from .self_operating_read import OwnerReadWorkspace

_SEAL=object()
_PURPOSE='owner_xhs_single_keyword_first_page_v1'
_NOTE=re.compile(r'[a-f0-9]{24}')
_REQUEST=re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{7,127}')
_SHA=re.compile(r'[a-f0-9]{64}')
_REVIEW=re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}')
_PURPOSE_FILE='owner-single-keyword-search-review.json'
_SOURCE_FILES=('app.py','assistant/self_operating_read.py',
    'assistant/owner_single_keyword_search.py','core/adapters.py',
    'core/platform_reads.py','web/workspace/self-operating-read.mjs',
    'assistant/owner_keyword_source_trace.py','assistant/self_operating_archive.py',
    'assistant/platform_receipt_archive.py','assistant/self_operating_acquisition.py')


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
                                    separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _keyword(value):
    if (type(value) is not str or value!=value.strip() or not 1<=len(value)<=200
            or value.startswith('-') or any(ord(c)<32 or ord(c)==127 for c in value)):
        raise ValueError('请输入一个明确关键词；不支持命令、列表或自动扩词')
    return value


def source_revision():
    # Ten exact source paths only, not a runtime inventory or source-tree scan.
    root=Path(__file__).parent.parent
    from core.runtime_license_policy import _plain
    return _digest({name:hashlib.sha256(_plain(root/name,root).read_bytes()).hexdigest()
                    for name in _SOURCE_FILES})


def _stable_binding(user,account,instance_id):
    return {'actor':{k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')},
            'instance_id':instance_id,'account_id':account['id'],
            'account_uid':account.get('platform_uid'),'connection':account.get('conn_id')}


def _plain_home(path,root):
    path,root=Path(path),Path(root)
    parts=path.relative_to(root).parts
    current=root
    for part in ('',*parts):
        if part:current=current/part
        try:attrs=current.lstat()
        except FileNotFoundError:continue
        if (current.is_symlink() or not stat.S_ISDIR(attrs.st_mode)
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
            raise ValueError('本人账号 HOME 不允许链接或重定向')
    return path


def validate_payload(payload):
    """Validate every raw card before original mapper; never drop/truncate."""
    # Fixed 0.6.4 formatter_utils.success_payload wraps the SDK's already
    # unwrapped successful data: exact ok=True/schema_version="1"/data.
    # Do not interpret another success/code/status/error envelope as an empty
    # successful page. The original global parser is intentionally unchanged.
    if (type(payload) is not dict or set(payload)!={'ok','schema_version','data'}
            or payload['ok'] is not True or type(payload['schema_version']) is not str
            or payload['schema_version']!='1' or type(payload['data']) is not dict):
        raise ValueError('固定 CLI 搜索成功包待核对；失败或未知状态不作为空页')
    raw=payload['data']
    if {'ok','success','code','status','error','schema_version'}&set(raw):
        raise ValueError('SDK 数据存在未核实的状态包；本页未接受')
    if type(raw) is not dict or type(raw.get('items')) is not list or len(raw['items'])>20:
        raise ValueError('首作品页结构或数量待核对')
    if raw.get('has_more') is not None and type(raw['has_more']) is not bool:
        raise ValueError('搜索页 has_more 待核对')
    seen=set()
    for item in raw['items']:
        if type(item) is not dict or type(item.get('id')) is not str or not _NOTE.fullmatch(item['id']) or item['id'] in seen:
            raise ValueError('搜索作品 ID 待核对')
        seen.add(item['id'])
        card=item.get('note_card')
        if type(card) is not dict or card.get('note_id') not in (None,item['id']):
            raise ValueError('搜索卡片与作品 ID 不一致')
        outer,inner=item.get('xsec_token'),card.get('xsec_token')
        if outer is not None and inner is not None and outer!=inner:
            raise ValueError('作品定位 token 不一致')
        token=outer if outer is not None else inner
        if type(token) is not str or not re.fullmatch(r'[A-Za-z0-9+/=_-]{1,512}',token):
            raise ValueError('作品缺少可核对定位 token；不猜测本地缓存')
        url='https://www.xiaohongshu.com/explore/'+item['id']+'?'+urlencode({'xsec_token':token,'xsec_source':'pc_search'})
        if len(url)>2048 or item.get('url') not in (None,url):raise ValueError('作品 URL 与 ID/token 不一致或过长')
        for name,maximum in (('display_title',1000),('title',1000),('desc',32000)):
            value=card.get(name)
            if value is not None and (type(value) is not str or len(value)>maximum):
                raise ValueError('作品字段待核对')
        user=card.get('user',{})
        if type(user) is not dict:raise ValueError('作品作者字段待核对')
        if type(user.get('nickname','')) is not str or len(user.get('nickname',''))>300:
            raise ValueError('作品作者显示字段待核对')
        uid=user.get('user_id','')
        if type(uid) is not str or uid and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9:_-]{0,255}',uid):
            raise ValueError('作者 ID 待核对；它不是本人账号 UID')
    return raw


class OwnerSingleKeywordSearch:
    ACTIONS=frozenset(('owner_keyword_search','owner_keyword_search_status','owner_keyword_search_cancel'))

    def __init__(self,workspace):
        if type(workspace) is not OwnerReadWorkspace:raise ValueError('搜索只能由当前可信自营实例创建')
        self.workspace=workspace
        self.scope=_OwnerSearchScope(workspace,_SEAL)

    def read_service_options(self):return {'owner_keyword_search_scope':self.scope}

    def bind_read_service(self,reads):
        from core.platform_reads import PlatformReadService
        if (type(reads) is not PlatformReadService or reads.core is not self.workspace.server.core
                or reads._owner_keyword_search_scope is not self.scope or self.scope.reads is not None
                or self.workspace._reads is not reads):raise ValueError('搜索须绑定原本人读取服务')
        self.scope.reads=reads

    def describe(self):
        # This is a small local purpose fact, not a platform/account readiness
        # probe or the original component's full artifact validation.
        try:self.scope.review(verify_sources=True);status='reviewed'
        except (ValueError,OSError,UnicodeError,TypeError,KeyError):status='pending'
        return {'purpose':_PURPOSE,'status':status,'page':1,'limit':20,
                'global_search_verified':False,'platform_requests_started':False,
                'auto_retry':False,'archive_available':False}

    def _result(self,result,request):
        from core.platform_reads import source_reference
        if (type(result) is not dict or result.get('platform')!='xiaohongshu'
                or result.get('action')!='search' or result.get('platform_writes') is not False
                or result.get('real_platform_verified') is not False or result.get('archive_available') is not False
                or type(result.get('items')) is not list or len(result['items'])>20):
            raise ValueError('原首作品页结果结构待核对')
        state='completed' if result['code']=='completed' else 'cancelled' if result['code']=='cancelled' else 'held'
        items=[]
        for item in result['items']:
            if type(item) is not dict or item.get('source_type')!='note' or item.get('platform')!='xiaohongshu':
                raise ValueError('首作品页只能显示原笔记定位')
            ident,url=source_reference('xiaohongshu',item.get('url'))
            if not _NOTE.fullmatch(ident) or item.get('post_id')!=ident or item.get('source_id')!=ident or url!=item['url']:
                raise ValueError('原作品定位未匹配 ID')
            items.append({'id':ident,'url':url,'title':item['title'],'text':item['text'],'author':item['author']})
        page=result['page']
        if (type(page) is not dict or page.get('has_more') is not None and type(page['has_more']) is not bool
                or type(page.get('pagination_verified')) is not bool or page.get('cursor')):
            raise ValueError('首作品页分页事实待核对')
        if state=='completed' and (result.get('observed_count')!=len(items) or result.get('requested_limit')!=20
                or result.get('limit_exceeded') is not False):raise ValueError('首作品页数量超界或不一致')
        return {'purpose':_PURPOSE,'request_id':request,'state':state,'code':result['code'],
                'message':result['message'],'operation_id':result['operation_id'],'items':items,
                'page':{'has_more':page['has_more'],'pagination_verified':page['pagination_verified']},
                'observed_count':len(items),'requested_limit':20,'archive_available':False,
                'global_search_verified':False,'source_verification':'transport_reported_only',
                'preparatory_http_max':4,'account_local_token_session_cache':True,
                'auto_retry':False,'platform_writes':False,'real_platform_verified':False}

    def _entry(self,reads,request,user,account):
        entry=reads._operations.get(request)
        if entry is not None and (entry['account_id']!=account['id']
                or entry.get('_owner_keyword_search') is not True
                or entry.get('_owner_keyword_binding')!=_stable_binding(user,account,
                    self.workspace.instance.check()['selfOperatingRead']['instance_id'])):
            raise ValueError('原编号不是当前本人、实例与账号的首作品页搜索')
        return entry

    def capture_selection(self,token,account_id,request,post_id):
        """Private original-search member snapshot; performs no platform call.

        Can inspect inside an already checked owner archive frame, but never
        issues a comments grant. The caller closes this search frame before
        invoking the independent original comments action.
        """
        if (type(request) is not str or not _REQUEST.fullmatch(request)
                or type(post_id) is not str or not _NOTE.fullmatch(post_id)):
            raise ValueError('原搜索选择必须使用原请求和作品编号')
        w=self.workspace;user=w._actor(token);account=w._account(user,account_id)
        reads=self.scope.reads
        if reads is None:raise ValueError('原搜索读取服务尚未绑定')
        with reads._lock:
            entry=self._entry(reads,request,user,account)
            if (entry is None or entry.get('running') or entry.get('cancelled')
                    or entry.get('response',{}).get('code')!='completed'):
                raise ValueError('原搜索未完成或已取消，不能声明选中出处')
            keyword=_keyword(entry.get('_owner_keyword'))
        active=getattr(w._tls,'call',None)
        if active is not None and (type(active) is not tuple or len(active)!=4
                or active[0]!=token or active[1]!=account or active[2] is not False or active[3] is not False):
            raise ValueError('搜索出处不能借核对、登录或其他账号范围')
        with (nullcontext() if active is not None else w._call(token,account)),self.scope.frame(token,user,account,request,keyword):
            w.execution_guard('xiaohongshu')
            with reads._lock:
                exact=self._entry(reads,request,w._actor(token),account)
                if (exact is not entry or entry.get('running') or entry.get('cancelled')
                        or reads._origin_error(entry,user,account)
                        or not self.scope.entry_current(entry,user,account)):
                    raise ValueError('原搜索当前账号、用途或结果已变化')
                stamp=entry.get('observed_at')
                now=time.time()
                if (type(stamp) not in (int,float) or not 0<=now-stamp<=300):
                    raise ValueError('原搜索选择已过期，请只保留旧出处记录')
                result=self._result(deepcopy(entry['response']),request)
                matches=[item for item in result['items'] if item['id']==post_id]
                if len(matches)!=1:raise ValueError('选中作品不是原搜索唯一成员')
                frame,_=self.scope.check(account)
                captured={'reference':matches[0]['url'],'keyword':keyword,
                    'search_operation_id':entry['operation_id'],
                    'search_result_digest':_digest(entry['response']),
                    'search_purpose_revision':frame['revision'],
                    'search_source_revision':frame['source_revision']}
            w.execution_guard('xiaohongshu')
        return captured

    def execute(self,token,action,data):
        if action not in self.ACTIONS or type(data) is not dict:
            raise ValueError('只支持固定首作品页搜索、原号状态或取消')
        required={'account_id','request_id'}
        if action=='owner_keyword_search':required|={'keyword','page','limit'}
        if set(data)!=required or type(data.get('request_id')) is not str or not _REQUEST.fullmatch(data['request_id']):
            raise ValueError('首作品页只接收本人账号、原号和固定单关键词参数')
        user=self.workspace._actor(token)
        if action!='owner_keyword_search':
            # Metadata/physical cancel never mint a new search or require review.
            account=self.workspace._account(user,data['account_id'],cleanup=True)
            reads=self.scope.reads
            if reads is None:raise ValueError('本人读取服务未绑定')
            if action=='owner_keyword_search_cancel':
                with reads._lock:self._entry(reads,data['request_id'],user,account)
                result=reads.execute('platform_read_cancel',data,self.workspace.server.core._public(user))
                with reads._lock:
                    entry=reads._operations.get(data['request_id'])
                    if entry and entry.get('fingerprint') is None and entry.get('cancelled') and not entry.get('running'):
                        # Original cancellation tombstone, never a search grant.
                        entry.update(_owner_keyword_search=True,_owner_keyword_binding=_stable_binding(user,account,
                            self.workspace.instance.check()['selfOperatingRead']['instance_id']))
                    result['cleanup_confirmed']=not bool(entry and entry.get('running'))
                return {'purpose':_PURPOSE,'request_id':data['request_id'],
                        'state':'cancelled' if result['cleanup_confirmed'] else 'cleanup_pending',
                        'auto_retry':False,'cleanup_confirmed':result['cleanup_confirmed'],
                        'platform_requests_started':False,'result_available':False,'result':None}
            # The original entry is read under its own lock. Missing requests
            # remain unknown; no new CLI, authorization or implicit re-submit.
            with reads._lock:
                entry=self._entry(reads,data['request_id'],user,account)
                if entry is None:return {'purpose':_PURPOSE,'request_id':data['request_id'],'state':'unknown',
                    'auto_retry':False,'cleanup_confirmed':False,'platform_requests_started':False,
                    'result_available':False,'result':None}
                state=('cleanup_pending' if entry.get('running') and entry.get('cancelled') else
                       'running' if entry.get('running') else 'cancelled' if entry.get('cancelled') else
                       'completed' if entry.get('response',{}).get('code')=='completed' else 'held')
                output={'purpose':_PURPOSE,'request_id':data['request_id'],'state':state,'auto_retry':False,
                    'cleanup_confirmed':not entry.get('running',False),'platform_requests_started':False,
                    'result_available':False,'result':None}
                keyword=entry.get('_owner_keyword')
            if state=='completed':
                # Old-number result lookup is never another execute/search.
                # Metadata stays visible under hold, content requires all fresh
                # current gates and the exact original purpose revision.
                from core import CoreError
                try:
                    current=self.workspace._account(user,account['id'])
                    with self.workspace._call(token,current),self.scope.frame(token,user,current,data['request_id'],_keyword(keyword)):
                        self.workspace.execution_guard('xiaohongshu')
                        if reads._origin_error(entry,user,current):raise ValueError('原首作品页的许可或来源已变化')
                        with reads._lock:
                            exact=self._entry(reads,data['request_id'],self.workspace._actor(token),current)
                            if exact is not entry or entry.get('running') or entry.get('cancelled') or not self.scope.entry_current(entry,user,current):
                                raise ValueError('原首作品页的来源范围已变化')
                            output.update(result_available=True,result=self._result(deepcopy(entry['response']),data['request_id']))
                        self.workspace.execution_guard('xiaohongshu')
                except (CoreError,ValueError,RuntimeError,OSError):
                    output.update(result_available=False,result=None)
            self.workspace._actor(token)
            return output
        keyword=_keyword(data['keyword'])
        if data['page']!=1 or type(data['page']) is not int or data['limit']!=20 or type(data['limit']) is not int:
            raise ValueError('本次仅首作品页，请求数量固定20，不自动翻页')
        account=self.workspace._account(user,data['account_id'])
        with self.workspace._call(token,account),self.scope.frame(token,user,account,data['request_id'],keyword):
            result=self.scope.reads.execute('platform_read_search',data,self.workspace.server.core._public(user))
            self.workspace.execution_guard('xiaohongshu')
            self.scope.check(account)
            return self._result(result,data['request_id'])


class _OwnerSearchScope:
    def __init__(self,workspace,seal):
        if seal is not _SEAL or type(workspace) is not OwnerReadWorkspace:raise ValueError('搜索范围无效')
        self.workspace=workspace
        self.server=workspace.server
        self.instance=workspace.instance
        self.core=workspace.server.core
        self.reads=None
        self._tls=threading.local()

    def review(self,*,verify_sources=False):
        """Fixed plain instance purpose file; shared component bytes untouched."""
        binding=self.server._runtime_license_review_binding
        if binding is None or not binding.current(self.server.company):raise ValueError('搜索用途默认待审')
        original=binding.review
        if original['review']['decision']!='approved' or original['usage_scope']!='internal_self_use_read':
            raise ValueError('原组件内部技术审查未批准')
        from core.runtime_license_policy import _plain
        root=self.instance.directory
        path=_plain(root/_PURPOSE_FILE,self.instance.work_root)
        attrs=path.stat()
        if attrs.st_nlink!=1 or attrs.st_size>65536:raise ValueError('搜索用途文件不能共享或过大')
        raw=path.read_bytes()
        if len(raw)>65536:raise ValueError('搜索用途文件过大')
        def pairs(items):
            result={}
            for key,value in items:
                if key in result:raise ValueError('搜索用途有重复字段')
                result[key]=value
            return result
        purpose=json.loads(raw.decode('utf-8'),object_pairs_hook=pairs)
        if type(purpose) is not dict or set(purpose)!={'schema','purpose','company_id','instance_id','route',
                'artifact','source_revision','page','limit','preparatory_http_max','decision',
                'revision','reviewer_ref','production_distribution_approved','real_platform_verified'}:
            raise ValueError('本机首作品页搜索用途尚未单独审查')
        if (purpose['schema']!='owner_single_keyword_search_review_v1'
                or purpose['purpose']!=_PURPOSE or purpose['company_id']!=self.server.company['id']
                or purpose['instance_id']!=self.instance.check()['selfOperatingRead']['instance_id']
                or type(purpose['artifact']) is not dict or purpose['artifact']!=original['artifact']
                or type(purpose['source_revision']) is not str or not _SHA.fullmatch(purpose['source_revision'])
                or purpose['route']!='guarded_cli_v1' or type(purpose['page']) is not int or purpose['page']!=1
                or type(purpose['limit']) is not int or purpose['limit']!=20
                or type(purpose['preparatory_http_max']) is not int or purpose['preparatory_http_max']!=4
                or purpose['decision']!='approved' or type(purpose['revision']) is not str
                or not _REVIEW.fullmatch(purpose['revision']) or type(purpose['reviewer_ref']) is not str
                or not _REVIEW.fullmatch(purpose['reviewer_ref'])
                or purpose['revision'].startswith('recorded-mainflow-') or purpose['reviewer_ref'].startswith('synthetic-')
                or purpose['production_distribution_approved'] is not False or purpose['real_platform_verified'] is not False):
            raise ValueError('搜索用途的实例、边界或真实内部技术决定尚待核对')
        frame=getattr(self._tls,'frame',None)
        expected=source_revision() if verify_sources else frame['source_revision'] if frame else source_revision()
        if purpose['source_revision']!=expected:raise ValueError('搜索用途与本切片源码版本不一致')
        return hashlib.sha256(raw).hexdigest(),expected

    @contextmanager
    def frame(self,token,user,account,request,keyword):
        if getattr(self._tls,'frame',None) is not None:raise ValueError('搜索不能借用或嵌套其他用途')
        revision,sources=self.review(verify_sources=True)
        frame={'seal':_SEAL,'token':token,'user':deepcopy(user),'account':deepcopy(account),
               'request':request,'keyword':keyword,'revision':revision,'source_revision':sources,
               'thread':threading.get_ident()}
        self._tls.frame=frame
        try:
            self.check(account);yield
            if self.review(verify_sources=True)!=(revision,sources):raise ValueError('搜索用途或源码已变化')
        finally:
            if getattr(self._tls,'frame',None) is frame:del self._tls.frame

    def check(self,account):
        frame=getattr(self._tls,'frame',None)
        if (frame is None or frame['seal'] is not _SEAL or frame['thread']!=threading.get_ident()
                or self.server._self_operating_reads is not self.workspace or self.workspace.instance is not self.instance
                or self.server.core is not self.core or self.workspace._reads is not self.reads
                or self.reads._owner_keyword_search_scope is not self
                or self.instance.check()!=self.server.company):raise ValueError('本次搜索私有范围已失效')
        current_user=self.workspace._actor(frame['token'])
        current_account=self.workspace._account(current_user,frame['account']['id'])
        if current_user!=frame['user'] or current_account!=frame['account'] or account!=current_account:
            raise ValueError('搜索期间本人或账号/UID/连接范围已变化')
        self.core._platform_execution_guard('xiaohongshu')
        if self.review()!=(frame['revision'],frame['source_revision']):raise ValueError('搜索用途审核已变化')
        if current_account.get('platform_uid','').casefold() in ('0','unknown','null','none','-'):
            raise ValueError('本人 UID 未知，不能搜索')
        manifest=self.core.adapters.manifest('xiaohongshu')
        if (manifest.get('mapper')!='xhs_v1' or manifest.get('search_verified') is not False
                or manifest.get('prefix_args')!=['xiaohongshu']
                or manifest.get('search_args')!=['search','{keyword}','--json']
                or manifest.get('isolation_guard') is not True
                or self.core.adapters.xhs_page_runtime is not None):raise ValueError('搜索必须使用原固定0.6.4 CLI，不能借页面许可')
        directory=self.core.store.directory/'accounts'/current_user['tenant_id']/current_account['id']
        return frame,_plain_home(directory,self.core.store.directory)

    def entry_current(self,entry,user,account):
        frame,_=self.check(account)
        return (entry.get('_owner_keyword_search') is True
                and entry.get('_owner_keyword_binding')==_stable_binding(user,account,
                    self.instance.check()['selfOperatingRead']['instance_id'])
                and entry.get('_owner_keyword_revision')==frame['revision']
                and entry.get('_owner_keyword')==frame['keyword'])

    def bind_entry(self,entry,user,account):
        frame=getattr(self._tls,'frame',None)
        if (frame is None or frame['seal'] is not _SEAL or frame['thread']!=threading.get_ident()
                or self.reads._operations.get(frame['request']) is not entry or entry.get('account_id')!=account['id']
                or user!=frame['user'] or account!=frame['account']):
            raise ValueError('搜索不能登记其他读取请求')
        entry.update(_owner_keyword_search=True,_owner_keyword=frame['keyword'],
            _owner_keyword_revision=frame['revision'],_owner_keyword_binding=_stable_binding(user,account,
                self.instance.check()['selfOperatingRead']['instance_id']))
        self.check(account)


class _XhsOwnerSearchCall:
    def __init__(self,scope,entry,user,account,task,seal):
        if seal is not _SEAL or type(scope) is not _OwnerSearchScope:raise ValueError('搜索须原私有调用')
        self.scope,self.entry,self.user,self.account,self.task=scope,entry,deepcopy(user),deepcopy(account),task
        frame,self.directory=scope.check(account)
        self.request,self.thread=frame['request'],threading.get_ident()
        self.args=['search',frame['keyword'],'--json','--page','1']
        self.adapters=scope.core.adapters
        self.manifest=deepcopy(self.adapters.manifest('xiaohongshu'))
        self.job_id=entry['operation_id']

    def check(self,adapters=None,platform=None,args=None,account_dir=None,job_id=None):
        frame,directory=self.scope.check(self.account)
        reads=self.scope.reads
        if (self.thread!=threading.get_ident() or frame['request']!=self.request or directory!=self.directory
                or reads._operations.get(self.request) is not self.entry or not self.entry.get('running')
                or self.entry.get('cancelled') or self.entry['account_id']!=self.account['id']
                or self.task.get('id')!=self.job_id or self.task.get('_account_dir')!=str(self.directory)
                or self.task.get('keywords')!=[frame['keyword']] or self.task.get('next_page')!=1
                or self.task.get('daily_limit')!=20 or self.adapters.manifest('xiaohongshu')!=self.manifest):
            raise ValueError('原搜索请求、范围或取消状态已变化')
        if adapters is not None and (adapters is not self.adapters or platform!='xiaohongshu'
                or args!=self.args or Path(account_dir)!=self.directory or job_id!=self.job_id):
            raise ValueError('搜索调用不匹配原适配器/命令/HOME/job')

    def check_spec(self,spec):
        root=self.directory
        env={**self.manifest.get('env',{}),'HOME':str(root),'USERPROFILE':str(root),
             'XDG_CONFIG_HOME':str(root/'.config'),'APPDATA':str(root/'AppData/Roaming'),
             'LOCALAPPDATA':str(root/'AppData/Local'),'LEADSTUDIO_ISOLATED':'1','PYTHONUTF8':'1',
             'PYTHONIOENCODING':'utf-8','WORKSPACE_ACTIVITY_LOG':str(root/'platform-activity.jsonl'),
             'WORKSPACE_ACTIVITY_KIND':'search'}
        if (type(spec) is not dict or set(spec)!={'argv','cwd','env'}
                or spec['argv']!=[self.manifest['executable'],'xiaohongshu']+self.args
                or spec['cwd']!=str(root) or spec['env']!=env
                or set(self.manifest.get('env',{}))-{'PYTHONUTF8','PYTHONIOENCODING'}):
            raise ValueError('最终搜索argv/HOME/隔离环境不一致')

    @contextmanager
    def launch(self):
        with self.scope.reads._lock,self.scope.core.lock:
            self.check()
            yield


@contextmanager
def owned_keyword_search(reads,entry,user,account,task,scope):
    from core.adapters import account_execution_lock,_BilibiliOwnedCleanupPending
    if type(scope) is not _OwnerSearchScope or scope.reads is not reads:raise ValueError('搜索用途待审')
    call=_XhsOwnerSearchCall(scope,entry,user,account,task,_SEAL)
    with account_execution_lock(call.directory):
        call.check();scope.bind_entry(entry,user,account)
        task['_xhs_owner_search_call']=call
        try:
            yield
        except _BilibiliOwnedCleanupPending as pending:
            # Original owner retains exact entry/collection lease and account
            # OS lock until confirmed exit; revoked permission never blocks it.
            while not pending.finish():threading.Event().wait(0.1)
            raise RuntimeError('原搜索进程已收尾，结果未确认') from None
        else:
            call.check()
            scope.workspace._require_activity_safe(user,account)
        finally:
            if task.get('_xhs_owner_search_call') is call:task.pop('_xhs_owner_search_call',None)


def check_adapter_call(adapters,platform,args,account_dir,job_id,call):
    if call is None:return None
    if type(call) is not _XhsOwnerSearchCall:raise ValueError('搜索只接受原私有用途类型')
    call.check(adapters,platform,args,account_dir,job_id)
    return call


from core.adapters import _BilibiliOwnedCleanupPending


class _XhsOwnerSearchCleanupPending(_BilibiliOwnedCleanupPending):
    """Same original physical finish; also remove its exact XHS HOME binding."""
    def __init__(self,adapters,process,key,job_id,account_dir):
        super().__init__(adapters,process,key,job_id)
        self.account_dir=Path(account_dir).resolve()

    def finish(self):
        if not super().finish():return False
        with self.adapters.lifecycle_lock:
            # Original finish has confirmed exit and removed only this process.
            if self.adapters.process_accounts.get(self.key)==self.account_dir:
                self.adapters.process_accounts.pop(self.key,None)
        return True
