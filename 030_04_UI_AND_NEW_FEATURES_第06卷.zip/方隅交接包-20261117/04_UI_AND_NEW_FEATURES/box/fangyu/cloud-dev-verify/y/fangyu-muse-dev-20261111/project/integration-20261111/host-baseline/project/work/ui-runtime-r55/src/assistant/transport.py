import json
import time
from urllib.parse import urlsplit
import httpx

DEVICE_POLL_ERROR_CODES=frozenset((
    'DEVICE_ACTIVE_LIMIT','DEVICE_AUTH_REQUIRED','DEVICE_OFFLINE','DEVICE_REVOKED',
    'DEVICE_SNAPSHOT_AUTH_REQUIRED','DEVICE_SNAPSHOT_REQUEST_INVALID',
    'DEVICE_SNAPSHOT_STATE_INVALID','DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE',
    'OWNER_INACTIVE','ROLE_INELIGIBLE','VERSION_MISMATCH','PROTOCOL_MISMATCH',
    'POLICY_DISABLED','COMPANY_MISMATCH'))

class CloudError(RuntimeError):
    def __init__(self,status,code=''):
        self.status=status;self.code=code
        super().__init__('cloud_request_failed_'+str(status))

class CloudTransport:
    def __init__(self,url,environment_id,company_id,client=None):
        parsed=urlsplit(url)
        if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('固定企业服务必须是HTTPS地址')
        self.url=url;self.environment_id=environment_id;self.company_id=company_id
        self.client=client or httpx.Client(timeout=httpx.Timeout(25,connect=8),follow_redirects=False,trust_env=False)

    def call(self,operation,data=None,token=''):
        payload={**(data or {}),'operation':operation,'environment_id':self.environment_id}
        headers={'Accept':'application/json'}
        if token:headers['Authorization']='Bearer '+token
        # Never retry state-changing operations inside the HTTP transport.
        # Contact sync runs beside the command poll and must not hold shutdown
        # or a shared HTTP connection for the ordinary 25-second timeout.
        options={'timeout':httpx.Timeout(8,connect=5)} if operation in ('contact_events_sync','contact_responses_sync') else {}
        with self.client.stream('POST',self.url,json=payload,headers=headers,**options) as response:
            if response.status_code!=200:
                code=''
                if operation in ('contact_events_sync','contact_responses_sync','device_poll'):
                    # Only a known machine code may distinguish an unclaimed
                    # sender from device revocation; never surface raw bodies.
                    raw=bytearray()
                    for chunk in response.iter_bytes():
                        raw.extend(chunk)
                        if len(raw)>4096:break
                    if len(raw)<=4096:
                        try:
                            body=json.loads(raw)
                            value=body.get('code') or (body.get('data') or {}).get('code')
                            allowed=(DEVICE_POLL_ERROR_CODES if operation=='device_poll' else
                                     {'CONTACT_SENDER_UNCLAIMED'} if operation=='contact_events_sync' else
                                     {'CONTACT_RESPONSE_UNVERIFIED','CONTACT_RESPONSE_CONFLICT','CONTACT_INVALID_INPUT'})
                            if value in allowed:code=value
                        except (ValueError,TypeError,AttributeError):pass
                raise CloudError(response.status_code,code)
            chunks=[];size=0
            for chunk in response.iter_bytes():
                size+=len(chunk)
                if size>2_000_000:raise ValueError('Cloud response too large')
                chunks.append(chunk)
        result=json.loads(b''.join(chunks))
        if (result.get('contract'),result.get('environment_id'),result.get('company_id'))!=('fangyu-workspace-v1',self.environment_id,self.company_id):
            raise ValueError('Cloud identity mismatch')
        return result

    def device_permission_snapshot(self,token):
        """Fixed no-claim metadata operation; missing server support is held."""
        result=self.call('device_permission_snapshot',{},token)
        device=result.get('device')
        release=result.get('employee_release')
        if (result.get('purpose')!='device_permission_snapshot'
                or result.get('schema')!='device-permission-snapshot-v1'
                or result.get('read_only') is not True
                or result.get('mutation_committed') is not False
                or result.get('command_claimed') is not False or result.get('auto_retry') is not False
                or type(result.get('snapshot_at')) is not int or result['snapshot_at']<0
                or not 0<=time.time()-result['snapshot_at']<=45
                or type(result.get('safety_hold')) is not bool
                or type(result.get('release_approved')) is not bool
                or type(result.get('release_version')) is not str
                or not isinstance(device,dict)
                or any(type(device.get(key)) is not str for key in ('id','name','owner','version'))
                or type(device.get('last_seen')) is not int or device['last_seen']<0
                or any(type(device.get(key)) is not bool for key in ('revoked','platform_qa','continuous_qa'))
                or not isinstance(result.get('owner_permissions'),dict)
                or type(result['owner_permissions'].get('can_reply')) is not bool
                or not isinstance(release,dict)
                or any(type(release.get(key)) is not bool for key in ('allowed','continuous_read'))
                or any(type(release.get(key)) is not str for key in ('device_id','version','reason'))
                or type(release.get('lease_seconds')) is not int or release['lease_seconds']<0
                or device.get('employee_release')!=release
                or any(type(result.get(key)) is not str for key in ('platform_qa_device_id','platform_qa_version','continuous_qa_mode'))
                or type(result.get('continuous_qa')) is not bool
                or any(type(result.get(key)) is not int or result[key]<0 for key in ('continuous_qa_max_batches','continuous_qa_until','continuous_qa_remaining_seconds'))):
            raise ValueError('Device permission snapshot contract mismatch')
        return result

    def close(self):self.client.close()
