"""Stable comment identity for append-only collection observations.

Adapted from the locally prepared incremental handoff's append/link/conflict
contract. Existing tenant+platform+comment deduplication remains authoritative;
the collecting account is an observation, not another copy of a customer.
"""
import hashlib
import json
import re
from urllib.parse import urlsplit

OBSERVATIONS = 'lead_task_observations_v1'
CONFLICTS = 'lead_comment_conflicts_v1'


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def comment_identity(row, platform):
    if not isinstance(row,dict) or row.get('platform') != platform:
        raise ValueError('评论平台与采集任务不一致，未推进评论断点')
    ident=row.get('comment_id')
    if (not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident)
            or row.get('source_id') != 'comment:'+ident):
        raise ValueError('评论缺少可核对的稳定来源编号，未推进评论断点')
    value=row.get('note_url') or row.get('url')
    if not isinstance(value,str) or len(value)>2048:
        raise ValueError('评论原帖来源尚不能核对，未推进评论断点')
    try:
        parsed=urlsplit(value);port=parsed.port
    except ValueError:
        raise ValueError('评论原帖来源尚不能核对，未推进评论断点') from None
    domains={'xiaohongshu':('xiaohongshu.com','www.xiaohongshu.com'),
             'douyin':('douyin.com','www.douyin.com')}
    pattern=(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]+)/?'
             if platform=='xiaohongshu' else r'/video/([0-9]+)/?')
    match=re.fullmatch(pattern,parsed.path)
    if (parsed.scheme!='https' or parsed.hostname not in domains.get(platform,())
            or port not in (None,443) or parsed.username or parsed.password or not match):
        raise ValueError('评论原帖来源尚不能核对，未推进评论断点')
    text=row.get('text')
    if not isinstance(text,str) or len(text)>3000 or '\x00' in text:
        raise ValueError('评论原文格式无法核对，未推进评论断点')
    return ident,match[1],text
