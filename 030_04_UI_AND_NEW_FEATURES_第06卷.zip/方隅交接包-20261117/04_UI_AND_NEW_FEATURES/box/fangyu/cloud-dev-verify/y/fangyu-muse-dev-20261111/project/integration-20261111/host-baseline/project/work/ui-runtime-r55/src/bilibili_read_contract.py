"""Fixed Bilibili search / top-level comment source contract, without authority."""
from datetime import datetime, timezone
import json
import re

BV = re.compile(r'BV[A-Za-z0-9]{10}')
MAX_BYTES = 1024 * 1024
class BilibiliContractError(ValueError):
    pass

def _need(condition):
    if not condition:raise BilibiliContractError('B站只读结果无法可靠关联原来源')

def _number(value, *, zero=False):
    _need(type(value) is int or isinstance(value,str) and re.fullmatch(r'0|[1-9][0-9]{0,19}',value) is not None)
    result=int(value)
    _need((result>=0 if zero else result>0) and result<10**20)
    return result

def _text(value, maximum=32000):
    _need(isinstance(value,str) and len(value)<=maximum)
    return value

def _stamp(value):
    value=_number(value)
    try:return datetime.fromtimestamp(value,tz=timezone.utc).isoformat(timespec='seconds')
    except (ValueError,OSError,OverflowError):raise BilibiliContractError('B站来源时间无效') from None

def _bvid(value):
    _need(isinstance(value,str) and BV.fullmatch(value) is not None)
    return value

def _note(item):
    _need(type(item) is dict)
    bvid=_bvid(item.get('bvid'))
    _number(item.get('aid'))
    title=_text(item.get('title'),1000)
    mid=item.get('mid')
    row={'platform':'bilibili','source_type':'note','source_id':bvid,
         'url':'https://www.bilibili.com/video/'+bvid,'text':title,'title':title,
         'author':_text(item.get('author',''),300),
         'author_id':str(_number(mid)) if mid is not None else '',
         'stage':'待核实视频','region':''}
    if item.get('pubdate') is not None:row['published_at']=_stamp(item['pubdate'])
    return row

def _comment(item,bvid,aid):
    _need(type(item) is dict and _number(item.get('oid'))==aid and type(item.get('type')) is int and item['type']==1)
    rpid=_number(item.get('rpid'))
    if item.get('rpid_str') is not None:_need(_number(item['rpid_str'])==rpid)
    _need(_number(item.get('root'),zero=True)==0 and _number(item.get('parent'),zero=True)==0)
    member,content=item.get('member'),item.get('content')
    _need(type(member) is dict and type(content) is dict)
    mid=_number(member.get('mid'))
    if item.get('mid') is not None:_need(_number(item['mid'])==mid)
    text=_text(content.get('message'))
    return {'platform':'bilibili','source_type':'comment','source_id':'comment:'+str(rpid),
            'comment_id':str(rpid),'url':'https://www.bilibili.com/video/'+bvid,
            'note_url':'https://www.bilibili.com/video/'+bvid,'text':text,'title':text[:100],
            'author':_text(member.get('uname',''),300),'author_id':str(mid),'region':'',
            'published_at':_stamp(item.get('ctime')),'parent_id':'','comment_level':1,
            'stage':'待核实评论'}

def project(payload, *, operation, page, limit, reference='', expected_uid='', keyword=None):
    """All-or-nothing source projection; transport facts never grant access."""
    _need(operation in ('search','comments') and type(page) is int and 1<=page<=50
          and type(limit) is int and 1<=limit<=20 and isinstance(expected_uid,str))
    if expected_uid:_need(str(_number(expected_uid))==expected_uid)
    _need(type(payload) is dict and payload.get('schema_version')==1 and type(payload['schema_version']) is int
          and payload.get('ok') is True and payload.get('platform')=='bilibili'
          and payload.get('operation')==operation and payload.get('requested_page')==page
          and type(payload.get('requested_page')) is int and payload.get('requested_limit')==limit
          and type(payload.get('requested_limit')) is int and payload.get('actor_uid')==expected_uid)
    try:_need(len(json.dumps(payload,ensure_ascii=False,allow_nan=False).encode('utf-8'))<=MAX_BYTES)
    except (ValueError,TypeError,OverflowError,RecursionError):raise BilibiliContractError('B站结果边界无效') from None
    raw=payload.get('raw');_need(type(raw) is dict)
    if operation=='search':
        if keyword is not None:_need(payload.get('requested_keyword')==keyword)
        data=raw.get('search');_need(type(data) is dict and type(data.get('page')) is int and data['page']==page)
        total=_number(data.get('numResults'),zero=True)
        pages=_number(data.get('numPages'),zero=True)
        source=data.get('result');_need(type(source) is list and len(source)<=20 and total>=len(source))
        _need(pages>=page or not source and pages==0)
        rows=[_note(item) for item in source]
        more=pages>page
    else:
        bvid=_bvid(reference)
        video,data=raw.get('video'),raw.get('comments')
        _need(type(video) is dict and video.get('bvid')==bvid and type(data) is dict)
        aid=_number(video.get('aid'))
        _need(type(data.get('page')) is int and data['page']==page
              and type(data.get('page_size')) is int and data['page_size']==20)
        total=_number(data.get('count'),zero=True)
        source=data.get('replies');_need(type(source) is list and len(source)<=20 and total>=len(source))
        rows=[_comment(item,bvid,aid) for item in source]
        more=page*20<total
    keys=[row.get('comment_id') or row['source_id'] for row in rows]
    _need(len(keys)==len(set(keys)))
    # A single request reads at most one page. Never expand embedded replies.
    # A deliberately truncated page cannot truthfully declare the source ended.
    return rows[:limit],{'has_more':None if len(rows)>limit else more,'bounded':True,'cursor':''}


_COOKIE_KEYS=frozenset(('SESSDATA','bili_jct','DedeUserID','DedeUserID__ckMd5','sid','buvid3','buvid4'))

def owned_credential(value):
    """Explicit Bili input only; no browser discovery or arbitrary cookie keys."""
    _need(type(value) is dict and bool(value) and not set(value)-_COOKIE_KEYS)
    _need(all(type(k) is str and type(v) is str and 1<=len(v)<=8192
              and all(33<=ord(c)<=126 and c not in ';,' for c in v)
              for k,v in value.items()))
    _need(bool(value.get('SESSDATA')))
    if 'DedeUserID' in value:_need(str(_number(value['DedeUserID']))==value['DedeUserID'])
    raw=json.dumps(value,ensure_ascii=False,allow_nan=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    _need(len(raw)<=65536)
    return raw

def owned_credential_input(raw):
    _need(type(raw) is bytes and 1<=len(raw)<=65536)
    def pairs(items):
        value={}
        for key,item in items:
            _need(key not in value);value[key]=item
        return value
    try:value=json.loads(raw,object_pairs_hook=pairs)
    except (ValueError,TypeError,UnicodeError):raise BilibiliContractError('B站本人配置输入无效') from None
    _need(owned_credential(value)==raw)
    return value

def project_owned_identity(payload, expected_uid=''):
    """Platform nav facts only; neither a grant nor an account-ready claim."""
    _need(type(expected_uid) is str)
    if expected_uid:_need(str(_number(expected_uid))==expected_uid)
    _need(type(payload) is dict and set(payload)=={'ok','schema_version','platform','operation','raw','actor_uid','nickname'}
          and payload['ok'] is True and type(payload['schema_version']) is int and payload['schema_version']==1
          and payload['platform']=='bilibili' and payload['operation']=='self')
    raw=payload['raw'];_need(type(raw) is dict and set(raw)=={'isLogin','mid','uname'} and raw['isLogin'] is True)
    uid=str(_number(raw['mid']));nickname=_text(raw['uname'],160)
    _need(not any(ord(c)<32 or ord(c)==127 for c in nickname))
    _need(payload['actor_uid']==uid and payload['nickname']==nickname and (not expected_uid or uid==expected_uid))
    return uid,nickname
