"""Owned managed live child jobs over the existing Store/account profile.

Preparing is local only. Opening requires explicit room/account confirmation,
the original device guard and original account-mode lease. No parent rebinding.
"""
from pathlib import Path
import json,os,subprocess,time
from .livestream_admission import LivestreamAdmission,fail,digest,get,put,stamp,binding,number,REQUEST

JOBS='livestream_managed_window_jobs_v1'
def checked_directory(path,base):
 path=Path(path);base=Path(base).absolute()
 if not path.absolute().is_relative_to(base):fail('LIVE_WINDOW_PATH_INVALID','直播窗口资料位置不属于当前账号',409)
 current=base
 if base.exists() and (base.is_symlink() or getattr(base.lstat(),'st_file_attributes',0)&0x400):fail('LIVE_WINDOW_PATH_INVALID','工作台资料位置不能使用目录链接',409)
 for part in path.absolute().relative_to(base).parts:
  current=current/part
  if current.exists():
   st=current.lstat()
   if current.is_symlink() or getattr(st,'st_file_attributes',0)&0x400 or not current.is_dir():fail('LIVE_WINDOW_PATH_INVALID','直播窗口资料位置不能使用目录链接或其他文件',409)
 return path

class ManagedLivestreamWindows:
 def __init__(self,core,visible=None):self.core=core;self.handles={};self.admission=LivestreamAdmission(core);self.visible=visible or (lambda p:False)
 def _paths(self,user,account):
  base=self.core.store.directory;directory=checked_directory(base/'accounts'/user['tenant_id']/account['id']/'managed-live-window',base)
  profile=checked_directory(base/'accounts'/user['tenant_id']/account['id']/'managed-window/profile',base)
  source=Path(__file__).resolve().parents[1];runtime=source.parent/'work/runtime/douyin-bridge'
  return directory,profile,source,runtime
 def prepare(self,user,store,account,authority):
  with self.core.store.connect() as db:self.admission._actor(db,user,store,authority,account)
  directory,profile,source,runtime=self._paths(user,account)
  ready=all(p.is_file() for p in (source/'managed_live_window.py',source/'managed_platform_window.py',runtime/'lib/livestream/page_observer.cjs',runtime/'scripts/douyin-live.user.js'))
  if ready:
   from managed_live_window import checked_source
   checked_source(runtime/'lib/livestream/page_observer.cjs','observer');checked_source(runtime/'scripts/douyin-live.user.js','control')
  return {'state':'prepared' if ready else 'missing_components','accountId':account['id'],'accountName':account.get('platform_nickname') or account.get('name') or '当前抖音账号','automaticLogin':False,'opensOnlyAfterConfirmation':True,'documentCreatedRequired':True,'realNativeFirstUseVerified':False,'message':'已检查本机直播窗口组件；确认房间后软件可打开独立子窗，需本人核对平台登录。准备不会打开网页或改父窗口。' if ready else '本机直播窗口组件不完整，请使用完整版本；没有打开平台。'}
 def _view(self,row):
  value={k:row[k] for k in ('requestId','accountId','accountName','webRid','state','code','message') if k in row};value.update(windowOpen=False,platformLoginConfirmed=False,accountConfirmed=False)
  handle=self.handles.get(row['id']);path=Path(row['statePath'])
  if path.is_file():
   if path.stat().st_size>8192:fail('LIVE_WINDOW_STATE_INVALID','原直播窗口回执超出范围，请保留原编号',409)
   state=json.loads(path.read_text('utf-8'))
   if any(state.get(k)!=row.get(k) for k in ('requestId','accountId','webRid')):fail('LIVE_WINDOW_STATE_INVALID','原直播窗口回执归属变化，请保留原编号',409)
   value.update({k:state[k] for k in ('state','code','pageLoaded','documentCreatedRegistered','connId') if k in state})
  if handle and handle.poll() is not None and value.get('state') not in ('closed','failed'):value.update(state='closed',windowOpen=False)
  # An OS process or page-loaded callback is not proof of natural account UID.
  value.update(platformLoginConfirmed=False,accountConfirmed=False)
  value.update(windowOpen=bool(handle and self.visible(handle)),windowEvidence='visible_owned_child_window' if handle and self.visible(handle) else 'owned_child_not_visible')
  return value
 def read(self,user,store,account,request,authority):
  if not isinstance(request,str) or not REQUEST.fullmatch(request):fail('LIVE_INPUT_INVALID','请保留原直播窗口编号',400)
  key=digest(['live-managed',user['tenant_id'],user['id'],request])
  with self.core.store.connect() as db:
   self.admission._actor(db,user,store,authority);row=get(db,JOBS,key,user['tenant_id'])
   if row is None:return {'state':'not_started','requestId':request,'windowOpen':False,'accountConfirmed':False,'message':'未找到原直播窗口打开回执；不会自动重开'}
   if row.get('storeId')!=store or row.get('ownerId')!=user['id']:fail('LIVE_SCOPE_FORBIDDEN','直播窗口编号不属于当前员工和门店',403)
  return self._view(row)
 def open(self,user,store,account,data,authority,guard):
  if set(data)!={'storeId','accountId','webRid','requestId','confirmed'} or data.get('confirmed') is not True or not number(data.get('webRid')) or not isinstance(data.get('requestId'),str) or not REQUEST.fullmatch(data['requestId']):fail('LIVE_WINDOW_CONFIRM_REQUIRED','请明确确认本人账号和要打开的直播房间',400)
  key=digest(['live-managed',user['tenant_id'],user['id'],data['requestId']]);signature=digest([data,binding(account)])
  with self.core.store.connect() as db:
   self.admission._actor(db,user,store,authority,account);old=get(db,JOBS,key,user['tenant_id'])
   if old:
    if old.get('signature')!=signature:fail('LIVE_WINDOW_REQUEST_CHANGED','原直播窗口打开编号的条件已变化',409)
    return self._view(old)
  guard();owner='live-window:'+key;self.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',owner)
  try:
   guard()
   if self.prepare(user,store,account,authority)['state']!='prepared':fail('LIVE_WINDOW_COMPONENT_MISSING','直播窗口组件不完整，本次未打开平台',409)
   directory,profile,source,runtime=self._paths(user,account)
   config=self.core.store.directory/'bridge'/user['tenant_id']/'config.json'
   if not config.is_file():fail('LIVE_PARENT_CONNECTION_REQUIRED','请先在账号页准备原抖音连接；本次未打开直播窗口',409)
   directory.mkdir(parents=True,exist_ok=True);profile.mkdir(parents=True,exist_ok=True);state_path=directory/(key+'.state.json');spec_path=directory/(key+'.json')
   spec={'window_kind':'livestream-child/1','platform':'douyin','requestId':data['requestId'],'accountId':account['id'],'accountName':account.get('platform_nickname') or account.get('name') or '当前抖音账号','webRid':data['webRid'],'config':str(config),'profile':str(profile),'statePath':str(state_path),'observer':str(runtime/'lib/livestream/page_observer.cjs'),'control':str(runtime/'scripts/douyin-live.user.js')}
   with self.core.store.connect() as db:
    db.execute('BEGIN IMMEDIATE');self.admission._actor(db,user,store,authority,account);old=get(db,JOBS,key,user['tenant_id'])
    if old:
     if old.get('signature')!=signature:fail('LIVE_WINDOW_REQUEST_CHANGED','原窗口编号已变化',409)
     return self._view(old)
    row={'id':key,'tenant_id':user['tenant_id'],'ownerId':user['id'],'storeId':store,'accountId':account['id'],'accountName':spec['accountName'],'webRid':data['webRid'],'requestId':data['requestId'],'signature':signature,'state':'opening','statePath':str(state_path),'createdAt':stamp(),'message':'已提交独立直播子窗打开请求；页面、脚本与登录均需核对，不能据此开始采集'};put(db,JOBS,row)
   spec_path.write_text(json.dumps(spec,ensure_ascii=False),'utf-8');guard()
   from account_connections import managed_window_argv
   with (directory/(key+'.log')).open('ab') as log:
    handle=subprocess.Popen(managed_window_argv(spec_path),stdout=log,stderr=log,stdin=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   self.handles[key]=handle
   return self._view(row)
  finally:self.core.release_account_mode(account['id'],user['tenant_id'],owner)
