"""Explicit one-reply WebView2 attempt behind existing Fangyu send gates.

The operator types in the owned page. This service never submits a platform
request; it durably freezes an approved attempt before the page is opened.
"""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
import re
import stat
import subprocess
import threading
import time
from urllib.parse import urlsplit
from uuid import uuid4

from core import CoreError
from core.engine import now
from core.adapters import AdapterSafetyRequired,account_execution_lock
from core.continuous import ACTIVE, process_alive
from core.review_queue import require_reply_permission,snapshot as reply_snapshot
from .browser_login_service import _profile_scope
from .business import xiaohongshu_held
from .owned_helper_process import tracked_reply_helper_argv
from .tracked_reply_window import ReplyWindowSpec, _note_url


_COMMENT_ID=re.compile(r'[A-Za-z0-9_-]{1,256}\Z')


def _staging_scope(store_dir,account_dir,staging):
    try:
        store=Path(store_dir).absolute();account=Path(account_dir).absolute()
        job=Path(staging).absolute()
        if (job.parent!=account/'work'/'tracked-reply' or
                account.parent.parent.parent!=store or not re.fullmatch(r'[0-9a-f]{32}',job.name)):
            return False
        for path in (store,store/'accounts',account.parent,account,account/'work',
                     job.parent,job):
            if path.is_symlink() or (hasattr(path,'is_junction') and path.is_junction()):
                return False
            if path.exists() and getattr(os.lstat(path),'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):
                return False
        return job.resolve(strict=False).parent==(account/'work'/'tracked-reply').resolve(strict=False)
    except (OSError,ValueError,RuntimeError):return False


class TrackedReplyService:
    wait_seconds=30
    window_seconds=300

    def __init__(self,server,*,launcher=None,worker_factory=None):
        self.server=server
        self.launcher=launcher or subprocess.Popen
        self.worker_factory=worker_factory or threading.Thread
        self.lock=threading.RLock()
        self.jobs={}
        self.threads={}
        self.stop_event=threading.Event()

    def _operator(self,user):
        from .employee_workspace import require_owner
        own=require_owner(self.server,user)
        assistant=self.server.assistant_service
        with assistant.lock:
            executor,state,device=assistant.executor,assistant.state,assistant.device or {}
        if (state!='online' or executor is None or
                device.get('id')!=own['device_id'] or device.get('owner')!=user.get('username') or
                getattr(executor,'owner',None)!=user.get('username') or
                getattr(executor,'tenant',None)!=user.get('tenant_id')):
            raise CoreError('本机助手未确认在线，网页回复已停止')
        command={'owner':user['username'],'principal':{'username':user['username'],
                 'role':user['role']},'action':'reply_send','data':{}}
        principal=executor.principal(command,read_only=True)
        if principal['id']!=user['id'] or principal.get('can_reply') is False:
            raise CoreError('本机员工回复权限未确认')
        return executor,principal,own['device_id']

    def _context(self,user,data):
        if (set(data) not in ({'reply_id','account_id','authorized'},
                              {'reply_id','account_id','authorized','reply_trial'}) or
                data.get('authorized') is not True or
                not all(isinstance(data.get(key),str) and data[key] for key in ('reply_id','account_id'))):
            raise CoreError('请逐条确认已审核回复和执行账号')
        executor,principal,device_id=self._operator(user)
        core=self.server.core;tenant=user['tenant_id']
        if xiaohongshu_held(self.server):
            raise CoreError('小红书平台操作当前暂停，受控网页回复未启动')
        with core.lock:
            reply=core._get('replies',data['reply_id'],tenant)
            lead=core._get('leads',reply['lead_id'],tenant)
            executor._lead_access(principal,lead)
            account=core._get('accounts',data['account_id'],tenant)
            core._account_access(principal,account)
            # This guard runs before pausing collection or touching a profile.
            # Current public/QA hold must stop here, even with a trial proof.
            core._public_reply_guard(lead.get('platform'),
                (principal,reply,reply_snapshot(core,reply,lead,account,user=user),data.get('reply_trial')))
            if account.get('platform')!='xiaohongshu' or reply.get('channel','comment')!='comment':
                raise CoreError('受控网页窗口仅支持小红书评论回复')
            self._manual_preflight(principal,reply,lead,account,data.get('reply_trial'))
            executor._claim_xhs_account(account)
            routing_lead=core._resolved_reply_lead(lead,'comment',user=principal,account=account)
            note_url=routing_lead.get('note_url') or ''
            note_id=urlsplit(note_url).path.rsplit('/',1)[-1]
            if not _note_url(note_url,note_id):raise CoreError('原帖链接不能用于受控网页回复')
            owner=core._contact_owner(lead,principal,tenant)
            spec=ReplyWindowSpec(tenant,owner,device_id,account['id'],
                                 account['platform_uid'],note_id,routing_lead.get('comment_id') or '',
                                 reply['text'])
            account_dir=core.store.directory/'accounts'/tenant/account['id']
            profile=account_dir/'xhs-browser-profile'
            if not _profile_scope(core.store.directory,account_dir,profile) or not profile.is_dir():
                raise CoreError('本机账号网页资料尚未就绪')
            return principal,reply,lead,account,spec,note_url,profile

    def _manual_preflight(self,user,reply,lead,account,trial_proof):
        """The Core send gates, excluding only the CLI reply contract.

        The owned browser has no CLI send call. Keep all customer, account,
        approval, quota, time, activity and trial restrictions explicit here.
        """
        core=self.server.core;tenant=user['tenant_id']
        core.require_platform(lead.get('platform'))
        core._public_reply_guard(lead.get('platform'),
            (user,reply,reply_snapshot(core,reply,lead,account,user=user),trial_proof))
        try:require_reply_permission(core,user,lead)
        except ValueError as exc:raise CoreError(str(exc)) from exc
        if reply.get('status')!='approved' or reply.get('channel','comment')!='comment':
            raise CoreError('仅已审核、未发送的评论回复可打开受控网页窗口')
        core._check_reply_recipient(reply,lead,user=user,account=account)
        core._validate_reply_text(reply['text'])
        core._employee_quota(user,tenant)
        if any(other['id']!=reply['id'] and other.get('lead_id')==lead['id'] and
               other.get('status') in ('sending','sent','unknown')
               for other in core.store.list('replies',tenant)):
            raise CoreError('该线索已有发送记录，禁止重复发送')
        core._account_access(user,account)
        if (lead.get('platform')!='xiaohongshu' or account.get('platform')!='xiaohongshu'
                or account.get('status')!='ready'):
            raise CoreError('小红书账号未就绪或与评论平台不匹配')
        core._require_customer_xhs_identity(account,tenant)
        if reply.get('approval_snapshot')!=reply_snapshot(core,reply,lead,account,user=user):
            raise CoreError('已审核内容、来源或执行账号已改变，请重新审核')
        routing_lead=core._resolved_reply_lead(lead,'comment',user=user,account=account)
        if lead.get('demo') or not routing_lead.get('comment_id') or not routing_lead.get('note_url'):
            raise CoreError('演示线索或缺少原评论来源，不能外部回复')
        task=core._get('tasks',lead['task_id'],tenant) if lead.get('task_id') else {}
        if task.get('status')=='paused' and task.get('pause_reason') not in ('user_continuous','user_reply_switch'):
            raise CoreError('原任务已暂停，不能发送')
        current=datetime.now().strftime('%H:%M');start=task.get('time_start','00:00');end=task.get('time_end','23:59')
        if not (start<=current<=end if start<=end else current>=start or current<=end):
            raise CoreError('当前不在运行时段')
        today=datetime.now().date().isoformat()
        used=sum(1 for item in core.store.list('replies',tenant)
                 if item.get('account_id')==account['id'] and
                 item.get('status') in ('sending','sent','unknown') and
                 item.get('attempted_at','').startswith(today))
        if used>=int(account.get('daily_send_limit') or 20):
            raise CoreError('该账号今日发送额度已用完')
        directory=core.store.directory/'accounts'/tenant/account['id']
        try:core.adapters.require_account_safe('xiaohongshu',directory)
        except AdapterSafetyRequired as exc:raise CoreError(str(exc)) from None
        return task

    def start(self,user,data):
        if self.stop_event.is_set() or self.server.closing:
            raise CoreError('软件正在退出，网页回复未启动')
        principal,reply,lead,account,spec,note_url,profile=self._context(user,data)
        core=self.server.core;tenant=principal['tenant_id']
        with self.lock:
            if any(job['status'] in ('awaiting_collection','opening','observing') and
                   job['account_id']==account['id'] for job in self.jobs.values()):
                raise CoreError('该账号已有一条网页回复正在进行')
            job_id=uuid4().hex
            job={'id':job_id,'reply_id':reply['id'],'account_id':account['id'],
                 'owner':principal['username'],'tenant_id':tenant,
                 'status':'awaiting_collection','message':'正在等待本批采集结束',
                 'started_at':time.time(),'outcome':'','platform_comment_id':''}
            self.jobs[job_id]=job
        try:
            with core.lock:
                for task in core.store.list('tasks',tenant):
                    if task.get('account_id')!=account['id']:continue
                    continuous=core.continuous.status(task)
                    if continuous.get('status') in ACTIVE or continuous.get('inflight'):
                        core._task_access(principal,task,tenant)
                        core.continuous.pause(task,reason='user_reply_switch',
                            message='已暂停采集；等待本批结束后打开回复窗口')
                    elif task['id'] in core.running:
                        core._task_access(principal,task,tenant)
                        task.update(status='paused',pause_reason='user_reply_switch',
                                    last_message='已切换回复模式，等待本批结束')
                        core.store.put('tasks',task)
            thread=self.worker_factory(target=self._run,args=(job_id,principal,data,spec,note_url,profile),
                                    name='tracked-reply-'+job_id[:8],daemon=True)
            with self.lock:self.threads[job_id]=thread
            thread.start()
        except Exception:
            with self.lock:self.jobs.pop(job_id,None)
            raise
        return self.status(user,job_id)

    def close(self,timeout=8):
        """Stop only helpers started here; an in-flight attempt becomes unknown."""
        self.stop_event.set()
        with self.lock:threads=list(self.threads.values())
        deadline=time.monotonic()+timeout
        for thread in threads:
            if thread is threading.current_thread():continue
            join=getattr(thread,'join',None)
            if callable(join):join(timeout=max(0,deadline-time.monotonic()))

    def status(self,user,job_id):
        if not isinstance(job_id,str) or not re.fullmatch(r'[0-9a-f]{32}',job_id):
            raise CoreError('网页回复任务编号无效')
        self._operator(user)
        with self.lock:
            job=self.jobs.get(job_id)
            if not job or (job['owner'],job['tenant_id'])!=(user['username'],user['tenant_id']):
                raise CoreError('网页回复任务不存在')
            return {key:job[key] for key in ('id','reply_id','account_id','status','message',
                                              'outcome','platform_comment_id')}

    def _set(self,job_id,**values):
        with self.lock:self.jobs[job_id].update(values)

    def _run(self,job_id,user,data,spec,note_url,profile):
        core=self.server.core;tenant=user['tenant_id'];account_id=spec.account_id
        lease_owner='tracked-reply:'+job_id
        leased=False;started=False;account_dir=profile.parent
        result={'outcome':'unknown','reason':'window_unverified'}
        try:
            deadline=time.monotonic()+self.wait_seconds
            while True:
                if self.stop_event.is_set() or self.server.closing:
                    self._set(job_id,status='stopped',message='软件正在退出，未打开网页回复窗口')
                    return
                with core.lock:
                    jobs=[core.continuous.status(task) for task in core.store.list('tasks',tenant)
                          if task.get('account_id')==account_id]
                    busy=any(job.get('inflight') for job in jobs)
                    busy=busy or any(task.get('account_id')==account_id and task['id'] in core.running
                                     for task in core.store.list('tasks',tenant))
                    mode=core.account_mode_status(account_id,tenant)
                    busy=busy or (mode.get('status')=='active' and process_alive(mode.get('pid'))
                                  and mode.get('mode')=='collection')
                if not busy:break
                if time.monotonic()>=deadline:
                    self._set(job_id,status='stopped',message='本批采集尚未结束；没有打开网页回复窗口')
                    return
                time.sleep(.2)
            with account_execution_lock(account_dir):
                with core.lock:
                    if self.stop_event.is_set() or self.server.closing:
                        raise CoreError('软件正在退出，网页回复未启动')
                    reply=core._get('replies',data['reply_id'],tenant)
                    lead=core._get('leads',reply['lead_id'],tenant)
                    account=core._get('accounts',account_id,tenant)
                    # Revalidate the short trial grant, account and approved
                    # snapshot after the collection wait and profile lock.
                    self._manual_preflight(user,reply,lead,account,data.get('reply_trial'))
                    routing_lead=core._resolved_reply_lead(lead,'comment',user=user,account=account)
                    if (reply['text']!=spec.expected_content or account.get('platform_uid')!=spec.account_uid
                            or routing_lead.get('comment_id')!=spec.target_comment_id or routing_lead.get('note_url')!=note_url):
                        raise CoreError('已审核回复或原评论发生变化，请重新确认')
                    core.acquire_account_mode(account_id,tenant,'replies',lease_owner);leased=True
                    reply.update(status='sending',attempted_at=now(),
                                 attempted_by=user['id'],account_id=account_id,idempotency_key=reply['id'])
                    audit=core._record({'actor':user['username'],'action':'manual_web_send_attempt',
                                        'detail':reply['id']},tenant)
                    records=[('replies',reply),('audit',audit)]
                    if (core.deployment_config.get('runtime') or {}).get('platform_qa_device_id'):
                        records.append(core.reply_trial.attempt(tenant,reply['id']))
                    core._contact_record('send_started',user,tenant,lead,reply,account,records)
                    started=True
                self._set(job_id,status='opening',message='已记录本次发送尝试，正在打开受控网页窗口')
                result=self._observe(job_id,spec,note_url,profile)
        except Exception as exc:
            if not started:
                self._set(job_id,status='stopped',message=str(exc))
                return
            result={'outcome':'unknown','reason':'window_unverified'}
        finally:
            try:
                if started:self._finish(job_id,user,result)
            finally:
                if leased:core.release_account_mode(account_id,tenant,lease_owner)

    def _observe(self,job_id,spec,note_url,profile):
        account_dir=profile.parent
        staging=account_dir/'work'/'tracked-reply'/job_id
        if (staging.exists() or not _profile_scope(self.server.core.store.directory,account_dir,profile)
                or not _staging_scope(self.server.core.store.directory,account_dir,staging)):
            return {'outcome':'unknown','reason':'staging_invalid'}
        staging.mkdir(parents=True,mode=0o700)
        if not _staging_scope(self.server.core.store.directory,account_dir,staging):
            return {'outcome':'unknown','reason':'staging_invalid'}
        source={'scope':{key:getattr(spec,key) for key in ReplyWindowSpec.__dataclass_fields__},
                'note_url':note_url,'profile_dir':str(profile)}
        spec_path=staging/'spec.json'
        with spec_path.open('x',encoding='utf-8') as stream:
            json.dump(source,stream,ensure_ascii=False,separators=(',',':'))
            stream.flush();os.fsync(stream.fileno())
        command=tracked_reply_helper_argv(spec_path)
        proc=self.launcher(list(command.argv),shell=False,stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           cwd=command.cwd,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),
                           env=dict(os.environ))
        self._set(job_id,status='observing',message='请在受控窗口中仅提交已审核的回复')
        deadline=time.monotonic()+self.window_seconds+10
        while proc.poll() is None:
            if time.monotonic()>=deadline or self.server.closing or self.stop_event.is_set():
                proc.terminate()
                try:proc.wait(timeout=3)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
                return {'outcome':'unknown','reason':'window_timeout'}
            time.sleep(.2)
        marker=staging/'outcome.json'
        try:
            if proc.returncode!=0 or marker.is_symlink() or marker.stat().st_size>1024:
                raise ValueError()
            outcome=json.loads(marker.read_text(encoding='utf-8'))
            if (not isinstance(outcome,dict) or set(outcome)!={'outcome','platform_comment_id','snapshot_hash','reason'}
                    or outcome['outcome'] not in ('sent','unknown')
                    or outcome['outcome']=='sent' and (not _COMMENT_ID.fullmatch(outcome['platform_comment_id'])
                       or not re.fullmatch(r'[0-9a-f]{64}',outcome['snapshot_hash']))):
                raise ValueError()
            return outcome
        except (OSError,ValueError,TypeError):
            return {'outcome':'unknown','reason':'helper_unverified'}

    def _finish(self,job_id,user,result):
        core=self.server.core;tenant=user['tenant_id']
        sent=result.get('outcome')=='sent'
        with core.lock:
            reply=core._get('replies',self.jobs[job_id]['reply_id'],tenant)
            lead=core._get('leads',reply['lead_id'],tenant)
            account=core._get('accounts',self.jobs[job_id]['account_id'],tenant)
            if reply.get('status')!='sending':
                self._set(job_id,status='stopped',message='本机回复状态已改变，需人工核实')
                return
            records=[]
            if sent:
                reply.update(status='sent',sent_at=now(),
                             sent_by=user['id'],platform_reply_id=result['platform_comment_id'])
                lead['reply_status']='sent';records.append(('leads',lead))
            else:
                reply.update(status='unknown',last_error='受控网页回复结果未能核实')
                account['status']='check_required';records.append(('accounts',account))
                if lead.get('task_id'):
                    task=core._get('tasks',lead['task_id'],tenant)
                    task.update(status='paused',last_message='网页回复结果不明，请人工核实')
                    records.append(('tasks',task))
            audit=core._record({'actor':user['username'],'action':'manual_web_send_result',
                                'detail':{'id':reply['id'],'status':reply['status']}},tenant)
            records=[('replies',reply),*records,('audit',audit)]
            try:core._contact_record('sent' if sent else 'unknown',user,tenant,lead,reply,account,records)
            except Exception:
                core.store.put_records(records)
                self._set(job_id,status='stopped',message='回复结果已本机保存，但联系记录写入失败，请核实')
                return
        self._set(job_id,status='completed' if sent else 'stopped',
                  outcome='sent' if sent else 'unknown',
                  platform_comment_id=result.get('platform_comment_id','') if sent else '',
                  message='平台明确成功，已保存本机记录' if sent else '结果不明，已停止；请人工核实')
