"""Fail-closed native maintenance candidate, without an application host.

There is no proved Service-free natural-browser deployment authority today.
The public entry therefore never launches. The private owned segment has no
live launcher; isolated tests can exercise the existing proof/argv/cancel path.
"""
from contextlib import closing
from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import stat
import sys
import threading
import time

from core.account_safety import summarize_activity
from core.adapters import account_execution_lock
from .browser_login_service import _profile_scope, _staging_scope
from .login_natural_proof import create_spec, verified_status
from .owned_helper_process import login_helper_argv, read_login_outcome
from .service import DeviceVault

PROJECT = Path(__file__).resolve().parents[4]
PURPOSE = 'inspect_original_browser_identity'
CONTRACT = 'original_browser_identity_maintenance_candidate_v1'
_ACCOUNT = re.compile(r'[a-f0-9]{32}\Z')
_COMPONENT = re.compile(r'[A-Za-z0-9_-]{1,128}\Z')


class OriginalBrowserIdentityMaintenanceError(ValueError):
    def __init__(self, code):
        self.code = 'ORIGINAL_BROWSER_IDENTITY_' + code
        super().__init__(self.code)


def _deny(code):
    raise OriginalBrowserIdentityMaintenanceError(code)


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _checked_path(path):
    path = Path(path).absolute()
    for part in (path, *path.parents):
        if part.is_symlink() or (part.exists() and
                getattr(part.lstat(), 'st_file_attributes', 0) & 0x400):
            _deny('PATH_UNAVAILABLE')
    return path


def _bytes(path, limit):
    path = _checked_path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= limit:
        _deny('METADATA_UNAVAILABLE')
    return path.read_bytes()


class NativeOriginalBrowserBootstrap:
    """Fixed native paths, no caller configuration, no constructor I/O."""
    def _native_local(self):
        source = PROJECT / 'work/product-upgrade-20261009/phase21_native_original_account_metadata.py'
        specification = importlib.util.spec_from_file_location('_original_identity_native_metadata', source)
        module = importlib.util.module_from_spec(specification)
        old = sys.dont_write_bytecode
        try:
            specification.loader.exec_module(module)
        finally:
            sys.dont_write_bytecode = old
        return module.native_local_appdata()

    def _company_path(self):
        # Candidate source identity only; this is not a running deployment.
        return PROJECT / 'work/app/company.json'

    def _vault_read(self, data, environment, company):
        return DeviceVault(data / 'assistant', environment, company).read()

    @staticmethod
    def _authorizer(action, *_):
        return sqlite3.SQLITE_OK if action in (sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ,
            sqlite3.SQLITE_FUNCTION, sqlite3.SQLITE_TRANSACTION) else sqlite3.SQLITE_DENY

    def snapshot(self, account_id):
        """Only metadata columns; no Cookie, password, content or key columns."""
        if not isinstance(account_id, str) or not _ACCOUNT.fullmatch(account_id):
            _deny('INVALID_REQUEST')
        local = _checked_path(self._native_local())
        if not local.is_dir() or 'Packages' in local.parts:
            _deny('NATIVE_DATA_UNAVAILABLE')
        data = _checked_path(local / 'fangyu-apartment-clientAssistant')
        if data.resolve().parent != local.resolve() or not data.is_dir():
            _deny('NATIVE_DATA_UNAVAILABLE')
        company_bytes = _bytes(self._company_path(), 262144)
        company = json.loads(company_bytes)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        environment = managed.get('environment_id') if isinstance(managed, dict) else None
        if (company.get('id') != 'fangyu-apartment-client' or company.get('authMode') != 'managed'
                or not isinstance(environment, str) or not _COMPONENT.fullmatch(environment)):
            _deny('COMPANY_UNAVAILABLE')
        vault_path = _checked_path(data / 'assistant/device.dpapi')
        encrypted = _bytes(vault_path, 65536)
        saved = self._vault_read(data, environment, company['id'])
        device = saved.get('device') if isinstance(saved, dict) else None
        owner = device.get('owner') if isinstance(device, dict) else None
        if (saved.get('state') != 'bound' or saved.get('environment_id') != environment
                or saved.get('company_id') != company['id'] or device.get('revoked') is True
                or not isinstance(device.get('id'), str) or not _COMPONENT.fullmatch(device['id'])
                or not isinstance(owner, str) or not owner.strip() or len(owner) > 160):
            _deny('BINDING_UNAVAILABLE')
        tenant = 'cloud-' + hashlib.sha256((environment+'\n'+company['id']).encode()).hexdigest()[:24]
        user_id = hashlib.sha256((tenant+'\n'+owner).encode()).hexdigest()
        database = _checked_path(data / 'workspace.sqlite3')
        if not database.is_file():
            _deny('METADATA_UNAVAILABLE')
        for suffix in ('-wal', '-journal'):
            pending = _checked_path(Path(str(database)+suffix))
            if pending.exists() and pending.stat().st_size:
                _deny('DATABASE_INFLIGHT_UNKNOWN')
        with closing(sqlite3.connect(database.as_uri()+'?mode=ro&immutable=1', uri=True)) as db:
            db.execute('PRAGMA query_only=ON')
            db.set_authorizer(self._authorizer)
            db.execute('BEGIN')
            user = db.execute("SELECT id,tenant_id,json_extract(body,'$.username'),json_extract(body,'$.cloud_bound'),json_extract(body,'$.disabled'),json_extract(body,'$.id'),json_extract(body,'$.tenant_id') FROM records WHERE entity='users' AND id=?", (user_id,)).fetchone()
            account = db.execute("SELECT id,tenant_id,json_extract(body,'$.platform'),json_extract(body,'$.platform_uid'),json_extract(body,'$.cloud_owner'),json_extract(body,'$.status'),json_extract(body,'$.updated_at'),json_extract(body,'$.disabled'),json_extract(body,'$.id'),json_extract(body,'$.tenant_id') FROM records WHERE entity='accounts' AND id=?", (account_id,)).fetchone()
            if (not user or user[:3] != (user_id, tenant, owner) or user[3] != 1 or user[4]
                    or user[5:] != (user_id, tenant)):
                _deny('MEMBER_UNAVAILABLE')
            if (not account or account[:3] != (account_id, tenant, 'xiaohongshu')
                    or account[4] != owner or account[7] or not isinstance(account[3], str)
                    or not account[3] or len(account[3]) > 256 or account[8:] != (account_id, tenant)):
                _deny('ACCOUNT_UNAVAILABLE')
            count = db.execute("SELECT COUNT(*) FROM records WHERE entity='accounts' AND tenant_id=? AND json_extract(body,'$.platform')='xiaohongshu' AND json_extract(body,'$.platform_uid')=?", (tenant, account[3])).fetchone()[0]
            if count != 1:
                _deny('DUPLICATE_ACCOUNT_IDENTITY')
            tasks = db.execute("SELECT entity,id,json_extract(body,'$.inflight'),json_type(body,'$.inflight'),json_extract(body,'$.status'),json_extract(body,'$.sequence_status') FROM records WHERE entity IN ('tasks','continuous_tasks') AND tenant_id=? AND json_extract(body,'$.account_id')=? ORDER BY entity,id", (tenant, account_id)).fetchall()
            for task in tasks:
                if task[3] != 'false':
                    _deny('TASK_INFLIGHT' if task[3] == 'true' else 'TASK_INFLIGHT_UNKNOWN')
                if task[4] in ('running', 'queued') or task[5] in ('running', 'queued'):
                    _deny('TASK_INFLIGHT')
            mode = db.execute("SELECT tenant_id,json_extract(body,'$.status') FROM records WHERE entity='account_modes' AND id=?", (account_id,)).fetchone()
            if mode is not None and mode != (tenant, 'idle'):
                _deny('ACCOUNT_BUSY')
            db.commit()
        account_dir = _checked_path(data / 'accounts' / tenant / account_id)
        profile = _checked_path(account_dir / 'xhs-browser-profile')
        if not account_dir.is_dir() or not profile.is_dir() or not _profile_scope(data, account_dir, profile):
            _deny('ORIGINAL_PROFILE_UNAVAILABLE')
        activity = _checked_path(account_dir / 'platform-activity.jsonl')
        activity_bytes = activity.read_bytes() if activity.is_file() else b''
        if len(activity_bytes) > 8 * 1024 * 1024:
            _deny('ACTIVITY_UNAVAILABLE')
        safety = summarize_activity(activity)
        info = profile.stat()
        private = dict(company_hash=hashlib.sha256(company_bytes).hexdigest(),
            vault_hash=hashlib.sha256(encrypted).hexdigest(), device=device, user=user,
            account=account, tasks=tasks, mode=mode,
            activity_hash=hashlib.sha256(activity_bytes).hexdigest(),
            profile_identity=(str(profile.resolve()), info.st_dev, info.st_ino))
        return dict(data=data, account_dir=account_dir, profile=profile, uid=account[3],
            account_id=account_id, safety_state=safety['state'], fingerprint=_hash(private))


class OriginalBrowserIdentityMaintenance:
    def __init__(self, trusted_bootstrap):
        if type(trusted_bootstrap) is not NativeOriginalBrowserBootstrap:
            _deny('BOOTSTRAP_REQUIRED')
        self.bootstrap = trusted_bootstrap
        self._operation = threading.Lock()

    @staticmethod
    def _result(scope, state, *, mechanism=False, job=False, code=None):
        return dict(contract=CONTRACT, state=state, reason=code,
            observed_at=int(time.time()), mechanism_only=mechanism, public_entry_authorized=False,
            account_present=scope is not None,
            account_reference_hash=hashlib.sha256(scope['account_id'].encode()).hexdigest() if scope else None,
            identity_present=state == 'original_identity_observed',
            original_identity_matches=state == 'original_identity_observed',
            original_identity_hash=hashlib.sha256(scope['uid'].encode()).hexdigest() if state == 'original_identity_observed' else None,
            prior_risk_state=scope['safety_state'] if scope else None, risk_cleared=False,
            original_session_committed=False, database_modified=False, accounts_modified=False,
            tasks_modified=False, cli_requests_started=False, cloud_requests_started=False,
            provider_requests_started=False, platform_requests_started=False, auto_retry=False,
            job_created=job, profile_may_be_modified=job, lock_file_may_be_modified=job)

    def execute(self, data):
        if (not isinstance(data, dict) or set(data) != {'purpose', 'account_id'}
                or data.get('purpose') != PURPOSE or not isinstance(data.get('account_id'), str)
                or not _ACCOUNT.fullmatch(data['account_id'])):
            _deny('INVALID_REQUEST')
        try:
            scope = self.bootstrap.snapshot(data['account_id'])
            after = self.bootstrap.snapshot(data['account_id'])
            if scope['fingerprint'] != after['fingerprint']:
                _deny('SCOPE_CHANGED')
        except OriginalBrowserIdentityMaintenanceError as error:
            return self._result(None, 'blocked', code=error.code)
        except Exception:
            return self._result(None, 'blocked', code='ORIGINAL_BROWSER_IDENTITY_METADATA_UNAVAILABLE')
        # No present mature validator proves this deployment purpose. Neither
        # client data, a CLI review, nor a true callback can open this branch.
        return self._result(after, 'blocked', code='deployment_confirmation_unavailable')

    @staticmethod
    def _launch_owned(_command, _scope, _staging):
        _deny('DEPLOYMENT_CONFIRMATION_UNAVAILABLE')

    def _fresh(self, original):
        fresh = self.bootstrap.snapshot(original['account_id'])
        if fresh['fingerprint'] != original['fingerprint']:
            _deny('SCOPE_CHANGED')
        return fresh

    @staticmethod
    def _cancel(process, cancel):
        try:
            _checked_path(cancel).write_bytes(b'cancelled')
        except (OriginalBrowserIdentityMaintenanceError, OSError):
            pass  # A redirected job must not receive a file write.
        try:
            process.wait(timeout=3)
        except Exception:
            process.terminate()
            try:
                process.wait(timeout=3)
            except Exception:
                process.kill()
                process.wait(timeout=3)

    def _run_owned_candidate(self, account_id):
        """Private mechanism probe; default launcher rejects. Not a live API."""
        if not self._operation.acquire(blocking=False):
            _deny('OPERATION_BUSY')
        try:
            scope = self.bootstrap.snapshot(account_id)
            with account_execution_lock(scope['account_dir']):
                try:
                    result = self._owned_segment(scope)
                finally:
                    self._cleanup_owned()
                self._fresh(scope)
                return result
        finally:
            self._operation.release()

    def _owned_segment(self, scope):
        self._owned_scope = scope
        self._owned_process = None
        self._owned_staging = None
        self._fresh(scope)
        import secrets
        staging = scope['account_dir'] / 'work/browser-login' / secrets.token_hex(12)
        if not _staging_scope(scope['data'], scope['account_dir'], staging):
            _deny('PATH_UNAVAILABLE')
        staging.parent.mkdir(parents=True, exist_ok=True)
        staging.mkdir(mode=0o700, exist_ok=False)
        self._owned_staging = staging
        create_spec(staging, job_id=staging.name, bound_uid=scope['uid'])
        cancel = staging / 'cancel.flag'
        command = login_helper_argv(staging, cancel, scope['profile'], natural_identity=True)
        self._fresh(scope)
        process = self._launch_owned(command, deepcopy(scope), staging)
        self._owned_process = process
        deadline = time.monotonic() + 300
        while process.poll() is None:
            try:
                self._fresh(scope)
                if time.monotonic() >= deadline:
                    _deny('TIMEOUT')
            except Exception:
                self._cancel(process, cancel)
                raise
            time.sleep(.05)
        self._fresh(scope)
        outcome = read_login_outcome(staging)
        candidate = staging / '.xiaohongshu-cli/cookies.json'
        proof = verified_status(staging, candidate)
        self._fresh(scope)
        if (process.returncode != 0 or outcome != b'candidate_staged_natural_verified'
                or proof is None or proof['data']['user']['id'] != scope['uid']):
            _deny('CANDIDATE_UNVERIFIED')
        return self._result(scope, 'original_identity_observed', mechanism=True, job=True)

    def _cleanup_owned(self):
        scope = getattr(self, '_owned_scope', None)
        staging = getattr(self, '_owned_staging', None)
        process = getattr(self, '_owned_process', None)
        if process is not None and process.poll() is None and staging is not None:
            self._cancel(process, staging / 'cancel.flag')
        if staging is not None:
            # Every delete target is checked inside the one owned account.
            if _staging_scope(scope['data'], scope['account_dir'], staging) and staging.is_dir():
                shutil.rmtree(staging)
        self._owned_process = self._owned_staging = self._owned_scope = None
