"""Fixed source runner and owned stdio channel; no public IPC endpoint.

The parent owns the real Adapters process/job/shutdown registries, the original
account lock and collection lease. Only its fixed child pipes carry identity,
guard and original-post messages. Runtime entitlement is always checked by the
existing host, never accepted as a Boolean or client JSON field.
"""
from contextlib import contextmanager, ExitStack
from dataclasses import asdict
import json
import os
from pathlib import Path
from queue import Empty, Queue
import re
import secrets
import subprocess
import sys
import threading
import time

_MAX_FRAME = 2 * 1024 * 1024
_ACTIONS = {'binding', 'observe', 'handoff', 'search', 'comments'}


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate')
        result[key] = value
    return result


def _reject(_value):
    raise ValueError('nonfinite')


def _read(stream):
    data = stream.readline(_MAX_FRAME + 1)
    if not data or len(data) > _MAX_FRAME or not data.endswith(b'\n'):
        raise ValueError('frame')
    value = json.loads(data.decode('utf-8'), object_pairs_hook=_unique, parse_constant=_reject)
    if type(value) is not dict:
        raise ValueError('frame')
    return value


def _write(stream, value):
    data = _canonical(value) + b'\n'
    if len(data) > _MAX_FRAME:
        raise ValueError('frame')
    stream.write(data)
    stream.flush()


def fixed_runner_argv(*, probe=False):
    from assistant.owned_helper_process import weibo_helper_argv, OwnedHelperArgvError
    from assistant.owned_weibo_host import HostRouteStopped
    if type(probe) is not bool:
        raise HostRouteStopped('owned_weibo_arguments_invalid')
    try:return weibo_helper_argv(probe=probe)
    except OwnedHelperArgvError:
        raise HostRouteStopped('owned_weibo_source_runner_missing') from None


def _scope_dict(scope):
    value = asdict(scope)
    value['account_root'] = str(value['account_root'])
    return value


class _OwnedShutdown:
    """Retain same-thread lock contexts through exact owned-child completion."""
    def __init__(self, host, process, process_key, job_id, entry, initial,
                 account_context, channel_lock, reader):
        self.host, self.process = host, process
        self.process_key, self.job_id, self.entry, self.initial = process_key, job_id, entry, initial
        self.account_context, self.channel_lock, self.reader = account_context, channel_lock, reader
        self.owner_thread, self.done = threading.get_ident(), False

    def _confirmed(self):
        if self.process is None:
            return True
        try: return self.process.poll() is not None
        except Exception: return False  # Unknown exit is never completion.

    def complete(self):
        from assistant.owned_weibo_host import HostRouteStopped
        if self.done:
            return
        if threading.get_ident() != self.owner_thread:
            raise HostRouteStopped('owned_weibo_shutdown_owner_thread_required')
        host, process, adapters = self.host, self.process, self.host._server.core.adapters
        pending = host._owned_shutdown_phase == 'exit_pending'
        while not self._confirmed():
            pending = True
            host._owned_shutdown_phase = 'exit_pending'
            # Original close may snapshot/clear registries before wait confirms
            # exit. Restore only our already-owned handle while it remains live.
            with adapters.lifecycle_lock:
                adapters.processes[self.process_key] = process
                adapters.process_accounts[self.process_key] = self.initial.account_root
                adapters.job_processes[self.job_id] = process
            try:
                process.wait(timeout=.2)
            except Exception:
                try: process.terminate(); process.wait(timeout=.2)
                except Exception:
                    try: process.kill(); process.wait(timeout=.2)
                    except Exception: pass
            if not self._confirmed():
                time.sleep(.2)  # Original helper completion cadence, no spin.
        # Nothing below can run while exit remains unconfirmed. All retained
        # contexts are released by their original owning thread, exactly once.
        cleanup_failed = False
        try:
            if process is not None:
                with adapters.lifecycle_lock:
                    if adapters.processes.get(self.process_key) is process:
                        adapters.processes.pop(self.process_key, None)
                        adapters.process_accounts.pop(self.process_key, None)
                    if adapters.job_processes.get(self.job_id) is process:
                        adapters.job_processes.pop(self.job_id, None)
                for stream in (process.stdin, process.stdout):
                    try: stream.close()
                    except Exception: cleanup_failed = True
            if self.reader is not None:
                self.reader.join(timeout=2)
        except Exception:
            cleanup_failed = True
        finally:
            try:
                if self.job_id is not None and self.entry is None:
                    host._server.core.release_account_mode(self.initial.account_id, self.initial.tenant_id, self.job_id)
            except Exception:
                cleanup_failed = True
            finally:
                try:
                    self.account_context.close()
                except Exception:
                    cleanup_failed = True
                finally:
                    try:
                        self.channel_lock.release()
                    except Exception:
                        cleanup_failed = True
                    finally:
                        self.done, host._owned_shutdown = True, None
                        if cleanup_failed:
                            host._owned_shutdown_phase = 'cleanup_unconfirmed'
                        elif pending:
                            host._owned_shutdown_phase = 'exit_confirmed_after_pending'
        if cleanup_failed:
            raise HostRouteStopped('owned_weibo_cleanup_unconfirmed') from None


class OwnedWeiboIPC:
    """Concrete original-parent channel, constructed only by the trusted host."""
    def __init__(self, host):
        from assistant.owned_weibo_host import HostRouteStopped, OwnedWeiboHostCandidate
        if type(host) is not OwnedWeiboHostCandidate:
            raise HostRouteStopped('owned_weibo_trusted_host_required')
        self.host = host

    def probe(self):
        # A diagnostic child cannot import a platform client, open a socket or
        # read credentials. Its sole request tests the CURRENT rejecting guard.
        return self._exchange('probe', {}, probe=True)

    def binding(self, receipt_id):
        return self._exchange('binding', {'identity_receipt_id': receipt_id})

    def observe(self):
        return self._exchange('observe', {})

    def handoff(self):
        from assistant.owned_weibo_host import HostRouteStopped
        # No caller fields: only this host's just-minted immutable transition.
        if self.host._registration_handoff is None:
            raise HostRouteStopped('owned_weibo_registration_handoff_invalid')
        return self._exchange('handoff', json.loads(self.host._registration_handoff))

    def read(self, operation, binding, receipt_id, *, keyword='', numeric_mid='', count=20):
        from assistant.owned_weibo_host import HostRouteStopped
        if operation not in ('search', 'comments'):
            raise HostRouteStopped('owned_weibo_arguments_invalid')
        return self._exchange(operation, {'identity_receipt_id': receipt_id,
            'keyword': keyword, 'numeric_mid': numeric_mid, 'count': count}, expected_binding=binding)

    @contextmanager
    def _job(self, scope):
        """Reuse the service's actual lease owner; otherwise own and release one."""
        from core.adapters import AdapterBusy
        from assistant.owned_weibo_host import HostRouteStopped
        reads, core = self.host._reads, self.host._server.core
        entry = None
        if reads is not None:
            if reads.core is not core or reads.tenant != scope.tenant_id:
                raise HostRouteStopped('owned_weibo_job_scope_invalid')
            with reads._lock:
                running = [entry for entry in reads._operations.values()
                    if entry.get('account_id') == scope.account_id and entry.get('running')]
                context = getattr(getattr(reads, '_owned_read_context', None), 'context', None)
                if context is None:
                    # A getter must not borrow any other thread's live _read,
                    # even before that read acquires its account OS lock.
                    if running:
                        raise AdapterBusy('微博同账号原读取正在执行')
                else:
                    if (type(context) is not tuple or len(context) != 2
                            or context[1] != threading.get_ident()
                            or type(context[0]) is not dict or len(running) != 1
                            or running[0] is not context[0] or context[0].get('cancelled')
                            or not any(value is context[0] for value in reads._operations.values())):
                        raise HostRouteStopped('owned_weibo_job_scope_invalid')
                    entry = context[0]
        job_id = entry['operation_id'] if entry else 'wb-ipc-' + secrets.token_hex(16)
        acquired = entry is None
        if acquired:
            core.acquire_account_mode(scope.account_id, scope.tenant_id, 'collection', job_id)
        else:
            lease = core.account_mode_status(scope.account_id, scope.tenant_id)
            if (lease.get('status') != 'active' or lease.get('mode') != 'collection'
                    or lease.get('owner') != job_id or lease.get('pid') != os.getpid()
                    or lease.get('runtime_id') != core.continuous.leases.runtime_id):
                raise HostRouteStopped('owned_weibo_job_scope_invalid')
        # The owned shutdown state releases an acquired lease only after the
        # exact child is confirmed dead; borrowed service leases stay outer-owned.
        yield job_id, entry

    def _exchange(self, action, arguments, *, probe=False, expected_binding=None):
        from core.adapters import account_execution_lock, AdapterBusy
        from assistant.owned_weibo_host import HostRouteStopped
        host, adapters = self.host, self.host._server.core.adapters
        if action not in _ACTIONS and not (probe and action == 'probe'):
            raise HostRouteStopped('owned_weibo_arguments_invalid')
        initial = host.current_parent_scope()
        with adapters.lifecycle_lock:
            if adapters.closed:
                raise HostRouteStopped('owned_weibo_host_closed')
        if not probe:
            host._require_connected()
        if action == 'handoff':
            host._guard_registration_handoff(arguments)
        command = fixed_runner_argv(probe=probe)
        channel = 'weibo:' + str(initial.account_root)
        with adapters.channel_guard:
            lock = adapters.channel_locks.setdefault(channel, threading.Lock())
        if not lock.acquire(blocking=False):
            raise AdapterBusy('微博当前owned子进程尚未结束')
        process, reader = None, None
        process_key = secrets.token_hex(16)
        nonce = secrets.token_hex(32)
        queue = Queue(maxsize=2)
        stop_reader = threading.Event()
        account_context = ExitStack()
        job_id, entry = None, None
        try:
            account_context.enter_context(account_execution_lock(initial.account_root))
            with self._job(initial) as (job_id, entry):
                # Exactly the original spawn+ownership-registration lock. The
                # original cancel(job_id), abort_account and close now see it.
                with adapters.lifecycle_lock:
                    if adapters.closed:
                        raise HostRouteStopped('owned_weibo_host_closed')
                    if action == 'handoff':
                        host._guard_registration_handoff(arguments)
                    if host.current_parent_scope() != initial or entry and entry.get('cancelled'):
                        raise HostRouteStopped('owned_weibo_scope_changed')
                    if not probe:
                        host._require_connected()
                    inherited = {key: value for key, value in os.environ.items()
                        if key.upper() in {'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'PATH'}}
                    root = initial.account_root
                    env = {**inherited, 'HOME': str(root), 'USERPROFILE': str(root),
                        'XDG_CONFIG_HOME': str(root / '.config'),
                        'APPDATA': str(root / 'AppData/Roaming'),
                        'LOCALAPPDATA': str(root / 'AppData/Local'),
                        'LEADSTUDIO_ISOLATED': '1', 'PYTHONUTF8': '1',
                        'PYTHONIOENCODING': 'utf-8',
                        'WORKSPACE_ACTIVITY_LOG': str(root / 'platform-activity.jsonl'),
                        'WORKSPACE_ACTIVITY_KIND': 'whoami'}
                    process = subprocess.Popen(command.argv, shell=False, stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, cwd=command.cwd,
                        env=env, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                    adapters.processes[process_key] = process
                    adapters.process_accounts[process_key] = root
                    adapters.job_processes[job_id] = process

                def receive():
                    try:
                        while not stop_reader.is_set():
                            value = _read(process.stdout)
                            queue.put(value, timeout=1)
                    except Exception:
                        try: queue.put(None, timeout=1)
                        except Exception: pass

                reader = threading.Thread(target=receive, name='owned-weibo-stdio', daemon=True)
                reader.start()
                _write(process.stdin, {'kind': 'start', 'version': 1, 'job_id': job_id,
                    'nonce': nonce, 'action': action, 'scope': _scope_dict(initial), 'arguments': arguments})
                deadline, seen_hello, child_identity = time.monotonic() + 35, False, None
                messages = 0
                while True:
                    messages += 1
                    if messages > 256:
                        raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise HostRouteStopped('owned_weibo_ipc_timeout')
                    try: message = queue.get(timeout=remaining)
                    except Empty: raise HostRouteStopped('owned_weibo_ipc_timeout') from None
                    if (type(message) is not dict or message.get('job_id') != job_id
                            or message.get('nonce') != nonce):
                        raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                    if host.current_parent_scope() != initial or entry and entry.get('cancelled'):
                        raise HostRouteStopped('owned_weibo_scope_changed')
                    if adapters.closed:
                        raise HostRouteStopped('owned_weibo_host_closed')
                    kind = message.get('kind')
                    if kind == 'hello' and not seen_hello and set(message) == {'kind', 'job_id', 'nonce', 'version'}:
                        if message['version'] != 1:
                            raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                        seen_hello = True
                        _write(process.stdin, {'kind': 'hello_ack', 'job_id': job_id, 'nonce': nonce})
                    elif seen_hello and kind == 'guard':
                        allowed_phases = {'probe'} if probe else {'identity'} | ({action} if action in ('search', 'comments') else set())
                        if set(message) != {'kind', 'job_id', 'nonce', 'phase'} or message['phase'] not in allowed_phases:
                            raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                        try:
                            host._require_connected()
                            response = {'code': 'current_authority_verified', 'scope': _scope_dict(host.current_parent_scope())}
                        except HostRouteStopped as exc:
                            response = {'code': exc.code}
                        _write(process.stdin, {'kind': 'guard_reply', 'job_id': job_id, 'nonce': nonce, **response})
                    elif seen_hello and kind == 'identity' and not probe:
                        if set(message) != {'kind', 'job_id', 'nonce', 'identity'}:
                            raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                        child_identity = host._identity_from_owned_child(message['identity'], _action=action)
                        if (action not in ('observe', 'handoff') and message['identity']['identity_receipt_id']
                                != arguments.get('identity_receipt_id')):
                            raise HostRouteStopped('owned_weibo_identity_invalid')
                        if expected_binding is not None and child_identity != expected_binding:
                            raise HostRouteStopped('owned_weibo_binding_changed')
                        # This identity lives only in this synchronous owned
                        # child exchange. It cannot be installed by a DTO.
                        _write(process.stdin, {'kind': 'identity_ack', 'job_id': job_id, 'nonce': nonce})
                    elif seen_hello and kind == 'resolve' and action == 'comments' and child_identity is not None:
                        if set(message) != {'kind', 'job_id', 'nonce', 'numeric_mid'} or message['numeric_mid'] != arguments['numeric_mid']:
                            raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                        with host._owned_child_identity(child_identity):
                            original = host.resolve_post(child_identity, message['numeric_mid'])
                        _write(process.stdin, {'kind': 'resolve_reply', 'job_id': job_id, 'nonce': nonce, 'post': original})
                    elif seen_hello and kind == 'result':
                        if set(message) != {'kind', 'job_id', 'nonce', 'result'}:
                            raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                        result = message['result']
                        process.stdin.close()
                        try: process.wait(timeout=min(3, max(0.01, deadline - time.monotonic())))
                        except subprocess.TimeoutExpired:
                            host._owned_shutdown_phase = 'exit_pending'
                            raise HostRouteStopped('owned_weibo_child_exit_pending') from None
                        if process.returncode != 0:
                            raise HostRouteStopped('owned_weibo_child_failed')
                        # Waiting for this exact child may have allowed cancel
                        # to win after the last message check. It cannot return
                        # an identity/result from a now-cancelled entry.
                        if host.current_parent_scope() != initial or entry and entry.get('cancelled'):
                            raise HostRouteStopped('owned_weibo_scope_changed')
                        if probe:
                            if (type(result) is not dict or set(result) != {'code'} or
                                    not isinstance(result['code'], str) or
                                    not re.fullmatch(r'[a-z_]{1,80}', result['code'])):
                                raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                            return {**result, 'child_started': True, 'platform_requests': 0,
                                'cookie_reads': 0, 'protocol': 'owned_stdio_v1'}
                        host._require_connected()
                        if type(result) is not dict or set(result) != {'identity', 'transport_result'}:
                            raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
                        current = host._identity_from_owned_child(result['identity'], _action=action)
                        if child_identity is None or current != child_identity:
                            raise HostRouteStopped('owned_weibo_binding_changed')
                        return result
                    else:
                        raise HostRouteStopped('owned_weibo_ipc_protocol_hold')
        except HostRouteStopped:
            raise
        except AdapterBusy:
            raise
        except Exception:
            raise HostRouteStopped('owned_weibo_ipc_hold') from None
        finally:
            stop_reader.set()
            # Keep the original same-thread OS lock, channel and exact lease
            # until completion, as DeveloperOriginalIdentityHost's fixed runner.
            # This call does not return a success/pending envelope while a child
            # still lives, so outer _read contexts cannot release their locks.
            host._owned_shutdown = _OwnedShutdown(host, process, process_key, job_id,
                entry, initial, account_context, lock, reader)
            host.complete_owned_shutdown()


class _ChildChannel:
    def __init__(self, start):
        self.start = start

    def call(self, kind, **data):
        _write(sys.stdout.buffer, {'kind': kind, 'job_id': self.start['job_id'],
            'nonce': self.start['nonce'], **data})
        reply = _read(sys.stdin.buffer)
        if (reply.get('job_id') != self.start['job_id'] or reply.get('nonce') != self.start['nonce']):
            raise ValueError('parent')
        return reply

    def authority(self, phase):
        reply = self.call('guard', phase=phase)
        if reply.get('kind') != 'guard_reply' or reply.get('code') != 'current_authority_verified':
            raise ValueError('authority')
        if reply.get('scope') != self.start['scope']:
            raise ValueError('scope')
        return reply['scope'], reply['code']


def _child_main(probe):
    # Probe always installs its restrictions before loading any project code.
    if probe:
        def deny(event, args):
            if event.startswith('socket.') or event in ('subprocess.Popen', 'os.system'):
                raise PermissionError('closed_probe')
            if event == 'open' and args and isinstance(args[0], (str, bytes)):
                name = os.fsdecode(args[0]).replace('\\', '/').lower()
                if 'credential' in name or 'weibo-cli' in name:
                    raise PermissionError('closed_probe')
        sys.addaudithook(deny)
    start = _read(sys.stdin.buffer)
    if (set(start) != {'kind', 'version', 'job_id', 'nonce', 'action', 'scope', 'arguments'}
            or start['kind'] != 'start' or start['version'] != 1
            or not re.fullmatch(r'[a-z0-9-]{8,80}', start['job_id'])
            or not re.fullmatch(r'[0-9a-f]{64}', start['nonce'])
            or type(start['scope']) is not dict or type(start['arguments']) is not dict
            or start['action'] not in (_ACTIONS | {'probe'} if probe else _ACTIONS)
            or probe and start['action'] != 'probe'):
        raise ValueError('start')
    channel = _ChildChannel(start)
    hello = channel.call('hello', version=1)
    if set(hello) != {'kind', 'job_id', 'nonce'} or hello['kind'] != 'hello_ack':
        raise ValueError('hello')
    if probe:
        reply = channel.call('guard', phase='probe')
        if reply.get('kind') != 'guard_reply' or not isinstance(reply.get('code'), str):
            raise ValueError('guard')
        _write(sys.stdout.buffer, {'kind': 'result', 'job_id': start['job_id'],
            'nonce': start['nonce'], 'result': {'code': reply['code']}})
        return

    # The source app uses only its fixed guarded CLI sibling. A package uses
    # its own collected modules. No stage path or request-supplied import root.
    if not getattr(sys,'frozen',False):
        runtime=Path(__file__).resolve().parents[1].parent/'work/runtime/platform-cli-guarded/_internal'
        if not (runtime/'weibo_cli/client.py').is_file():
            raise ValueError('source_runtime_missing')
        sys.path.insert(0,str(runtime))
    from core.weibo_identity import IdentityScope, IdentityService, VerifiedIdentity
    from core.weibo_read_transport import AccountBinding, execute_read

    def scope_provider():
        scope, code = channel.authority('identity')
        return IdentityScope(Path(scope['account_root']), scope['tenant_id'], scope['owner_id'],
            scope['device_id'], scope['account_id'], scope['account_revision'],
            str(scope['permission_revision']), code == 'current_authority_verified')

    def authorize_identity(scope):
        return scope_provider() == scope

    identity_service = IdentityService(scope_provider, authorize=authorize_identity)
    arguments, action = start['arguments'], start['action']
    if action == 'handoff':
        if (set(arguments) != {'original_identity', 'new_account_revision', 'registration_id'}
                or type(arguments['original_identity']) is not dict
                or set(arguments['original_identity']) != set(VerifiedIdentity.__dataclass_fields__)):
            raise ValueError('handoff')
        verified = identity_service.handoff_registered_identity(
            VerifiedIdentity(**arguments['original_identity']), arguments['new_account_revision'],
            arguments['registration_id'])
    else:
        receipt = (identity_service.observe()['identity_receipt_id'] if action == 'observe'
                   else arguments.get('identity_receipt_id'))
        verified = identity_service.binding(receipt)
    proof = asdict(verified)
    ack = channel.call('identity', identity=proof)
    if ack.get('kind') != 'identity_ack':
        raise ValueError('identity')
    output = None
    if action in ('search', 'comments'):
        binding = AccountBinding(Path(start['scope']['account_root']), verified.tenant_id,
            verified.account_id, verified.platform_uid, verified.credential_sha256, True)
        os.environ['WORKSPACE_ACTIVITY_KIND'] = action
        def authorize_read(selected, operation):
            if selected != binding or operation != action:
                raise ValueError('binding')
            channel.authority(operation)
        def resolve_post(selected, numeric_mid):
            if selected != binding or numeric_mid != arguments.get('numeric_mid'):
                raise ValueError('original')
            reply = channel.call('resolve', numeric_mid=numeric_mid)
            if reply.get('kind') != 'resolve_reply' or type(reply.get('post')) is not dict:
                raise ValueError('original')
            return reply['post']
        output = execute_read(binding, action, authorize=authorize_read,
            keyword=arguments.get('keyword', ''), post_id=arguments.get('numeric_mid', ''),
            count=arguments.get('count', 20), resolve_post=resolve_post if action == 'comments' else None)
    _write(sys.stdout.buffer, {'kind': 'result', 'job_id': start['job_id'], 'nonce': start['nonce'],
        'result': {'identity': proof, 'transport_result': output}})


def main(argv=None):
    try:
        args=sys.argv[1:] if argv is None else argv
        if args not in ([], ['--probe-ipc']):
            raise ValueError('argv')
        _child_main(args == ['--probe-ipc'])
        return 0
    except Exception:
        # No raw exception, path, credential or platform body on stderr.
        return 73
