"""Check the installed local build against its guard manifest, not its filename."""
import hashlib
import json
import stat
from pathlib import Path


def cli_runtime_tree_sha256(runtime):
    """Hash the complete frozen CLI payload, excluding only its own manifest."""
    root = Path(runtime).resolve()
    if not root.is_dir():
        raise ValueError('CLI runtime directory is missing')
    digest = hashlib.sha256()
    count = 0
    for path in sorted(root.rglob('*'), key=lambda item: item.relative_to(root).as_posix()):
        attributes = getattr(path.lstat(), 'st_file_attributes', 0)
        if path.is_symlink() or attributes & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
            raise ValueError('CLI runtime contains a link or junction')
        if not path.is_file() or path == root / 'guard-manifest.json':
            continue
        relative = path.relative_to(root).as_posix()
        content = hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda: source.read(1024 * 1024), b''):
                content.update(block)
        digest.update(relative.encode('utf-8') + b'\0' + content.hexdigest().encode('ascii') + b'\n')
        count += 1
    if not count:
        raise ValueError('CLI runtime is empty')
    return digest.hexdigest()


def opencli_evaluate_guard_verified(runtime):
    if opencli_publication_guard_verified(runtime):
        return True
    root = Path(runtime)
    required = {'dist/src/browser/page.js', 'dist/src/browser/daemon-client.js'}
    try:
        manifest = json.loads((root / 'workbench-guard.json').read_text('utf-8'))
        if manifest.get('schemaVersion') != 1 or manifest.get('version') != '1.8.8':
            return False
        if manifest.get('protection') != 'evaluate-exec-no-replay':
            return False
        files = manifest.get('files')
        if not isinstance(files, dict) or set(files) != required:
            return False
        for name in required:
            path = root / name
            if not path.resolve().is_relative_to(root.resolve()):
                return False
            if hashlib.sha256(path.read_bytes()).hexdigest() != files[name]:
                return False
        return 'WORKBENCH_SINGLE_ATTEMPT' in (root / 'dist/src/browser/page.js').read_text('utf-8')
    except (OSError, ValueError, TypeError):
        return False


def opencli_publication_guard_verified(runtime):
    root = Path(runtime)
    required = {'dist/src/browser/page.js', 'dist/src/browser/daemon-client.js',
                'dist/src/execution.js', 'dist/src/runtime.js', 'dist/src/commanderAdapter.js',
                'clis/zhihu/answer.js', 'clis/zhihu/write-shared.js', 'clis/zhihu/target.js'}
    try:
        manifest = json.loads((root / 'workbench-guard.json').read_text('utf-8'))
        if (manifest.get('schemaVersion') != 2 or manifest.get('version') != '1.8.8'
                or manifest.get('protection') != 'exec-single-transport'):
            return False
        files = manifest.get('files')
        if not isinstance(files, dict) or set(files) != required:
            return False
        for name in required:
            path = root / name
            if not path.resolve().is_relative_to(root.resolve()):
                return False
            if hashlib.sha256(path.read_bytes()).hexdigest() != files[name]:
                return False
        return ('WORKBENCH_SINGLE_ATTEMPT' in (root/'dist/src/browser/page.js').read_text('utf-8')
                and 'WORKBENCH_EXEC_SINGLE_TRANSPORT' in (root/'dist/src/browser/daemon-client.js').read_text('utf-8'))
    except (OSError, ValueError, TypeError):
        return False
