"""Independent customer natural-page material binding, never an actor grant.

The manifest-verifying host owns the review bytes. The original three page
policies still own semantics, scopes, Jobs and readiness. A runtime inventory
does not create a live device lease or prove platform login/loaded memory.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import stat
import sys

SCOPE = 'customer_distribution_read'
PURPOSES = {
    'xiaohongshu_natural_read': ('collection_read', 'natural_page_v1'),
    'xiaohongshu_identity_observation': ('identity_observation', 'natural_identity_observation_v1'),
    'xiaohongshu_session_recovery': ('session_recovery', 'natural_session_recovery_v1'),
}
_SEAL = object()
_SHA = re.compile('[0-9a-f]{64}\\Z')
_LIMITS = {'public_send_grant': False, 'native_loaded_bytes_verified': False,
    'real_platform_verified': False, 'loaded_provenance_criterion':
    'two_stable_origins_file_identity_hash', 'profile_scope': 'original_account_owned',
    'helper_route': 'fixed_portable_exe', 'system_webview': 'microsoft_machine_evergreen'}
_REQUIRED = frozenset(('assistant/customer_natural_materials.py',
    'assistant/xhs_page_read_policy.py', 'assistant/xhs_identity_policy.py',
    'assistant/xhs_session_policy.py', 'assistant/xhs_identity_context.py',
    'assistant/xhs_session_context.py', 'assistant/xhs_batch_scope.py',
    'assistant/xhs_customer_account_runtime.py', 'assistant/xhs_identity_worker.py',
    'assistant/xhs_session_worker.py', 'assistant/xhs_session_transport.py', 'core/adapters.py',
    'assistant/xhs_identity_scope.py', 'assistant/xhs_session_scope.py',
    'assistant/xhs_app_context.py', 'assistant/customer_read_lease.py',
    'assistant/owned_helper_process.py', 'assistant/owned_native_job.py',
    'assistant/owned_xhs_native/provider.py', 'assistant/owned_xhs_native/ready.py',
    'assistant/owned_xhs_native/image.py', 'assistant/owned_xhs_native/owner.py',
    'assistant/owned_xhs_native/classifier.py', 'assistant/owned_xhs_native/occupancy.py',
    'assistant/owned_xhs_native/runtime_materials.py',
    'assistant/webview_system_dependency.py', 'assistant/windows_authenticode.py',
    'assistant/windows_managed_dependency.py',
    'assistant/xhs_portable_helper.py',
    'xhs_page_transport.py', 'portable_helper_package.py', 'portable_code_origins.py'))


def _fail():
    raise ValueError('xhs_customer_natural_materials_unavailable')


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _relative(value):
    return (type(value) is str and bool(value) and '\\' not in value and ':' not in value
        and all(part not in ('', '.', '..') for part in value.split('/')))


def _file(root, relative, sha, size):
    from core.runtime_license_policy import _plain
    if (not _relative(relative) or type(sha) is not str or not _SHA.fullmatch(sha)
            or type(size) is not int or size < 0):
        _fail()
    path = _plain(root / relative, root)
    for part in (path, *path.parents):
        info = part.lstat()
        if part.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            _fail()
    before = path.stat()
    if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size != size
            or hashlib.sha256(path.read_bytes()).hexdigest() != sha):
        _fail()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size) != (
            after.st_dev, after.st_ino, after.st_mtime_ns, after.st_size):
        _fail()
    return path


def review_for(authority, server, purpose):
    """Validate static reviewed bytes only; no policy/current/heartbeat cycle."""
    if purpose not in PURPOSES:
        return None
    try:
        index, roots, records, plain, file_hash = authority._state(server)
        if purpose not in records:
            return None
        row, review = records[purpose]
        if (type(review) is not dict or set(review) != {'schema', 'scope', 'purpose',
                'company_binding', 'limits', 'helper', 'materials', 'licenses',
                'distribution_basis', 'evidence'}
                or review['schema'] != 'fangyu_customer_natural_material_review_v1'
                or review['scope'] != SCOPE or review['purpose'] != purpose
                or review['company_binding'] != index['company_binding']
                or review['limits'] != _LIMITS
                or any(type(review['limits'][key]) is not type(value) for key, value in _LIMITS.items())
                or review['evidence'] != {'license_source_reviewed': True,
                    'real_platform_verified': False, 'native_loaded_bytes_verified': False,
                    'public_send_grant': False}):
            _fail()
        helper = review['helper']
        if (type(helper) is not dict or set(helper) != {'root', 'entry', 'manifest_sha256'}
                or not _relative(helper['root']) or not _relative(helper['entry'])
                or helper['root'] != 'resources/xhs-page-helper/FangyuXhsPageHelper'
                or helper['entry'] != 'FangyuXhsPageHelper.exe'
                or type(helper['manifest_sha256']) is not str
                or not _SHA.fullmatch(helper['manifest_sha256'])):
            _fail()
        helper_root = roots['release'] / helper['root']
        from portable_helper_package import verify_package
        package, manifest_sha, facts = verify_package(helper_root / helper['entry'],
            expected_manifest_sha=helper['manifest_sha256'])
        roots = dict(roots, helper=helper_root)
        material_facts, licenses, seen = [], [], set()
        for name, output, roles in (('materials', material_facts,
                {'source', 'dependency', 'native_runtime', 'managed_runtime'}),
                ('licenses', licenses, {'license'})):
            entries = review[name]
            if type(entries) is not list or not 1 <= len(entries) <= 8192:
                _fail()
            for item in entries:
                if (type(item) is not dict or set(item) != {'root', 'path', 'sha256', 'bytes', 'role'}
                        or item['root'] not in roots or item['role'] not in roles
                        or (item['root'], item['path']) in seen):
                    _fail()
                path = _file(roots[item['root']], item['path'], item['sha256'], item['bytes'])
                output.append((str(path), item['sha256'].upper(), item['role']))
                seen.add((item['root'], item['path']))
        required = {('source', path) for path in _REQUIRED}
        required |= {('vendor', 'app.py'), ('release', 'ui_native_host.py'),
            ('release', 'resources/platform-runtime/platform_runtime.py'),
            ('release', 'resources/platform-runtime/customer_read_distribution.py')}
        required |= {('helper', item['path']) for item in package['files']}
        required.add(('helper', 'HELPER-PACKAGE.json'))
        if not required <= seen or len(licenses) < 10:
            _fail()
        basis = review['distribution_basis']
        if (type(basis) is not dict or set(basis) != {'reviewer_ref', 'reviewed_at', 'permission', 'licenses'}
                or type(basis['reviewer_ref']) is not str or not basis['reviewer_ref'].strip()
                or basis['permission'] != 'scoped_customer_natural_read_only'
                or basis['licenses'] != 'retained_helper_and_project_license_files'):
            _fail()
        from datetime import datetime, timezone
        stamp = datetime.fromisoformat(basis['reviewed_at'].replace('Z', '+00:00'))
        if stamp.tzinfo is None or stamp > datetime.now(timezone.utc):
            _fail()
        if authority._state(server)[0] != index:
            _fail()
        return {'purpose': purpose, 'scope': SCOPE, 'revision': _digest([row, review]),
            'helper_root': helper_root, 'helper_exe': helper_root / helper['entry'],
            'manifest_sha256': manifest_sha, 'package': package,
            'materials': tuple(material_facts), 'licenses': tuple(licenses)}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, ImportError):
        return None


def authority_review(server, purpose):
    module = sys.modules.get('fangyu_customer_read_distribution')
    authority = getattr(server, '_customer_read_authority', None)
    if module is None or not module.is_authority(authority):
        return None
    return authority.natural_material_review(server, purpose)


@dataclass(frozen=True, slots=True, repr=False)
class _NaturalMaterials:
    seal: object
    policy: object
    purpose: str
    raw: dict
    system: object
    managed: object
    materials: tuple
    licenses: tuple

    def check(self, decision):
        from app import AppServer
        from .xhs_app_context import XhsAppHostContext
        from .xhs_page_runtime import XhsPageRuntime
        server = self.policy.server
        from .xhs_customer_account_runtime import runtime_for
        account_purpose = self.purpose != 'xiaohongshu_natural_read'
        runtime = runtime_for(server) if account_purpose else getattr(server, 'xhs_page_runtime', None)
        if (self.seal is not _SEAL or decision.customer is not self
                or decision.policy is not self.policy or self.policy._decision is not decision
                or type(server) is not AppServer or not getattr(sys, 'frozen', False)
                or decision.route != PURPOSES[self.purpose][1]
                or decision.usage_scope != SCOPE or decision.revision != self.raw['revision']
                or type(runtime) is not XhsPageRuntime or not runtime.natural_mode
                or runtime.closed or runtime.core is not server.core
                or not account_purpose and runtime is not server.core.adapters.xhs_page_runtime
                or type(server._xhs_app_context) is not XhsAppHostContext
                or server._xhs_app_context._server is not server
                or runtime.app_context_factory is not server._xhs_app_context
                or server.company != server.core.deployment_config or server.closing):
            _fail()
        current = authority_review(server, self.purpose)
        if current is None or current['revision'] != self.raw['revision']:
            _fail()
        self.system.check_current()
        self.managed.check_current()

    def check_execution(self, scope=None):
        from .customer_read_lease import current
        if not current(self.policy.server, self.purpose):
            _fail()
        if self.purpose != 'xiaohongshu_natural_read':
            if scope is None or not scope.entered:
                _fail()
            from .xhs_customer_account_runtime import check_operation
            check_operation(scope.app_context, required=True)

    def check_loaded(self, decision, facts):
        self.check(decision)
        if (type(facts) is not dict or facts.get('contract') != 'page_ready_sources_v1'
                or facts.get('portable_code_origins_checked') is not True
                or facts.get('helper_package_sha256') != self.raw['manifest_sha256']
                or tuple(tuple(item[:3]) for item in facts.get('bound_materials', ())
                    if type(item) in (tuple, list) and len(item) == 4) != self.materials):
            _fail()
        approved = {str(Path(path)).casefold() for path, sha, role in self.materials}
        for name in ('python_modules', 'managed_assemblies'):
            entries = facts.get(name)
            if type(entries) not in (tuple, list) or len(entries) > 8192:
                _fail()
            if any(type(path) is not str or str(Path(path)).casefold() not in approved for path in entries):
                _fail()
        for role in ('native_runtime', 'managed_runtime', 'webview_runtime'):
            loaded = {str(Path(path)).casefold() for name in ('python_modules', 'native_modules',
                'managed_assemblies', 'browser_modules') for path in facts.get(name, ())}
            if not any(item_role == role and str(Path(path)).casefold() in loaded
                    for path, sha, item_role in self.materials):
                _fail()

    def close(self):
        self.system.close()
        self.managed.close()


def create_decision(policy, decision_type, seal, purpose):
    """A separate purpose review; missing customer materials stay unavailable."""
    if purpose not in PURPOSES or not getattr(sys, 'frozen', False):
        return None
    raw = authority_review(policy.server, purpose)
    if raw is None:
        return None
    from .webview_system_dependency import OwnedRuntimePin, SystemWebView2Policy
    root = raw['helper_root']
    package = raw['package']
    # Exact SDK and whole fixed helper EXE are still owned artifacts. Only the
    # external Microsoft machine Evergreen files have dynamic patch identity.
    roles = {'FangyuXhsPageHelper.exe': 'helper_exe_with_embedded_pyz',
        '_internal/webview/lib/Microsoft.Web.WebView2.Core.dll': 'sdk_core',
        '_internal/webview/lib/Microsoft.Web.WebView2.WinForms.dll': 'sdk_winforms',
        '_internal/webview/lib/runtimes/win-x64/native/WebView2Loader.dll': 'sdk_loader'}
    files = {row['path']: row for row in package['files']}
    pins = tuple(OwnedRuntimePin(root / name, files[name]['sha256'], files[name]['bytes'], role)
        for name, role in roles.items())
    system = SystemWebView2Policy(pins, mode='compiled').verify()
    managed = None
    try:
        from .windows_managed_dependency import verify_framework_files
        managed = verify_framework_files()
        materials = raw['materials'] + tuple(system.materials) + tuple(managed.materials)
        bundle = _NaturalMaterials(_SEAL, policy, purpose, raw, system, managed, materials, raw['licenses'])
        return decision_type(seal, policy, raw['revision'], materials, raw['licenses'],
            raw['revision'], PURPOSES[purpose][1], SCOPE, bundle)
    except BaseException:
        system.close()
        if managed is not None:
            managed.close()
        raise


def resolve_customer(policy, decision_type, seal, purpose):
    """Recreate file evidence for a new explicit call after a genuine update.

    A running owner retains its original decision and will stop on identity
    change. No old task receives a silently replaced loaded-runtime token.
    """
    existing = policy._decision
    if type(existing) is decision_type and getattr(existing, 'customer', None) is not None:
        try:
            existing._current()
            return existing
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            existing.customer.close()
            policy._decision = None
            return None
    try:
        value = create_decision(policy, decision_type, seal, purpose)
        if value is not None:
            policy._decision = value
            value._current()
        return value
    except (OSError, ValueError, TypeError, KeyError, AttributeError, ImportError):
        policy._decision = None
        return None


class _PortableHelperBinding:
    """One reviewed EXE, not a Python/pyvenv impersonation or user argv."""
    def __init__(self, decision):
        from .owned_xhs_native.classifier import _executable_key, canonical_path
        if type(getattr(decision, 'customer', None)) is not _NaturalMaterials:
            _fail()
        self.decision = decision
        decision.customer.check(decision)
        path = decision.customer.raw['helper_exe']
        from .xhs_portable_helper import PortableHelperBinding
        self.package_binding = PortableHelperBinding(path, decision.customer.raw['manifest_sha256'])
        self._binding = {'kind': 'fixed_portable_xhs_helper_v1',
            'routes': {_executable_key(str(path)): canonical_path(str(path))},
            'executable_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'manifest_sha256': decision.customer.raw['manifest_sha256']}

    def validate(self):
        try:
            self.decision.customer.check(self.decision)
            path = self.decision.customer.raw['helper_exe']
            return (self._binding['manifest_sha256'] == self.decision.customer.raw['manifest_sha256']
                and self.package_binding.validate()
                and hashlib.sha256(path.read_bytes()).hexdigest() == self._binding['executable_sha256'])
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            return False

    def executable(self, value, owner_sid, current_sid):
        from .owned_xhs_native.classifier import _executable_key, canonical_path
        if owner_sid != current_sid or not self.validate():
            _fail()
        expected = self._binding['routes'].get(_executable_key(value))
        if expected is None or canonical_path(value) != expected:
            _fail()
        return expected

    def command(self, spec_path, profile_dir):
        if (not self.validate() or spec_path.name != 'spec.json' or len(spec_path.parents) < 4
                or profile_dir != spec_path.parents[3] / 'xhs-browser-profile'):
            _fail()
        return self.package_binding.command(spec_path, profile_dir)
