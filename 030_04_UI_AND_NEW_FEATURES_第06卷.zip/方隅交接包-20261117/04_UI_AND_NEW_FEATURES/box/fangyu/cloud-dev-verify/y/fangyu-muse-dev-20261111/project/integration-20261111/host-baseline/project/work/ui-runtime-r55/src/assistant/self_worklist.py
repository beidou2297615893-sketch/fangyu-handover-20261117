"""Employee-local next-step suggestions, never an authority to send or deliver.

Read all authorized identities before lane filtering/paging. Immutable local
contact evidence is checked independently of CustomerHistory's presentation
fallbacks; unavailable history must not turn into permission to recontact.
"""
from copy import deepcopy
import hashlib
import json
import re
import unicodedata

from core import CoreError
from core.contact_journal import KINDS
from core.review_queue import snapshot as reply_snapshot, require_reply_permission
from .acquisition_operations import AcquisitionOperations, AcquisitionError, HANDOFFS, _digest, _text
from .customer_list import CustomerHistory, _person, _unresolved_contact
from .ai_workflow import effective_intent

ACTION = 'self_worklist_get'
LANES = ('check_record', 'response', 'handoff', 'draft', 'contact')
REASONS = frozenset(('journal_unreadable', 'contact_result_unknown', 'contact_record_unverified',
    'source_identity_unverified', 'source_text_missing', 'source_version_changed', 'history_scope_unavailable',
    'handoff_audit_conflict', 'authorization_not_current', 'handoff_needs_review', 'draft_snapshot_changed',
    'draft_owner_unverified', 'permission_unavailable', 'response_observed', 'handoff_pending',
    'draft_existing', 'high_intent_uncontacted'))
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_MAX_INTEGER = 9007199254740991
_FLAGS = dict(read_only=True, local_only=True, storage_scope='this_device', cross_machine_verified=False,
    platform_requests_started=False, provider_requests_started=False, ratings_modified=False,
    contacts_modified=False, handoffs_modified=False, auto_retry=False)


class SelfWorklistError(CoreError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status, self.mutation_committed = 'SELF_WORKLIST_'+code, status, False


def _fail(code, message, status=400):
    raise SelfWorklistError(code, message, status)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _name(value):
    try:
        name = _text(value, '客户显示名称', 160)
        checked = unicodedata.normalize('NFKC', name)
        checked = ''.join(char for char in checked if unicodedata.category(char) not in ('Cc', 'Cf', 'Cs'))
        _text(checked, '客户显示名称', 160)
        scan = ''.join(char for char in checked if unicodedata.category(char)[0] not in ('P', 'Z'))
        return '昵称待核对' if re.search(r'\d{7,}', scan) else checked
    except AcquisitionError:
        return '昵称待核对'


def _rank(lead):
    value = effective_intent(lead)
    kind = value.get('level') if value.get('status') == 'graded' else value.get('status')
    return (('super_high', 'high', 'medium', 'low', 'very_low', 'uncertain', 'unrelated', 'pending').index(kind)
            if kind in ('super_high', 'high', 'medium', 'low', 'very_low', 'uncertain', 'unrelated', 'pending') else 7,
            str(lead.get('id', '')))


class SelfWorklist:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access):
        if (not isinstance(tenant, str) or not tenant or not isinstance(owner, str) or not owner or len(owner) > 160
                or not isinstance(company, dict) or not isinstance(company.get('id'), str) or not company['id']
                or not isinstance(device_id, str) or not _ID.fullmatch(device_id)
                or not callable(scope_guard) or not callable(lead_access)):
            raise ValueError('待办需要可信本机主体、企业、设备与原评论权限')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.company_id, self.device_id, self._device_id = company['id'], device_id, device_id
        self.scope_guard, self.lead_access = scope_guard, lead_access

    def _scope(self):
        try:
            valid = (self.company.get('id') == self.company_id and self.device_id == self._device_id
                     and self.scope_guard() is True)
        except Exception:
            valid = False
        if not valid:
            _fail('SCOPE_CHANGED', '员工、企业或设备已变化，请重新读取待办', 409)

    def _actor(self, user):
        self._scope()
        helper = AcquisitionOperations(self.core, self.tenant, self.owner, self.company, lead_access=self.lead_access)
        try:
            with self.core.store.connect() as db:
                actor = helper._user(db, user)
            if actor.get('username') != self.owner or actor.get('cloud_bound') is not True:
                raise ValueError('owner changed')
        except (AcquisitionError, CoreError, ValueError):
            _fail('FORBIDDEN', '待办仅限当前本人有权的本机资料，请核对登录', 403)
        return deepcopy(actor), helper

    def _database_digest(self, db, actor):
        """One SQLite read snapshot of only this owner's dependencies.

        No row text escapes the digest. Current task access still decides every
        returned lead; including an owned unavailable historical dependency
        cannot grant access to that dependency.
        """
        entities = ('users', 'leads', 'tasks', 'accounts', 'replies', HANDOFFS,
                    'acquisition_events', 'acquisition_contacts', 'acquisition_consent_withdrawals')
        rows = db.execute('SELECT entity,id,body FROM records WHERE tenant_id=? ORDER BY entity,id', (self.tenant,)).fetchall()
        parsed = [(row, json.loads(row['body'])) for row in rows if row['entity'] in entities]
        owned_tasks = {value['id'] for row, value in parsed if row['entity'] == 'tasks' and value.get('cloud_owner') == self.owner}
        owned_leads = {value['id'] for row, value in parsed if row['entity'] == 'leads'
                       and (value.get('cloud_owner') == self.owner or not value.get('cloud_owner') and value.get('task_id') in owned_tasks)}
        selected = []
        for row, value in parsed:
            entity = row['entity']
            keep = (entity == 'users' and value.get('id') == actor['id'] or
                    entity == 'leads' and value.get('id') in owned_leads or
                    entity in ('tasks', 'accounts') and value.get('cloud_owner') in (None, '', self.owner) or
                    entity == 'replies' and (value.get('author_id') == actor['id'] or value.get('lead_id') in owned_leads) or
                    entity in (HANDOFFS, 'acquisition_events', 'acquisition_contacts', 'acquisition_consent_withdrawals')
                    and value.get('cloud_owner') == self.owner and value.get('company_id', self.company_id) == self.company_id)
            if keep: selected.append(dict(row))
        result = {'records': selected, 'company': deepcopy(self.company), 'device_id': self.device_id}
        for table in ('contact_events', 'customer_response_observations', 'contact_response_outbox'):
            exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            result[table] = [dict(row) for row in db.execute('SELECT * FROM '+table+' WHERE tenant_id=? AND cloud_owner=?', (self.tenant, self.owner))] if exists else []
        return _hash(result)

    def _contact_evidence(self, rows, leads, groups, replies, actor):
        """Check owned history, including UID warnings outside visible tasks.

        Hidden original text/IDs never enter the result; an opaque own history
        warning merely prevents classifying a visible UID as uncontacted.
        """
        visible = {lead['id']: lead for lead in leads}
        lead_keys = {lead['id']: _person(lead)[0] for lead in leads}
        events, problems, cache, global_bad = {}, {}, {}, False
        def issue(key, reason, lead_id=None):
            if key in groups:
                target = lead_id if lead_id in visible and lead_keys[lead_id] == key else None
                problems.setdefault(key, (reason, target))
        for row in rows:
            try:
                event = json.loads(row['payload']); original = event['lead']; reply_id = event['reply']['id']
                lead_id = original['id']; key = _person(original)[0]
                current_key = lead_keys.get(lead_id, key)
                if (not isinstance(lead_id, str) or not isinstance(reply_id, str) or not reply_id
                        or event.get('kind') not in KINDS or event.get('event_id') != row['event_id']
                        or event.get('kind') != row['kind'] or reply_id != row['reply_id']
                        or hashlib.sha256(row['payload'].encode()).hexdigest() != row['payload_hash']
                        or _hash(event) != row['payload_hash']):
                    raise ValueError('event changed')
                receipt_key = (reply_id, lead_id)
                if receipt_key not in cache:
                    cache[receipt_key] = self.core.contact_journal.receipt(self.tenant, self.owner, reply_id, lead_id)
                receipt = cache[receipt_key]
                matching = [entry for entry in receipt['events'] if entry['event_id'] == row['event_id']]
                if (receipt.get('local_integrity') != 'ok' or len(matching) != 1
                        or matching[0].get('local_integrity') != 'ok' or matching[0].get('payload_hash') != row['payload_hash']):
                    raise ValueError('journal chain changed')
                item = {'event_id': row['event_id'], 'kind': event['kind'], 'reply_id': reply_id, 'lead_id': lead_id}
                events.setdefault(key, []).append(item)
                if lead_id not in visible:
                    if event['kind'] in ('send_started', 'unknown', 'sent', 'copied', 'external_reported'):
                        issue(key, 'history_scope_unavailable')
                elif (key != current_key or any(original.get(name) != str(visible[lead_id].get(name) or '')
                        for name in ('platform', 'author_id', 'comment_id', 'task_id', 'text'))):
                    issue(current_key, 'source_version_changed', lead_id); issue(key, 'source_version_changed', lead_id)
            except Exception:
                # An unreadable scoped payload cannot safely be assigned to a
                # UID. Do not silently erase a possible prior contact.
                global_bad = True
        if global_bad:
            for key in groups: problems[key] = ('journal_unreadable', None)
        evidenced_replies = {event['reply_id'] for history in events.values() for event in history}
        if any(reply.get('author_id') == actor['id'] and reply.get('lead_id') not in visible
               and reply.get('status') in ('unknown', 'sending', 'copied', 'sent', 'external_reported')
               and reply.get('id') not in evidenced_replies for reply in replies):
            # Own legacy contact without an accessible source/immutable UID
            # cannot be assigned safely. Expose no hidden reference and do not
            # assert another visible customer has never been contacted.
            for key in groups: problems.setdefault(key, ('history_scope_unavailable', None))
        for key, people in groups.items():
            own_replies = [reply for reply in replies if reply.get('lead_id') in {lead['id'] for lead in people}]
            history = events.get(key, [])
            if (any(reply.get('status') in ('unknown', 'sending') for reply in own_replies)
                    or _unresolved_contact(history, own_replies)):
                current = next((reply['lead_id'] for reply in own_replies if reply.get('status') in ('unknown', 'sending')), None)
                if current is None:
                    outcomes = {}
                    for event in history:
                        if event['kind'] in ('send_started', 'unknown', 'sent', 'failed'):
                            outcomes[event['reply_id']] = event
                    current = next((event['lead_id'] for event in reversed(list(outcomes.values()))
                                    if event['kind'] in ('send_started', 'unknown') and event['lead_id'] in visible), None)
                issue(key, 'contact_result_unknown', current)
            latest = {}
            for event in history: latest[event['reply_id']] = event['kind']
            if (any(reply.get('status') == 'copied' for reply in own_replies)
                    or any(kind == 'copied' for kind in latest.values())):
                current = next((reply['lead_id'] for reply in own_replies if reply.get('status') == 'copied'), None)
                issue(key, 'contact_record_unverified', current)
        return problems

    def _capture(self, user):
        with self.core.lock:
            actor, helper = self._actor(user)
            with self.core.store.connect() as db:
                db.execute('BEGIN')
                database_before = self._database_digest(db, actor)
            history = CustomerHistory(self.core, self.tenant, self.owner, lead_access=self.lead_access)
            leads = history._visible(actor)
            groups = {}
            for lead in leads: groups.setdefault(_person(lead)[0], []).append(deepcopy(lead))
            people = history._build(actor)
            if set(people) != set(groups) or {comment['lead_id'] for person in people.values() for comment in person['comments']} != {lead['id'] for lead in leads}:
                _fail('SCOPE_CHANGED', '读取期间原评论权限或来源已变化，请重新读取待办', 409)
            replies = [deepcopy(row) for row in self.core.store.list('replies', self.tenant)]
            accounts = [deepcopy(row) for row in self.core.store.list('accounts', self.tenant)
                        if row.get('cloud_owner') in (None, '', self.owner)]
            with self.core.store.connect() as db:
                journal = [dict(row) for row in db.execute('SELECT * FROM contact_events WHERE tenant_id=? AND cloud_owner=? ORDER BY sequence', (self.tenant, self.owner))]
                raw_items = []  # Do not borrow a receiver/admin view.
                for row in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (HANDOFFS, self.tenant)):
                    item = json.loads(row['body'])
                    if item.get('cloud_owner') == self.owner and item.get('company_id') == self.company_id:
                        raw_items.append(item)
                handoffs, handoff_problems = {}, {}
                current_keys = {lead['id']: _person(lead)[0] for lead in leads}
                for item in raw_items:
                    source = item.get('source') or {}
                    key = current_keys.get(item.get('lead_id'), item.get('customer_key'))
                    if key not in groups: continue
                    visible_ids = {lead['id'] for lead in groups[key]}
                    if item.get('lead_id') not in visible_ids:
                        handoff_problems.setdefault(key, ('history_scope_unavailable', None, None)); continue
                    try:
                        trusted = helper._item(db, item['id'], actor)
                        public = helper._public(db, trusted, actor)
                        lead = next(lead for lead in groups[key] if lead['id'] == item['lead_id'])
                        if (item.get('customer_key') != key or any(source.get(name) != lead.get(name) for name in ('platform', 'author_id', 'comment_id', 'task_id'))
                                or source.get('original_text_hash') != _digest(lead.get('text', ''))):
                            handoff_problems.setdefault(key, ('source_version_changed', item['id'], lead['id']))
                        elif public['current_authorization']['state'] != 'granted':
                            handoff_problems.setdefault(key, ('authorization_not_current', item['id'], lead['id']))
                        elif trusted['status'] in ('duplicate_pending_review', 'existing_customer_pending_review', 'disputed') or trusted.get('qualification') in ('duplicate', 'existing_customer'):
                            handoff_problems.setdefault(key, ('handoff_needs_review', item['id'], lead['id']))
                        handoffs.setdefault(key, []).append(public)
                    except (AcquisitionError, CoreError, ValueError):
                        handoff_problems.setdefault(key, ('handoff_audit_conflict', item.get('id'), item['lead_id']))
            problems = self._contact_evidence(journal, leads, groups, replies, actor)
            # All storage-backed evidence reads above may take time. Validate
            # the saved principal *after* the last journal/lead-access boundary.
            with self.core.store.connect() as db:
                db.execute('BEGIN')
                database_after = self._database_digest(db, actor)
                try:
                    final_actor = helper._user(db, user)
                except (AcquisitionError, CoreError, ValueError):
                    _fail('FORBIDDEN', '待办仅限当前本人有权的本机资料，请核对登录', 403)
            if final_actor != actor:
                _fail('SCOPE_CHANGED', '核对期间员工身份已变化，请重新读取待办', 409)
            if database_before != database_after:
                _fail('SCOPE_CHANGED', '核对期间来源、草稿或授权已变化，请重新读取待办', 409)
            self._scope()
            fingerprint = _hash({'database': database_after, 'actor': final_actor,
                                 'visible_leads': sorted(leads, key=lambda row: row['id'])})
            return dict(actor=actor, groups=groups, people=people, replies=replies, accounts=accounts,
                        handoffs=handoffs, handoff_problems=handoff_problems, problems=problems, fingerprint=fingerprint)

    def _rows(self, state):
        items = []
        for key, leads in state['groups'].items():
            lead = sorted(leads, key=_rank)[0]
            lead_ids = {value['id'] for value in leads}
            person = state['people'][key]
            records = sorted(state['handoffs'].get(key, []), key=lambda item: (item['updated_at'], item['id']), reverse=True)
            drafts = [row for row in state['replies'] if row.get('lead_id') in lead_ids and row.get('status') in ('draft', 'approved')]
            lane = reason = None; handoff_id = None
            if key in state['problems']:
                lane, reason = 'check_record', state['problems'][key][0]
                target = state['problems'][key][1]
                if target: lead = next(value for value in leads if value['id'] == target)
            elif key in state['handoff_problems']:
                lane, reason = 'check_record', state['handoff_problems'][key][0]
                ident = state['handoff_problems'][key][1]
                lead = next((value for value in leads if value['id'] == state['handoff_problems'][key][2]), lead)
                handoff_id = ident if isinstance(ident, str) and _HANDOFF.fullmatch(ident) else None
                if handoff_id:
                    record = next((row for row in records if row['id'] == handoff_id), None)
                    if record: lead = next(value for value in leads if value['id'] == record['lead_id'])
            elif (not isinstance(lead.get('author_id'), str) or not _ID.fullmatch(lead['author_id'].strip())
                    or not isinstance(lead.get('comment_id'), str) or not _ID.fullmatch(lead['comment_id'])):
                lane, reason = 'check_record', 'source_identity_unverified'
            elif not isinstance(lead.get('text'), str) or not lead['text'].strip():
                lane, reason = 'check_record', 'source_text_missing'
            elif person.get('uncertain_contact'):
                lane, reason = 'check_record', 'contact_result_unknown'
            elif person.get('incoming_reply_status') == 'observed':
                lane, reason = 'response', 'response_observed'
                incoming = person.get('incoming_replies') or []
                target = next((row['lead_id'] for incoming_row in incoming for row in state['replies']
                               if row['id'] == incoming_row.get('reply_id') and row.get('lead_id') in lead_ids), None)
                if target:
                    lead = next(value for value in leads if value['id'] == target)
                else:
                    lane, reason = 'check_record', 'history_scope_unavailable'
            elif records:
                pending = next((row for row in records if row['status'] in ('draft', 'ready_to_deliver', 'needs_information', 'rejected')), None)
                if pending:
                    lane, reason, handoff_id = 'handoff', 'handoff_pending', pending['id']
                    lead = next(value for value in leads if value['id'] == pending['lead_id'])
                    if state['actor'].get('can_handoff') is False: lane, reason = 'check_record', 'permission_unavailable'
                # An existing authorized handoff never becomes a fresh contact.
            elif drafts:
                draft = sorted(drafts, key=lambda row: (str(row.get('updated_at', '')), row['id']), reverse=True)[0]
                lead = next(value for value in leads if value['id'] == draft['lead_id'])
                lane, reason = 'draft', 'draft_existing'
                if draft.get('author_id') != state['actor']['id']:
                    lane, reason = 'check_record', 'draft_owner_unverified'
                else:
                    try:
                        require_reply_permission(self.core, state['actor'], lead, draft)
                        self.core._check_reply_recipient(draft, lead)
                        if draft['status'] == 'approved':
                            account = next(row for row in state['accounts'] if row['id'] == draft.get('review_account_id'))
                            self.core._account_access(state['actor'], account)
                            if draft.get('approval_snapshot') != reply_snapshot(self.core, draft, lead, account):
                                raise ValueError('approval changed')
                    except Exception:
                        lane, reason = 'check_record', 'draft_snapshot_changed'
            elif person['contact_state'] in ('copied', 'external_reported', 'legacy_sent_unverified', 'unknown'):
                lane, reason = 'check_record', 'contact_record_unverified'
            elif person['contact_state'] == 'uncontacted' and _rank(lead)[0] <= 1:
                lane, reason = 'contact', 'high_intent_uncontacted'
                if state['actor'].get('can_reply') is False: lane, reason = 'check_record', 'permission_unavailable'
            if lane:
                if not isinstance(lead.get('id'), str) or not _ID.fullmatch(lead['id']):
                    _fail('STORAGE_UNAVAILABLE', '本机原评论引用暂不可核对，请保留现有记录后重试', 503)
                items.append(dict(author_key=key, lead_id=lead['id'], display_name=_name(lead.get('author')),
                    lane=lane, reason_code=reason, detail_view='handoff' if handoff_id else 'contact', handoff_id=handoff_id))
        return sorted(items, key=lambda item: (LANES.index(item['lane']), item['author_key']))

    def execute(self, action, data, user):
        if (action != ACTION or not isinstance(data, dict) or set(data)-{'lane', 'offset', 'limit'}
                or data.get('lane', 'all') not in ('all', *LANES)
                or type(data.get('offset', 0)) is not int or not 0 <= data.get('offset', 0) <= _MAX_INTEGER
                or type(data.get('limit', 10)) is not int or not 1 <= data.get('limit', 10) <= 20):
            _fail('INVALID_INPUT', '请选择有效待办类别，每页1至20位，页码须为非负整数')
        lane, offset, limit = data.get('lane', 'all'), data.get('offset', 0), data.get('limit', 10)
        try:
            before = self._capture(user)
            rows = self._rows(before)
            counts = {name: sum(row['lane'] == name for row in rows) for name in LANES}
            counts['all'] = len(rows)
            selected = rows if lane == 'all' else [row for row in rows if row['lane'] == lane]
            result = {**_FLAGS, 'contract': 'self_worklist_v1', 'lane': lane, 'offset': offset, 'limit': limit,
                      'total': len(selected), 'counts': counts, 'items': selected[offset:offset+limit]}
            # Recheck every dependency after draft/source reads, not merely the
            # principal captured at the beginning of classification.
            after = self._capture(user)
            if after['fingerprint'] != before['fingerprint']:
                _fail('SCOPE_CHANGED', '读取期间来源、草稿、授权或身份已变化，请重新读取待办', 409)
            self._scope()
            return result
        except SelfWorklistError:
            raise
        except Exception:
            _fail('STORAGE_UNAVAILABLE', '本机待办资料暂不可核对，请保留现有记录后重试', 503)
