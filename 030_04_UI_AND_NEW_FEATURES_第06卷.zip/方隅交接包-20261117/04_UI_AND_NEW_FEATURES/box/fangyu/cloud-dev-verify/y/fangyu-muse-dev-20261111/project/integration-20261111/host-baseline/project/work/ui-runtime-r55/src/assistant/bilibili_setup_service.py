"""Narrow original employee host for explicit own Bilibili setup.

Credentials go directly to the bounded setup module, never a Business command or
audit payload. A RAM holder captures the original DeviceSession; it is no grant.
"""
from dataclasses import dataclass
import re
import threading

from core import CoreError
from core.bilibili_owned_setup import BilibiliOwnedSetup
from core.service_plans import require_feature
from .business import BusinessExecutor
from .xhs_app_context import _DeviceSession

_PURPOSE='owned_credential_setup'
_ACTIONS=frozenset(('observe','confirm','status','cancel'))


def _binding(service,*,execution):
    from app import AppServer
    from .service import AssistantService
    if type(service) is not AssistantService:
        raise ValueError('当前本机助手尚未连接')
    server,core=service.server,service.server.core
    if (type(server) is not AppServer
            or server.assistant_service is not service or not server.employee_workspace_mode):
        raise ValueError('B站本人配置仅允许原本机员工工作台')
    with core.lock:
        with service.lock:
            executor=service.executor
            device=dict(service.device or {})
            if (service.closed or service.stop_event.is_set() or server.closing
                    or getattr(service,'_bilibili_setup_stopping',False)
                    or service.state not in ('online','held') or type(executor) is not BusinessExecutor):
                raise ValueError('当前本人电脑连接尚未核实')
        user=service._local_user(read_only=True)
        stored=core.store.get('users',user.get('id'))
        session=getattr(executor,'_xhs_app_session',None)
        if (type(session) is not _DeviceSession or session.service is not service
                or session.executor is not executor or session.core is not core
                or not stored or stored.get('disabled') or stored.get('cloud_bound') is not True
                or stored.get('development_local_only') is True
                or stored.get('role') not in ('admin','operator')
                or (stored.get('id'),stored.get('tenant_id'),stored.get('username')) !=
                    (executor.user_id,executor.tenant,executor.owner)
                or device.get('owner')!=executor.owner or not device.get('id')):
            raise ValueError('当前本人员工或设备绑定已变化')
        session.check()
        if execution:
            with service.lock:
                if service.state!='online' or service.executor is not executor:
                    raise ValueError('企业连接尚未确认在线，B站核对暂缓')
            if core.remote_safety_hold:
                raise ValueError('企业云端已暂停平台操作，B站核对暂缓')
            if server._runtime_license_usage_scope('internal_self_use_read')!='internal_self_use_read':
                raise ValueError('当前B站本人配置仅限已审源码自用范围')
            for config in (server.company,core.deployment_config):
                runtime=config.get('runtime') or {}
                if type(runtime) is not dict:raise ValueError('当前运行范围需重新核对')
                qa=runtime.get('platform_qa_device_id')
                if qa not in (None,'') and (type(qa) is not str or qa!=device['id']):
                    raise ValueError('当前电脑不属于指定平台验收设备')
                if runtime.get('portable_employee_release') not in (None,False):
                    if (runtime.get('portable_employee_release') is not True
                            or not core._employee_release_allowed()
                            or core.employee_release_device_id!=device['id']):
                        raise ValueError('原员工平台读取期限未确认')
            core.require_platform('bilibili')
            core._platform_execution_guard('bilibili')
            require_feature(server.company,'acquisition')
        session.check()
        return user,executor,session,device['id']


def bilibili_setup_availability(service):
    value={'purpose':_PURPOSE,'status':'blocked','reason':'current_scope_unavailable','account_ready':False}
    try:
        _binding(service,execution=True)
        policy=service.server.platform_read_license_policy
        if type(policy) is not dict or policy.get('bilibili') is not True:
            value['reason']='component_review_pending'
            return value
        from core.bilibili_read import configured
        if not configured(service.server.core.adapters.manifest('bilibili')):
            value['reason']='fixed_runtime_unavailable'
            return value
        value.update(status='available',reason='explicit_owned_setup_only')
    except (CoreError,ValueError,OSError,TypeError):pass
    return value


@dataclass(slots=True,repr=False)
class _SetupHolder:
    executor:object
    session:object
    device_id:str
    actor_id:str
    account_id:str
    setup_id:str
    manager:object=None
    preparing:bool=True


class BilibiliSetupService:
    def __init__(self,service):
        self.service=service
        self.lock=threading.RLock()
        self.holders={}
        self.closed=False

    @staticmethod
    def _request(operation,data):
        fields={'observe':{'account_id','setup_id','credential'},
                'confirm':{'account_id','setup_id','observed_uid','confirmed'},
                'status':{'account_id','setup_id'},'cancel':{'account_id','setup_id'}}
        if (operation not in _ACTIONS or type(data) is not dict or set(data)!=fields[operation]
                or type(data.get('account_id')) is not str
                or re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['account_id']) is None
                or type(data.get('setup_id')) is not str
                or re.fullmatch(r'[0-9a-f]{32}',data['setup_id']) is None):
            raise ValueError('B站本人配置仅接受原账号与本次32位配置编号')
        if operation=='confirm' and (data['confirmed'] is not True or type(data['observed_uid']) is not str):
            raise ValueError('请明确确认平台返回的本人身份')
        return data['account_id'],data['setup_id']

    def _guard(self,holder,user,account):
        fresh,executor,session,device_id=_binding(self.service,execution=True)
        if (executor is not holder.executor or session is not holder.session or device_id!=holder.device_id
                or fresh.get('id')!=holder.actor_id or user.get('id')!=fresh.get('id')
                or account.get('id')!=holder.account_id or account.get('tenant_id')!=executor.tenant
                or account.get('cloud_owner')!=executor.owner or account.get('platform')!='bilibili'):
            raise ValueError('B站本次配置的原员工、账号或设备范围已变化')

    def _admit(self,user,executor,session,device_id,account_id,ident):
        with self.lock:
            if self.closed:raise ValueError('本机配置服务正在关闭')
            existing=self.holders.get(ident)
            if existing is not None:
                if (existing.actor_id!=user['id'] or existing.account_id!=account_id
                        or existing.device_id!=device_id):
                    raise ValueError('B站配置编号不属于当前本人账号或电脑')
                return existing
            if len(self.holders)>=16:raise ValueError('本次B站配置编号已达上限，请安全结束后重新打开助手')
            for holder in self.holders.values():
                if holder.account_id!=account_id:continue
                with holder.manager.lock:
                    entry=holder.manager.entries.get(holder.setup_id)
                    occupied=holder.preparing or entry and (entry['running'] or entry['state']=='pending_confirmation'
                                                           or entry.get('cleanup') is not None)
                if occupied:raise ValueError('此账号已有配置候选，请核对或取消原编号')
            holder=_SetupHolder(executor,session,device_id,user['id'],account_id,ident)
            holder.manager=BilibiliOwnedSetup(self.service.server.core,executor.tenant,executor.owner,
                self.service.server.company,device_id=device_id,
                scope_guard=lambda current,account:self._guard(holder,current,account),
                license_policy_provider=lambda:self.service.server.platform_read_license_policy)
            self.holders[ident]=holder
            return holder

    def _holder(self,user,device_id,account_id,ident):
        with self.lock:
            holder=self.holders.get(ident)
            if (holder is None or holder.actor_id!=user['id'] or holder.account_id!=account_id
                    or holder.device_id!=device_id):
                raise ValueError('B站本次配置编号不存在或不属于当前本人电脑')
            return holder

    def _pending(self,holder):
        with self.lock:
            preparing=holder.preparing
        return {'platform':'bilibili','purpose':_PURPOSE,'account_id':holder.account_id,'setup_id':holder.setup_id,
                'state':'observing' if preparing else 'cancelled' if holder.manager.closed else 'failed',
                'observed_uid':'','nickname':'','credential_saved':False,'uid_saved':False,'account_ready':False,
                'cleanup_complete':not preparing,'worker_active':preparing,'auto_retry':False,'real_platform_verified':False}

    def execute(self,operation,data):
        account_id,ident=self._request(operation,data)
        user,executor,session,device_id=_binding(self.service,execution=operation in ('observe','confirm'))
        if operation=='observe':
            with self.service.server.core.lock:
                # Creation and the captured original session are one short
                # admission; neither lock spans the original synchronous GET.
                fresh,executor,session,device_id=_binding(self.service,execution=True)
                holder=self._admit(fresh,executor,session,device_id,account_id,ident)
            try:return holder.manager.observe(user,data)
            finally:
                with self.lock:holder.preparing=False
        holder=self._holder(user,device_id,account_id,ident)
        if operation=='confirm':return holder.manager.confirm(user,data)
        if operation=='cancel':
            # This manager contains exactly this candidate. Closing before its
            # original entry is installed also blocks every later first action.
            holder.manager.close()
        with holder.manager.lock:
            installed=ident in holder.manager.entries
        return holder.manager.status(user,data) if installed else self._pending(holder)

    def cancel_all(self,*,permanent=False,account_id=None):
        with self.lock:
            if permanent:self.closed=True
            holders=[holder for holder in self.holders.values()
                     if account_id is None or holder.account_id==account_id]
        for holder in holders:holder.manager.close()
