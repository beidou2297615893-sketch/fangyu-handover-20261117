"""Employee-scoped local customer history built from existing lead evidence.

No platform, cloud, or AI request occurs here. A platform author ID is the
only cross-comment identity; missing IDs remain separate provisional people.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import inspect
import json
import re
import time
from urllib.parse import urlsplit, urlunsplit

from core import CoreError
from core.contact_journal import _public_url
from core.platform_reads import source_reference
from .ai_workflow import effective_intent


FILTERS=frozenset(('all','viewed','contacted','uncontacted','new_comment',
                   'uncertain','copied','customer_replied','response_unverified'))
LEVELS=('super_high','high','medium','low','very_low','uncertain','unrelated','pending')
GROUP_BY=frozenset(('post','intent'))
CONTACT_KINDS=frozenset(('send_started','sent','failed','unknown','copied','external_reported'))
_KEY=re.compile(r'[0-9a-f]{64}\Z')
_COMMENT_ID=re.compile(r'[A-Za-z0-9_-]{1,256}\Z')


def _key(parts):
    return hashlib.sha256(json.dumps(parts,ensure_ascii=False,
                       separators=(',',':')).encode('utf-8')).hexdigest()


def _epoch(value):
    if type(value) in (int,float) and value>=0:return int(value)
    if not isinstance(value,str):return 0
    try:return int(datetime.fromisoformat(value.replace('Z','+00:00')).timestamp())
    except (ValueError,OverflowError):return 0


def _legacy_post(lead):
    platform=str(lead.get('platform') or '')
    url=_public_url(str(lead.get('note_url') or ''))
    if url:
        parsed=urlsplit(url)
        match=(re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]{24})/?',
                            parsed.path) if parsed.hostname in
               ('xiaohongshu.com','www.xiaohongshu.com') else None)
        identity=('xiaohongshu-note:'+match.group(1).lower() if match else
                  f'{parsed.hostname}{parsed.path}')
    else:
        identity='lead:'+str(lead['id'])
    return _key((platform,'post',identity)),url


def _source_url(platform,value):
    """Project only existing source contracts; no guessed profile or share route."""
    if (not isinstance(value,str) or not value or len(value)>2048 or
            any(ord(char)<32 or ord(char)==127 for char in value)):
        return ''
    try:
        if platform=='xiaohongshu':
            # Retain the three original 24-ID history routes, then let the
            # existing source contract validate and project signing context.
            parsed=urlsplit(value)
            if (parsed.scheme!='https' or parsed.hostname not in
                    ('xiaohongshu.com','www.xiaohongshu.com') or
                    parsed.port or parsed.username or parsed.password):
                return ''
            match=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]{24})/?',parsed.path)
            if match:
                value=urlunsplit(('https',parsed.hostname,'/explore/'+match.group(1),parsed.query,''))
        if platform=='weibo':
            parsed=urlsplit(value)
            match=re.fullmatch(r'/([1-9][0-9]{0,31})/([A-Za-z0-9]{1,32})',parsed.path)
            if (parsed.scheme!='https' or parsed.hostname!='weibo.com' or
                    parsed.port or parsed.username or parsed.password or not match):
                return ''
            return 'https://weibo.com/'+match.group(1)+'/'+match.group(2)
        return source_reference(platform,value)[1]
    except (ValueError,TypeError):
        return ''


def _post(lead):
    platform=str(lead.get('platform') or '')
    if platform=='douyin' and lead.get('source_type')=='livestream_chat':
        original=(lead.get('live_source') or {}).get('original') or {}
        room=original.get('webRid');internal=original.get('roomId')
        if isinstance(room,str) and re.fullmatch(r'[1-9][0-9]{0,19}',room) and isinstance(internal,str) and re.fullmatch(r'[1-9][0-9]{0,19}',internal):
            return _key((platform,'livestream',internal)),'https://live.douyin.com/'+room
        return _key((platform,'unverified-livestream',lead['id'])),''
    url=_source_url(platform,lead.get('note_url'))
    if url:
        parsed=urlsplit(url)
        match=(re.fullmatch(r'/explore/([A-Za-z0-9]{24})',parsed.path)
               if platform=='xiaohongshu' else None)
        if match:
            identity='xiaohongshu-note:'+match.group(1).lower()
        elif platform in ('bilibili','zhihu'):
            # These existing contracts return the same original post ID for
            # their permitted URL variants. Never derive a Weibo MID from bid.
            identity=platform+'-post:'+source_reference(platform,url)[0]
        else:
            identity=f'{parsed.hostname}{parsed.path}'
    else:
        identity='lead:'+str(lead['id'])
    return _key((platform,'post',identity)),url


def _person(lead):
    platform=str(lead.get('platform') or '')
    uid=str(lead.get('author_id') or '').strip()
    if uid:return _key((platform,'uid',uid)),False,uid
    provisional=str(lead.get('comment_id') or '').strip() or 'lead:'+str(lead['id'])
    # Existing provisional customer keys must survive source URL projection.
    post_key,_=_legacy_post(lead)
    return _key((platform,'provisional-comment',post_key,provisional)),True,''


def _unresolved_contact(lead_events, reply_rows):
    """Keep a later result for the same reply from leaving an old warning active."""
    latest={}
    for event in lead_events:
        if event.get('kind') in ('send_started','unknown','sent','failed'):
            ident=event.get('reply_id') or 'event:'+str(event.get('event_id') or '')
            latest[ident]=event['kind']
    reply_ids={reply['id'] for reply in reply_rows}
    for reply in reply_rows:
        outcome=latest.get(reply['id'])
        if outcome in ('send_started','unknown') or (
                outcome is None and reply.get('status') in ('sending','unknown')):
            return True
    return any(outcome in ('send_started','unknown') for ident,outcome in latest.items()
               if ident not in reply_ids)


class CustomerHistory:
    def __init__(self,core,tenant,owner,*,lead_access=None):
        if not isinstance(tenant,str) or not tenant or not isinstance(owner,str) or not owner:
            raise ValueError('客户清单归属无效')
        self.core=core;self.tenant=tenant;self.owner=owner
        self.lead_access=lead_access

    def _user(self,user):
        if (not isinstance(user,dict) or user.get('tenant_id')!=self.tenant or
                user.get('username')!=self.owner or user.get('cloud_bound') is not True or
                user.get('disabled')):
            raise CoreError('客户清单仅限本机绑定员工')

    def _visible(self,user):
        visible=[]
        # This cache exists only for one list/detail build. The injected access
        # callback still checks every lead and every task against this user.
        task_cache={}
        try:
            cached_access=callable(self.lead_access) and 'task_cache' in inspect.signature(self.lead_access).parameters
        except (TypeError,ValueError):
            cached_access=False
        for lead in self.core.store.list('leads',self.tenant):
            if lead.get('demo') or lead.get('tenant_id')!=self.tenant:
                continue
            if lead.get('cloud_owner') and lead['cloud_owner']!=self.owner:
                continue
            try:
                if callable(self.lead_access):
                    if cached_access:self.lead_access(user,lead,task_cache=task_cache)
                    else:self.lead_access(user,lead)
                else:
                    task_id=lead.get('task_id')
                    if task_id:
                        task=self.core._get('tasks',task_id,self.tenant)
                        self.core._task_access(user,task,self.tenant)
                    elif lead.get('cloud_owner')!=self.owner:
                        continue
            except (CoreError,ValueError):continue
            visible.append(lead)
        return visible

    def _views(self):
        with self.core.store.connect() as db:
            exists=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='customer_views'").fetchone()
            if not exists:return {}
            rows=db.execute('''SELECT kind,author_key,post_key,viewed_at FROM customer_views
              WHERE tenant_id=? AND cloud_owner=?''',(self.tenant,self.owner)).fetchall()
        return {(row['kind'],row['author_key'],row['post_key']):row['viewed_at'] for row in rows}

    def _events(self,lead_ids):
        if not lead_ids:return {}
        with self.core.store.connect() as db:
            exists=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='contact_events'").fetchone()
            if not exists:return {}
            rows=db.execute('''SELECT e.payload,a.acked_at FROM contact_events e
              LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
              WHERE e.tenant_id=? AND e.cloud_owner=? ORDER BY e.sequence''',
              (self.tenant,self.owner)).fetchall()
        grouped={}
        for row in rows:
            try:event=json.loads(row['payload'])
            except (TypeError,ValueError):continue
            lead_id=event.get('lead',{}).get('id') if isinstance(event.get('lead'),dict) else None
            if lead_id not in lead_ids:continue
            grouped.setdefault(lead_id,[]).append({
                'event_id':event.get('event_id'),'kind':event.get('kind'),
                'occurred_at':event.get('occurred_at'),
                'reply_id':event.get('reply',{}).get('id') if isinstance(event.get('reply'),dict) else '',
                'reply_text':event.get('reply',{}).get('text') if isinstance(event.get('reply'),dict) else '',
                'sender_account_id':event.get('sender',{}).get('account_id') if isinstance(event.get('sender'),dict) else '',
                'uploaded':row['acked_at'] is not None,
                'cloud_verified':False,
            })
        return grouped

    def _response_observations(self):
        """Read employee-local platform observations without adding acquisition leads."""
        with self.core.store.connect() as db:
            exists=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='customer_response_observations'").fetchone()
            if not exists:return []
            rows=db.execute('''SELECT body FROM customer_response_observations
              WHERE tenant_id=? AND cloud_owner=?''',(self.tenant,self.owner)).fetchall()
        result=[]
        for row in rows:
            try:value=json.loads(row['body'])
            except (TypeError,ValueError):continue
            if isinstance(value,dict):result.append(value)
        return result

    def _build(self,user):
        leads=self._visible(user)
        ids={lead['id'] for lead in leads}
        replies={}
        for reply in self.core.store.list('replies',self.tenant):
            if reply.get('lead_id') in ids:
                replies.setdefault(reply['lead_id'],[]).append(reply)
        events=self._events(ids)
        views=self._views()
        account_uids={account['id']:str(account.get('platform_uid') or '').strip()
                      for account in self.core.store.list('accounts',self.tenant)
                      if account.get('tenant_id')==self.tenant and
                         account.get('cloud_owner')==self.owner}
        people={}
        for lead in leads:
            key,provisional,uid=_person(lead)
            record=people.setdefault(key,{'author_key':key,'platform':str(lead.get('platform') or ''),
                'author_id':uid,'provisional_identity':provisional,'identity_status':
                'unverified_comment' if provisional else 'platform_uid',
                'nickname':'','avatar_url':'','avatar_lead_id':'','latest_published_at':'','comment_count':0,'post_count':0,
                'intent_distribution':{level:0 for level in LEVELS},
                'last_comment_at':'','last_contact_at':0,'last_contact_activity_at':0,
                'latest_comment':'',
                'latest_note_url':'',
                'contact_state':'uncontacted','contacted':False,'uncertain_contact':False,
                'copied_only':False,'incoming_reply_status':'not_monitored',
                'incoming_reply_count':0,'last_incoming_reply_at':'',
                'viewed_at':views.get(('customer',key,'')),
                'has_new_comment':False,'new_post_count':0,'_last_comment_epoch':0,'_posts':{},'_comments':[],
                '_reply_statuses':set(),'_event_kinds':set(),
                '_outgoing_proofs':[],'_incoming_candidates':[],'_uncertain_contact':False})
            record['comment_count']+=1
            stamp=lead.get('created_at') or lead.get('published_at') or ''
            epoch=_epoch(stamp)
            if epoch>=record['_last_comment_epoch']:
                record['_last_comment_epoch']=epoch
                record['last_comment_at']=stamp
                record['latest_comment']=str(lead.get('text') or '')
                record['latest_note_url']=_source_url(record['platform'],lead.get('note_url'))
                record['nickname']=str(lead.get('author') or record['nickname'])
                record['avatar_lead_id']=lead['id']
                record['latest_published_at']=lead.get('published_at') or ''
                record['avatar_url']=_public_url(str(lead.get('author_avatar_url') or ''),avatar=True) or record['avatar_url']
            intent=effective_intent(lead)
            level=(intent.get('level') if intent.get('status')=='graded' else intent.get('status')) or 'pending'
            record['intent_distribution'][level if level in LEVELS else 'pending']+=1
            post_key,note_url=_post(lead)
            viewed_at=views.get(('post',key,post_key))
            legacy_view=views.get(('post',key,_legacy_post(lead)[0]))
            if legacy_view is not None:
                viewed_at=max(viewed_at,legacy_view) if viewed_at is not None else legacy_view
            record['_incoming_candidates'].append({
                'lead_id':lead['id'],'platform':str(lead.get('platform') or ''),
                'author_id':str(lead.get('author_id') or '').strip(),
                'post_key':post_key,'comment_id':str(lead.get('comment_id') or '').strip(),
                'target_comment_id':str(lead.get('target_comment_id') or '').strip(),
                'target_author_id':str(lead.get('target_author_id') or '').strip(),
                'comment_level':lead.get('comment_level'),
                'published_at':lead.get('published_at') or '',
                'observed_at':lead.get('created_at') or '',
                'text':str(lead.get('text') or ''),'note_url':note_url,
                'source_note_title':str(lead.get('content_title') or lead.get('title') or '')})
            post=record['_posts'].setdefault(post_key,{'post_key':post_key,
                'platform':record['platform'],'note_url':note_url,
                'title':str(lead.get('content_title') or lead.get('title') or ''),
                'cover_url':'',
                'comment_count':0,'last_comment_at':'','_last_epoch':0,
                'viewed_at':viewed_at,'has_new_comment':False})
            # A legacy per-lead view applies only to that lead, never its newly
            # merged siblings. A canonical view applies to the whole known post.
            post['has_new_comment']|=viewed_at is None or epoch>viewed_at
            if viewed_at is not None:
                post['viewed_at']=max(post['viewed_at'],viewed_at) if post['viewed_at'] is not None else viewed_at
            post['comment_count']+=1
            if epoch>=post['_last_epoch']:
                post['_last_epoch']=epoch;post['last_comment_at']=stamp
                post['title']=str(lead.get('content_title') or lead.get('title') or post['title'])
                post['note_url']=note_url or post['note_url']
                post['cover_url']=_public_url(str(lead.get('content_cover_url') or ''),avatar=True) or post['cover_url']
            reply_history=[]
            lead_events=events.get(lead['id'],[])
            reply_rows=replies.get(lead['id'],[])
            record['_uncertain_contact']=record['_uncertain_contact'] or _unresolved_contact(lead_events,reply_rows)
            for event in lead_events:
                if event.get('kind') in CONTACT_KINDS:
                    record['_event_kinds'].add(event['kind'])
                    when=_epoch(event.get('occurred_at'))
                    record['last_contact_activity_at']=max(record['last_contact_activity_at'],when)
                    if event['kind'] in ('sent','external_reported'):
                        record['last_contact_at']=max(record['last_contact_at'],when)
            for reply in reply_rows:
                related=[event for event in lead_events if event.get('reply_id')==reply['id']]
                kind=related[-1]['kind'] if related else 'legacy_unverified'
                status=str(reply.get('status') or 'unknown')
                record['_reply_statuses'].add(status)
                record['last_contact_activity_at']=max(record['last_contact_activity_at'],
                    _epoch(reply.get('sent_at')), _epoch(reply.get('attempted_at')))
                if status=='sent':
                    record['last_contact_at']=max(record['last_contact_at'],_epoch(reply.get('sent_at')))
                platform_id=str(reply.get('platform_reply_id') or '').strip()
                sent_events=[event for event in related if event.get('kind')=='sent' and
                             event.get('sender_account_id')==reply.get('account_id') and
                             event.get('reply_text')==reply.get('text')]
                sent_at=_epoch(reply.get('sent_at'))
                if (status=='sent' and not provisional and platform_id and
                        _COMMENT_ID.fullmatch(platform_id) and reply.get('account_id') and
                        platform_id!=str(lead.get('comment_id') or '') and
                        sent_at>0 and sent_events):
                    record['_outgoing_proofs'].append({
                        'reply_id':reply['id'],'origin_lead_id':lead['id'],
                        'origin_comment_id':str(lead.get('comment_id') or ''),
                        'platform':str(lead.get('platform') or ''),'author_id':uid,
                        'post_key':post_key,'platform_reply_id':platform_id,
                        'sender_uid':account_uids.get(reply['account_id'],''),
                        'sent_at':sent_at,
                        'sent_event_id':sent_events[-1].get('event_id')})
                reply_history.append({'id':reply['id'],'text':str(reply.get('text') or ''),
                    'status':status,'evidence_kind':kind,
                    'platform_reply_id':platform_id if _COMMENT_ID.fullmatch(platform_id) else '',
                    'created_at':reply.get('created_at') or '',
                    'sent_at':reply.get('sent_at') or '',
                    'attempted_at':reply.get('attempted_at') or '',
                    'events':related,'cloud_verified':False})
            reply_history.sort(key=lambda item:(item['created_at'],item['id']),reverse=True)
            record['_comments'].append({'lead_id':lead['id'],'comment_id':str(lead.get('comment_id') or ''),
                'text':str(lead.get('text') or ''),'created_at':stamp,'intent':intent,
                'lead':{key:lead[key] for key in ('id','task_id','platform','author','author_id','author_avatar_url','text','note_url','url','source_type','live_source','comment_id','parent_id','parent_text','target_comment_id','target_author_id','comment_level','content_title','content_author','content_author_id','content_author_avatar_url','content_cover_url','content_published_at','published_at','created_at','ai_intent','manual_intent','analysis_status','verification_status','post_date_status','ip_location','region','content_region','grade') if key in lead},
                'published_at':lead.get('published_at') or '',
                'post_key':post_key,'note_url':note_url,'reply_history':reply_history,
                'contact_events':lead_events})
        observations=self._response_observations()
        observations_by_source={}
        for position,item in enumerate(observations):
            source=(item.get('platform'),item.get('author_id'),item.get('post_key'))
            if all(isinstance(part,str) for part in source):
                observations_by_source.setdefault(source,[]).append((position,item))
        for record in people.values():
            existing={(item['post_key'],item['comment_id']) for item in record['_incoming_candidates']}
            if record['author_id']:
                relevant=[entry for post_key in record['_posts'] for entry in
                    observations_by_source.get((record['platform'],record['author_id'],post_key),[])]
                if len(relevant)>1:relevant.sort(key=lambda entry:entry[0])
                for _,item in relevant:
                    post_key=item['post_key']
                    if (post_key,item.get('comment_id')) in existing:continue
                    record['_incoming_candidates'].append({
                        'lead_id':'response:'+str(item.get('comment_id') or ''),
                        'platform':item['platform'],'author_id':item['author_id'],
                        'post_key':post_key,'comment_id':str(item.get('comment_id') or ''),
                        'target_comment_id':str(item.get('target_comment_id') or ''),
                        'target_author_id':str(item.get('target_author_id') or ''),
                        'published_at':item.get('published_at') or '',
                        'observed_at':item.get('observed_at') or '',
                        'text':str(item.get('text') or ''),'note_url':str(item.get('note_url') or ''),
                        'source_note_title':str(item.get('source_note_title') or ''),
                        'source':'response_check'})
                    existing.add((post_key,item.get('comment_id')))
            proofs=record.pop('_outgoing_proofs')
            candidates=record.pop('_incoming_candidates')
            incoming={}
            for candidate in candidates:
                published=_epoch(candidate['published_at'])
                if (not published or not candidate['comment_id'] or
                        not candidate['target_comment_id'] or
                        not _COMMENT_ID.fullmatch(candidate['target_comment_id'])):
                    continue
                matches=[proof for proof in proofs if
                    candidate['lead_id']!=proof['origin_lead_id'] and
                    candidate['platform']==proof['platform'] and
                    candidate['post_key']==proof['post_key'] and
                    candidate['author_id']==proof['author_id'] and
                    candidate['comment_id'] not in
                        (proof['platform_reply_id'],proof['origin_comment_id']) and
                    candidate['target_comment_id']==proof['platform_reply_id'] and
                    (not candidate['target_author_id'] or
                     candidate['target_author_id']==proof['sender_uid'] and bool(proof['sender_uid'])) and
                    published>proof['sent_at']]
                if len(matches)!=1:continue
                proof=matches[0]
                incoming[candidate['lead_id']]={
                    'lead_id':candidate['lead_id'],'comment_id':candidate['comment_id'],
                    'text':candidate['text'],'published_at':candidate['published_at'],
                    'observed_at':candidate['observed_at'],'note_url':candidate['note_url'],
                    'reply_id':proof['reply_id'],'platform_reply_id':proof['platform_reply_id'],
                    'target_comment_id':candidate['target_comment_id'],
                    'source_note_title':candidate['source_note_title'],
                    'sent_event_id':proof['sent_event_id'],
                     'source':candidate.get('source','collected'),
                    'evidence':'explicit_target_comment_same_uid_post_after_sent'}
            record['incoming_replies']=sorted(incoming.values(),
                key=lambda item:(item['published_at'],item['lead_id']),reverse=True)
            record['incoming_reply_count']=len(incoming)
            if incoming:
                record['incoming_reply_status']='observed'
                record['last_incoming_reply_at']=record['incoming_replies'][0]['published_at']
            kinds=record.pop('_event_kinds');statuses=record.pop('_reply_statuses')
            if 'sent' in kinds:state='sent'
            elif 'external_reported' in kinds:state='external_reported'
            elif record['_uncertain_contact']:state='unknown'
            elif 'copied' in kinds or 'copied' in statuses:state='copied'
            elif 'sent' in statuses:state='legacy_sent_unverified'
            else:state='uncontacted'
            record['contact_state']=state
            record['contacted']=state in ('sent','external_reported')
            record['uncertain_contact']=record.pop('_uncertain_contact')
            record['copied_only']=state=='copied'
            posts=record.pop('_posts')
            record['post_count']=len(posts)
            for post in posts.values():
                post.pop('_last_epoch')
            record['new_post_count']=sum(post['has_new_comment'] for post in posts.values())
            record['has_new_comment']=record['new_post_count']>0
            record['posts']=sorted(posts.values(),key=lambda post:(post['last_comment_at'],post['post_key']),reverse=True)
            record['primary_post']=dict(record['posts'][0]) if record['posts'] else None
            record['comments']=sorted(record.pop('_comments'),key=lambda item:(item['created_at'],item['lead_id']),reverse=True)
            top=self._top_level(record)
            matches=[comment for comment in record['comments']
                     if (comment['intent'].get('level') if comment['intent'].get('status')=='graded'
                         else comment['intent'].get('status'))==top]
            representative=next((comment for comment in matches
                                 if comment['intent'].get('source')=='manual' or
                                    isinstance(comment['lead'].get('manual_intent'),dict)),None)
            representative=representative or (matches[0] if matches else None)
            record['representative_intent_lead_id']=representative['lead_id'] if representative else ''
            record['representative_comment']=representative['text'] if representative else ''
            record['representative_comment_at']=(representative['published_at'] or representative['created_at']) if representative else ''
        return people

    def customer_list(self,data,user):
        self._user(user)
        if not isinstance(data,dict) or set(data)-{'query','filter','offset','limit','group_by','group_key'}:
            raise ValueError('客户清单参数无效')
        query=data.get('query','');selected=data.get('filter','all')
        offset=data.get('offset',0);limit=data.get('limit',20)
        group_by=data.get('group_by','post');group_key=data.get('group_key','')
        if (not isinstance(query,str) or len(query)>100 or selected not in FILTERS or
                type(offset) is not int or offset<0 or type(limit) is not int or not 1<=limit<=100 or
                not isinstance(group_by,str) or group_by not in GROUP_BY or
                not isinstance(group_key,str) or len(group_key)>64 or
                (group_key and not (_KEY.fullmatch(group_key) if group_by=='post' else group_key in LEVELS))):
            raise ValueError('客户清单参数无效')
        rows=list(self._build(user).values())
        needle=query.strip().casefold()
        if needle:
            rows=[item for item in rows if needle in item['nickname'].casefold() or
                  needle in item['author_id'].casefold() or
                  any(needle in comment['text'].casefold() or needle in comment['note_url'].casefold()
                      for comment in item['comments'])]
        counts={'all':len(rows)}
        for name in FILTERS-{'all'}:
            counts[name]=sum(self._matches(item,name) for item in rows)
        contact_states={name:sum(item['contact_state']==name for item in rows)
                        for name in ('sent','external_reported','legacy_sent_unverified',
                                     'unknown','copied','uncontacted')}
        filtered=[item for item in rows if self._matches(item,selected)]
        # Build every group before paging. A UID can belong to several posts, but
        # remains one customer row in any selected post and in the unfiltered list.
        groups={}
        if group_by=='post':
            for item in filtered:
                for post in item['posts']:
                    group=groups.setdefault(post['post_key'],{'key':post['post_key'],
                        'platform':post['platform'],
                        'label':post['title'] or '帖子标题未提供','note_url':post['note_url'],
                        'cover_url':post['cover_url'],'count':0,'last_comment_at':''})
                    group['count']+=1
                    if _epoch(post['last_comment_at'])>=_epoch(group['last_comment_at']):
                        group['last_comment_at']=post['last_comment_at']
                        if post['title']:group['label']=post['title']
                        if post['note_url']:group['note_url']=post['note_url']
                        if post['cover_url']:group['cover_url']=post['cover_url']
            groups=sorted(groups.values(),key=lambda group:(_epoch(group['last_comment_at']),group['key']),reverse=True)
            if group_key:filtered=[item for item in filtered if any(post['post_key']==group_key for post in item['posts'])]
            group_activity={group['key']:_epoch(group['last_comment_at']) for group in groups}
            filtered.sort(key=lambda item:(
                group_activity.get(group_key or (item['primary_post'] or {}).get('post_key'),0),
                -LEVELS.index(self._top_level(item)),
                item['_last_comment_epoch'],
                item['author_key']),reverse=True)
        else:
            groups=[{'key':level,'label':level,'count':sum(self._top_level(item)==level for item in filtered)}
                    for level in LEVELS]
            if group_key:filtered=[item for item in filtered if self._top_level(item)==group_key]
            filtered.sort(key=lambda item:(-LEVELS.index(self._top_level(item)),item['_last_comment_epoch'],item['author_key']),reverse=True)
        return {'items':[self._summary(item,group_key if group_by=='post' else '')
                         for item in filtered[offset:offset+limit]],
                'total':len(filtered),'all_total':len(rows),'state_counts':counts,
                'contact_state_counts':contact_states,
                'offset':offset,'limit':limit,'group_by':group_by,'group_key':group_key,
                'groups':groups,'groups_total':len(groups),
                'group_scope':'all_query_and_filter_matches_before_pagination;post_membership_can_overlap',
                'incoming_reply_status':'observed' if counts['customer_replied'] else 'not_observed_in_local_evidence',
                'incoming_reply_scope':'all_query_matches_before_filter_and_pagination'}

    @staticmethod
    def _top_level(item):
        return next((level for level in LEVELS if item['intent_distribution'][level]>0),'pending')

    @staticmethod
    def _matches(item,selected):
        return (selected=='all' or selected=='viewed' and item['viewed_at'] is not None or
                selected=='contacted' and item['contacted'] or
                selected=='uncontacted' and item['contact_state']=='uncontacted' or
                selected=='new_comment' and item['has_new_comment'] or
                selected=='uncertain' and item['uncertain_contact'] or
                selected=='copied' and item['copied_only'] or
                selected=='customer_replied' and item['incoming_reply_count']>0 or
                selected=='response_unverified' and item['incoming_reply_count']==0 and
                  item['contact_state'] in ('sent','external_reported','legacy_sent_unverified','unknown'))

    @staticmethod
    def _summary(item,selected_post=''):
        summary={key:value for key,value in item.items()
                 if key not in ('comments','posts','incoming_replies','_last_comment_epoch')}
        if selected_post:
            comment=next((comment for comment in item['comments']
                          if comment['post_key']==selected_post),None)
            post=next((post for post in item['posts'] if post['post_key']==selected_post),None)
            if comment and post:
                summary['latest_comment']=comment['text']
                summary['latest_published_at']=comment['published_at']
                summary['last_comment_at']=comment['created_at']
                summary['primary_post']=post
        return summary

    def customer_detail(self,author_key,user):
        self._user(user)
        if not isinstance(author_key,str) or not _KEY.fullmatch(author_key):
            raise ValueError('客户标识无效')
        item=self._build(user).get(author_key)
        if not item:raise CoreError('客户不存在或无权访问')
        return {key:value for key,value in item.items() if key!='_last_comment_epoch'}

    def customer_seen(self,data,user):
        self._user(user)
        if (not isinstance(data,dict) or set(data) not in ({'author_key'},{'author_key','post_key'}) or
                not isinstance(data.get('author_key'),str) or not _KEY.fullmatch(data['author_key'])):
            raise ValueError('浏览记录参数无效')
        key=data['author_key'];post_key=data.get('post_key','')
        item=self._build(user).get(key)
        if not item:raise CoreError('客户不存在或无权访问')
        if post_key and (not isinstance(post_key,str) or not _KEY.fullmatch(post_key) or
                         post_key not in {post['post_key'] for post in item['posts']}):
            raise CoreError('原帖不存在或无权访问')
        stamp=int(time.time())
        with self.core.store.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS customer_views(
              tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,
              kind TEXT NOT NULL,author_key TEXT NOT NULL,post_key TEXT NOT NULL,
              viewed_at INTEGER NOT NULL,
              PRIMARY KEY(tenant_id,cloud_owner,kind,author_key,post_key))''')
            db.execute('''INSERT INTO customer_views VALUES(?,?,?,?,?,?)
              ON CONFLICT(tenant_id,cloud_owner,kind,author_key,post_key)
              DO UPDATE SET viewed_at=excluded.viewed_at''',
              (self.tenant,self.owner,'customer',key,'',stamp))
            if post_key:
                db.execute('''INSERT INTO customer_views VALUES(?,?,?,?,?,?)
                  ON CONFLICT(tenant_id,cloud_owner,kind,author_key,post_key)
                  DO UPDATE SET viewed_at=excluded.viewed_at''',
                  (self.tenant,self.owner,'post',key,post_key,stamp))
        fresh=self._build(user).get(key)
        if not fresh:raise CoreError('客户记录已变化，请刷新后再查看')
        return {'author_key':key,'post_key':post_key,'viewed_at':stamp,'local_only':True,
                'has_new_comment':fresh['has_new_comment'],'new_post_count':fresh['new_post_count']}
