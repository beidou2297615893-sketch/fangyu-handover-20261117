"""Pure correlation of a manual reply in one explicitly owned XHS WebView2.

This module never opens a browser, reads cookies, or sends a platform request.
Only a matched POST and its own finished response can produce sent evidence.
"""
from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
import hashlib
import json
import re
import time
from urllib.parse import urlsplit

from .login_natural_identity import _profile


POST_URL='https://edith.xiaohongshu.com/api/sns/web/v1/comment/post'
GETME_URL='https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
MAX_EVENT=64*1024
MAX_POST=4096
MAX_BODY=64*1024
MAX_ATTEMPTS=8
_NOTE=re.compile(r'[0-9a-f]{24}')
_ID=re.compile(r'[A-Za-z0-9_-]{1,256}')
_SCOPE_ID=re.compile(r'[A-Za-z0-9_.@:-]{1,256}')
_REQUEST_ID=re.compile(r'[A-Za-z0-9_.:-]{1,256}')


def _pairs(items):
    result={}
    for key,value in items:
        if key in result:raise ValueError('duplicate_json_key')
        result[key]=value
    return result


def _json(raw,limit):
    if not isinstance(raw,str) or len(raw)>limit:return None
    try:
        result=json.loads(raw,object_pairs_hook=_pairs,
                          parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
    except (TypeError,ValueError,RecursionError):return None
    return result if isinstance(result,dict) else None


def _api_url(value,expected):
    if not isinstance(value,str):return False
    try:
        parsed=urlsplit(value)
        port=parsed.port
    except ValueError:return False
    return (parsed.scheme=='https' and parsed.hostname=='edith.xiaohongshu.com'
            and port is None and not parsed.username and not parsed.password
            and not parsed.query and not parsed.fragment and parsed.path==urlsplit(expected).path)


def _note_url(value,note_id):
    if not isinstance(value,str):return False
    try:
        parsed=urlsplit(value)
        port=parsed.port
    except ValueError:return False
    return (parsed.scheme=='https' and parsed.hostname=='www.xiaohongshu.com'
            and port is None and not parsed.username and not parsed.password
            and not parsed.fragment and parsed.path in
            (f'/explore/{note_id}',f'/search_result/{note_id}'))


def _safe_id(value,limit=256):
    return isinstance(value,str) and len(value)<=limit and bool(_ID.fullmatch(value))


@dataclass(frozen=True,repr=False)
class ReplyWindowSpec:
    tenant_id:str
    cloud_owner:str
    device_id:str
    account_id:str
    account_uid:str
    note_id:str
    target_comment_id:str
    expected_content:str=''

    def __post_init__(self):
        for name in ('tenant_id','cloud_owner','device_id','account_id'):
            value=getattr(self,name)
            if not isinstance(value,str) or not _SCOPE_ID.fullmatch(value):
                raise ValueError('reply_window_scope_invalid')
        if not _safe_id(self.account_uid) or not _safe_id(self.target_comment_id,160):
            raise ValueError('reply_window_scope_invalid')
        if not isinstance(self.note_id,str) or not _NOTE.fullmatch(self.note_id):
            raise ValueError('reply_window_note_invalid')
        if (not isinstance(self.expected_content,str) or len(self.expected_content)>3000
                or '\x00' in self.expected_content):
            raise ValueError('reply_window_content_invalid')


def _request_post(raw,spec):
    value=_json(raw,MAX_POST)
    if not value or set(value) not in ({'note_id','target_comment_id','content'},
                                      {'note_id','target_comment_id','content','at_users'}):return None
    if value.get('at_users',[])!=[]:return None
    content=value.get('content')
    if (value.get('note_id')!=spec.note_id or value.get('target_comment_id')!=spec.target_comment_id
            or not isinstance(content,str) or not content.strip() or len(content)>3000
            or '\x00' in content or spec.expected_content and content!=spec.expected_content):return None
    return content


def _response_result(body,status,spec,identity_uid):
    if type(status) is not int or status<200 or status>=300:return 'failed','',''
    value=_json(body,MAX_BODY)
    if value is None:return 'unknown','',''
    if value.get('success') is False or (type(value.get('code')) is int and value['code']!=0):
        return 'failed','',''
    if value.get('success') is not True or value.get('code')!=0:
        return 'unknown','',''
    data=value.get('data')
    if not isinstance(data,dict):return 'unknown','',''
    comment=data.get('comment') if isinstance(data.get('comment'),dict) else {}
    ids={candidate for candidate in (data.get('id'),data.get('comment_id'),
         comment.get('id'),comment.get('comment_id')) if _safe_id(candidate,160)}
    if len(ids)!=1:return 'unknown','',''
    uids={candidate for candidate in (data.get('user_id'),data.get('sender_uid'),
          (data.get('user') or {}).get('user_id') if isinstance(data.get('user'),dict) else None,
          (comment.get('user') or {}).get('user_id') if isinstance(comment.get('user'),dict) else None)
          if _safe_id(candidate)}
    if len(uids)>1:return 'unknown','',''
    response_uid=next(iter(uids),'')
    if response_uid and response_uid!=spec.account_uid:return 'unknown','',''
    if not response_uid and identity_uid!=spec.account_uid:return 'unknown','',''
    return 'sent',next(iter(ids)),response_uid or identity_uid


class TrackedReplyWindow:
    def __init__(self,spec:ReplyWindowSpec):
        if not isinstance(spec,ReplyWindowSpec):raise ValueError('reply_window_scope_invalid')
        self.spec=spec
        self.frame_id='';self.loader_id='';self.document_url='';self.identity_uid=''
        self.invalid='';self.requests={};self.used_ids=set();self.output=[]

    def bind_document(self,url,frame_id,loader_id):
        if self.invalid or not _note_url(url,self.spec.note_id) or not _safe_id(frame_id) or not _safe_id(loader_id):
            self.invalid='document_scope_invalid';return False
        if self.frame_id and (frame_id!=self.frame_id or loader_id!=self.loader_id):
            self.invalid='document_changed';return False
        self.document_url=url;self.frame_id=frame_id;self.loader_id=loader_id
        return True

    def invalidate(self,code='document_changed'):
        self.invalid=code
        self.requests.clear();self.output.clear()

    def request(self,raw,session_id=''):
        if self.invalid or session_id:return None
        event=_json(raw,MAX_EVENT)
        if event is None:return None
        request=event.get('request')
        if not isinstance(request,dict):return None
        rid,frame,loader=(event.get(key) for key in ('requestId','frameId','loaderId'))
        if (not isinstance(rid,str) or not _REQUEST_ID.fullmatch(rid)
                or not _safe_id(frame) or not _safe_id(loader)):return None
        method=request.get('method');url=request.get('url')
        if event.get('type')=='Document':
            if self.frame_id and frame!=self.frame_id:return None
            if method=='GET' and _note_url(url,self.spec.note_id):
                self.bind_document(url,frame,loader)
            else:self.invalidate('document_changed')
            return None
        if not self.frame_id or frame!=self.frame_id or loader!=self.loader_id:return None
        kind='post' if method=='POST' and _api_url(url,POST_URL) else \
             'getme' if method=='GET' and _api_url(url,GETME_URL) else ''
        if not kind:return None
        if (event.get('redirectResponse') is not None or rid in self.used_ids or
                len(self.used_ids)>=MAX_ATTEMPTS*2):
            self.invalidate('request_scope_invalid');return None
        self.used_ids.add(rid)
        self.requests[rid]={'kind':kind,'url':url,'frame':frame,'loader':loader,
                            'post':None,'status':None,'responded':False,'finished':False,
                            'body':None,'at':int(time.time())}
        return (rid,kind)

    def request_post_data(self,rid,raw):
        record=self.requests.get(rid)
        if not record or record['kind']!='post' or self.invalid:return
        wrapper=_json(raw,MAX_POST+1024)
        content=_request_post(wrapper.get('postData'),self.spec) if wrapper else None
        if content is None:
            # A different manual POST may already have left the browser. Stop
            # this attempt instead of later claiming a matched POST as the
            # only reply made in the window.
            self.invalidate('post_scope_mismatch');return
        record['post']=content
        self._settle(rid)

    def response(self,raw,session_id=''):
        if self.invalid or session_id:return
        event=_json(raw,MAX_EVENT)
        if event is None:return
        rid=event.get('requestId');record=self.requests.get(rid)
        response=event.get('response')
        if not record or not isinstance(response,dict):return
        if (event.get('frameId')!=record['frame'] or event.get('loaderId')!=record['loader']
                or response.get('url')!=record['url']):
            self.requests.pop(rid,None);return
        record['status']=response.get('status');record['responded']=True

    def finished(self,raw,session_id=''):
        if self.invalid or session_id:return None
        event=_json(raw,MAX_EVENT)
        if event is None:return None
        rid=event.get('requestId');record=self.requests.get(rid)
        if not record:return None
        size=event.get('encodedDataLength')
        if not record['responded'] or record['finished'] or type(size) not in (int,float) or not 0<=size<=MAX_BODY:
            self.body_unavailable(rid);return None
        record['finished']=True
        return rid

    def body_unavailable(self,rid):
        record=self.requests.get(rid)
        if not record:return
        if record['kind']=='post':
            record['body']='';self._settle(rid)
        else:self.requests.pop(rid,None)

    def response_body(self,rid,raw):
        record=self.requests.get(rid)
        if not record or self.invalid:return
        wrapper=_json(raw,MAX_BODY*2)
        if wrapper is None or not isinstance(wrapper.get('body'),str) or type(wrapper.get('base64Encoded')) is not bool:
            self.body_unavailable(rid);return
        try:
            body=(base64.b64decode(wrapper['body'],validate=True) if wrapper['base64Encoded']
                  else wrapper['body'].encode('utf-8'))
            if len(body)>MAX_BODY:raise ValueError()
            text=body.decode('utf-8')
        except (ValueError,UnicodeError,binascii.Error):
            self.body_unavailable(rid);return
        if record['kind']=='getme':
            profile,error=_profile(body)
            if not error and profile['id']==self.spec.account_uid:self.identity_uid=profile['id']
            else:self.identity_uid=''
            self.requests.pop(rid,None)
        else:
            record['body']=text
            self._settle(rid)

    def _settle(self,rid):
        record=self.requests.get(rid)
        if (not record or record['kind']!='post' or record['post'] is None or
                record['body'] is None):return
        outcome,comment_id,sender_uid=_response_result(record['body'],record['status'],self.spec,self.identity_uid)
        frozen={'tenant_id':self.spec.tenant_id,'cloud_owner':self.spec.cloud_owner,
                'device_id':self.spec.device_id,'account_id':self.spec.account_id,
                'account_uid':self.spec.account_uid,'note_id':self.spec.note_id,
                'target_comment_id':self.spec.target_comment_id,'content':record['post'],
                'platform_comment_id':comment_id,'sender_uid':sender_uid,
                'observed_at':record['at'],'outcome':outcome}
        digest=hashlib.sha256(json.dumps(frozen,ensure_ascii=False,sort_keys=True,
                                         separators=(',',':')).encode('utf-8')).hexdigest()
        frozen['snapshot_hash']=digest
        self.output.append(frozen)
        self.requests.pop(rid,None)

    def drain(self):
        result=list(self.output)
        self.output.clear()
        return result
