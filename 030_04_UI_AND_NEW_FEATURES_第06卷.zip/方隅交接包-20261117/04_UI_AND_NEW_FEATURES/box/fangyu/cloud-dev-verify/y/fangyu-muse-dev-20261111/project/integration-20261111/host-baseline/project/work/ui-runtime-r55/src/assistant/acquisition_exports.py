"""Authorized local handoff reconciliation exports, without contact plaintext.

Exporting a file is neither delivery nor an independent resource-department ACK.
Every row is projected from one current, authenticated SQLite read snapshot.
XLSX uses the pinned official XlsxWriter package vendored in this client only.
"""
from __future__ import annotations

import base64
from contextlib import nullcontext
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import unicodedata

from core.service_plans import require_feature
from .acquisition_operations import AcquisitionOperations, _digest, _fail, _ident


ACTION = 'handoff_export'
MAX_ROWS = 1000
PLATFORMS = {'xiaohongshu': '小红书', 'douyin': '抖音', 'zhihu': '知乎',
             'wechat_channels': '视频号', 'weixin': '视频号', 'bilibili': '哔哩哔哩',
             'bili': '哔哩哔哩', 'kuaishou': '快手'}
HEADERS = ('交接编号', '客户昵称', '平台', '来源核对编号', '接收部门', '资料用途',
           '交接阶段', '当前授权', '可继续准备交付', '历史独立接收记录',
           '本机记录版本', '更新时间（UTC）', '业务归属', '成交核验', '结算核验', '来源一致性')
BOUNDARY = '本机核对清单；不含手机号、微信号、平台联系引用或原始评论。不证明跨电脑送达、真实成交或分成到账。'


def _cell(value):
    text = str(value) if value is not None else ''
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
    if len(text) > 2000:
        _fail('EXPORT_CELL_LIMIT', '导出字段超长，请先核对记录')
    return text


def _csv_cell(value):
    text = _cell(value)
    # Excel may recognize formulas after tabs/spaces as well as at column start.
    return "'" + text if text.lstrip().startswith(('=', '+', '-', '@')) else text


def _public_label(value):
    """Do not export recognizable contacts hidden in otherwise free text."""
    text = unicodedata.normalize('NFKC', _cell(value))
    text = ''.join(char for char in text if unicodedata.category(char) not in ('Cc', 'Cf', 'Cs'))
    compact = ''.join(char for char in text if unicodedata.category(char)[0] not in ('P', 'Z'))
    sensitive = (re.search(r'\d{7,}', compact)
                 or re.search(r'(?:contact|platform|consent|evidence|notice|document)\s*:', text, re.I)
                 or re.search(r'(?:微信|wechat|weixin|wxid|手机号|电话)\s*[:：_号]?\s*[A-Za-z0-9]{3,}', text, re.I)
                 or re.search(r'(?<![A-Za-z0-9_])wx\s*[:：_号]\s*[A-Za-z0-9_-]{3,}', text, re.I)
                 or re.search(r'(?<![A-Za-z0-9_])Bearer\s+|sk-[\w-]{12}|(?:cookie|password|secret|api[_-]?key)\s*[:=]', text, re.I))
    if sensitive:
        _fail('EXPORT_PRIVATE_FIELD', '昵称、部门或用途含疑似联系方式或受保护引用，请先核对；本次未生成文件')
    return text


def _source_code(tenant, company_id, item):
    source = item.get('source') or {}
    identity = [tenant, company_id, source.get('platform'), source.get('author_id'),
                source.get('comment_id'), source.get('task_id'), source.get('original_text_hash')]
    return 'source:' + hashlib.sha256(json.dumps(identity, ensure_ascii=False,
                                               separators=(',', ':')).encode('utf-8')).hexdigest()


def _updated(stamp):
    if type(stamp) is not int or not 0 <= stamp <= 253402300799:
        return '时间待核对'
    return datetime.fromtimestamp(stamp, timezone.utc).isoformat(timespec='seconds')


def _row(tenant, company_id, item):
    authorization = item.get('current_authorization') or {}
    return tuple(map(_cell, (
        item['id'], _public_label(item.get('customer_display_name') or '已保存客户'),
        PLATFORMS.get((item.get('source') or {}).get('platform'), '来源平台待核对'),
        _source_code(tenant, company_id, item), _public_label(item.get('recipient_name') or '接收部门待核对'),
        _public_label(item.get('purpose')), item.get('status_text') or '待核对',
        authorization.get('status_text') or '当前授权待核对',
        '是（本机核验）' if item.get('eligible_for_delivery') else '否',
        '已登记（本机）' if item.get('historical_resource_receipt_verified') else '无已核验记录',
        item.get('revision'), _updated(item.get('updated_at')),
        '待业务核对', '未接入公司订单核验', '未接入真实结算',
        '当前来源一致（本机）' if item.get('export_source_verified') else '来源已变化，需重新核对')))


def _csv_bytes(rows):
    stream = io.StringIO(newline='')
    writer = csv.writer(stream, lineterminator='\r\n')
    writer.writerow(HEADERS)
    writer.writerows(tuple(_csv_cell(value) for value in row) for row in rows)
    return ('\ufeff' + stream.getvalue()).encode('utf-8')


def _xlsx_bytes(rows, metadata):
    try:
        import xlsxwriter
    except ImportError:
        _fail('EXPORT_DEPENDENCY', '本机Excel组件尚未安装，请使用CSV或核对本客户运行环境')
    expected_package = Path(__file__).resolve().parents[1] / 'xlsxwriter'
    if (xlsxwriter.__version__ != '3.2.9'
            or not Path(xlsxwriter.__file__).resolve().is_relative_to(expected_package)):
        _fail('EXPORT_DEPENDENCY', '本机Excel组件版本需核对')
    stream = io.BytesIO()
    workbook = xlsxwriter.Workbook(stream, {'in_memory': True, 'strings_to_formulas': False,
                                           'strings_to_urls': False, 'strings_to_numbers': False})
    sheet = workbook.add_worksheet('交接核对清单')
    header = workbook.add_format({'bold': True, 'font_color': '#FFFFFF', 'bg_color': '#14748A',
                                  'text_wrap': True, 'valign': 'vcenter'})
    body = workbook.add_format({'text_wrap': True, 'valign': 'top'})
    sheet.freeze_panes(1, 2)
    sheet.set_row(0, 32)
    sheet.set_column(0, 0, 34)
    sheet.set_column(1, 2, 18)
    sheet.set_column(3, 3, 76)
    sheet.set_column(4, len(HEADERS) - 1, 24)
    for col, value in enumerate(HEADERS):
        sheet.write_string(0, col, value, header)
    for number, row in enumerate(rows, 1):
        for col, value in enumerate(row):
            # Explicit literal string, including identifiers and formula-looking names.
            if sheet.write_string(number, col, value, body) != 0:
                _fail('EXPORT_ENCODING', 'Excel内容未完整写入，请重新核对')
    if rows:
        sheet.autofilter(0, 0, len(rows), len(HEADERS) - 1)
    notice = workbook.add_worksheet('范围与核验说明')
    notice.set_column(0, 0, 26)
    notice.set_column(1, 1, 100)
    for number, (label, value) in enumerate(metadata):
        notice.write_string(number, 0, label)
        notice.write_string(number, 1, _cell(value), body)
    workbook.close()
    return stream.getvalue()


class AcquisitionExports:
    def __init__(self, core, tenant, owner, company, *, lead_access=None):
        self.operations = AcquisitionOperations(core, tenant, owner, company, lead_access=lead_access)

    def execute(self, action, data, user):
        if action != ACTION or not isinstance(data, dict) or set(data) - {'format', 'mode', 'limit', 'ids'}:
            _fail('INVALID_INPUT', '导出操作或参数无效')
        output_format, mode = data.get('format', 'xlsx'), data.get('mode', 'delivery')
        limit = data.get('limit', MAX_ROWS)
        if output_format not in ('xlsx', 'csv') or mode not in ('delivery', 'audit'):
            _fail('INVALID_INPUT', '请选择Excel或CSV以及待交接/核对范围')
        if type(limit) is not int or not 1 <= limit <= MAX_ROWS:
            _fail('INVALID_INPUT', '每批导出数量需为1至1000，请分批核对')
        selected = data.get('ids')
        if selected is not None:
            if not isinstance(selected, list) or not 1 <= len(selected) <= MAX_ROWS or len(set(map(str, selected))) != len(selected):
                _fail('INVALID_INPUT', '所选交接编号需为不重复的有界列表')
            selected = {_ident(ident, '交接编号') for ident in selected}
        ops = self.operations
        with getattr(ops.core, 'lock', nullcontext()):
            require_feature(ops.company, 'export')
            if ops.company.get('id') != ops.company_id:
                _fail('FORBIDDEN', '企业配置已变化，请重新读取')
            policy = ops.company.get('acquisitionPolicy', {})
            ops.policy = json.loads(json.dumps(policy)) if isinstance(policy, dict) else {}
            with ops.core.store.connect() as db:
                db.execute('BEGIN')
                actor = ops._user(db, user)
                if actor.get('can_export') is False:
                    _fail('FORBIDDEN', '当前成员没有导出权限')
                events = ops._event_index(db)
                raw = ops._all(db, actor, event_index=events)
                withdrawals = ops._withdrawal_index(db)
                items = [ops._public(db, item, actor, withdrawal_index=withdrawals,
                                     history_events=events.get(item['id'], [])) for item in raw]
                for item in items:
                    lead = ops._source_lead(db, item, actor)
                    source = item.get('source') or {}
                    verified = (source.get('original_text_hash') == _digest(lead.get('text', ''))
                                and all(source.get(key) == lead.get(key) for key in
                                        ('platform', 'author_id', 'comment_id', 'task_id')))
                    item['export_source_verified'] = verified
                    if not verified:
                        item['eligible_for_delivery'] = False
                if selected is not None:
                    items = [item for item in items if item['id'] in selected]
                    if len(items) != len(selected):
                        _fail('EXPORT_SOURCE_UNAVAILABLE', '所选记录不在当前可导出范围，请重新读取')
                if mode == 'delivery':
                    eligible = [item for item in items if item.get('eligible_for_delivery') is True]
                    if selected is not None and len(eligible) != len(items):
                        _fail('EXPORT_SCOPE_CHANGED', '所选记录授权或交接阶段已变化，请重新读取')
                    items = eligible
                count = len(items)
                items = items[:limit]
                rows = [_row(ops.tenant, ops.company_id, item) for item in items]
                snapshot = hashlib.sha256(json.dumps(rows, ensure_ascii=False,
                                                    separators=(',', ':')).encode('utf-8')).hexdigest()
                metadata = [('记录范围', '当前授权有效且待送达的本机记录' if mode == 'delivery' else '当前账号有权查看的历史核对记录'),
                            ('说明', BOUNDARY), ('本批条数', len(rows)), ('范围内总条数', count),
                            ('是否仍有未导出记录', '是，请按明确记录编号分批' if count > limit else '否'),
                            ('内容核对SHA256', snapshot), ('校验边界', '内容Hash仅用于核对文件，不能替代独立接收、签名、订单或结算证明')]
                content = _xlsx_bytes(rows, metadata) if output_format == 'xlsx' else _csv_bytes(rows)
        return {'filename': f'交接核对清单_不含联系方式.{output_format}',
                'mime_type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if output_format == 'xlsx' else 'text/csv;charset=utf-8',
                'encoding': 'base64', 'content_base64': base64.b64encode(content).decode('ascii'),
                'sha256': hashlib.sha256(content).hexdigest(), 'snapshot_sha256': snapshot,
                'rows': len(rows), 'total_in_scope': count, 'has_more': count > limit,
                'mode': mode, 'contains_contact_plaintext': False, 'local_only': True,
                'cross_machine_verified': False, 'delivery_confirmed': False, 'message': BOUNDARY}
