"""Trusted local-owner archive over the original retained read and transaction.

The instance UUID is a local data boundary, never a cloud device or grant.
HTTP callers supply identifiers only; an owned workspace supplies this scope.
"""
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
import threading

from core import CoreError
from core.platform_reads import PlatformReadService
from .platform_receipt_archive import PlatformReceiptArchive, ReceiptArchiveError
from .self_operating_read import OwnerReadWorkspace, _OwnerReadInstance, _UID

_SEAL = object()


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


class _OwnerArchiveScope:
    def __init__(self, service, workspace, seal):
        if seal is not _SEAL or type(workspace) is not OwnerReadWorkspace or type(workspace.instance) is not _OwnerReadInstance:
            raise CoreError('来源归档需要可信自营实例')
        self._seal, self.service, self.workspace = seal, service, workspace
        self.server, self.core, self.instance = workspace.server, workspace.server.core, workspace.instance
        self.instance_id = self.instance.check()['selfOperatingRead']['instance_id']
        self.review = self.server._runtime_license_review_binding
        self._reads = None
        self._metadata = threading.local()

    def check(self, user=None, account=None):
        metadata = getattr(self._metadata, 'call', None)
        frame = metadata if metadata is not None else getattr(self.workspace._tls, 'call', None)
        if (self._seal is not _SEAL or self.server.core is not self.core
                or self.workspace.instance is not self.instance
                or self.server._self_operating_reads is not self.workspace
                or self._reads is None or self.workspace._reads is not self._reads
                or type(frame) is not tuple
                or metadata is not None and (len(frame) != 2 or getattr(self.workspace._tls, 'call', None) is not None)
                or metadata is None and (len(frame) not in (3, 4)
                    or frame[2] is not False or len(frame) == 4 and frame[3] is not False
                    or self.server._runtime_license_review_binding is not self.review
                    or self.review is None or not self.review.current(self.server.company))):
            raise CoreError('来源归档的当前自营范围已变化')
        saved = self.workspace._actor(frame[0])
        current = self.workspace._account(saved, frame[1]['id'], cleanup=metadata is not None)
        matched = (self._account_identity(current) == self._account_identity(frame[1])
                   if metadata is not None else current == frame[1])
        if (not matched or current['tenant_id'] != self._reads.tenant
                or saved['username'] != self._reads.owner
                or user is not None and any(user.get(key) != saved.get(key) for key in
                    ('id', 'tenant_id', 'username', 'role', 'cloud_bound', 'personal_owner'))
                or account is not None and (self._account_identity(account) != self._account_identity(current)
                    if metadata is not None else account != current)
                or metadata is not None and (type(current.get('platform_uid')) is not str
                    or _UID.fullmatch(current['platform_uid']) is None)):
            raise CoreError('来源归档的本人或账号绑定已变化')
        company = self.instance.check()
        if (company['selfOperatingRead']['instance_id'] != self.instance_id
                or self.core.store.directory != self.instance.directory / 'data'
                or self.core.deployment_config.get('id') != company['id']
                or self.core.deployment_config.get('edition') != 'owner'
                or self.core.deployment_config.get('personalMode') is not True):
            raise CoreError('来源归档不能接管其他实例数据')
        if metadata is None:
            self.workspace.execution_guard('xiaohongshu')
        return saved, current, frame[0]

    @staticmethod
    def _account_identity(account):
        return {key: account.get(key) for key in
            ('id', 'tenant_id', 'cloud_owner', 'platform', 'platform_uid', 'conn_id')}

    @contextmanager
    def metadata_call(self, token, account):
        if getattr(self._metadata, 'call', None) is not None or getattr(self.workspace._tls, 'call', None) is not None:
            raise CoreError('本机回执核对不能借用或嵌套平台执行范围')
        frame = (token, deepcopy(account))
        self._metadata.call = frame
        try:
            self.check()
            yield
        finally:
            if getattr(self._metadata, 'call', None) is frame:
                del self._metadata.call

    def require_action(self, action):
        if getattr(self._metadata, 'call', None) is not None and action != 'platform_read_archive_status':
            raise CoreError('本机回执核对不能用于新归档或平台执行')

    def guard(self):
        self.check()
        return True

    def origin_digest(self, user, account):
        self.require_action('platform_read_archive')
        saved, current, token = self.check(user, account)
        return _digest([self.instance_id, _digest(token), self._actor(saved), current])

    @staticmethod
    def _actor(user):
        return {key: user.get(key) for key in
            ('id', 'tenant_id', 'username', 'role', 'cloud_bound', 'personal_owner')}

    def receipt_binding(self, user):
        saved, current, _ = self.check(user)
        return {'schema': 'local_owner_archive_v2', 'local_instance_id': self.instance_id,
            'account_id': current['id'], 'account_digest': _digest(self._account_identity(current)),
            'actor_digest': _digest(self._actor(saved))}

    def check_receipt(self, user, binding):
        if binding != self.receipt_binding(user):
            raise CoreError('原归档回执的本机账号范围已变化')

    def store_source_trace(self, db, snapshot, batch_id, lead_ids, receipt_id, stamp, user):
        self.require_action('platform_read_archive')
        self.check(user)
        tracer = getattr(self.workspace, '_keyword_source_trace', None)
        if tracer is None:
            return
        from .owner_keyword_source_trace import OwnerKeywordSourceTrace
        if type(tracer) is not OwnerKeywordSourceTrace or tracer.workspace is not self.workspace:
            raise CoreError('关键词出处必须属于原自营实例，不能接管其他来源')
        tracer.store_archive(db, snapshot, batch_id, lead_ids, receipt_id, stamp, user)


class OwnerSourceArchive:
    """Created by the trusted OwnerReadWorkspace, never by HTTP data."""
    ACTIONS = PlatformReceiptArchive.ACTIONS

    def __init__(self, workspace):
        self.workspace = workspace
        self._scope = _OwnerArchiveScope(self, workspace, _SEAL)
        self._archive = None
        self._unknown_keys = set()

    def read_service_options(self):
        return {'device_id': self._scope.instance_id, 'archive_scope_guard': self._scope.guard,
                'owner_archive_scope': self._scope}

    def bind_read_service(self, reads):
        if (self._archive is not None or type(reads) is not PlatformReadService
                or reads.core is not self._scope.core or reads.device_id != self._scope.instance_id
                or reads._owner_archive_scope is not self._scope
                or self.workspace._reads is not reads):
            raise CoreError('归档必须绑定原自营读取服务，不能移交其他回执')
        self._scope._reads = reads
        self._archive = PlatformReceiptArchive(reads.core, reads.tenant, reads.owner,
            self.workspace.server.company, read_service=reads, device_id=self._scope.instance_id,
            scope_guard=self._scope.guard, owner_scope=self._scope)

    def execute(self, token, action, data):
        allowed = ({'account_id', 'idempotency_key'} if action == 'platform_read_archive_status'
                   else {'account_id', 'read_request_id', 'idempotency_key'})
        if self._archive is None or action not in self.ACTIONS or type(data) is not dict or set(data) != allowed:
            raise ReceiptArchiveError('INVALID_INPUT', '来源归档仅接受原账号、原读取和原归档编号')
        key = data['idempotency_key']
        self._archive._receipt_id(key)  # Original fixed identifier contract; no storage or authorization.
        # A recorded unknown outcome can only be queried by its original key.
        with self.workspace._lock:
            user = self.workspace._actor(token)
            if action == 'platform_read_archive_status':
                account = self.workspace._account(user, data['account_id'], cleanup=True)
                with self._scope.metadata_call(token, account):
                    try:
                        return self._archive.execute(action, {'idempotency_key': key}, user)
                    except ReceiptArchiveError as error:
                        if error.mutation_committed is None:
                            self._unknown_keys.add(key)
                        raise
            if action == 'platform_read_archive' and key in self._unknown_keys:
                raise ReceiptArchiveError('LOOKUP_REQUIRED', '原归档结果未知，请只核对原编号', mutation_committed=None)
            account = self.workspace._account(user, data['account_id'])
            with self.workspace._call(token, account):
                self._scope.check(user, account)
                fields = deepcopy(data)
                try:
                    return self._archive.execute(action, fields, user)
                except ReceiptArchiveError as error:
                    if error.mutation_committed is None:
                        self._unknown_keys.add(key)
                    raise
