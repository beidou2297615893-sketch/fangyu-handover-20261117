"""Local product write receipts and cancellation tombstones.

The authenticated gateway must authorize the current user, device and feature
before using this helper. ``run`` holds core.lock from begin through finish.
Manual begin/service/finish integration must hold that same lock throughout.
Service writes remain their own transactions: a crash after commit but before
finish is deliberately unknown, never a claim that no business write occurred.
No request payload, free text, contact value or exception text is persisted.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import re
import time

from core import CoreError


ENTITY = 'product_operation_receipts'
WRITE_ACTIONS = frozenset({'handoff_create', 'handoff_update', 'handoff_submit',
    'handoff_receipt', 'contact_create', 'strategy_save', 'strategy_import', 'intent_rules_save', 'source_intent_analyze_selected'})
_KEY = re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_ID = re.compile(r'(?:[A-Za-z][A-Za-z0-9_-]{0,159}|[a-f0-9]{32,64})\Z')
_CONTACT = re.compile(r'contact:[a-f0-9]{32}\Z')
_PLATFORM_CONTACT = re.compile(r'platform:[A-Za-z_][A-Za-z0-9_-]*:[A-Za-z_][A-Za-z0-9_-]{0,159}\Z')
_STATUS = re.compile(r'[a-z][a-z0-9_]{0,79}\Z')
_NUMBER_FIELDS = frozenset({'revision', 'original_revision', 'keyword_count',
    'enabled_keyword_count', 'active_batch_size', 'total_query_quota', 'queries_spent',
    'queries_reserved', 'queries_remaining', 'cursor', 'cycle', 'added', 'updated',
    'skipped', 'imported', 'import_rows', 'duplicates', 'duplicate_count', 'inserted', 'accepted_count', 'total'})
_BOOL_FIELDS = frozenset({'local_only', 'cross_machine_verified', 'resource_receipt_verified',
    'enabled', 'can_manage', 'scheduler_only', 'platform_requests_started', 'lease_active',
    'replayed', 'can_edit', 'can_submit', 'can_withdraw', 'can_dispute', 'can_receipt',
    'can_review', 'can_create', 'resource_receiver_configured'})
_ENUM_FIELDS = frozenset({'status', 'qualification', 'attribution_status', 'delivery_status',
    'storage_scope', 'quota_unit', 'policy_status'})
_ID_FIELDS = frozenset({'id', 'lead_id', 'recipient_id', 'strategy_id'})
_STAMP = re.compile(r'\d{4}-\d{2}-\d{2}T[0-9:.+-]+(?:Z)?\Z')


class ProductReceiptError(CoreError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = 'PRODUCT_OPERATION_' + code
        self.mutation_committed = False


def _encoded(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                          allow_nan=False)
    except (ValueError, TypeError):
        raise ProductReceiptError('INVALID_INPUT', '操作参数无效') from None


def _hash(value):
    return hashlib.sha256(_encoded(value).encode('utf-8')).hexdigest()


def protected_projection(result):
    """Bounded allowlist, suitable for replay after the gateway reauthorizes.

    The client refreshes detail/get endpoints for current names, permissions and
    consent. Results do not copy phone/WeChat, masks, keywords or free-form text.
    """
    if not isinstance(result, dict):
        raise TypeError('产品写入结果必须是对象')
    projected = {}
    for key, value in result.items():
        if key in _ID_FIELDS and isinstance(value, str) and _ID.fullmatch(value):
            projected[key] = value
        elif key == 'contact_reference' and isinstance(value, str) and (_CONTACT.fullmatch(value) or _PLATFORM_CONTACT.fullmatch(value)):
            projected[key] = value
        elif key in _NUMBER_FIELDS and type(value) is int and 0 <= value <= 2 ** 53 - 1:
            projected[key] = value
        elif key in _BOOL_FIELDS and type(value) is bool:
            projected[key] = value
        elif key in _ENUM_FIELDS and isinstance(value, str) and _STATUS.fullmatch(value):
            projected[key] = value
        elif key in ('created_at', 'updated_at', 'revoked_at') and (value is None or
                (type(value) in (int, float) and math.isfinite(value) and value >= 0) or
                (isinstance(value, str) and _STAMP.fullmatch(value))):
            projected[key] = value
        elif key in ('item', 'permissions') and isinstance(value, dict):
            projected[key] = protected_projection(value)
        elif key == 'counts' and isinstance(value, dict):
            projected[key] = {name: count for name, count in value.items()
                if isinstance(name, str) and _STATUS.fullmatch(name) and type(count) is int and 0 <= count <= 2 ** 53 - 1}
        elif key == 'receipt_recipients' and isinstance(value, list) and len(value) <= 100:
            projected[key] = [ident for ident in value if isinstance(ident, str) and _ID.fullmatch(ident)]
    return projected


class ProductOperationReceipts:
    def __init__(self, core, tenant, owner):
        if not isinstance(tenant, str) or not tenant or not isinstance(owner, str) or not owner:
            raise ValueError('本机操作回执归属无效')
        self.core, self.tenant, self.owner = core, tenant, owner
        self._pending = None

    def _identity(self, action, key):
        if action not in WRITE_ACTIONS or not isinstance(key, str) or not _KEY.fullmatch(key):
            raise ProductReceiptError('INVALID_INPUT', '请使用有效的产品写入动作与原操作编号')
        return _hash([self.tenant, self.owner, action, key])

    def _read(self, db, ident, action, key):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (ENTITY, ident, self.tenant)).fetchone()
        if not row:
            return None
        item = json.loads(row['body'])
        if any(item.get(field) != value for field, value in (
                ('id', ident), ('tenant_id', self.tenant), ('cloud_owner', self.owner),
                ('original_action', action), ('idempotency_key', key))):
            raise ProductReceiptError('INVALID_RECORD', '本机操作回执归属不一致，请人工核对')
        if item.get('state') not in ('started', 'succeeded', 'rejected', 'cancelled', 'unknown'):
            raise ProductReceiptError('INVALID_RECORD', '本机操作回执状态无效，请人工核对')
        return item

    def _put(self, db, record, *, new=False):
        if new:
            db.execute('INSERT INTO records VALUES(?,?,?,?)',
                       (ENTITY, record['id'], self.tenant, _encoded(record)))
        else:
            changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (_encoded(record), ENTITY, record['id'], self.tenant)).rowcount
            if changed != 1:
                raise RuntimeError('本机操作回执丢失')

    @staticmethod
    def _view(record, *, replayed=True, should_execute=False):
        state = record['state']
        result = {'operation_id': record['id'], 'original_action': record['original_action'],
            'idempotency_key': record['idempotency_key'], 'state': state,
            'mutation_committed': True if state == 'succeeded' else False if state in ('rejected', 'cancelled') else None,
            'should_execute': should_execute, 'replayed': replayed,
            'local_only': True, 'cross_machine_verified': False}
        if state == 'succeeded':
            result['result'] = protected_projection(record.get('result', {}))
            result['refresh_required'] = True
        elif state in ('rejected', 'cancelled', 'unknown'):
            result['error_code'] = ('PRODUCT_OPERATION_CANCELLED' if state == 'cancelled' else
                'PRODUCT_OPERATION_REJECTED' if state == 'rejected' else 'PRODUCT_OPERATION_UNKNOWN')
        return result

    def begin(self, action, key, payload):
        """Start once; caller may execute ONLY when should_execute is true."""
        ident = self._identity(action, key)
        if not isinstance(payload, dict) or payload.get('idempotency_key') != key:
            raise ProductReceiptError('INVALID_INPUT', '操作编号与请求不一致')
        digest = _hash(payload)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            item = self._read(db, ident, action, key)
            if item:
                if item.get('payload_digest') not in (None, digest):
                    raise ProductReceiptError('KEY_CONFLICT', '原操作编号已绑定不同请求，请核对后使用新编号')
                return self._view(item)
            if self._pending is not None:
                raise ProductReceiptError('BUSY', '本机操作尚未结束，请先核对')
            item = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                'original_action': action, 'idempotency_key': key, 'payload_digest': digest,
                'state': 'started', 'created_at': time.time(), 'updated_at': time.time()}
            self._put(db, item, new=True)
        self._pending = deepcopy(item)
        return self._view(item, replayed=False, should_execute=True)

    def _finish(self, state, result=None):
        if self._pending is None:
            raise ProductReceiptError('NOT_STARTED', '尚未开始本机操作')
        pending = self._pending
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            item = self._read(db, pending['id'], pending['original_action'], pending['idempotency_key'])
            if not item or item['state'] != 'started' or item.get('payload_digest') != pending['payload_digest']:
                raise RuntimeError('本机操作状态已变化，结果需要人工核对')
            item.update(state=state, updated_at=time.time())
            if state == 'succeeded':
                item['result'] = protected_projection(result)
            self._put(db, item)
        self._pending = None
        return self._view(item, replayed=False)

    def finish(self, result):
        """Persist a protected success projection after the service returns."""
        return self._finish('succeeded', result)

    def fail(self, error):
        """Call for the SERVICE exception, never for a failed finish/transport.

        Only a service's explicit mutation_committed=False is a safe rejection.
        A CoreError/ValueError can occur after commit too, so its type conveys no
        outcome. No exception text is stored.
        """
        return self._finish('rejected' if getattr(error, 'mutation_committed', None) is False else 'unknown')

    def status(self, action, key):
        """Absent operations are atomically cancelled before reporting absence."""
        ident = self._identity(action, key)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            item = self._read(db, ident, action, key)
            if item is None:
                item = {'id': ident, 'tenant_id': self.tenant, 'cloud_owner': self.owner,
                    'original_action': action, 'idempotency_key': key, 'payload_digest': None,
                    'state': 'cancelled', 'created_at': time.time(), 'updated_at': time.time()}
                self._put(db, item, new=True)
            return self._view(item)

    def run(self, action, payload, service):
        """Convenience integration; callback must implement an atomic service."""
        with self.core.lock:
            begun = self.begin(action, payload.get('idempotency_key') if isinstance(payload, dict) else None, payload)
            if not begun['should_execute']:
                return begun
            try:
                result = service()
            except Exception as error:
                return self.fail(error)
            # Never classify finish failure as a rejected service. Its durable
            # started receipt keeps both retries and status conservatively locked.
            return self.finish(result)
