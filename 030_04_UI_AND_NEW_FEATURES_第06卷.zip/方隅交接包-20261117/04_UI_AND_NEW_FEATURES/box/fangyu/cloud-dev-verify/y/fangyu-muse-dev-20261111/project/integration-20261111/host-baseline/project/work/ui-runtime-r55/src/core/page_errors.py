"""Fixed, local page-route errors safe to classify at the assistant boundary."""


class CoreError(ValueError):
    pass


class PageOperationFailure(CoreError):
    """Trusted wrapper around a fixed page code; never carries provider text."""

    def __init__(self, code):
        self.code = code if type(code) is str and code in PAGE_ERROR_MESSAGES else 'page_unavailable'
        super().__init__('网页采集暂不可用，已停止；无需重新扫码')

    def __str__(self):
        return '网页采集暂不可用，已停止；无需重新扫码'


PAGE_ERROR_MESSAGES = {
    'pagination_unknown': '搜索页面仍在加载，采集断点已保留；请稍后继续',
    'pagination_unavailable': '当前评论续读未完成，断点已保留；无需重新扫码',
    'comment_scroll_unavailable': '评论页面暂未加载完整，断点已保留；无需重新扫码',
    'search_scroll_unavailable': '搜索页面暂未加载完整，断点已保留；无需重新扫码',
    'body_unavailable': '网页读取未完成，断点已保留；无需重新扫码',
    'body_stale': '网页读取结果已过期，断点已保留；无需重新扫码',
    'response_scope_invalid': '网页读取结果与当前任务不一致，已停止；无需重新扫码',
    'request_scope_invalid': '网页读取请求与当前任务不一致，已停止；无需重新扫码',
    'page_client_unavailable': '网页采集组件未就绪，请管理员检查；无需重新扫码',
    'helper_start_failed': '网页采集窗口未能启动，请管理员检查；无需重新扫码',
    'helper_exited': '网页采集窗口已退出，请管理员检查；无需重新扫码',
    'connect_timeout': '网页采集窗口连接超时，请管理员检查；无需重新扫码',
    'ipc_start_failed': '网页采集连接未能启动，请管理员检查；无需重新扫码',
    'spec_failed': '网页采集连接准备失败，请管理员检查；无需重新扫码',
    'invalid_result': '网页采集返回结果无法识别，已停止；无需重新扫码',
    'invalid_response': '网页采集返回结果无法识别，已停止；无需重新扫码',
    'invalid_request': '网页采集请求参数无效，请管理员检查；无需重新扫码',
    'origin_invalid': '网页采集页面来源无法确认，已停止；无需重新扫码',
    'document_changed': '网页采集页面已变化，已停止；请核对当前页面',
    'timeout': '网页采集请求超时，已保留任务断点；请核对页面状态',
    'guard_rejected': '网页采集安全检查未通过，已停止；请核对账号状态',
    'platform_rejected': '本次网页采集请求被拒绝，已保留任务断点',
    'page_rejected': '本次网页采集请求未完成，已保留任务断点',
    'axios_rejected': '本次网页采集请求未完成，已保留任务断点',
    'response_oversize': '网页采集结果超出限制，已保留任务断点',
    'source_mismatch': '笔记来源与已保存断点不一致，已停止采集',
    'identity_unverified': '网页账号身份暂无法确认，已停止采集',
    'helper_alive': '旧采集窗口尚未退出，请稍后重试',
    'paused': '网页采集连接已暂停，请核对页面状态',
    'cancelled': '网页采集请求已取消，任务断点已保留',
    'unsafe_path': '账号目录安全检查未通过，请管理员检查',
}
