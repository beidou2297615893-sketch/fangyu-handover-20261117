"""Private host request -> exact local task receipt; no discovery or execution."""
from datetime import datetime,timezone
import hashlib,json,re
from copy import deepcopy

ENTITY='workbench_acquisition_receipt_v1'
SCHEMA='workbench-acquisition-binding/1'

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()

def stamp(value):
    parsed=datetime.fromisoformat(value)
    if parsed.tzinfo is None:raise ValueError('receipt_time_invalid')
    return parsed.astimezone(timezone.utc)

def make_binding(record,payload):
    return {'schema':SCHEMA,'requestId':record['requestId'],'requestRecordId':record['id'],
        'signature':record['signature'],'storeId':record['storeId'],
        'profileDigest':record.get('profileDigest'),'batchOffset':record['batchOffset'],
        'batchEnd':record['batchEnd'],'totalEligible':record['totalEligible'],
        'created_at':record['created_at'],'keywordsDigest':digest(record['keywordBatch']),
        'payloadDigest':digest(payload)}

def validate_binding(binding,payload):
    try:
        keys={'schema','requestId','requestRecordId','signature','storeId','profileDigest',
              'batchOffset','batchEnd','totalEligible','created_at','keywordsDigest','payloadDigest'}
        if type(binding) is not dict or set(binding)!=keys or binding['schema']!=SCHEMA:return False
        for key in ('requestRecordId','signature','keywordsDigest','payloadDigest'):
            if not isinstance(binding[key],str) or not re.fullmatch('[a-f0-9]{64}',binding[key]):return False
        if (not isinstance(binding['requestId'],str) or not re.fullmatch('[A-Za-z0-9_-]{16,80}',binding['requestId'])
                or binding['storeId']!=payload.get('storeId')
                or binding['keywordsDigest']!=digest(payload.get('keywords'))
                or binding['payloadDigest']!=digest(payload)):
            return False
        if binding['profileDigest'] is not None and (not isinstance(binding['profileDigest'],str)
                or not re.fullmatch('[a-f0-9]{64}',binding['profileDigest'])):return False
        start,end,total=(binding[key] for key in ('batchOffset','batchEnd','totalEligible'))
        if (any(type(value) is not int for value in (start,end,total))
                or not 0<=start<end<=total or end-start!=len(payload['keywords']) or end-start>100):return False
        stamp(binding['created_at'])
        return True
    except (ValueError,TypeError,KeyError,OverflowError):return False

def task_digest(task):
    keys=('id','tenant_id','cloud_owner','store_id','platform','account_id','created_at','keywords','scope',
          'continuous_enabled','comment_keyword_mode','unknown_policy','daily_limit','target_count',
          'comment_date_range','region','city','area','date_from','date_to','excludes','intent_mode')
    return digest({key:task.get(key) for key in keys})

def prepared_receipt(user,task,binding):
    return {'id':task['id'],'tenant_id':user['tenant_id'],'owner':user['username'],
        'store_id':task['store_id'],'platform':task['platform'],'account_id':task['account_id'],
        'binding':deepcopy(binding),'taskConditionsDigest':task_digest(task),
        'state':'prepared','created_at':datetime.now(timezone.utc).isoformat(),
        'task_created_at':task['created_at']}

def matches_receipt(receipt,record,task):
    try:
        payload=record['launchConditions'];binding=record['requestBinding']
        if not validate_binding(binding,payload) or make_binding(record,payload)!=binding:return False
        if (type(receipt) is not dict or type(task) is not dict or receipt.get('state')!='started'
                or receipt.get('binding')!=binding or task_digest(task)!=receipt.get('taskConditionsDigest')):return False
        expected=(task['id'],record['tenant_id'],record['owner'],record['storeId'],
                  payload['platform'],payload['accountId'])
        if tuple(receipt.get(key) for key in ('id','tenant_id','owner','store_id','platform','account_id'))!=expected:return False
        if tuple(task.get(key) for key in ('id','tenant_id','cloud_owner','store_id','platform','account_id'))!=expected:return False
        if digest(task.get('keywords'))!=binding['keywordsDigest']:return False
        created=stamp(record['created_at']);saved=stamp(receipt['created_at']);started=stamp(receipt['started_at'])
        return (created<=saved<=started and 0<=(started-created).total_seconds()<=120
            and receipt['task_created_at']==task['created_at'])
    except (ValueError,TypeError,KeyError,OverflowError):return False
