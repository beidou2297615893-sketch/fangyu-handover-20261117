"""Owner-scoped intent rules with atomic version history and offline preview.

Trusted company policy is captured at construction. No client can self-grant
management, supply a comment as a persisted lead, or trigger provider/platform
calls here. Integration hooks are server-only and must not become public APIs.
"""
import json
import re
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone

from core.intent_policy import (IntentPolicyError, LEVELS, POLICY_VERSION, apply_intent_policy,
                                facts_summary, normalize_policy, policy_digest)

ENTITY = 'intent_rule_policies'
HISTORY = 'intent_rule_policy_history'
OPERATIONS = 'intent_rule_operations'
ACTIONS = frozenset(('intent_rules_get', 'intent_rules_save', 'intent_rules_history', 'intent_rules_preview'))


class IntentRulePermissionError(IntentPolicyError):
    code = 'INTENT_RULES_FORBIDDEN'


class IntentRuleConflict(IntentPolicyError):
    code = 'INTENT_RULES_REVISION_CONFLICT'


def _reject(error):
    # Only known pre-commit validations/rolled-back transactions. Database or
    # transport exceptions do not inherit a claim that nothing was committed.
    error.mutation_committed = False
    return error


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _integer(value, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise _reject(IntentPolicyError('页码或版本参数格式无效'))
    return value


class IntentRuleManagement:
    def __init__(self, core, tenant, owner, company):
        if (not isinstance(tenant, str) or not tenant or not isinstance(owner, str)
                or not owner or not isinstance(company, dict)):
            raise _reject(IntentPolicyError('规则归属或可信公司配置格式无效'))
        self.core, self.tenant, self.owner = core, tenant, owner
        self.company = deepcopy(company)
        self.ident = policy_digest(['intent-policy-v1', tenant, owner])

    @contextmanager
    def _transaction(self):
        with self.core.lock:
            with self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                yield db

    def _get(self, db, entity, ident):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (entity, ident, self.tenant)).fetchone()
        return json.loads(row['body']) if row else None

    @staticmethod
    def _put(db, entity, record):
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                   (entity, record['id'], record['tenant_id'],
                    json.dumps(record, ensure_ascii=False, separators=(',', ':'), allow_nan=False)))

    def _authorize(self, db, user, private=False):
        if not isinstance(user, dict) or not isinstance(user.get('id'), str):
            raise _reject(IntentRulePermissionError('规则需要有效员工身份'))
        current = self._get(db, 'users', user['id'])
        identity = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
        if (not isinstance(current, dict) or current.get('disabled')
                or any(current.get(key) != user.get(key) for key in identity)
                or current.get('tenant_id') != self.tenant or current.get('username') != self.owner
                or current.get('role') not in ('admin', 'operator')):
            raise _reject(IntentRulePermissionError('员工身份或规则归属已变化'))
        trusted = self.company.get('acquisitionStrategy', {})
        owners = trusted.get('operatorOwners', []) if isinstance(trusted, dict) else []
        valid = isinstance(owners, list) and all(isinstance(item, str) and item for item in owners)
        manager = current['role'] == 'admin' or (current.get('cloud_bound') is True and valid and self.owner in owners)
        if current['role'] == 'operator' and current.get('cloud_bound') is not True:
            raise _reject(IntentRulePermissionError('规则需要绑定员工身份'))
        if private and not manager:
            raise _reject(IntentRulePermissionError('规则与公寓资料仅限可信策略管理员'))
        actor = policy_digest({key: current.get(key) for key in identity})
        return manager, actor

    def _load(self, db):
        value = self._get(db, ENTITY, self.ident)
        if value is None:
            policy = normalize_policy({})
            return {'id': self.ident, 'tenant_id': self.tenant, 'owner': self.owner,
                    'revision': 0, 'policy': policy, 'digest': policy_digest(policy),
                    'created_at': '', 'updated_at': '', 'actor_id': ''}
        if (value.get('id') != self.ident or value.get('tenant_id') != self.tenant
                or value.get('owner') != self.owner or type(value.get('revision')) is not int
                or value['revision'] < 1):
            raise _reject(IntentRulePermissionError('规则存储归属无效'))
        policy = normalize_policy(value.get('policy'))
        if value.get('digest') != policy_digest(policy):
            raise _reject(IntentPolicyError('规则摘要不一致，请核对版本'))
        return {**value, 'policy': policy}

    @staticmethod
    def _summary(value, manager):
        facts = facts_summary(value['policy'])
        return {'name': value['policy']['name'], 'revision': value['revision'],
                'enabled': value['policy']['enabled'], 'can_manage': manager,
                'digest': value['digest'], 'validation_version': POLICY_VERSION,
                'updated_at': value['updated_at'], **facts,
                'missing_data_state': 'needs_facts' if not facts['usable_fact_count'] else 'needs_review',
                'historical_grades_rewritten': False, 'provider_requests_started': False}

    def snapshot(self, user):
        """SERVER ONLY: freeze verified actor + rule revision before analysis."""
        with self._transaction() as db:
            _, actor = self._authorize(db, user)
            value = self._load(db)
            return {'tenant_id': self.tenant, 'owner': self.owner, 'revision': value['revision'],
                    'digest': value['digest'], 'policy': deepcopy(value['policy']), 'actor_fingerprint': actor}

    def assert_snapshot(self, snapshot, user):
        """SERVER ONLY: recheck inside caller's core.lock before any AI write.

        Caller must keep that same lock through cache/history/lead persistence;
        otherwise another save could race after this method returns.
        """
        with self._transaction() as db:
            _, actor = self._authorize(db, user)
            current = self._load(db)
            if (not isinstance(snapshot, dict) or snapshot.get('tenant_id') != self.tenant
                    or snapshot.get('owner') != self.owner or snapshot.get('actor_fingerprint') != actor
                    or snapshot.get('revision') != current['revision']
                    or snapshot.get('digest') != current['digest']
                    or policy_digest(snapshot.get('policy')) != current['digest']):
                raise _reject(IntentRuleConflict('意向规则或员工身份已变化，请重新分析'))
            return True

    def _preview(self, db, data, user, value):
        ident = data.get('lead_id')
        if not isinstance(ident, str) or not ident or len(ident) > 160:
            raise _reject(IntentPolicyError('请选择已保存线索'))
        lead = self._get(db, 'leads', ident)
        task = self._get(db, 'tasks', lead.get('task_id')) if isinstance(lead, dict) else None
        if (not isinstance(lead, dict) or not isinstance(task, dict)
                or lead.get('id') != ident or lead.get('tenant_id') != self.tenant
                or lead.get('cloud_owner') != self.owner or task.get('tenant_id') != self.tenant
                or task.get('cloud_owner') != self.owner or task.get('id') != lead.get('task_id')):
            raise _reject(IntentRulePermissionError('线索或来源任务无权读取'))
        access = getattr(self.core, '_task_access', None)
        if callable(access):
            try:
                access(user, task, self.tenant)
            except (ValueError, PermissionError) as exc:
                raise _reject(IntentRulePermissionError('来源任务权限已变化')) from exc
        source = lead.get('manual_intent') or lead.get('ai_intent')
        source = source if isinstance(source, dict) else {}
        row = {key: deepcopy(source[key]) for key in ('status', 'level', 'reason', 'evidence', 'region_status',
                                                     'content_region', 'key_info', 'rules_version') if key in source}
        row.setdefault('status', 'graded' if row.get('level') in LEVELS else 'uncertain')
        row.setdefault('level', None)
        row.setdefault('reason', '尚未分析或缺少本人依据，需人工核对')
        row.setdefault('evidence', [])
        row.setdefault('region_status', 'unknown')
        row.setdefault('content_region', '')
        row.setdefault('key_info', [])
        context = {'post': {'title': lead.get('content_title', '')}}
        comment = {**lead, 'is_post_author': bool(lead.get('author_id') and lead.get('content_author_id')
                                                and lead['author_id'] == lead['content_author_id'])}
        strict = apply_intent_policy(comment, row, value['policy'], context=context)
        # Return old grade untouched and show the NEW guard's findings separately.
        projection = apply_intent_policy(comment, row, value['policy'], context=context, legacy=True)
        return {'lead_id': ident, 'revision': value['revision'], 'preview_only': True, 'persisted': False,
                'source': 'manual' if lead.get('manual_intent') else 'ai', 'result': projection,
                'validation_preview': strict['policy_validation'], 'matching_preview': strict['property_match'],
                'provider_requests_started': False}

    def execute(self, action, data, user):
        if action not in ACTIONS or not isinstance(data, dict):
            raise _reject(IntentPolicyError('意向规则操作或参数无效'))
        allowed = {'intent_rules_get': set(), 'intent_rules_save': {'policy', 'expected_revision', 'idempotency_key'},
                   'intent_rules_history': {'offset', 'limit'}, 'intent_rules_preview': {'lead_id'}}[action]
        if set(data) - allowed:
            raise _reject(IntentPolicyError('意向规则含不支持的操作字段'))
        try:
            if len(json.dumps(data, ensure_ascii=False, allow_nan=False).encode('utf-8')) > 512 * 1024:
                raise IntentPolicyError('意向规则请求过大')
        except (ValueError, TypeError, UnicodeError) as exc:
            raise _reject(IntentPolicyError('意向规则请求格式无效')) from exc
        with self._transaction() as db:
            manager, actor = self._authorize(db, user, private=action in ('intent_rules_save', 'intent_rules_history'))
            value = self._load(db)
            if action == 'intent_rules_get':
                result = {'summary': self._summary(value, manager)}
                if manager:
                    result['policy'] = deepcopy(value['policy'])
                return result
            if action == 'intent_rules_preview':
                return self._preview(db, data, user, value)
            if action == 'intent_rules_history':
                offset = _integer(data.get('offset', 0), 0, 1000000)
                limit = _integer(data.get('limit', 20), 1, 50)
                rows = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?', (HISTORY, self.tenant)).fetchall()
                items = [json.loads(row['body']) for row in rows]
                items = sorted((item for item in items if item.get('policy_id') == self.ident
                                and item.get('owner') == self.owner and item.get('tenant_id') == self.tenant),
                               key=lambda item: item['revision'], reverse=True)
                return {'items': deepcopy(items[offset:offset + limit]), 'total': len(items), 'offset': offset, 'limit': limit}
            token = data.get('idempotency_key')
            if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,128}', token):
                raise _reject(IntentPolicyError('幂等键须为8到128位字母数字、下划线或连字符'))
            operation_id = policy_digest([self.ident, token])
            fingerprint = policy_digest([action, data])
            previous = self._get(db, OPERATIONS, operation_id)
            if previous:
                if (previous.get('owner') != self.owner or previous.get('actor_fingerprint') != actor
                        or previous.get('fingerprint') != fingerprint):
                    raise _reject(IntentPolicyError('幂等键已用于不同请求或员工身份'))
                return deepcopy(previous['response'])
            revision = _integer(data.get('expected_revision'), 0, 2 ** 53 - 1)
            if revision != value['revision']:
                raise _reject(IntentRuleConflict('规则版本已变化，请刷新后重试'))
            try:
                policy = normalize_policy(data.get('policy'))
            except IntentPolicyError as exc:
                raise _reject(exc)
            stamp = _stamp()
            current = {**value, 'policy': policy, 'revision': revision + 1, 'digest': policy_digest(policy),
                       'updated_at': stamp, 'created_at': value['created_at'] or stamp, 'actor_id': user['id']}
            history = {**deepcopy(current), 'policy_id': self.ident,
                       'id': policy_digest([self.ident, current['revision']])}
            response = {'revision': current['revision'], 'digest': current['digest'], 'updated_at': stamp,
                        'mutation_committed': True, 'historical_grades_rewritten': False}
            self._put(db, ENTITY, current)
            self._put(db, HISTORY, history)
            self._put(db, OPERATIONS, {'id': operation_id, 'tenant_id': self.tenant, 'owner': self.owner,
                                      'actor_fingerprint': actor, 'fingerprint': fingerprint,
                                      'response': response, 'created_at': stamp})
            return response
