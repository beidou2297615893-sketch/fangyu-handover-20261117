"""Fixed app subprocess entries; authorization remains in private job scopes.

These entries run only an owned helper. They do not create a workspace server,
enable platform access, change release policy, or accept arbitrary commands.
"""
from pathlib import Path


def _absolute(value):
    return (isinstance(value,str) and value and not any(ord(c)<32 for c in value)
            and Path(value).is_absolute())


def dispatch_owned_helper(argv, *, page=None, login=None, tracked_reply=None):
    if not argv or not isinstance(argv[0],str):
        return None
    if argv[0].startswith('--owned-weibo-'):
        if argv[0]!='--owned-weibo-ipc-helper' or list(argv[1:]) not in ([],['--probe-ipc']):return 2
        from .owned_weibo_ipc import main
        return main(list(argv[1:]))
    if not argv[0].startswith('--owned-xhs-'):return None
    mode=argv[0]
    args=list(argv[1:])
    if mode=='--owned-xhs-cli-pages':
        if args:return 2
        from .xhs_cli_page_worker import main
        return main()
    if mode=='--owned-xhs-page-helper':
        if (len(args)!=4 or args[0:4:2]!=['--bridge-spec','--profile-dir'] or
                not all(_absolute(value) for value in args[1:4:2])):return 2
        if page is None:
            from xhs_page_window import main as page
        return page(args)
    if mode=='--owned-xhs-login-helper':
        natural=bool(args and args[-1]=='--natural-identity')
        fixed=args[:-1] if natural else args
        if (len(fixed)!=7 or fixed[0]!='--live' or
                fixed[1:7:2]!=['--staging-dir','--cancel-file','--profile-dir'] or
                not all(_absolute(value) for value in fixed[2:7:2]) or
                Path(fixed[4])!=Path(fixed[2])/'cancel.flag'):
            return 2
        if login is None:
            from .browser_login_window import main as login
        return login(args)
    if mode=='--owned-xhs-tracked-reply-helper':
        if len(args)!=2 or args[0]!='--spec' or not _absolute(args[1]):return 2
        if tracked_reply is None:
            from .tracked_reply_window_helper import main as tracked_reply
        return tracked_reply(args)
    return 2
