"""Source-only owner shutdown proof, consumed under the original main mutex.

This module grants no platform operation and persists no idle/closed assertion.
The writer review pin is intentionally empty until Root reviews the actual code.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
import hashlib
import os
import re
import stat
import sys
import threading
import time
import types
import json
import sqlite3


_SEAL = object()
_WRITER_MODULE = 'assistant.owner_instance_platform_upgrade_writer'
_WRITER_INTERFACE = 'owner_instance_platform_upgrade_writer_v1'
_REVIEWED_UPGRADE_WRITER_SHA256 = 'C9B555C5A1E783C24ED20BABAAB00A92CA85371F0D246F82DB016395A387EEC2'  # Root's reviewed CODE pin; not a license.


class OwnerClosePending(RuntimeError):
    def __init__(self, code='OWNER_CLOSE_PENDING'):
        self.code = code
        super().__init__('原工作台资源仍在收尾，请稍后再次正常关闭')


@dataclass(frozen=True)
class _OwnerClosedContext:
    instance: object
    server: object
    core: object
    data_dir: Path
    lock_path: Path
    instance_id: str
    from_schema: str
    pid: int
    owner_thread_id: int
    upgrade_source_sha256: str | None
    close_mode: str
    recovery_key: str | None


def _plain_file(path):
    value = path.lstat()
    if (not stat.S_ISREG(value.st_mode) or path.is_symlink() or value.st_nlink != 1
            or getattr(value, 'st_file_attributes', 0)
            & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
        raise OwnerClosePending()
    return value.st_dev, value.st_ino


def require_reviewed_writer(module):
    """Read-only loaded CODE binding; neither a close proof nor a license."""
    expected = Path(__file__).parent / 'owner_instance_platform_upgrade_writer.py'
    from .self_operating_read import _plain_directory
    _plain_directory(expected.parent, Path(expected.anchor))
    if (not re.fullmatch(r'[0-9A-F]{64}', _REVIEWED_UPGRADE_WRITER_SHA256)
            or type(module) is not types.ModuleType or module.__name__ != _WRITER_MODULE
            or sys.modules.get(_WRITER_MODULE) is not module
            or Path(getattr(module, '__file__', '')) != expected
            or getattr(module, 'WRITER_INTERFACE', None) != _WRITER_INTERFACE
            or getattr(module, 'LOADED_SOURCE_SHA256', None) != _REVIEWED_UPGRADE_WRITER_SHA256):
        raise OwnerClosePending('WRITER_CODE_REVIEW_PENDING')
    before = _plain_file(expected)
    if (hashlib.sha256(expected.read_bytes()).hexdigest().upper() != _REVIEWED_UPGRADE_WRITER_SHA256
            or _plain_file(expected) != before):
        raise OwnerClosePending('WRITER_CODE_CHANGED')
    return _REVIEWED_UPGRADE_WRITER_SHA256


def _recovery_metadata(server, instance_id):
    """Only owner/account identifiers and original R13 cleanup/custody hashes.

    No session, password, Cookie, source text or contact field is selected. The
    original R13 pure row validators are reused as a read-only negative gate;
    this small view is not an OwnerWebContactObservation execution instance.
    """
    from .owner_web_contact_observation import (OwnerWebContactObservation,
        ATTEMPTS, HEADS, CUSTODY)
    from .self_operating_read import _plain_directory
    instance = server.self_operating_instance
    path = server.core.store.path
    _plain_directory(path.parent, instance.work_root)
    before = _plain_file(path)
    if path.parent != instance.directory / 'data':
        raise OwnerClosePending()
    iid = instance_id  # Retained original identity; never old v1.check after CAS.
    class MetadataView:
        _saved = OwnerWebContactObservation._saved
        _validate_attempt = OwnerWebContactObservation._validate_attempt
        _base = OwnerWebContactObservation._base
        _key = staticmethod(OwnerWebContactObservation._key)
        _custody_id = OwnerWebContactObservation._custody_id
        _terminal_digest = staticmethod(OwnerWebContactObservation._terminal_digest)
    view = MetadataView()
    view.instance_id = iid
    db = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=0)
    db.row_factory = sqlite3.Row
    try:
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')
        fields = ('id', 'tenant_id', 'username', 'role', 'cloud_bound', 'personal_owner')
        columns = ','.join("json_extract(body,'$.%s') AS %s" % (f, f) for f in fields)
        rows = db.execute('SELECT id AS saved_id,tenant_id AS saved_tenant,' + columns
            + ",json_type(body,'$.cloud_bound') AS cloud_type,json_type(body,'$.personal_owner') AS owner_type,"
            + "json_type(body,'$.disabled') AS disabled_type"
            + " FROM records WHERE entity='users' ORDER BY tenant_id,id").fetchall()
        users = []
        for row in rows:
            user = {f: row[f] for f in fields}
            user['cloud_bound'] = None if row['cloud_type'] in (None, 'null') else False if row['cloud_type'] == 'false' else True
            user['personal_owner'] = row['owner_type'] == 'true'
            if (not user['personal_owner'] or row['disabled_type'] not in (None, 'null', 'false')
                    or user['cloud_bound'] is not None and user['cloud_bound'] is not False
                    or user['role'] != 'admin' or user['id'] != row['saved_id']
                    or user['tenant_id'] != row['saved_tenant']
                    or any(type(user[k]) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9:_-]{0,255}', user[k])
                           for k in ('id', 'tenant_id')) or type(user['username']) is not str or not user['username']):
                raise OwnerClosePending('OWNER_METADATA_UNCONFIRMED')
            users.append(user)
        accounts = []
        proof = []
        for user in users:
            account_rows = db.execute("SELECT id,tenant_id,json_extract(body,'$.id') AS body_id,"
                "json_extract(body,'$.tenant_id') AS body_tenant,json_extract(body,'$.cloud_owner') AS owner,"
                "json_extract(body,'$.platform') AS platform,json_extract(body,'$.status') AS status"
                " FROM records WHERE entity='accounts' AND tenant_id=? ORDER BY id",
                (user['tenant_id'],)).fetchall()
            owned = set()
            for row in account_rows:
                if row['owner'] != user['username']:
                    raise OwnerClosePending('ACCOUNT_OWNER_UNCONFIRMED')
                if (row['id'] != row['body_id'] or row['tenant_id'] != row['body_tenant']
                        or type(row['id']) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9:_-]{0,255}', row['id'])
                        or row['platform'] not in ('xiaohongshu', 'douyin', 'wechat_channels')):
                    raise OwnerClosePending('ACCOUNT_METADATA_UNCONFIRMED')
                if row['status'] == 'logging_in':
                    raise OwnerClosePending('ORIGINAL_LOGIN_CLEANUP_UNCONFIRMED')
                owned.add(row['id'])
                accounts.append((user['tenant_id'], row['id'], user['username'], row['platform']))
            for entity in (ATTEMPTS, HEADS, CUSTODY):
                identifiers = db.execute('SELECT id FROM records WHERE entity=? AND tenant_id=? ORDER BY id',
                    (entity, user['tenant_id'])).fetchall()
                for identifier in identifiers:
                    row = view._saved(db, entity, identifier['id'], user)
                    if row is None or row['account_id'] not in owned:
                        raise OwnerClosePending('ORIGINAL_OBSERVATION_OWNER_UNCONFIRMED')
                    if entity == ATTEMPTS and row['creation_submitted'] and row['cleanup_state'] != 'closed':
                        raise OwnerClosePending('ORIGINAL_NATIVE_CLEANUP_UNCONFIRMED')
                    if entity == CUSTODY:
                        attempt = view._saved(db, ATTEMPTS, row['key'], user)
                        if (attempt is None or any(attempt[k] != row[k] for k in
                                ('account_id', 'lead_id', 'sequence', 'base', 'uid_digest'))
                                or attempt['creation_submitted'] and attempt['cleanup_state'] != 'closed'):
                            raise OwnerClosePending('ORIGINAL_CUSTODY_CLEANUP_UNCONFIRMED')
                        # A physically closed unknown keeps its active business
                        # custody. No journal/head/attempt row is retired here.
                    proof.append((entity, row['id'], row['record_hash']))
        if (len(accounts) != db.execute("SELECT count(*) FROM records WHERE entity='accounts'").fetchone()[0]
                or len(proof) != db.execute('SELECT count(*) FROM records WHERE entity IN (?,?,?)',
                    (ATTEMPTS, HEADS, CUSTODY)).fetchone()[0]):
            raise OwnerClosePending('ORPHAN_OWNER_METADATA')
        if _plain_file(path) != before:
            raise OwnerClosePending('OWNER_DATABASE_IDENTITY_CHANGED')
        return (tuple(tuple(user[f] for f in fields) for user in users),
                tuple(sorted(accounts)), tuple(proof))
    finally:
        db.close()


class _RecoveryAccounts:
    """Retain original account_execution_lock contexts on this same main thread."""
    def __init__(self, mutex, snapshot):
        from core.adapters import account_execution_lock, _account_lock_owner
        from .self_operating_read import _plain_directory
        self.mutex, self.snapshot, self.contexts = mutex, snapshot, []
        self._factory = account_execution_lock
        self._code = account_execution_lock.__wrapped__.__code__
        self._tls = _account_lock_owner
    def acquire(self):
        from core.adapters import Adapters
        from .self_operating_read import _plain_directory
        for tenant, account, _, platform in self.snapshot[1][len(self.contexts):]:
            directory = self.mutex.instance.directory / 'data/accounts' / tenant / account
            _plain_directory(directory, self.mutex.instance.work_root)
            if directory.resolve() in getattr(self._tls, 'paths', set()):
                raise OwnerClosePending('ACCOUNT_LOCK_NESTED')
            path = directory / 'platform-command.lock'
            try:
                identity = _plain_file(path)
            except FileNotFoundError:
                # Original ctx may use O_CREAT/write before yielding. Establish
                # a missing owned file exclusively under checked ancestors, not
                # a caller-supplied redirected path, before lending it to ctx.
                with path.open('x+b') as stream:
                    _plain_directory(directory, self.mutex.instance.work_root)
                    identity = _plain_file(path)
                    opened = os.fstat(stream.fileno())
                    if identity != (opened.st_dev, opened.st_ino) or opened.st_nlink != 1:
                        raise OwnerClosePending('ACCOUNT_LOCK_IDENTITY_CHANGED')
                    stream.write(b'\0')
                    stream.flush()
                    os.fsync(stream.fileno())
            _plain_directory(directory, self.mutex.instance.work_root)
            if _plain_file(path) != identity:
                raise OwnerClosePending('ACCOUNT_LOCK_IDENTITY_CHANGED')
            manager = self._factory(directory)
            manager.__enter__()
            self.contexts.append((directory, manager, identity))
            self._check_context(directory, manager, identity)
            # Original unfinished activity is not retired by an empty registry,
            # free OS lock, missing PID or this new source-only launch.
            Adapters.require_account_safe(platform, directory)

    def _check_context(self, directory, manager, identity):
        from .self_operating_read import _plain_directory
        _plain_directory(directory, self.mutex.instance.work_root)
        frame = manager.gen.gi_frame
        if manager.gen.gi_code is not self._code or frame is None:
            raise OwnerClosePending('ACCOUNT_LOCK_OWNER_CHANGED')
        facts = frame.f_locals
        fd = facts.get('handle')
        if (facts.get('root') != directory or facts.get('locked') is not True
                or type(fd) is not int or directory not in getattr(self._tls, 'paths', set())
                or (os.fstat(fd).st_dev, os.fstat(fd).st_ino) != identity
                or _plain_file(directory / 'platform-command.lock') != identity):
            raise OwnerClosePending('ACCOUNT_OS_LOCK_UNCONFIRMED')

    def check(self):
        from core.adapters import Adapters
        self.mutex._mechanical()
        if len(self.contexts) != len(self.snapshot[1]):
            raise OwnerClosePending('ACCOUNT_LOCK_SET_INCOMPLETE')
        for index, (directory, manager, identity) in enumerate(self.contexts):
            self._check_context(directory, manager, identity)
            Adapters.require_account_safe(self.snapshot[1][index][3], directory)
        with self.mutex._core.lock:
            if _recovery_metadata(self.mutex._server, self.mutex._identity['instance_id']) != self.snapshot:
                raise OwnerClosePending('OWNER_RECOVERY_METADATA_CHANGED')

    def close(self):
        # Original generator's finally releases its own RLock/TLS and OS byte0.
        # No other thread can release these contexts; failed exits stay held.
        while self.contexts:
            _, manager, _ = self.contexts[-1]
            manager.__exit__(None, None, None)
            self.contexts.pop()


def owner_physical_closed(server):
    """Current retained resources, never registry absence after generic clear."""
    workspace = server._self_operating_reads
    from .self_operating_read import OwnerReadWorkspace
    from core.adapters import _OwnerXhsReadJob
    if (type(workspace) is not OwnerReadWorkspace or workspace.server is not server
            or workspace.instance is not server.self_operating_instance):
        return False
    with server.job_lock:
        if any(t.is_alive() for t in server._owner_http_threads):
            return False
        jobs = tuple(server.jobs.values())
        login_jobs = tuple(workspace._login._jobs.values())
    if any(not any(job is original for original in login_jobs) for job in jobs):
        return False  # No unknown generic registration is retired for this proof.
    for job in login_jobs:
        thread = job.get('_thread')
        if (thread is None or thread.is_alive() or not job['_done'].is_set()
                or job.get('cleanup_confirmed') is not True or job.get('process') is not None):
            return False
    if workspace._reads is not None:
        with workspace._reads._lock:
            entries = tuple(workspace._reads._operations.values())
        for entry in entries:
            if entry.get('running'):
                return False
            holder = entry.get('_owner_job')
            if holder is not None and (type(holder) is not _OwnerXhsReadJob
                                       or not holder.cleanup_confirmed()):
                return False
    observation = workspace._web_contact_observation
    if observation is not None:
        with observation._lock:
            frames = tuple(observation._frames.values())
        for frame in frames:
            if (frame._launching or not frame._launch_done.is_set()
                    or any(t is not None and t.is_alive()
                           for t in (frame._worker, frame._finisher))
                    or frame.holder is not None and not frame.holder.attested_closed()):
                return False
    if workspace._douyin is not None:
        with workspace._douyin._lock:
            if workspace._douyin.pending:
                return False
    adapters = server.core.adapters
    with adapters.lifecycle_lock:
        if adapters.processes or adapters.job_processes or adapters.process_accounts or adapters.http_jobs:
            return False
    # This owner launcher does not enable the shared employee page runtime.
    # An unexpected runtime is retained rather than borrowing its weak close DTO.
    if adapters.xhs_page_runtime is not None or server.account_connections.owned:
        return False
    return True


def begin_owner_close(server):
    """Freeze new owner requests, then drain existing callers outside short locks."""
    with server.job_lock:
        server.closing = True
        threads = tuple(server._owner_http_threads)
    complete = server._self_operating_reads.close() is True
    deadline = time.monotonic() + 3
    for thread in threads:
        if thread is threading.current_thread():
            complete = False
        elif thread.ident is not None:
            thread.join(max(0, deadline - time.monotonic()))
            complete = complete and not thread.is_alive()
    with server.job_lock:
        server._owner_http_threads.difference_update(t for t in threads if not t.is_alive())
    return complete and owner_physical_closed(server)


def owner_process_request(server, request, address):
    """Register a normal HTTP worker before start, sharing the close gate."""
    from http.server import ThreadingHTTPServer
    def work():
        ThreadingHTTPServer.process_request_thread(server, request, address)
        # The original thread remains registered until another thread observes
        # is_alive=False/join completion, never before this function returns.
    with server.job_lock:
        if server.closing:
            server.shutdown_request(request)
            return
        server._owner_http_threads.difference_update(
            t for t in tuple(server._owner_http_threads) if not t.is_alive())
        thread = threading.Thread(target=work, name='owner-workspace-http', daemon=False)
        server._owner_http_started = True
        server._owner_http_threads.add(thread)
        try:
            thread.start()
        except BaseException:
            server._owner_http_threads.discard(thread)
            server.shutdown_request(request)
            raise


class _OwnerInstanceMutex:
    def __init__(self, instance, file, seal):
        if seal is not _SEAL:
            raise OwnerClosePending()
        self._seal, self.instance, self._file = seal, instance, file
        self._path = instance.directory / 'data/instance.lock'
        self._file_identity = _plain_file(self._path)
        self._fd = file.fileno()
        opened = os.fstat(self._fd)
        if (opened.st_dev, opened.st_ino) != self._file_identity:
            raise OwnerClosePending()
        self._thread = threading.current_thread()
        self._pid = os.getpid()
        self._released = False
        self._server = self._core = self._workspace = None
        self._window = self._server_thread = None
        self._monitor_thread = self._closed_callback_thread = None
        self._window_closed = threading.Event()
        self._normal_close_confirmed = threading.Event()
        self._listener_closed = False
        self._commit_active = False
        self._writer_sha = None
        self._recovery_key = None
        self._recovery_plan = self._recovery_module = self._recovery_origin = None
        self._accounts = None
        self._native_phase = 'not_submitted'
        self._identity = instance.check()['selfOperatingRead']

    def bind_server(self, server):
        from .self_operating_read import OwnerReadWorkspace
        from http.server import ThreadingHTTPServer
        if (self._server is not None or not isinstance(server, ThreadingHTTPServer)
                or server.self_operating_instance is not self.instance
                or type(server._self_operating_reads) is not OwnerReadWorkspace
                or server._self_operating_reads.server is not server
                or server.core.store.directory != self.instance.directory / 'data'):
            raise OwnerClosePending()
        self._server, self._core = server, server.core
        self._workspace = server._self_operating_reads
        server._owner_instance_mutex = self

    def bind_desktop(self, window, server_thread):
        self._mechanical()
        if (self._window is not None or self._recovery_key is not None
                or type(server_thread) is not threading.Thread):
            raise OwnerClosePending()
        self._window, self._server_thread = window, server_thread

    def bind_metadata_recovery(self, plan, writer_module):
        # Only the explicit normal main recovery route invokes this before any
        # native/HTTP lifecycle starts. It is not an offline/PID-based proof.
        self._mechanical()
        revision = require_reviewed_writer(writer_module)
        if (self._window is not None or self._server_thread is not None
                or self._recovery_key is not None or self._server._owner_http_started
                or type(plan) is not writer_module._UpgradePlan
                or not owner_physical_closed(self._server)):
            raise OwnerClosePending()
        origin = plan.require_closed_origin(self.instance, revision)
        company = self.instance.check()
        if (type(origin) is not writer_module._ClosedUpgradeOrigin
                or origin._seal is not writer_module._SEAL or origin.instance is not self.instance
                or origin.instance_id != company['selfOperatingRead']['instance_id']
                or origin.company_id != company['id'] or origin.source_revision != revision.lower()
                or origin.idempotency_key != plan.idempotency_key
                or not re.fullmatch(r'[0-9a-f]{64}', origin.journal_checkpoint_sha256)
                or origin.phase not in ('reserved', 'backup_ready', 'replace_started', 'committed')):
            raise OwnerClosePending('TRUSTED_CLOSED_ORIGIN_UNCONFIRMED')
        self._recovery_plan, self._recovery_module, self._recovery_origin = plan, writer_module, origin
        self._recovery_key = origin.idempotency_key

    def native_creation_submitted(self, window):
        self._mechanical()
        if (window is not self._window or self._native_phase != 'not_submitted'
                or self._recovery_key is not None):
            raise OwnerClosePending('NATIVE_START_SCOPE_CHANGED')
        self._native_phase = 'submitted_unknown'

    def bind_monitor(self, thread):
        self._mechanical()
        if self._monitor_thread is not None or type(thread) is not threading.Thread:
            raise OwnerClosePending()
        self._monitor_thread = thread

    def record_owned_close(self):
        # Original host invokes only after its entire close implementation
        # returns physical success; no caller-provided boolean is accepted.
        if (self._server._owner_instance_mutex is not self or not self._server.closing
                or not owner_physical_closed(self._server)):
            raise OwnerClosePending()
        self._normal_close_confirmed.set()

    def _lifecycle_closed(self):
        if self._recovery_key is not None:
            return (self._window is None and self._server_thread is None
                    and self._monitor_thread is None and not self._server._owner_http_started)
        if any(t is not None and t.is_alive() for t in (self._monitor_thread, self._closed_callback_thread)):
            return False
        if self._native_phase == 'not_submitted':
            return self._server_thread is None or not self._server_thread.is_alive()
        return (self._native_phase == 'closed' and self._window is not None
                and self._server_thread is not None and self._window_closed.is_set()
                and not self._server_thread.is_alive())

    def native_closed(self, window):
        if window is not self._window or self._native_phase not in ('submitted_unknown', 'closed'):
            raise OwnerClosePending()
        if self._native_phase == 'closed':return
        self._closed_callback_thread = threading.current_thread()
        self._native_phase = 'closed'
        self._window_closed.set()  # Only original closed-event callback calls this.

    def listener_closed(self):
        self._mechanical()
        if (self._server.socket.fileno() != -1 or not self._lifecycle_closed()
                or not self._normal_close_confirmed.is_set()
                or not owner_physical_closed(self._server)):
            raise OwnerClosePending()
        self._listener_closed = True

    def _mechanical(self):
        from .self_operating_read import _plain_directory
        _plain_directory(self.instance.directory / 'data', self.instance.work_root)
        if (self._seal is not _SEAL or self._released or self._file.closed
                or threading.current_thread() is not self._thread or os.getpid() != self._pid
                or self._file.fileno() != self._fd
                or _plain_file(self._path) != self._file_identity):
            raise OwnerClosePending()
        value = os.fstat(self._fd)
        if (value.st_dev, value.st_ino) != self._file_identity:
            raise OwnerClosePending()
        if self._server is not None and (
                self._server._owner_instance_mutex is not self or self._server.core is not self._core
                or self._server._self_operating_reads is not self._workspace
                or self._workspace.instance is not self.instance):
            raise OwnerClosePending()

    def closed_capability(self):
        self._mechanical()
        company = self.instance.check()
        if (self._server is None or self._server.company != company
                or not self._listener_closed or not self._lifecycle_closed()
                or not owner_physical_closed(self._server)):
            raise OwnerClosePending()
        # Every commit, including a fresh native close, checks possible legacy
        # owned activity. An empty new Core never substitutes for this fence.
        if self._accounts is None:
            with self._core.lock:
                snapshot = _recovery_metadata(self._server, self._identity['instance_id'])
            self._accounts = _RecoveryAccounts(self, snapshot)
        self._accounts.acquire()
        self._accounts.check()
        if self._recovery_key is not None:
            revision = require_reviewed_writer(self._recovery_module)
            if self._recovery_plan.require_closed_origin(self.instance, revision) != self._recovery_origin:
                raise OwnerClosePending('TRUSTED_CLOSED_ORIGIN_CHANGED')
        return _OwnerNormalCloseCapability(self, company['selfOperatingRead'], _SEAL)

    def release(self):
        self._mechanical()
        if self._commit_active or self._server is not None and not self._listener_closed:
            raise OwnerClosePending()
        if self._accounts is not None:
            self._accounts.close()
        if os.name == 'nt':
            import msvcrt
            self._file.seek(0)
            msvcrt.locking(self._fd, msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(self._fd, fcntl.LOCK_UN)
        self._file.close()
        self._released = True


class _OwnerNormalCloseCapability:
    def __init__(self, mutex, identity, seal):
        if seal is not _SEAL or type(mutex) is not _OwnerInstanceMutex:
            raise OwnerClosePending()
        self._seal, self._mutex = seal, mutex
        self._identity = dict(identity)

    def _mechanical(self, instance):
        mutex = self._mutex
        mutex._mechanical()
        if (self._seal is not _SEAL or instance is not mutex.instance or not mutex._listener_closed
                or not mutex._lifecycle_closed()
                or not owner_physical_closed(mutex._server)):
            raise OwnerClosePending()
        if mutex._accounts is None:
            raise OwnerClosePending('ACCOUNT_CLOSURE_FENCE_MISSING')
        mutex._accounts.check()

    def require(self, instance):
        self._mechanical(instance)
        m = self._mutex
        try:
            current = instance.check()['selfOperatingRead']
        except ValueError:
            # Only the same held commit can produce the canonical v2 target.
            # Retained old instance/company objects and permissions stay old.
            from .self_operating_read import _company
            marker = instance.directory / 'self-operating-instance.json'
            target = json.dumps({'schema': 'owner_read_instance_v2',
                'instance_id': self._identity['instance_id'],
                'company': _company(self._identity['instance_id'], instance._wrapper_sha,
                    'primary_platforms_v2')}, ensure_ascii=False, sort_keys=True).encode()
            if not m._commit_active or _plain_file(marker) is None or marker.read_bytes() != target:
                raise OwnerClosePending('CURRENT_MARKER_CHANGED') from None
            current = self._identity
        if current != self._identity:
            raise OwnerClosePending('CURRENT_INSTANCE_CHANGED')
        return _OwnerClosedContext(instance, m._server, m._core, instance.directory / 'data',
            m._path, self._identity['instance_id'], self._identity['schema'], m._pid,
            m._thread.ident, m._writer_sha,
            'metadata_recovery' if m._recovery_key is not None else 'startup_not_created' if m._native_phase == 'not_submitted' else 'native', m._recovery_key)

    def require_writer(self, module):
        self._mechanical(self._mutex.instance)
        self._mutex._writer_sha = require_reviewed_writer(module)
        return self.require(self._mutex.instance)

    @contextmanager
    def hold_for_commit(self, instance):
        context = self.require(instance)
        m = self._mutex
        if m._commit_active:
            raise OwnerClosePending()
        m._commit_active = True
        try:
            yield context
        finally:
            try:
                # The writer may have legitimately replaced the v1 marker.
                # Do not call the cached old instance.check() on this exit.
                self._mechanical(instance)
            finally:
                m._commit_active = False


def acquire_owner_instance_lock(instance):
    """Perform the original main lock operation; never accept a held=True claim."""
    from .self_operating_read import _OwnerReadInstance, _plain_directory
    if (type(instance) is not _OwnerReadInstance
            or threading.current_thread() is not threading.main_thread()):
        raise OwnerClosePending()
    instance.check()
    directory = instance.directory / 'data'
    _plain_directory(directory, instance.work_root)
    path = directory / 'instance.lock'
    try:
        original = _plain_file(path)  # Before any open/write follows the path.
    except FileNotFoundError:
        original = None
    file = path.open('x+b' if original is None else 'r+b')
    try:
        _plain_directory(directory, instance.work_root)
        identity = _plain_file(path)
        opened = os.fstat(file.fileno())
        if (identity != (opened.st_dev, opened.st_ino) or opened.st_nlink != 1
                or original is not None and identity != original):
            raise OwnerClosePending('INSTANCE_LOCK_IDENTITY_CHANGED')
        if opened.st_size == 0:
            file.write(b'1')
            file.flush()
            os.fsync(file.fileno())
        file.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return _OwnerInstanceMutex(instance, file, _SEAL)
    except BaseException:
        file.close()
        raise


def finish_owner_main(server, mutex, *, require_upgrade_capability=False):
    """Close ordinary use; mint a commit capability only for explicit upgrade."""
    if type(require_upgrade_capability) is not bool:
        raise OwnerClosePending('OWNER_CLOSE_SCOPE_CHANGED')
    if type(mutex) is not _OwnerInstanceMutex or mutex._server is not server:
        raise OwnerClosePending()
    try:
        return _finish_owner_main(server, mutex,
            require_upgrade_capability=require_upgrade_capability)
    except OwnerClosePending:
        raise
    except (Exception, KeyboardInterrupt):
        # Preserve original contexts and mutex. No vendor/DB exception detail
        # is emitted to the fallback UI or reinterpreted as confirmed closed.
        raise OwnerClosePending('OWNED_CLOSE_FACTS_UNCONFIRMED') from None


def _finish_owner_main(server, mutex, *, require_upgrade_capability=False):
    """Normal finally: bounded check, retain lock on any incomplete lifecycle.

    A failed close never runs another platform command or clears a receipt. The
    original worker / explicit next close attempt must establish the close fact.
    Root inserts the fixed reviewed writer at the returned-capability seam.
    """
    if type(mutex) is not _OwnerInstanceMutex or mutex._server is not server:
        raise OwnerClosePending()
    if server.close_owned_jobs() is not True:
        raise OwnerClosePending('OWNED_RESOURCES_CLEANUP_PENDING')
    if mutex._recovery_key is None:
        if mutex._native_phase == 'submitted_unknown':
            # A closed callback can still be finishing; closing.is_set and a
            # return from start never replace the actual closed event.
            if not mutex._window_closed.wait(3):
                raise OwnerClosePending('NATIVE_CLOSED_EVENT_PENDING')
        if mutex._server_thread is not None:
            if mutex._server_thread.is_alive():
                server.shutdown()
            if mutex._server_thread.ident is not None:
                mutex._server_thread.join(6)
            if mutex._server_thread.is_alive():
                raise OwnerClosePending('ORIGINAL_SERVER_THREAD_PENDING')
        for thread in (mutex._monitor_thread, mutex._closed_callback_thread):
            if thread is not None and thread is not threading.current_thread() and thread.ident is not None:
                thread.join(6)
            if thread is not None and thread.is_alive():
                raise OwnerClosePending('ORIGINAL_DESKTOP_THREAD_PENDING')
    server.server_close()
    mutex.listener_closed()
    # A newly registered, never-used account need not have its scope
    # directory yet. Ordinary exit still closes every retained resource
    # and listener above; it does not request a writer capability.
    # Every explicit commit and metadata recovery retains the complete
    # original account/activity/metadata fence in closed_capability.
    # Known unsubmitted Native cannot authorize an upgrade. Its normal
    # main may report held only after the real closure above; no cap
    # is minted and no account fence is bypassed for any commit.
    return (mutex.closed_capability()
            if mutex._recovery_key is not None or (require_upgrade_capability
                and mutex._native_phase != 'not_submitted') else None)
