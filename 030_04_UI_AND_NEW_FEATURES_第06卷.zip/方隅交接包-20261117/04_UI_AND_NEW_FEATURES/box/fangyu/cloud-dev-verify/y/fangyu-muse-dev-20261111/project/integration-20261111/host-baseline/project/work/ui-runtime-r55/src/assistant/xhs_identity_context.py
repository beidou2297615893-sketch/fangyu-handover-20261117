"""Original DeviceSession-derived facts for one account-only status worker.

No Task, collection Call or stored UID/readiness is created by this module.
Claims retain exact RAM jobs; a fresh worker frame supplies its own thread.
These facts do not approve Native components or platform execution.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import threading
import time

from .xhs_app_context import _DeviceSession, _ACTOR, _ACCOUNT, _digest


_SEAL = object()
_LOCAL = threading.local()
_PURPOSE = 'identity_observation'
_IDENTITY_ACCOUNT = _ACCOUNT + ('store_id',)


class IdentityContextRequired(ValueError):
    def __init__(self):
        super().__init__('xhs_identity_context_unavailable')


@dataclass(frozen=True, slots=True, repr=False)
class _IdentityWorkerClaim:
    seal: object
    session: _DeviceSession
    job: dict
    actor: bytes
    account: bytes
    actor_id: str
    account_id: str
    deadline: float

    def check(self):
        """Fresh account/job binding, also usable for a completed RAM result.

        Execution additionally needs the current opaque worker context below.
        Saved login_required, empty UID and requires_review are observations,
        never platform permissions and never normalized to a false/ready value.
        """
        from app import AppServer
        if self.seal is not _SEAL or type(self.session) is not _DeviceSession:
            raise IdentityContextRequired()
        self.session.check()
        service, executor = self.session.service, self.session.executor
        server, core = service.server, self.session.core
        if (type(server) is not AppServer or getattr(server, 'closing', False)
                or core.remote_safety_hold or service.stop_event.is_set()):
            raise IdentityContextRequired()
        with service.lock:
            qa=(server.company.get('runtime') or {}).get('platform_qa_device_id')
            if service.state != 'online' or qa and (service.device or {}).get('id')!=qa:
                raise IdentityContextRequired()
        with core.lock:
            user = core.store.get('users', self.actor_id)
            account = core._get('accounts', self.account_id, executor.tenant)
            if (not user or _digest({key:user.get(key) for key in _ACTOR}) != self.actor
                    or _digest({key:account.get(key) for key in _IDENTITY_ACCOUNT}) != self.account
                    or user.get('disabled') or user.get('cloud_bound') is not True
                    or user.get('development_local_only') is True
                    or user.get('role') not in ('operator', 'admin')
                    or (user.get('id'), user.get('username'), user.get('tenant_id')) !=
                        (executor.user_id, executor.owner, executor.tenant)
                    or account.get('platform') != 'xiaohongshu'
                    or account.get('cloud_owner') != executor.owner
                    or account.get('status') == 'session_recovery_required'):
                raise IdentityContextRequired()
            core._account_access(user, account)
            core.require_platform('xiaohongshu')
            from core.platform_capabilities import platform_runtime_unavailable_reason
            if platform_runtime_unavailable_reason('xiaohongshu'):
                raise IdentityContextRequired()
            executor._require_product_feature('acquisition')
        with server.job_lock:
            if (type(self.job) is not dict or server.jobs.get(self.job.get('id')) is not self.job
                    or self.job.get('_identity_claim') is not self
                    or self.job.get('_customer_ui_revoked') is True
                    or self.job.get('kind') != 'assistant_account_login'
                    or self.job.get('mode') != 'browser' or self.job.get('purpose') != _PURPOSE
                    or self.job.get('owner_id') != self.actor_id
                    or self.job.get('account_id') != self.account_id
                    or self.job.get('tenant_id') != executor.tenant
                    or not isinstance(self.job.get('worker_done'), threading.Event)):
                raise IdentityContextRequired()
        self.session.check()


@dataclass(frozen=True, slots=True, repr=False)
class _IdentityExecutionContext:
    seal: object
    claim: _IdentityWorkerClaim
    thread: object

    def check(self):
        if (self.seal is not _SEAL or type(self.claim) is not _IdentityWorkerClaim
                or self.thread is not threading.current_thread()
                or getattr(_LOCAL, 'context', None) is not self):
            raise IdentityContextRequired()
        server=self.claim.session.service.server
        if getattr(server,'_customer_natural_component',False):
            from .customer_read_lease import current
            if not current(server,'xiaohongshu_identity_observation'):raise ValueError('customer_read_lease_unavailable')
        self.claim.check()
        server, job = self.claim.session.service.server, self.claim.job
        with server.job_lock:
            if (getattr(server, '_xhs_identity_contexts', {}).get(job['id']) is not self
                    or job.get('status') != 'running' or job['worker_done'].is_set()
                    or time.monotonic() >= self.claim.deadline):
                raise IdentityContextRequired()


def mint_identity_worker(service, user, account, job):
    """Called only by the original trusted service, after installing its RAM job."""
    from .service import AssistantService
    from .business import BusinessExecutor
    if type(service) is not AssistantService or type(service.executor) is not BusinessExecutor:
        raise IdentityContextRequired()
    executor, server = service.executor, service.server
    session = getattr(executor, '_xhs_app_session', None)
    if (type(session) is not _DeviceSession or session.service is not service
            or type(user) is not dict or type(account) is not dict or type(job) is not dict
            or job.get('status') != 'running' or job.get('_identity_claim') is not None):
        raise IdentityContextRequired()
    claim = _IdentityWorkerClaim(_SEAL, session, job,
        _digest({key:user.get(key) for key in _ACTOR}),
        _digest({key:account.get(key) for key in _IDENTITY_ACCOUNT}), user['id'], account['id'],
        time.monotonic()+300)
    with server.job_lock:
        if server.jobs.get(job.get('id')) is not job:
            raise IdentityContextRequired()
        job['_identity_claim'] = claim
    try:
        claim.check()
    except BaseException:
        with server.job_lock:
            if job.get('_identity_claim') is claim:
                job.pop('_identity_claim')
        raise
    return claim


@contextmanager
def identity_worker_call(claim):
    """A new account worker frame; no collection/HTTP active frame is inherited."""
    if type(claim) is not _IdentityWorkerClaim or getattr(_LOCAL, 'context', None) is not None:
        raise IdentityContextRequired()
    claim.check()
    server, job = claim.session.service.server, claim.job
    current = _IdentityExecutionContext(_SEAL, claim, threading.current_thread())
    with server.job_lock:
        contexts = getattr(server, '_xhs_identity_contexts', None)
        if type(contexts) is not dict or job['id'] in contexts:
            raise IdentityContextRequired()
        contexts[job['id']] = current
    _LOCAL.context = current
    try:
        current.check()
        yield current
    finally:
        # Cleanup cannot depend on the permission that was just revoked.
        _LOCAL.context = None
        with server.job_lock:
            if contexts.get(job['id']) is current:
                contexts.pop(job['id'])


def current_identity_context(core):
    current = getattr(_LOCAL, 'context', None)
    if type(current) is not _IdentityExecutionContext or current.claim.session.core is not core:
        return None
    try:
        current.check()
        return current
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        return None
