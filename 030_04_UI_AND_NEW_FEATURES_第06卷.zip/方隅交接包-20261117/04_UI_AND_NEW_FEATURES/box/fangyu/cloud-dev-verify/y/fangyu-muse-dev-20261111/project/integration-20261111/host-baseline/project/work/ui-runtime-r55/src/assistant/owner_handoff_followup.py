"""Owner-reported delivery and recipient feedback; never independent receipt.

Only original successful package rows are addressable. This module does not
decrypt contacts, emit files, send messages or change a draft's business state.
"""
from copy import deepcopy
from datetime import datetime
import json
import math
import re
import time

from .product_receipts import ProductOperationReceipts, ENTITY as RECEIPTS
from .self_operating_acquisition import (OwnerAcquisition, OwnerAcquisitionError,
    _OwnerReceipts, _row, _identity, _ACTOR, _LOCAL, _KEY, _HEX, digest, FACTS,
    KINDS, TONES)
from .owner_contact_handoff_package import (OwnerContactHandoffPackages,
    _PackageContext, _SEAL as _PACKAGE_SEAL, ENTITY as PACKAGES)

PURPOSE = 'owner_handoff_followup_v1'
DELIVERY = 'owner_handoff_delivery_record'
FEEDBACK = 'owner_handoff_feedback_record'
STATUS = 'owner_handoff_followup_operation_status'
LIST = 'owner_handoff_followup_list'
DETAIL = 'owner_handoff_followup_detail'
ACTIONS = frozenset((DELIVERY, FEEDBACK, STATUS, LIST, DETAIL))
WRITES = frozenset((DELIVERY, FEEDBACK))
METHODS = frozenset(('in_person', 'external_channel_reported'))
FEEDBACKS = frozenset(('needs_supplement', 'rejected',
    'duplicate_or_existing_unverified', 'reported_received', 'unknown'))
EVENTS = 'owner_handoff_followup_events_v1'
SLOTS = 'owner_handoff_followup_slots_v1'
ANCHORS = 'owner_handoff_followup_anchors_v1'
_SCOPE = 'owner_handoff_followup_scope'
_SEAL = object()


def _fail(message, committed=False):
    raise OwnerAcquisitionError(message, mutation_committed=committed)


def _put(db, entity, value, *, new=False):
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False)
    if new:
        db.execute('INSERT INTO records VALUES(?,?,?,?)',
            (entity, value['id'], value['tenant_id'], encoded))
    elif db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
            (encoded, entity, value['id'], value['tenant_id'])).rowcount != 1:
        _fail('原跟进记录需要核对', None)


def _auth(state='needs_review'):
    return {'state': state, 'checked_at': time.time(), 'reason_code': {
        'current_recorded_scope': 'CURRENT_RECORDED_SCOPE',
        'withdrawn': 'RECORDED_CONSENT_WITHDRAWN',
        'needs_review': 'ORIGINAL_ROW_NEEDS_REVIEW'}[state]}


def _stamp(value):
    if value is None:
        return None
    if type(value) is not str or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z', value):
        _fail('请选择明确的日期，或保留日期不确定')
    try:
        datetime.fromisoformat(value[:-1] + '+00:00')
    except ValueError:
        _fail('登记日期无效')
    return value


class _FollowupReceipts(ProductOperationReceipts):
    """Original receipt transactions, with proof and slots on their own DB."""
    def __init__(self, service, token, user, package, action, row_id, payload=None, seal=None):
        if seal is not _SEAL or type(service) is not OwnerHandoffFollowup:
            _fail('跟进必须来自当前本人原包')
        self.service, self.token, self.user = service, token, deepcopy(user)
        self.package, self.action, self.row_id = deepcopy(package), action, row_id
        self.payload = deepcopy(payload)
        super().__init__(service.core, service.acq.tenant, service.acq.owner)

    def _identity(self, action, key):
        if action != self.action or action not in WRITES or type(key) is not str or not _KEY.fullmatch(key):
            _fail('请核对本次登记的原编号')
        return digest([PURPOSE, self.tenant, self.owner, self.service.acq.instance_id, action, key])

    def _guard(self, db):
        package = self.service._package(db, self.token, self.user, self.package['id'])
        if package != self.package:
            _fail('原包在本次登记中变化，请保留原号')
        if self.action == FEEDBACK and self.row_id not in self.service._row_ids(package):
            _fail('只能核对原包中的指定行')
        if self.action == DELIVERY and self.row_id is not None:
            _fail('整包交出登记不接受行编号')

    def _read(self, db, ident, action, key):
        self._guard(db)
        record = super()._read(db, ident, action, key)
        if record is not None:
            self.service._receipt_shape(record, self.package, self.user, action, self.row_id)
            if record['state'] == 'succeeded':
                event = self.service._event_for_receipt(db, record)
                self.service._slot(db, self.package, self.user, action, self.row_id)
                if event is None:
                    _fail('成功登记缺少原事实，请保留原编号', None)
        return record

    def _put(self, db, record, *, new=False):
        self._guard(db)
        scope = self.service._scope(self.package, self.user, record['original_action'], self.row_id)
        if new:
            record[_SCOPE] = scope
            if record['state'] == 'started':
                if self.payload is None:
                    _fail('新登记缺少明确提交')
                self.service._fresh_write(db, self.token, self.user, self.package,
                    record['original_action'], self.row_id, self.payload)
                self.service._ensure_slots(db, self.package, self.user)
                slot = self.service._slot(db, self.package, self.user, record['original_action'], self.row_id)
                if slot['pending_key'] is not None:
                    _fail('本行已有登记结果待核对，请只查原编号')
                if slot['revision'] != self.payload['expected_revision']:
                    _fail('本行登记已更新，请先重新核对详情')
                slot['pending_key'] = record['idempotency_key']
                self.service._save_slot(db, slot)
            elif record['state'] != 'cancelled':
                _fail('新回执状态无效')
            # Cancelled is the original absent tombstone. It does not initialize
            # slots, release another key or infer that an unknown write ended.
        else:
            self.service._receipt_shape(record, self.package, self.user, record['original_action'], self.row_id)
            slot = self.service._slot(db, self.package, self.user, record['original_action'], self.row_id)
            if slot is None or slot['pending_key'] != record['idempotency_key']:
                _fail('原待核登记与当前行不一致', None)
            if record['state'] == 'succeeded':
                event = self.service._event_for_receipt(db, record)
                if event is None or event['revision'] != slot['revision'] + 1:
                    _fail('原登记事实或版本需要核对', None)
                self.service._fresh_write(db, self.token, self.user, self.package,
                    record['original_action'], self.row_id, self.payload)
                slot.update(revision=event['revision'], last_event_id=event['id'], pending_key=None)
                self.service._save_slot(db, slot)
            elif record['state'] == 'rejected':
                if _row(db, EVENTS, self.service._event_id(record['id']), self.tenant) is not None:
                    _fail('已有登记事实，不能声称未提交', None)
                slot['pending_key'] = None
                self.service._save_slot(db, slot)
            elif record['state'] != 'unknown':
                _fail('原待核登记不能提前结束', None)
        super()._put(db, record, new=new)


class OwnerHandoffFollowup:
    def __init__(self, acquisition):
        if type(acquisition) is not OwnerAcquisition or type(acquisition._packages) is not OwnerContactHandoffPackages:
            _fail('人工交付与回流只能从当前本人原包服务创建')
        self.acq, self.workspace, self.core = acquisition, acquisition.workspace, acquisition.core

    def _package(self, db, token, user, package_id):
        self.acq._packages._session(db, token, user)
        raw = _row(db, PACKAGES, package_id, self.acq.tenant)
        if raw is None or type(raw.get('idempotency_key')) is not str:
            _fail('原资料包不存在或需要核对')
        record = self.acq._packages._record(db, raw['idempotency_key'], user)
        if record != raw or record['id'] != package_id or record['state'] != 'succeeded':
            _fail('请使用当前本人已生成的原资料包')
        return record

    def _row_ids(self, package):
        return [digest([PURPOSE, self.acq.tenant, self.acq.owner, self.acq.instance_id,
            package['id'], package['selection_digest'], selected['draft_id']]) for selected in package['selection']]

    def _scope(self, package, user, action, row_id):
        return {'schema': PURPOSE, 'company_id': self.acq.server.company['id'],
            'tenant_id': self.acq.tenant, 'cloud_owner': self.acq.owner,
            'actor_digest': digest(_identity(user, _ACTOR)), 'instance_id': self.acq.instance_id,
            'package_id': package['id'], 'selection_digest': package['selection_digest'],
            'original_action': action, 'row_id': row_id}

    def _slot_id(self, package, action, row_id):
        return digest([PURPOSE, 'slot', self.acq.instance_id, package['id'], action, row_id])

    def _anchor_id(self, package):
        return digest([PURPOSE, 'anchor', self.acq.instance_id, package['id']])

    def _slot_specs(self, package):
        return [(DELIVERY, None)] + [(FEEDBACK, ident) for ident in self._row_ids(package)]

    def _anchor(self, db, package, user):
        ident = self._anchor_id(package)
        anchor = _row(db, ANCHORS, ident, self.acq.tenant)
        scope = self._scope(package, user, DELIVERY, None)
        specs = self._slot_specs(package)
        if anchor is None:
            if any(_row(db, SLOTS, self._slot_id(package, a, r), self.acq.tenant) is not None for a, r in specs):
                _fail('原跟进索引缺失，不把坏记录视为尚未登记')
            old = db.execute("SELECT 1 FROM records WHERE entity=? AND tenant_id=? "
                "AND json_extract(body,'$.owner_handoff_followup_scope.package_id')=? "
                "AND json_extract(body,'$.owner_handoff_followup_scope.instance_id')=? "
                "AND json_extract(body,'$.state')!='cancelled' LIMIT 1",
                (RECEIPTS, self.acq.tenant, package['id'], self.acq.instance_id)).fetchone()
            if old is not None:
                _fail('原登记回执与行索引待核对')
            return None
        if (set(anchor) != {'id', 'tenant_id', 'scope', 'slots', 'digest'}
                or anchor['scope'] != scope
                or anchor['slots'] != [self._slot_id(package, a, r) for a, r in specs]
                or anchor['digest'] != digest({k: v for k, v in anchor.items() if k != 'digest'})):
            _fail('原跟进主体或行清单需要核对')
        return anchor

    def _ensure_slots(self, db, package, user):
        if self._anchor(db, package, user) is not None:
            return
        slots = []
        for action, row_id in self._slot_specs(package):
            slot = {'id': self._slot_id(package, action, row_id), 'tenant_id': self.acq.tenant,
                'scope': self._scope(package, user, action, row_id), 'revision': 0,
                'last_event_id': None, 'pending_key': None}
            self._save_slot(db, slot, new=True)
            slots.append(slot['id'])
        anchor = {'id': self._anchor_id(package), 'tenant_id': self.acq.tenant,
            'scope': self._scope(package, user, DELIVERY, None), 'slots': slots}
        anchor['digest'] = digest(anchor)
        _put(db, ANCHORS, anchor, new=True)

    def _save_slot(self, db, slot, new=False):
        slot['digest'] = digest({k: v for k, v in slot.items() if k != 'digest'})
        _put(db, SLOTS, slot, new=new)

    def _slot(self, db, package, user, action, row_id):
        if self._anchor(db, package, user) is None:
            return None
        slot = _row(db, SLOTS, self._slot_id(package, action, row_id), self.acq.tenant)
        if (slot is None or set(slot) != {'id', 'tenant_id', 'scope', 'revision', 'last_event_id', 'pending_key', 'digest'}
                or slot['scope'] != self._scope(package, user, action, row_id)
                or type(slot['revision']) is not int or not 0 <= slot['revision'] <= 2**53-1
                or slot['digest'] != digest({k: v for k, v in slot.items() if k != 'digest'})
                or slot['pending_key'] is not None and (type(slot['pending_key']) is not str or not _KEY.fullmatch(slot['pending_key']))):
            _fail('原跟进行状态或版本需要核对')
        if slot['revision'] == 0:
            if slot['last_event_id'] is not None:
                _fail('原跟进初始状态需核对')
        else:
            event = self._confirmed_event(db, slot['last_event_id'], slot['scope'])
            if event['revision'] != slot['revision']:
                _fail('原跟进版本与成功回执不一致')
        if slot['pending_key'] is not None:
            ident = digest([PURPOSE, self.acq.tenant, self.acq.owner, self.acq.instance_id, action, slot['pending_key']])
            receipt = _row(db, RECEIPTS, ident, self.acq.tenant)
            if receipt is None or receipt.get('state') not in ('started', 'unknown'):
                _fail('原待核编号与行状态不一致')
            self._receipt_shape(receipt, package, user, action, row_id)
        return slot

    def _receipt_shape(self, receipt, package, user, action, row_id):
        self._receipt_schema(receipt, self._scope(package, user, action, row_id))

    def _receipt_schema(self, receipt, scope):
        action = scope['original_action']
        base = {'id', 'tenant_id', 'cloud_owner', 'original_action', 'idempotency_key',
            'payload_digest', 'state', 'created_at', 'updated_at', _SCOPE}
        if (set(receipt) != base | ({'result'} if receipt.get('state') == 'succeeded' else set())
                or receipt.get(_SCOPE) != scope
                or receipt.get('tenant_id') != self.acq.tenant or receipt.get('cloud_owner') != self.acq.owner
                or receipt.get('original_action') != action or action not in WRITES
                or type(receipt.get('idempotency_key')) is not str or not _KEY.fullmatch(receipt['idempotency_key'])
                or receipt['id'] != digest([PURPOSE, self.acq.tenant, self.acq.owner,
                    self.acq.instance_id, action, receipt['idempotency_key']])
                or receipt.get('state') not in ('started', 'unknown', 'succeeded', 'rejected', 'cancelled')
                or receipt.get('payload_digest') is None and receipt['state'] != 'cancelled'
                or receipt.get('payload_digest') is not None and (type(receipt['payload_digest']) is not str or not _HEX.fullmatch(receipt['payload_digest']))
                or any(type(receipt.get(k)) not in (int, float) or not math.isfinite(receipt[k]) or receipt[k] <= 0
                    for k in ('created_at', 'updated_at'))):
            _fail('原登记回执归属或结构需要核对', None)
        if receipt['state'] == 'succeeded':
            result = receipt['result']
            if (type(result) is not dict or set(result) != {'id', 'status', 'revision', 'created_at',
                    'local_only', 'platform_requests_started', 'cross_machine_verified', 'resource_receipt_verified'}
                    or type(result.get('id')) is not str or not _HEX.fullmatch(result['id'])
                    or type(result.get('status')) is not str or result['status'] not in (METHODS if action == DELIVERY else FEEDBACKS)
                    or type(result.get('revision')) is not int or not 1 <= result['revision'] <= 2**53-1
                    or type(result.get('created_at')) not in (int, float) or not math.isfinite(result['created_at']) or result['created_at'] <= 0
                    or result.get('local_only') is not True or result.get('platform_requests_started') is not False
                    or result.get('cross_machine_verified') is not False or result.get('resource_receipt_verified') is not False):
                _fail('原成功回执的安全结果类型需要核对', None)

    def _event_id(self, operation_id):
        return digest([PURPOSE, 'event', operation_id])

    def _event(self, db, event_id, scope):
        if type(event_id) is not str or not _HEX.fullmatch(event_id):
            _fail('原登记事件编号需要核对')
        event = _row(db, EVENTS, event_id, self.acq.tenant)
        fields = {'id', 'tenant_id', 'scope', 'operation_id', 'revision', 'category',
            'occurred_at', 'recorded_at', 'evidence_operation_id', 'previous_event_id', 'digest'}
        action = scope['original_action']
        if (event is None or set(event) != fields or event['scope'] != scope
                or type(event.get('operation_id')) is not str or not _HEX.fullmatch(event['operation_id'])
                or event_id != self._event_id(event['operation_id'])
                or type(event['revision']) is not int or not 1 <= event['revision'] <= 2**53-1
                or event['category'] not in (METHODS if action == DELIVERY else FEEDBACKS)
                or type(event['recorded_at']) not in (int, float) or not math.isfinite(event['recorded_at']) or event['recorded_at'] <= 0
                or event['previous_event_id'] is not None and (type(event['previous_event_id']) is not str or not _HEX.fullmatch(event['previous_event_id']))
                or event['revision'] == 1 and event['previous_event_id'] is not None
                or event['revision'] > 1 and event['previous_event_id'] is None
                or event['evidence_operation_id'] is not None and (type(event['evidence_operation_id']) is not str or not _HEX.fullmatch(event['evidence_operation_id']))
                or event['digest'] != digest({k: v for k, v in event.items() if k != 'digest'})):
            _fail('原登记事实不完整，请核对原号')
        _stamp(event['occurred_at'])
        return event

    def _result(self, event):
        return {'id': event['id'], 'status': event['category'], 'revision': event['revision'],
            'created_at': event['recorded_at'], 'local_only': True,
            'platform_requests_started': False, 'cross_machine_verified': False,
            'resource_receipt_verified': False}

    def _event_for_receipt(self, db, receipt):
        event = self._event(db, self._event_id(receipt['id']), receipt[_SCOPE])
        if event['operation_id'] != receipt['id'] or receipt.get('result') != self._result(event):
            _fail('登记事实与原成功回执不一致', None)
        return event

    def _confirmed_event(self, db, event_id, scope):
        event = self._event(db, event_id, scope)
        receipt = _row(db, RECEIPTS, event['operation_id'], self.acq.tenant)
        if receipt is None:
            _fail('原事实缺少成功回执，不能展示已登记')
        self._receipt_schema(receipt, scope)
        if (receipt.get('state') != 'succeeded'
                or receipt.get('result') != self._result(event)):
            _fail('原事实未获成功回执确认，不能展示已登记')
        # A stored receipt must still bind its exact original key/action/identity.
        if (receipt.get('original_action') != scope['original_action']
                or receipt.get('cloud_owner') != self.acq.owner
                or type(receipt.get('idempotency_key')) is not str or not _KEY.fullmatch(receipt['idempotency_key'])
                or receipt['id'] != digest([PURPOSE, self.acq.tenant, self.acq.owner,
                    self.acq.instance_id, scope['original_action'], receipt['idempotency_key']])):
            _fail('原登记成功回执身份需要核对')
        return event

    def _public_event(self, event):
        return {'event_id': event['id'], 'operation_id': event['operation_id'],
            'original_action': event['scope']['original_action'], 'package_id': event['scope']['package_id'],
            'row_id': event['scope']['row_id'], 'revision': event['revision'], 'category': event['category'],
            'occurred_at': event['occurred_at'], 'recorded_at': event['recorded_at'],
            'evidence_operation_id': event['evidence_operation_id'], 'previous_event_id': event['previous_event_id'],
            'evidence_source': 'operator_recorded', 'independently_verified': False}

    def _history(self, db, slot):
        if slot is None or slot['revision'] == 0:
            return [], False
        events, ident, expected = [], slot['last_event_id'], slot['revision']
        while ident is not None and len(events) < 20:
            event = self._confirmed_event(db, ident, slot['scope'])
            if event['revision'] != expected:
                _fail('原登记历史版本需要核对')
            events.append(self._public_event(event))
            ident, expected = event['previous_event_id'], expected - 1
        return events, ident is not None

    def _row_proof(self, db, token, user, package, index):
        acq = self.acq
        selected, proof = package['selection'][index], package['proofs'][index]
        original = _row(db, RECEIPTS, selected['operation_id'], acq.tenant)
        stored = original.get('owner_acquisition_scope') if original else None
        if (selected['operation_id'] != digest([acq.tenant, acq.owner, 'handoff_create', selected['handoff_key']])
                or original is None or original.get('state') != 'succeeded'
                or original.get('original_action') != 'handoff_create' or original.get('cloud_owner') != acq.owner
                or original.get('idempotency_key') != selected['handoff_key']
                or type(stored) is not dict or stored.get('account_id') != selected['account_id']
                or stored.get('lead_id') != selected['lead_id'] or stored.get('local_instance_id') != acq.instance_id
                or stored.get('actor_digest') != digest(_identity(user, _ACTOR))):
            _fail('原包行的成功草稿证明需要核对')
        context = _PackageContext(acq._packages, db, token, user, _PACKAGE_SEAL)
        with acq._call(token, 'contact_read', selected['account_id'], selected['lead_id'],
                _stored_binding=stored, _shared_db=db, _package_context=context) as current:
            receipts = _OwnerReceipts(acq._scope)
            if receipts._read(db, selected['operation_id'], 'handoff_create', selected['handoff_key']) != original:
                _fail('原草稿成功证明已经变化')
            result, authorization = acq._history_protected_result(db, original, receipts._view(original).get('result'))
            if (authorization not in ('granted', 'withdrawn') or result.get('id') != selected['draft_id']
                    or acq._scope._frame()['binding']['privacy_redacted'] is not False):
                _fail('原来源隐私和同意需要核对')
            draft = _row(db, 'acquisition_handoffs', selected['draft_id'], acq.tenant)
            reference = draft.get('contact_reference')
            if draft.get('recipient_id') != package['recipient_id'] or draft.get('purpose') != package['handoff_purpose']:
                _fail('原包行的接收方与用途需要核对')
            if authorization == 'granted':
                from .acquisition_contacts import AcquisitionContacts
                contacts = AcquisitionContacts(acq.core, acq.tenant, acq.owner, acq.server.company, owner_scope=acq._scope)
                contact, _ = contacts._package_read(reference, current, db, context, decrypt=False)
            else:
                # Only original protected history can classify a legitimate
                # withdrawal; this path does not decrypt or grant contact reads.
                contact = _row(db, 'acquisition_contacts', reference[8:], acq.tenant)
                if contact is None or contact.get('encrypted_payload') != '' or contact.get('revision', 0) < 2:
                    _fail('原撤回元数据需要核对')
            expected = {'draft_id': selected['draft_id'], 'contact_reference': reference,
                'binding_digest': digest(acq._scope._frame()['binding']), 'receipt_digest': digest(original),
                'draft_digest': digest(draft), 'contact_digest': digest(contact)}
            if (any(expected[k] != proof[k] for k in expected if k != 'contact_digest')
                    or authorization == 'granted' and expected['contact_digest'] != proof['contact_digest']):
                _fail('原包行证明与来源不一致')
            acq._scope.check(current, db)
        return _auth('current_recorded_scope' if authorization == 'granted' else 'withdrawn')

    def _evidence(self, db, token, user, package, action, row_id, ident):
        if ident is None:
            return
        raw = _row(db, RECEIPTS, ident, self.acq.tenant)
        stored = raw.get('owner_acquisition_scope') if raw else None
        choices = package['selection'] if action == DELIVERY else [package['selection'][self._row_ids(package).index(row_id)]]
        if (raw is None or raw.get('state') != 'succeeded' or raw.get('original_action') != 'owner_manual_contact_record'
                or type(stored) is not dict or not any(stored.get('account_id') == r['account_id']
                    and stored.get('lead_id') == r['lead_id'] for r in choices)):
            _fail('证据仅可选择原包行已核实的本人人工记录')
        context = _PackageContext(self.acq._packages, db, token, user, _PACKAGE_SEAL)
        with self.acq._call(token, 'contact_read', stored['account_id'], stored['lead_id'],
                _stored_binding=stored, _shared_db=db, _package_context=context):
            receipts = _OwnerReceipts(self.acq._scope)
            fresh = receipts._read(db, ident, 'owner_manual_contact_record', raw.get('idempotency_key'))
            if fresh != raw:
                _fail('原人工记录证据已经变化')
            result, _ = self.acq._history_protected_result(db, fresh, receipts._view(fresh).get('result'))
            fact = _row(db, FACTS, result.get('id'), self.acq.tenant)
            if fact.get('status') != fact.get('kind') or fact.get('kind') not in KINDS or fact.get('tone') not in TONES:
                _fail('原人工记录状态与事实类别需要核对')

    def _fresh_write(self, db, token, user, package, action, row_id, payload):
        self._package(db, token, user, package['id'])
        if action == DELIVERY:
            for index in range(len(package['selection'])):
                if self._row_proof(db, token, user, package, index)['state'] != 'current_recorded_scope':
                    _fail('原同意已撤回，只可保留历史，不能登记新的交出')
        else:
            self._row_proof(db, token, user, package, self._row_ids(package).index(row_id))
            delivery = self._slot(db, package, user, DELIVERY, None)
            if delivery is None or delivery['revision'] == 0 or delivery['pending_key'] is not None:
                _fail('请先核实原本人交出登记，再转记本行回复')
        self._evidence(db, token, user, package, action, row_id, payload['evidence_operation_id'])
        self.acq._packages._session(db, token, user)

    def _payload(self, action, data):
        fields = {'package_id', 'expected_revision', 'occurred_at', 'evidence_operation_id', 'confirmed', 'idempotency_key'}
        fields |= {'delivery_method'} if action == DELIVERY else {'row_id', 'feedback'}
        if (set(data) != fields or data.get('confirmed') is not True
                or type(data.get('expected_revision')) is not int or not 0 <= data['expected_revision'] < 2**53-1
                or type(data.get('idempotency_key')) is not str or not _KEY.fullmatch(data['idempotency_key'])
                or type(data.get('package_id')) is not str or not _HEX.fullmatch(data['package_id'])
                or data.get('evidence_operation_id') is not None and (type(data['evidence_operation_id']) is not str or not _HEX.fullmatch(data['evidence_operation_id']))
                or action == FEEDBACK and (type(data.get('row_id')) is not str or not _HEX.fullmatch(data['row_id']))):
            _fail('请明确选择原包、原行和本次人工登记')
        category = data['delivery_method'] if action == DELIVERY else data['feedback']
        if type(category) is not str or category not in (METHODS if action == DELIVERY else FEEDBACKS):
            _fail('请选择固定的交出方式或回复类别')
        _stamp(data['occurred_at'])
        return deepcopy(data)

    def _write(self, token, user, action, data):
        payload = self._payload(action, data)
        row_id = data.get('row_id') if action == FEEDBACK else None
        with self.core.store.connect() as db:
            package = self._package(db, token, user, data['package_id'])
        receipts = _FollowupReceipts(self, token, user, package, action, row_id, payload, _SEAL)
        try:
            begun = receipts.begin(action, payload['idempotency_key'], payload)
        except Exception:
            # Failed begin/COMMIT does not establish absence. Status uses the
            # same key and original linearized tombstone mechanism.
            raise OwnerAcquisitionError('本次登记尚未确认，请保留原编号核对', mutation_committed=None) from None
        if not begun['should_execute']:
            return self._outcome(token, user, package, receipts, begun)
        try:
            with self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                receipts._guard(db)
                original = receipts._read(db, begun['operation_id'], action, payload['idempotency_key'])
                if original is None or original['state'] != 'started':
                    _fail('原登记未处于开始状态', None)
                self._fresh_write(db, token, user, package, action, row_id, payload)
                slot = self._slot(db, package, user, action, row_id)
                if slot['pending_key'] != payload['idempotency_key'] or slot['revision'] != payload['expected_revision']:
                    _fail('原待核登记或版本已变化', None)
                event = {'id': self._event_id(original['id']), 'tenant_id': self.acq.tenant,
                    'scope': self._scope(package, user, action, row_id), 'operation_id': original['id'],
                    'revision': slot['revision'] + 1, 'category': payload['delivery_method'] if action == DELIVERY else payload['feedback'],
                    'occurred_at': payload['occurred_at'], 'recorded_at': time.time(),
                    'evidence_operation_id': payload['evidence_operation_id'], 'previous_event_id': slot['last_event_id']}
                event['digest'] = digest(event)
                _put(db, EVENTS, event, new=True)
                self._fresh_write(db, token, user, package, action, row_id, payload)
        except Exception as error:
            # The transaction exit itself can fail after COMMIT. Only an
            # explicitly pre-write error can reject; other failures stay unknown.
            if not isinstance(error, OwnerAcquisitionError):
                error = OwnerAcquisitionError('本次登记结果需核对', mutation_committed=None)
            try:
                outcome = receipts.fail(error)
            except Exception:
                raise OwnerAcquisitionError('本次登记结果未知，请只核对原编号', mutation_committed=None) from None
            return self._outcome(token, user, package, receipts, outcome)
        try:
            outcome = receipts.finish(self._result(event))
        except Exception:
            raise OwnerAcquisitionError('本次登记回执未确认，请只核对原编号', mutation_committed=None) from None
        return self._outcome(token, user, package, receipts, outcome)

    def _outcome(self, token, user, package, receipts, outcome):
        fields = ('operation_id', 'original_action', 'idempotency_key', 'state', 'mutation_committed',
            'should_execute', 'replayed', 'local_only', 'cross_machine_verified', 'result', 'error_code', 'refresh_required')
        operation = {k: outcome.get(k) for k in fields}
        operation['should_execute'] = False
        operation['refresh_required'] = outcome.get('refresh_required') is True
        record = None
        with self.core.store.connect() as db:
            original = receipts._read(db, outcome['operation_id'], receipts.action, outcome['idempotency_key'])
            if original is not None and original['state'] == 'succeeded':
                record = self._public_event(self._event_for_receipt(db, original))
            self._package(db, token, user, package['id'])
        return {'purpose': PURPOSE, 'instance_id': self.acq.instance_id, 'operation': operation,
            'record': record, 'needs_review': operation['state'] in ('started', 'unknown'), **_LOCAL}

    def _status(self, token, user, data):
        if (set(data) != {'package_id', 'row_id', 'operation_action', 'idempotency_key'}
                or type(data.get('package_id')) is not str or not _HEX.fullmatch(data['package_id'])
                or data.get('operation_action') not in WRITES
                or type(data.get('idempotency_key')) is not str or not _KEY.fullmatch(data['idempotency_key'])
                or data['operation_action'] == DELIVERY and data['row_id'] is not None
                or data['operation_action'] == FEEDBACK and (type(data['row_id']) is not str or not _HEX.fullmatch(data['row_id']))):
            _fail('核对只接受原包、原行和原登记编号')
        with self.core.store.connect() as db:
            package = self._package(db, token, user, data['package_id'])
        receipts = _FollowupReceipts(self, token, user, package, data['operation_action'], data['row_id'], seal=_SEAL)
        try:
            outcome = receipts.status(data['operation_action'], data['idempotency_key'])
        except Exception:
            raise OwnerAcquisitionError('原登记状态未确认，请保留原号', mutation_committed=None) from None
        return self._outcome(token, user, package, receipts, outcome)

    def _delivery(self, db, package, user):
        try:
            slot = self._slot(db, package, user, DELIVERY, None)
            events, more = self._history(db, slot)
            event = events[0] if events else None
            review = slot is not None and slot['pending_key'] is not None
            return {'revision': slot['revision'] if slot else 0,
                'report_state': 'needs_review' if review else 'operator_reported_delivered' if event else 'unrecorded_unknown',
                'last_event_id': event['event_id'] if event else None,
                'delivery_method': event['category'] if event else None,
                'occurred_at': event['occurred_at'] if event else None,
                'recorded_at': event['recorded_at'] if event else None,
                'evidence_operation_id': event['evidence_operation_id'] if event else None,
                'events': events, 'history_more': more}
        except (OwnerAcquisitionError, ValueError, TypeError, KeyError):
            return {'revision': None, 'report_state': 'needs_review', 'last_event_id': None,
                'delivery_method': None, 'occurred_at': None, 'recorded_at': None,
                'evidence_operation_id': None, 'events': [], 'history_more': True}

    def _rows(self, db, token, user, package, *, fresh):
        rows = []
        for index, row_id in enumerate(self._row_ids(package)):
            selected = package['selection'][index]
            try:
                authorization = self._row_proof(db, token, user, package, index) if fresh else {
                    'state': 'needs_review', 'checked_at': time.time(), 'reason_code': 'METADATA_ONLY'}
                slot = self._slot(db, package, user, FEEDBACK, row_id)
                events, more = self._history(db, slot)
                event = events[0] if events else None
                pending = slot is not None and slot['pending_key'] is not None
                rows.append({'row_id': row_id, 'draft_id': selected['draft_id'],
                    'account_id': selected['account_id'] if fresh else None, 'lead_id': selected['lead_id'] if fresh else None,
                    'source_verified': fresh, 'authorization': authorization,
                    'feedback_revision': slot['revision'] if slot else 0,
                    'feedback_state': 'needs_review' if pending else event['category'] if event else 'unrecorded_unknown',
                    'last_event_id': event['event_id'] if event else None,
                    'occurred_at': event['occurred_at'] if event else None,
                    'recorded_at': event['recorded_at'] if event else None, 'needs_review': pending or not fresh,
                    'events': events, 'history_more': more})
            except (OwnerAcquisitionError, ValueError, TypeError, KeyError):
                rows.append({'row_id': row_id, 'draft_id': selected['draft_id'], 'account_id': None, 'lead_id': None,
                    'source_verified': False, 'authorization': _auth(), 'feedback_revision': None,
                    'feedback_state': 'needs_review', 'last_event_id': None, 'occurred_at': None,
                    'recorded_at': None, 'needs_review': True, 'events': [], 'history_more': True})
        return rows

    def _item(self, package, delivery, rows, fresh):
        counts = {k: 0 for k in ('unrecorded_unknown', *sorted(FEEDBACKS), 'needs_review')}
        for row in rows:
            counts[row['feedback_state']] += 1
        bad = any(r['feedback_revision'] is None for r in rows) or delivery['revision'] is None
        if bad:
            counts = {k: None for k in counts}
        state = 'needs_review'
        if fresh and all(r['source_verified'] for r in rows):
            state = 'withdrawn' if any(r['authorization']['state'] == 'withdrawn' for r in rows) else 'current_recorded_scope'
        return {'package_id': package['id'], 'selection_digest': package['selection_digest'],
            'recipient_id': package['recipient_id'], 'handoff_purpose': package['handoff_purpose'],
            'generated_at': package['artifact']['generated_at'], 'selected_count': len(package['selection']),
            'delivery_revision': delivery['revision'], 'delivery_report_state': delivery['report_state'],
            'feedback_counts': counts, 'authorization': _auth(state),
            'needs_review': bad or any(r['needs_review'] for r in rows) or delivery['report_state'] == 'needs_review'}

    def _detail(self, token, user, data):
        if set(data) != {'package_id'} or type(data['package_id']) is not str or not _HEX.fullmatch(data['package_id']):
            _fail('请选择原资料包')
        with self.core.store.connect() as db:
            package = self._package(db, token, user, data['package_id'])
            delivery = self._delivery(db, package, user)
            rows = self._rows(db, token, user, package, fresh=True)
            item = self._item(package, delivery, rows, True)
            self.acq._packages._session(db, token, user)
        return {'purpose': PURPOSE, 'instance_id': self.acq.instance_id, 'package': item,
            'delivery': delivery, 'rows': rows, 'needs_review': item['needs_review'], **_LOCAL}

    def _list(self, token, user, data):
        if (set(data) != {'limit', 'cursor', 'filter'} or type(data['limit']) is not int
                or not 1 <= data['limit'] <= 50 or type(data['filter']) is not str or data['filter'] not in ('all', 'needs_followup')):
            _fail('工作池只接受固定筛选和每页1至50包')
        cursor = data['cursor']
        if cursor is None:
            cutoff, after = time.time(), {'created_at': 0, 'package_id': ''}
        else:
            if (type(cursor) is not dict or set(cursor) != {'schema', 'instance_id', 'filter', 'cutoff', 'after'}
                    or cursor['schema'] != 'owner_handoff_followup_cursor_v1' or cursor['instance_id'] != self.acq.instance_id
                    or cursor['filter'] != data['filter'] or type(cursor['cutoff']) not in (int, float)
                    or not math.isfinite(cursor['cutoff']) or not 0 < cursor['cutoff'] <= time.time()
                    or type(cursor['after']) is not dict or set(cursor['after']) != {'created_at', 'package_id'}
                    or type(cursor['after']['created_at']) not in (int, float) or not math.isfinite(cursor['after']['created_at'])
                    or not 0 < cursor['after']['created_at'] <= cursor['cutoff']
                    or type(cursor['after']['package_id']) is not str or not _HEX.fullmatch(cursor['after']['package_id'])):
                _fail('工作池页码需重新明确核对')
            cutoff, after = cursor['cutoff'], cursor['after']
        with self.core.store.connect() as db:
            self.acq._packages._session(db, token, user)
            candidates = db.execute("SELECT id,body FROM records WHERE entity=? AND tenant_id=? "
                "AND json_extract(body,'$.created_at')<=? AND (json_extract(body,'$.created_at')>? "
                "OR (json_extract(body,'$.created_at')=? AND id>?)) "
                "ORDER BY json_extract(body,'$.created_at'),id LIMIT 201",
                (PACKAGES, self.acq.tenant, cutoff, after['created_at'], after['created_at'], after['package_id'])).fetchall()
            items, examined, reviews, last = [], 0, 0, after
            for candidate in candidates[:200]:
                raw = json.loads(candidate['body'])
                last = {'created_at': raw.get('created_at'), 'package_id': candidate['id']}
                examined += 1
                try:
                    package = self._package(db, token, user, candidate['id'])
                    delivery = self._delivery(db, package, user)
                    rows = self._rows(db, token, user, package, fresh=False)
                    item = self._item(package, delivery, rows, False)
                    # Metadata listing never proves each current source consent.
                    # All valid original packages remain available to open.
                    needs = delivery['report_state'] != 'operator_reported_delivered' or any(
                        r['feedback_state'] != 'reported_received' for r in rows)
                    if data['filter'] == 'all' or needs:
                        items.append(item)
                        reviews += int(item['needs_review'])
                    if len(items) == data['limit']:
                        break
                except (OwnerAcquisitionError, ValueError, TypeError, KeyError):
                    # Do not project foreign owner/pair/body identifiers.
                    continue
            has_more = examined < len(candidates)
            next_cursor = {'schema': 'owner_handoff_followup_cursor_v1', 'instance_id': self.acq.instance_id,
                'filter': data['filter'], 'cutoff': cutoff, 'after': last} if has_more else None
            self.acq._packages._session(db, token, user)
        return {'purpose': PURPOSE, 'instance_id': self.acq.instance_id, 'items': items,
            'returned_count': len(items), 'scanned_count': examined, 'needs_review_count': reviews,
            'page': {'has_more': has_more, 'cursor': next_cursor, 'partial': has_more or reviews > 0,
                'cutoff': cutoff, 'scope': 'this_owner_instance'}, 'snapshot_verified': False, **_LOCAL}

    def execute(self, token, action, data):
        # Acq dispatcher already holds workspace -> core continuously. Reentrant
        # entry preserves this order for any internal caller, without nested BEGIN.
        if action not in ACTIONS or type(data) is not dict:
            _fail('不支持此人工跟进动作')
        with self.workspace._lock, self.core.lock:
            user = self.acq._current(token)
            if action == LIST:
                return self._list(token, user, data)
            if action == DETAIL:
                return self._detail(token, user, data)
            if action == STATUS:
                return self._status(token, user, data)
            return self._write(token, user, action, data)
