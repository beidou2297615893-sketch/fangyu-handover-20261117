"""Stage-only bridge from a trusted owned search receipt to the private index.

Current PlatformReadService retains normalized response only, and its
owned_receipt context accepts comments only. PlatformReceiptArchive also saves
comments only. Neither is an existing raw-search provider. A future trusted
host must retain the successful execute_read output privately and implement
owned_search_receipt(binding, request_id) as a lock-held context that checks the
original actor/account/request, cancellation and live scope before AND after
yield. It yields TrustedOwnedSearchReceipt, never caller-supplied JSON.

This adapter uses the real read-result hash, archive batch hash, and transport
raw-post extraction/projection contracts. It starts no read, writes no archive,
and adds no production route. Only capture(binding, request_id) and
resolve_post(binding, numeric_mid) are exposed; no raw/receipt-hash payloads.
"""
from collections import OrderedDict
from copy import deepcopy
from dataclasses import dataclass
from hmac import compare_digest
from pathlib import Path
import re
from threading import RLock

from core.platform_reads import _digest, _REQUEST
from assistant.platform_receipt_archive import _hash
from core.weibo_read_contract import _items, _map
from core.owned_search_post_index import (
    OwnedPostIndexStopped, OwnedSearchOrigin, OwnedSearchPostIndex, OwnedSearchScope,
)


@dataclass(frozen=True)
class TrustedOwnedSearchReceipt:
    """Host-only extension of the actual read snapshot; this is NOT an RPC DTO."""
    scope: OwnedSearchScope
    snapshot: dict
    transport_result: dict
    raw_response_sha256: str


@dataclass(frozen=True)
class _ReceiptReference:
    request_id: str
    operation_id: str
    result_digest: str
    receipt_digest: str
    snapshot_digest: str
    raw_digest: str


_MID = re.compile(r'[1-9][0-9]{0,31}')
_SHA = re.compile(r'[0-9a-f]{64}')
_OPERATION = re.compile(r'[A-Za-z0-9_.-]{1,128}')
_SOURCE_KEYS = ('platform', 'source_type', 'source_id', 'post_id', 'author_id', 'url', 'text')


class OwnedSearchReceiptAdapter:
    def __init__(self, scope, *, live_authority, owned_search_receipt,
                 max_posts=256, max_bytes=2 * 1024 * 1024):
        if not callable(owned_search_receipt):
            raise OwnedPostIndexStopped('owned_search_receipt_provider_required')
        self._scope, self._authority = scope, live_authority
        self._provider = owned_search_receipt
        self._index, self._writer = OwnedSearchPostIndex.for_trusted_host(
            scope, live_authority=live_authority, max_posts=max_posts, max_bytes=max_bytes)
        self._references = OrderedDict()
        self._max_posts, self._lock = max_posts, RLock()

    def _check_current(self, binding, operation):
        scope = self._scope
        try:
            matches = (binding.identity_verified is True and binding.tenant_id == scope.tenant_id
                       and binding.account_id == scope.account_id and binding.platform_uid == scope.platform_uid
                       and Path(binding.account_root) == scope.account_root
                       and isinstance(binding.credential_sha256, str)
                       and compare_digest(binding.credential_sha256.lower(), scope.credential_sha256))
        except (AttributeError, TypeError, ValueError):
            matches = False
        if not matches:
            raise OwnedPostIndexStopped('owned_search_binding_mismatch')
        current = self._authority(binding, operation)
        if not isinstance(current, OwnedSearchScope) or current != scope:
            raise OwnedPostIndexStopped('owned_search_scope_changed')

    def _verify(self, trusted, request_id):
        try:
            return self._verify_receipt(trusted, request_id)
        except OwnedPostIndexStopped:
            raise
        except Exception:
            raise OwnedPostIndexStopped('owned_search_receipt_invalid') from None

    def _verify_receipt(self, trusted, request_id):
        if not isinstance(trusted, TrustedOwnedSearchReceipt) or trusted.scope != self._scope:
            raise OwnedPostIndexStopped('owned_search_receipt_scope_mismatch')
        snapshot, output = deepcopy(trusted.snapshot), deepcopy(trusted.transport_result)
        if type(snapshot) is not dict or type(output) is not dict:
            raise OwnedPostIndexStopped('owned_search_raw_receipt_required')
        result, origin = snapshot.get('result'), snapshot.get('origin')
        operation_id = snapshot.get('operation_id')
        if (snapshot.get('request_id') != request_id or not isinstance(operation_id, str)
                or not _OPERATION.fullmatch(operation_id) or type(result) is not dict
                or type(origin) is not dict or result.get('operation_id') != operation_id
                or result.get('platform') != 'weibo' or result.get('action') != 'search'
                or result.get('code') != 'completed' or result.get('status') != 'completed'
                or result.get('limit_exceeded') is not False or result.get('auto_retry') is not False
                or result.get('platform_writes') is not False):
            raise OwnedPostIndexStopped('owned_search_success_receipt_required')
        scope, actor = self._scope, origin.get('actor')
        if (type(actor) is not dict or not isinstance(actor.get('id'), str) or not actor['id']
                or actor.get('tenant_id') != scope.tenant_id or actor.get('username') != scope.owner_id
                or actor.get('role') not in ('operator', 'admin') or actor.get('cloud_bound') is not True
                or origin.get('device_id') != scope.device_id or origin.get('account_id') != scope.account_id
                or origin.get('account_uid') != scope.platform_uid or origin.get('platform') != 'weibo'
                or origin.get('archive_scope_verified') is not True
                or any(not isinstance(origin.get(key), str) or not _SHA.fullmatch(origin[key])
                       for key in ('account_binding_digest', 'connection_digest', 'license_digest', 'input_digest'))):
            raise OwnedPostIndexStopped('owned_search_receipt_scope_mismatch')
        # PlatformReadService hashes result with insertion-order JSON; archive
        # hashes a sorted canonical [origin, result_digest, operation_id] tuple.
        result_digest = snapshot.get('result_digest')
        if not isinstance(result_digest, str) or not compare_digest(_digest(result), result_digest):
            raise OwnedPostIndexStopped('owned_search_receipt_digest_mismatch')
        raw = output.get('raw')
        if (output.get('platform') != 'weibo' or output.get('operation') != 'search'
                or type(output.get('requested_page')) is not int or output['requested_page'] != 1
                or type(raw) is not dict or type(raw.get('ok')) is not int or raw['ok'] != 1):
            raise OwnedPostIndexStopped('owned_search_raw_receipt_required')
        raw_digest = _hash(raw)
        if (not isinstance(trusted.raw_response_sha256, str)
                or not compare_digest(raw_digest, trusted.raw_response_sha256)):
            raise OwnedPostIndexStopped('owned_search_raw_digest_mismatch')
        mapped = _map(raw)
        sources = result.get('items')
        if (output.get('items') != mapped or type(sources) is not list or len(sources) != len(mapped)
                or any(type(item) is not dict for item in sources)
                or [{key: item.get(key) for key in _SOURCE_KEYS} for item in sources]
                != [{key: item.get(key) for key in _SOURCE_KEYS} for item in mapped]
                or type(result.get('observed_count')) is not int or result['observed_count'] != len(mapped)
                or type(result.get('requested_limit')) is not int
                or not len(mapped) <= result['requested_limit'] <= 1000):
            raise OwnedPostIndexStopped('owned_search_raw_source_mismatch')
        receipt_digest = _hash([origin, result_digest, operation_id])
        reference = _ReceiptReference(request_id, operation_id, result_digest,
                                      receipt_digest, _hash(snapshot), raw_digest)
        return _items(raw, 'search'), reference

    def capture_owned_search(self, binding, read_request_id):
        """Host admission takes only an owned request reference, never raw/hash."""
        if not isinstance(read_request_id, str) or not _REQUEST.fullmatch(read_request_id):
            raise OwnedPostIndexStopped('owned_search_request_invalid')
        with self._lock:
            self._check_current(binding, 'search')
            with self._provider(binding, read_request_id) as trusted:
                posts, reference = self._verify(trusted, read_request_id)
                self._check_current(binding, 'search')
            # Do not publish until the provider's final lock-held permission /
            # original-receipt/cancellation check has successfully exited.
            self._check_current(binding, 'search')
            count = self._writer(binding, posts, origin=OwnedSearchOrigin(
                reference.request_id, reference.operation_id, reference.receipt_digest))
            for post in posts:
                mid = str(post.get('idstr') or post.get('id'))
                self._references.setdefault(mid, reference)
                self._references.move_to_end(mid)
            while len(self._references) > self._max_posts:
                self._references.popitem(last=False)
            return count

    def resolve_post(self, binding, numeric_mid):
        """Reopen the original owned search receipt under live authority each time."""
        with self._lock:
            self._check_current(binding, 'comments')
            if not isinstance(numeric_mid, str) or not _MID.fullmatch(numeric_mid):
                raise OwnedPostIndexStopped('owned_post_numeric_mid_required')
            original = self._references.get(numeric_mid)
            if original is None:
                raise OwnedPostIndexStopped('owned_post_source_required')
            with self._provider(binding, original.request_id) as trusted:
                posts, current = self._verify(trusted, original.request_id)
                if current != original:
                    raise OwnedPostIndexStopped('owned_search_original_receipt_changed')
                post = self._index.resolve_post(binding, numeric_mid)
                matching = [raw for raw in posts if str(raw.get('idstr') or raw.get('id')) == numeric_mid]
                if not matching or any(raw != post for raw in matching):
                    raise OwnedPostIndexStopped('owned_search_original_post_changed')
                self._check_current(binding, 'comments')
            self._check_current(binding, 'comments')
            return post
