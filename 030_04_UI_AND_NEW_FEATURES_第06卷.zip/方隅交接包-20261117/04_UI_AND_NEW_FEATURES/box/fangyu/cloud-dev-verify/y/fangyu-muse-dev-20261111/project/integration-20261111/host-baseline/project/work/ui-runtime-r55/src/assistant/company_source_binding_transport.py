"""One exact original source read, reusing the no-renewal session capture."""
from copy import deepcopy
import re
from .company_handoff_status_transport import (CompanyHandoffStatusTransport,
    CompanyHandoffStatusTransportError)

ACTION='acquisition_source_binding_read'
_UUID=re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z')
_HEX=re.compile(r'[a-f0-9]{64}\Z')
_DEVICE=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')

class CompanySourceBindingReadTransportError(ValueError):
    def __init__(self,code,message,status=503):
        super().__init__(message)
        self.code='COMPANY_SOURCE_BINDING_READ_'+code
        self.status=status
        self.mutation_committed=False

def _fail(code,message,status=503):
    raise CompanySourceBindingReadTransportError(code,message,status)

class CompanySourceBindingReadTransport(CompanyHandoffStatusTransport):
    def _source_capture(self,actor,margin):
        try:
            return self._capture(actor,margin)
        except CompanyHandoffStatusTransportError as error:
            if error.code=='COMPANY_HANDOFF_STATUS_SESSION_REQUIRED':
                _fail('SESSION_REQUIRED','当前公司来源核对需要现有有效登录，请在设置中明确连接',409)
            _fail('BINDING_CHANGED','当前员工、公司或电脑范围已变化，请回到原范围核对来源',409)

    def __call__(self,actor,operation,data):
        if (operation!=ACTION or not isinstance(data,dict)
                or set(data)!={'event_id','payload_hash','expected_device_id'}
                or not isinstance(data.get('event_id'),str) or not _UUID.fullmatch(data['event_id'])
                or not isinstance(data.get('payload_hash'),str) or not _HEX.fullmatch(data['payload_hash'])
                or not isinstance(data.get('expected_device_id'),str) or not _DEVICE.fullmatch(data['expected_device_id'])):
            _fail('INVALID_REQUEST','来源核对需要本机已保存的原准备，不能输入另一事件',400)
        before=self._source_capture(actor,60)
        from integrations import request_json
        try:
            result=request_json(before['endpoint'],{'environment_id':self.environment_id,
                'operation':ACTION,**deepcopy(data)},before['token'])
        except Exception:
            _fail('READ_UNAVAILABLE','原来源公司记录暂不可读，请保留原准备；此次未上传或重发')
        after=self._source_capture(actor,0)
        if after!=before:
            _fail('BINDING_CHANGED','返回时公司连接已变化，请在原范围重新核对来源',409)
        fields={'contract','environment_id','company_id','source_binding','read_only','mutation_committed','auto_retry'}
        if (not isinstance(result,dict) or set(result)!=fields
                or result.get('contract')!='fangyu-workspace-v1'
                or result.get('environment_id')!=self.environment_id or result.get('company_id')!=self.company_id
                or result.get('read_only') is not True or result.get('mutation_committed') is not False
                or result.get('auto_retry') is not False or not isinstance(result.get('source_binding'),dict)):
            _fail('READ_UNAVAILABLE','原来源公司回执的身份或格式需核对，原准备继续保留')
        try:
            self._principal(actor)
        except CompanyHandoffStatusTransportError:
            _fail('BINDING_CHANGED','返回时员工或公司范围已变化，请在原范围重新核对来源',409)
        return {key:deepcopy(result[key])for key in ('source_binding','read_only','mutation_committed','auto_retry')}
