"""Pure original Weibo contract and immutable identity types; no runtime/IO."""
from dataclasses import dataclass
from html import unescape
from pathlib import Path
import re

class ReadStopped(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class AccountBinding:
    account_root: Path
    tenant_id: str
    account_id: str
    platform_uid: str
    credential_sha256: str
    identity_verified: bool


def _items(payload, operation):
    data = payload.get('data')
    if operation == 'search':
        cards = data.get('cards') if isinstance(data, dict) else None
        if not isinstance(cards, list):
            raise ReadStopped('protocol_error')
        posts = []
        for card in cards:
            if not isinstance(card, dict):
                raise ReadStopped('protocol_error')
            if card.get('mblog'):
                posts.append(card['mblog'])
            group = card.get('card_group', [])
            if not isinstance(group, list) or any(not isinstance(row, dict) for row in group):
                raise ReadStopped('protocol_error')
            posts.extend(row['mblog'] for row in group if row.get('mblog'))
        return posts
    rows = data.get('data') if isinstance(data, dict) else data
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ReadStopped('protocol_error')
    return rows


def _identifier(item):
    value = str(item.get('idstr') or item.get('id') or '')
    if not re.fullmatch(r'[1-9][0-9]{0,31}', value):
        raise ReadStopped('protocol_error')
    return value


def _map(payload):
    result = []
    for post in _items(payload, 'search'):
        if not isinstance(post, dict) or not isinstance(post.get('user'), dict):
            raise ReadStopped('protocol_error')
        user = post['user']
        post_id, author_id = _identifier(post), _identifier(user)
        bid = post.get('bid') or post_id
        if not isinstance(bid, str) or not re.fullmatch(r'[A-Za-z0-9]{1,32}', bid):
            raise ReadStopped('protocol_error')
        if not isinstance(post.get('text', ''), str):
            raise ReadStopped('protocol_error')
        result.append({'platform': 'weibo', 'source_id': post_id, 'post_id': post_id,
                       'author_id': author_id, 'author': user.get('screen_name', ''),
                       'text': unescape(re.sub(r'<[^>]+>', '', post.get('text', ''))),
                       'url': f'https://weibo.com/{author_id}/{bid}', 'source_type': 'note',
                       'published_at': post.get('created_at', ''), 'source': post.get('source', '')})
    return result


def _map_comments(payload, post_id, post_url):
    result = []
    for comment in _items(payload, 'comments'):
        user = comment.get('user')
        if not isinstance(user, dict) or not isinstance(comment.get('text', ''), str):
            raise ReadStopped('protocol_error')
        comment_id, author_id = _identifier(comment), _identifier(user)
        result.append({'platform': 'weibo', 'source_id': comment_id, 'comment_id': comment_id,
                       'post_id': post_id, 'author_id': author_id, 'author': user.get('screen_name', ''),
                       'text': unescape(re.sub(r'<[^>]+>', '', comment.get('text', ''))),
                       'note_url': post_url, 'url': post_url, 'source_type': 'comment',
                       'published_at': comment.get('created_at', ''), 'source': comment.get('source', '')})
    return result


def _known_post_url(binding, post_id, resolve_post):
    # This callback belongs to the trusted host: it must read an owned successful
    # original search receipt in the current account scope. It is never a payload.
    if not callable(resolve_post):
        raise ReadStopped('owned_post_source_required')
    post = resolve_post(binding, post_id)
    if not isinstance(post, dict) or not isinstance(post.get('user'), dict):
        raise ReadStopped('owned_post_source_required')
    ids = [str(post[name]) for name in ('idstr', 'id') if name in post]
    bid = post.get('bid')
    if (not ids or any(value != post_id for value in ids)
            or not isinstance(bid, str) or not re.fullmatch(r'[A-Za-z0-9]{1,32}', bid)):
        raise ReadStopped('known_post_source_mismatch')
    author_id = _identifier(post['user'])
    author_ids = [str(post['user'][name]) for name in ('idstr', 'id') if name in post['user']]
    if any(value != author_id for value in author_ids):
        raise ReadStopped('known_post_source_mismatch')
    return f'https://weibo.com/{author_id}/{bid}'


@dataclass(frozen=True, repr=False)
class IdentityScope:
    account_root: Path
    tenant_id: str
    owner: str
    device_id: str
    account_id: str
    account_revision: str
    license_revision: str
    license_approved: bool


@dataclass(frozen=True, repr=False)
class VerifiedIdentity:
    identity_receipt_id: str
    tenant_id: str
    owner: str
    device_id: str
    account_id: str
    account_revision: str
    license_revision: str
    platform_uid: str
    credential_sha256: str
    response_sha256: str
    receipt_sha256: str

