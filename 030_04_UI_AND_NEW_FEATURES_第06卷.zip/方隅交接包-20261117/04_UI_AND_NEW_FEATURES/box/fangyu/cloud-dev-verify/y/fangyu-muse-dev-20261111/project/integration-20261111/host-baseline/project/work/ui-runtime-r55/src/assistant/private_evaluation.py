"""Narrow, current-user permit for the private fresh-install evaluation.

This is not a production release approval. The cloud's exact-device QA hold is
still authoritative for every platform request.
"""
import ctypes
from ctypes import wintypes
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

from integrations import protect


COMPANY_ID = 'fangyu-apartment-client'
ENVIRONMENT_ID = 'fh6-d5ga45c0ddae7008c'
ENDPOINT = ('https://fh6-d5ga45c0ddae7008c-1439321968.'
            'ap-shanghai.app.tcloudbase.com/fangyu-workspace')
VERSION = '1.1.7-qa.1'
SOURCE_SHA256 = '2580bd579de76191a5bfd33109c612287f19c94bc55dc10fb64873a31676bb31'
EXE_NAME = '方隅公寓本地助手.exe'
GRANT_NAME = 'private-install-evaluation.dpapi'
DATA_MARKER = 'private-evaluation-session.json'
GRANT_KEYS = {'schema', 'company_id', 'session_id', 'executable_sha256',
              'install_root', 'data_root', 'expires_at', 'windows_sid'}


class PrivateEvaluationError(ValueError):
    pass


@dataclass(frozen=True)
class Capability:
    session_id: str
    executable_sha256: str
    install_root: Path
    data_root: Path
    probe: bool
    expires_at: datetime


def source_config_valid(config):
    """Recognize only the explicitly marked, still-held private bundle."""
    if not isinstance(config, dict):
        return False
    runtime = config.get('runtime')
    managed = config.get('managedWorkspace')
    feed = config.get('updateFeed')
    return bool(
        config.get('id') == COMPANY_ID
        and config.get('edition') == 'customer'
        and config.get('personalMode') is False
        and config.get('authMode') == 'managed'
        and config.get('releaseVersion') == VERSION
        and set(config.get('platforms') or []) == {'xiaohongshu'}
        and isinstance(managed, dict)
        and managed.get('environment_id') == ENVIRONMENT_ID
        and managed.get('endpoint') == ENDPOINT
        and isinstance(runtime, dict)
        and runtime.get('role') == 'local_assistant_only'
        and runtime.get('ui_entry') == 'employee_workspace'
        and runtime.get('executable') == EXE_NAME
        and runtime.get('xiaohongshu_read_transport') == 'guarded_cli_v1'
        and runtime.get('cli_source_sha256') == SOURCE_SHA256
        and runtime.get('release_approved') is False
        and runtime.get('xiaohongshu_automation') == 'hold'
        and runtime.get('private_evaluation') is True
        and not runtime.get('platform_qa_device_id')
        and isinstance(runtime.get('private_evaluation_session_id'), str)
        and re.fullmatch(r'[0-9a-f]{32}', runtime['private_evaluation_session_id']) is not None
        and (feed is None or isinstance(feed, dict) and feed.get('enabled') is False)
    )


def runtime_config_valid(config, capability, device_id=''):
    """Accept the source hold or its process-only QA activation, never GA."""
    if not isinstance(capability, Capability) or not isinstance(config, dict):
        return False
    runtime = config.get('runtime')
    if not isinstance(runtime, dict) or runtime.get('private_evaluation_session_id') != capability.session_id:
        return False
    if not device_id:
        return source_config_valid(config)
    if (not isinstance(device_id, str)
            or re.fullmatch(r'[A-Za-z0-9_-]{16,80}', device_id) is None
            or runtime.get('platform_qa_device_id') != device_id
            or runtime.get('xiaohongshu_automation') != 'enabled'):
        return False
    original = {**config, 'runtime': {**runtime, 'xiaohongshu_automation': 'hold'}}
    original['runtime'].pop('platform_qa_device_id', None)
    return source_config_valid(original)


def ensure_current(capability, now=None):
    if (not isinstance(capability, Capability) or
            capability.expires_at <= (now or datetime.now(timezone.utc))):
        raise PrivateEvaluationError('私下安装许可已过期')


def activate_bound_assistant(service, capability):
    """Use a fresh bound identity; the authenticated cloud poll must still allow it."""
    ensure_current(capability)
    if capability.probe:
        return False
    saved = service.vault.read()
    if not saved or saved.get('state') != 'bound':
        return False
    device = saved.get('device')
    if not isinstance(device, dict):
        raise PrivateEvaluationError('本机电脑绑定记录无效')
    device_id, owner = device.get('id'), device.get('owner')
    if (not isinstance(device_id, str) or re.fullmatch(r'[A-Za-z0-9_-]{16,80}', device_id) is None
            or not isinstance(owner, str) or not owner.strip() or owner != owner.strip()):
        raise PrivateEvaluationError('本机电脑归属记录无效')
    server = service.server
    runtime = server.company.get('runtime') or {}
    if not (runtime_config_valid(server.company, capability)
            or runtime_config_valid(server.company, capability, device_id)):
        raise PrivateEvaluationError('私下安装运行配置已改变')
    tenant = 'cloud-' + hashlib.sha256((service.environment_id + '\n' + service.company_id).encode()).hexdigest()[:24]
    user_id = hashlib.sha256((tenant + '\n' + owner).encode()).hexdigest()
    user = server.core.store.get('users', user_id)
    if (not isinstance(user, dict) or user.get('tenant_id') != tenant
            or user.get('username') != owner or user.get('role') != 'operator'
            or user.get('cloud_bound') is not True or user.get('disabled')):
        raise PrivateEvaluationError('本机绑定员工身份尚未通过企业登录核对')
    server.core.remote_safety_hold = True
    runtime.update(platform_qa_device_id=device_id, xiaohongshu_automation='enabled')
    server.core.deployment_config.setdefault('runtime', {}).update(
        platform_qa_device_id=device_id, xiaohongshu_automation='enabled')
    return True


def current_windows_sid():
    """Read the current process token SID without a shell or extra dependency."""
    if os.name != 'nt':
        raise PrivateEvaluationError('私下安装验收仅支持 Windows')
    token = wintypes.HANDLE()
    advapi = ctypes.windll.advapi32
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    advapi.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi.OpenProcessToken.restype = wintypes.BOOL
    advapi.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                            wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    advapi.GetTokenInformation.restype = wintypes.BOOL
    advapi.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    advapi.ConvertSidToStringSidW.restype = wintypes.BOOL
    if not advapi.OpenProcessToken(kernel.GetCurrentProcess(), 0x0008, ctypes.byref(token)):
        raise PrivateEvaluationError('无法读取当前 Windows 用户身份')
    try:
        required = wintypes.DWORD()
        advapi.GetTokenInformation(token, 1, None, 0, ctypes.byref(required))
        if required.value < ctypes.sizeof(ctypes.c_void_p) or required.value > 65536:
            raise PrivateEvaluationError('当前 Windows 用户身份无效')
        buffer = ctypes.create_string_buffer(required.value)
        if not advapi.GetTokenInformation(token, 1, buffer, required, ctypes.byref(required)):
            raise PrivateEvaluationError('无法读取当前 Windows 用户身份')
        sid_pointer = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_void_p))[0]
        sid_string = ctypes.c_void_p()
        if not sid_pointer or not advapi.ConvertSidToStringSidW(sid_pointer, ctypes.byref(sid_string)):
            raise PrivateEvaluationError('无法核对当前 Windows 用户身份')
        try:
            return ctypes.wstring_at(sid_string)
        finally:
            kernel.LocalFree(sid_string)
    finally:
        kernel.CloseHandle(token)


def _same_path(left, right):
    return os.path.normcase(str(Path(left).resolve())) == os.path.normcase(str(Path(right).resolve()))


def _sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _probe_directory(path):
    directory = Path(path)
    temp = Path(tempfile.gettempdir()).resolve()
    if (not re.fullmatch(r'fangyu-release-probe-[A-Za-z0-9_-]{4,80}', directory.name)
            or directory.is_symlink() or not directory.is_dir()
            or directory.parent.resolve() != temp or any(directory.iterdir())):
        raise PrivateEvaluationError('私下安装探测必须使用系统临时目录下的全新空目录')


def validate(config, executable, data_dir, *, headless=False, local_appdata=None,
             grant_path=None, now=None, sid=None, unprotect=None):
    """Validate before creating a data directory or loading customer state.

    `sid`, `unprotect`, `now` and paths are injectable solely for hermetic tests.
    Production callers omit them and use CurrentUser DPAPI and the real token.
    """
    if not source_config_valid(config):
        raise PrivateEvaluationError('当前程序不是固定的方隅私下安装验收包')
    if os.name != 'nt' and unprotect is None:
        raise PrivateEvaluationError('私下安装验收仅支持 Windows')
    local = Path(local_appdata if local_appdata is not None else os.environ.get('LOCALAPPDATA', ''))
    if not local.is_absolute() or not local.is_dir():
        raise PrivateEvaluationError('当前用户本机目录无效')
    expected_install = local / 'fangyu-apartment-clientWorkspaceApp'
    expected_data = local / 'fangyu-apartment-clientAssistant'
    permit = Path(grant_path) if grant_path is not None else local / 'FangyuMaintenance' / GRANT_NAME
    if (permit.is_symlink() or not permit.is_file() or permit.parent.is_symlink()
            or not _same_path(permit, local / 'FangyuMaintenance' / GRANT_NAME)):
        raise PrivateEvaluationError('当前 Windows 用户的私下安装许可不存在')
    try:
        raw = (unprotect or (lambda value: protect(value, decrypt=True)))(permit.read_bytes())
        grant = json.loads(raw)
    except (OSError, ValueError, TypeError):
        raise PrivateEvaluationError('私下安装许可无法解密或格式无效') from None
    if not isinstance(grant, dict) or set(grant) != GRANT_KEYS or grant.get('schema') != 1:
        raise PrivateEvaluationError('私下安装许可字段无效')
    if (grant.get('company_id') != COMPANY_ID or grant.get('session_id') !=
            config['runtime']['private_evaluation_session_id']
            or not isinstance(grant.get('executable_sha256'), str)
            or re.fullmatch(r'[0-9a-f]{64}', grant['executable_sha256']) is None
            or grant.get('windows_sid') != (sid if sid is not None else current_windows_sid())):
        raise PrivateEvaluationError('私下安装许可与当前用户或程序不匹配')
    try:
        expiry = datetime.fromisoformat(grant['expires_at'].replace('Z', '+00:00'))
    except (AttributeError, TypeError, ValueError):
        raise PrivateEvaluationError('私下安装许可到期时间无效') from None
    clock = now or datetime.now(timezone.utc)
    if expiry.tzinfo is None or clock.tzinfo is None or expiry <= clock.astimezone(timezone.utc):
        raise PrivateEvaluationError('私下安装许可已过期')
    created = datetime.fromtimestamp(permit.stat().st_ctime, timezone.utc)
    if expiry > created + timedelta(days=7, minutes=5):
        raise PrivateEvaluationError('私下安装许可超过七天有效期')
    if (not isinstance(grant.get('install_root'), str) or not isinstance(grant.get('data_root'), str)
            or not _same_path(grant['install_root'], expected_install)
            or not _same_path(grant['data_root'], expected_data)):
        raise PrivateEvaluationError('私下安装许可的安装或数据目录无效')
    exe = Path(executable)
    if exe.name != EXE_NAME or not exe.is_file() or exe.is_symlink():
        raise PrivateEvaluationError('私下安装程序入口无效')
    if (_sha256(exe) != grant['executable_sha256']
            or exe.parent.parent.name != 'releases'
            or not re.fullmatch(r'[1-9][0-9]*', exe.parent.name)
            or not _same_path(exe.parent.parent.parent, expected_install)):
        raise PrivateEvaluationError('私下安装程序字节或安装位置与许可不匹配')
    target = Path(data_dir)
    if headless:
        _probe_directory(target)
        probe = True
    else:
        if not _same_path(target, expected_data) or target.is_symlink():
            raise PrivateEvaluationError('私下安装必须使用固定的全新本机数据目录')
        probe = False
    return Capability(grant['session_id'], grant['executable_sha256'],
                      expected_install.resolve(), expected_data.resolve(), probe, expiry)


def prepare_fresh_data(capability):
    """Keep prior employee state out of this first-use evaluation."""
    if capability.probe:
        return
    root = capability.data_root
    if root.is_symlink() or root.exists() and not root.is_dir():
        raise PrivateEvaluationError('私下安装数据目录无效')
    root.mkdir(parents=True, exist_ok=True)
    marker = root / DATA_MARKER
    if marker.is_symlink():
        raise PrivateEvaluationError('私下安装数据标记无效')
    if marker.is_file():
        try:
            value = json.loads(marker.read_text('utf-8'))
        except (OSError, ValueError):
            raise PrivateEvaluationError('私下安装数据标记损坏') from None
        if value != {'schema': 1, 'session_id': capability.session_id}:
            raise PrivateEvaluationError('本机数据属于另一轮安装验收')
        return
    if any(root.iterdir()):
        raise PrivateEvaluationError('数据目录已有历史资料；请先完成备份并使用全新目录')
    with marker.open('x', encoding='utf-8') as stream:
        json.dump({'schema': 1, 'session_id': capability.session_id}, stream)
        stream.flush()
        os.fsync(stream.fileno())
