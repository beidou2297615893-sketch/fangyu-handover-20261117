"""Pure, resumable Xiaohongshu read adapters. No network, login, CLI or model IO.

The public Interface is initial_checkpoint(scope), next_request(scope, checkpoint)
and consume(scope, checkpoint, request, receipt). A caller must persist the entire
PageProposal atomically before using its proposed checkpoint. Receipts are supplied
by an independently guarded transport; configuration never grants permission.

ProfileSource accepts 1--20 explicit user IDs or official public profile URLs.
InteractionSource accepts mentions/likes/connections for the scope's own account.
All proposed comments are pending model analysis; social signals are only events.
Only explicit bool has_more and string cursor pages are accepted. Unknown shapes
raise ContractError and leave the caller's checkpoint unchanged.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re
from urllib.parse import parse_qsl, urlencode, urlsplit

from .contracts import ContractError, PageProposal, ReadRequest, verify_receipt


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def _string(value):
    return value if isinstance(value, str) and value.strip() else ""


def _page(payload, rows_key, current_cursor, seen_cursors):
    if not isinstance(payload, dict):
        raise ContractError("page must be an object")
    data = payload.get("data", payload)
    for envelope in (payload, data):
        if not isinstance(envelope, dict):
            continue
        if "success" in envelope and envelope["success"] is not True:
            raise ContractError("platform page explicitly failed or has unknown success status")
        if "code" in envelope and (type(envelope["code"]) is not int or envelope["code"] != 0):
            raise ContractError("platform page error code is not an explicit integer zero")
    if not isinstance(data, dict) or not isinstance(data.get(rows_key), list):
        raise ContractError("unsupported page shape: " + rows_key)
    if type(data.get("has_more")) is not bool:
        raise ContractError("has_more must be explicit boolean")
    if not isinstance(data.get("cursor"), str):
        raise ContractError("cursor must be explicit string")
    cursor = data["cursor"]
    if data["has_more"] and (not cursor or cursor == current_cursor or cursor in seen_cursors):
        raise ContractError("page cursor did not advance")
    return data[rows_key], data["has_more"], cursor


def _official_url(value, section):
    if not isinstance(value, str) or len(value) > 2048 or any(ord(c) < 32 or ord(c) == 127 for c in value):
        return None
    sections = (section,) if isinstance(section, str) else section
    try:
        parts = urlsplit(value)
        items = parse_qsl(parts.query, keep_blank_values=True, strict_parsing=True)
        matched = next((prefix for prefix in sections if parts.path.startswith(prefix)), None)
        if (parts.scheme != "https" or parts.hostname not in {"www.xiaohongshu.com", "xiaohongshu.com"}
                or parts.username or parts.password or parts.port not in (None, 443) or parts.fragment
                or matched is None or len(items) > 16 or len(items) != len(dict(items))
                or any(not key or not val or any(ord(c) < 32 or ord(c) == 127 for c in key + val)
                       for key, val in items)):
            return None
    except ValueError:
        return None
    identity = parts.path[len(matched):].rstrip("/")
    return (identity, dict(items)) if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,159}", identity) else None


def _note(row):
    if not isinstance(row, dict):
        return None
    card = row.get("note_card", {})
    card = card if isinstance(card, dict) else {}
    note_id = _string(row.get("note_id")) or _string(row.get("id")) or _string(card.get("note_id"))
    url = _string(row.get("note_url")) or _string(row.get("url"))
    paths = ("/explore/", "/search_result/", "/discovery/item/")
    parsed = _official_url(url, paths) if url else None
    if url and not parsed:
        return None
    if parsed and note_id and parsed[0] != note_id:
        return None
    if parsed:
        note_id = parsed[0]
    token = _string(row.get("xsec_token")) or _string(card.get("xsec_token"))
    origin = _string(row.get("xsec_source")) or _string(card.get("xsec_source"))
    if not re.fullmatch(r"[A-Za-z0-9]+", note_id):
        return None
    if parsed and parsed[1].get("xsec_token"):
        return {"note_id": note_id, "note_url": url}
    if not token:
        return None
    query = {"xsec_token": token}
    if origin and (not parsed or "xsec_source" not in parsed[1]):
        query["xsec_source"] = origin
    base = url if parsed else "https://www.xiaohongshu.com/explore/" + note_id
    separator = "&" if urlsplit(base).query else "?"
    completed = base + separator + urlencode(query)
    return {"note_id": note_id, "note_url": completed} if _official_url(completed, paths) else None


def _comment(row, note, *, parent_id="", parent_text=""):
    if not isinstance(row, dict):
        return None
    user = row.get("user_info", row.get("user", {}))
    user = user if isinstance(user, dict) else {}
    author_id = _string(user.get("user_id")) or _string(row.get("author_id"))
    comment_id = _string(row.get("id")) or _string(row.get("comment_id"))
    text = _string(row.get("content")) or _string(row.get("text"))
    if not author_id or not comment_id or not text:
        return None
    return {"platform": "xiaohongshu", "source_id": "comment:" + comment_id, "note_id": note["note_id"],
            "note_url": note["note_url"], "comment_id": comment_id, "text": text,
            "author_id": author_id, "author": _string(user.get("nickname")),
            "parent_id": parent_id, "parent_text": parent_text,
            # Epoch units/timezone have not been attested by a real transport.
            "published_at": "",
            "analysis_status": "pending", "raw": deepcopy(row)}


def _page_evidence(request, receipt):
    return {"type": "read_page", "operation": request.operation,
            "params": deepcopy(dict(request.params)), "request_digest": receipt.request_digest,
            "scope_fingerprint": receipt.scope_fingerprint, "raw": deepcopy(receipt.payload),
            "transport_evidence": deepcopy(dict(receipt.evidence))}


class ProfileSource:
    kind = "profiles"

    def __init__(self, profiles, *, include_sub_comments=False):
        if (not isinstance(profiles, (list, tuple)) or not 1 <= len(profiles) <= 20
                or type(include_sub_comments) is not bool):
            raise ContractError("profiles require 1--20 entries and explicit sub-comment option")
        self.profiles = []
        for value in profiles:
            if not _string(value):
                raise ContractError("profile must be an explicit ID or official URL")
            parsed = _official_url(value, "/user/profile/") if "://" in value else None
            if "://" in value and not parsed:
                raise ContractError("unsupported profile URL")
            user_id = parsed[0] if parsed else value
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,159}", user_id):
                raise ContractError("invalid profile ID")
            if user_id not in [item["user_id"] for item in self.profiles]:
                self.profiles.append({"user_id": user_id, "profile_url": value if parsed else ""})
        self.include_sub_comments = include_sub_comments
        self.config_digest = _digest([self.profiles, include_sub_comments])

    def initial_checkpoint(self, scope):
        if scope.platform != "xiaohongshu":
            raise ContractError("XHS source requires xiaohongshu scope")
        return {"schema": "xhs-source/1", "kind": self.kind,
                "scope_fingerprint": scope.fingerprint, "config_digest": self.config_digest,
                "seen_notes": [], "jobs": [dict(operation="user_posts", cursor="", seen_cursors=[], **p)
                                             for p in self.profiles]}

    def _validate(self, scope, checkpoint):
        if (scope.platform != "xiaohongshu" or not isinstance(checkpoint, dict)
                or checkpoint.get("schema") != "xhs-source/1" or checkpoint.get("kind") != self.kind
                or checkpoint.get("scope_fingerprint") != scope.fingerprint
                or checkpoint.get("config_digest") != self.config_digest
                or not isinstance(checkpoint.get("jobs"), list)):
            raise ContractError("checkpoint does not match source and scope")

    def next_request(self, scope, checkpoint):
        self._validate(scope, checkpoint)
        if not checkpoint["jobs"]:
            return None
        job = checkpoint["jobs"][0]
        if job["operation"] == "user_posts":
            return ReadRequest("user_posts", {"user_id": job["user_id"], "cursor": job["cursor"]})
        if job["operation"] == "sub_comments":
            return ReadRequest("sub_comments", {"note_url": job["note_url"],
                                                "root_comment_id": job["parent_id"], "cursor": job["cursor"]})
        return ReadRequest("comments", {"note_url": job["note_url"], "cursor": job["cursor"]})

    def consume(self, scope, checkpoint, request, receipt):
        self._validate(scope, checkpoint)
        expected = self.next_request(scope, checkpoint)
        if expected is None or request.digest(scope) != expected.digest(scope):
            raise ContractError("request does not match checkpoint")
        verify_receipt(scope, request, receipt)
        proposal = PageProposal(checkpoint=deepcopy(checkpoint))
        job = proposal.checkpoint["jobs"].pop(0)
        rows, has_more, cursor = _page(receipt.payload,
                                       "notes" if job["operation"] == "user_posts" else "comments",
                                       job["cursor"], job["seen_cursors"])
        discovered = []
        if job["operation"] == "user_posts":
            for row in rows:
                note = _note(row)
                if note is None:
                    proposal.unresolved.append({"reason": "missing_note_access_context", "raw": deepcopy(row)})
                    continue
                proposal.evidence.append({"type": "profile_note", "profile_id": job["user_id"],
                                          **note, "raw": deepcopy(row)})
                if note["note_id"] not in proposal.checkpoint["seen_notes"]:
                    proposal.checkpoint["seen_notes"].append(note["note_id"])
                    discovered.append(dict(operation="comments", cursor="", seen_cursors=[], **note))
        else:
            for row in rows:
                comment = _comment(row, job, parent_id=job.get("parent_id", ""),
                                   parent_text=job.get("parent_text", ""))
                if comment is None:
                    proposal.unresolved.append({"reason": "incomplete_comment_identity_or_text",
                                                "note_url": job["note_url"], "raw": deepcopy(row)})
                else:
                    proposal.comments.append(comment)
                if (self.include_sub_comments and job["operation"] == "comments"
                        and isinstance(row, dict)):
                    parent_id = _string(row.get("id")) or _string(row.get("comment_id"))
                    parent_text = _string(row.get("content")) or _string(row.get("text"))
                    children = row.get("sub_comments", [])
                    if not parent_id or not isinstance(children, list):
                        proposal.unresolved.append({"reason": "incomplete_sub_comment_context", "raw": deepcopy(row)})
                        continue
                    for child in children:
                        normalized = _comment(child, job, parent_id=parent_id, parent_text=parent_text)
                        if normalized is None:
                            proposal.unresolved.append({"reason": "incomplete_comment_identity_or_text",
                                                        "note_url": job["note_url"], "raw": deepcopy(child)})
                        else:
                            proposal.comments.append(normalized)
                    if row.get("sub_comment_has_more") is True:
                        child_cursor = row.get("sub_comment_cursor")
                        if not _string(child_cursor):
                            proposal.unresolved.append({"reason": "missing_sub_comment_cursor", "raw": deepcopy(row)})
                        else:
                            discovered.append({"operation": "sub_comments", "note_id": job["note_id"],
                                               "note_url": job["note_url"], "parent_id": parent_id,
                                               "parent_text": parent_text, "cursor": child_cursor,
                                               "seen_cursors": [""]})
        if has_more:
            job["seen_cursors"].append(job["cursor"])
            job["cursor"] = cursor
            discovered.append(job)
        proposal.checkpoint["jobs"] = discovered + proposal.checkpoint["jobs"]
        proposal.evidence.append(_page_evidence(request, receipt))
        return proposal


def _notification_comment(row):
    explicit = row.get("comment_info", row.get("comment"))
    if not isinstance(explicit, dict):
        return None
    note_data = row.get("note_info", row.get("note", row.get("item_info", {})))
    note = _note(note_data)
    if note is None:
        return None
    comment = _comment(explicit, note)
    if comment is None:
        return None
    actor = row.get("user_info", {})
    actor_id = _string(actor.get("user_id")) if isinstance(actor, dict) else ""
    if not actor_id or actor_id != comment["author_id"]:
        return None
    comment["raw"] = deepcopy(row)
    return comment


class InteractionSource:
    kind = "own_interactions"

    def __init__(self, types=("mentions",), *, baseline="from_now", num=20):
        if (not isinstance(types, (list, tuple)) or not types
                or any(not isinstance(kind, str) or kind not in {"mentions", "likes", "connections"}
                       for kind in types)
                or not isinstance(baseline, str) or baseline not in {"from_now", "visible_history"}
                or type(num) is not int or not 1 <= num <= 50):
            raise ContractError("invalid own interaction configuration")
        self.types = list(dict.fromkeys(types))
        self.baseline, self.num = baseline, num
        self.config_digest = _digest([self.types, baseline, num])

    def _jobs(self, checkpoint):
        return [{"type": kind, "cursor": "", "seen_cursors": [],
                 "baseline": not checkpoint["baseline_complete"][kind]} for kind in self.types]

    def initial_checkpoint(self, scope):
        if scope.platform != "xiaohongshu":
            raise ContractError("XHS source requires xiaohongshu scope")
        checkpoint = {"schema": "xhs-source/1", "kind": self.kind,
                      "scope_fingerprint": scope.fingerprint, "config_digest": self.config_digest,
                      "baseline_complete": {kind: self.baseline == "visible_history" for kind in self.types},
                      "seen_events": {kind: [] for kind in self.types},
                      "baseline_event_ids": {kind: [] for kind in self.types}, "scan": 1}
        checkpoint["jobs"] = self._jobs(checkpoint)
        return checkpoint

    def _validate(self, scope, checkpoint):
        if (scope.platform != "xiaohongshu" or not isinstance(checkpoint, dict)
                or checkpoint.get("schema") != "xhs-source/1" or checkpoint.get("kind") != self.kind
                or checkpoint.get("scope_fingerprint") != scope.fingerprint
                or checkpoint.get("config_digest") != self.config_digest
                or not isinstance(checkpoint.get("jobs"), list)):
            raise ContractError("checkpoint does not match source and scope")

    def start_scan(self, scope, checkpoint):
        """Start a new explicit scan after a completed scan, retaining the baseline."""
        self._validate(scope, checkpoint)
        if checkpoint["jobs"]:
            raise ContractError("cannot start a scan before the previous scan completed")
        result = deepcopy(checkpoint)
        result["scan"] += 1
        result["jobs"] = self._jobs(result)
        return result

    def next_request(self, scope, checkpoint):
        self._validate(scope, checkpoint)
        if not checkpoint["jobs"]:
            return None
        job = checkpoint["jobs"][0]
        return ReadRequest("notifications", {"type": job["type"], "cursor": job["cursor"], "num": self.num})

    def consume(self, scope, checkpoint, request, receipt):
        self._validate(scope, checkpoint)
        expected = self.next_request(scope, checkpoint)
        if expected is None or request.digest(scope) != expected.digest(scope):
            raise ContractError("request does not match checkpoint")
        verify_receipt(scope, request, receipt)
        proposal = PageProposal(checkpoint=deepcopy(checkpoint))
        job = proposal.checkpoint["jobs"].pop(0)
        rows, has_more, cursor = _page(receipt.payload, "message_list", job["cursor"], job["seen_cursors"])
        for row in rows:
            if not isinstance(row, dict):
                proposal.unresolved.append({"reason": "unknown_notification_row", "raw": deepcopy(row)})
                continue
            event_id = _string(row.get("event_id")) or _string(row.get("message_id")) or _string(row.get("id"))
            if not event_id:
                proposal.unresolved.append({"reason": "missing_stable_event_id", "type": job["type"],
                                            "raw": deepcopy(row)})
                continue
            baselines=proposal.checkpoint.setdefault("baseline_event_ids",{kind:[] for kind in self.types})[job["type"]]
            if event_id in baselines:
                continue
            if job["baseline"]:baselines.append(event_id)
            comment = _notification_comment(row) if job["type"] == "mentions" else None
            user = row.get("user_info", {})
            user = user if isinstance(user, dict) else {}
            author_id = _string(user.get("user_id"))
            event_key = _digest([event_id, author_id, comment["comment_id"] if comment else "",
                                 comment["text"] if comment else ""])
            if event_key in proposal.checkpoint["seen_events"][job["type"]]:
                continue
            proposal.checkpoint["seen_events"][job["type"]].append(event_key)
            event = {"event_id": event_id, "type": job["type"], "author_id": author_id,
                     "author": _string(user.get("nickname")), "raw": deepcopy(row),
                     "text": comment["text"] if comment else "",
                     "text_source": "explicit_comment" if comment else "",
                     "disposition": "baseline" if job["baseline"] else "record_only"}
            if not job["baseline"] and job["type"] == "mentions":
                if comment is None:
                    event["disposition"] = "pending_evidence"
                    proposal.unresolved.append({"reason": "incomplete_notification_comment_evidence",
                                                "event_id": event_id, "raw": deepcopy(row)})
                else:
                    event["disposition"] = "pending_analysis"
                    comment["interaction_event_id"] = event_id
                    proposal.comments.append(comment)
            proposal.events.append(event)
        if has_more:
            job["seen_cursors"].append(job["cursor"])
            job["cursor"] = cursor
            proposal.checkpoint["jobs"].insert(0, job)
        else:
            proposal.checkpoint["baseline_complete"][job["type"]] = True
        proposal.evidence.append(_page_evidence(request, receipt))
        return proposal
