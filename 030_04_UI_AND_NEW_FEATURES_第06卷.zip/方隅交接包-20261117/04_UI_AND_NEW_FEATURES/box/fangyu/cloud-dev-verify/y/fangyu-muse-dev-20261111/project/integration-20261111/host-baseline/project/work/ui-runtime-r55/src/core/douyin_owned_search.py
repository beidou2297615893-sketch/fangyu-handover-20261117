"""One exact typed search purpose; reuse original physical cleanup and lock mechanics."""
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import threading
from .adapters import account_execution_lock, AdapterBusy
from .douyin_comments_policy import _digest
from .douyin_owned_comments import _DouyinCommentsCall, _DouyinCommentCleanupPending, _DouyinCommentOrigin
from .douyin_search_policy import DouyinSearchPolicy
from .runtime_license_policy import _plain

@dataclass(frozen=True)
class _DouyinSearchOrigin(_DouyinCommentOrigin):
    """Physical/actor facts only; no active call or permission to execute."""

def receipt_origin_current(reads,entry,account,policy):
    from assistant.douyin_connection_service import _binding
    origin=entry.get('_douyin_search_origin')
    if type(origin) is not _DouyinSearchOrigin or type(policy) is not DouyinSearchPolicy:return False
    try:
        server=policy._server;binding=_binding(server.assistant_service,account['id'])
        if (reads.core is not server.core or origin.manager is not server.account_connections
                or origin.manager.owned.get(account['id']) is not origin.owned
                or tuple(origin.owned.get(k) for k in ('marker','state_path'))!=origin.window_facts
                or origin.owned['process'].poll() is not None
                or server.bridge.processes.get(reads.tenant) is not origin.bridge_process
                or origin.bridge_process.poll() is not None or server.bridge.external(reads.tenant)
                or binding[1] is not origin.executor or binding[2] is not origin.session
                or binding[3]!=origin.device or origin.device!=reads.device_id
                or origin.account_id!=account['id'] or _digest(binding[4])!=origin.account_digest):return False
        policy.current_review()
        for path,root,sha in origin.files:
            if _plain(path,root)!=path or hashlib.sha256(path.read_bytes()).hexdigest()!=sha:return False
        return True
    except (ValueError,RuntimeError,OSError,KeyError,TypeError):return False

class _DouyinSearchCall(_DouyinCommentsCall):
    """Inherited identity/spec/launch are mechanical; constructor/check are search-only."""
    def __init__(self,reads,entry,user,account,task,policy,revision):
        from assistant.douyin_connection_service import _binding,_ACTOR
        if type(policy) is not DouyinSearchPolicy:raise ValueError('douyin_search_component_pending')
        server=policy._server
        current,executor,session,device,selected,stored=_binding(server.assistant_service,account['id'])
        keywords=task.get('keywords')
        if (reads.core is not server.core or reads.tenant!=executor.tenant or reads.owner!=executor.owner
                or reads.device_id!=device or current['id']!=user['id'] or selected!=account
                or account.get('status')!='ready' or type(account.get('platform_uid')) is not str
                or re.fullmatch(r'[0-9]{1,160}',account['platform_uid']) is None
                or not account['platform_uid'].strip('0') or not account.get('conn_id')
                or task.get('next_cursor') not in ('',None) or task.get('next_page')!=1
                or type(task.get('daily_limit')) is not int or not 1<=task['daily_limit']<=20
                or type(keywords) is not list or len(keywords)!=1 or type(keywords[0]) is not str
                or not 1<=len(keywords[0])<=200 or task.get('note_url') not in ('',None)):
            raise ValueError('douyin_owned_search_scope_unconfirmed')
        self.reads,self.entry,self.policy,self.server=reads,entry,policy,server
        self.task,self.thread,self.active=task,threading.current_thread(),True
        self.user_id,self.executor,self.session,self.device=user['id'],executor,session,device
        self.account_id,self.account=account['id'],_digest(account)
        self.actor=_digest({k:stored.get(k) for k in _ACTOR})
        self.uid,self.conn,self.revision=account['platform_uid'],account['conn_id'],revision
        self.input_digest=_digest([keywords[0],0,task['daily_limit']])
        self.material_snapshot=policy._snapshot()
        self.manager=server.account_connections;self.owned=self.manager.owned.get(self.account_id)
        self.bridge_process=server.bridge.processes.get(reads.tenant)
        self.window_facts=({k:self.owned.get(k) for k in ('marker','state_path')} if self.owned is not None else None)
        self.bridge_config=server.bridge.root(reads.tenant)/'config.json'
        self.bridge_config_hash=hashlib.sha256(self.bridge_config.read_bytes()).hexdigest()
        self.directory=server.core.store.directory/'accounts'/reads.tenant/self.account_id
        window_root=self.directory/'managed-window'
        self.window_spec=_plain(window_root/'window.json',self.directory)
        self.script=_plain(server.bridge.root(reads.tenant)/'工作台_抖音连接.user.js',server.core.store.directory)
        self.window_spec_hash=hashlib.sha256(self.window_spec.read_bytes()).hexdigest()
        self.script_hash=hashlib.sha256(self.script.read_bytes()).hexdigest()
        spec=json.loads(self.window_spec.read_text('utf8'))
        if (spec.get('platform')!='douyin' or self.owned is None or spec.get('marker')!=self.owned.get('marker')
                or Path(spec.get('profile',''))!=window_root/'profile' or spec.get('state_path')!=self.owned.get('state_path')
                or Path(spec.get('config',''))!=self.bridge_config or Path(spec.get('script',''))!=self.script):
            raise ValueError('douyin_owned_search_profile_unconfirmed')
        self.args=[str(server.bridge.runtime/'cli.js'),'search',keywords[0],'--offset','0',
            '--count',str(task['daily_limit']),'--conn-id',self.conn,'--no-store','--no-log']

    def check(self,adapters=None,platform=None,args=None,directory=None,job_id=None):
        from assistant.douyin_connection_service import _binding,_ACTOR
        if (not self.active or self.thread is not threading.current_thread() or type(self.policy) is not DouyinSearchPolicy
                or self.server.account_connections is not self.manager or self.server.core is not self.reads.core
                or self.owned is None or self.manager.owned.get(self.account_id) is not self.owned
                or self.owned['process'].poll() is not None
                or {k:self.owned.get(k) for k in ('marker','state_path')}!=self.window_facts
                or self.bridge_process is None or self.server.bridge.processes.get(self.reads.tenant) is not self.bridge_process
                or self.bridge_process.poll() is not None or self.server.bridge.external(self.reads.tenant)
                or hashlib.sha256(self.bridge_config.read_bytes()).hexdigest()!=self.bridge_config_hash
                or _plain(self.window_spec,self.directory)!=self.window_spec
                or _plain(self.script,self.server.core.store.directory)!=self.script
                or hashlib.sha256(self.window_spec.read_bytes()).hexdigest()!=self.window_spec_hash
                or hashlib.sha256(self.script.read_bytes()).hexdigest()!=self.script_hash
                or _digest([self.task.get('keywords',[None])[0],0,self.task.get('daily_limit')])!=self.input_digest
                or self.task.get('next_page')!=1 or self.task.get('next_cursor') not in ('',None)):
            raise ValueError('douyin_owned_search_scope_changed')
        if adapters is not None and (adapters is not self.server.core.adapters or platform!='douyin'
                or args!=self.args or Path(directory)!=self.directory or job_id!=self.entry['operation_id']):
            raise ValueError('douyin_owned_search_call_changed')
        current,executor,session,device,account,stored=_binding(self.server.assistant_service,self.account_id)
        with self.reads._lock:
            if (self.entry.get('cancelled') or not self.entry.get('running')
                    or not any(item is self.entry for item in self.reads._operations.values())
                    or executor is not self.executor or session is not self.session or device!=self.device
                    or current['id']!=self.user_id or _digest(account)!=self.account
                    or _digest({k:stored.get(k) for k in _ACTOR})!=self.actor):
                raise ValueError('douyin_owned_search_scope_changed')
        self.policy.current_review()
        if self.policy._snapshot()!=self.material_snapshot:raise ValueError('douyin_owned_search_transport_changed')
        return account

@contextmanager
def owned_search(reads,entry,user,account,task,policy):
    if type(policy) is not DouyinSearchPolicy or policy._server.core is not reads.core:
        raise ValueError('douyin_search_component_pending')
    revision=policy.resolve()
    if revision is None:raise ValueError('douyin_search_component_pending')
    call=_DouyinSearchCall(reads,entry,user,account,task,policy,revision['revision'])
    lock=call.manager.locks.setdefault(account['id'],threading.Lock())
    if not lock.acquire(blocking=False):raise AdapterBusy('本人窗口正在核对，本次未搜索')
    try:
        with account_execution_lock(call.directory):
            call.identity();task['_douyin_search_call']=call
            try:yield
            except _DouyinCommentCleanupPending as pending:
                while not pending.finish():threading.Event().wait(0.1)
                raise RuntimeError('抖音本次原子进程已安全收尾，搜索结果未确认') from None
            else:
                call.identity()
                entry['_douyin_search_origin']=_DouyinSearchOrigin(call.manager,call.owned,call.bridge_process,
                    call.executor,call.session,call.device,call.account_id,call.account,call.directory,
                    tuple(call.window_facts[k] for k in ('marker','state_path')),
                    ((call.window_spec,call.directory,call.window_spec_hash),
                        (call.script,call.server.core.store.directory,call.script_hash),
                        (call.bridge_config,call.server.core.store.directory,call.bridge_config_hash)))
            finally:task.pop('_douyin_search_call',None)
    finally:
        call.active=False;lock.release()
