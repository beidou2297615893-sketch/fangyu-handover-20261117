"""Same-instance capability upgrade: durable files, no DB or platform grant.

Commit is private to a trusted normal-main close finalizer retaining its original
instance mutex. No offline lock acquisition, rollback or automatic retry exists.
The close-capability import is intentionally deferred to the commit seam.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time

from .self_operating_read import _OwnerReadInstance, _company, _plain_directory
from .owner_instance_platform_upgrade import prepare_owner_platform_upgrade as _first_prepare

WRITER_INTERFACE = 'owner_instance_platform_upgrade_writer_v1'
# Actual bytes loaded now; the trusted outer host independently fixes the review
# pin. A later disk edit cannot be accepted as evidence of our loaded revision.
LOADED_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest().upper()

_SEAL = object()
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_IID = re.compile(r'[0-9a-f]{32}\Z')
_PHASES = ('reserved', 'backup_ready', 'replace_started', 'committed')
_FIELDS = frozenset(('schema', 'idempotency_key', 'plan_digest', 'instance_id',
    'company_id', 'old_product', 'new_product', 'wrapper_sha256', 'source_revision',
    'old_marker_sha256', 'target_marker_sha256', 'data_marker_sha256',
    'backup_sha256', 'backup_bytes', 'phase', 'created_at', 'updated_at'))
_DB_FILES = ('workspace.sqlite3', 'workspace.sqlite3-wal',
             'workspace.sqlite3-shm', 'workspace.sqlite3-journal')


class OwnerPlatformUpgradeError(ValueError):
    def __init__(self, code='MATERIAL_REVIEW_REQUIRED'):
        super().__init__('本工作区升级资料待核对；保留原编号，不自动提交或回退')
        self.code = code
        self.mutation_committed = None
        self.auto_retry = False


def _fail(code='MATERIAL_REVIEW_REQUIRED'):
    raise OwnerPlatformUpgradeError(code)


def _digest(raw):
    return hashlib.sha256(raw).hexdigest()


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')


def _pairs(rows):
    result = {}
    for name, value in rows:
        if name in result:
            _fail('DUPLICATE_FIELDS')
        result[name] = value
    return result


def _json(raw):
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=_pairs)
    except (UnicodeError, ValueError):
        _fail()


def _plain(path, *, optional=False, max_bytes=8192):
    try:
        info = path.lstat()
    except FileNotFoundError:
        if optional:
            return None
        _fail('MISSING_MATERIAL')
    if (not stat.S_ISREG(info.st_mode) or path.is_symlink() or info.st_nlink != 1
            or getattr(info, 'st_file_attributes', 0)
                & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)
            or max_bytes is not None and info.st_size > max_bytes):
        _fail()
    return info


def _read(path, *, optional=False):
    before = _plain(path, optional=optional)
    if before is None:
        return None
    raw = path.read_bytes()
    after = _plain(path)
    if (len(raw) > 8192 or before.st_size != len(raw)
            or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)):
        _fail()
    return raw


def _data(instance, iid):
    directory = instance.directory / 'data'
    _plain_directory(directory, instance.work_root)
    expected = json.dumps({'schema': 'owner_read_data_v1', 'instance_id': iid}, sort_keys=True).encode()
    if _read(directory / 'owner-data-instance.json') != expected:
        _fail('DATA_BINDING_CHANGED')
    for name in _DB_FILES:
        _plain(directory / name, optional=True, max_bytes=None)  # lstat only.
    return expected


def _current(instance):
    if type(instance) is not _OwnerReadInstance or instance.product not in ('xiaohongshu_v1', 'primary_platforms_v2'):
        _fail('ORIGINAL_FACTORY_REQUIRED')
    company = instance.check()
    iid = company['selfOperatingRead']['instance_id']
    if (not _IID.fullmatch(iid) or not _HEX.fullmatch(instance._wrapper_sha)
            or company != _company(iid, instance._wrapper_sha, instance.product)):
        _fail()
    _plain_directory(instance.directory, instance.work_root)
    raw = _read(instance.directory / 'self-operating-instance.json')
    if raw != instance._bytes:
        _fail('CURRENT_INSTANCE_CHANGED')
    return company, raw, _data(instance, iid)


def _marker(raw, iid, wrapper, product):
    value = _json(raw)
    expected = {'schema': 'owner_read_instance_v1' if product == 'xiaohongshu_v1' else 'owner_read_instance_v2',
        'instance_id': iid, 'company': _company(iid, wrapper, product)}
    if value != expected:
        _fail('MARKER_BINDING_CHANGED')
    return expected


@dataclass(frozen=True)
class _ClosedUpgradeOrigin:
    _seal: object
    instance: object
    idempotency_key: str
    instance_id: str
    company_id: str
    source_revision: str
    journal_checkpoint_sha256: str
    phase: str


class _UpgradePlan:
    __slots__ = ('_seal', '_instance', '_old', '_target', '_data', '_summary', '_key', '_origin')

    def __init__(self, seal, instance, old, target, data, summary, key):
        if seal is not _SEAL:
            _fail()
        self._seal, self._instance = seal, instance
        self._old, self._target, self._data = old, target, data
        self._summary, self._key = summary, key
        self._origin = None

    def summary(self):
        if self._seal is not _SEAL:
            _fail()
        # Preserve the existing safe 14-key shape; key is separately supplied by
        # the original host's deterministic plan-key calculation, not a new grant.
        return deepcopy(self._summary)

    @property
    def idempotency_key(self):
        if self._seal is not _SEAL:
            _fail()
        return self._key

    def require_closed_origin(self, instance, reviewed_writer_sha256):
        """Verify a prior reviewed-writer checkpoint, not current physical idle.

        Its only legitimate producer is the reviewed commit code below, after
        entering the exact normal-close capability. The close Module must still
        independently prove account/Native/worker closure in the current host.
        """
        _check_plan(self)
        if instance is not self._instance or self._origin is None:
            _fail('TRUSTED_CLOSED_ORIGIN_REQUIRED')
        if type(reviewed_writer_sha256) is not str:
            _fail('WRITER_SOURCE_REVIEW_REQUIRED')
        revision = reviewed_writer_sha256.lower()
        if revision != _reviewed_revision():
            _fail('WRITER_SOURCE_REVIEW_REQUIRED')
        existing = _existing(instance, self._key)
        if (existing is None or existing[1] != self._origin[0]
                or existing[4] is not self._origin[1]
                or existing[2]['source_revision'] != revision):
            _fail('TRUSTED_CLOSED_ORIGIN_CHANGED')
        return _ClosedUpgradeOrigin(_SEAL, instance, self._key,
            self._summary['instance_id'], self._summary['company_id'], revision,
            _digest(existing[1]), existing[2]['phase'])


def _make_plan(instance, old, data):
    value = _json(old)
    iid = value.get('instance_id') if type(value) is dict else None
    if type(iid) is not str or not _IID.fullmatch(iid):
        _fail()
    wrapper = instance._wrapper_sha
    _marker(old, iid, wrapper, 'xiaohongshu_v1')
    expected_data = json.dumps({'schema': 'owner_read_data_v1', 'instance_id': iid}, sort_keys=True).encode()
    if data != expected_data:
        _fail()
    target_value = {'schema': 'owner_read_instance_v2', 'instance_id': iid,
        'company': _company(iid, wrapper, 'primary_platforms_v2')}
    target = json.dumps(target_value, ensure_ascii=False, sort_keys=True).encode()
    company_id = value['company']['id']
    payload = {'schema': 'owner_platform_upgrade_plan_v1', 'instance_id': iid,
        'company_id': company_id, 'wrapper_sha256': wrapper,
        'instance_directory_digest': _digest(str(instance.directory).encode('utf-8')),
        'work_root_digest': _digest(str(instance.work_root).encode('utf-8')),
        'source_marker_sha256': _digest(old), 'target_marker_sha256': _digest(target),
        'data_marker_sha256': _digest(data), 'from_product': 'xiaohongshu_v1',
        'to_product': 'primary_platforms_v2'}
    summary = {'schema': 'owner_platform_upgrade_prepare_v1', 'state': 'prepared_read_only',
        'instance_id': iid, 'company_id': company_id, 'from_product': 'xiaohongshu_v1',
        'to_product': 'primary_platforms_v2', 'source_marker_sha256': _digest(old),
        'target_marker_sha256': _digest(target), 'plan_digest': _digest(_encoded(payload)),
        'added_platforms': {'douyin': 'pending', 'wechat_channels': 'pending'},
        'instance_idle_verified': False, 'database_opened': False,
        'mutation_committed': False, 'platform_permissions_granted': False}
    key = _digest(_encoded({'domain': 'owner_instance_upgrade_key_v1', 'instance_id': iid,
        'company_id': company_id, 'plan_digest': summary['plan_digest'],
        'source_marker_sha256': summary['source_marker_sha256'],
        'target_marker_sha256': summary['target_marker_sha256']}))
    return _UpgradePlan(_SEAL, instance, old, target, data, summary, key)


def _directory_exists(directory, root):
    try:
        directory.lstat()
    except FileNotFoundError:
        return False
    _plain_directory(directory, root)
    return True


def _paths(instance, key):
    directory = instance.directory / 'platform-upgrade'
    _directory_exists(directory, instance.work_root)
    return directory, directory / 'journal.json', directory / 'original-marker.json', \
        instance.directory / ('self-operating-instance.' + key + '.upgrade.tmp')


def _journal(raw):
    value = _json(raw)
    if type(value) is not dict or set(value) != _FIELDS:
        _fail()
    if (value['schema'] != 'owner_instance_platform_upgrade_journal_v1'
            or value['old_product'] != 'xiaohongshu_v1' or value['new_product'] != 'primary_platforms_v2'
            or value['phase'] not in _PHASES or type(value['instance_id']) is not str
            or not _IID.fullmatch(value['instance_id']) or type(value['company_id']) is not str
            or value['company_id'] != 'self-read-' + value['instance_id'][:24]
            or type(value['backup_bytes']) is not int or not 1 <= value['backup_bytes'] <= 8192):
        _fail()
    for name in ('idempotency_key', 'plan_digest', 'wrapper_sha256', 'source_revision',
                 'old_marker_sha256', 'target_marker_sha256', 'data_marker_sha256', 'backup_sha256'):
        if type(value[name]) is not str or not _HEX.fullmatch(value[name]):
            _fail()
    if value['backup_sha256'] != value['old_marker_sha256']:
        _fail()
    for name in ('created_at', 'updated_at'):
        if type(value[name]) not in (int, float) or not math.isfinite(value[name]) or value[name] < 0:
            _fail()
    if value['updated_at'] < value['created_at']:
        _fail()
    return value


def _bound(journal, plan):
    expected = {'idempotency_key': plan._key, 'plan_digest': plan._summary['plan_digest'],
        'instance_id': plan._summary['instance_id'], 'company_id': plan._summary['company_id'],
        'wrapper_sha256': plan._instance._wrapper_sha, 'old_marker_sha256': _digest(plan._old),
        'target_marker_sha256': _digest(plan._target), 'data_marker_sha256': _digest(plan._data),
        'backup_sha256': _digest(plan._old), 'backup_bytes': len(plan._old)}
    if any(journal[name] != value for name, value in expected.items()):
        _fail('JOURNAL_BINDING_CHANGED')


def _stored_intent(instance, key, directory, path, target_temp):
    raw = _read(path, optional=True)
    if raw is not None:
        return raw, False
    staged = directory / ('journal.' + key + '.reserved.tmp')
    raw = _read(staged, optional=True)
    if raw is None:
        return None, False
    value = _journal(raw)
    if value['phase'] != 'reserved' or value['idempotency_key'] != key:
        _fail('PARTIAL_OR_CONFLICTING_INTENT')
    # The initial intent is the first material write. A complete same-key stage
    # may be explicitly promoted, but extra/partial material cannot be guessed.
    if any(child != staged for child in directory.iterdir()) or target_temp.exists():
        _fail('PARTIAL_OR_CONFLICTING_INTENT')
    return raw, True


def _existing(instance, key):
    company, current, data = _current(instance)
    directory, path, backup_path, temp = _paths(instance, key)
    if _directory_exists(directory, instance.work_root):
        raw, staged_intent = _stored_intent(instance, key, directory, path, temp)
    else:
        raw, staged_intent = None, False
    if raw is None:
        return None
    journal = _journal(raw)
    if (journal['idempotency_key'] != key or journal['instance_id'] != company['selfOperatingRead']['instance_id']
            or journal['company_id'] != company['id'] or journal['wrapper_sha256'] != instance._wrapper_sha):
        _fail()
    backup = _read(backup_path, optional=True)
    if backup is None:
        if journal['phase'] != 'reserved' or _digest(current) != journal['old_marker_sha256']:
            _fail('MISSING_BACKUP')
        old = current
    else:
        old = backup
    plan = _make_plan(instance, old, data)
    _bound(journal, plan)
    if backup is not None and backup != plan._old:
        _fail()
    staged = _read(temp, optional=True)
    if staged is not None and staged != plan._target:
        _fail('PARTIAL_TARGET')
    if current == plan._old:
        if journal['phase'] == 'committed':
            _fail('COMMITTED_MARKER_CHANGED')
        state = 'unknown' if staged_intent or journal['phase'] == 'replace_started' else 'pending'
        if journal['phase'] == 'replace_started' and staged is None:
            _fail('MISSING_STAGED_TARGET')
    elif current == plan._target:
        if journal['phase'] not in ('replace_started', 'committed') or backup is None:
            _fail()
        state = 'succeeded' if journal['phase'] == 'committed' else 'target_applied_pending_confirmation'
    else:
        _fail('CURRENT_MARKER_CHANGED')
    instance.check()  # current metadata caller, not stale v1 after replacement.
    plan._origin = (raw, staged_intent)
    return plan, raw, journal, state, staged_intent


def prepare_owner_platform_upgrade(instance, key=None):
    """Zero-write fresh v1 preparation, or strict same-key metadata recovery."""
    if key is not None:
        if type(key) is not str or not _HEX.fullmatch(key):
            _fail('ORIGINAL_KEY_REQUIRED')
        existing = _existing(instance, key)
        if existing is None:
            _fail('UNKNOWN_ORIGINAL_KEY')
        return existing[0]
    first = _first_prepare(instance)
    plan = _make_plan(instance, first._source_bytes, first._data_bytes)
    if plan._summary != first.summary() or plan._target != first._target_bytes:
        _fail('ORIGINAL_PREPARE_CHANGED')
    directory, path, _, temp = _paths(instance, plan._key)
    if _directory_exists(directory, instance.work_root):
        existing = _existing(instance, plan._key)
        if existing is None:
            # A crash can leave only mkdir. This remains unknown in GET and can
            # only proceed as an explicit native-close first write, never via
            # the no-intent metadata-recovery mode. No not_committed is inferred.
            if any(directory.iterdir()) or temp.exists():
                _fail('UNKNOWN_PARTIAL_UPGRADE')
            return plan
        return existing[0]
    if temp.exists():
        _fail('UNKNOWN_PARTIAL_UPGRADE')
    return plan


def _result(plan, key, state, phase=None):
    value = plan._summary if plan is not None else {}
    return {'schema': 'owner_instance_platform_upgrade_result_v1', 'state': state,
        'idempotency_key': key, 'instance_id': value.get('instance_id'),
        'company_id': value.get('company_id'), 'phase': phase,
        'old_marker_sha256': value.get('source_marker_sha256'),
        'target_marker_sha256': value.get('target_marker_sha256'),
        'mutation_committed': True if state == 'succeeded' else None,
        'added_platforms': {'douyin': 'pending', 'wechat_channels': 'pending'},
        'auto_retry': False, 'platform_permissions_granted': False,
        'process_exited_verified': False}


def _reviewed_revision():
    # Pure reviewed-code check supplied by the trusted host/close Module. This
    # neither creates a close capability nor infers that resources are idle.
    from .owner_normal_close import require_reviewed_writer
    reviewed = require_reviewed_writer(sys.modules[__name__])
    if type(reviewed) is not str:
        _fail('WRITER_SOURCE_REVIEW_REQUIRED')
    revision = reviewed.lower()
    if (not _HEX.fullmatch(revision) or revision != LOADED_SOURCE_SHA256.lower()
            or revision != _digest(Path(__file__).read_bytes())):
        _fail('WRITER_SOURCE_REVIEW_REQUIRED')
    return revision


def get_owner_platform_upgrade(instance, key):
    if type(key) is not str or not _HEX.fullmatch(key):
        _fail('ORIGINAL_KEY_REQUIRED')
    try:
        existing = _existing(instance, key)
        if existing is not None and existing[3] == 'succeeded':
            try:
                if existing[2]['source_revision'] != _reviewed_revision():
                    _fail('WRITER_SOURCE_REVIEW_REQUIRED')
            except (ImportError, ValueError, RuntimeError, OSError, KeyError, TypeError, AttributeError):
                return _result(existing[0], key, 'held', existing[2]['phase'])
        return _result(None, key, 'unknown') if existing is None else _result(existing[0], key, existing[3], existing[2]['phase'])
    except (ImportError, ValueError, RuntimeError, OSError, KeyError, TypeError, AttributeError):
        return _result(None, key, 'held')


def _write_exclusive(path, raw):
    if path.exists():
        if _read(path) != raw:
            _fail('PARTIAL_OR_CONFLICTING_FILE')
        return
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    if _read(path) != raw:
        _fail('PERSISTENCE_UNKNOWN')


def _cas(path, expected, target, temp):
    _write_exclusive(temp, target)
    current = _read(path, optional=expected is None)
    if current != expected:
        _fail('CAS_CHANGED')
    os.replace(temp, path)
    # No claim of Windows directory fsync/power-loss guarantees. The persistent
    # intent and exact read-back govern recovery if replace completion is unclear.
    with path.open('r+b') as stream:
        stream.flush()
        os.fsync(stream.fileno())
    if _read(path) != target:
        _fail('PERSISTENCE_UNKNOWN')


def _advance(path, raw, journal, phase):
    if _PHASES.index(phase) != _PHASES.index(journal['phase']) + 1:
        _fail()
    temp = path.parent / ('journal.' + journal['idempotency_key'] + '.' + phase + '.tmp')
    staged = _read(temp, optional=True)
    if staged is not None:
        next_value = _journal(staged)
        immutable = _FIELDS - {'phase', 'updated_at'}
        if (any(next_value[name] != journal[name] for name in immutable)
                or next_value['phase'] != phase or next_value['updated_at'] < journal['updated_at']):
            _fail('PARTIAL_OR_CONFLICTING_FILE')
        next_raw = staged
    else:
        next_value = dict(journal, phase=phase, updated_at=max(time.time(), journal['updated_at']))
        next_raw = _encoded(next_value)
    _cas(path, raw, next_raw, temp)
    return next_raw, next_value


def _verified_target(plan):
    current = _read(plan._instance.directory / 'self-operating-instance.json')
    if current != plan._target:
        _fail('TARGET_REVIEW_REQUIRED')
    target_instance = _OwnerReadInstance(plan._instance.directory, plan._instance.work_root,
        plan._instance._wrapper_sha, product='primary_platforms_v2')
    checked = target_instance.check()
    if (checked['id'] != plan._summary['company_id']
            or checked['selfOperatingRead']['instance_id'] != plan._summary['instance_id']
            or _data(target_instance, plan._summary['instance_id']) != plan._data):
        _fail()
    return target_instance


def _check_plan(plan):
    if type(plan) is not _UpgradePlan or plan._seal is not _SEAL:
        _fail('ORIGINAL_PLAN_AND_KEY_REQUIRED')
    if (type(plan._instance) is not _OwnerReadInstance
            or type(plan._instance._wrapper_sha) is not str or not _HEX.fullmatch(plan._instance._wrapper_sha)
            or type(plan._old) is not bytes or type(plan._target) is not bytes
            or type(plan._data) is not bytes or not 1 <= len(plan._old) <= 8192
            or not 1 <= len(plan._target) <= 8192):
        _fail('ORIGINAL_PLAN_CHANGED')
    rebuilt = _make_plan(plan._instance, plan._old, plan._data)
    if (rebuilt._target != plan._target or rebuilt._summary != plan._summary
            or rebuilt._key != plan._key):
        _fail('ORIGINAL_PLAN_CHANGED')


def commit_owner_platform_upgrade(plan, key, closed_handoff):
    """Private same-main finalizer: no acquired offline lock, rollback or retry."""
    _check_plan(plan)
    if type(key) is not str or key != plan._key:
        _fail('ORIGINAL_PLAN_AND_KEY_REQUIRED')
    try:
        # Exact authority implementation is the independently authored close
        # Module. It supplies the outer host's reviewed loaded-source pin.
        from .owner_normal_close import _OwnerNormalCloseCapability
        if type(closed_handoff) is not _OwnerNormalCloseCapability:
            _fail('NORMAL_CLOSE_PENDING')
        authority = closed_handoff.require_writer(sys.modules[__name__])
        if authority.close_mode not in ('native', 'metadata_recovery'):
            _fail('NORMAL_CLOSE_PENDING')
        if authority.close_mode == 'metadata_recovery' and authority.recovery_key != key:
            _fail('ORIGINAL_RECOVERY_KEY_REQUIRED')
        revision = authority.upgrade_source_sha256.lower()
        if not _HEX.fullmatch(revision) or revision != _digest(Path(__file__).read_bytes()):
            _fail('WRITER_SOURCE_CHANGED')
        if authority.close_mode == 'metadata_recovery':
            plan.require_closed_origin(plan._instance, revision)
        with closed_handoff.hold_for_commit(plan._instance):
            directory, journal_path, backup, target_temp = _paths(plan._instance, key)
            marker = plan._instance.directory / 'self-operating-instance.json'
            if _data(plan._instance, plan._summary['instance_id']) != plan._data:
                _fail()
            existed = _directory_exists(directory, plan._instance.work_root)
            if existed:
                raw, staged_intent = _stored_intent(plan._instance, key, directory, journal_path, target_temp)
            else:
                raw, staged_intent = None, False
            if raw is None:
                if authority.close_mode == 'metadata_recovery':
                    _fail('UNKNOWN_ORIGINAL_KEY')
                if (existed and any(directory.iterdir())) or target_temp.exists():
                    _fail('UNKNOWN_PARTIAL_UPGRADE')
                if _read(marker) != plan._old:
                    _fail('CURRENT_MARKER_CHANGED')
                if not existed:
                    directory.mkdir()
                _plain_directory(directory, plan._instance.work_root)
                now = time.time()
                journal = {'schema': 'owner_instance_platform_upgrade_journal_v1',
                    'idempotency_key': key, 'plan_digest': plan._summary['plan_digest'],
                    'instance_id': plan._summary['instance_id'], 'company_id': plan._summary['company_id'],
                    'old_product': 'xiaohongshu_v1', 'new_product': 'primary_platforms_v2',
                    'wrapper_sha256': plan._instance._wrapper_sha, 'source_revision': revision,
                    'old_marker_sha256': _digest(plan._old), 'target_marker_sha256': _digest(plan._target),
                    'data_marker_sha256': _digest(plan._data), 'backup_sha256': _digest(plan._old),
                    'backup_bytes': len(plan._old), 'phase': 'reserved', 'created_at': now, 'updated_at': now}
                raw = _encoded(journal)
                _cas(journal_path, None, raw, directory / ('journal.' + key + '.reserved.tmp'))
            else:
                journal = _journal(raw)
                _bound(journal, plan)
                if journal['source_revision'] != revision:
                    _fail('WRITER_SOURCE_REVIEW_REQUIRED')
                if staged_intent:
                    if journal['phase'] != 'reserved' or _read(marker) != plan._old:
                        _fail('PARTIAL_OR_CONFLICTING_INTENT')
                    if _read(backup, optional=True) is not None or target_temp.exists():
                        _fail('PARTIAL_OR_CONFLICTING_INTENT')
                    _cas(journal_path, None, raw, directory / ('journal.' + key + '.reserved.tmp'))
            if journal['phase'] == 'committed':
                if _read(backup) != plan._old:
                    _fail()
                _verified_target(plan)
                return _result(plan, key, 'succeeded', 'committed')
            current = _read(marker)
            if current == plan._target:
                if journal['phase'] != 'replace_started' or _read(backup) != plan._old:
                    _fail()
                _verified_target(plan)
                closed_handoff.require_writer(sys.modules[__name__])
                raw, journal = _advance(journal_path, raw, journal, 'committed')
                return _result(plan, key, 'succeeded', 'committed')
            if current != plan._old:
                _fail()
            if journal['phase'] == 'reserved':
                _write_exclusive(backup, plan._old)
                raw, journal = _advance(journal_path, raw, journal, 'backup_ready')
            elif _read(backup) != plan._old:
                _fail('MISSING_OR_PARTIAL_BACKUP')
            if journal['phase'] == 'replace_started' and _read(target_temp, optional=True) != plan._target:
                _fail('MISSING_OR_PARTIAL_STAGED_TARGET')
            _write_exclusive(target_temp, plan._target)
            if journal['phase'] == 'backup_ready':
                raw, journal = _advance(journal_path, raw, journal, 'replace_started')
            if journal['phase'] != 'replace_started':
                _fail()
            closed_handoff.require_writer(sys.modules[__name__])
            if _data(plan._instance, plan._summary['instance_id']) != plan._data:
                _fail()
            _cas(marker, plan._old, plan._target, target_temp)
            _verified_target(plan)
            closed_handoff.require_writer(sys.modules[__name__])
            raw, journal = _advance(journal_path, raw, journal, 'committed')
            return _result(plan, key, 'succeeded', 'committed')
    except (ImportError, ValueError, RuntimeError, OSError, KeyError, TypeError, AttributeError):
        # Retain every key/phase/partial file. Never overwrite durable progress
        # with a generic held phase or guess not_committed after file exceptions.
        return _result(plan, key, 'held')
