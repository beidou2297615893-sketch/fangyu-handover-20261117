"""Bound, readonly data contracts. A Scope is identity data, never permission."""
from dataclasses import asdict, dataclass, field
import hashlib
import json
import math
from types import MappingProxyType
from typing import Any, Mapping


class ContractError(ValueError):
    pass


def canonical_json(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ContractError('Value must be finite JSON') from exc


def json_copy(value):
    return json.loads(canonical_json(value))


def json_digest(value):
    return hashlib.sha256(canonical_json(value).encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class Scope:
    tenant_id: str
    owner: str
    store_id: str
    account_id: str
    platform_uid: str
    identity_revision: Any
    task_id: str
    source_digest: str
    platform: str = 'xiaohongshu'

    def __post_init__(self):
        for name in ('tenant_id', 'owner', 'store_id', 'account_id',
                     'platform_uid', 'task_id', 'source_digest', 'platform'):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip() or '\x00' in value:
                raise ContractError(f'Missing or invalid scope field: {name}')
        if self.platform not in ('xiaohongshu', 'douyin'):
            raise ContractError('Unsupported platform')
        revision = self.identity_revision
        if isinstance(revision, bool) or not isinstance(revision, (str, int)) or str(revision) == '':
            raise ContractError('identity_revision must be a nonempty string or integer')

    def binding(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return json_digest(self.binding())


READ_OPERATIONS = frozenset(('user_me', 'user_profile', 'user_posts', 'comments', 'sub_comments',
                             'notifications', 'unread', 'dm_list', 'dm_listen'))


class _FrozenParams(Mapping):
    """Scalar-only immutable mapping that remains safe to deepcopy for evidence."""
    __slots__=('__values',)

    def __init__(self, values):
        self.__values=MappingProxyType(json_copy(dict(values)))

    def __getitem__(self,key):return self.__values[key]
    def __iter__(self):return iter(self.__values)
    def __len__(self):return len(self.__values)
    def __deepcopy__(self,memo):return self


@dataclass(frozen=True)
class ReadRequest:
    operation: str
    params: Mapping

    def __post_init__(self):
        if self.operation not in READ_OPERATIONS or not isinstance(self.params, Mapping):
            raise ContractError('Unknown readonly operation or invalid parameters')
        for key, value in self.params.items():
            if not isinstance(key, str) or not isinstance(value, (str, int, float, bool, type(None))):
                raise ContractError('Parameters must be a JSON scalar dictionary')
            if isinstance(value, float) and not math.isfinite(value):
                raise ContractError('Non-finite parameter')
        object.__setattr__(self, 'params', _FrozenParams(self.params))

    def digest(self, scope):
        return json_digest({'scope': scope.binding(), 'operation': self.operation,
                            'params': dict(self.params)})


@dataclass(frozen=True)
class ReadReceipt:
    scope_fingerprint: str
    request_digest: str
    operation: str
    payload: Any
    evidence: Mapping = field(default_factory=dict)

    def __post_init__(self):
        object.__setattr__(self, 'payload', json_copy(self.payload))
        object.__setattr__(self, 'evidence', json_copy(dict(self.evidence)))


def verify_receipt(scope, request, receipt):
    if not isinstance(receipt, ReadReceipt):
        raise ContractError('Transport must return a bound ReadReceipt')
    if (receipt.scope_fingerprint != scope.fingerprint or
            receipt.request_digest != request.digest(scope) or
            receipt.operation != request.operation):
        raise ContractError('Receipt account, task, source or request binding mismatch')


@dataclass(frozen=True)
class PageProposal:
    checkpoint: dict
    comments: list = field(default_factory=list)
    events: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    unresolved: list = field(default_factory=list)

    def __post_init__(self):
        if not isinstance(self.checkpoint, dict):
            raise ContractError('Checkpoint must be a dictionary')
        for key in ('checkpoint', 'comments', 'events', 'evidence', 'unresolved'):
            object.__setattr__(self, key, json_copy(getattr(self, key)))
