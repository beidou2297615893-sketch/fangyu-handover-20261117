"""Owned manual locator evidence in the existing Core records/audit store.

The authenticated host supplies scope_guard and lead_access. This module never
sets a reply status, platform_reply_id, contact event, or response-check job.
"""
import hashlib
import json
import re
from urllib.parse import urlsplit

from core.page_errors import CoreError
from core.contact_journal import contact_event
from core.review_queue import require_reply_permission, snapshot as reply_snapshot
from core.store import _xhs_note_id

ENTITY = 'manual_reply_locator_evidence'
SAVE = 'manual_reply_locator_save'
GET = 'manual_reply_locator_get'
_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}\Z')
_KEY = re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_ACTOR = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
_SOURCE = ('id', 'tenant_id', 'cloud_owner', 'platform', 'author_id', 'source_id',
           'source_uid', 'source_type', 'comment_id', 'note_url', 'url', 'text',
           'task_id', 'readonly_archive', 'target_comment_id', 'target_author_id')


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_encoded(value).encode()).hexdigest()


class ManualReplyEvidenceError(CoreError):
    def __init__(self, reason):
        super().__init__('定位待核验：' + reason)
        self.code = 'MANUAL_REPLY_EVIDENCE_' + reason.upper()
        self.mutation_committed = False


def _fail(reason):
    raise ManualReplyEvidenceError(reason)


class ManualReplyEvidence:
    ACTIONS = frozenset((SAVE, GET))

    def __init__(self, core, tenant, owner, *, device_id, scope_guard, lead_access):
        if (not all(isinstance(v, str) and v for v in (tenant, owner, device_id))
                or not callable(scope_guard) or not callable(lead_access)):
            raise ValueError('需要当前可信本机范围与评论授权检查')
        self.core, self.store, self.tenant, self.owner = core, core.store, tenant, owner
        self.device_id, self.scope_guard, self.lead_access = device_id, scope_guard, lead_access

    def _row(self, db, entity, ident):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                         (entity, ident, self.tenant)).fetchone()
        if row is None:
            return None
        try:
            value = json.loads(row['body'])
        except (ValueError, TypeError):
            _fail('record_invalid')
        if (not isinstance(value, dict) or value.get('id') != ident
                or value.get('tenant_id') != self.tenant):
            _fail('record_invalid')
        return value

    def _principal(self, db, user):
        actor = self._row(db, 'users', user.get('id')) if isinstance(user, dict) else None
        if (not actor or actor.get('disabled') or actor.get('cloud_bound') is not True
                or actor.get('role') not in ('operator', 'admin')
                or (actor.get('username'), actor.get('tenant_id')) != (self.owner, self.tenant)
                or any(actor.get(key) != user.get(key) for key in _ACTOR)):
            _fail('principal_changed')
        try:
            ready = self.scope_guard() is True
        except Exception:
            ready = False
        if not ready:
            _fail('scope_changed')
        return actor

    def _identity(self, db, reply_id, actor):
        reply = self._row(db, 'replies', reply_id)
        if not reply or reply.get('author_id') != actor['id']:
            _fail('reply_forbidden')
        lead = self._row(db, 'leads', reply.get('lead_id'))
        if (not lead or lead.get('cloud_owner') != self.owner
                or lead.get('platform') != 'xiaohongshu' or reply.get('channel', 'comment') != 'comment'):
            _fail('source_forbidden')
        try:
            self.lead_access(actor, lead)
            require_reply_permission(self.core, actor, lead, reply)
        except (ValueError, CoreError):
            _fail('reply_permission_changed')
        approval = reply.get('approval_snapshot')
        account_id = reply.get('review_account_id')
        if (not isinstance(approval, dict) or not account_id
                or approval.get('account_id') != account_id
                or reply.get('account_id') not in (None, '', account_id)):
            _fail('review_account_missing_or_changed')
        account = self._row(db, 'accounts', account_id)
        if (not account or account.get('cloud_owner') != self.owner
                or account.get('platform') != lead.get('platform')):
            _fail('account_forbidden')
        try:
            self.core._account_access(actor, account)
            self.core._check_reply_recipient(reply, lead, user=actor, account=account)
            current = reply_snapshot(self.core, reply, lead, account, user=actor)
        except (ValueError, CoreError):
            _fail('binding_changed')
        if current != approval:
            _fail('binding_changed')
        recipient = current.get('recipient', {})
        note_id = _xhs_note_id(recipient.get('note_url') or recipient.get('url'))
        comment_id = recipient.get('comment_id')
        customer_id = lead.get('author_id')
        if lead.get('readonly_archive') is True:
            resolver = getattr(self.core, 'archived_reply_targets', {}).get((self.tenant, self.owner))
            if resolver is None:
                _fail('archive_binding_unavailable')
            try:
                source = resolver._contact_source(lead, actor, account, db=db)
            except (ValueError, CoreError):
                _fail('binding_changed')
            if (source.get('comment_id'), source.get('post_id')) != (comment_id, note_id):
                _fail('binding_changed')
            customer_id = source.get('author_id')
        if (not note_id or not isinstance(comment_id, str) or not _ID.fullmatch(comment_id)
                or not isinstance(customer_id, str) or not _ID.fullmatch(customer_id)):
            _fail('source_identity_missing')
        return reply, lead, account, dict(reply_id=reply_id, lead_id=lead['id'],
            post_id=note_id, origin_comment_id=comment_id, customer_id=customer_id,
            account_id=account_id, account_uid=account.get('platform_uid', ''),
            source_digest=_hash({key: lead.get(key) for key in _SOURCE}),
            approval_digest=_hash(approval))

    def _manual_event(self, reply, lead, actor):
        if reply.get('status') != 'sent' or reply.get('sent_by') != actor['id'] or reply.get('platform_reply_id'):
            _fail('manual_contact_required')
        try:
            receipt = self.core.contact_journal.receipt(self.tenant, self.owner, reply['id'], lead['id'])
        except (ValueError, CoreError):
            _fail('contact_evidence_invalid')
        if (receipt.get('local_integrity') != 'ok' or receipt.get('local_outcome') != 'external_reported'
                or any(item['kind'] in ('send_started', 'sent', 'unknown') for item in receipt['events'])):
            _fail('manual_contact_required')
        event = next(item for item in reversed(receipt['events']) if item['kind'] == 'external_reported')
        with self.store.connect() as db:
            raw = db.execute('SELECT payload FROM contact_events WHERE event_id=? AND tenant_id=? AND cloud_owner=?',
                             (event['event_id'], self.tenant, self.owner)).fetchone()
        if not raw:
            _fail('contact_evidence_invalid')
        payload = json.loads(raw['payload'])
        current = contact_event('external_reported', lead, reply,
                                occurred_at=payload['occurred_at'], event_id=payload['event_id'])
        if payload.get('lead') != current['lead'] or payload.get('reply') != current['reply']:
            _fail('original_contact_changed')
        return dict(event_id=event['event_id'], payload_hash=event['payload_hash'], chain_hash=event['chain_hash'])

    def _view(self, record, reply):
        return dict(evidence_id=record['id'], reply_id=record['anchor']['reply_id'],
            lead_id=record['anchor']['lead_id'], idempotency_key=record['idempotency_key'],
            locator=dict(record['locator']), evidence_digest=record['evidence_digest'],
            status='external_reported', verification_status='unverified', message='定位待核验',
            storage_scope='this_device', reply_status_unchanged=reply.get('status'),
            platform_reply_id_modified=False, platform_verified=False,
            response_check_started=False, auto_retry=False, created_at=record['created_at'])

    def __call__(self, action, data, user):
        fields = {'reply_id', 'idempotency_key'}
        if action == SAVE:
            fields |= {'reported_comment_id', 'reported_note_url', 'confirmed'}
        if (action not in self.ACTIONS or not isinstance(data, dict) or set(data) != fields
                or not isinstance(data.get('reply_id'), str) or not _ID.fullmatch(data['reply_id'])
                or not isinstance(data.get('idempotency_key'), str) or not _KEY.fullmatch(data['idempotency_key'])):
            _fail('invalid_input')
        ident = _hash([self.tenant, self.owner, self.device_id, data['reply_id']])
        with self.core.lock, self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE' if action == SAVE else 'BEGIN')
            actor = self._principal(db, user)
            reply, lead, account, anchor = self._identity(db, data['reply_id'], actor)
            existing = db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=?',
                                  (ENTITY, self.tenant)).fetchall()
            if any(raw['id'] != ident and (value := json.loads(raw['body'])).get('cloud_owner') == self.owner
                   and value.get('device_id') == self.device_id
                   and value.get('idempotency_key') == data['idempotency_key'] for raw in existing):
                _fail('idempotency_conflict')
            record = self._row(db, ENTITY, ident)
            if record:
                expected = {key: record.get(key) for key in record if key != 'evidence_digest'}
                if (record.get('evidence_digest') != _hash(expected) or record.get('anchor') != anchor
                        or record.get('cloud_owner') != self.owner or record.get('device_id') != self.device_id
                        or record.get('actor') != {key: actor.get(key) for key in _ACTOR}):
                    _fail('saved_binding_changed')
                if record.get('idempotency_key') != data['idempotency_key']:
                    _fail('original_key_required')
            if action == GET:
                self._principal(db, user)
                return self._view(record, reply) if record else dict(reply_id=data['reply_id'],
                    idempotency_key=data['idempotency_key'], state='unknown', message='原编号未找到保存证据，请人工核对',
                    evidence=None, auto_retry=False, mutation_committed=False, response_check_started=False)
            if data.get('confirmed') is not True:
                _fail('confirmation_required')
            comment = data['reported_comment_id']
            url = data['reported_note_url']
            if (not isinstance(comment, str) or not _ID.fullmatch(comment)
                    or comment == anchor['origin_comment_id'] or _xhs_note_id(url) != anchor['post_id']):
                _fail('locator_source_mismatch')
            parsed = urlsplit(url)
            if parsed.query or parsed.fragment:
                _fail('public_locator_only')
            locator = dict(reported_comment_id=comment,
                           reported_note_url='https://www.xiaohongshu.com/explore/' + anchor['post_id'])
            if record:
                if record.get('locator') != locator:
                    _fail('idempotency_conflict')
                self._principal(db, user)
                return self._view(record, reply)
            event = self._manual_event(reply, lead, actor)
            # A sibling's unresolved operation remains a send lock; recording
            # a locator must never create a route around it.
            siblings = db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',
                                  ('replies', self.tenant)).fetchall()
            if any((row := json.loads(raw['body'])).get('lead_id') == lead['id']
                   and row.get('status') in ('sending', 'unknown') for raw in siblings):
                _fail('contact_result_unknown')
            record = self.core._record(dict(id=ident, cloud_owner=self.owner,
                device_id=self.device_id, actor={key: actor.get(key) for key in _ACTOR},
                anchor=anchor, original_contact_event=event, idempotency_key=data['idempotency_key'],
                operation_action=SAVE, locator=locator, status='external_reported',
                verification_status='unverified'), self.tenant)
            record['evidence_digest'] = _hash(record)
            audit = self.core._record(dict(actor=actor['username'], action=SAVE,
                detail=dict(evidence_id=ident, reply_id=reply['id'], lead_id=lead['id'],
                            evidence_digest=record['evidence_digest'], verification_status='unverified')), self.tenant)
            self._principal(db, user)
            for entity, value in ((ENTITY, record), ('audit', audit)):
                db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                           (entity, value['id'], self.tenant, _encoded(value)))
            self._principal(db, user)
            return self._view(record, reply)

    execute = __call__
