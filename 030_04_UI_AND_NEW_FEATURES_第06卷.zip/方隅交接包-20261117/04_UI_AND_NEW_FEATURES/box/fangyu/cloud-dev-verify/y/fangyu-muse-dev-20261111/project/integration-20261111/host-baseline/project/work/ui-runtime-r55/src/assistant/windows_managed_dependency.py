"""Windows .NET Framework file evidence; no CLR or renderer is constructed.

Legacy Framework signatures may have a valid authenticated timestamp and an
expired signing certificate today. Verify the original WinTrust signer time
and both signer/timestamp chains against machine roots, without online fetch.
This is independent of the stricter current Evergreen policy.
"""
import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
import hashlib
import time
import uuid
from . import windows_authenticode as auth
from .webview_system_dependency import _Apis, _HeldFile, _acl, _path

_SEAL = object()
_NAMES = frozenset(('mscorlib', 'System', 'System.Core', 'System.Xml', 'System.Xml.Linq',
    'System.Data', 'System.Drawing', 'System.Windows.Forms', 'System.Configuration',
    'System.Management', 'System.Net.Http', 'System.Numerics', 'System.Collections',
    'System.Dynamic.Runtime', 'System.Reflection', 'System.Reflection.Emit',
    'System.Runtime', 'System.Runtime.Extensions', 'System.Runtime.Remoting',
    'System.Runtime.InteropServices.RuntimeInformation', 'System.Threading',
    'System.ValueTuple', 'Microsoft.CSharp', 'netstandard', 'Accessibility'))
_ROOTS = frozenset(('Microsoft Root Certificate Authority 2010',
    'Microsoft Root Certificate Authority 2011', 'Microsoft Root Certificate Authority 2020',
    'Microsoft Identity Verification Root Certificate Authority 2020'))


class ManagedDependencyRequired(ValueError):
    pass


def _fail(code):
    raise ManagedDependencyRequired(code)


class FILETIME(c.Structure):
    _fields_ = [('low', w.DWORD), ('high', w.DWORD)]


class SIGNER(c.Structure):
    _fields_ = [('size', w.DWORD), ('verifyAsOf', FILETIME), ('certCount', w.DWORD),
        ('certs', c.c_void_p), ('signerType', w.DWORD), ('info', c.c_void_p),
        ('error', w.DWORD), ('counterCount', w.DWORD), ('counters', c.c_void_p),
        ('chain', c.c_void_p)]


def microsoft_timestamped_signature(path, handle):
    wintrust, crypt = auth._dll('wintrust.dll'), auth._dll('crypt32.dll')
    wintrust.WinVerifyTrust.argtypes = [w.HWND, c.POINTER(auth.GUID), c.POINTER(auth.TRUSTDATA)]
    wintrust.WinVerifyTrust.restype = c.c_long
    wintrust.WTHelperProvDataFromStateData.argtypes = [w.HANDLE]
    wintrust.WTHelperProvDataFromStateData.restype = c.c_void_p
    wintrust.WTHelperGetProvSignerFromChain.argtypes = [c.c_void_p, w.DWORD, w.BOOL, w.DWORD]
    wintrust.WTHelperGetProvSignerFromChain.restype = c.c_void_p
    wintrust.WTHelperGetProvCertFromChain.argtypes = [c.c_void_p, w.DWORD]
    wintrust.WTHelperGetProvCertFromChain.restype = c.POINTER(auth.PROVIDERCERT)
    crypt.CertGetNameStringW.argtypes = [c.c_void_p, w.DWORD, w.DWORD, c.c_void_p, w.LPWSTR, w.DWORD]
    crypt.CertGetNameStringW.restype = w.DWORD
    crypt.CertGetCertificateChain.argtypes = [w.HANDLE, c.c_void_p, c.c_void_p, w.HANDLE,
        c.POINTER(auth.CHAINPARA), w.DWORD, c.c_void_p, c.POINTER(c.POINTER(auth.CHAINCONTEXT))]
    crypt.CertGetCertificateChain.restype = w.BOOL
    crypt.CertFreeCertificateChain.argtypes = [c.POINTER(auth.CHAINCONTEXT)]
    action = auth.GUID((c.c_ubyte * 16).from_buffer_copy(
        uuid.UUID('00aac56b-cd44-11d0-8cc2-00c04fc295ee').bytes_le))
    file = auth.FILEINFO(c.sizeof(auth.FILEINFO), str(path), handle, None)
    data = auth.TRUSTDATA(c.sizeof(auth.TRUSTDATA), None, None, 2, 0, 1,
        c.pointer(file), 1, None, None, 0x1000 | 0x80, 0, None)

    def attr(cert, oid):
        result = c.create_unicode_buffer(1024)
        raw = c.c_char_p(oid.encode('ascii'))
        if not 1 < crypt.CertGetNameStringW(cert, 3, 0, c.cast(raw, c.c_void_p), result, 1024) <= 1024:
            _fail('managed_certificate_name')
        return result.value

    def record(cert):
        value = c.cast(cert, c.POINTER(auth.CERTCONTEXT)).contents
        if not 1 <= value.size <= 65536:
            _fail('managed_certificate_size')
        return {'commonName': attr(cert, '2.5.4.3'), 'organization': attr(cert, '2.5.4.10'),
            'country': attr(cert, '2.5.4.6'),
            'certificateSha256': hashlib.sha256(c.string_at(value.data, value.size)).hexdigest()}

    def chain_for(cert, when, eku):
        context = c.cast(cert, c.POINTER(auth.CERTCONTEXT)).contents
        para = auth.CHAINPARA(); para.cbSize = c.sizeof(para)
        oids = (c.c_char_p * 1)(eku)
        para.usage = auth.USAGEMATCH(0, auth.USAGE(1, oids)); para.urlTimeout = 1000
        chain = c.POINTER(auth.CHAINCONTEXT)()
        try:
            if not crypt.CertGetCertificateChain(w.HANDLE(1), cert, c.byref(when), context.store,
                    c.byref(para), 0x4 | 0x100 | 0x40000000 | 0x80000000, None, c.byref(chain)):
                _fail('managed_machine_chain_unavailable')
            if not chain or chain.contents.trust.error or chain.contents.count != 1:
                _fail('managed_machine_chain_' + format(chain.contents.trust.error if chain else 0xffffffff, '08x'))
            simple = chain.contents.chains[0].contents
            if simple.trust.error or not 2 <= simple.count <= 8:
                _fail('managed_machine_chain_invalid')
            rows = [record(simple.elements[i].contents.cert) for i in range(simple.count)]
            if rows[-1]['commonName'] not in _ROOTS or rows[-1]['organization'] != 'Microsoft Corporation' or rows[-1]['country'] != 'US':
                _fail('managed_root_not_microsoft')
            return rows
        finally:
            if chain:
                crypt.CertFreeCertificateChain(chain)

    try:
        status = wintrust.WinVerifyTrust(w.HWND(-1), c.byref(action), c.byref(data))
        if status != 0:
            _fail('managed_authenticode_' + format(status & 0xffffffff, '08x'))
        provider = wintrust.WTHelperProvDataFromStateData(data.state)
        pointer = wintrust.WTHelperGetProvSignerFromChain(provider, 0, False, 0) if provider else None
        if not pointer:
            _fail('managed_signer_unavailable')
        signer = c.cast(pointer, c.POINTER(SIGNER)).contents
        if signer.size < c.sizeof(SIGNER) or signer.error or not 1 <= signer.certCount <= 8:
            _fail('managed_signer_invalid')
        when = signer.verifyAsOf
        ticks = (int(when.high) << 32) | when.low
        now_ticks = int((time.time() + 11644473600) * 10000000)
        if not 116444736000000000 <= ticks <= now_ticks + 10000000:
            _fail('managed_verified_time_invalid')
        certificate = wintrust.WTHelperGetProvCertFromChain(pointer, 0)
        if not certificate or not certificate.contents.cert:
            _fail('managed_signer_certificate')
        leaf = record(certificate.contents.cert)
        if (leaf['commonName'], leaf['organization'], leaf['country']) != (
                'Microsoft Corporation', 'Microsoft Corporation', 'US'):
            _fail('managed_publisher_not_microsoft')
        rows = chain_for(certificate.contents.cert, when, b'1.3.6.1.5.5.7.3.3')
        timestamps = []
        if signer.counterCount:
            if not 1 <= signer.counterCount <= 8:
                _fail('managed_timestamp_invalid')
            for index in range(signer.counterCount):
                counter_ptr = wintrust.WTHelperGetProvSignerFromChain(provider, 0, True, index)
                if not counter_ptr:
                    _fail('managed_timestamp_unavailable')
                counter = c.cast(counter_ptr, c.POINTER(SIGNER)).contents
                counter_cert = wintrust.WTHelperGetProvCertFromChain(counter_ptr, 0)
                if counter.error or not counter_cert or not counter_cert.contents.cert:
                    _fail('managed_timestamp_invalid')
                timestamps.append(chain_for(counter_cert.contents.cert, when, b'1.3.6.1.5.5.7.3.8'))
        elif abs(now_ticks - ticks) > 60 * 10000000:
            _fail('managed_untimestamped_historical_time')
        return {'authenticodeResult': 0, 'publisher': leaf, 'signerChain': rows,
            'verifiedAsOfFiletime': ticks, 'timestampChains': timestamps,
            'machineChainError': 0, 'networkRetrieval': False, 'ui': False}
    finally:
        data.action = 2
        wintrust.WinVerifyTrust(w.HWND(-1), c.byref(action), c.byref(data))


def windows_framework_roots():
    kernel = auth._dll('kernel32.dll')
    kernel.GetWindowsDirectoryW.argtypes = [w.LPWSTR, w.UINT]
    kernel.GetWindowsDirectoryW.restype = w.UINT
    value = c.create_unicode_buffer(32768)
    if not 0 < kernel.GetWindowsDirectoryW(value, len(value)) < len(value):
        _fail('managed_windows_root')
    return _path(Path(value.value) / 'Microsoft.NET')


def _allowed(path, root):
    path = _path(path)
    if not path.is_relative_to(root) or path.suffix.casefold() != '.dll' or path.stem.casefold() not in {x.casefold() for x in _NAMES}:
        _fail('managed_assembly_not_evaluated')
    parts = path.relative_to(root).parts
    framework = len(parts) == 3 and parts[0] == 'Framework64' and parts[1] == 'v4.0.30319'
    gac = (len(parts) == 5 and parts[0] == 'assembly' and parts[1] in ('GAC_64', 'GAC_MSIL')
        and parts[2].casefold() == path.stem.casefold()
        and parts[3] in ('v4.0_4.0.0.0__b77a5c561934e089', 'v4.0_4.0.0.0__b03f5f7f11d50a3a',
            'v4.0_4.0.0.0__cc7b13ffcd2ddd51', 'v4.0_2.0.0.0__cc7b13ffcd2ddd51'))
    if not framework and not gac:
        _fail('managed_assembly_location')
    return path


class _ManagedEvidence:
    def __init__(self, seal, root, held, rows, directories):
        if seal is not _SEAL:
            _fail('managed_evidence_unavailable')
        self._seal, self.root, self._held, self._rows, self._directories = seal, root, held, rows, directories
        self.closed = False

    @property
    def materials(self):
        return tuple((row['path'], row['sha256'].upper(), 'managed_runtime') for row in self._rows)

    def check_current(self):
        if self._seal is not _SEAL or self.closed or windows_framework_roots() != self.root:
            _fail('managed_evidence_changed')
        apis = self._held[0].apis
        for path, expected in self._directories:
            if _acl(path, apis) != expected:
                _fail('managed_directory_changed')
        for held in self._held:
            if held.facts() != held.initial:
                _fail('managed_file_changed')
        return self

    def describe(self):
        return {'contract': 'windows_framework_file_trust_v1', 'files': list(self._rows),
            'nativeLoadedBytesVerified': False, 'windowOpened': False}

    def close(self):
        if not self.closed:
            self.closed = True
            for held in reversed(self._held):
                held.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


def verify_framework_files(paths=None):
    root, apis = windows_framework_roots(), _Apis()
    if paths is None:
        paths = [root / 'Framework64/v4.0.30319' / (name + '.dll') for name in sorted(_NAMES)]
        paths += list((root / 'assembly/GAC_MSIL').glob('*/*/*.dll'))
        paths += list((root / 'assembly/GAC_64').glob('*/*/*.dll'))
        paths = [path for path in paths if path.is_file() and path.stem.casefold() in {x.casefold() for x in _NAMES}]
    if type(paths) not in (tuple, list) or not 1 <= len(paths) <= 128:
        _fail('managed_inventory_budget')
    held, rows, directories, seen = [], [], [], set()
    try:
        for path in paths:
            path = _allowed(path, root)
            if str(path).casefold() in seen:
                _fail('managed_duplicate')
            seen.add(str(path).casefold())
            for part in (*reversed(path.relative_to(root).parents),):
                directory = root / part
                if str(directory).casefold() not in {str(p).casefold() for p, _ in directories}:
                    item = _HeldFile(apis, directory, directory=True); held.append(item)
                    directories.append((directory, _acl(directory, apis)))
            item = _HeldFile(apis, path); held.append(item)
            rows.append({'path': str(path), 'sha256': item.hash(), 'identity': item.initial,
                'signature': microsoft_timestamped_signature(path, item.handle)})
        if not {'mscorlib', 'system.windows.forms', 'system.drawing'} <= {Path(row['path']).stem.casefold() for row in rows}:
            _fail('managed_required_missing')
        value = _ManagedEvidence(_SEAL, root, held, rows, directories)
        value.check_current()
        return value
    except BaseException:
        for item in reversed(held):
            item.close()
        raise
