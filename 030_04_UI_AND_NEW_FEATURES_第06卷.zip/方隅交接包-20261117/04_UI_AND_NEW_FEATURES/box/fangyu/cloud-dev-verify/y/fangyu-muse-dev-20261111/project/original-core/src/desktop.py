"""Windows native WebView2 shell. Never falls back to an external browser."""
import ctypes
from ctypes import wintypes
import logging
import os
import threading
import time
from pathlib import Path
from urllib.parse import urlparse
import sys


def focus_process_window(pid):
    """Activate only a visible top-level window owned by the locked app process."""
    if os.name!='nt' or not isinstance(pid,int) or pid<=0:return False
    user32=ctypes.windll.user32
    user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    user32.IsWindowVisible.argtypes=[wintypes.HWND]
    user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
    user32.SetForegroundWindow.argtypes=[wintypes.HWND]
    matches=[]
    callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    def visitor(handle,_):
        owner=wintypes.DWORD();user32.GetWindowThreadProcessId(handle,ctypes.byref(owner))
        if owner.value==pid and user32.IsWindowVisible(handle):matches.append(handle);return False
        return True
    callback=callback_type(visitor)
    user32.EnumWindows(callback,0)
    if not matches:return False
    user32.ShowWindow(matches[0],9)
    user32.SetForegroundWindow(matches[0])
    return True


def show_desktop_error(message):
    logging.error('Desktop startup failed: %s',message)
    if os.name=='nt':
        ctypes.windll.user32.MessageBoxW(None,'本地客户端未能启动。\n\n请确认已安装 Microsoft Edge WebView2 Runtime，并查看工作台日志。\n\n'+str(message),'客户端启动失败',0x10)


def run_desktop(server,url,data_dir,title,ready_callback=None):
    import webview
    if os.name=='nt':ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('LocalWorkspace.'+server.company['id'])
    stop_lock=threading.Lock();stopped=False
    def stop_owned():
        nonlocal stopped
        with stop_lock:
            if stopped:return
            stopped=True
        try:server.close_owned_jobs()
        finally:server.shutdown()
    webview.settings['ALLOW_DOWNLOADS']=True
    window=webview.create_window(title,url=url,width=1440,height=960,min_size=(1000,680),background_color='#F6F7F8',text_select=True,zoomable=False)
    def attach_navigation_guard():
        if getattr(window,'_workspace_navigation_guard',None):return
        try:
            origin=urlparse(url)
            def guard(sender,args):
                target=urlparse(str(args.Uri))
                if target.scheme=='about' and target.path=='blank':return
                if target.scheme=='blob':
                    blob_origin=urlparse(target.path)
                    if (blob_origin.scheme,blob_origin.netloc)==(origin.scheme,origin.netloc):return
                if (target.scheme,target.netloc)==(origin.scheme,origin.netloc):return
                args.Cancel=True
                if bool(getattr(args,'IsUserInitiated',False)) and target.scheme in ('http','https'):
                    import webbrowser
                    webbrowser.open(str(args.Uri))
            from System import Action
            def register():window.native.browser.webview.NavigationStarting.__iadd__(guard)
            window.native.Invoke(Action(register))
            window._workspace_navigation_guard=guard
        except Exception:
            logging.exception('Native navigation protection could not initialize')
            window.destroy()
            show_desktop_error('桌面页面隔离未能初始化，客户端已关闭。')
    window.events.loaded+=attach_navigation_guard
    renderer_state={'accepted':False}
    def check_renderer(renderer):
        renderer_state['accepted']=renderer=='edgechromium'
        return renderer_state['accepted']
    window.events.initialized+=check_renderer
    window.events.closed+=stop_owned
    if ready_callback:window.events.loaded+=lambda:ready_callback(window)
    server_thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.2},daemon=True)
    server_thread.start()
    def monitor():
        while not stopped:
            if server.closing or not server_thread.is_alive():
                try:window.destroy()
                except Exception:pass
                return
            time.sleep(.2)
    threading.Thread(target=monitor,daemon=True).start()
    try:
        resource_root=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
        icon=resource_root/'resources/brand.ico'
        webview.start(gui='edgechromium',debug=False,private_mode=False,storage_path=str(Path(data_dir)/'webview2'),icon=str(icon) if icon.exists() else None)
        if not renderer_state['accepted']:raise RuntimeError('需要 WebView2 桌面运行时，不使用旧浏览器替代')
    finally:
        stop_owned();server_thread.join(timeout=6)
