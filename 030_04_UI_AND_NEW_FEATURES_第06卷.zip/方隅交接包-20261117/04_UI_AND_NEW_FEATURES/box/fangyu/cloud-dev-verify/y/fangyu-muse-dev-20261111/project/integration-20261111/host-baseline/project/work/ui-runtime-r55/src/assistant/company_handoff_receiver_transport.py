"""Fixed receiver actions over the existing, unrefreshed company session."""
from copy import deepcopy
import re

from .company_handoff_status_transport import CompanyHandoffStatusTransport, CompanyHandoffStatusTransportError

LIST = 'acquisition_handoff_list'
DETAIL = 'acquisition_handoff_detail'
RECEIPT = 'acquisition_handoff_receipt'
STATUS = 'acquisition_handoff_operation_status'
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_REF = re.compile(r'(?:evidence|document):[a-f0-9]{32}\Z')
_REASONS = {'accept': None, 'reject': ('not_qualified', 'outside_service_area'),
    'needs_information': ('needs_information',), 'duplicate': ('duplicate',), 'existing_customer': ('existing_customer',)}


class CompanyHandoffReceiverTransportError(ValueError):
    def __init__(self, code, message, status=503, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_RECEIVER_TRANSPORT_' + code
        self.status, self.mutation_committed = status, mutation_committed


def _fail(code, message, status=503, *, mutation=False):
    raise CompanyHandoffReceiverTransportError(code, message, status, mutation)


def _valid(operation, data):
    if not isinstance(data, dict):
        return False
    if operation == LIST:
        return (set(data) <= {'view', 'recipient_id', 'offset', 'limit'} and data.get('view') == 'received'
            and ('recipient_id' not in data or isinstance(data['recipient_id'], str) and _ID.fullmatch(data['recipient_id']))
            and type(data.get('offset', 0)) is int and data.get('offset', 0) >= 0
            and type(data.get('limit', 10)) is int and 1 <= data.get('limit', 10) <= 15)
    if operation == DETAIL:
        return set(data) == {'channel_id'} and isinstance(data['channel_id'], str) and bool(_CHANNEL.fullmatch(data['channel_id']))
    if operation == STATUS:
        return (set(data) == {'operation_action', 'idempotency_key'} and data['operation_action'] == RECEIPT
            and isinstance(data['idempotency_key'], str) and bool(_HEX.fullmatch(data['idempotency_key'])))
    if operation == RECEIPT:
        reason = _REASONS.get(data.get('decision'), False)
        return (reason is not False and set(data) == ({'channel_id', 'expected_revision', 'decision', 'evidence_reference', 'idempotency_key'}
            | ({'reason_code'} if reason is not None else set()))
            and isinstance(data['channel_id'], str) and bool(_CHANNEL.fullmatch(data['channel_id']))
            and type(data['expected_revision']) is int and 1 <= data['expected_revision'] < 9007199254740991
            and isinstance(data['idempotency_key'], str) and bool(_HEX.fullmatch(data['idempotency_key']))
            and isinstance(data['evidence_reference'], str) and bool(_REF.fullmatch(data['evidence_reference']))
            and (reason is None or data.get('reason_code') in reason))
    return False


class CompanyHandoffReceiverTransport(CompanyHandoffStatusTransport):
    def _receiver_capture(self, actor, margin, *, dispatched=False):
        try:
            return self._capture(actor, margin)
        except CompanyHandoffStatusTransportError as error:
            _fail('SESSION_REQUIRED' if error.code.endswith('_SESSION_REQUIRED') else 'BINDING_CHANGED',
                '当前公司接收身份或连接需核对，请保留原接收编号', 409,
                mutation=None if dispatched else False)

    def __call__(self, actor, operation, data):
        if not _valid(operation, data):
            _fail('INVALID_REQUEST', '公司接收只接受固定范围和原编号，不能附带来源人或联系方式', 400)
        writing = operation == RECEIPT
        before = self._receiver_capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], dict(environment_id=self.environment_id,
                operation=operation, **deepcopy(data)), before['token'])
        except Exception:
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE',
                '公司接收结果尚未确认，请保留原号核对；未自动重发' if writing else '公司收件或原接收回执暂不可读，请稍后核对',
                mutation=None if writing else False)
        after = self._receiver_capture(actor, 0, dispatched=writing)
        if after != before:
            _fail('BINDING_CHANGED', '返回时本人或公司连接已变化，请保留原号', 409, mutation=None if writing else False)
        outer = {'contract', 'environment_id', 'company_id'}
        common = {'server_recorded', 'platform_delivery_verified', 'attribution_confirmed', 'settlement_active'}
        pure = {'read_only', 'mutation_committed', 'auto_retry'}
        if operation == STATUS:
            expected = outer | {'operation_receipt'} | pure
        elif writing:
            expected = outer | common | {'item', 'replayed'}
        elif operation == DETAIL:
            expected = outer | common | {'item'} | pure
        else:
            expected = outer | common | {'items', 'total', 'offset', 'has_more', 'authorized_recipients',
                'selected_recipient_id', 'selection_required'} | pure
        valid = (isinstance(result, dict) and set(result) == expected
            and result.get('contract') == 'fangyu-workspace-v1' and result.get('environment_id') == self.environment_id
            and result.get('company_id') == self.company_id)
        if valid and not writing:
            valid = result.get('read_only') is True and result.get('mutation_committed') is False and result.get('auto_retry') is False
        if valid and operation != STATUS:
            valid = result.get('server_recorded') is True and all(result.get(key) is False for key in
                ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))
        if not valid:
            _fail('RESULT_UNKNOWN' if writing else 'READ_UNAVAILABLE', '公司接收回执身份或格式需核对，请保留原号',
                mutation=None if writing else False)
        if self._receiver_capture(actor, 0, dispatched=writing) != before:
            _fail('BINDING_CHANGED', '返回时原公司范围已变化，请保留原接收编号', 409, mutation=None if writing else False)
        if writing:
            return {key: deepcopy(result[key]) for key in ('item', 'replayed')}
        return {key: deepcopy(value) for key, value in result.items() if key not in outer}
