"""Background checks for an already pinned employee update feed.

This worker never starts, stops, or replaces an application process. The fixed
launcher applies a queued update on the next normal opening of the workbench.
"""
import threading


class AutoUpdateWorker:
    def __init__(self, coordinator, *, initial_delay=90, check_interval=4 * 60 * 60,
                 idle_retry=5 * 60):
        if min(initial_delay, check_interval, idle_retry) < 0 or not check_interval or not idle_retry:
            raise ValueError('自动更新检查周期无效')
        self.coordinator = coordinator
        self.initial_delay = initial_delay
        self.check_interval = check_interval
        self.idle_retry = idle_retry
        self._closed = threading.Event()
        self._thread = None

    def run_once(self):
        """Check signed metadata, stage verified bytes, queue only when idle."""
        if self._closed.is_set():
            return 'closed'
        try:
            state = self.coordinator.status()
            if not state.get('feed_configured'):
                return 'waiting'
            if state.get('requires_restart'):
                state = self.coordinator.refresh_pending()
                if state.get('requires_restart'):
                    return 'waiting'
            # Refresh TUF metadata even for an already staged package: a busy
            # workbench may run beyond timestamp expiry before it can queue.
            state = self.coordinator.check(download=True)
            if self._closed.is_set():
                return 'closed'
            if state.get('status') == 'staged':
                state = self.coordinator.request_install()
            return state.get('status', 'waiting')
        except Exception:
            # Preserve a fixed, non-secret status. TUF errors may contain URLs or
            # machine paths and must never be copied to employee-facing state.
            try:
                if not self._closed.is_set():
                    self.coordinator.record_background_failure()
            except Exception:
                pass
            return 'check_failed'

    def _run(self):
        if self._closed.wait(self.initial_delay):
            return
        while not self._closed.is_set():
            status = self.run_once()
            delay = self.idle_retry if status in ('busy', 'check_failed') else self.check_interval
            if self._closed.wait(delay):
                return

    def start(self):
        if self._thread is not None:
            raise ValueError('自动更新工作线程已经启动')
        if self._closed.is_set():
            raise ValueError('自动更新工作线程已经关闭')
        self._thread = threading.Thread(target=self._run, name='employee-auto-update', daemon=True)
        self._thread.start()
        return self

    def close(self, timeout=5):
        self._closed.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
        return self._thread is None or not self._thread.is_alive()
