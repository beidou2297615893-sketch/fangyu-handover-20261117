"""Explicit, status-only identity observation; never session commit or ready.

One original worker owns the account/Job until physical shutdown. Only then is
the small RAM observation available to the same current DeviceSession actor.
"""
import secrets
import threading
import time

from core.adapters import AdapterSafetyRequired
from xhs_page_transport import XhsPageTransport,PageTransportError,_identity_observation_profile
from .xhs_identity_scope import _IdentityScope
from .xhs_identity_context import (mint_identity_worker,identity_worker_call,
                                   _IdentityWorkerClaim)
from .xhs_identity_policy import XhsIdentityObservationPolicy
from .owned_xhs_native.provider import OwnedXhsNativeProvider


_MESSAGES={
    'unknown':'尚未读取本机页面身份；原账号状态保持不变',
    'in_progress':'正在只读核对页面身份，窗口完成收尾后显示结果',
    'pending_manual_review':'已读取页面身份，待人工核对；尚未绑定或确认账号就绪',
    'needs_login':'当前页面没有可核对的已登录身份，请按原登录流程处理',
    'verification_required':'平台要求电脑端验证；本次身份观测已结束',
    'cancelled':'已取消身份观测，原账号状态保持不变',
    'failed':'本次身份观测未完成，原账号与风险记录保持不变',
}


def _view(state,identity=None,stamp=None,job_id=None):
    value={'observation_state':state,'observed_identity':identity,
           'observed_at':stamp,'account_ready':False,'message':_MESSAGES[state]}
    if job_id is not None:value['login_job']=job_id
    return value


def start_identity_observation(service,account_id):
    from .service import AssistantService
    from .xhs_page_runtime import XhsPageRuntime
    if type(service) is not AssistantService:
        raise AdapterSafetyRequired('identity_service_unavailable')
    server,core=service.server,service.server.core
    user=service._local_user(read_only=True)
    with core.lock:
        account=core._get('accounts',str(account_id or ''),user['tenant_id'])
        core._account_access(user,account)
        from .xhs_customer_account_runtime import runtime_for,account_runtime_matches
        runtime=runtime_for(server)
        policy=getattr(server,'_xhs_identity_policy',None)
        factory=getattr(runtime,'owned_identity_factory',None)
        if (account.get('platform')!='xiaohongshu' or type(runtime) is not XhsPageRuntime
                or not account_runtime_matches(server,runtime) or runtime.core is not core
                or not runtime.natural_mode or runtime.closed
                or type(policy) is not XhsIdentityObservationPolicy or policy.resolve() is None
                or type(factory) is not OwnedXhsNativeProvider or factory._server is not server
                or factory.identity_factory is not factory):
            raise AdapterSafetyRequired('identity_component_review_unavailable')
        job={'id':secrets.token_hex(12),'kind':'assistant_account_login','mode':'browser',
             'purpose':'identity_observation','owner_id':user['id'],'tenant_id':user['tenant_id'],
             'account_id':account['id'],'status':'running','phase':'observing_identity',
             'worker_done':threading.Event(),'_identity_runtime':runtime}
    with server.job_lock:
        if any(other.get('kind')=='assistant_account_login' and other.get('account_id')==account['id']
                and (other.get('status')=='running' or
                     isinstance(other.get('worker_done'),threading.Event) and not other['worker_done'].is_set())
                for other in server.jobs.values()):
            raise AdapterSafetyRequired('identity_previous_worker_closing')
        server.jobs[job['id']]=job
    try:
        claim=mint_identity_worker(service,user,account,job)
        decision=policy.resolve()
        if decision is None:raise AdapterSafetyRequired('identity_component_review_unavailable')
    except BaseException:
        with server.job_lock:
            if server.jobs.get(job['id']) is job:server.jobs.pop(job['id'])
        raise

    def run():
        scope=None
        response=None
        outcome='failed'
        try:
            with identity_worker_call(claim) as context:
                scope=_IdentityScope(runtime,user,account,job,context)
                scope.enter()
                try:
                    def guard(event,facts):
                        if (facts.get('action')!='status' or facts.get('tenant_id')!=scope.tenant
                                or facts.get('account_id')!=scope.account_id):
                            raise AdapterSafetyRequired('identity_action_denied')
                        scope.check()
                        if job.get('cancel_file') and runtime.entries[scope.root].transport.cancel_file.exists():
                            raise AdapterSafetyRequired('identity_cancelled')
                        return True
                    transport=XhsPageTransport(scope.root,scope.tenant,scope.account_id,
                        str(account.get('platform_uid') or ''),guard,
                        lambda path:factory(path,owned_scope=scope),
                        natural_mode=True,identity_observation=True)
                    scope.entry.transport=transport
                    with server.job_lock:
                        job['cancel_file']=transport.cancel_file
                    envelope=transport.open()
                    response=_identity_observation_profile(envelope)
                    outcome='pending_manual_review'
                except PageTransportError as error:
                    outcome=('needs_login' if error.code=='not_authenticated' else
                             'verification_required' if error.code=='verification_required' else
                             'cancelled' if job.get('status')=='cancelled' else 'failed')
                finally:
                    # Stop also a verification page: this fixed entry observes
                    # one status, it does not wait for or import a new login.
                    scope.entry.stop_requested=True
                    scope.entry.lifecycle_wake.set()
                    with server.job_lock:job['phase']='cleaning_candidate'
                    scope.finish()
                # Revoke/cancel after a valid response can still reject the
                # result. Physical cleanup above never needs this authority.
                context.check()
                if policy.resolve() is not decision:
                    raise AdapterSafetyRequired('identity_component_review_changed')
                with server.job_lock:
                    if job.get('status')!='running':
                        outcome='cancelled';response=None
                    job['identity_observation']=_view(outcome,response if outcome=='pending_manual_review' else None,
                        time.time() if outcome=='pending_manual_review' else None,job['id'])
                    job.update(status='completed' if outcome=='pending_manual_review' else 'cancelled'
                        if outcome=='cancelled' else 'failed',phase=outcome,error_code='' if outcome=='pending_manual_review' else outcome,
                        error='' if outcome=='pending_manual_review' else _MESSAGES[outcome])
        except Exception:
            with server.job_lock:
                outcome='cancelled' if job.get('status')=='cancelled' else 'failed'
                job['identity_observation']=_view(outcome,job_id=job['id'])
                job.update(status='cancelled' if outcome=='cancelled' else 'failed',phase=outcome,
                           error_code=outcome,error=_MESSAGES[outcome])
        finally:
            # Original finish returns only after all physical transport/Job
            # cleanup. An interruption leaves the exact scope retained and
            # must not publish done or detach its owner.
            if scope is None or not scope.entered or scope.finished:
                job['worker_done'].set()
    try:
        threading.Thread(target=run,name='assistant-identity-observation',daemon=True).start()
    except BaseException:
        with server.job_lock:
            if server.jobs.get(job['id']) is job:server.jobs.pop(job['id'])
        raise
    return {'login_job':job['id'],'mode':'browser','purpose':'identity_observation',
            'account':{key:account.get(key) for key in ('id','name','platform','status')},
            **_view('in_progress',job_id=job['id'])}


def cancel_identity_observation(service,job):
    """Signal the exact original worker atomically with Resume/first publish.

    This is cleanup authority, including service stop after actor revocation.
    Manual access admission remains in Service. Never close from this thread.
    """
    from .service import AssistantService
    from .browser_login_service import _cancel_marker
    if type(service) is not AssistantService or type(job) is not dict:
        raise AdapterSafetyRequired('identity_cancel_scope_changed')
    server=service.server
    runtime=job.get('_identity_runtime')
    with server.core.lock:
        with runtime.lock:
            with server.job_lock:
                claim=job.get('_identity_claim')
                if (server.jobs.get(job.get('id')) is not job
                        or job.get('purpose')!='identity_observation'
                        or job.get('kind')!='assistant_account_login' or job.get('mode')!='browser'
                        or type(claim) is not _IdentityWorkerClaim or claim.job is not job
                        or claim.session.service is not service):
                    raise AdapterSafetyRequired('identity_cancel_scope_changed')
                if job['worker_done'].is_set():return 'already_finished'
                job.update(status='cancelled',phase='cancelled',error_code='cancelled',
                           error=_MESSAGES['cancelled'])
                scope=runtime.jobs.get(job['id'])
                if type(scope) is _IdentityScope and scope.job is job:
                    scope.user_cancelled=True
                    if scope.entry is not None and scope.entry.batch_scope is scope:
                        scope.entry.stop_requested=True
                        scope.entry.lifecycle_wake.set()
                        if scope.entry.transport is not None:scope.entry.transport.request_stop()
    _cancel_marker(job)
    return 'requested'


def identity_observation_status(service,user,account,*,job=None):
    core,server=service.server.core,service.server
    core._account_access(user,account)
    with server.job_lock:
        jobs=[item for item in ([job] if job is not None else server.jobs.values()) if type(item) is dict
              and server.jobs.get(item.get('id')) is item and item.get('purpose')=='identity_observation'
              and item.get('kind')=='assistant_account_login' and item.get('mode')=='browser'
              and item.get('account_id')==account['id'] and item.get('owner_id')==user['id']
              and item.get('tenant_id')==user['tenant_id']]
        if not jobs:return _view('unknown')
        job=jobs[-1]
        claim=job.get('_identity_claim')
    if type(claim) is not _IdentityWorkerClaim:return _view('unknown')
    claim.check()
    with server.job_lock:
        if not job['worker_done'].is_set():return _view('in_progress',job_id=job['id'])
        value=job.get('identity_observation')
        if type(value) is not dict or value.get('observation_state') not in _MESSAGES:
            return _view('unknown')
        identity=value.get('observed_identity')
        if identity is not None:
            if (type(identity) is not dict or set(identity)!={'id','nickname','guest'}
                    or identity.get('guest') is not False):return _view('unknown')
            identity=dict(identity)
        return _view(value['observation_state'],identity,value.get('observed_at'),job['id'])
