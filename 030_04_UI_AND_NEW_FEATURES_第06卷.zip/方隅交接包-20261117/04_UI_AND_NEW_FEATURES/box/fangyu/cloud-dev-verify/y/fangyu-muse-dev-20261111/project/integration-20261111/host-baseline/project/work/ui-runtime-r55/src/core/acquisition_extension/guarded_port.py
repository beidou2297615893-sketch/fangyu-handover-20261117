"""Auditable readonly command compiler; deliberately contains no CLI executor.

The trusted host must register each operation in the original dispatcher and
thread its existing ownership/identity/activity/hold gates through dispatch.
Only a host-verified ReadReceipt is accepted. This adapter never blesses raw
payload as belonging to an account just because it requested that account.
"""
from dataclasses import dataclass
import re
from urllib.parse import parse_qsl, urlsplit

from .contracts import ContractError, verify_receipt


@dataclass(frozen=True)
class ControlledCommand:
    verb: str
    args: tuple
    wire_path: str
    wire_query: tuple
    request_digest: str


def _text(value, maximum=2048, empty=False):
    if not isinstance(value,str) or len(value)>maximum or not empty and not value or any(ord(c)<32 or ord(c)==127 for c in value):
        raise ContractError('Invalid bounded command value')
    return value


def _id(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,159}',value):
        raise ContractError('Explicit stable identifier required')
    return value


def _note(value):
    _text(value)
    try:
        url=urlsplit(value)
        items=parse_qsl(url.query,keep_blank_values=True,strict_parsing=True)
        match=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]+)/?',url.path)
        if (url.scheme!='https' or url.hostname not in ('xiaohongshu.com','www.xiaohongshu.com')
                or url.username or url.password or url.port not in (None,443) or url.fragment
                or not match or len(items)>16 or len(dict(items))!=len(items)):
            raise ValueError()
        query=dict(items)
        token=_text(query.get('xsec_token',''))
        if any(not _text(k,64) or not _text(v) for k,v in items):raise ValueError()
        return match[1],token
    except (ValueError, TypeError):
        raise ContractError('Full official note URL with explicit access token required; no cache fallback') from None


def compile_xhs_read(scope, request):
    from dataclasses import replace
    return replace(compile_xhs_request(request, scope.platform), request_digest=request.digest(scope))


def compile_xhs_request(request, platform='xiaohongshu'):
    # Pure wire constraints only. This function grants no identity or permission.
    if platform!='xiaohongshu':raise ContractError('This compiler only accepts Xiaohongshu')
    op,p=request.operation,request.params
    shapes={'user_me':set(),'user_profile':{'user_id'},'user_posts':{'user_id','cursor'},'comments':{'note_url','cursor'},
        'sub_comments':{'note_url','root_comment_id','cursor'},'notifications':{'type','cursor','num'},'unread':set()}
    if op not in shapes or set(p)!=shapes[op]:raise ContractError('Readonly command shape not registered')
    cursor=_text(p.get('cursor',''),4096,empty=True)
    if op=='user_me':
        verb='whoami';args=('--json',);path='/api/sns/web/v2/user/me';query={}
    elif op=='user_profile':
        uid=_id(p['user_id']);verb='user';args=(uid,'--json');path='/api/sns/web/v1/user/otherinfo';query={'target_user_id':uid}
    elif op=='user_posts':
        uid=_id(p['user_id'])
        verb='user-posts';args=(uid,'--cursor='+cursor,'--json')
        path='/api/sns/web/v1/user_posted'
        query={'num':'30','cursor':cursor,'user_id':uid,'image_scenes':'FD_WM_WEBP'}
    elif op in ('comments','sub_comments'):
        note,token=_note(p['note_url'])
        query={'note_id':note,'cursor':cursor,'top_comment_id':'','image_formats':'jpg,webp,avif','xsec_token':token}
        if op=='comments':
            verb='comments';args=(p['note_url'],'--cursor='+cursor,'--json');path='/api/sns/web/v2/comment/page'
        else:
            root=_id(p['root_comment_id']);query.update(root_comment_id=root,num='30')
            verb='sub-comments';args=(note,root,'--cursor='+cursor,'--xsec-token='+token,'--json')
            path='/api/sns/web/v2/comment/sub/page'
    elif op=='notifications':
        if p['type'] not in ('mentions','likes','connections') or type(p['num']) is not int or not 1<=p['num']<=50:
            raise ContractError('Unknown notification type or page limit')
        verb='notifications';args=('--type='+p['type'],'--cursor='+cursor,'--num='+str(p['num']),'--json')
        path='/api/sns/web/v1/you/'+p['type'];query={'num':str(p['num']),'cursor':cursor}
    else:
        verb='unread';args=('--json',);path='/api/sns/web/unread_count';query={}
    return ControlledCommand(verb,args,path,tuple(sorted(query.items())), '')


class SinglePageWireGate:
    """Host installs this immediately before the original guarded wire request."""
    def __init__(self, command):
        self.command,self.used=command,False

    def __call__(self, method, url):
        if self.used:raise ContractError('One page cannot issue a second wire request or retry')
        try:
            parsed=urlsplit(url);items=parse_qsl(parsed.query,keep_blank_values=True,strict_parsing=True)
            valid=(method=='GET' and parsed.scheme=='https' and parsed.hostname=='edith.xiaohongshu.com'
                and parsed.port in (None,443) and not parsed.username and not parsed.password and not parsed.fragment
                and parsed.path==self.command.wire_path and len(items)==len(dict(items))
                and tuple(sorted(items))==self.command.wire_query)
        except (ValueError,TypeError):valid=False
        if not valid:raise ContractError('Wire destination or exact page parameters not approved')
        self.used=True


class GuardedCoreReadAdapter:
    def __init__(self, *, preflight, dispatch, registered_operations=()):
        self.preflight,self.dispatch=preflight,dispatch
        self.registered_operations=frozenset(registered_operations)

    def read(self, scope, request):
        command=compile_xhs_read(scope,request)
        if request.operation not in self.registered_operations:
            raise ContractError('Original guarded dispatcher operation is not integrated')
        if self.preflight(scope,request,command)!=scope.binding():
            raise ContractError('Original Core preflight did not confirm exact scope')
        receipt=self.dispatch(scope,request,command)
        if self.preflight(scope,request,command)!=scope.binding():
            raise ContractError('Identity or permission changed during platform read')
        verify_receipt(scope,request,receipt)
        return receipt
