"""Read the original company register through a frozen owned local origin.

No dispatch, refresh, tombstone, receipt write, or current business-state update.
Matching a register record is not proof of local dispatch or resource delivery.
"""
from copy import deepcopy
import math
import re

from core import CoreError
from .company_handoff_preparation import (CompanyHandoffPreparation, CompanyHandoffPreparationError,
    GET, CLOUD_ACTION, _hash, _raw, _json)

ACTION = 'company_handoff_original_status'
CLOUD_READ = 'acquisition_handoff_operation_status'
_MAX = 9007199254740991
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_IDENT = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_STATES = frozenset(('draft', 'submitted', 'accepted', 'rejected', 'needs_information',
    'duplicate_pending_review', 'existing_customer_pending_review', 'withdrawn', 'disputed'))
_ENVELOPE = frozenset(('operation_receipt', 'read_only', 'mutation_committed', 'auto_retry'))
_RECEIPT = frozenset(('contract', 'read_only', 'mutation_committed', 'storage_scope', 'authenticated_actor',
    'observed_at', 'operation_action', 'idempotency_key', 'state', 'original_execution_confirmed',
    'original_operation', 'current_handoff', 'auto_retry', 'platform_delivery_verified', 'settlement_active',
    'financial_receipt_verified', 'cooperation_policy_verified', 'verified_cash_cents', 'verified_paid_commission_cents'))
_ORIGINAL = frozenset(('payload_hash', 'channel_id', 'revision', 'historical_status', 'occurred_at',
    'historical_event_self_hash_verified', 'full_historical_chain_verified'))
_CURRENT = frozenset(('channel_id', 'revision', 'status', 'current_consent_valid',
    'historical_resource_receipt_recorded', 'receipt_evidence_independently_verified'))


class CompanyHandoffOriginalStatusError(CoreError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_ORIGINAL_STATUS_' + code
        self.status = status
        self.mutation_committed = False  # This query, never the original operation.


def _fail(code, message, status=400):
    raise CompanyHandoffOriginalStatusError(code, message, status)


def _exact(value, fields):
    if not isinstance(value, dict) or set(value) != fields:
        _fail('RECEIPT_INVALID', '公司原操作回执字段需核对，请保留原准备编号', 409)


def _integer(value, minimum=0):
    return type(value) is int and minimum <= value <= _MAX


class CompanyHandoffOriginalStatus:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access, cloud_read):
        if not callable(cloud_read):
            raise ValueError('原公司登记核对需要可信的无自动续期只读入口')
        self.core, self.tenant, self.owner, self.company = core, tenant, owner, company
        self.device_id, self._fixed_device = device_id, device_id
        self.scope_guard, self.cloud_read = scope_guard, cloud_read
        self.preparation = CompanyHandoffPreparation(core, tenant, owner, company, device_id=device_id,
            scope_guard=self._scope_ok, lead_access=lead_access)

    def _scope_ok(self):
        return self.device_id == self._fixed_device and self.scope_guard() is True

    def _scope(self):
        try:
            self.preparation._scope()
        except CompanyHandoffPreparationError:
            _fail('SCOPE_CHANGED', '员工、企业环境或设备范围已变化，请重新核对原公司登记', 409)

    def _historical_source(self, db, origin, state):
        """Check the original owned immutable event, not today's changed text."""
        try:
            row = db.execute('''SELECT e.*,a.acked_at FROM contact_events e
                LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
                WHERE e.event_id=? AND e.tenant_id=? AND e.cloud_owner=?''',
                (origin['source_event_id'], self.tenant, self.owner)).fetchone()
            if not row:
                raise ValueError('original owned source missing')
            import json
            event = json.loads(row['payload'])
            if (row['sequence'] != origin['source_sequence'] or row['payload_hash'] != origin['source_payload_hash']
                    or row['chain_hash'] != origin['source_chain_hash'] or row['kind'] != origin['source_event_kind']
                    or event.get('event_id') != origin['source_event_id'] or event.get('kind') != origin['source_event_kind']
                    or event.get('lead', {}).get('id') != state['item']['lead_id']
                    or event.get('reply', {}).get('id') != row['reply_id']
                    or not isinstance(row['reply_id'], str) or not row['reply_id']
                    or _raw(row['payload']) != origin['source_payload_hash'] or _hash(event) != origin['source_payload_hash']
                    or row['provisional'] != 0 or row['syncable'] != 1
                    or event.get('lead', {}).get('platform') != 'xiaohongshu'
                    or not _IDENT.fullmatch(event.get('lead', {}).get('author_id', ''))
                    or not _IDENT.fullmatch(event.get('lead', {}).get('comment_id', ''))
                    or not isinstance(event.get('lead', {}).get('text'), str) or not event['lead']['text'].strip()
                    or type(row['acked_at']) not in (int, float) or not math.isfinite(row['acked_at'])
                    or row['acked_at'] != origin['source_acked_at']):
                raise ValueError('original immutable source differs')
            receipt = self.core.contact_journal.receipt(self.tenant, self.owner, row['reply_id'], state['item']['lead_id'])
            entries = [entry for entry in receipt['events'] if entry['event_id'] == origin['source_event_id']]
            if (receipt.get('local_integrity') != 'ok' or len(entries) != 1
                    or entries[0].get('local_integrity') != 'ok' or entries[0].get('payload_hash') != origin['source_payload_hash']
                    or entries[0].get('chain_hash') != origin['source_chain_hash'] or entries[0].get('acked') is not True
                    or entries[0].get('acked_at') != origin['source_acked_at']):
                raise ValueError('original reply history differs')
            return _hash({'event': dict(row), 'receipt': receipt})
        except Exception:
            _fail('SOURCE_HISTORY_CONFLICT', '原不可变来源或本人完整联系历史需核对，未查询公司原操作', 409)

    def _snapshot(self, handoff_id, user):
        self._scope()
        try:
            public = self.preparation.execute(GET, {'handoff_id': handoff_id}, user)
            with self.core.lock, self.core.store.connect() as db:
                db.execute('BEGIN')
                state = self.preparation._read_state(db, handoff_id, user)
                origin = self.preparation._row(db, handoff_id)
                window = self.preparation._journal_state(db, state['lead'])
                current_public = self.preparation._result(state, window, origin, read_only=True)
                if public != current_public:
                    _fail('LOCAL_CHANGED', '原准备或本机来源读取期间已变化，请重新核对', 409)
                history = self._historical_source(db, origin, state) if origin else None
        except CompanyHandoffPreparationError as error:
            suffix = error.code.removeprefix('COMPANY_HANDOFF_PREPARATION_')
            _fail(suffix, '原准备、本人来源或当前权限需核对，未查询公司原操作', error.status)
        self._scope()
        return {'actor': state['actor'], 'origin': origin, 'current': public['current'],
            'fingerprint': _hash({'state': state['fingerprint'], 'window': window['hash'], 'origin': origin, 'history': history})}

    def _receipt(self, answer, origin):
        _exact(answer, _ENVELOPE)
        if answer['read_only'] is not True or answer['mutation_committed'] is not False or answer['auto_retry'] is not False:
            _fail('RECEIPT_INVALID', '本次公司核对不是可信纯读回执，请保留原编号', 409)
        receipt = answer['operation_receipt']
        _exact(receipt, _RECEIPT)
        if (receipt['contract'] != 'handoff_operation_receipt_v1' or receipt['read_only'] is not True
                or receipt['mutation_committed'] is not False or receipt['storage_scope'] != 'company_server_ledger'
                or receipt['authenticated_actor'] != self.owner or not _integer(receipt['observed_at'])
                or receipt['operation_action'] != CLOUD_ACTION or receipt['idempotency_key'] != origin['cloud_idempotency_key']
                or receipt['state'] not in ('recorded', 'unknown') or receipt['auto_retry'] is not False
                or any(receipt[field] is not False for field in ('platform_delivery_verified', 'settlement_active',
                    'financial_receipt_verified', 'cooperation_policy_verified'))
                or receipt['verified_cash_cents'] is not None or receipt['verified_paid_commission_cents'] is not None):
            _fail('RECEIPT_INVALID', '原公司登记的身份、范围或证据标志需核对，请保留原编号', 409)
        if receipt['state'] == 'unknown':
            if (receipt['original_execution_confirmed'] is not None or receipt['original_operation'] is not None
                    or receipt['current_handoff'] is not None):
                _fail('RECEIPT_INVALID', '未知原操作不能显示已登记或未执行，请保留原编号', 409)
            return deepcopy(receipt)
        original, current = receipt['original_operation'], receipt['current_handoff']
        _exact(original, _ORIGINAL)
        _exact(current, _CURRENT)
        if (receipt['original_execution_confirmed'] is not True
                or original['payload_hash'] != origin['cloud_payload_hash'] or not _HEX.fullmatch(original['payload_hash'])
                or original['channel_id'] != origin['expected_cloud_channel_id'] or type(original['revision']) is not int
                or original['revision'] != 1 or original['historical_status'] != 'draft'
                or not _integer(original['occurred_at']) or original['occurred_at'] > receipt['observed_at']
                or original['historical_event_self_hash_verified'] is not True or original['full_historical_chain_verified'] is not False
                or current['channel_id'] != origin['expected_cloud_channel_id'] or not _integer(current['revision'], 1)
                or current['status'] not in _STATES or type(current['current_consent_valid']) is not bool
                or type(current['historical_resource_receipt_recorded']) is not bool
                or current['receipt_evidence_independently_verified'] is not False
                or (current['status'] == 'withdrawn' and current['current_consent_valid'] is not False)):
            _fail('ORIGINAL_MISMATCH', '公司原登记与本机固定原准备不一致，未显示对应结果', 409)
        return deepcopy(receipt)

    def _result(self, snapshot, receipt=None):
        origin = snapshot['origin']
        state = receipt['state'] if receipt else 'no_origin'
        original = None
        if state == 'recorded':
            original = {key: value for key, value in receipt['original_operation'].items() if key != 'payload_hash'}
            original.update(operation_action=CLOUD_ACTION, execution_confirmed=True)
        return {'contract': 'company_handoff_original_status_v1', 'read_only': True, 'mutation_committed': False,
            'local_only': state == 'no_origin', 'storage_scope': 'local_bridge_company_server_ledger',
            'cross_machine_verified': False, 'cloud_read_requested': receipt is not None,
            'observed_at': receipt['observed_at'] if receipt else None, 'state': state,
            'origin': {'origin_id': origin['origin_id'], 'local_handoff_revision': origin['handoff_revision']} if origin else None,
            'current_local': deepcopy(snapshot['current']), 'original_operation': original,
            'current_company': deepcopy(receipt['current_handoff']) if receipt else None,
            'origin_binding_verified': state == 'recorded', 'source_cloud_binding_verified': False,
            'platform_delivery_verified': False, 'financial_receipt_verified': False, 'cooperation_policy_verified': False,
            'verified_cash_cents': None, 'verified_paid_commission_cents': None, 'settlement_active': False,
            'auto_retry': False, 'no_dispatch': True, 'no_dispatch_scope': 'this_status_query_only',
            'provider_requests_started': False, 'platform_requests_started': False,
            'contacts_modified': False, 'handoffs_modified': False, 'ratings_modified': False}

    def execute(self, action, data, user):
        if (action != ACTION or not isinstance(data, dict) or set(data) != {'handoff_id'}
                or not isinstance(data['handoff_id'], str) or not _HANDOFF.fullmatch(data['handoff_id'])):
            _fail('INVALID_INPUT', '原公司登记核对仅接受本人已有本机交接编号')
        try:
            before = self._snapshot(data['handoff_id'], user)
            receipt = None
            if before['origin']:
                self._scope()
                try:
                    answer = self.cloud_read(deepcopy(before['actor']), CLOUD_READ,
                        {'operation_action': CLOUD_ACTION, 'idempotency_key': before['origin']['cloud_idempotency_key']})
                except Exception as error:
                    if getattr(error, 'code', None) == 'COMPANY_HANDOFF_STATUS_SESSION_REQUIRED':
                        _fail('SESSION_REQUIRED', '当前公司会话需明确重新连接，请保留原准备编号后再核对', 409)
                    _fail('READ_UNAVAILABLE', '公司原操作暂不可读，请保留原准备编号；本次未重发', 503)
                receipt = self._receipt(answer, before['origin'])
            after = self._snapshot(data['handoff_id'], user)
            if after['fingerprint'] != before['fingerprint']:
                _fail('LOCAL_CHANGED', '原准备、当前授权或来源读取期间已变化，请重新核对', 409)
            self._scope()
            return self._result(after, receipt)
        except CompanyHandoffOriginalStatusError:
            raise
        except Exception:
            _fail('READ_UNAVAILABLE', '原准备对应的公司登记暂不可读，请保留原编号', 503)
