"""A single main/reply page per batch, with an opaque persisted continuation."""
import json
import re

def page_request(task):
    token=task.get('next_cursor')
    state=json.loads(token) if token else {'v':1,'main_cursor':'0','main_done':False,'replies':[]}
    if not isinstance(state,dict) or state.get('v')!=1 or not isinstance(state.get('replies'),list):
        raise ValueError('抖音分页断点格式无效')
    if not isinstance(state.get('main_done'),bool) or not re.fullmatch(r'\d{1,12}',str(state.get('main_cursor',''))):
        raise ValueError('抖音主评论断点无效')
    for reply in state['replies']:
        if not isinstance(reply,dict) or not re.fullmatch(r'\d{1,24}',str(reply.get('cid',''))) or not re.fullmatch(r'\d{1,12}',str(reply.get('cursor',''))):
            raise ValueError('抖音子评论断点无效')
    current=state['replies'][0] if state['replies'] else None
    return state, {'cursor':str(current['cursor']) if current else str(state['main_cursor']),
                   'parent':str(current['cid']) if current else ''}

def finish_page(state, request, payload, include_replies=True):
    if not isinstance(payload,dict) or not isinstance(payload.get('comments'),list) or not isinstance(payload.get('has_more'),bool):
        raise ValueError('抖音分页返回格式无效')
    more=payload['has_more'];cursor=str(payload.get('cursor',''))
    if more and (not re.fullmatch(r'\d{1,12}',cursor) or cursor==request['cursor']):
        raise ValueError('抖音分页游标未前进，已暂停')
    if request['parent']:
        if more: state['replies'][0]['cursor']=cursor
        else: state['replies'].pop(0)
    else:
        state['main_done']=not more
        if more: state['main_cursor']=cursor
        if include_replies:
            for item in payload['comments']:
                cid=str(item.get('cid',''))
                if int(item.get('reply_count',0))>0 and re.fullmatch(r'\d{1,24}',cid):
                    state['replies'].append({'cid':cid,'cursor':'0','text':str(item.get('text',''))})
    has_more=not state['main_done'] or bool(state['replies'])
    return {'has_more':has_more,'cursor':json.dumps(state,ensure_ascii=False,separators=(',',':')) if has_more else ''}
