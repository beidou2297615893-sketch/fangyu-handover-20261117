"""Manual GUI probe: synthetic HttpOnly cookie in an isolated WebView2.

Run only with ``--offline``. The page binds to 127.0.0.1 on a random port.
No real browser profile, website, JavaScript bridge, or remote debugger is used.
"""

from __future__ import annotations

import argparse
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import secrets
import tempfile
import threading

if __package__:
    from .auth_candidate import CandidateRejected, OwnedCookie, extract_scoped_cookies
    from .owned_webview2_cookies import read_owned_window_cookies
else:
    from auth_candidate import CandidateRejected, OwnedCookie, extract_scoped_cookies
    from owned_webview2_cookies import read_owned_window_cookies


HERE = Path(__file__).resolve().parent
PROBE_NAME = "__qa_session"
PAGE = b"<!doctype html><html lang='zh'><meta charset='utf-8'><title>Local WebView2 probe</title><body><h1>Local WebView2 cookie probe</h1><p>This window closes after a local readback.</p></body></html>"


def make_handler(token: str, persistent_token: str | None = None):
    class LocalPage(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802 - stdlib handler contract
            expected_host = f"127.0.0.1:{self.server.server_port}"
            if self.path != "/" or self.headers.get("Host") != expected_host:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(PAGE)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'none'")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Set-Cookie", f"{PROBE_NAME}={token}; Path=/; HttpOnly; SameSite=Strict")
            if persistent_token is not None:
                self.send_header("Set-Cookie", f"__qa_persistent={persistent_token}; Max-Age=600; Path=/; HttpOnly; SameSite=Strict")
            self.end_headers()
            self.wfile.write(PAGE)

        def log_message(self, *_args):
            # Never emit request headers, URLs, or Cookie values.
            return

    return LocalPage


def inspect_local_snapshot(raw: list[SimpleCookie | OwnedCookie], current_url: str,
                           expected_url: str, expected_token: str) -> bool:
    if current_url != expected_url:
        raise CandidateRejected("origin_mismatch")
    found = extract_scoped_cookies(
        raw, current_url=current_url, expected_host="127.0.0.1", scheme="http",
        allowed_names=frozenset({PROBE_NAME}), required_names=frozenset({PROBE_NAME}),
        allowed_cookie_domains=frozenset({"127.0.0.1"}),
    )
    matching = []
    for cookie in raw:
        if isinstance(cookie, OwnedCookie) and cookie.name == PROBE_NAME:
            matching.append(cookie.httponly)
        elif isinstance(cookie, SimpleCookie) and PROBE_NAME in cookie:
            matching.append(bool(cookie[PROBE_NAME]["httponly"]))
    if matching != [True]:
        raise CandidateRejected("httponly_missing")
    return secrets.compare_digest(found[PROBE_NAME], expected_token)


def run_offline() -> int:
    # Import lazily so static checks and unit tests cannot open a GUI.
    import webview

    token = secrets.token_urlsafe(24)
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(token))
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, name="local-probe-http", daemon=True)
    thread.start()
    expected_url = f"http://127.0.0.1:{server.server_port}/"
    result = {"code": "not_started"}

    try:
        with tempfile.TemporaryDirectory(prefix="webview2-probe-", dir=HERE,
                                         ignore_cleanup_errors=True) as temporary:
            profile = str(Path(temporary) / "profile")
            window = webview.create_window("Local WebView2 cookie probe", expected_url,
                                           width=600, height=360, js_api=None)

            def check():
                try:
                    if not window.events.loaded.wait(15):
                        result["code"] = "page_timeout"
                        return
                    current_url = window.get_current_url()
                    cookies = read_owned_window_cookies(
                        window, expected_url=expected_url,
                        allowed_names=frozenset({PROBE_NAME}), timeout_s=10,
                    )
                    result["code"] = (
                        "cookie_readback_ok" if inspect_local_snapshot(
                            cookies, current_url, expected_url, token,
                        ) else "cookie_value_mismatch"
                    )
                except CandidateRejected as exc:
                    result["code"] = exc.code
                except Exception:
                    result["code"] = "native_readback_failed"
                finally:
                    window.destroy()

            webview.start(check, gui="edgechromium", private_mode=True,
                          storage_path=profile, debug=False)
    except Exception:
        result["code"] = "gui_unavailable"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    # This is the entire output contract: no URL, profile path, Cookie or token.
    print(result["code"])
    return 0 if result["code"] == "cookie_readback_ok" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Offline local WebView2 HttpOnly cookie probe")
    parser.add_argument("--offline", action="store_true", help="run localhost-only GUI probe")
    args = parser.parse_args()
    if not args.offline:
        parser.error("explicit --offline is required")
    return run_offline()


if __name__ == "__main__":
    raise SystemExit(main())
