"""Durable, append-only contact evidence and a separately acknowledged sync outbox.

The event log shares the workspace database so a reply state and its evidence can
commit in one SQLite transaction. Device credentials never enter event payloads.
"""
import hashlib
import json
import re
import sqlite3
import time
from urllib.parse import parse_qsl, quote_plus, urlsplit, urlunsplit
from uuid import UUID, uuid4


KINDS=frozenset(('reviewed','send_started','sent','failed','unknown','copied','external_reported'))
LEAD_FIELDS=('id','platform','author_id','author','text','note_url','author_avatar_url',
             'task_id','comment_id','parent_id','source_keyword')
REPLY_FIELDS=('id','text')
SENDER_FIELDS=('account_id','nickname')
PLATFORM_ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
INTENT_FIELDS=('source','status','level','reason','assessed_at','rules_version')
INTENT_LEVELS=frozenset(('super_high','high','medium','low','very_low'))
INTENT_STATUSES=frozenset(('graded','uncertain','unrelated'))


def _intent_snapshot(lead):
    """Capture the existing judgement when a new event is made; never infer old history."""
    manual=lead.get('manual_intent')
    ai=lead.get('ai_intent')
    source='manual' if isinstance(manual,dict) else 'ai' if isinstance(ai,dict) else 'none'
    value=manual if source=='manual' else ai if source=='ai' else {}
    status=value.get('status') if isinstance(value,dict) else None
    level=value.get('level') if isinstance(value,dict) else None
    if status not in INTENT_STATUSES or (status=='graded' and level not in INTENT_LEVELS) or (status!='graded' and level is not None):
        source,status,level='none','pending',None
        value={}
    def clean(key,limit):
        raw=value.get(key,'')
        return raw[:limit] if isinstance(raw,str) else ''
    return {'source':source,'status':status,'level':level,'reason':clean('reason',500),
            'assessed_at':clean('updated_at' if source=='manual' else 'analyzed_at',64),
            'rules_version':clean('rules_version',80) if source=='ai' else ''}


def _public_url(value,avatar=False):
    if not isinstance(value,str) or len(value)>1000:return ''
    try:
        parsed=urlsplit(value)
        port=parsed.port
    except ValueError:return ''
    if (parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password
            or port is not None):return ''
    host=parsed.hostname.lower()
    roots=('xhscdn.com',) if avatar else ('xiaohongshu.com','xhslink.com')
    if not any(host==root or host.endswith('.'+root) for root in roots):return ''
    if avatar and any(key.lower() in ('cookie','authorization','password','secret','api_key','apikey')
                      for key,_ in parse_qsl(parsed.query,keep_blank_values=True)):return ''
    parts={}
    for key,part in parse_qsl(parsed.query,keep_blank_values=True):parts.setdefault(key,part)
    def encode(part):return quote_plus(part,safe='*').replace('~','%7E')
    query=parsed.query if avatar else '&'.join(f'{encode(key)}={encode(parts[key])}'
        for key in ('xsec_token','xsec_source') if parts.get(key) and len(parts[key])<=500)
    result=urlunsplit((parsed.scheme,parsed.netloc.lower(),parsed.path,query,''))
    return result if len(result)<=1000 else ''


def contact_event(kind, lead, reply, account=None, *, occurred_at=None, event_id=None):
    if kind not in KINDS:raise ValueError('Invalid contact event kind')
    if event_id is None:event_id=str(uuid4())
    UUID(event_id)
    account=account or {}
    safe_lead={key:str(lead.get(key) or '') for key in LEAD_FIELDS}
    safe_lead['note_url']=_public_url(safe_lead['note_url'])
    safe_lead['author_avatar_url']=_public_url(safe_lead['author_avatar_url'],avatar=True)
    safe_reply={key:str(reply.get(key) or '') for key in REPLY_FIELDS}
    safe_sender={'account_id':str(account.get('id') or reply.get('account_id') or ''),
                 'nickname':str(account.get('nickname') or account.get('name') or '')}
    if kind=='sent':
        platform_reply_id=str(reply.get('platform_reply_id') or '').strip()
        platform_uid=str(account.get('platform_uid') or '').strip()
        if isinstance(platform_reply_id,str) and PLATFORM_ID.fullmatch(platform_reply_id):
            safe_reply['platform_reply_id']=platform_reply_id
        if isinstance(platform_uid,str) and PLATFORM_ID.fullmatch(platform_uid):
            safe_sender['platform_uid']=platform_uid
    if kind in ('send_started','sent') and reply.get('followup_target_id'):
        preparation=reply.get('followup_send_preparation')
        if (not isinstance(preparation,dict) or set(preparation)!={'schema','attemptId','requestDigest','bindingDigest'}
                or preparation.get('schema')!='fangyu_followup_send_preparation_v1'
                or not isinstance(preparation.get('attemptId'),str) or not re.fullmatch('[a-f0-9]{32}',preparation['attemptId'])
                or any(not isinstance(preparation.get(key),str) or not re.fullmatch('[a-f0-9]{64}',preparation[key]) for key in ('requestDigest','bindingDigest'))):
            raise ValueError('Missing followup prebound transport evidence')
        if kind=='sent':
            receipt=reply.get('reviewed_transport_receipt') or {}
            if any(receipt.get(key)!=preparation[key] for key in ('attemptId','requestDigest')):
                raise ValueError('Followup transport result differs from prepared attempt')
        safe_reply['followup_attempt_id']=preparation['attemptId']
        safe_reply['followup_request_digest']=preparation['requestDigest']
    return {'event_id':event_id,'kind':kind,'occurred_at':int(time.time() if occurred_at is None else occurred_at),
            'lead':safe_lead,
            'reply':safe_reply,
            'sender':safe_sender,
            'intent_snapshot':_intent_snapshot(lead)}


class ContactJournal:
    def __init__(self,store):
        self.store=store
        with store.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS contact_events(
                  sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                  event_id TEXT NOT NULL UNIQUE,
                  reply_id TEXT NOT NULL,
                  kind TEXT NOT NULL,
                  tenant_id TEXT NOT NULL,
                  cloud_owner TEXT NOT NULL,
                  provisional INTEGER NOT NULL,
                  syncable INTEGER NOT NULL,
                  payload TEXT NOT NULL,
                  payload_hash TEXT NOT NULL,
                  previous_hash TEXT NOT NULL,
                  chain_hash TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS contact_events_scope ON contact_events(tenant_id,cloud_owner,sequence);
                CREATE INDEX IF NOT EXISTS contact_events_reply ON contact_events(reply_id,kind);
                CREATE TABLE IF NOT EXISTS contact_event_acks(
                  event_id TEXT PRIMARY KEY REFERENCES contact_events(event_id),
                  acked_at REAL NOT NULL);
                CREATE TRIGGER IF NOT EXISTS contact_events_no_update BEFORE UPDATE ON contact_events
                  BEGIN SELECT RAISE(ABORT,'contact events are append only'); END;
                CREATE TRIGGER IF NOT EXISTS contact_events_no_delete BEFORE DELETE ON contact_events
                  BEGIN SELECT RAISE(ABORT,'contact events are append only'); END;
            ''')

    def append(self,event,tenant_id,cloud_owner,records=()):
        if (not isinstance(tenant_id,str) or not tenant_id or
                not isinstance(cloud_owner,str)):
            raise ValueError('Invalid contact scope')
        if event.get('kind') not in KINDS:raise ValueError('Invalid contact event kind')
        event_id=str(UUID(event['event_id']))
        if event_id!=event['event_id']:raise ValueError('Noncanonical contact event ID')
        fields={'event_id','kind','occurred_at','lead','reply','sender'}
        if set(event) not in (fields,fields|{'intent_snapshot'}):raise ValueError('Invalid contact event fields')
        for name,fields in (('lead',LEAD_FIELDS),('reply',REPLY_FIELDS),('sender',SENDER_FIELDS)):
            allowed=set(fields)
            optional={'platform_reply_id','followup_attempt_id','followup_request_digest'} if name=='reply' else {'platform_uid'} if name=='sender' else set()
            actual=event.get(name)
            if (not isinstance(actual,dict) or not allowed.issubset(actual) or
                    not set(actual).issubset(allowed|optional) or
                    (event['kind']!='sent' and set(actual)!=allowed and not (name=='reply' and event['kind']=='send_started' and set(actual)==allowed|{'followup_attempt_id','followup_request_digest'}))):
                raise ValueError('Invalid contact snapshot')
            if any(not isinstance(actual[key],str) or not PLATFORM_ID.fullmatch(actual[key])
                   for key in optional if key in actual):raise ValueError('Invalid platform evidence')
        reply=event['reply']
        if 'followup_attempt_id' in reply or 'followup_request_digest' in reply:
            if event['kind'] not in ('send_started','sent') or not re.fullmatch('[a-f0-9]{32}',reply.get('followup_attempt_id','')) or not re.fullmatch('[a-f0-9]{64}',reply.get('followup_request_digest','')):
                raise ValueError('Invalid followup transport evidence')
        intent=event.get('intent_snapshot')
        if intent is not None:
            if not isinstance(intent,dict) or set(intent)!=set(INTENT_FIELDS):raise ValueError('Invalid contact intent snapshot')
            if intent['source'] not in ('none','manual','ai') or intent['status'] not in (INTENT_STATUSES|{'pending'}):
                raise ValueError('Invalid contact intent snapshot')
            if (intent['source']=='none')!=(intent['status']=='pending'):
                raise ValueError('Invalid contact intent snapshot')
            if (intent['status']=='graded' and intent['level'] not in INTENT_LEVELS or
                    intent['status']!='graded' and intent['level'] is not None):raise ValueError('Invalid contact intent snapshot')
            if any(not isinstance(intent[key],str) or len(intent[key])>limit for key,limit in
                   (('reason',500),('assessed_at',64),('rules_version',80))):raise ValueError('Invalid contact intent snapshot')
        if not event['lead']['id'] or not event['reply']['id']:raise ValueError('Contact identity missing')
        payload=json.dumps(event,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
        payload_hash=hashlib.sha256(payload.encode('utf-8')).hexdigest()
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            prior=db.execute('SELECT tenant_id,cloud_owner,payload FROM contact_events WHERE event_id=?',(event_id,)).fetchone()
            if prior:
                if (prior['tenant_id'],prior['cloud_owner'],prior['payload'])!=(tenant_id,cloud_owner,payload):
                    raise ValueError('Contact event ID collision')
                if records:raise ValueError('Duplicate contact event cannot change records')
                return False
            if event['kind']=='sent' and 'followup_attempt_id' in event['reply']:
                rows=db.execute('SELECT kind,payload FROM contact_events WHERE tenant_id=? AND cloud_owner=? AND reply_id=? ORDER BY sequence DESC',
                    (tenant_id,cloud_owner,event['reply']['id'])).fetchall()
                start=next((row for row in rows if row['kind'] in ('send_started','sent','failed','unknown','external_reported')),None)
                prior=json.loads(start['payload']) if start and start['kind']=='send_started' else None
                if (not prior or any(prior['reply'].get(key)!=event['reply'].get(key) for key in ('id','text','followup_attempt_id','followup_request_digest'))
                        or prior.get('lead')!=event.get('lead') or prior['sender'].get('account_id')!=event['sender'].get('account_id')):
                    raise ValueError('Followup success lacks the exact paired prepared start')
            last=db.execute('SELECT chain_hash FROM contact_events ORDER BY sequence DESC LIMIT 1').fetchone()
            previous=last['chain_hash'] if last else '0'*64
            chain=hashlib.sha256((previous+'\n'+tenant_id+'\n'+cloud_owner+'\n'+event_id+'\n'+payload_hash).encode()).hexdigest()
            provisional=int(not bool(event['lead']['author_id']))
            syncable=int(event['lead']['platform']=='xiaohongshu' and
                         bool(event['lead']['author_id'] or event['lead']['comment_id']))
            db.execute('INSERT INTO contact_events(event_id,reply_id,kind,tenant_id,cloud_owner,provisional,syncable,payload,payload_hash,previous_hash,chain_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                       (event_id,event['reply']['id'],event['kind'],tenant_id,cloud_owner,provisional,syncable,payload,payload_hash,previous,chain))
            for entity,record in records:
                if entity not in ('replies','leads','accounts','tasks','audit','reply_trial_attempts') or record.get('tenant_id')!=tenant_id:
                    raise ValueError('Contact record scope mismatch')
                db.execute('INSERT OR REPLACE INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                           (entity,record['id'],tenant_id,json.dumps(record,ensure_ascii=False)))
        return True

    def pending(self,tenant_id,cloud_owner,limit=20):
        if not tenant_id or not cloud_owner:raise ValueError('Contact sync scope missing')
        limit=min(20,max(1,int(limit)))
        with self.store.connect() as db:
            rows=db.execute('''SELECT e.payload FROM contact_events e
              LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
              WHERE e.tenant_id=? AND e.cloud_owner=? AND e.syncable=1 AND a.event_id IS NULL
              ORDER BY e.sequence LIMIT ?''',(tenant_id,cloud_owner,limit)).fetchall()
        return [json.loads(row['payload']) for row in rows]

    def acknowledge(self,tenant_id,cloud_owner,event_ids):
        if not tenant_id or not cloud_owner:raise ValueError('Contact sync scope missing')
        with self.store.connect() as db:
            for event_id in set(event_ids):
                row=db.execute('SELECT 1 FROM contact_events WHERE event_id=? AND tenant_id=? AND cloud_owner=?',
                               (event_id,tenant_id,cloud_owner)).fetchone()
                if row:db.execute('INSERT OR IGNORE INTO contact_event_acks VALUES(?,?)',(event_id,time.time()))

    def is_uploaded(self,tenant_id,cloud_owner,event_id):
        with self.store.connect() as db:
            row=db.execute('''SELECT 1 FROM contact_events e JOIN contact_event_acks a
                ON a.event_id=e.event_id WHERE e.tenant_id=? AND e.cloud_owner=?
                AND e.event_id=? AND e.kind='sent' ''',(tenant_id,cloud_owner,event_id)).fetchone()
        return bool(row)

    def status(self,tenant_id,cloud_owner):
        with self.store.connect() as db:
            row=db.execute('''SELECT COUNT(*) AS total,
              SUM(CASE WHEN a.event_id IS NULL THEN 1 ELSE 0 END) AS unsynced,
              SUM(CASE WHEN e.syncable=0 THEN 1 ELSE 0 END) AS needs_identity
              FROM contact_events e LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
              WHERE e.tenant_id=? AND e.cloud_owner=?''',(tenant_id,cloud_owner)).fetchone()
        return {'total':row['total'],'unsynced':row['unsynced'] or 0,
                'needs_identity':row['needs_identity'] or 0}

    def receipt(self,tenant_id,cloud_owner,reply_id,lead_id):
        """Read only local evidence; an upload ACK is never a cloud verification."""
        if not all(isinstance(value,str) and value for value in (tenant_id,cloud_owner,reply_id,lead_id)):
            raise ValueError('Contact receipt scope missing')
        with self.store.connect() as db:
            rows=db.execute('''SELECT e.sequence,e.event_id,e.reply_id,e.kind,e.tenant_id,e.cloud_owner,
              e.payload,e.payload_hash,e.previous_hash,e.chain_hash,a.acked_at
              FROM contact_events e LEFT JOIN contact_event_acks a ON a.event_id=e.event_id
              WHERE e.tenant_id=? AND e.cloud_owner=? AND e.reply_id=? ORDER BY e.sequence''',
              (tenant_id,cloud_owner,reply_id)).fetchall()
            events=[]
            for row in rows:
                payload=json.loads(row['payload'])
                if payload.get('lead',{}).get('id')!=lead_id or payload.get('reply',{}).get('id')!=reply_id:
                    raise ValueError('Contact receipt identity mismatch')
                earlier=db.execute('SELECT chain_hash FROM contact_events WHERE sequence<? ORDER BY sequence DESC LIMIT 1',
                                   (row['sequence'],)).fetchone()
                previous=earlier['chain_hash'] if earlier else '0'*64
                payload_hash=hashlib.sha256(row['payload'].encode('utf-8')).hexdigest()
                chain=hashlib.sha256((row['previous_hash']+'\n'+tenant_id+'\n'+cloud_owner+'\n'+row['event_id']+'\n'+row['payload_hash']).encode()).hexdigest()
                intact=(payload_hash==row['payload_hash'] and previous==row['previous_hash']
                        and chain==row['chain_hash'] and payload.get('event_id')==row['event_id']
                        and payload.get('kind')==row['kind'])
                events.append({'event_id':row['event_id'],'kind':row['kind'],
                               'occurred_at':payload.get('occurred_at'),
                               'payload_hash':row['payload_hash'],'chain_hash':row['chain_hash'],
                               'local_integrity':'ok' if intact else 'mismatch',
                               'acked':row['acked_at'] is not None,'acked_at':row['acked_at']})
        sent=next((item for item in reversed(events) if item['kind']=='sent' and item['local_integrity']=='ok'),None)
        terminal=next((item['kind'] for item in reversed(events) if item['kind'] in
                       ('sent','failed','unknown','external_reported')),None)
        return {'reply_id':reply_id,'lead_id':lead_id,'events':events,
                'local_sent_event_id':sent['event_id'] if sent else '',
                'local_outcome':terminal or 'none',
                'upload_state':'not_recorded' if not events else
                               'uploaded' if all(item['acked'] for item in events) else 'pending_upload',
                'local_integrity':'not_recorded' if not events else
                                  'ok' if all(item['local_integrity']=='ok' for item in events) else 'mismatch',
                'cloud_verified':False}

    def sent_snapshot(self,tenant_id,cloud_owner,event_id,reply_id,lead_id):
        """Return an intact scoped sent payload for a newly observed response."""
        receipt=self.receipt(tenant_id,cloud_owner,reply_id,lead_id)
        if (receipt['local_integrity']!='ok' or receipt['local_sent_event_id']!=event_id or
                receipt['local_outcome']!='sent'):
            return None
        with self.store.connect() as db:
            row=db.execute('''SELECT payload FROM contact_events WHERE event_id=? AND tenant_id=?
                AND cloud_owner=? AND reply_id=? AND kind='sent' ''',
                (event_id,tenant_id,cloud_owner,reply_id)).fetchone()
        return json.loads(row['payload']) if row else None

    def unfinished_attempts(self):
        """Return starts lacking a terminal event, for restart reconciliation."""
        with self.store.connect() as db:
            rows=db.execute('''SELECT s.tenant_id,s.cloud_owner,s.payload FROM contact_events s
              WHERE s.kind='send_started' AND NOT EXISTS (
                SELECT 1 FROM contact_events t WHERE t.reply_id=s.reply_id
                AND t.sequence>s.sequence AND t.kind IN ('sent','failed','unknown'))
              ORDER BY s.sequence''').fetchall()
        return [(row['tenant_id'],row['cloud_owner'],json.loads(row['payload'])) for row in rows]
