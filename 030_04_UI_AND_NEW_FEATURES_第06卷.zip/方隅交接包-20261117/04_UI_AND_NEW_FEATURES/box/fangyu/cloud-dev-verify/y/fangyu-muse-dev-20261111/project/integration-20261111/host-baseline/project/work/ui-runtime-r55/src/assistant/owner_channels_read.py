"""Owner v2 single local channel preview. Connection is never WeChat identity.

Only a separately reviewed fixed instance purpose may start local GET. Old
XHS/Dy/component decisions are not a grant. Metadata/cancel never lend it.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import stat
import threading
from urllib.parse import parse_qs, urlsplit

from .self_operating_read import OwnerReadWorkspace

_SEAL=object()
PURPOSE='owner_channels_single_local_session_preview_v1'
_FILE='owner-channels-preview-review.json'
_REQUEST=re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{7,127}')
_ID=re.compile(r'[A-Za-z0-9][A-Za-z0-9:_-]{0,255}')
_SHA=re.compile(r'[a-f0-9]{64}')
_REF=re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}')
_SOURCE_FILES=('assistant/owner_channels_read.py','wechat_channels_connection.py',
    'core/wechat_channels.py','core/platform_reads.py','assistant/self_operating_read.py',
    'web/workspace/self-operating-read.mjs')
_FALSE=('authenticated','verified','identity_verified','account_ready',
        'account_isolation','archive_available','auto_retry','platform_writes',
        'real_platform_verified','external_tool_started','external_binary_verified',
        'production_distribution_approved')
_REVIEW_FIELDS={'schema','purpose','company_id','instance_id','actor_digest','account_id',
    'port','source_revision','route','usage_scope','page','limit','decision','revision',
    'reviewer_ref',*_FALSE}


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
        separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def _endpoint(port):
    if type(port) is not int or not 1024<=port<=65535:
        raise ValueError('请明确填写已经自行运行的本机服务整数端口；不探测或猜测端口')
    return 'http://127.0.0.1:'+str(port)


def _port(endpoint):
    if type(endpoint) is not str:raise ValueError('本机服务地址待核对')
    parsed=urlsplit(endpoint)
    try:port=parsed.port
    except ValueError:raise ValueError('本机服务端口待核对') from None
    if endpoint!=_endpoint(port):raise ValueError('只允许 exact 127.0.0.1 整数端口，无附加路径或凭据')
    return port


def _actor_identity(user):
    return {k:user.get(k) for k in ('id','tenant_id','username','role','personal_owner','cloud_bound')}


def _binding(user,account,instance):
    return {'actor':_actor_identity(user),'instance_id':instance,'account_id':account['id'],
        'platform':'wechat_channels','saved_uid':account.get('platform_uid'),
        'connection':account.get('conn_id'),'endpoint':account.get('endpoint'),
        'bound_client':account.get('bound_client_id'),
        'confirmation':deepcopy(account.get('owner_channels_preview'))}


def _cleanup_binding(binding):
    # Execution values may change while a blocked original call still owns its
    # cleanup. Stable scope never authorizes its result body or another GET.
    if (type(binding) is not dict or set(binding)!={'actor','instance_id','account_id',
            'platform','saved_uid','connection','endpoint','bound_client','confirmation'}):
        raise ValueError('原请求范围结构待核对')
    return {key:deepcopy(binding[key]) for key in
            ('actor','instance_id','account_id','platform','confirmation')}


def _require_feed_success(payload):
    # bool is an int subclass; False must not become a successful empty page.
    if type(payload) is not dict or type(payload.get('code')) is not int or payload['code']!=0:
        raise ValueError('视频号读取响应须明确返回整数成功码；未知包不能视作空页')


def _duplicates(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('本机用途或配置有重复字段')
        result[key]=value
    return result


def source_revision():
    # Exactly six known source files. No runtime/tree inventory or old materials.
    from core.runtime_license_policy import _plain
    root=Path(__file__).parent.parent
    return _digest({name:hashlib.sha256(_plain(root/name,root).read_bytes()).hexdigest()
                    for name in _SOURCE_FILES})


def validate_review(value,company,instance,actor,account,port,revision):
    """Pure schema check. A digest is not reviewer authentication or consent."""
    if type(value) is not dict or set(value)!=_REVIEW_FIELDS:
        raise ValueError('视频号本机预览用途默认待审')
    if (value['schema']!='owner_channels_preview_review_v1' or value['purpose']!=PURPOSE
            or value['company_id']!=company or value['instance_id']!=instance
            or value['actor_digest']!=actor or value['account_id']!=account
            or type(value['port']) is not int or value['port']!=port
            or not _SHA.fullmatch(str(value['source_revision'])) or value['source_revision']!=revision
            or value['route']!='wx_channel_loopback_http_v1'
            or value['usage_scope']!='internal_owner_local_session_preview'
            or type(value['page']) is not int or value['page']!=1
            or type(value['limit']) is not int or value['limit']!=20
            or value['decision']!='approved'
            or type(value['revision']) is not str or not _REF.fullmatch(value['revision'])
            or type(value['reviewer_ref']) is not str or not _REF.fullmatch(value['reviewer_ref'])
            or value['revision'].startswith('recorded-mainflow-')
            or value['reviewer_ref'].startswith('synthetic-')
            or any(value[name] is not False for name in _FALSE)):
        raise ValueError('视频号用途实例、本人、端口、源码或未知身份边界不一致')
    _endpoint(port)
    return value


def validate_status(payload,bound='',capability=None):
    from wechat_channels_connection import status_clients
    # The old projection truncates remote_addr. Owner compares the original full
    # value first; two long values must never collide after truncation.
    if type(payload) is not dict or type(payload.get('code')) is not int:
        raise ValueError('视频号本机状态协议待核对')
    data=payload.get('data')
    if type(data) is not dict or type(data.get('client_list')) is not list:
        raise ValueError('本机页面列表待核对')
    for item in data['client_list']:
        if (type(item) is not dict or type(item.get('remote_addr')) is not str
                or not 1<=len(item['remote_addr'])<=256
                or any(ord(c)<32 or ord(c)==127 for c in item['remote_addr'])):
            raise ValueError('临时页面连接标识无效或过长')
    clients=status_clients(payload)
    if bound or capability:
        if len(clients)!=1:raise ValueError('须保持唯一原视频号页面；健康不代表本人身份')
        raw=data['client_list'][0]
        if bound and raw['remote_addr']!=bound:raise ValueError('原临时页面连接已变化')
        if raw.get('fresh') is not True or raw.get('api_ready') is not True:
            raise ValueError('原视频号页面连接尚未就绪')
        if capability and raw.get('supports_'+capability) is not True:
            raise ValueError('当前页面不支持指定读取接口')
    return clients


def _plain_home(path,root):
    path,root=Path(path),Path(root)
    current=root
    for part in ('',*path.relative_to(root).parts):
        if part:current/=part
        try:info=current.lstat()
        except FileNotFoundError:continue
        if (current.is_symlink() or not stat.S_ISDIR(info.st_mode)
                or getattr(info,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
            raise ValueError('本人账号 HOME 不能使用链接或重定向')
    return path


def _plain_config(path):
    try:info=path.lstat()
    except FileNotFoundError:return
    if (path.is_symlink() or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1
            or getattr(info,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
        raise ValueError('本机配置不能使用链接、共享文件或重定向')


class OwnerChannelsRead:
    ACTIONS=frozenset(('owner_channels_account_create','owner_channels_configure',
        'owner_channels_check','owner_channels_comments','owner_channels_status','owner_channels_cancel'))

    def __init__(self,workspace):
        if type(workspace) is not OwnerReadWorkspace:raise ValueError('视频号只由可信 owner v2 实例创建')
        self.workspace=workspace
        self.scope=_OwnerChannelsScope(workspace,_SEAL)

    def read_service_options(self):return {'owner_channels_preview_scope':self.scope}

    def bind_read_service(self,reads):
        from core.platform_reads import PlatformReadService
        if (type(reads) is not PlatformReadService or reads.core is not self.scope.core
                or reads._owner_channels_preview_scope is not self.scope
                or self.workspace._reads is not reads or self.scope.reads is not None):
            raise ValueError('视频号须绑定当前本人原 Reads')
        self.scope.reads=reads

    def describe(self,user=None):
        status='pending';account_id='';port=None
        if user is not None:
            # Local fixed purpose metadata only. No platform probe/grant and
            # never treat a connection as authoritative account identity.
            try:
                from core.runtime_license_policy import _plain
                raw=_plain(self.scope.instance.directory/_FILE,self.scope.instance.work_root).read_bytes()
                if len(raw)>65536:raise ValueError('用途过大')
                value=json.loads(raw.decode('utf-8'),object_pairs_hook=_duplicates)
                account=self.scope.account(user,value.get('account_id'))
                self.scope.review(user,account,value.get('port'))
                status='reviewed';account_id=account['id'];port=value['port']
            except (ValueError,OSError,UnicodeError,TypeError,KeyError):pass
        return {'purpose':PURPOSE,'status':status,'page':1,'limit':20,
            'reviewed_account_id':account_id,'reviewed_port':port,
            'owner_v2_required':True,'port_required':True,'platform_requests_started':False,
            **{name:False for name in _FALSE}}

    def _entry(self,request,user,account,*,cleanup=False):
        reads=self.scope.reads
        if reads is None:raise ValueError('视频号原读取服务尚未接线')
        entry=reads._operations.get(request)
        if entry is not None:
            stored=entry.get('_owner_channels_binding')
            current=_binding(user,account,self.scope.instance_id())
            same=(_cleanup_binding(stored)==_cleanup_binding(current) if cleanup else stored==current)
            if (entry.get('_owner_channels') is not True or entry.get('account_id')!=account['id'] or not same):
                raise ValueError('原编号不属于当前本人、实例与原确认来源')
        return entry

    def _metadata(self,request,entry):
        state=('unknown' if entry is None else 'cleanup_pending' if entry.get('running') and entry.get('cancelled')
            else 'running' if entry.get('running') else 'cancelled' if entry.get('cancelled')
            else 'completed' if entry.get('response',{}).get('code')=='completed' else 'held')
        return {'purpose':PURPOSE,'request_id':request,'state':state,
            'cleanup_confirmed':False if entry is None else not entry.get('running',False),
            'cleanup_evidence':'same_local_call_finally_only','platform_requests_started':False,
            'result_available':False,'result':None,**{name:False for name in _FALSE}}

    def _result(self,result,request):
        if (type(result) is not dict or result.get('platform')!='wechat_channels'
                or result.get('action')!='comments' or type(result.get('items')) is not list
                or len(result['items'])>20 or any(result.get(k) is not False for k in
                    ('archive_available','platform_writes','real_platform_verified'))):
            raise ValueError('视频号预览返回范围待核对')
        output={'purpose':PURPOSE,'request_id':request,'state':'completed' if result['code']=='completed'
            else 'cancelled' if result['code']=='cancelled' else 'held','code':result['code'],
            'message':result['message'],'operation_id':result['operation_id'],
            'items':deepcopy(result['items']),'observed_count':0,'displayed_count':0,
            'requested_limit':result.get('requested_limit',20),'limit_exceeded':False,
            'source_verification':'transport_reported_only','page':{'has_more':None,'pagination_verified':False},
            **{name:False for name in _FALSE}}
        if output['state']=='completed':
            observed=result.get('observed_count');shown=result.get('displayed_count');limit=result.get('requested_limit')
            if (type(observed) is not int or not 0<=observed<=1000 or type(shown) is not int
                    or shown!=len(output['items']) or type(limit) is not int or not 1<=limit<=20
                    or not 0<=shown<=min(observed,limit) or result.get('limit_exceeded') is not (observed>limit)
                    or result.get('purpose')!=PURPOSE):raise ValueError('实际观察数量与显示数量不一致')
            output.update(observed_count=observed,displayed_count=shown,requested_limit=limit,
                limit_exceeded=observed>limit)
        return output

    def execute(self,token,action,data):
        if action not in self.ACTIONS or type(data) is not dict:raise ValueError('视频号仅开放固定本机预览动作')
        user=self.workspace._actor(token);self.scope.require_v2()
        if action=='owner_channels_account_create':
            if (set(data)!={'name','acknowledge_self_use','acknowledge_single_session'}
                    or type(data['name']) is not str or not 1<=len(data['name'].strip())<=80
                    or data['acknowledge_self_use'] is not True or data['acknowledge_single_session'] is not True):
                raise ValueError('请记录本人有权使用的单一微信页面；这不验证微信身份')
            with self.scope.core.lock:
                if self.workspace._actor(token)!=user:raise ValueError('本人身份已变化')
                # Original Core._save retains entitlement/account limit/single
                # global WeChat account restriction; no direct Store bypass.
                account=self.scope.core.handle('save',{'entity':'accounts','record':{
                    'name':data['name'].strip(),'platform':'wechat_channels','platform_uid':'',
                    'status':'unverified','cloud_owner':user['username'],'owner_channels_preview':{
                        'schema':'local_owner_channels_preview_v1','instance_id':self.scope.instance_id(),
                        'actor_digest':_digest(_actor_identity(user)),'self_use_confirmed':True,
                        'single_session_confirmed':True,'identity_verified':False}}},user)
            return {'purpose':PURPOSE,'account_id':account['id'],'name':account['name'],
                'status':'unverified','message':'已保存本人使用确认；微信身份仍未核实',**{name:False for name in _FALSE}}
        required={'account_id'}
        if action=='owner_channels_configure':required|={'port','acknowledge_self_use','acknowledge_single_session'}
        if action in ('owner_channels_comments','owner_channels_status','owner_channels_cancel'):required|={'request_id'}
        if action=='owner_channels_comments':required|={'reference','page','limit'}
        if set(data)!=required:raise ValueError('视频号不接命令、目录、身份、scope、UID、客户端或审批参数')
        account=self.scope.account(user,data['account_id'],cleanup=action in ('owner_channels_status','owner_channels_cancel'))
        if action in ('owner_channels_status','owner_channels_cancel'):
            request=data['request_id']
            if type(request) is not str or not _REQUEST.fullmatch(request):raise ValueError('请使用原请求编号')
            with self.scope.reads._lock:
                entry=self._entry(request,user,account,cleanup=True)
                if action=='owner_channels_cancel':
                    result=self.scope.reads.execute('platform_read_cancel',data,self.scope.core._public(user))
                    entry=self.scope.reads._operations.get(request)
                    if entry.get('fingerprint') is None:
                        entry.update(_owner_channels=True,_owner_channels_binding=_binding(user,account,self.scope.instance_id()))
                    # The original adapter's event cannot abort blocked GET.
                    result['cleanup_confirmed']=not entry.get('running',False)
                return self._metadata(request,entry)
        if action=='owner_channels_configure':
            if data['acknowledge_self_use'] is not True or data['acknowledge_single_session'] is not True:
                raise ValueError('保存端口前请确认本人单一页面；不会安装或启动工具')
            port=data['port'];_endpoint(port)
        else:port=_port(account.get('endpoint'))
        if action in ('owner_channels_configure','owner_channels_check'):
            with self.scope.frame(token,user,account,port,action):
                with self.scope.connection_call() as call:
                    fields={'id':account['id']}
                    if action=='owner_channels_configure':fields['port']=port
                    raw=(call.manager.configure(user,fields,_preview_call=call) if action=='owner_channels_configure'
                         else call.manager.status(user,fields,_preview_call=call))
                    call.complete_saved();call.check()
                    return {'purpose':PURPOSE,'account_id':account['id'],'port':port,
                        'status':raw['status'],'message':raw['message'],'single_session':True,
                        'temporary_page_connected':raw['status']=='connected_unverified',
                        **{name:False for name in _FALSE}}
        request=data['request_id']
        if (type(request) is not str or not _REQUEST.fullmatch(request) or type(data['page']) is not int
                or data['page']!=1 or type(data['limit']) is not int or not 1<=data['limit']<=20):
            raise ValueError('只显示指定视频第一页、不超过20条；不自动翻页或换号')
        from core.platform_reads import source_reference
        _,reference=source_reference('wechat_channels',data['reference'])
        fields={'account_id':account['id'],'request_id':request,'reference':reference,'page':1,'limit':data['limit']}
        with self.scope.reads._lock:
            entry=self._entry(request,user,account)
            if entry and entry.get('_owner_channels_input')!=fields and not entry.get('cancelled'):
                raise ValueError('同一原编号不能换视频或数量')
            cached=deepcopy(entry.get('response')) if entry and not entry.get('running') else None
        with self.scope.frame(token,user,account,port,'comments',request,fields):
            if entry is not None:
                if entry.get('cancelled'):return self._result(self.scope.reads._response('wechat_channels','comments','cancelled'),request)
                if not cached:return self._result(self.scope.reads._response('wechat_channels','comments','busy'),request)
                if cached.get('code')!='completed':return self._result(cached,request)
                # Cache contents are never served from old config/health alone.
                with self.scope.cached_call(entry) as call:
                    call.check()
                    return self._result(cached,request)
            result=self.scope.reads.execute('platform_read_comments',fields,self.scope.core._public(user))
            self.scope.check()
            return self._result(result,request)


class _OwnerChannelsScope:
    def __init__(self,workspace,seal):
        if seal is not _SEAL or type(workspace) is not OwnerReadWorkspace:raise ValueError('视频号私有范围无效')
        self.workspace,self.server,self.instance=workspace,workspace.server,workspace.instance
        self.core=self.server.core;self.reads=None;self._tls=threading.local();self._unknown=set()

    def instance_id(self):return self.instance.check()['selfOperatingRead']['instance_id']

    def require_v2(self):
        company=self.instance.check()
        if (self.server._self_operating_reads is not self.workspace or self.server.core is not self.core
                or self.workspace.instance is not self.instance or company!=self.server.company
                or company.get('platforms')!=['xiaohongshu','douyin','wechat_channels']
                or company.get('selfOperatingRead')!={'schema':'owner_read_instance_v2',
                    'instance_id':self.instance_id(),'archive_available':False}):
            raise ValueError('视频号需正规全新 owner v2 实例；不迁移或改写旧 v1')

    def account(self,user,ident,*,cleanup=False):
        self.require_v2()
        if type(ident) is not str or not _ID.fullmatch(ident):raise ValueError('本人预览账号编号无效')
        with self.core.lock:
            current=self.core._get('accounts',ident,user['tenant_id'])
            self.core._account_access(user,current)
        expected={'schema':'local_owner_channels_preview_v1','instance_id':self.instance_id(),
            'actor_digest':_digest(_actor_identity(user)),'self_use_confirmed':True,
            'single_session_confirmed':True,'identity_verified':False}
        if (current.get('tenant_id')!=user['tenant_id'] or current.get('cloud_owner')!=user['username']
                or current.get('platform')!='wechat_channels' or current.get('owner_channels_preview')!=expected):
            raise ValueError('账号须来自本实例本人明确记录；不接旧员工或手工 scope')
        if not cleanup:
            if (current.get('requires_review') not in (None,False)
                    or current.get('risk_state') not in (None,'','normal','safe')
                    or current.get('status') not in ('unverified','connected_unverified')
                    or current.get('platform_uid') not in (None,'') or current.get('conn_id') not in (None,'')
                    or ident in self._unknown or current.get('owner_channels_read_hold')):
                raise ValueError('原账号、风险或上游未确认读取仍待核；不重发或换号解除')
        return current

    def review(self,user,account,port):
        try:return self._review(user,account,port)
        except (OSError,UnicodeError):
            # Missing plain purpose is pending, not a generic HTTP500 or a
            # raw filesystem/HOME error. No fallback review or GET is created.
            raise ValueError('视频号本机预览用途默认待审；固定用途文件缺失或不可读取') from None

    def _review(self,user,account,port):
        from core.runtime_license_policy import _plain
        path=_plain(self.instance.directory/_FILE,self.instance.work_root)
        info=path.stat()
        if info.st_nlink!=1 or info.st_size>65536:raise ValueError('视频号用途文件不允许共享或过大')
        raw=path.read_bytes()
        if len(raw)>65536:raise ValueError('视频号用途文件过大')
        revision=source_revision()
        value=json.loads(raw.decode('utf-8'),object_pairs_hook=_duplicates)
        validate_review(value,self.server.company['id'],self.instance_id(),
            _digest(_actor_identity(user)),account['id'],port,revision)
        return hashlib.sha256(raw).hexdigest(),revision

    @contextmanager
    def frame(self,token,user,account,port,operation,request=None,fields=None):
        if getattr(self._tls,'frame',None) is not None:raise ValueError('视频号不能嵌套或借用别的平台用途')
        revision,sources=self.review(user,account,port)
        frame={'seal':_SEAL,'token':token,'user':deepcopy(user),'account':deepcopy(account),
            'port':port,'operation':operation,'request':request,'fields':deepcopy(fields),
            'revision':revision,'sources':sources,'thread':threading.get_ident()}
        self._tls.frame=frame
        try:self.check();yield;self.check()
        finally:
            if getattr(self._tls,'frame',None) is frame:del self._tls.frame

    def check(self,account=None):
        self.require_v2();frame=getattr(self._tls,'frame',None)
        if (frame is None or frame['seal'] is not _SEAL or frame['thread']!=threading.get_ident()
                or self.workspace._reads is not self.reads or self.reads is None
                or self.reads._owner_channels_preview_scope is not self):raise ValueError('视频号当前私有调用已失效')
        user=self.workspace._actor(frame['token']);current=self.account(user,frame['account']['id'])
        if user!=frame['user'] or current!=frame['account'] or account is not None and account!=current:
            raise ValueError('读取期间本人、账号、保存UID或连接字段已变化')
        self.core.require_platform('wechat_channels');self.core._platform_execution_guard('wechat_channels')
        from core.service_plans import require_feature
        require_feature(self.server.company,'acquisition')
        if self.review(user,current,frame['port'])!=(frame['revision'],frame['sources']):raise ValueError('视频号用途或六源字节已变化')
        if frame['operation']=='comments' and (current.get('status')!='connected_unverified'
                or not current.get('bound_client_id') or _port(current.get('endpoint'))!=frame['port']):
            raise ValueError('指定评论须先绑定唯一原本机页面；身份仍未核实')
        directory=_plain_home(self.core.store.directory/'accounts'/user['tenant_id']/current['id'],self.core.store.directory)
        _plain_config(directory/'wechat_channels.json')
        self.core.adapters.require_account_safe('wechat_channels',directory)
        return frame,directory

    def bind_entry(self,entry,user,account):
        frame,_=self.check(account)
        if (self.reads._operations.get(frame['request']) is not entry or not entry.get('running')
                or entry.get('account_id')!=account['id'] or user!=frame['user']):
            raise ValueError('不能登记其它账号或原号')
        entry.update(_owner_channels=True,_owner_channels_input=deepcopy(frame['fields']),
            _owner_channels_revision=frame['revision'],
            _owner_channels_binding=_binding(user,account,self.instance_id()))

    def entry_current(self,entry,user,account):
        frame,_=self.check(account)
        return (entry.get('_owner_channels') is True
            and entry.get('_owner_channels_binding')==_binding(user,account,self.instance_id())
            and entry.get('_owner_channels_revision')==frame['revision']
            and entry.get('_owner_channels_input')==frame['fields'])

    def mark_unknown(self,entry):
        frame=getattr(self._tls,'frame',None)
        if frame is None:return
        ident=frame['account']['id'];self._unknown.add(ident)
        # Only our original stable owner record gets a conservative local hold.
        # No risk/UID/permission/consent is cleared; metadata/cancel bypass it.
        with self.core.lock:
            current=self.core.store.get('accounts',ident)
            if (type(current) is dict and all(current.get(k)==frame['account'].get(k)
                    for k in ('id','tenant_id','cloud_owner','platform','owner_channels_preview'))):
                current['owner_channels_read_hold']={'schema':'owner_channels_local_unknown_v1',
                    'request_id':frame['request'],'upstream_completion_verified':False}
                self.core.store.put('accounts',current)

    @contextmanager
    def connection_call(self):
        from core.adapters import account_execution_lock
        call=_OwnerChannelsCall(self,None,None,_SEAL)
        with call.manager.lock,account_execution_lock(call.directory),call.channel_lock():
            try:call.check();yield call
            finally:call.active=False

    @contextmanager
    def cached_call(self,entry):
        from core.adapters import account_execution_lock
        from core.wechat_channels import Client
        call=_OwnerChannelsCall(self,entry,None,_SEAL,cached=True)
        with call.manager.lock,account_execution_lock(call.directory),call.channel_lock():
            try:
                call.check();client=Client(call.directory,_preview_call=call)
                client.check('comment');call.check()
                yield call
                client.check('comment');call.check()
            finally:call.active=False


class _OwnerChannelsCall:
    def __init__(self,scope,entry,task,seal,*,cached=False):
        if seal is not _SEAL or type(scope) is not _OwnerChannelsScope:raise ValueError('视频号只接受 exact 私有用途')
        self.scope,self.reads,self.entry,self.task=scope,scope.reads,entry,task
        self.frame,self.directory=scope.check();self.account_id=self.frame['account']['id']
        self.server=scope.server;self.manager=self.server.wechat_channels
        self.endpoint=_endpoint(self.frame['port']);self.cached=cached;self.active=True
        self.thread=threading.get_ident();self.config=None;self.pending_saved=False
        self.platform_call_started=False;self.profile_nonce=None
        self.complete_saved(optional=self.frame['operation']=='owner_channels_configure')

    def complete_saved(self,*,optional=False):
        from core.runtime_license_policy import _plain
        path=self.directory/'wechat_channels.json'
        if optional and not path.exists():return
        raw=_plain(path,self.scope.core.store.directory).read_bytes()
        if len(raw)>8192:raise ValueError('本机连接配置过大')
        value=json.loads(raw.decode('utf-8'),object_pairs_hook=_duplicates)
        account=self.frame['account']
        if (type(value) is not dict or set(value)!={'endpoint','bound_client_id'}
                or value['endpoint']!=self.endpoint or value['bound_client_id']!=account.get('bound_client_id','')):
            if optional:return
            raise ValueError('账号与普通本机配置的绑定不一致')
        self.config=raw;self.pending_saved=False

    def accept_saved(self,account):
        if any(account.get(k)!=self.frame['account'].get(k) for k in
                ('id','tenant_id','cloud_owner','platform','platform_uid','conn_id','owner_channels_preview',
                 'risk_state','requires_review','owner_channels_read_hold')):
            raise ValueError('连接保存不能修改身份、风险或原上游hold')
        self.frame['account']=deepcopy(account);self.pending_saved=True

    def check(self):
        frame,directory=self.scope.check()
        if (not self.active or self.thread!=threading.get_ident() or self.frame is not frame
                or directory!=self.directory or self.manager is not self.server.wechat_channels
                or self.endpoint!=_endpoint(frame['port'])):raise ValueError('本机连接调用已失效')
        if self.pending_saved:self.complete_saved()
        if self.config is not None and (self.directory/'wechat_channels.json').read_bytes()!=self.config:
            raise ValueError('读取过程中本机配置已变化')
        if self.entry is not None:
            if (self.reads._operations.get(frame['request']) is not self.entry
                    or self.entry.get('cancelled') or self.entry.get('account_id')!=self.account_id
                    or self.entry.get('running',False)!=(not self.cached)
                    or not self.scope.entry_current(self.entry,frame['user'],frame['account'])):
                raise ValueError('原读取已取消、收尾或范围改变')
        return frame

    def before_io(self):return self.check()

    @contextmanager
    def channel_lock(self):
        from core.adapters import AdapterBusy
        adapters=self.scope.core.adapters
        with adapters.channel_guard:lock=adapters.channel_locks.setdefault('wechat_channels:single-local-session',threading.Lock())
        if not lock.acquire(blocking=False):raise AdapterBusy('原视频号单会话仍在读取或收尾')
        try:
            with adapters.lifecycle_lock:
                if adapters.closed:raise ValueError('工作台正在关闭')
            yield
        finally:lock.release()

    def check_spec(self,task):
        frame=self.check()
        if (self.cached or self.entry is None or self.task is not task
                or task.get('_wechat_preview_call') is not self or task.get('_account_dir')!=str(self.directory)
                or task.get('id')!=self.entry['operation_id'] or task.get('keywords')!=['']
                or task.get('note_url')!=frame['fields']['reference'] or task.get('next_cursor')!=''
                or task.get('next_page')!=1 or task.get('daily_limit')!=frame['fields']['limit']
                or task.get('max_pages')!=1):raise ValueError('最终评论目标、HOME、页码或原job不一致')

    def local_get(self,endpoint,path,timeout=3):
        from wechat_channels_connection import local_get
        from core.wechat_channels import unwrap
        frame=self.check()
        if endpoint!=self.endpoint:raise ValueError('请求不能切换本机端口')
        parsed=urlsplit(path)
        if parsed.scheme or parsed.netloc or parsed.fragment or not path.startswith('/api/channels/'):
            raise ValueError('只开放固定本机只读路径')
        query=parse_qs(parsed.query,keep_blank_values=True,strict_parsing=bool(parsed.query))
        if any(len(values)!=1 for values in query.values()):raise ValueError('本机请求参数不能重复')
        if parsed.path=='/api/channels/status':
            if query:raise ValueError('状态请求不接其它参数')
            if type(timeout) not in (int,float) or timeout not in (3,5):raise ValueError('状态请求超时范围不一致')
            bound=frame['account'].get('bound_client_id','')
        else:
            if type(timeout) not in (int,float) or timeout!=65:raise ValueError('原同步读取超时范围不一致')
            if self.cached or frame['operation']!='comments' or self.entry is None:
                raise ValueError('缓存或连接检查不能派生新的平台读取')
            self.check_spec(self.task)
            expected=(__import__('core.wechat_channels',fromlist=['video_reference']).video_reference(frame['fields']['reference']))
            if parsed.path=='/api/channels/feed/profile':
                if set(query)-{'object_id','nonce_id'} or query.get('object_id')!=[expected['object_id']]:raise ValueError('详情请求不是原明确视频')
                if 'nonce_id' in query and query['nonce_id']!=[expected.get('nonce_id','')]:raise ValueError('详情nonce不是原定位上下文')
            elif parsed.path=='/api/channels/feed/comment/list':
                if (set(query)-{'object_id','nonce_id','next_marker'} or query.get('object_id')!=[expected['object_id']]
                        or query.get('next_marker',[''])!=[''] or not query.get('nonce_id')):
                    raise ValueError('评论请求只接原视频第一页')
                nonce=query['nonce_id'][0]
                if not 1<=len(nonce)<=512 or any(ord(c)<32 or ord(c)==127 for c in nonce):raise ValueError('nonce定位上下文无效')
                if expected.get('nonce_id') and nonce!=expected['nonce_id']:raise ValueError('评论nonce已变化')
                if not expected.get('nonce_id') and nonce!=self.profile_nonce:raise ValueError('未知nonce须先核同作品详情')
            else:raise ValueError('未开放搜索或其它本机平台接口')
            self.platform_call_started=True
        try:
            payload=local_get(endpoint,path,timeout=timeout)
            self.check()
            if parsed.path!='/api/channels/status':_require_feed_success(payload)
            if parsed.path=='/api/channels/status':
                validate_status(payload,bound=bound)
            elif parsed.path=='/api/channels/feed/profile':
                obj=unwrap(payload).get('object')
                if (type(obj) is not dict or str(obj.get('id',''))!=expected['object_id']
                        or type(obj.get('objectNonceId')) is not str or not 1<=len(obj['objectNonceId'])<=512
                        or any(ord(c)<32 or ord(c)==127 for c in obj['objectNonceId'])):
                    raise ValueError('详情不是原明确作品或nonce未知；未请求评论')
                self.profile_nonce=obj['objectNonceId']
            else:
                data=unwrap(payload);items=data.get('commentInfo')
                if type(items) is not list:raise ValueError('评论包未知，不能视作空页')
                total=0
                for item in items:
                    if type(item) is not dict or type(item.get('levelTwoComment',[])) is not list:
                        raise ValueError('评论嵌套结构待核')
                    total+=1+len(item.get('levelTwoComment',[]))
                    if total>1000:raise ValueError('本页实际观察行数超过原处理边界')
            return payload
        except (ValueError,RuntimeError,OSError,TimeoutError,TypeError,KeyError):
            if self.platform_call_started:self.scope.mark_unknown(self.entry)
            raise


@contextmanager
def owned_channels_read(reads,entry,user,account,task,scope):
    from core.adapters import account_execution_lock
    if type(scope) is not _OwnerChannelsScope or scope.reads is not reads:raise ValueError('视频号专属用途待审')
    scope.bind_entry(entry,user,account)
    call=_OwnerChannelsCall(scope,entry,task,_SEAL)
    try:
        # Original adapter acquires its channel lock below this scope. Never
        # release either OS lock or original registry while synchronous GET waits.
        with call.manager.lock,account_execution_lock(call.directory):
            call.check();task['_wechat_preview_call']=call
            try:
                yield call
                call.check()
            except (ValueError,RuntimeError,OSError,TimeoutError):
                if call.platform_call_started:scope.mark_unknown(entry)
                raise
    finally:
        if task.get('_wechat_preview_call') is call:task.pop('_wechat_preview_call',None)
        call.active=False
