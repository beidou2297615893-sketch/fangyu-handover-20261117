"""Original natural login window with the fixed parent's first-load gate."""
from pathlib import Path
import time

from .browser_login_window import run_login_window,_RECORDED_OUTCOMES
from .native_login_observer import NativeLoginError
from xhs_page_window import BridgeSpec,_post,_reparse


def run_session_recovery_window(spec):
    if type(spec) is not BridgeSpec or spec.read_mode!='natural' or spec.purpose!='session_recovery':
        return 'mode_invalid'
    account=spec.spec_path.parents[3]
    job_id=spec.spec_path.parent.name
    staging=account/'work/browser-login'/job_id
    cancel=staging/'cancel.flag'
    if _reparse(staging) or _reparse(cancel) or not staging.is_dir():return 'staging_path_invalid'
    token=None
    packet=None
    def bound(extra=None):
        return {'session_token':token,'doc_epoch':1,**(extra or {})}
    def before_navigation(window,observer):
        nonlocal token,packet
        from owned_window_sources import collect_window_facts
        facts=collect_window_facts(observer.native,spec.profile_dir)
        connected=_post(spec,'/connect',{'secret':spec.bootstrap_secret,'doc_epoch':1,
            'tenant_id':spec.tenant_id,'account_id':spec.account_id,'bound_uid':spec.bound_uid,
            'purpose':'session_recovery','runtime_facts':facts})
        token=connected.get('session_token')
        if not isinstance(token,str) or len(token)<32:raise NativeLoginError('native_pending')
        deadline=time.monotonic()+30
        while time.monotonic()<deadline and not cancel.exists() and not spec.cancel_file.exists():
            value=_post(spec,'/poll',bound())
            if value.get('action')=='stop':raise NativeLoginError('cancelled')
            if value.get('action')=='session_recovery':
                if (set(value)!={'ok','action','call_id','task_epoch'} or value.get('ok') is not True or value['call_id']!='recover'
                        or type(value['task_epoch']) is not int or value['task_epoch']!=1):
                    raise NativeLoginError('native_pending')
                packet=value
                return
            time.sleep(.05)
        raise NativeLoginError('native_pending')
    def current():
        if cancel.exists() or spec.cancel_file.exists():return False
        # Before the blank window is ready this permits local initialization
        # only. The mandatory hook above still blocks the first platform load.
        if token is None:return True
        if packet is None:return False
        try:
            value=_post(spec,'/session_current',bound({'call_id':packet['call_id'],
                'task_epoch':packet['task_epoch']}),timeout=1)
            return value.get('action')=='continue'
        except Exception:return False
    code=run_login_window(mode='live',staging_root=staging,cancel_file=cancel,
        profile_dir=spec.profile_dir,guard=current,natural_identity=True,
        before_navigation=before_navigation)
    if token is not None and packet is not None and code in _RECORDED_OUTCOMES:
        try:_post(spec,'/session_result',bound({'call_id':packet['call_id'],
            'task_epoch':packet['task_epoch'],'code':code}))
        except Exception:return 'cancelled'
    return code
