"""Canonical acquired customer materials; no model, authority or I/O."""
from copy import deepcopy
import hashlib
import json
import re
from urllib.parse import urlsplit

SOURCE_FIELDS = ('id','tenant_id','cloud_owner','store_id','task_id','platform',
    'author_id','author','comment_id','source_id','source_type','text',
    'title','content_title','content_text','content_body','post_text',
    'parent_text','parent_id','target_comment_id','target_author_id','comment_level',
    'content_author','content_author_id','published_at','content_published_at',
    'created_at','note_url','url','live_source','is_post_author','source_context','post_date_status')
TASK_FIELDS = ('id','tenant_id','cloud_owner','store_id','city','area','platform',
    'account_id','content_title','content_text','post_text','content_body','note_url','url','scope')
EXTRA_FIELDS = ('content_description',)
BODY_FIELDS = ('content_text','content_body','post_text','content_description')

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()

def extra_source_material(lead,task):
    extra={}
    for label,source in (('lead',lead),('task',task)):
        values={key:deepcopy(source.get(key)) for key in EXTRA_FIELDS
            if source.get(key) is not None and
            (not isinstance(source.get(key),str) or source[key].strip())}
        if values:extra[label]=values
    return extra

def source_digest(lead,task):
    # Byte-compatible with v3 when no newly acquired description exists.
    payload={'schema':'customer-intent-source-v1',
        'lead':{k:deepcopy(lead.get(k)) for k in SOURCE_FIELDS},
        'task':{k:deepcopy(task.get(k)) for k in TASK_FIELDS}}
    extra=extra_source_material(lead,task)
    if extra:payload['extra_source_material']=extra
    return digest(payload)

def customer_key(platform,uid):
    # Preserve the established assistant.customer_list._person identity bytes.
    return hashlib.sha256(json.dumps((platform,'uid',uid),ensure_ascii=False,
        separators=(',',':')).encode()).hexdigest()

def stable_uid(value):
    return (isinstance(value,(str,int)) and not isinstance(value,bool)
        and str(value).strip().casefold() not in ('','0','unknown','null','none','undefined','n/a','-'))

def _post_reference(value):
    if not isinstance(value,str):return None
    try:
        parsed=urlsplit(value)
        if parsed.scheme!='https' or parsed.username or parsed.password or parsed.port not in (None,443):return None
        if parsed.hostname in ('xiaohongshu.com','www.xiaohongshu.com'):
            match=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]{24})/?',parsed.path)
            return ('xiaohongshu',match[1].lower()) if match else None
        if parsed.hostname in ('douyin.com','www.douyin.com'):
            match=re.fullmatch(r'/video/([1-9][0-9]{0,31})/?',parsed.path)
            return ('douyin',match[1]) if match else None
    except ValueError:return None
    return None

def scope(lead,task):
    tenant=lead.get('tenant_id');owner=lead.get('cloud_owner');store=lead.get('store_id') or task.get('store_id')
    platform=lead.get('platform');uid=str(lead.get('author_id') or '').strip()
    if (not all(isinstance(x,str) and x for x in (tenant,owner,store))
            or platform not in ('xiaohongshu','douyin')):return None
    known=stable_uid(lead.get('author_id'))
    return {'tenant_id':tenant,'owner':owner,'store_id':store,'platform':platform,
        'uid':uid if known else '', 'customer_id':customer_key(platform,uid) if known else '',
        **({} if known else {'provisional_lead_id':lead['id']})}

def canonical_comment(lead,task):
    from core.intent_policy import original_post_title
    title=original_post_title(lead);sources={'title':'content_title' if lead.get('content_title') else 'title'}
    bodies=[('lead.'+key,lead.get(key)) for key in BODY_FIELDS if lead.get(key) is not None and
        (not isinstance(lead.get(key),str) or lead[key].strip())]
    task_bodies=[('task.'+key,task.get(key)) for key in BODY_FIELDS if task.get(key) is not None and
        (not isinstance(task.get(key),str) or task[key].strip())]
    lead_post=_post_reference(lead.get('note_url') or lead.get('url'))
    task_post=_post_reference(task.get('note_url') or task.get('url'))
    bound=bool(lead_post and lead_post==task_post)
    if bound:bodies+=task_bodies
    invalid=any(not isinstance(value,str) or len(value)>10000 for _,value in bodies)
    distinct={value for _,value in bodies if isinstance(value,str)}
    conflict=len(distinct)>1
    body=bodies[0][1] if bodies and not invalid and not conflict else ''
    if bodies:sources['body']=bodies[0][0]
    text=lead.get('text');missing=[]
    if not isinstance(text,str) or not text.strip():missing.append('own_comment_missing')
    if invalid or conflict:missing.append('post_material_conflict' if conflict else 'post_material_invalid')
    if not title and not body:missing.append('post_material_missing')
    return {'id':lead['id'],'task_id':lead.get('task_id'),'text':text or '', 'parent_text':deepcopy(lead.get('parent_text') or ''),
        'post':{'title':title,'text':body,'author_id':lead.get('content_author_id')},
        'is_post_author':bool(lead.get('author_id') and lead.get('content_author_id') and
            str(lead['author_id'])==str(lead['content_author_id'])),
        'published_at':lead.get('published_at'),'material_sources':sources,'missing_materials':missing,
        'unused_materials':['task_post_unbound'] if task_bodies and not bound else [],
        'comment_id':lead.get('comment_id'),'author_id':lead.get('author_id'),
        'captured_at':lead.get('created_at'),'post_reference':lead_post,
        'parent':{'root_comment_id':lead.get('parent_id'),
            'direct_target_comment_id':lead.get('target_comment_id'),
            'direct_target_author_id':lead.get('target_author_id'),
            'text_source':'persisted_root_parent_text' if lead.get('parent_text') else 'missing',
            'text_speaker_id':lead.get('target_author_id') if lead.get('parent_id') and lead.get('parent_id')==lead.get('target_comment_id') else None,
            'direct_target_differs_from_root':bool(lead.get('parent_id') and lead.get('target_comment_id') and lead.get('parent_id')!=lead.get('target_comment_id'))},
        'saved_ai':deepcopy(lead.get('ai_intent') or {}),'manual_intent':deepcopy(lead.get('manual_intent') or {})}
