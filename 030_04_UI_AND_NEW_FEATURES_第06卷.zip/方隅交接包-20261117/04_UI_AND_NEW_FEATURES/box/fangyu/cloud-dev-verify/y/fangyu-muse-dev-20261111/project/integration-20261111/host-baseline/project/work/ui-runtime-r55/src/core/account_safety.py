"""Conservative, account-local summary of platform activity metadata.

The summary is an operational heuristic, never a platform-approved safe rate.
"""
import json
import math
import os
import re
import threading
import time
from collections import deque
from contextlib import contextmanager
from pathlib import Path

RISK_HTTP={429,461,471}
AUTH_HTTP={401,403}
SEMANTIC_RISK={'api_error'}
SEMANTIC_PROCESS={'protocol_error'}
def redirect_http(status):return isinstance(status,int) and 300<=status<400
RISK_CODES={'verification_required','ip_blocked'}
AUTH_CODES={'not_authenticated'}
PROCESS_CODES={'start_failed','process_failed','timeout','transport_error',
               'protocol_error','signature_error','api_error','unsupported_operation'}
MANUAL_KINDS={'phone_verification','unexpected_logout','review_completed'}
TRIAL_KINDS={'search','read','comments','sub-comments','user-posts','notifications','reply'}
FINISHED_STATUSES={'transport_error','api_error','protocol_error','cancelled_before_send','page_read_complete','page_local_error'}
CLI_FINISHED_STATUSES={'completed'}|RISK_CODES|AUTH_CODES|PROCESS_CODES
_manual_lock_guard=threading.Lock()
_manual_locks={}

def local_page_failure(entry):
    """Only a confirmed owned helper's local search-read failure; no HTTP risk exemption."""
    diagnostic=entry.get('page_diagnostic')
    return (entry.get('stage')=='finished' and entry.get('status') in ('transport_error','page_local_error')
        and isinstance(diagnostic,dict) and diagnostic.get('stage')=='call'
        and diagnostic.get('failure_received') is True
        and diagnostic.get('failure_code')=='search_scroll_unavailable'
        and all(type(diagnostic.get(key)) is int and diagnostic[key]>0 for key in ('doc_epoch','task_epoch')))

@contextmanager
def _manual_activity_lock(path):
    """Serialize manual warnings and reviews across threads and processes."""
    root=Path(path).parent.resolve()
    root.mkdir(parents=True,exist_ok=True)
    with _manual_lock_guard:
        local=_manual_locks.setdefault(root,threading.Lock())
    with local:
        handle=os.open(root/'platform-activity-control.lock',os.O_CREAT|os.O_RDWR,0o600)
        try:
            if os.fstat(handle).st_size==0:os.write(handle,b'\0')
            os.lseek(handle,0,os.SEEK_SET)
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(handle,msvcrt.LK_LOCK,1)
            else:
                import fcntl
                fcntl.flock(handle,fcntl.LOCK_EX)
            try:yield
            finally:
                os.lseek(handle,0,os.SEEK_SET)
                if os.name=='nt':msvcrt.locking(handle,msvcrt.LK_UNLCK,1)
                else:fcntl.flock(handle,fcntl.LOCK_UN)
        finally:os.close(handle)


def record_manual_signal(path,kind,at=None,expected_revision=None):
    """Record only an employee-selected signal, with no account or phone data."""
    if kind not in MANUAL_KINDS:raise ValueError('不支持此账号异常类型')
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    entry={'at':float(at if at is not None else time.time()),'stage':'manual_signal','kind':kind}
    payload=(json.dumps(entry,separators=(',',':'))+'\n').encode('utf-8')
    with _manual_activity_lock(path):
        current=path.stat().st_size if path.is_file() else 0
        if expected_revision is not None and (type(expected_revision) is not int or expected_revision!=current):
            raise ValueError('账号安全记录已更新，请重新查看最新提醒后再确认复核')
        handle=os.open(path,os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
        try:
            if os.write(handle,payload)!=len(payload):raise OSError('Activity record was incomplete')
            os.fsync(handle)
        finally:os.close(handle)



ACTION_LABELS={'user-posts':'读取博主帖子','notifications':'读取本人互动','search':'搜索','read':'读取帖子','comments':'读取评论',
               'sub-comments':'读取回复','reply':'回复','login':'登录',
               'status':'检查状态','whoami':'检查账号'}
PHONE_LABELS={'unexpected_logout':'手机异常退出',
              'phone_verification':'手机提示验证',
              'review_completed':'人工复核'}
CLI_LABELS={'verification_required':'电脑提示验证','ip_blocked':'电脑连接受限',
            'not_authenticated':'电脑登录失效','start_failed':'程序启动失败',
            'process_failed':'程序运行失败','timeout':'电脑请求超时',
            'transport_error':'电脑连接中断','protocol_error':'电脑响应异常',
            'signature_error':'电脑签名异常','api_error':'电脑接口异常',
            'unsupported_operation':'电脑操作不受支持'}


def _computer_label(entry):
    stage,status=entry.get('stage'),entry.get('status')
    if local_page_failure(entry):return '搜索页面读取未完成'
    if stage in {'cli_finished','browser_finished'}:return CLI_LABELS.get(status)
    if stage!='finished':return None
    if status==429:return '电脑请求过于频繁'
    if status==461:return '电脑接口要求验证'
    if status==471:return '电脑接口受限'
    if status in AUTH_HTTP:return '电脑登录失效'
    if redirect_http(status):return '电脑登录跳转'
    return {'api_error':'电脑接口异常','protocol_error':'电脑响应异常',
            'transport_error':'电脑连接中断','page_local_error':'电脑页面读取异常'}.get(status)


def _incident_history(events):
    """Only bounded, redacted incidents; an HTTP 461 and its CLI exit are one incident."""
    incidents=[]
    pairing_barrier=-1
    for index,entry in enumerate(events):
        stage=entry.get('stage');kind=entry.get('kind')
        if stage=='started' or stage=='manual_signal':pairing_barrier=index
        if stage=='manual_signal' and kind in PHONE_LABELS:
            incidents.append({'at':entry['at'],'source':'phone_report',
                'kind':PHONE_LABELS[kind],'label':PHONE_LABELS[kind],
                'abnormal':kind!='review_completed','_code':kind})
            continue
        label=_computer_label(entry)
        if not label:continue
        if stage=='cli_finished' and entry.get('status') in {'verification_required','not_authenticated'}:
            # A CLI exit may repeat one wire failure. Pair only the same action,
            # nearby, with no intervening request/review, and consume once.
            def same_failure(item):
                if entry['status']=='verification_required':
                    return item.get('_status')==461
                return (item.get('_status') in AUTH_HTTP or
                        item.get('_status')=='api_error' and item.get('_platform_code')==-100)
            match=next((item for item in reversed(incidents)
                        if item.get('_stage')=='finished' and same_failure(item)
                        and item.get('source')=='computer_http'
                        and item.get('_event_index',-1)>pairing_barrier
                        and item.get('_raw_kind')==kind
                        and 0<=entry['at']-item['at']<=120),None)
            if match:
                match['source']='computer_http_cli'
                match['label']=label
                continue
        incidents.append({'at':entry['at'],
            'source':('computer_http' if stage=='finished' else
                      'computer_browser' if stage=='browser_finished' else 'computer_cli'),
            'kind':ACTION_LABELS.get(kind,'电脑操作'), 'label':label,'abnormal':True,
            '_stage':stage,'_status':entry.get('status'),
            '_platform_code':entry.get('platform_code'),'_raw_kind':kind,
            '_event_index':index})
    return incidents


def _typed_interval_advice(events,integrity_error=False):
    """Keep collection and reply observations independent; neither is a safe rate."""
    cancelled={e.get('request_id') for e in events if e.get('stage')=='finished'
               and e.get('status')=='cancelled_before_send'}
    completed={e.get('request_id'):e['at'] for e in events if e.get('stage')=='finished'
               and e.get('request_id') not in cancelled and isinstance(e.get('request_id'),str)}
    starts=[];by_type={'collection':[],'reply':[]};gaps={}
    for entry in events:
        if entry.get('stage')!='started' or entry.get('request_id') in cancelled:continue
        kind=entry.get('kind');ident=entry.get('request_id')
        starts.append((entry['at'],ident,kind))
        group='reply' if kind=='reply' else 'collection' if kind in TRIAL_KINDS else None
        if group is None:continue
        previous=by_type[group][-1] if by_type[group] else None
        by_type[group].append((entry['at'],ident))
        if (previous and ident in completed and previous[1] in completed
                and completed[previous[1]]<=entry['at']<=completed[ident]):
            gaps[ident]=(group,max(0,entry['at']-previous[0]))
    observed={'collection':[],'reply':[]}
    for entry in events:
        stage,status=entry.get('stage'),entry.get('status')
        relevant=((stage=='finished' and status in RISK_HTTP)
                  or (stage in {'cli_finished','browser_finished'} and status in RISK_CODES)
                  or (stage=='manual_signal' and entry.get('kind') in
                      {'phone_verification','unexpected_logout'}))
        if not relevant or entry.get('kind') in {'login','status','whoami'}:continue
        ident=entry.get('request_id')
        found=gaps.get(ident) if ident in completed and completed[ident]<=entry['at'] else None
        if found is None:
            for started_at,request_id,kind in reversed(starts):
                if started_at<=entry['at']:
                    if (entry['at']-started_at<=900 and completed.get(request_id,float('inf'))<=entry['at']):
                        found=gaps.get(request_id)
                    break
        if found is not None:observed[found[0]].append(found[1])
    advice={}
    for group,values in observed.items():
        gap=max(values) if values else None
        trial=max(600,math.ceil(gap*2)) if gap is not None and gap<=43200 and not integrity_error else None
        if trial is not None:
            recommendation=f'再次操作可参考至少 {trial} 秒作为谨慎试探间隔；再次异常立即停止'
            reason='只依据此类操作在异常前的已完成请求间隔估算，不是平台保证'
        elif gap is not None:
            recommendation='历史间隔证据不足，暂不提供数字建议'
            reason=('记录损坏或不完整，不能据此建议间隔' if integrity_error
                    else '已观测间隔超过可用于试探建议的范围')
        else:
            recommendation='没有独立间隔证据，暂不提供数字建议'
            reason='没有此类操作的独立、完整异常前间隔证据'
        advice[group]={'observed_gap_seconds':round(gap,1) if gap is not None else None,
                       'suggested_trial_gap_seconds':trial,
                       'recommendation':recommendation,'reason':reason}
    return advice


def _history_additions(events,state,integrity_error=False,older=False,overflow=False):
    incidents=_incident_history(events)
    phone=[item for item in incidents if item['source']=='phone_report' and item['abnormal']]
    phone_counts={key:sum(item.get('_code')==key for item in phone)
                  for key in ('unexpected_logout','phone_verification')}
    latest_phone=phone[-1]['at'] if phone else None
    last_phone_index=next((index for index in range(len(incidents)-1,-1,-1)
                           if incidents[index]['source']=='phone_report'
                           and incidents[index]['abnormal']),None)
    reviewed=(last_phone_index is not None and
              any(item.get('_code')=='review_completed'
                  for item in incidents[last_phone_index+1:]))
    phone_state=('unknown' if latest_phone is None else
                 'reviewed' if reviewed else 'reported_issue')
    login='账号退出后，直接点击一键登录重新连接'
    login_reason='历史活动仅供诊断，不是重新登录的前置条件'
    public=lambda item:{key:item[key] for key in ('at','source','kind','label','abnormal')}
    return {'phone_state':phone_state,'phone_report_count':len(phone),
        'phone_report_counts':phone_counts,
        'last_phone_anomaly_at':latest_phone,
        'previous_phone_anomaly_at':phone[-2]['at'] if len(phone)>1 else None,
        'computer_incident_count':sum(item['source'].startswith('computer_') for item in incidents),
        'incident_history':[public(item) for item in reversed(incidents[-20:])],
        'history_scope':{'days':30,'record_limit':5000,'timeline_limit':20,
                         'truncated_by_time':older,'truncated_by_records':overflow},
        'interval_advice':_typed_interval_advice(events,integrity_error),
        'next_login_recommendation':login,'next_login_reason':login_reason}

def summarize_activity(path,now=None):
    """Summarize the latest 30 days; never infer an official safe frequency."""
    now=float(now if now is not None else time.time())
    path=Path(path)
    if not path.is_file():
        return {'requests':0,'risk_signals':0,'process_anomalies':0,'state':'no_data',
                'review_reason':'none',
                'activity_revision_bytes':0,
                'observed_gap_before_signal_seconds':None,'suggested_trial_gap_seconds':None,
                'message':'尚无运行记录，不能推算安全间隔',
                **_history_additions([], 'no_data')}
    revision=path.stat().st_size
    events=deque(maxlen=5000)
    unreviewed=False;integrity_error=False;unfinished={};review_reason='none'
    older_events=False;window_records=0
    with path.open('r',encoding='utf-8',errors='replace') as stream:
        for line in stream:
            try:entry=json.loads(line)
            except ValueError:
                integrity_error=True
                continue
            if not isinstance(entry,dict):integrity_error=True;continue
            stage=entry.get('stage')
            if stage in {'started','finished','cli_finished','browser_finished','manual_signal'}:
                at=entry.get('at')
                if type(at) not in (int,float) or not math.isfinite(at):
                    integrity_error=True;continue
            kind=entry.get('kind')
            if (stage=='manual_signal' and (type(kind) is not str or kind not in MANUAL_KINDS)
                    or stage in ('started','finished','cli_finished','browser_finished')
                    and kind is not None and type(kind) is not str):
                integrity_error=True;continue
            status=entry.get('status')
            if (stage=='finished' and not (type(status) is int and 100<=status<=599
                                           or type(status) is str and status in FINISHED_STATUSES)
                    or stage in {'cli_finished','browser_finished'}
                    and (type(status) is not str or status not in CLI_FINISHED_STATUSES)):
                integrity_error=True;continue
            if (stage=='browser_finished' and (kind!='login'
                    or not isinstance(entry.get('request_id'),str)
                    or re.fullmatch(r'[a-f0-9]{24}',entry['request_id']) is None)):
                integrity_error=True;continue
            if entry.get('stage')=='manual_signal' and entry.get('kind')=='review_completed':
                unreviewed=False;unfinished.clear();review_reason='none'
            elif entry.get('stage')=='started':
                request_id=entry.get('request_id')
                if not isinstance(request_id,str) or not request_id:integrity_error=True
                elif request_id in unfinished:integrity_error=True
                else:unfinished[request_id]=entry.get('at')
            elif entry.get('stage')=='finished':
                request_id=entry.get('request_id')
                if not isinstance(request_id,str) or request_id not in unfinished:
                    integrity_error=True
                elif entry['at']<unfinished.pop(request_id):
                    integrity_error=True
            if ((entry.get('stage')=='finished' and (entry.get('status') in RISK_HTTP|AUTH_HTTP|SEMANTIC_RISK|SEMANTIC_PROCESS
                 or entry.get('status') in ('transport_error','page_local_error') and not local_page_failure(entry) or redirect_http(entry.get('status'))))
                or (entry.get('stage') in {'cli_finished','browser_finished'}
                    and entry.get('status') in RISK_CODES|AUTH_CODES|PROCESS_CODES)
                or (entry.get('stage')=='manual_signal' and entry.get('kind') in {'phone_verification','unexpected_logout'})):
                unreviewed=True
                if stage in {'cli_finished','browser_finished'} and status in RISK_CODES|AUTH_CODES:
                    review_reason=status
                elif ((stage=='finished' and status==461)
                      or (stage=='manual_signal' and kind=='phone_verification')):
                    review_reason='verification_required'
                elif stage=='finished' and status in AUTH_HTTP:
                    review_reason='not_authenticated'
                elif stage=='manual_signal' and kind=='unexpected_logout':
                    review_reason='manual_signal'
                else:
                    review_reason='other_risk'
            if (type(entry.get('at')) in (int,float) and math.isfinite(entry['at'])):
                if entry['at']<now-30*86400:older_events=True
                elif entry['at']<=now+60:
                    window_records+=1
                    events.append(entry)
    events=sorted(events,key=lambda item:item['at'])
    cancelled_ids={entry.get('request_id') for entry in events
                   if entry.get('stage')=='finished'
                   and entry.get('status')=='cancelled_before_send'
                   and isinstance(entry.get('request_id'),str)}
    completed_at={entry.get('request_id'):entry['at'] for entry in events
                  if entry.get('stage')=='finished' and entry.get('request_id') not in cancelled_ids
                  and isinstance(entry.get('request_id'),str)}
    request_times=[];trial_times=[];gaps={};risk=[];process=[]
    for entry in events:
        stage=entry.get('stage');status=entry.get('status')
        if stage=='started' and entry.get('request_id') not in cancelled_ids:
            kind=entry.get('kind')
            request_times.append((entry['at'],entry.get('request_id'),kind))
            if kind in TRIAL_KINDS:
                previous=trial_times[-1] if trial_times else None
                trial_times.append((entry['at'],entry.get('request_id')))
                request_id=entry.get('request_id')
                if (previous is not None and request_id in completed_at
                        and previous[1] in completed_at
                        and completed_at[previous[1]]<=entry['at']
                        and completed_at[request_id]>=entry['at']):
                    gaps[request_id]=max(0,entry['at']-previous[0])
        if ((stage=='finished' and status in RISK_HTTP|SEMANTIC_RISK)
                or (stage in {'cli_finished','browser_finished'} and status in RISK_CODES)
                or (stage=='manual_signal' and entry.get('kind')=='phone_verification')):
            risk.append(entry)
        if ((stage in {'cli_finished','browser_finished'} and status in PROCESS_CODES|AUTH_CODES)
                or (stage=='finished' and (status in AUTH_HTTP|SEMANTIC_PROCESS or redirect_http(status)))
                or (stage=='finished' and status in ('transport_error','page_local_error'))
                or (stage=='manual_signal' and entry.get('kind')=='unexpected_logout')):
            process.append(entry)
    # A user-reported unexpected logout is an account signal worth examining,
    # but a generic CLI crash is not evidence about platform request spacing.
    # A generic API semantic error pauses the account, but says nothing about
    # request spacing (for example an optional search prewarm compatibility error).
    interval_signals=[entry for entry in risk
                      if not (entry.get('stage')=='finished'
                              and entry.get('status') in SEMANTIC_RISK)]+[entry for entry in process
                           if entry.get('stage')=='manual_signal'
                           and entry.get('kind')=='unexpected_logout']
    incident_gaps=[]
    for signal in interval_signals:
        if signal.get('kind') in {'login','status','whoami'}:continue
        signal_id=signal.get('request_id')
        gap=(gaps.get(signal_id) if signal.get('kind') in TRIAL_KINDS
             and completed_at.get(signal_id,float('inf'))<=signal['at'] else None)
        if gap is None:
            # A phone prompt or CLI error has no request ID. Associate only a
            # recent preceding acquisition request. A newer login/status poll
            # prevents an older acquisition request from being mistaken for cause.
            for request_at,request_id,kind in reversed(request_times):
                if request_at<=signal['at']:
                    if (signal['at']-request_at<=15*60 and kind in TRIAL_KINDS
                            and completed_at.get(request_id,float('inf'))<=signal['at']):
                        gap=gaps.get(request_id)
                    break
        if gap is not None:incident_gaps.append(gap)
    # Use the largest observed gap before a signal so another incident cannot
    # reduce the trial suggestion. It is an operational heuristic, not a safe rate.
    gap=max(incident_gaps) if incident_gaps else None
    # A capped suggestion shorter than the incident gap would be misleading.
    # For intervals beyond this observation range, keep the incident evidence
    # but do not invent a numeric trial interval.
    trial=max(600,math.ceil(gap*2)) if gap is not None and gap<=43200 and not integrity_error else None
    # Recovery events and ordinary CLI checkpoints use one strict interpretation.
    # Historical counts remain unchanged; a resolution covers only its old risks.
    try:
        from .xhs_identity_recovery import read_activity,scan_activity
        raw,_=read_activity(path)
        parsed=scan_activity(raw)
        unreviewed=bool(parsed['pending'])
        unfinished=parsed['unfinished']
        if parsed['nonrecoverable_other_risk']:review_reason='other_risk'
        elif unreviewed and review_reason=='none':review_reason='verification_required'
    except Exception:
        integrity_error=True
    state='review_required' if unreviewed or integrity_error or unfinished else 'observe'
    if integrity_error or unfinished:review_reason='unknown'
    elif state!='review_required':review_reason='none'
    message=('历史记录有损坏或不完整，仅供诊断，不影响重新登录'
             if integrity_error else '历史记录包含未结束请求，仅供诊断，不作为人工复核条件'
             if unfinished else '历史异常已记录，需要时直接重新登录'
             if unreviewed or risk or process else '暂未记录异常；历史记录不能证明当前平台登录状态')
    return {'requests':len(request_times),'risk_signals':len(risk),'process_anomalies':len(process)+len(unfinished),
            'activity_revision_bytes':revision,
            'state':'observe','legacy_review_pending':state=='review_required',
            'manual_review_enabled':False,'review_reason':review_reason,
            'observed_gap_before_signal_seconds':round(gap,1) if gap is not None else None,
            'suggested_trial_gap_seconds':trial,'message':message,
            **_history_additions(events,state,integrity_error,older_events,window_records>5000)}


def account_review_view(path):
    """Compatibility view: local manual review was retired by user request.

    Platform responses, account ownership and incomplete credential commits
    retain their own checks. Historical activity is diagnostic, never a
    persistent admission lock or a prerequisite for ordinary login.
    """
    return {'requires_review':False,'review_reason':'none','manual_review_enabled':False}
