"""Sealed local archive of an original owner Douyin preview, no platform work."""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re
import threading
import time

from core import CoreError
from core.platform_reads import PlatformReadService, _digest, _ident, source_reference
from .platform_receipt_archive import (PlatformReceiptArchive, ReceiptArchiveError,
    RECEIPTS, BATCHES, SOURCES, _hash, _safe_text)

_SEAL=object()
_CONTRACT='owner_douyin_local_source_archive_v1'
_FILE='owner-douyin-source-archive-review.json'
_ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_KEY=re.compile(r'[A-Za-z0-9_-]{8,128}\Z')
_HEX=re.compile(r'[0-9a-f]{64}\Z')
_HISTORY='owner_douyin_saved_history_v1'
_HISTORY_CURSOR='owner_douyin_saved_history_cursor_v1'
_HISTORY_LOCAL={'read_only':True,'mutation_committed':False,'local_only':True,
    'storage_scope':'this_device','platform_requests_started':False,'AI_started':False,
    'reply_allowed':False,'cross_machine_verified':False,'real_platform_verified':False}
_ROOT=Path(__file__).parent.parent
_SOURCES=('assistant/owner_douyin_source_archive.py','assistant/owner_douyin_read.py',
    'assistant/self_operating_read.py','core/platform_reads.py',
    'assistant/platform_receipt_archive.py','web/workspace/self-operating-read.mjs')
_LIMITS={'comments_page':1,'max_comments':20,'local_storage':True,'platform_requests':False,
    'search':False,'AI':False,'reply':False,'dm':False,'auto_retry':False,
    'cross_machine_verified':False,'real_platform_verified':False}

def _fail(code,message,*,unknown=False):
    raise ReceiptArchiveError('OWNER_DY_'+code,message,mutation_committed=None if unknown else False)

class _StoragePermit:
    def __init__(self,service):self.service=service

    def review(self):
        # Absent by default. This is a local write decision, never the original
        # comments-purpose decision, a platform authorization or a demo grant.
        from core.runtime_license_policy import _plain
        service=self.service;w=service.workspace;config=w.instance.check()
        if config!=w.server.company or config['selfOperatingRead']['schema']!='owner_read_instance_v2':
            raise ValueError('本机抖音存储实例需核对')
        path=_plain(w.instance.directory/_FILE,w.instance.directory);attrs=path.stat()
        if attrs.st_size>16384 or attrs.st_nlink!=1:raise ValueError('本机存储审查文件无效')
        value=json.loads(path.read_bytes())
        expected={'schema','contract','scope','instance_id','company_id','source_revision','limits','decision'}
        if (type(value) is not dict or set(value)!=expected or type(value['schema']) is not int
                or value['schema']!=1 or value['contract']!=_CONTRACT
                or value['scope']!='internal_self_use_local_storage'
                or value['instance_id']!=config['selfOperatingRead']['instance_id']
                or value['company_id']!=config['id'] or value['limits']!=_LIMITS):
            raise ValueError('本机抖音保存尚待独立审查')
        decision=value['decision']
        if (type(decision) is not dict or set(decision)!={'id','reviewer','internal_technical_use',
                'production_distribution','account_authorization','real_platform_verified'}
                or type(decision['id']) is not str or not _ID.fullmatch(decision['id'])
                or type(decision['reviewer']) is not str or not 1<=len(decision['reviewer'])<=160
                or any(ord(c)<32 for c in decision['reviewer'])
                or decision['internal_technical_use'] is not True
                or any(decision[k] is not False for k in
                    ('production_distribution','account_authorization','real_platform_verified'))):
            raise ValueError('本机存储审查不能作为账号或商用批准')
        revision=_digest({name:hashlib.sha256(_plain(_ROOT/name,_ROOT).read_bytes()).hexdigest() for name in _SOURCES})
        if value['source_revision']!=revision:raise ValueError('本机存储源码版本已变化')
        return _digest(value)

    def current(self,revision):
        if self.review()!=revision:raise ValueError('本机存储审查已变化')

class _OwnerDouyinArchiveScope:
    """Only this exact factory scope may capture original Dy source snapshots."""
    def __init__(self,service,seal):
        if seal is not _SEAL:_fail('SCOPE','本机抖音归档只接可信服务')
        self.service=service;self.workspace=service.workspace;self.core=self.workspace.server.core
        self.reads=self.workspace._reads;self.helper=self.workspace._douyin
        self.instance_id=self.helper.scope.instance;self._tls=threading.local();self._seal=seal

    def check(self,user=None):
        frame=getattr(self._tls,'frame',None);w=self.workspace
        if (self._seal is not _SEAL or frame is None or frame['scope'] is not self
                or frame['thread']!=threading.get_ident() or w._douyin_archive is not self.service
                or self.reads is not w._reads or self.reads._owner_douyin_archive_scope is not self
                or self.helper is not w._douyin or self.helper.scope.reads is not self.reads
                or w.server.core is not self.core or w.server._self_operating_reads is not w
                or w.instance.check()['selfOperatingRead']['instance_id']!=self.instance_id
                or self.core.store.directory!=w.instance.directory/'data'):
            _fail('SCOPE','本机抖音保存范围已变化')
        saved,account=self.helper._account(frame['token'],frame['account']['id'],metadata=frame['metadata'],reading=not frame['metadata'])
        identity=lambda item:{k:item.get(k) for k in ('id','tenant_id','cloud_owner','platform','platform_uid','conn_id')}
        if (saved!=frame['user'] or identity(account)!=identity(frame['account'])
                or not frame['metadata'] and account!=frame['account']
                or user is not None and saved!=user or type(account.get('platform_uid')) is not str
                or re.fullmatch(r'[0-9]{1,160}',account['platform_uid']) is None
                or not account['platform_uid'].strip('0')):
            _fail('SCOPE','原本人抖音账号或UID范围已变化')
        if not frame['metadata']:
            self.service.permit.current(frame['revision']);self.helper.execution_guard()
        elif frame.get('write_revision') is not None:
            # Only newly created tombstones are writes. Existing receipt
            # recovery never borrows or requires current storage approval.
            self.service.permit.current(frame['write_revision'])
        return saved,account

    def guard(self):self.check();return True

    @contextmanager
    def call(self,token,account,*,metadata=False):
        if (getattr(self._tls,'frame',None) is not None
                or getattr(self.workspace._tls,'call',None) is not None):
            _fail('SCOPE','本机抖音归档不能借XHS或嵌套范围')
        user,current=self.helper._account(token,account['id'],metadata=metadata,reading=not metadata)
        if current!=account:_fail('SCOPE','本机抖音归档开始前账号已变化')
        revision=None if metadata else self.service.review_storage_write()
        frame={'scope':self,'thread':threading.get_ident(),'token':token,'user':user,
            'account':deepcopy(account),'metadata':metadata,'revision':revision}
        self._tls.frame=frame
        try:
            if metadata:self.check();yield
            else:
                with self.helper._call(token,account,'comments'):
                    self.check();yield
                    self.check()
        finally:
            if getattr(self._tls,'frame',None) is frame:del self._tls.frame

    def require_storage_write(self,user):
        self.check(user)
        self._tls.frame['write_revision']=self.service.review_storage_write()
        self.check(user)

    def require_action(self,action):
        self.check()
        expected='platform_read_archive_status' if self._tls.frame['metadata'] else 'platform_read_archive'
        if action!=expected:_fail('SCOPE','本机抖音回执核对不能借作新保存或平台执行')

    def receipt_binding(self,user):
        saved,account=self.check(user)
        return {'schema':'local_owner_douyin_archive_v1','local_instance_id':self.instance_id,
            'account_id':account['id'],'account_digest':_digest({k:account.get(k) for k in
                ('id','tenant_id','cloud_owner','platform','platform_uid','conn_id')}),
            'actor_digest':_digest({k:saved.get(k) for k in
                ('id','tenant_id','username','role','cloud_bound','personal_owner')})}

    def check_receipt(self,user,binding):
        if binding!=self.receipt_binding(user):_fail('SCOPE','原抖音保存回执本人范围已变化')

    def snapshot_check(self,entry,user,account):
        from .owner_douyin_read import _OwnerDouyinOrigin
        self.check(user)
        origin=entry.get('_owner_douyin_origin')
        result=entry.get('response')
        if (entry.get('account_id')!=account['id'] or entry.get('running') or entry.get('cancelled')
                or type(origin) is not _OwnerDouyinOrigin or not origin.current(self.helper.scope)
                or not self.helper.scope.entry_current(entry,user,account)
                or type(result) is not dict or result.get('platform')!='douyin'
                or result.get('action')!='comments' or result.get('code')!='completed'
                or result.get('limit_exceeded') is not False or result.get('requested_limit')!=20
                or type(result.get('items')) is not list or not 1<=len(result['items'])<=20
                or type(entry.get('observed_at')) not in (int,float)
                or not math.isfinite(entry['observed_at'])):
            _fail('SOURCE','原抖音评论未确认、已取消、超界或原窗口来源需核对')

    def store_source_trace(self,*args):
        # The original transaction seam cannot lend XHS search provenance to Dy.
        self.check()

class OwnerDouyinSourceArchive:
    ACTIONS=frozenset(('owner_douyin_source_archive','owner_douyin_source_archive_status'))
    HISTORY_ACTIONS=frozenset(('owner_douyin_saved_history_page','owner_douyin_saved_history_detail'))
    def __init__(self,workspace):
        from .self_operating_read import OwnerReadWorkspace
        from .owner_douyin_read import OwnerDouyinRead
        if (type(workspace) is not OwnerReadWorkspace or type(workspace._douyin) is not OwnerDouyinRead
                or type(workspace._reads) is not PlatformReadService):
            _fail('SCOPE','本机抖音保存须绑定原本人读取服务')
        self.workspace=workspace;self.permit=_StoragePermit(self);self._unknown={}
        self.scope=_OwnerDouyinArchiveScope(self,_SEAL)
        if workspace._reads._owner_douyin_archive_scope is not None:_fail('SCOPE','本机抖音保存范围不能重绑')
        workspace._reads._owner_douyin_archive_scope=self.scope
        self.archive=None

    def describe(self):
        try:self.permit.review();state='reviewed'
        except (ValueError,CoreError,OSError,TypeError,KeyError):state='pending'
        return {'contract':_CONTRACT,'available':True,'status':state,'limit':20,'auto_retry':False,
            'platform_requests_started':False,'AI_started':False,'real_platform_verified':False}

    def describe_history(self):
        return {'contract':_HISTORY,'available':True,'page_limit':50,'scan_limit':200,
            'detail_limit':20,'read_only':True,'auto_retry':False,'platform_requests_started':False}

    def source_pool_item(self,token,user,account,lead_id,source):
        """Project only a canonical Dy source with its original successful PRA.

        Reuse the history factory and proof; this metadata read neither grants
        current platform use nor invokes PRA status/execute or creates a key.
        """
        if type(source) is not dict or source.get('lead_id')!=lead_id:
            _fail('POOL_SOURCE','原抖音来源定位需核对')
        with self.scope.call(token,account,metadata=True):
            archive=self._service(user);actor=archive._principal(user)
            with archive.store.connect() as db:
                db.execute('BEGIN')
                safe=self._history_source(db,archive,actor,account,lead_id)
                records=db.execute('''SELECT r.body FROM records AS r JOIN records AS b
                    ON b.entity=? AND b.tenant_id=r.tenant_id AND b.id=json_extract(r.body,'$.batch_id')
                    WHERE r.entity=? AND r.tenant_id=?
                      AND json_extract(r.body,'$.local_owner_scope.account_id')=?
                      AND EXISTS (SELECT 1 FROM json_each(b.body,'$.lead_ids') AS member WHERE member.value=?)
                    ORDER BY r.id LIMIT 200''',
                    (BATCHES,RECEIPTS,actor['tenant_id'],account['id'],lead_id)).fetchall()
                for row in records:
                    projected=self._history_projection(db,archive,actor,account,json.loads(row['body']))
                    if projected is not None:
                        archive._principal(actor)
                        if safe['source_id']!=source.get('id'):
                            _fail('POOL_SOURCE','原抖音来源定位已变化')
                        return safe
                _fail('POOL_RECEIPT','所选抖音来源缺少原成功保存批与回执')

    def _history_source(self,db,archive,user,account,lead_id):
        # The canonical source is immutable across deduplicated save events.
        # Its input digest is NOT required to equal a later event batch digest.
        lead=archive._row(db,'leads',lead_id)
        if (not lead or lead.get('cloud_owner')!=archive.owner or lead.get('task_id') or lead.get('demo')
                or lead.get('platform')!='douyin' or lead.get('source_type')!='comment'
                or lead.get('readonly_archive') is not True or lead.get('can_reply') is not False
                or lead.get('reply_target_status')!='not_verified'
                or any(lead.get(k) not in (None,'') for k in
                    ('author_id','comment_id','target_comment_id','target_author_id'))
                or type(lead.get('source_uid')) is not str):
            _fail('HISTORY_SOURCE','原抖音本机安全来源需核对，不返回自由内容')
        ident=_hash([user['tenant_id'],lead['source_uid']])
        source=archive._row(db,SOURCES,ident)
        routing={k:lead.get(k) for k in ('platform','source_id','source_type','note_url','url',
            'comment_id','author_id','target_comment_id','target_author_id')}
        if (not source or source.get('lead_id')!=lead_id or source.get('cloud_owner')!=archive.owner
                or source.get('source_uid')!=lead['source_uid'] or source.get('platform')!='douyin'
                or source.get('device_id')!=self.scope.instance_id or source.get('actor_id')!=user['id']
                or source.get('actor_role')!=user['role'] or source.get('account_id')!=account['id']
                or source.get('account_uid')!=account['platform_uid']
                or source.get('connection_digest')!=_digest([account.get('conn_id') or ''])
                or source.get('lead_text_hash')!=_hash(lead.get('text') or '')
                or source.get('safe_text_hash')!=_hash(lead.get('text') or '')
                or source.get('lead_source_digest')!=_hash(routing)
                or source.get('privacy_redacted')!=lead.get('privacy_redacted')
                or type(source.get('privacy_redacted')) is not bool
                or source.get('real_platform_verified') is not False or source.get('reply_target_verified') is not False
                or source.get('storage_scope')!='this_device' or source.get('evidence_level')!='transport_reported'
                or any(type(source.get(k)) is not str or not _HEX.fullmatch(source[k]) for k in
                    ('account_binding_digest','connection_digest','license_digest','input_digest','original_text_hash'))):
            _fail('HISTORY_SOURCE','原抖音保存来源、正文、隐私或本人范围需核对')
        post_id,_=source_reference('douyin',lead.get('note_url') or lead.get('url'))
        if (post_id!=source.get('post_id') or type(source.get('comment_id')) is not str
                or _ident(source['comment_id'])!=source['comment_id']
                or type(source.get('author_id')) is not str
                or (source['author_id']!='' and _ident(source['author_id'])!=source['author_id'])
                or source.get('author_identity')!=('platform_id' if source['author_id'] else 'not_provided')
                or lead['source_uid']!='douyin:'+_digest(['comment',post_id,source['comment_id']])):
            _fail('HISTORY_SOURCE','原抖音作品或评论身份已变化')
        safe={}
        for name,maximum in (('text',3000),('title',1000),('author',300),('region',200),('published_at',100)):
            value=lead.get(name)
            if name=='published_at' and type(value) is str and re.fullmatch(
                    r'\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})?)?',value):
                safe[name]=value
            else:
                projected,changed=_safe_text(value,maximum)
                if changed:_fail('HISTORY_SOURCE','原显示字段隐私或内容已变化，不返回自由内容')
                safe[name]=projected
        if not safe['text'].strip():_fail('HISTORY_SOURCE','原安全评论正文需核对')
        return {'source_id':ident,**safe,'privacy_redacted':source['privacy_redacted']}

    def _history_projection(self,db,archive,user,account,record):
        if (type(record) is not dict or record.get('cloud_owner')!=archive.owner
                or record.get('device_id')!=self.scope.instance_id or record.get('actor')!=archive._actor(user)
                or type(record.get('local_owner_scope')) is not dict
                or record['local_owner_scope'].get('account_id')!=account['id']):
            return None
        if record.get('state')=='cancelled':return None
        view=archive._receipt_view(record,user)
        if (view.get('state')!='succeeded' or type(record.get('id')) is not str
                or not _HEX.fullmatch(record['id']) or type(record.get('batch_id')) is not str
                or not _HEX.fullmatch(record['batch_id']) or type(record.get('payload_digest')) is not str
                or not _HEX.fullmatch(record['payload_digest'])
                or type(record.get('created_at')) not in (int,float) or not math.isfinite(record['created_at'])
                or record['created_at']<0 or not 1<=view['accepted_count']<=20
                or len(view['lead_ids'])>20 or any(not _HEX.fullmatch(k) for k in view['lead_ids'])):
            _fail('HISTORY_RECEIPT','原抖音成功保存回执数量或定位需核对')
        batch=archive._row(db,BATCHES,record['batch_id'])
        if (not batch or batch.get('cloud_owner')!=archive.owner or batch.get('device_id')!=self.scope.instance_id
                or batch.get('actor')!=archive._actor(user) or type(batch.get('source_count')) is not int
                or batch['source_count']!=view['accepted_count'] or batch.get('lead_ids')!=view['lead_ids']
                or type(batch.get('created_at')) not in (int,float) or not math.isfinite(batch['created_at'])
                or batch['created_at']<0 or any(type(batch.get(k)) is not str or not _HEX.fullmatch(batch[k])
                    for k in ('batch_digest','input_digest'))):
            _fail('HISTORY_BATCH','原抖音成功保存批与回执证据需核对')
        items=[self._history_source(db,archive,user,account,lead_id) for lead_id in view['lead_ids']]
        if sum(int(item['privacy_redacted']) for item in items)!=view['privacy_redacted_count']:
            _fail('HISTORY_SOURCE','原保存批隐私计数需核对')
        summary={k:view[k] for k in ('accepted_count','inserted','duplicate_count','privacy_redacted_count')}
        summary.update(receipt_id=record['id'],created_at=record['created_at'])
        return summary,items

    def execute_history(self,token,action,data):
        detail=action=='owner_douyin_saved_history_detail'
        if (action not in self.HISTORY_ACTIONS or type(data) is not dict
                or set(data)!=({'account_id','receipt_id'} if detail else {'account_id','limit','cursor'})
                or type(data.get('account_id')) is not str or not _ID.fullmatch(data['account_id'])):
            _fail('HISTORY_INPUT','已保存评论仅接受原账号与只读分页或回执选择')
        if detail:
            if type(data['receipt_id']) is not str or not _HEX.fullmatch(data['receipt_id']):
                _fail('HISTORY_INPUT','请从已保存评论页选择原回执')
        else:
            if type(data['limit']) is not int or not 1<=data['limit']<=50:
                _fail('HISTORY_INPUT','已保存评论页每次仅返回1至50批')
            cursor=data['cursor']
            if cursor is None:cutoff,after=time.time(),''
            else:
                if (type(cursor) is not dict or set(cursor)!={'schema','account_id','cutoff','after'}
                        or cursor['schema']!=_HISTORY_CURSOR or cursor['account_id']!=data['account_id']
                        or type(cursor['cutoff']) not in (int,float) or not math.isfinite(cursor['cutoff'])
                        or not 0<=cursor['cutoff']<=time.time() or type(cursor['after']) is not str
                        or not _HEX.fullmatch(cursor['after'])):
                    _fail('HISTORY_INPUT','原已保存评论游标或账号需核对')
                cutoff,after=cursor['cutoff'],cursor['after']
        user,account=self.workspace._douyin._account(token,data['account_id'],metadata=True)
        with self.scope.call(token,account,metadata=True):
            archive=self._service(user);actor=archive._principal(user)
            with archive.store.connect() as db:
                # Read snapshot only: no PRA.execute/status or new tombstones.
                db.execute('BEGIN')
                if detail:
                    record=archive._row(db,RECEIPTS,data['receipt_id'])
                    projected=self._history_projection(db,archive,actor,account,record)
                    if projected is None:
                        _fail('HISTORY_UNKNOWN','原成功保存回执或范围未确认；不能推断此前未提交')
                    summary,items=projected
                    archive._principal(actor)
                    return {'purpose':action,'batch':summary,'items':items,'returned_count':len(items),**_HISTORY_LOCAL}
                rows=db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? AND id>? ORDER BY id LIMIT 200',
                    (RECEIPTS,actor['tenant_id'],after)).fetchall()
                items=[];examined=review=0;last=after
                for row in rows:
                    last=row['id'];examined+=1
                    try:
                        record=json.loads(row['body'])
                    except (ValueError,TypeError):
                        # No current actor/account can be established from a
                        # malformed body; do not attribute its review count.
                        continue
                    if (type(record) is not dict or record.get('id')!=last
                            or record.get('tenant_id')!=actor['tenant_id']
                            or type(record.get('created_at')) not in (int,float)
                            or not math.isfinite(record['created_at']) or not 0<=record['created_at']<=cutoff):
                        continue
                    try:
                        projected=self._history_projection(db,archive,actor,account,record)
                    except (CoreError,ValueError,TypeError,KeyError):
                        review+=1;continue
                    if projected is None:continue
                    items.append(projected[0])
                    if len(items)==data['limit']:break
                archive._principal(actor)
                more=examined<len(rows) or len(rows)==200
                next_cursor={'schema':_HISTORY_CURSOR,'account_id':account['id'],'cutoff':cutoff,'after':last} if more else None
                return {'purpose':action,'items':items,'returned_count':len(items),'scanned_count':examined,
                    'needs_review_count':review,'page':{'has_more':more,'next_cursor':next_cursor,'cutoff':cutoff,
                    'scope':'this_instance_owner_account','snapshot_verified':False},**_HISTORY_LOCAL}

    def review_storage_write(self):
        try:return self.permit.review()
        except (ValueError,CoreError,OSError,TypeError,KeyError):
            _fail('PERMIT_PENDING','本机抖音保存尚待独立审查，本次没有写入')

    def _service(self,user):
        if self.archive is None:
            self.archive=PlatformReceiptArchive(self.workspace.server.core,user['tenant_id'],user['username'],
                self.workspace.server.company,read_service=self.workspace._reads,device_id=self.scope.instance_id,
                scope_guard=self.scope.guard,owner_scope=self.scope)
        return self.archive

    def can_offer(self,token,account_id,request):
        try:
            self.permit.review();user,account=self.workspace._douyin._account(token,account_id,reading=True)
            with self.workspace._reads._lock:
                entry=self.workspace._reads._operations.get(request)
                if entry is None:return False
                from .owner_douyin_read import _OwnerDouyinOrigin
                origin=entry.get('_owner_douyin_origin');result=entry.get('response') or {}
                return (type(origin) is _OwnerDouyinOrigin and origin.current(self.workspace._douyin.scope)
                    and self.workspace._douyin.scope.entry_current(entry,user,account)
                    and not entry.get('running') and not entry.get('cancelled')
                    and result.get('code')=='completed' and result.get('limit_exceeded') is False
                    and result.get('requested_limit')==20 and 1<=len(result.get('items',[]))<=20)
        except (ValueError,CoreError,OSError,TypeError,KeyError):return False

    def execute(self,token,action,data):
        status=action=='owner_douyin_source_archive_status'
        if (action not in self.ACTIONS or type(data) is not dict
                or set(data)!=({'account_id','idempotency_key'} if status else {'account_id','read_request_id','idempotency_key'})
                or type(data.get('account_id')) is not str or not _ID.fullmatch(data['account_id'])
                or type(data.get('idempotency_key')) is not str or not _KEY.fullmatch(data['idempotency_key'])
                or not status and (type(data.get('read_request_id')) is not str or not _KEY.fullmatch(data['read_request_id']))):
            _fail('INPUT','本机抖音保存只接受原账号、原读取及原保存编号')
        user,account=self.workspace._douyin._account(token,data['account_id'],metadata=status,reading=not status)
        key=data['idempotency_key'];pair=(user['id'],account['id'])
        if not status and key in self._unknown:_fail('UNKNOWN','原保存结果未确认，只能核对原编号',unknown=True)
        try:
            with self.scope.call(token,account,metadata=status):
                archive=self._service(user)
                fields={'idempotency_key':key} if status else data
                result=archive.execute('platform_read_archive_status' if status else 'platform_read_archive',fields,user)
                if result.get('state')=='succeeded' and (result.get('accepted_count',101)>20
                        or len(result.get('lead_ids',[]))>20):
                    _fail('SOURCE','原抖音保存回执数量超界，请只核对原号',unknown=True)
                self._unknown.pop(key,None)
                return result
        except ReceiptArchiveError as ex:
            if ex.mutation_committed is None:self._unknown[key]=pair
            raise
        except Exception:
            self._unknown[key]=pair
            _fail('UNKNOWN','原本机抖音保存交付未确认，请只核对原编号',unknown=True)
