"""Staged owned self-identity observation; no production dispatcher or login.

The host supplies a current selected-account scope and an authorization callback.
Neither a user payload, a cookie UID, nor account_save can supply identity proof.
"""
from contextlib import closing
from dataclasses import asdict, dataclass
from hashlib import sha256
from hmac import compare_digest
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import time
from urllib.parse import urljoin, urlsplit

from .weibo_read_contract import IdentityScope, VerifiedIdentity

import httpx
from weibo_cli.auth import Credential
from weibo_cli.client import WeiboClient
from weibo_cli.constants import BASE_URL, HEADERS
from platform_cli import activity_checkpoint, record_request_event

SELF_ROUTE = '/ajax/profile/me'  # Actual upstream commands/auth.py me first route.


class IdentityStopped(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)






def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _no_links(path):
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if not current.exists():
            continue
        attrs = getattr(current.lstat(), 'st_file_attributes', 0)
        if current.is_symlink() or attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
            raise IdentityStopped('scope_path_invalid')


def _scope_dict(scope):
    return {key: value for key, value in asdict(scope).items()
            if key not in ('account_root', 'license_approved')}


def _credential(scope, ignore_request_id=None):
    if not isinstance(scope, IdentityScope):
        raise IdentityStopped('trusted_scope_required')
    for value in (scope.tenant_id, scope.account_id, scope.device_id,
                  scope.account_revision, scope.license_revision):
        if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,160}', value):
            raise IdentityStopped('scope_invalid')
    if (not isinstance(scope.owner, str) or not scope.owner or len(scope.owner) > 160
            or any(ord(ch) < 32 for ch in scope.owner)):
        raise IdentityStopped('scope_invalid')
    root = Path(scope.account_root)
    if (not root.is_absolute() or '..' in root.parts or not root.is_dir()
            or root.name != scope.account_id or root.parent.name != scope.tenant_id):
        raise IdentityStopped('scope_path_invalid')
    _no_links(root)
    root = root.resolve(strict=True)
    for name in ('HOME', 'USERPROFILE'):
        value = os.environ.get(name)
        if not value or Path(value).resolve() != root:
            raise IdentityStopped('scope_environment_invalid')
    journal = root / 'platform-activity.jsonl'
    value = os.environ.get('WORKSPACE_ACTIVITY_LOG')
    if (os.environ.get('LEADSTUDIO_ISOLATED') != '1'
            or os.environ.get('WORKSPACE_ACTIVITY_KIND') != 'whoami'
            or not value or Path(value).resolve() != journal):
        raise IdentityStopped('scope_environment_invalid')
    _no_links(journal)
    if journal.exists() and not journal.is_file():
        raise IdentityStopped('scope_path_invalid')
    if activity_checkpoint(ignore_request_id=ignore_request_id)[0]:
        raise IdentityStopped('account_review_required')
    path = root / '.config/weibo-cli/credential.json'
    _no_links(path)
    if not path.is_file() or path.stat().st_size > 1024 * 1024:
        raise IdentityStopped('saved_credential_required')
    raw = path.read_bytes()
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        raise IdentityStopped('saved_credential_invalid') from None
    cookies = data.get('cookies') if isinstance(data, dict) else None
    if (not isinstance(cookies, dict) or not {'SUB', 'SUBP'} <= set(cookies)
            or not 1 <= len(cookies) <= 100
            or any(not isinstance(key, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', key)
                   or not isinstance(value, str) or not value or len(value) > 16384
                   or any(ch in value for ch in ('\r', '\n', ';')) for key, value in cookies.items())):
        raise IdentityStopped('saved_credential_invalid')
    # Never call get/load/extract/save_credential. Cookie UID is intentionally ignored.
    return Credential.from_dict(data), sha256(raw).hexdigest()


def _self_uid(payload):
    if (not isinstance(payload, dict) or type(payload.get('ok')) is not int
            or payload['ok'] != 1 or not isinstance(payload.get('data'), dict)):
        raise IdentityStopped('self_identity_unconfirmed')
    data = payload['data']
    user = data.get('user', data)
    if not isinstance(user, dict):
        raise IdentityStopped('self_identity_unconfirmed')
    values = [user.get(key) for key in ('idstr', 'id', 'uid') if key in user]
    if user is not data and 'uid' in data:
        values.append(data['uid'])
    if not values or any(type(value) not in (str, int)
                         or not re.fullmatch(r'[1-9][0-9]{0,31}', str(value)) for value in values):
        raise IdentityStopped('self_identity_unconfirmed')
    ids = {str(value) for value in values}
    if len(ids) != 1:
        raise IdentityStopped('self_identity_conflict')
    return ids.pop()


class _SelfClient(WeiboClient):
    def __init__(self, credential, guard, transport, timeout):
        super().__init__(credential, timeout=timeout, max_retries=1)
        self.guard, self.transport = guard, transport
        self.deadline, self.used = time.monotonic() + timeout, False
        self.raw = None

    def _build_client(self):
        return httpx.Client(base_url=BASE_URL, headers=dict(HEADERS), cookies=self.credential.cookies,
                            follow_redirects=False, trust_env=False, timeout=self._timeout,
                            transport=self.transport)

    def _request(self, method, url, *, client=None, **kwargs):
        parsed = urlsplit(urljoin(BASE_URL, url))
        if (method != 'GET' or parsed.scheme != 'https' or parsed.netloc != 'weibo.com'
                or parsed.path != SELF_ROUTE or parsed.query or parsed.fragment
                or client is not None or kwargs != {'params': None} or self.used):
            raise IdentityStopped('self_route_rejected')
        self.guard()
        _, last = activity_checkpoint()
        if last:
            self._last_request_time = min(last, time.time())
        self._rate_limit_delay()
        # Current host authority and exact saved bytes are rechecked AFTER pacing.
        self.guard()
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise IdentityStopped('time_budget_exhausted')
        request_id = secrets.token_hex(8)
        record_request_event('started', request_id, method)
        status, http_status = 'cancelled_before_send', None
        started = time.monotonic()
        try:
            self.guard(ignore_request_id=request_id)
            remaining = self.deadline - time.monotonic()
            if remaining <= 0:
                raise IdentityStopped('time_budget_exhausted')
            self.used = True
            status = 'transport_error'
            # No upstream retry, fallback/profile/config request or cookie merge.
            response = self.client.request('GET', SELF_ROUTE, follow_redirects=False, timeout=remaining)
            http_status = response.status_code
            if http_status != 200:
                status = (http_status if http_status in (401, 403, 429) or 300 <= http_status < 400
                          else 'transport_error')
                raise IdentityStopped('self_read_hold')
            if len(response.content) > 1024 * 1024:
                status = 'protocol_error'
                raise IdentityStopped('self_identity_unconfirmed')
            try:
                payload = response.json()
                _self_uid(payload)
            except (ValueError, UnicodeError, IdentityStopped):
                status = 'protocol_error'
                raise IdentityStopped('self_identity_unconfirmed') from None
            self.raw = payload
            status = 200
            self._mark_request()
            return payload
        except IdentityStopped:
            raise
        except Exception:
            raise IdentityStopped('self_read_hold') from None
        finally:
            record_request_event('finished', request_id, method, status=status, http_status=http_status,
                                 elapsed_ms=(time.monotonic() - started) * 1000)


class IdentityService:
    def __init__(self, scope_provider, *, authorize, timeout=30):
        if (not callable(scope_provider) or not callable(authorize)
                or type(timeout) not in (int, float) or not 0 < timeout <= 35):
            raise IdentityStopped('trusted_host_required')
        self.scope_provider, self.authorize, self.timeout = scope_provider, authorize, timeout

    def _guard(self, original=None, fingerprint=None, *, ignore_request_id=None):
        try:
            current = self.scope_provider()
            if not isinstance(current, IdentityScope):
                raise IdentityStopped('trusted_scope_required')
            if current.license_approved is not True:
                raise IdentityStopped('license_hold')
            if self.authorize(current) is not True:
                raise IdentityStopped('authorization_hold')
        except IdentityStopped:
            raise
        except Exception:
            raise IdentityStopped('authorization_hold') from None
        if original is not None and current != original:
            raise IdentityStopped('scope_changed')
        credential, digest = _credential(current, ignore_request_id)
        if fingerprint is not None and not compare_digest(fingerprint, digest):
            raise IdentityStopped('credential_changed')
        return current, credential, digest

    @staticmethod
    def _database(scope):
        path = Path(scope.account_root) / 'work/weibo-identity/receipts.sqlite3'
        _no_links(path)
        return path

    def observe(self, *, transport=None):
        scope, credential, fingerprint = self._guard()
        guard = lambda **kwargs: self._guard(scope, fingerprint, **kwargs)
        with _SelfClient(credential, guard, transport, self.timeout) as client:
            # Genuine vendor _get + _handle_response; no stock me fallback wrapper.
            client._get(SELF_ROUTE, action='个人资料')
            raw = client.raw
        guard()
        receipt = 'wb-self-' + secrets.token_hex(16)
        proof = {**_scope_dict(scope), 'identity_receipt_id': receipt,
                 'platform_uid': _self_uid(raw), 'credential_sha256': fingerprint,
                 'response_sha256': sha256(_canonical(raw).encode('utf-8')).hexdigest(),
                 'self_route': SELF_ROUTE, 'observed_at': time.time(),
                 'evidence': 'owned_self_http_response', 'production_available': False}
        path = self._database(scope)
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(path)) as db, db:
            db.execute('PRAGMA synchronous=FULL')
            db.execute('CREATE TABLE IF NOT EXISTS identity_receipts (id TEXT PRIMARY KEY, proof TEXT NOT NULL, digest TEXT NOT NULL)')
            db.execute('BEGIN IMMEDIATE')
            guard()
            serialized = _canonical(proof)
            db.execute('INSERT INTO identity_receipts VALUES (?, ?, ?)',
                       (receipt, serialized, sha256(serialized.encode('utf-8')).hexdigest()))
            guard()  # Scope/credential changes roll the transaction back.
        # Do not set account ready, grant an entitlement or unlock production.
        return {'identity_receipt_id': receipt, 'platform_uid': proof['platform_uid'],
                'status': 'identity_observed', 'production_available': False,
                'real_platform_verified': False, 'auto_retry': False}

    def binding(self, receipt_id):
        scope, _, fingerprint = self._guard()
        if not isinstance(receipt_id, str) or not re.fullmatch(r'wb-self-[0-9a-f]{32}', receipt_id):
            raise IdentityStopped('original_receipt_required')
        path = self._database(scope)
        if not path.is_file():
            raise IdentityStopped('original_receipt_required')
        with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
            row = db.execute('SELECT proof, digest FROM identity_receipts WHERE id=?', (receipt_id,)).fetchone()
        if not row or not compare_digest(sha256(row[0].encode('utf-8')).hexdigest(), row[1]):
            raise IdentityStopped('original_receipt_invalid')
        try:
            proof = json.loads(row[0])
            if any(proof.get(key) != value for key, value in _scope_dict(scope).items()):
                raise IdentityStopped('scope_changed')
            if not compare_digest(proof['credential_sha256'], fingerprint):
                raise IdentityStopped('credential_changed')
            if (proof['identity_receipt_id'] != receipt_id or proof['self_route'] != SELF_ROUTE
                    or proof['evidence'] != 'owned_self_http_response'
                    or not re.fullmatch(r'[1-9][0-9]{0,31}', proof['platform_uid'])):
                raise IdentityStopped('original_receipt_invalid')
            self._guard(scope, fingerprint)
            return VerifiedIdentity(**{key: proof[key] for key in VerifiedIdentity.__dataclass_fields__
                if key != 'receipt_sha256'}, receipt_sha256=row[1])
        except (KeyError, TypeError, ValueError):
            raise IdentityStopped('original_receipt_invalid') from None

    def handoff_registered_identity(self, original, new_account_revision, registration_id):
        """Private owned-host registration handoff; never an authorization grant.

        The fixed parent channel supplies a transition minted by its account
        transaction. Its live guard must still authorize every call. Only the
        account revision changes; the old receipt/digest/scope and exact saved
        credential/self response remain immutable. No GET or retry is made.
        """
        scope, _, fingerprint = self._guard()
        if (type(original) is not VerifiedIdentity
                or not isinstance(registration_id, str)
                or not re.fullmatch(r'wb-reg-[0-9a-f]{32}', registration_id)
                or not isinstance(new_account_revision, str)
                or not re.fullmatch(r'[0-9a-f]{64}', new_account_revision)
                or scope.account_revision != new_account_revision
                or scope.account_revision == original.account_revision
                or not re.fullmatch(r'wb-self-[0-9a-f]{32}', original.identity_receipt_id)
                or any(not isinstance(value, str) or not re.fullmatch(r'[0-9a-f]{64}', value)
                       for value in (original.receipt_sha256, original.credential_sha256, original.response_sha256))):
            raise IdentityStopped('registration_handoff_invalid')
        expected = {key: getattr(original, key) for key in _scope_dict(scope)}
        expected['account_revision'] = new_account_revision
        if _scope_dict(scope) != expected:
            raise IdentityStopped('scope_changed')
        if not compare_digest(original.credential_sha256, fingerprint):
            raise IdentityStopped('credential_changed')
        guard = lambda: self._guard(scope, fingerprint)
        path = self._database(scope)
        if not path.is_file():
            raise IdentityStopped('original_receipt_required')
        receipt = 'wb-self-' + secrets.token_hex(16)
        with closing(sqlite3.connect(path)) as db, db:
            db.execute('PRAGMA synchronous=FULL')
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT proof,digest FROM identity_receipts WHERE id=?',
                (original.identity_receipt_id,)).fetchone()
            if (not row or len(row[0]) > 16384
                    or not compare_digest(row[1], original.receipt_sha256)
                    or not compare_digest(sha256(row[0].encode('utf-8')).hexdigest(), row[1])):
                raise IdentityStopped('original_receipt_invalid')
            try:
                proof = json.loads(row[0])
                fields = {key: proof[key] for key in VerifiedIdentity.__dataclass_fields__
                    if key != 'receipt_sha256'}
                if (VerifiedIdentity(**fields, receipt_sha256=row[1]) != original
                        or proof['self_route'] != SELF_ROUTE
                        or proof['evidence'] != 'owned_self_http_response'
                        or not re.fullmatch(r'[1-9][0-9]{0,31}', proof['platform_uid'])):
                    raise IdentityStopped('original_receipt_invalid')
            except (KeyError, TypeError, ValueError):
                raise IdentityStopped('original_receipt_invalid') from None
            guard()
            rebound = {**proof, 'identity_receipt_id': receipt,
                'account_revision': new_account_revision, 'registration_id': registration_id,
                'original_identity_receipt_id': original.identity_receipt_id,
                'original_identity_receipt_sha256': original.receipt_sha256}
            serialized = _canonical(rebound)
            db.execute('INSERT INTO identity_receipts VALUES(?,?,?)',
                (receipt, serialized, sha256(serialized.encode('utf-8')).hexdigest()))
            guard()  # Concurrent identity/permission/credential changes rollback.
        # Reuse the original full receipt/scope/credential contract, not a
        # constructed VerifiedIdentity or an old proof in a new scope.
        return self.binding(receipt)
