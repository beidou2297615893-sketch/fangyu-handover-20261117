"""Bounded internal DM CLI, original adapter lifecycle/account isolation only."""
from pathlib import Path
import hashlib,re

CONTRACT='fangyu-dm-bounded-v1'
PINS={'lib/server/dm.js': '540a863f342a4ec01711c00a2928160d3a6de93e7fe20073d81615c7cb9590e5', 'lib/server/registry.js': '5664a6d5a335230c2d1fc61d638c7b2dddd41155f73b38bdf302df7c71e23734', 'lib/server/router.js': '44a5164fa1e3bed5213d4e969d4a0359527d3cfac268bfa7e1c66af7e0337696', 'lib/client/bridge-client.js': 'ed1c6439b0d0436c2a91f5f2b5ce84ce8fed86b8f9d6255a2304809158902c45', 'dm_workbench_cli.js': 'ca90b625650659e9eebdeca842181fe2088cdfd0b728ecac4aafea02aa1bdfad', 'scripts/douyin.user.js': '078df0041b0131a0a3a747e75277d64728502561f6a9c12b2ed240ffc025a532', 'lib/dm_workbench_browser.js': 'b0847e7a4cb2804317d1001786baa0b0fa9cc8ad333457e065bb37266f64db8b'}
def direct_messages(adapters,account,operation,request_id,directory,*,guard,timeout_ms=20000,recipient='',text=''):
 from .adapters import account_execution_lock
 if account.get('platform')!='douyin' or operation not in ('listen','stop','send') or not callable(guard):raise ValueError('私信只允许固定的抖音命令')
 if (not re.fullmatch('[A-Za-z0-9_-]{8,160}',request_id or '') or not re.fullmatch('[1-9][0-9]{0,24}',str(account.get('platform_uid') or '')) or not re.fullmatch('[A-Za-z0-9_-]{1,160}',str(account.get('conn_id') or ''))):raise ValueError('私信缺少已核对的账号身份、固定窗口或原操作编号')
 manifest=adapters.manifest('douyin')
 if int(account['platform_uid'])>18446744073709551615:raise ValueError('账号平台编号超出64位范围')
 root=Path(manifest['search_args'][0]).parent
 for relative,pin in PINS.items():
  path=root/relative
  if path.is_symlink() or getattr(path.lstat(),'st_file_attributes',0)&0x400 or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=pin:raise ValueError('私信执行组件发生变化，请重新核验')
 if len(PINS)!=7:raise ValueError('私信执行组件尚未封定')
 if operation=='send' and manifest.get('dm_contract_verified') is not True:raise ValueError('此账号私信送出合同尚未经本人核验，草稿保留')
 args=[str(root/'dm_workbench_cli.js'),operation,'--conn-id',account['conn_id'],'--expected-uid',str(account['platform_uid']),'--request-id',request_id]
 if operation=='listen':
  if type(timeout_ms) is not int or not 100<=timeout_ms<=20000:raise ValueError('监听须在20秒内结束')
  args+=['--timeout',str(timeout_ms)]
 if operation=='send':
  if not re.fullmatch('[1-9][0-9]{0,24}',recipient or '') or recipient==str(account['platform_uid']) or type(text) is not str or not text.strip() or len(text)>1000:raise ValueError('私信收件人或正文无效')
  if int(recipient)>18446744073709551615:raise ValueError('收件人编号超出64位范围')
  args+=['--recipient',recipient,'--text',text]
 if getattr(adapters._dm_calls,'guard',None) is not None:raise ValueError('私信命令不能嵌套')
 with account_execution_lock(directory):
  adapters._dm_calls.guard=guard
  try:
   guard()
   value=adapters.execute('douyin',args,directory,job_id='dm:'+request_id,timeout=35)
   if not isinstance(value,dict) or value.get('contract')!=CONTRACT or value.get('request_id')!=request_id:raise ValueError('私信原请求回执不明确，禁止自动重试')
   return value
  finally:del adapters._dm_calls.guard
