"""Owner-only passive pre-navigation adapter, source candidate.

No Cookie access, browser discovery, DOM filling, clicking, or platform API
request. A parent-authorized canonical navigation must follow Network.enable.
The source helper remains disabled while this batch's purpose review is pending.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import sys
import threading
import time
from types import SimpleNamespace
from urllib.parse import urlsplit

from owned_natural_reader import _NativeOwner
from .native_contact_observer import NativeContactError
from .tracked_reply_window import (ReplyWindowSpec, TrackedReplyWindow,
    GETME_URL, POST_URL, MAX_EVENT, MAX_BODY, MAX_ATTEMPTS, _api_url, _json,
    _note_url, _safe_id, _REQUEST_ID)


def _pack(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


class _PreNavigationPassiveObserver:
    """Same owned Native Core, bounded early GETME, original strict correlator."""
    def __init__(self, window, spec, *, native=None):
        if window is None or type(spec) is not ReplyWindowSpec:
            raise NativeContactError('owned_window_scope_invalid')
        self.window, self.spec = window, spec
        self.native = native
        self.tracked = TrackedReplyWindow(spec)
        self.lock = threading.RLock()
        self._refs = None
        self._navigation_attached = False
        self._core = None
        self._control = None
        self._enabled = self._issued = self._navigation_consumed = False
        self._bound = self._closed = False
        self._error = ''
        self._started = None
        self._document = None
        self._early = []
        self._early_ids = {}
        self._early_bytes = 0
        self._pending_post = []
        self._pending_body = []

    def _fail(self, code):
        self._error = code
        self.tracked.invalidate(code)
        self._early.clear()
        self._early_ids.clear()
        self._early_bytes = 0
        self._pending_post.clear()
        self._pending_body.clear()

    def _remember(self, kind, value):
        size = len(_pack(value).encode('utf-8'))
        if (self._started is None or time.monotonic()-self._started > 10
                or len(self._early) >= 64 or self._early_bytes+size > MAX_BODY*2):
            self._fail('early_event_limit')
            return False
        self._early.append((kind, value))
        self._early_bytes += size
        return True

    @staticmethod
    def _request_projection(value):
        request = value.get('request')
        if type(request) is not dict:
            return None
        # Deliberately do not retain headers, Cookie, postData, initiator, URLs
        # outside the two exact endpoints / parent-granted canonical document.
        result = {key:value.get(key) for key in ('requestId', 'frameId', 'loaderId', 'type')}
        result['request'] = {key:request.get(key) for key in ('method', 'url')}
        if value.get('redirectResponse') is not None:
            result['redirectResponse'] = {'present':True}
        return result

    def attach_before_navigation(self):
        if self._refs is not None or self._closed:
            raise NativeContactError('native_state_invalid')
        self.native = self.native or _NativeOwner(self.window)
        self.native.invoke(self._subscribe_ui)
        task = self._enable_task
        if not task.Wait(10000) or task.IsCanceled or task.IsFaulted:
            self._fail('native_cdp_unavailable')
            raise NativeContactError('native_cdp_unavailable')
        self._enabled = True
        return self

    def _subscribe_ui(self):
        control, core = self.native.core()
        if core is None or str(core.Source) != 'about:blank':
            raise NativeContactError('native_document_unverified')
        self._control, self._core = control, core
        receivers = []
        def subscribe(name, handler):
            receiver = core.GetDevToolsProtocolEventReceiver(name)
            receiver.DevToolsProtocolEventReceived += handler
            receivers.append((receiver, handler))

        def navigation(_sender, args):
            with self.lock:
                if (not self._issued or self._navigation_consumed
                        or not _note_url(str(args.Uri), self.spec.note_id)
                        or bool(getattr(args, 'IsRedirected', False))):
                    self._fail('navigation_changed')
                    return
                self._navigation_consumed = True

        def request(_sender, args):
            try:
                self._on_request(str(args.ParameterObjectAsJson), str(args.SessionId))
            except Exception:
                with self.lock:
                    self._fail('cdp_read_unavailable')

        def response(_sender, args):
            try:
                self._on_response(str(args.ParameterObjectAsJson), str(args.SessionId))
            except Exception:
                with self.lock:
                    self._fail('cdp_read_unavailable')

        def finished(_sender, args):
            try:
                self._on_finished(str(args.ParameterObjectAsJson), str(args.SessionId))
            except Exception:
                with self.lock:
                    self._fail('cdp_read_unavailable')

        def failed(_sender, args):
            value = _json(str(args.ParameterObjectAsJson), 8192)
            with self.lock:
                if value and value.get('requestId') in self._early_ids:
                    self._fail('early_identity_unavailable')
                elif value:
                    self.tracked.body_unavailable(value.get('requestId'))

        control.NavigationStarting += navigation
        self._navigation_attached = True
        self._refs = (control, navigation, receivers)
        subscribe('Network.requestWillBeSent', request)
        subscribe('Network.responseReceived', response)
        subscribe('Network.loadingFinished', finished)
        subscribe('Network.loadingFailed', failed)
        self._enable_task = core.CallDevToolsProtocolMethodAsync('Network.enable', _pack({
            'maxResourceBufferSize':MAX_BODY, 'maxTotalBufferSize':MAX_BODY*2,
            'maxPostDataSize':0}))

    def activate(self, note_url):
        with self.lock:
            if (self._closed or self._error or not self._enabled or self._issued
                    or not _note_url(note_url, self.spec.note_id)):
                raise NativeContactError('native_navigation_unavailable')
            self._issued = True
            self._started = time.monotonic()
        def issue():
            control, core = self.native.core()
            if (not self.native.same_core(core, self._core)
                    or not self.native.same_core(control, self._control)
                    or str(core.Source) != 'about:blank'):
                raise NativeContactError('owned_window_changed')
            core.Navigate(note_url)
        self.native.invoke(issue)

    def _on_request(self, raw, session_id=''):
        with self.lock:
            if self._closed or self._error or session_id or not self._issued:
                return
            value = _json(raw, MAX_EVENT)
            projected = self._request_projection(value) if value else None
            if projected is None:
                return
            request = projected['request']
            rid = projected['requestId']
            if projected['type'] == 'Document':
                if not _note_url(request['url'], self.spec.note_id):
                    # Child-frame documents are not the Native main document.
                    # Main navigation changes are fenced by NavigationStarting.
                    return
                if request['method'] != 'GET' or projected.get('redirectResponse'):
                    self._fail('document_changed')
                    return
                doc = (request['url'], projected['frameId'], projected['loaderId'])
                if self._document is not None and self._document != doc:
                    self._fail('document_changed')
                    return
                self._document = doc
                if self._bound:
                    self.tracked.request(_pack(projected))
                return
            is_post = request['method'] == 'POST' and _api_url(request['url'], POST_URL)
            is_getme = request['method'] == 'GET' and _api_url(request['url'], GETME_URL)
            if not is_post and not is_getme:
                return
            if not self._bound:
                if is_post:
                    self._fail('post_before_document_verified')
                    return
                if (projected.get('redirectResponse') or type(rid) is not str
                        or _REQUEST_ID.fullmatch(rid) is None
                        or not _safe_id(projected['frameId']) or not _safe_id(projected['loaderId'])
                        or rid in self._early_ids or len(self._early_ids) >= MAX_ATTEMPTS*2):
                    self._fail('early_identity_scope_invalid')
                    return
                if self._remember('request', projected):
                    self._early_ids[rid] = {'frame':projected['frameId'],
                        'loader':projected['loaderId'], 'responded':False, 'finished':False}
                return
            matched = self.tracked.request(_pack(projected))
            if matched and matched[1] == 'post':
                task = self._core.CallDevToolsProtocolMethodAsync('Network.getRequestPostData',
                    _pack({'requestId':matched[0]}))
                self._pending_post.append((matched[0], task))

    def _on_response(self, raw, session_id=''):
        with self.lock:
            if self._closed or self._error or session_id:
                return
            value = _json(raw, MAX_EVENT)
            response = value.get('response') if value else None
            if type(response) is not dict:
                return
            rid = value.get('requestId')
            projected = {key:value.get(key) for key in ('requestId', 'frameId', 'loaderId')}
            projected['response'] = {key:response.get(key) for key in ('url', 'status')}
            if not self._bound:
                record = self._early_ids.get(rid)
                if (record is None or projected['frameId'] != record['frame']
                        or projected['loaderId'] != record['loader']
                        or not _api_url(response.get('url'), GETME_URL)):
                    return
                if self._remember('response', projected):
                    record['responded'] = True
            else:
                self.tracked.response(_pack(projected))

    def _on_finished(self, raw, session_id=''):
        with self.lock:
            if self._closed or self._error or session_id:
                return
            value = _json(raw, MAX_EVENT)
            if value is None:
                return
            projected = {key:value.get(key) for key in ('requestId', 'encodedDataLength')}
            rid = projected['requestId']
            if not self._bound:
                record = self._early_ids.get(rid)
                size = projected['encodedDataLength']
                if record is None:
                    return
                if (not record['responded'] or record['finished']
                        or type(size) not in (int, float) or not 0 <= size <= MAX_BODY):
                    self._fail('early_identity_body_unavailable')
                    return
                if not self._remember('finished', projected):
                    return
                record['finished'] = True
                matched = rid
            else:
                matched = self.tracked.finished(_pack(projected))
            if matched:
                task = self._core.CallDevToolsProtocolMethodAsync('Network.getResponseBody',
                    _pack({'requestId':matched}))
                self._pending_body.append((matched, task))

    def _pump(self):
        for name, is_post in (('_pending_post', True), ('_pending_body', False)):
            pending = getattr(self, name)
            ready = [(rid, task) for rid, task in pending if task.IsCompleted]
            setattr(self, name, [(rid, task) for rid, task in pending if not task.IsCompleted])
            for rid, task in ready:
                if task.IsCanceled or task.IsFaulted:
                    if not self._bound:
                        self._fail('early_identity_body_unavailable')
                    else:
                        self.tracked.body_unavailable(rid)
                    continue
                raw = str(task.Result)
                if not self._bound:
                    value = _json(raw, MAX_BODY*2)
                    if not is_post and value is not None:
                        self._remember('body', {'requestId':rid, 'result':value})
                    else:
                        self._fail('early_identity_body_unavailable')
                elif is_post:
                    self.tracked.request_post_data(rid, raw)
                else:
                    self.tracked.response_body(rid, raw)

    def bind_loaded_document(self):
        def tree():
            control, core = self.native.core()
            if (not self.native.same_core(core, self._core)
                    or not self.native.same_core(control, self._control)
                    or not _note_url(str(core.Source), self.spec.note_id)):
                raise NativeContactError('owned_window_changed')
            return core.CallDevToolsProtocolMethodAsync('Page.getFrameTree', '{}')
        task = self.native.invoke(tree)
        if not task.Wait(10000) or task.IsCanceled or task.IsFaulted:
            raise NativeContactError('native_document_unverified')
        value = _json(str(task.Result), 8192)
        frame = ((value or {}).get('frameTree') or {}).get('frame')
        with self.lock:
            if (self._closed or self._error or not self._issued or not self._navigation_consumed
                    or self._bound or type(frame) is not dict
                    or time.monotonic()-self._started > 10):
                raise NativeContactError('native_document_unverified')
            document = (frame.get('url'), frame.get('id'), frame.get('loaderId'))
            if self._document is None or self._document != document:
                self._fail('document_scope_invalid')
                raise NativeContactError('native_document_unverified')
            self._pump()
            if self._error or not self.tracked.bind_document(*document):
                raise NativeContactError('native_document_unverified')
            for kind, event in self._early:
                if kind == 'request':
                    self.tracked.request(_pack(event))
                elif kind == 'response':
                    self.tracked.response(_pack(event))
                elif kind == 'finished':
                    self.tracked.finished(_pack(event))
                elif kind == 'body':
                    self.tracked.response_body(event['requestId'], _pack(event['result']))
            self._early.clear()
            self._early_ids.clear()
            self._early_bytes = 0
            self._bound = True
        return True

    def poll(self):
        with self.lock:
            if self._closed or self._error:
                raise NativeContactError(self._error or 'native_state_invalid')
            self._pump()
            if self._error or self.tracked.invalid:
                raise NativeContactError(self._error or self.tracked.invalid)
            if not self._bound:
                return []
        def current():
            control, core = self.native.core()
            return (self.native.same_core(control, self._control)
                and self.native.same_core(core, self._core)
                and _note_url(str(core.Source), self.spec.note_id))
        if not self.native.invoke(current):
            self._fail('owned_window_changed')
            raise NativeContactError('owned_window_changed')
        with self.lock:
            return self.tracked.drain()

    def close(self):
        with self.lock:
            self._closed = True
            self._fail('closed')
            refs = self._refs
        if refs is None:
            return True
        control, navigation, receivers = refs
        def detach():
            failed = False
            if self._navigation_attached:
                try:
                    control.NavigationStarting -= navigation
                    self._navigation_attached = False
                except Exception:
                    failed = True
            for receiver, handler in tuple(receivers):
                try:
                    receiver.DevToolsProtocolEventReceived -= handler
                    receivers.remove((receiver, handler))
                except Exception:
                    failed = True
            return not failed
        try:
            if not self.native.invoke(detach):
                return False
        except Exception:
            return False
        with self.lock:
            self._refs = None
        return True


def _read_spec(path):
    from .owned_xhs_native.runtime_materials import _checked_path
    path = _checked_path(Path(path))
    if (path.name != 'spec.json' or not path.is_file()
            or path.stat().st_size > 12288):
        raise ValueError('owner_observation_spec_invalid')
    value = _json(path.read_text(encoding='utf-8'), 12288)
    if (value is None or set(value) != {'contract', 'endpoint', 'bootstrap_secret',
            'nonce', 'window_nonce', 'idempotency_key', 'scope', 'canonical_url', 'profile_dir'}
            or value['contract'] != 'owner_contact_observation_helper_v1'):
        raise ValueError('owner_observation_spec_invalid')
    for name, length in (('bootstrap_secret', 64), ('nonce', 32),
            ('window_nonce', 32), ('idempotency_key', 64)):
        if type(value[name]) is not str or re.fullmatch('[a-f0-9]{'+str(length)+'}', value[name]) is None:
            raise ValueError('owner_observation_spec_invalid')
    endpoint = urlsplit(value['endpoint'])
    if (endpoint.scheme != 'http' or endpoint.hostname != '127.0.0.1'
            or endpoint.username or endpoint.password or endpoint.path
            or endpoint.query or endpoint.fragment or not 1 <= (endpoint.port or 0) <= 65535
            or value['endpoint'] != 'http://127.0.0.1:'+str(endpoint.port)):
        raise ValueError('owner_observation_endpoint_invalid')
    scope = value['scope']
    if (type(scope) is not dict or set(scope) != set(ReplyWindowSpec.__dataclass_fields__)
            or scope['expected_content'] != ''):
        raise ValueError('owner_observation_scope_invalid')
    spec = ReplyWindowSpec(**scope)
    if not _note_url(value['canonical_url'], spec.note_id):
        raise ValueError('owner_observation_spec_invalid')
    profile = _checked_path(Path(value['profile_dir']))
    account = profile.parent
    if (profile.name != 'xhs-browser-profile' or not profile.is_dir()
            or path.parent.name != value['idempotency_key']
            or path.parent.parent != account/'work'/'owner-contact-observation'
            or re.fullmatch('[a-f0-9]{32}', account.name) is None
            or account.parent.parent.name != 'accounts'):
        raise ValueError('owner_observation_profile_invalid')
    return value, spec, profile


def _install_local_draft(native, draft):
    """Trusted WinForms sibling controls; copy occurs only on the user's click."""
    if type(draft) is not str or not draft.strip() or len(draft) > 1000 or '\x00' in draft:
        raise ValueError('owner_observation_draft_invalid')
    from System.Windows.Forms import Panel, TextBox, Button, Label, DockStyle, Clipboard
    def install():
        control, core = native.core()
        if core is None or str(core.Source) != 'about:blank':
            raise NativeContactError('owned_window_changed')
        panel = Panel()
        panel.Height = 135
        panel.Dock = DockStyle.Top
        label = Label()
        label.Text = '已冻结的本人草稿：请明确复制，再在小红书页面手工粘贴和提交。'
        label.Dock = DockStyle.Top
        label.Height = 25
        text = TextBox()
        text.Multiline = True
        text.ReadOnly = True
        text.Text = draft
        text.Dock = DockStyle.Fill
        button = Button()
        button.Text = '复制草稿'
        button.Dock = DockStyle.Right
        button.Width = 115
        def copy(_sender, _args):
            # This handler belongs to the native sibling button. No js_api,
            # page DOM query/automation, or unconditional clipboard operation.
            Clipboard.SetText(draft)
        button.Click += copy
        panel.Controls.Add(text)
        panel.Controls.Add(button)
        panel.Controls.Add(label)
        native.form.Controls.Add(panel)
        panel.BringToFront()
        return (panel, text, button, copy)
    return native.invoke(install)


def _run_owned(spec_path):
    """Normal source helper. Parent fixed IPC/Native proof authorizes one issue."""
    value, initial_spec, profile = _read_spec(spec_path)
    # Reuse the mature proxy-free, redirect-refusing local JSON transport.
    from xhs_page_window import _post
    from owned_window_sources import collect_window_facts
    import webview
    window = webview.create_window('方隅工作台 · 本人网页核对', 'about:blank',
        width=1180, height=820, hidden=True, js_api=None, background_color='#F7F8FA')
    stop = threading.Event()
    loaded = threading.Event()
    state = {'observer':None, 'worker':None, 'local_draft':None, 'error':False}
    def on_loaded():
        loaded.set()
    window.events.loaded += on_loaded
    endpoint = SimpleNamespace(endpoint=value['endpoint'])
    def worker():
        observer = None
        session = None
        sequence = 0
        try:
            if not loaded.wait(30) or stop.is_set():
                raise ValueError('owner_observation_blank_unavailable')
            loaded.clear()
            native = _NativeOwner(window)
            facts = collect_window_facts(native, profile)
            observer = _PreNavigationPassiveObserver(window, initial_spec, native=native)
            state['observer'] = observer
            observer.attach_before_navigation()
            hwnd = native.invoke(lambda:int(native.form.Handle.ToInt64()))
            ready = _post(endpoint, '/ready', {'secret':value['bootstrap_secret'],
                'nonce':value['nonce'], 'sequence':sequence, 'hwnd':hwnd,
                'window_nonce':value['window_nonce'], 'runtime_facts':facts})
            if (type(ready) is not dict or set(ready) != {'ok', 'session_token'}
                    or ready['ok'] is not True or type(ready['session_token']) is not str
                    or re.fullmatch('[a-f0-9]{64}', ready['session_token']) is None):
                raise ValueError('owner_observation_ipc_unavailable')
            session = ready['session_token']
            result_pending = False
            while not stop.is_set():
                sequence += 1
                command = _post(endpoint, '/poll', {'session_token':session,
                    'nonce':value['nonce'], 'sequence':sequence})
                if type(command) is not dict or command.get('ok') is not True:
                    raise ValueError('owner_observation_ipc_unavailable')
                mode = command.get('command')
                if mode == 'close' and set(command) == {'ok', 'command'}:
                    break
                if mode == 'activate':
                    if (set(command) != {'ok', 'command', 'canonical_url', 'draft_text'}
                            or command['canonical_url'] != value['canonical_url']
                            or observer._issued):
                        raise ValueError('owner_observation_ipc_unavailable')
                    draft = command['draft_text']
                    state['local_draft'] = _install_local_draft(native, draft)
                    frozen_spec = ReplyWindowSpec(**{**initial_spec.__dict__, 'expected_content':draft})
                    with observer.lock:
                        observer.spec = frozen_spec
                        observer.tracked = TrackedReplyWindow(frozen_spec)
                    observer.activate(value['canonical_url'])
                    sequence += 1
                    _post(endpoint, '/observe', {'session_token':session, 'nonce':value['nonce'],
                        'sequence':sequence, 'phase':'canonical_navigation_submitted', 'observation':None})
                elif mode != 'wait' or set(command) != {'ok', 'command'}:
                    raise ValueError('owner_observation_ipc_unavailable')
                if result_pending:
                    # Keep the original HWND/Core alive for the parent's
                    # independent current Native proof and durable publish.
                    # The native control is disabled below; no second manual
                    # input is accepted while waiting for parent close.
                    stop.wait(.1)
                    continue
                if observer._issued and not observer._bound and loaded.is_set():
                    observer.bind_loaded_document()
                    loaded.clear()
                    window.show()
                    sequence += 1
                    _post(endpoint, '/observe', {'session_token':session, 'nonce':value['nonce'],
                        'sequence':sequence, 'phase':'observing', 'observation':None})
                rows = observer.poll()
                if rows:
                    def freeze_input():
                        control, core = native.core()
                        if not native.same_core(core, observer._core):
                            raise NativeContactError('owned_window_changed')
                        control.Enabled = False
                    native.invoke(freeze_input)
                    observer.close()
                for row in rows:
                    sequence += 1
                    _post(endpoint, '/observe', {'session_token':session, 'nonce':value['nonce'],
                        'sequence':sequence, 'phase':'observing', 'observation':row})
                if rows:
                    result_pending = True
                stop.wait(.1)
        except Exception:
            state['error'] = True
        finally:
            if observer is not None:
                observer.close()
            try:
                window.destroy()
            except Exception:
                state['error'] = True
    def start():
        thread = threading.Thread(target=worker, name='owner-contact-helper', daemon=False)
        state['worker'] = thread
        thread.start()
    try:
        webview.start(start, gui='edgechromium', private_mode=False,
            storage_path=str(profile), debug=False)
    finally:
        stop.set()
        thread = state['worker']
        if thread is not None and thread is not threading.current_thread():
            thread.join(8)
        if thread is not None and thread.is_alive():
            state['error'] = True
        state['local_draft'] = None
    return 2 if state['error'] else 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 2 or argv[0] != '--spec':
        return 2
    # A crafted local spec must not bypass this batch's default pending gate.
    # No approved material was supplied; refusal happens before Native import.
    from .owner_contact_observation_policy import _APPROVED_REVIEW_SHA
    if _APPROVED_REVIEW_SHA is None:
        return 2
    try:
        return _run_owned(argv[1])
    except Exception:
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
