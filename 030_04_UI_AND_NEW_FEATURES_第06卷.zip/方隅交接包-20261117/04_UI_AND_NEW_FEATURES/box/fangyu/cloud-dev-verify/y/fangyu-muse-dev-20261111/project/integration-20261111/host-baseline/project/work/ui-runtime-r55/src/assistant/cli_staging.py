"""One-use, job-owned CLI candidate file; never an authenticated account store.

The caller owns this private tempHOME and must delete it after its single
status/account check. This module does not call the platform or the vendor CLI.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import time

if __package__:
    from .auth_candidate import (
        CandidateRejected, MAX_TOTAL_COOKIE_BYTES, MAX_COOKIE_VALUE_BYTES,
        XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES,
    )
else:
    from auth_candidate import (
        CandidateRejected, MAX_TOTAL_COOKIE_BYTES, MAX_COOKIE_VALUE_BYTES,
        XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES,
    )


def validate_job_paths(staging_root: Path, cancel_file: Path) -> Path:
    """Require one absolute private root with a fixed sibling cancel marker."""
    if not isinstance(staging_root, Path) or not isinstance(cancel_file, Path):
        raise CandidateRejected("staging_path_invalid")
    if not staging_root.is_absolute() or not cancel_file.is_absolute():
        raise CandidateRejected("staging_path_invalid")
    if cancel_file != staging_root / "cancel.flag":
        raise CandidateRejected("staging_path_invalid")
    if staging_root.is_symlink() or cancel_file.is_symlink():
        raise CandidateRejected("staging_path_invalid")
    if not staging_root.is_dir():
        raise CandidateRejected("staging_path_invalid")
    if (staging_root / ".xiaohongshu-cli").is_symlink():
        raise CandidateRejected("staging_path_invalid")
    return staging_root / ".xiaohongshu-cli" / "cookies.json"


def stage_cli_candidate_once(cookies: dict[str, str], *, staging_root: Path,
                             cancel_file: Path, allowed_names: frozenset[str] = XHS_COOKIE_NAMES,
                             required_names: frozenset[str] = XHS_REQUIRED_NAMES) -> Path:
    """Write the pinned vendor JSON shape exactly once with O_EXCL.

    An existing file is never overwritten. Only a private, disposable tempHOME
    should be supplied. A successful file is still unverified.
    """
    path = validate_job_paths(staging_root, cancel_file)
    if (not isinstance(cookies, dict) or not required_names.issubset(cookies)
            or not set(cookies).issubset(allowed_names)):
        raise CandidateRejected("staging_input_invalid")
    total = 0
    for value in cookies.values():
        if not isinstance(value, str) or not value:
            raise CandidateRejected("staging_input_invalid")
        size = len(value.encode("utf-8"))
        total += size
        if size > MAX_COOKIE_VALUE_BYTES or total > MAX_TOTAL_COOKIE_BYTES:
            raise CandidateRejected("staging_input_invalid")
    if cancel_file.exists():
        raise CandidateRejected("cancelled")
    payload = json.dumps({**cookies, "saved_at": time.time()},
                         ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(payload) > MAX_TOTAL_COOKIE_BYTES + 2048:
        raise CandidateRejected("staging_input_invalid")
    try:
        path.parent.mkdir(mode=0o700, exist_ok=False)
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        path.chmod(0o600)
    except FileExistsError:
        raise CandidateRejected("staging_exists") from None
    except OSError:
        path.unlink(missing_ok=True)
        raise CandidateRejected("staging_write_failed") from None
    if cancel_file.exists():
        discard_cli_candidate(path)
        raise CandidateRejected("cancelled")
    return path


def discard_cli_candidate(path: Path | None) -> None:
    if path is None:
        return
    try:
        path.unlink(missing_ok=True)
    except OSError:
        raise CandidateRejected("staging_cleanup_failed") from None
