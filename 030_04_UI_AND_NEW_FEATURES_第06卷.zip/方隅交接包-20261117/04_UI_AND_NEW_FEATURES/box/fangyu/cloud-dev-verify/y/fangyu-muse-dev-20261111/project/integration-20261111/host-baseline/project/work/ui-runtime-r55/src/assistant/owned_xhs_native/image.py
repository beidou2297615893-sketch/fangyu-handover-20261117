"""RAM-only same-process-object metadata evidence; never classify vacancy.

Import and construction perform no DLL/file/process observation. Both private
entries require trusted internal readers. Injected APIs/dependencies exist only
for recording fixtures, never request/DTO input. A native image name is neither
runtime permission nor a hash of the bytes loaded when the process was born.
"""
import copy
import ctypes
from ctypes import wintypes
import hashlib
import json
from pathlib import Path
import re
import subprocess

from . import owner as OWNER, classifier as FROZEN

_PINS = (('owner.py', '9770E5721A705F5B53ED0DCF859E192B15DE21A9235A6F6049D0868A26B0055F'), ('classifier.py', '96F8F0D3FD7BBBDDCB78FEEC44254CD4B42D2A8D31A1BA171603AAFDED6F50D3'))


def _fixed_sources_valid():
    folder = Path(__file__).resolve().parent
    return all(hashlib.sha256((folder / name).read_bytes()).hexdigest().upper() == expected
               for name, expected in _PINS)

_ROW_FIELDS = {'pid', 'parent_pid', 'created', 'name', 'executable', 'command_line', 'owner_sid'}
_SPEC_FIELDS = {'application_name', 'argv', 'cwd', 'run_nonce'}
_REASONS = frozenset({'metadata_unavailable', 'frozen_source_changed', 'native_api_unavailable',
                     'principal_changed', 'runtime_binding_unavailable', 'state_unavailable',
                     'process_not_running', 'job_conflict', 'token_open_unavailable',
                     'token_buffer_unavailable', 'token_user_unavailable', 'sid_unavailable',
                     'close_unconfirmed', 'pid_unavailable', 'creation_unavailable',
                     'image_unavailable', 'pid_conflict', 'creation_conflict', 'image_conflict',
                     'owner_conflict', 'snapshot_unavailable', 'row_changed',
                     'argv0_conflict', 'process_open_unavailable', 'verified'})


class _BindingError(ValueError):
    pass


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def _fixed_dependencies():
    if not _fixed_sources_valid():
        raise _BindingError('frozen_source_changed')
    return OWNER, FROZEN


def _handle(value):
    raw = value.value if isinstance(value, ctypes.c_void_p) else value
    if type(raw) is not int or not 0 < raw < (1 << (ctypes.sizeof(ctypes.c_void_p) * 8)) - 1:
        raise _BindingError('metadata_unavailable')
    return raw


def _text(value):
    return isinstance(value, str) and 0 < len(value) <= 32760 and not any(ord(c) < 32 for c in value)


def _nonce(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{32}', value) is not None


class NativeProcessImageBinding:
    def __init__(self, *, apis=None, frozen_loader=None):
        self.apis = apis
        self.frozen_loader = frozen_loader
        self._default_dependencies = None  # code identity only, never process evidence

    @staticmethod
    def _result(origin):
        return dict(contract='process_image_binding_v1', origin=origin, state='unknown',
                    reason='metadata_unavailable', owner_current=None, wmi_owner_agrees=None,
                    creation_verified=False, running_before=None, running_after=None,
                    pid_stable=None, native_image_read=None, native_image_stable=None,
                    cim_image_matches=None, argv0_matches=None, fixed_runtime_matches=None,
                    job_membership_verified=None, exact_row_stable=None, token_user_verified=False,
                    handles_closed=True, borrowed_process_handle=origin == 'createprocess_retained_handle',
                    argv_native_verified=False, native_loaded_bytes_verified=False,
                    profile_vacancy_verified=False, evidence_hash=None)

    def _dependencies(self):
        if self.frozen_loader is not None:
            value = self.frozen_loader()
        else:
            if self._default_dependencies is None:
                self._default_dependencies = _fixed_dependencies()
            elif not _fixed_sources_valid():
                raise _BindingError('frozen_source_changed')
            value = self._default_dependencies
        if not isinstance(value, tuple) or len(value) != 2:
            raise _BindingError('frozen_source_changed')
        return value

    def _final_sources(self):
        if self.frozen_loader is None and not _fixed_sources_valid():
            raise _BindingError('frozen_source_changed')

    def _native(self, owner):
        if self.apis is not None:
            if not isinstance(self.apis, tuple) or len(self.apis) != 2:
                raise _BindingError('native_api_unavailable')
            return self.apis
        kernel, advapi = owner.native_apis()
        for name, args, result in (
            ('GetProcessId', [wintypes.HANDLE], wintypes.DWORD),
            ('QueryFullProcessImageNameW', [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
                                          ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
            ('IsProcessInJob', [wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.BOOL)], wintypes.BOOL),
        ):
            function = getattr(kernel, name)
            function.argtypes, function.restype = args, result
        return kernel, advapi

    @staticmethod
    def _principal(owner, provider, expected=None):
        if not callable(provider):
            raise _BindingError('principal_changed')
        value = provider()
        if not owner.valid_sid(value) or (expected is not None and value != expected):
            raise _BindingError('principal_changed')
        return value

    @staticmethod
    def _runtime(profile, binding):
        from assistant.customer_natural_materials import _PortableHelperBinding
        if type(binding) is _PortableHelperBinding:
            value=copy.deepcopy(binding._binding)
            if (set(value)!={'kind','routes','executable_sha256','manifest_sha256'}
                    or value['kind']!='fixed_portable_xhs_helper_v1'
                    or type(value['routes']) is not dict or len(value['routes'])!=1
                    or any(not _text(k) or not _text(v) for k,v in value['routes'].items())
                    or any(type(value[k]) is not str or re.fullmatch('[0-9a-f]{64}',value[k]) is None
                        for k in ('executable_sha256','manifest_sha256'))
                    or not binding.validate() or binding._binding!=value):
                raise _BindingError('runtime_binding_unavailable')
            return value
        if (not isinstance(binding, profile.TrustedCurrentPython)
                or not callable(getattr(binding, 'validate', None))
                or not callable(getattr(binding, 'executable', None))):
            raise _BindingError('runtime_binding_unavailable')
        value = copy.deepcopy(getattr(binding, '_binding', None))
        if (not isinstance(value, dict) or set(value) != {'routes', 'configuration_sha', 'shim_sha', 'base_sha'}
                or not isinstance(value['routes'], dict) or not 1 <= len(value['routes']) <= 3
                or any(not _text(k) or not _text(v) for k, v in value['routes'].items())
                or any(not isinstance(value[k], str) or re.fullmatch('[0-9a-fA-F]{64}', value[k]) is None
                       for k in ('configuration_sha', 'shim_sha', 'base_sha'))
                or binding.validate() is not True or getattr(binding, '_binding', None) != value):
            raise _BindingError('runtime_binding_unavailable')
        return value

    @staticmethod
    def _mapped(profile, binding, material, value, sid):
        expected = material['routes'].get(profile._executable_key(value))
        if expected is None or binding.executable(value, sid, sid) != expected:
            raise _BindingError('runtime_binding_unavailable')
        return profile.canonical_path(expected)

    @staticmethod
    def _running(kernel, handle, owner):
        value = kernel.WaitForSingleObject(handle, 0)
        if value not in (0, owner.WAIT_TIMEOUT):
            raise _BindingError('state_unavailable')
        if value != owner.WAIT_TIMEOUT:
            raise _BindingError('process_not_running')
        return True

    @staticmethod
    def _job(kernel, process, job):
        member = wintypes.BOOL()
        if not kernel.IsProcessInJob(process, job, ctypes.byref(member)) or not member.value:
            raise _BindingError('job_conflict')

    @staticmethod
    def _token_sid(kernel, advapi, process, owner, result):
        token, sid_string = wintypes.HANDLE(), ctypes.c_void_p()
        token_acquired = sid_allocated = False
        sid = None
        try:
            if not advapi.OpenProcessToken(process, owner.TOKEN_QUERY, ctypes.byref(token)) or not token.value:
                raise _BindingError('token_open_unavailable')
            token_acquired = True
            required = wintypes.DWORD()
            ctypes.set_last_error(0)
            ok = advapi.GetTokenInformation(token, owner.TOKEN_USER_CLASS, None, 0, ctypes.byref(required))
            if ok or ctypes.get_last_error() != 122 or not ctypes.sizeof(owner.TOKEN_USER) <= required.value <= 65536:
                raise _BindingError('token_buffer_unavailable')
            capacity = required.value
            buffer = ctypes.create_string_buffer(capacity)
            if (not advapi.GetTokenInformation(token, owner.TOKEN_USER_CLASS, buffer, capacity, ctypes.byref(required))
                    or not ctypes.sizeof(owner.TOKEN_USER) <= required.value <= capacity):
                raise _BindingError('token_user_unavailable')
            pointer = ctypes.cast(buffer, ctypes.POINTER(owner.TOKEN_USER)).contents.User.Sid
            start = ctypes.addressof(buffer)
            if not pointer or not start <= pointer <= start + required.value - 8:
                raise _BindingError('sid_unavailable')
            if not advapi.ConvertSidToStringSidW(pointer, ctypes.byref(sid_string)) or not sid_string.value:
                raise _BindingError('sid_unavailable')
            sid_allocated = True
            sid = ctypes.wstring_at(sid_string)
            if not owner.valid_sid(sid):
                raise _BindingError('sid_unavailable')
            return sid
        finally:
            closed = True
            if token_acquired:
                try:
                    closed = bool(kernel.CloseHandle(token.value))
                except Exception:
                    closed = False
            if sid_allocated:
                try:
                    closed = not kernel.LocalFree(sid_string) and closed
                except Exception:
                    closed = False
            if not closed:
                result['handles_closed'] = False
                raise _BindingError('close_unconfirmed')
            sid = None

    def _identity(self, kernel, advapi, handle, owner, profile, result):
        pid = kernel.GetProcessId(handle)
        if type(pid) is not int or not 1 <= pid <= 0xffffffff:
            raise _BindingError('pid_unavailable')
        created = owner.NativeOwnerResolver._creation(kernel, handle)
        if type(created) is not int or not owner.DOTNET_FILETIME_EPOCH < created <= owner.DOTNET_FILETIME_EPOCH + 0xffffffffffffffff:
            raise _BindingError('creation_unavailable')
        capacity = 32768
        buffer, length = ctypes.create_unicode_buffer(capacity), wintypes.DWORD(capacity)
        if not kernel.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)) or not 1 <= length.value < capacity:
            raise _BindingError('image_unavailable')
        text = buffer[:length.value]
        if not _text(text) or buffer.value != text:
            raise _BindingError('image_unavailable')
        result['native_image_read'] = True
        image = profile.canonical_path(text)
        sid = self._token_sid(kernel, advapi, handle, owner, result)
        return dict(pid=pid, created=created, image=image, sid=sid)

    @staticmethod
    def _agree(first, last, result):
        if first['pid'] != last['pid']:
            raise _BindingError('pid_conflict')
        result['pid_stable'] = True
        if first['created'] != last['created']:
            raise _BindingError('creation_conflict')
        if first['image'] != last['image']:
            raise _BindingError('image_conflict')
        result['native_image_stable'] = True
        if first['sid'] != last['sid']:
            raise _BindingError('owner_conflict')

    @staticmethod
    def _row(owner, row):
        if (not isinstance(row, dict) or set(row) != _ROW_FIELDS
                or type(row['pid']) is not int or not 1 <= row['pid'] <= 0xffffffff
                or type(row['parent_pid']) is not int or not 0 <= row['parent_pid'] <= 0xffffffff
                or type(row['created']) is not int or not 0 < row['created'] <= owner.DOTNET_FILETIME_EPOCH + 0xffffffffffffffff
                or any(not _text(row[k]) for k in ('name', 'executable', 'command_line'))
                or (row['owner_sid'] is not None and not owner.valid_sid(row['owner_sid']))):
            raise _BindingError('snapshot_unavailable')
        return copy.deepcopy(row)

    def _snapshot_row(self, owner, provider, sid, original):
        if not callable(provider):
            raise _BindingError('snapshot_unavailable')
        value = copy.deepcopy(provider())
        fields = {'current_sid', 'processes', 'complete', 'default_profiles'}
        if (not isinstance(value, dict) or set(value) not in (fields, fields - {'default_profiles'})
                or value['complete'] is not True or value['current_sid'] != sid
                or not isinstance(value['processes'], list) or len(value['processes']) > 4096):
            raise _BindingError('snapshot_unavailable')
        rows = {}
        for raw in value['processes']:
            # This provider binds one selected row, not the whole vacancy
            # verdict. Unrelated metadata may be unavailable or change; its
            # profile/browser relevance remains the frozen classifier's job.
            if (not isinstance(raw, dict) or set(raw) != _ROW_FIELDS
                    or type(raw['pid']) is not int or not 1 <= raw['pid'] <= 0xffffffff
                    or raw['pid'] in rows):
                raise _BindingError('snapshot_unavailable')
            rows[raw['pid']] = raw
        if rows.get(original['pid']) != original:
            raise _BindingError('row_changed')

    def _capture_owned(self, hprocess, expected_pid, *, job_handle, creation_spec,
                       current_sid_provider, runtime_binding):
        """Borrow CreateProcessW's retained handle, before caller resumes it.

        This method never creates/assigns/resumes a process or owns its Job.
        Full argv/cwd are trusted frozen creation intent, not Native argv proof.
        """
        result = self._result('createprocess_retained_handle')
        first = last = sid = spec = material = None
        try:
            process, job = _handle(hprocess), _handle(job_handle)
            if type(expected_pid) is not int or not 1 <= expected_pid <= 0xffffffff:
                raise _BindingError('metadata_unavailable')
            if (not isinstance(creation_spec, dict) or set(creation_spec) != _SPEC_FIELDS
                    or not _text(creation_spec['application_name']) or not _text(creation_spec['cwd'])
                    or not _nonce(creation_spec['run_nonce']) or not isinstance(creation_spec['argv'], list)
                    or not 1 <= len(creation_spec['argv']) <= 256 or any(not _text(v) for v in creation_spec['argv'])):
                raise _BindingError('metadata_unavailable')
            spec = copy.deepcopy(creation_spec)
            owner, profile = self._dependencies()
            sid = self._principal(owner, current_sid_provider)
            material = self._runtime(profile, runtime_binding)
            application = self._mapped(profile, runtime_binding, material, spec['application_name'], sid)
            argv0 = self._mapped(profile, runtime_binding, material, spec['argv'][0], sid)
            cwd = profile.canonical_path(spec['cwd'])
            if profile.windows_argv(subprocess.list2cmdline(spec['argv'])) != spec['argv'] or application != argv0:
                raise _BindingError('argv0_conflict')
            kernel, advapi = self._native(owner)
            self._job(kernel, process, job)
            result['running_before'] = self._running(kernel, process, owner)
            first = self._identity(kernel, advapi, process, owner, profile, result)
            if first['pid'] != expected_pid:
                raise _BindingError('pid_conflict')
            result['owner_current'] = first['sid'] == sid
            if not result['owner_current']:
                raise _BindingError('owner_conflict')
            if first['image'] != application:
                raise _BindingError('image_conflict')
            self._principal(owner, current_sid_provider, sid)
            last = self._identity(kernel, advapi, process, owner, profile, result)
            self._agree(first, last, result)
            result['running_after'] = self._running(kernel, process, owner)
            self._job(kernel, process, job)
            if creation_spec != spec or profile.canonical_path(spec['cwd']) != cwd or self._runtime(profile, runtime_binding) != material:
                raise _BindingError('runtime_binding_unavailable')
            self._principal(owner, current_sid_provider, sid)
            self._final_sources()
            self._principal(owner, current_sid_provider, sid)
            result.update(state='verified', reason='verified', creation_verified=True,
                          argv0_matches=True, fixed_runtime_matches=True, job_membership_verified=True,
                          token_user_verified=True, evidence_hash=_hash(['createprocess_image_v1', spec, material, first]))
        except _BindingError as error:
            result.update(state='unknown', reason=str(error) if str(error) in _REASONS else 'metadata_unavailable', evidence_hash=None)
        except Exception:
            result.update(state='unknown', reason='metadata_unavailable', evidence_hash=None)
        finally:
            first = last = sid = spec = material = None
        return result

    def _observe_existing(self, original_row, *, snapshot_provider, current_sid_provider,
                          runtime_binding, run_nonce):
        """Observe one exact fresh row on one owned limited-query handle.

        Two complete snapshots bind the original seven fields. A successful
        observer remains observation, not an owned process or vacant profile.
        """
        result = self._result('openprocess_snapshot_bound')
        process = kernel = first = last = sid = row = material = None
        try:
            if not _nonce(run_nonce):
                raise _BindingError('metadata_unavailable')
            owner, profile = self._dependencies()
            row = self._row(owner, original_row)
            sid = self._principal(owner, current_sid_provider)
            self._snapshot_row(owner, snapshot_provider, sid, row)
            self._principal(owner, current_sid_provider, sid)
            material = self._runtime(profile, runtime_binding)
            kernel, advapi = self._native(owner)
            process = kernel.OpenProcess(owner.PROCESS_ACCESS, False, row['pid'])
            if not process:
                raise _BindingError('process_open_unavailable')
            process = _handle(process)
            result['running_before'] = self._running(kernel, process, owner)
            first = self._identity(kernel, advapi, process, owner, profile, result)
            if first['pid'] != row['pid']:
                raise _BindingError('pid_conflict')
            if not 0 <= first['created'] - row['created'] <= 9:
                raise _BindingError('creation_conflict')
            result['owner_current'] = first['sid'] == sid
            result['wmi_owner_agrees'] = None if row['owner_sid'] is None else first['sid'] == row['owner_sid']
            if not result['owner_current'] or result['wmi_owner_agrees'] is False:
                raise _BindingError('owner_conflict')
            self._principal(owner, current_sid_provider, sid)
            last = self._identity(kernel, advapi, process, owner, profile, result)
            self._agree(first, last, result)
            result['running_after'] = self._running(kernel, process, owner)
            self._snapshot_row(owner, snapshot_provider, sid, row)
            self._principal(owner, current_sid_provider, sid)
            result.update(creation_verified=True, exact_row_stable=True, token_user_verified=True)
            if original_row != row or self._runtime(profile, runtime_binding) != material:
                raise _BindingError('row_changed')
            self._principal(owner, current_sid_provider, sid)
            self._final_sources()
            self._principal(owner, current_sid_provider, sid)
            # Native metadata must remain observable for an unknown spelling.
            # It is still not a grant: the old fixed-route/argv binding below
            # must succeed before a complete binding result can be verified.
            selected = self._mapped(profile, runtime_binding, material, row['executable'], sid)
            if first['image'] != selected:
                result['cim_image_matches'] = False
                raise _BindingError('image_conflict')
            result['cim_image_matches'] = True
            argv = profile.windows_argv(row['command_line'])
            if (not isinstance(argv, list) or not 1 <= len(argv) <= 256 or any(not _text(v) for v in argv)
                    or self._mapped(profile, runtime_binding, material, argv[0], sid) != selected):
                result['argv0_matches'] = False
                raise _BindingError('argv0_conflict')
            if self._runtime(profile, runtime_binding) != material:
                raise _BindingError('runtime_binding_unavailable')
            self._final_sources()
            self._principal(owner, current_sid_provider, sid)
            result.update(state='verified', reason='verified', creation_verified=True,
                          cim_image_matches=True, argv0_matches=True, fixed_runtime_matches=True,
                          exact_row_stable=True, token_user_verified=True,
                          evidence_hash=_hash(['snapshot_process_image_v1', run_nonce, row, material, first]))
        except _BindingError as error:
            result.update(state='unknown', reason=str(error) if str(error) in _REASONS else 'metadata_unavailable', evidence_hash=None)
        except Exception:
            result.update(state='unknown', reason='metadata_unavailable', evidence_hash=None)
        finally:
            if process is not None and kernel is not None:
                try:
                    closed = bool(kernel.CloseHandle(process))
                except Exception:
                    closed = False
                if not closed:
                    result.update(state='unknown', reason='close_unconfirmed', handles_closed=False,
                                  token_user_verified=False, evidence_hash=None)
                elif sid is not None:
                    try:
                        self._principal(owner, current_sid_provider, sid)
                        if original_row != row:
                            raise _BindingError('row_changed')
                    except _BindingError as error:
                        result.update(state='unknown', reason=str(error) if str(error) in _REASONS else 'metadata_unavailable', evidence_hash=None)
                    except Exception:
                        result.update(state='unknown', reason='metadata_unavailable', evidence_hash=None)
            first = last = sid = row = material = None
        return result
