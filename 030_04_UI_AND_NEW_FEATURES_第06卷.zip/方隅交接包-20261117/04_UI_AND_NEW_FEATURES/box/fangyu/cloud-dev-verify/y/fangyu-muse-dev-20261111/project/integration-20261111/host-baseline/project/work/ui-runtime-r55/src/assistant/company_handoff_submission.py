"""One explicit original company submit; recovery never repeats the write.

Only platform references are handed to the existing company ledger. Immutable
registration history and local handoffs are unchanged. Receipt != acceptance.
"""
from copy import deepcopy
import json
import re
import time

from core import CoreError
from .company_handoff_channel_check import CompanyHandoffChannelCheck, CLOUD_DETAIL
from .company_handoff_preparation import _hash, _json
from .company_handoff_original_status import _ENVELOPE, _RECEIPT, _ORIGINAL, _CURRENT, _STATES

SUBMIT = 'company_handoff_submit'
GET = 'company_handoff_submission_get'
CLOUD_ACTION = 'acquisition_handoff_submit'
ATTEMPTS = 'company_handoff_submission_attempts'
CONTRACT = 'company_handoff_submission_v1'
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_MAX = 9007199254740991
_ROW_FIELDS = frozenset(('id', 'version', 'tenant_id', 'cloud_owner', 'company_id', 'environment_id',
    'device_id', 'actor_id', 'handoff_id', 'origin_id', 'handoff_revision', 'cloud_idempotency_key',
    'cloud_payload_hash', 'expected_cloud_channel_id', 'expected_cloud_revision', 'state',
    'created_at', 'updated_at', 'revision', 'record_hash'))


class CompanyHandoffSubmissionError(CoreError):
    def __init__(self, code, message, status=409, mutation_committed=False):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_SUBMISSION_' + code
        self.status, self.mutation_committed = status, mutation_committed


def _fail(code, message, status=409, *, mutation=False):
    raise CompanyHandoffSubmissionError(code, message, status, mutation)


def _integer(value, minimum=0):
    return type(value) is int and minimum <= value <= _MAX


class CompanyHandoffSubmission:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard, lead_access,
                 cloud_read, cloud_submit, clock=None):
        if not callable(cloud_read) or not callable(cloud_submit):
            raise ValueError('公司提交需要可信原号纯读与一次明确提交入口')
        self.core, self.tenant, self.owner = core, tenant, owner
        self.device_id, self.cloud_read, self.cloud_submit = device_id, cloud_read, cloud_submit
        self.clock = clock or time.time
        self.check = CompanyHandoffChannelCheck(core, tenant, owner, company, device_id=device_id,
            scope_guard=scope_guard, lead_access=lead_access, cloud_read=cloud_read)
        self.registration, self.preparation = self.check.registration, self.check.preparation

    def _scope(self):
        self.registration._scope()

    def _snapshot(self, handoff_id, user):
        try:
            value = self.check._snapshot(handoff_id, user)
            with self.core.lock, self.core.store.connect() as db:
                value['submission'] = self._row(db, value)
            self._scope()
            return value
        except CompanyHandoffSubmissionError:
            raise
        except Exception:
            _fail('LOCAL_CHANGED', '原准备、本人权限或完整来源需核对，保留原交接编号')

    def _record_id(self, handoff_id):
        return _hash(['company-handoff-submission-v1', self.tenant, self.preparation.company_id, self.owner, handoff_id])

    def _key(self, origin):
        return _hash(['company-handoff-cloud-submit-v1', self.tenant, self.preparation.company_id, self.owner, origin['origin_id']])

    def _body(self, origin, expected_revision):
        return dict(environment_id=self.preparation.environment_id, operation=CLOUD_ACTION,
            channel_id=origin['expected_cloud_channel_id'], expected_revision=expected_revision,
            idempotency_key=self._key(origin))

    def _row(self, db, snapshot):
        raw = db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',
            (ATTEMPTS, self._record_id(snapshot['current']['handoff_id']))).fetchone()
        if not raw:
            return None
        try:
            row, origin = json.loads(raw['body']), snapshot['origin']
            fields = dict(id=self._record_id(origin['handoff_id']), version=1, tenant_id=self.tenant,
                cloud_owner=self.owner, company_id=self.preparation.company_id,
                environment_id=self.preparation.environment_id, device_id=self.device_id,
                actor_id=snapshot['actor']['id'], handoff_id=origin['handoff_id'], origin_id=origin['origin_id'],
                handoff_revision=origin['handoff_revision'], expected_cloud_channel_id=origin['expected_cloud_channel_id'],
                cloud_idempotency_key=self._key(origin))
            if (set(row) != _ROW_FIELDS or raw['tenant_id'] != self.tenant
                    or any(row[key] != value for key, value in fields.items())
                    or row['record_hash'] != _hash({key: value for key, value in row.items() if key != 'record_hash'})
                    or row['state'] not in ('unknown', 'recorded') or not _integer(row['expected_cloud_revision'], 1)
                    or row['cloud_payload_hash'] != _hash(self._body(origin, row['expected_cloud_revision']))
                    or not _integer(row['created_at'], 1577836800) or not _integer(row['updated_at'], row['created_at'])
                    or not _integer(row['revision'], 1)):
                raise ValueError('submission mismatch')
            return row
        except Exception:
            _fail('ATTEMPT_CONFLICT', '原公司提交元数据完整性需核对，不能新建或重发')

    @staticmethod
    def _put(db, row, *, new=False):
        unsigned = {key: value for key, value in row.items() if key != 'record_hash'}
        value = dict(unsigned, record_hash=_hash(unsigned))
        if new:
            db.execute('INSERT INTO records(entity,id,tenant_id,body) VALUES(?,?,?,?)',
                (ATTEMPTS, value['id'], value['tenant_id'], _json(value)))
        else:
            changed = db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (_json(value), ATTEMPTS, value['id'], value['tenant_id']))
            if changed.rowcount != 1:
                _fail('ATTEMPT_CONFLICT', '原提交元数据范围已变化，请保留原号')
        return value

    @staticmethod
    def _commit(db):
        db.commit()

    def _fence(self, before, user):
        after = self._snapshot(before['current']['handoff_id'], user)
        if (after['fingerprint'] != before['fingerprint'] or after['attempt'] != before['attempt']
                or after['original_event'] != before['original_event'] or after['submission'] != before['submission']):
            _fail('LOCAL_CHANGED', '读取期间原提交、来源、授权或本人范围已变化，请保留原号')
        return after

    def _corroborate(self, snapshot, user):
        if not snapshot['origin'] or not snapshot['attempt']:
            return None
        receipt = self.registration._status_read(snapshot)
        self._fence(snapshot, user)
        if receipt['state'] != 'recorded':
            return dict(register=receipt, binding=None, item=None)
        binding = self.registration._source_read(snapshot)
        self._fence(snapshot, user)
        if binding['state'] != 'matched':
            return dict(register=receipt, binding=binding, item=None)
        answer = self.cloud_read(deepcopy(snapshot['actor']), CLOUD_DETAIL,
            dict(channel_id=snapshot['origin']['expected_cloud_channel_id']))
        self._fence(snapshot, user)
        self.check._detail(answer, snapshot, receipt)
        return dict(register=receipt, binding=binding, item=deepcopy(answer['item']))

    def _receipt(self, answer, snapshot, row):
        receipt = answer.get('operation_receipt') if isinstance(answer, dict) else None
        if (not isinstance(answer, dict) or set(answer) != _ENVELOPE or answer['read_only'] is not True
                or answer['mutation_committed'] is not False or answer['auto_retry'] is not False
                or not isinstance(receipt, dict) or set(receipt) != _RECEIPT
                or receipt['contract'] != 'handoff_operation_receipt_v1' or receipt['read_only'] is not True
                or receipt['mutation_committed'] is not False or receipt['storage_scope'] != 'company_server_ledger'
                or receipt['authenticated_actor'] != self.owner or not _integer(receipt['observed_at'])
                or receipt['operation_action'] != CLOUD_ACTION or receipt['idempotency_key'] != row['cloud_idempotency_key']
                or receipt['state'] not in ('unknown', 'recorded') or receipt['auto_retry'] is not False
                or any(receipt[key] is not False for key in ('platform_delivery_verified', 'settlement_active',
                    'financial_receipt_verified', 'cooperation_policy_verified'))
                or receipt['verified_cash_cents'] is not None or receipt['verified_paid_commission_cents'] is not None):
            _fail('RECEIPT_INVALID', '公司原提交回执身份或范围需核对，原编号继续保留')
        if receipt['state'] == 'unknown':
            if any(receipt[key] is not None for key in ('original_execution_confirmed', 'original_operation', 'current_handoff')):
                _fail('RECEIPT_INVALID', '未知原提交不能显示已提交或未执行')
            return deepcopy(receipt)
        original, current = receipt['original_operation'], receipt['current_handoff']
        if (not isinstance(original, dict) or set(original) != _ORIGINAL
                or not isinstance(current, dict) or set(current) != _CURRENT
                or receipt['original_execution_confirmed'] is not True
                or original['payload_hash'] != row['cloud_payload_hash']
                or original['channel_id'] != row['expected_cloud_channel_id']
                or type(original['revision']) is not int or original['revision'] != row['expected_cloud_revision'] + 1
                or original['historical_status'] != 'submitted' or not _integer(original['occurred_at'])
                or original['occurred_at'] > receipt['observed_at']
                or original['historical_event_self_hash_verified'] is not True or original['full_historical_chain_verified'] is not False
                or current['channel_id'] != row['expected_cloud_channel_id'] or not _integer(current['revision'], original['revision'])
                or current['status'] not in _STATES or type(current['current_consent_valid']) is not bool
                or type(current['historical_resource_receipt_recorded']) is not bool
                or current['receipt_evidence_independently_verified'] is not False
                or (current['status'] == 'withdrawn' and current['current_consent_valid'] is not False)):
            _fail('ORIGINAL_MISMATCH', '原公司提交与固定原号、内容或版本不一致，不能显示已提交')
        return deepcopy(receipt)

    def _status(self, snapshot, row):
        answer = self.cloud_read(deepcopy(snapshot['actor']), 'acquisition_handoff_operation_status',
            dict(operation_action=CLOUD_ACTION, idempotency_key=row['cloud_idempotency_key']))
        return self._receipt(answer, snapshot, row)

    @staticmethod
    def _safe_operation(receipt, action):
        if not receipt or receipt['state'] != 'recorded':
            return None
        original = {key: value for key, value in receipt['original_operation'].items() if key != 'payload_hash'}
        return dict(original, operation_action=action, execution_confirmed=True)

    def _eligible(self, snapshot, proof):
        item = proof['item'] if proof else None
        return bool(snapshot['submission'] is None and snapshot['current']['preparation_usable']
            and isinstance(item, dict) and item['status'] == 'draft' and item['current_consent_valid'] is True
            and isinstance(item.get('permissions'), dict) and item['permissions'].get('can_submit') is True)

    def _result(self, snapshot, proof=None, receipt=None, *, read_only, dispatched=False, committed=False):
        row, origin = snapshot['submission'], snapshot['origin']
        register = proof['register'] if proof else None
        matched = bool(proof and proof['item'] is not None)
        recorded = bool(receipt and receipt['state'] == 'recorded')
        state = 'no_origin' if origin is None else 'not_attempted' if row is None else 'recorded' if recorded else 'unknown'
        current = receipt['current_handoff'] if recorded else register['current_handoff'] if register else None
        eligible = self._eligible(snapshot, proof)
        requested = proof is not None or receipt is not None
        return dict(contract=CONTRACT, read_only=read_only, mutation_committed=committed,
            local_only=not requested, storage_scope='local_bridge_company_server_ledger', cross_machine_verified=False,
            state=state, origin=dict(origin_id=origin['origin_id'], local_handoff_revision=origin['handoff_revision']) if origin else None,
            attempt=dict(attempt_id=row['id'], state=row['state'], expected_company_revision=row['expected_cloud_revision'],
                created_at=row['created_at'], updated_at=row['updated_at']) if row else None,
            current_local=deepcopy(snapshot['current']), current_company=deepcopy(current),
            register_operation=self._safe_operation(register, 'acquisition_channel_register'),
            original_operation=self._safe_operation(receipt, CLOUD_ACTION), origin_binding_verified=bool(register and register['state'] == 'recorded'),
            registration_source_verified=bool(matched and snapshot['attempt']['registration_source_verified']),
            company_event_payload_matched=bool(proof and proof['binding'] and proof['binding']['state'] == 'matched'),
            current_channel_source_matched=matched, eligible_for_company_submit=eligible,
            submission_execution_confirmed=True if recorded else None, cloud_read_requested=requested,
            cloud_submit_requested=dispatched, no_dispatch=not dispatched,
            no_dispatch_scope='this_submission_get_only' if read_only else 'this_submission_call_only',
            source_cloud_binding_verified=False, platform_delivery_verified=False, financial_receipt_verified=False,
            cooperation_policy_verified=False, verified_cash_cents=None, verified_paid_commission_cents=None,
            settlement_active=False, auto_retry=False, provider_requests_started=False, platform_requests_started=False,
            contacts_modified=False, local_handoffs_modified=False, ratings_modified=False)

    def _recover(self, snapshot, user, *, read_only):
        row = snapshot['submission']
        receipt = self._status(snapshot, row)
        self._fence(snapshot, user)
        proof = self._corroborate(snapshot, user)
        if (receipt['state'] == 'recorded' and (not proof or proof['register']['state'] != 'recorded'
                or receipt['current_handoff'] != proof['register']['current_handoff'])):
            _fail('CURRENT_CHANGED', '原提交与当前登记版本需再次核对，原编号继续保留')
        final = self._fence(snapshot, user)
        return self._result(final, proof, receipt, read_only=read_only)

    def execute(self, action, data, user):
        fields = {'handoff_id'} if action == GET else {'handoff_id', 'expected_origin_id', 'expected_handoff_revision', 'expected_cloud_revision'}
        if (action not in (GET, SUBMIT) or not isinstance(data, dict) or set(data) != fields
                or not isinstance(data.get('handoff_id'), str) or not _HANDOFF.fullmatch(data['handoff_id'])
                or (action == SUBMIT and (not isinstance(data.get('expected_origin_id'), str)
                    or not _HEX.fullmatch(data['expected_origin_id']) or not _integer(data.get('expected_handoff_revision'), 1)
                    or not _integer(data.get('expected_cloud_revision'), 1)))):
            _fail('INVALID_INPUT', '公司提交只接受本人原交接与当前确认版本，不能传入新编号或联系人', 400)
        started = False
        try:
            before = self._snapshot(data['handoff_id'], user)
            if before['submission'] is not None:
                started = action == SUBMIT
                return self._recover(before, user, read_only=action == GET)
            proof = self._corroborate(before, user)
            if action == GET:
                return self._result(self._fence(before, user), proof, read_only=True)
            origin = before['origin']
            if (not origin or origin['origin_id'] != data['expected_origin_id']
                    or origin['handoff_revision'] != data['expected_handoff_revision']):
                _fail('ORIGIN_CHANGED', '页面与原准备不一致，请先读取原交接')
            if not self._eligible(before, proof):
                _fail('SUBMISSION_BLOCKED', '原公司草稿、来源、当前授权或提交权益尚未核对，提交保持暂停')
            if proof['item']['revision'] != data['expected_cloud_revision']:
                _fail('REVISION_CHANGED', '公司草稿版本已变化，请按原交接重新核对')
            self._fence(before, user)
            with self.core.lock, self.core.store.connect() as db:
                db.execute('PRAGMA busy_timeout=500')
                db.execute('BEGIN IMMEDIATE')
                fresh = self.registration._tx_snapshot(db, data['handoff_id'], user)
                if (fresh['fingerprint'] != before['fingerprint'] or self.registration._row(db, fresh) != before['attempt']):
                    _fail('LOCAL_CHANGED', '提交前原来源或本人授权已变化，本次未提交')
                row = self._row(db, fresh)
                owns_dispatch = row is None
                if owns_dispatch:
                    now = int(self.clock())
                    if not _integer(now, 1577836800):
                        _fail('CLOCK_UNAVAILABLE', '本机可信时间不可用，未提交')
                    body = self._body(origin, data['expected_cloud_revision'])
                    row = self._put(db, dict(id=self._record_id(data['handoff_id']), version=1, tenant_id=self.tenant,
                        cloud_owner=self.owner, company_id=self.preparation.company_id, environment_id=self.preparation.environment_id,
                        device_id=self.device_id, actor_id=fresh['actor']['id'], handoff_id=data['handoff_id'], origin_id=origin['origin_id'],
                        handoff_revision=origin['handoff_revision'], expected_cloud_channel_id=origin['expected_cloud_channel_id'],
                        expected_cloud_revision=data['expected_cloud_revision'], cloud_idempotency_key=body['idempotency_key'],
                        cloud_payload_hash=_hash(body), state='unknown', created_at=now, updated_at=now, revision=1), new=True)
                    started = True
                    self._commit(db)
                else:
                    db.rollback()
            if not owns_dispatch:
                started = True
                return self._recover(self._snapshot(data['handoff_id'], user), user, read_only=False)
            submitted = dict(before, submission=row)
            self._fence(submitted, user)
            answer = self.cloud_submit(deepcopy(before['actor']), CLOUD_ACTION, deepcopy(body))
            if (not isinstance(answer, dict) or set(answer) != {'item', 'replayed'} or type(answer['replayed']) is not bool
                    or not isinstance(answer['item'], dict)):
                _fail('WRITE_RECEIPT_INVALID', '公司提交回执需核对，原号继续保留', mutation=None)
            self._fence(submitted, user)
            receipt = self._status(submitted, row)
            self._fence(submitted, user)
            after_proof = self._corroborate(submitted, user)
            if (receipt['state'] != 'recorded' or not after_proof or after_proof['item'] is None
                    or receipt['current_handoff'] != after_proof['register']['current_handoff']
                    or answer['item'] != after_proof['item']):
                _fail('RESULT_UNKNOWN', '原公司提交或来源仍待核对，请保留原号；未自动重发', mutation=None)
            with self.core.lock, self.core.store.connect() as db:
                db.execute('PRAGMA busy_timeout=500')
                db.execute('BEGIN IMMEDIATE')
                fresh = self.registration._tx_snapshot(db, data['handoff_id'], user)
                if (fresh['fingerprint'] != before['fingerprint'] or self.registration._row(db, fresh) != before['attempt']
                        or self._row(db, fresh) != row):
                    _fail('LOCAL_CHANGED', '保存提交回执前当前范围已变化，请保留原号', mutation=None)
                row = self._put(db, dict(row, state='recorded', updated_at=max(row['created_at'], int(self.clock())), revision=row['revision']+1))
                self._commit(db)
            final = self._fence(dict(before, submission=row), user)
            return self._result(final, after_proof, receipt, read_only=False, dispatched=True, committed=True)
        except CompanyHandoffSubmissionError as error:
            if action == GET:
                error.mutation_committed = False
            elif started:
                error.mutation_committed = None
            raise
        except Exception as error:
            session = getattr(error, 'code', '').endswith('_SESSION_REQUIRED')
            _fail('SESSION_REQUIRED' if session else 'RESULT_UNKNOWN' if started else 'UNAVAILABLE',
                '请明确连接原公司后按原提交编号核对' if session else '公司原提交暂不可核对，请保留原号；未自动重发',
                409 if session or started else 503, mutation=None if started and action != GET else False)
