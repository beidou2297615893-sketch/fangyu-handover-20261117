"""Bounded semantic analysis worker, independent of platform and command threads."""
import threading
import time
from datetime import datetime,timedelta
from assistant.ai_workflow import model_metadata
from core import CoreError

# Invalid inputs and unknown billing require a changed enterprise configuration or
# an explicit retry. Repeating them unattended can consume money without a result.
PRODUCT_REVIEW_CODES=frozenset(('PRODUCT_AUTH_REQUIRED','PRODUCT_TENANT_INVALID','PRODUCT_TENANT_MISMATCH',
    'PRODUCT_STORAGE_UNAVAILABLE','PRODUCT_POLICY_INVALID','PRODUCT_SERVER_CONFIG_INVALID',
    'PRODUCT_EXPIRED','PRODUCT_FEATURE_DENIED','PRODUCT_PERIOD_REQUIRED','PRODUCT_PERIOD_INACTIVE',
    'PRODUCT_PERIOD_CONFLICT','PRODUCT_REQUEST_INVALID','PRODUCT_REQUEST_SCOPE','PRODUCT_REQUEST_CANCELLED',
    'PRODUCT_REQUEST_CONFLICT','PRODUCT_REQUEST_UNKNOWN','PRODUCT_REQUEST_RELEASED','PRODUCT_REQUEST_RESOLVED',
    'PRODUCT_ANALYSIS_LIMIT','PRODUCT_SETTLEMENT_SCOPE','PRODUCT_SETTLEMENT_CONFLICT'))
REVIEW_CODES=frozenset(('AI_INVALID_INPUT','AI_INVALID_OUTPUT','AI_BILLING_UNKNOWN',
                        'AI_UNPRICED_MODEL','AI_TENANT_MISMATCH','AI_ADMIN_REQUIRED',
                        'AI_PROVIDER_TIMEOUT',
                        'AI_PROVIDER_UNAVAILABLE','AI_PROVIDER_BODY_TOO_LARGE',
                        'AI_PROVIDER_INVALID_RESPONSE','AI_LEDGER_CONFLICT',
                        'AI_PROVIDER_BALANCE','AI_PROVIDER_AUTH'))|PRODUCT_REVIEW_CODES
KNOWN_CODES=REVIEW_CODES|frozenset(('AI_DAILY_BUDGET','AI_NOT_CONFIGURED','AI_DISABLED',
                                    'AI_PROVIDER_REJECTED','AI_IN_PROGRESS',
                                    'AI_TRANSACTION_UNAVAILABLE','AI_SERVICE_UNAVAILABLE',
                                    'AI_UNAVAILABLE','AI_AUTH_REQUIRED','AI_CONTEXT_REQUIRED','AI_CONFIG_CHANGED'))

def needs_analysis(lead):
    return (not lead.get('demo') and not lead.get('manual_intent') and not lead.get('ai_intent')
            and (isinstance(lead.get('text'),str) and bool(lead['text'].strip())
                 or lead.get('analysis_status')!='missing_text'))

def safe_error_code(error):
    code=getattr(error,'code',None)
    if isinstance(code,str) and code in KNOWN_CODES:return code
    # Workspace authentication happens before the AI handler and returns a
    # plain HTTP status. IntegrationError preserves it as http_status.
    status=getattr(error,'http_status',None)
    if status==401:return 'AI_AUTH_REQUIRED'
    if status==403:return 'AI_ADMIN_REQUIRED'
    return 'AI_UNAVAILABLE'

class AIWorker:
    def __init__(self, executor):
        self.executor=executor
        self.stop_event=threading.Event()
        self.thread=None
        self.retry_after=0

    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self._loop,name='comment-analysis',daemon=True)
        self.thread.start()

    def close(self):
        self.stop_event.set()

    def step(self):
        executor=self.executor
        user=executor.core.store.get('users',executor.user_id)
        if not user or user.get('disabled'):return
        # A disabled/expired product entitlement cannot enter the automatic
        # provider queue. Existing results and manual corrections stay intact.
        from core.service_plans import require_feature, ProductAccessError
        try:
            require_feature(getattr(getattr(executor, 'server', None), 'company', {}), 'intent_analysis')
        except ProductAccessError:
            return
        # Existing comments join the same bounded queue once enterprise AI is enabled.
        leads=executor.core.store.list('leads',executor.tenant)
        tasks=[]
        for task in executor.core.store.list('tasks',executor.tenant):
            try:executor.core._task_access(user,task,executor.tenant)
            except CoreError:continue
            task_leads=list(executor._analysis_visible_leads(user,task,leads))
            previous=executor.core.store.get('ai_jobs',task['id']) or {}
            if previous and previous.get('tenant_id')==executor.tenant:
                # Refresh the visible local denominator even if no eligible
                # comment remains. Preserve paused/unknown billing and retry
                # metadata; filtering a row is never evidence of analysis.
                current=[lead for lead in task_leads if not lead.get('demo')
                         and not lead.get('manual_intent') and not lead.get('ai_intent')]
                valid=sum(isinstance(lead.get('text'),str) and bool(lead['text'].strip())
                          for lead in current)
                excluded=len(current)-valid
                if (previous.get('pending'),previous.get('excluded_missing_text'))!=(valid,excluded):
                    executor.core.store.put('ai_jobs',{**previous,'pending':valid,
                        'excluded_missing_text':excluded})
            if any(needs_analysis(lead) for lead in task_leads):
                tasks.append(task)
        if not tasks or time.time()<self.retry_after:return
        try:
            profile=executor.ai.cloud(user,'ai_profile',{})
            config=profile.get('config',profile)
            revision=config.get('revision')
            if type(revision) is not int:return
            if not config.get('enabled') or not config.get('configured'):
                code='AI_DISABLED' if not config.get('enabled') else 'AI_NOT_CONFIGURED'
                for task in tasks:
                    pending=sum(needs_analysis(lead) for lead in executor._analysis_visible_leads(user,task))
                    previous=executor.core.store.get('ai_jobs',task['id']) or {}
                    # A temporarily disabled profile is not evidence that an
                    # earlier paid attempt is safe to retry. The local recount
                    # above already updated its visible pending count.
                    if previous.get('status')=='paused' and previous.get('tenant_id')==executor.tenant:
                        continue
                    if (previous.get('tenant_id'),previous.get('profile_revision'),previous.get('code'),previous.get('pending')) == (executor.tenant,revision,code,pending):
                        continue
                    executor.core.store.put('ai_jobs',{'id':task['id'],'tenant_id':executor.tenant,'task_id':task['id'],
                        'profile_revision':revision,'status':'pending','pending':pending,'code':code,
                        'retry_count':0,'message':'企业 AI 尚未启用，评论已保存，待管理员配置',
                        'updated_at':datetime.now().isoformat()})
                return
        except Exception as error:
            # Profile is a read-only cloud check. Probe again soon after login
            # or connectivity recovers, without submitting a paid request.
            code=safe_error_code(error)
            for task in tasks:
                pending=sum(needs_analysis(lead) for lead in executor._analysis_visible_leads(user,task))
                previous=executor.core.store.get('ai_jobs',task['id']) or {}
                # A failed read-only profile check cannot clear a paid-retry pause.
                # Local queue counts were already refreshed before this request.
                if previous.get('status')=='paused' and previous.get('tenant_id')==executor.tenant:
                    continue
                if (previous.get('tenant_id'),previous.get('code'),previous.get('pending')) == (executor.tenant,code,pending):
                    continue
                executor.core.store.put('ai_jobs',{'id':task['id'],'tenant_id':executor.tenant,'task_id':task['id'],
                    'status':'pending','pending':pending,'code':code,'retry_count':0,
                    'message':'企业 AI 授权待恢复，评论已保存；恢复后自动分析' if code=='AI_AUTH_REQUIRED'
                              else 'AI 暂不可用，评论已保存；稍后自动检查',
                    'updated_at':datetime.now().isoformat()})
            self.retry_after=time.time()+60
            return
        tasks.sort(key=lambda task:((executor.core.store.get('ai_jobs',task['id']) or {}).get('updated_at',''),task['id']))
        for task in tasks:
            if self.stop_event.is_set():return
            previous=executor.core.store.get('ai_jobs',task['id']) or {}
            same_revision=previous.get('profile_revision')==revision
            # Existing installations may have paused an old missing-city task
            # as AI_INVALID_INPUT before local context validation existed.
            # Re-evaluate that legacy record once; every other paused reason,
            # including unknown billing, remains stopped.
            legacy_input_recheck=(same_revision and previous.get('status')=='paused'
                                  and previous.get('code')=='AI_INVALID_INPUT'
                                  and previous.get('context_preflight_checked') is not True)
            # A model/rules revision is not a receipt that an unknown resource
            # request is safe to repeat, or that a service period has renewed.
            if previous.get('status')=='paused' and previous.get('code') in PRODUCT_REVIEW_CODES:continue
            if same_revision and previous.get('status')=='paused' and not legacy_input_recheck:continue
            if same_revision and previous.get('retry_after',0)>time.time():continue
            pending=[lead for lead in executor._analysis_visible_leads(user,task) if needs_analysis(lead)]
            if not pending:continue
            status={'id':task['id'],'tenant_id':executor.tenant,'task_id':task['id'],
                    'profile_revision':revision,'updated_at':datetime.now().isoformat(),
                    **model_metadata(config)}
            try:
                executor.core.store.put('ai_jobs',{**status,'status':'running','pending':len(pending)})
                result=executor.analyze_pending(user,{'task_id':task['id']})
                status.update(model_metadata(result,config))
                excluded=result.get('excluded_missing_text',0)
                status.update(status='pending' if excluded and not result.get('pending') else 'ready',
                              pending=result.get('pending',0),excluded_missing_text=excluded,
                              last_analyzed=result.get('analyzed',0),retry_count=0)
                if excluded and not result.get('pending'):
                    status['message']='无正文评论待核实，未提交 AI 分析'
            except Exception as error:
                # No provider response or customer text in logs. Preserve all pending leads.
                code=safe_error_code(error)
                failures=min(3,(previous.get('retry_count',0) if same_revision else 0)+1)
                current=[lead for lead in executor._analysis_visible_leads(user,task)
                         if not lead.get('demo') and
                         not lead.get('manual_intent') and not lead.get('ai_intent')]
                valid=sum(isinstance(lead.get('text'),str) and bool(lead['text'].strip()) for lead in current)
                excluded=sum(lead.get('analysis_status')=='missing_text' and
                             (not isinstance(lead.get('text'),str) or not lead['text'].strip()) for lead in current)
                status.update(status='pending',pending=valid,excluded_missing_text=excluded,code=code,retry_count=failures,
                              message='AI 暂不可用，评论已保存，稍后继续分析')
                # Three short attempts open a one-hour circuit. The next probe
                # remains automatic, including after restart; a new revision
                # bypasses this same-revision cooldown at the next worker tick.
                retry_after=time.time()+(3600 if failures>=3 else 300*2**(failures-1))
                if code=='AI_DAILY_BUDGET':
                    tomorrow=datetime.now().date()+timedelta(days=1)
                    retry_after=datetime.combine(tomorrow,datetime.min.time()).timestamp()
                    status['message']='今日 AI 预算已用完，评论已保存，明天继续分析'
                    status['retry_count']=0
                elif code in ('AI_NOT_CONFIGURED','AI_DISABLED'):
                    status['message']='企业 AI 尚未启用，评论已保存，待管理员配置'
                    status['retry_count']=0
                elif code=='AI_AUTH_REQUIRED':
                    status['message']='企业 AI 授权待恢复，评论已保存；恢复后自动分析'
                    status['retry_count']=0
                    retry_after=time.time()+60
                elif code=='AI_CONFIG_CHANGED':
                    status['message']='企业 AI 配置已变化，正在核对新模型后继续分析'
                    status['retry_count']=0
                    retry_after=time.time()+15
                elif code=='AI_CONTEXT_REQUIRED':
                    status['message']='采集任务缺少目标城市或帖子上下文，评论待补范围后自动分析'
                    status['retry_count']=0
                    retry_after=time.time()+60
                elif code in PRODUCT_REVIEW_CODES:
                    status.update(status='paused',retry_count=0)
                    retry_after=0
                    status['message']=('分析结果尚未核对，原额度保留；核对原请求后再决定，未自动重试'
                        if code=='PRODUCT_REQUEST_UNKNOWN' else
                        '当前服务分析额度不足，评论已保存；核对可信服务周期和额度后点继续分析'
                        if code=='PRODUCT_ANALYSIS_LIMIT' else
                        '服务周期未配置、未开始或已结束，评论已保存；请管理员核对后点继续分析'
                        if code in ('PRODUCT_PERIOD_REQUIRED','PRODUCT_PERIOD_INACTIVE') else
                        '当前服务授权已到期或此功能未开放，评论已保存；请管理员核对服务权益'
                        if code in ('PRODUCT_EXPIRED','PRODUCT_FEATURE_DENIED') else
                        '原服务请求或额度账本需核对，评论已保存；未自动重试，也未生成新请求编号')
                elif code in REVIEW_CODES:
                    status['status']='paused'
                    status['message']=('企业 AI 余额不足，充值后点继续分析' if code=='AI_PROVIDER_BALANCE'
                                       else '企业 AI 密钥无效，请管理员检查后点继续分析' if code=='AI_PROVIDER_AUTH'
                                       else 'AI 分析需核对企业配置，评论已保存，未继续计费重试')
                    status['retry_count']=0
                    retry_after=0
                    if code=='AI_INVALID_INPUT':status['context_preflight_checked']=True
                elif failures>=3:
                    status['message']='AI 暂不可用，评论已保存；将稍后自动重试'
                status['retry_after']=retry_after
            executor.core.store.put('ai_jobs',status)
            if status.get('code')=='AI_CONTEXT_REQUIRED' or status.get('excluded_missing_text') and not status.get('pending'):
                continue
            # One same-post batch per tick prevents AI requests monopolizing the machine.
            return

    def _loop(self):
        while not self.stop_event.wait(15):
            try:self.step()
            except Exception:self.retry_after=time.time()+300
