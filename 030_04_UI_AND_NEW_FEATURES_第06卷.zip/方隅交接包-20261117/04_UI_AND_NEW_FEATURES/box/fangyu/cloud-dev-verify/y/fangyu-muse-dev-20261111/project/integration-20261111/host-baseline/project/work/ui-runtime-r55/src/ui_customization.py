"""Versioned customer UI seam. Data-only configuration, no executable templates."""
import json
import re
from pathlib import Path

PAGES = ('tasks', 'leads', 'accounts', 'settings')
COLORS = ('accent', 'soft', 'wash', 'line')

def load_customization(directory):
    directory = Path(directory)
    result = {'schemaVersion': 1, 'sections': {}, 'copy': {}, 'assets': {}, 'warnings': []}
    for filename, key in [('主题.json', 'sections'), ('文案.json', 'copy'), ('素材映射.json', 'assets')]:
        path = directory / filename
        if not path.is_file():
            continue
        try:
            if path.stat().st_size > 1024 * 1024:
                raise ValueError('配置超过1MB')
            data = json.loads(path.read_text('utf-8-sig'))
            if not isinstance(data, dict):
                raise ValueError('必须为JSON对象')
            if key == 'sections':
                if data.get('schemaVersion', 1) != 1:
                    raise ValueError('不支持的配置版本')
                for page, values in data.get('sections', {}).items():
                    if page not in PAGES or not isinstance(values, dict):
                        continue
                    result[key][page] = {k: v for k, v in values.items() if k in COLORS and isinstance(v, str) and re.fullmatch(r'#[0-9a-fA-F]{6}', v)}
            elif key == 'copy':
                result[key] = {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str) and 0 < len(k) <= 250 and 0 < len(v) <= 1000}
            else:
                result[key] = {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str) and Path(k).name == k and '/' not in k and '\\' not in k and Path(v).name == v and '/' not in v and '\\' not in v and ':' not in v and Path(v).suffix.lower() in {'.png', '.webp', '.jpg', '.jpeg', '.gif'}}
        except (ValueError, OSError, TypeError) as exc:
            result['warnings'].append(f'{filename}未应用：{exc}')
    return result

def replacement_asset(directory, config, original):
    filename = config.get('assets', {}).get(original)
    if not filename:
        return None
    base = (Path(directory) / '图片').resolve()
    target = (base / filename).resolve()
    if target.parent != base or not target.is_file():
        return None
    return target
