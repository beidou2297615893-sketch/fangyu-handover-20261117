"""Owner-thread lifecycle only; this scope is not a Native route approval.

The production helper needs a separately reviewed principal/device/runtime
provider. The old one-argument Popen factory cannot accept this private context
and is rejected before spawn. Never infer that missing provider from task data.
"""
from contextlib import contextmanager
import hashlib
import json
import threading

from core.adapters import AdapterBusy, AdapterSafetyRequired, account_execution_lock


def _binding(user, task, account):
    selected = (
        {k: user.get(k) for k in ('id', 'tenant_id', 'username', 'role', 'disabled', 'cloud_bound')},
        {k: task.get(k) for k in ('id', 'tenant_id', 'platform', 'account_id', 'cloud_owner',
             'strategy_source', 'updated_at', 'scope', 'keywords', 'continuous_enabled',
             'note_url', 'excludes', 'region', 'city', 'area', 'date_from', 'date_to',
             'comment_date_range', 'comment_date_from', 'comment_date_to',
             'excluded_authors', 'excluded_bloggers', 'comment_depth',
             'comment_keyword_mode', 'unknown_policy', 'blogger_unknown_policy',
             'intent_mode', 'high_intent_words', 'medium_intent_words',
             'negative_intent_words', 'daily_limit', 'target_count', 'search_pages',
             'time_start', 'time_end')},
        {k: account.get(k) for k in ('id', 'tenant_id', 'platform', 'platform_uid',
                                    'cloud_owner', 'status', 'requires_review', 'updated_at')},
    )
    return hashlib.sha256(json.dumps(selected, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).digest()


class _BatchScope:
    def __init__(self, runtime, user, task, execution_guard, *, retain_result=False):
        from .xhs_app_context import XhsAppHostContext, AppContextRequired
        if type(runtime.app_context_factory) is not XhsAppHostContext:
            raise AppContextRequired()
        self.app_context = runtime.app_context_factory.capture(user, task)
        self.runtime = runtime
        self.thread = threading.current_thread()
        self.user_id, self.task_id = user['id'], task['id']
        self.tenant, self.account_id = user['tenant_id'], task['account_id']
        self.root = (runtime.core.store.directory / 'accounts' / self.tenant / self.account_id).resolve()
        self.execution_guard = execution_guard
        self.entered = self.finished = False
        self.os_lock = account_execution_lock(self.root)
        self.entry = None
        self.binding = None
        self.retain_result = retain_result
        self.user_cancelled = False
        self.result_released = False

    def check(self):
        if (threading.current_thread() is not self.thread or self.finished or
                self.entry is not None and self.entry.batch_scope is not self):
            raise AdapterSafetyRequired('页面采集必须由原批次线程持有')
        if self.user_cancelled:
            raise AdapterSafetyRequired("原采集请求已取消")
        return self._check_binding()

    def _check_binding(self):
        self.app_context.check()
        core = self.runtime.core
        current = core.store.get('users', self.user_id)
        task = core._get('tasks', self.task_id, self.tenant)
        account = core._get('accounts', self.account_id, self.tenant)
        if (not current or current.get('disabled') or current.get('tenant_id') != self.tenant
                or task.get('account_id') != self.account_id
                or task.get('platform') != 'xiaohongshu'):
            raise AdapterSafetyRequired('原员工、任务或账号范围已变化')
        core._task_access(current, task, self.tenant)
        core._account_access(current, account)
        core.require_platform('xiaohongshu')
        core._platform_execution_guard('xiaohongshu')
        if self.execution_guard is not None:
            self.execution_guard()
        binding = _binding(current, task, account)
        if self.binding is not None and self.binding != binding:
            raise AdapterSafetyRequired('原员工、任务或账号版本已变化')
        return binding

    def __enter__(self):
        self.enter()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.finish()

    def require_result(self):
        # Result/continuation gates are short and hold Core before runtime,
        # the same order as the original pause/cancel API. Never gate cleanup.
        with self.runtime.core.lock:
            with self.runtime.lock:
                if (threading.current_thread() is not self.thread or not self.finished
                        or self.result_released
                        or self.runtime.jobs.get(self.task_id) is not self
                        or self.user_cancelled):
                    raise AdapterSafetyRequired("原采集请求已取消或结果范围已变化")
            self._check_binding()

    def commit_result(self, commit):
        with self.runtime.core.lock:
            self.require_result()
            return commit()

    def release_result(self):
        if threading.current_thread() is not self.thread:
            raise AdapterBusy("必须由原采集线程结束结果范围")
        if not self.finished:
            return
        with self.runtime.lock:
            if self.runtime.jobs.get(self.task_id) is self:
                self.runtime.jobs.pop(self.task_id)
            self.result_released = True

    def enter(self):
        self.binding = self.check()
        self.runtime._account(self.root)
        self.root, entry = self.runtime._entry(self.root)
        self.entry = entry
        with self.runtime.lock:
            if (entry.batch_scope is not None or entry.login_reserved or self.runtime.closed
                    or self.task_id in self.runtime.jobs):
                raise AdapterBusy('原账号窗口仍由另一批次持有，尚不能切换')
            entry.batch_scope = self
            self.runtime.jobs[self.task_id] = self
        try:
            self.os_lock.__enter__()
            self.entered = True
            self.binding = self.check()
            entry.lock.acquire()
        except BaseException:
            if self.entered:
                self.os_lock.__exit__(None, None, None)
                self.entered = False
            with self.runtime.lock:
                if entry.batch_scope is self:
                    entry.batch_scope = None
                if self.runtime.jobs.get(self.task_id) is self:
                    self.runtime.jobs.pop(self.task_id)
            raise

    def finish(self):
        if threading.current_thread() is not self.thread:
            raise AdapterBusy('必须由原采集线程确认窗口关闭')
        if self.finished:
            return
        entry = self.entry
        # Remain on the original worker. No new read/spawn/authorization retry.
        # A visible verification page stays owned until an explicit stop.
        while entry.transport is not None:
            if entry.verification_hold and not entry.stop_requested:
                entry.lifecycle_wake.wait(.2)
                entry.lifecycle_wake.clear()
                continue
            try:
                self.runtime._close_locked(entry)
            except Exception:
                entry.lifecycle_wake.wait(.2)
                entry.lifecycle_wake.clear()
        self.finished = True
        entry.lock.release()
        self.os_lock.__exit__(None, None, None)
        self.entered = False
        with self.runtime.lock:
            if entry.batch_scope is self:
                entry.batch_scope = None
            if not self.retain_result and self.runtime.jobs.get(self.task_id) is self:
                self.runtime.jobs.pop(self.task_id)
            entry.stop_requested = False


def first_search_scope(runtime, user, task, execution_guard=None):
    # Private logical result stays exact even after physical Job/lock closure.
    return _BatchScope(runtime, user, task, execution_guard, retain_result=True)


@contextmanager
def collection_scope(runtime, user, task, execution_guard=None):
    """Only called by the authenticated Core/bound first-search caller."""
    scope = _BatchScope(runtime, user, task, execution_guard)
    scope.enter()
    try:
        yield scope
    finally:
        # Unexpected interruption deliberately leaves entry/lock/scope retained.
        # There is no cross-thread ExitStack or fallback ordinary Popen route.
        scope.finish()
