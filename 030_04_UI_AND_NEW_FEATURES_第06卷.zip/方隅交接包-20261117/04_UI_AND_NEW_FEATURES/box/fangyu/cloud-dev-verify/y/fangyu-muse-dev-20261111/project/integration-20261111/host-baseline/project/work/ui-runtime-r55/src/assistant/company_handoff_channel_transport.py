"""One exact channel detail read through the current unrefreshed session."""
from copy import deepcopy
import re
from .company_handoff_status_transport import CompanyHandoffStatusTransport, _fail

ACTION = 'acquisition_handoff_detail'
_CHANNEL = re.compile(r'hc_[a-f0-9]{64}\Z')
_FIELDS = frozenset(('contract', 'environment_id', 'company_id', 'item', 'server_recorded',
    'platform_delivery_verified', 'attribution_confirmed', 'settlement_active',
    'read_only', 'mutation_committed', 'auto_retry'))


class CompanyHandoffChannelTransport(CompanyHandoffStatusTransport):
    def __call__(self, actor, operation, data):
        if (operation != ACTION or not isinstance(data, dict) or set(data) != {'channel_id'}
                or not isinstance(data['channel_id'], str) or not _CHANNEL.fullmatch(data['channel_id'])):
            _fail('INVALID_REQUEST', '公司详情只接受原准备派生的固定编号', 400)
        before = self._capture(actor, 60)
        from integrations import request_json
        try:
            result = request_json(before['endpoint'], dict(environment_id=self.environment_id,
                operation=ACTION, **deepcopy(data)), before['token'])
        except Exception:
            _fail('READ_UNAVAILABLE', '公司当前草稿暂不可读，请保留原编号')
        after = self._capture(actor, 0)
        if after != before:
            _fail('BINDING_CHANGED', '详情返回时公司连接或本人范围已变化', 409)
        if (not isinstance(result, dict) or set(result) != _FIELDS
                or result['contract'] != 'fangyu-workspace-v1'
                or result['environment_id'] != self.environment_id or result['company_id'] != self.company_id
                or not isinstance(result['item'], dict) or result['server_recorded'] is not True
                or result['read_only'] is not True or result['mutation_committed'] is not False
                or result['auto_retry'] is not False
                or any(result[key] is not False for key in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))):
            _fail('READ_UNAVAILABLE', '公司详情身份或纯读格式需核对，请保留原编号')
        self._principal(actor)
        return {key: deepcopy(result[key]) for key in _FIELDS if key not in ('contract', 'environment_id', 'company_id')}
