"""One explicit same-identity status attempt; never a collection or send grant.

The private stdin/ledger protocol prevents accidental inheritance and replay.
It is not a sandbox against the Windows account that owns these files.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import stat
import threading
import time

SCHEMA = 'xhs-identity-revalidation-v1'
STATUS_URL = 'https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
MAX_LOG = 8 * 1024 * 1024
_SEAL = object()
_HEX = re.compile(r'[a-f0-9]{64}\Z')
_ID = re.compile(r'[a-f0-9]{32}\Z')


class IdentityRecoveryError(RuntimeError):
    def __init__(self, code):
        super().__init__('本次账号身份未完成核实，采集保持暂停。')
        self.code = code


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True,
        ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def _plain(path, *, directory=False):
    path = Path(path).absolute()
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise IdentityRecoveryError('RECOVERY_SCOPE_INVALID')
    info = path.stat()
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise IdentityRecoveryError('RECOVERY_SCOPE_INVALID')
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise IdentityRecoveryError('RECOVERY_SCOPE_INVALID')
    return info


def read_activity(path):
    try:
        before = _plain(path)
        if before.st_size > MAX_LOG:
            raise ValueError
        with Path(path).open('rb') as stream:
            opened = os.fstat(stream.fileno())
            raw = stream.read(MAX_LOG + 1)
        after = _plain(path)
        if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                or (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino)
                or len(raw) > MAX_LOG or raw and not raw.endswith(b'\n')):
            raise ValueError
        return raw, (before.st_dev, before.st_ino)
    except IdentityRecoveryError:
        raise
    except (OSError, ValueError):
        raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID') from None


def rows_of(raw):
    rows = []
    offset = 0
    try:
        if raw and not raw.endswith(b'\n'):
            raise ValueError
        for line in raw.splitlines(keepends=True):
            value = json.loads(line.decode('utf-8'))
            if (type(value) is not dict or type(value.get('at')) not in (int, float)
                    or not math.isfinite(value['at']) or value['at'] < 0):
                raise ValueError
            rows.append((offset, offset + len(line), value))
            offset += len(line)
        return rows
    except (ValueError, UnicodeError, TypeError):
        raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID') from None


def credential_fingerprint(directory):
    """Hash only this existing CLI session; no capture, parsing or credential export."""
    path=Path(directory)/'.xiaohongshu-cli/cookies.json'
    try:
        before=_plain(path)
        if before.st_size>65536:raise ValueError
        raw=path.read_bytes();after=_plain(path)
        identity=lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns)
        if identity(before)!=identity(after):raise ValueError
        return digest(raw)
    except (OSError,ValueError):
        raise IdentityRecoveryError('RECOVERY_HANDOFF_UNAVAILABLE') from None


def _receipt(raw, revision, attempt_id, *, complete=False):
    rows = rows_of(raw[revision:])
    if len(rows) > 3 or complete and len(rows) != 3:
        raise IdentityRecoveryError('RECOVERY_RECEIPT_INVALID')
    stages = ('started', 'finished', 'cli_finished')
    request_id = None
    for index, (_, _, row) in enumerate(rows):
        if (row.get('stage') != stages[index] or row.get('kind') != 'status'
                or row.get('attempt_id') != attempt_id):
            raise IdentityRecoveryError('RECOVERY_RECEIPT_INVALID')
        if index == 0:
            request_id = row.get('request_id')
            if (not isinstance(request_id, str) or re.fullmatch(r'[a-f0-9]{16}', request_id) is None
                    or row.get('method') != 'GET'):
                raise IdentityRecoveryError('RECOVERY_RECEIPT_INVALID')
        elif index == 1:
            if (row.get('request_id') != request_id or row.get('method') != 'GET'
                    or type(row.get('status')) is not int or row['status'] != 200
                    or row['at'] < rows[0][2]['at']):
                raise IdentityRecoveryError('RECOVERY_RECEIPT_INVALID')
        elif (row.get('status') != 'completed' or row.get('exit_code') != 0
                or row.get('request_id') != request_id or row['at'] < rows[1][2]['at']):
            raise IdentityRecoveryError('RECOVERY_RECEIPT_INVALID')
    return rows, request_id


def scan_activity(raw):
    """Strict ordered journal interpretation shared by runtime and packed CLI."""
    pending = []
    nonrecoverable_other = set()
    unfinished = {}
    seen = set()
    finished = {}
    last_finished = 0.0
    resolution_count = 0
    for start, end, row in rows_of(raw):
        stage, kind, status = row.get('stage'), row.get('kind'), row.get('status')
        if stage == 'started':
            ident = row.get('request_id')
            if (not isinstance(ident, str) or not ident or ident in seen
                    or kind not in (None,'login','status','whoami','search','read','comments','sub-comments','reply','other')
                    or row.get('method') not in (None,'GET','POST','OTHER')):
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
            seen.add(ident)
            unfinished[ident] = row
        elif stage == 'finished':
            ident = row.get('request_id')
            before = unfinished.pop(ident, None)
            if before is None or before.get('kind') != kind or row['at'] < before['at']:
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
            if not (type(status) is int and 100 <= status <= 599 or status in (
                    'transport_error','api_error','protocol_error','cancelled_before_send',
                    'page_read_complete','page_local_error')):
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
            finished[ident] = row
            if status != 'cancelled_before_send':
                last_finished = max(last_finished, row['at'])
            if type(status) is int and status in (401,403,461,471):
                pending.append((end, kind not in (None,'other') and before.get('method') in ('GET','POST')))
            elif (type(status) is int and (status == 429 or 300 <= status < 400)
                    or status in ('transport_error','api_error','protocol_error','page_local_error')):
                pending.append((end, False))
                nonrecoverable_other.add(end)
        elif stage in ('cli_finished', 'browser_finished'):
            allowed = ('completed','not_authenticated','verification_required','ip_blocked',
                'start_failed','process_failed','timeout','transport_error','protocol_error',
                'signature_error','api_error','unsupported_operation')
            if status not in allowed or not isinstance(kind, str):
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
            if status != 'completed':
                matching = [value for value in finished.values() if value.get('kind') == kind]
                paired = matching and matching[-1]['at'] <= row['at'] and matching[-1].get('status') in (401,403,461,471)
                pending.append((end, bool(stage == 'cli_finished' and paired
                    and status in ('not_authenticated','verification_required'))))
                # A directly observed browser challenge keeps its diagnosis but
                # is still not a paired CLI receipt authorizing revalidation.
                if not (stage == 'browser_finished' and status == 'verification_required') and not pending[-1][1]:
                    nonrecoverable_other.add(end)
        elif stage == 'manual_signal':
            if kind in ('phone_verification','unexpected_logout'):
                pending.append((end, True))
            elif kind == 'review_completed':
                # Legacy acknowledgement never erases an unfinished or unknown risk.
                pending = [entry for entry in pending if not entry[1]]
            else:
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
        elif stage == 'identity_revalidated':
            revision = row.get('covers_through_revision')
            attempt = row.get('attempt_id')
            if (type(revision) is not int or not 0 < revision < start
                    or not isinstance(attempt, str) or _ID.fullmatch(attempt) is None
                    or digest(raw[:revision]) != row.get('covered_prefix_sha256')
                    or row.get('receipt_start') != revision or row.get('receipt_end') != start
                    or not all(isinstance(row.get(key), str) and _HEX.fullmatch(row[key])
                        for key in ('scope_hash','uid_hash','account_revision','auth_generation_hash'))
                    or row.get('revalidation_generation') != attempt):
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
            _, request_id = _receipt(raw[:start], revision, attempt, complete=True)
            if request_id != row.get('request_id') or any(not recoverable for _, recoverable in pending):
                raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
            pending = [(offset, recoverable) for offset, recoverable in pending if offset > revision]
            resolution_count += 1
        else:
            raise IdentityRecoveryError('RECOVERY_ACTIVITY_INVALID')
    return {'pending': pending, 'unfinished': unfinished, 'last_finished': last_finished,
            'nonrecoverable_other_risk':any(offset in nonrecoverable_other for offset,_ in pending),
            'resolution_count': resolution_count}


def _atomic_json(path, value):
    temp = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
    try:
        with temp.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(value, sort_keys=True, separators=(',', ':')))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


class _RecoveryScope:
    def __init__(self, seal, adapter, account, directory, guard, finish, binding, lease_until, source_sha, candidate_provider=None):
        self.seal, self.adapter, self.account = seal, adapter, dict(account)
        self.directory = Path(directory).absolute()
        self.guard, self.finish, self.binding = guard, finish, digest(binding)
        self.lease_until, self.source_sha = lease_until, source_sha
        from assistant.browser_session_commit import account_revision
        self.expected_revision = account_revision(account)
        self.candidate_provider = candidate_provider
        self.active_credential = binding.get("cookie")
        self.candidate = None
        self.candidate_hash = None


def trusted_scope(adapter, account, directory, *, guard, finish, binding, lease_until, source_sha, candidate_provider=None):
    """Private caller Interface: runtime supplies its original authority checks."""
    if (not callable(guard) or not callable(finish) or not guard()
            or type(lease_until) not in (int, float) or lease_until <= time.monotonic()
            or not isinstance(account.get('platform_uid'), str) or not account['platform_uid'].strip()
            or account.get('platform') != 'xiaohongshu'
            or not isinstance(source_sha, str) or _HEX.fullmatch(source_sha) is None):
        raise IdentityRecoveryError('RECOVERY_SCOPE_INVALID')
    return _RecoveryScope(_SEAL, adapter, account, directory, guard, finish, binding, lease_until, source_sha, candidate_provider)


class IdentityAttempt:
    def __init__(self, scope):
        if type(scope) is not _RecoveryScope or scope.seal is not _SEAL:
            raise IdentityRecoveryError('RECOVERY_SCOPE_INVALID')
        self.scope, self.owner_thread = scope, threading.get_ident()
        self.attempt_id = secrets.token_hex(16)
        self.path = scope.directory / 'platform-activity.jsonl'
        self.raw, self.identity = read_activity(self.path)
        state = scan_activity(self.raw)
        if state['unfinished'] or not state['pending'] or any(not item[1] for item in state['pending']):
            raise IdentityRecoveryError('RECOVERY_NOT_ELIGIBLE')
        self.revision, self.prefix = len(self.raw), digest(self.raw)
        self.deadline = min(time.monotonic() + 35, scope.lease_until)
        self.wall_deadline = time.time() + max(0, self.deadline - time.monotonic())
        self.spec = None
        self.capsule = None
        self.pending_revision = None
        self.request_id = None
        self.ledger = scope.directory / 'work/identity-revalidation.json'
        if scope.candidate_provider is not None:
            self.check()
            candidate=scope.candidate_provider(self)
            self.check()
            from assistant.browser_session_commit import _controlled_candidate,_valid_candidate
            candidate=Path(candidate).absolute()
            if (not _controlled_candidate(scope.directory,candidate/'.xiaohongshu-cli/cookies.json')
                    or not _valid_candidate(candidate/'.xiaohongshu-cli/cookies.json')):
                raise IdentityRecoveryError('RECOVERY_CANDIDATE_INVALID')
            scope.candidate=candidate
            scope.candidate_hash=credential_fingerprint(candidate)

    def check(self):
        if (threading.get_ident() != self.owner_thread or time.monotonic() >= self.deadline
                or self.scope.guard() is not True):
            raise IdentityRecoveryError('RECOVERY_SCOPE_CHANGED')
        if (self.scope.candidate is not None and credential_fingerprint(self.scope.candidate)!=self.scope.candidate_hash):
            raise IdentityRecoveryError('RECOVERY_CANDIDATE_CHANGED')
        raw, identity = read_activity(self.path)
        if identity != self.identity or raw[:self.revision] != self.raw:
            raise IdentityRecoveryError('RECOVERY_ACTIVITY_CHANGED')
        _receipt(raw, self.revision, self.attempt_id)
        return raw

    def check_adapter(self, adapter, platform, args, directory, job_id, spec=None):
        if (adapter is not self.scope.adapter or platform != 'xiaohongshu'
                or list(args) != ['status','--json'] or Path(directory).absolute() != self.scope.directory
                or job_id != self.attempt_id):
            raise IdentityRecoveryError('RECOVERY_SCOPE_INVALID')
        self.check()
        if spec is not None:
            self.bind_spec(spec)

    def bind_spec(self, spec):
        argv, env = spec.get('argv'), spec.get('env') or {}
        if (not isinstance(argv, list) or len(argv) != 4 or argv[1:] != ['xiaohongshu','status','--json']
                or Path(argv[0]).absolute() != Path(argv[0])
                or Path(env.get('HOME','')).absolute() != (self.scope.candidate or self.scope.directory)
                or Path(env.get('WORKSPACE_ACTIVITY_LOG','')).absolute() != self.path
                or env.get('WORKSPACE_ACTIVITY_KIND') != 'status'):
            raise IdentityRecoveryError('RECOVERY_SPEC_INVALID')
        executable = Path(argv[0])
        _plain(executable)
        manifest_path = executable.parent / 'guard-manifest.json'
        _plain(manifest_path)
        manifest_raw = manifest_path.read_bytes()
        if len(manifest_raw) > 16384:
            raise IdentityRecoveryError('RECOVERY_GUARD_INVALID')
        manifest = json.loads(manifest_raw)
        module_sha = digest(Path(__file__).read_bytes())
        exe_sha = digest(executable.read_bytes())
        if (manifest.get('identity_recovery') != SCHEMA
                or manifest.get('source_sha256') != self.scope.source_sha
                or manifest.get('exe_sha256') != exe_sha
                or manifest.get('identity_recovery_module_sha256') != module_sha
                or manifest.get('request_transport') != 'single_attempt_all'
                or manifest.get('automatic_action_replay') is not False):
            raise IdentityRecoveryError('RECOVERY_GUARD_INVALID')
        bound = {'schema':SCHEMA, 'attempt_id':self.attempt_id, 'activity':str(self.path),
            'directory':str(self.scope.directory), 'revision':self.revision, 'prefix_sha256':self.prefix,
            'file_identity':list(self.identity), 'deadline':self.wall_deadline, 'max_wire':1,
            'argv':argv, 'executable_sha256':exe_sha, 'guard_sha256':digest(manifest_raw),
            'scope_hash':self.scope.binding, 'home':str(self.scope.candidate or self.scope.directory),
            'credential_sha256':credential_fingerprint(self.scope.candidate or self.scope.directory)}
        if self.capsule is not None:
            if self.spec != bound:
                raise IdentityRecoveryError('RECOVERY_SPEC_INVALID')
            return
        from .account_safety import _manual_activity_lock
        self.ledger.parent.mkdir(parents=True, exist_ok=True)
        _plain(self.ledger.parent, directory=True)
        with _manual_activity_lock(self.path):
            self.check()
            if self.ledger.exists():
                _plain(self.ledger)
                old = json.loads(self.ledger.read_text('utf-8'))
                if old.get('state') == 'issued' and old.get('deadline',0) > time.time():
                    raise IdentityRecoveryError('RECOVERY_BUSY')
            self.spec = bound
            self.capsule = json.dumps(bound, sort_keys=True, separators=(',', ':'))
            _atomic_json(self.ledger, {'schema':SCHEMA, 'attempt_id':self.attempt_id,
                'capsule_sha256':digest(self.capsule.encode()), 'deadline':self.wall_deadline, 'state':'issued'})

    def receipt(self):
        raw = self.check()
        rows, request_id = _receipt(raw, self.revision, self.attempt_id, complete=True)
        self.request_id = request_id
        return raw, request_id

    def close(self, state='failed'):
        cleanup=getattr(self.scope,'cleanup',None)
        if cleanup is not None:
            self.scope.cleanup=None
            try:cleanup(state=='committed')
            except Exception:pass
        if self.capsule is None:
            return
        try:
            from .account_safety import _manual_activity_lock
            with _manual_activity_lock(self.path):
                _plain(self.ledger)
                row = json.loads(self.ledger.read_text('utf-8'))
                if row.get('attempt_id') == self.attempt_id:
                    row['state'] = state
                    _atomic_json(self.ledger, row)
        except (OSError, ValueError, IdentityRecoveryError):
            pass


def begin_identity_revalidation(scope):
    return IdentityAttempt(scope)


class ChildPermit:
    def __init__(self, raw, argv):
        if not isinstance(raw, str) or len(raw.encode()) > 16384:
            raise IdentityRecoveryError('RECOVERY_CAPSULE_INVALID')
        try:
            value = json.loads(raw)
            required = {'schema','attempt_id','activity','directory','revision','prefix_sha256',
                'file_identity','deadline','max_wire','argv','executable_sha256','guard_sha256','scope_hash','home','credential_sha256'}
            if (set(value) != required or value['schema'] != SCHEMA or type(value['max_wire']) is not int or value['max_wire'] != 1
                    or _ID.fullmatch(value['attempt_id']) is None or value['argv'] != list(argv)
                    or list(argv)[1:] != ['xiaohongshu','status','--json']
                    or not 0 < value['deadline'] - time.time() <= 45
                    or any(_HEX.fullmatch(value[key]) is None for key in
                        ('prefix_sha256','executable_sha256','guard_sha256','scope_hash','credential_sha256'))):
                raise ValueError
            self.value, self.raw = value, raw
            self.path, self.directory = Path(value['activity']), Path(value['directory'])
            if (not self.directory.is_absolute() or self.path != self.directory/'platform-activity.jsonl'
                    or Path(os.environ.get('HOME','')).absolute() != Path(value['home'])
                    or Path(os.environ.get('WORKSPACE_ACTIVITY_LOG','')).absolute() != self.path
                    or os.environ.get('WORKSPACE_ACTIVITY_KIND') != 'status'):
                raise ValueError
            _plain(self.directory, directory=True)
            home=Path(value['home'])
            if home!=self.directory:
                from assistant.browser_session_commit import _controlled_candidate
                if not _controlled_candidate(self.directory,home/'.xiaohongshu-cli/cookies.json'):raise ValueError
            if credential_fingerprint(home)!=value['credential_sha256']:raise ValueError
            _plain(Path(argv[0]))
            guard = Path(argv[0]).parent/'guard-manifest.json'
            _plain(guard)
            if digest(Path(argv[0]).read_bytes()) != value['executable_sha256'] or digest(guard.read_bytes()) != value['guard_sha256']:
                raise ValueError
            self.ledger = self.directory/'work/identity-revalidation.json'
            self.consumed = False
            self.checkpoint()
        except IdentityRecoveryError:
            raise
        except (ValueError, TypeError, KeyError, OSError):
            raise IdentityRecoveryError('RECOVERY_CAPSULE_INVALID') from None

    @property
    def attempt_id(self):
        return self.value['attempt_id']

    def checkpoint(self, ignore_request_id=None):
        if time.time() >= self.value['deadline']:
            raise IdentityRecoveryError('RECOVERY_EXPIRED')
        if credential_fingerprint(Path(self.value['home']))!=self.value['credential_sha256']:
            raise IdentityRecoveryError('RECOVERY_CANDIDATE_CHANGED')
        raw, identity = read_activity(self.path)
        revision = self.value['revision']
        if (type(revision) is not int or not 0 < revision <= len(raw)
                or list(identity) != self.value['file_identity']
                or digest(raw[:revision]) != self.value['prefix_sha256']):
            raise IdentityRecoveryError('RECOVERY_ACTIVITY_CHANGED')
        baseline = scan_activity(raw[:revision])
        if baseline['unfinished'] or not baseline['pending'] or any(not x[1] for x in baseline['pending']):
            raise IdentityRecoveryError('RECOVERY_NOT_ELIGIBLE')
        rows, request_id = _receipt(raw, revision, self.attempt_id)
        if rows and (len(rows) != 1 or ignore_request_id != request_id):
            raise IdentityRecoveryError('RECOVERY_RECEIPT_INVALID')
        _plain(self.ledger)
        ledger = json.loads(self.ledger.read_text('utf-8'))
        if (ledger.get('attempt_id') != self.attempt_id or ledger.get('capsule_sha256') != digest(self.raw.encode())
                or ledger.get('state') != 'issued'):
            raise IdentityRecoveryError('RECOVERY_ALREADY_USED')
        return baseline['last_finished']

    def consume(self, method, url, request_id):
        if self.consumed or method != 'GET' or str(url) != STATUS_URL:
            raise IdentityRecoveryError('RECOVERY_REQUEST_FORBIDDEN')
        from .account_safety import _manual_activity_lock
        with _manual_activity_lock(self.path):
            self.checkpoint(request_id)
            row = json.loads(self.ledger.read_text('utf-8'))
            row.update(state='consumed', request_id=request_id)
            _atomic_json(self.ledger, row)
            self.consumed = True


def load_child_permit(raw, argv):
    return ChildPermit(raw, argv) if raw else None
