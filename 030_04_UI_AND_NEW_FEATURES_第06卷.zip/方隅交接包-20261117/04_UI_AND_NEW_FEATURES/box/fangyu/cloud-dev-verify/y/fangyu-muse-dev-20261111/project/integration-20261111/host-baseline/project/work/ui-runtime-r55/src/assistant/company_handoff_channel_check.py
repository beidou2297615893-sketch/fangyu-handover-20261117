"""Read the exact original company channel without rewriting register history."""
from copy import deepcopy
import json
import re

from core import CoreError
from .company_handoff_preparation import CLOUD_ACTION, _hash, _raw
from .company_handoff_registration import CompanyHandoffRegistration
from .company_handoff_original_status import _STATES, _integer

ACTION = 'company_handoff_channel_check_get'
CLOUD_DETAIL = 'acquisition_handoff_detail'
CONTRACT = 'company_handoff_channel_check_v1'
_HANDOFF = re.compile(r'[a-f0-9]{32}\Z')
_DETAIL = frozenset(('item', 'server_recorded', 'platform_delivery_verified',
    'attribution_confirmed', 'settlement_active', 'read_only', 'mutation_committed', 'auto_retry'))


class CompanyHandoffChannelCheckError(CoreError):
    def __init__(self, code, message, status=409):
        super().__init__(message)
        self.code = 'COMPANY_HANDOFF_CHANNEL_CHECK_' + code
        self.status, self.mutation_committed = status, False


def _fail(code, message, status=409):
    raise CompanyHandoffChannelCheckError(code, message, status)


class CompanyHandoffChannelCheck:
    def __init__(self, core, tenant, owner, company, *, device_id, scope_guard,
                 lead_access, cloud_read):
        self.core, self.cloud_read = core, cloud_read
        self.registration = CompanyHandoffRegistration(core, tenant, owner, company,
            device_id=device_id, scope_guard=scope_guard, lead_access=lead_access,
            cloud_read=cloud_read, cloud_register=self._no_write)
        self.history, self.preparation = self.registration.history, self.registration.preparation

    @staticmethod
    def _no_write(*_):
        raise AssertionError('The channel check has no write transport')

    def _snapshot(self, handoff_id, user):
        before = self.registration._snapshot(handoff_id, user)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN')
            snapshot = self.registration._tx_snapshot(db, handoff_id, user)
            if snapshot['fingerprint'] != before['fingerprint']:
                _fail('LOCAL_CHANGED', '原来源或当前权限已变化，请在原交接重新核对')
            row = self.registration._row(db, snapshot)
            origin = snapshot['origin']
            event = None
            if origin:
                raw = db.execute('SELECT payload FROM contact_events WHERE event_id=? AND tenant_id=? AND cloud_owner=?',
                    (origin['source_event_id'], self.registration.tenant, self.registration.owner)).fetchone()
                if not raw or _raw(raw['payload']) != origin['source_payload_hash']:
                    _fail('SOURCE_CONFLICT', '原不可变来源已变化，未继续公司详情核对')
                event = json.loads(raw['payload'])
                if _hash(event) != origin['source_payload_hash']:
                    _fail('SOURCE_CONFLICT', '原不可变来源完整性需核对')
        self.registration._scope()
        return dict(snapshot, attempt=row, original_event=event)

    def _fence(self, before, handoff_id, user):
        after = self._snapshot(handoff_id, user)
        if (after['fingerprint'] != before['fingerprint'] or after['attempt'] != before['attempt']
                or after['original_event'] != before['original_event']):
            _fail('LOCAL_CHANGED', '读取期间本人、原准备或当前授权已变化，请保留原号重新核对')
        return after

    def _detail(self, answer, snapshot, receipt):
        if (not isinstance(answer, dict) or set(answer) != _DETAIL
                or answer['server_recorded'] is not True or answer['read_only'] is not True
                or answer['mutation_committed'] is not False or answer['auto_retry'] is not False
                or any(answer[key] is not False for key in ('platform_delivery_verified', 'attribution_confirmed', 'settlement_active'))):
            _fail('DETAIL_INVALID', '公司详情身份或纯读范围需核对，原编号继续保留')
        item, origin = answer['item'], snapshot['origin']
        lead = snapshot['original_event']['lead']
        source = dict(platform=lead['platform'], author_id=lead['author_id'], comment_id=lead['comment_id'],
            source_lead_hash=_raw(lead['id']), device_id=origin['device_id'], original_text_hash=_raw(lead['text']),
            evidence_source='device_report', platform_provenance_verified=False)
        consent = item.get('consent') if isinstance(item, dict) else None
        current = receipt['current_handoff']
        if (not isinstance(item, dict) or item.get('channel_id') != origin['expected_cloud_channel_id']
                or item.get('company_id') != self.preparation.company_id
                or item.get('source_owner') != self.registration.owner
                or item.get('source_event_id') != origin['source_event_id'] or item.get('source') != source
                or item.get('customer_id') != 'cu_'+_raw(lead['platform']+':author:'+lead['author_id'])
                or item.get('qualification') != 'qualified' or not _integer(item.get('revision'), 1)
                or item.get('status') not in _STATES or item.get('revision') != current['revision']
                or item.get('status') != current['status'] or type(item.get('current_consent_valid')) is not bool
                or item['current_consent_valid'] != current['current_consent_valid']
                or not isinstance(consent, dict)
                or set(consent) != {'status', 'evidence_reference', 'notice_version', 'evidence_source', 'independently_verified'}
                or consent['status'] not in ('granted', 'withdrawn')
                or consent['evidence_source'] != 'operator_recorded' or consent['independently_verified'] is not False
                or (consent['status'] == 'withdrawn' and item['current_consent_valid'] is not False)
                or item.get('platform_delivery_verified') is not False
                or item.get('storage_scope') != 'company_server_ledger'
                or item.get('contact_delivery') != 'platform_reference_only'
                or item.get('settlement') != {'status': 'not_configured', 'amount_cents': None, 'attribution_confirmed': False}):
            _fail('DETAIL_MISMATCH', '公司当前草稿与原客户来源不一致，请保留原号核对')
        # Consent may since have been withdrawn. Compare its immutable original
        # grant to the fixed register digest, while keeping current consent false.
        body = dict(environment_id=self.preparation.environment_id, operation=CLOUD_ACTION,
            source_event_id=origin['source_event_id'], recipient_id=item.get('recipient_id'),
            purpose=item.get('purpose'), consent=dict(status='granted',
                evidence_reference=consent['evidence_reference'], notice_version=consent['notice_version']),
            contact_reference=item.get('contact_reference'), qualification='qualified',
            idempotency_key=origin['cloud_idempotency_key'])
        if _hash(body) != origin['cloud_payload_hash']:
            _fail('DETAIL_MISMATCH', '公司接收方、用途或同意记录与原准备不一致')
        return deepcopy(current)

    def _result(self, snapshot, receipt=None, binding=None, *, detail=False):
        base = self.history._result(snapshot, receipt)
        row = snapshot['attempt']
        matched = binding is not None and binding['state'] == 'matched'
        state = ('no_origin' if snapshot['origin'] is None else 'not_attempted' if row is None
            else 'registration_unknown' if receipt['state'] == 'unknown'
            else 'matched' if detail and matched and snapshot['current']['preparation_usable']
                and receipt['current_handoff']['current_consent_valid'] else 'hold')
        base.update(contract=CONTRACT, state=state,
            company_event_payload_matched=matched, current_channel_source_matched=detail,
            registration_source_verified=bool(row and row['registration_source_verified'] and matched
                and receipt is not None and receipt['state'] == 'recorded'),
            eligible_for_company_submit=False, detail_read_requested=detail,
            no_dispatch_scope='this_channel_check_get_only')
        return base

    def execute(self, action, data, user):
        if (action != ACTION or not isinstance(data, dict) or set(data) != {'handoff_id'}
                or not isinstance(data['handoff_id'], str) or not _HANDOFF.fullmatch(data['handoff_id'])):
            _fail('INVALID_INPUT', '公司来源核对仅接受本人原交接编号', 400)
        try:
            before = self._snapshot(data['handoff_id'], user)
            receipt = binding = None
            detailed = False
            if before['attempt']:
                receipt = self.registration._status_read(before)
                self._fence(before, data['handoff_id'], user)
                if receipt['state'] == 'recorded':
                    binding = self.registration._source_read(before)
                    self._fence(before, data['handoff_id'], user)
                    answer = self.cloud_read(deepcopy(before['actor']), CLOUD_DETAIL,
                        dict(channel_id=before['origin']['expected_cloud_channel_id']))
                    self._fence(before, data['handoff_id'], user)
                    self._detail(answer, before, receipt)
                    detailed = True
            final = self._fence(before, data['handoff_id'], user)
            self.registration._scope()
            return self._result(final, receipt, binding, detail=detailed)
        except CompanyHandoffChannelCheckError:
            raise
        except Exception as error:
            if getattr(error, 'code', '').endswith('_SESSION_REQUIRED'):
                _fail('SESSION_REQUIRED', '请在设置中明确连接原公司后核对，原编号继续保留')
            _fail('READ_UNAVAILABLE', '公司原草稿来源暂不可核对，请保留原号；本次未发送', 503)
