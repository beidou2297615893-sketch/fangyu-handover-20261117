"""Portable business backups. Credentials for external platforms are never copied."""
import hashlib
import json
import re
import shutil
import sqlite3
import tempfile
import zipfile
from contextlib import closing
from datetime import datetime
from pathlib import Path
from uuid import uuid4


class BackupManager:
    def __init__(self,store): self.store=store

    @staticmethod
    def _digest(path):
        digest=hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda:source.read(1024*1024),b''): digest.update(block)
        return digest.hexdigest()

    @staticmethod
    def _records(db,entity):
        return [json.loads(row[0]) for row in db.execute('SELECT body FROM records WHERE entity=?',(entity,))]

    @staticmethod
    def _validate_database(db):
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok': raise ValueError('备份数据库损坏')
        tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'records','sessions','unique_leads'}<=tables: raise ValueError('备份数据库格式不正确')
        for entity,id,tenant,body in db.execute('SELECT entity,id,tenant_id,body FROM records'):
            record=json.loads(body)
            if record.get('id')!=id or record.get('tenant_id')!=tenant: raise ValueError('备份记录隔离字段不一致')
            if not re.fullmatch(r'[a-zA-Z0-9_-]{1,128}',tenant) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,128}',id): raise ValueError('备份企业或记录标识不安全')

    def create(self):
        directory=self.store.directory/'backups'; directory.mkdir(exist_ok=True)
        work=self.store.directory/'work'; work.mkdir(exist_ok=True)
        path=directory/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid4().hex[:8]+'.zip')
        with tempfile.TemporaryDirectory(prefix='backup-',dir=work) as temporary:
            database=Path(temporary)/'workspace.sqlite3'
            with self.store.connect() as source,closing(sqlite3.connect(database)) as target: source.backup(target)
            with closing(sqlite3.connect(database)) as db:
                self._validate_database(db)
                assets=self._records(db,'assets')
                db.execute('DELETE FROM sessions'); db.commit()
            manifest={'format':'local-lead-workspace-backup','version':1,'created_at':datetime.now().isoformat(),'database_sha256':self._digest(database),'assets':[]}
            resolved=[]
            for asset in assets:
                source=Path(asset.get('path','')).resolve()
                root=(self.store.directory/'assets'/asset['tenant_id']).resolve()
                if not source.is_relative_to(root) or not source.is_file(): raise ValueError('素材缺失或路径越界，无法生成完整备份：'+str(asset.get('name',asset['id'])))
                member='assets/'+asset['tenant_id']+'/'+asset['id']+'/'+source.name
                manifest['assets'].append({'id':asset['id'],'tenant_id':asset['tenant_id'],'member':member,'sha256':self._digest(source)})
                resolved.append((source,member))
            staged=Path(temporary)/'backup.zip'
            with zipfile.ZipFile(staged,'w',compression=zipfile.ZIP_DEFLATED) as archive:
                archive.write(database,'workspace.sqlite3')
                for source,member in resolved: archive.write(source,member)
                archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
            shutil.move(str(staged),path)
        return {'path':str(path),'asset_count':len(assets),'format':'portable_zip','warnings':[]}

    def restore(self,path):
        work=self.store.directory/'work'; work.mkdir(exist_ok=True)
        warnings=[]; restored_assets=[]
        with tempfile.TemporaryDirectory(prefix='restore-',dir=work) as temporary:
            directory=Path(temporary); database=directory/'workspace.sqlite3'
            if zipfile.is_zipfile(path):
                with zipfile.ZipFile(path) as archive:
                    names=archive.namelist()
                    if len(set(names))!=len(names) or len(names)>50002: raise ValueError('备份归档含重复或过多条目')
                    if sum(item.file_size for item in archive.infolist())>2*1024*1024*1024: raise ValueError('备份解压体积超过 2GB 限制')
                    manifest=json.loads(archive.read('manifest.json'))
                    if manifest.get('format')!='local-lead-workspace-backup' or manifest.get('version')!=1: raise ValueError('未知备份格式')
                    with archive.open('workspace.sqlite3') as source,database.open('wb') as target: shutil.copyfileobj(source,target)
                    if self._digest(database)!=manifest.get('database_sha256'): raise ValueError('备份数据库校验失败')
                    with closing(sqlite3.connect(database)) as db:
                        self._validate_database(db)
                        assets={a['id']:a for a in self._records(db,'assets')}
                    entries=manifest.get('assets',[])
                    if len(entries)!=len(assets) or {e.get('id') for e in entries}!=set(assets): raise ValueError('备份素材清单不完整')
                    restore_id=uuid4().hex
                    for entry in entries:
                        asset=assets[entry['id']]; member=entry.get('member','')
                        parts=member.split('/')
                        if entry.get('tenant_id')!=asset['tenant_id'] or len(parts)!=4 or parts[:3]!=['assets',asset['tenant_id'],asset['id']] or parts[-1] in ('','.','..') or '\\' in parts[-1] or ':' in parts[-1]: raise ValueError('备份素材路径或企业标识不一致')
                        staged=directory/(asset['id']+'.asset')
                        with archive.open(member) as source,staged.open('wb') as target: shutil.copyfileobj(source,target)
                        if self._digest(staged)!=entry.get('sha256'): raise ValueError('备份素材校验失败')
                        destination=self.store.directory/'assets'/asset['tenant_id']/('restored-'+restore_id)/asset['id']/parts[-1]
                        restored_assets.append((asset,staged,destination))
            else:
                with closing(sqlite3.connect('file:'+path.as_posix()+'?mode=ro',uri=True)) as source,closing(sqlite3.connect(database)) as target:
                    self._validate_database(source); source.backup(target)
                warnings.append('旧 SQLite 备份未包含素材；仅可恢复本机仍存在的素材，建议重新生成完整 ZIP 备份。')
            # Every restored-* directory is fresh and belongs only to this attempt.
            # A failed copy or database replacement must not leave partial assets.
            asset_home=(self.store.directory/'assets').resolve()
            restore_roots={destination.parent.parent for _,_,destination in restored_assets}
            for root in restore_roots:
                if root.exists() or root.is_symlink() or not root.resolve().is_relative_to(asset_home):
                    raise ValueError('备份恢复目标目录已存在或越界')
            try:
                with closing(sqlite3.connect(database)) as db:
                    self._validate_database(db)
                    for asset,staged,destination in restored_assets:
                        destination.parent.mkdir(parents=True,exist_ok=True)
                        shutil.copyfile(staged,destination)
                        asset['path']=str(destination.resolve())
                        db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(asset,ensure_ascii=False),'assets',asset['id']))
                    if not zipfile.is_zipfile(path):
                        for asset in self._records(db,'assets'):
                            source=Path(asset.get('path','')).resolve(); root=(self.store.directory/'assets'/asset['tenant_id']).resolve()
                            if not source.is_relative_to(root) or not source.is_file():
                                asset.update(path='',restore_warning='旧备份未携带该素材，请重新上传')
                                db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(asset,ensure_ascii=False),'assets',asset['id']))
                    for entity in ('accounts','tasks','replies','reply_queues','publications'):
                        for record in self._records(db,entity):
                            if entity=='accounts': record.update(status='login_required',checked_at=''); record.pop('conn_id',None)
                            elif entity=='tasks':
                                record.update(status='paused',last_message='备份恢复后需重新验证平台账号再恢复任务')
                                if record.get('sequence_status')=='running': record.update(sequence_status='interrupted',sequence_message='备份恢复，连续采集不会自动续跑')
                            elif entity=='replies' and record.get('status')=='sending': record.update(status='unknown',last_error='备份时正在发送，需人工核实')
                            elif entity=='reply_queues' and record.get('status')=='running': record.update(status='interrupted',message='备份恢复，队列不会自动续发')
                            elif entity=='publications' and record.get('status')=='sending': record.update(status='unknown',message='备份时正在发布，需到平台核实')
                            elif entity=='publications' and record.get('status')=='approved':
                                record.update(status='draft',message='备份已恢复，请重新核对账号与图片并审核')
                                record.pop('approval_hash',None);record.pop('approved_by',None)
                            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(record,ensure_ascii=False),entity,record['id']))
                    db.execute('DELETE FROM sessions'); db.commit()
                    with self.store.connect() as target: db.backup(target)
            except Exception:
                for root in restore_roots:
                    if root.exists() or root.is_symlink():
                        if not root.resolve().is_relative_to(asset_home):
                            raise ValueError('备份恢复残留目录越界，需人工清理')
                        shutil.rmtree(root)
                raise
        return {'restored':True,'asset_count':len(restored_assets),'warnings':warnings,'requires_platform_login':True}
