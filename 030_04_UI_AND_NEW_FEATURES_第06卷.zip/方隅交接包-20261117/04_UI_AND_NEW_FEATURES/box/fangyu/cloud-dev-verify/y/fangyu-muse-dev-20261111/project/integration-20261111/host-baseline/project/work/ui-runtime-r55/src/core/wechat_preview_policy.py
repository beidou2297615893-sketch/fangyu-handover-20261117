"""Fixed source-only HTTP preview. External service and identity remain unverified."""
import hashlib
import json
from pathlib import Path
from .runtime_license_policy import _plain, _file_hash

_SOURCE=Path(__file__).resolve().parents[1]
_PURPOSE='wechat_channels_single_session_preview'
_REVIEW_SHA='3E6BF2070F3B85974BD04D20BC113290F07AEB721DCAAC65E21D055B7CDF7A29'
_LIMITS={'platform_reads':['status','search','comments'], 'external_tool_started':False,
    'external_tool_loaded_bytes_verified':False,'account_identity_verified':False,
    'account_isolation':False,'archive_allowed':False,'send_allowed':False,
    'page_limit':20,'commercial_binary_approved':False}

class WechatPreviewPolicy:
    def __init__(self,server):
        self._server=server
        self._source_sha=_file_hash(_plain(Path(__file__),_SOURCE)).upper()

    def current_review(self):
        server=self._server
        from wechat_channels_connection import WechatChannelsConnection
        if (not server.employee_workspace_mode or server.closing
                or getattr(server,'manual_owned_read_start',False)
                or Path(server.core.resources_dir)!=_SOURCE/'resources'
                or type(server.wechat_channels) is not WechatChannelsConnection
                or server.wechat_channels.server is not server
                or server._runtime_license_usage_scope('internal_self_use_read')!='internal_self_use_read'
                or _file_hash(_plain(Path(__file__),_SOURCE)).upper()!=self._source_sha):
            raise ValueError('preview_materials_pending')
        review=_plain(_SOURCE/'resources/wechat-preview/review.json',_SOURCE)
        if _file_hash(review).upper()!=_REVIEW_SHA:raise ValueError('preview_materials_pending')
        manifest=server.core.adapters.manifest('wechat_channels')
        if (manifest.get('transport')!='wx_channel_http' or manifest.get('mapper')!='wx_channel_v1'
                or set(manifest.get('capabilities') or [])!={'search','comments'}
                or manifest.get('env') not in (None,{}) or manifest.get('executable') not in (None,'')
                or manifest.get('auto_start') is not False):
            raise ValueError('preview_materials_pending')
        return review

    def resolve(self):
        try:
            review=self.current_review();raw=review.read_bytes();value=json.loads(raw)
            if (set(value)!={'schema','purpose','scope','company_id','limits','materials','evidence'}
                    or value['schema']!=1 or value['purpose']!=_PURPOSE
                    or value['scope']!='internal_self_use_read'
                    or value['company_id']!=self._server.company.get('id')
                    or value['limits']!=_LIMITS or type(value['materials']) is not list
                    or not value['materials']):return None
            seen=set()
            for item in value['materials']:
                if (type(item) is not dict or set(item)!={'path','sha256','bytes','role'}
                        or type(item['path']) is not str or ':' in item['path'] or '\\' in item['path']
                        or any(x in ('','.','..') for x in item['path'].split('/'))
                        or item['path'] in seen or item['path']=='core/wechat_preview_policy.py'):
                    return None
                path=_plain(_SOURCE/item['path'],_SOURCE);before=path.stat()
                if before.st_size!=item['bytes'] or _file_hash(path).upper()!=item['sha256']:return None
                after=path.stat()
                if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):return None
                seen.add(item['path'])
            if self.current_review()!=review or review.read_bytes()!=raw:return None
            revision=hashlib.sha256(raw+self._source_sha.encode()).hexdigest()
            return {'purpose':_PURPOSE,'revision':revision}
        except (OSError,ValueError,TypeError,KeyError):return None

    def describe(self):
        selected=self.resolve()
        return {'purpose':_PURPOSE,'status':'available' if selected else 'blocked',
            'reason':'single_page_identity_unverified' if selected else 'component_review_pending',
            'identity_verified':False,'account_isolation':False,'account_ready':False,
            'platform_read_only':True,'archive_available':False,'external_tool_started':False}
