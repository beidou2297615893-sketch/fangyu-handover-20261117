"""Frozen, account-isolated CLI dispatcher. No automatic browser-cookie extraction."""
import os
import sys
import json
import math
import re
import secrets
import time
from pathlib import Path
from urllib.parse import urlparse

_IDENTITY_PERMIT = None
_PAGE_WIRE_GATE = None


def configure_identity_recovery(argv, stream):
    """Only private stdin on the exact status dispatcher can carry a capability."""
    global _IDENTITY_PERMIT
    _IDENTITY_PERMIT = None
    if list(argv)[1:] != ['xiaohongshu','status','--json'] or stream is None:
        return
    raw = stream.read(16385)
    if raw:
        from core.xhs_identity_recovery import load_child_permit
        _IDENTITY_PERMIT = load_child_permit(raw, argv)

def display_qr(data):
    import qrcode
    import struct
    import zlib
    import json
    target=os.environ.get('WORKSPACE_QR_PATH')
    if not target: return False
    path=Path(target)
    try:
        path.parent.mkdir(parents=True,exist_ok=True)
        qr=qrcode.QRCode(border=4,error_correction=qrcode.constants.ERROR_CORRECT_M)
        qr.add_data(data);qr.make(fit=True)
        matrix=qr.get_matrix();scale=8;size=len(matrix)*scale
        # Encode a simple grayscale PNG directly: no Pillow format plug-in discovery
        # in the frozen executable, and no partial file while the UI is polling.
        pixels=b''.join((b'\x00'+b''.join((b'\x00' if cell else b'\xff')*scale for cell in row))*scale for row in matrix)
        def chunk(kind,payload):
            return struct.pack('!I',len(payload))+kind+payload+struct.pack('!I',zlib.crc32(kind+payload)&0xffffffff)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',size,size,8,0,0,0,0))+chunk(b'IDAT',zlib.compress(pixels))+chunk(b'IEND',b'')
        temporary=path.with_suffix('.tmp')
        temporary.write_bytes(png);temporary.replace(path)
    except Exception as ex:
        try:path.with_suffix('.error.json').write_text(json.dumps({'code':'qr_write_failed','type':type(ex).__name__}),encoding='utf-8')
        except OSError:pass
        raise RuntimeError('二维码生成或保存失败') from None
    print('二维码已显示在工作台，请使用平台手机 App 扫码。',flush=True)
    return True

def http_only_login(login):
    def wrapped(*args, **kwargs):
        kwargs['prefer_browser_assisted'] = False
        return login(*args, **kwargs)
    return wrapped


def _safe_platform_code(value):
    """Accept only bounded numeric codes, never arbitrary platform response text."""
    if type(value) is str and len(value)<=11 and re.fullmatch(r'-?(?:0|[1-9][0-9]{0,9})',value):
        value=int(value)
    return value if type(value) is int and -(2**31)<=value<2**31 else None


def _response_platform_code(payload):
    if type(payload) is not dict:return None
    for key in ('code','errorcode','error_code'):
        value=_safe_platform_code(payload.get(key))
        if value is not None:return value
    return None


def record_request_event(stage, request_id, method, status=None, elapsed_ms=None,
                         http_status=None, platform_code=None, prewarm_unavailable=False):
    """Persist timing/status and bounded error codes; never response text or credentials."""
    destination=os.environ.get('WORKSPACE_ACTIVITY_LOG')
    if not destination:raise RuntimeError('缺少账号活动记录路径，平台请求已停止')
    kind=os.environ.get('WORKSPACE_ACTIVITY_KIND','other')
    if kind not in {'login','status','whoami','search','read','comments','sub-comments','user-posts','notifications','reply'}:
        kind='other'
    event={'at':time.time(),'request_id':request_id,'stage':stage,
           'kind':kind,'method':str(method).upper() if str(method).upper() in {'GET','POST'} else 'OTHER'}
    if _IDENTITY_PERMIT is not None:
        event['attempt_id']=_IDENTITY_PERMIT.attempt_id
    if stage=='finished':
        event['status']=(status if (isinstance(status,int) and 100<=status<=599)
                         or (isinstance(status,str) and status in {'api_error','protocol_error','cancelled_before_send'})
                         else 'transport_error')
        event['elapsed_ms']=max(0,int(elapsed_ms or 0))
        # Diagnostics cannot alter the existing status/review classification.
        if (event['status']!='cancelled_before_send'
                and not (type(event['status']) is int and 200<=event['status']<300)
                and type(http_status) is int and 100<=http_status<=599):
            event['http_status']=http_status
            code=_safe_platform_code(platform_code)
            if code is not None:event['platform_code']=code
        elif (prewarm_unavailable is True and kind=='search' and event['method']=='POST'
              and type(event['status']) is int and 200<=event['status']<300
              and _safe_platform_code(platform_code)==0):
            # Fixed metadata only. The optional onebox response body is never logged.
            event['prewarm_unavailable']=True
            event['platform_code']=0
    payload=(json.dumps(event,separators=(',',':'))+'\n').encode('utf-8')
    handle=os.open(destination,os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        if os.write(handle,payload)!=len(payload):raise OSError('Activity record was incomplete')
        os.fsync(handle)
    finally:os.close(handle)

def activity_checkpoint(ignore_request_id=None):
    """Carry forward timing only; historical activity never requires manual review."""
    if _IDENTITY_PERMIT is not None:
        return False,_IDENTITY_PERMIT.checkpoint(ignore_request_id)
    destination=os.environ.get('WORKSPACE_ACTIVITY_LOG')
    if not destination or not Path(destination).is_file():return False,0.0
    try:
        from core.xhs_identity_recovery import read_activity,scan_activity
        raw,_=read_activity(destination);state=scan_activity(raw)
        return False,state['last_finished']
    except Exception:return False,0.0

def activity_requires_review():
    return activity_checkpoint()[0]

def single_attempt_transport(original):
    """Record every request and never replay after a risk or ambiguous response."""
    risk_seen=False
    def request(client, method, url, **kwargs):
        nonlocal risk_seen
        if not os.environ.get('WORKSPACE_ACTIVITY_LOG'):
            raise RuntimeError('缺少账号活动记录路径，平台请求已停止')
        review_required,last_finished_at=activity_checkpoint()
        if risk_seen or review_required:
            raise RuntimeError('平台未接受本次请求，已结束本次操作；可重新登录后再试')
        # The vendor's delay clock starts at zero for every new CLI process.
        # Carry forward this account's last completed request before it runs.
        local_last=getattr(client,'_last_request_time',0)
        if isinstance(local_last,(int,float)) and last_finished_at:
            client._last_request_time=max(local_last,min(last_finished_at,time.time()))
        client._rate_limit_delay()
        # Stop this invocation after an actual rejected or ambiguous request.
        if risk_seen or activity_requires_review():
            raise RuntimeError('平台未接受本次请求，已结束本次操作；可重新登录后再试')
        request_id=secrets.token_hex(8)
        record_request_event('started',request_id,method)
        started=time.monotonic()
        # A redirect is another wire request, even when the caller made one call.
        # Keep every network attempt visible in the account activity log.
        kwargs['follow_redirects']=False
        # Preserve the optional typed permit and this invocation's stop state.
        try:
            if risk_seen or activity_checkpoint(ignore_request_id=request_id)[0]:
                raise RuntimeError('平台未接受本次请求，已结束本次操作；可重新登录后再试')
            if _PAGE_WIRE_GATE is not None:
                _PAGE_WIRE_GATE(str(method).upper(),url)
            if _IDENTITY_PERMIT is not None:
                _IDENTITY_PERMIT.consume(str(method).upper(),url,request_id)
        except Exception:
            # No HTTP function was entered. Pair the local start even when a
            # private checkpoint/consume raises; preserve all other risk rows.
            risk_seen=True
            record_request_event('finished',request_id,method,status='cancelled_before_send',
                                 elapsed_ms=(time.monotonic()-started)*1000)
            raise
        try:response=client._http.request(method,url,**kwargs)
        except Exception:
            risk_seen=True
            record_request_event('finished',request_id,method,elapsed_ms=(time.monotonic()-started)*1000)
            raise
        redirected=300<=response.status_code<400
        semantic_error=None;platform_code=None;prewarm_unavailable=False
        parsed_url=urlparse(str(url))
        api_response=parsed_url.path.startswith('/api/')
        onebox_prewarm=(str(method).upper()=='POST'
                        and parsed_url.scheme=='https'
                        and parsed_url.netloc=='edith.xiaohongshu.com'
                        and parsed_url.path=='/api/sns/web/v1/search/onebox'
                        and not parsed_url.query)
        if 200<=response.status_code<300 and api_response:
            try:payload=response.json()
            except (ValueError,TypeError):semantic_error='protocol_error'
            else:
                if not isinstance(payload,dict):semantic_error='protocol_error'
                elif onebox_prewarm and 'success' in payload and type(payload['success']) is not bool:
                    semantic_error='protocol_error'
                elif not payload.get('success'):
                    platform_code=_response_platform_code(payload)
                    # The pinned 0.6.4 search treats onebox as optional. The
                    # observed HTTP-2xx/code-0 response has no success data;
                    # let its existing XhsApiError handler continue to notes.
                    if (onebox_prewarm and type(payload.get('code')) is int
                            and payload['code']==0
                            and ('success' not in payload or payload['success'] is False)):
                        prewarm_unavailable=True
                    else:semantic_error='api_error'
        elif response.status_code>=400 and api_response:
            # Inspect an already-received error only for a numeric code; no extra request.
            try:platform_code=_response_platform_code(response.json())
            except (ValueError,TypeError):pass
        if response.status_code in (401,403,429,461,471) or redirected or semantic_error:risk_seen=True
        if not redirected:client._merge_response_cookies(response)
        client._mark_request()
        record_request_event('finished',request_id,method,status=semantic_error or response.status_code,
                             elapsed_ms=(time.monotonic()-started)*1000,
                             http_status=response.status_code,platform_code=platform_code,
                             prewarm_unavailable=prewarm_unavailable)
        if redirected:raise RuntimeError('平台返回非预期跳转，账号已暂停；请人工核实登录与任务结果')
        return response
    return request

def single_attempt_action(get_client):
    def run(ctx, action):
        # A session error may occur after upload/publish; never restart the action.
        with get_client(ctx) as client:
            return action(client)
    return run

def install_xhs_write_guards():
    from xhs_cli.client import XhsClient
    from xhs_cli.commands import _common
    XhsClient._request_with_retry=single_attempt_transport(XhsClient._request_with_retry)
    _common.run_client_action=single_attempt_action(_common.get_client)


def install_xhs_profile_avatar_compat():
    """Preserve a real profile image omitted by the pinned CLI's status normalizer."""
    from xhs_cli import command_normalizers
    from xhs_cli.commands import auth

    original=command_normalizers.normalize_xhs_user_payload
    if getattr(original,'_workspace_avatar_compat',False):
        return

    def normalize(info):
        user=original(info)
        if not isinstance(info,dict) or not isinstance(user,dict):
            return user
        basic=info.get('basic_info') if isinstance(info.get('basic_info'),dict) else {}
        avatar=(basic.get('avatar') or basic.get('image') or basic.get('avatar_url')
                or info.get('avatar') or info.get('image') or info.get('avatar_url'))
        if avatar and not user.get('avatar'):
            user['avatar']=avatar
        return user

    normalize._workspace_avatar_compat=True
    command_normalizers.normalize_xhs_user_payload=normalize
    auth.normalize_xhs_user_payload=normalize

def install_xhs_sub_comments_compat():
    """Adapt upstream PR #81 to pinned 0.6.4 without changing its transport.

    Source: jackwener/xiaohongshu-cli PR #81 (4ddad8a). Request parameters
    mirror that patch; the all-request stop/no-replay guard remains in force.
    """
    import click
    from xhs_cli.client_mixins import ReadingEndpointsMixin
    from xhs_cli.commands import reading
    from xhs_cli.cli import cli
    if getattr(ReadingEndpointsMixin.get_sub_comments,'_workspace_pr81',False):
        return

    def get_sub_comments(self,note_id,root_comment_id,num=30,cursor='',xsec_token=''):
        return self._main_api_get('/api/sns/web/v2/comment/sub/page',{
            'note_id':note_id,'root_comment_id':root_comment_id,'num':num,
            'cursor':cursor,'image_formats':'jpg,webp,avif',
            'top_comment_id':'','xsec_token':xsec_token})
    get_sub_comments._workspace_pr81=True
    ReadingEndpointsMixin.get_sub_comments=get_sub_comments

    @click.command('sub-comments')
    @click.argument('note_id')
    @click.argument('comment_id')
    @click.option('--cursor',default='',help='Pagination cursor')
    @click.option('--xsec-token',default='',help='Access token from the source note URL')
    @reading.structured_output_options
    @click.pass_context
    def sub_comments(ctx,note_id,comment_id,cursor,xsec_token,as_json,as_yaml):
        return reading.handle_command(ctx,
            action=lambda client:client.get_sub_comments(note_id,comment_id,
                                                        cursor=cursor,xsec_token=xsec_token),
            render=reading.render_comments,as_json=as_json,as_yaml=as_yaml)
    reading.sub_comments=sub_comments
    cli.commands['sub-comments']=sub_comments


def main():
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'): stream.reconfigure(encoding='utf-8',errors='replace')
    if not getattr(sys,'frozen',False):
        # -I excludes the script directory. Import only this fixed app source.
        source_root=str(Path(__file__).resolve().parent)
        if source_root not in sys.path:sys.path.insert(0,source_root)
    if len(sys.argv)<2 or sys.argv[1] not in {'xiaohongshu','--owned-xhs-cli-pages'}:
        raise SystemExit('Customer read component requires the fixed read purpose')
    from assistant.owned_helper_dispatch import dispatch_owned_helper
    # Customer CLI has no public helper or platform-writing route. The fixed
    # page worker still consumes the original private task/UID/lease protocol.
    if len(sys.argv)>1 and sys.argv[1].startswith('--owned-') and sys.argv[1]!='--owned-xhs-cli-pages':
        raise SystemExit('Customer read component does not permit this helper purpose')
    helper_exit=dispatch_owned_helper(sys.argv[1:])
    if helper_exit is not None:return helper_exit
    if len(sys.argv)>1 and sys.argv[1]=='--qr-self-test':
        display_qr('https://example.invalid/local-qr-test');return
    if len(sys.argv)>2 and sys.argv[2] not in {'status','whoami','search','read','comments','sub-comments','--help','--version'}:
        raise SystemExit('Customer read component permits only status/whoami/search/read/comments/sub-comments')
    if len(sys.argv)<2: raise SystemExit('Required platform: xiaohongshu')
    # A normal desktop child has no stdin pipe. Never wait on an interactive console.
    stream=getattr(sys,'stdin',None)
    if stream is not None:
        try:
            if os.name=='nt':
                import ctypes,msvcrt
                api=ctypes.windll.kernel32.GetFileType
                api.argtypes=[ctypes.c_void_p];api.restype=ctypes.c_uint32
                piped=api(msvcrt.get_osfhandle(stream.fileno()))==3
            else:
                import stat
                piped=stat.S_ISFIFO(os.fstat(stream.fileno()).st_mode)
        except (OSError,ValueError):piped=False
        if piped:configure_identity_recovery(sys.argv,stream)
    platform=sys.argv.pop(1)
    if platform!='xiaohongshu': raise SystemExit('Unsupported platform')
    install_xhs_write_guards()
    install_xhs_profile_avatar_compat()
    install_xhs_sub_comments_compat()
    import xhs_cli.cookies
    xhs_cli.cookies.extract_browser_cookies=lambda *a,**k:None
    import xhs_cli.qr_login
    xhs_cli.qr_login._display_qr_in_terminal=display_qr
    xhs_cli.qr_login.qrcode_login=http_only_login(xhs_cli.qr_login.qrcode_login)
    from xhs_cli.cli import cli
    # The upstream package exposes publishing, deletion and social actions.
    # This customer build only dispatches the commands used by its first-release flow.
    allowed={'status','whoami','search','read','comments','sub-comments'}
    cli.commands={name:command for name,command in cli.commands.items() if name in allowed}
    if len(sys.argv)>1 and sys.argv[1]=='login' and '--help' not in sys.argv and '--qrcode' not in sys.argv:
        raise SystemExit('This customer build requires QR login')
    cli()

if __name__=='__main__': sys.exit(main())
