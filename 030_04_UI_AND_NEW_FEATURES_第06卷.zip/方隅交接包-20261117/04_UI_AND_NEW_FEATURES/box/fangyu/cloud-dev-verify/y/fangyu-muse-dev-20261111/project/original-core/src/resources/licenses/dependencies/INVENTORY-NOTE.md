# Installed distribution license inventory

Only LICENSE/LICENCE/NOTICE/COPYING/COPYRIGHT files listed by each installed distribution's file metadata were copied. CPython and Node licenses are the actual installed runtime license files. No accounts, configuration, logs, or full site-packages directory were copied.

DEPENDENCIES.json records exact versions, declared metadata, copied files, and missing-license-file status. Current missing installed-distribution license files: camoufox, kabi-weibo-cli, runs, ua-parser-builtins, WMI, xiaohongshu-cli. Existing upstream metadata declarations for xiaohongshu-cli/weibo-cli remain separately retained; a declaration is not misrepresented as a bundled upstream LICENSE file. This inventory is not a completed legal review of all dependencies.

Pillow 12.3.0, qrcode 8.2, PyInstaller 6.22.3, Python 3.11.15 and Node.js 22.23.2 actual license texts are included. Exact Python distribution lock is work/build/cli-requirements.lock.txt.
