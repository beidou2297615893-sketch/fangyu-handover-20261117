"""Serialize explicit model adjudications; no text classifier or platform calls.
All 200 source comments and grouped bodies were read before initial decisions.
Unchanged original fields are retained after individual semantic comparison.
"""
from pathlib import Path
import json, copy, hashlib, collections

BASE=Path(__file__).resolve().parent
read=lambda name:[json.loads(s) for s in (BASE/name).read_text(encoding='utf-8').splitlines()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=['reviewed.jsonl','decisions.tsv','input.jsonl','grouped-model-input.json']
before={n:sha(BASE/n) for n in protected}
grouped=json.loads((BASE/'grouped-model-input.json').read_text(encoding='utf-8'))
source={c['key']:(c,g) for g in grouped['shared_post_context'] for c in g['comments']}
inputs={x['review_key']:x for x in read('input.jsonl')}
original=read('reviewed.jsonl')
rows={r['review_key']:copy.deepcopy(r) for r in original}
reasons=collections.defaultdict(list)

def change(n,why,**fields):
    k=f'D{n:04d}'
    rows[k].update(fields)
    reasons[k].append(why)

def topic(pool,quote,polarity='ask',subject='own_demand',scope=None):
    return dict(pool=pool,quote=quote,polarity=polarity,subject=subject,condition_scope=scope)

def tm(n,quote,role='other',normalized=None,verification='原文时间保留，具体时点不明'):
    return dict(quote=quote,time_role=role,anchor_source='comment_published_at',anchor_time=source[f'D{n:04d}'][0]['published_at'],normalized=normalized,verification=verification)

def reg(text,relation='desired',group='unknown',scope=None):
    return dict(text=text,quote=text,relation=relation,group_relation=group,condition_scope=scope)

# Explicit per-comment judgments for short metric questions. A housing inquiry
# can be retained while its requested metric remains unresolved.
for n in (16,23,74,78,83):
    change(n,'具体可租房源正文中的指标询问应保留租房线索；指标歧义不等于供需身份全无证据。',
           role='demand',demand_state='active_at_comment',interest='medium',context_used=['own','body'],
           reason='针对正文可租房源询问指标，保留询租线索；价格、面积等具体指标未明，未计入确定需求池',
           needs_review=['需明确所问是租金、面积或其他指标；不能填入确定价格或面积条件'])

change(26,'同一供给位置主题重复两次；保留两处位置证据，但合成一个供给位置主题。',
       topics=[topic('位置通勤','川沙租吗，我们自己的房子，华夏东路地铁8分钟，交通方便','fact','supply')])

change(50,'泛问能否看房尚无约看时间、确定安排或订房动作，不能据此直接超高。',interest='high',
       reason='在明确出租公寓正文下询问位置和能否看房，属评论时高兴趣；尚未落实约看安排',
       topics=[topic('位置通勤','在哪里'),topic('看房联系','能看房吗？')],
       needs_review=['看房是否实际安排、具体时间尚未确定'])

for n in (52,53,57):
    change(n,'具体居住公寓广告下问所售房源位置，可据上下文保留当时高兴趣，不因没有重复说我想租机械降级。',
           interest='high',reason='正文明确出租居住公寓，本人追问该房源位置，属评论时高兴趣；未确认今日仍找房',needs_review=[])
change(58,'有真实性疑问但仍在明确可租房源下追问位置；保留价格真实性疑问，不虚构已核验。',
       interest='high',reason='追问正文可租公寓位置，同时质疑房源真实性，保留评论时高兴趣',
       needs_review=['所询房源、报价及位置真实性尚未核实'],context_flags=['本人质疑真实性，回复不得承诺原帖价格或房态已核实'])
change(60,'居住公寓语境已明确，无证据要求所有此类询租者再核住宅用途；仅保留实际定位缺口。',
       needs_review=['需核实培黎职业学院的具体地点及可接受通勤范围；不凭学校名猜校区'])

change(65,'拆分短租本人条件与工作地点事实；工作地不改成本人必须租住地区。',
       topics=[topic('入住与租期','短租一个月','require',scope='短租一个月'),topic('位置通勤','我这边工作在中关村','fact')],
       needs_review=['已知工作在中关村，实际可接受居住区域及通勤范围未明'])
change(69,'真实可租房源下主动问联系方法属于推进询租，但无确定约看，不应升超高。',
       interest='high',reason='在具体可租房源下询问联系方法，属评论时高兴趣，尚无确定约看',
       needs_review=['所需房型、预算及是否安排看房尚未明确'])
change(72,'整租、约千元预算和接受较小面积应分开，不能把整段作为接受或把约数当硬上限。',
       topics=[topic('房源状态','还有没有整租的呀？'),topic('户型面积与居住方式','整租','require'),
               topic('价格预算','1000左右','prefer',scope='1000左右的小一点也可以。'),
               topic('户型面积与居住方式','小一点也可以','accept',scope='1000左右的小一点也可以。')])
change(73,'真实房源下询问公寓名称保留询租可能，不直接视作无关联；名称问题不能确定本人租期和预算。',
       topics=[topic('位置通勤','这是什么公寓？','unknown','unresolved')],
       reason='在具体可租公寓正文下询问公寓名称，可能为选房核实，也可能只是了解；保留待核',
       needs_review=['本人是否找房及询问名称的目的未明'])

change(87,'本人询问指定区域是否有房，虽原帖也是求租但不能因此抹去问房动作；未指向确定在租房源。',
       role='demand',demand_state='active_at_comment',interest='medium',
       topics=[topic('位置通勤','锦江区有没有'),topic('房源状态','锦江区有没有')],
       target_regions=[reg('锦江区')],reason='在租房讨论中本人追问锦江区有没有房，保留地区询租；没有具体可租房源承接',
       needs_review=['原帖不是房源供给，实际房型预算及是否仍找房未明'])
change(88,'本人指定区域问房与替别人提供房源语气不同，保留中兴趣，不因求租帖上下文漏掉。',
       role='demand',demand_state='active_at_comment',interest='medium',
       topics=[topic('位置通勤','武侯区有没有'),topic('房源状态','武侯区有没有')],
       target_regions=[reg('武侯区')],reason='本人追问武侯区有没有房，属于地区询租线索；没有具体可租房源承接',
       needs_review=['原帖不是房源供给，实际房型预算及是否仍找房未明'])
change(89,'找合租室友不等于已持有可供房间，也未说明性别和现房状态。',
       needs_review=['需区分共同找房还是已有合租空位；不能认定本人已有房可供'])
change(90,'有房嘛是问房动作；原帖并非供给造成承接对象不明，但不应整体隐藏需求。',
       role='demand',demand_state='active_at_comment',interest='medium',
       topics=[topic('房源状态','有房嘛')],reason='本人询问有没有房，保留评论时询租；原帖为求租，尚无具体在租房源',
       needs_review=['实际想找的房源地区、条件和被询问对象未明'])
change(100,'成都既是本人刚来地点，也是哪里租房的上下文；仍不推导具体城区或通勤条件。',
       target_regions=[reg('成都','desired',scope='我也是刚来成都，哪里租房')])

# Landlord/employment histories are not historical housing-search actions.
for n in (109,114,115,116,122):
    change(n,'原文是出租方或从业经历，历史事件不能直接标成本人过去找房动作。',demand_state='unknown')
change(114,'保留去年这个历史合同语境，但不拿它当入住时间。',
       time_mentions=[tm(114,'去年','other','2025','相对年份按2026年评论时点推定，仅指收到电话的年份，不是找房或入住时间')])
change(115,'20年及每月为房东出租合同和收益语境，不能成为本人租房预算或租期。',
       time_mentions=[tm(115,'20年'),tm(115,'每月','other',None,'按月收益/抵扣语境，不代表租赁期限')],
       context_flags=['房东出租合同及每月收益均非本人求租条件'])
change(117,'联系限制针对托管平台在涨价/解约以外事项，不能扩成对所有人的永久拒联。',
       contact_boundaries=[dict(quote='其他事情不要联系我',scope='本人对其托管平台的答复：要么涨租金，要么直接违约；其他事情不要联系。不能外推为对所有账号一概拒联，也不产生本项目联系授权。')])
change(119,'当前持续租住9年不等于还在找房；将价格最贵留为对现房评价，而非新预算。',
       time_mentions=[tm(119,'目前9年','other',None,'现住房已租住时长，不是拟租期限')],
       context_flags=['明确因懒得换而继续租原房，无新找房需求'])

change(136,'公租房实时选房与普通商业可租房源询问应分开；保留本人住房推进，但不承诺可提供该公租房。',
       interest='medium',reason='本人在公租房渠道实时选房但无房可选，有住房推进线索；不等同接受普通商业公寓',
       topics=[topic('房源状态','实时选房，怎么一直没房怎么办',scope='实时选房')],
       context_flags=['公租房申请/选房语境，不能假称可安排该渠道房源'],
       needs_review=['是否仍在等待公租房、是否另有过渡房或商业租赁需求未明'])
change(137,'抢房开放时间不是入住时间或租期，不能强塞入住池。',topics=[],
       other_constraints=[dict(quote='每个月几号几点抢啊',subject='unresolved',detail='询问公租房选房/抢房开放时间；不是入住时间或租期')])
change(138,'本人已申请通过但正在等摇号，资格证咨询不等于问商业房态；保留住房线索而不直接等同商业高意向。',
       interest='medium',topics=[],reason='本人公租房申请已通过，等通知摇号选房，询问安居资格证；保留住房线索',
       other_constraints=[dict(quote='安居资格证是什么啊',subject='own_demand',detail='公租房申请资格/手续问题，不是已确认商业租赁需求')],
       context_flags=['公租房申请通过并等待选房，不能承诺资格结论或可安排房源'],
       needs_review=['资格证具体问题及是否另需过渡房或商业租赁未明'])
change(140,'我的到这一步表明本人正在申请链路，步骤不清不应抹掉本人主体。',
       role='demand',demand_state='active_at_comment',interest='medium',
       reason='本人表示公租房申请已到某一步，但没有提供可识别步骤；保留住房申请线索',
       needs_review=['具体申请步骤、是否已选房及有无额外找房需求未明'],
       other_constraints=[dict(quote='我的到这一步了',subject='own_demand',detail='本人申请进度指向未展示步骤，不能猜已通过或已获房')])
change(141,'开始时间为流程开放时点，不是入住/租期池。',topics=[],
       other_constraints=[dict(quote='几点开始？',subject='unresolved',detail='公租房流程开放时间，申请主体及具体步骤未明')])
change(150,'本人请求房子租及介绍，已比单纯问经历多一步，应保留当时高兴趣，但不是确定约看。',
       interest='high',reason='询问哪里有房可租并请求介绍，保留评论时主动找房需求，未落实约看',
       needs_review=['具体区域、预算及介绍对象未明'])
change(152,'问他人过去租房地点，不可把福州登记为本人已确认目标。',
       topics=[topic('位置通勤','在福州哪里租的？','ask','other_person')])
change(155,'本人两房半原词不能擅自标准化为两室；2000内是上限，区域与房型需联立。',
       topics=[topic('位置通勤','晋安区','require',scope='晋安区有两房半的，2000内的吗'),
               topic('户型面积与居住方式','两房半','require',scope='晋安区有两房半的，2000内的吗'),
               topic('价格预算','2000内','require',scope='晋安区有两房半的，2000内的吗'),
               topic('房源状态','有两房半的，2000内的吗')],needs_review=['两房半的具体房型含义未明，不能直接改成标准两居'])
change(156,'你们住哪里明确问对方现居位置，而非已知本人租住目标。',
       topics=[topic('位置通勤','你们住哪里','ask','other_person')])
change(158,'1109可能价格也可能门牌/其他数字，不能把数字未经说明视为确定租金。',
       topics=[topic('位置通勤','高新区','unknown','unresolved'),topic('户型面积与居住方式','两房','unknown','unresolved')],
       possible_topics=[dict(pool='价格预算',ambiguity='1109可能租金，也可能门牌或其他数字；原文未给单位或询问方向')],
       reason='高新区两房1109可能提供房源、讲现居经验或提出条件，数字含义不明，保留待核',
       needs_review=['本人是求租、供给还是分享现居未明；1109的指标及单位未明'])

change(173,'办理闵行区保障房涉及申请地点，并未明确想租闵行区；不是住宅用途缺口。',
       topics=[topic('位置通勤','闵行区可以办理来吗？','unknown','unresolved')],
       needs_review=['闵行区是办理地还是目标房源地、是否本人申请及是否另需商业住房未明'])
change(175,'抢不到便宜房源可能本人受阻，保留未知需求，亦不硬判已明确预算。',
       topics=[topic('房源状态','便宜的房源抢不到','unknown','unresolved'),topic('价格预算','价格区间太大','compare','unresolved')])
change(176,'与现租房价格作比较不等于本人另租；记录比较主体以免变成新预算。',
       topics=[topic('价格预算','比我租的房子贵！','compare','current_home')])
change(180,'这是本人公租房申请等待事实，不是问商业房源是否有房；期限不能变租期。',
       topics=[],other_constraints=[dict(quote='申请了两年一点动静没有',subject='own_demand',detail='本人住房申请无进展，非已确认商业房源需求')],
       reason='本人曾申请保障房且到评论时仍无进展；保留住房需求线索，是否仍有效和另租意愿未明',
       context_flags=['公租/保租申请等待，不等于接受商业租赁'])
change(181,'本人申请无消息为等待事实，不能改成商业房态询问。',
       topics=[],other_constraints=[dict(quote='申请好久了一点消息都没有',subject='own_demand',detail='本人住房申请等待事实，非已确认商业房源需求')],
       reason='本人住房申请等待无消息，保留住房线索；没有明确新的商业找房动作',
       context_flags=['公租/保租申请等待，不等于接受商业租赁'])
change(182,'空文本且同帖作者，不能当新增可联系求租者，也不能凭身份认定无需求。',
       context_flags=['评论文本为空，原始记录显示与帖文同作者'],needs_review=['空评论无法判语义；同作者信息不提供本人新增找房证据'])
change(183,'停车位是现住民房的已有配置，不是本人新房必须有车位。',
       other_constraints=[dict(quote='有自己停车位',subject='current_home',detail='现住房已有停车位，未提出新找房或新房车位要求')],
       context_flags=['现居满意体验，不转为预算1000或必须有菜地/停车位的新需求'])

# Individually reviewed service-apartment inquiries. The body expressly offers
# residential room types and flexible rental terms; boilerplate use checks lack
# a concrete ambiguity in these records.
for n in (184,185,186,187,188,189,190,193,194,195,196,197,198,200):
    change(n,'正文明确服务式公寓可租及居住房型，不因服务式或攻略标签统一要求再核住宅用途。',needs_review=[])
change(184,'一年是询价方案条件，每月是计价周期，不能当已确认签一年。',
       topics=[topic('入住与租期','租一年','conditional',scope='租一年每月多少？'),
               topic('价格预算','每月多少？',scope='租一年每月多少？')],
       time_mentions=[tm(184,'一年','lease_duration','P1Y','本人以租一年为询价条件，尚无已签约或确定起租日'),tm(184,'每月','other',None,'月度计价周期，不是另一个租期')])
change(185,'月租价格不证明只租一个月；保留月计价，不当成确定租期池。',
       topics=[topic('价格预算','月租价格 求')],time_mentions=[tm(185,'月租','other',None,'按月询价，不能确定总租期为一个月')])
change(186,'类似房型是对房源类型的询问，不把正文具体房型直接变成本人硬要求。',
       topics=[topic('户型面积与居住方式','类似的房型'),topic('价格预算','多少价位一个月？')],
       time_mentions=[tm(186,'一个月','other',None,'月租计价周期，总租期未明确')])
change(189,'20天为本人询价短租时长，不代表已具备供应或已经订房。',
       topics=[topic('入住与租期','短租20天','require',scope='短租20天多少钱'),topic('价格预算','多少钱',scope='短租20天多少钱')])
change(190,'私个价格只请求私下提供该房源价格，不外推为任意营销或本项目发送授权。',
       contact_boundaries=[dict(quote='私个价格',scope='希望私下获知所询房源价格；请求范围限该事项，不等同已授权本项目实际发送')])
change(191,'一个月多少可为月计价或仅住一月，分开价格确定性与总租期不确定性。',
       topics=[topic('价格预算','一个🈷️多少')],
       time_mentions=[tm(191,'一个🈷️','other',None,'月度价格询问；总租期是否仅一个月仍未说明')],
       possible_topics=[dict(pool='入住与租期',ambiguity='可能仅住一个月，也可能只是问月价，不能确定总租期')],
       needs_review=['需要的总租期是否一个月未明，不能把月价直接记成一个月短租'])
change(192,'一居室是本人所询房型；多少指标未明不应抹去对真实出租公寓的询问主体。',
       role='demand',demand_state='active_at_comment',interest='medium',
       topics=[topic('户型面积与居住方式','一居室')],
       reason='本人询问正文一居室房源的指标，保留询租线索；多少是租金或面积尚未明确',
       context_used=['own','body'],needs_review=['多少所指租金、面积或其他指标未明，不计入确定价格池'])
change(196,'多少一个月是按月询价，不足以确认总租期仅一个月。',
       topics=[topic('价格预算','多少一个月')],time_mentions=[tm(196,'一个月','other',None,'月租计价周期，总租期未明确')])
change(199,'本人价格、8月入住及私信三池联动；当时推进与今日期望分开，八月不改成今天或明年。',
       topics=[topic('价格预算','价格多少'),topic('入住与租期','8月入住','fact'),topic('看房联系','丝一下我')],
       time_mentions=[tm(199,'8月','move_in','2026-08','按2026-07-22评论时点推定为随后2026年8月；原文未写年份和日，尚未由本人确认')],
       needs_review=['8月具体日及推定年份未由本人确认；该期望入住月份已早于分析日，是否仍有新需求未核实'],
       contact_boundaries=[dict(quote='丝一下我',scope='希望私信回应本次租房询价/入住事项；不等同本项目实际发送许可')],
       context_flags=['评论时主动询价并计划随后8月入住，不等于截至2026-10-29仍在找房；不能把入住时间过期当作已租好'])
change(200,'私一下价格限制在询问该房源价格，不能当批量营销许可。',
       contact_boundaries=[dict(quote='私一下价格',scope='希望私下获知所询房源价格；不等同已授权本项目实际发送')])

# Reply suitability is explicitly adjudicated by review key. This does not
# generate text, fill template placeholders, or authorize contact.
mother_file=BASE.parents[3]/'approved-mothers-model-view.json'
mothers=json.loads(mother_file.read_text(encoding='utf-8'))
approved_slots={m['slot'] for m in mothers if m['approved']}
reply_groups={
 1:[5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,64,71,74,75,76,77,78,79,80,81,83,84,85,89,90,92,96,104,154,185,187,188,190,191,193,194,195,196,197,198,199,200],
 7:[56,186,192],
 19:[65,184,189],
 25:[70],
 28:[50,69],
 31:[51,52,53,54,55,57,58,59,60,61,62,63,66,67,68,82,87,88,100,146,147,150],
 34:[72,86,155,159,161]}
slot_facts={
 1:['方隅拟推荐门店、有效优惠及适用条件未核；通用接话不提供正式报价或实时房态'],
 7:['同一方隅门店确有本人所询房型及有效房源尚未核实；不能套用原帖房型背书'],
 19:['同一方隅门店是否接受所询时长、当期可安排房源及相应总价未核实'],
 25:['同一方隅门店当前水电口径、全部必付费用和所询房源报价尚未核实'],
 28:['真实对接权限、同店可看房态和看房安排尚未核实，预约尚未确认'],
 31:['方隅具体门店位置与本人地区/通勤适配尚未核实；优惠及条件未核实'],
 34:['同一方隅房源是否同时满足本人全部房型、地区、预算等条件及有效优惠尚未核实']}
assigned={n:s for s,ns in reply_groups.items() for n in ns}
assert sum(len(ns) for ns in reply_groups.values())==len(assigned)
for n in range(1,201):
    k=f'D{n:04d}'; r=rows[k]; s=assigned.get(n)
    if s is None:
        plan=dict(preferred_mother_slot=None,generic_intro_suitable=False,tone='normal',
                  missing_facts=copy.deepcopy(r['needs_review']),
                  caution=[r['reason'],'未确认适合住户推荐接话；保留原语义及待核机会，不据此授权发送'])
    else:
        assert s in approved_slots
        plan=dict(preferred_mother_slot=s,generic_intro_suitable=True,tone='normal',
                  missing_facts=copy.deepcopy(slot_facts[s])+copy.deepcopy(r['needs_review']),
                  caution=['slot1可作为已认可通用住户推荐接话，但不等于完整回答原帖报价、房态或专项条件',
                           '专项母句含有事实断言时须先补齐同店同房源证据；不能拿原帖其他出租者的设施、宠物政策或报价替方隅背书',
                           '仅按评论时语义适配，今日是否仍需房未复核；本计划及原评论私信请求均非本项目发送许可'])
        if 5<=n<=23:plan['missing_facts'].append('所询原帖为上海长宁个人转租；其报价/房态及方隅替代位置适配尚未核实')
        if 50<=n<=68:plan['missing_facts'].append('所询正文为北京可租公寓；本人未说的目标地区不能由IP或上海源门店补齐')
        if 69<=n<=85:plan['missing_facts'].append('所询正文为北京沙河可租房源；不能把源门店当成本人目标地区')
        if 184<=n<=200:plan['missing_facts'].append('所询正文为虹桥服务式公寓；原帖价格/房态/服务不等于方隅同店事实')
    r['reply_plan']=plan

def reply_extra(n,missing=(),caution=()):
    p=rows[f'D{n:04d}']['reply_plan'];p['missing_facts']+=list(missing);p['caution']+=list(caution)

for n in (16,23,74,78,83,192):reply_extra(n,caution=['先保留价格/面积指标歧义，不能用价格母句假装已回答所问指标'])
reply_extra(51,missing=['西城或4号线是OR选择，不要求同一房源同时位于两个地点'])
reply_extra(56,missing=['同房源是否允许两个人居住及对应房型、人数规则未核实'])
reply_extra(58,caution=['本人已质疑真实性，不得暗示原帖房源及低价已由方隅核验'])
reply_extra(62,missing=['10号线或12号线为OR选择，具体站点与通勤距离未明'])
reply_extra(65,missing=['工作地中关村不是必须居住在中关村；可接受通勤范围未明'],caution=['一个月为本人明确短租时长，不能用别店历史租期政策兜底'])
reply_extra(72,missing=['同一房源能否整租、月预算约1000及全部必付费用是否合适未核实'],caution=['小一点可接受有预算场景，1000左右是约数，不改成精确硬上限或接受合租'])
reply_extra(86,missing=['武侯区合租的具体地点、房间和室友安排未核实'],caution=['合租是本人询问方向，不当成必须整租或已有整套预算'])
reply_extra(89,missing=['本人想找共同租房的室友还是已备合租房间未明'],caution=['不宣称方隅可提供室友或已确认合租空位'])
reply_extra(96,missing=['合租对象、空位及是否已持有房源未明'],caution=['本人询问合租，不能承诺方隅提供室友或可多人分租'])
reply_extra(154,missing=['本人是找合租房、共同找房室友还是已有房招室友未明'],caution=['保留合租机会，但不直接说方隅有其所需室友/分租空位'])
reply_extra(155,caution=['晋安区、两房半和2000内须由同一房源联立满足，不能各拿一间房拼条件；不把两房半擅改两居'])
reply_extra(159,missing=['便宜的具体预算上限未明；两房是否必须整租未明'])
reply_extra(161,missing=['同一房源需匹配晋安区鼓山镇及两室一厅，均未核实'])
reply_extra(184,caution=['一年为询价条件，不是已签约承诺；母句不能代替月租及总费用报价'])
reply_extra(185,caution=['月租询价不等于只住一个月'])
reply_extra(186,missing=['类似的房型具体指向未明，不得假定为正文全部房型或全部公区服务'])
reply_extra(189,caution=['20天短租与月租门槛可能不同，未核实不得用租期母句直接断言可以住'])
reply_extra(190,caution=['仅请求私下报价，不等于已经授权发送与该房源无关的批量广告'])
reply_extra(191,caution=['按月询价或仅住一月尚未区分，不承诺一个月短租政策'])
reply_extra(199,caution=['原文8月入住按评论时点推定；不强改为下一年8月，不声称已经入住或仍在等待；私信不等于约看'])
reply_extra(200,caution=['同时关心房态与价格，通用推荐不能假装已经逐项回答；私下报价请求范围不扩为任意营销'])
for n in (136,137,138,139,140,141,142,173,180,181):
    reply_extra(n,missing=['是否另有商业公寓或过渡房需求未确认'],caution=['当前只见公租/保租资格、选房或等待语境，不冒充能代办、保资格、抢房或加速排队；留作需求待核'])
reply_extra(117,caution=['原文联系限制仅针对其托管平台其他事项；本条不推荐住户母句的原因是没有本人找房需求，非把该限制扩为对所有人拒联'])

final=[rows[r['review_key']] for r in original]
allowed_pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
allowed={
 'role':{'demand','supply','mixed','unknown','discussion'},
 'demand_state':{'active_at_comment','future','ended','historical','unknown'},
 'interest':{'super_high','high','medium','low','very_low','uncertain','unrelated'},
 'polarity':{'ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'},
 'subject':{'own_demand','supply','current_home','other_person','unresolved'},
 'relation':{'desired','preferred','accepted','excluded','work','current_home','offered','unresolved'},
 'group_relation':{'AND','OR','unknown'},
 'time_role':{'move_in','viewing','lease_duration','search_start','other'}}
errors=[];quote_count=0
for r in final:
    k=r['review_key']; text=source[k][0]['text']
    for fld in ('comment_id','customer_uid','video_id'):
        if r[fld]!=inputs[k][fld]:errors.append([k,'identity',fld])
    for fld in ('role','demand_state','interest'):
        if r[fld] not in allowed[fld]:errors.append([k,'enum',fld])
    for fld in ('topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','context_used','needs_review','contact_boundaries','context_flags'):
        if not isinstance(r[fld],list):errors.append([k,'list',fld])
    quotes=list(r['evidence'])
    for fld in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries'):
        for x in r[fld]:
            if 'quote' in x: quotes.append(x['quote'])
            for f in ('polarity','subject','relation','group_relation','time_role'):
                if f in x and x[f] not in allowed[f]:errors.append([k,'enum',f,x[f]])
    for x in r['topics']+r['possible_topics']:
        if x['pool'] not in allowed_pools:errors.append([k,'pool',x['pool']])
    for q in quotes:
        quote_count+=1
        if not q or q not in text:errors.append([k,'quote_not_verbatim',q])
    for x in r['topics']+r['target_regions']:
        if x.get('condition_scope') and x['condition_scope'] not in text:
            # Only a semantic channel marker is allowed outside raw scope, but
            # prefer a source-verbatim scope for every exported record.
            errors.append([k,'scope_not_verbatim',x['condition_scope']])
    if any(r[f] is not False for f in ('human_confirmed','send_authorized')) or r['store_assignment'] is not None:errors.append([k,'authorization'])
    p=r['reply_plan']
    if p['preferred_mother_slot'] is not None and p['preferred_mother_slot'] not in approved_slots:errors.append([k,'mother_slot'])
    if p['tone'] not in ('normal','serious') or not isinstance(p['generic_intro_suitable'],bool):errors.append([k,'reply_plan_enum'])

changes=[]
for old,new in zip(original,final):
    diffs={f:{'old':old.get(f),'new':new.get(f)} for f in set(old)|set(new) if old.get(f)!=new.get(f)}
    changes.append(dict(review_key=new['review_key'],comment_id=new['comment_id'],independently_semantically_reviewed=True,
                        changed=bool(diffs),semantic_fields_changed=any(f!='reply_plan' for f in diffs),fields=diffs,
                        reasons=reasons.get(new['review_key'],['独立通读本人评论及所属正文后，与初判逐字段比较，未发现需修正的实质判断。'])+['逐条增加已认可母句适配计划；未撰写或发送回复正文。']))

assert len(final)==len(inputs)==len(source)==200
assert not errors,errors
assert len({r['review_key'] for r in final})==200
assert before=={n:sha(BASE/n) for n in protected}
(BASE/'fine-reviewed.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in final),encoding='utf-8')
(BASE/'changes.json').write_text(json.dumps({'method':'独立模型细筛，非人工金标；先通读200条与共享正文，再比对初判。脚本仅序列化逐条明确修订及确定性校验，不运行关键词分类器。','reviewed_count':200,'changed_count':sum(x['changed'] for x in changes),'records':changes},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
validation=dict(input_count=len(inputs),output_count=len(final),independently_reviewed_count=len(changes),
                review_key_set_equal={r['review_key'] for r in final}==set(inputs),
                comment_id_set_equal={r['comment_id'] for r in final}=={r['comment_id'] for r in inputs.values()},
                unique_review_keys=len({r['review_key'] for r in final}),unique_comment_ids=len({r['comment_id'] for r in final}),
                identities_match=not any(e[1]=='identity' for e in errors),quotes_verbatim=not any(e[1]=='quote_not_verbatim' for e in errors),
                verified_quote_count=quote_count,enum_validation='passed',scope_quotes_verbatim='passed',fixed_authorization_fields_valid=True,
                protected_original_sha256=before,protected_original_bytes_unchanged=before=={n:sha(BASE/n) for n in protected},
                interest_counts=dict(collections.Counter(r['interest'] for r in final)),role_counts=dict(collections.Counter(r['role'] for r in final)),
                state_counts=dict(collections.Counter(r['demand_state'] for r in final)),changed_records=sum(x['changed'] for x in changes),
                interest_changed_records=sum('interest' in x['fields'] for x in changes),
                role_changed_records=sum('role' in x['fields'] for x in changes),errors=errors,
                semantic_changed_records=sum(x['semantic_fields_changed'] for x in changes),
                reply_plan_count=sum('reply_plan' in r for r in final),
                generic_intro_suitable_count=sum(r['reply_plan']['generic_intro_suitable'] for r in final),
                mother_slot_counts=dict(collections.Counter(r['reply_plan']['preferred_mother_slot'] for r in final)),
                approved_mothers_sha256=sha(mother_file),
                method='独立模型逐条细筛；非人工金标、非绝对准确率评估、非实地房源/资格核验',
                scope='仅200条本地派生文件；未改原始初判/源库/主指针，未采集、未调用外部API、未发送或publish')
(BASE/'fine-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False,indent=2))
