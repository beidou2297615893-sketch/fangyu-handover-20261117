import json,hashlib,collections
from pathlib import Path
p=Path(__file__).parent
source=p/'shard-0.jsonl'; rows=[json.loads(s) for s in source.read_text(encoding='utf-8-sig').splitlines()]
def ids(s):return {int(n) for n in s.split()}
high=ids('1 4 7 10 13 16 37 43 46 49 52 55 67 85 88 91 112 118 133 163 169 178 202 208 217 220 262 265 268 304 307 310')
medium=ids('127 211')
supply=ids('19 25 28 31 40 58 106 214 256 277')
discussion=ids('22 34 70 79 82 94 151 181 184 190 223 229 241 289 292 295 298')
ended=ids('61')
mixed=ids('154')
notes={
64:'询问五号线推荐，视频在讨论中介，尚不能确定询问房源还是中介。',73:'“川沙有没有”可能询问房源或中介，缺少明确对象。',76:'只说人在南翔，未说明是现住、工作还是求租目标。',97:'询问某房是否值得，缺少已签约状态及是否本人当前找房。',100:'表达预算但对象是租房经验分享，未说明本人正在找房或所指具体房源。',103:'只说闵行浦江，具体是居住地、工作地或求租目标不明。',109:'说家附近没房子，没有说明本人是否现在求租及具体对象。',115:'提出预算但询问对象为租房经验分享，无法确认具体房源及本人当前需求。',121:'问“自如”但对象是品牌、价格或房源不明。',124:'“有合适的吗”缺少具体对象，背景是租房经验而非在租房源，需确认本人是否正在找房。',130:'仅问地点；视频是已租房体验，不能假定为在租房源或本人求租。',136:'只问某地区“有吗”，视频是体验分享，具体所问对象待核。',139:'只问地区“有没有”，视频不是明确可租房源，具体对象待核。',142:'问房子价格，视频描述已租住体验，可能询问现租金而非可租房源。',145:'只问地名“有没有”，视频为已租房体验，未明所指对象。',148:'只问“位置”，帖子本身是别人求租，不能推断本人的需求或提供身份。',157:'只说“这边有”，未明有房、资源还是其他，深层回复未读。',160:'询问上城500元的房屋类型，不能据此确认本人正在求租。',166:'只问上城有吗，租房价格讲解语境中所指房型或价格对象不明。',172:'问有没有便宜一点的，未指明是哪套房或是否本人当前求租。',175:'只问上城有吗，租房价格讲解语境中所指房型或价格对象不明。',187:'表达找室友并提到户型及租金，但未明已有房源、拟合租目标及条件归属。',193:'称看过一个价格并问别人在哪个区，未说明本人是否提供房或正在求租。',196:'仅有地名和附近，不能确定是现住、工作还是求租目标。',199:'说租了七年没找到适合的，未说明是否仍在找新房。',205:'“有没有诚心”指代不明，可能找室友或提供房间，不能单凭原帖认定身份。',226:'“我不是”缺少所指对象和直接回复关系。',232:'索取表格但未明确本人是否当前找房。',235:'提及线路和地名，但所指为房源、通勤还是表格信息不清楚。',238:'询问表格领取方式，未说明本人当前租房需求。',244:'“不要钱，九亭”指代不明，不能推断租金或房源是否真实。',247:'“租不到”未说明本人是否当前仍在找或具体房源需求，深层回复未读。',250:'“金桥这边有”未说明是提供房源、推荐地区还是其他内容。',253:'仅有表情，缺少具体意思。',259:'“有没有一起的”可能找室友或同行，未说明本人需求及具体对象。',271:'询问某地区一居市场价格，未表明本人正在找租房。',274:'“我不知道”缺少具体所指和直接回复。',280:'质疑价格真实性，视频是已租房体验，不是明确本人求租。',283:'只问地点，视频是已租房体验，不能当作在租房源询盘。',286:'问怎么租，但视频是已租住体验，无法确定是本人当前找房还是泛问方法。',301:'“合租可以”可能回复发帖人或者表达本人意愿，缺少直接关系。'
}

# Per-record semantic annotations, quoting only the comment itself.
T={}
def topic(n,pool,quote,polarity='ask',subject='own_demand',scope='本人对租房的询问或条件'):
 T.setdefault(n,[]).append(dict(pool=pool,quote=quote,polarity=polarity,subject=subject,source='comment',condition_scope=scope))
R={}
def region(n,quote,relation='desired',scope='本人询问或希望的租住范围',group='unknown'):
 R.setdefault(n,[]).append(dict(text=quote,quote=quote,relation=relation,group_relation=group,condition_scope=scope,source='comment'))

for n in [1,4,7,10,13,16,37,43,52,55,85,118,133,163,169,208,307]:
 q={1:'有没有转租的',4:'有吗',7:'有吗',10:'有没有',13:'有没有',16:'有吗',37:'有没有转租的',43:'还有吗',52:'还在吗',55:'还在吗',85:'有推荐吗',118:'哪有',133:'有套一吗',163:'有吗',169:'有吗',208:'有一起合租的吗',307:'有没有'}[n]
 topic(n,'房源状态',q,'ask',scope='询问房源或合租对象；不代表房源现有或已预约')
for n in [1,4,7,10,13,16,67,85,91,112,118,133,163,169,202,208,211,262,265,268,304,307,310]:
 q={1:'八号线12号线',4:'杨浦国京路这块',7:'杨浦区',10:'宝山',13:'普陀镇平路或者曹杨路',16:'九亭 泗泾',67:'芦潮港新芦苑这边和泥城这边',85:'浦江镇',91:'宝山杨浦静安附近',112:'在哪个位置',118:'角门到十里河十号线这段',133:'双流二江寺这边',163:'拱墅区',169:'杭州大夏附近',202:'娄山关路',208:'长宁区',211:'仙霞或者伊犁附近',262:'离地铁站步行多少米',265:'七宝哪',268:'通州台湖附近',304:'金沙湖附近',307:'上城区望江家园或附近',310:'中心一点的'}[n]
 pol='ask' if n in (112,262,265) else ('prefer' if n==310 else 'require')
 topic(n,'位置通勤',q,pol,scope='仅记录本人询问或所写区域；不从视频或IP补充地区')
for n in [1,4,7,10,13,16,67,85,91,118,133,163,169,202,208,211,268,304,307]:
 q={1:'八号线12号线',4:'杨浦国京路这块',7:'杨浦区',10:'宝山',13:'普陀镇平路或者曹杨路',16:'九亭 泗泾',67:'芦潮港新芦苑这边和泥城这边',85:'浦江镇',91:'宝山杨浦静安附近',118:'角门到十里河十号线这段',133:'双流二江寺这边',163:'拱墅区',169:'杭州大夏附近',202:'娄山关路',208:'长宁区',211:'仙霞或者伊犁附近',268:'通州台湖附近',304:'金沙湖附近',307:'上城区望江家园或附近'}[n]
 region(n,q,group='OR' if n in (13,16,67,91,211,307) else 'unknown')
topic(13,'户型面积与居住方式','一室户','require');topic(13,'费用合同','房东直租','require')
topic(46,'价格预算','多少钱');topic(49,'看房联系','怎么联系')
topic(67,'价格预算','预算500-800','require');topic(67,'价格预算','哪边房租便宜些','compare');topic(67,'户型面积与居住方式','想租一室一厅一厨一卫','prefer')
topic(85,'户型面积与居住方式','打算租两室的','require')
topic(88,'户型面积与居住方式','想合租','require');topic(88,'户型面积与居住方式','大学毕业生','require',scope='对潜在合租伙伴的条件，非房型')
topic(91,'位置通勤','不需要靠近地铁站','not_required',scope='不把不需要靠近理解成完全拒绝地铁站');topic(91,'位置通勤','离地铁站越远越好','prefer',scope='希望距地铁较远')
topic(112,'价格预算','性价比高','prefer');topic(118,'价格预算','一千以下','require');topic(118,'户型面积与居住方式','单间','require')
topic(133,'户型面积与居住方式','套一','require');topic(163,'户型面积与居住方式','一室一厨一卫','require');topic(169,'户型面积与居住方式','二居','require')
topic(178,'户型面积与居住方式','ab套还是整租','ask',scope='询问两种住房方式，不等于接受或拒绝某一方式')
topic(202,'户型面积与居住方式','想找合租','require');topic(202,'宠物','我一人一猫','fact',scope='本人有猫，不推断任何门店可养宠')
topic(208,'户型面积与居住方式','一起合租','require');topic(217,'价格预算','多少钱');topic(220,'价格预算','多少钱');topic(220,'看房联系','怎么联系')
topic(268,'户型面积与居住方式','独门独院','require')
topic(304,'价格预算','1200以内','require');topic(304,'房内设施','要独卫','require');topic(304,'户型面积与居住方式','实用面积25+','require',scope='面积原词，单位和测量口径未明');topic(304,'费用合同','民水民电','require')
topic(310,'价格预算','预算5000','require');topic(310,'户型面积与居住方式','户型','ask')
topic(187,'户型面积与居住方式','想找个室友','require','unresolved',scope='已表达找室友，但已有房源或本人另找住房待核')
topic(187,'户型面积与居住方式','两室两厅','unknown','unresolved',scope='不确定为现有房型或新需求');topic(187,'价格预算','房租一千多','unknown','unresolved',scope='不确定为现有租金或预算')
topic(100,'价格预算','预算4000','unknown','unresolved',scope='预算目的不明');topic(115,'价格预算','预算2500','unknown','unresolved',scope='咨询对象及当前找房状态不明');topic(124,'价格预算','预算6000左右','unknown','unresolved',scope='咨询对象及当前找房状态不明')
topic(160,'户型面积与居住方式','是什么房子','ask','unresolved');topic(271,'价格预算','一般多少钱','ask','unresolved',scope='询问市场水平不等于本人预算');topic(271,'户型面积与居住方式','一居','ask','unresolved')
topic(280,'价格预算','价格真实不','ask','unresolved',scope='质疑已住体验所述价格真实性，不等于询租');topic(286,'看房联系','怎么租','ask','unresolved',scope='咨询租房方式，不等于具体约看')
topic(301,'户型面积与居住方式','合租可以','accept','unresolved',scope='说话人是否本人寻租或回应他人未明')
for n,q in [(64,'五号线'),(73,'川沙'),(103,'闵行浦江'),(124,'北京'),(136,'武侯区三环附近'),(139,'武侯区八号线周围'),(145,'双楠'),(166,'上城'),(175,'上城'),(196,'闵行维璟中心附近'),(259,'普陀嘉定'),(271,'海淀')]:region(n,q,'unresolved','地点用途及本人目标待核')
for n,q in [(19,'徐汇区 徐汇世家花园'),(106,'金盏西村'),(154,'杭州滨江齐虹雅园'),(214,'普陀区华师大一村'),(256,'11号线昌吉东路地铁站附近'),(277,'路松街')]:region(n,q,'offered','提供或转租房源区域，不是本人新求租目标')
region(70,'宝山','unresolved','评论者所述租住房地点，未明确现住或已搬离，不作为新求租目标')
for n,q in [(79,'九号线泗泾'),(82,'西渡'),(289,'杭州余杭欧美金融城')]:region(n,q,'current_home','评论者所述租住或既有房屋；不能转换为新求租目标')
for n,q in [(79,'七宝'),(82,'漕宝路')]:region(n,q,'work','本人所述工作地点；不能自动转换成居住目标')
time_quotes={154:[('还有10月到期','lease_end','supply')],211:[('准备找','search_start','own_demand')],289:[('这个月底我要搬去萧山','move','current_home')]}

out=[]
for d in rows:
 n=int(d['review_key'][1:]); t=d['comment_text']; reasons=[]
 if n in high:role='demand';interest='high';why='本人提出找房条件或针对明确租赁房源提出有效询问，仅代表评论时兴趣。'
 elif n in medium:role='demand';interest='medium';why='本人表达租住或近期找房意愿，具体房源及后续行动尚未明确。'
 elif n in supply:role='supply';interest='unrelated';why='评论提供、推荐、转租房源或提供租房服务，没有明确本人新求租条件。'
 elif n in discussion:role='discussion';interest='unrelated';why='评论为经验、评价、建议、其他话题或已入住情况，未明确新的本人求租。'
 elif n in ended:role='demand';interest='unrelated';why='本人明确刚租好，当前这次需求已结束，未表达新的需求。'
 elif n in mixed:role='mixed';interest='uncertain';why='本人提供转租房并因工作变动说要换房；新房是否已找到及需求条件待核。';reasons.append('旧房位置、设施、租金和入住条件不能当成新房需求；换房进展未知。')
 else:
  assert n in notes,n
  role='unknown';interest='uncertain';why=notes[n];reasons.append(notes[n])
 if n==31: reasons.append('工作变动引发转租，是否另找新住处未知，保留待核线索。')
 if n==25: reasons.append('本人正尝试转租旧房；是否也在找新住处未说明。')
 if n in (127,133,136,139,142,145,280,283,286):reasons.append('视频是本人已租住体验，不证明视频中房源仍在出租；画面未读。')
 if n in (4,7,10,13,16,37,67,85,88,91,112,118,127,133,163,169,202,208,211,268,304,307,310):reasons.append('评论时有找房或租住线索，当前是否仍在找需核实。')
 if n in (43,46,49,52,55,178,217,220,262,265):reasons.append('仅为评论时对该房源的询问，房源当前状态和本人后续进展未知。')
 if n==67:reasons.append('预算500–800的付款周期未说明；2600–2300是本人转述中介报价，不是本人预算。')
 if n==91:reasons.append('不需要靠近地铁并希望越远越好；具体可接受距离未说明。')
 if n==211:reasons.append('“准备找”未说明开始日期；不因未来入住或计划词机械认定暂不推进。')
 if n==304:reasons.append('面积“25+”的计量单位及预算周期未明确；民水民电、独卫均需实际事实核实。')
 if n==289:reasons.append('表述计划月底搬往另一地，但没有说是否仍需找房或已安排新住处。')
 times=[dict(quote=q,time_role=tr,subject=sub,source='comment',published_at_unix=d.get('published_at_unix'),normalized=None,verification='只保存本人原词，未凭今天推定具体日期或当前状态') for q,tr,sub in time_quotes.get(n,[])]
 reply='有可见深层回复，尚未读取' if d.get('deeper_reply_count_visible',0) and not d.get('deeper_replies_read') else ('深层回复已读取' if d.get('deeper_replies_read') else '未读取深层回复；当前未见可见回复数')
 if d.get('deeper_reply_count_visible',0) and not d.get('deeper_replies_read'):reasons.append(f"可见{d['deeper_reply_count_visible']}条深层回复未读取，不能据此推断后续结果。")
 if d.get('source_version_conflict'):reasons.append('源版本存在冲突，应复核原始证据。')
 te=T.get(n,[]); regs=R.get(n,[])
 for e in te+regs+times:assert e['quote'] in t,(n,e['quote'])
 topics=list(dict.fromkeys(e['pool'] for e in te))
 state='ended' if n in ended else ('unknown' if n==211 else ('active_at_comment' if role=='demand' else 'unknown'))
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],video_id=d['video_id'],role=role,demand_state=state,interest_at_comment=interest,topics=topics,topic_evidence=te,target_regions=regs,time_mentions=times,reason=why,evidence=[t],review_reasons=reasons,context_used=['comment','post_body'],media_context='未读取视频画面；仅使用已保存的视频文字与本人评论',reply_context=reply,current_need_verified=False,assigned_store=None,send_authorized=False))

assert len(rows)==len(out)==104
assert len({x['review_key'] for x in rows})==104
assert {(x['review_key'],x['comment_id'],x['customer_uid'],x['video_id']) for x in rows}=={(x['review_key'],x['comment_id'],x['customer_uid'],x['video_id']) for x in out}
poolset={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for x,d in zip(out,rows):
 assert all(e and e in d['comment_text'] for e in x['evidence'])
 assert all(y['quote'] in d['comment_text'] for y in x['topic_evidence']+x['target_regions']+x['time_mentions'])
 assert set(x['topics'])<=poolset and set(x['topics'])=={y['pool'] for y in x['topic_evidence']}
 assert not (x['role']=='unknown' and x['interest_at_comment']=='unrelated')
 assert x['current_need_verified'] is False and x['assigned_store'] is None and x['send_authorized'] is False
(p/'reviewed-0.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
val={'input_count':104,'output_count':104,'unique_review_keys':len({x['review_key'] for x in out}),'id_quadruples_equal':True,'evidence_and_quotes_verbatim':True,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'role_counts':dict(collections.Counter(x['role'] for x in out)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in out)),'topic_counts':dict(collections.Counter(y for x in out for y in x['topics'])),'needs_review_count':sum(bool(x['review_reasons']) for x in out),'deeper_replies_unread_count':sum(bool(d.get('deeper_reply_count_visible')) and not d.get('deeper_replies_read') for d in rows),'video_frames_read':False,'human_confirmed':False,'current_need_verified':False,'send_authorized':False,'model_reference_not_gold':True}
(p/'validation-0.json').write_text(json.dumps(val,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(val,ensure_ascii=False,indent=2))
