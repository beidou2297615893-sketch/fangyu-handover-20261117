import json,pathlib,datetime,collections,sys
BASE=pathlib.Path(__file__).resolve().parent
ROOT=BASE.parent.parent
TASK=json.loads((BASE/'task.json').read_text(encoding='utf-8'))
SRC={r['review_key']:r for r in map(json.loads,pathlib.Path(TASK['source_full_metadata_file']).read_text(encoding='utf-8').splitlines())}
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
CODES={'H':('demand','active_at_comment','high'),'M':('demand','active_at_comment','medium'),'U':('unknown','unknown','uncertain'),'Q':('demand','unknown','uncertain'),'V':('demand','active_at_comment','super_high'),'E':('demand','ended','unrelated'),'R':('demand','historical','unrelated'),'F':('demand','future','low'),'S':('supply','unknown','unrelated'),'X':('discussion','unknown','unrelated'),'B':('mixed','unknown','uncertain'),'N':('demand','active_at_comment','unrelated')}
FACTS={1:'真实住户、推荐资格及优惠适用门店、时效、条件',2:'同店同房源符合总预算和全部明确条件',7:'同店有效房源具备所指户型',13:'真实住户及同店房型对该宠物种类体型数量的政策',16:'真实住户、同店电梯及具体楼层可看安排',19:'同店接受所需租期且相应日期可住',25:'真实住户、同店水电及全部必付费用口径',28:'真实对接权限、同店可看安排与本人方便时间',31:'真实住户、可承接位置、推荐优惠及介绍资格',34:'同一有效房源满足全部条件、报价、优惠与介绍资格'}
def expand(n):
 d=json.loads((BASE/f'page-{n:02}.json').read_text(encoding='utf-8')); cs={c['key']:(g,c) for g in d['shared_post_context'] for c in g['comments']};out=[]
 rawlines=(BASE/f'decisions-{n:02}.txt').read_text(encoding='utf-8').splitlines()
 lines=[]
 for line in rawlines:
  if not line.strip() or line.startswith('#'):continue
  ks,rest=line.split('|',1)
  lines.extend(k+'|'+rest for k in ks.split(','))
 for line in lines:
  if not line.strip() or line.startswith('#'):continue
  p=line.split('|'); assert len(p)>=7,line
  k,cp,ts,rs,reason,mom,extra=p; g,c=cs[k];s=SRC[k];code=cp[0];contact={'a':'allow','i':'identity_restricted','n':'no_contact','u':'unknown'}[cp[1]];e=json.loads(extra) if extra else {};role,state,interest=CODES[code]
  r={x:s.get(x) for x in ['review_key','platform','comment_id','customer_uid','video_id','comment_text','published_at_unix','post_author_same_as_commenter','source_stable_key','source_comment_sha256','rule_version']}
  r.update(role=role,demand_state=state,interest=interest,topics=[],target_regions=[],time_mentions=e.pop('time_mentions',[]),other_constraints=e.pop('other_constraints',[]),possible_topics=e.pop('possible_topics',[]),evidence=[c['text']] if c['text'] else [],reason=reason,context_used=['own','body']+(['parent'] if c['parent'] else []),needs_review=e.pop('needs_review',[]),human_confirmed=False,send_authorized=False,store_assignment=None)
  for t in ts.split(';') if ts else []:
   a=t.split('~'); assert len(a)>=2
   r['topics'].append(dict(pool=POOLS[int(a[0])-1],quote=a[1],polarity=a[2] if len(a)>2 else 'ask',subject=a[3] if len(a)>3 else ('own_demand' if role=='demand' else 'unresolved'),condition_scope=a[4] if len(a)>4 else a[1]))
  for t in rs.split(';') if rs else []:
   a=t.split('~');r['target_regions'].append(dict(text=a[0],quote=a[1] if len(a)>1 and a[1] else a[0],relation=a[2] if len(a)>2 else 'desired',group_relation=a[3] if len(a)>3 else 'unknown',condition_scope=a[4] if len(a)>4 else (a[1] if len(a)>1 and a[1] else a[0])))
  for t in r['time_mentions']:
   t.setdefault('anchor_source','comment_published_at_unix');t.setdefault('anchor_time',datetime.datetime.fromtimestamp(s['published_at_unix'],datetime.timezone.utc).isoformat() if s.get('published_at_unix') else None);t.setdefault('normalized',None);t.setdefault('verification','保留原词，未确认当前有效')
  slot=int(mom.rstrip('s')) if mom.rstrip('s') else None;serious=mom.endswith('s')
  missing=e.pop('missing_facts',[])
  if slot:missing += [FACTS[slot], '本人目前是否仍找房、方隅可承接门店及同一房源的全部条件']+[f'本人所问“{t["quote"]}”对应的{t["pool"]}事实' for t in r['topics'] if t['subject']=='own_demand']
  if code in ['H','M','V']:r['needs_review'] += ['评论时兴趣，当前找房状态与方隅承接条件未确认']
  if code in ['U','Q','B']:r['needs_review'] += [reason]
  cautions=e.pop('caution',[])
  if slot:cautions += ['仅母句适配候选，须补核同店同房源事实；通用介绍也须核真实住户、优惠与推荐资格，不等于完整答复或发送许可']
  if serious:cautions += ['严肃语境去掉宝宝等亲昵称呼']
  r['reply_plan']=dict(preferred_mother_slot=slot,generic_intro_suitable=e.pop('generic_intro_suitable',bool(slot)),tone='serious' if serious else 'normal',missing_facts=missing,caution=cautions,contact_policy=contact)
  r['contact_boundaries']=e.pop('contact_boundaries',[])
  r['context_flags']={'post_author_same_as_commenter':c['same_author'],'source_version_conflict':c['source_conflict'],'direct_parent_present':bool(c['parent']),'source_regions_not_assumed':True,'intent_at_comment_not_current_confirmation':True}
  r.update(e);out.append(r)
 assert len(out)==len(cs),(len(out),len(cs));assert {r['review_key'] for r in out}==set(cs);assert len({r['review_key'] for r in out})==len(out)
 for r in out:
  s=SRC[r['review_key']];allowed=[s['comment_text']]+([s.get('post_body','')] if s['post_author_same_as_commenter'] else [])
  for f in ['evidence','topics','target_regions','time_mentions','other_constraints','possible_topics']:
   for v in r[f]:
    q=v if isinstance(v,str) else v.get('quote','');assert not q or any(q in z for z in allowed),(r['review_key'],f,q)
 (BASE/f'reviewed-{n:02}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
 completed=sorted(int(p.stem.split('-')[-1]) for p in BASE.glob('reviewed-*.jsonl'))
 (BASE/'progress.json').write_text(json.dumps(dict(shard=1,total=TASK['comments'],total_pages=TASK['pages'],completed_pages=completed,completed_comments=sum(len(p.read_text(encoding='utf-8').splitlines()) for p in BASE.glob('reviewed-*.jsonl')),status='in_progress',method='explicit_per_comment_model_initial_and_detailed_decisions',updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),ensure_ascii=False,indent=2),encoding='utf-8')
 print(n,len(out),'validated')
if __name__=='__main__':expand(int(sys.argv[1]))


