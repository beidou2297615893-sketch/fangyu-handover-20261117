import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent
source=[json.loads(x) for x in (p/'shard-0.jsonl').read_text(encoding='utf-8-sig').splitlines()]
a=[json.loads(x) for x in (p/'reviewed-0-sub-a.jsonl').read_text(encoding='utf-8').splitlines()];b=[json.loads(x) for x in (p/'reviewed-0-sub-b.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(source)==522 and len(a)==260 and len(b)==262
src={x['review_key']:x for x in source};pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for r in b:
 d=src[r['review_key']]; original=r.pop('topics');r['topic_evidence']=original;r['topics']=list(dict.fromkeys(x['pool'] for x in original if x['subject']=='own_demand'));r['interest_at_comment']=r.pop('interest');r['review_reasons']=r.pop('needs_review');r['assigned_store']=r.pop('store_assignment');r['current_need_verified']=False
 for field in ('topic_evidence','target_regions','time_mentions','other_constraints'):
  for x in r[field]:x.setdefault('source','comment')
 r['evidence_sources']=[{'source':'comment','quote':q} for q in r['evidence']]
 r['media_context']='未读取视频画面；不能从他人房源继承本人条件';r['reply_context']='可见深层回复未读取' if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read') else '未读取深层回复'
allout=a+b
q=lambda x:(x['review_key'],x['comment_id'],x['customer_uid'],x['video_id'])
assert len({q(x) for x in allout})==522 and {q(x) for x in allout}=={q(x) for x in source}
for r in allout:
 d=src[r['review_key']];t=d['comment_text'] or ''
 assert r['role'] in ('demand','supply','mixed','unknown','discussion')
 assert r['interest_at_comment'] in ('super_high','high','medium','low','very_low','uncertain','unrelated')
 assert r['role']!='unknown' or r['interest_at_comment']=='uncertain'
 assert r['current_need_verified'] is False and r['assigned_store'] is None and r['send_authorized'] is False and r['human_confirmed'] is False
 assert set(r['topics'])<=pools and all(x['pool'] in pools for x in r['topic_evidence'])
 assert set(r['topics'])=={x['pool'] for x in r['topic_evidence'] if x['subject']=='own_demand'}
 assert r['published_at_unix']==d.get('published_at_unix') and r['ip_location_raw']==d.get('ip_location_raw')
 for field in ('topic_evidence','target_regions','time_mentions','other_constraints','evidence_sources'):
  for x in r[field]:
   assert x['source']=='comment' and x['quote'] in t,(r['review_key'],field,x)
 assert r['evidence']==[x['quote'] for x in r['evidence_sources']]
 assert all(x['time_role'] in ('move_in','viewing','lease_duration','search_start','other') for x in r['time_mentions'])
 if not t:assert not r['evidence'] and r['interest_at_comment']=='uncertain'
assert json.loads((p/'claim-0.json').read_text(encoding='utf-8-sig'))['owner']=='increment_a'
(p/'reviewed-0.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allout),encoding='utf-8')
check=[json.loads(x) for x in (p/'reviewed-0.jsonl').read_text(encoding='utf-8').splitlines()];assert allout==check
v={'input_count':len(source),'output_count':len(check),'unique_review_keys':len({x['review_key'] for x in check}),'id_quadruples_equal':True,'evidence_and_quotes_verbatim':True,'input_sha256':hashlib.sha256((p/'shard-0.jsonl').read_bytes()).hexdigest(),'output_sha256':hashlib.sha256((p/'reviewed-0.jsonl').read_bytes()).hexdigest(),'role_counts':dict(collections.Counter(x['role'] for x in check)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in check)),'own_demand_topic_counts':dict(collections.Counter(y for x in check for y in x['topics'])),'topic_subject_counts':dict(collections.Counter(y['subject'] for x in check for y in x['topic_evidence'])),'needs_review_count':sum(bool(x['review_reasons']) for x in check),'deeper_replies_unread_count':sum(bool(x.get('deeper_reply_count_visible')) and not x.get('deeper_replies_read') for x in source),'empty_comment_count':sum(not x['comment_text'] for x in source),'post_write_independent_reread':True,'video_frames_read':False,'human_confirmed':False,'current_need_verified':False,'send_authorized':False,'model_reference_not_gold':True,'interpretation_limit':'所有分类为模型语义初判，不是人工金标；画面、深层回复及当下需求未核实，平台效果未测；仅文本处理，无发送。'}
(p/'validation-0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,ensure_ascii=False))
