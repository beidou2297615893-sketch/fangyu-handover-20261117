"""Increment saved Douyin classifications and verify the read-only local journal."""
import json,sqlite3,hashlib,collections,shutil
from pathlib import Path
from datetime import datetime,timezone,timedelta
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=R/'work/fangyu-douyin-independent';D=W/'douyin-registered-v2';D.mkdir(exist_ok=True)
O=R/'outputs/方隅双平台文本业务/抖音逐店采集与意向'
def load(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def find(x,vid):
 if isinstance(x,dict):
  if str(x.get('aweme_id',x.get('video_id','')))==vid and 'desc' in x:return x
  for v in x.values():
   y=find(v,vid)
   if y:return y
 if isinstance(x,list):
  for v in x:
   y=find(v,vid)
   if y:return y
 return None
decisions=[
 ('fifth','7700127622508593929','discussion','unrelated',[],None,'噢no仅为感叹，没有本人租房需求证据。'),
 ('fifth','7700113223152042802','unknown','uncertain',[],None,'换房子了所指是已换完、正在换或回复他人不明；不直接当需求结束或仍在找。'),
 ('twelfth','7676016837893686074','demand','high',['房源状态'],None,'向明确成都住宅出租房源询问是否仍在并表示我需要；河南属地不盖过所问房源位置。'),
 ('twelfth','7674601457585046282','supply','unrelated',[],None,'已核为帖主，提供密码锁看房安排，属于供应方说明，不是本人约看请求。'),
 ('twelfth','7676138212570612486','demand','high',['房源状态'],None,'明确住宅出租语境询问房态；仅代表评论时询盘。'),
 ('twelfth','7680929827632710435','demand','high',['价格预算'],None,'在住宅出租正文下询问这个多少，按租金询价记录，金额未核，不作本人预算。'),
 ('thirteenth','7700697169179329316','unknown','uncertain',['价格预算','位置通勤'],'良渚（话题地点，本人目标待核）','询问良渚低价租住可能性，未明确本人正在找；六七百、七八百不是已确认本人预算。'),
 ('thirteenth','7700288120880857896','demand','high',['位置通勤','户型面积与居住方式','房内设施'],'乐富海邦园附近','明确询房、单间独卫及接受合租；安静规律描述本人生活习惯，不自动变成房屋隔音硬要求。'),
 ('thirteenth','7664265284589093681','unknown','uncertain',['位置通勤'],'马鞍山雅苑（关系待核）','仅小区名称，不明推荐、现住或求租，不当作明确目标。'),
 ('thirteenth','7683102868640252709','discussion','unrelated',[],None,'详细分享本月已搬家后的居住体验并推荐区域，没有另找新房的表达；现住地、费用和通勤不转为新需求。'),
 ('thirteenth','7673514829005456165','discussion','unrelated',[],None,'评价某处便宜，未表达本人找房，不按房租词判需求。'),
 ('thirteenth','7699496338153259833','demand','high',['位置通勤'],'余杭五常','本人明确在五常找房；山东属地不代替目标地区，门店覆盖仍待核。'),
 ('thirteenth','7667635505474962234','discussion','unrelated',[],None,'对瓶窑交通发问，未明确本人租房，不把出行讨论当需求。'),
 ('thirteenth','7666559739337720576','discussion','unrelated',[],None,'自述已租住的价格设施和交通，不代表仍有新需求。'),
 ('thirteenth','7665036516460102449','demand','high',['位置通勤','房源状态'],'城北万象城附近','在租房话题下询问指定区域是否有房，按当时寻房线索保留，非具体门店匹配。'),
 ('thirteenth','7699517321555854123','demand','high',['位置通勤','价格预算'],'良睦路工作地出发地铁通勤20分钟内；不要往西湖','本人明确预算和通勤条件；良睦路是工作地，不直接填成目标住址，摩托车是排除西湖方向的本人说明。'),
 ('thirteenth','7664968562792350504','unknown','uncertain',['看房联系'],None,'寻找中介渠道，也可能泛咨询或同行资源，尚不足确认本人租赁需求。'),
 ('thirteenth','7664689461137031974','demand','high',['位置通勤','价格预算','户型面积与居住方式','房内设施','费用合同'],'景芳、三堡九堡、钱江世纪城附近','明确预算约2500、可选一室一厅或可做饭大单间、民水民电和装修；可出中介费是接受条件，不继承视频其他预算。'),
 ('thirteenth','7666663124477723450','demand','high',['位置通勤','房源状态'],'临平南苑地铁站附近','主动寻找指定区域房源；河南属地不作目标城市。'),
 ('thirteenth','7699923674791068474','demand','high',['位置通勤','房源状态'],'未来科技城万达广场附近','在租房话题下询问具体区域是否有房；本人没说明预算户型，不能补视频作者条件。'),
 ('thirteenth','7669833504720732970','demand','high',['位置通勤','价格预算','户型面积与居住方式','房内设施'],'西溪景苑','明确问租金并要一室独卫，未自报预算。'),
 ('thirteenth','7667230614278587173','discussion','unrelated',[],None,'泛谈毕业季租金，不能推断评论者本人毕业或正在找房。'),
 ('thirteenth','7683442903616308026','demand','high',['位置通勤','房源状态'],'经纬能碳园附近','本人询问园区附近房源，地点原词保留，具体城市与门店服务范围仍待核。'),
 ('thirteenth','7678646099485131558','demand','medium',['位置通勤'],'腾龙路附近','主动比较居住区域，但未具体询盘或说明找房下一步，按评论时中等兴趣保留；道路城市未明确。'),
 ('thirteenth','7663912597787984666','discussion','unrelated',[],None,'分享曾询价和地区价格经历，未明确当前继续找；不把三千以上当本人预算。'),
 ('thirteenth','7663793108451017518','demand','low',[],None,'明确计划明年毕业后借攻略找房，目前未推进；明年锚定评论发表时间，不能当现在正在找。'),
]
old=[json.loads(x) for x in (W/'douyin-observations-v2/all-observed-classifications.jsonl').read_text(encoding='utf8').splitlines()];assert len(old)==33
allrows=old[:];source_by_pref={};new=[]
for pref in ['fifth','twelfth','thirteenth']:
 rp=B/f'{pref}-comments-raw.json';sp=B/f'{pref}-search-raw.json';raw=load(rp);video=find(load(sp),str(raw['video']));assert video
 comments={str(c['cid']):c for c in raw['response']['comments']};ds=[x for x in decisions if x[0]==pref];assert len(comments)==len(ds) and set(comments)=={x[1] for x in ds}
 for _,cid,role,level,topics,target,reason in ds:
  c=comments[cid];uid=str(c['user']['uid']);same=uid==str(video.get('author',{}).get('uid',''));t=c.get('text') or ''
  if cid=='7674601457585046282':assert same
  row={'platform':'douyin','comment_id':cid,'customer_uid':uid,'video_id':str(c['aweme_id']),'comment_text':t,
   'published_at':datetime.fromtimestamp(c['create_time'],timezone(timedelta(hours=8))).isoformat(),'observed_at':raw['at'],
   'age_days_at_observation':round((datetime.fromisoformat(raw['at'].replace('Z','+00:00')).timestamp()-c['create_time'])/86400,2),
   'source_store':raw['store'],'source_keyword':raw['keyword'],'role':role,'interest_at_comment':level,'topics':topics,
   'topic_status':'本人需求主题' if role=='demand' else '待核话题' if role=='unknown' else '供给或讨论条件不作本人需求',
   'target_region_reference':target,'queried_property_region':'成都高新西郫都区百草路777号（所问房源，不是本人明确地域约束）' if pref=='twelfth' and role=='demand' else None,
   'ip_location_raw':c.get('ip_label'),'ip_is_not_target_region':True,'post_body':video['desc'],'post_author_same_as_commenter':same,'post_body_conditions_are_own':same,
   'direct_parent_text':None,'reply_to':str(c.get('reply_id','0')),'deeper_reply_count_visible':c.get('reply_comment_total',0),'deeper_replies_read':False,
   'reason':reason,'evidence':[t] if t else [],'evidence_by_source':[{'source_kind':'own_comment','quote':t}],
   'context_flags':[],'review_reasons':([reason] if level=='uncertain' else [])+(['存在未读取的下级回复'] if c.get('reply_comment_total',0) else []),
   'current_need_verified':False,'assigned_store':None,'store_match_status':'未核；地区原词、工作地、所问房源与来源门店分开，不用IP直接分配',
   'rule_version':'business-text-20261029-v2','review_method':'新增26条模型语义判读；结构与引用本地核验','human_confirmed':False,'send_authorized':False,'send_attempted':False,
   'source_file':rp.name,'source_sha256':sha(rp),'search_file_sha256':sha(sp)}
  new.append(row);allrows.append(row)
dbpath=B/'runtime/collection.sqlite3';db=sqlite3.connect(dbpath.as_uri()+'?mode=ro',uri=True);ledger_total=db.execute("select count(*) from entities where kind='comments'").fetchone()[0]
mother=next(x for x in load(W/'mothers/first50.json') if x['slot']==1);assert mother['user_approved']
for row in allrows:
 found=db.execute("select data from entities where kind='comments' and source_id=?",(row['comment_id'],)).fetchone();assert found,'Unregistered source not counted'
 actual=json.loads(found[0]);assert actual['text']==row['comment_text'] and str(actual['aweme_id'])==row['video_id'] and str(actual['user']['uid'])==row['customer_uid']
 obs=db.execute("select store_id,keyword from observations where stable_key=?",('comment:'+row['comment_id'],)).fetchall();assert any(k==row['source_keyword'] for st,k in obs)
 row.update(registration_state='verified_local_independent_ledger',ledger_keyword_association_verified=True,source_store_raw=row['source_store'],source_store='上海古北方隅服务公寓' if row['source_store']=='上海古北店' else row['source_store'])
 eligible=row['role']=='demand' and row['interest_at_comment'] in ['high','medium'] and not row.get('context_flags')
 row.update(mother_slot=1 if eligible else None,mother_reply_text=mother['template'] if eligible else None,
  reply_status='已认可母句本地套用，仅供审核；未核门店及当前需求，不入发送清单' if eligible else '暂缓；本人需求、联系边界或启动时机尚待核',
  reply_scope='仅接话母句，未声称已回答全部具体条件',reply_generation_model_calls=0)
assert len(allrows)==len({x['comment_id'] for x in allrows})==59
assert all(all(q in x['comment_text'] for q in x['evidence']) for x in allrows)
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allrows);(D/'classified-59.jsonl').write_text(packed,encoding='utf8')
(D/'increment-26.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in new),encoding='utf8')
groups=collections.defaultdict(list)
for x in allrows:groups[x['source_file']].append(x)
for name,xs in groups.items():
 pref=name.removesuffix('-comments-raw.json');p=B/f'{pref}-text-screening-registered-v2.jsonl';p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in xs),encoding='utf8')
 receipt={'source_file':name,'source_sha256':sha(B/name),'classified_unique_comments':len(xs),'ledger_registration_verified':True,'result_file':p.name,'result_sha256':sha(p),'rule_version':'business-text-20261029-v2','new_reply_generation_model_calls':0,'source_files_modified':False,'sent':0}
 (B/f'{pref}-text-screening-registered-receipt-v2.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
by_store=collections.defaultdict(list)
for x in allrows:by_store[x['source_store']].append(x)
summary={'snapshot_unique_comments':59,'added_classified_comments':26,'previous_classified_comments':33,'unique_customers':len({x['customer_uid'] for x in allrows}),
 'ledger_total_at_read':ledger_total,'snapshot_not_live_total':True,'ledger_all_59_verified':True,'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in allrows)),
 'increment_interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in new)),'by_source_store':{},'local_mother_drafts':sum(bool(x['mother_reply_text']) for x in allrows),
 'confirmed_assigned_stores':0,'can_send_now':0,'source_files_modified':False,'platform_calls':0,'actual_sent':0,'full_deep_context_verified':False}
lines=['# 抖音59条登记评论的增量意向分析','',
'本次固定快照59条，均已与独立账本评论标识、原文、作者、作品及关键词关联逐条核对：原33条沿用判读，新增26条逐条分析。不是持续采集的实时累计；本轮没有请求平台、停止采集或修改原始数据。','',
'|来源门店|已分析评论|高|中|低|待核|供给或讨论|确认适配本店|','|---|---:|---:|---:|---:|---:|---:|---:|']
for name,xs in by_store.items():
 c=collections.Counter(x['interest_at_comment'] for x in xs);summary['by_source_store'][name]={'comments':len(xs),**dict(c),'assigned_store_verified':0}
 lines.append(f'|{name}|{len(xs)}|{c["high"]}|{c["medium"]}|{c["low"]}|{c["uncertain"]}|{c["unrelated"]}|0|')
lines+=['','来源门店不是客户意向门店。例如杭州余杭来源内还有临平、钱江世纪城、景芳等目标或工作通勤范围；成都来源询问具体百草路房源，不代表已经接受高新西方隅的地址或条件。所有实际分配仍待核，时效和地区不混进兴趣强弱。','',
'已确认的本人中高需求仅本地套用已认可母句1，作为可审核接话稿，不代表房型、预算、费用、宠物或通勤条件已全部满足。原帖作者与评论者分开，供应房的配置不作本人需求。明确拒中介的联系边界单独保留；不机械删客户，也不绕过边界。','',
'仅保存文字和一级评论。评论下方回复、视频画面、空文本附件仍未读取；明年毕业后的计划不当现在找房。当前没有可直接发送名单。','']
for x in allrows:
 lines+=['────────','来源门店：'+x['source_store'],'原评论：'+(x['comment_text'] or '文字为空，附件未核'),'评论时间：'+x['published_at'],
  '意向：'+{'high':'高','medium':'中','low':'低（未来计划）','uncertain':'待核','unrelated':'供给或讨论，无明确本人新需求'}[x['interest_at_comment']],
  '需求池：'+('、'.join(x['topics']) or '未确认具体本人需求池'),'地区线索：'+str(x.get('target_region_reference') or x.get('queried_property_region') or '未明'),
  '依据：'+x['reason'],'待核与边界：'+'；'.join(x['context_flags']+x['review_reasons']+['当前需求及门店适配未核']),
  '本地母句审核稿：'+(x['mother_reply_text'] or '暂缓，不生成'),'状态：未发送。','']
(O/'59条登记评论、逐店意向与本地母句.md').write_text('\n'.join(lines),encoding='utf8')
(D/'summary-59.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
(B/'text-screening-current-summary.json').write_text(json.dumps(dict(summary,result_file=str(D/'classified-59.jsonl'),report_file=str(O/'59条登记评论、逐店意向与本地母句.md')),ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
