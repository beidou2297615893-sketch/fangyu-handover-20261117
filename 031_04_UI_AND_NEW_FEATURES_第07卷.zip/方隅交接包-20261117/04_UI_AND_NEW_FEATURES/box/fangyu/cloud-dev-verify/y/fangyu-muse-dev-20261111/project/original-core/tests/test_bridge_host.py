import sys, tempfile, unittest, json, urllib.request, urllib.error, threading, http.cookiejar, subprocess
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from bridge import KuaishouBridgeManager
from app import AppServer

class BridgeHostTests(unittest.TestCase):
    def test_private_host_auth_connections_and_shutdown(self):
        with tempfile.TemporaryDirectory() as directory:
            manager=KuaishouBridgeManager(directory,ROOT/'work/runtime/kuaishou-bridge',ROOT/'work/runtime/douyin-bridge')
            try:
                started=manager.start('tenant-a')
                config=json.loads((manager.root('tenant-a')/'config.json').read_text('utf-8'))
                self.assertEqual(manager.connections('tenant-a'),[])
                base='http://127.0.0.1:'+str(started['port'])
                with self.assertRaises(urllib.error.HTTPError) as denied:urllib.request.urlopen(base+'/api/health')
                self.assertEqual(denied.exception.code,401)
                request=urllib.request.Request(base+'/api/connect',json.dumps({'site':'kuaishou.com','url':'https://www.kuaishou.com/short-video/mock123','title':'本地模拟页面'}).encode(),headers={'Authorization':'Bearer '+config['bridge']['token'],'Content-Type':'application/json'})
                with urllib.request.urlopen(request) as response:connection=json.load(response)
                rows=manager.connections('tenant-a')
                self.assertEqual(rows[0]['id'],connection['connectionId']);self.assertTrue(rows[0]['alive'])
                second=manager.start('tenant-b');self.assertNotEqual(second['port'],started['port'])
                other=json.loads((manager.root('tenant-b')/'config.json').read_text('utf-8'))
                self.assertNotEqual(config['bridge']['token'],other['bridge']['token'])
                script=(manager.root('tenant-a')/started['script']).read_text('utf-8')
                self.assertIn(config['bridge']['token'],script)
                self.assertIn(str(started['port']),script)
            finally:manager.close()
            self.assertTrue(all(p.poll() is not None for p in manager.processes.values()))

class HostHttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.server=AppServer(('127.0.0.1',0),self.tmp.name)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base='http://127.0.0.1:'+str(self.server.server_port)
        self.client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def tearDown(self):
        self.server.shutdown();self.thread.join();self.server.bridge.close();self.server.kuaishou_bridge.close();self.server.server_close();self.tmp.cleanup()
    def call(self,action,data=None):
        request=urllib.request.Request(self.base+'/api',json.dumps({'action':action,'data':data or {}}).encode(),headers={'Content-Type':'application/json','X-Local-App':'1'})
        with self.client.open(request) as response:return json.load(response)
    def login(self):self.call('bootstrap',{'username':'host-test','password':'[REDACTED:assigned_secret]'})
    def test_public_image_and_traversal(self):
        with self.client.open(self.base+'/assets/login-apartment.png') as response:self.assertEqual(response.status,200)
        for path in ('/assets/../app.py','/assets/%2e%2e%2fapp.py','/assets/%5c..%5capp.py','/assets/image.svg'):
            with self.assertRaises(urllib.error.HTTPError) as blocked:self.client.open(self.base+path)
            self.assertIn(blocked.exception.code,(403,404))
    def test_only_help_embeds_same_origin(self):
        self.login()
        with self.client.open(self.base+'/help') as response:
            self.assertEqual(response.headers['X-Frame-Options'],'SAMEORIGIN')
            self.assertIn("frame-ancestors 'self'",response.headers['Content-Security-Policy'])
        with self.client.open(self.base+'/') as response:
            self.assertEqual(response.headers['X-Frame-Options'],'DENY')
            self.assertIn("frame-ancestors 'none'",response.headers['Content-Security-Policy'])
    def test_close_owned_jobs_stops_only_owned_child(self):
        child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],creationflags=0x08000000)
        unrelated=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],creationflags=0x08000000)
        event=threading.Event();self.server.core.sequences['qa-sequence']=event
        self.server.jobs['qa-login']={'process':child}
        try:
            self.server.close_owned_jobs()
            self.assertTrue(self.server.closing);self.assertTrue(event.is_set())
            self.assertIsNotNone(child.poll());self.assertIsNone(unrelated.poll())
            self.server.close_owned_jobs()
        finally:
            for proc in (child,unrelated):
                if proc.poll() is None:proc.terminate();proc.wait(timeout=5)
    def test_backup_folder_admin_fixed_path(self):
        self.login()
        with patch('app.os.startfile') as start:
            result=self.call('open_backup_folder',{'path':'C:/unexpected'})
            expected=str(Path(self.tmp.name).resolve()/'backups')
            self.assertEqual(result['path'],expected);start.assert_called_once_with(expected)
        self.call('logout')
        with self.assertRaises(urllib.error.HTTPError):self.call('open_backup_folder')
    def test_platform_routes_and_private_script(self):
        self.login()
        result=self.call('bridge_start',{'platform':'kuaishou'})
        self.assertEqual(result['platform'],'kuaishou')
        self.assertEqual(self.call('bridge_connections',{'platform':'kuaishou'}),[])
        with self.client.open(self.base+'/bridge-script?platform=kuaishou') as response:
            self.assertIn(b'const TOKEN = ',response.read())
        with self.assertRaises(urllib.error.HTTPError):self.call('bridge_start',{'platform':'unknown'})

if __name__=='__main__':unittest.main()
