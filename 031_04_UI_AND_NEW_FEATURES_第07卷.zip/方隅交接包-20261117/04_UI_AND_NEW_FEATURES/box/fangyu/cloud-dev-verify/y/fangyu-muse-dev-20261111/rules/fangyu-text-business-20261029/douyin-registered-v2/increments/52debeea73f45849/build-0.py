import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent;src=p/'shard-0.jsonl';rows=[json.loads(s) for s in src.read_text(encoding='utf-8-sig').splitlines()]
assert len(rows)==386
assert json.loads((p/'claim-0.json').read_text(encoding='utf-8-sig'))['owner']=='increment_a','仅允许本批已登记的负责人重建自己的结果'
ds={};ts={};rs={};os={};ms={};notes={}
def mark(role,interest,numbers,reason,state=None):
 for n in map(int,numbers.split()):
  assert n not in ds,(n,ds.get(n));ds[n]=(role,interest,reason,state or ('active_at_comment' if role=='demand' and interest not in ('uncertain','unrelated') else 'unknown'))
def note(n,s):notes.setdefault(n,[]).append(s)
def topic(n,pool,q,pol='ask',subject='own_demand',scope='本人原话中的问题或条件',source='comment'):
 ts.setdefault(n,[]).append(dict(pool=pool,quote=q,polarity=pol,subject=subject,condition_scope=scope,source=source))
def region(n,q,relation='desired',scope='本人明确提出的租住地区或范围',group='unknown',source='comment'):
 rs.setdefault(n,[]).append(dict(text=q,quote=q,relation=relation,condition_scope=scope,group_relation=group,source=source))
def other(n,q,subject='own_demand',pol='require',scope='本人明确条件，不强塞十池'):
 os.setdefault(n,[]).append(dict(quote=q,subject=subject,polarity=pol,condition_scope=scope,source='comment'))
def moment(n,q,role,subject='own_demand'):
 ms.setdefault(n,[]).append(dict(quote=q,time_role=role,subject=subject,source='comment',normalized=None,verification='保留原词，未将相对时间锚定到今天或推断当前状态'))
for i in range(1,5):exec(compile((p/f'review-0-part-{i}.py').read_text(encoding='utf-8'),str(p/f'review-0-part-{i}.py'),'exec'))
valid={int(x['review_key'][1:]) for x in rows}
for x in (ds,ts,rs,os,ms,notes):assert set(x)<=valid,('无效编号',set(x)-valid)
out=[]
for d in rows:
 n=int(d['review_key'][1:]);t=d['comment_text'] or '';gaps=list(notes.get(n,[]))
 if n in ds:role,interest,reason,state=ds[n]
 else:
  role='unknown';interest='uncertain';state='unknown'
  reason='评论为空，未读取画面，不能识别说话意图。' if not t else '本人短句所指对象、供需身份或当前租房目的未明确，须结合缺失上下文核对。'
  gaps.append(reason)
 if role=='unknown' and not gaps:gaps.append('本人供需角色、所指对象或当前需求仍需核实。')
 if role=='demand' and interest in ('high','medium','super_high'):gaps.append('评论时需求或询盘不等于当前仍在找；后续状态和实际承接条件未核实。')
 if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read'):gaps.append(f"有{d['deeper_reply_count_visible']}条可见深层回复未读取，不能推断后续结果。")
 if d.get('source_version_conflict'):gaps.append('来源版本存在冲突，需复核原始数据。')
 te=ts.get(n,[]);reg=rs.get(n,[]);tm=ms.get(n,[]);otherx=os.get(n,[])
 if role=='demand' and interest in ('high','medium','super_high'):
  if not any(x['relation'] in ('desired','preferred','accepted') for x in reg):gaps.append('本人租住目标地区未明确或仅提及参照地点；不能用来源门店或IP补全。')
  if not any(x['pool']=='价格预算' and x['polarity'] in ('require','prefer','accept') for x in te):gaps.append('本人预算未明确或仅询问他人报价，不能当成预算上限。')
 for e in te+reg+tm+otherx:
  s=e.get('source','comment'); origin=(d.get('post_body') or '') if s=='same_author_post' else t
  assert e['quote'] in origin,(n,e['quote'],s)
  if s=='same_author_post':assert d.get('post_author_same_as_commenter') is True and d.get('post_author_uid') and str(d['post_author_uid'])==str(d['customer_uid']),(n,'author')
 for e in tm:e['anchor_source']='comment_published_at_unix' if d.get('published_at_unix') else 'unknown';e['anchor_time']=d.get('published_at_unix')
 evidence=[t] if t else [];evidence_sources=[dict(source='comment',quote=t)] if t else []
 for e in te+reg:
  if e.get('source')=='same_author_post' and e['quote'] not in evidence:evidence.append(e['quote']);evidence_sources.append(dict(source='same_author_post',quote=e['quote']))
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],video_id=d['video_id'],published_at_unix=d.get('published_at_unix'),ip_location_raw=d.get('ip_location_raw'),role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(x['pool'] for x in te if x['subject']=='own_demand')),topic_evidence=te,possible_topics=[],target_regions=reg,time_mentions=tm,other_constraints=otherx,reason=reason,evidence=evidence,evidence_sources=evidence_sources,review_reasons=gaps,context_used=['comment','post_body'],media_context='未读取视频画面；文字叙述不是房源事实核验',reply_context='可见深层回复未读取' if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read') else '未读取深层回复',human_confirmed=False,current_need_verified=False,assigned_store=None,send_authorized=False))
assert len(out)==len(rows)==386
assert {(r['review_key'],r['comment_id'],r['customer_uid'],r['video_id']) for r in rows}=={(r['review_key'],r['comment_id'],r['customer_uid'],r['video_id']) for r in out}
poolset={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for d,x in zip(rows,out):
 assert len(x['evidence'])==len(x['evidence_sources'])
 for q,e in zip(x['evidence'],x['evidence_sources']):assert q==e['quote'] and q in ((d['post_body'] or '') if e['source']=='same_author_post' and d['post_author_same_as_commenter'] else (d['comment_text'] or ''))
 assert set(x['topics'])<=poolset and set(x['topics'])=={e['pool'] for e in x['topic_evidence'] if e['subject']=='own_demand'} and {e['pool'] for e in x['topic_evidence']}<=poolset
 assert not (x['role']=='unknown' and x['interest_at_comment']=='unrelated')
 assert x['current_need_verified'] is False and x['assigned_store'] is None and x['send_authorized'] is False
for i in range(4):
 chunk=out[i*100:(i+1)*100]
 (p/f'reviewed-0.part-{i+1}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in chunk),encoding='utf-8')
(p/'reviewed-0.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
v={'input_count':386,'output_count':386,'unique_review_keys':len({x['review_key'] for x in out}),'id_quadruples_equal':True,'evidence_and_quotes_verbatim':True,'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'role_counts':dict(collections.Counter(x['role'] for x in out)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in out)),'topic_counts_including_unresolved':dict(collections.Counter(y for x in out for y in x['topics'])),'topic_subject_counts':dict(collections.Counter(y['subject'] for x in out for y in x['topic_evidence'])),'needs_review_count':sum(bool(x['review_reasons']) for x in out),'deeper_replies_unread_count':sum(bool(x.get('deeper_reply_count_visible')) and not x.get('deeper_replies_read') for x in rows),'empty_comment_count':sum(not x['comment_text'] for x in rows),'video_frames_read':False,'human_confirmed':False,'current_need_verified':False,'send_authorized':False,'model_reference_not_gold':True}
(p/'validation-0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,ensure_ascii=False,indent=2))
