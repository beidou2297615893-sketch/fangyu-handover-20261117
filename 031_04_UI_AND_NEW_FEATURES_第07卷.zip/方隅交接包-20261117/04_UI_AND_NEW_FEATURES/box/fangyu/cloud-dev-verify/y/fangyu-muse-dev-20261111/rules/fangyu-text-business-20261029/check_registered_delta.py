"""Read-only registered-comment difference check; never freeze, classify, or send."""
from pathlib import Path
import json,sqlite3,hashlib,datetime

W=Path(__file__).resolve().parent
ROOT=W.parents[1]
B=ROOT/'work/fangyu-douyin-independent'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def write(p,data):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');tmp.replace(p)

pointer=read(B/'text-screening-current-summary.json')
assert sha(pointer['result_file'])==pointer['result_sha256']
done=set()
with Path(pointer['result_file']).open(encoding='utf-8') as f:
    for line in f:
        if not line.strip():continue
        cid=json.loads(line)['comment_id'];assert cid not in done;done.add(cid)
assert len(done)==pointer['snapshot_unique_comments']
policy_path=B/'runner-audit-myeaj720/runner-qualification-policy.json'
policy=read(policy_path);manual=set(policy['qualified_request_ids'])
db=sqlite3.connect((B/'runtime/collection.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)
db.execute('PRAGMA query_only=ON');db.execute('BEGIN');qualified=set()
try:
    for rid,spec,state in db.execute('SELECT request_id,spec,state FROM attempts'):
        s=json.loads(spec)
        if state!='parsed' or not isinstance(s,dict) or s.get('kind')!='comments':continue
        e=s.get('eligibility')
        if rid in manual or isinstance(e,dict) and e.get('state')=='eligible':
            if rid in manual:assert s['account_uid']==policy['account_uid']
            qualified.add(rid)
    keys={key for rid,key in db.execute("SELECT request_id,stable_key FROM observations WHERE kind='comments'") if rid in qualified}
    allids=set();raw=0
    for key,cid,data in db.execute("SELECT stable_key,source_id,data FROM entities WHERE kind='comments'"):
        raw+=1
        if key in keys:
            c=json.loads(data);assert cid==c['cid'] and isinstance(c['user']['uid'],str)
            assert cid not in allids;allids.add(cid)
finally:db.close()
assert done<=allids
pending=[];owners=[]
for mf in (W/'douyin-registered-v2/increments').glob('*/manifest.json'):
    folder=mf.parent;inp=folder/'input.jsonl'
    if not inp.exists():continue
    missing=set()
    with inp.open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                cid=json.loads(line)['comment_id']
                if cid not in done:missing.add(cid)
    if missing:
        item={'batch':folder.name,'remaining':len(missing)}
        for name in ['model-work-status.json','publish-owner.json','quality-gate.json']:
            path=folder/name
            if path.exists():
                x=read(path);item[name]={k:x.get(k) for k in ['state','owner','active','publication_allowed']}
        pending.append(item)
    op=folder/'publish-owner.json'
    if op.exists() and read(op).get('active'):owners.append({'batch':folder.name,'owner':read(op).get('owner')})
D=W/'region-brand-routing';c=read(D/'current.json');m=read(c['manifest'])
brand_source_matches=m['platforms']['douyin']['result_sha256']==pointer['result_sha256']
assert sha(c['manifest'])==c['manifest_sha256']
v=read(c['validation']);assert v.get('all_passed') and all(v['checks'].values())
wrapper=read(W/'当前双平台回复结果指针.json')
for p,f in c['results'].items():
    h=sha(f);assert h==c['result_sha256'].get(p,c['result_sha256'].get(Path(f).name))
    assert wrapper['platforms'][p]['reply_sidecar_sha256']==h
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
result={'checked_at':now,'platform':'douyin','eligible_registered_comments':len(allids),'all_registered_comments':raw,'out_of_scope_comments':raw-len(allids),'published_comments':len(done),'pending_registered_comments':len(allids-done),'new_comment_ids':sorted(allids-done),'result_sha256':pointer['result_sha256'],'policy_sha256':sha(policy_path),'source_open_mode':'sqlite_ro_query_only','source_database_modified':False,'platform_calls':0,'new_batch_frozen':False,'unpublished_frozen_batches':pending,'active_publication_owners':owners,'region_sidecar_hashes_verified':True,'brand_source_matches_latest_classification':brand_source_matches,'reply_consumption_pointer_matches':brand_source_matches and wrapper['platforms']['douyin']['classification_sha256']==pointer['result_sha256']}
write(W/'last-registered-delta-check.json',result)
state_path=W/'当前文本处理运行状态.json';state=read(state_path);state['last_registered_delta_check']=result
state['last_heartbeat_local_check']={'checked_at':now,'status':'new_registered_comments_pending' if result['new_comment_ids'] else 'no_new_eligible_registered_comments','canonical_and_brand_pointers_verified':result['reply_consumption_pointer_matches'],'unpublished_frozen_batches':len(pending),'active_publication_owners':len(owners),'notification':'quiet_ordinary_check','platform_calls':0}
write(state_path,state)
print(json.dumps({k:v for k,v in result.items() if k!='new_comment_ids'},ensure_ascii=False))
