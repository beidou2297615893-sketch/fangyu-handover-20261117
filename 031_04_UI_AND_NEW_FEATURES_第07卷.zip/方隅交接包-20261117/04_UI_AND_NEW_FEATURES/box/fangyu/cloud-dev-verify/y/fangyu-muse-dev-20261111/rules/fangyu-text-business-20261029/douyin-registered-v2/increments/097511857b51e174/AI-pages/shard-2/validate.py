import json, pathlib, collections, hashlib, datetime
import assemble
P=pathlib.Path(__file__).parent;ROOT=P.parent.parent
assemble.run()
task=assemble.TASK;source=assemble.SOURCE
rows=[json.loads(x) for x in (ROOT/'reviewed-new-2.jsonl').read_text(encoding='utf-8').splitlines()]
errors=[]
allowed={
'role':{'demand','supply','mixed','unknown','discussion'},
'demand_state':{'active_at_comment','future','ended','historical','unknown'},
'interest':{'super_high','high','medium','low','very_low','uncertain','unrelated'},
}
pol={'ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'}
subject={'own_demand','supply','current_home','other_person','unresolved'}
rel={'desired','preferred','accepted','excluded','work','current_home','offered','unresolved'}
time_roles={'move_in','viewing','lease_duration','search_start','other'}
slots={1,2,7,13,16,19,25,28,31,34,None}
keys=[r['review_key'] for r in rows];ids=[r['comment_id'] for r in rows]
expected=set(task['expected_review_keys'])
if len(rows)!=1869:errors.append('count')
if len(set(keys))!=len(keys) or set(keys)!=expected:errors.append('review_key_coverage')
if len(set(ids))!=len(ids) or set(ids)!={source[k]['comment_id'] for k in expected}:errors.append('comment_id_coverage')
if set(ids)&set(task['exclude_pilot_comment_ids']):errors.append('pilot_overlap')
quote_checks=0
for r in rows:
    k=r['review_key'];s=source[k];txt=s['comment_text']
    for field in ['comment_id','customer_uid','video_id','platform']:
        if r[field]!=s[field]:errors.append(k+':identity:'+field)
    for field,vals in allowed.items():
        if r[field] not in vals:errors.append(k+':enum:'+field)
    for name in ['topics','target_regions','time_mentions','other_constraints','possible_topics']:
        for a in r[name]:
            quote_checks+=1
            if a['quote'] not in txt:errors.append(k+':quote:'+name)
    for q in r['evidence']:
        quote_checks+=1
        if q not in txt:errors.append(k+':evidence')
    for q in r['contact_boundaries']:
        quote_checks+=1
        if isinstance(q,str) and q not in txt:errors.append(k+':contact_boundary_quote')
    for a in r['topics']:
        if a['pool'] not in assemble.POOLS or a['polarity'] not in pol or a['subject'] not in subject:errors.append(k+':topic_enum')
        if not a['condition_scope']:errors.append(k+':scope_missing')
    for a in r['target_regions']:
        if a['relation'] not in rel or a['group_relation'] not in {'AND','OR','unknown'}:errors.append(k+':region_enum')
    for a in r['time_mentions']:
        if a['time_role'] not in time_roles:errors.append(k+':time_enum')
        if a['normalized'] is not None:errors.append(k+':unexpected_normalized')
    plan=r['reply_plan']
    if plan['preferred_mother_slot'] not in slots:errors.append(k+':mother_slot')
    if plan['tone'] not in {'normal','serious'}:errors.append(k+':tone')
    if plan['contact_policy'] not in {'allow','identity_restricted','no_contact','unknown'}:errors.append(k+':contact_policy')
    if not isinstance(plan['generic_intro_suitable'],bool):errors.append(k+':generic_type')
    if r['role'] in {'discussion','supply'} and plan['generic_intro_suitable']:errors.append(k+':irrelevant_generic')
    if r['human_confirmed'] is not False or r['send_authorized'] is not False or r['store_assignment'] is not None:errors.append(k+':authorization')
    if r['role']=='unknown' and (r['interest']!='uncertain' or not r['needs_review']):errors.append(k+':unknown_not_retained')
    for q in s.get('contact_boundaries') or []:
        if q not in r['contact_boundaries']:errors.append(k+':boundary_lost')
    for q in s.get('context_flags') or []:
        if q not in r['context_flags']:errors.append(k+':context_flag_lost')
stats={name:dict(collections.Counter(r[name] for r in rows)) for name in ['role','demand_state','interest']}
stats['mother_slot']=dict(collections.Counter(str(r['reply_plan']['preferred_mother_slot']) for r in rows))
stats['contact_policy']=dict(collections.Counter(r['reply_plan']['contact_policy'] for r in rows))
stats['topics']=dict(collections.Counter(t['pool'] for r in rows for t in r['topics']))
stats['serious_tone']=sum(r['reply_plan']['tone']=='serious' for r in rows)
stats['needs_review']=sum(bool(r['needs_review']) for r in rows)
result={'shard':2,'expected_input_count':1869,'output_count':len(rows),'unique_review_keys':len(set(keys)),'unique_comment_ids':len(set(ids)),'id_set_equal':set(keys)==expected,'identity_fields_checked':['review_key','comment_id','customer_uid','video_id','platform'],'pilot_overlap_count':len(set(ids)&set(task['exclude_pilot_comment_ids'])),'quote_checks':quote_checks,'quote_error_count':sum('quote' in e or 'evidence' in e for e in errors),'enum_and_schema_validation':'PASS' if not errors else 'FAIL','errors':errors,'stats':stats,'source_sha256':hashlib.sha256(pathlib.Path(task['source_full_metadata_file']).read_bytes()).hexdigest(),'output_sha256':hashlib.sha256((ROOT/'reviewed-new-2.jsonl').read_bytes()).hexdigest(),'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'当前会话模型逐条语义初筛与细筛同轮完成；不是两次独立审核或人工金标；本地脚本仅结构扩展、原身份补齐、逐字证据及覆盖验证','human_confirmed':False,'send_authorized':False,'platform_calls':0}
(ROOT/'shard2-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
progress=json.loads((P/'progress.json').read_text(encoding='utf-8'));progress.update(status='complete' if not errors else 'validation_failed',validation_file=str(ROOT/'shard2-validation.json'),updated_at=result['completed_at_utc']);(P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'output_count':len(rows),'quote_checks':quote_checks,'errors':errors,'stats':stats},ensure_ascii=True))
if errors:raise SystemExit(1)
