import sys
sys.dont_write_bytecode=True
import pathlib,json,hashlib,copy,collections,importlib.util,datetime
from write_audit import B,OUT,PAGES,COMMENTS

ROOT=B.parents[2]
task=json.loads((B/'recall-audit/part-0/task.json').read_text(encoding='utf-8'))
expected=set(task['expected_review_keys'])
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
audit=[]
for i in (0,1):
    audit.extend(json.loads(s) for s in (B/f'recall-audit/part-0/page-{i:02}.audit.jsonl').read_text(encoding='utf-8').splitlines())
assert len(audit)==184 and len({r['review_key'] for r in audit})==184
assert {r['review_key'] for r in audit}==expected==set(COMMENTS)
primary={}
primary_sha={}
for source in task['primary_sources']:
    p=B/source['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest()
    assert actual==source['sha256']
    primary_sha[source['path']]=actual
    for line in p.read_text(encoding='utf-8').splitlines():
        row=json.loads(line)
        if row['review_key'] in expected:
            assert row['review_key'] not in primary
            primary[row['review_key']]=row
assert set(primary)==expected
merged=[]
identities=[]
quote_checks=0
for item in audit:
    key=item['review_key'];p=primary[key];c=COMMENTS[key]
    assert item['decision'] in ('keep','change') and isinstance(item['reason'],str) and item['reason']
    assert isinstance(item['patch'],dict) and set(item['patch'])<=allowed
    if item['decision']=='keep':assert item['patch']=={}
    else:assert item['patch']
    for f,v in c['first_semantic_judgment'].items():assert p[f]==v,(key,f,'input first judgment differs from primary')
    m=copy.deepcopy(p);m.update(copy.deepcopy(item['patch']))
    assert all(m[f]==p[f] for f in ('review_key','platform','comment_id','customer_uid','video_id'))
    assert m['platform']=='douyin' and m['human_confirmed'] is False and m['send_authorized'] is False and m['store_assignment'] is None
    assert all(m[f] for f in ('review_key','comment_id','customer_uid','video_id'))
    identities.append(tuple(m[f] for f in ('review_key','comment_id','customer_uid','video_id')))
    source_text=c['text']
    # 本分片无同作者正文引用；逐字证据只允许当前原评论。
    assert c['same_author'] is False
    for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
        for val in m[field]:
            if isinstance(val,dict) and 'quote' in val:
                assert val['quote'] in source_text,(key,field,val['quote'])
                quote_checks+=1
    for val in m['evidence']:
        assert isinstance(val,str) and val in source_text,(key,'evidence',val)
        quote_checks+=1
    assert set(m['context_used'])<=set(('own','title','parent','body'))
    assert m['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
    assert m['reply_plan']['contact_policy'] in ('allow','identity_restricted','no_contact','unknown')
    merged.append(m)
assert len(set(i[1] for i in identities))==184

def dump(path,rows):
    path.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows),encoding='utf-8')

# 真实语义合并结果，先保留无编译兼容元数据字节，再仅在隔离文件添加预检所需来源信息。
dump(OUT/'semantic-merged-before-transport.jsonl',merged)
for m in merged:
    m['classification_method']='ai_independent_semantic_fine_review'
    m['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic']
source=OUT/'isolated-semantic-review.jsonl';dump(source,merged)
sha=hashlib.sha256(source.read_bytes()).hexdigest()
validated=[];cache={}
spec=importlib.util.spec_from_file_location('readonly_mother_adapter',ROOT/'mother_adapter.py')
adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
for m in merged:
    row=copy.deepcopy(m)
    row['classification_review_source']={'path':source.relative_to(B).as_posix(),'sha256':sha}
    adapter.validate_new_review(row,B,cache)
    validated.append(row)
dump(OUT/'isolated-validated-review.jsonl',validated)
summary={
 'status':'passed','records':184,'audit_records':len(audit),'keep':sum(a['decision']=='keep' for a in audit),'change':sum(a['decision']=='change' for a in audit),
 'changed_keys':[a['review_key'] for a in audit if a['decision']=='change'],
 'review_key_sets_equal':True,'comment_id_unique':True,'identity_fields_unchanged':True,
 'first_judgment_matches_primary':True,'primary_sha256_verified':primary_sha,
 'verbatim_quote_and_evidence_checks':quote_checks,'quote_errors':0,
 'adapter':'mother_adapter.validate_new_review','adapter_rows_passed':len(validated),
 'isolated_semantic_source_sha256':sha,
 'isolated_validated_sha256':hashlib.sha256((OUT/'isolated-validated-review.jsonl').read_bytes()).hexdigest(),
 'semantic_before_transport_sha256':hashlib.sha256((OUT/'semantic-merged-before-transport.jsonl').read_bytes()).hexdigest(),
 'formal_primary_modified':False,'formal_compiler_binding_done':False,
 'human_confirmed':False,'send_authorized':False,'usage':'unknown',
 'limitations':['仅本分片184条单次独立模型语义复核，不是用户金标或独立多轮审核','未读取视频画面或未提供深层回复，不确认今日需求及房源事实','隔离结构预检通过不等于正式编译发布绑定或发送许可']}
(OUT/'validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
progress=json.loads((OUT/'progress.json').read_text(encoding='utf-8'))
progress.update(status='complete',validation_status='passed',validated_records=184,changes=summary['change'],usage='unknown')
(OUT/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'report.md').write_text('''# 分片独立语义复核结果

完成两页184条：保留180条、变更4条。逐条读取共享正文、原评论、发表时间和初判；每个键显式给出保留或变更，没有程序默认未读保留。

- D0076：艾特、问号和尬笑用途不明，改为未知待核，不认定无关，不出推介。
- D0089：请求公司地点路线未确认住宅找房行动，改为未知待核并清除推介候选。
- D0288：裸户型与金额供需归属不明，改为未知待核，不当确定讨论、预算或供给。
- D0405：金融街可能是通勤终点或居住目标，地区关系改为未定，保留明确求租及一小时内通勤和预算条件。

原primary与补丁合并后，184个review_key完整相等，评论ID唯一，账号和视频身份保留；逐字证据检查及现有mother_adapter.validate_new_review隔离真实JSONL、SHA预检全部通过。没有更改正式primary、adapter或总状态，没有平台、账号、凭据、发送或新采集操作。

这是一次独立模型复核，不是人工认可或独立多轮；不确认今日需求、当前房源及优惠。仅隔离结构预检，正式编译绑定由主代理执行。usage未知。
''',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=True))
