import json,copy,hashlib,sys
from pathlib import Path
W=Path(__file__).resolve().parent;B=W.parent;T=B.parents[2]
sys.path.insert(0,str(T))
import mother_adapter
def read(p):return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
task=json.loads((B/'recall-audit/part-1/task.json').read_text(encoding='utf-8-sig'))
expected=task['expected_review_keys']; originals={}; hashes={}
for s in task['primary_sources']:
    p=B/s['path'];hashes[s['path']]=digest(p);assert hashes[s['path']]==s['sha256']
    for r in read(p):
        if r['review_key'] in expected:
            assert r['review_key'] not in originals
            originals[r['review_key']]=r
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
all_audits=[]; texts={};inputs={};page_results=[];quotation_errors=[]
for n in range(2):
    p=B/f'recall-audit/part-1/page-{n:02d}.json'; data=json.loads(p.read_text(encoding='utf-8-sig'))
    cs=[c for g in data['post_groups'] for c in g['comments']]
    aa=read(p.with_suffix('.audit.jsonl'))
    assert len(aa)==len(cs) and [a['review_key'] for a in aa]==[c['key'] for c in cs]
    for g in data['post_groups']:
        for c in g['comments']:
            key=c['key'];assert key not in texts
            texts[key]=[c['text']]+([g['post_body']] if c['same_author'] else [])
            inputs[key]=c
            for field,value in c['first_semantic_judgment'].items():assert originals[key][field]==value,(key,field,'primary-page mismatch')
    for a in aa:
        assert set(a)=={'review_key','decision','reason','patch'}
        assert a['decision'] in ('keep','change') and a['reason'].strip()
        assert set(a['patch'])<=allowed
        assert (a['patch']=={})==(a['decision']=='keep')
    all_audits+=aa
    page_results.append({'page':n,'input':len(cs),'output':len(aa),'id_set_equal':True,'keep':sum(a['decision']=='keep' for a in aa),'change':sum(a['decision']=='change' for a in aa),'audit_sha256':digest(p.with_suffix('.audit.jsonl')),'input_sha256':digest(p)})
assert len(all_audits)==len(expected)==len(set(a['review_key'] for a in all_audits))==184
assert set(originals)==set(expected)==set(texts)==set(a['review_key'] for a in all_audits)
patched={k:copy.deepcopy(v) for k,v in originals.items()}
for a in all_audits:patched[a['review_key']].update(a['patch'])
formal_results={};source_files={}
for label,rows in [('original',originals),('patched',patched)]:
    prepared=[]
    for key in expected:
        r=copy.deepcopy(rows[key])
        assert all(r[x]==originals[key][x] for x in ['review_key','comment_id','customer_uid','platform','video_id'])
        assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
        assert r['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
        quotes=[]
        for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
            for v in r[f]:
                if isinstance(v,dict) and 'quote' in v:quotes.append((f,v['quote']))
        quotes += [('evidence',v) for v in r['evidence']]
        for f,q in quotes:
            if not isinstance(q,str) or not any(q in t for t in texts[key]):quotation_errors.append([label,key,f,q])
        r['classification_method']='ai_independent_semantic_fine_review' if label=='patched' else 'ai_semantic_initial_and_detailed'
        r['classification_stages_completed']=mother_adapter.REVIEW_METHOD_STAGES[r['classification_method']]
        r.pop('classification_review_source',None)
        prepared.append(r)
    source=W/f'{label}-isolated-semantic.jsonl'
    source.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in prepared),encoding='utf-8')
    sha=digest(source);source_files[label]={'path':str(source.relative_to(B)),'sha256':sha}
    cache={};errors=[]
    for r in prepared:
        candidate=copy.deepcopy(r);candidate['classification_review_source']=source_files[label]
        try:mother_adapter.validate_new_review(candidate,B,cache)
        except Exception as e:errors.append(str(e))
    formal_results[label]={'records':len(prepared),'passed':len(prepared)-len(errors),'errors':errors,'uses_actual_jsonl_and_sha256':True}
assert not quotation_errors,quotation_errors
assert all(not x['errors'] for x in formal_results.values()),formal_results
for p in page_results:
    progress=W/f"page-{p['page']:02d}.progress.json";d=json.loads(progress.read_text(encoding='utf-8'));d['formal_validation']='passed';progress.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
result={'records':184,'keep':sum(a['decision']=='keep' for a in all_audits),'change':sum(a['decision']=='change' for a in all_audits),'pages':page_results,'id_set_equal':True,'preserved_identifiers':True,'quotation_errors':quotation_errors,'formal_adapter':str(Path(mother_adapter.__file__).resolve()),'formal_adapter_sha256':digest(Path(mother_adapter.__file__)),'formal_validation':formal_results,'isolated_sources':source_files,'unchanged_primary_sha256':hashes,'usage':'unknown','human_confirmed':False,'send_authorized':False,'limitations':['仅本分片184条一次独立模型语义复核，不是人工金标或多轮人工认可','只据提供正文与原评论判读，未读取平台、深层回复或账号信息','评论时意向不是今日仍有效，门店报价、政策、房态及推荐资格待核','隔离文件编译元数据只用于正式结构预检；正式合并和发布绑定由主任务处理']}
(W/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
report=f"本分片独立语义复核完成：184条，保留{result['keep']}条、修订{result['change']}条。\n\n两页完整ID集合一致，原始身份字段保留；引文逐字核对0错误。正式 mother_adapter.validate_new_review 对原判断184条和合并patch后184条分别通过，均读取隔离真实JSONL并核SHA256。未修改primary、adapter或总状态。\n\n修订主要为：未来才换房的低优先级、商城路短询与马尾有人租的身份歧义、杭州查询地不冒充居住目标、短租时间角色遗漏、11条专项母句的同一房源条件事实缺口。\n\n限制：单次独立模型复核，不是人工认可或多轮复核；未读平台或深层回复，不能确认今日需求、真实报价与政策。未生成回复正文、未发送。模型usage/credits实际消耗未知。\n"
(W/'report.md').write_text(report,encoding='utf-8')
print(json.dumps({'records':184,'keep':result['keep'],'change':result['change'],'formal_validation':formal_results,'quotation_errors':quotation_errors},ensure_ascii=False))
