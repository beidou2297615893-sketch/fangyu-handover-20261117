import collections,hashlib,json,sys,unittest,io
from datetime import datetime,timezone
from pathlib import Path
import business_fit
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
sys.path.insert(0,str(WORK/'recency-priority'))
import recency
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(l) for l in Path(p).read_text(encoding='utf-8-sig').splitlines() if l]
tests=unittest.TestSuite()
for folder,pattern in [(HERE,'test_business_fit.py'),(WORK/'douyin-semantic-repair-v5','test_semantic_guard.py')]:
 tests.addTests(unittest.defaultTestLoader.discover(str(folder),pattern=pattern,top_level_dir=str(folder)))
log=io.StringIO();run=unittest.TextTestRunner(stream=log,verbosity=2).run(tests)
(HERE/'test-results.txt').write_text(log.getvalue(),encoding='utf-8')
assert run.wasSuccessful(),log.getvalue()
code_sha=sha(HERE/'business_fit.py')
report={'checked_at':datetime.now(timezone.utc).isoformat(),'tests':{'methods':run.testsRun,'failures':len(run.failures),'errors':len(run.errors),'log':str(HERE/'test-results.txt')},'shared_code_sha256':code_sha,'platforms':{},'platform_requests':0,'source_database_writes':0,'ledger_writes':0,'full_AI_reanalysis':False}
mandatory={'7632500230256739091','7650190525278307115','7661993310910759717','7686676112985965347','7693933991636927281','7653728802602550074','7654049346787033919'}
for platform,mp,qp in [('douyin',WORK/'douyin-semantic-repair-v5/manifest.json',WORK/'douyin-semantic-repair-v5/pending-candidates.jsonl'),('xiaohongshu',WORK/'recency-priority/xiaohongshu-source-priority-report.json',WORK/'recency-priority/xiaohongshu-pending-by-source-and-recency.jsonl')]:
 m=load(mp);cf=m['commercial_fit'];assert cf['code_sha256']==code_sha,(platform,'stale shared module')
 all_path=Path(cf['all_pool_file']);assert sha(all_path)==cf['all_pool_sha256']
 all_rows=rows(all_path);pending=rows(qp)
 if platform=='douyin':assert sha(m['output'])==m['output_sha256']
 else:assert sha(qp)==m['sha256']
 assert len(all_rows)==cf['all_pool_records']
 for r in pending:
  fit=r['commercial_fit'];assert fit['eligible_candidate'] and not fit['eligible_priority'],(platform,r['comment_id'])
  assert fit['budget']['state'] not in ('below_3000','budget_3000_3999_unverified')
  assert not fit['exclusion_reasons']
  assert not (r.get('delivery') or {}).get('excluded_from_pending')
  assert not r.get('actual_send_authorized')
 if platform=='douyin':assert [r['comment_id'] for r in sorted(pending,key=recency.key)]==[r['comment_id'] for r in pending]
 reasons=collections.Counter(x for r in all_rows for x in r['commercial_fit']['exclusion_reasons'])
 holds=collections.Counter(x for r in all_rows for x in r['commercial_fit']['verification_required'])
 bands=collections.Counter(recency.BANDS[recency.key(r)[0]] for r in pending)
 sampled=[dict(comment_id=r['comment_id'],comment_text=r.get('comment_text'),fit=r['commercial_fit']) for r in all_rows if r['comment_id'] in mandatory]
 assert not any(r['comment_id'] in mandatory for r in pending),(platform,'mandatory low/ambiguous test record leaked')
 report['platforms'][platform]={'all_pool_records':len(all_rows),'all_pool_file':str(all_path),'all_pool_sha256':sha(all_path),'pending_file':str(qp),'pending_sha256':sha(qp),'pending_records':len(pending),'commercial_fit_counts':dict(collections.Counter(r['commercial_fit']['commercial_fit'] for r in all_rows)),'budget_state_counts':dict(collections.Counter(r['commercial_fit']['budget']['state'] for r in all_rows)),'exclusion_reason_counts':dict(reasons),'verification_reason_counts':dict(holds),'pending_time_bands':dict(bands),'mandatory_real_comments':sampled,'no_old_age_automatic_discard':True,'text_missing':sum('original_comment_text_missing' in r['commercial_fit']['verification_required'] for r in all_rows)}
out=HERE/'rescreen-verification.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
