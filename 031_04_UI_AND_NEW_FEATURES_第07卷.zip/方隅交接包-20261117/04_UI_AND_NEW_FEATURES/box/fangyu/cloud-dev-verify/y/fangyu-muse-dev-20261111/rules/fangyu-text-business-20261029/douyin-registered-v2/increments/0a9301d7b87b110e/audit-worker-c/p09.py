from decisions import *
j=original(9,'D2520'); ts=j['topics'][:1]
emit(9,'''D2466 D2468 D2470 D2472 D2474 D2476 D2478 D2480 D2482 D2484 D2686 D2688 D2690 D2692 D2694 D2696 D2698 D2700 D2702 D2487 D2489 D2491 D2493 D2495 D2497 D2499 D2501 D2503 D2506 D2726 D2728 D2508 D2510 D2512 D2514 D2516 D2518 D2522 D2524 D2730 D2732 D2527 D2529 D2531 D2533 D2535 D2537 D2539 D2541 D2543 D2553 D2559 D2561 D2563 D2565 D2567 D2569 D2571 D2575 D2577 D2581 D2583 D2585 D2587 D2590 D2592 D2595 D2598 D2602 D2607 D2611 D2616 D2618 D2620 D2622 D2624 D2626 D2628 D2630 D2632 D2634 D2636 D2638 D2640 D2642 D2644 D2646 D2648 D2650 D2652 D2654 D2656 D2660 D2662 D2664 D2666 D2668 D2670 D2672 D2674 D2676 D2678 D2680 D2682 D2684 D2706 D2708 D2710 D2712 D2714 D2716 D2718 D2720 D2722 D2724''',{
'D2704':('分享帖问租金体现关注，尚不足认定正在推进找房；补具体待核。',dict(demand_state='unknown',needs_review=['本人是否在找房或仅询问博主现居租金待核'])),
'D2520':('只要别太差是房屋整体品质下限，不是户型要求。',dict(topics=ts,other_constraints=[dict(quote='只要别太差就行',detail='房屋整体品质下限未量化，不能补成具体户型面积')],reason='本人明确求租并接受约一小时通勤，房屋别太差保留为品质约束')),
'D2573':('纯问号未能辨明含义，不应确定为无关价格评论。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='纯问号意图不明，保留待核',needs_review=['问号指代内容及是否本人住房需求不明'],reply_plan=plan(contact='unknown'))),
'D2579':('杭州是所询原帖位置，未自报愿租杭州；目标关系待核。',dict(target_regions=[reg('杭州',relation='unresolved')],needs_review=['询问AI辨认原帖地点，是否本人求租及接受杭州待核'])),
'D2658':('讨论燃气使用偏好，没有找房或询房动作，不作确定本人求租条件。',dict(role='discussion',demand_state='unknown',interest='unrelated',topics=[],reason='对他人看房内容讨论燃气安全与个人生活偏好，未表达新租赁需求',needs_review=[],reply_plan=plan()))
})
