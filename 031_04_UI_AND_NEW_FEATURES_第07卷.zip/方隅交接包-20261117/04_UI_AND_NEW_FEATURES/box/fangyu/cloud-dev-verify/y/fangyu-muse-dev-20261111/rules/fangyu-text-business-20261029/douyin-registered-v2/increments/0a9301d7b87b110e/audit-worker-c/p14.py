from decisions import *
j=original(14,'D3898'); ts=j['topics'];
for t in ts:t['polarity']='fact'
r=original(14,'D4131')['target_regions'];r[1]['relation']='unresolved'
r2=original(14,'D4028')['target_regions'];r2[1]['relation']='unresolved'
r3=original(14,'D3911')['target_regions']+[reg('地铁7号线',quote='地铁7号线',relation='accepted',group='OR',scope='成华区内，7号线或8号线择一'),reg('8号线',quote='8号线',relation='accepted',group='OR',scope='成华区内，7号线或8号线择一')]
emit(14,'''D3867 D3869 D4011 D4014 D4017 D4019 D4021 D4025 D3872 D3874 D3876 D3878 D3880 D3882 D3884 D3886 D3889 D3891 D4030 D4032 D4034 D4036 D4038 D4040 D4042 D4044 D4046 D4048 D3893 D3896 D3900 D3902 D3905 D3909 D3913 D3916 D3919 D4053 D4057 D4060 D4062 D4064 D4066 D4068 D3929 D3931 D3934 D3937 D3939 D3941 D3943 D3948 D4101 D3950 D3952 D3954 D3956 D3958 D3960 D3962 D3964 D3966 D3968 D4121 D4123 D4125 D4127 D4129 D4133 D4135 D4137 D4139 D3970 D3972 D3974 D3976 D3978 D3980 D3982 D3984 D3986 D3988 D4141 D4143 D4145 D4147 D4149 D4151 D4153 D4155 D4157 D4159 D3990 D3992 D3994 D3996 D3998 D4000 D4002 D4004 D4006 D4008 D4073 D4076 D4078 D4080 D4082 D4084 D4086 D4088 D4091 D4094 D4118''',{
'D4023':('住院医院是临时住房的参照地点，不是工作地点；严肃月租需求保留。',dict(target_regions=[reg('北京大学第一医院',relation='desired',scope='住院相关临时住房选址参照，具体距院要求待核')],other_constraints=[dict(quote='在北京大学第一医院住院',detail='医疗住院相关临时居住，不能当医院工作；本人或家属入住主体待核')])),
'D4028':('新宫只是问合适与否，不能确认已接受。',dict(target_regions=r2,needs_review=['新宫是考虑中的选项，是否接受及通勤可行性待核；座位条件不能承诺'])),
'D3898':('金额户型为陈述不是问句，供给或现居仍待核。',dict(topics=ts,target_regions=[reg('武林门地铁口',relation='unresolved')])),
'D3907':('占用一下加地区户型没有明确出租动作，也可能本人求租，保留未知避免漏筛。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='牛王庙套二片段的供需方向未明',topics=[topic('户型面积与居住方式','套二',polarity='unknown',subject='unresolved')],target_regions=[reg('牛王庙',relation='unresolved')],needs_review=['占楼是发布套二房源还是寻求套二住房待核'],reply_plan=plan())),
'D3911':('七八号线均可的择一地区条件不能只放在主题而漏地域结构。',dict(target_regions=r3)),
'D3922':('找舍友合租有住房线索，但已持房招租或共同找房未明，不能确定高意向本人租赁。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='指定地点找女性合租伙伴，持房或另找房方向待核',topics=[topic('位置通勤','成华区东郊记忆附近',subject='unresolved'),topic('户型面积与居住方式','找女生舍友合租',polarity='require',subject='unresolved')],target_regions=[reg('成华区东郊记忆附近',relation='unresolved')],needs_review=['本人已有房源招女室友还是希望共同找房待核；保留女生合租要求'],reply_plan=plan())),
'D4131':('成都可住得舒服是比较，不足确认已接受成都作为目标。',dict(target_regions=r))
})
