"""Reconcile persisted completion receipts and explicitly claimed AI workers only."""
import json, os
from pathlib import Path
from datetime import datetime
W=Path(__file__).resolve().parent
B=W/'douyin-registered-v2/increments'
now=datetime.now().astimezone().isoformat()
def get(p): return json.loads(p.read_text(encoding='utf-8'))
def put(p,v):
    t=p.with_name(p.name+'.reconcile.tmp')
    t.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(t,p)
old=B/'097511857b51e174'
status=get(old/'model-work-status.json')
receipt=get(old/'semantic-compile-receipt.json')
assert receipt['AI_initial_and_detailed_complete']==5806 and (old/'summary.json').is_file()
status['previous_partial_status_preserved']={k:status.get(k) for k in ['dispatched_comments','completed_comments','remaining_not_dispatched','pilot_independent_fine_review','per_shard_completed','worker_owners']}
status.update(dispatched_comments=5806,completed_comments=5806,remaining_not_dispatched=0,pilot_independent_fine_review='complete',per_shard_completed={'0':1869,'1':1868,'2':1869},worker_owners={},independent_recall_reviewed=receipt['independent_recall_and_level_calibration_complete'],updated_at=now)
put(old/'model-work-status.json',status)
batch=B/'0a9301d7b87b110e';m=get(batch/'manifest.json')
workers={str(i):f'/root/resume_dy_ai_{i}' for i in range(3)}
assert m['new_comments']==7439 and not (batch/'summary.json').exists()
put(batch/'model-work-status.json',dict(state='AI_initial_and_detailed_in_progress',owner='/root',input_comments=7439,prior_published_comments=18215,dispatched_comments=7439,completed_model_records=0,worker_owners=workers,model='gpt-6.1-sol',reasoning_effort='high',authorization='existing_credits_authorized_small_pilot_then_continue',updated_at=now,completion_count_basis='validated_reviewed_new_files_only_not_unmaterialized_decisions',source_writes=0,platform_calls=0,actual_sent_by_text_task=0,task_specific_usage=None,recovery_note='No prior worker active at heartbeat inventory; resume from matching explicit page decisions, never duplicate active workers.'))
put(batch/'quality-gate.json',dict(state='await_AI_primary_then_targeted_independent_review',input_comments=7439,AI_initial_and_detailed_complete=0,independent_recall_required=True,independent_recall_calibration_queued=0,publication_allowed=False,platform_send_allowed=False,quality_requirement='All shard IDs/evidence/schema must match; then independently review ambiguous, negative, mixed, restricted and high-risk cases before publication.',updated_at=now))
state=get(W/'当前文本处理运行状态.json')
state['douyin'].update(processing_shards=workers,publication_gate=str(batch/'quality-gate.json'))
state['last_working_progress_check']=dict(checked_at=now,canonical_published_classified=18215,pending_frozen_comments=7439,validated_new_completed=0,worker_owners=workers,whole_frozen_batch_complete=False,source_total_not_rechecked=True,platform_calls=0)
state['last_increment_check']=dict(checked_at=now,eligible_snapshot_comments=25654,classified_comments=18215,pending_comments=7439,batch_directory=str(batch),source_database_modified=False,platform_calls=0,counts_from_existing_frozen_manifest=True)
put(W/'当前文本处理运行状态.json',state)
print(json.dumps({'published':18215,'frozen_pending':7439,'claims':workers,'platform_calls':0},ensure_ascii=False))
