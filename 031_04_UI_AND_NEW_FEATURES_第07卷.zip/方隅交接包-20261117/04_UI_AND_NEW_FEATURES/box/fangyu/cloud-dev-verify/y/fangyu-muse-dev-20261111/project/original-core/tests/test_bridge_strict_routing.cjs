const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {Router}=require('../work/runtime/douyin-bridge/lib/server/router');
(async()=>{
 for (const scenario of ['missing','closed','unspecified','wrong-site']) {
  let fallbackCalls=0,sends=0;
  const hub=new EventEmitter();hub.sendEval=()=>{sends++;throw Error('must not send')};
  const registry={getById:()=>scenario==='closed'?{ws:{readyState:3}}:null,get:()=>{fallbackCalls++;return {id:'other-live',ws:{readyState:1}}}};
  const router=new Router({registry,wsHub:hub,strictConnections:true,allowedSite:'douyin.com'});
  router._parseBody=async()=>({site:scenario==='wrong-site'?'other.com':'douyin.com',expression:'1',...(scenario==='unspecified'?{}:{connId:'chosen-offline'})});
  let code=0,body='';const res={writeHead:c=>code=c,end:b=>body=b};
  await router._call({},res);
  assert.equal(code,['missing','closed'].includes(scenario)?503:400,scenario);
  assert.equal(JSON.parse(body).ok,false);assert.equal(fallbackCalls,0);assert.equal(sends,0);
  assert.equal(router._pending.size,0);assert.equal(router._pollQueue.size,0);
 }
 console.log('PASS: 4 strict routing scenarios; no fallback, no send, no queued action');
})().catch(e=>{console.error(e);process.exitCode=1});
