import sys,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from desktop import run_desktop,focus_process_window

class Event:
    def __init__(self):self.handlers=[]
    def __iadd__(self,handler):self.handlers.append(handler);return self
    def emit(self,*args):return [handler(*args) for handler in self.handlers]

class DesktopTests(unittest.TestCase):
    def run_shell(self,renderer):
        stopped=threading.Event();calls=[]
        server=SimpleNamespace(closing=False,company={'id':'test'},serve_forever=lambda **kwargs:stopped.wait(3),shutdown=lambda:stopped.set())
        def close():server.closing=True;calls.append('owned-closed')
        server.close_owned_jobs=close
        window=SimpleNamespace(events=SimpleNamespace(initialized=Event(),closed=Event(),loaded=Event()),destroy=lambda:None)
        module=SimpleNamespace(settings={},create_window=lambda *args,**kw:(calls.append(('window',args,kw)) or window))
        def start(**kwargs):
            calls.append(('start',kwargs))
            if False in window.events.initialized.emit(renderer):return
            window.events.closed.emit()
        module.start=start
        with tempfile.TemporaryDirectory() as directory,patch.dict(sys.modules,{'webview':module}):
            if renderer=='edgechromium':run_desktop(server,'http://127.0.0.1:9999',directory,'独立桌面')
            else:
                with self.assertRaisesRegex(RuntimeError,'WebView2'):run_desktop(server,'http://127.0.0.1:9999',directory,'独立桌面')
        return calls,module
    def test_forces_edge_and_closes_owned_service(self):
        calls,module=self.run_shell('edgechromium')
        self.assertEqual(next(c for c in calls if isinstance(c,tuple) and c[0]=='start')[1]['gui'],'edgechromium')
        self.assertEqual(calls.count('owned-closed'),1);self.assertTrue(module.settings['ALLOW_DOWNLOADS'])
    def test_rejects_fallback_renderer_and_still_cleans(self):
        calls,_=self.run_shell('mshtml');self.assertEqual(calls.count('owned-closed'),1)
    def test_invalid_focus_pid_does_not_target_other_apps(self):
        self.assertFalse(focus_process_window(None));self.assertFalse(focus_process_window(0))

if __name__=='__main__':unittest.main()
