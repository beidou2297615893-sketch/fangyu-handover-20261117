import csv
import io
import sys
import tempfile
import unittest
import json
import os
import subprocess
import threading
import shutil
import zipfile
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from core import Core,CoreError
from core.adapters import Adapters, AdapterBusy

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.core=Core(self.tmp.name)
        self.auth=self.core.handle('bootstrap',{'username':'admin','password':'[REDACTED:assigned_secret]','company_name':'测试公寓'})
        self.user=self.auth['user']
    def tearDown(self): self.tmp.cleanup()
    def call(self,action,data=None,user=None): return self.core.handle(action,data,user or self.user)
    def save(self,entity,record,**kw): return self.call('save',{'entity':entity,'record':record,**kw})
    def test_auth_and_no_default(self):
        self.assertEqual(self.core.session(self.auth['token'])['username'],'admin')
        self.assertNotIn('password_hash',self.auth['user'])
        with self.assertRaises(CoreError): self.core.handle('login',{'username':'admin','password':'wrong'})
        self.core.handle('logout',{'token':self.auth['token']})
        self.assertIsNone(self.core.session(self.auth['token']))
    def test_tenant_isolation_and_privilege(self):
        employee=self.save('users',{'username':'worker','password':'[REDACTED:assigned_secret]','role':'operator'})
        other=self.save('tenants',{'name':'其他企业','industry':'food'})
        self.save('leads',{'source_id':'same','title':'其他企业数据'},tenant_id=other['id'])
        self.assertEqual(self.call('list',{'entity':'leads'},employee),[])
        with self.assertRaises(CoreError): self.call('list',{'entity':'leads','tenant_id':other['id']},employee)
        with self.assertRaises(CoreError): self.call('save',{'entity':'users','record':{'id':employee['id'],'role':'admin'}},employee)
    def test_dedupe_export_formula(self):
        value={'content':'platform,source_id,title\nxiaohongshu,123,=HYPERLINK(1)\n'}
        self.assertEqual(self.call('import_csv',value)['imported'],1)
        self.assertEqual(self.call('import_csv',value)['duplicates'],1)
        exported=self.call('export_csv')['content'].lstrip('\ufeff')
        self.assertTrue(next(csv.DictReader(io.StringIO(exported)))['title'].startswith("'="))
    def test_reply_review_and_dedupe(self):
        lead=self.save('leads',{'source_id':'123','title':'求租'})
        reply=self.call('draft_reply',{'lead_id':lead['id'],'text':'您好，方便确认一下区域吗？'})
        with self.assertRaises(CoreError): self.call('copy_reply',{'id':reply['id']})
        self.call('approve_reply',{'id':reply['id']}); self.call('copy_reply',{'id':reply['id']})
        with self.assertRaises(CoreError): self.call('mark_reply_sent',{'id':reply['id']})
        self.call('mark_reply_sent',{'id':reply['id'],'confirmed':True})
        with self.assertRaises(CoreError): self.call('draft_reply',{'lead_id':lead['id'],'text':'再发一次'})
    def test_blocked_not_success_and_demo_label(self):
        task=self.save('tasks',{'name':'测试','platform':'xiaohongshu','keywords':['租房'],'daily_limit':1})
        self.assertEqual(self.call('run_task',{'id':task['id']})['status'],'blocked')
        self.save('tasks',{'id':task['id'],'status':'ready'})
        self.assertEqual(self.call('run_task',{'id':task['id'],'demo':True})['status'],'demo')
        self.assertTrue(self.call('list',{'entity':'leads'})[0]['demo'])
        with self.assertRaises(CoreError): self.call('run_task',{'id':task['id'],'demo':True})
    def test_backup_restore_requires_password_and_revokes_sessions(self):
        backup=self.call('backup')['path']
        self.save('leads',{'source_id':'afterbackup'})
        with self.assertRaises(CoreError): self.call('restore',{'path':backup,'password':'wrong'})
        self.call('restore',{'path':backup,'password':'[REDACTED:assigned_secret]'})
        self.assertEqual(self.call('list',{'entity':'leads'}),[])
        self.assertIsNone(self.core.session(self.auth['token']))
    def test_unknown_region_date_are_not_guessed(self):
        account=self.save('accounts',{'name':'模拟账号','platform':'xiaohongshu','status':'ready'})
        task=self.save('tasks',{'name':'严格筛选','platform':'xiaohongshu','account_id':account['id'],'keywords':['租房'],'region':'上海','date_from':'2026-01-01','date_to':'2026-12-31','unknown_policy':'exclude'})
        self.core.adapters.search=lambda platform,task:[{'source_id':'unknown','title':'租房'},{'source_id':'valid','title':'租房','region':'上海','published_at':'2026-09-01'},{'source_id':'old','title':'租房','region':'上海','published_at':'2025-01-01'}]
        result=self.call('run_task',{'id':task['id']})
        self.assertEqual(result['imported'],1)
        self.assertEqual(self.call('list',{'entity':'leads'})[0]['source_id'],'valid')
    def test_cli_mapper_preserves_unknown_and_marks_unqualified(self):
        rows=Adapters.map_items({'ok':True,'data':{'items':[{'id':'note1','note_card':{'display_title':'公寓','user':{'nickname':'作者'}}}]}},'xhs_v1','xiaohongshu')
        self.assertEqual(rows[0]['source_id'],'note1')
        self.assertNotIn('region',rows[0]); self.assertNotIn('published_at',rows[0])
        self.assertIn('非已确认客户',rows[0]['stage'])
        with self.assertRaises(RuntimeError): Adapters.map_items({'data':{'unexpected':[]}},'xhs_v1','xiaohongshu')
    def test_search_mappers_never_classify_posts_as_high_intent(self):
        self.core.resources_dir=Path(__file__).resolve().parents[1]/'src'/'resources'
        xhs=Adapters.map_items({'data':{'items':[{'id':'xhs-intent','note_card':{'display_title':'预约看房预算','xsec_token':'card-token'}}]}},'xhs_v1','xiaohongshu')
        weibo=Adapters.map_items({'data':{'cards':[{'mblog':{'id':'weibo-intent','text':'预约看房预算','user':{'id':'u'}}}]}},'weibo_cards','weibo')
        self.assertIn('xsec_token=card-token',xhs[0]['url'])
        for row in xhs+weibo:
            self.assertEqual(row['source_type'],'note')
            lead=self.save('leads',row)
            self.assertEqual(lead['grade'],'C')
            self.assertIn('不能确认作者',lead['grade_reason'])
    def test_management_hidden_and_reply_status_locked(self):
        employee=self.save('users',{'username':'worker','password':'[REDACTED:assigned_secret]','role':'operator'})
        for entity in ('audit','users'):
            with self.assertRaises(CoreError): self.call('list',{'entity':entity},employee)
        lead=self.save('leads',{'source_id':'immutable'})
        with self.assertRaises(CoreError): self.save('leads',{'id':lead['id'],'reply_status':'sent'})
        self.call('import_csv',{'content':'source_id,reply_status\nold,sent\n'})
        imported=next(x for x in self.call('list',{'entity':'leads'}) if x['source_id']=='old')
        self.assertEqual(imported['reply_status'],'未回复')
        self.assertIn('未核实',imported['historical_reply_status'])
    def test_comments_map_nested_and_dates(self):
        rows=Adapters.map_comments({'ok':True,'data':{'comments':[{'id':'c1','content':'想租房','create_time':1700000000000,'ip_location':'上海','user_info':{'nickname':'张','user_id':'u1'},'sub_comments':[{'id':'c2','content':'同问'}]}]}},'https://www.xiaohongshu.com/explore/note')
        self.assertEqual(len(rows),2); self.assertEqual(rows[0]['comment_id'],'c1')
        self.assertTrue(rows[0]['published_at'].startswith('2023-'))
        self.assertEqual(rows[1]['region'],''); self.assertEqual(rows[1]['published_at'],'')
    def test_home_isolation_reaches_real_child_process(self):
        self.core.adapters.manifest=lambda platform:{'executable':sys.executable,'isolation_guard':True}
        directory=Path(self.tmp.name)/'accounts'/'a'
        spec=self.core.adapters.account_spec('xiaohongshu',directory,['-c','from pathlib import Path; print(Path.home())'])
        process=subprocess.run(spec['argv'],env={**os.environ,**spec['env']},capture_output=True,text=True,check=True)
        self.assertEqual(Path(process.stdout.strip()),directory.resolve())
        self.assertEqual(spec['env']['LEADSTUDIO_ISOLATED'],'1')
    def _approved_comment(self):
        account=self.save('accounts',{'name':'模拟','platform':'xiaohongshu','status':'ready','daily_send_limit':2})
        lead=self.save('leads',{'source_id':'comment:1','platform':'xiaohongshu','comment_id':'1','note_url':'https://www.xiaohongshu.com/explore/n','title':'求租'})
        reply=self.call('draft_reply',{'lead_id':lead['id'],'text':'测试正文'})
        self.call('approve_reply',{'id':reply['id']})
        self.core.adapters.manifest=lambda platform:{'reply_contract_verified':True,'isolation_guard':True}
        return account,lead,reply
    def test_send_requires_authorization_and_is_idempotent(self):
        account,lead,reply=self._approved_comment(); calls=[]
        self.core.adapters.send=lambda *args:calls.append(args) or {'success':True}
        data={'id':reply['id'],'account_id':account['id']}
        with self.assertRaises(CoreError): self.call('send_reply',data)
        data['authorized']=True
        self.assertEqual(self.call('send_reply',data)['status'],'sent')
        self.assertEqual(self.call('send_reply',data)['status'],'sent')
        self.assertEqual(len(calls),1)
        self.assertEqual(self.call('list',{'entity':'leads'})[0]['reply_status'],'sent')
    def test_send_unknown_is_never_retried(self):
        account,lead,reply=self._approved_comment(); calls=[]
        def failing(*args): calls.append(args); raise RuntimeError('网络中断')
        self.core.adapters.send=failing
        data={'id':reply['id'],'account_id':account['id'],'authorized':True}
        self.assertEqual(self.call('send_reply',data)['status'],'unknown')
        with self.assertRaises(CoreError): self.call('send_reply',data)
        self.assertEqual(len(calls),1)
    def test_industry_rules_and_template_draft(self):
        self.core.resources_dir=Path(__file__).resolve().parents[1]/'src'/'resources'
        lead=self.save('leads',{'source_id':'comment:rules','text':'明天预约看房预算三千','source_type':'comment'})
        self.assertEqual(lead['grade'],'A'); self.assertIn('规则判断',lead['grade_reason'])
        reply=self.call('suggest_reply',{'lead_id':lead['id']})
        self.assertEqual(reply['status'],'draft'); self.assertIn('测试公寓',reply['text'])
        note=self.save('leads',{'source_id':'note:rules','text':'明天预约看房预算三千','source_type':'note'})
        self.assertEqual(note['grade'],'C')
    def test_assets_cannot_cross_tenants(self):
        other=Path(self.tmp.name)/'assets'/'other'; other.mkdir(parents=True)
        (other/'a.txt').write_text('other')
        with self.assertRaises(CoreError): self.save('assets',{'name':'a','path':str(other/'a.txt')})
        own=Path(self.tmp.name)/'assets'/self.user['tenant_id']; own.mkdir(parents=True)
        (own/'a.txt').write_text('own')
        self.assertEqual(self.save('assets',{'name':'a','path':str(own/'a.txt')})['name'],'a')
    def test_pagination_persists_and_dedupes_target(self):
        account=self.save('accounts',{'name':'模拟','platform':'xiaohongshu','status':'ready'})
        task=self.save('tasks',{'name':'分页','platform':'xiaohongshu','account_id':account['id'],'target_count':3,'daily_limit':5})
        pages=[]
        def search(platform,task):
            pages.append(task['next_page']); task['_page_info']={'has_more':True}
            return [{'source_id':'a','title':'候选'},{'source_id':'b' if task['next_page']==1 else 'c','title':'候选'}]
        self.core.adapters.search=search
        first=self.call('run_task',{'id':task['id']}); second=self.call('run_task',{'id':task['id']})
        self.assertEqual(pages,[1,2]); self.assertEqual(second['accumulated'],3); self.assertEqual(second['duplicates'],1)
        with self.assertRaises(CoreError): self.call('run_task',{'id':task['id']})
    def test_crashed_sending_becomes_unknown(self):
        account,lead,reply=self._approved_comment()
        record=self.core.store.get('replies',reply['id']); record['status']='sending'; self.core.store.put('replies',record)
        restored=Core(self.tmp.name)
        self.assertEqual(restored.store.get('replies',reply['id'])['status'],'unknown')
    def test_bridge_requires_explicit_connection_and_uses_tenant_config(self):
        account=self.save('accounts',{'name':'抖音窗口','platform':'douyin','status':'ready'})
        task=self.save('tasks',{'name':'抖音','platform':'douyin','account_id':account['id']})
        self.assertEqual(self.call('run_task',{'id':task['id']})['status'],'blocked')
        self.assertIn('明确',self.core.store.get('tasks',task['id'])['last_message'])
        self.core.adapters.manifest=lambda p:{'executable':sys.executable,'isolation_guard':True}
        config=Path(self.tmp.name)/'bridge'/self.user['tenant_id']; config.mkdir(parents=True); (config/'config.json').write_text('{}')
        account_dir=Path(self.tmp.name)/'accounts'/self.user['tenant_id']/account['id']
        spec=self.core.adapters.account_spec('douyin',account_dir,['help'])
        self.assertEqual(Path(spec['env']['DOUYIN_CONFIG']),config/'config.json')
    def test_template_variables_block_server_side(self):
        lead=self.save('leads',{'source_id':'var'})
        reply=self.call('draft_reply',{'lead_id':lead['id'],'text':'您好，{租金}元'})
        with self.assertRaises(CoreError): self.call('approve_reply',{'id':reply['id']})
        raw=self.core.store.get('replies',reply['id']); raw['status']='approved'; self.core.store.put('replies',raw)
        with self.assertRaises(CoreError): self.call('copy_reply',{'id':reply['id']})
    def test_employee_daily_limit_and_company_employee_limit(self):
        self.save('users',{'id':self.user['id'],'daily_send_limit':1})
        for index in range(2):
            lead=self.save('leads',{'source_id':'manual'+str(index)})
            reply=self.call('draft_reply',{'lead_id':lead['id'],'text':'您好'})
            self.call('approve_reply',{'id':reply['id']})
            if index==0:
                self.call('copy_reply',{'id':reply['id']}); self.call('mark_reply_sent',{'id':reply['id'],'confirmed':True})
            else:
                with self.assertRaises(CoreError): self.call('copy_reply',{'id':reply['id']})
        tenant=self.core.store.get('tenants',self.user['tenant_id']); tenant['business_rules']={'employeeLimit':1}; self.core.store.put('tenants',tenant)
        with self.assertRaises(CoreError): self.save('users',{'username':'extra','password':'[REDACTED:assigned_secret]','role':'operator'})
    def test_approved_queue_stops_on_unknown(self):
        account,lead,first=self._approved_comment()
        other=self.save('leads',{'source_id':'comment:2','platform':'xiaohongshu','comment_id':'2','note_url':'https://www.xiaohongshu.com/explore/n'})
        second=self.call('draft_reply',{'lead_id':other['id'],'text':'第二条'})
        self.call('approve_reply',{'id':second['id']}); calls=[]
        def failing(*args): calls.append(args); raise RuntimeError('未知结果')
        self.core.adapters.send=failing
        with self.assertRaises(CoreError): self.call('run_reply_queue',{'reply_ids':[first['id'],second['id']],'account_id':account['id']})
        queue=self.call('run_reply_queue',{'reply_ids':[first['id'],second['id']],'account_id':account['id'],'authorized':True})
        self.assertEqual(queue['status'],'stopped'); self.assertEqual(len(calls),1)
        self.assertEqual(self.core.store.get('replies',second['id'])['status'],'approved')
    def test_industry_change_replaces_rules_not_old_templates(self):
        self.core.resources_dir=Path(__file__).resolve().parents[1]/'src'/'resources'
        self.save('templates',{'name':'公寓旧模板','text':'旧公寓回复','keywords':['订位']})
        tenant=self.save('tenants',{'id':self.user['tenant_id'],'industry':'restaurant'})
        self.assertEqual(tenant['business_rules']['industry'],'restaurant')
        lead=self.save('leads',{'source_id':'food','text':'想订位'})
        reply=self.call('suggest_reply',{'lead_id':lead['id']})
        self.assertNotIn('旧公寓',reply['text']); self.assertIn('用餐',reply['text'])
    def test_bulk_import_dedupes_and_store_transaction_rolls_back(self):
        content='platform,source_id,title\n'+''.join('xiaohongshu,batch%s,预算看房\n'%i for i in range(100))
        self.assertEqual(self.call('import_csv',{'content':content}),{'imported':100,'duplicates':0})
        self.assertEqual(self.call('import_csv',{'content':content}),{'imported':0,'duplicates':100})
        good=self.core._record({'platform':'xiaohongshu','source_id':'rollback-1'},self.user['tenant_id'])
        bad=self.core._record({'platform':'xiaohongshu','source_id':'rollback-2'},self.user['tenant_id'])
        bad['id']=good['id']
        with self.assertRaises(Exception): self.core.store.insert_leads([good,bad])
        self.assertIsNone(self.core.store.get('leads',good['id']))
        self.assertEqual(self.core.store.insert_leads([good]),1)
    def test_shared_bridge_channel_never_executes_concurrently(self):
        adapters=self.core.adapters; entered=threading.Event(); release=threading.Event(); active=[]
        def blocked(*args):
            active.append(1); entered.set(); release.wait(3); active.pop(); return []
        adapters._execute=blocked
        parent=Path(self.tmp.name)/'accounts'/'tenant'
        worker=threading.Thread(target=lambda:adapters.execute('douyin',['search','--conn-id','same'],parent/'account1'))
        worker.start()
        try:
            self.assertTrue(entered.wait(2))
            with self.assertRaises(AdapterBusy): adapters.execute('douyin',['post','--conn-id','same'],parent/'account2')
            self.assertEqual(len(active),1)
        finally: release.set(); worker.join(3)
        self.assertFalse(worker.is_alive())
    def test_busy_channel_does_not_claim_unknown_external_send(self):
        account,lead,reply=self._approved_comment()
        def busy(*args): raise AdapterBusy('账号忙，本次未执行')
        self.core.adapters.send=busy
        result=self.call('send_reply',{'id':reply['id'],'account_id':account['id'],'authorized':True})
        self.assertEqual(result['status'],'approved'); self.assertNotIn('attempted_at',result)
        self.assertEqual(self.core.store.get('accounts',account['id'])['status'],'ready')
    def test_disabled_and_reset_sessions_cannot_revive(self):
        employee=self.save('users',{'username':'employee','password':'[REDACTED:assigned_secret]','role':'operator'})
        token=self.core.handle('login',{'username':'employee','password':'[REDACTED:assigned_secret]'})['token']
        self.save('users',{'id':employee['id'],'disabled':True})
        self.assertIsNone(self.core.session(token))
        self.save('users',{'id':employee['id'],'disabled':False})
        self.assertIsNone(self.core.session(token))
        token=self.core.handle('login',{'username':'employee','password':'[REDACTED:assigned_secret]'})['token']
        self.save('users',{'id':employee['id'],'password':'[REDACTED:assigned_secret]'})
        self.assertIsNone(self.core.session(token))
        with self.assertRaises(CoreError): self.core.handle('login',{'username':'employee','password':'[REDACTED:assigned_secret]'})
        self.assertTrue(self.core.handle('login',{'username':'employee','password':'[REDACTED:assigned_secret]'})['token'])
    def test_portable_backup_restores_assets_in_new_workspace(self):
        folder=Path(self.tmp.name)/'assets'/self.user['tenant_id']; folder.mkdir(parents=True)
        material=folder/'公寓.txt'; material.write_text('真实素材内容',encoding='utf-8')
        asset=self.save('assets',{'name':'公寓资料','path':str(material)})
        account=self.save('accounts',{'name':'平台账号','platform':'xiaohongshu','status':'ready'})
        credentials=Path(self.tmp.name)/'accounts'/self.user['tenant_id']/account['id']; credentials.mkdir(parents=True)
        (credentials/'cookies.json').write_text('fake-test-credential')
        backup=self.call('backup')
        self.assertEqual(backup['asset_count'],1)
        with zipfile.ZipFile(backup['path']) as archive:
            self.assertFalse(any('cookies' in name or name.startswith('accounts/') for name in archive.namelist()))
        with tempfile.TemporaryDirectory() as destination:
            second=Core(destination)
            administrator=second.handle('bootstrap',{'username':'temporary','password':'[REDACTED:assigned_secret]'})['user']
            target=Path(destination)/'backups'; target.mkdir(); copied=target/Path(backup['path']).name; shutil.copyfile(backup['path'],copied)
            result=second.handle('restore',{'path':str(copied),'password':'[REDACTED:assigned_secret]'},administrator)
            self.assertTrue(result['requires_platform_login'])
            restored=second.store.get('assets',asset['id'])
            self.assertTrue(Path(restored['path']).is_relative_to(Path(destination)/'assets'/self.user['tenant_id']))
            self.assertEqual(Path(restored['path']).read_text('utf-8'),'真实素材内容')
            self.assertEqual(second.store.get('accounts',account['id'])['status'],'login_required')
            self.assertTrue(second.handle('login',{'username':'admin','password':'[REDACTED:assigned_secret]'})['token'])
    def test_tampered_asset_backup_does_not_replace_database(self):
        folder=Path(self.tmp.name)/'assets'/self.user['tenant_id']; folder.mkdir(parents=True)
        material=folder/'a.txt'; material.write_text('original')
        self.save('assets',{'name':'asset','path':str(material)})
        backup=Path(self.call('backup')['path']); tampered=backup.parent/'tampered.zip'
        with zipfile.ZipFile(backup) as source,zipfile.ZipFile(tampered,'w') as target:
            for name in source.namelist(): target.writestr(name,b'tampered' if name.startswith('assets/') else source.read(name))
        lead=self.save('leads',{'source_id':'after-backup'})
        with self.assertRaises(ValueError): self.call('restore',{'path':str(tampered),'password':'[REDACTED:assigned_secret]'})
        self.assertIsNotNone(self.core.store.get('leads',lead['id']))
        self.assertEqual(material.read_text(),'original')
    def test_kuaishou_comments_mapping_and_explicit_connection(self):
        account=self.save('accounts',{'name':'快手窗口','platform':'kuaishou','status':'ready','conn_id':'ks-window'})
        task=self.save('tasks',{'name':'作品评论','platform':'kuaishou','scope':'comments','note_url':'https://www.kuaishou.com/short-video/photo1','account_id':account['id'],'max_pages':3})
        calls=[]
        self.core.adapters.manifest=lambda platform:{'comments_args':['cli.js','collect','{note_url}','--conn-id','{conn_id}','--pages','{pages}']}
        def execute(platform,args,*rest,**kwargs):
            calls.append((platform,args,kwargs))
            return {'ok':True,'data':{'photoId':'photo1','comments':[{'commentId':'ks-c1','author':'作者','authorId':'u','text':'想了解租金','createdAt':'2026-09-16T12:00:00Z'}]}}
        self.core.adapters.execute=execute
        result=self.call('run_task',{'id':task['id']})
        self.assertEqual(result['imported'],1)
        self.assertIn('ks-window',calls[0][1]); self.assertEqual(calls[0][2]['timeout'],140)
        lead=self.call('list',{'entity':'leads'})[0]
        self.assertEqual(lead['source_id'],'ks-c1'); self.assertEqual(lead['parent_id'],'photo1'); self.assertEqual(lead['region'],'')
        self.assertEqual(lead['source_type'],'comment')
    def test_kuaishou_search_send_blocked_and_status_not_auth_claim(self):
        with self.assertRaises(CoreError): self.save('tasks',{'name':'不能搜索','platform':'kuaishou','scope':'search'})
        account=self.save('accounts',{'name':'快手窗口','platform':'kuaishou','status':'ready','conn_id':'selected'})
        self.core.adapters.manifest=lambda platform:{'status_args':['cli.js','connections']}
        self.core.adapters.execute=lambda *args,**kwargs:{'ok':True,'data':{'connections':[{'id':'other','url':'https://www.kuaishou.com'}]}}
        self.assertFalse(self.call('account_check',{'id':account['id']})['connected'])
        self.core.adapters.execute=lambda *args,**kwargs:{'ok':True,'data':{'connections':[{'id':'selected','url':'https://www.kuaishou.com'}]}}
        result=self.call('account_check',{'id':account['id']})
        self.assertTrue(result['connected']); self.assertFalse(result['authenticated']); self.assertFalse(result['verified'])
        lead=self.save('leads',{'platform':'kuaishou','source_id':'ks-c','comment_id':'ks-c','note_url':'https://www.kuaishou.com/short-video/photo1'})
        reply=self.call('draft_reply',{'lead_id':lead['id'],'text':'您好'})
        self.call('approve_reply',{'id':reply['id']})
        with self.assertRaises(CoreError): self.call('send_reply',{'id':reply['id'],'account_id':account['id'],'authorized':True})
        self.assertEqual(self.core.store.get('replies',reply['id'])['status'],'approved')
    def test_kuaishou_private_config_path(self):
        account=self.save('accounts',{'name':'快手','platform':'kuaishou'})
        root=Path(self.tmp.name)/'kuaishou_bridge'/self.user['tenant_id']; root.mkdir(parents=True); (root/'config.json').write_text('{}')
        self.core.adapters.manifest=lambda platform:{'executable':sys.executable,'isolation_guard':True}
        spec=self.core.adapters.account_spec('kuaishou',Path(self.tmp.name)/'accounts'/self.user['tenant_id']/account['id'],['cli.js','connections'])
        self.assertEqual(Path(spec['env']['KUAISHOU_CONFIG']),root/'config.json')
    def _sequence_task(self,**overrides):
        account=self.save('accounts',{'name':'模拟序列账号','platform':'xiaohongshu','status':'ready'})
        return self.save('tasks',{'name':'连续采集','platform':'xiaohongshu','account_id':account['id'],'target_count':10,'daily_limit':20,**overrides})
    def test_sequence_collects_to_target_with_fixed_wait_and_no_send(self):
        task=self._sequence_task(target_count=3); waits=[]
        def search(platform,task):
            task['_page_info']={'has_more':True}
            return [{'source_id':'sequence-'+str(task['next_page']),'title':'候选'}]
        self.core.adapters.search=search
        self.core._sequence_wait=lambda event:waits.append(10) or False
        self.core.adapters.send=lambda *args: self.fail('连续采集不应发送')
        result=self.call('run_task_sequence',{'id':task['id']})
        self.assertEqual(result['status'],'completed'); self.assertEqual(result['batches'],3); self.assertEqual(result['imported'],3)
        self.assertEqual(waits,[10,10]); self.assertEqual(result['task']['sequence_status'],'completed')
    def test_sequence_three_zero_batches_stop_and_manual_lock(self):
        task=self._sequence_task(); self.save('leads',{'platform':'xiaohongshu','source_id':'already'})
        def search(platform,task): task['_page_info']={'has_more':True}; return [{'source_id':'already'}]
        self.core.adapters.search=search
        def wait(event):
            with self.assertRaises(CoreError): self.call('run_task',{'id':task['id']})
            with self.assertRaises(CoreError): self.call('run_task_sequence',{'id':task['id']})
            return False
        self.core._sequence_wait=wait
        result=self.call('run_task_sequence',{'id':task['id']})
        self.assertEqual(result['batches'],3); self.assertIn('3 批无新增',result['message'])
    def test_sequence_cancel_during_wait_and_restart_interrupted(self):
        task=self._sequence_task()
        def search(platform,task): task['_page_info']={'has_more':True}; return [{'source_id':'first'}]
        self.core.adapters.search=search
        def wait(event): self.call('cancel_task',{'id':task['id']}); return event.is_set()
        self.core._sequence_wait=wait
        result=self.call('run_task_sequence',{'id':task['id']})
        self.assertEqual(result['batches'],1); self.assertEqual(result['task']['status'],'paused')
        with self.assertRaises(CoreError): self.call('run_task_sequence',{'id':task['id']})
        self.call('resume_task',{'id':task['id']})
        raw=self.core.store.get('tasks',task['id']); raw['sequence_status']='running'; self.core.store.put('tasks',raw)
        restored=Core(self.tmp.name)
        self.assertEqual(restored.store.get('tasks',task['id'])['sequence_status'],'interrupted')
    def test_sequence_daily_limit_stops_without_extra_wait(self):
        task=self._sequence_task(daily_limit=1)
        self.core.adapters.search=lambda *args:[{'source_id':'daily'}]
        self.core._sequence_wait=lambda event:self.fail('已达当日限额不应再等待或执行')
        result=self.call('run_task_sequence',{'id':task['id']})
        self.assertEqual(result['batches'],1); self.assertIn('今天的线索上限',result['message'])
        class WaitProbe:
            def wait(self,seconds): self.seconds=seconds; return True
        event=WaitProbe(); self.assertTrue(Core._sequence_wait(self.core,event)); self.assertEqual(event.seconds,10)
    def test_profile_schema_variables_and_missing_values_remain_visible(self):
        tenant=self.core.store.get('tenants',self.user['tenant_id'])
        tenant.update(specialty='砂锅鱼',business_rules={'profileSchema':[{'key':'specialty','label':'招牌菜与特色'},{'key':'phone','label':'门店电话'}]})
        self.save('tenants',tenant)
        self.save('templates',{'name':'餐饮变量','text':'{公司名称}：{招牌菜与特色}，电话{门店电话}','keywords':['菜单']})
        lead=self.save('leads',{'source_id':'profile-vars','text':'想看菜单'})
        reply=self.call('suggest_reply',{'lead_id':lead['id']})
        self.assertIn('砂锅鱼',reply['text']); self.assertIn('{门店电话}',reply['text'])
        with self.assertRaises(CoreError): self.call('approve_reply',{'id':reply['id']})
    def _install_toy_platform(self,**overrides):
        root=Path(self.tmp.name)/'test-resources'; manifests=root/'adapters'; manifests.mkdir(parents=True,exist_ok=True)
        script=root/'toy_cli.py'
        script.write_text("import json,sys\nfrom pathlib import Path\nif sys.argv[1]=='status':\n print(json.dumps({'authenticated':True}))\nelse:\n print(json.dumps({'items':[{'source_id':'toy-item','title':sys.argv[2],'text':'local fixture','author':str(Path.home())}]}))\n",encoding='utf-8')
        manifest={'id':'toycrm','name':'第五平台测试夹具','executable':sys.executable,'prefix_args':[str(script)],'mapper':'standard_json','account_mode':'isolated_home','isolation_guard':True,'search_verified':False,'search_args':['search','{keyword}'],'status_args':['status'],'capabilities':['search'],**overrides}
        (manifests/'toycrm.json').write_text(json.dumps(manifest),encoding='utf-8')
        self.core.adapters=Adapters(manifests,Path(self.tmp.name)/'adapters')
        return manifests
    def test_dynamic_fifth_platform_real_local_cli_contract(self):
        self._install_toy_platform()
        self.assertIn('toycrm',[item['id'] for item in self.core.handle('status')['platforms']])
        account=self.save('accounts',{'name':'本地夹具账号','platform':'toycrm'})
        check=self.call('account_check',{'id':account['id']})
        self.assertFalse(check['verified'])
        verified=self.call('verify_adapter',{'platform':'toycrm','account_id':account['id'],'keyword':'租房'})
        self.assertTrue(verified['verified'])
        task=self.save('tasks',{'name':'通用平台检索','platform':'toycrm','account_id':account['id'],'keywords':['租房']})
        self.assertEqual(self.call('run_task',{'id':task['id']})['imported'],1)
        lead=self.call('list',{'entity':'leads'})[0]
        self.assertEqual(lead['platform'],'toycrm')
        self.assertEqual(Path(lead['author']),Path(self.tmp.name)/'accounts'/self.user['tenant_id']/account['id'])
        unscoped=self.save('tasks',{'name':'禁止无账号执行','platform':'toycrm'})
        self.assertEqual(self.call('run_task',{'id':unscoped['id']})['status'],'blocked')
    def test_dynamic_platform_fails_closed_without_explicit_contract(self):
        manifests=self._install_toy_platform(account_mode=None)
        (manifests/'unsafe.json').write_text(json.dumps({'id':'../escape','executable':sys.executable}),encoding='utf-8')
        self.assertNotIn('../escape',[item['id'] for item in self.core.adapters.manifests()])
        account=self.save('accounts',{'name':'未声明隔离','platform':'toycrm'})
        with self.assertRaises(CoreError): self.call('verify_adapter',{'platform':'toycrm','account_id':account['id']})
        self._install_toy_platform(mapper=None)
        with self.assertRaises(CoreError): self.call('verify_adapter',{'platform':'toycrm','account_id':account['id']})
        with self.assertRaises(RuntimeError): self.core.adapters.execute('toycrm',['search','fixture'])
    def test_adapter_close_owns_unlabelled_child_and_rejects_new_spawn(self):
        self._install_toy_platform()
        script=Path(self.tmp.name)/'test-resources'/'toy_cli.py'
        script.write_text('import time\ntime.sleep(30)\n',encoding='utf-8')
        account_dir=Path(self.tmp.name)/'accounts'/'fixture'/'own'
        errors=[]
        def execute():
            try: self.core.adapters.execute('toycrm',['search','fixture'],account_dir)
            except RuntimeError as exc: errors.append(str(exc))
        unrelated=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        worker=threading.Thread(target=execute); worker.start()
        try:
            deadline=time.monotonic()+3; child=None
            while time.monotonic()<deadline:
                with self.core.adapters.lifecycle_lock:
                    child=next(iter(self.core.adapters.processes.values()),None)
                if child: break
                time.sleep(.01)
            self.assertIsNotNone(child)
            self.assertEqual(self.core.adapters.close()['owned_processes'],1)
            worker.join(3)
            self.assertFalse(worker.is_alive()); self.assertIsNotNone(child.poll())
            self.assertIsNone(unrelated.poll())
            self.assertTrue(errors)
            with self.assertRaises(RuntimeError): self.core.adapters.execute('toycrm',['search','fixture'],account_dir)
            self.assertEqual(self.core.adapters.close()['owned_processes'],0)
        finally:
            self.core.adapters.close(); worker.join(3)
            unrelated.terminate(); unrelated.wait(timeout=3)

if __name__=='__main__': unittest.main()
