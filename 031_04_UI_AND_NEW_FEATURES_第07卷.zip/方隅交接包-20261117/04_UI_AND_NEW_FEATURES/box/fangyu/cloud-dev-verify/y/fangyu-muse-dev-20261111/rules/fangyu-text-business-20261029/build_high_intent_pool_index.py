"""Account for every existing high-intent judgment, without rerunning intent models.

Immutable source classifications remain intact. Missing or ambiguous needs have
an explicit exception destination rather than an invented specific demand pool.
"""
import collections
import csv
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3

W=Path(__file__).resolve().parent
ROOT=W.parents[1]
OUT=ROOT/'outputs/方隅双平台文本业务/全部高意向分池'
FOLDER=W/'high-intent-pools-20261101'
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def rows(path):
    with Path(path).open(encoding='utf-8-sig') as stream:
        for line in stream:
            if line.strip():yield json.loads(line)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def packed(value):return json.dumps(value,ensure_ascii=False,sort_keys=True)
def high(c):return c.get('interest_at_comment',c.get('interest')) in ('high','super_high')


def supplement(text):
    """Only refine an existing high-intent judgment; never infer intent from a word hit."""
    if re.search(r'租金|房租|价格|价位|预算|多少钱|多钱|询价|多少一月|月租|什么价',text):
        return ['价格预算'],'原文明确询价或预算',None
    if re.search(r'多少|多米|几张',text):
        return [],None,'计量或询问对象不明；价格与面积不能擅选'
    if re.search(r'小区|在哪|哪里|哪儿|地址|什么位置|附近|路|区|地铁|通勤',text):
        return ['位置通勤'],'原文明确地点或通勤话题',None
    if re.search(r'装修|车位|停车|阳台|厨房|浴室|洗衣|空调',text):
        return ['房内设施'],'原文明确设施或装修话题',None
    if re.search(r'猫|宠物|狗',text):
        return ['宠物'],'原文明确宠物话题；条件肯否另保留',None
    if re.search(r'合租|整租|室|单间|人住|女生|男生|早睡|一居|两居',text):
        return ['户型面积与居住方式'],'原文明确房型或居住方式话题',None
    if re.search(r'电梯|楼层|几楼',text):return ['楼层电梯'],'原文明确楼层电梯话题',None
    if re.search(r'入住|起租|短租|长租|租期',text):return ['入住与租期'],'原文明确入住租期话题',None
    if re.search(r'联系|私|聊|看房|看看|了解|详情|微信|加我|怎么租',text):
        return ['看房联系'],'原文明确了解或联系话题',None
    if re.search(r'租|要|找|有吗|还有|有没有|安排|推荐|转租',text):
        return ['房源状态'],'既有高意向判断下的基础询租；未补造预算户型等条件',None
    return [],None,'原文没有可确定的细分需求；保留高意向判断并进异常池'


def route(c,text):
    names=[];details=[];unknown=[]
    for t in c.get('topics',[]) or []:
        name=t.get('pool') if isinstance(t,dict) else t
        if name in POOLS:
            if name not in names:names.append(name)
            details.append(t)
        else:unknown.append(t)
    method='沿用既有语义分池'
    exception=None
    if not names:
        names,why,exception=supplement(text)
        method=why or '保留疑难，不强造需求'
    if c.get('role') not in ('demand','mixed'):
        exception='原高意向与供需身份存在冲突，保留原判断并进异常池核对'
    if unknown:exception=exception or '有无法识别的历史池标签，保留原文待核'
    return names,details,method,exception


def main():
    FOLDER.mkdir(exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
    pointer=read(W/'当前双平台回复结果指针.json')
    raw_xhs={}
    for path in [W/'delivery-v2/source-input.jsonl',W/'xhs-increment-846/input.jsonl']:
        for r in rows(path):raw_xhs[str(r['comment_id'])]=r
    frozen=[];sources={};expected=set()
    for platform,p in pointer['platforms'].items():
        path=Path(p['classification_file']);assert sha(path)==p['classification_sha256']
        sources[platform]={'file':str(path),'sha256':sha(path)}
        for row in rows(path):
            c=row.get('classification') or row
            if not high(c):continue
            raw=raw_xhs.get(str(row['comment_id']),row) if platform=='xiaohongshu' else row
            key=(platform,str(row['comment_id']));assert key not in expected;expected.add(key)
            frozen.append((platform,row,c,raw,'已发布历史分类'))
    delta=W/'local-first-resumption/state/derived.sqlite3'
    if delta.exists():
        db=sqlite3.connect(delta.resolve().as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        increment=[json.loads(raw) for raw, in db.execute('SELECT data FROM delta')];db.close()
        for row in increment:
            if not high(row):continue
            key=('douyin',str(row['comment_id']))
            if key in expected:continue
            expected.add(key);frozen.append(('douyin',row,row,row,'新增本地旁注'))
        sources['douyin_increment']={'store':str(delta),'snapshot_rows':len(increment),
            'high_rows':sum(high(r) for r in increment),'content_sha256':hashlib.sha256(packed(increment).encode()).hexdigest()}
    result=[]
    for platform,row,c,raw,stage in frozen:
        cid=str(row['comment_id']);text=raw.get('comment_text') or ''
        pools,details,method,exception=route(c,text)
        if not text:exception='缺原评论正文，必须补来源后再备稿'
        # Pet pool is multi-label. Cat wording applies only to a positive own-demand cat condition.
        cat=('宠物' in pools and '猫' in text and
             not re.search(r'不养猫|不带猫|没养猫|没有猫|不要猫|不接受猫|不喜欢猫|怕猫|猫不行',text))
        contact=c.get('contact_boundaries') or row.get('effective_contact_policy')
        blockers=list(c.get('needs_review') or []) if isinstance(c.get('needs_review'),list) else []
        if exception:blockers.append(exception)
        cat_additional_conditions=cat and bool(re.search(r'狗|多猫|\d+只猫|[两三四五六七八九十]只猫',text))
        if cat and len(pools)==1 and not exception and not cat_additional_conditions:
            body='宝宝，我住方隅这边，能带猫的，介绍有优惠。'
            family='cat_user_confirmed_20261101'
        else:
            body=None
            family='multi_pool_integrated' if len(pools)>1 else {
                '价格预算':'price','位置通勤':'location','户型面积与居住方式':'room_or_living_mode',
                '房内设施':'facilities','宠物':'pet_condition','楼层电梯':'floor',
                '入住与租期':'move_in_or_lease','房源状态':'available_or_general_rental',
                '费用合同':'fees_or_contract','看房联系':'viewing_or_contact'
            }.get(pools[0] if pools else None,'needs_clarification')
        if cat and len(pools)>1:blockers.append('猫可带口径已确认；须与其余需求合成一句，不能丢其他条件')
        if cat_additional_conditions:blockers.append('猫可带口径不能替代狗或多宠数量条件，另行保留这些条件')
        item={'platform':platform,'comment_id':cid,'customer_uid':str(row.get('customer_uid') or c.get('customer_uid') or ''),
            'comment_text':text,'interest_at_comment':c.get('interest_at_comment',c.get('interest')),
            'role':c.get('role'),'source_stage':stage,'demand_pools':pools,'original_topic_details':details,
            'pool_assignment_method':method,'exception_pool_reason':exception,
            'destination':'异常池' if exception or not pools else '需求池',
            'original_classification':c,'target_regions':c.get('target_regions') or row.get('target_region_reference'),
            'ip_location_raw':raw.get('ip_location_raw',raw.get('ip_location')),
            'time_mentions':c.get('time_mentions') or [],
            'published_at':raw.get('published_at',raw.get('published_at_unix',row.get('comment_published_at'))),
            'current_need_verified':False,'contact_boundaries':contact,
            'mother_family':family,'cat_positive_user_approved':cat,
            'cat_additional_conditions':cat_additional_conditions,
            'cat_mother_clause':'我住方隅这边，能带猫的，介绍有优惠。' if cat else None,
            'reply_text_candidate':body,'reply_status':'用户认可口径的本地草稿' if body else '尚需按本条条件完成母句适配，不能退回统一介绍句',
            'unresolved_items':blockers,'send_authorized':False,'can_send_now':False,
            'classification_complete_is_not_reply_complete':True,'send_or_retry_attempted':False}
        result.append(item)
    keys={(r['platform'],r['comment_id']) for r in result}
    assert keys==expected and len(keys)==len(result)
    assert all(r['destination'] in ('需求池','异常池') for r in result)
    assert all(set(r['demand_pools'])<=set(POOLS) for r in result)
    assert not any(r['send_authorized'] or r['send_or_retry_attempted'] for r in result)
    allfile=FOLDER/'all-high-intent-pools.jsonl'
    allfile.write_text(''.join(packed(r)+'\n' for r in result),encoding='utf8')
    stats={}
    for platform in ['douyin','xiaohongshu']:
        group=[r for r in result if r['platform']==platform]
        stats[platform]={'high_comments':len(group),'high_customers':len({r['customer_uid'] for r in group if r['customer_uid']}),
            'demand_pool_comments':sum(r['destination']=='需求池' for r in group),
            'exception_pool_comments':sum(r['destination']=='异常池' for r in group),
            'multi_pool_comments':sum(len(r['demand_pools'])>1 for r in group),
            'pool_counts':dict(collections.Counter(p for r in group for p in r['demand_pools'])),
            'cat_positive_comments':sum(r['cat_positive_user_approved'] for r in group),
            'ready_cat_only_candidates':sum(bool(r['reply_text_candidate']) for r in group)}
        folder=FOLDER/platform;folder.mkdir(exist_ok=True)
        for pool in POOLS+['异常池']:
            selected=[r for r in group if (r['destination']=='异常池' if pool=='异常池' else pool in r['demand_pools'])]
            (folder/(pool+'.jsonl')).write_text(''.join(packed(r)+'\n' for r in selected),encoding='utf8')
        name='抖音' if platform=='douyin' else '小红书'
        with (OUT/(name+'历史原始求租意愿明细.csv')).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f);writer.writerow(['客户原评论','评论时意向','需求池','处理去向','分池依据','母句准备','尚待核对'])
            for r in group:writer.writerow([r['comment_text'],'超高' if r['interest_at_comment']=='super_high' else '高','、'.join(r['demand_pools']),r['destination'],r['pool_assignment_method'],r['reply_text_candidate'] or r['reply_status'],'；'.join(str(x) for x in r['unresolved_items'])])
    manifest={'created_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),'sources':sources,
        'results_file':str(allfile),'results_sha256':sha(allfile),'stats':stats,
        'checks':{'all_high_ids_accounted_for':keys==expected,'no_duplicate_platform_cid':len(keys)==len(result),
            'all_have_destination':True,'multi_pool_preserved':True,'no_automatic_send_or_retry':True},
        'pool_counts_overlap':True,'all_high_intent_reply_bodies_completed':False,
        'historical_classifications_changed':False,'model_reclassification_jobs':0,
        'old_frozen_567_queue_replaced':False,'not_a_send_queue':True,'actual_semantic_accuracy':'not_measured_without_gold'}
    (FOLDER/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    current={'manifest':str(FOLDER/'manifest.json'),'manifest_sha256':sha(FOLDER/'manifest.json'),
             'results_file':str(allfile),'results_sha256':sha(allfile),'not_a_send_queue':True}
    (W/'历史原始求租意愿分池指针.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'stats':stats,'checks':manifest['checks']},ensure_ascii=False))


if __name__=='__main__':main()
