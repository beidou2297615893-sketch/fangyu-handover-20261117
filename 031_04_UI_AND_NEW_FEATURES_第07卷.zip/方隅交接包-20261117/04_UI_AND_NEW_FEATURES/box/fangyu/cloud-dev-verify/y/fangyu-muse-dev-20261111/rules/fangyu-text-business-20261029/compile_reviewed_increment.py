"""Join completed model judgments and explicit review patches without classifying text."""
import argparse, copy, hashlib, json, re
from collections import Counter
from pathlib import Path
from mother_adapter import validate_new_review

W=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--run',required=True,help='16-character frozen run hash')
parser.add_argument('--output-dir',type=Path,help='isolated output directory for validation; review source still names the run')
args=parser.parse_args()
if not re.fullmatch(r'[0-9a-f]{16}',args.run): parser.error('--run must be a 16-character lowercase hexadecimal hash')
B=W/'douyin-registered-v2/increments'/args.run
O=args.output_dir.resolve() if args.output_dir else B
O.mkdir(parents=True,exist_ok=True)
def read(path): return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump_rows(path,rows):
    payload=''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows).encode('utf-8')
    if path.exists(): assert path.read_bytes()==payload, f'Frozen derived output differs: {path.name}'
    else: path.write_bytes(payload)

manifest=json.loads((B/'manifest.json').read_text(encoding='utf-8'))
raw=(B/'input.jsonl').read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(raw).hexdigest()==manifest['input_sha256'] and manifest['input_sha256'].startswith(args.run)
inputs=read(B/'input.jsonl');source={r['review_key']:r for r in inputs}
assert len(inputs)==manifest['new_comments'] and len(source)==len(inputs)
for i in range(3): assert read(B/f'shard-{i}.jsonl')==inputs[i::3]
primary_files=[B/f'reviewed-new-{i}.jsonl' for i in range(3)]
pilot_initial=B/'pilot-200/reviewed.jsonl';pilot_fine=B/'pilot-200/fine-reviewed.jsonl'
audit_candidates=[B/f'recall-audit-{i}.jsonl' for i in range(2)]
audit_files=[p for p in audit_candidates if p.exists()]
quality_path=B/'quality-gate.json'
quality=json.loads(quality_path.read_text(encoding='utf-8')) if quality_path.exists() else {}
required_audits=max(quality.get('independent_recall_calibration_queued',0),quality.get('independent_recall_calibration_complete',0))
if required_audits or quality.get('independent_recall_required',False):
    assert len(audit_files)==len(audit_candidates), 'Quality gate requires both recall audit files'
pilot_files=[pilot_initial,pilot_fine] if pilot_fine.exists() else []
if pilot_files:
    assert pilot_initial.is_file(), 'Fine-reviewed pilot requires its initial review provenance'
    initial_rows=read(pilot_initial); initial={r['review_key']:r for r in initial_rows}
    assert len(initial)==len(initial_rows)
    for r in read(pilot_fine):
        assert r['review_key'] in initial
        assert all(r[k]==initial[r['review_key']][k] for k in ('comment_id','customer_uid','video_id'))
versions={str(p.relative_to(B)):sha(p) for p in primary_files+pilot_files+audit_files}
records={};origin={}
for p in primary_files+([pilot_fine] if pilot_files else []):
    for row in read(p):
        key=row['review_key'];assert key not in records
        records[key]=copy.deepcopy(row);origin[key]=p
assert set(records)==set(source) and len(records)==len(inputs)
audits={}
allowed={'role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','contact_boundaries','context_flags','reply_plan'}
for p in audit_files:
    for a in read(p):
        key=a['review_key'];assert key in records and key not in audits
        assert a['decision'] in ('keep','change') and set(a['patch'])<=allowed
        assert a['decision']=='change' or a['patch']=={}
        assert origin[key]!=pilot_fine
        audits[key]=(p,a)
        if a['decision']=='change':records[key].update(copy.deepcopy(a['patch']))
assert len(audits)>=required_audits, 'Recall audit count falls short of quality gate'

pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for key,row in records.items():
    s=source[key];p=origin[key]
    assert all(row[k]==s[k] for k in ('comment_id','customer_uid','video_id'))
    assert row['role'] in ('demand','supply','mixed','discussion','unknown')
    assert row['demand_state'] in ('active_at_comment','future','ended','historical','unknown')
    assert row['interest'] in ('super_high','high','medium','low','very_low','uncertain','unrelated')
    assert not(row['role']=='unknown' and row['interest']=='unrelated')
    assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
    assert isinstance(row['reply_plan'],dict) and type(row['reply_plan']['generic_intro_suitable']) is bool
    for t in row['topics']: assert t['pool'] in pools
    own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
    quotes=list(row.get('evidence',[]))
    for field in ('topics','target_regions','time_mentions','other_constraints','contact_boundaries'):
        quotes += [x['quote'] for x in row.get(field,[]) if isinstance(x,dict) and 'quote' in x]
    assert all(isinstance(q,str) and q and any(q in text for text in own) for q in quotes),key
    row['classification_method']='ai_independent_semantic_fine_review' if p==pilot_fine else 'ai_semantic_initial_and_detailed'
    row['classification_stages_completed']=['initial_semantic','detailed_semantic']+(['independent_semantic'] if p==pilot_fine else [])
    row['analysis_provenance']=[{'stage':'initial_semantic','path':str(pilot_initial),'sha256':versions[str(pilot_initial.relative_to(B))]}] if p==pilot_fine else []
    row['analysis_provenance'].append({'stage':row['classification_method'],'path':str(p),'sha256':versions[str(p.relative_to(B))]})
    row['independent_recall_reviewed']=key in audits
    if key in audits:
        ap,a=audits[key]
        row['analysis_provenance'].append({'stage':'independent_recall_calibration','path':str(ap),'sha256':versions[str(ap.relative_to(B))],'decision':a['decision'],'reason':a['reason']})
    row['human_confirmed']=False;row['send_authorized']=False

final=[records[s['review_key']] for s in inputs]
semantic=O/'semantic-final.jsonl'
semantic_bytes=''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in final).encode('utf-8')
semantic_hash=hashlib.sha256(semantic_bytes).hexdigest()
review_source={'path':str(B/'semantic-final.jsonl'),'sha256':semantic_hash}
# Reuse the publisher's contract before writing; recall is recorded independently in
# independent_recall_reviewed/provenance because its method-stage list is strict.
source_cache={(B/'semantic-final.jsonl').resolve():(semantic_hash,{(r['review_key'],r['comment_id']):r for r in final})}
for row in final:
    item=copy.deepcopy(row);item['classification_review_source']=review_source
    validate_new_review(item,B,source_cache)
dump_rows(semantic,final)
for i in range(3):
    out=[]
    for r in final[i::3]:
        item=copy.deepcopy(r);item['classification_review_source']=review_source;out.append(item)
    dump_rows(O/f'reviewed-{i}.jsonl',out)
receipt={'input_comments':len(inputs),'AI_initial_and_detailed_complete':len(records),'independent_pilot_fine_complete':sum(1 for p in origin.values() if p==pilot_fine),'independent_recall_and_level_calibration_complete':len(audits),'audit_changed_records':sum(a['decision']=='change' for _,a in audits.values()),'unique_comments_with_independent_review':len(set(audits)|{k for k,p in origin.items() if p==pilot_fine}),'interest_counts':dict(Counter(r['interest'] for r in final)),'role_counts':dict(Counter(r['role'] for r in final)),'all_IDs_and_identities_match':True,'quoted_evidence_verbatim':True,'original_review_file_versions':versions,'semantic_final_sha256':sha(semantic),'publisher_invoked':False,'accuracy_or_zero_misses_claimed':False,'source_modified':False,'platform_calls':0,'actual_sent_by_this_text_task':0}
receipt_path=O/'semantic-compile-receipt.json'
receipt_payload=json.dumps(receipt,ensure_ascii=False,indent=2).encode('utf-8')
if receipt_path.exists(): assert receipt_path.read_bytes().replace(b'\r\n',b'\n')==receipt_payload, 'Existing receipt differs'
else: receipt_path.write_bytes(receipt_payload)
print(json.dumps({k:v for k,v in receipt.items() if k!='original_review_file_versions'},ensure_ascii=True))
