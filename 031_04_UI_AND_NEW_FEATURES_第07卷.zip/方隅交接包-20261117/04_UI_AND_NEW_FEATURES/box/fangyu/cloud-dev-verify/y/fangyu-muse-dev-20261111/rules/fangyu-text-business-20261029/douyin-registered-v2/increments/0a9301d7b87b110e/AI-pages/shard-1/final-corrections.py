import pathlib,json
b=pathlib.Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/0a9301d7b87b110e/AI-pages/shard-1')
# Model-authored correction of decision notation, never text-based classification.
# On review none of the u-coded rows expresses any contact restriction; missing semantic
# intent does not itself imply an unknown contact prohibition. Their roles/intents stay.
for p in b.glob('decisions-*.txt'):
 t=p.read_text(encoding='utf-8').replace('|Uu|','|Ua|')
 if p.name=='decisions-04.txt':
  t=t.replace('D2531|Xi|','D2531|Xa|').replace('identity_restricted仅对应其表达偏好，发言为对他人建议，不作客户全面拒联','建议针对博主，未表达本人联系限制，不继承为客户限制')
 if p.name=='decisions-00.txt':
  t=t.replace('D0452|Xa|','D0452|Na|')
 if p.name=='decisions-03.txt':
  t=t.replace('D1628,D1631|Xa|||询房屋总价买卖，非租赁||','D1628|Xa|||问现房总价，未明本人租赁需求||\nD1631|Na|||主动问怎么卖及房价，保留购房需求非住宅租赁||')
 if p.name=='decisions-09.txt':
  t=t.replace('D5312|Xa|','D5312|Na|')
 if p.name=='decisions-13.txt':
  t=t.replace('"relation":"work","group_relation":"unknown","condition_scope":"地铁30分钟的通勤锚，是否工作地点未确认"','"relation":"unresolved","group_relation":"unknown","condition_scope":"地铁30分钟的目的地锚，是否工作地点未确认"')
 p.write_text(t,encoding='utf-8')
print('Explicit review corrections saved; contact restriction is absent from formerly u-coded rows, not sending permission.')
