import json,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parents[1]; PART=BASE/'recall-audit'/'part-0'
short={'role':'r','demand_state':'s','interest':'i','topics':'t','target_regions':'rg','time_mentions':'tm','other_constraints':'o','possible_topics':'p','needs_review':'n','contact_boundaries':'cb','context_used':'u','reply_plan':'rp','reason':'why','pool':'P','quote':'q','polarity':'pol','subject':'sub','condition_scope':'scope','preferred_mother_slot':'slot','generic_intro_suitable':'gen','tone':'tone','missing_facts':'facts','caution':'cau','contact_policy':'contact'}
def compact(v,own,strings,used,new):
 if isinstance(v,dict):return {short.get(k,k):compact(x,own,strings,used,new) for k,x in v.items()}
 if isinstance(v,list):return [compact(x,own,strings,used,new) for x in v]
 if isinstance(v,str):
  if v==own and own:return '$'
  if len(v)>18:
   if v not in strings:strings[v]=len(strings)
   ix=strings[v]
   if ix not in used:used.add(ix);new.append((ix,v))
   return '#'+str(ix)
 return v
strings={};used=set(); target=int(sys.argv[1]);a=int(sys.argv[2]);b=int(sys.argv[3]);out=[];news=[]
def emit(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
defaults={'topics':[],'target_regions':[],'time_mentions':[],'other_constraints':[],'possible_topics':[],'needs_review':[],'contact_boundaries':[],'context_used':['own','body']}
for page in range(target+1):
 d=json.loads((PART/f'page-{page:02}.json').read_text(encoding='utf8'));i=0
 for g in d['post_groups']:
  group=False
  for c in g['comments']:
   sel=page==target and a<=i<b
   if sel and not group:out.append('BODY '+g['video']+' '+g['post_body']);group=True
   new=[];j={k:v for k,v in c['first_semantic_judgment'].items() if defaults.get(k,object())!=v};cv=compact(j,c['text'],strings,used,new)
   if sel:
    news+=new;out.append(c['key']+' '+emit(c['text'])+' '+emit(cv)+(' SAMEAUTHOR' if c['same_author'] else '')+(' parent='+emit(c['parent']) if c['parent'] else ''))
   i+=1
print('NEWDICT '+emit(dict(news)));print('\n'.join(out))
