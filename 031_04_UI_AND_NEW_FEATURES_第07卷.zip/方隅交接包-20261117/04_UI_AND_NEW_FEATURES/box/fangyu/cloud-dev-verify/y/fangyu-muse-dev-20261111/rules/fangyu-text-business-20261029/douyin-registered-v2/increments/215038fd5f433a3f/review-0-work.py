import json,hashlib,collections
from pathlib import Path
p=Path(__file__).parent; source=p/'shard-0.jsonl';rows=[json.loads(s) for s in source.read_text(encoding='utf-8-sig').splitlines()]
decisions={
1:('unknown','uncertain','unknown','仅回答“有”，具体指房源、信息或其他对象不明。'),
4:('demand','high','active_at_comment','本人询问普陀和嘉定是否有转租房，属于评论时的区域找房询盘。'),
7:('supply','unrelated','unknown','本人明确提供转租房，未表示另找房。'),
10:('unknown','uncertain','unknown','“杨浦这边有”可能指提供、知道房源或其他资源，供需身份与具体对象待核。'),
13:('supply','unrelated','unknown','向求租者推荐静安公寓，不等于本人寻找住房；本人是否房东或代理未明。'),
16:('unknown','uncertain','unknown','仅有地名，不能确定是推荐房源、本人目标还是其他回应。'),
19:('supply','unrelated','unknown','询问求租者是否要杨浦房屋，属于提供或推荐房源。'),
22:('unknown','uncertain','unknown','只描述金额和房间设施，未明是提供房源、分享已租经历还是询问。'),
25:('unknown','uncertain','unknown','仅有小区名，供需角色和所指内容不明。'),
28:('demand','high','active_at_comment','对明确直租房源询问是否还有；只表示评论时兴趣。'),
31:('demand','high','active_at_comment','对明确直租房源询问面积和价格，不表示本人预算。'),
34:('discussion','unrelated','unknown','表达对房子的喜欢，未明确本人求租或后续租赁行动。'),
37:('unknown','uncertain','unknown','询问某数字是否审批通过，申请对象、本人身份和其与住房需求的关系不明。'),
40:('discussion','unrelated','unknown','讨论备案和税费，没有明确新的本人求租。'),
43:('discussion','unrelated','unknown','评论金额与他人行为，没有明确新的本人求租。'),
46:('supply','unrelated','unknown','本人自称地铁站附近中介，提供服务身份线索；没有明确本人求租。'),
49:('unknown','uncertain','unknown','针对价格攻略问13号地铁站，可能询问信息，未明确本人当前求租。'),
52:('discussion','unrelated','unknown','评价某地区租房价格贵，未明确本人当前找房。'),
55:('unknown','uncertain','unknown','质疑某站点是否真有低价房，不能据此确认本人当前租房意向。'),
58:('unknown','uncertain','unknown','在攻略下请求六号线信息，可能索取价格表，并未明确本人当前求租。'),
61:('discussion','unrelated','unknown','感谢内容作者，未表达本人求租。'),
64:('demand','high','active_at_comment','本人明确找圣爱大厦附近的租房并提出价格上限；同作者正文另有不同数字，需核对。'),
67:('discussion','unrelated','unknown','建议他人考虑其他地区并评价房价，没有本人新求租。'),
70:('discussion','unrelated','unknown','祝愿他人租房顺利，没有本人求租。'),
73:('discussion','unrelated','unknown','对他人的数字发问或调侃，没有明确本人求租。'),
76:('discussion','unrelated','unknown','回忆本人以前在香港找室友的经历，没有当前新租房需求。'),
79:('discussion','unrelated','unknown','建议他人考虑某地区通勤和租金，不是本人新求租。'),
82:('discussion','unrelated','unknown','向他人建议床位及价格，没有表达本人现在求租。'),
85:('demand','high','active_at_comment','针对明确出租房源问价，只说明评论时兴趣。'),
88:('unknown','uncertain','unknown','质疑房间和价格真实性，不等同本人当前找房或已核真实房源。'),
91:('demand','high','active_at_comment','针对明确出租房源询问能否看房；没有提出预约时间。'),
94:('demand','high','active_at_comment','针对明确出租房源询问是否还有，只能判断评论时兴趣。'),
}
T={};R={};TM={}
def topic(n,pool,q,pol='ask',subject='own_demand',source='comment',scope='本人原话中的询问或条件'):
 T.setdefault(n,[]).append(dict(pool=pool,quote=q,polarity=pol,subject=subject,source=source,condition_scope=scope))
def region(n,q,relation,scope,group='unknown'):
 R.setdefault(n,[]).append(dict(text=q,quote=q,relation=relation,source='comment',group_relation=group,condition_scope=scope))
topic(4,'位置通勤','普陀区嘉定区','require',scope='本人提出两处区域，未明确两者是二选一还是并列');topic(4,'房源状态','有马','ask',scope='询问是否有房，不确认库存')
region(4,'普陀区嘉定区','desired','评论者询问的区域，两个区域的连接关系未明确')
region(7,'繁荣路地铁附近','offered','提供转租房所在地，不是本人新求租地区');TM[7]=[dict(quote='11月中旬搬出',time_role='other',subject='supply',source='comment',normalized=None,verification='只保留原词及发表时间，未推定入住日期或当前状态')]
region(10,'杨浦','unresolved','说话人对杨浦提及的供需角色不明');region(13,'静安区','offered','向他人推荐的公寓区域，不是本人目标地区');region(16,'赵巷','unresolved','仅地名，区域用途未明');region(19,'杨浦控江','offered','提供或推荐房屋的区域')
region(25,'宝山通河八村','unresolved','仅小区名称，角色和地点用途未知')
topic(28,'房源状态','还有','ask',scope='询问房源是否在租，未核实当前实际房态');topic(31,'户型面积与居住方式','多大');topic(31,'价格预算','什么价');
region(46,'13号线金运路站','offered','中介自述服务位置，非本人租房目标')
topic(49,'位置通勤','13号地铁站','ask','unresolved',scope='询问攻略中的线路内容，是否本人当前求租未明');region(49,'13号地铁站','unresolved','交通信息询问，不能确定为本人目标区域')
topic(55,'价格预算','哪有这么便宜的','compare','unresolved',scope='对攻略价格的质疑，不作为确定预算或当前求租');region(55,'景西路站','unresolved','质疑价格时提及的站点，不认定为目标地区')
topic(58,'位置通勤','6号线','ask','unresolved',scope='请求攻略信息，是否本人求租待核');region(58,'6号线','unresolved','可能是在求攻略信息，并非已核本人目标')
topic(64,'位置通勤','圣爱大厦附近','require',scope='本人表示附近租房，不从其他人或IP推断');region(64,'圣爱大厦附近','desired','本人明确想在该处附近租房')
topic(64,'价格预算','2800以下','require',scope='本人评论中的价格上限；与同作者帖子中的1500以内不同，需核对时间及范围')
topic(64,'价格预算','1500以内','require','own_demand','same_author_post',scope='已验证同一作者帖子原文；与评论上限不同，不能自行覆盖或拼接')
topic(85,'价格预算','问价');topic(88,'价格预算','这个价格','ask','unresolved',scope='仅质疑价格真实性，并非已确认预算或租房需求');topic(91,'看房联系','可以看房吗','ask',scope='泛看房询问，没有具体预约时间');topic(94,'房源状态','还有嘛')
out=[]
for d in rows:
 n=int(d['review_key'][1:]); assert n in decisions
 role,interest,state,reason=decisions[n];t=d['comment_text']; gaps=[]; te=T.get(n,[]); regs=R.get(n,[]);times=TM.get(n,[])
 if role=='unknown':gaps.append(reason)
 if role=='demand' and state=='active_at_comment':gaps.append('评论时询盘或找房不等于当前仍在找；房源实际状态及承接条件未知。')
 if n==64:gaps.append('同作者正文写1500以内，本人评论写2800以下；可能是调整、不同口径或不同需求，需核实，不能静默任选。')
 if n in (13,19):gaps.append('推荐或提供的房源及其权限未核；不推断评论者一定是房东。')
 if n==7:gaps.append('转租原因及是否需要另找新房未说明。')
 if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read'):gaps.append(f"有{d['deeper_reply_count_visible']}条可见深层回复未读取，不能推断后续结果。")
 if d.get('source_version_conflict'):gaps.append('来源版本存在冲突，需复核原始记录。')
 evidence=[t];evidence_sources=[dict(source='comment',quote=t)]
 if n==64:
  assert d['post_author_same_as_commenter'] and '1500以内' in d['post_body']
  evidence.append('1500以内');evidence_sources.append(dict(source='same_author_post',quote='1500以内'))
 for x in te+regs+times:
  src=x.get('source','comment');text=d['post_body'] if src=='same_author_post' else t
  assert x['quote'] in text,(n,x['quote'])
  if src=='same_author_post':assert d['post_author_same_as_commenter']
 for x in times:x['anchor_source']='comment_published_at_unix';x['anchor_time']=d.get('published_at_unix')
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],video_id=d['video_id'],role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(x['pool'] for x in te)),topic_evidence=te,target_regions=regs,time_mentions=times,reason=reason,evidence=evidence,evidence_sources=evidence_sources,review_reasons=gaps,context_used=['comment','post_body'] if d.get('post_body') else ['comment'],media_context='未读取视频画面；不将文字描述当作画面已核实',reply_context='有可见深层回复但未读' if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read') else '未读取深层回复',current_need_verified=False,assigned_store=None,send_authorized=False))
assert len(rows)==len(out)==32
assert {(d['review_key'],d['comment_id'],d['customer_uid'],d['video_id']) for d in rows}=={(d['review_key'],d['comment_id'],d['customer_uid'],d['video_id']) for d in out}
allowed={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for d,x in zip(rows,out):
 assert len(x['evidence'])==len(x['evidence_sources'])
 for q,e in zip(x['evidence'],x['evidence_sources']):assert q==e['quote'] and q in (d['post_body'] if e['source']=='same_author_post' and d['post_author_same_as_commenter'] else d['comment_text'])
 assert set(x['topics'])<=allowed and set(x['topics'])=={z['pool'] for z in x['topic_evidence']}
 assert not(x['role']=='unknown' and x['interest_at_comment']=='unrelated')
 assert x['current_need_verified'] is False and x['assigned_store'] is None and x['send_authorized'] is False
(p/'reviewed-0.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
v=dict(input_count=len(rows),output_count=len(out),unique_review_keys=len({x['review_key'] for x in out}),id_quadruples_equal=True,evidence_and_quotes_verbatim=True,input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),role_counts=dict(collections.Counter(x['role'] for x in out)),interest_counts=dict(collections.Counter(x['interest_at_comment'] for x in out)),needs_review_count=sum(bool(x['review_reasons']) for x in out),same_author_body_used_count=1,deeper_replies_unread_count=sum(bool(x.get('deeper_reply_count_visible')) and not x.get('deeper_replies_read') for x in rows),video_frames_read=False,current_need_verified=False,send_authorized=False,model_reference_not_gold=True)
(p/'validation-0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,ensure_ascii=False,indent=2))
