from decisions import *
j=original(13,'D3857');r=j['target_regions'];
for v in r[1:]:v['relation']='unresolved'
emit(13,'''D3552 D3554 D3556 D3558 D3560 D3562 D3564 D3566 D3568 D3570 D3572 D3580 D3585 D3595 D3598 D3769 D3772 D3774 D3784 D3787 D3601 D3603 D3605 D3607 D3609 D3611 D3613 D3615 D3617 D3619 D3795 D3797 D3799 D3801 D3803 D3805 D3807 D3809 D3811 D3621 D3623 D3625 D3627 D3629 D3631 D3633 D3635 D3637 D3639 D3813 D3815 D3817 D3819 D3821 D3823 D3825 D3827 D3829 D3831 D3641 D3643 D3645 D3647 D3649 D3651 D3653 D3655 D3657 D3659 D3833 D3835 D3837 D3839 D3841 D3843 D3845 D3847 D3849 D3851 D3661 D3663 D3665 D3668 D3670 D3672 D3674 D3676 D3678 D3680 D3682 D3684 D3686 D3853 D3855 D3859 D3865 D3688 D3690 D3692 D3694 D3696 D3698 D3700 D3702 D3704 D3706 D3708 D3712 D3715 D3717 D3720 D3724 D3733 D3736 D3746 D3751 D3766 D3792''',{
'D3780':('明确出租及具体这套语境下常规询价，不能只因省略价格二字丢为未知。',dict(role='demand',demand_state='active_at_comment',interest='high',topics=[topic('价格预算','这套多少')],possible_topics=[],reason='在可租公寓房源下询所指这套租价，保留评论时询租兴趣',needs_review=['所指具体房型、完整租价及本人当前是否仍找房待核'],reply_plan=plan(1,True,facts=['真实住户、介绍资格、同店优惠时效及适用条件待核','对应房源及同店可承接房型的真实报价和全部必付费用待核']))),
'D3857':('看过区域不等于接受租住，保留为待核备选；通勤地和次卧要求不变。',dict(target_regions=r,needs_review=j['needs_review']+['新宫、传媒大学、物资学院是已看选项，是否仍接受或已排除待核']))
})
