import json,hashlib,re,collections
from pathlib import Path

root=Path.cwd(); here=Path(__file__).parent; src=root/'work/reply-classification-20261029'; work=root/'work/fangyu-text-business-20261029'
def lines(p): return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def filehash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=lines(src/'old-snapshot.jsonl');new=lines(src/'new-snapshot.jsonl');rows={}
for c in old:
 for z in c.get('comments',[]):
  f=z['original_fields'];cid=f['comment_id']; text=f.get('text','') or ''
  rows[cid]={'comment_id':cid,'customer_uid':c.get('platform_uid',''),'text':text,'post_title':f.get('content_title','') or '', 'parent_text':f.get('parent_text','') or '', 'parent_relationship':f.get('parent_relationship','unknown'),'post_text':'','published_at':f.get('published_at','') or '', 'source_group':'old-snapshot'}
for c in new:
 obs=c.get('input_observations',[])
 if not obs:continue
 fs=[o.get('data',o) for o in obs]; f=max(fs,key=lambda x:sum(len(x.get(k,'') or '') for k in ('post_title','parent_text','post_text')))
 cid=c.get('comment_id');text=f.get('comment_text','') or ''
 if cid in rows:
  if rows[cid]['text']!=text:rows[cid]['source_conflict']=True
  continue
 rows[cid]={'comment_id':cid,'customer_uid':(c.get('customer_uids') or [f.get('customer_uid','')])[0], 'text':text,'post_title':f.get('post_title','') or '', 'parent_text':f.get('parent_text','') or '', 'parent_relationship':f.get('parent_relationship','unknown'),'post_text':f.get('post_text','') or '', 'published_at':f.get('published_at','') or '', 'source_group':'new-snapshot'}
excluded_ids=set();excluded_hash=set();excluded_uid=set()
prior=lines(work/'holdout-200.jsonl')
for r in prior:excluded_ids.add(r['comment_id']);excluded_hash.add(sha(r.get('text','')));excluded_uid.add(r.get('customer_uid',''))
benchmark=json.loads((root/'work/xhs-topic-pool-evaluation/sample-comparison.json').read_text(encoding='utf-8-sig'))['samples']
for r in benchmark:excluded_hash.update([r.get('source_text_sha256'),sha(r.get('anonymous_original_comment',''))])
for n in [124,142,264,511,671,1094,976,894,1043]:
 c=old[n-1];excluded_uid.add(c.get('platform_uid',''))
 for z in c.get('comments',[]):excluded_ids.add(z['original_fields'].get('comment_id'));excluded_hash.add(sha(z['original_fields'].get('text','') or ''))
for n in [91,128,161,214,653,681,1010,175,69,13,19]:
 c=new[n-1];excluded_ids.add(c.get('comment_id'));excluded_uid.update(c.get('customer_uids',[]));excluded_hash.update(sha(t or '') for t in c.get('comment_text_variants',[]))
extra=json.loads((work/'rules/coverage-supplement.json').read_text(encoding='utf-8-sig'))['records']
for r in extra:excluded_ids.add(r['comment_id']);excluded_hash.add(sha(r.get('original_text','')))
for r in lines(work/'backlog-57-reviewed.jsonl'):excluded_ids.add(r.get('comment_id'));excluded_hash.add(sha(r.get('t','')))
cli_files=sorted((work/'increments').glob('*/input.jsonl'))
for p in cli_files:
 for r in lines(p):excluded_ids.add(r.get('comment_id'));excluded_hash.add(sha(r.get('comment_text','') or ''))
excluded_uid.discard('');excluded_ids.discard(None);excluded_hash.discard(None)
eligible=[r for r in rows.values() if r['text'].strip() and r['comment_id'] not in excluded_ids and sha(r['text']) not in excluded_hash and (not r['customer_uid'] or r['customer_uid'] not in excluded_uid) and not r.get('source_conflict')]
eligible.sort(key=lambda r:sha('fangyu-v2-independent-20261029|'+r['comment_id']))
seen_uid=set();seen_text=set();selected=[]
def add(r,stratum):
 uid=r['customer_uid'] or r['comment_id'];h=sha(r['text'])
 if uid in seen_uid or h in seen_text:return False
 seen_uid.add(uid);seen_text.add(h);selected.append({**r,'stratum':stratum});return True
for r in eligible:
 if len(selected)>=100:break
 add(r,'固定散列常规样本')
edge=re.compile('不|没|无|拒|已|明年|去年|个月|哪里|什么|多少|预算|养|宠|看房|联系|转租|招租|合租|一楼|地铁')
for r in eligible:
 if len(selected)>=200:break
 if edge.search(r['text']):add(r,'定向困难样本')
assert len(selected)==200
for i,r in enumerate(selected,1):r['review_key']=f'V{i:03d}'
payload=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in selected);(here/'frozen-input.jsonl').write_text(payload,encoding='utf-8')
for name,start,end in [('a',0,70),('b',70,140),('c',140,200)]:
 (here/f'shard-{name}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in selected[start:end]),encoding='utf-8')
paths=[src/'old-snapshot.jsonl',src/'new-snapshot.jsonl',work/'holdout-200.jsonl',root/'work/xhs-topic-pool-evaluation/sample-comparison.json',work/'rules/coverage-supplement.json',work/'backlog-57-reviewed.jsonl']+cli_files
rules=[root/'outputs/方隅双平台文本业务/筛选与分类规则/筛选与分类业务规则.md',work/'increment-review-contract.md']
manifest={'rule_version':'business-text-20261029-v2','source_hashes':{str(p):filehash(p) for p in paths},'rule_hashes':{str(p):filehash(p) for p in rules},'frozen_input_sha256':filehash(here/'frozen-input.jsonl'),'input_count':200,'ordinary':100,'directed':100,'eligible_before_identity_dedupe':len(eligible),'sampling':'固定comment_id散列；100常规加100定向；本人身份及评论文本去重','prior_exclusions':['首批200','32条旧难例','22条定向抽核相关客户','17条补充案例','57条历史补核','所有当前增量CLI输入'],'exclude_comment_ids_count':len(excluded_ids),'exclude_text_hashes_count':len(excluded_hash),'exclude_customer_uids_count':len(excluded_uid),'rule_locked_before_review':True,'no_platform_requests':True,'labels_are_user_gold':False,'no_accuracy_claim':True}
(here/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'selected':len(selected),'eligible':len(eligible),'frozen_input_sha256':manifest['frozen_input_sha256'],'cli_inputs_excluded':len(cli_files)},ensure_ascii=False))
