import json,collections
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(s) for s in (p/'shard-c.jsonl').read_text(encoding='utf-8').splitlines()]
def S(s):return {int(x) for x in s.split()}
supply=S('143 144 145 150 151 152 158 162 163 164 165 166 168 169 171 172 174 175 178 180 181 182 183 184 188 189 191 193 194 195 196 197 198')
discussion=S('141 142 147 149 154 155 156 161 170 176 177 179 185 186 187 190 192 199')
unknown=S('148 153 159 173 200')
demands={
 146:('high','本人明确询问短租价格；租赁语境来自本人，即使标题未注明出租。',[('价格预算','什么价格','ask'),('入住与租期','短租','ask')]),
 157:('high','本人询问转租房整租价格。',[('价格预算','多少钱','ask'),('户型面积与居住方式','整租','ask')]),
 160:('high','本人对转租房询问价格。',[('价格预算','多少钱','ask')]),
 167:('medium','本人以“我们要租房的”表达租房群体寻找房东的困难。',[]),
}
regions={145:'东源名都西区',150:'15号线沿线',151:'长寿路',158:'吴中路小区',162:'罗家锦苑',163:'莘庄地铁',164:'南陈路',165:'普陀桃浦新村地铁站',168:'万源新城南区',169:'杨浦区',171:'上海西站地铁口',172:'宝钢三村',174:'梅川路红星美凯龙附近',175:'肇嘉浜路地铁口',178:'世纪公园',180:'普陀区',181:'静安区愚园路',182:'浦东2号线凌空路地铁站附近',183:'嘉定江桥万达泰宸沙河茗苑',184:'潍坊',188:'九号线七宝',189:'名都城',191:'御桥地铁站',194:'上海地铁5号线萧唐地铁站附近',195:'长宁区古北一期',196:'上海徐汇',198:'九亭'}
times={143:[('10/1起租','move_in','supply')],145:[('最好在10月底转租出去','other','supply'),('还有九个月','lease_duration','current_home')],151:[('租期到明年三月份','lease_duration','supply')],164:[('随时看房','viewing','supply'),('随时入住','move_in','supply')],169:[('2026.10.28后可入住','move_in','supply'),('现可看房','viewing','supply')],183:[('合同到11月底','lease_duration','supply')],196:[('随时可以看房入住','other','supply')]}
unknown_notes={148:'短片段被截断，仅有地区和价格，无法确认本人是提供房源还是寻找房源。',153:'仅给出租房及地铁口片段，不能确定是求租、推荐或供给。',159:'只说看不到“你的”，直接回复对象及需求不明。',173:'只有地段与户型描述，缺少上下文确定供需角色。',200:'只问小区，标题没有明确是出租、出售或体验，需核对对象和本人目的。'}
out=[]
for d in rows:
 n=int(d['review_key'][1:]);t=d['text'];a=dict(role='unknown',demand_state='unknown',interest='uncertain',topics=[],target_regions=[],time_mentions=[],other_constraints=[],possible_topics=[],evidence=[t],reason='供需对象或本人意图无法确认。',context_used=['own'],needs_review=[])
 if n in supply:
  a.update(role='supply',interest='unrelated',reason='评论提供、转租、推荐房源或提供找房服务，没有明确表达本人另找房。')
  if n in regions:
   q=regions[n];assert q in t
   a['target_regions'].append(dict(text=q,quote=q,relation='offered',group_relation='unknown',condition_scope='所提供或推荐的信息；不代表本人求租地区'))
  if n==184:a['needs_review'].append('“潍坊”地点具体含义和城市未由本人说明。')
  if n in (144,171,174,182):a['needs_review'].append('提供或推荐房源，但本人是否房东及其权限未明确。')
  if n==143:a['needs_review'].append('文中说“已租”，评论发布时前后时间关系和目前房态不可据此重新确认。')
 elif n in discussion:
  a.update(role='discussion',interest='unrelated',reason='评论为历史体验、建议、观点或交流群信息，没有明确新的本人求租。')
  if n in (149,177,186):a['needs_review'].append('所述费用或租住情况是既有经历，不是新的预算或求租要求。')
  if n==187:a['needs_review'].append('明确已搬离旧房并入住另一处，未表达新求租。')
 elif n in demands:
  level,reason,ts=demands[n];a.update(role='demand',demand_state='active_at_comment',interest=level,reason=reason)
  a['topics']=[dict(pool=pool,quote=quote,polarity=pol,subject='own_demand',condition_scope='询问此房源条件') for pool,quote,pol in ts]
  a['needs_review'].append('仅能判断评论发表时的兴趣，当前是否继续找房未核实。')
  if n in (157,160):a['context_used'].append('title')
  if n==146:a['needs_review'].append('明确短租询价，但住宅或其他用途及具体租期未明。')
  if n==167:a['needs_review'].append('所指“我们”可能是泛指租客，需核实是否本人正在寻找。')
 else:
  assert n in unknown,n
  a['needs_review'].append(unknown_notes[n])
  if n==200:a['topics']=[dict(pool='位置通勤',quote='什么小区',polarity='ask',subject='unresolved',condition_scope='询问对象未核')];a['context_used'].append('title')
 for q,role,subject in times.get(n,[]):
  assert q in t
  a['time_mentions'].append(dict(quote=q,time_role=role,subject=subject,anchor_source='comment_published_at' if d['published_at'] else 'unknown',anchor_time=d['published_at'] or None,normalized=None,verification='原词保留；归一化日期及当前状态未核'))
 if a['role']=='demand':
  a['mother_assessment']={'candidate_approved_mother':'1' if n!=146 else '8','status':'conditional_only','reason':'仅作条件候选；需核实当前需求、可承接区域及实际房源条件。第1条还需核实账号确为住户且优惠真实有效；第8条需核实实际接受所需租期。未获发送授权。','sendable':False}
 else:a['mother_assessment']={'candidate_approved_mother':None,'status':'not_selected','reason':'未确认本人当前租住需求，或属于供给、讨论，不能套用获客母句。','sendable':False}
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],**a,human_confirmed=False,send_authorized=False,store_assignment=None))
assert len(rows)==len(out)==60
assert {(r['review_key'],r['comment_id']) for r in rows}=={(r['review_key'],r['comment_id']) for r in out}
for r,o in zip(rows,out):
 for e in o['evidence']+[x['quote'] for x in o['topics']]+[x['quote'] for x in o['target_regions']]+[x['quote'] for x in o['time_mentions']]:assert e in r['text'],(o['review_key'],e)
 assert not(o['role']=='unknown' and o['interest']=='unrelated')
(p/'reviewed-c.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
val={'inputs':len(rows),'outputs':len(out),'id_pairs_equal':True,'all_quotes_verbatim':True,'role_counts':dict(collections.Counter(x['role'] for x in out)),'needs_review_count':sum(bool(x['needs_review']) for x in out),'human_confirmed':False,'send_authorized':False}
(p/'c-validation.json').write_text(json.dumps(val,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(val,ensure_ascii=False,indent=2))
