from manage import *
facts=['原问句指标及本人找房计划待核','通用介绍仍须真实住户、介绍资格及同店优惠时效和条件']
changes={'D6473':dict(demand_state='active_at_comment',interest='high',reason='本人明确在余杭永福搜索房源并称难找，已是实际找房动作；具体预算未给不应降为未知意向。',needs_review=['需补预算、户型、入住计划，并核目前是否仍在找房'],reply_plan=first(0,23,'D6473')['reply_plan']),
'D6477':dict(topics=[tp('户型面积与居住方式','一室一厅','require')],reason='在找房是需求动作，不单独当作看房联系；明确一室一厅高意向保留。'),
'D6507':dict(role='demand',demand_state='active_at_comment',interest='medium',reason='出租从业者带看住房语境中的短询保留住房询盘；计量对象仍留候选。',needs_review=['需澄清所问为租价还是面积及当前找房计划'],reply_plan=plan(1,True,facts)),
'D6556':dict(role='demand',demand_state='active_at_comment',interest='high',reason='明确人才公寓招租正文下问多少米，有住房询租动作；不因指标歧义丢掉需求，价格面积仍仅候选。',needs_review=['多少米指租价还是面积需澄清，当前需求及目标地区待补'],reply_plan=plan(1,True,facts)),
'D6694':dict(role='unknown',demand_state='unknown',interest='uncertain',topics=[],reason='房源帖下单独你好只是招呼，未明租赁诉求，不确认为当前找房或联系池。',needs_review=['招呼目的及本人是否求租待核'],reply_plan=plan()),
'D6794':dict(role='demand',demand_state='unknown',interest='medium',reason='本人称对愚园路住房心动，保留弱住房关注，尚无找房推进证据。',needs_review=['仅心动表达，是否有实际租住计划待核'],reply_plan=plan(1,True,facts)),
'D6541':dict(reason='本人询问一居室与一房一厅的租价，不能把一房一厅误写为两居。')}
save(0,23,'D6450 D6452 D6456 D6459 D6462 D6701 D6706 D6708 D6714 D6716 D6465 D6469 D6471 D6475 D6480 D6643 D6648 D6650 D6653 D6657 D6660 D6482 D6484 D6486 D6488 D6491 D6493 D6495 D6497 D6499 D6501 D6662 D6664 D6666 D6668 D6670 D6672 D6675 D6678 D6680 D6512 D6725 D6527 D6529 D6533 D6537 D6543 D6740 D6742 D6745 D6747 D6545 D6564 D6566 D6568 D6570 D6572 D6574 D6760 D6762 D6764 D6766 D6768 D6770 D6772 D6576 D6578 D6580 D6582 D6584 D6586 D6588 D6590 D6592 D6594 D6596 D6598 D6602 D6604 D6606 D6608 D6611 D6613 D6615 D6617 D6619 D6622 D6624 D6626 D6628 D6632 D6635 D6637 D6640 D6682 D6690 D6727 D6729 D6732 D6734 D6736 D6756 D6758 D6774 D6776 D6778 D6780 D6782 D6784 D6786 D6788 D6790 D6792',changes,'逐条读取本人及正文，原判预算户型否定、宠物、期限、供方与一般建议的区分可保留；未把收入/他人条件转为本人预算或把办公用途当住宅。')
