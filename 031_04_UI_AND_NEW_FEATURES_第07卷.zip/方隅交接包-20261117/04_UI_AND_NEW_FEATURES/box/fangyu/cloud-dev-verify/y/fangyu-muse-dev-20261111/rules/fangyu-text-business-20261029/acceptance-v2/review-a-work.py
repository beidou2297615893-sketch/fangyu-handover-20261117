import json,pathlib,collections
p=pathlib.Path('work/fangyu-text-business-20261029/acceptance-v2')
rows=[json.loads(x) for x in (p/'shard-a.jsonl').open(encoding='utf-8')];by={int(x['review_key'][1:]):x for x in rows};out={}
def ids(s):return [int(x) for x in s.split()]
def group(s,role,state,interest,reason,needs=None,ctx=('own','title')):
 for n in ids(s):
  d=by[n];out[n]={'review_key':d['review_key'],'comment_id':d['comment_id'],'customer_uid':d['customer_uid'],'role':role,'demand_state':state,'interest':interest,'topics':[],'target_regions':[],'time_mentions':[],'other_constraints':[],'possible_topics':[],'evidence':[d['text']],'reason':reason,'context_used':[x for x in ctx if x=='own' or (x=='title' and d.get('post_title')) or (x=='parent' and d.get('parent_text')) or (x=='body' and d.get('post_text'))],'needs_review':list(needs or []),'mother_assessment':{'status':'不适用或尚不能选择','approved_candidates':[],'conditions':['需确认本人需求、说话人身份及授权后再判断；不生成或发送回复。']},'human_confirmed':False,'send_authorized':False,'store_assignment':None}
group('2 9 10 12 13 15 16 21 24 29 31 32 38 42 48 51 54 58 64 69','supply','unknown','unrelated','本人发布房源、转租、租房服务或群信息，未明确本人同时有新求租需求。')
group('11 17 19 23 25 28 30 35 37 40 41 43 49 53 55 56 57 59 60 65 66 70','discussion','unknown','unrelated','评论讨论见闻、经历、意见或其他话题，未明确新的本人住宅租赁需求。')
group('1 3 4 5 6 7 8 14 18 20 22 26 27 33 36 39 44 45 46 50 52 61 62 63 67','unknown','unknown','uncertain','本人身份、说话对象或当前住宅租赁意图无法从现有资料确认。',['核对直接回复对象、评论意图及是否可租住宅。'])
group('34','demand','active_at_comment','high','本人正在找短租，明确租期、预算上限及独卫、洗衣机和非合租要求。',['“15张”具体金额及预算是否包括所有必付费用需核对；目标地区未在本人评论说明。'])
group('47','demand','active_at_comment','high','在具体租房帖下询问是否方便停车，属于当时住宅房源询盘。',['核对停车条件与当前房源有效性。'])
group('68','demand','ended','unrelated','本人明确说已经找到房子，未提新需求。')
# Additional decisions remain explicit rather than inferred from titles.
out[1]['reason']='“私”可能是求私信，也可能回应其他人请求；父评论关系未知。';out[1]['needs_review']=['核对说话者与父评论的直接关系，不能将对方看房意向转为本人需求。'];out[1]['context_used']=['own','title','parent']
for n in (3,4):out[n]['reason']='向求租者问是否考虑某区域，但未明确是否持有或推荐可租房源。';out[n]['needs_review']=['核对供需身份；地点是向对方提出的候选，不能认作本人目标地区。']
out[5]['reason']='问具体小区，但父评论与本评论的直接关系不明，无法确认本人住房需求。';out[5]['needs_review']=['核对父评论是否直接对象及该人询问目的。'];out[5]['context_used']=['own','title','parent']
for n in (6,8,20,26,33,39,50,52,62,67):out[n]['reason']='本人只提供地点、房屋描述或数量，未明确是推荐、供应还是本人找房。';out[n]['needs_review']=['补直接对话，区分房源推荐与本人求租。']
out[7]['reason']='引导看主页的服务式公寓，可能推荐或提供房源；未明确身份和交易对象。';out[7]['needs_review']=['核对主页内容和本人供需身份。']
out[14]['reason']='本人说是房东，但没有给出房源或新需求，不能只凭身份断定当下提供住房。';out[14]['needs_review']=['核对房东是否主动招租及是否另有本人需求。']
out[18]['reason']='“完美符合朝向”缺少直接回复对象，既不能判定房源供需，也不能推定本人的朝向要求。';out[18]['needs_review']=['核对评论对象及是谁的朝向条件。']
out[22]['reason']='数字“7256”含义不清，父评论关系未确定。';out[22]['needs_review']=['核对数字所指及直接回复关系，不能将父评论内容当本人条件。'];out[22]['context_used']=['own','title','parent']
out[27]['reason']='“9000k”没有单位或对象，既可能是价格也可能是其他编码。';out[27]['needs_review']=['核对数值的单位、对象和供需身份。']
out[36]['reason']='比较隔音，但标题是两个公寓的推荐讨论，未明确评论者正在租房或直接询某套可租房。';out[36]['needs_review']=['核对本人是否正在找房及所比较房源状态。']
out[44]['reason']='欢迎咨询可能是推广，缺少明确供给、出租状态或直接对象。';out[44]['needs_review']=['核对发布者身份及房源交易类型。']
out[45]['reason']='让对方查看视频号但未明确“很多”的对象和本人供需身份。';out[45]['needs_review']=['核对所推荐内容及是否提供住宅房源。']
out[46]['reason']='本人问地点价格，但标题只描述住房和数字，未明确当前可出租。';out[46]['needs_review']=['核对原帖是出租、出售还是生活展示，以及评论者本人用途。']
out[61]['reason']='“已丝注意查收”表明已私信，但父评论关系未知，不能认定是租客还是供应者。';out[61]['needs_review']=['核对私信对象和供需身份；不继承父评论房源条件。'];out[61]['context_used']=['own','title','parent']
out[63]['reason']='只有提及他人，无法确认本人住房需求。';out[63]['needs_review']=['核对提及对象和讨论目的。']
out[54]['needs_review']=['工作调动是转租原因；是否另找新住处及找房状态未明确，保留新需求待核。']
out[64]['needs_review']=['本人描述房源现无空房，不能认作当前可租或把供应条件当本人需求。']
# Exact own comment quotes, separate object, polarity and condition scope.
def topic(n,pool,q,polarity,subject='own_demand',scope=''):
 assert q in by[n]['text'];out[n]['topics'].append({'pool':pool,'quote':q,'polarity':polarity,'subject':subject,'condition_scope':scope})
def region(n,q,relation,group_relation='unknown',scope=''):
 assert q in by[n]['text'];out[n]['target_regions'].append({'text':q,'quote':q,'relation':relation,'group_relation':group_relation,'condition_scope':scope})
def possible(n,pools,q,why):
 assert q in by[n]['text'];out[n]['possible_topics'].append({'pools':pools,'quote':q,'subject':'unresolved','reason':why})
topic(34,'入住与租期','短租（半年以内）','require',scope='短租时长上限半年，计时起点未说')
topic(34,'价格预算','15张以内','require',scope='上限原话；“张”换算、计费周期和必付费用待核')
topic(34,'房内设施','有洗衣机独卫','require',scope='同一房源需有洗衣机及独立卫生间')
topic(34,'户型面积与居住方式','非合租','reject',scope='不接受合租')
topic(34,'看房联系','联系我','ask',scope='主动邀请联系，不构成预约或发送授权')
out[47]['other_constraints'].append({'quote':'好停车么','subject':'own_demand','polarity':'ask','condition_scope':'询问停车便利性，不推断具体车位或费用要求','type':'停车'})
possible(5,['位置通勤'],'具体哪个小区啊','父评论是否直接回复对象及本人是否求租待核')
possible(36,['房内设施'],'哪个隔音更好','比较隔音是明确问题，但本人当前是否找房未知')
possible(46,['位置通勤','价格预算'],'请问地点和价格','标题未明确当前出租，主题暂作询问候选')
possible(27,['价格预算','户型面积与居住方式'],'9000k','数值单位与用途不明，不正式归池')
# Offered areas: location is from advertiser's own comment only.
offered={2:'宝山7号线顾村公园 -美兰湖🚇沿线',9:'上海普陀区金沙江路地铁站附近',10:'地铁7号线上海大学站',12:'乐秀路地铁站附近',13:'镇坪路',15:'静安区愚园路',16:'近虹桥机场',21:'普陀长风这边威宁路',24:'闵行 浦江镇 世博家园 15街坊',29:'杨思三林世博',31:'天山华庭',32:'嘉定南翔',42:'嘉定丰庄',48:'宝山万达500米小区',51:'镇坪路岚皋路曹杨路新村路长寿路',54:'醉白池',58:'淞南',64:'宝山淞南',69:'威宁路地铁站滨谷广场'}
for n,q in offered.items(): region(n,q,'offered',scope='供应房源或服务覆盖范围；不作为本人目标租住地')
# Time annotations preserve own expressions and publication anchors. Naive timestamp remains timezone-unverified.
def time(n,q,role,anchor,norm,verify,subject):
 assert q in by[n]['text'];out[n]['time_mentions'].append({'quote':q,'time_role':role,'anchor_source':anchor,'anchor_time':by[n].get('published_at') if anchor=='published_at' else None,'normalized':norm,'verification':verify,'subject':subject})
time(34,'半年以内','lease_duration','none','不超过半年','起止日期、具体租期待核','own_demand')
time(15,'月底可搬','other','published_at','2026年10月底','发表时间含UTC；原话为本人搬出，不自动等同接租者入住日期。','supply')
time(52,'月底空出','other','published_at','未归一化','发表时间无时区，日期口径及本评论说话身份待核。','unresolved')
time(52,'已住两年','other','none','两年','所述为租客已住时长，不当成本人租期需求。','other_person')
time(56,'明天跑路','other','published_at','未归一化','“明天”应按平台发表时点时区换算；此记录为经历表达，平台显示时区需核对。','own')
# Approved original wording shortlist corresponds to accepted records, not first 10 numeric rows.
out[34]['mother_assessment']={'status':'仅条件候选，暂不可使用','approved_candidates':[{'template_number':19,'description':'短租期限','required':'核实门店可接收该租期且同一房源满足独卫、洗衣机、非合租、预算和地区等全部明确条件'}, {'template_number':34,'description':'多需求综合接话','required':'核实同一房源满足全部硬条件及预算口径，且介绍资格与优惠真实有效'}],'conditions':['目标地区和预算单位未明，实际房源、租期、优惠及账号身份均未核，不能承诺或发送。']}
out[47]['mother_assessment']={'status':'无匹配的已认可母句','approved_candidates':[],'conditions':['已认可母句未直接回答停车便利性；需核停车事实，且不得用楼层模板替代。']}
# Explain absent topic for genuine silence; no context inheritance.
for n in (2,9,10,12,13,15,16,21,24,29,31,32,38,42,48,51,54,58,64,69):out[n]['mother_assessment']={'status':'不适用','approved_candidates':[],'conditions':['本人为供给或推广，不能套求租母句。']}
for n in out:
 if out[n]['role']=='unknown':out[n]['mother_assessment']={'status':'暂缓','approved_candidates':[],'conditions':['本人需求或身份未确认，不选择母句。']}
 if out[n]['role']=='discussion':out[n]['mother_assessment']={'status':'不适用','approved_candidates':[],'conditions':['没有明确新求租需求，不选择求租母句。']}
out[68]['mother_assessment']={'status':'不适用','approved_candidates':[],'conditions':['本人已找到房子且未说新需求。']}
result=[out[n] for n in sorted(out)];assert len(result)==70
keys={(x['review_key'],x['comment_id']) for x in rows};outkeys={(x['review_key'],x['comment_id']) for x in result};errs=[]
for x in result:
 source=by[int(x['review_key'][1:])]['text']
 quotes=x['evidence']+[t['quote'] for t in x['topics']]+[t['quote'] for t in x['target_regions']]+[t['quote'] for t in x['time_mentions']]+[t['quote'] for t in x['other_constraints']]+[t['quote'] for t in x['possible_topics']]
 for q in quotes:
  if q not in source:errs.append([x['review_key'],'quote',q])
 if x['role']=='unknown' and x['interest']!='uncertain':errs.append([x['review_key'],'unknown role'])
 if x['role']=='supply' and x['topics']:errs.append([x['review_key'],'supply incorrectly topics'])
 if x['human_confirmed'] or x['send_authorized'] or x['store_assignment'] is not None:errs.append([x['review_key'],'authority'])
with (p/'reviewed-a.jsonl').open('w',encoding='utf8',newline='\n') as f:
 for x in result:f.write(json.dumps(x,ensure_ascii=False)+'\n')
report={'input_count':len(rows),'output_count':len(result),'input_unique_key_count':len(keys),'output_unique_key_count':len(outkeys),'id_sets_equal':keys==outkeys,'all_own_quotes_verbatim':not errs,'validation_errors':errs,'role_counts':dict(collections.Counter(x['role'] for x in result)),'interest_counts':dict(collections.Counter(x['interest'] for x in result)),'human_gold':False,'send_authorized':False,'note':'机器校验只验证数量、逐字证据、枚举约束，不证明语义准确率。'}
(p/'a-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))


