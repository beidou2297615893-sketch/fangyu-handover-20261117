"""Apply the user's AI-first decision to local policy/state only; no API/platform calls."""
import json
from pathlib import Path
from datetime import datetime, timezone

W = Path(__file__).resolve().parent
R = W.parents[1]
now = datetime.now().astimezone().isoformat()
archive = W / 'policy-history' / ('ai-first-' + datetime.now().strftime('%Y%m%dT%H%M%S'))
archive.mkdir(parents=True, exist_ok=False)

def save(path, value):
    if path.exists():
        (archive / path.name).write_bytes(path.read_bytes())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) if not isinstance(value, str) else value, encoding='utf-8')

decision = {
    'approved_at_recorded': now,
    'authority': 'user_latest_instruction',
    'user_instruction': '不要用纯规则版；额度足够时全部用AI初筛和细筛，优先质量，不要漏人',
    'screening_scope': 'every_eligible_unanalyzed_comment',
    'initial_screening': 'AI_semantic_judgment',
    'detailed_screening': 'AI_semantic_judgment',
    'pure_rules_production_enabled': False,
    'model_input_delivery': 'batch_comments_with_shared_post_context',
    'reply_text': 'local_approved_mother_templates_only',
    'uncertain_handling': 'retain_and_review_not_discard',
    'historical_results': 'preserve_no_automatic_full_rerun',
    'ordinary_usage_allowed_at_check': False,
    'ordinary_used_percent_at_check': 100,
    'existing_credits_available': True,
    'credits_spending_authorized_for_new_bulk_jobs': False,
    'quota_decision': 'await_user_choice_on_existing_credits',
    'source_database_writes': False,
    'platform_calls': 0,
    'send_authorized': False,
}
save(W/'rules/评论分析执行方式.json', decision)

handoff = W/'双平台分工与后台文本接续.md'
text = handoff.read_text(encoding='utf-8')
text = text.replace(text.split('\n\n')[1], '**最新优先口径：本人已明确取消纯规则版。所有新增合格登记评论的初筛与细筛均由AI作语义判断；按帖共享必要上下文、批量返回结构化标签，减少重复输入，不省略任何人的判读。回复只用已认可母句本地套用，不用AI逐条重写。旧模型结果保留，不全量重跑。本地去重、来源资格、格式与证据校验继续使用，但不得用规则命中替代意向判断。当前普通额度已100%、ordinaryUsageAllowed=false；新增5806条已冻结，尚未派工，等待本人选择是否使用现有额外credits。不得自动购买或默认为已同意额外credits消费。纯规则实验归档，不等待其通过验收才处理AI文本。新指令以 rules/评论分析执行方式.json 为准。')
save(handoff, text)

state_path = W/'当前文本处理运行状态.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
batch = W/'douyin-registered-v2/increments/097511857b51e174'
meta = json.loads((batch/'manifest.json').read_text(encoding='utf-8'))
assert meta['previous_comments'] == 12409 and meta['new_comments'] == 5806
state['douyin'].update({
    'state':'frozen_awaiting_quota_choice',
    'known_eligible_comments':meta['eligible_snapshot_comments'],
    'unprocessed_registered_comments':meta['new_comments'],
    'pending_batch':str(batch),
    'default_model_per_comment':True,
    'ordinary_model_calls_disabled':True,
    'ordinary_model_calls_disabled_reason':'ordinary_quota_exhausted_pending_extra_credit_choice',
    'screening_policy':'all_eligible_comments_AI_initial_and_detailed',
    'reply_generation_policy':'local_approved_mothers',
})
state['pipeline_migration'].update({'status':'cancelled_by_user','pure_rule_pipeline_enabled':False,'updated_at':now,'replacement':'AI_semantic_screening_with_local_mother_replies'})
state['last_increment_check'] = {'checked_at':now,'eligible_snapshot_comments':meta['eligible_snapshot_comments'],'classified_comments':meta['previous_comments'],'pending_comments':meta['new_comments'],'batch_directory':str(batch),'source_database_modified':False,'platform_calls':0}
state['quota_check'] = {'checked_at':now,'ordinary_usage_allowed':False,'ordinary_used_percent':100,'existing_credits_available':True,'bulk_credit_spending_choice':'pending','reset_time_utc':datetime.fromtimestamp(1793774194,timezone.utc).isoformat()}
save(state_path, state)
save(batch/'model-work-status.json', {'state':'waiting_for_credit_authorization','input_comments':5806,'dispatched_comments':0,'completed_comments':0,'owner':None,'initial_and_detailed_judgment':'AI','mother_reply_generation':'local','created_at':now,'source_modified':False,'platform_calls':0})

manifest_path = W/'local-rule-pipeline/manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
manifest.update({'status':'disabled_by_user','production_enabled':False,'default_route':'disabled','disable_reason':'User explicitly selected AI for all initial and detailed screening; pure rules were not accepted for production.','updated_at':now})
save(manifest_path,manifest)

doc = '''# 评论筛选与回复的最新执行方式

按最新决定，每条合格登记评论都由 AI 做初筛和细筛，优先保证判断质量。纯规则分类版不启用。

1. 本地登记来源、核对评论身份和去重，避免重复分析；误采来源单独留痕。
2. AI 初筛判断谁有需求、谁在提供房源，以及是否只是讨论。供需混合时保留本人新需求。
3. AI 细筛判断意向、否定条件、时间、目标地区和多个需求池。评论自身优先，含糊时补已有标题、正文和上级评论；同帖上下文合并提供，减少重复输入。
4. 资料不清、观点冲突及可能漏判的线索保留待核，不凭一个词删除。所有原记录和判断依据可回查。
5. 本地按分类结果选用已认可母句，只填有依据的资料，不让 AI 逐条重写回复。判断不清或事实不足的，暂缓套用涉及承诺的句子。
6. 发送由对应平台按授权处理，分类结果和草稿不代表已经发送。

已有分析保留，新评论增量接续；不因换流程全量重跑。小红书与抖音共用业务口径，各自独立记账。来源门店、客户目标地区和最终指派门店分别保留，IP仅作辅助。

模型消耗按实际调用记录核对。软件后续可接 DeepSeek；模型选择以实际质量、额度和费用为准，不保证绝不漏判，也不把模型判断称为人工金标。普通额度不足时保留待处理队列，额外消费按明确授权执行。
'''
save(R/'outputs/方隅双平台文本业务/筛选与分类规则/百万级评论处理与软件接入说明.md',doc)
with (W/'local-rule-pipeline/progress.md').open('a',encoding='utf-8') as f:
    f.write('\nRuling superseded by latest user: 不使用纯规则版；所有合格新增评论初筛、细筛均由AI判断，母句仍本地。停止纯规则修复/上线流程，保留实验与历史证据。普通额度已100%，ordinaryUsageAllowed=false，有现有credits但尚未获新增批量消费选择；5806条已冻结、未派工，等待额度选择，不造已完成回执。\n')
print(json.dumps({'policy':'AI_all_initial_and_detailed','pure_rules_enabled':False,'classified':12409,'pending':5806,'frozen_batch':str(batch),'quota_gate':'await_existing_credit_choice','backup':str(archive),'platform_calls':0},ensure_ascii=False))
