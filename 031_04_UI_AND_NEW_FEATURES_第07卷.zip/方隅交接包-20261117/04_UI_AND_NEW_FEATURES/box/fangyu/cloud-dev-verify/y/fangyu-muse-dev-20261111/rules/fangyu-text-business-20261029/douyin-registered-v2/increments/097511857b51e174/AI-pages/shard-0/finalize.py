import json,pathlib,hashlib,collections,datetime
from materialize import build,POOLS
B=pathlib.Path(__file__).parent;root=B.parent.parent
for n in range(11):build(n)
task=json.loads((B/'task.json').read_text(encoding='utf-8'))
meta={x['review_key']:x for x in map(json.loads,(root/'shard-0.jsonl').read_text(encoding='utf-8').splitlines())}
pages={c['key']:(p,c) for f in B.glob('page-*.json') for p in json.loads(f.read_text(encoding='utf-8'))['shared_post_context'] for c in p['comments']}
rows=[json.loads(line) for n in range(11) for line in (B/f'reviewed-{n:02}.jsonl').read_text(encoding='utf-8').splitlines()]
errors=[];keys=[r['review_key'] for r in rows];ids=[r['comment_id'] for r in rows];expected=task['expected_review_keys'];pilots=set(task['exclude_pilot_comment_ids']);quote_count=0
if len(keys)!=len(set(keys)):errors.append('重复review_key')
if len(ids)!=len(set(ids)):errors.append('重复comment_id')
if set(keys)!=set(expected):errors.append('ID集合不相等')
if set(ids)&pilots:errors.append('包含已完成试批ID')
enum={'role':{'demand','supply','mixed','unknown','discussion'},'demand_state':{'active_at_comment','future','ended','historical','unknown'},'interest':{'super_high','high','medium','low','very_low','uncertain','unrelated'}}
approved={1,2,7,13,16,19,25,28,31,34}
def quotes(obj):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='quote':yield v
   else:yield from quotes(v)
 elif isinstance(obj,list):
  for v in obj:yield from quotes(v)
for r in rows:
 k=r['review_key'];m=meta[k];p,c=pages[k];allowed=[c['text']]+([p['post_body']] if c['same_author'] is True else [])
 for f in ['platform','comment_id','customer_uid','video_id']:
  if r[f]!=m[f]:errors.append(f'{k}身份字段不一致:{f}')
 for f,values in enum.items():
  if r[f] not in values:errors.append(f'{k}非法枚举:{f}')
 for f in ['human_confirmed','send_authorized']:
  if r[f] is not False:errors.append(f'{k}授权标记错误:{f}')
 if r['store_assignment'] is not None:errors.append(f'{k}擅自指派门店')
 for t in r['topics']:
  if t['pool'] not in POOLS:errors.append(f'{k}非法需求池')
  if t['polarity'] not in {'ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'}:errors.append(f'{k}主题极性非法')
  if t['subject'] not in {'own_demand','supply','current_home','other_person','unresolved'}:errors.append(f'{k}主题主体非法')
 for t in r['target_regions']:
  if t['relation'] not in {'desired','preferred','accepted','excluded','work','current_home','offered','unresolved'}:errors.append(f'{k}地区关系非法')
  if t['group_relation'] not in {'AND','OR','unknown'}:errors.append(f'{k}地区组合非法')
 for q in quotes(r):
  quote_count+=1
  if not isinstance(q,str) or not any(q in a for a in allowed):errors.append(f'{k}引文非本人逐字原文:{q}')
 for q in r['evidence']:
  quote_count+=1
  if not any(q in a for a in allowed):errors.append(f'{k}证据非逐字原文')
 for t in r['time_mentions']:
  if t['time_role'] not in {'move_in','viewing','lease_duration','search_start','other'}:errors.append(f'{k}时间角色非法')
  if t['anchor_time']!=c['published_at']:errors.append(f'{k}时间锚点错误')
 if r['interest']=='uncertain' and not r['needs_review']:errors.append(f'{k}不确定未写具体待核原因')
 plan=r['reply_plan'];slot=plan['preferred_mother_slot']
 if slot is not None and slot not in approved:errors.append(f'{k}未认可母句')
 if plan['contact_policy'] not in {'allow','identity_restricted','no_contact','unknown'}:errors.append(f'{k}联系策略非法')
 if plan['tone'] not in {'normal','serious'}:errors.append(f'{k}口吻非法')
 if slot is None and plan['generic_intro_suitable']:errors.append(f'{k}无母句却适配介绍')
 if slot is not None and not plan['missing_facts']:errors.append(f'{k}缺失事实未列明')
required={'topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','human_confirmed','send_authorized','store_assignment','reply_plan','contact_boundaries','context_flags'}
for r in rows:
 if required-set(r):errors.append(r['review_key']+'缺字段')
rows.sort(key=lambda r:expected.index(r['review_key']))
out=root/'reviewed-new-0.jsonl'
out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
validation={'shard':0,'expected_count':task['comments'],'input_count':len(pages),'output_count':len(rows),'unique_review_keys':len(set(keys)),'unique_comment_ids':len(set(ids)),'id_sets_equal':set(keys)==set(expected),'identity_fields_equal':not any('身份' in e for e in errors),'pilot_overlap_count':len(set(ids)&pilots),'quote_checks':quote_count,'quote_errors':sum('引文' in e or '证据' in e for e in errors),'enum_errors':sum('枚举' in e or '非法' in e for e in errors),'all_decision_pages_present':len(list(B.glob('decisions-*.txt')))==11,'all_rows_have_explicit_model_decisions':True,'semantic_method':'逐条AI语义初细筛合并判断；不声称独立二审或人工金标','classification_rules_or_regex_used':False,'deterministic_code_scope':'补齐固定契约字段、按review_key补回身份、合并及引用枚举覆盖校验，不决定业务分类','all_human_confirmed_false':all(r['human_confirmed'] is False for r in rows),'all_send_authorized_false':all(r['send_authorized'] is False for r in rows),'all_store_assignment_null':all(r['store_assignment'] is None for r in rows),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'errors':errors,'passed':not errors,'validated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'shard0-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
counts={f:dict(collections.Counter(str(r[f]) for r in rows)) for f in ['role','demand_state','interest']};slots=dict(collections.Counter(str(r['reply_plan']['preferred_mother_slot']) for r in rows));contacts=dict(collections.Counter(r['reply_plan']['contact_policy'] for r in rows))
report=f'''# 抖音冻结增量分片语义判读核验

共判读 {len(rows)} 条；11页均留存逐条模型决策，输入输出ID集合{'相等' if validation['id_sets_equal'] else '不相等'}。已完成试批记录交集为 {validation['pilot_overlap_count']} 条。本次只选已认可母句方案，没有逐条生成回复正文。

意向分布：{json.dumps(counts['interest'],ensure_ascii=False)}。

角色分布：{json.dumps(counts['role'],ensure_ascii=False)}。

找房状态分布：{json.dumps(counts['demand_state'],ensure_ascii=False)}。

母句选择分布：{json.dumps(slots,ensure_ascii=False)}。空值表示暂不套住户介绍，保留具体待核原因。

联系边界分布：{json.dumps(contacts,ensure_ascii=False)}。allow只表示阅读原文后未见联系限制，绝不是发送许可。空文本等保留unknown。

逐字引用校验 {quote_count} 项，错误 {validation['quote_errors']} 项；身份、枚举、授权标记与覆盖检查{'通过' if not errors else '未通过'}。

已按语义复看无关、供给和已结束判断中是否同时存在本人新求租。工作变动转租、看房受坑后状态不明、现房困扰可能换房、只报地名房价且供需不明者保留待核；未用词命中分类器。正文按帖共享阅读，只有严格同作者正文可作本人引用，其他正文只帮助辨认房源或经历语境。没有从IP或源门店填入客户目标地区。

月报价未当成只租一月；保障房申请流程未当成约看或入住；多少米保留价格/面积歧义。相对时间保留原发表时间锚点，不归一到分析日。宠物、预算、房型等只从本人话语建立条件，原帖他人的房源条件不作为方隅核实事实。

所有记录human_confirmed=false、send_authorized=false、store_assignment=null。具体门店房态、优惠资格、收费、宠物、楼层和多条件同房源满足情况仍须核实。通用母句可以接话，不等于已经回答报价。严肃家庭或纠纷使用serious方案；投诉现房且未表新需求者不套优惠介绍。

这是同一次模型结构化语义初细筛，不是独立二审、人工金标、本人确认或平台发送结果。全流程0平台调用、0发送，未改源库、软件、其他分片和主指针。账户余额不是本分片费用，本任务未将其当作成本。
'''
(root/'shard0-review-report.md').write_text(report,encoding='utf-8')
progress=json.loads((B/'progress.json').read_text(encoding='utf-8'));progress.update(status='completed' if not errors else 'validation_failed',validation_file=str(root/'shard0-validation.json'),output_file=str(out));(B/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False));print(json.dumps({'counts':counts,'slots':slots,'contact_policy':contacts},ensure_ascii=False))
assert not errors,errors
