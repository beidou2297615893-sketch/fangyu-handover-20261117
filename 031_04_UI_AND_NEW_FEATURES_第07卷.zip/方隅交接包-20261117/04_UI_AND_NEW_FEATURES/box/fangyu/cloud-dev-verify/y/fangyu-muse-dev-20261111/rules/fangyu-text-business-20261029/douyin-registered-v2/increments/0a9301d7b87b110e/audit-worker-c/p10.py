from decisions import *
a=original(10,'D2738'); b=original(10,'D2740')
emit(10,'''D2734 D2736 D2743 D2745 D2747 D2961 D2963 D2965 D2968 D2970 D2972 D2974 D2976 D2749 D2751 D2753 D2755 D2757 D2759 D2761 D2763 D2765 D2767 D2769 D2771 D2773 D2775 D2777 D2779 D2781 D2783 D2785 D2788 D2790 D2792 D2794 D2796 D2798 D2800 D2802 D2804 D2806 D2808 D2810 D2812 D2814 D2816 D2818 D2821 D2823 D2825 D2827 D2978 D2980 D2982 D2984 D2986 D2988 D2990 D2830 D2842 D2844 D2846 D2849 D2851 D2853 D2855 D2857 D2859 D2861 D2863 D2865 D2867 D2869 D2871 D2873 D2875 D2878 D2880 D2882 D2884 D2886 D2888 D2890 D2892 D2894 D2896 D2898 D2900 D2902 D2904 D2906 D2908 D2910 D2912 D2914 D2916 D2918 D2920 D2922 D2924 D2926 D2929 D2931 D2933 D2935 D2937 D2939 D2941 D2943 D2945 D2947 D2949 D2951 D2953 D2955 D2957''',{
'D2738':('环境好点是整体居住环境偏好，不能当具体房内设施；厨房等原需求保留。',dict(topics=a['topics'][:3],other_constraints=[dict(quote='环境好点的',detail='希望整体居住环境好一些，偏好未量化')])),
'D2740':('环境好是整体居住条件，保留合租、预算、位置和环境联立要求。',dict(topics=[t for t in b['topics'] if t['quote']!='要环境好的'],other_constraints=[dict(quote='要环境好的',detail='要求整体居住环境好，标准待澄清')])),
'D2959':('虽有租房攻略语境，房价仍可能询购买价格，先保留真实住房线索待核。',dict(role='unknown',demand_state='unknown',interest='uncertain',topics=[topic('价格预算','北京哪里的房价便宜',subject='unresolved'),topic('位置通勤','北京哪里的房价便宜',subject='unresolved')],reason='询问北京便宜住房区域，租赁还是购买未明',needs_review=['本人是否正在租房或咨询买房待核'],reply_plan=plan()))
})
