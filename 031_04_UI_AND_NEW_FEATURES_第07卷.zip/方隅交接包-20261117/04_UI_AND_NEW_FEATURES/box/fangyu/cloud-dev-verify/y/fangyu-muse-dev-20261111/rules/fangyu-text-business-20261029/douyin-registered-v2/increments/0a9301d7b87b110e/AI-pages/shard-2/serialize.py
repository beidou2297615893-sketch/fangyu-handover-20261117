import json,pathlib,datetime,collections,hashlib
P=pathlib.Path(__file__).parent
ROOT=P.parent.parent
TASK=json.loads((P/'task.json').read_text(encoding='utf-8-sig'))
SOURCE={r['review_key']:r for r in map(json.loads,pathlib.Path(TASK['source_full_metadata_file']).read_text(encoding='utf-8-sig').splitlines())}
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
MOTHERS={m['slot']:m['required_facts'] for m in json.loads((ROOT.parents[2]/'approved-mothers-model-view.json').read_text(encoding='utf-8-sig'))}
CONTACT_BOUNDARIES=json.loads((P/'contact-boundary-decisions.json').read_text(encoding='utf-8'))
# Every disposition and quoted condition is explicitly supplied by the reviewing model.
# This file performs no keyword matching or semantic inference from source text.
KINDS={
 'X':('discussion','unknown','unrelated','对帖内容作讨论、建议或感叹，未表达本人当前找房。','allow'),
 'S':('supply','unknown','unrelated','提供房源或招租服务，未表达本人另找房。','allow'),
 'H':('demand','historical','unrelated','讲述本人既往租住经历，未表达新的找房动作。','allow'),
 'E':('demand','ended','unrelated','本人已租好或已结束找房，未表达新需求。','allow'),
 'U':('unknown','unknown','uncertain','短句指代或供需身份不清，保留线索待核。','unknown'),
 'D':('demand','active_at_comment','high','本人在租房语境具体询问或提出要求，按评论时的找房动作保留。','allow'),
 'M':('demand','unknown','medium','有住房关注或探索线索，尚未明确当前找房推进。','allow'),
 'V':('demand','active_at_comment','super_high','本人明确提出具体约看、预约或签租推进请求；未视为预约成功。','allow'),
 'F':('demand','future','low','本人明确以后才开始找房，目前未推进。','allow'),
 'W':('mixed','unknown','uncertain','本人有转租/退租及可能另找房动作，新需求是否落实待核。','allow'),
 'R':('discussion','unknown','uncertain','本人遇到现居/退租问题，后续是否另找房尚不清楚。','allow'),
 'B':('demand','active_at_comment','unrelated','本人所求为买卖或非住宅用途，未确认为住宅租赁。','allow')}
def make(line,page):
 parts=line.split('|');key,code=parts[:2];raw=SOURCE[key];txt=raw['comment_text'];kind=code[0]
 role,state,interest,reason,contact=KINDS[kind]
 slot=int(code[1:]) if code[1:] else None
 assert slot is None or slot in MOTHERS,(key,slot)
 out={k:raw[k] for k in ['review_key','comment_id','customer_uid','video_id','platform']}
 out.update(role=role,demand_state=state,interest=interest,topics=[],target_regions=[],time_mentions=[],other_constraints=[],possible_topics=[],evidence=[txt] if txt else [],reason=reason,context_used=['own','body'],needs_review=[],human_confirmed=False,send_authorized=False,store_assignment=None)
 out['contact_boundaries']=list(CONTACT_BOUNDARIES.get(key,[]))
 out['context_flags']=list(raw.get('context_flags') or [])
 if raw.get('post_author_same_as_commenter'):out['context_flags'].append('same_author_as_post')
 if raw.get('source_version_conflict'):out['context_flags'].append('source_version_conflict')
 plan=dict(preferred_mother_slot=slot,generic_intro_suitable=kind in 'DMV',tone='normal',missing_facts=[],caution=[],contact_policy=contact)
 for part in parts[2:]:
  if not part:continue
  k,v=part.split('=',1)
  if k.isdigit():
   for item in v.split('~'):
    item=item.replace('[TILDE]','~');pol='ask';subject='unresolved' if kind in 'UW' else 'own_demand';quote=item
    if '::' in item:
     meta,quote=item.split('::',1);m=meta.split(',');pol=m[0];subject=m[1] if len(m)>1 else subject
    out['topics'].append(dict(pool=POOLS[int(k)-1],quote=quote,polarity=pol,subject=subject,condition_scope=quote))
  elif k=='r':
   for item in v.split('~'):
    rel,quote=item.split(':',1);out['target_regions'].append(dict(text=quote,quote=quote,relation=rel,group_relation='unknown',condition_scope=quote))
  elif k=='gr':
   for r in out['target_regions']:r['group_relation']=v
  elif k=='t':
   for item in v.split('~'):
    tr,q=item.split(':',1);ts=raw.get('published_at_unix');anchor=datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat() if ts else None
    out['time_mentions'].append(dict(quote=q,time_role=tr,anchor_source='published_at_unix' if ts else None,anchor_time=anchor,normalized=None,verification='保留原词及可信评论时间锚；未以分析日代替，也未确认今天仍有效'))
  elif k=='n':out['needs_review'].append(v)
  elif k=='o':out['other_constraints'].append(dict(quote=v,subject='own_demand',description=v))
  elif k=='p':out['possible_topics'].append(dict(quote=v,candidate_pools=['价格预算','户型面积与居住方式'],ambiguity='计量对象不明，价格/面积仅作候选，不计为确定需求'))
  elif k=='why':out['reason']=v
  elif k=='c':plan['contact_policy']=v
  elif k=='g':plan['generic_intro_suitable']=v=='true'
  elif k=='m':plan['preferred_mother_slot']=None if v=='null' else int(v)
  elif k=='serious':plan['tone']='serious';plan['caution'].append('严肃或家庭场景去掉亲昵称呼，先确认实际住房诉求')
  elif k=='caution':plan['caution'].append(v)
  elif k=='state':out['demand_state']=v
  elif k=='interest':out['interest']=v
  else:raise ValueError((key,k))
 if raw.get('direct_parent_text'):out['context_used'].append('parent')
 if kind=='U' and not out['needs_review']:out['needs_review'].append('需确认短句指代及本人是否有住宅租赁需求')
 if kind in 'RW' and not out['needs_review']:out['needs_review'].append('需确认退租/现居变化后的本人新住房是否已落实')
 if kind=='M' and not out['needs_review']:out['needs_review'].append('需确认本人是否正在找房，不能将参观/比较视为明确推进')
 if kind in 'DV' and not out['needs_review']:out['needs_review'].append('需确认评论后是否仍在找房及原咨询是否已解决；未将当时意向视为今日有效')
 final=plan['preferred_mother_slot']
 if final:
  plan['missing_facts']=[MOTHERS[final],'原帖房源不能证明方隅同店同一房源事实；须核实位置承接及全部明确条件']
 if plan['generic_intro_suitable']:
  plan['missing_facts'].append('通用介绍仍需真实住户身份、介绍资格及同店优惠活动事实；未核实不承诺')
 if plan['contact_policy']=='identity_restricted':plan['caution'].append('需核发送身份是否符合本人限制；不得伪装个人房东或住户')
 if plan['contact_policy']=='no_contact':plan['generic_intro_suitable']=False;plan['preferred_mother_slot']=None;plan['caution'].append('本人全面拒绝联系，不生成推销接话')
 out['reply_plan']=plan
 out['model_review_provenance']=dict(method='逐条模型语义初筛及细筛同轮判断；程序仅展开显式决定、保留ID和校验',decision_file=f'decisions-{page}.txt',independent_second_review=False,usage='unknown')
 return out
def run():
 rows=[];pages=[];errors=[]
 for f in sorted(P.glob('decisions-*.txt')):
  page=f.stem[-2:];data=json.loads((P/f'page-{page}.json').read_text(encoding='utf-8-sig'));expected=[c['key'] for g in data['shared_post_context'] for c in g['comments']]
  made=[make(l,page) for l in f.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
  keys=[r['review_key'] for r in made]
  if len(keys)!=len(expected) or set(keys)!=set(expected):errors.append(f'{page}:coverage')
  for r in made:
   src=SOURCE[r['review_key']]
   for fld in ['comment_id','customer_uid','video_id']:
    if r[fld]!=src[fld]:errors.append(f'{r["review_key"]}:{fld}')
   for q in r['evidence']+[x['quote'] for fld in ['topics','target_regions','time_mentions','other_constraints','possible_topics'] for x in r[fld]]:
    if q not in src['comment_text'] and not (src.get('post_author_same_as_commenter') and q in src.get('post_body','')):errors.append(f'{r["review_key"]}:quote:{q}')
  (P/f'reviewed-{page}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in made),encoding='utf-8')
  rows+=made;pages.append(page)
 progress=dict(shard=TASK['shard'],expected=TASK['comments'],expected_pages=TASK['pages'],completed_pages=pages,reviewed=len(rows),errors=errors,platform_calls=0,send_authorized=False,method='逐页完整语义读取后显式逐条决定；同轮初筛细筛，非独立二审',usage='unknown')
 keys=[r['review_key'] for r in rows]
 if len(rows)==TASK['comments']:
  if len(keys)!=len(set(keys)) or set(keys)!=set(TASK['expected_review_keys']):errors.append('final_coverage')
  if not errors:pathlib.Path(TASK['output_file']).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
 (P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(progress,ensure_ascii=False))
if __name__=='__main__':run()
