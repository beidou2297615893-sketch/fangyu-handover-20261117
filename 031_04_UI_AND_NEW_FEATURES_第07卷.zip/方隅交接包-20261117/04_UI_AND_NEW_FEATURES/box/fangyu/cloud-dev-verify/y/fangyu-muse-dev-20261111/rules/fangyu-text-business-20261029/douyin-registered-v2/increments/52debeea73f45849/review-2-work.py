import json, pathlib, datetime, collections
D=pathlib.Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/52debeea73f45849')
a=[json.loads(x) for x in open(D/'shard-2.jsonl',encoding='utf-8-sig')]
# Index groups were read individually with the saved post context. Unknown contexts remain unresolved.
supply=set(map(int,'''2 5 18 21 30 32 33 34 35 38 47 48 52 53 72 73 74 75 76 77 79 80 82 84 85 86 111 112 113 114 115 116 135 136 137 138 139 140 154 159 162 163 164 165 166 167 168 182 209 215 226 227 228 229 252 253 254 255 256 257 258 273 274 283 310 312 325 326 327 328 329 330 332 333 343 344 345 346 356 363 365 366 367 368'''.split()))
# 255: entered rental industry, no longer actively finding housing; not necessarily a provider.
supply.remove(255)
ended=set([1,6,60,142,214,259,369])
# Explicit demand or effective inquiries of identifiable rental listings.
high=set(map(int,'''7 8 9 15 19 23 25 26 49 50 51 55 56 63 65 81 94 95 96 98 99 100 104 117 128 143 144 146 171 172 173 174 175 181 184 186 188 196 210 216 217 218 219 220 221 222 223 224 225 238 239 240 241 244 251 262 264 284 286 287 290 291 292 293 294 295 296 297 306 307 317 318 319 320 321 322 323 334 337 341 342 350 351 352 353 354 355 360 372 373 374 375 376 377 378'''.split()))
medium=set([11,57,61,66,147,285,288,336,347,348,349])
# Unresolved, including short inquiries under experience posts and ambiguous search/source comments.
unknown=set(map(int,'''0 4 12 13 14 20 24 28 29 31 37 40 41 42 43 45 54 59 62 67 68 69 70 71 78 87 88 89 91 93 102 120 123 129 130 133 134 141 148 149 150 151 152 153 155 160 170 177 183 187 194 204 206 245 246 247 249 250 279 358 361 364 370 381 382 384'''.split()))
# Explicit own rental intent despite a vague post.
high.update([92])
# Only asking about a rental listing shown as occupied is still uncertain unless independently explicit.
# key: pools with direct text snippets, and whether the condition is a question, requirement or preference.
T={
7:[('位置通勤','通明湖附近','require'),('价格预算','2000左右','prefer'),('户型面积与居住方式','一居室','require'),('房源状态','有吗','ask')],
8:[('位置通勤','海淀温阳路地铁附近','require'),('价格预算','很贵','fact'),('费用合同','水电还高','fact')],
9:[('位置通勤','马驹桥','ask'),('价格预算','便宜的','prefer')],
11:[('位置通勤','灯市口上班','fact')],
12:[('位置通勤','在哪里','ask')],13:[('价格预算','800-900','ask'),('房源状态','有没有','ask')],14:[('房源状态','还有吗','ask')],15:[('价格预算','500','conditional')],
19:[('户型面积与居住方式','合租','require'),('位置通勤','临平','fact')],20:[('户型面积与居住方式','合租吗','ask')],
23:[('位置通勤','榕心未来','ask'),('价格预算','1300左右','prefer'),('户型面积与居住方式','独门独户','require'),('房源状态','有','ask')],
25:[('位置通勤','闽侯','require'),('户型面积与居住方式','两室一厅','require'),('房源状态','有吗','ask')],26:[('位置通勤','东街省立附近','require'),('户型面积与居住方式','两室','require'),('房源状态','有吗','ask')],29:[('位置通勤','位置在哪里','ask')],
40:[('位置通勤','龙柏附近','ask'),('房源状态','有吗','ask')],43:[('位置通勤','13号线','ask')],45:[('位置通勤','15号线','ask')],
49:[('位置通勤','徐汇闵行区','require'),('户型面积与居住方式','合租','ask'),('户型面积与居住方式','一个人','fact')],50:[('户型面积与居住方式','一起合租','require')],51:[('位置通勤','闵行区','require'),('户型面积与居住方式','一个人住','require')],
55:[('位置通勤','芳华里附近上班','fact'),('位置通勤','通勤的话一个小时左右就行','accept'),('价格预算','预算1800左右','prefer')],
56:[('位置通勤','国家大剧院附近上班','fact'),('位置通勤','石景山古城苹果园附近','require'),('价格预算','便宜的','prefer')],57:[('位置通勤','通州','ask'),('房内设施','没有噪音','require')],
61:[('位置通勤','荣昌东街上班','fact')],63:[('位置通勤','通州大运河附近','require'),('价格预算','预算2500','require')],
65:[('位置通勤','学院桥或者是新街口附近','require'),('位置通勤','10km内都能接受','accept'),('户型面积与居住方式','一居室','require'),('价格预算','4000以下','require')],66:[('位置通勤','积水潭b2出口附近工作','fact'),('价格预算','便宜一点','prefer')],
67:[('房内设施','有网嗎','ask')],68:[('位置通勤','哪个区','ask')],69:[('房源状态','这套不在吗','ask')],70:[('位置通勤','天府新区','ask')],71:[('房源状态','还有么','ask'),('看房联系','可以看房么','ask')],81:[('户型面积与居住方式','拼房','require')],
87:[('看房联系','怎么租','ask')],88:[('房源状态','还有吗','ask')],89:[('位置通勤','新店附近','ask')],91:[('价格预算','多少钱','ask')],93:[('位置通勤','闽侯这边','ask')],94:[('房源状态','房子还在吗','ask')],95:[('房源状态','还有吗','ask')],96:[('房源状态','还在吗','ask')],
98:[('位置通勤','上海江桥','require'),('价格预算','预算充足','fact')],99:[('位置通勤','九亭','require'),('看房联系','转租的','ask')],100:[('位置通勤','嘉定新城','fact'),('户型面积与居住方式','合租','require')],104:[('位置通勤','1号线附近','require'),('户型面积与居住方式','1室1厅','require'),('房内设施','天然气','require')],117:[('位置通勤','17号沿线','require'),('楼层电梯','电梯房','require')],
123:[('位置通勤','静安','ask'),('户型面积与居住方式','一居室','ask')],128:[('位置通勤','莲花南路春申路银都路附近','require'),('户型面积与居住方式','大二室','require'),('户型面积与居住方式','合租','require'),('户型面积与居住方式','我一家二个人','fact')],141:[('费用合同','电费一块二？一块五？','ask')],
143:[('位置通勤','东城区青年湖附近上班','fact'),('位置通勤','通勤时间1小时以内','require'),('价格预算','房租2500以内','require')],144:[('位置通勤','永定门外上班','fact'),('位置通勤','媳妇在建国门','fact'),('价格预算','预算3000左右','prefer')],146:[('位置通勤','海淀紫竹桥通勤地铁半小时内','require'),('价格预算','便宜的','prefer')],147:[('位置通勤','永泰庄地铁上班','fact'),('位置通勤','不想离朝阳那边太远','prefer')],
148:[('位置通勤','天府新区哪里','ask')],149:[('位置通勤','华阳','ask')],150:[('位置通勤','牛王庙玉双路这边','ask')],151:[('位置通勤','温江','ask')],152:[('入住与租期','月租','ask')],153:[('位置通勤','青羊泡西这边','ask')],155:[('看房联系','有中介吗','ask')],160:[('位置通勤','滨江','ask')],170:[('价格预算','多少钱','ask')],
171:[('位置通勤','鼓楼区','require'),('价格预算','预算800','require')],172:[('位置通勤','晋安附近','require'),('户型面积与居住方式','一个人住','require')],173:[('位置通勤','闽侯荆溪','require'),('户型面积与居住方式','三室两卫的套房','require')],174:[('位置通勤','台江','require'),('房内设施','采光好一点点','prefer'),('价格预算','预算1500','require')],175:[('位置通勤','双江路这边','ask')],181:[('位置通勤','吴泾','require'),('户型面积与居住方式','合租','require'),('户型面积与居住方式','两室两厅','fact'),('价格预算','房租一千多','fact')],184:[('价格预算','预算1800','require')],186:[('看房联系','中介骑着小电驴带我看房','fact')],188:[('位置通勤','浦东新区张江附近','require'),('价格预算','2500左右','prefer'),('户型面积与居住方式','一居室','require')],194:[('位置通勤','在哪里','ask')],196:[('位置通勤','静安大融城附近','require'),('户型面积与居住方式','整租一室一厅','require'),('价格预算','预算3500左右','prefer'),('户型面积与居住方式','不要公寓','reject')],
210:[('位置通勤','沙河地铁附近','ask')],216:[('位置通勤','知春路上班','fact'),('位置通勤','女朋友在金台路','fact'),('位置通勤','两个人通勤差不多','require'),('价格预算','2500预算','require')],217:[('位置通勤','望京利泽中二路附近上班','fact'),('户型面积与居住方式','整租一居室','require'),('价格预算','4-5K预算','require')],218:[('位置通勤','东边五环外','require'),('价格预算','便宜的','prefer'),('户型面积与居住方式','村子公寓','require'),('房内设施','独卫就行','require')],219:[('价格预算','预算2k','require'),('位置通勤','长春桥 火器营那边上班','fact'),('户型面积与居住方式','一室一厅整租','require')],
220:[('房源状态','真有吗','ask')],221:[('看房联系','怎么联系','ask')],222:[('位置通勤','高新万达','ask')],223:[('位置通勤','哪个位置','ask')],224:[('位置通勤','双流华阳那边','ask')],225:[('费用合同','水电是民水民电么','ask')],
238:[('位置通勤','靠近地铁站','require'),('位置通勤','滨江附近','require'),('费用合同','不要收中介费','reject')],239:[('户型面积与居住方式','单间','require')],240:[('价格预算','多少钱一个月','ask')],241:[('位置通勤','具体位置在哪','ask')],244:[('户型面积与居住方式','什么房子','ask'),('价格预算','什么价格','ask')],245:[('位置通勤','离锐捷近','ask')],246:[('位置通勤','潘墩新城','ask')],247:[('位置通勤','在哪里','ask'),('看房联系','帮忙找个','ask')],249:[('位置通勤','福建省肿瘤医院旁边','ask')],250:[('位置通勤','鼓楼区近万象汇','ask')],251:[('位置通勤','哪里','ask'),('价格预算','多少钱一个月','ask')],262:[('位置通勤','8号线联航路','require'),('看房联系','个人转租','ask')],264:[('位置通勤','宝山路这边','require'),('价格预算','两千五以内','require'),('户型面积与居住方式','两个人','fact'),('房内设施','独立卫浴','require')],
284:[('位置通勤','天通苑','require'),('价格预算','很便宜','prefer')],285:[('位置通勤','西单上班','conditional'),('位置通勤','尽量不需要倒地铁','prefer'),('价格预算','尽可能控制在1000以里','prefer')],286:[('位置通勤','广化大街附近','require'),('位置通勤','挨着朝阳边上的通州也可以','accept'),('价格预算','1k左右','prefer')],287:[('位置通勤','北沙滩上班','fact'),('价格预算','预算2000左右','prefer'),('户型面积与居住方式','单间','require')],288:[('位置通勤','温阳路  北安河附近的村','compare')],290:[('位置通勤','高新青年公寓6号院','ask')],291:[('位置通勤','在哪里','ask'),('看房联系','怎么联系','ask')],292:[('位置通勤','四川','ask')],293:[('费用合同','水电费怎么算','ask')],294:[('位置通勤','什么地方','ask')],295:[('价格预算','1400一间吗','ask')],296:[('位置通勤','中西结合医院附近','require'),('户型面积与居住方式','一个人住','require')],297:[('位置通勤','离地铁近嘛','ask'),('价格预算','几张','ask')],306:[('户型面积与居住方式','合租','ask'),('位置通勤','上城','require')],307:[('位置通勤','什么位置','ask')],
317:[('房源状态','还有吗','ask'),('位置通勤','9号线就行','accept')],318:[('户型面积与居住方式','合租','ask')],319:[('房源状态','还在吗','ask')],321:[('楼层电梯','在几搂','ask')],322:[('房源状态','还在吗','ask')],323:[('位置通勤','周浦','ask')],334:[('户型面积与居住方式','俩居','require')],336:[('位置通勤','晶耀虹桥上班','fact')],337:[('位置通勤','张江广兰路，金科路张江高科地铁站附近','require'),('户型面积与居住方式','一室户','require')],341:[('位置通勤','浦东','require')],342:[('位置通勤','川沙地铁站100米','require'),('户型面积与居住方式','合租','require')],347:[('位置通勤','十里河那里上班','fact')],348:[('位置通勤','亦庄永昌北路','ask')],349:[('位置通勤','西城区有研大厦那里上班','fact')],350:[('位置通勤','高新区大源桂溪','ask')],351:[('位置通勤','成都大学附近','ask')],352:[('位置通勤','在哪','ask')],353:[('房源状态','还有吗','ask')],354:[('价格预算','预算七百','require'),('入住与租期','长租','require'),('位置通勤','MPS上班','fact'),('房源状态','还有这样的房子吗','ask')],355:[('入住与租期','租一个月','ask')],358:[('看房联系','申请','ask')],360:[('看房联系','怎么租','ask')],361:[('位置通勤','滨江区哪里','ask')],364:[('位置通勤','萧山','ask')],370:[('位置通勤','在哪里','ask')],372:[('价格预算','什么价格','ask')],373:[('价格预算','多少钱','ask')],374:[('入住与租期','租期还有多久','ask')],375:[('位置通勤','位置','ask')],376:[('位置通勤','在哪','ask')],377:[('位置通勤','在哪里','ask')],378:[('位置通勤','在哪','ask')],381:[('房内设施','隔音如何','ask')],382:[('位置通勤','哪个小区','ask')],384:[('价格预算','多少钱一个月','ask')]
}
# Target relations only when direction derives from comment, not title or IP.
R={7:[('通明湖附近','desired')],8:[('海淀温阳路地铁附近','desired')],9:[('亦庄','work'),('马驹桥','unresolved')],11:[('灯市口','work')],19:[('临平','current_home')],23:[('榕心未来','desired')],25:[('闽侯','desired')],26:[('东街省立附近','desired')],40:[('龙柏附近','unresolved')],49:[('徐汇闵行区','desired')],51:[('闵行区','desired')],55:[('芳华里附近','work')],56:[('国家大剧院附近','work'),('石景山古城苹果园附近','desired')],57:[('通州','unresolved')],61:[('荣昌东街','work')],63:[('通州大运河附近','desired')],65:[('学院桥','desired'),('新街口附近','desired')],66:[('积水潭b2出口附近','work')],70:[('天府新区','unresolved')],89:[('新店附近','unresolved')],93:[('闽侯这边','unresolved')],98:[('上海江桥','desired')],99:[('九亭','desired')],100:[('嘉定新城','current_home')],128:[('莲花南路春申路银都路附近','desired')],143:[('东城区青年湖附近','work')],144:[('永定门外','work'),('建国门','work')],146:[('海淀紫竹桥','work')],147:[('永泰庄地铁','work'),('朝阳','unresolved')],148:[('天府新区','unresolved')],149:[('华阳','unresolved')],150:[('牛王庙玉双路这边','unresolved')],151:[('温江','unresolved')],153:[('青羊泡西这边','unresolved')],155:[('萧山','unresolved')],160:[('滨江','unresolved')],171:[('鼓楼区','desired')],172:[('晋安附近','desired')],173:[('闽侯荆溪','desired')],174:[('台江','desired')],175:[('双江路这边','desired')],181:[('吴泾','desired')],188:[('浦东新区张江附近','desired')],196:[('静安大融城附近','desired')],210:[('沙河地铁附近','unresolved')],216:[('知春路','work'),('金台路','work')],217:[('望京利泽中二路附近','work')],218:[('东边五环外','desired')],219:[('长春桥 火器营那边','work')],222:[('高新万达','desired')],224:[('双流华阳那边','unresolved')],238:[('滨江附近','desired')],245:[('锐捷','unresolved')],246:[('潘墩新城','unresolved')],249:[('福建省肿瘤医院旁边','unresolved')],250:[('鼓楼区近万象汇','unresolved')],264:[('宝山路这边','desired')],284:[('天通苑','desired')],285:[('西单','work')],286:[('广化大街附近','desired'),('挨着朝阳边上的通州','accepted')],287:[('北沙滩','work')],288:[('温阳路','unresolved'),('北安河附近的村','unresolved')],290:[('高新青年公寓6号院','desired')],292:[('四川','unresolved')],296:[('中西结合医院附近','desired')],306:[('上城','desired')],323:[('周浦','desired')],336:[('晶耀虹桥','work')],341:[('浦东','desired')],342:[('川沙地铁站100米','desired')],347:[('十里河','work')],348:[('亦庄永昌北路','unresolved')],349:[('西城区有研大厦','work')],350:[('高新区大源桂溪','desired')],351:[('成都大学附近','desired')],354:[('MPS','work')],361:[('滨江区','unresolved')],364:[('萧山','unresolved')]}
import re
supply.add(180)
high.discard(210); unknown.add(210)
high.discard(92); medium.add(92)
high.update([87,152,247]); unknown.difference_update([87,152,247])
medium.discard(285); unknown.add(285)
# Only exact text from the commenter is used in topic evidence.
P=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
supply_patterns={
'价格预算':r'(?:\d+(?:\.\d+)?\s*[kK千元]|(?<![\d.])\d{3,5}(?![\d.米m年月日号])(?:元/月|元|块钱|一个月)?|一千多)',
'位置通勤':r'(?:\d+号线|地铁站|地铁口|地铁房)',
'户型面积与居住方式':r'(?:三室两厅两卫|三室两厅|两室一厅|一室一厅|一室一卫|大一居室|一居室|单间|次卧|合租|整租|\d+平)',
'房内设施':r'(?:独立卫浴|独厨独卫|独立卫生间|卫生间|洗衣机|大阳台|阳台|厨房|燃气|WiFi|采光|花园|家电齐全|空调)',
'宠物':r'(?:可养宠物|遛狗|萨摩耶)',
'楼层电梯':r'(?:电梯|顶楼|二楼|6复7)',
'入住与租期':r'(?:短租|合同到2027\.5\.31|租期到下一年4月30日|最早17号就能住进去)',
'费用合同':r'(?:无中介费|不用中介费|没有中介费|不收中介费|不会要你中介费|押一付一|月付|民水电|水电|包水网|合同)',
'看房联系':r'(?:私信|联系我|随时看房|房东直租|个人转租|转租)'}
extra={143:[('安全就行','安全要求')],181:[('作息规律，有洁癖爱干净，会做饭','室友条件或本人描述需确认')],285:[('如果是在西单上班','假设情形，并非确认本人当前需求')]}
# Time is not normalized without validating the platform's publication timestamp semantics.
times={34:[('月底','other')],35:[('次年三月','lease_duration')],162:[('租期到下一年4月30日','lease_duration'),('月底可搬走','move_in')],180:[('一年起签','lease_duration')],152:[('月租','lease_duration')],204:[('下个月18号到期','other')],354:[('长租','lease_duration')],355:[('一个月','lease_duration')],374:[('租期还有多久','lease_duration')]}
def build(i,x):
 s=x['comment_text'] or ''
 if i in supply:
  role,state,interest='supply','unknown','unrelated'; reason='本人提供房源、转租或协助找房，未明确本人另有求租需求。'
 elif i in ended:
  role,state,interest='demand','ended','unrelated'; reason='本人描述已经租住或租到的房屋，未明确新的找房需求。'
 elif i in high:
  role,state,interest='demand','active_at_comment','high'; reason='本人提出找房条件或针对出租房源询问，反映评论时行为；当前需求尚未核实。'
 elif i in medium:
  role,state,interest='demand','active_at_comment','medium'; reason='本人在租房语境中询问地区或通勤建议，尚无具体房源约看。'
 elif i in unknown:
  role,state,interest='unknown','unknown','uncertain'; reason='评论对象、供需身份或是否本人正在找房不明确，需结合上下文核实。'
 else:
  role,state,interest='discussion','unknown','unrelated'; reason='本人分享体验、建议或讨论，未表达新的本人求租需求。'
 if i==3: reason='作者说明视频录制和推广过程，未表达本人求租需求。'
 if i==4 or i==41 or i==78 or i==157 or i==230: reason='评论文本为空，无法判断对象与本人需求。'
 if i==0: reason='让对方看视频并询问附近，视频内容未读；不能确定是提供房源还是求租。'
 if i==15: reason='在转租语境下提出500并表示租，是否双方成交未核实。'
 if i==19: reason='本人找合租伙伴；临平是本人所在位置，不自动认定新租目标地区。'
 if i==65: reason='本人明确找公寓一居室，两个地点为备选，预算和骑行距离均保留。'
 if i==123: reason='多少米可能指价格或面积，当前未澄清；无法确定本人是否实际求租。'
 if i==210: reason='仅说沙河地铁附近租房，身份可能是求租、出租或推荐，待核。'
 if i==255: reason='本人描述曾未找到好房并入职租房行业，未明确现在仍找房。'
 if i==285: reason='以如果提出西单通勤和预算设想，是否本人当前找房待核。'
 if i==320: reason='在明确转租房源下表示我要，视为有效询盘；不能视为预订或成交。'
 if i==358: reason='咨询孩子申请公租房的可能性，具体申请计划及主体状态待核。'
 if i==360: reason='本人表达想申请公租房并询问如何租，住房属性与申请资格另核。'
 if i==364: reason='仅说萧山租房，身份和租房动作不明确。'
 review=[]
 if interest=='uncertain': review.append(reason)
 if interest in ('high','medium'): review.append('评论仅反映当时的意向；当前需求和可承接事实尚未核实。')
 if x.get('source_version_conflict'): review.append('来源版本存在冲突，需核对原文。')
 if x.get('deeper_reply_count_visible',0): review.append(f"有{x['deeper_reply_count_visible']}条可见深层回复未读，后续状态未知。")
 if i in (13,14,67,68,69,70,71,87,88,89,91,93,148,149,150,151,152,153,170,245,246,247,249,250,381,382,384): review.append('帖子为入住体验或讨论，未证明房源当前可租；不得继承帖主条件。')
 if i==358: review.append('受益人为孩子；资格和本人是否承担找房需要确认。')
 te=[]
 for pool,q,pol in T.get(i,[]):
  if q not in s: raise ValueError((i,q,s))
  subj='unresolved' if interest=='uncertain' else 'own_demand'
  te.append(dict(pool=pool,quote=q,polarity=pol,subject=subj,source='comment',condition_scope='保留原文措辞；仅反映该项询问或条件'))
 if role=='supply':
  for pool,pat in supply_patterns.items():
   for m in re.finditer(pat,s,re.I):
    te.append(dict(pool=pool,quote=m.group(),polarity='fact',subject='supply',source='comment',condition_scope='供给房源描述，不能转为本人新求租条件'))
 regs=[]
 for q,rel in R.get(i,[]):
  if q not in s: raise ValueError((i,q,s))
  regs.append(dict(text=q,quote=q,relation=rel,source='comment',group_relation='OR' if i in (65,286) and rel in ('desired','accepted') else 'unknown',condition_scope='原文位置作用范围按关系标注，不推断门店'))
 tim=[]
 for q,r in times.get(i,[]):
  if q not in s: raise ValueError((i,q,s))
  tim.append(dict(quote=q,time_role=r,anchor_source='published_at_unix' if x.get('published_at_unix') else None,anchor_time=x.get('published_at_unix'),normalized=None,verification='保持原文，具体日期及发表时点语义待核'))
 out={k:x.get(k) for k in ('review_key','comment_id','customer_uid','video_id')}
 out.update(role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(z['pool'] for z in te)),topic_evidence=te,target_regions=regs,time_mentions=tim,other_constraints=[dict(quote=q,description=d,subject='unresolved' if interest=='uncertain' else 'own_demand') for q,d in extra.get(i,[])],possible_topics=([dict(pools=['价格预算','户型面积与居住方式'],quote='多少米',reason='米可能指租金或面积，未澄清。')] if i==123 else []),evidence=[s] if s else [],reason=reason,review_reasons=review,context_used=['comment','post_body'] if not x.get('direct_parent_text') else ['comment','post_body','direct_parent'],media_context='未读取视频画面；不把视频文字视为房源事实已核',reply_context='有可见深层回复但未读' if x.get('deeper_reply_count_visible') else '未读取深层回复',current_need_confirmed=False,current_need_verified=False,assigned_store=None,send_authorized=False)
 return out
# Each independently written batch contains 80–100 lines, followed by a merge.
rows=[build(i,x) for i,x in enumerate(a)]
bounds=[(0,96),(96,192),(192,288),(288,len(rows))]
for part,(start,end) in enumerate(bounds,1):
 with open(D/f'reviewed-2-part-{part}.jsonl','w',encoding='utf-8',newline='\n') as f:
  for row in rows[start:end]: f.write(json.dumps(row,ensure_ascii=False)+'\n')
with open(D/'reviewed-2.jsonl','w',encoding='utf-8',newline='\n') as f:
 for row in rows: f.write(json.dumps(row,ensure_ascii=False)+'\n')
ids=lambda z:(z['review_key'],z['comment_id'],z['customer_uid'],z['video_id'])
errors=[]
for x,y in zip(a,rows):
 if ids(x)!=ids(y): errors.append('identity:'+x['review_key'])
 for q in y['evidence']:
  if q not in (x['comment_text'] or ''): errors.append('evidence:'+x['review_key'])
 for field in ('topic_evidence','target_regions','time_mentions','other_constraints','possible_topics'):
  for item in y[field]:
   if item['quote'] not in (x['comment_text'] or ''): errors.append(field+':'+x['review_key'])
 for z in y['topic_evidence']:
  if z['pool'] not in P: errors.append('pool:'+x['review_key'])
 if set(y['topics'])!={z['pool'] for z in y['topic_evidence']}: errors.append('topic_mismatch:'+x['review_key'])
 if y['current_need_confirmed'] or y['assigned_store'] is not None or y['send_authorized']: errors.append('authorization:'+x['review_key'])
result=dict(input_count=len(a),output_count=len(rows),id_quadruples_unique=len(set(map(ids,a)))==len(a)==len(set(map(ids,rows))),id_quadruple_set_equal=set(map(ids,a))==set(map(ids,rows)),pool_names_valid=all(z in P for y in rows for z in y['topics']),quote_checks_passed=not errors,errors=errors,batch_counts=[end-start for start,end in bounds],role_counts=dict(collections.Counter(r['role'] for r in rows)),interest_counts=dict(collections.Counter(r['interest_at_comment'] for r in rows)),limitations='格式与引文校验不能证明语义准确率；初判未获用户金标，未发送。')
(D/'validation-2.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
