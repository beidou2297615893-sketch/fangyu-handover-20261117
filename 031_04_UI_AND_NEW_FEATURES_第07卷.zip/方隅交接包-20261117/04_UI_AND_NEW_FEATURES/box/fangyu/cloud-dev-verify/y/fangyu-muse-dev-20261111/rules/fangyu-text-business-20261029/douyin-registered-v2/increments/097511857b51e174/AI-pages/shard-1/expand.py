import json,pathlib,datetime,collections
BASE=pathlib.Path(__file__).resolve().parent
ROOT=BASE.parent.parent
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
src={r['review_key']:r for r in map(json.loads,(ROOT/'shard-1.jsonl').read_text(encoding='utf-8').splitlines())}
# All semantic choices below come from saved, individually model-authored page decisions.
# This helper only expands the decision notation and joins immutable identity fields.
CODES={'H':('demand','active_at_comment','high'),'M':('demand','active_at_comment','medium'),'U':('unknown','unknown','uncertain'),'Q':('demand','unknown','uncertain'),'V':('demand','active_at_comment','super_high'),'E':('demand','ended','unrelated'),'R':('demand','historical','unrelated'),'F':('demand','future','low'),'S':('supply','unknown','unrelated'),'X':('discussion','unknown','unrelated'),'B':('mixed','unknown','uncertain')}
FACTS={1:'推荐优惠的适用门店、活动时效、适用条件和本人介绍资格',2:'同店符合全部预算与必付费用及居住要求的有效房型',7:'同店确有客户所指户型及有效房源',13:'同店同房型对该宠物种类、体型和数量的规定',16:'同店电梯、具体楼层与可看安排',19:'同店接收该租期且相应日期可入住',25:'同店当前水电、租金及全部必付费用口径',28:'账号对接权限、同店可看安排及本人方便时间',31:'可承接位置和推荐优惠适用条件',34:'同一有效房源满足本人全部明确要求、准确报价与优惠条件'}
TIME_DECISIONS=json.loads((BASE/'time-decisions.json').read_text(encoding='utf-8'))
def expand(page):
  inp=json.loads((BASE/f'page-{page:02}.json').read_text(encoding='utf-8'))
  cs={c['key']:(g,c) for g in inp['shared_post_context'] for c in g['comments']}
  out=[]
  for line in (BASE/f'decisions-{page:02}.txt').read_text(encoding='utf-8').splitlines():
    if not line.strip() or line.startswith('#'):continue
    parts=line.split('|');parts+=['']*(7-len(parts))
    k,code,topics,regions,reason,mother,extra=parts[:7]
    g,c=cs[k];r=src[k];role,state,interest=CODES[code]
    e=json.loads(extra) if extra else {}
    rr={a:r.get(a) for a in ['review_key','platform','comment_id','customer_uid','video_id','comment_text','published_at_unix','post_author_same_as_commenter','source_stable_key','source_comment_sha256','rule_version']}
    rr.update(role=role,demand_state=state,interest=interest,topics=[],target_regions=[],time_mentions=e.pop('time_mentions',[]),other_constraints=e.pop('other_constraints',[]),possible_topics=e.pop('possible_topics',[]),evidence=[c['text']] if c['text'] else [],reason=reason,context_used=['own','body'],needs_review=e.pop('needs_review',[]),human_confirmed=False,send_authorized=False,store_assignment=None)
    for q,kind,norm,ver in TIME_DECISIONS.get(k,[]):
      rr['time_mentions'].append(dict(quote=q,time_role=kind,anchor_source='comment_published_at_unix',anchor_time=None,normalized=norm,verification=ver))
    for tm in rr['time_mentions']:
      if tm.get('anchor_source')=='comment_published_at_unix' and r.get('published_at_unix'):
        tm['anchor_time']=datetime.datetime.fromtimestamp(r['published_at_unix'],datetime.timezone.utc).isoformat()
    for t in topics.split(';') if topics else []:
      a=t.split('~');n=int(a[0]);q=a[1];pol=a[2] if len(a)>2 else 'ask';sub=a[3] if len(a)>3 else ('own_demand' if role=='demand' else 'unresolved');scope=a[4] if len(a)>4 else q
      rr['topics'].append(dict(pool=POOLS[n-1],quote=q,polarity=pol,subject=sub,condition_scope=scope))
    for t in regions.split(';') if regions else []:
      a=t.split('~');rr['target_regions'].append(dict(text=a[0],quote=a[1] if len(a)>1 and a[1] else a[0],relation=a[2] if len(a)>2 else 'desired',group_relation=a[3] if len(a)>3 else 'unknown',condition_scope=a[4] if len(a)>4 else (a[1] if len(a)>1 and a[1] else a[0])))
    slot=int(mother.strip()) if mother.strip() else None
    serious=e.pop('serious',False)
    missing=e.pop('missing_facts',[])
    if slot:
      missing+=[FACTS[slot]]
      if role in ('demand','mixed'):missing+=['本人目前是否仍找房及可接受的方隅门店']
      for t in rr['topics']:
        if t['subject']=='own_demand':
          missing.append('针对本人“'+t['quote']+'”核实同店房源的'+t['pool']+'事实；不把来源房源当作方隅事实')
    if code in ('U','Q','B') and not rr['needs_review']:
      rr['needs_review']=[reason]
    cautions=e.pop('caution',[])
    if serious:cautions+=['严肃语境成句需去掉宝宝等亲昵称呼']
    if slot==1:cautions+=['通用推荐介绍不代表已回答具体报价、位置或房源条件']
    elif slot:cautions+=['所选专池母句须核实列明同店事实再成句；可先用已认可通用介绍，不冒充具体问题的完整回答']
    rr['reply_plan']=dict(preferred_mother_slot=slot,generic_intro_suitable=bool(slot and code not in ['E','R','S','X']),tone='serious' if serious else 'normal',contact_policy=e.pop('contact_policy','allow'),missing_facts=missing,caution=cautions)
    rr['contact_boundaries']=e.pop('contact_boundaries',[])
    rr['context_flags']={'post_author_same_as_commenter':c['same_author'],'source_version_conflict':c['source_conflict'],'direct_parent_present':bool(c['parent']),'source_regions_not_assumed':True,'intent_at_comment_not_current_confirmation':True}
    rr.update(e)
    out.append(rr)
  assert len(out)==len(cs),(len(out),len(cs))
  assert set(r['review_key'] for r in out)==set(cs)
  assert len({r['review_key'] for r in out})==len(out)
  (BASE/f'reviewed-page-{page:02}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),encoding='utf-8')
  return out
def validate(rows,expected):
  errors=[]
  for r in rows:
    orig=src[r['review_key']];text=orig['comment_text'];body=orig['post_body'] if orig['post_author_same_as_commenter'] else ''
    for field in ['evidence','topics','target_regions','time_mentions','other_constraints','possible_topics']:
      for v in r[field]:
        q=v if isinstance(v,str) else v.get('quote','')
        if q and q not in text and q not in body:errors.append([r['review_key'],field,q])
    for field in ['comment_id','customer_uid','video_id']:
      if r[field]!=orig[field]:errors.append([r['review_key'],'identity',field])
    for t in r['topics']:
      if t['pool'] not in POOLS:errors.append([r['review_key'],'pool'])
  keys=[r['review_key'] for r in rows]
  return dict(input_count=len(expected),output_count=len(rows),unique_keys=len(set(keys)),key_set_equal=set(keys)==set(expected),identity_and_verbatim_errors=errors,all_human_confirmed_false=all(r['human_confirmed'] is False for r in rows),all_send_authorized_false=all(r['send_authorized'] is False for r in rows),all_store_assignment_null=all(r['store_assignment'] is None for r in rows),role_counts=dict(collections.Counter(r['role'] for r in rows)),interest_counts=dict(collections.Counter(r['interest'] for r in rows)))
if __name__=='__main__':
  import sys
  page=int(sys.argv[1]);rows=expand(page)
  check=validate(rows,[c['key'] for g in json.loads((BASE/f'page-{page:02}.json').read_text(encoding='utf-8'))['shared_post_context'] for c in g['comments']])
  assert not check['identity_and_verbatim_errors'],check
  completed=sorted(int(p.stem.split('-')[-1]) for p in BASE.glob('reviewed-page-*.jsonl'))
  (BASE/'progress.json').write_text(json.dumps(dict(shard=1,total=1868,completed_pages=completed,completed_comments=sum(len(p.read_text(encoding='utf-8').splitlines()) for p in BASE.glob('reviewed-page-*.jsonl')),status='in_progress',method='model_per_comment_initial_and_detailed_semantic_review',updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),ensure_ascii=False,indent=2),encoding='utf-8')
  print(json.dumps(check,ensure_ascii=False))
