# 抖音本批分片0判读与校验记录

已完成14页、2480条显式模型语义初筛与细筛合并判读。页00原决定保留，以corrected文件修复错引、遗漏和部分角色；页02、04、11相对日期归一保守修正也另存，未删除原决定。

输入和输出均为2480条；review_key、comment_id、customer_uid、video_id、platform及原文散列逐条与本批完整metadata核对，ID集合相同，无重复、缺漏或串片。14页正文、评论、时间、同作者和来源冲突等字段与源metadata一致。逐字证据出现次数校验4785，错误0。schema、认可母句槽位、联系策略、权限标记校验通过。

意向计数：{"medium": 228, "uncertain": 201, "unrelated": 1252, "high": 791, "super_high": 4, "low": 4}。
角色计数：{"demand": 1080, "unknown": 152, "discussion": 1180, "supply": 66, "mixed": 2}。
联系策略：{"allow": 2390, "unknown": 88, "identity_restricted": 2}。
需进一步核实的记录：238条。

所有记录human_confirmed=false、send_authorized=false、store_assignment=null。allow仅为文本未表达拒联，不是发送授权。母句只选已认可槽位，没有改写或生成正文；已选母句和适用通用介绍的事实缺口均保留。无平台调用、无发送、无源数据库写入、无发布或冻结；未改变其他分片或总状态。费用未知，本代理未购买额度。

## 局限

本次为同一代理逐条初细筛合并判读，不冒充独立二审或人工验收。没有读未提供的更深回复、图像或视频；context_used只记录实际读过的own/body，存在parent才计parent。active_at_comment不等于今日仍有效。模糊租购、预算单位、时区、指代或新租状态均保留待核；母句所需真实住户、门店房源报价优惠和介绍权限均未核实。root将另行独立风险复核，本片现已停止，不自行发布。

输入SHA256：f5716f372be834c1b606b7aed72eafeb023e49e68dfd074ed49d210c66456f11

输出SHA256：c2a7c75c0dede5feaa675c547f9291de56a4cd9029d5b26afd1b07899930718d

## 正式契约格式兼容修正

27条记录中的29项other_constraints保留原constraint字段，并补detail同值；逐条结构差异检查确认无其它语义字段变化。正式结果与逐页结果一致，受影响页及决定文件、正式结果和原校验报告的原字节已备份至本片schema-before，34份备份散列均核对通过。

正式mother_adapter.validate_new_review对2480条隔离副本完整校验通过，错误0；阶段与来源指针仅添加于隔离预检副本，没有写回正式结果或页，也没有声明独立二审。母句、角色、意向、证据、联系方式策略和授权标记全部未改。本片现已停止。

修正后输出SHA256：c2a7c75c0dede5feaa675c547f9291de56a4cd9029d5b26afd1b07899930718d
