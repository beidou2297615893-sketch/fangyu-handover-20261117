"""Select accepted mother sentences locally; never call a model, platform or send."""
import json,csv,hashlib,re,collections
from pathlib import Path
from datetime import datetime
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;D=W/'delivery-v2';O=R/'outputs/方隅双平台文本业务/古北分类与预生成回复';O.mkdir(exist_ok=True)
def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
def sha(v):return hashlib.sha256(v.encode()).hexdigest()
sources=jl(D/'source-input.jsonl');source={x['comment_id']:x for x in sources};assert len(sources)==len(source)==2755
checks=json.loads((W/'acceptance-v2/validation.json').read_text(encoding='utf8'));assert checks['input_count']==checks['output_count']==200 and checks['rule_unchanged_after_freeze']
paths=[W/'increments/032413f79937dc52/reviewed-v2.jsonl',W/'increments/12004ba66ecdfa94/reviewed-v2.jsonl',D/'batch39-reviewed.jsonl'];reviews=[x for p in paths for x in jl(p)]
assert len(reviews)==2755 and len({x['comment_id'] for x in reviews})==2755 and {x['comment_id'] for x in reviews}==set(source)
poolnames={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for x in reviews:
 s=source[x['comment_id']];assert s['customer_uid']==x['customer_uid'];text=s['comment_text']
 for q in x.get('evidence',[]):assert q in text or q in re.sub(r'(https?://[^\s?#]+)[?#][^\s]*',r'\1',text),(x['comment_id'],'evidence')
 for t in x['topics']:assert t['pool'] in poolnames and t['quote'] in text,(x['comment_id'],'topic')
 for t in x['target_regions']:assert t['quote'] in text,(x['comment_id'],'region')
 assert not (x['role']=='unknown' and x['interest']=='unrelated')
 assert x['send_authorized'] is False
mothers={x['slot']:x for x in json.loads((W/'mothers/first50.json').read_text(encoding='utf8'))}
assert mothers[1]['user_approved'] and mothers[31]['user_approved']
catalog={
 'resident_base':{'text':mothers[1]['template'],'mother_slot':1,'purpose':'已认可的住户推荐承接；不回答未核具体房源条件'},
 'resident_location':{'text':mothers[31]['template'].replace('【已核实位置】','红松东路1000号'),'mother_slot':31,'purpose':'位置或价格位置组合，填入资料已核地址'},
 'family_base':{'text':mothers[1]['template'].removeprefix('宝宝，'),'mother_slot':1,'purpose':'严肃家庭语境仅去掉宝宝，母句不另写'},
 'family_location':{'text':mothers[31]['template'].replace('【已核实位置】','红松东路1000号').removeprefix('宝宝，'),'mother_slot':31,'purpose':'严肃家庭语境仅去掉宝宝并填入已核地址'}}
(D/'pool-mother-routing.json').write_text(json.dumps({'version':'pool-mother-routing-20261029-v1','source':'本人认可前10母句及最新明确允许住户推荐优惠口气；所有文案只本地套用','model_calls_for_reply_generation':0,
 'routing':'位置通勤池含位置询问→31；其余通过筛选的需求→1作为接话母句；家庭语境去宝宝；涉及具体户型/设施/库存承诺的其他母句仍按其事实前提，不强行套用',
 'exact_pool_answer_complete':False,'variants':catalog},ensure_ascii=False,indent=2),encoding='utf8')
out=[]
def meaningful_region(x):return [z for z in x['target_regions'] if z['relation'] in {'desired','preferred','accepted'}]
for x in reviews:
 s=source[x['comment_id']];raw=s['comment_text'];regions=meaningful_region(x);regiontext='、'.join(z['text'] for z in regions)
 reasons=[];reply=None;variant=None
 if x['role'] not in {'demand'}:reasons.append({'supply':'供给，无明确本人求租','discussion':'讨论或经历','mixed':'供给与可能新需求需分清','unknown':'身份、对象或需求待核'}[x['role']])
 if x['demand_state'] in {'ended','historical'} or x['interest']=='unrelated':reasons.append('已结束、历史或无当前本人需求')
 if x['interest'] in {'uncertain','low','very_low'}:reasons.append('需求对象、启动条件或意向仍需核清')
 if x['demand_state']=='future':reasons.append('未来才找或条件未成，暂不进入推介')
 # A known other city/remote target must never be assigned to Gubei simply by keyword origin.
 outside=re.search(r'北京|杭州|苏州|成都|福州|深圳|广州|南京|天津|无锡|嘉定|安亭|松江|奉贤|金山|浦东|临港|世博|前滩|宝山|普陀|虹口|杨浦|徐泾|青浦|双江路|莘庄',regiontext)
 if outside:reasons.append('本人目标另一区域，转门店适配核对，不从古北发推介')
 serious=bool(re.search(r'父母|老人|孩子|一家人|一家三口|带娃|住院|治病|陪护|家人',raw))
 if not reasons:
  location_asked=any(t['pool']=='位置通勤' and t['polarity']=='ask' for t in x['topics'])
  variant=('family_location' if serious else 'resident_location') if location_asked else ('family_base' if serious else 'resident_base')
  reply=catalog[variant]['text']
 item={'platform':'xiaohongshu','comment_id':s['comment_id'],'note_id':s['note_id'],'customer_uid':s['customer_uid'],
  'source_account_uid':s['source_account_uid'],'required_sending_account_uid':s['source_account_uid'],
  'source_batch':s['batch'],'source_keyword':s['keyword'],'source_page':s['page'],'input_sha256':s['input_sha256'],'comment_text_sha256':sha(raw),
  'comment_published_at':s['published_at'],'source_store':'古北','selected_store':None,'candidate_store':'古北' if reply else None,
  'rule_version':'business-text-20261029-v2','classification':x,'reply_variant':variant,'reply_text':reply,'reply_sha256':sha(reply) if reply else None,
  'text_generation_complete':bool(reply),'requires_model_at_send':False,'user_approved_variant':True if reply else None,
  'mother_slot':catalog[variant]['mother_slot'] if variant else None,'reply_method':'local_mother_selection_and_fact_fill','reply_generation_model_calls':0,
  'approval_scope':'已认可母句措辞及本人最新允许住户推荐口气；不是发送授权或账号住户事实独立核验',
  'text_status':'precomputed_pending_sender_checks' if reply else 'held_no_reply',
  'blocking_reasons':reasons,'semantic_review_reasons':x.get('needs_review',[]),'current_need_confirmed':False,
  'sender_checks':['按授权核实可用账号及平台状态','核已发、在途或未知回执，跨评论按客户防重','核本文所问对象与本人需求；旧评论的当前有效性','住户推荐口气按本人明确许可使用，具体适用推荐优惠由执行方核对','不得增补未核现价、空房、设施或宠物承诺'],
  'send_authorized':False,'can_send_now':False,'delivery_state':'not_attempted'}
 out.append(item)
# Exactly one proposed reply per customer; all other comments and reasons remain visible.
rank={'super_high':4,'high':3,'medium':2}
groups=collections.defaultdict(list)
for x in out:
 if x['reply_text']:groups[x['customer_uid']].append(x)
for xs in groups.values():
 xs.sort(key=lambda x:(x['comment_published_at'] or '',rank.get(x['classification']['interest'],0)),reverse=True)
 for x in xs[1:]:
  x['alternative_reply_text']=x['reply_text'];x['reply_text']=None;x['reply_sha256']=None;x['text_generation_complete']=False;x['text_status']='held_duplicate_customer';x['blocking_reasons'].append('同一客户已有更近评论的预生成回复，保留但不重复入队')
audit_path=D/'reply-audit.json'
audit={x['comment_id']:x for x in json.loads(audit_path.read_text(encoding='utf8'))['records']} if audit_path.exists() else {}
for x in out:
 if x['reply_text'] and audit.get(x['comment_id'],{}).get('action')=='hold':
  x['held_mother_slot']=x['mother_slot'];x['reply_text']=None;x['reply_sha256']=None;x['text_generation_complete']=False;x['text_status']='held_semantic_or_region_review';x['blocking_reasons'].append(audit[x['comment_id']]['reason'])
 x['candidate_store']=None # Collection origin never proves the client's store eligibility.
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out)
bundle=D/'cli-readonly-bundle';bundle.mkdir(exist_ok=True)
(bundle/'all-classifications.jsonl').write_text(packed,encoding='utf8')
queue=[x for x in out if x['reply_text']]
queuepack=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in queue)
(bundle/'precomputed-replies.jsonl').write_text(queuepack,encoding='utf8')
receipt={'rule_version':'business-text-20261029-v2','registered_comments':2755,'distinct_customers':len({x['customer_uid'] for x in out}),'classified_records':len(out),
 'role_counts':dict(collections.Counter(x['classification']['role'] for x in out)),'precomputed_reply_customers':len(queue),
 'held_records':len(out)-len(queue),'can_send_now':0,'platform_calls':0,'new_customer_reply_texts_generated':len(queue),'actual_sent':0,
 'same_customer_duplicates_prevented':sum(x['text_status']=='held_duplicate_customer' for x in out),
 'no_placeholders':all(not re.search(r'【|】|\{\{|\}\}',x['reply_text']) for x in queue),
 'no_model_at_send':True,'first50_user_approval_unchanged':True,'batch40_unregistered_62_excluded':True,
 'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in bundle.glob('*.jsonl')}}
(bundle/'manifest.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
def clean(t):
 t=re.sub(r'https?://\S+','[链接已省略]',t or '');t=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[联系方式已省略]',t);return re.sub(r'@[\w\u4e00-\u9fff.]+','[提及账号已省略]',t)
lines=['# 古北已登记评论的分类与预生成回复','',f'本次登记2755条评论，对应{receipt["distinct_customers"]}个平台客户；全部有分类记录。生成{len(queue)}条按客户防重的完整澄清回复，不含模板占位。它们由已认可母句本地套用，住户推荐与优惠口气依据本人最新明确许可；没有获准发送，不新增未核现价、库存或设施承诺。其他记录保留明确暂缓原因。','']
for x in out:
 s=source[x['comment_id']];c=x['classification'];lines+=['────────','原评论：'+clean(s['comment_text']),'评论发表时间：'+str(s['published_at'] or '缺失'),
  '分类：'+{'demand':'本人需求或询盘','supply':'供给','mixed':'供需混合','unknown':'待核','discussion':'讨论经历'}[c['role']],
  '需求池：'+('、'.join(t['pool'] for t in c['topics']) or '未确认本人具体需求池'),
  '判读依据：'+clean(c['reason']),'目标地点原话：'+('；'.join(z['text']+'（'+z['relation']+'）' for z in c['target_regions']) or '本人目标地区未明'),
  '完整回复：'+(x['reply_text'] or '暂不入回复队列'),'暂缓或发送前核对：'+('；'.join(x['blocking_reasons']) or '需核当前有效性、账号、历史回执、新拟措辞及本次发送授权'),
  '状态：已预生成、待核验；未发送。' if x['reply_text'] else '状态：分类记录保留，未发送。','']
(O/'逐条分类与完整回复.txt').write_text('\n'.join(lines),encoding='utf8')
(O/'交付说明.md').write_text(f'''# 古北分类与预生成回复交付

2755条正式登记评论已整理成同一版本，覆盖17个登记来源；未登记62条不计入。对应{receipt['distinct_customers']}个平台客户，非可联系人数。

已生成{len(queue)}条按客户防重的完整回复，另{receipt['same_customer_duplicates_prevented']}条同客户候选未重复入队。发送时可直接读取固定文案，不再临时调用模型分类或生成。暂缓记录有明确原因，不能临时随意补句。

按本人最新明确要求，允许采用“我住方隅公寓这边、介绍有优惠”的住户推荐口气。本批只用已认可母句1、31，由本地选择和填入红松东路1000号；家庭严肃语境仅去掉宝宝。没有逐条调用模型写回复，原50条及10条认可原句不变。其余具体户型、宠物、设施、房态母句仍受事实前提约束；本批接话母句不冒充已完整回答所有条件。

这不是已授权发送名单：平台当前有限制，历史回执、当前需求有效性及本次实际发送授权仍须核对。没有请求平台、恢复采集或发送。分类和固定文案已完成，不等于所有客户可自动联系。

规则文本锁定后新冻结200条历史样本完成模型检查，五池需求正例不足与待核如实保留，不报告准确率。15个官网项目的3000候选词已完成分层；完整25店名册在现有资料中未找到，缺口不以历史项目填数。
''',encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False))
