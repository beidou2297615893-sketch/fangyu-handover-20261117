import sys,json,pathlib,copy,collections,hashlib,datetime,importlib.util
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent;ROOT=P.parent.parent;WORK=ROOT.parents[2]
spec=importlib.util.spec_from_file_location('production_mother_adapter_readonly',WORK/'mother_adapter.py')
adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
original=[json.loads(x) for x in (P/'schema-before/reviewed-new-2.jsonl').read_text(encoding='utf-8').splitlines()]
rows=[json.loads(x) for x in (ROOT/'reviewed-new-2.jsonl').read_text(encoding='utf-8').splitlines()]
current={x['review_key']:x for x in rows};changed_semantics=[]
for old in original:
 new=current[old['review_key']]
 if old!={k:v for k,v in new.items() if k not in {'contact_boundaries','context_flags'}}:changed_semantics.append(old['review_key'])
probes={}
for phase in ['before_normalization','contacts_only_normalized','contacts_and_context_normalized']:
 errs=[]
 for old in original:
  row=copy.deepcopy(old);new=current[row['review_key']]
  if phase!='before_normalization':row['contact_boundaries']=copy.deepcopy(new['contact_boundaries'])
  if phase=='contacts_and_context_normalized':row['context_flags']=copy.deepcopy(new['context_flags'])
  try:adapter.validate_new_review(row,ROOT,{})
  except ValueError as exc:errs.append({'review_key':row['review_key'],'error':str(exc)})
 probes[phase]={'count':len(errs),'error_counts':dict(collections.Counter(x['error'].split(': ',1)[-1] for x in errs)),'errors':errs}
# Compiler-only methods/stages are added to isolated copies for schema validation.
# There is no independent semantic review and the primary judgment files retain this distinction.
compiled=[]
for row in rows:
 r=copy.deepcopy(row)
 r['classification_method']='ai_semantic_initial_and_detailed'
 r['classification_stages_completed']=['initial_semantic','detailed_semantic']
 r['independent_recall_reviewed']=False
 compiled.append(r)
stage=P/'formal-schema-preflight-input.jsonl'
stage.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in compiled),encoding='utf-8')
digest=sha(stage);cache={};errors=[]
for row in compiled:
 r=copy.deepcopy(row);r['classification_review_source']={'path':str(stage.resolve()),'sha256':digest}
 try:adapter.validate_new_review(r,ROOT,cache)
 except (ValueError,TypeError,KeyError) as exc:errors.append({'review_key':r['review_key'],'error':str(exc)})
boundary_errors=[];source={s['review_key']:s for s in map(json.loads,(ROOT/'shard-2.jsonl').read_text(encoding='utf-8-sig').splitlines())}
for r in rows:
 for b in r['contact_boundaries']:
  if b['quote'] not in source[r['review_key']]['comment_text']:boundary_errors.append(r['review_key'])
backup=json.loads((P/'schema-before/manifest.json').read_text(encoding='utf-8'))
backup_errors=[m['backup'] for m in backup if sha(m['backup'])!=m['sha256']]
result=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),validator='mother_adapter.validate_new_review',validator_file_sha256=sha(WORK/'mother_adapter.py'),count=len(rows),normalized_fields=['contact_boundaries','context_flags'],pre_normalization_probes=probes,formal_errors=errors,formal_pass_count=len(rows)-len(errors),semantic_changed_keys=changed_semantics,boundary_quote_errors=boundary_errors,boundary_nonempty_count=sum(bool(r['contact_boundaries']) for r in rows),boundary_row_keys=[r['review_key'] for r in rows if r['contact_boundaries']],backup_count=len(backup),backup_integrity_errors=backup_errors,isolated_compiler_metadata_only=True,compiler_metadata_fields=['classification_method','classification_stages_completed','independent_recall_reviewed','classification_review_source'],independent_second_review_performed=False,source_cache_entries=len(cache),isolated_source_sha256=digest,primary_output_sha256=sha(ROOT/'reviewed-new-2.jsonl'),passed=not(errors or changed_semantics or boundary_errors or backup_errors),usage='unknown')
(P/'formal-schema-preflight-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:result[k] for k in ['count','formal_pass_count','formal_errors','semantic_changed_keys','boundary_nonempty_count','boundary_row_keys','backup_integrity_errors','passed','primary_output_sha256']},ensure_ascii=False))
print(json.dumps({k:{a:v for a,v in p.items() if a!='errors'} for k,p in probes.items()},ensure_ascii=False))
