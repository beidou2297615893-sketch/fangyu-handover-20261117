"""Read verified pending-page receipts, never infer model judgments or publication."""
import json,hashlib,os
from pathlib import Path
from datetime import datetime
W=Path(__file__).resolve().parent
base=W/'douyin-registered-v2/increments'
pending=[p.parent for p in base.glob('*/manifest.json') if not (p.parent/'summary.json').exists()]
assert len(pending)<=1
if not pending:
    print('{"pending_batches":0}');raise SystemExit
B=pending[0]
def get(p):return json.loads(p.read_text(encoding='utf-8'))
def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def put(p,v):
    t=p.with_name(p.name+'.checkpoint.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(t,p)
m=get(B/'manifest.json')
assert hashlib.sha256((B/'input.jsonl').read_bytes().replace(b'\r\n',b'\n')).hexdigest()==m['input_sha256']
counts={};final_counts={};allkeys=set()
for i in range(3):
    source={r['review_key']:r for r in jl(B/f'shard-{i}.jsonl')}
    pages=sorted((B/f'AI-pages/shard-{i}').glob('reviewed-*.jsonl'))
    partial=[r for p in pages for r in jl(p)]
    assert len({r['review_key'] for r in partial})==len(partial)
    for r in partial:
        s=source[r['review_key']]
        assert all(r[k]==s[k] for k in ['comment_id','customer_uid','video_id'])
        own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
        qs=list(r.get('evidence',[]))
        for field in ['topics','target_regions','time_mentions','other_constraints','contact_boundaries']:
            qs.extend(t['quote'] for t in r.get(field,[]) if isinstance(t,dict) and 'quote' in t)
        assert all(isinstance(q,str) and q and any(q in txt for txt in own) for q in qs),r['review_key']
        assert r['review_key'] not in allkeys;allkeys.add(r['review_key'])
    counts[str(i)]=len(partial)
    f=B/f'reviewed-new-{i}.jsonl'
    if f.exists():
        rows=jl(f)
        assert len(rows)==len(source) and {r['review_key'] for r in rows}==set(source)
        assert {r['review_key']:r for r in rows}=={r['review_key']:r for r in partial}
        final_counts[str(i)]=len(rows)
    else:final_counts[str(i)]=0
now=datetime.now().astimezone().isoformat()
receipt=dict(checked_at=now,run=B.name,input_comments=m['new_comments'],validated_page_comments=sum(counts.values()),per_shard_page_comments=counts,finalized_primary_comments=sum(final_counts.values()),per_shard_finalized=final_counts,unpublished=True,ID_and_quote_checks_passed=True,source_database_read=False,platform_calls=0)
put(B/'pending-receipt-check.json',receipt)
status=get(B/'model-work-status.json')
status.update(updated_at=now,per_shard_completed=final_counts,per_shard_page_completed=counts,completed_model_records=sum(final_counts.values()),validated_page_comments=sum(counts.values()))
put(B/'model-work-status.json',status)
state=get(W/'当前文本处理运行状态.json')
state['last_working_progress_check']=dict(receipt,canonical_published_classified=state['douyin']['classified_comments'])
state['douyin']['new_frozen_AI_semantic_page_completed']=sum(counts.values())
state['douyin']['new_frozen_AI_semantic_completed']=sum(final_counts.values())
put(W/'当前文本处理运行状态.json',state)
print(json.dumps(receipt,ensure_ascii=False))
