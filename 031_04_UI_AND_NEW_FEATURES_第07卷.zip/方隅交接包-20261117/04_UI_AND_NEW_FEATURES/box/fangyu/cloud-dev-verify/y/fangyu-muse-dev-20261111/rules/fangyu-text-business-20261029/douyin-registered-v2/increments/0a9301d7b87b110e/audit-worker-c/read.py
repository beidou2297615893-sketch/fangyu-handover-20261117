import json,pathlib,sys,collections
B=pathlib.Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/0a9301d7b87b110e'); W=B/'audit-worker-c'
BASE={'role':'discussion','demand_state':'unknown','interest':'unrelated','topics':[],'target_regions':[],'time_mentions':[],'other_constraints':[],'possible_topics':[],'needs_review':[],'contact_boundaries':[],'context_used':['own','body']}
PBASE={'preferred_mother_slot':None,'generic_intro_suitable':False,'tone':'normal','missing_facts':[],'caution':[],'contact_policy':'allow'}
AB={'role':'r','demand_state':'s','interest':'i','reason':'why','topics':'T','target_regions':'R','time_mentions':'M','other_constraints':'O','possible_topics':'P','needs_review':'N','contact_boundaries':'B','context_used':'C','reply_plan':'plan','preferred_mother_slot':'slot','generic_intro_suitable':'generic','missing_facts':'facts','contact_policy':'contact','condition_scope':'scope','group_relation':'group','polarity':'pol','subject':'sub'}
def read(n):
 x=json.loads((B/f'recall-audit/part-1/page-{n:02}.json').read_text(encoding='utf-8')); js=[];cnt=collections.Counter()
 def count(o):
  if isinstance(o,str) and len(o)>26:cnt[o]+=1
  elif isinstance(o,dict):
   for v in o.values():count(v)
  elif isinstance(o,list):
   for v in o:count(v)
 for g in x['post_groups']:
  for c in g['comments']:count(c['first_semantic_judgment'])
 aliases={s:'@'+str(i) for i,(s,c) in enumerate((s,c) for s,c in cnt.items() if c>1)}
 def compact(o):
  if isinstance(o,str):return aliases.get(o,o)
  if isinstance(o,dict):return {AB.get(k,k):compact(v) for k,v in o.items()}
  if isinstance(o,list):return [compact(v) for v in o]
  return o
 print('DEFAULT J=',json.dumps(BASE,ensure_ascii=False),'DEFAULT PLAN=',json.dumps(PBASE,ensure_ascii=False))
 for s,a in aliases.items():print(a,s)
 for g in x['post_groups']:
  print('POST',g['video'],g['post_body'])
  for c in g['comments']:
   j=c['first_semantic_judgment'];st=json.dumps(j,ensure_ascii=False)
   if st not in js:js.append(st)
   print(c['key'],json.dumps(c['text'],ensure_ascii=False),'J'+str(js.index(st)),c['published_at'],('SAME_AUTHOR ' if c['same_author'] else ''),('PARENT='+json.dumps(c['parent'],ensure_ascii=False) if c['parent'] else ''),('CONFLICT' if c.get('source_conflict') else ''))
 print('JUDGMENTS: omitted fields equal DEFAULT J; omitted plan fields equal DEFAULT PLAN')
 for i,s in enumerate(js):
  j=json.loads(s);p=j.pop('reply_plan');j={k:v for k,v in j.items() if k not in BASE or v!=BASE[k]};j['plan']={k:v for k,v in p.items() if k not in PBASE or v!=PBASE[k]};print('J'+str(i),json.dumps(compact(j),ensure_ascii=False,separators=(',',':')))
if __name__=='__main__':read(int(sys.argv[1]))
