import pathlib,json,copy,hashlib,datetime,importlib.util
B=pathlib.Path(__file__).parent;R=B.parent.parent
old=[json.loads(x) for x in (B/'schema-before/batch/reviewed-new-0.jsonl').read_text(encoding='utf-8').splitlines()]
new=[json.loads(x) for x in (R/'reviewed-new-0.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(old)==len(new)==2480
changed_keys=[];changed_items=0
for a,b in zip(old,new):
 assert a['review_key']==b['review_key']
 stripped=copy.deepcopy(b)
 for ac,bc in zip(a['other_constraints'],stripped['other_constraints']):
  if 'detail' not in ac and 'detail' in bc:
   assert bc['detail']==ac['constraint']==bc['constraint'];bc.pop('detail');changed_items+=1
 assert stripped==a,(a['review_key'],'semantic change')
 if a!=b:changed_keys.append(b['review_key'])
assert len(changed_keys)==27 and changed_items==29
pagemap={r['review_key']:r for p in B.glob('reviewed-*.jsonl') for r in map(json.loads,p.read_text(encoding='utf-8').splitlines())}
assert all(pagemap[r['review_key']]==r for r in new)
manifest=json.loads((B/'schema-before/manifest.json').read_text(encoding='utf-8'))
for f in manifest['files']:assert hashlib.sha256(pathlib.Path(f['backup']).read_bytes()).hexdigest()==f['sha256']
# 正式阶段标签/来源指针仅在隔离预检副本添加，不写回本片正式结果或页。
pre=[]
for r in new:
 t=copy.deepcopy(r);assert 'classification_method' not in t and 'classification_review_source' not in t
 t['classification_method']='ai_semantic_initial_and_detailed'
 t['classification_stages_completed']=['initial_semantic','detailed_semantic'];pre.append(t)
p=B/'schema-preflight-source.jsonl';p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in pre),encoding='utf-8');digest=hashlib.sha256(p.read_bytes()).hexdigest()
adapter=R.parents[3]/'mother_adapter.py'
# 批目录层级固定，避免导入其它版本。
adapter=pathlib.Path('work/fangyu-text-business-20261029/mother_adapter.py').resolve()
spec=importlib.util.spec_from_file_location('formal_mother_adapter',adapter);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
errors=[];cache={}
for r in pre:
 row=copy.deepcopy(r);row['classification_review_source']={'path':str(p.resolve()),'sha256':digest}
 try:mod.validate_new_review(row,R,cache)
 except Exception as e:errors.append({'key':r['review_key'],'error':str(e)})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'schema_compatibility_only':True,'affected_rows':27,'affected_constraint_items':29,'changed_keys':changed_keys,'semantic_fields_unchanged':True,'formal_file_matches_pages':True,'backup_file_hashes_verified':len(manifest['files']),'formal_validator':str(adapter),'formal_validator_sha256':hashlib.sha256(adapter.read_bytes()).hexdigest(),'formal_validator_checked_rows':len(pre),'formal_validator_errors':errors,'isolated_preflight_source':str(p.resolve()),'isolated_preflight_source_sha256':digest,'stage_and_provenance_only_in_isolated_preflight':True,'independent_review_claimed':False,'output_sha256':hashlib.sha256((R/'reviewed-new-0.jsonl').read_bytes()).hexdigest(),'before_output_sha256':hashlib.sha256((B/'schema-before/batch/reviewed-new-0.jsonl').read_bytes()).hexdigest()}
(B/'schema-compatibility-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
assert not errors,errors[:5]
vpath=R/'shard-0-validation.json';v=json.loads(vpath.read_text(encoding='utf-8'));v['formal_schema_compatibility']=result;vpath.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
report=R/'shard-0-report.md'
with report.open('a',encoding='utf-8') as f:
 f.write('\n## 正式契约格式兼容修正\n\n27条记录中的29项other_constraints保留原constraint字段，并补detail同值；逐条结构差异检查确认无其它语义字段变化。正式结果与逐页结果一致，受影响页及决定文件、正式结果和原校验报告的原字节已备份至本片schema-before，34份备份散列均核对通过。\n\n正式mother_adapter.validate_new_review对2480条隔离副本完整校验通过，错误0；阶段与来源指针仅添加于隔离预检副本，没有写回正式结果或页，也没有声明独立二审。母句、角色、意向、证据、联系方式策略和授权标记全部未改。本片现已停止。\n\n修正后输出SHA256：'+result['output_sha256']+'\n')
progress=B/'progress.json';v=json.loads(progress.read_text(encoding='utf-8'));v['schema_compatibility_validated_at']=result['at'];v['formal_schema_preflight_errors']=0;v['status']='completed_model_review_and_formal_schema_preflight';progress.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:result[k] for k in ['affected_rows','affected_constraint_items','semantic_fields_unchanged','formal_file_matches_pages','formal_validator_checked_rows','formal_validator_errors','output_sha256']},ensure_ascii=False))
