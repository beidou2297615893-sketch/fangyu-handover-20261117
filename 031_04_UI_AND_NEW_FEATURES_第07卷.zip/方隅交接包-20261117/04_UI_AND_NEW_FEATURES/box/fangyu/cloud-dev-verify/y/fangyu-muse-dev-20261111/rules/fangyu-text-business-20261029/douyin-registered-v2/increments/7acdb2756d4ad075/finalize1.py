from shard1_helper import *
import collections,datetime
parts=['part-1-a.jsonl','part-1-b.jsonl','part-1-c.jsonl','part-1-d.jsonl','part-1-e.jsonl']
out=[]
for f in parts:out.extend(json.loads(x) for x in (P/f).read_text(encoding='utf-8').splitlines())
assert len(rows)==470 and len(out)==470
bykey={o['review_key']:o for o in out}
assert len(bykey)==470 and set(bykey)=={x['review_key'] for x in rows}
out=[bykey[x['review_key']] for x in rows]
# 保留短问中本人提到的区域，但不猜测其是目标住址。
unresolved_regions={1:['七号线'],23:['昆仑数智'],45:['拱墅区'],46:['萧山区'],48:['萧山农业大厦附近'],49:['拱墅'],65:['上海南'],119:['临平'],120:['萧山'],121:['滨江'],123:['富阳区'],178:['萧山'],179:['临平'],180:['钱塘区'],181:['西湖区'],196:['青浦'],199:['徐汇'],204:['龙漕路'],206:['江宁路'],238:['郫筒'],255:['滨江'],256:['萧山','滨江'],257:['钱塘区'],258:['义蓬'],259:['萧山高新六路'],261:['滨江'],264:['长沙'],267:['沈阳'],283:['数字产业园附近'],284:['11号线'],288:['松江区'],326:['萧山丽晶'],327:['萧山'],328:['上城区'],329:['钱塘区'],332:['滨江'],337:['广州','深圳'],342:['松江'],344:['13号线'],345:['宝山'],372:['白石桥南'],392:['炬华科技园附近'],397:['金地广场附近'],402:['海口'],405:['西安'],409:['七宝地铁站附近'],412:['徐汇'],414:['巨峰路附近'],423:['陆家嘴'],427:['大木桥路'],440:['醉白池'],455:['牡丹园附近'],461:['锦江区']}
for i,places in unresolved_regions.items():
 for place in places:
  assert place in rows[i]['comment_text'],(i,place)
  out[i]['target_regions'].append({'text':place,'quote':place,'relation':'unresolved','group_relation':'unknown','condition_scope':place})
errors=[]; sameauthor=0
for x,o in zip(rows,out):
 text=x['comment_text'];key=x['review_key']
 for f in ('human_confirmed','current_need_verified','send_authorized'):
  if o.get(f) is not False:errors.append([key,'false_flag',f])
 if o.get('assigned_store') is not None:errors.append([key,'store_assigned'])
 if o['role'] not in ('demand','supply','mixed','unknown','discussion'):errors.append([key,'invalid_role'])
 if o['interest_at_comment'] not in ('super_high','high','medium','low','very_low','uncertain','unrelated'):errors.append([key,'invalid_interest'])
 for f in ('review_key','comment_id','customer_uid','video_id'):
  if x[f]!=o.get(f):errors.append([key,'identity',f])
 if o['role']=='unknown' and o['interest_at_comment']!='uncertain':errors.append([key,'unknown_interest'])
 if o['role'] not in ('demand','mixed') and o['topic_evidence']:errors.append([key,'topic_subject_role'])
 if set(o['topics'])!={z['pool'] for z in o['topic_evidence']}:errors.append([key,'topic_evidence_mismatch'])
 for q in o['evidence']:
  if not q or q not in text:errors.append([key,'own_evidence'])
 for field in ('topic_evidence','target_regions','other_constraints','possible_topics','time_mentions'):
  for z in o[field]:
   source=z.get('source_kind','comment')
   if source=='same_author_post':
    sameauthor+=1
    valid=x.get('post_author_same_as_commenter') is True and bool(x.get('post_author_uid')) and x['post_author_uid']==x['customer_uid']
    source_text=x.get('post_body','')
   else: valid=source=='comment';source_text=text
   if not valid or not z.get('quote') or z['quote'] not in source_text:errors.append([key,'quote',field,z.get('quote')])
   if field=='topic_evidence' and (z['pool'] not in pools or z['subject']!='own_demand'):errors.append([key,'topic',z])
   for pool in z.get('pools',[]):
    if pool not in pools:errors.append([key,'possible_pool',pool])
for f in ('review_key','comment_id'):
 if len({x[f] for x in rows})!=470 or len({x[f] for x in out})!=470 or {x[f] for x in rows}!={x[f] for x in out}:errors.append(['duplicate_or_mismatch',f])
if errors:raise ValueError(errors)
(P/'reviewed-1.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
v={'input_count':470,'output_count':470,'review_key_unique_count':len({x['review_key'] for x in out}),'comment_id_unique_count':len({x['comment_id'] for x in out}),'identity_fields_equal_in_order':True,'all_quotes_from_own_comment_or_verified_same_author_post':True,'same_author_post_topic_quotes':sameauthor,'same_author_post_context_quotes':0,'all_topic_pools_valid':True,'topic_and_evidence_match':True,'errors':errors,'role_counts':dict(collections.Counter(x['role'] for x in out)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in out)),'human_gold':False,'send_authorized':False,'limitations':'逐条模型语义初判，不是用户金标；结构和引用校验不代表语义准确率或需求当前性、住房资格、门店适配及房源事实已核。'}
(P/'validation-1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
claim=json.loads((P/'claim-1.json').read_text(encoding='utf-8'));claim.update(status='completed',completed_at=datetime.datetime.now().astimezone().isoformat(),input_count=470,output_count=470)
(P/'claim-1.json').write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(v,ensure_ascii=False,indent=2))
