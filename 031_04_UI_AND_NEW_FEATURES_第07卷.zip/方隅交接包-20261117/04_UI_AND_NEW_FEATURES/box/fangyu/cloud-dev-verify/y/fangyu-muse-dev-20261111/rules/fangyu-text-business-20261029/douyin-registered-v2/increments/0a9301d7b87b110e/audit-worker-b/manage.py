import json,pathlib,copy,hashlib,sys
b=pathlib.Path(__file__).resolve().parent.parent; w=b/'audit-worker-b'
def page(part,num):return b/f'recall-audit/part-{part}/page-{num:02}.json'
def save(part,num,keeps,changes,reason):
 p=page(part,num); doc=json.loads(p.read_text(encoding='utf-8')); cs=[c for g in doc['post_groups'] for c in g['comments']]; expected=[c['key'] for c in cs]; ks=keeps.split(); assert len(ks)==len(set(ks)); assert not set(ks)&set(changes); assert set(ks)|set(changes)==set(expected),(set(expected)-set(ks)-set(changes),set(ks)|set(changes)-set(expected))
 out=[{'review_key':k,'decision':'keep','reason':reason,'patch':{}} if k in ks else {'review_key':k,'decision':'change','reason':changes[k].pop('_audit_reason',changes[k].get('reason','按本人原文修正分池/语境')),'patch':changes[k]} for k in expected]
 p.with_suffix('.audit.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in out),encoding='utf-8')
 prog=json.loads((w/'progress.json').read_text(encoding='utf-8')) if (w/'progress.json').exists() else {'worker':'b','pages':{}}
 prog['pages'][f'{part}/{num:02}']={'records':len(out),'keep':len(ks),'change':len(changes),'semantic_read_complete':True};prog['records']=sum(v['records'] for v in prog['pages'].values());prog['changes']=sum(v['change'] for v in prog['pages'].values());prog['status']='in_progress';(w/'progress.json').write_text(json.dumps(prog,ensure_ascii=False,indent=2),encoding='utf-8');print(part,num,len(out),len(changes))
def first(part,num,key):
 return next(c['first_semantic_judgment'] for g in json.loads(page(part,num).read_text(encoding='utf-8'))['post_groups'] for c in g['comments'] if c['key']==key)
def tp(pool,quote,pol='ask',sub='own_demand',cs=None):return dict(pool=pool,quote=quote,polarity=pol,subject=sub,condition_scope=cs)
def plan(slot=None,gen=False,facts=None,cp='allow',tone='normal',caution=None):return dict(preferred_mother_slot=slot,generic_intro_suitable=gen,tone=tone,missing_facts=facts or [],caution=caution or [],contact_policy=cp)
