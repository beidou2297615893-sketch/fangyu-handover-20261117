from decisions import *
a=original(25,'D7092');t=original(25,'D7101')['time_mentions'];t[0]['time_role']='other';t[0]['verification']='月底去为到达/出行时间，未明确当日入住；保留发表时间锚'
emit(25,'''D7084 D7086 D7088 D7090 D7097 D7099 D7103 D7287 D7289 D7292 D7295 D7300 D7106 D7108 D7110 D7112 D7114 D7306 D7308 D7310 D7312 D7314 D7316 D7318 D7137 D7139 D7141 D7143 D7145 D7147 D7149 D7151 D7153 D7155 D7320 D7322 D7324 D7326 D7328 D7330 D7332 D7334 D7336 D7338 D7157 D7159 D7161 D7163 D7165 D7167 D7169 D7172 D7175 D7342 D7344 D7347 D7351 D7354 D7358 D7360 D7183 D7188 D7190 D7192 D7194 D7196 D7199 D7201 D7371 D7374 D7376 D7380 D7383 D7386 D7203 D7205 D7208 D7210 D7213 D7215 D7223 D7225 D7227 D7229 D7231 D7233 D7235 D7237 D7239 D7241 D7243 D7245 D7247 D7249 D7251 D7253 D7255 D7258 D7260 D7262 D7264 D7266 D7270 D7274 D7276 D7278 D7280 D7282 D7304 D7340 D7365 D7369''',{
'D7092':('好点是房屋整体品质偏好，不是具体户型。',dict(topics=a['topics'][:1],other_constraints=[dict(quote='好点的',detail='希望整体住房条件好些，未说明具体户型面积或设施')])),
'D7094':('明确之后找房才找作者，取消适合即时介绍的母句计划。',dict(reply_plan=plan(),needs_review=['后续开始找房日期与实际要求尚未给出'])) ,
'D7101':('月底去是到达时间，不等于明确月底入住。',dict(time_mentions=t,needs_review=original(25,'D7101')['needs_review']+['月底到达时间与实际入住日是否一致待核'])) ,
'D7116':('因房租打消去上海计划，其他住房需求未明，不宜继续上海通用介绍。',dict(interest='uncertain',reason='表达因价格不想去上海，其他城市或后续住房需求未说明',reply_plan=plan())) ,
'D7125':('装修展示帖仅多少米，价格面积及本人租意均不明，不能定高。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='多少米指标未明且正文仅装修展示，无确定求租推进',needs_review=['米所指价格或面积、本人是否住宅租赁需求待核'],reply_plan=plan())) ,
'D7128':('看看可能只是看装修内容，没有明确约看动作或住房指向。',dict(role='unknown',demand_state='unknown',interest='uncertain',topics=[],reason='装修分享下看看对象未明，保留待核不作看房请求',needs_review=['看看是浏览作品、索取资料还是实地看房待核'],reply_plan=plan())) ,
'D7378':('地质大学是上学地点，不是工作单位，应保留学习通勤语境。',dict(target_regions=[reg('地质大学',relation='unresolved',scope='上学地点，非工作单位')])),
'D7272':('买房五人容量不能进入住宅租赁需求统计，保留购买用途和家庭容量。',dict(topics=[],other_constraints=[dict(quote='想买一套中大的房子，不用很大，够5️⃣个人住',detail='购买住房且需容纳五人，非租赁需求或租房户型条件')],reason='明确想买中大房子供五人居住，非住宅租赁询盘'))
})
