import json,pathlib,hashlib,sys,tempfile,datetime,collections
from decisions import BASE,PART,WORK
ROOT=BASE.parents[2];sys.path.insert(0,str(ROOT));import mother_adapter
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review contact_boundaries context_flags reply_plan'.split())
def read(p):return [json.loads(l) for l in p.read_text(encoding='utf8').splitlines() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
errors=[];expected=[];reviews=[];merged=[];counts=[];quote_checks=0;source_checks=[]
primary={r['review_key']:r for i in range(3) for r in read(BASE/f'reviewed-new-{i}.jsonl')}
inputs={r['review_key']:r for r in read(BASE/'input.jsonl')}
task=json.loads((PART/'task.json').read_text(encoding='utf8'))
for s in task['primary_sources']:
 actual=sha(BASE/s['path']);source_checks.append({'path':s['path'],'unchanged':actual==s['sha256'],'sha256':actual})
 if actual!=s['sha256']:errors.append({'source_changed':s['path']})
for page in range(17):
 p=PART/f'page-{page:02}.json';d=json.loads(p.read_text(encoding='utf8'));cmap={c['key']:(g,c) for g in d['post_groups'] for c in g['comments']};ids=list(cmap);expected+=ids
 audit=read(PART/f'page-{page:02}.audit.jsonl');reviews+=audit
 assert len(audit)==120 and len(set(r['review_key'] for r in audit))==120
 assert set(r['review_key'] for r in audit)==set(ids)
 counts.append({'page':page,'input':len(ids),'output':len(audit),'changes':sum(r['decision']=='change' for r in audit),'id_set_equal':True,'duplicates':0,'audit_sha256':sha(PART/f'page-{page:02}.audit.jsonl')})
 for a in audit:
  k=a['review_key'];g,c=cmap[k];assert set(a)=={'review_key','decision','reason','patch'};assert a['decision'] in ('keep','change');assert a['reason'];assert set(a['patch'])<=allowed
  assert bool(a['patch'])==(a['decision']=='change')
  original=primary[k];row=dict(original);row.update(a['patch']);raw=inputs[k]
  for f,v in c['first_semantic_judgment'].items():
   if original.get(f)!=v:errors.append({'key':k,'snapshot_mismatch':f})
  permitted=raw['comment_text']+('\n'+raw['post_body'] if raw['post_author_same_as_commenter'] else '')
  quotes=list(row['evidence'])
  for f in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
   for item in row[f]:
    if isinstance(item,dict) and 'quote' in item:quotes.append(item['quote'])
  for q in quotes:
   quote_checks+=1
   if q not in permitted:errors.append({'key':k,'invalid_quote':q})
  for f in ('review_key','comment_id','customer_uid','video_id','platform'):
   assert row[f]==original[f]
  assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
  assert row['reply_plan']['preferred_mother_slot'] in (None,1,2,7,13,16,19,25,28,31,34)
  row['classification_method']='ai_independent_semantic_fine_review';row['classification_stages_completed']=mother_adapter.REVIEW_METHOD_STAGES[row['classification_method']]
  merged.append(row)
assert len(expected)==2040 and len(expected)==len(set(expected));assert set(expected)=={r['review_key'] for r in reviews}
with tempfile.TemporaryDirectory(prefix='isolated-preflight-',dir=WORK) as tmp:
 source=pathlib.Path(tmp)/'merged-review.jsonl';source.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in merged),encoding='utf8');digest=sha(source);cache={}
 for row in merged:
  row=dict(row);row['classification_review_source']={'path':str(source.relative_to(BASE)),'sha256':digest}
  try:mother_adapter.validate_new_review(row,BASE,cache)
  except Exception as exc:errors.append({'key':row['review_key'],'formal_preflight_error':str(exc)})
result={'worker':'a','assigned_pages':list(range(17)),'read_every_assigned_comment_and_first_judgment':True,'input_records':len(expected),'audit_records':len(reviews),'id_set_equal':set(expected)=={r['review_key'] for r in reviews},'duplicates':len(reviews)-len({r['review_key'] for r in reviews}),'changes':sum(r['decision']=='change' for r in reviews),'keeps':sum(r['decision']=='keep' for r in reviews),'quote_checks':quote_checks,'quote_errors':sum('invalid_quote' in e for e in errors),'formal_validator':'mother_adapter.validate_new_review','formal_preflight_errors':sum('formal_preflight_error' in e for e in errors),'isolated_temporary_compilation_removed':True,'primary_source_checks':source_checks,'pages':counts,'errors':errors,'usage':'unknown','status':'passed' if not errors else 'failed','limitations':['仅模型独立语义复核，不是用户金标；未读更深回复、未核门店事实、未验证当前仍找房。','page17由root负责，不在本worker覆盖范围。'],'updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(WORK/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ('pages','primary_source_checks','limitations')},ensure_ascii=False))
