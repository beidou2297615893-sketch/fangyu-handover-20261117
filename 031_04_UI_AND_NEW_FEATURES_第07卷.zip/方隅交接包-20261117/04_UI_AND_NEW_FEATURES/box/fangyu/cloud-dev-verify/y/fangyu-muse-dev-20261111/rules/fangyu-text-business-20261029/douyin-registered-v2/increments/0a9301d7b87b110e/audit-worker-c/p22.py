from decisions import *
r=original(22,'D6239')['target_regions'];r[1]['relation']='unresolved'
r2=original(22,'D6319')['target_regions']
for v in r2[1:]:v['condition_scope']='鼓楼不合适时再考虑台江或晋安'
t=original(22,'D6253')['time_mentions'];t[0]['time_role']='other';t[0]['verification']='后天过去为到达时间，未明确当天入住；保留发表锚，不以分析日替代'
emit(22,'''D6140 D6144 D6146 D6148 D6355 D6357 D6365 D6367 D6369 D6154 D6156 D6159 D6161 D6163 D6165 D6167 D6393 D6395 D6397 D6399 D6401 D6403 D6169 D6171 D6173 D6175 D6177 D6179 D6181 D6183 D6185 D6187 D6189 D6191 D6193 D6195 D6197 D6199 D6201 D6203 D6205 D6207 D6405 D6407 D6409 D6411 D6413 D6415 D6417 D6419 D6421 D6423 D6209 D6211 D6213 D6215 D6217 D6219 D6221 D6223 D6225 D6228 D6231 D6233 D6236 D6242 D6244 D6429 D6431 D6434 D6438 D6440 D6442 D6250 D6255 D6258 D6260 D6262 D6264 D6266 D6268 D6270 D6272 D6274 D6276 D6278 D6280 D6283 D6285 D6287 D6289 D6291 D6297 D6301 D6304 D6307 D6445 D6448 D6313 D6317 D6323 D6325 D6329 D6331 D6339 D6343 D6345 D6349 D6374 D6377 D6380 D6382 D6384 D6386 D6388''',{
'D6239':('只能回龙观了吗是待评价选项，非确认接受；预算16-17单位须留核。',dict(target_regions=r,needs_review=original(22,'D6239')['needs_review']+['回龙观是否接受待核；16-17金额单位未明，不擅换算'])) ,
'D6253':('后天过去是到达而非明确入住，保留紧迫求房动作和原时间锚。',dict(time_mentions=t,needs_review=['到达日期按原发表时间理解，实际入住日、是否需要到达当日可住及当前是否仍求租待核'])) ,
'D6295':('肿瘤医院只是通勤参照，未说在院工作，不能无证归工作。',dict(target_regions=[reg('肿瘤医院',relation='unresolved')],needs_review=['医院是工作、就医或其他通勤目的及具体院区待核；预算通勤原条件保留'])) ,
'D6319':('台江或晋安仅鼓楼不行时接受，应保留替代条件层次。',dict(target_regions=r2)) ,
'D6390':('长租总时长未明，应保留租期原词；月租是报价单位。',dict(time_mentions=[dict(quote='长租',time_role='lease_duration',anchor_source='comment_published_at',anchor_time='2026-02-10T15:17:33+00:00',normalized=None,verification='明确长租，未给总月数；月租为报价周期')]))
})
