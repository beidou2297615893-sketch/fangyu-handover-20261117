import json,collections
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(s) for s in (p/'shard-b.jsonl').read_text(encoding='utf-8').splitlines()]
def S(s):return {int(x) for x in s.split()}
supply=S('71 74 75 80 82 87 89 94 95 96 98 101 102 106 107 109 112 113 114 117 118 121 123 124 126 128 129 130 132 134 137 138 139')
discussion=S('73 78 79 83 84 85 86 90 104 105 110 111 116 120 122 125 127 133 135')
unknown=S('72 76 77 81 88 91 92 93 97 99 100 103 115 119 131 136 140')
regions={75:'闵行梅陇15号线景西路地铁站',80:'13号线江宁路地铁口',82:'长宁中山公园站旁边',87:'2号线潘祥路过家会计学院附近',89:'松江大学城地铁口',94:'浦东川沙古镇',95:'通协小区',96:'大场镇地铁站附近',98:'虹桥徐泾',101:'普陀中环以内曹杨二村',102:'天山小区',107:'银都路地铁站',109:'上海三林世博杨思前滩',112:'普陀桃浦新村地铁站',113:'陆家嘴·招远小区',114:'岚皋路地铁站旁',117:'桂林路站漕宝路99弄',118:'江苏路495弄25号',121:'汇金路地铁口',123:'普陀中浩云花园',124:'爱博一村',128:'梧桐区',129:'民雷路地铁站',130:'三湘花苑西苑',132:'新江湾城',134:'唐镇地铁站',137:'七宝地铁站',138:'琪衡公寓'}
times={87:[('短租两个月','lease_duration','supply')],94:[('租期明年七月底','lease_duration','supply'),('随时可以搬','move_in','supply')],101:[('半个月','lease_duration','supply')],113:[('随时看房','viewing','supply'),('租期到明年5月','lease_duration','supply')],124:[('入住时间可聊','move_in','supply')],129:[('剩余租期8个月','lease_duration','supply')],137:[('这月底就腾出来了','other','supply')],138:[('合同是25号开始','lease_duration','supply'),('随时看房','viewing','supply'),('随时入住','move_in','supply')]}
notes={72:'询问某处是否有房，但标题未说明房源或交易对象；是否本人求租及具体地点含义待核。',76:'只问是否考虑合租，未说明本人是找室友、提供房间或寻租。',77:'只给小区名和视频，视频未采集，供需对象不明。',81:'只问位置，标题未明确出租、出售或经验介绍。',88:'仅自称房东，并不明确本人是否正在出租；父评论关系未核。',91:'房屋描述简短，未明确是提供房源还是建议。',92:'询问某站位置是否可以，未明确本人是否提供房源或求租。',93:'只有价格与小区名，缺少完整交易和本人角色。',97:'仅说求图；父评论关系未核，不可将其内容作为明确指代。',99:'仅说“丝”，缺少具体对象；父评论关系未核。',100:'仅小区名，未说明本人供需角色。',103:'房屋特点简短，未明确本人是推荐还是寻找。',115:'问价格，标题提及转租但用途与交易对象不明，不能假定住宅求租。',119:'只有金额和房型特点，未明确是提供还是寻求房源。',131:'只有地铁站距离，未明本人供需角色。',136:'仅问哪里，帖子是租房观点讨论且直接父评论关系未核。',140:'仅给出位置和房屋设施，缺少明确供需关系。'}
out=[]
for d in rows:
 n=int(d['review_key'][1:]);t=d['text'];a=dict(role='unknown',demand_state='unknown',interest='uncertain',topics=[],target_regions=[],time_mentions=[],other_constraints=[],possible_topics=[],evidence=[t],reason='说话角色或询问对象不能确定。',context_used=['own'],needs_review=[])
 if n in supply:
  a.update(role='supply',interest='unrelated',reason='本人提供、推荐或转租房源，或提供找房服务，没有明确表达本人另找房。')
  if n in regions:
   q=regions[n];assert q in t,(n,q)
   a['target_regions'].append(dict(text=q,quote=q,relation='offered',group_relation='unknown',condition_scope='提供或推荐的房源地区，不代表本人新求租目标'))
  if n in (89,96,121):a['needs_review'].append('询问对方是否考虑该房，是否房东或代理及权限未明。')
  if n==130:a['needs_review'].append('末尾的拒绝条件可能是对求租信息的引用，不能归给提供房源者的本人需求；需核对评论关系。')
  if n==128:a['reason']='以房东身份讨论自身房屋出租要求，不是本人求租。';a['needs_review'].append('主要是讨论性质，是否在主动招租尚不明确。')
 elif n in discussion:
  a.update(role='discussion',interest='unrelated',reason='评论属于观点、建议、历史租住经历或群组信息，未表达本人新的租房需求。')
  if n==78:a['needs_review'].append('询问另一人居住人数，未说明本人是否需要房源。')
 elif n==108:
  a.update(role='demand',demand_state='active_at_comment',interest='high',reason='本人请求推荐租房联系人，表达租房相关主动联系需求。',topics=[dict(pool='看房联系',quote='租房子的能推给我不',polarity='ask',subject='own_demand',condition_scope='请求推荐租房联系人')],needs_review=['具体地区、需求与当前进度未知；父评论关系未核，不继承父文信息。'])
 else:
  assert n in unknown,n
  a['needs_review'].append(notes[n])
  if n==72:a['target_regions']=[dict(text='青浦天空万科附近',quote='青浦天空万科附近',relation='unresolved',group_relation='unknown',condition_scope='询问地区是否有房，是否本人目标地区待核')];a['topics']=[dict(pool='房源状态',quote='有吗',polarity='ask',subject='unresolved',condition_scope='具体房源对象待核')]
  if n in (81,136):a['topics']=[dict(pool='位置通勤',quote='位置哪里呢' if n==81 else '哪里啊',polarity='ask',subject='unresolved',condition_scope='询问对象待核')]
  if n==97:a['topics']=[dict(pool='看房联系',quote='求图',polarity='ask',subject='unresolved',condition_scope='所指图片及交易对象不明')]
  if n==115:a['topics']=[dict(pool='价格预算',quote='多少钱',polarity='ask',subject='unresolved',condition_scope='用途及具体交易对象待核')];a['context_used'].append('title')
 for q,role,subject in times.get(n,[]):
  assert q in t,(n,q)
  a['time_mentions'].append(dict(quote=q,time_role=role,subject=subject,anchor_source='comment_published_at' if d['published_at'] else 'unknown',anchor_time=d['published_at'] or None,normalized=None,verification='保留原词，未确认具体归一日期或当前房态'))
 if n==108:a['mother_assessment']={'candidate_approved_mother':'1','status':'conditional_only','reason':'需核实本人需求、可承接地区、账号住户身份及介绍优惠的真实有效性；未授权发送。','sendable':False}
 else:a['mother_assessment']={'candidate_approved_mother':None,'status':'not_selected','reason':'未确认本人当前求租，或为供给、讨论，不套用获客母句。','sendable':False}
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],**a,human_confirmed=False,send_authorized=False,store_assignment=None))
assert len(rows)==len(out)==70
assert {(r['review_key'],r['comment_id']) for r in rows}=={(r['review_key'],r['comment_id']) for r in out}
for r,o in zip(rows,out):
 for e in o['evidence']+[x['quote'] for x in o['topics']]+[x['quote'] for x in o['target_regions']]+[x['quote'] for x in o['time_mentions']]:assert e in r['text'],(o['review_key'],e)
 assert not(o['role']=='unknown' and o['interest']=='unrelated')
(p/'reviewed-b.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
val={'inputs':len(rows),'outputs':len(out),'id_pairs_equal':True,'all_quotes_verbatim':True,'role_counts':dict(collections.Counter(x['role'] for x in out)),'needs_review_count':sum(bool(x['needs_review']) for x in out),'human_confirmed':False,'send_authorized':False}
(p/'b-validation.json').write_text(json.dumps(val,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(val,ensure_ascii=False,indent=2))
