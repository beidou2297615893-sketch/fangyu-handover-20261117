"""Serialize root's explicitly read 167 semantic decisions; never select unread IDs."""
import json,copy,hashlib,sys
from pathlib import Path
D=Path(__file__).resolve().parent;B=D.parent;W=B.parents[2];sys.path.insert(0,str(W))
from mother_adapter import validate_new_review
def get(p):return json.loads(p.read_text(encoding='utf-8'))
def jl(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
primary={r['review_key']:r for i in range(3) for r in jl(B/f'reviewed-new-{i}.jsonl')}
src={r['review_key']:r for r in jl(B/'input.jsonl')}
mothers={m['slot']:m for m in get(W/'approved-mothers-model-view.json')}
def topic(pool,q,pol='ask',subject='own_demand',scope=None):return dict(pool=pool,quote=q,polarity=pol,subject=subject,condition_scope=scope)
def plan(slot):return dict(preferred_mother_slot=slot,generic_intro_suitable=True,tone='normal',contact_policy='allow',missing_facts=list(dict.fromkeys([mothers[slot]['required_facts'],mothers[1]['required_facts'],'客户是否当前找房、目标地区及同一门店同一房源具体条件尚需核实'])),caution=['只选择已认可母句；通用介绍并非已回答具体问题或已获发送许可'])
patches={}
def change(k,why,**p):p['reason']=why;patches[k]=dict(reason=why,patch=p)
change('D4897','能租到这么好的是同类住房向往，未指明户型，保留待核但移除虚设户型池。',topics=[],needs_review=['是否开始共同找房未知；好未指明面积、户型或居住方式'])
change('D4704','问博主通勤时长，不能据此认定本人已找房，也不宜机械归无关。',interest='uncertain',topics=[topic('位置通勤','上班通勤多久','ask','other_person')],needs_review=['询问的是博主通勤，是否本人有相似住房需求未明'])
change('D4710','本人明确想租并询位置，保留高意向；想租本身不是看房或联系条件。',topics=[copy.deepcopy(primary['D4710']['topics'][0])])
change('D4714','具体询问房屋晾晒功能，保留住房探索线索，当前找房动作未知。',role='demand',demand_state='unknown',interest='medium',topics=[topic('房内设施','晒衣服在哪')],needs_review=['询问原帖住房的晾晒配置，是否本人准备找房待核'],reply_plan=plan(34))
change('D4907','询问找房渠道，未提出看房联系或说明本人当前找房，不强塞看房联系池。',demand_state='unknown',topics=[],other_constraints=[dict(quote='咋找的房源',detail='询问找房渠道，是否本人正在找房待核')],needs_review=['找房渠道咨询，未确认本人当前找房推进'])
change('D4913','隔音是居住品质问题，保留原问句为其他条件，不冒充房内设备。',topics=[],other_constraints=[dict(quote='隔音好吗',detail='询问隔音表现，是否当前找房及硬性要求待核')])
change('D4722','老小区询问属于楼龄小区性质，未指定户型面积，按其他条件保留。',topics=[],other_constraints=[dict(quote='老小区吗',detail='询问原帖小区楼龄或性质，不是户型要求')],reply_plan=plan(1))
regions=copy.deepcopy(primary['D4732']['target_regions']);regions[1].update(relation='preferred',condition_scope='尽量离成都职业技术学院花源校区近一点')
change('D4732','新津区为求租地区，尽量近花源校区是偏好，不能升格为必须落在校区。',target_regions=regions)
times=copy.deepcopy(primary['D4866']['time_mentions']);times[0].update(time_role='other',verification='这几天明确指回成都，不等同确定入住；保留原评论时间锚且不归一到今天')
change('D4866','正在找同租人，回成都日期与确定入住日期分开记录。',time_mentions=times)
change('D4756','三号线及东宝兴路位置条件保留，隔音要求单列其他条件。',topics=[copy.deepcopy(primary['D4756']['topics'][1])],other_constraints=[dict(quote='隔音稍微好点',detail='希望隔音较好；属于居住品质条件而非具体设备')])
regions=copy.deepcopy(primary['D4759']['target_regions']);regions[0]['relation']='unresolved'
change('D4759','博世xc是选址参照但原文未明确上班关系，保留标识并核参照性质。',target_regions=regions,needs_review=['博世xc具体所指及是否工作地待核，不据名称推定身份或通勤事实'])
change('D4783','明确本人可接受的房租占工资比例，保留预算偏好线索，未确认当前找房。',role='demand',demand_state='unknown',interest='medium',topics=[topic('价格预算','工资的 10%~20% 去付房租','prefer')],needs_review=['个人预算比例偏好，不代表当前正在找房；金额和收入未知'],reply_plan=plan(1))
change('D4797','询问住房布局和月报价口径，可保留住房探索，不能因无我字删除潜在线索。',role='demand',demand_state='unknown',interest='medium',topics=[topic('户型面积与居住方式','几房几厅'),topic('价格预算','一万多几房几厅？一个月吗？')],needs_review=['询问帖内住房布局和月价，不代表本人预算一万多或已明确当前找房'],reply_plan=plan(34))
change('D4815','老破房子是房屋状况取舍，不是户型；梧桐树下保留位置氛围偏好。',topics=[copy.deepcopy(primary['D4815']['topics'][1])],other_constraints=[dict(quote='宁愿住老破房子也要住梧桐树下',detail='接受房屋较旧以换取所述街区氛围，未明确具体地区和当前找房')])
change('D4825','比较两地价格与安全，安全单列其他条件，不错误归为房内设施。',topics=copy.deepcopy(primary['D4825']['topics'][:2]),other_constraints=[dict(quote='安全',detail='比较居住安全性，不代表已确认任何门店或片区安全')])
change('D4831','本人明确最终勉强租了，无新换房请求，记录需求已结束而非身份不明讨论。',role='demand',demand_state='ended',interest='unrelated',needs_review=[])
change('D4834','预算与一居保留，并将明确工作参照归入位置通勤池，不推定必须住工作地。',topics=copy.deepcopy(primary['D4834']['topics'])+[topic('位置通勤','在马甸桥上班','fact')])
change('D4933','明确请求按指定位置找房，高意向保留；尚未提出看房或联系方式。',topics=[copy.deepcopy(primary['D4933']['topics'][0])])
for k,q in [('D4877','龙潭寺'),('D4952','浦东'),('D4859','双流彭镇幸福新村'),('D7439','滨江区')]:
    change(k,'明确求租地区同时进入位置通勤池；原有身份、意向和其他条件保留。',topics=copy.deepcopy(primary[k]['topics'])+[topic('位置通勤',q)])
for k in ['D7392','D7395','D7401','D4779','D4929']:
    change(k,'现住或曾住费用比较，不等于当前求租身份；未提出新找房需求。',role='discussion',demand_state='unknown',interest='unrelated')
regions=copy.deepcopy(primary['D7438']['target_regions']);regions[0]['relation']='unresolved'
change('D7438','明确询问余杭房源位置，保留高关注；查询地名不等于确认目标地区。',target_regions=regions,needs_review=['余杭是所询房源位置，是否本人目标地区仍待核'])
regions=copy.deepcopy(primary['D7432']['target_regions']);regions[0]['relation']='unresolved'
change('D7432','大学地名片段保留住房关注，位置关系和当前找房动作未明确。',demand_state='unknown',target_regions=regions,topics=[topic('位置通勤','浙大紫金港','unknown','unresolved')],needs_review=['仅地名片段，可能是所询位置、工作学习参照或目标地区，须核本人用途'])
change('D7426','这个吧可能在选择房源，也可能只是分享，保留未知而非直接排无关。',role='unknown',demand_state='unknown',interest='uncertain',needs_review=['艾特后这个吧的选择对象和实际找房意图未知'])
times=copy.deepcopy(primary['D7437']['time_mentions']);times[0].update(time_role='other',verification='过几天租房可能指开始寻找或入住，保留原词与发表锚，不将二者强行等同')
change('D7437','本人现在主动加联系为高意向，过几天租房的起租或开始寻找含义待核。',time_mentions=times)
explicit={
 (0,17):'''D4692 D4694 D4696 D4698 D4879 D4881 D4883 D4885 D4887 D4889 D4891 D4893 D4895 D4897 D4700 D4702 D4704 D4706 D4708 D4710 D4712 D4714 D4716 D4718 D4899 D4901 D4903 D4905 D4907 D4909 D4911 D4913 D4915 D4917 D4722 D4724 D4726 D4729 D4732 D4734 D4736 D4859 D4862 D4866 D4872 D4875 D4877 D4739 D4741 D4743 D4745 D4747 D4749 D4751 D4753 D4756 D4759 D4761 D4769 D4944 D4946 D4948 D4950 D4952 D4954 D4958 D4771 D4773 D4775 D4777 D4779 D4781 D4783 D4785 D4787 D4789 D4791 D4793 D4795 D4797 D4799 D4801 D4803 D4805 D4807 D4809 D4811 D4813 D4815 D4817 D4819 D4821 D4823 D4825 D4827 D4829 D4831 D4834 D4836 D4839 D4843 D4845 D4847 D4849 D4851 D4853 D4855 D4857 D4920 D4922 D4924 D4927 D4929 D4933 D4935 D4938 D4962 D4964 D4968 D4970'''.split(),
 (0,26):'''D7388 D7390 D7392 D7394 D7396 D7398 D7400 D7402 D7404 D7406 D7408 D7410 D7412 D7414 D7416 D7418 D7420 D7422 D7424 D7426 D7428 D7431 D7437 D7439'''.split(),
 (1,26):'''D7389 D7391 D7393 D7395 D7397 D7399 D7401 D7403 D7405 D7407 D7409 D7411 D7413 D7415 D7417 D7419 D7421 D7423 D7425 D7427 D7429 D7432 D7438'''.split()}
all_audits=[]
for (part,n),keys in explicit.items():
    page=B/f'recall-audit/part-{part}/page-{n:02}.json'
    expected=[c['key'] for g in get(page)['post_groups'] for c in g['comments']]
    assert keys==expected, (part,n,len(keys),len(expected),set(keys)^set(expected))
    rows=[]
    for k in keys:
        if k in patches:
            v=patches[k];rows.append(dict(review_key=k,decision='change',reason=v['reason'],patch=v['patch']))
        else:rows.append(dict(review_key=k,decision='keep',reason='逐条核对原评论、共享正文及首判；现有意向和条件归属可保留，未知与事实缺口继续留核。',patch={}))
    f=page.with_name(f'page-{n:02}.audit.jsonl');assert not f.exists()
    f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8');all_audits+=rows
assert len(all_audits)==167 and {r['review_key'] for r in all_audits}==set().union(*[set(x) for x in explicit.values()])
assert set(patches)<={r['review_key'] for r in all_audits}
merged=[];quote_count=0
for a in all_audits:
    r=copy.deepcopy(primary[a['review_key']]);r.update(a['patch']);s=src[a['review_key']]
    own=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
    qs=list(r['evidence'])
    for field in ['topics','target_regions','time_mentions','other_constraints','contact_boundaries']:
        qs.extend(t['quote'] for t in r[field] if isinstance(t,dict) and 'quote' in t)
    assert all(q and any(q in text for text in own) for q in qs),a['review_key'];quote_count+=len(qs)
    r.update(classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']);merged.append(r)
f=D/'schema-preflight-source.jsonl';raw=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in merged).encode('utf-8');f.write_bytes(raw);h=hashlib.sha256(raw).hexdigest();cache={}
for r in merged:
    candidate=copy.deepcopy(r);candidate['classification_review_source']={'path':str(f),'sha256':h};validate_new_review(candidate,B,cache)
receipt=dict(complete=True,explicit_reviewed_records=167,changes=sum(a['decision']=='change' for a in all_audits),verbatim_quotes_checked=quote_count,formal_schema_passed=167,source_modified=False,platform_calls=0,actual_task_usage=None,focus='Intent, subject/condition/time/region and mother slot suitability; repeated mother fact literals retained, not reverified as actual housing facts.',pages=[dict(part=i,page=n,records=len(ks)) for (i,n),ks in explicit.items()])
(D/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False))
