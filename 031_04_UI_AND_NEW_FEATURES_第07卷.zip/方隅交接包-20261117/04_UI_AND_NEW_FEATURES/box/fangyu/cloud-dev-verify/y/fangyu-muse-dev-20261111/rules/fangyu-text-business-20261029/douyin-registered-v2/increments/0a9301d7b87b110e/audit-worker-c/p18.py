from decisions import *
r=original(18,'D5249')['target_regions'];r[0]['relation']='unresolved';r[1]['relation']='unresolved';r[2]['condition_scope']='按当前预算租不起，未表达任意价格下永久排除'
emit(18,'''D4974 D4976 D4978 D4980 D4982 D4987 D4989 D4991 D4993 D4995 D4997 D4999 D5001 D5186 D5188 D5190 D5192 D5194 D5196 D5198 D5200 D5003 D5005 D5007 D5009 D5011 D5013 D5015 D5017 D5019 D5202 D5204 D5206 D5208 D5210 D5212 D5214 D5216 D5218 D5220 D5021 D5023 D5025 D5027 D5029 D5032 D5034 D5037 D5039 D5223 D5225 D5227 D5232 D5234 D5237 D5239 D5241 D5041 D5043 D5048 D5056 D5059 D5243 D5245 D5247 D5251 D5255 D5257 D5061 D5063 D5066 D5068 D5070 D5073 D5075 D5077 D5080 D5083 D5085 D5087 D5089 D5091 D5093 D5095 D5097 D5100 D5104 D5106 D5108 D5110 D5112 D5114 D5116 D5120 D5122 D5125 D5127 D5130 D5132 D5134 D5136 D5140 D5147 D5153 D5157 D5159 D5161 D5165 D5168 D5170 D5172 D5175 D5177 D5180 D5183''',{
'D5045':('疑串串房及甲醛是环境健康风险，不等于拒绝某项房内设施。',dict(topics=[],other_constraints=[dict(quote='看着都像串串房咋办',detail='担心中介图示房源为突击装修出租并有甲醛风险；非已证实检测超标'),dict(quote='买了个测甲醛仪器不知道准不',detail='本人询检测仪准确性，未核仪器性能，不写房源已安全')],needs_review=['本人当前是否已签租、房源真实空气质量及检测结论待核'])),
'D5249':('租不起为当前价格限制，不是任意条件下排除；两地工作/现居角色仍需核。',dict(target_regions=r,needs_review=original(18,'D5249')['needs_review']+['三里屯及飞书是工作或现居及飞书具体地址待核；慧新西街排除仅限当前支付能力'])) ,
'D5102':('杭州是所问原帖位置，不足确认本人已接受杭州目标地区。',dict(target_regions=[reg('杭州',relation='unresolved')],needs_review=['询原帖具体位置，是否本人找房及目标杭州待核'])),
'D5118':('需要的对象可能是房屋或物品，未明时不能确定需求者并出介绍计划。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='需要所指房屋或物品未明，保留住房可能线索',needs_review=['需要所指对象和本人住宅租赁需求待核'],reply_plan=plan())),
'D5149':('真实出租房源下明确核问价格，和泛真假不同，应保留高询租兴趣。',dict(interest='high',reason='在标价招租房下明确询问价格真实性，保留评论时高询租兴趣',needs_review=['实际报价、适用房型、必付费用及当前是否仍在找房待核']))
})

