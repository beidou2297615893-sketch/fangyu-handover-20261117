import json
from pathlib import Path
P=Path(__file__).parent
rows=[json.loads(x) for x in (P/'shard-1.jsonl').read_text(encoding='utf-8').splitlines()]
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
roles={'Y':('demand','super_high','active_at_comment'),'U':('unknown','uncertain','unknown'),'X':('discussion','unrelated','unknown'),'S':('supply','unrelated','unknown'),'H':('demand','high','active_at_comment'),'M':('demand','medium','active_at_comment'),'L':('demand','low','future'),'V':('demand','very_low','future'),'E':('demand','unrelated','ended'),'D':('demand','uncertain','unknown'),'B':('mixed','uncertain','unknown')}
O=[]
def add(i,code,reason,ts=(),rs=(),note='',state=None,other=(),possible=(),times=(),ctx=False):
 x=rows[i]; text=x['comment_text'];role,interest,dstate=roles[code]; e=[];regions=[]
 for pool,quote,pol in ts:
  assert pool in pools and quote in text,(i,pool,quote)
  e.append({'pool':pool,'quote':quote,'polarity':pol,'subject':'own_demand','source_kind':'comment','condition_scope':quote})
 for name,quote,rel in rs:
  assert quote in text,(i,quote)
  regions.append({'text':name,'quote':quote,'relation':rel,'group_relation':'unknown','condition_scope':quote})
 for z in (*other,*possible,*times): assert z['quote'] in text,(i,z)
 o={k:x[k] for k in ('review_key','comment_id','customer_uid','video_id')}
 o.update(role=role,interest_at_comment=interest,demand_state=state or dstate,topics=list(dict.fromkeys(z['pool'] for z in e)),topic_evidence=e,target_regions=regions,evidence=[text] if text else [],reason=reason,review_reasons=[note] if note else [],context_used=['own','body'] if ctx else ['own'],other_constraints=list(other),possible_topics=list(possible),time_mentions=list(times),human_confirmed=False,current_need_verified=False,assigned_store=None,send_authorized=False)
 O.append(o)
def save(part,expected):
 assert len(O)==expected,(len(O),expected)
 (P/part).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in O),encoding='utf-8')
