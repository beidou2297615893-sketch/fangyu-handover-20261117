"""Consolidate text deliverables and validate counts; never writes source data."""
import json,csv,hashlib,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;OUT=ROOT/'outputs/方隅双平台文本业务';K=OUT/'门店词库'
def readcsv(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
official=readcsv(K/'官网房源项目对照表.csv'); assert len(official)==15
assoc={};perstore={};allcounts={}
for row in official:
 name=row['对应词库'];paths=list((K/'已有门店').rglob(name+'.csv'));assert len(paths)==1,(name,paths)
 records=readcsv(paths[0]);words=[r for r in records if r.get('优先建议')=='长租优先候选']
 # The two newly confirmed official stores use a narrower public-source table.
 if not words and len(records)==200: words=records
 assert len(words)==200,(name,len(words),list(records[0]))
 assert len({r['搜索词'] for r in words})==200
 perstore[name]=len(words);allcounts[name]=len(records)
 for r in words:
  key=re.sub(r'\s+',' ',r['搜索词']).strip();assoc.setdefault(key,set()).add(name)
with (K/'双平台优先搜索总表.csv').open('w',encoding='utf-8-sig',newline='') as f:
 c=csv.writer(f);c.writerow(['搜索词','适用门店资料组','关联门店数','使用方式','核对状态'])
 for word,names in sorted(assoc.items(),key=lambda z:(len(z[1]),z[0])):
  c.writerow([word,'；'.join(sorted(names)),len(names),'单店具体词优先；多店共同词只搜索一次并保留全部来源关联','文本候选，未采集；客户归属另核'])
priority=['# 双平台搜索词优先顺序','',
'先古北，其他门店按资料已核范围分批覆盖。两平台共用本表的业务词，实际平台结果与进度分别记录。不要把来源门店当客户归属。',
'每店优先200条已列于各店词表；合并表按同一文本跨店去重，保留适用门店关联，避免不同员工重复搜索同一共同词。',
'第一顺序：具体门店、已核板块或道路搭配求租、租房、整租、换房等明确租住需求。',
'第二顺序：已核地区搭配户型、预算、通勤、宠物、租期等条件，用于发现具体询盘；条件只表示客户搜索假设，不是门店承诺。',
'第三顺序：宽泛市区或线路相关词，核对新增及跨店重叠后再扩大。生活兴趣另列，不作为当前需求或收入推断。',
'关键词搜索完一页或预设页数不代表整体完成；是否继续由实际新结果、已采台账、平台状况和本人授权决定。本窗口没有执行搜索。',
'筛选时先看本人明确目标地区，IP只作辅助，地区不明进入待核；跨店候选由共同台账认领，未知发送回执不重发。','']
(K/'优先搜索顺序.md').write_text('\n'.join(priority),encoding='utf8')
mother=json.loads((W/'mothers/first50.json').read_text(encoding='utf8'));assert len(mother)==50 and sum(x['user_approved'] for x in mother)==10
review=[json.loads(x) for x in (W/'holdout-200-reviewed.jsonl').read_text(encoding='utf8').splitlines()];assert len(review)==200
summary=json.loads((W/'holdout-review-summary.json').read_text(encoding='utf8'))
back=[json.loads(x) for x in (W/'backlog-57-reviewed.jsonl').read_text(encoding='utf8').splitlines()];assert len(back)==57
supp=json.loads((W/'rules/coverage-supplement.json').read_text(encoding='utf8'))
check={'version':'business-text-20261029-v1','official_page_projects':len(official),'priority_store_associations':sum(perstore.values()),'cross_store_unique_priority_queries':len(assoc),
 'per_store':perstore,'total_words_in_official_store_tables':sum(allcounts.values()),'first_mothers':50,'approved_exact_mothers':10,'new_pending_mothers':40,'holdout_reviewed':200,'backlog_reviewed':57,
 'software_installed':False,'source_databases_changed':False,'platform_requests_for_customer_collection':0,'sent':0}
(W/'delivery-validation.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf8')
receipt=['# 文本业务成果入口','',
'## 先看50条母评论','',
'打开“母评论校准/第一批50条母评论模板.md”可一次看全。共30条单需求、15条组合、5条语境变体；其中10条沿用你已看过并认可的措辞，其余40条本批新拟。之后集中反馈，不再逐条提问。',
'每条有适用条件；括号位置只能填入核实事实。认可措辞不等于房源事实成立，也不等于发送授权。','',
'## 门店搜索词','',
'官网两页房源目录与预约选项共15个项目，详情页逐个核对；旧词库13组与其对应，另补余杭、北京天璟各200条候选。',
f'当前15个官网项目均有每店200条长租优先候选，共3000条门店关联；跨店相同文本合并后为{len(assoc)}条，关联关系保留在“双平台优先搜索总表”。完整各店表共{sum(allcounts.values())}条文本候选，含待核、长尾、短租与生活兴趣，不是全数优先使用。',
'另外17条公开历史线索单列；可能更名、退出或重复，不能为凑25家直接计入。官网15项不证明公司只有15家，更不证明本次业务25家已经核全。现行公司名册和中央授权目录仍待核对；软件相关请求已交代码窗口。',
'所有新增词尚未启用和采集；搜索量、效果、实时经营及房源适配未知。','',
'## 筛选分类与检查','',
'“筛选与分类规则”提供统一业务规则、准确十池、否定/供给/结束/家庭标记、字段与证据规范、流程缺口及员工建议审核模板；共享规则由你或指定业务审核人批准。求租地区优先，IP辅助。',
'对200条冻结样本完成当前模型语义参考核对，另经独立模型审阅并保留修订；它们不是用户金标准或平台总体随机样本。额外17条补核不足场景，不与留出样本混作准确率。',
'200条中经复核：99条供给或房源推荐、14条本人求租或具体询盘线索、26条待核、1条供给与本人换租线索并存、60条讨论经历假设或无关。这些是样本模型判断，14条也未确认当前有效或可回复。',
'现有词面原型在109条非已确认本人询盘的样本上仍会命中主题，说明不能将词命中直接作为需求或自动回复资格。没有安装新分类器，没有测得新分类器准确率、自动母句覆盖率或速度收益。','',
'## 历史补核与新批次','',
'此前57条未分析或未找到分析的记录已补做文本初筛：27条房源或服务供给线索，其余30条含咨询或对象/身份待核；没有写回原分级。',
'本轮检查时第19批只有尝试及失败诊断，没有完整已登记新增回执，故未算新采集或伪造新批次。持续自动接收、服务器防重和断点由代码窗口实现；本次没有部署常驻监听。','',
'版本：2026年10月29日文本业务第一版；母评论认可记录单独保存。原有词库、客户数据库、账号会话与未决发送状态保留，今天未采集或发送。','']
(OUT/'先看这里.md').write_text('\n'.join(receipt),encoding='utf8')
test=['# 留出核对与补充场景说明','',
'200条在补规则时冻结：100条按身份及原文去重的固定散列常规样本，100条定向难例，已排除之前32测试及定向抽查的原文。并非总体随机样本，标签由当前模型提出，不是用户金标准。',
'独立审阅提出2处主要修正：转租旧房同时要换房应保留两种角色；具体问价对象未清楚时先放待核线索。另补发帖可见性讨论和非住宅转租语境说明。原标签及审阅意见都保留。',
'本次是文本规则和模型参考核对，没有安装新的执行分类器，不计算其准确率。原词面命中、主题语义、本人需求、门店适配、用户认可及发送许可分别报告。',
'200条在设施、宠物、楼层和费用等需求正例上不足，额外17条补核扩大场景覆盖；这17条不是新的留出样本，不能混合成准确率或声称独立金标准。',
'由于门店事实、当前需求及母句认可尚未全部齐备，正式母句可用覆盖率暂不可计算，不能把资料不明记成零需求、零覆盖或默认可回复。','']
(OUT/'验收与逐批记录/本轮核对结论.md').write_text('\n'.join(test),encoding='utf8')
print(json.dumps(check,ensure_ascii=False))
