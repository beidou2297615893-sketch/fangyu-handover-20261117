from manage import *
import importlib.util,datetime,collections
spec=importlib.util.spec_from_file_location('formal_adapter',b.parents[2]/'mother_adapter.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
primary={}
for i in range(3):
 for l in (b/f'reviewed-new-{i}.jsonl').read_text(encoding='utf-8').splitlines():
  r=json.loads(l);assert r['review_key'] not in primary;primary[r['review_key']]=r
inputs={r['review_key']:r for r in map(json.loads,(b/'input.jsonl').read_text(encoding='utf-8').splitlines())}
checks=[];merged=[];quote_errors=[];struct_errors=[];source_hashes=[];allkeys=[]
for part,pages in [(0,range(18,26)),(1,range(9))]:
 task=json.loads((b/f'recall-audit/part-{part}/task.json').read_text(encoding='utf-8')); expected_task=set(task['expected_review_keys'])
 for num in pages:
  pg=page(part,num);doc=json.loads(pg.read_text(encoding='utf-8'));comments=[c for g in doc['post_groups'] for c in g['comments']];ix={c['key']:(c,g) for g in doc['post_groups'] for c in g['comments']}; rs=list(map(json.loads,pg.with_suffix('.audit.jsonl').read_text(encoding='utf-8').splitlines()));keys=[r['review_key'] for r in rs];allkeys+=keys
  assert len(keys)==len(set(keys)) and set(keys)==set(ix) and set(keys)<=expected_task,(part,num)
  for a in rs:
   k=a['review_key'];c,g=ix[k];assert a['decision'] in ('keep','change') and a['reason'].strip() and isinstance(a['patch'],dict);assert (a['decision']=='keep')==(a['patch']=={});r=copy.deepcopy(primary[k]);r.update(a['patch'])
   assert r['review_key']==k and r['comment_id']==inputs[k]['comment_id'] and r['customer_uid']==inputs[k]['customer_uid']
   corpus=c['text']+(('\n'+g['post_body']) if c['same_author'] else '')
   for field in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
    for item in r[field]:
     if isinstance(item,str):q=item
     else:q=item.get('quote')
     if not isinstance(q,str) or not q or q not in (c['text'] if field=='target_regions' else corpus):quote_errors.append({'key':k,'field':field,'quote':q,'decision':a['decision']})
   for q in r['evidence']:
    if q and q not in corpus:quote_errors.append({'key':k,'field':'evidence','quote':q,'decision':a['decision']})
   assert r['reply_plan']['preferred_mother_slot'] in [None,1,2,7,13,16,19,25,28,31,34]
   r['classification_method']='ai_independent_semantic_fine_review';r['classification_stages_completed']=mod.REVIEW_METHOD_STAGES[r['classification_method']];r.pop('classification_review_source',None);merged.append(r)
  checks.append({'part':part,'page':num,'input':len(ix),'output':len(rs),'id_set_equal':set(keys)==set(ix),'duplicates':len(keys)-len(set(keys)),'change':sum(r['decision']=='change' for r in rs),'input_sha256':hashlib.sha256(pg.read_bytes()).hexdigest(),'audit_sha256':hashlib.sha256(pg.with_suffix('.audit.jsonl').read_bytes()).hexdigest()})
assert len(allkeys)==len(set(allkeys))==2040
source=w/'preflight-source.jsonl';raw=''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in merged).encode('utf-8');source.write_bytes(raw);digest=hashlib.sha256(raw).hexdigest();cache={}
for r in merged:
 r=copy.deepcopy(r);r['classification_review_source']={'path':str(source.relative_to(b)),'sha256':digest}
 try:mod.validate_new_review(r,b,cache)
 except Exception as e:struct_errors.append(str(e))
for i in range(3):source_hashes.append({'file':f'reviewed-new-{i}.jsonl','sha256':hashlib.sha256((b/f'reviewed-new-{i}.jsonl').read_bytes()).hexdigest()})
expected_hashes=json.loads((b/'recall-audit/part-0/task.json').read_text(encoding='utf-8'))['primary_sources'];assert all(s['sha256']==next(x['sha256'] for x in expected_hashes if x['path']==s['file']) for s in source_hashes)
validation={'worker':'b','scope':{'part0_pages':'18-25','part1_pages':'00-08'},'pages':checks,'records':len(merged),'changes':sum(x['change'] for x in checks),'keeps':len(merged)-sum(x['change'] for x in checks),'all_id_sets_equal':all(x['id_set_equal'] for x in checks),'cross_page_duplicates':len(allkeys)-len(set(allkeys)),'quote_errors':quote_errors,'formal_adapter_validation_errors':struct_errors,'formal_adapter_validated':len(merged)-len(struct_errors),'preflight_source':str(source.relative_to(b)),'preflight_only_compiler_metadata':True,'primary_hashes_unchanged':True,'primary_sources':source_hashes,'usage':'unknown; current agent tool exposes no verified token/credit accounting','semantic_review_is_not_human_gold':True,'platform_or_send_actions':False,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(w/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in validation.items() if k not in ['pages','primary_sources']},ensure_ascii=False))
