import json,hashlib,collections
from pathlib import Path
p=Path(__file__).parent;source=p/'shard-2.jsonl';rows=[json.loads(s) for s in source.read_text(encoding='utf-8-sig').splitlines()]
assert not (p/'reviewed-2.jsonl').exists(), '该分片已有结果，禁止覆盖'
def ids(s):return {int(x) for x in s.split()}
high=ids('15 18 30 54 72 75 159 171 201 204 207 210 228 255 258 264 270 273')
medium=ids('156')
identified_uncertain=ids('196 247')
ended=ids('6')
supply=ids('9 51 99 102 111 117 123 126 132 138 165 168 183 186 189 192 291')
discussion=ids('3 42 93 96 174 198 225 231 234 240 243 246 276 279 282 288')
groups=[high,medium,identified_uncertain,ended,supply,discussion]
for i,a in enumerate(groups):
 for b in groups[i+1:]:assert not a&b,a&b
notes={12:'仅问某区有没有，视频展示他人已住的房屋，询问对象和本人当前需求未明。',21:'问某地附近有没有，但视频为他人已租体验，未说明具体租房对象。',24:'“单间好多”是数量评价，未说明本人供需角色及当前需求。',27:'只问某地附近有吗，帖子为已租体验，具体所指未明。',33:'只有地名和独卫条件，未明是提供房源、推荐或本人寻租。',36:'列出地名、价格和条件，未说明本人在提供、寻找还是介绍房源。',39:'只说“有的”，缺少所指对象及供需关系。',45:'描述偏远地区和房间，关键语句存在歧义，未明是否提供房源。',48:'称西湖一带有老小区，可能是建议或提供房源，身份及对象未明确。',57:'只有“有？”，没有具体对象。',60:'询问区域是否有千元左右的，视频是价格攻略，不能确认本人当下租房还是泛问。',63:'询问该地区租房月价，属于市场价格问题，未确认本人当前求租。',66:'仅@他人及表情，未说明本人租房目的。',69:'只说地名，可能是给他人建议或本人需求，不能推断。',78:'询问某价格能否租到，可能是质疑或咨询行情，没有明确本人当前求租。',81:'仅表情，没有明确需求。',84:'仅地名，无法判断工作、现住或目标地区。',87:'仅地名，无法判断地点用途和本人需求。',90:'仅地名，无法判断地点用途和本人需求。',105:'询问他人是否考虑某地区，未明确本人是否提供房源。',108:'询问是否考虑浦东，未明确本人是否提供房源或只是建议。',114:'只说“房东直租”，无法确认本人身份或是否有实际提供房源。',120:'仅表情，不能判定本人供需需求。',129:'问他人预算和区域，可能提供服务或询问信息，未明确身份。',135:'询问是否需要合租且限男生，但未明自己已有房源还是寻找合租。',141:'只有价位和房型，未明提供房源、报价推荐或本人需求。',144:'仅询问13号沿线是否有，帖为价格攻略而非明确在租房源；本人需求待核。',147:'询问某地附近有没有，帖为价格攻略，所指具体内容与本人需求待核。',150:'“蹲个北京的”可能在等北京版攻略，并不自动构成本人求租。',153:'质疑金额是否少写零，不能当成本人租房询盘。',162:'仅@他人，没有本人租房需求或可确认对象。',177:'只写小区和两居，未明本人是提供、推荐还是寻租。',180:'询问别人在哪里住，未明本人供需身份及目的。',195:'讨论区域房租并说“都能接受”，未说明本人是否正在找房、还是分享既住或看房经历。',213:'只问某地有没有，帖子是已入住体验，具体对象及本人求租不明确。',216:'只问某地有没有，帖子是已入住体验，具体对象及本人求租不明确。',219:'问房子具体位置，视频是已租体验，不代表该房仍在出租或本人正找房。',222:'询问某区一室行情价格，帖子为已租体验，未明确本人当前求租。',237:'在租房攻略下只提小区并询问，具体对象、本人角色不明。',249:'问怎么租并提到实习收入，收入不是预算，是否正在找房需核对。',252:'仅@他人，无法判断本人租房需求。',261:'询问面积和地点，视频是入住体验，不代表房源当前可租或本人已确认求租。',267:'表达“想住”可能只是喜爱和假设，未明确实际租赁行动。',285:'询问还有没有房，但帖子在讨论中介，缺少直接询问对象或可租房源。'}
T={};R={};TM={};O={}
def topic(n,pool,q,pol='ask',subject='own_demand',scope='本人原话中的询问或条件'):
 T.setdefault(n,[]).append(dict(pool=pool,quote=q,polarity=pol,subject=subject,source='comment',condition_scope=scope))
def region(n,q,relation='desired',scope='本人提出的租住目标或范围',group='unknown'):
 R.setdefault(n,[]).append(dict(text=q,quote=q,relation=relation,source='comment',group_relation=group,condition_scope=scope))
def moment(n,q,role,subject='own_demand'):
 TM.setdefault(n,[]).append(dict(quote=q,time_role=role,subject=subject,source='comment',normalized=None,verification='只保留原词及发表时间，不用今天推定日期或当前状态'))

topic(15,'位置通勤','双流区','require');region(15,'双流区');topic(15,'户型面积与居住方式','套一','require');topic(15,'房源状态','有吗','ask')
topic(18,'入住与租期','住一个月','ask',scope='询问是否可住一个月；未确认该房目前可租');moment(18,'去玩一个月','other')
topic(30,'位置通勤','南湖跟怡心湖片区','require');region(30,'南湖跟怡心湖片区','desired','本人提出的目标范围，两地点关系未明确');topic(30,'户型面积与居住方式','来一套','require',scope='表达希望租一套，不能将视频中房型当本人具体要求')
region(54,'南湖未来科学园','work','本人明确上班地点，不作为希望租住地区');topic(54,'位置通勤','南湖未来科学园上班','require');topic(54,'价格预算','千元内','require',scope='本人预算上限，币种和计费周期需核实')
region(72,'萧山区南站','desired','本人询问房源的地区');topic(72,'房源状态','有便宜的房子 吗','ask');topic(72,'价格预算','便宜的','prefer',scope='希望便宜；所述1800是他人报价不是本人预算')
region(75,'大华滨江总部','work','本人所述上班地点，不自动作为居住目标');topic(75,'户型面积与居住方式','想租两室一厅','require');topic(75,'价格预算','需要多少预算','ask');topic(75,'位置通勤','大华滨江总部上班','require')
region(159,'普陀','desired','本人明确询问房源的地区');topic(159,'价格预算','1500','ask',scope='询问此价格是否有房，不等于明确硬性预算');topic(159,'房源状态','有1500的吗','ask')
topic(171,'看房联系','可以看房吗','ask',scope='泛看房询问，不是具体预约')
region(201,'北京','desired','本人询问未来实习租住的城市');topic(201,'价格预算','1000元','ask',scope='询问该价格能租到何种房子，不自动记为硬预算');topic(201,'户型面积与居住方式','不想合租','reject');moment(201,'明年实习','other')
region(204,'海淀区亚运村五道口附近','desired','本人给出的租住范围');topic(204,'位置通勤','海淀区亚运村五道口附近','require');topic(204,'价格预算','2000～2500以内','require');topic(204,'户型面积与居住方式','整租单人间','require')
region(207,'西二旗','unresolved','本人通勤终点，不明确是否工作地点，也不是已确认目标居住地');topic(207,'位置通勤','通勤西二旗','require');topic(207,'位置通勤','1h通勤','require');topic(207,'价格预算','3k预算','require')
topic(210,'位置通勤','这个位置附近','require',scope='位置来自视频画面指代；未读取画面，具体地区未知');topic(210,'户型面积与居住方式','一室一厅','require');topic(210,'价格预算','预算三千左右','require')
region(228,'七八九堡附近','preferred','本人明确“最好”处，原词保留，具体范围需核');topic(228,'位置通勤','最好七八九堡附近','prefer');topic(228,'户型面积与居住方式','一人住的','require')
region(255,'闽侯高新区','desired');region(255,'璀璨江山或者中海寰宇','preferred','本人偏好的两个小区，未说明一定只能这两处','OR');topic(255,'位置通勤','闽侯高新区','require');topic(255,'户型面积与居住方式','两房一厅或者三房一厅','require',scope='两种房型二选一');topic(255,'费用合同','押一付一','require');topic(255,'费用合同','民水民电','require');topic(255,'价格预算','预算2.6k内','require');topic(255,'位置通勤','最好是璀璨江山或者中海寰宇','prefer');O[255]=[dict(quote='城中村',subject='unresolved',polarity='unknown',condition_scope='原文将“城中村”放在小区偏好括号中，其与小区范围关系待核')]
topic(258,'位置通勤','哪里','ask');topic(258,'房源状态','还有吗','ask');topic(258,'入住与租期','想租','require',scope='本人明确租住意愿；未说具体租期')
region(264,'台江鼓楼仓山','accepted','本人说都可以；具体城市不从他人视频或IP代入','OR');topic(264,'位置通勤','台江鼓楼仓山都可以','accept');topic(264,'价格预算','价格在1300左右','require');topic(264,'户型面积与居住方式','最好是两室一厅','prefer');topic(264,'户型面积与居住方式','一室一厅也可以','accept');topic(264,'看房联系','能联系你嘛','ask',scope='请求联系，并非约看');moment(264,'月底去福州','other')
region(270,'鼓楼区','desired');topic(270,'位置通勤','鼓楼区','require');topic(270,'价格预算','预算800','require');topic(270,'户型面积与居住方式','合租','accept')
topic(273,'价格预算','预算4000','require');topic(273,'看房联系','想找个中介问一下','require',scope='想咨询中介，不等于约看')
for n,q in [(12,'天府新区'),(21,'天府五街附近'),(27,'海昌路附近'),(33,'城西银泰'),(36,'九堡'),(45,'大江东'),(48,'西湖'),(60,'杭行路'),(63,'余杭区勾庄附近'),(69,'良渚'),(84,'人民广场'),(87,'余杭区'),(90,'临平'),(105,'青浦朱家角'),(108,'浦东'),(129,'哪个区'),(135,'徐家汇近4/7/12号线东安路地铁站'),(141,'九亭'),(144,'13号线'),(147,'龙华附近'),(150,'北京'),(177,'丰台区彩虹家园北区'),(195,'沙河'),(213,'小南街'),(216,'警官学院附近'),(222,'武侯'),(237,'梅家巧新苑')]:region(n,q,'unresolved','地点的对象或本人需求未明确，不能推断目标门店')
for n,q in [(99,'闵行区浦江镇联航路地铁站附近'),(102,'闵行梅陇15号线景西路地铁站'),(111,'浦东搏山路'),(117,'闵行区'),(123,'浦江镇'),(126,'秀沿路'),(132,'青浦华新'),(138,'彭浦附近'),(165,'虹桥'),(168,'上海宝山区金地草莓保租房'),(183,'南二环外14号线地铁景泰站附近'),(186,'大兴机场附近'),(192,'西红门附近'),(291,'华漕华新中心村')]:region(n,q,'offered','提供或推荐房源的地区，不当成本人新求租地区')
region(246,'仓溢绿苑','current_home','本人当前所租地点，不自动当成新目标地区');region(246,'金龙中心','work','本人明确上班地点')
for n,q in [(144,'13号线'),(147,'龙华附近'),(150,'北京'),(213,'小南街'),(216,'警官学院附近'),(219,'这个房子在哪个位置'),(222,'武侯'),(237,'梅家巧新苑'),(261,'在什么地方')]:topic(n,'位置通勤',q,'ask','unresolved',scope='对象及本人租房需求待核')
topic(222,'价格预算','一般多少钱','ask','unresolved',scope='咨询行情，不能当本人预算');topic(222,'户型面积与居住方式','套一','ask','unresolved')
topic(261,'户型面积与居住方式','多少平','ask','unresolved');topic(285,'房源状态','还有房吗','ask','unresolved')
topic(78,'价格预算','一千四五','ask','unresolved',scope='询问价格能否租到，不作为本人预算');topic(78,'户型面积与居住方式','整租一室一厅','ask','unresolved')
moment(168,'10.25-11.30左右','lease_duration','supply');moment(201,'明年实习','other');moment(264,'月底去福州','other')

out=[]
for d in rows:
 n=int(d['review_key'][1:]);t=d['comment_text'];gaps=[]
 if n in high:role='demand';interest='high';state='active_at_comment';why='本人明确提出租房条件或对具体租赁行为询问，只反映评论时意向。'
 elif n in medium:role='demand';interest='medium';state='active_at_comment';why='本人表达想租房意愿，具体条件与后续行动未说明。'
 elif n in identified_uncertain:role='demand';interest='uncertain';state='unknown';why='本人称找到或拿下房源，但是否已签约入住及是否还有新需求未知。';gaps.append('不能把找到或拿下自动当成签约入住与需求完全结束。')
 elif n in ended:role='demand';interest='unrelated';state='ended';why='本人明确说昨天已租，未表达新的求租需求。'
 elif n in supply:role='supply';interest='unrelated';state='unknown';why='本人提供、推荐或转租房源或提供租房服务，没有明确本人另找房。'
 elif n in discussion:role='discussion';interest='unrelated';state='unknown';why='本人分享观点、建议、历史或当前体验，没有明确新的租房需求。'
 else:
  assert n in notes,n
  role='unknown';interest='uncertain';state='unknown';why=notes[n];gaps.append(why)
 if n in high|medium:gaps.append('评论时兴趣不等于当前仍在找房；需核本人后续进展与实际可承接事实。')
 if n in (15,18,30,156):gaps.append('视频是他人已入住体验，不证明视频中房源仍可租，也不继承其价格或设施。')
 if n==171:gaps.append('只询问是否看房，未提出具体约看时间或已确认预约。')
 if n==201:gaps.append('提到明年实习，但本人已询问租房方案，不能仅凭未来时间降为尚不推进；具体年份和起租时间待核。')
 if n==210:gaps.append('“这个位置”需要视频画面才能确定，当前未读取，不能用帖子或IP填地点。')
 if n==255:gaps.append('房型为两种备选，小区为偏好；“城中村”与括号内两小区的关系需核。')
 if n==258:gaps.append('视频为他人租住体验，原房源是否仍可租或愿意转租未经核实。')
 if n==264:gaps.append('月底去福州为行程，不等同入住日期；1300左右为目标价位，计费周期待核。')
 if n==270:gaps.append('预算周期未说明；鼓楼区可能同名，具体城市与可承接门店须核实。')
 if n==126:gaps.append('本人转租旧房，是否也在另找新房未说明。')
 if n==168:gaps.append('提供本人短租安排，不把提供期限或地区当新求租需求。')
 if n==291:gaps.append('评论者自称有意可入住，未核其房东身份及实际出租权限。')
 if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read'):gaps.append(f"有{d['deeper_reply_count_visible']}条可见深层回复未读，后续结果未知。")
 if d.get('source_version_conflict'):gaps.append('来源版本存在冲突，需复核原始数据。')
 te=T.get(n,[]);regs=R.get(n,[]);times=TM.get(n,[]);other=O.get(n,[])
 for e in te+regs+times+other:assert e['quote'] in t,(n,e['quote'])
 for e in times:e['anchor_source']='comment_published_at_unix' if d.get('published_at_unix') else 'unknown';e['anchor_time']=d.get('published_at_unix')
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],video_id=d['video_id'],role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(x['pool'] for x in te)),topic_evidence=te,target_regions=regs,time_mentions=times,other_constraints=other,reason=why,evidence=[t],review_reasons=gaps,context_used=['comment','post_body'],media_context='未读取视频画面；不把视频文字视为实物已核',reply_context='有可见深层回复但未读' if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read') else '未读取深层回复',current_need_verified=False,assigned_store=None,send_authorized=False))
assert len(rows)==len(out)==97
assert len({r['review_key'] for r in rows})==97
assert {(r['review_key'],r['comment_id'],r['customer_uid'],r['video_id']) for r in rows}=={(r['review_key'],r['comment_id'],r['customer_uid'],r['video_id']) for r in out}
poolset={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for d,r in zip(rows,out):
 assert all(q and q in d['comment_text'] for q in r['evidence'])
 assert all(x['quote'] in d['comment_text'] for x in r['topic_evidence']+r['target_regions']+r['time_mentions']+r['other_constraints'])
 assert set(r['topics'])<=poolset and set(r['topics'])=={x['pool'] for x in r['topic_evidence']}
 assert not(r['role']=='unknown' and r['interest_at_comment']=='unrelated')
 assert not r['current_need_verified'] and r['assigned_store'] is None and not r['send_authorized']
(p/'reviewed-2.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
v={'input_count':97,'output_count':97,'unique_review_keys':len({r['review_key'] for r in out}),'id_quadruples_equal':True,'evidence_and_quotes_verbatim':True,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'role_counts':dict(collections.Counter(r['role'] for r in out)),'interest_counts':dict(collections.Counter(r['interest_at_comment'] for r in out)),'topic_counts_including_unresolved':dict(collections.Counter(y for r in out for y in r['topics'])),'topic_subject_counts':dict(collections.Counter(y['subject'] for r in out for y in r['topic_evidence'])),'needs_review_count':sum(bool(r['review_reasons']) for r in out),'deeper_replies_unread_count':sum(bool(r.get('deeper_reply_count_visible')) and not r.get('deeper_replies_read') for r in rows),'video_frames_read':False,'human_confirmed':False,'current_need_verified':False,'send_authorized':False,'model_reference_not_gold':True}
(p/'validation-2.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,ensure_ascii=False,indent=2))
