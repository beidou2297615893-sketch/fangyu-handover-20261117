import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent;source=p/'shard-0.jsonl';rows=[json.loads(s) for s in source.read_text(encoding='utf-8-sig').splitlines()]
def ids(s):return {int(x) for x in s.split()}
high=ids('19 31 49 52 55 91 202 211 214 253 262 265 283')
medium=ids('64 208 241 244 268')
identified_uncertain=ids('196 247')
supply=ids('37 40 43 46 103 112 124 130 133 136 139 163 166 169 184 187 190')
discussion=ids('1 7 97 142 154 157 193 199 226 229 232 238 259 274 277 280 289')
sets=[high,medium,identified_uncertain,supply,discussion]
for i,a in enumerate(sets):
 for b in sets[i+1:]:assert not a&b,a&b
unknown_notes={4:'“公寓吗”没有指明是否询问自己租住的对象，帖子是他人求租，不是明确出租房源。',10:'询问合租者并写出性别年龄，但未说明本人已拥有房间还是正在找房合租。',13:'仅问双流是否有，视频为已住体验，未明询问具体房源或地区信息。',16:'“1300我马上订”是对已住体验价格的条件假设，不代表存在可预订房源或已经预约。',22:'只问能否私信，视频是他人已租体验，联系目的不明。',25:'只问是否月租，视频是他人已租体验，未明确本人需求与具体可租对象。',28:'仅问成华有没有，视频为已住体验，未明具体询问对象。',34:'只说找我，提供房源、帮助或其他含义不明。',58:'说两个小区“也可以”，可能是建议他人或本人可接受，缺少直接关系。',61:'询问某地区哪里较好，但帖子为价格攻略，是否本人正在找房未明。',67:'问某区域是否有一千多的，房型及本人当前找房状态未明确。',70:'孤立数字，币种、用途、价格或其他对象不明。',73:'询问两地区有什么，可能是攻略信息或实际找房，未明确本人需求。',76:'询问价格与户型的真实性，帖子是攻略，未明确本人当前求租。',79:'问攻略为何没有某区，不等于本人要在该区租房。',82:'问车站附近有吗，攻略并非具体房源，是否本人求租及所指对象待核。',85:'问下沙有房吗，视频是一般攻略；是否本人当前找房及房源对象需核实。',88:'仅说租房，可能表达兴趣或回复内容，未说明本人是否在找及具体需求。',100:'说找合租并描述房间，未说明本人已有房间招室友还是正在找合租房。',106:'询问对方哪个区，未明是提供房源、代找或本人求租。',109:'仅说地铁站附近，未说明提供房源还是寻租目标。',115:'问浦东能否接受，未明是否本人提供房源或仅提出建议。',118:'仅地名，无法判断供需角色。',121:'只说浦东有，未明是提供房源还是转述他人信息。',127:'问普陀有没有需要的，提供的具体内容及身份不明。',145:'攻略中询问某线路推荐，未明确本人当前找房及具体对象。',148:'问某线路内容，未明确本人当前找房及所指事项。',151:'“蹲蹲13号线”可能是在等攻略或找房，未明本人需求。',160:'“三房应该可以吧”是房型判断，未说明对象和供需角色。',172:'提及某地价格和租期并请求回应，未明是自荐房源还是询租。',175:'找室友但未说本人已有房源还是需要另找合租住房。',178:'提及附近有空床，未明确是本人提供还是转述信息。',181:'询问对方是否退租，帖子没有明确具体出租房源，不能推断本人求租。',205:'只问某地点附近去哪里，是否本人找房及该地是工作地或目标地未明。',217:'质疑房源真实性，并非已核本人求租或房源真实。',220:'问某地“有没”，视频是已租体验，具体对象及本人需求不明。',223:'仅问某地“有吗”，视频为已租体验，具体对象与本人需求不明。',235:'“好早房子”表述可能是输入错误，不能断定其含义或本人当前求租。',250:'问某地有没有，视频为租房攻略，具体对象及本人意向不明。',256:'询问视频中房屋位置；视频是入住体验，房源是否可租和本人需求未明。',271:'仅问在哪里，视频为入住体验，不能据此确认本人当前租房。',286:'仅提地点，无法判断是工作、现住、目标地区或向他人建议。'}
unknown_notes[94]='问价格，视频是他人已租体验，不能仅凭提问认定该房仍可租或本人当前求租。'
T={};R={};TM={};O={}
def topic(n,pool,q,pol='ask',subject='own_demand',scope='本人原话中的询问或条件'):
 T.setdefault(n,[]).append(dict(pool=pool,quote=q,polarity=pol,subject=subject,source='comment',condition_scope=scope))
def region(n,q,relation='desired',scope='本人提出的租住目标或范围',group='unknown'):
 R.setdefault(n,[]).append(dict(text=q,quote=q,relation=relation,source='comment',group_relation=group,condition_scope=scope))
def moment(n,q,role,subject='own_demand'):
 TM.setdefault(n,[]).append(dict(quote=q,time_role=role,subject=subject,source='comment',normalized=None,verification='保留原词和评论时间；未据今天推定日期或当前状态'))

topic(19,'房源状态','有房源吗');topic(19,'位置通勤','天府生命科技园','require');region(19,'天府生命科技园')
topic(31,'户型面积与居住方式','套二','require')
for q in ['2室1厅','整租']:topic(49,'户型面积与居住方式',q,'require')
for q in ['卧室要有采光','有独卫厨房']:topic(49,'房内设施',q,'require')
topic(49,'费用合同','民水民电','require');topic(49,'位置通勤','离地铁近','require');topic(49,'位置通勤','三号线这边','require');topic(49,'价格预算','预算2200上下','require');region(49,'三号线这边')
topic(52,'入住与租期','租一年','require');topic(52,'价格预算','价格1200以下','require');moment(52,'租一年','lease_duration');O[52]=[dict(quote='有车位的',subject='own_demand',polarity='require',condition_scope='本人希望有车位；不塞入房内设施池')]
topic(55,'位置通勤','杭师大附近','require');topic(55,'户型面积与居住方式','一个人住','require');topic(55,'房源状态','有没有','ask');region(55,'杭师大附近')
topic(64,'位置通勤','上班可以租哪里的房子','ask',scope='询问通勤相关区域；未明确可接受居住范围');region(64,'余杭区向往街368号正淘易谷创新园','work','本人明确上班地点，不转为本人租住目标')
topic(91,'价格预算','这套多少','ask');topic(91,'入住与租期','急租','require',scope='明确急租需求；并非已预约')
topic(94,'价格预算','多少钱','ask','unresolved',scope='仅询问已住体验的价格，是否本人当前求租及该房可租均未明')
topic(202,'位置通勤','电动车通勤半小时','require');topic(202,'价格预算','预算2200左右','require');region(202,'海淀天地邻枫创新产业园','unresolved','本人通勤参照地点，未明确是工作地或居住目标')
topic(208,'位置通勤','在哪租房比较合适','ask');region(208,'海淀区清河街道小营西路','unresolved','租房选址的参照位置，工作地或目标居住地未明确')
topic(211,'位置通勤','北苑路北上班','require',scope='本人工作地点，不直接代表希望租住该地点');region(211,'北苑路北','work','本人明确的上班地点');topic(211,'户型面积与居住方式','主卧','require');topic(211,'房内设施','独卫','require');topic(211,'价格预算','预算2500以内','require')
topic(214,'户型面积与居住方式','套一','ask');topic(214,'房源状态','有套一吗','ask');region(214,'动物园往外','desired','本人提出的范围，具体城市和边界需核对')
topic(241,'位置通勤','租哪里','ask');region(241,'绿城三维·未来PARK','unresolved','选址参照地点，是否工作地、现住地或目标地点未明')
topic(244,'位置通勤','这三站推荐住哪','compare');region(244,'潮王路 杭氧 打铁关','unresolved','本人请求比较三站，不自动推定均为已接受目标','OR')
topic(253,'位置通勤','泰禾近地铁口','require');topic(253,'价格预算','这种类型价格','ask',scope='询问类似价格，具体金额只见他人视频，不作为本人预算');topic(253,'入住与租期','下个月租到','require');region(253,'泰禾近地铁口');moment(253,'下个月租到','move_in')
region(262,'晋安鼓楼','desired','本人询问的可租房地区','OR');topic(262,'位置通勤','晋安鼓楼','require');topic(262,'价格预算','1600左右','require',scope='本人寻找新房的目标价；周期需核');topic(262,'房内设施','带厨房','require');topic(262,'户型面积与居住方式','独门独户','require');moment(262,'十月份就要到期了','lease_end','current_home');O[262]=[dict(quote='一个月2500有点支撑不住',subject='current_home',polarity='fact',condition_scope='当前房租及负担，不是新房预算')]
region(265,'省立医院附近');topic(265,'位置通勤','省立医院附近','require');topic(265,'房源状态','有没有','ask')
topic(283,'价格预算','预算2000左右','require');topic(283,'房源状态','哪有合适的房子','ask')
for n,q in [(10,'昌平沙河'),(13,'双流'),(28,'成华'),(58,'西溪花园，蒋村花园'),(61,'西湖文化广场附近'),(67,'上城区钱塘江江河汇'),(73,'朝阳和新街'),(79,'拱墅区'),(82,'六堡地铁站附近'),(85,'下沙'),(100,'宝山顾村'),(109,'远东地铁站附近'),(115,'浦东'),(118,'颛桥附近'),(121,'浦东'),(127,'普陀'),(145,'十二号线'),(148,'十号线'),(151,'13号线'),(175,'鸟巢附近'),(178,'五道口附近'),(205,'生命科学院附近'),(220,'金牛区，植物园'),(223,'簇桥'),(235,'梅家桥星苑'),(250,'拱墅'),(286,'浦东金桥')]:region(n,q,'unresolved','本人提及地区的角色或用途未明确，不能直接归属门店')
for n,q in [(37,'萧山银泰这边'),(103,'奉贤区'),(112,'嘉怡路'),(124,'老闵行'),(130,'江桥 14号线乐秀路站'),(133,'宝山顾村、美兰湖、罗南新村、罗泾'),(136,'海霞路493弄'),(163,'闵行浦江镇'),(166,'芦恒地铁站附近'),(169,'一品漫城别墅区'),(187,'海淀'),(190,'百子湾家园')]:region(n,q,'offered','提供、转租或服务覆盖区域，不作为本人新求租目标')
region(199,'成寿寺附近','current_home','本人所述现租住址，非新求租目标');region(199,'南站附近','work','对象的上班地点，非评论者本人已确认工作地或租住目标');R[199][-1]['subject']='other_person'
for n,q,pool in [(4,'公寓吗','户型面积与居住方式'),(10,'找合租','户型面积与居住方式'),(10,'男的00后','户型面积与居住方式'),(25,'月租嘛','价格预算'),(49,'卧室要有采光','房内设施'),(58,'西溪花园，蒋村花园也可以','位置通勤'),(61,'哪里比较好','位置通勤'),(67,'一千多的','价格预算'),(73,'有什么样的','户型面积与居住方式'),(76,'1400一室一厅','价格预算'),(82,'六堡地铁站附近','位置通勤'),(85,'有房吗','房源状态'),(100,'找合租','户型面积与居住方式'),(145,'十二号线','位置通勤'),(151,'13号线','位置通勤'),(175,'找室友','户型面积与居住方式'),(181,'要退租了','入住与租期'),(217,'确定实际房源吗','房源状态'),(235,'一个人住','户型面积与居住方式'),(256,'这房位置','位置通勤'),(271,'在哪','位置通勤')]:
 if n not in high and n not in medium:topic(n,pool,q,'ask' if n not in (10,58,100,151,175,235) else 'unknown','unresolved',scope='本人租房身份、所指对象或该条件归属未确认')
moment(196,'昨天刚刚','other','unresolved')
out=[]
for d in rows:
 n=int(d['review_key'][1:]);t=d['comment_text'];gaps=[]
 if n in high:role='demand';interest='high';state='active_at_comment';reason='本人明确询找或提出租房条件，只能反映评论时的兴趣。'
 elif n in medium:role='demand';interest='medium';state='active_at_comment';reason='本人表达找房、比较区域或租房意愿，具体交易与后续进展未明。'
 elif n in identified_uncertain:role='demand';interest='uncertain';state='unknown';reason='本人表示找到或拿下房源，但是否已经签约入住、是否仍有新需求未明。';gaps.append('找到或拿下不等于已确认完成签约入住，不能擅自标已结束。')
 elif n in supply:role='supply';interest='unrelated';state='unknown';reason='提供、转租或推广房源和服务，没有明确本人另找住房的需求。'
 elif n in discussion:role='discussion';interest='unrelated';state='unknown';reason='评论为建议、经历、评价、问候或一般讨论，未明确新的本人求租。'
 else:
  assert n in unknown_notes,n
  role='unknown';interest='uncertain';state='unknown';reason=unknown_notes[n];gaps.append(reason)
 if n in high|medium:gaps.append('评论时租房意向不等于当前仍在找；实际房源、地区和承接条件未确认。')
 if n==49:gaps.append('“2200上下”是目标价位，计费周期和可浮动范围未说明；是否允许宠物未知。')
 if n==52:gaps.append('车位作为独立要求保留，未核车位费用及预算周期。')
 if n==91:gaps.append('该视频是他人已入住体验，未证明原房源当前可租。')
 if n==202:gaps.append('产业园是通勤参照点，但是否本人工作地尚未明确；不把它填为目标居住地。')
 if n==211:gaps.append('上班地点与目标居住区域分开；预算上限及房屋设施均需实际核实。')
 if n==253:gaps.append('“下个月租到”只保留相对时间，未凭今天推定具体月份；视频为体验，房源现况未知。')
 if n==262:gaps.append('1600左右是找新房价位；2500是当前租金，不混作新预算。十月份年份及当前租住状态需核实。')
 if n==163:gaps.append('因在上海找不到工作想回家而转租，是否还要另找住房未说明。')
 if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read'):gaps.append(f"有{d['deeper_reply_count_visible']}条可见深层回复未读取，后续结果未知。")
 if d.get('source_version_conflict'):gaps.append('来源版本存在冲突，需核对原始数据。')
 for x in T.get(n,[])+R.get(n,[])+TM.get(n,[])+O.get(n,[]):assert x['quote'] in t,(n,x['quote'])
 times=TM.get(n,[])
 for x in times:x['anchor_source']='comment_published_at_unix';x['anchor_time']=d.get('published_at_unix')
 ev=T.get(n,[]);out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],video_id=d['video_id'],role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(x['pool'] for x in ev)),topic_evidence=ev,target_regions=R.get(n,[]),time_mentions=times,other_constraints=O.get(n,[]),reason=reason,evidence=[t],review_reasons=gaps,context_used=['comment','post_body'],media_context='未读取视频画面；不把帖子文字视作实物已核',reply_context='有可见深层回复但未读取' if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read') else '未读取深层回复',current_need_verified=False,assigned_store=None,send_authorized=False))
assert len(rows)==len(out)==97
assert len({x['review_key'] for x in rows})==97
assert {(x['review_key'],x['comment_id'],x['customer_uid'],x['video_id']) for x in rows}=={(x['review_key'],x['comment_id'],x['customer_uid'],x['video_id']) for x in out}
poolset={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for x,d in zip(out,rows):
 assert all(e and e in d['comment_text'] for e in x['evidence'])
 assert all(z['quote'] in d['comment_text'] for z in x['topic_evidence']+x['target_regions']+x['time_mentions']+x['other_constraints'])
 assert set(x['topics'])<=poolset and set(x['topics'])=={z['pool'] for z in x['topic_evidence']}
 assert not(x['role']=='unknown' and x['interest_at_comment']=='unrelated')
 assert x['current_need_verified'] is False and x['assigned_store'] is None and x['send_authorized'] is False
(p/'reviewed-0.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
v={'input_count':97,'output_count':97,'unique_review_keys':len({x['review_key'] for x in out}),'id_quadruples_equal':True,'evidence_and_quotes_verbatim':True,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'role_counts':dict(collections.Counter(x['role'] for x in out)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in out)),'topic_counts_including_unresolved':dict(collections.Counter(y for x in out for y in x['topics'])),'topic_subject_counts':dict(collections.Counter(y['subject'] for x in out for y in x['topic_evidence'])),'needs_review_count':sum(bool(x['review_reasons']) for x in out),'deeper_replies_unread_count':sum(bool(x.get('deeper_reply_count_visible')) and not x.get('deeper_replies_read') for x in rows),'video_frames_read':False,'human_confirmed':False,'current_need_verified':False,'send_authorized':False,'model_reference_not_gold':True}
(p/'validation-0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,ensure_ascii=False,indent=2))
