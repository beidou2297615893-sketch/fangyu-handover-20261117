import json,pathlib
from decisions import BASE,PART,WORK
# Explicit follow-through for already-read changed rows: sync facts with corrected semantic scope.
fixes={3:{'D0917':{'preferred_mother_slot':34,'generic_intro_suitable':True,'tone':'normal','missing_facts':['同一有效房源符合1200预算和单人单间要求，确认适用地区及全部必付费用','不挑环境的具体接受范围待核，不将其当所有房内设施无需','真实住户、本人介绍资格及同店优惠时效和条件'],'caution':['只是不挑环境，不能推定接受不安全房源或缺少必要设施。'],'contact_policy':'allow'}},8:{'D2393':{'preferred_mother_slot':1,'generic_intro_suitable':True,'tone':'normal','missing_facts':['真实住户、本人介绍资格及同店优惠活动时效和适用条件','指定原帖6000价位房源与本人预算的区别、本人可接受全部费用及同店有效房源'],'caution':['6000不是本人明确预算上限；通用接话不表示方隅有同价同条件房源。'],'contact_policy':'allow'}}}
for page,changes in fixes.items():
 p=PART/f'page-{page:02}.audit.jsonl';rows=[json.loads(l) for l in p.read_text(encoding='utf8').splitlines()]
 for row in rows:
  if row['review_key'] in changes:
   assert row['decision']=='change';row['patch']['reply_plan']=changes[row['review_key']]
 p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf8')
print('已同步两条已读修订的母句事实缺口')
