import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import unittest, tempfile, threading, json, urllib.request, urllib.error, http.cookiejar
from app import AppServer

class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.server=AppServer(('127.0.0.1',0),self.tmp.name)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.url='http://127.0.0.1:'+str(self.server.server_port)
        self.client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def tearDown(self): self.server.shutdown(); self.server.server_close(); self.tmp.cleanup()
    def call(self,action,data=None,headers=None):
        req=urllib.request.Request(self.url+'/api',data=json.dumps({'action':action,'data':data or {}}).encode(),headers=headers or {'Content-Type':'application/json','X-Local-App':'1'})
        with self.client.open(req) as r:return json.load(r)
    def test_bootstrap_seed_session_and_csv(self):
        out=self.call('bootstrap',{'username':'fixture-admin','password':'[REDACTED:assigned_secret]','company_name':'验收企业'})
        self.assertNotIn('token',out)
        self.assertEqual(self.call('me')['user']['username'],'fixture-admin')
        self.assertGreaterEqual(len(self.call('list',{'entity':'templates'})),1)
        result=self.call('import_csv',{'content':'source_id,title,author\nfixture-1,想预约看房,验收用户\n'})
        self.assertEqual(result['imported'],1)
        self.assertIn('fixture-1',self.call('export_csv')['content'])
        self.call('logout'); self.assertIsNone(self.call('me')['user'])
    def test_csrf_and_unauthenticated(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.call('bootstrap',{}, {'Content-Type':'application/json','X-Local-App':'1','Origin':'https://example.org'})
        self.assertEqual(e.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError):self.call('list',{'entity':'leads'})
    def test_asset_upload_and_path_boundary(self):
        self.call('bootstrap',{'username':'fixture-admin','password':'[REDACTED:assigned_secret]'})
        record=self.call('upload_asset',{'name':'note.txt','base64':'dGVzdA==','kind':'验收文件'})
        self.assertTrue(Path(record['path']).is_file())
        self.assertEqual(self.client.open(self.url+'/asset/'+record['id']).read(),b'test')
        with self.assertRaises(urllib.error.HTTPError):self.client.open(self.url+'/references/../../app.py')

if __name__=='__main__':unittest.main()
