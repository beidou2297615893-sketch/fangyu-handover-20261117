"""Build review-only mother-comment text and a versioned 50-slot scenario plan."""
import json,csv,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; HERE=Path(__file__).resolve().parent/'mothers'
OUT=ROOT/'outputs/方隅双平台文本业务/母评论校准'
HERE.mkdir(parents=True,exist_ok=True); OUT.mkdir(parents=True,exist_ok=True)
cases=[
('价格预算','您好 什么价格','宝宝，我住方隅公寓这边，介绍有优惠的。','只核对亲切、住户起手与优惠承接的语气，不能当对原帖房子的正式报价。','账号确为住户；推荐优惠真实适用。','未知对方问哪套房、没有优惠依据或假扮住户时不用。'),
('位置通勤、价格预算','具体位置，多少钱','宝宝，我住方隅公寓这边，在【已核实位置】，介绍有优惠的。','沿第1条已认可的起手，补上位置；无现价不编报价。','住户身份、推荐优惠和具体门店位置已核实；目标地区可承接。','把原帖地点当本人需求、IP代替求租地或门店不明时不用。'),
('户型面积与居住方式','有一室一厅的房子吗','宝宝，这种户型方隅公寓也有，我可以介绍。','不是替原帖房东回答，而是介绍另一个明确选择。','同一适用门店确有该户型且当前可供了解。','仅有历史户型、没有现房事实、客户拒绝公寓时不用。'),
('价格预算、户型面积与居住方式、房内设施、位置通勤','一室一厅什么价带燃气吗，位置在哪里','宝宝，这样的方隅有，我介绍有优惠的。','测试综合接话的自然程度；不是把四个母句拼接。','同一房源同时满足一室一厅和燃气，位置可承接，当前报价及优惠可核对。','不从不同房源拼条件；没有房源事实时暂缓本句。'),
('价格预算；严肃家庭语境','越来越难了，唉，到处省钱，我自己已经把4500元的房租退了准备换3000以下的，因为是一家人住，不能合租','方隅公寓这边也可以看看，有【已核实预算内房型】，我可以介绍。','不叫宝宝，不机械复述一家人不容易，也不加如果还在找房。','确有3000以下并适合该家庭整租条件的房型；费用范围已核。','没有预算内家庭整租房、合租房凑条件或总费用超预算时不用。'),
('宠物','希望房子能养宠物，我有一只小狗，从不在家里上厕所，宁愿一直憋着，也一定要去外面上厕所。','宝宝，我住方隅公寓这边对宠物挺友好的，你可以找我了解一下。','住户体验前置，直接接住宠物诉求。','账号真实住户且有相关体验；该门店与房型的宠物政策适用于此宠物。','宠物大小/种类有限制却未核，或只凭品牌宣传作保证时不用。'),
('楼层电梯','几楼？可以去看看吗','宝宝，我住方隅公寓这边有电梯，你看合不合适？','本句只示范楼层/电梯接话；看房承接可在组合母句另调。','住户身份、该门店电梯及可推荐楼层均核实。','不能用有电梯替代客户明确的低楼层硬限制。'),
('入住与租期','短租一个月可以吗','宝宝，这个租期方隅公寓可以住，我可以介绍。','直接回应租期，不机械追问当前是否还找房。','同一门店确实接收一个月且当前可安排；入住日期另核。','古北历史1—12个月不能推广所有店；旧日期、缺库存时不用。'),
('费用合同','水电费贵吗','宝宝，我住方隅公寓这边，水电是【已核实收费】，你看看合不合适。','收费要有事实；不拿主观便宜替代收费范围。','本人经历真实；当前计费、额外费用和适用门店已核。','未知费率、以品牌整体代替实际门店、漏算必付费时不用。'),
('看房联系','怎么约看房','宝宝，你可以找我约看方隅公寓，我帮你对接。','明确由我承接，但不承诺已经约好。','账号确有介绍/对接权限；门店当前可安排看房。','不能把请求写成预约已确认，不能编销售联系方式。')]
samples=json.loads((ROOT/'work/xhs-topic-pool-evaluation/sample-comparison.json').read_text(encoding='utf8'))['samples']
sources={s['anonymous_original_comment']:{'path':s['source_file'],'text_sha256':s['source_text_sha256']} for s in samples}
old=ROOT/'work/reply-classification-20261029/old-snapshot.jsonl'
for line in old.open(encoding='utf8'):
 c=json.loads(line)
 for q in c['comments']:
  f=q['original_fields'];sources.setdefault(f.get('text',''),{'path':str(old),'comment_id':f.get('comment_id'),'customer_uid':c['platform_uid']})
entries=[]
for i,(pool,text,copy,why,facts,ban) in enumerate(cases,1):
 assert text in sources, f'missing source: {text}'
 entries.append({'slot':i,'pool':pool,'original_comment':text,'candidate':copy,'reason':why,'required_facts':facts,'forbidden':ban,'source':sources[text],'status':'待本人校准','user_approved':False})
slots=[]
single=[('价格预算',['具体房源问价','本人预算硬上限','比较租金与优惠']),('位置通勤',['问位置或小区','地铁与通勤上限','多地可选与优先地区']),('户型面积与居住方式',['问户型面积','明确整租或拒合租','人数与空间需求']),('房内设施',['燃气与做饭','采光隔音与朝向','独立厨卫与洗烘等']),('宠物',['能否养宠','大宠物或多宠物限制','费用与特殊宠物政策']),('楼层电梯',['问楼层电梯','明确拒绝一楼或高层','低楼层与无电梯限制']),('入住与租期',['一个月或短租','入住时间与可接租期','剩余租期与续签']),('房源状态',['是否仍有房','指定户型库存','原帖已租出与其他选择']),('费用合同',['押付与中介费','水电物业等必付项','合同及优惠适用条件']),('看房联系',['如何约看','具体看房时间请求','索取租赁联系方式'])]
for pool,scene in single:
 for sc in scene:slots.append({'slot':len(slots)+1,'type':'单需求','pool':pool,'scenario':sc,'text':None,'status':'场景槽位，待前10条语气反馈后拟写','user_approved':False})
combos=[('价格预算、位置通勤','位置与价格一起问'),('价格预算、户型面积与居住方式','户型和价格一起问'),('户型面积与居住方式、房内设施','一室一厅并要求燃气'),('价格预算、户型面积与居住方式、房内设施','价格、户型、燃气综合'),('宠物、楼层电梯','养宠与楼层限制'),('价格预算、费用合同','预算与全部必付费用'),('入住与租期、看房联系','入住安排与约看时间分开'),('房源状态、看房联系','有房与如何看房'),('位置通勤、户型面积与居住方式','目标位置与整租户型'),('宠物、户型面积与居住方式','宠物与独立空间'),('入住与租期、位置通勤','短租与通勤范围'),('价格预算、入住与租期','租期与租金条件'),('户型面积与居住方式、楼层电梯','户型与低楼层要求'),('房内设施、费用合同','设施与水电费用'),('价格预算、位置通勤、户型面积与居住方式','高频三需求综合')]
for pool,sc in combos:slots.append({'slot':len(slots)+1,'type':'组合','pool':pool,'scenario':sc,'text':None,'status':'场景槽位，待校准','user_approved':False})
for sc in ['家庭严肃语境，不强加宝宝','真实住户经历前置','官方或员工身份自然承接','事实不足且不虚构房源的中性接话','多条件冲突，暂缓并说明必要澄清']:
 slots.append({'slot':len(slots)+1,'type':'语境','pool':'依实际需求','scenario':sc,'text':None,'status':'场景槽位，待校准','user_approved':False})
assert len(slots)==50
approval_path=HERE/'本人认可记录.jsonl'
approved={}
if approval_path.exists():
 for line in approval_path.read_text(encoding='utf8').splitlines():
  if line.strip():
   event=json.loads(line)
   if event.get('user_approved') and event.get('approved_text'):approved[event['approved_text']]=event
   elif event.get('user_approved') and event.get('approved_snapshot'):
    snapshot=HERE/event['approved_snapshot']
    if not snapshot.exists():raise ValueError('Approved snapshot is missing; never infer or downgrade approval')
    for prior in json.loads(snapshot.read_text(encoding='utf8')):approved[prior['candidate']]=event
for e in entries:
 if e['candidate'] in approved:
  e.update(user_approved=True,status='本人已认可措辞，事实仍须逐账号核实',approval_version=approved[e['candidate']]['version'])
for e in entries:
 if e['slot']==1 and e['user_approved']:
  slots[0].update(text=e['candidate'],status='本人已认可措辞，事实仍须逐账号核实',user_approved=True)
(HERE/'first10.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf8')
(HERE/'scenario50.json').write_text(json.dumps(slots,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# 前10条母评论：先调语气','',
('你已看过前10条并认可整体口气与措辞；现在一次审看50条，不再逐条提问。' if all(e['user_approved'] for e in entries) else '第1条已获你明确认可，其余9条仍待逐条校准。' if entries[0]['user_approved'] else '全部为待你逐条校准的候选，没有一条被自动标为认可。')+'原评论来自已有真实记录，用于调口气，不代表对方今天仍有需求或可以发送。',
'【方括号】表示尚需核实的业务事实，未填实之前整句不能用于回复。即使没有方括号，住户身份、优惠和房源等适用条件也必须满足。','']
for e in entries:
 lines += [f"## 第{e['slot']}条｜{e['pool']}",'',f"**客户原话：** {e['original_comment']}",'',f"**{'已认可母句' if e['user_approved'] else '待调母句'}：** {e['candidate']}",'',f"这条想解决：{e['reason']}",f"适用前提：{e['required_facts']}",f"不能使用的情况：{e['forbidden']}",('你的反馈：'+approved[e['candidate']]['user_verbatim']+'；仅该条措辞，不代表授权发送。' if e['user_approved'] else '你的改法：待口述或逐条填写。'),'']
lines+=['后续安排：一次审看《第一批50条母评论模板》、集中反馈，不再逐条提问。前10条的认可不自动推广到新拟40条，也不保证覆盖全部评论。','']
(OUT/'先调这10条.md').write_text('\n'.join(lines),encoding='utf8')
with (OUT/'50条母评论场景量表.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['顺序','场景类型','需求池','适用场景','拟稿状态','本人认可状态'])
 for s in slots:w.writerow([s['slot'],s['type'],s['pool'],s['scenario'],s['status'],'该条已认可，事实待核' if s['user_approved'] else '未认可'])
(OUT/'认可与修改记录模板.csv').write_text('\ufeff日期,对应场景,客户原话,原母句,本人改法,修改原因,适用平台,适用账号身份,必需门店事实,认可范围,生效版本\n',encoding='utf8')
print(json.dumps({'first_candidates':len(entries),'scenario_slots':len(slots),'approved':sum(e['user_approved'] for e in entries),'source_matches':all(e['source'] for e in entries)}))
