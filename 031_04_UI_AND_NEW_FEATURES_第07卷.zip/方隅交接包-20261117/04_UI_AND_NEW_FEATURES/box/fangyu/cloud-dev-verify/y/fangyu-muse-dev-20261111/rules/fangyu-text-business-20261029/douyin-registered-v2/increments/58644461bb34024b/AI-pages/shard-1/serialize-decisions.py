"""Serialize explicit model decisions. No text matching or intent inference."""
import json, hashlib, copy, sys
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone

P=Path(__file__).resolve().parent
B=P.parent.parent
W=B.parents[2]
source=[json.loads(x) for x in (B/'shard-1.jsonl').read_text(encoding='utf8').splitlines()]
by={x['review_key']:x for x in source}
mothers={x['slot']:x for x in json.loads((W/'approved-mothers-model-view.json').read_text(encoding='utf8'))}
decisions={}
PRICE='价格预算'; LOC='位置通勤'; HOME='户型面积与居住方式'; FAC='房内设施'; PET='宠物'; FLOOR='楼层电梯'; TIME='入住与租期'; STATUS='房源状态'; FEE='费用合同'; CONTACT='看房联系'
def T(pool,quote,polarity='ask',subject='own_demand',scope=None):
    return dict(pool=pool,quote=quote,polarity=polarity,subject=subject,condition_scope=scope)
def G(text,quote=None,relation='desired',group='unknown',scope=None):
    return dict(text=text,quote=quote or text,relation=relation,group_relation=group,condition_scope=scope)
def C(quote,detail): return dict(quote=quote,detail=detail)
def TM(quote,role,normalized=None):
    return dict(quote=quote,time_role=role,anchor_source='comment.published_at_unix',anchor_time=None,normalized=normalized,verification='发表时间可用；按原词保留，不以分析日推定当前状态')
def A(key,role,state,interest,reason,topics,regions,slot,suitable,review,*,constraints=None,times=None,possible=None,boundaries=None,policy='allow',tone='normal',flags=None):
    assert key not in decisions
    s=by[key]
    missing=[]
    if slot is not None: missing.append(mothers[slot]['required_facts'])
    if suitable and slot!=1: missing.append(mothers[1]['required_facts'])
    if suitable: missing.append('客户目前是否仍需要住房、目标地区与同店有效房源能否承接；实际优惠及适用条件尚未核实')
    missing.extend(review)
    decisions[key]={**{f:s[f] for f in ['review_key','platform','comment_id','customer_uid','video_id']},'role':role,'demand_state':state,'interest':interest,'topics':topics,'target_regions':regions,'time_mentions':times or [],'other_constraints':constraints or [],'possible_topics':possible or [],'evidence':[s['comment_text']],'reason':reason,'context_used':['own','body'],'needs_review':review,'contact_boundaries':boundaries or [],'context_flags':{'post_author_same_as_commenter':False,'source_store_is_not_target':True,'post_conditions_not_assigned_to_commenter':True,**(flags or {})},'reply_plan':{'preferred_mother_slot':slot,'generic_intro_suitable':suitable,'tone':tone,'missing_facts':missing,'caution':['母句仅本地候选，不回答未核实价格、库存、优惠或政策；allow不是发送许可'] if suitable else ['语义尚不适合直接推介或不属于当前住宅租赁需求；仅保留判读，不发送'],'contact_policy':policy},'human_confirmed':False,'send_authorized':False,'store_assignment':None}
def D(key,interest,reason,topics,regions,slot,review,**kw):
    A(key,'demand','active_at_comment',interest,reason,topics,regions,slot,True,review,**kw)
def Q(key,reason,topics=None,regions=None,**kw):
    A(key,'discussion','unknown','unrelated',reason,topics or [],regions or [],None,False,[],**kw)
def U(key,reason,topics=None,regions=None,review=None,**kw):
    A(key,'unknown','unknown','uncertain',reason,topics or [],regions or [],None,False,review or [reason],**kw)

# Explicit semantic initial and detailed decisions, read against full shared post bodies.
D('D0002','high','向租房中介主动询问尚有无房子，是评论时找房动作，未指明户型地区。',[T(STATUS,'还有没有房子')],[],1,['具体目标地区、预算及目前需求未说明'])
D('D0005','medium','租房中介自述帖下询问联系方式，有接洽线索；尚未明确租房条件或约看。',[T(CONTACT,'请问怎么联系你呢')],[],28,['联系目的是否为本人租房及具体条件需核；不是明确预约'])
D('D0008','high','询问火车南站附近能否提供房源，租房语境支持评论时需求。',[T(LOC,'火车南站附近')],[G('火车南站附近')],31,['需核所在城市及可承接门店，不能按IP补地区'])
D('D0011','high','明确温江锦秀城套三房源询租。',[T(LOC,'温江锦秀城'),T(HOME,'套三','require')],[G('温江锦秀城')],34,['套三有效房态、报价及具体位置待核'])
D('D0014','high','骨科医院附近为目标，套一或公寓为可接受替代，不是两者同时硬需。',[T(LOC,'青羊区骨科医院附近'),T(HOME,'套一的或者公寓都行','accept',scope='套一或公寓二选一')],[G('青羊区骨科医院附近')],34,['同一房源满足位置与其一居住方案；报价房态待核'])
D('D0017','high','尚未到成都但已主动找武侯区合租伙伴，找房动作发生于评论时。',[T(LOC,'武侯区'),T(HOME,'一起合租','require')],[G('武侯区')],7,['合租对象和入住时间待核；尚未到成都不等于未来才开始找'],constraints=[C('男生','本人说明男性身份；未明确只接受男性室友')],times=[TM('目前还没到成都','other')])
A('D0020','demand','active_at_comment','unrelated','本人明确问150万元能买什么房，是购房而非住宅租赁需求。',[T(PRICE,'预算一百五十万','require',scope='购房总预算')],[],None,False,['仅买房，不用租赁母句；目标地区未自报'],constraints=[C('能买什么样的房子','明确购房用途')],flags={'purchase_only':True})
U('D0023','避雷帖下感叹没早点看到，可能经历过问题但未说明已解决或还在找房。',review=['本人是否遇到租房问题、是否仍需换租待核；不从感叹推定已结束'])
A('D0026','demand','active_at_comment','unrelated','明确想买房供五人居住，不属于确定租赁需求；70个的金额单位尚未澄清。',[T(PRICE,'有70个','fact',scope='购房资金，单位未明'),T(HOME,'不用很大，够5️⃣个人住','require',scope='购房居住容量')],[],None,False,['购房用途明确；70个是否70万元及中大所指待核'],constraints=[C('想买一套中大的房子','本人明确购房；中大是地名还是描述不明')],flags={'purchase_only':True})
A('D0029','demand','active_at_comment','unrelated','主动求推荐小户型，但明确买房，保留真实购房身份。',[T(HOME,'小户型','require',scope='购房')],[],None,False,['只买房，不使用公寓租赁母句'],constraints=[C('想买个','明确购房而非租赁')],flags={'purchase_only':True})
U('D0032','福州中介避雷帖下问鼓楼区有没有靠谱的，有住房/中介线索但对象和租购未明。',[T(LOC,'鼓楼区',subject='unresolved')],[G('鼓楼区',relation='unresolved')],['靠谱的所指中介还是房源、本人租购及条件待核'])
Q('D0035','赞和比心表情属于欣赏互动，未表达住房诉求。')
D('D0038','high','租房价格讨论帖下主动问浦东房源，评论自身表达区域找房。',[T(LOC,'浦东')],[G('浦东')],31,['浦东具体范围、预算房型待核'])
D('D0041','high','主动求浦东金桥租房推荐。',[T(LOC,'浦东金桥')],[G('浦东金桥')],31,['具体预算房型及门店承接待核'])
D('D0044','high','明确宝山大华、两房及5000预算的组合找房。',[T(LOC,'宝山大华'),T(HOME,'2房','require'),T(PRICE,'5000','require')],[G('宝山大华')],34,['5000计价与全部必付费用上限、两房有效库存待核'])
A('D0047','demand','future','low','明确一年后才考虑找博主，当前未见推进住房筛选。',[],[],1,False,['一年后是计划接洽找房时间，不能认定当下高意向'],times=[TM('1年后','search_start','2027-09-12（约，按发表日期一年后）')])
A('D0050','demand','future','medium','关注并表达后续换房找博主，保留未来需求；尚无当前筛房推进。',[],[],1,True,['后面换房的计划时间及具体条件待核'],times=[TM('后面要换房子找你','search_start')])
D('D0053','high','租房语境下主动问张江房源。',[T(LOC,'张江')],[G('张江')],31,['张江具体位置、预算房型待核'])
U('D0056','出租帖下质疑6000与1350报价矛盾，关注真实性但没有明确租房推进。',[T(PRICE,'这不是6000吗？怎么又1350了？','compare',subject='unresolved')],review=['是否本人有租赁需要及报价真假待核；不把质疑当预算'])
D('D0059','high','条件性表示价格若真实要两套，有强询租动作但非无条件订房。',[T(PRICE,'这个价格是真的假的','ask'),T(HOME,'如果是真的，我要两套','conditional',scope='价格真实才要两套')],[],34,['两套是租赁及同样房型需核；真实价格、附加费、两套房态待核'])
D('D0062','high','明确出租帖下问这套房位置，属于当时询租。',[T(LOC,'在哪个位置呀？这个房子。')],[],31,['具体地址与本人接受范围待核'])
Q('D0065','奉贤都有是对房源分布的评价，没有自报目标或求房。',regions=[G('奉贤',relation='unresolved')])
D('D0068','high','明确在租房源下问哪里，保留当时位置询盘。',[T(LOC,'哪里')],[],31,['所询房源具体地址与客户接受范围未核'])
D('D0071','high','出租房源下询位置，不因短句或发表早就过滤。',[T(LOC,'在哪里，')],[],31,['地址及目前是否仍需房待核；可见2条深层回复未读取'])
D('D0074','high','明确出租房源下问位置，有询租兴趣。',[T(LOC,'在哪啊')],[],31,['房源地址和本人目标范围未核'])
Q('D0077','对博主纠结燃气提出看法并表达电磁炉更好，非本人找房设施条件。',[T(FAC,'个人感觉电磁炉更好','prefer','other_person',scope='讨论做饭方式；非找房要求')])
Q('D0080','艾特朋友感叹上海贵，是房租价格讨论，未提出本人找房动作。',[T(PRICE,'好贵上海','fact','unresolved')])
Q('D0083','评价上海租房没那么夸张，非本人求租。')
D('D0086','high','明确在周浦东上班并问租哪里，工作地不是自动目标居住地。',[T(LOC,'在周浦东上班推荐租哪里啊')],[G('周浦东','在周浦东上班',relation='work')],31,['工作地点准确所指及可接受通勤、预算需核'])
D('D0089','medium','向租房路线博主索要金虹桥国际中心拼多多路线，有通勤住房线索但未明确本人已在找房。',[T(LOC,'金虹桥国际中心，拼多多的路线')],[G('金虹桥国际中心','金虹桥国际中心，拼多多的路线',relation='unresolved')],31,['是否本人工作地和租房计划、路线起点待核'])
D('D0092','high','娄山关路为工作地点，主动问租哪里好。',[T(LOC,'娄山关路上班租哪里好')],[G('娄山关路','娄山关路上班',relation='work')],31,['可接受通勤及预算未说明'])
D('D0095','high','明确出租公寓下问价了解，属于当时询租。',[T(PRICE,'多钱，了解')],[],1,['具体房型有效报价及全部必付费用未核'])
D('D0098','high','出租房源下明确问价。',[T(PRICE,'多少钱')],[],1,['所询房型及当前有效报价未核'])
D('D0101','high','可租房源语境下问价是明确询租兴趣。',[T(PRICE,'问价')],[],1,['房型报价与附加费用未核'])
D('D0104','high','出租公寓下用价格询问租金，不是无语义互动。',[T(PRICE,'价格')],[],1,['报价及计费口径未核'])
D('D0107','high','明确问出租公寓价位。',[T(PRICE,'这个什么价位')],[],1,['所指户型、同店有效报价未核'])
D('D0110','high','问所示出租房型价位，不能把正文所有配置移为本人硬要求。',[T(PRICE,'这样的多少价位')],[],1,['所指房型和有效报价待核'])
D('D0113','high','在可租房源下询具体价格。',[T(PRICE,'什么价格')],[],1,['当时所指房型及现有效报价待核'])
D('D0116','high','本人十里河上班并求较短通勤的居住建议。',[T(LOC,'在十里河上班，住哪里会比较好，不用通勤时间那么长','require')],[G('十里河','在十里河上班',relation='work')],31,['可接受通勤时长、预算待核；10条可见深层回复未读'])
Q('D0119','赞美博主人美心善，未表达住房需要。')
D('D0122','high','主动咨询公寓选择，14号线是偏好不是硬限制。',[T(HOME,'公寓','require'),T(LOC,'14号线最好','prefer')],[G('14号线','14号线最好',relation='preferred')],34,['14号线具体站点、预算与同店可用公寓待核'])
D('D0125','high','在北京租房攻略下给出金台路和3000预算，是找房条件。',[T(LOC,'金台路'),T(PRICE,'预算3000','require')],[G('金台路')],34,['3000是否全部费用上限、房型和有效库存待核'])
D('D0128','high','本人在通州新华北路附近并询1500左右房源，明确附近找房但未说明现住或工作身份。',[T(LOC,'通州新华北路这边哪里有'),T(PRICE,'1500 左右','require')],[G('通州新华北路这边','通州新华北路这边哪里有',relation='desired')],34,['当前所在是现住地还是工作地、租房范围、全部费用和房型待核'])
D('D0131','high','明确经海路地铁附近、两千预算、可合租但要求独卫。',[T(LOC,'经海路地铁附近','require'),T(PRICE,'预算两千','require'),T(HOME,'可合租','accept'),T(FAC,'求独卫','require')],[G('经海路地铁附近')],34,['独卫与合租方式在同一房源落实；预算含费范围待核'])
D('D0134','high','本人和对象各有工作地，问预算2000上下在哪租；两个工作地不当居住目标。',[T(LOC,'我在通州经海五路那上班我对象在木樨园'),T(PRICE,'预算2000上下','require')],[G('通州经海五路','我在通州经海五路那上班',relation='work',group='AND'),G('木樨园','我对象在木樨园',relation='work',group='AND')],34,['双方通勤权衡、整租或合租、费用上限待核'],constraints=[C('我对象','两人有分别工作地；未明确两人同住或房型')])
D('D0137','high','主动求西单2000以内租房。',[T(LOC,'西单'),T(PRICE,'2000以内','require')],[G('西单')],34,['预算是否含费、房型及同区有效库存待核'])
Q('D0140','叙述入住一个多月后水电尚未收取，询现居计费情况，未提出换租。',[T(HOME,'小区隔断的两室一厅一厨一卫','fact','current_home'),T(FEE,'中介没喊我交水电费我也没问','fact','current_home')],times=[TM('来了一个多月了','other')])
Q('D0143','水电费讨论下报电费几十，非找房预算。',[T(FEE,'电费几十','fact','current_home')])
Q('D0146','水电费讨论下叙述每月700开销，不是租金预算或新需求。',[T(FEE,'我一个月700','fact','current_home')])
Q('D0149','叙述义乌空调一晚费用，未表达目标地区和求租。',[T(FEE,'一晚上空调十几块','fact','current_home')],regions=[G('义乌',relation='unresolved')])
Q('D0152','叙述8月电量及费用，非本人求租。',[T(FEE,'8月928度电   450块','fact','current_home')],times=[TM('8月','other')])
U('D0155','因高额电费已搬离红街公寓，但新住处或后续租房是否解决未说清，保留变动机会。',[T(FEE,'电费一个月500','fact','current_home')],[G('上城区红街公寓','我们住在上城区红街公寓',relation='current_home')],['已搬走不等于已租好；后续是否需另找房及收费争议待核'],times=[TM('搬走了','other')],flags={'housing_transition_unresolved':True})
Q('D0158','提醒租房别只看房租，是经验建议。')
U('D0161','与朋友商量去杭州，独居合租生活帖未给出租房态；不能推定当时正求房。',regions=[G('杭州','我们去杭州吧',relation='unresolved')],review=['去杭州是旅行、搬迁还是找房未明'])
U('D0164','生活合租帖下问价，疑似住房价格兴趣但正文没有明确在出租。',[T(PRICE,'多少价',subject='unresolved')],review=['所问是否房租、本人是否求租和房态待核'])
U('D0167','生活帖下问联系，保留住房接洽线索但联系对象和意图未明。',[T(CONTACT,'怎么联系',subject='unresolved')],review=['联系目的、是否出租及本人租赁需要待核'])
U('D0170','生活合租帖下单说多少，指标与所问对象不明。',review=['所问可能价格或面积，出租状态及本人需求待核'],possible=[{'candidate_pools':[PRICE,HOME],'ambiguity':'多少未说明价格、面积或其他指标，正文不是明确出租'}])
D('D0173','high','房东租房帖下询萧山房源。',[T(LOC,'萧山')],[G('萧山')],31,['萧山具体范围、预算及可用房态待核'])
D('D0176','high','房东租房帖下询大江东房源。',[T(LOC,'大江东')],[G('大江东')],31,['大江东具体区域和房型预算待核'])
D('D0179','high','房东租房语境下询小和山附近。',[T(LOC,'小和山那边')],[G('小和山那边')],31,['具体范围与房态待核；可见深层回复未读'])
D('D0182','high','询余杭未来科技城附近租房。',[T(LOC,'余杭未来科技城附近')],[G('余杭未来科技城附近')],31,['预算、房型及附近可承接房态待核'])
Q('D0185','提出福州租房不如申请公租房的建议，没有本人申请或求租动作。')
D('D0188','high','明确整租出租帖下问具体价。',[T(PRICE,'具体价格多少？')],[],1,['具体房型现有效价格和必付费用未核'])
D('D0191','high','明确整租房源下询还有无房，评论时房态兴趣。',[T(STATUS,'你好还有吗')],[],1,['有效房态、客户当前需求及条件未核'])
D('D0194','high','出租房源下短询还有吗，不能因旧日期认定已租好。',[T(STATUS,'还有吗')],[],1,['当前库存和本人目前是否仍需房待核'])
D('D0197','high','明确出租房源下问在哪，是位置询租。',[T(LOC,'在哪')],[],31,['房源地址和本人目标范围待核'])
D('D0200','high','出租房源下同时问位置与月租，月计价不是租期。',[T(LOC,'在哪'),T(PRICE,'多少一个月')],[],31,['房源真实地址、月租和全部费用待核'])
D('D0203','high','出租房源下问位置并问多少米，后者不确定价格还是面积。',[T(LOC,'这在哪？')],[],31,['多少米的指标与具体房源价格面积待核'],possible=[{'candidate_pools':[PRICE,HOME],'ambiguity':'多少米可能指价格或面积，未澄清前不进入确定价格或面积池'}])
Q('D0206','建议博主租北外滩虹口，不是本人目标地区。',[T(LOC,'租在北外滩虹口可能会好点','prefer','other_person')],regions=[G('北外滩虹口',relation='unresolved')])
Q('D0209','艾特朋友并感叹我靠，属明确反应互动，未提出住房诉求。')
Q('D0212','评论灯光没有频闪，属于视频设施观察，非本人房源要求。',[T(FAC,'第三个灯没有频闪','fact','other_person')])
U('D0215','只有艾特，转给朋友的用途未知，不能判定本人求租或彻底无关。',review=['纯艾特无本人需求证据，不生成推介'])
U('D0218','只有艾特和躺平表情，分享目的不明，保留未知低优先。',review=['未说明本人找房；不生成推介'])
Q('D0221','对视频多窗户冬天冷作观察，并未表达本人找房约束。',[T(FAC,'这么多窗户','fact','other_person')])
Q('D0224','叙述自己五角场现租单间1500并感叹，未说换房。',[T(PRICE,'1500一个月','fact','current_home'),T(HOME,'一个单间','fact','current_home')],regions=[G('五角场','我在五角场',relation='current_home')])
D('D0227','high','工作后滩并求2500以下租住建议，工作地不直接当居住目标。',[T(LOC,'工作地点在后滩 租哪里好一点'),T(PRICE,'预算2500以下','require')],[G('后滩','工作地点在后滩',relation='work')],34,['可接受通勤、房型及预算含费口径待核'])
D('D0230','high','主动问南京东路相关租住选址；南京东路是工作还是目标未说明。',[T(LOC,'南京东路最好要在哪里租呀')],[G('南京东路',relation='unresolved')],31,['南京东路作为工作地还是目标居住地、通勤预算待核'])
D('D0233','high','远程工作不限制地区，明确3k内一室、燃气厨房、电梯、新小区、较好装修、朝南的联合需求。',[T(LOC,'不要求位置','not_required'),T(PRICE,'3k以内','require'),T(HOME,'一室','require'),T(FAC,'燃气厨房','require'),T(FLOOR,'有电梯','require'),T(FAC,'装修好点','prefer'),T(FAC,'朝南','require')],[],34,['同一房源联立全部硬条件及装修偏好，3k含费范围、报价库存待核'],constraints=[C('在家工作','远程办公语境，不能当具体工作地区'),C('新小区','本人要求较新的住宅小区；不是新增需求池')])
D('D0236','high','本人吴中路工作并求租住建议，未指定住吴中路。',[T(LOC,'在吴中路上班在哪里租房好一点')],[G('吴中路','在吴中路上班',relation='work')],31,['可接受通勤、预算和户型待核'])
D('D0239','high','工作中山公园并问找房，刚出来钱少不能补具体预算。',[T(LOC,'中山公园上班在哪找房子呢'),T(PRICE,'刚出来没什么钱','prefer')],[G('中山公园','中山公园上班',relation='work')],31,['具体预算、通勤和房型未说明'])
U('D0242','租房攻略下只说双江路，可能是想咨询该地但关系未明。',[T(LOC,'双江路',subject='unresolved')],[G('双江路',relation='unresolved')],['双江路是工作地、现住地还是目标；有无本人租房需求未明'])
Q('D0245','笑声是情绪互动，未表达住房需要。')
D('D0248','high','明确出租房源下同时问房态和民水民电，属于当时询租。',[T(STATUS,'还有吗？'),T(FEE,'是民水民电吗')],[],25,['同一房源可租状态、当前水电口径及其他必付项待核'])
D('D0251','high','出租房源下问价格，保留当时询租。',[T(PRICE,'什么价格')],[],1,['具体房型及同店有效报价待核'])
D('D0254','high','出租房源下问多少钱。',[T(PRICE,'多少钱')],[],1,['报价、计费周期与房态待核'])
D('D0257','high','明确出租并降价帖下多少按共享价格语境理解为询价，不能移入房型配置。',[T(PRICE,'多少')],[],1,['具体所指价位、房型及附加费待核'])
D('D0260','high','多少租直接询租金。',[T(PRICE,'多少租')],[],1,['租金及总必付费用待核'])
D('D0263','high','可租公寓下问价是当时询租。',[T(PRICE,'多少钱')],[],1,['所指户型及现报价待核'])
D('D0266','high','明确新都花满庭附近一公里房源范围。',[T(LOC,'新都，花满庭附近一公里','require')],[G('新都花满庭附近一公里','新都，花满庭附近一公里')],31,['一公里范围符合的库存、预算户型待核'])
D('D0269','high','询大源地铁站附近房源。',[T(LOC,'大源地铁站附近')],[G('大源地铁站附近')],31,['具体距离容忍度、预算户型待核'])
U('D0272','中介真诚自述帖下说我要，有接洽线索但未明确要房子还是服务。',review=['我要的对象及本人租房需求、条件未明；不当订房'])
Q('D0275','自报仓山上渡现住单身公寓1800，未求换租。',[T(HOME,'单身公寓','fact','current_home'),T(PRICE,'一千八','fact','current_home')],regions=[G('仓山上渡附近','我仓山上渡附近',relation='current_home')])
U('D0278','房租压力帖下报鼓楼中心单间900三房2700，可能分享市价或提供房源，供需未明。',[T(PRICE,'单间900，三房一厅2700','fact','unresolved'),T(HOME,'单间','fact','unresolved'),T(HOME,'三房一厅','fact','unresolved')],[G('鼓楼中心',relation='unresolved')],['本人现租、市场讨论还是出租报价待核，不当本人预算'])
A('D0281','supply','unknown','unrelated','问马尾老城区有人租吗是在招租，不是自己找房。',[T(STATUS,'有人租？','ask','supply')],[G('马尾老城区',relation='offered')],None,False,[],flags={'supply_only':True})
Q('D0284','容易呀是对房租话题的评价，无本人需求。')
Q('D0287','推荐城中村三四百房价是给他人的建议，不是本人预算。',[T(PRICE,'就三四百','fact','other_person')])
U('D0290','房租讨论下只报1600，可能现住租金或预算，未有找房动作。',[T(PRICE,'1600','unknown','unresolved')],review=['1600是现租金额、市场报价还是新预算未明'])
Q('D0293','询为何没说新店，是对视频地区覆盖的讨论，非明确求房。',regions=[G('新店',relation='unresolved')])
Q('D0296','串串是对视频装修/房源的评论，没有本人求房。')
D('D0299','high','明确好房推荐两房房源下问价。',[T(PRICE,'多少钱')],[],1,['所指房源有效报价待核'])
D('D0302','high','明确房源实景推荐下询价格。',[T(PRICE,'什么价格？')],[],1,['现报价和全部费用待核'])
D('D0305','high','房源推荐下询多少钱，保留评论时兴趣。',[T(PRICE,'多少钱')],[],1,['所询房源价格及房态待核'])
D('D0308','high','租房语境下明确问九亭房源。',[T(LOC,'九亭')],[G('九亭')],31,['预算和房型、门店承接待核'])
D('D0311','high','世纪公园或人民广场都可，保留地区OR替代关系。',[T(LOC,'世纪公园[玫瑰][玫瑰]人民广场都可以','accept')],[G('世纪公园',relation='accepted',group='OR'),G('人民广场',relation='accepted',group='OR')],31,['两地其一可接受；具体通勤、预算户型未核'])
D('D0314','high','求惠南镇小一点房源，面积偏好无具体数值。',[T(LOC,'惠南镇'),T(HOME,'小一点的','prefer')],[G('惠南镇')],34,['小一点所指面积或户型、预算和同区房态待核'])
D('D0317','high','主动问剑川路附近租房。',[T(LOC,'剑川路那边')],[G('剑川路那边')],31,['预算、房型和具体范围待核'])
Q('D0320','表示似乎看过视频内容，没有本人找房动作。')
D('D0323','high','租房语境下问曹路有无房源。',[T(LOC,'曹路')],[G('曹路')],31,['具体位置、预算户型待核'])
D('D0326','high','在明确出租帖下问张华浜公寓，保留异区需求而非来源店指派。',[T(LOC,'张华浜'),T(HOME,'公寓','require')],[G('张华浜')],34,['张华浜具体范围、可租公寓及报价待核'])
D('D0329','high','出租公寓下询地点。',[T(LOC,'哪里的公寓')],[],31,['所询房源地址和本人地区接受度待核'])
U('D0332','明确出租帖下称这不错，属于弱关注但没有明确找房推进。',review=['是欣赏房源还是本人准备求租未明'])
D('D0335','high','明确租房目的并索联系，不自动升成约看超高。',[T(CONTACT,'租房怎么联系啊')],[],28,['具体租房条件和对接渠道待核；未表达预约时段'])
D('D0338','high','主动求短租一两个月，明确租期不是月租计价。',[T(TIME,'短租','require'),T(TIME,'一两个月的','require')],[],19,['同店是否接收1—2个月以及可用房型报价待核'],times=[TM('一两个月的','lease_duration','1—2个月')])
D('D0341','high','询虹桥天地附近租房。',[T(LOC,'虹桥天地附近')],[G('虹桥天地附近')],31,['具体距离预算房型待核'])
D('D0344','high','可租房源帖下询这个还有无。',[T(STATUS,'这个还有吗')],[],1,['具体所指房源现库存待核'])
Q('D0347','判断视频中有串串房，是房源观察，无本人求租。')
Q('D0350','串串房是对视频装修类型的评价，未有本人求房。')
D('D0353','high','看房经历帖下明确询1w2毛坯房位置，评论自身锁定房源，有当时兴趣；非自报12000上限。',[T(LOC,'在哪里呀'),T(PRICE,'1w2那个毛坯','fact',scope='所指房源标识，不等于本人预算'),T(FAC,'毛坯','fact',scope='所指房源，不是硬要求')],[],31,['所指房源位置、当时/目前可租状态及本人预算待核'])
Q('D0356','评论上海租金较过去下降，属市场讨论。',[T(PRICE,'上海租房价格都下来不少了','fact','unresolved')])
Q('D0359','建议博主稍远租高品质大两房，不是本人区域、户型或预算要求。',[T(HOME,'大2房','prefer','other_person')])
U('D0362','押金纠纷经历帖下短租不租，可能是出租方拒短租或本人不接受短租，身份作用域不明。',[T(TIME,'短租不租','reject','unresolved')],review=['不租短租的主体及含义待核，不能推定本人长租需求或全面拒联'])
D('D0365','high','明确龙柏新村招室友帖下问多少，结合房源招租语境保留询租金。',[T(PRICE,'多少')],[],1,['具体价格、合租房态及同住条件待核'])
U('D0368','纯艾特，北漂租房避坑语境无法证明本人找房或明确无关。',review=['艾特用途与本人需求未明；不生成推介'])
U('D0371','两个艾特没有实质文字，分享用途不明。',review=['没有本人租房条件或找房动作，不生成推介'])
A('D0374','supply','unknown','unrelated','自称房东提供景泰站两居整租，全部配置属于供给。',[T(LOC,'14号线地铁景泰站附近','fact','supply'),T(HOME,'两居整租','fact','supply'),T(FLOOR,'一层','fact','supply'),T(FAC,'家具家电齐全','fact','supply'),T(PET,'宠物友好','fact','supply')],[G('14号线地铁景泰站附近',relation='offered')],None,False,[],constraints=[C('如果公司租既可以存放货物也不影响居住','供给方说明兼容存货场景，不是本人求办公仓库'),C('房东在此','本人明确供给方身份')],flags={'supply_only':True})
A('D0377','supply','unknown','unrelated','本人转租丰台长辛店房源并报优惠设施费用，未说自己另找房。',[T(LOC,'丰台区长辛店西峰寺','fact','supply'),T(FLOOR,'4楼','fact','supply'),T(PRICE,'原1620/月，本人转租1400/月','fact','supply'),T(FEE,'包暖气费包物业费包网费','fact','supply')],[G('丰台区长辛店西峰寺',relation='offered')],None,False,['如另有换房需求需本人说明；不把转租本身推定本人找房'],constraints=[C('搭一辆雅迪高速电动车','转租供给附带电动车，不是本人新房需求')],flags={'supply_only':True})
A('D0380','supply','unknown','unrelated','提供大望路30平胡同平房及计费装修信息，邀人帮看三年房属于供给。',[T(LOC,'大望路','fact','supply'),T(HOME,'30平（胡同平房）','fact','supply'),T(FEE,'电费按照国标，水费居委会定点儿收','fact','supply'),T(FAC,'家电全新','fact','supply'),T(TIME,'来帮我看3年房吧','ask','supply')],[G('大望路',relation='offered')],None,False,[],times=[TM('3年','lease_duration','3年（供给邀租）'),TM('6月刚装完','other')],flags={'supply_only':True})
A('D0383','supply','unknown','unrelated','借楼提供传媒大学站附近房东直租合租位，是招租不是求租。',[T(LOC,'朝阳区传媒大学地铁站400米','fact','supply'),T(HOME,'寻求干净利落人合租','require','supply'),T(FAC,'全屋向阳','fact','supply'),T(FEE,'没有中间费用','fact','supply')],[G('朝阳区传媒大学地铁站400米',relation='offered')],None,False,[],constraints=[C('寻求干净利落人合租','供给方要求室友干净利落，不作为本人新房条件')],flags={'supply_only':True})
A('D0386','supply','unknown','unrelated','转租天丰苑小区并列设施和月价，是供给广告，无新求租动作。',[T(LOC,'丰台区天丰苑小区','fact','supply'),T(FAC,'空调、冰箱、热水器、燃气灶、冬天供暖、床、衣柜、桌子等一应俱全','fact','supply'),T(PRICE,'一个月1000多','fact','supply')],[G('丰台区天丰苑小区',relation='offered')],None,False,[],flags={'supply_only':True})
U('D0389','服务式公寓出租帖下问是不是方隅，是品牌识别弱关注，未足以确定找房推进。',review=['所询品牌及本人是否准备租房未明；不能凭来源店确认品牌事实'])
D('D0392','high','明确出租帖下要求私信价格，有当时租房询价；私我不是当前任务发送授权。',[T(PRICE,'价格'),T(CONTACT,'私我','ask')],[],1,['具体房型价格未核；渠道偏好不是本任务发送授权'],constraints=[C('价格私我','本人希望通过私信获报价；保留渠道偏好')])
D('D0395','high','明确服务式公寓出租帖下问这样的价位。',[T(PRICE,'这样的得多少钱啊')],[],1,['所指户型与全部必付费用待核'])
D('D0398','high','明确可住出租公寓帖下问位置。',[T(LOC,'在哪啊')],[],31,['地址和客户接受范围待核'])
D('D0401','high','明确想找十里河附近两居室。',[T(LOC,'十里河附近','require'),T(HOME,'两居室','require')],[G('十里河附近')],34,['预算、附近范围及两居房态待核'])
D('D0404','high','单位在坝北村并问有房，工作地不自动成为居住目标。',[T(LOC,'单位在坝北村那块'),T(STATUS,'有房吗')],[G('坝北村','单位在坝北村那块',relation='work')],31,['可接受通勤、预算房型及有效房态待核'])
D('D0407','high','租房攻略下主动问石景山房源。',[T(LOC,'石景山')],[G('石景山')],31,['预算、具体位置与房型待核'])
D('D0410','high','公司在14号线，期望14/16/6号线周围、预算1500左右；地区替代关系保留。',[T(LOC,'公司在14号线上'),T(LOC,'建议在14号线，16号线，六号线周围','prefer'),T(PRICE,'1500 左右预算','require')],[G('14号线','公司在14号线上',relation='work'),G('14号线','14号线，16号线，六号线周围',relation='preferred',group='OR'),G('16号线','14号线，16号线，六号线周围',relation='preferred',group='OR'),G('六号线','14号线，16号线，六号线周围',relation='preferred',group='OR')],34,['偏好三线其一及具体站点、通勤、费用上限和库存待核'])
D('D0413','high','公司西单，要求两室一厅或三室一厅、近地铁且不超1500，不能把户型和预算分开满足。',[T(LOC,'公司在西单'),T(HOME,'两室一厅或者三室一厅','require',scope='两室一厅或三室一厅其一'),T(LOC,'离地铁站比较近的','require'),T(PRICE,'不超过1500','require')],[G('西单','公司在西单',relation='work')],34,['1500是整套还是合租预算及含费口径需核；不得擅自改为单间'],constraints=[C('离地铁站比较近的','近站要求，具体步行距离待核')])
Q('D0416','叙述空调烘干机电脑用电和费用，不是新房设施要求。',[T(FEE,'一个月三百多一天二十几','fact','current_home'),T(FAC,'还有烘干机每天都用，三台电脑','fact','current_home')])
Q('D0419','问老乡国庆是否回家，是社交闲聊，不是入住或约看。',times=[TM('国庆节','other')])
Q('D0422','叙述家里每月电费600多和用电设备，非找房诉求。',[T(FEE,'我家里一个月 600多电费','fact','current_home'),T(FAC,'一个空调24小时开，一个电磁炉','fact','current_home')])
Q('D0425','叙述两个月电费1100、单价1元，不能当预算或租期。',[T(FEE,'两个月1100块。 也是1元1度','fact','current_home')],times=[TM('两个月','other')])
Q('D0428','对单间与整租电价作解释，非本人住宅需求。',[T(FEE,'租单间都是一块钱一度 整租就是民用水电','fact','unresolved')])
Q('D0431','叙述上个月电费四百多，没有求租动作。',[T(FEE,'我上个月四百多','fact','current_home')],times=[TM('上个月','other')])
U('D0434','生活合租帖下问位置，有住房线索但正文未明确提供出租。',[T(LOC,'在哪里',subject='unresolved')],review=['是房源询租还是生活地点询问、房态未明'])
D('D0437','medium','即使正文是生活合租帖，主动问地址价格并问成都有无，已表达地区房源询问；租购与房态仍核。',[T(LOC,'地址'),T(PRICE,'价格'),T(LOC,'成都有吗')],[G('成都')],31,['所问是否可租房源、成都具体范围、价格房态待核；原帖杭州不覆盖本人目标'])
U('D0440','生活合租帖下问地址价格，保留住房兴趣但未明确出租或本人找房。',[T(LOC,'地址',subject='unresolved'),T(PRICE,'价格',subject='unresolved')],review=['所问房租与房态、是否本人求租待核'])
U('D0443','非明确出租的生活合租帖下询价，不能无证确定高意向。',[T(PRICE,'价格多少啊',subject='unresolved')],review=['是否房租询盘、本人需求和可租状态未明'])
D('D0446','high','房东租房帖下主动求滨江区推荐。',[T(LOC,'滨江区')],[G('滨江区')],31,['具体范围、预算房型及可承接房态待核'])
D('D0449','high','房东租房语境下问临平房源。',[T(LOC,'临平')],[G('临平')],31,['临平具体范围、预算房型未核'])
D('D0452','high','主动问短租还有没有，保留真实短租要求，不借正文补总时长。',[T(TIME,'短租','require'),T(STATUS,'还有吗')],[],19,['短租具体时长、起租日及门店接收政策待核'],times=[TM('短租','lease_duration')])
D('D0455','high','房东租房帖下询萧山房源，不因与他人相同文本而去掉本条。',[T(LOC,'萧山')],[G('萧山')],31,['具体位置、预算房型待核'])
D('D0458','high','询西湖文化广场附近房源。',[T(LOC,'西湖文化广场附近')],[G('西湖文化广场附近')],31,['预算、户型和附近距离要求未核'])
D('D0461','high','主动询文辉路附近房源，保留原文地名不静默改名。',[T(LOC,'文辉路附近')],[G('文辉路附近')],31,['道路准确名称、预算户型及房态待核'])
U('D0464','在租房避雷帖问福州水电正常费用，可能现居问题或找房了解；未明确本人当前求租。',[T(FEE,'福州租房水电费多少正常',subject='unresolved')],[G('福州',relation='unresolved')],['问收费常识还是新租条件、是否有当前找房动作待核'])
A('D0467','supply','unknown','unrelated','自述作为中介收取半月租中介费，并为行业辩解，是供给侧身份不是本人求租。',[T(FEE,'我们就是收你一个月房租的百分之50的中介费','fact','supply')],[],None,False,[],constraints=[C('别被黑中介坑了就把所有的中介都带入','为中介行业辩解，不是拒绝所有联系')],flags={'supply_side_identity':True})
D('D0470','high','明确需要福州仓山区单间；骗子别来只排斥诈骗不扩大为全部禁联。',[T(LOC,'福州仓山区','require'),T(HOME,'单间','require')],[G('福州仓山区')],34,['预算及单间房态未核；须核真实身份和房源'],boundaries=[{'quote':'骗子别来','scope':'拒绝诈骗接洽；不等于拒绝真实住户或全部联系'}],tone='serious')
D('D0473','high','明确要在福州租房，即使避雷帖也由本人完整语义建立需求。',[T(LOC,'在福州','require')],[G('福州','在福州')],31,['福州具体地区、预算户型待核'])
D('D0476','high','避雷帖下直接问烟台山房源，有本人区域找房动作。',[T(LOC,'烟台山'),T(STATUS,'有没有烟台山的房源')],[G('烟台山')],31,['烟台山具体范围、预算户型及有效房态待核'])
U('D0479','只说什么，避雷帖下没有可辨识的住房需求。',review=['所问对象和本人需求未知；不生成推介'])
D('D0482','high','明确精装出租房源下问水电收费，是当时询租条件。',[T(FEE,'水电咋算')],[],25,['同一房源水电现行计费与全部必付项待核'])
D('D0485','high','明确出租帖下问可否看房，通常高兴趣；未约时间不升超高。',[T(CONTACT,'可以看房吗')],[],28,['可看房态、时段及真实对接权限待核；尚无预约确认'])
D('D0488','high','明确出租帖下询位置，保留评论时兴趣。',[T(LOC,'在在什么位置')],[],31,['房源实际地址和客户接受地区待核'])
Q('D0491','建议除甲醛，是对博主房源的讨论，无本人新租要求。')
Q('D0494','想知道装修成本，非租金或找房预算询问。')
Q('D0497','建议博主换中介，非本人求中介或求租。')
Q('D0500','询视频有没有后续，未表达本人找房。')
U('D0503','仅艾特蛋挞大王，分享用途未知。',review=['纯艾特没有本人住房动作，不生成推介'])

# Only serialization and deterministic evidence/identity checks below.
assert len(source)==168 and len(decisions)==168, (len(source),len(decisions),set(by)-set(decisions))
assert set(decisions)==set(by)
for r in decisions.values():
    for t in r['time_mentions']:
        t['anchor_time']=datetime.fromtimestamp(by[r['review_key']]['published_at_unix'],timezone.utc).isoformat()
    s=by[r['review_key']]
    assert all(r[f]==s[f] for f in ['review_key','comment_id','customer_uid','video_id','platform'])
    quotes=r['evidence']+[v['quote'] for f in ['topics','target_regions','time_mentions','other_constraints','contact_boundaries'] for v in r[f]]
    assert all(q and q in s['comment_text'] for q in quotes),r['review_key']

rows=[decisions[s['review_key']] for s in source]
def dump(path,rs): path.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rs),encoding='utf8')
dump(P/'explicit-model-decisions.jsonl',rows)
dump(P/'reviewed-00.jsonl',rows)
dump(B/'reviewed-new-1.jsonl',rows)

# Isolated compile metadata uses actual semantic source and actual SHA. Root compiler
# will bind final sources; no independent semantic review is claimed here.
semantic_path=P/'isolated-semantic-source.jsonl'
compiled=copy.deepcopy(rows)
semantic_sha=hashlib.sha256((B/'reviewed-new-1.jsonl').read_bytes()).hexdigest()
for r in compiled:
    r['classification_method']='ai_semantic_initial_and_detailed'
    r['classification_stages_completed']=['initial_semantic','detailed_semantic']
    r['analysis_provenance']=[{'stage':'ai_semantic_initial_and_detailed','path':str(B/'reviewed-new-1.jsonl'),'sha256':semantic_sha}]
dump(semantic_path,compiled)
digest=hashlib.sha256(semantic_path.read_bytes()).hexdigest()
sys.path.insert(0,str(W))
from mother_adapter import validate_new_review
cache={}
for r in compiled:
    r['classification_review_source']={'path':str(semantic_path),'sha256':digest}
    validate_new_review(r,B,cache)
dump(P/'isolated-compiled-preflight.jsonl',compiled)
report={'input_count':len(source),'output_count':len(rows),'unique_review_keys':len(decisions),'all_key_cid_uid_video_platform_identities_match':True,'all_quotes_verbatim_in_own_comment':True,'adapter_validate_new_review_passed':len(compiled),'validation_scope':'shard-1 isolated preflight only; root final compiler still required','classification_stages':['initial_semantic','detailed_semantic'],'independent_semantic_review_claimed':False,'reviewed_new_sha256':semantic_sha,'isolated_semantic_source_sha256':digest,'role_counts':dict(Counter(r['role'] for r in rows)),'interest_counts':dict(Counter(r['interest'] for r in rows)),'source_modified':False,'platform_calls':0,'send_attempts':0,'human_confirmed_count':0,'send_authorized_count':0,'usage':'unknown; no new credit purchase','contact_policy_allow_is_permission':False}
(B/'shard-1-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(B/'shard-1-validation-report.md').write_text('shard-1 已逐条完成同轮模型语义初筛和细筛，共168条。\n\n168条原key、comment_id、customer_uid、video_id、platform一一匹配；所有证据逐字来自本人评论。既有mother_adapter.validate_new_review在本片真实SHA隔离源预检168条通过。正式编译绑定与root复核尚待进行，不声明独立二审或人工金标。\n\n保留购房用途、供给广告、工作地/居住目标区别、搬离后需求未知、短询上下文、时间角色和未知报价房态。只选择认可母句槽位，未重写正文；优惠、身份、报价、库存和政策均在missing_facts保留。全部未人工确认、未授权发送、未分配门店；allow仅说明没有明确文本禁联。\n\n未运行平台、未读取凭据、未修改源库或其他片、未发送；usage未知，未购买额度。\n',encoding='utf8')
(P/'progress.json').write_text(json.dumps({'status':'complete','completed_pages':['page-00.json'],'page_results':['reviewed-00.jsonl'],'explicit_decisions':168,'adapter_preflight_passed':168,'awaiting':'root review and final compiler'},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
