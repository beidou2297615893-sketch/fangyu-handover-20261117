from manage import *
changes={}
for k in ['D0954','D0966']:
 changes[k]=dict(role='demand',demand_state='active_at_comment',interest='high',reason='明确一室一厅招租正文下的短询保留实际询盘，数量指标仍作价格/面积候选，不能整条降未知。',needs_review=['需澄清所问为租价还是面积、当前是否仍在找房'],reply_plan=plan(1,True,['原问句计量对象及相应房源信息需核','通用介绍须核真实住户、介绍资格和同店优惠时效条件']))
changes['D0958']=dict(topics=[],possible_topics=[{'quote':'多少','candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'出租语境保留询盘，但省略计量指标，澄清前不作确定价格池'}],reason='询租身份和高兴趣可保留，裸多少计量指标需澄清，不确定归价格池。')
changes['D1027']=dict(role='demand',demand_state='active_at_comment',interest='unrelated',reason='本人以450万预算明确询购买住房，保留购房需求身份，不当住宅租赁。',reply_plan=plan())
changes['D1058']=dict(role='supply',reason='本人明确给失业租客免房租，出租方身份明确，非自己求租。')
changes['D1105']=dict(interest='medium',reason='本人表达毛坯偏好且称难找，保留具体住房探索；现阶段是否仍找需核，但不整条压成完全不确定。',needs_review=['是否正在找毛坯房、目标位置预算及当前进度待核'],reply_plan=first(1,3,'D1105')['reply_plan'])
save(1,3,'D0860 D0862 D0864 D0866 D0868 D0870 D0872 D0874 D0876 D0878 D0880 D0882 D0884 D0886 D0888 D0891 D0893 D1114 D1116 D1118 D1120 D1122 D0895 D0898 D0900 D0902 D0904 D0906 D0908 D0910 D0912 D0914 D0916 D0918 D0920 D0923 D0925 D0928 D0930 D0932 D0934 D0936 D0938 D0942 D0944 D0949 D0951 D0961 D0969 D0975 D0977 D0979 D0981 D0983 D0985 D0987 D0989 D0991 D0993 D0995 D0997 D0999 D1001 D1003 D1005 D1007 D1009 D1011 D1013 D1015 D1017 D1019 D1021 D1023 D1025 D1029 D1031 D1034 D1036 D1038 D1040 D1042 D1044 D1046 D1048 D1050 D1052 D1054 D1056 D1060 D1062 D1064 D1066 D1068 D1070 D1072 D1074 D1076 D1078 D1080 D1082 D1084 D1086 D1088 D1090 D1092 D1094 D1096 D1099 D1101 D1103 D1108 D1110 D1112',changes,'已逐条读完整正文及初判；原判识别住房探索、价位闲聊、退押纠纷、双用途歧义和停车约束可保留，未借别人条件、未将政策询问算约看。')
