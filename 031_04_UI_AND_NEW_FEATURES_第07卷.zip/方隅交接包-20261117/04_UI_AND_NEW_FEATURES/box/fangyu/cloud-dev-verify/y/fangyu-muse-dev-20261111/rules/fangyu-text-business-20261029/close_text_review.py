"""Keep human business documents consistent with the frozen text review scope."""
from pathlib import Path
import json,csv,re,hashlib
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=R/'outputs/方隅双平台文本业务'
def write(rel,text):(O/rel).write_text(text.strip()+'\n',encoding='utf8')
p=O/'筛选与分类规则/十个需求池与判读例表.csv';a=list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')));headers=list(a[0]);a=[x for x in a if x['子主题']!='本人需求结束']
with p.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(a)
write('筛选与分类规则/独立标记与十池区别.md','''# 独立标记与十池的区别

十个池只表达客户问了什么或需要什么。一条评论可以同时属于多个池。家庭、否定、供给身份、混合供需、需求结束、地区未明和时间未明都是独立标记，不另增池。

“我已经租到了”设置本人需求结束，不能为了有个分类而进入房源状态池；“已经租出去了吗”才可能是房态询问。“旧房转租，自己另找”分开保存两部分；仅因换房转租但未说新需求是否仍在，保留待核线索。

每个需求条件保留对象、连续原话、询问或硬要求、偏好、允许、排除、条件限制、事实背景或未知。“不需要宠物友好”不等于拒绝宠物；车位等暂未落在十池的条件另存其他约束，不丢失或强塞进房内设施。
''')
write('筛选与分类规则/流程完成度与问题清单.md','''# 筛选流程完成度与待办

更新：2026年10月29日收尾第二稿，待业务审核。本人要求先完成原文本任务，再继续新增分类；该顺序已记录，现不再接续新增分池。

|项目|已完成的文本工作|仍缺什么|
|---|---|---|
|全店目录与词库|13组旧词库保留，官网新增核到余杭和北京天璟；15组各200条候选；历史17条再次核源|尚未取得能证明本次25家范围的真实全店名册，不能称已齐全；跨店适用范围及实际效果待核|
|筛选流程|来源与去重、供需、地区与时态、多池、门店匹配、母句或疑难审核均已写出|软件和服务器实现另行处理；本窗口不据文字稿宣称已运行|
|属地|前一组1166条中1152条取得小红书平台属地，14条缺失；与目标地区分开|这是该固定批次观察，不证明所有入口或抖音字段完整；缺失不填不匹配|
|分级与时态|未来入住与现在找房分开；本人明确长租不因标题缺词丢掉；泛看房不自动超高|新稿待审核；第一稿结果保留，不能静默覆盖历史人工更正|
|十池和限制|准确十池、多标签、否定范围、偏好、条件性限制、供需混合及结束标记已统一|未知条件继续待核，不凭词面给人或门店下结论|
|母评论|50条完整候选及事实前提已出；10条认可措辞逐字保留；其余40条一次集中审看|事实承诺仍需同店同房资料；没有以50条数宣称覆盖全部评论|
|原200条核对|模型语义参考及独立模型审阅已做；又检查母句候选和阻断|样本已经暴露并用于找错，现是回归资料；不是第二稿独立测试、用户金标或准确率|
|员工反馈|建议选项、证据、指定审核人、发布与回退文本已出|员工个人建议不自动生效；系统实现另交代码窗口|
|新增批次|1166条已归档为第一稿模型初判；1384条只保留未合并初判|现暂停接续；未来按可用规则版本复核，再从真实未处理登记记录接续|
|联系与回执|草稿、提交、平台回执和未知状态已分开定义|只有执行窗口按实际授权处理；未知结果不重发|

优先顺序：收尾原词库和规则 → 集中审阅母评论及未决业务口径 → 核齐真实门店与必要事实 → 另冻结新样本验证 → 按明确版本复核旧初判并接续。不能用采集数量增加掩盖规则缺口。
''')
hist=(W/'stores/历史线索收尾核对.md').read_text(encoding='utf8').split('## 检索限制')[0]
write('门店词库/历史项目复核与真实门店缺口.md',hist+'\n\n以上是资料核对，未向项目方或门店对外联系。仍需本次业务真实全店名册，不能以历史记录补足25家。')
src={x['review_key']:x for x in map(json.loads,(W/'holdout-200-reviewed.jsonl').read_text(encoding='utf8').splitlines())}
checks=[json.loads(x) for x in (W/'mothers/回归200条母句承接核对.jsonl').read_text(encoding='utf8').splitlines()]
assert len(checks)==200 and {x['review_key'] for x in checks}==set(src)
assert all(x['source_text_sha256']==hashlib.sha256(src[x['review_key']]['text'].encode()).hexdigest() for x in checks)
assert all(x['sendable'] is False and x['send_authorized'] is False and x['customer_reply_generated'] is False for x in checks)
def clean(t):
 t=re.sub(r'https?://\S+','[链接已省略]',t or '')
 t=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[联系方式已省略]',t)
 return re.sub(r'@[\w\u4e00-\u9fff.]+','[提及账号已省略]',t)
lines=['# 200条回归资料的母评论承接核对','',
 '200条已暴露的原资料逐条检查候选及阻断；没有用户金标，不是第二稿独立测试，也不计算覆盖率。12条只列条件候选，188条未列候选；未生成客户回复，也未形成可直接发送的成品回复。候选不是事实成立或可联系资格。','',
 '其中99条供给、60条讨论、26条身份或需求待核，不套推介；14条本人线索与1条混合线索再核母句适配。现租金、现住房面积、旧房地点不变成新预算、面积下限或目标地区。','']
for x in checks:
 s=src[x['review_key']]
 lines+=['────────','原评论：'+clean(s['text']),'原模型参考判断：'+x['original_semantic_role'],
 '承接检查：'+clean(x['case_assessment']),
 '条件候选：'+('；'.join('母评论'+str(z['slot'])+'：'+z['scenario'] for z in x['candidate_templates']) or '先不选母评论'),
 '阻断或待核：'+'；'.join(clean(z) for z in x['blocking_or_needed_checks']),
 '状态：模型参考，尚未由业务审核人确认；未生成客户回复，未发送。','']
write('验收与逐批记录/200条回归资料的母评论承接检查.txt','\n'.join(lines))
write('验收与逐批记录/文本收尾状态.md','''# 原文本任务的收尾状态

还没有全部完成，不能将已有文件等同全店已齐或规则已验收。本人已要求先完成原任务再继续新增分类，现已暂停接续，未建立分类定时任务。

|任务|目前已交付|未完成部分|
|---|---|---|
|所有店搜索词|15个官网项目逐家有来源；各200条候选；旧词表保留；总表、分店表、顺序及历史线索分别整理|以25家为核对目标，尚缺能确认真实范围的全店名册；17条历史线索不能直接替代缺少的店；实际搜索效果未测|
|统一筛选和十池|收尾第二稿及难例边界已写出；时态、本人语义、身份、否定、地区与属地分开|业务审核及未暴露新样本验证尚未完成，不宣称运行准确率或节省模型比例|
|50条母评论|30条单需求、15条组合、5条语境；10条认可原句保留，40条候选集中看|新增40条尚未获本人认可，同店同房事实仍须补齐；50条不代表全部评论覆盖|
|原资料验收|200条模型语义参考及独立模型审阅、17条不足场景、200条母句承接检查|原200条已用于找错，不再当第二稿独立留出；没有用户金标或新分类器实测|
|新增评论分类|1166条已归档为第一稿模型初判；1384条只有待复核初判文件|现不继续分，未将1384条记为完成；后续登记输入保留，等原任务收尾和版本明确再接续|

现在可以集中审阅文本；不能说25家已经齐全、所有母句已认可、规则已在软件生效或可自动发送。门店名册缺口已交代码窗口只读核对，未要求开发软件或操作正在进行的采集。

后续另有一项待办：古北本次一万条实际登记采集完成后，用已有关键词覆盖、新增与重复、时间地区及需求质量、确已耗尽的结果评估还值不值得继续。现在只记录，未启动该评估或扩大采集。
''')
p=O/'先看这里.md';s=p.read_text(encoding='utf8');s='原文本任务尚未全部完成；当前状态以《验收与逐批记录/文本收尾状态.md》为准。本人要求先收尾原任务，再继续新增分类，现已暂停接续。\n\n'+s if not s.startswith('原文本任务尚未全部完成') else s
s=s.replace('对200条冻结样本完成当前模型语义参考核对，另经独立模型审阅并保留修订；它们不是用户金标准或平台总体随机样本。','对200条原样本完成模型语义参考核对、独立模型审阅和母句承接检查；这些资料已暴露并用于修订，现为回归资料，不是第二稿独立测试、用户金标准或平台总体随机样本。')
s=s.replace('本轮检查时第19批只有尝试及失败诊断，没有完整已登记新增回执，故未算新采集或伪造新批次。持续自动接收、服务器防重和断点由代码窗口实现；本次没有部署常驻监听。','此前第19批无完整新增回执，只按当时失败观察保留。后来第23至28批1166条完成第一稿模型初判；第29至38批1384条仅初判未合并。本人现要求先完成原文本任务，已暂停接续分类。后续登记输入保留；本窗口未部署常驻监听或分类定时任务。')
s=s.replace('今天未采集或发送。','本窗口未进行平台采集或发送。')
p.write_text(s,encoding='utf8')
p=O/'验收与逐批记录/逐批分析接续记录.md';s=p.read_text(encoding='utf8')
if not s.startswith('当前接续已暂停'):p.write_text('当前接续已暂停：按本人最新安排先完成原文本任务。1166条已归档初判，1384条尚未合并；现况见《新批次接收状态》。以下保留较早的接续观察，不代表现在没有新增输入。\n\n'+s,encoding='utf8')
(W/'text-closeout-validation.json').write_text(json.dumps({'regression_rows':200,'candidate_only':sum(bool(x['candidate_templates']) for x in checks),'customer_replies_generated':0,'sendable':0,'approved_template_texts_preserved':10,'new_classification_paused':True,'complete_store_directory_verified':False,'new_unexposed_accuracy_test_done':False},ensure_ascii=False,indent=2),encoding='utf8')
print('Business status, pool markers, historical sources and 200 mother applicability records exported; new classification remains held.')
