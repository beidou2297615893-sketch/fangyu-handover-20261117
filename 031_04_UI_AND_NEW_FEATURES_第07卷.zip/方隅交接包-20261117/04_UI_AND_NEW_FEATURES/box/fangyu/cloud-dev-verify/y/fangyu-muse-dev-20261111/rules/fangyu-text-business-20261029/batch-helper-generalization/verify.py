import json,hashlib,pathlib,subprocess,sys,shutil,os
root=pathlib.Path('work/fangyu-text-business-20261029').resolve()
test=root/'batch-helper-generalization'; old=root/'douyin-registered-v2/increments/097511857b51e174'; out=test/'old-run-output'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['semantic-final.jsonl','reviewed-0.jsonl','reviewed-1.jsonl','reviewed-2.jsonl']:
 a,b=sha(old/name),sha(out/name); assert a==b,(name,a,b);print('OLD_EQUAL',name,a)
# Build a small isolated frozen run from already reviewed primary rows, with no pilot/audit.
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
inputs=rows(old/'input.jsonl'); original={r['review_key']:r for r in inputs}
review=[r for i in range(3) for r in rows(old/f'reviewed-new-{i}.jsonl')][:12]
subset=[original[r['review_key']] for r in review]
packed=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in subset).encode('utf8'); digest=hashlib.sha256(packed).hexdigest(); run=digest[:16]
fixture=test/'fixture'; fixture.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'compile_reviewed_increment.py',fixture/'compile_reviewed_increment.py')
shutil.copy2(root/'mother_adapter.py',fixture/'mother_adapter.py')
b=fixture/'douyin-registered-v2/increments'/run;b.mkdir(parents=True,exist_ok=True)
(b/'input.jsonl').write_bytes(packed);(b/'manifest.json').write_text(json.dumps({'input_sha256':digest,'new_comments':len(subset)}),encoding='utf8')
for i in range(3):
 (b/f'shard-{i}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in subset[i::3]),encoding='utf8')
 (b/f'reviewed-new-{i}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in review[i::3]),encoding='utf8')
cmd=[sys.executable,str(fixture/'compile_reviewed_increment.py'),'--run',run]
(b/'quality-gate.json').unlink(missing_ok=True)
(b/'recall-audit-0.jsonl').unlink(missing_ok=True)
env={**os.environ,'PYTHONUTF8':'1'}
p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf8',env=env);assert p.returncode==0,(p.stdout,p.stderr)
final=rows(b/'semantic-final.jsonl');receipt=json.loads((b/'semantic-compile-receipt.json').read_text(encoding='utf8'))
assert len(final)==12 and receipt['independent_pilot_fine_complete']==0 and receipt['independent_recall_and_level_calibration_complete']==0
assert all(not r['independent_recall_reviewed'] and r['classification_stages_completed']==['initial_semantic','detailed_semantic'] for r in final)
print('NO_AUDIT_PASS',run,len(final))
# Gate requires audit data; verify a failed command does not alter preexisting semantic output.
before=sha(b/'semantic-final.jsonl');(b/'quality-gate.json').write_text(json.dumps({'independent_recall_calibration_queued':1}),encoding='utf8')
p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf8',env=env);assert p.returncode!=0 and 'requires both recall audit files' in p.stderr
assert sha(b/'semantic-final.jsonl')==before
print('REQUIRED_AUDIT_MISSING_REJECTED',before)

# One explicit audit is accepted without a gate; it adds evidence only for that key.
(b/'quality-gate.json').unlink()
audit={'review_key':review[0]['review_key'],'decision':'keep','patch':{},'reason':'fixture'}
(b/'recall-audit-0.jsonl').write_text(json.dumps(audit,ensure_ascii=False)+'\n',encoding='utf8')
audit_out=fixture/'audit-output'; audit_cmd=cmd+['--output-dir',str(audit_out)]
for _ in range(2):
 p=subprocess.run(audit_cmd,capture_output=True,text=True,encoding='utf8',env=env);assert p.returncode==0,(p.stdout,p.stderr)
audit_rows=rows(audit_out/'semantic-final.jsonl'); audited=[r for r in audit_rows if r['independent_recall_reviewed']]
assert len(audited)==1 and audited[0]['review_key']==audit['review_key']
assert audited[0]['analysis_provenance'][-1]['stage']=='independent_recall_calibration'
assert audited[0]['classification_stages_completed']==['initial_semantic','detailed_semantic']
assert json.loads((audit_out/'semantic-compile-receipt.json').read_text(encoding='utf8'))['independent_recall_and_level_calibration_complete']==1
print('OPTIONAL_AUDIT_PASS',sha(audit_out/'semantic-final.jsonl'))
