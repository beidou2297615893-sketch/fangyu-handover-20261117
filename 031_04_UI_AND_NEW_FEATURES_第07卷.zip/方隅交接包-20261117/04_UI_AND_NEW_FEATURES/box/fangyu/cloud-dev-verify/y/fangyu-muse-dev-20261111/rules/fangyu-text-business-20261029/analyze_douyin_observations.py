"""Review saved Douyin text observations; no platform, credentials or sends."""
import json,hashlib,collections,csv
from pathlib import Path
from datetime import datetime,timezone,timedelta
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=R/'work/fangyu-douyin-independent';D=W/'douyin-observations-v2';D.mkdir(exist_ok=True)
O=R/'outputs/方隅双平台文本业务/抖音逐店采集与意向';O.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def find_video(x,vid):
 if isinstance(x,dict):
  if str(x.get('aweme_id',x.get('video_id','')))==vid and 'desc' in x:return x
  for v in x.values():
   y=find_video(v,vid)
   if y:return y
 if isinstance(x,list):
  for v in x:
   y=find_video(v,vid)
   if y:return y
 return None
records=[];sources=[]
for pref in ['first','second','third','fourth']:
 rawp=B/f'{pref}-comments-raw.json';searchp=B/f'{pref}-search-raw.json';raw=load(rawp);video=find_video(load(searchp),str(raw['video']));assert video
 oldp=B/f'{pref}-analysis.json';old={x['comment_id']:x for x in load(oldp).get('records',[])} if oldp.exists() else {}
 author=str(video.get('author',{}).get('uid',''));batch=[]
 for c in raw['response']['comments']:
  cid=str(c['cid']);uid=str(c.get('user',{}).get('uid',''));t=c.get('text') or '';previous=old.get(cid)
  if previous:
   assert previous['comment_text']==t and previous['commenter_uid']==uid
   level={'高':'high','中':'medium','待核':'uncertain','不相关或已结束':'unrelated'}[previous['intent_at_comment']]
   role='demand' if level in ['high','medium'] else 'unknown' if level=='uncertain' else 'supply' if previous['speaker_role'].startswith(('供给','提供')) else 'discussion'
   topics=previous['demand_pools'][:];reason=previous['reason'];target=previous.get('target_region')
  else:
   role='unknown';level='uncertain';topics=[];reason='未有旧判，按保存的住宅出租正文核对。';target=None
   if t=='好像那边没，北大桥这边有':role='supply';level='unrelated';reason='向出租或找房语境补充北大桥供给信息，没有本人新求租证据。'
   elif t=='有押金吗':role='demand';level='high';topics=['费用合同'];reason='本人向明确住宅出租正文询问押金；原帖只付房租不构成已核费用事实。'
   elif t=='多大面积':role='demand';level='high';topics=['户型面积与居住方式'];reason='向明确住宅出租房源询问面积，是当时具体询盘；面积尚未提供。'
   elif t=='多少啊？':role='demand';level='high';topics=['价格预算'];reason='出租正文明确只需付房租，短问句可按该语境记租金询价；不当本人预算，金额未核。'
  flags=[];pending=[]
  if t=='租完了[捂脸]':role='unknown';level='uncertain';topics=[];reason='结束表达所指可能是本人租到或供应房已租出，对象不明，保留待核而非认定本人需求已结束。'
  if t=='一样求租':topics=[];reason+=' 本人没有复述具体地区条件，需求池留空，原帖上海只能作指代语境线索。'
  if '中介的朋友请绕道' in t:
   topics=[z for z in topics if z!='费用合同'];flags.append('本人拒绝中介身份，核实际联系身份是否符合；不机械删客，也不记作拒付中介费')
  if pref=='second':
   assert author and author==uid,'Same author must be verified before using body as own conditions'
   topics=[z for z in topics if z!='费用合同'] # Original post has no separate fee/contract condition.
  if author==uid and '中介朋友麻烦绕道' in video['desc']:flags.append('同一作者原帖拒中介；同人正文可解释该本人限制')
  if level=='uncertain':pending.append(reason)
  if c.get('reply_comment_total',0):pending.append('该一级评论下存在回复，尚未读取，不能声称深层语境完整')
  observed=datetime.fromisoformat(raw['at'].replace('Z','+00:00'));published=datetime.fromtimestamp(c['create_time'],timezone.utc)
  context_target='沙河地铁站（出租正文；城市未在正文明确）' if pref=='fourth' and role=='demand' else None
  x={'platform':'douyin','comment_id':cid,'customer_uid':uid,'video_id':str(c['aweme_id']),'comment_text':t,'published_at':published.astimezone(timezone(timedelta(hours=8))).isoformat(),
   'observed_at':raw['at'],'age_days_at_observation':round((observed-published).total_seconds()/86400,2),'source_store':raw['store'],'source_keyword':raw['keyword'],
   'registration_state':'observed_source_not_yet_verified_shared_ledger_registration','role':role,'interest_at_comment':level,
   'topics':topics,'topic_status':'本人需求主题' if role=='demand' else '待核话题' if role=='unknown' else '供给或讨论条件不作本人需求',
   'target_region_reference':target,'queried_property_region':context_target,'ip_location_raw':c.get('ip_label'),'ip_is_not_target_region':True,
   'post_body':video['desc'],'post_author_same_as_commenter':author==uid,'post_body_conditions_are_own':author==uid,
   'direct_parent_text':None,'reply_to':str(c.get('reply_id','0')),'deeper_reply_count_visible':c.get('reply_comment_total',0),'deeper_replies_read':False,
   'reason':reason,'evidence':[t] if t else [],'evidence_by_source':([{'source_kind':'own_comment','quote':t}] if t else [])+([{'source_kind':'verified_same_author_post','quote':video['desc']}] if author==uid else []),'context_flags':flags,'review_reasons':pending,'current_need_verified':False,'assigned_store':None,
   'store_match_status':'未核实；来源门店和IP不能直接作门店归属','rule_version':'business-text-20261029-v2','review_method':'模型语义复核既有初判及新增4条；证据与结构本地校验',
   'mother_reply_text':None,'reply_status':'仅分类；当前资料不足以指定门店或套用房源承诺','human_confirmed':False,'send_authorized':False,'send_attempted':False,
   'source_file':rawp.name,'source_sha256':digest(rawp),'search_file_sha256':digest(searchp)}
  batch.append(x);records.append(x)
 result=B/f'{pref}-text-screening-v2.jsonl';packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in batch);result.write_text(packed,encoding='utf8')
 receipt={'source_file':rawp.name,'source_sha256':digest(rawp),'search_sha256':digest(searchp),'result_file':result.name,'result_sha256':digest(result),'observed_comments':len(batch),'registration_verified':False,'source_files_modified':False,'sent':0}
 (B/f'{pref}-text-screening-receipt-v2.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8');sources.append(receipt)
assert len(records)==33 and len({x['comment_id'] for x in records})==33
assert all(all(q in x['comment_text'] for q in x['evidence']) for x in records)
(D/'all-observed-classifications.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records),encoding='utf8')
stores=collections.defaultdict(list)
for x in records:stores[x['source_store']].append(x)
summary={'observations':33,'unique_comment_ids_in_this_snapshot':33,'unique_customers':len({x['customer_uid'] for x in records}),'registered_new_comments_verified':0,
 'levels':dict(collections.Counter(x['interest_at_comment'] for x in records)),'by_origin_store':{},'source_receipts':sources,'platform_requests':0,'actual_sent':0,'full_deep_context_verified':False}
lines=['# 抖音首轮逐店评论与意向分析','',
'本轮只读首4批已保存原始记录，共33条评论观察，稳定评论标识在本快照内去重后仍为33条；尚未核实统一账本登记，不能当作已登记新增。门店来源仅是搜索入口，不代表客户属于该店。这是固定首轮快照，不是抖音当前实时累计；其他11店本快照未见原始评论，不等于它们从未采集。','',
'|搜索来源门店|评论观察|高|中|待核|供给或讨论|已确认适配本店|','|---|---:|---:|---:|---:|---:|---:|']
for store,xs in stores.items():
 count=collections.Counter(x['interest_at_comment'] for x in xs);summary['by_origin_store'][store]={'observations':len(xs),**dict(count),'store_match_verified':0}
 lines.append(f'|{store}|{len(xs)}|{count["high"]}|{count["medium"]}|{count["uncertain"]}|{count["unrelated"]}|0|')
lines+=['','高意向表示评论时本人租房或具体询盘，不等于今天仍有效。古北来源评论里有龙漕路、颛桥、杨浦、嘉定、虹口等不同目标，不能都归古北。江苏或河北属地也不能盖过本人上海求租。','',
'原帖作者与评论者已按平台标识区分。联航路那条评论是作者本人补充预算，可以引用其本人正文；杭州原帖作者求租与下面8位评论者分开统计，不把作者预算、户型和地点转给其他人。北京来源的沙河地铁站正文未明确城市，IP北京不能单独证明属于北京沙河店。','',
'只读取保存的文字和一级评论，未读视频画面、空文本附件或评论下面的回复；存在回复不代表已采全。没有重写既有草稿、没有平台采集或发送。母句待需求和门店适配核清后本地选择，不逐条生成新稿。','']
for x in records:
 lines+=['────────','来源门店：'+x['source_store'],'原评论：'+(x['comment_text'] or '文字为空，附件未核'),
 '评论时间：'+x['published_at'],'评论时意向：'+{'high':'高','medium':'中','uncertain':'待核','unrelated':'供给或讨论，无明确本人新需求'}[x['interest_at_comment']],
 '需求池：'+('、'.join(x['topics']) or '未确认具体本人需求池'),'依据：'+x['reason'],
 '目标地区线索：'+str(x['target_region_reference'] or x['queried_property_region'] or '本人目标地区未核'),
 '联系边界及待核：'+'；'.join(x['context_flags']+x['review_reasons']+['当前需求及门店适配未核，未发送']),'']
(O/'首轮33条评论与逐店意向.md').write_text('\n'.join(lines),encoding='utf8')
(D/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['source_receipts']},ensure_ascii=False))
