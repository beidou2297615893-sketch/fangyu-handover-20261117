import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent;src=p/'shard-0.jsonl';allrows=[json.loads(s) for s in src.read_text(encoding='utf-8-sig').splitlines()];assert len(allrows)==522;rows=allrows[:260]
ds={};ts={};rs={};os={};ms={};notes={};possible={};contexts={}
def mark(role,interest,numbers,reason,state=None):
 for n in map(int,numbers.split()):
  assert n not in ds,(n,ds.get(n));ds[n]=(role,interest,reason,state or ('active_at_comment' if role=='demand' and interest not in ('uncertain','unrelated') else 'unknown'))
def note(n,s):notes.setdefault(n,[]).append(s)
def topic(n,pool,q,pol='ask',subject='own_demand',scope='本人原话中的问题或条件'):
 ts.setdefault(n,[]).append(dict(pool=pool,quote=q,polarity=pol,subject=subject,condition_scope=scope,source='comment'))
def region(n,q,relation='desired',scope='本人明确提出的租住地区或范围',group='unknown'):
 rs.setdefault(n,[]).append(dict(text=q,quote=q,relation=relation,condition_scope=scope,group_relation=group,source='comment'))
def other(n,q,subject='own_demand',pol='require',scope='本人明确条件，不强塞十池'):
 os.setdefault(n,[]).append(dict(quote=q,subject=subject,polarity=pol,condition_scope=scope,source='comment'))
def moment(n,q,role,subject='own_demand'):
 ms.setdefault(n,[]).append(dict(quote=q,time_role=role,subject=subject,source='comment',normalized=None,verification='保留原词，未将相对时间锚定到今天或推断当前状态'))
for i in range(1,4):exec(compile((p/f'sub-a-part-{i}.py').read_text(encoding='utf-8'),str(p/f'sub-a-part-{i}.py'),'exec'))
valid={int(x['review_key'][1:]) for x in rows}
for x in (ds,ts,rs,os,ms,notes,possible,contexts):assert set(x)<=valid,('无效编号',set(x)-valid)
out=[]
for d in rows:
 n=int(d['review_key'][1:]);t=d['comment_text'] or '';gaps=list(notes.get(n,[]))
 if n in ds:role,interest,reason,state=ds[n]
 else:
  role='unknown';interest='uncertain';state='unknown'
  reason='评论为空，未读取画面，不能识别说话意图。' if not t else '本人短句所指对象、供需身份或当前租房目的未明确，须结合缺失上下文核对。'
  gaps.append(reason)
 if role=='unknown' and not gaps:gaps.append('本人供需角色、所指对象或当前需求仍需核实。')
 if role=='demand' and interest in ('high','medium','super_high'):gaps.append('评论时需求或询盘不等于当前仍在找；后续状态和实际承接条件未核实。')
 if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read'):gaps.append(f"有{d['deeper_reply_count_visible']}条可见深层回复未读取，不能推断后续结果。")
 if d.get('source_version_conflict'):gaps.append('来源版本存在冲突，需复核原始数据。')
 te=ts.get(n,[]);reg=rs.get(n,[]);tm=ms.get(n,[]);otherx=os.get(n,[])
 if role=='demand' and interest in ('high','medium','super_high'):
  if not any(x['relation'] in ('desired','preferred','accepted') for x in reg):gaps.append('本人租住目标地区未明确或仅提及参照地点；不能用来源门店或IP补全。')
  if not any(x['pool']=='价格预算' and x['polarity'] in ('require','prefer','accept') for x in te):gaps.append('本人预算未明确或仅询问他人报价，不能当成预算上限。')
 for e in te+reg+tm+otherx+possible.get(n,[]):assert e['quote'] in t,(n,e['quote'])
 for e in tm:e['anchor_source']='comment_published_at_unix' if d.get('published_at_unix') else 'unknown';e['anchor_time']=d.get('published_at_unix')
 evidence=[t] if t else [];es=[dict(source='comment',quote=t)] if t else []
 out.append(dict(review_key=d['review_key'],comment_id=d['comment_id'],customer_uid=d['customer_uid'],video_id=d['video_id'],published_at_unix=d.get('published_at_unix'),ip_location_raw=d.get('ip_location_raw'),role=role,demand_state=state,interest_at_comment=interest,topics=list(dict.fromkeys(x['pool'] for x in te if x['subject']=='own_demand')),topic_evidence=te,possible_topics=possible.get(n,[]),target_regions=reg,time_mentions=tm,other_constraints=otherx,reason=reason,evidence=evidence,evidence_sources=es,review_reasons=gaps,context_used=['comment']+(['post_body'] if n in contexts else []),media_context='未读取视频画面；文字叙述不是房源事实核验',reply_context='可见深层回复未读取' if d.get('deeper_reply_count_visible') and not d.get('deeper_replies_read') else '未读取深层回复',human_confirmed=False,current_need_verified=False,assigned_store=None,send_authorized=False))
assert len(out)==260 and len({x['review_key'] for x in out})==260
pool={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for r in out:assert set(r['topics'])<=pool and all(x['pool'] in pool for x in r['topic_evidence'])
for i in range(3):(p/f'reviewed-0-sub-a-part-{i+1}.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out[100*i:100*(i+1)]),encoding='utf-8')
(p/'reviewed-0-sub-a.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
print(json.dumps({'count':len(out),'role':dict(collections.Counter(x['role'] for x in out)),'interest':dict(collections.Counter(x['interest_at_comment'] for x in out))},ensure_ascii=False))
