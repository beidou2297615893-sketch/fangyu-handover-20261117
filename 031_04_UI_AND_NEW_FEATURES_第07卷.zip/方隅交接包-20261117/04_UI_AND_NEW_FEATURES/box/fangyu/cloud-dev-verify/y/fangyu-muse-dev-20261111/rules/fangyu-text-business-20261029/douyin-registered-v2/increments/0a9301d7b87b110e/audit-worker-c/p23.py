from decisions import *
r=original(23,'D6636')['target_regions']
for v in r[2:]:v['relation']='unresolved'
t=original(23,'D6633')['time_mentions'];t[0]['time_role']='other';t[0]['verification']='马上指实习工作开始，实际入住日未知；保留原发表锚'
emit(23,'''D6451 D6453 D6457 D6461 D6698 D6703 D6707 D6709 D6715 D6464 D6468 D6470 D6472 D6476 D6479 D6481 D6647 D6649 D6652 D6658 D6661 D6485 D6487 D6490 D6492 D6494 D6496 D6498 D6500 D6663 D6665 D6667 D6669 D6671 D6674 D6677 D6679 D6681 D6502 D6510 D6723 D6524 D6528 D6531 D6535 D6538 D6542 D6738 D6741 D6743 D6746 D6749 D6544 D6555 D6559 D6565 D6567 D6569 D6571 D6573 D6575 D6761 D6763 D6765 D6767 D6769 D6771 D6773 D6577 D6579 D6581 D6583 D6585 D6587 D6589 D6591 D6593 D6595 D6597 D6795 D6601 D6603 D6605 D6607 D6610 D6614 D6616 D6618 D6620 D6623 D6625 D6627 D6630 D6638 D6641 D6689 D6693 D6726 D6728 D6731 D6733 D6735 D6757 D6759 D6775 D6777 D6779 D6781 D6783 D6785 D6787 D6789 D6791 D6793''',{
'D6474':('租房d可能找搭子或招室友，没有明确独立求房动作，保留未知避免定高。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='杭州租房d片段及爱干净自述，供需与d指向待核',target_regions=[reg('杭州',relation='unresolved')],other_constraints=[dict(quote='爱干净',detail='本人习惯或对室友期望尚未分清，不能默认新房硬条件')],needs_review=['租房d是找搭子、招室友或求房联系待核；是否已持房未明'],reply_plan=plan())) ,
'D6654':('骆家庄怎么样是备选咨询，未确认接受；短租要记录时间原词。',dict(target_regions=[reg('骆家庄',relation='unresolved')],time_mentions=[dict(quote='短租',time_role='lease_duration',anchor_source='comment_published_at',anchor_time='2026-06-21T15:43:21+00:00',normalized=None,verification='明确短租，未给总时长')],needs_review=['骆家庄是否适合并接受、短租具体期限及当前找房状态待核'])) ,
'D6483':('大连有这种就好了为假设向往，不能确定已接受大连找房目标。',dict(target_regions=[reg('大连',relation='unresolved')])) ,
'D6612':('到九月底是租赁结束边界，应列租期而非泛other，起租未明不算总月数。',dict(time_mentions=[dict(quote='到九月底',time_role='lease_duration',anchor_source='comment_published_at',anchor_time='2026-07-13T17:38:17+00:00',normalized='2026-09月底',verification='租赁结束边界按发表年解释；起租和总时长未知')])) ,
'D6633':('马上是实习工作开始，不是已确定入住日。',dict(time_mentions=t)) ,
'D6636':('先前看过看丹大瓦窑不能等于本人已接受租住，保留当前换房主要求。',dict(target_regions=r,needs_review=['看丹和大瓦窑为以前看过的备选，是否仍接受或已排除待核']))
})
