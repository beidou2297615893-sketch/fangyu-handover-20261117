import pathlib,json,collections,hashlib,datetime
P=pathlib.Path(__file__).parent; ROOT=P.parent.parent
task=json.loads((P/'task.json').read_text('utf-8-sig'))
rows=[json.loads(l) for l in (ROOT/'recall-audit-1.jsonl').read_text('utf-8').splitlines()]
original={}; digests={}
for f in sorted(ROOT.glob('reviewed-new-*.jsonl')):
 digests[f.name]=hashlib.sha256(f.read_bytes()).hexdigest()
 for l in f.read_text('utf-8').splitlines():
  r=json.loads(l); original[r['review_key']]=r
comments={}; pages=[]
for f in sorted(P.glob('page-??.json')):
 j=json.loads(f.read_text('utf-8-sig'))
 keys=[]
 for g in j['post_groups']:
  for c in g['comments']:comments[c['key']]=c; keys.append(c['key'])
 decisions=[json.loads(l) for l in (P/(f.stem+'-decisions.jsonl')).read_text('utf-8').splitlines()]
 pages.append({'page':f.name,'input_count':len(keys),'output_count':len(decisions),'keys_equal':set(keys)=={x['review_key'] for x in decisions}})
allowed=set('role demand_state interest topics target_regions time_mentions other_constraints possible_topics evidence reason context_used needs_review human_confirmed send_authorized store_assignment reply_plan'.split())
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
errors=[]; inherited_errors=[]; quotes=collections.Counter(); transitions=collections.Counter(); effective=[]
for a in rows:
 k=a['review_key']; o=original[k]; text=comments[k]['text']; patch=a['patch']; r=o|patch; effective.append(r)
 if a['decision'] not in ('keep','change'): errors.append([k,'invalid decision'])
 if a['decision']=='keep' and patch:errors.append([k,'keep patch not empty'])
 if a['decision']=='change' and not patch:errors.append([k,'change patch empty'])
 if set(patch)-allowed:errors.append([k,'unknown fields',list(set(patch)-allowed)])
 if r.get('human_confirmed') is not False or r.get('send_authorized') is not False:errors.append([k,'authorization flags'])
 if r.get('store_assignment') is not None:errors.append([k,'store assigned'])
 if o['interest']!=r['interest']:transitions[o['interest']+' -> '+r['interest']]+=1
 for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics'):
  for item in r.get(field,[]):
   if not isinstance(item,dict):continue
   for sub in ('quote','condition_scope'):
    q=item.get(sub)
    if q is not None:
     quotes[field+'.'+sub]+=1
     if not isinstance(q,str) or q not in text:
      (errors if field in patch else inherited_errors).append([k,field,sub,q])
   if field=='topics' and item.get('pool') not in pools:errors.append([k,'invalid pool',item])
 for q in r.get('evidence',[]):
  quotes['evidence']+=1
  if q not in text:(errors if 'evidence' in patch else inherited_errors).append([k,'evidence',q])
 rp=r.get('reply_plan',{})
 if not {'preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy'}.issubset(rp):errors.append([k,'incomplete reply_plan'])
 if rp.get('contact_policy') not in ('allow','identity_restricted','no_contact','unknown'):errors.append([k,'contact enum'])
 if r['interest'] in ('uncertain','unrelated','very_low') and rp.get('generic_intro_suitable'):errors.append([k,'unknown/no need suitable'])
 if 'reply_plan' in patch and any(x in str(patch['reply_plan']) for x in ['宝宝，我住','介绍有优惠的。']):errors.append([k,'reply body in plan'])
keys=[r['review_key'] for r in rows]; expected=set(task['expected_review_keys'])
v={'validated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_count':len(expected),'input_count':len(comments),'output_count':len(rows),'unique_count':len(set(keys)),'id_sets_equal':set(keys)==expected==set(comments),'duplicate_keys':[k for k,c in collections.Counter(keys).items() if c>1],'keep_count':sum(r['decision']=='keep' for r in rows),'change_count':sum(r['decision']=='change' for r in rows),'page_checks':pages,'quote_checks':dict(quotes),'patch_errors':errors,'inherited_quote_errors':inherited_errors,'interest_transitions':dict(transitions),'effective_interest_distribution':dict(collections.Counter(r['interest'] for r in effective)),'source_primary_review_sha256':digests,'validation_scope':'Local completeness, identity, literal evidence, contract structure and specified consistency checks only; not model accuracy or human gold evaluation','platform_calls':0,'messages_sent':0,'source_files_written':False}
v['pass']=v['id_sets_equal'] and len(keys)==len(expected)==len(set(keys)) and all(p['keys_equal'] and p['input_count']==p['output_count'] for p in pages) and not errors and not inherited_errors
(P/'audit1-validation.json').write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(v,ensure_ascii=False,indent=2))
