import json,pathlib,sys,datetime
B=pathlib.Path(__file__).parent; root=B.parent.parent
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
STATES={'H':('demand','active_at_comment','high'),'M':('demand','active_at_comment','medium'),'V':('demand','active_at_comment','super_high'),'U':('unknown','unknown','uncertain'),'D':('demand','unknown','uncertain'),'X':('discussion','unknown','unrelated'),'S':('supply','unknown','unrelated'),'E':('demand','ended','unrelated'),'F':('demand','future','low'),'B':('mixed','active_at_comment','high'),'W':('mixed','unknown','uncertain')}
TASK=json.loads((B/'task.json').read_text(encoding='utf-8'))
MOTHERS={x['slot']:x for x in json.loads(pathlib.Path('work/fangyu-text-business-20261029/approved-mothers-model-view.json').read_text(encoding='utf-8'))}
def build(n):
 page=json.loads((B/f'page-{n:02}.json').read_text(encoding='utf-8')); src={c['key']:(p,c) for p in page['shared_post_context'] for c in p['comments']}
 metadata={r['review_key']:r for r in map(json.loads,(root/'shard-0.jsonl').read_text(encoding='utf-8').splitlines())}
 rows=[]; decisions=[]
 decision_file=B/f'decisions-{n:02}-corrected.txt'
 if not decision_file.exists():decision_file=B/f'decisions-{n:02}.txt'
 raw=decision_file.read_text(encoding='utf-8').splitlines(); expanded=[]
 for rawline in raw:
  if not rawline.strip():continue
  keys,rest=rawline.split('|',1)
  expanded.extend(k+'|'+rest for k in keys.split(','))
 for line in expanded:
  if not line.strip():continue
  z=[x.strip() for x in line.replace('||||1','|||1').split('|')]; key,code,reason=z[:3]; topics=json.loads(z[3]) if len(z)>3 and z[3] else []; regions=json.loads(z[4]) if len(z)>4 and z[4] else []; slot=int(z[5]) if len(z)>5 and z[5] and z[5]!='-' else None; extra=json.loads(z[6]) if len(z)>6 and z[6] else {}
  p,c=src[key]; m=metadata[key]; role,state,interest=STATES[code]; ownbody=p['post_body'] if c['same_author'] is True else ''; allowed=c['text']+'\n'+ownbody
  ts=[]
  for t in topics:
   if isinstance(t,int):t=[t,c['text']]
   q=t[1]; assert q in allowed,(key,q); ts.append(dict(pool=POOLS[t[0]-1],quote=q,polarity=t[2] if len(t)>2 else 'ask',subject=t[3] if len(t)>3 else ('unresolved' if code=='U' else 'own_demand'),condition_scope=t[4] if len(t)>4 else None))
  rs=[]
  for r in regions:
   if isinstance(r,str):r=[r]
   q=r[0];assert q in allowed,(key,q);rs.append(dict(text=q,quote=q,relation=r[1] if len(r)>1 else 'desired',group_relation=r[2] if len(r)>2 else 'unknown',condition_scope=r[3] if len(r)>3 else None))
  time=[]
  for t in extra.pop('times',[]):
   assert t[0] in allowed;(q,kind,*rest)=t;time.append(dict(quote=q,time_role=kind,anchor_source='comment_published_at',anchor_time=c['published_at'],normalized=rest[0] if rest else None,verification='原始发表时间可核；含相对表述时不以分析日为锚'))
  review=extra.pop('review',[])
  if code in ['U','D','W']: review.append(reason)
  if c['source_conflict']:review.append('来源版本冲突需核原文')
  caut=extra.pop('caution',[])
  if slot is not None:caut+=['母句方案待核事实；不代表已回答报价或其他具体条件','源帖房态、价格和设施不作为方隅房源事实']
  assert str(m['video_id'])==str(p['video']),key
  r={k:m[k] for k in ['review_key','platform','comment_id','customer_uid','video_id']};r.update(role=role,demand_state=state,interest=interest,topics=ts,target_regions=rs,time_mentions=time,other_constraints=extra.pop('other',[]),possible_topics=extra.pop('possible',[]),evidence=[c['text']] if c['text'] else [],reason=reason,context_used=['own','body']+(['parent'] if c['parent'] else []),needs_review=review,human_confirmed=False,send_authorized=False,store_assignment=None,reply_plan=dict(preferred_mother_slot=slot,generic_intro_suitable=extra.pop('generic',slot is not None),tone=extra.pop('tone','normal'),missing_facts=([MOTHERS[slot]['required_facts']] if slot else [])+extra.pop('missing',[]),caution=caut),contact_boundaries=extra.pop('contact',[]),context_flags=dict(same_author=c['same_author'],post_context_is_not_customer_condition=not c['same_author'],source_conflict=c['source_conflict'],relative_time_not_anchored_to_analysis_day=True),analysis_method='AI逐条语义初细筛合并判读；非独立二审或人工金标',analysis_page=n)
  r['reply_plan']['contact_policy']=extra.pop('contact_policy','allow')
  if r['reply_plan']['generic_intro_suitable']:
   r['reply_plan']['missing_facts'].append('通用推荐也须核真实住户身份、本人介绍资格及具体门店优惠的时效和适用条件；地区承接待核')
  r['published_at']=c['published_at'];r['rule_version']=m.get('rule_version','business-text-20261029-v2');r['source_comment_sha256']=m.get('source_comment_sha256')
  if ownbody:r['evidence'].append(ownbody)
  if slot:r['reply_plan']['missing_facts'].extend('具体条件/问句待核实答复：'+t['quote'] for t in ts)
  for cand in r['possible_topics']:
   if isinstance(cand,dict) and 'quote' not in cand:cand['quote']=c['text']
  r.update(extra);rows.append(r);decisions.append(dict(key=key,semantic_code=code,reason=reason,topics=topics,regions=regions,slot=slot,contact_policy=r['reply_plan']['contact_policy']))
 assert set(src)=={r['review_key'] for r in rows},(n,len(src),len(rows),set(src)-{r['review_key'] for r in rows})
 assert len(rows)==len(src)
 (B/f'reviewed-{n:02}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
 (B/f'semantic-decisions-{n:02}.json').write_text(json.dumps(decisions,ensure_ascii=False,indent=2),encoding='utf-8')
 pages=sorted(int(p.stem.split('-')[1]) for p in B.glob('reviewed-*.jsonl'))
 progress={'shard':0,'pages_completed':pages,'completed_count':sum(len(p.read_text(encoding='utf-8').splitlines()) for p in B.glob('reviewed-*.jsonl')),'expected_count':TASK['comments'],'updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'in_progress','method':'explicit_model_semantic_decisions'}
 (B/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(progress,ensure_ascii=False))
if __name__=='__main__':build(int(sys.argv[1]))
