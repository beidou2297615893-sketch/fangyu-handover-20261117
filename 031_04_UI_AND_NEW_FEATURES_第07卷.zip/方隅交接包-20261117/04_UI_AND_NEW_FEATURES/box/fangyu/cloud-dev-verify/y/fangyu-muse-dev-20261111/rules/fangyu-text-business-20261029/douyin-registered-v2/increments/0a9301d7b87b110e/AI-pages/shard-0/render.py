import json,sys,pathlib
base=pathlib.Path(__file__).parent
p=json.loads((base/f'page-{int(sys.argv[1]):02d}.json').read_text(encoding='utf-8'))
print('PAGE_METADATA',json.dumps({k:v for k,v in p.items() if k!='shared_post_context'},ensure_ascii=False))
for i,b in enumerate(p['shared_post_context']):
 print('POST',i,json.dumps({k:v for k,v in b.items() if k!='comments'},ensure_ascii=False))
 for c in b['comments']:
  print(c['key'],json.dumps(c['text'],ensure_ascii=False),c['published_at'],('OWNBODY' if c['same_author'] else ''),('PARENT='+json.dumps(c['parent'],ensure_ascii=False) if c['parent'] else ''),('CONFLICT' if c['source_conflict'] else ''),('REPLY='+c['reply_to'] if c['reply_to']!='0' else ''))
