import collections,hashlib,json
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;manifest=json.loads((p/'manifest.json').read_text(encoding='utf-8'))
def jlines(path):return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]
frozen=jlines(p/'frozen-input.jsonl');src={x['review_key']:x for x in frozen}
assert hashlib.sha256((p/'frozen-input.jsonl').read_bytes()).hexdigest()==manifest['frozen_input_sha256']
for path,h in manifest['rule_hashes'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h, '规则已变化，冻结样本需重新隔离'
records=[r for name in 'abc' for r in jlines(p/f'reviewed-{name}.jsonl')]
assert len(records)==200 and len({r['review_key'] for r in records})==200
assert {(x['review_key'],x['comment_id']) for x in records}=={(x['review_key'],x['comment_id']) for x in frozen}
allowed_pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for r in records:
 d=src[r['review_key']]; own=d['text']; assert r['customer_uid']==d['customer_uid']
 assert r['role'] in {'demand','supply','mixed','unknown','discussion'}
 assert r['demand_state'] in {'active_at_comment','future','ended','historical','unknown'}
 assert r['interest'] in {'super_high','high','medium','low','very_low','uncertain','unrelated'}
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 if r['role']=='unknown':assert r['interest']=='uncertain'
 for ev in r['evidence']:assert ev and ev in own,(r['review_key'],'evidence')
 for field in ['topics','target_regions','time_mentions','other_constraints','possible_topics']:
  for x in r[field]:
   if 'quote' in x:assert x['quote'] and x['quote'] in own,(r['review_key'],field)
   if field=='topics':
    assert x['pool'] in allowed_pools and x['polarity'] in {'ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'}
    assert x['subject'] in {'own_demand','supply','current_home','other_person','unresolved'}
   if field=='target_regions':assert x['relation'] in {'desired','preferred','accepted','excluded','work','current_home','offered','unresolved'}
 mom=r['mother_assessment'];assert mom.get('sendable',False) is False
 for c in mom.get('approved_candidates',[]):assert 1<=int(c['template_number'])<=10
 if mom.get('candidate_approved_mother'):assert 1<=int(mom['candidate_approved_mother'])<=10
 if r['demand_state']=='ended':assert r['role']=='demand' and r['interest']=='unrelated'
records.sort(key=lambda x:x['review_key'])
(p/'逐条判读结果.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records),encoding='utf-8')
counts=collections.Counter(r['role'] for r in records); interests=collections.Counter(r['interest'] for r in records)
topic_counts=collections.Counter(x['pool'] for r in records for x in r['topics'] if x['subject']=='own_demand')
topic_unresolved=collections.Counter(x['pool'] for r in records for x in r['topics'] if x['subject']=='unresolved')
conditions=sum(bool(r['mother_assessment'].get('approved_candidates')) or bool(r['mother_assessment'].get('candidate_approved_mother')) for r in records)
q={k:topic_counts[k] for k in sorted(allowed_pools)}
report={'rule_version':'business-text-20261029-v2','frozen_input_sha256':manifest['frozen_input_sha256'],'rule_hashes':manifest['rule_hashes'],'input_count':len(frozen),'output_count':len(records),'id_pairs_equal':True,'all_evidence_and_quote_strings_verbatim':True,'rule_unchanged_after_freeze':True,'no_unknown_as_unrelated':True,'approved_mother_candidates_1_to_10_only':True,'no_human_gold':True,'no_approved_send':True,'no_platform_request':True,'no_production_change':True,'role_counts':dict(counts),'interest_counts':dict(interests),'demand_topics_counts':q,'unresolved_topics_counts':dict(topic_unresolved),'uncertainty_records':sum(bool(r['needs_review']) for r in records),'conditional_approved_mother_candidates':conditions,'uncovered_demand_pools':[k for k in sorted(allowed_pools) if topic_counts[k]==0],'review_adjustments':['V034移除未认可的第19和34条母句，改为已认可第8条的条件候选','V005、V036、V046补充不确定对象的话题，保持待核','V088仅自称房东，不足以证明本人正在提供房源，保留待核'],'limitations':['100条常规加100条定向，不是平台整体随机样本','模型语义参考，无用户金标，不计算准确率或真实获客效果','未部署分类器，未实际测试发送或验证母句事实','仅评论原文及已保存可用语境，父子关系不明时未继承对方条件']}
(p/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
topic_md='、'.join(f'{k}{v}' for k,v in q.items() if v)
uncovered='、'.join(report['uncovered_demand_pools'])
human=f'''# 第二稿历史样本核对结果

筛选与分类规则第二稿已作为文本定稿供业务使用，效果未保证。按固定规则从既有历史资料中另选200条，完成逐条模型语义参考核对；这些结果不是本人逐条认可的金标准，也不代表软件已经安装、实际获客效果或可以发送。

样本包括100条固定顺序常规评论和100条定向难例，已排除此前200条、32条及22条难例、17条不足场景、57条历史补核和本轮新增采集评论。此样本不是平台总体随机样本，不计算准确率或召回率。

|模型初判|评论数|
|---|---:|
|提供或推荐房源、找房服务|{counts['supply']}|
|本人需求或有效询盘|{counts['demand']}|
|讨论、经历或无新的求租|{counts['discussion']}|
|供需身份或对象待核|{counts['unknown']}|
|供需混合|{counts['mixed']}|

本人需求中的话题记录为：{topic_md}。同一评论可涉及多个池，不能相加作人数；对象不明的询问单列待核，不作本人已确认条件。本样本未出现经初判可确认的本人需求正例的池包括：{uncovered}。这表示样本覆盖不足，不证明规则对这些池有效或无效。

{report['uncertainty_records']}条至少有一项具体待核说明；本人是否仍在找房、房源是否可承接、地区与事实应另行核实，不能由历史评论推成当前可回复名单。母句方面，{conditions}条仅列已认可母句的条件候选；是否适用仍须核对身份、房源、租期、优惠和本人需求。尚未认可的40条未当作可用母句；全部记录均没有发送授权。

逐条记录已核查输入输出一一对应，引用均能在本人评论中找到；冻结规则和输入的摘要已保存。针对审阅中发现的母句编号错误，已保留原判并改为已认可句的待核候选；其他不确定条件按待核保留。这些检查保证记录可追溯，不构成准确率或商业效果承诺。
'''
out=root/'outputs/方隅双平台文本业务/验收与逐批记录/第二稿200条历史样本核对.md';out.write_text(human,encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
