import json, pathlib, datetime, collections
P=pathlib.Path(__file__).parent
ROOT=P.parent.parent
TASK=json.loads((P/'task.json').read_text(encoding='utf-8-sig'))
SOURCE={x['review_key']:x for x in map(json.loads,pathlib.Path(TASK['source_full_metadata_file']).read_text(encoding='utf-8-sig').splitlines())}
POOLS=['价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系']
MOTHERS={x['slot']:x['required_facts'] for x in json.loads((ROOT.parents[2]/'approved-mothers-model-view.json').read_text(encoding='utf-8-sig'))}
def make(line):
    parts=line.split('|'); key=parts[0]; code=parts[1]; raw=SOURCE[key]; txt=raw['comment_text']
    a=code[0]; slot=int(code[1:]) if a in 'DMV' and code[1:] else (1 if a in 'DMV' else None)
    role={'X':'discussion','S':'supply','H':'demand','E':'demand','U':'unknown','D':'demand','M':'demand','V':'demand','F':'demand','W':'mixed','R':'discussion','B':'demand'}[a]
    state={'H':'historical','E':'ended','D':'active_at_comment','M':'unknown','V':'active_at_comment','F':'future','B':'active_at_comment'}.get(a,'unknown')
    interest={'D':'high','M':'medium','V':'super_high','U':'uncertain','W':'uncertain','F':'low'}.get(a,'unrelated')
    reason={'X':'对帖子内容作评论、建议或讨论，未表达本人或代理当前找房。','S':'在提供、转租房源或招租服务，未表达另找房需求。','H':'讲述本人过去租住经历，未表达新的找房动作。','E':'本人找房已结束，未表达新的找房需求。','U':'语义或主体不足，保留线索待核，不判为无关。','D':'本人在租房语境提出具体咨询或找房要求，按评论时有意向保留。','M':'本人提供找房线索或一般探索，推进程度尚待确认。','V':'本人对明确房源提出具体约看或推进请求，按评论时高推进意向保留。','F':'本人明确以后才开始找房，当前未推进。','W':'存在供给/退租动作，同时可能另找房，保留新需求待核。','R':'本人现住或退租问题，尚未明确另找房需求。','B':'明确其他住房交易需求，未表达住宅租赁。'}[a]
    out={k:raw[k] for k in ['review_key','comment_id','customer_uid','video_id']}
    out['platform']=raw['platform']
    out.update(role=role,demand_state=state,interest=interest,topics=[],target_regions=[],time_mentions=[],other_constraints=[],possible_topics=[],evidence=[txt] if txt else [],reason=reason,context_used=['own','body'],needs_review=[],human_confirmed=False,send_authorized=False,store_assignment=None,contact_boundaries=list(raw.get('contact_boundaries') or []),context_flags=list(raw.get('context_flags') or []))
    plan={'preferred_mother_slot':slot,'generic_intro_suitable':a in 'DMV','tone':'normal','missing_facts':[],'caution':[],'contact_policy':'allow' if a in 'DMVF' else 'unknown'}
    for p in parts[2:]:
        if not p: continue
        k,v=p.split('=',1)
        if k.isdigit():
            for q in v.split('~'):
                q=q.replace('[TILDE]','~')
                pol='ask';subject='unresolved' if a in 'UW' else 'own_demand'; scope=q
                if '::' in q:
                    meta,q=q.split('::',1); b=meta.split(',');pol=b[0];subject=b[1] if len(b)>1 else subject
                out['topics'].append(dict(pool=POOLS[int(k)-1],quote=q,polarity=pol,subject=subject,condition_scope=scope.split('::')[-1]))
        elif k=='r':
            for r in v.split('~'):
                rel,q=r.split(':',1); out['target_regions'].append(dict(text=q,quote=q,relation=rel,group_relation='unknown',condition_scope=q))
        elif k=='gr':
            for item in out['target_regions']:item['group_relation']=v
        elif k=='t':
            for t in v.split('~'):
                tr,q=t.split(':',1);ts=raw.get('published_at_unix');anchor=datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat() if ts else None
                out['time_mentions'].append(dict(quote=q,time_role=tr,anchor_source='published_at_unix' if ts else None,anchor_time=anchor,normalized=None,verification='保留原词；未将相对时间当作今日或确认日程'))
        elif k=='n':out['needs_review'].append(v)
        elif k=='o':out['other_constraints'].append({'quote':v,'subject':'own_demand','description':v})
        elif k=='p':out['possible_topics'].append({'quote':v,'candidate_pools':['价格预算','户型面积与居住方式'],'ambiguity':'原词计量含糊，须确认是租金、面积还是其他量；未计入确定需求池'})
        elif k=='why':out['reason']=v
        elif k=='c':plan['contact_policy']=v
        elif k=='b':out['contact_boundaries'].append(v)
        elif k=='flag':out['context_flags'].append(v)
        elif k=='serious':plan['tone']='serious';plan['caution'].append('涉及家庭/困境或严肃问题，去掉宝宝称呼')
        elif k=='g':plan['generic_intro_suitable']=v=='true'
        elif k=='m':plan['preferred_mother_slot']=int(v) if v!='null' else None
        elif k=='caution':plan['caution'].append(v)
        else:raise ValueError((key,k))
    if a=='U' and not out['needs_review']: out['needs_review'].append('本人当前是否找房及短句指代对象不明，需补问')
    if a=='W' and not out['needs_review']:out['needs_review'].append('转租/退租后的本人新住房是否已落实不明，需补问')
    if raw.get('direct_parent_text'):out['context_used'].append('parent')
    if raw.get('source_version_conflict'):out['context_flags'].append('source_version_conflict')
    if raw.get('post_author_same_as_commenter'):out['context_flags'].append('same_author_as_post')
    final_slot=plan['preferred_mother_slot']
    if final_slot:plan['missing_facts']=[MOTHERS[final_slot],'原帖房源价格、位置、设施不证明方隅同店同房源事实']
    if plan['tone']=='serious':plan['caution'].append('家庭或严肃场景先理解住房诉求；不使用亲昵称呼或轻浮推销')
    out['reply_plan']=plan
    return out
def run():
    outputs=[]; pages=[];errors=[]
    for f in sorted(P.glob('decisions-*.txt')):
        rows=[make(x) for x in f.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
        page=json.loads((P/('page-'+f.stem[-2:]+'.json')).read_text(encoding='utf-8-sig'))
        expected=[c['key'] for g in page['shared_post_context'] for c in g['comments']]
        if set(expected)!={r['review_key'] for r in rows} or len(expected)!=len(rows):errors.append(f'{f.name}:coverage')
        (P/(f.stem+'.jsonl')).write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows)+'\n',encoding='utf-8')
        outputs+=rows;pages.append(f.stem[-2:])
    for r in outputs:
        txt=SOURCE[r['review_key']]['comment_text']
        quotes=r['evidence']+[a['quote'] for name in ['topics','target_regions','time_mentions','other_constraints','possible_topics'] for a in r[name]]
        for q in quotes:
            if q not in txt:errors.append(r['review_key']+':quote:'+q)
    keys=[r['review_key'] for r in outputs]
    progress={'shard':2,'completed_pages':pages,'reviewed':len(outputs),'expected':TASK['comments'],'method':'每条由当前模型明确语义初筛和细筛同轮判断；本地脚本仅扩展结构和校验','errors':errors,'platform_calls':0,'send_authorized':False}
    (P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
    if len(outputs)==TASK['comments'] and not errors:
        expected=set(TASK['expected_review_keys'])
        if set(keys)!=expected or len(keys)!=len(set(keys)):errors.append('final_coverage')
        if not errors:(ROOT/'reviewed-new-2.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in outputs)+'\n',encoding='utf-8')
    print(json.dumps(progress,ensure_ascii=False))
if __name__=='__main__':run()
