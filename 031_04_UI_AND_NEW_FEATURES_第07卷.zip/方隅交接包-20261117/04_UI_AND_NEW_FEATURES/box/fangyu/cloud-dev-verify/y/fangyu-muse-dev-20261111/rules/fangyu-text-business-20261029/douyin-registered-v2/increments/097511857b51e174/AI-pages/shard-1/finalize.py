import importlib.util,json,pathlib,collections,datetime,hashlib
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('expander',HERE/'expand.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
task=json.loads((HERE/'task.json').read_text(encoding='utf-8'))
rows=[r for n in range(11) for r in m.expand(n)]
bykey={r['review_key']:r for r in rows};rows=[bykey[k] for k in task['expected_review_keys']]
check=m.validate(rows,task['expected_review_keys'])
check['comment_id_set_equal']=set(r['comment_id'] for r in rows)==set(m.src[k]['comment_id'] for k in task['expected_review_keys'])
check['identity_tuple_set_equal']=set((r['review_key'],r['comment_id'],r['customer_uid'],r['video_id']) for r in rows)==set((k,m.src[k]['comment_id'],m.src[k]['customer_uid'],m.src[k]['video_id']) for k in task['expected_review_keys'])
check['pilot_overlap_count']=len(set(r['comment_id'] for r in rows)&set(task['exclude_pilot_comment_ids']))
check['duplicate_comment_id_count']=len(rows)-len({r['comment_id'] for r in rows})
check['page_count']=11
check['page_counts']={f'{n:02}':len((HERE/f'reviewed-page-{n:02}.jsonl').read_text(encoding='utf-8').splitlines()) for n in range(11)}
check['enum_errors']=[]
for r in rows:
  k=r['review_key']
  enums={'role':['demand','supply','mixed','unknown','discussion'],'demand_state':['active_at_comment','future','ended','historical','unknown'],'interest':['super_high','high','medium','low','very_low','uncertain','unrelated']}
  for a,valid in enums.items():
    if r[a] not in valid:check['enum_errors'].append([k,a,r[a]])
  for t in r['topics']:
    if t['polarity'] not in ['ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown']:check['enum_errors'].append([k,'polarity'])
    if t['subject'] not in ['own_demand','supply','current_home','other_person','unresolved']:check['enum_errors'].append([k,'subject'])
  for t in r['target_regions']:
    if t['relation'] not in ['desired','preferred','accepted','excluded','work','current_home','offered','unresolved']:check['enum_errors'].append([k,'region_relation'])
    if t['group_relation'] not in ['AND','OR','unknown']:check['enum_errors'].append([k,'group_relation'])
  for t in r['time_mentions']:
    if t['time_role'] not in ['move_in','viewing','lease_duration','search_start','other']:check['enum_errors'].append([k,'time_role'])
  rp=r['reply_plan']
  if rp['preferred_mother_slot'] not in [None,1,2,7,13,16,19,25,28,31,34]:check['enum_errors'].append([k,'mother_slot'])
  if rp['contact_policy'] not in ['allow','identity_restricted','no_contact','unknown']:check['enum_errors'].append([k,'contact_policy'])
  if rp['tone'] not in ['normal','serious']:check['enum_errors'].append([k,'tone'])
  if not isinstance(rp['generic_intro_suitable'],bool):check['enum_errors'].append([k,'generic_intro_suitable'])
check['unknown_role_unrelated_count']=sum(r['role']=='unknown' and r['interest']=='unrelated' for r in rows)
check['non_demand_generic_intro_count']=sum(r['role'] in ['supply','discussion'] and r['reply_plan']['generic_intro_suitable'] for r in rows)
check['mother_counts']=dict(collections.Counter(str(r['reply_plan']['preferred_mother_slot']) for r in rows))
check['contact_policy_counts']=dict(collections.Counter(r['reply_plan']['contact_policy'] for r in rows))
check['topic_counts']=dict(collections.Counter(t['pool'] for r in rows for t in r['topics'] if t['subject']=='own_demand'))
check['potential_customers_with_possible_topics']=sum(bool(r['possible_topics']) for r in rows)
check['method']='逐条AI语义初筛与细筛在同一次结构化判读中完成；程序仅展开、合身份及验收，不是独立二审或人工金标'
assert len(rows)==1868 and check['key_set_equal'] and check['comment_id_set_equal'] and check['identity_tuple_set_equal']
assert not check['identity_and_verbatim_errors'] and not check['enum_errors'] and not check['pilot_overlap_count'] and not check['duplicate_comment_id_count']
assert not check['unknown_role_unrelated_count'] and not check['non_demand_generic_intro_count']
out=m.ROOT/'reviewed-new-1.jsonl';out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
check['output_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();check['status']='passed';check['validated_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(m.ROOT/'shard1-validation.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
progress=dict(shard=1,total=1868,completed_pages=list(range(11)),completed_comments=1868,status='complete',method='model_per_comment_initial_and_detailed_semantic_review',output=str(out),validation=str(m.ROOT/'shard1-validation.json'),updated_at=check['validated_at'])
(HERE/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
report='''# 抖音冻结增量第一分片判读结果

已完成1868条评论的逐条AI语义初筛、细筛与已认可母句方案选择。初筛和细筛在同一次结构化判读中完成，不是独立二审或人工金标。没有生成回复正文，没有平台采集、外部API或发送。

## 结果与范围

- 全部11页均保留逐条原决策和展开记录，页码为00至10；输入1868条，输出1868条，评论、用户、视频身份集合完全一致。
- 已完成试批的评论交集为0；没有覆盖试批、源库、软件、主指针或其他代理文件。
- 按评论时的找房动作判意向；目前是否仍找房需另核，不把历史评论当作今日需求确认。
- 需求、供给、混合或对象不明分开。已有住房招室友和离城转租不自动等同新求租；含不确定新需求的保留待核。
- 多条件、地区关系、否定方向、时间、车位等约束保留。没有将帖子房型、宠物、价格、来源店或IP地址继承为本人要求；“多少米”保留价格与面积歧义。
- 保障住房申请、学历资格、排队和政策入口未写成商业房源余量、约看或入住；适配未知具体留核。

## 意向分布

'''+ '\n'.join('- '+k+'：'+str(v)+'条' for k,v in check['interest_counts'].items())+'''

## 母句与联系边界

只选择已认可母句编号并记录所缺事实，不交付待发回复。通用介绍可作为推荐优惠接话，不代表已经回答具体房态、报价、宠物、户型或费用。专池句需核实同店同房源事实，不能以来源帖子替方隅背书。严肃家庭及维权情境标记严肃语气，成句需去掉“宝宝”等称呼。

contact_policy的allow只表示评论没有提出联系限制，不等于授权发送；房东直租或拒中介等身份要求独立保留；片段或渠道限制标明未知及具体边界。所有记录human_confirmed=false、send_authorized=false、store_assignment=null。

## 验证

输入输出覆盖、唯一性、身份元组、试批排除、逐字证据和引用、十池与枚举、母句编号、联系策略枚举均通过。验收脚本只做确定性检查，未采用关键词、正则或统一默认无关来代替语义判断。原决策逐条可核对。尚无人工内容验收或商业效果验证。
'''
(m.ROOT/'shard1-review-report.md').write_text(report,encoding='utf-8')
print(json.dumps({k:check[k] for k in ['status','input_count','output_count','key_set_equal','identity_tuple_set_equal','pilot_overlap_count','interest_counts','contact_policy_counts','output_sha256']},ensure_ascii=False))
