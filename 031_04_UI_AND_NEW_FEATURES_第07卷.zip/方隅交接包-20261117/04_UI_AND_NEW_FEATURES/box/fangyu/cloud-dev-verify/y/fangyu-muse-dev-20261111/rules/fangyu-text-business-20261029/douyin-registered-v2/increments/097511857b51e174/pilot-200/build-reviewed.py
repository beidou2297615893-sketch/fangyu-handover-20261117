from pathlib import Path
import json,collections
base=Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/097511857b51e174/pilot-200')
a=json.loads((base/'grouped-model-input.json').read_text(encoding='utf-8'))
comments={c['key']:(c,g) for g in a['shared_post_context'] for c in g['comments']}
ident={x['review_key']:x for x in (json.loads(s) for s in (base/'input.jsonl').read_text(encoding='utf-8').splitlines())}
names={'P':'价格预算','L':'位置通勤','H':'户型面积与居住方式','T':'入住与租期','S':'房源状态','C':'费用合同','V':'看房联系','R':'位置通勤'}
regions={26:[('川沙','offered','unknown'),('华夏东路地铁','offered','unknown')],40:[('嘉定13号金运路14号嘉怡路到封浜','offered','unknown')],48:[('13号线张江路','unresolved','unknown')],51:[('西城','desired','OR'),('4号线','desired','OR')],55:[('东坝','desired','unknown')],59:[('地大附近','desired','unknown')],60:[('培黎职业学院附近','desired','unknown')],61:[('嘉捷科技园附近','desired','unknown')],62:[('10号线','desired','OR'),('12号线','desired','OR')],63:[('关庄地铁站附近','desired','unknown')],65:[('中关村','work','unknown')],66:[('五棵松附近','desired','unknown')],67:[('航天城','desired','unknown')],68:[('通州万达附近','desired','unknown')],86:[('武侯区','desired','unknown')],87:[('锦江区','unresolved','unknown')],88:[('武侯区','unresolved','unknown')],100:[('成都','desired','unknown')],152:[('福州','unresolved','unknown')],155:[('晋安区','desired','unknown')],157:[('福州','unresolved','unknown')],158:[('高新区','unresolved','unknown')],161:[('晋安区鼓山镇','desired','unknown')],167:[('浦东','current_home','unknown')],173:[('闵行区','unresolved','unknown')]}
times={65:[('一个月','lease_duration','P1M')],72:[],137:[('每个月几号几点','other',None)],138:[],141:[('几点','other',None)],180:[('两年','other',None)],181:[('好久','other',None)],184:[('一年','lease_duration','P1Y'),('每月','other',None)],185:[('月租','lease_duration',None)],186:[('一个月','other',None)],189:[('20天','lease_duration','P20D')],191:[('一个🈷️','other',None)],196:[('一个月','other',None)],199:[('8月','move_in','2026-08')]}
rows=[]
for raw in (base/'decisions.tsv').read_text(encoding='utf-8').splitlines():
 n,role,state,interest,codes,reason,review=raw.split('|'); n=int(n); key=f'D{n:04}'
 c,g=comments[key]; item=ident[key]; text=c['text']; topics=[]
 for code in ([] if codes=='-' else codes.split(',')):
  subject='own_demand'
  if code.startswith('s'): subject='supply'; code=code[1:]
  elif code.startswith('u'): subject='unresolved'; code=code[1:]
  polarity='ask' if subject=='own_demand' else ('fact' if subject=='supply' else 'unknown')
  if n==72 and code=='H': polarity='accept'
  if n==65 and code=='T': polarity='require'
  if n==155 and code in ('H','P'): polarity='require'
  topics.append({'pool':names[code],'quote':text,'polarity':polarity,'subject':subject,'condition_scope': text if n in (65,72,155,184,189,199) else None})
 if n==72:
  topics.append({'pool':'户型面积与居住方式','quote':'整租','polarity':'require','subject':'own_demand','condition_scope':None})
 poss=[]
 if n in (16,23,74,78,83,192):
  poss=[{'pool':'价格预算','ambiguity':'可能询问价格，尚未明确'}, {'pool':'户型面积与居住方式','ambiguity':'可能询问面积，尚未明确'}]
 t=[]
 for quote,role_t,norm in times.get(n,[]):
  assert quote in text,(key,quote)
  t.append({'quote':quote,'time_role':role_t,'anchor_source':'comment_published_at','anchor_time':c['published_at'],'normalized':norm,'verification':'月份依据评论发表时间推定，具体日期待核' if n==199 else ('时间指向或具体时间待核' if norm is None else '时长来自评论原文')})
 reg=[]
 for quote,rel,group in regions.get(n,[]):
  assert quote in text,(key,quote)
  reg.append({'text':quote,'quote':quote,'relation':rel,'group_relation':group,'condition_scope':None})
 boundaries=[]
 if n==117: boundaries=[{'quote':'其他事情不要联系我','scope':'房东对托管平台其他事项的联系限制'}]
 row={'review_key':key,'comment_id':item['comment_id'],'customer_uid':item['customer_uid'],'video_id':item['video_id'],'role':role,'demand_state':state,'interest':interest,'topics':topics,'target_regions':reg,'time_mentions':t,'other_constraints':[],'possible_topics':poss,'evidence':[text] if text else [],'reason':reason,'context_used':['own','body'] if codes!='-' or n in (5,38,64,73,87,88,90,91,93,94,95,98,100,102,103,104,136,138,139,140,142,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,173,175,180,181,182,188) else ['own'],'needs_review':review.split('；') if review else [],'contact_boundaries':boundaries,'context_flags':[],'human_confirmed':False,'send_authorized':False,'store_assignment':None}
 if n==175:
  row.update(role='unknown',demand_state='unknown',interest='uncertain',reason='便宜房源抢不到可能是个人经历，也可能是泛泛评价',needs_review=['核实是否本人正在找房'])
  row['topics']=[{'pool':'房源状态','quote':text,'polarity':'unknown','subject':'unresolved','condition_scope':None}]
 rows.append(row)
assert len(rows)==len(comments)==len(ident)==200
assert len({r['review_key'] for r in rows})==200 and {r['review_key'] for r in rows}==set(ident)
for r in rows:
 s=comments[r['review_key']][0]['text']
 for v in r['evidence']+[x['quote'] for k in ('topics','target_regions','time_mentions','contact_boundaries') for x in r[k]]: assert v and v in s,(r['review_key'],v)
 assert r['role'] in ('demand','supply','mixed','unknown','discussion')
 assert r['demand_state'] in ('active_at_comment','future','ended','historical','unknown')
 assert r['interest'] in ('super_high','high','medium','low','very_low','uncertain','unrelated')
 for x in r['topics']:
  assert x['pool'] in names.values() and x['polarity'] in ('ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown') and x['subject'] in ('own_demand','supply','current_home','other_person','unresolved')
 for x in r['target_regions']: assert x['relation'] in ('desired','preferred','accepted','excluded','work','current_home','offered','unresolved') and x['group_relation'] in ('AND','OR','unknown')
 for x in r['time_mentions']: assert x['time_role'] in ('move_in','viewing','lease_duration','search_start','other')
(base/'reviewed.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
counts=collections.Counter(x['interest'] for x in rows)
roles=collections.Counter(x['role'] for x in rows)
validation={'input_count':len(ident),'output_count':len(rows),'review_key_set_equal':{x['review_key'] for x in rows}==set(ident),'comment_id_set_equal':{x['comment_id'] for x in rows}=={x['comment_id'] for x in ident.values()},'identities_match':all(all(x[k]==ident[x['review_key']][k] for k in ('comment_id','customer_uid','video_id')) for x in rows),'quotes_verbatim':'passed: evidence, topics, target_regions, time_mentions, contact_boundaries','enum_validation':'passed: role, demand_state, interest, topic pool/polarity/subject, region relation/group_relation, time_role','all_fixed_fields_valid':all(not x['human_confirmed'] and not x['send_authorized'] and x['store_assignment'] is None for x in rows),'interest_counts':dict(counts),'role_counts':dict(roles),'records_needing_review':sum(bool(x['needs_review']) for x in rows),'scope':'仅本地200条；未改源库或软件、未采集、未发送、未运行publish或改主结果指针、未创建冻结批','method':'同一次模型逐条语义判读，非两次独立审核或人工金标'}
(base/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
reason_counts=collections.Counter(reason for x in rows for reason in x['needs_review'])
report=['# 200条评论试筛记录','','对200条评论逐条进行一次结构化语义判读，结合所属帖文理解，但不把他人正文条件当成评论者自身条件。','', '意向等级：'+ '；'.join(f'{k} {counts.get(k,0)}条' for k in ('super_high','high','medium','low','very_low','uncertain','unrelated'))+'。',f'需核记录：{sum(bool(x["needs_review"]) for x in rows)}条，原因可能同时出现。','','待核原因：']
report += [f'- {k}：{v}条' for k,v in reason_counts.most_common()]
report += ['','地区、入住时间、租期及联系限制按原文记录。高意向只说明评论时的兴趣，不能证明现在仍在找房或适配任何具体门店。','', '核验：输入输出均200条；键及评论ID集合一致；身份对应、引用逐字及字段枚举通过。此次是模型初筛与细筛合并的一次判断，不是独立复核或人工金标；所有记录未人工确认、未授权发送。未运行采集、发布或发送，未修改源库与软件，也未修改主结果指针或创建冻结批。']
(base/'review-report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False,indent=2))
