from decisions import *
r=original(21,'D5884')['target_regions'];r[0]['relation']='unresolved';r[0]['condition_scope']='周六周日上课地点，不是工作地'
ts=original(21,'D6101')['topics']
for t in ts:t['subject']='unresolved'
emit(21,'''D5848 D5850 D5852 D5854 D5856 D6007 D6009 D6011 D6013 D6015 D6017 D6019 D6021 D6023 D6025 D5858 D5861 D5863 D5866 D5868 D5872 D5875 D5877 D6028 D6030 D6033 D6035 D6038 D6040 D6042 D6044 D5879 D5882 D5886 D5888 D5890 D5893 D5895 D5897 D5900 D5903 D5906 D5908 D5914 D6047 D6049 D6052 D6055 D6059 D6061 D6064 D5916 D5918 D5920 D5922 D5924 D5926 D5928 D5930 D5932 D5934 D6087 D6089 D6091 D6093 D6095 D6097 D6099 D6103 D6105 D5936 D5939 D5941 D5945 D5947 D5949 D5951 D5956 D5958 D5963 D5968 D6066 D6068 D6073 D6075 D6077 D6079 D6083 D6085 D5970 D5973 D5975 D5977 D5981 D5983 D5985 D5987 D5992 D5994 D6134 D6137 D5997 D5999 D6001 D6003 D6005 D6107 D6109 D6111 D6113 D6115 D6117 D6119 D6121 D6125 D6128 D6131''',{
'D5884':('中关村是周末上课地点，不能标工作；仍保留双地点通勤联立。',dict(target_regions=r,needs_review=['周末中关村上课、平日朝阳工作需分别核通勤，当前找房是否仍有效待核'])) ,
'D6057':('找次卧合租室友未明确自己已有空房，不确定供给身份，保留共同找房可能。',dict(role='unknown',demand_state='unknown',interest='uncertain',reason='在梨园找次卧合租伙伴并询渠道，已持房供给或共同找房未明',topics=[topic('户型面积与居住方式','找次卧合租室友',subject='unresolved'),topic('看房联系','一般都去哪找室友呀',subject='unresolved')],target_regions=[reg('梨园',relation='unresolved')],needs_review=['本人是否已持房招次卧室友，还是本人需要次卧并共同找房待核'],reply_plan=plan())) ,
'D6101':('艾特加冒号可能引用别人询价，不能将被引用条件确认成本人需求。',dict(role='unknown',demand_state='unknown',interest='uncertain',topics=ts,reason='地址价格询问带引用格式，本人是否同需待核',needs_review=['@一只哈密瓜冒号格式可能为引用；本人是否也求租待核'],reply_plan=plan()))
})
