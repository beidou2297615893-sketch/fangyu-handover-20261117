from decisions import *
a=original(16,'D4442')
emit(16,'''D4422 D4425 D4427 D4429 D4432 D4434 D4436 D4445 D4448 D4661 D4664 D4666 D4668 D4670 D4674 D4677 D4679 D4451 D4453 D4455 D4457 D4459 D4461 D4463 D4465 D4467 D4469 D4681 D4683 D4685 D4687 D4689 D4691 D4471 D4473 D4475 D4477 D4479 D4481 D4483 D4486 D4488 D4490 D4492 D4494 D4496 D4498 D4500 D4502 D4504 D4506 D4508 D4510 D4512 D4514 D4516 D4518 D4525 D4530 D4532 D4538 D4540 D4542 D4544 D4546 D4548 D4550 D4552 D4555 D4557 D4559 D4561 D4563 D4565 D4567 D4569 D4571 D4573 D4575 D4577 D4579 D4581 D4583 D4585 D4587 D4589 D4591 D4593 D4595 D4597 D4599 D4601 D4603 D4605 D4607 D4609 D4611 D4613 D4615 D4617 D4619 D4621 D4625 D4633 D4635 D4637 D4639 D4641 D4643 D4646 D4648 D4651 D4653 D4657 D4659''',{
'D4440':('三天是驿站给的准住限制，不是本人希望租三天；不能选对应三天可住母句。',dict(topics=[topic('入住与租期','只让我租三天','fact','current_home')],reply_plan=plan(),reason='本人询驿站仅准住三天的原因，实际所需期限与替代住房意愿待核')),
'D4442':('安静相处是合住相处偏好，不是房内设备；保留本人习惯自述。',dict(topics=a['topics'][:1],other_constraints=a['other_constraints']+[dict(quote='安静相处',detail='希望安静和睦合住，不代表某项房内设施')])),
'D4623':('短租询盘应补租期原词，具体时长未明不能补一月。',dict(time_mentions=[dict(quote='短租',time_role='lease_duration',anchor_source='comment_published_at',anchor_time='2026-08-23T10:21:25+00:00',normalized=None,verification='询短租可否，未给总时长和起止')])) ,
'D4627':('北京是询原帖房屋所在城市，不能直接确认客户接受北京目标。',dict(target_regions=[reg('北京',relation='unresolved')],needs_review=['询原帖所属区域，是否本人求租并接受北京待核'])),
'D4630':('俸伯地铁是被问距离的参照，不能直接当接受居住区域。',dict(target_regions=[reg('顺义俸伯地铁',relation='unresolved')],needs_review=['所问房源到俸伯地铁的距离及本人真实租房计划待核']))
})
