import json,pathlib,collections
p=pathlib.Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/060636ba95252f65')
rows=[json.loads(s) for s in (p/'shard-1.jsonl').open(encoding='utf8')];by={int(d['review_key'][1:]):d for d in rows};out={}
def ids(s):return [int(x) for x in s.split()]
def group(s,role,interest,reason,needs=None):
 for n in ids(s):
  d=by[n];out[n]={'review_key':d['review_key'],'comment_id':d['comment_id'],'customer_uid':d['customer_uid'],'video_id':d['video_id'],'role':role,'interest_at_comment':interest,'topics':[],'topic_evidence':[],'target_regions':[],'reason':reason,'evidence':[d['comment_text']] if d['comment_text'] else [],'review_reasons':list(needs or []),'other_constraints':[],'possible_topics':[],'current_need_verified':False,'assigned_store':None,'send_authorized':False}
group('5 8 11 14 26 29 38 41 50 53 86 95 110 113 116 119 122 128 140 146 161 164 167 170 176 200 203 209 215 221 236 239 257 260 263 266 272 275','demand','high','本人提出找房、找合租或询问具体出租信息，代表发表时意向。',['当前需求和房源状态尚未核实。'])
group('17 74 152 185 254 311','supply','unrelated','本人明确提供、推荐或转租住房，未见本人另找住房的明确要求。')
group('20','mixed','uncertain','本人转租并称要换房；新住处是否已确定、是否仍在寻找尚不清楚。',['旧房的位置、租金和设施属于供给，不能转作新求租条件。'])
group('23 32 35 62 68 80 89 98 101 107 158 191 194 197 227 248 269 290 296 299 302 308','discussion','unrelated','评论是经历、建议、评价或其他话题，未明确本人新的住宅找房需求。')
group('2 44 47 56 59 65 71 77 83 92 104 125 131 134 137 143 149 155 173 179 182 188 206 212 218 230 233 242 245 251 278 281 284 287 293 305','unknown','uncertain','现有评论和上下文不足以确认说话对象、供需身份或本人租房需求。',['核对直接回复对象或原帖内容后再判断。'])
# Case-specific contextual uncertainty; no blanket inherited other-person requirements.
for n in (44,47,56,218):out[n]['reason']='评论只问“多少”，在可租房语境中具体指租金、面积或其他数量不明。';out[n]['review_reasons']=['“多少”的计量对象需核对，不将原帖价格当成本人预算。']
for n in (59,125,188,287):out[n]['reason']='评论为空、仅表情或单独数字，无法确认本人住宅需求。';out[n]['review_reasons']=['核对完整评论及直接上下文；不从发布者正文继承需求。']
for n in (65,77,206):out[n]['reason']='询问他人的需求或找房状态，无法确认说话人是提供房源还是有本人求租。';out[n]['review_reasons']=['核对供需身份和直接对话。']
for n in (2,71,242,305):out[n]['reason']='提及合租或找室友，但无法分清已有房找室友还是本人寻租。';out[n]['review_reasons']=['核对是否已有房源及本人是招租还是寻找合租住房。']
out[83]['reason']='询问两室一厅，但正文是租房价格攻略，无法确认本人是否当前找房。';out[83]['review_reasons']=['核对问的是一般行情还是本人具体求租。']
out[92]['reason']='列举曹路房屋条件并评价预算内难找，可能是本人找房也可能是对行情的评论。';out[92]['review_reasons']=['核对条件是否为本人当前需求；不得把现地曹路直接当目标。']
out[104]['reason']='要求看对方已经租住的房子，原帖为居住经验，未明确房源可出租或本人求租。';out[104]['review_reasons']=['核对是想看房屋展示还是寻找可租房。']
for n in (131,134,137,143,281,284):out[n]['reason']='在已有住户的生活展示下询问地点或类似房源，正文未给出当前可出租房源，不能确定本人当前租赁意图。';out[n]['review_reasons']=['核对本人是否正在找房及具体询问对象；不把原帖房屋条件当作本人要求。']
out[149]['reason']='仅列几个杭州地名，可能是在给求租者推荐或陈述自己需求，方向不明。';out[149]['review_reasons']=['核对这些地点属于推荐、工作地还是本人目标。']
out[155]['reason']='“我有”可能表示提供房源，但未明确具体对象或本人身份。';out[155]['review_reasons']=['核对是否有可出租住宅。']
out[173]['reason']='明确询问可办营业执照和开工作室的空间，住宅居住需求与用途不明。';out[173]['review_reasons']=['先核对工作室是否需居住及本项目是否承接此类用途。']
out[179]['reason']='询问月费用，但正文是具体房屋介绍和生活标签，未明确该房当前可出租。';out[179]['review_reasons']=['核对是否为实际可租房源及问价用途。']
out[182]['reason']='只有到期日期，未说明是本人现有租约、房源还是其他对象。';out[182]['review_reasons']=['核对到期对象、年份及是否有新找房需求。']
out[212]['reason']='询问男生是否可以，可能为本人、他人或供应方，不能由性别条件推定供需。';out[212]['review_reasons']=['核对实际对象和是否希望合租。']
out[230]['reason']='提到某地有复式，但未明确是本人房源、推荐还是讨论。';out[230]['review_reasons']=['核对房源对象及评论者身份。']
out[233]['reason']='索取表格，可能是研究资料而非本人当前租房。';out[233]['review_reasons']=['核对是否同时有本人找房需求。']
out[245]['reason']='“根本遇不到”缺少对话对象和具体指代，不能推定正在找房。';out[245]['review_reasons']=['核对所指事项及是否本人需求。']
out[251]['reason']='“我也想”缺少具体对象，不能将视频作者的条件视为本人条件。';out[251]['review_reasons']=['核对想要什么及是否在找房。']
out[278]['reason']='称自己有90多平，但是否供出租或只是经历介绍不明。';out[278]['review_reasons']=['核对交易意向和房源状态。']
out[293]['reason']='单字“求”在求租帖下可能是求房，也可能求其他信息，无法确认本人需求。';out[293]['review_reasons']=['核对具体所求及直接对象，不继承发帖人的预算。']
out[173]['possible_topics'].append({'pool':'费用合同','quote':'可以办营业执照的','reason':'经营用途需核对，并非住宅租赁合同要求。'})
# Explicitly classify the topic and quote only own comment, preserving conditions.
def topic(n,pool,q,polarity='ask',subject='own_demand',scope=None):
 assert q in by[n]['comment_text'],(n,q);d=out[n];d['topics'].append(pool) if pool not in d['topics'] else None;d['topic_evidence'].append({'pool':pool,'quote':q,'polarity':polarity,'subject':subject,'source_kind':'own_comment','condition_scope':scope})
def reg(n,q,relation='desired',group='unknown',scope=None):
 assert q in by[n]['comment_text'],(n,q);out[n]['target_regions'].append({'text':q,'quote':q,'relation':relation,'group_relation':group,'condition_scope':scope})
def possibility(n,pools,q,why):
 assert q in by[n]['comment_text'];out[n]['possible_topics'].append({'pools':pools,'quote':q,'reason':why,'subject':'unresolved'})
# Housing availability, district preferences, and living arrangements.
for n,q in {5:'定边路地铁站附近',8:'宝山',11:'普陀区',14:'金桥这边',38:'闵行',41:'北新泾',110:'常营，东坝，黄渠，东夏园',113:'朝阳区中国人寿大厦附近',119:'石景山',122:'朝阳区',140:'30号线或者5号线附近',146:'萧山建设路',161:'拱墅区',167:'拱墅区大关地铁站附近',200:'长宁区',209:'拼多多附近的',215:'大润发附近',260:'顾村这边',263:'松江租房九亭',272:'北京',275:'沙河'}.items():reg(n,q,scope='目标地点来自本人评论；具体城市或边界有歧义时待核')
for n in (5,8,11,14,38,41,86,110,113,116,119,122,140,146,161,167,200,203,209,215,260,263,272,275):
 topic(n,'位置通勤',by[n]['comment_text'],'require' if n in (11,122,140,161,200,203,209,275) else 'ask',scope='仅保留本人评论表述，地点不得由视频或IP补全')
for n in (5,8,14,38,41,50,53,110,113,116,119,146,167,170,176,215,236,257,263,272):topic(n,'房源状态',by[n]['comment_text'],'ask')
for n in (26,29,116,161,164,170,176,200,203,236,239,275):topic(n,'户型面积与居住方式',by[n]['comment_text'],'require' if n in (26,29,161,200,203,236,239,275) else 'ask')
for n in (38,95,164,221,236,260):topic(n,'价格预算',by[n]['comment_text'],'prefer' if n in (38,260) else ('require' if n==236 else 'ask'),scope='上下限按原文；问价不等于预算')
for n in (119,215,236):topic(n,'房内设施',by[n]['comment_text'],'require' if n in (119,236) else 'ask',scope='具体设施依本人原文')
topic(128,'入住与租期','短租一个月可以吗','ask',scope='询问一个月短租，不代表对方已同意')
topic(128,'位置通勤','在哪个区','ask')
topic(122,'入住与租期','周六周日上课过来住2-3天','require',scope='仅保留每次居住2–3天，合同租期未说明')
topic(122,'入住与租期','最近就需要','require',scope='近期需求，无可靠日期不假定入住具体日')
topic(140,'位置通勤','通勤一个小时以内','require',scope='通勤目的地未写明')
topic(257,'看房联系','可以看房吗','ask',scope='泛问看房，不是预约或确认')
topic(266,'位置通勤','哪','ask',scope='询问该房位置，不推定目标地区')
topic(275,'入住与租期','长期稳定合租','require')
topic(239,'位置通勤','徐汇','require',scope='本人评论提出的地区；正文与评论为同一作者')
topic(26,'看房联系','有没有女生一起合租','ask')
# Preferences and contextual details that do not fit existing ten pools.
out[26]['other_constraints']=[{'quote':'希望对方爱干净','polarity':'prefer','subject':'other_person','condition_scope':'对室友卫生习惯的偏好'},{'quote':'双方都不要把陌生人带回家','polarity':'require','subject':'own_demand','condition_scope':'双方共同遵守'}]
out[122]['other_constraints']=[{'quote':'能停车最好','polarity':'prefer','subject':'own_demand','condition_scope':'停车为偏好，不是硬要求'}]
out[275]['other_constraints']=[{'quote':'要00后长期稳定合租的室友','polarity':'require','subject':'other_person','condition_scope':'本人室友要求'},{'quote':'尽量来男的','polarity':'prefer','subject':'other_person','condition_scope':'男室友为倾向'}]
out[200]['other_constraints']=[{'quote':'男女不限','polarity':'accept','subject':'other_person','condition_scope':'室友性别不限'}]
# Explicit unknown facts, preserved as candidate themes only, not confirmed pools.
for n in (44,47,56,218):possibility(n,['价格预算','户型面积与居住方式'],'多少','数量对象不明，需明确是价格、面积或其他。')
for n in (131,134,137,143,281,284):possibility(n,['位置通勤'],by[n]['comment_text'],'地点相关询问，但当前求租身份及交易用途未确认。')
possibility(83,['户型面积与居住方式'],'两室一厅','可能询一般行情或本人需要，未确认。')
possibility(92,['价格预算','户型面积与居住方式','房内设施','宠物'],by[92]['comment_text'],'本人是否在求租、列举要求是否为本人条件未确认。')
for n in (2,71,242,305):possibility(n,['户型面积与居住方式'],by[n]['comment_text'],'合租可能为寻找房源或已有房招室友。')
possibility(179,['价格预算'],'多少钱一个月','生活展示语境，房源可租状态及本人需求未知。')
# Supply geography is separate from target regions.
for n,q in {17:'浦东新区秀沿路',20:'杨浦延吉东路长白三村小区',74:'奉贤',152:'西湖区西溪路639号',254:'虹桥地铁站🚉附近',311:'彭埠东站'}.items():reg(n,q,'offered',scope='供应或推荐地点，不是本人目标地区')
out[203]['review_reasons'].append('“这附近”具体所指待核；不可把视频中的地点当作本人已确认目标。')
out[209]['review_reasons'].append('拼多多地点可能指多个办公地点，需核具体城市和位置。')
out[110]['review_reasons'].append('列出多个地点，互为替代还是有其他要求需核实。')
out[140]['review_reasons'].append('通勤目的地及具体线路所在地待核；原视频不能证明其目标城市。')
out[122]['review_reasons'].append('原文存在编码缺失，不擅自修复；停车是偏好。')
out[239]['reason']='本人评论明确寻找徐汇合租，且与视频作者相同；只采用本人评论的地区条件。'
# Generic price-guide questions without a clearly offered dwelling do not establish present demand.
for n in (86,164,170,176):
 d=out[n];d['role']='unknown';d['interest_at_comment']='uncertain';d['reason']='在租房行情攻略下提出一般性问题，未明确本人当前找房或具体可租房源。';d['review_reasons']=['核对是询一般行情还是本人实际求租，以及对象。']
 for t in d['topic_evidence']:t['subject']='unresolved'
 d['possible_topics']=[{'pools':list(d['topics']),'quote':by[n]['comment_text'],'subject':'unresolved','reason':'主题可辨，但本人需求与具体对象未确认。'}]
 d['topics']=[];d['topic_evidence']=[];d['target_regions']=[]
reg(29,'上海',scope='本人近期想去上海并询问合租，入住或出行日期未说明')
reg(95,'九号线合川路',scope='本人询问该站周边整租价格；具体城市待核')
reg(116,'八号线，十八号线',scope='线路所在城市及两线是否为替代选择需核')
reg(239,'徐汇',scope='本人评论明确求徐汇合租')
reg(203,'这附近','unresolved',scope='本人表达附近租房但未说明所指地点，不能继承视频地点')
# Distinct alternative transit lines remain alternatives, not simultaneous constraints.
out[140]['target_regions']=[]
reg(140,'30号线','desired','OR',scope='地铁线及通勤目的地待核')
reg(140,'5号线附近','desired','OR',scope='与30号线是替代选择')
topic(95,'位置通勤','九号线合川路','ask')
topic(95,'户型面积与居住方式','整租','ask',scope='询问整租行情，是否为硬要求待核')
topic(161,'价格预算','预算充足','fact',scope='没有说明具体金额，不能估算')
out[122]['possible_topics'].append({'pools':['户型面积与居住方式'],'quote':'不��要太大','subject':'unresolved','reason':'字符损坏，面积表述不能擅自补字。'})
# Review objects expected by caller. Context is interpretive; no copied parent requirements.
for n in by:
 if n not in out:group(str(n),'unknown','uncertain','评论对象或本人需求无法从现有内容确定。',['核对完整上下文及供需身份。'])
result=[out[n] for n in sorted(out)]; errors=[];allowed={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for x in result:
 d=by[int(x['review_key'][1:])]; own=d['comment_text']
 if (x['comment_id'],x['customer_uid'],x['video_id'])!=(d['comment_id'],d['customer_uid'],d['video_id']):errors.append([x['review_key'],'identity'])
 for q in x['evidence']+[t['quote'] for t in x['topic_evidence']]+[t['quote'] for t in x['target_regions']]+[t['quote'] for t in x['other_constraints']]+[t['quote'] for t in x['possible_topics']]:
  if q not in own:errors.append([x['review_key'],'quote'])
 if any(t not in allowed for t in x['topics']):errors.append([x['review_key'],'pool'])
 if x['role']=='unknown' and x['interest_at_comment']!='uncertain':errors.append([x['review_key'],'role consistency'])
 if x['role']=='supply' and x['topics']:errors.append([x['review_key'],'supply topic'])
 if x['assigned_store'] is not None or x['send_authorized'] or x['current_need_verified']:errors.append([x['review_key'],'authorization'])
ins={(x['review_key'],x['comment_id']) for x in rows};outs={(x['review_key'],x['comment_id']) for x in result}
with (p/'reviewed-1.jsonl').open('w',encoding='utf8',newline='\n') as f:
 for x in result:f.write(json.dumps(x,ensure_ascii=False)+'\n')
report={'input_count':len(rows),'output_count':len(result),'input_unique_count':len(ins),'output_unique_count':len(outs),'id_sets_equal':ins==outs,'all_quotes_in_own_comment':not errors,'validation_errors':errors,'role_counts':dict(collections.Counter(x['role'] for x in result)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in result)),'empty_comment_count':sum(not d['comment_text'] for d in rows),'independent_human_gold':False,'send_authorized':False,'limits':'逐条模型语义初判；数量、枚举与逐字证据校验不等于准确率或当前需求核实。'}
(p/'validation-1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
