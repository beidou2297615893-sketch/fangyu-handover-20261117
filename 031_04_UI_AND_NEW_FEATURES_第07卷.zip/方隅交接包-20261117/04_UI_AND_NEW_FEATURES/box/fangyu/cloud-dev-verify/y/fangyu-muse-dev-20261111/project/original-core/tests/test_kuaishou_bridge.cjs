const assert=require('node:assert/strict');const {once}=require('node:events');const {createBridge}=require('../work/runtime/kuaishou-bridge/server');
(async()=>{const token='a'.repeat(48),b=createBridge({host:'127.0.0.1',token},{timeoutMs:250,ttlMs:90000});b.server.listen(0,'127.0.0.1');await once(b.server,'listening');const base='http://127.0.0.1:'+b.server.address().port;
async function call(path,body,auth=true){const r=await fetch(base+path,{method:body?'POST':'GET',headers:{...(auth?{Authorization:'Bearer '+token}:{}),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});return {code:r.status,data:await r.json()};}
try{
 assert.equal((await call('/api/status',null,false)).code,401);
 assert.equal((await call('/api/connect',{site:'kuaishou.com',url:'https://evil.invalid/'})).code,400);
 const connect=()=>call('/api/connect',{site:'kuaishou.com',url:'https://www.kuaishou.com/short-video/test123',title:'模拟页'});
 const a=(await connect()).data.connectionId,c=(await connect()).data.connectionId;
 assert.equal((await call('/api/collect',{connId:'missing',photoId:'test123',maxPages:1})).code,409);
 assert.equal((await call('/api/poll?connectionId='+a)).data.action,'wait');
 assert.equal((await call('/api/collect',{connId:a,photoId:'test123',maxPages:11})).code,400);
 const promise=call('/api/collect',{connId:a,photoId:'test123',maxPages:1});
 let job;for(let i=0;i<20;i++){job=(await call('/api/poll?connectionId='+a)).data;if(job.requestId)break;await new Promise(r=>setTimeout(r,5));}
 assert.equal((await call('/api/result',{requestId:job.requestId,connectionId:c,ok:true,value:{comments:[]}})).code,403);
 assert.equal((await call('/api/result',{requestId:job.requestId,connectionId:a,ok:true,value:{comments:[],pagesFetched:1}})).code,200);
 assert.equal((await promise).data.value.pagesFetched,1);
 const expired=await call('/api/collect',{connId:a,photoId:'test123',maxPages:1});assert.equal(expired.code,504);assert.equal((await call('/api/poll?connectionId='+a)).data.action,'wait');
 assert.equal(b.pending.size,0);console.log('PASS: auth, site allowlist, strict connection, pagination, result binding, timeout cancellation; local mock only');
}finally{b.close();b.server.closeAllConnections();}
})().catch(e=>{console.error(e);process.exitCode=1;});
