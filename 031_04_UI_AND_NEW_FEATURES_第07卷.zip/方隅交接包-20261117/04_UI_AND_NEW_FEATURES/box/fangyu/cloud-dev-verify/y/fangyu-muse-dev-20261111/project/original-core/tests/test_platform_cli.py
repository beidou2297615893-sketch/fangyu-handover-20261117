import importlib.util,os,tempfile,unittest
from pathlib import Path
from unittest.mock import Mock,patch
spec=importlib.util.spec_from_file_location('platform_cli',Path(__file__).resolve().parents[1]/'src/platform_cli.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class PlatformCliTest(unittest.TestCase):
 def test_synthetic_qr_png(self):
  from PIL import Image
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'nested/qr.png'
   with patch.dict(os.environ,{'WORKSPACE_QR_PATH':str(path)}):self.assertTrue(module.display_qr('synthetic-local-test'))
   with Image.open(path) as img:self.assertEqual(img.format,'PNG');self.assertGreater(img.width,100);img.verify()
 def test_http_forced_even_if_caller_requests_browser(self):
  login=Mock(return_value={'ok':True})
  module.http_only_login(login)(prefer_browser_assisted=True,timeout_s=20)
  login.assert_called_once_with(prefer_browser_assisted=False,timeout_s=20)
if __name__=='__main__':unittest.main()
