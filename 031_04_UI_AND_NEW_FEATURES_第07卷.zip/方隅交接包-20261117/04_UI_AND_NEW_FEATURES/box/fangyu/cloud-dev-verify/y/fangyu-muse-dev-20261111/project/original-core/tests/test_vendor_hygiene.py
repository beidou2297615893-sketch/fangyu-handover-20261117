"""Static distribution boundaries; never start a browser/Bridge or read account data."""
import json,re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VENDOR=ROOT/'work/runtime/douyin-bridge'
class VendorHygiene(unittest.TestCase):
 def test_no_customer_state(self):
  for name in ('config.json','logs','storage','data','outputs'):
   self.assertFalse((VENDOR/name).exists(),name)
 def test_template_empty_token_new_port(self):
  js=(VENDOR/'scripts/douyin.user.js').read_text(encoding='utf-8-sig')
  block=js.split('const CONFIG = {',1)[1].split('};',1)[0]
  self.assertRegex(block,r"token:\s*''")
  self.assertIn('127.0.0.1:19432',block)
 def test_no_old_project_identifiers(self):
  paths=list((VENDOR/'lib').rglob('*.js'))+list((VENDOR/'scripts').rglob('*.js'))+[VENDOR/'cli.js',VENDOR/'server.js']
  for p in paths:
   txt=p.read_text(encoding='utf-8-sig')
   for needle in ('19422','灵感心理','南风心理','喵的心理','满月塔罗','rmsama','OPENAI_API_KEY'):
    self.assertNotIn(needle,txt,str(p.relative_to(VENDOR)))
 def test_config_isolation(self):
  for name in ('cli.js','server.js','lib/risk-control.js'):
   self.assertIn('process.env.DOUYIN_CONFIG',(VENDOR/name).read_text(encoding='utf-8-sig'))
 def test_only_approved_commands(self):
  txt=(VENDOR/'lib/commands/index.js').read_text(encoding='utf-8-sig')
  self.assertEqual(set(re.findall(r"require\('./([^']+)'\)",txt)),{'search','get','replies','post'})
  self.assertFalse((VENDOR/'lib/llm.js').exists())
  self.assertFalse((VENDOR/'lib/reply-engine/index.js').exists())
 def test_help_no_removed_features(self):
  txt=(VENDOR/'cli.js').read_text(encoding='utf-8-sig').split('function printHelp()',1)[1].split('async function main',1)[0]
  for name in ('campaign','suggest','draft','analyze','LLM'):
   self.assertNotIn(name,txt)
if __name__=='__main__':unittest.main()
