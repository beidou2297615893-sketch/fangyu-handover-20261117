import json,pathlib,copy,hashlib,sys,collections
from read import B,W
P=B/'recall-audit/part-1'
def plan(slot=None,generic=False,tone='normal',facts=None,contact='allow'):
 return dict(preferred_mother_slot=slot,generic_intro_suitable=generic,tone=tone,missing_facts=facts or [],caution=['仅为母句适配，不表示已核房源事实或获得发送授权'] if slot else [],contact_policy=contact)
def topic(pool,quote,polarity='ask',subject='own_demand',scope=None):return dict(pool=pool,quote=quote,polarity=polarity,subject=subject,condition_scope=scope)
def reg(text,quote=None,relation='desired',group='unknown',scope=None):return dict(text=text,quote=quote or text,relation=relation,group_relation=group,condition_scope=scope)
def load(n):
 x=json.loads((P/f'page-{n:02}.json').read_text(encoding='utf-8'));return {c['key']:(g,c) for g in x['post_groups'] for c in g['comments']}
def emit(n,keeps,changes):
 rows=load(n); ids=keeps.split(); assert len(set(ids))==len(ids);assert not set(ids)&set(changes);assert set(ids)|set(changes)==set(rows),(n,set(rows)-set(ids)-set(changes),set(ids)-set(rows))
 out=[]
 for key in rows:
  if key in changes:
   why,patch=changes[key]; out.append(dict(review_key=key,decision='change',reason=why,patch=patch))
  else:out.append(dict(review_key=key,decision='keep',reason='已结合完整正文与本人评论独立核对；首判的身份、意向、证据、条件及母句计划可保留。',patch={}))
 target=P/f'page-{n:02}.audit.jsonl';target.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in out),encoding='utf-8')
 progress={'worker':'c','pages':[],'usage':'unknown'}
 if (W/'progress.json').exists():progress=json.loads((W/'progress.json').read_text(encoding='utf-8'))
 progress['pages']=[p for p in progress['pages'] if p['page']!=n]+[dict(page=n,input_count=len(rows),output_count=len(out),change_count=len(changes),all_ids_explicit=True)]
 (W/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8');print(n,len(out),len(changes))
def original(n,k):return copy.deepcopy(load(n)[k][1]['first_semantic_judgment'])
