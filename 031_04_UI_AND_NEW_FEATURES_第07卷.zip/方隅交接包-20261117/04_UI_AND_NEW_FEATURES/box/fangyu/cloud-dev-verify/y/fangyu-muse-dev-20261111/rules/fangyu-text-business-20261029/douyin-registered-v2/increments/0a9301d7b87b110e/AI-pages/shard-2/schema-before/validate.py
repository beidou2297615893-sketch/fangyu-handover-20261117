import json,pathlib,collections,hashlib,datetime
P=pathlib.Path(__file__).parent;ROOT=P.parent.parent
task=json.loads((P/'task.json').read_text(encoding='utf-8-sig'))
source=[json.loads(l) for l in pathlib.Path(task['source_full_metadata_file']).read_text(encoding='utf-8-sig').splitlines()]
output=pathlib.Path(task['output_file']);rows=[json.loads(l) for l in output.read_text(encoding='utf-8').splitlines()]
S={s['review_key']:s for s in source};errors=[]
required=['review_key','comment_id','customer_uid','video_id','role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','human_confirmed','send_authorized','store_assignment','reply_plan']
enums={'role':{'demand','supply','mixed','unknown','discussion'},'demand_state':{'active_at_comment','future','ended','historical','unknown'},'interest':{'super_high','high','medium','low','very_low','uncertain','unrelated'}}
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
pols={'ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'}
subjects={'own_demand','supply','current_home','other_person','unresolved'}
allowed_slots={1,2,7,13,16,19,25,28,31,34}
quotes_checked=0;body_quotes=[];metadata_replacements=[]
def check(ok,msg):
 if not ok:errors.append(msg)
for row in rows:
 k=row['review_key'];src=S.get(k);check(src is not None,k+':unknown_key')
 if src is None:continue
 check(all(f in row for f in required),k+':required')
 for f in ['comment_id','customer_uid','video_id']:check(row[f]==src[f],k+':'+f)
 for f,values in enums.items():check(row[f] in values,k+':'+f+':enum')
 check(row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None,k+':authority')
 check(set(row['context_used'])==({'own','body','parent'} if src.get('direct_parent_text') else {'own','body'}),k+':context')
 for x in row['topics']:
  check(x['pool'] in pools,k+':pool');check(x['polarity'] in pols,k+':polarity');check(x['subject'] in subjects,k+':subject');check(bool(x['condition_scope']),k+':scope')
 for x in row['target_regions']:
  check(x['relation'] in {'desired','preferred','accepted','excluded','work','current_home','offered','unresolved'},k+':region_relation')
  check(x['group_relation'] in {'AND','OR','unknown'},k+':region_group')
 for x in row['time_mentions']:check(x['time_role'] in {'move_in','viewing','lease_duration','search_start','other'},k+':time_role')
 qlist=row['evidence']+[x['quote'] for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics'] for x in row[f]]
 for q in qlist:
  quotes_checked+=1
  if q not in src['comment_text']:
   if src.get('post_author_same_as_commenter') and q in src.get('post_body',''):body_quotes.append({'key':k,'quote':q,'same_author_verified':True})
   else:errors.append(k+':quote:'+q)
 plan=row['reply_plan'];check(set(plan)=={'preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy'},k+':reply_schema')
 check(plan['preferred_mother_slot'] is None or plan['preferred_mother_slot'] in allowed_slots,k+':mother')
 check(plan['contact_policy'] in {'allow','identity_restricted','no_contact','unknown'},k+':contact')
 check(isinstance(plan['generic_intro_suitable'],bool),k+':generic_type')
 check(not (row['role']=='unknown' and row['demand_state']=='unknown' and row['interest']=='unrelated'),k+':unknown_drop')
 meta={f:row[f] for f in ['reason','needs_review','reply_plan','model_review_provenance']}
 if '\ufffd' in json.dumps(meta,ensure_ascii=False):metadata_replacements.append(k)
keys=[r['review_key'] for r in rows]
check(len(rows)==task['comments']==len(source),'count')
check(len(keys)==len(set(keys)) and set(keys)==set(task['expected_review_keys'])==set(S),'key_set')
for f in ['comment_id','customer_uid','video_id']:
 check(collections.Counter((r['review_key'],r[f]) for r in rows)==collections.Counter((s['review_key'],s[f]) for s in source),'full_'+f+'_mapping')
page_counts={}
for pagefile in sorted(P.glob('page-*.json')):
 page=pagefile.stem[-2:];d=json.loads(pagefile.read_text(encoding='utf-8-sig'));expected=[c['key'] for g in d['shared_post_context'] for c in g['comments']]
 local=[json.loads(l) for l in (P/f'reviewed-{page}.jsonl').read_text(encoding='utf-8').splitlines()]
 check(len(expected)==len(local) and set(expected)=={r['review_key'] for r in local},'page_'+page)
 page_counts[page]=len(local)
check(len(page_counts)==task['pages'],'page_count')
check(not metadata_replacements,'metadata_utf8')
progress=json.loads((P/'progress.json').read_text(encoding='utf-8'));check(progress['method']=='逐页完整语义读取后显式逐条决定；同轮初筛细筛，非独立二审','progress_method_utf8')
check(not progress['errors'],'serializer_errors')
result=dict(shard=2,validated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),input_count=len(source),output_count=len(rows),expected_count=task['comments'],page_counts=page_counts,unique_review_key_count=len(set(keys)),id_mapping_fields=['review_key','comment_id','customer_uid','video_id'],id_mappings_equal=not any('mapping' in e or 'key_set' in e for e in errors),quotes_checked=quotes_checked,quote_errors=[e for e in errors if ':quote:' in e],verified_same_author_body_quotes=body_quotes,metadata_utf8_replacement_keys=metadata_replacements,source_comment_replacement_keys=[s['review_key'] for s in source if '\ufffd' in s['comment_text']],source_comments_preserved=True,role_counts=dict(collections.Counter(r['role'] for r in rows)),interest_counts=dict(collections.Counter(r['interest'] for r in rows)),contact_policy_counts=dict(collections.Counter(r['reply_plan']['contact_policy'] for r in rows)),output_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),errors=errors,passed=not errors,platform_calls=0,send_attempts=0,human_confirmed=False,send_authorized=False,store_assignment=None,independent_second_review=False,usage='unknown',limitations=['每条为同一模型同轮语义初筛与细筛，不冒充人工金标或独立第二模型复核。','时间均保留原词与评论时间锚，未用今天替换相对日期；当时意向不保证今日有效。','方隅门店、同一房源库存、报价、资格及优惠事实未核实；母句仅候选，不是事实承诺或发送许可。','源评论D2235含原有替换字符，原样保留；生成的reason、计划、进度元数据未新增替换字符。','账号消耗、credits具体usage未取得，记unknown，未购买额度。'])
(ROOT/'shard-2-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
report=f'''# 抖音本地文本判读记录

本分片已逐页读取14页共享原帖上下文，并对2479条评论逐条作模型语义初筛与细筛；程序仅按显式决定展开字段、保留身份映射和校验。未使用关键词、正则词库代判，没有独立第二轮模型复核或人工确认。

校验结果：输入2479条，输出{len(rows)}条，唯一记录{len(set(keys))}条；记录键、评论、账号和视频映射一一相同。逐字证据检查{quotes_checked}处，错误{len(result['quote_errors'])}处。页级覆盖、字段枚举、联系策略、母句槽位、授权状态和UTF-8元数据检查{'通过' if not errors else '未通过'}。详细错误数：{len(errors)}。

意向分布：高{result['interest_counts'].get('high',0)}条，超高{result['interest_counts'].get('super_high',0)}条，中{result['interest_counts'].get('medium',0)}条，低{result['interest_counts'].get('low',0)}条，待判断{result['interest_counts'].get('uncertain',0)}条，无当前住宅租赁意向{result['interest_counts'].get('unrelated',0)}条。最后一类包含已解决、历史居住、一般讨论、供给和非住宅用途，不代表删除原记录。

保留了本人主动替亲友求租、严肃家庭场景、未明确后续住房的退租/费用纠纷机会、未来入住但正在咨询、工作地与目标区域、否定和条件范围。每月报价没有自动变成总租期。只有明确提出今天或明天看房的2条记为超高，仍不等于已预约成功。

全部记录人工确认和发送授权均为false，门店指派为空。联系策略allow只代表文本未表达该限制，不是发送授权。未调用平台、未采集、未发送、未写源库、未接触凭据、未购买额度。

## 尚需核实

{chr(10).join('- '+x for x in result['limitations'])}

输出SHA-256：{result['output_sha256']}
'''
(ROOT/'shard-2-report.md').write_text(report,encoding='utf-8')
progress.update(status='complete' if not errors else 'validation_failed',validation_passed=not errors,validated_output_count=len(rows),metadata_encoding='UTF-8',usage='unknown')
(P/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:result[k] for k in ['input_count','output_count','unique_review_key_count','quotes_checked','verified_same_author_body_quotes','metadata_utf8_replacement_keys','source_comment_replacement_keys','errors','passed','output_sha256']},ensure_ascii=False))
