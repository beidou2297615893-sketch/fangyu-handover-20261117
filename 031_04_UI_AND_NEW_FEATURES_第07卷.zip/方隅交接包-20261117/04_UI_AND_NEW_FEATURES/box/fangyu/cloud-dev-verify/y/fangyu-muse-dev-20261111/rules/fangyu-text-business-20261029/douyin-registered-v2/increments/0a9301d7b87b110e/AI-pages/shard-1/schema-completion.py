import pathlib,json
b=pathlib.Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/0a9301d7b87b110e/AI-pages/shard-1')
p=b/'serialize.py'; t=p.read_text(encoding='utf-8');t=t.replace("r['context_flags']={'post_author_same_as_commenter'", "r['contact_boundaries']=e.pop('contact_boundaries',[])\n  r['context_flags']={'post_author_same_as_commenter'"); p.write_text(t,encoding='utf-8')
patches={
'D4667':{'contact_boundaries':[{'quote':'个人转租的 中介勿扰','scope':'仅求个人转租，拒绝中介身份；非所有联系'}]},
'D4670':{'contact_boundaries':[{'quote':'来个房东','scope':'要求房东身份，须核真实身份与是否接受其他承接'}]},
'D5375':{'contact_boundaries':[{'quote':'直接联系房东','scope':'请求直接房东渠道，勿冒充房东'}]},
'D0452':{'other_constraints':[{'quote':'卖不卖','meaning':'购房询盘，非租房'}]},
'D1631':{'other_constraints':[{'quote':'怎么卖，房价多少','meaning':'购房询盘，非租房'}]},
'D5312':{'other_constraints':[{'quote':'想买这种房子','meaning':'购买住房需求，不作住宅租赁'}]}
}
for p in b.glob('decisions-*.txt'):
 out=[]
 for line in p.read_text(encoding='utf-8').splitlines():
  if line and not line.startswith('#'):
   parts=line.split('|')
   if parts[0] in patches:
    e=json.loads(parts[6]) if parts[6] else {};e.update(patches[parts[0]]);parts[6]=json.dumps(e,ensure_ascii=False);line='|'.join(parts)
  out.append(line)
 p.write_text('\n'.join(out)+'\n',encoding='utf-8')
