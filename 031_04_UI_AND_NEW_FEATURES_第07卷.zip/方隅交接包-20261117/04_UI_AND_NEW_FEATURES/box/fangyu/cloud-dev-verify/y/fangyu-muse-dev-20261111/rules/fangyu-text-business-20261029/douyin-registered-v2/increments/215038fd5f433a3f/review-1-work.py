import json,pathlib,collections
p=pathlib.Path('work/fangyu-text-business-20261029/douyin-registered-v2/increments/215038fd5f433a3f')
rows=[json.loads(s) for s in (p/'shard-1.jsonl').open(encoding='utf8')];by={int(d['review_key'][1:]):d for d in rows};out={}
def ids(s):return [int(x) for x in s.split()]
def group(s,role,interest,state,reason,needs=None):
 for n in ids(s):
  d=by[n];out[n]={'review_key':d['review_key'],'comment_id':d['comment_id'],'customer_uid':d['customer_uid'],'video_id':d['video_id'],'role':role,'interest_at_comment':interest,'demand_state':state,'topics':[],'topic_evidence':[],'target_regions':[],'reason':reason,'evidence':[d['comment_text']] if d['comment_text'] else [],'review_reasons':list(needs or []),'context_used':['own','body'] if d['post_body'] else ['own'],'other_constraints':[],'possible_topics':[],'time_mentions':[],'human_confirmed':False,'current_need_verified':False,'assigned_store':None,'send_authorized':False}
group('5 8 11 14 17','supply','unrelated','unknown','本人明确转租、提供房源或向求租者介绍出租住房，未表达本人另找房需求。')
group('35 38 41 50 53 59 65 68 71 74 77 80','discussion','unrelated','unknown','评论是建议、评价、经历或其他话题，未表达本人新的住宅求租需求。')
group('2 20 23 26 29 47 56 62','unknown','uncertain','unknown','评论对象、供需身份或本人租房意图不明，不能借用视频作者的需求。',['需核对直接对话和供需对象。'])
group('32 44 86 89 92 95','demand','high','active_at_comment','本人提出租房区域或向明确出租房源询问房态、位置或价格，表示评论时兴趣。',['当前需求、房源状态与对方身份尚待核实。'])
group('83','demand','low','future','本人说待对方找到后再帮找一间，表示有条件的后续找房愿望。',['核对是否现已开始独立找房，不继承对方的价格或地区要求。'])
out[2]['reason']='“宝山转租”可能是提供转租，也可能是在找宝山转租房，表达不完整。';out[2]['review_reasons']=['核对该说话人是转出租房还是寻求承租。']
out[20]['reason']='单字“我”无法确认所指和供需身份。';out[20]['review_reasons']=['核对直接对话，不将发帖人的求租条件当作本人条件。']
out[23]['reason']='只提及地点，可能是推荐房源或本人寻租；未见直接关系。';out[23]['review_reasons']=['核对是房源推荐、工作地还是本人目标地区。']
out[26]['reason']='问对方是否需要某地房源，但未明确自己有可出租住房。';out[26]['review_reasons']=['核对是否有对应房源；不能把该地当作本人目标。']
out[29]['reason']='“华漕附近的”是残句，可能指本人的目标位置或回答他人。';out[29]['review_reasons']=['核对地点所属对象及本人意图。']
out[47]['reason']='单列地铁路线和站名，未说明推荐还是本人想租。';out[47]['review_reasons']=['补充说话对象及其对该地的意图。']
out[56]['reason']='攻略下“蹲一个6号线”可能是在等线路攻略，也可能找附近房源。';out[56]['review_reasons']=['核对蹲的是攻略信息还是本人住房。']
out[62]['reason']='询问如何联系房源信息，但视频是价格攻略，未明本人是否在找房或对应具体房源。';out[62]['review_reasons']=['核对本人需求、信息对象和房源是否可租。']
# Helper functions use only verbatim words from the speaker's comment.
def topic(n,pool,q,pol='ask',scope=None):
 assert q in by[n]['comment_text'];x=out[n]
 if pool not in x['topics']:x['topics'].append(pool)
 x['topic_evidence'].append({'pool':pool,'quote':q,'polarity':pol,'subject':'own_demand','source_kind':'own_comment','condition_scope':scope})
def region(n,q,relation,scope=None):
 assert q in by[n]['comment_text'];out[n]['target_regions'].append({'text':q,'quote':q,'relation':relation,'group_relation':'unknown','condition_scope':scope})
def poss(n,pools,q,reason):
 assert q in by[n]['comment_text'];out[n]['possible_topics'].append({'pools':pools,'quote':q,'subject':'unresolved','reason':reason})
for n in (86,89,95):topic(n,'房源状态',by[n]['comment_text'],'ask',scope='询问该房当时是否可租，不代表现有库存')
topic(92,'价格预算','实价','ask',scope='询问该房实际价格，不推定本人预算')
topic(32,'位置通勤','在哪里','ask',scope='询问房源位置，不从视频内容推本人目标区域')
topic(44,'位置通勤','漕河泾附近','require',scope='本人询问该区域的住房，不从视频继承预算')
topic(44,'房源状态','漕河泾附近有吗','ask')
region(44,'漕河泾附近','desired','以本人原话为准，城市及具体范围待核')
topic(83,'户型面积与居住方式','找到了也给我找一间','conditional',scope='先等对方找到，再请求寻找一间；租期和条件未说明')
for n,q in {5:'浦东新区金东名苑西',11:'东靖路地铁站附近',14:'泗泾',17:'中潭路地铁房'}.items():region(n,q,'offered','供给的旧房或推荐房源位置，不作本人新求租目标')
for n,pools in [(2,['房源状态']),(23,['位置通勤']),(26,['位置通勤']),(29,['位置通勤']),(47,['位置通勤']),(56,['位置通勤']),(62,['看房联系'])]:poss(n,pools,by[n]['comment_text'],'该话题与本人找房或供给的关系未明确。')
# No inferred demand from landlord conditions or post author's title.
result=[out[n] for n in sorted(out)];allowed={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'};errs=[]
for x in result:
 d=by[int(x['review_key'][1:])];own=d['comment_text']
 if (x['comment_id'],x['customer_uid'],x['video_id'])!=(d['comment_id'],d['customer_uid'],d['video_id']):errs.append([x['review_key'],'identity'])
 for q in x['evidence']+[t['quote'] for t in x['topic_evidence']]+[t['quote'] for t in x['target_regions']]+[t['quote'] for t in x['possible_topics']]+[t['quote'] for t in x['other_constraints']]:
  if q not in own:errs.append([x['review_key'],'quote'])
 if any(t not in allowed for t in x['topics']):errs.append([x['review_key'],'pool'])
 if x['role']=='unknown' and x['interest_at_comment']!='uncertain':errs.append([x['review_key'],'unknown'])
 if x['role']=='supply' and x['topics']:errs.append([x['review_key'],'supply_topics'])
 if x['current_need_verified'] or x['human_confirmed'] or x['assigned_store'] is not None or x['send_authorized']:errs.append([x['review_key'],'authorization'])
ins={(x['review_key'],x['comment_id']) for x in rows};outs={(x['review_key'],x['comment_id']) for x in result}
with (p/'reviewed-1.jsonl').open('w',encoding='utf8',newline='\n') as f:
 for x in result:f.write(json.dumps(x,ensure_ascii=False)+'\n')
report={'input_count':len(rows),'output_count':len(result),'input_unique_count':len(ins),'output_unique_count':len(outs),'id_sets_equal':ins==outs,'all_own_quotes_valid':not errs,'errors':errs,'role_counts':dict(collections.Counter(x['role'] for x in result)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in result)),'human_gold':False,'send_authorized':False,'limitations':'模型逐条语义初判，结构和逐字校验不构成准确率、当前意向或房源核实。'}
(p/'validation-1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report,ensure_ascii=False,indent=2))
