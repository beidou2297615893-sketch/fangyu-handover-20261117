import json,pathlib,sys,re
b=pathlib.Path(__file__).resolve().parent.parent
p=json.loads((b/'recall-audit'/f'part-{sys.argv[1]}'/f'page-{int(sys.argv[2]):02}.json').read_text(encoding='utf-8'))
dic=json.loads((b/'audit-worker-b/strings.json').read_text(encoding='utf-8'))
als={'role':'r','demand_state':'s','interest':'i','reason':'why','topics':'tp','target_regions':'reg','time_mentions':'tm','other_constraints':'oc','possible_topics':'poss','needs_review':'nr','contact_boundaries':'cb','context_used':'ctx','reply_plan':'plan','preferred_mother_slot':'slot','generic_intro_suitable':'gen','missing_facts':'facts','contact_policy':'cp','condition_scope':'cs','group_relation':'gr','polarity':'pol','subject':'sub','verification':'ver','anchor_source':'src','anchor_time':'at','time_role':'tr','normalized':'norm'}
def cv(x,own):
 if isinstance(x,str):
  if x==own:return '$own'
  return dic.get(x,x.replace('具体条件/问句待核实答复：','?').replace('本人所问“','?').replace('”对应的','→').replace('事实',''))
 if isinstance(x,dict):
  if set(['pool','quote','polarity','subject','condition_scope'])<=set(x):return [x['pool'],cv(x['quote'],own),x['polarity'],x['subject'],'=' if x['condition_scope']==x['quote'] else cv(x['condition_scope'],own)]
  if set(['text','quote','relation','group_relation','condition_scope'])<=set(x):return [x['text'],'=' if x['quote']==x['text'] else cv(x['quote'],own),x['relation'],x['group_relation'],'=' if x['condition_scope']==x['quote'] else cv(x['condition_scope'],own)]
  if set(['preferred_mother_slot','generic_intro_suitable'])<=set(x):pass
  return {als.get(k,k):cv(v,own) for k,v in x.items()}
 if isinstance(x,list):return [cv(v,own) for v in x]
 return x
lo=int(sys.argv[3]) if len(sys.argv)>3 else 0; hi=int(sys.argv[4]) if len(sys.argv)>4 else 10000
n=0
print('DEFAULT omitted empty lists/objects/null; plan slot null gen false tone normal facts[] caution[] cp allow; ctx own,body. § legend strings.json; $own is exact current comment.')
for g in p['post_groups']:
 if any(lo<=n+k<hi for k in range(len(g['comments']))): print('BODY',g['video'],g['post_body'])
 for c in g['comments']:
  idx=n;n+=1
  if not lo<=idx<hi:continue
  d=dict(c['first_semantic_judgment']); pl=d.pop('reply_plan'); ctx=d.pop('context_used'); d={k:v for k,v in d.items() if v not in ([],{},None)}
  dp={'preferred_mother_slot':None,'generic_intro_suitable':False,'tone':'normal','missing_facts':[],'caution':[],'contact_policy':'allow'}
  pl={k:v for k,v in pl.items() if v!=dp.get(k)}
  if pl:d['reply_plan']=pl
  if ctx!=['own','body']:d['context_used']=ctx
  print(idx,c['key'],json.dumps(c['text'],ensure_ascii=False),str(c['same_author']),str(c['published_at'])[:10],('parent='+str(c['parent']) if c['parent'] else ''),('CONFLICT' if c['source_conflict'] else ''),json.dumps(cv(d,c['text']),ensure_ascii=False,separators=(',',':')))
