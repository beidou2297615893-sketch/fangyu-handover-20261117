import json,hashlib,collections
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]; PART=Path(__file__).resolve().parent
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
task=read(PART/'task.json'); pages=sorted(PART.glob('page-??.json'))
comments={c['key']:(c,g['video'],f.name) for f in pages for g in read(f)['post_groups'] for c in g['comments']}
primary={json.loads(l)['review_key']:json.loads(l) for f in BASE.glob('reviewed-new-*.jsonl') for l in f.read_text(encoding='utf-8-sig').splitlines()}
rows=[json.loads(l) for l in (BASE/'recall-audit-0.jsonl').read_text(encoding='utf-8').splitlines()]
keys=[r['review_key'] for r in rows]
assert len(rows)==len(set(keys))==task['records']==1523
assert set(keys)==set(comments)==set(task['expected_review_keys'])
fields={'role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','human_confirmed','send_authorized','store_assignment','reply_plan'}
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
roles={'demand','supply','mixed','unknown','discussion'}; states={'active_at_comment','future','ended','historical','unknown'}
interests={'super_high','high','medium','low','very_low','uncertain','unrelated'}
polarities={'ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown'}
subjects={'own_demand','supply','current_home','other_person','unresolved'}
relations={'desired','preferred','accepted','excluded','work','current_home','offered','unresolved'}
planfields={'preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy'}
transitions=collections.Counter(); counts=collections.Counter(); patchfields=collections.Counter(); quotes=0; inherited_quote_errors=[]
for r in rows:
 key=r['review_key']; c,video,page=comments[key]; old=primary[key]; patch=r['patch']; merged=old|patch
 assert set(r)=={'review_key','decision','reason','patch'}
 assert r['decision'] in {'keep','change'} and bool(r['reason'])
 assert (r['decision']=='keep')==(patch=={})
 assert set(patch)<=fields,(key,set(patch)-fields)
 assert merged['role'] in roles and merged['demand_state'] in states and merged['interest'] in interests
 assert merged['human_confirmed']==False and merged['send_authorized']==False and merged['store_assignment'] is None
 if patch:
  transitions[(old['interest'],merged['interest'])]+=1;patchfields.update(patch.keys())
  assert set(merged['reply_plan'])==planfields
  assert merged['reply_plan']['contact_policy'] in {'allow','identity_restricted','no_contact','unknown'}
  if merged['interest']=='uncertain' or merged['demand_state']=='unknown':
   assert not merged['reply_plan']['generic_intro_suitable'],key
  assert old['reply_plan']['contact_policy'] not in {'no_contact','identity_restricted'} or merged['reply_plan']['contact_policy']==old['reply_plan']['contact_policy']
 for field in ['topics','target_regions','time_mentions']:
  for q in merged.get(field,[]):
   if q['quote'] not in c['text']:inherited_quote_errors.append({'key':key,'field':field,'quote':q['quote'],'new_patch':field in patch})
  for q in patch.get(field,[]):
   assert q['quote'] in c['text'],(key,field,q); quotes+=1
   if field=='topics':assert q['pool'] in pools and q['polarity'] in polarities and q['subject'] in subjects
   if field=='target_regions':assert q['relation'] in relations and q['group_relation'] in {'AND','OR','unknown'}
 assert old['video_id']==video
 counts[r['decision']]+=1
assert not inherited_quote_errors,inherited_quote_errors
perpage=[]
for f in pages:
 audit=PART/f'{f.stem}.audit.jsonl'; a=[json.loads(l) for l in audit.read_text(encoding='utf-8').splitlines()]
 explicit=[l.split('\t',1)[0] for l in (PART/f'{f.stem}.decisions.tsv').read_text(encoding='utf-8-sig').splitlines() if l.strip()]
 expected=[c['key'] for g in read(f)['post_groups'] for c in g['comments']]
 assert set(explicit)==set(expected)==set(r['review_key'] for r in a) and len(explicit)==len(expected)==len(a)
 perpage.append({'page':f.name,'input':len(expected),'explicit_decisions':len(explicit),'output':len(a),'change':sum(x['decision']=='change' for x in a),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
validation={'input_count':1523,'output_count':len(rows),'unique_output_keys':len(set(keys)),'key_sets_equal':True,'missing_keys':[],'extra_keys':[],'all_explicit_decisions':True,'default_keep_fallback':False,'keep':counts['keep'],'change':counts['change'],'patch_field_counts':dict(patchfields),'patch_quote_count':quotes,'patch_quotes_verbatim_in_own_comment':True,'all_merged_topic_region_time_quotes_verbatim':True,'inherited_quote_errors':[],'enum_checks_passed':True,'reply_plan_structure_passed':True,'unknown_changed_rows_do_not_allow_generic_draft':True,'human_confirmed_and_send_authorized_remain_false':True,'store_assignment_remains_null':True,'source_references_match':True,'per_page':perpage,'interest_transitions':[{'from':a,'to':b,'count':n} for (a,b),n in sorted(transitions.items())],'primary_source_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(BASE.glob('reviewed-new-*.jsonl'))},'output_sha256':hashlib.sha256((BASE/'recall-audit-0.jsonl').read_bytes()).hexdigest(),'limitations':['模型独立语义复核，不是人工金标或准确率测评','只提供派生patch；不改变初评、源库、软件、主指针或独立前200','评论时意向不证明今日仍有效；unknown保留待核不自动出稿或发送','原始文件哈希为本次引用校验快照，并非声称预先已有双时点完整性比对']}
(BASE/'audit0-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
report=['# 抖音语义召回与意向分级独立复核（第0部分）','','已完成全部1,523条逐条独立阅读与显式决策：保留1,313条，提出210条派生修改。所有预期人员记录均保留，没有按意向删除。','','每条先读本人评论及共享正文，再比较初评。各页的 decisions.tsv 是逐条显式决策；本地脚本只展开这些决定、读取原评审引用字段并检查，不使用关键词规则判意向，也没有默认keep后补例外。','','主要修改包括：泛看房从超高校准到高；真假、短问、单个地名等保留中兴趣或不确定并说明找房动作未知；押金、解约、当前住处不满及过去看房去向不明者保留具体待核；纯艾特用途不明保留不确定。明确供给、已安置且无新需求、闲聊及只购房继续保留原判断。','','回复计划随改判复核；未知动作记录不适合直接生成介绍草稿。allow只表示评论未表达联系限制，不构成发送授权。未写逐条回复、未采集、未发送。','','## 验证','','- 输入、输出与预期key集合完全相等：1,523/1,523，无重复、无缺失、无额外。','- 10页均有逐条显式决定与页输出，progress.json记录全量进度。',f'- 新patch含{quotes}处主题/地区逐字引文，全部来自对应本人评论；派生合并后全部主题/地区/时间引文亦通过逐字校验。','- patch字段、身份/意向/状态、主题极性/主体、地区关系及回复计划结构枚举校验通过。','- human_confirmed、send_authorized仍为false，门店归属仍为空。','- 初评文件、源库、软件、主指针、独立前200文件没有被本流程编辑；本流程仅写本部分决策和派生audit。','','## 修改字段计数','']
report += [f'- {k}: {n}' for k,n in patchfields.items()]
report += ['','## 引用与交付','','- 根批目录 recall-audit-0.jsonl：完整逐条keep/change与最小字段patch。','- recall-audit/part-0/page-00.json至page-09.json：共享正文与原评论。','- recall-audit/part-0/page-XX.decisions.tsv、page-XX.audit.jsonl：显式决定及展开结果。','- reviewed-new-0/1/2.jsonl：只读引用初评，身份与来源关联已核对。','- audit0-validation.json：逐页计数、引文检查、枚举、字段计数、意向转移及来源/结果哈希。','','这是模型独立复核，不是人工金标、用户认可或准确率保证；评论发表时的意向也不代表今日仍有效。没有发布、重新冻结或修改主指针。']
(BASE/'audit0-report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
print(json.dumps({k:validation[k] for k in ['input_count','output_count','keep','change','patch_quote_count','key_sets_equal','enum_checks_passed']},ensure_ascii=False))
