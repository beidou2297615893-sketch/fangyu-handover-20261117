"""Serialize this agent's explicit per-key semantic decisions. No automatic classification."""
import copy
import hashlib
import importlib.util
import json
from collections import Counter
from datetime import datetime, timezone, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
BATCH = HERE.parent.parent
SRC = [json.loads(x) for x in (BATCH/'shard-0.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
BY = {int(x['review_key'][1:]): x for x in SRC}
DEC = {}
P = {'p':'价格预算','l':'位置通勤','h':'户型面积与居住方式','f':'房内设施','a':'宠物','e':'楼层电梯','t':'入住与租期','s':'房源状态','c':'费用合同','v':'看房联系'}

def T(pool, quote, polarity='ask', subject='own_demand', scope=None):
    return dict(pool=P[pool], quote=quote, polarity=polarity, subject=subject, condition_scope=scope)

def R(text, quote=None, relation='desired', group='unknown', scope=None):
    return dict(text=text,quote=quote or text,relation=relation,group_relation=group,condition_scope=scope)

def X(quote,detail): return dict(quote=quote,detail=detail)

def TM(quote,role,normalized=None,verification='保留本人时间表达，不据分析日推断当前状态'):
    return dict(quote=quote,time_role=role,anchor_source='comment.published_at_unix',anchor_time=None,normalized=normalized,verification=verification)

def add(n, role, state, interest, reason, topics=(), regions=(), slot=None, needs=(), possible=(), times=(), other=(), generic=False, tone='normal', flags=None, missing=()):
    assert n not in DEC, n
    s=BY[n]
    DEC[n] = dict(review_key=s['review_key'],platform=s['platform'],comment_id=s['comment_id'],customer_uid=s['customer_uid'],video_id=s['video_id'],role=role,demand_state=state,interest=interest,topics=list(topics),target_regions=list(regions),time_mentions=list(times),other_constraints=list(other),possible_topics=list(possible),evidence=[s['comment_text']] if s['comment_text'] else [],reason=reason,context_used=['own','body'],needs_review=list(needs),contact_boundaries=[],context_flags=dict(flags or {}),reply_plan=dict(preferred_mother_slot=slot,generic_intro_suitable=generic,tone=tone,missing_facts=list(missing),caution=['仅表示评论时语义，未核实今日需求；allow不等于发送授权'],contact_policy='allow'),human_confirmed=False,send_authorized=False,store_assignment=None)

def demand(n,reason,topics=(),regions=(),slot=1,needs=(),possible=(),times=(),other=(),tone='normal',interest='high',missing=(),flags=None):
    add(n,'demand','active_at_comment',interest,reason,topics,regions,slot,needs,possible,times,other,True,tone,flags,missing)

def inquiry(n,kind,reason=None):
    # kind and key are explicitly chosen below by this agent; no source text matcher.
    quote=BY[n]['comment_text']
    demand(n,reason or '本人在明确出租房源下主动询问'+{'p':'租金','l':'位置','s':'房态','v':'联系方法'}[kind]+'，保留评论时询租兴趣；未把帖子其他条件搬为本人需求。',[T(kind,quote)],slot=28 if kind=='v' else (31 if kind=='l' else 1),needs=['需核实当前仍在找房及所询房源今天是否可承接'],missing=['真实住户身份、可承接位置、当前有效房源和推荐优惠条件未核实'])

def discussion(n,reason,topics=(),regions=(),state='unknown',needs=(),other=(),possible=(),times=()):
    add(n,'discussion',state,'unrelated',reason,topics,regions,needs=needs,other=other,possible=possible,times=times)

def unknown(n,reason,topics=(),regions=(),needs=(),possible=(),other=(),interest='uncertain'):
    add(n,'unknown','unknown',interest,reason,topics,regions,needs=needs,possible=possible,other=other)

# Initial semantic reading, then detailed evidence/subject/temporal review in the
# same agent turn. Every input key below is explicitly assigned; no fallback rows.
demand(1,'本人明确询问学校附近房源，地名按原文保留。',[T('l','武侯领创学校付近'),T('s','有房不')],[R('武侯领创学校付近')],31,needs=['学校准确名称及可接受距离待核'])
demand(4,'租房中介语境下本人明确问成华房源。',[T('l','成华'),T('s','有没有啊')],[R('成华')],31)
demand(7,'本人在租房语境要求市中心房源推荐。',[T('l','市中心')],[R('市中心')],31,needs=['市中心具体范围与预算待核'])
demand(10,'本人主动找温江一室一厅，两项条件需同时满足。',[T('l','温江'),T('h','一室一厅','require'),T('s','有一室一厅的吗')],[R('温江')],7)
demand(13,'本人主动问青羊区房源。',[T('l','青羊区'),T('s','有吗')],[R('青羊区')],31)
add(16,'supply','unknown','unrelated','“谁想住”是在推介200的套一，属于提供方而非本人求租。',[T('p','200','fact','supply'),T('h','套一','fact','supply')],needs=['200的计价周期和供给真实性未核实'])
discussion(19,'围绕中介费反问和争论，没有本人正在找房的动作。',[T('c','正规租房不收中介费 你养他吗？','compare','unresolved')])
demand(22,'本人明确想租仓山附近，预算2k。',[T('l','仓山附近'),T('p','预算2k','require')],[R('仓山附近')],2,missing=['预算计价周期、同店预算内房源与全部必付费用待核'])
demand(25,'本人求整租单间且预算800左右；不借帖子地区填本人目标。',[T('h','整租单间','require'),T('p','预算800左右','require'),T('s','有没有整租单间')],slot=2,needs=['整租单间的独立空间定义和目标地区待核'])
unknown(28,'本人抱怨五四路太贵且租不起，未明确提出当前找房；保留住房预算线索。',[T('p','咋这么贵 我都租不起','fact','unresolved')],[R('鼓楼区五四路',relation='unresolved')],needs=['是否当前寻找替代房源、可承担预算及目标范围待核'])
add(31,'demand','ended','unrelated','本人表示已申请到公租房且无新找房动作，保留已解决状态。',other=[X('申请到了公租房','住房需求已通过公租房申请解决，未表达新商业租赁需求')])
discussion(34,'表达中介费应支付的观点，不是求租条件。',[T('c','中介费正常还是要给的','fact','unresolved')])
demand(37,'本人询问申昆枢纽附近2000-2500房源。',[T('l','申昆枢纽附近'),T('p','2000-2500','require'),T('s','有吗')],[R('申昆枢纽附近')],2)
demand(40,'本人寻找世纪大道附近供两人居住的房。',[T('l','世纪大道附近'),T('h','两个人住','require'),T('s','房子有推荐吗')],[R('世纪大道附近')],34,needs=['两人关系、整合租和房型未说明'])
demand(43,'本人主动问能否帮忙找房，未给具体房型和预算。',slot=1,needs=['找房地区、预算和居住条件待补'])
demand(46,'本人问真北路一室一厅，“好点”保留为偏好而非客观标准。',[T('l','真北路'),T('h','一室一厅','require')],[R('真北路')],7,other=[X('好点的','房屋品质偏好，具体标准待确认')])
demand(49,'本人问浦东或者奉贤房源，原文明示二选一。',[T('l','浦东或者奉贤'),T('s','有没')],[R('浦东',group='OR'),R('奉贤',group='OR')],31)
demand(52,'本人明确问青浦房源。',[T('l','青浦'),T('s','有没有青浦')],[R('青浦')],31)
demand(55,'本人问中铁中环时代广场附近房源。',[T('l','中铁中环时代广场附近'),T('s','有吗')],[R('中铁中环时代广场附近')],31)
inquiry(58,'l','明确出租房源下本人问便宜房子在哪里，含对低价的关注；不能推出具体预算上限。')
DEC[58]['topics'].append(T('p','那么便宜','ask'))
inquiry(61,'l')
inquiry(64,'l')
inquiry(67,'l')
inquiry(70,'l')
inquiry(73,'l')
discussion(76,'艾特并带疑问与尬笑，属对视频的感叹互动，未询房。')
discussion(79,'艾特朋友感叹一万多租金，非本人预算或找房要求。',[T('p','一万多租房子','fact','other_person')])
discussion(82,'艾特与“老天爷”表达惊讶，没有本人需求。')
demand(85,'租房指引语境本人以“商城路呢”追问该处房源或路线；有住房线索但询问对象不足。',[T('l','商城路呢','ask')],[R('商城路',relation='unresolved')],31,interest='medium',needs=['需确认要房源推荐还是交通攻略，商城路是否目标'])
unknown(88,'租房帖下只向博主打招呼并报淞虹路，地点用途和是否找房未明。',[T('l','淞虹路','unknown','unresolved')],[R('淞虹路',relation='unresolved')],needs=['需确认是目标居住地、工作地还是攻略咨询'])
unknown(91,'“路线”可能求通勤或攻略路线，不能直接推定当前求租。',[T('l','求中华艺术宫的路线','ask','unresolved')],[R('中华艺术宫',relation='unresolved')],needs=['需核实路线用途和是否寻找住宅房源'])
demand(94,'本人问龙柏附近单间。',[T('l','龙柏附近'),T('h','单间','require'),T('s','有单间吗')],[R('龙柏附近')],7)
inquiry(97,'s')
DEC[97]['topics'].append(T('p','多少钱'))
inquiry(100,'p')
inquiry(103,'v')
demand(106,'本人明确询问短租房，帖子租赁语境明确。',[T('t','短租','require')],slot=19,needs=['具体租期、入住时间待核'],times=[TM('短租','lease_duration')])
demand(109,'本人问虹桥机场附近房源及租金。',[T('l','虹桥机场附近'),T('s','有吗'),T('p','多贵')],[R('虹桥机场附近')],31)
inquiry(112,'p')
unknown(115,'本人叙述孩子租房受坑与又面临搬家，也表达长租诉求；新房是否已解决、是否主动代租未明，保留亲友住房机会。',[T('t','为什么就找不到长租的','prefer','other_person'),T('c','不给退租','fact','other_person'),T('c','又多拿了一个垃圾费','fact','other_person')],needs=['孩子这次搬家是否已找好、本人是否希望协助找房及目标条件待核'],other=[X('这又面临搬家','子女再次搬家，不能整体当纯历史投诉过滤'),X('我去帮忙打包','本人参与亲友搬家，但尚未明确替亲友询租')])
DEC[115]['reply_plan']['tone']='serious'
DEC[115]['time_mentions']=[TM('长租','lease_duration'),TM('一年一租','lease_duration',verification='描述孩子过去租房模式，不当作新租期要求')]
discussion(118,'仅点赞表情，无询租内容。')
discussion(121,'吐槽北漂中介经历，没有提出新房需求。')
demand(124,'本人问石景山区鲁谷路瑞达大厦附近房源。',[T('l','石景山区鲁谷路瑞达大厦附近'),T('s','有吗')],[R('石景山区鲁谷路瑞达大厦附近')],31)
demand(127,'本人主动求租房选址建议，六道口与对象马驹桥芯片厂是两处通勤工作地，不是两个硬目标区。',[T('l','公司搬家到六道口了'),T('l','我对象在南六环马驹桥那边的芯片厂'),T('l','去哪里租房合适')],[R('六道口',relation='work',group='AND'),R('南六环马驹桥那边的芯片厂',relation='work',group='AND')],31,needs=['两人可接受通勤时长、预算及最终目标区域待核'],other=[X('我对象','两人共同通勤语境，不推定特定房型')],tone='serious')
demand(130,'本人预算2000询问兼顾798与亦庄的租房位置；两处工作/活动地未直接说是工作单位。',[T('l','一个在798，一个在亦庄'),T('p','预算2000','require'),T('l','在哪租合适')],[R('798',relation='unresolved',group='AND'),R('亦庄',relation='unresolved',group='AND')],2,needs=['两地是工作还是居住地、可接受通勤和整合租待核'],other=[X('一个在798，一个在亦庄','需兼顾两人地点，不视为二选一目标区域')])
unknown(133,'本人说望京找工作、住顺义，未表达正在租房，工作意向地与现住地分别保留。',[T('l','找工作望京','fact','unresolved'),T('l','住顺义','fact','current_home')],[R('望京',relation='work'),R('顺义',relation='current_home')],needs=['是否需要换房以及最终工作地点待核'])
demand(136,'本人求龙泽地铁站附近约1500短租房。',[T('l','龙泽地铁站'),T('p','1500左右','require'),T('t','短租','require')],[R('龙泽地铁站')],19,needs=['短租时长及1500计价周期待核'],times=[TM('短租','lease_duration')])
demand(139,'本人主动求世纪城海昌路中和附近住房并提总费用1000；“比超过”疑为“别超过”，保留原证据待核，不能擅自改硬上限。',[T('l','世纪城海昌路 中和附近'),T('p','预算水电气加起来比超过1000的','unknown','own_demand','预算水电气加起来比超过1000的')],[R('世纪城海昌路 中和附近',group='unknown')],2,needs=['“比超过1000”方向及世纪城/海昌路/中和是并列可选还是一片范围待核'],other=[X('预算水电气加起来比超过1000的','总费用包含水电气；预算上限文字存在疑似错字，确认后才筛预算')])
discussion(142,'回应水电费话题的季节感叹，不是入住时间。')
discussion(145,'询问博主工作，不是租房询盘。')
discussion(148,'泛生活感慨，没有本人找房动作。')
discussion(151,'比较学校费用，没有新租赁需求。')
discussion(154,'讨论合理电费区间，不是本人新房预算。',[T('c','一个月120-180才是正常的电费','compare','unresolved')])
discussion(157,'“上个月我的”在电费讨论中指历史账单，金额和新需求均未说明。',times=[TM('上个月','other',verification='可信发表时间可供核对，指账单时期，不是入住日期')])
# 闺蜜生活帖没有可租/转租陈述：短问保留住房询问但不强判确定找房。
unknown(160,'生活合租帖下蹲价格，住房价格询问存在，但是否有可租房源及本人当前求租未明。',[T('p','蹲价格','ask','unresolved')],needs=['需确认询问房租及本人是否在找房，帖子是否有可租房源'])
unknown(163,'生活合租帖下问价，不能把朋友居住展示当明确出租。',[T('p','什么价格','ask','unresolved')],needs=['所询价格对象、可租状态及当前租赁意愿待核'])
unknown(166,'生活合租帖下问位置，可能了解住房但无明确找房动作。',[T('l','在哪里？','ask','unresolved')],needs=['询问对象与本人找房意愿待核'])
unknown(169,'生活合租帖下询价格，需求和供给状态未确定。',[T('p','是什么价格呀','ask','unresolved')],needs=['需确认房租对象、可租状态与本人租赁意愿'])
demand(172,'本人在房东租房语境问余杭区房源。',[T('l','余杭区'),T('s','有余杭区嘛')],[R('余杭区')],31)
demand(175,'本人在房东租房语境问滨江区房源。',[T('l','滨江区'),T('s','有吗')],[R('滨江区')],31)
demand(178,'房东公寓租房语境下本人问贵不贵，属评论时询租兴趣，未给具体预算。',[T('p','贵不贵')],slot=1,needs=['本人可承受预算和目标房型待核'])
demand(181,'本人问滨江与萧山房源，区域并列但未说明必须同时或二选一。',[T('l','滨江跟萧山'),T('s','有吗')],[R('滨江'),R('萧山')],31,needs=['两地可选关系及更偏好地区待核'])
demand(184,'本人询问新天地租房价格，保留本人所述地名，不从来源店推导方隅店。',[T('l','新天地'),T('p','价格')],[R('新天地')],31,needs=['新天地具体位置和房型待核'])
unknown(187,'“我都是明码标价的”呈提供服务者口吻，但未明确提供房源或本人求租；不能据此当租客。',needs=['是否中介/房东身份及陈述对象待核'])
inquiry(190,'s')
inquiry(193,'l','明确公寓整租推广语境下问哪家公寓，有评论时询租兴趣；品牌询问不等于本人目标地。')
inquiry(196,'l')
add(199,'supply','unknown','unrelated','本人发布公寓出租广告，各条件属于供给。',[T('p','1.5k','fact','supply'),T('c','民水民电','fact','supply'),T('c','可押一付一','fact','supply'),T('l','近地铁','fact','supply'),T('v','随时看房入住','fact','supply')],[R('9号线醉白池地铁站',relation='offered'),R('松江体育中心',relation='offered')],times=[TM('随时','other',verification='供给方可看房入住表述，不是租客预约')])
inquiry(202,'s')
inquiry(205,'p')
unknown(208,'纯艾特无具体语义，保留未知低优先，不能视为确定无关或询租。',needs=['艾特用途及本人是否有住房需求未明'])
discussion(211,'向朋友感叹高房租与收入关系，未给本人预算。',[T('p','1万多的房租','fact','other_person')])
unknown(214,'纯艾特分享用途未知，未表达本人需求。',needs=['艾特目的及是否询租待核'])
add(217,'supply','unknown','unrelated','“把房子租给你”是房东/提供者方向，未求租。',needs=['是否真实供给及具体房源未核'])
discussion(220,'艾特朋友并惊讶“纳尼”，属视频感叹。')
unknown(223,'纯艾特用途未知，保留未知线索而不推销。',needs=['是否与本人找房有关待核'])
demand(226,'本人五角场上班且求1000出头住房推荐，工作地不等于硬目标区。',[T('l','在五角场上班'),T('p','1000出头','require')],[R('五角场',relation='work')],2,needs=['可接受通勤、具体预算上限及整合租待核'])
demand(229,'本人在租房推荐帖问双江路房源还有没有，属本人房源需求。',[T('l','双江路'),T('s','还有吗')],[R('双江路')],31)
demand(232,'本人问长宁区房源，目标明确。',[T('l','长宁区'),T('s','有没有长宁区的房子')],[R('长宁区')],31)
demand(235,'本人主动求便宜住房，公司所在地博荟广场仅作通勤地。',[T('l','公司在博荟广场这边'),T('p','便宜房子','prefer')],[R('博荟广场',relation='work')],2,needs=['具体预算与可接受通勤待核'])
demand(238,'本人主动求静安2000住房推荐。',[T('l','静安'),T('p','2000','require')],[R('静安')],2)
demand(241,'本人在租房攻略下求适合伊犁路上班的站点推荐，工作站点不能当硬目标居住站点。',[T('l','在十号线伊犁路上班'),T('l','有推荐的站点吗')],[R('十号线伊犁路',relation='work')],31,needs=['预算、可接受通勤和目标站点待核'])
discussion(244,'评价视频中的愚园路4700租房不错，未说本人找房或接受该预算。',[T('p','4700元','fact','other_person')],[R('愚园路',relation='unresolved')])
inquiry(247,'p','明确可租房源下“这个多少呢”有询租动作，但金额/面积指标不明，保留候选而非确定价格池。')
DEC[247]['topics']=[]
DEC[247]['possible_topics']=[dict(candidate_pools=['价格预算','户型面积与居住方式'],quote='这个多少呢',ambiguity='未指明询问租金还是面积，需澄清指标')]
DEC[247]['needs_review'].append('“多少”具体指租金还是面积待核')
inquiry(250,'s','本人问房子还在且问“多少米”，有评论时房态询问；米可能金额或面积，不能确定分池。')
DEC[250]['topics']=[T('s','还在吗')]
DEC[250]['possible_topics']=[dict(candidate_pools=['价格预算','户型面积与居住方式'],quote='房子多少米呀',ambiguity='米可能是金额口语或面积，缺指标解释')]
DEC[250]['needs_review'].append('“多少米”询问价格还是面积待核')
demand(253,'本人明确询价和看房，但没有约时段、预约或签约请求，判高而非超高。',[T('p','询价'),T('v','看房')],slot=28,needs=['所询房型、报价、可看安排待核'])
inquiry(256,'p')
inquiry(259,'p')
inquiry(262,'p')
inquiry(265,'p')
demand(268,'租房中介语境下明确“成都急需”，保留紧急找房需求而不自造房型和日期。',[T('l','成都')],[R('成都')],31,needs=['预算、房型及需入住时间未说明'],other=[X('急需','本人表达紧急程度，未形成具体约看或签约')])
demand(271,'本人主动问还有无好房，明确找房询问，品质标准未量化。',[T('s','还有好房子嘛')],slot=1,needs=['目标地区、预算、品质标准待核'])
discussion(274,'讨论福州区数与排名，无找房动作。')
discussion(277,'回忆2015年台江单间价格和条件，不是当前预算或新房要求。',[T('p','1300','fact','current_home'),T('h','单间','fact','current_home'),T('h','20平左右','fact','current_home'),T('f','没有卫生间','fact','current_home')],[R('福州台江',relation='current_home')],state='historical',times=[TM('15年','other','2015',verification='本人明确历史年份；不当作入住计划')])
unknown(280,'“苍山1700啥水平”是地区价格比较，未说求租或本人已住，保留歧义。',[T('p','1700啥水平','compare','unresolved')],[R('苍山',relation='unresolved')],needs=['苍山地名准确写法、价格属于现居还是询租待核'])
discussion(283,'观察周边民房空置和人口流出，不是本人明确供房或找房。',[T('s','很多民房空了很多没人租','fact','unresolved')])
discussion(286,'明确自己台江现租3800并抱怨贵，没有新找房动作。',[T('p','租3800真的太贵了','fact','current_home')],[R('台江',relation='current_home')],needs=['若需后续跟进应先确认是否准备换房，不能直接转为当前需求'])
discussion(289,'比较保利价格，没有本人要求。',[T('p','保利会贵一些','compare','unresolved')])
discussion(292,'用自己900元单间反驳别人的报价，未表达当前求租。',[T('p','为什么我单间900块','fact','current_home'),T('h','单间','fact','current_home')])
inquiry(295,'p')
inquiry(298,'p')
inquiry(301,'p')
inquiry(304,'p')
inquiry(307,'p')
demand(310,'本人主动求宝山米谷产业园房源并明确要阳台。',[T('l','宝山米谷产业园'),T('f','我想要阳台的','require')],[R('宝山米谷产业园')],34,needs=['园区周边范围、预算和阳台标准待核'])
demand(313,'本人求莘庄便宜一室户，便宜属偏好且无金额上限。',[T('l','莘庄'),T('p','便宜点','prefer'),T('h','一室户','require')],[R('莘庄')],7,needs=['具体可承受租金待核'])
demand(316,'本人已准备换房并主动问联系方法，找房动作在评论时开始，不因准备二字判未来低意向。',[T('v','怎么找你啊')],slot=28,needs=['换房地区、预算和入住时间待核'])
unknown(325,'“关注了”只有关注动作，没有明确找房请求；保留低优先未知住房线索。',needs=['是否当前租房、目标条件待核'],interest='low')
demand(319,'本人主动询问虹口广灵二路附近两室租金。',[T('l','虹口广灵二路附近'),T('h','两室的','require'),T('p','大概啥价')],[R('虹口广灵二路附近')],7)
demand(322,'本人问闵行华漕房源，保留本人目标，不凭来源古北门店指派。',[T('l','闵行华漕'),T('s','有吗')],[R('闵行华漕')],31)
demand(328,'本人询房态且明确有房即明天看房签合同，为带条件的超高推进；未视为已预约或成交。',[T('s','还有吗'),T('v','有的话明天看房签合同','conditional','own_demand','有的话'),T('c','签合同','conditional','own_demand','有的话')],slot=28,interest='super_high',needs=['房源仍可租、看房签约安排及本人今日需求未核'],times=[TM('明天','viewing','2026-03-08',verification='原评论2026-03-06T16:06:04Z换算上海时间为2026-03-07T00:06:04+08:00，按上海房源语境次日为2026-03-08；非分析日次日')])
unknown(331,'对所示租金说贵，没有当前找房或可承受上限，保留价格线索待核。',[T('p','那么贵','reject','unresolved')],needs=['是否仍考虑租房及预算待核'])
inquiry(334,'l','明确出租房源下本人问离地铁口多久，属通勤询租问题，未给最大距离。')
inquiry(337,'l')
inquiry(340,'l','明确出租房源下问离5号线多远，有通勤询租兴趣；不将5号线当所需住宅所在区域。')
inquiry(343,'l')
demand(346,'本人求宝山顾村预算2k的房源。',[T('l','宝山顾村'),T('p','预算 2k','require'),T('s','有没有')],[R('宝山顾村')],2)
discussion(349,'比较深圳与上海贵不贵，没有本人找房动作。')
unknown(352,'评价视频某套硬装和大落地窗，可能审美偏好，但未表达自己正在租或硬要求。',[T('f','硬装好那个可以 大落地窗','prefer','unresolved')],needs=['是否本人租房偏好、是否当前找房待核'])
discussion(355,'艾特朋友并说吓尿，属感叹互动。')
discussion(358,'询问博主为何不选择长住酒店，不是本人租期或住宅需求。',[T('t','长住那种','ask','other_person')])
unknown(361,'评价第三套不错，弱住房关注但无明确本人求租。',needs=['是否本人考虑该套、当前找房与可接受条件待核'],interest='low')
inquiry(364,'p','找室友合租房源语境下本人主动询价，保留高询租兴趣；不把帖子女生等限制移给本人。')
discussion(367,'批评平台信息治理，不是询租。')
unknown(370,'纯艾特语义未知，不据此断言无住房需求。',needs=['艾特用途和本人是否找房待核'])
add(373,'supply','unknown','unrelated','明确自称经营公寓并招揽客户；月付、卫浴和不收费用均是供给条件，举例2000海淀是被拒客户而非本人需求。',[T('h','整租','fact','supply'),T('f','独立卫浴','fact','supply'),T('c','压一付一月付','fact','supply'),T('c','成交了也不收任何费用','fact','supply')],other=[X('许愿客户不要找我了','提供者局部拒绝不现实预算客户，不能扩成拒绝所有联系或租客边界')],needs=['供给真实性及服务范围未核'])
unknown(376,'评论文本为空，无法根据缺失文字完成意向判断。',needs=['缺少原评论文字，无法判读'])
add(379,'supply','unknown','unrelated','本人明确出租次卧，供给房屋条件不当本人需求。',[T('h','次卧','fact','supply'),T('h','两室一厅一卫一厨','fact','supply'),T('p','2300元','fact','supply'),T('c','包水电网','fact','supply')],[R('丰台区西局玉园小区',relation='offered'),R('六里桥、西局、七里庄地铁站',quote='临近六里桥、西局、七里庄地铁站',relation='offered')],other=[X('不是中介','提供者自述身份，不是拒绝中介联系')])
add(382,'supply','unknown','unrelated','本人发布西单附近单间平房出租，属于供给。',[T('h','一单间平房','fact','supply'),T('h','可两人居住','fact','supply')],[R('西单附近',relation='offered'),R('宣武门',quote='近宣武门',relation='offered'),R('闹市口大街',relation='offered'),R('文华胡同',relation='offered')],other=[X('不是中介','供给方自述，非联系身份限制')])
add(385,'supply','unknown','unrelated','本人打算从中介收回房子自己找四家租户，明确供给方，不是求租。',[T('h','现在分4家','fact','supply'),T('f','装修一般','fact','supply'),T('c','中介快到期了','fact','supply')],times=[TM('十一到期','other',verification='供给方中介合同到期，“十一”具体所指及年份待核')],other=[X('打算自己找租户了','业主拟自行出租')])
demand(388,'本人主动询问短租公寓。',[T('t','短租','require')],slot=19,needs=['具体租期及入住时间待核'],times=[TM('短租','lease_duration')])
demand(391,'本人询问海淀房源，不将帖子四号线或来源店当目标。',[T('l','海淀'),T('s','有吗')],[R('海淀')],31)
inquiry(394,'l')
DEC[394]['topics']=[T('l','哪里'),T('p','多少钱')]
inquiry(397,'l')
inquiry(400,'p','明确居住公寓推广下本人询每月价格；一个月是计价周期，不是总租期。')
demand(403,'本人求石油大学附近2000左右一居室或者公寓，OR只作用于房型选择。',[T('l','石油大学附近'),T('p','2000左右','require'),T('h','一居室或者公寓','require','own_demand','一居室或者公寓')],[R('石油大学附近')],2,needs=['石油大学校区、可接受周边和公寓定义待核'])
demand(406,'本人要求整租，预算3500以下，三元桥是公司工作地。',[T('h','整租','require'),T('p','预算3500以下','require'),T('l','公司在三元桥')],[R('三元桥',relation='work')],2,needs=['可接受通勤、房型和全部必付费用待核'])
demand(409,'本人问丰台还剩一个月的转租，属于承接短租需求，不是自己供给转租。',[T('l','丰台区'),T('t','还有一个月的','require'),T('s','有转租还有一个月的吗')],[R('丰台区')],19,times=[TM('还有一个月','lease_duration','P1M',verification='剩余可承接租期约一个月，不是入住日期')],needs=['具体起止日期与转租授权待核'])
discussion(412,'只评论三元桥价格贵，未说自己求租。',[T('p','挺贵','fact','unresolved')],[R('三元桥',relation='unresolved')])
discussion(415,'分享本人现居电价和养狗用电，宠物不是新房需求。',[T('c','一个月100元电费','fact','current_home'),T('a','家里养狗','fact','current_home'),T('f','全天开空调','fact','current_home'),T('c','电费白天5毛8.晚上电费2毛五','fact','current_home')])
unknown(418,'明确排斥商水商电，但讨论语境中未说明正在找新房；限制保留而不冒充活跃需求。',[T('c','商水商电的，不能住','reject','unresolved')],needs=['是否本人新房硬限制、是否当前找房待核'])
discussion(421,'分享热水器使用与一人居住经验，没有新租房要求。',[T('h','我一个人住','fact','current_home'),T('f','热水器','fact','current_home')])
discussion(424,'本人分享既往账单，非新房租金预算。',[T('c','1块一度','fact','current_home'),T('c','上个月用208块','fact','current_home')],times=[TM('上个月','other',verification='原评论发布月之前的账单月份，不作找房或入住时间')])
discussion(427,'分享本人当前电费，未说新租赁要求。',[T('c','我是1.2一度','fact','current_home')])
unknown(430,'电费帖下只写600，可能账单金额，但缺主语与指标，无法判本人需求。',needs=['600的含义和是否与新找房有关待核'],possible=[dict(pool='费用合同',quote='600',ambiguity='可能电费账单，无法确定数值对象及本人归属')])
unknown(433,'生活合租帖下问位置价格，有住房询问但帖子未明示出租，暂不强判本人当前求租。',[T('l','位置','ask','unresolved'),T('p','价格','ask','unresolved')],needs=['房源可租状态及本人找房意愿待核'])
unknown(436,'生活合租帖问地址，住房兴趣存在但是否在找房及是否有可租空间未明。',[T('l','地址在哪里','ask','unresolved')],needs=['所询对象、房态与本人需求待核'])
unknown(439,'艾特朋友说出发杭州可能旅行或搬家，不能借杭州字样推定求租。',regions=[R('杭州',relation='unresolved')],needs=['出发用途及是否有居住需求待核'])
unknown(442,'生活合租帖蹲地址价格，不能凭生活展示确认出租或本人租房推进。',[T('l','地址','ask','unresolved'),T('p','价格','ask','unresolved')],needs=['询问对象、房源是否可租与本人当前需求待核'])
unknown(445,'生活合租帖只问价格，未明确住房供需关系。',[T('p','价格','ask','unresolved')],needs=['价格对象、可租状态和本人是否求租待核'])
inquiry(448,'p','房东租房公寓语境下本人问多少钱，有评论时询租兴趣；帖子宠物条件不变成本人需求。')
inquiry(451,'l','房东租房公寓语境下本人问位置，有询租兴趣；不据IP补目标地区。')
inquiry(454,'l','房东租房语境本人问杭州哪里，有询租兴趣；杭州是本人询问范围。')
DEC[454]['target_regions']=[R('杭州')]
inquiry(457,'l','房东租房公寓语境下本人问位置，有评论时住房询问。')
demand(460,'本人明确问西湖附近房源。',[T('l','西湖附近'),T('s','有吗')],[R('西湖附近')],31)
demand(463,'本人主动找福州仓山区盘屿路阳光天地附近单间。',[T('l','福州仓山区盘屿路阳光天地附近'),T('h','单间','require'),T('s','单间有吗')],[R('福州仓山区盘屿路阳光天地附近')],7,tone='serious')
discussion(466,'评价良心中介明码标价，没有本人求租动作。')
unknown(469,'前缀@林品如:使后段可能为转载他人求租；保留完整住房需求候选，不能直接归给当前账号。',[T('l','仓山区首山附近','ask','unresolved'),T('h','一室一厅','require','unresolved'),T('f','带厕所','require','unresolved'),T('h','大一点的，不要小小的','require','unresolved'),T('p','什么价位啊','ask','unresolved')],[R('仓山区首山附近',relation='unresolved')],needs=['需核实是本人/代亲友主动求租还是引用他人原话；具体面积与预算待核'])
demand(472,'本人问新店附近房源，明确求房动作。',[T('l','新店附近'),T('s','有没有新店附近的房源')],[R('新店附近')],31,needs=['新店具体地名范围待核'])
unknown(475,'“仓山区有没有租房的”可指找房源或找租客，缺供需对象，保留待核而不一刀切过滤。',[T('l','仓山区','unknown','unresolved')],[R('仓山区',relation='unresolved')],needs=['需确认是在求租房源还是寻找租客'])
discussion(478,'分享从未遇到中介收费的经验，无本人新需求。',[T('c','至今都没遇到收中介费的中介','fact','unresolved')])
discussion(481,'结合过去问价与中介费解释平台问题，没有明确当前找房。',[T('p','他挂牌1000结果那个房东跟我说实际租金是3000','fact','other_person'),T('c','五五开','fact','unresolved')],state='historical',other=[X('反正不要看安居客','平台建议，不是对所有联系的拒绝')])
inquiry(484,'l')
inquiry(487,'l')
discussion(490,'分享昆明本人现居整两居与一千价格，不是新租赁条件。',[T('p','一千元','fact','current_home'),T('h','整两居','fact','current_home')],[R('昆明',relation='current_home')])
discussion(493,'比较视频中前后房源质量，不含本人找房动作。')
unknown(496,'问展示房屋是否串串房，关注房屋安全但不能推出本人正在找房。',needs=['是否本人意向房源及是否在求租待核'],other=[X('这是不是串串房啊','房屋翻新/质量疑虑，未陈述具体新房要求')])
discussion(499,'给博主推荐北外滩，不是本人目标区域或本人求租。',regions=[R('北外滩',relation='unresolved')],other=[X('可以看看北外滩','建议他人看该地区，不计作本人目标区域')])
discussion(502,'艾特朋友感受上海物价，属分享评论。')

assert set(DEC)==set(BY), {'missing':sorted(set(BY)-set(DEC)),'extra':sorted(set(DEC)-set(BY))}

# Detail pass: temporal anchors and mother facts are serialization of the explicit
# judgments above, not intent inference or keyword classification.
MOTHERS = json.loads((BATCH.parents[2]/'approved-mothers-model-view.json').read_text(encoding='utf-8'))
MF={m['slot']:m['required_facts'] for m in MOTHERS}
for n,r in DEC.items():
    s=BY[n]
    r['context_flags'].update(post_author_same_as_commenter=False,source_version_conflict=False,source_store_is_not_assignment=True,ip_not_used_as_target=True,deeper_replies_read=False)
    if s['deeper_reply_count_visible']:
        r['context_flags']['deeper_reply_count_visible']=s['deeper_reply_count_visible']
        r['needs_review'].append('可见有后续回复但本片未提供回复正文，不推定已解决或后续确认')
    for t in r['time_mentions']:
        t['anchor_time']=datetime.fromtimestamp(s['published_at_unix'],timezone.utc).isoformat()
    slot=r['reply_plan']['preferred_mother_slot']
    if slot is not None:
        r['reply_plan']['missing_facts'].append(MF[slot])
        if r['reply_plan']['generic_intro_suitable'] and slot!=1:
            r['reply_plan']['missing_facts'].append(MF[1])
    r['reply_plan']['missing_facts']=list(dict.fromkeys(r['reply_plan']['missing_facts']))
    if r['reply_plan']['generic_intro_suitable']:
        r['reply_plan']['caution'].append('通用介绍仅为候选接话，不能冒充已回答具体房态、报价或所有硬条件')
    if n==328:
        r['reply_plan']['caution'].append('约看签约附带“有的话”条件，未代表预约已确认')
    if n in (247,250):
        r['reply_plan']['caution'].append('先澄清多少/米的指标，不把价格与面积候选计为确定需求池')
    if n==469:
        r['context_flags']['possible_quoted_other_person_demand']=True

OUT = BATCH/'reviewed-new-0.jsonl'
rows=[DEC[int(s['review_key'][1:])] for s in SRC]
OUT.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
(HERE/'reviewed-00.jsonl').write_bytes(OUT.read_bytes())

# Isolated compiler-style provenance for the real formal validator. The submitted
# semantic file above intentionally contains neither provenance nor fake stages.
isolated=[dict(copy.deepcopy(r),classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic']) for r in rows]
proof=HERE/'adapter-preflight-source.jsonl'
proof.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in isolated),encoding='utf-8')
digest=hashlib.sha256(proof.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('mother_adapter',BATCH.parents[2]/'mother_adapter.py')
adapter=importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)
cache={}
schema=[]
evidence=[]
for r in isolated:
    s=BY[int(r['review_key'][1:])]
    check=dict(copy.deepcopy(r),classification_review_source=dict(path=str(proof.relative_to(BATCH)),sha256=digest))
    try: adapter.validate_new_review(check,BATCH,cache)
    except Exception as exc: schema.append(str(exc))
    quotes=list(r['evidence'])
    for field in ('topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries'):
        quotes += [v['quote'] for v in r[field] if isinstance(v,dict) and 'quote' in v]
    for q in quotes:
        if not q or q not in s['comment_text']:
            evidence.append(dict(review_key=r['review_key'],quote=q))
ids=lambda xs:{tuple(x[k] for k in ('review_key','comment_id','customer_uid','video_id')) for x in xs}
result=dict(input_count=len(SRC),output_count=len(rows),id_sets_equal=ids(SRC)==ids(rows),unique_key_count=len({r['review_key'] for r in rows}),unique_comment_id_count=len({r['comment_id'] for r in rows}),formal_validator='mother_adapter.validate_new_review',formal_validator_checked=len(isolated),schema_errors=schema,verbatim_evidence_errors=evidence,review_sha256=hashlib.sha256(OUT.read_bytes()).hexdigest(),isolated_provenance_sha256=digest,role_counts=dict(Counter(r['role'] for r in rows)),interest_counts=dict(Counter(r['interest'] for r in rows)),method='same_agent_explicit_semantic_initial_and_detailed',independent_review_completed=False,human_confirmed=False,send_authorized=False)
(BATCH/'shard-0-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(HERE/'progress.json').write_text(json.dumps(dict(status='completed',shard=0,completed_pages=['page-00.json'],completed_page_indexes=[0],page_count=1,input_count=len(SRC),reviewed_count=len(rows),review_file='reviewed-00.jsonl',review_sha256=result['review_sha256'],schema_error_count=len(schema),verbatim_evidence_error_count=len(evidence),classification_method='ai_semantic_initial_and_detailed',classification_stages_completed=['initial_semantic','detailed_semantic'],independent_review_completed=False,human_confirmed=False,send_authorized=False),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(HERE/'report.md').write_text('# 本片语义判读与结构验证\n\n168条逐key模型初筛及细筛；没有运行关键词分类或默认补未读记录。评论原文和完整共享正文已读，原始元数据单独核对；没有读取未提供后续回复。\n\n- 输入/输出：'+str(len(SRC))+'/'+str(len(rows))+'；key/cid/uid/video集合一致：'+str(result['id_sets_equal'])+'。\n- 正式函数隔离预检：'+str(len(isolated))+'条，结构错误'+str(len(schema))+'，逐字证据错误'+str(len(evidence))+'。\n- 评审SHA256：'+result['review_sha256']+'。\n- 本轮只有同一代理的初筛与细筛，未伪造独立复核；正式编译绑定由总控进行。\n- 没有平台请求、采集、凭据读取、发送或门店指派。所有human_confirmed/send_authorized=false、store_assignment=null。\n- D0115保留孩子再次搬家及长租线索；D0127/D0130/D0226/D0235/D0241/D0406工作与通勤地分开；D0139原文预算疑似错字未擅改；D0247/D0250未把多少米直接当价格；D0328带条件的次日看房签约；D0469疑似引用他人求租；D0475供需对象未明。\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
assert not schema and not evidence and result['id_sets_equal'] and len(rows)==168
