import json,pathlib,sys,collections
BASE=pathlib.Path(__file__).resolve().parents[1]
PART=BASE/'recall-audit'/'part-0'
def load(n): return json.loads((PART/f'page-{n:02}.json').read_text(encoding='utf-8'))
# Lossless judgement display: default fields stated, repeated complete values interned.
def show(n):
 d=load(n); cache={}; dic=[]; out=[]
 defaults={'topics':[],'target_regions':[],'time_mentions':[],'other_constraints':[],'possible_topics':[],'needs_review':[],'contact_boundaries':[],'context_used':['own','body']}
 def intern(v):
  s=json.dumps(v,ensure_ascii=False,separators=(',',':'))
  if s not in cache: cache[s]=len(dic);dic.append(v)
  return '@'+str(cache[s])
 for g in d['post_groups']:
  out.append('BODY '+g['video']+' '+g['post_body'])
  for c in g['comments']:
   j=c['first_semantic_judgment']; vals={k:v for k,v in j.items() if defaults.get(k,object())!=v}
   role=[vals.pop(k) for k in ['role','demand_state','interest']]
   for k in ['reason','reply_plan','needs_review']:
    if k in vals: vals[k]=intern(vals[k])
   out.append(c['key']+' '+json.dumps({'text':c['text'],'same_author':c['same_author'],'published':c['published_at'],'parent':c['parent'],'reply_to':c['reply_to'],'conflict':c['source_conflict'],'label':role,**vals},ensure_ascii=False,separators=(',',':')))
 print('PAGE',n,'DEFAULTS',json.dumps(defaults,ensure_ascii=False));print('DICT',json.dumps(dic,ensure_ascii=False,separators=(',',':')));print('\n'.join(out))
if __name__=='__main__':show(int(sys.argv[1]))
