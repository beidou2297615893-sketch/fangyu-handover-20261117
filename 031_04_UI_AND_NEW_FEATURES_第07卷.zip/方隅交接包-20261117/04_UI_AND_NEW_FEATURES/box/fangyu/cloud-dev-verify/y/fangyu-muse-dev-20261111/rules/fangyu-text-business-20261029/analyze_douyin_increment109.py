"""Assess the next saved 50 comments and write text sidecars, without platform calls."""
import json,sqlite3,hashlib,collections
from pathlib import Path
from datetime import datetime,timezone,timedelta
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=R/'work/fangyu-douyin-independent';D=W/'douyin-registered-v2'
O=R/'outputs/方隅双平台文本业务/抖音逐店采集与意向'
def load(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def find(x,vid):
 if isinstance(x,dict):
  if str(x.get('aweme_id',x.get('video_id','')))==vid and 'desc' in x:return x
  for z in x.values():
   y=find(z,vid)
   if y:return y
 if isinstance(x,list):
  for z in x:
   y=find(z,vid)
   if y:return y
 return None
decisions=[
 ('fifteenth','7701532268737151802','demand','high',['位置通勤','房源状态'],'火车站附近（具体车站未核）','在明确福州住宅出租正文下询问车站附近房源；不能仅凭IP或来源店确认具体车站。'),
 ('fifteenth','7701183517619716874','demand','high',['价格预算','房源状态'],None,'询问几百元档房源；保留几百原词，不编具体预算或门店报价。'),
 ('fifteenth','7695758165832925994','demand','high',['位置通勤','房源状态'],'晋安泰禾附近','指定地区询房；广东属地不覆盖该明确地区，不把原帖全部设施写成其硬要求。'),
 ('fifteenth','7700909749881062201','demand','high',['看房联系'],None,'在房源帖下请求对方联系，属于租赁联络意愿；不自动超高，也不当系统已获私信授权。'),
 ('fifteenth','7699294814412784441','demand','high',['入住与租期'],None,'明确询问短租，时长未给；原帖3个月起租不能倒填为本人需要3个月。'),
 ('fifteenth','7698613997637763899','unknown','uncertain',[],None,'只有问号，缺少指代；同一人另一条地名房型留言也未分清供需，不能升级本人需求。'),
 ('fifteenth','7695490422479029050','demand','high',['价格预算','房源状态'],None,'主动询问900左右的租住选择，按目标价位原词保存；不当门店现价。'),
 ('fifteenth','7698613936670114597','unknown','uncertain',['位置通勤','户型面积与居住方式','房内设施'],'附一旁（具体位置及供需未核）','地名加单间厨房，可能提出需求或借楼供房，缺动词与直接回复语境，暂不确定身份。'),
 ('fifteenth','7696933207497638690','demand','high',['宠物'],None,'向出租住宅询问可否养宠；不能推断具体宠物种类或本店宠物政策。'),
 ('fifteenth','7697564437859205925','demand','high',['位置通勤','房源状态'],'金山地铁站附近','本人指定地铁位置询房，门店服务范围待核。'),
 ('fifteenth','7700688141053133609','demand','high',['位置通勤'],None,'出租房源语境询问位置，不等于明确接受所在地区。'),
 ('fifteenth','7699545695725077288','demand','high',['位置通勤'],None,'出租房源语境询问在哪，不替本人填写目标城市。'),
 ('fifteenth','7697550745617531658','demand','high',['位置通勤'],None,'出租房源语境询问位置；只能确认询盘主题，门店匹配未核。'),
 ('fifteenth','7697448649769075493','demand','high',['位置通勤'],None,'对住宅房源问地点，不把帖主多个房源区域拼成其目标。'),
 ('fifteenth','7695322591774835514','unknown','uncertain',['位置通勤','户型面积与居住方式'],'晋安新店（供需关系待核）','只有地名和单间，可能供给也可能需求，不能凭词直接判高。'),
 ('fourteenth','7696410148839080763','demand','high',['价格预算'],None,'询问具体住宅租金；原帖1700是该帖报价，不能复制为本人预算或方隅现价。'),
 ('fourteenth','7696723904577225521','demand','high',['费用合同'],None,'具体房源询问中介费，不等于绝对拒绝中介。'),
 ('fourteenth','7696991551985550114','demand','high',['房源状态'],None,'询问这套是否仍在，属于当时具体询盘，不代表目前仍有或本人仍找。'),
 ('ninth-rental','7702015423881921317','demand','high',['房源状态'],None,'已找到对应七宝住宅出租正文，可解释还有么所问房态；不沿用误选买房视频。'),
 ('ninth-rental','7699733997777142554','demand','high',['价格预算','房源状态'],None,'本人明确最近一直找房并询问同价房源；1800仅为所问帖子参照，不当已核硬预算。'),
 ('ninth-rental','7700926105519522610','demand','high',['位置通勤','户型面积与居住方式'],'上海青浦区明珠路附近','明确合租需求及地区，男女不限为其合住接受条件；不能归上海龙柏店。'),
 ('ninth-rental','7699285612318491419','unknown','uncertain',['价格预算'],None,'只质疑价格真伪，可能围观或真实询盘，本人租赁需求未明确。'),
 ('ninth-rental','7700448395643044667','demand','high',['位置通勤','价格预算','房源状态'],'闵行','本人明确1500预算并等房源；闵行全区不能等同龙柏门店范围。'),
 ('ninth-rental','7699364504148656953','demand','medium',[],None,'明确正好要租房但本句尚未提出具体需求或明确约看，按评论时当前找房兴趣保留；真实性仍待核。'),
 ('ninth-rental','7699420892300428073','demand','high',['看房联系'],None,'住宅出租语境泛问能看吗，不是明确预约，不自动超高。'),
 ('ninth-rental','7700678601982034747','unknown','uncertain',['价格预算'],None,'我1.8k可能现租金或预算，不明所指，不能直接设预算1800。'),
 ('ninth-rental','7699356733126361898','demand','high',['位置通勤','看房联系'],None,'询问房源地点及是否可看，属于具体询盘；真实性疑问保留，未预约成功。'),
 ('ninth-rental','7699420726772318976','unknown','uncertain',[],None,'真的嘛可能围观或质疑对象，不能仅凭此确认本人求租。'),
 ('ninth-rental','7699325784997430058','unknown','uncertain',[],None,'仅询真实性，租房意图及指代未明，留待核。'),
 ('ninth-rental','7699469511305904931','demand','high',['房源状态'],None,'明确住宅房源语境下问是否仍在，不替原房东确认房态。'),
 ('ninth-rental','7699338877102195513','demand','high',['看房联系'],None,'对具体出租房源主动招呼并表示有意向；尚无明确约看或时间，不自动超高。'),
 ('ninth-rental','7699500326885671723','unknown','uncertain',[],None,'孤立数字1无法确定含义，不当房型或租赁意向。'),
 ('ninth-rental','7699412237614351153','demand','high',['位置通勤'],None,'对出租房源询问到地铁距离，不能自动认定接受所在地区或代填通勤分钟数。'),
 ('ninth-rental','7699098505072476982','demand','high',['位置通勤','房源状态'],'松江','主动寻找松江房源，不归龙柏店。'),
 ('ninth-rental','7701415570123047689','demand','high',['位置通勤'],None,'明确问房源位置，目标住址尚未自述。'),
 ('ninth-rental','7699480464121889593','demand','high',['房源状态'],None,'明确询问这套是否还在，当前状态仍未核。'),
 ('ninth-rental','7699303987224363776','demand','high',['看房联系'],None,'泛问可以看房，不等于预约或已确定时间。'),
 ('ninth-rental','7699281355250795315','demand','high',['位置通勤','房源状态'],'杭州','明确问杭州有没有，不能用上海搜索来源或IP变成龙柏需求。'),
 ('sixteenth','7692038995295224603','supply','unrelated',[],None,'明确个人转租滨浦七村供房，设施租金均是供应信息，不作本人新求租。'),
 ('sixteenth','7697982978747827002','supply','unrelated',[],None,'给求租作者推介沈杜公路房源及价位，不是本人找房。'),
 ('sixteenth','7696902952796242747','supply','unrelated',[],None,'借楼宣传一室一厅供房，未有本人新需求。'),
 ('sixteenth','7696678567690666809','supply','unrelated',[],None,'完整转租广告并邀看房，出租费用及设施不能进入本人需求池。'),
 ('sixteenth','7691973240537924390','unknown','uncertain',[],None,'仅有的，偏回应作者求租，但不足确认供应身份或独立本人需求，保留待核。'),
 ('thirteenth-page2','7697519549796729626','demand','high',['位置通勤','房源状态'],'未来之城边上','指定地区询房，未来之城原词保留，不改成未来科技城或北京未来云城。'),
 ('thirteenth-page2','7699102771215598346','demand','high',['位置通勤','房源状态'],'未来科技城附近','在租房话题下指定区域询房，安徽属地不代替本人目标。'),
 ('thirteenth-page2','7698979395436806939','demand','high',['位置通勤','房源状态'],'杭州余杭区丝腾中泰科创园附近','本人明确杭州余杭目标，贵州属地仅辅助；是否对应余杭店服务范围另核。'),
 ('thirteenth-page2','7697165888641844006','demand','high',['位置通勤','房源状态'],'余杭西溪北','本人指定区域找房，不能把视频其他推荐地区全部当作可接受范围。'),
 ('thirteenth-page2','7695284872982643519','discussion','unrelated',[],None,'请求博主出一期性价比大平层内容，未明确本人现在找；不将选题建议当高意向或预算。'),
 ('thirteenth-page2','7695255020916671275','demand','high',['位置通勤'],'创景路附近','在租房话题下主动寻求该区域推荐，按当时地区寻房需求保留；门店距离未核。'),
 ('thirteenth-page2','7695222119101580089','demand','medium',['位置通勤'],None,'本人说明菜鸟智谷工作地并比较适合居住小区；不把工作地直接填成目标住址，尚无具体房源询盘。'),
]
old=[json.loads(x) for x in (D/'classified-59.jsonl').read_text(encoding='utf8').splitlines()];assert len(old)==59
oldids={x['comment_id'] for x in old};new=[];source_cache={}
for pref in dict.fromkeys(x[0] for x in decisions):
 rp=B/f'{pref}-comments-raw.json';raw=load(rp);assert raw.get('source_correction',{}).get('eligible_for_relevant_collection') is not False
 direct=B/f'{pref}-search-raw.json';fallback=B/('thirteenth-search-raw.json' if pref=='thirteenth-page2' else 'ninth-search-raw.json');sp=direct if direct.exists() else fallback
 video=find(load(sp),str(raw['video']));assert video
 comments={str(c['cid']):c for c in raw['response']['comments'] if str(c['cid']) not in oldids};group=[x for x in decisions if x[0]==pref];assert set(comments)=={x[1] for x in group}
 for _,cid,role,level,topics,target,reason in group:
  c=comments[cid];t=c.get('text') or '';uid=str(c['user']['uid']);same=uid==str(video.get('author',{}).get('uid',''))
  x={'platform':'douyin','comment_id':cid,'customer_uid':uid,'video_id':str(c['aweme_id']),'comment_text':t,
   'published_at':datetime.fromtimestamp(c['create_time'],timezone(timedelta(hours=8))).isoformat(),'observed_at':raw['at'],
   'age_days_at_observation':round((datetime.fromisoformat(raw['at'].replace('Z','+00:00')).timestamp()-c['create_time'])/86400,2),
   'source_store':raw['store'],'source_store_raw':raw['store'],'source_keyword':raw['keyword'],'role':role,'interest_at_comment':level,'topics':topics,
   'topic_status':'本人需求主题' if role=='demand' else '待核话题' if role=='unknown' else '供给或讨论条件不作本人需求',
   'target_region_reference':target,'queried_property_region':None,'ip_location_raw':c.get('ip_label'),'ip_is_not_target_region':True,
   'post_body':video['desc'],'post_author_same_as_commenter':same,'post_body_conditions_are_own':same,
   'direct_parent_text':None,'reply_to':str(c.get('reply_id','0')),'deeper_reply_count_visible':c.get('reply_comment_total',0),'deeper_replies_read':False,
   'reason':reason,'evidence':[t] if t else [],'evidence_by_source':[{'source_kind':'own_comment','quote':t}],
   'context_flags':[],'review_reasons':([reason] if level=='uncertain' else [])+(['存在未读取的下级回复'] if c.get('reply_comment_total',0) else []),
   'current_need_verified':False,'assigned_store':None,'store_match_status':'未核；本人目标地区和来源搜索门店分开，所问原房源不是方隅现有房源',
   'rule_version':'business-text-20261029-v2','review_method':'新增50条模型语义判读；结构引用与独立账本本地核验','human_confirmed':False,'send_authorized':False,'send_attempted':False,
   'source_file':rp.name,'source_sha256':sha(rp),'search_file_sha256':sha(sp),'search_file':sp.name}
  new.append(x)
allrows=old+new;assert len(new)==50 and len(allrows)==len({x['comment_id'] for x in allrows})==109
excluded=load(D/'source-exclusions.json')[0];assert not {x['comment_id'] for x in allrows}&set(excluded['excluded_comment_ids'])
db=sqlite3.connect((B/'runtime/collection.sqlite3').as_uri()+'?mode=ro',uri=True);ledger_total=db.execute("select count(*) from entities where kind='comments'").fetchone()[0]
mother=next(x for x in load(W/'mothers/first50.json') if x['slot']==1);assert mother['user_approved']
for x in allrows:
 found=db.execute("select data from entities where kind='comments' and source_id=?",(x['comment_id'],)).fetchone();assert found
 c=json.loads(found[0]);assert c['text']==x['comment_text'] and str(c['aweme_id'])==x['video_id'] and str(c['user']['uid'])==x['customer_uid']
 assert db.execute('select 1 from observations where stable_key=? and keyword=?',('comment:'+x['comment_id'],x['source_keyword'])).fetchone()
 assert all(q in x['comment_text'] for q in x['evidence'])
 x.update(registration_state='verified_local_independent_ledger',ledger_keyword_association_verified=True)
 eligible=x['role']=='demand' and x['interest_at_comment'] in ['high','medium'] and not x['context_flags']
 x.update(mother_slot=1 if eligible else None,mother_reply_text=mother['template'] if eligible else None,
  reply_status='已认可母句本地套用，仅供审核；门店地区与当前需求未核，未授权发送' if eligible else '暂缓；本人需求、联系边界或启动时机未核',
  reply_scope='仅接话母句，不代表具体户型、价格和设施条件已全部满足',reply_generation_model_calls=0)
# Prevent replying twice to the same platform customer; retain the alternative text for auditing.
groups=collections.defaultdict(list)
for x in allrows:
 if x['mother_reply_text']:groups[x['customer_uid']].append(x)
duplicates=0
for xs in groups.values():
 xs.sort(key=lambda x:({'high':2,'medium':1}[x['interest_at_comment']],x['published_at']),reverse=True)
 for x in xs[1:]:x['alternative_mother_reply_text']=x['mother_reply_text'];x['mother_reply_text']=None;x['reply_status']='同客户已有更优候选，不重复入队';duplicates+=1
packed=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allrows);(D/'classified-109.jsonl').write_text(packed,encoding='utf8');(D/'increment-50.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in new),encoding='utf8')
by_source=collections.defaultdict(list)
for x in new:by_source[x['source_file']].append(x)
for name,xs in by_source.items():
 pref=name.removesuffix('-comments-raw.json');p=B/f'{pref}-text-screening-registered-v2.jsonl';p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in xs),encoding='utf8')
 (B/f'{pref}-text-screening-registered-receipt-v2.json').write_text(json.dumps({'source_file':name,'source_sha256':sha(B/name),'classified_unique_comments':len(xs),'ledger_registration_verified':True,'result_file':p.name,'result_sha256':sha(p),'rule_version':'business-text-20261029-v2','reply_generation_model_calls':0,'source_files_modified':False,'sent':0},ensure_ascii=False,indent=2),encoding='utf8')
stores=collections.defaultdict(list)
for x in allrows:stores[x['source_store']].append(x)
summary={'snapshot_unique_comments':109,'newly_analyzed':50,'previously_analyzed':59,'unique_customers':len({x['customer_uid'] for x in allrows}),
 'ledger_total_at_read':ledger_total,'snapshot_not_live_total':True,'out_of_scope_buying_comments_excluded':18,'excluded_comments_in_snapshot':0,
 'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in allrows)),'new_interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in new)),
 'by_source_store':{},'local_mother_drafts':sum(bool(x['mother_reply_text']) for x in allrows),'same_customer_duplicates_prevented':duplicates,
 'store_assignment_verified':0,'can_send_now':0,'reply_generation_model_calls':0,'platform_calls':0,'actual_sent':0,'source_or_ledger_modified':False}
lines=['# 抖音109条租房相关登记评论的意向汇总','',
'本次在已分析59条基础上新增分析50条，合计109条。全部按稳定评论标识、作品、作者、原文和搜索词关联与独立账本只读核对；已知误选买房视频18条单列排除，不进入本统计。固定快照不等于持续采集的实时累计。','',
'|来源门店|已分析评论|高|中|低|待核|供给或讨论|已核本店适配|','|---|---:|---:|---:|---:|---:|---:|---:|']
for name,xs in stores.items():
 c=collections.Counter(x['interest_at_comment'] for x in xs);summary['by_source_store'][name]={'comments':len(xs),**dict(c),'store_assignment_verified':0}
 lines.append(f'|{name}|{len(xs)}|{c["high"]}|{c["medium"]}|{c["low"]}|{c["uncertain"]}|{c["unrelated"]}|0|')
lines+=['', '兴趣等级针对本人在评论时的表达，不等于今天仍有效或该门店可承接。来源搜索门店不当作意向门店，工作地、明确目标、询问的原房源位置及IP分开。跨城市、别的区、预算、宠物、通勤和合同条件不自动拼成符合门店的需求。','',
'新增50条的难例：只质疑价位或房源真实性、孤立数字、地名加户型但供需不明留待核；明确“最近一直找房”保留本人需求；“出一期大平层攻略”是内容建议，不按大平层词判本人高意向；我1.8k可能现租金也可能预算；不会默认成预算。','',
'中高需求仅本地套用已认可接话母句，未逐条调用模型写回复，不冒称具体需求全部满足。原文存在的拒中介边界单独保留；同客户不重复入队。未查看视频画面、空文本附件或下级回复，没有深层评论采全证据，也没有执行发送。','']
for x in allrows:
 lines+=['────────','来源门店：'+x['source_store'],'原评论：'+(x['comment_text'] or '文字为空，附件未核'),'评论时间：'+x['published_at'],
  '意向：'+{'high':'高','medium':'中','low':'低，未来计划','uncertain':'待核','unrelated':'供给或讨论，无明确本人新需求'}[x['interest_at_comment']],
  '需求池：'+('、'.join(x['topics']) or '未确认具体本人需求池'),'地区线索：'+str(x.get('target_region_reference') or x.get('queried_property_region') or '本人目标地区未明确'),
  '依据：'+x['reason'],'待核与联系边界：'+'；'.join(x['context_flags']+x['review_reasons']+['当前需求和门店适配未核']),
  '本地母句审核稿：'+(x['mother_reply_text'] or '暂缓或同客户不重复生成'),'状态：未发送。','']
(O/'109条租房评论、逐店意向与母句.md').write_text('\n'.join(lines),encoding='utf8')
(D/'summary-109.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
(B/'text-screening-current-summary.json').write_text(json.dumps(dict(summary,result_file=str(D/'classified-109.jsonl'),report_file=str(O/'109条租房评论、逐店意向与母句.md')),ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
