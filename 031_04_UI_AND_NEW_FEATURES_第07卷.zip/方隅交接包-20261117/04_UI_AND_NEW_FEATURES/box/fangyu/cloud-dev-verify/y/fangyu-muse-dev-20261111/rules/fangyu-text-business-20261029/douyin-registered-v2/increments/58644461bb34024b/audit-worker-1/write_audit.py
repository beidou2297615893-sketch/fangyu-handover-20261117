import json, copy
from pathlib import Path
B=Path(__file__).resolve().parent.parent
W=Path(__file__).resolve().parent
def load_page(n):
    return json.loads((B/f'recall-audit/part-1/page-{n:02d}.json').read_text(encoding='utf-8-sig'))
def comments(n):
    return [c for g in load_page(n)['post_groups'] for c in g['comments']]
def build(n):
    by={c['key']:c for c in comments(n)}
    out={}
    def keep(keys,reason):
        for k in keys.split():
            assert k in by and k not in out,k
            out[k]={'review_key':k,'decision':'keep','reason':reason,'patch':{}}
    def change(k,audit_reason,**patch):
        assert k in by and k not in out,k
        out[k]={'review_key':k,'decision':'change','reason':audit_reason,'patch':patch}
    def planfacts(k,facts):
        p=copy.deepcopy(by[k]['first_semantic_judgment']['reply_plan'])
        p['missing_facts']+=facts
        change(k,'保留原询租身份和意向；专项母句还需联立核对本人区域、预算或居住条件，补具体事实缺口。',reply_plan=p)
    if n==0:
        keep('D0003 D0007 D0012 D0014 D0267 D0271 D0022 D0030 D0036 D0039 D0044 D0048 D0052 D0055 D0310 D0324 D0072 D0200 D0090 D0097 D0109 D0248 D0256 D0124 D0126 D0128 D0132 D0134 D0138 D0172 D0178 D0181 D0227 D0229 D0232 D0236 D0304 D0326 D0328 D0338','本人直接询租或提交住房条件；原判断保留多项联立、工作地与目标分开及时间角色，母句为待核候选，等级与证据一致。')
        keep('D0005','向租房中介询问联系为中等接洽线索，原判断已明确联系目的待核且没有当预约或超高。')
        keep('D0016 D0217 D0291','原文方向为提供房屋或商业场地，不是本人住宅求租，原供给身份及无租客推介方案准确。')
        keep('D0273 D0028 D0032 D0187 D0315 D0321 D0198 D0088 D0093 D0160 D0162 D0164 D0166 D0168 D0170 D0242 D0331','短句、价格感叹或地点关系不足以确认当前求租；原判断保留具体住房线索及歧义，不当高意向也不武断过滤。')
        keep('D0020 D0026','本人明确购房需求，原判断保留购房预算或居住容量，租赁兴趣无关且不套租房母句。')
        keep('D0018 D0024 D0034 D0185 D0057 D0077 D0079 D0081 D0083 D0207 D0209 D0211 D0213 D0219 D0221 D0348 D0119 D0121 D0142 D0148 D0154 D0158 D0234 D0244 D0279 D0283 D0285 D0287 D0289 D0293 D0296','明确为观点、经验建议、反讽或对他人视频的评价；原判断未把他人价格、房屋条件及地区转成本人找房要求。')
        keep('D0215 D0223','纯艾特未说明用途，原判断保留未知、无推介，不武断认定找房或完全无关。')
        keep('D0063','低价争议中出两千可为实际出价或调侃；原判断保留中等线索与反讽歧义并禁生成推介，未直接判高。')
        keep('D0059','若价格真实才要两套是附条件推进；原判断保留条件和两套数量，不当无条件订房或已成交。')
        keep('D0115','亲友搬家与长租诉求有后续机会，但本人只明确帮打包，未明确代租；原判断具体待核且未将历史开销变成新预算。')
        keep('D0140 D0144 D0146 D0150 D0152 D0156 D0275 D0277','原文为现居或明确历史费用经历，原判断没有转成新房预算、设施硬要求或入住计划。')
        change('D0050','只表达后面换房再找、当前先关注，没有现在筛房推进；未来低优先级比中等当前机会更贴合。',interest='low',reason='关注并计划后面换房再联系，未提出当前筛房动作；保留未来低优先级住房需求。')
        j=copy.deepcopy(by['D0085']['first_semantic_judgment'])
        t=j['topics'];t[0]['subject']='unresolved'
        p=j['reply_plan'];p.update(preferred_mother_slot=None,generic_intro_suitable=False,missing_facts=['商城路所指房源、交通攻略还是内容选题，以及本人是否正在找房待核'])
        change('D0085','商城路呢在租房指引下仍可能只是路线或选题追问；不能已判本人主动找房并推介。',role='unknown',demand_state='unknown',interest='uncertain',topics=t,reason='只追问商城路，所问房源或路线未明，保留住房地点线索待核。',reply_plan=p)
        j=copy.deepcopy(by['D0281']['first_semantic_judgment']);j['topics'][0]['subject']='unresolved';j['target_regions'][0]['relation']='unresolved'
        change('D0281','有人租可为试探招租，也可质疑马尾老城区有无租客；正文仅房租压力，供给身份不够确定。',role='unknown',demand_state='unknown',interest='uncertain',topics=j['topics'],target_regions=j['target_regions'],reason='询问马尾老城区是否有人租，可能试探招租或市场感叹，不能确定本人供房或找房。',needs_review=['是否本人提供房源、单纯谈论出租市场或有实际找房需求待核'])
        for k,f in [
          ('D0010','同一可租一室一厅须在本人要求的温江范围内，具体门店、预算和入住安排未核'),
          ('D0046','同一可租一室一厅须在真北路可接受范围且符合本人好点的品质偏好，报价未核'),
          ('D0313','同一可租一室户须在莘庄可接受范围内，便宜点的实际预算上限和全部费用未核'),
          ('D0319','同一两室房源须在虹口广灵二路附近，实际租金、全部费用和房态未核'),
          ('D0346','同一预算2k可承接房源须位于宝山顾村可接受范围，计价周期和全部必付费用待核'),
          ('D0130','同一预算2000房源能否兼顾798与亦庄两人地点、可接受通勤及整合租方式未核'),
          ('D0136','同一短租房源须满足龙泽地铁站范围及1500左右预算，实际短租时长、计价与房态未核'),
          ('D0225','同一房源能否在张江高科可接受范围支持两人合租、同住方式及费用未核'),
          ('D0238','同一预算2000房源须在静安可接受范围，计价周期与全部必付费用未核'),
          ('D0240','同一人广可接受范围房源能否满足一千预算、居住方式及全部必付费用未核')]:
            planfacts(k,[f])
    elif n==1:
        keep('D0350 D0354 D0356 D0358 D0492 D0494 D0498 D0500 D0502 D0504 D0412 D0428 D0432 D0462 D0471 D0474 D0478 D0480','明确为评价、费用观点、建议或对他人视频的分享；原判断未把他人房屋条件和价格转为本人求租。')
        keep('D0352 D0360 D0496 D0362 D0418 D0430 D0434 D0436 D0438 D0440 D0442 D0464 D0469 D0483','短询、否定或用途与主语未明，原判断保留具体线索及待核歧义；未当住宅高意向，未误扩拒联。')
        keep('D0368 D0370 D0372 D0376 D0444','纯艾特、省略号或空文本不足以辨意向；原判断保留未知且不作推介。')
        keep('D0374 D0378 D0380 D0382 D0384 D0386 D0467','本人方向明确是房东、中介或转租供给；原判断的设施费用和租期主体为供给，不自动补新租需求。')
        keep('D0490 D0416 D0420 D0422 D0424 D0426','本人分享现居面积、费用或用电经验；原判断未将现居条件转成新租要求，账单月份不当入住时间。')
        keep('D0388 D0392 D0394 D0401 D0404 D0410 D0414 D0447 D0452 D0460 D0476','本人主动询租、询房或提交租赁条件；原判断等级、时间与工作地/目标/查询地分开，母句仍是事实待核候选。')
        c=by['D0390']
        change('D0390','短租是本人明确租期方向，主题已保留但time_mentions遗漏，补租期时间角色而不编具体天数。',time_mentions=[{'quote':'短租','time_role':'lease_duration','anchor_source':'comment.published_at_unix','anchor_time':c['published_at'],'normalized':None,'verification':'本人只说短租，具体时长和起租日期待核；不是月计价或未来才找房'}])
        j=copy.deepcopy(by['D0454']['first_semantic_judgment']);j['target_regions'][0]['relation']='unresolved'
        change('D0454','杭州哪里是查询所询房源地址，不足以视为客户已自报居住目标；保留询租兴趣和查询地点。',target_regions=j['target_regions'],reason='房东租房语境下问所询房源在杭州哪里，有当时位置询租兴趣；杭州仅为查询地点，客户居住目标接受范围待核。',needs_review=['核所询房源真实地址、客户是否接受杭州及具体范围、当前是否仍在找房'])
        planfacts('D0406',['同一预算3500以下的整租房源能否满足三元桥工作地的通勤范围、具体居住户型和全部必付费用未核'])
    else:
        raise ValueError('unsupported page')
    assert set(out)==set(by),(set(by)-set(out),set(out)-set(by))
    p=B/f'recall-audit/part-1/page-{n:02d}.audit.jsonl'
    p.write_text(''.join(json.dumps(out[c['key']],ensure_ascii=False)+'\n' for c in comments(n)),encoding='utf-8')
    progress={'page':n,'records':len(out),'keep':sum(x['decision']=='keep' for x in out.values()),'change':sum(x['decision']=='change' for x in out.values()),'semantic_review':'independent model review; not human confirmed','formal_validation':'pending'}
    (W/f'page-{n:02d}.progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
    print(progress)
if __name__=='__main__':
    import sys
    build(int(sys.argv[1]))
