import json,collections,datetime
from decisions import BASE,PART,WORK
v=json.loads((WORK/'validation.json').read_text(encoding='utf8'));rows=[json.loads(l) for n in range(17) for l in (PART/f'page-{n:02}.audit.jsonl').read_text(encoding='utf8').splitlines()];changed=[r for r in rows if r['decision']=='change'];fields=collections.Counter(k for r in changed for k in r['patch'])
progress={'worker':'a','assigned_pages':list(range(17)),'completed_pages':list(range(17)),'records':2040,'changes':39,'keeps':2001,'status':'complete','validation':'passed','usage':'unknown','page17_owner':'root','updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(WORK/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
report='''# 独立语义复核记录

已完成原分派页中的第00—16页，共2040条；第17页按root后续消息由root接手，本worker未读写该页。

逐页阅读共享正文、本人评论及完整首轮判断。展示使用无损默认空字段、完整值字典及简写结构以减少重复；未用关键词程序重分类。每个已读key在本地序列化脚本中显式列入保留组或修订字典，未用程序默认补未读记录。

结果：2001条保留，39条修订。修订涵盖真实求租/预备关注的区分、主动承接房源等级、找了候选房尚未明确租好的未知状态、预算与地名断句、条件所属和否定范围、工作地与查询位置归属、租期与入住窗口、中介费与水电母句适配。没有按改变数量追求修订。

正式预检：使用原有mother_adapter.validate_new_review，对原判断合并补丁后在worker专属临时隔离目录补编译元数据并验证，2040条全部通过；临时合并文件已移除。没有修改adapter，也没有写入part汇总或全局状态。17页输入输出ID集合一致、无重复；3233个原句证据检查全部逐字通过。task记录的三份primary来源SHA保持不变。

结果不是人工金标或用户验收。仅分析当前登记文本，未读取更深回复，未核验当前仍找房或同店事实；门店指派保持null，未发送、未恢复采集、未读取凭据。contact_policy为文本边界判断，不是发送许可。usage未知，不能虚报token或credits。

修订key：
'''+', '.join(r['review_key'] for r in changed)+'\n\n补丁字段计数：'+json.dumps(dict(fields),ensure_ascii=False)+'\n\n各页计数及审计SHA见validation.json。原判留在原primary中；补丁单独留在每页.audit.jsonl中，worker脚本保留显式决定及两条母句事实联动补充过程。\n'
(WORK/'report.md').write_text(report,encoding='utf8');print(json.dumps(progress,ensure_ascii=False));print(dict(fields))
