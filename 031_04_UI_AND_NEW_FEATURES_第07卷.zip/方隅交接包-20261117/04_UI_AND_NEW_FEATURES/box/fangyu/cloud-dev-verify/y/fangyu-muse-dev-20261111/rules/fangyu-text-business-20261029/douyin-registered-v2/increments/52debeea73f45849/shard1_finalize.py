from shard1_helper import *
import collections, datetime
parts=['part-1-a.jsonl','part-1-b.jsonl','part-1-c.jsonl','part-1-d.jsonl']
out=[]
for f in parts:out.extend(json.loads(x) for x in (P/f).read_text(encoding='utf-8').splitlines())
assert len(rows)==386 and len(out)==386
# Preserve explicit alternatives and intersection independently of geographic inference.
for i in (50,189,322):
 for z in out[i]['target_regions']:
  if i != 189 or z['relation']=='desired':z['group_relation']='OR'
for z in out[226]['target_regions']:z['group_relation']='AND'
# Travel or work dates are distinct from lease and move-in dates.
out[10]['time_mentions'].append({'quote':'下周去北京朝阳区实习','time_role':'other','anchor_source':None,'anchor_time':None,'normalized':None,'verification':'指实习出行，相对时间未锚定；不等于入住日期'})
errors=[]
for x,o in zip(rows,out):
 text=x['comment_text'];k=x['review_key']
 for f in ('review_key','comment_id','customer_uid','video_id'):
  if x[f]!=o.get(f):errors.append([k,'identity',f])
 if o['role']=='unknown' and o['interest_at_comment']!='uncertain':errors.append([k,'unknown_interest'])
 if o['role'] not in ('demand','mixed') and o['topic_evidence']:errors.append([k,'topic_subject_role'])
 if set(o['topics'])!={z['pool'] for z in o['topic_evidence']}:errors.append([k,'topic_evidence_mismatch'])
 for q in o['evidence']:
  if not q or q not in text:errors.append([k,'evidence'])
 for field in ('topic_evidence','target_regions','other_constraints','possible_topics','time_mentions'):
  for z in o[field]:
   if not z.get('quote') or z['quote'] not in text:errors.append([k,'quote',field,z.get('quote')])
   if field=='topic_evidence' and (z['pool'] not in pools or z['subject']!='own_demand' or z['source_kind']!='comment'):errors.append([k,'topic',z])
   for pool in z.get('pools',[]):
    if pool not in pools:errors.append([k,'possible_pool',pool])
for f in ('review_key','comment_id'):
 if len({x[f] for x in rows}) != 386 or len({x[f] for x in out}) != 386 or {x[f] for x in rows}!={x[f] for x in out}:errors.append(['duplicate_or_mismatch',f])
if errors:raise ValueError(errors)
(P/'reviewed-1.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
v={'input_count':386,'output_count':386,'review_key_unique_count':len({x['review_key'] for x in out}),'comment_id_unique_count':len({x['comment_id'] for x in out}),'identity_fields_equal_in_order':True,'all_quotes_from_own_comment':True,'all_topic_pools_valid':True,'topic_and_evidence_match':True,'errors':errors,'role_counts':dict(collections.Counter(x['role'] for x in out)),'interest_counts':dict(collections.Counter(x['interest_at_comment'] for x in out)),'human_gold':False,'send_authorized':False,'limitations':'逐条模型语义初判，不是用户金标；程序校验身份、标签和引文，不能验证语义准确率、当前需求、资格、门店适配或房源事实。'}
(P/'validation-1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
claim=json.loads((P/'claim-1.json').read_text(encoding='utf-8'));claim.update(status='completed',completed_at=datetime.datetime.now().astimezone().isoformat(),input_count=386,output_count=386)
(P/'claim-1.json').write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(v,ensure_ascii=False,indent=2))
