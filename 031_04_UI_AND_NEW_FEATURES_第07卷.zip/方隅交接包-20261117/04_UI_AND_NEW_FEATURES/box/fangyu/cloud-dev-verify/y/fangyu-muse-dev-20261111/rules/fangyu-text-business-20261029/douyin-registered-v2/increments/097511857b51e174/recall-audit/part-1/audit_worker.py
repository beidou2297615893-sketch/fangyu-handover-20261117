import json, pathlib, sys, collections
BASE=pathlib.Path(__file__).parent
ROOT=BASE.parent.parent
def read(p): return json.loads(p.read_text('utf-8-sig'))
def show(n):
 for g in read(BASE/f'page-{n:02d}.json')['post_groups']:
  print('POST',g['video'],g['post_body'])
  for c in g['comments']:
   a=c['first_semantic_judgment']
   print(c['key'],c['text'],'|',a['role'],a['demand_state'],a['interest'],'|parent',c['parent'])
def build(n):
 spec=read(BASE/f'decisions-{n:02d}.json'); out=[]
 for group in spec['keep']:
  for key in group['keys'].split(): out.append({'review_key':key,'decision':'keep','reason':group['reason'],'patch':{}})
 for c in spec['change']:
  patch=c['patch']; reason=c['reason']
  patch.setdefault('reason',reason)
  if 'reply' in c:
   p=c['reply']; patch['reply_plan']={'preferred_mother_slot':p.get('slot'), 'generic_intro_suitable':p.get('suitable',False),'tone':p.get('tone','normal'),'missing_facts':p.get('missing',[]),'caution':p.get('caution',[]),'contact_policy':p.get('contact','unknown')}
  out.append({'review_key':c['key'],'decision':'change','reason':reason,'patch':patch})
 expected=[c['key'] for g in read(BASE/f'page-{n:02d}.json')['post_groups'] for c in g['comments']]
 assert len(out)==len(expected),(len(out),len(expected))
 assert len(set(x['review_key'] for x in out))==len(out)
 assert set(expected)==set(x['review_key'] for x in out),set(expected)-set(x['review_key'] for x in out)
 by={x['review_key']:x for x in out}; out=[by[k] for k in expected]
 if (BASE/'supplements.json').exists():
  for c in read(BASE/'supplements.json'):
   if c['key'] not in by: continue
   row=by[c['key']]; row['decision']='change'; row['reason']=c['reason']; row['patch'].update(c['patch']); row['patch']['reason']=c['reason']
   if 'reply' in c:
    p=c['reply']; row['patch']['reply_plan']={'preferred_mother_slot':p.get('slot'),'generic_intro_suitable':p.get('suitable',False),'tone':p.get('tone','normal'),'missing_facts':p.get('missing',[]),'caution':p.get('caution',[]),'contact_policy':p.get('contact','unknown')}
 (BASE/f'page-{n:02d}-decisions.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),'utf-8')
 allrows=[]; pages=[]
 for p in sorted(BASE.glob('page-??-decisions.jsonl')):
  rows=[json.loads(x) for x in p.read_text('utf-8').splitlines()]; allrows+=rows; pages.append({'page':p.name,'records':len(rows),'changes':sum(x['decision']=='change' for x in rows)})
 (ROOT/'recall-audit-1.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allrows),'utf-8')
 (BASE/'progress.json').write_text(json.dumps({'completed':len(allrows),'expected':1523,'pages':pages,'method':'模型逐条独立语义复核；程序仅展开已显式给定决策及校验身份集合'},ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps(pages[-1],ensure_ascii=False))
if __name__=='__main__':
 {'show':show,'build':build}[sys.argv[1]](int(sys.argv[2]))
