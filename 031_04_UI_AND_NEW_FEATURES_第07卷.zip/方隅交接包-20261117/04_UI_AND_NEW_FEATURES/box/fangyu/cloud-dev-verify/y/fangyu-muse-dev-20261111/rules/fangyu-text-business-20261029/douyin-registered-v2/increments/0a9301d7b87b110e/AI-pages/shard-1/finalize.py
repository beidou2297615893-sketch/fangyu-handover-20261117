import json,pathlib,hashlib,datetime,collections,sys,copy
BASE=pathlib.Path(__file__).resolve().parent
ROOT=BASE.parent.parent
WORK=ROOT.parent.parent.parent
TASK=json.loads((BASE/'task.json').read_text(encoding='utf-8'))
def read(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources=read(pathlib.Path(TASK['source_full_metadata_file']));source={r['review_key']:r for r in sources}
assert len(sources)==len(source)==TASK['comments']==2480
rows=[];page_provenance=[];page_keys=[]
for n in range(TASK['pages']):
 p=BASE/f'page-{n:02}.json';d=json.loads(p.read_text(encoding='utf-8'));rs=read(BASE/f'reviewed-{n:02}.jsonl');cmap={c['key']:(g,c) for g in d['shared_post_context'] for c in g['comments']}
 assert len(rs)==len(cmap) and {r['review_key'] for r in rs}==set(cmap)
 for k,(g,c) in cmap.items():
  s=source[k]
  assert c['text']==s['comment_text'] and g['post_body']==s['post_body'] and g['video']==s['video_id']
  assert c['same_author']==s['post_author_same_as_commenter'] and c['parent']==s['direct_parent_text']
  assert int(datetime.datetime.fromisoformat(c['published_at']).timestamp())==s['published_at_unix']
 page_keys.extend(cmap);rows.extend(rs)
 page_provenance.append({'page':n,'count':len(rs),'input_sha256':sha(p),'model_decisions_sha256':sha(BASE/f'decisions-{n:02}.txt'),'reviewed_sha256':sha(BASE/f'reviewed-{n:02}.jsonl')})
assert len(page_keys)==len(set(page_keys))==2480 and set(page_keys)==set(TASK['expected_review_keys'])==set(source)
bykey={r['review_key']:r for r in rows};assert len(rows)==len(bykey)==2480
rows=[bykey[s['review_key']] for s in sources]
assert set((r['review_key'],r['comment_id'],r['customer_uid'],r['video_id']) for r in rows)==set((s['review_key'],s['comment_id'],s['customer_uid'],s['video_id']) for s in sources)
errors=[];quote_count=0
roles={'demand','supply','mixed','discussion','unknown'};states={'active_at_comment','future','ended','historical','unknown'};levels={'super_high','high','medium','low','very_low','uncertain','unrelated'}
pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
for r in rows:
 s=source[r['review_key']]
 for f in ['comment_id','customer_uid','video_id','comment_text','source_comment_sha256','source_stable_key']:
  assert r[f]==s[f],(r['review_key'],f)
 assert hashlib.sha256(r['comment_text'].encode('utf-8')).hexdigest()==r['source_comment_sha256']
 assert r['role'] in roles and r['demand_state'] in states and r['interest'] in levels
 assert not(r['role']=='unknown' and r['interest']=='unrelated')
 assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
 assert r['context_used']==['own','body'] # Every complete page body and own comment was read; no parents present.
 allowed=[s['comment_text']]+([s['post_body']] if s['post_author_same_as_commenter'] else [])
 for f in ['evidence','topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
  assert isinstance(r[f],list)
  for v in r[f]:
   q=v if isinstance(v,str) else v.get('quote','')
   if q:
    quote_count+=1
    if not any(q in t for t in allowed):errors.append({'key':r['review_key'],'field':f,'quote':q})
 assert all(t['pool'] in pools for t in r['topics'])
 p=r['reply_plan'];assert set(['preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy'])<=set(p)
 assert p['preferred_mother_slot'] in [None,1,2,7,13,16,19,25,28,31,34]
 assert type(p['generic_intro_suitable']) is bool and p['tone'] in ['normal','serious']
 assert p['contact_policy'] in ['allow','identity_restricted','no_contact','unknown']
 if p['preferred_mother_slot']:assert p['missing_facts'] and p['caution']
assert not errors,errors
out=ROOT/'reviewed-new-1.jsonl'
out.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rows),encoding='utf-8')
# Check the existing downstream validator with an actual isolated derivative containing
# only the compiler metadata it will add. No independent review is claimed.
sys.path.insert(0,str(WORK));from mother_adapter import validate_new_review
schema_rows=copy.deepcopy(rows)
for r in schema_rows:
 r['classification_method']='ai_semantic_initial_and_detailed';r['classification_stages_completed']=['initial_semantic','detailed_semantic'];r['independent_recall_reviewed']=False
schema_path=BASE/'compiled-schema-check.jsonl';schema_path.write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in schema_rows),encoding='utf-8')
cache={}
for r in schema_rows:
 v=copy.deepcopy(r);v['classification_review_source']={'path':str(schema_path),'sha256':sha(schema_path)};validate_new_review(v,ROOT,cache)
result={'shard':1,'input_count':len(sources),'output_count':len(rows),'expected_count':TASK['comments'],'pages':TASK['pages'],'unique_review_keys':len(bykey),'key_sets_equal':True,'full_identity_tuple_sets_equal':True,'comment_id_uid_video_matches':True,'input_page_text_body_video_author_time_matches':True,'source_comment_sha256_verified':True,'verbatim_quote_count':quote_count,'verbatim_errors':errors,'all_human_confirmed_false':True,'all_send_authorized_false':True,'all_store_assignment_null':True,'context_used':['own','body'],'direct_parent_rows':0,'classification_method':'model_per_comment_initial_and_detailed_semantic_review','grouped_notation':'Explicit key lists represent individually read model choices; serializer does no text inference.','independent_second_review_performed':False,'downstream_schema_check_with_compiler_metadata':True,'primary_output_metadata_policy':'Existing parent compiler adds classification stages and provenance; primary judgments do not claim independent review.','source_sha256':sha(pathlib.Path(TASK['source_full_metadata_file'])),'output_sha256':sha(out),'role_counts':dict(collections.Counter(r['role'] for r in rows)),'interest_counts':dict(collections.Counter(r['interest'] for r in rows)),'contact_policy_counts':dict(collections.Counter(r['reply_plan']['contact_policy'] for r in rows)),'mother_slot_counts':dict(collections.Counter(str(r['reply_plan']['preferred_mother_slot']) for r in rows)),'page_provenance':page_provenance,'platform_calls':0,'sent':0,'source_modified':False,'usage':'unknown','limitations':['AI judgments are not human gold labels or current intent confirmation.','No independent second reviewer or zero-miss accuracy claim.','Source post facts are context only and not verified Fangyu inventory.','Deep replies, visual/video contents and present platform status were not inspected.','Reply plans are approved mother-slot candidates, not generated reply bodies or sending permission.']}
(ROOT/'shard-1-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
report=f'''# 抖音分片判读完成记录\n\n本分片2480条已逐条阅读本人评论及所属帖子正文，完成语义初筛和细筛；14页分别落盘。结果为模型判断，未人工确认，未执行发送。\n\n输入和输出均为2480条，review_key、comment_id、customer_uid、video_id组合逐条一致，无重复或缺失。每页原文、正文、视频、同作者标识及发表时间已与完整元数据核对。共核查{quote_count}处逐字证据，错误0；下游结构校验在隔离派生文件补入既有compiler字段后通过。\n\n角色分布：{json.dumps(result['role_counts'],ensure_ascii=False)}\n\n意向分布：{json.dumps(result['interest_counts'],ensure_ascii=False)}\n\n联系策略：{json.dumps(result['contact_policy_counts'],ensure_ascii=False)}。allow仅表示未表达文本联系限制，不是发送许可。三个身份限制保留本人逐字证据；给博主的找房建议不扩大为本人拒联。\n\n每条语义决定保留在decisions文件，包含明确列出的每个key；同义纯讨论或纯互动可共享同一已判断结论。serializer仅展开显式决定、拼接身份、格式化证据和做校验，不按关键词、正则或词库分类，不根据未列出的记录补默认意向。表格化判读仍存在模型误判风险。\n\n上下文仅登记实际读取的own、body；本分片没有direct parent文本。帖子他人条件不移给客户，同作者正文仍核查供需主体。未读深层回复、视频画面或平台最新状态。需求时态、入住日期、租期、月计价与地区作用分别保留；米等歧义留possible_topics。\n\n只选择已认可母句槽位并保留真实住户、优惠、对接权限和同店同房源事实缺口，未重写回复正文。明确不租公寓的记录不适用通用公寓介绍。所有条目human_confirmed=false、send_authorized=false、store_assignment=null。\n\n初筛及细筛由同一模型逐条完成，未冒称独立二审；分类阶段与provenance由既有compiler汇总。无平台调用，无发布，无凭据读取，无源库修改。Token/credits使用量未知，未购买额度。\n\n输出SHA256：{result['output_sha256']}\n'''
(ROOT/'shard-1-report.md').write_text(report,encoding='utf-8')
progress=json.loads((BASE/'progress.json').read_text(encoding='utf-8'));progress.update(status='complete',completed_comments=len(rows),validation_file=str(ROOT/'shard-1-validation.json'),output_file=str(out),output_sha256=sha(out));(BASE/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['page_provenance','limitations','mother_slot_counts']},ensure_ascii=False))
