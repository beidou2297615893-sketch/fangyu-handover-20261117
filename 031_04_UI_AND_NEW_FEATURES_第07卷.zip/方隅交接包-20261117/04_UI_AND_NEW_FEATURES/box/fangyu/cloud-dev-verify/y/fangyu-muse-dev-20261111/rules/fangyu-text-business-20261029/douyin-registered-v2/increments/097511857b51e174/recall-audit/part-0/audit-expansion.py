import json,sys,hashlib
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
PART=Path(__file__).resolve().parent
PRIMARY={}
for f in BASE.glob('reviewed-new-*.jsonl'):
 for l in f.open(encoding='utf-8-sig'):
  x=json.loads(l); PRIMARY[x['review_key']]=x

def plan(reason,kind,old):
 if kind in ('U','M'):
  return dict(preferred_mother_slot=None,generic_intro_suitable=False,tone='normal',missing_facts=[reason],caution=['仅保留待核机会；未确认找房动作前不出介绍草稿','不得自动发送；allow也不代表发送授权'],contact_policy='unknown')
 p=old.get('reply_plan',{}).copy()
 if not p.get('generic_intro_suitable'):
  p=dict(preferred_mother_slot=None,generic_intro_suitable=True,tone='normal',missing_facts=['本人当前找房需求及可承接门店','方隅房源和实际对接权限'],caution=[],contact_policy='allow')
 p['caution']=list(dict.fromkeys(p.get('caution',[])+['意向是评论时状态；今日是否仍需租房待核','泛看房询问不代表已预约；不得自动发送']))
 return p

def main(page):
 source=PART/f'page-{page:02d}.json'; data=json.loads(source.read_text(encoding='utf-8-sig'))
 cm={c['key']:c for g in data['post_groups'] for c in g['comments']}
 out=[]
 for line in (PART/f'page-{page:02d}.decisions.tsv').read_text(encoding='utf-8-sig').splitlines():
  if not line.strip():continue
  vals=line.split('\t',3); key,kind,reason=vals[:3]; extra=json.loads(vals[3]) if len(vals)>3 else {}
  assert key in cm,key
  old=PRIMARY[key]; patch={}
  if kind!='K':
   if kind=='U':patch.update(role='unknown',demand_state='unknown',interest='uncertain',needs_review=[reason],reply_plan=plan(reason,kind,old))
   elif kind=='M':patch.update(role='demand',demand_state='unknown',interest='medium',needs_review=[reason],reply_plan=plan(reason,kind,old))
   elif kind=='H':patch.update(role='demand',demand_state='active_at_comment',interest='high',reply_plan=plan(reason,kind,old))
   elif kind!='X':raise ValueError(kind)
   patch['reason']=reason
   patch.update(extra)
   patch={k:v for k,v in patch.items() if old.get(k)!=v}
   if any(k in patch for k in ['role','demand_state','interest']) and 'reply_plan' not in patch:
    patch['reply_plan']=plan(reason,'U' if patch.get('interest',old['interest'])=='uncertain' else 'H',old)
  assert (kind=='K')== (not patch),key
  for fld in ['topics','target_regions','time_mentions']:
   for q in patch.get(fld,[]): assert q['quote'] in cm[key]['text'],(key,fld,q)
  out.append(dict(review_key=key,decision='keep' if kind=='K' else 'change',reason=reason,patch=patch))
 assert len(out)==len(cm) and len(set(x['review_key'] for x in out))==len(cm),(len(out),len(cm))
 assert set(cm)==set(x['review_key'] for x in out)
 dest=PART/f'page-{page:02d}.audit.jsonl';dest.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out),encoding='utf-8')
 pages=sorted(PART.glob('page-*.audit.jsonl')); allout=[json.loads(l) for f in pages for l in f.read_text(encoding='utf-8').splitlines()]
 (BASE/'recall-audit-0.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in allout),encoding='utf-8')
 (PART/'progress.json').write_text(json.dumps(dict(completed_pages=[f.name for f in pages],reviewed_records=len(allout),changed=sum(x['decision']=='change' for x in allout),total=1523,method='逐条读取原评论和正文后显式决策；脚本仅展开明确决定和校验'),ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(dict(page=page,count=len(out),changes=sum(x['decision']=='change' for x in out),total=len(allout)),ensure_ascii=False))
if __name__=='__main__':main(int(sys.argv[1]))
