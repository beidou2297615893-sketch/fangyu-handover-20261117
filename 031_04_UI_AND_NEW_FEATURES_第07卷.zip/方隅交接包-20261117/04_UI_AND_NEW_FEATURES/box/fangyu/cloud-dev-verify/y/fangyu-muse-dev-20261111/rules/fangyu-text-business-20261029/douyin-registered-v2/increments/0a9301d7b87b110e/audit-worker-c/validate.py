from decisions import *
import hashlib,importlib.util
allowed={'role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','contact_boundaries','context_flags','reply_plan'}
primary={}
for f in B.glob('reviewed-new-*.jsonl'):
 for s in f.read_text(encoding='utf-8').splitlines():
  r=json.loads(s);assert r['review_key'] not in primary;primary[r['review_key']]=r
errors=[];merged=[];stats=[];changes=[]
for n in range(9,26):
 rows=load(n);audit=[json.loads(s) for s in (P/f'page-{n:02}.audit.jsonl').read_text(encoding='utf-8').splitlines()]
 assert len(audit)==len(rows)==len({a['review_key'] for a in audit});assert {a['review_key'] for a in audit}==set(rows)
 for a in audit:
  key=a['review_key'];g,c=rows[key]; assert set(a)=={'review_key','decision','reason','patch'}
  assert a['decision'] in ['keep','change'];assert set(a['patch'])<=allowed;assert a['reason'].strip()
  if a['decision']=='keep': assert not a['patch']
  else:assert a['patch'];changes.append(key)
  r=copy.deepcopy(primary[key]);r.update(a['patch']);assert str(r['video_id'])==g['video']
  # first_judgment fields are a reduced unchanged projection of the primary, then audit patch replaces fields.
  assert all(primary[key].get(f)==v for f,v in c['first_semantic_judgment'].items()), key
  corpus=c['text']+ ('\n'+g['post_body'] if c.get('same_author') else '')
  for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
   for it in r.get(f,[]):
    if isinstance(it,dict) and isinstance(it.get('quote'),str) and it['quote'] not in corpus:errors.append(dict(key=key,field=f,quote=it['quote'],comment=c['text']))
  for ev in r['evidence']:
   if ev not in corpus:errors.append(dict(key=key,field='evidence',quote=ev,comment=c['text']))
  if r['reply_plan']['preferred_mother_slot'] not in [None,1,2,7,13,16,19,25,28,31,34]:errors.append(dict(key=key,field='slot'))
  assert r['human_confirmed'] is False and r['send_authorized'] is False and r['store_assignment'] is None
  merged.append(r)
 stats.append(dict(page=n,input_count=len(rows),output_count=len(audit),change_count=sum(a['decision']=='change' for a in audit)))
print(json.dumps({'stats':stats,'total':len(merged),'changes':len(changes),'quote_errors':errors},ensure_ascii=False,indent=2))
# Parent authorized durable helper JSONL for isolated metadata validation.
# Primary and production metadata are unchanged.
assert not errors, errors
spec=importlib.util.spec_from_file_location('mother_adapter',B.parents[2]/'mother_adapter.py')
adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
fixture=W/'preflight-compiled.jsonl'
for r in merged:
 r['classification_method']='ai_independent_semantic_fine_review'
 r['classification_stages_completed']=['initial_semantic','detailed_semantic','independent_semantic']
 r.pop('classification_review_source',None)
raw=''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in merged).encode('utf-8')
fixture.write_bytes(raw);source_sha=hashlib.sha256(raw).hexdigest();cache={};formal=[]
for r in merged:
 test=copy.deepcopy(r)
 test['classification_review_source']={'path':str(fixture.resolve()),'sha256':source_sha}
 try:adapter.validate_new_review(test,B,cache)
 except Exception as ex:formal.append(str(ex))
primary_shas=[]
task=json.loads((P/'task.json').read_text(encoding='utf-8'))
for source in task['primary_sources']:
 actual=hashlib.sha256((B/source['path']).read_bytes()).hexdigest()
 primary_shas.append(dict(path=source['path'],actual_sha256=actual,expected_sha256=source['sha256'],unchanged=actual==source['sha256']))
 assert actual==source['sha256']
validation=dict(worker='c',status='passed' if not formal else 'failed',scope='part-1/page-09.json through page-25.json only',pages=stats,total_records=len(merged),change_count=len(changes),keep_count=len(merged)-len(changes),id_coverage_exact=True,duplicate_count=0,all_decisions_explicit=True,quote_errors=errors,formal_validator='work/fangyu-text-business-20261029/mother_adapter.py::validate_new_review',formal_checked=len(merged),formal_errors=formal,isolated_metadata_only=True,isolated_source_sha256=source_sha,isolated_source_lifecycle='Durable helper JSONL preflight-compiled.jsonl, actual SHA bound and reproducible by validate.py.',primary_sources=primary_shas,audit_sha256={f'page-{n:02}':hashlib.sha256((P/f'page-{n:02}.audit.jsonl').read_bytes()).hexdigest() for n in range(9,26)},usage='unknown')
assert len({r['review_key'] for r in merged})==len(merged)
assert {r['review_key'] for r in merged} <= set(task['expected_review_keys'])
validation['quote_check_count']=sum(len(r.get(f,[])) for r in merged for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries','evidence'])
(W/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'formal_checked':len(merged),'formal_errors':formal,'primary_unchanged':all(x['unchanged'] for x in primary_shas)},ensure_ascii=False))
assert not formal,formal
progress=json.loads((W/'progress.json').read_text(encoding='utf-8'));progress.update(status='completed',total_records=len(merged),change_count=len(changes),keep_count=len(merged)-len(changes),formal_preflight='passed',usage='unknown');(W/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
