import pathlib,json,collections,datetime,hashlib
B=pathlib.Path(__file__).parent;R=B.parent.parent
T=json.loads((B/'task.json').read_text(encoding='utf-8'))
src=[json.loads(x) for x in pathlib.Path(T['source_full_metadata_file']).read_text(encoding='utf-8').splitlines() if x.strip()]
by={x['review_key']:x for x in src};assert len(src)==len(by)==T['comments']==2480
assert set(by)==set(T['expected_review_keys'])
pages=[];flat={};page_counts={}
for n in range(T['pages']):
 p=json.loads((B/f'page-{n:02}.json').read_text(encoding='utf-8'));page_counts[n]=0
 for post in p['shared_post_context']:
  for c in post['comments']:
   key=c['key'];assert key not in flat;flat[key]=(post,c);m=by[key]
   assert post['video']==m['video_id']
   assert post['post_body']==m['post_body']
   assert c['text']==m['comment_text']
   assert c['same_author']==m['post_author_same_as_commenter']
   assert c['parent']==m['direct_parent_text']
   assert c['reply_to']==m['reply_to']
   assert c['source_conflict']==m['source_version_conflict']
   assert datetime.datetime.fromisoformat(c['published_at']).timestamp()==m['published_at_unix']
   page_counts[n]+=1
 rows=[json.loads(x) for x in (B/f'reviewed-{n:02}.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
 assert len(rows)==page_counts[n]
 assert {x['review_key'] for x in rows}=={c['key'] for p in p['shared_post_context'] for c in p['comments']}
 pages.extend(rows)
assert len(flat)==len(pages)==len({x['review_key'] for x in pages})==T['comments']
assert set(flat)==set(by)=={x['review_key'] for x in pages}
allowed_pools={'价格预算','位置通勤','户型面积与居住方式','房内设施','宠物','楼层电梯','入住与租期','房源状态','费用合同','看房联系'}
allowed_mothers={1,2,7,13,16,19,25,28,31,34};quotes_checked=0
required={'review_key','platform','comment_id','customer_uid','video_id','role','demand_state','interest','topics','target_regions','time_mentions','other_constraints','possible_topics','evidence','reason','context_used','needs_review','human_confirmed','send_authorized','store_assignment','reply_plan'}
for row in pages:
 key=row['review_key'];m=by[key];post,c=flat[key]
 assert required<=set(row),(key,required-set(row))
 for f in ['review_key','platform','comment_id','customer_uid','video_id','source_comment_sha256']:assert row[f]==m[f],(key,f)
 assert row['human_confirmed'] is False and row['send_authorized'] is False and row['store_assignment'] is None
 assert row['role'] in ['demand','supply','mixed','unknown','discussion']
 assert row['demand_state'] in ['active_at_comment','future','ended','historical','unknown']
 assert row['interest'] in ['super_high','high','medium','low','very_low','uncertain','unrelated']
 assert row['role']!='unknown' or row['interest']!='unrelated'
 assert row['context_used']==['own','body']+(['parent'] if c['parent'] else [])
 allowed=[m['comment_text']]+([m['post_body']] if c['same_author'] is True else [])
 def quote_check(q):
  global quotes_checked
  assert isinstance(q,str) and q and any(q in s for s in allowed),(key,'quote',q)
  quotes_checked+=1
 for q in row['evidence']:quote_check(q)
 for f in ['topics','target_regions','time_mentions','other_constraints','possible_topics','contact_boundaries']:
  for x in row.get(f,[]):
   if isinstance(x,dict) and 'quote' in x:quote_check(x['quote'])
 for x in row['topics']:
  assert x['pool'] in allowed_pools
  assert x['polarity'] in ['ask','require','prefer','reject','accept','conditional','fact','not_required','compare','unknown']
  assert x['subject'] in ['own_demand','supply','current_home','other_person','unresolved']
 for x in row['target_regions']:
  assert x['relation'] in ['desired','preferred','accepted','excluded','work','current_home','offered','unresolved']
  assert x['group_relation'] in ['AND','OR','unknown']
 for x in row['time_mentions']:
  assert x['time_role'] in ['move_in','viewing','lease_duration','search_start','other']
  assert x['anchor_time']==c['published_at']
 rp=row['reply_plan'];assert {'preferred_mother_slot','generic_intro_suitable','tone','missing_facts','caution','contact_policy'}<=set(rp)
 assert rp['contact_policy'] in ['allow','identity_restricted','no_contact','unknown']
 assert rp['preferred_mother_slot'] is None or rp['preferred_mother_slot'] in allowed_mothers
 assert not rp['generic_intro_suitable'] or any('通用推荐' in x for x in rp['missing_facts'])
 assert rp['preferred_mother_slot'] is None or rp['missing_facts']
 assert 'reply_text' not in row and 'reply_text' not in rp
out=pathlib.Path(T['output_file']);ordered={x['review_key']:x for x in pages}
content=''.join(json.dumps(ordered[x['review_key']],ensure_ascii=False)+'\n' for x in src)
out.write_text(content,encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
stats={f:dict(collections.Counter(str(x[f]) for x in pages)) for f in ['role','demand_state','interest']}
stats['contact_policy']=dict(collections.Counter(x['reply_plan']['contact_policy'] for x in pages))
stats['mother_slot']=dict(collections.Counter(str(x['reply_plan']['preferred_mother_slot']) for x in pages))
val={'shard':0,'validated_at':now,'expected_count':T['comments'],'input_count':len(src),'output_count':len(pages),'pages_read_and_completed':list(range(T['pages'])),'page_counts':page_counts,'id_sets_equal':True,'unique_review_keys':len(ordered),'unique_comment_ids':len({x['comment_id'] for x in pages}),'identity_fields_checked':['review_key','platform','comment_id','customer_uid','video_id','source_comment_sha256'],'identity_mismatches':0,'page_metadata_match':True,'quote_occurrences_checked':quotes_checked,'invalid_quotes':0,'schema_errors':0,'authorization_flags_valid':True,'contact_policy_values_valid':True,'approved_mother_slots_only':True,'selected_and_generic_mother_fact_gaps_present':True,'source_sha256':sha(pathlib.Path(T['source_full_metadata_file'])),'output_sha256':sha(out),'stats':stats,'with_needs_review':sum(bool(x['needs_review']) for x in pages),'platform_calls':0,'source_database_writes':0,'sent_count':0,'fees':'unknown','method':'本代理逐条阅读14页完整正文、评论、时间与可见上下文；显式模型语义初细筛合并判读，本地仅序列化与确定性校验；非独立二审、人工金标或用户认可','limitations':['未读取未提供的更深回复、图像或视频画面；仅使用页面给定文本及同作者标记','active_at_comment仅表示原评论时动作，未验证今日是否仍求租','地区、预算、租购、模糊表达未知保留，待核不等于无需求','未核门店即时房源、报价、优惠、真实住户及介绍资格，所有话术方案均非发送许可','本次未独立二审，root另做风险复核；错误与遗漏风险仍存在']}
(R/'shard-0-validation.json').write_text(json.dumps(val,ensure_ascii=False,indent=2),encoding='utf-8')
progress=json.loads((B/'progress.json').read_text(encoding='utf-8'));progress.update(status='completed_model_review_and_local_validation',completed_count=len(pages),updated_at=now,validation_file=str(R/'shard-0-validation.json'),output_file=str(out),independent_second_review=False)
(B/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
report=f'''# 抖音本批分片0判读与校验记录

已完成14页、2480条显式模型语义初筛与细筛合并判读。页00原决定保留，以corrected文件修复错引、遗漏和部分角色；页02、04、11相对日期归一保守修正也另存，未删除原决定。

输入和输出均为2480条；review_key、comment_id、customer_uid、video_id、platform及原文散列逐条与本批完整metadata核对，ID集合相同，无重复、缺漏或串片。14页正文、评论、时间、同作者和来源冲突等字段与源metadata一致。逐字证据出现次数校验{quotes_checked}，错误0。schema、认可母句槽位、联系策略、权限标记校验通过。

意向计数：{json.dumps(stats['interest'],ensure_ascii=False)}。
角色计数：{json.dumps(stats['role'],ensure_ascii=False)}。
联系策略：{json.dumps(stats['contact_policy'],ensure_ascii=False)}。
需进一步核实的记录：{val['with_needs_review']}条。

所有记录human_confirmed=false、send_authorized=false、store_assignment=null。allow仅为文本未表达拒联，不是发送授权。母句只选已认可槽位，没有改写或生成正文；已选母句和适用通用介绍的事实缺口均保留。无平台调用、无发送、无源数据库写入、无发布或冻结；未改变其他分片或总状态。费用未知，本代理未购买额度。

## 局限

本次为同一代理逐条初细筛合并判读，不冒充独立二审或人工验收。没有读未提供的更深回复、图像或视频；context_used只记录实际读过的own/body，存在parent才计parent。active_at_comment不等于今日仍有效。模糊租购、预算单位、时区、指代或新租状态均保留待核；母句所需真实住户、门店房源报价优惠和介绍权限均未核实。root将另行独立风险复核，本片现已停止，不自行发布。

输入SHA256：{val['source_sha256']}

输出SHA256：{val['output_sha256']}
'''
(R/'shard-0-report.md').write_text(report,encoding='utf-8')
print(json.dumps({k:val[k] for k in ['input_count','output_count','id_sets_equal','quote_occurrences_checked','invalid_quotes','schema_errors','stats','with_needs_review','output_sha256']},ensure_ascii=False))
