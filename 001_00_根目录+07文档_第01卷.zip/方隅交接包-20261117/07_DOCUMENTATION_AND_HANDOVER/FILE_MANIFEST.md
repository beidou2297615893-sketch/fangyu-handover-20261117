# FILE_MANIFEST

完整逐文件清单（包内路径、源路径、大小、SHA256、修改时间、included/duplicate）在 07 包的 `07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part01.zip, 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part02.zip, 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part03.zip, 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part04.zip`（共 70,073,738 B；超长清单按 .contNN 续写），脱敏清单 `*.redactions.csv` 也在其中。被排除文件的逐条清单可能含敏感文件名，只放在 `_LOCAL_ONLY_DO_NOT_UPLOAD\excluded-lists`，这里只列计数。

## 各打包单元

| 单元 | 收录(唯一) | 重复(只存一份) | 收录字节 | 脱敏副本 |
|---|---|---|---|---|
| 01_CORE_SOURCE.box | 1,504 | 118 | 28,282,680 | 14 |
| 01_CORE_SOURCE.fangyu | 60,532 | 979,640 | 789,624,212 | 3573 |
| 01_CORE_SOURCE.quiz | 12,331 | 19,825 | 116,285,925 | 96 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | 925 | 4,531 | 50,192,918 | 6 |
| 03_CURRENT_VERSION.rmsama | 856 | 481 | 63,898,885 | 2 |
| 04_UI_AND_NEW_FEATURES.box | 9,240 | 8,590 | 237,722,167 | 133 |
| 05_GIT.gitbuild.s1 | 1,459 | 0 | 8,129,874 | 10 |
| 05_GIT.gitbuild.s2 | 1,460 | 0 | 8,136,654 | 10 |
| 05_GIT.gitbuild.s3 | 1,473 | 0 | 8,173,628 | 10 |
| 05_GIT.gitbuild.s4 | 88 | 0 | 25,278,553 | 0 |
| 05_GIT.gitbuild.s5 | 125 | 0 | 23,175,548 | 0 |
| 05_GIT.gitbuild.s6 | 384 | 0 | 29,235,418 | 0 |
| 05_GIT.gitbuild.s7 | 490 | 0 | 51,816,908 | 0 |
| 05_GIT.gitbuild.s8 | 191 | 0 | 25,880,022 | 0 |
| 05_GIT.gitbuild.s9 | 15,699 | 0 | 120,062,817 | 98 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | 270 | 55 | 5,749,405 | 1 |

## 排除原因计数

| 单元 | 原因 | 数量 |
|---|---|---|
| 01_CORE_SOURCE.box | customer_data_fields | 7 |
| 01_CORE_SOURCE.box | data_ledger | 37 |
| 01_CORE_SOURCE.box | data_or_evidence_dir | 5 |
| 01_CORE_SOURCE.box | image_too_large_for_profile | 9 |
| 01_CORE_SOURCE.box | large_json_likely_run_data | 14 |
| 01_CORE_SOURCE.box | large_text_likely_run_data | 2 |
| 01_CORE_SOURCE.box | rebuildable_dir | 1 |
| 01_CORE_SOURCE.box | receipt_or_ledger_json | 1 |
| 01_CORE_SOURCE.box | run_output_dir | 1 |
| 01_CORE_SOURCE.box | sensitive_dir | 4 |
| 01_CORE_SOURCE.box | sensitive_name | 1 |
| 01_CORE_SOURCE.box | tabular_data | 17 |
| 01_CORE_SOURCE.box | unknown_type | 75 |
| 01_CORE_SOURCE.box | unreviewed_image_privacy | 138 |
| 01_CORE_SOURCE.fangyu | binary_or_package | 3,579 |
| 01_CORE_SOURCE.fangyu | customer_data_fields | 6,341 |
| 01_CORE_SOURCE.fangyu | data_ledger | 7,270 |
| 01_CORE_SOURCE.fangyu | data_or_evidence_dir | 3,643 |
| 01_CORE_SOURCE.fangyu | excluded_by_spec_rx | 309 |
| 01_CORE_SOURCE.fangyu | image_too_large_for_profile | 19,853 |
| 01_CORE_SOURCE.fangyu | large_json_likely_run_data | 15,740 |
| 01_CORE_SOURCE.fangyu | large_text_likely_run_data | 6 |
| 01_CORE_SOURCE.fangyu | nested_git_pointer | 4 |
| 01_CORE_SOURCE.fangyu | rebuildable | 493 |
| 01_CORE_SOURCE.fangyu | rebuildable_dir | 1,878 |
| 01_CORE_SOURCE.fangyu | receipt_or_ledger_json | 2,218 |
| 01_CORE_SOURCE.fangyu | reparse_point_not_followed | 1 |
| 01_CORE_SOURCE.fangyu | run_output_dir | 329 |
| 01_CORE_SOURCE.fangyu | sensitive_dir | 1,959 |
| 01_CORE_SOURCE.fangyu | sensitive_name | 372 |
| 01_CORE_SOURCE.fangyu | skipped_by_spec | 10 |
| 01_CORE_SOURCE.fangyu | tabular_data | 824 |
| 01_CORE_SOURCE.fangyu | text_too_large | 1 |
| 01_CORE_SOURCE.fangyu | unknown_type | 11,497 |
| 01_CORE_SOURCE.fangyu | unreviewed_image_privacy | 11,745 |
| 01_CORE_SOURCE.quiz | binary_or_package | 8,505 |
| 01_CORE_SOURCE.quiz | customer_data_fields | 1,357 |
| 01_CORE_SOURCE.quiz | data_ledger | 2,783 |
| 01_CORE_SOURCE.quiz | data_or_evidence_dir | 228 |
| 01_CORE_SOURCE.quiz | image_too_large_for_profile | 311 |
| 01_CORE_SOURCE.quiz | large_json_likely_run_data | 391 |
| 01_CORE_SOURCE.quiz | large_text_likely_run_data | 31 |
| 01_CORE_SOURCE.quiz | rebuildable_dir | 467 |
| 01_CORE_SOURCE.quiz | receipt_or_ledger_json | 67 |
| 01_CORE_SOURCE.quiz | reparse_point_not_followed | 1 |
| 01_CORE_SOURCE.quiz | run_output_dir | 4 |
| 01_CORE_SOURCE.quiz | sensitive_dir | 211 |
| 01_CORE_SOURCE.quiz | sensitive_name | 71 |
| 01_CORE_SOURCE.quiz | tabular_data | 16 |
| 01_CORE_SOURCE.quiz | text_too_large | 2 |
| 01_CORE_SOURCE.quiz | unknown_type | 2,094 |
| 01_CORE_SOURCE.quiz | unreviewed_image_privacy | 6,551 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | binary_or_package | 1 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | customer_data_fields | 2 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | data_or_evidence_dir | 3 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | large_json_likely_run_data | 50 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | rebuildable_dir | 3 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | receipt_or_ledger_json | 1 |
| 02_STABLE_HISTORICAL_VERSION.fangyu-ui | skipped_by_spec | 1 |
| 03_CURRENT_VERSION.rmsama | binary_or_package | 23 |
| 03_CURRENT_VERSION.rmsama | customer_data_fields | 10 |
| 03_CURRENT_VERSION.rmsama | data_ledger | 15 |
| 03_CURRENT_VERSION.rmsama | data_or_evidence_dir | 5 |
| 03_CURRENT_VERSION.rmsama | image_too_large_for_profile | 6 |
| 03_CURRENT_VERSION.rmsama | large_json_likely_run_data | 15 |
| 03_CURRENT_VERSION.rmsama | rebuildable_dir | 11 |
| 03_CURRENT_VERSION.rmsama | receipt_or_ledger_json | 2 |
| 03_CURRENT_VERSION.rmsama | sensitive_dir | 6 |
| 03_CURRENT_VERSION.rmsama | sensitive_name | 2 |
| 03_CURRENT_VERSION.rmsama | unknown_type | 4 |
| 03_CURRENT_VERSION.rmsama | unreviewed_image_privacy | 60 |
| 04_UI_AND_NEW_FEATURES.box | binary_or_package | 80 |
| 04_UI_AND_NEW_FEATURES.box | customer_data_fields | 215 |
| 04_UI_AND_NEW_FEATURES.box | data_ledger | 32 |
| 04_UI_AND_NEW_FEATURES.box | data_or_evidence_dir | 36 |
| 04_UI_AND_NEW_FEATURES.box | excluded_by_spec_rx | 1 |
| 04_UI_AND_NEW_FEATURES.box | large_json_likely_run_data | 112 |
| 04_UI_AND_NEW_FEATURES.box | large_text_likely_run_data | 3 |
| 04_UI_AND_NEW_FEATURES.box | rebuildable_dir | 39 |
| 04_UI_AND_NEW_FEATURES.box | receipt_or_ledger_json | 5 |
| 04_UI_AND_NEW_FEATURES.box | reparse_point_not_followed | 2 |
| 04_UI_AND_NEW_FEATURES.box | run_output_dir | 57 |
| 04_UI_AND_NEW_FEATURES.box | sensitive_dir | 23 |
| 04_UI_AND_NEW_FEATURES.box | sensitive_name | 2 |
| 04_UI_AND_NEW_FEATURES.box | tabular_data | 35 |
| 04_UI_AND_NEW_FEATURES.box | unknown_type | 27 |
| 04_UI_AND_NEW_FEATURES.box | unreviewed_image_privacy | 450 |
| 05_GIT.gitbuild.s1 | binary_or_package | 1 |
| 05_GIT.gitbuild.s1 | customer_data_fields | 560 |
| 05_GIT.gitbuild.s1 | data_ledger | 81 |
| 05_GIT.gitbuild.s1 | data_or_evidence_dir | 2,880 |
| 05_GIT.gitbuild.s1 | excluded_by_spec_rx | 288 |
| 05_GIT.gitbuild.s1 | image_too_large_for_profile | 22 |
| 05_GIT.gitbuild.s1 | large_json_likely_run_data | 1,028 |
| 05_GIT.gitbuild.s1 | rebuildable_dir | 13,929 |
| 05_GIT.gitbuild.s1 | receipt_or_ledger_json | 1 |
| 05_GIT.gitbuild.s1 | run_output_dir | 3,017 |
| 05_GIT.gitbuild.s1 | sensitive_dir | 1,284 |
| 05_GIT.gitbuild.s1 | tabular_data | 2 |
| 05_GIT.gitbuild.s1 | unknown_type | 10 |
| 05_GIT.gitbuild.s1 | unreviewed_image_privacy | 41 |
| 05_GIT.gitbuild.s2 | binary_or_package | 1 |
| 05_GIT.gitbuild.s2 | customer_data_fields | 560 |
| 05_GIT.gitbuild.s2 | data_ledger | 81 |
| 05_GIT.gitbuild.s2 | data_or_evidence_dir | 2,880 |
| 05_GIT.gitbuild.s2 | excluded_by_spec_rx | 290 |
| 05_GIT.gitbuild.s2 | image_too_large_for_profile | 22 |
| 05_GIT.gitbuild.s2 | large_json_likely_run_data | 1,029 |
| 05_GIT.gitbuild.s2 | rebuildable_dir | 13,929 |
| 05_GIT.gitbuild.s2 | receipt_or_ledger_json | 1 |
| 05_GIT.gitbuild.s2 | run_output_dir | 3,017 |
| 05_GIT.gitbuild.s2 | sensitive_dir | 1,284 |
| 05_GIT.gitbuild.s2 | tabular_data | 2 |
| 05_GIT.gitbuild.s2 | unknown_type | 10 |
| 05_GIT.gitbuild.s2 | unreviewed_image_privacy | 41 |
| 05_GIT.gitbuild.s3 | binary_or_package | 1 |
| 05_GIT.gitbuild.s3 | customer_data_fields | 563 |
| 05_GIT.gitbuild.s3 | data_ledger | 87 |
| 05_GIT.gitbuild.s3 | data_or_evidence_dir | 2,880 |
| 05_GIT.gitbuild.s3 | excluded_by_spec_rx | 302 |
| 05_GIT.gitbuild.s3 | image_too_large_for_profile | 22 |
| 05_GIT.gitbuild.s3 | large_json_likely_run_data | 1,029 |
| 05_GIT.gitbuild.s3 | rebuildable_dir | 13,929 |
| 05_GIT.gitbuild.s3 | receipt_or_ledger_json | 1 |
| 05_GIT.gitbuild.s3 | run_output_dir | 3,017 |
| 05_GIT.gitbuild.s3 | sensitive_dir | 1,284 |
| 05_GIT.gitbuild.s3 | tabular_data | 2 |
| 05_GIT.gitbuild.s3 | unknown_type | 10 |
| 05_GIT.gitbuild.s3 | unreviewed_image_privacy | 41 |
| 05_GIT.gitbuild.s4 | data_or_evidence_dir | 1 |
| 05_GIT.gitbuild.s5 | large_json_likely_run_data | 1 |
| 05_GIT.gitbuild.s6 | binary_or_package | 1 |
| 05_GIT.gitbuild.s6 | customer_data_fields | 2 |
| 05_GIT.gitbuild.s6 | data_or_evidence_dir | 1 |
| 05_GIT.gitbuild.s6 | large_json_likely_run_data | 13 |
| 05_GIT.gitbuild.s6 | rebuildable_dir | 2 |
| 05_GIT.gitbuild.s7 | binary_or_package | 1 |
| 05_GIT.gitbuild.s7 | customer_data_fields | 2 |
| 05_GIT.gitbuild.s7 | data_or_evidence_dir | 1 |
| 05_GIT.gitbuild.s7 | large_json_likely_run_data | 15 |
| 05_GIT.gitbuild.s7 | rebuildable_dir | 2 |
| 05_GIT.gitbuild.s8 | rebuildable_dir | 1 |
| 05_GIT.gitbuild.s9 | binary_or_package | 214 |
| 05_GIT.gitbuild.s9 | customer_data_fields | 2,694 |
| 05_GIT.gitbuild.s9 | data_ledger | 3,681 |
| 05_GIT.gitbuild.s9 | data_or_evidence_dir | 47 |
| 05_GIT.gitbuild.s9 | excluded_by_spec_rx | 103 |
| 05_GIT.gitbuild.s9 | image_too_large_for_profile | 27 |
| 05_GIT.gitbuild.s9 | large_json_likely_run_data | 2,689 |
| 05_GIT.gitbuild.s9 | large_text_likely_run_data | 4 |
| 05_GIT.gitbuild.s9 | nested_git_pointer | 2 |
| 05_GIT.gitbuild.s9 | rebuildable_dir | 318 |
| 05_GIT.gitbuild.s9 | receipt_or_ledger_json | 1,809 |
| 05_GIT.gitbuild.s9 | run_output_dir | 247 |
| 05_GIT.gitbuild.s9 | sensitive_dir | 19 |
| 05_GIT.gitbuild.s9 | sensitive_name | 47 |
| 05_GIT.gitbuild.s9 | skipped_by_spec | 4 |
| 05_GIT.gitbuild.s9 | tabular_data | 50 |
| 05_GIT.gitbuild.s9 | unknown_type | 615 |
| 05_GIT.gitbuild.s9 | unreviewed_image_privacy | 1,295 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | data_ledger | 26 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | excluded_by_spec_rx | 13 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | large_json_likely_run_data | 5 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | run_output_dir | 1 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | tabular_data | 3 |
| 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs | unreviewed_image_privacy | 4 |

## 上传文件

| 包 | 文件 | 大小 | 条目 | SHA256 |
|---|---|---|---|---|
| 01_CORE_SOURCE | 01_CORE_SOURCE.box.part01.zip | 9,320,466 | 1,516 | `2560dd684e6407154fe960d95bdfafafd2993baa2a354c753c8f053bbb43942e` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.fangyu.part01.zip | 98,148,828 | 21,982 | `aed7ec9a0dae69fcd90d758f40edb4df4673f4d8fba9d5abbb9fe15bd977ffeb` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.fangyu.part02.zip | 98,269,905 | 24,800 | `00c808afd4d76b947593c8db2dcd85d556e712005b71a8984be945eb0c7c55c4` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.fangyu.part03.zip | 70,958,155 | 14,521 | `88280c3f6de583275881715407babe026a5fa4c3938a3f96b7f3713d775b3bef` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.quiz.part01.zip | 55,694,241 | 12,391 | `fd00243f74c1e57aed8b6e9cc0afa2c49fc14338261cb45db27206df2764cc9a` |
| 02_STABLE_HISTORICAL_VERSION | 02_STABLE_HISTORICAL_VERSION.fangyu-ui.part01.zip | 36,980,366 | 931 | `926be86ea6ebebac7600299c483610638f522f3ae367c2c52e4319df860d5bfe` |
| 03_CURRENT_VERSION | 03_CURRENT_VERSION.rmsama.part01.zip | 52,134,398 | 857 | `21c2baa37cf365f17e043ecc817f52491799b863fd18934bc7d39c9e035f6217` |
| 04_UI_AND_NEW_FEATURES | 04_UI_AND_NEW_FEATURES.box.part01.zip | 91,675,365 | 337 | `600926faf3c2f5cba88b830ae63354d4ae4334f1def28af6915af7c0ec13c996` |
| 04_UI_AND_NEW_FEATURES | 04_UI_AND_NEW_FEATURES.box.part02.zip | 91,532,649 | 8,940 | `ebc95b30cfa941c2c42271acdd5d9cc9035525e4c307a59b2c9f03b7d139a1c7` |
| 06_DATABASE_AND_MIGRATIONS | 06_DATABASE_AND_MIGRATIONS.part01.zip | 38,346 | 18 | `6e858c1d713efe0bcb46f406fe5d070aa26e3d39153a1d01149a692f1eeb2798` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part01.zip | 18,388,654 | 2 | `1da060698f5ead33836ccd6a3364d4e703941f62edc9a343f20ade38fcd274a4` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part02.zip | 18,891,639 | 1 | `8c809faddc384bc17cf47bb22718330de030d15223e11e4e93708e0486a2701a` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part03.zip | 20,273,942 | 1 | `162160fcf4b401cc095365602e80456c2f62268b912f1312c9fb204b0c4c28da` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part04.zip | 12,519,503 | 31 | `752094a8a7923bf0b9b11375cb6373e55003160b882b1e892c9385ff5619299d` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs.part01.zip | 1,648,992 | 271 | `1154be28aa824d8a4ff9bb368a55b4d72a92b3f52848f3df42d52a6b9eefd41f` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.handover-docs.part01.zip | 1,261,237 | 54 | `9381ce7d79eaf90e50ffa0d6e2b777eaaa40d549be01246bde20ee9feb5ccdeb` |
| 05_GIT_FULL_HISTORY | fangyu-version-history-RECONSTRUCTED.bundle | 89,470,847 | 15 refs | `93f07a54cddf47cfa509bba17900878abcd7f464e68d0a17fc74aeaa1053f231` |
| 05_GIT_FULL_HISTORY | quiz-desktop-final-archive-daily-hundred-app.bundle | 1,409,630 | 3 refs | `2bad3d6d47a4aeef18785d03ac34495a5f0434c01584d6401d3b920acf5a31f1` |
| 05_GIT_FULL_HISTORY | quiz-original-control-source.bundle | 1,346,416 | 5 refs | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| 05_GIT_FULL_HISTORY | quiz-outputs-daily-hundred-app.bundle | 1,409,630 | 3 refs | `2bad3d6d47a4aeef18785d03ac34495a5f0434c01584d6401d3b920acf5a31f1` |
| 05_GIT_FULL_HISTORY | quiz-tijing-dailyhundred.bundle | 1,346,416 | 5 refs | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| 05_GIT_FULL_HISTORY | quiz-tijing-minimal.bundle | 1,346,416 | 5 refs | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| 05_GIT_FULL_HISTORY | quiz-tijing-upstream.bundle | 1,346,416 | 5 refs | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
