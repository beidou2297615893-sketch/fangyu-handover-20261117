第一阶段盘点（00_ASSET_INVENTORY.md）中“r57 共 327 个 release 都在原仓”有误：主目录 work\ui-native-r57\releases 只有 46 个；B/C/F 位于集成候选嵌套副本。以 docs/VERSION_COMPARISON.md 为准。
