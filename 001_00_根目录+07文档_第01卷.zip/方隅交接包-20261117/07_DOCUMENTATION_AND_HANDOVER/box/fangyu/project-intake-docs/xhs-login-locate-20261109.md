# 小红书登录程序定位 + 玉米碴(ec0b)采集绑定（2026-11-09）

- 时区：Asia/Shanghai (UTC+8)
- 执行窗口：约 12:58–13:01
- 机器：f79a5338-7ab9-41e1-bad0-3f5c3b1dd392 (RMSAMA)
- 根：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统`（下称 R）
- 约束遵守：只读元数据/源码文本；未运行任何脚本(含 --help)；未联网；未读会话/Cookie/凭据内容；未改文件；未停/碰任何进程（含抖音 panel/control/account_probe/collector 与 19422）
- **中断**：宽扫第二段命令启动时本机返回 temporarily unreachable；按任务要求立即停、不重试。此后仅用 box 既有归档补证，未再对本机发命令。

## 任务A：CLI 扫码登录程序

### A1. `R\work\xhs-standalone-session` 一级目录（只列名+mtime，未进入）

| Name | LastWriteTime (本机本地) |
|---|---|
| browser-cli-20261029-0104 | 2026/10/29 1:05:34 |
| browser-cli-manual-verify-20261029-attempt1 | 2026/10/29 14:52:58 |
| browser-cli-new-account-20261029 | 2026/10/29 14:05:09 |
| browser-cli-new-account-20261029-attempt3 | 2026/10/29 14:31:59 |
| browser-cli-new-account-20261029-attempt4 | 2026/10/29 14:35:12 |
| browser-cli-new-account-20261029-attempt5 | 2026/10/29 14:49:52 |
| browser-cli-new-account-20261029-reconnect | 2026/10/29 14:22:34 |
| browser-cli-verified-import-20261029 | 2026/10/29 15:06:46 |
| browser-cli-verified-import-20261029-attempt2 | 2026/10/29 15:10:39 |
| browser-cli-verified-import-20261029-attempt3 | 2026/10/29 15:21:45 |
| browser-cli-verified-import-20261029-attempt4 | 2026/10/29 15:41:30 |
| browser-cli-verified-import-20261029-attempt5 | 2026/10/29 15:51:51 |
| chrome-import-20261029 | 2026/10/29 0:39:23 |
| cli-login-20261028-164606 | 2026/10/28 16:46:06 |
| cli-login-20261028-165417 | 2026/10/28 16:55:01 |
| collection-live | 2026/10/29 13:59:57 |
| diagnostics | 2026/10/29 1:18:20 |
| **huihuijiang-browser-login-20261105-01** | **2026/11/5 14:09:20** |
| huihuijiang-reply-relogin-20261104-01 | 2026/11/4 14:12:52 |
| huihuijiang-reply-relogin-20261105-01 | 2026/11/5 11:32:28 |
| huihuijiang-reply-verified-20261105-02 | 2026/11/5 11:54:39 |
| huihuijiang-send-20261101-01 | 2026/11/1 19:04:51 |
| leimu-15stores-20261029 | 2026/10/29 23:56:45 |
| leimu-15stores-login-20261029 | 2026/10/30 0:15:12 |
| login-20261028-161108 | 2026/10/28 16:11:08 |
| new-task-20261029-1710 | 2026/10/29 17:02:04 |
| new-task-managed-20261029 | 2026/10/29 17:33:30 |
| new-task-session-repair-20261029-1720 | 2026/10/29 17:16:16 |
| relogin-20261028 | 2026/10/28 23:48:38 |
| reply-account-001-20261029 | 2026/10/29 18:52:30 |
| reply-account-001-verified-20261029 | 2026/10/29 19:09:01 |
| stores15-chrome-sync-20261103-01 | 2026/11/3 15:01:43 |
| stores15-chrome-sync-20261103-02 | 2026/11/3 15:03:24 |
| stores15-dedicated-login-20261103-01 | 2026/11/3 15:46:01 |
| stores15-resume-login-20261030-01 | 2026/10/30 13:14:22 |
| stores15-user-relogin-20261030-02 | 2026/10/30 13:16:56 |
| stores15-user-relogin-20261030-03 | 2026/11/8 0:50:04 |

注：目标历史目录 `huihuijiang-browser-login-20261105-01` 存在，mtime=2026-11-05 14:09:20，与任务描述一致。未进入、未列其内部文件。

### A2. `R\work` 下文件名含 login/relogin/qr/browser/登录 的脚本（排除 node_modules、vendor\cli-runtime\Lib、xhs-standalone-session 内部）

业务相关（去噪后，按 mtime 新→旧）：

| Rel（相对 work） | mtime | 备注 |
|---|---|---|
| xhs-resume-20261103\import_browser_dom.py | 2026/11/3 16:03:07 | DOM 导入旁路，非 CLI 扫码登录 |
| xhs-resume-20261103\login_diagnostic.py | 2026/11/3 15:50:47 | HTTP QR 诊断登录 |
| xhs-resume-20261103\login_for_collection.py | 2026/11/3 15:45:59 | 薄包装→diagnostics\new_login.py |
| qr-display-observer-20261029\test_qr_display.py | 2026/10/29 14:42:11 | 观察器测试 |
| qr-display-observer-20261029\qr_display.py | 2026/10/29 14:41:52 | QR 展示观察 |
| xhs-three-stage-integration\browser_intake.py | 2026/10/29 0:59:01 | 三阶段 intake |
| account-verification-entry\…\xhs_browser_login.py 等 | 2026/10/19 | 旧助理浏览器登录（副本树） |
| vendor\github\xiaohongshu-cli\xhs_cli\qr_login.py | 2026/9/16 23:15:52 | 上游 CLI QR 本体（vendor 副本） |

另有大量 scipy/huggingface/playwright/_internal/MediaCrawler 噪声命中（文件名含 qr/login/browser），已排除出业务结论。全量 name-match COUNT=68。

**未找到** mtime 接近 2026-11-05 14:09、且文件名/本次已读内容内写死 `huihuijiang-browser-login-*` 命名的包装脚本。11-05 目录名更像调用时由操作者指定的 `--session-home`（或等价参数），而非脚本内硬编码。

### A3. Select-String（焦点脚本）`qr-0001|browser-login|qrcode|login`

**login_for_collection.py**（全文已读，782B）：

- L1: CLI QR login into isolated collection session
- L8: 固定会话 `work/xhs-standalone-session/stores15-dedicated-login-20261103-01`
- L11–12: 若已有 cookies.json → `SESSION_ALREADY_SAVED_NO_RELOGIN`（未读 cookies 内容，仅见存在性判断源码）
- L14–17: 转调 `work/xhs-standalone-session/diagnostics/new_login.py`，QR 输出 `session/login-qr.png`（**非** qr-0001.png）
- **无 argparse**；无 browser-login 命名逻辑

**login_diagnostic.py**（全文已读）：

- L46 argparse：`--execute`；`--session-home` **必填**
- 无 `--execute` → 打印 `PREVIEW_NO_NETWORK` 后返回（仍属源码结论，本次未运行）
- L52：在 `session_home/.xiaohongshu-cli` 建配置目录（exist_ok=False）
- L62：QR 存 `home/'login-qr.png'`（**非** qr-0001.png）
- L63–64：poll 确认后 `storage.save_cookies`；成功 emit LOGIN_SUCCESS
- **输出目录命名**：完全由调用方传入的 `--session-home` 决定，脚本内不生成 `*-browser-login-*` 时间戳名

**其他焦点**：`import_browser_dom.py` 未在本轮完整摘参；`qr_display*.py` 为观察/测试；宽扫中 `browser-login` 字符串大量落在 `account-verification-entry` 旧助理副本的 `work/browser-login/<job>` 舞台路径（账号目录内 stage，不是 `xhs-standalone-session/*-browser-login-*`）。

**历史 qr-0001.png 证据（box 归档/handoff，非本次本机打开会话目录）**：

- source/handoff 曾嵌入路径形如  
  `…\xhs-standalone-session\<某会话>\qr-0001.png`  
  （new-task… / reply-account-001-20261029 / leimu-15stores-login-20261029）
- 说明存在会写 `qr-0001.png` 的登录程序；但 **本次在非会话目录脚本中未定位到写死 `qr-0001` 的调用包装**。候选实现位置：
  1. `work\xhs-standalone-session\diagnostics\new_login.py`（被 login_for_collection 引用；按约束未进入会话树，**未读**）
  2. `vendor\github\xiaohongshu-cli\xhs_cli\qr_login.py`（上游；本次未展开全文，机器已离线）
  3. 旧 `account-verification-entry` 的 `xhs_browser_login.py` / `browser_login_window.py`（“打开浏览器窗→成功后关窗”叙事更贴近用户历史描述，但是 10-19 副本树，**未证即 11-05 所用**）

### A4. 与“CLI 专用浏览器、成功保存后自动关窗”的对照

- box `source.md` 约 L8502–8524（11-05 叙事）：打开 CLI 专用登录浏览器 → 用户扫码 → 程序保存会话后**自动关窗** → 账号确认玉米碴/慧慧酱。对应会话名与一级目录 `huihuijiang-browser-login-20261105-01` 一致。
- `login_diagnostic.py` / `login_for_collection.py` 路径是 **HTTP 出 PNG 二维码**（login-qr.png），源码未见“启动专用浏览器窗口并自动关窗”的 Playwright/Chromium 启动逻辑。
- **结论（诚实）**：11-05 那次“CLI 专用浏览器扫码登录”的**确切可执行入口路径，本次未能在允许扫描范围内钉死**。已钉死的是：
  - 会话落点目录名与 mtime；
  - 采集侧现成 HTTP-QR 包装：`login_diagnostic.py`（可指定任意 session-home）与 `login_for_collection.py`（写死蕾姆专用 dedicated 目录）；
  - 真正被 login_for_collection 调用的 `diagnostics\new_login.py` 仍在会话树内，待下次本机在线且获准**只列 diagnostics 下普通 .py 文件名（仍不读凭据）**后再核。

## 任务B：采集入口与玉米碴 uid `5f469df5000000000101ec0b` 绑定

三文件均在 `R\work\xhs-resume-20261103\`，mtime：resume.py 11-03 12:09:50；resume006.py 11-03 15:46:14；verify_resume006.py 11-03 15:46:07。

### B1. resume.py（蕾姆续采，**非** ec0b）

| 项 | 行号 | 值 |
|---|---|---|
| UID | L8 | `5aa9b337e8ac2b4ab2d21957`（蕾姆） |
| PRIOR | L9 | `…/stores15-resume004-20261030` |
| ROOT | L10 | `…/stores15-resume005-20261103` |
| HOME | L11 | `…/xhs-standalone-session/stores15-user-relogin-20261030-03`（**写死**） |
| argparse | L70 | 仅 `--execute` |
| 会话可否参数指定 | — | **否**（无 env、无 --session-home） |

→ **不原生支持 ec0b/玉米碴。**

### B2. resume006.py（玉米碴续采，**原生 ec0b**）

| 项 | 行号 | 值 |
|---|---|---|
| OLD_UID | L8 | `5aa9b337e8ac2b4ab2d21957`（仅对账旧清单） |
| UID | L9 | `5f469df5000000000101ec0b` |
| PRIOR | L10 | 同 resume 的 resume004 |
| ROOT | L11 | `…/stores15-resume006-20261103` |
| HOME | L12 | `Path(os.environ.get('XHS_COLLECTION_SESSION_HOME', str(PROJECT/'work/xhs-standalone-session/stores15-ec0b-pending-20261103')))` |
| 进度文案账号 | L67 | `玉米碴（慧慧酱）` |
| argparse | L81 | 仅 `--execute` |
| 身份门闩 | L85 | 要求 `identity-check` 结果 `status==verified` 且 `uid==UID` 且 `session_home` resolve 等于 **HOME** |

会话目录：

- **默认真值**：`R\work\xhs-standalone-session\stores15-ec0b-pending-20261103`
- **可用环境变量覆盖**：`XHS_COLLECTION_SESSION_HOME`（**不是** argparse）
- 一级目录列表中 **未见** `stores15-ec0b-pending-20261103` → 默认 HOME 目录当前不存在（仅凭一级名列表；未进入其他目录找）
- 与历史核验一致的候选会话名：`huihuijiang-browser-login-20261105-01`；要用它必须设  
  `XHS_COLLECTION_SESSION_HOME=<该目录绝对或相对项目约定路径>`，且先通过 verify

### B3. verify_resume006.py（ec0b 身份核验入口）

| 项 | 行号 | 值 |
|---|---|---|
| argparse | L7 | `--session-home` **必填**；`--uid` 默认 `5f469df5000000000101ec0b`；`--execute` |
| 预览 | L8–9 | 无 `--execute` → status preview, network false |
| 核验 | L13–14 | InboxClient(session_home/`.xiaohongshu-cli/cookies.json`, uid) → verify（**本次未运行**） |
| 产出 | L28 | verified → `identity-check-resume006-verified.json`；否则 `identity-check-resume006-latest-failure.json` |

→ **原生支持 ec0b**（默认 uid）；会话路径由 `--session-home` 指定。

### B4. 绑定结论与缺口

| 入口 | 原生 ec0b？ | 会话如何指定 | 缺口 |
|---|---|---|---|
| resume.py | 否（固定蕾姆） | 写死 HOME | 不能直接用于玉米碴 |
| resume006.py | **是**（UID=ec0b） | env `XHS_COLLECTION_SESSION_HOME`；默认 pending 目录不存在 | ①默认 HOME 缺失 ②须先有 verified 且 path 与 HOME 一致 ③上次已知核验曾 `session_update_requires_review`（既有 runtime 记录，本次未复跑） |
| verify_resume006.py | **是**（默认 uid） | `--session-home` | 联网核验/会话写回策略不在本任务范围；本轮未执行 |

**不能**：登录成功后直接拿旧 `resume.py --execute` 硬跑玉米碴。  
**原路**：`verify_resume006.py --session-home <玉米碴会话> [--uid ec0b] --execute` → 通过后设同路径 env → `resume006.py --execute`。

## 停止点

1. 本机宽扫第二段启动时 offline → **已停、未重试**。
2. 未进入 `xhs-standalone-session\**`（含 diagnostics），故 `new_login.py` 本体未读。
3. 未展开 vendor `qr_login.py` 全文确认是否产出 `qr-0001.png`。
4. 11-05“专用浏览器关窗”入口：有会话目录与叙事证据，**无本次允许范围内的确切脚本路径钉死**。

## 若本机恢复后的最小续读（仅建议，未执行）

在仍遵守不读凭据/不运行的前提下，只需：

1. 列 `R\work\xhs-standalone-session\diagnostics\` 下 `.py/.cmd` **文件名+mtime**（仍不读 cookies）。
2. 对 `diagnostics\new_login.py`（若存在）只读 argparse/输出文件名（是否 `qr-0001.png`）与关窗逻辑行号。
3. 对 `vendor\github\xiaohongshu-cli\xhs_cli\qr_login.py` 只读是否写 `qr-0001` / browser 启动。
4. 在非会话树脚本中 `Select-String 'huihuijiang-browser-login|browser-login-%|qr-0001\.png'` 收束命名来源。

