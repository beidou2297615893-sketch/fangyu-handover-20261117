# 方隅本地CLI运行检查

记录更新：2026-11-08 00:53（Asia/Shanghai，UTC+8）执行权交接
机器：RMSAMA `f79a5338-7ab9-41e1-bad0-3f5c3b1dd392`
许可根：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统`

本执行者即刻停止一切本机预检、启动、审批、窗口操作和补包；不终止已有业务进程。下列均用已知证据，不再访问用户电脑。

## 执行权交接（专责接手）

- 交接时刻起本执行者不再对 RMSAMA 发起任何操作。
- 未杀 PID 5444 / 53852 / 48004，也未杀其他进程。
- 真实发送从未执行，仍禁止。

### 在途工具（不能假定已停止）

不能回报“确认无在途启动”。

1. 第一次小红书采集：`work/vendor/cli-runtime/Scripts/python.exe -u -B -X utf8 work/xhs-resume-20261103/resume.py --execute`（工作目录为许可根，隐藏窗口，标准输出/错误重定向到本机临时文件 `fy-xhs-exec-out.txt` / `fy-xhs-exec-err.txt`）。Auto-review 拒绝，原文：`Rejected: Start xhs resume.py with --execute flag without verified safe execution scope.` 此次命令未实际启动。
2. 随后用**同一命令、同一参数**加上 `request_smart_mode_approval=true` 和上述精确拒绝原文尝试举原生审批卡。工具返回：`Shell command was interrupted before it completed. It may still be running.` 无法确认：审批卡是否已展示、用户是否已批、`Start-Process` 是否已拉起 `resume.py --execute`。
3. 该在途动作若最终跑起来，会启动小红书原范围采集（文档写明无评论/私信发送），不是发送入口。
4. 00:47 前最后成功进程快照未见 `resume.py` / `runner.cjs`。00:50 进程复核暂时不可达，之后按交接要求未再查本机。因此：**不能证明采集已启动，也不能证明举卡重试已彻底停下。**

抖音未发出 `--run`。未再发起 `collection_identity_check` / `identity_probe` / 预演。没有未执行完毕的打包或写 Page。

### 连接归属（本次现场，不是 11 月 3 日旧记录）

- 抖音 `identity_probe.cjs`：`unexpected_connection_count=3`（要求恰好 1 条活跃连接）。
- 抖音 `collection_identity_check.cjs` 对当前确认计划：exit 1；`ok=false`，`connection_matches=false`，`uid_matches=false`；失败类型 `authorized_account_not_verified`。无 `challenge_visible` 字段。
- 小红书默认预演：exit 0，`status=locally_reconciled`，`network=false`。这是本地对账，不是在线身份通过。
- 本人步骤仅针对抖音现场 3 条连接：只保留计划绑定的那一个已登录连接后再预检。不提权取 Cookie。

### 原生卡状态

- 已发生：一次自动拒绝（上文原文）。
- 一次举卡重试被中断，**不确定卡是否在用户侧待批**。本执行者不再重复举卡。
- 没有“已批准、待本执行者继续执行”的明确命令回执。唯一可能待完成的就是上述被中断的 `--execute` 举卡/启动。

### 最近安全读取（本轮已做，不再重做）

帮助：`AGENTS.md`、`runner_README.md`、`STRICT-BRIDGE-USAGE.md`、抖音 `README.md`/`采集交接.md`/`timeout-investigation-20261101.md`/`文本接续最新核对.md`、小红书 `xhs-resume-20261103/README.md`、`xhs-send-current-20261029/README.md` 与 `等待登录接续.md`、`本窗口接续说明.md`。此前 12 份文档审阅见 `takeover-readonly.md`。
状态白名单：`active-runner.json`、`progress.json`、文本运行状态/优先顺序、发送 status（只取状态/时间/计数/PID 类字段）。预检输出已去敏。未读 Cookie/会话/身份文件正文/客户正文。

### 完整实际入口与历史顺序

详见下文“已确认原链路”和“本次与历史差在哪一步”。摘要：

抖音：Bridge `127.0.0.1:19422` → 只读身份/严格连接预检 → `node runner.cjs --run`（最后确认计划/目录为 `plan-confirmed-20261107-051216-338401.json` 与 `runner-live-confirmed-20261107-051216-338401`，不要退回帮助示例或 10 月 29 日旧探针文件）→ 本地筛选 → 母句草稿 → 发送在独立回复链（本轮禁止）。
小红书：内置 `work/vendor/cli-runtime/Scripts/python.exe` → `--execute` 时才现场核验身份 → `resume.py --execute` 采集（默认无参数仅预演）→ 共用文本筛选/母句 → `prepare_logged_sender.py` 预览 / `managed_send_client` + 原 Runner 提交 / `readback_client` 回读（本轮禁止实发）。

当前卡点：抖音连接归属（3 条连接）；小红书现场身份未做，且 `--execute` 审批/启动状态未决。

ListMachines 在预检前为 `connected=true`。此后偶发短暂原生“temporarily unreachable”，不据此称离线。00:50 进程复核再次暂时不可达，下列活进程以 00:42–00:47 成功核验为准。

## 业务暂停与安全停线（分开）

- 普通业务采集暂停：总指挥确认，用户当前“评论采集/回复先跑起来”足以恢复原范围普通业务采集暂停。不再把 `AGENTS.md` 旧暂停当作当前启动否决项，也不再重复问业务暂停许可。
- 安全停线仍有效，不能当作已解除：unknown 不重试、不恢复；平台验证/验证码停线不绕过；不授权真实发送。
- 2026-11-03 小红书 `stopped_dedicated_login_verification_required` 与 `native_browser_cookie3_requires_admin` 只作为旧记录，不当作本次复现阻塞。本次以现场公开 CLI 预检为准。

## 现有进程（00:47 前最后成功快照）

| PID | 程序 | 开始时间 | 脚本基名 |
|---|---|---|---|
| 5444 | python.exe | 2026-11-07 18:12:42 | collection_wait_worker.py |
| 53852 | python.exe | 2026-11-07 23:06:26 | ensure_text_worker.py |
| 48004 | python.exe | 2026-11-07 23:06:26 | watch_increment.py |

记录中的抖音 runner PID 36212：当时 `alive=false`。未见 `runner.cjs` 或 `resume.py`/`resume006.py` 活进程。未杀任何进程。

普通文档未说明 `collection_wait_worker.py` 在 runner 已死后是否会自动拉起。进程事实：该等待进程已持续数小时，期间没有出现 `runner.cjs`。契约缺口（交云端，不查源码行为）：等待进程的调度语义、会不会稍后自动拉起 runner。因此即使抖音预检通过，当时也不会再启一个 runner，以免重复。

## 抖音现场预检（本次实际结果）

公开 CLI，只输出类型，未打印账号/secret/客户内容。使用当前调度文件名 `plan-confirmed-20261107-051216-338401.json` 与已有 Bridge 配置存在性；未读计划或身份文件正文。

1. `node collection_identity_check.cjs <当前确认计划> <已有Bridge配置>`  
   - exit_code=1  
   - 失败类型：`authorized_account_not_verified` / `pinned_account_not_verified_message`  
   - 白名单字段：`ok=False`，`connection_matches=False`，`uid_matches=False`  
   - 输出中无 `page_ready` / `challenge_visible` / `status`，不能声称当前看到验证码。

2. `node identity_probe.cjs`（只读身份探针；临时输出文件未写成，或已删除且未读内容）  
   - exit_code=1  
   - 失败类型：`unexpected_connection_count`，`count=3`  
   - 即当前 Bridge 上活跃抖音连接数为 3，探针要求恰好 1 条。

结论：抖音当前身份/连接预检未通过。未启动 `runner.cjs --run`。这是现场结果，不是 11 月 3 日旧状态。

本人步骤（仅因本次预检失败，不是凭旧登录记录）：请在电脑前只保留当前采集计划所绑定的那一个已登录抖音页/连接，关闭其它会挂到同一 Bridge 的抖音连接后，再做同样的只读预检。不要管理员提权提取 Cookie，也不要直接打开会话文件。未见验证码字段，故不要求去打验证码。

运行目录 `runner-live-confirmed-20261107-051216-338401` 当时存在，无 `STOP`，有 `control.json`。`historical_halts_preserved=true` 仍表示历史安全 halt 要保留。

## 小红书预演、采集与审批

文档入口：`work/vendor/cli-runtime/Scripts/python.exe -u -B -X utf8 work/xhs-resume-20261103/resume.py`，默认预演；`--execute` 才采集。README 写明无评论或私信发送。

1. 默认预演（无 `--execute`）已跑：exit_code=0，`status=locally_reconciled`，`network=false`，未提到登录/验证。  
   这只是本地对账预演，**不是**在线身份/连接预检通过。

2. 因此不把本次预演当成“当前身份已通过”。帮助里没有与抖音 `collection_identity_check.cjs` 对等的、可单独做现场只读身份核验且保证不发不采的小红书命令；在线核验按 README 是 `--execute` 时才会做。这是契约缺口，不是已通过的预检。

3. 采集启动审批实际状态：  
   - 第一次执行 `resume.py --execute`：Auto-review 拒绝，原文 `Rejected: Start xhs resume.py with --execute flag without verified safe execution scope.`  
   - 这是自动拦截，不等于用户已看到或处理了审批卡。  
   - 随后曾按原命令、原参数加上 `request_smart_mode_approval=true` 和上述精确拒绝原文尝试举卡；该次调用返回“interrupted before it completed / may still be running”。  
   - 无法确认审批卡是否已成功展示或得到处理。未收到启动 PID，也未观察到采集已跑起来。  
   - 本次不再重复举卡：离线预演不能代替身份预检通过；帮助虽写 `--execute` 为原范围采集且无发送，但未写明是否会提取浏览器 Cookie/不删数据。在身份未现场通过、安全边界未从普通契约完全确认前，再请用户批准会误导。不改命令、不换路径绕过。

4. 小红书采集：未启动。停止方法备查（未执行）：运行目录创建 `STOP`。

## 筛选 / 草稿 / 发送

实际发送仍完全禁止。未执行发送，未恢复旧批准发送队列。

文本侧 PID 53852 / 48004 此前已在运行，未再另启筛选或出稿，以免重复。未见可证明“只做离线出草稿、不触发发送”的额外现成命令。

## 快照

| 项 | 结果 |
|---|---|
| 抖音采集 | 未启动。现场预检失败：`unexpected_connection_count=3`；计划绑定核验 `ok=false, connection_matches=false, uid_matches=false`。记录 runner 不在；等待进程 5444 仍在。 |
| 小红书采集 | 未启动。本地预演成功但 `network=false`，不是在线身份通过。`--execute` 被 Auto-review 拒绝；举卡重试中断，采集未证实启动。 |
| 离线文本窗口 | 原有两个 Python 进程仍按上次快照存在；未新启动。 |
| 实际回复发送 | 未启动，且禁止。 |

## 云端契约缺口（不查源码行为）

1. `collection_wait_worker.py` 在记录 runner 已死时是否会自动拉起 `runner.cjs`。  
2. 小红书是否存在不启动采集、只做现场只读身份核验的公开 CLI。  
3. `resume.py --execute` 除采集外是否会提取浏览器 Cookie、删除数据，或恢复 unknown。  

代码行为问题交总指挥转现有云端 `bc-011f98ce-c113-513a-a874-12e38f5ab6b3`。不承诺明早可开始回复。

## 已确认原链路（复用12份文档 + 本次状态，不重查代码）

总指挥云端已核等待器 / 小红书 `--execute` 契约，本侧不重复调查源码。下列是文档与最后调度状态里的原顺序，不是新设计。

### 抖音

1. 前置服务：本机抖音自用采集台 Bridge（`127.0.0.1:19422`），页面已登录且 Bridge 上活跃抖音连接与计划绑定连接一致。帮助要求探针所见活跃连接为恰好 1 条；严格路由拒绝不存在的连接 ID。配置文件存在：`抖音自用采集台/data/bridge.json`。
2. 身份/连接：先做只读身份与严格连接预检，再交给 runner 消费。公开 CLI 有 `collection_identity_check.cjs <计划> <Bridge配置>` 和 `identity_probe.cjs`。runner 启动消费 `--identity-probe`、`--strict-proof`、`--bridge-config`，自己不再当作已实时验过服务。
3. 采集：帮助示例  
   `node runner.cjs --run --plan 15-store-plan.json --bridge-config <已核实Bridge配置> --identity-probe identity-probe.json --strict-proof <严格预检JSON> --database runner-runtime/collection.sqlite3 --directory runner-runtime --minimum-delay-ms 40000`  
   最后一次调度记录（`active-runner.json` 白名单，比采集交接里 PID 17684 / `15-store-plan-account2-ready.json` 更晚）实际用的是：计划 `plan-confirmed-20261107-051216-338401.json`，目录 `runner-live-confirmed-20261107-051216-338401`，身份/严格预检文件与该时间戳对应，日志为 `runner-ui-continue-...`，`minimum_delay_ms=1000`，记录 PID 36212，`batch_baseline=36034`。无发送器。`STOP` / Ctrl+C 停止。unknown / 验证码停线保留，不重试。
4. 筛选：采集端正文地域/租赁守门；其后本地 30 天与分类（`recency-priority`、`local_classifier`，规则版本曾见 `business-text-20261029-v2` / `fangyu-commercial-fit-v4.3-20261106`）。
5. 母句草稿：本地已认可母句套用（`mother_adapter`）。`文本接续最新核对.md` 记历史快照：分类 34840、母句稿 11504，不是本轮新生成。草稿不等于发送授权。
6. 发送入口（本轮不执行）：采集 runner 不含发送器。发送在独立回复链；历史有成功回执记载，本轮无账号/批次/正文/数量授权，禁止实发。unknown 不重发。

### 小红书

1. 前置服务：内置 `work/vendor/cli-runtime/Scripts/python.exe`，复用执行器/调度器与共享防重账本；使用应用已配置会话，不手工读 Cookie。
2. 身份/连接：README 写明 `--execute` 时才做原生身份核验。默认无参数是只读预演。没有与抖音对等的、单独现场只读身份 CLI 写进这 12 份帮助。
3. 采集：  
   `work/vendor/cli-runtime/Scripts/python.exe -u -B -X utf8 work/xhs-resume-20261103/resume.py --execute`  
   默认预演不加 `--execute`。运行目录建 `STOP` 可在当前批后停。无评论或私信发送。文档记 2026-11-03 恢复采集为当时授权，按命令入口仍用 `resume.py`。
4. 筛选：与抖音共用文本业务窗口的时间/意向/分类规则，两平台账本分开。
5. 母句草稿：同上，本地母句套用；文本窗口说明里新增强增处理开关曾为 false。草稿不等于可发。
6. 发送入口（本轮不执行）：`prepare_logged_sender.py` 默认预览；`managed_send_client.make_client` 接原 Sender/Runner 单次提交；`readback_client.py` 独立回读。受理回执不是公开可见成功，禁止自动重发。

## 本次与历史差在哪一步（先恢复差异，不改设计）

| 步骤 | 历史最后成功/文档约定 | 本次实况 | 要先恢复的差异 |
|---|---|---|---|
| 抖音前置连接 | 活跃抖音连接恰好 1 条，且等于计划绑定连接 | `identity_probe`：`unexpected_connection_count=3`；`collection_identity_check`：`ok=false, connection_matches=false, uid_matches=false`。未见验证码字段 | 本人在电脑前只保留计划所绑定的那一个已登录连接，关掉同一 Bridge 上另外两条后重做只读预检。不提权取 Cookie。这是当前第一卡点 |
| 抖音采集进程 | 最后调度记录 status=running、PID 36212；采集交接更早一次成功为 PID 17684 / account2-ready 计划 | PID 36212 不在；等待进程 5444 `collection_wait_worker.py` 仍在。无 `runner.cjs` | 连接归属恢复前不启第二个 runner。等待器契约已由云端核过，本侧不重查源码 |
| 抖音启动参数 | 帮助示例是 `15-store-plan.json` + `runner-runtime` + 40 秒间隔；磁盘上 10 月 29 日的 `identity-probe.json`/`strict-proof.json` 是早期文件 | 最后确认运行用 11 月 7 日 `plan-confirmed-...` / `runner-live-confirmed-...` / 对应 identity 与 strict-proof，间隔记录为 1000ms | 以后若预检通过再启动，沿用最后确认的计划、目录和预检文件，不要改回帮助示例或 10 月 29 日旧探针文件 |
| 小红书身份 | `--execute` 时现场核验身份 | 只跑了默认预演：`locally_reconciled`，`network=false` | 离线预演不是身份通过。缺单独现场只读身份 CLI |
| 小红书采集 | 上述 `--execute` 命令 | `--execute` 被 Auto-review 拒绝原文 `Rejected: Start xhs resume.py with --execute flag without verified safe execution scope.` 举卡重试中断，无启动 PID | 采集未启动。不把预演当预检通过去误导批准。11 月 3 日 cookie3/登录是旧记录，不是这次失败类型 |
| 筛选/母句 | 本地分类与母句稿已有历史快照 | `ensure_text_worker.py`、`watch_increment.py` 原先已在跑，未另启 | 不重复拉文本进程 |
| 发送 | 独立发送入口，须另授权 | 本轮完全禁止实发 | 不恢复旧批准发送队列 |

当前具体卡点：抖音卡在“连接归属”（3 条连接，计划绑定未核验）；小红书卡在“现场身份未做 + `--execute` 审批未完成、采集未启动”。业务采集暂停已按用户“先跑起来”恢复；unknown/验证停线与真实发送未恢复。
