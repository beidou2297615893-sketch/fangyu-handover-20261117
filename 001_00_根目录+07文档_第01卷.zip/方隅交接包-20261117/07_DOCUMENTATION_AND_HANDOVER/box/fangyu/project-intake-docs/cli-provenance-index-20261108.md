# 方隅原CLI来源、版本及启动顺序索引
2026-11-08 17:39请求后的box现成资料整理（Asia/Shanghai）。仅准备信息，不恢复或发送。未碰本机、未联网、未运行CLI、未安装/下载/拉库/改代码。引文路径均相对本文件目录；source=source.md；Codex=codex-handoff-20261108-1731.txt。未全文重读历史，Codex仅按索引读取L174–242。

## 一、小红书：上游工具与本地包装分开
- **原第三方产品/项目已定位**：jackwener/xiaohongshu-cli，原记录项目URL https://github.com/jackwener/xiaohongshu-cli 。证据source L7182–7195、L7877（本轮关键词定位）；L7195明确作者说明链接，L7230引用该仓库PR87，L7563引用xhs_cli/client.py。该项目非小红书官方工具，不因开源即获平台授权。
- **原安装/下载证据缺口**：上述为原文引用的上游仓库，不是本机安装包的已证下载URL。release/tag/commit、安装包名称、下载渠道/日期/文件哈希均未核；不能写成已从该URL下载了某版。PR87只证明当时查过上游修复，不证明本机采用。
- **已核版本：未核**。Python解释器版本、上游CLI包版本及httpx等依赖版本未在本轮资料确证。`cli-runtime`是目录名，不是版本号；业务规则v4.3、pool-sop-v3也不是CLI版本。takeover-readonly.md L111、L120–123明确依赖/现用版本仍待核。
- **本地项目根**：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统`（takeover-readonly.md L28、L76；xhs-runtime.md L8）。运行时路径 `work/vendor/cli-runtime/Scripts/python.exe`（takeover L103、L110；local-runtime-check.md L152–156），是嵌入Python运行时定位，不是可证明上游来源的下载记录。
- **我们写的业务包装，不冒充下载产品**：采集 `work/xhs-resume-20261103/resume.py`，后增`verify_resume006.py`/`resume006.py`；准备/发送`work/xhs-send-current-20261029/prepare_logged_sender.py`、`prepare_latest_priority.py`、`bulk_run.py`、`managed_send_client.py`、`readback_client.py`；本地CLI适配`work/xhs-cli-standalone-entry/standalone_cli.py`。依据takeover L103–111；xhs-runtime L9–17；xhs-send-readiness.md L31–37。本地文件不等于上游原版CLI，补丁版本也不等于上游版本。

## 二、小红书原顺序（描述性历史，不是现在执行指令）
1. 已有内置Python运行时、原应用登录/会话流程；不可手工提取Cookie。登录成功不等于通过发送门闩，更不是抖音Bridge已连接。
2. **旧采集文档路线**：默认`resume.py`只预演；`--execute`才现场核身份并采集。原文完整命令仅可在local-runtime-check.md L94–108、L152–156查阅，本索引不另造通用`xhs ...`命令。默认预演`locally_reconciled/network=false`并非在线身份成功。
3. **后来候选路线**：`verify_resume006.py`产生verified证明，再由`resume006.py`消费；status/uid/session_home须匹配，旧默认与实际路径不一致。此路线未证成功：xhs-runtime.md L9–19、L23–30记录核验停止。它不是发送链必经门闩，不把InboxClient审核套到发送链。
4. **本地筛选/母句**：共用文本业务窗口、两平台账本分开；不重启/重做（local-runtime-check.md L157–159）。
5. **发送侧**：准备批文件及mapping/source-manifest→现行`bulk_run.py`预览→获具体批准后原Runner提交→独立回读。`prepare_logged_sender.py`是准备/预览，不是实际提交器（xhs-send-readiness.md L31–37）。仅列既有顺序，本轮不运行任何阶段。`start.cmd→launcher.ps1`是10-28旧入口，非已证当前一键入口（xhs-runtime.md L12）。

### 最近成功证据（在本轮引用资料范围内）
- 历史发送：source L7774–7788，11-01累计457平台成功回执，19待核、91暂缓；受理不等于公开可见。对应CSV路径在L7786–7788；本轮未打开CSV。**原确切成功命令/脚本名未取得**（xhs-send-readiness.md L22–25），不能将后来定位的bulk_run反推为457那次原命令。
- 更后的登录成功：source L8520–8526记录CLI专用浏览器登录保存；同处批次被历史unknown拦住，发送0（L8538–8540）。不输出账号/会话目录细节，不以此证明现在可发。
- 新Codex交接仅历史概述：L220–228，含曾有效非游客会话、2755采集登记及31回复编号的旧报告；不是当前验收，也未给上游版本或确切下载/启动命令。

## 三、抖音对照：不要认错工具
- 用户原工具是**浏览器Node Bridge CLI**，不是Python `dy.exe`。Codex L174–191：后者为另一套`dy-cli 0.2.2`；该版本不能写成原Bridge版本。
- 原Node Bridge产品名/作者repo/下载URL及已安装版本：**未核**。现有本地路径和入口只能证明部署定位，不能反推下载仓库。
- 根同上；工具子目录`抖音自用采集台`。历史桥接代码`work/collector/cli.js`、`server.js`，历史运行时`work/node.exe`、配置`data/bridge.json`、端口19422（Codex L178–187）。较后现场运行时`work/runtime/douyin-bridge/node.exe server.js`（douyin-runtime.md L17–24）；两者是不同历史定位，不擅自合并。
- 包装入口：采集台`启动.cmd→miniconda3/python.exe app.py`；进度窗口`collection_progress_window.py→continue_collection.py→runner.cjs`；本地控制面板`work/douyin-local-control/打开本地进度.cmd→panel.py`（douyin-runtime.md L22–26、L33–39、L45–51）。不是已证上游通用CLI命令，旧reply-pilot启动器不当作当前任务入口。
- 原顺序：Bridge服务→浏览器网页/脚本真正挂接（仅浏览器登录不够）→绑定计划的身份/连接及严格预检→原runner采集→本地筛选/母句→独立回复链（local-runtime-check.md L139–148；Codex L186）。早期“必须关闭另两条连接”被后文更正：计划匹配且存活恰好一条即可，其他无关连接不必关闭（douyin-runtime.md L17–20），不采用早期误判。
- 成功范围：Codex L205报告11-04附近592平台回执快照；不是现在运行；L203保留分页核查后接续的历史先例。采集最近记录定位douyin-runtime.md L50–54：page_committed后停于ledger_unknown，active running为残留，不能当当前成功。版本/原下载来源仍缺。

## 四、可直接回答用户的准备结论
小红书上游项目已找到原文引用：jackwener/xiaohongshu-cli；抖音原用Node Bridge，不是dy-cli。两平台本地根、历史入口和启动先后已有精确定位；**两者原安装包/上游确切版本未核，抖音下载repo也未核，小红书457成功那次的确切命令未核**。因此可以交代准备顺序，不能给一个杜撰的通用CLI命令或保证开窗即连通。
本索引不授权安装、更新、启动、登录、采集、发帖或清unknown；本轮没有恢复XHS。后续如另获授权，可只核非敏感安装元数据/原下载记录补版本来源，不读会话或凭据；本轮不派本机核查。
