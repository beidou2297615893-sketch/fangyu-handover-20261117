# 小红书本机现场（2026-11-08 00:55 UTC+8，只读）
- 进程：本机无任何 resume.py / resume006 / xhs runner 进程（Win32_Process 全量 python/node 枚举）。在跑仅抖音 5444(+子29172 identity_check)、42084 bridge，文本 53852/48004。
- 卡/中断命令：未执行迹象。xhs-resume-20261103 最新写入 reconciliation.json 00:50:04 = status locally_reconciled, network=false, interrupted_batch_inserted=0, next_batch=22, remaining_pages=128, old_state_unchanged=true（即预演产物，非 --execute）。xhs-live-collection-runner-20261029 近2小时无文件写入。原审批卡状态未确认（仅证当前未见采集运行，不证卡失效或原命令永不执行）。
- 未动：未启动、未举卡、未kill、未读会话/Cookie。
- 最小下一步：负责人确认后，以原命令原参数 `resume.py --execute` 举一次审批卡；runner.py/client.py 脱敏机制副本待执行权内另取。

## 接管前实际启动器还原（01:05 只读）
根/工作目录：C:\Users\rmsama\Documents\ChatGPT\自动获客系统（命令均相对此根）
1. 11-03 resume.py --execute（README入口）：active-runner.json 11-03 15:47 status=stopped_dedicated_login_verification_required；账号蕾姆 uid 5aa9…，session_home xhs-standalone-session/stores15-user-relogin-20261030-03；runtime xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume005-20261103；本次新登记0，前段累计3914（stores15），send_authorized=false。dedicated-login 扫码确认后 verification_required，会话未保存。
2. 11-03 15:46 后出现 resume006.py / verify_resume006.py（晚于resume.py 12:09）。最后一次实跑是 11-06 15:33 verify（identity-check-resume006-latest-failure.json）：uid 5f469d…（另一账号），session_home xhs-standalone-session/huihuijiang-browser-login-20261105-01，status=stopped/Halt，stage=unknown，request_started=true，自动重试false → 按规则 unknown 停线。
3. 11-03 16:02–17:38 另有 browser-sample-0002..0043（浏览器DOM导入 import_browser_dom.py）旁路，非CLI链路，不复用。
4. 回复/发送侧：prepare_logged_sender.py（xhs-send-current-20261029，默认预览）；xhs-cli-standalone-entry/start.cmd→launcher.ps1 为10-28旧入口。发送禁止，未读。
结论：现用入口更可能是 resume006 链（先 verify_resume006.py --execute 写核验文件，resume006 消费），不是 resume.py；差异不是 collect_once，而是 11-06 身份核验 unknown 停线 + 账号/会话已切换（蕾姆→5f469d…）。未复制 collect_once。

## 账号/会话一致性（01:06 只读）
- resume006.py：UID=5f469df5…ec0b；HOME=env XHS_COLLECTION_SESSION_HOME，默认 work/xhs-standalone-session/stores15-ec0b-pending-20261103 —— 该目录不存在。L85 要求 verified 的 status/uid/session_home 三项匹配 HOME。
- verify_resume006.py：--session-home 必填，--uid 默认 5f469d…；11-06 用的是 huihuijiang-browser-login-20261105-01 → 与 resume006 默认 HOME 不一致，即使核验成功也会被 verified_new_account_required 拒，除非显式设 env 同路径。
- 候选 ec0b 会话：huihuijiang-browser-login-20261105-01（11-05 14:09，11-06核验所用）；另有 huihuijiang-reply-verified-20261105-02 等回复侧会话。未读任何会话内容。
- identity-check-resume006.json（旧）=stopped/SessionStop，无有效 verified。平台验证/拒绝：11-06 failure 无 http_status/verification 证据，仅 Halt stage=unknown；11-03 蕾姆曾 461/verification_required。
- 注意：stores15-user-relogin-20261030-03（蕾姆）目录 mtime=11-08 00:50:04，与 resume.py 预演同时刻，预演疑触碰该会话目录（未读内容）。
- 旧卡：仍未知。

## 单次身份核比（01:06:41 UTC+8，已执行一次）
命令：work\vendor\cli-runtime\Scripts\python.exe -u -B -X utf8 work\xhs-resume-20261103\verify_resume006.py --execute --session-home work\xhs-standalone-session\huihuijiang-browser-login-20261105-01（执行前确认无同类进程）。exit=0。
回执 identity-check-resume006-latest-failure.json：status=stopped, error_type=InboxStop, reason=session_update_requires_review, http_status=200, stage/endpoint=unknown, automatic_retry=false；uid、session_home 与输入一致（取自输入参数，实际平台身份未证）；status≠verified。exit=0 为捕获异常后正常退出。identity-check-resume006.json 未更新（仍旧SessionStop）。无平台验证/拒绝迹象。未重试、未串resume、未读cookies。
解读（未查源码，仅凭client.py L31已读机制）：请求成功返回后会话Cookie被平台更新，客户端按设计拒绝自动保存，要求人工审阅会话更新。

## 收束（01:09）
云端窄查结论（经负责人转）：session_update_requires_review = 响应后Cookie不同即抛，锁实例不写回；无确认入口/参数/保存步骤。
待修产品问题：小红书客户端缺少正常会话更新审阅机制，导致身份核验无法通过。保持停线；不再verify/补依赖/启动resume/读凭据，等明确修复任务。旧resume卡仍未知；发送禁止。
