# 抖音本机运行增量（00:55 UTC+8，方隅抖音链路专责，唯一操作者）
- runner_README L9/L39–46：计划字段含 connection_id；runner要求实际返回连接与计划指定连接一致，并须有 identity-probe.json、strict-proof（account_uid/connection_id与计划一致）。
- 只读查看 plan-confirmed-20261107-051216-338401.json：PowerShell 解析 JSON 失败（ArgumentException，疑重复键/格式问题），未取得 connection_id；文件末段有 connection_rebind（2026-11-07 18:00 UTC+8，原页连接离线、同账号在当前页重核，operator Codex）。账号标识不在此记录。
- 未列 Bridge 连接、未关/杀任何进程、未启动 runner、未发送。
- 缺口：缺一个可只读列出 Bridge 存活连接 connection_id 的现成命令（README未给）；需云端从 bridge-client 给出机制，或用 Node 严格 JSON 解析取计划 connection_id 后比对。

## 00:57 增量
- Node 严格解析计划成功：顶层 connection_id 存在；connection_rebind 无 connection_id（键 at/reason/account_uid/operator），即rebind只重核账号、未写新连接标识，顶层connection_id可能仍是离线旧页的。未输出标识值。
- Bridge 列连接：无文档化只读命令，预检停止，未关/杀。
- 副本：import/douyin/bridge-client.js（源SHA256 0AE5E749…448E）、collection_wait_worker.py（源SHA256 0267A6CB…BE9BE）；box侧SHA见下行。依赖：bridge-client 由 runner.cjs L361、identity_probe.cjs L7 引用，未取其余 bridge 服务端。
0ae5e74909915fc08278a830767644989bff92e74636d913220a9ed07a36448e  bridge-client.js
0267a6cb20c2b70678c3fddc1b3d8e394e507213213daa9c85a90da29a7be9be  collection_wait_worker.py

## 01:00 增量
- 用 BridgeClient.status（仅GET /api/status，配置取自 抖音自用采集台/data/bridge.json，令牌只在内存）：ECONNREFUSED，本地Bridge未在监听，无法核对计划connection_id是否存活。未重试、未启动Bridge、未关连接。

## 01:03 更正与增量
- 01:00 ECONNREFUSED 是我的读取错误：bridge.json 字段嵌套在 bridge 下，未取到端口，客户端落到默认19432。Bridge 实际在运行：PID 42084，work/runtime/douyin-bridge/node.exe server.js（package.json scripts.server = node server.js），监听127.0.0.1:19422，与配置一致；11-07 18:02 UTC+8 启动。
- 正确端口 GET /api/status：douyin.com 共3条连接都存活；计划 connection_id（sha8 2d466d84）匹配且存活的恰好1条，满足 runner 连接条件。另两条 a082b9fe、1b196080 与计划无关，不用关。
- 因此早前 collection_identity_check 失败的原因不在连接数，待查 uid（sec_uid 与计划 account_uid）/授权核验。未启动、未关闭、未改动。

## 01:08 现成启动器定位（只读，未执行）
- 采集台：抖音自用采集台\启动.cmd → miniconda3\python.exe app.py（同目录 data\bridge.json 即 Bridge 配置）。
- Bridge：work\runtime\douyin-bridge\node.exe server.js（PID 42084 在跑，127.0.0.1:19422）。
- 本地进度面板：work\douyin-local-control\打开本地进度.cmd → pythonw panel.py。
- 回复（发送，禁止执行）：outputs\方隅抖音批量回复\开始本批回复.cmd → pythonw work\fangyu-douyin-independent\reply-pilot\batch_window.py。
- 最后回复记录 reply-pilot\launcher-last.log（11-02 01:40）：第228–232条 SUCCESS（每条约1秒），第233条 UNKNOWN status_code=2147 平台拒绝未给原因，已停止不重发。该unknown不能解除。

## 01:03 身份核验单次复跑
- node collection_identity_check.cjs <plan-confirmed-20261107-051216-338401.json> ..\..\抖音自用采集台\data\bridge.json（与 collection_wait_worker L51 同一配置来源），01:02:56 UTC+8，exit=1：ok=false，connection_matches=false，uid_matches=false。白名单过滤没抓到错误类别字段（可能是中文或嵌套值），未复跑。
- 差异：/api/status 显示计划 connection_id 存活且唯一，但核验仍报 connection_matches=false——核验比对的对象（实际返回 connection / sec_uid）需由云端按脚本契约解释。脚本静态扫描无写文件/POST/STOP/halt 字样。

## 01:06 采集台入口
- 启动.cmd：工作目录=抖音自用采集台（cd /d %~dp0），Python=C:\Users\rmsama\miniconda3\python.exe（存在），命令 python.exe app.py。目录内无 README/说明/requirements。
- 当前无 app.py 进程。app.py 8954B，09-30 17:09，SHA256 006499cb…3530；只用标准库（tkinter GUI + socket/subprocess/threading）。副本 import/douyin/collector-desk-app.py，SHA一致，秘密扫描无命中。
- 是否纯UI、打开后是否自动采集/发送/重放unknown/删数据：没有文档证据，交云端窄核。旧runner身份核验失败 ≠ 采集台也卡在这里（未证）。

## 01:07 采集台UI已打开
- 启动前无 app.py 进程；Start-Process miniconda3\python.exe app.py（CWD=抖音自用采集台），PID 50660 存活，窗口标题「抖音自用采集台 · 采集与人工复核」。未点击“保存并启动采集”，未启动采集、未运行回复启动器、未动Bridge。

## 01:09 采集台设置只读
- data/settings.json 存在：任务名=代码默认 daily；采集连接ID为空；关键词2个且等于代码默认值（非方隅租房词）；账号槽5个。连接为空，故无存活匹配。无 long-fangkong collector 进程。
- 采集JS副本 import/douyin/long-fangkong-comment-job.js，SHA 1c3b2686…3aca 源与副本一致。

## 11-08 auto-entry locate
- Codex获客工作台 (启动工作台.ps1→work\server.py, 19747) = non-方隅 scope, old; not running.
- 方隅 auto chain: fangyu-douyin-independent\collection_progress_window.py → continue_collection.continue_active → runner.cjs --plan <active.plan>; CLI `continue_collection.py --confirmed <id>`. sha256 425bfc83/1d3fb60b/75b25ed9.
- Procs: Bridge 42084, wait_worker 5444 (11-07 18:12), no runner/server.py. Reported to lead.

## 11-08 01:13 last auto-collection record (read-only)
- Entry: progress window 「抖音采集｜进度与继续」 (collection_progress_window.py→continue_collection.py); stdout runner-ui-continue-20261107-051216-338401-stdout.log, last write 11-07 20:24 UTC+8.
- Tail: page_committed ×2 → paused reason=ledger_unknown. control: stopped=ledger_unknown, nextIndex=9, pending=null. STOP absent.
- active-runner.json says running pid 36212, process absent → stale. Not cleared.
- Hold: keep ledger_unknown stop; no continue/replay/confirm-id; don't touch control/ledger/active.
- Risk: a control.json parse failure echoed the raw JSON to output once; not reposted, not committed. Rule: strict parse + whitelist; on failure print exception type only.
