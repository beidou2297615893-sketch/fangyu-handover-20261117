# 工作台四格时间字段口径（2026-11-14）

依据：11-09 有效池形态样本（`filter-audit-20261109/data/retained-dy-sample-200.jsonl`、`screened-high-intent.jsonl`）和共享账本 `ledger.py` 副本（`/workspace/dy-deploy/private/ledger-copy-for-box.py`）。**不是当天生产库现核。** 生产库表结构需另做只读 PRAGMA / 字段名核对。

## 有效池件数

沿用原进度窗：hash 核验 `visible_business_pool` 中/高/超高，再扣共享账本 `reservations+leads` 中 `platform=douyin` 且 `status=sent/unknown` 的评论或客户，以及旧回执 `sends.status='SENT_VERIFIED'`。不用「累计采集 − 累计回复」倒推。云电脑没有本机状态文件时显示 —。不要把分类交接、jsonl、账本整份拷到云电脑。

## 今日采集：暂无入池时间列

样本中没有 `entered_at` / `pooled_at` / `classified_at` / `admitted_at`。

已见到、但不得用来切片「今日采集」的列：

- `published_at`（字符串时间）、`published_at_unix`（float）：评论发布时间，只用于近 30 天窗口。
- `source_observations[].observed_at`：采集时看到这条评论的时间，不是筛进入池时间。

今日采集继续显示 —，不要用上面两列凑数。

## 今日回复：账本没有确认发出时间列

`outcome` 写成 `sent` 时：

- 只更新 `reservations.status`、`reservations.evidence`
- 同时把 `leads.status` 改为 `sent`，并把 `leads.review_time` 清空
- **不写 sent_at**

因此：

- `leads.review_time`：只用于审核/history_clear 窗口，sent 之后是空的，不能当发出时间。
- `reservations.created`：预留写入时间，不是确认发出时间。
- 原 `summary.py` 用评论 `create_time` 分今天/昨天，那不是「今日我方确认发出」。

旧回执 `sends` 在现有读取代码里只用到 `cid`、`uid`、`status`，未见发出时间列（生产库表结构待核）。

今日回复继续显示 —。

## 有效池加减

还缺上一份已核验快照，没有就不要编。累计在今日切片未定前也保持 —。

## 2026-11-14 15:38 生产库只读核对应（抖音链路回报，未改文件、未拷库）

与上面口径一致，生产库仍没有可切「今日采集 / 今日回复」的入池时间或确认发出时间列。

- 当前可见有效池文件指针可读：`douyin-semantic-repair-v5\retained-business-customers.jsonl`（sha256 已回报；未重算整文件哈希，未抄客户内容）。
- 该 jsonl 前 2 条字段名：没有 entered_at / pooled_at / classified_at / admitted_at。时间类字段仍是 published_at、published_at_unix、source_observations[].observed_at，以及部分记录的 classification.original_metadata.published_at。
- shared.sqlite3：reservations 列为 token, platform, customer, comment, status, evidence, created；leads 列为 platform, customer, comment, status, review_time, evidence, operator, source。没有 sent_at / outcome_at / updated。
- 旧回执 sends 列：account, cid, uid, position, status, text, sha, evidence, note, updated（TEXT）。有 updated，没有 sent_at / outcome_at。未看字段值，也未在源码里找到写入 updated 的实现，故 **不得把 sends.updated 当作确认发出时间**。

今日采集、今日回复、累计、有效池加减继续显示 —。
