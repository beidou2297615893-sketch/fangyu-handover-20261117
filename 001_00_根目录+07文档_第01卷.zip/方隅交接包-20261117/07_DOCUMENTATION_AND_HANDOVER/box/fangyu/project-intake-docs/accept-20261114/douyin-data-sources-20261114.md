# 抖音原窗口入口、状态文件与统计算法（2026-11-14）

来源：抖音链路只读回报。负责人未逐项复验现场进程。未授权在用户电脑执行下列任何命令，也不得另开 Bridge / 采集 / 发送。

简称：

- R = `C:\Users\rmsama\Documents\ChatGPT\自动获客系统`
- CI = `R\work\fangyu-douyin-independent`
- C = `R\work\douyin-local-control`
- TEXT = `R\work\fangyu-text-business-20261029`
- Python：`C:\Users\rmsama\miniconda3\python.exe` / `pythonw.exe`

对照依据（对方自述）：今日《紧急交接-以本文件为准-20261114》、今日路径清单，以及与本机同大小的原窗口源码副本（采集进度窗 15208 字节，与本机 2026-11-11 00:34 文件一致）。

## 一、原窗口入口与启动方式

### 1. 采集进度窗

- 源码：`CI\collection_progress_window.py`
- 标题：抖音采集｜进度与继续
- 只开窗、不启动采集：在 CI 下 `pythonw collection_progress_window.py`
- 开新一轮时，`CI\new_round.py` 若发现还没有 `collection_progress_window` 进程，会自动同样拉起该窗。`continue_active` / 弹窗续采都不会自动开这个窗，需另开并置顶。
- 关闭窗口不会停采集。

### 2. 回复面板

- 源码：`C\panel.py`
- 标题：抖音回复｜近30天进度
- 标准入口：`C\打开本地进度.cmd`（切到 R，再 `start pythonw C\panel.py`）
- 11-10 接手说明里桌面快捷方式是 `C:\Users\rmsama\Desktop\方隅发送面板.lnk`，指向上述 cmd。今日路径清单核过 cmd 仍在，未再单独核该快捷方式是否还在桌面，请以 cmd 为准。
- 面板里「启动／继续」才会跑 `C\control.py`（有 hold 时加 `--check-resume`，否则 `--employee-start`）。只开面板不等于发送。

### 3. 验证码/停顿弹窗

- 源码：`CI\collection_stop_popup.py`（标题：抖音采集已停止）
- 续采脚本：`CI\collection_popup_resume.py`（做法等同原 `start_collect` / `continue_active`：先挪 runner 目录里的 STOP，再 `continue_active`）
- 启动：在 CI 下 `pythonw collection_stop_popup.py`（单实例，互斥名 `Local\FangyuDouyinCollectionStopPopup`）
- 11-12 已放到用户开机启动文件夹，快捷方式名「抖音采集停止弹窗.lnk」，目录一般是 `C:\Users\rmsama\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup`。对方称今日进程清单里已能看到该弹窗在跑，未再点开快捷方式复核。
- 采集非手动停下时置顶弹出；验证码点完可在弹窗里点「继续采集」。这个弹窗尚未收进软件，也还没替换掉原进度窗。

## 二、工作台应读的状态/库，以及原统计算法

现装 Direct 的 `local_progress.py` 只读下面这些 JSON，`completeStatistics=false`，不能替代原窗口数字。覆盖说明在 `direct-desktop\sources\LOCAL_PROGRESS_COVERAGE.md`。

### 采集状态（CI）

- `active-runner.json`（当前任务指针；pid 不能单独当成仍在跑）
- 其所指 directory 下的 `control.json`、`STOP`、stdout/stderr
- `collection-wait-state.json`
- `current-collection-status.json`
- `progress-report-state.json`，或 `active-runner.diagnostic` 指向的文件
- `classification-handoff-status.json`（含 `visible_business_pool`、`commercial_fit`、`pending_candidates_count`）
- `auto-collect.stop`

### 发送状态（C 及任务目录）

- `C\status.json`、`active.json`、`douyin-send-hold.json`、`auto-continue.stop` / `auto-continue.log`
- 任务目录由 `C\active.json` 的 task 指向：`batch-runner-status.json`、`batch-stop.json`、`batch-context.json`、`approved-cli-queue.json`、`unavailable-targets.json`，以及各条 `cid.json` / `cid.json.submitted`

### 数据库与池文件（只读，短超时）

不要对 `collection.sqlite3` 做重查询，对方称库大约 10GB。

- `CI\runtime\collection.sqlite3`
- `R\work\shared-acquisition-ledger\shared.sqlite3`
- `R\Codex获客工作台\work\reply_receipts.sqlite3`（旧 SENT_VERIFIED 回执）
- 可见有效池、全量筛选池的实际路径和哈希，以 `classification-handoff-status.json` 里 `visible_business_pool.file/sha256`、`commercial_fit.all_pool_file/all_pool_sha256` 为准。
- 生成侧通常是 `TEXT\douyin-semantic-repair-v5\retained-business-customers.jsonl` 和 `all-pool-business-fit.jsonl`，由 `TEXT\retention-cleanup-20261106\ensure_text_worker.py` → `douyin-semantic-repair-v5\watch_increment.py` → `build_snapshot.py` 写入。
- 哈希对不上就显示「正在核验/更新」，不要用旧快照凑数。
- 没有数据时显示「—」，不要填 0。

### 原算法文件

- 有效池加减、已回复扣除、unknown 单列：`CI\collection_progress_window.py` 的 `_reply_status_sets()`、`_pool_display_counts()`。
  - 口径：先 hash 核验 `visible_business_pool` 里中/高/超高记录；再与共享账本 `reservations+leads` 里 `platform=douyin` 且 `status=sent/unknown` 的 comment/customer，以及旧回执 SENT_VERIFIED，按评论或客户并集扣除。
  - 有效池 = 通过筛选 + 近30天 + 未回复；unknown 和预留不算进池。
  - 不要用「累计采集 − 累计回复」倒推有效池。
- 本轮扫描/入账：同一文件 `poll()`。`scan_pages` 按 `plan.scan_id` 计数；新增评论是 `entities(kind=comments)` 联结 `attempts.spec.scan_id`；扫描评论数累加 stdout 里 `page_committed` + `kind=comments` 的 `recent_counts`。
- 近30天符合条件、本批可回复、已回复：`C\summary.py` 的 `Summary.refresh()` 与 `live()`，由 `C\panel.py` 调用（资格集合约 60 秒重算，直播状态约 1.5 秒刷新）。
  - `refresh`：用 `collection.sqlite3` 评论 `create_time` 做滚动 30 天；hash 核验 `commercial_fit.all_pool_file`；只要中/高/超高且 `eligible_candidate=true`；再对 `approved-cli-queue` 做 `items_sha256` 校验，排除 `unavailable-targets` 和已有提交文件。
  - `live`：同一账本口径汇总 `total` / `sent` / `remaining` / `unmatched`。
- 今日采集、今日回复、累计：原进度窗和回复面板没有这四个工作台字段的现成函数。工作台口径写在「定稿有效池版」《界面与按钮说明.md》：
  - 今日采集 = 今天通过筛选并加入有效池的条数（不是原始扫描评论）
  - 今日回复 = 今天我方已确认发出并因此出池的条数（不是客户回我们）
  - 累计采集/累计回复 = 同平台同权限范围的累计
  - 要对齐，必须在上述原算法上按北京时间「今天」切片，不要另写一套。
  - 入池时间用哪一列，需对照生产 jsonl 原字段；抖音链路称没有打开现场大库或生产 jsonl。

## 三、Bridge 和浏览器的现成命令（不要在用户电脑执行）

没有已经做好的「依赖 + 浏览器 + Bridge」一键准备入口。今日紧急交接里的「一键准备」是目标，不是现成脚本。现成、可复用的分项是：

- 现行严格桥（现场现在就是这样跑的，不要再开一条）：在 CI 下

  `node strict-bridge-server.cjs --serve --config "R\抖音自用采集台\data\bridge.json" --port 19422 --allow-owned-19422`

  不带 `--allow-owned-19422` 会报 `original_port_protected`。配置只读该 `bridge.json`，不要提取浏览器凭据。

- 原采集台壳（会起采集台窗口，可能抢前台，集成时不要在用户电脑上试）：`R\抖音自用采集台\启动.cmd` → 同目录 `python app.py`。
- 只检查配置、不监听端口：`node CI\strict-bridge-server.cjs --check-config --config "R\抖音自用采集台\data\bridge.json" --port 19423`
- 新工作台 `sources\system_browser_login.py` 只会打开官方抖音登录页，不启动 Bridge，`collectionReady` / `bridgeConnected` 现为 false，不能当原 CLI 的一键准备。

现场仍由抖音链路独占操作。对方称采集从今天 13:36（北京时间）用当前登录号在跑，发送停止标记仍保留，未再开发送。此为对口回报，负责人未在本轮复验。
