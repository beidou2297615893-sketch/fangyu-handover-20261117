import json,hashlib,os,re
B='/workspace'
src={
'cli_index':'project-intake/fangyu/cli-provenance-index-20261108.md',
'codex_idx':'project-intake/fangyu/codex-handoff-20261108-1731-index.md',
'mapping':'project-intake/fangyu/software-acceptance-mapping.md',
'xhs_route':'project-intake/fangyu/xhs-existing-recovery-route.md',
'send_handoff':'dy-deploy/send-handoff-1803.md',
'dy_runtime':'project-intake/fangyu/douyin-runtime.md',
'local_check':'project-intake/fangyu/local-runtime-check.md',
'v3_accept':'dy-acceptance/inrun-isolation-v3-acceptance.md',
'iso_install':'dy-deploy/isolate-install-1738.md',
'ds_status':'notes/deepseek-api-connection-status.json'}
man={}
for k,p in src.items():
  fp=f'{B}/{p}';d=open(fp,'rb').read()
  man[k]={'path':fp,'exists':True,'bytes':len(d),'lines':d.count(b'\n')+1,'sha256':hashlib.sha256(d).hexdigest(),'mtime':os.path.getmtime(fp)}
def R(k,a,b=None): return {'src':k,'lines':[a,b or a]}
chains=[
{'chain':'douyin_send','data_time':'2026-11-08 18:12 snapshot; superseded by main-window reports 18:16–23:46 (unverified here)',
 'entry':'C\\打开本地进度.cmd -> pythonw panel.py -> [启动/继续] python.exe control.py (cwd=R) -> T\\batch_reply_runner.py|resume_after_confirmation.py -> node.exe send_cli_once.cjs <attempt>',
 'interpreter':'C:\\Users\\rmsama\\miniconda3\\python(w).exe','proven':['entry/cmd chain read on-machine 18:12','1520 queue hash match 17:47 copy','泪痣 binding consistent','--check-resume returns before runner but calls send_cli_once --preflight (writes checkpoint)'],
 'unproven_or_stale':['18:12 counts sent877/unknown9 are stale','0d1e252 seven files != fully recoverable: main window reported 18:16 prepare_verified only accepts preserve -> AssertionError','later single-file fix, ALLIE 6-file pack (65f8586) and queue_business_screen.py increment (05f3269d…) installed = main-window report only','23:45 stop on cid in isolated list but runner only honoring preserve (agent report)'],
 'recovery_preconditions':['single operator','无重复/冲突持锁运行（健康业务不停止，面板存在不妨碍接续）','unknown preserved/isolated, never resent','hold inactive','account binding match; captcha/hold/identity stop -> no auto switch'],
 'refs':[R('send_handoff',17,90),R('send_handoff',91,125),R('send_handoff',182,201),R('send_handoff',241,302)]},
{'chain':'douyin_collect','data_time':'11-08 01:13 and 18:00 reports',
 'entry':'collection_progress_window.py -> continue_collection.py --confirmed <id> -> runner.cjs --plan <active.plan>; Bridge work\\runtime\\douyin-bridge\\node.exe server.js :19422; desk 启动.cmd -> python app.py',
 'proven':['plan connection matches and alive exactly once is sufficient; other connections not conflicts','【历史观察 11-08 01:13/18:00，非当前】stopped=ledger_unknown nextIndex=9；active-runner.json残留；更晚现场未核'],
 'unproven_or_stale':['identity_probe global got2 is old/strict check, not plan-bound','collection_identity_check connection_matches=false cause unexplained','--resume-local cannot clear ledger_* halt; no legal existing continuation located'],
 'recovery_preconditions':['shared ledger with send; do not reshuffle ordering','do not retry unknown page; keep evidence'],
 'refs':[R('dy_runtime',17,20),R('dy_runtime',29,31),R('dy_runtime',45,55),R('cli_index',23,29)]},
{'chain':'xhs','data_time':'11-03..11-08 box docs; user computer off',
 'entry':'work/vendor/cli-runtime/Scripts/python.exe -u -B -X utf8 work/xhs-resume-20261103/resume.py [--execute]; send: prepare_logged_sender.py preview -> managed_send_client -> readback_client.py',
 'proven':['upstream jackwener/xiaohongshu-cli (cited, version unverified)','resume.py default = local preview, no login entry','【历史观察：resume.py最后记录停于11-03 verification_required，非当前】更晚仅专责01:39报告，现场未核'],
 'unproven_or_stale':['standalone QR login script path not located','resume006 blocked by session_update gate (not adopted)','prepare_latest_priority reads old daily-priority, not v4.3','preview may touch session mtime'],
 'recovery_preconditions':['user logs in via app flow; no cookie handling','verify current send authorization; no old drafts','stop on captcha/identity anomaly'],
 'refs':[R('cli_index',4,21),R('xhs_route',3,18),R('local_check',94,108),R('local_check',150,160)]}]
issues=[
{'issue':'single item failure / no resend','fix':'0d1e252 startup isolation; v3 acd6c08 in-run isolation (NOT installed per 18:12); ALLIE 65f8586 (reported installed)','real_coverage':'v3 tests use simulate_execute only, zero runner.execute, no real CLI; lock simulated, no dual-process','constraint':'restart must not resend; isolated must be honored by prepare_verified and runner','refs':[R('v3_accept',13),R('v3_accept',60,69),R('send_handoff',202,240)]},
{'issue':'multi-account rotation','fix':'existing shared ledger + accounts.json 5 task dirs','real_coverage':'none verified at runtime','constraint':'shared ledger/pool, no per-account patches; caps are user experience configurable, not platform official','refs':[R('mapping',8),R('send_handoff',312,339)]},
{'issue':'rule/role screening','fix':'queue_business_screen.py increment 05f3269d (reported)','real_coverage':'unknown','constraint':'verify actual load chain, not asset presence','refs':[R('mapping',9)]},
{'issue':'near-200 reminder & consecutive-reject pause','fix':'NOT implemented','real_coverage':'none','constraint':'threshold from user scheme, no invented numbers; reminder != auto-switch','refs':[R('mapping',10),R('mapping',21)]},
{'issue':'CLI boundary','fix':'n/a','real_coverage':'n/a','constraint':'基础上游CLI跟随上游、不改内部；send_cli_once.cjs等属本地业务adapter，需修改时按既有审批，不是永不允许修改','refs':[R('mapping',11)]},
{'issue':'159 x 2147 recovery','fix':'offline prep owned by 规则与运营报告 (manifest ...20261108-2343, sha prefix 243174)','real_coverage':'not in this stream','constraint':'old "wait for OK" is historical; ops reported new main-window decision; user authorization not verified here; production not executed','refs':[R('mapping',22)]}]
local=['【条件式接续，非必做新清单】先由原负责人复用最新已有结果（主窗/抖音链路/运营报告），仅仍影响恢复的缺项才一次窄核；不要求再全量对比v3/ALLIE混版','可能缺项示例：prepare_verified是否认 preserve∪isolated（18:16 AssertionError 是否已被后续修补消除）','可能缺项示例：采集身份检查 connection_matches=false 原因','可能缺项示例：XHS扫码登录程序位置（仅文件名及login/qr引用行）']
codex=['runner/prepare端到端一致识别isolated名单，补真实execute()测试（非simulate）','接近200提醒+连续拒绝暂停：在业务包装层做成可配置（阈值待用户方案）','采集ledger_unknown停线的合法续法（不重采未知页）——仅当原负责人确认无既有续法时','【非开发需求】XHS受管会话更新路径已暂停/不采用，待用户决定或既有方案接续缺口，不授权接线；v4.3接线属后置，非恢复原CLI前提']
calls={'backend':'deepseek','model':None,'count':0,'reason':'deterministic script sufficient; no inference','balance_query':'not performed (no call)','usage':None,'prior_record':'02:13 connectivity sample deepseek-flash 56 tokens, balance CNY 54.00 (from status file)'}
out={'generated':'2026-11-09 02:4x Asia/Shanghai','production_run':False,'chains':chains,'issues':issues,'local_checkpoints':local,'codex_min':codex,'model_calls':calls,'manifest':man}
spot=[('send_handoff',34,34,'pythonw.exe'),('dy_runtime',19,19,'恰好1条'),('local_check',19,19,'resume.py')]
sc=[]
for k,a,b,kw in spot:
  L=open(man[k]['path'],encoding='utf-8').read().split('\n')[a-1:b]
  sc.append({'src':k,'line':a,'keyword':kw,'matched':any(kw in x for x in L)})
# validate refs
errs=[]
for sec in chains+issues:
  for r in sec['refs']:
    if r['lines'][1]>man[r['src']]['lines']: errs.append(r)
txt=json.dumps(out,ensure_ascii=False)
secret=bool(re.search(r'sk-[A-Za-z0-9]{16,}|sec_uid=|MS4wLj',txt))
out['validation']={'json_ok':True,'sources_exist':all(m['exists'] for m in man.values()),'ref_out_of_range':errs,'secret_pattern_hit':secret,'customer_text_included':False,'spot_checks':sc}
json.dump(out,open('night-summary.json','w'),ensure_ascii=False,indent=1)
json.load(open('night-summary.json'))
md=['# 方隅夜间三链收敛 2026-11-09','生成：脚本，未运行生产/未访问本机/未调用模型。JSON: night-summary.json','## 1 三链入口（标【历史观察】者非当前；主窗/专责更晚报告≠已核现场）']
for c in chains:
  md+= [f"### {c['chain']}（资料时间：{c['data_time']}）",f"- 入口：`{c['entry']}`"]+[f'- 已证：{x}' for x in c['proven']]+[f'- 未证/过时：{x}' for x in c['unproven_or_stale']]+[f'- 前提：{x}' for x in c['recovery_preconditions']]+['- 来源：'+'; '.join(f"{r['src']} L{r['lines'][0]}-{r['lines'][1]}" for r in c['refs'])]
md+=['## 2 问题→修复→覆盖→约束']+[f"- **{i['issue']}**｜{i['fix']}｜覆盖：{i['real_coverage']}｜约束：{i['constraint']}" for i in issues]
md+=['## 3 待本机最小检查点']+[f'- {x}' for x in local]+['## 3b 待Codex最小问题']+[f'- {x}' for x in codex]
md+=['## 4 Manifest']+[f"- {k}: {v['path']} {v['lines']}行 sha {v['sha256'][:16]}" for k,v in man.items()]+[f"- 验证：{out['validation']}"]
md+=['## 5 模型调用',f'- {calls}']
open('night-summary.md','w').write('\n'.join(md)+'\n')
print(out['validation'])
