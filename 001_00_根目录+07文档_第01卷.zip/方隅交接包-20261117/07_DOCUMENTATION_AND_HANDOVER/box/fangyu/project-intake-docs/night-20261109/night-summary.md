# 方隅夜间三链收敛 2026-11-09
生成：脚本，未运行生产/未访问本机/未调用模型。JSON: night-summary.json
## 1 三链入口（标【历史观察】者非当前；主窗/专责更晚报告≠已核现场）
### douyin_send（资料时间：2026-11-08 18:12 snapshot; superseded by main-window reports 18:16–23:46 (unverified here)）
- 入口：`C\打开本地进度.cmd -> pythonw panel.py -> [启动/继续] python.exe control.py (cwd=R) -> T\batch_reply_runner.py|resume_after_confirmation.py -> node.exe send_cli_once.cjs <attempt>`
- 已证：entry/cmd chain read on-machine 18:12
- 已证：1520 queue hash match 17:47 copy
- 已证：泪痣 binding consistent
- 已证：--check-resume returns before runner but calls send_cli_once --preflight (writes checkpoint)
- 未证/过时：18:12 counts sent877/unknown9 are stale
- 未证/过时：0d1e252 seven files != fully recoverable: main window reported 18:16 prepare_verified only accepts preserve -> AssertionError
- 未证/过时：later single-file fix, ALLIE 6-file pack (65f8586) and queue_business_screen.py increment (05f3269d…) installed = main-window report only
- 未证/过时：23:45 stop on cid in isolated list but runner only honoring preserve (agent report)
- 前提：single operator
- 前提：无重复/冲突持锁运行（健康业务不停止，面板存在不妨碍接续）
- 前提：unknown preserved/isolated, never resent
- 前提：hold inactive
- 前提：account binding match; captcha/hold/identity stop -> no auto switch
- 来源：send_handoff L17-90; send_handoff L91-125; send_handoff L182-201; send_handoff L241-302
### douyin_collect（资料时间：11-08 01:13 and 18:00 reports）
- 入口：`collection_progress_window.py -> continue_collection.py --confirmed <id> -> runner.cjs --plan <active.plan>; Bridge work\runtime\douyin-bridge\node.exe server.js :19422; desk 启动.cmd -> python app.py`
- 已证：plan connection matches and alive exactly once is sufficient; other connections not conflicts
- 已证：【历史观察 11-08 01:13/18:00，非当前】stopped=ledger_unknown nextIndex=9；active-runner.json残留；更晚现场未核
- 未证/过时：identity_probe global got2 is old/strict check, not plan-bound
- 未证/过时：collection_identity_check connection_matches=false cause unexplained
- 未证/过时：--resume-local cannot clear ledger_* halt; no legal existing continuation located
- 前提：shared ledger with send; do not reshuffle ordering
- 前提：do not retry unknown page; keep evidence
- 来源：dy_runtime L17-20; dy_runtime L29-31; dy_runtime L45-55; cli_index L23-29
### xhs（资料时间：11-03..11-08 box docs; user computer off）
- 入口：`work/vendor/cli-runtime/Scripts/python.exe -u -B -X utf8 work/xhs-resume-20261103/resume.py [--execute]; send: prepare_logged_sender.py preview -> managed_send_client -> readback_client.py`
- 已证：upstream jackwener/xiaohongshu-cli (cited, version unverified)
- 已证：resume.py default = local preview, no login entry
- 已证：【历史观察：resume.py最后记录停于11-03 verification_required，非当前】更晚仅专责01:39报告，现场未核
- 未证/过时：standalone QR login script path not located
- 未证/过时：resume006 blocked by session_update gate (not adopted)
- 未证/过时：prepare_latest_priority reads old daily-priority, not v4.3
- 未证/过时：preview may touch session mtime
- 前提：user logs in via app flow; no cookie handling
- 前提：verify current send authorization; no old drafts
- 前提：stop on captcha/identity anomaly
- 来源：cli_index L4-21; xhs_route L3-18; local_check L94-108; local_check L150-160
## 2 问题→修复→覆盖→约束
- **single item failure / no resend**｜0d1e252 startup isolation; v3 acd6c08 in-run isolation (NOT installed per 18:12); ALLIE 65f8586 (reported installed)｜覆盖：v3 tests use simulate_execute only, zero runner.execute, no real CLI; lock simulated, no dual-process｜约束：restart must not resend; isolated must be honored by prepare_verified and runner
- **multi-account rotation**｜existing shared ledger + accounts.json 5 task dirs｜覆盖：none verified at runtime｜约束：shared ledger/pool, no per-account patches; caps are user experience configurable, not platform official
- **rule/role screening**｜queue_business_screen.py increment 05f3269d (reported)｜覆盖：unknown｜约束：verify actual load chain, not asset presence
- **near-200 reminder & consecutive-reject pause**｜NOT implemented｜覆盖：none｜约束：threshold from user scheme, no invented numbers; reminder != auto-switch
- **CLI boundary**｜n/a｜覆盖：n/a｜约束：基础上游CLI跟随上游、不改内部；send_cli_once.cjs等属本地业务adapter，需修改时按既有审批，不是永不允许修改
- **159 x 2147 recovery**｜offline prep owned by 规则与运营报告 (manifest ...20261108-2343, sha prefix 243174)｜覆盖：not in this stream｜约束：old "wait for OK" is historical; ops reported new main-window decision; user authorization not verified here; production not executed
## 3 待本机最小检查点
- 【条件式接续，非必做新清单】先由原负责人复用最新已有结果（主窗/抖音链路/运营报告），仅仍影响恢复的缺项才一次窄核；不要求再全量对比v3/ALLIE混版
- 可能缺项示例：prepare_verified是否认 preserve∪isolated（18:16 AssertionError 是否已被后续修补消除）
- 可能缺项示例：采集身份检查 connection_matches=false 原因
- 可能缺项示例：XHS扫码登录程序位置（仅文件名及login/qr引用行）
## 3b 待Codex最小问题
- runner/prepare端到端一致识别isolated名单，补真实execute()测试（非simulate）
- 接近200提醒+连续拒绝暂停：在业务包装层做成可配置（阈值待用户方案）
- 采集ledger_unknown停线的合法续法（不重采未知页）——仅当原负责人确认无既有续法时
- 【非开发需求】XHS受管会话更新路径已暂停/不采用，待用户决定或既有方案接续缺口，不授权接线；v4.3接线属后置，非恢复原CLI前提
## 4 Manifest
- cli_index: /workspace/project-intake/fangyu/cli-provenance-index-20261108.md 34行 sha c7ecb5c170475ecc
- codex_idx: /workspace/project-intake/fangyu/codex-handoff-20261108-1731-index.md 18行 sha 8f720962c136c3c0
- mapping: /workspace/project-intake/fangyu/software-acceptance-mapping.md 29行 sha 5a3b2a4e93382d90
- xhs_route: /workspace/project-intake/fangyu/xhs-existing-recovery-route.md 19行 sha 0a3246892cb3dcb6
- send_handoff: /workspace/dy-deploy/send-handoff-1803.md 353行 sha 2622f2ef0c7a3766
- dy_runtime: /workspace/project-intake/fangyu/douyin-runtime.md 56行 sha 89d305c0aae1745c
- local_check: /workspace/project-intake/fangyu/local-runtime-check.md 174行 sha d32cc87f91cf1043
- v3_accept: /workspace/dy-acceptance/inrun-isolation-v3-acceptance.md 94行 sha f1483f5b5068c86c
- iso_install: /workspace/dy-deploy/isolate-install-1738.md 126行 sha 6087431a388d2cf6
- ds_status: /workspace/notes/deepseek-api-connection-status.json 66行 sha 880da52eb34c5390
- 验证：{'json_ok': True, 'sources_exist': True, 'ref_out_of_range': [], 'secret_pattern_hit': False, 'customer_text_included': False, 'spot_checks': [{'src': 'send_handoff', 'line': 34, 'keyword': 'pythonw.exe', 'matched': True}, {'src': 'dy_runtime', 'line': 19, 'keyword': '恰好1条', 'matched': True}, {'src': 'local_check', 'line': 19, 'keyword': 'resume.py', 'matched': True}]}
## 5 模型调用
- {'backend': 'deepseek', 'model': None, 'count': 0, 'reason': 'deterministic script sufficient; no inference', 'balance_query': 'not performed (no call)', 'usage': None, 'prior_record': '02:13 connectivity sample deepseek-flash 56 tokens, balance CNY 54.00 (from status file)'}
