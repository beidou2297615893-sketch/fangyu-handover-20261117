# 小红书发送前状态（2026-11-08 11:25 UTC+8，只读，未跑平台/未读DB/未读正文）
根 R=C:\Users\rmsama\Documents\ChatGPT\自动获客系统
- 待发批次：work\xhs-send-current-20261029\latest-priority-batch.json（11-06 17:36 UTC+8 准备）：源235→排队214（跳过：标题缺4、账本拦截/重复5、帖子不可用12）；账号ec0b(5f469d…) 180条 runs\latest-priority-20261106-093642-041909\account-1\prepared-batch.json，账号60655f…27fc 34条 account-2\prepared-batch.json；send_attempts=0。
- 正文版本：文本侧指针 当前按池SOP回复指针.json = pool-sop-v3-20261101（XHS 957条均有SOP稿，needs_semantic_review=0，not_a_send_grant=true，production_consumer_verified=false）。214批是否消费 pool-sop-v3 未核实 → 正文版本与认可状态需文本侧对批次文件逐条核。
- 筛选口径：各账号窗口统一回复入口.json → XHS 预算/联系硬筛后按原评论时间7/15/30天分档，预算第二、意愿第三；证据缺失保持未知；发送前实时核共享账本。可见池416（medium411/high4/super_high1），status=paused。
- unknown/旧授权：retirement-verification.json 4类历史特例退休、unknown_halt_preserved=true；retired-historical-scopes.json new_send_authorization_granted=false；legacy grants fail-closed。
- 发送入口：xhs-send-current-20261029 下 prepare_logged_sender.py（默认预览/单次提交+独立回读）、bulk_run.py（11-05）。哪个为现行未核源码。
- 账号/会话：ec0b 在 01:06 只读身份核验即 InboxStop/session_update_requires_review（客户端无会话更新审阅机制），实际身份未证；账号2 60655f 会话未核。
- 回执：历史 runs\huihuijiang-*\events.jsonl 已最小化；独立回读 readback_client.py。
最小剩余障碍：1) 会话更新审阅机制缺失→两个发送账号均无法通过身份核验（产品待修，交云端）；2) 214批正文与 pool-sop-v3/已认可母句(10认可/40待审)对应未核；3) 现行发送入口(prepare_logged_sender vs bulk_run)待定；4) 用户需对具体账号+批次+正文走原生审批。

## 实际加载核对（11:27，只读，未读正文）
- 214批生成器 prepare_latest_priority.py 读 TEXT\recency-priority\daily-priority\current.json → platforms.xiaohongshu.queue（校验SHA与条数），原评论取 delivery-v2\source-input.jsonl + xhs-increment-846\input.jsonl；**不读 pool-sop-v3\replies.jsonl**（其SHA 41f7…仍与指针一致）。发送账号来自 resume-request-20261103.json sender_uid。
- 批次源 classified-queue SHA d3735ed6…（=latest-priority-batch source_queue_sha256），235行：wording_version 全为 referral-wording-v4-20261101；rule_version business-text-20261029-v2；user_approved_variant True 214/空21；approval_scope「已认可母句措辞及本人最新允许住户推荐口气；不是发送授权或账号住户事实独立核验」200/空35。
- 状态冲突：text_status = held_semantic_or_region_review 141、held_no_reply 21、held_duplicate_customer 4、precomputed_pending_sender_checks 仅69；send_authorized/can_send_now 全 False，delivery_state 全 not_attempted。即214批中大量为待语义/地区审的行，不能整批发。
- 时效：按今天算原评论>30天已有10条；未见读取30天新池 v4.3 报告（live_sender_integration_verified=false 与此一致）。
- 是否套用 approved-mother-overrides-20261101.json / mothers-referral-v4 renderer：生成器未引用，待文本侧比对 reply_sha256。

## 口径更正（文本侧对照）
上节 141/21/4/69 为 235 源行统计；仅214实入批：held_semantic_or_region_review 140、held_no_reply 21、precomputed_pending_sender_checks 53；can_send_now/actual_send_authorized 全 false。193行 mother_slot 映射首批50认可项，21行无映射（不等于未获后续认可）。commercial_fit.version 全 v4.3（字段存在不证生成器接新池）。>30天日期数未验。结论不变：214不可整批发。

## 最后成功发送命令溯源（2026-11-08 11:30 UTC+8，只读）
- source L7451–7477/7534–7550/7774–7788：账号=玉米碴（慧慧酱改名，UID尾ec0b，用户确认）；567候选→339入队→逐条提交；第8条unknown隔离；累计457平台回执、19待核实、91暂缓。记录：outputs\小红书回复发送记录\慧慧酱\2026-11-01发送累计核对\评论回复记录.csv。source未给确切命令行/脚本名。
- L8520–8540：CLI专用浏览器已完成慧慧酱登录并保存会话（非游客）；230条批次被11-01一条-9131 unknown的账号级stop拦截，当日发送0。接续问题未修。
- 用户电脑元数据核查：首条Get-ChildItem（列xhs-send-current-20261029与runs、session-fix目录）被用户中断，未重试。故运行目录、确切命令、session_home字段均未取得。
- 推断（未证）：457成功链账号=ec0b，与今日verify_resume006同账号；但发送器与reply-inbox是否同一实现未证。现用账号阻断点是旧unknown账号级stop，不是登录。

## 口径更正（11-08 11:31）
11-01 账号级 unknown 停标仅为历史记录，未经今日证据不称当前实际状态。不请用户裁决清unknown；只能用原工具正常核回执/隔离接续。只读列举被用户中断，不重试、不再请求重做；等用户主动新指令。

## 发送入口窄读（11-08 14:51）
- 实际发送器=bulk_run.py（L231 adapter.submit；L642–648 原 sender.Runner.submit；L496–500 动态加载 standalone_cli）。prepare_logged_sender.py 只准备批文件/打印预览，不提交（L49–59、69–74）。
- 预览：vendor python -B -X utf8 bulk_run.py --sender-uid --batch --mapping --source-manifest --session-home --platform-access-state（L808–829；勿省参落旧默认 L843–848）。--latest-priority 自选三件（L830–842）。
- 提交：加 --execute --run-name <新> --interval 3；无单条参数，遍历全部rows（L184），单条须用仅一行的批文件（prepared-first.json 可由 prepare_logged_sender 生成，适用性未核）。
- 预览 run() 在 L157–161 提前返回，早于目录/锁/适配器（L164–179）；但 main L876–877 先调 daily_time_order.order_rows 未核。预览不读 STOP/账本/历史未决/平台halt（L186–225、563、708–714、347–406），故预览成功≠停线已解。
- 批校验：intended_account_uid（L855–860）、mapping冻结哈希（L874–875）、来源哈希与逐条计划（L503–515）。
- 会话：--session-home；发送/回读客户端走 managed_session.ManagedClient 的更新审核，未用 InboxClient/session_update_requires_review。

## 预览实跑（11-08 14:55 UTC+8）
命令：vendor python -B -X utf8 bulk_run.py --latest-priority --sender-uid 5f469df5000000000101ec0b --session-home ...huihuijiang-browser-login-20261105-01（无--execute）。预览路径经核纯只读（run L157–161 早返回；mapping_reason 前段未逐行）。
结果 exit 1：daily_time_order.py L14 ValueError approved_targets_missing_from_daily_time_priority —— 11-06 旧批有目标不在当日 current.json 队列。无提交/无写入。未重跑。
含义：旧214批已与当日排序队列脱节，原链路要求由原生成器 prepare_latest_priority.py 按当日队列重新产出 batch+mapping+manifest 后再预览。ec0b 专用 platform-access-state 路径未找到（execute 前必须确定，不可落默认蕾姆）。

## held 消费点窄核（11-08 14:59）
全链（prepare_latest_priority→standalone_cli.prepare_batch L136–167→bulk_run mapping_reason L91–114→execute门闩 L180–221→verify_prepared L106–133/make_plan L190–195）无任何读取 text_status/held_* 的排除。133 held_semantic 行不带 L85–88 排除字段 → 会入批。make_plan L194 固定 authorized=True。
ledger_states（standalone_cli L35–66）只读：mode=ro + query_only + SELECT + rollback。
最小修正建议：prepare_latest_priority.py L85–88 条件加 `or row.get('text_status') != 'precomputed_pending_sender_checks'`（白名单，缺字段亦排除），计入跳过原因。测试：无 prepare_latest_priority 测试需新写；回归可用 test_bulk_run.py L100、L162；test_prepare_logged_sender.py 5 例。未改文件、未生成。
