# 方隅抖音本地链路交接（HANDOFF）

**用途**：本文档供其他 AI 或技术同事对已跑通的方隅抖音本地「采集 → 筛选 → 母句匹配 → 草稿 → 发送」链路做软件集成。换一个不了解现场的 AI 也应能按本文独立操作。  
**读者**：其他 AI / 技术同事。  
**时区**：Asia/Shanghai（UTC+8）。  
**首版日期**：2026-11-10。

文档与集成必须按「浏览器当前登录号 + `accounts.json` 映射」工作，通用多账号，不绑定单号。用户可随时换号；采集配置固定不变，不因换号改动。

---

## 1 总览

完整链路：

```
采集 → 筛选 → 母句匹配 → 草稿 → 发送
```

- **采集**：`CI\auto_collect.py` 自动轮换关键词并续跑，产生采集结果。
- **筛选**：常驻分类 worker 自动消化新采集，写入 `CI\classification-handoff-status.json`。该 worker 不向平台发请求。
- **母句匹配与草稿**：衔接在筛选之后、出队/发送之前。本交接未单独列出独立启动命令。
- **出队**：`publish_douyin_send_queue.py` 从有效候选发布发送队列（也可由 `control.py` 在发送启动时调用）。
- **发送**：`打开本地进度.cmd` → `panel.py` → `control.py` → 出队脚本 → `batch_reply_runner`。`auto_continue.py` 负责可跳过暂停的自动续跑。

---

## 2 路径与环境

运行环境：用户 Windows 机。命令中的 `python` / `pythonw` 使用下表中的解释器。

| 简称 | 全路径 |
|------|--------|
| R | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统` |
| CI | `R\work\fangyu-douyin-independent`（采集） |
| C | `R\work\douyin-local-control`（发送控制） |
| Python | `C:\Users\rmsama\miniconda3\python.exe` |

示例账号映射（仅示例，不绑定单号）：

```
小烨Cc. → R\work\douyin-local-20261104-40aaf15b06
```

---

## 3 启动顺序与命令

建议顺序：先保证严格桥接在跑，再按当前任务启动采集或发送。采集与发送不并行（见第 6 节）。同一时间只允许一个操作者、一个 runner。

### 3.1 严格桥接（账号探测依赖它）

在 CI 目录运行：

```
node strict-bridge-server.cjs --serve --config "R\抖音自用采集台\data\bridge.json" --port 19422 --allow-owned-19422
```

- 不带 `--allow-owned-19422` 会失败，报 `original_port_protected`。
- 桥接进程没了会表现为「检测不到账号」。处理：先查并恢复桥接，再请用户刷新页面。不要提取浏览器凭据。

### 3.2 账号识别

采集侧（在 CI 下执行）：

```
python -c "import new_round,json;print(json.dumps(new_round.who()))"
```

发送侧：`C\account_probe.cjs`。

`C\accounts.json` 记录 uid → 任务目录，发送侧按当前登录号解析到对应任务目录。

### 3.3 采集启动

- 方式一：快捷方式 `启动采集自动续跑.cmd`。
- 方式二：在 CI 下 `pythonw auto_collect.py`。

开新一轮：`new_round`（使用计划文件 `plan-round-*`）。若账号存在不可跳过的暂停记录，`new_round` 会拒绝开新轮。

`auto_collect` 只在正常结束态后续跑；异常退出不会自动续跑，需人工确认后重新启动。

### 3.4 采集暂停与恢复

- **暂停**：若存在文件 `CI\auto-collect.stop`，`auto_collect.py` 会退出。发送期间用该文件暂停采集。
- **恢复**：删除 `auto-collect.stop`，再按 3.3 方式重新启动。仅在需要恢复采集时执行。

### 3.5 常驻筛选 worker

调用链（不向平台发请求）：

```
fangyu-text-business-20261029\retention-cleanup-20261106\ensure_text_worker.py
  → douyin-semantic-repair-v5\watch_increment.py
  → build_snapshot.py
```

自动消化新采集，写入 `CI\classification-handoff-status.json`。

### 3.6 出队（发布发送队列）

```
R\work\fangyu-text-business-20261029\recency-priority\publish_douyin_send_queue.py <任务目录> [--preview]
```

入队与排除口径见第 5 节。发送启动时由 `control.py` 调用；也可单独预览。

### 3.7 发送启动

- 入口：`打开本地进度.cmd` → `panel.py`。
- 面板「开始」运行 `python control.py`；若已有 hold，则运行 `python control.py --check-resume`。

`control.py` 顺序：

```
探测账号 → 更新 C\active.json → 跑 publish（出队脚本）→ batch_reply_runner
```

`auto_continue.py`：遇到可跳过暂停会自动续跑；遇到停线类暂停不会续跑。

状态查看：`C\status.json`、任务目录下的 `runner-stdout.log`、`C\auto-continue.log`。

注意：用 `Start-Process` 启动 `control.py` 可能实际不跑，应改为后台 shell 直接运行。

---

## 4 配置位置

| 配置 / 文件 | 位置 |
|------|--------|
| 桥接配置 | `R\抖音自用采集台\data\bridge.json` |
| 采集配置（固定不变，换号不得改动） | `collection-config-fixed.json` |
| 账号映射 | `C\accounts.json`（uid → 任务目录） |
| 采集新轮计划 | `plan-round-*` |
| 发送激活状态 | `C\active.json` |

---

## 5 账本/状态文件口径

### 5.1 `CI\classification-handoff-status.json`

由筛选 worker 写入。其中可见 `pending_candidates`；可见池按 `medium` / `high` / `super_high` 分。

### 5.2 发送队列排除与入队口径

`publish_douyin_send_queue.py` 出队时排除：

- 共享账本预留；
- `reply_receipts.sends`；
- 已存在的 `.json` / `.submitted`；
- `unavailable-targets.json`。

入队要求：必须是 `pending_candidate`，且 `commercial_fit.eligible_candidate`。

### 5.3 runner lease

`runner.cjs` 的 `acquireLease` 会写入：

- `runner-lease-connection-*.json`
- `runner-lease-database-*.json`

异常退出不会自动清理这些 lease。陈旧 lease 备份目录：`R\work\_backup\stale-lease-日期\`。处理步骤见 6.1，不能直接删除。

### 5.4 发送运行状态

- `C\status.json`
- 任务目录 `runner-stdout.log`
- `C\auto-continue.log`

---

## 6 运行规则（停线/跳过/换号/采发不并行）

- **未知提交（unknown）**：不重试、不重发；先经 `control.py` 核验。
- **验证码 / 身份异常 / 限流**：停线，不换号，等待用户手动通过验证码后再继续。
- **采集与发送不并行**：发送期间用 `auto-collect.stop` 暂停采集。
- **换号提醒**：单号接近 200 条时提醒换号。用当前浏览器已登录的号，不在停线时擅自换号。
- **安全暂停**：连续十几条跳过或拒绝时安全暂停。
- **问题条目**：跳过且不再发送。
- **唯一操作者**：同一时间只允许一个操作者、一个 runner；启动或修改本机任务前须确认唯一操作者，不能并发重复 runner。
- **不提取浏览器凭据**。
- **续跑限制**：`auto_collect` 只在正常结束态后续跑；异常退出不会自动续跑。
- **不可跳过暂停记录**：若账号存在不可跳过的暂停记录，`new_round` 会拒绝开新轮。
- **采集配置**：固定不变，不因换号改动 `collection-config-fixed.json`。
- **业务口径**：门店辐射范围内的城市都有效，不存在「外地求租」这一否决口径。只要评论落在门店辐射范围内即可发送。

### 6.1 陈旧 lease 处理步骤

必须按此顺序，不能直接删除：

1. 确认 runner 进程已死；
2. 确认 unknown = 0；
3. 确认最后状态已提交；
4. 把 lease 文件移到 `R\work\_backup\stale-lease-日期\`；
5. 然后再 `new_round`。

---

## 7 已知坑与处理

| 坑 | 处理 |
|----|------|
| 桥接掉线，表现为「检测不到账号」 | 先查并恢复桥接，再请用户刷新；不要提取浏览器凭据 |
| 用 `Start-Process` 启动 `control.py` 可能实际不跑 | 改为后台 shell 直接运行 |
| 陈旧 lease 阻塞重启 | 按 6.1 步骤迁移，不要直接删除 |
| `auto_collect` 异常退出不会自动续跑 | 人工确认后重新启动 |
| 错误码 `3220` | 平台拒绝 |
| 点「启动／继续」看起来没反应 | 常见原因是遇到旧的「验证未结束」（`3002123`）记录后立即停线，既不跳过也不继续。员工会以为按钮坏了 |
| 错误码 `3002123`（当日实测） | 旧回执里出现时，不能不再核对就整批停线。应只读检查（绝不重发）：已发出去则记为已发送，确认没发出去则保留并跳过，然后继续发后面的。仅当当场仍检测到验证/身份问题，或连续十几条跳过/失败，才停线提醒。页面看起来正常、甚至手动能评论，自动提交仍可能被拦，同样按跳过一条后继续处理 |
| 同一视频连排导致反复被拦 | 当日同一视频下连续多条自动提交失败；队列中该视频仍有大量待发。已确认的同视频交错规则等本轮发送结束后再生效，由技术集成，现场不改本批队列 |
| 抖音页面没响应 / 桥接无客户端 | 清楚提示刷新已登录的抖音页面；刷新后再点一次「启动／继续」必须能越过旧记录继续发。不要提取浏览器凭据 |
| 打开进度窗口被系统拦截 | 可能弹出 Windows 安全警告，需用户点「运行」。软件安装或启动方式应避免员工每次遇到这个拦截 |

---

## 8 待 Codex 集成项

现场不要临时打补丁到 `auto_collect` 等在运行程序。待集成项：

- **「启动／继续」一键恢复（用户 11-10 13:32 强调，集成时不能再出现今天这些问题）**：不要靠助手当启动器。员工自己点一下即可继续发送。所有已经遇到过、也知道怎么修的卡点，都收进这一个本地按钮；员工不必知道问题是什么，也不必看错误码。至少包括：
  - 旧的 `3002123`／「验证未结束」记录：只读核对、不重发，跳过或记已发送后继续，不能让按钮看起来没反应；
  - 页面正常或手动能评、自动提交仍被拦：跳过该条继续发，单条或少量失败不停整批；连续十几条跳过/失败才安全暂停；
  - 页面没响应：明确提示刷新已登录页面，刷新后点一次即可继续；
  - 陈旧 lease、桥接掉线看起来像没登录、打开进度窗口被系统拦截等已知卡点，也收进同一按钮或软件自动处理。
- 边采边筛、增量进入有效池；已回复自动出池。
- 陈旧 lease 的自动安全恢复（并入上一键按钮）。
- 同一视频分散发送（已确认规则：同视频连续最多 3 条、每轮每视频最多 5 条；等本轮发送结束后再生效，不改当前批次）。
- 多账号通用化。

---

## 9 更新记录

- **2026-11-10**：首版。根据已跑通的本地采集-筛选-出队-发送流程整理，供软件集成使用。之后每次流程或规则有变化都应更新本文件。
- **2026-11-10 13:32**：按用户要求补记「启动／继续」一键恢复，以及当日发送中出现、集成时不能再出现的卡点。本轮发送现场程序不改，结束后交技术集成。
