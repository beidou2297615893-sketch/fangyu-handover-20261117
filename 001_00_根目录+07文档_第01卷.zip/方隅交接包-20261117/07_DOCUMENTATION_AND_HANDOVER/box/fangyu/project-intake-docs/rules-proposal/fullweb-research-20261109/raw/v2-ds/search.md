# 搜索策略（全网研究提案 · 带轮换算法版）

- 生成时间：2026-11-09 Asia/Shanghai
- 更新：新增「可直接执行的轮换算法」（伪代码 + 参数表 + 状态字段）、扩圈/冷却/淘汰/补充规则、词池可持续性估算、监控指标
- 性质：**只出方案**，不改生产采集配置；落地需用户确认后由链路负责人并入
- 原则对齐用户要求：采集/筛选以**地域周边为主**；搜索词要能大量轮换、尽量搜不完

本文只管**通用层 × 地名**的组合方法与轮换机制。店级地名词（具体小区、商圈、地铁站名清单）另文件维护（`keywords-proposal-20261109-batch2-clean.csv` 等），本文不重复、不编造。

---

## 1. 总原则

- **地域优先**：搜索词以门店周边圈层由近到远展开（近圈：步行/骑行可达；中圈：3–5公里；外圈：同城相邻板块）。先保证近圈词被系统消耗，再向外扩。
- **意图词次之**：地名打底，意图词只做叠加，不单独占用搜索配额。
- **可轮换**：词池是库存，不是清单。任何一天只启用一部分词，其余进冷却。
- **不改预算门槛、不承诺改生产**：本文是方案级建议，落地以现行规则为准。

---

## 2. 词池分层

| 层 | 内容 | 示例（占位） |
|---|---|---|
| A 锚点地名 | 店周边圈层地名，由近到远 | 联航路、虹桥、XX路地铁站周边 |
| B 意图/需求 | 租房动作与决策意图 | 租房、求租、直租、转租、合租、整租、一室户、押一付一 |
| C 内容类型 | 内容形态限定词 | 找房vlog、避坑、对比、某站租房、看房记录、吐槽中介 |
| D 时段轮换 | 同一批词按发布时间窗分批启用 | 上午批 / 晚间批 / 周末批 |

### 2.1 词组构造（本版新增，可执行定义）

**核心公式：**

```
词 = 店级地名词(L) ∪ 组合词(锚点A × 通用意图B) ∪ 可选(A × B × C)
```

其中：

- **L = 店级地名词**：来自 `keywords-proposal-20261109-batch2-clean.csv`（例：上海联航路云涛公寓 L=301 个）。
- **A = 锚点地名**：分「近圈 / 中圈 / 外圈」三档（见 §2.2）。
- **B = 通用意图词**：从《通用租房意图词库.csv》中取 `用途` 字段含 `"搜索"` 的词：
  - **强意图 276 个**（如：求租、直租、转租、合租、整租、一室户、押一付一、个人房源…）
  - **中意图 402 个**（如：找房、看房、租房子、租房攻略…）
- **C = 内容类型词**（可选层）：只在近圈 A 上用；外圈不用 C。

**组合规模（未去无效搭配）：**

- 只配强意图池：`|L| + |A| × 276`
- 加中意图池：`|L| + |A| × (276 + 402) = |L| + |A| × 678`

**分组（rotation_group）：**

- 每 **20 词一组**，组内按以下优先级排序：
  1. 圈层：**近圈 → 中圈 → 外圈**
  2. 意图强度：**强 → 中**
- `rotation_group` 是轮换的最小调度单元；同组词一般同批启用，避免跨圈混用。

### 2.2 圈层与上海门店的锚点A映射（本版新增）

| 圈层 | 定义 | 上海门店示例（锚点A） |
|---|---|---|
| 近圈 | 步行/骑行可达的地名（官网明确） | 联航路→「联航路云涛」；芦恒路→「浦江」 |
| 中圈 | 3–5km 内地名（官网或地址可推） | 按店级名词中「区域级」名称 |
| 外圈 / 通勤目的地 | 同城相邻板块、通勤目的地站 | 地铁站表「外圈」列 |
| 弱-待核 | 站名存在但覆盖不确定 | 虹桥火车站、国家会展中心、季乐路(未开通) |

**上海店专用词源：** 可从《上海地铁站租房词.csv》取「站名 × 8 模板」组合：
- 模板示例（8 条）：`{站} 租房`、`{站} 转租`、`{站} 求租`、`{站} 合租`、`{站} 个人房源`、`{站} 一室户`、`{站} 租房避坑`、`{站} 找房`。
- 站名按圈层分组，**弱-待核**站名一律先入 `probation`，观察产出后再升级。
- **非上海门店不适用此表**（见 §9）。

### 2.3 扩量公式

- `A × B`：基础组合，覆盖「地名+需求」，是日消耗主力。
- `A × B × C`：扩量组合，用于把长尾词做深，只在近圈 A 上用，避免外圈词过散。

**示例（占位，非核实小区）**

- A×B：`联航路 租房`、`联航路 求租`、`联航路 直租`、`虹桥 合租`、`虹桥 转租`
- A×B×C：`联航路 租房 避坑`、`联航路 找房vlog`、`虹桥 租房 对比`、`虹桥 某站租房`

规则：C 层词优先配近圈 A；外圈 A 只用 A×B，不铺 C。

---

## 3. 轮换与冷却

- **每日活跃上限思路**：按店设「日活跃搜索词数」上限（D，默认 40，可调 30/60），确保单店词池能撑满一个轮换周期，不把全部词池一天打光。
- **冷却**：词用尽后进冷却，冷却天数按词池规模与日上限反推（词池 ÷ 日上限 ≈ 周期天数），冷却期内不再启用。
- **降权**：连续失败或零评论的词标记降权，降低启用优先级；降权词不进当日主批次，仅作补位。
- **分批**：结合 D 层，把 A×B、A×B×C 分到不同时段批次，避免同一时间集中打同一圈层。

### 3.1 词状态字段（本版新增，落地必填）

每个词一条状态记录，持久化到存储（建议 SQLite / Postgres 表 `search_word_state`，或 JSON 快照）：

| 字段 | 类型 | 含义 | 初值 |
|---|---|---|---|
| `word` | text | 搜索词原文 | — |
| `store` | text | 门店ID（如 `sh-lianhangyun`） | — |
| `rotation_group` | text | 分组ID（如 `g_sh-lianhangyun_03`） | — |
| `ring` | enum | `near` / `mid` / `far` / `weak` | 按 A 圈层 |
| `intent` | enum | `strong` / `mid` | 按 B 强度 |
| `last_used_at` | datetime | 最近一次使用时间 | `null` |
| `uses` | int | 累计使用次数 | `0` |
| `yield_comments` | int | 最近一次采集到 30 天内评论数 | `0` |
| `yield_mid_high` | int | 该词带来的中高意向评论数（累计） | `0` |
| `zero_streak` | int | 连续「零产出」次数（yield_comments=0 时 +1，否则归零） | `0` |
| `status` | enum | `active` / `cooling` / `retired` / `probation` | `active` |
| `cooldown_until` | datetime | 冷却结束时间（status=cooling 时有意义） | `null` |
| `created_from` | enum | `L` / `A×B` / `A×B×C` / `new_mined` / `seasonal` / `synonym` | — |
| `last_eval_at` | datetime | 上次评估时间（用于 retired 抽检） | `null` |

### 3.2 冷却规则（本版新增，可调）

| 情形 | 冷却时长 | 依据 |
|---|---|---|
| 默认（`yield_mid_high = 0`） | **14 天** | 参数 `COOLDOWN_DEFAULT_DAYS` |
| 产出好（`yield_mid_high ≥ 1`） | **7 天**（减半） | 参数 `COOLDOWN_GOOD_DAYS` |

冷却结束后：`status` 由 `cooling` 自动回到 `active`，`cooldown_until = null`。

### 3.3 圈层扩圈规则（本版新增）

触发条件（任一满足即扩）：

1. 某店**当日 active 近圈词组全部用完**（即近圈组中已无可调度词）；
2. 近**3 组**（`rotation_group` 维度）`yield_mid_high` 均值 = 0。

动作：

- **近圈 → 中圈**：启用中圈组；
- **中圈 → 外圈 / 通勤目的地**：中圈再无产出时，启用外圈/通勤目的地词（上海从地铁站表「外圈」取；非上海从本地站点表取，见 §9）。

回落：当日已扩到中/外圈后，次日按规则重新从近圈开始，不固化。

---

## 4. 高密度内容类型与评论区时机

高密度内容类型：找房vlog、租房避坑、区域对比、吐槽中介/求直租、应届生租房。

- **抖音**：视频发布后 1–3 小时评论区活跃度高，优先在此窗口采集。
- **小红书**：约上午 10 点、晚 8 点为互动高峰（第三方经验总结，**非官方数据**，以实际观测为准）。

> 本版补充：日调度时段可对齐此活跃窗口（如 09:00–11:00、19:30–21:30 各跑一次），词池轮换按小时切片，同词每天最多 1 次（§7）。

---

## 5. 抖音 vs 小红书差异

- **搜索语法**：抖音偏「关键词直搜+话题标签」；小红书偏「关键词+笔记标题/标签」组合，长词更吃标题匹配。
- **同城**：抖音同城入口强，适合按地域圈层采集；小红书地域靠笔记定位与标签，需靠地名词补。
- **标签**：抖音话题标签参与排序；小红书标签影响推荐与搜索召回。
- **最新排序**：两端均可用「最新」排序抓新发内容，抖音时效性更强，小红书需配合发布时间筛选。

---

## 6. 与现行规则衔接

- 评论采集后 **30 天内只保留有效评论**，过期清理。
- 扫描页数/条数需**可显示速率**（页/分钟、条/分钟），便于判断词是否值得继续消耗。
- **不改预算门槛**，本文不涉及预算调整。

---

## 7. 轮换算法（本版新增 · 可直接执行）

以下算法与 §3.1 状态字段、§3.2 冷却参数配套；落地由链路负责人实现，**本文不改生产配置**。

### 7.1 参数表

| 参数 | 符号 | 默认值 | 可调范围 | 说明 |
|---|---|---|---|---|
| 每日每店词上限 | `D` | **40** | 30 / 60 | 每店每日最多调度的词条数 |
| 单词每日最大使用 | `PER_DAY_CAP` | **1** | 1 | 同词同日只用 1 次 |
| 轮换组大小 | `GROUP_SIZE` | **20** | — | 每 20 词一组 |
| 默认冷却天数 | `COOLDOWN_DEFAULT_DAYS` | **14** | 7–21 | 用过的词默认冷却 |
| 高产冷却天数 | `COOLDOWN_GOOD_DAYS` | **7** | 3–14 | `yield_mid_high ≥ 1` 时减半 |
| 零淘汰阈值 | `ZERO_STREAK_RETIRE` | **3** | 3–5 | 连续零产出次数 |
| Retired 抽检比例 | `RETIRED_SAMPLE_PCT` | **10%** | 5–20% | 每 `RETIRED_SAMPLE_DAYS` 抽检 |
| Retired 抽检周期 | `RETIRED_SAMPLE_DAYS` | **30** | 30 | 天 |
| 近圈扩圈触发 | `NEAR_MAIN_ZERO_GROUPS` | **3** | 2–5 | 连续 3 组 yield_mid_high=0 → 扩中圈 |
| 中圈扩圈触发 | `MID_MAIN_ZERO_GROUPS` | **3** | 2–5 | 同上，中 → 外 |
| 每周同义扩写 | `SYNONYM_WEEKLY` | **1** | 每周一次 | DeepSeek 生成近义扩写 |
| 中高意向门槛 | `MID_HIGH_GOOD` | **1** | — | yield_mid_high ≥ 1 视为「产出好」 |

### 7.2 状态机（status 流转）

```
probation ──有产出──> active
probation ──zero_streak ≥ ZERO_STREAK_RETIRE──> retired
active ──用完──> cooling（cooldown_until = now + COOLDOWN_*）
cooling ──到期──> active（回池）
active/cooling ──zero_streak ≥ ZERO_STREAK_RETIRE──> retired
retired ──抽检命中──> probation（试一次）
```

### 7.3 伪代码：每日调度

```python
# 每日每店调度一个批次，调度上限 = D，同词同日最多 1 次

def daily_dispatch(store, today):
    # 1) 载入本店全部词状态
    words = load_word_state(store)  # status,ring,intent,rotation_group,...

    # 2) 候选池 = active ∩ cooldown_until <= today ∩ last_used_at.date() != today
    cand = [w for w in words
            if w.status == "active"
            and (w.cooldown_until is None or w.cooldown_until <= today)
            and (w.last_used_at is None or w.last_used_at.date() != today)]

    # 3) 分层排序：近圈→中圈→外圈→弱核；强→中
    RING_ORDER = {"near": 0, "mid": 1, "far": 2, "weak": 3}
    INTENT_ORDER = {"strong": 0, "mid": 1}
    cand.sort(key=lambda w: (RING_ORDER[w.ring],
                             INTENT_ORDER[w.intent],
                             w.rotation_group,
                             w.last_used_at or datetime.min))

    # 4) 扩圈门控（§3.3）
    cand = apply_ring_gate(store, today, cand)

    # 5) 取前 D 个，执行
    batch = cand[:D]
    results = []
    for w in batch:
        r = run_search_and_scrape(w)          # 调用采集链路
        update_word_state(w, r)               # 见 7.4
        results.append((w, r))

    # 6) Retired 抽检（§7.6）
    sample_retired(store, today)

    # 7) 每周同义扩写（§7.7）
    if is_week_start(today):
        generate_synonyms(store)

    return results


def apply_ring_gate(store, today, cand):
    """扩圈门控：近圈耗尽或近3组无产出 → 放开中圈；中圈同理→外圈"""
    near = [w for w in cand if w.ring == "near"]
    mid  = [w for w in cand if w.ring == "mid"]
    far  = [w for w in cand if w.ring in ("far", "weak")]

    # 已扩圈标记（当日）
    if near:
        return near + mid[:0] + far[:0]            # 先用近圈
    # 近圈当日无可用 → 判是否放开中圈
    if mid:
        recent_groups = recent_n_groups(store, "near", n=NEAR_MAIN_ZERO_GROUPS)
        if all(g.yield_mid_high_sum == 0 for g in recent_groups):
            return mid + far[:0]
        return []  # 近圈还有但当日耗尽，仍只跑近圈（避免越层）
    if far:
        recent_groups = recent_n_groups(store, "mid", n=MID_MAIN_ZERO_GROUPS)
        if all(g.yield_mid_high_sum == 0 for g in recent_groups):
            return far
        return []
    return []
```

### 7.4 伪代码：状态更新（含冷却/淘汰）

```python
def update_word_state(w, r):
    # r.yield_comments >= 0，r.yield_mid_high >= 0
    w.uses += 1
    w.last_used_at = now()
    w.yield_comments = r.yield_comments       # 采到 30 天内评论数
    w.yield_mid_high += r.yield_mid_high      # 累计中高意向
    if r.yield_comments == 0:
        w.zero_streak += 1
    else:
        w.zero_streak = 0

    # 冷却
    if r.yield_mid_high >= MID_HIGH_GOOD:
        w.cooldown_until = now() + days(COOLDOWN_GOOD_DAYS)
    else:
        w.cooldown_until = now() + days(COOLDOWN_DEFAULT_DAYS)
    w.status = "cooling"

    # 淘汰
    if w.zero_streak >= ZERO_STREAK_RETIRE:
        w.status = "retired"
        w.cooldown_until = None
    save(w)
```

### 7.5 伪代码：新词补充（5 个来源）

```python
def supplement_words(store, today):
    # ① 本店中高意向评论里出现的新地名/新说法（脚本抽取 + 人工确认后入库）
    mined = mine_from_comments(store, window_days=30)   # 返回候选词
    for kw in mined:
        if human_confirmed(kw):
            upsert_word(store, kw, status="probation", created_from="new_mined")

    # ② 词库未用的中意图词（兜底，按近期零产出速度投放）
    unused = load_unused_mid_intent(store)
    upsert_word_batch(store, unused, status="probation", created_from="A×B")

    # ③ 地铁站表（仅上海门店）
    if store.city == "上海":
        upsert_word_batch(store, load_metro_stations("近圈"), status="probation",
                          created_from="A×B")
        upsert_word_batch(store, load_metro_stations("弱-待核"), status="probation",
                          created_from="A×B")

    # ④ DeepSeek 每周一次按已验证高产词生成近义扩写
    if is_week_start(today):
        for seed in high_yield_words(store, n=20):
            for syn in deepseek_synonym_expand(seed):
                upsert_word(store, syn, status="probation",
                            created_from="synonym")

    # ⑤ 节假日 / 毕业季 / 年后返工季节词
    for kw in seasonal_words(today):
        upsert_word(store, kw, status="probation", created_from="seasonal")
```

新词规则：**一律先 `probation`**，产出达标（`zero_streak = 0` 且 `yield_mid_high ≥ 1` 累计）后自动升 `active`；连续 3 次零产出 → `retired`。

### 7.6 伪代码：Retired 抽检

```python
def sample_retired(store, today):
    retired = [w for w in load_word_state(store) if w.status == "retired"]
    if not retired:
        return
    # 每 RETIRED_SAMPLE_DAYS 抽 10% 回到 probation 试一次
    if today - last_sample_date(store) < days(RETIRED_SAMPLE_DAYS):
        return
    k = max(1, int(len(retired) * RETIRED_SAMPLE_PCT))
    picked = random.sample(retired, min(k, len(retired)))
    for w in picked:
        w.status = "probation"
        w.zero_streak = 0
        save(w)
    mark_sample_date(store, today)
```

### 7.7 伪代码：每周 DeepSeek 近义扩写（来源④）

```python
def generate_synonyms(store):
    seeds = top_n(store, by="yield_mid_high", n=20)  # 已验证高产词
    for s in seeds:
        prompt = f"参考这位用户搜索词：{s}。生成 5 条本门店周边租房场景的近义搜索词，" \
                 f"保持地域锚点与租房意图不变，只做说法替换。每行一条，不要解释。"
        for kw in parse_lines(deepseek_chat(prompt)):
            upsert_word(store, kw, status="probation", created_from="synonym")
```

### 7.8 单词 / 单店 / 单日约束

- 单词每日最多 1 次（`PER_DAY_CAP=1`）：由 `last_used_at.date() != today` 拦截。
- 单店每日最多 `D=40` 词；`D` 可下调为 30 或上调为 60。
- **同视频回复纪律不变**：同一视频评论区只回复一次，由采集侧独立保证，不受本节影响。

---

## 8. 每日用量与「不会用完」估算（本版新增 · 按表核算）

- 每店日上限 **D = 40 词**（可调 30/60）；单词每天最多用 1 次。
- 表中「只配强意图池」= `|L| + |A| × 276`；「加中意图池」= `|L| + |A| × 678`。
- **组合有效率**：按 **50%** 折算（弱核、无效搭配、孤儿词等），即实际可调度词 ≈ 池 × 0.5。

### 8.1 三种指标计算

1. **首次轮完天数（未折算）** = `池 / D`
2. **考虑组合有效率（50%）后的天数** = `池 × 0.5 / D`
3. **可持续条件**：`池 × 有效率 ÷ D ≥ COOLDOWN_DEFAULT_DAYS(14天)` → **永不枯竭**。等价于 `池 × 0.5 / 40 ≥ 14` → `池 ≥ 1120`。

### 8.2 门店核算表

| 门店 | L | A | D | 只强池 | 日数(未折算) | 加中池 | 日数(未折算) | 只强池×0.5 天数 | 加中池×0.5 天数 | 只强池可持续？ | 加中池可持续？ |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 上海联航路云涛公寓 | 301 | 6 | 40 | 1957 | 48.9 | 4369 | 109.2 | 24.5 | 54.6 | ✅ | ✅ |
| 上海古北方隅服务公寓 | 321 | 3 | 40 | 1149 | 28.7 | 2355 | 58.9 | 14.4 | 29.4 | ⚠️ 刚过线 | ✅ |
| 上海会展方隅国际公寓 | 326 | 5 | 40 | 1706 | 42.6 | 3716 | 92.9 | 21.3 | 46.5 | ✅ | ✅ |
| 上海浦江方隅服务公寓 | 283 | 5 | 40 | 1663 | 41.6 | 3673 | 91.8 | 20.8 | 45.9 | ✅ | ✅ |
| 上海中骏广场方隅服务公寓 | 136 | 5 | 40 | 1516 | 37.9 | 3526 | 88.2 | 19.0 | 44.1 | ✅ | ✅ |
| FUNLIVE·上海天璟方隅服务公寓 | 294 | 5 | 40 | 1674 | 41.9 | 3684 | 92.1 | 20.9 | 46.1 | ✅ | ✅ |
| 上海龙柏方隅服务公寓 | 294 | 3 | 40 | 1122 | 28.1 | 2328 | 58.2 | 14.0 | 29.1 | ⚠️ 临界 | ✅ |
| 北京天璟方隅公寓 | 188 | 2 | 40 | 740 | 18.5 | 1544 | 38.6 | 9.3 | 19.3 | ❌ | ⚠️ 刚过线 |
| 北京未来云城方隅公寓 | 306 | 8 | 40 | 2514 | 62.9 | 5730 | 143.2 | 31.4 | 71.6 | ✅ | ✅ |
| 北京沙河方隅服务公寓 | 286 | 3 | 40 | 1114 | 27.9 | 2320 | 58.0 | 13.9 | 29.0 | ⚠️ 临界 | ✅ |
| 成都高新西方隅服务公寓 | 266 | 3 | 40 | 1094 | 27.4 | 2300 | 57.5 | 13.7 | 28.8 | ⚠️ 临界 | ✅ |
| 杭州东站方隅公寓 | 53 | 3 | 40 | 881 | 22.0 | 2087 | 52.2 | 11.0 | 26.1 | ❌ | ✅ |
| 杭州余杭方隅公寓 | 172 | 4 | 40 | 1276 | 31.9 | 2884 | 72.1 | 16.0 | 36.1 | ✅ | ✅ |
| 杭州青山湖方隅服务公寓 | 70 | 4 | 40 | 1174 | 29.4 | 2782 | 69.5 | 14.7 | 34.8 | ⚠️ 刚过线 | ✅ |
| 福州白湖亭方隅服务公寓 | 104 | 3 | 40 | 932 | 23.3 | 2138 | 53.5 | 11.7 | 26.7 | ❌ | ✅ |

> 说明：「只强池可持续」列以 `池×0.5/40 ≥ 14` 判定；「⚠️ 临界 / 刚过线」表示 14–16 天，仍可能因离散性出现枯竭，建议加中意图池或降 D=30。

### 8.3 结论要点

- **只用强意图池、50% 折算后会低于 14 天（即不可持续）的门店**：
  - **北京天璟**（9.3 天）——严重不足；
  - **杭州东站**（11.0 天）——严重不足；
  - **福州白湖亭**（11.7 天）——不足；
  - **北京沙河**（13.9 天）、**成都高新西**（13.7 天）——临界，易枯竭。
- **临界但可接受的门店**（14.0–14.7 天）：上海古北、上海龙柏、杭州青山湖——建议**降 D=30** 或**补中意图池**消除枯竭风险。
- **加中意图池后**：仅**北京天璟**（19.3 天）仍在较低区间，其余全部 ≥ 26 天，整体可持续。
- **可持续条件总结**：`池 × 0.5 ÷ D ≥ 14` 即永不枯竭。**推荐全线门店至少开启「强 + 中」双意图池**；D 默认 40，词池薄（L 少且 A 少）的门店（北京天璟、杭州东站、福州白湖亭）建议 D=30。

---

## 9. 非上海门店词源说明（本版新增）

**上海地铁站租房词.csv 仅限上海门店使用。** 非上海门店**不得引用上海地铁站表**，需另做本地站点表：

| 城市 | 门店 | 要求 |
|---|---|---|
| 北京 | 天璟方隅、未来云城方隅、沙河方隅 | 需本地站点表（北京地铁 × 8 模板） |
| 杭州 | 东站方隅、余杭方隅、青山湖方隅 | 需本地站点表（杭州地铁 × 8 模板） |
| 成都 | 高新西方隅 | 需本地站点表（成都地铁 × 8 模板） |
| 福州 | 白湖亭方隅 | 需本地站点表（福州地铁 × 8 模板） |

- 本地站点表格式对齐上海表：列入「站名 / 圈层(近/中/外/弱-待核) / 8 模板」。
- 圈层定义与上海一致（近=步行骑行、中=3–5km、外=相邻板块或通勤目的地）。
- **在本地站点表建立前**，这些门店的 A 层暂只用店级词 L 中已明确的区域名，`ring` 默认标 `mid` 或 `weak`，进 `probation`。

**店级词数来源确认**：§8.2 中「L」列为 `keywords-proposal-20261109-batch2-clean.csv` 各店 L 行数，与现状文件一致。

---

## 10. 监控指标与异常告警（本版新增）

### 10.1 指标

| 指标 | 粒度 | 计算 | 用途 |
|---|---|---|---|
| 产出率 | 每词 / 每组 | `yield_mid_high / uses` | 判断是否降权 / 冷却缩短 |
| 每小时扫描评论数 | 每店 | `scanned_comments / hours` | 判断节奏是否需要调时段 |
| 存下比例 | 每店 | `kept / scanned`（**当前约 25%**） | 判断过滤阈值是否合理 |
| 中高意向率 | 每店 / 每词 | `mid_high / kept` | 衡量词质，反哺 §7.5 补充来源④ |

### 10.2 异常告警（建议阈值）

- **连续 ≥ 10 次零产出**（同一词或同一 rotation_group）：提醒人工复核（理由：可能是词已死、视频侧选题变化、采集侧故障）。
- **连续 ≥ 10 次跳过**（调度侧主动未纳入主批次）：提醒人工复核（理由：状态门控可能卡住词池）。

> 上述两项数值以参数 `ALERT_ZERO_STREAK = 10`、`ALERT_SKIP_STREAK = 10` 落地，可调。

---

## 11. 落地边界

- 本文**不修改生产采集配置 / 词库 / 程序**；伪代码为参考实现，落地由**链路负责人**评估后并入。
- 「上海地铁站租房词.csv」「通用租房意图词库.csv」为输入源；如需扩充字段（圈层、模板）需协调数据侧。
- 强意图 276 / 中意图 402 的库统计口径以上述 CSV 的 `用途=搜索` 为准，本文不复核原始行。
- 所有"估算"（§8）基于当前 L、A 快照，**词池变动需重算**。

---

## 12. 来源

- 拓客吧·抖音租房截流：https://www.tuokeba.com/jingyan/583.html
- 人人都是产品经理·小红书租房引流拆解：https://www.woshipm.com/share/6244172.html
- 安居客问答主题分析：http://www.thearxiv.net/2025/118/dd0c20251180175.html
- 上海安居客·地铁口租房挂牌：https://sh.zu.anjuke.com/rmss/chuzu-394/
- 上海58·地铁沿线租房：https://sh.58.com/chuzu/sub/
- 帮帮忙么·抖音租房发布时间经验：https://www.bangmangma.com/find/258600.html
- 金层SEO·关键词组合思路：https://jinceng.com/11076.html
- 小红书房源搜索组合经验：https://blog.huochengrm.cn/zmt/30480.html

**内部数据源**

- `keywords-proposal-20261109-batch2-clean.csv`（店级词 L）
- `通用租房意图词库.csv`（用途=搜索：强意图 276、中意图 402）
- `上海地铁站租房词.csv`（仅上海门店）

> 性质：规则提案。未改在用采集配置/词库/程序。店级地名词见 keywords-expansion / keywords-intent，不在本文重复生成。轮换算法伪代码为参考实现，落地需用户确认后由链路负责人并入。