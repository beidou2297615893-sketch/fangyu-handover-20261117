# 小红书既有恢复路线（仅box资料）

## 已有正规路线与证据
- **历史有正常会话更新修复，不能泛称整套机制不存在。** source.md L6644记采集器未沿用上游正常更新处理；L6698报告独立入口保存正常更新，账号变化、外部替换、保存失败仍停止；L6712–6724记acw_tc白名单误拒已修、17项测试及真实身份核验/搜索通过，但评论读取仍461。此为历史报告，不证明今天同因或已经接通。
- 候选资产 `work/xhs-new-task-session-fix-20261029/managed_session.py` 出现在现存副本依赖缺口清单（import/xhs-mech-20261108/MANIFEST.md L3–6）；**与当前异常的具体关联只是推测，未静态核实**，不能把文件名当已接入证明。source.md L6959只记发送器正在补齐更新处理，未证完成。本轮未查源码；接线核对交总指挥已在跑的原云端，不另起任务。
- 较新采集候选：`work/xhs-resume-20261103/verify_resume006.py`→verified证明→`resume006.py`；证明status/uid/session_home须匹配，实际会话路径与默认路径不同（xhs-runtime.md L9–19）。最近verify返回session_update_requires_review，证明未更新；HTTP200/exit0不是身份成功，返回uid/session_home来自输入（L24–30）。旧client单文件无确认参数/写回入口，不等于全工程无配套机制。
- 发送已有 `work/xhs-send-current-20261029/prepare_logged_sender.py`默认预览、`managed_send_client.make_client`接原Sender/Runner、`readback_client.py`独立回读（takeover-readonly.md L103–111）；bulk_run.py并存，现行入口未定（xhs-send-readiness.md L7）。未找到当前异常专用session review/approval命令或UI契约，不编造参数。

## 账号、成功与版本替代
- 慧慧酱=改名玉米碴有历史用户确认（source.md L7455–7465）；旧批曾457条平台受理，非公开可见证明（L7774–7788）。后续专用浏览器曾登录保存成功，但230批仍被旧unknown拦截（L8520–8540）；再后采集身份请求失败（L8573–8589）。旧成功不能证明当前可发。
- 另一绑定账号34条与慧慧酱180条仅通过离线预览；旧正文依赖的4类特例授权已退休，unknown仍保留（source.md L8653–8691；initial-audit.md L84–90）。账号2会话/实际身份未核（xhs-send-readiness.md L3、8）；该报告L10把问题扩到两账号，超过L8证据，不沿用。resume006晚于旧resume不等于正式废弃证明，尚缺明确替代契约。

## 最小恢复建议、待修范围及禁止动作
1. 后续由既有云端核对历史受管更新修复是否接入当前verify/发送消费者、版本是否替换及合成测试；优先复用，不先重造审阅系统。若确需修改，范围先限接线、受管更新兼容及错误阶段诊断；保留账号变化、外部替换、保存失败、unknown保护。具体补丁尚无足够证据。
2. **会话恢复、文案消费接线是两道独立闸。** 最新平台报告记prepare_latest_priority.py仍读旧daily-priority235行，未接v4.3/30天新池与认可覆盖，214不可整批发（xhs-send-readiness.md L12–17）；本轮仅复用，未独立核代码。版本替代由运营定；身份恢复后也须核正文、账号批次及当前具体发送授权，不能直接发旧稿。
3. 本轮不做本机/网络探针，不重跑verify/业务，不读凭据/会话，不改Cookie/stop/unknown，不补写verified，不重放未知，不借旧授权发送，不安装或另开开发/云端。

检索范围与不足：先source-index.md定位小红书L6497–8697，再关键词命中窄读source.md；复用xhs-runtime.md、takeover-readonly.md、initial-audit.md，补读现有发送报告及MANIFEST。检索词：session_update、session review/session_review、review、approval/approve、verify、会话、acw_tc、managed_session、账号2/第二个账号、慧慧/玉米、废弃/退休。未找到当前异常专用审阅入口，只是现有资料不足，不断言不存在。已读unblock-research；外部研究超出本次仅box范围，未进行。
