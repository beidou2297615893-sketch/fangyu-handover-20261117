# 窗口 1：reply-tone-history.md（回复语气｜关键词过滤词）

## 1. 窗口职责
负责两平台共用的文字业务：门店搜索词、过滤和意向判断规则、多标签分类池、细分类词、母句语气、本地回复适配、评论分析旁注、时间预算意愿排序，以及供 CLI 消费的文字结果和指针。

## 2. 已经做成、现在还能接续的能力
- 15 家门店确认范围，3000 条门店—搜索词关系分层（主动求租与找房 511、地域与租住条件 2297、补充探索 192）。
- 10 个需求大池、40 个细标签、多标签分池及旁注原型；12209 条历史高意向池有分池和 SOP 草稿，空池 0、空回复 0。
- 本地确定性分类器原型、100 万合成输入压测（约 19.118 秒、约 52307 条/秒、模型调用 0）；4712 条旧库本地复核，支持需求 1200 条且均有母句，model_calls=0、platform_requests=0。
- 母句系统：first10、first50、按池微调、短句家族、`approved-mother-overrides-20261101.json`、`mothers-referral-v4` 渲染器。
- 语义修复：`douyin-semantic-repair-v5` 的语义守卫、定向复核、本地已确认需求补母句；纠错涉及找房时长、否定作用范围、第三方引用等。
- 预算、时效、意愿交叉筛选 `fangyu-commercial-fit-v4.3-20261106`；时效排序、Windows 计划任务 `Fangyu-Local-Daily-Time-Sort` 与 `Fangyu-Local-Text-Worker`。
- 11 月 6 日清理：文本副本三轮清理、缓存清理、小红书本地重筛、旧导出清理；过期指纹与正向名单机制。
- 共享账本与 CLI 消费指针协调；回复文字结果版本、哈希、SHA 机制。

## 3. 明确未完成、未解决或不能夸大的问题
- 本地规则原型未接近 AI 或达到 99%：修复版 200 条中，供需角色一致 71、意向一致 69、需求池集合一致 157；本地明确决定仅 30/少量，大多数要求上下文。
- 12209 条历史 SOP 覆盖不代表未来真实评论准确率；细标签命中率不等于准确率。
- 预算规则走过两种极端错误：一度放过明显低预算，后把所有未报足 4000 的全拦，最终 v4.3 才拆轴纠正。
- 真实发送与本地排序/草稿多次脱节；旧 567 行冻结队列中前 8 次提交 7 成功、1 未知，余 559 行未自动换新。
- 客户版界面截至 11 月 6 日未实施正向显示；11 月 10 日未重新验证。
- DeepSeek 未确认接通或计费；未构成专属大模型微调或自学习闭环。
- 小红书最新合格客户数不能延续旧 957 条；须核实时点。
- 旧规则文件冲突：早期“超 90 天低优先”“仅抖音 30 天归档”已被 11 月 6 日滚动 30 天删除及正向显示政策覆盖。
- 文件改盘不等于进程热更新；未知回执不能重发；历史清理不是磁盘安全擦除保证。

## 4. 工程/文件入口
- 主工作目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029`
- 门店/词库：`stores\当前门店范围.json`、`stores\最终覆盖核对.json`、`stores\词库分层验证.json`、`stores\public_sources.json`、`outputs\方隅双平台文本业务\15家门店关键词\15家门店关键词总表.csv`
- 母句：`mothers\`、`pool-mother-review\`、`pool-sop-v3\mothers-referral-v4\`
- 本地规则原型：`local-rule-pipeline\`
- AI 批次：`prepare_authorized_ai_pilot.py`、`compile_reviewed_increment.py`、`publish_douyin_increment_snapshot.py`、`sync_ai_text_status.py`、`check_registered_delta.py`
- 成本纠偏：`cost-audit\`、`rules\本地优先与疑难AI执行方式.json`、`rules\评论分析执行方式.json`
- 地区品牌旁注：`region-brand-routing\`
- 细标签：`local-subtag-v2\`、`local-subtag-integration-20261101\manifest.json`、`subtag-mother-contract\renderer.py`
- SOP：`pool-sop-v3\classifier\`、`pool-sop-v3\manifest.json`、`当前按池SOP回复指针.json`、`reply-handoff-current\manifest.json`
- 语义修复：`douyin-semantic-repair-v5\semantic_guard.py`、`local_recheck.py`、`complete_local_demand.py`、`base_renderer.py`
- 预算：`business-fit\business_fit.py`、`rules\预算时效交叉筛选纠正.md`、`rules\意向分级与预算口径-20261105.md`
- 时效排序：`recency-priority\`
- 清理：`retention-cleanup-20261106\`（`scrub_text_records.py`、`prune_cached_records.py`、`retain_xhs_business.py`、`refresh_visible_business.py`、`ensure_text_worker.py`、`expired-fingerprints.json`等）
- 运行/状态：`douyin-semantic-repair-v5\watch_increment.py`、`build_snapshot.py`、`all-pool-business-fit.jsonl`、`retained-business-customers.jsonl`、`pending-candidates.jsonl`、`douyin-replies.jsonl`、`visible-refresh-status.json`；`fangyu-douyin-independent\classification-handoff-status.json`；`recency-priority\xiaohongshu-retained-business-customers.jsonl`；`retention-cleanup-20261106\visible-current.json`、`当前文本处理运行状态.json`
- 旧库复核：`local-backlog-recheck-20261105\`、`old-library-audit-20261106\`
- 发送/共享账本：`work\shared-acquisition-ledger\shared.sqlite3`、`Codex获客工作台\work\reply_receipts.sqlite3`、`douyin-local-control\` 文件属发送窗口
- 小红书页面：`outputs\小红书15店采集进度\进度.html`、`outputs\小红书回复发送进度\进度.html`

## 5. 接续时必须遵守的限制
- 不得重跑旧 AI 批次或旧全量模型任务，除非有原始授权、唯一 owner、manifest、阶段、完成文件和 SHA。
- 本窗口只交文字候选与排序，不登录、不采集、不发送、不解除平台限制。
- 旧 `sync_douyin_text_status.py` 已禁用，不得覆盖新指针。
- `scrub_text_records.py`、`prune_cached_records.py` 等会真实删除数据，不能当只读检查运行。
- 不得恢复用户设置停止的任务，不再无新增时跑模型心跳。
- 不带 refresh-only 运行 `refresh_visible_business.py` 会清理旧导出，须授权。
- 修改规则前冻结样本、光标和消费指针；不得重写正在发送批次或已发原文与回执。

## 6. 文中出现的时间节点或耗时信息
- 2026 年 10 月 29 日：主工作目录后缀日期。
- 2026 年 10 月 30 日 18:32：成本纠偏核对，抖音合格结果 34840、新增差集 0、历史候选 12963 重构、语义标签 267 条。
- 2026 年 11 月 1 日：前 8 次提交核对；12209 条历史 SOP 草稿；`pool-sop-v3` 完成记录。
- 2026 年 11 月 2 日：时间优先排序规则文件。
- 2026 年 11 月 5 日：`意向分级与预算口径`；`local-backlog-recheck-20261105`。
- 2026 年 11 月 6 日：`fangyu-commercial-fit-v4.3-20261106`；4712 条本地复核；11 月 6 日大清理；客户版未实施正向显示。
- 2026 年 11 月 10 日 06:16:34 UTC（北京时间 14:16:34）：抖音分类交接状态快照更新；06:20:38 UTC 摘要 phase=watching_for_registered_delta，model_auto_calls=false，error 为空。
- 本地 4712 条复核耗时约 1.223 秒；100 万合成压测约 19.118 秒。
- 计划任务 `Fangyu-Local-Daily-Time-Sort` 后续记录运行间隔为 15 分钟；`watch_increment.py` 轮询间隔 60 秒。
- 源窗口本轮报告删除 9211 个独立评论：非客户 7343、低意向 1856、需求结束 12；78 条文本/快照不匹配拒删。
- 小红书窗口：冻结评论源和分类源各清 1994 处引用，草稿源清 384；39 份旧派生文件 34 份有改动，共清 8424 处引用。

## 7. 与其他窗口的交接关系
- 小红书窗口：负责小红书的采集源与冻结发送文件；本窗口提供正向文件和排除指纹，由该窗口实施删除与依赖重建。
- 抖音采集源窗口：负责 `collection.sqlite3`、runner 缓存和采集计数；按滚动 30 天清除过期记录。
- CLI/抖音发送窗口：真实发送、防重、未知停线、账号、平台限制；本窗口协调只读面板、正向池与账本交集。
- 代码与功能整合窗口：接收门店目录、IP 字段、来源/目标地区分离、去重、反馈审批、按池母句等定义；客户版界面截至 11 月 6 日未同步。
- 共享账本：`shared.sqlite3` 由多个发送端直接读取，迁移必须兼容；真实回执另查 `reply_receipts.sqlite3`。

---

# 窗口 2：contract-history.md（补充乙方信息并审阅合同）

## 1. 窗口职责
负责公寓合作协议的阅读、初步法律/商业条款审阅，以及按用户范围补充乙方资料；不修改原合同条款、不代签、不对外发送。

## 2. 已经做成、现在还能接续的能力
- 阅读并提取完整合同正文；并行做了条款审阅（contract_review）与乙方身份调查（party_info）。
- 从营业执照图片填写乙方主体名称、统一社会信用代码、纳税人识别号、廉政附件名称等。
- 收集联系人、电话、联系地址、开户行、个人账户户名和收款账号，生成 `公寓合作协议_乙方资料已填写.docx`。
- 与早期营业执照版做逐段比对：各 144 段，仅 6 段资料变化；技术使用 python-docx 脚本和 JSON 核对。
- 初步审阅了佣金计算、有效客户认定、结算条件、数据/隐私、管辖等风险点。
- 早期渲染过第一版 PDF/图片，从 11 页降到 10 页，删除尾部空白段。

## 3. 明确未完成、未解决或不能夸大的问题
- 最新版 DOCX 未完成渲染后的分页目视核验。
- 微信临时原文件已失效，无法证明最新版与原始微信文件全 OOXML 一致。
- 合作期限、签署日期、盖章位置留空；未签署。
- 银行账号、开户行、户名真实性未经银行核验，仅按用户陈述抄录。
- 甲方是否接受个人账户收款无对方回执。
- 发票类型和税率未明确；经营资格与合同责任条款风险仍保留原条款。
- 法律建议均未写入合同；用户明确不修改任何条款。

## 4. 工程/文件入口
- 最新交付：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\公寓合作协议审阅\outputs\公寓合作协议_乙方资料已填写.docx`（33383 字节，修改时间 2026-11-05）
- 旧版：`...\outputs\公寓合作协议_已补充营业执照信息.docx`（33248 字节，2026-10-28）
- 原始微信临时文件（已失效）：`C:\Users\rmsama\xwechat_files\wxid_2bhs2bi84nqv22_fd98\temp\RWTemp\2026-10\37fea8b9fd4bf17ff14dfaf4e9ee7b23\公寓合作协议.docx`
- 营业执照原图（临时）：`C:\Users\rmsama\AppData\Local\Temp\codex-clipboard-17c36b77-b22a-40fd-999f-a042c6696dd5.jpg`
- 处理脚本：`...\work\fill_contract.py`、`complete_details.py`、`资料填写核对.json`
- 正文提取：`...\work\正文提取.txt`、`提取记录.json`
- 渲染材料：`...\work\render\`（首轮 PDF/PNG）、`work\render2\`（第二轮）、`work\final_render\`（最新版转换失败）
- 法规链接：民法典中介合同章节、个人信息保护法、上海房屋管理局备案、住建部相关来源。

## 5. 接续时必须遵守的限制
- 不重跑 `fill_contract.py`：依赖已失效的微信原文路径。
- 不重跑 `complete_details.py` 只为查看进度：会从第一版重新生成并写入个人资料。
- 查看合同直接打开最新 DOCX，不先启动脚本。
- 不发对外合同，不代签、不填造日期，不擅改原条款。
- 不要把脚本源码或个人资料整段复制到共享交接文件。
- 若继续改某项资料，先备份最新版，做局部替换后对照差异；原主合同与廉政附件乙方名称一起核对。
- 最终版式验收须重新发现当前随附运行时/渲染器，不沿用历史桌面 LibreOffice 路径。

## 6. 文中出现的时间节点或耗时信息
- 2026 年 10 月 28 日：生成仅填写营业执照信息的旧版（33248 字节）。
- 2026 年 11 月 5 日：生成最新版《乙方资料已填写.docx》（33383 字节）；独立比对确认 6 处变化、各 144 段；尝试最新版渲染失败；微信原件路径已失效。
- 2026 年 11 月 10 日：盘点最新文件存在，未重新生成或修改合同。

## 7. 与其他窗口的交接关系
- 文中未写与其他自动获客窗口存在直接交接；本窗口是独立合同事项。
- 部分行为规则来自 HISTORY-COMMON.md，但未列出具体其他窗口交接关系。

---

# 跨窗口重复出现的问题

1. **明确范围收窄并拒绝擅自扩权。**  
   - 文本窗口：用户多次纠正“只改数字不要扩写”“只交文字候选不发送”“不要无新增跑模型”。  
   - 合同窗口：用户明确“只填自己的资料，不修改任何原合同条款”；审阅建议未写入合同。

2. **旧版/历史文件或路径失效，不得假设当前仍可用。**  
   - 文本窗口：旧规则、旧冻结队列、旧进程号、旧发送队列与当前指针脱节；旧 `sync_douyin_text_status.py` 已弃用。  
   - 合同窗口：微信原文件路径已失效、旧营业执照版过期、历史 LibreOffice 路径不能沿用。

3. **写过脚本或跑过流程不等于最终生效 / 验收完成。**  
   - 文本窗口：写文件、给其他窗口消息、有“已收到”不等于 CLI 已加载新稿；文件改盘不等于 Python 进程已热更新；排序文件存在不等于发送队列按新顺序消费。  
   - 合同窗口：最新版已生成，但渲染分页目视核验未完成；旧图片验收不能替代最新版证据。

4. **数量或统计口径易混，逐层区分“已登记/已判断/已入队/已提交/平台成功/未知”。**  
   - 文本窗口：多次强调历史采集数、分类数、SOP 数、当前可见池数不相同；清理报告是文件引用数，不是独立客户数。  
   - 合同窗口：144 段与 6 处变化只覆盖两份保存版本，不覆盖原始微信文件的全格式一致性；技术完成、用户决定、对方接受、正式签署状态需分开。

5. **临时文件、历史中间产物容易误导当前状态，必须核实时点与 SHA/指纹。**  
   - 文本窗口：多次要求核当前源、消费指针、SHA、评论标识稳定、时间是否过窗。  
   - 合同窗口：原始营业执照图和微信文件都是临时路径，不保证长期保留；最新文件盘点在 11 月 10 日存在，但不证明其内容经银行或对方确认。