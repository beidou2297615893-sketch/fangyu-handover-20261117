# 抖音 CLI｜搜索跟进 窗口事实提取

## 1. 窗口职责
- 在用户已登录、明确授权的抖音页面及账号范围内搜索租房相关评论。
- 从合格视频来源读取评论，保存评论 ID、原发布时间、原文及平台公开字段。
- 本地保存请求意图、反馈、回执、游标和关联来源。
- 与共享发送账本核对抖音侧防重证据，不重置 sent、unknown、reserved。
- 按原评论时间做准入及保留期处理，把合格增量交给本地分类链路。
- 消费语气窗口提供的版本化分类结果，显示有效中、高、超高意向与可回复数量。
- 提供可见的采集状态、停止原因和用户完成验证码后的继续入口。
- 采集授权与发送授权分开；本窗口后续持续任务明确为只采集、分类和草稿，不发送、不操作其他平台。

## 2. 已经做成、现在还能接续的能力
- 独立本地 SQLite 账本：请求、反馈、实体、来源关系、游标具备事务一致性；评论按平台原始字符串 CID 去重；写入失败不单独推进游标。
- Node runner 持续采集调度，搜索页与评论页交错执行、门店间公平轮换，真实断点来自 scan_streams、scan_pages。
- 来源相关性守门：检查实际返回视频正文的地域锚点、租赁语义、异地及买卖房语义，不单凭搜索词放行。
- 页指纹防重：不仅查 cursor，还查返回 ID 组合；处理“同批 ID 换游标”“空列表说有下一页”“游标不前进”。
- 可重建派生缓存 v7（runner-cache-v7.sqlite3），源库只读附加，明确 ingest 才写源库。
- scoped_recovery / collection_confirmed_scope：按 account_uid、scan_id、spec 判断 effective_halt；用户确认后建立新 scope 并排除原未知目标；旧 account_halts 不清空。
- 分层超时设计：浏览器约 60 秒、Bridge 约 70 秒、runner 本地 HTTP 约 75 秒。
- 本地清理：comment_retention.py 精确滚动 30×86400 秒；classified_comment_prune.py 对锁定低意向/非客户/结束需求按四重一致性证据清理原文并保留最小防重指纹。
- 采集进度窗口（collection_progress_window.py）：标题「抖音采集｜进度与继续」，有“验证已完成，继续采集”按钮和“停止采集并保留当前结果”按钮。
- 窄条件本地等待 worker（collection_wait_worker.py）：unknown、ok=false、transport_error=request_timeout、business 阶段、前核账号匹配且平台正常的超时事件，最多连续跳过 3 次；达到阈值后留 waiting_for_connection。
- 分类接续：消费 watch_increment.py 的本地增量 worker、build_snapshot.py、semantic_guard.py；当前商业适配版本 fangyu-commercial-fit-v4.3-20261106。
- 已修复本地 SQLITE_BUSY/locked 入账恢复、Windows control 文件共享冲突有界退避、身份核验误报等。
- 搜索引擎层面：已发现并保留 service_empty、search_service_rpc_err 与验证码等不同故障的判别文件。

## 3. 明确未完成、未解决或不能夸大的问题
- 2026-11-10 只读核实时：active-runner.json 写 status=running、pid=62008，但 tasklist 查不到该 PID；等待 state pid=47840 也查不到；采集进程实际退出的根因未查明。
- 已派发但结果未知的业务不重发，只能保留 unknown；不能证明某次旧故障是特定网络错误。
- 平台接口未证明可只返回 30 天内评论；当前做法是本地按原评论 create_time 过滤，读取许多页可能只新增少量近期记录。
- 搜索并非可靠按最新评论排序；阅读量大而有效量少是可能结果，不能承诺吞吐。
- 两层自动接续存在协调风险：2026-11-07 business timeout 守护与 2026-11-09 auto_collect.py/new_round.py 各有自己的状态和节奏，谁拥有恢复权、是否完整排除历史 unknown、是否会循环，尚未全组合验收。
- 手机提醒渠道没有经过本窗口验证的配置和送达记录。
- 说明文档过时：README 仍是离线小样，runner_README 仍写 30/40 秒、v5 缓存；本次未重写。
- 当前不是完整商业交付的通用客户端，不能扩张为跨电脑部署、所有账号自动切换、所有异常自动恢复、正式安装包、实际发送全链路。
- 11 月 9 日后续 auto_collect / new_round 代码只读看到，未运行验收；启动采集自动续跑.cmd 未验证全套平台行为。

## 4. 工程/文件入口
项目根目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统`

本窗口主目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent`

核心入口：
- `active-runner.json`：当前入口指针；只信 status 不够，还要核进程、租约。
- `runner.cjs`、`runner_ledger_adapter.py`、`ledger.py`
- `scoped_recovery.py`、`collection_confirmed_scope.py`、`continue_collection.py`
- `collection_identity_check.cjs`、`collection_progress_window.py`、`collection_wait_worker.py`
- `comment_retention.py`、`classified_comment_prune.py`
- `classification-handoff-status.json`
- `new_round.py`、`collection-config-fixed.json`、`auto_collect.py`、`启动采集自动续跑.cmd`
- `plan-round-20261109-230850.json`
- `runner-live-round-20261109-230850\control.json`
- `runtime\collection.sqlite3`、`runtime\runner-cache-v7.sqlite3`
- `runner-audit-myeaj720\runner-qualification-policy.json`

共享账本：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3`
历史回复回执：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\reply_receipts.sqlite3`

分类工作区：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029`
- `douyin-semantic-repair-v5\watch_increment.py`、`build_snapshot.py`、`semantic_guard.py`、`local_recheck.py`、`complete_local_demand.py`
- `douyin-semantic-repair-v5\all-pool-business-fit.jsonl`、`retained-business-customers.jsonl`、`watch.log`、`实时进度.txt`
- `business-fit\business_fit.py`、`pool-sop-v3\classifier`、`recency-priority`

## 5. 接续时必须遵守的限制
- 不复制客户原文、客户身份、登录状态、密码、Cookie、Token、Bridge 配置内容。
- 不把视频数算成评论数；评论不是独立人数；来源门店不是意向门店；IP 属地不是意向地区。
- raw 原始返回是经敏感字段脱敏的 JSON 结构，不是网络原始字节档案，也不承诺任意自由文本已绝对脱敏。
- 重开或恢复前先查 active 文件、真实 PID、租约、control 的 pending/prepared/dispatching/STOP、feedback、末尾 stdout/stderr；再用 scoped_recovery 核 effective_halt；不清理 halt、不直接认验证码。
- 未知不重发；sent/unknown/reserved 不重置；历史 halt 不清空；身份异常、验证、限流、错账号仍需人工处理。
- 90 天 backfill 文件是历史阶段，不能在新任务中复活已清理旧 CID。
- 当前 30 天为精确滚动秒边界，不用 90 天准入。
- `--recover-local` 只重放已经落盘的确定反馈；不能拿 dispatching 当确定反馈。
- 1 秒是上一页回执完成后的节奏等待，不是每秒必得一页，也不是并发无上限。
- 打开进度窗只读不启动采集；窗口“验证已完成”按钮不代用户点击。
- 继续当前任务、开新轮、恢复本地反馈是不同入口，不能混用。
- 后续只能以用户认可的后续商业适配版本为准，不因文件名新就自动认可。

## 6. 时间节点或耗时信息
- 2026-10-29 起：建立持续采集 runner 与多来源调度；最初计划覆盖 15 个门店入口和约 3000 个规范搜索词。
- 2026-11-04：本地优先、约 5 万目标、1 秒间隔；minimum_delay_ms 变为 1000。
- 早期生产节奏默认 40 秒、最低 30 秒；用户要求改为每页 1 秒。
- 2026-11-05：用户明确只保留 30 天以内，超过 30 天从有效派生池移除。
- 2026-11-06：约 18:43—18:45 实际观察到验证码并留证；同天进一步要求源 comments 业务正文滚动 30 天清理。
- 2026-11-07 约 01:41：历史健康检查确认采集、等待守护和分类 worker 都在、effective halt 为空，当时可见有效线索 4157、可回复 1631。
- 2026-11-09 23:09：active-runner.json 修改时间，指向 plan-round-20261109-230850.json 及其运行目录。
- 2026-11-10 14:25—14:26：本次只读状态快照；tasklist 查不到采集 PID 62008、等待 PID 47840；分类 worker PID 38104 显示 python.exe。
- 分类快照声明：有效可见线索 4643（中 4152、高 479、超高 12）、pending_candidates_count 839；worker 水位 9500、model_auto_calls=false、error=null。
- 早期离线性能历史：约 10 万合成评论、5000 页样本首次缓存约 0.933 秒、暖 snapshot 约 0.021 秒；本次未重跑。
- 历史阶段曾用过 35588、36034 作为累计起点；均为历史口径，不是当前有效条件。
- 旧汇报文件停在 11 月 7 日约 01:42，含旧 PID、旧批次、90 天字段。

## 7. 与其他窗口的交接关系
- 「回复语气｜关键词 过滤词」窗口：维护意向、预算、双方意愿、母句、回复口吻和排序规则主体；本窗口只接入其产物，不自造分类标准。历史修复旧回复索引漏纳，恢复约 589 条候选关联。
- 共享发送账本：本窗口只针对 platform=douyin 核对，不读取、重置或接管其他平台状态。
- 分类链路：消费语气窗口认可的 v4.3 商业适配版本；分类 worker 和产物在 fangyu-text-business-20261029 工作区。
- 相邻采集台：`抖音自用采集台\启动.cmd` 和 `work\runtime\douyin-bridge` 是相邻入口/运行环境，不应该与独立 runner、自动续跑器盲目同时启动。
- 本窗口不负责 xiaohongshu 账号与采集窗口的事务；本次只写自己的历程。

---

# 小红书 CLI｜搜索跟进 窗口事实提取

## 1. 窗口职责
- 最初承接方隅小红书独立 CLI：门店搜索、评论读取、意向筛选、经授权的回复和记录。
- 用户强调 CLI 要脱离 Codex 独立运行，员工以后也能使用；不要等软件完成才采集。
- 每个阶段必须有本地持久记录，区分采集、分析、草稿、发送尝试、平台回执和未知结果。
- 2026-10-29 调整职责：语气、过滤词、意向分类、门店关键词、回复母句交「回复语气｜双平台」；软件实施交「代码与功能整合」；小红书 CLI 的账号、采集执行、技术排错、账本交新建的「小红书 CLI｜账号与采集」窗口。

## 2. 已经做成、现在还能接续的能力
- 用现有 `xiaohongshu-cli` 独立 CLI 会话成功登录蕾姆身份并读取主评论；独立会话目录与浏览器数据隔离。
- 成功搜索并持续采集过部分批次；保存 collection.json、attempted-notes.json、dedup-summary.json、register-result.json、new-ai-input.json、registered-ready.json、state.json 等运行文件。
- 曾登记 942 条新增评论；另一次恢复后 18 个批次实际登记 1,700 条新增评论、1,336 个本地客户 ID。
- 补齐过旧备份统计：历史 3,069 条评论、1,869 个本地客户分组；旧版分类为高意向 157、中 22、低 6、极低 8、待确认 264、暂判无关 1,412。
- 独立去重工具 `xhs-dedupe-standalone`：按平台+评论 ID 去重；同平台可靠 UID 可归组；冲突和缺身份进待核。14 项隔离测试通过。
- 接通过古北首轮经授权发送：首批 31 条返回回复编号，后 15 人复核中 1 条新受理，合计 32 条受理；另有 1 条该次尝试未知、1 位历史 submitted 未知。
- 菜单入口 `xhs-cli-standalone-entry/start.cmd`、`standalone_cli.py`、README：支持状态查看和预览；菜单含真实发送功能，本次未运行。
- `project_send_log.py`：从共享账本只读生成幂等文本快照，6 项离线测试通过；对应 33 条预留/结果。
- 补过楼中楼兼容参数（19 项本地测试）、qr_http_adapter 候选（14 项离线测试）、account_switch 候选（70 项离线测试报告：28 候选+42 回归）。
- 旧 AI 初筛：887 条缺正文初筛，后续 44 条正文复核；同帖小样 12 位约 59 秒。
- 草稿阶段：`xhs-intent-drafts` 保存 120 个对象中 116 条非空草稿、4 条暂缓；均为未发送。
- 用户否定旧语气模板；xhs-resident-tone-regeneration 中 304 条对象 294 草稿、10 暂缓，均标“未认可”。
- 话题池候选：32 条样本，第二版 24 条标签一致、8 条遗漏，只离线验证。

## 3. 明确未完成、未解决或不能夸大的问题
- 新账号登录：10 月 29 日尝试换号时一次扫码超时、后来重新显示二维码，但本窗口未得到可核实的新账号登录结果。
- 动态账号候选在真实小红书上的采集与登记，交接时未证实；单次入口只运行一页，尚无完整持续调度；STOP 只在单批启动前检查；跨电脑互斥未实现；发送端未同步适配。
- 461 的具体触发原因、是否存在平台可操作验证入口，当时缺直接证据；不能说已彻底修复，也不能归因单一账号/网络/设备。
- 逐条外部文本自动记录与实际发送入口接通、跨机统一账本、员工身份、服务器原子认领、离线冲突处理，均未完成。
- 旧采集风险：attempted-notes 被当作已处理，可能漏掉失败或未完成帖子的后续评论；交接时发现该风险，并在隔离候选中研究，但旧窗口被中断，没有获得最终通过或真实验证结果。
- 2026-11-10 只读查询旧路径关键字未匹配到进程，但不覆盖所有后来新增入口，不能断言全项目没有其他任务。
- 网页登录成功不自动同步 CLI 会话；不能凭手机或浏览器验证状态断言 CLI 会话完成。
- 用户反馈页面看不到二维码或扫码过期时，必须展示当前有效图，不能复用旧二维码。
- 平台返回编号只说明受理，公开页面是否全部可见未逐条验证。
- 历史 31+1 受理、2 未知仅覆盖当时已核对来源；没有将旧数字冒称 11 月 10 日全系统实时统计。

## 4. 工程/文件入口
历史客户备份：
`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3`

本窗口工作目录：
- `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/`
- `diagostics/qr_http_adapter.py`、`test_qr_http_adapter.py`、`browser_cli_once.py`
- `collection-live/batch-0019/failure-diagnostic.json`
- `collection-live/user-pause-receipt.json`

采集相关：
- `xhs-collection-candidate/collector.py`、`register.py`
- `xhs-standalone-session/diagnostics/dedup_collect_once.py`、`continue_collection.py`
- Python：`work/vendor/cli-runtime/Scripts/python.exe`

去重和入口：
- `xhs-dedupe-standalone/`
- `xhs-cli-standalone-entry/start.cmd`、`standalone_cli.py`、`README.md`

共享账本：
- `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/shared.sqlite3`
- `.../shared-acquisition-ledger/CLI对接说明.md`

发送核对输出：
- `outputs/古北已回复语气/已受理客户原话与回复.txt`
- `outputs/古北十五位复核与回复/十五位客户的判断与回复情况.txt`
- `work/xhs-recording-audit/20261029-第一批回复复核.md`
- `work/xhs-recording-audit/project_send_log.py`
- `历史发送账本文本快照.jsonl`

分类/草稿/交接：
- `work/xhs-context-lite-analysis/state.json`
- `work/xhs-browser-context-recovery/analysis/`
- `work/xhs-three-stage-integration/live_consumer.py`
- `work/xhs-analysis-recovery/`、`work/xhs-analysis-recovery-0016/`
- `work/xhs-intent-drafts/`
- `work/xhs-resident-tone-regeneration/PAUSED.md`
- `work/xhs-topic-pool-spike-v2/`、`work/xhs-topic-pool-evaluation/`
- `outputs/评论分类测试与词类/分类词与真实评论对照.md`
- `work/voice-window-handoff-20261029/筛选关键词语气交接.md`
- `work/xhs-account-switch-candidate/account_switch.py`、`collect_once.py`、`README.md`、`verification-result.json`
- `work/cli-window-handoff-20261029/CLI交接.md`

## 5. 接续时必须遵守的限制
- 不复制客户原文、登录数据、Cookie、Token、账号凭据。
- 不能把本地无记录等同平台从未回复；历史 submitted 但无回执的状态保留，不自动重发。
- 平台验证、461、登录异常、限流时停止并保存证据，由用户完成验证；不能自动切号或绕过平台限制。
- 不确定状态必须保留，不能只靠旧文件数字推断当前状态。
- 菜单含真实发送功能，不能为确认而盲点发送；不能照搬旧批次发送命令。
- 换账号候选每批必须绑定实际登录 UID、非游客检查、登记前再核身份；STOP 只在单批启动前检查，不能假称已持续化。
- 缺正文只能做“明确标记的初筛”，不能当作最终判断。
- 旧 `related_keyword_schedule.py` 可能重建队列，不能为接续直接覆盖历史安排。
- 语气和分类结果必须使用语气窗口已认可的版本；本窗口不自认两者已与 CLI 一体化。
- 跨平台相似信息不能自动合并，昵称不能当身份。
- 若独立候选只支持一页，要如实说明尚未持续化。
- 服务器多员工账本、原子认领等属于后续软件需求，不能当作已部署能力。
- 不要把“文件写入”或其他窗口创建动作误称窗口已经运行或软件已经部署。

## 6. 时间节点或耗时信息
- 2026-10-28：用户多次扫码及网页验证，手机显示成功，但 CLI 确认阶段未获预期结果或需要进一步验证；出现过电脑设备登录超限。
- 2026-10-28：蕾姆 CLI 成功登录并成功搜索、持续采集，也遇到 461 和 NeedVerifyError。
- 2026-10-28：首批 31 条平台返回回复编号；后 15 人复核中 1 条新受理；合计 32；另有 1 条未知。
- 2026-10-29：尝试从古北找房第 5 页恢复时 SessionExpiredError、业务码 -100；第 19 批在身份阶段停止；batch-0019/failure-diagnostic.json 留证。
- 2026-10-29：用户选择换账号，本窗口生成新二维码，第一次扫码等待超时，重新显示二维码后未得到可核实的新账号登录结果。
- 2026-10-29：核查共享账本 5,728 条评论，含历史 3,069 和后来 2,659；旧快照，当前活跃库会变化。
- 2026-10-29：本窗口先后登记 942 条新增评论；另有 55 条正文补读、887 条缺正文初筛。
- 2026-10-29：恢复采集时，18 个批次实际登记 1,700 条新增评论、1,336 个本地客户 ID。
- 2026-10-29：最后一份测试报告为 70 项离线通过（28 候选+42 回归），无真实平台请求。
- 2026-11-10：本次只读按旧路径关键字查询进程没有匹配，未覆盖所有新入口。
- 早期用户曾要求 5 分钟心跳，但后来明确无采集时不要汇报；本窗口暂停了 automation-10。
- 早期独立菜单支持“一秒额外间隔”，但时间还包含网络和处理，不能保证每秒一条。

## 7. 与其他窗口的交接关系
- 2026-10-29 用户调整后，业务规则交「回复语气｜双平台」，软件实施交「代码与功能整合」，密码/采集/账本交新建的「小红书 CLI｜账号与采集」窗口。
- 本窗口实际创建了新窗口并发送初始任务；创建动作在被用户中断前成功，但后续执行不是本窗口自身完成的工作。
- 本窗口把筛选关键词、语气交接材料交给语气窗口：`voice-window-handoff-20261029/筛选关键词语气交接.md`。
- 本窗口留下 CLI 交接文件：`cli-window-handoff-20261029/CLI交接.md`。
- 服务器多员工账本、关键词、语气等分别有对应窗口；本窗口不把文件写入误称窗口已经运行或软件已部署。
- 本窗口不把抖音窗口的采集、分类、发送链路混入小红书窗口；小红书旧 AI 分析、草稿与发送也是不同环节。

---

# 跨窗口重复出现的问题

1. **状态文件写 running / stopped / alive 不等于真实进程存在**  
   两份历程都出现同一问题：抖音窗口 2026-11-10 看到 active 写 running、PID 不存在；小红书窗口 2026-11-10 看到 state.json 最后 stopped，未匹配到旧路径进程，但不敢断言没有新任务。共同点是：必须查当前真实进程、锁、租约、最新状态，不能只信状态文件。

2. **旧统计数字、历史快照和当前有效量容易混用**  
   抖音窗口多次纠正：旧累计起点 35588/36034、旧 5 万目标、旧汇报 4157/1631、新快照 4643/839、90 天旧字段，都不能替代当前有效线索。小红书窗口也多次出现：3,069、942、1,700、5,728、457/481 等口径不能叠加，平台返回编号不等同公开可见或发送成功。共同问题：历史数量、不同阶段口径、当前实时统计必须分开，不能直接相加或代替。

3. **“未知结果”和“失败”不能被自动重发或清空**  
   抖音窗口强调 dispatching 但结果未知不能重发原业务；unknown、sent、reserved 不重置。小红书窗口强调历史 submitted 无回执不能假设成功或失败，也不能自动重发；结果未知必须保留。共同点：未知/在途状态是证据边界，接续时不能靠自动逻辑消除。

4. **用户网页/手机验证成功，不等于独立 CLI 或 Bridge 会话同步成功**  
   抖音窗口多次遇到页面正常但 CLI 仍未知、身份前后核验失败；小红书窗口明确网页登录/验证成功不与独立 CLI 会话自动共享，二维码必须当前有效。共同点：验证环节必须与执行会话和平台返回的实际身份分别核实，不能因用户一句“OK了”就免核查。

5. **历史“超过 30 天/90 天”旧保留规则与新 30 天准入规则不能混用**  
   抖音窗口明确当前为精确滚动 30 天，90 天 backfill 是历史阶段；小红书窗口虽然没有同样明确写 30 天入口，但其客户口径多次强调历史不同阶段、旧快照不能当当前有效，且多次改规则。共同点：时间准入规则被用户多次修改，接续时必须取最新认可口径，不能复活旧字段。

6. **本地/离线测试通过不能当作平台真实验证或生产验收**  
   抖音窗口说合成账本、离线性能测试不能承诺真实吞吐；小红书窗口说离线测试、候选代码只能说明本地逻辑