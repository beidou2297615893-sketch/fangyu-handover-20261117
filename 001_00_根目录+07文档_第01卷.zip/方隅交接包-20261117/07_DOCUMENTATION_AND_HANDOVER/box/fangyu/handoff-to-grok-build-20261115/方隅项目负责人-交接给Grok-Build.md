# 方隅项目负责人 · 交接给 Grok Build

写于 2026-11-15 00:58（北京时间）。这份文档是给没看过我们聊天的编程工具用的：读完应能接着改「方隅自动获客系统」客户端，不必再翻旧对话。

当前编程主战场只有下面这个目录，不要另起一套，也不要把旧工作台再封装一遍。

- 产品代码与预览壳：`/workspace/fangyu-opendoor-replica/`
- 界面设计依据：`/workspace/project-intake/fangyu/ui-design/batch-09/`（先读同目录 `README.md`）
- 开源提示词原件（只读参考）：`/workspace/fangyu-opendoor-replica/source/`，网上对应 [xuanxuan-prompts / openDoor](https://github.com/xuanxuan321/xuanxuan-prompts/tree/main/openDoor)

---

## 1. 项目是什么

用户经营公寓招租，已有一套本机采集、筛选、拟回复的链路（抖音为主，小红书另有对口）。现在要做的，是对外名叫「方隅自动获客系统」的桌面客户端：看起来要像 openDoor 那种带动效的漂亮网页，但日常不是官网长滚动，而是四个工作状态的软件主界面，以后再接到已有采集和回复能力。

用户明确说过：不要把我们团队自己设计的那套旧界面做成网页再做成软件；要用这类「好看、带动效的网站复刻提示词」当底子，把功能和按键嵌进去，再封装进软件。

指定的免费提示词就是 openDoor（花植黄门、电影感背景、顶部药丸导航、底部超大标题、液态玻璃、鼠标视差）。

---

## 2. 先打开这些，按这个顺序看

1. 设计说明：`/workspace/project-intake/fangyu/ui-design/batch-09/README.md`，以及同目录 01–08 共八张 PNG。
2. 已发给用户、以这套为准的四态实机截图（2026-11-14 约 23:20 修过两处小问题后重截）：
   - `/workspace/fangyu-opendoor-replica/shots/b09-idle.png`
   - `/workspace/fangyu-opendoor-replica/shots/b09-running.png`
   - `/workspace/fangyu-opendoor-replica/shots/b09-need.png`
   - `/workspace/fangyu-opendoor-replica/shots/b09-paused.png`
3. 网页实现：`/workspace/fangyu-opendoor-replica/web/`，入口说明 `web/README.md`。状态、文案、数字、接口地址集中在 `web/src/lib/product.ts`。
4. 云电脑预览壳：`/workspace/fangyu-opendoor-replica/client/`，尤其是 `bridge.py`（硬闸门）和 `open_preview.py`。

下面这些可以当历史，不要当当前成品，也不要在它们上面继续改产品界面：

- `/workspace/fangyu-workbench-copy-20261114/`：云电脑上的旧工作台副本。里面的 `web-client/` 是把已否决的深色玻璃预览包进 Electron，用户不要这条路。
- `/workspace/fangyu-opendoor-replica/shots/client-*.png` 和早期英文官网截图：Mux 视频 403 时截到的黑屏/英文落地页，不是产品。
- `/workspace/fangyu-opendoor-replica/shots/ui/01-idle.png` 等四张：同一晚更早的产品截图，已被上面的 `b09-*.png` 取代（当时药丸高亮有时不像「主页」，右下角还有浅浅的「演示数字」标签）。
- `client/打开预览.md` 里有一段过时描述（还写着网页标题是英文、首屏可能停在 Loading 0%、按键还没嵌进动效）。以现在的 `web/` 源码和 `web/README.md` 为准。

---

## 3. 已经做到哪一步（截至 2026-11-14 23:20，之后源码没有新改动）

- 已按官方 `prompt.md` 在云电脑上复刻 openDoor 网页，技术栈是 React 19 + Vite + Tailwind CSS v4 + GSAP + hls.js + react-router-dom 等，见 `web/package.json`。
- 已把日常界面从 500vh 长滚动官网，改成四个镜头位置对应四个工作状态。查询参数：
  - `?state=idle|running|needYou|paused`（规范写法是 `needYou`；`needs_you` / `need-you` 也能认）
  - `?empty=1` 四个数字全部显示「—」
  - 不要加 `?hls=1` 去抢 Mux 官方流（见第 6 节）
- 主页四态已经按 batch-09 做进 `web/`，并在云电脑用隔离 Chrome 应用窗预览。窗口标题和网页 `<title>` 都是「方隅自动获客系统」。
- 启动／暂停／知道了只会 `POST http://127.0.0.1:18765/api/action`，动作是 `start` / `resume` / `pause` / `ack`。`client/bridge.py` 里硬闸门 `COPY_BLOCKS_LIVE_ACTIONS = True`，关不掉，只记演练，不会采集或发送。占位接口没开时，界面仍会在本地切态。
- 打开预览：`python3 /workspace/fangyu-opendoor-replica/client/open_preview.py`
  - 网页：`http://127.0.0.1:5173/`
  - 占位接口：`http://127.0.0.1:18765/`（`/api/health`、`/api/state`、`/api/action`、`/api/login` 等）
  - 不要占用 8765、8766，也不要去连 19422。
- 闸门自检：`cd /workspace/fangyu-opendoor-replica/client && python3 -m unittest test_bridge_gate.py -v`（此前 9 项通过）。
- 设计侧 batch-09 的 05–08（客户、设置、帮助、登录）已经出图并发给用户；软件里还没按图做进去，点开药丸目前只是占位玻璃说明。
- 这四张修过的主界面截图已发给用户看。按用户 23:05 的要求：慢慢来、按流程一步一步做稳。当前应等用户看完这四态（以及已发出的 05–08 设计图）再说下一步，不要抢着把启动接到真链路，也不要先做悬浮窗。

待开始时四个数字是「—」。运行中、需要你处理的示意数字是 86 / 54 / 32+4 / 1286；已安全暂停里有效池是 32-2。这些是对照设计图的演示数，不是现场真实账本。

---

## 4. 还没做完什么

按「先稳住主界面四态，用户认可或明确说继续，再做面板」的顺序：

1. **客户 / 设置 / 帮助面板**：按 `05-customers.png`、`06-settings.png`、`07-help.png` 嵌进现有液态玻璃，不要每天挡在主画面上；从顶部药丸点开才出现。现在 `product.ts` 的 `PANEL_COPY` 只是占位文字。
2. **登录页**：按 `08-login.png`。未登录时顶栏只留屋脊标、不放药丸；标题写清「请在普通抖音网页登录，不要走进创作者中心。」；说明用「现有通道」，界面不要写 Bridge、端口、Cookie；主按钮「打开抖音页」。登录成功只供核对账号，**不会自动开始采集**。真登录页若以后要接，目标是普通抖音页 `https://www.douyin.com/jingxuan`，不要打开创作者中心。
3. **悬浮窗**：若用户还要，等这一批看过后再按同一气质另做；先不要做。
4. **接到本机已有采集和回复链路**：现在还不行。硬闸门必须保持。用户本机正在用的安装不能换、不能覆盖。没经用户用大白话同意前，不要把预览里的启动／暂停改成真的采集或发送，也不要请用户拿这个预览去扫码验证。
5. **本机正式封装**：`client/windows_preview_draft.py` 只是以后用 pywebview + Edge 的草稿，这轮不要在用户电脑上跑，不要替换正在用的安装。

和设计图相比，主界面四态还有这些已知差别，不是必须立刻推倒重做，但接手时要知道：镜头是本地视频 seek，不是设计图那几张预合成静帧，远近可能略有差别；屋脊标用的是官方白标，圆圈里会紧一点；玻璃是实时 `backdrop-filter`，设计图是预先模糊好的。

---

## 5. 产品必须遵守的规则（不要自行发挥）

- 对外名称只叫「方隅自动获客系统」，不要叫「抖音工作台」或「方隅工作台」。
- 只有四种状态：待开始、运行中、需要你处理、已安全暂停。单条失败或页面一时没反应，由软件自己跳过，不要把这些失败画到主界面上。
- 主画面只放三样：一句说明当前在干什么、一个大按钮、下面一行四个数字（今日采集、今日回复、有效池加减、累计总数）。没数写「—」，不要写成 0，也不要擅自加「按小时／按时间」这类用户没要过的统计列。
- 大按钮文案：待开始和已安全暂停是「启动／继续」（全角斜杠）；运行中变为「暂停」；需要你处理是「知道了」（保持停住，不画假验证码，不弹错误码）。
- 药丸导航：主页 / 客户 / 设置 / 帮助。当前项必须能一眼看出是「主页」（浅色当前项或设计图里的黑底白字，以设计图为准，但四态上都应是「主页」被选中，除非用户点开了其他药丸）。客户、设置、帮助是入口，点开才出列表或面板。
- 门店在安装时选一次并记住，默认「上海联航路云涛公寓」。日常界面不要出现「切换门店」。设置里的「切换」只换账号，不是切门店。
- 登录只要连普通抖音，并接上现有通道；不要打开创作者中心或创作中心。
- 打开软件、登录成功，都不等于授权发送。
- 不要在界面或日志里露出完整 UID、手机号、Cookie、客户评论原文。演示名单用遮罩，例如 王**。
- 能留的 openDoor 味道：全屏花植黄门电影感背景（随状态推进镜头、需要你处理时门打开）、顶部居中药丸、底部超大标题、液态玻璃只在需要你处理和点开的面板出现、黑白通透、大留白、鼠标微微带动画面。
- 不要搬进来的：HOME / ABOUT / SERVICES / CONTACT、英文广告和品牌跑马灯、官网式多页长滚动、汉堡菜单、把 Loading 百分比当成日常界面、创作者中心登录、日常切门店、旧版居中一张深色工作台卡加左侧导航。

用户没提过的新功能或新做法，先用大白话问用户，同意了再做。技术工作优先套用现成 skill、开源项目或开源软件，不要从零另起一套。

---

## 6. 已知坑

- **Mux 官方 HLS 会 403。** 地址是 `https://stream.mux.com/43NlHXsaMrmyzWamMk87m01fNyxSTekAD669BBAPBNm00.m3u8`，在这台云电脑上返回 `not_authorized`。不要反复重试。本地兜底已经有：`web/public/subway-jungle.mp4`（同一段花植黄门成片，没有烧进 UI），以及 `camera-idle.jpg`、`camera-running.jpg`、`camera-need-you.jpg`、`camera-paused.jpg`、`opendoor-poster.jpg`。源 GIF `source/opendoor.gif` 带官网导航和标题烧录，不要拿它当循环背景。
- **Dirtyline 字体没有中文。** 大中文标题用 Noto Serif SC Bold；数字用 Manrope。字体文件在 `web/public/Dirtyline-36daysoftype-2022.woff2`。
- **不要读、不要连现场 Bridge。** 副本不得真连 19422，不得去读本机 `bridge.json`。路径里带「抖音自用采集台/data/bridge.json」的请求应直接拒绝，并且不读那个文件。
- **端口：** 预览用 5173 和 18765。8765 是别的项目在用，8766 是旧工作台预览，不要占、不要停别人的服务。
- **云电脑和用户本机不是同一台，** 文件不会自动共用。不要用操作用户电脑的方式去换正在用的安装，也不要为了预览去动用户前台。
- **`client/打开预览.md` 部分过时**，见第 2 节。演练日志位置文档写的是 `client/copy-dry-run/blocked-actions.jsonl`，实际还要看 `client/.logs/bridge.log`。
- 早期有人把状态写成 `needs_you`，产品规范是 `needYou`。解析已经兼容，新代码请用 `needYou`。

---

## 7. 绝对不要动什么

- **不要改、不要覆盖、不要替换用户本机正在用的安装。** 本机快捷方式「方隅工作台（新版试用）.lnk」指向：`C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261114\方隅抖音工作台（员工候选）.exe`。旧工作台源码位置（历史底子，不是当前产品 UI）：`C:\积木软件工坊\项目\方隅公寓客户版\work\ui-native-r57\run_workbench.py`。
- **不要从任何副本里启动或停止真实采集、发送，** 不要启停或重连现场 Bridge，不要打开独立的真实浏览器登录资料去干活。
- **不要拆硬闸门，** 不要把 `COPY_BLOCKS_LIVE_ACTIONS` 改成可关闭。
- **不要把账号 Cookie、客户数据、商业文案写进通用组件或代码仓库，** 不要在文档或聊天里贴密钥、账本、登录态。
- **不要删除业务数据。**
- 抖音现场发送、小红书现场发送各有对口窗口，不是这份客户端预览的工作。不要另开第二条采集或发送通路，也不要打断本机可能正在跑的任务。
- 以前自动对接官方 Codex 的办法已经作废。不要自己进入或操作 Codex 窗口。

---

## 8. 建议你接手后怎么干

1. 先在云电脑打开现有预览，对照 `b09-*.png` 和 batch-09 的 01–04，确认主界面四态还在、硬闸门还在、本机安装没被碰到。
2. 主界面若还有用户指出的问题，先只修这四态。
3. 用户认可或明确说继续之后，再按 05–08 把客户、设置、帮助、登录做进同一个 `web/` 项目（不要新开一个仓库或再做一套深色玻璃）。做完用现有 `open_preview.py` 重开预览并截图，不要覆盖设计原图和 `source/` 里的官方素材。
4. 在用户明确同意之前，启动／暂停继续只打占位接口。不要为了「快一点交给用户扫码」去接真链路。

相关资料（不必先读完才能开工，缺证据时再查）：

- 11-14 紧急交接（旧工作台接受口径，不是当前产品 UI）：`/workspace/project-intake/fangyu/紧急交接-以本文件为准-20261114.md` 和 `/workspace/project-intake/fangyu/accept-20261114/`
- 更早的项目分拣入口：`/workspace/project-intake/fangyu/`
