# 技术软件集成窗口交接给 Grok Build

这份文档是给一个没看过我们聊天的编程工具看的。写文档的窗口是「技术 软件集成」，负责把方隅公寓自动获客系统做成可打开的客户端，并在云电脑上封装和预览。不要从别的窗口（总书记、抖音链路、小红书链路、规则与运营、新软件负责人／每日百题）把无关任务捡过来做。

文档写于 2026-11-15 00:58（北京时间）。下面的路径都在云电脑上，除非写明是用户 Windows 本机。

---

## 项目是什么

产品对外名称：**方隅自动获客系统**。

用户指定用开源提示词合集 [xuanxuan-prompts 的 openDoor](https://github.com/xuanxuan321/xuanxuan-prompts/tree/main/openDoor) 网页动效，作为客户端主界面基础。滚动/镜头推进花植黄门车厢，四种工作状态对应四个镜头位置，功能和按键嵌进这套动效里。

**不要再做、也不要再封装**此前那套深色工作台玻璃界面（batch-07／batch-08 的居中玻璃卡、左侧栏）。那只是旧预览，已经不是产品方向。

---

## 文件在哪

### 当前正在做的工程（以这个为准）

云电脑：`/workspace/fangyu-opendoor-replica/`

| 位置 | 是什么 |
| --- | --- |
| `source/prompt.md` | 原版 openDoor 复刻提示词 |
| `source/opendoor.gif`、`source/opendoor.poster.jpg` | 原动图和封面，不要覆盖 |
| `web/` | 网页工程。技术栈：React 19、Vite、Tailwind CSS v4、GSAP（ScrollTrigger／ScrollToPlugin）、hls.js、react-router-dom。界面已按 batch-09 改成产品四态，不再是英文官网落地页 |
| `client/` | 客户端封装壳。云电脑用隔离档案的 Chrome 应用窗口（`--app`）加载网页 |
| `client/open_preview.py` | 一键打开预览 |
| `client/打开预览.md` | 人话说明：怎么打开、端口、闸门 |
| `client/bridge.py` | 本机占位 API 和硬闸门 |
| `client/test_bridge_gate.py` | 闸门测试，9 项应全部通过 |
| `client/windows_preview_draft.py` | 以后 Windows 上用 pywebview + Edge 的草稿。本轮不要在用户电脑上跑，不要换本机安装 |
| `shots/b09-idle.png` 等四张 | 当前主界面成品预览（2026-11-14 23:20 重截，方隅已看过并已发给用户） |

一键打开（只在云电脑）：

```bash
python3 /workspace/fangyu-opendoor-replica/client/open_preview.py
```

- 网页：`http://127.0.0.1:5173/`。若 Vite 已经在跑，直接复用，不要再起一份。
- 切四态：`http://127.0.0.1:5173/?state=idle` / `running` / `needs_you` / `paused`
- 真实缺数演示：同一地址加 `?empty=1`，四个数字都显示「—」，不要写成 0
- 占位 API：`http://127.0.0.1:18765/`（`/api/health`、`/api/state`、`/api/action`、`/api/login`）
- 不要占用 **8765**（答题项目残留）和 **8766**（旧工作台预览）。不要去连 **19422**。

自检闸门：

```bash
cd /workspace/fangyu-opendoor-replica/client
python3 -m unittest test_bridge_gate.py -v
```

### 产品界面依据

`/workspace/project-intake/fangyu/ui-design/batch-09/`

- `README.md` 是口径说明，先读这个。
- `01-home-idle.png` 待开始：门关着，大标题是产品名，按钮「启动／继续」，四个数字都是「—」
- `02-home-running.png` 运行中：镜头靠近门，按钮变为「暂停」，演示数字 86、54、32+4、1286
- `03-home-need-you.png` 需要你处理：门已打开，液态玻璃板滑上，按钮「知道了」，不画假验证码
- `04-home-paused.png` 已安全暂停：按钮回到「启动／继续」，有效池 32 且 -2
- `05-customers.png`、`06-settings.png`、`07-help.png`、`08-login.png` 已出图，**先不要嵌进产品**。方隅说等用户先看完主界面，再按图加这些玻璃面板。

缺的图和按钮排布以这些设计图为准，不要自己另起一套视觉。

### 旧工作台副本（仅作参考，不是当前产品）

`/workspace/fangyu-workbench-copy-20261114/`

这里有更早的深色玻璃预览、四态状态机、统计口径和硬闸门初版（例如 `direct-desktop/sources/board_actions.py`、`bridge_login.py`、`douyin_board_stats.py`）。可以对照口径，**不要再把它封装成给用户看的成品**，也不要改去覆盖当前 `fangyu-opendoor-replica`。

相关口径文档：

- `/workspace/project-intake/fangyu/紧急交接-以本文件为准-20261114.md`
- `/workspace/project-intake/fangyu/accept-20261114/douyin-data-sources-20261114.md`
- `/workspace/project-intake/fangyu/accept-20261114/board-stats-time-fields-20261114.md`

---

## 已经做到哪一步

1. **客户端壳已能在云电脑打开看动效。** 这台云电脑没有 WebKit／pywebview，用已有 Chrome（`/usr/bin/google-chrome`）加隔离资料目录 `.chrome-preview-profile`。窗口标题「方隅自动获客系统」（用 `client/chrome-title-extension/` 改标题，不必改网页源码里的 title）。
2. **网页已按 batch-09 改成产品主界面四态**，不是英文官网（没有 HOME／ABOUT／“Unleash The Full Power”／品牌跑马灯）。药丸导航是：主页、客户、设置、帮助。
3. **花植黄门背景能看见。** Mux 线上视频在这台云电脑会返回 HTTP 403 `not_authorized`，所以默认走本地 `/subway-jungle.mp4` 和分镜静帧。只有加 `?hls=1` 才去探测 Mux。不要改设计原图或 `source/` 里的 gif／封面。
4. **四种状态、一句话说明、主按钮、四项数字**已嵌在主界面里。切态目前主要靠网页参数 `?state=`。按钮会打占位 API，但只记 dry-run，不会真启动。
5. **硬闸门开着且关不掉：** `COPY_BLOCKS_LIVE_ACTIONS = True`，写在 `client/bridge.py`。启动／继续、暂停、登录都是 `executed=false`，`spawned_process=false`。日志在 `client/copy-dry-run/blocked-actions.jsonl`。
6. **登录口径已写好，但只记不执行：** 打开普通抖音页 `https://www.douyin.com/jingxuan`，对上已有 Bridge 通道名称（本副本不得真连）：
   `node CI\strict-bridge-server.cjs --serve --config "R\\抖音自用采集台\\data\\bridge.json" --port 19422 --allow-owned-19422`
   以及 `collection_refresh_page.cjs`、`collection_identity_check.cjs`。不要打开 `creator.douyin.com`，不要开独立 Edge 档案，路径带「抖音自用采集台/data/bridge.json」的请求要直接拒绝且不读文件。
7. **门店只记一次：** 默认「上海联航路云涛公寓」，凭证 `fy_s_5d7de1ce644eabc4386eab0e`。日常主界面不提供「切换门店」。
8. **2026-11-14 23:20 按方隅要求改了两处并重截，方隅已确认并发给用户：**
   - 四态主页时，药丸当前项必须是「主页」（浅色选中）。客户／设置／帮助是黑底白字，不能看起来像「帮助」被选中。
   - 右下角「演示数字」小字已从成品预览拿掉。运行中／需要你处理／已安全暂停用演示数字 86、54、32±、1286 可以，和设计稿一致；待开始用「—」也对。真实缺数时四个都要能显示「—」，不要写成 0。
9. 客户／设置／帮助点开后目前只是占位说明，还没有按 05–08 设计图做成玻璃面板。登录页也还没做。

成品预览这四张（不要用英文官网旧图）：

- `/workspace/fangyu-opendoor-replica/shots/b09-idle.png`
- `/workspace/fangyu-opendoor-replica/shots/b09-running.png`
- `/workspace/fangyu-opendoor-replica/shots/b09-need.png`
- `/workspace/fangyu-opendoor-replica/shots/b09-paused.png`

旧的 `shots/client-idle.png`、`client-mid.png`、`client-glass.png`、`client-window.png` 仍是英文官网版，**不要当成品**。

---

## 还没做完什么

按优先级，先等用户看完主界面，不要抢着交差：

1. **先不要嵌**客户列表、设置、帮助、登录（设计图已在 batch-09 的 05–08）。等方隅或用户说可以再按图做。登录主按钮将来是「打开抖音页」，只走普通抖音，成功后不要自动开始采集。侧栏是点开才出现，不要把列表铺在主画面上。
2. 尚未在用户电脑上真连已有 Bridge，也没有在原来的采集浏览器里真正打开／刷新 jingxuan。这是预期，未接到明确允许前不要做。
3. 占位 API 的 `/api/state` 仍默认停在「待开始」。按钮动作不会改 API 状态，界面切态靠 `?state=`。以后若要把按钮和真实状态接通，仍然必须先走硬闸门，本副本不得真启动采集或发送。
4. 真实统计数字还算不出来。今日采集、今日回复、累计、有效池加减，在没有已确认的「入池时间／发出时间」字段之前，继续用「—」。不要用 `published_at`、`observed_at`、`created`、`review_time`、`sends.updated` 等禁列去切片，也不要推断「累计采集减累计回复」。不要把客户数据（分类交接、可见池 jsonl、共享账本、生产库）拷到云电脑。
5. `windows_preview_draft.py` 还没在 Windows 上跑，也绝不能拿去替换用户本机正在用的安装。
6. 旧副本里的 `verify_direct.py`、`package_handoff.py` 还有旧名称／「切换门店」等过时表述，不是当前任务。
7. 悬浮窗若还要用，要按同一套气质另做，仍保持小窗、不写产品名。还没开工。

---

## 已知坑

- 这台云电脑请求 Mux 地址 `https://stream.mux.com/43NlHXsaMrmyzWamMk87m01fNyxSTekAD669BBAPBNm00.m3u8` 会 403。背景必须有本地兜底，否则首屏可能一直 Loading 或黑屏。
- 截四态时，鼠标如果停在导航上，「帮助」容易看起来像被选中。`open_preview.py` 截图前会把鼠标移开导航。改完请用无头截图核对四张，确认当前项都是「主页」，右下角没有「演示数字」。
- 可见预览窗口有时会叠开两个同名窗口，右上角可能冒出 Google 翻译条。无头四态图没有这个问题。
- 镜头位置接近设计图，但和设计静帧不是逐像素同一帧。背景用的是本地 mp4 + 分镜静帧，不是 `opendoor.gif`。
- Vite 开发服可能绑在 `0.0.0.0:5173`。启动器若发现已经在跑就复用；如果要自己起，只绑 `127.0.0.1`。
- 云电脑和用户本机不是同一台，文件不自动共用。不要以为改了云电脑副本，本机安装就会变。

---

## 不要动什么（硬限制）

- **不要改用户本机正在用的安装。** 本机目录是 `C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261114`，桌面快捷方式仍是 `C:\Users\rmsama\Desktop\方隅工作台（新版试用）.lnk`。不要替换它，也不要用新快捷方式覆盖正在用的那一个。
- **不要开采集或发送。** 不要启动、停止或重连现场 Bridge，不要拉起 node 去连 19422，不要读现场 `bridge.json`、cookie、密码或登录态。
- 不要查询或拷贝大约 10GB 的 `collection.sqlite3`，不要拷生产库或客户 jsonl。
- 不要在用户两台电脑的前台抢屏幕或打断正在用的程序。可以在云电脑上做封装和预览。
- 不要把密钥、账本、登录态写进文档、仓库或聊天。
- 不要自己对接或操作官方 Codex 窗口。以前那些对口规则已作废。需要时由用户手动复制。
- 用户没点头的新功能不要私自做。先用大白话问，同意了再做。
- 技术工作优先用现成的 skill、开源项目或开源软件，不要从零手搭；找不到再用自己的办法，并先说明。

---

## 写程序时还要遵守的约定

- 对用户说话用大白话，少堆术语。方隅相关结果通常先回「方隅项目负责人」，由对方按节奏转告用户；用户常常在那边的窗口等候，不在本窗口。
- 用户 2026-11-14 约 23:06 说：慢慢来，不要着急，按流程一步一步把东西做好。可以开多个窗口一起干，但仍按流程来，**不要抢着交差**。主界面没看稳之前，不要把半成品或英文落地页、黑背景预览发给用户当成品。
- 四态文案和按钮：待开始／已安全暂停用「启动／继续」（中间是全角斜杠）；运行中用「暂停」；需要你处理用「知道了」，只确认提示，不在软件里完成验证码，验证要到原来的网页里做。
- 数字缺省一律「—」，不要写 0，不要靠推算定。
- 本副本的启动／暂停／登录先硬闸门，闸门不能关。

---

## 环境和备份（供对照，不是让你去改备份系统）

- 用户本机 Windows 电脑名称 RMSAMA。
- 助手还有一台 24 小时开机的云电脑，和本机文件不自动共用。当前工程在云电脑 `/workspace/`。
- 云端产出备份在用户本机 `C:\Users\rmsama\Documents\AI-Backup\`，总入口是该目录下的 `00-START-HERE.md`。不要备份密钥、账本、登录态。

---

## 下一步建议（等用户或方隅开口后再做）

用户正在看主界面四张图。下一步默认是：等方隅转达「可以按 05–08 做客户／设置／帮助／登录」之后，再按设计图把玻璃面板嵌进去；登录只走普通抖音页和已有 Bridge 名称，成功后不自动采集，硬闸门保持，仍不改本机安装。在此之前不要自行开工下一批。
