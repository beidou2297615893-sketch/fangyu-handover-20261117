# 每日百题／知题 APP 交接给 Grok Build

时间：2026-11-15 00:58（北京时间，Asia/Shanghai）
写文档的窗口：新软件负责人（接手原「答题软件负责人」）
这份文档是给一个没看过我们聊天的编程工具看的。读完应能接着干，不必再翻旧对话。

更细的原文和截图仍在下面列出的路径里。本文件是浓缩，不替代实测报告。

---

## 1. 项目是什么

这是用户的安卓应用「知题」（对外也可叫「每日百题」）。目标是：在真实考试类页面上，自动认出题目、对照已导入的题库选出答案、点「确认答案」、翻到下一题。软件必须通用，出了问题只改软件本身，绝不能改测试页来迁就它。

当前测试页是「微信百题验证」，包名 `com.jimusoft.railwaymp`，题库同一套 1,859 道铁路题。不要改这个测试宿主。

知题自己的包名是 `com.jimusoft.dailyhundredapp`。源码里不少类还留着旧包名前缀 `com.futureyyy.tijing`（例如支付和会话相关代码），这是历史遗留，不要误当成要改回官方提镜包。

2026-11-14 对照过三个现成安装包后，底座仍然用**知题现有工程**，不要改用官方提镜包，也不要拿 AI答题改包：

| 软件 | 版本 | 包名 | 结论 |
| --- | --- | --- | --- |
| 官方提镜 | 0.7.7 | `com.futureyyy.tijing` | 题库模式被锁成只展示答案，自动点击还要 API Key，不能当底座 |
| AI答题 | 7.7.7 | `com.dsh.aianswer` | 能查库，但点选项不可靠，答完只找「下一题」，不认「确认答案」；许可也不清，不能当商用底座 |
| 知题 | 从 0.4.20 改到现在 | `com.jimusoft.dailyhundredapp` | 浮窗路径「选中 → 确认答案 → 真翻页」能打通；后来主要卡在启动同步、交互约定，以及云端建立答题会话失败 |

---

## 2. 文件在哪

能在用户电脑完成的改动、打包、测试，优先在用户电脑做，不要先把大文件绕到云电脑。用户本机名称是 RMSAMA。优先用 `C:\` 路径，不要走 `V:` 拷贝（`V:` 只是同一份源码的映射盘）。

### 用户电脑（主战场）

- 源码树：`C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\original-vs-0419\release-mobile`（等同 `V:\work\original-vs-0419\release-mobile`）
- 当前未发布的正式签名包：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\zhiti-0.4.24-resume.apk`
  - 大小：6,601,519 字节
  - SHA-256：`0D12BCA04AA088BCB8CA94B6539480F3CB1E56E791B9870AB672A6CECEA4C533`
- 正式打包脚本：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\build-0424-official.cmd`
- 0.4.24 实测材料（准备交给分析用的副本）：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\attach-0424\`（含 REPORT-0424.md、logcat、05/06 截图）
- 发送脚本（如仍需把材料附到某个桌面对话，必须用）：`C:\Users\rmsama\AppData\Local\Temp\zt0423-gpt-pack\attach-0424.ps1`（必须 `powershell -STA`）
- 官方提镜 0.7.7 原版包：`C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work\fullflow-alternatives\three-apk-baselines\TiJing-official-0.7.7.apk`
  - 大小：960,780 字节
  - SHA-256：`3F4988B2FE4C5EAAB22C4E604468C9C99114A0CE3B522611601B2B9A0FCFF20F`
  - 同目录还有 `AIanswer-v7.7.7.apk`、`Zhiti-0.4.20-candidate.apk`
- adb：`V:\work\tools\android-sdk\platform-tools\adb.exe -P 5037 -s emulator-5556`
- 开发文档汇总的电脑副本：`C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\知题-三软件对照至0.4.24-开发文档汇总.md`

0.4.24 实际改过的源码文件：

- `android\app\src\main\java\com\futureyyy\tijing\payment\AndroidPayment.kt`
- 版本号在 `android\app\build.gradle.kts`（versionCode 91，versionName 0.4.24）

### 云电脑证据（只读参考，不要当工作副本去改）

- 给新窗口的短交接：`/workspace/zt045/交接-给新软件负责人.md`
- 更详细接手说明：`/workspace/zt045/fix-0423/HANDOFF-NOW.md`
- 开发文档汇总：`/workspace/zt045/知题-三软件对照至0.4.24-开发文档汇总.md`
- 0.4.24 实测：`/workspace/zt045/fix-0423/emu-test-0424/`（含 `REPORT-0424.md`、`logcat-dump-after-wait.txt`、截图 `05-after-start.png` / `06-after-wait.png`）
- 0.4.24 已应用源码和备份：`/workspace/zt045/fix-0423/src-0424/`、`/workspace/zt045/fix-0423/backup-0424/`
- 只读源码摘录（含 FreeService.kt）：`/workspace/zt045/fix-0423/readonly-src/`
- 上一轮桌面 ChatGPT 批复全文：`/workspace/zt045/fix-0423/gpt-latest-reply.txt`
- 0.4.23 界面报告：`/workspace/zt045/fix-0423/emu-test/REPORT-0423.md`
- 0.4.23 诊断日志：`/workspace/zt045/fix-0423/emu-test-diag/REPORT-DIAG.md`
- 0.4.23 只读快照：`/workspace/zt045/fix-0423/emu-test-readonly/REPORT-SNAPSHOT.md`
- 0.4.22 实测与当时 503 分析：`/workspace/zt045/fix-until-clean/REPORT.md`、`SESSION-CAUSE.md`
- 三软件交叉比对（失败根因最完整）：`/workspace/zt045/交叉比对-失败根因.md`
- 其余对照：`/workspace/zt045/evidence/three-apk-compare/`、`/workspace/zt045/compare-aianswer.md`、`/workspace/zt045/rea-compare/REA交叉比对结论.md`
- 公开资料初筛（只做资料核对，没有拿来换底座）：`/workspace/zt045/现成软件与替代底座初筛.md`

方隅和其他项目的文件不要动、不要混进本项目。更早的 0.3.x 历史安装包还留着，不要当垃圾删。

---

## 3. 现在停在哪一步

截至 2026-11-15 00:26 交接时（此后新窗口未再改代码、未再点模拟器、未发布）：

- 手机现网仍是正式签名 **知题 0.4.22**（versionCode 89，蒲公英 build 41）：https://www.pgyer.com/meiribaiti
  - 现网包 SHA-256：`0DD2AC8F793F77C83697453034A9942185EF58D6DA23AD77D058EE9A1FDA3A45`
- 模拟器 `emulator-5556`（adb 端口 `-P 5037`）上已覆盖安装正式签名 **0.4.24**（versionCode 91），**还没有发到蒲公英**。
  - 测试当时进程 PID 12889。覆盖安装后 `firstInstallTime` 仍是 2026-11-14 06:15:40（模拟器时钟，等于当天 14:15:40 北京时间）。
  - 题库 1,859 题还在。
- 0.4.24 按当时批准的方案，只改了一件事：已经确认过的免费任务，改走 `/free/resume`，不再重复 `confirm`。
- 实测结果：`/free/resume` 成功（北京时间 00:00:30），随后建立模型会话的 `/session` 在 00:00:49 返回 **HTTP 503**，`error=session_unavailable`，`requestId=35a07f96-11de-49aa-8730-64159cbfc71c`。
- 第一题还没有真正进入识别、点选和确认。
- 界面停在：「答题已暂停：本轮答题授权暂未确认，请保留本次任务，稍后重试。」出现「重试」「继续」「停止」。
- 测试页仍是 53/100。选项 D 是更早一次误点选中的，当时并没有按「确认答案」。不要把这次选中当成软件自己答的，也不要去按宿主的「确认答案」。

同一笔免费任务快照（不要重置，不要清账）：

- 短号 / id：`c20263ab1326`
- 对象：`com.jimusoft.railwaymp`
- `source=free`，`phase=confirmed`，`submission=none`
- `savedRunMatches=true`，`tokenPresent=true`，`expiresValid=false`
- 0.4.24 选路结果：`freshAllowed=false`（不允许再新开任务）
- 发起 `/session` 前的预检：`authSource=free`，`bindingPresent=true`，`deviceDigestPresent=true`

关键日志原文（模拟器 logcat 是 UTC，下面注释为北京时间）：

```
11-14 15:59:15.533 I ZhitiSession: local-snapshot id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true source=free phase=confirmed submission=none savedState=active savedRunMatches=true tokenPresent=true expiresValid=false
11-14 16:00:20.259 I ZhitiSession: run-selection id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true phase=confirmed submission=none savedState= freshAllowed=false
11-14 16:00:20.268 I ZhitiSession: gateway-auth stage=start-enter
11-14 16:00:20.274 I ZhitiSession: gateway-auth stage=run-start-complete source=free phase=confirmed
11-14 16:00:20.275 I ZhitiSession: gateway-auth stage=confirmation-complete source=free phase=confirmed
11-14 16:00:20.285 I ZhitiSession: free-auth operation=resume phase=confirmed
11-14 16:00:30.055 I ZhitiSession: free-auth operation=resume result=ok
11-14 16:00:30.055 I ZhitiSession: gateway-auth stage=authorization-ready source=free state=confirmed
11-14 16:00:30.056 I ZhitiSession: exchange-preflight id=c20263ab1326 target=com.jimusoft.railwaymp ledgerFound=true phase=confirmed submission=none authSource=free bindingPresent=true deviceDigestPresent=true
11-14 16:00:49.048 I ZhitiSession: http=503 error=session_unavailable requestId=35a07f96-11de-49aa-8730-64159cbfc71c
11-14 16:00:49.049 W TiJingRunner: gateway-session-begin-failed
```

对应北京时间：00:00:20 开始授权并发出 `/free/resume`；00:00:30 resume 成功并出现 `authorization-ready`，随即发起 `/session`；00:00:49 `/session` 返回 503。

失败发生在 `/session`，不是 DNS 超时，也不是 `/free/resume` 失败。日志里没有 `ZhitiBilling` 的 `network-failure` 或 `http-failure`。随后客户端抛出：`java.lang.IllegalStateException: 答题授权暂未确认，请保留本次任务重试；如需新一轮，请明确结束本轮后重新开始。` 堆栈经过 `GatewaySessionEntry` 和 `AndroidPayment.kt` 的 `PaymentRuntime`。

这就是当时方案里说的「结果 D」：免费授权能续上，但模型会话仍被服务端判为不可用。

---

## 4. 已经做好、必须保留的

- 底座用知题现有工程，不改用官方提镜包或 AI答题包。
- 支持多种题目文件导入（JSON、Excel 等）。覆盖安装后 1,859 题还在。
- 已去掉本机文字识别模型，包体回到约 6.3 MB，走提镜原有「读屏幕文字」路径，不要再加视觉模型或本机识别模型。
- 点首页「一键答题」不会立刻开始识别；先进入状态页，再授权录屏，然后出现左侧「知」图标。
- 点「知」图标只展开悬浮窗，必须再点窗内「开始答题」才会开跑。这条已经修好，不要改回去。
- 「知」图标已改到左下角，展开面板贴在底部，不再挡住题干、选项和「确认答案」（0.4.23 已验证）。
- 暂停后的「重试」「继续」能点中，并且会立即回到「识别中 / 正在核对本轮答题权限」（0.4.22 已验证；0.4.23 保持中文提示）。
- 授权失败时不再把 `Connection reset`、DNS 等英文原文铺到用户界面（0.4.23 已验证）。
- 免费任务的只读状态，以及已确认任务走 `resume` 的路径，已经按方案做完，并且 `resume` 本身是成功的。

---

## 5. 还没做完什么

主阻塞只有一件：**建立模型会话时，云端 `/session` 返回 503 `session_unavailable`，第一题进不了识别和点击。**

已经能确定的：

- 不是安装失败，也不是题库丢了。
- 不是「请求没发出」。0.4.22 时客户端已经走过本地授权核对，再 POST `/session` 才得到 503。0.4.24 里则是 `resume` 成功后再 POST `/session` 得到 503。
- 用假凭据探测过线上入口：入口是活的，但对无效凭据本来就会返回 503。**不能**用这个证明真会话也一定失败，也不能用这个证明服务端完全正常。
- 本窗口没有 CloudBase 控制台权限，无法代查这些服务端记录：
  - 2026-11-14 20:57:41、21:04:51、22:40:51 的旧 503
  - 这次 `requestId=35a07f96-11de-49aa-8730-64159cbfc71c`（2026-11-15 00:00:49）

因此：0.4.24 只证明了「免费授权可以续上，但模型会话仍被服务端判为不可用」。下一步怎么处理，必须先得到用户明确指示，再改代码或再点模拟器。不要自己另想一套去改授权、计费或云函数。

另外还没有验收、不能宣称已经好的：

- 完整 100 题连跑
- 暂停后恢复再跑
- 多选题、判断题
- 更早 0.4.14 出现过的假翻页、灰色确认键仍上滑（0.4.20 源码里还在，3 题短跑没碰到，不能说已经修好）
- 真实手机支付全流程（本轮模拟器用的是已确认的免费任务，没有让用户再付款）

在第一题真正进入识别、点选、确认，并且用户明确同意之前，不要把 0.4.23 或 0.4.24 发到蒲公英。

---

## 6. 版本沿革（只保留对接着干有用的）

| 版本 | 大约时间 | 蒲公英 | 改了什么 | 结果 |
| --- | --- | --- | --- | --- |
| 0.4.20 候选 / 87 | 11-14 下午短测 | 未作为后来的标准包保留，当时约 79 MB，带本机识别模型 | 三包对照用 | 浮窗开始后 3 题全对；应用内开始和浮窗不同步 |
| 0.4.20 start-sync | 11-14 16:14 | 短链出现过 build 39，约 139.3 MB | 为修启动同步一度打进本机文字识别，包体暴涨 | 用户明确要求去掉识别模型 |
| **0.4.21 / 88** | 11-14 17:06 | 已发布，build 40，约 6.3 MB | 去掉本机识别模型，改回读屏幕文字路径 | 用户手机覆盖安装后反馈：一点「一键答题」就立刻识别；识别失败后「重试」「继续」按了没反应 |
| **0.4.22 / 89** | 11-14 20:01 | **现网正式包，build 41，6,599,055 字节** | 点「一键答题」不再立刻识别，须先点「知」展开再点「开始答题」；暂停后「重试」「继续」要立即有反馈 | 模拟器上这两条操作约定已通过。但一点「开始答题」就卡在「正在核对本轮答题权限」，两次 `/session` 返回 503。第一题没有进入作答 |
| 0.4.23 / 90（三轮，均未发布） | 11-14 晚 | 未发布 | 先把「知」改到左下、面板贴底，暂停改成短中文，不再把英文异常直接显示给用户；后来只加诊断/只读状态日志，不改授权和计费 | 界面和中文提示通过。只读快照已证明同一笔免费任务已是 `source=free`、`phase=confirmed`，本地凭证在但已过期。仍未进入第一题识别 |
| **0.4.24 / 91** | 11-14 23:54 装上，11-15 00:00 测 | **未发布** | 只改 `AndroidPayment.kt`：已确认的免费任务改用 `resume`；并加阶段日志、区分网络失败和 HTTP 失败 | `resume` 成功，随后 `/session` 仍是 503。符合「结果 D」。第一题仍未真正识别 |

正式签名证书 SHA-256 一直是 `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`。证书显示名仍是 `CN=Android Debug`，**不要改证书**。正式签名只在用户电脑做。不要把调试包发到正式短链。

---

## 7. 已知坑

- **当前最大坑：`/session` 503。** 不要把它误诊成安装失败、题库丢失、DNS 超时或 resume 失败。也不要用「假凭据探测也返回 503」来单方面定责。
- 本地凭证 `expiresValid=false`（已过期），同时 `freshAllowed=false`（不能新开任务）。`resume` 已经成功，所以「过期」不是本次失败的表面原因；它仍可能和服务端判定会话不可用有关，不要在没查清前擅自清账或重开任务。
- 覆盖安装后，系统可能会关掉无障碍权限。要用设置恢复，不要靠卸载或清数据来「修好」。
- 点收起的「知」图标必须先展开，不能立刻开跑；图标不能压在选项或题干上。这两条已经修过。
- 应用内「一键答题 / 开始答题」和浮窗里的「开始答题」曾经不同步。不要再把应用内按钮直接触发识别。
- 测试页上的按钮写的是「确认答案」，不是「下一题」。以前 AI答题就是栽在只找「下一题」。
- 更早的假翻页、灰色确认键仍上滑，还不能宣称已修好。
- 选项 D 当前是误点留下的，不要当成自动答题结果，也不要去按宿主「确认答案」。
- 不要真实扣费。本轮用的是已确认的免费任务。
- 云电脑和用户本机不是同一台，两边文件不自动共用。改代码、打包、签正式名，以用户电脑源码树为准。
- 以前和官方 Codex 自动对接、以及「发现问题就自己去问桌面 ChatGPT 并只执行它的方案」那套循环，用户已要求停止。不要自己进入或操作 Codex 窗口，也不要自己去问桌面 ChatGPT。需要时只能请用户本人复制或亲自去问。等用户指示再改代码、再点模拟器、再发布。

---

## 8. 绝对不要动什么

动手前先记住这些硬规则：

1. 只覆盖安装，不要卸载，不要清理数据，不要重置这笔任务（`c20263ab1326`），不要清账。
2. 先不要点界面上的「重试 / 继续 / 停止 / 确认答案 / 开始答题」，除非用户明确要求。
3. 不要改铁路测试页「微信百题验证」`com.jimusoft.railwaymp`。
4. 未经用户明确同意，不要把 0.4.23、0.4.24 或任何调试包发到蒲公英（https://www.pgyer.com/meiribaiti）。
5. 不要再加视觉模型或本机文字识别模型。
6. 不要改正式签名证书。
7. 不要改提镜上游树，不要拿 AI答题改包，也不要把知题改回官方那种「只展示答案」的题库模式。
8. 保持本项目独立，不要把方隅或其他软件的文件混进来。
9. 优先复用已有方案，不要擅自推倒重写点击、题库或支付。
10. 不要在聊天、文档或仓库里写密钥、密码、账本或登录态。

---

## 9. 建议的下一步（仍须先得到用户同意）

1. 先保持模拟器现场，不要点那些按钮，也不要重置任务。
2. 若要继续查 503：需要有 CloudBase 或等价服务端权限的人，去查 `requestId=35a07f96-11de-49aa-8730-64159cbfc71c` 以及 11-14 晚上那几次 503 的服务端记录。本窗口没有这个权限。
3. 在用户同意之前，不要自己改授权逻辑、计费或云函数，也不要发布。
4. 只有当第一题真正完成「识别 → 点选 → 确认」，并且用户明确点头后，才考虑把新包发到蒲公英，而且必须覆盖安装，不要让用户卸载重装。
5. 之后才做 100 题连跑，以及暂停恢复、多选/判断、假翻页回归。

操作环境提示：用户本机是 Windows。模拟器命令形态是 `adb.exe -P 5037 -s emulator-5556`。若无障碍被覆盖安装清掉，用 `settings put` 恢复，不要清数据。
