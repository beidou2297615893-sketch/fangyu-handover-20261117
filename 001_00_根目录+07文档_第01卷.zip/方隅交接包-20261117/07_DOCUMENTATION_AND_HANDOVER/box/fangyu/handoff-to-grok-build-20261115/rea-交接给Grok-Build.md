# rea 窗口交接给 Grok Build

这份文档是给 Grok Build 看的。写文档的窗口叫「rea」，从 2026-11-10 起负责：把用户指定的两套开源工具装好，以后按用户要求配合使用。到写本文时（2026-11-15），还没有对任何一个具体软件做过逆向或仿制，只完成了下载和安装。

换一个没看过原聊天的编程工具，应能凭这份文档接着用这两套工具干活，不必再从对话里翻安装过程。

## 这个窗口在做什么

用户要的是两套工具一起用，不是只装其中一套：

1. **REA**（Reverse Engineer Anything）：逆向工程工具。官方仓库 [morluto/rea](https://github.com/morluto/rea)，网站 [rea.tools](https://rea.tools/)，npm 包名 `rea-agents`。用来搞清楚一个程序、应用或运行时行为是怎么工作的。
2. **Replica Skill**：11 个技能，按「 recon → 设计/架构 → 搭建 → 对比」把应用的功能和流程干净地仿出来，再用 `replica-diff` 给仿制品和原版打分。官方仓库 [Jakeschincariol/replica-skill](https://github.com/Jakeschincariol/replica-skill)。它仿的是功能和流程，不抄原版的代码、logo、文案或内容。

用户原话是这两个「配合着用」。典型用法：先用 REA 把目标看懂，再用 Replica 做出一份对照版，并用 `replica-diff` 看像不像。

另外还下过一个轻量替代 **leanrea**（[aicodeking/leanrea](https://github.com/aicodeking/leanrea)，一份约 8 KB 的 `SKILL.md`，不装 MCP）。这是搜索过程中找到的对照方案，用户没有把它定为主方案，不要默认改用 leanrea 替换 REA。

## 文件在哪

### 云电脑（助手共用的那台 Linux 机器）

2026-11-15 已当场核对，这些路径还在：

| 内容 | 路径 | 说明 |
|---|---|---|
| REA 命令行 | `/home/box/.local/bin/rea` 和 `/home/box/.local/bin/rea-agents` | 全局安装的 `rea-agents@6.8.0`，当前 `rea --version` 为 6.8.0 |
| REA 软件包目录 | `/home/box/.local/lib/node_modules/rea-agents/` | 自带技能在 `skills/reverse-engineer-anything/SKILL.md` |
| Replica 技能（本窗口安装的一份） | `/workspace/tools/replica-skill/` | 内含 11 个 `replica-*` 文件夹，各有一份 `SKILL.md` |
| 源码克隆和压缩包 | `/workspace/dl/` | 见下表 |

`/workspace/dl/` 里有：

- `rea/` 和 `rea.zip`（约 27 MB，压缩包不含 `.git`；文件夹里有 git）。克隆自 `https://github.com/morluto/rea.git`，当时提交 `b2f3dc8`（2026-11-10，说明：`fix(cli): reject invalid JavaScript application paths`）。
- `replica-skill/` 和 `replica-skill.zip`。克隆自 `https://github.com/Jakeschincariol/replica-skill.git`，当时提交 `77c9436`（2026-10-03，v1.0）。
- `leanrea/` 和 `leanrea.zip`。克隆自 `https://github.com/aicodeking/leanrea.git`，当时提交 `09ba4aa`。技能文件在 `/workspace/dl/leanrea/leanrea/SKILL.md`。
- `ida-pro-mcp/`、`ida-pro-mcp.zip`、`reverse-skill/`、`reverse-skill.zip`：**早期听错下错的，不是用户要的工具。** 不要拿来继续这个任务。

云电脑当前 Node 是 v24.22.1，满足 REA 的要求（需要 Node `^22.23.4` 或 `^24.22.1` 或 `>=26.12.1`）。云电脑上没有给 Codex 配 REA 的 MCP；这边能直接跑的是命令行 `rea`。

同目录还能看到 `/home/box/shared-skills/from-codex/` 里也有 `reverse-engineer-anything` 和若干 `replica-*`，那是共享技能目录里的副本，不是本窗口的主安装位置。本窗口以 `/home/box/.local/bin/rea` 和 `/workspace/tools/replica-skill/` 为准。

### 用户自己的 Windows 电脑（名称 RMSAMA）

以下是 2026-11-11 凌晨安装结束时的状态。写本文时没有再登录这台电脑复查，接手后如果要在本机干活，请先核对一遍是否还在。

- 压缩包曾复制到：`C:\Users\rmsama\Downloads\`（`rea.zip`、`replica-skill.zip`、`leanrea.zip`，以及那两个下错的包）。
- Replica 的 11 个技能装到了：`C:\Users\rmsama\.codex\skills\replica-*`。
- REA 技能装到了：`C:\Users\rmsama\.agents\skills\reverse-engineer-anything\SKILL.md`。
- 在 `C:\Users\rmsama\.codex\config.toml` 里加了 `[mcp_servers.rea]`（大约在第 260 行附近），参数为：`[ "/d", "/c", "npx", "-y", "rea-agents@6.8.0", "mcp" ]`（由 `cmd.exe` 调用）。改之前的备份在：`C:\Users\rmsama\.codex\config.toml.rea.backup`。
- 为满足 REA 的 Node 版本要求，当时把本机 Node 从 **24.15.0 升到了 24.22.1**，安装位置仍是 `C:\Program Files\nodejs`。

安装后本窗口没有重启 Codex。当时的说法是：用户新开一个 Codex 对话，或重启 Codex，才能加载刚装上的 REA 和 Replica。这一步有没有做过，本窗口没有确认。

## 已经做完什么

- 确认用户要的就是 GitHub 上较热门的 REA（`morluto/rea`），以及能「一边搞清楚、一边做出对照版并对比」的 Replica Skill，不是早期误下的 IDA / reverse-skill。
- 两套工具已在云电脑和用户电脑两边都装好（云电脑侧 2026-11-15 仍可用）。
- 用户明确同意「两边都装」，并同意「现在就升级」本机 Node。
- 用户希望以后把这两套工具配合使用。

## 还没做完什么

- **还没有对任何具体目标做过逆向或仿制。** 没有样例分析结果，也没有 Replica 的对照成品。
- 两边都没有配置可选的原生分析引擎（Ghidra、IDA、JADX、Kuna 等）。没有它们时，JavaScript、Electron、.NET 这类分析仍可用；要做更深的原生二进制分析，需要另行安装和配置，且须先问用户。
- 没有把这两套工具接到 Grok Build 自己的技能或 MCP 配置里。当时是为 Codex 装的。若 Grok Build 要直接调用，可能还要按 Grok Build 的方式接一次，不要盲目改 Codex 的配置。
- 用户电脑上 Codex 是否已经重新加载这些技能，未经确认。
- 升级 Node 时，本机大约 20 个原先在跑的系统 `node.exe` 进程停掉了，当时只剩 1 个。Codex 自己的进程当时没受影响。本窗口曾问用户：要不要通知「抖音链路」和「小红书链路」去检查并重新拉起采集/发送程序。**用户没有在本窗口答复，这件事仍未处理。** 不要擅自再升级 Node，也不要在未确认的情况下重启那些业务程序。

## 已知坑

- 用户一开始说的「IEA」其实是 **REA**。不要再去找 IEA，也不要重新去下 IDA Pro MCP 或 reverse-skill。
- REA 对 Node 版本很挑。版本不够时，安装程序会停下来等人升级。用户电脑上升级 24.15.0 → 24.22.1 时，杀掉了一批正在跑的 Node 程序，可能包括抖音、小红书相关进程。以后改 Node 前必须先跟用户说清楚这个风险。
- 向用户电脑拷大文件时，机器有时会短暂连不上（当时报过 `RMSAMA temporarily unreachable`），重试可以成功。`rea.zip` 约 27–28 MB，超过聊天附件 25 MB 限制，但用文件拷贝可以过去。
- 云电脑当时没有系统自带的 `zip` 命令，打包是用 Python 做的。
- Replica 是干净室仿制：只重建功能和流程，不复制人家拥有的代码、品牌和内容。技能自己也会守这条，不要绕开。
- `/workspace/zt045/` 下也能看到名为 `rea-engine`、`rea-compare`、`rea-skill` 的目录。那是「每日百题 / 知题」那边的东西，**不是本窗口的工作**，不要当成这份交接的一部分去改。

## 不要动什么

- 不要删、不要整份重写用户电脑上的 `C:\Users\rmsama\.codex\config.toml`。本窗口只追加了 REA 这一段；改坏了可以用旁边的 `config.toml.rea.backup` 对照，但不要未经询问就覆盖回去。
- 不要影响用户电脑前台正在跑的采集、发送或其他程序，也不要擅自改代理或网络设置。
- 不要把密钥、密码、账本、登录态写进文档或仓库，也不要在聊天里明文展示。
- 用户没点名要做的新功能或新做法，先用大白话问用户，同意了再做。
- 技术工作优先用现成的 skill、开源项目或开源软件，不要从零另做一套。本任务已经选定 REA + Replica，接着用即可，不必再换一套同类工具，除非用户另有明确要求。
- 以前和官方 Codex 自动对接的规则已经作废。不要自己进入或操作 Codex 窗口；需要时由用户手动复制过去。
- 不要建议用户删除这个窗口：删除窗口会把助手一起删掉。编程细节以这份文档为准即可。

## 接着怎么干

如果用户让你逆向或仿制某个具体软件：

1. 先确认目标、权限边界（只用公开页面、截图、用户自己的账号和用户明确提供的文件）。
2. 优先用已经装好的 REA 和 Replica，不要重新从零安装。
3. 在云电脑上可以直接跑 `rea`；Replica 技能从 `/workspace/tools/replica-skill/` 加载。
4. 若要在用户本机或 Grok Build 里调用，先检查本机 Node 仍是 24.22.1、Codex/Grok Build 的技能和 MCP 配置是否还在，缺了再补，不要重复升级 Node。
5. 开工前，若这是可以用简单复制粘贴交给用户网页端 Muse 做、从而省 token 的工作，按用户 2026-11-14 的规则提醒或询问用户要不要先让 Muse 做；不要打断已经在进行的进度，效率和质量优先。

同目录里还有其他窗口写给 Grok Build 的交接文档。那些窗口各自的项目（方隅、知题等）不归本窗口管。
