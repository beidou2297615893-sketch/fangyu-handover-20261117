# 抖音链路交接给 Grok Build

这份文档是给 Grok Build（或任何没看过我们聊天的编程工具）接手用的。写于 2026-11-15，北京时间约 00:58。现场状态以当天 00:40 核对为准。时区一律按 Asia/Shanghai（北京时间）。

本窗口是「抖音链路」：只负责用户电脑上已经跑通的抖音本地链路（采集 → 筛选 → 母句匹配 → 草稿 → 发送）。不负责小红书，也不负责把这些程序收进最终软件界面（那是「技术 / 软件集成」的事）。

不要把密钥、密码、Cookie、登录态、账本库文件写进仓库或聊天。下面出现的账号名和 uid 只是运行身份标识，不是登录凭据。

---

## 1. 项目是什么

用户在做「方隅公寓自动获客系统」。抖音这一侧已经有一套本地程序：按关键词采集评论，按业务规则筛选，配好回复，再发回评论区。

现场一直在用户自己的 Windows 电脑上跑，电脑名 RMSAMA，机器编号 `f79a5338-7ab9-41e1-bad0-3f5c3b1dd392`。这台电脑有时会短暂连不上，短命令再试一次即可，不要因此另开一路或改程序。

助手另有一台云电脑（本文件所在的环境），和用户本机不是同一台，两边文件不自动共用。改用户本机上的程序前，先分清你改的是哪一台。工程调查或改仓库代码，按 code-changes 交给云端，不要自行克隆仓库。

---

## 2. 文件在哪

用户本机根目录记为 `R`：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统`

| 简称 | 完整路径 | 做什么 |
|------|----------|--------|
| R | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统` | 本机总根。启动发送时工作目录用这里 |
| F 或 CI | `R\work\fangyu-douyin-independent` | 采集程序和采集进度窗 |
| C | `R\work\douyin-local-control` | 发送控制、进度面板 |
| TEXT | `R\work\fangyu-text-business-20261029` | 筛选、排序、出队、母句 |
| 共享账本 | `R\work\shared-acquisition-ledger\shared.sqlite3` | 去重、已回复/未知等，只定位，不要清、不要备份进仓库 |
| 旧回执库 | `R\Codex获客工作台\work\reply_receipts.sqlite3` | 历史发送回执，同样不要清 |
| 采集库 | `F\runtime\collection.sqlite3` | 约 10GB，不要对它做沉重查询 |
| 每日优先分类 | `TEXT\recency-priority\daily-priority\` | 出队时用的分类快照 |
| Python | `C:\Users\rmsama\miniconda3\python.exe` 和 `pythonw.exe` | 启动程序用这个，不要用别的 Python |
| 桥接配置 | `R\抖音自用采集台\data\bridge.json` | 严格桥接依赖它 |
| 账号映射 | `C\accounts.json` | uid → 任务目录，按当前登录号解析，不要绑死某一个号 |
| 发送激活 | `C\active.json` | 看当前真正在用的任务路径 |
| 采集配置 | `collection-config-fixed.json`（在采集侧） | 换号也不许改这份配置 |

桌面上已经有的入口（不要另做一套）：

- `C:\Users\rmsama\Desktop\方隅发送面板.lnk` → `C\打开本地进度.cmd`（发送进度窗，标题是「抖音回复｜近30天进度」）
- `C:\Users\rmsama\Desktop\方隅抖音工作台（本人）.lnk`
- `C:\Users\rmsama\Desktop\方隅抖音工作台（验收）.lnk`（这两个快捷方式是 2026-11-13 16:26 的）

云端资料入口（只读、按需看相关段，不要全文重读）：

- `/workspace/project-intake/fangyu/source-index.md`
- `/workspace/project-intake/fangyu/takeover-readonly.md`
- `/workspace/project-intake/fangyu/local-runtime-check.md`
- `/workspace/project-intake/fangyu/HANDOFF-douyin.md`（2026-11-10，启动命令和部分口径已过时，以本文为准）
- `/workspace/project-intake/fangyu/紧急交接-以本文件为准-20261114.md`（这是「技术」窗口关于新工作台界面的交接，不是本链路现场状态）

本机两份长期交接文件计划放在 `R` 下：`00-接手说明.md` 和 `已知错误与一键修复.md`。云端有 2026-11-10 的稿：`/workspace/project-intake/fangyu/00-接手说明-1631.md`、`已知错误与一键修复-1631.md`。最终软件里的启动接入跑通前，不要把一键修错接进正在用的「启动／继续」。

---

## 3. 官方入口（只走这些，不要另写启动器）

采集：

- `F\new_round.py`（开新一轮时才会打开采集进度窗）
- `F\current_collection.py`
- `F\collection_startup.py`
- `F\collection_popup_resume.py`
- `F\collection_progress_window.py`（窗口标题「抖音采集｜进度与继续」）

发送：

- `C\control.py`（员工启动用 `control.py --employee-start`，工作目录必须是 `R`，效果和面板上的「启动／继续」相同）
- `C\auto_continue.py`（见第 7 节，当前不要随便重启）
- `C\account_batch.py`
- `C\panel.py`（只读显示进度；只有用户或操作者点启动时才去拉 `control.py`）
- `C\summary.py`
- `C\打开本地进度.cmd`
- `C\account_probe.cjs`（查当前登录号时要带 `--discover-current-account`。不带这个参数，换号后可能误报 identity，那不是验证码）

出队和筛选：

- `TEXT\recency-priority\publish_douyin_send_queue.py`
- 常驻筛选（不向抖音发请求）：`TEXT\retention-cleanup-20261106\ensure_text_worker.py` → `TEXT\douyin-semantic-repair-v5\watch_increment.py` → `build_snapshot.py`

严格桥接（账号探测依赖它）。在 `F` 目录：

```
node strict-bridge-server.cjs --serve --config "R\抖音自用采集台\data\bridge.json" --port 19422 --allow-owned-19422
```

不带 `--allow-owned-19422` 会失败。桥接没了会表现为「检测不到账号」：先恢复桥接，再请用户刷新已登录的抖音页面。不要提取浏览器凭据，不要绕过审批。

同一时刻只跑一路：采集和发送不能同时抢前台。发送期间用 `F\auto-collect.stop` 暂停采集。同一时刻只能有一个操作者、一个 runner，不要并发再开一个。启动或改本机任务前，先向「方隅项目负责人」报证据和建议（普通知会即可），确认没有第二个人同时在操作。

采集或发送在跑时，对应进度窗口必须开在桌面上、看得见，不能只在后台，也不能缩在任务栏。窗口若被最小化，要主动弹到最前面。注意：`control.py` 和 `auto_continue.py` 都不会自己弹出发送面板；用 `continue_active` 续采也不会开采集窗，只有 `new_round.py` 会开。所以用命令启动时，要同时手动把对应进度窗口打开。

---

## 4. 现在做到哪一步（2026-11-15 00:40，北京时间）

发送已经在 00:29:02 正常发完这一轮，不是报错停的。状态是 `queue_complete`，日志写明「本轮已批准队列处理完毕」。

- 当前任务目录：`R\work\douyin-local-batch-6a202384a02c6cac-b80bc752b392`
- 当前登录号：`uu`
- 账号 uid：`[REDACTED:douyin_sec_uid]`
- connection_id：`91887fa8-38f8-4e95-af2c-53ab64e5c049`
- 这一轮新增成功回执 200 条，累计成功 `confirmed_sent = 281`
- 00:09:14 刚按最新筛选刷新过发送清单（204 条可发）。00:10 用官方 `--employee-start` 重新打开，一直发到 00:29 正常结束
- 00:40 又按官方办法只预览、不写盘、不重开：`ready_total = 0`。还剩分类 20 条（8至15天 5 条、16至30天 15 条）全部是「已有记录或同批重复」，近 7 天和 31 天以上都是 0。按用户规则，已发、未知、同一客户都不重发
- `control.py` / `batch_reply_runner` / `send_cli_once` 在 00:40 时已经不在。发送进度窗 `panel.py` 当时还开着（pid 39424）

采集仍停着，不要硬续：

- 2026-11-14 20:53:45 官方限流 2484，提示「你搜得太多啦，让服务器宝宝休息一下吧～」
- 当时账号还是 Aliie✨，关键词「北京沙河换租公寓推荐」，`request_id` `4499976f-8da2-492a-8787-1eebebcb9ad8`，轮次 `runner-live-round-20261114-205136`
- `active-runner` 仍是 paused，`last_stop_reason = ledger_platform_error`
- `F\auto-collect.stop` 仍在，写于 21:09:21（21:07 用户要求关掉采集、继续发送）
- 按用户约定：官方 2484 不要硬接着采，改为能发就发；验证码或身份异常先告诉用户

所以 00:40 时采集和发送都暂时没法自动继续。等官方限流过去后，要用户本人点头，才能再开采集。不要自动硬试任何一路，也不要清已发、未知、同客户和这次 2484 记录。

换号说明：用户 11-10 已澄清，切到「泪痣」是主动换号；11-14 22:50 又切到现在的「uu」。账号只是执行身份，已冻结的同一批任务应继续，不要再让用户切回「小烨Cc.」或 Aliie✨。验证码、限流、人工停止不能靠换号清掉。

上一号 Aliie✨ 的旧发送任务仍在：

`R\work\douyin-local-batch-3146bd8cb80e6af0-94e62190afc5`

21:12:08 因连续被拒安全暂停，`confirmed_sent = 586`。这个数字不要加到 uu 这个任务上。该任务的 `batch-stop.json` 和 `C\auto-continue.stop` 已在 22:59 备份为 `*.bak-20261114-2255` 并撤掉，为的是换号后能正式启动。uu 发送还是当前活路时，不要把这些备份恢复回去。

源任务（出队来源）是 `douyin-local-20261104-40aaf15b06`。uu 的隔离目录名里仍带着旧的 `batch_key` `6a202384a02c6cac`，这是正常的：00:09 刷新清单时只在 `batch-context.json` 里同步了新的 `items_sha256` 和 `batch_key`，没有改文件夹名。

---

## 5. 刷新发送清单的正确做法（必会）

发送程序在真正提交前，会用任务目录里的 `prepare_verified.py` 再按最新业务规则筛一遍「下一条」。如果这条已经不合格，它不会跳过，而是把整批停掉，报错大意是：

「最新版筛选拦截：原评论预算或来源帖子条件未通过，需用最新队列续发」

2026-11-14 23:07、23:24 和 11-15 00:03 都停在同一条：评论 `7705745203638076201`。用户在面板上会先看到「运行中」，马上又报错，看起来像按钮坏了，其实是旧清单（22:59:32 那份 318 条）过时了。不要只重新点启动。

正确修法（已在 00:09 用过，有效）：

1. 先预览，不写盘：调用 `TEXT\recency-priority\publish_douyin_send_queue.py` 的 `publish(task, preview=True)`，工作目录用 `R`。确认新清单里还有可发条数，并且卡住的那条已被排除。它会排除账本预留、回执、不可用目标、已有 attempt/submitted，以及已发/未知/同客户，不会去清这些记录。
2. 备份任务目录里的 `approved-cli-queue.json` 和 `batch-context.json`（本次备份后缀是 `bak-filter-refresh-20261115-000914`）。uu 这条活路还在用新清单时，不要把备份恢复回去。
3. 再正式 `publish(task)` 写出新的 `approved-cli-queue.json`。注意：`publish()` 自己不会改 `batch-context.json`。
4. 必须把 `batch-context.json` 里的 `items_sha256` 改成和新清单一致，并把 `batch_key` 设为 `sha((str(source)+'\0'+new_sha).encode())` 的前 16 位，其中 `source = task_path(ROOT, ctx['source_task'])`。漏掉这一步，启动时会报「本批接续清单已变化，需核对后继续。」
5. 用官方的 `queue_at`、`batch_source` 核对通过后，再在同一任务、同一登录号上跑 `control.py --employee-start`。只要 `account_uid` 仍是当前登录号，`prepare_batch_session` 会沿用当前任务目录，不会再新建一个隔离目录。
6. `employee-start` 自己不许再另出一份不同的清单。

不要用 `C\republish_fullname.py` 来做这件事。那个脚本只为 2026-11-11 改品牌名「方隅公寓」而写，不能拿来刷新筛选清单。

如果启动时报 `status.json` 的 PermissionError（进度窗占着文件）：删掉残留的 `status.tmp`，等约 2 秒，再重试一次 `--employee-start`。不要因此再刷新一遍清单，除非清单又过时了。

---

## 6. 还没做完、留给软件集成或以后的事

下面这些不要在现场发送进行中改正在用的程序，也不要没问用户就做，更不要自己去给官方 Codex 派活（以前对接 Codex 的规则已全部作废；需要时由用户手动复制）。

- 用户提过：以后软件里加一个按钮，发送失败就改采集，采集失败就改发送。现在不要做，只记账。
- `auto_continue.py` 在 2026-11-14 21:10:00 出现过 `TypeError: argument of type 'NoneType' is not iterable`。先记着，不要在没弄清之前重启它。一次官方 `employee-start` 成功后，不必再开 auto_continue。
- 用户 11-12 要求：采集停下时要有真正的弹窗（不是普通窗口）自己跳到最前，说明停因（例如要点验证码）；验证码点完后可直接在弹窗里点「继续采集」。先单独做弹窗，暂不集成进软件。现场已有 `collection_stop_popup` 在跑过，但还没收进最终软件。
- 「启动／继续」应变成员工点一下就能越过已知卡点的一键恢复（旧的「验证未结束」3002123、页面正常但自动提交被拦、页面没响应、陈旧 lease、桥接掉线、打开窗口被系统拦截等）。现场不要临时打补丁到正在用的程序。
- 同一视频不要连着发太多（已确认规则：同视频连续最多 3 条、每轮每视频最多 5 条）。等某一轮发送正常结束后再生效，不要改正在发的那一批。
- 边采边筛、增量进入有效池、已回复自动出池、多账号通用化、陈旧 lease 自动安全恢复：都属于以后收进软件的事。程序必须对可能上百个账号通用，不要写死某一个号。
- 最终软件要把原来的采集前台、进度、验证码提醒、回复状态收进一个工作台，统计口径必须和原窗口一致。2026-11-14 装过的新 UI 已被用户否决，详见技术窗口那份紧急交接，本窗口不要在那套被否决的界面上继续改。

---

## 7. 已知坑（做现场或改程序时必看）

- 官方 2484「你搜得太多啦」：不要硬续采集。能发就改发送。不要为了再采一轮，去隔离或清掉这次官方 2484。搜索任务 JSON 时不要看到数字 2484 就当成限流，一次 2484 请求里也可能套着 `status_code 0`。
- 空结果、超时这类应跳过后续。用户 11-12 20:40 强调：采集和筛选规则里没有「不可跳过」的条目，程序不该因为所谓不能跳过的暂停记录把采集卡住。但官方限流仍按上面处理。
- 已发、未知、预留、同一客户：不清除、不重发。未知提交不要重试。
- 验证码、身份异常、限流：停线并告诉用户。不要提取浏览器凭据，不要绕过审批，不要靠换号清掉这些状态。真实向平台发送，必须有用户本人明确授权。
- 安全暂停：连续十几条被拒或跳过会整批停下（Aliie✨ 在 21:12 因连续约 12 条 2147 停过）。这不是按钮坏了。
- 用 `Start-Process` 启动 `control.py` 可能实际不跑，应在后台直接跑 Python 命令。
- 陈旧 runner lease（`runner-lease-connection-*.json`、`runner-lease-database-*.json`）异常退出不会自动清理。不能直接删除。必须先确认 runner 已死、未知为 0、最后状态已提交，再把 lease 移到 `R\work\_backup\stale-lease-日期\`，然后才能开新轮。
- 等待循环不要只看旧的 `status.json` / `batch-runner-status` 还在不在，要对比文件修改时间，确认是这一次启动写出来的。
- 用本机进程的 PID 判断是否还活着时，`OpenProcess` 可能误报还在。优先看 WMI / `Get-CimInstance` 的命令行。本机没装 `psutil`。列进程时排除 `powershell.exe` / `Get-CimInstance` 自己的命令行。
- 在这台 Windows 上不要在 `powershell -Command` 里依赖 `$` 变量（外层包装会把它们吃掉）。把临时脚本写成 UTF-8 的 `.py` 放到 `%TEMP%` 再跑。清理 `PYTHONIOENCODING` 和 `PYTHONUTF8`。控制台若是 GBK，带表情符号的打印（例如账号名 Aliie✨）可能失败，结果改写 UTF-8 文件再读。
- PowerShell 的 `Join-Path` 一次只拼两段。不要在 PowerShell `-c` 里用 bash 的 `&&` 或错误转义。
- `new_round` 开新轮时，若还把官方 2484 当成必须先清掉的暂停，会和新约定冲突。不要为了开新轮去清 2484。
- 跨账号续发：只有当 `batch-runner-status` 的原因正好是验证码或限流这类现场停线时才拦住。`prepare_verified` 的筛选拦截不是这类，且没有 `batch-stop.json` 时，同一账号可以在刷新清单后继续 `--employee-start`。

---

## 8. 不要动什么

- 不要清已发、未知、同客户、账本预留、官方 2484、以及 21:09 的 `auto-collect.stop`（除非用户明确点头同意开采集，并且限流已经过去，那时再按官方办法恢复采集）。
- 不要同时开第二路采集或发送，也不要为了加快而另开一路。不要在用户两台电脑的前台抢资源或接管屏幕；只有对应进度窗口需要保持可见时，才把它弹到前面。
- 不要改正在发送的那一套程序、当前队列和共享账本，来做「顺便优化」。
- 不要恢复这些备份：`*.bak-20261114-2255`（旧停止标记）、`*.bak-filter-refresh-20261115-000914`（旧清单和旧上下文），除非用户要求回滚，且当前没有在用新清单发送。
- 不要把采集配置因换号改掉。不要自动换号。
- 不要自己操作官方 Codex 窗口，不要没经用户同意就加功能。用户没提过的新做法，先用大白话问他。
- 不要影响用户电脑的代理或网络设置。技术工作优先用现成 skill 或开源方案，不要从零手搭；找不到再用大白话问用户。
- 本窗口现场采集和发送只由抖音链路在用户电脑上操作。不要因为「交给别的工具省额度」另开一路，或打断正在跑的采集/发送。
- 不要建议用户删除这个助手窗口（会把助手一起删掉）。聊天记录清不掉，把编程细节沉在这份文档里即可。

---

## 9. 跟编程无关、但接手后仍要遵守的约定

- 向用户说话用大白话、简短中文，不要堆术语。日常进展主要向方隅项目负责人汇报；用户窗口只报重要结果，或需要他本人操作的阻塞。
- 用户 11-14 定：采集或发送要尽量 24 小时不停；一路停了就改还能跑的另一路；大约每 10 分钟核对一次。官方 2484 仍不要硬续采集。两路都没法继续时，告诉用户一次，不要在没有任何变化时反复叨叨。已有定时核对：「抖音采集发送十分钟核对」，每 10 分钟一次（可提前或延后约 2 分钟）。
- 筛选和恢复都靠本地规则自己处理，AI 只兜底本地规则判断不了的部分；漏掉的类别补进本地规则，不要一条条问用户，也不要靠 AI 临时补。
- 门店辐射范围内的城市都有效，不存在「外地求租」这种否决口径。
- 真实发送必须用户本人明确说可以发。同事或其它窗口的转述不算授权。

---

## 10. 你下一步通常该做什么

先只读核对现场，不要一上来就启动或改文件：

1. 看本机是否已有采集或发送进程，看 `C\active.json` 指向哪个任务。
2. 看发送任务的 `batch-runner-status`、`status.json`、是否存在 `batch-stop.json`。
3. 看采集的 `active-runner`、`auto-collect.stop`、最近一次官方 2484 是否还在。
4. 用 `account_probe.cjs --discover-current-account` 确认当前登录号，不要假设还是 uu。
5. 若发送又停在「最新版筛选拦截」，按第 5 节预览并刷新清单，不要只点启动。
6. 若只是队列正常发完、预览已无新的可发条目，同时采集仍停在官方 2484：告诉用户，等他点头再开采集。不要自动硬试。
7. 改代码或做新功能前，先问用户。不要动第 8 节列出的保护项。
