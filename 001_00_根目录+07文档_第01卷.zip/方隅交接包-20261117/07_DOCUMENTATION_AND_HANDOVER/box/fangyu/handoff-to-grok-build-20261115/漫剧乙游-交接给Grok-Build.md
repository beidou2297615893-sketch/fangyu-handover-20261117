# 漫剧乙游窗口 · 交接给 Grok Build

更新时间：2026-11-15 00:58（北京时间，Asia/Shanghai）
来源窗口：漫剧乙游
用途：把本窗口跟编程、做游戏相关的现状交给一个没看过聊天记录的编程工具，让它能直接接着干。

---

## 一句话

用户接了一个活：客户有一部火爆「漫剧」，人物建模和性格都有，要把这些做成乙女向可交互 Galgame，以后能上 Steam 或手机。

现在已经有一套可双击运行的 Windows 游戏骨架，游戏名暂定「星渊」，引擎是官方 Ren'Py 8.5.3。内容是原创占位角色和短演示剧情，不是客户正片，也还没有真正放到用户电脑桌面上。

---

## 用户要的是什么（必须先看清）

- 要的是能当软件发行的游戏，不是网页。用户已经明确否定过网页演示。
- 先要 Windows 包，以后还希望能上 Steam、能出手机安装包。
- 这是骨架：后面用户把客户的人物、剧情、设计点交来，就可以套进去，不要每次从零重做。
- 资产口径已锁定为「A+C」：正式进游戏的是干净的 2D 立绘；漫剧视频或设计图只当参考，不要把视频直接当游戏角色。
- 禁止抄《恋与深空》的官方名字、造型、素材。当前占位角色必须是原创。用户口误「炼狱深空 / 淫女游戏 / 疑女 / 疑虑游戏 / Galo Game」都是指「恋与深空 / 乙女游戏」，不是成人向内容。

---

## 现在以哪套工程为准

唯一接受的产品工程：

- 源码：`/workspace/otome-pipeline/renpy-xingyuan`
- 剧本主文件：`/workspace/otome-pipeline/renpy-xingyuan/game/script.rpy`
- 配置：`game/options.rpy`（显示名「星渊」，版本 0.1.0，构建名 XingYuan）
- 简要说明：`/workspace/otome-pipeline/renpy-xingyuan/README.txt`
- 路线说明：`/workspace/otome-pipeline/renpy-xingyuan/story/brief.md`
- 官方 Windows 构建：`/workspace/otome-pipeline/renpy-xingyuan-dists/XingYuan-0.1.0-win.zip`
- 给用户的同内容副本：`/workspace/demo-share/xingyuan-windows.zip`（约 35MB，36538167 字节）
- SHA256（两份相同）：`91d9eb41555723062773cdb20ffb0b5446ee378660e38cba4b4ad976f05650f7`

怎么玩（给用户或验收用）：

1. 解压 zip，得到文件夹 `XingYuan-0.1.0-win`
2. 打开这个文件夹，双击 `XingYuan.exe`
3. 不要只把 exe 单独拷走，`lib`、`game`、`renpy` 必须和 exe 放在一起
4. 存档位置：Windows 的 `%APPDATA%\RenPy\XingYuan-0.1.0`

游戏内容（骨架演示，不是成品体量）：

- 四位占位男主：沈星野（猎手）、顾深（医师）、黎川（画家）、霍烬（危险的保护者）
- 公共线在天台认识四人，然后锁一条路线
- 每条线一次关键选择，两个分支，进入该角色结局
- 好感变量：`xingye_affection` / `gushen_affection` / `lichuan_affection` / `huojin_affection`
- 立绘：`game/images/characters/{xingye,gushen,lichuan,huojin}.jpg`
- 背景：`game/images/backgrounds/{rooftop,penthouse,aquarium}.jpg`
- 标题图：`game/images/ui/title.jpg`
- `game/audio/` 是空的，还没有音乐和音效
- 立绘是不带透明通道的 JPG，放大后边缘不干净；构建时资源检查有过 4 条警告，当时没有重画

引擎和打包方式：

- 必须用官方 Ren'Py 8.5.3 打包，不要再做成网页
- SDK 缓存在：`/home/box/.cache/renpy-agent/sdk/8.5.3/`，启动器是这里的 `renpy.sh`
- 对应 skill：`/workspace/otome-pipeline/.agents/skills/renpy`（helper：`scripts/renpy.py`，可 setup / doctor / init / lint）
- 布局、中文、校验可参考：`/workspace/otome-pipeline/.agents/skills/renpy-galgame-builder`
- 安装清单：`/workspace/otome-pipeline/skills-lock.json`
- 上次官方 `lint --error-code` 已通过，无报错。日志：`/workspace/otome-pipeline/renpy-xingyuan/.renpy-agent/logs/20261114T230127-574f4357-lint.log`

人物和剧情的入库入口（后面套客户素材时用这里，不要另起一套目录）：

- `/workspace/otome-pipeline/INPUT/characters/<角色id>/profile.json` + `portrait.jpg` 或 `portrait.png`
- `/workspace/otome-pipeline/INPUT/story/chapters.json`
- `/workspace/otome-pipeline/INPUT/design/game.json`
- 已有两个用户库 skill：乙女人设入库（skill-1794665287337）、乙女剧情与设计套用（skill-1794665298504）
- 注意：`scripts/apply.py` 和 `套用说明.md` 是给已否定的网页版用的，不要再按那套往 `/workspace/otome-pipeline/game/` 里套。以后套新内容，应改 Ren'Py 工程里的 `game/script.rpy` 和 `game/images/`，或先把 apply 改成写 Ren'Py，再跑。

调研资料（只作参考，不要当当前产品）：

- `/workspace/manju-otome-research/01-github-engines-generators.md`
- `/workspace/manju-otome-research/02-prompts-methodology.md`
- `/workspace/manju-otome-research/03-open-skills.md`
- `/workspace/manju-otome-research/04-assets-pipeline.md`

已装到工程里的 skill 目录：`/workspace/otome-pipeline/.agents/skills/`
其中有：renpy、renpy-galgame-builder、visual-novel、dialogue-systems、galgame-master、novel-to-game、novel-game-analyze、game-design、game-build、game-qa、character-bible、live2d-from-art、ruxi-skill、visual-novel-builder。

开源备份：`/workspace/otome-pipeline/vendor/`（含 dsh-galgame-generator、GalgameTemplate、vn-playbook、ruxi-skill）

---

## 不要动、不要再当成产品的东西

这些都是被用户否定过的路径，不要修复后重新交给用户当成品：

1. 手搭的 HTML/CSS/JS 游戏：`/workspace/otome-pipeline/game/`（含 index.html、css、js、data）。用户明确说过：不要手搭，要用 skill。
2. 网页版 Galgame：`/workspace/otome-pipeline/skill-galgame/` 以及生成出的 `星渊.galgame.html` / `xingyuan.html`。用户明确说过：不要网页，而且当时没法保存文件来玩。
3. 不要把 `visual-novel-builder` 接进生成链路（安全原因，只许当流程参考）。
4. 不要使用或仿制《恋与深空》官方 IP。
5. 不要改 Ren'Py 官方引擎文件。改玩法或剧情，主要改 `game/script.rpy`、图片和配置。
6. 不要建议用户删除这个助手窗口来「清空记录」。聊天记录删不掉；编程细节已经沉到这份文档里即可。也不要假装对话框已经被清空。

---

## 做到哪一步，还没做完什么

已完成：

- 全网搜过引擎、生成器、提示词方法和开源 skill，并下载安装到工程里
- 用官方 Ren'Py 8.5.3 打出可运行的 Windows 包
- 聊天里发过拆分文件（因为整包超过聊天附件 25MB 上限）：
  - `/workspace/demo-share/xingyuan-1-of-2.bin`（20MB）
  - `/workspace/demo-share/xingyuan-2-of-2.bin`（约 15MB）
  - `/workspace/demo-share/join-xingyuan.bat`（同目录下 `copy /b` 拼回 `xingyuan-windows.zip`，盒子上校验过哈希一致）
- 给用户的说明书：`/workspace/demo-share/README.txt`

还没完成（按优先级）：

1. **最紧急：把游戏包放到用户 Windows 桌面。**  
   目标路径：`C:\Users\rmsama\Desktop\xingyuan-windows.zip`  
   用户电脑：机器 id `f79a5338-7ab9-41e1-bad0-3f5c3b1dd392`，名字 RMSAMA。  
   用户 2026-11-14 约 23:06 明确要求「直接放到桌面」。当时聊天是通的（消息就是从这台电脑发来的），但往这台电脑拷文件、在这台电脑上执行命令都失败，提示「暂时连不上 RMSAMA」。通道一恢复就应立刻拷过去，并告诉用户已经在桌面上。不要再对用户说「你的电脑离线了」。
2. 用户还没把客户漫剧的正式人物、性格、剧情交来，所以还没有套正片。当前四人只是占位。
3. 没有做 Steam 上架。那需要用户自己的 Steamworks / Steam 合作伙伴账号，在后台创建应用并上传构建。现有 zip 只是能运行的 Windows 游戏文件。
4. 没有打 Android APK。同一套工程可以走 Ren'Py 官方 Android 流程，但当时环境里没有 RAPT / Android SDK。
5. 没有音乐、音效；立绘还没有透明底；剧情只是很短的骨架演示。
6. `story/assets.json` 还是空的，没有记录素材出处。

---

## 已知坑

- **「离线」这词会误导用户。** 用户强调自己的电脑从来没有离线过，也很反感同事反复这么说。真实情况是：聊天通道可以通，专门用来拷文件、在用户电脑上执行命令的那条「本地执行」通道会抖动。ListMachines 有时显示 connected，但 CopyFromBox 和带 machineId 的命令仍可能失败。这不是云电脑的问题，也不是用户电脑关机或断网。机器人这边修不了这条官方通道。相关设置入口是应用里的「电脑」和「本地执行」。不要把「更新 Bot 的电脑」当成修用户电脑通道的办法，那是修云端盒子的。聊天附件上限 25MB，CopyFromBox 上限 100MiB；35MB 的 zip 不能当聊天附件整包发送，可以拆分，或等本地拷贝通道恢复后直接放到桌面。
- 打包过程中，`game/tl/schinese/screens.rpy` 一度出现中文翻译词条重复（"Skipping" 重复定义），当时 `traceback.txt` 里有记录。后来 lint 已通过，现在文件里只剩一处。如果重新生成翻译，要检查是否再次重复。
- `script.rpy` 里霍烬结局 B 有一句笔误：「既然你要站在你身边」，语义不通，应是「站在我身边」一类。
- 立绘是 JPG、无透明通道，在游戏里用 0.52 缩放居中显示，边缘会发脏。要换正式立绘时优先用带透明底的 PNG。
- 聊天里发图、发视频时：不要用中文文件名；图片要单独当附件发，不要塞进文本消息的图片数组；视频用 Baseline H.264 的 mp4，或较小的 gif。之前用中文名和高规格 H.264 时，用户看不到。
- Debian 环境当时没法把 35MB 的 zip 再压到 25MB 以下（软件源 500、系统 Python 限制安装压缩库）。
- 用户额度紧。技术类工作能用现成 skill / 开源方案就用，不要手搭或另做一套。普通推理和写稿优先考虑让用户把任务复制给 Muse 网页端（用户可手动来回粘贴，Muse 管不了本地文件，也不要打断已经在进行的工作）。

---

## 必须遵守的约定（跟编程有关的也要留着）

- 能用 skill 就用 skill，不要自己想一套，也不许手搭。很简单的小事可以灵活处理；只要有点复杂就必须用 skill。除非用户明确说「只稍微改这一点」。
- 优先在 GitHub / 开源里找高质量现成方案再套用，找不到才自己做，并且要先跟用户说明。
- 对用户说人话，少堆术语。
- 未经用户同意，不要把新想法直接做进去，先用大白话问。
- 不要使用官方 Codex，除非用户本人明确要求。
- 客户正片素材还没到。到了以后：人设进 INPUT/characters，剧情和设计点进 INPUT/story 与 INPUT/design，再写入 Ren'Py 工程，不要新开一个互不兼容的游戏目录。

---

## 建议接手后怎么继续

1. 先确认 `/workspace/demo-share/xingyuan-windows.zip` 还在，哈希仍是上面那一串。
2. 只要用户电脑的本地拷贝通道可用，立刻把这个 zip 放到 `C:\Users\rmsama\Desktop\xingyuan-windows.zip`，并告知用户：解压后打开 `XingYuan-0.1.0-win`，双击 `XingYuan.exe`。
3. 不要再做网页版，不要翻新手搭 HTML。
4. 等用户交来客户的人物和剧情，再按 Ren'Py 工程替换立绘、背景和 `game/script.rpy`。
5. Steam 和安卓包等用户明确要求，并且具备 Steamworks 账号或 Android 打包环境后再做。
