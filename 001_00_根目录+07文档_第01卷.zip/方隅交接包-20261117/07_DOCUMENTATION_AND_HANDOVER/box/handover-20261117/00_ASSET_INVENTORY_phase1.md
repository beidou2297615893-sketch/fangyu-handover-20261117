# 00_ASSET_INVENTORY：方隅 / 答题（每日百题·知题）/ 公共工具 资产盘点

- 盘点时间：2026-11-17 13:48–14:40（北京时间 UTC+8）
- 范围：用户电脑 RMSAMA（Windows，只有 C 盘）+ 云电脑 box
- 方式：**只读**。只扫了文件名、大小、修改时间；Git 只用 `--no-optional-locks` 读；SQLite 只用 `mode=ro&immutable=1` 读表名。没有读任何凭据、Cookie、账本内容，没有启动/停止进程，没有改动、移动、删除项目文件。RMSAMA 上的临时扫描脚本和结果已删除；原始清单保存在本目录 `inv/` 下。
- 本阶段**没有打包、没有复制项目文件**。

> 说明：时间均为文件修改时间（mtime），不是创建时间。PowerShell 5.1 扫描时遇到过「Filename too long」，路径超过 260 字符的文件可能漏计，所以**文件数是下限**。

---

## 1. 一句话结论

1. **方隅没有可用的 Git 历史。** 方隅的主开发区 `C:\积木软件工坊\项目\方隅公寓客户版` 不是 Git 仓库。另一个工作区 `Documents\ChatGPT\自动获客系统` 虽然有 `.git`，但 **0 个提交、0 个分支、0 个 tag、0 个 stash**，里面只有 Codex 自动留下的 4 个「目录快照 tree」（10-13、10-13、10-15、10-16）和 35,003 个散落对象（7.66 GiB），外加 48 个残留临时对象（441 MiB）。所以版本只能**按目录快照的时间线**来认，没有 Commit ID 可回退。
2. **答题项目只有零碎的小仓库。** 每个仓库都只有 1–3 个提交（TiJing 上游导入、`ui/yejin`、`repair/cloud-056`、`codex/configurable-automation-v2`），没有完整开发历史。最新的正式包是 0.4.27（11-17，桌面「知题-支付调整完整开发包」）。交接文档里写的 0.4.24 已经过时。
3. **体量非常大，必须挑着打包。** 方隅相关约 487 GB，答题约 337 GB，公共部分约 45 GB。真正的代码（按文件名+大小去重后）大约是：方隅 0.58 GB 代码 + 0.12 GB 文档，答题 0.2 GB，公共 0.34 GB。其余几乎都是：成百上千份重复的发布目录、PyInstaller 运行库、模拟器镜像、虚拟机磁盘、安装包，以及 **106 GB 正在使用的实时账本**。
4. **「UI 大改之前」的候选**（详见第 5 节）：视觉以 10-15～18 用户认可的 `ui-approved-implementation\ui-preview` 为准；整机应用（能运行的程序）以 r57 发布目录 `ui-r57-20261018T103009Z-ebd9da3c`（10-18 18:30）作为首选基线。证据强度为**中**：只核对了时间线，内容还没逐个比对。

---

## 2. 磁盘与输出位置

| 位置 | 已用 | 剩余 | 说明 |
|---|---|---|---|
| RMSAMA `C:`（唯一盘符，无 D 盘；`subst` 为空，`V:` 不存在） | 1,679.5 GB | **226.1 GB** | 放核心包够用；放全量原样副本不够（全量去掉可重建内容后仍有约 700 GB 以上） |
| box `/` | 40 GB | **88 GB** | CopyToBox 单个文件上限 100 MiB，所以大包不适合从本机搬到 box 再打包 |

**建议输出位置**：在 RMSAMA 上新建 `C:\方隅交接包-20261117\`，在本机打包（项目源头在本机，不用跨机搬运）。每个分卷 ≤ 95 MiB，这样之后可以按需 CopyToBox，或直接上传给其他 AI。box 只放文档和校验文件（`SHA256SUMS.txt`、`FILE_MANIFEST.csv`）的副本：`/workspace/project-intake/fangyu/handover-20261117/`。

---

## 3. 项目总表（RMSAMA）

大小按文件实际字节汇总。「可重建」指 node_modules、PyInstaller `_internal`、Python 环境、gradle/build、缓存、浏览器 profile、AVD 镜像等。

### 3.1 方隅自动获客系统

| 路径 | 大小 | 文件数 | Git | 最后改动 | 是什么 |
|---|---|---|---|---|---|
| `C:\积木软件工坊\项目\方隅公寓客户版\` | 342.7 GB | 4,259,064 | 否 | 11-17 12:02 | **桌面客户端/界面/打包主开发区**。`work\` 下有 466 个子目录（307 GB），`outputs\` 35.6 GB（正式交付 26 GB、软件完整交接 236 MB、Linux 云端开发工程 734 MB 等） |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\` | 142.0 GB | 291,644 | 有 `.git`，但 0 提交 | **11-17 14:13（正在写）** | **采集/回复引擎和实时账本**：`work\fangyu-douyin-independent`（95 GB，账本 85.8 GB）、`fangyu-text-business-20261029`（14 GB）、`shared-acquisition-ledger`、`douyin-local-control`、`抖音自用采集台`（Bridge）、小红书各链路、`Codex获客工作台` |
| `C:\积木软件工坊\项目\方隅公寓\` | 303.7 MB | 378 | 否 | 10-27 | 早期项目 |
| `AppData\Local\FangyuDesktopDirect-20261117` | 25.9 MB | 200 | 否 | 11-17 12:15 | **现在的安装**：浅色认可 UI 接现有后端（桌面「方隅工作台（新版试用）」） |
| `AppData\Local\FangyuDesktopDirect-20261114` / `-backup-20261117` | 各 71.9 MB（净 11 MB） | 568 | 否 | 11-14 | 11-14 试用壳及其备份（两者完全一样） |
| `AppData\Local\FangyuDesktopDirect-20261114-state` | 83.1 MB | 1,189 | 否 | 11-17 10:31 | **运行状态**（门店记忆、`employee-data\douyin-browser\<hash>\Default` 浏览器登录态）——敏感 |
| `AppData\Local\FangyuDesktopPreview-20261114(-state)` | 71.8 MB | 565 | 否 | 11-14 | 11-14 预览版 |
| `AppData\Local\fangyu-apartment-client*`（4 个目录，含 2 个 `.previous-*`）、`fangyuWorkspace(App)`、`FangyuMaintenance` | 约 1.8 GB | 约 6,000 | 否 | 9-17～10-18 | 9～10 月的旧安装（PyInstaller） |
| `Documents\ChatGPT\fangyu-accept-20261114` | 6.3 MB | 5 | 否 | 11-14 | 验收材料 |
| `agent-tools\fangyu-ui-design` | 1.9 MB | 4 | 否 | 11-11 | 界面设计工具 |

### 3.2 答题小程序（每日百题 / 知题，包名 `com.jimusoft.dailyhundredapp`）

| 路径 | 大小 | 文件数 | Git | 最后改动 | 是什么 |
|---|---|---|---|---|---|
| `Documents\ChatGPT\答题小程序\` | 186.1 GB | 732,384 | 子目录里有多个小仓库（见第 4 节） | 11-16 | 主开发区。`每日百题APP\work`（179.9 GB，其中 AVD 镜像 146 GB、gradle 14 GB）。0.4.24 源码在 `work\original-vs-0419\release-mobile`。另有微信小程序工程 `outputs\每日百题_微信小程序工程` |
| `C:\Users\rmsama\DailyHundredNativeBuild\` | 147.1 GB | 381,940 | 否 | 11-13 | 安卓构建和 30 多个模拟器副本（可重建内容约 139 GB） |
| `Desktop\知题-支付调整完整开发包\` | 212.8 MB | 25,094 | 否 | **11-17 12:27** | **最新**：0.4.27（versionCode 94）正式签名包、云函数、线上部署前备份、回滚包。README 说明线上云函数已于 11-17 12:13/12:14 更新 |
| `Desktop\知题-完整项目最终存档\` | 3.72 GB | 130,545 | `outputs\daily-hundred-app` 是仓库 | 11-16 | 0.4.24 最终存档（release-mobile、outputs） |
| `.codex\local-build-aliases\dailyhundred-20261023` | — | — | — | — | **是 junction**，指向 `每日百题APP\work`，不是另一份数据，打包时不能重复算 |
| `.config\.cloudbase\projects\`（约 70 个目录） | 小 | — | 否 | 至 11-17 | 腾讯云 CloudBase 部署配置——可能含凭据 |
| `C:\Users\rmsama\WeChatProjects\` | 11.2 MB | 474 | 否 | 6-7 月 | 微信开发者工具的默认模板工程（miniprogram-1～10），**大概率与本项目无关**，待确认 |

### 3.3 公共工具与共享组件

| 路径 | 大小 | 文件数 | 是什么 |
|---|---|---|---|
| `C:\积木软件工坊\`（根下 `AGENTS.md`、`打开这里.md`、`.gitignore`、`memory\`） | 小 | — | 工坊级开发规则。根下有 `.gitignore`，但**没有 `.git`** |
| `C:\积木软件工坊\核心组件\` | 9.98 GB | 190,658 | 社媒人设与内容运营组件库（5.3 GB）、versions、work；去掉可重建内容后，代码约 393 MB |
| `C:\积木软件工坊\设计方法库\` | 761 MB | 41,686 | 开源 UI 资源库、交互研究 |
| `C:\积木软件工坊\备份\` | 3.14 GB | 14 | 9 月备份包 |
| `C:\积木软件工坊\项目\自用工作台`（22.9 GB）、`三平台自用工作台`（7.9 GB）、`小红书CLI独立试用`（209 MB）、`客户交付模板` | — | — | 关联的自用项目 |
| `...\方隅公寓客户版\work\desktop-python\` | 52.9 MB | 3,140 | **两个项目共用的 Python 运行环境**，桌面快捷方式都用它的 `pythonw.exe`（可重建，但要记下版本） |
| `Documents\AI-Backup\`（Git，6 个提交，无远端，main） | 292.8 MB | 1,713 | 11-10 的 AI 备份，含 codex-archived-threads（250 MB，历史对话 jsonl） |
| `Codex-Bridge`、`GrokCross`（87 MB）、`agent-tools`（144 MB）、`.grokbot` | 小 | — | 工具 |
| `Documents\GrokBuild\` | 182 MB | 11 | Grok Build 启动目录 |

### 3.4 云电脑 box

| 路径 | 大小 | 文件数 | 其中可重建 / 安装包 | 是什么 |
|---|---|---|---|---|
| `/workspace/project-intake/`（fangyu、quiz、quiz-app、TECH-HANDOFF.md） | 290 MB | 926 | 压缩包 94 MB | **交接文档的主要来源**：HANDOFF*.md、USER-CHANGE-LOG、product-spec、rules-*、ui-design/batch-01～09 |
| `/workspace/fangyu-ui-rollback-20261117/` | 179 MB | 765 | 压缩包 56 MB | 11-17 浅色 UI 回退工作副本：`pristine/`（ui-preview 原样）、`work/production-desktop/`（部署源码）、`docs/页面对照表.md`、`部署记录-20261117.md` |
| `/workspace/fangyu-opendoor-replica/` | 607 MB | 10,627 | 198 MB | openDoor 复刻客户端（batch-09），未装到本机 |
| `/workspace/fangyu-workbench-copy-20261114/` | 339 MB | 1,162 | 303 MB | 11-14 工作台副本、ui-native-r57 精简版、紧急交接 |
| `/workspace/fangyu-cloud-dev-verify/` | 870 MB | 11,835 | 压缩包 269 MB | muse dev 11-11 全量（final.zip / muse.zip 各 90 MB） |
| `/workspace/handoff-to-grok-build/` | 0.1 MB | 12 | — | 11-15 各窗口交接书（方隅负责人/界面设计/抖音/小红书/规则/新软件负责人等） |
| `/workspace/zt042`～`zt045`、`quiz-delivery`、`quiz-ui-redesign`、`release-0358`、`bankassist` | 约 2.0 GB | 约 8,000 | quiz-delivery 里 APK 占 1.46 GB | 答题项目的云端修复记录、0.3.x～0.4.24 证据。zt045 的交接书说明见 `交接-给新软件负责人.md` |
| `dy-*`、`douyin-*`、`xhs-*`、`staged-round4～9`、`staged-store-tier-20261115` | 约 70 MB | 约 600 | — | 抖音/小红书修复和规则轮次的暂存 |
| `/workspace/tools/deepseek`（ds 调用器）、`tools/backup`、`tools/replica-skill` | <1 MB | 54 | — | 公共工具（密钥只放在环境变量里，不在文件中） |
| `/home/box/agent-data/workflows/`（10 个技能） | <1 MB | 11 | — | Bot 技能 |
| `/home/box/shared-skills/` | 613 MB | 6,981 | 249 MB | 共享技能库（含第三方 Git 仓库 OpenMAIC 等） |
| `/home/box/.local/share/ai-backup/staging`（Git，25 个提交，无远端） | 218 MB | 2,247 | .git 84 MB | 每日备份守护程序，最后一次 11-17 07:48，`secret_name_count=0` |
| `/workspace/tmp`、`uploads`、`cloud-agent-transcripts` | 285 MB | 1,757 | — | 临时文件、上传件、转写 |

---

## 4. Git 仓库清单（全部）

| 仓库 | 归属 | HEAD / 分支 | 提交数 | 首/末提交 | tag | stash | 远端 | 未提交 / 未跟踪 |
|---|---|---|---|---|---|---|---|---|
| `Documents\ChatGPT\自动获客系统` | 方隅 | `master`（未出生） | **0** | — | 0 | 0 | 无 | 未跟踪 242,367 个；另有 refs/codex/turn-diffs 下 4 个 tree 快照（`15c5d08e` 10-13 两次、`ec152e88` 10-15 12:53、`4c40d02c` 10-16 21:44，每个约 24,600 个文件） |
| `每日百题APP\work\tijing-upstream` | 答题 | main | 3 | 10-05 20:57 / 10-05 22:34（`2d2da07`） | v0.7.7 | 0 | github.com/futureYYY/TiJing | 0/0 |
| `每日百题APP\work\tijing-dailyhundred` | 答题 | main | 3（同上） | 同上 | v0.7.7 | 0 | 本地 tijing-upstream | 修改 15 / 未跟踪 19 |
| `每日百题APP\work\tijing-minimal` | 答题 | main | 3（同上） | 同上 | v0.7.7 | 0 | 本地 tijing-upstream | 11 / 14 |
| `每日百题APP\work\original-vs-0419\original-control\source` | 答题 | main | 3（同上） | 同上 | v0.7.7 | 0 | `V:\work\tijing-upstream`（**V: 盘已不存在**） | 1 / 2 |
| `每日百题APP\work\cloud-056-repair` | 答题 | `repair/cloud-056` | 1（`7957f9e` 11-10 15:49） | — | 0 | 0 | 无 | 47 / 2,534 |
| `每日百题APP\work\ui-yejin-isolated` | 答题 | `ui/yejin`（另有 master） | 1（`67d35b0` 11-10 20:59） | — | 0 | 0 | 无 | 5 / 19 |
| `每日百题APP\outputs\daily-hundred-app` | 答题 | `codex/configurable-automation-v2` | 1（`4d819a3` 10-23 13:51） | — | 0 | 0 | 无 | 45 / 73,337 |
| `Desktop\知题-完整项目最终存档\outputs\daily-hundred-app` | 答题 | 同上 | 1（同一提交） | — | 0 | 0 | 无 | 45 / 37,117 |
| `每日百题APP\work\tijing-bankassist`、`知题本轮验收\isolated\source`、`知题启动修复\work\isolated(-no-frame)\source` | 答题 | 未出生 | 0 | — | — | — | — | 仅未跟踪 167～190 个 |
| `每日百题APP\work\fullflow-alternatives\{quizsnap-source, r-source}`、`android-updater-reference` | 第三方参考 | — | 1（grafted 浅克隆） | — | r-source: v1.0.0 | 0 | GitHub | 0 |
| `Documents\AI-Backup` | 公共 | main | 6 | 11-10 12:30 / 12:31 | 0 | 0 | 无 | 4 / 346 |
| box `~/.local/share/ai-backup/staging` | 公共 | main | 25 | 11-10 / 11-17 07:48 | 0 | 0 | 无（未推送） | — |
| 第三方浅克隆（只读参考，不属于本项目历史）：dyhub、gsap-skills、motion-skill-kit、taste-skill、auto-rednote、xiaohongshu-cli×3、Auto-Redbook-Skills×3、sing-box、index-tts×2、ComfyUI、reverse-skill；box：otome-pipeline/vendor×4、dl/×5、shared-skills/video×3、/tmp×3 | — | — | 1（grafted） | — | — | 0 | GitHub | — |

**结论：** 用户要的「完整 Git 历史 bundle」，对方隅来说**没有可打的提交历史**。能保留的只有：①把上表里的小仓库各自打成 `git bundle --all`；②方隅 `自动获客系统\.git` 里的 4 个 Codex tree 快照（bundle 只认提交，需要在**副本仓库**里用 `commit-tree` 包一层再打 bundle；或者直接把 `.git` 原样归档，7.7 GB）；③方隅的版本史只能靠**目录快照 + 时间线**表达（见第 5 节）。

---

## 5. 方隅版本时间线与「UI 大改之前」候选

方隅所有版本都是目录快照。r57 在 `work\ui-native-r57\releases\` 下共有 **327 个带哈希的发布目录**（10-16～10-27），相当于一份按时间排的「提交史」。

| 时间（北京） | 版本 / 目录 | 大小 | 说明 |
|---|---|---|---|
| 9-17～9-24 | `work\界面改版备份_20260923_*`（约 80 个小备份）、`fangyuWorkspaceApp` | 小 | 第一代界面 |
| 10-05～10-15 | `ui-runtime-r56`、`ui-runtime-r55`、`v3-ui-approved-source44-candidate`（10-12）、`ui-core-completion`（10-15） | 220 MB | r55/r56 运行时 |
| **10-14 18:51～10-18 12:17** | **`work\ui-approved-implementation\ui-preview`**（17.7 MB，86 个文件）+ screenshots + page-fidelity-review | 28.9 MB | **用户认可的浅色 UI**（11-17 t466u 再次确认） |
| 10-16 15:31～10-18 18:30 | r57 发布 64 个，`ui-r57-20261016T073114Z` → **`ui-r57-20261018T103009Z-ebd9da3c`** | 每个 17～24 MB / 71～126 个文件 | 认可 UI 期间的整机程序 |
| 10-19～10-22 | r57 发布 59 个，到 `ui-r57-20261022T153627Z-4d546d79`（25.5 MB） | 25 MB | 小步改动 |
| 10-22～10-27 | `commercial-integration-20261022`（110.7 GB）、`parallel-integration-20261018`（48 GB）；10-23 一天出了 145 个 r57 发布，体积从 25 MB 跳到 122 MB / 925 个文件 | — | 大规模集成商业功能，体积暴增 |
| **10-25 13:06 起** | `ui-spacious-redesign-20261025` → `ui-production-redesign` → `ui-reference-fidelity` → `ui-fidelity-correction` → `ui-visual-restore-20261027` | — | **UI 大改开始** |
| 10-27 21:29 | r57 `FROZEN.json` 冻结；最后一个发布 `ui-r57-20261027T130512Z-a9ba360f`（393 MB，其中部分文件 11-11 又被改过） | 393 MB | 「10-27 r57 冻结版」，11-17 页面对照表已明确**不用它作为目标界面** |
| 11-01 | `独立界面工程` | 47.5 MB | 网页版界面 |
| 11-10～11-11 | outputs：`极简获客界面`、`简洁无小字界面`、`暖色公寓简洁界面` | — | 设计稿 |
| 11-13～11-14 | `release-20261113`（2.1 GB）、`release-20261114`（838 MB）、`FangyuDesktopDirect-20261114`、batch-07/08 深色玻璃、batch-09 openDoor（box） | — | 11-14 试用壳 + 新设计 |
| 11-17 12:15 | `FangyuDesktopDirect-20261117`（浅色 UI 接现有后端） | 25.9 MB | 当前安装 |

**候选（按推荐顺序）：**

| # | 候选 | 日期 | 理由 | 证据强度 |
|---|---|---|---|---|
| A（视觉基准） | `work\ui-approved-implementation\ui-preview` | 10-14～10-18 12:17 | 用户 10 月认可、11-17 再次确认的界面，11-17 新安装就是从它接出来的 | **强**（有用户明确认可），但它**只是前端预览，不含后端** |
| B（整机首选） | `work\ui-native-r57\releases\ui-r57-20261018T103009Z-ebd9da3c` | 10-18 18:30 | 认可 UI 实施结束后的第一个完整程序；早于 10-22/23 商业集成暴增，也早于 10-25 UI 大改 | **中**（只核了时间线，还没比对它是否真的用了 ui-preview 的界面） |
| C（功能更多的备选） | `ui-r57-20261025T015609Z-8a7e4038` | 10-25 09:56 | UI 大改（13:06）开始前的最后一个发布，已带上 10-23/24 的商业集成功能（144 MB / 2,802 个文件） | **中偏弱**（同上，而且 10-23 以后界面可能已经开始变了） |
| 补充（引擎侧） | `自动获客系统\.git` 的 Codex tree `ec152e88`（10-15 12:53）/ `4c40d02c`（10-16 21:44） | 10-15 / 10-16 | 同期采集/回复引擎工作区的完整快照，可以和 A/B 配套 | 中 |
| 不推荐 | 10-27 冻结版 `a9ba360f` | 10-27 | 已在 UI 大改之后，并且 11-11 改过 | — |

**注意：** 采集/回复引擎（`自动获客系统\work\fangyu-douyin-independent` 等）一直在线上运行、持续更新，和界面是两条线。界面回退**不应该**带着回退引擎和账本。

---

## 6. 数据库 / 账本（只记路径、大小、表名）

共找到 3,294 个 SQLite 文件、4,398 个 jsonl、约 5.4 万个回执/账本类 json，合计约 **110 GB**。

| 文件 | 大小 | 表 | 状态 |
|---|---|---|---|
| `自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3` | **15.33 GB** | account_halts, attempts, collection_event_reviews, collection_halt_events, collection_scope_reviews, entities, excluded/expired_comment_fingerprints, items, ledger_metadata, observations, pages, recent_comment_*（3 张）, recovery_events, scan_pages, scan_streams, streams | **正在写**（14:13）。同名的 collection*.sqlite3 共 777 个，合计 83 GB |
| `...\runtime\runner-cache-v7.sqlite3` | 1.08 GB | admissions, comment_relations, comment_yield, counts, fingerprints, meta, qualified_comments, refs, videos | 正在写 |
| `自动获客系统\work\shared-acquisition-ledger\shared.sqlite3`（共享去重账本） | 28.4 MB | assessments, business_cleared_fingerprints, collection_uid_observations, historical_assessments, historical_deliveries, identity_aliases, leads, local_sender_plans, reservations, searches, words | **正在写**；另有 pre-full-history-backup、backup-20261028 两份 |
| `方隅公寓客户版\outputs\软件完整交接\方隅软件交接包\06-账本快照\共享业务账本.sqlite3` | 24.1 MB | 与 shared 相同的 11 张表 | 11-11 快照 |
| `workspace.sqlite3`（积木各轮工作目录，共 1,749 个，合计 1.14 GB，最大 74.9 MB） | — | contact_event_acks, contact_events, contact_response_acks/blocks/outbox, customer_followup_targets_v1, customer_read_epoch/insert_guard/revision_v1, records, sessions, unique_leads | 客户端工作库，是历史快照 |
| `Codex获客工作台\work\codex_reviews.sqlite3` / `campaign.sqlite3` | 149 MB / 33 MB | reviews, review_fullpasses, review_rechecks / checkpoint, comment_index, records, reply_queue, search_state, video_queue | 旧工作台 |
| `fangyu-text-business-20261029`（data 13.6 GB）、`_backup`（5.3 GB）、`outputs\方隅客户资料备份\方隅客户资料_20261027_234130.sqlite3`（46.6 MB）、`outputs\去重账本快照.sqlite3` | — | 未读 | 都含客户数据 |
| 答题：`free-ledger.js`、`AndroidRunLedger.kt`（代码）；线上数据在腾讯云 `fh6-d5ga45c0ddae7008c`，本机没有生产库 | — | — | 只有代码和本地测试账本 |

**迁移脚本：** 方隅没有单独的 migrations 目录，表结构变更写在各候选代码里，例如 `xhs-local-ledger-sender-candidate\migration_candidate.py`、`ledger.py`、`owned_ledger.py`。要做数据字典，需要在后续阶段从代码里提取 `CREATE TABLE`，或者对**副本**跑 `.schema`。

---

## 7. 配置与依赖清单

- 去掉可重建目录后，共找到约 5,560 个清单类文件：package.json、requirements*.txt、pyproject.toml、build.gradle(.kts)、project.config.json、cloudbaserc.json、*.spec、AGENTS*.md、README*、.gitignore。完整列表在 `inv/summary.json` 的 `mans` 字段里。
- 关键入口（来自桌面快捷方式）：

| 快捷方式 | 指向 |
|---|---|
| 方隅工作台（新版试用） | `desktop-python\Scripts\pythonw.exe -X utf8 -B ...\FangyuDesktopDirect-20261117\employee.py` |
| 方隅工作台（指错的旧版） | `pythonw.exe -X utf8 -B -I ...\work\ui-native-r57\run_workbench.py` |
| 方隅抖音工作台（本人） | `...\work\release-20261113\platform\owner_entry.py --ui` |
| 方隅抖音工作台（验收） | `...\work\release-20261113\client\employee.py` |
| Grok Build | wt → `Documents\GrokBuild\work\launch-grok.cmd` |

**可重建内容体积**（不进核心包，但要写清怎么恢复）：

| 类别 | 体积 |
|---|---|
| 积木 PyInstaller `_internal` | 77.3 GB |
| 积木 node_modules | 13.4 GB |
| 积木 Python 环境 | 4.5 GB |
| 积木浏览器 profile | 3.1 GB |
| 积木缓存 | 2.3 GB |
| 答题 AVD / 模拟器镜像 | 146 GB |
| 答题 node_modules | 19.5 GB + 3.1 GB |
| 答题 gradle | 6.9 GB + 14.5 GB |
| 方隅 `自动获客系统\.git` 散落对象 | 8.7 GB |
| 员工虚拟机 `employee-vm-machines\...\system.vhdx` | 29.2 GB（另有 VMRS 1.9 GB） |

---

## 8. 敏感信息位置（只记路径，没有读内容）

打包时这些位置**一律排除**，或者只放脱敏模板：

- **浏览器登录态 / profile**：
  - `FangyuDesktopDirect-20261114-state\employee-data\douyin-browser\<hash>\Default`
  - `work\ui-native-r57\state\webview2\EBWebView`
  - `work\profile-save-full-candidate-20261027`（669 MB）、`work\profile-native-validation-20261027`（657 MB）
  - `overnight-integration\...\isolated-native-storage\EBWebView`
  - `自动获客系统\work\desktop-qa`（Local State / Login Data）
  - `Documents\douyin_publish_staging\chrome_profile_copy`、`playwright_chrome_profile`
  - `Documents\接单号\douyin_profile_backup`
  - `.cache\chrome-devtools-mcp\chrome-profile`
- **Cookie / 会话 / 授权文件**：
  - `自动获客系统\work\xhs-standalone-session`（cookies.json、token_cache.json、session_imported.json）
  - `xhs-next78/180/final4-preparation`（user-authorization.json）
  - `account-verification-entry`（cookies.json）
  - `小红书工具选型评估\work`
  - `fresh-install-20261007\private-backup`（Trust Tokens、cookies.json）
  - `region-followup-20261027\region\v5`（auth-*.json）
  - `work\vendor`（browser-cookie.exe、cookie_extract.py）
  - 去掉可重建目录后，文件名命中敏感词的共 **4,155 个**。完整列表在 `inv/sens_db_prof.json`。其中不少是测试夹具（test-ca.pem、server-key.pem）或第三方源码里的 token.py，后续需要逐类判定。
- **签名 / 支付 / 云端**：
  - 方隅：`employee-update-20261009\pilot-signing-private`
  - 答题：`每日百题APP\work\{private-signing, payment-secret-prep, alipay-secure-2021007111679969, payment-pilot-private}`、`signing-config-versions.json`、keystore
  - `.config\.cloudbase`
- **用户目录级**：`C:\Users\rmsama\.ssh`、`.opencode.env`、`.emulator_console_auth_token`、`.claude.json`、`.codex`、`.xiaohongshu-cli`、`.dy`、`.douyin-skills`
- **客户隐私数据**：第 6 节的全部账本、`outputs\方隅客户资料备份`、各类 receipt/jsonl、box 上的 `douyin-pending-drafts.csv`、`有效评论样本-20261112.txt`、`class-reply-samples-50-*`

---

## 9. 打包体积估算（去掉可重建内容之后）

| 包 | 建议内容 | 原始体积估计 | 压缩后估计 |
|---|---|---|---|
| 01 核心源码 | 方隅代码去重 0.58 GB + 文档 0.12 GB；答题 0.2 GB；公共 0.34 GB | 约 1.3 GB | 0.3～0.5 GB |
| 02 历史稳定版 | ui-preview（29 MB）+ r57 `ebd9da3c`（24 MB）+ 备选 `8a7e4038`（144 MB 中约 72 MB 可重建）+ 10-15/16 引擎 tree | 约 0.2～0.5 GB | <0.2 GB |
| 03 当前版本 | FangyuDesktopDirect-20261117（26 MB）、release-20261113/14 的源码部分（约 180 MB）、引擎代码（不含账本）；答题 0.4.27 源码 + 云函数（约 60 MB，不含 node_modules） | 约 0.5～1 GB | 0.2～0.4 GB |
| 04 UI 与新功能 | r57 冻结版、独立界面工程、box 的 batch-01～09、openDoor 复刻、rollback 副本、11-14 试用壳 | 约 1～1.5 GB（图片多） | 约 1 GB |
| 05 Git | 答题小仓库 bundle（约 60 MB）+ AI-Backup + box 备份仓库；方隅 `.git` 原样 7.7 GB 另行决定 | 0.15 GB（不含方隅 `.git`） | 同左 |
| 06 数据库 | 表结构 / 数据字典 + 脱敏样本；**不带生产账本** | <50 MB | <20 MB |
| 07 文档 | 13 份交接文档 + box 现有 HANDOFF 等 | <50 MB | <20 MB |
| 可选 | 关键 APK / 安装器（0.4.24～0.4.27 每个约 6.6 MB；方隅 exe 等约 1～2 GB）；方隅 json/txt 运行证据去重 12.6 GB（**含客户内容，必须先脱敏**） | — | — |

**合计：** 核心 7 包压缩后约 **1.5～2.5 GB**，RMSAMA 剩余 226 GB 足够。如果连全部安装包、证据和图片原样都带上，会达到几十 GB 甚至上百 GB，不建议。

---

## 10. 无法获取或有风险的内容

1. **方隅没有提交历史**：没有 Commit ID 可回退，只能用目录快照代替。`自动获客系统\.git` 里有 48 个残留的 tmp_obj，可能是 Codex 写对象时中断留下的。
2. **实时账本正在写**（collection.sqlite3 15 GB、shared.sqlite3、runner-cache）：直接复制会得到不一致的副本。后续要用 SQLite 在线备份 API，或在采集/发送空闲时做副本，**不能打断现场**。按要求，生产账本本来也不进可上传的包。
3. **长路径**：部分路径超过 260 字符（如 `fangyu-text-business-20261029\douyin-registered-v2\...`），PS 5.1 和普通 zip 可能漏文件。打包要用支持长路径的工具（如 7-Zip，或 `\\?\` 前缀 / robocopy），已查：本机**没有 7-Zip**；系统 LongPathsEnabled=1，但 PowerShell 5.1 的 Compress-Archive 仍有限制，后续需选工具（Python zipfile 或装 7-Zip 需用户同意）。
4. **`V:\work`** 是 original-control 仓库的远端，这个盘现在不存在，远端已失效。
5. **线上 / 云端内容不在本机**：答题的腾讯云环境 `fh6-d5ga45c0ddae7008c`（云函数线上版本、数据库）、支付宝配置；方隅的腾讯云规则与管理员入口；蒲公英发布记录。只能靠本地备份（`部署前线上备份-20261117`、`回滚包-20261117`）间接保留。
6. **对话类历史**：Codex 对话只有 AI-Backup 的 codex-archived-threads（11-10）和 box 上的 codex-history 摘要；Grok Bot 各窗口的对话没有导出成文件。
7. **答题交接文档已过时**：zt045 交接书写的是 0.4.24。现在已有 0.4.25/26/27，线上云函数在 11-17 12:13/12:14 已经更新。0.4.27 还没在手机上实机验收，也没有真实付款测试。
8. **数据量下限**：扫描到 519.9 万 + 102.4 万个文件。因为长路径可能漏计，以及正在写的目录，数字会继续变。
9. **本盘点没有做内容级比对**：候选 B/C 是否真的用了认可的浅色 UI、和当前版本差了哪些功能，要等第二阶段 diff 后才能下结论。

---

## 11. 本目录里的原始盘点数据（box）

`/workspace/project-intake/fangyu/handover-20261117/inv/`

| 文件 | 内容 |
|---|---|
| `files.tsv.gz`、`files3.tsv.gz` | RMSAMA 全部扫描文件的路径、大小、修改时间（只有元数据） |
| `summary.json`、`agg3.json` | 目录汇总 |
| `git.txt`、`git3.txt` | 各仓库的分支、tag、stash、日志、状态 |
| `lnk.txt` | 桌面快捷方式指向 |
| `kwdirs.txt`、`ls2.txt`、`probe_out.txt` | 关键词目录与目录列表 |
| `sens_db_prof.json` | 敏感 / 账本 / profile 的路径列表（不含内容） |
| `r57_releases.tsv` | 327 个 r57 发布目录的时间线 |
| `*.ps1`、`*.py` | 本次使用的只读扫描脚本 |
