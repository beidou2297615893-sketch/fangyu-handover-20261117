# API_REFERENCE

本表由包内源码静态提取；未向生产接口发请求。API 的真实授权参数与返回结构以源码为准。

## 方隅当前本地工作台

`local_workbench.py::LocalWorkbenchBackend.dispatch(action,data,token)`：

- `employee_browser_open, employee_browser_status`
- `select_store, install_select_store`
- `board_action`
- `board_stats`
- `bootstrap`
- `employee_cloud_status`
- `employee_start`
- `local_drafts`
- `local_progress`

`board_actions.py::dispatch_board_action`：`start/resume` → 本地控制通道；`pause` → 原链路暂停；`ack` → 确认。不允许交接脚本调用这些动作。

前端 transport（`acceptance-release/web/backend.mjs`）沿用 `/api/workbench`、`/api/workbench/bootstrap`、`/api/workbench/platform`、`/api/workbench/customers`、`/api/workbench/customer` 等历史路径；当前后端只接上表明确支持的 action，旧业务功能多数仅作视觉壳，不要把旧 API 名当已接通。

## 知题云函数（当前目录名 03/quiz/current-0.4.27，其中已含 0.4.28 源码）

云函数 `dailyHundredBillingV1` / 入口 `production-entry.main`；`dailyHundredImportV1Event` / 入口 `index.main`。下列为源码中出现的 action / 路由字面量（不代表全部可直接调用，需检查鉴权）。

- `/api/billing/trial/activate`
- `/gateway.do`
- `cancel`
- `database.abortTransaction`
- `database.commitTransaction`
- `database.getDocument`
- `database.modifyDocument`
- `database.startTransaction`
- `diagnostic`
- `function`
- `migrate`
- `reserve`
- `status`
- `trial/activate`
- `trial/status`

## 生产操作禁令
- 只读状态接口在线 ≠ 真支付验收成功。未经本人明确同意，不得向正式地址下单/扣费。
- 不在文档中写 Token/签名/私钥/订单个人资料。
- 实际调用须由用户本人配置环境变量并在独立环境验证。