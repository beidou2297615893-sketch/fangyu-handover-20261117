# MASTER_HANDOVER — 方隅自动获客系统 + 知题/每日百题（2026-11-17）

接手的人或 AI 先读本文件，再按顺序读：AI_INSTRUCTIONS → BUSINESS_RULES → CURRENT_STATUS → TODO → KNOWN_BUGS → PROJECT_ARCHITECTURE → VERSION_COMPARISON → DEVELOPMENT_HISTORY → DATABASE_SCHEMA → API_REFERENCE → DEPLOYMENT → TESTING。

## 1. 两个项目一句话
- **方隅自动获客系统**：为杭州余杭“方隅公寓”在抖音/小红书上找租房意向客户（采集评论/作品 → 规则+模型判断意向 → 生成回复草稿 → 人工审核 → 发送），Windows 桌面工作台（Python 宿主 + WebView 前端）+ 若干后台脚本 + SQLite。
- **知题 / 每日百题**：安卓刷题 App（WebView 前端 + Android 壳 + 云函数），付费周/月套餐与 72h 试用。

## 2. 包结构（C:\方隅交接包-20261117\）
| 包 | 内容 | 关键点 |
|---|---|---|
| 01_CORE_SOURCE | 方隅工坊/引擎源码（fangyu）、知题全部源码（quiz）、box 上公共工具与脚本（box） | 已去掉依赖目录、运行数据、浏览器状态、二进制；重复文件只存一份（见 `restore_duplicates.py`） |
| 02_STABLE_HISTORICAL_VERSION | A 认可预览、B、C、r57 主目录 | 推荐 B，视觉基准 A |
| 03_CURRENT_VERSION | 11-17 现用安装、11-14 安装（只记 exe 哈希）、10-27 冻结、知题当前 | |
| 04_UI_AND_NEW_FEATURES | box 上的 UI 回滚素材、11-14 工作台源码副本、11-16/17 功能分支工作 | 可独立迁回的新功能都在这里 |
| 05_GIT_FULL_HISTORY | 重建的 `fangyu-version-history` bundle（9 个提交、4 个分支 + main、多个 tag（见 VERIFICATION_REPORT））+ 知题 6 个 git bundle | **重建历史，不是原始 git**；原 7.7GB `.git` 未复制 |
| 06_DATABASE_AND_MIGRATIONS | 8 个库的 schema.sql、虚构 fixture、行数 | 无任何真实数据 |
| 07_DOCUMENTATION_AND_HANDOVER | 13 份文档、旧交接/规则文档、打包工具、进度、校验报告、FILE_MANIFEST | |
| _LOCAL_ONLY_DO_NOT_UPLOAD | 历史里含疑似客户数据/密钥的 3 个 git bundle、排除清单 | **不要上传** |

## 3. 推荐版本
- 稳定历史版：**B** = commit `cc99c4f651e63f8540acfe0ae6d2682c08586478`（分支 `stable-pre-ui-overhaul`，2026-10-18 18:30）。
- 视觉基准：**A** = `f8608dad009ff7607a7c52a0801709a15276775b`（2026-10-18 12:17）。
- 当前：`current-20261117` = `f13f4949e3fa8ecf5b0265e5324c53a5e8fd0c55`（11-17 安装 `e7f01cc6` + 引擎当前代码）。
- 详见 VERSION_COMPARISON.md（回退会失去什么、哪些能单独迁回）。

## 4. 恢复步骤（最短）
1. 校验：`python -c` 或 PowerShell `Get-FileHash` 对照根目录 `SHA256SUMS.txt`。
2. 解压：用 Python `zipfile`（Windows 资源管理器/旧 unzip 可能乱码中文名）。每个 part 是独立 zip，解到同一目录。
3. 还原重复文件：`python restore_duplicates.py <解压目录> FILE_MANIFEST.csv`。
4. 版本史：`git clone fangyu-version-history-RECONSTRUCTED.bundle fangyu && git -C fangyu branch -a`。
5. 依赖与运行：DEPLOYMENT.md；数据库用 06 的 schema 建空库；配置/密钥按 DEPLOYMENT.md「安全配置恢复」由本人重新填。

## 5. 脱敏与没打包的东西
- 未打包：真实数据库与 jsonl 账本、浏览器配置/Cookie/登录态、员工数据、签名 keystore/支付私钥、.env 真值、截图（除 UI 预览）、exe/apk/大二进制（只记哈希）、依赖目录（node_modules、.venv、gradle、desktop-python、_internal 可重建）、原始 .git。
- 代码里的疑似密钥/手机号/sec_uid 改成 `[REDACTED:类型]` 的副本，清单在各包 `redactions.csv`。
- 客户字段较多的数据型 JSON 整份排除。

## 6. 硬性业务约束（不能违反）
见 BUSINESS_RULES.md 与 AI_INSTRUCTIONS.md。要点：不得打断正在跑的采集/发送；抖音、小红书各有唯一专责；对外回复默认草稿+人工审核；浅色旧 UI；不恢复已砍功能、不加未要求功能；不恢复旧员工密码认证；jingxuan 登录绝不进创作者中心；门店记住；四格缺数据显示“—”。

## 7. 已知未完成
TODO.md 的 T1–T7；KNOWN_BUGS.md；VERIFICATION_REPORT.md 里的“未验证”。
