# CURRENT_STATUS（截至 2026-11-17 下午，北京时间）

## 方隅自动获客系统
- **正在使用的安装**：`C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117`，桌面入口「方隅工作台（新版试用）.lnk」→ `desktop-python\pythonw.exe employee.py`；状态目录 `FangyuDesktopDirect-20261114-state`（门店已记住：杭州余杭方隅公寓）。`--self-test` PASS。交接时没有启动它的 GUI。
- **界面**：A 浅色视觉（42 个文件原样）+ 四格统计、门店记住、jingxuan 普通登录、一键启动/暂停。
- **后台业务**：抖音采集/发送和小红书由各自专责会话（抖音 f82b6180…，小红书 763ed36f…）持续运行；交接期间看到的 python 进程（例如 15:35 起的 `douyin-semantic-repair-v5\build_snapshot.py`）都是业务进程，交接过程没有碰。
- **数据规模（只读计数）**：采集 observations 129,730 / items 43,932；runner-cache refs 416,265 / videos 358,454；shared leads 20,805 / reservations 10,239；campaign records 18,014；codex_reviews 16,127。详见 06。
- **未完成**：见 TODO.md T1–T6（浅色 UI 的副屏/缩放、jingxuan+Bridge 真机链路、小红书 skip_continue、规则 round9 等）；KNOWN_BUGS.md。
- **未经验证**：11-17 安装在用户真实操作下的一键启动/暂停端到端；B/C 视觉与 A 是否一致。

## 知题 / 每日百题
- 最新构建 **0.4.28（versionCode 95）**，APK SHA256 `E8B75FF8B65B9D49334BF080D97A3DA09FC5DB1F090921747103D8C21927419C`，6,609,015 B，签名 Android Debug；0.4.27（code 94，`E9C7C20C…DBEDBF`）也在。
- 测试：web 76 通过；Android 单测 199 通过；云函数 plan-trial 11 通过。
- 云端：周/月套餐 + 72h 试用云函数 11-17 12:13/12:14 已部署。
- **未完成/未验证**：没有在手机上装 0.4.28；没有真实付款；“试用未写入数据库”原因未查明（TODO T7）。zt045（0.4.24、session_unavailable）的描述已过时。

## 交接包本身
- 见 MASTER_HANDOVER.md 和 VERIFICATION_REPORT.md。
