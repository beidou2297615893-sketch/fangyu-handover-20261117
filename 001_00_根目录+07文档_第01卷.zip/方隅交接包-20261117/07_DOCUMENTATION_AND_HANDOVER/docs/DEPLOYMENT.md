# DEPLOYMENT / 恢复与迁移

## 0. 解包
- 所有 zip 用 UTF-8 文件名标志写入。Windows 10+ 资源管理器、7-Zip、Python `zipfile` 可正确显示中文；部分 Linux `unzip` 会乱码，请用 `python3 -c "import zipfile,sys;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])" x.zip out/`。
- 各 partNN.zip 是**独立可解压**的 zip（不是分卷），全部解到同一目录即可还原该包完整结构。
- 每个包的 `_logs/<包>.manifest.csv` 列出 `status=duplicate` 的文件及其 `duplicate_of`（同内容只存一次）；需要完整路径时运行 `07/tools/restore_duplicates.py <解包目录> <manifest.csv>` 复制回去。
- bundle 分片：`copy /b a.bundle.part01+a.bundle.part02 a.bundle`（Windows）或 `cat a.bundle.part* > a.bundle`，再核 `05_GIT.bundles.result.json` 中的 bundle_sha256，然后 `git clone a.bundle repo`。

## 1. 方隅桌面端（当前版）
1. 建 Python 3.11 venv：`py -3.11 -m venv C:\fy\desktop-python`；依赖按 `acceptance-release/RELEASE.json` 与 `resources/backend-dependencies.json`（含版本与 SHA256）安装（pywebview、bottle、clr_loader、pythonnet 等）。原 venv 52.9MB 未打包（可重建）。
2. 解 03 `fangyu/20261117-install` 到 `%LOCALAPPDATA%\FangyuDesktopDirect-20261117`（新机器）；**不要在原机覆盖现有安装**。
3. 状态目录：设环境变量 `FANGYU_CANDIDATE_STATE` 指向新目录（默认 `%LOCALAPPDATA%\FangyuDesktopDirect-20261114-state`）。状态目录含浏览器资料、门店记忆，**未打包**；新机器需重新选门店、重新登录抖音。
4. 自检：`pythonw employee.py --self-test`；再用快捷方式启动。

## 2. 方隅引擎
- 代码：05 仓库 `engine/`（tag `snap/engine-current-20261117`）或 01 `rmsama/engines/auto-acquisition`。
- 数据库：用 06 `migrations/*.schema.sql` 建空库，或在**原机停写后**由用户本人复制 `collection.sqlite3`/`shared.sqlite3`（含 -wal/-shm 一并，或 `sqlite3 src ".backup dst"`）。真实账本不经过上传包。
- 运行时目录（runtime/、runner-live-*、receipts、evidence）已排除，不需要也不应迁移给第三方。

## 3. 知题
- 源码：03 `quiz/current-0.4.27/完整项目源码`（已含 0.4.28 修改）；修改前 `备份-20261117-编译前`；云函数 `云函数/`；回滚包与线上备份目录（若含 node_modules 已排除，需 `npm ci`）。
- 构建：JDK + Android SDK（原 `DailyHundredNativeBuild` 147GB 中约 139GB 为 SDK/AVD/Gradle 缓存，可重建）；英文路径下 `gradlew assembleProdRelease -PpaymentRelease=true -PphoneOnlyRelease=true`。
- 云函数部署：CloudBase CLI，环境 `fh6-d5ga45c0ddae7008c`；回滚按《生产部署差异与回滚-20261117.md》。

## 4. 安全配置恢复（脱敏说明）
包内所有 `[REDACTED:<类型>]` 都是被删除的真实值，类型含 assigned_secret / api_key_sk / aws_key / tencent_secretid / cookie_kv / jwt / private_key / base64_key / phone_cn / douyin_sec_uid / wechat_id / id_card_cn。恢复方式：
1. 由用户本人在新机器设置环境变量或本地 `.env`（不进仓库），例如 DeepSeek/模型 API Key、腾讯云 SecretId/SecretKey、支付宝应用私钥/公钥、Android 签名 keystore 与密码。
2. 被删除文件类别（只在本机保留）：浏览器 Profile/Cookie/会话（`*-state`、`douyin-browser`、`xhs-*-profile`、`EBWebView`）、签名私钥（`pilot-signing-private`、`*.jks/*.keystore`）、支付密钥目录（`payment-secret-prep`、`alipay-secure-*`）、`.env`、`bridge.json`、`local.properties`、`google-services.json`。
3. 每类排除的完整路径清单见 `_logs/*.excluded.csv`（reason=sensitive_dir / sensitive_name），脱敏文件清单见 `_logs/*.redactions.csv`（只含路径与类型，不含值）。
4. 本机 `C:\方隅交接包-20261117\_LOCAL_ONLY_DO_NOT_UPLOAD\` 中的 git bundle 含未脱敏历史，**只供本人本机恢复，禁止上传**。
