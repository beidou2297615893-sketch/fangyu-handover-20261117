# DEVELOPMENT_HISTORY

时间均为北京时间。来源：目录 mtime、r57 release 名（UTC 时间戳已换算）、Codex checkpoint、USER-CHANGE-LOG、HANDOFF、部署记录。方隅原仓库没有真实提交史，下列不是 git log。

## 方隅自动获客系统
| 时间 | 事件 | 证据/位置 |
|---|---|---|
| 09-17～09-24 | 第一代界面 `fangyuWorkspaceApp`，约 80 个 `界面改版备份_20260923_*` | 01 `rmsama/workshop/fangyu/work/...` |
| 10-05～10-15 | r55/r56 运行时、`v3-ui-approved-source44-candidate`（10-12）、`ui-core-completion`（10-15） | 01 |
| 10-13 18:35 / 22:22 | 引擎工作区 Codex checkpoint tree 15c5d08 | 05 tag `snap/engine-codex-20261013`（ad4baa4b） |
| 10-14～10-18 12:17 | **A 浅色 UI 预览定稿（用户认可）** | 02 A；05 `f8608dad` |
| 10-15 12:53 / 10-16 21:44 | 引擎 checkpoint ec152e8 / 4c40d02 | 05 `93bf9630` / `761a7566` |
| 10-16 15:31～10-17 23:36 | r57 原生宿主主目录 46 个 release | 02 `ui-native-r57_main-workdir/releases` |
| 10-18 18:30 | r57 B `ebd9da3c` | 02 B；05 `cc99c4f6`（stable） |
| 10-19～10-22 | r57 小步发布约 59 个（集成候选 v12～v38 等） | 01 parallel-integration |
| 10-22～10-24 | 商业集成（commercial-integration 110GB、parallel-integration 48GB），10-23 一天 145 个 release，体积 25→122MB | 01 |
| 10-25 09:56 | r57 C `8a7e4038`（改版前最后） | 02 C；05 `f1cf8bf3` |
| 10-25 13:06～10-27 | UI 大改：spacious → production → reference-fidelity → fidelity-correction → visual-restore | 01 |
| 10-27 21:29 | r57 FROZEN，最后 release `a9ba360f` | 03 `fangyu/20261027-freeze`；05 `f0e9d789` |
| 10-29～11-04 | 文字业务 `fangyu-text-business-20261029`、抖音本地批次、独立采集 `fangyu-douyin-independent` | 05 engine |
| 11-01 | `独立界面工程` | 01 |
| 11-08～11-10 | 规则升级（11-10 12:36 用户确认）、HANDOFF 首版、小红书 461 停线、UI 风格多轮讨论（主看板四格/悬浮窗） | 07 project-intake-docs |
| 11-11 | 品牌全称“方隅公寓”；预算槽/需求槽/地点槽修正，优先队列 869 条；小红书 30 天/7 天口径 | USER-CHANGE-LOG |
| 11-13～11-14 | release-20261113/14、`FangyuDesktopDirect-20261114`（exe）；batch-07/08 深色玻璃、batch-09 openDoor 复刻 | 03/04 |
| 11-14 22:04～11-15 22:00 | 工作台副本停在 22:04；五分钟进度 routine 至 11-15 22:00 停止 | 记忆记录 |
| 11-15 | 12 份交接给 Grok Build 的文档（openDoor/batch09 方向，已被 11-17 决定覆盖） | 07 handoff-to-grok-build |
| 11-16～11-17 | staged-round4～9 规则、xhs skip_continue、douyin-2484-fix 等 | 04 feature-work |
| 11-17 约12:15 | 用户授权：浅色认可 UI 覆盖本机正在用的安装 → `FangyuDesktopDirect-20261117`，自检 PASS | 03；05 `e7f01cc6` |
| 11-17 15:00 | 本次交接：引擎当前代码快照 | 05 `f13f4949` |

## 知题 / 每日百题
| 时间 | 事件 |
|---|---|
| 10-05 20:57～22:34 | tijing 上游 3 个提交（v0.7.7 tag），派生 dailyhundred/minimal/original-control |
| 10-23 13:51 | outputs/daily-hundred-app `codex/configurable-automation-v2` 单提交 |
| 11-08 | payment-runtime-complete 回归（cloud-056 仓库历史中） |
| 11-10 15:49 / 20:59 | cloud-056-repair、ui-yejin-isolated 单提交 |
| 11-15 | zt045 交接：0.4.24（code 91），测试失败 session_unavailable（已过时） |
| 11-17 | 支付调整：周/月套餐+72h 试用；云函数 12:13/12:14 上线；0.4.25/0.4.26/0.4.27（code 94）APK；之后 0.4.28（code 95）客户端显示修复，单测 199、web 76 通过 |
