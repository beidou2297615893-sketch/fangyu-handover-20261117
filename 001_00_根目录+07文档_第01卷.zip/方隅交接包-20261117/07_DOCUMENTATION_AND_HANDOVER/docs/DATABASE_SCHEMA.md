# DATABASE_SCHEMA（2026-11-17 约15:05 北京时间只读导出）

导出方式：`sqlite3` URI `mode=ro`（WAL 库）或 `mode=ro&immutable=1`（非 WAL 库，不计行数），`PRAGMA query_only=ON`，只读 `sqlite_master` 与 `count(*)`（每表 ≤5 秒），**未读取任何业务行内容**。各库计数不是同一时刻的原子快照（采集仍在写）。

| # | 来源库 | 日志模式 | 表数 | 说明 |
|---|---|---|---|---|
| 1 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3` | wal | 19 | 抖音独立采集账本（运行中，约15.3GB） |
| 2 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3` | wal | 9 | 抖音 runner 缓存 v7（约1.08GB） |
| 3 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3` | wal | 11 | 跨平台共享获客账本（leads/预留/已发，约28MB） |
| 4 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\campaign.sqlite3` | wal | 6 | Codex获客工作台 旧活动库（10-11 后未更新） |
| 5 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\codex_reviews.sqlite3` | wal | 3 | Codex 复核记录 |
| 6 | `C:\积木软件工坊\项目\方隅公寓客户版\work\region-followup-20261027\verification\actual-data-1793083003306682900\workspace.sqlite3` | wal | 13 | 客户端 workspace（验证实数副本 / 11-14 Preview state） |
| 7 | `C:\Users\rmsama\AppData\Local\FangyuDesktopPreview-20261114-state\employee-data\workspace.sqlite3` | rollback/unknown(header 1/1) | 10 | 客户端 workspace（验证实数副本 / 11-14 Preview state） |
| 8 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline\fixtures\real-source-check\derived.sqlite3` | wal | 11 | 文字业务本地规则流水线派生库（目录名 real-source-check，含真实来源，原件不打包） |

## 各表行数（只读 count）

### 1. `collection.sqlite3`

- 路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| account_halts | 5 |
| attempts | 33397 |
| collection_event_reviews | 15411 |
| collection_halt_events | 186 |
| collection_scope_reviews | 320 |
| entities | 43932 |
| excluded_comment_fingerprints | 9470 |
| expired_comment_fingerprints | 50974 |
| items | 43932 |
| ledger_metadata | 1 |
| observations | 129730 |
| pages | 0 |
| recent_comment_backfill | 0 |
| recent_comment_date_review | 0 |
| recent_comment_page_counts | 19082 |
| recovery_events | 25 |
| scan_pages | 33182 |
| scan_streams | 24306 |
| streams | 0 |

### 2. `runner-cache-v7.sqlite3`

- 路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| admissions | 364877 |
| comment_relations | 28539 |
| comment_yield | 13207 |
| counts | 24292 |
| fingerprints | 31046 |
| meta | 171 |
| qualified_comments | 27304 |
| refs | 416265 |
| videos | 358454 |

### 3. `shared.sqlite3`

- 路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| assessments | 7461 |
| business_cleared_fingerprints | 2319 |
| collection_uid_observations | 7331 |
| historical_assessments | 1869 |
| historical_deliveries | 5 |
| identity_aliases | 9730 |
| leads | 20805 |
| local_sender_plans | 509 |
| reservations | 10239 |
| searches | 1 |
| words | 1609 |

### 4. `campaign.sqlite3`

- 路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\campaign.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| checkpoint | 1303 |
| comment_index | 16127 |
| records | 18014 |
| reply_queue | 3639 |
| search_state | 262 |
| video_queue | 1887 |

### 5. `codex_reviews.sqlite3`

- 路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\codex_reviews.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| review_fullpasses | 21149 |
| review_rechecks | 3331 |
| reviews | 16127 |

### 6. `workspace.sqlite3`

- 路径：`C:\积木软件工坊\项目\方隅公寓客户版\work\region-followup-20261027\verification\actual-data-1793083003306682900\workspace.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| contact_event_acks | 0 |
| contact_events | 3 |
| contact_response_acks | 0 |
| contact_response_blocks | 0 |
| contact_response_outbox | 0 |
| customer_followup_targets_v1 | 0 |
| customer_read_epoch_v1 | 1 |
| customer_read_insert_guard_v1 | 0 |
| customer_read_revision_v1 | 1 |
| records | 20609 |
| sessions | 2 |
| sqlite_sequence | 1 |
| unique_leads | 3069 |

### 7. `workspace.sqlite3`

- 路径：`C:\Users\rmsama\AppData\Local\FangyuDesktopPreview-20261114-state\employee-data\workspace.sqlite3`
- 计数策略：not WAL: schema only via immutable read; row counts skipped to avoid holding locks on a live DB

| 表 | 行数 |
|---|---|
| contact_event_acks | —（未计数） |
| contact_events | —（未计数） |
| contact_response_acks | —（未计数） |
| contact_response_blocks | —（未计数） |
| contact_response_outbox | —（未计数） |
| customer_followup_targets_v1 | —（未计数） |
| records | —（未计数） |
| sessions | —（未计数） |
| sqlite_sequence | —（未计数） |
| unique_leads | —（未计数） |

### 8. `derived.sqlite3`

- 路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline\fixtures\real-source-check\derived.sqlite3`
- 计数策略：exact count, each table max 5 seconds; running DB is not atomic across DBs

| 表 | 行数 |
|---|---|
| candidates | 2692 |
| exceptions | 10 |
| meta | 6 |
| observations | 20524 |
| qualified | 1313 |
| result_identities | 12419 |
| result_topics | 4508 |
| results | 12419 |
| runs | 2 |
| source_audits | 8 |
| videos | 2460 |

## 未导出 / 限制
- 未复制任何正在写入的 DB 原件，也未复制历史备份库（`fangyu-douyin-independent\*-backup*\collection.sqlite3` 等 13 个以上，0.07–9.2GB），只在本文件与排除清单中记路径。
- 知题线上数据库（腾讯云 CloudBase 环境 `fh6-d5ga45c0ddae7008c`）未连线导出；结构以 03 包 `quiz/current-0.4.27/云函数` 源码和《套餐和试用规则说明.md》为准。
- `fixtures/*.FICTIONAL.sqlite3`：按真实 schema 建表（含索引），每表 2 行明显虚构值（DEMO-*、2026-01-0x、{"fictional":true}）。单例/唯一约束表可能只有 1 行。
- 建空库：`sqlite3 new.sqlite3 < migrations/03_shared.schema.sql`。真实数据迁移只能由用户本人在本机拷贝（停写后或用 sqlite `.backup`），不经过上传包，见 DEPLOYMENT.md。
