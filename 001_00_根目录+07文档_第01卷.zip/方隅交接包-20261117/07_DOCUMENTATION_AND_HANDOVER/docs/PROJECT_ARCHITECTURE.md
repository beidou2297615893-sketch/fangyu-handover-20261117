# PROJECT_ARCHITECTURE

更新：2026-11-17（北京时间）。基于本机目录盘点、版本快照内容比对和已有交接文档；未运行任何业务程序。

## 1. 三个资产域

| 域 | 原始位置（RMSAMA，Windows） | 交接包位置 | 说明 |
|---|---|---|---|
| 方隅自动获客系统：桌面客户端 | `C:\积木软件工坊\项目\方隅公寓客户版`（342GB，约426万文件，大量嵌套副本） | 01 `rmsama/workshop/fangyu`；02/03/04；05 仓库 `desktop-ui/*` | 员工使用的桌面壳（Python + WebView 前端）；当前安装 `AppData\Local\FangyuDesktopDirect-20261117` |
| 方隅自动获客系统：获客引擎/账本 | `C:\Users\rmsama\Documents\ChatGPT\自动获客系统`（142GB） | 01 `rmsama/engines/auto-acquisition`；05 仓库 `engine/` | 抖音采集与发送、共享账本、规则、小红书、Bridge（`抖音自用采集台`）、Codex 获客工作台 |
| 答题小程序 / 每日百题 / 知题 | `C:\Users\rmsama\Documents\ChatGPT\答题小程序`（186GB）、`C:\Users\rmsama\DailyHundredNativeBuild`（147GB，约139GB可重建）、桌面 `知题-支付调整完整开发包`（最新）、桌面 `知题-完整项目最终存档`（0.4.24） | 01 `rmsama/quiz/*`；03 `quiz/current-0.4.27`；05 各 quiz bundle | Android 原生壳 + 内嵌 Web（Vite）+ 腾讯云 CloudBase 云函数（计费/导入） |
| 公共工具 | box `/workspace/tools`（deepseek 调用器等）、AI-Backup（RMSAMA `Documents\AI-Backup`，box `~/.local/share/ai-backup`）、工坊 `核心组件/设计方法库/自用工作台/小红书CLI独立试用` | 01 / 04 `box/common/*` | 备份守护、模型调用、通用组件 |

## 2. 方隅运行架构（当前 2026-11-17）

```
员工双击 桌面「方隅工作台（新版试用）.lnk」
  → C:\积木软件工坊\项目\方隅公寓客户版\work\desktop-python\Scripts\pythonw.exe（Python 3.11.15 venv，可重建，未打包）
  → AppData\Local\FangyuDesktopDirect-20261117\employee.py
       ├─ control_window.py / local_workbench.py / board_state.py / board_actions.py（启动/暂停一键、四格统计）
       ├─ douyin_board_stats.py（今日采集/今日回复/有效池加减/累计，缺失为“—”）
       ├─ install_store.py + local_stores.json（门店选一次记住）
       ├─ system_browser_login.py（只开普通抖音 https://www.douyin.com/jingxuan，经既有 Bridge；绝不打开创作者中心）
       └─ acceptance-release/ui_native_host.py + web/（浅色“方隅工作台/渠道运营”UI，复用 A 版 ui-preview 资源）
  状态目录（不打包，含浏览器资料）：AppData\Local\FangyuDesktopDirect-20261114-state
引擎（独立进程，由抖音/小红书专责窗口操作）：
  自动获客系统\work\fangyu-douyin-independent（collection.sqlite3 15.3GB、runner-cache-v7）
  自动获客系统\work\shared-acquisition-ledger\shared.sqlite3（跨平台 leads/预留/已发）
  自动获客系统\work\douyin-local-control、抖音自用采集台（Bridge）、xhs-*（小红书）
  自动获客系统\work\fangyu-text-business-20261029（文字业务/规则流水线）
```

## 3. 桌面 UI 代际

| 代 | 位置 | 技术 | 状态 |
|---|---|---|---|
| A ui-preview（10-14～10-18） | `work\ui-approved-implementation\ui-preview` | 纯前端 mjs + `server.cjs` 预览 | 用户 10 月认可、11-17 再确认的浅色 UI；11-17 安装直接复用其大部分文件 |
| r57 原生宿主（10-16～10-27） | `work\ui-native-r57`（主目录 46 个 release，10-16～10-17）；B/C/冻结版在 `parallel-integration-20261018\final-integration\candidate-unified-v6/v107` 与 `combined-full-candidate-20261027` 的嵌套副本里 | `ui_native_host.py` + web + `redesign.css` | 功能最全的一代；10-25 起“宽松/生产/还原”多轮改版 |
| 10-25 以后改版 | `ui-spacious-redesign-20261025`、`ui-production-redesign-20261025`、`ui-reference-fidelity-20261025`、`ui-fidelity-correction-20261025`、`ui-visual-restore-20261027`、`独立界面工程`（11-01） | | 用户未认可，作为历史保留在 01 |
| 11-14 试用壳 | `AppData\Local\FangyuDesktopDirect-20261114`（PyInstaller exe，SHA256 5B24E844…D0B1；与 backup-20261117 完全一致） | 源码在 box `fangyu-workbench-copy-20261114`（04 包） | 已被 11-17 新入口替代，未删除 |
| openDoor / batch-09 深色玻璃 | box `fangyu-opendoor-replica`、`project-intake/fangyu/ui-design/batch-0x` | | 11-17 用户改定浅色后不作目标；用户另提“以 openDoor 动效为基础”的想法见 TODO |
| 11-17 当前 | `AppData\Local\FangyuDesktopDirect-20261117`；源码副本 box `fangyu-ui-rollback-20261117/work/production-desktop` | A 的视觉 + 现有一键/四格/门店/jingxuan 逻辑 | 已部署、`--self-test` PASS；未经员工实际使用验收 |

## 4. 知题架构
- 包名 `com.jimusoft.dailyhundredapp`；Android 原生（Kotlin/Gradle）+ `assets/web`（Vite 构建）。
- 云：腾讯云 CloudBase 环境 `fh6-d5ga45c0ddae7008c`；云函数 `dailyHundredBillingV1`（入口 `production-entry.main`）、`dailyHundredImportV1Event`（`index.main`）；网关 `https://1439321968-1w2zycn1o6.ap-shanghai.tencentscf.com`。
- 计费：周 4.9 元/7 天（490 分）、月 9.9 元/30 天（990 分）；首次激活 72 小时服务端试用；旧 100 分、590 分订单兼容。
- 最新包：0.4.28（versionCode 95，**Debug 证书签名**），0.4.27（code 94）仍在；原 `release-mobile` 工程仍是 0.4.24/code 91。
