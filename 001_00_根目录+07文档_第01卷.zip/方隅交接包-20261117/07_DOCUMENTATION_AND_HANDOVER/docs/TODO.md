# TODO（在制任务交接，八要素）

> 所有“状态”均为 2026-11-17 交接时根据文件与记录判断；没有亲自运行业务程序验证的写“未验收”。

## T1 浅色认可 UI 落地到当前安装
- 需求：用户认可浅色“方隅工作台/渠道运营”旧 UI；保留现在的功能、留白、一键；不恢复旧员工密码认证；四格统计；门店记住；jingxuan。
- 已完成：11-17 部署到 `AppData\Local\FangyuDesktopDirect-20261117`，入口桌面「方隅工作台（新版试用）.lnk」；`--self-test` PASS；旧安装与备份保留。
- 文件：03 `fangyu/20261117-install/`；box 源码 `04 box/fangyu/ui-rollback-20261117/work/production-desktop`；对照表 `docs/页面对照表.md`；05 tag `install/FangyuDesktopDirect-20261117`。
- 状态：已部署，未经员工完整使用验收。
- 遗留：客户/规则/账号等旧页只作视觉壳；“方隅工作台”侧栏品牌与对外名“方隅自动获客系统”并存。
- 下一步：在不影响采集/发送的时段，用户本人打开新入口走一遍：门店→登录 jingxuan→启动→暂停→四格。
- 测试：`employee.py --self-test`；TESTING.md T-UI-1～6。
- 可迁移性：高。纯 Python + 静态 web，依赖 desktop-python（pywebview 等，可按 requirements 重建）。

## T2 openDoor 动效复刻
- 需求：11-17 用户提出以 openDoor 网页及动效为界面基础，筛选可用动效并嵌入方隅功能（与 T1 并行、各做各的）。
- 已完成：box `fangyu-opendoor-replica`（04 包）复刻页面与 batch-09 四态截图（11-14 23:19 左右后无源码更新）；占位 API 127.0.0.1:18765 硬闸门。
- 文件：04 `box/fangyu/opendoor-replica`、`box/fangyu/ui-design-batches-01-09`。
- 状态：设计/原型阶段；未接真链路；与 11-17 浅色定稿关系需用户确认（只取动效，不改浅色主视觉？）。
- 遗留：node_modules 未打包（npm install 重建）；页面动效与浅色 UI 未融合。
- 下一步：先问用户一句“openDoor 只借动效、保留浅色画风对吗？”再做。
- 测试：本地 `npm install && npm run dev`（见目录 package.json）；截图对比 batch-09。
- 可迁移性：高（前端独立）。

## T3 窗口缩放 / 副屏
- 需求：窗口可放大、缩小、最大化，画面铺满；用户副屏在左。
- 已完成：11-17 安装 README 写明可缩放/最大化；A 版自带 `canvas-fit.*`、`fit.*`、`pane-scroll.mjs`。
- 文件：03 `fangyu/20261117-install/employee.py`、`acceptance-release/web/canvas-fit.css|mjs`、`fit.css|mjs`。
- 状态：代码就绪，实机多分辨率/副屏未验收。
- 遗留：负坐标副屏（在左）上的窗口位置记忆未见专门处理。
- 下一步：按 TESTING T-UI-4 在 1366×768、1920×1080、副屏左侧各试一次。
- 测试：截图存 Desktop 给用户看（用户看不到聊天图片）。
- 可迁移性：高。

## T4 普通抖音 jingxuan 登录 + Bridge
- 需求：只开 `https://www.douyin.com/jingxuan`，接既有 Bridge，绝不打开创作者中心。
- 已完成：`system_browser_login.py`（641 字节）与 `local_workbench._browser` 已实现 employee_browser_open/status。
- 文件：03 `fangyu/20261117-install/system_browser_login.py`、`local_workbench.py`；Bridge 源码 01 `rmsama/engines/auto-acquisition/抖音自用采集台`。
- 状态：静态核对；未在现场点击（避免干扰）。
- 遗留：Bridge 端口/会话属于运行时状态，不在包里。
- 下一步：用户在场时点一次“登录”，确认打开的是 jingxuan。
- 测试：TESTING T-UI-3；grep 确认代码中无 creator.douyin.com。
- 可迁移性：中（依赖本机 Edge/Bridge 与登录态，需本人重新登录）。

## T5 小红书 skip_continue
- 需求：小红书发送遇到可跳过的单条失败时隔离跳过、继续下一条（H3），不重发已提交项。
- 已完成：box `xhs-send-skip-continue-20261117/skip_continue.py`（04 包 `box/fangyu/feature-work/`）。另有 `xhs-progress-window`、`xhs-heldfix-mirror`。
- 状态：代码草案；是否部署到用户机未在本交接确认。
- 遗留：需与小红书唯一专责窗口 763ed36f 的最新报告核对。
- 下一步：离线用虚构数据跑；部署必须由小红书专责在不发送时进行。
- 测试：构造“单条失败→跳过→下一条成功”与“重启不重发”两例。
- 可迁移性：中。

## T6 规则 round9
- 需求：筛选规则第 9 轮升级（business_fit）。
- 已完成：box `staged-round9/`：business_fit.py、live-business_fit.py、round9_append.py、test_round9.py、verify_round9.py、deploy_backup.py（04 包）。round4～8 亦在。
- 状态：staged（暂存）；是否已上线未确认。
- 遗留：上线需先 deploy_backup，再在不采集时替换，不能边跑边换。
- 下一步：`python test_round9.py`（box 可跑，只用样例），对比 live-business_fit.py 差异，再问用户/专责是否上线。
- 测试：test_round9.py、verify_round9.py。
- 可迁移性：高（纯 Python）。

## T7 知题 0.4.28 实机验收与支付
- 需求：周/月套餐 + 72h 试用；修客户端权益文案。
- 已完成：0.4.27 云函数部署（11-17 12:13/12:14）、0.4.28 APK 编译，单测 199 项通过、web 76 项通过。
- 文件：03 `quiz/current-0.4.27/`（含 0.4.28 文档与源码；APK 二进制未打包，只记 SHA256）。
- 状态：未手机安装、未真付款；试用未落库原因未知。
- 遗留：见 KNOWN_BUGS 知题 1–10；APK 为 Debug 签名。
- 下一步：用户本人同意后装 0.4.28 实机测试；查试用落库日志；准备正式签名。
- 测试：`:app:testProdDebugUnitTest`（英文路径）、web `npm test`、云函数 `plan-trial.test.js`。
- 可迁移性：中（需要 Android SDK/JDK/Gradle 与 CloudBase 账号；密钥由本人配置）。
