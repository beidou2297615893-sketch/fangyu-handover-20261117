# VERSION_COMPARISON（方隅桌面端）

比对方法（2026-11-17 实测）：把 A/B/C/10-27 冻结/11-14/11-17 六个快照按同一过滤规则取出，对前端目录逐文件 SHA1/SHA256 比较；11-14 两个 exe 做 SHA256。未运行任何版本的 GUI（避免干扰现场）。

## 1. 六个版本

| 代号 | 原路径 | 时间（北京） | 新仓库 commit / tag | 内容 |
|---|---|---|---|---|
| A | `work\ui-approved-implementation\ui-preview`（+screenshots、page-fidelity-review） | 10-14～10-18 12:17 | `f8608dad009ff7607a7c52a0801709a15276775b` / `ui/A-approved-preview-20261018`，分支 `ui-approved-A-20261018` | 用户认可的浅色 UI，纯前端预览（60 个 web 文件，35 个 mjs/css/html） |
| B | `work\parallel-integration-20261018\final-integration\candidate-unified-v6\project\work\ui-native-r57\releases\ui-r57-20261018T103009Z-ebd9da3c`（主 r57 目录里只有其启动脚本） | 10-18 18:30 | `cc99c4f651e63f8540acfe0ae6d2682c08586478` / `r57/B-20261018T103009Z-ebd9da3c`，**分支 `stable-pre-ui-overhaul`** | 完整 r57 程序：ui_native_host + customer/reply/rental/store 工作台 py + web（58 文件，`redesign.css` 首行注明 “Approved 2026-10-18 layout”） |
| C | `...candidate-unified-v107\...\ui-r57-20261025T015609Z-8a7e4038` | 10-25 09:56 | `f1cf8bf30102ed7c5b348e74e84a9b3d9e080aa8` / `r57/C-...`，分支 `candidate-pre-overhaul-C-20261025` | 10-25 13:06 改版前最后一个 r57；web 80 文件/71 代码，新增 ~40 个页面模块 |
| F | `work\combined-full-candidate-20261027\project\work\ui-native-r57\releases\ui-r57-20261027T130512Z-a9ba360f` | 10-27 21:29 冻结 | `f0e9d7896c8460c765afb5951106b7aee97ed372` / `r57/F-freeze-...` | 改版后冻结版，web 159 文件；部分文件 11-11 又改 |
| 11-14 | `AppData\Local\FangyuDesktopDirect-20261114` | 11-14 | 不入仓（PyInstaller exe）；源码在 04 `box/fangyu/workbench-copy-20261114` | exe SHA256 `5B24E8449E92622B5EF9F6C59865ECCC5AFD7ACB40EB3614445CC78CBD39D0B1`，与 `-backup-20261117` 完全相同 |
| 11-17 | `AppData\Local\FangyuDesktopDirect-20261117` | 11-17 约12:15 | `e7f01cc6cef0cded117119a333365f5f553ad688` / `install/FangyuDesktopDirect-20261117` | 当前安装：A 的视觉 + 一键/四格/门店/jingxuan |

## 2. 内容重合（同路径同内容的文件数）
| | A | B | C | F | 11-17 |
|---|---|---|---|---|---|
| A | — | 0 | 0 | 1 | **42** |
| B | | — | 0 | 8 | 33 |
| C | | | — | 39 | 9 |
| F | | | | — | 0 |

结论：
- **11-17 当前版 = A 的前端**：A 的 42 个文件原样复用；只改了 `app.mjs`、`backend.mjs`、`canvas.html`、`index.html`、`pages/acquire.mjs`、`pages/reply.mjs`，新增 `pages/home-control.css` 和一批 fy-icon/tabler 图标资源与许可证。
- B、C 的前端代码与 A **没有一份相同**（B 用 `redesign.css`+`platform-ui.mjs` 另写了一套 10-18 布局）。所以“用户认可的视觉”严格说只有 A；B/C 是否在视觉上与 A 一致，本次没有运行截图证实。
- C 与 F 共享 39 个文件，说明 10-23～10-25 商业集成内容延续到了冻结版；F 与 11-17 零重合。

## 3. 推荐
**稳定历史版本（可运行整机）：B — commit `cc99c4f6`（分支 `stable-pre-ui-overhaul`），2026-10-18 18:30。**
- 理由：A 获认可后同日出的第一个完整程序；早于 10-22/23 商业集成体积暴增（25MB→122MB）和 10-25 13:06 UI 大改；`redesign.css` 声明为 10-18 认可布局；文件少、依赖少、风险低。
- **视觉基准仍是 A**（commit `f8608dad`），11-17 现行版本就是 A 视觉，因此日常使用**不需要回退**；B 只作“需要整机回到改版前”时的回退点。
- 回退到 B 会失去：11-17 的四格统计（今日采集/今日回复/有效池加减/累计，缺失“—”）、门店记住、jingxuan 普通登录入口、启动/暂停一键接本地控制通道、窗口缩放铺满；C 的 10-19～10-25 新增模块（客户意向修正、关键词效果、内容运营、直播获客、知识文件导入、私信/批量回复、AI 模型页等）；F 及以后的规则与地域修正。
- 可独立迁回 B 的新功能：`douyin_board_stats.py`（四格）、`install_store.py`+`local_stores.json`（门店记住）、`system_browser_login.py`（jingxuan）、`board_actions.py`（一键）——它们是独立小模块，只依赖本地状态目录；C 的 `pages/keyword-effect.*`、`customer-intent-correction.mjs` 等前端模块可单独移植但需对应后端 py（`keyword_effect_workbench.py`、`customer_intent_workbench.py`）。
- 备选 C（`f1cf8bf3`）：要保留 10-23/24 商业集成功能时用，但 10-23 起已开始变化，视觉不保证。
- 不推荐：F（改版后，11-11 被改过）、11-14 exe（已被替代，源码在 box 副本）。

## 4. 未做/限制
- 未在任何机器上启动 B/C/F 的 GUI 做截图比对；视觉一致性只基于代码与 A 截图。
- 原 r57 主目录只有 46 个 release（10-16～10-17）；B/C/F 只存在于集成候选的嵌套副本中。第一阶段报告“327 个 release”是全树重复计数，已更正。
