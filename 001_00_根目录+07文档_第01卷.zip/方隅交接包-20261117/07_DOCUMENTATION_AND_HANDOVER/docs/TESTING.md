# TESTING

## 交接包自身校验（已执行，结果见 07 `VERIFICATION_REPORT.md`）
- 每个 zip：Python `zipfile.testzip()` 全部 CRC 通过；记录条目数、未压缩字节数、SHA256。
- 每个 bundle：`git bundle verify`。
- `SHA256SUMS.txt`：`sha256sum -c SHA256SUMS.txt`（Linux）或 `Get-FileHash`（Windows）。

## 方隅（离线，可在新机器做）
| 编号 | 内容 | 方法 |
|---|---|---|
| T-UI-1 | 当前安装自检 | `python employee.py --self-test`（需 desktop-python 依赖；设 `FANGYU_CANDIDATE_STATE` 指到空目录，避免碰原状态） |
| T-UI-2 | A 版预览 | `cd 02/fangyu/A_*/ui-preview && node server.cjs` 或 `start-preview.ps1`，比对 `screenshots/*.png` |
| T-UI-3 | 登录只到 jingxuan | 搜源码无 `creator.douyin.com`；手点登录看打开网址 |
| T-UI-4 | 窗口缩放/副屏 | 1366×768、1920×1080、左侧副屏，最大化/还原 |
| T-UI-5 | 四格缺数据为“—” | 空状态目录启动看四格 |
| T-UI-6 | 门店记住 | 选一次门店后重启仍记住 |
| T-ENG-1 | 规则 | `staged-round9/test_round9.py`；引擎 `tests/`（05 仓库 engine/tests） |
| T-DB-1 | 空库建表 | `sqlite3 x.db < 06/migrations/03_shared.schema.sql` |
| T-DB-2 | 虚构样例 | 06/fixtures/*.FICTIONAL.sqlite3 |

**禁止**：在用户现场机做发送/采集测试，除非用户明确授权且由唯一专责操作。

## 知题
- Web：`npm test`（11-17 记录 76 通过）。
- Android：英文路径下 `gradlew :app:testProdDebugUnitTest`（11-17 记录 199 通过）；`assembleProdRelease -PpaymentRelease=true -PphoneOnlyRelease=true`。
- 云函数：`node plan-trial.test.js`（11 通过）；不要以 package.json 的 npm test 为准。
- 实机/真支付：未做，须用户本人同意。
