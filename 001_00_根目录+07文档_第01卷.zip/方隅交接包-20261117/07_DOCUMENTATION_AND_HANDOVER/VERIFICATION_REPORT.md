# VERIFICATION_REPORT
生成：2026-11-17 17:07:42（北京时间，RMSAMA 本机）

- zip 卷数：16，全部 testzip OK 且 ≤95MiB：是
- 最大卷：93.72 MiB
- git bundle：10 个（其中 LOCAL_ONLY 3 个），verify 失败：0
- 重建仓库 clone 测试：脚本内失败（Windows 路径过长导致检出中断，非 bundle 问题）；用 core.longpaths=true 人工复核：clone OK、fsck OK、9 个提交，见文末「克隆复核」
- stable-pre-ui-overhaul = cc99c4f651e63f8540acfe0ae6d2682c08586478；current-20261117 = main = f13f4949e3fa8ecf5b0265e5324c53a5e8fd0c55

## zip

| 包 | 文件 | MiB | 条目 | 解压后字节 | testzip | SHA256 |
|---|---|---|---|---|---|---|
| 01_CORE_SOURCE | 01_CORE_SOURCE.box.part01.zip | 8.89 | 1,516 | 28,459,623 | OK | `2560dd684e6407154fe960d95bdfafafd2993baa2a354c753c8f053bbb43942e` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.fangyu.part01.zip | 93.6 | 21,982 | 331,249,205 | OK | `aed7ec9a0dae69fcd90d758f40edb4df4673f4d8fba9d5abbb9fe15bd977ffeb` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.fangyu.part02.zip | 93.72 | 24,800 | 348,442,280 | OK | `00c808afd4d76b947593c8db2dcd85d556e712005b71a8984be945eb0c7c55c4` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.fangyu.part03.zip | 67.67 | 14,521 | 157,935,867 | OK | `88280c3f6de583275881715407babe026a5fa4c3938a3f96b7f3713d775b3bef` |
| 01_CORE_SOURCE | 01_CORE_SOURCE.quiz.part01.zip | 53.11 | 12,391 | 117,560,779 | OK | `fd00243f74c1e57aed8b6e9cc0afa2c49fc14338261cb45db27206df2764cc9a` |
| 02_STABLE_HISTORICAL_VERSION | 02_STABLE_HISTORICAL_VERSION.fangyu-ui.part01.zip | 35.27 | 931 | 50,246,331 | OK | `926be86ea6ebebac7600299c483610638f522f3ae367c2c52e4319df860d5bfe` |
| 03_CURRENT_VERSION | 03_CURRENT_VERSION.rmsama.part01.zip | 49.72 | 857 | 63,902,476 | OK | `21c2baa37cf365f17e043ecc817f52491799b863fd18934bc7d39c9e035f6217` |
| 04_UI_AND_NEW_FEATURES | 04_UI_AND_NEW_FEATURES.box.part01.zip | 87.43 | 337 | 93,552,054 | OK | `600926faf3c2f5cba88b830ae63354d4ae4334f1def28af6915af7c0ec13c996` |
| 04_UI_AND_NEW_FEATURES | 04_UI_AND_NEW_FEATURES.box.part02.zip | 87.29 | 8,940 | 144,572,176 | OK | `ebc95b30cfa941c2c42271acdd5d9cc9035525e4c307a59b2c9f03b7d139a1c7` |
| 06_DATABASE_AND_MIGRATIONS | 06_DATABASE_AND_MIGRATIONS.part01.zip | 0.04 | 18 | 935,414 | OK | `6e858c1d713efe0bcb46f406fe5d070aa26e3d39153a1d01149a692f1eeb2798` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part01.zip | 17.54 | 2 | 197,793,432 | OK | `1da060698f5ead33836ccd6a3364d4e703941f62edc9a343f20ade38fcd274a4` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part02.zip | 18.02 | 1 | 197,980,903 | OK | `8c809faddc384bc17cf47bb22718330de030d15223e11e4e93708e0486a2701a` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part03.zip | 19.33 | 1 | 198,864,565 | OK | `162160fcf4b401cc095365602e80456c2f62268b912f1312c9fb204b0c4c28da` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part04.zip | 11.94 | 31 | 101,636,811 | OK | `752094a8a7923bf0b9b11375cb6373e55003160b882b1e892c9385ff5619299d` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs.part01.zip | 1.57 | 271 | 5,769,388 | OK | `1154be28aa824d8a4ff9bb368a55b4d72a92b3f52848f3df42d52a6b9eefd41f` |
| 07_DOCUMENTATION_AND_HANDOVER | 07_DOCUMENTATION_AND_HANDOVER.handover-docs.part01.zip | 1.2 | 54 | 9,066,823 | OK | `9381ce7d79eaf90e50ffa0d6e2b777eaaa40d549be01246bde20ee9feb5ccdeb` |

## git bundle

| 文件 | 字节 | refs | verify | SHA256 |
|---|---|---|---|---|
| 05_GIT_FULL_HISTORY\fangyu-version-history-RECONSTRUCTED.bundle | 89,470,847 | 15 | OK | `93f07a54cddf47cfa509bba17900878abcd7f464e68d0a17fc74aeaa1053f231` |
| 05_GIT_FULL_HISTORY\quiz-desktop-final-archive-daily-hundred-app.bundle | 1,409,630 | 3 | OK | `2bad3d6d47a4aeef18785d03ac34495a5f0434c01584d6401d3b920acf5a31f1` |
| 05_GIT_FULL_HISTORY\quiz-original-control-source.bundle | 1,346,416 | 5 | OK | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| 05_GIT_FULL_HISTORY\quiz-outputs-daily-hundred-app.bundle | 1,409,630 | 3 | OK | `2bad3d6d47a4aeef18785d03ac34495a5f0434c01584d6401d3b920acf5a31f1` |
| 05_GIT_FULL_HISTORY\quiz-tijing-dailyhundred.bundle | 1,346,416 | 5 | OK | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| 05_GIT_FULL_HISTORY\quiz-tijing-minimal.bundle | 1,346,416 | 5 | OK | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| 05_GIT_FULL_HISTORY\quiz-tijing-upstream.bundle | 1,346,416 | 5 | OK | `8ef75b8630dfcc98e7db8fd3e6f4f5065d81cd4504f883632c7cea813af2ddeb` |
| _LOCAL_ONLY_DO_NOT_UPLOAD\git-bundles\quiz-cloud-056-repair.bundle | 23,926,722 | 2 | OK | `d1dcd74ed32f8d0e38af77837b01f01ce0840f6d12a14e452787c65d42d06dc0` |
| _LOCAL_ONLY_DO_NOT_UPLOAD\git-bundles\quiz-ui-yejin-isolated.bundle | 24,606,999 | 3 | OK | `d4032a5d2390ecb2abc5fddf7bba3e45255ab6917996263e626921c832ed4f22` |
| _LOCAL_ONLY_DO_NOT_UPLOAD\git-bundles\rmsama-AI-Backup.bundle | 3,574,774 | 2 | OK | `efe1b9b10a5207036f11307fe4a4f851c4d566eb73e4506e40bbea06c12c0a06` |

## 重建仓库

分支：

tag：

```
```

## 未在此处验证
- 未在新机器上实际解压全部包并运行程序；未运行 GUI；B/C 视觉未渲染比对。
- 空 git 仓库（tijing-bankassist 等 4 个）无法生成 bundle，只在 05 的 refs 记录中说明。

## 克隆复核（2026-11-17 17:2x 北京时间，人工补做）
finalize.py 里的 clone 测试失败，原因是 **Windows 路径长度限制**：直接 `git clone` 在 Temp 目录检出时，`engine/work/...` 下有些很深的测试夹具路径超过 260 字符（"Filename too long"），检出中断，脚本记成了 clone=false。bundle 本身没有问题，所以没有替换，SHA256 仍是 `93F07A54CDDF47CFA509BBA17900878ABCD7F464E68D0A17FC74AEAA1053F231`。

在 Windows 上要这样克隆：`git -c core.longpaths=true clone fangyu-version-history-RECONSTRUCTED.bundle <目录>`（Linux/macOS 直接 clone 即可）。

| bundle | clone | fsck --full | 提交数 | 分支 |
|---|---|---|---|---|
| fangyu-version-history-RECONSTRUCTED | OK（16,567 个文件检出，status 干净） | OK | 9 | main(HEAD)、current-20261117、stable-pre-ui-overhaul、ui-approved-A-20261018、candidate-pre-overhaul-C-20261025；tag 9 个 |
| quiz-tijing-upstream / -dailyhundred / -minimal / quiz-original-control-source | OK | OK | 各 3 | main（四个内容相同） |
| quiz-outputs-daily-hundred-app / quiz-desktop-final-archive-daily-hundred-app | OK | OK | 各 1 | master、codex/configurable-automation-v2（两个相同） |
| LOCAL_ONLY quiz-cloud-056-repair | OK | OK | 1 | repair/cloud-056 |
| LOCAL_ONLY quiz-ui-yejin-isolated | OK | OK | 1 | master、ui/yejin |
| LOCAL_ONLY rmsama-AI-Backup | OK | OK | 6 | main |

重建仓库提交：ad4baa4b(10-13) → 93bf9630(10-15) → 761a7566(10-16) → f8608dad A(10-18 12:17) → cc99c4f6 B(10-18 18:30) → f1cf8bf3 C(10-25) → f0e9d789 F(10-27) → e7f01cc6 11-17 安装 → f13f4949 引擎当前(11-17 15:00)。
