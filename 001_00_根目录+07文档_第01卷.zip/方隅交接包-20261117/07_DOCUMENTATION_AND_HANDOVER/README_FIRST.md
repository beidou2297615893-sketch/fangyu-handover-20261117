# README_FIRST — 方隅交接包 2026-11-17

1. **先看** `07_DOCUMENTATION_AND_HANDOVER\docs\MASTER_HANDOVER.md`（同一套文档也在 `07_…handover-docs.part01.zip` 里）。
2. **校验**：PowerShell `Get-FileHash -Algorithm SHA256 <文件>` 或 `python -c "import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())" <文件>`，对照 `SHA256SUMS.txt`。完整校验结果见 `VERIFICATION_REPORT.md`。
3. **解压**：每个 `*.partNN.zip` 都是独立 zip，单卷 ≤95MiB。建议用 Python：`python -c "import zipfile,sys;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])" x.zip 目标目录`（中文文件名是 UTF-8）。同一包的各卷解到同一目录。
4. **重复文件**：为省空间，同一包内内容相同的文件只存一份。解压后运行 `python restore_duplicates.py <目录> <该包 manifest.csv>`（脚本在 07 包 `tools/`，manifest 在 `07_…FILE_MANIFEST.part01.zip`）。
5. **版本历史**：`git -c core.longpaths=true clone 05_GIT_FULL_HISTORY\fangyu-version-history-RECONSTRUCTED.bundle fangyu-history`（Windows 必须加 core.longpaths，否则部分深路径检出失败），分支 `stable-pre-ui-overhaul`（推荐稳定版 B）、`current-20261117`、`ui-approved-A-20261018`、`candidate-pre-overhaul-C-20261025`。这是根据快照**重建**的历史，不是原始 git 提交。

## 可以上传的
`01_CORE_SOURCE`、`02_STABLE_HISTORICAL_VERSION`、`03_CURRENT_VERSION`、`04_UI_AND_NEW_FEATURES`、`05_GIT_FULL_HISTORY`、`06_DATABASE_AND_MIGRATIONS`、`07_DOCUMENTATION_AND_HANDOVER`，以及根目录的 `README_FIRST.md`、`SHA256SUMS.txt`、`FILE_MANIFEST.csv`、`FILE_MANIFEST.md`、`VERIFICATION_REPORT.md`。

## 不要上传
- `_LOCAL_ONLY_DO_NOT_UPLOAD\`：历史中检出疑似客户数据/密钥的 git bundle、被排除文件的清单（文件名可能含客户信息）。
- `_work\`、`_logs\`、`_tools\`、`_specs\`：打包时的工作目录（`_logs` 里的 excluded 清单同样可能含敏感文件名）。

## 包里没有的
真实数据库/账本、浏览器登录态与 Cookie、密钥与签名文件、员工数据、exe/apk 等二进制（只记哈希）、可重新安装的依赖目录、原始 7.7GB `.git`。恢复方法见 `DEPLOYMENT.md`「安全配置恢复」。
