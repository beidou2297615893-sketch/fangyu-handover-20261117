# -*- coding: utf-8 -*-
import os,sys,csv,json,zipfile,hashlib,shutil,subprocess,glob,time,ctypes,collections
k=ctypes.windll.kernel32; k.GetCurrentProcess.restype=ctypes.c_void_p; k.SetPriorityClass.argtypes=[ctypes.c_void_p,ctypes.c_uint]; k.SetPriorityClass(k.GetCurrentProcess(),0x4000)
csv.field_size_limit(10**9)
T=r'C:\Users\rmsama\AppData\Local\Temp\fyho'; O=r'C:\方隅交接包-20261117'; L=lambda p:'\\\\?\\'+p
PK=['01_CORE_SOURCE','02_STABLE_HISTORICAL_VERSION','03_CURRENT_VERSION','04_UI_AND_NEW_FEATURES','05_GIT_FULL_HISTORY','06_DATABASE_AND_MIGRATIONS','07_DOCUMENTATION_AND_HANDOVER']
LO=os.path.join(O,'_LOCAL_ONLY_DO_NOT_UPLOAD')
def sha(p):
    h=hashlib.sha256()
    with open(L(p),'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
F=os.path.join(T,'final')
# 1 place box files
D7=os.path.join(O,'07_DOCUMENTATION_AND_HANDOVER'); os.makedirs(os.path.join(D7,'docs'),exist_ok=True)
for f in os.listdir(F):
    s=os.path.join(F,f)
    if f.endswith('.md'): shutil.copyfile(s,os.path.join(D7,'docs',f))
    elif f.endswith('.zip'): shutil.copyfile(s,os.path.join(D7,f))
for f in os.listdir(os.path.join(F,'boxlogs')): shutil.copyfile(os.path.join(F,'boxlogs',f),os.path.join(O,'_logs',f))
shutil.copyfile(os.path.join(F,'README_FIRST.md'),os.path.join(O,'README_FIRST.md'))
rep={'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'zips':[],'bundles':[],'clone':{}}
# 2 FILE_MANIFEST
logs=os.path.join(O,'_logs'); mans=sorted(glob.glob(os.path.join(logs,'*.manifest.csv')))
summ=collections.OrderedDict(); exc=collections.Counter(); red=collections.Counter()
for old in glob.glob(os.path.join(D7,'07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part*.zip')): os.remove(old)
mzl=[]; part=[0]; cur={'z':None,'raw':0}
def roll():
    if cur['z']: cur['z'].close()
    part[0]+=1; p=os.path.join(D7,'07_DOCUMENTATION_AND_HANDOVER.FILE_MANIFEST.part%02d.zip'%part[0]); mzl.append(p)
    cur['z']=zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=9); cur['raw']=0
roll()
LIM=180*1024*1024
for m in mans+sorted(glob.glob(os.path.join(logs,'*.redactions.csv'))):
    n=os.path.basename(m); isman=n.endswith('.manifest.csv'); st=collections.Counter(); by=0; seg=0
    with open(m,encoding='utf-8-sig',newline='') as f:
        rd=csv.reader(f); hdr=next(rd); idx={h:i for i,h in enumerate(hdr)}
        def openseg():
            nm='FILE_MANIFEST/'+n if seg==0 else 'FILE_MANIFEST/'+n[:-4]+'.cont%02d.csv'%seg
            w=cur['z'].open(nm,'w'); import io; t=io.TextIOWrapper(w,encoding='utf-8',newline=''); c=csv.writer(t); c.writerow(hdr); return w,t,c
        w,t,c=openseg()
        for r in rd:
            if isman:
                s_=r[idx['status']]; st[s_]+=1
                if s_=='included': by+=int(r[idx['size']] or 0)
            else: red[n[:-15]]+=1
            c.writerow(r); cur['raw']+=sum(len(x) for x in r)+len(r)
            if cur['raw']>LIM:
                t.close(); roll(); seg+=1; w,t,c=openseg()
        t.close()
    if isman: summ[n[:-13]]=(dict(st),by)
cur['z'].close()
mzs=sum(os.path.getsize(p) for p in mzl); mz=', '.join(os.path.basename(p) for p in mzl)
os.makedirs(os.path.join(LO,'excluded-lists'),exist_ok=True)
for m in sorted(glob.glob(os.path.join(logs,'*.excluded.csv'))):
    shutil.copyfile(m,os.path.join(LO,'excluded-lists',os.path.basename(m)))
    with open(m,encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f): exc[(os.path.basename(m)[:-13],r.get('reason',''))]+=1
# 3 verify zips
for p in PK:
    for z in sorted(glob.glob(os.path.join(O,p,'*.zip'))):
        sz=os.path.getsize(z); e=None; n=0; un=0
        try:
            with zipfile.ZipFile(L(z)) as zz: e=zz.testzip(); il=zz.infolist(); n=len(il); un=sum(i.file_size for i in il)
            ok= e is None
        except Exception as ex: ok=False; e=repr(ex)
        rep['zips'].append({'pkg':p,'file':os.path.basename(z),'size':sz,'MiB':round(sz/1048576,2),'le95MiB':sz<=95*1048576,'entries':n,'uncompressed':un,'testzip':'OK' if ok else str(e),'sha256':sha(z)})
# 4 bundles
for b in sorted(glob.glob(os.path.join(O,'05_GIT_FULL_HISTORY','*.bundle'))+glob.glob(os.path.join(LO,'git-bundles','*.bundle'))):
    r=subprocess.run(['git','bundle','verify',b],capture_output=True,text=True,encoding='utf-8',errors='replace')
    heads=subprocess.run(['git','bundle','list-heads',b],capture_output=True,text=True,encoding='utf-8',errors='replace').stdout.splitlines()
    rep['bundles'].append({'file':os.path.relpath(b,O),'size':os.path.getsize(b),'verify':'OK' if r.returncode==0 else (r.stderr or r.stdout)[-400:],'refs':len(heads),'heads':heads[:30],'sha256':sha(b),'local_only':LO in b})
# 5 clone test
cb=os.path.join(O,'05_GIT_FULL_HISTORY','fangyu-version-history-RECONSTRUCTED.bundle'); ct=os.path.join(T,'clonetest')
if os.path.exists(ct): shutil.rmtree(ct)
r=subprocess.run(['git','clone','-q',cb,ct],capture_output=True,text=True,encoding='utf-8',errors='replace')
if r.returncode==0:
    g=lambda *a: subprocess.run(['git','-C',ct]+list(a),capture_output=True,text=True,encoding='utf-8',errors='replace').stdout.strip()
    rep['clone']={'ok':True,'branches':g('branch','-r').splitlines(),'tags':g('tag').splitlines(),'commits':g('rev-list','--all','--count'),'log':g('log','--all','--date=iso','--format=%h %ad %s').splitlines(),'fsck':subprocess.run(['git','-C',ct,'fsck','--no-progress'],capture_output=True,text=True).returncode==0,'stable':g('rev-parse','origin/stable-pre-ui-overhaul'),'current':g('rev-parse','origin/current-20261117')}
else: rep['clone']={'ok':False,'err':r.stderr[-400:]}
shutil.rmtree(ct,ignore_errors=True)
# 6 FILE_MANIFEST.md
fm=['# FILE_MANIFEST','',f'完整逐文件清单（包内路径、源路径、大小、SHA256、修改时间、included/duplicate）在 07 包的 `{mz}`（共 {mzs:,} B；超长清单按 .contNN 续写），脱敏清单 `*.redactions.csv` 也在其中。被排除文件的逐条清单可能含敏感文件名，只放在 `_LOCAL_ONLY_DO_NOT_UPLOAD\\excluded-lists`，这里只列计数。','','## 各打包单元','','| 单元 | 收录(唯一) | 重复(只存一份) | 收录字节 | 脱敏副本 |','|---|---|---|---|---|']
for n,(st,by) in summ.items(): fm.append(f"| {n} | {st.get('included',0):,} | {st.get('duplicate',0):,} | {by:,} | {red.get(n,0)} |")
fm+=['','## 排除原因计数','','| 单元 | 原因 | 数量 |','|---|---|---|']+[f'| {a} | {b} | {c:,} |' for (a,b),c in sorted(exc.items())]
fm+=['','## 上传文件','','| 包 | 文件 | 大小 | 条目 | SHA256 |','|---|---|---|---|---|']+[f"| {z['pkg']} | {z['file']} | {z['size']:,} | {z['entries']:,} | `{z['sha256']}` |" for z in rep['zips']]+[f"| 05_GIT_FULL_HISTORY | {os.path.basename(b['file'])} | {b['size']:,} | {b['refs']} refs | `{b['sha256']}` |" for b in rep['bundles'] if not b['local_only']]
with open(L(os.path.join(O,'FILE_MANIFEST.csv')),'w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f); w.writerow(['package','file','type','size','entries_or_refs','uncompressed','sha256','verify'])
    for z in rep['zips']: w.writerow([z['pkg'],z['file'],'zip',z['size'],z['entries'],z['uncompressed'],z['sha256'],z['testzip']])
    for b in rep['bundles']: w.writerow(['_LOCAL_ONLY_DO_NOT_UPLOAD' if b['local_only'] else '05_GIT_FULL_HISTORY',os.path.basename(b['file']),'git-bundle',b['size'],b['refs'],'',b['sha256'],b['verify']])
open(L(os.path.join(O,'FILE_MANIFEST.md')),'w',encoding='utf-8').write('\n'.join(fm)+'\n')
# 7 VERIFICATION_REPORT
bad=[z for z in rep['zips'] if z['testzip']!='OK' or not z['le95MiB']]+[b for b in rep['bundles'] if b['verify']!='OK']
v=['# VERIFICATION_REPORT',f"生成：{rep['generated']}（北京时间，RMSAMA 本机）",'',f"- zip 卷数：{len(rep['zips'])}，全部 testzip OK 且 ≤95MiB：{'是' if not [z for z in rep['zips'] if z['testzip']!='OK' or not z['le95MiB']] else '否'}",f"- 最大卷：{max(z['MiB'] for z in rep['zips'])} MiB",f"- git bundle：{len(rep['bundles'])} 个（其中 LOCAL_ONLY {sum(b['local_only'] for b in rep['bundles'])} 个），verify 失败：{len([b for b in rep['bundles'] if b['verify']!='OK'])}",f"- 重建仓库 clone 测试：{'通过' if rep['clone'].get('ok') else '失败'}；fsck：{rep['clone'].get('fsck')}；提交数 {rep['clone'].get('commits')}",f"- stable-pre-ui-overhaul = {rep['clone'].get('stable')}；current-20261117 = {rep['clone'].get('current')}",'','## zip','','| 包 | 文件 | MiB | 条目 | 解压后字节 | testzip | SHA256 |','|---|---|---|---|---|---|---|']
v+=[f"| {z['pkg']} | {z['file']} | {z['MiB']} | {z['entries']:,} | {z['uncompressed']:,} | {z['testzip']} | `{z['sha256']}` |" for z in rep['zips']]
v+=['','## git bundle','','| 文件 | 字节 | refs | verify | SHA256 |','|---|---|---|---|---|']+[f"| {b['file']} | {b['size']:,} | {b['refs']} | {b['verify'] if b['verify']=='OK' else 'FAIL'} | `{b['sha256']}` |" for b in rep['bundles']]
v+=['','## 重建仓库','','分支：'+', '.join(rep['clone'].get('branches',[])),'','tag：'+', '.join(rep['clone'].get('tags',[])),'','```']+rep['clone'].get('log',[])+['```','','## 未在此处验证','- 未在新机器上实际解压全部包并运行程序；未运行 GUI；B/C 视觉未渲染比对。','- 空 git 仓库（tijing-bankassist 等 4 个）无法生成 bundle，只在 05 的 refs 记录中说明。']
open(L(os.path.join(O,'VERIFICATION_REPORT.md')),'w',encoding='utf-8').write('\n'.join(v)+'\n')
for f in ('VERIFICATION_REPORT.md','FILE_MANIFEST.md','FILE_MANIFEST.csv','README_FIRST.md'): shutil.copyfile(os.path.join(O,f),os.path.join(D7,f))
json.dump(rep,open(L(os.path.join(O,'_logs','verification.json')),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
# 8 SHA256SUMS
lines=[]
for p in PK:
    for r_,ds,fs in os.walk(L(os.path.join(O,p))):
        for f in sorted(fs):
            fp=os.path.join(r_,f); rel=os.path.relpath(fp,L(O)); lines.append(f'{sha(fp[4:])} *{rel}')
for f in ('README_FIRST.md','FILE_MANIFEST.md','FILE_MANIFEST.csv','VERIFICATION_REPORT.md'): lines.append(f'{sha(os.path.join(O,f))} *{f}')
open(L(os.path.join(O,'SHA256SUMS.txt')),'w',encoding='utf-8').write('\n'.join(lines)+'\n')
print(json.dumps({'zips':len(rep['zips']),'bad':[x.get('file') for x in bad],'bundles':len(rep['bundles']),'clone':rep['clone'].get('ok'),'commits':rep['clone'].get('commits'),'sums':len(lines),'manifest_zip':mzs},ensure_ascii=False))
