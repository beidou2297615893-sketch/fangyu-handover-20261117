import os,json
W=r'C:\积木软件工坊\项目\方隅公寓客户版'
F=r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统'
Q=r'C:\Users\rmsama\Documents\ChatGPT\答题小程序'
D=r'C:\Users\rmsama\Desktop'
O=r'C:\方隅交接包-20261117'
def item(src,arc,profile='code',**k):
    x=dict(src=src,arc=arc,profile=profile); x.update(k);return x
def spec(fn,pkg,pp,items):
    json.dump(dict(out_dir=O,package=pkg,part_prefix=pp,log_prefix=pp,max_part_mib=90,items=items),open('specs/'+fn+'.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
spec('01_core_fangyu','01_CORE_SOURCE','01_CORE_SOURCE.fangyu',[
 item(W,'rmsama/workshop/fangyu',skip=['backups','data','memory','outputs','work\\ui-native-r57','work\\desktop-python']),
 item(F,'rmsama/engines/auto-acquisition',skip=['outputs','memory','data'],exclude_rx=[r'(?i)(\\|^)(archive|archive-before.*|backup.*|.*runtime.*|.*evidence.*|.*ledger.*|.*state.*)(\\|$)']),
 item(r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117','rmsama/current/FangyuDesktopDirect-20261117','ui'),
])
spec('01_core_quiz','01_CORE_SOURCE','01_CORE_SOURCE.quiz',[
 item(Q,'rmsama/quiz/project',skip=['每日百题APP\\work\\original-vs-0419\\release-mobile\\.git']),
 item(D+r'\知题-支付调整完整开发包','rmsama/quiz/current-0.4.27'),
 item(D+r'\知题-完整项目最终存档','rmsama/quiz/desktop-final-0.4.24'),
 item(r'C:\Users\rmsama\DailyHundredNativeBuild','rmsama/quiz/native-build'),
])
spec('03_current','03_CURRENT_VERSION','03_CURRENT_VERSION.rmsama',[
 item(r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117','fangyu/20261117-install','ui'),
 item(r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261114','fangyu/20261114-install','ui'),
 item(r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261114-backup-20261117','fangyu/20261114-backup','ui'),
 item(W+r'\work\combined-full-candidate-20261027\project\work\ui-native-r57\releases\ui-r57-20261027T130512Z-a9ba360f','fangyu/20261027-freeze','ui'),
 item(D+r'\知题-支付调整完整开发包','quiz/current-0.4.27'),
])
