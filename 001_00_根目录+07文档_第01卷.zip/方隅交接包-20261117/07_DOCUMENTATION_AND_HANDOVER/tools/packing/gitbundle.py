# -*- coding: utf-8 -*-
import os, sys, subprocess, json, hashlib, ctypes
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fypack  # sets BelowNormal priority
from fypack import LP
from blobscan import scan_repo
O = r'C:\方隅交接包-20261117'
LOCAL = O + r'\_LOCAL_ONLY_DO_NOT_UPLOAD\git-bundles'
OUT = O + r'\05_GIT_FULL_HISTORY'
Q = r'C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP'
REPOS = [
 ('fangyu-version-history-RECONSTRUCTED', O + r'\_work\fangyu-version-history'),
 ('quiz-tijing-upstream', Q + r'\work\tijing-upstream'),
 ('quiz-tijing-dailyhundred', Q + r'\work\tijing-dailyhundred'),
 ('quiz-tijing-minimal', Q + r'\work\tijing-minimal'),
 ('quiz-original-control-source', Q + r'\work\original-vs-0419\original-control\source'),
 ('quiz-cloud-056-repair', Q + r'\work\cloud-056-repair'),
 ('quiz-ui-yejin-isolated', Q + r'\work\ui-yejin-isolated'),
 ('quiz-outputs-daily-hundred-app', Q + r'\outputs\daily-hundred-app'),
 ('quiz-desktop-final-archive-daily-hundred-app', r'C:\Users\rmsama\Desktop\知题-完整项目最终存档\outputs\daily-hundred-app'),
 ('quiz-tijing-bankassist', Q + r'\work\tijing-bankassist'),
 ('quiz-zhiti-acceptance-isolated-source', Q + r'\work\知题本轮验收\isolated\source'),
 ('quiz-zhiti-startfix-isolated-source', Q + r'\work\知题启动修复\work\isolated\source'),
 ('quiz-zhiti-startfix-isolated-no-frame-source', Q + r'\work\知题启动修复\work\isolated-no-frame\source'),
 ('rmsama-AI-Backup', r'C:\Users\rmsama\Documents\AI-Backup'),
 ('fangyu-engine-root-codex-refs-NOT-BUNDLED', None),
]
MAXP = 90 * 1024 * 1024
def git(*a, cwd=None):
    return subprocess.run(['git', '-c', 'safe.directory=*', '--no-optional-locks'] + list(a), capture_output=True, cwd=cwd)
def sha(p):
    h = hashlib.sha256()
    with open(LP(p), 'rb') as f:
        for ch in iter(lambda: f.read(1 << 20), b''): h.update(ch)
    return h.hexdigest()
os.makedirs(LP(OUT), exist_ok=True)
res = []
ONLY = sys.argv[1:]
for name, path in REPOS:
    if ONLY and name not in ONLY: continue
    r = dict(name=name, source=path)
    if path is None:
        r['note'] = 'C:\\Users\\rmsama\\Documents\\ChatGPT\\自动获客系统\\.git：0 commits，只有 4 个 refs/codex/turn-diffs/checkpoints tree 引用（3 个唯一 tree）。未打包原 .git（7.7GB 且混有账本 blob）；其 tree 已按过滤规则重建进 fangyu-version-history。'
        res.append(r); continue
    refs = git('-C', path, 'for-each-ref', '--format=%(refname) %(objectname) %(objecttype)').stdout.decode('utf-8', 'replace')
    r['refs'] = refs.strip().splitlines()
    r['head'] = git('-C', path, 'rev-parse', '--abbrev-ref', 'HEAD').stdout.decode().strip()
    r['shallow'] = git('-C', path, 'rev-parse', '--is-shallow-repository').stdout.decode().strip()
    r['remotes'] = git('-C', path, 'remote', '-v').stdout.decode('utf-8', 'replace').strip().splitlines()
    r['commit_count_all'] = git('-C', path, 'rev-list', '--all', '--count').stdout.decode().strip()
    st = git('-C', path, 'status', '--porcelain=v1', '-uall').stdout.decode('utf-8', 'replace').splitlines()
    r['status_modified'] = sum(1 for l in st if not l.startswith('??')); r['status_untracked'] = sum(1 for l in st if l.startswith('??'))
    stash = git('-C', path, 'stash', 'list').stdout.decode('utf-8', 'replace').strip().splitlines(); r['stash'] = stash
    commit_refs = [l for l in r['refs'] if l.endswith(' commit') or l.endswith(' tag')]
    if not commit_refs:
        r['bundle'] = None; r['note'] = '无提交/无 commit 引用，git bundle 无法创建；工作区文件已在 01_CORE_SOURCE 中按过滤规则收录。'
        res.append(r); print(json.dumps(r, ensure_ascii=False)[:300], flush=True); continue
    sc = scan_repo(path)
    r['history_scan'] = {k: sc[k] for k in ('blobs_scanned', 'files_with_hits', 'by_type')}
    json.dump(sc, open(LP(O + r'\_logs\05_GIT.blobscan.' + name + '.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    dest = OUT if sc['files_with_hits'] == 0 else LOCAL
    r['placement'] = 'upload_package' if dest == OUT else 'LOCAL_ONLY (history contains secret/PII/data-pattern blobs; working-tree code is in 01 after filtering)'
    os.makedirs(LP(dest), exist_ok=True)
    b = os.path.join(dest, name + '.bundle')
    c = git('bundle', 'create', b, '--all', cwd=path)
    if c.returncode != 0:
        r['bundle'] = None; r['error'] = c.stderr.decode('utf-8', 'replace')[-800:]; res.append(r); continue
    v = git('bundle', 'verify', b, cwd=path)
    r['verify'] = 'OK' if v.returncode == 0 else 'FAIL: ' + v.stderr.decode('utf-8', 'replace')[-500:]
    r['bundle_size'] = os.path.getsize(LP(b)); r['bundle_sha256'] = sha(b)
    if r['bundle_size'] > MAXP:
        parts = []
        with open(LP(b), 'rb') as f:
            i = 0
            while True:
                ch = f.read(MAXP)
                if not ch: break
                i += 1; pn = b + '.part%02d' % i
                open(LP(pn), 'wb').write(ch); parts.append(dict(file=os.path.basename(pn), size=len(ch), sha256=hashlib.sha256(ch).hexdigest()))
        os.remove(LP(b)); r['split_parts'] = parts
        r['rejoin'] = 'Windows: copy /b ' + '+'.join(p['file'] for p in parts) + ' ' + name + '.bundle ; Linux: cat ' + name + '.bundle.part* > ' + name + '.bundle ; then check bundle_sha256'
    res.append(r); print(json.dumps({k: r[k] for k in r if k not in ('refs',)}, ensure_ascii=False)[:500], flush=True)
json.dump(res, open(LP(O + r'\_logs\05_GIT.bundles.result' + ('.' + '_'.join(ONLY) if ONLY else '') + '.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('DONE', len(res))
