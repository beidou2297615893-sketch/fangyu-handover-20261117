# -*- coding: utf-8 -*-
"""扫描 git 仓库全部历史 blob 的密钥/隐私模式；只输出 路径+类型，不输出命中值。"""
import subprocess, sys, os, json, collections, re
DATA_LIKE = ('.json','.json5','.txt','.csv','.tsv','.md','.html','.xml','.yaml','.yml','.log','')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fypack import SECRET_RX, PII_RX, CUSTOMER_JSON_RX, DATA_EXT_RX, SENS_NAME_RX
def scan_repo(repo, maxsize=5 * 1024 * 1024):
    G = ['git', '-c', 'safe.directory=*', '--no-optional-locks', '-C', repo]
    objs = subprocess.run(G + ['rev-list', '--objects', '--all'], capture_output=True).stdout.decode('utf-8', 'replace').splitlines()
    paths = {}
    for l in objs:
        if ' ' in l:
            h, p = l.split(' ', 1); paths.setdefault(h, p)
    p = subprocess.Popen(G + ['cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    hits = []; n = 0
    for h, path in paths.items():
        p.stdin.write((h + '\n').encode()); p.stdin.flush()
        hdr = p.stdout.readline().decode().split()
        if len(hdr) < 3: continue
        typ, size = hdr[1], int(hdr[2]); data = p.stdout.read(size); p.stdout.read(1)
        if typ != 'blob': continue
        n += 1
        name = path.rsplit('/', 1)[-1]
        t = []
        if DATA_EXT_RX.search(name.lower()): t.append('data_file_in_history')
        if SENS_NAME_RX.search(name) and not name.lower().endswith(('.py', '.js', '.mjs', '.ts', '.md', '.kt')): t.append('sensitive_name_in_history')
        if size <= maxsize:
            s = re.sub(r'\[REDACTED:[a-z_]+\]', '', data.decode('utf-8', 'replace'))
            t += [k for k, rx in SECRET_RX + PII_RX if rx.search(s)]
            ext = os.path.splitext(name.lower())[1]
            if ext in DATA_LIKE and len(CUSTOMER_JSON_RX.findall(s)) >= 3: t.append('customer_data_fields')
            if ext in DATA_LIKE and PII_RX[1][1].search(s): t.append('douyin_sec_uid_in_data')
        if t: hits.append(dict(path=path, types=sorted(set(t))))
    p.stdin.close(); p.wait()
    c = collections.Counter(x for h in hits for x in h['types'])
    return dict(repo=repo, blobs_scanned=n, files_with_hits=len(hits), by_type=dict(c), hits=hits[:2000])
if __name__ == '__main__':
    r = scan_repo(sys.argv[1]); out = sys.argv[2]
    json.dump(r, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(json.dumps({k: r[k] for k in ('blobs_scanned', 'files_with_hits', 'by_type')}, ensure_ascii=False))
