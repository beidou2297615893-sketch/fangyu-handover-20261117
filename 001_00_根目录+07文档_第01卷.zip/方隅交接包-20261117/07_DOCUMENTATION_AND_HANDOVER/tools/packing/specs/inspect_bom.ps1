﻿$T='C:\Users\rmsama\AppData\Local\Temp\fyho'
& 'C:\Users\rmsama\miniconda3\python.exe' "$T\inspect.py" 2>&1 | Out-File -Encoding utf8 "$T\inspect.out.txt"
