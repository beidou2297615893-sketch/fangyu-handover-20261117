﻿$T='C:\Users\rmsama\AppData\Local\Temp\fyho'
$O='C:\方隅交接包-20261117'
$py='C:\Users\rmsama\miniconda3\python.exe'
Copy-Item "$T\fypack.py","$T\gitbuild.py","$T\gitbundle.py","$T\blobscan.py","$T\inspect.py" "$O\_tools\" -Force
Copy-Item "$T\*.json" "$O\_specs\" -Force -Exclude 'schema_rowcounts.json'
$mode=$args[0]
if ($mode -eq 'git') {
  if (Test-Path "$O\_work\fangyu-version-history") { Remove-Item "$O\_work\fangyu-version-history" -Recurse -Force }
  Get-ChildItem "$O\_logs" -Filter '05_GIT*' | Remove-Item -Force
  "GITBUILD START $(Get-Date -Format 'HH:mm:ss')"
  & $py "$O\_tools\gitbuild.py" 2>&1
  "GITBUNDLE START $(Get-Date -Format 'HH:mm:ss')"
  & $py "$O\_tools\gitbundle.py" 2>&1
  "GIT END $(Get-Date -Format 'HH:mm:ss')"
} else {
  foreach ($s in $args[1..($args.Count-1)]) {
    Get-ChildItem "$O" -Recurse -Filter "$s.part*.zip" -ErrorAction SilentlyContinue | Remove-Item -Force
    Get-ChildItem "$O\_logs" -Filter "$s.*" -ErrorAction SilentlyContinue | Remove-Item -Force
    "START $s $(Get-Date -Format 'HH:mm:ss')"
    & $py "$O\_tools\fypack.py" "$O\_specs\$s.json" 2>&1
    "END $s $(Get-Date -Format 'HH:mm:ss')"
  }
}
