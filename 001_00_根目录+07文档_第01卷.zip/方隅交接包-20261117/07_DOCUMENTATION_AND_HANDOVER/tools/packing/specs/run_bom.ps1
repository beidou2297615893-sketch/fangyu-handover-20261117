﻿param([string]$Spec)
$py = 'C:\Users\rmsama\miniconda3\python.exe'
$p = Start-Process -FilePath $py -ArgumentList @('C:\方隅交接包-20261117\_tools\fypack.py', $Spec) -NoNewWindow -PassThru -Wait -RedirectStandardOutput ($Spec + '.out.txt') -RedirectStandardError ($Spec + '.err.txt')
"exit=" + $p.ExitCode
