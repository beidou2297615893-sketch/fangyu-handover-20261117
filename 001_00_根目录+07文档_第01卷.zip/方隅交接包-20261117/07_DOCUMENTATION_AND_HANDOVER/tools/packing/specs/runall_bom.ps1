﻿$T='C:\Users\rmsama\AppData\Local\Temp\fyho'
$O='C:\方隅交接包-20261117'
Copy-Item "$T\fypack.py" "$O\_tools\fypack.py" -Force
Copy-Item "$T\*.json" "$O\_specs\" -Force
foreach ($s in $args) {
  Get-ChildItem "$O" -Recurse -Filter "$s.part*.zip" -ErrorAction SilentlyContinue | Remove-Item -Force
  "START $s $(Get-Date -Format 'HH:mm:ss')"
  & 'C:\Users\rmsama\miniconda3\python.exe' "$O\_tools\fypack.py" "$O\_specs\$s.json" 2>&1
  "END $s $(Get-Date -Format 'HH:mm:ss')"
}
