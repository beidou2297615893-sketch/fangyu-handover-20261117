# -*- coding: utf-8 -*-
"""方隅交接包打包器（只读源文件；输出到指定目录）。
用法: python fypack.py <spec.json>
spec: {"out_dir":..., "package":"01_CORE_SOURCE", "part_prefix":"01_CORE_SOURCE", "max_part_mib":90,
       "items":[{"src":..., "arc":..., "profile":"code|ui|docs", "dedup":true, "skip_dirs":[...相对路径前缀...]}]}
"""
import os, sys, re, json, zipfile, hashlib, csv, time, io, ctypes
WIN = os.name == 'nt'
if WIN:
    try:
        k32 = ctypes.windll.kernel32
        k32.GetCurrentProcess.restype = ctypes.c_void_p
        k32.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        if not k32.SetPriorityClass(k32.GetCurrentProcess(), 0x4000): print('WARN: SetPriorityClass failed', flush=True)  # BELOW_NORMAL
    except Exception as e: print('WARN priority', e, flush=True)
def LP(p):
    if WIN:
        p = os.path.abspath(p)
        if not p.startswith('\\\\?\\'): p = '\\\\?\\' + p
    return p
def UNLP(p): return p[4:] if p.startswith('\\\\?\\') else p

REBUILD_DIRS = {'node_modules','.venv','venv','site-packages','__pycache__','.gradle','gradle-home','.cache','cache','code cache','gpucache',
  'shadercache','.pytest_cache','.mypy_cache','_internal','.git','.cxx','intermediates','.expo','.next','.turbo','.parcel-cache','avd','dist-packages',
  'graphitedawncache','dawncache','crashpad','blob_storage','service worker','indexeddb','local storage','session storage','pnpm-store','.pnpm-store','.idea','.vs'}
REBUILD_DIR_RX = re.compile(r'^(gradle-\d.*|build|\.?venv\d*|python-runtime|python_embed|desktop-python|android-sdk|jdk.*|tmp[a-z0-9_]{6,}|snapshot-staging-.*|emulator\d.*|.*-avd)$', re.I)
SENS_DIR_RX = re.compile(r'(profile|user data|ebwebview|webview2|douyin-browser|employee-data|chrome[_-]?data|browser[_-]?data|private|secret|signing|keystore|credential|cookie|session|login-state|storage-state|alipay-secure)', re.I)
RUN_DIR_RX = re.compile(r'(runner-live|reply-pilot|review-batches|daily-priority|live-round|-round-\d|round\d+-task|real-source|real-e2e|actual-data|douyin-local-batch|douyin-local-2026|xhs-next\d+|xhs-final\d|preparation|sent-|send-log|outbox|inbox-|comments?-dump|harvest|crawl-out|scan-out|collect-out|pending-drafts|samples?\d+|transcripts?|chat-?logs?|codex-window-histor|archived-threads)', re.I)
DATA_DIR_RX = re.compile(r'^(runtime|data|state|states|screenshots|screen-shots|browser-artifacts|artifacts|receipts?|evidence|runs|logs?|test-runs|real-e2e|ledger-snapshot|06-账本快照|账本快照|方隅客户资料备份|去重账本快照|customer-qa|actual-data-.*|backups?|_backup.*|recovery-backup|current-business-backup)$', re.I)
BIN_EXT = set('.exe .msi .dll .pyd .so .dylib .whl .apk .aab .apks .zip .7z .rar .tar .gz .tgz .bz2 .xz .img .qcow2 .vhdx .vhd .avhdx .vmrs .vmcx .iso .dmg .pkg .pyz .bin .dex .class .o .obj .pch .node .lib .a .exp .pdb .mp4 .mov .webm .avi .mkv .mp3 .wav .m4a .flac .psd .ttf .otf .woff .woff2 .eot .pak .dat .ldb .msix .appx .cab .nupkg .jar .aar .ilk .idb .ckpt .pt .pth .onnx .safetensors .tflite .model .npy .npz .h5 .parquet .pdf .docx .doc .xlsx .xls .pptx .ppt .wpt'.split())
DATA_EXT_RX = re.compile(r'\.(sqlite3?|db|duckdb|db-wal|db-shm|sqlite3?-wal|sqlite3?-shm|sqlite3?-journal|jsonl|ndjson|log|har|pcap|dmp|lock)$', re.I)
SENS_NAME_RX = re.compile(r'(cookie|^login data|^local state|^trust tokens|token[_-]?cache|authorization|^session|session[_-]?(imported|state|store)|^auth-|credential|secret|password|passwd|\.pem$|\.key$|\.pfx$|\.p12$|\.jks$|\.keystore$|\.crt$|\.cer$|\.der$|^\.env$|^\.env\.(?!example|sample|template)|^id_rsa|^id_ed25519|signing-config|local\.properties$|google-services\.json$|^bridge\.json$|storage[_-]?state|\.mobileprovision$|^\.npmrc$|^\.pypirc$|\.netrc$)', re.I)
RECEIPT_RX = re.compile(r'(receipt|ledger|账本|回执|客户资料|客户名单|评论原文|全部评论|待回复|已发|sent[_-]?log|reply[_-]?log)', re.I)
TEXT_EXT = set('.py .pyw .pyi .js .mjs .cjs .ts .tsx .jsx .vue .svelte .css .scss .less .html .htm .md .markdown .txt .rst .ps1 .psm1 .psd1 .bat .cmd .sh .kt .kts .java .gradle .toml .yaml .yml .ini .cfg .conf .sql .svg .wxml .wxss .wxs .json .json5 .xml .csv .spec .iss .nsi .properties .gitignore .gitattributes .editorconfig .env.example .tpl .mustache .ejs .hbs .plist .pro .cmake .c .h .cpp .hpp .cs .go .rs .rb .php .lua .r .ipynb .tsv .manifest .rc .def .reg'.split())
IMG_EXT = set('.png .jpg .jpeg .gif .webp .ico .bmp .avif'.split())
CODE_EXT = set('.py .pyw .pyi .js .mjs .cjs .ts .tsx .jsx .vue .svelte .css .scss .less .html .htm .ps1 .psm1 .bat .cmd .sh .kt .kts .java .gradle .sql .wxml .wxss .wxs .c .h .cpp .hpp .cs .go .rs .rb .php .lua'.split())
SECRET_RX = [
 ('private_key', re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]{20,}?-----END [A-Z ]*PRIVATE KEY-----')),
 ('aws_key', re.compile(r'AKIA[0-9A-Z]{16}')),
 ('tencent_secretid', re.compile(r'AKID[0-9A-Za-z]{13,}')),
 ('api_key_sk', re.compile(r'\bsk-[A-Za-z0-9_\-]{20,}')),
 ('github_token', re.compile(r'\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}')),
 ('slack_token', re.compile(r'\bxox[baprs]-[A-Za-z0-9-]{10,}')),
 ('jwt', re.compile(r'\beyJ[A-Za-z0-9_-]{15,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}')),
 ('assigned_secret', re.compile(r'(?i)\b(api[_-]?key|secret[_-]?key|client[_-]?secret|app[_-]?secret|access[_-]?token|refresh[_-]?token|auth[_-]?token|private[_-]?key|password|passwd|pwd)\b["\']?\s*[:=]\s*["\']([^"\'\s<>{}$]{12,})["\']')),
 ('cookie_kv', re.compile(r'(?i)\b(sessionid(_ss)?|sid_tt|sid_guard|uid_tt|ttwid|odin_tt|passport_csrf_token|mstoken|web_session|webid|a1|gid|acw_tc|xsecappid|sso_uid_tt|toutiao_sso_user|n_mh)=[A-Za-z0-9%_\-\.|]{12,}')),
 ('cookie_blob', re.compile(r'(?i)"(cookie|cookies|set-cookie)"\s*:\s*"[^"]{40,}"')),
 ('base64_key', re.compile(r'MII[A-Za-z0-9+/]{200,}={0,2}')),
 ('alipay_appid_key', re.compile(r'(?i)(alipay[_-]?(public|private)[_-]?key)\s*[:=]\s*["\'][^"\']{40,}')),
]
PII_RX = [
 ('phone_cn', re.compile(r'(?<![0-9A-Za-z.#_/\-])1[3-9]\d{9}(?![0-9A-Za-z])')),
 ('douyin_sec_uid', re.compile(r'MS4wLjAB[A-Za-z0-9_\-]{20,}')),
 ('id_card_cn', re.compile(r'(?<![0-9A-Za-z.#_/\-])[1-9]\d{5}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx](?![0-9A-Za-z])')),
 ('wechat_id', re.compile(r'(?i)(微信号|wechat|vx|wx)\s*[:：]\s*[A-Za-z][A-Za-z0-9_-]{5,19}')),
]
CUSTOMER_JSON_RX = re.compile(r'"(nickname|nick_name|comment_text|commentText|reply_text|user_name|screen_name|author_name|unique_id|short_id|sec_uid|secUid|uid|user_id|userId|aweme_id|awemeId|cid|comment_id|commentId|note_id|noteId|xsec_token|text|content|comment|desc|reply|reply_content|customer|lead|author)"\s*:\s*"[^"]{2,}"', re.I)

def load(p):
    with open(LP(p),'rb') as f: return f.read()

def classify_name(rel_parts, name, size, profile, images_ok=False):
    low = name.lower(); ext = os.path.splitext(low)[1]
    if low.endswith('.pyc'): return 'x', 'rebuildable'
    if low in ('.git', '.gitmodules'): return 'x', 'nested_git_pointer'
    if SENS_NAME_RX.search(name) and not low.endswith(('.py','.js','.mjs','.cjs','.ts','.md','.kt')): return 'x', 'sensitive_name'
    if DATA_EXT_RX.search(low): return 'x', 'data_ledger'
    if ext == '.jar' and low == 'gradle-wrapper.jar': return 'i', None
    if ext in BIN_EXT: return 'x', 'binary_or_package'
    if ext in IMG_EXT:
        if not images_ok and not re.search(r'(^|[/\\])(assets?|icons?|ui-preview|web|resources)([/\\]|$)', '/'.join(rel_parts), re.I) and ext != '.ico': return 'x', 'unreviewed_image_privacy'
        lim = {'code':512*1024,'ui':15*1024*1024,'docs':8*1024*1024}[profile]
        return ('i',None) if size <= lim else ('x','image_too_large_for_profile')
    if ext in ('.csv','.tsv'):
        if re.search(r'(rule|规则|keyword|关键词|采集词|template|模板|preset|预设)', '/'.join(rel_parts)+name, re.I) and size <= 512*1024: return 't', None
        return 'x', 'tabular_data'
    if ext == '.json' or ext == '.json5':
        if RECEIPT_RX.search(name): return 'x', 'receipt_or_ledger_json'
        if size > 64*1024 and not low in ('package.json','package-lock.json','tsconfig.json','release.json','manifest.json','backend-dependencies.json'): return 'x', 'large_json_likely_run_data'
        if low == 'package-lock.json' and size > 4*1024*1024: return 'x', 'large_lockfile'
        return 't', None
    if ext == '.txt' and size > 256*1024: return 'x', 'large_text_likely_run_data'
    if ext in TEXT_EXT or low in ('.gitignore','.gitattributes','dockerfile','makefile','procfile','license','readme','.editorconfig','.npmrc.example'):
        if size > 5*1024*1024: return 'x', 'text_too_large'
        return 't', None
    if ext == '' and size <= 256*1024: return 't', None
    if size <= 1024*1024 and profile != 'code': return 'i', None
    return 'x', 'unknown_type'

def scan_text(b, name):
    try: s = b.decode('utf-8')
    except UnicodeDecodeError:
        try: s = b.decode('gbk')
        except Exception: return None, [], False
    hits = []
    for t, rx in SECRET_RX:
        if rx.search(s): hits.append(t)
    for t, rx in PII_RX:
        if rx.search(s): hits.append(t)
    cust = False
    ext = os.path.splitext(name.lower())[1]
    if ext in ('.json','.json5','.txt','.csv','.tsv','.md','.html','.xml','.yaml','.yml') and len(CUSTOMER_JSON_RX.findall(s)) >= 3: cust = True
    if ext in ('.json','.json5','.txt','.csv','.tsv','.xml','.yaml','.yml') and PII_RX[1][1].search(s): cust = True
    if len(PII_RX[1][1].findall(s)) >= 3: cust = True
    return s, hits, cust

def redact(s):
    for t, rx in SECRET_RX + PII_RX:
        if t == 'assigned_secret':
            s = rx.sub(lambda m: m.group(0).replace(m.group(2), '[REDACTED:'+t+']'), s)
        else:
            s = rx.sub('[REDACTED:'+t+']', s)
    return s

def SAN(x):
    if isinstance(x, str):
        try: x.encode('utf-8')
        except UnicodeEncodeError: x = x.encode('utf-8', 'surrogateescape').decode('utf-8', 'replace')
    return x
class SafeW:
    def __init__(self, f): self.w = csv.writer(f)
    def writerow(self, r): self.w.writerow([SAN(v) for v in r])
class Packer:
    def __init__(self, spec):
        self.spec = spec; self.out = spec['out_dir']; self.pkg = spec['package']
        os.makedirs(LP(os.path.join(self.out, self.pkg)), exist_ok=True)
        os.makedirs(LP(os.path.join(self.out, '_logs')), exist_ok=True)
        self.maxb = int(spec.get('max_part_mib', 90))*1024*1024
        self.part = 0; self.zf = None; self.seen = {}
        L = lambda n: open(LP(os.path.join(self.out,'_logs', f"{spec.get('log_prefix', self.pkg)}.{n}.csv")),'w',newline='',encoding='utf-8-sig')
        self.fm, self.fx, self.fr = L('manifest'), L('excluded'), L('redactions')
        self.wm, self.wx, self.wr = SafeW(self.fm), SafeW(self.fx), SafeW(self.fr)
        self.wm.writerow(['package','part','arcname','source_path','size','sha256','mtime','status','duplicate_of'])
        self.wx.writerow(['package','source_path','reason','size'])
        self.wr.writerow(['package','arcname','source_path','hit_types','action'])
        self.stats = {'included':0,'duplicates':0,'excluded':0,'redacted':0,'bytes':0}
    def newpart(self):
        if self.zf: self.zf.close()
        self.part += 1
        fn = os.path.join(self.out, self.pkg, f"{self.spec.get('part_prefix', self.pkg)}.part{self.part:02d}.zip")
        self.zf = zipfile.ZipFile(LP(fn), 'w', zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True)
    def add_bytes(self, arc, data, mtime, src, status='included', dup=''):
        if self.zf is None or self.zf.fp.tell() + len(data) > self.maxb: self.newpart()
        t = time.localtime(max(mtime, 315532800+86400))[:6]
        zi = zipfile.ZipInfo(SAN(arc), date_time=t); zi.compress_type = zipfile.ZIP_DEFLATED
        self.zf.writestr(zi, data)
        self.stats['bytes'] += len(data)
        self.wm.writerow([self.pkg, self.part, arc, src, len(data), hashlib.sha256(data).hexdigest(), time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(mtime)), status, dup])
    def excl(self, src, reason, size=''):
        self.stats['excluded'] += 1; self.wx.writerow([self.pkg, src, reason, size])
    def run_item(self, it):
        src = it['src']; arc0 = it['arc'].strip('/'); prof = it.get('profile','code'); dedup = it.get('dedup', True)
        skip = [s.lower().replace('/','\\').strip('\\') for s in it.get('skip', [])]
        extra_excl = [re.compile(x, re.I) for x in it.get('exclude_rx', [])]
        allow_dirs = it.get('allow_data_dirs', False); self.images_ok = it.get('images_ok', False)
        if not os.path.exists(LP(src)): self.excl(src, 'missing_source'); return
        if os.path.isfile(LP(src)):
            self.one(src, os.path.dirname(src), arc0, prof, dedup, [], os.path.basename(src)); return
        for root, dirs, files in os.walk(LP(src)):
            rroot = UNLP(root); rel = os.path.relpath(rroot, src); rel = '' if rel == '.' else rel
            keep = []
            for d in dirs:
                rd = os.path.join(rel, d) if rel else d; dl = d.lower(); rdl = rd.lower()
                reason = None
                if any(rdl == s or rdl.startswith(s+'\\') for s in skip): reason = 'skipped_by_spec'
                elif dl in REBUILD_DIRS or REBUILD_DIR_RX.match(d): reason = 'rebuildable_dir'
                elif SENS_DIR_RX.search(d): reason = 'sensitive_dir'
                elif (not allow_dirs) and RUN_DIR_RX.search(d): reason = 'run_output_dir'
                elif (not allow_dirs) and DATA_DIR_RX.match(d) and not (self.images_ok and dl in ('screenshots','screen-shots')): reason = 'data_or_evidence_dir'
                elif any(rx.search(rd) for rx in extra_excl): reason = 'excluded_by_spec_rx'
                try:
                    if os.path.islink(os.path.join(root, d)) or (WIN and (os.stat(os.path.join(root,d), follow_symlinks=False).st_file_attributes & 0x400)): reason = reason or 'reparse_point_not_followed'
                except Exception: pass
                if reason: self.excl(os.path.join(rroot, d)+'\\', reason)
                else: keep.append(d)
            dirs[:] = keep
            for f in files:
                rf = os.path.join(rel, f) if rel else f
                if any(rx.search(rf) for rx in extra_excl): self.excl(os.path.join(rroot,f), 'excluded_by_spec_rx'); continue
                self.one(os.path.join(rroot, f), src, arc0 + '/' + rf.replace('\\','/'), prof, dedup, rel.split('\\') if rel else [], f)
    def one(self, path, base, arc, prof, dedup, rel_parts, name):
        try: st = os.stat(LP(path))
        except Exception as e: self.excl(path, 'stat_error'); return
        kind, reason = classify_name(rel_parts, name, st.st_size, prof, getattr(self,'images_ok',False))
        if kind == 'x': self.excl(path, reason, st.st_size); return
        try: b = load(path)
        except Exception: self.excl(path, 'read_error', st.st_size); return
        status = 'included'
        if kind == 't' or os.path.splitext(name.lower())[1] in TEXT_EXT:
            s, hits, cust = scan_text(b, name)
            if cust: self.excl(path, 'customer_data_fields', st.st_size); return
            if hits:
                if s is None: self.excl(path, 'secret_or_pii_undecodable', st.st_size); return
                b = redact(s).encode('utf-8'); status = 'redacted'; self.stats['redacted'] += 1
                self.wr.writerow([self.pkg, arc, path, '|'.join(sorted(set(hits))), 'redacted_copy'])
        h = hashlib.sha256(b).hexdigest()
        if dedup and h in self.seen:
            self.stats['duplicates'] += 1
            self.wm.writerow([self.pkg, '', arc, path, len(b), h, time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime)), 'duplicate', self.seen[h]]); return
        self.seen[h] = arc
        self.add_bytes(arc, b, st.st_mtime, path, status)
        self.stats['included'] += 1
    def add_text(self, arc, text):
        self.add_bytes(arc, text.encode('utf-8'), time.time(), '(generated)', 'generated')
    def close(self):
        if self.zf: self.zf.close()
        for f in (self.fm, self.fx, self.fr): f.close()

def verify(out, pkg, part_prefix):
    res = []
    d = os.path.join(out, pkg)
    for fn in sorted(os.listdir(LP(d))):
        if not (fn.startswith(part_prefix) and fn.endswith('.zip')): continue
        p = os.path.join(d, fn)
        with zipfile.ZipFile(LP(p)) as z:
            bad = z.testzip(); n = len(z.infolist()); usz = sum(i.file_size for i in z.infolist())
        h = hashlib.sha256()
        with open(LP(p),'rb') as f:
            for ch in iter(lambda: f.read(1<<20), b''): h.update(ch)
        res.append({'file': fn, 'entries': n, 'uncompressed': usz, 'size': os.path.getsize(LP(p)), 'sha256': h.hexdigest(), 'testzip': 'OK' if bad is None else 'BAD:'+bad})
    return res

if __name__ == '__main__':
    spec = json.load(open(sys.argv[1], encoding='utf-8'))
    P = Packer(spec)
    t0 = time.time()
    for it in spec['items']:
        P.run_item(it)
        print('done item', it['arc'], P.stats, int(time.time()-t0), 's', flush=True)
    for g in spec.get('generated', []):
        P.add_text(g['arc'], open(LP(g['from']), encoding='utf-8').read())
    P.close()
    v = verify(spec['out_dir'], spec['package'], spec.get('part_prefix', spec['package']))
    json.dump({'package': spec['package'], 'stats': P.stats, 'parts': v, 'seconds': int(time.time()-t0)}, open(LP(os.path.join(spec['out_dir'], '_logs', spec.get('log_prefix', spec['package'])+'.result.json')),'w',encoding='utf-8'), ensure_ascii=False, indent=1)
    print('RESULT', json.dumps({'stats': P.stats, 'parts': len(v), 'bad': [x for x in v if x['testzip']!='OK']}, ensure_ascii=False))

# ---------- directory materializer (used by gitbuild.py) ----------
class DirPacker(Packer):
    """Same filters as Packer but writes into a plain directory (for building the reconstructed git repo)."""
    def __init__(self, spec, target):
        self.target = target
        super().__init__(spec)
    def newpart(self): pass
    def add_bytes(self, arc, data, mtime, src, status='included', dup=''):
        p = os.path.join(self.target, *arc.split('/'))
        os.makedirs(LP(os.path.dirname(p)), exist_ok=True)
        with open(LP(p), 'wb') as f: f.write(data)
        self.stats['bytes'] += len(data)
        self.wm.writerow([self.pkg, 'dir', arc, src, len(data), hashlib.sha256(data).hexdigest(), time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(mtime)), status, dup])
    def run_tar(self, tarpath, arc0, prof='code', exclude_rx=()):
        import tarfile
        ex = [re.compile(x, re.I) for x in exclude_rx]
        with tarfile.open(LP(tarpath)) as tf:
            for m in tf:
                if not m.isfile(): continue
                parts = m.name.split('/'); name = parts[-1]; dparts = parts[:-1]
                reason = None
                for i, d in enumerate(dparts):
                    dl = d.lower()
                    if dl in REBUILD_DIRS or REBUILD_DIR_RX.match(d): reason = 'rebuildable_dir'
                    elif SENS_DIR_RX.search(d): reason = 'sensitive_dir'
                    elif DATA_DIR_RX.match(d): reason = 'data_or_evidence_dir'
                    elif RUN_DIR_RX.search(d): reason = 'run_output_dir'
                    if reason: break
                if not reason and any(rx.search(m.name.replace('/','\\')) for rx in ex): reason = 'excluded_by_spec_rx'
                src = 'git-tree:' + m.name
                if reason: self.excl(src, reason, m.size); continue
                kind, r2 = classify_name(dparts, name, m.size, prof)
                if kind == 'x': self.excl(src, r2, m.size); continue
                b = tf.extractfile(m).read()
                status = 'included'
                if kind == 't' or os.path.splitext(name.lower())[1] in TEXT_EXT:
                    s, hits, cust = scan_text(b, name)
                    if cust: self.excl(src, 'customer_data_fields', m.size); continue
                    if hits:
                        if s is None: self.excl(src, 'secret_or_pii_undecodable', m.size); continue
                        b = redact(s).encode('utf-8'); status = 'redacted'; self.stats['redacted'] += 1
                        self.wr.writerow([self.pkg, arc0 + '/' + m.name, src, '|'.join(sorted(set(hits))), 'redacted_copy'])
                self.add_bytes(arc0 + '/' + m.name, b, m.mtime, src, status)
                self.stats['included'] += 1
