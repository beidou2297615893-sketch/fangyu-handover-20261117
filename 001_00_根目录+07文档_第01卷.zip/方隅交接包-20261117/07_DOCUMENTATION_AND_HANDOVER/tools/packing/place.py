import os,shutil,hashlib,zipfile,json
X=r'C:\Users\rmsama\AppData\Local\Temp\fyho\xfer'; O='\\\\?\\C:\\方隅交接包-20261117'
exp={'01_CORE_SOURCE.box.part01.zip':('01_CORE_SOURCE','2560dd684e6407154fe960d95bdfafafd2993baa2a354c753c8f053bbb43942e'),
'04_UI_AND_NEW_FEATURES.box.part01.zip':('04_UI_AND_NEW_FEATURES','600926faf3c2f5cba88b830ae63354d4ae4334f1def28af6915af7c0ec13c996'),
'04_UI_AND_NEW_FEATURES.box.part02.zip':('04_UI_AND_NEW_FEATURES','ebc95b30cfa941c2c42271acdd5d9cc9035525e4c307a59b2c9f03b7d139a1c7'),
'06_DATABASE_AND_MIGRATIONS.part01.zip':('06_DATABASE_AND_MIGRATIONS','6e858c1d713efe0bcb46f406fe5d070aa26e3d39153a1d01149a692f1eeb2798'),
'07_DOCUMENTATION_AND_HANDOVER.box-legacy-docs.part01.zip':('07_DOCUMENTATION_AND_HANDOVER','1154be28aa824d8a4ff9bb368a55b4d72a92b3f52848f3df42d52a6b9eefd41f')}
for p in ('01','02'):
    t=os.path.join(X,f'04_UI_AND_NEW_FEATURES.box.part{p}.zip')
    if not os.path.exists(t):
        with open(t,'wb') as w:
            for i in range(4): w.write(open(os.path.join(X,f'p{p}.chunk0{i}'),'rb').read())
for n,(d,h) in exp.items():
    s=os.path.join(X,n); got=hashlib.sha256(open(s,'rb').read()).hexdigest()
    ok=got==h and zipfile.ZipFile(s).testzip() is None
    if ok:
        os.makedirs(os.path.join(O,d),exist_ok=True); shutil.copyfile(s,os.path.join(O,d,n))
    print(n,ok)
