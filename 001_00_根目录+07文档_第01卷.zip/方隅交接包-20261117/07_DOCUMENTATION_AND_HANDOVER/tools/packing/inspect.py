import os,json,sys,sqlite3,time,urllib.parse,re
sys.path.insert(0,os.path.dirname(__file__));from fypack import LP,UNLP
O=r'C:\方隅交接包-20261117'
T=r'C:\Users\rmsama\AppData\Local\Temp\fyho'
paths=[r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261114',r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261114-backup-20261117',r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117']
for p in paths:
 print('DIR',p)
 for r,ds,fs in os.walk(LP(p)):
  rel=os.path.relpath(UNLP(r),p)
  if rel.count('\\')>1: ds[:]=[];continue
  for f in fs: print(os.path.join(rel,f),os.path.getsize(os.path.join(r,f)))
F=r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统'
D=F+r'\work'
dbs=[D+r'\fangyu-douyin-independent\runtime\collection.sqlite3',D+r'\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3',D+r'\shared-acquisition-ledger\shared.sqlite3',F+r'\Codex获客工作台\work\campaign.sqlite3',F+r'\Codex获客工作台\work\codex_reviews.sqlite3',r'C:\积木软件工坊\项目\方隅公寓客户版\work\region-followup-20261027\verification\actual-data-1793083003306682900\workspace.sqlite3',r'C:\Users\rmsama\AppData\Local\FangyuDesktopPreview-20261114-state\employee-data\workspace.sqlite3',D+r'\fangyu-text-business-20261029\local-rule-pipeline\fixtures\real-source-check\derived.sqlite3']
# Add other DBs by pre-inventoried filename locations only; no user rows are selected.
res=[]
for p in dbs:
 row={'source':p,'mode':'ro','query_only':True,'tables':[],'error':None,'count_policy':'exact count, each table max 5 seconds; running DB is not atomic across DBs'}
 try:
  hdr=open(LP(p),'rb').read(100); wal=(hdr[18]==2 and hdr[19]==2); row['journal']='wal' if wal else 'rollback/unknown(header %d/%d)'%(hdr[18],hdr[19])
  row['wal_present']=os.path.exists(LP(p+'-wal'))
  uri='file:'+urllib.parse.quote(p.replace('\\','/'),safe=':/')+('?mode=ro' if wal else '?mode=ro&immutable=1')
  if not wal: row['count_policy']='not WAL: schema only via immutable read; row counts skipped to avoid holding locks on a live DB'
  c=sqlite3.connect(uri,uri=True,timeout=0.2);c.execute('PRAGMA query_only=ON');c.execute('PRAGMA busy_timeout=200')
  c.execute('BEGIN')
  schema=c.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name").fetchall()
  row['objects']=[dict(zip(['type','name','table','sql'],x)) for x in schema]
  for typ,name,tbl,sql in schema:
   if typ!='table' or not wal:continue
   t=time.monotonic();c.set_progress_handler(lambda:int(time.monotonic()-t>5),20000)
   try: n=c.execute('SELECT count(*) FROM "'+name.replace('"','""')+'"').fetchone()[0];err=None
   except Exception as e:n=None;err=type(e).__name__+':'+str(e)
   row['tables'].append({'table':name,'row_count':n,'error':err,'seconds':round(time.monotonic()-t,3)})
   c.set_progress_handler(None,0)
  c.rollback();c.close()
 except Exception as e:row['error']=type(e).__name__+':'+str(e)
 res.append(row);print('DBDONE',os.path.basename(p),len(row['tables']),flush=True)
os.makedirs(LP(O+r'\06_DATABASE_AND_MIGRATIONS'),exist_ok=True)
j=json.dumps(res,ensure_ascii=False,indent=1)
open(LP(O+r'\06_DATABASE_AND_MIGRATIONS\schema_rowcounts.json'),'w',encoding='utf-8').write(j)
open(LP(T+r'\schema_rowcounts.json'),'w',encoding='utf-8').write(j)
