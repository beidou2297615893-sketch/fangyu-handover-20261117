import json,sqlite3,os,re,ntpath
d=json.load(open('schema_rowcounts.json'))
desc={'collection.sqlite3':'抖音独立采集账本（运行中，约15.3GB）','runner-cache-v7.sqlite3':'抖音 runner 缓存 v7（约1.08GB）','shared.sqlite3':'跨平台共享获客账本（leads/预留/已发，约28MB）','campaign.sqlite3':'Codex获客工作台 旧活动库（10-11 后未更新）','codex_reviews.sqlite3':'Codex 复核记录','workspace.sqlite3':'客户端 workspace（验证实数副本 / 11-14 Preview state）','derived.sqlite3':'文字业务本地规则流水线派生库（目录名 real-source-check，含真实来源，原件不打包）'}
md=['# DATABASE_SCHEMA（2026-11-17 约15:05 北京时间只读导出）\n','导出方式：`sqlite3` URI `mode=ro`（WAL 库）或 `mode=ro&immutable=1`（非 WAL 库，不计行数），`PRAGMA query_only=ON`，只读 `sqlite_master` 与 `count(*)`（每表 ≤5 秒），**未读取任何业务行内容**。各库计数不是同一时刻的原子快照（采集仍在写）。\n','| # | 来源库 | 日志模式 | 表数 | 说明 |','|---|---|---|---|---|']
order={'table':0,'view':1,'index':2,'trigger':3}
for i,x in enumerate(d,1):
    b=ntpath.basename(x['source']); key=f"{i:02d}_{b.replace('.sqlite3','')}"
    objs=sorted(x['objects'],key=lambda o:order.get(o['type'],9))
    open(f'pkg06/migrations/{key}.schema.sql','w').write(f"-- source: {x['source']}\n-- exported read-only 2026-11-17; schema only, no rows\n"+';\n\n'.join(o['sql'] for o in objs)+';\n')
    md.append(f"| {i} | `{x['source']}` | {x.get('journal')} | {sum(1 for o in objs if o['type']=='table')} | {desc.get(b,'')} |")
    c=sqlite3.connect(f'pkg06/fixtures/{key}.FICTIONAL.sqlite3'); fails=[]
    for o in objs:
        if not o['name'].startswith('sqlite_'):
            try:c.execute(o['sql'])
            except Exception as e: fails.append(o['name'])
    for o in objs:
        if o['type']!='table' or o['name'].startswith('sqlite_'):continue
        cols=c.execute(f'PRAGMA table_info("{o["name"]}")').fetchall()
        for n in (1,2):
            vals=[]
            for cid,cn,ct,nn,dv,pk in cols:
                t=(ct or '').upper()
                if 'INT' in t or cn in('singleton',): vals.append(1 if cn=='singleton' else n)
                elif re.search(r'(data|spec|response|evidence|detail|counts|body|result)$',cn): vals.append(json.dumps({"fictional":True,"note":"虚构样例","n":n},ensure_ascii=False))
                elif re.search(r'(_at|time|collected)$',cn): vals.append(f'2026-01-0{n}T00:00:00+08:00')
                else: vals.append(f'DEMO-{cn}-{n}')
            try:c.execute(f'INSERT INTO "{o["name"]}" VALUES ({",".join("?"*len(vals))})',vals)
            except Exception as e: fails.append(f'{o["name"]}#{n}:{type(e).__name__}')
    c.commit();c.close()
    if fails: print(key,fails)
md.append('\n## 各表行数（只读 count）\n')
for i,x in enumerate(d,1):
    md.append(f"### {i}. `{ntpath.basename(x['source'])}`\n\n- 路径：`{x['source']}`\n- 计数策略：{x['count_policy']}\n\n| 表 | 行数 |\n|---|---|")
    tabs={t['table']:t['row_count'] for t in x['tables']}
    for o in x['objects']:
        if o['type']=='table': md.append(f"| {o['name']} | {tabs.get(o['name'],'—（未计数）')} |")
    md.append('')
md.append('''## 未导出 / 限制
- 未复制任何正在写入的 DB 原件，也未复制历史备份库（`fangyu-douyin-independent\\*-backup*\\collection.sqlite3` 等 13 个以上，0.07–9.2GB），只在本文件与排除清单中记路径。
- 知题线上数据库（腾讯云 CloudBase 环境 `fh6-d5ga45c0ddae7008c`）未连线导出；结构以 03 包 `quiz/current-0.4.27/云函数` 源码和《套餐和试用规则说明.md》为准。
- `fixtures/*.FICTIONAL.sqlite3`：按真实 schema 建表（含索引），每表 2 行明显虚构值（DEMO-*、2026-01-0x、{"fictional":true}）。单例/唯一约束表可能只有 1 行。
- 建空库：`sqlite3 new.sqlite3 < migrations/03_shared.schema.sql`。真实数据迁移只能由用户本人在本机拷贝（停写后或用 sqlite `.backup`），不经过上传包，见 DEPLOYMENT.md。
''')
open('pkg06/DATABASE_SCHEMA.md','w').write('\n'.join(md))
