import re,sys
rx=re.compile(r'(?<![\d.])1[3-9]\d{9}(?![\d])')
for p in sys.argv[1:]:
    s=open('\\\\?\\'+p,encoding='utf-8',errors='replace').read()
    for m in list(rx.finditer(s))[:4]:
        c=s[max(0,m.start()-40):m.end()+15]
        print(p[-60:], '|', re.sub(r'\d','#',c).replace('\n',' '))
