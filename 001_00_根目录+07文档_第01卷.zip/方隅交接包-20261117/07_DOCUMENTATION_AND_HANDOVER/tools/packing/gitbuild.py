# -*- coding: utf-8 -*-
"""重建“方隅版本历史”仓库：只读原始来源，所有提交都是重建快照，不是原始开发提交。"""
import os, sys, json, subprocess, shutil, time, stat
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fypack
from fypack import LP, DirPacker
O = r'C:\方隅交接包-20261117'
WORK = O + r'\_work'
REPO = WORK + r'\fangyu-version-history'
TMP = WORK + r'\tmp'
GIT = 'git'
W = r'C:\积木软件工坊\项目\方隅公寓客户版\work'
PI = W + r'\parallel-integration-20261018\final-integration'
F = r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统'
ORIG_GIT = F + r'\.git'
ENGINE_EX = [r'(?i)(^|\\)(archive[^\\]*|[^\\]*backup[^\\]*|_backup[^\\]*|tmp[^\\]*|[^\\]*-evidence[^\\]*|outputs)(\\|$)']
STEPS = [
 dict(id='s1', date='2026-10-13T18:35:00+08:00', comp='engine', tree='15c5d08ed983bb2773d81c7e8fb2d91d3dc1739f', tag='snap/engine-codex-20261013', msg='engine: Codex checkpoint tree 15c5d08 (refs recorded 10-13 18:35 and 22:22)'),
 dict(id='s2', date='2026-10-15T12:53:00+08:00', comp='engine', tree='ec152e886e8e0320fb5ed287653c159ff972d748', tag='snap/engine-codex-20261015', msg='engine: Codex checkpoint tree ec152e8'),
 dict(id='s3', date='2026-10-16T21:44:00+08:00', comp='engine', tree='4c40d02c09e1cb31608ef03bf2f4831fc057b8fb', tag='snap/engine-codex-20261016', msg='engine: Codex checkpoint tree 4c40d02'),
 dict(id='s4', date='2026-10-18T12:17:00+08:00', comp='desktop-ui/A-approved-preview', src=W + r'\ui-approved-implementation', prof='ui', images_ok=True, tag='ui/A-approved-preview-20261018', msg='desktop-ui: A ui-approved-implementation (user-approved light UI, front-end preview)'),
 dict(id='s5', date='2026-10-18T18:30:09+08:00', comp='desktop-ui/r57-release', src=PI + r'\candidate-unified-v6\project\work\ui-native-r57\releases\ui-r57-20261018T103009Z-ebd9da3c', prof='ui', tag='r57/B-20261018T103009Z-ebd9da3c', msg='desktop-ui: B r57 release ui-r57-20261018T103009Z-ebd9da3c'),
 dict(id='s6', date='2026-10-25T09:56:09+08:00', comp='desktop-ui/r57-release', src=PI + r'\candidate-unified-v107\project\work\ui-native-r57\releases\ui-r57-20261025T015609Z-8a7e4038', prof='ui', tag='r57/C-20261025T015609Z-8a7e4038', branch='stable-pre-ui-overhaul', msg='desktop-ui: C r57 release ui-r57-20261025T015609Z-8a7e4038 (last r57 release before 10-25 13:06 spacious redesign)'),
 dict(id='s7', date='2026-10-27T21:29:14+08:00', comp='desktop-ui/r57-release', src=W + r'\combined-full-candidate-20261027\project\work\ui-native-r57\releases\ui-r57-20261027T130512Z-a9ba360f', prof='ui', tag='r57/F-freeze-20261027T130512Z-a9ba360f', msg='desktop-ui: 10-27 frozen r57 release a9ba360f'),
 dict(id='s8', date='2026-11-17T12:00:00+08:00', comp='desktop-ui/installed', src=r'C:\Users\rmsama\AppData\Local\FangyuDesktopDirect-20261117', prof='ui', tag='install/FangyuDesktopDirect-20261117', msg='desktop-ui: current install FangyuDesktopDirect-20261117 (light UI restored from A)'),
 dict(id='s9', date='2026-11-17T15:00:00+08:00', comp='engine', src=F, prof='code', skip=['outputs','memory','data','work\\_backup','ONLYOFFICE办公软件','设计实习首日汇报'], exclude_rx=ENGINE_EX, tag='snap/engine-current-20261117', branch='current-20261117', msg='engine: current working tree code snapshot 2026-11-17 (filtered; no ledgers/runtime/state)'),
]
def run(args, **kw):
    r = subprocess.run(args, capture_output=True, **kw)
    if r.returncode != 0: raise RuntimeError('%s -> %s %s' % (args, r.returncode, r.stderr[-2000:]))
    return r.stdout
def g(*a, env=None): return run([GIT, '-C', REPO] + list(a), env=env)
def rmtree(p):
    def onerr(f, path, ex):
        os.chmod(path, stat.S_IWRITE); f(path)
    if os.path.exists(LP(p)): shutil.rmtree(LP(p), onerror=onerr)
def main():
    os.makedirs(LP(TMP), exist_ok=True)
    if os.path.exists(LP(REPO)): raise SystemExit('repo exists; refusing to overwrite: ' + REPO)
    os.makedirs(LP(REPO))
    g('init', '-q', '-b', 'main'); g('config', 'core.longpaths', 'true'); g('config', 'core.autocrlf', 'false'); g('config', 'user.name', 'Fangyu Handover Reconstruction'); g('config', 'user.email', 'handover@fangyu.invalid')
    open(LP(REPO + r'\RECONSTRUCTED_HISTORY.md'), 'w', encoding='utf-8').write('# 重建的版本历史（非原始开发提交）\n\n本仓库每个提交都是在 2026-11-17 由交接脚本从现存快照目录或 Codex checkpoint tree 重建的。提交时间=快照时间，作者统一为重建者。\n账本、运行证据、浏览器状态、凭据、可重建依赖已按 fypack 规则排除，命中密钥/隐私模式的文本已脱敏。\n')
    log = []
    for s in STEPS:
        t0 = time.time()
        dst = os.path.join(REPO, *s['comp'].split('/'))
        rmtree(dst)
        spec = dict(out_dir=O, package='05_GIT_FULL_HISTORY', part_prefix='gitbuild', log_prefix='05_GIT.gitbuild.' + s['id'], max_part_mib=90, items=[])
        P = DirPacker(spec, REPO)
        if 'tree' in s:
            tar = os.path.join(TMP, s['id'] + '.tar')
            with open(LP(tar), 'wb') as f:
                r = subprocess.run([GIT, '-c', 'safe.directory=*', '--git-dir', ORIG_GIT, 'archive', '--format=tar', s['tree']], stdout=f, stderr=subprocess.PIPE)
            if r.returncode != 0: raise RuntimeError(r.stderr)
            P.run_tar(tar, s['comp'], 'code', ENGINE_EX)
            os.remove(LP(tar))
        else:
            P.run_item(dict(src=s['src'], arc=s['comp'], profile=s.get('prof', 'code'), skip=s.get('skip', []), exclude_rx=s.get('exclude_rx', []), images_ok=s.get('images_ok', False), dedup=False))
        P.close()
        g('add', '-A', '-f')
        env = dict(os.environ, GIT_AUTHOR_DATE=s['date'], GIT_COMMITTER_DATE=s['date'])
        g('commit', '-q', '--allow-empty', '-m', '[reconstructed] ' + s['msg'], '-m', 'source: ' + (s.get('src') or ('orig .git tree ' + s['tree'])) + '\nreconstructed-at: 2026-11-17 by handover script; not an original developer commit', env=env)
        cid = g('rev-parse', 'HEAD').decode().strip()
        g('tag', '-a', s['tag'], '-m', s['msg'], env=env)
        if s.get('branch'): g('branch', s['branch'])
        log.append(dict(step=s['id'], commit=cid, tag=s['tag'], branch=s.get('branch'), date=s['date'], comp=s['comp'], stats=P.stats, seconds=int(time.time() - t0)))
        print('STEP', json.dumps(log[-1], ensure_ascii=False), flush=True)
    json.dump(log, open(LP(O + r'\_logs\05_GIT.gitbuild.result.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(g('count-objects', '-vH').decode())
if __name__ == '__main__': main()
