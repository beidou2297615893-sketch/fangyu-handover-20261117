# -*- coding: utf-8 -*-
"""按 manifest 把 status=duplicate 的文件从 duplicate_of 复制回原路径。用法: python restore_duplicates.py <解包根目录> <manifest.csv>"""
import csv, os, shutil, sys
root, man = sys.argv[1], sys.argv[2]
n = miss = 0
for r in csv.DictReader(open(man, encoding='utf-8-sig')):
    if r['status'] != 'duplicate': continue
    src = os.path.join(root, *r['duplicate_of'].split('/')); dst = os.path.join(root, *r['arcname'].split('/'))
    if not os.path.exists(src): miss += 1; continue
    os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy2(src, dst); n += 1
print('restored', n, 'missing_source', miss)
