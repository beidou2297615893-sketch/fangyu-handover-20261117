-- source: C:\积木软件工坊\项目\方隅公寓客户版\work\region-followup-20261027\verification\actual-data-1793083003306682900\workspace.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE contact_event_acks(
                  event_id TEXT PRIMARY KEY REFERENCES contact_events(event_id),
                  acked_at REAL NOT NULL);

CREATE TABLE contact_events(
                  sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                  event_id TEXT NOT NULL UNIQUE,
                  reply_id TEXT NOT NULL,
                  kind TEXT NOT NULL,
                  tenant_id TEXT NOT NULL,
                  cloud_owner TEXT NOT NULL,
                  provisional INTEGER NOT NULL,
                  syncable INTEGER NOT NULL,
                  payload TEXT NOT NULL,
                  payload_hash TEXT NOT NULL,
                  previous_hash TEXT NOT NULL,
                  chain_hash TEXT NOT NULL);

CREATE TABLE contact_response_acks(
                observation_id TEXT PRIMARY KEY REFERENCES contact_response_outbox(observation_id),
                acked_at REAL NOT NULL);

CREATE TABLE contact_response_blocks(
                observation_id TEXT PRIMARY KEY REFERENCES contact_response_outbox(observation_id),
                reason TEXT NOT NULL,blocked_at REAL NOT NULL);

CREATE TABLE contact_response_outbox(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                observation_id TEXT NOT NULL UNIQUE,
                tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,
                platform TEXT NOT NULL,post_key TEXT NOT NULL,comment_id TEXT NOT NULL,
                payload TEXT NOT NULL,payload_hash TEXT NOT NULL,
                UNIQUE(tenant_id,cloud_owner,platform,post_key,comment_id));

CREATE TABLE customer_followup_targets_v1(
    id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,body TEXT NOT NULL);

CREATE TABLE customer_read_epoch_v1(singleton INTEGER PRIMARY KEY CHECK(singleton=1),version INTEGER NOT NULL,epoch TEXT NOT NULL);

CREATE TABLE customer_read_insert_guard_v1(table_name TEXT NOT NULL,tenant_id TEXT NOT NULL,changed INTEGER NOT NULL,PRIMARY KEY(table_name,tenant_id));

CREATE TABLE customer_read_revision_v1(tenant_id TEXT PRIMARY KEY,revision INTEGER NOT NULL);

CREATE TABLE records(entity TEXT NOT NULL,id TEXT NOT NULL,tenant_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(entity,id));

CREATE TABLE sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL);

CREATE TABLE sqlite_sequence(name,seq);

CREATE TABLE unique_leads(tenant_id TEXT,platform TEXT,source_id TEXT,lead_id TEXT,PRIMARY KEY(tenant_id,platform,source_id));

CREATE INDEX contact_events_reply ON contact_events(reply_id,kind);

CREATE INDEX contact_events_scope ON contact_events(tenant_id,cloud_owner,sequence);

CREATE INDEX response_outbox_scope
                ON contact_response_outbox(tenant_id,cloud_owner,sequence);

CREATE INDEX scope ON records(entity,tenant_id);

CREATE TRIGGER contact_events_no_delete BEFORE DELETE ON contact_events
                  BEGIN SELECT RAISE(ABORT,'contact events are append only'); END;

CREATE TRIGGER contact_events_no_update BEFORE UPDATE ON contact_events
                  BEGIN SELECT RAISE(ABORT,'contact events are append only'); END;

CREATE TRIGGER "customer_read_v1_contact_event_acks_before_insert" BEFORE INSERT ON "contact_event_acks" BEGIN DELETE FROM customer_read_insert_guard_v1 WHERE table_name='contact_event_acks';INSERT INTO customer_read_insert_guard_v1(table_name,tenant_id,changed) SELECT 'contact_event_acks',(SELECT tenant_id FROM contact_events WHERE event_id=t.event_id),MAX(NOT (t."event_id" IS NEW."event_id" AND t."acked_at" IS NEW."acked_at")) FROM "contact_event_acks" t WHERE ((NEW."event_id" IS NOT NULL AND t."event_id"=NEW."event_id")) AND (SELECT tenant_id FROM contact_events WHERE event_id=t.event_id) IS NOT NULL GROUP BY (SELECT tenant_id FROM contact_events WHERE event_id=t.event_id); END;

CREATE TRIGGER "customer_read_v1_contact_event_acks_delete" AFTER DELETE ON "contact_event_acks" BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT (SELECT tenant_id FROM contact_events WHERE event_id=OLD.event_id),1 WHERE (SELECT tenant_id FROM contact_events WHERE event_id=OLD.event_id) IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1; END;

CREATE TRIGGER "customer_read_v1_contact_event_acks_insert" AFTER INSERT ON "contact_event_acks" BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT tenant_id,1 FROM customer_read_insert_guard_v1 WHERE table_name='contact_event_acks' AND changed=1 ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT (SELECT tenant_id FROM contact_events WHERE event_id=NEW.event_id),1 WHERE (SELECT tenant_id FROM contact_events WHERE event_id=NEW.event_id) IS NOT NULL AND NOT EXISTS(SELECT 1 FROM customer_read_insert_guard_v1 WHERE table_name='contact_event_acks' AND tenant_id=(SELECT tenant_id FROM contact_events WHERE event_id=NEW.event_id) AND changed=0) ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;DELETE FROM customer_read_insert_guard_v1 WHERE table_name='contact_event_acks'; END;

CREATE TRIGGER "customer_read_v1_contact_event_acks_update" AFTER UPDATE ON "contact_event_acks" WHEN NOT (OLD."event_id" IS NEW."event_id" AND OLD."acked_at" IS NEW."acked_at") BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT (SELECT tenant_id FROM contact_events WHERE event_id=OLD.event_id),1 WHERE (SELECT tenant_id FROM contact_events WHERE event_id=OLD.event_id) IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT (SELECT tenant_id FROM contact_events WHERE event_id=NEW.event_id),1 WHERE (SELECT tenant_id FROM contact_events WHERE event_id=NEW.event_id) IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1; END;

CREATE TRIGGER "customer_read_v1_contact_events_before_insert" BEFORE INSERT ON "contact_events" BEGIN DELETE FROM customer_read_insert_guard_v1 WHERE table_name='contact_events';INSERT INTO customer_read_insert_guard_v1(table_name,tenant_id,changed) SELECT 'contact_events',t.tenant_id,MAX(NOT (t."sequence" IS NEW."sequence" AND t."event_id" IS NEW."event_id" AND t."reply_id" IS NEW."reply_id" AND t."kind" IS NEW."kind" AND t."tenant_id" IS NEW."tenant_id" AND t."cloud_owner" IS NEW."cloud_owner" AND t."provisional" IS NEW."provisional" AND t."syncable" IS NEW."syncable" AND t."payload" IS NEW."payload" AND t."payload_hash" IS NEW."payload_hash" AND t."previous_hash" IS NEW."previous_hash" AND t."chain_hash" IS NEW."chain_hash" AND NEW."sequence"<>-1)) FROM "contact_events" t WHERE ((NEW."sequence" IS NOT NULL AND t."sequence"=NEW."sequence") OR (NEW."event_id" IS NOT NULL AND t."event_id"=NEW."event_id")) AND t.tenant_id IS NOT NULL GROUP BY t.tenant_id; END;

CREATE TRIGGER "customer_read_v1_contact_events_delete" AFTER DELETE ON "contact_events" BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT OLD.tenant_id,1 WHERE OLD.tenant_id IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1; END;

CREATE TRIGGER "customer_read_v1_contact_events_insert" AFTER INSERT ON "contact_events" BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT tenant_id,1 FROM customer_read_insert_guard_v1 WHERE table_name='contact_events' AND changed=1 ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT NEW.tenant_id,1 WHERE NEW.tenant_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM customer_read_insert_guard_v1 WHERE table_name='contact_events' AND tenant_id=NEW.tenant_id AND changed=0) ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;DELETE FROM customer_read_insert_guard_v1 WHERE table_name='contact_events'; END;

CREATE TRIGGER "customer_read_v1_contact_events_update" AFTER UPDATE ON "contact_events" WHEN NOT (OLD."sequence" IS NEW."sequence" AND OLD."event_id" IS NEW."event_id" AND OLD."reply_id" IS NEW."reply_id" AND OLD."kind" IS NEW."kind" AND OLD."tenant_id" IS NEW."tenant_id" AND OLD."cloud_owner" IS NEW."cloud_owner" AND OLD."provisional" IS NEW."provisional" AND OLD."syncable" IS NEW."syncable" AND OLD."payload" IS NEW."payload" AND OLD."payload_hash" IS NEW."payload_hash" AND OLD."previous_hash" IS NEW."previous_hash" AND OLD."chain_hash" IS NEW."chain_hash") BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT OLD.tenant_id,1 WHERE OLD.tenant_id IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT NEW.tenant_id,1 WHERE NEW.tenant_id IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1; END;

CREATE TRIGGER "customer_read_v1_records_before_insert" BEFORE INSERT ON "records" WHEN NEW.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1') BEGIN DELETE FROM customer_read_insert_guard_v1 WHERE table_name='records';INSERT INTO customer_read_insert_guard_v1(table_name,tenant_id,changed) SELECT 'records',t.tenant_id,MAX(NOT (t."entity" IS NEW."entity" AND t."id" IS NEW."id" AND t."tenant_id" IS NEW."tenant_id" AND t."body" IS NEW."body")) FROM "records" t WHERE ((NEW."entity" IS NOT NULL AND t."entity"=NEW."entity" AND NEW."id" IS NOT NULL AND t."id"=NEW."id")) AND t.tenant_id IS NOT NULL GROUP BY t.tenant_id; END;

CREATE TRIGGER "customer_read_v1_records_delete" AFTER DELETE ON "records" WHEN OLD.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1') BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT OLD.tenant_id,1 WHERE OLD.tenant_id IS NOT NULL ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1; END;

CREATE TRIGGER "customer_read_v1_records_insert" AFTER INSERT ON "records" WHEN NEW.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1') BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT tenant_id,1 FROM customer_read_insert_guard_v1 WHERE table_name='records' AND changed=1 ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT NEW.tenant_id,1 WHERE NEW.tenant_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM customer_read_insert_guard_v1 WHERE table_name='records' AND tenant_id=NEW.tenant_id AND changed=0) ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;DELETE FROM customer_read_insert_guard_v1 WHERE table_name='records'; END;

CREATE TRIGGER "customer_read_v1_records_update" AFTER UPDATE ON "records" WHEN (OLD.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1') OR NEW.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1')) AND NOT (OLD."entity" IS NEW."entity" AND OLD."id" IS NEW."id" AND OLD."tenant_id" IS NEW."tenant_id" AND OLD."body" IS NEW."body") BEGIN INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT OLD.tenant_id,1 WHERE OLD.tenant_id IS NOT NULL AND OLD.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1') ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;INSERT INTO customer_read_revision_v1(tenant_id,revision) SELECT NEW.tenant_id,1 WHERE NEW.tenant_id IS NOT NULL AND NEW.entity IN ('leads','accounts','tasks','replies','rental_assessments_v1','rental_task_context_v1','customer_outcome_events','ui_customer_handoff_v1','ui_reply_requests_v1','lead_task_observations_v1') ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1; END;

CREATE TRIGGER followup_target_no_delete BEFORE DELETE ON customer_followup_targets_v1
     BEGIN SELECT RAISE(ABORT,'followup target is immutable'); END;

CREATE TRIGGER followup_target_no_update BEFORE UPDATE ON customer_followup_targets_v1
     BEGIN SELECT RAISE(ABORT,'followup target is immutable'); END;

CREATE TRIGGER response_outbox_no_delete BEFORE DELETE ON contact_response_outbox
                BEGIN SELECT RAISE(ABORT,'response outbox is append only'); END;

CREATE TRIGGER response_outbox_no_update BEFORE UPDATE ON contact_response_outbox
                BEGIN SELECT RAISE(ABORT,'response outbox is append only'); END;
