-- source: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\campaign.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE checkpoint(key text primary key,value text);

CREATE TABLE comment_index(id text primary key,recent integer,user_id text);

CREATE TABLE records(id text primary key,user_id text,data text,score integer,tier text,urgent integer,budget integer);

CREATE TABLE reply_queue(cid text primary key,data text,visits integer default 0,exhausted integer default 0);

CREATE TABLE search_state(qid integer primary key,cursor integer default 0,pages integer default 0,exhausted integer default 0);

CREATE TABLE video_queue(vid text primary key,data text,hint integer,visits integer default 0,exhausted integer default 0);

CREATE INDEX records_user on records(user_id);
