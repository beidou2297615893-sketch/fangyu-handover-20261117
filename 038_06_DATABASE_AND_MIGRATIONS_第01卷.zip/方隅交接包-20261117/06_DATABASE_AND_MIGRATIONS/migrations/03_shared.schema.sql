-- source: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE assessments(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,data TEXT NOT NULL,updated INTEGER NOT NULL,PRIMARY KEY(platform,customer,comment), FOREIGN KEY(platform,customer,comment) REFERENCES leads(platform,customer,comment));

CREATE TABLE business_cleared_fingerprints(digest TEXT PRIMARY KEY);

CREATE TABLE collection_uid_observations(
    platform TEXT NOT NULL, platform_uid TEXT NOT NULL, canonical TEXT NOT NULL,
    basis TEXT NOT NULL, source TEXT NOT NULL, observed_at INTEGER NOT NULL,
    PRIMARY KEY(platform,platform_uid), UNIQUE(platform,canonical));

CREATE TABLE historical_assessments(platform TEXT NOT NULL,customer TEXT NOT NULL,source TEXT NOT NULL,data TEXT NOT NULL,recorded INTEGER NOT NULL,PRIMARY KEY(platform,customer,source));

CREATE TABLE historical_deliveries(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,reference TEXT NOT NULL,delivery_state TEXT NOT NULL,source TEXT NOT NULL,recorded INTEGER NOT NULL,PRIMARY KEY(platform,reference,comment));

CREATE TABLE identity_aliases(platform TEXT NOT NULL, alias TEXT NOT NULL, canonical TEXT NOT NULL, evidence TEXT NOT NULL, verified INTEGER NOT NULL, PRIMARY KEY(platform,alias));

CREATE TABLE leads(platform TEXT NOT NULL, customer TEXT NOT NULL, comment TEXT NOT NULL, status TEXT NOT NULL, review_time INTEGER, evidence TEXT, operator TEXT, source TEXT NOT NULL, PRIMARY KEY(platform,customer,comment), UNIQUE(platform,comment));

CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY, data TEXT NOT NULL, FOREIGN KEY(token) REFERENCES reservations(token));

CREATE TABLE reservations(token TEXT PRIMARY KEY, platform TEXT NOT NULL, customer TEXT NOT NULL, comment TEXT NOT NULL, status TEXT NOT NULL, evidence TEXT, created INTEGER NOT NULL, FOREIGN KEY(platform,customer,comment) REFERENCES leads(platform,customer,comment));

CREATE TABLE searches(event TEXT PRIMARY KEY, store TEXT NOT NULL, platform TEXT NOT NULL, keyword TEXT NOT NULL, status TEXT NOT NULL, result TEXT NOT NULL, recorded INTEGER NOT NULL);

CREATE TABLE words(store TEXT NOT NULL, keyword TEXT NOT NULL, category TEXT NOT NULL, priority TEXT NOT NULL, evidence TEXT NOT NULL, condition TEXT NOT NULL, source TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'candidate', PRIMARY KEY(store,keyword,source));
