-- source: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline\fixtures\real-source-check\derived.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE candidates(
      platform TEXT,customer_key TEXT,comment_id TEXT,batch_id TEXT,data TEXT,
      PRIMARY KEY(platform,customer_key));

CREATE TABLE exceptions(
      platform TEXT,comment_id TEXT,exception_type TEXT,scenario TEXT,
      needs_model_review INTEGER,data TEXT,PRIMARY KEY(platform,comment_id));

CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);

CREATE TABLE observations(
      platform TEXT NOT NULL,source_rowid INTEGER NOT NULL,request_id TEXT NOT NULL,
      stable_key TEXT NOT NULL,account_uid TEXT,store_id TEXT,keyword TEXT,target TEXT,
      collected_at TEXT,identity_digest TEXT,malformed INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY(platform,source_rowid));

CREATE TABLE qualified(
      platform TEXT,request_id TEXT,target TEXT,account_uid TEXT,qualification TEXT,
      PRIMARY KEY(platform,request_id));

CREATE TABLE result_identities(
      platform TEXT,stable_key TEXT,comment_id TEXT,customer_uid TEXT,identity_digest TEXT,
      PRIMARY KEY(platform,stable_key));

CREATE TABLE result_topics(
      platform TEXT,comment_id TEXT,pool TEXT,PRIMARY KEY(platform,comment_id,pool));

CREATE TABLE results(
      platform TEXT NOT NULL,comment_id TEXT NOT NULL,stable_key TEXT NOT NULL,
      customer_uid TEXT,method TEXT,rule_version TEXT,input_digest TEXT,
      interest TEXT,role TEXT,exception_type TEXT,needs_model_review INTEGER,
      batch_id TEXT,data TEXT NOT NULL,PRIMARY KEY(platform,comment_id));

CREATE TABLE runs(
      batch_id TEXT PRIMARY KEY,created_at REAL,exported INTEGER DEFAULT 0);

CREATE TABLE source_audits(
      platform TEXT,stable_key TEXT,comment_id TEXT,customer_uid TEXT,data TEXT,
      PRIMARY KEY(platform,stable_key));

CREATE TABLE videos(
      platform TEXT,video_id TEXT,body TEXT,author_uid TEXT,context_digest TEXT,
      PRIMARY KEY(platform,video_id));

CREATE INDEX candidate_batch ON candidates(batch_id);

CREATE INDEX exception_group ON exceptions(needs_model_review,scenario);

CREATE INDEX obs_key ON observations(platform,stable_key,request_id);

CREATE INDEX obs_request ON observations(platform,request_id,stable_key);

CREATE INDEX result_batch ON results(batch_id);

CREATE INDEX result_method ON results(method);

CREATE INDEX result_stable ON results(platform,stable_key);

CREATE INDEX source_audit_customer ON source_audits(platform,customer_uid);
