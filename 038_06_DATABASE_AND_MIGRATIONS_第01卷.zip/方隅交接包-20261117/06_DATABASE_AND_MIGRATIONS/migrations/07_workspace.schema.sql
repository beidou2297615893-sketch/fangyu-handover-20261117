-- source: C:\Users\rmsama\AppData\Local\FangyuDesktopPreview-20261114-state\employee-data\workspace.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE contact_event_acks(
                  event_id TEXT PRIMARY KEY REFERENCES contact_events(event_id),
                  acked_at REAL NOT NULL);

CREATE TABLE contact_events(
                  sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                  event_id TEXT NOT NULL UNIQUE,
                  reply_id TEXT NOT NULL,
                  kind TEXT NOT NULL,
                  tenant_id TEXT NOT NULL,
                  cloud_owner TEXT NOT NULL,
                  provisional INTEGER NOT NULL,
                  syncable INTEGER NOT NULL,
                  payload TEXT NOT NULL,
                  payload_hash TEXT NOT NULL,
                  previous_hash TEXT NOT NULL,
                  chain_hash TEXT NOT NULL);

CREATE TABLE contact_response_acks(
                observation_id TEXT PRIMARY KEY REFERENCES contact_response_outbox(observation_id),
                acked_at REAL NOT NULL);

CREATE TABLE contact_response_blocks(
                observation_id TEXT PRIMARY KEY REFERENCES contact_response_outbox(observation_id),
                reason TEXT NOT NULL,blocked_at REAL NOT NULL);

CREATE TABLE contact_response_outbox(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                observation_id TEXT NOT NULL UNIQUE,
                tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,
                platform TEXT NOT NULL,post_key TEXT NOT NULL,comment_id TEXT NOT NULL,
                payload TEXT NOT NULL,payload_hash TEXT NOT NULL,
                UNIQUE(tenant_id,cloud_owner,platform,post_key,comment_id));

CREATE TABLE customer_followup_targets_v1(
    id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,cloud_owner TEXT NOT NULL,body TEXT NOT NULL);

CREATE TABLE records(entity TEXT NOT NULL,id TEXT NOT NULL,tenant_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(entity,id));

CREATE TABLE sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL);

CREATE TABLE sqlite_sequence(name,seq);

CREATE TABLE unique_leads(tenant_id TEXT,platform TEXT,source_id TEXT,lead_id TEXT,PRIMARY KEY(tenant_id,platform,source_id));

CREATE INDEX contact_events_reply ON contact_events(reply_id,kind);

CREATE INDEX contact_events_scope ON contact_events(tenant_id,cloud_owner,sequence);

CREATE INDEX response_outbox_scope
                ON contact_response_outbox(tenant_id,cloud_owner,sequence);

CREATE INDEX scope ON records(entity,tenant_id);

CREATE TRIGGER contact_events_no_delete BEFORE DELETE ON contact_events
                  BEGIN SELECT RAISE(ABORT,'contact events are append only'); END;

CREATE TRIGGER contact_events_no_update BEFORE UPDATE ON contact_events
                  BEGIN SELECT RAISE(ABORT,'contact events are append only'); END;

CREATE TRIGGER followup_target_no_delete BEFORE DELETE ON customer_followup_targets_v1
     BEGIN SELECT RAISE(ABORT,'followup target is immutable'); END;

CREATE TRIGGER followup_target_no_update BEFORE UPDATE ON customer_followup_targets_v1
     BEGIN SELECT RAISE(ABORT,'followup target is immutable'); END;

CREATE TRIGGER response_outbox_no_delete BEFORE DELETE ON contact_response_outbox
                BEGIN SELECT RAISE(ABORT,'response outbox is append only'); END;

CREATE TRIGGER response_outbox_no_update BEFORE UPDATE ON contact_response_outbox
                BEGIN SELECT RAISE(ABORT,'response outbox is append only'); END;
