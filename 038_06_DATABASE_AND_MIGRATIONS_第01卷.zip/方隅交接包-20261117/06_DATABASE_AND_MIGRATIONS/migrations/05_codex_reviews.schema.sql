-- source: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\codex_reviews.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE review_fullpasses(pass_id text, id text, batch text, data text, primary key(pass_id,id));

CREATE TABLE review_rechecks(id text primary key, batch text, data text);

CREATE TABLE reviews(id text primary key, batch text, data text);
