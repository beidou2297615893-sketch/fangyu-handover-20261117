-- source: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE account_halts(
                    account_uid TEXT PRIMARY KEY, request_id TEXT NOT NULL,
                    state TEXT NOT NULL, detail TEXT NOT NULL, halted_at TEXT NOT NULL);

CREATE TABLE attempts(
                    request_id TEXT PRIMARY KEY, collected_at TEXT NOT NULL,
                    spec TEXT NOT NULL, response TEXT NOT NULL, digest TEXT NOT NULL,
                    state TEXT NOT NULL, detail TEXT NOT NULL, added INTEGER NOT NULL);

CREATE TABLE collection_event_reviews(
 account_uid TEXT NOT NULL,scan_id TEXT NOT NULL,request_id TEXT NOT NULL,response_sha256 TEXT NOT NULL,
 authorization TEXT NOT NULL,evidence TEXT NOT NULL,reviewed_at TEXT NOT NULL,PRIMARY KEY(account_uid,scan_id,request_id));

CREATE TABLE collection_halt_events(
 account_uid TEXT NOT NULL,request_id TEXT PRIMARY KEY,state TEXT NOT NULL,detail TEXT NOT NULL,halted_at TEXT NOT NULL);

CREATE TABLE collection_scope_reviews(
 account_uid TEXT NOT NULL,scan_id TEXT NOT NULL,reviewed_request_id TEXT NOT NULL,
 allowed_keywords TEXT NOT NULL,excluded_videos TEXT NOT NULL,authorization TEXT NOT NULL,
 reviewed_at TEXT NOT NULL,PRIMARY KEY(account_uid,scan_id));

CREATE TABLE entities(
                    stable_key TEXT PRIMARY KEY, kind TEXT NOT NULL, source_id TEXT NOT NULL,
                    first_request TEXT NOT NULL, data TEXT NOT NULL);

CREATE TABLE excluded_comment_fingerprints(digest TEXT PRIMARY KEY, classification_version TEXT NOT NULL, lead_intent TEXT NOT NULL, snapshot_sha256 TEXT NOT NULL);

CREATE TABLE expired_comment_fingerprints(digest TEXT PRIMARY KEY);

CREATE TABLE items(
                    stable_key TEXT PRIMARY KEY, kind TEXT NOT NULL, source_id TEXT NOT NULL,
                    target TEXT NOT NULL, first_request TEXT NOT NULL, data TEXT NOT NULL);

CREATE TABLE ledger_metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);

CREATE TABLE observations(
                    request_id TEXT NOT NULL, stable_key TEXT NOT NULL,
                    scan_id TEXT NOT NULL, account_uid TEXT NOT NULL, store_id TEXT NOT NULL,
                    keyword TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL,
                    collected_at TEXT NOT NULL, data TEXT NOT NULL,
                    PRIMARY KEY(request_id,stable_key));

CREATE TABLE pages(
                    account_uid TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL,
                    cursor INTEGER NOT NULL, request_id TEXT NOT NULL,
                    PRIMARY KEY(account_uid,kind,target,cursor));

CREATE TABLE recent_comment_backfill(
                    request_id TEXT NOT NULL, cid TEXT NOT NULL, account_uid TEXT NOT NULL,
                    age_days INTEGER NOT NULL, backfilled_at TEXT NOT NULL, PRIMARY KEY(request_id,cid));

CREATE TABLE recent_comment_date_review(
                    request_id TEXT NOT NULL, cid TEXT NOT NULL, PRIMARY KEY(request_id,cid));

CREATE TABLE recent_comment_page_counts(request_id TEXT PRIMARY KEY, counts TEXT NOT NULL);

CREATE TABLE recovery_events(
                    event_id INTEGER PRIMARY KEY, account_uid TEXT NOT NULL,
                    request_id TEXT NOT NULL, operator TEXT NOT NULL, reason TEXT NOT NULL,
                    rule_source TEXT NOT NULL, recovered_at TEXT NOT NULL);

CREATE TABLE scan_pages(
                    scan_id TEXT NOT NULL, account_uid TEXT NOT NULL, kind TEXT NOT NULL,
                    target TEXT NOT NULL, store_id TEXT NOT NULL, keyword TEXT NOT NULL,
                    cursor INTEGER NOT NULL, request_id TEXT NOT NULL,
                    PRIMARY KEY(scan_id,account_uid,kind,target,store_id,keyword,cursor));

CREATE TABLE scan_streams(
                    scan_id TEXT NOT NULL, account_uid TEXT NOT NULL, kind TEXT NOT NULL,
                    target TEXT NOT NULL, store_id TEXT NOT NULL, keyword TEXT NOT NULL,
                    cursor INTEGER NOT NULL, exhausted INTEGER NOT NULL, last_request TEXT NOT NULL,
                    PRIMARY KEY(scan_id,account_uid,kind,target,store_id,keyword));

CREATE TABLE streams(
                    account_uid TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL,
                    cursor INTEGER NOT NULL, exhausted INTEGER NOT NULL, last_request TEXT NOT NULL,
                    PRIMARY KEY(account_uid,kind,target));

CREATE INDEX backfill_retention_cid ON recent_comment_backfill(cid);

CREATE INDEX entities_by_kind ON entities(kind);

CREATE INDEX entities_retention_identity ON entities(kind,source_id);

CREATE INDEX items_retention_identity ON items(kind,source_id);

CREATE INDEX observations_by_stream
                    ON observations(scan_id,account_uid,kind,store_id,keyword,target);

CREATE INDEX observations_retention_key ON observations(stable_key) WHERE kind='comments';
