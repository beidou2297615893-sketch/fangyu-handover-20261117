-- source: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3
-- exported read-only 2026-11-17; schema only, no rows
CREATE TABLE admissions(scan TEXT,account TEXT,video TEXT,plan TEXT,store TEXT,scope_store TEXT,scope_keyword TEXT,state TEXT,evidence TEXT,PRIMARY KEY(scan,account,video,plan));

CREATE TABLE comment_relations(request TEXT,cid TEXT,account TEXT,state TEXT,PRIMARY KEY(request,cid));

CREATE TABLE comment_yield(scan TEXT,account TEXT,target TEXT,store TEXT,keyword TEXT,last_added INTEGER,PRIMARY KEY(scan,account,target,store,keyword));

CREATE TABLE counts(scan TEXT,account TEXT,kind TEXT,target TEXT,store TEXT,keyword TEXT,n INTEGER,PRIMARY KEY(scan,account,kind,target,store,keyword));

CREATE TABLE fingerprints(scan TEXT,account TEXT,kind TEXT,target TEXT,digest TEXT,request TEXT,cursor INTEGER,PRIMARY KEY(scan,account,kind,target,digest));

CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT);

CREATE TABLE qualified_comments(policy TEXT,account TEXT,cid TEXT,PRIMARY KEY(policy,account,cid));

CREATE TABLE refs(scan TEXT,account TEXT,video TEXT,store TEXT,keyword TEXT,request TEXT,PRIMARY KEY(scan,account,video,store,keyword,request));

CREATE TABLE videos(scan TEXT,account TEXT,video TEXT,store TEXT,keyword TEXT,request TEXT,body TEXT,published INTEGER,likes INTEGER,PRIMARY KEY(scan,account,video));

CREATE INDEX admission_queue ON admissions(scan,account,plan,store,state);

CREATE INDEX comments_account ON comment_relations(account);

CREATE INDEX refs_video ON refs(scan,account,video);

CREATE INDEX video_scan ON videos(scan,account,store);
