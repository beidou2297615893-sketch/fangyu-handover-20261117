# One-command installer for the local AI workspace backup puller.
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\Install-AIBackup.ps1
#   powershell -ExecutionPolicy Bypass -File .\Install-AIBackup.ps1 -RepoUrl https://github.com/USER/ai-workspace-backup.git
# This script only creates/updates C:\Users\rmsama\Documents\AI-Backup and a current-user scheduled task.
# It does not change other files on this computer.

[CmdletBinding()]
param(
    [string]$RepoUrl = "",
    [string]$Target = "C:\Users\rmsama\Documents\AI-Backup",
    [string]$TaskName = "AI-Workspace-Backup-Pull"
)

$ErrorActionPreference = "Stop"
Write-Host "AI Backup installer"
Write-Host "Target: $Target"

if (-not (Test-Path "C:\Users\rmsama\Documents")) {
    throw "Documents folder not found: C:\Users\rmsama\Documents"
}

New-Item -ItemType Directory -Force -Path $Target | Out-Null
$git = Get-Command git -ErrorAction SilentlyContinue
if (-not $git) {
    throw "git is not installed or not in PATH. Install Git for Windows first."
}

Push-Location $Target
try {
    if (-not (Test-Path (Join-Path $Target ".git"))) {
        git init -b main | Out-Host
        git config user.name "AI Workspace Backup"
        git config user.email "backup@local"
    }

    if ($RepoUrl -and $RepoUrl.Trim().Length -gt 0) {
        $url = $RepoUrl.Trim()
        $existing = git remote 2>$null
        if ($existing -match "origin") {
            git remote set-url origin $url
            Write-Host "Updated origin to the given repo URL."
        } else {
            git remote add origin $url
            Write-Host "Added origin."
        }
        git fetch origin 2>&1 | Out-Host
        git checkout -B main
        git pull --ff-only origin main 2>&1 | Out-Host
    } else {
        Write-Host "No -RepoUrl given. Files already in this folder will be kept."
        Write-Host "When the private GitHub repo is ready, re-run with -RepoUrl."
    }
} finally {
    Pop-Location
}

$pullPs1 = Join-Path $Target "pull-backup.ps1"
$pullBody = @"
# Auto-generated. Pulls the latest backup if origin is configured.
`$ErrorActionPreference = 'Continue'
`$Target = '$Target'
`$Log = Join-Path `$Target 'pull.log'
function Write-Log(`$m) {
    `$line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), `$m
    Add-Content -Path `$Log -Value `$line
}
Set-Location `$Target
if (-not (Test-Path (Join-Path `$Target '.git'))) {
    Write-Log 'No git repo yet; skip.'
    exit 0
}
`$remotes = @(git remote 2>`$null)
if (-not (`$remotes -contains 'origin')) {
    Write-Log 'No origin remote yet; skip pull. Re-run Install-AIBackup.ps1 -RepoUrl <url> when ready.'
    exit 0
}
git pull --ff-only origin main | Tee-Object -FilePath `$Log -Append
exit `$LASTEXITCODE
"@
Set-Content -Path $pullPs1 -Value $pullBody -Encoding UTF8

$taskCmd = "powershell.exe"
$taskArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$pullPs1`""
$taskOk = $false
$prevEap = $ErrorActionPreference
$ErrorActionPreference = "Continue"

# Prefer the PowerShell ScheduledTask module (current-user, no admin).
try {
    $action = New-ScheduledTaskAction -Execute $taskCmd -Argument $taskArgs -WorkingDirectory $Target
    $triggers = @(
        (New-ScheduledTaskTrigger -Daily -At '00:10'),
        (New-ScheduledTaskTrigger -Daily -At '06:10'),
        (New-ScheduledTaskTrigger -Daily -At '12:10'),
        (New-ScheduledTaskTrigger -Daily -At '18:10'),
        (New-ScheduledTaskTrigger -AtLogOn)
    )
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable -MultipleInstances IgnoreNew
    $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -Settings $settings -Principal $principal -Force -ErrorAction Stop | Out-Null
    if (Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop) {
        $taskOk = $true
        Write-Host "Registered scheduled task via Register-ScheduledTask."
    }
} catch {
    Write-Host "Register-ScheduledTask failed: $($_.Exception.Message)"
}

if (-not $taskOk) {
    cmd /c "schtasks /Create /TN `"$TaskName`" /TR `"$taskCmd $taskArgs`" /SC HOURLY /MO 6 /ST 00:10 /F"
    if ($LASTEXITCODE -eq 0) { $taskOk = $true }
}

$ErrorActionPreference = $prevEap

if ($taskOk) {
    Write-Host ""
    Write-Host "Installed scheduled task: $TaskName"
    Write-Host "It runs at logon and every 6 hours (starting 00:10)."
} else {
    Write-Host ""
    Write-Host "WARNING: could not register the scheduled task from this session (often 'Access denied' when not run in an interactive desktop PowerShell)."
    Write-Host "Files are already in $Target. Open a normal PowerShell window and run:"
    Write-Host "  powershell -ExecutionPolicy Bypass -File $Target\Install-AIBackup.ps1"
}

if (-not $RepoUrl) {
    Write-Host "origin is not set yet, so the pull task will log and exit until you re-run with -RepoUrl."
}

Push-Location $Target
git config core.autocrlf false
git config core.filemode false
git status | Out-Host
Pop-Location
Write-Host "Done. Backup folder: $Target"
