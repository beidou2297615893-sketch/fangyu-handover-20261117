# 备份报告

- 时间：2026-11-17 14:53:02（Asia/Shanghai）
- 模式：incremental
- 新拷贝：969 个文件
- 更新：0 个文件
- 未变：1007 个文件
- 删除过期：1 个文件
- 纳入总大小：202179900 字节（约 192.81 MB）
- 因类型/规则跳过：93 个文件
- 00-START-HERE.md 来源：reused existing 00-START-HERE.md
- git commit：是
- git push：未配置 origin，跳过 push（等 GitHub 私有仓库建好后再加）

## 因文件名疑似密钥/登录态而排除（只列路径，不列内容）

- （无）

## 因内容扫描疑似明文密钥而排除（只列路径，不列内容）

- （无）

## 因超过大小上限而排除

- `/workspace/project-intake/fangyu/review/region-leak-src/douyin-replies.jsonl (70447640 bytes)`

## 固定排除规则（摘要）

- 目录：node_modules、__pycache__、.git、venv/geo-venv、private、浏览器配置、.ssh
- 文件名：.env、cookie、credentials、secret、私钥、.pem
- 路径含 `/private/`、`/agent-data/`
- 二进制/压缩包/数据库/apk/exe，以及大于 50MB 的文件（图片大于 10MB）
- DeepSeek / OpenAI 等密钥只存在环境变量，不会写入本仓库

本报告本身也不含密钥。
