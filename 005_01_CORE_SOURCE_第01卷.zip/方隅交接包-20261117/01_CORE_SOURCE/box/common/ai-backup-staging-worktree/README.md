# 云端 box 本地备份（零 Grok 额度）

这套脚本把云端 box 上的项目文档、脚本、配置模板和交接文件，定期备份到一份「换任何 AI 都能看懂」的仓库里。

## 定时（不消耗 Grok 额度）

- 每 6 小时（00:00 / 06:00 / 12:00 / 18:00，Asia/Shanghai）：增量同步并提交
- 每天 07:00：全量同步，并用 DeepSeek 更新 `00-START-HERE.md`（失败则脚本拼接原文）
- box 上由 `start-daemon.sh` 启动 supercronic（或 sleep 循环），不经过对话窗口

## 路径

- 脚本：`/workspace/tools/backup/`
- 暂存 git 仓库：`/home/box/.local/share/ai-backup/staging/`
- 日志：`/home/box/.local/share/ai-backup/logs/`
- 用户电脑目标：`C:\Users\rmsama\Documents\AI-Backup\`

## 推荐传输路径

优先：box 定时 `git push` 到用户 GitHub **私有**仓库（例如 `ai-workspace-backup`），电脑用计划任务 `git pull`。

当前若 GitHub 还不能从 box 推送（box 与电脑上的 `gh` 都未登录，且不能把电脑上的凭据拷到 box），备份会先落在 box 本地，并在电脑在线时把一份完整快照拷到 `Documents\AI-Backup`。等私有仓库建好、把 box 的部署公钥加进去后，把 origin 配上就会自动 push/pull。步骤见 `GITHUB-SETUP.md`。

## 手动跑一次

```bash
/workspace/tools/backup/backup.py --mode daily
/workspace/tools/backup/start-daemon.sh
```

## 不会进入备份的内容

密钥、`.env`、cookie、浏览器会话、账号登录态、`dy-deploy/private/`、数据库、大于 50MB 的文件、`node_modules`、venv、apk/exe 等二进制。疑似明文密钥的文件会被排除，只在 `BACKUP-REPORT.md` 里列出路径。
