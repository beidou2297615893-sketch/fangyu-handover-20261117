# 抖音诊断补丁独立验收笔记（新版）

时间：2026-11-08 约 15:52–16:00 Asia/Shanghai
范围：仅 box 只读验收。未碰用户电脑、未部署、未联网平台、未跑业务/真实诊断、未读凭据。
本机当时离线；Windows 临时演练由平台专责独占，本笔记作者未探活。

## 锁到的版本

- 补丁：`/workspace/dy-deploy/diagnose-deploy.patch`
- 补丁 SHA256：`c7286aaec10ba4a8e3a9ad56db4703ca44e0a2a5c2b9b7c94f1843301d1ff0cc`（与任务给定值一致）
- 声明：分支 `cursor/unknown-diagnose-8e1d`，commit `23ba734`，基于 e42c7de。未拉仓库核证 commit 本身。
- 配套：`/workspace/dy-deploy/diagnose-sha.txt`、`/workspace/dy-deploy/diagnose-test-output.txt`
- 只改 `douyin-local-control/control.py` 与 `unknown_resolution.py`
- e42c7de 对照树（未改）：`/tmp/dy-review-20261108/`
  - control.py `a3b4abbfa26f0ed679e989b245a7a1acde01d82e10023dc86196770dac32b43c`
  - unknown_resolution.py `feb60099134fefcc414aa092ad2713ba54ae58081e7073dab8662f7ecd328e70`
- 新副本打补丁：`/tmp/dy-diagnose-review-23ba734/`（仅此两文件变化）
  - control.py `009429c5008ec694e02df1a3fb047d6c311f6988185249e3645358b7c29a2554`
  - unknown_resolution.py `d16434a40c708574f0a64693ec89522b4ef4ccb9c19582d1a557475da3539d62`
  - 与 diagnose-sha.txt 的 23ba734 stored_bytes / redacted_normalized 两列一致
- 账号常量：对照树中 `olduid='<REDACTED_ACCOUNT>'` 与 e42c7de 原文同一行，补丁未改该行，也未新增脱敏覆盖。生产文件应把补丁打在本机原文件上，不能用这份脱敏树整文件覆盖。

## 云端测试输出（不是本验收自跑）

`diagnose-test-output.txt` 记录 pytest collected 25、25 passed、28 subtests passed，另有既有 Node 阅读测试 PASS。
新产物未附带 `test_unknown_resolution.py` 等测试源码。上述 25+28 不能当作本验收自行通过的证据。

## 前轮 6 项定点结果

1. 自由文本：输出诊断记录已无 `stderr_excerpt`/`redact_excerpt`。`sanitize_diagnostic` 只保留 `stage`/`error_type`/`http_status`/`cli_error_code`/`pagination_complete`。合成攻击样本（cookie/token/URL/账号/正文/cid）未出现在输出中。`_read` 异常不再写入 `str(exc)`，只把异常类名当分类 hint。分类过程仍会在内存中读 stderr 以提取 HTTP 状态或匹配关键词，但不落盘、不打印原文。
   残余：打印的 `items[].own_reply_state` 未再做枚举白名单（预期为 found/not_found/unchecked）；`kind` 由 `classify()` 闭合产生。

2. 参数：`diagnose_argv_action` 仅当 `args == ['--diagnose-unknown']` 为 diagnose；任何多余、重复、或折叠后含 `diagnos` 的近似拼写为 reject，打印 `blocked_reason=bad_args` 并在取得发送许可之前返回，不会回落发送路径。合成矩阵已覆盖。

3. 任务锁：`task_lock_state`/`_lock_existing` 用 `os.open(path, os.O_RDWR)`（无 O_CREAT），只打开已存在文件；`FileNotFoundError` 视为 free。`inspect_task_locks` 跳过不存在路径；结果 unknown 则视为不可用（diagnose 报 `lock_uncertain` 并停止查询）。诊断路径传入 `lock_state='free'`，不会走仍用 `a+b` 的旧 `foreign_runner_locked()`。
   启动路径仍调用 `foreign_runner_locked()`（`a+b`，可能新建其他任务的 `batch-runner.lock`）。诊断不走这条。

4. `control.lock` 失败：diagnose 时 `control_lock_result(True)` 打印 `blocked_reason=control_lock`，且 `write_status=False`，不写 `status.json`。captcha / reserved / no_submitted / no_items 分别有明确 `blocked_reason`，合成已确认且不触发 read。无任务目录时入口也打印 `no_items`（与“没有待核 pending”共用同一枚举）。

5. 只读诊断不调用 `commit_resolution`、`upgrade_task`、`prepare()`、`ensure_adapter_file`（`ensure_adapter=False`）、不写授权/账本/队列/`status.json`/`.submitted`。`diagnose_unknown` 的 wrote/auth/records/start_sender/continue_queue 均为不写、不续发。
   启动核对路径若失败仍可能把**枚举型**诊断事件写入 `captcha-recovery-authorization.json`（无摘录、不扩保留名单）。这不是诊断入口的行为。

6. 子进程（静态，未执行）：诊断在锁空闲后调用既有 `probe()`（读登录身份，不写文件），若有 pending 再 `subprocess.run([node, adapter, '--verify-own-reply', video, cid])`。该命令走已部署 adapter 的 verify 分支：身份核对 + `readOwnReply` 后 return，在 `await post` 之前，不写 `.submitted`、不写 binding。不再走 `runner.run_json`（因而也不会在 JSON 失败时写 `subprocess-failure.json`）。继承 `os.environ`。验收未实际启动 node/浏览器/runner。

## control.lock 与“只读”精确边界

- 诊断与启动共用 `with (P/'control.lock').open('a+b')`：若文件不存在会创建空锁文件，属于控制目录的文件系统写入，并尝试独占锁。
- 这不是业务数据写入（不是账本、队列、回执、`.submitted`、授权正文、发送状态）。
- 因此“只读”是指：不发送、不改业务记录；不是“零文件系统变更”。已存在的 `control.lock` 被加锁时可能更新文件元数据。

## 本验收自跑的合成测试

仅 import `/tmp/dy-diagnose-review-23ba734/douyin-local-control/unknown_resolution.py`，禁网、无真实数据、无业务子进程。参数矩阵、日志攻击样本、诊断阻断枚举、锁检查、control_lock 写开关、启动路径事件无摘录：全部通过，0 fail。

## 结论

- 针对前轮 6 项风险：新版独立验收**通过**（附上述边界）。
- 不是全链通过：未执行真实诊断，未自跑云端 25+28，未附测试源码，未验证本机生产字节（生产仍声明为 e42c7de，本机离线未核）。
- 可以向用户明确描述如下批准请求（由平台专责在连接恢复后独占执行，不保证可发）：
  1. 备份 `R/work/douyin-local-control/{control.py,unknown_resolution.py}`
  2. 将 SHA `c7286aae…f0cc` 的 `diagnose-deploy.patch` 打到本机原文件（不要用脱敏对照树整文件覆盖）
  3. 运行一次：`python control.py --diagnose-unknown`
     - 会占用/可能创建 `control.lock`
     - 只打开已存在的 `batch-runner.lock`
     - 进行一次登录身份探测；若存在已提交且未保留的 unknown，再对每条做 `--verify-own-reply` 只读查询
     - 不生成发送清单、不启动发送、不点「启动／继续」
