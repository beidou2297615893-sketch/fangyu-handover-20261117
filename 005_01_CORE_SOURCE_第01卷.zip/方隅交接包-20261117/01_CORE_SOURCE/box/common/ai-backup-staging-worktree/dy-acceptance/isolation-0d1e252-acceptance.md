# 隔离补丁 0d1e252 独立验收笔记

时间：2026-11-08 约 17:09–17:20 Asia/Shanghai（北京时间）；Origin 补测读取约 17:14–17:18；导出原测试复验约 17:17–17:20 Asia/Shanghai
范围：仅 box 只读验收既有交付物。未新开云端、未改业务代码、未碰用户电脑、未部署、未联网平台、未跑真实诊断或发送、未读凭据、未生成 Page。
对照原件未改：`/tmp/dy-diagnose-review-23ba734/`（上轮已验 23ba734）。
隔离副本：`/tmp/dy-isolate-review-0d1e252/`（由对照树拷贝后机械打补丁）。
验收语义（本轮任务给定，用户 16:56 亲核「单条出问题跳过」）：单条核对失败/不明须保留 unknown 并隔离，绝不重发、不清旧回执，后续原已审队列可续；读取失败不能称确认未发；账号/平台全局限制、验证码、身份异常、预留仍停。16:25 旧 reason 已丢，不能补称现场根因。16:00 一次诊断授权不可复用。

## 结论

**唯一最终状态：交付版本机械验收通过。这不是全业务通过，也不表示“用户自动当场跳过”已经实现。**

机械通过依据：补丁 SHA / 七文件适配哈希、16:56 隔离语义的代码路径与 runner `guard` 同步、以及隔离副本上的原样合成测试全部通过（见第 3、3.2 节）。测试证明的是启动／继续之后的只读核对与隔离逻辑；现场仍要点启动／继续才会 isolate，运行中新产生的 unknown 仍会停本轮。

未做：本机更新、启动／继续、`--diagnose-unknown`、`--check-resume`、任何发送、凭据读取。

## 1. 交付物定位与 SHA

任务给定路径 `/cursor/stores/user/grok-bot/agents/2172f823-cfff-4818-9573-d9c941543a05/assets/01M6X6N3W90JNB3QXPFVG9Q894.patch`：**不存在**（该 agents/assets 目录当时不可读或未挂载）。未扩大搜寻其它无关目录。

按补充指示只读原云端私有副本：

- 补丁：`/cursor/stores/bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d/artifacts/isolate-deploy.patch`
- 体积：27413 字节（与声称一致）
- SHA256（本验收实测 = 清单末行 = 专责提供的完整值）：`3535b81c2dc8322f6aede8b4233c297de314e4783f42ab9c14d7dc2ba653efef`
- SHA 清单：同目录 `isolate-sha.txt`（baseline 23ba734 → final 0d1e252）
- 测试原输出：同目录 `isolate-test-output.txt`（17:06；声称 commit/branch 信息见任务，本对照未另拉 git 核证 0d1e252 对象本身）
- 测试源码：补丁七个 diff 中**没有**测试文件；「测试源码就在补丁里」与实际不符。

补丁未改账号常量行（无 `ACCOUNT` / `olduid` / `<REDACTED_ACCOUNT>` hunk）。生产必须把补丁打在本机原文件上，不能用这份脱敏对照树整文件覆盖。

## 2. 文件清单与前后哈希

补丁只改 7 个文件：

| 路径 | 23ba734（清单=对照树实测） | 0d1e252（清单=隔离副本应用后实测） |
|---|---|---|
| `douyin-local-control/control.py` | `009429c5008ec694e02df1a3fb047d6c311f6988185249e3645358b7c29a2554` | `c6b8681b1f8d407441b4b72835e1e82004398cb9661b931a12aa064617859423` |
| `douyin-local-control/panel.py` | `1e9711000d724b6e37637556255a2a882405e19254c22408a9cebb36e5fc7ebf` | `9069729b61de78a1639852b8b3084667de2b72c365f47c94520302c31e845dad` |
| `douyin-local-control/send_hold.py` | `ae64446fd6a125cb6e3fa5fc355c2543e6b0cd127b52bd6fdeee7cd1349f69e3` | `9e0d78c26e3c37814a4c9d720e34e25ab639649b9321c29c38404b5f7f62bed4` |
| `douyin-local-control/target_reader.cjs` | `1d3d2cc8be5be275b9fcdf7e2eb81cf2c610f9c2d0925136e15d81f91d9c2ee0` | `49ed5cdd33b4c852ca89a6a72582bf1a78b930120d68ab511370d9ab5d2f8e9d` |
| `douyin-local-control/unknown_resolution.py` | `d16434a40c708574f0a64693ec89522b4ef4ccb9c19582d1a557475da3539d62` | `0b6bbb1c68b39b49b090852d9d8fbfacc11d56f240fa775145c7fa55b3660a30` |
| `task/batch_reply_runner.py` | `3b22dda8592d8c77703ed1ae759ec2165b16a41ee1985164c7a16d419d7f82a1` | `5888835a6cc034b9d56d69fd731fe61155a78997d51bcc89b318294c56747c17` |
| `task/resume_after_confirmation.py` | `82b2384420c1ac0bf9c2ac8cf6c5b80bb13b9c16457936851eac61d6f3835d2c` | `6f5b23de08bfa9c3237ff422ec4c6562a00ec9c4d7017fe0ab0902e5ed590c0f` |

在 `/tmp/dy-isolate-review-0d1e252` 上：`git -c core.autocrlf=false apply --check --unidiff-zero -p1` 通过，随后同命令应用成功。应用后七项哈希全部 MATCH。对照原件七项哈希仍为 23ba734，未被改动。

## 3. 既有测试产物能否对应本版本

`isolate-test-output.txt` 记录：

- `test_unknown_resolution.py`：23 passed（含 `test_each_read_reason_isolates_without_confirming_absence`、`test_restart_does_not_resend_isolated_item_and_later_items_continue`、`test_new_unknown_still_blocks_and_runner_guard_remains` 等新名）
- `test_publish_recovery.py`：1 passed
- `test_read_recovery.py`：4 passed
- `test_target_reader.cjs`：PASS
- `test_own_reply_reader.cjs`：多条 found/unchecked 例 PASS

对应关系：

- 23 项 + own-reply：Origin 读取当时未果（3.1）；后随原导出独立复验通过（3.2），与这份输出一致。
- 树内现成合成测试（无网络、无真实数据、不启动 control/发送）已在隔离副本复跑：`test_publish_recovery.py` OK（1）、`test_read_recovery.py` OK（4）、`test_target_reader.cjs` PASS。这三项源码未被本补丁修改；target_reader 实现被改过，现有断言仍通过。
- 未跑 `test_startup_recovery.py`（不在本交付测试输出的新隔离套件内，且历史上依赖缺失夹具目录）。未发明补测试。未把 `full.patch` 里的旧测试或其它提交文件充当 0d1e252。

### 3.1 补齐两份测试的只读远程读取（约 17:14–17:18 Asia/Shanghai）

准确路径来自既有交付笔记与 `isolate-test-output.txt` / `sha.txt`，不是全仓搜索：

- `douyin-local-control/test_unknown_resolution.py`
- `douyin-local-control/test_own_reply_reader.cjs`

按 source-control 技能使用 Origin 内置只读单文件面（`cursor-origin` `get_repository` / `get_file_contents` / `commit_read` / `list_branches`）。仓库 `beidou2297615893/fangyu-lead-automation` 存在（private，defaultBranch=`main`，无 mirror 字段）。未 clone、未改业务代码、未碰本机、未新开云端、未用 PR https://cursor.com/codebase/beidou2297615893/fangyu-lead-automation/pull/2 的 branch。

工具返回：

1. `get_file_contents` `ref=0d1e252` 读取上述两路径：`invalid_argument: invalid revision: 0d1e252: The reference '0d1e252' did not exist`。
2. `commit_read` 与 `get_file_contents` `ref=cursor/unknown-diagnose-8e1d`：`The reference 'cursor/unknown-diagnose-8e1d' did not exist`。
3. 将斜杠写作 `cursor%2Funknown-diagnose-8e1d` 再读：同样 did not exist。
4. `commit_read sha=HEAD`：完整 SHA `a38ef888aab39ea51f027a1c2f5a4aecb1824f17`，说明为 Initial commit，tree `4b825dc642cb6eb9a060e54bf8d69288fbee4904`（空树），**不是** `0d1e252`。未从这个 HEAD 读取任何测试，以免换来源充当同版。
5. 必要的窄查找：`list_branches prefix=cursor/unknown-diagnose`（pageSize 50）返回 `branches: []`，无 `nextPageToken`。未再扫全仓或其它前缀。

因此当时两份原测试没有落入隔离副本，也没有复跑。该缺口随后由原导出补齐，见 3.2；3.1 的 Origin 结论保持为当时实况，没有改用其它 git ref 顶替。

### 3.2 原导出测试复验（约 17:17–17:20 Asia/Shanghai）

导出目录：`/cursor/stores/bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d/artifacts/isolate-tests/`（实测 10 个程序文件 + `SHA256SUMS.txt`，即两份测试加 8 个辅助文件；不是另算 10 个辅助）。未改测试或业务代码，未覆盖隔离副本里任何已打补丁文件。

导出清单与哈希：每个文件的 SHA256 均等于 `SHA256SUMS.txt`。两份测试与任务给定值一致：

- `test_unknown_resolution.py` `cb7ba7fc142ffad82e59d3f486c3f547675212953f59a99b17d403ebd5b353fe`
- `test_own_reply_reader.cjs` `17073a1407c3344b72929d4275dd783f2d129537e3999d0a730ef3a390785d99`

导出辅助 vs 隔离副本（应用 isolate-deploy.patch 之后）哈希全部一致，因此不存在“用导出辅助盖住原补丁缺件”的问题，选择在原副本 `/tmp/dy-isolate-review-0d1e252/` 上运行：

| 导出辅助 | 与隔离副本一致 | 说明 |
|---|---|---|
| `control.py` / `panel.py` / `send_hold.py` / `target_reader.cjs` / `unknown_resolution.py` / `batch_reply_runner.py` | 是（亦等于 isolate-sha 0d1e252 列） | 补丁内文件 |
| `startup_recovery.py` `a3dcf25aaaddaa303934cde83e79e03e644671f05b738234be9a36dcdcf2ead2` | 是 | 不在 isolate-deploy.patch 内，隔离树里本就是 23ba734/e42c7de 原件 |
| `send_cli_once.cjs` `4fb96da30203552c727a320893a71049a398e8265a42d41d7a9f2fdce80ffbae` | 是（`task/send_cli_once.cjs`） | 同上，不在本补丁内 |
| `resume_after_confirmation.py` | 导出未附 | 隔离副本保持补丁后哈希 `6f5b23de…590c0f`，未用其它版本替换 |

只把两份原测试拷入 `douyin-local-control/`（拷贝后哈希仍等于给定值）；七个补丁文件与上述两份未改辅助的哈希未变。

静态安全：两测试为合成用例。Python 侧用 mock `read_reply`，不调用真实 CLI/浏览器/账本，`execute` 断言未被调用；只把 `control.py` / runner 当文本检查顺序；`tempfile` 仅写虚构回执与 hold JSON。Node 侧用内存 `__bridge` mock，`publish()` 会抛错，表达式禁止包含 `post(`；`send_cli_once.cjs` 只做文本读取以检查 verify 分支。未见读取真实凭据或联网平台。确认后再跑。

复跑结果（cwd=`/tmp/dy-isolate-review-0d1e252`）：

| 套件 | 数 | 通过 | 失败 |
|---|---|---|---|
| `test_unknown_resolution.py` | 23 | 23（0.006s，OK） | 0 |
| `test_own_reply_reader.cjs` | 16 个 named check + 1 条 adapter verify 只读检查 | 全部 PASS | 0 |
| 先前已在同一隔离副本跑过、本轮未重跑 | `test_publish_recovery.py` 1、`test_read_recovery.py` 4、`test_target_reader.cjs` 1 | 当时均通过 | 0 |

与 `isolate-test-output.txt`：23 个测试名一致且均为 ok；own-reply 的 16 条状态行（found/not_found/unchecked）及最后 “adapter verify branch is read-only PASS” 与交付输出一致。

这些通过只支持交付版本的合成/机械验收。它们把 isolate 绑定在「启动／继续」后的 `resolve_on_start`（事件里的 `user_statement` 仍是「用户点击启动／继续」），**不能**当成完整的“用户不用再操作、运行中自动当场跳过”已经实现。

## 4. 16:56 语义对照（代码路径）

核心改动在 `unknown_resolution.py`：`_isolate()` 把未完成核对的 cid 写入 `captcha-recovery-authorization.json` 的 `isolated_unknown_comments`，`own_reply_state` 固定为 `unchecked`，`mark` 为 `isolated, not resent`，注释写明不要把这称作「确认从未发出」。不调用记 `not_sent` 的路径；`found` 仍只在看见本账号回复时记 sent；完整 `not_found` 仍走原来的 `preserve_unknown_comments`。

`resolve_on_start()`：核对不完整不再 `_stop` 整队，改为 `_isolate` 后 `continue_queue=True`。无提交标记的 unknown 同样 isolate，不再以 `no_submitted` 停整队。摘要改为「没核对完的保持原样，不重发，也不挡住其余已审队列」。

重启防重：

- `select_stuck(..., isolated)` 跳过已 isolate / preserve 的 cid，不会再拿去核对或重发。
- `receipt_blocks_queue` / `preserve_previous_unknown`：仅未 isolate 且未 preserve 的 unknown、以及任何 reserved 仍阻断。
- `unresolved_blockers` 将 preserved∪isolated 视为已决、不挡后续。
- runner `guard()` 同步读取 `isolated_unknown_comments`。
- `execute()` 在入账检查前若 cid 已在 preserve∪isolated 则 `continue`（注释：Kept unknown or confirmed absent: never republish this cid）。
- 账本里已有该 comment/customer 的行仍会 `continue`（含显式 `not_sent`）。
- 补丁不删除 `.submitted`、`*-cli-receipt.json` 或账本旧回执。

读取失败不称确认未发：isolate 与 preserve 分离；`absence_confirmed()` 未放宽。`target_reader.cjs` 增加字符串状态 `0`、单对象当列表、耗尽页空评论当 `[]` 等解析，目的是让更多读取能走完；耗尽且无评论列表仍不会让 `absence_confirmed`（需要 `target_present is True`）把失败读成「确认未发」。本对照把这视为解析收紧/兼容，不是把失败叫未发。不能用这些改动回填或解释 16:25 丢弃的 reason。

面板/检查文案（`panel.py`、`control.py` `check_resume`）已改成与「核对失败那一条保持未知、不重发、不挡其余；验证码或账号不符停线」一致。

## 5. 全局停点是否仍在，会不会绕停线

仍停整队：

- 验证码：`select_stuck` 在已提交且 `status_code == 3002123` 时列入 captcha，`resolve_on_start` 立即 `_stop`，不 isolate。
- 预留：`reserved` 仍 `_stop`；`receipt_blocks_queue` / `guard` 仍把 reserved 当阻断。
- 身份：pending 循环里 `kind == 'stop_identity'` 仍 `_stop`，不 isolate 该条。
- 账号不一致 / runner 忙 / 停止标记 / 缺 prefix：`_gate` 仍停。
- 发送批准：`control.main` 在核对前调用 `require_send_allowed()`；runner `execute()` 入口和循环内再次调用。`send_hold.py` 只增加可选路径参数供测试注入，默认仍读原来的本地 hold 与共享入口；hold 为真则抛错。隔离成功（`continue_queue=True`）不会取消 hold。

`may_launch_sender(resolution, send_allowed)` 已写入 `unknown_resolution.py`（要求 `send_allowed is True` 且非 diagnose），但 **`control.py` 未调用它**。生产路径仍靠启动入口和 runner 里的 `require_send_allowed()`，不构成新的绕 hold 通道；只是该辅助函数目前是死代码。本补丁之前，hold 检查时机同样在启动开头与 runner，没有因为隔离而前移或取消。

未发现「单条 isolate 直接跳过验证码/身份/预留/hold」的新通道。边缘（与 23ba734 相同的分类顺序，不是新开的验证码旁路）：没有 `.submitted` 标记的 unknown 会先进入 unsubmitted 并被 isolate，即使回执文件里写着 3002123 也不会走到 captcha 分支。有提交标记的 3002123 仍停线。

同一轮 runner 里新产生的 unknown（提交后不是 sent）仍会按原逻辑停止该次运行（`preserve_unavailable` 的视频不可用例外仍在）。要 isolate 并续发其余，需再次点启动／继续走 `resolve_on_start`。隔离授权绑定在启动／继续的只读核对，不是发送中自动清障。

诊断路径未改为写入 isolate：`diagnose_unknown` 仍 `continue_queue=False`、不 commit。本验收未跑诊断。

## 5.1 残留行为差距（测试通过也不能抹掉）

- **旧的、已经提交的 unknown**：在下一次启动／继续时，只读核对失败或不明会写入 `isolated_unknown_comments`，该条保持 unknown、不重发、不清旧回执；其余原已审队列可以继续（`continue_queue=True`，`guard` 不再把已 isolate 的 unknown 当全队门禁）。这是本次补丁要验收的路径，合成测试已覆盖 isolate / 重启不重读不重发 / 后续 cid 可进入已审过滤。
- **运行中新产生的 unknown**：`execute()` 在提交后若结果不是 `sent`，除原有 `preserve_unavailable`（视频详情不可用）外，仍会 `RuntimeError('已保存CLI返回结果并停止；不会自动重发')`，**停本轮**。要 isolate 这一条并续发后面的已审条目，需要再次点启动／继续，走 `resolve_on_start`。合成测试没有、也不能证明“发送过程中当场自动跳过”。
- 验证码 `3002123`、预留、身份不一致、账号 hold 仍停整队；`may_launch_sender` 仍未被 `control.py` 调用，hold 靠启动入口与 runner 的 `require_send_allowed()`。

## 6. runner 旧 guard：必须同步的最小本机文件范围

主窗判断成立：若只更新 `douyin-local-control/`，活动任务目录里的旧 `guard()` 只认 `preserve_unknown_comments`，已 isolate 但仍为 unknown 的账本行会继续「禁止继续」，整队仍被挡。`startup_recovery.upgrade_task()`（本补丁未改）只会做历史字符串替换，**不会**写入 `isolated_unknown_comments` 逻辑，因此点启动不能指望它自动修好旧 guard。

补丁中的 `task/` 是通用任务副本语义，**不是**整目录覆盖模板。本机应对应到这些**文件**，不要覆盖整个 `work/douyin-local-control` 或整个任务目录（会毁掉 `accounts.json`、队列、回执、`.submitted`、授权 JSON、账本绑定等）。

**通用源**（`{项目根}/work/douyin-local-control/`，与补丁路径同名）：

1. `control.py`
2. `panel.py`
3. `send_hold.py`
4. `target_reader.cjs`
5. `unknown_resolution.py`

**当前生产任务副本**（`prepare()` / `accounts.json` 登记的活动目录，不是对照树里的脱敏 `task/`；不要整目录覆盖）：

6. `batch_reply_runner.py`（旧 guard 必须换成补丁版，否则 isolate 后仍挡全队）
7. `resume_after_confirmation.py`（`pending_confirmation` 的 approved 集合需并入 `isolated_unknown_comments`）

**模板源**（`control.py` 中 `T=ROOT/'work/douyin-round2-task5'`，仅当还要用 `prepare()` 生成新任务时）：

8. `work/douyin-round2-task5/batch_reply_runner.py`
9. `work/douyin-round2-task5/resume_after_confirmation.py`

不在本补丁、不要当成本次最小范围去覆盖：`send_cli_once.cjs`、`accounts.json`、`active.json`、`captcha-recovery-authorization.json`、批准队列、回执与 `.submitted`、共享账本。任务内的 `send_cli_once.cjs` 通过相对路径使用 control 目录的 `target_reader.cjs`；更新通用源中的 reader 即可，不要用对照树覆盖任务适配器。

应用后可用 `isolate-sha.txt` 的 0d1e252 列核对应文件哈希（任务副本两文件应等于清单里 `task/batch_reply_runner.py` / `task/resume_after_confirmation.py` 的 0d1e252 哈希，前提是打在未改过的 23ba734/等价原文上）。

## 7. 16:25 旧 reason

本对照不把 16:25 `blocked_reason=read_incomplete` 等枚举摘要补称为现场根因。补丁为后续诊断增加了白名单 `reason` 以及有界整数 `detail_status` / `comments_status`（经 `sanitize_diagnostic`），不能回填已经丢掉的当场原文或 stdout。

## 8. 最小更新 + 不发送核查范围（新批准，不可复用 16:00）

若用户另行批准更新（本验收不构成该批准）：

1. 备份上述最小文件（通用 5 个 + 活动任务 2 个；如需新任务再加模板 2 个）。
2. 将 SHA `3535b81c…efef` 的 `isolate-deploy.patch` 打在本机原文件上，或按清单逐文件替换这几份；禁止整目录覆盖、禁止用脱敏树覆盖含真实账号的文件。
3. **不发送核查**（与 16:00 那次 `--diagnose-unknown` 不是同一授权，不得复用）：离线核上述文件的 SHA256 是否等于 `isolate-sha.txt` 0d1e252 列。不要为此再跑 `--diagnose-unknown`，也不要点「启动／继续」（启动路径在 isolate 之后若 `continue_queue` 会真正启动 runner 发送其余已审队列）。
4. `--check-resume` 虽不启动发送，但会 `probe()` 登录页，属于平台联网，需要**新的**用户批准，也不在本验收执行范围内。

任何实际发送、再次诊断、或把 isolate 用于绕验证码/停线，均不在本文件授权之内。

本次机械验收通过，不代替用户批准上述更新，也不等于现场已经自动跳过。
