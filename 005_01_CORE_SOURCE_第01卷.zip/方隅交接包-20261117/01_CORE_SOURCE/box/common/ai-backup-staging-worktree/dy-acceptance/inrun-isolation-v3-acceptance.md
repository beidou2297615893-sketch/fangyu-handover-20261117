# 运行中隔离最终版 acd6c08（v3）独立验收笔记

时间：2026-11-08 约 17:53–17:55 Asia/Shanghai（北京时间）
范围：仅 box 对 `inrun-isolate-v3/` 做既定最终窄验。未改源码或测试、未碰本机/平台/凭据、未安装、未启动、未联网、未真实发送。未投工程、未联系其他执行人。
基准树：已验 0d1e252 `/tmp/dy-isolate-review-0d1e252/`（本轮未覆盖）。
本轮隔离副本：`/tmp/dy-inrun-review-v3-acd6c08/`（从 0d1e252 全新拷贝后机械打 v3 增量）。
只取目录：`/cursor/stores/bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d/artifacts/inrun-isolate-v3/`（未用主窗混杂的 v1/v2 或其他目录）。

## 唯一最终状态

**交付版本机械验收通过（最终 v3 / commit `acd6c08bea03199e8f50593bf5df570dd579932e`）。这不是现场可发，也不得自动安装。**

机械通过依据：补丁大小与 SHA、在 0d1e252 新副本上 `git apply` 成功、三份生产文件及测试文件哈希与清单/制品副本一致、现成测试自跑 6+6+4+23 全部通过。重点覆盖项见 §4：名称含 Execute 的套件调用的是 `simulate_execute`，**零次**调用 `batch_reply_runner.execute()`，也没有真实 CLI。

## 1. 交付物、基准、SHA

- `COMMIT.txt`：`acd6c08bea03199e8f50593bf5df570dd579932e`（与 run17 给定短 SHA acd6c08 一致）
- `inrun-isolate-deploy.patch`：32965 字节，SHA256 `919983efb2d896c7e0d8a3774874e847cc77de55408c74fa6355bbe9440cf1ae`（实测 = 清单 = 任务给定值）
- 清单与 `DEPLOY-FILES.txt` 均声明相对已装 **0d1e252**，不是相对 v2
- 制品单文件哈希均等于 `SHA256SUMS.txt`

补丁 `git apply --stat`：6 个文件，+525 / −13。生产三文件 + 三份测试（含新的 `test_execute_offline.py`）。无缺件，未重写任何文件。

应用前对照树哈希与已验 0d1e252 一致：`batch_reply_runner.py` `5888835a…47c17`，`prepare_verified.py` `55d24375…0cb0`，`publish_recovery.py` `68732eb6…496db`；当时尚无 `test_execute_offline.py` / `test_inrun_isolate.py`。`git -c core.autocrlf=false apply --check --unidiff-zero -p1` 通过并应用成功。应用后与清单及制品副本一致：

| 文件 | SHA256 |
|---|---|
| `task/batch_reply_runner.py` | `9b373e6e4314608cea8dc97671bb41c2f1d40c55651e70fbd7a136576f34a037` |
| `task/prepare_verified.py` | `de4b52b568e84b108aafc42e6363aa6183c7044f6f4e31b1214167de3ef0e224` |
| `douyin-local-control/publish_recovery.py` | `5575679f1a0c75824c53b773862846b0654ecc4c09f6972350d1eec24672b01a` |
| `test_execute_offline.py` | `69bf5b6de7e95a35327f8a9ff2883e5215119f1f5c10d4de2cf5d2e4ee34f37c` |
| `test_inrun_isolate.py` | `05fbff6c14b58e7e2054130493aa4c8623753bad44e519e4743b4f5085535454` |
| `test_publish_recovery.py` | `3ba4ea3b38e30991ee798226718d568e6a32550d3eece0270788df1741fd6b3e` |

已装七文件中其余未改，抽查 `control.py` / `unknown_resolution.py` / `resume_after_confirmation.py` 仍为 0d1e252 哈希。0d1e252 原树 runner 仍为 `5888835a…47c17`。

## 2. 相对 v2（2c06e94）的生产差异

`prepare_verified.py` 与 v2 **相同**（仍是 isolated ∪ preserve）。变化在另外两份：

- `publish_recovery.py`：新增 `_CLI_IDENTITY_ERRORS` 与 `identity_not_sent()`（只认 `status=='not_sent'` 且 error 含 `send_cli_once.cjs` 67/69/71 三句原文的小写子串）；`in_run_non_sent_action` 对命中者返回 **`stop_identity`**（v2 同类输入落入 `stop_other`）；另含测试用 `load_auth` / `simulate_execute`（生产 runner 不调用后两者）。
- `batch_reply_runner.py`：在 `stop_captcha` 之后增加 `stop_identity` 分支（320–322 行），抛「账号核对未通过，已停线。没有继续发送。」其余提交后分发与 v2 相同。

三份生产文件仍无次数阈值（无 `IN_RUN_ISOLATE_CAP` / `stop_cap` / `consecutive_unknown_isolates`）。

## 3. 最终生产落地范围

仍仅为这三份，不得自动安装，禁止整目录覆盖：

1. **C** `{项目根}/work/douyin-local-control/publish_recovery.py`（runner 从该目录 import `in_run_non_sent_action` 等）
2. **T** 当前活动任务 `{任务目录}/batch_reply_runner.py`
3. **T** 同一活动任务 `{任务目录}/prepare_verified.py`

`DEPLOY-FILES.txt` 与此一致：已装七文件中只改 runner；额外部署 `publish_recovery.py` 与 `prepare_verified.py`。`resume_after_confirmation.py` 本增量未改。模板 `work/douyin-round2-task5/` 的 runner / `prepare_verified.py` 只在将来 `prepare()` 生成**新**任务时才需要同步，**不是本次活动任务的必需落地**。

## 4. 覆盖项（不是测试名摘要）

静态：`test_execute_offline.py` / `test_inrun_isolate.py` / `test_publish_recovery.py` 只 import `json`/`pathlib`/`tempfile`/`unittest` 及本地 `publish_recovery`（后两份另有 `unknown_resolution`、`send_hold`）。无 subprocess / socket / http / NODE / ADAPTER / 真实凭据。确认后在 `/tmp/dy-inrun-review-v3-acd6c08` 复跑。

`test_execute_offline.py` 模块文档写明「Offline full-queue simulation… No CLI, no platform。」`simulate_execute`（`publish_recovery.py` 137 行）文档写明它是「Offline stand-in for the runner's per-item post-CLI branch. No real CLI。」该测试文件对 `recovery.simulate_execute` 调用 10 次，**没有** `runner.execute`。模拟器只复现：循环前三个开关（`lock_busy` / `hold_reason` / `identity_ok`）、`preserve ∪ isolated` 跳过、按预制 `cli_results[cid]` 取结果、`in_run_non_sent_action` 分发、`isolate_unknown_in_run` / `preserve_unavailable`、匹配的 stop 抛错。它不跑 `validate_queue`、`--identity` CLI、循环内 `require_send_allowed`、`guard`/账本、`prepare_verified.py` 子进程、`run_json(ADAPTER)`、`cli_success`、`record_outcome`、预留 `reserved`、attempt / `.submitted`。mock 里 `status=='sent'` 只是把该 cid 记入返回值的 `sent` 列表，不是真实发送。

| 核查项 | 结论 | 实际覆盖到什么 | 未覆盖 |
|---|---|---|---|
| unknown 之后后续条目标为 sent | **模拟器已覆盖，不是完整 execute** | `test_unknown_then_later_items_are_sent`：A=3056 unknown → isolate；B/C 的 mock 为 sent，返回 `sent=[B,C]`。`test_inrun_isolate.test_in_run_unknown_is_isolated_and_later_items_still_send` 是函数级 isolate + 源码顺序（isolate → 打印 → `continue`）及「LATER 不在 decided」 | 未调用 `execute()`；后续「sent」不是 CLI/账本成功回执 |
| 多条 unknown 逐条隔离并继续 | **模拟器 + 函数级已覆盖，不是完整 execute** | `test_several_unknowns_in_a_row_each_isolated_and_run_continues`：A/B/C 分别为 3056/2209/2147 → 均 isolate，D 记入 sent。`test_inrun_isolate` 对 5 条 3056 循环调用 `in_run_non_sent_action` + `isolate_unknown_in_run` | 同上，无真实 CLI |
| 重启不重发 | **模拟器 + 名单/阻断函数已覆盖，不是进程重启** | `test_restart_does_not_resend_isolated`：第一次 isolate A；第二次即便给 A 预制 `status=sent`，因已在 isolated 名单而进入 `skipped`，只把 B/C 记入 sent。`test_restart_does_not_resend_isolated_item` 查 `unresolved_blockers` / `receipt_blocks_queue` / decided 过滤 | 不是再拉起 `execute()` 或真实进程；不测账本行、attempt 文件、`.submitted` |
| 真实 adapter 提交前身份 `not_sent` → 整队停 | **分类器 + 模拟器 + runner 源码分支已覆盖；契约是 not_sent，不是虚构的身份 unknown** | 三句原文：`Batch account binding missing`、`Task account mismatch`、`Round2Task5 identity changed; no submission`（与 `task/send_cli_once.cjs` 67/69/71 一致）。字典 `{status:'not_sent', error:该原文, skip_target:False}` → `identity_not_sent` 为真 → `in_run_non_sent_action` 返回 **`stop_identity`**（v3 新动作；v2 同类输入是 `stop_other`，同样整队停）→ `simulate_execute` 抛「账号核对未通过」，且 isolated 名单仍空。`test_publish_recovery.test_cli_identity_not_sent_stops_globally` 与决策表三项相同。runner 320–322 有对应 `raise` | **未运行** `send_cli_once.cjs`，也未调用 `execute()`。没有把 `{status:'unknown', error:身份原文}` 当作真实契约 |
| 验证码 | **分类器 + 模拟器已覆盖** | 3002123 → `stop_captcha`；模拟器抛含 `3002123` 的停线文案；`test_captcha_is_not_an_in_run_skip` 仍在 | 无真实 CLI 验证码回执 |
| hold | **部分覆盖** | 模拟器 `hold_reason='账号暂停'` 在函数开头直接抛错（137–142 行开关，不是 `send_hold`）。`test_account_pause_and_captcha_mid_run_still_stop` 用临时 `hold.json` 调用真正的 `send_hold.require_send_allowed`，隔离后 hold 仍抛错 | 未在 `execute()` 循环里走到 `require_send_allowed()` |
| reserved | **本轮新套件未覆盖** | `test_execute_offline.py` / `test_inrun_isolate.py` / `test_publish_recovery.py` 均无 reserved 用例。生产代码仍会停：runner `guard` 把 `reserved` 当阻断、`prepare_verified.py` 对未批准 reserved assert、预留返回 `reserved is not True` 则抛错 | 不能把「生产里仍有这些检查」写成测试已覆盖 |
| resume 锁 / 防双发 | **只证锁名与源码顺序，以及模拟器开关；不证双进程争用，也不证防双发** | `test_resume_lock_prevents_concurrent_double_execution`：`lock_busy=True` 时模拟器立刻抛「本批程序已经运行，请勿重复启动」（文案对齐 `batch_reply_runner.main` 341–346，**不是** resume 的行为）。随后只读 runner/resume 文本，断言含 `batch-runner.lock`、`msvcrt.locking`，以及 runner 含 `stop_identity`。`test_no_double_send_race_with_resume` 断言 resume 源码中 `batch-runner.lock` 出现在 `runner.execute()` 之前（resume 24–27 加锁，48 行 `runner.execute()`）。resume 抢锁失败是打印「任务已在运行，无需重复启动」后 `return`，并不抛 runner 那句 | 无 `multiprocessing`/`Process`/`Popen`，没有两个进程去争同一把锁，没有调用 `resume_after_confirmation.main()` 或 `runner.execute()`/`main()`。因此不能证明第二进程会被真实锁挡住，也不能证明持锁后的发送路径不会双发 |

启动路径 `test_unknown_resolution.py` 23 项按现成脚本回归通过，未做全面重审。

## 5. 自跑实测数

| 套件 | 数 | 通过 | 耗时 | 失败 |
|---|---|---|---|---|
| `test_execute_offline.py` | 6 | 6 | 0.004s | 0 |
| `test_inrun_isolate.py` | 6 | 6 | 0.004s | 0 |
| `test_publish_recovery.py` | 4 | 4 | 0.001s | 0 |
| `test_unknown_resolution.py` | 23 | 23 | 0.006s | 0 |

与交付 `test-output.txt` 的测试名及结果一致（交付记录的墙钟略不同，属正常）。合计 39 通过、0 失败。

## 6. 剩余技术与现场条件

- 本验收不是现场可发，也不构成安装或发送批准。
- 必须另批才能改本机上述三份生产文件；不要覆盖回执、授权 JSON、队列、账本、`accounts.json`、`send_cli_once.cjs`。
- 完整 `execute()`、真实 CLI、双进程 resume、reserved 预留、循环内 hold 均未被这些离线测试跑到。
- 分类器仍不把虚构的身份 unknown 当契约；当前适配器提交前身份失败的约定输出是 `not_sent`。v3 将其标为 `stop_identity` 并整队停。
- 验证码、hold、预留、启动/`--identity` 失败在生产路径上仍会停整轮；现场恢复发送另需账号、连接与用户批准，本对照未验证。
- 不要用启动／继续来核对本机文件（会真实发送其余已审队列）。
