# 运行中隔离最终版 2c06e94 独立验收笔记

时间：2026-11-08 约 17:46–17:50 Asia/Shanghai（北京时间）
范围：仅 box 现成交付机械验收。未新开云端、未改业务或测试、未碰用户电脑/平台/凭据、未部署、未启动、未真实诊断或发送。
基准：已验 0d1e252 私有副本 `/tmp/dy-isolate-review-0d1e252/`（本轮未覆盖）。
最终版隔离副本：`/tmp/dy-inrun-review-v2-2c06e94/`（从 0d1e252 新拷后机械打 v2 增量）。
废弃阈值版 6fb4235 的隔离树 `/tmp/dy-inrun-review-6fb4235/` 仅作已做证据保留，本轮不再深验、不写入部署建议。

## 唯一最终状态

**交付版本机械验收通过（最终 v2 / commit `2c06e9469caf49838d8ec33902514cf233c1556e`）。这不是端到端可发送，也不得把超出已装 0d1e252 七文件的范围自动安装。**

机械通过依据：补丁 SHA 与体积、在 0d1e252 新副本上 `git apply` 成功且五份变更文件哈希与清单一致、三份生产文件中普通 unknown 逐条 `continue_isolated` 且无次数阈值、合成测试自跑 6+3+23 全部通过并与交付 `test-output.txt` 对应。

未做：本机更新、启动／继续、诊断、任何发送。

## 1. 交付物、SHA、基线

目录：`/cursor/stores/bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d/artifacts/inrun-isolate-v2/`

- `COMMIT.txt`：`2c06e9469caf49838d8ec33902514cf233c1556e`（与任务给定完整 SHA 一致）
- `inrun-isolate-deploy.patch`：21486 字节，SHA256 `b1fa246932eec598f1e5bc99bff5da3db7d735ea84aa9e86660c0ee2272d522b`（实测 = 清单 = 任务给定值）
- 清单声明相对已装 **0d1e252**，不是相对废弃的 6fb4235
- 制品单文件哈希均等于 `SHA256SUMS.txt` 的 `artifact_copies` / `per_file_sha256_at_HEAD` 列

补丁文件清单：

| 路径 | 角色 |
|---|---|
| `douyin-local-control/publish_recovery.py` | 生产，通用源 |
| `task/batch_reply_runner.py` | 生产，任务副本 |
| `task/prepare_verified.py` | 生产，任务副本 |
| `douyin-local-control/test_inrun_isolate.py` | 新测试，非生产安装 |
| `douyin-local-control/test_publish_recovery.py` | 测试更新，非生产安装 |

已装 0d1e252 七文件中，本增量只改 `task/batch_reply_runner.py`。`control.py` / `panel.py` / `send_hold.py` / `target_reader.cjs` / `unknown_resolution.py` / `resume_after_confirmation.py` 声明且实测仍为 0d1e252 哈希。

0d1e252 对照树中将被改写的基线与清单一致：`batch_reply_runner.py` `5888835a…47c17`，`prepare_verified.py` `55d24375…0cb0`，`publish_recovery.py` `68732eb6…496db`，`test_publish_recovery.py` `aed465be…a689a`；`test_inrun_isolate.py` 在 0d1e252 为 MISSING。

在 `/tmp/dy-inrun-review-v2-2c06e94`：`git -c core.autocrlf=false apply --check --unidiff-zero -p1` 通过并应用成功。应用后：

- `publish_recovery.py` `dabc51204208d6038d56a1d024e122311bb001a7cf5d9cedb1be31e3822ace1d`
- `batch_reply_runner.py` `afee510f5cc8e68fc81cb55dc56ca9876aead488aa293648a43f9f146c96b8e0`
- `prepare_verified.py` `de4b52b568e84b108aafc42e6363aa6183c7044f6f4e31b1214167de3ef0e224`
- `test_inrun_isolate.py` `74da57b3711977e392dafde34fd0c8a721439e877fc20d5fab29d502e74f788a`
- `test_publish_recovery.py` `8525de486d6be95072f6c701736d3953e4290c5a5d411544eaf804e07704c0d9`

0d1e252 原树 runner 仍为 `5888835a…47c17`。

## 2. 三份生产文件的真实调用依赖

以下来自应用后源码，不是交付说明的转述。

**1. 通用源 `work/douyin-local-control/publish_recovery.py`（C）**

- runner 开头：`sys.path.insert(0, str(ROOT / 'work/douyin-local-control'))`（`ROOT = HERE.parents[1]`）。
- `execute()` 在 `status != 'sent'` 时：`from publish_recovery import in_run_non_sent_action, isolate_unknown_in_run, preserve_unavailable`，再 `action = in_run_non_sent_action(status, result)`。
- 运行时加载的是通用目录里的模块，不是任务目录副本。不更新此文件，新 runner 会 `ImportError`，或继续用只有 `preserve_unavailable` 的旧模块。
- `in_run_non_sent_action(status, result)` **没有**次数参数。普通 `unknown` 一律返回 `continue_isolated`。文档写明 “There is no count threshold.” 以词边界检索，三份生产文件中均无 `IN_RUN_ISOLATE_CAP`、`stop_cap`、`consecutive_unknown_isolates`、`consecutive_isolates`。
- `captcha_unknown`：`status == 'unknown'` 且回执 `status_code == 3002123` → `stop_captcha`。
- `isolate_unknown_in_run` 把 cid 写入任务目录 `captcha-recovery-authorization.json` 的 `isolated_unknown_comments`，不写入 `preserve_unknown_comments`，事件 `source=in_run_unknown_isolated`，`mark=isolated, not resent`，不设 `absence_condition`（不称确认未发）。不改账本 unknown 回执。

**2. 活动任务 `batch_reply_runner.py`（T）**

- 提交后非 sent：`continue_unavailable` 仍走原 `preserve_unavailable` 并 `continue`；`continue_isolated` 调用 `isolate_unknown_in_run` 后打印「本条已隔离、不重发，继续其余已审队列」并 `continue`；`continue_skip_target` 记不可见目标并继续；`stop_captcha` 抛「错误码 3002123…已停线。不会自动重发」；其余 `stop_other` 抛「已保存CLI返回结果并停止；不会自动重发」。
- 循环内每次仍 `guard(rows)`、`require_send_allowed()`。`guard` 已把 `isolated_unknown_comments` 与 preserve 一并视为可跳过的 unknown（此逻辑来自已装 0d1e252，本增量未改 guard 本身）。
- 循环内 `args = [sys.executable, HERE / 'prepare_verified.py', item['cid'], item['uid'], item['video'], evidence]`，`HERE` 为任务目录。下一条预留会再跑这份任务内脚本。
- 启动时 `run_json([NODE, ADAPTER, '--identity'])`，未核验或账号不一致则停。
- 无次数累加、无「连续 N 条」停线。

**3. 活动任务 `prepare_verified.py`（T）**

- 被 runner 以**任务目录路径**子进程调用，不是 import 通用源。
- 本增量唯一生产改动：`approved = preserve_unknown_comments ∪ isolated_unknown_comments`。随后用账本 `unknown`/`reserved` 行做 `assert`：「unknown 且 cid 不在 approved」或任何 `reserved` 会 `Unresolved outcome blocks further sending`。
- 运行时为何需要这份更新：隔离后该 cid 仍是账本 `unknown`。若任务内 `prepare_verified.py` 只认 preserve 名单，下一条预留会被这条刚隔离的 unknown 挡住，运行中续发会在预留阶段失败。这是从 runner 的实际调用与 assert 条件推出的，不是报告里「必须」二字的转述。
- `prepare()` 从 `T=ROOT/'work/douyin-round2-task5'` 复制此文件给**新**任务；当前活动任务要用的是活动目录里那一份。模板只在还要生成新任务时才需要同步。

`resume_after_confirmation.py` 本增量未改（仍为 0d1e252 的 `6f5b23de…590c0f`）。它已把 isolated 并入 approved，并在 `batch-runner.lock` 之后调用 `runner.execute()`。防双发依赖「已装 0d1e252 的 resume + 本增量 runner/prepare」，不是本补丁新改 resume。

## 3. 行为核对

- **运行中普通 unknown**：当场 `isolate_unknown_in_run`，账本保持 unknown，不重发，`continue` 后续已审条目。5 条连续 3056 在合成测试中全部 `continue_isolated` 并写入隔离名单。
- **无次数阈值**：生产三文件无 cap；测试断言 runner / `publish_recovery.py` 不含 `IN_RUN_ISOLATE_CAP`、`consecutive_*`、`'stop_cap'`。废弃 6fb4235 曾有 `IN_RUN_ISOLATE_CAP = 3` 及成功清零连击，用户未认可；最终 v2 已去掉，本轮不再验收那一版。
- **不重发 / 重启**：隔离 cid 进入 `isolated_unknown_comments`；`unresolved_blockers` / `receipt_blocks_queue` / runner `decided` 跳过该 cid；再次 isolate 同一 cid 不重复写入名单。
- **resume 防双发**：测试检查 runner 与 resume 均有 `batch-runner.lock` 与 `isolated_unknown_comments`，resume 先加锁再 `execute()`，`prepare_verified.py` 含 isolated 集合。这是源码与临时授权文件上的机械检查，不是双进程竞态实测。
- **验证码**：回执 3002123 → `stop_captcha`，不写入隔离续发；测试覆盖决策表与 `test_captcha_is_not_an_in_run_skip`。
- **账号 hold**：`require_send_allowed()` 仍在入口和循环内；隔离后 hold 仍会抛错（测试用临时 hold.json）。
- **预留**：`guard` 仍把 `reserved` 当阻断；`prepare_verified.py` 对非 unknown 的 reserved 仍 assert 失败。
- **身份**（澄清，不是已证实的绕过）：运行中进入全局停的明确身份信号是字段 `verified` / `account_uid`，以及提交前适配器抛出的固定英文错误原文。`execute()` 在循环前调用一次 `--identity`（`task/batch_reply_runner.py` 166–168）：`verified is not True` 或 `account_uid != ACCOUNT` 即抛「当前账号未核验或账号不匹配，已停止」。`resume_after_confirmation.py` 39–41 用同一对字段，失败则「账号核对未通过，未恢复」。此外 `validate_queue` 91–92 检查清单 `account_uid`，预留后 271–272 检查尝试文件 `account_uid`。循环内不再次调用 `--identity`，但下一条真正调用适配器发送时，`task/send_cli_once.cjs` 67/69/71 仍会在 `post` 之前分别抛 `Batch account binding missing`、`Task account mismatch`、`Round2Task5 identity changed; no submission`。这些抛错发生时 `attempted` 仍为 false，catch（76–87）打印 `{status:'not_sent', error:上述原文, skip_target:false}`；runner 285–300 把它交给 `in_run_non_sent_action`，因不满足 96–101 的 `skip_target` 条件而返回 `stop_other`，再在 320–321 整队停止。`in_run_non_sent_action`（`publish_recovery.py` 80–101）没有身份分支，也不读取启动路径 `unknown_resolution.py` 19–26 的 `_IDENTITY_MARKERS`；先前「若身份问题以普通 unknown 出现会被隔离」只是该分类器对任意无验证码/不可用标记的 `status=='unknown'` 一律 `continue_isolated` 的理论限制，不是当前适配器会把上述明确身份抛错写成 unknown 的已发现可达路径。原 `test_inrun_isolate.py` / `test_publish_recovery.py` 无身份用例；决策表有 generic `('not_sent', {status:not_sent, error:boom}, stop_other)`，形状与提交前身份输出一致。启动路径 `test_unknown_resolution.py` 的身份停线用例不覆盖 `in_run_non_sent_action`。不能据此判定当前存在身份绕过。

不要把测试通过理解成现场已经自动跳过、或用户不用再点启动／继续。本增量改的是 **runner 已经在跑之后** 对提交结果的处理；启动路径仍是已装的 0d1e252。

## 4. 测试自跑

静态：`test_inrun_isolate.py` / `test_publish_recovery.py` 使用 mock、`tempfile` 和源码文本检查；`execute`/`publish` 不被真实调用；无平台网络、真实凭据或发送。`test_unknown_resolution.py` 仍为 0d1e252 已核的合成套件（本补丁未改该文件）。确认后在 `/tmp/dy-inrun-review-v2-2c06e94` 复跑：

| 套件 | 数 | 通过 | 失败 |
|---|---|---|---|
| `test_inrun_isolate.py` | 6 | 6（0.004s） | 0 |
| `test_publish_recovery.py` | 3 | 3（0.001s） | 0 |
| `test_unknown_resolution.py` | 23 | 23（0.007s） | 0 |

与交付 `test-output.txt` 的测试名及结果一致，包括 `test_several_ordinary_unknowns_in_a_row_are_each_isolated_and_run_continues`（不再是废弃版的 `test_three_consecutive_unknowns_escalate_to_global_stop`）。

## 5. 最小落地范围（相对已装 0d1e252）

只这三份生产文件，禁止整目录覆盖，不得自动安装：

1. **通用源** `{项目根}/work/douyin-local-control/publish_recovery.py`  
   提供 `in_run_non_sent_action` / `isolate_unknown_in_run`；runner 从该目录 import。
2. **当前活动任务** `{accounts.json 登记的任务目录}/batch_reply_runner.py`  
   提交后按动作隔离或停线并 `continue`；不同步则仍会在普通 unknown 上整轮抛错。
3. **同一活动任务** `{任务目录}/prepare_verified.py`  
   预留时把 isolated 视为已决 unknown，否则下一条预留会被刚隔离的账本 unknown 挡住。

若还要用 `prepare()` 生成新任务，再同步模板 `work/douyin-round2-task5/` 里的 `batch_reply_runner.py` 与 `prepare_verified.py`。不要覆盖 `send_cli_once.cjs`、回执、`.submitted`、授权 JSON、队列、账本、`accounts.json`。`resume_after_confirmation.py` 若已是 0d1e252，本增量无需再改。

无发送核查（需另批，不可复用旧诊断授权）：用清单 HEAD 列核上述三文件哈希。不要点启动／继续来「验证」（会真实发送其余已审队列）。

## 6. 剩余真实卡点

- 本验收不是端到端可发，也不构成安装或发送批准。
- 必须另批才能改本机这三份文件；范围已超出「只更新旧七文件中的 runner」。
- 合成测试未跑完整 `execute()` / 真实 CLI / 双进程 resume。
- 身份：提交前适配器的明确身份抛错走 `not_sent` → `stop_other` 全局停，不是已被证实会隔离的 unknown。先前「中途身份以普通 unknown 出现会被隔离」已更正为分类器理论限制，详见 §3；不能据此判定当前存在身份绕过。
- 验证码、hold、预留、启动时身份失败仍会停整轮，这是设计内的全局停，不是本增量能消掉的发送条件。
- 启动／继续之后若 `continue_queue`，仍会启动 runner 发送其余已审队列；现场恢复发送另需账号、连接与用户批准，本对照未验证。
