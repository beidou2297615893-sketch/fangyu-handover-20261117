# 隔离补丁 0d1e252 安装报告（未安装）

时间：2026-11-08 17:30–17:32 Asia/Shanghai（北京时间 / 中国标准时间，UTC+8）
结果：**已停止，未备份、未安装。** 阻塞原因：本机面板进程仍在运行。

## 授权核对

总指挥窗口 `2172f823-cfff-4818-9573-d9c941543a05`：

- 跨窗转录中**没有**独立的用户角色消息/答卡本体 `t233s754`（总指挥已预告「答卡本体可能不在跨窗转录」）。
- 总指挥对用户的回执：「收到，先备份并安装这版抖音修改，只核对安装结果，不启动、不联网、不发送。」
- 总指挥 position 758 转述 17:28 用户对 t233s754 安装卡的实际答复原文：『同意先备份并安装这版抖音修改，仅核对安装结果，不启动、不联网、不发送。』
- 该原文与负责人交办、本次任务范围一致。因此进行了连接与只读基线检查；在发现运行中进程后按规则停手，没有改任何业务文件。

范围仅限：备份、安装、核对落盘。不启动、不联网、不发送。本次连这些写入步骤都未开始。

## 连接实证

- ListMachines：机器 `RMSAMA`，machineId `f79a5338-7ab9-41e1-bad0-3f5c3b1dd392`，kind=desktop，`connected=true`。
- 只读检查在本机执行时间：`2026-11-08 17:31:59`，时区名「中国标准时间」，UTC offset `+0800`。
- COMPUTERNAME=`RMSAMA`，USERNAME=`rmsama`。
- 路径存在：`R`、`C`=`R\work\douyin-local-control`、`T`=`R\work\douyin-local-20261104-1e985ff064` 均为 True。
- 这不是断线。上次已知失败连接记录是 16:38:57；本次已连通，未循环重试。
- 补丁 `/cursor/stores/bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d/artifacts/isolate-deploy.patch` 实测 SHA256 `3535b81c2dc8322f6aede8b4233c297de314e4783f42ab9c14d7dc2ba653efef`，与清单一致。未拷到本机（尚未进入安装步）。

## 进程检查

查询方式：本机 `Get-CimInstance Win32_Process`，匹配 panel/control/runner/`send_cli_once`/`douyin-bridge\node.exe`/`douyin-local-control`/`douyin-local-20261104`。

| 结果 | 详情 |
|---|---|
| 相关进程 | **1 个** |
| PID | **52784** |
| 映像 | `pythonw.exe` |
| 命令行 | `"C:\Users\rmsama\miniconda3\pythonw.exe" "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\panel.py"` |
| runner / send_cli / node / control.py | 未发现 |

说明：此前记录面板曾于 16:26:23 启动、旧 PID 50724 已关闭、当时新 PID 未确认。现在确认面板仍在跑，PID 52784。

规则：已有相关进程则立即停止、不改任何文件。未结束该进程（本次授权不含关面板/停进程）。未启动任何程序。

## 备份

未创建。预定路径格式为 `R\work\_backup\douyin-isolate-<yyyyMMdd-HHmmss>\`，因进程阻塞未执行。

## 七文件基线（只读，安装前）

预期基线来自 `isolate-sha.txt` / 验收笔记的 23ba734 列。`control.py` 另对照 16:25 部署记录的生产原文哈希 `46975b2f…`。

脱敏核对：将文件中的 1 处 `MS4w…` 账号常量替换为 `<REDACTED_ACCOUNT>` 后再哈希；**未打印账号或客户内容**。

| 路径 | 安装前 SHA256 | 预期 23ba734 | 是否匹配 | 说明 |
|---|---|---|---|---|
| `C\control.py` | `46975b2fefa8f5983f5a46ec9f5ef87c59d3fa76db10839f456153edbcb1ebc0` | raw `009429c5…2554` | raw 否；脱敏后是 | 等于 16:25 部署记录；脱敏后 `009429c5008ec694e02df1a3fb047d6c311f6988185249e3645358b7c29a2554`。mtime 2026-11-08 16:25:36，LF，20140 字节。可解释，不是不明差异。 |
| `C\panel.py` | `1e9711000d724b6e37637556255a2a882405e19254c22408a9cebb36e5fc7ebf` | `1e971100…7ebf` | 是 | mtime 2026-11-08 15:30:38，CRLF，5993 字节 |
| `C\send_hold.py` | `ae64446fd6a125cb6e3fa5fc355c2543e6b0cd127b52bd6fdeee7cd1349f69e3` | `ae64446f…69e3` | 是 | mtime 2026-11-04 16:10:03，LF，1154 字节 |
| `C\target_reader.cjs` | `1d3d2cc8be5be275b9fcdf7e2eb81cf2c610f9c2d0925136e15d81f91d9c2ee0` | `1d3d2cc8…2ee0` | 是 | mtime 2026-11-08 15:30:38，LF，10594 字节 |
| `C\unknown_resolution.py` | `d16434a40c708574f0a64693ec89522b4ef4ccb9c19582d1a557475da3539d62` | `d16434a4…9d62` | 是 | 等于 16:25 部署记录。mtime 2026-11-08 16:25:36，LF，28279 字节 |
| `T\batch_reply_runner.py` | `aa7e687f7c1d0d3852c037fab68e4792c1f56efc73c138a65f537d280110dfa2` | raw `3b22dda8…82a1` | raw 否；脱敏后是 | 脱敏后 `3b22dda8592d8c77703ed1ae759ec2165b16a41ee1985164c7a16d419d7f82a1`。mtime 2026-11-06 15:25:27，CRLF，20663 字节。可解释（生产账号常量），不是不明差异。 |
| `T\resume_after_confirmation.py` | `82b2384420c1ac0bf9c2ac8cf6c5b80bb13b9c16457936851eac61d6f3835d2c` | `82b23844…5d2c` | 是 | mtime 2026-11-08 15:30:39，CRLF，3267 字节 |

目标 0d1e252 SHA（本次未应用，仅备查）：

- `C\control.py` 脱敏后应到 `c6b8681b1f8d407441b4b72835e1e82004398cb9661b931a12aa064617859423`（生产原文因账号常量不会等于该值）
- `C\panel.py` `9069729b61de78a1639852b8b3084667de2b72c365f47c94520302c31e845dad`
- `C\send_hold.py` `9e0d78c26e3c37814a4c9d720e34e25ab639649b9321c29c38404b5f7f62bed4`
- `C\target_reader.cjs` `49ed5cdd33b4c852ca89a6a72582bf1a78b930120d68ab511370d9ab5d2f8e9d`
- `C\unknown_resolution.py` `0b6bbb1c68b39b49b090852d9d8fbfacc11d56f240fa775145c7fa55b3660a30`
- `T\batch_reply_runner.py` 脱敏后应到 `5888835a6cc034b9d56d69fd731fe61155a78997d51bcc89b318294c56747c17`
- `T\resume_after_confirmation.py` `6f5b23de08bfa9c3237ff422ec4c6562a00ec9c4d7017fe0ab0902e5ed590c0f`

## 安装与语法检查

未执行。未拷补丁、未 `git apply`、未覆盖任何文件、未跑 `py_compile` / `node --check`。

## 范围外

未改：账本 `shared.sqlite3`/-wal/-shm、队列、授权、回执、`.submitted`、模板 `work\douyin-round2-task5\` 两文件、测试文件、`send_cli_once.cjs`。
未访问抖音或其他平台网络，未诊断，未发送，未启动 CLI/runner/control。
未打印账号或客户内容。

辅助只读脚本曾放到本机 `C:\Users\rmsama\AppData\Local\Temp\dy-isolate-install\baseline_check.py`（不在项目目录，未改业务文件）。因已停装，未再删除该临时文件。

## 精确阻塞

**PID 52784 的 `pythonw.exe` 正在运行 `douyin-local-control\panel.py`。**

按「已有相关进程则立即停并报、不改文件」停止。七文件基线在说明账号常量脱敏后均能对上 23ba734，基线本身不是阻塞原因。

要继续安装，需要：面板已关闭（或用户另作明确授权后再处理该进程），然后重新做一次进程检查；通过后再备份并安装这 7 个文件。本次授权不含关面板、启动或发送。安装成功也不等于可以发送；运行中新出现的 unknown 仍需下次启动才会隔离。
