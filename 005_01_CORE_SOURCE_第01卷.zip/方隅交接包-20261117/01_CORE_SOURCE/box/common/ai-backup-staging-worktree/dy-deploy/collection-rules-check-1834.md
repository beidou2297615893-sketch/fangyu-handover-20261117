# 抖音采集配置/规则只读核对 2026-11-08 18:34 北京时间
未启采/未联网/未读Bridge页面/未改文件/未查数据库/未读客户正文；本机仅 3 次只读读取（JSON键值+源码grep）+1次grep规则文件。发送进程未触碰。
I=R\work\fangyu-douyin-independent
- active-runner.json: status=running pid=36212（过期，进程不存在）；plan=plan-confirmed-20261107-051216-338401.json；dir=runner-live-confirmed-20261107-051216-338401；account=泪痣；target_comments=100000；minimum_delay_ms=1000；maximum_comment_age_days=30；comment_age_boundary=rolling_30_days_2592000_seconds；classification_exclusion_version=fangyu-commercial-fit-v4.3-20261106
- plan: 无重复键；account_uid=泪痣(1e985ff0…同发送)；connection_id=95bb3665…（rebind 11/7 Codex）；stores=15；每店词数[5,32,27,33,36,37,24,33,6,6,14,46,44,45,6] 合计394、无重复；plan_source=fangyu-text-business-20261029\recent-collection\近期优先搜索词.csv；deferred_previous_account_searches=3090（旧账号已试搜索被递延/排除）；excluded_historical_videos=2060；diagnostic_keywords_never_automatically_replay=1；maximum_comment_age_days=30
- runner.cjs: L73-75 读 store.keywords 去重；L216-243 店铺轮换 nextIndex 循环；L308 使用 plan.maximum_comment_age_days(默认30)；L318 page_items_digest+ledger.pageSeen 防同页重复；L269 stopped 非 local_stop_* 时 --resume-local 抛 only_explicit_user_stop_can_be_locally_resumed
- excluded_historical_videos/deferred_*：runner.cjs 不直接引用；由 collection_confirmed_scope.py L19/20/60、runner_ledger_adapter.py L149 引用（未深挖调用链）
- control.json: stopped=ledger_unknown, pending=null, nextIndex=9, last_completed=11/7 20:24:31(北京)
- 规则 business_fit.py（发送前/分类筛选，非采集入口过滤）：<3000 → whole_home_monthly_budget_below_3000 排除；3000–3999 → 待核hold；L171-173 source_post_advertised_rent_below_3000 按来源帖广告租金排除（需用户确认是否符合“不是每店统一房价”口径）；IP 不当客户条件(L4, L224)；冲突金额不取最低(L86)；30天窗口(L187)；role unknown 需明确求租(L139)；send_authorized=False 固定
- runner-qualification-policy.json account_uid=另一账号(8Ju…)，qualified_request_ids=12，仅历史计数白名单
未证：近15天/超高预算适配规则未在grep中定位；地域守门具体实现未定位；394 vs 15×200 差异为换词表(近期优先搜索词.csv)+3090递延，非解析漏载证据

## 18:38 收口（仅既有材料+窄引用；未修/未启采/未联网/未碰发送）
1. 来源帖广告租金<3000排除 —— 符合，用户原话认可：source.md 消息384 用户「除非说那个帖子本身就是一两千的视频，那么他这个预算就不在我们的这…」；消息387/388 助手落实「帖子标题、正文明确是低租金房源，另作低价来源筛选」，客户预算仍以本人评论为准、未写为待确认。business_fit.py L171-173 与此一致（限来源帖上下文，非每店统一房价）。
2. 超高意向 —— 符合：business_fit.py L168 explicit_compatible_budget(budget_at_least_4000…) 且 L206 age_band<=1 → super_high；test_business_fit.py L41/L80「求租，预算5000→super_high」。口径来源 source.md L6176/L6192「超高…近15天，同时要求明确求租、预算匹配」；initial-audit.md L63/L179。age_band<=1 即近15天为按时间档(近7/8–15)推断，未逐行核 band() 边界。
3. 地域守门 —— 部分：business_fit.py L164 消费上游 region_conflict/geography_status(mismatch/out_of_coverage)/store_match_status 排除，test L43 覆盖；口径 source.md L3453/L4299「求租地区优先，IP辅助…不清楚进待核池」。产生这些字段的上游分类模块未定位 → 待核（需窄定位生产者，不在本次范围）。
4. ledger_unknown 合法继续 —— 未找到现成方式：runner.cjs L269 --resume-local 拒绝非 local_stop_*；douyin-runtime.md L54「keep ledger_unknown stop; no continue/replay/confirm-id」；Codex完整交接指令.md L38 与 questions-douyin.md 第5项把它列为待原持有人回答的问题，未见历史实证恢复法（volume-01 L1288 仅记录再次按 ledger_unknown 退出）。结论：现有材料无合法继续入口，未来启采会被挡，须原持有人/用户决定，不清不重采。
