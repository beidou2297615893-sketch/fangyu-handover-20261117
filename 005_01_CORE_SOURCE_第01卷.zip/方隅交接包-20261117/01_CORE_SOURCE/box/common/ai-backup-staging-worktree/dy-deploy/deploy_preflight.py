import pathlib,re,hashlib,json,subprocess
BASE=pathlib.Path(__file__).resolve().parent
M=pathlib.Path(r'C:\Users\rmsama\AppData\Local\Temp\dy-isolated-cs1lzoyo')
R=pathlib.Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统')
def reverse_file(data,name):
 patch=(BASE/'full.patch').read_bytes().splitlines(keepends=True)
 active=False;hunks=[];cur=None
 for line in patch:
  if line.startswith(b'diff --git '):
   active=line.startswith(('diff --git a/'+name+' b/').encode());cur=None
  elif active and line.startswith(b'@@ '):
   m=re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line)
   cur=[int(m[3]),int(m[4] or b'1'),[],[]];hunks.append(cur)
  elif active and cur is not None and line[:1] in (b' ',b'+',b'-'):
   if line[:1] in (b' ',b'-'):cur[2].append(line[1:])
   if line[:1] in (b' ',b'+'):cur[3].append(line[1:])
 lines=data.splitlines(keepends=True)
 for start,count,old,new in reversed(hunks):
  at=start-1 if count else start
  assert lines[at:at+count]==new,'reverse patch context mismatch '+name+' line '+str(start)
  lines[at:at+count]=old
 return b''.join(lines)

names=['douyin-local-control/control.py','douyin-local-control/panel.py','douyin-local-control/startup_recovery.py','douyin-local-control/target_reader.cjs','task/resume_after_confirmation.py','task/send_cli_once.cjs']
out=[]
for n in names:
 expected=hashlib.sha256(reverse_file((M/'work'/n).read_bytes(),n)).hexdigest()
 actualpath=R/'work'/n if not n.startswith('task/') else R/'work/douyin-local-20261104-1e985ff064'/n.split('/')[-1]
 actual=hashlib.sha256(actualpath.read_bytes()).hexdigest()
 out.append({'file':n,'baseline_expected':expected,'baseline_actual':actual,'match':expected==actual})
print(json.dumps(out,indent=2))
print('UNKNOWN_RESOLUTION_EXISTS', (R/'work/douyin-local-control/unknown_resolution.py').exists())
(BASE/'baseline-preflight.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
