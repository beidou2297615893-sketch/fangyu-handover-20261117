import pathlib,tempfile,subprocess,shutil,json,hashlib,difflib,re
B=pathlib.Path(__file__).resolve().parent
R=pathlib.Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统');W=R/'work';M=pathlib.Path(tempfile.mkdtemp(prefix='dy-deploy-rehearsal-'));I=pathlib.Path(r'C:\Users\rmsama\AppData\Local\Temp\dy-isolated-cs1lzoyo')
log=[]
def say(x):log.append(x);print(x,flush=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
git=shutil.which('git');assert git
rows=json.loads((B/'baseline-preflight.json').read_text())
def run(args,cwd,ok=True):
 q=subprocess.run([git]+args,cwd=cwd,capture_output=True)
 if ok:assert q.returncode==0,'git command failed (diagnostics suppressed)'
 return q
try:
 for row in rows:
  n=row['file'];rel=n if not n.startswith('task/') else 'douyin-local-20261104-1e985ff064/'+n.split('/')[-1]
  source=W/rel;assert sha(source)==row['baseline_expected'],'production baseline mismatch '+n
  dest=M/'work'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
 say('SIX_BASELINES exact; files copied only to '+str(M))
 # Prove split patches are byte-exact sections of original deploy.patch.
 chunks=re.split(rb'(?=diff --git )',(B/'deploy.patch').read_bytes())
 for prefix,n in [(b'diff --git a/douyin-local-control/','control-deploy.patch'),(b'diff --git a/task/','task-deploy.patch')]:
  expected=b''.join(x for x in chunks if x.startswith(prefix));assert expected==(B/n).read_bytes(),'split mismatch'
  say('SPLIT '+n+' SHA256='+hashlib.sha256(expected).hexdigest()+' exact=True')
 prodroot=run(['rev-parse','--show-toplevel','--show-prefix'],W).stdout.decode('utf-8',errors='replace');say('PRODUCTION ROOT/PREFIX '+prodroot.replace('\n',' | '))
 for key in ('core.autocrlf','core.eol'):
  q=run(['config','--get',key],W,False);say('GIT_CONFIG '+key+'='+q.stdout.decode().strip()+' rc='+str(q.returncode))
 # Isolated original test tree had no git root; production tree does.
 q=run(['rev-parse','--show-toplevel'],I/'work',False);say('OLD_ISOLATION Git root rc='+str(q.returncode))
 run(['init','--quiet'],M)
 control=M/'work/douyin-local-control/control.py';before=sha(control)
 old=['-c','core.autocrlf=false','apply','--unidiff-zero']
 q=run(old+['--check',str(B/'control-deploy.patch')],M/'work');say('OLD_COMMAND check rc='+str(q.returncode))
 q=run(old+[str(B/'control-deploy.patch')],M/'work');say('OLD_COMMAND apply rc='+str(q.returncode)+' SHA='+sha(control)+' unchanged='+str(sha(control)==before))
 # --verbose proof emits only patch file names, not code/account values.
 q=run(old+['--check','--verbose',str(B/'control-deploy.patch')],M/'work');say('OLD_VERBOSE '+q.stderr.decode('utf-8',errors='replace'))
 a=control.read_bytes();b=(I/'work/douyin-local-control/control.py').read_bytes()
 say('COMPARE bom_equal='+str(a.startswith(b'\xef\xbb\xbf')==b.startswith(b'\xef\xbb\xbf'))+' trailing_newline_equal='+str(a.endswith(b'\n')==b.endswith(b'\n'))+' CRLF_counts='+str((a.count(b'\r\n'),b.count(b'\r\n'))))
 for tag,i,j,k,l in difflib.SequenceMatcher(None,a.splitlines(True),b.splitlines(True),autojunk=False).get_opcodes():
  if tag=='equal':continue
  aa=a.splitlines(True)[i:j];bb=b.splitlines(True)[k:l]
  typ='line_endings' if [x.rstrip(b'\r\n') for x in aa]==[x.rstrip(b'\r\n') for x in bb] else 'patch_not_applied'
  say('DIFF '+json.dumps({'current_lines':[i+1,j],'expected_lines':[k+1,l],'operation':tag,'type':typ}))
 # Correct root-relative path mapping; keep both patch sections unchanged.
 cp=old+['--directory=work',str(B/'control-deploy.patch')]
 tp=old+['-p2','--directory=work/douyin-local-20261104-1e985ff064',str(B/'task-deploy.patch')]
 for cmd in (cp,tp):run(cmd[:-1]+['--check',cmd[-1]],M)
 for cmd in (cp,tp):run(cmd,M)
 expected={t[0]:t[2] for line in (B/'sha.txt').read_text().splitlines() if len(t:=line.split('\t'))==3}
 expected['douyin-local-control/control.py']='a1f10189a4adebc6a3563bd5585906dca3250d18db842cb8368b3ebb8cf84f32';expected['task/send_cli_once.cjs']='d2dbdaf6bae665280ab95657e615fa67013df3fea5c4cb3b3f441421287757bc'
 for n in [r['file'] for r in rows]+['douyin-local-control/unknown_resolution.py']:
  rel=n if not n.startswith('task/') else 'douyin-local-20261104-1e985ff064/'+n.split('/')[-1]
  p=M/'work'/rel;actual=sha(p);say('REHEARSAL SHA '+n+' '+actual+' match='+str(actual==expected[n]));assert actual==expected[n]
 assert control.read_bytes()==(I/'work/douyin-local-control/control.py').read_bytes()
 say('SUCCESS seven final SHAs match; control byte-identical to prior isolated result; no production changes')
except Exception as e:say('STOP '+type(e).__name__+' '+str(e))
finally:(B/'deployment-diagnosis-output.txt').write_text('\n'.join(log)+'\n',encoding='utf-8')
