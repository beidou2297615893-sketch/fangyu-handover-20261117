import unittest
from datetime import datetime,timezone,timedelta
import business_fit as f

class BusinessFit(unittest.TestCase):
    def row(self,text,**kwargs):return dict(comment_text=text,role='demand',pools=['价格预算'],interest_at_comment='high',**kwargs)
    def test_low_whole_home(self):
        for text in ['预算1300求租今天入住','预算一千三','预算一千三百','预算1.3k','求租1300/月','外环路地铁站附近 1300预算 带独卫有窗户有吗','想找个600-1300的，就像这种一个大房','许愿上海松江区车墩镇的房子，预算1300以内，不要顶层','中坝四号线有没有套一预算1300-1800','封顶1300一个月 中春路七宝有没有推荐的','预算一两千求租','预算两千多求租']:
            with self.subTest(text=text):
                got=f.screen(self.row(text));self.assertEqual(got['commercial_fit'],'very_low');self.assertFalse(got['eligible_candidate'])
    def test_scope(self):
        for text in ['押金1300预算5000','以前1300现在预算5000','以前房租1300，现在预算5000','工资1300，预算5000']:
            with self.subTest(text=text):self.assertEqual(f.budget(text,True)['monthly_minimum'],5000)
        for text in ['预算1300/天','预算1300每天','预算13000每年']:
            self.assertNotEqual(f.budget(text,True)['state'],'below_3000')
    def test_joint(self):
        b=f.budget('两人每人2000整租',True);self.assertEqual(b['monthly_minimum'],4000);self.assertEqual(b['monthly_maximum'],4000)
        self.assertFalse(f.screen(self.row('合租单间预算1300'))['eligible_candidate'])
    def test_range_unknown(self):
        self.assertEqual(f.budget('预算2000到4500')['state'],'budget_unverified')
        self.assertNotEqual(f.screen(self.row('预算2000到4500'))['commercial_fit'],'very_low')
        for t in ['预算3500','预算3k5','预算三千五','预算3000到3999']:
            self.assertFalse(f.screen(self.row(t))['eligible_candidate'],t)
    def test_non_budget_numbers(self):
        for text in ['说半天多少钱','找了半天房','Hi这是哪里？1300元？','这套1300真的假的','11月3日入住，想租两个月','押金1300求租','以前1300现在想换房','1300米离地铁远吗']:
            with self.subTest(text=text):self.assertNotEqual(f.screen(self.row(text))['commercial_fit'],'very_low')
    def test_uncapped_low_held(self):
        for t in ['预算1300+','预算1300左右','预算1300上下','预算1300以上','1300','1.3k','想找个600-1300的','有1500的房吗','附近1300左右有房吗','租个2000以内的','1800能租吗','1500预算','1300一个月']:
            with self.subTest(text=t):self.assertFalse(f.screen(self.row(t))['eligible_candidate'])
    def test_low_colloquial_budgets_do_not_enter_queue(self):
        for text in ['预算五百','预算就八百','预算1,000','预算能给800',
                     '西土城上班，1.5-2k，通勤1小时左右，不合租，有推荐么',
                     '北京西上班 1-1.5k 推荐推荐','预算除电费2000以内',
                     '有没有可以短租的一到两千的房子','目前住门头沟有没有哪里1k的房子']:
            with self.subTest(text=text):
                self.assertFalse(f.screen(self.row(text))['eligible_candidate'])
        self.assertTrue(f.screen(self.row('中介费700吗'))['eligible_candidate'])
        self.assertTrue(f.screen(self.row('2028年可以住吗，房还在吗'))['eligible_candidate'])
    def test_recent_demand_does_not_require_unused_manual_flags(self):
        r=self.row('预算5000求租',published_at=datetime.now(timezone.utc).isoformat())
        self.assertEqual(f.screen(r)['lead_intent'],'super_high')
        r['comment_text']='求租，具体位置在哪里';self.assertEqual(f.screen(r)['commercial_fit'],'high')
        r['region_conflict']=True;self.assertFalse(f.screen(r)['eligible_candidate'])
    def test_low_source_post_and_comment_budget_are_separate(self):
        r=self.row('多少钱',published_at=datetime.now(timezone.utc).isoformat(),post_body='上海整租，月租1800')
        fit=f.screen(r);self.assertFalse(fit['eligible_candidate']);self.assertEqual(fit['budget']['state'],'budget_unverified')
        r['comment_text']='我预算5000，求租';self.assertTrue(f.screen(r)['eligible_priority'])
        r['post_body']='押金800，电费500，月租5000';self.assertTrue(f.screen(r)['eligible_priority'])
        r['comment_text']='多少钱';r['post_body']='月租1800起';self.assertFalse(f.screen(r)['eligible_priority'])
    def test_old_comment_deprioritized_without_deleting_candidate(self):
        r=self.row('预算5000求租',published_at=(datetime.now(timezone.utc)-timedelta(days=100)).isoformat())
        self.assertTrue(f.screen(r)['eligible_candidate']);self.assertFalse(f.screen(r)['eligible_priority'])
    def test_only_douyin_has_active_thirty_day_cutoff(self):
        stamp=(datetime.now(timezone.utc)-timedelta(days=40)).isoformat()
        row=self.row('预算5000求租',published_at=stamp,platform='douyin')
        self.assertFalse(f.screen(row)['eligible_candidate'])
        row['platform']='xiaohongshu';self.assertFalse(f.screen(row)['eligible_candidate'])
    def test_douyin_unit_caption_is_separate_source_price(self):
        for body in ['杭州一室一厅1350的小屋','上海转租 闵行七宝一居室1550','金汇两房整租2300']:
            with self.subTest(body=body):
                row=self.row('多少钱',platform='douyin',post_body=body,published_at=datetime.now(timezone.utc).isoformat())
                fit=f.screen(row)
                self.assertEqual(fit['budget']['state'],'budget_unverified')
                self.assertIn('source_post_advertised_rent_below_3000',fit['exclusion_reasons'])
                row['comment_text']='我预算5000求租';self.assertTrue(f.screen(row)['eligible_candidate'])
        for body in ['一室一厅押金1500，月租5000','以前一室一厅1800，现在月租5000','一室一厅3个人住','单间150/天','整租100平米，月租5000','转租2026年签的房子','一室一厅100㎡']:
            self.assertNotIn('source_post_advertised_rent_below_3000',f.screen(self.row('多少钱',platform='douyin',post_body=body))['exclusion_reasons'],body)
    def test_identity_or_channel_limit_is_review_not_blanket_rejection(self):
        for text in ['求租房子，中介勿扰','如果你是个人房东请给我留言，我要租房','礼貌问价，明盘，不要私信']:
            with self.subTest(text=text):
                fit=f.screen(self.row(text,platform='douyin',published_at=datetime.now(timezone.utc).isoformat()))
                self.assertFalse(fit['eligible_candidate'])
                self.assertFalse(fit['exclusion_reasons'])
                self.assertEqual(fit['candidate_state'],'pending_verification')
        fit=f.screen(self.row('求租，不要联系我',platform='douyin'))
        self.assertIn('contact_or_brand_restricted',fit['exclusion_reasons'])
    def test_inquiry_clear_request_and_budget_have_different_grades(self):
        now=datetime.now(timezone.utc)
        cases=[('多少钱','medium'),('具体位置在哪','medium'),('我想租，哪里可以看房','high'),
               ('求租，预算5000','super_high'),('预算500想租','low')]
        for text,expected in cases:
            with self.subTest(text=text):self.assertEqual(f.screen(self.row(text,published_at=now.isoformat()))['lead_intent'],expected)
        older=self.row('求租，预算5000',published_at=(now-timedelta(days=20)).isoformat())
        self.assertEqual(f.screen(older)['lead_intent'],'high')
        unclear=self.row('求租，预算5000')
        self.assertEqual(f.screen(unclear)['lead_intent'],'high')
    def test_demands_and_restrictions(self):
        for t in ['我有房出租预算5000','已经租到房了','求租不要中介','求租不住公寓','不要私信求租']:
            self.assertFalse(f.screen(self.row(t))['eligible_candidate'],t)
        self.assertTrue(f.screen(self.row('求租不要中介费'))['eligible_candidate'])
        self.assertTrue(f.screen(self.row('已经租到房了但我想换房'))['eligible_candidate'])
        for t in ['求一个转租，预算5000','求房东直租，预算5000','不找室友，想整租，预算5000','不接受转租，预算5000']:
            self.assertTrue(f.screen(self.row(t))['eligible_candidate'],t)
        self.assertFalse(f.screen(self.row('预算2000可以加到4500'))['eligible_candidate'])
        self.assertNotEqual(f.screen(self.row('预算2000可以加到4500'))['commercial_fit'],'very_low')
    def test_preserve(self):
        r=self.row('预算1300求租');r.update(reply={'draft_text':'旧稿'},delivery={'status':'sent'})
        out=f.apply(r);self.assertEqual(r['reply']['draft_text'],'旧稿');self.assertEqual(out['prior_draft_before_business_fit']['draft_text'],'旧稿');self.assertEqual(out['delivery'],r['delivery']);self.assertEqual(out['interest_at_comment'],'high');self.assertIsNone(out['reply']['draft_text'])

if __name__=='__main__':unittest.main()
