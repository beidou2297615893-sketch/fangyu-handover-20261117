const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..'), runtime=path.join(root,'work/runtime/douyin-bridge');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const identityOnly=process.argv[2]==='--identity';
const preflight=process.argv[2]==='--preflight';
const verifyOwn=process.argv[2]==='--verify-own-reply';
const task=identityOnly||preflight||verifyOwn?null:read(process.argv[2]);
process.env.DOUYIN_RISK_STATE_PATH=path.join(__dirname,'cli-risk-state.json');
process.env.DOUYIN_LOG_DIR=path.join(__dirname,'cli-logs');
const {BridgeClient}=require(path.join(runtime,'lib/client/bridge-client'));
const client=new BridgeClient(read(path.join(root,'抖音自用采集台/data/bridge.json')).bridge);
const bindingPath=path.join(__dirname,'cli-current-binding.json');
const connId=((preflight||verifyOwn) && process.argv[5]) || (fs.existsSync(bindingPath)?read(bindingPath).connection_id:null);
const accountUid='<REDACTED_ACCOUNT>';
const post=require(path.join(runtime,'lib/commands/post'));
const {diagnosticCodes,canSkip,buildTargetCheck}=require('./target-diagnosis.cjs');
let attempted=false,receipt=null;
const ctx={noStore:true,audit:{startOperation(){},endOperation(){}},loggedCall:async(endpoint,params,expression)=>{
 fs.writeFileSync(process.argv[2]+'.submitted',new Date().toISOString(),{flag:'wx'});
 attempted=true;
 const r=await client.call({site:'douyin.com',connId,expression,timeout:15000});
 if(!r.ok||r.connection!==connId)throw Error(r.error||'Connection mismatch');
 const d=r.value,c=d?.comment;
 receipt={status_code:d?.status_code,message:d?.status_msg,cid:c?.cid,text:c?.text,sec_uid:c?.user?.sec_uid,reply_id:c?.reply_id,status:c?.status};
 fs.writeFileSync(process.argv[2]+'.receipt.json',JSON.stringify({at:new Date().toISOString(),connection_id:connId,receipt},null,2),{flag:'wx'});
 return d;
}};
(async()=>{try{
 if(identityOnly||preflight||verifyOwn){
  const status=await client.status();
  const pages=(status.connections?.['douyin.com']||[]).filter(c=>c.alive&&!c.url.includes('/ucenter/security/')).sort((a,b)=>Date.parse(b.lastActivity)-Date.parse(a.lastActivity));
  if(!pages.length)throw Error('No active Douyin page connection');
  if(!pages.some(p=>p.id===connId))throw Error('Round2Task5 fixed connection unavailable');
  const r=await client.call({site:'douyin.com',connId,timeout:10000,expression:`(async()=>{const p=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+p,{credentials:'include'});const d=await r.json();return {status_code:d.status_code,account_uid:d.user?.sec_uid,nickname:d.user?.nickname}})()`});
  if(!r.ok||r.connection!==connId||r.value?.status_code!==0||r.value?.account_uid!==accountUid)throw Error('Current account identity not verified: '+JSON.stringify({ok:r.ok,error:r.error,status_code:r.value?.status_code,account_match:r.value?.account_uid===accountUid,connection_match:r.connection===connId}));
  if(preflight){
   const [videoId,commentId]=process.argv.slice(3);
   if(!/^\d+$/.test(videoId||'')||!/^\d+$/.test(commentId||''))throw Error('目标编号无效');
   const {readTarget}=require('../douyin-local-control/target_reader.cjs');
   const checkpointPath=path.join(__dirname,commentId+'-read-checkpoint.json');
   const checkpoint=fs.existsSync(checkpointPath)?read(checkpointPath):null;
   const diagnosis=await readTarget(client,connId,videoId,commentId,{checkpoint,
    onProgress:point=>{fs.writeFileSync(checkpointPath,JSON.stringify(point));
     const statePath=path.join(__dirname,'batch-runner-status.json');
     if(fs.existsSync(statePath)){const state=read(statePath);state.reason='正在分段读取目标评论，第'+point.pages+'页；尚未提交。';state.updated_at=new Date().toISOString();fs.writeFileSync(statePath,JSON.stringify(state));}},
    clearCheckpoint:()=>{if(fs.existsSync(checkpointPath))fs.unlinkSync(checkpointPath);}});
   console.log(JSON.stringify({status:'target_check',diagnosis}));return;
  }
  if(verifyOwn){
   const [videoId,commentId]=process.argv.slice(3,5);
   if(!/^\d+$/.test(videoId||'')||!/^\d+$/.test(commentId||''))throw Error('目标编号无效');
   const attemptPath=path.join(__dirname,commentId+'.json');
   if(!fs.existsSync(attemptPath))throw Error('缺少原尝试记录，无法只读核对');
   const attempt=read(attemptPath);
   if(attempt.account_uid!==accountUid||String(attempt.comment_id||commentId)!==commentId)throw Error('Task account mismatch');
   const draft=attempt.reply&&attempt.reply.draft_text;
   if(typeof draft!=='string'||!draft)throw Error('缺少原文，无法只读核对');
   const {readOwnReply}=require('../douyin-local-control/target_reader.cjs');
   const diagnosis=await readOwnReply(client,connId,videoId,commentId,{accountUid,text:draft});
   console.log(JSON.stringify({status:'own_reply_check',diagnosis,submission_attempted:false,automatic_retry:false}));
   return;
  }
  fs.writeFileSync(bindingPath,JSON.stringify({connection_id:connId,account_uid:accountUid,verified_at:new Date().toISOString()},null,2));
  console.log(JSON.stringify({verified:true,...r.value,connection_id:connId}));return;
 }
 const state=read(path.join(__dirname,'continuation-state.json'));
 if(!connId||read(bindingPath).account_uid!==accountUid)throw Error('Batch account binding missing');
 if(state.status==='stopped_platform_rejection'||state.unknown>0)throw Error('Unresolved platform rejection; no submission');
 if(task.account_uid!==accountUid)throw Error('Task account mismatch');
 const identity=await client.call({site:'douyin.com',connId,timeout:10000,expression:`(async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include'});const d=await r.json();return {code:d.status_code,uid:d.user?.sec_uid}})()`});
 if(!identity.ok||identity.connection!==connId||identity.value?.code!==0||identity.value?.uid!==accountUid)throw Error('Round2Task5 identity changed; no submission');
 await post(ctx,[task.video_id,task.reply.draft_text,'--reply-to',task.comment_id]);
 if(!receipt?.cid||receipt.status_code!==0||receipt.text!==task.reply.draft_text||receipt.sec_uid!==task.account_uid||String(receipt.reply_id)!==task.comment_id)throw Error('Incomplete CLI success receipt');
 receipt.success_basis='platform_publish_response';
 console.log(JSON.stringify({status:'sent',receipt}));
}catch(e){
 let diagnosis=null,skip_target=false;
 if(attempted && !receipt?.cid && diagnosticCodes.includes(receipt?.status_code)){
  try{
   const r=await client.call({site:'douyin.com',connId,timeout:15000,expression:buildTargetCheck(task.video_id,task.comment_id)});
   if(r.ok && r.connection===connId){
    diagnosis=r.value;
    skip_target=canSkip(receipt,diagnosis);
   }
  }catch(diagnosticError){diagnosis={error:diagnosticError.message};}
 }
 console.log(JSON.stringify({status:skip_target?'not_sent':attempted?'unknown':'not_sent',error:receipt?.status_code===3002123?'需要检查验证码或其他平台提示；错误码3002123未说明原因，等待验证完成后恢复':e.message,receipt,skip_target,diagnosis}));process.exitCode=1;
}})();
