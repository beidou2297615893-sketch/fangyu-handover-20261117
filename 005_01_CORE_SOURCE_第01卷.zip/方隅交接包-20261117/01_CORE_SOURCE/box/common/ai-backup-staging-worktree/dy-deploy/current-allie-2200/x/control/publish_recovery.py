"""Skip the specific unavailable target without changing its unknown receipt."""
import datetime
import json

def unavailable_target(result):
    receipt=result.get('receipt') or {}
    diagnosis=result.get('diagnosis') or {}
    return (receipt.get('status_code') in (2053, 2209) and not receipt.get('cid')
        and diagnosis.get('detail_status')==0
        and diagnosis.get('video_present') is False
        and diagnosis.get('no_video_detail') is True)

def preserve_unavailable(task,cid,result):
    if not unavailable_target(result):
        return False
    path=task/'captcha-recovery-authorization.json'
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    preserved=set(data.get('preserve_unknown_comments',[]))
    if cid not in preserved:
        preserved.add(cid)
        data['preserve_unknown_comments']=sorted(preserved)
        data.setdefault('events',[]).append({'at':datetime.datetime.now().astimezone().isoformat(),
            'source':'user_authorized_skip_unavailable_target','skip_unknown_comments':[cid],
            'receipt_status':result['receipt']['status_code'],'diagnosis':result['diagnosis'],
            'note':'原始结果保持未知，不重发；仅跳过当前视频详情不可用的这一目标'})
        temporary=path.with_suffix('.unavailable.tmp')
        temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(path)
    return True
