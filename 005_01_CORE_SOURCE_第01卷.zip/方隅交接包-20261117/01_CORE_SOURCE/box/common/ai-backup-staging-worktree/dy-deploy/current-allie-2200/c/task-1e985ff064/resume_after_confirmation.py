"""Captcha-only confirmation. Startup handles other submitted unknowns first.

A still-unknown captcha receipt stops 启动／继续 before this script runs.
This script does not preserve or resend any other status code.
"""
import os
import sys
import msvcrt
import batch_reply_runner as runner

def pending_confirmation(rows, approved, receipt_loader):
    pending = [r for r in rows if r['token'].startswith(runner.PREFIX)
               and r['status'] in ('reserved', 'unknown')
               and not (r['status'] == 'unknown' and r['comment'] in approved)]
    if not pending:
        return []
    for row in pending:
        receipt = receipt_loader(row['comment'])
        if row['status'] != 'unknown' or (receipt.get('receipt') or {}).get('status_code') != 3002123:
            raise RuntimeError('当前异常不是待人工确认的验证事件，请检查停止原因')
    return [r['comment'] for r in pending]

def main():
    with (runner.HERE / 'batch-runner.lock').open('a+b') as lock:
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            print('任务已在运行，无需重复启动', flush=True)
            return
        try:
            auth_path = runner.HERE / 'captcha-recovery-authorization.json'
            auth = runner.load(auth_path)
            approved = set(auth.get('preserve_unknown_comments', [])) | set(auth.get('isolated_unknown_comments', []))
            pending = pending_confirmation(runner.ledger_rows(), approved,
                lambda cid: runner.load(runner.HERE / (cid + '-cli-receipt.json')))
            if (runner.HERE / 'batch-stop.json').exists():
                raise RuntimeError('任务有停止标记，不能通过验证按钮恢复')
            identity = runner.run_json([runner.NODE, runner.ADAPTER, '--identity'])
            if identity.get('verified') is not True or identity.get('account_uid') != runner.ACCOUNT:
                raise RuntimeError('账号核对未通过，未恢复')
            auth.setdefault('events', []).append({'at': runner.now(),
                'source': 'local_user_button', 'user_statement': '验证已完成，继续',
                'skip_unknown_comments': pending, 'account_uid': runner.ACCOUNT})
            auth['preserve_unknown_comments'] = sorted(approved.union(pending))
            runner.save(auth_path, auth)
            print('已收到启动／继续确认；账号核对通过，保留已有记录，从下一目标继续。', flush=True)
            runner.execute()
        except Exception as exc:
            print('已停止：' + str(exc), flush=True)
            runner.save(runner.HERE / 'batch-runner-status.json', {
                'status': 'blocked', 'reason': str(exc), 'updated_at': runner.now(),
                'process_id': os.getpid(), 'automatic_retry': False,
                'confirmed_sent': sum(r['token'].startswith(runner.PREFIX) and r['status']=='sent'
                                      for r in runner.ledger_rows())})
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    main()
