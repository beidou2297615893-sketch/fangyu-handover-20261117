"""Local evidence-only commercial screening. Never changes historical intent or receipts.

Amounts describe the commenter's current monthly housing budget only. No source-post
price, IP location, historical rent or unrelated number becomes a customer condition.
"""
import re
import sys
from pathlib import Path
from datetime import datetime, timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'recency-priority'))
import recency
import retention30

VERSION = 'fangyu-commercial-fit-v4.3-20261106'
N = r'(?:\d+(?:\.\d+)?(?:[kK百千万元](?:\d)?)?|[零一二两三四五六七八九十百千万]+)'
AMOUNT = re.compile(r'(?P<a>'+N+r')\s*(?:(?P<sep>到|至|[-~—～])\s*(?P<b>'+N+r'))?\s*(?P<tail>以内|以下|左右|上下|多|以上|起|封顶|最多)?')
DIGITS = dict(zip('零一二三四五六七八九两', [0,1,2,3,4,5,6,7,8,9,2]))

def number(raw):
    raw = raw.lower().replace('元','')
    m = re.fullmatch(r'(\d+(?:\.\d+)?)([k百千万])?(\d)?', raw)
    if m:
        unit = {'百':100, 'k':1000, '千':1000, '万':10000}.get(m[2], 1)
        return float(m[1])*unit + (int(m[3])*unit/10 if m[3] else 0)
    total = 0; digit = 0; last_unit = 1
    for ch in raw:
        if ch in DIGITS: digit = DIGITS[ch]
        elif ch in '十百千万':
            unit = {'十':10,'百':100,'千':1000,'万':10000}[ch]
            total += (digit or 1)*unit; digit = 0; last_unit = unit
        else: return None
    # Spoken 一千三/一万五 abbreviate the next place; 一千三百 remains exact.
    return total + digit*(last_unit/10 if last_unit >= 100 and digit and '零' not in raw else 1)

def budget(text, rental_context=False):
    evidence=[]
    # 一两千/三四千 are intervals, not concatenated Chinese numbers.
    normalized=re.sub(r'(?<!\d)(\d{1,2})[,，](\d{3})(?!\d)',r'\1\2',text)
    normalized=re.sub(r'([一二两三四五六七八九])([一二两三四五六七八九])(百|千|万)',r'\1\3到\2\3',normalized)
    for m in AMOUNT.finditer(normalized):
        a,b=number(m['a']),number(m['b']) if m['b'] else None
        if a is None: continue
        if b is not None and a<100:
            unit=re.search(r'([kK百千万])(?:\d)?$',m['b'])
            if unit and not re.search(r'[kK百千万元]',m['a']):
                a *= {'百':100,'千':1000,'万':10000,'k':1000}[unit[1].lower()]
        pre=normalized[max(0,m.start()-24):m.start()]; post=normalized[m.end():m.end()+15]
        if re.match(r'米(?:离|距|到|远|近|路|外|内)',post):continue
        if post.startswith('米') and re.search(r'地铁|距离|相距|离.{0,6}$',pre):continue
        # Restrict to monetary slots; years, room counts, days, floors are not prices.
        if re.match(r'(?:年|月(?!租|预算|房租)|天|个|人|室|居|楼|平|号线)',post) and not re.match(r'月(?:租|预算|房租)',post): continue
        prefix_budget=bool(re.search(r'(?:预算|封顶|上限|最多|最高|可以加到|能加到|加到|提高到)(?:[是为在大概约就只有能给不超过最多上限到：: ]|(?:不含|不算|除去?)(?:水电(?:费)?|电费|水费)){0,10}$',pre))
        explicit=prefix_budget or (a>=100 and bool(re.match(r'(?:元|块|米)?\s*预算',post)))
        local_clause=re.split(r'[，,。；;！？!?]',pre)[-1]
        current_clause=re.split(r'有没有|想找|想租|要租|求租|想换|求推荐|预算',local_clause)[-1]
        excluded=not prefix_budget and (bool(re.search(r'(?:押金|水电|电费|水费|中介费|工资|收入|买房|首付|房东报价|房源报价).{0,8}$',local_clause)) or bool(re.search(r'(?:以前|之前|原来|曾经|去年|现在住|目前住).{0,8}$',current_clause)))
        monetary=bool(re.match(r'(?:元|块|米|[kK]|/月|每月|一个月|一月|月租)',post) or re.search(r'[百千万元kK]',m['a']+(m['b'] or '')) or (a>=100 and (rental_context or re.search(r'求租|找房|想找|整租|预算|想租|要租',text))))
        scoped=explicit or (monetary and bool(re.search(r'求租|想租|要租|找房|想找|整租|短租|长租|租金|房租|月租|以内|上限',local_clause+post)))
        # A bare amount under a known rental post is ambiguous, never confirmed low.
        if not scoped:
            if monetary and not excluded and ((a>=100 and a<3000 and rental_context) or re.fullmatch(r'\s*'+re.escape(m.group())+r'(?:元|块|米|/月)?[?？!！。 ]*',normalized)):
                evidence.append(dict(quote=m.group(),minimum=min(a,b) if b is not None else a,maximum=max(a,b) if b is not None else a,scope='ambiguous_amount',usable=False))
            continue
        if excluded: continue
        if not explicit and re.search(r'太贵|好贵|这么贵|这么便宜|好便宜|真的假的|真有|这(?:个|套)房',local_clause+post): continue
        lo,hi=sorted([a,b]) if b is not None else (a,a)
        tail=m['tail'] or ''
        if tail=='多': hi=(int(a/1000)+1)*1000-1 if a>=1000 else None
        if tail in ('以上','起'): hi=None
        if post.startswith('+'):hi=None
        if tail in ('左右','上下'): lo=None;hi=None
        scope='whole_home_monthly'; usable=True
        if re.match(r'(?:/(?:天|日|周|年)|每天|每日|每周|每年|一天|一周|一年)',post) or re.search(r'日租|每天|每日|每周|每年',pre[-8:]):
            scope='non_monthly_rate';usable=False
        elif re.search(r'每人|人均|一人',pre[-8:]):
            scope='per_person_monthly';usable=False
            persons=re.search(r'([两二三四五六七八九十\d]+)人',normalized)
            if persons and re.search(r'整租',normalized):
                count=number(persons[1]);lo=lo*count if lo is not None else None;hi=hi*count if hi is not None else None
                scope='whole_home_from_explicit_people';usable=True
        elif re.search(r'合租|单间|床位|次卧|主卧',text) and not re.search(r'不合租|不要合租|整租',text):
            scope='shared_room_monthly';usable=False
        evidence.append(dict(quote=m.group(),nominal_amount=a,minimum=lo,maximum=hi,scope=scope,usable=usable,explicit_budget=explicit))
    usable=[e for e in evidence if e['usable']]
    caps=[e['maximum'] for e in usable if e['maximum'] is not None]
    # Multiple incompatible current amounts are not resolved by picking the cheapest.
    if len(usable)>1:
        return dict(state='budget_conflict_unverified',evidence=evidence,monthly_minimum=None,monthly_maximum=None)
    if not usable: return dict(state='budget_unverified',evidence=evidence,monthly_minimum=None,monthly_maximum=None)
    e=usable[0];lo,hi=e['minimum'],e['maximum']
    state='below_3000' if hi is not None and hi<3000 else ('budget_3000_3999_unverified' if hi is not None and hi<4000 else ('budget_at_least_4000' if lo is not None and lo>=4000 else 'budget_unverified'))
    return dict(state=state,evidence=evidence,monthly_minimum=lo,monthly_maximum=hi)

def advertised_rent(row):
    metadata=(row.get('classification') or {}).get('original_metadata') or {}
    post=row.get('post_body') or metadata.get('post_body')
    if not post:
        post='\n'.join(str(row.get(key) or '') for key in ('post_title','post_text'))
    prices=[]
    for match in re.finditer(r'(?:月租|房租|租金|整租价)(?:\s|[：:￥¥]|只要|只需|仅需|才|低至|最低|仅){0,8}',post):
        if re.search(r'以前|之前|过去|去年|曾经',post[max(0,match.start()-8):match.start()]):
            continue
        amount=AMOUNT.match(post,match.end())
        if not amount:
            continue
        quote=post[match.start():amount.end()]
        parsed=budget('预算'+amount.group(),True)
        if parsed['evidence']:
            prices.append({'quote':quote,'budget':parsed})
    if row.get('platform') == 'douyin':
        # Caption unit prices remain source evidence, never the customer's budget.
        for match in re.finditer(r'(?:整租|转租|出租|一室(?:一厅)?|两室(?:一厅)?|一居(?:室)?|两居(?:室)?|套一|套二|单间|开间)(?P<gap>[^\d，,。；;]{0,8})', post):
            pre=post[max(0,match.start()-12):match.end()]
            if re.search(r'以前|之前|去年|曾经|工资|押金|水电|中介费|预算|首付', pre):continue
            amount=AMOUNT.match(post,match.end())
            if not amount:continue
            parsed=budget('预算'+amount.group(),True)
            if not any(e.get('nominal_amount',0)>=100 for e in parsed['evidence']):continue
            tail=post[amount.end():amount.end()+5]
            if re.match(r'平|㎡|平方|平米|米|人|室|厅|号|楼|层|年|月|天|分钟|公里',tail):continue
            if re.match(r'/(?:天|日|周|年)|每天|每日|每周|每年|一天|一周|一年',tail):continue
            quote=post[match.start():amount.end()]
            if not any(p['quote']==quote for p in prices):prices.append({'quote':quote,'budget':parsed,'scope':'advertised_rental_unit_caption'})
    return prices

def screen(row, now=None):
    c=row.get('classification') or {};meta=c.get('original_metadata') or {};source_class=row.get('source_classification') or {}
    t=row.get('comment_text') or row.get('text') or c.get('comment_text') or ''
    role=row.get('role') or c.get('role') or c.get('original_role') or 'unknown'
    original_intent=row.get('interest_at_comment') or row.get('interest') or c.get('interest') or c.get('original_intent') or row.get('original_interest')
    b=budget(t,bool(role=='demand' or row.get('post_body') or meta.get('post_body') or c.get('topics') or row.get('pools')))
    source_rents=advertised_rent(row)
    reasons=[];holds=[]
    reopening=bool(re.search(r'但|还想|还要|还在找|想换|要换|重新找|再找|有推荐|求租|求房',t))
    ended=bool(re.search(r'已经租到|已租到|租好了|租到了|找到房了|不找了|不租了|已签约|签好合同|决定租.{0,10}了',t)) and not reopening
    speaker_supply=bool(re.search(r'(?:^|[，,。；;])\s*(?:我有房|本人出租|我是房东|我这(?:里|边)有房|(?:本人)?(?:房东直租|房东出租|房源出租|招室友|找室友|转租))',t))
    supply=role in ('supply','discussion','unrelated') or (speaker_supply and not re.search(r'求租|想租|要租|自己找房|还在找房',t))
    explicit_demand=bool(re.search(r'求租|想租|要租|正在找房|找房|找整租|准备租|预算',t))
    demand=role=='demand' or (role=='unknown' and explicit_demand and not supply)
    if supply: reasons.append('not_supported_customer_demand')
    if ended or (row.get('demand_state') or source_class.get('demand_state') or c.get('demand_state')) in ('ended','completed','inactive'):reasons.append('demand_ended')
    if (row.get('demand_state') or source_class.get('demand_state') or c.get('demand_state')) in ('historical','future'):holds.append('demand_time_state_requires_confirmation')
    if not t:holds.append('original_comment_text_missing')
    flags=meta.get('context_flags') or {}
    conflict=flags.get('source_conflict') if isinstance(flags,dict) else 'source_conflict' in flags
    if row.get('source_error') or row.get('source_version_conflict') or meta.get('source_version_conflict') or conflict:reasons.append('source_error_or_conflict')
    boundary=row.get('contact_boundaries') or c.get('contact_boundaries') or meta.get('contact_boundaries')
    if row.get('platform')=='douyin':
        identity_limited=bool(row.get('effective_contact_policy')=='identity_restricted' or re.search(r'中介勿扰|不要中介(?!费)|不想要中介|只找房东|个人房东|只要个人',t))
        private_only=bool(re.search(r'不要私信|别私信',t))
        broad_text=re.sub(r'(?:中介|二房东|经纪人|房产中介|没有)(?:请)?勿扰','',t)
        if re.search(r'勿扰|不要联系|别联系|不住公寓|不租公寓',broad_text) or row.get('brand_recommendation_allowed') is False:
            reasons.append('contact_or_brand_restricted')
        if row.get('effective_contact_policy') in ('restricted','do_not_contact'):
            reasons.append('contact_identity_restricted')
        if identity_limited:holds.append('contact_identity_requires_confirmation')
        if private_only:holds.append('public_reply_scope_requires_confirmation')
        if boundary and boundary not in ('allow','unknown') and not identity_limited and not private_only:
            holds.append('contact_scope_requires_confirmation')
    else:
        if re.search(r'勿扰|不要私信|别私信|不要联系|别联系|不要中介(?!费)|不住公寓|不租公寓',t) or row.get('brand_recommendation_allowed') is False:reasons.append('contact_or_brand_restricted')
        if boundary and boundary not in ('allow','unknown'):reasons.append('contact_boundary')
        if row.get('effective_contact_policy') in ('identity_restricted','restricted','do_not_contact'):reasons.append('contact_identity_restricted')
    if row.get('region_conflict') or row.get('geography_status') in ('mismatch','out_of_coverage') or row.get('store_match_status')=='mismatch':reasons.append('known_region_conflict')
    if b['state']=='below_3000':reasons.append('whole_home_monthly_budget_below_3000')
    if b['state']=='budget_3000_3999_unverified':holds.append('budget_3000_3999_requires_confirmation')
    if b['state']=='budget_conflict_unverified':holds.append('conflicting_budget_requires_confirmation')
    explicit_compatible_budget=(b['state']=='budget_at_least_4000' and
                               any(e.get('explicit_budget') and e['usable'] for e in b['evidence']))
    if source_rents and not explicit_compatible_budget:
        if all(price['budget']['state']=='below_3000' for price in source_rents):
            reasons.append('source_post_advertised_rent_below_3000')
        elif any(any(e.get('nominal_amount',float('inf'))<3000 for e in price['budget']['evidence']) for price in source_rents):
            holds.append('source_post_low_rent_range_requires_confirmation')
    if any(e.get('nominal_amount',float('inf'))<3000 and (e['maximum'] is None or not e['usable']) for e in b['evidence']):holds.append('low_amount_scope_or_ceiling_unverified')
    if any(e['scope']=='ambiguous_amount' for e in b['evidence']):holds.append('standalone_rental_amount_requires_confirmation')
    if not demand:holds.append('demand_role_unverified')
    if row.get('needs_currentness_review'):holds.append('currentness_review_required')
    # Location and current-need confirmations remain evidence, not mandatory flags.
    location_verified=bool(row.get('target_store_match_verified') or row.get('store_match_verified') or row.get('gubei_match_verified'))
    current_verified=bool(row.get('current_need_confirmed') or row.get('current_need_verified') or c.get('current_need_confirmed'))
    if not location_verified:holds.append('location_unverified')
    if not current_verified:holds.append('current_need_unverified')
    if b['state'] in ('budget_unverified','budget_conflict_unverified'):holds.append('budget_unverified')
    age_band=recency.key(row,now)[0]
    if row.get('platform')=='douyin' and not recency.within_douyin_active_window(row,now):
        reasons.append('outside_douyin_active_30_day_window')
    if row.get('platform')=='xiaohongshu' and retention30.enabled('xiaohongshu') and not recency.within_douyin_active_window(row,now):
        reasons.append('outside_active_30_day_window')
    if age_band>=5:holds.append('comment_age_old_or_unknown_deprioritized')
    hard_hold=any(x in holds for x in ('budget_3000_3999_requires_confirmation','conflicting_budget_requires_confirmation','standalone_rental_amount_requires_confirmation','low_amount_scope_or_ceiling_unverified','demand_role_unverified','demand_time_state_requires_confirmation','currentness_review_required','original_comment_text_missing','source_post_low_rent_range_requires_confirmation','contact_identity_requires_confirmation','public_reply_scope_requires_confirmation','contact_scope_requires_confirmation'))
    eligible=not reasons and not hard_hold
    clear_request=bool(re.search(r'求租|求房|想租|要租|正在找房|找房|找整租|准备租|预算|想找.{0,8}(?:房|一居|两居)|(?:租|找)(?:一个|个|一套).{0,8}(?:房|公寓)|有.{0,8}(?:房子|房源|一室|两室).{0,5}(?:吗|嘛|么)',t))
    low_budget=any(reason in reasons for reason in ('whole_home_monthly_budget_below_3000','source_post_advertised_rent_below_3000'))
    if low_budget:
        intent='low'
    elif supply:
        intent='non_customer'
    elif ended:
        intent='ended'
    elif reasons or hard_hold:
        intent='uncertain'
    elif original_intent in ('uncertain','unknown'):
        intent='uncertain'
    elif demand and clear_request:
        intent='super_high' if explicit_compatible_budget and age_band<=1 else 'high'
    elif demand:
        intent='medium'
    else:
        intent='uncertain'
    eligible=eligible and intent in ('medium','high','super_high')
    priority=eligible and intent in ('high','super_high') and age_band<5
    labels={'super_high':'超高意向','high':'高意向','medium':'中意向','low':'低意向',
            'uncertain':'待核意向','non_customer':'非求租客户','ended':'需求已结束'}
    fit=intent if intent in ('high','super_high') else ('very_low' if reasons else 'unverified')
    return dict(version=VERSION,commercial_fit=fit,lead_intent=intent,lead_intent_label=labels[intent],
                eligible_candidate=eligible,eligible_priority=priority,
                candidate_state='excluded' if reasons else ('pending_verification' if hard_hold or not eligible else ('priority' if priority else 'generic_inquiry_non_priority')),
                exclusion_reasons=reasons,verification_required=list(dict.fromkeys(holds)),budget=b,
                source_advertised_rents=source_rents,demand_role=role,demand_supported=demand,
                location_verified=location_verified,current_need_verified=current_verified,
                original_intent=original_intent,original_intent_preserved=True,
                customer_budget_from_comment_only=True,source_post_price_is_separate_filter=True,
                ip_is_not_exact_target_store=True,send_authorized=False)

def apply(row):
    out=dict(row);fit=screen(row);out['commercial_fit']=fit
    out['commercial_pending_eligible']=fit['eligible_candidate']
    out['commercial_priority']=fit['eligible_priority']
    if not fit['eligible_candidate']:
        prior=dict(row.get('reply') or {})
        if prior.get('draft_text'):out['prior_draft_before_business_fit']=prior
        out['reply']=dict(prior,draft_text=None,status='commercial_fit_hold',business_fit_reasons=fit['exclusion_reasons']+fit['verification_required'],send_authorized=False)
        out['pending_candidate']=False
    return out
