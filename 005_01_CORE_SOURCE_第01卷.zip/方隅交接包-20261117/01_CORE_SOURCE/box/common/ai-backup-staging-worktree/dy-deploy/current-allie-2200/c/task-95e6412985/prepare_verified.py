"""Reserve a live-verified target; never sends network requests or browser actions."""
import sys,json,sqlite3,pathlib,hashlib,subprocess,datetime
cid,uid,video,evidence=sys.argv[1:5]
prepared_sha=sys.argv[5] if len(sys.argv)==6 else None
if not prepared_sha:
 from commercial_gate import verify_current
 verify_current(cid)
p=pathlib.Path(__file__).parent
assert (p/'captcha-recovery-authorization.json').exists()
db=sqlite3.connect('work/shared-acquisition-ledger/shared.sqlite3')
approved=set(json.loads((p/'captcha-recovery-authorization.json').read_text(encoding='utf-8-sig')).get('preserve_unknown_comments',[]))
blockers=db.execute("select comment,status from reservations where platform='douyin' and token like 'douyin-local-20261104-95e6412985-%' and status in ('unknown','reserved')").fetchall()
assert not any(status!='unknown' or cid not in approved for cid,status in blockers),'Unresolved outcome blocks further sending'

c=sqlite3.connect('Codex获客工作台/work/reply_receipts.sqlite3')
assert not c.execute('select status from sends where uid=? or cid=?',(uid,cid)).fetchall(),'Existing receipt'
if prepared_sha:
 from batch_reply_runner import ACCOUNT, digest, load
 manifest=load(p/'approved-cli-queue.json')
 assert manifest.get('prepared_by')=='douyin-classification-ready-v1'
 assert manifest.get('authorized') is True and manifest.get('account_uid')==ACCOUNT
 payload=json.dumps(manifest['items'],ensure_ascii=False,sort_keys=True,separators=(',',':'))
 assert prepared_sha==manifest['items_sha256']==digest(payload),'Sending queue changed'
 item=next(item for item in manifest['items'] if item['cid']==cid and item['uid']==uid and item['video']==video)
 assert item['reply_sha256']==digest(item['draft'])
 r=dict(comment_id=cid,comment_text=item['text'],reply={'draft_text':item['draft']},
        reply_body_sha256=item['reply_sha256'],original_reply_body_sha256=item['original_reply_sha256'],
        published_at=item['created'],reply_priority=item['reply_priority'],
        source_output_sha256=manifest['source_output_sha256'],priority_queue_sha256=manifest['priority_queue_sha256'])
else:
 r=next(json.loads(l) for l in open(p/'tone-approved-source.jsonl',encoding='utf-8') if json.loads(l).get('comment_id')==cid)
 assert hashlib.sha256(r['reply']['draft_text'].encode()).hexdigest()==r['reply_body_sha256']
 assert not r['reply'].get('contact_hold') and not r.get('needs_currentness_review')
 r['original_reply_body_sha256']=r['reply_body_sha256']
 r['original_draft_text']=r['reply']['draft_text']
 r['reply']['draft_text']=r['reply']['draft_text'].replace('我介绍有优惠','介绍有优惠').replace('介绍有优惠','我介绍有优惠')
 r['reply_body_sha256']=hashlib.sha256(r['reply']['draft_text'].encode()).hexdigest()
 r['wording_authorization']='User 2026-11-02: add 我, use 我介绍有优惠; retain sent history'

# Frozen send batches can outlive the local budget rules. Screen the original
# comment again before creating any reservation or attempt file.
sys.path.insert(0, str(p.parent / 'fangyu-text-business-20261029/business-fit'))
from business_fit import screen
classification_status=json.loads((p.parent/'fangyu-douyin-independent/classification-handoff-status.json').read_text(encoding='utf-8-sig'))
with pathlib.Path(classification_status['output']).open(encoding='utf-8-sig') as current_source:
 current_record=next((record for record in map(json.loads,current_source) if record.get('comment_id')==cid),None)
if not current_record or current_record.get('comment_text')!=r['comment_text']:
 raise RuntimeError('最新分类无法对应原评论，需刷新发布队列')
if not screen(current_record)['eligible_candidate']:
 raise RuntimeError('最新版筛选拦截：原评论预算或来源帖子条件未通过，需用最新队列续发')

token='douyin-local-20261104-95e6412985-20261102-'+cid
r.update(customer_uid=uid,video_id=video,attempt_id=token,status='prepared',authorized=True,account_uid='<REDACTED_ACCOUNT>',automatic_retry=False)
assert not db.execute("select 1 from reservations where platform='douyin' and (customer=? or comment=?)",(uid,cid)).fetchone(),'Existing shared reservation'
assert not (p/(cid+'.json')).exists(),'Existing attempt file'
(p/(cid+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
a=p/(cid+'-assessment.json')
a.write_text(json.dumps(dict(source=evidence,intent='rental',store='方隅公寓',match='match',pending='',draft=r['reply']['draft_text'],peer_reply='none'),ensure_ascii=False),encoding='utf-8')
base=[sys.executable,'work/shared-acquisition-ledger/ledger.py','--db','work/shared-acquisition-ledger/shared.sqlite3']
for args in [['identity-bind','douyin',uid,uid,evidence],['lead','douyin',uid,cid],['assess','douyin',uid,cid,str(a)],['review','douyin',uid,cid,'codex',evidence],['reserve','douyin',uid,cid,token]]:
 out=subprocess.check_output(base+args,text=True,encoding='utf-8')
 if args[0]=='reserve':assert json.loads(out)['granted']
print(json.dumps({'reserved':True,'cid':cid,'draft':r['reply']['draft_text']},ensure_ascii=False))
