"""Stop only Douyin sends while the user has a hold in effect."""
import json
from pathlib import Path


WORK = Path(__file__).resolve().parents[1]
LOCAL_HOLD = WORK / 'douyin-local-control/douyin-send-hold.json'
SHARED_ENTRY = WORK / 'fangyu-text-business-20261029/各账号窗口统一回复入口.json'


def hold_reason(local_hold=None, shared_entry=None):
    local_hold = LOCAL_HOLD if local_hold is None else Path(local_hold)
    shared_entry = SHARED_ENTRY if shared_entry is None else Path(shared_entry)
    try:
        if local_hold.exists():
            hold = json.loads(local_hold.read_text(encoding='utf-8-sig'))
            if hold.get('blocked') is True:
                return hold.get('reason') or '抖音发送已暂停'
        if shared_entry.exists():
            entry = json.loads(shared_entry.read_text(encoding='utf-8-sig'))
            hold = entry.get('user_send_hold') or {}
            if hold.get('platform') == 'douyin' and (hold.get('active') is True or hold.get('new_sends_allowed') is False):
                return hold.get('reason') or '抖音发送已暂停'
    except (OSError, ValueError, AttributeError):
        return '无法核验抖音发送暂停状态，暂缓发送'
    return None


def require_send_allowed(local_hold=None, shared_entry=None):
    reason = hold_reason(local_hold, shared_entry)
    if reason:
        raise RuntimeError(reason)
