"""Authorized local serial runner. No collection, no automatic retry, no UI driver."""
import argparse
from contextlib import closing
import datetime as dt
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'work/douyin-local-control'))
from send_hold import require_send_allowed
DB = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
LEDGER = ROOT / 'work/shared-acquisition-ledger/ledger.py'
POOL = HERE / 'tone-approved-source.jsonl'
NODE = ROOT / 'work/runtime/douyin-bridge/node.exe'
ADAPTER = HERE / 'send_cli_once.cjs'
QUEUE = HERE / 'approved-cli-queue.json'
ACCOUNT = '<REDACTED_ACCOUNT>'
PREFIX = 'douyin-local-20261104-95e6412985-'
LIMIT = None  # User 2026-11-02 removed the 200-success ceiling.

def now():
    return dt.datetime.now().astimezone().isoformat()

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, data):
    # status_replace_retry_v1: Windows readers may briefly hold the target open.
    import tempfile
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out, ensure_ascii=False, indent=2)
        for attempt in range(20):
            try:
                os.replace(name, path)
                return
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        if os.path.exists(name):
            os.unlink(name)

def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def wording(text):
    return text.replace('我介绍有优惠', '介绍有优惠').replace('介绍有优惠', '我介绍有优惠')

def ledger_rows(db=DB):
    with closing(sqlite3.connect(db.as_uri() + '?mode=ro', uri=True, timeout=5)) as c:
        c.row_factory = sqlite3.Row
        return [dict(r) for r in c.execute("SELECT * FROM reservations WHERE platform='douyin'")]

def guard(rows):
    auth_path = HERE / 'captcha-recovery-authorization.json'
    approved = set(load(auth_path).get('preserve_unknown_comments', [])) if auth_path.exists() else set()
    blockers = [r for r in rows if r['token'].startswith(PREFIX) and r['status'] in ('unknown', 'reserved') and not (r['status']=='unknown' and r['comment'] in approved)]
    if blockers:
        raise RuntimeError('存在结果未知或未核验记录，禁止继续，也不会自动重发：' + ', '.join(r['comment'] for r in blockers))
    # Fixed authorization batch persists over midnight; never reset by today's date.
    used = sum(r['token'].startswith(PREFIX) and r['status']=='sent' for r in rows)
    return used

def run_json(args, timeout=180):
    child_env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    result = subprocess.run([str(x) for x in args], cwd=ROOT, capture_output=True,
                            text=True, encoding='utf-8', timeout=timeout, env=child_env,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        value = json.loads((result.stdout or '').strip().splitlines()[-1])
    except (ValueError, IndexError):
        save(HERE / 'subprocess-failure.json', {'at':now(), 'program':Path(str(args[1])).name if len(args)>1 else str(args[0]), 'returncode':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr})
        raise RuntimeError('子程序失败，详细证据已保存：' + (result.stderr or result.stdout or 'empty output')[-1000:])
    return value

def validate_queue(manifest, pool=None):
    if manifest.get('authorized') is not True or manifest.get('account_uid') != ACCOUNT:
        raise RuntimeError('本批批准快照尚未就绪或账号不匹配')
    items = manifest.get('items', [])
    payload = json.dumps(items, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    if manifest.get('items_sha256') != digest(payload):
        raise RuntimeError('批准快照校验失败')
    seen_cid, seen_uid = set(), set()
    for item in items:
        cid, uid, video = (item.get(k, '') for k in ('cid', 'uid', 'video'))
        if not all(isinstance(v, str) and v.isdigit() for v in (cid, uid, video)):
            raise RuntimeError('批准快照缺少精确评论、作者或视频编号')
        if cid in seen_cid or uid in seen_uid:
            raise RuntimeError('批准快照包含重复客户或评论')
        seen_cid.add(cid); seen_uid.add(uid)
        if pool is None:
            if not item.get('draft') or item.get('reply_sha256') != digest(item['draft']):
                raise RuntimeError('发送清单正文校验失败')
            continue
        source = pool[cid]
        original = source['reply']['draft_text']
        if source.get('pending_candidate') is not True or source.get('commercial_fit',{}).get('eligible_candidate') is not True:
            raise RuntimeError('新版商业适配未允许该候选')
        if digest(original) != source['reply_body_sha256']:
            raise RuntimeError('原批准草稿校验失败')
        if item.get('original_reply_sha256') != source['reply_body_sha256'] or item.get('reply_sha256') != digest(item.get('draft', '')):
            raise RuntimeError('逐条草稿指纹不一致')
        if source['reply'].get('contact_hold') or source.get('needs_currentness_review'):
            raise RuntimeError('快照包含尚未解除的内容阻断')
        if item.get('draft') != wording(original) or item.get('text') != source['comment_text']:
            raise RuntimeError('批准快照与原评论或最新语气不一致')
    return items

def cli_success(receipt, item):
    return bool(receipt.get('cid') and receipt.get('status_code') == 0
        and receipt.get('text') == item['draft'] and receipt.get('sec_uid') == ACCOUNT
        and str(receipt.get('reply_id')) == item['cid'])

def record_outcome(task, status, result):
    evidence = json.dumps(result, ensure_ascii=False, separators=(',', ':'))
    answer = run_json([sys.executable, LEDGER, '--db', DB, 'outcome', task['attempt_id'], status, evidence])
    actual = next(r for r in ledger_rows() if r['token'] == task['attempt_id'])
    if actual['status'] != status:
        raise RuntimeError('共享账本回执确认失败；停止，禁止重发')
    task.update(status='sent_cli_success' if status == 'sent' else status,
                verified_at=now(), receipt_evidence=evidence, automatic_retry=False,
                elapsed_seconds=result.get('elapsed_seconds'))
    save(HERE / (task['comment_id'] + '.json'), task)
    with (HERE / '发送回执记录.txt').open('a',encoding='utf-8') as log:
        log.write(f"{now()} | 账号：北斗Enzo | 目标评论：{task['comment_id']} | 结果：{status} | 回复：{task['reply']['draft_text']} | 平台回复编号：{(result.get('receipt') or {}).get('cid','未返回')}\n")
    save(HERE / 'batch-runner-status.json', {'updated_at': now(), 'last_comment': task['comment_id'],
         'status': status, 'confirmed_sent': sum(r['token'].startswith(PREFIX) and r['status']=='sent' for r in ledger_rows()),
         'limit': LIMIT, 'process_id': os.getpid(), 'elapsed_seconds': result.get('elapsed_seconds')})

def execute(check_only=False, max_new=None):
    if not check_only:
        require_send_allowed()
    rows = ledger_rows()
    used = guard(rows)
    print(f'持续处理已批准队列；账本累计成功 {used} 条；无200条上限。', flush=True)
    if LIMIT is not None and used >= LIMIT:
        print('已达到本批上限，不再发送。'); return
    if check_only:
        print('只读检查完成，没有启动发送。'); return
    manifest = load(QUEUE)
    prepared = manifest.get('prepared_by') == 'douyin-classification-ready-v1'
    pool = None
    if not prepared:
        pool = {r['comment_id']: r for r in (json.loads(line) for line in POOL.read_text(encoding='utf-8-sig').splitlines() if line.strip())}
    items = validate_queue(manifest, pool)
    if not items:
        reason = '上游发送清单已处理完毕。'
        print(reason, flush=True)
        save(HERE / 'batch-runner-status.json', {'status': 'queue_empty', 'reason': reason,
             'confirmed_sent': used, 'updated_at': now(), 'process_id': os.getpid()})
        return
    identity = run_json([NODE, ADAPTER, '--identity'])
    if identity.get('verified') is not True or identity.get('account_uid') != ACCOUNT:
        raise RuntimeError('当前账号未核验或账号不匹配，已停止')
    new_sent = 0
    read_timeout_skips = 0
    unavailable_this_run = set()
    if not prepared:
        from time_priority import live_ordered
        items = live_ordered(items, enforce_review_gap=True)
    for item in items:
        excluded_path = HERE / 'unavailable-targets.json'
        excluded = load(excluded_path) if excluded_path.exists() else {}
        if item['cid'] in excluded.get('comments', {}) or item['video'] in unavailable_this_run:
            continue  # Evidence-backed exclusions only; retain original queue and receipts.
        if max_new is not None and new_sent >= max_new:
            print('本次限定恢复测试完成；未启动其余队列。', flush=True)
            return
        rows = ledger_rows()
        used = guard(rows)
        if LIMIT is not None and used >= LIMIT:
            print('本批累计200条，已停止。'); return
        require_send_allowed()
        if (HERE / 'batch-stop.json').exists():
            raise RuntimeError('已收到本批停止标记')
        if any(r['comment'] == item['cid'] or r['customer'] == item['uid'] for r in rows):
            continue  # Includes explicit not_sent: never automatically retry.
        attempt_path = HERE / (item['cid'] + '.json')
        if attempt_path.exists() or Path(str(attempt_path) + '.submitted').exists():
            raise RuntimeError('存在历史尝试文件，必须核查后再继续，禁止重发：' + item['cid'])
        evidence = 'Approved local source snapshot; ' + manifest['items_sha256']
        if manifest.get('live_preflight', False):
            save(HERE / 'batch-runner-status.json', {
                 'status': 'checking_target', 'reason': '正在读取下一目标；不可见的目标会跳过。',
                 'updated_at': now(), 'confirmed_sent': used, 'process_id': os.getpid()})
            from read_recovery import recover_preflight
            def report_recovery(message):
                print(message, flush=True)
                save(HERE / 'batch-runner-status.json', {'status': 'reconnecting', 'reason': message,
                     'confirmed_sent': used, 'updated_at': now(), 'process_id': os.getpid()})
            preflight = recover_preflight(HERE, ACCOUNT,
                lambda: run_json([NODE, ADAPTER, '--preflight', item['video'], item['cid']]),
                require_send_allowed, report_recovery)
            check = preflight.get('diagnosis') or {}
        else:
            check = {'verification_basis': 'approved_upstream_queue', 'live_target_check_performed': False}
        if prepared:
            priority = item['reply_priority']
            priority_evidence = {'reply_priority': priority, 'original_time': item['created'],
                'time_band': priority['time_band'], 'priority_key': priority['key'],
                'source_sha256': manifest['source_output_sha256'], 'queue_sha256': manifest['priority_queue_sha256']}
        else:
            priority_evidence = item['_priority_evidence']
        selection = dict(priority_evidence, at=now(), account=ACCOUNT, cid=item['cid'],
                         runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         video_id=item['video'], target_check=check,
                         stage='selected_after_ledger_before_live_commercial_reserve')
        with (HERE/'selection-evidence.jsonl').open('a',encoding='utf-8') as evidence_log:
            evidence_log.write(json.dumps(selection,ensure_ascii=False)+'\n')
        save(HERE/'next-selection.json',selection)
        print(f"选取原评论日期：{selection['original_time']} ｜ {selection['time_band']}；已按时间档、预算、意愿排序。", flush=True)
        if manifest.get('live_preflight', False):
            if check.get('read_timeout'):
                read_timeout_skips += 1
                with (HERE / 'target-read-skips.jsonl').open('a', encoding='utf-8') as log:
                    log.write(json.dumps({'at': now(), 'cid': item['cid'], 'video': item['video'],
                        'diagnosis': check, 'submission_attempted': False}, ensure_ascii=False) + '\n')
                print('本条只读请求暂未返回，尚未提交；继续下一条。', flush=True)
                continue
            if preflight.get('status') != 'target_check' or check.get('detail_status') != 0:
                raise RuntimeError(preflight.get('error') or '平台目标核验未完成，请检查页面提示。')
            if check.get('no_video_detail') is True:
                unavailable_this_run.add(item['video'])
                print('本轮未取到视频详情，暂跳过该视频的候选。', flush=True)
                continue
            if check.get('video_present') is not True or check.get('comments_status') != 0:
                raise RuntimeError('目标视频或评论列表无法核验，已停止发送')
            if check.get('target_present') is not True:
                if check.get('incomplete') and check.get('comments_status', 0) == 0:
                    read_timeout_skips += 1
                    with (HERE / 'target-read-skips.jsonl').open('a', encoding='utf-8') as log:
                        log.write(json.dumps({'at': now(), 'cid': item['cid'], 'video': item['video'],
                            'diagnosis': check, 'submission_attempted': False}, ensure_ascii=False) + '\n')
                    print('本条只读分页暂未完成，进度已保存，暂跳过并继续下一条。', flush=True)
                    continue
                if check.get('has_more') == 0 and check.get('target_present') is False:
                    excluded.setdefault('comments', {})[item['cid']] = {
                        'reason': 'Target absent from exhausted comment list before submission',
                        'diagnosis': check, 'at': now(), 'submission_attempted': False}
                    save(excluded_path, excluded)
                    print('完整评论列表未找到该目标，已记录并跳过，继续下一条。', flush=True)
                    continue
                raise RuntimeError('目标评论核验未完成，已停止发送')
        require_send_allowed()
        args = [sys.executable, HERE / 'prepare_verified.py', item['cid'], item['uid'], item['video'], evidence]
        if prepared:
            args.append(manifest['items_sha256'])
        reserved = run_json(args)
        if reserved.get('reserved') is not True:
            raise RuntimeError('共享账本预留失败')
        task = load(attempt_path)
        if task['reply']['draft_text'] != item['draft'] or task['account_uid'] != ACCOUNT:
            raise RuntimeError('预留内容与批准快照不一致，保持预留阻断')
        task.update(submission_intent_at=now(), status='submission_intent', automatic_retry=False,
                    approved_snapshot_sha256=manifest['items_sha256'])
        save(attempt_path, task)
        save(HERE / 'batch-runner-status.json', {'status': 'publishing', 'reason': '正在提交下一条并等待平台回执。',
             'confirmed_sent': used, 'updated_at': now(), 'process_id': os.getpid()})
        print(f'正在处理第 {used + 1} 条：{item["text"]}', flush=True)
        started = time.monotonic()
        try:
            result = run_json([NODE, ADAPTER, attempt_path])
        except BaseException as exc:
            result = {'status': 'unknown', 'error': str(exc), 'automatic_retry': False}
        result['elapsed_seconds'] = round(time.monotonic() - started, 3)
        status = result.get('status')
        receipt = result.get('receipt') or {}
        if status == 'sent' and not cli_success(receipt, item):
            status = 'unknown'
            result['receipt_validation_error'] = True
        if status not in ('sent', 'unknown', 'not_sent'):
            status = 'unknown'
        result['status'] = status
        save(HERE / (item['cid'] + '-cli-receipt.json'), result)
        marker = Path(str(attempt_path) + '.submitted')
        if marker.exists():
            task['submitted_at'] = marker.read_text(encoding='utf-8').strip()
        record_outcome(task, status, result)
        if status != 'sent':
            from publish_recovery import preserve_unavailable
            if status == 'unknown' and preserve_unavailable(HERE, item['cid'], result):
                print('本条未取得成功回执且视频详情不可用；保留未知记录、不重发，继续下一条。', flush=True)
                continue
            if status == 'not_sent' and result.get('skip_target') is True:
                d = result.get('diagnosis') or {}
                if d.get('detail_status') == 0 and d.get('comments_status') == 0 and d.get('has_more') == 0 and d.get('target_present') is False:
                    excluded = load(excluded_path) if excluded_path.exists() else {}
                    group, key = 'comments', item['cid']  # Never extrapolate one failed target to its entire video.
                    excluded.setdefault(group, {})[key] = {'reason': 'Rejected publish; target absent from complete current result', 'diagnosis': d, 'at': now()}
                    save(excluded_path, excluded)
                    print('SKIPPED，目标当前不可见，已留账；继续下一条。', flush=True)
                    continue
            print('UNKNOWN' if status == 'unknown' else 'FAILED', result.get('error', ''), flush=True)
            raise RuntimeError('已保存CLI返回结果并停止；不会自动重发')
        print(f'SUCCESS，已同步共享账本：{used + 1}；本条提交与回执耗时 {result["elapsed_seconds"]:.1f} 秒', flush=True)
        new_sent += 1
    print('本轮已批准队列处理完毕。', flush=True)
    if prepared:
        save(HERE / 'batch-runner-status.json', {'status': 'queue_partial' if read_timeout_skips else 'queue_complete',
             'reason': (f'本轮新增成功回执 {new_sent} 条；{read_timeout_skips} 条只读超时未提交，下次启动可再读取。' if read_timeout_skips else f'本轮近期队列已处理完毕，新增成功回执 {new_sent} 条。'),
             'confirmed_sent': sum(r['token'].startswith(PREFIX) and r['status']=='sent' for r in ledger_rows()),
             'updated_at': now(), 'process_id': os.getpid()})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--max-new', type=int, default=None)
    args = parser.parse_args()
    if args.max_new is not None and args.max_new < 1:
        parser.error('--max-new must be positive')
    with (HERE / 'batch-runner.lock').open('a+b') as lock:
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise RuntimeError('本批程序已经运行，请勿重复启动')
        try:
            execute(args.check_only, args.max_new)
        finally:
            lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)

if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    try:
        main()
    except Exception as exc:
        print('已停止：' + str(exc), flush=True)
        save(HERE / 'batch-runner-status.json', {'status': 'blocked', 'reason': str(exc),
             'updated_at': now(), 'limit': LIMIT, 'process_id': os.getpid(), 'automatic_retry': False, 'confirmed_sent': sum(r['token'].startswith(PREFIX) and r['status']=='sent' for r in ledger_rows())})
        sys.exit(1)
