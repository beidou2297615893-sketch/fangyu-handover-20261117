import datetime, hashlib, json, os, sqlite3, subprocess, sys
try:
 import msvcrt
except ModuleNotFoundError:
 msvcrt = None  # Windows file locks; non-Windows hosts can still import the controller for tests.
from contextlib import closing
from pathlib import Path
from send_hold import hold_reason, require_send_allowed
from startup_recovery import ensure_adapter_file, ensure_local_bridge, upgrade_task
import time
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
T=ROOT/'work/douyin-round2-task5'
NODE=ROOT/'work/runtime/douyin-bridge/node.exe'
ENV=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');t.replace(p)
def probe(timeout=None):
 r=subprocess.run([str(NODE),str(P/'account_probe.cjs')],capture_output=True,text=True,encoding='utf-8',env=ENV,creationflags=subprocess.CREATE_NO_WINDOW,timeout=timeout)
 d=json.loads(r.stdout.strip().splitlines()[-1])
 if d.get('error'):raise RuntimeError(d['error'])
 return d
def connect_for_start(probe_fn=None, ensure_fn=None, sleep_fn=None):
 probe_fn=probe_fn or probe
 ensure_fn=ensure_fn or ensure_local_bridge
 sleep_fn=sleep_fn or time.sleep
 for attempt in range(2):
  ensure_fn()
  try:
   return probe_fn(timeout=25)
  except (RuntimeError,subprocess.TimeoutExpired) as exc:
   message=str(exc)
   transient=isinstance(exc,subprocess.TimeoutExpired) or any(word in message for word in
       ('未找到可用的已登录抖音连接','Request timeout','ECONNREFUSED','fetch failed','HTTP request failed'))
   if not transient:raise
   if attempt:
    raise RuntimeError('本地连接已检查，抖音页面仍未响应。请刷新已登录的抖音页面后点启动／继续；没有提交新评论。') from exc
   sleep_fn(2)
def prepare(identity):
 uid=identity['account_uid']
 registry=load(P/'accounts.json') if (P/'accounts.json').exists() else {}
 if uid in registry:
  task=Path(registry[uid])
 else:
  name='douyin-local-'+datetime.datetime.now().strftime('%Y%m%d')+'-'+hashlib.sha256(uid.encode()).hexdigest()[:10]
  task=ROOT/'work'/name;task.mkdir(exist_ok=False)
  olduid='<REDACTED_ACCOUNT>'
  files=['batch_reply_runner.py','prepare_verified.py','send_cli_once.cjs','target-diagnosis.cjs','commercial_gate.py','time_priority.py','resume_after_confirmation.py','publish-pacing.json','tone-approved-source.jsonl','approved-cli-queue.json']
  for filename in files:
   source=(T/filename).read_text(encoding='utf-8-sig')
   if filename.endswith(('.py','.cjs')):
    source=source.replace(olduid,uid).replace('douyin-round2-task5',name).replace('北斗Enzo（RMsama）',identity['nickname'])
   (task/filename).write_text(source,encoding='utf-8')
  q=load(task/'approved-cli-queue.json');q['account_uid']=uid;q['authorization']='User 2026-11-04: local start button for current verified account; existing approved wording and live screening';save(task/'approved-cli-queue.json',q)
  save(task/'continuation-state.json',{'status':'authorized','unknown':0})
  save(task/'captcha-recovery-authorization.json',{'preserve_unknown_comments':[],'events':[]})
  registry[uid]=str(task);save(P/'accounts.json',registry)
 save(task/'cli-current-binding.json',identity)
 save(P/'active.json',dict(identity,task=str(task)))
 return task

def acknowledge_repaired_pause(task):
 # This function is only reached from an explicit Start/Continue invocation.
 # Keep the stop marker on disk until that invocation; never auto-resume.
 marker=task/'batch-stop.json'
 if not marker.exists():return
 pause=load(marker)
 completed_sort_pause=(pause.get('source')=='user_via_cli_handoff'
                       and pause.get('at','').startswith('2026-11-04')
                       and pause.get('reason')=='按用户要求暂停全部抖音发送，等待近期优先规则修复并通过离线验证'
                       and load(task/'approved-cli-queue.json').get('prepared_by')=='douyin-classification-ready-v1')
 if not completed_sort_pause and (pause.get('user_pause') is not True or pause.get('ready_for_user_resume') is not True):
  raise RuntimeError('任务仍有停止标记，请先处理停止原因')
 history=task/'pause-resume-events.jsonl'
 with history.open('a',encoding='utf-8') as log:
  log.write(json.dumps({'at':datetime.datetime.now().astimezone().isoformat(),
      'action':'explicit_start_after_priority_fix','pause':pause},ensure_ascii=False)+'\n')
 marker.unlink()

def preserve_previous_unknown(task):
 # An explicit start continues at the next target, keeping every old outcome.
 prefix=task.name+'-'
 database=ROOT/'work/shared-acquisition-ledger/shared.sqlite3'
 with closing(sqlite3.connect(database.as_uri()+'?mode=ro',uri=True,timeout=5)) as db:
  rows=db.execute("SELECT comment,status FROM reservations WHERE platform='douyin' AND substr(token,1,?)=? AND status IN ('reserved','unknown')",
                  (len(prefix),prefix)).fetchall()
 auth_path=task/'captcha-recovery-authorization.json'
 auth=load(auth_path)
 from unknown_resolution import receipt_blocks_queue
 preserved=auth.get('preserve_unknown_comments',[])
 isolated=auth.get('isolated_unknown_comments',[])
 for cid,status in rows:
  block=receipt_blocks_queue(status, cid, preserved, isolated)
  if block=='reserved':
   raise RuntimeError('仍有未完成的发送预留，请先核对结果')
  if block=='unknown':
   raise RuntimeError('仍有未经完整只读核对的未知记录，已停止。没有继续发送。')

def check_resume():
    """Read the current account, ledger, and queue head without starting a sender."""
    identity = probe(timeout=25)
    nickname = identity['nickname']
    registry = load(P / 'accounts.json') if (P / 'accounts.json').exists() else {}
    task_path = registry.get(identity['account_uid'])
    if not task_path:
        return f'{nickname} 已登录，等待该账号的发送任务准备完成。'
    task = Path(task_path).resolve()
    if not task.is_relative_to(ROOT / 'work'):
        raise RuntimeError('账号的任务目录无法核验')
    sys.path.insert(0, str(task))
    import batch_reply_runner as runner
    import time_priority
    if runner.ACCOUNT != identity['account_uid']:
        raise RuntimeError('当前账号与任务账号不一致')
    blocked_by_receipt = False
    try:
        runner.guard(runner.ledger_rows())
    except RuntimeError:
        blocked_by_receipt = True
    manifest = runner.load(runner.QUEUE)
    prepared = manifest.get('prepared_by') == 'douyin-classification-ready-v1'
    if prepared:
        next_item = next(iter(time_priority.unattempted_items(manifest['items'], runner.ledger_rows(), {})), None)
    else:
        next_item = next(time_priority.live_ordered(manifest['items'], enforce_review_gap=True), None)
    if next_item is None:
        result = '当前批准队列没有剩余候选。'
    else:
        if not prepared:
            from commercial_gate import verify_current
            verify_current(next_item['cid'])
        response = runner.run_json([runner.NODE, runner.ADAPTER, '--preflight',
                                    next_item['video'], next_item['cid'], identity['connection_id']], timeout=35)
        target = response.get('diagnosis') or {}
        if target.get('no_video_detail') is True:
            result = '抖音未返回队首的视频详情。'
        elif response.get('status') == 'target_check' and target.get('video_present') is True and target.get('target_present') is True:
            result = '队首的视频和评论已核对。'
        else:
            result = '队首的视频或评论还无法核对。'
    pending = ' 有已提交但回执未知的记录。点启动／继续会先只读核对；核对不完整的那一条保持未知并跳过，验证码或账号不符会停线。' if blocked_by_receipt else ''
    return f'{nickname} 已连接。{result}{pending}'

def foreign_runner_locked():
 for other in (ROOT/'work').glob('douyin-*/batch-runner.lock'):
  with other.open('a+b') as existing:
   existing.seek(0)
   try:msvcrt.locking(existing.fileno(),msvcrt.LK_NBLCK,1)
   except OSError:return True
   existing.seek(0);msvcrt.locking(existing.fileno(),msvcrt.LK_UNLCK,1)
 return False

def load_task_runner(task):
 import importlib.util
 name='douyin_task_runner_'+hashlib.sha256(str(task).encode()).hexdigest()[:12]
 spec=importlib.util.spec_from_file_location(name, task/'batch_reply_runner.py')
 module=importlib.util.module_from_spec(spec)
 spec.loader.exec_module(module)
 return module

def task_lock_state(root=None, open_lock=None):
 """'free', 'busy', or 'unknown'. Never creates a batch-runner.lock."""
 from unknown_resolution import inspect_task_locks
 root=root or (ROOT/'work')
 try:
  paths=[path for path in root.glob('douyin-*/batch-runner.lock') if path.is_file()]
 except OSError:
  return 'unknown'
 return inspect_task_locks(paths, open_lock or _lock_existing)

def _lock_existing(path):
 flags=os.O_RDWR
 try:fd=os.open(path, flags)
 except FileNotFoundError:return 'free'
 except OSError:return 'unknown'
 try:
  if msvcrt is not None:
   try:msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
   except OSError:return 'busy'
   msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
   return 'free'
  import fcntl
  try:fcntl.flock(fd, fcntl.LOCK_EX|fcntl.LOCK_NB)
  except OSError:return 'busy'
  fcntl.flock(fd, fcntl.LOCK_UN)
  return 'free'
 except OSError:
  return 'unknown'
 finally:
  os.close(fd)

def prepare_resolution(identity, task, lock_state=None):
 """Load the ledger view and the read-only verifier. Does not publish."""
 from unknown_resolution import build_verify_command, classify_diagnostic, diagnosis_from_cli
 runner=load_task_runner(task)
 auth_path=task/'captcha-recovery-authorization.json'
 auth=load(auth_path) if auth_path.exists() else {'preserve_unknown_comments':[],'events':[]}
 def marker_text(cid):
  marker=task/f'{cid}.json.submitted'
  if not marker.exists():return None
  text=marker.read_text(encoding='utf-8',errors='replace').strip()
  return text or str(marker.stat().st_mtime)
 def receipt_for(cid):
  path=task/f'{cid}-cli-receipt.json'
  if not path.exists():return {}
  try:return load(path)
  except (OSError,ValueError):return {}
 def attempt_for(cid):
  path=task/f'{cid}.json'
  if not path.exists():return None
  try:return load(path)
  except (OSError,ValueError):return None
 rows=runner.ledger_rows()
 submitted, receipts, attempts = {}, {}, {}
 for row in rows:
  if not str(row.get('token') or '').startswith(runner.PREFIX):continue
  cid=str(row.get('comment') or '')
  if not cid:continue
  stamp=marker_text(cid)
  if stamp:submitted[cid]=stamp
  receipts[cid]=receipt_for(cid)
  attempt=attempt_for(cid)
  if attempt is not None:attempts[cid]=attempt
 stop=load(task/'batch-stop.json') if (task/'batch-stop.json').exists() else None
 def read_reply(item, attempt, ensure_adapter=True):
  def failed(stage, hint, stderr, value=None):
   return {'own_reply_state':'unchecked','reason':'verify_failed','submission_attempted':False,
           'diagnostic':classify_diagnostic(stage, hint, stderr, value)}
  adapter=task/'send_cli_once.cjs'
  if ensure_adapter:
   try:ensure_adapter_file(task)
   except OSError as exc:return failed('adapter', type(exc).__name__, '')
  source=adapter.read_text(encoding='utf-8-sig') if adapter.exists() else ''
  if '--verify-own-reply' not in source:return failed('adapter', 'VerifyModeMissing', '')
  video=(attempt or {}).get('video_id') or ''
  try:command=build_verify_command(runner.NODE, adapter, video, item['cid'])
  except RuntimeError:return failed('command', 'missing_param', '')
  try:
   child_env=dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
   kwargs=dict(cwd=ROOT, capture_output=True, text=True, encoding='utf-8', timeout=90, env=child_env)
   if os.name=='nt':kwargs['creationflags']=subprocess.CREATE_NO_WINDOW
   completed=subprocess.run([str(x) for x in command], **kwargs)
  except subprocess.TimeoutExpired as exc:
   err=exc.stderr.decode('utf-8','replace') if isinstance(exc.stderr, bytes) else (exc.stderr or '')
   return failed('cli_timeout', 'TimeoutExpired', err)
  except OSError as exc:
   return failed('cli_spawn', type(exc).__name__, '')
  try:value=json.loads((completed.stdout or '').strip().splitlines()[-1])
  except (ValueError, IndexError):value=None
  return diagnosis_from_cli(value, completed.stderr or '')
 if lock_state is None:
  runner_busy=foreign_runner_locked(); lock_uncertain=False
 else:
  lock_uncertain=lock_state!='free' and lock_state!='busy'
  runner_busy=lock_state=='busy' or lock_uncertain
 state={'identity_uid':identity.get('account_uid'),'runner_account':runner.ACCOUNT,
  'runner_busy':runner_busy,'lock_uncertain':lock_uncertain,'stop_marker':stop,'prefix':runner.PREFIX,
  'task':str(task),'rows':rows,'auth':auth,'submitted':submitted,'receipts':receipts,
  'attempts':attempts}
 return runner, auth_path, state, read_reply

def resolve_task_on_start(identity, task):
 """Read submitted unknowns before the approved queue. Does not start a sender."""
 from unknown_resolution import commit_resolution, resolve_on_start
 runner, auth_path, state, read_reply=prepare_resolution(identity, task)
 result=resolve_on_start(state, {'read_reply':lambda item, attempt: read_reply(item, attempt, True),
  'now':lambda:datetime.datetime.now().astimezone().isoformat()})
 if result.get('start_sender'):
  raise RuntimeError('核对流程不能自行启动发送')
 def record(task_body, evidence):
  if evidence.get('status')!='sent' or evidence.get('submission_attempted') is not False:
   raise RuntimeError('只读核对不能把上一笔写成未发送或重发')
  runner.record_outcome(task_body, 'sent', evidence)
 commit_resolution(result, {
  'record':record,
  'auth':lambda body:runner.save(auth_path, body),
  'status':lambda body:runner.save(task/'batch-runner-status.json', body),
 })
 return result

def diagnose_task_unknown(identity, task, lock_state):
 """Print one read-only report. No ledger, queue, submitted-marker, status, or comment write."""
 from unknown_resolution import diagnose_unknown
 if lock_state!='free':
  reason='runner_locked' if lock_state=='busy' else 'lock_uncertain'
  print(json.dumps({'action':'diagnose','blocked_reason':reason,'continue_queue':False,'wrote':False,
                    'records':[],'items':[]}, ensure_ascii=False))
  return {'action':'diagnose','blocked_reason':reason,'wrote':False,'records':[],'continue_queue':False}
 _runner, _auth_path, state, read_reply=prepare_resolution(identity, task, lock_state='free')
 result=diagnose_unknown(state, {'read_reply':lambda item, attempt: read_reply(item, attempt, False),
  'now':lambda:datetime.datetime.now().astimezone().isoformat()})
 print(json.dumps({'action':'diagnose','blocked_reason':result.get('blocked_reason'),'continue_queue':False,
  'wrote':False,'records':[],'items':result.get('items') or []}, ensure_ascii=False))
 return result

def main(expected_task=None, use_prepared_queue=False):
 from unknown_resolution import control_lock_result, diagnose_argv_action
 argv_action=diagnose_argv_action(sys.argv[1:])
 if argv_action=='reject':
  print(json.dumps({'action':'diagnose','blocked_reason':'bad_args','error_type':'other','stage':'gate',
                    'http_status':None,'cli_error_code':'other','continue_queue':False,'wrote':False,'records':[]},
                   ensure_ascii=False))
  return
 diagnose_only=argv_action=='diagnose'
 with (P/'control.lock').open('a+b') as lock:
  lock.seek(0)
  try:
   if msvcrt is None:raise OSError('control lock unavailable')
   msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
  except OSError:
   payload, write_status=control_lock_result(diagnose_only)
   print(json.dumps(payload, ensure_ascii=False))
   if write_status:
    save(P/'status.json', {'message':payload['blocked_reason'], 'blocked_reason':'control_lock'})
   return
  try:
   if sys.argv[1:] == ['--check-resume']:
    save(P/'status.json',{'mode':'resume_check','message':'正在重新检查账号和近期队首…'})
    try:
     message=check_resume()
    except subprocess.TimeoutExpired:
     message='重新检查超时。可在抖音页面加载完成后再点一次。'
    except Exception as e:
     message=f'重新检查未完成。{e}'
    if hold_reason():message+=' 发送仍暂停。'
    save(P/'status.json',{'mode':'resume_check','message':message})
    return
   if diagnose_only:
    try:
     lock_state=task_lock_state()
     if lock_state!='free':
      diagnose_task_unknown(None, None, lock_state)
      return
     identity=probe(timeout=25)
     registry=load(P/'accounts.json') if (P/'accounts.json').exists() else {}
     task_path=registry.get(identity.get('account_uid'))
     if not task_path:
      print(json.dumps({'action':'diagnose','blocked_reason':'no_items','continue_queue':False,'wrote':False,
                        'records':[],'items':[]}, ensure_ascii=False))
      return
     task=Path(task_path).resolve()
     if not task.is_relative_to(ROOT/'work'):
      raise RuntimeError('账号的任务目录无法核验')
     diagnose_task_unknown(identity, task, 'free')
    except Exception:
     print(json.dumps({'action':'diagnose','blocked_reason':'read_incomplete','error_type':'other','stage':'gate',
                       'http_status':None,'cli_error_code':'other','continue_queue':False,'wrote':False,'records':[]},
                      ensure_ascii=False))
    return
   require_send_allowed()
   save(P/'status.json',{'message':'正在核对当前账号…'})
   if foreign_runner_locked():
    raise RuntimeError('已有回复任务运行中，请先等待当前任务停止')
   save(P/'status.json',{'message':'正在准备本地连接；连接短暂异常会自动重查…'})
   identity=connect_for_start()
   if expected_task is not None:
    registered=load(P/'accounts.json').get(identity['account_uid'])
    if not registered or Path(registered).resolve()!=expected_task.resolve():
     raise RuntimeError('当前登录账号与要继续的任务不匹配')
   task=prepare(identity)
   upgrade_task(task)
   save(P/'status.json',{'message':'上游正在生成已排序的发送清单…','account':identity['nickname']})
   producer=ROOT/'work/fangyu-text-business-20261029/recency-priority/publish_douyin_send_queue.py'
   result=subprocess.run([sys.executable,str(producer),str(task)],cwd=ROOT,env=ENV,
                         capture_output=True,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
   if result.returncode:
    raise RuntimeError(result.stderr.strip().splitlines()[-1] if result.stderr else '上游发送清单生成失败')
   acknowledge_repaired_pause(task)
   save(P/'status.json',{'message':'正在只读核对已提交的未知记录…','account':identity['nickname']})
   resolution=resolve_task_on_start(identity, task)
   if not resolution.get('continue_queue'):
    save(P/'status.json',{'message':resolution['summary'],'account':identity['nickname']})
    return
   preserve_previous_unknown(task)
   from unknown_resolution import runner_script_after_resolution
   state=load(task/'batch-runner-status.json') if (task/'batch-runner-status.json').exists() else {}
   script=runner_script_after_resolution(resolution, state.get('status'))
   if not script:
    save(P/'status.json',{'message':resolution['summary'],'account':identity['nickname']})
    return
   save(P/'status.json',{'message':'本地任务运行中','account':identity['nickname']})
   with (task/'runner-stdout.log').open('a',encoding='utf-8') as out,(task/'runner-stderr.log').open('a',encoding='utf-8') as err:
    subprocess.run([sys.executable,'-u',str(task/script)],cwd=ROOT,stdout=out,stderr=err,env=ENV,creationflags=subprocess.CREATE_NO_WINDOW)
   state=load(task/'batch-runner-status.json') if (task/'batch-runner-status.json').exists() else {}
   message=state.get('reason') or '任务已停止；验证完成后点启动／继续'
   save(P/'status.json',{'message':message,'account':identity['nickname']})
  except Exception as e:save(P/'status.json',{'message':str(e)})
  finally:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
if __name__=='__main__':main()
