# 抖音原 CLI 调用链：仅离线核对

2026-11-08，北京时间。仅检索 box 已有材料；未访问 RMSAMA，未联网、拉仓库、启动云端代理或执行业务命令。下面“已核”只指离线源码/记录，不等于现场可用。

路径约定：
- R = `C:\Users\rmsama\Documents\ChatGPT\自动获客系统`
- C = `R\work\douyin-local-control`
- T = `R\work\douyin-local-20261104-1e985ff064`
- N = `R\work\runtime\douyin-bridge\node.exe`

## 1. 原 CLI 名称与路径

**已核：发送链实际调用的是 Node 适配脚本，不是 Python 自己发评论。**
- 可执行文件 N；脚本 `T\send_cli_once.cjs`。
- 证据：`/workspace/project-intake/fangyu/import/douyin/local1104-batch_reply_runner.py:15-24`，NODE/ADAPTER 常量；`:273` 实际调用。
- 适配器加载 `R\work\runtime\douyin-bridge\lib\client\bridge-client` 和 `R\work\runtime\douyin-bridge\lib\commands\post`。
- 证据：`/workspace/cloud-agent-transcripts/bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d.jsonl:29` 的适配器源码输出，正文行 2、9、14、57；更新版同文件 `:82`。
- **未核：**该 runtime 上游软件包的产品名、通用 CLI bin 入口、现机版本。不能凭目录名虚构 `douyin-cli post` 等命令。
- **已核：另一条是采集链** `R\work\fangyu-douyin-independent\runner.cjs`，不等于发送入口。证据：`takeover-readonly.md:109`；`local-runtime-check.md:141-148`（这两文件均位于 `/workspace/project-intake/fangyu/`）。

## 2. 原命令：仅说明，全部未执行

下列 `<...>` 是原代码运行时绑定的值，不是可直接执行的现成命令；没有输出账号、客户内容或真实对象 ID。

### 身份/评论读取（涉及平台读取；不代表零本地写入）

工作目录 R，代码构建参数：

```text
"<N>" "<T>\send_cli_once.cjs" --identity
"<N>" "<T>\send_cli_once.cjs" --preflight <video> <cid>
"<N>" "<T>\send_cli_once.cjs" --verify-own-reply <video> <cid>
```

**已核**前两条：`local1104-batch_reply_runner.py:163,203`；第三条：`/workspace/dy-deploy/full.patch:979-983,143-148`。其中 preflight 可带绑定连接参数：云端 transcript `:29` 正文行12；核对分支同文件 `:82` 正文行13。

注意：身份分支可写 `cli-current-binding.json`；preflight 分页可写 checkpoint/status，不能统称完全不写文件。证据：云端 transcript `:29` 正文行39-48。`--verify-own-reply` 是后加的核对模式，不是最初适配器已有参数。

诊断更新后的专用命令：
```text
python work\douyin-local-control\control.py --diagnose-unknown
```
**已核**仅诊断分支：`/workspace/dy-deploy/diagnose-deploy.patch:96-151,479-517`。它与普通启动不同；本轮不再运行。可占用/创建 control.lock；不能说零写入。

### 采集命令（不发送，但有网络读取和本地入库）

**已核原帮助模板，不是最后调度的可直接重启命令：**
```text
node runner.cjs --run --plan 15-store-plan.json --bridge-config <已核实Bridge配置> --identity-probe identity-probe.json --strict-proof <严格预检JSON> --database runner-runtime/collection.sqlite3 --directory runner-runtime --minimum-delay-ms 40000
```
证据：`local-runtime-check.md:143-145`。最后调度实际使用 11 月7日的确认计划/目录、1000ms；完整现用参数绑定**未核**，不能退回帮助模板。只读身份入口为 `collection_identity_check.cjs <计划> <Bridge配置>`、`identity_probe.cjs`，参数完整绑定未核（同文件 `:142`）。

### 发送命令（仅供负责人识别；不是当前授权，不得执行）

```text
"<面板解释器同目录的python.exe>" "<C>\control.py"
"<当前python解释器>" -u "<T>\<script>"
"<N>" "<T>\send_cli_once.cjs" "<attempt_path>"
```

**已核：**第一条由按钮构建；第二条 script 为 `batch_reply_runner.py` 或受门禁选择的 `resume_after_confirmation.py`；第三条由 runner 单条调用。证据：云端 transcript `:265` 正文行24-39；`full.patch:195-208,1101-1109`；`local1104-batch_reply_runner.py:273`。

适配器最终发布调用是：
```text
post(ctx,[task.video_id,task.reply.draft_text,'--reply-to',task.comment_id])
```
**已核：**云端 transcript `:29` 正文行51-59。这是模块函数调用，不是另一个已核实的 shell 命令。提交前检查绑定、unknown/平台拒绝与身份，不能从它绕过上游预览/批准。

## 3. 启动／继续按钮调用链

**已核（静态）：**
1. `panel.py start()`：已有 child 或 control 锁占用时直接返回；否则构建同目录 python.exe + control.py。`hold_reason()` 为真时附加 `--check-resume`，并非发送分支。证据：云端 transcript `:265` 正文行24-39。
2. control 普通分支核身份、选择任务，`handle_unknown_start()` 复用核对；若 `continue_queue` 为假，保存状态后返回，尚未启动 batch runner。证据：`full.patch:189-208`、`:1264-1269`。
3. 核对使用 runner.NODE + task/send_cli_once.cjs + `--verify-own-reply`，再调用 target_reader 的读评论/读回复逻辑。证据：`full.patch:143-148,979-983,446-470`。
4. 门禁通过才选 runner_script；control `subprocess.run([sys.executable,'-u',str(task/script)],cwd=ROOT,...)`；runner 验批准队列→身份→目标预检→预留→单条 Node 适配器→post。证据：`full.patch:195-208`；`local1104-batch_reply_runner.py:87-117,156-163,203,264-273`。

**未核（现场）：**用户最近一次点击是否启动了 control、有无重复进程、当前 hold/status/stop 内容。不可将上述静态链当现场已执行。

## 4. 最近成功证据与时间

- **已核“历史报告存在”**：`/workspace/project-intake/fangyu/source.md:12525-12529` 报累计877条成功回执、任务已停、上一笔待核；`:11971` 和 `:12165` 分别报单条3.3秒/3.1秒成功回执。
- **未核“最近一条成功回执本体及绝对时间”**：这些摘录没有对应原始回执文件路径/mtime/带日期时间；877是累计来源报告，不能充当最近一条的可见成功证明。没有为此扫描或访问本机。
- **已核最近核查记录但不是发送成功**：`/workspace/dy-deploy/diag-20261108-1624/summary.md:15-16`：北京时间2026-11-08 16:25:49，`blocked_reason=read_incomplete, own_reply_state=unchecked, stage=own_reply_check, error_type=other, http_status=null, cli_error_code=none, pagination_complete=false`。不是最近点击的现场状态。

## 5. 不经面板的等价入口（命令仅列示，未执行）

**已核参数构造；未核面板实际解释器绝对路径。**工作目录 R；正常分支与 hold 分支分别为：

```text
"<面板解释器同目录的python.exe>" "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\control.py"
"<面板解释器同目录的python.exe>" "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\control.py" --check-resume
```

证据：云端 transcript `:265` 正文行29-33。不能把直接运行 batch_reply_runner.py 说成按钮严格等价；那会绕开 control 的核对门禁。

## 6. 新规则：没回复就跳过，再处理剩余条目

**结论：有条件可执行；按最近已存结果不可执行。**

已装规则本来就支持：只有完整读取证明 `not_found`、目标可见、未提交、无超时/未完成、身份正常，才把该未知项 preserve，保持 unknown、不重发；再消费原已审队列。找到已发回复则补 sent 证据。账号/验证码/停线门禁先检查，未解除不能继续。

证据：`full.patch:1053-1081`（absence_confirmed/classify）；`:1218-1269`（resolve_on_start）；`diagnose-deploy.patch:435-459`（枚举门禁）。

最近一次是 unchecked + pagination_complete=false，不是“确认没有回复”。若要求连这种情况也跳过并发送，与“不完整读取不能当没发”和“unknown停线不清除”边界冲突，不能执行。

最小行为差异定位（不写代码）：`C\unknown_resolution.py`，`resolve_on_start()` 中 unchecked → `_stop(...)` 分支，证据 `full.patch:1264-1265`；`C\control.py main()` 的 `continue_queue` 门禁，证据 `full.patch:195-197`。现有完整 not_found 跳过逻辑无需修改。不能把前述停止分支改成无条件继续，作为合规修复。

## 7. 待发项、草稿及原发送批准证据

- **已核文件存在、未核逐项批准：** box `/workspace/douyin-pending-drafts.csv`，CSV第1行只有“条数、拟发文案”，286条聚合草稿记录；没有对象ID/alias或逐项批准字段，不是可绑定对象的发送队列。未输出其中客户化文本，不能把286条聚合稿当286个批准对象。
- **未核：** box所查导入材料未见实际 `approved-cli-queue.json` 或真实 `captcha-recovery-authorization.json` 的批准快照；因此不能列出已核准对象ID+对应批准文案。
- **已核批准门禁代码：** `local1104-batch_reply_runner.py:24,87-117` 要求 approved-cli-queue.json 的 authorized、账号绑定、源SHA/队列SHA、精确对象与原草稿校验；`:66-70` 读 preserve_unknown_comments。这是机制证据，不是用户批准本次发送的实物凭证。
- 旧恢复脚本 `local1104-resume_after_confirmation.py:28-44` 会处理授权/preserve并调用 runner，不能将其直接命令当作无需批准的捷径。
- 当前明确许可仍只是更新+一次诊断，不能外推为自动发送许可。

## 四项可用性（均不声称可用）

|项|离线结论|
|---|---|
|面板响应|未核当前点击；上次重开未确认PID，见 summary.md:21-25。|
|CLI启动|已核静态命令，未核当前是否启动。|
|评论读取|最近已存核查不完整；当前能力未核。|
|发送可用性|未核；不具备据此宣布可发送的证据。|

下一步：仅在另获在线只读检查许可且连接恢复后，取得本轮点击的进程/状态/锁证据及原队列批准绑定。需要新的联网读核查时必须另列精确范围请求批准；不自动再诊断或运行上述命令。
