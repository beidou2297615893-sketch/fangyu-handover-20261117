import pathlib,tempfile,shutil,subprocess,hashlib,json,ast,sys,zipfile
R=pathlib.Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统')
BASE=pathlib.Path(__file__).resolve().parent
mirror=pathlib.Path(tempfile.mkdtemp(prefix='dy-isolated-'))
log=[]
def note(x):log.append(x);print(x,flush=True)
def run():
 w=R/'work'; tasks=sorted([d for d in w.iterdir() if d.is_dir() and (d.name.startswith('douyin-local-') and d.name!='douyin-local-control' or d.name=='douyin-round2-task5')])
 fs=[f for f in (w/'douyin-local-control').iterdir() if f.is_file() and f.suffix in ('.py','.cjs','.js','.cmd','.md')]
 fs += [d/n for d in tasks for n in ('batch_reply_runner.py','resume_after_confirmation.py','send_cli_once.cjs')]
 assert len(tasks)>=6 and all(f.is_file() for f in fs)
 # Inspect imported historical runners, with constants never rendered or extracted.
 for d in tasks:
  tree=ast.parse((d/'batch_reply_runner.py').read_text(encoding='utf-8-sig'))
  for n in tree.body:
   if isinstance(n,(ast.FunctionDef,ast.ClassDef)):continue
   if isinstance(n,ast.If):
    assert ast.unparse(n.test)=="__name__ == '__main__'", 'unguarded historical if'
    continue
   calls=[ast.unparse(c.func) for c in ast.walk(n) if isinstance(c,ast.Call)]
   assert all(c in ('Path(__file__).resolve','Path','sys.path.insert','str') for c in calls), 'unexpected top-level call'
  imports=[ast.unparse(n) for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
  assert all(not any(t in x for t in ('requests','socket','urllib','browser','ledger import')) for x in imports)
  note('STATIC historical runner safe import boundary: '+d.name)
 note('WHITELIST '+json.dumps([str(f.relative_to(R)) for f in fs],ensure_ascii=True))
 for f in fs:
  p=mirror/f.relative_to(R);p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,p)
 note('MIRROR '+str(mirror)+'; ordinary files='+str(len(fs)))
 # Full patch uses flattened cloud paths. Supply baseline task alias as ordinary code only.
 alias=mirror/'work/task';alias.mkdir()
 for n in ('batch_reply_runner.py','resume_after_confirmation.py','send_cli_once.cjs'):
  shutil.copyfile(mirror/'work/douyin-local-20261104-1e985ff064'/n,alias/n)
 git=shutil.which('git');assert git, 'git unavailable'
 cmd=[git,'apply','--unidiff-zero','--exclude=README.md',str(BASE/'full.patch')]
 q=subprocess.run(cmd,cwd=mirror/'work',capture_output=True)
 note('GIT APPLY stdout:\n'+q.stdout.decode('utf-8',errors='replace'))
 note('GIT APPLY stderr:\n'+q.stderr.decode('utf-8',errors='replace'))
 assert q.returncode==0,'full.patch apply failed'
 bad=[]
 for line in (BASE/'sha.txt').read_text().splitlines():
  cols=line.split('\t')
  if len(cols)!=3 or cols[0]=='README.md':continue
  p=mirror/'work'/cols[0];actual=hashlib.sha256(p.read_bytes()).hexdigest()
  ok=actual==cols[2];note('FINAL SHA '+cols[0]+' '+actual+' match='+str(ok))
  if not ok:bad.append(cols[0])
 if bad:
  note('STOP: exact final SHA mismatch: '+','.join(bad)+'. No constant normalization or source changes performed. Tests NOT RUN; collected=0 executed=0.')
  return
 note('SHA gate passed. STOP pending independent safety check of isolated harness before executing tests.')
try:run()
except Exception as e:
 note('BLOCKER '+type(e).__name__+': '+str(e))
finally:
 (BASE/'isolated-test-output.txt').write_text('\n'.join(log)+'\n',encoding='utf-8')
 print('OUTPUT '+str(BASE/'isolated-test-output.txt'))
