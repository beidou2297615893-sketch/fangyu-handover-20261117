import pathlib,re,hashlib,json,sys,io,contextlib,unittest,tempfile,os
BASE=pathlib.Path(__file__).resolve().parent
M=pathlib.Path(r'C:\Users\rmsama\AppData\Local\Temp\dy-isolated-cs1lzoyo')
OUT=M/'isolated-test-output.txt'
log=io.StringIO()
def say(x): print(x,file=log)
def sha(b):return hashlib.sha256(b).hexdigest()
def reverse_file(data,name):
 patch=(BASE/'full.patch').read_bytes().splitlines(keepends=True)
 active=False;hunks=[];cur=None
 for line in patch:
  if line.startswith(b'diff --git '):
   active=line.startswith(('diff --git a/'+name+' b/').encode());cur=None
  elif active and line.startswith(b'@@ '):
   m=re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line)
   cur=[int(m[3]),int(m[4] or b'1'),[],[]];hunks.append(cur)
  elif active and cur is not None and line[:1] in (b' ',b'+',b'-'):
   if line[:1] in (b' ',b'-'):cur[2].append(line[1:])
   if line[:1] in (b' ',b'+'):cur[3].append(line[1:])
 lines=data.splitlines(keepends=True)
 for start,count,old,new in reversed(hunks):
  at=start-1 if count else start
  assert lines[at:at+count]==new,'reverse patch context mismatch '+name+' line '+str(start)
  lines[at:at+count]=old
 return b''.join(lines)
def run():
 specs=[('douyin-local-control/control.py',rb"olduid='([^']+)'"),('task/send_cli_once.cjs',rb"const accountUid='([^']+)'" )]
 manifest={t[0]:(t[1],t[2]) for l in (BASE/'sha.txt').read_text().splitlines() if len(t:=l.split('\t'))==3}
 allok=True;accounts=[]
 for name,pattern in specs:
  final=(M/'work'/name).read_bytes();match=re.search(pattern,final);assert match,'literal location missing'
  account=match[1];accounts.append(account)
  baseline=reverse_file(final,name)
  say('FILE '+name+' REAL_FINAL_SHA256 '+sha(final))
  for version,data,expected in [('baseline',baseline,manifest[name][0]),('final',final,manifest[name][1])]:
   masked=data.replace(account,b'<REDACTED_ACCOUNT>')
   lines=[i+1 for i,l in enumerate(data.splitlines()) if account in l]
   ok=sha(masked)==expected;allok &=ok
   say(json.dumps({'file':name,'version':version,'replacement_lines':lines,'replacement_count':data.count(account),'masked_sha256':sha(masked),'expected_sha256':expected,'match':ok}))
   if not ok:
    ref=BASE/'refs'/version/name
    if ref.exists():
     a=masked.splitlines(keepends=True);b=ref.read_bytes().splitlines(keepends=True)
     for i in range(max(len(a),len(b))):
      if (a[i] if i<len(a) else None)!=(b[i] if i<len(b) else None):
       typ='line_ending_only' if i<len(a) and i<len(b) and a[i].rstrip(b'\r\n')==b[i].rstrip(b'\r\n') else 'non_account_content_or_line_count'
       say('DIFFERENCE line='+str(i+1)+' type='+typ)
 if not allok:
  say('STOP SHA normalization mismatch; collected=0 executed=0');return
 say('All four masked baseline/final SHA comparisons match. No code files modified.')
 # Exact byte-replacement is established by BOTH archived baseline and cloud final SHA.
 # Audit guard refuses DB, network, subprocesses, real business paths and writes outside mirror.
 sys.dont_write_bytecode=True
 fixtures=M/'test-fixtures';fixtures.mkdir(exist_ok=True)
 tempfile.tempdir=str(fixtures)
 real=pathlib.Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统')
 def audit(event,args):
  if event.startswith(('socket.','sqlite3.')) or event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn'):
   raise RuntimeError('ISOLATION blocked capability '+event)
  if event in ('open','os.listdir','os.scandir','os.chdir','os.remove','os.rmdir','os.mkdir','os.rename'):
   for a in args[:2] if event=='os.rename' else args[:1]:
    if not isinstance(a,(str,bytes,os.PathLike)):continue
    p=pathlib.Path(os.fsdecode(a)).resolve()
    if p==real or real in p.parents:raise RuntimeError('ISOLATION blocked production path')
   if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
    mode=args[1] or '';flags=args[2] or 0
    if any(c in str(mode) for c in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):
     p=pathlib.Path(os.fsdecode(args[0])).resolve()
     if p!=M and M not in p.parents:raise RuntimeError('ISOLATION blocked external write')
 sys.addaudithook(audit)
 sys.path.insert(0,str(M/'work/douyin-local-control'))
 import control
 assert control.ROOT==M
 import test_startup_recovery as tests
 names=['test_transient_windows_file_lock_is_retried','test_default_sender_goes_to_reservation_without_live_comment_scan','test_three_page_timeouts_skip_without_reserving_or_stopping','test_migrate_all_existing_runner_variants_offline_idempotently']
 suite=unittest.TestSuite(tests.StartupRecoveryTests(n) for n in names)
 say('COLLECTED '+str(suite.countTestCases()))
 stdout=io.StringIO();stderr=io.StringIO()
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 say('=== RAW STDOUT ===\n'+stdout.getvalue())
 say('=== RAW STDERR ===\n'+stderr.getvalue())
 say('RESULT '+json.dumps({'collected':4,'run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'successful':result.wasSuccessful()}))
try:run()
except Exception as e:
 # Never render unknown exception arguments which could contain account values.
 say('HARNESS ERROR '+type(e).__name__)
 import traceback
 say('\n'.join('  '+f.filename+':'+str(f.lineno)+' in '+f.name for f in traceback.extract_tb(e.__traceback__)))
finally:
 OUT.write_text(log.getvalue(),encoding='utf-8');print(log.getvalue())
