"""Send-time adapter for field business_fit.screen(), plus a narrow supply gate.

Unique deploy name: queue_business_screen.py

Field business_fit (7BB699A7) stays untouched. Its speaker_supply pattern misses
common field listings such as「礼貌借楼转租…」and「有人要嘛…1200 40平」when
upstream role is mislabeled demand — those become eligible and leak into send.

This module:
  1) applies a strict supply-side / listing gate on comment text (not cid hardcodes);
  2) then calls the real screen() and keeps all of its budget/region/time/conflict rules;
  3) never false-passes when text is missing or supply/demand is ambiguous (待核 → skip).
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] if HERE.parent.name == 'work' else HERE.parent

_FIT_CANDIDATES = (
    HERE.parent / 'fangyu-text-business-20261029/business-fit',
    ROOT / 'work/fangyu-text-business-20261029/business-fit',
)

# Seeker language: customer wants a unit (including seeking a sublet).
_SEEK_DEMAND = re.compile(
    r'(?:求|想|要|找)转租|求租|想租|要租|正在找房|找整租|准备租|求房|'
    r'有没有转租|求个转租|想找转租|预算'
)
# Supply / listing language: commenter offers a unit (not own monthly budget).
# Negative lookbehinds keep seeker phrases like「求转租」「有没有转租」out of supply.
_SUPPLY_OFFER = re.compile(
    r'借楼转租|(?<!求)(?<!想)(?<!要)(?<!找)(?<!有没有)转租|'
    r'(?<!求)(?<!想)(?<!要)(?<!找)转让|'
    r'本人出租|我有房|我是房东|房东直租|房东出租|房源出租|'
    r'招室友|找室友|整租转出|整租转让|次卧转|'
    r'有人要嘛|有人要吗|有没有人要'
)
# Unit listing price cues — not the commenter's own housing budget.
_LISTING_PRICE = re.compile(
    r'押一付一|押\s*\d\s*付\s*\d|一付一|'
    r'(?:水费)?物业费|{0}\s*平|月租{0}|房租{0}'.format(r'\d+(?:\.\d+)?')
)


def _ensure_business_fit():
    for path in _FIT_CANDIDATES:
        if path.is_dir() and (path / 'business_fit.py').exists():
            inserted = str(path)
            if inserted not in sys.path:
                sys.path.insert(0, inserted)
            break
    from business_fit import screen  # noqa: WPS433 — field module only
    return screen


def _classification_paths():
    return (
        HERE.parent / 'fangyu-douyin-independent/classification-handoff-status.json',
        ROOT / 'work/fangyu-douyin-independent/classification-handoff-status.json',
    )


def load_classification_record(cid: str):
    """Best-effort load of the live classification row for cid. None if offline."""
    for status_path in _classification_paths():
        if not status_path.exists():
            continue
        try:
            status = json.loads(status_path.read_text(encoding='utf-8-sig'))
            output = Path(status['output'])
            if not output.is_absolute():
                output = (ROOT / output).resolve()
            with output.open(encoding='utf-8-sig') as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    if str(row.get('comment_id')) == str(cid):
                        return row
        except (OSError, KeyError, ValueError, TypeError, json.JSONDecodeError):
            return None
    return None


def _comment_text(record) -> str:
    record = record or {}
    classification = record.get('classification') or {}
    return str(
        record.get('comment_text')
        or record.get('text')
        or classification.get('comment_text')
        or ''
    )


def supply_side_skip_reason(text: str) -> str | None:
    """Outer gate: supply/listing → skip; ambiguous → 待核 skip; clear seeker → None.

    Returns a reason string to skip send, or None to continue into real screen().
    """
    t = (text or '').strip()
    if not t:
        return 'original_comment_text_missing'
    seeking = bool(_SEEK_DEMAND.search(t))
    offering = bool(_SUPPLY_OFFER.search(t))
    listing_price = bool(_LISTING_PRICE.search(t))
    if offering and seeking:
        return 'supply_demand_ambiguous_review'
    if offering and not seeking:
        return 'supply_side_transfer_or_listing'
    if listing_price and not seeking:
        # Bare unit price without seeker language is not an own-budget demand.
        return 'listing_price_not_own_budget_review'
    return None


def _reason_from_screen_result(result: dict) -> str:
    """Map real screen() reason lists; never invent rule codes locally."""
    exclusions = result.get('exclusion_reasons')
    if isinstance(exclusions, (list, tuple)) and exclusions:
        return str(exclusions[0])
    holds = result.get('verification_required')
    if isinstance(holds, (list, tuple)) and holds:
        return str(holds[0])
    for key in ('screen_reason', 'reject_reason', 'ineligible_reason', 'reason'):
        value = result.get(key)
        if value:
            return str(value)
    return 'business_fit_ineligible'


def skip_reason_for_record(record, now=None) -> str | None:
    """None = may send; otherwise skip/待核 reason. Missing fields never false-pass."""
    text = _comment_text(record)
    gate = supply_side_skip_reason(text)
    if gate:
        return gate
    screen = _ensure_business_fit()
    result = screen(record, now) if now is not None else screen(record)
    if isinstance(result, dict) and result.get('eligible_candidate') is True:
        return None
    return _reason_from_screen_result(result if isinstance(result, dict) else {})


def skip_reason_for_queue_item(item, record=None, now=None) -> str | None:
    """Prefer live classification row so field screen sees full context."""
    cid = str((item or {}).get('cid') or '')
    row = record if record is not None else load_classification_record(cid)
    queue_text = str((item or {}).get('text') or '')
    if row is None:
        row = {
            'comment_id': cid,
            'comment_text': queue_text,
            'commercial_fit': (item or {}).get('commercial_fit') or {},
        }
    elif queue_text and not _comment_text(row):
        row = dict(row, comment_text=queue_text)
    # Gate both queue-visible and classification text; either supply hit blocks send.
    for text in (queue_text, _comment_text(row)):
        gate = supply_side_skip_reason(text)
        if gate:
            return gate
    return skip_reason_for_record(row, now=now)
