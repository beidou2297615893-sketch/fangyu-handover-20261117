import unittest
import retention30 as r

class Retention(unittest.TestCase):
 def test_exact_rolling_cutoff(self):
  now=2000000000
  row={'comment_id':'1234567890123','published_at_unix':now-30*86400}
  self.assertFalse(r.expired(row,'douyin',now))
  row['published_at_unix']-=1
  self.assertTrue(r.expired(row,'douyin',now))
 def test_unknown_date_not_deleted_or_treated_as_current(self):
  row={'comment_id':'1234567890123'}
  self.assertFalse(r.expired(row,'douyin'))
  self.assertFalse(r.allowed(row,'douyin'))
 def test_not_a_comment_and_not_file_date(self):
  self.assertFalse(r.expired({'template_id':'price','published_at_unix':1000},'douyin'))
  self.assertFalse(r.expired({'comment_id':'1234567890123','collected_at':1000},'douyin'))
 def test_raw_platform_timestamp(self):
  self.assertTrue(r.expired({'cid':'1234567890123','create_time':1000},'xiaohongshu',2000000000))

if __name__=='__main__':unittest.main()
