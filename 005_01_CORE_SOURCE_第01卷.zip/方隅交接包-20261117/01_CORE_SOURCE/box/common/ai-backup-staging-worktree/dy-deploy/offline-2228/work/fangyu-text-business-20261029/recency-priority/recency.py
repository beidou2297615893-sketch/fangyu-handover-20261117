from datetime import datetime, timezone
BANDS=['近7天','8至15天','16至30天（低优先）','31至60天（极低优先）','61至90天（极低优先）','超过90天（极低优先）','时间不明']
DOUYIN_REPLY_PRIORITY_VERSION = 'douyin-time-budget-intent-pools-v4-20261105'
DOUYIN_ACTIVE_POOL_POLICY = 'douyin-active-30days-20261105'
FOLLOWUP_POOLS = ('优先跟进', '重点跟进', '一般跟进', '低优先或待核实')
INTENT_POOLS = ('原评论求租意愿强', '原评论求租意愿中等', '原评论求租意愿弱', '求租意愿待核实')
def stamp(r):
 metadata=((r.get('classification') or {}).get('original_metadata') or {})
 for v in [r.get('published_at'),r.get('original_comment_date'),r.get('comment_published_at'),metadata.get('published_at'),r.get('published_at_unix')]:
  if v is None or isinstance(v,bool) or v=='':continue
  try:
   if isinstance(v,(int,float)) or (isinstance(v,str) and v.strip().isdigit()):
    n=float(v)
    if n<=0:continue
    return datetime.fromtimestamp(n/1000 if n>100000000000 else n,timezone.utc).timestamp()
   t=datetime.fromisoformat(v.replace('Z','+00:00'));return t.replace(tzinfo=timezone.utc).timestamp() if t.tzinfo is None else t.timestamp()
  except (ValueError,TypeError,AttributeError,OverflowError,OSError):continue
 return None
def key(r,now=None):
 now=now or datetime.now(timezone.utc).timestamp();t=stamp(r)
 if t is None or t>now+3600:return (6,0)
 age=max(0,(now-t)/86400);band=next((i for i,n in enumerate([7,15,30,60,90]) if age<=n),5)
 return (band,-t)

def within_douyin_active_window(row, now=None):
 return key(row,now)[0]<=2

def priority_key(r,now=None):
 band,negative_time=key(r,now)
 fit=r.get('commercial_fit') or {}
 budget=(fit.get('budget') or {}).get('state')
 budget_rank=0 if budget=='budget_at_least_4000' else 1
 interest=fit.get('lead_intent') or r.get('interest_at_comment') or fit.get('original_intent') or r.get('original_interest')
 intent_rank={'super_high':0,'high':1,'medium':2,'low':3,'very_low':4}.get(interest,5)
 # Recency windows dominate. Within a window, compare evidenced budget, then
 # rental intent; newest first breaks remaining ties. Never relax fit gates.
 return (band,budget_rank,intent_rank,negative_time)


def douyin_reply_priority(row, now=None):
    """Keep time bands first, then cross the budget evidence with rental intent."""
    band, budget_rank, intent_rank, negative_time = priority_key(row, now)
    intent_tier = 0 if intent_rank <= 1 else 1 if intent_rank == 2 else 2 if intent_rank <= 4 else 3
    pool = min(budget_rank + intent_tier, 3)
    return {
        'version': DOUYIN_REPLY_PRIORITY_VERSION,
        'time_band': BANDS[band],
        'budget_pool': '预算有达标证据' if budget_rank == 0 else '预算待核实',
        'intent_pool': (row.get('commercial_fit') or {}).get('lead_intent_label') or INTENT_POOLS[intent_tier],
        'followup_pool': FOLLOWUP_POOLS[pool],
        'key': (band, budget_rank, intent_rank, negative_time),
    }
