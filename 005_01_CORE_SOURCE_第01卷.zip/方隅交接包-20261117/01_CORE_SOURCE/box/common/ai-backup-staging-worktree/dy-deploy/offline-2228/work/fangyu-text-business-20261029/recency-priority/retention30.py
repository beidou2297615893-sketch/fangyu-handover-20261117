"""Project-local comment retention. Long-lived rules and templates are not rows."""
import hashlib
import json
from pathlib import Path
import time
import recency

WORK=Path(__file__).resolve().parent.parent
POLICY=WORK/'rules/只保留30天评论执行方式.json'
REGISTRY=WORK/'retention-cleanup-20261106/expired-fingerprints.json'
_cached_mtime=None
_fingerprints=set()

def enabled(platform):
    return POLICY.exists() and platform in ('douyin','xiaohongshu')

def fingerprint(platform,cid):
    return hashlib.sha256((platform+'\0'+str(cid)).encode()).hexdigest()

def registry():
    global _cached_mtime,_fingerprints
    mtime=REGISTRY.stat().st_mtime_ns if REGISTRY.exists() else None
    if mtime!=_cached_mtime:
        _fingerprints=set(json.loads(REGISTRY.read_text(encoding='utf-8'))['digests']) if mtime else set()
        _cached_mtime=mtime
    return _fingerprints

def cid(row):
    for key in ('comment_id','cid'):
        if row.get(key) is not None:return str(row[key])
    value=row.get('source_stable_key') or row.get('stable_key')
    if isinstance(value,str) and value.startswith('comment:'):return value.split(':',1)[1]
    value=row.get('comment')
    return str(value) if isinstance(value,(str,int)) and len(str(value))>=12 and ' ' not in str(value) else None

def stamp(row):
    found=recency.stamp(row)
    if found is None and cid(row):
        for key in ('create_time','created_time','comment_time'):
            if row.get(key):
                found=recency.stamp({'published_at':row[key]})
                if found is not None:break
    if found is None and isinstance(row.get('source_record'),dict):return stamp(row['source_record'])
    return found

def expired(row,platform=None,now=None):
    platform=row.get('platform') or platform
    comment=cid(row)
    if not comment:return False
    if platform and fingerprint(platform,comment) in registry():return True
    published=stamp(row)
    now=time.time() if now is None else now
    return published is not None and published<=now and now-published>30*86400

def allowed(row,platform=None,now=None):
    now=time.time() if now is None else now
    published=stamp(row)
    return not expired(row,platform,now) and published is not None and published<=now+3600
