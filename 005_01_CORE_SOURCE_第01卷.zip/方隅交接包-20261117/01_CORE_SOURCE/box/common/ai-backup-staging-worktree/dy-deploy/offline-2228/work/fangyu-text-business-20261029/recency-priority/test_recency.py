import unittest
from datetime import datetime,timezone
import recency

class RecencyTests(unittest.TestCase):
 def setUp(self):self.now=datetime(2026,11,4,14,tzinfo=timezone.utc).timestamp()
 def row(self,days=1,**kw):return dict(published_at_unix=self.now-days*86400,**kw)
 def test_unix_seconds_milliseconds_and_numeric_string(self):
  for value in [self.now-86400,(self.now-86400)*1000,str(int(self.now-86400))]:
   self.assertEqual(recency.key({'published_at_unix':value},self.now)[0],0)
 def test_iso_is_preferred_and_bad_iso_falls_back(self):
  self.assertEqual(recency.key(self.row(published_at='2026-08-01T00:00:00Z'),self.now)[0],5)
  self.assertEqual(recency.key(self.row(published_at='unknown'),self.now)[0],0)
 def test_missing_and_collected_time_do_not_imply_recency(self):
  for row in [{},{'collected_at':self.now},{'published_at_unix':0},{'published_at_unix':True}]:
   self.assertEqual(recency.key(row,self.now)[0],6)
 def test_future_stays_unknown(self):
  self.assertEqual(recency.key(self.row(-2),self.now)[0],6)
 def test_douyin_active_window_keeps_only_known_thirty_days(self):
  self.assertTrue(recency.within_douyin_active_window(self.row(30),self.now))
  for row in [self.row(30.01),self.row(60),self.row(90),{},self.row(-2)]:
   self.assertFalse(recency.within_douyin_active_window(row,self.now))
 def test_age_before_budget_and_intent(self):
  recent=self.row(1,interest_at_comment='medium')
  older=self.row(10,interest_at_comment='high',commercial_fit={'budget':{'state':'budget_at_least_4000'}})
  self.assertLess(recency.priority_key(recent,self.now),recency.priority_key(older,self.now))
 def test_thirty_days_before_sixty_and_ninety_even_with_higher_budget(self):
  recent=self.row(29,interest_at_comment='medium')
  for age in [31,60,89,90]:
   older=self.row(age,interest_at_comment='super_high',commercial_fit={'budget':{'state':'budget_at_least_4000'}})
   self.assertLess(recency.douyin_reply_priority(recent,self.now)['key'],recency.douyin_reply_priority(older,self.now)['key'])
 def test_same_band_budget_then_intent(self):
  funded=self.row(6,interest_at_comment='medium',commercial_fit={'budget':{'state':'budget_at_least_4000'}})
  high=self.row(1,interest_at_comment='high')
  medium=self.row(0,interest_at_comment='medium')
  self.assertLess(recency.priority_key(funded,self.now),recency.priority_key(high,self.now))
  self.assertLess(recency.priority_key(high,self.now),recency.priority_key(medium,self.now))

if __name__=='__main__':unittest.main()
