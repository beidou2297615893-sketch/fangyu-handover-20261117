"""抖音新一轮采集（通用，任意已登录账号）。配置固定：collection-config-fixed.json。
流程：严格桥核验 -> 当前登录账号 -> 生成本轮计划 -> 本账号历史只读暂停记录按本轮范围复核(排除相关词/视频，不重发) -> 1页验证 -> 后台全量 -> 打开进度窗。
不发送、不改发送账本。"""
import json, sqlite3, hashlib, subprocess, sys, os, time, datetime, shutil
from pathlib import Path
from contextlib import closing
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scoped_recovery import effective_halt
APP = ROOT.parents[1]
BRIDGE = APP / '抖音自用采集台' / 'data' / 'bridge.json'
DB = ROOT / 'runtime' / 'collection.sqlite3'
CONFIG = ROOT / 'collection-config-fixed.json'
POLICY = 'runner-audit-myeaj720/runner-qualification-policy.json'
NODE = shutil.which('node') or 'node'
PYW = str(Path(sys.executable).with_name('pythonw.exe'))
FLAGS = 0x08000000
WHO = r'''
const fs=require('fs');const {BridgeClient}=require('../runtime/douyin-bridge/lib/client/bridge-client');
(async()=>{const b=new BridgeClient({...JSON.parse(fs.readFileSync(process.argv[2],'utf8')).bridge,reuseConnections:false});
const refused=await b.call({site:'douyin.com',connId:'nonexistent-collection-confirmation-proof',expression:'1',awaitPromise:true,timeout:3000});
const strict=refused.ok===false;const out=[];const st=await b.status();
for(const c of (st.connections['douyin.com']||[])){if(!c.alive)continue;
 const r=await b.call({site:'douyin.com',connId:c.id,expression:"(async()=>{const q=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+q,{credentials:'include'});const d=await r.json();return {s:d.status_code,u:d.user?.sec_uid,n:d.user?.nickname}})()",awaitPromise:true,timeout:14000});
 out.push({id:c.id,last:c.lastActivity,ok:r.ok,connection:r.connection,v:r.value||null});}
console.log(JSON.stringify({strict,conns:out}));})().catch(e=>{console.log(JSON.stringify({error:e.message}));});
'''
def say(m): print(m, flush=True)
def rd(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p, d): Path(p).write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding='utf-8')
def running(pid):
    if not pid: return False
    out = subprocess.run(['tasklist', '/FI', f'PID eq {pid}', '/NH'], capture_output=True, text=True, creationflags=FLAGS).stdout
    return str(pid) in out
def who():
    f = ROOT / '_who_tmp.cjs'; f.write_text(WHO, encoding='utf-8')
    try: return json.loads(subprocess.run([NODE, f.name, str(BRIDGE)], cwd=ROOT, capture_output=True, text=True, encoding='utf-8', timeout=90, creationflags=FLAGS).stdout.strip().splitlines()[-1])
    finally: f.unlink(missing_ok=True)
def main():
    active_file = ROOT / 'active-runner.json'
    active = rd(active_file)
    if running(active.get('pid')): say('采集已在运行，未重复启动。'); return 1
    w = who()
    if w.get('error'): say('采集桥连接失败：' + w['error']); return 1
    if not w['strict']: say('采集桥不是严格模式（请求可能发到别的页面），已停止。'); return 1
    good = [c for c in w['conns'] if c['ok'] and c['connection'] == c['id'] and c['v'] and c['v'].get('s') == 0 and c['v'].get('u')]
    accounts = {c['v']['u'] for c in good}
    if not good: say('没有可用的已登录抖音页面。请打开抖音并登录后再试。'); return 1
    if len(accounts) > 1: say('有多个不同账号的抖音页面同时连接，请只保留要采集的那个账号页面。'); return 1
    conn = sorted(good, key=lambda c: c['last'] or '')[-1]
    uid, nick = conn['v']['u'], conn['v']['n']
    say(f'当前登录账号：{nick}（连接 {conn["id"][:8]}）')
    cfg = rd(CONFIG)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    scan = f'douyin-round-{stamp}'; s = f'round-{stamp}'
    plan = dict(cfg, scan_id=scan, account_uid=uid, connection_id=conn['id'],
                collection_accounts=sorted(set(cfg.get('collection_accounts', [])) | {uid}),
                account_transition_source=f'User 2026-11-09 standing instruction: collect with whichever account is logged in; fixed config; {nick} verified {stamp}',
                local_comment_deferrals=[], local_search_deferrals=[])
    # 本账号历史暂停记录：按本轮范围复核，排除相关词与视频（不重新请求）
    auth = f'User 2026-11-09 14:58 explicit: new round with logged-in account, fixed config; historical transport unknowns of other scans excluded, never replayed; account freshly verified {stamp}'
    with closing(sqlite3.connect(DB, timeout=15)) as db, db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN IMMEDIATE')
        halts = [dict(r) for r in db.execute('SELECT * FROM collection_halt_events WHERE account_uid=?', (uid,))]
        legacy = db.execute('SELECT * FROM account_halts WHERE account_uid=?', (uid,)).fetchone()
        ids = [h['request_id'] for h in halts] + ([legacy['request_id']] if legacy else [])
        words, videos = set(), set(plan.get('excluded_historical_videos', []))
        att = {}
        for rid in ids:
            a = db.execute('SELECT * FROM attempts WHERE request_id=?', (rid,)).fetchone()
            if not a: say(f'历史暂停记录 {rid} 缺少原始记录，无法复核，已停止。'); db.rollback(); return 1
            att[rid] = a; sp = json.loads(a['spec'])
            if sp.get('keyword'): words.add(sp['keyword'])
            (words if sp['kind'] == 'search' else videos).add(sp['target'])
        # 轮换：最近3天已搜过的词排到后面，没搜过的新词先搜
        since = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=3)).isoformat()
        recent = {json.loads(r[0]).get('keyword') for r in db.execute("SELECT spec FROM attempts WHERE json_extract(spec,'$.kind')='search' AND state!='unknown' AND collected_at>=?", (since,))}
        stores = [dict(st, keywords=sorted([k for k in st['keywords'] if k not in words], key=lambda k: k in recent)) for st in plan['stores']]
        if not all(st['keywords'] for st in stores): say('排除后有门店没有关键词，已停止。'); db.rollback(); return 1
        plan.update(stores=stores, excluded_historical_videos=sorted(videos))
        allowed = sorted({k for st in stores for k in st['keywords']})
        now = datetime.datetime.now().astimezone().isoformat()
        if ids:
            db.execute('INSERT INTO collection_scope_reviews VALUES(?,?,?,?,?,?,?)',
                       (uid, scan, legacy['request_id'] if legacy else ids[0], json.dumps(allowed, ensure_ascii=False), json.dumps(sorted(videos)), auth, now))
            for rid, a in att.items():
                db.execute('INSERT INTO collection_event_reviews VALUES(?,?,?,?,?,?,?)',
                           (uid, scan, rid, hashlib.sha256(a['response'].encode()).hexdigest(), auth, f'identity-{s}.json', now))
        left = effective_halt(db, uid, scan)
        if left: say(f'该账号仍有不能跳过的暂停记录（{left["detail"][:60]}），已停止，未采集。'); db.rollback(); return 1
        plan_name = f'plan-{s}.json'; wr(ROOT / plan_name, plan)
        chk = subprocess.run([NODE, 'collection_identity_check.cjs', plan_name, str(BRIDGE)], cwd=ROOT, capture_output=True, text=True, encoding='utf-8', timeout=60, creationflags=FLAGS)
        if chk.returncode: say('账号核验未通过（可能有验证码或页面未加载完），已停止。'); db.rollback(); return 1
    (ROOT / f'identity-{s}.json').write_text(chk.stdout.strip(), encoding='utf-8')
    wr(ROOT / f'strict-proof-{s}.json', dict(verified=True, source='Exact route refusal and same account profile verified', account_uid=uid, connection_id=conn['id']))
    say(f'本轮关键词 {len(allowed)} 个（排除该号历史暂停相关 {len(words)} 个）')
    base = [NODE, 'runner.cjs', '--plan', plan_name, '--database', str(DB), '--directory', f'runner-live-{s}', '--qualification-policy', POLICY,
            '--run', '--bridge-config', str(BRIDGE), '--identity-probe', f'identity-{s}.json', '--strict-proof', f'strict-proof-{s}.json', '--minimum-delay-ms', '1000']
    val = f'runner-{s}-validation.log'
    with open(ROOT / val, 'wb') as out:
        subprocess.run(base + ['--max-pages', '1'], cwd=ROOT, stdout=out, stderr=subprocess.STDOUT, creationflags=FLAGS)
    last = (ROOT / val).read_text(encoding='utf-8', errors='replace').strip().splitlines()[-1:] or ['']
    if 'bounded_batch_complete' not in last[0]: say('第1页验证没通过，已停止：' + last[0][:200]); return 1
    say('第1页验证通过，开始全量采集。')
    so, se = f'runner-{s}-stdout.log', f'runner-{s}-stderr.log'
    p = subprocess.Popen(base, cwd=ROOT, stdout=open(ROOT / so, 'wb'), stderr=open(ROOT / se, 'wb'), creationflags=FLAGS)
    time.sleep(1)
    if p.poll() is not None: say('全量采集没能启动，请看 ' + se); return 1
    prev = {k: active.get(k) for k in ('plan', 'directory', 'stdout', 'stderr', 'identity', 'strict_proof', 'pid')}
    active.update(plan=plan_name, directory=f'runner-live-{s}', stdout=so, stderr=se, identity=f'identity-{s}.json',
                  strict_proof=f'strict-proof-{s}.json', pid=p.pid, status='running', account_nickname=nick, validation_log=val,
                  started_at=datetime.datetime.now().astimezone().isoformat(), previous_round=prev, minimum_delay_ms=1000)
    active.pop('current_blocker', None)
    tmp = active_file.with_suffix('.tmp'); wr(tmp, active); tmp.replace(active_file)
    q = subprocess.run(['powershell', '-NoProfile', '-Command', "(Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe'\").CommandLine"], capture_output=True, text=True, creationflags=FLAGS).stdout
    if 'collection_progress_window' not in (q or ''): subprocess.Popen([PYW, 'collection_progress_window.py'], cwd=ROOT)
    say(f'已开始采集（账号 {nick}），进度窗口已打开。')
    return 0
if __name__ == '__main__':
    sys.exit(main())
