"""采集自动续跑：采集停下(结果未知跳过/词用尽)后自动开新一轮，用当前登录账号+固定配置。
验证码/身份异常/不可跳过的暂停 -> new_round.py 会拒绝，本程序随即停手等人工。停止：建 auto-collect.stop"""
import json, subprocess, sys, time, datetime
from pathlib import Path
ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'auto-collect.log'; STOP = ROOT / 'auto-collect.stop'
PY = str(Path(sys.executable).with_name('python.exe'))
FLAGS = 0x08000000
OK = ('ledger_unknown', 'sources_exhausted', 'bounded_batch_complete', 'awaiting_candidate_review')
def log(m):
    with open(LOG, 'a', encoding='utf-8') as f: f.write(f'{datetime.datetime.now():%m-%d %H:%M:%S} {m}\n')
def alive(pid):
    return bool(pid) and str(pid) in subprocess.run(['tasklist', '/FI', f'PID eq {pid}', '/NH'], capture_output=True, text=True, creationflags=FLAGS).stdout
def last_state(a):
    try:
        lines = (ROOT / a['stdout']).read_text(encoding='utf-8', errors='replace').strip().splitlines()
        j = json.loads(lines[-1]); return j.get('reason') or j.get('state')
    except Exception: return None
restarts = []
log('started')
while not STOP.exists():
    time.sleep(60)
    try:
        a = json.loads((ROOT / 'active-runner.json').read_text(encoding='utf-8'))
        if alive(a.get('pid')) or any(ROOT.glob('runner-lease-*.json')): continue
        st = last_state(a)
        if st not in OK: log(f'stopped state={st}, not auto-restarting'); time.sleep(600); continue
        now = time.time(); restarts = [t for t in restarts if now - t < 3600]
        if len(restarts) >= 6: log('6 restarts within 1h, cooling 30min'); time.sleep(1800); continue
        time.sleep(120 if st == 'ledger_unknown' else 30)
        r = subprocess.run([PY, 'new_round.py'], cwd=ROOT, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=900, creationflags=FLAGS, env={**__import__('os').environ, 'PYTHONIOENCODING': 'utf-8'})
        restarts.append(now)
        log(f'after {st}: rc={r.returncode} ' + ' | '.join(r.stdout.strip().splitlines()[-3:]))
        if r.returncode: time.sleep(900)
    except Exception as e:
        log(f'error {e!r}'); time.sleep(300)
log('stop file found, exiting')
