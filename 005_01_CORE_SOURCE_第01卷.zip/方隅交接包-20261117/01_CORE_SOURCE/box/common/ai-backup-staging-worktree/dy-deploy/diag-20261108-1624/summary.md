# Diagnostic deployment — 2026-11-08 (Asia/Shanghai)

## Evidence availability
The requested execution.json, side-effects-before.json and side-effects-after.json have NOT been copied. RMSAMA became unreachable before sanitization/copy. They remain at C:\Users\rmsama\AppData\Local\Temp\dy-diag-exec-1624\. Do not describe execution.json as raw diagnosis JSON: the executor retained filtered enumerated diagnosis fields and discarded raw stdout/stderr.

## Connection / deployment
Connection succeeded at 16:24:20 Beijing time. Update SHA verification and py_compile passed at 16:25:36. Git check/apply reported no Skipped. Backup: C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_backup\douyin-diag-20261108-162536.

## SHA-256
| File | Before raw | Before normalized | After raw | After normalized |
|---|---|---|---|---|
| control.py | a1f10189a4adebc6a3563bd5585906dca3250d18db842cb8368b3ebb8cf84f32 | a3b4abbfa26f0ed679e989b245a7a1acde01d82e10023dc86196770dac32b43c | 46975b2fefa8f5983f5a46ec9f5ef87c59d3fa76db10839f456153edbcb1ebc0 | 009429c5008ec694e02df1a3fb047d6c311f6988185249e3645358b7c29a2554 |
| unknown_resolution.py | feb60099134fefcc414aa092ad2713ba54ae58081e7073dab8662f7ecd328e70 | feb60099134fefcc414aa092ad2713ba54ae58081e7073dab8662f7ecd328e70 | d16434a40c708574f0a64693ec89522b4ef4ccb9c19582d1a557475da3539d62 | d16434a40c708574f0a64693ec89522b4ef4ccb9c19582d1a557475da3539d62 |

## Exactly one diagnosis
Completed at 16:25:49, returncode 0. blocked_reason=read_incomplete; own_reply_state=unchecked; stage=own_reply_check; error_type=other; http_status=null; cli_error_code=none; pagination_complete=false. No second diagnosis, normal start, send or retry was invoked.

## Side effects
Queue, receipts, .submitted, authorization, status and task-lock snapshots unchanged. Ledger main/WAL mtime and size unchanged. shared.sqlite3-shm mtime DID change (1794126334858386700 to 1794126345478711900 ns), size remained 32768 bytes. control.lock was excluded from the unchanged check as approved. This is not zero file writes; SHM content equality was not verified. Parent subsequently accepted the SHM mtime difference as expected.

## Panel
Reopen command invoked the existing 打开本地进度.cmd at 16:26:23 Beijing time. Its output contained libpng warnings, but no PID confirmation. The command was still reported running after 108616 ms. No button was clicked. Panel PID is UNCONFIRMED; do not launch another panel blindly.

At 16:28:35 Beijing time, the follow-up command to confirm PID and sanitize existing evidence failed to spawn: Your computer "RMSAMA" is temporarily unreachable. Retry the request in a moment.
Stopped immediately with no retry. No evidence copy occurred. The prior reopen command's final state is unknown; do not claim it was stopped or completed.

## Next step
After an explicit connection-restored instruction: confirm the existing panel PID only (do not relaunch), sanitize/copy the three existing evidence files. Do not run another diagnosis or start sending.
