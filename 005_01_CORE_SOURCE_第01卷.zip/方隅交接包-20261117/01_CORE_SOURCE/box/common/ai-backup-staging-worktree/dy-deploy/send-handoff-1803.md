# 抖音发送交接包（泪痣）

时间：2026-11-08 18:12 Asia/Shanghai（北京时间，UTC+8）  
范围：只读核对 + 交接。**未启动发送，未运行 `--check-resume`，未安装 v3，未启动采集，未调用 post。**  
当前发送范围：仅账号标签 **泪痣**。其余四账号只在附录列出，不在本次发送范围。

路径约定：
- R = `C:\Users\rmsama\Documents\ChatGPT\自动获客系统`
- C = `R\work\douyin-local-control`
- T = `R\work\douyin-local-20261104-1e985ff064`（当前活动任务）
- N = `R\work\runtime\douyin-bridge\node.exe`
- 共享账本 = `R\work\shared-acquisition-ledger\shared.sqlite3`
- 文本入口 = `R\work\fangyu-text-business-20261029\各账号窗口统一回复入口.json`

---

## 1. 原可用发送入口（完整命令）

### 1.1 打开本地进度面板

文件：`C\打开本地进度.cmd`（SHA256 `dbd9a45afa4c016fb49f891822cabeb94fcba929ca6217434c8921a3eaf7ca32`）

```bat
@echo off
cd /d "%~dp0..\.."
start "" "C:\Users\rmsama\miniconda3\pythonw.exe" "%~dp0panel.py"
```

展开后：

```text
工作目录：C:\Users\rmsama\Documents\ChatGPT\自动获客系统
解释器： C:\Users\rmsama\miniconda3\pythonw.exe
命令：   C:\Users\rmsama\miniconda3\pythonw.exe "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\panel.py"
```

证据：本机读取该 cmd 第 1–5 行；`douyin-runtime.md` L25；`panel.py` L9–10。

### 1.2 点击「启动／继续」之后

`C\panel.py` `start()` L24–33：

```text
解释器： C:\Users\rmsama\miniconda3\python.exe
         （由当前 pythonw 同目录替换为 python.exe，panel.py L29）
脚本：   C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\control.py
工作目录：C:\Users\rmsama\Documents\ChatGPT\自动获客系统
         （cwd=P.parents[1]，即 R，panel.py L33）
附加参数：若 send_hold.hold_reason() 为真，则追加 --check-resume（panel.py L30–31）
```

等价命令：

```text
"C:\Users\rmsama\miniconda3\python.exe" "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\control.py"
```

当前本地 hold `blocked=false`，共享入口 `user_send_hold.active=false` 且 `new_sends_allowed=true`，因此 `hold_reason()` 按 `C\send_hold.py` L11–26 应返回 `None`，**点击启动不会自动带 `--check-resume`**。

### 1.3 control.py → runner → 适配器

无 `--check-resume` 时，`control.py` `main()` 在拿到 `control.lock` 后走到 L351 起的发送准备，而不是 L318 的检查分支：

1. `require_send_allowed()`（L351）
2. `connect_for_start()` → `account_probe.cjs`（L356，L19–23）
3. `prepare(identity)` 按 `C\accounts.json` 取已有任务目录，并写 `C\active.json`（L40–61、L361）
4. `resolve_task_on_start()` 启动时只读核对未知回执（L371；L263–280）。此步不启动 sender（L269–270 若 `start_sender` 会抛错）
5. `runner_script_after_resolution()` 在 `C\unknown_resolution.py` L390–398 选择：
   - `batch_reply_runner.py` 或
   - `resume_after_confirmation.py`
6. L384：

```text
"C:\Users\rmsama\miniconda3\python.exe" -u "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-20261104-1e985ff064\<script>"
工作目录：R
```

7. runner 再调用（`T\batch_reply_runner.py` L22–23、L281）：

```text
"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\runtime\douyin-bridge\node.exe" "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-20261104-1e985ff064\send_cli_once.cjs" "<attempt_path>"
```

无 attempt 路径、直接 post 的底层调用不是原入口，不得使用。

活动 T 的绝对路径：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-20261104-1e985ff064`  
证据：`C\accounts.json` 第 3 条登记目录；该目录 `cli-current-binding.json` 的 nickname=`泪痣`；与 `C\active.json` nickname 一致；runner `PREFIX` 第 26 行为 `douyin-local-20261104-1e985ff064-`。

---

## 2. 当前第一个技术卡点

**已安装的 0d1e252 下，若跳过面板、直接拉起 `T\batch_reply_runner.py`，`guard()` 会因 1 条未决 unknown 停住。**

现场计数（2026-11-08 18:08:37 Asia/Shanghai，共享账本只读，token 前缀 `douyin-local-20261104-1e985ff064-`）：

| 状态 | 条数 |
|---|---|
| sent | 877 |
| unknown | 9 |
| not_sent | 1 |
| reserved | 0 |
| 前缀合计 | 887 |

`T\captcha-recovery-authorization.json`（mtime 2026-11-08 17:32:38）：
- `preserve_unknown_comments` = 8
- **没有** `isolated_unknown_comments` 键
- 9 条 unknown 中：8 条已在 preserve 名单，**1 条未决**
- `reserved` = 0

`T\batch_reply_runner.py` L65–73：`skipped = preserve ∪ isolated`；`status in ('unknown','reserved')` 且 unknown 不在 skipped 中即视为阻断并抛「存在结果未知或未核验记录，禁止继续，也不会自动重发」。因此 `GUARD_WOULD_BLOCK=True`。

原按钮路径会先走 `control.py` L371 `resolve_task_on_start` → `unknown_resolution`：启动时只读核对应回执，读失败或不完整的那一条会写入 `isolated_unknown_comments`，不重发、不挡其余队列（`unknown_resolution.py` L1–7、L346–367；安装报告 `isolate-install-1738.md` L123：「运行中新出现的 unknown 仍需下次启动才会隔离」）。**本轮没有点击启动，也没有跑这段核对，所以那 1 条仍未隔离。**

不是卡点（避免误判）：
- 不要用采集侧 `identity_probe` 的「Expected exactly one active Douyin connection; got 2」来判断发送冲突。发送绑定的 `C\active.json` `connection_id=eb54c2c1-03b7-4be1-9198-bc6ff6092957` 当前在 Bridge `/api/status` 中为存活连接之一。
- 本地 `C\douyin-send-hold.json`：`blocked=false`，`released_at=2026-11-04T17:05:49.666112+08:00`。
- 共享入口 `user_send_hold`：`platform=douyin`，`active=false`，`new_sends_allowed=true`，`released_at=2026-11-04T17:05:49.664112+08:00`。
- 无 panel / control / runner / `send_cli_once` 进程（18:07:37 只见采集台 Bridge PID 5628）。
- `not_sent=1` 不进 `guard()` 阻断集；runner L195–196 遇到已有账本行会跳过、不自动重试。

授权问题（不是上面这条技术卡点，但交接必须写明）：当前 1520 条清单全部为 **待审**。2026-11-04 用户确认的 3 条不在此清单中。分类交接曾记录 `send_authorized=false`。不能把清单自带 `authorized=true` 当成逐条批准。

---

## 3. 1520 条清单与 17:47 审阅副本对照

对照源：
- 17:47 审阅副本：`/tmp/dy-readonly/approved-cli-queue.json`（拷到 box 的时间 17:46:29；私有审阅 `/workspace/dy-deploy/private/queue-review-1747.md` 生成于 17:47:16）
- 现场文件：`T\approved-cli-queue.json`（mtime 2026-11-08 17:32:29）

| 项 | 17:47 副本 | 现场 18:07 |
|---|---|---|
| 文件 SHA256 | `a3fac398d9b69bb1d807696ac068a003ebcee22aa0b85e96c95853cc8b3e207d` | 相同 |
| 条数 | 1520 | 1520 |
| `items_sha256` 字段 | `44017f81b191dd7ff6178be4a9bb67b5cb6524fb99b9658f596f479d668e120e` | 相同 |
| 条目列表 SHA256（有序列 `(cid, video, reply_sha256)`，JSON 紧凑） | `48c3714980d9f97ee976afe7d14f7ef5051d9c0eb948690275a7c240b964ca3c` | 相同 |
| 仅在 17:47 | 0 | — |
| 仅在现场 | 0 | — |

**结论：与 17:47 审阅副本完全一致。** 客户正文只在私有审阅文件中，本文不收录。

---

## 4. 泪痣账号绑定（非敏感）

| 来源 | 字段 | 结果 |
|---|---|---|
| `C\active.json` | `nickname` | 泪痣 |
| `C\active.json` | `account_uid` | 存在；SHA8=`1e985ff0` |
| `C\active.json` | `connection_id` | `eb54c2c1-03b7-4be1-9198-bc6ff6092957`（当前存活） |
| `C\active.json` | `status_code`、`task` | 键存在 |
| `T\approved-cli-queue.json` | 顶层 `account_uid` | 与 `active.json` 相同（`ACTIVE_UID_EQ_QUEUE_ACCOUNT_UID=True`，SHA8 同为 `1e985ff0`） |
| `T\batch_reply_runner.py` L25 | `ACCOUNT = ...` | 与队列顶层 `account_uid` 相同，也与 `active.json` 相同 |
| 采集计划 `account_uid` | SHA8 | 同为 `1e985ff0`（账号一致，不等于采集连接已钉住） |
| 队列每条 `uid` | — | 1520 个互不相同，且不等于顶层 `account_uid`。这是客户作者编号（runner `validate_queue` L99–103 禁止重复客户），**不是**发送账号字段 |

未读取 cookie、会话或凭据文件，未写出 `account_uid` 原文。

---

## 5. 发送进程、锁、计数，以及 0d1e252 如何跳过

### 5.1 进程（18:07:37 Asia/Shanghai）

相关匹配（panel / control / `batch_reply_runner` / `resume_after_confirmation` / `send_cli_once` / `打开本地进度`）：无。  
仅有采集台 Bridge：PID 5628，`抖音自用采集台\work\collector\server.js`。采集 runner / `app.py` 也未在跑。

### 5.2 锁与状态文件

| 文件 | 存在 | mtime | 说明 |
|---|---|---|---|
| `C\control.lock` | 是，0 字节 | 2026-11-04 10:38:41 | 磁盘上有锁文件；当时无 control 进程。未尝试占用该锁 |
| `T\batch-runner.lock` | 是，0 字节 | 2026-11-04 12:05:53 | 同样未见持锁进程 |
| `INDEP\continue-collection.lock` | 否 | — | 采集继续锁不在 |
| `T\batch-stop.json` | 否 | — | |
| `C\douyin-send-hold.json` | 是 | 2026-11-04 17:05:49 | `blocked=false`；`no_auto_resume=true`；`reason` 为已确认继续核验通过的 3 条（那 3 条不在当前 1520 清单） |
| `C\hold.json` | 否 | — | |

文件在磁盘上不等于锁被占用。

### 5.3 已安装 0d1e252 的跳过方式（启动时隔离，不是运行中隔离）

安装报告：`/workspace/dy-deploy/isolate-install-1738.md`。七文件已按 0d1e252 核对。

启动时（点击启动／继续之后，runner 之前）：
- `unknown_resolution.select_stuck` / `unresolved_blockers` / `receipt_blocks_queue`（L263–367）：`preserve_unknown_comments ∪ isolated_unknown_comments` 中的 unknown 不再阻断；`reserved` 仍阻断。
- `control.py` L90–98 `preserve_previous_unknown` 使用同一套判定。
- `resume_after_confirmation.py` L34：approved 集合含 isolated。
- runner `guard()` L68–71 与循环内 L192–194：已决定的 unknown 直接 `continue`，不重发。

运行中（当前已装 runner L298–313）：
- unknown 且 `preserve_unavailable`（视频详情不可用）→ 继续
- `not_sent` 且 `skip_target`（目标完整读取后不可见）→ 继续
- **其余 unknown → 整队停止**（「已保存CLI返回结果并停止；不会自动重发」）
- 新出现的 unknown 要等下次启动才可能被隔离

账本里这 1 条未决 unknown 正是启动核对要处理的对象；本轮未跑核对，未知记录全部保留。

---

## 6. 运行中隔离 v3：需要另行批准，未执行

v3（commit `acd6c08bea03199e8f50593bf5df570dd579932e`）是在已装 0d1e252 之上，给**运行中**的失败条目标隔离并继续其余已审队列。离线验收见 `/workspace/dy-acceptance/inrun-isolation-v3-acceptance.md`。**不是现场可发，不得自动安装。**

生产三文件（相对已装 0d1e252）：

| 文件 | 角色 | v3 SHA256 |
|---|---|---|
| `C\publish_recovery.py` | 新增 `in_run_non_sent_action` / `isolate_unknown_in_run` / `stop_identity` | `5575679f1a0c75824c53b773862846b0654ecc4c09f6972350d1eec24672b01a` |
| `T\batch_reply_runner.py` | 非 sent 后按动作继续或停（含 `stop_identity`） | `9b373e6e4314608cea8dc97671bb41c2f1d40c55651e70fbd7a136576f34a037` |
| `T\prepare_verified.py` | 批准集合改为 preserve ∪ isolated | `de4b52b568e84b108aafc42e6363aa6183c7044f6f4e31b1214167de3ef0e224` |

补丁：制品目录 `inrun-isolate-deploy.patch`，32965 字节，SHA256 `919983efb2d896c7e0d8a3774874e847cc77de55408c74fa6355bbe9440cf1ae`。`git apply --stat`：6 个文件（上述三文件 + 三份测试）。

与已装 0d1e252 的差异（不要用「got 2」理解这个差异）：
- 已装：启动时隔离；运行中除「视频不可用 / 目标不可见」外，unknown 停整队。
- v3：运行中把一般 unknown 标为 `continue_isolated` 并继续；验证码 `3002123` 仍停；提交前身份 `not_sent` 走 `stop_identity` 停整队。
- 无次数阈值。

建议安装命令（**仅在用户另批后**；不要整目录覆盖；`task/` 不能用 `--directory=work`，否则会打到 `work\task\`。这与 0d1e252 安装时相同）：

```text
:: 备份三份生产文件
mkdir "R\work\_backup\douyin-inrun-v3-<stamp>"
copy "C\publish_recovery.py" "R\work\_backup\douyin-inrun-v3-<stamp>\douyin-local-control\"
copy "T\batch_reply_runner.py" "R\work\_backup\douyin-inrun-v3-<stamp>\task\"
copy "T\prepare_verified.py" "R\work\_backup\douyin-inrun-v3-<stamp>\task\"

:: 将补丁按路径拆成 control 与 task 两段后：
git -C "R" -c core.autocrlf=false apply --unidiff-zero --directory=work --check --verbose isolate-control-part.patch
git -C "R" -c core.autocrlf=false apply --unidiff-zero --directory=work isolate-control-part.patch
git -C "R" -c core.autocrlf=false apply --unidiff-zero -p2 --directory=work/douyin-local-20261104-1e985ff064 --check --verbose isolate-task-part.patch
git -C "R" -c core.autocrlf=false apply --unidiff-zero -p2 --directory=work/douyin-local-20261104-1e985ff064 isolate-task-part.patch
```

不要覆盖队列、账本、`accounts.json`、回执、`.submitted`、`send_cli_once.cjs`。模板 `work\douyin-round2-task5\` 不是当前活动任务的必需落地。本轮未执行上述任何一步。

---

## 7. `--check-resume` 恢复检查：已读代码，未执行

用户原话『重新启动发送』覆盖它所需要的平台读取；但父代理要求：若任何分支会碰到 `batch_reply_runner` 进程、`send_cli_once` 或 post，就不要运行，只把命令和效果写入本包。

### 7.1 调用链与行号（已装 0d1e252 / 对照树 `control.py`）

`sys.argv[1:] == ['--check-resume']` 时：

1. `main()` L297–316：先抢 `C\control.lock`。抢不到则打印锁占用结果并返回，不发送。
2. L318–328：写入 `C\status.json` `mode=resume_check`，调用 `check_resume()`，再写入 `status.json` 后 **`return`**。
3. **不会**走到 L351 `require_send_allowed`、L361 `prepare`、L371 `resolve_task_on_start`、L384 的 `subprocess.run(... task/script)`。因此不会作为子进程启动 `batch_reply_runner.py` / `resume_after_confirmation.py`，也不会走到 attempt 路径上的 `post()`。

`check_resume()` L100–143：

1. L102 `probe(timeout=25)` → L19–23：`N` + `C\account_probe.cjs`（平台身份读取，不是 post）。
2. L104–107：用 `C\accounts.json[account_uid]` 找任务；没有任务则返回文案，结束。
3. L112：`import batch_reply_runner as runner`（导入模块，不调用 `execute()` / `main()`）。
4. L117–120：`runner.guard(runner.ledger_rows())`，异常只标记 `blocked_by_receipt`。
5. L121–126：读队列头。当前清单 `prepared_by=douyin-classification-ready-v1`，走 `time_priority.unattempted_items`。
6. **若存在队首（当前 1520 条，极可能有）**，L133–134：

```text
runner.run_json([runner.NODE, runner.ADAPTER, '--preflight', next_item['video'], next_item['cid'], identity['connection_id']], timeout=35)
```

即：

```text
"<N>" "<T>\send_cli_once.cjs" --preflight <video> <cid> <connection_id>
```

`T\send_cli_once.cjs` L4–6、L29–47：`--preflight` 不会执行 L72 的 `post(...)`，但会：
- 调用 Bridge `status()` 和页面资料读取（L30–35）
- `readTarget` 分页读目标评论（L39–46）
- 写入 `T\<cid>-read-checkpoint.json`
- 若存在则更新 `T\batch-runner-status.json`

因此：**检查分支会到达 `send_cli_once.cjs`（`--preflight`），虽然不到 post。** 按「不要碰到 send_cli_once」的限制，本轮不运行。

### 7.2 若执行，原命令应是

```text
解释器： C:\Users\rmsama\miniconda3\python.exe
脚本：   C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\control.py
参数：   --check-resume
原工作目录（panel.py L33、打开本地进度.cmd L3）：C:\Users\rmsama\Documents\ChatGPT\自动获客系统
control.py 自身用 __file__ 定位 C 与 R，不依赖 cwd 来找脚本。
```

### 7.3 实际运行记录

**未运行。** 因此：
- 无退出码、无 stdout/stderr
- 未改任何状态文件，没有前后 SHA/mtime 对照
- `read_incomplete` 未检查、未清除
- 未知记录全部保留
- 只打算跑一次，也不存在第二次

若之后要跑，须先另行确认：允许 `--preflight` 这种 `send_cli_once` 读取（会写 checkpoint / 可能改 `batch-runner-status.json`），并且当时没有 panel/runner 进程。

---

## 8. 单人操作警告

总指挥一旦接手发送：
- 不要同时再开第二个 panel / `control.py` / `batch_reply_runner` / `resume_after_confirmation`（`control.py` L353–354 `foreign_runner_locked`；`T\batch-runner.lock`；`resume_after_confirmation.py` L24–30）。
- 不要与采集操作并行：采集 `runner.cjs`、`continue_collection.py` 或另一条发送 runner 同时跑，会争用同一 Bridge、同一账号页和共享账本。
- 本包不启动采集。采集此刻未在运行；其 `control.json` 仍是 `stopped=ledger_unknown`，`pending=null`，`nextIndex=9`。不要在发送进行时另起采集。

---

## 9. 附录：五账号登记（非敏感标签）

Codex 交接把共享账本与分账号任务写在：
- 共享账本：`R\work\shared-acquisition-ledger\shared.sqlite3`（`codex-handoff-20261108-1731.txt` L96、L214）
- 文本总入口：`R\work\fangyu-text-business-20261029\各账号窗口统一回复入口.json`（同文件 L436；`C\send_hold.py` L8 也读它的 `user_send_hold`）
- 账号→任务目录登记：`C\accounts.json`，由 `C\control.py` `prepare()` L40–61 和 `check_resume()` L104–105 使用。键是 `account_uid`（本文不写出），值是任务目录。

本机 18:12:02 只读：`accounts.json` 恰好 **5** 条，目录都存在。`各账号窗口统一回复入口.json`（mtime 2026-11-05 18:40:22）是策略/暂停入口，**不内含五账号名单**。它当前的发送暂停为关闭：`user_send_hold.platform=douyin`，`active=false`，`new_sends_allowed=true`。

每账号各自一份 runner，限额写法相同：
- `batch_reply_runner.py` L27：`LIMIT = None  # User 2026-11-02 removed the 200-success ceiling.`
- 同文件约 L149/186（各任务行号略有偏移）：仍留有「无200条上限」打印，以及 `LIMIT is not None` 时才生效的「本批累计200条，已停止」——当前 `LIMIT is None`，200 条上限不生效。
- `publish-pacing.json`：`{"write":[1,1]}`（本地 1 秒节奏；Codex L206 对应 `risk-control.js` 返回 `[1,1]`）。这是本地节奏，不是平台无限速许可。

| # | 非敏感标签 | 任务目录（accounts.json 值） | 绑定证据 | 每账号限额 |
|---|---|---|---|---|
| 1 | 绑定文件无 nickname 字段 | `R\work\douyin-local-20261104-95e6412985` | `cli-current-binding.json` 仅有 `account_uid,connection_id,verified_at`；队列 1993 条 | `LIMIT = None`（runner L27）；`publish-pacing.json` `write:[1,1]` |
| 2 | 绑定文件无 nickname 字段 | `R\work\douyin-local-20261104-b80bc752b3` | 同上键；队列 8074 条 | 同上 L27 / `write:[1,1]` |
| 3 | **泪痣**（本次发送范围） | `R\work\douyin-local-20261104-1e985ff064` | `cli-current-binding.json` nickname=泪痣；与 `C\active.json` 一致；队列 1520 条 | 同上 L27 / `write:[1,1]` |
| 4 | 小烨Cc. | `R\work\douyin-local-20261104-40aaf15b06` | `cli-current-binding.json` nickname=小烨Cc.；队列 1586 条 | 同上 L27（打印在 L146/183）/ `write:[1,1]` |
| 5 | Aliie✨ | `R\work\douyin-local-20261104-94e62190af` | `cli-current-binding.json` nickname=Aliie✨；队列 1690 条 | 同上 / `write:[1,1]` |

历史发送目录 `work\douyin-send-task2` / `task3` / `task4` 仍在磁盘上（Codex 第二任务「北斗Enzo（RMsama）」、第三任务「uu（loubeidou666）」、第四任务当时未完全定名），**不是**当前 `accounts.json` 的五条登记，也不在本次发送范围。未把这些历史名称套到上面缺 nickname 的两个目录上。

其余四账号：不新建队列、不拆账本、不做开发改动、不启动它们的 runner。只共享账本防重。

---

## 10. 采集（仅状态，未操作）

采集从未在本轮启动。最后现场：无 `runner.cjs` / `app.py`；`control.json` 仍为 `stopped=ledger_unknown`。身份核验此前失败，本轮不再处理。发送优先，采集独立且未干预。

---

## 11. 本轮明确未做

- 未点面板启动／继续，未运行 `control.py`（含 `--check-resume`），未运行 `batch_reply_runner` / `resume_after_confirmation` / 无参数的 `send_cli_once` / `post`
- 未安装 v3，未改已装 0d1e252 文件
- 未清除 unknown，未改账本、队列、授权 JSON
- 未启动或停止采集
- 客户正文不在本文件；完整拟发正文只在 `/workspace/dy-deploy/private/queue-review-1747.md`
