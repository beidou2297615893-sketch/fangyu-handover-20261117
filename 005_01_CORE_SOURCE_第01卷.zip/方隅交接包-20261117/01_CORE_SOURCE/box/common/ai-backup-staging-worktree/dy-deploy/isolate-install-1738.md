# 隔离补丁 0d1e252 安装报告

时间：2026-11-08 17:35–17:38 Asia/Shanghai（北京时间 / 中国标准时间，UTC+8）
结果：**安装完成。** 已备份、已安装 7 个文件、哈希与语法检查通过。未重新打开面板，未启动 CLI/runner，未联网，未诊断，未发送。

## 授权与范围

延续用户 17:28 对总指挥 t233s754 安装卡的批准：「同意先备份并安装这版抖音修改，仅核对安装结果，不启动、不联网、不发送。」关闭空闲面板被视为该批准内必要、可逆的一步，不是启动、联网或发送。

范围：仅通用源 5 文件 + 活动任务 `douyin-local-20261104-1e985ff064` 的 `batch_reply_runner.py` 与 `resume_after_confirmation.py`。未改模板 `work\douyin-round2-task5\` 两文件。

## 连接实证

- 机器：RMSAMA，machineId `f79a5338-7ab9-41e1-bad0-3f5c3b1dd392`，kind=desktop（上一轮 ListMachines 为 `connected=true`，本轮命令均在该机成功执行，未断线、未循环重试）。
- COMPUTERNAME=`RMSAMA`。
- 补丁拷贝后 SHA256：`3535b81c2dc8322f6aede8b4233c297de314e4783f42ab9c14d7dc2ba653efef`（与清单一致）。
- 完整补丁路径（本机临时目录）：`C:\Users\rmsama\AppData\Local\Temp\dy-isolate-install\isolate-deploy.patch`
- 为避免 `git apply --directory=work` 把 `task/` 打到错误的 `work\task\`，将完整补丁按原字节拆成：
  - `isolate-control.patch` SHA256 `7ca7ad72a1248982f09deb56e89bb9219cab47fac8c443041cc4a7b59d62ee2f`（24594 字节）
  - `isolate-task.patch` SHA256 `f16788bff0cd25deedfd5fd7ff30157d229bb5e7797771e2f4db9d6ff1c7849a`（2819 字节）
  - 两段拼接字节与完整补丁完全一致。

## 进程检查与结束面板

查询：`Get-CimInstance Win32_Process`，匹配 panel / control / runner / `send_cli_once` / `douyin-bridge\node.exe` / 活动任务路径。

### 结束前（2026-11-08 17:35:29 / 精确 UTF-8 复核 17:36:03）

| 项 | 结果 |
|---|---|
| PID 52784 是否存在 | 是 |
| Name | `pythonw.exe` |
| ExecutablePath | `C:\Users\rmsama\miniconda3\pythonw.exe` |
| CommandLine | `"C:\Users\rmsama\miniconda3\pythonw.exe"  "C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\panel.py"` |
| 与预期面板路径完全一致 | 是（`EXPECTED_PANEL_IN_CMD=True`） |
| runner / send_cli_once / node / control.py | 无 |
| 其他相关进程 | 无（仅此 1 个） |
| 发送活动 | 无 |

身份与 17:31 记录的空闲面板一致，无新活动，因此只结束该 PID。

### 结束动作（约 17:36:10）

```
taskkill /PID 52784 /F
```

本机返回：`成功: 已终止 PID 为 52784 的进程。` 未结束其他 Python 进程，未动浏览器，未清任何状态。

### 结束后（2026-11-08 17:36:14）

- PID 52784：不存在
- 相关进程：无
- 发送活动：无

安装完成后再次检查（2026-11-08 17:38:41）：PID 52784 仍不存在，相关进程无，发送活动无。未重新打开面板。

## 备份

主备份（成功安装所依据的那份，内容与安装前 23ba734 等价原文一致）：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_backup\douyin-isolate-20261108-173827`

另有一次中途失败后的同内容备份（见下节）：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\_backup\douyin-isolate-20261108-173741`

两份备份都按相对路径保存了这 7 个文件，拷贝哈希与当时原文一致。

## 安装过程

1. **第一次尝试（17:37:41）**  
   C 目录 5 文件：`git -C R -c core.autocrlf=false apply --unidiff-zero --directory=work --check --verbose` 通过，无 Skipped；随后 apply 全部 cleanly。  
   T 两文件：误用 Windows 绝对路径作为 `--directory`，`git apply` 返回 `error: invalid path`（exit 128）。按规则立即从 `douyin-isolate-20261108-173741` 恢复全部 7 个文件，恢复后哈希均与安装前一致。
2. **第二次尝试（17:38:27）**  
   先再次备份到 `douyin-isolate-20261108-173827`（安装前哈希与上一次相同，说明恢复有效）。  
   C 目录：同样命令 `--check --verbose` 通过，无 Skipped；apply 5 文件全部 cleanly。  
   T 两文件：改为  
   `git -C R -c core.autocrlf=false apply --unidiff-zero -p2 --directory=work/douyin-local-20261104-1e985ff064 --check --verbose`  
   通过，无 Skipped；apply `batch_reply_runner.py` 与 `resume_after_confirmation.py` 全部 cleanly。  
   `R\work\task` 未出现（`WORK_TASK_EXISTS=False`）。

未用脱敏导出文件覆盖生产文件（生产 `control.py` 与活动 `batch_reply_runner.py` 含账号常量；补丁未改这些行）。哈希核对应：无账号常量的文件直接对 0d1e252 列；这两份先将 `MS4w…` 替换为 `<REDACTED_ACCOUNT>` 再对 0d1e252 列。未打印账号或客户内容。

## 七文件哈希

| 路径 | 安装前 SHA256 | 安装后 SHA256 | 预期 0d1e252 | 是否匹配 |
|---|---|---|---|---|
| `C\control.py` | raw `46975b2fefa8f5983f5a46ec9f5ef87c59d3fa76db10839f456153edbcb1ebc0`（脱敏 `009429c5…2554`，即 23ba734） | raw `49ed7f5c38ba94017b09f2daa71d63fc09e4c2cac0afaf8e5de416dc6f41d225`；脱敏 `c6b8681b1f8d407441b4b72835e1e82004398cb9661b931a12aa064617859423` | `c6b8681b1f8d407441b4b72835e1e82004398cb9661b931a12aa064617859423`（按脱敏比较） | 是 |
| `C\panel.py` | `1e9711000d724b6e37637556255a2a882405e19254c22408a9cebb36e5fc7ebf` | `9069729b61de78a1639852b8b3084667de2b72c365f47c94520302c31e845dad` | `9069729b61de78a1639852b8b3084667de2b72c365f47c94520302c31e845dad` | 是 |
| `C\send_hold.py` | `ae64446fd6a125cb6e3fa5fc355c2543e6b0cd127b52bd6fdeee7cd1349f69e3` | `9e0d78c26e3c37814a4c9d720e34e25ab639649b9321c29c38404b5f7f62bed4` | `9e0d78c26e3c37814a4c9d720e34e25ab639649b9321c29c38404b5f7f62bed4` | 是 |
| `C\target_reader.cjs` | `1d3d2cc8be5be275b9fcdf7e2eb81cf2c610f9c2d0925136e15d81f91d9c2ee0` | `49ed5cdd33b4c852ca89a6a72582bf1a78b930120d68ab511370d9ab5d2f8e9d` | `49ed5cdd33b4c852ca89a6a72582bf1a78b930120d68ab511370d9ab5d2f8e9d` | 是 |
| `C\unknown_resolution.py` | `d16434a40c708574f0a64693ec89522b4ef4ccb9c19582d1a557475da3539d62` | `0b6bbb1c68b39b49b090852d9d8fbfacc11d56f240fa775145c7fa55b3660a30` | `0b6bbb1c68b39b49b090852d9d8fbfacc11d56f240fa775145c7fa55b3660a30` | 是 |
| `T\batch_reply_runner.py` | raw `aa7e687f7c1d0d3852c037fab68e4792c1f56efc73c138a65f537d280110dfa2`（脱敏 `3b22dda8…82a1`，即 23ba734） | raw `ec709bf5e0f40251723b928591c2e3d5511f72d3df7a7b502b0ea96a4c43531c`；脱敏 `5888835a6cc034b9d56d69fd731fe61155a78997d51bcc89b318294c56747c17` | `5888835a6cc034b9d56d69fd731fe61155a78997d51bcc89b318294c56747c17`（按脱敏比较） | 是 |
| `T\resume_after_confirmation.py` | `82b2384420c1ac0bf9c2ac8cf6c5b80bb13b9c16457936851eac61d6f3835d2c` | `6f5b23de08bfa9c3237ff422ec4c6562a00ec9c4d7017fe0ab0902e5ed590c0f` | `6f5b23de08bfa9c3237ff422ec4c6562a00ec9c4d7017fe0ab0902e5ed590c0f` | 是 |

`control.py` 与活动 `batch_reply_runner.py` 的原文哈希因生产账号常量与脱敏清单不同，这与 16:25 / 本次安装前基线的解释相同；补丁未改账号行。

## 语法检查（不执行程序）

`py_compile.compile(..., doraise=True)`，输出写到临时目录，不作为运行入口：

- `control.py` OK
- `panel.py` OK
- `send_hold.py` OK
- `unknown_resolution.py` OK
- `batch_reply_runner.py` OK
- `resume_after_confirmation.py` OK

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\runtime\douyin-bridge\node.exe --check`：

- `target_reader.cjs` OK（exit 0）

观察到 `douyin-local-control\__pycache__` 与活动任务目录 `__pycache__` 目录存在；语法检查的字节码写在临时目录，未删除这些原有缓存目录。

## 范围外 / 未做

- 未改账本 `shared.sqlite3` / `-wal` / `-shm`、队列、授权、回执、`.submitted`
- 未改模板 `work\douyin-round2-task5\batch_reply_runner.py` 与 `resume_after_confirmation.py`
- 未访问抖音或其他平台网络，未诊断，未发送
- 未启动面板、CLI、runner 或 control
- 未打印账号或客户内容
- 安装不等于可以发送；运行中新出现的 unknown 仍需下次启动才会隔离

临时辅助文件仍在 `C:\Users\rmsama\AppData\Local\Temp\dy-isolate-install\`（检查脚本、拆分补丁、安装脚本），不在项目业务目录内。
