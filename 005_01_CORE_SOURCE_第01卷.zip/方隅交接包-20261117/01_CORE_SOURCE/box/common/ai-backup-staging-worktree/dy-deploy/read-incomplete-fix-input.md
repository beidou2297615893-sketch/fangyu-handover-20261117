# 原云端任务最小修复输入：评论读取不完整

仅 box 离线证据整理；未访问 RMSAMA、联网、诊断、启动代理或修改程序。复用原云端任务 bc-1125a7e0-aeb1-54b9-9523-eb5917b18e1d，不重建发送链。

## 1. 唯一已存现场结果

北京时间 2026-11-08 16:25:49：
```text
blocked_reason=read_incomplete
stage=own_reply_check
own_reply_state=unchecked
error_type=other
http_status=null
cli_error_code=none
pagination_complete=false
```
来源：`/workspace/dy-deploy/diag-20261108-1624/summary.md:15-16`。此为执行时筛选后的枚举摘要，非原始 CLI stdout，不能推出浏览器掉登录、网络故障或没有发出旧回复。

部署版本证据：同文件 `:7,12-13`；诊断 patch SHA 为 c7286aaec10ba4a8e3a9ad56db4703ca44e0a2a5c2b9b7c94f1843301d1ff0cc；两文件规范化最终 SHA 见 `/workspace/dy-deploy/diagnose-sha.txt:10,12`。独立验收只覆盖定点安全条件，不是平台全链验收。

## 2. 原读取路径与精确来源

下面行号均指 box 证据文件本身；补丁行号不是声称现机源码行号。括号内源码行号仅在补丁 hunk 明示时注明。

- `douyin-local-control/control.py`：`prepare_resolution()` 内 `read_reply()` 构造原核对命令、capture stdout/stderr、取最后一行 JSON，交 `diagnosis_from_cli()`。
  - `/workspace/dy-deploy/diagnose-deploy.patch:40-77`；hunk 指 read_reply 从源码223附近开始，subprocess 为235附近的变更。
  - `diagnose_task_unknown()` 复用这个 reader，ensure_adapter=False；同 patch `:96-108`（源码279起）。不是发送入口。
- `douyin-local-control/unknown_resolution.py`：`build_verify_command()` 返回 node + adapter + `--verify-own-reply` + video/cid。
  - `/workspace/dy-deploy/full.patch:979-983`。
- `task/send_cli_once.cjs`（现机为活动任务目录中的同名脚本）：verifyOwn 分支加载旧尝试、校验绑定，调用 `readOwnReply()`，包装为 `{status:own_reply_check, diagnosis, submission_attempted:false}` 并 return。
  - `full.patch:1321-1334`；hunk 对应源码49-62。
- `douyin-local-control/target_reader.cjs`：
  - `buildReplyPageCheck()`：`full.patch:357-400`；调用已有 window.__bridge.getDetail/getComments/getReplies，识别返回结构、游标、内嵌回复和读超时。
  - `readOwnReply()`：`full.patch:402-471`。client.call 与连接校验 `:409-413`；unfinished 结果裁剪 `:414-417`；评论页循环 `:425-448`；回复页循环 `:455-470`。
  - `matchOwnReply()`：`full.patch:334-354`；需要原账号、原草稿及目标匹配，不可放宽匹配来凑成功。
- Python 诊断/门禁：
  - `diagnosis_from_cli()` 原包装 `full.patch:986-999`，新版 `diagnose-deploy.patch:326-347`。
  - `classify_diagnostic()`：`diagnose-deploy.patch:225-284`；`sanitize_diagnostic()` `:287-309`；`diagnostic_from_read()` `:319-323`。
  - `diagnose_unknown()`：`diagnose-deploy.patch:479-517`；仅当分类不是 found/not_found（且非 identity）时报告 read_incomplete。
  - 正常启动 `resolve_on_start()` 的不完整停线：`full.patch:1243-1269`，新版 `diagnose-deploy.patch:460-467`。

## 3. 可能形成 read_incomplete + other 的分支（均为假设，不是已证实根因）

### A. 与本次 own_reply_check / unchecked / none 一致的候选

所有候选最终都须经过 classify_diagnostic 的兜底：`diagnose-deploy.patch:266-277`。该分支在 stage=own_reply_check 时给 other/none；不是 CLI 返回“没有错误”。

|假设|原 reader 分支|为何可能落 other|
|---|---|---|
|H1：视频详情缺失|readOwnReply 返回 unfinished(no_video_detail)：`full.patch:433-435`；详情来源 `:369-374`|reason 不在分页枚举映射中，detail_status 也未被 _platform_code 读取。|
|H2：视频详情状态/标识无法确认，含缺字段|unfinished(video_unverified)，同 `:433-435`；response.value 缺失被转空对象见 `:412`|同上；不能等同身份异常或视频删除。|
|H3：评论页数据不合法/状态非0/缺字段|buildReplyPageCheck `:382`；readOwnReply unfinished(comments_status) `:436`|reason=comments_status 没有固定映射。_platform_code 虽读取 comments_status，但仅 stage=read_result 才将其作为平台错误分类（诊断 patch `:209-216,269-272`）；当前是 own_reply_check。|
|H4：回复页状态非0/字段缺失|同构检查 `full.patch:382`，回复循环 `:464`|与H3相同。|
|H5：正常 own_reply_check 包装里有 unchecked/其他不完整结构，却缺已识别 reason/标志|Python复制 diagnosis：`full.patch:996-998`，新版赋 diagnostic：`diagnose-deploy.patch:347`|无匹配标志就 other；需要原枚举字段才能区分，不能断言确已出现。|

H1-H4还须无超时、HTTP、身份、网络等更高优先级匹配。平台状态码本身不是 HTTP 状态；http_status=null 不证明平台状态为0。

### B. 可产生同类组合，但与本次 stage/own_reply_state 不一致的候选

- H6：`prepare_resolution.read_reply` 遇未知适配器异常，经 failed → classify_diagnostic('adapter',...) 兜底 other；诊断 patch `:48-58`。明确 VerifyModeMissing 会是 missing_param，不在此候选内。stage不同。
- H7：`_read()` 捕获未识别异常，或 hook 返回非字典，分别经 read_exception/read_result；诊断 patch `:391-401`。只有不被已识别错误优先分支命中时 other；本次stage不同。
- H8：`diagnostic_from_read()` 的无 diagnostic 降级，reason 未命中映射时 other；诊断 patch `:319-323`。read_result stage，不吻合本次。
- H9：提供的 diagnostic 中 error_type 不在白名单，被 sanitize 改 other；诊断 patch `:287-309`。现有正常路径自己生成已枚举类型，非已证明的生产来源。
- H10：found 但证据不匹配，或 not_found 缺目标/提交条件，最终 classify=unchecked，但原 own_reply_state 未必为unchecked。证据校验 `full.patch:1039-1081`；条件不满足但未触发分页/超时分类时，可有 other；不等同本次完整元组。
- H11：诊断总入口异常 catch，直接输出 read_incomplete/other；诊断 patch `:150-153`。其 stage=gate、cli_error_code=other，且无 items，不吻合本次。

### C. 分页的其他退出：需修准，但正常不应被解释为本次 other

- scan_budget：`full.patch:426,456`；reply_list_unavailable `:463`；target_not_visible `:448`；incomplete：评论下一游标缺失/游标重复/100页上限 `:427-428,444-447`，回复对应 `:457-458,467-470`。诊断 patch `:243-249,262-263` 正常映射 pagination_incomplete。
- read_timeout：`full.patch:397,432,462`；诊断 patch `:235-236,250-251` 正常映射 timeout。
- 非 JSON、进程启动失败、90秒超时：诊断 patch `:70-77,328-345`，通常给对应枚举而不是本次 own_reply_check/other。
- 正常 not_found 完整结果也可能有 diagnostic.error_type=other/none（没有失败优先标志），但 classify=not_found，不会因此产生 read_incomplete。不能把 other 字段单独当故障判定。

以上是当前可见调用链的分支清单；桥接服务/平台内部未知实现不在离线证据覆盖内，不声称已穷尽平台根因。

## 4. 当前交付与所需修复之间的缺口

- 当前交付已做到独立诊断入口、禁止误入发送、枚举脱敏和停线；没有证明评论分页可在现场完成。
- reader 已返回细分 reason/数值状态，但对视频详情/评论状态等分支，Python分类会压成 other；最终诊断 items未保留细分 reason。本次保存过程又只保留指定枚举并丢弃原stdout，不能逆推分支。
- 正常评论/回复返回结构、游标推进/终止、耗时预算是否与真实 bridge 返回契合，未有本次字段级证据；这些均交原云端任务核实，不预设平台接口变更。
- 需要合成覆盖每个上述退出和错误映射，证明：完整 not_found 才允许原规则 preserve；不完整/身份/验证码继续停线；不新增发布路径、重试或授权写入。
- 精确子因必须固定枚举，配数字状态/布尔完整性；不记录原stderr片段、URL、账号、对象ID、客户正文或令牌。

## 5. 目标与不变约束

**目标：让原来的评论读取正确完整完成，或者报告精确子因。**

复用原 control → send_cli_once → target_reader → bridge 调用，不重建链路、不发送、不部署、不联网试跑。不要改 unknown 跳过规则：未完整读取不是“确认没回复”；unknown不重发，不清账号/验证码/停线；保留原预览和批准流程。本输入不是新发送或二次诊断授权。

## 6. 材料是否足够 / 唯一必要现场字段记录

- **足够**让原云端任务开始修“把可见 reader 原因准确映射成安全枚举”，并补全合成分支测试；已有源码上下文及原任务代码，无需新代理或重建。
- **不足**锁定本次平台读取究竟落H1/H2/H3/H4哪支，更不足承诺现场读完。
- 唯一必要现场字段记录：**16:25这一次 `--verify-own-reply` 的 `diagnosis.reason` 枚举值**，只允许 reader 已定义的 no_video_detail/video_unverified/comments_status/scan_budget/read_timeout/target_not_visible/reply_list_unavailable/incomplete，不转述任何任意原字符串；缺失就记 missing，不取账号/正文。
- 若有已存在的该次 CLI 输出/日志，只读抽取这一字段即属原只读核查范围，不运行新命令链。本执行记录明确 raw stdout 被丢弃（summary.md:4），现有 status摘要没有该字段；不能承诺某个log tail一定还能找回，也不要求反复搜索。
- 若原字段未保存，记录为“证据已丢失”。先让云端在原读取返回中保留枚举子因；要获取新的现场样本，必须另行批准一次限定旧unknown的只读核查。此前一次诊断额度已用，不能自动再跑。
