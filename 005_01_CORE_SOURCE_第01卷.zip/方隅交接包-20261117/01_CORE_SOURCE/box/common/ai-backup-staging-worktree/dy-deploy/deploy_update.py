import pathlib,json,subprocess,hashlib,datetime,shutil,os,time,py_compile,re,msvcrt
B=pathlib.Path(__file__).resolve().parent
R=pathlib.Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统');W=R/'work';C=W/'douyin-local-control';T=W/'douyin-local-20261104-1e985ff064'
rows=json.loads((B/'baseline-preflight.json').read_text());paths={r['file']:(W/r['file'] if not r['file'].startswith('task/') else T/pathlib.Path(r['file']).name) for r in rows}
unknown=C/'unknown_resolution.py'; log=[];backup=None;changed=False

def say(s):log.append(s);print(s,flush=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def processes():
 p=subprocess.run(['powershell','-NoProfile','-Command','Get-CimInstance Win32_Process | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json -Compress'],capture_output=True,encoding='utf-8',errors='replace',check=True)
 return json.loads(p.stdout)
def runners(ps):
 return [p['ProcessId'] for p in ps if str(p['Name']).lower() in ('python.exe','pythonw.exe','node.exe') and any(x in str(p.get('CommandLine') or '').lower() for x in ('control.py','batch_reply_runner'))]
def baseline():
 for r in rows:assert digest(paths[r['file']])==r['baseline_expected'],'baseline changed: '+r['file']
 assert not unknown.exists(),'unknown_resolution.py unexpectedly exists'
def command(args,cwd):
 p=subprocess.run(args,cwd=cwd,capture_output=True)
 # git/compiler/node diagnostics carry code excerpts; show only success and retain no account literals.
 assert b'Skipped patch' not in p.stderr+p.stdout,'Git skipped patch'
 assert p.returncode==0,'command failed: '+pathlib.Path(str(args[0])).name+' '+str(args[1:2])+' rc='+str(p.returncode)
 return p
try:
 baseline();say('BASELINE all six exact; unknown_resolution absent')
 ps=processes();assert not runners(ps),'runner running; pids='+str(runners(ps))
 lp=C/'control.lock';pid=None
 if lp.exists():
  b=lp.read_bytes()
  if b.strip().isdigit():pid=int(b.strip())
  if pid is not None:assert not any(p['ProcessId']==pid for p in ps),'control.lock pid alive'
  with lp.open('rb') as handle:
   handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_NBRLCK,1);handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
  say('LOCK probe passed; exists; recorded_pid='+str(pid)+'; live matching control/runner processes=0; lock untouched')
 else:say('LOCK absent')
 panels=[p for p in ps if str(C/'panel.py').lower() in str(p.get('CommandLine') or '').lower().replace('/','\\') or (p['ProcessId']==50372 and 'panel.py' in str(p.get('CommandLine') or '').lower())]
 for p in panels:
  assert p['Name'].lower()=='pythonw.exe','panel process executable mismatch'
  command(['taskkill','/PID',str(p['ProcessId'])],R);say('Closed verified panel pid='+str(p['ProcessId']))
 time.sleep(.3)
 assert not runners(processes()),'runner started during preflight'
 baseline()
 backup=W/'_backup'/('douyin-fix-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir(parents=True,exist_ok=False)
 for n,p in paths.items():
  rel=p.relative_to(W);dest=backup/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);assert digest(dest)==digest(p),'backup hash mismatch'
 say('BACKUP '+str(backup))
 patch=(B/'deploy.patch').read_bytes();parts=re.split(rb'(?=diff --git )',patch);cp=b''.join(p for p in parts if p.startswith(b'diff --git a/douyin-local-control/'));tp=b''.join(p for p in parts if p.startswith(b'diff --git a/task/'))
 assert cp and tp and cp.count(b'diff --git ')==5 and tp.count(b'diff --git ')==2,'patch scope unexpected'
 (B/'control-deploy.patch').write_bytes(cp);(B/'task-deploy.patch').write_bytes(tp)
 git=shutil.which('git');assert git,'git missing'
 common=[git,'-c','core.autocrlf=false','apply','--unidiff-zero','--verbose']
 cp=common+['--directory=work',str(B/'control-deploy.patch')]
 tp=common+['-p2','--directory=work/douyin-local-20261104-1e985ff064',str(B/'task-deploy.patch')]
 for cmd in (cp,tp):
  q=command(cmd[:-1]+['--check',cmd[-1]],R)
  say('PATCH CHECK rc=0 no Skipped; '+cmd[-1])
 baseline();assert not runners(processes()),'runner appeared before apply'
 changed=True
 for cmd in (cp,tp):
  command(cmd,R);say('PATCH APPLY rc=0 no Skipped; '+cmd[-1])
 expected={t[0]:t[2] for l in (B/'sha.txt').read_text().splitlines() if len(t:=l.split('\t'))==3}
 expected['douyin-local-control/control.py']='a1f10189a4adebc6a3563bd5585906dca3250d18db842cb8368b3ebb8cf84f32';expected['task/send_cli_once.cjs']='d2dbdaf6bae665280ab95657e615fa67013df3fea5c4cb3b3f441421287757bc'
 targets=dict(paths);targets['douyin-local-control/unknown_resolution.py']=unknown
 for n,p in targets.items():
  after=digest(p);say('OBSERVED AFTER SHA '+n+' '+after);assert after==expected[n],'after SHA mismatch '+n
  before=next((r['baseline_expected'] for r in rows if r['file']==n),'ABSENT')
  say('SHA '+json.dumps({'file':n,'before':before,'after':after}))
 node=shutil.which('node')
 if not node:
  candidate=W/'runtime/douyin-bridge/node.exe';node=str(candidate) if candidate.is_file() else None
 assert node,'node unavailable'
 for i,(n,p) in enumerate(targets.items()):
  if p.suffix=='.py':py_compile.compile(str(p),cfile=str(B/('compile-'+str(i)+'.pyc')),doraise=True)
  else:command([node,'--check',str(p)],B)
  say('SYNTAX OK '+n)
 launcher=C/'打开本地进度.cmd';assert launcher.is_file(),'original launcher absent'
 os.startfile(str(launcher));time.sleep(1)
 panels=[p for p in processes() if p['Name'].lower()=='pythonw.exe' and 'panel.py' in str(p.get('CommandLine') or '').lower()]
 assert len(panels)==1,'expected exactly one reopened panel'
 say('PANEL_PID '+str(panels[0]['ProcessId']))
 state=json.loads((C/'status.json').read_text(encoding='utf-8-sig'))
 allow=('status','reason','updated_at','confirmed_sent','process_id','automatic_retry')
 # reason is locally generated operational text, not arbitrary customer message.
 say('STATUS '+json.dumps({k:state[k] for k in allow if k in state},ensure_ascii=True))
 say('SUCCESS update only; no start click and no sending invoked')
except Exception as e:
 say('STOP '+type(e).__name__+' '+str(e))
 if changed and backup:
  try:
   for n,p in paths.items():shutil.copyfile(backup/p.relative_to(W),p)
   if unknown.exists():unknown.unlink()
   assert all(digest(paths[r['file']])==r['baseline_expected'] for r in rows)
   say('ROLLBACK verified six baselines restored; new module absent')
  except Exception as er:say('ROLLBACK FAILED '+type(er).__name__)
finally:
 (B/'deployment-output.txt').write_text('\n'.join(log)+'\n',encoding='utf-8')
