# 把自动同步接到 GitHub 私有仓库

做完下面几步之后，box 每 6 小时会自己 `git push`，你的 Windows 电脑用计划任务 `git pull`，过程不消耗 Grok 额度。

## 为什么需要你动手一次

Cursor 这边不能代你新建 GitHub 仓库；云端 box 和这台电脑上的 `gh` 都还没有登录。我们也不会把你电脑上的 Git 凭据拷到 box。所以仓库要由你在自己的 GitHub 账号下建，再把 box 的**部署公钥**加进去。

## 步骤

1. 在 GitHub 新建一个 **私有** 仓库，名字建议：`ai-workspace-backup`。不要加 README、不要加 License（空仓库即可）。
2. 打开仓库 Settings → Deploy keys → Add deploy key：
   - Title: `box-ai-backup`
   - 勾选 **Allow write access**
   - 粘贴下面的公钥（这是公钥，可以公开；私钥只留在 box 上，不会进备份）
3. 在这台电脑上，进入 `C:\Users\rmsama\Documents\AI-Backup`，执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\Install-AIBackup.ps1 -RepoUrl https://github.com/你的用户名/ai-workspace-backup.git
```

4. 在 box 上把同样的地址配成 origin（把用户名和仓库名换掉）：

```bash
cd /home/box/.local/share/ai-backup/staging
git remote add origin git@github.com:你的用户名/ai-workspace-backup.git
/workspace/tools/backup/backup.py --mode incremental
```

之后电脑上的计划任务每 6 小时会 `git pull`。

## Box 部署公钥

```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIADh7G9gZKc/q7jBZYIU+25wQrr78A6uilt0SwBJ6kvw box-ai-backup
```
