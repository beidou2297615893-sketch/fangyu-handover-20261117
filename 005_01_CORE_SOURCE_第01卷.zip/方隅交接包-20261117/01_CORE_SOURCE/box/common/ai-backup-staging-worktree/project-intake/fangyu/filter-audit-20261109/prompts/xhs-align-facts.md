# 素材（只读事实，写成口径稿，不要改规则）

## 任务
小红书采集后的筛选规则要和抖音完全一致：只保留30天内评论，按意向排序后再进入发布链路。
“发布”=本地母句草稿 + 另需发送许可/CLI发送；不等于自动公开发帖或自动回复。

## 抖音现行源（用户机拷贝到 box，路径与SHA）
源目录（用户机）：C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\
1. business-fit/business_fit.py
   - VERSION=fangyu-commercial-fit-v4.3-20261106
   - SHA256=7bb699a799a7a5be8e724e99c632bb8a7f5f8fde7c9ff527c38f8c87a6441dd0
2. recency-priority/recency.py
   - DOUYIN_ACTIVE_POOL_POLICY=douyin-active-30days-20261105
   - DOUYIN_REPLY_PRIORITY_VERSION=douyin-time-budget-intent-pools-v4-20261105
   - SHA256=7608096684c07bf359eff7d209e6b99eb1d93821af5f6b7ed624aa8770cc85b5
3. recency-priority/retention30.py
   - SHA256=ab2965caedbdf5b269747fc1e940f16217e45f33c9a7707368075aaa6520ddc3
4. rules/只保留30天评论执行方式.json（双平台）
   - SHA256=eec27a57713a434c75a58a00df4e163448941d5a6914356887421bf7d40445a5
   - platforms含 douyin 与 xiaohongshu；date_basis=原评论发表时间，滚动30天，不按采集时间
5. rules/抖音30天有效池-20261105.json
   - SHA256=e62d55260bece43e872e687597553144f8fa3ea3e020924358d4c26d0e5a292f
6. rules/意向分级与预算口径-20261105.md
   - SHA256=63cd42e4cb0371f9c31c6a4142308554e527d1116b98db2925c972b21de189a8
7. rules/时间优先排序-20261102.json
   - SHA256=21a41c20fc90248922011c5ffffed1e7aaaae20ac345f4487b8b5dcbc874413f
证据：classification-handoff-status.json 的 commercial_fit.version / code_sha256 与上列 business_fit 一致；当前全部高意向分池指针 business_fit_version 同为 fangyu-commercial-fit-v4.3-20261106。

## 时间字段映射
抖音实际常见字段：
- published_at（ISO，多为 +00:00）
- published_at_unix（秒；偶见毫秒由 recency.stamp 判断）
- classification.original_metadata.published_at（部分有）
小红书实际常见字段：
- comment_published_at（ISO，多为 +00:00）
统一解析入口：recency.stamp(row) 按序尝试 published_at / original_comment_date / comment_published_at / metadata.published_at / published_at_unix。
retention30.stamp 额外尝试 create_time / created_time / comment_time，并递归 source_record。
30天基准：原评论发表时间；不是采集时间、不是文件mtime。
时区：存储多为 UTC（+00:00）；比较用 datetime.now(timezone.utc) / time.time() 的UTC秒；策略文档日刷新锚点写 Asia/Shanghai 00:05，但年龄计算按绝对秒差，不按上海日历日切窗。
超窗：recency.within_douyin_active_window = 时间档<=2（即<=30天）；retention30.expired = now-published > 30*86400。

## 意向排序键（两侧应共用）
recency.priority_key / douyin_reply_priority：
1. time_band：近7 / 8-15 / 16-30 / 31-60 / 61-90 / >90 / 不明
2. budget_rank：budget_at_least_4000 优先，否则待核实
3. intent_rank：super_high < high < medium < low ...
4. 同档按原评论时间新到旧（-timestamp）
标签字段：commercial_fit.lead_intent / lead_intent_label；commercial_fit.budget.state；douyin_reply_priority 输出 time_band/budget_pool/intent_pool/followup_pool。
超高意向额外：明确求租 + 显式兼容预算>=4000 + age_band<=1（近15天内）。

## 现状差异（证据）
1. 小红书保留池 xiaohongshu-retained-business-customers.jsonl（SHA c102493b… 状态指针）在复核时点仍有 41 条落在 31-60 天档，未按“只留30天”清出显示/候选；抖音 screened/retained 本轮未见>30天高意向。
2. 联系限制代码分叉：business_fit.screen 对抖音「不要中介」→ hold(contact_identity_requires_confirmation)；对小红书同类措辞→ exclusion(contact_or_brand_restricted) 直接拦截。与已确认“按范围打标签不直接丢弃”不一致（小红书侧更严）。
3. 时间字段名不统一：抖音 published_at(+unix)，小红书 comment_published_at；虽 stamp() 兼容，但上游采集/导入需保证写入 stamp 可识别字段，缺字段会进“时间不明”。
4. 高意向分池指针 stats 写小红书12，但 screened-high-intent.jsonl 实为小红书5条（文件SHA与指针 results_sha256 同为 bda208e9…）——统计字段与正文不一致。
5. 规则文件名仍大量带“抖音”字样（如抖音30天有效池），但只保留30天执行方式.json 已声明双平台；小红书对齐时应明确消费同一套 business_fit + recency + retention30，而不是另起词表。
6. 预算解析缺口（双平台同源代码）：“3000左右/三千左右/3500左右”被清成 budget_unverified 仍可高意向 eligible；“两千五六”未解析。属共同缺陷，对齐时要一并修口径，不能只对齐小红书。

## 对齐目标（只写口径，不实施）
- 小红书采集入库后：同一 business_fit 版本筛选；同一 30 天原评论窗；同一 priority_key 排序；再进母句草稿。
- 发送/公开发布仍需既有发送许可，不因对齐自动发送。
- 字段：小红书继续用 comment_published_at，但必须能被 recency.stamp 读到；禁止用采集时间冒充。
