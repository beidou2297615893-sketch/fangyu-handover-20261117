import gzip,re,collections,json
G=lambda b:f"{b/1e9:.2f}G" if b>1e9 else f"{b/1e6:.1f}M"
RB=re.compile(r'\\(node_modules|\.venv|venv|site-packages|__pycache__|\.gradle|gradle-home|_internal|\.cache|Cache|Code Cache|GPUCache|User Data|EBWebView|avd|\.pytest_cache|build\\intermediates|build\\outputs|build\\tmp|\.cxx|Lib\\site-packages|desktop-python|python-runtime)\\|\.(pyc|img|qcow2|vhdx|vmrs|avhdx)$',re.I)
SRC=re.compile(r'\.(py|pyw|js|mjs|cjs|ts|tsx|jsx|vue|css|scss|html|htm|md|ps1|psm1|bat|cmd|sh|kt|kts|java|gradle|toml|ya?ml|ini|cfg|sql|svg|wxml|wxss|wxs|txt|json|xml|csv|spec|iss|nsi)$',re.I)
BIN=re.compile(r'\.(apk|aab|exe|msi|zip|7z|rar|dll|pyd|so|whl|dmg|pkg)$',re.I)
IMG=re.compile(r'\.(png|jpe?g|gif|webp|mp4|mov|webm|psd|fig|ico)$',re.I)
DATA=re.compile(r'(\.(sqlite3?|db|jsonl)(-wal|-shm)?$|receipt|ledger)',re.I)
def area(p):
  if p.startswith('C:\\积木软件工坊\\项目\\方隅公寓') or '\\Fangyu' in p or '\\fangyu' in p or '\\自动获客系统\\' in p or 'fangyu-accept' in p: return 'fangyu'
  if '\\答题小程序\\' in p or 'DailyHundred' in p or '\\知题' in p or 'WeChatProjects' in p: return 'quiz'
  if p.startswith('C:\\积木软件工坊\\'): return 'common_jimu'
  return 'other'
S=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0]))
U=collections.defaultdict(set); US=collections.defaultdict(int)
for fn in ['files.tsv.gz','files3.tsv.gz']:
  for line in gzip.open(fn,'rt',encoding='utf-8',errors='replace'):
    p=line.rstrip('\n').split('\t')
    if len(p)<3: continue
    path,sz=p[0],int(p[1] or 0)
    if fn=='files.tsv.gz' and '\\Documents\\ChatGPT\\' in path: continue
    a=area(path)
    if '\\.git\\' in path: c='git'
    elif RB.search(path): c='rebuildable'
    elif DATA.search(path.rsplit('\\',1)[-1]): c='data_ledger'
    elif BIN.search(path): c='binary_pkg'
    elif IMG.search(path): c='image_media'
    elif SRC.search(path) and sz<2*1024*1024: c='source_text'
    else: c='other'
    s=S[a][c]; s[0]+=1; s[1]+=sz
    if c=='source_text':
      k=(path.rsplit('\\',1)[-1],sz)
      if k not in U[a]: U[a].add(k); US[a]+=sz
for a in S:
  print('##',a, 'TOTAL',G(sum(v[1] for v in S[a].values())))
  for c,v in sorted(S[a].items(),key=lambda x:-x[1][1]): print('   ',c,G(v[1]),v[0])
  print('    source_text dedup(name+size):',G(US[a]),len(U[a]))
