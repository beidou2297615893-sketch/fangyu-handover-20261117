﻿$ErrorActionPreference='SilentlyContinue'
$T='C:\Users\rmsama\AppData\Local\Temp\fy_inv'
$enc=New-Object Text.UTF8Encoding($false)
$G=New-Object System.Collections.Generic.List[string]
$G.Add('==ALIAS'); Get-Item -Force 'C:\Users\rmsama\.codex\local-build-aliases\dailyhundred-20261023','C:\Users\rmsama\.codex\local-build-aliases' | ForEach-Object { $G.Add($_.FullName+"`t"+$_.Attributes+"`t"+(($_ | Select-Object -ExpandProperty Target) -join ';')) }
Get-ChildItem -Force 'C:\Users\rmsama\.codex\local-build-aliases' | ForEach-Object { $G.Add($_.FullName+"`t"+$_.Attributes+"`t"+(($_ | Select-Object -ExpandProperty Target) -join ';')) }
$G.Add('==SUBST'); (& subst) | ForEach-Object { $G.Add($_) }
foreach($rp in @('C:\Users\rmsama\Documents\ChatGPT\自动获客系统')){
 $G.Add('#### REPO '+$rp)
 $a=@('-c','safe.directory=*','--no-optional-locks','-C',$rp)
 $G.Add('-- remotes'); (& git @a remote -v) | ForEach-Object { $G.Add($_) }
 $G.Add('-- branches'); (& git @a branch -a -v --no-abbrev) | ForEach-Object { $G.Add($_) }
 $G.Add('-- head'); (& git @a rev-parse --abbrev-ref HEAD) | ForEach-Object { $G.Add($_) }
 $G.Add('-- tags'); (& git @a tag -l --format='%(refname:short) %(objectname:short) %(creatordate:short)') | ForEach-Object { $G.Add($_) }
 $G.Add('-- stash'); (& git @a stash list --date=iso) | ForEach-Object { $G.Add($_) }
 $G.Add('-- worktrees'); (& git @a worktree list) | ForEach-Object { $G.Add($_) }
 $G.Add('-- count'); (& git @a rev-list --all --count) | ForEach-Object { $G.Add($_) }
 $G.Add('-- status'); $st=(& git @a status --porcelain=v1 -uall); $G.Add('modified='+(@($st | Where-Object {$_ -notmatch '^\?\?'}).Count)+' untracked='+(@($st | Where-Object {$_ -match '^\?\?'}).Count)); $st | Select-Object -First 400 | ForEach-Object { $G.Add('  '+$_) }
 $G.Add('-- log'); (& git @a log --all --date=format:'%Y-%m-%d %H:%M' --format='%h|%ad|%D|%s') | ForEach-Object { $G.Add($_) }
 $G.Add('-- lsfiles'); (& git @a ls-files) | ForEach-Object { $G.Add($_) }
 $G.Add('-- gitsize'); $gs=(Get-ChildItem -LiteralPath (Join-Path $rp '.git') -Recurse -Force -File | Measure-Object Length -Sum).Sum; $G.Add([string]$gs)
}
foreach($w in (Get-ChildItem -Force 'C:\.codex\worktrees' -Directory)){ $G.Add('#### WT '+$w.FullName); Get-ChildItem -Force $w.FullName | ForEach-Object { $G.Add('  '+$_.Name) }; $gf=Join-Path $w.FullName '.git'; if(Test-Path $gf){ if((Get-Item -Force $gf).PSIsContainer){$G.Add('  .git dir')}else{ $G.Add('  gitfile: '+(Get-Content -TotalCount 1 $gf)) } ; (& git -c safe.directory=* --no-optional-locks -C $w.FullName log --all -3 --date=short --format='%h|%ad|%D|%s') | ForEach-Object { $G.Add('  '+$_) } } }
[IO.File]::WriteAllLines("$T\git3.txt",$G,$enc)
$sw=New-Object IO.StreamWriter("$T\files3.tsv",$false,$enc)
foreach($r in @('C:\Users\rmsama\Documents\ChatGPT\自动获客系统','C:\Users\rmsama\Documents\ChatGPT\答题小程序','C:\Users\rmsama\Documents\ChatGPT\fangyu-accept-20261114','C:\Users\rmsama\Documents\GrokBuild','C:\.codex\worktrees')){ Get-ChildItem -LiteralPath $r -Recurse -Force -File | ForEach-Object { $sw.WriteLine($_.FullName + "`t" + $_.Length + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')) } }
$sw.Close()
'DONE' | Out-File "$T\done3.txt"
