# 界面接口

`render(viewModel)` 返回本页可交互HTML，`bind(root, context)` 绑定操作，可返回离页清理函数。

`context.viewModel` 是当前演示会话模型，`context.actions` 提供 `update(mutator)`、`navigate(page)`、`toast(text)`、`modal(options)`。`state` 和同名顶层方法为现有页模块的兼容别名。

- 登录、门店、页面、回复草稿、客户勾选等保存在当前页面内存。
- 模块不导入生产controller，不发送网络请求；服务端和CSP同时阻断业务transport。
- 当前客户/帖子/规则是明确的示例数据；后续接功能时逐项提取为真实数据适配器，保留本轮DOM和样式。
- 模拟确认仅改变演示状态，Excel入口只展示导出预览。真实采集、发送、Excel文件导出和账号认证尚未接入。
- 界面认可后才进行真实业务接口和桌面入口/版本清单接回，不把原生产启动器指向此演示服务。
