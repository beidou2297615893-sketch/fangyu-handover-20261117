"""Managed, explicitly requested continuation of the active Douyin collector."""
import ctypes
import json
import os
import shutil
import subprocess
import time
import uuid
import argparse
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

from runner_ledger_adapter import gate
from collection_confirmed_scope import confirmable,prepare_scope

ROOT = Path(__file__).resolve().parent
DATABASE = ROOT / 'runtime' / 'collection.sqlite3'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def running(pid):
    if not isinstance(pid, int) or pid < 1:
        return False
    kernel = ctypes.windll.kernel32
    kernel.OpenProcess.restype = ctypes.c_void_p
    handle = kernel.OpenProcess(0x100000, False, pid)
    if not handle:
        return kernel.GetLastError() == 5
    try:
        return kernel.WaitForSingleObject(ctypes.c_void_p(handle), 0) != 0
    finally:
        kernel.CloseHandle(ctypes.c_void_p(handle))


def continuation_action(control, terminal, stop_exists, has_response):
    if control.get('pending'):
        return 'recover' if has_response else 'unknown'
    if terminal == 'target_reached':
        return 'complete'
    if terminal in ('awaiting_candidate_review', 'sources_exhausted'):
        return 'review'
    if control.get('stopped') and not control['stopped'].startswith('local_stop_'):
        return 'blocked'
    if stop_exists or control.get('stopped'):
        return 'resume'
    return 'start'


def last_state(path):
    if not path.exists():
        return None
    with path.open('rb') as source:
        source.seek(max(0, path.stat().st_size - 16000))
        for line in reversed(source.read().splitlines()):
            try:
                return json.loads(line).get('state')
            except (ValueError, AttributeError):
                continue
    return None


def write_active(path, active):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(active, ensure_ascii=False, indent=2), encoding='utf-8')
    for delay in (0.02, 0.04, 0.08, 0.16, None):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if delay is None:
                raise
            time.sleep(delay)


def confirmation_event(halt):
    if not halt:
        return None
    with closing(sqlite3.connect(DATABASE.resolve().as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        event = db.execute('SELECT * FROM attempts WHERE request_id=?', (halt['request_id'],)).fetchone()
        return halt['request_id'] if confirmable(event) else None


def continue_active(confirmed_id=None, source='progress_window'):
    lock = ROOT / 'continue-collection.lock'
    try:
        with lock.open('x', encoding='utf-8') as lease:
            lease.write(str(os.getpid()))
    except FileExistsError:
        return '已有继续操作正在处理。'
    try:
        return _continue_active(confirmed_id, source)
    finally:
        lock.unlink(missing_ok=True)


def _continue_active(confirmed_id, source):
    active_file = ROOT / 'active-runner.json'
    active = read(active_file)
    if running(active.get('pid')):
        return '采集已在运行，未重复启动。'
    if any(ROOT.glob('runner-lease-*.json')):
        return '采集运行锁仍在，需核实原进程后继续。'
    plan = read(ROOT / active['plan'])
    directory = ROOT / active['directory']
    control_path = directory / 'control.json'
    control = read(control_path)
    halt = gate(DATABASE, plan['account_uid'], plan['scan_id'])['halt']
    if confirmed_id and confirmation_event(halt) != confirmed_id:
        return '暂停事件已变化，或该状态需要单独核查。'
    if halt and not confirmed_id:
        return '账本仍在等待处理。若已经完成抖音验证，请使用验证确认按钮。'
    node = shutil.which('node') or str(ROOT.parent / 'runtime' / 'douyin-bridge' / 'node.exe')
    flags = subprocess.CREATE_NO_WINDOW
    bridge = ROOT.parent.parent / '抖音自用采集台' / 'data' / 'bridge.json'
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    if confirmed_id:
        if control.get('pending'):
            return '上一页本地回执仍待核查，暂时无法恢复。'
        check = subprocess.run([node, 'collection_identity_check.cjs', active['plan'], str(bridge)],
                               cwd=ROOT, capture_output=True, creationflags=flags, timeout=55)
        if check.returncode:
            return '原采集账号或连接未能核实，请在原抖音页面检查。'
        identity = json.loads(check.stdout)
        suffix = f'confirmed-{stamp}'
        identity_name = f'identity-{suffix}.json'
        (ROOT / identity_name).write_text(json.dumps(identity, ensure_ascii=False), encoding='utf-8')
        try:
            plan, evidence = prepare_scope(DATABASE, plan, confirmed_id, f'douyin-{suffix}',
                                           (f'User requested continuation after a prior transport failure; same account freshly verified via {source}'
                                            if source in ('chat_user_resume_identity_timeout','chat_user_resume_identity_recheck','chat_user_resume_business_timeout','chat_user_resume_service_empty','local_bounded_timeout_recovery') else
                                            f'User explicitly confirmed verification completed via {source}'), identity_name)
        except ValueError:
            return '现有暂停无法安全恢复。请查看进度和回执。'
        proof = dict(verified=True, source='Exact route refusal and same account profile verified',
                     account_uid=plan['account_uid'], connection_id=plan['connection_id'])
        plan_name, proof_name, review_name = (f'{prefix}-{suffix}.json' for prefix in ('plan', 'strict-proof', 'recovery-review'))
        for name, value in ((plan_name, plan), (proof_name, proof), (review_name, evidence)):
            (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        active['previous_confirmed_scope'] = {key: active.get(key) for key in ('plan','directory','stdout','stderr','current_blocker')}
        active.update(plan=plan_name, identity=identity_name, strict_proof=proof_name,
                      directory=f'runner-live-{suffix}', recovery_review=review_name)
        action = 'start'
    else:
        action = None
    pending = control.get('pending')
    has_response = False
    if pending:
        evidence = Path(pending['record_path']).resolve()
        if evidence.is_relative_to(directory.resolve()) and evidence.exists():
            record = read(evidence)
            has_response = (record.get('spec', {}).get('request_id') == pending['request_id']
                            and isinstance(record.get('response'), dict))
    if action is None:
        action = continuation_action(control, last_state(ROOT / active['stdout']), (directory / 'STOP').exists(), has_response)
    messages = {
        'unknown': '上一页结果未知，已保留记录。继续按钮不会重新请求该页。',
        'complete': '采集已达到累计目标。',
        'review': '当前搜索范围已用完或候选待核查。',
        'blocked': '采集因异常停止，请先查看回执和停机原因。',
    }
    if action in messages:
        return messages[action]
    base = [node, 'runner.cjs', '--plan', active['plan'], '--database', str(DATABASE),
            '--directory', active['directory'], '--qualification-policy', active['qualification_policy']]
    local_actions = [action] if action in ('recover', 'resume') else []
    if action == 'recover' and (directory / 'STOP').exists():
        local_actions.append('resume')
    for local_action in local_actions:
        command = base + ['--recover-local' if local_action == 'recover' else '--resume-local']
        if local_action == 'resume':
            review = directory / f'continue-review-{stamp}.json'
            review.write_text(json.dumps(dict(account_uid=plan['account_uid'], operator='progress_window',
                                              reason='User clicked continue after ordinary stop', rule_source='explicit click')),
                              encoding='utf-8')
            command += ['--review', str(review)]
        with (directory / f'continue-audit-{stamp}-{local_action}.log').open('xb') as audit:
            result = subprocess.run(command, cwd=ROOT, stdout=audit, stderr=subprocess.STDOUT, creationflags=flags)
        control = read(control_path)
        if result.returncode or control.get('pending') or control.get('stopped'):
            return '本地恢复后仍有暂停原因。请查看进度和回执。'
        if not gate(DATABASE, plan['account_uid'], plan['scan_id'])['can_collect']:
            return '本地回执已核对，账本仍暂停。'
    if (directory / 'STOP').exists():
        return '停止标记仍在。请核查后再继续采集。'
    command = base + ['--run', '--bridge-config', str(bridge), '--identity-probe', active['identity'],
                      '--strict-proof', active['strict_proof'], '--minimum-delay-ms', str(active['minimum_delay_ms'])]
    if confirmed_id:
        validation = f'runner-ui-continue-{stamp}-validation.log'
        with (ROOT / validation).open('xb') as out:
            result = subprocess.run(command + ['--max-pages', '1'], cwd=ROOT, stdout=out,
                                    stderr=subprocess.STDOUT, creationflags=flags)
        active['validation_log'] = validation
        if result.returncode or last_state(ROOT / validation) != 'bounded_batch_complete':
            new_halt = gate(DATABASE, plan['account_uid'], plan['scan_id'])['halt']
            active.update(status='paused',pid=None,stdout=validation,stderr=validation,
                          current_blocker=new_halt['request_id'] if new_halt else None)
            write_active(active_file, active)
            return '验证后第一新页仍未成功。已暂停，请查看抖音提示和回执。'
    stdout = f'runner-ui-continue-{stamp}-stdout.log'
    stderr = f'runner-ui-continue-{stamp}-stderr.log'
    with (ROOT / stdout).open('xb') as out, (ROOT / stderr).open('xb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err, creationflags=flags)
        time.sleep(0.35)
        if process.poll() is not None:
            if confirmed_id:
                active.update(status='paused',pid=None,stdout=stdout,stderr=stderr)
                active.pop('current_blocker',None)
                write_active(active_file, active)
            return '采集未能启动。请查看本地运行记录。'
    active['previous_window_run'] = {key: active.get(key) for key in ('pid', 'stdout', 'stderr')}
    active.update(status='running', pid=process.pid, stdout=stdout, stderr=stderr,
                  continued_at=datetime.now().astimezone().isoformat())
    active.pop('current_blocker', None)
    active.pop('verification_required_now', None)
    active.pop('verification_evidence', None)
    write_active(active_file, active)
    from collection_wait_worker import ensure_worker
    ensure_worker(reset=source != 'local_bounded_timeout_recovery')
    return '已从原断点继续采集。'


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--confirmed', required=True)
    args = parser.parse_args()
    print(continue_active(args.confirmed, source='chat_user_explicit_confirmation'))
