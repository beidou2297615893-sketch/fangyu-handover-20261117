# 本轮实现范围

2026-10-16：以第三轮五张图为目标，沿用 r56 的原生HTML/ES模块技术、摄影与品牌资产，新增独立 UI-only 入口。现有真实桌面和生产 controller 未修改。

- root：index.html、styles.css、app.mjs、server.cjs、验收与交接。
- ui_architecture：pages/acquire.mjs/.css、pages/presets.mjs/.css。
- ui_requirements：pages/reply.mjs/.css、pages/customers.mjs/.css。
- hang_diagnostics：连接修复、独立生成示例头像。

模块接口：render(state) -> HTML；bind(root,ctx) -> optional cleanup；ctx包含state、update(mutator)、navigate(page)、toast(text)、modal({title,html,onConfirm,confirmLabel})。page为acquire/reply/customers/presets/accounts/login。

只使用当前页面内存演示数据；不载入真实账号、数据库、Cookie或API key。CSP connect-src none，服务端拒绝API及非GET/HEAD请求。功能接入须等完整界面获得用户认可。

状态：五页隔离预览、真实浏览器验收与并排图审证据完成。等待用户整套界面认可；尚未切换原桌面入口或打正式包。短接续见 CURRENT.md。
