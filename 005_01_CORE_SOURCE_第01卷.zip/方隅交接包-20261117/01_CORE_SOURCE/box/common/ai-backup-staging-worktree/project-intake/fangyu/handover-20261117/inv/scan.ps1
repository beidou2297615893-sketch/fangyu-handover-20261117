﻿$ErrorActionPreference='SilentlyContinue'
$T='C:\Users\rmsama\AppData\Local\Temp\fy_inv'
New-Item -ItemType Directory -Force $T | Out-Null
$enc=New-Object Text.UTF8Encoding($false)
$roots=New-Object System.Collections.Generic.List[string]
foreach($r in @('C:\积木软件工坊','C:\Users\rmsama\Documents\AI-Backup','C:\Users\rmsama\DailyHundredNativeBuild','C:\Users\rmsama\WeChatProjects','C:\Users\rmsama\Codex-Bridge','C:\Users\rmsama\Desktop','C:\work','C:\ai','C:\automations','C:\Users\rmsama\automations','C:\Users\rmsama\.douyin-skills','C:\Users\rmsama\.xiaohongshu-cli','C:\Users\rmsama\.dy','C:\Users\rmsama\.douyin-ide','C:\Users\rmsama\GrokCross','C:\Users\rmsama\agent-tools','C:\uu','C:\Users\rmsama\.grokbot')){ if(Test-Path -LiteralPath $r){$roots.Add($r)} }
Get-ChildItem -Force 'C:\Users\rmsama\AppData\Local' -Directory | Where-Object { $_.Name -match '^fangyu|^Fangyu' } | ForEach-Object { $roots.Add($_.FullName) }
# keyword dir search
$kw='fangyu|方隅|douyin|抖音|小红书|xhs|xiaohongshu|知题|百题|答题|zhiti|dailyhundred|quiz|daily-hundred|tijing'
$kwhits=New-Object System.Collections.Generic.List[string]
function Walk($p,$d){ if($d -gt 5){return}; Get-ChildItem -LiteralPath $p -Directory -Force | ForEach-Object { $n=$_.FullName; if($n -match '\\(node_modules|Windows|Program Files|Program Files \(x86\)|ProgramData|\$Recycle\.Bin|System Volume Information|WinSxS|Packages|Microsoft|Google|site-packages|\.git|miniconda3|msys64|Edge|User Data|__pycache__|Temp)$'){return}; if($_.Name -match $kw){$kwhits.Add($n + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))}; Walk $n ($d+1) } }
Walk 'C:\Users\rmsama' 0
Get-ChildItem 'C:\' -Directory -Force | Where-Object { $_.Name -notmatch '^(Windows|Program Files|Program Files \(x86\)|ProgramData|Users|\$Recycle\.Bin|System Volume Information|积木软件工坊|msys64|Recovery|\$SysReset)$' } | ForEach-Object { if($_.Name -match $kw){$kwhits.Add($_.FullName)}; Walk $_.FullName 1 }
[IO.File]::WriteAllLines("$T\kwdirs.txt",$kwhits,$enc)
[IO.File]::WriteAllLines("$T\roots.txt",$roots,$enc)
# file listing
$sw=New-Object IO.StreamWriter("$T\files.tsv",$false,$enc)
foreach($r in $roots){ Get-ChildItem -LiteralPath $r -Recurse -Force -File | ForEach-Object { $sw.WriteLine($_.FullName + "`t" + $_.Length + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')) } }
$sw.Close()
# git repos
$repos=New-Object System.Collections.Generic.List[string]
$cand=@($roots) + ($kwhits | ForEach-Object { ($_ -split "`t")[0] })
foreach($r in ($cand | Sort-Object -Unique)){ Get-ChildItem -LiteralPath $r -Recurse -Force -Filter '.git' | Where-Object { $_.FullName -notmatch '\\node_modules\\' } | ForEach-Object { $repos.Add($_.Parent.FullName); if(-not $_.PSIsContainer){} } ; if(Test-Path -LiteralPath (Join-Path $r '.git')){$repos.Add($r)} }
$repos2=@()
foreach($x in $repos){ $repos2 += ($(if($x){$x}else{''})) }
$G=New-Object System.Collections.Generic.List[string]
foreach($rp in ($repos | Where-Object {$_} | Sort-Object -Unique)){
 $G.Add('#### REPO '+$rp)
 $a=@('-c','safe.directory=*','--no-optional-locks','-C',$rp)
 $G.Add('-- remotes'); (& git @a remote -v) | ForEach-Object { $G.Add($_) }
 $G.Add('-- branches'); (& git @a branch -a -v --no-abbrev) | ForEach-Object { $G.Add($_) }
 $G.Add('-- head'); (& git @a rev-parse --abbrev-ref HEAD) | ForEach-Object { $G.Add($_) }
 $G.Add('-- tags'); (& git @a tag -l --format='%(refname:short) %(objectname:short) %(creatordate:short)') | ForEach-Object { $G.Add($_) }
 $G.Add('-- stash'); (& git @a stash list --date=iso) | ForEach-Object { $G.Add($_) }
 $G.Add('-- count'); (& git @a rev-list --all --count) | ForEach-Object { $G.Add($_) }
 $G.Add('-- status'); $st=(& git @a status --porcelain=v1 -uall); $G.Add('modified='+(@($st | Where-Object {$_ -notmatch '^\?\?'}).Count)+' untracked='+(@($st | Where-Object {$_ -match '^\?\?'}).Count)); $st | Select-Object -First 200 | ForEach-Object { $G.Add('  '+$_) }
 $G.Add('-- log'); (& git @a log --all --date=format:'%Y-%m-%d %H:%M' --format='%h|%ad|%D|%s') | ForEach-Object { $G.Add($_) }
 $G.Add('-- reflogcount'); (& git @a reflog --all | Measure-Object).Count | ForEach-Object { $G.Add([string]$_) }
 $G.Add('-- gitsize'); $gs=(Get-ChildItem -LiteralPath (Join-Path $rp '.git') -Recurse -Force -File | Measure-Object Length -Sum).Sum; $G.Add([string]$gs)
}
[IO.File]::WriteAllLines("$T\git.txt",$G,$enc)
# shortcuts
$sh=New-Object -ComObject WScript.Shell
$S=New-Object System.Collections.Generic.List[string]
Get-ChildItem 'C:\Users\rmsama\Desktop','C:\Users\Public\Desktop' -Filter *.lnk -Force | ForEach-Object { $k=$sh.CreateShortcut($_.FullName); $S.Add($_.Name + "`t" + $k.TargetPath + "`t" + $k.Arguments + "`t" + $k.WorkingDirectory + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) }
[IO.File]::WriteAllLines("$T\lnk.txt",$S,$enc)
$f="$T\files.tsv"; $fs=[IO.File]::OpenRead($f); $o=[IO.File]::Create("$f.gz"); $gz=New-Object IO.Compression.GZipStream($o,[IO.Compression.CompressionMode]::Compress); $fs.CopyTo($gz); $gz.Close(); $fs.Close()
'DONE' | Out-File "$T\done.txt"
