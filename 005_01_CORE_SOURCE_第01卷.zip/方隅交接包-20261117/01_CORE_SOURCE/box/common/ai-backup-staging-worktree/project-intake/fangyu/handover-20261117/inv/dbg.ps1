﻿try { . 'C:\Users\rmsama\AppData\Local\Temp\fy_inv_scan2.ps1' } catch { 'CATCH: ' + $_ }
'ERRCOUNT ' + $Error.Count
$Error | Select-Object -First 5 | ForEach-Object { $_.ToString() + ' @ ' + $_.InvocationInfo.PositionMessage }
