# -*- coding: utf-8 -*-
"""Read-only: select 50 diverse Douyin class/reply samples from live queue + all-pool."""
import json, re, sqlite3, random
from collections import defaultdict, Counter
from datetime import datetime, timezone, timedelta
from pathlib import Path

SH = timezone(timedelta(hours=8))
R = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work")
FB = R / "fangyu-text-business-20261029"
QPATH = FB / "recency-priority" / "daily-priority" / "douyin-3e9aef4d3fa025fe.jsonl"
POOL = FB / "douyin-semantic-repair-v5" / "all-pool-business-fit.jsonl"
LEDGER = R / "shared-acquisition-ledger" / "shared.sqlite3"
OUT = Path(r"C:\Users\rmsama\agent-tools\class-reply-samples-50-20261112.json")

NOW = datetime(2026, 11, 12, 18, 32, tzinfo=SH)

CAT_CN = {
    "contextual_rental_inquiry": "找房咨询（结合视频语境）",
    "explicit_rental_demand": "明确求租",
    "insufficient_current_rental_evidence": "租房意向不够明确",
    "interaction_only": "只是互动，不像在找房",
    "mention_interaction_only": "只是互动或提及，不像在找房",
    "experience_or_price_discussion": "在聊租住经历或价格，不像自己在找房",
    "number_scope_requires_context": "只给了数字，所指不清",
    "short_reference_requires_context": "话太短，看不出具体需求",
    "advice_or_third_party": "像在给别人出主意，或说的是别人的事",
    "source_author_context": "更像在跟视频作者互动，不像明确找房",
    "supply": "像是在出租或提供房源",
    "supply_or_roommate_offer": "像是自己有房，在找室友或分租",
    "ended": "已经不找了",
    "missing_original_text": "原评论内容没读到",
    "demand": "找房需求",
}

EXCL_CN = {
    "低价视频-预算不符": "低价视频，预算对不上",
    "房源广告/中介": "房源广告或中介推销",
    "not_supported_customer_demand": "不像是在给自己找房",
    "source_post_advertised_rent_below_3000": "视频里标价低于三千",
    "whole_home_monthly_budget_below_3000": "评论里写的整租预算低于三千",
    "非本人找房需求（劝告/科普/反问他人/房东经验）": "不是本人在找房（劝告、科普、反问或在谈房东经验）",
    "demand_ended": "已经不找了",
    "交友/找搭子非租房": "交友或找搭子，不是找房",
    "contact_or_brand_restricted": "涉及联系方式或品牌限制，不能按普通找房来回",
    "供给方：自有房找室友/分租出去": "自己有房，在找室友或把房子分租出去",
    "供给方：询问是否有人找房": "在问有没有人要找房，像是在出租",
}

# store / area words that count as a real place (brand 方隅公寓 alone does not)
PLACE_WORDS = [
    "白湖亭", "仓山", "闽清", "高仕路", "骏盛公馆", "鼓山", "福清",
    "联航路", "云涛", "古北", "会展", "浦江", "中骏", "天璟", "龙柏", "颛桥",
    "沙河", "未来云城", "昌平", "高新西", "东站", "余杭", "青山湖",
    "闵行", "七宝", "徐汇", "静安", "浦东", "松江", "嘉定", "宝山", "虹桥", "莘庄",
    "朝阳", "海淀", "通州", "天通苑", "西单", "回龙观",
    "西湖", "下沙", "转塘", "临平", "滨江", "武侯", "高新",
    "三里新城", "桂林路", "宜山路",
]


def shanghai(ts):
    if ts is None or ts == "":
        return None
    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(float(ts), SH)
    s = str(ts).strip()
    try:
        if s.endswith("Z"):
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        else:
            dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(SH)
    except Exception:
        return None


def days_ago(dt):
    if not dt:
        return None
    return (NOW - dt).total_seconds() / 86400


def load_blocked():
    con = sqlite3.connect(f"file:{LEDGER}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    amap = {}
    canon_of = defaultdict(set)
    for r in con.execute("SELECT alias, canonical FROM identity_aliases WHERE platform='douyin'"):
        c = r["canonical"] or r["alias"]
        amap[r["alias"]] = c
        canon_of[c].add(r["alias"])
        canon_of[c].add(c)

    def canon(u):
        return amap.get(str(u), str(u))

    blocked_cids, blocked_canons = set(), set()
    for r in con.execute(
        "SELECT comment, customer, status FROM reservations WHERE platform='douyin' AND status IN ('sent','unknown','reserved')"
    ):
        if r["comment"]:
            blocked_cids.add(str(r["comment"]))
        if r["customer"]:
            blocked_canons.add(canon(str(r["customer"])))
    con.close()
    return blocked_cids, blocked_canons, canon


def is_blocked(cid, uid, blocked_cids, blocked_canons, canon):
    if cid and str(cid) in blocked_cids:
        return True
    if uid and canon(str(uid)) in blocked_canons:
        return True
    return False


def text_of(row):
    return (row.get("comment_text") or (row.get("classification") or {}).get("comment_text") or "").strip()


def video_snip(row, cf=None):
    cf = cf or row.get("commercial_fit") or {}
    vr = cf.get("video_listed_rent") or {}
    quote = (vr.get("quote") or "").strip()
    post = (row.get("post_body") or "").strip()
    if not post and not quote:
        return ""
    # keep title-like first chunk, plus price quote if not already in it
    first = re.split(r"[\n#]", post)[0].strip()
    first = re.sub(r"\s+", " ", first)
    if len(first) > 80:
        first = first[:80] + "…"
    if quote and quote not in first:
        if first:
            return f"{first}（标价：{quote}）"
        return f"标价：{quote}"
    return first


def literals(reply):
    lit = ((reply or {}).get("requested_details") or {}).get("literals") or {}
    def vals(key):
        v = lit.get(key) or []
        out = []
        if isinstance(v, list):
            for x in v:
                if isinstance(x, dict):
                    out.append(str(x.get("text") or x.get("value") or x.get("raw") or x).strip())
                else:
                    out.append(str(x).strip())
        elif v:
            out.append(str(v).strip())
        return [x for x in out if x]
    return {"budget": vals("budget"), "location": vals("location"), "layout": vals("layout"), "time": vals("time")}


def place_in_reply(draft, loc_slots):
    t = draft or ""
    hits = []
    for p in loc_slots:
        if p and p in t and p not in hits:
            hits.append(p)
    for p in PLACE_WORDS:
        if p and p in t and p not in hits:
            hits.append(p)
    # strip brand-only
    hits = [h for h in hits if h not in ("方隅", "方隅公寓")]
    return hits


def mother_phrase(template_id, status):
    tid = (template_id or "").strip()
    st = (status or "").strip()
    if not tid and not st:
        return "未记录用了哪类母句"
    # subtag
    mapping_prefix = {
        "budget_context": "预算",
        "location_context": "位置通勤",
        "layout_context": "户型或怎么住",
        "combined_context": "组合条件",
        "pool_generic": "通用池",
        "subtag": "细类",
    }
    subtag_map = {
        "有无空房": "问还有没有房",
        "位置查询": "问在哪",
        "问价": "问价格",
        "具体地点": "问具体地点",
        "联系咨询": "想联系咨询",
        "指定条件求房": "按条件找房",
        "是否仍可租": "还能否租",
        "水电": "问水电",
        "工作地通勤": "问上班通勤",
        "环境与安全": "问环境和安全",
    }
    if tid == "negative_scoped_generic" or st == "negative_scoped_generic":
        return "用了处理否定或排除条件的通用母句"
    if tid == "cat_exact_approved":
        return "用了按这条评论分类套用的现成母句"
    if ":" in tid:
        prefix, rest = tid.split(":", 1)
        if prefix == "subtag":
            name = subtag_map.get(rest, rest)
            return f"用了「{name}」这类母句"
        # rest may be pool names already in Chinese
        parts = [p.strip() for p in rest.split(",") if p.strip()]
        if parts:
            return f"用了「{'、'.join(parts)}」这类母句"
    if tid:
        return f"用了「{tid}」这类母句"
    return "未记录用了哪类母句"


def intent_cn(cf, row):
    lab = (cf or {}).get("lead_intent_label") or ""
    if lab:
        return lab
    raw = (cf or {}).get("lead_intent") or (row.get("local_recheck") or {}).get("interest") or row.get("interest_at_comment") or ""
    return {"high": "高意向", "medium": "中意向", "super_high": "超高意向", "uncertain": "意向还不明确", "low": "低意向"}.get(str(raw), str(raw) or "未记录")


def main_pools(row):
    pools = row.get("pools") or (row.get("local_recheck") or {}).get("pools") or (row.get("classification") or {}).get("pools") or []
    if isinstance(pools, str):
        pools = [pools]
    return [str(p) for p in pools if p]


def subtags(row):
    s = row.get("subtags") or (row.get("classification") or {}).get("subtags") or []
    if isinstance(s, str):
        s = [s]
    return [str(x) for x in s if x]


def class_label_kept(row, cf):
    loc = row.get("local_recheck") or {}
    cat = CAT_CN.get(loc.get("category") or "", None)
    if not cat:
        cat = "找房咨询" if loc.get("category") else "未记录具体分类"
    pools = main_pools(row)
    tags = subtags(row)
    intent = intent_cn(cf, row)
    bits = [cat]
    # prefer a concrete tag/pool for the middle part
    mid = None
    if tags:
        mid = "、".join(tags[:2])
    elif pools:
        mid = "、".join(pools[:2])
    if mid:
        bits.append(mid)
    if intent and intent != "未记录":
        bits.append(intent)
    return " · ".join(bits)


def budget_state_cn(state):
    return {
        "budget_at_least_4000": "评论里的预算至少四千",
        "budget_3000_3999_unverified": "评论里的预算在三千到四千之间，还待确认",
        "budget_3000_3999_requires_confirmation": "评论里的预算在三千到四千之间，需要再确认",
        "below_3000": "评论里的预算低于三千",
        "budget_unverified": "评论里没有写出明确的月租预算",
        "whole_home_monthly_budget_below_3000": "评论里写的整租预算低于三千",
    }.get(state or "", "未记录预算情况" if not state else state)


def reason_kept(row, cf, lit, place_hits):
    parts = []
    loc = row.get("local_recheck") or {}
    ev = loc.get("evidence")
    if isinstance(ev, list):
        ev = "，".join(str(x) for x in ev[:3] if x)
    ev = (str(ev).strip() if ev else "")
    text = text_of(row)
    if ev and ev not in ("", text):
        parts.append("分类依据主要来自评论里的这些话：" + ev[:80] + ("…" if len(ev) > 80 else ""))
    elif text:
        parts.append("是根据这条评论本身的意思来分的。")
    else:
        parts.append("评论原文未记录。")
    cat = loc.get("category") or ""
    if cat and CAT_CN.get(cat):
        parts.append("本地分类看成「" + CAT_CN[cat] + "」。")
    intent = intent_cn(cf, row)
    if intent and intent != "未记录":
        parts.append("意向评为" + intent + "。")
    b = (cf or {}).get("budget") or {}
    parts.append(budget_state_cn(b.get("state")) + "。")
    vr = (cf or {}).get("video_listed_rent") or {}
    if vr.get("state") == "below_floor" and vr.get("quote"):
        parts.append("视频里写了「" + str(vr.get("quote")) + "」，低于三千门槛；但这条评论自己报了够得上的预算，所以仍留在可发池。")
    elif vr.get("quote"):
        parts.append("视频里出现过标价「" + str(vr.get("quote")) + "」。")
    if (cf or {}).get("eligible_candidate"):
        parts.append("商务筛选判定可以进入可发名单。")
    return "".join(parts)


def reply_how(row, reply, lit, place_hits):
    draft = (reply or {}).get("draft_text") or ""
    if not draft.strip():
        return "未记录生成的回复"
    how = mother_phrase((reply or {}).get("template_id"), (reply or {}).get("status"))
    bits = [how]
    if lit["budget"]:
        bits.append("填入了预算「" + "、".join(lit["budget"]) + "」")
    else:
        bits.append("没有填预算")
    if lit["location"]:
        bits.append("填入了地点「" + "、".join(lit["location"]) + "」")
    elif place_hits:
        bits.append("地点槽位未记录，但回复里出现了地点「" + "、".join(place_hits) + "」")
    else:
        bits.append("没有填具体地点")
    if lit["layout"]:
        bits.append("还用到了户型「" + "、".join(lit["layout"]) + "」")
    if lit["time"]:
        bits.append("还用到了时间「" + "、".join(lit["time"]) + "」")
    return "；".join(bits) + "。"


def reason_excl(row, cf, labs):
    parts = []
    pretty = [EXCL_CN.get(x, x) for x in labs]
    if pretty:
        parts.append("排除原因：" + "；".join(pretty) + "。")
    vr = (cf or {}).get("video_listed_rent") or {}
    if vr.get("quote"):
        parts.append("视频里相关的话是「" + str(vr.get("quote")) + "」。")
    b = (cf or {}).get("budget") or {}
    if b.get("state") in ("below_3000",) or "whole_home_monthly_budget_below_3000" in labs:
        ev = b.get("evidence")
        if isinstance(ev, list) and ev:
            parts.append("评论预算依据：" + "、".join(str(x)[:40] for x in ev[:2]) + "。")
        else:
            parts.append("评论里的预算低于三千。")
    loc = row.get("local_recheck") or {}
    cat = loc.get("category") or ""
    if cat and CAT_CN.get(cat):
        parts.append("本地分类看成「" + CAT_CN[cat] + "」。")
    ev = loc.get("evidence")
    if isinstance(ev, list):
        ev = "，".join(str(x) for x in ev[:3] if x)
    if ev:
        parts.append("依据：" + str(ev)[:80] + ("…" if len(str(ev)) > 80 else "") + "。")
    why = (row.get("reason") or "").strip()
    if why and why not in "".join(parts):
        parts.append(why if why.endswith("。") else why + "。")
    if not parts:
        parts.append("被筛掉，但具体原因未记录。")
    return "".join(parts)


def class_label_excl(labs, row):
    if labs:
        return "排除：" + "；".join(EXCL_CN.get(x, x) for x in labs)
    loc = row.get("local_recheck") or {}
    cat = CAT_CN.get(loc.get("category") or "", "")
    if cat:
        return "排除：" + cat
    why = (row.get("reason") or "").strip()
    if why:
        return "排除：需求或语境不够明确"
    return "排除：未进入可发名单"


def pack_kept(row):
    cf = row.get("commercial_fit") or {}
    reply = row.get("reply") or {}
    draft = (reply.get("draft_text") or "").strip()
    lit = literals(reply)
    places = place_in_reply(draft, lit["location"])
    pub = shanghai(row.get("published_at") or row.get("published_at_unix"))
    return {
        "kind": "kept",
        "comment_id": str(row.get("comment_id") or ""),
        "customer_uid": str(row.get("customer_uid") or ""),
        "video_id": str(row.get("video_id") or ""),
        "comment_text": text_of(row),
        "video_snip": video_snip(row, cf),
        "分类": class_label_kept(row, cf),
        "这样分的原因": reason_kept(row, cf, lit, places),
        "生成的回复": draft or "未记录",
        "回复是怎么来的": reply_how(row, reply, lit, places),
        "intent": intent_cn(cf, row),
        "category": (row.get("local_recheck") or {}).get("category") or "未记录",
        "pools": main_pools(row),
        "subtags": subtags(row),
        "ip": row.get("ip_location_raw") or "未记录",
        "time_band": ((row.get("reply_priority") or {}).get("time_band") or "未记录"),
        "has_budget": bool(lit["budget"]),
        "has_place": bool(places or lit["location"]),
        "budget_state": ((cf.get("budget") or {}).get("state") or ""),
        "template_id": reply.get("template_id") or "",
        "published_at": pub.strftime("%Y-%m-%d %H:%M") + " Asia/Shanghai" if pub else "未记录",
        "published_unix": row.get("published_at_unix") or 0,
        "days_ago": days_ago(pub),
    }


def pack_excl(row, cf, labs):
    pub = shanghai(row.get("published_at") or row.get("published_at_unix"))
    return {
        "kind": "excluded",
        "comment_id": str(row.get("comment_id") or ""),
        "customer_uid": str(row.get("customer_uid") or ""),
        "video_id": str(row.get("video_id") or ""),
        "comment_text": text_of(row),
        "video_snip": video_snip(row, cf),
        "分类": class_label_excl(labs, row),
        "这样分的原因": reason_excl(row, cf, labs),
        "生成的回复": "不自动回",
        "回复是怎么来的": "因为被排除，不会自动生成回复。",
        "intent": intent_cn(cf, row),
        "category": (row.get("local_recheck") or {}).get("category") or "未记录",
        "labs": labs,
        "ip": row.get("ip_location_raw") or "未记录",
        "published_at": pub.strftime("%Y-%m-%d %H:%M") + " Asia/Shanghai" if pub else "未记录",
        "published_unix": row.get("published_at_unix") or 0,
        "days_ago": days_ago(pub),
        "has_budget": False,
        "has_place": False,
    }


def pick_diverse_kept(items, n=40):
    items = [x for x in items if (x.get("生成的回复") or "") not in ("", "未记录")]
    # prefer more recent, but not just the head of a pre-sorted list
    items = sorted(items, key=lambda x: (-(x["published_unix"] or 0), x["comment_id"]))
    chosen = []
    used_ids, used_videos = set(), Counter()

    def accept(x, max_per_video=2):
        if x["comment_id"] in used_ids:
            return False
        if used_videos[x["video_id"]] >= max_per_video:
            return False
        return True

    def add(x, max_per_video=2):
        if not accept(x, max_per_video):
            return False
        chosen.append(x)
        used_ids.add(x["comment_id"])
        used_videos[x["video_id"]] += 1
        return True

    def take(pred, k, max_per_video=2, newest=True):
        pool = [x for x in items if pred(x) and accept(x, max_per_video)]
        if not newest:
            # spread: take from different time bands / positions
            pool = pool[:: max(1, len(pool) // max(k * 2, 1))] + pool
            # unique preserve
            seen = set()
            uniq = []
            for x in pool:
                if x["comment_id"] not in seen:
                    seen.add(x["comment_id"])
                    uniq.append(x)
            pool = uniq
        got = 0
        for x in pool:
            if got >= k:
                break
            if add(x, max_per_video):
                got += 1
        return got

    # forced diversity
    take(lambda x: x["intent"] == "超高意向", 10)  # all 3
    take(lambda x: x["has_budget"] or x["budget_state"] == "budget_at_least_4000", 10)
    take(lambda x: x["intent"] == "高意向" and x["has_place"], 4)
    take(lambda x: x["intent"] == "高意向" and not x["has_place"], 3)
    take(lambda x: x["category"] == "explicit_rental_demand", 4)
    take(lambda x: x["category"] == "insufficient_current_rental_evidence", 2)
    take(lambda x: x["template_id"] == "negative_scoped_generic", 2)
    # cities / IP
    for ip, k in [("上海", 5), ("北京", 4), ("福建", 4), ("浙江", 3), ("四川", 3)]:
        take(lambda x, ip=ip: x["ip"] == ip and x["intent"] == "中意向", k, newest=False)
    # pools / tags
    def has_pool(x, name):
        return name in (x.get("pools") or []) or name in (x.get("subtags") or [])
    for name, k in [("价格预算", 2), ("位置通勤", 2), ("房源状态", 2), ("户型面积与居住方式", 2),
                    ("入住与租期", 2), ("房内设施", 2), ("合租", 2), ("短租", 1), ("空房查询", 2), ("问价", 2)]:
        take(lambda x, name=name: has_pool(x, name) and not x["has_budget"], k, newest=False)
    # mid intent without place or budget, recent
    take(lambda x: x["intent"] == "中意向" and not x["has_budget"] and not x["has_place"] and (x["days_ago"] or 99) <= 7, 6, newest=False)
    # fill remainder preferring 近7天 then 8-15, spread videos
    for pred in [
        lambda x: x["time_band"] == "近7天",
        lambda x: "8至15" in (x["time_band"] or ""),
        lambda x: True,
    ]:
        if len(chosen) >= n:
            break
        take(pred, n - len(chosen), newest=False)
    return chosen[:n]


def pick_excl(cands, n=10):
    # prefer one from each type, most recent first
    priority = [
        "低价视频-预算不符",
        "房源广告/中介",
        "非本人找房需求（劝告/科普/反问他人/房东经验）",
        "供给方：自有房找室友/分租出去",
        "交友/找搭子非租房",
        "whole_home_monthly_budget_below_3000",
        "demand_ended",
        "not_supported_customer_demand",
        "供给方：询问是否有人找房",
        "WEAK",
    ]
    chosen, used = [], set()

    def ok(x):
        return x["comment_id"] not in used and (x.get("comment_text") or "").strip()

    def newest_for(lab=None, weak=False, max_days=30):
        pool = []
        for x in cands:
            if not ok(x):
                continue
            if (x.get("days_ago") or 999) > max_days:
                continue
            labs = x.get("labs") or []
            if weak:
                if labs:
                    continue
                cat = x.get("category") or ""
                if cat in ("insufficient_current_rental_evidence", "interaction_only", "short_reference_requires_context", "mention_interaction_only", "experience_or_price_discussion"):
                    # need a reasonably clear weak example, not empty
                    if len(x.get("comment_text") or "") <= 40:
                        pool.append(x)
            else:
                if lab in labs:
                    pool.append(x)
        pool.sort(key=lambda z: (z.get("days_ago") is None, z.get("days_ago") or 0, z["comment_id"]))
        return pool

    for lab in priority:
        if len(chosen) >= n:
            break
        pool = newest_for(weak=True, max_days=30) if lab == "WEAK" else newest_for(lab, max_days=30)
        if not pool and lab != "WEAK":
            pool = newest_for(lab, max_days=45)
        if pool:
            x = pool[0]
            chosen.append(x)
            used.add(x["comment_id"])
    # fill if short
    if len(chosen) < n:
        rest = [x for x in sorted(cands, key=lambda z: (z.get("days_ago") is None, z.get("days_ago") or 0)) if ok(x)]
        for x in rest:
            if len(chosen) >= n:
                break
            chosen.append(x)
            used.add(x["comment_id"])
    return chosen[:n]


def main():
    blocked_cids, blocked_canons, canon = load_blocked()
    kept_rows = []
    with QPATH.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            row = json.loads(line)
            if is_blocked(row.get("comment_id"), row.get("customer_uid"), blocked_cids, blocked_canons, canon):
                continue
            st = ((row.get("delivery") or {}).get("status") or "")
            if st in ("sent", "unknown", "reserved"):
                continue
            packed = pack_kept(row)
            if packed["comment_text"] and packed["生成的回复"] not in ("", "未记录"):
                kept_rows.append(packed)
    print("kept usable", len(kept_rows))

    excl_rows = []
    with POOL.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            row = json.loads(line)
            cf = row.get("commercial_fit") or {}
            elig = cf.get("eligible_candidate") if "eligible_candidate" in cf else row.get("eligible_candidate")
            if elig:
                continue
            if is_blocked(row.get("comment_id"), row.get("customer_uid"), blocked_cids, blocked_canons, canon):
                continue
            labs = cf.get("exclusion_reason_labels") or row.get("exclusion_reason_labels") or []
            if not isinstance(labs, list):
                labs = [labs] if labs else []
            packed = pack_excl(row, cf, labs)
            if packed["comment_text"]:
                excl_rows.append(packed)
    print("excl usable", len(excl_rows), "with labels", sum(1 for x in excl_rows if x.get("labs")))

    kept40 = pick_diverse_kept(kept_rows, 40)
    # ensure 40
    if len(kept40) < 40:
        have = {x["comment_id"] for x in kept40}
        for x in sorted(kept_rows, key=lambda z: -(z["published_unix"] or 0)):
            if len(kept40) >= 40:
                break
            if x["comment_id"] not in have:
                kept40.append(x)
                have.add(x["comment_id"])
    excl10 = pick_excl(excl_rows, 10)

    # diversity report
    print("KEPT", len(kept40))
    print(" intent", Counter(x["intent"] for x in kept40))
    print(" cat", Counter(x["category"] for x in kept40))
    print(" ip", Counter(x["ip"] for x in kept40))
    print(" budget_filled", sum(1 for x in kept40 if x["has_budget"]), "place", sum(1 for x in kept40 if x["has_place"]))
    print(" time", Counter(x["time_band"] for x in kept40))
    print("EXCL", len(excl10))
    for x in excl10:
        print(" -", x["分类"], "|", (x["comment_text"] or "")[:40], "|", x["published_at"], "|", x.get("labs"))

    out = {"kept": kept40, "excluded": excl10, "queue": str(QPATH), "generated_at": "2026-11-12 18:32 Asia/Shanghai"}
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote", OUT, "bytes", OUT.stat().st_size)


if __name__ == "__main__":
    main()
