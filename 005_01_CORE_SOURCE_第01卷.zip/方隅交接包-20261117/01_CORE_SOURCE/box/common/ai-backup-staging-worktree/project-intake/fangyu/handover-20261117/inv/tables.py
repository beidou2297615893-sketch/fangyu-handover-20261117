import sqlite3,urllib.parse,json,os
P=[r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3',
r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3',
r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3',
r'C:\积木软件工坊\项目\方隅公寓客户版\outputs\软件完整交接\方隅软件交接包\06-账本快照\共享业务账本.sqlite3',
r'C:\积木软件工坊\项目\方隅公寓客户版\work\region-followup-20261027\verification\actual-data-1793083003306682900\workspace.sqlite3',
r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\codex_reviews.sqlite3',
r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\campaign.sqlite3']
out={}
for p in P:
  try:
    u='file:'+urllib.parse.quote(p.replace('\\','/'))+'?mode=ro&immutable=1'
    c=sqlite3.connect(u,uri=True)
    rows=c.execute("select type,name from sqlite_master where type in ('table','view') order by name").fetchall()
    out[p]={'size':os.path.getsize(p),'objects':[f'{t}:{n}' for t,n in rows]}
    c.close()
  except Exception as e: out[p]={'error':str(e)}
json.dump(out,open(r'C:\Users\rmsama\AppData\Local\Temp\fy_inv\tables.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print('ok')
