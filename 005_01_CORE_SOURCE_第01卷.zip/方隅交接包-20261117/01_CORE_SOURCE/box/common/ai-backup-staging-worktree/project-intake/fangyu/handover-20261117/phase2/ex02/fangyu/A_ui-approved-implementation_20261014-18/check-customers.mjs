import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createBackend} from './ui-preview/backend.mjs';
import {render,bind} from './ui-preview/pages/customers.mjs';
import * as customerPage from './ui-preview/pages/customers.mjs';
import {customerControls,customerQuery,actorMatches} from './ui-preview/pages/customers-data.mjs';

const state={connection:'connected',user:'fixture-employee',storeId:'fixture-store',store:'验证门店',scenario:'normal',customerView:{status:'ready',actor:{username:'fixture-employee',storeId:'fixture-store'},items:[],stats:{total:0,high:0,replied:0,handoff:null},total:0,page:1,pageSize:20,pages:1}};
let checks=0;const results=[];
function check(name,fn){fn();checks++;results.push({name,ok:true});process.stdout.write('PASS '+name+'\n');}
check('connected empty list never falls through to demonstration customers',()=>{
  const html=render(structuredClone(state));
  assert.match(html,/还没有客户记录/);
  assert.doesNotMatch(html,/小雨|陈先生|林女士|周先生|128|3500/);
  assert.match(html,/待交接[\s\S]*?—/);
});
const populated=()=>({...structuredClone(state),customerView:{...structuredClone(state.customerView),items:[{id:'opaque-a',name:'验证<&客户',need:'两居 · 地区待确认',rank:null,level:'意向未分级',contactLabel:'2026-10-12 09:30',replied:false,channel:'小红书',postTitle:'真实来源标题',quote:'仅来自 fixture 的原文',nextStep:'查看需求与来源'}],stats:{total:11,high:2,replied:3,handoff:null},total:11,page:1,pageSize:20,pages:1}});
check('connected rows use actual values, escaped text and all four sorts',()=>{
  const html=render(populated());
  assert.match(html,/验证&lt;&amp;客户/);
  assert.match(html,/真实来源标题/);
  assert.match(html,/意向未分级/);
  assert.match(html,/共 11 条/);
  for(const kind of ['intent','reply','time','post'])assert.match(html,new RegExp('data-customer-sort="'+kind+'"'));
  assert.doesNotMatch(html,/示例头像|portrait-woman|古北|小雨/);
  const scoped=populated();scoped.customerView.scope='employee-local-history';assert.match(render(scoped),/本机当前员工可见客户/);
});
check('contact time is Shanghai time while contact status remains distinct',()=>{
  const current=populated();Object.assign(current.customerView.items[0],{contactAt:'2026-10-16T03:15:00+00:00',contactLabel:'已回复',replied:true});let html=render(current);assert.match(html,/title="2026-10-16T03:15:00\+00:00"/);assert.match(html,/2026-10-16 11:15/);assert.match(html,/cs-contact-status">已回复</);
  Object.assign(current.customerView.items[0],{contactAt:'',contactLabel:'发送结果待确认',replied:false});html=render(current);assert.match(html,/暂无联系时间/);assert.match(html,/cs-contact-status">发送结果待确认</);assert.doesNotMatch(html,/cs-contact-status">已回复</);
  Object.assign(current.customerView.items[0],{contactAt:'not-an-ISO-time',contactLabel:'已登记联系'});html=render(current);assert.match(html,/暂无联系时间/);assert.match(html,/cs-contact-status">已登记联系</);
  Object.assign(current.customerView.items[0],{contactAt:null,contactLabel:'已复制，未确认发送'});html=render(current);assert.match(html,/cs-contact-status">已复制，未确认发送</);
});
check('other store and employee envelopes cannot leak rows or counts',()=>{
  for(const actor of [{username:'another-employee',storeId:'fixture-store'},{username:'fixture-employee',storeId:'another-store'}]){
    const changed=populated();changed.customerView.actor=actor;
    const html=render(changed);assert.doesNotMatch(html,/验证&lt;|真实来源标题|>11<|>3</);assert.match(html,/正在读取客户清单/);
  }
});
class Element{
  constructor(dataset={}){this.dataset=dataset;this.listeners={};this.value='';this.checked=false;}
  addEventListener(type,fn){this.listeners[type]=fn;}
  fire(type,event={}){return this.listeners[type]?.({target:this,preventDefault(){},...event});}
}
function harness(current){
  const elements=new Map(),groups=new Map(),calls=[],modals=[];
  const root={querySelector:selector=>elements.get(selector)||null,querySelectorAll:selector=>groups.get(selector)||[]};
  const ctx={state:current,actions:{loadCustomers:payload=>calls.push(['list',payload]),loadCustomerDetail:id=>calls.push(['detail',id]),exportCustomers:payload=>calls.push(['export',payload]),openCustomerSource:id=>calls.push(['source',id])},update:fn=>fn(current),modal:options=>{modals.push(options);return options;},toast:text=>calls.push(['toast',text])};
  return {elements,groups,calls,modals,root,ctx,add:(selector,dataset)=>{const e=new Element(dataset);elements.set(selector,e);return e;},group:(selector,records)=>{const rows=records.map(record=>new Element(record));groups.set(selector,rows);return rows;}};
}
check('all four sort controls request server ordering and reset pagination',()=>{
  const current=populated();render(current);current.customers.page=3;
  const h=harness(current),buttons=h.group('[data-customer-sort]',['intent','reply','time','post'].map(customerSort=>({customerSort})));
  bind(h.root,h.ctx);buttons.forEach(button=>button.fire('click'));
  assert.deepEqual(h.calls.map(([,query])=>[query.sort,query.sortDirection,query.page]),[['intent','asc',1],['reply','desc',1],['time','desc',1],['post','desc',1]]);
});
check('filter and completed Chinese composition request the real list',()=>{
  const current=populated();render(current);const h=harness(current),search=h.add('[data-customer-search]'),[filter]=h.group('[data-customer-filter-value]',[{customerFilterValue:'pending'}]);
  bind(h.root,h.ctx);filter.fire('click');search.fire('compositionstart');search.value='真实中文';search.fire('input',{isComposing:true});assert.equal(h.calls.length,1);search.fire('compositionend');
  assert.deepEqual(h.calls.map(([,query])=>[query.filter,query.query]),[['pending',''],['pending','真实中文']]);
});
check('selection and export confirm use actual opaque IDs',()=>{
  const current=populated();render(current);const h=harness(current),[checkbox]=h.group('[data-customer-check]',[{customerCheck:'opaque-a'}]),exportButton=h.add('[data-customer-export]');
  bind(h.root,h.ctx);checkbox.checked=true;checkbox.fire('change');exportButton.fire('click');assert.equal(h.calls.length,0);assert.match(h.modals[0].html,/已选/);h.modals[0].onConfirm();
  assert.deepEqual(h.calls,[['export',{query:'',filter:'all',sort:'intent',sortDirection:'desc',selectedIds:['opaque-a']}]]);
});
check('unselected export means all current filtered results, never the current page only',()=>{
  const current=populated();render(current);current.customers.query='住房';current.customers.filter='high';const h=harness(current),button=h.add('[data-customer-export]');
  bind(h.root,h.ctx);button.fire('click');assert.match(h.modals[0].html,/当前筛选的全部/);assert.match(h.modals[0].html,/按筛选导出最多3000位；已选批次最多100位/);h.modals[0].onConfirm();
  assert.deepEqual(h.calls,[['export',{query:'住房',filter:'high',sort:'intent',sortDirection:'desc'}]]);
});
check('selected export above 100 is blocked before opening confirmation',()=>{
  const current=populated();render(current);current.customers.checkedIds=Array.from({length:101},(_,i)=>'opaque-'+i);const h=harness(current),button=h.add('[data-customer-export]');bind(h.root,h.ctx);button.fire('click');assert.equal(h.modals.length,0);assert.deepEqual(h.calls,[['toast','已选客户每批最多导出100位，请减少勾选数量后重试。']]);
});
check('an export dialog cannot act after the employee switches stores',()=>{
  const current=populated();render(current);const h=harness(current),button=h.add('[data-customer-export]');bind(h.root,h.ctx);button.fire('click');current.storeId='another-store';h.modals[0].onConfirm();assert.equal(h.calls.length,0);
});
check('keyboard row selection requests matching real detail',()=>{
  const current=populated();render(current);const h=harness(current),[row]=h.group('[data-customer-row]',[{customerRow:'opaque-a'}]);bind(h.root,h.ctx);row.fire('keydown',{key:'Enter'});
  assert.equal(current.customers.selectedId,'opaque-a');assert.deepEqual(h.calls,[['detail','opaque-a']]);
});
check('detail source and evidence require matching actor and customer ID',()=>{
  const current=populated();render(current);current.customers.selectedId='opaque-a';current.customers.evidenceOpen=true;current.customerDetail={actor:{username:'fixture-employee',storeId:'fixture-store'},id:'opaque-a',status:'ready',item:{...current.customerView.items[0],quote:'原文 <script>禁止执行</script>',postUrl:'https://www.xiaohongshu.com/explore/fixture',evidence:['现有证据 <b>仅文本</b>']}};
  let html=render(current);assert.match(html,/原文 &lt;script&gt;/);assert.match(html,/现有证据 &lt;b&gt;/);assert.doesNotMatch(html,/<script>|<b>仅文本/);
  const h=harness(current),source=h.add('[data-customer-source]');bind(h.root,h.ctx);source.fire('click');assert.deepEqual(h.calls,[['source','opaque-a']]);
  current.customerDetail.actor.storeId='another-store';html=render(current);assert.doesNotMatch(html,/禁止执行|现有证据/);source.fire('click');assert.equal(h.calls.length,1);
});
check('reply and handoff controls never mutate real or preview reply state',()=>{
  const current=populated();render(current);current.customers.selectedId='opaque-a';const h=harness(current),batch=h.add('[data-customer-batch]'),reply=h.add('[data-customer-reply]'),handoff=h.add('[data-customer-handoff]');bind(h.root,h.ctx);batch.fire('click');reply.fire('click');handoff.fire('click');assert.equal(h.calls.length,0);assert.equal(current.reply,undefined);assert.equal(h.modals.length,3);assert.ok(h.modals.every(item=>item.html.includes('后续')||item.html.includes('下一批')));
});
check('static visual preview retains its original demonstration layout',()=>{
  const html=render({connection:'preview',scenario:'normal'});assert.match(html,/小雨/);assert.match(html,/>128</);assert.match(html,/示例头像/);
});
// Exercise the existing public viewModel/actions and real customer page binding.
// Browser DOM and HTTP are the only synthetic boundaries; response timing is
// controlled so a list and its detail arrive inside one IME composition.
await (async()=>{
  const name='Chinese IME survives list and detail responses, then queries the committed text';
  const source=readFileSync(new URL('./ui-preview/app.mjs',import.meta.url),'utf8');
  const section=(start,end)=>{const offset=source.indexOf(start);assert(offset>=0,start);const limit=source.indexOf(end,offset);assert(limit>offset,end);return source.slice(offset,limit);};
  const pending=[],requests=[],waiters=[];
  const backend=createBackend(async(url,options)=>{
    const request={url,options};requests.push(request);
    return new Promise(resolve=>{request.resolve=body=>resolve(new Response(JSON.stringify({ok:true,...body}),{status:200}));pending.push(request);waiters.shift()?.();});
  });
  const nextRequest=async()=>{if(!pending.length)await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('fixture request did not arrive')),2000);waiters.push(()=>{clearTimeout(timeout);resolve();});});return pending.shift();};
  let focused=null,search=null,writes=0,selectionWrites=0,currentRoot=null;
  const dummy=()=>({addEventListener(){},hasAttribute(){return false;}});
  const document={body:{dataset:{}},get activeElement(){return focused;},getElementById:id=>id==='page-content'?currentRoot:id==='customer-search'?search:{close(){}} ,querySelector:selector=>selector==='#customer-search'?search:dummy(),querySelectorAll:()=>[]};
  const app={querySelectorAll:()=>[],set innerHTML(html){
    writes++;const matched=html.match(/id="customer-search"[^>]*value="([^"]*)"/);
    search=matched?new Element():null;
    if(search){search.id='customer-search';search.value=matched[1];search.selectionStart=0;search.selectionEnd=0;search.focus=()=>{focused=search;};search.hasAttribute=()=>false;search.setSelectionRange=()=>{selectionWrites++;};}
    currentRoot={querySelector:selector=>selector==='[data-customer-search]'?search:null,querySelectorAll:()=>[]};
  }};
  const current=populated();Object.assign(current,{page:'customers',session:{user:{username:current.user}},capabilities:{customers:true}});
  const code=section('function navigate(page)','\nfunction toast')+'\n'+section('function update(mutator)','\nfunction modal')+'\n'+section("let customerScope=''",'\nasync function exportCustomers')+'\n'+section('function render(){','\ndocument.addEventListener');
  const api=new Function('state','document','app','pages','backend','customerControls','customerQuery','customerActorMatches','CSS',`
    let cleanup;const actorKey=()=>JSON.stringify([state.user,state.storeId||'']);
    const titles={customers:[],acquire:[]},location={hash:'#customers'},history={replaceState(){}},window={scrollTo(){}};
    const shell=html=>html,tools=()=>'',toast=()=>{},showActionError=error=>{throw error;},reconcilePlatformActor=async()=>{throw new Error('unexpected actor change');},syncPlatformPolling=()=>{};
    const ctx={state,actions:{loadCustomers,loadCustomerDetail,setCustomerSearchComposing:typeof setCustomerSearchComposing==='function'?setCustomerSearchComposing:undefined},update,toast,modal(){}};
    ${code}
    return {render,navigate};
  `)(current,document,app,{customers:customerPage,acquire:{render:()=>'<p>acquire fixture</p>',bind(){}}},backend,customerControls,customerQuery,actorMatches,{escape:value=>value});
  api.render();const list=await nextRequest();assert.match(list.url,/\/customers\?/);
  const composingInput=search;composingInput.focus();composingInput.fire('compositionstart');composingInput.value='yu';composingInput.fire('input',{isComposing:true});const before=writes,beforeSelection=selectionWrites;
  list.resolve({customers:structuredClone(current.customerView)});
  const detail=await nextRequest();assert.match(detail.url,/\/customer\?id=/);
  assert.equal(search,composingInput,'a list response must preserve the composing input');assert.equal(writes,before);
  const id=current.customerView.items[0].id;detail.resolve({customer:{actor:current.customerView.actor,id,item:current.customerView.items[0]}});
  await new Promise(resolve=>setTimeout(resolve,0));assert.equal(search,composingInput,'a detail response must preserve the composing input');assert.equal(document.activeElement,composingInput);assert.equal(writes,before);assert.equal(selectionWrites,beforeSelection,'asynchronous responses must not change the live IME selection');
  composingInput.value='预算';composingInput.fire('compositionend');assert.notEqual(search,composingInput);assert.equal(search.value,'预算');assert.equal(document.activeElement,search);
  const filtered=await nextRequest();assert.equal(new URL('http://fixture'+filtered.url).searchParams.get('query'),'预算');assert.equal(requests.filter(request=>request.url.includes('/customers?')).length,2);
  // A page change must discard the deferred render gate and stale responses.
  search.fire('compositionstart');api.navigate('acquire');assert.equal(document.body.dataset.page,'acquire');assert.equal(search,null);
  filtered.resolve({customers:structuredClone(current.customerView)});await new Promise(resolve=>setTimeout(resolve,0));assert.equal(document.body.dataset.page,'acquire');
  api.navigate('customers');const reopened=await nextRequest();assert.match(reopened.url,/\/customers\?/);assert(search,'returning to customers must render without the old IME gate');
  search.fire('compositionstart');current.storeId='another-store';api.render();assert.equal(search,null,'a changed actor must replace the previous employee input immediately');
  api.navigate('acquire');reopened.resolve({customers:structuredClone(current.customerView)});await new Promise(resolve=>setTimeout(resolve,0));
  checks++;results.push({name,ok:true});process.stdout.write('PASS '+name+'\n');
})();
writeFileSync(new URL('./frontend-customers-check.json',import.meta.url),JSON.stringify({ok:true,checks,results},null,2)+'\n');
process.stdout.write(JSON.stringify({ok:true,checks})+'\n');
