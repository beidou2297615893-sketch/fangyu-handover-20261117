"""Read-only r55 -> r56 UI release audit. Never imports or starts the App.

Default: verify the pinned r55 release, unchanged backend/runtime, and the narrow
UI integration. After publishing metadata: add --require-manifest --check-launcher.
Only source/runtime/asset trees and release/launcher files are read. Owner data,
databases, platform sessions and credentials are never accessed.
"""
from pathlib import Path, PurePosixPath
import argparse
import ast
import copy
import hashlib
import json
import re
import stat
import sys

sys.dont_write_bytecode = True
PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
BASE = PROJECT / 'work/ui-runtime-r55'
CANDIDATE = PROJECT / 'work/ui-runtime-r56'
BASE_MANIFEST_SHA256 = 'E4E33FDA9699EB610F7E092A2F23C4A39AD3AB2F8505895BB194BD9D09606CF5'
TREES = ('src', 'work/runtime', 'mirrors')
STYLES = ('approved-shell.css', 'approved-collection.css', 'approved-customers.css', 'approved-management.css')
MODULES = ('approved-ui.mjs', 'approved-collection.mjs', 'approved-customers.mjs')
ICONS = ('search', 'message-circle', 'users', 'user-round', 'settings')
ROUTES = {name: (name, 'text/css; charset=utf-8') for name in STYLES}
ROUTES.update({name: (name, 'text/javascript; charset=utf-8') for name in MODULES})
ROUTES.update({f'approved-icon-{name}.svg': (f'assets/approved-icon-{name}.svg', 'image/svg+xml') for name in ICONS})
ADDED = {'src/web/workspace/' + name for name in (*STYLES, *MODULES)}
ADDED.update('src/web/workspace/assets/approved-icon-' + name + '.svg' for name in ICONS)
ADDED.update('src/web/workspace/assets/fy-approved-' + name + '.png' for name in ('header-apartment', 'official-logo', 'sidebar-apartment'))
ADDED.add('src/resources/approved-ui-lucide-LICENSE.txt')
CHANGED = {'src/assistant/employee_workspace.py', 'src/web/workspace/index.html', 'src/web/workspace/self-operating-read.mjs'}


class AuditFailure(RuntimeError):
    pass


def need(condition, message):
    if not condition:
        raise AuditFailure(message)


def public_bytes(path, root):
    path.relative_to(root)
    for parent in (path, *path.parents):
        if parent == root.parent:
            break
        info = parent.lstat()
        need(not parent.is_symlink() and not getattr(info, 'st_file_attributes', 0) & 0x400,
             'Link or reparse point rejected: ' + str(path.relative_to(root)))
    before = path.stat()
    need(stat.S_ISREG(before.st_mode), 'Not a regular public file')
    raw = path.read_bytes()
    after = path.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'File changed while auditing')
    return raw


def digest(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def snapshot(root):
    result = {}
    for subtree in TREES:
        folder = root / subtree
        need(folder.is_dir(), 'Missing public tree: ' + subtree)
        for path in folder.rglob('*'):
            need(not path.is_symlink() and not getattr(path.lstat(), 'st_file_attributes', 0) & 0x400,
                 'Linked tree entry rejected')
            if path.is_file():
                raw = public_bytes(path, root)
                result[path.relative_to(root).as_posix()] = {'sha256': digest(raw), 'size': len(raw)}
    return result


def validate_manifest(root, files, expected_sha=None):
    raw = public_bytes(root / 'RELEASE.json', root)
    sha = digest(raw)
    if expected_sha:
        need(sha == expected_sha, 'Pinned baseline RELEASE.json hash mismatch')
    value = json.loads(raw)
    need(value.get('schema') == 'fangyu_local_code_release_v1', 'Invalid release schema')
    need(Path(value.get('project', '')) == PROJECT and value.get('source_root') == 'src', 'Invalid project/source binding')
    entries = value.get('files')
    need(type(entries) is list, 'Invalid manifest file list')
    expected = {}
    for item in entries:
        name = item.get('path', '')
        rel = PurePosixPath(name)
        need(name and not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name,
             'Unsafe manifest public path')
        need(any(name.startswith(tree + '/') for tree in TREES), 'Non-public manifest root')
        need(name not in expected, 'Duplicate manifest path')
        expected[name] = {'sha256': str(item.get('sha256', '')).upper(), 'size': item.get('size')}
    need(expected == files, 'Manifest bytes or public file set do not match')
    return {'sha256': sha, 'release_id': value.get('release_id'), 'files': len(expected)}


def text(root, name):
    return public_bytes(root / name, root).decode('utf-8').replace('\r\n', '\n')


def assignment(tree, name):
    matches = [n for n in tree.body if isinstance(n, ast.Assign)
               and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
    need(len(matches) == 1, 'Expected exactly one assignment: ' + name)
    return matches[0]


def audit_gateway(before, after):
    a, b = ast.parse(before), ast.parse(after)
    aa, bb = assignment(a, 'ASSETS'), assignment(b, 'ASSETS')
    old, new = ast.literal_eval(aa.value), ast.literal_eval(bb.value)
    need(not set(ROUTES) & set(old), 'Approved route unexpectedly overlaps baseline')
    need(new == {**old, **ROUTES}, 'Gateway permits changes beyond the exact UI asset routes')
    # The only semantic gateway change may be the known static ASSETS additions.
    bb.value = copy.deepcopy(aa.value)
    need(ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False),
         'Non-ASSETS backend/gateway change rejected')
    alines, blines = before.splitlines(True), after.splitlines(True)
    need(alines[:aa.lineno-1] == blines[:bb.lineno-1]
         and alines[aa.end_lineno:] == blines[bb.end_lineno:],
         'Backend text outside ASSETS changed')


def audit_integration(before, after):
    strips = [
        'let approvedUI=null;\n',
        ' if(approvedUI)approvedUI.sync(page);\n',
        "const {installApprovedUI}=await import(new URL('?asset=approved-ui.mjs',import.meta.url));\napprovedUI=installApprovedUI({state,show});\n",
    ]
    reduced = after
    for block in strips:
        need(reduced.count(block) == 1, 'Missing/duplicated approved UI integration')
        reduced = reduced.replace(block, '', 1)
    need(reduced == before, 'Original controller/API/guard change outside UI integration rejected')


def audit_html(before, after):
    block = ''.join(f'<link rel="stylesheet" href="?asset={name}">' for name in STYLES)
    need(after.count(block) == 1 and after.replace(block, '', 1) == before,
         'HTML change exceeds the approved stylesheet links')


def audit_launcher(root, manifest):
    before = ast.parse(text(BASE, 'run_workbench.py'))
    after = ast.parse(text(root, 'run_workbench.py'))
    old_manifest, new_manifest = assignment(before, 'MANIFEST_SHA256'), assignment(after, 'MANIFEST_SHA256')
    need(ast.literal_eval(new_manifest.value).upper() == manifest['sha256'], 'Launcher does not bind candidate manifest')
    release = assignment(after, 'RELEASE')
    expected_release = ast.parse("PROJECT / 'work/ui-runtime-r56'", mode='eval').body
    need(ast.dump(release.value) == ast.dump(expected_release), 'Launcher release path mismatch')
    status = assignment(after, 'STATUS_ROOT')
    allowed_status = [ast.parse("PROJECT / '" + p + "'", mode='eval').body for p in
                      ('work/new-ui-direct-release/launch-status', 'work/ui-approved-implementation/launch-status')]
    need(any(ast.dump(status.value) == ast.dump(p) for p in allowed_status), 'Unexpected launch diagnostics destination')
    for name in ('RELEASE', 'MANIFEST_SHA256', 'STATUS_ROOT'):
        assignment(after, name).value = copy.deepcopy(assignment(before, name).value)
    release_id = manifest['release_id']
    need(isinstance(release_id, str) and release_id and release_id != 'ui-core-r55', 'Candidate release needs its own identity')
    class NormalizeLabels(ast.NodeTransformer):
        def visit_Constant(self, node):
            if isinstance(node.value, str):
                node.value = node.value.replace(release_id, 'ui-core-r55').replace('R56-', 'R55-')
            return node
    after = NormalizeLabels().visit(after)
    need(ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False),
         'Launcher behavior differs beyond release/hash/diagnostic-label binding')
    return {'status': 'PASS', 'owner_platform_api_license_checks_unchanged': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--require-manifest', action='store_true')
    parser.add_argument('--check-launcher', action='store_true')
    args = parser.parse_args()
    need(not args.check_launcher or args.require_manifest, '--check-launcher also needs --require-manifest')
    base_files, candidate_files = snapshot(BASE), snapshot(CANDIDATE)
    baseline = validate_manifest(BASE, base_files, BASE_MANIFEST_SHA256)
    added = set(candidate_files) - set(base_files)
    removed = set(base_files) - set(candidate_files)
    changed = {name for name in set(base_files) & set(candidate_files) if base_files[name] != candidate_files[name]}
    need(not removed, 'Original public files removed: ' + ', '.join(sorted(removed)))
    need(added == ADDED, 'Unexpected/missing UI additions: ' + ', '.join(sorted(added ^ ADDED)))
    need(changed == CHANGED, 'Non-whitelisted source/runtime change: ' + ', '.join(sorted(changed ^ CHANGED)))
    audit_gateway(text(BASE, 'src/assistant/employee_workspace.py'), text(CANDIDATE, 'src/assistant/employee_workspace.py'))
    audit_integration(text(BASE, 'src/web/workspace/self-operating-read.mjs'), text(CANDIDATE, 'src/web/workspace/self-operating-read.mjs'))
    audit_html(text(BASE, 'src/web/workspace/index.html'), text(CANDIDATE, 'src/web/workspace/index.html'))
    for name in MODULES:
        value = text(CANDIDATE, 'src/web/workspace/' + name)
        need(not re.search(r'\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(|\bsendBeacon\s*\(|document\.cookie', value),
             'New direct transport/credential API in UI module: ' + name)
    report = {'status': 'PASS_SOURCE_SCOPE', 'baseline': baseline, 'candidate_public_files': len(candidate_files),
              'changed': sorted(changed), 'added': sorted(added), 'removed': [],
              'original_public_files_byte_identical': len(base_files)-len(changed),
              'backend_change': 'Exact static ASSETS additions only; remaining AST/text unchanged',
              'controller_change': 'UI variable, show sync, and setup-after import/install only',
              'platform_api_license_guards': 'Unchanged bytes outside the validated static asset table',
              'private_data_reads': 0, 'app_starts': 0, 'writes': 0,
              'candidate_manifest': 'Not checked; pending root finalization'}
    if args.require_manifest:
        report['candidate_manifest'] = validate_manifest(CANDIDATE, candidate_files)
        report['status'] = 'PASS_RELEASE_MANIFEST'
    if args.check_launcher:
        report['candidate_launcher'] = audit_launcher(CANDIDATE, report['candidate_manifest'])
        report['status'] = 'PASS_RELEASE_AND_LAUNCHER'
    if args.require_manifest:
        need(snapshot(CANDIDATE) == candidate_files, 'Candidate changed during final release verification')
        need(digest(public_bytes(CANDIDATE / 'RELEASE.json', CANDIDATE)) == report['candidate_manifest']['sha256'],
             'Candidate manifest changed during final release verification')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (AuditFailure, OSError, ValueError, KeyError, SyntaxError) as error:
        print(json.dumps({'status': 'FAIL', 'reason': str(error)}, ensure_ascii=False))
        raise SystemExit(1)
