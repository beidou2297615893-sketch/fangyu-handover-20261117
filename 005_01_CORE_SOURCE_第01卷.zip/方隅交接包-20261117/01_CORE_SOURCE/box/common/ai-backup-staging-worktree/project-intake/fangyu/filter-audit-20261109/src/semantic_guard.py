"""Douyin-only scoped semantics; original records and receipts stay immutable."""
import re, importlib.util, sys
from pathlib import Path
VERSION='douyin-semantic-scope-v5-20261102'
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'business-fit'))
import business_fit
spec=importlib.util.spec_from_file_location('v5base',Path(__file__).with_name('base_renderer.py'))
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
OLD_DETAILS=base._literal_details
DURATION=r'[一二两三四五六七八九十半\d]+(?:个?月|天|周|年)'
def details(text):
 d=OLD_DETAILS(text)
 # Only an explicit intended stay/lease anchors duration. Monthly prices,
 # search/discussion duration, contract history remain evidence, not slots.
 allowed=[]
 for match in re.finditer(r'(?:想|要|能|可以|打算|准备|计划)?(?:租|住)(?:个|上|满|大概|约|至少|最多)?('+DURATION+r')',text):
  pre=text[max(0,match.start()-6):match.start()]
  tail=text[match.end():match.end()+8]
  if re.search(r'以前|之前|已经|已|曾经|原来',pre) or re.match(r'[\d一二两三四五六七八九十百千]+(?:元|块|[，,。]|$)',tail):continue
  value=match.group(1)
  if re.fullmatch(r'[一二两三四五六七八九十半\d]+月',value):value=value[:-1]+'个月'
  allowed.append(value)
 for match in re.finditer('('+DURATION+r')(?:可以|能|可不可以)(?:租|住|吗|嘛)',text):
  value=match.group(1)
  if re.fullmatch(r'[一二两三四五六七八九十半\d]+月',value):value=value[:-1]+'个月'
  allowed.append(value)
 for value in d['time']:
  if re.search(r'(?:'+re.escape(value)+r').{0,4}(?:入住|搬家|起租|到期)|(?:入住|搬家|起租).{0,4}'+re.escape(value),text):allowed.append(value)
 for value in d['time']:
  if re.search(r'[下本这]个?月|月底|月初|明天|后天|[0-9一二三四五六七八九十]+月',value) and re.search(re.escape(value)+r'.{0,3}(?:租房|找房|搬|住|起租)',text):allowed.append(value)
 if re.search(r'(?:短租|租)一月二月',text):allowed=['一个月','两个月']
 d['time']=list(dict.fromkeys(allowed))
 # Don't present a regex fragment of a sentence as a place name.
 d['location']=[re.sub(r'^(?:我|都|没|有|找到|找找|找|还|在|想|要)+','',x) for x in d['location']]
 d['location']=[x for x in d['location'] if not re.search(r'马路|路人|骑|小电驴|后面|坐|异样|眼光|看着|我|你|他|她',x)]
 return d
base._literal_details=details
def state(text):
 # Questions/negation about finding a landlord are not completed demand.
 reopening=bool(re.search(r'但|但是|还想|还要|还在|想换|要换|重新找|再找|有推荐|求推荐|求房|求租|哪里有',text))
 ended=bool(re.search(r'(?:我)?(?:已经|已|刚刚|刚)?(?:租到(?:房|了)|租好(?:房|了)|找到(?:了)?房子了|找到房了|签好(?:了)?合同|不找了|不租了)',text))
 if re.search(r'没(?:有)?(?:找到|租到|租好)|还没|未(?:找到|租到)|怎么|如何|能.{0,3}找到|能.{0,3}租到',text):ended=False
 if re.search(r'(?:找到|租到|租好).{0,5}(?:吗|嘛|么|[?？])',text):ended=False
 choice=bool(re.search(r'(?:最后|最终)?决定(?:去)?租.{0,12}了',text))
 if ended and not reopening:return 'ended','明确表示租房已落实或不再寻找'
 if choice and not reopening:return 'choice_made_unconfirmed','已选定租赁方向；未证明签约，不主动续推'
 return 'active_or_unknown','不根据历史高意向推断当前已成交或仍在找'
def guard(row):
 t=row.get('comment_text') or row.get('text') or ''
 d=details(t); old=OLD_DETAILS(t); st,reason=state(t)
 passive_pet=bool(re.search(r'不养[猫狗]|不带[猫狗]|没养[猫狗]|没有[猫狗]',t))
 neg=bool(re.search(r'不要|不需要|不接受|不能|不养|不带|没养|没有[猫狗]|不合租',t))
 risky=bool(re.search(r'不能养.{0,2}[猫狗].{0,2}[吗嘛？?]|不让养',t))
 pools=list(row.get('pools') or [])
 if passive_pet:pools=[x for x in pools if x!='宠物']
 if old['time'] and not d['time'] and re.search(r'(?:找|看|说|问|等).{0,5}(?:半天|[一二两三四五六七八九十\d]+(?:个?月|天|周|年))',t) and not re.search(r'租期|短租|长租|月租|入住|起租|租多久|续租|到期',t):pools=[x for x in pools if x!='入住与租期']
 risky=risky or bool(re.search(r'(?:要是|如果).{0,8}真.{0,24}(?:退房|退租|房.{0,5}退)',t))
 status='review' if risky else 'corrected'
 if st!='active_or_unknown':status='not_outreach'
 return dict(version=VERSION,state=st,state_reason=reason,pools=pools,discarded_time_slots=[x for x in old['time'] if x not in d['time']],negative_conditions_preserved=base._negative_requirements(row,t,row.get('classification') or {}),passive_pet=passive_pet,negative=neg,status=status)
def render(row):
 g=guard(row); t=row.get('comment_text') or row.get('text') or ''
 fit=business_fit.screen(row)
 if fit['exclusion_reasons'] or any(x in fit['verification_required'] for x in ['budget_3000_3999_requires_confirmation','conflicting_budget_requires_confirmation','standalone_rental_amount_requires_confirmation','low_amount_scope_or_ceiling_unverified']):
  return dict(draft_text=None,status='commercial_fit_hold',semantic_guard=g,commercial_fit=fit,contact_hold='contact_or_brand_restricted' in fit['exclusion_reasons'],send_authorized=False)
 if g['status']!='corrected':return dict(draft_text=None,status=g['status'],semantic_guard=g,send_authorized=False)
 r=dict(row,pools=g['pools'])
 if not g['pools']:
  return dict(draft_text=None,status='needs_semantic_review',semantic_guard=g,send_authorized=False)
 if g['negative']:
  # Negatives constrain matching; don't copy them into a sales sentence.
  names={'价格预算':'价格','位置通勤':'位置','户型面积与居住方式':'房型','房内设施':'配套','宠物':'宠物需求','楼层电梯':'楼层','入住与租期':'租期','费用合同':'费用','看房联系':'看房'}
  needs=[names[p] for p in g['pools'] if p in names]
  body=('宝宝，'+('、'.join(needs[:2])+'可以一起了解下方隅这边，' if needs else '找房可以看看方隅这边，')+'我介绍有优惠。')
  result=dict(draft_text=body,status='negative_scoped_generic',send_authorized=False,template_id='negative_scoped_generic')
 else:result=base.render(r)
 result.update(semantic_guard=g,version=VERSION,reply_generation_model_calls=0)
 result['contact_hold']=bool(re.search(r'中介勿扰|不要中介(?!费)|不住公寓|不租公寓',t))
 return result
