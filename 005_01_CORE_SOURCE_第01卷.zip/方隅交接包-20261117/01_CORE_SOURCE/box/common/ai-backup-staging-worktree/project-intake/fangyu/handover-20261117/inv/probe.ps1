﻿$ErrorActionPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$out='C:\Users\rmsama\AppData\Local\Temp\fy_inv_probe.txt'
$L=New-Object System.Collections.Generic.List[string]
$L.Add('==DRIVES')
Get-PSDrive -PSProvider FileSystem | ForEach-Object { $L.Add(('{0}`t used={1:N1}GB`t free={2:N1}GB' -f $_.Name,($_.Used/1GB),($_.Free/1GB))) }
$L.Add('==GIT')
$g=Get-Command git -ErrorAction SilentlyContinue
if($g){$L.Add($g.Source); $L.Add((& git --version))}else{$L.Add('git not found')}
$L.Add('==TOP 积木软件工坊')
Get-ChildItem -Force 'C:\积木软件工坊' | ForEach-Object { $L.Add($_.FullName + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) }
foreach($p in @('C:\积木软件工坊\项目','C:\积木软件工坊\项目\方隅公寓客户版','C:\积木软件工坊\项目\方隅公寓客户版\work')){
 $L.Add('==LS '+$p)
 Get-ChildItem -Force $p | ForEach-Object { $L.Add($_.FullName + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm') + "`t" + $(if($_.PSIsContainer){'D'}else{$_.Length})) }
}
$L.Add('==LOCAL Fangyu*')
Get-ChildItem -Force 'C:\Users\rmsama\AppData\Local' -Directory | Where-Object { $_.Name -match 'fangyu|方隅|douyin|xhs|quiz|zhiti' } | ForEach-Object { $L.Add($_.FullName + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) }
$L.Add('==AI-Backup')
Get-ChildItem -Force 'C:\Users\rmsama\Documents\AI-Backup' | ForEach-Object { $L.Add($_.FullName + "`t" + $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) }
$L.Add('==OTHER DRIVE ROOTS')
Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -ne 'C' } | ForEach-Object { Get-ChildItem -Force ($_.Name+':\') | ForEach-Object { $L.Add($_.FullName) } }
$L.Add('==C ROOT')
Get-ChildItem -Force 'C:\' | ForEach-Object { $L.Add($_.FullName) }
$L.Add('==USER ROOT')
Get-ChildItem -Force 'C:\Users\rmsama' | ForEach-Object { $L.Add($_.FullName) }
[IO.File]::WriteAllLines($out,$L,(New-Object Text.UTF8Encoding($false)))
