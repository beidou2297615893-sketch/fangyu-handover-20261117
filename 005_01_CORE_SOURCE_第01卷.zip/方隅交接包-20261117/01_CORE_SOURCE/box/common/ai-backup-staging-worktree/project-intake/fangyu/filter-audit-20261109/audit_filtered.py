#!/usr/bin/env python3
"""只读复核：按已确认规则 + 现行 business_fit 对已筛评论做脚本核验。

不写账本、不启停进程、不改在用规则。仅读本地副本并写出复核结果。

运行方式（box）:
  python3 audit_filtered.py \\
    --screened data/screened-high-intent.jsonl \\
    --extra data/xiaohongshu-retained-business-customers.jsonl \\
    --extra data/retained-dy-sample-200.jsonl \\
    --watermark watermarks/last.json \\
    --out-dir out

水位（判断新一轮筛选完成）:
  1) 首选：当前全部高意向分池指针.json 的 results_sha256 + stats
  2) 其次：screened-high-intent.jsonl 的 mtime / 行数 / sha256
  3) 辅助：当前文本处理运行状态.json 的 douyin/xiaohongshu.sha256 与符合条件数
  仅当指针 SHA 或 screened 文件 SHA 相对上次水位变化时，视为新一轮筛选完成，再跑本脚本。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
import business_fit  # noqa: E402
import recency  # noqa: E402

CONFIRMED = {
    "budget_exclude_below": 3000,
    "budget_review_lo": 3000,
    "budget_review_hi": 3999,
    "budget_pass": 4000,
    "active_days": 30,
    "super_high_days": 15,
    "pools_expected": {
        "价格预算",
        "位置通勤",
        "户型面积与居住方式",
        "房内设施",
        "宠物",
        "楼层电梯",
        "入住与租期",
        "房源状态",
        "费用合同",
        "看房联系",
    },
}

NOW_DEFAULT = datetime(2026, 11, 9, 7, 30, tzinfo=timezone.utc)

AMOUNT_HINT = re.compile(
    r"(?:预算|月租|房租|租金)?.{0,6}("
    r"\d{3,5}|[一二两三四五六七八九十百千万]+[百千万]?|[1-9]\d?\s*[kK]"
    r").{0,6}(?:元|块|/月|每月|以内|以下|左右|上下|内)?"
)
LOW_HINT = re.compile(
    r"(?<!以前)(?<!之前)(?<!原来)(?<!曾经)(?:预算|月租).{0,8}(?:[12]\d{3}|两千|二千|一千|1千|2千|两千五|两千六|两千八)"
)
AROUND_3K = re.compile(r"(?:预算|月租|房租).{0,6}(?:3000|三千|3千).{0,3}(?:左右|上下)")
RANGE_3K = re.compile(
    r"(?:预算|月租).{0,8}(?:3[0-9]{3}|三千\s*[到至\-~—～]?\s*[三四]千?|[34]千).{0,4}(?:以内|以下|内|封顶)?"
)
NO_AGENT = re.compile(r"不要中介(?!费)|中介勿扰|只找(?:个人)?房东|只要个人房东")
IP_CITY = re.compile(r"^(北京|上海|杭州|成都|福州|深圳|广州)$")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_jsonl(path: Path):
    rows = []
    text = path.read_text(encoding="utf-8-sig")
    for i, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as e:
            rows.append({"_parse_error": str(e), "_line": i, "comment_id": f"parse_error_{i}"})
    return rows


def comment_id_of(row: dict) -> str:
    return str(row.get("comment_id") or row.get("cid") or row.get("_line") or "")


def platform_of(row: dict) -> str:
    return str(row.get("platform") or "unknown")


def text_of(row: dict) -> str:
    c = row.get("classification") or {}
    return str(row.get("comment_text") or row.get("text") or c.get("comment_text") or "")


def post_title_of(row: dict) -> str:
    c = row.get("classification") or {}
    meta = c.get("original_metadata") or {}
    return str(
        row.get("post_title")
        or meta.get("post_title")
        or (row.get("post_body") or "")[:40]
        or ""
    )


def original_fit(row: dict) -> dict:
    cf = row.get("commercial_fit")
    return cf if isinstance(cf, dict) else {}


def age_days(row: dict, now: datetime) -> float | None:
    ts = recency.stamp(row)
    if ts is None:
        return None
    return max(0.0, (now.timestamp() - ts) / 86400.0)


def independent_budget_flags(text: str) -> list[str]:
    flags = []
    if AROUND_3K.search(text):
        flags.append("confirmed_rule:预算约3000应进待核(3000-3999)")
    if re.search(r"(?:预算|月租).{0,10}(?:3500|三千五|3千5).{0,4}(?:以内|以下|内|封顶)?", text):
        flags.append("confirmed_rule:预算3500档应进待核(3000-3999)")
    if re.search(
        r"(?<!以前)(?<!之前)(?<!原来)(?<!曾经)(?:预算|月租).{0,10}(?:两千五六|两千五|两千六|两千八|2500|2600|2800|2000|1500|1800)",
        text,
    ):
        flags.append("confirmed_rule:明确低于3000应排除或至少不得直接高意向通过")
    if re.search(r"(?:预算|月租).{0,6}(?:4000|4千|四千).{0,2}以下", text):
        flags.append("edge:预算4000以下被当成>=4000通过(边界)")
    if re.fullmatch(r"\s*\d{3,5}\s*(?:元|块)?\s*", text) or re.search(
        r"^(?:就|大概|大约)?\s*\d{3,5}\s*(?:元|块)?\s*$", text.strip()
    ):
        flags.append("confirmed_rule:孤立金额应进待核")
    return flags


def pools_of(row: dict) -> list[str]:
    c = row.get("classification") or {}
    pools = c.get("pools") or c.get("pool_labels") or c.get("topics") or []
    out = []
    for p in pools:
        if isinstance(p, str):
            out.append(p)
        elif isinstance(p, dict):
            out.append(str(p.get("name") or p.get("pool") or p.get("topic") or p))
        else:
            out.append(str(p))
    return out


def issue(
    rows_out: list,
    row: dict,
    original: str,
    audit: str,
    itype: str,
    reason: str,
    severity: str = "med",
):
    rows_out.append(
        {
            "评论标识": comment_id_of(row),
            "平台": platform_of(row),
            "原判": original,
            "复核判": audit,
            "问题类型": itype,
            "严重度": severity,
            "理由": reason,
            "评论摘要": text_of(row)[:80].replace("\n", " "),
            "来源帖摘要": post_title_of(row)[:60].replace("\n", " "),
            "预算状态原": (original_fit(row).get("budget") or {}).get("state"),
            "意向原": original_fit(row).get("lead_intent"),
        }
    )


def audit_row(row: dict, now: datetime, issues: list, stats: Counter):
    if row.get("_parse_error"):
        issue(issues, row, "parse_error", "invalid", "数据损坏", row["_parse_error"], "high")
        stats["parse_error"] += 1
        return

    text = text_of(row)
    plat = platform_of(row)
    ofit = original_fit(row)
    orig_intent = ofit.get("lead_intent") or row.get("interest_at_comment") or row.get("interest") or ""
    orig_state = ofit.get("candidate_state") or ""
    budget_state = (ofit.get("budget") or {}).get("state")

    # Re-run live business_fit
    try:
        refit = business_fit.screen(row, now=now.timestamp())
    except Exception as e:  # noqa: BLE001
        issue(issues, row, orig_intent, "error", "复算失败", str(e), "high")
        stats["rescreen_error"] += 1
        return

    stats["rows"] += 1
    stats[f"platform:{plat}"] += 1
    stats[f"orig_intent:{orig_intent}"] += 1

    # Compare re-screen
    if refit.get("lead_intent") != orig_intent and ofit:
        issue(
            issues,
            row,
            str(orig_intent),
            str(refit.get("lead_intent")),
            "复算不一致",
            f"原 commercial_fit 与现行 {business_fit.VERSION} 复算意向不同; "
            f"exclusion={refit.get('exclusion_reasons')}; holds={refit.get('verification_required')}",
            "med",
        )
        stats["rescreen_mismatch"] += 1

    age = age_days(row, now)
    if age is None:
        issue(issues, row, orig_intent, "待核", "时间不明", "评论时间缺失或无法解析，应按不明隔离", "med")
        stats["time_unknown"] += 1
    elif age > CONFIRMED["active_days"]:
        if orig_intent in ("medium", "high", "super_high") or ofit.get("eligible_candidate"):
            issue(
                issues,
                row,
                orig_intent,
                "应出有效池",
                "超出时间窗",
                f"评论约{age:.1f}天前，超过滚动30天仍在中高意向/候选",
                "high",
            )
            stats["over_30d"] += 1
    elif age > CONFIRMED["super_high_days"] and orig_intent == "super_high":
        issue(
            issues,
            row,
            "super_high",
            "high",
            "超高时效不符",
            f"评论约{age:.1f}天前，超高意向要求近15天",
            "high",
        )
        stats["super_high_over_15d"] += 1

    # Confirmed budget rules vs original labeling
    for flag in independent_budget_flags(text):
        if "低于3000" in flag and orig_intent in ("medium", "high", "super_high") and budget_state not in (
            "below_3000",
        ):
            issue(
                issues,
                row,
                f"{orig_intent}/{budget_state}",
                "应排除或待核",
                "预算判错",
                flag + f"; 现行budget.state={budget_state}",
                "high",
            )
            stats["budget_low_miss"] += 1
        elif "3000-3999" in flag or "3500" in flag or "约3000" in flag:
            if budget_state not in ("budget_3000_3999_unverified",) and orig_intent in (
                "high",
                "super_high",
                "medium",
            ):
                # 左右被清成 unverified 且仍高意向通过，属问题
                if budget_state in (None, "budget_unverified") and ofit.get("eligible_candidate"):
                    issue(
                        issues,
                        row,
                        f"{orig_intent}/{budget_state}",
                        "待核(3000-3999)",
                        "预算判错",
                        flag + f"; 现行把左右/内档清成{budget_state}仍eligible",
                        "high",
                    )
                    stats["budget_mid_miss"] += 1
        elif "孤立金额" in flag and orig_intent in ("high", "super_high") and ofit.get("eligible_candidate"):
            issue(
                issues,
                row,
                orig_intent,
                "待核",
                "预算判错",
                flag,
                "med",
            )
            stats["budget_ambiguous_pass"] += 1
        elif "4000以下" in flag and budget_state == "budget_at_least_4000":
            issue(
                issues,
                row,
                f"{orig_intent}/{budget_state}",
                "边界待核",
                "预算边界",
                flag,
                "low",
            )
            stats["budget_edge_4000"] += 1

    # Source-post price used as if customer budget? Flag if exclusion uses source only while comment has no amount
    excl = ofit.get("exclusion_reasons") or []
    if "source_post_advertised_rent_below_3000" in excl and not AMOUNT_HINT.search(text):
        # This may be intentional per 意向分级, but conflicts with “来源帖低价不算客户预算” wording
        issue(
            issues,
            row,
            orig_intent,
            "复核:来源低价≠客户预算",
            "来源帖冒充预算",
            "排除原因含 source_post_advertised_rent_below_3000，评论文本无客户预算证据",
            "med",
        )
        stats["source_price_as_budget"] += 1

    # IP used as store binding
    ip = row.get("ip_location_raw") or (row.get("classification") or {}).get("ip_location_raw")
    selected = row.get("selected_store") or row.get("candidate_store")
    if selected and ip and IP_CITY.match(str(ip).strip()):
        # if comment has no place name overlapping store city, suspicious
        issue(
            issues,
            row,
            str(selected),
            "不应仅凭IP定店",
            "凭IP定店",
            f"IP={ip}, selected/candidate={selected}",
            "high",
        )
        stats["ip_store_bind"] += 1

    # 不要中介: confirmed = scoped tag, not discard. Live XHS discards; DY holds.
    if NO_AGENT.search(text):
        if plat == "xiaohongshu" and (
            "contact_or_brand_restricted" in excl
            or orig_intent in ("uncertain", "non_customer", "low")
            or ofit.get("eligible_candidate") is False
        ):
            issue(
                issues,
                row,
                orig_intent or str(excl),
                "应打范围标签待核",
                "联系限制过严",
                "小红书对「不要中介」直接拦截；已确认规则要求按范围打标签不直接丢弃",
                "high",
            )
            stats["no_agent_xhs_drop"] += 1
        holds = ofit.get("verification_required") or []
        if plat == "douyin" and "contact_identity_requires_confirmation" not in holds and ofit.get(
            "eligible_candidate"
        ):
            # may already be held elsewhere; soft check
            if "中介勿扰" in text or "不要中介" in text:
                if "contact_identity_requires_confirmation" not in holds:
                    issue(
                        issues,
                        row,
                        orig_intent,
                        "应标记身份待核",
                        "漏标签",
                        "抖音「不要中介」未见 contact_identity_requires_confirmation",
                        "med",
                    )
                    stats["no_agent_dy_miss_hold"] += 1

    # Pool labels missing when clear demand signals exist
    pools = pools_of(row)
    if orig_intent in ("high", "super_high", "medium"):
        if not pools:
            issue(issues, row, orig_intent, "缺池标签", "漏标签", "中高意向无十池标签", "low")
            stats["missing_pools"] += 1
        else:
            unknown = [p for p in pools if p not in CONFIRMED["pools_expected"]]
            if unknown:
                issue(
                    issues,
                    row,
                    ",".join(pools),
                    "非十池名",
                    "标签异常",
                    f"非标准池名: {unknown}",
                    "low",
                )
                stats["nonstandard_pool"] += 1

    # eligible high with hard budget mid unresolved due to 左右
    if ofit.get("eligible_candidate") and budget_state == "budget_unverified":
        if AROUND_3K.search(text) or re.search(r"3[0-9]{3}\s*内", text):
            stats["eligible_with_mid_budget_unparsed"] += 1


def find_duplicates(rows: list[dict], issues: list, stats: Counter):
    by_cid = defaultdict(list)
    by_cust = defaultdict(list)
    for r in rows:
        cid = comment_id_of(r)
        if cid:
            by_cid[(platform_of(r), cid)].append(r)
        cuid = r.get("customer_uid")
        if cuid:
            by_cust[(platform_of(r), cuid)].append(r)
    for k, grp in by_cid.items():
        if len(grp) > 1:
            issue(
                issues,
                grp[0],
                f"x{len(grp)}",
                "重复评论",
                "重复评论",
                f"同一平台 comment_id 出现 {len(grp)} 次",
                "med",
            )
            stats["dup_comment"] += 1
    for k, grp in by_cust.items():
        if len(grp) > 1:
            # not always wrong (multiple comments), flag for review list
            stats["multi_comment_customer"] += 1
            if len(grp) >= 3:
                issue(
                    issues,
                    grp[0],
                    f"客户{len(grp)}条",
                    "同客多评",
                    "重复客户",
                    f"同平台同客户 {len(grp)} 条已筛记录",
                    "low",
                )


def select_semantic_sample(rows: list[dict], issues: list, limit: int = 40) -> list[dict]:
    """Pick disputed / amount / contact-limit comments for DeepSeek."""
    prioritized = []
    issue_ids = {i["评论标识"] for i in issues if i["严重度"] in ("high", "med")}
    for r in rows:
        t = text_of(r)
        score = 0
        if comment_id_of(r) in issue_ids:
            score += 5
        if AMOUNT_HINT.search(t):
            score += 3
        if NO_AGENT.search(t):
            score += 2
        if (original_fit(r).get("budget") or {}).get("state") == "budget_unverified" and AMOUNT_HINT.search(t):
            score += 4
        if score:
            prioritized.append((score, r))
    prioritized.sort(key=lambda x: (-x[0], comment_id_of(x[1])))
    # diversify by platform
    picked = []
    seen = set()
    for _, r in prioritized:
        cid = comment_id_of(r)
        if cid in seen:
            continue
        seen.add(cid)
        picked.append(r)
        if len(picked) >= limit:
            break
    return picked


def write_semantic_prompt(samples: list[dict], path: Path):
    items = []
    for r in samples:
        ofit = original_fit(r)
        items.append(
            {
                "id": comment_id_of(r),
                "platform": platform_of(r),
                "comment_text": text_of(r)[:300],
                "comment_time": r.get("comment_published_at") or r.get("published_at"),
                "post_title_or_body_head": post_title_of(r)[:120],
                "original_intent": ofit.get("lead_intent"),
                "original_budget_state": (ofit.get("budget") or {}).get("state"),
                "original_exclusion": ofit.get("exclusion_reasons"),
                "original_holds": ofit.get("verification_required"),
            }
        )
    path.write_text(
        "你是租房获客筛选复核员。只根据给定字段判断，不要编造未提供的信息，不要输出身份信息。\n"
        "已确认规则：\n"
        "1) 时间以评论日期滚动30天；超高意向需近15天。\n"
        "2) 预算只认客户自己评论的月租：<3000排除；3000-3999待核；>=4000可通过。来源帖低价不算客户预算。孤立金额待核。\n"
        "3) 明确地名优先于IP；区级词只作区域候选，不绑单店。\n"
        "4) 「不要中介」打范围标签待核，不直接丢弃；明确不要联系/不租公寓可拦截。\n"
        "5) 十个需求池可多标签。\n\n"
        "对每条输出 JSON 数组元素：{id, audit_intent, audit_budget, problems:[], one_line_reason}\n"
        "audit_intent 取: super_high|high|medium|low|uncertain|non_customer|ended\n"
        "audit_budget 取: below_3000|mid_3000_3999|at_least_4000|unverified|ambiguous\n"
        "只输出 JSON 数组，不要前言。\n\n"
        + json.dumps(items, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_watermark(path: Path | None) -> dict:
    if not path or not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def save_watermark(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description="只读筛选复核")
    ap.add_argument("--screened", type=Path, required=True, help="主已筛结果 jsonl")
    ap.add_argument("--extra", type=Path, action="append", default=[], help="额外已筛/保留池 jsonl")
    ap.add_argument("--pointer", type=Path, default=ROOT / "src" / "当前全部高意向分池指针.json")
    ap.add_argument("--status", type=Path, default=ROOT / "src" / "当前文本处理运行状态.json")
    ap.add_argument("--watermark", type=Path, default=ROOT / "watermarks" / "last.json")
    ap.add_argument("--out-dir", type=Path, default=ROOT / "out")
    ap.add_argument("--now", type=str, default="2026-11-09T07:30:00+00:00")
    ap.add_argument("--semantic-limit", type=int, default=40)
    ap.add_argument("--force", action="store_true", help="忽略水位强制全量")
    args = ap.parse_args()

    now = datetime.fromisoformat(args.now)
    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    screened_sha = sha256_file(args.screened) if args.screened.exists() else None
    pointer = {}
    if args.pointer.exists():
        pointer = json.loads(args.pointer.read_text(encoding="utf-8-sig"))
    status = {}
    if args.status.exists():
        status = json.loads(args.status.read_text(encoding="utf-8-sig"))

    wm_new = {
        "checked_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "screened_path": str(args.screened),
        "screened_sha256": screened_sha,
        "screened_mtime": args.screened.stat().st_mtime if args.screened.exists() else None,
        "screened_lines": None,
        "pointer_results_sha256": pointer.get("results_sha256"),
        "pointer_stats": pointer.get("stats"),
        "status_douyin_sha256": (status.get("douyin") or {}).get("sha256"),
        "status_xhs_sha256": (status.get("xiaohongshu") or {}).get("sha256"),
        "business_fit_version_code": business_fit.VERSION,
        "business_fit_code_sha256": sha256_file(ROOT / "src" / "business_fit.py"),
    }

    wm_old = load_watermark(args.watermark)
    changed = (
        args.force
        or not wm_old
        or wm_old.get("screened_sha256") != screened_sha
        or wm_old.get("pointer_results_sha256") != pointer.get("results_sha256")
    )
    if not changed:
        summary = {
            "skipped": True,
            "reason": "水位未变：screened SHA 与指针 results_sha256 同上次",
            "watermark": wm_old,
        }
        (out_dir / "skip.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0

    rows = load_jsonl(args.screened)
    wm_new["screened_lines"] = len(rows)
    sources = [("screened-high-intent", rows)]
    for p in args.extra:
        if p.exists():
            er = load_jsonl(p)
            sources.append((p.name, er))
            rows = rows + er

    issues: list[dict] = []
    stats: Counter = Counter()
    # Dedup audit identity by platform+comment_id keeping first source
    seen = set()
    unique_rows = []
    for r in rows:
        key = (platform_of(r), comment_id_of(r))
        if key in seen and key[1]:
            stats["input_dup_skipped"] += 1
            continue
        seen.add(key)
        unique_rows.append(r)

    for r in unique_rows:
        audit_row(r, now, issues, stats)

    find_duplicates(unique_rows, issues, stats)

    # Write CSV
    csv_path = ROOT / "复核问题清单.csv"
    fields = [
        "评论标识",
        "平台",
        "原判",
        "复核判",
        "问题类型",
        "严重度",
        "理由",
        "评论摘要",
        "来源帖摘要",
        "预算状态原",
        "意向原",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in issues:
            w.writerow({k: row.get(k, "") for k in fields})

    semantic = select_semantic_sample(unique_rows, issues, args.semantic_limit)
    prompt_path = ROOT / "prompts" / "semantic-batch.json.txt"
    write_semantic_prompt(semantic, prompt_path)

    # Persist machine-readable issues + stats
    (out_dir / "issues.json").write_text(json.dumps(issues, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "stats.json").write_text(json.dumps(dict(stats), ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "semantic_ids.json").write_text(
        json.dumps([comment_id_of(r) for r in semantic], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    save_watermark(args.watermark, wm_new)

    type_counts = Counter(i["问题类型"] for i in issues)
    sev = Counter(i["严重度"] for i in issues)
    print(
        json.dumps(
            {
                "rows_unique": len(unique_rows),
                "issues": len(issues),
                "by_type": type_counts,
                "by_severity": sev,
                "stats": stats,
                "semantic_prompt": str(prompt_path),
                "csv": str(csv_path),
                "watermark": wm_new,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
