"""Progress viewer. Opening the window never starts collection."""
from pathlib import Path
import json,sqlite3,hashlib,tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from tkinter.scrolledtext import ScrolledText
from continue_collection import confirmation_event,continue_active,gate,last_state,running
B=Path(__file__).resolve().parent
w=tk.Tk();w.title('抖音采集｜进度与继续');w.geometry('1000x720')
label=tk.StringVar();summary_label=tk.Label(w,textvariable=label,font=('Microsoft YaHei UI',13),justify='left');summary_label.pack(padx=12,pady=12)
box=ScrolledText(w,font=('Microsoft YaHei UI',10));box.pack(fill='both',expand=True,padx=12,pady=8)
tk.Label(w,text='关闭窗口不会停止采集。停止后会保留已完成的回执和断点。').pack()
feedback=tk.StringVar()
feedback_label=tk.Label(w,textvariable=feedback,wraplength=940,font=('Microsoft YaHei UI',11))
feedback_label.pack()
actions=tk.Frame(w);actions.pack(pady=12,before=summary_label)
help_label=tk.Label(w,text='请先在浏览器完成验证码，再点绿色按钮。会跳过上一条结果未知的记录继续采集。',font=('Microsoft YaHei UI',11),wraplength=950)
help_label.pack(pady=4,before=summary_label)
feedback_label.pack(before=summary_label)
executor=ThreadPoolExecutor(max_workers=1)
confirmed_event=None
def stop():
 a=json.loads((B/'active-runner.json').read_text(encoding='utf-8'));(B/a['directory']/'STOP').write_text('User requested stop from progress window',encoding='utf-8')
def continue_clicked():
 continue_button.configure(state='disabled')
 feedback.set('正在核对采集状态和原断点…')
 result=executor.submit(continue_active,confirmed_event)
 def check():
  if not result.done():
   w.after(100,check)
   return
  try:feedback.set(result.result())
  except Exception:feedback.set('无法完成本地核对。请查看采集日志。')
  finally:continue_button.configure(state='normal')
 w.after(100,check)
continue_button=tk.Button(actions,text='验证已完成，继续采集',command=continue_clicked,font=('Microsoft YaHei UI',17,'bold'),bg='#15803d',fg='white',activebackground='#166534',activeforeground='white',padx=24,pady=12)
continue_button.pack(side='left',padx=6)
tk.Button(actions,text='停止采集并保留当前结果',command=stop).pack(side='left',padx=6)

def _parse_run_start(a):
 for key in ('continued_at','started_at'):
  raw=a.get(key)
  if not raw: continue
  try:
   dt=datetime.fromisoformat(raw)
  except ValueError:
   continue
  if dt.tzinfo is None:
   dt=dt.replace(tzinfo=timezone.utc)
  return dt,key
 return None,None

def _scan_comment_stats(stdout_path):
 """Sum comment-page recent_counts from runner stdout (read-only)."""
 scanned=0
 comment_pages=0
 known=False
 try:
  lines=stdout_path.read_text(encoding='utf-8',errors='replace').splitlines()
 except OSError:
  return None,0
 for line in lines:
  try:event=json.loads(line)
  except ValueError:continue
  if event.get('state')!='page_committed' or event.get('kind')!='comments':
   continue
  comment_pages+=1
  rc=event.get('recent_counts')
  if isinstance(rc,dict) and rc:
   known=True
   scanned+=sum(int(rc.get(k) or 0) for k in rc)
  elif event.get('added') is not None:
   # only added is incomplete for scanned; keep known false unless recent_counts seen
   pass
 return (scanned if known else None), comment_pages

def poll():
 global confirmed_event
 try:
  a=json.loads((B/'active-runner.json').read_text(encoding='utf-8'));p=json.loads((B/a['plan']).read_text(encoding='utf-8'));s=json.loads((B/a['directory']/'control.json').read_text(encoding='utf-8'))
  with sqlite3.connect((B/'runtime/collection.sqlite3').as_uri()+'?mode=ro',uri=True) as c:
   pages=c.execute('select count(*) from scan_pages where scan_id=?',(p['scan_id'],)).fetchone()[0]
   added=c.execute("select count(*) from entities e join attempts a on a.request_id=e.first_request where e.kind='comments' and json_extract(a.spec,'$.scan_id')=?",(p['scan_id'],)).fetchone()[0]
  stdout_path=B/a['stdout']
  raw_log=stdout_path.read_text(encoding='utf-8',errors='replace')[-12000:]
  activity=[]
  for line in raw_log.splitlines():
   try:event=json.loads(line)
   except ValueError:continue
   if event.get('state')=='page_committed':
    activity.append('已完成一次搜索' if event.get('kind')=='search' else '已处理一页评论，正在按规则筛选')
   elif event.get('state')=='paused':activity.append('采集已暂停，请查看顶部状态')
  text='\n'.join(activity[-20:])
  live=running(a.get('pid'))
  halt=None
  if live:
   state='正在请求并等待回执' if s.get('pending') else '运行中，按页间隔等待'
  else:
   state='已暂停，待核对上一页回执' if s.get('pending') else '已停止'
   state={'target_reached':'已达到累计目标','awaiting_candidate_review':'等待候选核查','sources_exhausted':'候选已耗尽'}.get(last_state(B/a['stdout']),state)
   halt=gate(B/'runtime/collection.sqlite3',p['account_uid'],p['scan_id'])['halt']
   if halt:
    state={'unknown':'已暂停，上一页结果未知','verification_required':'已暂停，等待抖音验证','platform_error':'已暂停，等待核查抖音回执'}.get(halt['state'],'已暂停，等待核查采集回执')
  waiter=json.loads((B/'collection-wait-state.json').read_text(encoding='utf-8')) if (B/'collection-wait-state.json').exists() else {}
  if not live and running(waiter.get('pid')) and waiter.get('mode') in ('waiting_for_connection','recovering_connection','waiting_for_user_check'):
   state={'waiting_for_connection':'等待连接恢复（未重复请求超时页）','recovering_connection':'正在核对连接，随后跳过超时页','waiting_for_user_check':'等待你检查浏览器连接或验证提示'}[waiter['mode']]
  confirmed_event=confirmation_event(halt)
  if not feedback.get().startswith('正在核对'):
   caption='正在采集' if live else ('验证已完成，继续采集' if confirmed_event else '继续采集')
   continue_button.configure(text=caption,state='disabled' if live or (halt and not confirmed_event) else 'normal')
  nickname=a.get('account_nickname','Aliie✨');baseline=a.get('batch_baseline',35588)
  progress=json.loads((B/a.get('diagnostic','progress-report-state.json')).read_text(encoding='utf-8'))
  total=progress.get('total_qualified_comments',baseline)
  days=a.get('maximum_comment_age_days',30)
  handoff=json.loads((B/'classification-handoff-status.json').read_text(encoding='utf-8'))
  pool=handoff.get('active_pool',{})
  eligible=progress.get('total_qualified_comments',pool.get('active_registered',0))
  candidates=handoff.get('pending_candidates_count',0)
  intent_counts=handoff.get('commercial_fit',{}).get('lead_intent_counts',{})
  leads=sum(intent_counts.get(level,0) for level in ('medium','high','super_high'))
  visible=handoff.get('visible_business_pool',{})
  if visible.get('file') and visible.get('sha256'):
   content=Path(visible['file']).read_bytes()
   if hashlib.sha256(content).hexdigest()!=visible['sha256']:raise ValueError('意向统计正在核验')
   records=[json.loads(line) for line in content.decode('utf-8-sig').splitlines() if line.strip()]
   if any(row.get('commercial_fit',{}).get('lead_intent') not in ('medium','high','super_high') for row in records):raise ValueError('意向统计正在核验')
   leads=len(records)
  else:raise ValueError('意向统计正在更新')
  if a.get('verification_required_now') and not live:state='等待你在浏览器完成验证码'
  scanned, _comment_pages=_scan_comment_stats(stdout_path)
  run_start, start_key=_parse_run_start(a)
  if run_start is not None:
   now=datetime.now(run_start.tzinfo)
   hours=max((now-run_start).total_seconds()/3600.0, 1e-6)
   elapsed_min=max(int((now-run_start).total_seconds()//60), 0)
   rate_added=added/hours
   if scanned is None:
    scan_line=f'本轮扫描页数：{pages:,} 页｜扫描评论数：暂无数据｜已跑约 {elapsed_min} 分钟｜入账约 {rate_added:.0f} 条/小时'
   else:
    rate_scan=scanned/hours
    ratio=(100.0*added/scanned) if scanned else 0.0
    scan_line=(f'本轮扫描页数：{pages:,} 页｜扫描评论约 {scanned:,} 条｜已跑约 {elapsed_min} 分钟｜'
               f'扫描约 {rate_scan:.0f} 条/小时｜入账约 {rate_added:.0f} 条/小时｜入账率约 {ratio:.1f}%')
  else:
   if scanned is None:
    scan_line=f'本轮扫描页数：{pages:,} 页｜扫描评论数：暂无数据｜运行时长：缺'
   else:
    scan_line=f'本轮扫描页数：{pages:,} 页｜扫描评论约 {scanned:,} 条｜运行时长：缺'
  label.set(
   f'账号：{nickname} ｜ {state}\n'
   f'本轮新采评论（未筛）：{added:,} 条\n'
   f'已确认中高意向（当前有效池）：{leads:,} 条\n'
   f'可回复：{candidates:,} 条\n'
   f'{scan_line}'
  )
  if box.get('1.0','end-1c')!=text:box.delete('1.0','end');box.insert('end',text);box.see('end')
 except Exception as e:label.set('正在读取本地进度：'+str(e))
 w.after(5000,poll)
poll();w.lift();w.attributes('-topmost',True);w.after(1200,lambda:w.attributes('-topmost',False));w.mainloop()
