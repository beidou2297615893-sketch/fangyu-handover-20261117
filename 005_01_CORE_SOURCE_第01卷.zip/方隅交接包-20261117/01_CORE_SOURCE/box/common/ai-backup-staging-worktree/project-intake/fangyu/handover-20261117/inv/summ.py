import sys,os,re,collections,json
src=r'C:\Users\rmsama\AppData\Local\Temp\fy_inv\files.tsv'
out=r'C:\Users\rmsama\AppData\Local\Temp\fy_inv\summary.json'
roots=[l.strip() for l in open(r'C:\Users\rmsama\AppData\Local\Temp\fy_inv\roots.txt',encoding='utf-8') if l.strip()]
roots.sort(key=len,reverse=True)
REB=[('node_modules',r'\\node_modules\\'),('python_env',r'\\(\.venv|venv|site-packages|desktop-python|python-runtime|python_embed|runtime\\python)\\'),('pycache',r'\\__pycache__\\|\.pyc$'),('gradle_build',r'\\(\.gradle|gradle-home|build\\intermediates|build\\outputs|build\\tmp|\.cxx)\\'),('pyinstaller_internal',r'\\_internal\\'),('cache',r'\\(\.cache|Cache|Code Cache|GPUCache|ShaderCache|\.pytest_cache|\.mypy_cache)\\'),('browser_profile',r'\\(User Data|chrome[_-]?profile[^\\]*|playwright[^\\]*profile[^\\]*|EBWebView|edge-profile[^\\]*|browser-profile[^\\]*|profile-[^\\]*)\\')]
REB=[(n,re.compile(p,re.I)) for n,p in REB]
SENS=re.compile(r'(cookie|token|secret|credential|password|passwd|\.env$|\.env\.|\.pem$|\.key$|\.pfx$|\.p12$|\.jks$|keystore|storage[_-]?state|login[ _-]?data|local state|auth[^\\]*\.json$|session[^\\]*\.json$|apikey|api[_-]key|\.sqlite-wal$|signing)',re.I)
DB=re.compile(r'(\.sqlite3?$|\.db$|\.duckdb$|ledger|账本|receipt|\.jsonl$)',re.I)
MAN=re.compile(r'\\(package\.json|requirements[^\\]*\.txt|pyproject\.toml|setup\.py|Pipfile|build\.gradle(\.kts)?|settings\.gradle(\.kts)?|project\.config\.json|cloudbaserc\.json|[^\\]*\.spec|AGENTS(\.local)?\.md|README[^\\]*\.md|.gitignore)$',re.I)
agg=collections.defaultdict(lambda:[0,0,''])
reb=collections.defaultdict(lambda:[0,0]); rebdir=collections.defaultdict(lambda:[0,0])
big=[];sens=[];dbs=[];mans=[];gits=collections.defaultdict(lambda:[0,0]);exts=collections.defaultdict(lambda:[0,0])
tot=collections.defaultdict(lambda:[0,0])
n=0
with open(src,encoding='utf-8',errors='replace') as f:
  for line in f:
    p=line.rstrip('\n').split('\t')
    if len(p)<3: continue
    path,sz,mt=p[0],int(p[1] or 0),p[2]; n+=1
    root=next((r for r in roots if path.startswith(r+'\\')),'?')
    t=tot[root]; t[0]+=1; t[1]+=sz
    rel=path[len(root)+1:].split('\\')
    for d in range(1,min(len(rel),5)):
      k=root+'\\'+'\\'.join(rel[:d]); a=agg[k]; a[0]+=1;a[1]+=sz
      if mt>a[2]: a[2]=mt
    i=path.lower().find('\\.git\\')
    if i>=0:
      g=gits[path[:i]]; g[0]+=1; g[1]+=sz; continue
    cat=None
    for nme,rx in REB:
      m=rx.search(path)
      if m:
        cat=nme; r=reb[(root,nme)]; r[0]+=1;r[1]+=sz
        rd=rebdir[(nme,path[:m.end()])]; rd[0]+=1; rd[1]+=sz
        break
    ext=os.path.splitext(path)[1].lower()
    e=exts[(ext,cat is None)]; e[0]+=1; e[1]+=sz
    if sz>=30*1024*1024: big.append((sz,mt,path,cat))
    base=path.rsplit('\\',1)[-1]
    if cat in (None,'browser_profile') and SENS.search(base if cat else path[len(root):]):
      if cat!='browser_profile': sens.append((sz,mt,path))
    if cat is None and DB.search(base): dbs.append((sz,mt,path))
    if cat is None and MAN.search(path): mans.append((sz,mt,path))
res=dict(n=n,tot={k:v for k,v in tot.items()},agg={k:v for k,v in agg.items() if v[1]>=1024*1024 or k.count('\\')<=6},
 reb={'|'.join(k):v for k,v in reb.items()},rebdir=sorted([[k[0],k[1],v[0],v[1]] for k,v in rebdir.items()],key=lambda x:-x[3])[:400],
 big=sorted(big,reverse=True)[:300],sens=sens[:3000],nsens=len(sens),dbs=sorted(dbs,reverse=True)[:3000],ndbs=len(dbs),mans=mans[:4000],nmans=len(mans),
 gits={k:v for k,v in gits.items()},exts=sorted([[k[0],k[1],v[0],v[1]] for k,v in exts.items()],key=lambda x:-x[3])[:80])
json.dump(res,open(out,'w',encoding='utf-8'),ensure_ascii=False)
print('ok',n)
