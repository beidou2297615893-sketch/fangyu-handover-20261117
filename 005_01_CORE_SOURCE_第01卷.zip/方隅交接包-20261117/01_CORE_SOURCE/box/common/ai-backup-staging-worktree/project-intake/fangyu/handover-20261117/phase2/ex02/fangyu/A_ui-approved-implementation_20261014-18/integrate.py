from pathlib import Path
import shutil

project=Path('C:/积木软件工坊/项目/方隅公寓客户版')
stage=project/'work/ui-runtime-r56'
web=stage/'src/web/workspace'
source=web/'self-operating-read.mjs'
s=source.read_text(encoding='utf-8')
if 'let approvedUI=null;' not in s:
 s=s.replace("const $=id=>document.getElementById(id);", "let approvedUI=null;\nconst $=id=>document.getElementById(id);",1)
 line=next(x for x in s.splitlines() if x.startswith(" $('upgrade-page-subtitle').textContent=") and '采集任务' not in x)
 s=s.replace(line,line+"\n if(approvedUI)approvedUI.sync(page);",1)
 s=s.replace("\nsetup();\ntry{const value=await api('me');", "\nsetup();\nconst {installApprovedUI}=await import(new URL('?asset=approved-ui.mjs',import.meta.url));\napprovedUI=installApprovedUI({state,show});\ntry{const value=await api('me');",1)
 source.write_text(s,encoding='utf-8',newline='\n')
html=web/'index.html'
s=html.read_text(encoding='utf-8')
styles=['approved-shell.css','approved-collection.css','approved-customers.css','approved-management.css']
if '?asset=approved-shell.css' not in s:
 s=s.replace('</head>',''.join(f'<link rel="stylesheet" href="?asset={name}">' for name in styles)+'</head>',1)
 html.write_text(s,encoding='utf-8',newline='\n')
icons=['search','message-circle','users','user-round','settings']
upstream=Path('C:/积木软件工坊/设计方法库/开源UI资源库/sources/lucide/6bc1373b3f30')
for icon in icons:
 shutil.copy2(upstream/'icons'/f'{icon}.svg',web/'assets'/f'approved-icon-{icon}.svg')
shutil.copy2(upstream/'LICENSE',stage/'src/resources/approved-ui-lucide-LICENSE.txt')
assets=stage/'src/assistant/employee_workspace.py'
s=assets.read_text(encoding='utf-8')
items={name:(name,'text/css; charset=utf-8') for name in styles}
items.update({name:(name,'text/javascript; charset=utf-8') for name in ['approved-ui.mjs','approved-collection.mjs','approved-customers.mjs']})
items.update({f'approved-icon-{n}.svg':(f'assets/approved-icon-{n}.svg','image/svg+xml') for n in icons})
if "'approved-ui.mjs':" not in s:
 s=s.replace('ASSETS = {','ASSETS = {\n'+''.join(f'    {k!r}: {v!r},\n' for k,v in items.items()),1)
 assets.write_text(s,encoding='utf-8',newline='\n')
ui=web/'approved-ui.mjs'
s=ui.read_text(encoding='utf-8').replace("replies.id='approved-replies-nav'","replies.id='approved-nav-replies'")
ui.write_text(s,encoding='utf-8',newline='\n')
print('Integrated r56 UI: preserved backend; asset routes and references registered.')
