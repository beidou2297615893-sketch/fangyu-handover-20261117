"""Read-only summary for the local progress panel."""
from collections import Counter
from contextlib import closing
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import time

ROOT = Path(__file__).resolve().parents[2]
TEXT = ROOT / 'work/fangyu-text-business-20261029'
LABELS = ('近7天', '8–15天', '16–30天')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def band(timestamp, now):
    if not timestamp or timestamp > now + 3600:
        return 6
    days = max(0, (now - timestamp) / 86400)
    return next((i for i, limit in enumerate((7, 15, 30, 60, 90)) if days <= limit), 5)


def receipt_counts(snapshot, sent, blocked_comments, blocked_customers):
    dates = snapshot['dates']
    collected = Counter(dates.values())
    replied = Counter(dates[cid] for cid in sent if cid in dates)
    pending = Counter(index for cid, (uid, index) in snapshot['candidates'].items()
                      if cid not in sent and cid not in blocked_comments and uid not in blocked_customers)
    return {'total': len(dates),
            'sent': sum(replied.values()), 'unmatched': len(sent - dates.keys()),
            'remaining': sum(pending.values())}


class Summary:
    def __init__(self):
        self.classification_sha = None
        self.classification_counts = Counter()
        self.classification_total = 0
        self.snapshot = None

    def refresh(self):
        now = time.time()
        database = ROOT / 'work/fangyu-douyin-independent/runtime/collection.sqlite3'
        with closing(sqlite3.connect(database.as_uri() + '?mode=ro', uri=True, timeout=2)) as db:
            comments = db.execute(
                "SELECT source_id, MAX(json_extract(data, '$.create_time')) "
                "FROM entities WHERE kind='comments' GROUP BY source_id").fetchall()
        collected = Counter()
        dates = {}
        for cid, value in comments:
            try:
                timestamp = float(value)
                timestamp = timestamp / 1000 if timestamp > 100000000000 else timestamp
            except (TypeError, ValueError):
                timestamp = None
            index = band(timestamp, now)
            if index < len(LABELS):
                collected[index] += 1
                dates[str(cid)] = index

        handoff = read(ROOT / 'work/fangyu-douyin-independent/classification-handoff-status.json')
        fit = handoff['commercial_fit']
        if True:  # The 30-day window advances even when the snapshot is unchanged.
            digest = hashlib.sha256()
            intents = Counter()
            seen = set()
            eligible = set()
            with Path(fit['all_pool_file']).open('rb') as stream:
                for line in stream:
                    digest.update(line)
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    cid = row.get('comment_id')
                    if not cid or cid in seen or str(cid) not in dates:
                        continue
                    seen.add(cid)
                    intent = (row.get('commercial_fit') or {}).get('lead_intent') or 'uncertain'
                    intents[intent] += 1
                    if intent in ('medium', 'high', 'super_high') and (row.get('commercial_fit') or {}).get('eligible_candidate') is True:
                        eligible.add(str(cid))
            if digest.hexdigest() == fit['all_pool_sha256']:
                self.classification_counts = intents
                self.classification_total = len(seen)
                self.classification_sha = fit['all_pool_sha256']
            else:
                raise RuntimeError('分类快照正在更新')

        dates = {cid: index for cid, index in dates.items() if cid in eligible}
        active = read(ROOT / 'work/douyin-local-control/active.json')
        task = Path(active['task'])
        manifest = read(task / 'approved-cli-queue.json')
        payload = json.dumps(manifest['items'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        if hashlib.sha256(payload).hexdigest() != manifest.get('items_sha256'):
            raise RuntimeError('发送清单正在更新')
        excluded = read(task / 'unavailable-targets.json') if (task / 'unavailable-targets.json').exists() else {}
        candidates = {}
        for row in manifest['items']:
            cid = str(row['cid'])
            if (cid in dates and cid not in excluded.get('comments', {})
                    and row.get('video') not in excluded.get('operator_skipped_videos', {})
                    and not (task / (cid + '.json')).exists()
                    and not (task / (cid + '.json.submitted')).exists()):
                candidates[cid] = (str(row.get('uid') or ''), dates[cid])
        self.snapshot = {'dates': dates, 'candidates': candidates}
        return '近30天，中、高、超高意向且符合业务筛选的评论。'

    def live(self):
        snapshot = self.snapshot
        if snapshot is None:
            return None
        ledger = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
        with closing(sqlite3.connect(ledger.as_uri() + '?mode=ro', uri=True, timeout=0.2)) as db:
            sent = {str(cid) for (cid,) in db.execute(
                "SELECT comment FROM reservations WHERE platform='douyin' AND status='sent' "
                "UNION SELECT comment FROM leads WHERE platform='douyin' AND status='sent'")}
            blocked = db.execute(
                "SELECT comment,customer FROM reservations WHERE platform='douyin' "
                "UNION SELECT comment,customer FROM leads WHERE platform='douyin' AND status IN ('sent','unknown','reserved')").fetchall()
        legacy = ROOT / 'Codex获客工作台/work/reply_receipts.sqlite3'
        with closing(sqlite3.connect(legacy.as_uri() + '?mode=ro', uri=True, timeout=0.2)) as db:
            sent.update(str(cid) for (cid,) in db.execute("SELECT cid FROM sends WHERE status='SENT_VERIFIED'"))
            blocked.extend(db.execute('SELECT cid,uid FROM sends').fetchall())
        return receipt_counts(snapshot, sent, {str(cid) for cid, _ in blocked},
                              {str(uid) for _, uid in blocked})
