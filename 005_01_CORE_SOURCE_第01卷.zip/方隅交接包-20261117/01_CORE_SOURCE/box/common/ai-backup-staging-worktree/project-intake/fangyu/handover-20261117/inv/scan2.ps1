﻿$ErrorActionPreference='SilentlyContinue'
$T='C:\Users\rmsama\AppData\Local\Temp\fy_inv'
$enc=New-Object Text.UTF8Encoding($false)
$L=New-Object System.Collections.Generic.List[string]
$L.Add('==CHATGPT TOP'); Get-ChildItem -Force 'C:\Users\rmsama\Documents\ChatGPT' | ForEach-Object { $L.Add($_.FullName+"`t"+$_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) }
foreach($p in @('C:\Users\rmsama\Documents\ChatGPT\自动获客系统','C:\Users\rmsama\Documents\ChatGPT\答题小程序','C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP','C:\Users\rmsama\Documents\ChatGPT\答题小程序\每日百题APP\work','C:\.codex\worktrees','C:\Users\rmsama\.codex\local-build-aliases\dailyhundred-20261023','C:\Users\rmsama\.config\.cloudbase\projects','C:\Users\rmsama\DailyHundredNativeBuild','C:\Users\rmsama\DailyHundredNativeBuild\work','C:\Users\rmsama\WeChatProjects')){
 $L.Add('==LS '+$p)
 Get-ChildItem -Force -LiteralPath $p | ForEach-Object { $rp=''; if($_.Attributes -band [IO.FileAttributes]::ReparsePoint){$rp='REPARSE->'+(($_ | Select-Object -ExpandProperty Target) -join ';')}; $L.Add($_.FullName+"`t"+$_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')+"`t"+$(if($_.PSIsContainer){'D'}else{$_.Length})+"`t"+$rp) }
}
[IO.File]::WriteAllLines("$T\ls2.txt",$L,$enc)
'DONE' | Out-File "$T\done2.txt"
