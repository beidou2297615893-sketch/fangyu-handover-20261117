"""Deterministic, evidence-bearing recheck of uncertain rental comments. No API IO."""
import hashlib
import re
import unicodedata
from pathlib import Path
import semantic_guard
import complete_local_demand

VERSION = 'douyin-local-backlog-recheck-v1.2-20261106'
CODE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def text_context(row):
    classification = row.get('classification') or {}
    meta = classification.get('original_metadata') or {}
    text = row.get('comment_text') or row.get('text') or classification.get('comment_text') or ''
    post = row.get('post_body') or meta.get('post_body') or '\n'.join(str(row.get(k) or '') for k in ('post_title', 'post_text'))
    parent = row.get('direct_parent_text') or meta.get('direct_parent_text') or ''
    return text, post, parent, meta


def evidence_hash(row):
    text, post, parent, meta = text_context(row)
    value = '\0'.join([text, post, parent, str(row.get('reply_to', meta.get('reply_to'))),
                       str(row.get('post_author_same_as_commenter', meta.get('post_author_same_as_commenter'))),
                       str(row.get('source_error')), str(row.get('source_version_conflict') or meta.get('source_version_conflict'))])
    return hashlib.sha256(value.encode()).hexdigest()


def decide(row):
    raw, post, parent, meta = text_context(row)
    text = unicodedata.normalize('NFKC', raw)
    text = re.sub(r'@[^\s@]+', ' ', text)
    text = re.sub(r'\[[^\]]{1,24}\]', '', text).strip()
    compact = re.sub(r'[\s，,。！？!?~～、:：;；]+', '', text).lower()
    context = bool(re.search(r'租房|房租|租金|公寓|房源|整租|合租|出租|转租|找房|求租|看房|一室|两室|一居|两居|套一|套二', post))
    nested = str(row.get('reply_to', meta.get('reply_to', '0')) or '0') != '0'

    def result(category, interest='uncertain', role='unknown', quote='', pools=None, context_used=False):
        return dict(version=VERSION, category=category, interest=interest, role=role,
                    evidence=quote, context_used=context_used,
                    pools=pools or [], input_evidence_sha256=evidence_hash(row), model_calls=0)

    if not raw.strip():
        return result('missing_original_text')
    if row.get('source_error') or row.get('source_version_conflict') or meta.get('source_version_conflict'):
        return result('source_conflict')
    if row.get('post_author_same_as_commenter') or meta.get('post_author_same_as_commenter'):
        return result('source_author_context')
    if not compact:
        return result('interaction_only', 'low', 'discussion', raw)
    question_particle = bool(re.search(r'(?:吗|嘛|么|吧)(?=$|[?？!！。.,，\s])|[?？]', text))
    if re.match(r'\s*\[群聊\]',raw):return result('housing_group_ad','low','supply',raw)
    own_current=bool(re.search(r'我(?:们|也|还|自己|和.{1,6})?(?:想租|要租|求租|在找房|想换房)|(?:^|[，,。])\s*求租',text))
    landlord=re.search(r'我是房(?:东|主)|我这(?:里|边)房源|我房源|我(?:的)?房子.{0,10}(?:空|直租|委托|出租)|我.{0,10}有房子出租|找我租|租我房子|租我的房子|想租.{0,18}(?:私信我|来找我|看看我)|房源.{0,6}(?:很多|多多)|帮我找租客',text)
    if landlord:
        if own_current:return result('mixed_supply_and_personal_need',quote=landlord.group())
        return result('supply','low','supply',landlord.group())
    advice=re.search(r'我觉得你|我建议|建议你|你可以|你找|你要几个人|想租.{0,18}的话.{0,12}(?:考虑|建议)|可以考虑|推荐你|考虑看看|(?:租客|房客|客户|他|她).{0,6}想租|我知道你想要',text)
    if advice and not own_current:return result('advice_or_third_party','low','discussion',advice.group())
    if re.search(r'房产证.{0,6}过户|过户给我',text):return result('purchase_not_rental','low','unrelated',text)

    state, state_reason = semantic_guard.state(text)
    if state == 'ended':
        return result('ended', 'low', 'demand', state_reason)
    if state != 'active_or_unknown':
        return result('chosen_or_historical_direction', quote=state_reason)

    supply = re.search(r'(?:^|[，,。；;])\s*(?:我(?:这(?:里|边)?)?有(?:空)?房|我(?:本人)?(?:是房东|出租|转租)|本人(?:出租|转租)|房东直租|.{0,10}这边有房出租)', text)
    if supply and not re.search(r'我(?:还)?(?:想租|要租|求租|在找房)|自己找房|重新找房', text):
        return result('supply', 'low', 'supply', supply.group())
    if re.search(r'(?:我|本人).{0,4}(?:招|找).{0,6}室友|(?:招|急招)室友', text) and not re.search(r'一起(?:租|找)|想合租|求合租', text):
        return result('supply_or_roommate_offer', 'low', 'supply', text)
    if re.search(r'想买(?:一套|这种|房)|要买房|买一套房|可以卖不|卖不卖', text) and not re.search(r'想租|求租|租房', text):
        return result('purchase_not_rental', 'low', 'unrelated', text)

    # A number / a topic mention alone is not a rental request.
    explicit = re.search(r'求租|求房|急租.{0,4}房|(?<![不别没])想租|我(?:也|还)?要租|(?<!找)我租[，,。！!？?\s]*$|我(?:也|还)?在找|(?:^|[，,。])(?:我(?:也|还)?|自己)?想(?:找|租|要)[^，,。；;]{0,8}(?:房|公寓|一居|两居|一室|两室)|(?:正在|还在|准备|打算)(?:找房|租房)|(?<!不)(?:想|准备)换房|重新找房|(?:帮|给)(?:我)?(?:父母|爸妈|妈妈|爸爸|家人).{0,8}(?:租|找).{0,4}房|想搬出去住|(?:现在|马上|今天).{0,2}(?:去定|去订|去看房)|有没有(?!可能|大佬|大老|人)[^，,。；;？?]{0,14}(?:房子|房源|一室|两室|单间)|(?:^|[，,。])找(?!到|了)[^，,。；;]{0,14}(?:附近的|单间|一居|一室|两室|房子)', text)
    if explicit and re.search(r'怎么才能|如何才能|有没有人|有人.{0,4}(?:想租|要租)|你(?:们)?(?:想租|要租)|问你|问问你|不想租', text):
        explicit = None
    if explicit and re.search(r'(?:去年|以前|之前|当年|曾经|那时候|年前).{0,12}'+re.escape(explicit.group()),text) and not re.search(r'现在|目前|这次|最近|还在|重新|想换',text):
        return result('experience_or_price_discussion','low','discussion',text)
    if explicit:
        if nested and not re.search(r'我|求租|求房|帮(?:父母|爸妈|家人)', text):
            return result('nested_reference_requires_parent', quote=text)
        classified = complete_local_demand.classifier.classify(dict(row, original_classification=row))
        return result('explicit_rental_demand', 'high', 'demand', explicit.group(),
                      classified['pools'] or ['房源状态'])

    # Current or past tenancy / a price reaction is evidence about an experience,
    # not a new request, even when it mentions features such as 可以 or 这么.
    if re.search(r'太贵|好贵|这么贵|好便宜|这么便宜|租不起|贵了|冤种|我(?:们)?(?:现在|目前)?(?:住|租)(?:的|了|在|着)|以前|去年|之前|房东.{0,8}(?:押金|跑路)|二房东.{0,8}(?:押金|跑路)', text) and not re.search(r'求租|想租|要租|找房|找个房|想换|重新找|有没有|有吗|怎么联系|求推荐', text):
        return result('experience_or_price_discussion', 'low', 'discussion', text)

    # Contact shorthand and direct feature/price/location inquiries require an
    # existing rental context. Bare topic keywords never upgrade a bystander.
    short_interest = bool(re.fullmatch(r'(?:我也?|我们)?(?:想要|要|想租|租|想住|要住|也想住)(?:一个|一套|这个|这套|这里|这儿)?(?:呀|啊|呢)?', compact))
    contact = re.search(r'怎么联系|如何联系|联系(?:方式|你|一下)|求(?:v|V|微信|链接|联系方式)|加我|私我|私信我|踢我|能了解(?:下|一下)吗|介绍一下|怎么租|咋租|如何租|求推荐|帮忙找房', text)
    contact = bool(contact or re.fullmatch(r'dd+|滴滴+|蹲+|踢踢|求链接', compact))
    price = re.search(r'多少钱|多少米|房租多少|租金多少|什么价格|什么价位|礼貌(?:问价|询价)|问价', text)
    price = bool(price or (re.search(r'多少|多钱|几米', compact) and not re.search(r'多少(?:人|平|米远|天|年|岁|面积)|离.{0,12}多少米|距离.{0,8}多少米', compact)))
    location = re.search(r'在哪里|在哪儿|在哪|哪里|这是哪|什么位置|哪个位置|[哪那]个区|哪个小区|那里|哪儿|看看位置|位置在[哪那]里|在[哪那]个位置|发我位置|给个位置|(?:什么|哪个)公寓|公寓.{0,4}(?:名字|叫什么)', text)
    location = bool(location and not re.search(r'在那里(?:住了|住过|上班)|在那(?:里)?(?:住了|住过)|找到了吗', text))
    feature_question = bool(question_particle or re.search(r'有没有|有没|能不能|可不可以|可以.{0,4}(?:养|租|住|做饭)|行不行|如何|咋|怎么|几楼|几人|多大|多少平|多久|押几|押一|月付|不要|不合租|独卫', text))
    feature = bool(re.search(r'猫|狗|宠物|电梯|楼层|几楼|水电|电费|水费|燃气|做饭|厨房|独卫|阳台|空调|隔音|停车|合租|整租|单间|一室|两室|一居|两居|套一|套二|面积|平米|平方|短租|长租|租期|入住|押金|中介费', text))
    available = bool(re.search(r'有(?:吗|嘛|么|没|没有|不$)|还在(?:吗|嘛)|还能租(?:吗|嘛)?', compact))
    classified = complete_local_demand.classifier.classify(dict(row, original_classification=row))
    literal_request = any(e.get('source')=='comment_literal' and e.get('subtag')=='明确求租或兴趣' for e in classified['evidence'])
    qualifications = bool(question_particle and re.search(r'能租|能住|可以租|卡年龄|卡学历|入住资格|非应届', text))
    own_budget = semantic_guard.business_fit.budget(text, context)
    supported_budget = bool(context and own_budget['monthly_maximum'] is not None and own_budget['monthly_maximum']<=50000
                            and any(e.get('explicit_budget') and e.get('usable') for e in own_budget['evidence'])
                            and not re.search(r'你(?:的|们的)?预算|他(?:的)?预算|她(?:的)?预算', text))
    housing_interest = bool(re.search(r'我(?:也)?想去.{0,12}(?:住|租房)|(?:^|[，,。])(?:成都|上海|杭州|北京|福州)?租个房子|我需要|我要(?:一个|一套)|我相中这个|这个房子适合我|理想中的家|打开租房软件|房子挺好|这房子.{0,6}(?:舒服|适合)|给个地址|(?:第.+套|基本).{0,6}家具.{0,8}(?:吗|嘛)|去地铁站多远',text))
    pool_question = bool(classified['pools'] and (question_particle or re.search(r'有没有|有没', text)))
    if context and (short_interest or contact or price or location or available or pool_question or literal_request or qualifications or supported_budget or housing_interest or (feature and feature_question)):
        if nested and not parent and not re.search(r'我|求租|求房', text):
            return result('nested_reference_requires_parent', quote=text)
        pools = classified['pools']
        if price and '价格预算' not in pools:pools.append('价格预算')
        if location and '位置通勤' not in pools:pools.append('位置通勤')
        if contact and '看房联系' not in pools:pools.append('看房联系')
        if available or short_interest:
            if '房源状态' not in pools:pools.append('房源状态')
        if literal_request and '房源状态' not in pools:pools.append('房源状态')
        if qualifications and '户型面积与居住方式' not in pools:pools.append('户型面积与居住方式')
        if supported_budget and '价格预算' not in pools:pools.append('价格预算')
        if housing_interest and not pools:pools.append('房源状态')
        return result('contextual_rental_inquiry', 'high' if short_interest or literal_request or supported_budget else 'medium', 'demand', text, pools, True)

    if re.fullmatch(r'\d+(?:\.\d+)?(?:k|千|元|块|米|w|万)?', compact):
        return result('number_scope_requires_context', quote=text)
    if re.fullmatch(r'真的?(?:吗|嘛)|真的假的|真实吗|真的吗|真的|真的假的啊|有|有的|可以|我|\?|？', compact):
        return result('short_reference_requires_context', quote=text)
    if re.search(r'太贵|好贵|这么贵|好便宜|真的假的|租不起|贵了|冤种|我(?:们)?(?:住|租)(?:的|了|在|着)|以前|去年|之前|房东.{0,8}(?:押金|跑路)|二房东.{0,8}(?:押金|跑路)', text):
        return result('experience_or_price_discussion', 'low', 'discussion', text)
    if re.fullmatch(r'不错|好(?:看|棒|漂亮|舒服)|真好|太棒了|谢谢(?:分享|博主)?|赞+|[\W_]+', compact):
        return result('interaction_only', 'low', 'discussion', text)
    if '@' in raw and not re.search(r'我|我们|想|要|租|住|问|多少|哪里|哪儿', text):
        return result('mention_interaction_only', 'low', 'discussion', text)
    return result('insufficient_current_rental_evidence', quote=text)


def apply_decision(row, decision):
    """Overlay a supported decision, preserving original fields and text evidence."""
    result = dict(row, local_recheck=decision, local_recheck_completed=True,
                  semantic_review_stage='local_backlog_recheck')
    if decision['role'] == 'unknown':
        if decision.get('recheck_legacy_missing_reply'):
            result['prior_local_recheck']={key:row.get(key) for key in ('role','interest_at_comment','pools','semantic_review_stage')}
            result.update(role='unknown',interest_at_comment='uncertain')
        return result
    result['prior_local_recheck'] = {key: row.get(key) for key in
                                    ('role', 'interest_at_comment', 'pools', 'semantic_review_stage')}
    result.update(role=decision['role'], interest_at_comment=decision['interest'],
                  pools=decision['pools'], semantic_review_stage='local_backlog_recheck')
    if decision['category'] == 'ended':result['demand_state']='ended'
    # A past semantic grade is preserved above; it must not veto newly evidenced
    # literal demand simply because the old field was called uncertain.
    return result
