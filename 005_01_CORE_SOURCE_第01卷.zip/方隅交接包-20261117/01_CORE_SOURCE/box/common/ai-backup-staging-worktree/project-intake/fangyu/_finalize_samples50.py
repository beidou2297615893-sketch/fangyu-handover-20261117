# -*- coding: utf-8 -*-
"""Re-pack the selected 40 kept + a cleaner 10 excluded, with honest everyday-Chinese reasons."""
import json, re, sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path

SH = timezone(timedelta(hours=8))
R = Path(r"C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work")
FB = R / "fangyu-text-business-20261029"
QPATH = FB / "recency-priority" / "daily-priority" / "douyin-3e9aef4d3fa025fe.jsonl"
POOL = FB / "douyin-semantic-repair-v5" / "all-pool-business-fit.jsonl"
LEDGER = R / "shared-acquisition-ledger" / "shared.sqlite3"
PREV = Path(r"C:\Users\rmsama\agent-tools\class-reply-samples-50-20261112.json")
OUT = Path(r"C:\Users\rmsama\agent-tools\class-reply-samples-50-20261112.json")

# Import helpers by exec of extractor? Duplicate the needed fns to stay self-contained.
# Load extractor functions from the earlier script.
import importlib.util
spec = importlib.util.spec_from_file_location("ex", r"C:\Users\rmsama\agent-tools\_build_samples50_extract.py")
ex = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ex)

EXCL_WANTED = [
    # (comment_id if known later, or match text start, preferred reason code)
]


def ev_quotes(budget):
    out = []
    for e in (budget or {}).get("evidence") or []:
        if isinstance(e, dict):
            q = (e.get("quote") or "").strip()
            if q:
                out.append(q)
        else:
            s = str(e).strip()
            if s:
                out.append(s)
    return out


def budget_reason(cf, comment_text):
    b = (cf or {}).get("budget") or {}
    state = b.get("state") or ""
    quotes = ev_quotes(b)
    text = comment_text or ""
    bits = []
    if state == "budget_at_least_4000":
        if quotes:
            bits.append("系统把预算记成了至少四千，依据摘的是「" + "、".join(quotes) + "」。")
        else:
            bits.append("系统把预算记成了至少四千，但没有记下摘自哪几个字。")
        # honest clues when the quote looks mismatched
        if any(q == "万" for q in quotes) and "万达" in text:
            bits.append("评论里出现了地名「万达」，需要你看是不是把「万」字误当成了金额。")
        if "月薪" in text or "工资" in text:
            bits.append("评论里说的是月薪，不一定是房租预算。")
        if re.search(r"(预算|房租).{0,8}(1[0-9]{3}|[1-9][0-9]{2,3})", text) and any("万" == q or (b.get("monthly_minimum") or 0) >= 4000 for q in quotes for b in [b]):
            m = re.search(r"(预算|房租)[^。！？]{0,20}", text)
            if m and ("1300" in text or "3000" in text or "2k" in text.lower()):
                bits.append("评论里同时还写了自己的房租数字，请对照一下系统有没有摘错。")
    elif state in ("budget_3000_3999_unverified", "budget_3000_3999_requires_confirmation"):
        q = "、".join(quotes) if quotes else "未记录摘录"
        bits.append("评论里的预算在三千到四千之间（摘录：「" + q + "」），还待确认。")
    elif state in ("below_3000", "whole_home_monthly_budget_below_3000"):
        q = "、".join(quotes) if quotes else "未记录摘录"
        bits.append("评论里写的整租预算低于三千（摘录：「" + q + "」）。")
    elif state == "budget_unverified":
        if quotes:
            bits.append("评论里出现过金额「" + "、".join(quotes) + "」，系统记成预算尚未核实。")
        else:
            bits.append("评论里没有写出明确的月租预算。")
    elif state:
        bits.append("预算状态未用日常说法记录，原始记录是：" + state + "。")
    else:
        bits.append("预算情况未记录。")
    return "".join(bits)


def reason_kept(row, cf, lit, place_hits):
    parts = []
    loc = row.get("local_recheck") or {}
    ev = loc.get("evidence")
    if isinstance(ev, list):
        ev = "，".join(str(x) for x in ev[:3] if x)
    ev = (str(ev).strip() if ev else "")
    text = ex.text_of(row)
    if ev:
        ev = ev.rstrip("。；;，,")
        parts.append("分类依据主要来自评论里的这些话：「" + ev[:100] + ("…" if len(ev) > 100 else "") + "」。")
    elif text:
        parts.append("是根据这条评论本身的意思来分的。")
    else:
        parts.append("评论原文未记录。")
    cat = loc.get("category") or ""
    if cat and ex.CAT_CN.get(cat):
        parts.append("本地分类看成「" + ex.CAT_CN[cat] + "」。")
    intent = ex.intent_cn(cf, row)
    if intent and intent != "未记录":
        parts.append("意向评为" + intent + "。")
    parts.append(budget_reason(cf, text))
    vr = (cf or {}).get("video_listed_rent") or {}
    if vr.get("state") == "below_floor" and vr.get("quote"):
        parts.append("视频里写了「" + str(vr.get("quote")) + "」，低于三千门槛；但这条评论被系统认定自己报了够得上的预算，所以仍留在可发池。")
    elif vr.get("quote"):
        parts.append("视频里出现过标价「" + str(vr.get("quote")) + "」。")
    if (cf or {}).get("eligible_candidate"):
        parts.append("商务筛选判定可以进入可发名单。")
    return "".join(parts)


# patch pack_kept to use new reason
def pack_kept(row):
    d = ex.pack_kept(row)
    cf = row.get("commercial_fit") or {}
    reply = row.get("reply") or {}
    lit = ex.literals(reply)
    places = ex.place_in_reply(reply.get("draft_text") or "", lit["location"])
    d["这样分的原因"] = reason_kept(row, cf, lit, places)
    # keep other fields
    d["budget_evidence"] = ev_quotes(cf.get("budget") or {})
    d["budget_state"] = ((cf.get("budget") or {}).get("state") or "")
    return d


CODE_CN = {
    "low_price_video_budget_mismatch": "低价视频，预算对不上",
    "listing_ad_or_agent": "房源广告或中介推销",
    "advice_not_self_demand": "不是本人在找房（劝告、科普、反问或在谈房东经验）",
    "own_home_seeking_roommate": "自己有房，在找室友或把房子分租出去",
    "seeking_buddy_or_dating": "交友或找搭子，不是找房",
    "whole_home_monthly_budget_below_3000": "评论里写的整租预算低于三千",
    "demand_ended": "已经不找了",
    "not_supported_customer_demand": "不像是在给自己找房",
    "solicit_people_looking": "在问有没有人要找房，像是在出租",
    "source_post_advertised_rent_below_3000": "视频里标价低于三千",
    "contact_or_brand_restricted": "涉及联系方式或品牌限制，不能按普通找房来回",
}


def labs_from(cf, row):
    labels = list(cf.get("exclusion_reason_labels") or row.get("exclusion_reason_labels") or [])
    reasons = list(cf.get("exclusion_reasons") or row.get("exclusion_reasons") or [])
    pretty = []
    seen = set()
    # prefer Chinese labels when present
    label_map = {
        "低价视频-预算不符": "low_price_video_budget_mismatch",
        "房源广告/中介": "listing_ad_or_agent",
        "非本人找房需求（劝告/科普/反问他人/房东经验）": "advice_not_self_demand",
        "交友/找搭子非租房": "seeking_buddy_or_dating",
        "供给方：自有房找室友/分租出去": "own_home_seeking_roommate",
        "供给方：询问是否有人找房": "solicit_people_looking",
    }
    for lab in labels:
        cn = ex.EXCL_CN.get(lab, lab)
        if cn not in seen:
            pretty.append(cn)
            seen.add(cn)
    for code in reasons:
        cn = CODE_CN.get(code, ex.EXCL_CN.get(code, code))
        if cn not in seen:
            pretty.append(cn)
            seen.add(cn)
    return pretty, reasons, labels


def pack_excl(row, pretty, reasons):
    cf = row.get("commercial_fit") or {}
    pub = ex.shanghai(row.get("published_at") or row.get("published_at_unix"))
    # reason text
    parts = []
    if pretty:
        parts.append("排除原因：" + "；".join(pretty) + "。")
    vr = (cf or {}).get("video_listed_rent") or {}
    if vr.get("quote"):
        parts.append("视频里相关的标价是「" + str(vr.get("quote")) + "」。")
    b = (cf or {}).get("budget") or {}
    quotes = ev_quotes(b)
    if "whole_home_monthly_budget_below_3000" in reasons or (b.get("state") in ("below_3000",)):
        if quotes:
            parts.append("评论里的预算摘录是「" + "、".join(quotes) + "」，低于三千。")
        else:
            parts.append("评论里的整租预算低于三千。")
    loc = row.get("local_recheck") or {}
    cat = loc.get("category") or ""
    if cat and ex.CAT_CN.get(cat):
        parts.append("本地分类看成「" + ex.CAT_CN[cat] + "」。")
    ev = loc.get("evidence")
    if isinstance(ev, list):
        ev = "，".join(str(x) for x in ev[:3] if x)
    if ev:
        parts.append("依据：「" + str(ev)[:80] + ("…" if len(str(ev)) > 80 else "") + "」。")
    why = (row.get("reason") or "").strip()
    if why and why not in "".join(parts):
        parts.append(why if why.endswith("。") else why + "。")
    if not parts:
        parts.append("被筛掉，但具体原因未记录。")
    title = "排除：" + ("；".join(pretty) if pretty else (ex.CAT_CN.get(cat) or "未进入可发名单"))
    return {
        "kind": "excluded",
        "comment_id": str(row.get("comment_id") or ""),
        "customer_uid": str(row.get("customer_uid") or ""),
        "video_id": str(row.get("video_id") or ""),
        "comment_text": ex.text_of(row),
        "video_snip": ex.video_snip(row, cf),
        "分类": title,
        "这样分的原因": "".join(parts),
        "生成的回复": "不自动回",
        "回复是怎么来的": "因为被排除，不会自动生成回复。",
        "intent": ex.intent_cn(cf, row),
        "category": cat or "未记录",
        "labs": pretty,
        "reasons": reasons,
        "ip": row.get("ip_location_raw") or "未记录",
        "published_at": pub.strftime("%Y-%m-%d %H:%M") + " Asia/Shanghai" if pub else "未记录",
        "published_unix": row.get("published_at_unix") or 0,
        "has_budget": False,
        "has_place": False,
    }


def main():
    prev = json.loads(PREV.read_text(encoding="utf-8"))
    keep_ids = [x["comment_id"] for x in prev["kept"]]
    # reload kept from live queue
    wanted = set(keep_ids)
    found = {}
    with QPATH.open(encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            cid = str(row.get("comment_id") or "")
            if cid in wanted:
                found[cid] = pack_kept(row)
    kept = []
    for cid in keep_ids:
        if cid not in found:
            raise SystemExit("missing kept " + cid)
        kept.append(found[cid])

    # pick excluded by preferred codes / texts, recent, unique
    # scan pool into buckets
    buckets = {k: [] for k in [
        "low_price_video_budget_mismatch",
        "listing_ad_or_agent",
        "advice_not_self_demand",
        "own_home_seeking_roommate",
        "seeking_buddy_or_dating",
        "whole_home_monthly_budget_below_3000",
        "demand_ended",
        "not_supported_customer_demand",
        "solicit_people_looking",
        "WEAK",
    ]}
    blocked_cids, blocked_canons, canon = ex.load_blocked()
    with POOL.open(encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            cf = row.get("commercial_fit") or {}
            elig = cf.get("eligible_candidate") if "eligible_candidate" in cf else row.get("eligible_candidate")
            if elig:
                continue
            if ex.is_blocked(row.get("comment_id"), row.get("customer_uid"), blocked_cids, blocked_canons, canon):
                continue
            text = ex.text_of(row)
            if not text:
                continue
            pretty, reasons, labels = labs_from(cf, row)
            pub = ex.shanghai(row.get("published_at") or row.get("published_at_unix"))
            d = ex.days_ago(pub)
            if d is None or d > 30:
                continue
            item = (d, row, pretty, reasons)
            # bucket
            if not reasons and not labels:
                cat = ((row.get("local_recheck") or {}) or {}).get("category") or ""
                if cat in ("interaction_only", "mention_interaction_only", "short_reference_requires_context"):
                    if not any(w in text for w in ["出租", "转租", "出一", "有房", "两居", "主卧", "找室友", "中介", "可租", "房源"]):
                        if 2 <= len(text) <= 20:
                            buckets["WEAK"].append(item)
                continue
            # prefer pure membership
            for code in [
                "low_price_video_budget_mismatch",
                "listing_ad_or_agent",
                "advice_not_self_demand",
                "own_home_seeking_roommate",
                "seeking_buddy_or_dating",
                "whole_home_monthly_budget_below_3000",
                "demand_ended",
                "not_supported_customer_demand",
                "solicit_people_looking",
            ]:
                if code in reasons:
                    buckets[code].append(item)

    def pick_from(code, prefer_pure=True, avoid_sub=None, prefer_text=None):
        arr = sorted(buckets[code], key=lambda x: x[0])
        if prefer_text:
            for d, row, pretty, reasons in arr:
                if prefer_text in (row.get("comment_text") or ""):
                    return row, pretty, reasons
        scored = []
        for d, row, pretty, reasons in arr:
            text = (row.get("comment_text") or "")
            if avoid_sub and any(s in text for s in avoid_sub):
                continue
            score = d
            if prefer_pure:
                # fewer extra reasons better
                extra = len([r for r in reasons if r != code])
                score = extra * 100 + d
            # prefer some substance
            if len(text) < 4:
                score += 20
            scored.append((score, row, pretty, reasons))
        scored.sort(key=lambda x: x[0])
        if not scored:
            return None
        return scored[0][1], scored[0][2], scored[0][3]

    picks = []
    plan = [
        ("low_price_video_budget_mismatch", dict()),
        ("listing_ad_or_agent", dict()),
        ("advice_not_self_demand", dict()),
        ("own_home_seeking_roommate", dict()),
        ("seeking_buddy_or_dating", dict()),
        ("whole_home_monthly_budget_below_3000", dict(prefer_pure=True, avoid_sub=["转租", "出租", "出一"])),
        ("demand_ended", dict(prefer_pure=True, avoid_sub=["转租", "出租"], prefer_text="我租好了房子")),
        ("not_supported_customer_demand", dict(prefer_pure=True, avoid_sub=["转租", "出租", "房东直租"], prefer_text="相比我之前北漂")),
        ("solicit_people_looking", dict()),
        ("WEAK", dict()),
    ]
    used = set()
    for code, kw in plan:
        got = pick_from(code, **kw) if buckets[code] else None
        if not got:
            print("MISSING", code, "n", len(buckets[code]))
            continue
        row, pretty, reasons = got
        cid = str(row.get("comment_id") or "")
        if cid in used:
            # try next
            for item in sorted(buckets[code], key=lambda x: x[0]):
                c2 = str(item[1].get("comment_id") or "")
                if c2 not in used:
                    row, pretty, reasons = item[1], item[2], item[3]
                    cid = c2
                    break
        used.add(cid)
        packed = pack_excl(row, pretty, reasons)
        picks.append(packed)
        print("EXCL", packed["分类"], "|", packed["comment_text"][:40].replace("\n"," "), "|", packed["published_at"])

    out = {
        "kept": kept,
        "excluded": picks,
        "queue": str(QPATH),
        "generated_at": "2026-11-12 18:40 Asia/Shanghai",
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("kept", len(kept), "excl", len(picks), "wrote", OUT)


if __name__ == "__main__":
    main()
