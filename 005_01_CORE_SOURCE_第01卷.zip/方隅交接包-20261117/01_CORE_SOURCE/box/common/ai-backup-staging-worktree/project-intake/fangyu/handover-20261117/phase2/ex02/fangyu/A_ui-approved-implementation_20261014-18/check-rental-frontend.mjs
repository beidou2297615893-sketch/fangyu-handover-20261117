import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import * as presets from './ui-preview/pages/presets.mjs';
import * as customers from './ui-preview/pages/customers.mjs';
import {customerControls} from './ui-preview/pages/customers-data.mjs';
const catalog=JSON.parse(readFileSync(new URL('../关键词规则整合/frontend-material-fixture.json',import.meta.url),'utf8'));
const material=catalog.materials.find(item=>item.key==='sh_gubei');
const checks=[];
const check=(name,fn)=>{fn();checks.push(name);};
const state={connection:'connected',user:'fixture-employee',storeId:'fixture-store',store:'授权门店',
  stores:[{id:'fixture-store',name:'授权门店'}],capabilities:{presets:true,materials:true},
  catalog:{search:[{id:'precise',name:'精准获客'},{id:'commute',name:'通勤拓展'}],intent:[{id:'standard',name:'历史规则'},{id:'rental-evidence',name:'租房与预算',assessmentEnabled:true}]},
  materials:{materials:catalog.materials},presets:{tab:'presets',search:'precise',intent:'standard',materialKey:'',keywordIds:[],showWords:false,showRules:false},selection:{applied:null}};
check('unbound employee explicitly selects source material; no source is guessed',()=>{
  const html=presets.render(state);assert.match(html,/请选择与当前授权门店对应的资料/);
  assert.match(html,/杭州余杭/);assert.match(html,/待补资料/);assert.equal(state.presets.materialKey,'');
});
class Element{constructor(){this.listeners={};this.value='';}addEventListener(type,fn){this.listeners[type]=fn;}fire(type){this.listeners[type]?.({target:this});}}
const select=new Element(),actions=[];
presets.bind({querySelectorAll:()=>[],querySelector:selector=>selector==='[data-material-select]'?select:null},
  {state,update:fn=>fn(state),actions:{applyPreset:()=>actions.push('apply'),refreshAssessments:()=>actions.push('grade')}});
check('material selection previews eligible terms and selects rental rules without starting work',()=>{
  select.value=material.key;select.fire('change');assert.equal(state.presets.intent,'rental-evidence');
  assert.equal(state.presets.search,'precise');assert.deepEqual(state.presets.keywordIds,material.keywordIds.slice(0,100));assert.deepEqual(actions,[]);
  state.presets.showRules=true;
  const html=presets.render(state);assert.ok(html.includes('确认对应门店并应用'));assert.ok(html.includes('预算'));
  for(const word of material.keywords.filter(word=>!word.eligible))assert.match(html,new RegExp('data-material-keyword="'+word.id+'"[^>]*disabled'));
});
check('empty material keyword selection cannot be applied',()=>{
  state.presets.keywordIds=[];assert.match(presets.render(state),/data-preset-apply[^>]*disabled/);
});
check('current unknown, budget scope and self-reported income share the shown source',()=>{
  const p={id:'fixture-author',name:'验证客户',level:'待确认',tone:'muted',intentSource:'rental-assessment',
    intentRuleVersion:catalog.ruleVersion,reviewRequired:true,quote:'只是先了解',postTitle:'原始来源',
    budgetSummary:'4000；单位待确认',incomeSummary:'本人自报税后月收入15000元；未验证',evidence:['本人当前只了解'],
    legacyIntent:{label:'高意向'}};
  state.customerView={actor:{username:state.user,storeId:state.storeId},status:'ready',items:[p],stats:{total:1,high:0},total:1};
  Object.assign(customerControls(state),{selectedId:p.id,evidenceOpen:true,filterOpen:true});
  state.customerDetail={actor:state.customerView.actor,id:p.id,status:'ready',item:p};
  const html=customers.render(state);assert.match(html,/待确认/);assert.match(html,/4000；单位待确认/);
  assert.match(html,/本人自报税后月收入15000元；未验证/);assert.match(html,/历史评级：高意向/);
  assert.match(html,/data-customer-filter-value="uncertain"/);assert.match(html,/data-customer-filter-value="low"/);
});
const report={status:'PASS',checks,scope:'Public UI DTOs and event handling only; no real platform, income or customer data.'};
writeFileSync(new URL('./frontend-rental-check.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
