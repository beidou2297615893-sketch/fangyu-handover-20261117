# Grok Bot 省用量证据备忘 2026-11-09
官方:
- https://cursor.com/help/grok-bot/routines : 每次运行耗用量；每小时/短间隔/繁忙Slack触发可一天用掉一周；不需要的先暂停；Test也耗；不运行不耗。
- https://docs.x.ai/grok-bot/skills-routines-and-automations : 同上+限流300/h总、200/h单例程。
- https://cursor.com/help/grok-bot/plans : 按agent步骤和tokens计,非消息数；大/长任务更耗；任务范围收紧。
团队成员/社区(非官方文档):
- https://thedailybot.vercel.app/changelog/tip-routine-frequency : Lauren Tan(Grok Bot团队)称长聊天历史使例程"much more expensive"，建议把定期例程移到新Bot；例程不短于1小时。
- https://liminalprompt.com/keep-grok-bot-usage-lean/ : 社区称群聊多Bot同时回应耗量大，建议@单个Bot。
- https://note.com/vast_viola153/n/n5d8ff29657f3 : 个人估算(假设性,勿引用倍数)：connector优于屏幕操作、历史轻、频率低；结果存文件、对话短；失败重试设上限。
未证实:新窗省量百分比、缓存机制、官方"总结迁移"按钮(未找到)。
