import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), 'acceptance-release', 'web');
const PORT = Number(process.env.PORT || 57877);
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.ico': 'image/x-icon',
};
const store = {id: 'fy_s_4b104739e834855f7c6e4fc3', name: '杭州余杭方隅公寓'};
const csrf = 'screenshot-csrf-token';
function send(res, status, body, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type': type, 'Cache-Control': 'no-store'});
  res.end(body);
}
function bootstrap() {
  return {
    ok: true,
    csrfToken: csrf,
    session: null,
    localMode: true,
    localProfile: {name: '本机'},
    appName: '方隅自动获客系统',
    dailyStoreSwitch: false,
    stores: [store],
    selection: {storeId: store.id, revision: 2},
    selectedStoreName: store.name,
    capabilities: {platforms: false},
    fixture: false
  };
}
function stats() {
  return {
    ok: true,
    csrfToken: csrf,
    status: 'missing',
    today_collected: null,
    today_replied: null,
    pool_effective: null,
    total: null,
    pool_delta: null,
    board: {mode: 'idle', title: '待开始', live: false, sub: '', action: '启动／继续', key: 'start'}
  };
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  if (url.pathname === '/api/workbench/bootstrap' && req.method === 'GET') {
    return send(res, 200, JSON.stringify(bootstrap()));
  }
  if (url.pathname === '/api/workbench' && req.method === 'POST') {
    let raw = '';
    req.on('data', c => { raw += c; if (raw.length > 1e6) req.destroy(); });
    req.on('end', () => {
      let body = {};
      try { body = JSON.parse(raw || '{}'); } catch { return send(res, 400, JSON.stringify({ok:false})); }
      const action = body.action;
      if (action === 'board_stats') return send(res, 200, JSON.stringify(stats()));
      if (action === 'board_action') return send(res, 200, JSON.stringify({ok:true, csrfToken:csrf, executed:false, message:'截图预览不会向本机控制通道发出启动或暂停。'}));
      if (action === 'employee_browser_open' || action === 'employee_browser_status') {
        return send(res, 200, JSON.stringify({ok:true, csrfToken:csrf, page_url:'https://www.douyin.com/jingxuan', message:'请在原来配合采集的抖音网页（https://www.douyin.com/jingxuan）里完成登录。软件不会打开创作者中心，也不会另开一个未接入采集通道的浏览器。'}));
      }
      return send(res, 409, JSON.stringify({ok:false, error:{code:'LOCAL_LINK_PENDING', message:'本机采集与回复链路待接通。'}}));
    });
    return;
  }
  if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  let rel = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const file = path.join(ROOT, rel);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
  }
  const type = MIME[path.extname(file)] || 'application/octet-stream';
  res.writeHead(200, {'Content-Type': type, 'Cache-Control': 'no-cache'});
  fs.createReadStream(file).pipe(res);
});
server.listen(PORT, '127.0.0.1', () => {
  console.log(`screenshot server http://127.0.0.1:${PORT}/`);
});
