const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, 'ui-preview');
const PORT = Number(process.env.FANGYU_PREVIEW_PORT || 57867);
const HOST = '127.0.0.1';
const OUT = path.join(ROOT, 'evidence');
fs.mkdirSync(OUT, {recursive: true});

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.json': 'application/json',
  '.md': 'text/plain; charset=utf-8'
};

const blocked = [];
let gets = 0;

function within(root, file) {
  return file === root || file.startsWith(root + path.sep);
}

function deny(res, why, status = 403) {
  blocked.push({time: new Date().toISOString(), why, status});
  fs.writeFileSync(path.join(OUT, 'transport-audit.json'), JSON.stringify({
    mode: 'isolated-ui-dry-run',
    staticRequests: gets,
    blocked
  }, null, 2));
  res.writeHead(status, {'Content-Type': 'application/json; charset=utf-8'});
  res.end(JSON.stringify({error: '本预览为硬闸门演练，不连接业务服务、本机桥接或采集发送', why, dryRun: true}));
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  if (url.pathname === '/api/workbench/bootstrap' && req.method === 'GET') {
    res.writeHead(404, {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'});
    return res.end(JSON.stringify({mode: 'isolated-ui-only', dryRun: true}));
  }
  if (url.pathname === '/__previewstatus') {
    res.writeHead(200, {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'});
    return res.end(JSON.stringify({
      app: 'fangyu-ui-rollback-dry-run',
      port: PORT,
      pid: process.pid,
      staticRequests: gets,
      blocked: blocked.length,
      mode: 'isolated-ui-dry-run',
      allowRealAcquisition: false,
      allowRealSend: false
    }));
  }
  if (url.pathname.startsWith('/api') || req.headers.upgrade || !['GET', 'HEAD'].includes(req.method)) {
    return deny(res, 'Business/upgrade request forbidden');
  }
  if (url.pathname === '/favicon.ico') {
    res.writeHead(204);
    return res.end();
  }
  let decoded;
  try { decoded = decodeURIComponent(url.pathname); }
  catch { return deny(res, 'Invalid path', 400); }
  const file = path.join(ROOT, decoded === '/' ? 'index.html' : decoded);
  if (!within(ROOT, file)) return deny(res, 'Outside static root');
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404, {'Content-Type': 'text/plain; charset=utf-8'});
    return res.end('Not found');
  }
  gets += 1;
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
    'Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; object-src 'none'; frame-src 'self'; form-action 'none'; base-uri 'none'",
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer'
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
});

server.on('upgrade', (req, socket) => {
  blocked.push({time: new Date().toISOString(), method: 'UPGRADE', path: req.url, why: 'No WebSocket in UI preview'});
  socket.end('HTTP/1.1 403 Forbidden\r\n\r\n');
});

server.listen(PORT, HOST, () => {
  console.log(`Fangyu UI rollback dry-run preview: http://${HOST}:${PORT}/`);
  console.log('Also: http://' + HOST + ':' + PORT + '/canvas.html#login');
  console.log('Hard gate on. No production controller, API, credentials, collection or send.');
});

const checkpoint = setInterval(() => {
  fs.writeFileSync(path.join(OUT, 'transport-audit.json'), JSON.stringify({
    mode: 'isolated-ui-dry-run',
    staticRequests: gets,
    blocked
  }, null, 2));
}, 5000);
checkpoint.unref();
