"""Local desktop shell with no employee identity or cloud login authority."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import threading
import uuid

from system_browser_login import edge_executable
from employee_gateway import original
from local_progress import read_progress


class LocalWorkbench:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.opened = {}
        root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
        rows = json.loads((root / 'local_stores.json').read_bytes())
        self.stores = [{'id': r['id'], 'name': r['name']} for r in rows if r['ready'] and r['id']]
        self.preference_path = self.data_dir / 'local-selection.json'
        self.selection = {'storeId': self.stores[0]['id'], 'revision': 0}
        preference = self.preference_path if self.preference_path.is_file() else (
            Path(sys.executable).parent / 'installation-preference.json')
        if preference.is_file():
            candidate = json.loads(preference.read_text(encoding='utf-8-sig'))
            if candidate.get('storeId') in {r['id'] for r in self.stores}:
                self.selection['storeId'] = candidate['storeId']
                revision = candidate.get('revision', 0)
                if type(revision) is int and revision >= 0:
                    self.selection['revision'] = revision

    def close(self):
        pass

    def bootstrap(self):
        return {'session': None, 'localMode': True, 'localProfile': {'name': '本机工作台'},
                'stores': list(self.stores), 'selection': dict(self.selection),
                'capabilities': {'platforms': False}, 'fixture': False}

    def _check_store(self, data):
        if type(data) is not dict or set(data) != {'storeId'} or data['storeId'] != self.selection['storeId']:
            raise original.WorkbenchError('INVALID_SELECTION', '请重新选择门店。', 409)

    def _browser(self, action, data):
        self._check_store(data)
        key = data['storeId']
        old = self.opened.get(key)
        if action == 'employee_browser_open' and (old is None or old.poll() is not None):
            profile = self.data_dir / 'douyin-browser' / hashlib.sha256(key.encode()).hexdigest()[:32]
            for parent in (profile, *profile.parents):
                if parent.exists() and (parent.is_symlink() or getattr(parent.lstat(), 'st_file_attributes', 0) & 0x400):
                    raise original.WorkbenchError('BROWSER_PATH_INVALID', '浏览器目录不可用。', 409)
            profile.mkdir(parents=True, exist_ok=True)
            try:
                self.opened[key] = subprocess.Popen(
                    [str(edge_executable()), '--user-data-dir=' + str(profile), '--no-first-run',
                     '--new-window', 'https://creator.douyin.com/'],
                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            except (OSError, ValueError) as exc:
                raise original.WorkbenchError('BROWSER_UNAVAILABLE', '请检查本机 Edge 是否可用。', 503) from exc
        active = self.opened.get(key)
        return {'browserState': 'browser_open_requested_login_unverified' if active and active.poll() is None else 'not_opened',
                'loginVerified': False, 'bridgeConnected': False, 'startedOperations': []}

    def dispatch(self, action, data, token=''):
        with self.lock:
            if action == 'bootstrap':
                return self.bootstrap()
            if action == 'local_progress':
                if data != {}:
                    raise original.WorkbenchError('INVALID_REQUEST', '请重新打开运行状态。', 400)
                return read_progress()
            if action == 'select_store':
                if type(data) is not dict or set(data) - {'storeId', 'expectedRevision'} or data.get('storeId') not in {r['id'] for r in self.stores}:
                    raise original.WorkbenchError('INVALID_SELECTION', '请选择有效门店。', 400)
                if data.get('expectedRevision', self.selection['revision']) != self.selection['revision']:
                    raise original.WorkbenchError('SELECTION_CHANGED', '门店已变化，请重新选择。', 409)
                selection = {'storeId': data['storeId'], 'revision': self.selection['revision'] + 1}
                temporary = self.preference_path.with_name('selection-' + uuid.uuid4().hex + '.tmp')
                try:
                    temporary.write_text(json.dumps(selection), encoding='utf-8')
                    os.replace(temporary, self.preference_path)
                finally:
                    temporary.unlink(missing_ok=True)
                self.selection = selection
                return self.bootstrap()
            if action in ('employee_browser_open', 'employee_browser_status'):
                return self._browser(action, data)
            if action == 'employee_cloud_status':
                self._check_store(data)
                return {'authenticationConfigured': False, 'loginVerified': False, 'collectionReady': False,
                        'replyReady': False, 'keywords': [], 'approvedDrafts': [], 'cloudAvailable': False}
            if action == 'local_drafts':
                raise original.WorkbenchError('LOCAL_DATA_PENDING', '本地客户数据正在接入，当前请以原程序记录为准。', 409)
            raise original.WorkbenchError('LOCAL_LINK_PENDING', '本机采集与回复链路待接通。', 409)


def create_backend(data_dir):
    return LocalWorkbench(data_dir)
