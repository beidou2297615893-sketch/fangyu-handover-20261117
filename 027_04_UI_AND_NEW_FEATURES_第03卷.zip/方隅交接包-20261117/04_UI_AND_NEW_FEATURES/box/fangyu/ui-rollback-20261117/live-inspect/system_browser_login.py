"""Trusted-host system-browser login preparation; no bridge/read/send authority.

authority(token, account_id) MUST be the host's original authenticated,
store/account-scoped callback, never a dictionary supplied by a webpage.
It returns tenant_id, employee_id, account_id and session_revision after its
normal current-session/employee/account checks. No authority means fail closed.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import threading
import time

PAIRING_URL = re.compile(
    r'https://fh6-d5ga45c0ddae7008c-1439321968\.ap-shanghai\.app\.tcloudbase\.com'
    r'/fangyu-workspace/douyin/oauth/connect#[a-f0-9]{64}\Z'
)


def edge_executable():
    for variable in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
        base = os.environ.get(variable)
        if base:
            path = Path(base) / 'Microsoft/Edge/Application/msedge.exe'
            if path.is_file() and not path.is_symlink():
                return path
    raise ValueError('edge_dependency_not_ready')


class SystemBrowserLogin:
    def __init__(self, data_root, authority):
        if not callable(authority):
            raise ValueError('trusted_host_authority_required')
        self.root = Path(data_root).absolute()
        self.authority = authority
        self.lock = threading.RLock()
        self.opened = {}

    def _scope(self, token, account_id):
        value = self.authority(token, account_id)
        fields = ('tenant_id', 'employee_id', 'account_id', 'session_revision')
        if (type(value) is not dict or any(type(value.get(k)) is not str or not value[k] for k in fields)
                or value['account_id'] != account_id
                or re.fullmatch(r'[A-Za-z0-9_-]{1,160}', account_id) is None):
            raise ValueError('current_employee_account_scope_required')
        return {key: value[key] for key in fields}

    def _path(self, scope):
        path = self.root
        for key in ('tenant_id', 'employee_id', 'account_id'):
            path /= hashlib.sha256(scope[key].encode()).hexdigest()[:32]
        path /= 'official-browser-profile'
        for ancestor in (path, *path.parents):
            if ancestor.exists() and (ancestor.is_symlink()
                    or getattr(ancestor.lstat(), 'st_file_attributes', 0) & 0x400):
                raise ValueError('linked_profile_path_rejected')
        return path

    def open(self, account_id, token):
        return self._open(account_id, token, 'https://creator.douyin.com/', pairing=False)

    def open_pairing(self, account_id, token, url):
        if not isinstance(url, str) or not PAIRING_URL.fullmatch(url):
            raise ValueError('untrusted_company_pairing_url')
        return self._open(account_id, token, url, pairing=True)

    def _open(self, account_id, token, url, *, pairing):
        with self.lock:
            scope = self._scope(token, account_id)
            profile = self._path(scope)
            executable = edge_executable()
            # No personal browser/profile/cookies or bridge config are read.
            profile.mkdir(parents=True, exist_ok=True)
            if self._scope(token, account_id) != scope:
                raise ValueError('employee_session_changed')
            key = str(profile)
            old = self.opened.get(key)
            if not pairing and old and old['scope'] == scope and old['process'].poll() is None:
                return self._dto(old, already_open=True)
            process = subprocess.Popen([str(executable), '--user-data-dir=' + str(profile),
                '--no-first-run', '--new-window', url],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            entry = {'scope': scope, 'process': process, 'opened_at': time.time()}
            if not pairing:
                self.opened[key] = entry
            # A session change after dispatch must not become a success for a
            # different employee; never retry or claim the platform logged in.
            if self._scope(token, account_id) != scope:
                raise ValueError('browser_request_result_unconfirmed')
            return self._dto(entry)

    @staticmethod
    def _dto(entry, already_open=False):
        return {'platform': 'douyin', 'state': 'browser_open_requested_login_unverified',
            'accountId': entry['scope']['account_id'], 'alreadyOpen': already_open,
            'platformLoginConfirmed': False, 'platformAccountBound': False,
            'collectionReady': False, 'replyReady': False, 'bridgeConnected': False,
            'launchProcessExited': entry['process'].poll() is not None,
            'message': '已请求打开抖音创作者中心，请在官方页面扫码登录。'}

    def status(self, account_id, token):
        with self.lock:
            scope = self._scope(token, account_id)
            entry = self.opened.get(str(self._path(scope)))
            if entry is None or entry['scope'] != scope:
                return {'platform': 'douyin', 'state': 'not_opened',
                    'platformLoginConfirmed': False, 'collectionReady': False, 'replyReady': False}
            return self._dto(entry)
