const app = document.querySelector('#app');
const noticeDialog = document.querySelector('#notice');
let csrf = '';
let state = {};
let page = 'work';
let choosingStore = false;
let view = 0;
const submittedReplyRefs = new Set();
function escapeText(value) {
  const entities = {'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'};
  return String(value ?? '').replace(/[&<>"']/g, ch => entities[ch]);
}

async function api(action, data = {}) {
  const response = await fetch('/api/workbench', {
    method: 'POST',
    headers: {'Content-Type':'application/json', 'X-Fangyu-CSRF':csrf},
    body: JSON.stringify({action, data})
  });
  const value = await response.json();
  if (!response.ok || value.ok !== true) {
    throw Error(value.error?.message || '暂时无法完成操作');
  }
  csrf = value.csrfToken || csrf;
  return value;
}

function notice(title, message) {
  document.querySelector('#noticeTitle').textContent = title;
  document.querySelector('#noticeText').textContent = message;
  if (!noticeDialog.open) noticeDialog.showModal();
}
document.querySelector('#closeNotice').onclick = () => noticeDialog.close();

function guarded(button, callback) {
  button.onclick = async () => {
    if (button.disabled) return;
    button.disabled = true;
    const currentView = view;
    try { await callback(); }
    catch (error) { if (view === currentView) notice('操作未完成', error.message); }
    finally { if (button.isConnected) button.disabled = false; }
  };
}

function renderStorePicker() {
  app.innerHTML = '<h1>选择门店</h1><div class="store-grid"></div>';
  const list = app.querySelector('.store-grid');
  for (const store of state.stores || []) {
    const button = document.createElement('button');
    button.textContent = store.name;
    button.dataset.store = store.id;
    list.append(button);
    guarded(button, async () => {
      const choices = [...list.querySelectorAll('button')];
      choices.forEach(choice => { choice.disabled = true; });
      try {
        const data = {storeId:store.id};
        if (Number.isSafeInteger(state.selection?.revision)) data.expectedRevision = state.selection.revision;
        state = await api('select_store', data);
        choosingStore = false;
        page = 'work';
        render();
      } finally { choices.forEach(choice => { choice.disabled = false; }); }
    });
  }
  if (!list.children.length) list.textContent = '尚未配置本机门店。';
}

function renderWork(content, store) {
  const currentView = view;
  content.innerHTML = '<h1>抖音工作台</h1><div class="top"><p class="status" id="connection" role="status" aria-live="polite">正在检查连接</p></div>' +
    '<div class="buttons"><button class="primary" id="prepare">登录抖音</button><button id="authorize" hidden>企业授权</button><button id="check">检查连接</button></div>' +
    '<div class="controls" style="margin-top:32px"><button disabled id="collect">开始采集</button><button disabled id="reply">开始回复</button></div>' +
    '<p class="info" id="workState" role="status" aria-live="polite"></p>' +
    '<dialog id="chooseReply"><h2>选择已批准的回复</h2><label for="drafts">待回复草稿</label>' +
    '<select id="drafts"></select><p id="selectedDraft"></p><div class="buttons">' +
    '<button id="back">取消</button><button class="primary" id="submitReply" disabled>确认发送这条回复</button></div></dialog>';
  const prepare = content.querySelector('#prepare');
  const authorize = content.querySelector('#authorize');
  const check = content.querySelector('#check');
  const collect = content.querySelector('#collect');
  const reply = content.querySelector('#reply');
  const dialog = content.querySelector('#chooseReply');
  const drafts = content.querySelector('#drafts');
  const preview = content.querySelector('#selectedDraft');
  const submitReply = content.querySelector('#submitReply');
  const title = content.querySelector('#connection');
  const info = content.querySelector('#workState');
  const current = () => view === currentView;
  let busy = false, running = false, pauseRequested = false, cloud = {};
  let pending = [], targets = '', lastMessage = '';
  const idOf = row => JSON.stringify([state.localProfile?.name, store.id, row.approvedReplyRef]);
  function alreadySubmitted(row) {
    const id = idOf(row);
    if (submittedReplyRefs.has(id)) return true;
    try { return sessionStorage.getItem('fy-reply:' + id) === 'submitted'; } catch { return false; }
  }
  function approvedDrafts() {
    if (cloud.loginVerified !== true || cloud.replyReady !== true || !Array.isArray(cloud.approvedDrafts)) return [];
    return cloud.approvedDrafts.filter(row => row && typeof row.approvedReplyRef === 'string' && row.approvedReplyRef.trim() && row.approvedReplyRef.length <= 512 &&
      /^[a-f0-9]{64}$/.test(row.contentDigest) && typeof row.content === 'string' && row.content.trim() && !alreadySubmitted(row));
  }

  function paint() {
    if (!current()) return;
    prepare.disabled = check.disabled = authorize.disabled = busy || running;
    authorize.hidden = cloud.authenticationConfigured !== true || cloud.loginVerified === true;
    collect.disabled = running ? pauseRequested : (busy || cloud.collectionReady !== true);
    reply.disabled = busy || running || approvedDrafts().length === 0;
    collect.textContent = running ? (pauseRequested ? '正在暂停' : '暂停采集') : pending.length ? '继续采集' : '开始采集';
    info.textContent = lastMessage || (approvedDrafts().length ? '可选择已批准的草稿并确认回复。' :
      cloud.collectionReady ? '使用本店获批关键词采集。当前没有可发送的已批准回复。' : '本机采集与回复链路待接通。');
  }
  async function update(action) {
    if (busy || running || !current()) return;
    busy = true;
    paint();
    try {
      if (state.fixture === true) {
        title.textContent = '合成数据验收';
        lastMessage = '演示环境不连接抖音。';
        return;
      }
      if (action === 'authorize') {
        const receipt = await api('employee_authorization_open', {storeId:store.id});
        if (!current()) return;
        if (receipt.authorizationOpened !== true) throw Error('企业授权页未确认打开。');
        title.textContent = '等待企业授权';
        lastMessage = '请在抖音完成扫码授权，再检查连接。';
        return;
      }
      const result = await api(action === 'open' ? 'employee_browser_open' : 'employee_browser_status', {storeId:store.id});
      if (!current()) return;
      try { cloud = await api('employee_cloud_status', {storeId:store.id}); }
      catch { cloud = {}; }
      if (!current()) return;
      if (cloud.loginVerified === true) {
        title.textContent = '企业抖音账号已授权';
      } else if (result.browserState === 'not_opened') {
        title.textContent = '等待登录抖音';
      } else if (result.browserState === 'browser_open_requested_login_unverified') {
        title.textContent = '已请求打开抖音，账号待核实';
      } else { title.textContent = '抖音连接待核实'; }
      if (pending.length && (!cloud.collectionReady || targetDigest() !== targets)) {
        pending = [];
        lastMessage = '门店规则或平台授权已变化，原范围已停止。';
      }
    } catch (error) {
      if (current()) {
        cloud = {};
        title.textContent = action === 'open' ? '抖音登录页未确认打开' : '连接状态待核实';
        lastMessage = error.message;
      }
    } finally { busy = false; paint(); }
  }
  function targetDigest() {
    return JSON.stringify((cloud.keywords || []).map(word => word.keywordRef));
  }
  async function run() {
    if (running) { pauseRequested = true; paint(); return; }
    if (busy || !current() || cloud.collectionReady !== true) return;
    if (!pending.length) {
      targets = targetDigest();
      pending = (cloud.keywords || []).map(word => ({type:'keyword', ref:word.keywordRef, cursor:0}));
    }
    running = true;
    pauseRequested = false;
    lastMessage = '正在读取抖音评论。';
    paint();
    try {
      while (current() && pending.length && !pauseRequested) {
        const task = pending[0], isSearch = task.type === 'keyword';
        const input = {storeId:store.id, cursor:task.cursor, [isSearch ? 'keywordRef' : 'videoRef']:task.ref};
        const result = await api(isSearch ? 'employee_keyword_page' : 'employee_video_comments', input);
        if (!current()) return;
        const key = isSearch ? 'videoRef' : 'commentRef';
        if (!Array.isArray(result.rows) || result.rows.length > 10 || typeof result.hasMore !== 'boolean' ||
          !Number.isSafeInteger(result.nextCursor) || result.nextCursor < 0 || (result.hasMore && result.nextCursor <= task.cursor) ||
          result.rows.some(row => typeof row?.[key] !== 'string' || !/^[a-f0-9]{64}$/.test(row[key]))) {
          throw Error('未取得有效的采集回执。');
        }
        // Only advance after a verified committed cloud page. If the response
        // is lost, manual continue requests the same immutable page.
        pending.shift();
        const next = isSearch ? result.rows.map(row => ({type:'video', ref:row.videoRef, cursor:0})) : [];
        if (result.hasMore) next.push({...task, cursor:result.nextCursor});
        pending.unshift(...next);
      }
      lastMessage = pending.length ? '已暂停采集，原范围可继续。' : '本轮获批关键词及评论已读取完毕。';
    } catch (error) {
      lastMessage = error.message;
      if (current()) {
        try { cloud = await api('employee_cloud_status', {storeId:store.id}); } catch { cloud = {}; }
        if (current() && (!cloud.collectionReady || targetDigest() !== targets)) pending = [];
      }
    } finally { running = false; paint(); }
  }
  prepare.onclick = () => update('open');
  authorize.onclick = () => update('authorize');
  check.onclick = () => update('status');
  collect.onclick = run;
  reply.onclick = () => {
    if (busy || running || !current() || reply.disabled) return;
    const rows = approvedDrafts();
    if (!rows.length) return;
    drafts.replaceChildren(new Option('请选择一条回复', ''));
    for (const row of rows) drafts.add(new Option(row.content, row.approvedReplyRef));
    preview.textContent = '';
    submitReply.disabled = true;
    drafts.onchange = () => {
      const row = rows.find(item => item.approvedReplyRef === drafts.value);
      preview.textContent = row?.content || '';
      submitReply.disabled = !row;
    };
    content.querySelector('#back').onclick = () => dialog.close();
    submitReply.onclick = async () => {
      const row = rows.find(item => item.approvedReplyRef === drafts.value);
      if (!row || busy || !current() || alreadySubmitted(row)) return;
      const id = idOf(row);
      submittedReplyRefs.add(id);
      try { sessionStorage.setItem('fy-reply:' + id, 'submitted'); } catch {}
      busy = true;
      submitReply.disabled = true;
      dialog.close();
      lastMessage = '正在提交这条回复。';
      paint();
      try {
        const result = await api('employee_approved_reply', {storeId:store.id, approvedReplyRef:row.approvedReplyRef,
          contentDigest:row.contentDigest, confirmed:true});
        lastMessage = result.state === 'sent' ? '平台已确认这条回复发送成功。' : '回复结果待核实，请先查看原评论。';
      } catch { lastMessage = '回复结果待核实，请先查看原评论。'; }
      finally { busy = false; paint(); }
    };
    dialog.showModal();
  };
  update('status');
}

async function renderCustomers(content) {
  if (state.fixture === true) {
    content.innerHTML = '<h1>客户</h1><p>合成示例客户 · 草稿未发送</p>';
    return;
  }
  const currentView = view;
  content.innerHTML = '<h1>本机客户草稿</h1><p role="status">正在读取</p>';
  try {
    const value = await api('local_drafts');
    if (view !== currentView) return;
    content.innerHTML = '<h1>本机客户草稿</h1>';
    for (const draft of value.localDrafts || []) {
      const row = document.createElement('article');
      row.className = 'info';
      row.textContent = [draft.intent, draft.draft || draft.reasons?.join('、') || '待核对'].filter(Boolean).join(' · ');
      content.append(row);
    }
    if (!value.localDrafts?.length) content.insertAdjacentHTML('beforeend', '<p>暂无客户草稿。</p>');
  } catch (error) { if (currentView === view) content.querySelector('p').textContent = error.message; }
}

async function renderProgress(content) {
  const currentView = view;
  content.innerHTML = '<h1>运行状态</h1><p class="info">显示原程序保存的状态记录。完整统计仍在接入中。</p><p id="progressTime" role="status"></p><div id="progressSources"></div>';
  const names = {collection_active:'采集任务',collection_wait:'采集验证提醒',collection_recovery:'采集恢复状态',collection_progress:'采集进度',classification_handoff:'分类进度',reply_status:'回复状态',reply_active:'回复任务',reply_hold:'回复暂停提醒',collection_control:'采集控制状态',reply_batch:'当前批次'};
  const states = {missing:'尚无状态记录',unavailable:'暂时无法读取',available:'已读取状态记录'};
  async function update() {
    try {
      const value = await api('local_progress');
      if (view !== currentView) return;
      const container = content.querySelector('#progressSources');
      const opened = new Set([...container.querySelectorAll('details[open]')].map(node => node.dataset.source));
      container.replaceChildren();
      content.querySelector('#progressTime').textContent = '本次读取时间 ' + new Date(value.observed_at).toLocaleTimeString('zh-CN');
      for (const [name, record] of Object.entries(value.sources || {})) {
        const section = document.createElement('details');
        section.dataset.source = name;
        section.open = opened.has(name);
        const summary = document.createElement('summary');
        summary.textContent = (names[name] || name) + ' · ' + (states[record.state] || '状态待确认');
        section.append(summary);
        if (record.modified_at) {
          const time = document.createElement('p');
          time.textContent = '记录更新时间 ' + new Date(record.modified_at).toLocaleString('zh-CN');
          section.append(time);
        }
        if (record.data !== null && record.data !== undefined) {
          const detail = document.createElement('pre');
          detail.textContent = JSON.stringify(record.data, null, 2);
          section.append(detail);
        }
        container.append(section);
      }
    } catch (error) {
      if (view === currentView) content.querySelector('#progressTime').textContent = error.message;
    }
    if (view === currentView) setTimeout(update, 5000);
  }
  await update();
}

function render() {
  view++;
  const profile = state.localMode === true ? state.localProfile : null;
  const store = state.stores?.find(item => item.id === state.selection?.storeId);
  const storeLabel = document.querySelector('#storeLabel');
  storeLabel.textContent = profile && !choosingStore && store ? store.name : '';
  storeLabel.hidden = !storeLabel.textContent;
  const tag = document.querySelector('.tag');
  tag.textContent = state.localMode === true ? '本机模式' : '';
  tag.hidden = !tag.textContent;
  if (!profile) { app.textContent = '本机工作台暂未就绪，请关闭后重新打开。'; return; }
  if (!store || choosingStore) return renderStorePicker();
  app.innerHTML = '<div class="layout"><nav class="nav" aria-label="工作台导航">' +
    '<button data-page="work">抖音</button><button data-page="progress">运行状态</button><button data-page="customers">客户</button><button data-page="settings">设置</button>' +
    '<button id="switch">切换门店</button></nav><section id="content"></section></div>';
  for (const button of app.querySelectorAll('[data-page]')) {
    button.classList.toggle('active', button.dataset.page === page);
    button.onclick = () => { page = button.dataset.page; render(); };
  }
  app.querySelector('#switch').onclick = () => { choosingStore = true; render(); };
  const content = app.querySelector('#content');
  if (page === 'work') return renderWork(content, store);
  if (page === 'progress') return renderProgress(content);
  if (page === 'customers') return renderCustomers(content);
  content.innerHTML = '<h1>设置</h1><h2>' + escapeText(store.name) + '</h2><p>' + escapeText(profile.name || '本机工作台') +
    '</p><p class="info">本机模式。当前云接入尚待配置。</p>';
}

try {
  const response = await fetch('/api/workbench/bootstrap');
  if (!response.ok) throw Error();
  state = await response.json();
  csrf = state.csrfToken;
  render();
} catch { app.textContent = '本地服务暂未就绪，请关闭后重新打开。'; }

