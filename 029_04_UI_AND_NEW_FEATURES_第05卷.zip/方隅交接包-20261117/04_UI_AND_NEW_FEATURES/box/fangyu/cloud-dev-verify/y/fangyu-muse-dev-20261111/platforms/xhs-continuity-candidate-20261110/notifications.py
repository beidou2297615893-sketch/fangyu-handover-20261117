"""Persistent candidate-only stop alerts. Importing this module has no UI effects.

WindowsBackend submits a system notification; ``submitted`` does not certify
that a human saw/heard it. Tests must inject a backend to avoid desktop effects.
"""
import base64
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import tempfile


_SECRET_KEY = re.compile(r"cookie|token|password|authorization|api[_-]?key|secret", re.I)
_SECRET_VALUE = re.compile(r"((?:cookie|token|password|authorization|api[_-]?key|secret)\s*[:=]\s*)([^;\s,]+)", re.I)


def _safe(value):
    if isinstance(value, dict):
        return {str(k): "[已隐藏]" if _SECRET_KEY.search(str(k)) else _safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe(v) for v in value]
    if isinstance(value, str):
        return _SECRET_VALUE.sub(r"\1[已隐藏]", value)
    if value is None or isinstance(value, (int, float, bool)):
        return value
    return _safe(str(value))


class WindowsBackend:
    """Standard-library PowerShell toast + timed popup/sound fallback.

    No installs, privilege changes, registry writes or network calls. runner is
    injectable so offline tests never launch PowerShell or display notifications.
    """
    def __init__(self, runner=None):
        self.runner = subprocess.run if runner is None else runner

    def _run(self, script):
        encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        self.runner(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded],
            shell=False, check=True, timeout=1.4, capture_output=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )

    def __call__(self, alert):
        message = {"title": "小红书任务已停止 · " + alert["lane"], "body": alert["reason"] + "\n下一步：" + alert["action"]}
        encoded = base64.b64encode(json.dumps(message, ensure_ascii=False).encode("utf-8")).decode("ascii")
        prefix = ("$ErrorActionPreference='Stop';"
                  "$m=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "'))|ConvertFrom-Json;")
        toast = prefix + """
[Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime]|Out-Null;
[Windows.Data.Xml.Dom.XmlDocument,Windows.Data.Xml.Dom.XmlDocument,ContentType=WindowsRuntime]|Out-Null;
$title=[Security.SecurityElement]::Escape($m.title);$body=[Security.SecurityElement]::Escape($m.body);
$xml=New-Object Windows.Data.Xml.Dom.XmlDocument;
$xml.LoadXml('<toast duration="long"><visual><binding template="ToastGeneric"><text>'+$title+'</text><text>'+$body+'</text></binding></visual><audio src="ms-winsoundevent:Notification.Default"/></toast>');
$toast=[Windows.UI.Notifications.ToastNotification]::new($xml);
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('Windows PowerShell').Show($toast);
"""
        try:
            self._run(toast)
            return
        except Exception as toast_error:
            first = type(toast_error).__name__
        fallback = prefix + """
Add-Type -AssemblyName System;
[System.Media.SystemSounds]::Exclamation.Play();
$popup=New-Object -ComObject WScript.Shell;
$result=$popup.Popup($m.body,1,$m.title,4112);
"""
        try:
            self._run(fallback)
        except Exception as fallback_error:
            raise RuntimeError("系统通知与弹窗声音均失败：" + first + "; " + type(fallback_error).__name__) from fallback_error


class Notifier:
    """One durable alert per event ID, across threads and process restarts.

    Unknown delivery after a crash is never automatically replayed. An explicit
    retry is allowed only for a recorded failure. Acknowledge means read, not
    resume/retry/resolve, and never modifies a platform/business ledger.
    """
    def __init__(self, root, backend=None):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "notification-alerts.sqlite3"
        self.backend = WindowsBackend() if backend is None else backend
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS alerts (
                event_id TEXT PRIMARY KEY, lane TEXT NOT NULL, reason TEXT NOT NULL,
                action TEXT NOT NULL, details TEXT NOT NULL, created_at TEXT NOT NULL,
                acknowledged INTEGER NOT NULL DEFAULT 0,
                delivery_status TEXT NOT NULL DEFAULT 'unknown',
                delivery_error TEXT NOT NULL DEFAULT '', attempts INTEGER NOT NULL DEFAULT 1)""")
        self._publish()

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def _alert(row):
        if row is None:
            raise KeyError("没有这个停止提醒")
        result = dict(row)
        result["acknowledged"] = bool(result["acknowledged"])
        result["details"] = json.loads(result["details"])
        result["severity"] = "red"
        return result

    def _get(self, event_id):
        with self._connect() as db:
            return self._alert(db.execute("SELECT * FROM alerts WHERE event_id=?", (event_id,)).fetchone())

    def _snapshot(self, db):
        alerts = [self._alert(row) for row in db.execute("SELECT * FROM alerts ORDER BY created_at, event_id")]
        failed = sum(a["delivery_status"] == "failed" for a in alerts)
        unknown = sum(a["delivery_status"] == "unknown" for a in alerts)
        headline = "任务停止提醒，请按下一步处理" if alerts else "暂无停止提醒"
        if failed:
            headline += "；通知未送达，请查看本页"
        if unknown:
            headline += "；通知投递结果待核对，不自动重发"
        return {"severity": "red" if alerts else "normal", "headline": headline,
                "unread_count": sum(not a["acknowledged"] for a in alerts),
                "delivery_failures": failed, "delivery_unknown": unknown, "alerts": alerts}

    def snapshot(self):
        with self._connect() as db:
            return self._snapshot(db)

    def _publish(self):
        # Serialize publication against all mutations; an older writer cannot
        # replace a newer state. The DB remains the durable source of truth.
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            content = json.dumps(self._snapshot(db), ensure_ascii=False, indent=2)
            temp = None
            try:
                with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=self.root, prefix="alerts-", suffix=".tmp", delete=False) as handle:
                    temp = Path(handle.name)
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temp, self.root / "alerts.json")
            finally:
                if temp is not None and temp.exists():
                    temp.unlink()

    def emit(self, event_id, lane, reason, action, details=None):
        for name, value in (("event_id", event_id), ("lane", lane), ("reason", reason), ("action", action)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(name + " must be a nonempty string")
        with self._connect() as db:
            result = db.execute(
                "INSERT OR IGNORE INTO alerts(event_id,lane,reason,action,details,created_at) VALUES(?,?,?,?,?,?)",
                (event_id, _safe(lane), _safe(reason), _safe(action), json.dumps(_safe(details), ensure_ascii=False), datetime.now(timezone.utc).isoformat()),
            )
            inserted = result.rowcount == 1
        self._publish()  # failure is intentionally propagated; never silently lose an alert
        if inserted:
            return self._deliver(event_id)
        return self._get(event_id)

    def _deliver(self, event_id):
        try:
            self.backend(deepcopy(self._get(event_id)))
        except Exception as exc:
            status, error = "failed", _safe(type(exc).__name__ + ": " + str(exc))
        else:
            status, error = "submitted", ""
        with self._connect() as db:
            db.execute("UPDATE alerts SET delivery_status=?,delivery_error=? WHERE event_id=?", (status, error, event_id))
        self._publish()
        return self._get(event_id)

    def retry_delivery(self, event_id):
        with self._connect() as db:
            result = db.execute("UPDATE alerts SET delivery_status='unknown',delivery_error='',attempts=attempts+1 WHERE event_id=? AND delivery_status='failed'", (event_id,))
            retry = result.rowcount == 1
        if retry:
            self._publish()
            return self._deliver(event_id)
        return self._get(event_id)

    def acknowledge(self, event_id):
        with self._connect() as db:
            db.execute("UPDATE alerts SET acknowledged=1 WHERE event_id=?", (event_id,))
        self._publish()
        return self._get(event_id)
