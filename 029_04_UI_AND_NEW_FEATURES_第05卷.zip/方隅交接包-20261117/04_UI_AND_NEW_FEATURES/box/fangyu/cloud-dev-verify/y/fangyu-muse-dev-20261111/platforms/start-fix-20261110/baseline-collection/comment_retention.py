"""Local rolling retention for Douyin business rows. Recovery evidence is untouched."""
import argparse
import datetime
import hashlib
import json
import sqlite3
import time
from pathlib import Path

ZONE = datetime.timezone(datetime.timedelta(hours=8))


def fingerprint(cid):
    return hashlib.sha256(('douyin\0' + cid).encode()).hexdigest()


def timestamp(item, now):
    value = item.get('create_time')
    if isinstance(value, str) and value.isdigit():
        value = int(value)
    if type(value) is not int or value <= 0 or value > now.timestamp():
        return None
    try:
        return datetime.datetime.fromtimestamp(value, ZONE)
    except (OverflowError, OSError, ValueError):
        return None


def expired(published, now):
    return (now - published).total_seconds() > 30 * 86400


def initialize(db):
    db.execute('CREATE TABLE IF NOT EXISTS expired_comment_fingerprints(digest TEXT PRIMARY KEY)')
    db.execute('CREATE TABLE IF NOT EXISTS excluded_comment_fingerprints(digest TEXT PRIMARY KEY, classification_version TEXT NOT NULL, lead_intent TEXT NOT NULL, snapshot_sha256 TEXT NOT NULL)')


def prune(path, now=None, batch_size=200):
    now = now or datetime.datetime.now(ZONE)
    db = sqlite3.connect(path, timeout=2)
    initialize(db)
    db.execute("CREATE INDEX IF NOT EXISTS observations_retention_key ON observations(stable_key) WHERE kind='comments'")
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='recent_comment_backfill'").fetchone():
        db.execute('CREATE INDEX IF NOT EXISTS backfill_retention_cid ON recent_comment_backfill(cid)')
    db.commit()
    # Read snapshots outside a write transaction, then delete bounded batches.
    rows = db.execute("SELECT stable_key,data FROM entities WHERE kind='comments' UNION SELECT stable_key,data FROM observations WHERE kind='comments' UNION SELECT stable_key,data FROM items WHERE kind='comments'").fetchall()
    expired_keys, unknown, fresh = set(), set(), set()
    for key, raw in rows:
        published = timestamp(json.loads(raw), now)
        if published is None:
            unknown.add(key)
        elif expired(published, now):
            expired_keys.add(key)
        else:
            fresh.add(key)
    # Conflicting or unknown original dates need review rather than deletion.
    expired_keys.difference_update(unknown | fresh)
    totals = dict(entities=0, observations=0, items=0, backfill=0)
    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    keys = sorted(expired_keys)
    for start in range(0, len(keys), batch_size):
        batch = keys[start:start + batch_size]
        marks = ','.join('?' for _ in batch)
        with db:
            db.executemany('INSERT OR IGNORE INTO expired_comment_fingerprints VALUES(?)',
                           [(fingerprint(key.rsplit(':', 1)[-1]),) for key in batch])
            for table in ('observations', 'items', 'entities'):
                totals[table] += db.execute(f"DELETE FROM {table} WHERE kind='comments' AND stable_key IN ({marks})", batch).rowcount
            if 'recent_comment_backfill' in tables:
                ids = [key.rsplit(':', 1)[-1] for key in batch]
                totals['backfill'] += db.execute(f'DELETE FROM recent_comment_backfill WHERE cid IN ({marks})', ids).rowcount
        time.sleep(0.01)
    remaining = db.execute("SELECT COUNT(*) FROM entities WHERE kind='comments'").fetchone()[0]
    db.close()
    return dict(deleted=totals, expired_unique=len({key.rsplit(':', 1)[-1] for key in expired_keys}), unknown_unique=len({key.rsplit(':', 1)[-1] for key in unknown}), remaining_business_comments=remaining)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--database', default=str(Path(__file__).parent / 'runtime/collection.sqlite3'))
    parser.add_argument('--watch', action='store_true')
    parser.add_argument('--classified', action='store_true')
    args = parser.parse_args()
    while True:
        try:
            print(json.dumps(prune(args.database)), flush=True)
            if args.classified:
                from classified_comment_prune import prune_classified
                try:
                    print(json.dumps(prune_classified(args.database)), flush=True)
                except (ValueError, KeyError) as error:
                    print(json.dumps({'classification_snapshot_rejected':str(error)}), flush=True)
        except sqlite3.OperationalError as error:
            print(json.dumps({'local_error': getattr(error, 'sqlite_errorname', 'SQLITE_ERROR')}), flush=True)
        if not args.watch:
            break
        time.sleep(60)
