"""Stage two: bounded reuse of existing short/combination mothers, no platform access."""
import collections, datetime as dt, hashlib, importlib.util, json, re, sqlite3, string
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
TEXT=ROOT/'work/fangyu-text-business-20261029'
OUT=Path(__file__).resolve().parent
FIRST=OUT/'frozen-6f9990c0a2438e23'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s]
def clean(s):return re.sub(r'[\s，。？！、,.!?～~：:＋+👋🙋]', '',re.sub(r'\[[^\]]*\]','',s))

def choose(own,pools):
    """Select only after existing semantic classification; no new intent labels."""
    norm=clean(own)
    if set(pools)=={'价格预算','位置通勤'}:
        remainder=norm
        for token in sorted(['你好','您好','礼貌','请问','问一下','问问','麻烦','谢谢','怎么样','多少价格','什么价格','价格','價格','问价','問價','询价','询个价','租金','多少钱','多钱','多少','哪个','什么','具体','位置','地址','在哪里','在哪','哪里','小区名字','小区名','小区','小區','和','与','呀','啊','呢','哇'],key=len,reverse=True):remainder=remainder.replace(token,'')
        if not remainder:return 'price_location',{}
    if set(pools)=={'位置通勤'} and re.fullmatch(r'(?:你好|您好)?(?:请问一下|请问|求|礼貌|问)?(?:具体)?(?:哪个小区|什么小区|小区位置|具体位置是|地址在哪|在那里)(?:啊|呀|呢|哇|是)*',norm):return 'location',{}
    if set(pools)=={'价格预算'} and norm in {'礼貌询个价','dd问价','滴滴礼貌询价','有价格吗'}:return 'price',{}
    if set(pools)=={'房源状态'} and norm in {'这套还在吗','这个房源还有吗','还在吗关注了','li还有吗','你好房子还在吗','你好房子还在嘛','房子还在吗'}:return 'available',{}
    if set(pools)=={'价格预算','房源状态'} and norm in {'你好请问房子还在嘛礼貌询价','还在吗询价'}:return 'combo_available_price',{}
    if set(pools)=={'看房联系'} and norm in {'请问可以看房吗','想看房','可以看看房子','请问方便看房吗','可以看房吗','你好可以看看嘛'}:return 'combo_view',{}
    if set(pools)=={'看房联系'} and norm=='求丝':return 'contact_how',{}
    if set(pools)=={'位置通勤','看房联系'} and norm=='位置可以看房吗':return 'combo_location_view',{}
    if set(pools)=={'费用合同'} and norm in {'你好是民水民电吗','民水民电me'}:return 'utilities',{}
    literal={
      '有没有两室的':('有没有两室',{'户型面积与居住方式','房源状态'}),
      '有两居室吗':('两居室',{'户型面积与居住方式'}),
      '请问商用水电吗':('商用水电',{'费用合同'}),
      '请问押几付几呀':('押几付几',{'费用合同'}),
      '问下楼层':('楼层',{'楼层电梯'}),
      '大房东还是二房东':('大房东还是二房东',{'费用合同'}),
      '这个多少平啊':('多少平',{'户型面积与居住方式'}),
      '晾衣服在哪呀':('晾衣服在哪',{'房内设施'}),
    }
    if norm in literal:
        span,expected=literal[norm]
        if set(pools)==expected and span in own:return 'requirements',{'requirements':span}
    return None,{}

def main():
    sourcehash={}
    def pin(path):path=path.resolve();sourcehash[str(path)]=sha(path.read_bytes());return path
    firstman=read(pin(FIRST/'manifest.json'))
    for name,digest in firstman['files'].items():assert sha((FIRST/name).read_bytes())==digest
    first=rows(pin(FIRST/'ready-drafts.jsonl'));held=rows(pin(FIRST/'held-drafts.jsonl'))
    pool={r['comment_id']:r for r in rows(pin(TEXT/'high-intent-pools-20261101/all-high-intent-pools.jsonl')) if r['platform']=='xiaohongshu'}
    ptr=read(pin(TEXT/'当前双平台回复结果指针.json'));side={r['comment_id']:r for r in rows(pin(Path(ptr['platforms']['xiaohongshu']['reply_sidecar_file'])))}
    short=read(pin(TEXT/'pool-mother-review/pool-mother-short-variants.json'))['templates']
    overrides=read(pin(TEXT/'pool-mother-review/approved-mother-overrides-20261101.json'))['templates'];short.update(overrides)
    contract={'families':{k:{'template':v,'required_fill':[f for _,f,_,_ in string.Formatter().parse(v) if f]} for k,v in short.items()}}
    addon=read(pin(TEXT/'pool-mother-review/legacy-combo-families/contract-addon.json'))
    for f in ('combo_available_price','combo_view','combo_location_view'):contract['families'][f]=addon['families'][f]
    rendererpath=pin(TEXT/'douyin-registered-v2/increments/f98cc21138910fb9/batch_short_mothers.py')
    spec=importlib.util.spec_from_file_location('stage_two_existing_renderer',rendererpath);renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
    pin(TEXT/'rules/按池选母句与微调执行方式.json');pin(Path(__file__))
    con=sqlite3.connect((ROOT/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
    ledger={t:list(con.execute('SELECT * FROM '+t+" WHERE platform='xiaohongshu'")) for t in ('reservations','leads','historical_deliveries','identity_aliases')}
    priorplans=[json.loads(x[0]) for x in con.execute("SELECT p.data FROM local_sender_plans p JOIN reservations r ON r.token=p.token WHERE r.platform='xiaohongshu' AND r.status IN ('reserved','unknown','sent')")];con.close()
    blocked_c=set();blocked_id=set();blocked_uid={x['plan']['customer_uid'] for x in priorplans}
    for r in ledger['reservations']:
        if r[4] in ('reserved','unknown','sent'):blocked_c.add(r[2]);blocked_id.add(r[3])
    for r in ledger['leads']:
        if r[3] in ('reserved','unknown','sent'):blocked_c.add(r[1]);blocked_id.add(r[2])
    for r in ledger['historical_deliveries']:
        if r[4]!='not_sent':blocked_c.add(r[1]);blocked_id.add(r[2])
    aliases={r[1]:r[2] for r in ledger['identity_aliases']}
    first_uids={r['customer_uid'] for r in first};selected=set();newrows=[];stamp=dt.datetime.now(dt.timezone.utc)
    appointment_notes={'仅询问能否看房，尚未明确预约时间。','尚未约定具体看房时间。','未明确线下看房或预约时间。','泛询看房，未提出具体预约时间。','未提出具体预约时间。','未明确是否约定线下看房。'}
    for prior in held:
        r=dict(prior);s=side[r['comment_id']];p=pool.get(r['comment_id']);c=p.get('original_classification',{}) if p else s.get('source_record',{}).get('classification',{})
        reasons=[v for v in prior['hold_reasons'] if v not in ('no_complete_bounded_template_match','pool_template_mismatch_or_multiple_pools','unresolved_semantics_or_conditions')]
        family,fill=choose(r['original_comment'],r['demand_pools'] or [])
        reviews=c.get('needs_review') or [];allow_appointment=(family in ('combo_view','combo_location_view') and set(reviews)<=appointment_notes)
        if c.get('other_constraints') or c.get('possible_topics') or c.get('pending_pools') or (reviews and not allow_appointment):reasons.append('existing_semantic_or_fact_review_unresolved')
        if not family:reasons.append('no_complete_bounded_template_match')
        if r['customer_uid'] in first_uids or r['customer_uid'] in selected:reasons.append('customer_already_in_first_or_added_drafts')
        if r['customer_uid'] in blocked_uid or r['customer_id'] in blocked_c or r['customer_uid'] in blocked_c or r['comment_id'] in blocked_id or aliases.get(r['customer_uid']) in blocked_c:reasons.append('latest_ledger_prior_submission_receipt_unknown_or_reservation')
        if s['customer_uid']!=r['customer_uid'] or s['note_id']!=r['note_id'] or s['comment_text']!=r['original_comment'] or sha(s['comment_text'].encode())!=r['comment_sha256']:reasons.append('source_binding_changed')
        if p and (p['comment_text']!=r['original_comment'] or p['customer_uid']!=r['customer_uid'] or sha(dump(c).encode())!=r['classification_sha256']):reasons.append('classification_binding_changed')
        try:
            published=dt.datetime.fromisoformat(r['published_at'].replace('Z','+00:00'))
            if not published.tzinfo or (stamp-published).total_seconds()>60*86400:reasons.append('current_60_day_hold')
        except (TypeError,ValueError,AttributeError):reasons.append('date_unknown')
        original_policy=(s.get('reply_plan') or {}).get('contact_policy','unknown')
        if original_policy in ('no_contact','identity_restricted','manual','manual_review') or s.get('contact_boundaries') or c.get('contact_boundaries') or s.get('source_record',{}).get('blocking_reasons'):reasons.append('existing_contact_or_business_hold')
        text=None;rendered=None
        if not reasons:
            evidence=[{'field':k,'quote':v} for k,v in fill.items()]
            plan={'local_mother':{'family':family,'fill':fill,'evidence':evidence},'tone':'normal','contact_policy':original_policy}
            rendered=renderer.render_plan({'role':c['role'],'demand_state':c['demand_state'],'interest':c['interest'],'reply_plan':plan},r['original_comment'],contract)
            text=rendered['validated_plan_text'] # A draft; do not upgrade unknown contact policy.
            selected.add(r['customer_uid'])
        r.update(status='draft_ready_for_sender_recheck' if text else 'held',text=text,text_sha256=sha(text.encode()) if text else None,
          family=family if text else None,hold_reasons=sorted(set(reasons)),previous_hold_reasons=prior['hold_reasons'],
          prior_package=str(FIRST),local_history_snapshot_at=stamp.isoformat(),stage='bounded_family_expansion_v2',
          literal_fill=fill if text else {},source_contact_policy=original_policy,contact_policy_upgraded=False,
          semantic_review_notes_preserved=reviews,appointment_not_yet_arranged=bool(text and allow_appointment and reviews),
          review_resolution='offer_to_ask_about_appointment_only_no_confirmed_slot' if text and allow_appointment and reviews else None,
          template_source='existing_combo_candidate_locally_reviewed' if text and family.startswith('combo_') else 'existing_short_mother',
          actual_housing_facts_verified=False,factual_scope='offer_to_check_not_assertion_of_inventory_price_location_or_appointment')
        newrows.append(r)
    ready=[r for r in newrows if r['text']]
    assert len(newrows)==430 and len({r['customer_uid'] for r in ready})==len(ready)
    assert not {r['customer_uid'] for r in ready}&first_uids
    for p,h in sourcehash.items():assert sha(Path(p).read_bytes())==h,p
    payload=''.join(dump(r)+'\n' for r in newrows);target=OUT/('expanded-'+sha(payload.encode())[:16]);target.mkdir(exist_ok=False)
    def write(name,txt):
        with (target/name).open('x',encoding='utf-8',newline='\n') as f:f.write(txt)
    write('prior430-dispositions.jsonl',payload);write('added-ready-drafts.jsonl',''.join(dump(r)+'\n' for r in ready));write('remaining-held.jsonl',''.join(dump(r)+'\n' for r in newrows if not r['text']))
    manifest={'created_at':stamp.isoformat(),'source_hashes':sourcehash,'prior137_preserved':True,'input_held':430,'added_ready':len(ready),'remaining_held':430-len(ready),'families':dict(collections.Counter(r['family'] for r in ready)),
      'hold_reason_counts_overlap':dict(collections.Counter(v for r in newrows for v in r['hold_reasons'])),
      'ledger_readonly_snapshot_sha256':sha(dump({'ledger':ledger,'plans':priorplans}).encode()),
      'platform_calls':0,'ledger_writes':0,'AI_reply_rewrites':0,'new_intent_classifications':0,'not_executable_send_queue':True,'runtime_eligibility_not_certified':True,
      'files':{name:sha((target/name).read_bytes()) for name in ('prior430-dispositions.jsonl','added-ready-drafts.jsonl','remaining-held.jsonl')}}
    write('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'directory':str(target),'added':len(ready),'remaining':430-len(ready),'families':manifest['families']},ensure_ascii=False))

if __name__=='__main__':main()
