"""One bounded, explicit read-only reconciliation; no comment POST or retry."""
import importlib.util
import json
import logging
import os
from pathlib import Path
import sys
import uuid
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
HOME = PROJECT / 'work/xhs-standalone-session/huihuijiang-send-20261101-01'
UID = '5f469df5000000000101ec0b'
NOTE = '6ad9e374000000002403ce0a'
TARGET = '6ae21371000000001203577f'
TEXT = '宝宝，我住方隅公寓这边，介绍有优惠的。'
TITLE = '🏡 上海静安寺｜55㎡一室一厅转租，无中介费'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    logging.disable(logging.CRITICAL)
    run = ROOT / 'eighth-readonly-01'
    run.mkdir(exist_ok=False)
    report = {'at': datetime.now(timezone.utc).isoformat(), 'sender_uid': UID,
              'note_id': NOTE, 'target_comment_id': TARGET,
              'comment_post_requests': 0, 'automatic_retry': False,
              'ledger_mutations': 0, 'target_found': False,
              'reply_candidates': [], 'reads': [], 'state': 'not_started'}
    lock = HOME / '.managed-use.lock'
    owner = str(uuid.uuid4())
    client = None
    account = None
    try:
        with lock.open('x', encoding='utf8') as stream:
            stream.write(owner)
        sys.path.insert(0, str(PROJECT / 'work/xhs-new-task-session-fix-20261029'))
        sys.path.insert(0, str(PROJECT / 'work/xhs-send-current-20261029'))
        import integration
        live, account, _, _ = integration.load()
        from readback_client import ReadbackClient

        def observe(response):
            kind = {'/api/sns/web/v2/user/me': 'identity',
                    '/api/sns/web/v1/search/onebox': 'context_prewarm',
                    '/api/sns/web/v1/search/filter': 'context_filter',
                    '/api/sns/web/v1/search/notes': 'single_note_context',
                    '/api/sns/web/v2/comment/page': 'target_comment',
                    '/api/sns/web/v2/comment/sub/page': 'target_replies'}.get(response.request.url.path, 'unexpected')
            report['reads'].append({'endpoint': kind, 'http_status': response.status_code,
                                    'verification_header_present': bool(response.headers.get('verifytype') or response.headers.get('verifyuuid'))})
            if response.status_code in (461, 471, 429) or report['reads'][-1]['verification_header_present']:
                report['read_stop_reason'] = 'platform_verification_or_rate_limit'
                raise RuntimeError('platform_verification_or_rate_limit')

        client = integration.client_factory(UID, delay=3.0)(HOME, run / 'cache')
        client._http.event_hooks['response'].append(observe)
        identity = account.identify(client.get_self_info())
        if identity['uid'] != UID or identity['guest'] is not False:
            raise ValueError('identity_mismatch')
        report['identity_verified'] = True
        report['current_nickname'] = identity.get('nickname')
        result = live.search_without_recommend(client, keyword=TITLE, page=1)
        matches = [x for x in result.get('items', []) if isinstance(x, dict) and x.get('id', x.get('note_id')) == NOTE]
        if len(matches) != 1:
            report['state'] = 'exact_note_context_not_found_in_one_page'
            return
        item = matches[0]
        token = item.get('xsec_token') or item.get('note_card', {}).get('xsec_token')
        if not isinstance(token, str) or not token:
            report['state'] = 'exact_note_context_missing'
            return
        client.close()
        client = ReadbackClient(HOME / '.xiaohongshu-cli/cookies.json', UID, delay=3.0)
        client._http.event_hooks['response'].append(observe)
        client.verify_identity()
        page = client.get_comments(NOTE, xsec_token=token, top_comment_id=TARGET)
        comments = page.get('comments')
        if not isinstance(comments, list):
            raise ValueError('target_page_shape_unknown')
        targets = [x for x in comments if isinstance(x, dict) and x.get('id', x.get('comment_id')) == TARGET]
        if len(targets) != 1:
            report['state'] = 'target_not_found_in_one_targeted_page'
            return
        target = targets[0]
        report['target_found'] = True
        report['target_content'] = target.get('content')
        report['target_subcomment_count'] = target.get('sub_comment_count')
        report['target_user_uid'] = target.get('user_info', {}).get('user_id')
        seen = set()

        def examine(comment, source):
            if not isinstance(comment, dict):
                return
            reply_id = comment.get('id', comment.get('comment_id'))
            if not isinstance(reply_id, str) or reply_id in seen:
                return
            seen.add(reply_id)
            user = comment.get('user_info', comment.get('user', {}))
            sender = user.get('user_id', user.get('userid', user.get('uid'))) if isinstance(user, dict) else None
            if sender != UID:
                return
            target_info = comment.get('target_comment')
            relations = {k: comment[k] for k in ('root_comment_id', 'target_comment_id') if isinstance(comment.get(k), str)}
            if isinstance(target_info, dict):
                relations['target_comment.id'] = target_info.get('id', target_info.get('comment_id'))
            report['reply_candidates'].append({'reply_id': reply_id, 'sender_uid': sender,
                'content': comment.get('content'), 'text_exact': comment.get('content') == TEXT,
                'create_time': comment.get('create_time'), 'relations': relations,
                'source': source, 'current_account_view_only': True})

        for reply in target.get('sub_comments', []):
            examine(reply, 'root_preview')
        pages = 0
        for subpage in client.iter_subcomment_pages(NOTE, TARGET, token, num=30, max_pages=3):
            pages += 1
            for reply in subpage['comments']:
                examine(reply, 'root_bound_subcomments')
            report['subcomments_has_more'] = subpage['has_more']
        report['subcomment_pages'] = pages
        report['state'] = 'bounded_read_complete'
    except Exception as exc:
        report['state'] = 'read_stopped_no_retry'
        report['error_type'] = type(exc).__name__
        code = getattr(exc, 'code', None)
        if type(code) is int:
            report['api_code'] = code
        if client is not None and account is not None:
            detail = account.safe_failure(client, exc)
            report['diagnostic'] = detail
            evidence = getattr(client, 'last_http_evidence', None)
            if isinstance(evidence, dict):
                report['http_evidence'] = evidence
    finally:
        if client is not None:
            client.close()
        try:
            if lock.read_text(encoding='utf8') == owner:
                lock.unlink()
        except OSError:
            pass
        (run / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
        print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
