"""Bounded local transport waiting. Never repeats a dispatched business target."""
import json, os, sqlite3, subprocess, sys, time
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent
STATE=ROOT/'collection-wait-state.json'

def eligible(state,response):
    meta=response.get('transport_meta',{})
    return (state=='unknown' and response.get('ok') is False
            and response.get('transport_error')=='request_timeout'
            and meta.get('stage')=='business' and 'value' not in response
            and any(c.get('stage')=='identity_before' and c.get('uid_matches') is True
                    and c.get('status_code')==0 for c in meta.get('identity_checks',[])))

def decision(state,response,skips):
    return 'manual' if not eligible(state,response) else 'wait' if skips>=3 else 'skip'

def save(value):
    value['updated_at']=datetime.now().astimezone().isoformat()
    temporary=STATE.with_suffix('.tmp');temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temporary,STATE)

def ensure_worker(reset=False):
    from continue_collection import running
    s=json.loads(STATE.read_text(encoding='utf-8')) if STATE.exists() else {}
    if reset:s.update(skips=0,seen=[],mode='monitoring')
    if running(s.get('pid')):
        save(s);return s['pid']
    flags=subprocess.CREATE_NO_WINDOW
    with (ROOT/'collection-wait-worker.log').open('ab') as out:
        p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--watch'],cwd=ROOT,stdout=out,stderr=out,creationflags=flags)
    s['pid']=p.pid;save(s);return p.pid

def watch():
    from continue_collection import read,running,continue_active,DATABASE
    from runner_ledger_adapter import gate
    while True:
        time.sleep(15)
        s=read(STATE);a=read(ROOT/'active-runner.json')
        if s.get('pid')!=os.getpid():return
        if running(a.get('pid')):continue
        if (ROOT/a['directory']/'STOP').exists():s['mode']='user_stopped';save(s);continue
        p=read(ROOT/a['plan']);halt=gate(DATABASE,p['account_uid'],p['scan_id'])['halt']
        if not halt:s['mode']='ordinary_stop';save(s);continue
        with sqlite3.connect(DATABASE) as db:
            row=db.execute('SELECT state,response FROM attempts WHERE request_id=?',(halt['request_id'],)).fetchone()
        if not row:s['mode']='needs_review';save(s);continue
        response=json.loads(row[1]);action=decision(row[0],response,s.get('skips',0))
        if action=='manual':s['mode']='platform_or_identity_review';save(s);continue
        # Strict route, exact same account, loaded page and no challenge iframe.
        check=subprocess.run(['node','collection_identity_check.cjs',a['plan'],str(ROOT.parent.parent/'抖音自用采集台/data/bridge.json')],cwd=ROOT,capture_output=True,timeout=55,creationflags=subprocess.CREATE_NO_WINDOW)
        if check.returncode:
            s['mode']='waiting_for_user_check';save(s);time.sleep(45);continue
        if action=='wait':
            s['mode']='waiting_for_connection';save(s);time.sleep(45);continue
        event=halt['request_id']
        if event in s.get('seen',[]):s['mode']='waiting_for_connection';save(s);continue
        s['skips']=s.get('skips',0)+1;s.setdefault('seen',[]).append(event);s['mode']='recovering_connection';save(s)
        result=continue_active(event,source='local_bounded_timeout_recovery')
        s=read(STATE);s['last_result']=result;save(s)

if __name__=='__main__':
    while True:
        try:
            watch();break
        except Exception as error:
            try:
                s=json.loads(STATE.read_text(encoding='utf-8'));s.update(mode='waiting_for_connection',local_error_type=type(error).__name__);save(s)
            except Exception:pass
            time.sleep(60)
