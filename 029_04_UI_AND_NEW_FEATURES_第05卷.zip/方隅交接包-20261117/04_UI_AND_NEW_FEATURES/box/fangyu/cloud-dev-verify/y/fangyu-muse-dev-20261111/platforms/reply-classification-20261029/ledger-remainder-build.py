"""Offline coverage audit for ledger comments absent from both snapshots."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, importlib.util, json, re, sqlite3

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
LEDGER=ROOT/'work/shared-acquisition-ledger/shared.sqlite3'
TOPIC=ROOT/'work/xhs-topic-pool-spike-v2/topic_candidate.py'
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sanitize(x):
    if isinstance(x,dict):return {k:sanitize(v) for k,v in x.items() if k.lower() not in ('reply','draft') and not re.search(r'cookie|token|authorization|credential|secret|password',k,re.I)}
    if isinstance(x,list):return [sanitize(v) for v in x]
    if isinstance(x,str):return re.sub(r'https?://[^\s"<>]+',lambda m: re.split(r'[?#]',m.group(0),1)[0],x)
    return x
spec=importlib.util.spec_from_file_location('topic',TOPIC);topic=importlib.util.module_from_spec(spec);spec.loader.exec_module(topic)
old={c['original_fields'].get('comment_id') for line in (OUT/'old-snapshot.jsonl').open(encoding='utf8') for c in json.loads(line)['comments'] if c['original_fields'].get('comment_id')}
new={json.loads(line)['comment_id'] for line in (OUT/'new-snapshot.jsonl').open(encoding='utf8')}
with sqlite3.connect(LEDGER.as_uri()+'?mode=ro',uri=True) as db:
    db.row_factory=sqlite3.Row
    records={r['comment']:dict(r) for r in db.execute('select platform,customer,comment,status,source from leads') if r['comment'] not in old|new}
    uidmap={r['canonical']:r['platform_uid'] for r in db.execute('select canonical,platform_uid from collection_uid_observations')}
obs=defaultdict(dict); assessments=defaultdict(dict); fields=('customer_id','customer_uid','comment_id','note_id','comment_text','parent_text','parent_comment_id','parent_relationship','post_title','post_text','published_at','missing_context','identity_evidence','context_missing')
def addrow(row,path):
    if not isinstance(row,dict) or row.get('comment_id') not in records:return
    item=sanitize({k:row[k] for k in fields if k in row}); key=json.dumps(item,ensure_ascii=False,sort_keys=True)
    k=hashlib.sha256(key.encode('utf8')).hexdigest();o=obs[row['comment_id']].setdefault(k,{'data':item,'sources':[]});o['sources'].append(str(path))
paths={Path(r['source'][len('collection:'):]) for r in records.values() if r['source'].startswith('collection:')}
paths|={ROOT/'work/xhs-context-controlled/work/live-20261028-larger-43/ai-input.json',ROOT/'work/xhs-continuous-runner/work/live-20261028-sample/batch-0001/context-and-ai/ai-input.json'}
for path in sorted(paths):
    if not path.exists():continue
    x=load(path);items=x.get('customers',[]) if isinstance(x,dict) else x
    if not isinstance(items,list):continue
    for parent in items:
        if not isinstance(parent,dict):continue
        addrow(parent,path)
        for child in parent.get('other_comments',[]) or []:
            if not isinstance(child,dict):continue
            merged={k:parent[k] for k in ('customer_id','customer_uid','note_id','post_title','post_text') if k in parent};merged.update(child);addrow(merged,path)
paths_analysis=set()
for pattern in ('work/xhs*/**/analysis.json','work/xhs*/**/validated.json'):
    paths_analysis.update(ROOT.glob(pattern))
read_errors=[]
for path in sorted(paths_analysis):
    try:x=load(path)
    except (OSError, ValueError) as exc:read_errors.append({'path':str(path),'error':type(exc).__name__});continue
    if isinstance(x,dict):x=x.get('items',[])
    if not isinstance(x,list):continue
    for a in x:
        if not isinstance(a,dict) or not isinstance(a.get('result'),dict):continue
        cid=a.get('comment_id') or a['result'].get('target_comment_id')
        if cid not in records:continue
        clean=sanitize(a);key=hashlib.sha256(json.dumps(clean,sort_keys=True,ensure_ascii=False).encode('utf8')).hexdigest()
        e=assessments[cid].setdefault(key,{'analysis':clean,'sources':[]});e['sources'].append(str(path))
output=[]
for cid,r in sorted(records.items()):
    observations=list(obs.get(cid,{}).values()); versions=list(assessments.get(cid,{}).values())
    texts=sorted({o['data'].get('comment_text','') for o in observations if o['data'].get('comment_text')})
    interests=sorted({v['analysis']['result'].get('interest','unknown') for v in versions})
    output.append({'comment_id':cid,'platform':r['platform'],'customer_id':r['customer'],
      'uid_from_local_observation':uidmap.get(r['customer']), 'ledger_status':r['status'],'ledger_source':r['source'],
      'input_observations':observations,'comment_text_variants':texts,
      'topic_candidates_by_text':[topic.classify({'source_comment_id':cid,'text':t})['topic_analysis'] for t in texts],
      'analysis_versions':versions,'analysis_found':bool(versions),'interest_versions':interests,
      'interest_conflict':len(interests)>1,'snapshot_high_or_super_high':bool({'high','super_high'}&set(interests)),
      'context_status':{'text_found':bool(texts),'post_title_found':any(o['data'].get('post_title') for o in observations),
        'post_body_found':any(o['data'].get('post_text') for o in observations),'parent_text_found':any(o['data'].get('parent_text') for o in observations),
        'uid_found':any(o['data'].get('customer_uid') for o in observations) or r['customer'] in uidmap,
        'multiple_texts':len(texts)>1},'classification_status':'词面候选，待语义及上下文复核',
      'eligible_to_reply':False})
summary={'ledger_comments_not_in_snapshots':len(records),'analysis_files_checked':len(paths_analysis),'analysis_read_errors':read_errors,
  'text_found':sum(r['context_status']['text_found'] for r in output),
  'post_title_found':sum(r['context_status']['post_title_found'] for r in output),
  'post_body_found':sum(r['context_status']['post_body_found'] for r in output),
  'parent_text_found':sum(r['context_status']['parent_text_found'] for r in output),
  'uid_found':sum(r['context_status']['uid_found'] for r in output),
  'analysis_found':sum(r['analysis_found'] for r in output),'no_analysis_found':sum(not r['analysis_found'] for r in output),
  'high_comments_any_version':sum(r['snapshot_high_or_super_high'] for r in output),
  'high_customers_any_version':len({r['customer_id'] for r in output if r['snapshot_high_or_super_high']}),
  'interest_values':dict(Counter(i for r in output for i in r['interest_versions'])),
  'interest_conflicts':sum(r['interest_conflict'] for r in output),
  'multiple_texts':sum(r['context_status']['multiple_texts'] for r in output),
  'missing_text':sum(not r['context_status']['text_found'] for r in output),
  'topic_rule_version':topic.RULE_VERSION,'topic_semantics':'仅词面候选，不等于语义判断或可回复资格；无分析不等于无意向',
  'platform_calls':0,'source_or_ledger_writes':0,'automatic_drafts':0}
with (OUT/'ledger-remainder.jsonl').open('x',encoding='utf8',newline='\n') as f:
    for r in output:f.write(json.dumps(r,ensure_ascii=False)+'\n')
with (OUT/'ledger-remainder-summary.json').open('x',encoding='utf8',newline='\n') as f:f.write(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=True,indent=2))
