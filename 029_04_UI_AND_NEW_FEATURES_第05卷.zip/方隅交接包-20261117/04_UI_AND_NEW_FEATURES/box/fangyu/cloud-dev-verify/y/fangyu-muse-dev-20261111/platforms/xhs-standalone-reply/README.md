# 独立小红书单条回复适配器

## 楼中楼参数兼容候选（2026-10-28）

`subcomments_compat.py` 按已有上游 PR 81 适配记录传入原帖访问上下文、图片格式和分页字段；必须由调用者提供禁止重试的客户端，函数遇平台验证直接向上抛出，不清除挑战、不重放请求。`test_subcomments_compat.py` 离线验证参数、缺上下文拒绝及异常不重试。此文件尚未接入真实命令或平台验证，不证明其解决本次平台限制。历史上同类兼容参数也曾遇到 HTTP 461；不得为测试候选绕过验证或反复请求。

这是独立调用现有 xhs_cli 的候选工具，不导入原软件、不连接原软件会话、不调用原软件许可。只有共享获客台账协议被复用；本目录没有修改台账程序、表结构或生产数据库。

## 验证结果

先编写测试并观察独立实现缺失而失败，再实现。会话隔离与跨进程账号锁、命令预览均先观察缺失测试失败再实现。16项测试已覆盖：实际安装 XhsClient 的身份与回复接口、精确正文和目标、严格 granted=true、UID不符不发、未核其他历史阻断、timeout/302/429/500/502/503/504单次POST后unknown、再次禁止、HOME双变量、不同进程账号锁、不同进程竞争同一台账仅一个授权、默认预览不联网。外部HTTP采用合成 MockTransport，测试进程 socket.connect 阻断。所有台账数据为临时合成数据。

运行全部本目录测试：

```powershell
& 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest discover -s 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-reply' -v
```

## 审阅与真实调用边界

`standalone_reply.py --plan <JSON路径>` 默认预览，不读取会话、不打开台账、不访问平台。JSON字段为 sender_uid、customer_uid、note_id、comment_id、text、attempt_id、authorized、verification_evidence、valid_until、source。authorized必须是JSON布尔true；valid_until必须为未来5分钟内的Unix秒。它们必须来自用户明确授权及真实核验，示例或人工文字不能冒充平台证据。正文、发送账号、客户平台UID、评论及笔记必须同时精确核对。

真实调用另需 `--execute --session-home <独立会话目录>`，且进程HOME、USERPROFILE两个环境变量都指向该目录。仅直接读取该目录下现有 xhs_cli 会话，不自动提取浏览器、不自动刷新、不复制旧会话。首次登录由独立登录流程完成，本适配器不负责获取或迁移凭据。

真实执行前必须核实所有相关账号历史、客户身份映射、目标原评论和回复、门店匹配及最新平台状态，并在共享台账按协议准备。适配器不会自动清除历史、审核客户或伪造核验。台账预留不是平台发送授权。生产台账路径固定为项目 work/shared-acquisition-ledger/shared.sqlite3。

## 真实缺口

未真实登录、发送或核验平台可见回复；签名、身份响应和HTTP均仅离线合成。目标客户与评论实时回读目前依赖操作者真实核验记录，没有自动平台回读功能。收到非空回复ID也只记 receipt_received，并保守写入共享台账unknown，待独立平台证据确认；不会自动重试/解除。

账号互斥覆盖本目录适配器的合作进程；不约束原软件、原CLI直接命令、其他脚本或其他电脑。共享台账只拦截实际采用它的发送链路，历史导入是快照，不能称全局防重或原软件同步已生效。禁止复制台账另开实例。任何异常或中断保留台账reserved/unknown阻断，不因超时自动解锁。

## 独审修订：精确授权绑定

首版仅比较plan与client.plan，不能防止入口JSON同时改变两者。独审已定位该缺口；修订测试先复现失败，再实施关闭策略。

正式执行现在要求共享台账assessment在人工核验后独立保存以下扩展字段（不修改台账结构）：

- `reply_binding`：`platform`固定为`xiaohongshu`，加plan完整原值，包括发送账号、客户平台UID、笔记、评论、正文、尝试编号、source、明确授权、核验依据和5分钟内有效期限。
- `verification_facts`：sender_uid、customer_uid、note_id、comment_id、source与plan精确相同；all_account_history_checked、target_and_peer_replies_checked、user_authorized均严格为JSON布尔true。
- assessment原有draft必须等于精确正文，source必须等于plan新增source；筛选必须仍为rental/match/none。review操作者不能为空，review证据必须等于plan核验依据，并且review在5分钟内。

这些字段必须先由实际人工核实与授权准备，再执行既有assess和review。发送入口绝不自动生成、补齐或覆写这些证据。空字段、旧候选缺少新绑定、只有plan里写authorized=true，都拒绝发送。

预留前读取check核对，预留后立即再次读取check并比较完整快照，仅容许该目标由reviewed转为reserved。发生改变时不会发送POST，预留保留为unknown。真实入口JSON改变正文、账号、客户、笔记、评论、尝试编号、来源、证据或有效期均有隔离测试覆盖；客户端与plan一起构造也不能绕过独立台账绑定。

该绑定防止意外偏离已存审核事实，不把人工声明变成自动平台核验，也不能防止具有台账写权限的人恶意重写全部证据。真实目标回读与授权事实仍须真实取得。


最终POST传输分支会在签名和台账复查完成后立即再次验证有效期；复查等待跨过期限也禁止实际POST，预留保守记unknown。已用第二次check后模拟时间越界的回归测试复现旧缺陷并验证修复。

