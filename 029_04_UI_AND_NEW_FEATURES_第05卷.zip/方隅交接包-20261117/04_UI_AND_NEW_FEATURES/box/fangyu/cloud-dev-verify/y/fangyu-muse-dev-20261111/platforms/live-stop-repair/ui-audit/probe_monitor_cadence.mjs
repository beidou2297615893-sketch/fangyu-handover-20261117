import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const H=path.dirname(fileURLToPath(import.meta.url)),file='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview/platform-notice.mjs';
const source=fs.readFileSync(file,'utf8'),sha=crypto.createHash('sha256').update(source).digest('hex');
const {createCollectionMonitor}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const make=(id,status)=>({actor:{username:'employee',storeId:'store'},acquisition:{taskId:id,status,taskScope:{platform:id==='xhs-task'?'xiaohongshu':'douyin'}}});
const state={connection:'connected',session:{},user:'employee',storeId:'store',authEpoch:1,page:'acquire',activePlatform:'douyin',platform:make('dy-task','completed'),platformWorkspaces:{xiaohongshu:{platform:make('xhs-task','running')}}};
let now=0,next=1,reads=0;const tasks=new Map();
const schedule=(fn,ms)=>{const id=next++;tasks.set(id,{fn,due:now+ms});return id;};const cancel=id=>tasks.delete(id);
async function advance(ms){const end=now+ms;while(true){const ready=[...tasks].sort((a,b)=>a[1].due-b[1].due).find(([id,t])=>t.due<=end);if(!ready)break;now=ready[1].due;tasks.delete(ready[0]);await ready[1].fn();}now=end;}
const monitor=createCollectionMonitor({state,read:async()=>{reads++;const p=make('xhs-task','failed');p.acquisition.platformError={category:'verification_required'};return{platform:p};},changed:()=>{},schedule,cancel});
monitor.sync();await advance(3500);monitor.sync();await advance(1500);
const report={status:reads===0?'REPRODUCED_MONITOR_CADENCE_STARVATION':'CADENCE_ALREADY_FIXED',module_sha256:sha,read_calls_by_original_5000ms:reads,next_due:[...tasks.values()].map(t=>t.due),UI_operations:0,platform_requests:0,model_requests:0,product_edits:0};
fs.writeFileSync(path.join(H,'MONITOR-CADENCE-BASELINE.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
