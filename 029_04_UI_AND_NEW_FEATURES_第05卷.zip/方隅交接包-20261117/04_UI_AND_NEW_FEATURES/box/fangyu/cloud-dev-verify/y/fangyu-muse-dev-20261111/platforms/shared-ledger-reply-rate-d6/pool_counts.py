"""Pure display-only customer-set aggregation; never changes ledger records."""
def count_pool(customers, records):
    universe={str(x) for x in customers if x}
    states={}
    for customer,status in records:
        customer=str(customer or '')
        if customer not in universe:continue
        states.setdefault(customer,set()).add(str(status))
    result={'valid':0,'sent':0,'unknown':0,'reserved':0,'failed':0}
    for customer in universe:
        s=states.get(customer,set())
        # Any unresolved attempt excludes the customer even if another record is sent.
        if 'unknown' in s: key='unknown'
        elif 'reserved' in s:key='reserved'
        elif 'sent' in s:key='sent'
        elif s.intersection({'not_sent','failed','failure','rejected'}):key='failed'
        else:key='valid'
        result[key]+=1
    result['pending']=result['valid']
    return result
