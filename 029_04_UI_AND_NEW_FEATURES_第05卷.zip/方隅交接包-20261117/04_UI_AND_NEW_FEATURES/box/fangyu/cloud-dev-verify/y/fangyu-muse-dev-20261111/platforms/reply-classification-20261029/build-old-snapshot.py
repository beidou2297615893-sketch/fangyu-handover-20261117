"""Read-only export of historical backup into local topic candidates; no drafts."""
from __future__ import annotations
import collections
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone

sys.dont_write_bytecode = True
root = pathlib.Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统')
source = root / 'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'
classifier_path = root / 'work/xhs-topic-pool-spike-v2/topic_candidate.py'
out = root / 'work/reply-classification-20261029'
spec = importlib.util.spec_from_file_location('topic_candidate_readonly', classifier_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def scrub(value):
    """Drop URL query/fragment and redact credential-shaped keys or parameters."""
    if isinstance(value, dict):
        return {k: ('[敏感字段已移除]' if re.search(r'token|cookie|authorization|password|secret|signature|xsec|session', k, re.I) else scrub(v)) for k,v in value.items()}
    if isinstance(value, list):
        return [scrub(v) for v in value]
    if isinstance(value, str):
        def clean_url(match):
            url = match.group(0)
            return url.split('?', 1)[0].split('#', 1)[0]
        value = re.sub(r'https?://[^\s<>"\']+', clean_url, value, flags=re.I)
        return re.sub(r'(?i)\b(?:[\w-]*(?:token|cookie|authorization|password|secret|signature|xsec|session)[\w-]*)\s*[:=]\s*[^\s&,;]+', '[敏感参数已移除]', value)
    return value

conn = sqlite3.connect(source.as_uri() + '?mode=ro&immutable=1', uri=True)
leads = [scrub(json.loads(body)) for (body,) in conn.execute("SELECT body FROM records WHERE entity='leads'")]
projections = [scrub(json.loads(body)) for (body,) in conn.execute("SELECT body FROM records WHERE entity='customer_intent_projection_v1'")]
conn.close()
by_id = {lead['id']: lead for lead in leads}
assert len(by_id) == len(leads) == 3069
assert len({p['customer_id'] for p in projections}) == len(projections) == 1869
member_ids = [m['lead_id'] for p in projections for m in p['members']]
assert len(member_ids) == len(set(member_ids)) == 3069
assert set(member_ids) == set(by_id)
assert len({str(x['author_id']) for x in leads}) == 1869

comment_fields = ('id','platform','source_id','comment_id','parent_id','comment_level',
    'note_url','url','text','title','content_title','parent_text','published_at',
    'content_published_at','comment_time_evidence','region','content_region',
    'grade','system_grade','manual_grade','ai_intent','analysis_status',
    'verification_status','reply_status','created_at','updated_at')
results = []
comment_topic_counts = collections.Counter()
customer_topic_counts = collections.Counter()
counts = collections.Counter()
review_reasons = collections.Counter()
seen_uids = set()
for projection in sorted(projections, key=lambda x: x['customer_id']):
    members = [by_id[m['lead_id']] for m in projection['members']]
    uids = {str(x.get('author_id') or '') for x in members}
    assert len(uids) == 1 and '' not in uids
    uid = next(iter(uids))
    assert uid not in seen_uids
    seen_uids.add(uid)
    customer = projection['customer']
    interest_high = customer.get('interestLevel') == 'high'
    comments = []
    all_topics = set()
    gaps = {'无评论原文': 0, '二级评论缺父评论原文': 0, '缺帖子标题': 0,
            '缺评论时间证据': 0, '缺帖子发布时间': 0}
    for lead in members:
        text = lead.get('text') or ''
        inp = {'source_comment_id': str(lead['id']), 'text': text,
               'parent_id': str(lead.get('parent_id') or ''),
               'parent_text': lead.get('parent_text') or '',
               'post_title': lead.get('content_title') or '',
               'published_at': lead.get('published_at')}
        topic = module.classify(inp)['topic_analysis']
        all_topics.update(topic['topics'])
        comment_topic_counts.update(topic['topics'])
        review_reasons.update(topic['review_reasons'])
        counts['comments'] += 1
        counts['comments_no_topic_keyword'] += not topic['topics']
        counts['comments_multitopic'] += len(topic['topics']) > 1
        counts['classifier_flagged_comments'] += bool(topic['review_reasons'])
        gaps['无评论原文'] += not bool(text.strip())
        gaps['二级评论缺父评论原文'] += bool(lead.get('parent_id')) and not bool((lead.get('parent_text') or '').strip())
        gaps['缺帖子标题'] += not bool((lead.get('content_title') or '').strip())
        gaps['缺评论时间证据'] += not bool(lead.get('comment_time_evidence'))
        gaps['缺帖子发布时间'] += not bool(lead.get('content_published_at'))
        comments.append({'original_fields': {k: lead.get(k) for k in comment_fields},
                         'topic_candidate': topic})
    customer_topic_counts.update(all_topics)
    counts['customers'] += 1
    counts['high_interest_customers'] += interest_high
    counts['high_interest_comments'] += len(members) if interest_high else 0
    counts['customers_multitopic'] += len(all_topics) > 1
    counts['customers_no_topic_keyword'] += not all_topics
    for k,v in gaps.items(): counts['gap_comments_'+k] += v
    results.append({'snapshot_source':'2026-10-27客户资料备份',
        'customer_id': projection['customer_id'], 'platform_uid': uid,
        'platform': projection.get('platform'),
        'observed_high_interest': interest_high,
        'store_high_match': customer.get('level') == 'high',
        'projection_original': projection,
        'candidate_topics_union': sorted(all_topics),
        'comment_count': len(comments), 'context_gap_counts': gaps,
        'post_body_available': False,
        'review_state': '全部候选需结合原始上下文及账号状态人工语义核对；非回复名单',
        'comments': comments})

assert len(results) == 1869 and counts['comments'] == 3069
assert counts['high_interest_customers'] == 157 and counts['high_interest_comments'] == 242
payload = ''.join(json.dumps(r, ensure_ascii=False, separators=(',', ':')) + '\n' for r in results)
summary = {'source': str(source), 'source_sha256': sha256(source),
    'classifier_path': str(classifier_path), 'classifier_sha256': sha256(classifier_path),
    'classifier_version': module.RULE_VERSION, 'generated_at': datetime.now(timezone.utc).isoformat(),
    'counts': dict(counts), 'topic_comment_hits': dict(comment_topic_counts),
    'topic_customer_hits': dict(customer_topic_counts), 'classifier_review_reasons': dict(review_reasons),
    'validation': {'customer_unique': True, 'uid_unique': True, 'member_comment_unique': True,
        'all_leads_covered': True, 'per_customer_single_uid': True},
    'limits': ['仅评论自身词面命中，父评论和标题保留但未参与分类',
        '未做语义审核，词面命中不是确认需求，漏词未命中不代表没有需求',
        '旧157高意向是历史模型投影，不代表当前仍求租或可回复',
        '不把帖子地点视为本人需求地区，评论时间和帖子时间独立',
        '无帖子正文；人工核对否定、供给、已结束、身份、地区与时间',
        'URL查询串与片段、敏感字段与参数已移除；原始资料仍在受保护备份',
        '未生成回复、未发送、未采集、未修改来源数据库'],
    'data_sha256': hashlib.sha256(payload.encode('utf-8')).hexdigest()}
out.mkdir(parents=True, exist_ok=True)
assert not re.search(r'xsec_token|(?:token|cookie|authorization|password|secret|signature|xsec|session)\s*=', payload, re.I)
with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',newline='\n',dir=out,delete=False) as f:
    f.write(payload)
    data_temp = pathlib.Path(f.name)
with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',newline='\n',dir=out,delete=False) as f:
    json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
    summary_temp = pathlib.Path(f.name)
os.replace(data_temp, out/'old-snapshot.jsonl')
os.replace(summary_temp, out/'old-summary.json')
print(json.dumps({'counts':dict(counts),'topics':dict(comment_topic_counts)},ensure_ascii=False))
