"""Exactly frozen 137 new-tone targets, qualified by the actual cat receipt."""
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import scoped_isolation as scope
import tone_singleton as cat

BATCH_SHA = 'b917d138480f94da77b64d8a0e498d47690aef42c253bb9a8ea6b6a9e2e316ba'
TONE_SHA = '37974faa24bb75b1af0acbb07d6c6609d263ac83ae2746ce73985eb79a3b677a'
READY_SHA = '61375f53c6fdb66ac187bccf4023629b1541d66ae157d15fb9de38260564394e'
PROOF_RECORD_SHA = 'a49315e49cd529af87eba3fb522a28aafc282950a56f41b0d9f4ea560a0ce3b6'
PROOF_RECEIPT = '6ae6fc4d0000000014030b57'
PROOF_EVENT_SHA = 'b20bac9f56bcb0891a783a0b6d2fe306c8a272eb56e450d5437ef078aff7930d'


@dataclass(frozen=True)
class NewToneBatchReceiptPolicy:
    schema: str
    policy_id: str
    sender_uid: str
    original_batch_path: str
    original_batch_sha256: str
    batch_sha256: str
    tone_approval_path: str
    tone_approval_sha256: str
    exclusion_manifest_path: str
    exclusion_manifest_sha256: str
    isolated_attempts: list
    platform_state_path: str
    platform_state_sha256: str
    halt_marker_path: str
    halt_marker_sha256: str
    revocation_path: str
    revocation_sha256: str
    proof_attempt_id: str
    proof_record_raw_sha256: str
    proof_receipt_id: str
    proof_event_path: str
    proof_event_sha256: str

    @classmethod
    def from_mapping(cls, value):
        if (not isinstance(value, dict) or set(value) != set(cls.__dataclass_fields__) or
            not isinstance(value.get('isolated_attempts'), list) or
            any(not isinstance(v, str) or not v for k, v in value.items() if k != 'isolated_attempts')):
            raise scope.ScopeRefused('tone_batch_schema_invalid')
        return cls(**value)

    def validate_context(self, batch_path, sender_uid):
        if Path(__file__).with_name("retired-historical-scopes.json").exists():
            raise scope.ScopeRefused("historical_scope_retired_after_retention_cleanup")
        fixed = {'schema':'xhs-two-unknown-new-tone-137-qualified-v1',
            'policy_id':'huihui-new-tone-137-cat-receipt-qualified-20261101-v1','sender_uid':scope.SCOPED_UID,
            'original_batch_sha256':scope.APPROVED_SHA,'batch_sha256':BATCH_SHA,'tone_approval_sha256':TONE_SHA,
            'exclusion_manifest_sha256':cat.EXCLUSION_SHA,'proof_attempt_id':cat.ALLOWED_ATTEMPT,
            'proof_record_raw_sha256':PROOF_RECORD_SHA,'proof_receipt_id':PROOF_RECEIPT,'proof_event_sha256':PROOF_EVENT_SHA}
        if sender_uid != scope.SCOPED_UID or any(getattr(self,k) != v for k,v in fixed.items()):
            raise scope.ScopeRefused('tone_batch_binding_invalid')
        if (Path(self.revocation_path).resolve() != scope.revocation_path(self.halt_marker_path).resolve() or
            scope.revocation_path(self.revocation_path).exists() or scope.revocation_path(self.revocation_path).is_symlink()):
            raise scope.ScopeRefused('tone_batch_revoked')
        halted = []
        for path,sha in ((self.platform_state_path,self.platform_state_sha256),
            (self.halt_marker_path,self.halt_marker_sha256),(self.revocation_path,self.revocation_sha256)):
            state = scope.checked_json(path,sha)
            if (state.get('sender_uid') != sender_uid or state.get('state') != 'unknown_requires_reconciliation' or
                state.get('cleared') is not False or scope.known_restriction(state)):
                raise scope.ScopeRefused('tone_batch_has_restriction')
            halted.append(state)
        isolated = {e['attempt_id']:(e['record_raw_sha256'],e['customer_uid'],e['comment_id']) for e in self.isolated_attempts}
        if len(self.isolated_attempts) != 2 or isolated != cat.ISOLATED:
            raise scope.ScopeRefused('tone_batch_isolation_invalid')
        original = scope.checked_json(self.original_batch_path,self.original_batch_sha256)
        batch = scope.checked_json(batch_path,self.batch_sha256)
        approval = scope.checked_json(self.tone_approval_path,self.tone_approval_sha256)
        if (original.get('count') != 567 or len(original.get('rows',[])) != 567 or batch.get('count') != 137 or
            len(batch.get('rows',[])) != 137 or batch.get('schema') != 'xhs-local-plan-v1' or
            batch.get('intended_account_uid') != sender_uid or approval.get('schema') != 'xhs-approved-tone-entry-v1' or
            len(approval.get('entries',[])) != 137 or approval.get('source_sha256') != READY_SHA):
            raise scope.ScopeRefused('tone_batch_shape_invalid')
        raw = Path(approval['source']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != READY_SHA:raise scope.ScopeRefused('tone_batch_candidates_changed')
        ready = [json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
        def index(rows):
            result = {r['comment_id']:r for r in rows}
            if len(result) != len(rows):raise scope.ScopeRefused('tone_batch_duplicate_target')
            return result
        originals, tones, candidates = index(original['rows']), index(approval['entries']), index(ready)
        if len({r['customer_uid'] for r in batch['rows']}) != 137 or set(index(batch['rows'])) != set(tones) or set(tones) != set(candidates):
            raise scope.ScopeRefused('tone_batch_target_set_changed')
        for target in batch['rows']:
            comment = target['comment_id']
            if comment not in originals or any(target.get(k) != originals[comment].get(k) for k in ('customer_id','customer_uid','comment_id','note_id')):
                raise scope.ScopeRefused('tone_batch_outside_original_targets')
            if any(target.get(k) != source.get(k) for source in (tones[comment],candidates[comment])
                   for k in ('customer_id','customer_uid','comment_id','note_id','text')):
                raise scope.ScopeRefused('tone_batch_text_or_identity_changed')
        exclusions = scope.checked_json(self.exclusion_manifest_path,self.exclusion_manifest_sha256)
        entries = exclusions.get('entries',[])
        if (exclusions.get('sender_uid') != sender_uid or len(entries) != 22 or len({e['attempt_id'] for e in entries}) != 22 or
            sum(e.get('state') == 'accepted' for e in entries) != 20 or
            {e['attempt_id'] for e in entries if e.get('state') == 'unknown'} != set(cat.ISOLATED) or
            any(r['customer_uid'] == e['customer_uid'] or r['comment_id'] == e['comment_id'] for r in batch['rows'] for e in entries)):
            raise scope.ScopeRefused('tone_batch_exclusions_invalid')
        for key,expected in (('original_batch',self.original_batch_sha256),('tone_approval',self.tone_approval_sha256),('exclusions',self.exclusion_manifest_sha256)):
            if batch.get('source_sha256',{}).get(key) != expected:raise scope.ScopeRefused('tone_batch_sources_changed')
        event = scope.checked_json(self.proof_event_path,self.proof_event_sha256); d = event.get('diagnostic',{})
        if (event.get('event') != 'accepted' or event.get('sender_uid') != sender_uid or event.get('attempt_id') != self.proof_attempt_id or
            event.get('receipt_id') != self.proof_receipt_id or d.get('success') is not True or d.get('http_status') != 200 or
            d.get('api_code') != 0 or d.get('verification_header_present') is not False or scope.known_restriction(d)):
            raise scope.ScopeRefused('tone_batch_proof_invalid')
        proof_time = datetime.fromisoformat(event['at'].replace('Z','+00:00'))
        if proof_time.tzinfo is None or any(proof_time <= datetime.fromisoformat(s['halted_at'].replace('Z','+00:00')) for s in halted):
            raise scope.ScopeRefused('tone_batch_proof_not_after_halt')
        return batch['rows'],entries

    def validate_ledger(self, db, plan, batch_path):
        try:
            rows,entries = self.validate_context(batch_path,plan.sender_uid)
            matched = [r for r in rows if r['attempt_id'] == plan.attempt_id]
            if len(matched) != 1 or any(matched[0].get(k) != getattr(plan,f) for k,f in (
                ('attempt_id','attempt_id'),('customer_id','canonical_customer'),('customer_uid','customer_uid'),
                ('comment_id','comment_id'),('note_id','note_id'),('text','text'))):return False
            if not cat.validate_excluded_records(db,entries,self.sender_uid):return False
            proof = db.execute('SELECT r.status,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token '
                'WHERE r.token=? AND r.platform=?',(self.proof_attempt_id,'xiaohongshu')).fetchone()
            if not proof or proof['status'] not in ('unknown','sent') or hashlib.sha256(proof['data'].encode()).hexdigest() != self.proof_record_raw_sha256:return False
            record = json.loads(proof['data']); p = record.get('plan',{}); result = record.get('result',{})
            cat_rows = [r for r in rows if r['comment_id'] == cat.TARGET_COMMENT]
            return (len(cat_rows) == 1 and p.get('sender_uid') == self.sender_uid and p.get('attempt_id') == self.proof_attempt_id and
                result.get('kind') == 'platform_receipt' and result.get('receipt_id') == self.proof_receipt_id and
                all(cat_rows[0].get(k) == p.get(f) for k,f in (('customer_id','canonical_customer'),('customer_uid','customer_uid'),
                    ('comment_id','comment_id'),('note_id','note_id'),('text','text'))))
        except (scope.ScopeRefused,OSError,ValueError,TypeError,KeyError,AttributeError):return False

    def permits(self, plan, old_row, batch_path, *, db=None):
        return (db is not None and old_row['token'] in cat.ISOLATED and self.validate_ledger(db,plan,batch_path) and
            old_row['status'] == 'unknown' and hashlib.sha256(old_row['data'].encode()).hexdigest() == cat.ISOLATED[old_row['token']][0])
