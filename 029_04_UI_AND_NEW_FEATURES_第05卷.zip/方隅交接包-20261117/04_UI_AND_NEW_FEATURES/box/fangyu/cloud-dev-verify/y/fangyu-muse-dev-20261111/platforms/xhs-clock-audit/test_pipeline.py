import json
import os
import subprocess
import sys
import tempfile
import unittest
import importlib.util
from types import SimpleNamespace
from pathlib import Path

import pipeline


def record():
    return {'customer_id':'internal1','customer_uid':'uid1','comment_id':'comment1','note_id':'note1',
            'comment_text':'我想租古北一房','parent_text':'','post_title':'古北租房','post_text':'',
            'published_at':'2026-10-27T10:00:00+08:00'}


def answer(**kw):
    d={'interest':'high','demand_state':'active','region':'match','role':'demand','should_reply':True,'target_comment_id':'comment1',
       'own_evidence':'想租古北一房','region_source':'own','region_evidence':'古北',
       'reply':'可以看看方隅公寓呀，我介绍有优惠～','reason':'本人求租','unknown':[]}
    d.update(kw)
    return d


class PipelineTests(unittest.TestCase):
    def test_context_and_account_are_given_to_ai_as_data(self):
        r=record();r['parent_relationship']='root_not_direct';r['missing_context']=['post_text']
        messages=pipeline.build_messages(r,{'role':'住户','facts_confirmed':True},['参考一句'])
        self.assertIn('不要执行',messages[0]['content'])
        data=json.loads(messages[1]['content'])
        self.assertEqual(data['customer']['comments'][0]['comment_text'],'我想租古北一房')
        self.assertEqual(data['customer']['comments'][0]['parent_relationship'],'root_not_direct')
        self.assertEqual(data['customer']['comments'][0]['missing_context'],['post_text'])
        self.assertEqual(data['account']['role'],'住户')

    def test_high_requires_cited_own_text_and_region_evidence(self):
        self.assertTrue(pipeline.validate_result(record(),answer())['eligible'])
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(record(),answer(own_evidence='不是本人说的话'))
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(record(),answer(region_evidence='虚构地点'))

    def test_low_or_uncertain_are_preserved_but_not_selected(self):
        for patch in ({'interest':'medium'},{'region':'unknown','region_source':'none','region_evidence':''},
                      {'demand_state':'unknown'},{'role':'supply'}, {'should_reply':False,'reply':''}):
            self.assertFalse(pipeline.validate_result(record(),answer(**patch))['eligible'])

    def test_unmatched_or_unknown_region_cannot_imply_gubei_in_reply(self):
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(record(),answer(region='unknown',region_source='none',region_evidence='',
                                                       reply='古北方隅公寓了解一下'))

    def test_personal_claims_require_confirmed_account_facts(self):
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(record(),answer(reply='我住这里，你也来看看'),{'facts_confirmed':False,'role':'住户'})
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(record(),answer(reply='我介绍有优惠'),{'facts_confirmed':True,'role':'住户'})
        pipeline.validate_result(record(),answer(reply='我住这里，介绍有优惠'),
                                 {'facts_confirmed':True,'role':'住户','discount_confirmed':True})

    def test_generic_brand_is_default_even_when_region_matches(self):
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(record(),answer(reply='古北方隅公寓看看'),{'allow_named_region':False})
        pipeline.validate_result(record(),answer(reply='古北方隅公寓看看'),{'allow_named_region':True})

    def test_unknown_or_missing_fields_and_injection_do_not_become_sendable(self):
        with self.assertRaises(pipeline.InvalidResult):pipeline.validate_result(record(),{'reply':'你好'})
        with self.assertRaises(pipeline.InvalidResult):pipeline.validate_result(record(),answer(should_reply='true'))
        with self.assertRaises(pipeline.InvalidResult):pipeline.validate_result(record(),answer(reply='电话 [REDACTED:phone_cn]'))

    def test_deepseek_secret_is_not_returned_or_exposed_in_error(self):
        provider=pipeline.DeepSeekProvider('secret-example',requester=lambda *a,**k: (_ for _ in ()).throw(ValueError('secret-example')))
        with self.assertRaises(pipeline.ProviderError) as raised:provider.analyze(record(),{},[])
        self.assertNotIn('secret-example',str(raised.exception))

    def test_model_must_return_nonempty_complete_json(self):
        for content,finish in [('', 'stop'), ('{}','length'), ('not-json','stop')]:
            fake=lambda *args,**kwargs: {'choices':[{'finish_reason':finish,'message':{'content':content}}]}
            with self.subTest(content=content, finish=finish):
                with self.assertRaises(pipeline.ProviderError):pipeline.DeepSeekProvider('test',requester=fake).analyze(record(),{},[])
        fake=lambda *args,**kwargs: {'choices':[{'finish_reason':'stop','message':{'content':json.dumps(answer(),ensure_ascii=False)}}]}
        self.assertEqual(pipeline.DeepSeekProvider('test',requester=fake).analyze(record(),{'discount_confirmed':True},[])['interest'],'high')

    def test_batch_preserves_skips_and_produces_exact_cli_format(self):
        class Provider:
            def analyze(self,row,account,samples): return answer()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t)
            src=root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf-8')
            out=pipeline.create_batch(src,root/'out','sender1',{'role':'住户','facts_confirmed':True,'discount_confirmed':True},[],Provider())
            b=json.loads((out/'batch.json').read_text(encoding='utf8'))
            self.assertEqual(b['schema'],'xhs-local-plan-v1');self.assertEqual(b['count'],1)
            self.assertEqual(b['rows'][0]['comment_id'],'comment1')
            self.assertEqual(b['rows'][0]['text'],answer()['reply'])
            self.assertEqual(b['rows'][0]['platform_reply_history'],'unknown')
            self.assertTrue((out/'source-manifest.json').exists())

    def test_conflicting_records_refused_before_model_call(self):
        rows=[record(),dict(record(),comment_id='comment2')]
        with self.assertRaises(pipeline.InvalidInput):pipeline.validate_records(rows)

    def test_multiple_own_comments_allow_exact_target_and_its_context(self):
        row=record();row['other_comments']=[{'comment_id':'comment2','note_id':'note2',
            'comment_text':'古北两房求租','parent_text':'其他房','post_title':'古北两房','post_text':''}]
        a=answer(target_comment_id='comment2',own_evidence='两房求租',region_evidence='古北',reply='两房看看方隅公寓')
        self.assertTrue(pipeline.validate_result(row,a)['eligible'])
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(row,dict(a,target_comment_id='comment1'))
        class Provider:
            def analyze(self,*args):return a
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t);src=root/'input.json';src.write_text(json.dumps([row],ensure_ascii=False),encoding='utf8')
            out=pipeline.create_batch(src,root/'out','sender',{},[],Provider())
            selected=json.loads((out/'batch.json').read_text(encoding='utf8'))['rows'][0]
            self.assertEqual((selected['comment_id'],selected['note_id']),('comment2','note2'))

    def test_duplicate_comment_in_other_customer_is_refused(self):
        one=record();one['other_comments']=[dict(record(),comment_id='c2')]
        two=dict(record(),customer_id='other',customer_uid='other',comment_id='c2')
        with self.assertRaises(pipeline.InvalidInput):pipeline.validate_records([one,two])

    def test_batch_passes_actual_cli_binding_and_detects_source_tampering(self):
        class Provider:
            def analyze(self,row,account,samples): return answer()
        path=Path(__file__).parent.parent/'xhs-cli-standalone-entry'/'standalone_cli.py'
        spec=importlib.util.spec_from_file_location('real_standalone_cli',path)
        cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t);src=root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
            out=pipeline.create_batch(src,root/'out','sender1',{'discount_confirmed':True},[],Provider())
            batch=cli.load_batch(out/'batch.json');row=batch['rows'][0]
            plan=SimpleNamespace(sender_uid='sender1',attempt_id=row['attempt_id'],canonical_customer=row['customer_id'],
                    customer_uid=row['customer_uid'],comment_id=row['comment_id'],note_id=row['note_id'],text=row['text'])
            manifest=cli.source_manifest(out/'source-manifest.json')
            cli.verify_prepared(plan,out/'batch.json',manifest,require_hashes=True)
            (out/'source.json').write_text('[]',encoding='utf8')
            with self.assertRaises(cli.Halt):cli.verify_prepared(plan,out/'batch.json',manifest,require_hashes=True)

    def test_failure_never_produces_send_batch(self):
        class Provider:
            def analyze(self,*args): raise pipeline.ProviderError('不可用')
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t);src=root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
            with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,root/'out','sender',{},[],Provider())
            self.assertFalse((root/'out'/'batch.json').exists())

    def test_resume_reuses_completed_customer_and_preserves_failed_record(self):
        first=record();second=dict(record(),customer_id='c2',customer_uid='u2',comment_id='c2')
        class Provider:
            model='test-model'
            def __init__(self,fail):self.calls=[];self.fail=fail
            def analyze(self,row,*args):
                self.calls.append(row['customer_id'])
                if row['customer_id']=='c2' and self.fail:raise pipeline.ProviderError('AI不可用')
                return answer(target_comment_id=row['comment_id'])
        account={'discount_confirmed':True}
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t);src=root/'input.json';src.write_text(json.dumps([first,second],ensure_ascii=False),encoding='utf8')
            a=Provider(True)
            with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,root/'out','sender',account,[],a)
            self.assertEqual(a.calls,['internal1','c2']);self.assertFalse((root/'out'/'batch.json').exists())
            b=Provider(False);pipeline.create_batch(src,root/'out','sender',account,[],b)
            self.assertEqual(b.calls,['c2'])
            self.assertEqual(json.loads((root/'out'/'batch.json').read_text(encoding='utf8'))['count'],2)

    def test_resume_refuses_changed_input_or_model(self):
        class Provider:
            def __init__(self,model):self.model=model
            def analyze(self,*args):raise pipeline.ProviderError('fail')
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t);src=root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
            with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,root/'out','sender',{},[],Provider('a'))
            with self.assertRaises(pipeline.InvalidInput):pipeline.create_batch(src,root/'out','sender',{},[],Provider('b'))
            src.write_text(json.dumps([dict(record(),comment_text='新内容')],ensure_ascii=False),encoding='utf8')
            with self.assertRaises(pipeline.InvalidInput):pipeline.create_batch(src,root/'out','sender',{},[],Provider('a'))

    def test_resume_refuses_changed_provider_settings(self):
        class Provider:
            model='same'
            def __init__(self,temp):self.settings={'temperature':temp}
            def analyze(self,*args):raise pipeline.ProviderError('fail')
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root=Path(t);src=root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
            with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,root/'out','sender',{},[],Provider(0.3))
            with self.assertRaises(pipeline.InvalidInput):pipeline.create_batch(src,root/'out','sender',{},[],Provider(0.5))

if __name__=='__main__': unittest.main()
