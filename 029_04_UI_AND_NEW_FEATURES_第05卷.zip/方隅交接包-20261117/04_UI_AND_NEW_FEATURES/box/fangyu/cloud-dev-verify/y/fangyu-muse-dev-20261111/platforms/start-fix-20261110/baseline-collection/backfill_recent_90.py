"""Admit eligible comments from original recent-policy receipts without a platform request."""
import argparse
import datetime
import json
from contextlib import closing
from pathlib import Path

from ledger import Ledger, RECENT_VERSION, SHANGHAI, encoded, recent_time, shared_duplicates
from runner_ledger_adapter import Cache, collection_accounts


def backfill(journal, plan, observed_at):
    accounts = collection_accounts(plan)
    cache = Cache(journal.path)
    with closing(cache.db):
        cache.sync()
        previous = cache.qualified(plan)
    remaining = max(0, plan['target_comments'] - previous)
    totals = dict(qualified_before=previous, inspected_pages=0, days_31_to_60=0, days_61_to_90=0, deduplicated=0)
    observed_at = observed_at.astimezone(SHANGHAI)
    with journal._db() as db:
        db.execute('BEGIN IMMEDIATE')
        rows = db.execute("""SELECT a.request_id,a.spec,a.response FROM attempts a
            JOIN recent_comment_page_counts c ON c.request_id=a.request_id
            WHERE a.state='parsed' AND a.detail NOT LIKE 'identical prior comment page%'
            AND json_extract(a.spec,'$.recent_collection.version')=? ORDER BY a.rowid""", (RECENT_VERSION,))
        for row in rows:
            if not remaining:
                break
            spec = json.loads(row['spec'])
            if spec['account_uid'] not in accounts:
                continue
            totals['inspected_pages'] += 1
            original_at = datetime.datetime.fromisoformat(spec['recent_collection']['observed_at']).astimezone(SHANGHAI)
            items = json.loads(row['response'])['value'].get('comments') or []
            candidates = []
            for item in items:
                original = recent_time(item, original_at)
                if original is None or not 31 <= original[0] <= 90:
                    continue
                current = recent_time(item, observed_at)
                if current is not None and 31 <= current[0] <= 90:
                    candidates.append((current, item))
            shared = shared_duplicates(journal.shared_ledger, tuple(sorted({item['cid'] for _, item in candidates})))
            for (age, _), item in sorted(candidates, key=lambda candidate: candidate[0][1], reverse=True):
                cid = item['cid']
                if cid in shared or db.execute('SELECT 1 FROM entities WHERE stable_key=?', ('comment:' + cid,)).fetchone():
                    totals['deduplicated'] += 1
                    continue
                if not remaining:
                    break
                at = observed_at.isoformat()
                db.execute('INSERT OR IGNORE INTO items VALUES(?,?,?,?,?,?)',
                           ('comment:' + spec['target'] + ':' + cid, 'comments', cid, spec['target'], spec['request_id'], encoded(item)))
                journal._observe(db, spec, cid, item, at)
                db.execute('INSERT INTO recent_comment_backfill VALUES(?,?,?,?,?)',
                           (spec['request_id'], cid, spec['account_uid'], age, at))
                totals['days_31_to_60' if age <= 60 else 'days_61_to_90'] += 1
                remaining -= 1
    cache = Cache(journal.path)
    with closing(cache.db):
        cache.sync()
        totals['qualified_after'] = cache.qualified(plan)
    totals['added'] = totals['days_31_to_60'] + totals['days_61_to_90']
    return totals


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--active', type=Path, required=True)
    args = parser.parse_args()
    active = json.loads(args.active.read_text(encoding='utf-8-sig'))
    root = args.active.resolve().parent
    plan = json.loads((root / active['plan']).read_text(encoding='utf-8-sig'))
    plan['qualification_policy'] = json.loads((root / active['qualification_policy']).read_text(encoding='utf-8-sig'))
    print(json.dumps(backfill(Ledger(root / 'runtime' / 'collection.sqlite3'), plan,
                              datetime.datetime.now(datetime.timezone.utc))))
