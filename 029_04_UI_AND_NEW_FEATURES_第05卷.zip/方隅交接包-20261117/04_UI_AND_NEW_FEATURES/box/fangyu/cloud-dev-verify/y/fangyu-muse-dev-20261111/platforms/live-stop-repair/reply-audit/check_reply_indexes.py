"""Compare old/new real reply read bodies with the same in-memory records."""
from pathlib import Path
from types import SimpleNamespace,MethodType
from copy import deepcopy
from collections import Counter
import ast,hashlib,json,threading,sys
from datetime import datetime,timezone
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
F=P/'work/parallel-integration-20261018/final-integration'
old=F/'candidate-unified-v17/project/work/ui-native-r57/reply_workbench.py'
new=F/'stage-02/project/work/ui-native-r57/reply_workbench.py'
O=Path(__file__).resolve().parent
class CoreError(ValueError):pass
class Error(ValueError):
    def __init__(self,code,message,status=400):self.code,self.status=code,status;super().__init__(message)
def fail(code,message,status=400):raise Error(code,message,status)
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def snapshot(core,reply,lead,account,user=None):return {'lead':lead['id'],'account':account['id']}
def load(path,permissions):
    tree=ast.parse(path.read_text('utf-8-sig'));cl=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ReplyWorkbench')
    methods=[n for n in cl.body if isinstance(n,ast.FunctionDef) and n.name in ('read','_latest','_public')]
    for fn in methods:fn.decorator_list=[]
    def permission(core,actor,lead,reply):
        permissions.append(lead['id'])
        if lead.get('denied'):raise CoreError('isolated permission denied')
    space={'CoreError':CoreError,'fail':fail,'digest':digest,'snapshot':snapshot,'require_reply_permission':permission,'ENTITY':'ui_reply_requests_v1'}
    exec(compile(ast.Module(body=methods,type_ignores=[]),str(path),'exec'),space);return space
def run(path,variant='standard'):
    actor={'id':'user','tenant_id':'tenant','username':'worker','role':'operator'};public={'username':'worker','storeId':'store'}
    leads=[{'id':key,'platform':'xiaohongshu','source_type':'comment','text':'isolated '+key} for key in ('A','B','C')]
    leads[2]['denied']=True
    accounts=[{'id':'ok','platform':'xiaohongshu','store_id':'store','name':'Allowed'},
        {'id':'unassigned','platform':'xiaohongshu','name':'Unassigned'},
        {'id':'other-owner','platform':'xiaohongshu','name':'Forbidden'},
        {'id':'other-store','platform':'xiaohongshu','store_id':'other-store','name':'OtherStore'},
        {'id':'dy','platform':'douyin','store_id':'store','name':'OtherPlatform'}]
    replies=[{'id':'draft-A1','lead_id':'A','version':1,'status':'draft','text':'old','author_id':'user'},
        {'id':'approved-A2','lead_id':'A','version':2,'status':'approved','text':'approved','author_id':'user','review_account_id':'ok','approval_snapshot':{'lead':'A','account':'ok'}},
        {'id':'draft-C1','lead_id':'C','version':1,'status':'draft','text':'foreign draft','author_id':'other-author'},
        {'id':'irrelevant-invalid','lead_id':'not-selected','version':0,'status':'draft','author_id':'other-author'}]
    receipts=[{'owner':'worker','storeId':'store','customerId':'customer','leadId':'B','requestId':'pending-B','state':'submitted'},
        {'owner':'worker','storeId':'store','customerId':'customer','state':'accepted','action':'reply_review','reply':{'id':'approved-A2'},'intent':{'sourceDigest':digest(leads[0])}},
        {'owner':'other-worker','storeId':'store','customerId':'customer','leadId':'A','requestId':'forbidden','state':'submitted'}]
    if variant=='bad-version':replies[0]['version']=0
    if variant=='version-tie':replies.append({'id':'zzz-A2','lead_id':'A','version':2,'status':'draft','text':'new tie','author_id':'user'})
    if variant=='wrong-approved-account':replies[1]['review_account_id']='other-owner'
    if variant=='non-comment':leads[1]['source_type']='note'
    if variant=='mixed-notice':leads[0]['post_date_status']='verified';leads[1]['post_date_status']='unverified'
    if variant=='empty':leads=[]
    by_entity={'leads':leads,'accounts':accounts,'replies':replies,'ui_reply_requests_v1':receipts};reads=Counter();permissions=[];account_checks=[]
    def listing(entity,tenant):assert tenant=='tenant';reads[entity]+=1;return deepcopy(by_entity.get(entity,[]))
    def get(entity,ident,tenant):
        assert tenant=='tenant'
        return deepcopy(next(row for row in by_entity[entity] if row['id']==ident))
    def account_access(actor,account):
        account_checks.append(account['id'])
        if account['id']=='other-owner':raise CoreError('isolated account forbidden')
    core=SimpleNamespace(lock=threading.RLock(),store=SimpleNamespace(list=listing),_get=get,_account_access=account_access,_reply_recipient=lambda *a,**kw:None)
    item={'id':'customer','name':'isolated'};person={'comments':[{'lead_id':row['id'],'text':row['text'],'published_at':'','note_url':''} for row in leads]}
    obj=SimpleNamespace(core=core,customers=SimpleNamespace(_media_url=lambda store,lead,kind:f'/isolated-media/{store}/{lead}/{kind}'),_context=lambda *a,**kw:(actor,public,deepcopy(item),deepcopy(person)))
    methods=load(path,permissions);obj._latest=MethodType(methods['_latest'],obj);obj._public=methods['_public']
    try:result=methods['read'](obj,actor,'store','customer',platform='xiaohongshu')
    except Error as error:result={'error':error.code,'status':error.status}
    return result,dict(reads),permissions,account_checks
if __name__=='__main__':
    results=[]
    for variant in ('standard','bad-version','version-tie','wrong-approved-account','non-comment','empty'):
        try:
            before,old_reads,old_permissions,old_accounts=run(old,variant);after,new_reads,new_permissions,new_accounts=run(new,variant)
            assert before==after,'Public result differs from v17'
            assert old_permissions==new_permissions,'Per-lead permission checks differ'
            assert new_reads.get('replies',0)==1 and new_reads.get('accounts',0)==1
            if variant=='standard':
                comments=after['comments'];assert comments[0]['reviewCurrent'];assert comments[1]['pendingRequestId']=='pending-B';assert comments[2]['draft'] is None
                assert all(a['id'] not in ('other-owner','other-store','dy') for c in comments for a in c['accounts'])
            results.append({'name':variant,'status':'PASS','old_store_reads':old_reads,'new_store_reads':new_reads})
        except Exception as error:results.append({'name':variant,'status':'FAIL','error':str(error)})
    report={'status':'PASS_REPLY_INDEX_EQUIVALENCE' if all(r['status']=='PASS' for r in results) else 'FAIL_REPLY_INDEX_EQUIVALENCE','at_utc':datetime.now(timezone.utc).isoformat(),'checks':len(results),'passed':sum(r['status']=='PASS' for r in results),'results':results,'source_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'real_HTTP_requests':0,'actual_core_imported':False,'production_writes':0,'UI_operations':0,'test_kind':'Old and new actual read bodies on identical synthetic records, no business success claim'}
    (O/'REPLY-INDEX.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(0 if report['status'].startswith('PASS') else 1)
