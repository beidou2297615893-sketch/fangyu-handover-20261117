# 停止提醒与只读进度窗：候选验收记录

本轮仅完成独立候选代码与离线验证。没有启动平台登录、采集、回复发送、真实通知、声音或图形窗口；没有修改现用程序、任务、账本或会话。系统桌面通知能否实际看见、声音能否实际听见、窗口视觉效果均待本人验收。

## 接口

```python
notifier = Notifier(candidate_state_root, backend=fake_backend_for_offline_tests)
alert = notifier.emit(event_id, lane, reason, action, details=None)
state = notifier.snapshot()
notifier.acknowledge(event_id)       # 仅已读，不放行、不清空、不恢复任何任务
notifier.retry_delivery(event_id)    # 仅明确投递失败时可显式重试通知
```

- `backend(alert)` 是可调用对象；正常返回代表通知已提交，抛出普通异常代表提交失败。离线测试必须注入 fake，不能省略 backend。
- `event_id` 必须由监督器为一次停止产生稳定唯一值，同一次停止重复轮询保持不变，不同停止不要共用值。`lane` 可用“采集”“回复”；`reason`、`action` 应写人话，例如“账号需要验证，回复已停止”“过验证后按启动”“换号后按启动”“待核对，未知记录不重发”。
- 返回项含 `event_id/lane/reason/action/details/created_at/acknowledged/delivery_status/delivery_error/attempts/severity`。`delivery_status=submitted` 仅代表系统API提交成功；不证明人已经看见或听见。`failed` 为投递失败，`unknown` 为投递未完成或崩溃中断待核对。
- `failed/unknown` 应在控制器与进度窗继续醒目显示；不要把 `submitted` 错标为失败。SQLite或快照持久化错误直接抛出，不能吞掉。

候选状态目录内创建 `notification-alerts.sqlite3` 作为事件防重真源，另原子写入 `alerts.json` 供只读进度窗。重开不清旧告警，重复ID不重新通知，已读仍保留停止原因。投递前先持久化为unknown，崩溃恢复不自动重播未知投递；业务中的未知发送结果始终由控制器单独保留，本模块不改业务账本。

## 进度窗

`progress_view.py` 的 `load_view(root)` 可离线读取而不打开窗口。图形入口只有显式运行 `python progress_view.py --root <候选状态目录>` 才打开，**本轮未运行此入口**。

只读窗读取 `root/controller-status.json` 与 `root/alerts.json`，每两秒刷新一次，不启动或操作任何平台任务。控制器数据格式：

```json
{"schema":1,"lanes":{"collect":{"status":"stopped","uid":"示例账号","today_sent":0,"success":0,"failed":0,"unknown":0,"reason":"需要验证","action":"过验证后按启动"},"send":{"status":"paused","today_sent":0,"success":0,"failed":0,"unknown":0,"reason":"已暂停","action":"按启动"}}}
```

显示采集/回复状态、UID、今日已发、成功/失败/未知、停止原因与下一步，以及历史红色告警和通知失败。读不到文件或文件损坏时明确红色提示，不能伪装成任务正常。当前无生产adapter，始终禁用“启动/继续”，显示“候选未安装到现用任务”。没有写控制请求、恢复任务、放行未知或静默清理告警的功能。

## 系统通知边界

已检查项目现有方式：`Codex获客工作台/work/launch.py` 使用标准库 `ctypes.windll.user32.MessageBoxW`；`work/build-tools/installer.py` 使用系统 `WScript.Shell`。没有找到可以直接复用且包含持久防重、失败回执与重启恢复的通知模块，因此补齐这一薄层，不引入第三方依赖。

默认Windows后端只调用本机PowerShell内置WinRT toast与系统通知声；失败后尝试系统WScript定时弹窗和SystemSounds声音。没有网络访问、安装、提权、改代理或注册表操作。参数使用UTF-16LE编码脚本，不用shell拼接执行业务内容；提示文本另经UTF-8 base64 JSON传递。凭据字段及典型凭据片段打码。

两次调用各最多1.4秒，合计目标约2.8秒；fallback弹窗仅停留1秒，真正持久的停止提醒在红色进度窗和本地文件中。慢电脑启动PowerShell可能超时，届时明确failed，不能假装送达。进程创建/系统调度开销不构成严格实时上界。通知不应在业务发送事务锁内执行。

系统静音、免打扰、关闭通知、无人登录桌面、桌面会话断开等会影响实际可见/可听结果；API提交成功不能等同本人确认。工作进程消失由独立监督器检测并调用emit；若监督器也被关闭、整机断电或系统崩溃，无法保证当场弹窗，重开后保留已有停止/未知记录，不能承诺绝对即时通知。

## 离线验收

使用 `test-driven-development` 流程先红后绿，日志为 `red-notifications.txt` 与 `green-notifications.txt`。最终14项通过：先持久再投递、跨重启防重、并发同事件只投递一次、失败可见且不自动重发、显式失败通知重试、崩溃未知不重播、已读不清停止记录、独立停止事件、输入校验、凭据打码、Windows双路径fake-runner与投递时限、只读窗数据/按钮边界、文件缺失或损坏可见。

全部Windows调用均为fake runner；没有实际弹窗、发声或启动PowerShell通知。全部UI验证为headless数据模型验证，没有假称真实桌面界面已验收。测试均使用隔离临时状态，不接触生产账本。
