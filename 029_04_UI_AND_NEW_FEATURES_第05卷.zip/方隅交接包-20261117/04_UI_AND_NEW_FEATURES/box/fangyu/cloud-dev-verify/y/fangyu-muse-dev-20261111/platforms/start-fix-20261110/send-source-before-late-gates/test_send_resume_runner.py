"""Exercise a copy of the real batch loop. The adapter and ledger are local fakes."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import startup_recovery

WORK=next(p for p in Path(__file__).resolve().parents if p.name=='work')
SCRIPTS=('batch_reply_runner.py','send_cli_once.cjs','resume_after_confirmation.py')
class RunnerTests(unittest.TestCase):
    def run_batch(self, outcomes, *, preflight=False):
        source=WORK/'douyin-local-20261104-40aaf15b06'
        with tempfile.TemporaryDirectory() as tmp, contextlib.ExitStack() as stack:
            taskdir=Path(tmp)
            for name in SCRIPTS: (taskdir/name).write_bytes((source/name).read_bytes())
            startup_recovery.upgrade_task(taskdir)
            spec=importlib.util.spec_from_file_location('fixture_runner',taskdir/SCRIPTS[0])
            r=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(r)
            items=[{'cid':str(i+10),'uid':str(i+100),'video':'99','created':'x','draft':'fixture',
                    'text':'fixture','reply_priority':{'time_band':'x','key':[]}} for i,_ in enumerate(outcomes)]
            manifest={'live_preflight':preflight,'prepared_by':'douyin-classification-ready-v1','items_sha256':'x',
                      'source_output_sha256':'x','priority_queue_sha256':'x'}
            (taskdir/'q').write_text(json.dumps(manifest))
            (taskdir/'captcha-recovery-authorization.json').write_text('{}')
            rows=[]; published=[]; reads=[]
            def record(t,status,result):
                rows[:]=[x for x in rows if x['comment']!=t['comment_id']]
                rows.append(dict(comment=t['comment_id'],status=status,token=t['attempt_id'],customer=t['customer']))
            def adapter(args,**kw):
                if args[-1]=='--identity':return {'verified':True,'account_uid':r.ACCOUNT}
                if '--preflight' in args:
                    incomplete=outcomes[int(args[-1])-10]=='preflight_skip'
                    return dict(status='target_check',diagnosis=dict(read_timeout=incomplete,detail_status=0,
                                 comments_status=0,video_present=True,target_present=not incomplete))
                if '--verify-own-reply' in args:
                    cid=args[-1]; reads.append(cid)
                    if outcomes[int(cid)-10]=='visible':
                        diagnosis={'own_reply_state':'found','own_reply':dict(cid='222',reply_id=cid,text='fixture',sec_uid=r.ACCOUNT)}
                    else:diagnosis={'own_reply_state':'not_found','check_complete':True,'target_present':True}
                    return dict(status='own_reply_check',submission_attempted=False,diagnosis=diagnosis)
                if Path(args[1]).name=='prepare_verified.py':
                    cid,uid=args[2:4]
                    (taskdir/(cid+'.json')).write_text(json.dumps({'comment_id':cid,'customer':uid,
                        'attempt_id':r.PREFIX+cid,'video_id':'99','account_uid':r.ACCOUNT,'reply':{'draft_text':'fixture'}}))
                    return dict(reserved=True)
                cid=Path(args[-1]).stem
                assert cid not in published
                published.append(cid)
                (taskdir/(cid+'.json.submitted')).write_text('now')
                outcome=outcomes[int(cid)-10]
                if outcome=='sent':return dict(status='sent',receipt=dict(status_code=0,reply_id=cid,cid='333',
                                          text='fixture',sec_uid=r.ACCOUNT))
                if outcome=='timeout':return dict(status='unknown',error='Request timeout after 15 seconds')
                if outcome=='challenge':return dict(status='not_sent',error='CURRENT_GATE:captcha')
                return dict(status='unknown',error='需要检查验证码或其他平台提示',receipt=dict(status_code=3002123))
            for name,val in dict(QUEUE=taskdir/'q',run_json=adapter,require_send_allowed=lambda:None,
                      ledger_rows=lambda:list(rows),record_outcome=record,validate_queue=lambda *a:items).items():
                stack.enter_context(patch.object(r,name,val))
            err=None
            try:
                with contextlib.redirect_stdout(io.StringIO()):r.execute()
            except RuntimeError as e: err=str(e)
            return published,reads,rows,json.loads((taskdir/'captcha-recovery-authorization.json').read_text()),err
    def test_single_denial_and_verified_success_continue(self):
        published,reads,rows,auth,err=self.run_batch(['deny','visible','sent'])
        self.assertIsNone(err)
        self.assertEqual(published,['10','11','12'])
        self.assertEqual(reads,['10','11'])
        self.assertEqual(auth['preserve_unknown_comments'],['10'])
        self.assertEqual([r['status'] for r in rows],['unknown','sent','sent'])
    def test_consecutive_count_resets_on_success(self):
        pub,_,_,_,err=self.run_batch(['deny']*8+['sent']+['deny']*12+['sent'])
        self.assertEqual(len(pub),21)
        self.assertIn('连续12条',err)
    def test_isolated_submit_timeout_uses_fresh_read(self):
        pub,reads,_,auth,err=self.run_batch(['timeout','sent'])
        self.assertIsNone(err)
        self.assertEqual((pub,reads,auth['preserve_unknown_comments']),(['10','11'],['10'],['10']))
    def test_preflight_skips_share_limit_and_success_resets(self):
        pub,_,_,_,err=self.run_batch(['preflight_skip']*8+['sent']+['preflight_skip']*11+['deny','sent'],preflight=True)
        self.assertEqual(pub,['18','30'])
        self.assertIn('连续12条',err)
    def test_live_challenge_stops_immediately(self):
        pub,_,_,_,err=self.run_batch(['challenge','sent'])
        self.assertEqual(pub,['10'])
        self.assertIn('验证',err)
