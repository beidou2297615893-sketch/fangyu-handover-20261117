"""Offline reconciliation of one confirmed null/zero/finished comment page."""
import datetime, json, pathlib, sqlite3
from ledger import Ledger

ROOT = pathlib.Path(__file__).resolve().parent
REQUEST = '94e46849-204c-4db4-8fdf-acea80dc3ef6'

def main():
    dbpath = ROOT/'runtime/collection.sqlite3'
    directory = ROOT/'runner-live-v2'
    controlpath = directory/'control.json'
    controlraw = controlpath.read_bytes()
    control = json.loads(controlraw)
    assert control.get('pending') is None and control.get('stopped') == 'ledger_invalid_response'
    assert not list(ROOT.glob('runner-lease-*')) and not (directory/'STOP').exists()
    backup = ROOT/('terminal-null-recovery-backup-'+REQUEST)
    backup.mkdir(exist_ok=False)
    (backup/'control.json').write_bytes(controlraw)
    with sqlite3.connect(dbpath) as db, sqlite3.connect(backup/'collection.sqlite3') as dst:
        db.backup(dst)
    with sqlite3.connect(dbpath) as db:
        db.row_factory = sqlite3.Row
        h = db.execute('SELECT * FROM account_halts').fetchall()
        assert len(h) == 1 and h[0]['request_id'] == REQUEST and h[0]['state'] == 'invalid_response'
        r = db.execute('SELECT * FROM attempts WHERE request_id=?',(REQUEST,)).fetchone()
        assert r['state'] == 'invalid_response' and r['added'] == 0
        spec, response = json.loads(r['spec']), json.loads(r['response'])
        v = response['value']
        assert response.get('ok') is True and response.get('connection') == spec['connection_id']
        assert v.get('status_code') == 0 and 'comments' in v and v['comments'] is None
        assert type(v.get('total')) is int and v['total'] >= 0 and v.get('has_more') == 0
        assert spec['kind'] == 'comments'
        raw = json.loads((directory/(REQUEST+'.json')).read_text(encoding='utf8'))
        assert raw == dict(spec=spec,response=response)
        assert Ledger(dbpath)._parse(spec,response)[0] == 'parsed'
        db.execute('BEGIN IMMEDIATE')
        assert db.execute('SELECT request_id FROM account_halts WHERE account_uid=?',(spec['account_uid'],)).fetchone()[0] == REQUEST
        db.execute('INSERT INTO recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) VALUES(?,?,?,?,?,?)',
          (spec['account_uid'],REQUEST,'Codex本地返回核验','成功终止页：null/total非负/has_more=0；声明的评论数量可能包含不可见项，仅记录已返回0条；只解析已保存响应，无网络请求；原异常保留。','用户明确要求核查后继续采集',datetime.datetime.now(datetime.timezone.utc).isoformat()))
        db.execute('DELETE FROM account_halts WHERE account_uid=? AND request_id=?',(spec['account_uid'],REQUEST))
        db.commit()
    # A crash before control reset leaves collection stopped for reconciliation.
    derived = dict(spec,request_id='local-empty-reconciliation-'+REQUEST,
                   derived_from_request_id=REQUEST,reconciliation='offline_saved_response_only_no_network')
    record = dict(spec=derived,response=response)
    (directory/(derived['request_id']+'.json')).write_text(json.dumps(record,ensure_ascii=False),encoding='utf8')
    receipt = Ledger(dbpath).ingest(derived,response)
    assert receipt['state'] == 'parsed' and receipt['added'] == 0
    (directory/(derived['request_id']+'.receipt.json')).write_text(json.dumps(receipt),encoding='utf8')
    assert controlpath.read_bytes() == controlraw
    control['stopped'] = None
    temp = directory/'control.empty-recovery.tmp'
    temp.write_text(json.dumps(control,ensure_ascii=False),encoding='utf8')
    temp.replace(controlpath)
    print(json.dumps(dict(state='saved_empty_page_reconciled',network_requests=0,original_attempt_preserved=True)))

if __name__ == '__main__':
    main()
