"""Real media method and inheritance bodies with memory-only authority/HTTP fakes."""
from pathlib import Path
from types import SimpleNamespace
from copy import deepcopy
import ast,hashlib,json,re,threading,time
from datetime import datetime,timezone
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
N=S/'work/ui-native-r57';O=Path(__file__).resolve().parent
backend_source=(N/'workbench_backend.py').read_bytes();tree=ast.parse(backend_source.decode('utf-8-sig'))
class IntegrationError(ValueError):pass
class WorkbenchError(ValueError):
    def __init__(self,code,message='',status=400):self.code,self.status=code,status;super().__init__(message)
def extract(name,method=None):
    klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
    return klass if method is None else next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name==method)
base_tree=ast.parse((S/'work/ui-runtime-r55/src/integrations.py').read_text('utf-8-sig'))
base=next(n for n in base_tree.body if isinstance(n,ast.ClassDef) and n.name=='Integrations')
base.body=[n for n in base.body if isinstance(n,ast.FunctionDef) and n.name in ('__init__','_cloud')]
net=[];profile={}
def request_json(endpoint,payload,token):
    net.append({'operation':payload['operation'],'token_supplied':bool(token)})
    return {'contract':'fangyu-workspace-v1','environment_id':'isolated-env','company_id':'fangyu-apartment-client','user':deepcopy(profile)}
space={'Path':Path,'threading':threading,'time':time,'deepcopy':deepcopy,'IntegrationError':IntegrationError,'_classify_cloud_failure':lambda error:error,'request_json':request_json,'re':re,'STORE_ID':re.compile('[A-Za-z0-9_-]{1,80}\\Z'),'WorkbenchError':WorkbenchError}
nodes=[base]+[extract(name) for name in ('_ProfileIntegrations','_ReadOnlyDeliveryIntegrations','_MediaReadIntegrations')]+[extract('WorkbenchBackend','media')]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'isolated-media-real-bodies','exec'),space)
Verifier=space['_MediaReadIntegrations'];media=space['media'];results=[]
def check(name,fn):
    try:fn();results.append({'name':name,'status':'PASS'})
    except Exception as error:results.append({'name':name,'status':'FAIL','error':type(error).__name__+': '+str(error)})
def verifier_case(role='operator'):
    user={'id':'user','tenant_id':'tenant','username':'owned-worker','role':role,'cloud_bound':True,'disabled':False}
    current=deepcopy(user);config={'cloud':{'endpoint':'https://isolated.invalid','environment_id':'isolated-env'},'sessions':{'user':{'token':'in-memory-token','expires':time.time()+60}}}
    store=SimpleNamespace(directory=O,get=lambda entity,ident:deepcopy(current))
    core=SimpleNamespace(store=store,deployment_config={'id':'fangyu-apartment-client'},_public=lambda value:deepcopy(value))
    verifier=Verifier(core);verifier._read=lambda tenant:deepcopy(config)
    verifier._write=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('Forbidden configuration write'))
    return user,current,config,verifier
def positive(role):
    global profile
    user,current,config,v=verifier_case(role);before=deepcopy(config);profile={'username':user['username'],'role':role};start=len(net)
    assert v.verify_identity(user,expected_user=deepcopy(user))==user
    assert v.verify_identity(user,expected_user=deepcopy(user))==user
    assert len(net)-start==2 and all(row['operation']=='me' for row in net[start:]);assert config==before and current==user
    assert v.last_verified_profile==profile
    assert Verifier.__mro__[1].__name__=='_ReadOnlyDeliveryIntegrations'
    assert Verifier._refresh_session is space['_ReadOnlyDeliveryIntegrations']._refresh_session
for role in ('operator','admin'):check('real inheritance fresh me supports '+role+' with no session/user/config writes',lambda role=role:positive(role))
def expired():
    global profile
    user,current,config,v=verifier_case('admin');profile={'username':user['username'],'role':'admin'};config['sessions']['user']['expires']=time.time()-1;before=deepcopy(config);start=len(net)
    assert v.verify_identity(user,expected_user=user) is None;assert len(net)==start;assert config==before;assert v.last_verification_error.http_status==401
check('expired media session rejects without renewal or fake HTTP',expired)
def deny(kind):
    global profile
    user,current,config,v=verifier_case('admin');profile={'username':user['username'],'role':'admin'}
    if kind=='cloud_role':profile['role']='operator'
    elif kind=='cloud_username':profile['username']='other-worker'
    elif kind=='cloud_disabled':profile['disabled']=True
    elif kind=='local_role':current['role']='operator'
    elif kind=='local_disabled':current['disabled']=True
    elif kind=='cloud_unbound':current['cloud_bound']=False
    assert v.verify_identity(user,expected_user=user) is None
for kind in ('cloud_role','cloud_username','cloud_disabled','local_role','local_disabled','cloud_unbound'):check('fresh identity rejects '+kind,lambda kind=kind:deny(kind))
def media_case(change_at=None,change=None):
    user={'id':'user','tenant_id':'tenant','username':'owned-worker','role':'operator','cloud_bound':True,'disabled':False};current=deepcopy(user);selection={'storeId':'owned-store'};calls=[]
    backend=SimpleNamespace(lock=threading.RLock(),closed=False,core=SimpleNamespace(store=SimpleNamespace(directory=O),session=lambda token:deepcopy(current) if current else None),_load_selection=lambda *a,**kw:dict(selection),_stores=lambda *a:[{'id':'owned-store'}])
    def mutate():
        if change=='logout':current.clear()
        elif change=='store':selection['storeId']='other-store'
        elif change=='closed':backend.closed=True
        else:current[change]='changed' if change not in ('disabled','cloud_bound') else change=='disabled'
    def identity(*a,**kw):
        calls.append('identity');assert isinstance(kw['verification'],Verifier)
        if change_at=='identity':mutate()
        return deepcopy(user),{}
    def image(*a):
        calls.append('image')
        if change_at=='image':mutate()
        return b'isolated-image','image/png'
    backend._identity=identity;backend.customer_workbench=SimpleNamespace(media=image)
    try:result=media(backend,'isolated-token',{'storeId':'owned-store','leadId':'a'*32,'kind':'author'})
    except WorkbenchError as error:return error.code,calls
    return result,calls
def unchanged():
    result,calls=media_case();assert result==(b'isolated-image','image/png') and calls==['identity','image']
check('media success uses the new verifier and unchanged response contract',unchanged)
for stage in ('identity','image'):
    for change in ('logout','id','tenant_id','username','role','cloud_bound','disabled','store','closed'):
        def run(stage=stage,change=change):
            result,calls=media_case(stage,change);assert result in ('AUTH_REQUIRED','STORE_FORBIDDEN','BACKEND_CLOSED'),result
            assert ('image' in calls)==(stage=='image')
        check('media refuses '+change+' changed during '+stage,run)
def old_visible_preserved():
    file='work/ui-native-r57/customer_workbench.py';old=S.parents[1]/'candidate-unified-v17/project'/file
    def body(path):
        tr=ast.parse(path.read_text('utf-8-sig'));cl=next(n for n in tr.body if isinstance(n,ast.ClassDef) and n.name=='CustomerWorkbench');fn=next(n for n in cl.body if isinstance(n,ast.FunctionDef) and n.name=='media');return ast.dump(fn,include_attributes=False)
    assert body(S/file)==body(old)
check('original customer media before/after visibility body preserved from v17',old_visible_preserved)
report={'status':'PASS_MEDIA_INCREMENTAL_SECURITY' if all(r['status']=='PASS' for r in results) else 'FAIL_MEDIA_INCREMENTAL_SECURITY','at_utc':datetime.now(timezone.utc).isoformat(),'checks':len(results),'passed':sum(r['status']=='PASS' for r in results),'results':results,'source_sha256':hashlib.sha256(backend_source).hexdigest(),'actual_core_imported':False,'real_HTTP_requests':0,'real_platform_requests':0,'production_writes':0,'UI_operations':0,'test_kind':'Real inheritance/method AST and in-memory fakes; HTTP function replaced before execution'}
(O/'MEDIA-SAFETY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in report.items() if k!='results'}|{'failures':[r for r in results if r['status']=='FAIL']},ensure_ascii=False,indent=2))
raise SystemExit(0 if report['status'].startswith('PASS') else 1)
