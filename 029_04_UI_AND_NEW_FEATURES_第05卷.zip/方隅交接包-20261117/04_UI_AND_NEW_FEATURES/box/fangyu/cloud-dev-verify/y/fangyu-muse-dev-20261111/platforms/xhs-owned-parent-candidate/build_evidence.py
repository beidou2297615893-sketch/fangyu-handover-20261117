"""Read-only provenance audit plus evidence files inside this candidate."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
baseline=json.loads((ROOT/'SOURCE-HASHES.json').read_text('utf-8-sig'))
rows=[]
for record in baseline:
    source=Path(record['source']);candidate=ROOT/record['relative']
    rows.append({'relative':record['relative'],'source':str(source),'sourceBaselineSha256':record['sha256'],'sourceCurrentSha256':sha(source),'sourceUnchanged':sha(source)==record['sha256'],'candidateSha256':sha(candidate),'candidateChanged':sha(candidate)!=record['sha256']})
extras=[
    (Path('C:/积木软件工坊/项目/方隅公寓客户版/work/multi-account-complete-20261027-final/candidate/worker/core/adapters.py'),'reference/adapters.py'),
    (ROOT.parent/'shared-acquisition-ledger/ledger.py','reference/ledger.py'),
    (ROOT.parent/'shared-acquisition-ledger/test_ledger.py','reference/test_ledger.py'),
]
for source,relative in extras:
    rows.append({'relative':relative,'source':str(source),'sourceCurrentSha256':sha(source),'candidateSha256':sha(ROOT/relative),'copyMatchesCurrentSource':sha(source)==sha(ROOT/relative)})
old=ROOT/'reference/original_reply_execution_policy.py'
new=ROOT/'candidate/runtime/core/reply_execution_policy.py'
patch=''.join(difflib.unified_diff(old.read_text('utf-8-sig').splitlines(True),new.read_text('utf-8-sig').splitlines(True),fromfile='original/runtime/core/reply_execution_policy.py',tofile='candidate/runtime/core/reply_execution_policy.py'))
(ROOT/'evidence/parent-ledger.patch').write_text(patch,encoding='utf-8')
(ROOT/'evidence/FINAL-PROVENANCE.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
runtime={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for folder in ['candidate','helper','reference','tests'] for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not any(x.startswith('tmp') for x in p.relative_to(ROOT).parts)}
(ROOT/'evidence/FINAL-CANDIDATE-HASHES.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2),encoding='utf-8')
assert all(r.get('sourceUnchanged',True) and r.get('copyMatchesCurrentSource',True) for r in rows)
print('Source audit passed; patch and candidate hashes saved.')
