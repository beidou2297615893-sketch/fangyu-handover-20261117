"""Synthetic-only experiment. Not connected to the platform or production ledger."""
from contextlib import closing
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sqlite3
import time

ROOT = Path(__file__).resolve().parent
PLATFORM = 'xiaohongshu'


class Refused(RuntimeError):
    pass


@dataclass(frozen=True)
class Plan:
    sender_uid: str
    customer_uid: str
    comment_id: str
    note_id: str
    text: str
    attempt_id: str

    def validate(self):
        if any(not isinstance(v, str) or not v.strip() for v in asdict(self).values()):
            raise Refused('all synthetic plan fields are required')


def connect(path):
    path = Path(path).resolve(strict=True)
    if not path.is_relative_to(ROOT) or path.name != 'synthetic.sqlite3':
        raise Refused('candidate accepts only synthetic test databases in its own directory')
    db = sqlite3.connect(path, timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db


def reserve(path, plan):
    plan.validate()
    with closing(connect(path)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            db.execute('CREATE TABLE IF NOT EXISTS local_sender_plans(token TEXT PRIMARY KEY, data TEXT NOT NULL, FOREIGN KEY(token) REFERENCES reservations(token))')
            if db.execute('SELECT 1 FROM identity_aliases a JOIN identity_aliases b ON a.platform=b.platform AND a.canonical=b.alias WHERE b.canonical<>a.canonical LIMIT 1').fetchone():
                raise Refused('identity chain requires reconciliation')
            for table in ('leads', 'historical_assessments', 'historical_deliveries'):
                if db.execute(f'SELECT 1 FROM identity_aliases a JOIN {table} h ON a.platform=h.platform AND a.alias=h.customer WHERE a.alias<>a.canonical LIMIT 1').fetchone():
                    raise Refused('split identity history requires reconciliation')
            old = db.execute('SELECT * FROM reservations WHERE token=?', (plan.attempt_id,)).fetchone()
            if old:
                if (old['platform'], old['comment']) != (PLATFORM, plan.comment_id):
                    raise Refused('attempt identifier conflict')
                db.rollback()
                return False
            alias = db.execute('SELECT * FROM identity_aliases WHERE platform=? AND alias=?',
                               (PLATFORM, plan.customer_uid)).fetchone()
            if not alias or not alias['evidence'] or alias['verified'] < int(time.time()) - 86400:
                raise Refused('customer identity mapping missing or expired')
            customer = alias['canonical']
            chain = db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',
                               (PLATFORM, customer)).fetchone()
            if chain and chain['canonical'] != customer:
                raise Refused('identity chain requires review')
            if plan.customer_uid != customer and db.execute('SELECT 1 FROM leads WHERE platform=? AND customer=? LIMIT 1',
                                                             (PLATFORM, plan.customer_uid)).fetchone():
                raise Refused('split identity history requires review')
            target = db.execute('SELECT * FROM leads WHERE platform=? AND comment=?',
                                (PLATFORM, plan.comment_id)).fetchone()
            if not target or target['customer'] != customer or target['status'] not in ('unverified', 'reviewed', 'history_clear'):
                raise Refused('target missing, changed or blocked')
            if db.execute("SELECT 1 FROM leads WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent') LIMIT 1",
                          (PLATFORM, customer)).fetchone():
                raise Refused('customer has existing unresolved or sent local record')
            if db.execute("SELECT 1 FROM reservations WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent') LIMIT 1",
                          (PLATFORM, customer)).fetchone():
                raise Refused('customer has existing local reservation')
            if db.execute("SELECT 1 FROM historical_deliveries WHERE platform=? AND customer=? AND delivery_state<>'not_sent' LIMIT 1",
                          (PLATFORM, customer)).fetchone():
                raise Refused('customer has unresolved software delivery history')
            # Existing sender reservations may lack any account metadata.
            # Preserve their unresolved state and fail closed instead of assuming
            # that they belong to a different account.
            if db.execute("SELECT 1 FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown') AND p.token IS NULL LIMIT 1", (PLATFORM,)).fetchone():
                raise Refused('unattributed prior sender reservation requires reconciliation')
            for row in db.execute("SELECT p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown')", (PLATFORM,)):
                try:
                    if json.loads(row['data']).get('local_mode', {}).get('sender_uid') == plan.sender_uid:
                        raise Refused('account has an unresolved local-mode attempt')
                except (ValueError, TypeError, AttributeError):
                    raise Refused('account reservation data cannot be interpreted')
            assessment = {'source': 'synthetic test only', 'intent': 'rental', 'store': 'synthetic',
                          'match': 'match', 'pending': 'platform and other accounts not checked',
                          'draft': plan.text, 'peer_reply': 'unknown',
                          'local_mode': {'sender_uid': plan.sender_uid, 'plan': asdict(plan),
                                         'platform_replies_checked': False,
                                         'all_accounts_history_checked': False}}
            db.execute("INSERT INTO reservations VALUES(?,?,?,?, 'reserved',NULL,?)",
                       (plan.attempt_id, PLATFORM, customer, plan.comment_id, int(time.time())))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',
                       (plan.attempt_id, json.dumps(assessment, ensure_ascii=False)))
            db.execute("UPDATE leads SET status='reserved',review_time=NULL WHERE platform=? AND customer=? AND comment=?",
                       (PLATFORM, customer, plan.comment_id))
            db.commit()
            return True
        except BaseException:
            db.rollback()
            raise


def mark_unknown(path, plan, detail):
    with closing(connect(path)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            row = db.execute('SELECT * FROM reservations WHERE token=?', (plan.attempt_id,)).fetchone()
            if not row or row['status'] != 'reserved' or row['comment'] != plan.comment_id:
                raise Refused('reservation changed during synthetic submission')
            db.execute("UPDATE reservations SET status='unknown',evidence=? WHERE token=?", (detail, plan.attempt_id))
            db.execute("UPDATE leads SET status='unknown',review_time=NULL WHERE platform=? AND customer=? AND comment=?",
                       (row['platform'], row['customer'], row['comment']))
            db.commit()
        except BaseException:
            db.rollback()
            raise


def submit_once(path, plan, transport):
    if not reserve(path, plan):
        raise Refused('attempt already used')
    try:
        transport(plan)  # Tests inject an in-memory fake; no platform client is provided.
        detail = 'synthetic transport result requires independent confirmation'
    except BaseException:
        detail = 'synthetic transport failed or timed out; no automatic retry'
    mark_unknown(path, plan, detail)
    return 'unknown'
