"""Resume 15-store collection after resume006 stopped at batch-0023 with 461.

离线可测：路径与 runtime 可通过环境变量 / 模块注入替换；不读 Cookie、无发送能力。
"""
import argparse
import json
import os
import sqlite3
from contextlib import closing
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = Path(os.environ.get('XHS_RESUME007_PROJECT', str(HERE.parents[1])))

# 模块级路径（main 开头会 refresh_paths 按环境变量重算）
RESUME006_ROOT = None
LEDGER = None
LIVE_TASKS = None
STOP_TODAY_FIXED = None

_LOAD = None
_CLIENT_FACTORY = None


def refresh_paths():
    """按当前环境变量刷新路径常量（测试在 import 后才设 env）。"""
    global HERE, PROJECT, RESUME006_ROOT, LEDGER, LIVE_TASKS, STOP_TODAY_FIXED
    HERE = Path(os.environ.get('XHS_RESUME007_HERE', str(Path(__file__).resolve().parent)))
    PROJECT = Path(os.environ.get('XHS_RESUME007_PROJECT', str(Path(__file__).resolve().parents[2])))  # R/work/<task>/resume007.py -> R
    default_root = PROJECT / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
    RESUME006_ROOT = Path(os.environ.get('XHS_RESUME007_RESUME006_ROOT', str(default_root)))
    LEDGER = Path(os.environ.get(
        'XHS_RESUME007_LEDGER',
        str(PROJECT / 'work/shared-acquisition-ledger/shared.sqlite3'),
    ))
    LIVE_TASKS = RESUME006_ROOT.parent
    STOP_TODAY_FIXED = Path(os.environ.get(
        'XHS_RESUME007_STOP_TODAY',
        str(HERE / 'stop-today-resume007.json'),
    ))


refresh_paths()


def _get_runtime():
    """返回 (live, candidate, once, scheduling, client_factory_fn)。"""
    if _LOAD is not None:
        live, candidate, once, scheduling = _LOAD()
    else:
        sys.path.insert(0, str(PROJECT / 'work/xhs-new-task-session-fix-20261029'))
        from integration import load  # type: ignore
        live, candidate, once, scheduling = load()
    if _CLIENT_FACTORY is not None:
        client_factory_fn = _CLIENT_FACTORY
    else:
        sys.path.insert(0, str(PROJECT / 'work/xhs-new-task-session-fix-20261029'))
        from integration import client_factory  # type: ignore
        client_factory_fn = client_factory
    return live, candidate, once, scheduling, client_factory_fn


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, path)


def reject(reason):
    print(json.dumps({'status': 'rejected', 'reason': reason}, ensure_ascii=False))
    return 1


def _resolve_session_home(arg_value):
    return Path(arg_value).resolve()


class VerificationStop(Exception):
    def __init__(self, http_status=461, reason='verification_required'):
        self.http_status = http_status
        self.reason = reason
        super().__init__(reason)


class SessionStop(Exception):
    def __init__(self, reason='session_deleted'):
        self.reason = reason
        super().__init__(reason)


def _is_stop_exc(exc):
    if isinstance(exc, (VerificationStop, SessionStop)):
        return True
    name = type(exc).__name__
    if name in ('VerificationStop', 'SessionStop'):
        return True
    if getattr(exc, 'http_status', None) == 461:
        return True
    return False


def _get_verified_identity(uid, session_home):
    for name in ('identity-check-resume007-verified.json', 'identity-check-resume006-verified.json'):
        path = HERE / name
        if not path.exists():
            continue
        ident = read_json(path)
        if (
            ident.get('status') == 'verified'
            and ident.get('uid') == uid
            and Path(ident.get('session_home', '')).resolve() == session_home
        ):
            return ident
    return None


def _check_stop_today():
    today = time.strftime('%Y-%m-%d')
    if STOP_TODAY_FIXED.exists():
        try:
            data = read_json(STOP_TODAY_FIXED)
            if data.get('date') == today:
                return True
        except (OSError, ValueError, json.JSONDecodeError):
            pass
    return False


def _query_ledger(source_pattern):
    if not LEDGER.exists():
        return 0
    uri = LEDGER.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True)) as db, db:
        db.execute('PRAGMA query_only=ON')
        row = db.execute(
            "SELECT count(*) FROM leads WHERE source LIKE ?",
            (source_pattern,),
        ).fetchone()
        return row[0] if row else 0


def _check_batch0023_empty():
    batch_dir = RESUME006_ROOT / 'batch-0023'
    pattern = f'%{RESUME006_ROOT.name}%batch-0023%'
    count = _query_ledger(pattern)
    if count != 0:
        return False, f'ledger count={count}'
    for name in ('register-result.json', 'registered-ready.json', 'collection.json'):
        if (batch_dir / name).exists():
            return False, f'{name} exists'
    return True, ''


def _check_failure_461():
    path = RESUME006_ROOT / 'batch-0023' / 'failure-diagnostic.json'
    if not path.exists():
        return False, 'failure-diagnostic.json missing'
    failure = read_json(path)
    status = failure.get('platform', {}).get('http_status')
    if status is None:
        status = failure.get('http_evidence', {}).get('http_status')
    return status == 461, f'http_status={status}'


def _check_locks(session_home):
    locks = [
        session_home / '.managed-use.lock',
        RESUME006_ROOT / 'scheduler.lock',
        RESUME006_ROOT / '.account-switch.lock',
    ]
    for lock in locks:
        if lock.exists():
            return False, str(lock)
    return True, ''


def _inflight_plan_index(state):
    plan = state.get('plan') or []
    inflight = state.get('inflight') or {}
    if inflight.get('batch') == 'batch-0023':
        for i, item in enumerate(plan):
            if item.get('keyword') == inflight.get('keyword') and item.get('page') == inflight.get('page'):
                return i
        return None
    for i, item in enumerate(plan):
        if item.get('keyword') == inflight.get('keyword') and item.get('page') == inflight.get('page'):
            return i
    return None


def _load_continuation_receipt():
    """读取 resume006 的 continuation-receipt，优先于猜测值。"""
    path = RESUME006_ROOT / 'continuation-receipt.json'
    if path.exists():
        try:
            data = read_json(path)
            prior = data.get('prior_registered') or data.get('registered') or 0
            partial = data.get('partial_registered_preserved') or 0
            return int(prior), int(partial), str(path)
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            pass
    # 合理默认：resume006 已知 3566 条注册，30 条部分保留
    return 3566, 30, 'default'


def _validate_prior_state():
    state_path = RESUME006_ROOT / 'state.json'
    if not state_path.exists():
        return False, 'prior_state_missing', None
    state = read_json(state_path)
    if state.get('status') != 'outcome_unknown':
        return False, 'prior_state_changed', state
    plan = state.get('plan') or []
    inflight = state.get('inflight') or {}
    if not plan or not inflight:
        return False, 'prior_state_changed', state
    if inflight.get('batch') != 'batch-0023':
        return False, 'prior_state_changed', state
    idx = _inflight_plan_index(state)
    if idx is None:
        return False, 'prior_state_changed', state
    receipts_path = RESUME006_ROOT / 'run-receipts.jsonl'
    if not receipts_path.exists():
        return False, 'prior_state_changed', state
    lines = [l for l in receipts_path.read_text(encoding='utf-8').splitlines() if l.strip()]
    if not lines:
        return False, 'prior_state_changed', state
    last_receipt = json.loads(lines[-1])
    if last_receipt.get('status') != 'outcome_unknown' or last_receipt.get('new_registered') != 0:
        return False, 'prior_state_changed', state
    ok, _ = _check_batch0023_empty()
    if not ok:
        return False, 'unknown_registration', state
    ok, _ = _check_failure_461()
    if not ok:
        return False, 'failure_changed', state
    return True, '', state


def _compute_remaining_pages(state):
    plan = state.get('plan') or []
    idx = _inflight_plan_index(state)
    if idx is None:
        return 0
    return len(plan) - idx


def _compute_already_known(once, state):
    dedup_path = RESUME006_ROOT / 'batch-0023' / 'dedup-summary.json'
    if dedup_path.exists():
        try:
            dedup = read_json(dedup_path)
            return int(dedup.get('skipped_notes', 0)), int(dedup.get('duplicate_comments', 0))
        except (OSError, ValueError, TypeError):
            pass
    try:
        idx = once.history_index([str(RESUME006_ROOT)], ledger=str(LEDGER))
        notes = idx.get('completed_notes') or []
        comments = idx.get('known_comments') or []
        return len(notes), len(comments)
    except Exception:
        return 0, 0


def _preview(args, live, candidate, once, scheduling, client_factory_fn, state):
    remaining = _compute_remaining_pages(state)
    plan = state.get('plan') or []
    idx = _inflight_plan_index(state)
    first_idx = idx if idx is not None else 0
    first = plan[first_idx] if first_idx < len(plan) else {'keyword': '', 'page': 0}
    notes, comments = _compute_already_known(once, state)
    uid_tail = args.uid[-4:] if len(args.uid) >= 4 else args.uid
    print(json.dumps({
        'status': 'preview_ok',
        'resume_from_batch': 23,
        'first': {'keyword': first.get('keyword'), 'page': first.get('page')},
        'remaining_pages': remaining,
        'already_known_notes': notes,
        'already_known_comments': comments,
        'delay': args.delay,
        'uid_tail': uid_tail,
        'network': False,
    }, ensure_ascii=False))
    return 0


def _write_stop_today(new_root, reason):
    today = time.strftime('%Y-%m-%d')
    stop_data = {'date': today, 'reason': str(reason), 'root': str(new_root), 'automatic_retry': False}
    write_json(new_root / 'stop-today.json', stop_data)
    write_json(STOP_TODAY_FIXED, stop_data)


def _wrap_history_index(once):
    """运行时包装 history_index，确保 RESUME006_ROOT 始终包含在 roots 中。"""
    _orig = once.history_index

    def _wrapped(roots, *, ledger):
        roots = list(roots)
        r6 = str(Path(RESUME006_ROOT).resolve())
        if r6 not in {str(Path(x).resolve()) for x in roots}:
            roots.append(r6)
        return _orig(roots, ledger=ledger)

    once.history_index = _wrapped
    return _wrapped


def _execute(args, live, candidate, once, scheduling, client_factory_fn, state):
    session_home = _resolve_session_home(args.session_home)
    remaining = _compute_remaining_pages(state)
    plan = state.get('plan') or []
    idx = _inflight_plan_index(state)
    if idx is None:
        return reject('prior_state_changed')
    remaining_plan = plan[idx:]

    # 执行期加锁（仿 resume006 L87/L90）：先锁后建 ROOT，避免孤儿目录
    lock = session_home / '.managed-use.lock'
    try:
        lock.mkdir()
    except FileExistsError:
        return reject('active_lock')
    owner_file = lock / 'owner.json'
    live.write_new(owner_file, {
        'pid': os.getpid(),
        'task': 'stores15-resume007',
        'at': live.now() if hasattr(live, 'now') else time.strftime('%Y-%m-%dT%H:%M:%S'),
    })

    new_root = LIVE_TASKS / f"stores15-resume007-{time.strftime('%Y%m%d-%H%M%S')}"
    try:
        new_root.mkdir(exist_ok=False)
    except FileExistsError:
        # 同秒冲突极少见；释放锁后拒绝
        try:
            owner_file.unlink(missing_ok=True); lock.rmdir()
        except OSError:
            pass
        return reject('root_exists')

    try:
        # 运行时包装 once.history_index，不改 src 即把 resume006 ROOT 纳入真实去重扫描
        _wrap_history_index(once)

        prior_registered, partial_preserved, prior_source = _load_continuation_receipt()

        task_config = {
            'session_home': str(session_home),
            'ledger': str(LEDGER),
            'source_db': str(PROJECT / 'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'),
            'shared_ledger': True,
            'max_comment_pages': 2,
            'operator': 'current_chat_15_store_collection_resume007',
            'task': '15家门店续采',
            'plan': remaining_plan,
            'expected_uid': args.uid,
            'send_authorized': False,
            'delay': args.delay,
            'source_store_is_customer_assignment': False,
            'plan_exhaustion_is_overall_completion': False,
        }
        live.write_new(new_root / 'task-config.json', task_config)
        live.write_new(new_root / 'continuation-receipt.json', {
            'status': 'locally_reconciled',
            'prior_registered': prior_registered,
            'interrupted_batch_inserted': 0,
            'next_batch': 23,
            'partial_registered_preserved': partial_preserved,
            'prior_counts_source': prior_source,
            'account_uid': args.uid,
            'remaining_pages': remaining,
            'first': remaining_plan[0] if remaining_plan else None,
            'old_state_unchanged': True,
            'network': False,
            'resume006_root': str(RESUME006_ROOT),
            'batch_number_mapping': {'first_batch': 23, 'continues': 'batch-0023'},
        })
        scheduling.initialize(new_root, remaining_plan, first_batch=23, target=2147483647)

        create_client = client_factory_fn(args.uid, delay=args.delay)

        class Executor:
            def run(self, batch, keyword, page, remaining_hint):
                # LiveExecutor/once.main 内调用 history_index；此处已包装，会自动含 resume006 ROOT
                result = live.LiveExecutor(
                    new_root, task_config, candidate, once, create_client
                ).run(batch, keyword, page, remaining_hint)
                live.append(new_root / 'store-analysis-manifest.jsonl', {
                    'at': live.now(),
                    'batch': batch,
                    'keyword': keyword,
                    'page': page,
                    'inserted_comments': result.get('inserted', 0),
                    'analysis_input': result.get('analysis_input'),
                    'status': 'registered_ready_for_classification',
                })
                return result

        try:
            result = scheduling.run(new_root, Executor())
            if result.get('status') == 'outcome_unknown':
                _write_stop_today(new_root, 'outcome_unknown')
                print(json.dumps({'status': 'stopped', 'reason': 'outcome_unknown', 'automatic_retry': False}, ensure_ascii=False))
                return 2
            live.append(new_root / 'run-receipts.jsonl', {
                'at': live.now(),
                'status': result['status'],
                'new_registered': result.get('inserted', 0),
                'inflight': result.get('inflight'),
                'automatic_retry': False,
            })
            print(json.dumps({'status': result['status'], 'new_registered': result.get('inserted', 0)}, ensure_ascii=False))
            return 0 if result['status'] in ['paused', 'plan_exhausted', 'ready'] else 2
        except Exception as e:
            if _is_stop_exc(e):
                _write_stop_today(new_root, e)
                try:
                    state_data = read_json(new_root / 'state.json')
                    state_data['status'] = 'outcome_unknown'
                    write_json(new_root / 'state.json', state_data)
                except (OSError, ValueError, json.JSONDecodeError):
                    pass
                live.append(new_root / 'run-receipts.jsonl', {
                    'at': live.now() if hasattr(live, 'now') else time.strftime('%Y-%m-%dT%H:%M:%S'),
                    'status': 'outcome_unknown',
                    'new_registered': 0,
                    'automatic_retry': False,
                    'reason': str(e),
                })
                print(json.dumps({'status': 'stopped', 'reason': str(e), 'automatic_retry': False}, ensure_ascii=False))
                return 2
            raise
    finally:
        # 释放锁
        try:
            if owner_file.exists():
                owner_file.unlink()
            lock.rmdir()
        except OSError:
            pass


def main(argv=None):
    refresh_paths()
    parser = argparse.ArgumentParser(description='小红书 stores15 resume007 续采（默认预览）')
    parser.add_argument('--uid', required=True)
    parser.add_argument('--session-home', required=True)
    parser.add_argument('--delay', type=float, default=10.0)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args(argv)

    if args.delay <= 3.0:
        return reject('delay_too_small')
    if _check_stop_today():
        return reject('verification_stop_today')

    live, candidate, once, scheduling, client_factory_fn = _get_runtime()
    session_home = _resolve_session_home(args.session_home)
    if _get_verified_identity(args.uid, session_home) is None:
        return reject('verified_account_required')
    ok, _ = _check_locks(session_home)
    if not ok:
        return reject('active_lock')
    ok, reason, state = _validate_prior_state()
    if not ok:
        return reject(reason)
    if not args.execute:
        return _preview(args, live, candidate, once, scheduling, client_factory_fn, state)
    return _execute(args, live, candidate, once, scheduling, client_factory_fn, state)


if __name__ == '__main__':
    raise SystemExit(main())
