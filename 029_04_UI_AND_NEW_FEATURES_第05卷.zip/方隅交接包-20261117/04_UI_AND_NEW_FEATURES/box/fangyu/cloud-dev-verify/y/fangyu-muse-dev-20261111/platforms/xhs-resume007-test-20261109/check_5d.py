﻿import socket, sys, os, json
ATT = []
def _blk(self, addr, *a, **k): ATT.append(repr(addr)); raise OSError('blocked')
socket.socket.connect = _blk
sys.path.insert(0, os.getcwd())
import resume007 as m
m.refresh_paths()
ok, reason, st = m._validate_prior_state()
print('(ok, reason) =', (ok, reason))
st = st or {}
inf = st.get('inflight') or {}
print('state.status =', st.get('status'), ' plan_len =', len(st.get('plan') or []))
print('inflight batch/keyword/page =', inf.get('batch'), '/', inf.get('keyword'), '/', inf.get('page'))
print('inflight plan index =', m._inflight_plan_index(st), ' remaining_pages =', m._compute_remaining_pages(st))
print('batch0023_empty =', m._check_batch0023_empty())
print('failure_461 =', m._check_failure_461())
print('continuation =', m._load_continuation_receipt())
rp = m.RESUME006_ROOT / 'run-receipts.jsonl'
last = json.loads([l for l in rp.read_text(encoding='utf-8').splitlines() if l.strip()][-1])
print('last receipt status/new_registered =', last.get('status'), last.get('new_registered'))
print('network attempts:', ATT)
