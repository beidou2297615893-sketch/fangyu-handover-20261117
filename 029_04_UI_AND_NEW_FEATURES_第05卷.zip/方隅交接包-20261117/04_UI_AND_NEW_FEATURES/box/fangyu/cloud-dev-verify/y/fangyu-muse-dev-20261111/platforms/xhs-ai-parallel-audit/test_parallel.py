import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import pipeline
import one_click
from test_pipeline import record, answer
from test_one_click import TestOneClick

STAMP='2026-10-28T23:59:59+08:00'


def rows(n):
    return [dict(record(),customer_id='customer'+str(i),customer_uid='uid'+str(i),comment_id='comment'+str(i)) for i in range(n)]


class CountingProvider:
    model='fixture'
    parallelism=3
    settings={}
    def __init__(self,fail=None):
        self.fail=fail;self.lock=threading.Lock();self.current=0;self.maximum=0;self.calls=[];self.times=[];self.review_as_of=None
    def bind_review_as_of(self,value):self.review_as_of=value
    def analyze(self,row,account,samples):
        with self.lock:
            self.current+=1;self.maximum=max(self.maximum,self.current);self.calls.append(row['customer_id']);self.times.append(self.review_as_of)
        try:
            if self.fail==row['customer_id']:
                time.sleep(.03);raise pipeline.ProviderError('synthetic error')
            time.sleep(.08)
            return answer(target_comment_id=row['comment_id'],reply='方隅公寓可以看看')
        finally:
            with self.lock:self.current-=1


class ParallelTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent);self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def write_input(self,n):
        path=self.root/'source.json';path.write_text(json.dumps(rows(n),ensure_ascii=False),encoding='utf8');return path

    def test_max_three_parallel_and_frozen_clock(self):
        src=self.write_input(7);provider=CountingProvider()
        with patch.object(pipeline,'now_shanghai',return_value=STAMP):
            pipeline.create_batch(src,self.root/'out','sender',{},[],provider)
        self.assertEqual(provider.maximum,3)
        self.assertEqual(len(provider.calls),7)
        self.assertEqual(set(provider.times),{STAMP})
        batch=json.loads((self.root/'out'/'batch.json').read_text(encoding='utf8'))
        self.assertEqual(batch['count'],7)
        self.assertEqual([x['customer_id'] for x in batch['rows']],[x['customer_id'] for x in rows(7)])

    def test_failure_stops_new_calls_and_preserves_completed_for_resume(self):
        src=self.write_input(7);provider=CountingProvider(fail='customer0');out=self.root/'out'
        with patch.object(pipeline,'now_shanghai',return_value=STAMP):
            with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,out,'sender',{},[],provider)
        self.assertEqual(set(provider.calls),{'customer0','customer1','customer2'})
        self.assertEqual(len(list((out/'completed').glob('*.json'))),2)
        self.assertFalse((out/'batch.json').exists())
        resumed=CountingProvider()
        with patch.object(pipeline,'now_shanghai',return_value='2026-10-29T00:00:01+08:00'):
            pipeline.create_batch(src,out,'sender',{},[],resumed)
        self.assertEqual(set(resumed.calls),{'customer0','customer3','customer4','customer5','customer6'})
        self.assertEqual(set(resumed.times),{STAMP})
        self.assertEqual(json.loads((out/'batch.json').read_text(encoding='utf8'))['count'],7)

    def test_completed_record_persists_while_other_calls_still_running(self):
        src=self.write_input(3);out=self.root/'out';started=threading.Event();release=threading.Event();errors=[]
        other1=threading.Event();other2=threading.Event()
        class Fixture(CountingProvider):
            def analyze(self,row,account,samples):
                if row['customer_id']=='customer0':
                    if not other1.wait(3) or not other2.wait(3):raise RuntimeError('not parallel')
                    started.set();return answer(target_comment_id=row['comment_id'],reply='方隅公寓可以看看')
                (other1 if row['customer_id']=='customer1' else other2).set()
                if not release.wait(5):raise RuntimeError('test timeout')
                return answer(target_comment_id=row['comment_id'],reply='方隅公寓可以看看')
        provider=Fixture()
        def work():
            try:pipeline.create_batch(src,out,'sender',{},[],provider,review_as_of=STAMP)
            except Exception as exc:errors.append(exc)
        thread=threading.Thread(target=work);thread.start()
        try:
            self.assertTrue(started.wait(3));deadline=time.monotonic()+3
            while time.monotonic()<deadline and not list((out/'completed').glob('*.json')):time.sleep(.01)
            self.assertEqual(len(list((out/'completed').glob('*.json'))),1)
            self.assertFalse((out/'batch.json').exists())
        finally:release.set();thread.join(5)
        self.assertFalse(thread.is_alive());self.assertEqual(errors,[])
        self.assertEqual(json.loads((out/'batch.json').read_text(encoding='utf8'))['count'],3)

    def test_duplicate_platform_user_is_rejected_before_parallel_calls(self):
        one,two=rows(2);two['customer_uid']=one['customer_uid']
        src=self.root/'source.json';src.write_text(json.dumps([one,two],ensure_ascii=False),encoding='utf8')
        provider=CountingProvider()
        with self.assertRaises(pipeline.InvalidInput):pipeline.create_batch(src,self.root/'out','sender',{},[],provider)
        self.assertEqual(provider.calls,[])


class WorkflowParallelTests(TestOneClick):
    def test_parallel_failure_does_not_invoke_sender(self):
        src=self.root/'source.json';src.write_text(json.dumps(rows(7),ensure_ascii=False),encoding='utf8')
        provider=CountingProvider(fail='customer0');calls=[]
        with self.assertRaises(pipeline.ProviderError):
            one_click.run_workflow(input_path=src,output_dir=self.root/'out',ledger=self.db,sender_uid='sender',
                account={},samples=[],provider=provider,send=lambda *args:calls.append(args),execute=True)
        self.assertEqual(calls,[])
        self.assertFalse((self.root/'out'/'analysis'/'batch.json').exists())

if __name__=='__main__':unittest.main(verbosity=2)
