"""Synthetic tests only; no live client, network, or real ledger."""
import json
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from contextlib import closing
from dataclasses import asdict, replace
from pathlib import Path

import production_sender as sender

ROOT=Path(__file__).resolve().parent
LEDGER=ROOT.parent/'shared-acquisition-ledger'/'ledger.py'
DDL='''CREATE TABLE collection_uid_observations(
 platform TEXT NOT NULL, platform_uid TEXT NOT NULL, canonical TEXT NOT NULL,
 basis TEXT NOT NULL, source TEXT NOT NULL, observed_at INTEGER NOT NULL,
 PRIMARY KEY(platform,platform_uid), UNIQUE(platform,canonical))'''


class FakeClient:
    def __init__(self,plan): self.plan=plan;self._armed=False;self.calls=0
    def identity(self): pass
    def send_once(self):
        self.calls+=1
        return {'comment':{'id':'SYNTHETIC'}}


class ObservationGuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT)
        self.db=Path(self.tmp.name)/'synthetic.sqlite3'
        subprocess.run([sys.executable,'-X','utf8',str(LEDGER),'--db',str(self.db),'init'],check=True,capture_output=True)
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY, data TEXT NOT NULL, FOREIGN KEY(token) REFERENCES reservations(token))')
            for customer,comment in [('canonical1','comment1'),('canonical2','comment2')]:
                db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',('xiaohongshu',customer,comment,'unverified','synthetic'))
            db.commit()
        self.plan=sender.SendPlan('sender1','uid1','note1','comment1','reply','attempt1',True,'local fixture',int(time.time())+200,'fixture','canonical1')

    def tearDown(self): self.tmp.cleanup()

    def table(self,sql=DDL,rows=()):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute(sql)
            for row in rows:db.execute('INSERT INTO collection_uid_observations VALUES(?,?,?,?,?,?)',row)
            db.commit()

    def submit(self,plan):
        client=FakeClient(plan)
        try:
            result=sender.Runner(self.db,client,synthetic=True).submit(plan)
            return ('accepted',client.calls,result)
        except sender.Refused:
            return ('blocked',client.calls,None)

    def test_old_database_without_observation_table_remains_compatible(self):
        self.assertEqual(self.submit(self.plan)[:2],('accepted',1))

    def test_identical_uid_and_canonical_is_accepted(self):
        self.table(rows=[('xiaohongshu','uid1','canonical1','local_source_consistency_only','fixture',123)])
        self.assertEqual(self.submit(self.plan)[:2],('accepted',1))

    def test_existing_empty_observation_table_allows_legacy_customer(self):
        self.table()
        self.assertEqual(self.submit(self.plan)[:2],('accepted',1))

    def test_same_uid_different_canonical_is_blocked_before_post(self):
        self.table(rows=[('xiaohongshu','uid1','canonical2','new_uid_candidate_not_platform_verified','fixture',123)])
        self.assertEqual(self.submit(self.plan)[:2],('blocked',0))

    def test_same_canonical_different_uid_is_blocked_before_post(self):
        self.table(rows=[('xiaohongshu','uid2','canonical1','local_source_consistency_only','fixture',123)])
        self.assertEqual(self.submit(self.plan)[:2],('blocked',0))

    def test_other_platform_does_not_claim_same_uid(self):
        self.table(rows=[('douyin','uid1','canonical2','new_uid_candidate_not_platform_verified','fixture',123)])
        self.assertEqual(self.submit(self.plan)[:2],('accepted',1))

    def test_wrong_observation_schema_is_blocked(self):
        self.table('CREATE TABLE collection_uid_observations(platform TEXT, platform_uid TEXT, canonical TEXT)')
        self.assertEqual(self.submit(self.plan)[:2],('blocked',0))

    def test_missing_unique_canonical_constraint_is_blocked(self):
        self.table('''CREATE TABLE collection_uid_observations(platform TEXT NOT NULL, platform_uid TEXT NOT NULL,
 canonical TEXT NOT NULL, basis TEXT NOT NULL, source TEXT NOT NULL, observed_at INTEGER NOT NULL,
 PRIMARY KEY(platform,platform_uid))''')
        self.assertEqual(self.submit(self.plan)[:2],('blocked',0))

    def test_partial_unique_index_cannot_masquerade_as_global_constraint(self):
        self.table('''CREATE TABLE collection_uid_observations(platform TEXT NOT NULL, platform_uid TEXT NOT NULL,
 canonical TEXT NOT NULL, basis TEXT NOT NULL, source TEXT NOT NULL, observed_at INTEGER NOT NULL,
 PRIMARY KEY(platform,platform_uid))''')
        with closing(sqlite3.connect(self.db)) as db:
            db.execute("CREATE UNIQUE INDEX partial_canonical ON collection_uid_observations(platform,canonical) WHERE canonical <> 'canonical1'")
            db.commit()
        self.assertEqual(self.submit(self.plan)[:2],('blocked',0))

    def test_affected_invalid_provenance_is_blocked(self):
        self.table(rows=[('xiaohongshu','uid1','canonical1','unknown','','0')])
        self.assertEqual(self.submit(self.plan)[:2],('blocked',0))

    def test_cross_account_concurrent_conflict_blocks_one_without_post(self):
        self.table(rows=[('xiaohongshu','uid1','canonical1','local_source_consistency_only','fixture',123)])
        second=replace(self.plan,sender_uid='sender2',canonical_customer='canonical2',comment_id='comment2',attempt_id='attempt2')
        barrier=threading.Barrier(2); result=[]
        def worker(plan):
            barrier.wait();result.append(self.submit(plan)[:2])
        threads=[threading.Thread(target=worker,args=(p,)) for p in (self.plan,second)]
        for thread in threads:thread.start()
        for thread in threads:thread.join()
        self.assertEqual(sorted(result),[('accepted',1),('blocked',0)])

    def test_two_processes_cross_account_conflict_blocked_before_post(self):
        self.table(rows=[('xiaohongshu','uid1','canonical1','local_source_consistency_only','fixture',123)])
        second=replace(self.plan,sender_uid='sender2',canonical_customer='canonical2',comment_id='comment2',attempt_id='attempt2')
        script='''
import json,sys,time
from pathlib import Path
import production_sender as sender
class Client:
 def __init__(self,plan): self.plan=plan;self._armed=False;self.calls=0
 def identity(self): pass
 def send_once(self): self.calls+=1;return {'comment':{'id':'SYNTHETIC'}}
plan=sender.SendPlan(**json.loads(sys.argv[2]))
Path(sys.argv[3]).touch()
deadline=time.monotonic()+8
while not Path(sys.argv[4]).exists():
 if time.monotonic()>deadline:raise RuntimeError('fixture barrier timeout')
 time.sleep(.005)
client=Client(plan)
try:
 sender.Runner(sys.argv[1],client,synthetic=True).submit(plan)
 print('accepted:'+str(client.calls))
except sender.Refused:print('blocked:'+str(client.calls))
'''
        directory=Path(self.tmp.name);gate=directory/'gate';ready=[directory/'one',directory/'two']
        processes=[subprocess.Popen([sys.executable,'-X','utf8','-c',script,str(self.db),json.dumps(asdict(plan)),str(ready[i]),str(gate)],
                                   cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                   for i,plan in enumerate((self.plan,second))]
        deadline=time.monotonic()+8
        while not all(p.exists() for p in ready):
            if time.monotonic()>deadline:
                for process in processes:process.kill()
                self.fail('fixture barrier timeout')
            time.sleep(.005)
        gate.touch();results=[]
        for process in processes:
            out,err=process.communicate(timeout=10)
            self.assertEqual(process.returncode,0,err)
            results.append(out.strip())
        self.assertEqual(sorted(results),['accepted:1','blocked:0'])


if __name__=='__main__': unittest.main()
