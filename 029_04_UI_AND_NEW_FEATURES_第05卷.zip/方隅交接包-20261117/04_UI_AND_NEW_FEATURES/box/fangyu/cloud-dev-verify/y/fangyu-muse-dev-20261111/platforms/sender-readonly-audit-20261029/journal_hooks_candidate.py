"""Isolated wiring candidate; does not import or run any real sender."""
class JournalFailure(RuntimeError): pass

def install(sender, ledger, journal, sync):
    # Crash recovery happens before a sender can become usable.
    sync(ledger,journal)
    original_reserve=sender._reserve
    original_outcome=sender._outcome
    def checkpoint():
        try: sync(ledger,journal)
        except Exception as exc: raise JournalFailure("Text journal unavailable; stop sending") from exc
    def reserve(*args,**kwargs):
        result=original_reserve(*args,**kwargs)
        checkpoint()  # committed reservation must be durable text before POST
        return result
    def outcome(*args,**kwargs):
        result=original_outcome(*args,**kwargs)
        checkpoint()  # failure propagates; next item must never start
        return result
    sender._reserve=reserve
    sender._outcome=outcome
    return checkpoint
