"""Reviewed new-batch continuation after a human completed verification.

Preview is read-only. This never retries the failed batch or logs credentials.
"""
import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def lines(path):return [json.loads(x) for x in Path(path).read_text(encoding='utf8').splitlines() if x]
def now():return datetime.now(timezone.utc).isoformat()
def write_new(path,value):
    with Path(path).open('x',encoding='utf8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.flush();os.fsync(stream.fileno())

def prefix(root,ledger,successor):
    state=read(root/'state.json');config=read(root/'task-config.json')
    manifest=lines(root/'analysis-manifest.jsonl')
    if (state.get('status')!='outcome_unknown' or not isinstance(state.get('inflight'),dict)
        or type(state.get('cursor')) is not int or not 0<=state['cursor']<len(state.get('plan',[]))
        or config.get('plan')!=state['plan'] or len(manifest)!=state['cursor']
        or config.get('first_batch',0)+state['cursor']!=state.get('next_batch')):
        raise ValueError('interrupted_state_conflict')
    failed_name=f"batch-{state['next_batch']:04d}";failed=root/failed_name
    expected=state['plan'][state['cursor']];inflight=state['inflight']
    if (inflight.get('batch')!=failed_name or inflight.get('keyword')!=expected['keyword']
        or inflight.get('page')!=expected['page'] or inflight.get('remaining')!=state['target']-state['inserted']):
        raise ValueError('interrupted_state_conflict')
    audit=lines(failed/'account-audit.jsonl')
    if (not audit or audit[-1].get('status')!='stopped_before_registration'
        or any(x.get('status') in ('registration_started','registered','registration_outcome_unknown_check_ledger') for x in audit)
        or any((failed/name).exists() for name in ('collection.json','register-result.json','registered-ready.json','new-ai-input.json'))):
        raise ValueError('failed_batch_registration_uncertain')
    account_uid=None;total=0
    with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        source='collection:'+str((failed/'collection.json').resolve())
        if db.execute("SELECT COUNT(*) FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchone()[0]:
            raise ValueError('failed_batch_registration_uncertain')
        seen=set()
        for index,event in enumerate(manifest):
            name=f"batch-{config['first_batch']+index:04d}";folder=root/name
            binding=read(folder/'account-binding.json');receipt=read(folder/'register-result.json')
            ready=read(folder/'registered-ready.json');collection=read(folder/'collection.json')
            selected=read(folder/'new-ai-input.json');item=state['plan'][index]
            count=receipt.get('result',{}).get('inserted')
            source='collection:'+str((folder/'collection.json').resolve(strict=True))
            if (type(count) is not int or count<0 or event.get('batch')!=name
                or event.get('keyword')!=item['keyword'] or event.get('page')!=item['page']
                or event.get('status')!='registered_ready_for_classification'
                or event.get('inserted_comments')!=count or event.get('registration_source')!=source
                or event.get('input')!=f'{name}/new-ai-input.json'
                or event.get('sha256')!=hashlib.sha256((folder/'new-ai-input.json').read_bytes()).hexdigest()
                or binding.get('guest') is not False or not binding.get('uid')
                or receipt.get('account')!=binding or collection.get('collection_account')!=binding
                or ready.get('registered') is not True or ready.get('account_uid')!=binding['uid']
                or ready.get('inserted_comments')!=count or ready.get('input')!='new-ai-input.json'):
                raise ValueError('registered_prefix_conflict')
            if account_uid is not None and account_uid!=binding['uid']:raise ValueError('registered_prefix_conflict')
            account_uid=binding['uid']
            original=successor.comments(collection.get('customers'));analysis=successor.comments(selected)
            rows=db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchall()
            if (len(rows)!=count or len(set(rows))!=count or set(rows)!=set(analysis)
                or any(key not in original or original[key]!=analysis[key] for key in analysis)
                or seen.intersection(rows)):
                raise ValueError('registered_prefix_conflict')
            seen.update(rows);total+=count
        db.rollback()
    failed_binding=read(failed/'account-binding.json')
    if total!=state['inserted'] or failed_binding.get('guest') is not False:
        raise ValueError('registered_prefix_conflict')
    account_uid=account_uid or failed_binding['uid']
    if failed_binding.get('uid')!=account_uid:raise ValueError('failed_account_conflict')
    return state,config,total,account_uid

def prepare(campaign_path,session_home):
    successor=load('resume_audit_helpers',PROJECT/'work/xhs-queue-successor-20261029/successor.py')
    campaign=read(campaign_path);active=Path(campaign['active_root']).resolve(strict=True)
    config=read(active/'task-config.json');ledger=Path(config['ledger']).resolve(strict=True)
    if (ledger.parent/'.xhs-collection-runner.lock').exists() or (active/'scheduler.lock').exists():
        raise ValueError('collection_lock_busy')
    total=0;uid=None;proofs=[]
    roots=[Path(x['root']).resolve(strict=True) for x in campaign['completed_segments']]
    if len(set(roots+[active]))!=len(roots)+1:raise ValueError('duplicate_campaign_segment')
    for entry,root in zip(campaign['completed_segments'],roots):
        state,old_config,manifest,account=successor.audit_registered(root,ledger)
        if entry.get('registered_comments')!=state['inserted']:raise ValueError('campaign_count_conflict')
        if uid is not None and uid!=account:raise ValueError('campaign_account_conflict')
        uid=account;total+=state['inserted'];proofs.append({'root':str(root),'inserted':state['inserted']})
    if total!=campaign['active_baseline']:raise ValueError('campaign_count_conflict')
    state,config,local,account=prefix(active,ledger,successor)
    if uid is not None and uid!=account:raise ValueError('campaign_account_conflict')
    total+=local;proofs.append({'root':str(active),'inserted':local,'failed_batch_preserved':state['inflight']['batch']})
    remaining=campaign['global_target']-total
    if remaining<=0:raise ValueError('target_already_reached')
    session=Path(session_home).resolve(strict=True)
    identity=read(session/'identity-receipt.json')
    if not (session/'.xiaohongshu-cli/cookies.json').is_file() or identity.get('uid')!=account or identity.get('guest') is not False or identity.get('saved') is not True:
        raise ValueError('verified_same_account_session_required')
    return {'created_at':now(),'campaign_source':str(Path(campaign_path).resolve()),
        'source_segments':proofs,'base_inserted':total,'global_target':campaign['global_target'],
        'remaining_target':remaining,'first_batch':state['next_batch']+1,
        'plan':state['plan'][state['cursor']:],'account_uid':account,'session_home':str(session),
        'ledger':str(ledger),'source_db':config['source_db'],'operator':config.get('operator'),
        'max_comment_pages':config['max_comment_pages'],'failed_root':str(active),
        'failed_batch':state['inflight']['batch'],'failed_batch_reused':False}

def launch(prepared,root):
    live=load('verification_resume_live_runner',PROJECT/'work/xhs-live-collection-runner-20261029/runner.py')
    root=Path(root).resolve()
    runtime=(PROJECT/'work/xhs-account-switch-recovery-candidate/runtime').resolve(strict=True)
    if root==runtime or not root.is_relative_to(runtime):raise ValueError('candidate_runtime_workspace_required')
    root.mkdir(exist_ok=False);write_new(root/'verified-resume-proof.json',prepared)
    result=live.run_task(root,prepared['plan'],session_home=prepared['session_home'],ledger=prepared['ledger'],
        source_db=prepared['source_db'],target=prepared['remaining_target'],first_batch=prepared['first_batch'],
        shared_ledger=True,max_comment_pages=prepared['max_comment_pages'],operator=prepared['operator'])
    receipt={'at':now(),'status':result['status'],'base_inserted':prepared['base_inserted'],
        'local_inserted':result.get('inserted',0),'total_inserted':prepared['base_inserted']+result.get('inserted',0),
        'global_target':prepared['global_target'],'automatic_retry':False,'inflight':result.get('inflight')}
    write_new(root/'cumulative-receipt.json',receipt);return receipt

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign',required=True);parser.add_argument('--session-home',required=True)
    parser.add_argument('--run-home',required=True);parser.add_argument('--execute',action='store_true')
    parser.add_argument('--apply-to-shared-ledger',action='store_true');args=parser.parse_args(argv)
    prepared=prepare(args.campaign,args.session_home)
    if not args.execute:
        print(json.dumps({'mode':'preview','network':False,'ledger_write':False,**prepared},ensure_ascii=False));return 0
    if not args.apply_to_shared_ledger:raise ValueError('explicit_shared_ledger_opt_in_required')
    result=launch(prepared,args.run_home);print(json.dumps(result,ensure_ascii=False))
    return 0 if result['status'] in ('target_reached','paused','plan_exhausted') else 2

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception:
        print(json.dumps({'status':'stopped','automatic_retry':False,'reason':'inspect_resume_evidence'}))
        raise SystemExit(2) from None
