"""Fake 替身：不联网；LiveExecutor 真实写 sqlite 并按 history+账本去重。"""
import json
import sqlite3
from contextlib import closing
import time
from pathlib import Path


class VerificationStop(Exception):
    def __init__(self, http_status=461, reason='verification_required'):
        self.http_status = http_status
        self.reason = reason
        super().__init__(reason)


class SessionStop(Exception):
    def __init__(self, reason='session_deleted'):
        self.reason = reason
        super().__init__(reason)


class FakeClient:
    def __init__(self, home, cache=None, delay=6.0, fail_on_comment=None, clock=None, sleep_fn=None,
                 search_notes=None):
        self.home = Path(home)
        self.cache = cache or {}
        self.delay = float(delay)
        self.fail_on_comment = fail_on_comment
        self.clock = clock or time.monotonic
        self.sleep_fn = sleep_fn if sleep_fn is not None else (lambda s: None)
        self.request_times = []
        self.sleep_log = []
        self.comment_calls = 0
        self.search_calls = 0
        self._last_request_at = None
        self.search_notes = search_notes  # optional fixed note list

    def _throttle(self):
        now = self.clock()
        if self._last_request_at is not None:
            gap = now - self._last_request_at
            need = self.delay - gap
            if need > 0:
                self.sleep_log.append(need)
                self.sleep_fn(need)
                now = self.clock()
        self._last_request_at = now
        self.request_times.append(now)

    def search(self, keyword, page):
        self._throttle()
        self.search_calls += 1
        if self.search_notes is not None:
            return list(self.search_notes)
        return [{'note_id': f'{keyword}-{page}-{i}', 'title': f'Note {i}'} for i in range(10)]

    def comments(self, note_id):
        self._throttle()
        self.comment_calls += 1
        if self.fail_on_comment is not None and self.comment_calls == self.fail_on_comment:
            raise VerificationStop(461)
        return [{'customer': f'customer-{note_id}-{i}', 'comment': f'comment-{i}'} for i in range(3)]

    def close(self):
        pass


class FakeClientFactory:
    def __init__(self, expected_uid, delay=6.0, fail_on_comment=None, clock=None, sleep_fn=None, search_notes=None):
        self.expected_uid = expected_uid
        self.delay = delay
        self.fail_on_comment = fail_on_comment
        self.clock = clock
        self.sleep_fn = sleep_fn
        self.search_notes = search_notes
        self.last_call_uid = None
        self.last_call_delay = None
        self.created_clients = []

    def __call__(self, uid, delay=None):
        if delay is None:
            delay = self.delay
        self.last_call_uid = uid
        self.last_call_delay = delay

        def create(home, cache=None):
            client = FakeClient(
                home, cache, delay=delay,
                fail_on_comment=self.fail_on_comment,
                clock=self.clock,
                sleep_fn=self.sleep_fn or (lambda s: None),
                search_notes=self.search_notes,
            )
            self.created_clients.append(client)
            return client

        return create


class FakeLive:
    def write_new(self, path, data):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def append(self, path, data):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('a', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False) + '\n')

    def now(self):
        return time.strftime('%Y-%m-%dT%H:%M:%S')

    def comment_rows(self, data):
        if isinstance(data, dict) and 'customers' in data:
            return data['customers']
        return data

    class LiveExecutor:
        def __init__(self, root, config, candidate, once, client_factory):
            self.root = Path(root)
            self.config = config
            self.candidate = candidate
            self.once = once
            self.client_factory = client_factory

        def run(self, batch, keyword, page, remaining):
            home = self.config.get('session_home', '.')
            ledger = Path(self.config['ledger'])
            # 与真实 once.main 一样调用 history_index（可被 resume007 包装）
            history = self.once.history_index([str(self.root)], ledger=str(ledger))
            known_notes = set(history.get('completed_notes') or [])
            known_comments = set(history.get('known_comments') or [])

            # 账本已有行也参与去重
            existing = set()
            if ledger.exists():
                with closing(sqlite3.connect(ledger)) as db, db:
                    for c, t in db.execute("SELECT customer, comment FROM leads WHERE platform='xiaohongshu'"):
                        existing.add((c, t))
                        known_comments.add(t)
                        known_comments.add(f'{c}|{t}')

            client = self.client_factory(home)
            try:
                notes = client.search(keyword, page)
                inserted = 0
                skipped_notes = 0
                duplicate_comments = 0
                batch_dir = self.root / batch
                batch_dir.mkdir(exist_ok=True)
                source = 'collection:' + str((batch_dir / 'collection.json').resolve())
                new_rows = []
                for note in notes[:5]:
                    nid = note['note_id']
                    if nid in known_notes:
                        skipped_notes += 1
                        continue
                    for c in client.comments(nid):
                        key_pair = (c['customer'], c['comment'])
                        key_alt = f"{c['customer']}|{c['comment']}"
                        if (
                            c['comment'] in known_comments
                            or key_alt in known_comments
                            or key_pair in existing
                        ):
                            duplicate_comments += 1
                            continue
                        new_rows.append(key_pair)
                        existing.add(key_pair)
                        inserted += 1
                if new_rows:
                    with closing(sqlite3.connect(ledger)) as db, db:
                        db.executemany(
                            "INSERT INTO leads(platform, source, customer, comment) VALUES (?,?,?,?)",
                            [('xiaohongshu', source, c, t) for c, t in new_rows],
                        )
                        db.commit()
                (batch_dir / 'dedup-summary.json').write_text(
                    json.dumps({'skipped_notes': skipped_notes, 'duplicate_comments': duplicate_comments}, ensure_ascii=False),
                    encoding='utf-8',
                )
                (batch_dir / 'collection.json').write_text('{"customers":[]}', encoding='utf-8')
                return {
                    'status': 'registered',
                    'inserted': inserted,
                    'analysis_input': f'{batch}/new-ai-input.json',
                }
            finally:
                client.close()


class FakeOnce:
    def __init__(self, history_index_data=None):
        self.history_index_data = history_index_data or {'completed_notes': [], 'known_comments': []}
        self.last_roots = None
        self.all_roots = []

    def history_index(self, roots, ledger=None):
        roots = list(roots)
        self.last_roots = roots
        self.all_roots.append(roots)
        return dict(self.history_index_data)

    def configure_runtime_cache(self, *args, **kwargs):
        pass

    def install_response_audit(self, *args, **kwargs):
        pass


class FakeScheduling:
    def __init__(self, max_batches=1):
        self.max_batches = max_batches

    def initialize(self, root, plan, first_batch=1, target=10000):
        state = {
            'version': 1,
            'plan': plan,
            'cursor': 0,
            'next_batch': first_batch,
            'target': target,
            'inserted': 0,
            'count_basis': 'comments',
            'rule_source': 'test',
            'created_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'status': 'ready',
            'inflight': None,
        }
        path = Path(root) / 'state.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
        return state

    def run(self, root, executor):
        root = Path(root)
        state_path = root / 'state.json'
        state = json.loads(state_path.read_text(encoding='utf-8'))
        plan = state['plan']
        ran = 0
        while state['cursor'] < len(plan) and ran < self.max_batches:
            batch_num = state['next_batch']
            batch_name = f'batch-{batch_num:04d}'
            item = plan[state['cursor']]
            remaining = state['target'] - state.get('inserted', 0)
            state['inflight'] = {
                'batch': batch_name,
                'keyword': item['keyword'],
                'page': item['page'],
                'remaining': remaining,
            }
            state['status'] = 'inflight'
            state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
            try:
                result = executor.run(batch_name, item['keyword'], item['page'], remaining)
                if not isinstance(result, dict) or result.get('status') != 'registered':
                    raise ValueError('invalid_result')
                state['inserted'] = state.get('inserted', 0) + int(result.get('inserted', 0))
                state['cursor'] += 1
                state['next_batch'] += 1
                state['inflight'] = None
                state['status'] = 'ready' if state['cursor'] < len(plan) else 'plan_exhausted'
                state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
                ran += 1
            except VerificationStop:
                state['status'] = 'outcome_unknown'
                state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
                raise
        return state
