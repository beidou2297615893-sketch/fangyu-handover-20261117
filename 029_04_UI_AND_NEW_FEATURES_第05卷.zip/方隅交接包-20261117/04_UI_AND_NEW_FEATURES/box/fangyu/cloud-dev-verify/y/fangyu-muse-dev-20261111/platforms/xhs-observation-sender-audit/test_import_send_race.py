"""Integration race between isolated importer and sender against one fake ledger.

Uses two real OS processes and a synthetic SQLite database. No platform calls.
"""
import json
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from contextlib import closing
from dataclasses import asdict
from pathlib import Path

import production_sender as sender

ROOT=Path(__file__).resolve().parent
LEDGER=ROOT.parent/'shared-acquisition-ledger'/'ledger.py'
COLLECTOR=ROOT.parent/'xhs-collection-candidate'

WORKER=r'''
import json,sys,time
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import register
import production_sender as sender
class FakeClient:
 def __init__(self,plan): self.plan=plan;self._armed=False;self.calls=0
 def identity(self): pass
 def send_once(self): self.calls+=1;return {'comment':{'id':'SYNTHETIC-RECEIPT'}}
role,db,plan_json,batch_json,mapping_json,ready,gate,wait_for,done=sys.argv[2:]
Path(ready).touch()
deadline=time.monotonic()+15
for path in (gate,wait_for):
 if not path: continue
 while not Path(path).exists():
  if time.monotonic()>deadline: raise RuntimeError('synthetic barrier timeout')
  time.sleep(.005)
if role=='import':
 result=register.register(db,json.loads(batch_json),json.loads(mapping_json),'fixture',apply=True)
 if result['inserted']==1 and result['blocked_customers']==0: print('imported:1')
 elif result['inserted']==0 and result['blocked_customers']==1: print('blocked:0')
 else: raise RuntimeError('unexpected import result')
else:
 plan=sender.SendPlan(**json.loads(plan_json));client=FakeClient(plan)
 try:
  sender.Runner(db,client,synthetic=True).submit(plan)
  print('accepted:'+str(client.calls))
 except sender.Refused:print('blocked:'+str(client.calls))
if done:Path(done).touch()
'''


class ImportSendRaceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT)
        self.base=Path(self.tmp.name)
        self.db=self.base/'synthetic.sqlite3'
        subprocess.run([sys.executable,'-X','utf8',str(LEDGER),'--db',str(self.db),'init'],check=True,capture_output=True)
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token))')
            db.execute("INSERT INTO leads(platform,customer,comment,status,source) VALUES('xiaohongshu','canonical1','comment1','unverified','fixture')")
            db.commit()
        self.plan=sender.SendPlan('same-sender','uid1','note1','comment1','reply','attempt1',True,
                                  'local fixture',int(time.time())+240,'fixture','canonical1')
        self.customer={'customer_id':'canonical2','customer_uid':'uid1','comment_id':'comment2',
                       'note_id':'note2','comment_text':'求租','other_comments':[]}
        self.batch={'schema':'xhs-collected-ai-input-v1','customers':[self.customer]}
        self.mapping={'uid1':'canonical2'}

    def tearDown(self):self.tmp.cleanup()

    def run_pair(self,first=None):
        gate=self.base/'gate'; done=self.base/'first-done'; ready=[self.base/'ready1',self.base/'ready2']
        proc=[]
        for i,role in enumerate(('import','sender')):
            wait_for=str(done) if first and role!=first else ''
            finish=str(done) if first and role==first else ''
            args=[sys.executable,'-X','utf8','-c',WORKER,str(COLLECTOR),role,str(self.db),
                  json.dumps(asdict(self.plan)),json.dumps(self.batch),json.dumps(self.mapping),
                  str(ready[i]),str(gate),wait_for,finish]
            proc.append(subprocess.Popen(args,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True))
        deadline=time.monotonic()+10
        while not all(p.exists() for p in ready):
            if time.monotonic()>deadline:
                for process in proc:process.kill()
                self.fail('process startup timeout')
            time.sleep(.005)
        gate.touch(); outcomes={}
        for role,process in zip(('import','sender'),proc):
            out,err=process.communicate(timeout=20)
            self.assertEqual(process.returncode,0,err)
            outcomes[role]=out.strip()
        return outcomes

    def assert_consistent(self,outcomes):
        self.assertIn(outcomes,[{'import':'imported:1','sender':'blocked:0'},
                                {'import':'blocked:0','sender':'accepted:1'}])
        with closing(sqlite3.connect(self.db)) as db:
            observations=db.execute('SELECT platform_uid,canonical FROM collection_uid_observations').fetchall()
            reservations=db.execute('SELECT customer,status FROM reservations').fetchall()
            new_leads=db.execute("SELECT customer,comment FROM leads WHERE comment='comment2'").fetchall()
        if outcomes['sender']=='accepted:1':
            self.assertEqual(reservations,[('canonical1','unknown')])
            self.assertEqual(observations,[])
            self.assertEqual(new_leads,[])
        else:
            self.assertEqual(reservations,[])
            self.assertEqual(observations,[('uid1','canonical2')])
            self.assertEqual(new_leads,[('canonical2','comment2')])

    def test_import_wins_then_sender_refuses_conflicting_uid(self):
        result=self.run_pair(first='import')
        self.assertEqual(result,{'import':'imported:1','sender':'blocked:0'})
        self.assert_consistent(result)

    def test_sender_wins_then_import_refuses_conflicting_uid(self):
        result=self.run_pair(first='sender')
        self.assertEqual(result,{'import':'blocked:0','sender':'accepted:1'})
        self.assert_consistent(result)

    def test_simultaneous_processes_have_only_one_effect(self):
        self.assert_consistent(self.run_pair())

    def use_same_canonical_other_uid(self):
        self.customer['customer_id']='canonical1'
        self.customer['customer_uid']='uid2'
        self.mapping={'uid2':'canonical1'}

    def test_import_wins_with_same_canonical_and_other_uid(self):
        self.use_same_canonical_other_uid()
        result=self.run_pair(first='import')
        self.assertEqual(result,{'import':'imported:1','sender':'blocked:0'})
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT platform_uid,canonical FROM collection_uid_observations').fetchall(),[('uid2','canonical1')])
            self.assertEqual(db.execute('SELECT count(*) FROM reservations').fetchone()[0],0)

    def test_sender_wins_with_same_canonical_and_other_uid(self):
        self.use_same_canonical_other_uid()
        result=self.run_pair(first='sender')
        self.assertEqual(result,{'import':'blocked:0','sender':'accepted:1'})
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT count(*) FROM collection_uid_observations').fetchone()[0],0)
            self.assertEqual(db.execute('SELECT customer,status FROM reservations').fetchall(),[('canonical1','unknown')])


if __name__=='__main__':unittest.main()
