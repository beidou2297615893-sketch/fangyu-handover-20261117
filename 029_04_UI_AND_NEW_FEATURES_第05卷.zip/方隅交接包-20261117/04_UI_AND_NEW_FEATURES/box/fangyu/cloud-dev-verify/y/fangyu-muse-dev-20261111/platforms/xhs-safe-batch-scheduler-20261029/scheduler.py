"""Offline-only scheduling prototype. No concrete platform executor is shipped.

The injected executor accepts batch, keyword, page, remaining. The remaining
amount is a progress hint only; a completed bounded batch may cross the target.
There is no platform executor and this is not a production entrypoint.
"""
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path


def _now():
    return datetime.now(timezone.utc).isoformat()


def _write_new(path, obj):
    with path.open('x', encoding='utf8') as stream:
        json.dump(obj, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def _replace(path, obj):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        _write_new(temp, obj)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _event(root, kind, **values):
    with (root/'events.jsonl').open('a', encoding='utf8') as stream:
        stream.write(json.dumps({'at':_now(), 'kind':kind, **values}, ensure_ascii=False)+'\n')
        stream.flush()
        os.fsync(stream.fileno())


def read_events(root):
    path = Path(root)/'events.jsonl'
    return [json.loads(line) for line in path.read_text(encoding='utf8').splitlines()] if path.exists() else []


def initialize(root, plan, *, first_batch, target=10000):
    root = Path(root).resolve(strict=True)
    if type(first_batch) is not int or first_batch < 1 or type(target) is not int or target < 1:
        raise ValueError('invalid_target_or_batch')
    if not isinstance(plan,list) or not plan:
        raise ValueError('explicit_nonempty_plan_required')
    clean=[]
    for item in plan:
        if not isinstance(item,dict) or set(item) != {'keyword','page'}:
            raise ValueError('invalid_plan_entry')
        keyword=item['keyword']; page=item['page']
        if not isinstance(keyword,str) or not keyword.strip() or len(keyword)>500 or type(page) is not int or not 1<=page<=100:
            raise ValueError('invalid_plan_entry')
        clean.append({'keyword':keyword,'page':page})
    if len({(entry['keyword'],entry['page']) for entry in clean}) != len(clean):
        raise ValueError('duplicate_plan_entry')
    state={'version':1,'plan':clean,'cursor':0,'next_batch':first_batch,'target':target,
        'inserted':0,'count_basis':'new_registered_unique_comments_since_this_resume',
        'rule_source':'user_resume_new_10000_2026-10-29','created_at':_now(),
        'status':'ready','inflight':None}
    _write_new(root/'state.json',state)
    return state


def run(root, executor):
    root=Path(root).resolve(strict=True)
    lock=root/'scheduler.lock'
    try:
        lock.mkdir()
    except FileExistsError:
        return {'status':'lock_busy'}
    try:
        _write_new(lock/'owner.json',{'pid':os.getpid(),'at':_now()})
        state=json.loads((root/'state.json').read_text(encoding='utf8'))
        if state.get('inflight') is not None or state.get('status')=='outcome_unknown':
            return {**state,'status':'outcome_unknown'}
        while True:
            if state['inserted'] >= state['target']:
                over=state['inserted']-state['target']
                if state['status']!='target_reached':
                    _event(root,'target_reached',inserted=state['inserted'],target=state['target'],over_target=over)
                state['status']='target_reached'; state['over_target']=over; _replace(root/'state.json',state); return state
            if (root/'STOP').exists():
                state['status']='paused'; _replace(root/'state.json',state); return state
            if state['cursor'] >= len(state['plan']):
                state['status']='plan_exhausted'; _replace(root/'state.json',state); return state
            item=state['plan'][state['cursor']]
            batch=f"batch-{state['next_batch']:04d}"
            # A production adapter must independently reject an existing batch at
            # the real candidate workspace, before its first platform request.
            if (root/batch).exists():
                state['status']='batch_already_exists'; _replace(root/'state.json',state); return state
            remaining=state['target']-state['inserted']
            started={'batch':batch,'keyword':item['keyword'],'page':item['page'],'remaining':remaining}
            state['inflight']=started; state['status']='inflight'
            _replace(root/'state.json',state)
            _event(root,'batch_started',**started)
            try:
                result=executor.run(batch,item['keyword'],item['page'],remaining)
                if not isinstance(result,dict) or result.get('status')!='registered':
                    raise ValueError('invalid_result')
                inserted=result.get('inserted')
                source=result.get('analysis_input')
                if type(inserted) is not int or inserted<0:
                    raise ValueError('invalid_inserted')
                if not isinstance(source,str) or source != f'{batch}/new-ai-input.json':
                    raise ValueError('invalid_analysis_source')
            except Exception:
                state['status']='outcome_unknown'
                _event(root,'outcome_unknown',**started)
                _replace(root/'state.json',state)
                return state
            _event(root,'batch_registered',**started,inserted=inserted,analysis_input=source)
            state['inserted']+=inserted
            state['next_batch']+=1
            state['cursor']+=1
            state['inflight']=None
            state['status']='ready'
            _replace(root/'state.json',state)
    finally:
        (lock/'owner.json').unlink(missing_ok=True)
        lock.rmdir()







def reconcile_offline(root, ledger):
    """Reconcile an interrupted synthetic batch; refuses every non-fixture path.

    No platform calls. This is an offline experiment, not a production recovery
    command. A registered receipt, analysis selection and ledger evidence must
    all agree; any ambiguity preserves the in-flight state and stops.
    """
    from contextlib import closing
    import sqlite3

    root=Path(root).resolve(strict=True)
    allowed=(Path(__file__).resolve().parent/'runtime').resolve(strict=True)
    if root==allowed or not root.is_relative_to(allowed):
        raise ValueError('offline_fixture_workspace_required')
    ledger=Path(ledger).resolve(strict=True)
    if not ledger.is_file() or not ledger.is_relative_to(root):
        raise ValueError('offline_fixture_ledger_required')
    scheduler_lock=root/'scheduler.lock'
    try:
        scheduler_lock.mkdir()
    except FileExistsError:
        return {'status':'lock_busy'}
    candidate_lock=root/'.account-switch.lock'
    got_candidate_lock=False
    try:
        try:
            candidate_lock.mkdir()
            got_candidate_lock=True
        except FileExistsError:
            return {'status':'lock_busy'}
        state=json.loads((root/'state.json').read_text(encoding='utf8'))
        started=state.get('inflight')
        if started is None:
            return {**state,'status':'nothing_to_reconcile'}
        def refuse():
            return {**state,'status':'outcome_unknown'}
        try:
            if not isinstance(started,dict) or type(state['cursor']) is not int or not 0<=state['cursor']<len(state['plan']):
                return refuse()
            expected=state['plan'][state['cursor']]
            batch=f"batch-{state['next_batch']:04d}"
            if (started.get('batch')!=batch or started.get('keyword')!=expected['keyword']
                or started.get('page')!=expected['page'] or started.get('remaining')!=state['target']-state['inserted']):
                return refuse()
            folder=(root/batch).resolve(strict=True)
            if not folder.is_dir() or not folder.is_relative_to(root): return refuse()
            def read_json(name):
                path=(folder/name).resolve(strict=True)
                if not path.is_file() or path.parent!=folder: raise ValueError('unsafe_evidence')
                return json.loads(path.read_text(encoding='utf8'))
            account=read_json('account-binding.json')
            collection=read_json('collection.json')
            receipt=read_json('register-result.json')
            ready=read_json('registered-ready.json')
            selected=read_json('new-ai-input.json')
            if (not isinstance(account,dict) or account.get('guest') is not False
                or not isinstance(account.get('uid'),str) or not account['uid']
                or collection.get('collection_account')!=account or receipt.get('account')!=account
                or collection.get('keyword')!=started['keyword']
                or collection.get('collection_task',{}).get('search_page')!=started['page']
                or ready.get('registered') is not True or ready.get('account_uid')!=account['uid']
                or ready.get('input')!='new-ai-input.json'):
                return refuse()
            actual=receipt.get('result',{}).get('inserted')
            if (type(actual) is not int or actual<0 or receipt['result'].get('mode')!='apply'
                or ready.get('inserted_comments')!=actual): return refuse()
            def items(rows):
                if not isinstance(rows,list): raise ValueError('bad_rows')
                result={}
                for row in rows:
                    if not isinstance(row,dict) or not isinstance(row.get('customer_id'),str) or not isinstance(row.get('customer_uid'),str):
                        raise ValueError('bad_row')
                    comments=[row,*row.get('other_comments',[])]
                    for comment in comments:
                        if not isinstance(comment,dict): raise ValueError('bad_comment')
                        key=(row['customer_id'],comment.get('comment_id'))
                        if not all(isinstance(v,str) and v for v in key) or key in result: raise ValueError('bad_key')
                        result[key]=(row['customer_uid'],comment.get('note_id'),comment.get('comment_text'),
                            comment.get('published_at'),comment.get('ip_location'))
                return result
            original=items(collection.get('customers'))
            analysis=items(selected)
            with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
                db.execute('PRAGMA query_only=ON')
                db.execute('BEGIN')
                source='collection:'+str((folder/'collection.json').resolve(strict=True))
                rows=db.execute("SELECT customer,comment FROM leads WHERE platform=? AND source=?",('xiaohongshu',source)).fetchall()
                db.rollback()
            keys=set(rows)
            if len(rows)!=len(keys) or len(keys)!=actual or keys!=set(analysis): return refuse()
            if any(key not in original or original[key]!=analysis[key] for key in keys): return refuse()
            events=read_events(root)
            starts=[e for e in events if e.get('kind')=='batch_started' and e.get('batch')==batch]
            if len(starts)!=1 or any(starts[0].get(key)!=value for key,value in started.items()): return refuse()
            count_events={}
            for event in events:
                if event.get('kind') not in ('batch_registered','batch_recovered'): continue
                name=event.get('batch'); count=event.get('inserted')
                if not isinstance(name,str) or type(count) is not int or count<0: return refuse()
                if name in count_events and count_events[name]!=count: return refuse()
                count_events[name]=count
            first=state['next_batch']-state['cursor']
            if first<1: return refuse()
            prior={f'batch-{number:04d}' for number in range(first,state['next_batch'])}
            if set(count_events)-{batch}!=prior or sum(count_events[name] for name in prior)!=state['inserted']:
                return refuse()
            if batch in count_events and count_events[batch]!=actual: return refuse()
            current=[e for e in events if e.get('kind') in ('batch_registered','batch_recovered') and e.get('batch')==batch]
            for event in current:
                if (any(event.get(key)!=value for key,value in started.items())
                    or event.get('analysis_input')!=f'{batch}/new-ai-input.json'
                    or (event.get('kind')=='batch_recovered' and event.get('account_uid')!=account['uid'])):
                    return refuse()
            recovered=[e for e in current if e.get('kind')=='batch_recovered']
            if len(recovered)>1: return refuse()
            if not recovered:
                _event(root,'batch_recovered',**started,inserted=actual,account_uid=account['uid'],
                       analysis_input=f'{batch}/new-ai-input.json')
            updated=dict(state)
            updated['inserted']+=actual; updated['cursor']+=1; updated['next_batch']+=1
            updated['inflight']=None; updated['status']='ready'
            _replace(root/'state.json',updated)
            return {**updated,'status':'reconciled'}
        except (OSError,ValueError,TypeError,KeyError,AttributeError,IndexError,sqlite3.Error):
            return refuse()
    finally:
        if got_candidate_lock: candidate_lock.rmdir()
        scheduler_lock.rmdir()


