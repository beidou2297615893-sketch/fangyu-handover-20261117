"""Read-only candidate progress window. Never starts any platform/controller.

Explicit opt-in UI: python progress_view.py --root <candidate-state-directory>
Import and load_view are headless and never create a window.
"""
import argparse
import json
from pathlib import Path


_STATUS = {"running": "运行中", "stopped": "已停止", "paused": "已暂停", "blocked": "等待处理",
           "waiting": "等待处理", "idle": "尚未启动", "completed": "已完成", "failed": "异常停止"}


def _read(path, label, errors):
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(value, dict):
            raise ValueError("expected object")
        return value
    except FileNotFoundError:
        errors.append(label + "尚未产生，当前无法确认任务状态")
    except (OSError, ValueError):
        errors.append(label + "无法读取，请待核对")
    return {}


def load_view(root):
    """Load controller-status.json + alerts.json, without mutating any file."""
    root = Path(root)
    errors = []
    status = _read(root / "controller-status.json", "进度记录", errors)
    alerts = _read(root / "alerts.json", "提醒记录", errors)
    lanes = status.get("lanes", {})
    if not isinstance(lanes, dict):
        errors.append("任务进度结构无法读取，请待核对")
        lanes = {}
    result = {}
    for name in ("collect", "send"):
        lane = lanes.get(name, {})
        if not isinstance(lane, dict):
            lane = {}
            errors.append("任务进度结构无法读取，请待核对")
        result[name] = {
            "status": _STATUS.get(lane.get("status", "idle"), "等待核对"),
            "uid": str(lane.get("uid") or "尚未确认"),
            "today_sent": lane.get("today_sent", 0), "success": lane.get("success", 0),
            "failed": lane.get("failed", 0), "unknown": lane.get("unknown", 0),
            "reason": str(lane.get("reason") or "尚无停止原因"),
            "action": str(lane.get("action") or "待核对"),
        }
    alert_items = alerts.get("alerts", [])
    if not isinstance(alert_items, list) or any(not isinstance(item, dict) for item in alert_items):
        errors.append("提醒内容无法读取，请待核对")
        alert_items = []
    return {
        "lanes": result, "alerts": alert_items, "read_errors": errors,
        "severity": "red" if errors or alerts.get("severity") == "red" else "normal",
        "headline": "；".join(errors) if errors else str(alerts.get("headline", "暂无停止提醒")),
        "start_enabled": False,
        "installation_note": "候选未安装到现用任务；本窗只读，启动/继续暂不可用。",
    }


def show_window(root):
    # Import here so offline tests need neither a desktop nor tkinter runtime.
    import tkinter as tk
    from tkinter import ttk
    window = tk.Tk()
    window.title("小红书任务进度 · 独立候选（只读）")
    window.geometry("850x690")
    window.minsize(690, 500)
    headline = tk.Label(window, text="正在读取候选进度", anchor="w", justify="left", wraplength=800,
                        bg="#a11321", fg="white", font=("Microsoft YaHei UI", 14, "bold"), padx=16, pady=14)
    headline.pack(fill="x")
    tk.Label(window, text="候选未安装到现用任务；本窗只读，启动/继续暂不可用。", anchor="w", padx=16, pady=10).pack(fill="x")
    panels = {}
    for key, title in (("collect", "采集"), ("send", "回复")):
        frame = ttk.LabelFrame(window, text=title, padding=12)
        frame.pack(fill="x", padx=16, pady=5)
        label = ttk.Label(frame, text="等待记录", justify="left", wraplength=760)
        label.pack(anchor="w")
        panels[key] = label
    ttk.Button(window, text="启动 / 继续（未安装）", state="disabled").pack(anchor="w", padx=16, pady=8)
    body = tk.Text(window, height=12, wrap="word", bg="#fff2f3", fg="#9b1420", font=("Microsoft YaHei UI", 10))
    body.pack(fill="both", expand=True, padx=16, pady=(0, 16))

    def refresh():
        model = load_view(root)
        headline.configure(text=model["headline"], bg="#a11321" if model["severity"] == "red" else "#287252")
        for key, label in panels.items():
            lane = model["lanes"][key]
            label.configure(text=(f"状态：{lane['status']}　账号UID：{lane['uid']}\n"
                                  f"今日已发：{lane['today_sent']}　成功：{lane['success']}　失败：{lane['failed']}　未知待核对：{lane['unknown']}\n"
                                  f"停止原因：{lane['reason']}\n下一步：{lane['action']}"))
        lines = list(model["read_errors"])
        for item in model["alerts"]:
            delivery = {"submitted": "已提交系统通知，是否看见/听见待本人确认", "failed": "系统通知失败", "unknown": "通知投递待核对，不自动重发"}.get(item.get("delivery_status"), "投递待核对")
            lines.append(f"【{item.get('lane', '任务')}已停止】{item.get('reason', '待核对')}\n下一步：{item.get('action', '待核对')}\n{delivery}")
            if item.get("delivery_error"):
                lines.append("通知未送达，请查看本页并待核对。")
        body.configure(state="normal")
        body.delete("1.0", "end")
        body.insert("1.0", "\n\n".join(lines) or "暂无停止提醒")
        body.configure(state="disabled")
        window.after(2000, refresh)

    refresh()
    window.mainloop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="只读候选任务进度；不启动平台任务")
    parser.add_argument("--root", required=True)
    show_window(Path(parser.parse_args().root))
