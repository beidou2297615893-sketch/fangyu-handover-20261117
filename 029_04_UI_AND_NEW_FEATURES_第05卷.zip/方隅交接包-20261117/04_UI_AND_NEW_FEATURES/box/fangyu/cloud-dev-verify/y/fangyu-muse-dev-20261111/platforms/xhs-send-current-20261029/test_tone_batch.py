import json, hashlib, sqlite3, unittest
from contextlib import closing
from dataclasses import asdict, replace
from datetime import datetime, timedelta, timezone
from unittest.mock import patch
import httpx
import bulk_run as bulk
import scoped_isolation as scope
import tone_singleton as cat
import tone_batch as batch_policy
import test_tone_singleton as base
from prepare_logged_sender import load_cli
from managed_send_client import make_client


class Tests(unittest.TestCase):
    def setUp(self):
        self.base = base.Tests('test_exact_new_tone_scope_allows_only_one_pending_target_preserving_22_records')
        self.base.setUp(); t = self.base; b = t.base
        self.rows = []
        original_rows = []
        for i in range(566):
            row = {'attempt_id':'original-'+str(i),'customer_id':'customer-'+str(i),'customer_uid':'uid-'+str(i),
                'comment_id':'comment-'+str(i),'note_id':'note-'+str(i),'text':'old approved'}
            original_rows.append(row)
            if i < 136:self.rows.append({**row,'attempt_id':'batch-'+str(i),'text':'new approved '+str(i)})
        original_cat = {**b.row,'comment_id':cat.TARGET_COMMENT}
        original_rows.append(original_cat)
        self.rows.append({**original_cat,'attempt_id':'new-batch-cat','text':cat.TEXT})
        original = bulk.read_json(b.approved); original['rows'] = original_rows
        b.approved.write_text(json.dumps(original),encoding='utf8')
        self.ready = b.root/'ready.jsonl'
        self.ready.write_text('\n'.join(json.dumps(row) for row in self.rows),encoding='utf8')
        self.approval = b.root/'approval137.json'
        self.approval.write_text(json.dumps({'schema':'xhs-approved-tone-entry-v1','source':str(self.ready),
            'source_sha256':bulk.digest(self.ready),'entries':self.rows}),encoding='utf8')
        self.batch = b.root/'batch137.json'
        self.batch.write_text(json.dumps({'schema':'xhs-local-plan-v1','intended_account_uid':b.uid,'count':137,
            'source_sha256':{'original_batch':bulk.digest(b.approved),'tone_approval':bulk.digest(self.approval),
                'exclusions':bulk.digest(t.exclusions)},'rows':self.rows}),encoding='utf8')
        proof = {'plan':asdict(t.plan),'result':{'kind':'platform_receipt','receipt_id':batch_policy.PROOF_RECEIPT}}
        self.proof_raw = json.dumps(proof)
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',(cat.ALLOWED_ATTEMPT,'xiaohongshu',
                t.plan.canonical_customer,t.plan.comment_id,'unknown','receipt',23))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',(cat.ALLOWED_ATTEMPT,self.proof_raw))
            db.execute('UPDATE leads SET status=? WHERE comment=?',('unknown',cat.TARGET_COMMENT))
            db.execute('INSERT INTO leads VALUES(?,?,?,?,NULL,NULL,NULL,?)',('xiaohongshu','customer-0','comment-0','unverified','synthetic'))
            db.commit()
        for path in (b.state,b.marker,t.revoked):
            state=bulk.read_json(path);state['halted_at']=(datetime.now(timezone.utc)-timedelta(hours=1)).isoformat()
            path.write_text(json.dumps(state),encoding='utf8')
        self.event=b.root/'proof-cat.json'
        self.event.write_text(json.dumps({'event':'accepted','sender_uid':b.uid,'attempt_id':cat.ALLOWED_ATTEMPT,
            'receipt_id':batch_policy.PROOF_RECEIPT,'at':datetime.now(timezone.utc).isoformat(),
            'diagnostic':{'success':True,'http_status':200,'api_code':0,'verification_header_present':False}}),encoding='utf8')
        self.constants=patch.multiple(batch_policy,BATCH_SHA=bulk.digest(self.batch),TONE_SHA=bulk.digest(self.approval),
            READY_SHA=bulk.digest(self.ready),PROOF_RECORD_SHA=hashlib.sha256(self.proof_raw.encode()).hexdigest(),PROOF_EVENT_SHA=bulk.digest(self.event))
        self.constants.start();self.original=patch.object(scope,'APPROVED_SHA',bulk.digest(b.approved));self.original.start()
        data=asdict(t.policy)
        for key in ('singleton_batch_sha256','allowed_attempt_id'):data.pop(key)
        data.update(schema='xhs-two-unknown-new-tone-137-qualified-v1',policy_id='huihui-new-tone-137-cat-receipt-qualified-20261101-v1',
            original_batch_sha256=bulk.digest(b.approved),batch_sha256=bulk.digest(self.batch),tone_approval_path=str(self.approval),
            tone_approval_sha256=bulk.digest(self.approval),platform_state_sha256=bulk.digest(b.state),
            halt_marker_sha256=bulk.digest(b.marker),revocation_sha256=bulk.digest(t.revoked),
            proof_attempt_id=cat.ALLOWED_ATTEMPT,proof_record_raw_sha256=batch_policy.PROOF_RECORD_SHA,
            proof_receipt_id=batch_policy.PROOF_RECEIPT,proof_event_path=str(self.event),proof_event_sha256=bulk.digest(self.event))
        self.policy=batch_policy.NewToneBatchReceiptPolicy.from_mapping(data)
        self.plan=replace(t.plan,attempt_id='batch-0',canonical_customer='customer-0',customer_uid='uid-0',comment_id='comment-0',note_id='note-0',text='new approved 0')
        b.sender.PREPARED_BATCH=self.batch

    def tearDown(self):
        self.original.stop();self.constants.stop();self.base.tearDown()

    def reserve(self,policy=None,plan=None):
        b=self.base.base
        b.sender._reserve(b.db,plan or self.plan,True,direct_id=True,scoped_isolation_policy=policy)

    def test_receipt_qualified_137_allows_pending_and_cat_dedup_skips(self):
        b=self.base.base
        with self.assertRaises(b.sender.Refused):self.reserve()
        before=b.state.read_bytes(),b.marker.read_bytes(),self.base.revoked.read_bytes()
        bulk.require_platform_access(b.state,b.uid,scoped_grant=self.policy,batch_path=self.batch)
        self.reserve(self.policy)
        cli=load_cli()
        self.assertEqual(cli.row_state(self.rows[-1],cli.ledger_states(b.db)),'accepted')
        self.assertEqual((b.state.read_bytes(),b.marker.read_bytes(),self.base.revoked.read_bytes()),before)

    def test_wrong_proof_or_modified_text_or_new_unknown_still_blocks(self):
        b=self.base.base
        for policy in (replace(self.policy,proof_record_raw_sha256='0'*64),replace(self.policy,proof_receipt_id='wrong')):
            with self.assertRaises(b.sender.Refused):self.reserve(policy)
        with self.assertRaises(b.sender.Refused):self.reserve(self.policy,replace(self.plan,text='changed'))
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',('new-unknown','xiaohongshu','extra','extra-comment','unknown',None,24))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',('new-unknown',json.dumps({'plan':{'sender_uid':b.uid,'customer_uid':'extra-uid'},'result':{'kind':'unknown'}})))
            db.commit()
        with self.assertRaises(b.sender.Refused):self.reserve(self.policy)

    def test_later_revocation_always_blocks_137_policy(self):
        scope.revocation_path(self.base.revoked).write_text('{}',encoding='utf8')
        with self.assertRaises(bulk.Stop):bulk.require_platform_access(self.base.base.state,self.base.base.uid,
            scoped_grant=self.policy,batch_path=self.batch)

    def test_actual_sender_one_post_uses_frozen_batch_text_and_preserves_cat_proof(self):
        b=self.base.base
        session=b.root/'synthetic-batch-session.json'
        session.write_text(json.dumps({'a1':'synthetic','web_session':'synthetic','webId':'synthetic'}),encoding='utf8')
        calls=[]
        def response(request):
            calls.append(request)
            data={'user_id':b.uid,'guest':False} if request.method=='GET' else {'comment':{'id':'synthetic-batch-receipt'}}
            return httpx.Response(200,json={'success':True,'code':0,'data':data})
        with make_client(b.sender,session,self.plan,transport=httpx.MockTransport(response)) as client:
            result=b.sender.Runner(b.db,client,synthetic=True,direct_id=True,scoped_isolation_policy=self.policy).submit(self.plan)
        self.assertEqual(result,'receipt_received_unverified')
        posts=[r for r in calls if r.method=='POST']
        self.assertEqual(len(posts),1)
        self.assertEqual(json.loads(posts[0].content)['content'],self.rows[0]['text'])
        with closing(sqlite3.connect(b.db)) as db:
            self.assertEqual(db.execute('SELECT data FROM local_sender_plans WHERE token=?',(cat.ALLOWED_ATTEMPT,)).fetchone()[0],self.proof_raw)


if __name__=='__main__':unittest.main()
