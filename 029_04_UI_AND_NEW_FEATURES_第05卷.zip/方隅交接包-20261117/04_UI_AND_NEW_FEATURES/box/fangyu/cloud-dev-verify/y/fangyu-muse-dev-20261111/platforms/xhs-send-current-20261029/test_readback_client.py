import json
from pathlib import Path
import socket,tempfile,unittest
from unittest.mock import patch
from urllib.parse import parse_qs
import httpx
from readback_client import ReadbackClient,ReadbackStop,match_receipt

HERE=Path(__file__).resolve().parent
UID='synthetic-sender'
IDENTITY='/api/sns/web/v2/user/me'
SUB='/api/sns/web/v2/comment/sub/page'
NORMAL='/api/sns/web/v2/comment/page'
class Tests(unittest.TestCase):
 def setUp(self):
  self.guard=patch.object(socket.socket,'connect',side_effect=AssertionError('network_forbidden'));self.guard.start()
  self.tmp=tempfile.TemporaryDirectory(dir=HERE);self.session=Path(self.tmp.name)/'cookies.json';self.session.write_text(json.dumps({'a1':'synthetic-a1','webId':'synthetic-web','web_session':'synthetic-session'}))
  self.calls=[]
 def tearDown(self):self.tmp.cleanup();self.guard.stop()
 def response(self,request,data=None):
  return httpx.Response(200,json={'success':True,'data':data if data is not None else ({'user_id':UID,'guest':False} if request.url.path==IDENTITY else {'comments':[],'has_more':False,'cursor':''})})
 def client(self,handler=None):
  def call(r):self.calls.append(r);return (handler or self.response)(r)
  return ReadbackClient(self.session,UID,transport=httpx.MockTransport(call),delay=0)
 def test_explicit_note_token_root_cursor_num_and_identity(self):
  with self.client() as client:data=client.read_subcomments('synthetic-note','synthetic-root','synthetic-token',cursor='cursor-one',num=13)
  self.assertEqual([r.url.path for r in self.calls],[IDENTITY,SUB])
  self.assertEqual(dict(self.calls[1].url.params),{'note_id':'synthetic-note','root_comment_id':'synthetic-root','num':'13','cursor':'cursor-one','image_formats':'jpg,webp,avif','top_comment_id':'','xsec_token':'synthetic-token'})
  self.assertEqual(data['comments'],[])
 def test_missing_token_refuses_before_identity_or_sub_request(self):
  with self.client() as client:
   with self.assertRaises(ValueError):client.read_subcomments('note','root','')
  self.assertEqual(self.calls,[])
 def test_limits_461_429_and_expired_session_are_comments_and_never_retry(self):
  for mode in (461,429,-100):
   with self.subTest(mode=mode):
    self.calls=[]
    def handler(r):
     if r.url.path==IDENTITY:return self.response(r)
     return httpx.Response(mode if mode>0 else 200,json={'success':False,'code':mode})
    with self.client(handler) as client:
     try:client.read_subcomments('note','root','token')
     except Exception as exc:diagnostic=client.diagnostic(exc)
     else:self.fail('read must stop')
     with self.assertRaises(Exception):client.read_subcomments('note','root','token')
    self.assertEqual([r.url.path for r in self.calls],[IDENTITY,SUB])
    self.assertEqual(diagnostic['platform']['stage'],'comments')
    self.assertEqual(diagnostic['platform']['endpoint'],'comments')
    if mode>0:self.assertEqual(diagnostic['platform']['http_status'],mode)
    else:self.assertEqual(diagnostic['platform']['api_code'],-100)
    self.assertIs(diagnostic['retry_allowed'],False)
 def test_wrong_uid_or_guest_stops_before_comment_request(self):
  for identity in ({'user_id':'other','guest':False},{'user_id':UID,'guest':True}):
   self.calls=[]
   with self.client(lambda r:self.response(r,identity)) as client:
    with self.assertRaises(Exception):client.read_subcomments('note','root','token')
   self.assertEqual([r.url.path for r in self.calls],[IDENTITY])
 def test_normal_comments_require_explicit_token_and_no_fallback(self):
  with self.client() as client:
   with self.assertRaises(ValueError):client.get_comments('note')
   self.assertEqual(self.calls,[])
   client.get_comments('note',cursor='cursor',xsec_token='token',top_comment_id='root')
  self.assertEqual([r.url.path for r in self.calls],[IDENTITY,NORMAL])
  self.assertEqual(self.calls[1].url.params['xsec_token'],'token')
 def test_repeated_cursor_stops_before_third_page(self):
  def handler(r):
   return self.response(r) if r.url.path==IDENTITY else self.response(r,{'comments':[],'has_more':True,'cursor':'same-cursor'})
  with self.client(handler) as client:
   with self.assertRaises(ReadbackStop):list(client.iter_subcomment_pages('note','root','token',max_pages=10))
  self.assertEqual([r.url.path for r in self.calls],[IDENTITY,SUB,SUB])
 def test_get_all_and_other_endpoints_are_not_enabled(self):
  with self.client() as client:
   with self.assertRaises(Exception):client.get_all_comments('note',xsec_token='token')
   with self.assertRaises(Exception):client._main_api_get('/api/sns/web/v1/feed',{})
  self.assertEqual(self.calls,[])

class Matching(unittest.TestCase):
 def row(self):return {'id':'receipt','content':'exact approved text','user_info':{'user_id':UID},'target_comment':{'id':'root'}}
 def match(self,row):return match_receipt(row,reply_id='receipt',sender_uid=UID,root_comment_id='root',text='exact approved text')
 def test_four_exact_fields_verify_receipt(self):self.assertEqual(self.match(self.row())['status'],'verified')
 def test_wrong_uid_text_id_or_relation_remains_unknown(self):
  for field,value in [('id','other'),('content','changed'),('user_info',{'user_id':'other'}),('target_comment',{'id':'other'})]:
   row=self.row();row[field]=value
   with self.subTest(field=field):self.assertEqual(self.match(row)['status'],'unknown')
 def test_missing_or_conflicting_root_never_verifies(self):
  row=self.row();del row['target_comment'];self.assertEqual(self.match(row)['status'],'unknown')
  row=self.row();row['root_comment_id']='other';self.assertEqual(self.match(row)['status'],'unknown')
if __name__=='__main__':unittest.main()
