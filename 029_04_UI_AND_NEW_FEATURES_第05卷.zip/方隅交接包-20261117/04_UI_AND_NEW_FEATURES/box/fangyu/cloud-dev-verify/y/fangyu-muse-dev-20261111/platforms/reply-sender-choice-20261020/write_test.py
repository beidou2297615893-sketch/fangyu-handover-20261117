from pathlib import Path
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/reply-sender-choice-20261020')
p=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/overnight-verification/round-10-batch-sop/test_batch.mjs')
s=p.read_text('utf-8').split('const cancelled=fixture();')[0].replace('const {bindBatch}=','const {bindBatch,renderBatch}=')
s=s.replace("const ctx={state,", "state.platform={accounts:[{id:'account-a',platform:'xiaohongshu',status:'ready',name:'一号备注',platformNickname:'小红薯甲'},{id:'account-b',platform:'xiaohongshu',status:'ready',name:'二号备注',platformNickname:'小红薯乙'},{id:'dy',platform:'douyin',status:'ready',name:'抖音号'}]};\n const ctx={state,")
s=s.replace("const root={querySelector:q=>q==='[data-batch-prepare]'?{addEventListener:(type,fn)=>handlers.prepare=fn}:null,", "const root={querySelector:q=>({'[data-batch-prepare]':'prepare','[data-batch-account]':'account'}[q]?{addEventListener:(type,fn)=>handlers[{'[data-batch-prepare]':'prepare','[data-batch-account]':'account'}[q]]=fn}:null),")
s+=r'''
const missing=fixture();await missing.handlers.prepare();assert.equal(missing.calls.length,0,'batch must require an explicit sender before reading/saving');assert.match(missing.toasts[0],/选择.*发送账号/);
const html=renderBatch(missing.state,missing.v);assert.match(html,/批量发送账号/);assert.match(html,/小红薯乙/);assert.ok(!html.includes('抖音号'));
const normal=fixture();normal.v.accountId='account-a';normal.handlers.account({target:{value:'account-b'}});await normal.handlers.prepare();assert.match(normal.modals[0].html,/本批发送账号/);assert.match(normal.modals[0].html,/小红薯乙/);assert.equal(normal.drafts.size,0);await normal.modals[0].onConfirm();assert.equal(normal.drafts.size,2);assert.ok([...normal.drafts.values()].every(d=>d.review_account_id==='account-b'));assert.match(normal.modals.at(-1).html,/本批发送账号/);assert.match(normal.modals.at(-1).html,/发送账号：/);assert.ok(!normal.calls.includes('start'));
const stale=fixture();stale.handlers.account({target:{value:'account-b'}});await stale.handlers.prepare();stale.handlers.account({target:{value:'account-a'}});assert.equal(await stale.modals[0].onConfirm(),false);assert.equal(stale.drafts.size,0,'changing sender invalidates old preview');
console.log('PASS: explicit uniform sender, platform-scoped nickname choices, captured account B, visible final account, stale preview rejected, no sends');
'''
(T/'test_sender.mjs').write_text(s,encoding='utf-8')
