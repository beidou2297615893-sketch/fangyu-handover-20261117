"""One explicitly requested original-account read check; no retry or writes to ledger."""
import importlib.util
import json
import logging
import re
from pathlib import Path
import sys
from datetime import datetime, timezone

PROJECT=Path(__file__).resolve().parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value

def main():
    logging.disable(logging.CRITICAL)
    run_name=sys.argv[1] if len(sys.argv)>1 else 'single-recheck-001'
    if not re.fullmatch(r'single-recheck-[0-9]{3}',run_name):
        raise ValueError('dedicated_check_name_required')
    root=Path(__file__).parent/run_name
    root.mkdir(exist_ok=False)
    report={'at':datetime.now(timezone.utc).isoformat(),'status':'started',
        'automatic_retry':False,'registered_new':0,'requests':[],
        'official_help':'Website help is a feedback form; no documented recovery duration found.'}
    def save():
        (root/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    save()
    client=None
    try:
        live=module('single_check_live',PROJECT/'work/xhs-live-collection-runner-20261029/runner.py')
        account,once,_=live.components()
        collector,_=account.dependencies()
        importer=module('single_check_profile',PROJECT/'work/xhs-verified-profile-import-20261029/profile_import.py')
        if len(sys.argv)>2:
            if sys.argv[2]!='saved-original-session':
                raise ValueError('unsupported_session_source')
            config=live.read(PROJECT/'work/xhs-account-switch-recovery-candidate/runtime/resume-new10000-20261029-batch42/task-config.json')
            cookies=once.load_cookies(Path(config['session_home']))
            report['session_source']='previously_verified_original_cli_session'
        else:
            cookies=importer.load_profile(Path('C:/Users/rmsama/AppData/Local/Temp/playwright_firefoxdev_profile-CroKpm'))
            report['session_source']='existing_browser_profile'
        once.configure_runtime_cache(root/'runtime-cache')
        class Bounded(collector.ReadClient):
            def _request_with_retry(self,method,url,**kwargs):
                from urllib.parse import urlsplit
                path=urlsplit(url).path
                kind='comments' if path.endswith('/comment/page') else ('identity' if path.endswith('/user/me') else 'search')
                if len(report['requests'])>=7 or (kind=='comments' and any(x['kind']=='comments' for x in report['requests'])):
                    raise collector.Halt('local_request_budget_exhausted')
                report['requests'].append({'kind':kind,'started':True}); save()
                return super()._request_with_retry(method,url,**kwargs)
        client=Bounded(cookies,delay=3.0)
        def observed(response):
            report['requests'][-1]['http_status']=response.status_code
            if response.status_code!=200:
                client.last_failure_detail={'error_type':'HTTPError','http_status':response.status_code,
                    'stage':client._last_stage,'endpoint':client._last_endpoint_kind,'request_started':True}
            save()
        client._http.event_hooks['response'].append(observed)
        identity=account.identify(client.get_self_info())
        if identity['uid']!='5f469df5000000000101ec0b':
            raise account.Refused('account_changed_no_retry')
        report['original_account_verified']=True; save()
        notes=collector.note_items(live.search_without_recommend(client,'红松东路租房',page=2),20)
        note=next((n for n in notes if n['note_id']=='6adb4cbf000000003103abf1'),None)
        if not note or not note['token']:
            report['status']='original_note_not_in_current_page'; return
        report['note_id']=note['note_id']; save()
        data=client.get_comments(note['note_id'],cursor='',xsec_token=note['token'])
        if not isinstance(data,dict) or not isinstance(data.get('comments'),list):
            raise collector.Halt('comment_shape_invalid')
        def clean(value):
            if isinstance(value,dict):
                return {k:clean(v) for k,v in value.items() if not any(s in k.lower() for s in ('token','cookie','authorization','secret'))}
            if isinstance(value,list): return [clean(v) for v in value]
            return value
        (root/'unregistered-comments.json').write_text(json.dumps(clean(data),ensure_ascii=False),encoding='utf8')
        report['status']='one_comment_page_read_succeeded'
        report['comments_received']=len(data['comments'])
    except Exception as exc:
        report['status']='stopped'
        if client is not None:
            report['diagnostic']=account.safe_failure(client,exc)
        else: report['diagnostic']={'category':'local_preflight_failed','retry_allowed':False}
    finally:
        if client is not None: client.close()
        save()
        print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__': main()
