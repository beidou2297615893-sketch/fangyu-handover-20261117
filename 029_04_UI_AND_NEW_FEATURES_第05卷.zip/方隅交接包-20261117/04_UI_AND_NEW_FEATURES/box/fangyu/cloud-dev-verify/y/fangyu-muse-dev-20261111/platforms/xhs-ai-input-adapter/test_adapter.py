import json
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest

import adapter


class InputAdapterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.db = Path(self.tmp.name) / 'synthetic.sqlite3'
        with closing(sqlite3.connect(self.db)) as conn, conn:
            conn.execute('CREATE TABLE records(entity TEXT,id TEXT,tenant_id TEXT,body TEXT)')
            self.add(conn, 'leads', 'l1', dict(id='l1',platform='xiaohongshu',comment_id='c1',author_id='u1',text='我想租房',published_at='2026-10-01',parent_id='c2',note_url='https://www.xiaohongshu.com/explore/123456789012345678901234?xsec_token=SECRET',content_title='古北房源'))
            self.add(conn, 'leads', 'l2', dict(id='l2',platform='xiaohongshu',comment_id='c2',author_id='u2',text='别人的话',published_at='2026-10-01',parent_id='',note_url='https://www.xiaohongshu.com/explore/123456789012345678901234?xsec_token=OTHER',content_title='古北房源'))
            self.add(conn, 'customer_intent_projection_v1', 'p1', dict(customer_id='h1',platform='xiaohongshu',members=[{'lead_id':'l1'}],customer={'representativeLeadId':'l1','interestLevel':'high'}))
            self.add(conn, 'customer_intent_projection_v1', 'p2', dict(customer_id='h2',platform='xiaohongshu',members=[{'lead_id':'l2'}],customer={'representativeLeadId':'l2'}))

    def tearDown(self): self.tmp.cleanup()

    @staticmethod
    def add(conn, entity, ident, value):
        conn.execute('INSERT INTO records VALUES(?,?,?,?)', (entity, ident, 't1', json.dumps(value,ensure_ascii=False)))

    def test_attribution_and_no_url_token(self):
        result=adapter.extract(self.db, None, 'account-1')
        c=next(x for x in result['customers'] if x['customer_id']=='h1')
        comment=c['comments'][0]
        self.assertEqual(comment['text'],'我想租房')
        self.assertEqual(comment['author_uid'],'u1')
        self.assertEqual(comment['parent']['text'],'别人的话')
        self.assertEqual(comment['parent']['author_uid'],'u2')
        self.assertEqual(comment['parent']['relationship'],'root_or_parent_not_direct_verified')
        self.assertEqual(comment['post']['note_id'],'123456789012345678901234')
        self.assertIn('post_body_missing',comment['missing_context'])
        self.assertEqual(c['account']['uid'],'account-1')
        self.assertNotIn('SECRET',json.dumps(result,ensure_ascii=False))
        self.assertNotIn('OTHER',json.dumps(result,ensure_ascii=False))

    def test_uid_conflict_and_missing_member_block(self):
        with closing(sqlite3.connect(self.db)) as conn, conn:
            self.add(conn,'customer_intent_projection_v1','p3',dict(customer_id='h3',platform='xiaohongshu',members=[{'lead_id':'l1'},{'lead_id':'l2'},{'lead_id':'missing'}],customer={'representativeLeadId':'l1'}))
        row=next(x for x in adapter.extract(self.db,None,None)['customers'] if x['customer_id']=='h3')
        self.assertEqual(row['state'],'needs_review')
        self.assertIsNone(row['platform_uid'])
        self.assertIn('missing_member',row['issues'])
        self.assertIn('platform_uid_conflict',row['issues'])

    def test_batch_target_and_account_mapping_must_match(self):
        batch={'intended_account_uid':'account-1','rows':[{'customer_id':'h1','customer_uid':'u9','comment_id':'c1','note_id':'123456789012345678901234'}]}
        result=adapter.extract(self.db,batch,'account-1')
        self.assertEqual(result['customers'][0]['state'],'needs_review')
        self.assertIn('batch_uid_mismatch',result['customers'][0]['issues'])
        batch['rows'][0]['customer_uid']='u1'
        self.assertEqual(adapter.extract(self.db,batch,'account-1')['customers'][0]['state'],'ready')
        with self.assertRaises(ValueError): adapter.extract(self.db,batch,'different-account')

    def test_missing_original_text_and_unresolvable_parent_require_review(self):
        with closing(sqlite3.connect(self.db)) as conn, conn:
            row=dict(id='l1',platform='xiaohongshu',comment_id='c1',author_id='u1',text='',published_at='',parent_id='absent',note_url='',content_title='')
            conn.execute('UPDATE records SET body=? WHERE id=?',(json.dumps(row),'l1'))
        c=next(x for x in adapter.extract(self.db,None,None)['customers'] if x['customer_id']=='h1')
        self.assertEqual(c['state'],'needs_review')
        self.assertIn('comment_text_missing',c['issues'])
        self.assertIsNone(c['comments'][0]['parent']['text'])
        self.assertIn('parent_not_available',c['comments'][0]['missing_context'])

    def test_bad_batch_cannot_duplicate_customer_or_guess_missing_id(self):
        with self.assertRaises(ValueError):adapter.extract(self.db,{'rows':[{'customer_id':'h1'},{'customer_id':'h1'}]},None)
        with self.assertRaises(ValueError):adapter.extract(self.db,{'rows':[{}]},None)

    def test_no_db_mutation(self):
        before=self.db.read_bytes()
        adapter.extract(self.db,None,None)
        self.assertEqual(before,self.db.read_bytes())

    def test_note_id_rejects_other_domains(self):
        self.assertIsNone(adapter.note_id('https://other.example/explore/123456789012345678901234'))
        self.assertIsNone(adapter.note_id('https://www.xiaohongshu.com.evil.example/explore/123456789012345678901234'))

    def test_pipeline_rows_preserve_target_and_separate_parent(self):
        contexts=adapter.extract(self.db,None,'account-1')
        rows=adapter.pipeline_rows(contexts, set())
        c=next(x for x in rows if x['customer_id']=='h1')
        self.assertEqual(c['customer_uid'],'u1')
        self.assertEqual(c['comment_id'],'c1')
        self.assertEqual(c['comment_text'],'我想租房')
        self.assertEqual(c['parent_text'],'别人的话')
        self.assertEqual(c['parent_relationship'],'root_or_parent_not_direct_verified')
        self.assertEqual(c['post_text'],'')
        self.assertIn('post_body_missing',c['missing_context'])
        self.assertEqual(adapter.pipeline_rows(contexts,{'h1'})[0]['customer_id'],'h2')

    def test_shared_ledger_block_preserves_other_customers(self):
        ledger=Path(self.tmp.name)/'ledger.sqlite3'
        with closing(sqlite3.connect(ledger)) as conn, conn:
            conn.executescript('CREATE TABLE leads(platform,customer,status);CREATE TABLE reservations(platform,customer,status);CREATE TABLE historical_deliveries(platform,customer,delivery_state);CREATE TABLE identity_aliases(platform,alias,canonical);')
            conn.execute('INSERT INTO leads VALUES(?,?,?)',('xiaohongshu','h1','unknown'))
            conn.execute('INSERT INTO leads VALUES(?,?,?)',('xiaohongshu','h2','unverified'))
        contexts=adapter.extract(self.db,None,'account-1')
        self.assertEqual(adapter.blocked_customers(ledger,contexts['customers']),{'h1'})
        rows=adapter.pipeline_rows(contexts,adapter.blocked_customers(ledger,contexts['customers']))
        self.assertEqual([x['customer_id'] for x in rows],['h2'])

    def test_incomplete_other_comment_is_not_silently_discarded(self):
        with closing(sqlite3.connect(self.db)) as conn, conn:
            self.add(conn,'leads','l3',dict(id='l3',platform='xiaohongshu',comment_id='c3',author_id='u1',text='',published_at='',parent_id='',note_url='https://www.xiaohongshu.com/explore/123456789012345678901234',content_title=''))
            row=dict(customer_id='h1',platform='xiaohongshu',members=[{'lead_id':'l1'},{'lead_id':'l3'}],customer={'representativeLeadId':'l1'})
            conn.execute('UPDATE records SET body=? WHERE id=?',(json.dumps(row),'p1'))
        result=adapter.extract(self.db,None,'account-1')
        person=next(x for x in result['customers'] if x['customer_id']=='h1')
        self.assertEqual(len(person['comments']),2)
        self.assertNotIn('h1',{x['customer_id'] for x in adapter.pipeline_rows(result,set())})

    def test_whitespace_source_text_is_flagged_not_silently_changed(self):
        with closing(sqlite3.connect(self.db)) as conn, conn:
            body=json.loads(conn.execute("SELECT body FROM records WHERE id='l1'").fetchone()[0])
            body['text']=' 原话 '
            conn.execute('UPDATE records SET body=? WHERE id=?',(json.dumps(body),'l1'))
        result=adapter.extract(self.db,None,'account-1')
        self.assertNotIn('h1',{x['customer_id'] for x in adapter.pipeline_rows(result,set())})


if __name__=='__main__': unittest.main(verbosity=2)
