"""Pure read-only audit of caller-provided, verified send evidence."""
from collections import Counter
from datetime import datetime,timezone,timedelta

BEIJING=timezone(timedelta(hours=8))

def from_ledger(ledger,work,day,video_run_limit=None):
    import json,sqlite3
    from contextlib import closing
    from round_reconstruct import read_task
    with closing(sqlite3.connect(ledger.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute("SELECT platform,token,comment,customer,status,evidence FROM reservations WHERE platform IN ('douyin','xiaohongshu') AND status IN ('sent','unknown')").fetchall()
    tasks=[p for p in work.iterdir() if p.is_dir() and p.name.startswith(('douyin-','xiaohongshu-','xhs-'))]
    round_maps={};round_details={}
    for task in tasks:
        if task.name.startswith('douyin-local-') and (task/'batch_reply_runner.py').is_file():
            round_maps[task.name],round_details[task.name]=read_task(task)
    records=[]
    for platform,token,cid,customer,status,evidence in rows:
        if status=='unknown':records.append({'status':status});continue
        entry={'status':status,'platform':platform}
        matches=[p for p in tasks if str(token).startswith(p.name+'-')]
        if len(matches)==1:
            path=matches[0]/(str(cid)+'.json')
            try:
                data=json.loads(path.read_text(encoding='utf-8-sig'))
                receipt=(json.loads(evidence or '{}').get('receipt') or {})
                verified=(platform=='douyin' and data.get('attempt_id')==token
                  and str(data.get('customer_uid'))==str(customer)
                  and receipt.get('status_code')==0 and bool(receipt.get('cid'))
                  and receipt.get('sec_uid')==data.get('account_uid') and bool(data.get('account_uid'))
                  and str(receipt.get('reply_id') or '')==str(cid)
                  and receipt.get('text')==(data.get('reply') or {}).get('draft_text')
                  and bool(receipt.get('text')))
                if verified:
                    entry['video']=data.get('video_id')
                    entry['text']=(data.get('reply') or {}).get('draft_text')
                    entry['time']=datetime.fromisoformat((data.get('submitted_at') or '').replace('Z','+00:00'))
                    # Local log boundaries provide approximate, not authoritative, rounds.
                    entry['round_id']=round_maps.get(matches[0].name,{}).get(str(cid))
            except (OSError,ValueError,AttributeError,TypeError):pass
        records.append(entry)
    result=audit(records,day,video_run_limit)
    result['round_reconstruction']='日志启动到暂停的闭合片段，按选择证据近似'
    result['round_tasks_aligned']=sum(v.get('aligned') is True for v in round_details.values())
    result['round_tasks_unaligned']=sum(v.get('aligned') is False for v in round_details.values())
    return result

def audit(records,day,video_run_limit=3,phrase_limit=15):
    today=[];all_video=[];unknown=0;missing=0;round_missing=0
    for row in records:
        if row.get('status')=='unknown':unknown+=1;continue
        if row.get('status')!='sent':continue
        stamp=row.get('time');video=row.get('video');text=row.get('text')
        if video and text:all_video.append(row)
        if not isinstance(stamp,datetime) or stamp.tzinfo is None or not text:
            missing+=1;continue
        if stamp.astimezone(BEIJING).date()==day.astimezone(BEIJING).date():today.append(row)
    today.sort(key=lambda row:row['time'])
    phrases=Counter(row['text'] for row in today)
    video_phrases=Counter((x.get('platform','douyin'),x['video'],x['text']) for x in all_video)
    rounds={}
    for row in today:
        if not row.get('video') or not row.get('round_id'):
            round_missing+=1;continue
        rounds.setdefault((row.get('platform','douyin'),row['round_id']),[]).append(row)
    best=0;round_video_violations=0
    for entries in rounds.values():
        run=0;previous=None; per_video=Counter()
        for row in entries:
            run=run+1 if row['video']==previous else 1
            best=max(best,run);previous=row['video'];per_video[row['video']]+=1
        round_video_violations+=sum(n>5 for n in per_video.values())
    return {'observed_sent':len(today),'unknown_records':unknown,'incomplete_records':missing,
        'longest_same_video_run':best if rounds else None,
        'same_video_exceeded':best>video_run_limit if rounds and video_run_limit is not None else None,
        'round_video_over_five':round_video_violations if rounds else None,
        'round_unverifiable_records':round_missing,
        'repeated_video_phrase_groups':sum(n>1 for n in video_phrases.values()),
        'phrases_over_limit':sum(n>phrase_limit for n in phrases.values()),
        'phrases_at_limit':sum(n==phrase_limit for n in phrases.values()),
        'phrases_over_limit_details':[{'text':text,'count':n} for text,n in phrases.most_common() if n>phrase_limit],
        'coverage':'partial' if missing or unknown or round_missing else 'observed_records_only'}

if __name__=='__main__':
    import argparse,json
    from reply_rate import LEDGER,ROOT
    p=argparse.ArgumentParser();p.add_argument('--video-run-limit',type=int,default=3)
    args=p.parse_args()
    print(json.dumps(from_ledger(LEDGER,ROOT/'work',datetime.now(BEIJING),args.video_run_limit),ensure_ascii=False))
