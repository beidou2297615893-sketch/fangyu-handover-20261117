"""Local reconciliation before a human-authorized fresh-session continuation."""
import hashlib
import json
import sqlite3
from contextlib import closing
from pathlib import Path

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def reconcile_empty_attempt(root,ledger,uid,item):
    root=Path(root).resolve(strict=True); state=read(root/'state.json'); inflight=state.get('inflight') or {}
    batch=inflight.get('batch',''); folder=root/batch
    if state.get('status')!='outcome_unknown' or state.get('inserted')!=0 or any(inflight.get(k)!=v for k,v in item.items()) or not batch.startswith('batch-'):
        raise ValueError('empty_attempt_checkpoint_mismatch')
    if any((root/p).exists() for p in ('scheduler.lock','.account-switch.lock')) or any(folder.glob('partial-*.json')) or any((folder/p).exists() for p in ('collection.json','register-result.json','registered-ready.json','new-ai-input.json')):
        raise ValueError('attempt_requires_data_reconciliation')
    binding=read(folder/'account-binding.json'); failure=read(folder/'failure-diagnostic.json')['platform']
    if binding.get('uid')!=uid or binding.get('guest') is not False or (failure.get('stage'),failure.get('http_status'))!=('comments',461):
        raise ValueError('unexpected_attempt_evidence')
    with closing(sqlite3.connect(Path(ledger).resolve(strict=True).as_uri()+'?mode=ro',uri=True)) as db:
        count=db.execute('SELECT count(*) FROM leads WHERE platform=? AND source=?',('xiaohongshu','collection:'+str(folder/'collection.json'))).fetchone()[0]
    if count:raise ValueError('empty_attempt_has_registration')
    return {'prior_empty_attempt':str(root),'registered':0,'next_batch':int(batch.split('-')[1])+1,'network':False,'ledger_write':False}

def reconcile_comment_interruption(root,ledger,recovery,uid,item):
    root=Path(root).resolve(strict=True); recovery=Path(recovery).resolve(strict=True)
    if any((root/p).exists() for p in ('scheduler.lock','.account-switch.lock')):
        raise ValueError('prior_task_lock_present')
    state=read(root/'state.json'); batch=f"batch-{state['next_batch']:04d}"
    if state.get('status')!='outcome_unknown' or state.get('cursor')!=0 or state.get('inserted')!=0 or state.get('plan',[None])[0]!=item:
        raise ValueError('comment_checkpoint_mismatch')
    if any((state.get('inflight') or {}).get(k)!=v for k,v in {'batch':batch,**item}.items()):
        raise ValueError('comment_inflight_mismatch')
    failure=read(root/batch/'failure-diagnostic.json')['platform']
    if (failure.get('stage'),failure.get('endpoint'),failure.get('http_status'))!=('comments','comments',461):
        raise ValueError('other_failure_requires_review')
    manifests=[json.loads(x) for x in (recovery/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines() if x.strip()]
    if len(manifests)!=1:raise ValueError('recovery_manifest_mismatch')
    m=manifests[0]; source='collection:'+str(recovery/'collection.json')
    with closing(sqlite3.connect(Path(ledger).resolve(strict=True).as_uri()+'?mode=ro',uri=True)) as db:
        count=db.execute('SELECT count(*) FROM leads WHERE platform=? AND source=?',('xiaohongshu',source)).fetchone()[0]
        prior_source='collection:'+str(root/batch/'collection.json')
        if db.execute('SELECT count(*) FROM leads WHERE platform=? AND source=?',('xiaohongshu',prior_source)).fetchone()[0]:raise ValueError('original_batch_registration_unknown')
    required={'original_batch':batch,**item,'account_uid':uid,'registration_source':source,'inserted_comments':count,'input':'new-ai-input.json','note_completion_proven':False}
    if any(m.get(k)!=v for k,v in required.items()) or hashlib.sha256((recovery/'new-ai-input.json').read_bytes()).hexdigest()!=m['sha256']:
        raise ValueError('recovered_manifest_ledger_mismatch')
    receipt=read(recovery/'register-result.json'); ready=read(recovery/'registered-ready.json')
    if receipt.get('account',{}).get('uid')!=uid or receipt['account'].get('guest') is not False or receipt.get('result',{}).get('mode')!='apply' or receipt['result'].get('inserted')!=count or ready.get('registered') is not True or ready.get('account_uid')!=uid or ready.get('inserted_comments')!=count:
        raise ValueError('recovered_receipt_mismatch')
    return {'recovered_registered':count,'recovery_runtime':str(recovery),'interrupted_runtime':str(root),'keyword_complete':False,'next_batch':state['next_batch']+1,'network':False,'ledger_write':False}

def reconcile(root, ledger, plan, uid):
    root=Path(root).resolve(strict=True)
    if any((root/name).exists() for name in ('scheduler.lock','.account-switch.lock')):
        raise ValueError('prior_task_lock_present')
    state=read(root/'state.json')
    cursor=state.get('cursor'); first=state.get('next_batch')
    if state.get('status')!='outcome_unknown' or state.get('plan')!=plan or type(cursor) is not int or not 0<=cursor<len(plan) or first!=cursor+1:
        raise ValueError('prior_checkpoint_changed')
    batch=f'batch-{first:04d}'; inflight=state.get('inflight') or {}
    if any(inflight.get(k)!=v for k,v in {'batch':batch,**plan[cursor]}.items()):
        raise ValueError('prior_inflight_mismatch')
    folder=root/batch
    failure=read(folder/'failure-diagnostic.json').get('platform',{})
    if (failure.get('stage'),failure.get('endpoint'),failure.get('http_status'))!=('search','prewarm_onebox',461):
        raise ValueError('interruption_requires_other_reconciliation')
    if any(folder.glob('partial-*.json')) or any((folder/name).exists() for name in ('collection.json','ai-input.json','new-ai-input.json','register-result.json','registered-ready.json','attempt-events.jsonl')):
        raise ValueError('unfinished_collection_data_requires_reconciliation')
    entries=[json.loads(line) for line in (root/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines() if line.strip()]
    if len(entries)!=cursor or len({m['batch'] for m in entries})!=cursor:
        raise ValueError('prior_manifest_mismatch')
    total=0
    with closing(sqlite3.connect(Path(ledger).resolve(strict=True).as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('PRAGMA query_only=ON'); db.execute('BEGIN')
        for i,m in enumerate(entries):
            name=f'batch-{i+1:04d}'; source='collection:'+str((root/name/'collection.json').resolve())
            count=db.execute('SELECT count(*) FROM leads WHERE platform=? AND source=?',('xiaohongshu',source)).fetchone()[0]
            expected={'batch':name,**plan[i],'account_uid':uid,'registration_source':source,'input':name+'/new-ai-input.json','inserted_comments':count}
            if any(m.get(k)!=v for k,v in expected.items()):raise ValueError('ledger_manifest_mismatch')
            if hashlib.sha256((root/m['input']).read_bytes()).hexdigest()!=m.get('sha256'):
                raise ValueError('prior_analysis_hash_changed')
            receipt=read(root/name/'register-result.json'); binding=read(root/name/'account-binding.json'); ready=read(root/name/'registered-ready.json')
            if binding.get('uid')!=uid or binding.get('guest') is not False or receipt.get('account')!=binding or receipt.get('result',{}).get('mode')!='apply' or receipt['result'].get('inserted')!=count:
                raise ValueError('prior_registration_receipt_mismatch')
            if ready.get('registered') is not True or ready.get('inserted_comments')!=count or ready.get('account_uid')!=uid or ready.get('input')!='new-ai-input.json':
                raise ValueError('prior_ready_receipt_mismatch')
            total+=count
        failed_source='collection:'+str((folder/'collection.json').resolve())
        if db.execute('SELECT count(*) FROM leads WHERE platform=? AND source=?',('xiaohongshu',failed_source)).fetchone()[0]:
            raise ValueError('unfinished_batch_already_registered')
        db.rollback()
    if total!=state.get('inserted'):raise ValueError('prior_count_mismatch')
    return {'prior_runtime':str(root),'cursor':cursor,'first_batch':first,'base_registered':total,
            'unfinished_batch_registered':0,'resume_authorization':'user_confirmed_normal_login_2026-10-30',
            'network':False,'ledger_write':False}
