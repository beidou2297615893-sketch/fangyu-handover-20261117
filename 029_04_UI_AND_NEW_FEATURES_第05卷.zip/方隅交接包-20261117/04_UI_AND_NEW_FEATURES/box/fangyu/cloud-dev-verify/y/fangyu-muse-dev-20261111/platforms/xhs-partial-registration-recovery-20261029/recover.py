"""Register an immutable interrupted partial locally; preview is default.

No platform, login, browser, send, or retry capability exists in this module.
"""
import argparse
from contextlib import closing
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import sys

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
RUNTIME=HERE/'runtime'
RECOVERY=PROJECT/'work/xhs-account-switch-recovery-candidate/runtime'
REAL_LEDGER=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'

def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):
    with Path(path).open('x',encoding='utf8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2); stream.flush(); os.fsync(stream.fileno())
def event(path,status,**extra):
    with Path(path).open('a',encoding='utf8') as stream:
        stream.write(json.dumps({'at':now(),'status':status,**extra},ensure_ascii=False)+'\n')
        stream.flush(); os.fsync(stream.fileno())

def components():
    live=PROJECT/'work/xhs-live-collection-runner-20261029'
    spec=importlib.util.spec_from_file_location('partial_recovery_live_helpers',live/'runner.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    candidate,_,_=module.components(); collector,registrar=candidate.dependencies()
    selector_path=PROJECT/'work/xhs-continuous-runner/runner.py'
    selector_spec=importlib.util.spec_from_file_location('partial_recovery_selector',selector_path)
    selector=importlib.util.module_from_spec(selector_spec); selector_spec.loader.exec_module(selector)
    return module,collector,registrar,selector

def identity_proof(path,uid):
    value=read(path)
    account=value.get('account')
    if (value.get('status')!='verified' or not isinstance(account,dict) or account.get('uid')!=uid
        or account.get('guest') is not False or value.get('proof_source')!='same_client_user_me'):
        raise ValueError('fresh_same_account_identity_required')
    try:
        at=datetime.fromisoformat(value['verified_at'])
        if at.tzinfo is None: raise ValueError('timezone required')
        age=(datetime.now(timezone.utc)-at).total_seconds()
        if not -30<=age<=300: raise ValueError('stale identity')
    except (ValueError,TypeError,KeyError): raise ValueError('fresh_same_account_identity_required') from None
    return {'status':'verified','account':{'uid':uid,'guest':False},
        'proof_source':'same_client_user_me','verified_at':value['verified_at']}

def original_evidence(partial,ledger):
    if not re.fullmatch(r'partial-[0-9]{4}\.json',partial.name): raise ValueError('numbered_partial_required')
    batch=partial.parent
    allowed=(partial.is_relative_to(RECOVERY.resolve(strict=True)) or partial.is_relative_to(RUNTIME.resolve(strict=True)))
    if not allowed or partial!=sorted(batch.glob('partial-[0-9][0-9][0-9][0-9].json'))[-1]:
        raise ValueError('latest_candidate_partial_required')
    if any((batch/name).exists() for name in ('collection.json','register-result.json','registered-ready.json')):
        raise ValueError('original_batch_registration_requires_review')
    binding=read(batch/'account-binding.json'); data=read(partial)
    events=[json.loads(line) for line in (batch/'account-audit.jsonl').read_text(encoding='utf8').splitlines() if line]
    if not events or events[-1].get('status')!='stopped_before_registration':
        raise ValueError('original_not_proven_stopped_before_registration')
    if any(entry.get('status') in ('registration_started','registered','registration_outcome_unknown_check_ledger') for entry in events):
        raise ValueError('original_registration_unknown')
    if (binding.get('guest') is not False or not isinstance(binding.get('uid'),str) or not binding['uid']
        or data.get('collection_account')!=binding): raise ValueError('original_account_conflict')
    last=events[-1]
    if (data.get('keyword')!=last.get('keyword') or type(last.get('search_page')) is not int
        or not isinstance(last.get('task'),str) or last.get('batch')!=batch.name):
        raise ValueError('original_target_conflict')
    for entry in events:
        account=entry.get('account')
        if isinstance(account,dict) and account.get('uid')!=binding['uid']:
            raise ValueError('original_account_conflict')
    originals=[partial,batch/'account-binding.json',batch/'account-audit.jsonl']
    config=batch.parent/'task-config.json'
    if config.exists():
        setting=read(config)
        if Path(setting['ledger']).resolve()!=ledger: raise ValueError('original_ledger_conflict')
        originals.append(config)
    if (batch/'failure-diagnostic.json').exists(): originals.append(batch/'failure-diagnostic.json')
    return data,binding,last,{str(path):digest(path) for path in originals}

def source_rows(ledger,source):
    with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
        return db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchall()

def recover(partial,*,ledger,source_db,output,identity_receipt=None,execute=False,allow_real_ledger=False):
    partial=Path(partial).resolve(strict=True); ledger=Path(ledger).resolve(strict=True)
    source_db=Path(source_db).resolve(strict=True); output=Path(output).resolve()
    fixture=ledger.is_relative_to(RUNTIME.resolve(strict=True))
    if not fixture and ledger!=REAL_LEDGER.resolve():
        raise ValueError('known_local_ledger_required')
    if execute and not fixture and allow_real_ledger is not True:
        raise ValueError('explicit_shared_ledger_opt_in_required')
    if output==RUNTIME.resolve() or not output.is_relative_to(RUNTIME.resolve(strict=True)) or not output.parent.is_dir():
        raise ValueError('fresh_recovery_output_required')
    helpers,collector,registrar,selector=components()
    data,binding,target,originals=original_evidence(partial,ledger)
    config=partial.parent.parent/'task-config.json'
    if config.exists() and Path(read(config)['source_db']).resolve()!=source_db:
        raise ValueError('original_identity_source_conflict')
    registrar.validate_batch(data)
    rows=helpers.comment_rows(data['customers'])
    if (data.get('summary',{}).get('usable_comments')!=len(rows)
        or data.get('summary',{}).get('customers')!=len(data['customers'])):
        raise ValueError('partial_summary_conflict')
    valid_ids={comment for _,comment in rows}
    def ids(value):
        result=set()
        if isinstance(value,dict):
            if isinstance(value.get('comment_id'),str): result.add(value['comment_id'])
            for item in value.values(): result.update(ids(item))
        elif isinstance(value,list):
            for item in value: result.update(ids(item))
        return result
    if valid_ids & ids([data.get('pending',[]),data.get('conflicts',[])]):
        raise ValueError('valid_and_pending_comment_overlap')
    original_sources=['collection:'+str(partial.parent/'collection.json'),'collection:'+str(partial)]
    if any(source_rows(ledger,source) for source in original_sources):
        raise ValueError('original_batch_already_registered_review_required')
    identity_map=collector.merge_ledger_identity_map(collector.load_identity_map(source_db,binding['uid']),ledger)
    existing=[]
    with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
        ordered=sorted(valid_ids)
        for offset in range(0,len(ordered),500):
            group=ordered[offset:offset+500]
            query="SELECT customer,comment,status,source FROM leads WHERE platform='xiaohongshu' AND comment IN ("+','.join('?' for _ in group)+')'
            existing.extend({'customer_id':row[0],'comment_id':row[1],'status':row[2],'source':row[3]}
                for row in db.execute(query,group))
    existing_ids={row['comment_id'] for row in existing}
    staged=deepcopy(data)
    staged['collection_task']={'task':target['task'],'operator':target.get('operator','unknown'),
        'search_page':target['search_page'],'original_batch':partial.parent.name}
    staged['partial_recovery']={'original_partial':str(partial),'original_sha256':digest(partial),
        'original_files':originals,'prepared_at':now(),'note_completion_proven':False}
    source='collection:'+str(output/'collection.json')
    if not execute:
        result=registrar.register(ledger,staged,identity_map,source,apply=False)
        return {'status':'preview','account_uid':binding['uid'],'valid_comments':len(rows),
            'would_insert':result['would_insert'],'blocked_customers':result['blocked_customers'],
            'already_present':result['already_present'],'existing_comments':existing,
            'not_yet_registered_comment_ids':sorted(valid_ids-existing_ids),
            'pending':len(data.get('pending',[])),'original_batch':partial.parent.name,
            'note_completion_proven':False,'network':False,'ledger_write':False}
    if identity_receipt is None: raise ValueError('fresh_same_account_identity_required')
    proof=identity_proof(identity_receipt,binding['uid'])
    if valid_ids and valid_ids<=existing_ids: raise ValueError('no_new_comments_to_register')
    if output.exists(): raise ValueError('existing_output_no_retry')
    lock=ledger.parent/'.xhs-collection-runner.lock'
    try: lock.mkdir()
    except FileExistsError: raise ValueError('collection_lock_busy_no_retry') from None
    claim=None; registration_started=False
    try:
        write(lock/'owner.json',{'pid':os.getpid(),'entry':'partial-registration-recovery','at':now()})
        if any(source_rows(ledger,entry) for entry in original_sources):
            raise ValueError('original_batch_already_registered_review_required')
        if any(digest(path)!=value for path,value in originals.items()): raise ValueError('original_changed')
        claims=ledger.parent/'.xhs-partial-recovery-claims'; claims.mkdir(exist_ok=True)
        key=hashlib.sha256((digest(partial)+':'+binding['uid']).encode('utf8')).hexdigest()
        new_claim=claims/key
        try: new_claim.mkdir()
        except FileExistsError: raise ValueError('partial_already_claimed_no_retry') from None
        claim=new_claim
        write(claim/'claim.json',{'at':now(),'partial':str(partial),'sha256':digest(partial),
            'account_uid':binding['uid'],'output':str(output),'automatic_retry':False})
        output.mkdir()
        write(output/'collection.json',staged); write(output/'account-binding.json',binding)
        write(output/'registration-account-check.json',proof)
        event(output/'recovery-audit.jsonl','prepared',original_batch=partial.parent.name,
            keyword=data['keyword'],search_page=target['search_page'],account_uid=binding['uid'],
            operator=target.get('operator','unknown'))
        registration_started=True
        event(claim/'events.jsonl','registration_started',source=source)
        result=registrar.register(ledger,staged,identity_map,source,apply=True)
        write(output/'register-result.json',{'account':binding,'result':result})
        chosen=selector.select_new(staged,ledger,output/'collection.json',result['inserted'])
        chosen_rows=helpers.comment_rows(chosen)
        registered=source_rows(ledger,source)
        if (len(registered)!=result['inserted'] or set(registered)!=set(chosen_rows)
            or any(key not in rows or chosen_rows[key]!=rows[key] for key in chosen_rows)):
            raise ValueError('registered_analysis_conflict')
        write(output/'new-ai-input.json',chosen)
        write(output/'registered-ready.json',{'registered':True,'account_uid':binding['uid'],
            'inserted_comments':result['inserted'],'input':'new-ai-input.json','original_batch':partial.parent.name})
        manifest={'at':now(),'status':'registered_ready_for_classification','original_batch':partial.parent.name,
            'keyword':data['keyword'],'page':target['search_page'],'account_uid':binding['uid'],
            'operator':target.get('operator','unknown'),'inserted_comments':result['inserted'],
            'input':'new-ai-input.json','sha256':digest(output/'new-ai-input.json'),
            'registration_source':source,'original_partial':str(partial),'original_sha256':digest(partial),
            'note_completion_proven':False,'count_basis':'new_registered_unique_comments_since_this_resume'}
        event(output/'analysis-manifest.jsonl','registered_ready_for_classification',**{k:v for k,v in manifest.items() if k not in ('at','status')})
        event(output/'recovery-audit.jsonl','registered',inserted=result['inserted'],pending=len(data.get('pending',[])))
        event(claim/'events.jsonl','registered',inserted=result['inserted'])
        return {'status':'registered','inserted':result['inserted'],'pending':len(data.get('pending',[])),
            'analysis_manifest':str(output/'analysis-manifest.jsonl'),'note_completion_proven':False}
    except Exception:
        if claim is not None and claim.exists():
            state='registration_outcome_unknown_check_ledger' if registration_started else 'stopped_before_registration'
            event(claim/'events.jsonl',state,automatic_retry=False)
            if output.exists(): event(output/'recovery-audit.jsonl',state,automatic_retry=False)
        raise
    finally:
        (lock/'owner.json').unlink(missing_ok=True); lock.rmdir()

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--partial',required=True); parser.add_argument('--output',required=True)
    parser.add_argument('--ledger',required=True); parser.add_argument('--source-db',required=True)
    parser.add_argument('--identity-receipt'); parser.add_argument('--execute',action='store_true')
    parser.add_argument('--apply-to-shared-ledger',action='store_true')
    args=parser.parse_args(argv)
    result=recover(args.partial,ledger=args.ledger,source_db=args.source_db,output=args.output,
        identity_receipt=args.identity_receipt,execute=args.execute,allow_real_ledger=args.apply_to_shared_ledger)
    print(json.dumps(result,ensure_ascii=False)); return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception:
        print(json.dumps({'status':'stopped','automatic_retry':False,'action':'inspect_recovery_receipts_and_ledger'}),file=sys.stderr)
        raise SystemExit(2) from None
