"""Prepare the current priority candidates for the existing offline CLI preview.

Only rows whose top-level text_status is already
precomputed_pending_sender_checks enter the existing sender-prep checks.
Held, missing, and unknown statuses are counted and left out. Passing the
text stage is not a send approval.
"""
from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace

import bulk_run
from daily_time_order import order_rows
from prepare_logged_sender import candidate_pending, load_cli

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
TEXT = PROJECT / 'work/fangyu-text-business-20261029'
PRIORITY = TEXT / 'recency-priority/daily-priority/current.json'
POINTER = HERE / 'latest-priority-batch.json'
ORIGINALS = [TEXT / 'delivery-v2/source-input.jsonl', TEXT / 'xhs-increment-846/input.jsonl']
READY_TEXT_STATUS = 'precomputed_pending_sender_checks'
HELD_TEXT_STATUS_REASONS = {
    'held_semantic_or_region_review': '文本阶段待核',
    'held_no_reply': '文本阶段无回复',
    'held_duplicate_customer': '文本阶段客户重复',
}


def text_status_skip_reason(row):
    """None only when this row has passed the text stage and awaits sender checks."""
    if 'text_status' not in row or row.get('text_status') is None:
        return '文本状态缺失'
    status = row.get('text_status')
    if status == READY_TEXT_STATUS:
        return None
    if isinstance(status, str):
        return HELD_TEXT_STATUS_REASONS.get(status, '文本状态未知')
    return '文本状态未知'


def partition_candidates(candidates, customers, original_comments, states):
    """Split queue rows into sender batches and skip reasons.

    The text-status gate runs first. Every row that passes it still has to
    clear the original account, ledger, source, draft, business, history, and
    mapping checks. The admitted count cannot exceed the text-stage count.
    """
    by_account = defaultdict(list)
    skipped = Counter()
    seen_customers = set()
    seen_uids = set()
    for row in candidates:
        reason = text_status_skip_reason(row)
        if reason:
            skipped[reason] += 1
            continue
        cid = row['comment_id']
        uid = row.get('customer_uid')
        note = row.get('note_id')
        sender_uid = row.get('required_sending_account_uid')
        if not all((uid, note, sender_uid)) or sender_uid != row.get('source_account_uid'):
            skipped['账号或目标资料待核'] += 1
            continue
        if len(customers[cid]) != 1:
            skipped['账本身份待核'] += 1
            continue
        customer = next(iter(customers[cid]))
        originals = [source for source in original_comments[cid]
                     if (source.get('customer_uid'), source.get('note_id'), source.get('comment_text'))
                     == (uid, note, row.get('comment_text'))]
        if not originals:
            skipped['原评论无法对应'] += 1
            continue
        titles = {source['post_title'] for source in originals if source.get('post_title')}
        reply = row.get('reply') or {}
        draft = reply.get('draft_text')
        if not isinstance(draft, str) or not draft.strip() or draft != draft.strip():
            skipped['回复正文格式待核'] += 1
            continue
        if hashlib.sha256(draft.encode('utf-8')).hexdigest() != row.get('reply_body_sha256'):
            skipped['回复正文校验失败'] += 1
            continue
        if (row.get('commercial_fit', {}).get('eligible_candidate') is not True
                or reply.get('contact_hold') or row.get('contact_boundaries') or row.get('needs_currentness_review')):
            skipped['业务条件待核'] += 1
            continue
        plan = {'customer_id': customer, 'customer_uid': uid, 'comment_id': cid,
                'note_id': note, 'text': draft}
        if not candidate_pending(plan, states) or customer in seen_customers or uid in seen_uids:
            skipped['账本已拦截或客户重复'] += 1
            continue
        mapping = {'comment_id': cid, 'customer_uid': uid, 'canonical_customer': customer,
                   'note_id': note, 'original_comment': row['comment_text'],
                   'post_title': next(iter(titles)) if len(titles) == 1 else '',
                   'published_at': row.get('published_at'), 'platform_history_checked': False}
        reason = bulk_run.mapping_reason(plan, mapping)
        if reason:
            skipped[reason] += 1
            continue
        by_account[sender_uid].append((plan, mapping))
        seen_customers.add(customer)
        seen_uids.add(uid)
    return by_account, skipped


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def read_jsonl(data):
    return [json.loads(line) for line in data.decode('utf-8-sig').splitlines() if line.strip()]


def prepare():
    cli = load_cli()
    priority = bulk_run.read_json(PRIORITY)['platforms']['xiaohongshu']
    queue_data = Path(priority['queue']).read_bytes()
    if hashlib.sha256(queue_data).hexdigest() != priority['sha256']:
        raise ValueError('小红书排序队列校验失败')
    candidates = order_rows(read_jsonl(queue_data), PRIORITY)
    if len(candidates) != priority['count']:
        raise ValueError('小红书排序队列条数不一致')

    original_comments = defaultdict(list)
    original_data = [path.read_bytes() for path in ORIGINALS]
    for data in original_data:
        for source in read_jsonl(data):
            original_comments[source['comment_id']].append(source)

    ledger = PROJECT / 'work/shared-acquisition-ledger/shared.sqlite3'
    states = cli.ledger_states(ledger)
    customers = defaultdict(set)
    with closing(sqlite3.connect(ledger.as_uri() + '?mode=ro', uri=True)) as db:
        for comment_id, customer in db.execute("SELECT comment, customer FROM leads WHERE platform='xiaohongshu'"):
            customers[comment_id].add(customer)

    by_account, skipped = partition_candidates(candidates, customers, original_comments, states)

    stamp = datetime.now(timezone.utc)
    root = HERE / 'runs' / f'latest-priority-{stamp:%Y%m%d-%H%M%S-%f}'
    root.mkdir()
    (root / 'classified-queue.jsonl').write_bytes(queue_data)
    sources = {'classified_queue': str(root / 'classified-queue.jsonl')}
    for index, data in enumerate(original_data, start=1):
        path = root / f'original-comments-{index}.jsonl'
        path.write_bytes(data)
        sources[f'original_comments_{index}'] = str(path)

    active_uid = bulk_run.read_json(HERE / 'resume-request-20261103.json')['sender_uid']
    batches = {}
    for index, (sender_uid, pairs) in enumerate(by_account.items(), start=1):
        account = root / f'account-{index}'
        account.mkdir()
        input_path, mapping_path = account / 'input.json', account / 'target-mapping.json'
        source_path, batch_path = account / 'source-manifest.json', account / 'prepared-batch.json'
        plans, mappings = map(list, zip(*pairs))
        write_json(input_path, plans)
        write_json(mapping_path, mappings)
        write_json(source_path, {**sources, 'queue_input': str(input_path), 'target_mapping': str(mapping_path)})
        cli.prepare_batch(SimpleNamespace(input=input_path, output=batch_path, source_manifest=source_path,
                                           sender_uid=sender_uid))
        batch = cli.load_batch(batch_path)
        assert order_rows(batch['rows'], PRIORITY) == batch['rows']
        assert [row['text'] for row in batch['rows']] == [row['text'] for row in plans]
        assert all(cli.row_state(row, states) == 'pending' for row in batch['rows'])
        batches[sender_uid] = {'batch': str(batch_path), 'mapping': str(mapping_path),
                               'source_manifest': str(source_path), 'count': len(plans)}

    ready = sum(batch['count'] for batch in batches.values())
    assert ready + sum(skipped.values()) == len(candidates)
    report = {'prepared_at': stamp.isoformat(), 'source_count': len(candidates), 'queued': ready,
              'source_queue_sha256': priority['sha256'], 'skipped': dict(skipped),
              'default_sender_uid': active_uid, 'accounts': batches, 'send_attempts': 0}
    write_json(root / 'preparation-receipt.json', report)
    temp = POINTER.with_suffix('.tmp')
    write_json(temp, report)
    temp.replace(POINTER)
    return report


if __name__ == '__main__':
    print(json.dumps(prepare(), ensure_ascii=False))
