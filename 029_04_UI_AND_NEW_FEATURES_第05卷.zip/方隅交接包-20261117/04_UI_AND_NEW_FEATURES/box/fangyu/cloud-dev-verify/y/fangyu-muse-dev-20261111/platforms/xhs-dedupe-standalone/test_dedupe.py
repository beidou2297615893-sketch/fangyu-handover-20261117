import json
from contextlib import closing
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import dedupe


class DedupeTests(unittest.TestCase):
    def row(self, **kw):
        return dict(platform='xiaohongshu', uid='u1', comment_id='c1', nickname='同名', **kw)

    def test_exact_comment_repetition_keeps_all_evidence(self):
        r = dedupe.aggregate([self.row(source='a', time=1), self.row(source='b', time=2)])
        self.assertEqual(len(r['comments']), 1)
        self.assertEqual(len(r['comments'][0]['observations']), 2)
        self.assertEqual(r['comments'][0]['reply_state'], 'unknown')

    def test_uid_groups_distinct_comments_not_nickname_or_cross_platform(self):
        rows = [self.row(), dict(platform='xiaohongshu', uid='u1', comment_id='c2'),
                dict(platform='xiaohongshu', uid='u2', comment_id='c3', nickname='同名'),
                dict(platform='douyin', uid='u1', comment_id='c1')]
        r = dedupe.aggregate(rows)
        self.assertEqual(len(r['comments']), 4)
        self.assertEqual(sorted(len(c['comment_keys']) for c in r['customers']), [1, 1, 2])

    def test_conflicting_uid_and_content_are_preserved_and_flagged(self):
        r = dedupe.aggregate([self.row(text='a'), dict(platform='xiaohongshu', uid='u2', comment_id='c1', text='b')])
        self.assertEqual(r['comments'][0]['uids'], ['u1', 'u2'])
        self.assertEqual(r['comments'][0]['conflicts'], ['uid', 'text'])
        self.assertTrue(all(c['needs_review'] for c in r['customers']))

    def test_missing_ids_and_internal_customer_id_remain_review_items(self):
        r = dedupe.aggregate([dict(platform='xiaohongshu', nickname='a'),
                             dict(platform='xiaohongshu', customer_id='hash', comment_id='c1')])
        self.assertEqual(len(r['pending']), 1)
        self.assertEqual(len(r['customers']), 0)
        self.assertTrue(r['comments'][0]['needs_review'])

    def test_reply_status_is_conservative(self):
        cases = [('sent', 'unreplied', 'replied'), ('unknown', 'unreplied', 'unknown'),
                 ('submitted', 'none', 'unknown'), ('reserved', 'none', 'in_progress'),
                 ('none', 'unreplied', 'unreplied'), ('prepared', 'none', 'unknown')]
        for a, b, expected in cases:
            with self.subTest(a=a, b=b):
                r = dedupe.aggregate([self.row(status=a), self.row(status=b)])
                self.assertEqual(r['comments'][0]['reply_state'], expected)
                self.assertFalse(r['comments'][0]['send_authorized'])

    def test_generic_success_is_not_reply_receipt(self):
        r = dedupe.aggregate([self.row(status='success')])
        self.assertEqual(r['comments'][0]['reply_state'], 'unknown')

    def test_assessment_status_is_evidence_not_reply_receipt(self):
        row = self.row(status='sent', _provenance={'table':'assessments'})
        r = dedupe.aggregate([row])
        self.assertEqual(r['comments'][0]['reply_state'], 'unknown')
        self.assertEqual(r['comments'][0]['observations'][0]['status'], 'sent')

    def test_conflicting_comment_id_fields_are_pending(self):
        r = dedupe.aggregate([self.row(commentID='other')])
        self.assertEqual(len(r['comments']), 0)
        self.assertEqual(len(r['pending']), 1)

    def test_cli_rejects_output_outside_project_and_invalid_previous(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            base = Path(tmp)
            src = base / 'input.json'
            src.write_text(json.dumps([self.row()]), encoding='utf-8')
            cli = [sys.executable, str(Path(__file__).with_name('dedupe.py')), '--input', str(src)]
            bad = subprocess.run(cli + ['--output', str(Path(__file__).parent.parent/'forbidden-dedupe')], capture_output=True)
            self.assertNotEqual(bad.returncode, 0)
            previous = base/'bad-state.json'
            previous.write_text('{}', encoding='utf-8')
            bad = subprocess.run(cli + ['--previous', str(previous), '--output', str(base/'result')], capture_output=True)
            self.assertNotEqual(bad.returncode, 0)
            self.assertIn(b'unsupported previous result', bad.stderr)
            self.assertFalse((base/'result').exists())

    def test_exclusive_locked_database_fails_without_retry_or_write(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            p = Path(tmp)/'locked.sqlite3'
            with closing(sqlite3.connect(p)) as db:
                db.execute('CREATE TABLE leads(platform,customer,comment,status)')
                db.commit()
                db.execute('BEGIN EXCLUSIVE')
                with self.assertRaises(sqlite3.OperationalError):
                    dedupe.read_ledger(p)
                db.rollback()

    def test_incremental_repeat_is_idempotent_and_retains_old_observations(self):
        one = dedupe.aggregate([self.row(source='a')])
        two = dedupe.aggregate([self.row(source='b'), self.row(source='b')], one)
        three = dedupe.aggregate([self.row(source='b')], two)
        self.assertEqual(two, three)
        self.assertEqual(len(two['comments'][0]['observations']), 2)

    def test_identifiers_not_coerced_or_casefolded(self):
        with self.assertRaises(ValueError):
            dedupe.aggregate([dict(platform='xiaohongshu', uid=123, comment_id='c')])
        r = dedupe.aggregate([dict(platform='xiaohongshu', uid='U', comment_id='C'), self.row()])
        self.assertEqual(len(r['comments']), 2)

    def test_sqlite_reader_preserves_sources_and_unknown_deliveries_without_writes(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            p = Path(tmp) / 'fixture.sqlite3'
            with closing(sqlite3.connect(p)) as db:
                db.executescript('CREATE TABLE leads(platform,customer,comment,status,source,review_time); CREATE TABLE historical_deliveries(platform,customer,comment,delivery_state,source,recorded);')
                db.execute('INSERT INTO leads VALUES(?,?,?,?,?,?)', ('xiaohongshu','hash','c1','reviewed','cli',123))
                db.execute('INSERT INTO historical_deliveries VALUES(?,?,?,?,?,?)', ('xiaohongshu','hash','c1','submitted','old',100))
                db.commit()
            before = p.read_bytes()
            r = dedupe.aggregate(dedupe.read_ledger(p))
            self.assertEqual(before, p.read_bytes())
            self.assertEqual(r['comments'][0]['reply_state'], 'unknown')
            self.assertEqual(len(r['comments'][0]['observations']), 2)
            self.assertEqual(r['customers'], [])

    def test_cli_creates_new_output_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            base = Path(tmp)
            src = base / 'in.json'
            src.write_text(json.dumps({'records':[self.row()]}), encoding='utf-8')
            cmd = [sys.executable, str(Path(__file__).with_name('dedupe.py')), '--input', str(src), '--output', str(base/'result')]
            first = subprocess.run(cmd, capture_output=True)
            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertTrue((base/'result'/'result.json').is_file())
            self.assertNotEqual(subprocess.run(cmd, capture_output=True).returncode, 0)
            self.assertEqual(json.loads(src.read_text())['records'][0]['uid'], 'u1')


if __name__ == '__main__':
    unittest.main(verbosity=2)
