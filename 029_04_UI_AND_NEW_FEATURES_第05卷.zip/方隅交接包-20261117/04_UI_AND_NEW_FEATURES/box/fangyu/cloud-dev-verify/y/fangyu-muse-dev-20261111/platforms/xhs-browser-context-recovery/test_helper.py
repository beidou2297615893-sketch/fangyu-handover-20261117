import importlib.util
import json
from pathlib import Path
import sqlite3
from contextlib import closing
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('recovery', Path(__file__).with_name('helper.py'))
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.folder = self.root / 'work/xhs-browser-context-recovery'
        self.folder.mkdir(parents=True)
        dbpath = self.root / 'work/shared-acquisition-ledger/shared.sqlite3'
        dbpath.parent.mkdir(parents=True)
        with closing(sqlite3.connect(dbpath)) as db:
            db.executescript('CREATE TABLE leads(platform,customer,comment,status); CREATE TABLE collection_uid_observations(platform,platform_uid,canonical);')
            db.execute('INSERT INTO leads VALUES(?,?,?,?)', ('xiaohongshu', 'known', 'old', 'unknown'))
            db.execute('INSERT INTO collection_uid_observations VALUES(?,?,?)', ('xiaohongshu', 'known_uid', 'known'))
            db.commit()

    def tearDown(self):
        self.temp.cleanup()

    def put(self, name, data):
        (self.folder / name).write_text(json.dumps(data, ensure_ascii=False), encoding='utf8')

    def test_deduplicates_excludes_author_and_own_and_keeps_original_date(self):
        self.put('note.json', {'note_id': 'note', 'title': 'title', 'body': 'body', 'author_uid': 'author'})
        comments = [
            {'comment_id': 'old', 'customer_uid': 'known_uid', 'comment_text': 'old', 'date_display': '昨天 上海'},
            {'comment_id': 'new', 'customer_uid': 'new_uid', 'comment_text': 'new', 'date_display': '7天前 北京'},
            {'comment_id': 'author_reply', 'customer_uid': 'author', 'comment_text': 'reply'},
            {'comment_id': 'own_reply', 'customer_uid': helper.OWN_UID, 'comment_text': 'reply', 'parent_comment_id': 'old'},
        ]
        self.put('note-comments.json', {'note_id': 'note', 'complete': False, 'comments': comments + [comments[1]]})
        report = helper.refresh(self.root)
        self.assertEqual((report['visible_comments'], report['new_comments'], report['own_visible_replies'], report['author_comments']), (4, 1, 1, 1))
        inputs = json.loads((self.folder / 'ai-input.json').read_text(encoding='utf8'))
        self.assertEqual({row['comment_id'] for row in inputs}, {'old', 'new'})
        new = next(row for row in inputs if row['comment_id'] == 'new')
        self.assertEqual(new['date_display'], '7天前 北京')
        self.assertEqual(new['published_at'], '')
        self.assertNotIn('region', new)
        self.assertFalse(new['send_authorized'])
        old = next(row for row in inputs if row['comment_id'] == 'old')
        self.assertTrue(old['own_reply_visible'])
        self.assertEqual(helper.refresh(self.root), report)

    def test_missing_author_never_treats_unknown_author_as_customer(self):
        self.put('note.json', {'note_id': 'note', 'title': 'title', 'body': 'body'})
        self.put('note-comments.json', {'note_id': 'note', 'comments': [{'comment_id': 'x', 'customer_uid': 'someone', 'comment_text': 'x'}]})
        report = helper.refresh(self.root)
        self.assertEqual(report['identity_review_comments'], 1)
        self.assertEqual(json.loads((self.folder / 'ai-input.json').read_text(encoding='utf8')), [])

    def test_normalized_media_and_post_uncertainties_survive_to_analysis_input(self):
        raw = {'note_id': 'note', 'title': 'title', 'post_text': '北京东路 10月30日 10月20日',
               'author_uid': 'author', 'displayed_comment_count': 186, 'complete': False,
               'post_date_conflict': True, 'search_location_not_verified': True,
               'comments': [{'id': 'a', 'uid': 'u', 'text': '[视频]30s', 'parent': '', 'date': '2天前上海', 'name': 'n'},
                            {'id': 'b', 'uid': 'v', 'text': '', 'parent': 'a', 'date': '昨天', 'name': 'v'}]}
        self.put('note-browser-raw.json', raw)
        helper.normalize_browser_raw(self.folder / 'note-browser-raw.json')
        report = helper.refresh(self.root)
        self.assertEqual((report['visible_comments'], report['complete_notes']), (2, 0))
        inputs = json.loads((self.folder / 'ai-input.json').read_text(encoding='utf8'))
        a, b = inputs
        self.assertTrue(a['unread_media'])
        self.assertTrue(b['unread_media'])
        self.assertFalse(a['text_evidence_available'])
        self.assertFalse(b['text_evidence_available'])
        self.assertEqual(b['parent_relationship'], 'reply')
        self.assertEqual(a['date_display'], '2天前上海')
        self.assertEqual(a['published_at'], '')
        self.assertIn('10月30', a['post_text'])
        self.assertIn('10月20', a['post_text'])
        self.assertTrue(a['post_date_conflict'])
        self.assertTrue(a['search_location_not_verified'])


if __name__ == '__main__':
    unittest.main()
