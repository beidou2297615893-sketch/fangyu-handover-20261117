"""Collect-result -> note context -> optional Codex analysis; never sends.

This consumes the existing collector's saved result, including a partial result.
Ledger selection is performed by the existing registrar before this stage.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import importlib.util
import json
import os
from pathlib import Path
import sys

from context_reader import Halt, ContextClient, cached_context, collector, note_body, save

ROOT=Path(__file__).resolve().parent

def _ai_module():
    spec=importlib.util.spec_from_file_location('context_ai_pipeline',ROOT.parent/'xhs-ai-standalone'/'pipeline.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def source_records(source,selected=None):
    if not isinstance(source,dict) or source.get('schema')!='xhs-collected-ai-input-v1' or not isinstance(source.get('customers'),list):
        raise Halt('必须使用现有主评论采集器的完整结果或部分结果')
    rows=source['customers']
    if rows:_ai_module().validate_records(rows)
    if selected is not None:
        if not isinstance(selected,list):raise Halt('新增客户选择格式错误')
        originals={(row['customer_id'],row['customer_uid']):row for row in rows}
        seen=set()
        fields=('comment_id','note_id','comment_text','parent_text','parent_relationship','post_title','post_text','published_at','missing_context')
        for row in selected:
            if not isinstance(row,dict) or row.get('customer_id') in seen:
                raise Halt('新增客户选择与原始采集记录不一致')
            original=originals.get((row.get('customer_id'),row.get('customer_uid')))
            if original is None:raise Halt('新增客户身份与原始采集记录不一致')
            available={item['comment_id']:item for item in [original,*original.get('other_comments',[])]}
            for item in [row,*row.get('other_comments',[])]:
                if not isinstance(item,dict) or item.get('comment_id') not in available or any(item.get(key)!=available[item['comment_id']].get(key) for key in fields):
                    raise Halt('新增客户选择与原始采集记录不一致')
            seen.add(row['customer_id'])
        if selected:_ai_module().validate_records(selected)
        rows=selected
    for row in rows:
        for comment in [row,*row.get('other_comments',[])]:
            if comment.get('parent_relationship') not in ('not_collected','top_level_comment_on_post'):
                raise Halt('来源不是已知主评论关系，不能改写为顶层评论')
    return deepcopy(rows)

def enrich_records(records,read_note,on_progress=None):
    """Read each distinct note once, preserve full comments, stop on any error."""
    acquired={}
    for row in records:
        for item in [row,*row.get('other_comments',[])]:
            note=item['note_id']
            if note not in acquired:
                body=read_note(note)
                if not isinstance(body,dict) or body.get('note_id')!=note or not all(isinstance(body.get(k),str) for k in ('title','body')):
                    raise Halt('补读正文与指定帖子不一致')
                acquired[note]=deepcopy(body)
                if on_progress:on_progress(deepcopy(acquired))
    result=deepcopy(records)
    for row in result:
        for item in [row,*row.get('other_comments',[])]:
            body=acquired[item['note_id']]
            item['search_post_title']=item.get('post_title','')
            if body['title']:item['post_title']=body['title']
            item['post_text']=body['body']
            item['parent_text']=''
            item['parent_relationship']='top_level_comment_on_post'
            removed={'parent_not_collected'}
            if body['body']:removed.add('post_body_missing')
            item['missing_context']=[flag for flag in item.get('missing_context',[]) if flag not in removed]
    return result,acquired

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection',required=True,help='现有采集器的collection.json或partial.json')
    parser.add_argument('--selected-input',help='登记后选出的新增、无阻断客户数组；原话必须与采集源一致')
    parser.add_argument('--output',required=True)
    parser.add_argument('--session-home');parser.add_argument('--sender-uid')
    parser.add_argument('--account');parser.add_argument('--style')
    parser.add_argument('--analyse',action='store_true',help='正文补齐后使用现有Codex分析和草稿流程')
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args(argv)
    source=json.loads(Path(args.collection).read_text('utf-8-sig'))
    selected=json.loads(Path(args.selected_input).read_text('utf-8-sig')) if args.selected_input else None
    records=source_records(source,selected)
    notes=sorted({item['note_id'] for row in records for item in [row,*row.get('other_comments',[])]})
    if len(notes)>20:raise Halt('单批正文补读最多二十篇，请按采集批次处理')
    if not args.execute:
        print(json.dumps({'mode':'preview','customers':len(records),'posts':len(notes),'analyse':args.analyse,'network':False,'send':False},ensure_ascii=False))
        return 0
    if not args.session_home or not args.sender_uid:raise Halt('执行必须指定现有独立会话和已核对账号')
    if args.analyse and (not args.account or not args.style or not args.selected_input):
        raise Halt('自动分析必须提供登记后新增选择、账号事实和语气样本')
    account=json.loads(Path(args.account).read_text('utf-8-sig')) if args.analyse else None
    style=json.loads(Path(args.style).read_text('utf-8-sig')) if args.analyse else None
    output=Path(args.output).resolve()
    if output.exists():raise Halt('输出目录已存在，禁止覆盖')
    home=Path(args.session_home).resolve(strict=True)
    contexts=cached_context(home,notes) if notes else {}
    os.environ['HOME']=str(home);os.environ['USERPROFILE']=str(home)
    sys.path.insert(0,str(ROOT.parent/'xhs-standalone-reply'))
    from standalone_reply import load_independent_cookies
    output.mkdir(parents=True,exist_ok=False)
    save(output/'collection-source.json',source)
    save(output/'selected-source.json',records)
    state={'status':'started','phase':'context','customers':len(records),'posts':len(notes),'send':False}
    save(output/'state.json',state)
    client=None
    try:
        if records:
            client=ContextClient(load_independent_cookies(home))
            collector.verify_identity(client,args.sender_uid)
            def read(note):
                ctx=contexts[note]
                return note_body(client.get_note_by_id(note,xsec_token=ctx['token'],xsec_source=ctx['source']),note)
            result,bodies=enrich_records(records,read,lambda value:save(output/'partial-context.json',value))
        else:result,bodies=[],{}
        save(output/'ai-input.json',result)
        save(output/'note-context.json',bodies)
        state.update(status='completed',phase='context',context_posts=len(bodies))
        save(output/'state.json',state)
        # Close platform session before starting model work. Model receives only
        # saved comment/title/body/relation fields through the existing prompt.
        if client is not None:client.close();client=None
        if args.analyse and result:
            state.update(status='started',phase='analysis');save(output/'state.json',state)
            ai=_ai_module()
            ai.create_batch(output/'ai-input.json',output/'analysis',args.sender_uid,account,style,ai.CodexProvider())
            state.update(status='completed',phase='analysis')
            save(output/'state.json',state)
        print(json.dumps(state,ensure_ascii=False));return 0
    except Exception as exc:
        # Raw vendor exceptions can include signed URLs or response values.
        state.update(status='stopped',reason=str(exc) if isinstance(exc,Halt) else type(exc).__name__)
        save(output/'state.json',state)
        print('停止：'+state['reason'],file=sys.stderr);return 2
    finally:
        if client is not None:client.close()

if __name__=='__main__':
    try:raise SystemExit(main())
    except (Halt,OSError,ValueError) as exc:
        print('停止：'+(str(exc) if isinstance(exc,Halt) else type(exc).__name__),file=sys.stderr)
        raise SystemExit(2)
