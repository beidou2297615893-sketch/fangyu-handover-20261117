import sys,json,importlib.util,ast
from pathlib import Path
root=Path.cwd();spec=importlib.util.spec_from_file_location('ai',root/'work/xhs-ai-standalone/pipeline.py');ai=importlib.util.module_from_spec(spec);spec.loader.exec_module(ai)
src=ast.parse((root/'work/xhs-context-lite-analysis/run.py').read_text('utf8'));f=next(n for n in src.body if isinstance(n,ast.FunctionDef) and n.name=='validate'); ns={'ai':ai};exec(compile(ast.Module(body=[f],type_ignores=[]),'original-validator','exec'),ns)
load=lambda p:json.loads(Path(p).read_text('utf-8-sig'))
b=root/'work/xhs-three-stage-integration/live-consumer/batch-0004'; rows=load(b/'input.json');mapped={r['comment_id']:r for r in rows};account=load(root/'work/xhs-ai-standalone/account-leimu.json');report=[];valid=[];redo=[]
for d in sorted((b/'analysis/batches').iterdir()):
 p=load(d/'input.json');raw=load(d/'raw.json')['items'];ids=[x['comment_id'] for x in p['comments']];good=[];bad=[];seen=set()
 for it in raw:
  key=it.get('target_comment_id')
  try:
   if key not in ids or key in seen:raise ValueError('unexpected or duplicate id')
   seen.add(key);v=ns['validate']([mapped[key]],[it],account);valid.extend(v);good.append(key)
  except Exception as e:bad.append({'id':key,'error':str(e),'item':it,'row':mapped.get(key)});redo.extend([mapped[key]] if key in mapped and key in ids else [])
 missing=set(ids)-seen;redo.extend(mapped[k] for k in missing)
 report.append({'batch':d.name,'expected':len(ids),'raw':len(raw),'valid':len(good),'missing':list(missing),'invalid':bad})
 print(d.name,'expected',len(ids),'raw',len(raw),'valid',len(good),'missing',list(missing),'bad',json.dumps(bad,ensure_ascii=False))
out=root/'work/xhs-analysis-recovery'
for name,value in [('diagnosis.json',report),('reused-analysis.json',valid),('redo-input.json',redo)]: (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')

