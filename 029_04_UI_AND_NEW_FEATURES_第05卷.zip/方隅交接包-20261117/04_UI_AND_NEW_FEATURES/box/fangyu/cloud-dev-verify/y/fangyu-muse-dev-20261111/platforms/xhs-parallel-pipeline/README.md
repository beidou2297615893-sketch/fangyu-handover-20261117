# 独立并行采集入口

三个持久队列各自推进：评论采集和账本登记 → 正文补读 → Codex 判断。采集完成一批就进入下一页，不等待 AI。正文补读与判断不合并，正文完成立即可交给独立 AI 工作线程。模型失败会停留在该批分析记录，采集仍可继续。

当前用同一个“蕾姆”CLI 会话，采集和正文平台阶段有共享互斥，避免多个进程同时写会话缓存；两个队列在批次边界交替获得网络执行机会，AI 与平台读取可以同时进行。不是无限提高平台请求并发，也不改变原平台频率、安全停止或接口白名单。

本入口不发评论。只复用现有采集器、登记器、正文读取器及 Codex 分析。默认仅预览，无网络。

可直接预览本机已核对配置：`& .\work\xhs-parallel-pipeline\start.ps1`。默认三个关键词各五个搜索页，共十五个采集任务，每页最多十篇、每篇两页评论。

所有其他采集和正文平台任务结束后，追加 `-Execute` 会通过 Windows `Start-Process -WindowStyle Hidden` 启动独立 Python 进程，并在本目录 `logs` 记录 PID、标准输出和错误路径。会话 UID 仅从既有真实采集的本地 checkpoint 读取，启动器不读取或输出 Cookie/Token。未在当前任务中实际启动该后台入口，因此不能将预览成功说成后台生产链验收。

## 启动前

1. 先结束其他采集或正文平台读取，且确认旧任务不再自动进入下一批。
2. 与旧连续启动器共用账本目录 `.xhs-collection-runner.lock`；存在旧锁时会拒绝启动。不得未经核查删除活跃任务的锁。
3. 采用已核对的独立会话、真实账本、源客户库、账号资料和语气配置。不要使用测试库。

在项目根目录先预览：

```powershell
& .\work\vendor\cli-runtime\Scripts\python.exe -X utf8 .\work\xhs-parallel-pipeline\parallel.py --keyword '古北租房' --keyword '古北求租' --search-start-page 1 --search-pages 3 --max-notes 10 --max-pages 2 --output '.\work\xhs-parallel-pipeline\work\古北并行采集'
```

实际执行在相同命令追加：

```text
--session-home <已核对独立会话目录> --sender-uid <已核对蕾姆UID> --source-db <真实源客户库文件> --ledger <共享账本文件> --account <现有account-leimu.json> --style <现有style-leimu.json> --execute
```

参数值必须使用真实已核对内容；尖括号不是可运行占位值。输出目录须为空或不存在。现有已完成批次不能直接作为新入口目录。

## 查看与暂停

根目录 `state.json` 分别记录每批的 `collection/context/analysis` 状态和新增数；每批下保存原始采集、登记预览/结果、精确新增数组、正文与 AI 输出。

在输出目录创建名为 `STOP` 的文件，采集和正文在当前受控阶段结束后暂停，AI 完成已领取的判断；删除 STOP 后使用完全相同参数追加 `--resume` 恢复。恢复只接受没有失败和执行中未知结果的安全暂停点。遇平台错误、验证、限流或未知失败即停止新平台阶段；不会自动重试、换号或改写登录。

异常退出若留下 `running` 状态或锁，须核对相应批次与账本：程序不会自动把它当失败重采。登记可能已提交而报告未完成时，禁止重新执行写入步骤。

## 范围与限制

- 按指定关键词和搜索页码推进。任务列表用完后退出，不会不停重复第一页；`--search-pages` 为 1–20，搜索页码最高 100，每篇评论页数 1–20。
- 上游每个批次的搜索会话可能变化，排序也可能变化，故按评论 ID 去重，不能保证完整无遗漏。
- 评论页 cursor 尚未在本入口跨批次续接；当前每篇仍以原采集器的有界页数读取。截断和待核保留在原始结果，不能把它称为已采完。
- 原 `start.cmd` 菜单和软件尚未接入这个新入口；离线验证不等于真实平台验收。
- 本入口只管理自己创建的批次，不能自动接管旧独立目录中的待正文/待分析记录；那些资料保留原路径，可用现有 context_pipeline 单独处理，不能把旧任务状态直接搬进新队列。
- 没有访问平台、改生产账本或发送评论的离线测试命令：`work\vendor\cli-runtime\Scripts\python.exe -X utf8 -m unittest discover -s work\xhs-parallel-pipeline -v`。
