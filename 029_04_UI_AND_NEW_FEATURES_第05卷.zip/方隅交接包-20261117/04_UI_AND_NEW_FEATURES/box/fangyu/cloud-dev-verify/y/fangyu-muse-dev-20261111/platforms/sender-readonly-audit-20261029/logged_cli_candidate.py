"""Isolated review entry. Current 461 hold forbids execute; preview remains usable."""
from pathlib import Path
import importlib.util,sys
ROOT=Path(__file__).resolve().parent.parent

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def main(argv=None):
 argv=list(sys.argv[1:] if argv is None else argv)
 if '--execute' in argv:
  print('停止：目标读取返回461，平台验证尚未确认恢复；此候选禁止发送。',file=sys.stderr);return 2
 cli=load('logged_original_cli',ROOT/'xhs-cli-standalone-entry/standalone_cli.py')
 recording=load('logged_projection_candidate',ROOT/'xhs-recording-audit/project_send_log.py')
 from logged_sender_candidate import attach
 original_loader=cli.load_sender
 def loader(project_root,ledger,batch_path,source_files):
  module=original_loader(project_root,ledger,batch_path,source_files)
  attach(module,ledger,Path(__file__).resolve().parent/'send-events.txt',recording.sync,
         lambda:(Path(__file__).resolve().parent/'STOP').exists())
  return module
 cli.load_sender=loader
 return cli.main(argv)
if __name__=='__main__':raise SystemExit(main())
