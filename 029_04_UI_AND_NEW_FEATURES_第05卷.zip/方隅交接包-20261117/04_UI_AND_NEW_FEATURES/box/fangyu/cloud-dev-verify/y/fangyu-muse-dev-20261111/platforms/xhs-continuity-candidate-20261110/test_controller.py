import json
from datetime import datetime, timezone
from pathlib import Path
import socket
import tempfile
import unittest
from unittest.mock import patch

try:
    from controller import Controller, Snapshot, Outcome, ProjectLock, Busy, beijing_day
except ImportError:
    Controller = Snapshot = Outcome = ProjectLock = Busy = None


class FakeAdapter:
    def __init__(self, outcomes, **overrides):
        self.outcomes = list(outcomes)
        self.calls = []
        self.overrides = overrides
        self.checkpoints = []

    def inspect(self, checkpoint):
        self.checkpoints.append(checkpoint)
        return Snapshot(uid='actual-B', verified_uid='actual-B', identity_verified=True,
                        ledger_ready=True, checkpoint_safe=True, count_known=True,
                        count_day=beijing_day(datetime.now(timezone.utc)),
                        **self.overrides)

    def step(self, checkpoint):
        self.calls.append(checkpoint)
        v = self.outcomes.pop(0)
        if isinstance(v, Exception):
            raise v
        return v


class TestController(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(Controller, '监督器尚未实现')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.alerts = []
        self.sleeps = []
        self.net = patch.object(socket.socket, 'connect', side_effect=AssertionError('network forbidden'))
        self.net.start()
        self.addCleanup(self.net.stop)

    def controller(self, lane='send'):
        return Controller(self.root, lane=lane, uid='actual-B',
                          notify=lambda *args: self.alerts.append(args), sleep=self.sleeps.append)

    def test_resume_uses_committed_checkpoint(self):
        a = FakeAdapter([Outcome('success', next_checkpoint={'cursor': 1}, receipt_confirmed=True),
                         Outcome('completed')])
        c = self.controller()
        self.assertEqual(c.run(a)['status'], 'completed')
        self.assertEqual(a.calls, [{}, {'cursor': 1}])
        b = FakeAdapter([Outcome('completed')])
        self.controller().run(b)
        self.assertEqual(b.calls[0], {'cursor': 1})

    def test_network_retry_is_bounded_with_backoff(self):
        a = FakeAdapter([Outcome('network_error')] * 4)
        result = self.controller().run(a)
        self.assertEqual(len(a.calls), 4)
        self.assertEqual(self.sleeps, [5, 10, 20])
        self.assertEqual(result['reason'], 'retry_exhausted')
        self.assertGreaterEqual(len(self.alerts), 4)

    def test_safe_network_resume_does_not_reset_checkpoint(self):
        a = FakeAdapter([Outcome('success', next_checkpoint={'cursor': 4}, receipt_confirmed=True),
                         Outcome('network_error'), Outcome('completed')])
        self.controller().run(a)
        self.assertEqual(a.calls, [{}, {'cursor': 4}, {'cursor': 4}])

    def test_validation_never_retries(self):
        for kind in ['verification', 'identity_error', 'outcome_unknown', 'rate_limit']:
            with self.subTest(kind=kind):
                c = Controller(self.root / kind, lane='send', uid='actual-B', notify=lambda *a: None)
                a = FakeAdapter([Outcome(kind)])
                result = c.run(a)
                self.assertEqual(len(a.calls), 1)
                self.assertEqual(result['reason'], kind)

    def test_snapshot_blocks_before_step(self):
        for key, val in [('platform_blocked', True), ('validation_required', True),
                         ('current_unknown', True), ('pending_submission', True),
                         ('checkpoint_safe', False), ('identity_verified', False),
                         ('ledger_ready', False), ('verified_uid', 'different')]:
            with self.subTest(key=key):
                c = Controller(self.root / key, lane='send', uid='actual-B', notify=lambda *a: None)
                a = FakeAdapter([])
                orig = a.inspect
                def inspect(cp, orig=orig, key=key, val=val):
                    s = orig(cp)
                    setattr(s, key, val)
                    return s
                a.inspect = inspect
                self.assertEqual(c.run(a)['status'], 'stopped')
                self.assertEqual(a.calls, [])

    def test_post_timeout_unknown_not_network_retry(self):
        a = FakeAdapter([Outcome('timeout', post_started=True)])
        r = self.controller().run(a)
        self.assertEqual(r['reason'], 'outcome_unknown')
        self.assertEqual(len(a.calls), 1)
        self.assertEqual(self.sleeps, [])

    def test_plain_exception_has_no_raw_error_in_state(self):
        a = FakeAdapter([TimeoutError('secret-cookie-example')])
        r = self.controller().run(a)
        self.assertEqual(r['reason'], 'outcome_unknown')
        self.assertNotIn('secret-cookie', (self.root / 'controller-status.json').read_text('utf8'))
        self.assertEqual(len(a.calls), 1)

    def test_no_receipt_on_send_success_is_unknown(self):
        r = self.controller().run(FakeAdapter([Outcome('success', next_checkpoint={'cursor': 8})]))
        self.assertEqual(r['reason'], 'outcome_unknown')
        self.assertEqual(r['checkpoint'], {})

    def test_new_uid_uses_new_lane_state_without_erasing_old(self):
        self.controller().run(FakeAdapter([Outcome('outcome_unknown')]))
        b = Controller(self.root, lane='send', uid='account-C', notify=lambda *a: None)
        a = FakeAdapter([])
        # Controller must not let a different UID erase or unlock current unknown.
        self.assertEqual(b.run(a)['reason'], 'account_change_requires_review')
        self.assertEqual(a.calls, [])

    def test_restart_after_unknown_stays_stopped(self):
        self.controller().run(FakeAdapter([Outcome('outcome_unknown')]))
        a = FakeAdapter([])
        self.assertEqual(self.controller().run(a)['reason'], 'outcome_unknown')
        self.assertEqual(a.calls, [])

    def test_crash_inflight_needs_positive_reconciliation(self):
        c = self.controller()
        c._persist(status='running', inflight=True, checkpoint={'cursor': 2})
        a = FakeAdapter([Outcome('completed')], recovered_no_submission=False)
        self.assertEqual(c.run(a)['reason'], 'outcome_unknown')
        self.assertEqual(a.calls, [])

    def test_crash_with_proven_no_submission_resumes(self):
        c = self.controller()
        c._persist(status='running', inflight=True, checkpoint={'cursor': 2})
        a = FakeAdapter([Outcome('completed')], recovered_no_submission=True)
        self.assertEqual(c.run(a)['status'], 'completed')
        self.assertEqual(a.calls, [{'cursor': 2}])

    def test_quota_200_stops_without_step(self):
        a = FakeAdapter([], sent_today=200)
        r = self.controller().run(a)
        self.assertEqual(r['action'], '换号')
        self.assertEqual(r['reason'], 'daily_limit')
        self.assertFalse(a.calls)

    def test_unknown_daily_count_does_not_assume_zero(self):
        a = FakeAdapter([])
        orig = a.inspect
        def inspect(cp):
            s = orig(cp)
            s.count_known = False
            return s
        a.inspect = inspect
        self.assertEqual(self.controller().run(a)['reason'], 'count_unconfirmed')

    def test_collect_does_not_require_send_quota(self):
        a = FakeAdapter([Outcome('success', next_checkpoint={'cursor': 1}, new_items=7), Outcome('completed')],
                        sent_today=200)
        result = self.controller('collect').run(a)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(result['new_items'], 7)

    def test_consecutive_rejects_stop_and_do_not_retry_target(self):
        a = FakeAdapter([Outcome('rejected', next_checkpoint={'cursor': n}, definitive_rejection=True) for n in (1, 2, 3)])
        r = self.controller().run(a)
        self.assertEqual(r['reason'], 'consecutive_rejections')
        self.assertEqual(r['checkpoint'], {'cursor': 3})
        self.assertEqual(self.sleeps, [])

    def test_global_lock_excludes_second_lane_and_auto_releases(self):
        lock = ProjectLock(self.root)
        with lock:
            with self.assertRaises(Busy):
                with ProjectLock(self.root):
                    pass
        with ProjectLock(self.root):
            pass

    def test_process_disappearance_alert_is_durable(self):
        c = self.controller()
        c._persist(status='running', inflight=True)
        r = c.observe_exit(worker_alive=False)
        self.assertEqual(r['reason'], 'outcome_unknown')
        self.assertEqual(r['action'], '待核对')
        self.assertEqual(len(self.alerts), 1)
        self.assertEqual(c.observe_exit(worker_alive=False)['reason'], 'outcome_unknown')
        self.assertEqual(len(self.alerts), 1)

    def test_process_disappearance_without_inflight_is_recoverable_notice(self):
        c = self.controller()
        c._persist(status='running', inflight=False)
        r = c.observe_exit(worker_alive=False)
        self.assertEqual(r['reason'], 'process_lost')
        self.assertEqual(r['action'], '按启动')

    def test_notify_failure_is_visible(self):
        c = Controller(self.root, lane='send', uid='actual-B',
                       notify=lambda *a: (_ for _ in ()).throw(OSError('no desktop')))
        r = c.run(FakeAdapter([Outcome('verification')]))
        self.assertTrue(r['notification_failed'])

    def test_terminal_halt_no_button_override(self):
        c = self.controller()
        c.run(FakeAdapter([Outcome('verification')]))
        a = FakeAdapter([])
        self.assertEqual(self.controller().run(a)['reason'], 'verification')
        self.assertFalse(a.calls)

    def test_complete_also_notifies(self):
        self.controller().run(FakeAdapter([Outcome('completed')]))
        self.assertEqual(len(self.alerts), 1)

    def test_malformed_persisted_state_is_blocked(self):
        (self.root / 'send-state.json').write_text('{broken', encoding='utf8')
        c = self.controller()
        self.assertEqual(c.run(FakeAdapter([]))['reason'], 'state_invalid')

    def test_send_validation_after_post_preserves_unknown(self):
        c = self.controller()
        r = c.run(FakeAdapter([Outcome('verification', post_started=True)]))
        self.assertEqual(r['reason'], 'outcome_unknown')
        self.assertEqual(r['action'], '过验证')
        self.assertTrue(r['inflight'])

    def test_nondefinitive_rejection_never_skips_target(self):
        r = self.controller().run(FakeAdapter([Outcome('rejected', next_checkpoint={'cursor': 7})]))
        self.assertEqual(r['reason'], 'outcome_unknown')
        self.assertEqual(r['checkpoint'], {})

    def test_local_counter_limits_even_if_snapshot_lags(self):
        a = FakeAdapter([Outcome('success', next_checkpoint={'cursor': 1}, receipt_confirmed=True)], sent_today=199)
        r = self.controller().run(a)
        self.assertEqual(r['reason'], 'daily_limit')
        self.assertEqual(r['today_sent'], 200)
        self.assertEqual(len(a.calls), 1)

    def test_snapshot_invalid_shape_never_crashes_or_starts(self):
        a = FakeAdapter([])
        a.inspect = lambda _: Snapshot(uid='actual-B', verified_uid='actual-B',
            identity_verified=1, checkpoint_safe=True, ledger_ready=True, count_known=True)
        self.assertEqual(self.controller().run(a)['reason'], 'adapter_error')

    def test_process_observer_refuses_nonboolean_liveness(self):
        with self.assertRaises(ValueError):
            self.controller().observe_exit(worker_alive='dead')


if __name__ == '__main__':
    unittest.main(verbosity=2)
