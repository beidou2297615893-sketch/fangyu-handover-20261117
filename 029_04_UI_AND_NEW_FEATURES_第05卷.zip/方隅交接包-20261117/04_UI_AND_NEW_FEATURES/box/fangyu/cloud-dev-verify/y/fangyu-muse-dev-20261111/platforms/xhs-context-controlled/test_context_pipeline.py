import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import types
import os

spec=importlib.util.spec_from_file_location('context_pipeline',Path(__file__).with_name('context_pipeline.py'))
module=importlib.util.module_from_spec(spec)
if spec.loader: spec.loader.exec_module(module)

def record(cid='c1',note='n1'):
    return {'customer_id':'local1','customer_uid':'u1','comment_id':cid,'note_id':note,'comment_text':'请问还有房吗',
            'post_title':'搜索标题','post_text':'','parent_text':'','parent_relationship':'not_collected',
            'missing_context':['post_body_missing','parent_not_collected','subcomments_not_collected'],'other_comments':[]}

class ContextPipelineTests(unittest.TestCase):
    def test_enriches_every_record_once_and_preserves_original(self):
        rows=[record()];rows[0]['other_comments']=[{**record('c2'),'other_comments':[]}]
        calls=[]
        def read(note):
            calls.append(note);return {'note_id':note,'title':'正文标题','body':'我在古北出租一居室'}
        result,bodies=module.enrich_records(rows,read)
        self.assertEqual(calls,['n1'])
        self.assertEqual(rows[0]['post_text'],'')
        for row in [result[0],*result[0]['other_comments']]:
            self.assertEqual(row['post_text'],'我在古北出租一居室')
            self.assertEqual(row['parent_relationship'],'top_level_comment_on_post')
            self.assertEqual(row['search_post_title'],'搜索标题')
            self.assertEqual(row['missing_context'],['subcomments_not_collected'])
        self.assertEqual(len(bodies),1)

    def test_partial_failure_saves_only_acquired_context_and_stops(self):
        calls=[];saved=[]
        rows=[record()];rows[0]['other_comments']=[{**record('c2','n2'),'other_comments':[]}]
        def read(note):
            calls.append(note)
            if note=='n2':raise module.Halt('验证要求，停止')
            return {'note_id':note,'title':'标题','body':'正文'}
        with self.assertRaises(module.Halt):module.enrich_records(rows,read,lambda value:saved.append(value))
        self.assertEqual(calls,['n1','n2'])
        self.assertEqual(list(saved[-1]),['n1'])

    def test_rejects_unrelated_selected_records_before_reading(self):
        source={'schema':'xhs-collected-ai-input-v1','customers':[record()]}
        bad=record();bad['comment_text']='被改写的原话'
        with self.assertRaises(module.Halt):module.source_records(source,[bad])

    def test_registrar_can_select_new_other_comment_as_lead(self):
        original=record();original['other_comments']=[{k:v for k,v in record('c2','n2').items() if k not in ('customer_id','customer_uid','other_comments')}]
        selected=record('c2','n2')
        result=module.source_records({'schema':'xhs-collected-ai-input-v1','customers':[original]},[selected])
        self.assertEqual(result[0]['comment_id'],'c2')

    def test_empty_body_stays_explicitly_missing(self):
        rows,_=module.enrich_records([record()],lambda n:{'note_id':n,'title':'标题','body':''})
        self.assertIn('post_body_missing',rows[0]['missing_context'])
        self.assertNotIn('parent_not_collected',rows[0]['missing_context'])

    def test_preview_does_not_contact_platform_or_create_output(self):
        with tempfile.TemporaryDirectory() as temp:
            source=Path(temp)/'source.json';out=Path(temp)/'out'
            source.write_text(json.dumps({'schema':'xhs-collected-ai-input-v1','customers':[record()]}),encoding='utf8')
            self.assertEqual(module.main(['--collection',str(source),'--output',str(out)]),0)
            self.assertFalse(out.exists())

    def test_complete_entry_passes_saved_body_into_ai_and_never_sends(self):
        class Client:
            def __init__(self,cookies):self.calls=[]
            def get_self_info(self):return {'user_id':'sender'}
            def get_note_by_id(self,note,**kwargs):
                return {'items':[{'note_card':{'note_id':note,'title':'真实出租标题','desc':'古北一居室出租'}}]}
            def close(self):pass
        ai=module._ai_module();seen=[]
        def create(input_path,*args):seen.extend(json.loads(Path(input_path).read_text('utf8')))
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ):
            directory=Path(temp);source=directory/'collection.json';selected=directory/'selected.json';out=directory/'out'
            source.write_text(json.dumps({'schema':'xhs-collected-ai-input-v1','customers':[record()]}),encoding='utf8')
            selected.write_text(json.dumps([record()]),encoding='utf8')
            account=directory/'account.json';account.write_text('{}');style=directory/'style.json';style.write_text('[]')
            with patch.object(module,'ContextClient',Client),patch.object(module,'cached_context',return_value={'n1':{'token':'private','source':'pc_search'}}),patch.object(module,'_ai_module',return_value=ai),patch.object(ai,'create_batch',side_effect=create),patch.dict('sys.modules',{'standalone_reply':types.SimpleNamespace(load_independent_cookies=lambda home:{})}):
                code=module.main(['--collection',str(source),'--selected-input',str(selected),'--output',str(out),'--session-home',temp,'--sender-uid','sender','--account',str(account),'--style',str(style),'--analyse','--execute'])
            self.assertEqual(code,0)
            self.assertEqual(seen[0]['post_text'],'古北一居室出租')
            self.assertEqual(seen[0]['comment_text'],'请问还有房吗')
            self.assertNotIn('private',json.dumps(json.loads((out/'ai-input.json').read_text('utf8'))))
            self.assertEqual(json.loads((out/'state.json').read_text('utf8'))['phase'],'analysis')

    def test_failed_context_creates_no_ai_input_and_preserves_source(self):
        class Client:
            def __init__(self,cookies):pass
            def get_self_info(self):return {'user_id':'sender'}
            def get_note_by_id(self,note,**kwargs):raise module.Halt('平台读取失败：461')
            def close(self):pass
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ):
            directory=Path(temp);source=directory/'collection.json';out=directory/'out'
            source.write_text(json.dumps({'schema':'xhs-collected-ai-input-v1','customers':[record()]}),encoding='utf8')
            with patch.object(module,'ContextClient',Client),patch.object(module,'cached_context',return_value={'n1':{'token':'private','source':'pc_search'}}),patch.dict('sys.modules',{'standalone_reply':types.SimpleNamespace(load_independent_cookies=lambda home:{})}):
                code=module.main(['--collection',str(source),'--output',str(out),'--session-home',temp,'--sender-uid','sender','--execute'])
            self.assertEqual(code,2)
            self.assertFalse((out/'ai-input.json').exists())
            self.assertTrue((out/'collection-source.json').exists())
            self.assertEqual(json.loads((out/'state.json').read_text('utf8'))['status'],'stopped')

if __name__=='__main__':unittest.main()
