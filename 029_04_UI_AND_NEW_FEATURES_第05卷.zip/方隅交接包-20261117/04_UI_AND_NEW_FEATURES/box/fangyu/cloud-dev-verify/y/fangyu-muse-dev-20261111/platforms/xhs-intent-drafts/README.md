# 分析后生成待审核草稿

本目录只读原始采集、分析和共享账本，写本目录与人用导出目录；不含平台调用或发送入口。复用已核实的官方Codex订阅CLI、现有账号事实和口吻样本。不要把analysis.should_reply=false作为排除草稿条件。

初始执行：`python work/xhs-intent-drafts/run.py --execute --sample`，确认样本内容后执行 `python work/xhs-intent-drafts/run.py --execute`。

已完成后的增量：`python work/xhs-intent-drafts/run.py --execute --extra-input work/xhs-intent-drafts/incremental-input.json --extra-analysis work/xhs-intent-drafts/incremental-analysis.json`。

`batch-plan.json`固定旧批目标，原指纹一致时复用validated结果，仅新目标追加批次。后续增量输入/分析必须累计保留此前增量；若既有UID候选或源资料变化触发指纹/计划冲突，则停止并要求人工核准，不能覆盖旧稿。当前所有批已完成后才能再次启动，不并发执行本脚本。

`python work/xhs-intent-drafts/export.py`导出人用CSV与说明；完整身份、原文与分析证据留在drafts.json内。每次增量重新读取账本；对历史发送、状态不明、可见本人已回复与同UID重复做保护。账本未在线复核，不代表发送前核验完成。

本人地区和帖子地区分别处理；当前需求未在线复核，评论日期只能用于排序。缺正文逐条记录。保留原分析结果，不以草稿阶段的暂缓决定覆盖意向分类。
