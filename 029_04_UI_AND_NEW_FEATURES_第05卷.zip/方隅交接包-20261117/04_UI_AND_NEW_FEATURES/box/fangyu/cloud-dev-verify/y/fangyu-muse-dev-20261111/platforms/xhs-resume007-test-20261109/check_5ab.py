﻿import socket, sys, os
ATTEMPTS = []
_c = socket.socket.connect
def _blk(self, addr, *a, **k):
    ATTEMPTS.append(repr(addr)); raise OSError('network blocked by retest harness')
socket.socket.connect = _blk
socket.socket.connect_ex = _blk
_cc = socket.create_connection
def _cc_blk(addr, *a, **k):
    ATTEMPTS.append('create_connection ' + repr(addr)); raise OSError('blocked')
socket.create_connection = _cc_blk
sys.path.insert(0, os.getcwd())
import resume007 as m
m.refresh_paths()
R = r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统'
print('5a')
for n in ('PROJECT','HERE','LEDGER','RESUME006_ROOT','LIVE_TASKS','STOP_TODAY_FIXED'):
    p = getattr(m, n); print(f'  {n} = {p}  exists={p.exists()}')
print('  PROJECT==R:', os.path.normcase(str(m.PROJECT.resolve())) == os.path.normcase(R))
print('5b')
called = []
import importlib
try:
    sys.path.insert(0, str(m.PROJECT / 'work/xhs-new-task-session-fix-20261029'))
    import integration
    _cf = integration.client_factory
    def _spy(*a, **k):
        called.append(1); raise RuntimeError('client_factory called in retest')
    integration.client_factory = _spy
    live, cand, once, sched, cf = m._get_runtime()
    for n, o in (('live',live),('candidate',cand),('once',once),('scheduling',sched)):
        print(f'  {n}: type={type(o).__name__} name={getattr(o,"__name__",None)} file={getattr(o,"__file__",None)}')
    print('  once.history_index exists:', callable(getattr(once,'history_index',None)))
    print('  client_factory_fn is (spied) integration.client_factory:', cf is _spy, ' called:', len(called))
except Exception as e:
    print('  LOAD FAILED:', type(e).__name__, str(e)[:300])
print('network attempts:', ATTEMPTS)
