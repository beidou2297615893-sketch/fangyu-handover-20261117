"""Exact singleton continuation only; synthetic files, ledger and transports."""
import hashlib
import json
from contextlib import closing, contextmanager
from dataclasses import asdict, replace
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
import unittest
from unittest.mock import patch

import bulk_run as bulk
import scoped_isolation as scope
import test_bulk_run as base_tests
import httpx
from managed_send_client import make_client
from readback_client import ReadbackClient


class Tests(unittest.TestCase):
    def setUp(self):
        self.fixture = base_tests.ExactLegacyPolicy('test_default_and_non_direct_policy_keep_original_account_block')
        self.fixture.setUp()
        self.root, self.sender, self.db = self.fixture.root, self.fixture.sender, self.fixture.db
        self.uid = scope.SCOPED_UID
        self.plan = replace(self.fixture.plan, sender_uid=self.uid, attempt_id=scope.ALLOWED_ATTEMPT)
        self.old_data = json.dumps({'plan': {'sender_uid': self.uid, 'customer_uid': 'old-uid'},
                                    'result': {'kind': 'unknown', 'api_code': -1}})
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('UPDATE reservations SET token=?', (scope.ISOLATED_ATTEMPT,))
            db.execute('UPDATE local_sender_plans SET token=?,data=?', (scope.ISOLATED_ATTEMPT, self.old_data))
            db.commit()
        self.marker_patch = patch.object(bulk, 'EMERGENCY_HALT_ROOT', self.root / 'markers')
        self.marker_patch.start()
        self.state = self.root / 'state.json'
        self.marker = bulk.halt_marker_path(self.state, self.uid)
        self.marker.parent.mkdir()
        halted = {'sender_uid': self.uid, 'state': 'unknown_requires_reconciliation', 'cleared': False,
                  'diagnostic': {'api_code': -1, 'http_status': 200}}
        for path in (self.state, self.marker):
            path.write_text(json.dumps(halted), encoding='utf8')
        self.row = {'attempt_id': self.plan.attempt_id, 'customer_uid': self.plan.customer_uid,
            'customer_id': self.plan.canonical_customer, 'comment_id': self.plan.comment_id,
            'note_id': self.plan.note_id, 'text': self.plan.text}
        self.approved = self.root / 'approved.json'
        self.singleton = self.root / 'singleton.json'
        base = {'schema': 'xhs-local-plan-v1', 'intended_account_uid': self.uid, 'source_sha256': {'frozen': 'same'}}
        rows = [{**self.row, 'attempt_id': 'filler-' + str(i)} for i in range(566)] + [self.row]
        self.approved.write_text(json.dumps({**base, 'count': 567, 'rows': rows}), encoding='utf8')
        self.singleton.write_text(json.dumps({**base, 'count': 1, 'rows': [self.row]}), encoding='utf8')
        self.constants = patch.multiple(scope, APPROVED_SHA=bulk.digest(self.approved),
            SINGLETON_SHA=bulk.digest(self.singleton), ISOLATED_RECORD_SHA=hashlib.sha256(self.old_data.encode()).hexdigest(),
            STATE_SHA=bulk.digest(self.state), MARKER_SHA=bulk.digest(self.marker))
        self.constants.start()
        self.grant = scope.ScopedUnknownIsolationPolicy.from_mapping({
            'schema': 'xhs-single-authorized-unknown-isolation-v1',
            'policy_id': 'huihui-unknown8-next-authorized-once-v1', 'sender_uid': self.uid,
            'approved_batch_path': str(self.approved), 'approved_batch_sha256': bulk.digest(self.approved),
            'singleton_batch_sha256': bulk.digest(self.singleton), 'isolated_attempt_id': scope.ISOLATED_ATTEMPT,
            'isolated_record_raw_sha256': scope.ISOLATED_RECORD_SHA, 'allowed_attempt_id': scope.ALLOWED_ATTEMPT,
            'platform_state_path': str(self.state), 'platform_state_sha256': bulk.digest(self.state),
            'halt_marker_path': str(self.marker), 'halt_marker_sha256': bulk.digest(self.marker)})
        self.sender.PREPARED_BATCH = self.singleton

    def tearDown(self):
        self.constants.stop()
        self.marker_patch.stop()
        self.fixture.tearDown()

    def reserve(self, grant=None, plan=None):
        self.sender._reserve(self.db, plan or self.plan, True, direct_id=True,
                             scoped_isolation_policy=grant)

    def test_default_closed_exact_grant_only_allows_bound_singleton_without_altering_old_rows(self):
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state, self.uid)
        with self.assertRaises(self.sender.Refused):
            self.reserve()
        bulk.require_platform_access(self.state, self.uid, scoped_grant=self.grant, batch_path=self.singleton)
        state_before, marker_before = self.state.read_bytes(), self.marker.read_bytes()
        self.reserve(self.grant)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT data FROM local_sender_plans WHERE token=?', (scope.ISOLATED_ATTEMPT,)).fetchone()[0], self.old_data)
            self.assertEqual(db.execute('SELECT status FROM reservations WHERE token=?', (scope.ISOLATED_ATTEMPT,)).fetchone()[0], 'unknown')
        self.assertEqual(self.state.read_bytes(), state_before)
        self.assertEqual(self.marker.read_bytes(), marker_before)
        with self.assertRaises(self.sender.Refused):
            self.reserve(self.grant)

    def test_wrong_bindings_and_changed_target_or_verification_are_rejected(self):
        for field, value in [('sender_uid', 'other'), ('approved_batch_sha256', '0'*64),
                ('platform_state_sha256', '0'*64), ('halt_marker_sha256', '0'*64),
                ('isolated_record_raw_sha256', '0'*64), ('allowed_attempt_id', 'other')]:
            with self.subTest(field=field), self.assertRaises(bulk.Stop):
                bulk.require_platform_access(self.state, self.uid,
                    scoped_grant=replace(self.grant, **{field: value}), batch_path=self.singleton)
        original = self.singleton.read_bytes()
        batch = bulk.read_json(self.singleton)
        batch['rows'][0]['text'] = 'changed'
        self.singleton.write_text(json.dumps(batch), encoding='utf8')
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state, self.uid, scoped_grant=self.grant, batch_path=self.singleton)
        self.singleton.write_bytes(original)
        state = bulk.read_json(self.state)
        state['diagnostic']['verification_header_present'] = True
        self.state.write_text(json.dumps(state), encoding='utf8')
        bad = replace(self.grant, platform_state_sha256=bulk.digest(self.state))
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state, self.uid, scoped_grant=bad, batch_path=self.singleton)

    def test_original_customer_uid_is_still_blocked_and_new_unknown_cannot_be_isolated(self):
        with self.assertRaises(self.sender.Refused):
            self.reserve(self.grant, replace(self.plan, customer_uid='old-uid'))
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                ('new-unknown', 'xiaohongshu', 'other-customer', 'other-comment', 'unknown', None, 2))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)', ('new-unknown', self.old_data))
            db.commit()
        with self.assertRaises(self.sender.Refused):
            self.reserve(self.grant)

    def run_native_singleton(self, success, identity_restriction=False):
        session = self.root / 'synthetic-cookies.json'
        session.write_text(json.dumps({'a1': 'synthetic', 'web_session': 'synthetic', 'webId': 'synthetic'}), encoding='utf8')
        calls = []
        def transport(request):
            calls.append(request.url.path)
            if request.method == 'GET':
                return httpx.Response(200, json={'success': True, 'data': {'user_id': self.uid, 'guest': False}},
                    headers={'verifyuuid': 'synthetic-private-challenge'} if identity_restriction else None)
            return httpx.Response(200, json=({'success': True, 'code': 0, 'data': {'comment': {'id': 'synthetic-receipt'}}}
                if success else {'success': False, 'code': -1, 'msg': '系统错误'}))
        with make_client(self.sender, session, self.plan, transport=httpx.MockTransport(transport)) as client:
            adapter = bulk.LiveAdapter.__new__(bulk.LiveAdapter)
            adapter.sender = self.sender
            adapter.last_client = client
            adapter.post_attempts = 0
            adapter.expected_uid = self.uid
            adapter.platform_access_state = self.state
            adapter.platform_access_state_digest = bulk.digest(self.state)
            adapter.initial_identity_receipt = None
            adapter.halt_writer = bulk.atomic_platform_state
            adapter._permanent_halt = False
            adapter.ledger = self.db
            adapter.identity = lambda: {'uid': self.uid, 'guest': False}
            adapter.state = lambda row: 'pending'
            adapter.close = lambda: None
            def submit(row):
                try:
                    return self.sender.Runner(self.db, client, synthetic=True, direct_id=True,
                        scoped_isolation_policy=self.grant).submit(self.plan)
                finally:
                    adapter.post_attempts += int(client._post_started)
            adapter.submit = submit
            meta = {'customer_uid': self.row['customer_uid'], 'canonical_customer': self.row['customer_id'],
                'post_title': 'available synthetic apartment', 'original_comment': 'synthetic original',
                'published_at': datetime.now(timezone.utc).isoformat()}
            report = bulk.run([self.row], {self.row['comment_id']: meta}, sender_uid=self.uid,
                session_home=self.root, run_dir=self.root/'run', execute=True, direct_id=True,
                adapter_factory=lambda root: adapter, interval=0)
        events = [json.loads(line) for line in (self.root/'run/events.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(calls.count('/api/sns/web/v1/comment/post'), 0 if identity_restriction else 1)
        return report, events

    def test_scoped_native_success_keeps_old_evidence_and_saves_safe_success_diagnostic(self):
        before = (self.state.read_bytes(), self.marker.read_bytes())
        report, events = self.run_native_singleton(True)
        self.assertEqual(report['accepted'], 1)
        self.assertEqual(report['visible_verified'], 0)
        diagnostic = next(event for event in events if event['event'] == 'accepted')['diagnostic']
        self.assertIs(diagnostic['success'], True)
        self.assertIs(diagnostic['verification_header_present'], False)
        self.assertEqual(diagnostic['api_code'], 0)
        self.assertEqual(diagnostic['http_status'], 200)
        self.assertEqual((self.state.read_bytes(), self.marker.read_bytes()), before)

    def test_scoped_new_unknown_remains_unknown_and_old_grant_cannot_restart(self):
        report, events = self.run_native_singleton(False)
        self.assertEqual(report['status'], 'stopped_unknown')
        self.assertEqual(report['accepted'], 0)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM reservations WHERE token=?', (scope.ALLOWED_ATTEMPT,)).fetchone()[0], 'unknown')
            self.assertEqual(db.execute('SELECT data FROM local_sender_plans WHERE token=?', (scope.ISOLATED_ATTEMPT,)).fetchone()[0], self.old_data)
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state, self.uid, scoped_grant=self.grant, batch_path=self.singleton)
        with self.assertRaises(self.sender.Refused):
            self.reserve(self.grant)

    def test_identity_http200_same_uid_with_verification_header_blocks_before_reserve(self):
        report, events = self.run_native_singleton(True, identity_restriction=True)
        self.assertEqual(report['post_attempts'], 0)
        self.assertEqual(report['accepted'], 0)
        self.assertEqual(bulk.read_json(self.state)['state'], 'verification_response_unresolved')
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT count(*) FROM reservations').fetchone()[0], 1)
            self.assertEqual(db.execute('SELECT data FROM local_sender_plans WHERE token=?',
                (scope.ISOLATED_ATTEMPT,)).fetchone()[0], self.old_data)
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state, self.uid, scoped_grant=self.grant, batch_path=self.singleton)

    def test_outer_readback_identity_verification_header_stops_before_native_identity(self):
        session = self.root / 'synthetic-readback-cookies.json'
        session.write_text(json.dumps({'a1': 'synthetic', 'web_session': 'synthetic', 'webId': 'synthetic'}), encoding='utf8')
        calls = []
        def transport(request):
            calls.append(request.url.path)
            return httpx.Response(200, json={'success': True, 'data': {'user_id': self.uid, 'guest': False}},
                                  headers={'verifytype': 'synthetic-private-verification'})
        with ReadbackClient(session, self.uid, transport=httpx.MockTransport(transport), delay=0) as client:
            adapter = bulk.LiveAdapter.__new__(bulk.LiveAdapter)
            adapter.sender = self.sender
            adapter.expected_uid = self.uid
            adapter.last_client = client
            adapter.post_attempts = 0
            adapter.platform_access_state = self.state
            adapter.platform_access_state_digest = bulk.digest(self.state)
            adapter.initial_identity_receipt = None
            adapter.halt_writer = bulk.atomic_platform_state
            adapter._permanent_halt = False
            adapter.close = lambda: None
            @contextmanager
            def opened(*args, **kwargs):
                yield client
            adapter._client = opened
            adapter.state = lambda row: self.fail('must not reach per-row state or native identity')
            report = bulk.run([self.row], {}, sender_uid=self.uid, session_home=self.root,
                run_dir=self.root/'outer-identity-run', execute=True, direct_id=True,
                adapter_factory=lambda root: adapter, interval=0)
        self.assertEqual(calls, ['/api/sns/web/v2/user/me'])
        self.assertEqual(report['post_attempts'], 0)
        self.assertEqual(bulk.read_json(self.state)['state'], 'verification_response_unresolved')
        events = [json.loads(line) for line in (self.root/'outer-identity-run/events.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertIs(next(e for e in events if e['event'] == 'stopped')['diagnostic']['verification_header_present'], True)


if __name__ == '__main__':
    unittest.main()
