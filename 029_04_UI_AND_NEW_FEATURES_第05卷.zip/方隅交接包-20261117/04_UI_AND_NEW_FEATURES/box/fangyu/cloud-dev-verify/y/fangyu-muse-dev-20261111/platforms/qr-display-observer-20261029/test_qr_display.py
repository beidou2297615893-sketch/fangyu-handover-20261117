import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from qr_display import QrDisplayObserver


class Request:
    method = 'POST'


class Response:
    url = 'https://edith.xiaohongshu.com/api/sns/web/v1/login/qrcode/create'
    request = Request()
    status = 200

    def __init__(self, payload):
        self.payload = payload

    def json(self):
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload


class ObserverTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.path = Path(self.temp.name)
        self.updates = []
        self.observer = QrDisplayObserver(self.path, self.updates.append)

    def tearDown(self):
        self.temp.cleanup()

    def read_state(self):
        self.assertTrue((self.path / 'status.json').is_file(), 'QR status was not published')
        return json.loads((self.path / 'status.json').read_text(encoding='utf8'))

    def test_new_create_event_invalidates_old_image_and_publishes_new(self):
        self.observer.handle_response(Response({'data': {'url': 'https://example.test/one-secret'}}))
        first = self.read_state()
        self.observer.handle_response(Response({'data': {'url': 'https://example.test/two-secret'}}))
        second = self.read_state()
        self.assertEqual(first['status'], 'awaiting_scan')
        self.assertEqual(second['status'], 'awaiting_scan')
        self.assertEqual(second['generation'], 2)
        self.assertEqual(second['previous'][0]['status'], 'superseded')
        self.assertNotEqual((self.path/first['image']).read_bytes(), (self.path/second['image']).read_bytes())
        self.assertNotIn('secret', json.dumps(second))
        self.assertEqual(self.updates[-1], second)

    def test_repeated_identical_response_does_not_publish_duplicate(self):
        event = Response({'data': {'url': 'https://example.test/one-secret'}})
        self.observer.handle_response(event)
        self.observer.handle_response(event)
        self.assertEqual(self.read_state()['generation'], 1)
        self.assertEqual(len(self.updates), 1)

    def test_expiry_must_be_explicit_and_disables_current_image(self):
        self.observer.handle_response(Response({'data': {'url': 'https://example.test/one-secret'}}))
        self.observer.mark_expired()
        state = self.read_state()
        self.assertEqual(state['status'], 'expired')
        self.assertIsNone(state['image'])
        self.assertEqual(state['previous'][0]['status'], 'expired')

    def test_invalid_response_disables_old_image_without_secret_in_output(self):
        self.observer.handle_response(Response({'data': {'url': 'https://example.test/one-secret'}}))
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            self.observer.handle_response(Response(RuntimeError('private-SECRET-DETAIL')))
        state = self.read_state()
        self.assertEqual(state['status'], 'unavailable')
        self.assertIsNone(state['image'])
        self.assertNotIn('SECRET', json.dumps(state) + output.getvalue())

    def test_unrelated_responses_cannot_change_display(self):
        response = Response({'data': {'url': 'https://example.test/one-secret'}})
        response.url = 'https://example.test/api/sns/web/v1/login/qrcode/create'
        self.observer.handle_response(response)
        self.assertFalse((self.path/'status.json').exists())
        self.assertEqual(self.updates, [])

    def test_platform_verification_disables_current_image(self):
        self.observer.handle_response(Response({'data': {'url': 'https://example.test/one-secret'}}))
        response = Response({})
        response.status = 461
        self.observer.handle_response(response)
        self.assertEqual(self.read_state()['status'], 'platform_verification_required')
        self.assertIsNone(self.read_state()['image'])

    def test_attach_registers_only_a_response_callback(self):
        class Page:
            def __init__(self): self.handlers = {}
            def on(self, name, handler): self.handlers[name] = handler
        page = Page()
        self.observer.attach(page)
        self.assertEqual(list(page.handlers), ['response'])
        page.handlers['response'](Response({'url': 'https://example.test/one-secret'}))
        self.assertEqual(self.read_state()['status'], 'awaiting_scan')

    def test_notification_failure_is_observable_without_error_text(self):
        def bad_callback(state): raise RuntimeError('private-SECRET-DETAIL')
        self.observer.on_update = bad_callback
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            self.observer.handle_response(Response({'url': 'https://example.test/one-secret'}))
        self.assertTrue(self.observer.notification_failed)
        self.assertNotIn('SECRET', output.getvalue())


if __name__ == '__main__':
    unittest.main()
