import unittest
import pipeline


def record(text='我想租古北一房', title='古北一室一厅出租'):
    return {'customer_id':'internal','customer_uid':'uid','comment_id':'comment1',
            'note_id':'note1','comment_text':text,'parent_text':'','post_title':title,
            'post_text':'','published_at':'2026-10-27T10:00:00+08:00'}


def answer(row, **changes):
    result={'interest':'high','demand_state':'active','region':'match','role':'demand',
            'should_reply':True,'target_comment_id':row['comment_id'],
            'own_evidence':row['comment_text'],'region_source':'title','region_evidence':'古北',
            'reply':'可以看看方隅公寓呀','reason':'模型判断','unknown':[]}
    result.update(changes)
    return result


class UnifiedPolicyTests(unittest.TestCase):
    def test_laughter_on_gubei_post_is_review_not_unrelated(self):
        row=record('哈哈')
        checked=pipeline.validate_result(row,answer(row))
        self.assertFalse(checked['eligible'])
        self.assertTrue(checked['needs_review'])
        self.assertEqual(checked['result']['interest'],'high')
        self.assertIn('strong_intent_evidence_insufficient',checked['review_reasons'])

    def test_vague_squat_on_rental_post_is_review(self):
        row=record('蹲蹲')
        checked=pipeline.validate_result(row,answer(row))
        self.assertFalse(checked['eligible'])
        self.assertTrue(checked['needs_review'])

    def test_super_high_with_viewing_is_eligible(self):
        row=record('我想租古北一房，明天可以约看吗')
        checked=pipeline.validate_result(row,answer(row,interest='super_high'))
        self.assertTrue(checked['eligible'])

    def test_super_high_without_viewing_or_next_step_is_review(self):
        row=record('我想租古北一房')
        checked=pipeline.validate_result(row,answer(row,interest='super_high'))
        self.assertFalse(checked['eligible'])
        self.assertTrue(checked['needs_review'])

    def test_reject_apartment_in_other_own_comment_is_review(self):
        row=record()
        row['other_comments']=[dict(comment_id='comment2',note_id='note2',comment_text='我不考虑公寓',parent_text='',post_title='',post_text='')]
        checked=pipeline.validate_result(row,answer(row))
        self.assertFalse(checked['eligible'])
        self.assertTrue(checked['needs_review'])
        self.assertIn('apartment_rejection',checked['review_reasons'])

    def test_supply_ad_misclassified_as_demand_needs_review(self):
        row=record('我要转租古北一房')
        checked=pipeline.validate_result(row,answer(row))
        self.assertFalse(checked['eligible'])
        self.assertIn('possible_supply_not_demand',checked['review_reasons'])

    def test_customer_says_already_found_home_needs_review(self):
        row=record('我已经租到房了')
        checked=pipeline.validate_result(row,answer(row))
        self.assertFalse(checked['eligible'])
        self.assertIn('possible_demand_ended',checked['review_reasons'])

    def test_direct_renter_is_not_confused_with_denial_of_landlord_role(self):
        row=record('我想租古北一房，不是房东')
        self.assertTrue(pipeline.validate_result(row,answer(row))['eligible'])

    def test_potential_own_comment_price_on_nonrental_gubei_post_needs_review(self):
        row=record('多少钱','古北网红餐厅推荐')
        checked=pipeline.validate_result(row,answer(row))
        self.assertFalse(checked['eligible'])
        self.assertTrue(checked['needs_review'])

    def test_valid_rental_price_on_rental_post_remains_eligible(self):
        row=record('多少钱','古北一室一厅出租')
        self.assertTrue(pipeline.validate_result(row,answer(row))['eligible'])

    def test_old_or_historical_demand_not_eligible(self):
        row=record()
        self.assertFalse(pipeline.validate_result(row,answer(row,demand_state='historical'))['eligible'])

    def test_parent_text_is_never_own_evidence(self):
        row=record('哈哈');row['parent_text']='我想租古北一房'
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(row,answer(row,own_evidence='我想租古北一房'))

    def test_ambiguous_region_does_not_add_area_in_reply(self):
        row=record('我想租一房')
        with self.assertRaises(pipeline.InvalidResult):
            pipeline.validate_result(row,answer(row,region='unknown',region_source='none',region_evidence='',reply='古北方隅公寓看看'))

    def test_default_budget_question_requires_review(self):
        row=record()
        checked=pipeline.validate_result(row,answer(row,reply='方隅公寓可以看看，你预算大概多少呀？'))
        self.assertFalse(checked['eligible'])
        self.assertIn('unprompted_budget_question',checked['review_reasons'])


if __name__=='__main__': unittest.main(verbosity=2)
