"""One bounded batch with dynamic verified identity. Preview is default.

No QR login, automatic account switching, sending, or retry exists here.
Caller uses an already separately authorized and authenticated session.
"""
import argparse
from contextlib import closing
import hashlib
import json
import logging
from pathlib import Path
import re
import sqlite3
import sys
import account_switch as candidate


def historical_ids(roots):
    # A file alone cannot prove registration, even if it says "ready".
    # Kept only for callers which lack a ledger; no IDs are safe to skip.
    return set(),set()


def historical_notes(roots):
    return historical_ids(roots)[0]


def history_index(roots, *, ledger):
    """Index historical evidence without treating observations as registration.

    A note is skippable only with explicit exhausted-page evidence, a final
    collection, and ledger proof for every observed comment on that note.
    All other observations stay discoverable in a local recovery index.
    """
    uri=Path(ledger).resolve(strict=True).as_uri()+'?mode=ro'
    with closing(sqlite3.connect(uri,uri=True)) as db:
        registered={row[0] for row in db.execute(
            "SELECT comment FROM leads WHERE platform='xiaohongshu'") if row[0]}
    folders={}
    names={'collection.json','partial.json','attempted-notes.json','ai-input.json',
           'completed-notes.json','attempt-events.jsonl'}
    for root in roots:
        root=Path(root)
        if not root.is_dir(): continue
        for path in root.rglob('*'):
            if path.is_file() and (path.name in names or
                    (path.name.startswith('partial-') and path.suffix=='.json')):
                folders.setdefault(path.parent.resolve(),set()).add(path.resolve())

    observations=set(); complete=set(); incomplete=set(); recovery=[]; all_seen_notes=set()
    note_sources={}; note_unregistered={}; pending_global=set(); proofs=[]
    def ids(value):
        notes=set(); comments=set(); links={}
        def visit(item, inherited=None):
            if isinstance(item,dict):
                note=item.get('note_id')
                note=note if isinstance(note,str) and note else inherited
                if note: notes.add(note)
                comment=item.get('comment_id')
                if isinstance(comment,str) and comment:
                    comments.add(comment)
                    if note: links.setdefault(note,set()).add(comment)
                for v in item.values(): visit(v,note)
            elif isinstance(item,list):
                for v in item: visit(v,inherited)
        visit(value)
        return notes,comments,links
    for folder,paths in sorted(folders.items(),key=lambda x:str(x[0])):
        all_notes=set(); all_comments=set(); note_comments={}; pending=set(); proof=set()
        final=False; files=[]
        for path in sorted(paths):
            raw=path.read_bytes()
            if path.name=='attempt-events.jsonl':
                value=[json.loads(line) for line in raw.decode('utf8').splitlines() if line]
            else:
                value=json.loads(raw.decode('utf-8-sig'))
            if path.name=='completed-notes.json':
                if not isinstance(value,dict) or not isinstance(value.get('exhausted_note_ids'),list):
                    raise candidate.Refused('history_completion_proof_invalid')
                proof={x for x in value['exhausted_note_ids'] if isinstance(x,str) and x}
                covered=value.get('covered_sources',{})
                if not isinstance(covered,dict):
                    raise candidate.Refused('history_completion_proof_invalid')
                continue
            if path.name=='collection.json':
                final=True
                if isinstance(value,dict):
                    p,_,_=ids([value.get('pending',[]),value.get('conflicts',[])])
                    pending.update(p)
            ns,cs,links=ids(value)
            all_notes.update(ns); all_comments.update(cs)
            for note in ns:
                note_sources.setdefault(note,{})[str(path)]=hashlib.sha256(raw).hexdigest()
            for note,comments in links.items(): note_comments.setdefault(note,set()).update(comments)
            files.append(str(path))
        unregistered=all_comments-registered
        all_seen_notes.update(all_notes|proof)
        observations.update(all_comments)
        pending_global.update(pending)
        for note,comments in note_comments.items():
            note_unregistered.setdefault(note,set()).update(comments-registered)
        safe={note for note in proof if final and note not in pending and
              not (note_comments.get(note,set())-registered)}
        # An unassociated unregistered comment means the proof cannot be
        # related to a note safely; do not suppress any note in this folder.
        linked=set().union(*note_comments.values()) if note_comments else set()
        if unregistered-linked: safe.clear()
        if unregistered-linked:
            for note in all_notes: note_unregistered.setdefault(note,set()).update(unregistered-linked)
        for note in safe:
            proof_coverage=covered.get(note,{})
            if not isinstance(proof_coverage,dict):
                raise candidate.Refused('history_completion_proof_invalid')
            proofs.append((folder,note,proof_coverage))
        incomplete.update((all_notes|proof)-safe)
        if unregistered or ((all_notes|proof)-safe):
            recovery.append({'kind':'final_collection_requires_local_registration_review' if final
                             else 'incomplete_collection_requires_local_review',
                             'source_files':files,'unregistered_comments':sorted(unregistered),
                             'incomplete_notes':sorted((all_notes|proof)-safe)})
    # A later proof may cover exact prior source snapshots. A newly created or
    # modified history file is not covered, regardless of timestamps.
    for folder,note,covered in proofs:
        required={path:digest for path,digest in note_sources.get(note,{}).items()
                  if Path(path).parent != folder}
        if (not note_unregistered.get(note) and note not in pending_global and
                all(covered.get(path)==digest for path,digest in required.items())):
            complete.add(note)
    incomplete=all_seen_notes-complete
    return {'completed_notes':sorted(complete),'incomplete_notes':sorted(incomplete),
            'known_comments':sorted(observations & registered),
            'unregistered_comments':sorted(observations-registered),'recovery':recovery,
            'note_sources':note_sources}


def load_cookies(home):
    # No HOME/USERPROFILE mutation, browser fallback, token refresh or login.
    home=Path(home).resolve(strict=True)
    allowed=(candidate.PROJECT/'work/xhs-standalone-session').resolve(strict=True)
    if home==allowed or not home.is_relative_to(allowed) or not home.is_dir():
        raise candidate.Refused('independent_session_required')
    path=(home/'.xiaohongshu-cli/cookies.json').resolve(strict=True)
    if not path.is_relative_to(home):
        raise candidate.Refused('session_path_escape')
    value=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(value,dict) or not all(isinstance(value.get(k),str) and value[k] for k in ('a1','web_session')):
        raise candidate.Refused('independent_session_incomplete')
    return {k:v for k,v in value.items() if isinstance(v,str)}


def configure_runtime_cache(cache):
    # Installed mixins import get_config_dir by value, so both namespaces must
    # be scoped. Keep xsec tokens and search-session IDs in memory only.
    import xhs_cli.cookies as storage
    import xhs_cli.client_mixins as mixins
    cache.mkdir(exist_ok=False)
    storage.get_config_dir=lambda: cache
    mixins.get_config_dir=lambda: cache
    mixins.cache_note_context=lambda *args,**kwargs: None
    mixins.get_cached_note_context=lambda *args,**kwargs: {}
    mixins.invalidate_note_context=lambda *args,**kwargs: None
    mixins._save_search_session_cache=lambda *args,**kwargs: None


def create_client(home, cache):
    logging.disable(logging.CRITICAL)
    cookies=load_cookies(home)
    collector,_=candidate.dependencies()
    configure_runtime_cache(cache)
    # Hash stays in memory. It detects a normal re-login replacing the selected
    # file and never appears in the batch audit or exception text.
    session=(Path(home).resolve(strict=True)/'.xiaohongshu-cli/cookies.json').resolve(strict=True)
    raw=session.read_bytes()
    latest=json.loads(raw.decode('utf-8-sig'))
    if not isinstance(latest,dict) or {k:v for k,v in latest.items() if isinstance(v,str)}!=cookies:
        raise candidate.Refused('independent_session_file_changed')
    digest=hashlib.sha256(raw).digest()
    client=collector.ReadClient(cookies)
    def unchanged_file():
        try:
            unchanged=session.is_file() and hashlib.sha256(session.read_bytes()).digest()==digest
        except OSError:
            unchanged=False
        if not unchanged: raise candidate.Refused('independent_session_file_changed')
    client._independent_session_guard=unchanged_file
    install_response_audit(client)
    return client


def install_response_audit(client):
    # HTTP failures occur before upstream response parsing, so capture only
    # the fixed status/endpoint metadata here; never store body or headers.
    def observe_response(response):
        if response.status_code!=200:
            client.last_failure_detail={'http_status':response.status_code,'error_type':'HTTPError',
                'stage':client._last_stage,'endpoint':client._last_endpoint_kind,'request_started':True}
    client._http.event_hooks['response'].append(observe_response)


def main(argv=None, *, client_factory=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace',required=True)
    parser.add_argument('--batch',required=True)
    parser.add_argument('--keyword',required=True)
    parser.add_argument('--search-page',type=int,required=True)
    parser.add_argument('--session-home')
    parser.add_argument('--ledger')
    parser.add_argument('--source-db')
    parser.add_argument('--task',default='独立账号关键词采集')
    parser.add_argument('--operator')
    parser.add_argument('--max-notes',type=int,default=10)
    parser.add_argument('--max-pages',type=int,default=2)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--apply-to-shared-ledger',action='store_true')
    args=parser.parse_args(argv)
    if not args.execute:
        print(json.dumps({'mode':'preview','batch':args.batch,'search_page':args.search_page,
            'network':False,'login':False,'send':False,'ledger_write':False},ensure_ascii=False))
        return 0
    if not all((args.session_home,args.ledger,args.source_db)):
        raise candidate.Refused('explicit_session_source_ledger_required')
    workspace=Path(args.workspace).resolve(strict=True)
    if not workspace.is_relative_to((candidate.HERE/'runtime').resolve(strict=True)) or workspace==candidate.HERE/'runtime':
        raise candidate.Refused('dedicated_candidate_workspace_required')
    if (workspace/'STOP').exists():
        raise candidate.Refused('user_pause_marker_present')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',args.batch):
        raise candidate.Refused('new_safe_batch_name_required')
    if (workspace/args.batch).exists():
        raise candidate.Refused('existing_batch_no_retry')
    ledger=Path(args.ledger).resolve(strict=True)
    if not ledger.is_relative_to(workspace) and not (args.apply_to_shared_ledger and ledger==candidate.REAL_LEDGER.resolve()):
        raise candidate.Refused('shared_ledger_opt_in_required')
    if type(args.search_page) is not int or not 1<=args.search_page<=100 or any(not 1<=n<=20 for n in (args.max_notes,args.max_pages)):
        raise candidate.Refused('bounded_range_required')
    areas=('xhs-continuous-runner/work','xhs-parallel-pipeline/work','xhs-browser-context-recovery',
        'xhs-collection-candidate/work','xhs-context-controlled/work','xhs-standalone-session/collection-live',
        'xhs-account-switch-candidate/runtime','xhs-account-switch-recovery-candidate/runtime')
    history=history_index([candidate.PROJECT/'work'/area for area in areas],ledger=ledger)
    # New-file-only durable evidence; a later failure never erases recovery work.
    candidate.write_new(workspace/('history-index-'+args.batch+'.json'),history)
    notes,comments=history['completed_notes'],history['known_comments']
    factory=client_factory or create_client
    client=factory(args.session_home,workspace/('cache-'+args.batch))
    try:
        result=candidate.run_batch(workspace=workspace,batch_name=args.batch,client=client,
            ledger=args.ledger,source_db=args.source_db,keyword=args.keyword,search_page=args.search_page,
            task=args.task,operator=args.operator,known_notes=notes,max_notes=args.max_notes,max_pages=args.max_pages,
            allow_real_ledger=args.apply_to_shared_ledger,known_comments=comments,
            history_snapshot=history)
        print(json.dumps({'status':'registered','account':result['account'],'result':result['result']},ensure_ascii=False))
    finally:
        client.close()
    return 0


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception:
        # Fixed category: upstream exceptions can contain response/session data.
        print(json.dumps({'status':'stopped','automatic_retry':False,'action':'inspect_batch_audit_and_ledger'},ensure_ascii=False),file=sys.stderr)
        raise SystemExit(2) from None
