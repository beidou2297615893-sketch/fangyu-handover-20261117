from pathlib import Path
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/reply-sender-choice-20261020');p=T/'test_sender.mjs';s=p.read_text('utf-8');s=s.replace("accounts:[{id:'account-a',name:'一号'},{id:'account-b',name:'二号'}]", "accounts:mode==='only-a'?[{id:'account-a',name:'一号'}]:[{id:'account-a',name:'一号'},{id:'account-b',name:'二号'}]")
s+=r'''
const unavailable=fixture();unavailable.setMode('only-a');unavailable.handlers.account({target:{value:'account-b'}});await unavailable.handlers.prepare();assert.equal(unavailable.modals.length,0);assert.equal(unavailable.drafts.size,0);assert.match(unavailable.v.batchError,/没有可用/);assert.ok(!unavailable.calls.includes('review'),'unavailable account B must not fall back to account A');
console.log('PASS: unavailable uniform sender never falls back to another account');
''';p.write_text(s,encoding='utf-8')
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-native-r57')
for n in ['reply_delivery.py','reply_workbench.py']:compile((S/n).read_text('utf-8'),n,'exec')
print('Python syntax PASS')
