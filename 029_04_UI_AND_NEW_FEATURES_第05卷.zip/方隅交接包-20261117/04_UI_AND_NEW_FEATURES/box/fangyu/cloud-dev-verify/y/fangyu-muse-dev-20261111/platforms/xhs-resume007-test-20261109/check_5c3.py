﻿import sqlite3, re
from pathlib import Path
L = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3')
db = sqlite3.connect(L.resolve().as_uri() + '?mode=ro', uri=True)
agg = {}
for s, c in db.execute("select source, count(*) from leads where platform='xiaohongshu' and source like '%live-tasks%' group by source"):
    m = re.search(r'live-tasks[\\/]([^\\/]+)[\\/](batch-\d+)', s or '')
    k = (m.group(1), m.group(2)) if m else ('?', '?')
    agg[k] = agg.get(k, 0) + c
tasks = {}
for (t, b), c in agg.items(): tasks.setdefault(t, []).append((b, c))
for t, v in tasks.items(): print(t, 'batches=', len(v), 'rows=', sum(c for _, c in v), 'max_batch=', max(b for b, _ in v))
b23 = {}
for s, c in db.execute("select source, count(*) from leads where source like '%batch-0023%' group by source"):
    k = re.sub(r'^.*?work[\\/]', 'work/', s or '')
    b23[k] = b23.get(k, 0) + c
print('batch-0023 sources:', b23)
db.close()
