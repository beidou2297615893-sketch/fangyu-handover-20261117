import unittest

from subcomments_compat import read_subcomments


class FakeClient:
    def __init__(self, result=None, error=None):
        self.calls = []
        self.result = result
        self.error = error

    def _main_api_get(self, endpoint, params):
        self.calls.append((endpoint, params))
        if self.error:
            raise self.error
        return self.result


class SubcommentsCompatibilityTests(unittest.TestCase):
    def test_supplies_original_note_context_and_exact_cursor_once(self):
        result = {"comments": [], "has_more": False}
        client = FakeClient(result=result)
        self.assertIs(read_subcomments(client, "note", "root", "token", cursor="next"), result)
        self.assertEqual(client.calls, [("/api/sns/web/v2/comment/sub/page", {
            "note_id": "note", "root_comment_id": "root", "num": 30,
            "cursor": "next", "image_formats": "jpg,webp,avif",
            "top_comment_id": "", "xsec_token": "token",
        })])

    def test_missing_note_context_is_rejected_without_request(self):
        client = FakeClient()
        with self.assertRaises(ValueError):
            read_subcomments(client, "note", "root", "")
        self.assertEqual(client.calls, [])

    def test_platform_verification_is_propagated_without_retry(self):
        error = RuntimeError("verification required")
        client = FakeClient(error=error)
        with self.assertRaisesRegex(RuntimeError, "verification required"):
            read_subcomments(client, "note", "root", "token")
        self.assertEqual(len(client.calls), 1)


if __name__ == "__main__":
    unittest.main()
