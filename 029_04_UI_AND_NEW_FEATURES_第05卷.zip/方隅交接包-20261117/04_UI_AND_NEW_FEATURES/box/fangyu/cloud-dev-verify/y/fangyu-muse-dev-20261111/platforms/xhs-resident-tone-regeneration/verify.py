import json,hashlib,collections
from pathlib import Path
P=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text('utf8'))
rows=[r for p in sorted((P/'batches').glob('*/validated.json')) for r in load(p)]
errors=[];seen=set()
for r in rows:
 cid=r['comment_id'];a=r['source_analysis'];s=r['source_record'];t=r['draft']
 if cid!=s['comment_id'] or cid!=a['result']['target_comment_id'] or r['customer_uid']!=s['customer_uid']:errors.append([cid,'identity'])
 if a['result']['own_evidence'] not in s['comment_text']:errors.append([cid,'evidence'])
 if r['customer_uid'] in seen:errors.append([cid,'duplicate_uid'])
 seen.add(r['customer_uid'])
 if len(t)>65 or any(w in t for w in ('以门店为准','需要确认','我帮你问','古北','保证','微信','手机号')):errors.append([cid,'voice_or_claim'])
 if '�' in t:errors.append([cid,'encoding'])
result={'verified_rows':len(rows),'nonempty':sum(bool(r['draft']) for r in rows),'held':sum(not r['draft'] for r in rows),'errors':errors,'exact_identity_and_own_evidence_checked':True,'platform_requests':0,'ledger_modified':False,'draft_text_sha256':hashlib.sha256(json.dumps([{k:r[k] for k in ('comment_id','customer_uid','draft')} for r in rows],ensure_ascii=False).encode()).hexdigest(),'repeated_nonempty_text':dict(collections.Counter(r['draft'] for r in rows if r['draft']))}
(P/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='repeated_nonempty_text'},ensure_ascii=False))
