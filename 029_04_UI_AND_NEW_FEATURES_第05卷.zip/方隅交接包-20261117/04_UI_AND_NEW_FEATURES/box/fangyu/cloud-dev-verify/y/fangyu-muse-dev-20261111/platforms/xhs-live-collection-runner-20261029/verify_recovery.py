"""Run unchanged dependency regression with its documented import setup."""
import importlib.util
import os
from pathlib import Path
import socket
import sys
import unittest

PROJECT=Path(__file__).resolve().parents[2]
RECOVERY=PROJECT/'work/xhs-account-switch-recovery-candidate'
sys.path.insert(0,str(RECOVERY))
import account_switch
account_switch.dependencies()
sys.path.insert(0,str(PROJECT/'work/xhs-ai-standalone'))
os.environ['PYTHONPATH']=str(PROJECT/'work/xhs-collection-candidate')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
suite=unittest.TestSuite()
for name in ('test_collection','test_register'):
    path=RECOVERY/('regression_'+name+'.py')
    if path.read_bytes()!=(PROJECT/'work/xhs-collection-candidate'/(name+'.py')).read_bytes():
        raise RuntimeError('Regression copy mismatch')
    spec=importlib.util.spec_from_file_location('regression_'+name,path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
suite.addTests(unittest.defaultTestLoader.discover(str(RECOVERY),pattern='test_account_switch.py'))
def deny(*args,**kwargs): raise AssertionError('Offline verification forbids network')
socket.socket.connect=deny
result=unittest.TextTestRunner(verbosity=1).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
