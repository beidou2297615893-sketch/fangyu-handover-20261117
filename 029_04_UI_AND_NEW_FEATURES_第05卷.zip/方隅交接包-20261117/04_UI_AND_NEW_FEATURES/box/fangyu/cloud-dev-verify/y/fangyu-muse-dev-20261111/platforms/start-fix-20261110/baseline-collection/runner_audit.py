"""Read-only production backup, standalone cache audit, and explicit legacy policy snapshot."""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import json
import sqlite3
import tempfile
from pathlib import Path
from runner_ledger_adapter import Cache, connect_ro, encoded, fingerprint

ROOT = Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--database',type=Path,default=ROOT/'runtime/collection.sqlite3')
    parser.add_argument('--plan',type=Path,default=ROOT/'15-store-plan-strict.json')
    args=parser.parse_args()
    plan=json.loads(args.plan.read_text('utf-8-sig'))
    directory=Path(tempfile.mkdtemp(prefix='runner-audit-',dir=ROOT))
    copy=directory/'collection-copy.sqlite3'
    with connect_ro(args.database) as source:
        destination=sqlite3.connect(copy)
        source.backup(destination)
        destination.close()
    before=hashlib.sha256(copy.read_bytes()).hexdigest()
    with connect_ro(copy) as source:
        attempts=list(source.execute('SELECT * FROM attempts ORDER BY rowid'))
        specs={row['request_id']:json.loads(row['spec']) for row in attempts}
        allowed=[request for request,spec in specs.items() if spec['kind']=='comments' and spec.get('source_file') and spec.get('eligibility')!='excluded_irrelevant' and spec['account_uid']==plan['account_uid']]
        policy=dict(account_uid=plan['account_uid'],qualified_request_ids=allowed,rule_source='主任务2026-10-29明确确认：除误选外的现有评论页及新增龙柏租房页，人工已选租房相关视频来源；不代表意向或门店确认',source_attempt_count=len(attempts))
        policy_path=directory/'runner-qualification-policy.json'
        policy_path.write_text(json.dumps(policy,ensure_ascii=False,indent=2),encoding='utf8')
        plan['qualification_policy']=policy
        terms={}
        for store in plan['stores']:
            for term in store['keywords']:
                terms.setdefault(term,dict(keyword=term,store_id=store['store_id']))
        plan['search_tasks']=list(terms.values())
        streams=list(source.execute('SELECT * FROM scan_streams WHERE scan_id=? AND account_uid=? AND kind="comments"',(plan['scan_id'],plan['account_uid'])))
    cache=Cache(copy)
    cache.sync()
    snapshot=cache.snapshot(plan)
    digest_pages=0
    for row in attempts:
        if row['state']!='parsed':continue
        spec=specs[row['request_id']]
        digest=fingerprint(spec['kind'],json.loads(row['response']).get('value',{}))
        if digest:
            assert cache.seen(dict(spec,page_items_digest=digest))
            digest_pages+=1
    # Each existing canonical comment scope is respected, even when its first search source differs.
    scope_issues=0
    for stream in streams:
        row=cache.db.execute('SELECT scope_store,scope_keyword FROM admissions WHERE scan=? AND account=? AND video=?',(stream['scan_id'],stream['account_uid'],stream['target'])).fetchone()
        if row and (row['scope_store'],row['scope_keyword'])!=(stream['store_id'],stream['keyword']):scope_issues+=1
    assert scope_issues==0
    with connect_ro(copy) as source:
        mapped=sum(row[0] not in {s['store_id'] for s in plan['stores']} for row in source.execute('SELECT DISTINCT store_id FROM scan_streams WHERE scan_id=? AND account_uid=?',(plan['scan_id'],plan['account_uid'])))
    assert mapped==0
    cache.db.close()
    assert before==hashlib.sha256(copy.read_bytes()).hexdigest()
    again=Cache(copy);again.sync();warm=again.snapshot(plan);again.db.close()
    report=dict(scope='offline_readonly_snapshot_only',source_attempts=len(attempts),historical_fingerprints_verified=digest_pages,legacy_qualified_requests=len(allowed),comment_streams=len(streams),comment_cursors=sorted(r['cursor'] for r in streams),comment_exhausted=sum(r['exhausted'] for r in streams),scope_conflicts=scope_issues,unmapped_stores=mapped,summary=snapshot['summary'],review_counts=snapshot['review_counts'],cache_first=snapshot['cache_stats'],cache_warm=warm['cache_stats'],copied_source_sha256_unchanged=True,production_written=False,platform_called=False,qualification_policy_path=str(policy_path))
    (directory/'runner-audit-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(encoded(report))


if __name__=='__main__':main()
