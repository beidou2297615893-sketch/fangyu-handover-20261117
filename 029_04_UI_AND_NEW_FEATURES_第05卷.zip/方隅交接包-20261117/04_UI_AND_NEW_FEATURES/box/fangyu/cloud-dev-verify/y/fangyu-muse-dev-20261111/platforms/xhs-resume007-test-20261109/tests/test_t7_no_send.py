"""测试 send_authorized 恒为 False，无发送能力。"""
import json
import os
import sys
import unittest
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SRC_DIR))

import resume007
from tests.fixture_builder import build_valid_fixture, create_ledger
from tests.fakes import FakeLive, FakeOnce, FakeScheduling, FakeClientFactory


class TestNoSend(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        self.resume006_root = self.project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
        self.resume006_root.mkdir(parents=True)
        self.ledger_dir = self.project / 'work/shared-acquisition-ledger'
        self.ledger_dir.mkdir(parents=True)
        self.ledger = self.ledger_dir / 'shared.sqlite3'
        create_ledger(self.ledger)
        self.stop_today = self.project / 'work/xhs-resume-20261103/stop-today-resume007.json'
        self.stop_today.parent.mkdir(parents=True)
        self.session_home = Path(self.tmp.name) / 'session-home'
        self.session_home.mkdir()
        self.here_dir = Path(self.tmp.name) / 'here'
        self.here_dir.mkdir()

        self.env = {
            'XHS_RESUME007_RESUME006_ROOT': str(self.resume006_root),
            'XHS_RESUME007_LEDGER': str(self.ledger),
            'XHS_RESUME007_STOP_TODAY': str(self.stop_today),
            'XHS_RESUME007_HERE': str(self.here_dir),
            'XHS_RESUME007_PROJECT': str(self.project),
        }
        for k, v in self.env.items():
            os.environ[k] = v

        self.live = FakeLive()
        self.once = FakeOnce()
        self.scheduling = FakeScheduling()
        self.client_factory = FakeClientFactory('test-uid', delay=6.0)
        resume007._LOAD = lambda: (self.live, None, self.once, self.scheduling)
        resume007._CLIENT_FACTORY = self.client_factory

        self.uid = '123456789012345678901234'
        build_valid_fixture(self.resume006_root, self.session_home, self.uid, self.here_dir)

    def tearDown(self):
        for k in self.env:
            os.environ.pop(k, None)
        resume007._LOAD = None
        resume007._CLIENT_FACTORY = None
        self.tmp.cleanup()

    def _run_main(self, args_list):
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            old_argv = sys.argv
            sys.argv = ['resume007.py'] + args_list
            try:
                code = resume007.main()
            finally:
                sys.argv = old_argv
        return code, f.getvalue().strip()

    def test_preview_has_no_network_and_no_send(self):
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertEqual(code, 0)
        data = json.loads(out)
        self.assertFalse(data['network'])
        # 预览不应创建任何文件（除了可能的 reconciliation 文件，但我们不写）
        # 检查 resume006 ROOT 下没有新文件
        before_files = set(p.name for p in self.resume006_root.rglob('*') if p.is_file())
        # 已经检查过，预览不创建新 ROOT

    def test_execute_task_config_send_authorized_false(self):
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home), '--execute'])
        # 执行可能成功或失败，但 task-config 应包含 send_authorized=False
        new_roots = [p for p in self.resume006_root.parent.iterdir() if p.name.startswith('stores15-resume007-')]
        if new_roots:
            new_root = new_roots[0]
            config_path = new_root / 'task-config.json'
            if config_path.exists():
                config = json.loads(config_path.read_text(encoding='utf-8'))
                self.assertFalse(config.get('send_authorized', True))


if __name__ == '__main__':
    unittest.main()
