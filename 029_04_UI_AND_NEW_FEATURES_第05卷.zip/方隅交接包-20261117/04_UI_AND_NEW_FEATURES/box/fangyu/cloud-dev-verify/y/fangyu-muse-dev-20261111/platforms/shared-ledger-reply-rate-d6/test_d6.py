import hashlib,json,sqlite3,tempfile,time,unittest
from contextlib import closing
from datetime import datetime,timezone
from pathlib import Path
from unittest.mock import patch
import pool_counts,pacing_audit,reply_rate,pool_report,receipt_alignment,round_reconstruct

class D6Tests(unittest.TestCase):
 def test_customer_states_are_disjoint_and_unknown_never_available(self):
  got=pool_counts.count_pool(['a','b','c','d','e','f','a'],[('a','sent'),('b','unknown'),('c','reserved'),('d','not_sent'),('e','sent'),('e','unknown')])
  self.assertEqual(got,{'valid':1,'sent':1,'unknown':2,'reserved':1,'failed':1,'pending':1})
 def test_observation_only_for_sent_and_positive_survives_later_unknown(self):
  with tempfile.TemporaryDirectory() as td:
   ledger=Path(td)/'source.sqlite3'; side=Path(td)/'side.sqlite3'
   with closing(sqlite3.connect(ledger)) as c,c:
    c.execute('create table reservations(token,platform,status,comment,customer)')
    c.executemany('insert into reservations values(?,?,?,?,?)',[('a','douyin','sent','1','u'),('b','douyin','unknown','2','v'),('c','douyin','sent','3','w')])
   with self.assertRaises(ValueError):reply_rate.record('b',{'state':'unknown','reason':'x','pages':1},ledger,side)
   with self.assertRaises(ValueError):reply_rate.record('a',{'state':'replied','reason':'x','followup_id':'5','pages':1},ledger,side)
   reply_rate.record('a',{'state':'replied','reason':'exact_identity_and_target','followup_id':'5','pages':1},ledger,side)
   reply_rate.record('a',{'state':'unknown','reason':'read_error','pages':0},ledger,side)
   self.assertEqual(reply_rate.report(ledger,side),{'confirmed_sent_customers':2,'confirmed_customer_followups':1,'checked_customers':1,'unknown_customers':1,'confirmed_minimum_percent':50.0})
 def test_pacing_ignores_unknown_and_requires_confirmed_times(self):
  t=datetime(2026,11,10,tzinfo=timezone.utc)
  rows=[{'status':'sent','time':t,'video':'v','text':'x','round_id':'r','platform':'douyin'} for _ in range(16)]+[{'status':'unknown'},{'status':'sent'}]
  got=pacing_audit.audit(rows,t,video_run_limit=3)
  self.assertEqual(got['observed_sent'],16);self.assertEqual(got['phrases_over_limit'],1)
  self.assertTrue(got['same_video_exceeded']);self.assertEqual(got['coverage'],'partial')
  self.assertEqual(got['round_video_over_five'],1);self.assertEqual(got['repeated_video_phrase_groups'],1)
 def test_daily_phrase_uses_both_platforms_and_beijing_midnight(self):
  t=datetime.fromisoformat('2026-11-09T16:05:00+00:00')
  rows=[{'status':'sent','time':t,'video':'v','text':'一样。','platform':'douyin'}]*8+\
       [{'status':'sent','time':t,'video':'w','text':'一样。','platform':'xiaohongshu'}]*8+\
       [{'status':'sent','time':t,'video':'z','text':'一样!','platform':'douyin'}]
  got=pacing_audit.audit(rows,t)
  self.assertEqual(got['phrases_over_limit_details'],[{'text':'一样。','count':16}])
  self.assertIsNone(got['same_video_exceeded'])

 def test_missing_receipt_identity_never_starts_adapter(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td); task=root/'work'/'douyin-test';task.mkdir(parents=True)
   ledger=root/'ledger.sqlite3';token='test-token';cid='123'
   with closing(sqlite3.connect(ledger)) as db,db:
    db.execute('create table reservations(token,platform,status,comment,customer,evidence)')
    db.execute('insert into reservations values(?,?,?,?,?,?)',(token,'douyin','sent',cid,'456',json.dumps({'receipt':{'status_code':0,'cid':'789','reply_id':cid,'text':'approved'}})))
   (task/(cid+'.json')).write_text(json.dumps({'attempt_id':token,'customer_uid':'456','account_uid':'account','video_id':'10','reply':{'draft_text':'approved'}}),encoding='utf-8')
   with patch.object(reply_rate,'ROOT',root),patch.object(reply_rate,'LEDGER',ledger),patch.object(reply_rate.subprocess,'run') as run:
    with self.assertRaisesRegex(ValueError,'账号、回复目标或正文'):reply_rate.check(token,task)
    run.assert_not_called()

 def test_readonly_pool_report_excludes_sent_and_unknown(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);work=root/'work';control=work/'douyin-local-control';task=work/'douyin-test';control.mkdir(parents=True);task.mkdir()
   source=work/'class.jsonl'
   rows=[{'comment_id':cid,'customer_uid':uid,'published_at_unix':time.time(),'commercial_fit':{'lead_intent':intent,'eligible_candidate':True}}
         for cid,uid,intent in [('1','11','high'),('2','22','medium'),('3','33','medium'),('4','44','low')]]
   source.write_text(''.join(json.dumps(x)+'\n' for x in rows),encoding='utf-8')
   handoff=work/'fangyu-douyin-independent/classification-handoff-status.json';handoff.parent.mkdir()
   handoff.write_text(json.dumps({'commercial_fit':{'all_pool_file':str(source),'all_pool_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}}),encoding='utf-8')
   (control/'active.json').write_text(json.dumps({'task':str(task)}),encoding='utf-8')
   items=[{'cid':str(i),'uid':str(i)*2,'video':'99'} for i in range(1,5)]
   payload=json.dumps(items,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
   (task/'approved-cli-queue.json').write_text(json.dumps({'items':items,'items_sha256':hashlib.sha256(payload).hexdigest()}),encoding='utf-8')
   ledger=work/'ledger.sqlite3'
   with closing(sqlite3.connect(ledger)) as db,db:
    db.execute('create table reservations(platform,customer,status)');db.execute('create table leads(platform,customer,status)')
    db.executemany('insert into reservations values(?,?,?)',[('douyin','11','sent'),('douyin','22','unknown')])
   legacy=root/'Codex获客工作台/work/reply_receipts.sqlite3';legacy.parent.mkdir(parents=True)
   with closing(sqlite3.connect(legacy)) as db,db:db.execute('create table sends(uid,status)')
   with patch.object(pool_report,'ROOT',root),patch.object(pool_report,'CONTROL',control),patch.object(pool_report,'LEDGER',ledger):
    got=pool_report.report()
   self.assertEqual((got['valid'],got['sent'],got['unknown'],got['pending']),(1,1,1,1))

 def test_receipt_alignment_requires_real_matching_fields(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);task=root/'work/douyin-test';task.mkdir(parents=True);ledger=root/'ledger.sqlite3'
   attempt={'attempt_id':'douyin-test-abc','customer_uid':'7','account_uid':'account','video_id':'99','reply':{'draft_text':'文案'}}
   (task/'12.json').write_text(json.dumps(attempt),encoding='utf-8')
   receipt={'status_code':0,'cid':'88','sec_uid':'account','reply_id':'12','text':'文案'}
   with closing(sqlite3.connect(ledger)) as db,db:
    db.execute('create table reservations(token,comment,customer,evidence,platform,status)')
    db.execute('insert into reservations values(?,?,?,?,?,?)',('douyin-test-abc','12','7',json.dumps({'receipt':receipt}),'douyin','sent'))
    db.execute('insert into reservations values(?,?,?,?,?,?)',('missing-abc','15','8','{}','douyin','sent'))
   with patch.object(receipt_alignment,'ROOT',root),patch.object(receipt_alignment,'LEDGER',ledger):got=receipt_alignment.inspect()
   self.assertEqual(got['aligned_for_future_check'],1);self.assertEqual(got['missing_unique_task'],1)

 def test_closed_round_reconstruction_requires_full_sequence_alignment(self):
  lines=['持续处理已批准队列','选取原评论日期：2026-11-10 ｜ 近7天','SUCCESS x','已停止：暂停',
         '持续处理已批准队列','选取原评论日期：2026-11-09 ｜ 近7天','SUCCESS x']
  events=[{'original_time':'2026-11-10','cid':'1'},{'original_time':'2026-11-09','cid':'2'}]
  mapping,meta=round_reconstruct.parse_rounds('t',lines,events)
  self.assertEqual(mapping,{'1':'t:1'});self.assertEqual(meta['unclosed_rounds'],1)
  mapping,meta=round_reconstruct.parse_rounds('t',lines,list(reversed(events)))
  self.assertEqual(mapping,{});self.assertFalse(meta['aligned'])
  mapping,meta=round_reconstruct.parse_rounds('t',lines,[{'original_time':'old','cid':'0'}]+events)
  self.assertEqual(mapping,{'1':'t:1'});self.assertEqual(meta['ignored_evidence_prefix'],1)

if __name__=='__main__':unittest.main()
