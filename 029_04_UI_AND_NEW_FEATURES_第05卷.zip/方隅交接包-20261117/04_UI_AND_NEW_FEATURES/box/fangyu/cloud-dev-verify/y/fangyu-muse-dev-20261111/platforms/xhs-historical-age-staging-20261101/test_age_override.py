"""Offline candidate-only age-gate tests; no live sender files are edited."""
import ast
from dataclasses import asdict
from datetime import datetime,timezone
import importlib.util
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

STAGE=Path(__file__).resolve().parent
LIVE=STAGE.parent/'xhs-send-current-20261029'
sys.path.insert(0,str(LIVE))
import test_target_isolation as fixtures

spec=importlib.util.spec_from_file_location('staged_age_policy',STAGE/'candidate/target_isolation.py')
candidate=importlib.util.module_from_spec(spec);sys.modules[spec.name]=candidate;spec.loader.exec_module(candidate)
tree=ast.parse((STAGE/'candidate/bulk_run.py').read_text(encoding='utf8'))
function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='mapping_reason')
namespace={'datetime':datetime,'timezone':timezone,'CLOSED_WORDS':('已出租','已租出','已成交'),
           'AuthorizedTargetIsolationPolicy':candidate.AuthorizedTargetIsolationPolicy}
exec(compile(ast.Module(body=[function],type_ignores=[]),'candidate/bulk_run.py','exec'),namespace)
mapping_reason=namespace['mapping_reason']


class Tests(unittest.TestCase):
    def setUp(self):
        self.fixture=fixtures.Tests('test_business_unknown_is_durably_verified_then_next_customer_posts_and_cookie_digest_matches')
        # Existing synthetic fixture writes are redirected into this staging root.
        with patch('test_bulk_run.__file__',str(STAGE/'offline_fixture.py')):self.fixture.setUp()
        f=self.fixture;self.row=dict(f.fixture.rows[0]);self.meta={
            'customer_uid':self.row['customer_uid'],'canonical_customer':self.row['customer_id'],
            'original_comment':'synthetic original question','post_title':'available apartment',
            'published_at':'2026-07-28T00:00:00+00:00'}
        self.history_path=f.b.root/'historical.jsonl'
        self.history={**self.row,'original_comment':self.meta['original_comment'],'post_title':self.meta['post_title'],
            'published_at':self.meta['published_at'],'current_need_confirmed':False,'actual_housing_facts_verified':False,
            'hold_reasons':[],'factual_scope':'offer_to_check_not_assertion_of_inventory_price_location_or_appointment',
            'review_notes_not_cleared':True,'historical_comment_days_old':95.87}
        self.history_path.write_text(json.dumps(self.history)+'\n',encoding='utf8')
        self.sha=hashlib.sha256(self.history_path.read_bytes()).hexdigest()
        self.constant=patch.object(candidate,'HISTORICAL_SOURCE_SHA',self.sha,create=True);self.constant.start()
        auth=json.loads(f.authorization.read_text(encoding='utf8'))
        auth.update(send_all_authorized=True,historical_over_60_days_authorized=True,
            historical_priority='after_recent_batches',historical_source_sha256=self.sha)
        f.authorization.write_text(json.dumps(auth),encoding='utf8')
        data=asdict(f.policy);data['authorization_sha256']=hashlib.sha256(f.authorization.read_bytes()).hexdigest()
        data['historical_age_override']={'source_path':str(self.history_path),'source_sha256':self.sha}
        self.data=data

    def tearDown(self):self.constant.stop();self.fixture.tearDown()

    def policy(self):return candidate.AuthorizedTargetIsolationPolicy.from_mapping(self.data)

    def reason(self,policy=None,meta=None,row=None):
        return mapping_reason(row or self.row,meta or self.meta,'2026-11-01',policy=policy,batch_path=self.fixture.fixture.batch)

    def test_default_age_hold_remains_and_explicit_qualified_override_only_removes_age(self):
        self.assertEqual(self.reason(),'comment_older_than_60_days')
        old=dict(self.data);old.pop('historical_age_override')
        self.assertEqual(self.reason(candidate.AuthorizedTargetIsolationPolicy.from_mapping(old)),'comment_older_than_60_days')
        before=self.history_path.read_bytes()
        self.assertIsNone(self.reason(self.policy()))
        self.assertEqual(self.history_path.read_bytes(),before)
        self.assertIs(self.history['current_need_confirmed'],False)
        self.assertIs(self.history['review_notes_not_cleared'],True)

    def test_all_authorization_without_explicit_historical_scope_cannot_clear_age(self):
        auth=json.loads(self.fixture.authorization.read_text(encoding='utf8'));auth['historical_over_60_days_authorized']=False
        self.fixture.authorization.write_text(json.dumps(auth),encoding='utf8')
        self.data['authorization_sha256']=hashlib.sha256(self.fixture.authorization.read_bytes()).hexdigest()
        self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_changed_source_or_original_text_never_clears_age(self):
        self.assertEqual(self.reason(self.policy(),meta={**self.meta,'original_comment':'changed'}),'comment_older_than_60_days')
        self.history_path.write_text('{}\n',encoding='utf8')
        self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_closed_title_identity_and_unknown_date_keep_their_original_holds(self):
        policy=self.policy()
        for meta,expected in [({**self.meta,'post_title':'已出租 apartment'},'post_no_longer_available'),
            ({**self.meta,'customer_uid':'other'},'target_mapping_conflict'),
            ({**self.meta,'published_at':'unknown'},'comment_date_unknown')]:
            self.assertEqual(self.reason(policy,meta=meta),expected)

    def test_active_semantic_or_fact_holds_cannot_be_cleared(self):
        for key,value in [('hold_reasons',['semantic_unresolved']),('semantic_invalid',True),
                          ('fact_assertion_unverified',True),('factual_scope','unverified_inventory_assertion')]:
            changed={**self.history,key:value}
            self.history_path.write_text(json.dumps(changed)+'\n',encoding='utf8')
            sha=hashlib.sha256(self.history_path.read_bytes()).hexdigest()
            self.data['historical_age_override']['source_sha256']=sha
            auth=json.loads(self.fixture.authorization.read_text(encoding='utf8'));auth['historical_source_sha256']=sha
            self.fixture.authorization.write_text(json.dumps(auth),encoding='utf8')
            self.data['authorization_sha256']=hashlib.sha256(self.fixture.authorization.read_bytes()).hexdigest()
            with patch.object(candidate,'HISTORICAL_SOURCE_SHA',sha):
                self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_known_platform_restriction_is_not_cleared_by_age_authorization(self):
        state=json.loads(self.fixture.b.state.read_text(encoding='utf8'))
        state['diagnostic']={'verification_header_present':True}
        self.fixture.b.state.write_text(json.dumps(state),encoding='utf8')
        self.data['platform_state_sha256']=hashlib.sha256(self.fixture.b.state.read_bytes()).hexdigest()
        self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')


if __name__=='__main__':unittest.main()
