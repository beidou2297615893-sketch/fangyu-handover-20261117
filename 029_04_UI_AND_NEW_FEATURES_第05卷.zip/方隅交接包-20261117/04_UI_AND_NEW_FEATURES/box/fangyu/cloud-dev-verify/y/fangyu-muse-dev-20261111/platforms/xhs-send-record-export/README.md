# 累计评论回复记录导出

脚本仅读取冻结批次、运行事件、原评论映射和 SQLite 账本，不加载发送器，不读取会话或凭据，不连接平台。未在真实账本上运行过；只做了合成测试。

从 `runs` 递归发现所有准备批次和真实运行，因此历史180、后续final4只要落在同一 `runs` 下，无需改脚本或硬编码批次名。按所选发送账号的真实 attempt 去重，每条提交只计一次；未提交草稿不会被计成已发送。

默认所有导出都是独立快照，输出目录必须不存在，绝不覆盖正式导出、批次文件或状态。运行中事件与账本跨文件不可能形成同一原子快照，可能出现暂时不一致；脚本会保留为待核对项。应在批次停止且对账后再把快照作为正式记录，脚本本身没有“转正式”或覆盖功能。

状态：

- 已取得平台回执：原生账本保存 `platform_receipt` 和非空真实回执号。账本 reservation 即使仍为 unknown，也按其真实回执区分。
- 结果未知：账本已有原生记录但没有真实回执，绝不计成失败或重发。
- 已预留，提交结果待核对：原生 reservation 仍为 reserved，不能由此断言 POST 已发生或进程仍在运行。
- 仅有运行记录：已出现提交开始或结果事件，但未与账本记录对应；不计入平台回执。

输出：

- `评论回复记录.csv`：中文业务列，含原帖标题、客户原评论、回复内容、结果、取得回执时间和可见性说明。对 Excel 公式起始字符作安全转义。
- `记录说明.txt`：累计分类数量及待核对提醒。
- `audit/records.jsonl`：技术对账信息，含真实 attempt、客户 UID、评论 ID、回执、原生记录哈希。只投影固定字段，不复制原始 native record、异常文本、body、headers、Cookie 或 Token。
- `audit/reconciliation.json`：输入文件哈希、批次覆盖、运行汇总和差异。成功事件必须与原生账本回执一致；冻结身份和文案须匹配原生 plan。原评论映射 UID 冲突时留空并报差异，不错误拼接。

平台回执仅证明提交获受理，不证明公开可见。导出不请求平台回读。

## 用法（父任务在需要时执行，本轮未执行真实导出）

```powershell
& 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 `
  'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-record-export/export_records.py' `
  --runs 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-current-20261029/runs' `
  --ledger 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/shared.sqlite3' `
  --mapping 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-current-20261029/target-mapping.json' `
  --sender-uid '5f469df5000000000101ec0b' `
  --output 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-record-export/snapshots/待核对累计记录-唯一名称'
```

输出目录最后一级须换为一个未使用名称。标准输出只含分类数量、一致性布尔值和差异条数。`reconciled=false` 时应查看 audit 差异；即使为 true，仍不代表平台可见性或客户已阅读。

## 离线测试

在本目录运行：

```powershell
& '../vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest test_export_records -v
```

6项通过。测试使用临时合成账本，核验数据库字节未改变、未知不冒充失败、重复事件不膨胀、在写事件尾部保守处理、只导出所选账号、不泄露藏于 native record 的模拟凭据、CSV 防公式注入和禁止覆盖。
