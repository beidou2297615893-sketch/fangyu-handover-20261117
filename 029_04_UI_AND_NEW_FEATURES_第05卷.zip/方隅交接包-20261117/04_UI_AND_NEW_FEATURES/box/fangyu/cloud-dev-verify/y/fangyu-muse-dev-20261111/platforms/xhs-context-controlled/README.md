# 受控正文补读入口

此入口仅为本次五位待核客户补读三篇所属帖子的标题和正文。默认预览，不访问平台。它不会搜索、读楼中楼或历史回执，也不会发送；不写业务数据库或账本，不覆盖已有输入。

程序：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-context-controlled/context_reader.py`

目录：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-context-controlled`

在工程根目录运行预览（已实际验证显示 5 位、3 篇，无网络）：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -X utf8 'work/xhs-context-controlled/context_reader.py' --input 'work/xhs-collection-candidate/work/gubei-continue-20261028-a/new-ai-input.json' --review-analysis 'work/xhs-collection-candidate/work/gubei-continue-20261028-a/new-ai-review/analysis.json' --output 'work/xhs-context-controlled/work/gubei-five-context' --source-top-level
```

由已获授权的执行者确认指定账号 UID 后，在同一命令追加：

```text
--session-home work/xhs-standalone-session/cli-login-20261028-165417 --sender-uid <蕾姆已核对的UID> --execute
```

不要将尖括号占位符原样执行。不要打印 token 或复制会话。输出目录须不存在；首次成功后不可用同一路径重跑。

执行先检查这三篇在现有独立会话的 token 缓存中有仍在 24 小时有效期内的 `pc_search` 上下文，然后核对账号身份，按帖子去重，每篇正文最多读取一次。直接调用 `get_note_by_id`，不用会自动回退 HTML 的 `get_note_detail`。唯一允许的请求是身份检查 GET `/api/sns/web/v2/user/me` 和正文只读 POST `/api/sns/web/v1/feed`。461、429、平台业务失败、网络错误等立即停止，不自动重试。

成功输出 `ai-input.json`（五位、保留本人原评论）、`note-context.json`、`state.json`。已取得的正文随进度保存 `partial-context.json`，失败时保留已得结果；错误只记脱敏原因。`--source-top-level` 只适用于已核实来自主评论顶层的本批输入，用于纠正原先统一“未采集父评论”的标记，不推断任何楼中楼内容。

离线测试：在本目录运行 `../vendor/cli-runtime/Scripts/python.exe -X utf8 -m unittest -v test_context_reader`。8 项通过；没有真实平台调用。真实补读与补齐后的 AI 复判仍待执行，不把离线测试当真实平台成功。
