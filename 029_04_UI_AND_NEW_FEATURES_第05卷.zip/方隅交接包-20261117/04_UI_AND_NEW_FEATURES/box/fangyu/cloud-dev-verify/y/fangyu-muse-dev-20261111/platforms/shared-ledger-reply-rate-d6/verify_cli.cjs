'use strict';
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..');
const {BridgeClient}=require(path.join(root,'work/runtime/douyin-bridge/lib/client/bridge-client'));
const {assertPageReady}=require('../douyin-local-control/page_guard.cjs');
const {scan}=require('./read_replies.cjs');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
(async()=>{try{
 const spec=JSON.parse(fs.readFileSync(0,'utf8'));
 const binding=read(path.join(spec.task,'cli-current-binding.json'));
 if(binding.account_uid!==spec.accountUid||!binding.connection_id)throw Error('account_mismatch');
 const config=read(path.join(root,'抖音自用采集台/data/bridge.json')).bridge;
 const client=new BridgeClient(config),conn=binding.connection_id;
 await assertPageReady(client,conn);
 const identity=await client.call({site:'douyin.com',connId:conn,timeout:10000,expression:`(async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include'});const d=await r.json();return {code:d.status_code,uid:d.user?.sec_uid}})()`});
 if(!identity.ok||identity.connection!==conn||identity.value?.code!==0||identity.value?.uid!==spec.accountUid)throw Error('account_mismatch');
 console.log(JSON.stringify(await scan(client,conn,spec)));
}catch(e){console.log(JSON.stringify({state:'unknown',reason:String(e.message).startsWith('CURRENT_GATE:')?'platform_verification':'connection_or_identity',pages:0}));}})();
