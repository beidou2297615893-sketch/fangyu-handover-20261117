"""Bounded, explicit-context readback; this module has no posting endpoint."""
import hashlib
import importlib.util
from pathlib import Path
from urllib.parse import urlsplit
from managed_send_client import managed,PROJECT

SUB_PATH='/api/sns/web/v2/comment/sub/page'
COMMENTS_PATH='/api/sns/web/v2/comment/page'
IDENTITY_PATH='/api/sns/web/v2/user/me'
compat_path=PROJECT/'work/xhs-standalone-reply/subcomments_compat.py'
COMPAT_SHA256='dc34f1bc9aa827f13b54fb01a7ed5e6217e03a4c1d71bac4a860fa32ec9e1d0b'
if hashlib.sha256(compat_path.read_bytes()).hexdigest()!=COMPAT_SHA256:
    raise RuntimeError('Reviewed subcomment adapter changed')
spec=importlib.util.spec_from_file_location('current_reply_readback_subcomments',compat_path)
compat=importlib.util.module_from_spec(spec);spec.loader.exec_module(compat)

class ReadbackStop(RuntimeError):
    def __init__(self,reason):self.reason=reason;super().__init__(reason)


def _require_text(*values):
    if any(not isinstance(x,str) or not x.strip() for x in values):
        raise ValueError('Explicit note, target and access context required')


class ReadbackClient(managed.ManagedClient):
    _ALLOWED=frozenset({
        ('GET','https://edith.xiaohongshu.com'+IDENTITY_PATH),
        ('GET','https://edith.xiaohongshu.com'+COMMENTS_PATH),
        ('GET','https://edith.xiaohongshu.com'+SUB_PATH),
    })
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._readback_identity_verified=False
        self.last_read_kind='unknown'
        # The reused ReadClient predates sub/page and calls it search. This
        # request-bound hook corrects the metadata before response/error parsing.
        self._http.event_hooks['request'].append(self._observe_request)
        self._http.event_hooks['response'].append(self._observe_response)

    def _observe_request(self,request):
        path=request.url.path
        if path in (COMMENTS_PATH,SUB_PATH):
            self._last_stage='comments';self._last_endpoint_kind='comments'
            self.managed_request_context.update(stage='comments',endpoint='comments',request_started=True)
            self.last_read_kind='subcomments' if path==SUB_PATH else 'comments'
        elif path==IDENTITY_PATH:self.last_read_kind='identity'

    def _observe_response(self,response):
        if any(name in response.headers for name in ('verifytype','verifyuuid')):
            self.last_failure_detail={'error_type':'ReadbackStop','stage':self._last_stage,
                'endpoint':self._last_endpoint_kind,'http_status':response.status_code,
                'request_started':True,'verification_header_present':True}
            raise ReadbackStop('verification_response_requires_review')
        if response.status_code!=200:
            self.last_failure_detail={'error_type':'HTTPError','stage':self._last_stage,
                'endpoint':self._last_endpoint_kind,'http_status':response.status_code,'request_started':True}

    def _request_with_retry(self,method,url,**kwargs):
        if urlsplit(url).path in (COMMENTS_PATH,SUB_PATH) and not self._readback_identity_verified:
            raise ReadbackStop('identity_required_before_readback')
        return super()._request_with_retry(method,url,**kwargs)

    def verify_identity(self):
        data=self.get_self_info()
        identity=managed.account.identify(data)
        if identity['uid']!=self.expected_uid:self._stop('account_changed_no_retry')
        self._readback_identity_verified=True
        return identity

    def _ready(self):
        self.assert_managed_session()
        if not self._readback_identity_verified:self.verify_identity()

    def read_subcomments(self,note_id,root_comment_id,xsec_token,*,cursor='',num=30):
        _require_text(note_id,root_comment_id,xsec_token)
        if not isinstance(cursor,str) or type(num) is not int or not 1<=num<=100:
            raise ValueError('Invalid explicit pagination parameters')
        self._ready()
        return compat.read_subcomments(self,note_id,root_comment_id,xsec_token,cursor=cursor,num=num)

    def get_sub_comments(self,note_id,root_comment_id,num=30,cursor='',*,xsec_token=''):
        return self.read_subcomments(note_id,root_comment_id,xsec_token,cursor=cursor,num=num)

    def get_comments(self,note_id,cursor='',xsec_token='',top_comment_id='',xsec_source=''):
        _require_text(note_id,xsec_token)
        if not all(isinstance(v,str) for v in (cursor,top_comment_id,xsec_source)):
            raise ValueError('Invalid explicit comment parameters')
        self._ready()
        # Same explicit-token payload as the installed get_comments. Deliberately
        # bypass its note-context cache and optional HTML/context refresh branch.
        return self._main_api_get(COMMENTS_PATH,{'note_id':note_id,'cursor':cursor,
            'top_comment_id':top_comment_id,'image_formats':'jpg,webp,avif','xsec_token':xsec_token})

    def get_all_comments(self,*args,**kwargs):
        raise ReadbackStop('implicit_all_comments_not_enabled')

    def iter_subcomment_pages(self,note_id,root_comment_id,xsec_token,*,cursor='',num=30,max_pages=20):
        _require_text(note_id,root_comment_id,xsec_token)
        if type(max_pages) is not int or not 1<=max_pages<=20 or not isinstance(cursor,str):
            raise ValueError('Invalid bounded page budget')
        seen=set()
        for _ in range(max_pages):
            if cursor in seen:raise ReadbackStop('cursor_repeated')
            seen.add(cursor)
            data=self.read_subcomments(note_id,root_comment_id,xsec_token,cursor=cursor,num=num)
            if not isinstance(data,dict) or not isinstance(data.get('comments'),list):
                raise ReadbackStop('comment_page_shape_unknown')
            yield data
            more=data.get('has_more')
            if type(more) is not bool:raise ReadbackStop('pagination_state_unknown')
            if more is False:return
            next_cursor=data.get('cursor')
            if not isinstance(next_cursor,str) or not next_cursor:
                raise ReadbackStop('cursor_missing')
            if next_cursor in seen:raise ReadbackStop('cursor_repeated')
            cursor=next_cursor
        raise ReadbackStop('page_budget_exhausted')

    def diagnostic(self,exc):
        data=managed.account.safe_failure(self,exc)
        if isinstance(exc,ReadbackStop) and exc.reason in {'identity_required_before_readback','implicit_all_comments_not_enabled','cursor_repeated','comment_page_shape_unknown','pagination_state_unknown','cursor_missing','page_budget_exhausted','verification_response_requires_review'}:data['category']=exc.reason
        data['read_kind']=self.last_read_kind
        return data


def match_receipt(comment,*,reply_id,sender_uid,root_comment_id,text):
    """Pure strict match. Missing/conflicting fields cannot prove visibility."""
    _require_text(reply_id,sender_uid,root_comment_id,text)
    unknown={'status':'unknown'}
    if not isinstance(comment,dict):return unknown
    ids=[comment[k] for k in ('id','comment_id') if k in comment]
    if not ids or any(v!=reply_id for v in ids):return unknown
    bodies=[comment[k] for k in ('content','comment_text') if k in comment]
    if not bodies or any(v!=text for v in bodies):return unknown
    uids=[]
    if 'user_id' in comment:uids.append(comment['user_id'])
    for name in ('user_info','user','author'):
        value=comment.get(name)
        if name in comment and not isinstance(value,dict):return unknown
        if isinstance(value,dict):uids.extend(value[k] for k in ('user_id','userid','uid','id') if k in value)
    if not uids or any(v!=sender_uid for v in uids):return unknown
    relations=[comment[k] for k in ('root_comment_id','target_comment_id') if k in comment]
    target=comment.get('target_comment')
    if 'target_comment' in comment and not isinstance(target,dict):return unknown
    if isinstance(target,dict):relations.extend(target[k] for k in ('id','comment_id') if k in target)
    if not relations or any(v!=root_comment_id for v in relations):return unknown
    return {'status':'verified','reply_id':reply_id,'sender_uid':sender_uid,'root_comment_id':root_comment_id,'text_matches':True}
