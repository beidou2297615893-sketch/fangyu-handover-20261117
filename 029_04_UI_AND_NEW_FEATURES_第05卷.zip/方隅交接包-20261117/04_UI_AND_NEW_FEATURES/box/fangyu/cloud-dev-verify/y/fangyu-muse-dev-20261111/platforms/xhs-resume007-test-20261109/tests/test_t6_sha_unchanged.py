"""T6: 验收前后 src 副本 SHA256 不变（不改现有文件）。"""
import hashlib
import unittest
from pathlib import Path

SRC_COPY = Path('/workspace/project-intake/fangyu/review/xhs-resume007-src')
BASELINE = Path('/workspace/project-intake/fangyu/review/xhs-resume007-out/tests/.src-sha-baseline.txt')
OUT_DIR = Path(__file__).resolve().parents[1]


def _sha_tree(root: Path):
    rows = []
    for p in sorted(root.rglob('*')):
        if p.is_file():
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append(f'{digest}  {p.relative_to(root).as_posix()}')
    return '\n'.join(rows) + '\n'


class TestShaUnchanged(unittest.TestCase):
    @unittest.skipUnless(SRC_COPY.exists(), 'box 专用：用户机无 src 副本，跳过')
    def test_src_sha_matches_baseline(self):
        current = _sha_tree(SRC_COPY)
        if not BASELINE.exists():
            BASELINE.write_text(current, encoding='utf-8')
        baseline = BASELINE.read_text(encoding='utf-8')
        self.assertEqual(current, baseline, 'xhs-resume007-src 下文件被改动')

    def test_resume007_parses(self):
        import ast
        ast.parse((OUT_DIR / 'resume007.py').read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
