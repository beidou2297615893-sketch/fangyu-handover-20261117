"""Attach durable text checkpoints to an existing sender module in isolation."""
from pathlib import Path
from journal_hooks_candidate import JournalFailure

def attach(sender, ledger, journal, sync, stop_requested=lambda:False):
 original_reserve=sender._reserve;original_outcome=sender._outcome
 def checkpoint():
  try:sync(ledger,journal)
  except Exception as exc:raise JournalFailure('文本记录未能落盘，已停止发送') from exc
 checkpoint() # reconstruct any committed facts before starting
 def reserve(*args,**kwargs):
  if stop_requested():raise JournalFailure('本人要求停止，本条未预留')
  value=original_reserve(*args,**kwargs)
  checkpoint()
  if stop_requested():raise JournalFailure('本人要求停止，已保留预留记录，本条未提交')
  return value
 def outcome(*args,**kwargs):
  value=original_outcome(*args,**kwargs);checkpoint();return value
 if hasattr(sender,"OneAttemptClient"):
  old_wire=sender.OneAttemptClient._request_with_retry
  def wire(client,method,url,**kwargs):
   if method=="POST" and stop_requested():raise sender.Refused("本人要求停止，本条未提交")
   return old_wire(client,method,url,**kwargs)
  sender.OneAttemptClient._request_with_retry=wire
 sender._reserve=reserve;sender._outcome=outcome
 return checkpoint
