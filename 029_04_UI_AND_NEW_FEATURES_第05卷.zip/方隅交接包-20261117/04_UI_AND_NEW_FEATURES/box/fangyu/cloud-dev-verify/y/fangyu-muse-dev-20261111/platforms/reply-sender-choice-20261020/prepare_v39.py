from pathlib import Path
import hashlib,json,importlib.util,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
S=F/'stage-02/project';C=F/'candidate-unified-v39';PROJECT=C/'project';N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
before=read(F/'candidate-unified-v38/INPUT-SNAPSHOT.json')['files'];after=read(C/'INPUT-SNAPSHOT.json')['files']
changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
added=set(read(T/'ADDED.json'))
expected={p.relative_to(T/'before').as_posix() for p in (T/'before').rglob('*') if p.is_file()}|added
assert changed==expected,(changed-expected,expected-changed)
for k in changed:
    if k not in added:assert sha(T/'before'/k)==before[k],k
    assert sha(S/k)==after[k] and sha(PROJECT/k)==after[k],k
pins=read(C/'UNIFIED-PINS.json')
for row in pins['files']:
    p=PROJECT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
guard='work/speed-collection-worker/component/artifacts/platform-cli-guarded/guard-manifest.json'
assert (PROJECT/guard).read_bytes()==(F/'candidate-unified-v38/project'/guard).read_bytes()
assert sha(N/'run_workbench.py')==read(F/'entry-v38/CANONICAL-DELEGATION-PREPARED.json')['launcher_sha256'].lower()
binding=sha(N/'state/production-workspace.json').upper()
assert binding=='14CF53964F5D44D123E989805EA741669AB3F05054E730DDCB299A0AAC51A9CB'
assert sha(PROJECT/'work/ui-native-r57/state/production-workspace.json').upper()==binding
staged=read(C/'STAGED.json');release=Path(staged['release']);manifest=read(release/'RELEASE.json')
assert sha(release/'RELEASE.json').upper()==staged['manifest_sha256'].upper()
files={r['path']:r for r in manifest['files']}
for key in ('reply_delivery.py','web/pages/reply-delivery.mjs','web/pages/acquisition-help.mjs','web/account-connection-state.mjs','web/viewport-layout.mjs'):
    assert key in files,key
assert sha(release/'web/account-connection-state.mjs')==sha(S/'work/ui-approved-implementation/ui-preview/account-connection-state.mjs')
assert sha(release/'workbench_backend.py')==sha(S/'work/ui-native-r57/workbench_backend.py')
assert sha(release/'resources/platform-runtime/platform_runtime.py')==sha(S/'work/shared-backend-integration/platform_runtime.py')
validation={'status':'PASS_SOURCE_CLOSURE_AND_EXPLICIT_REPLY_SENDER','files':len(pins['files']),'changed':sorted(changed),'explicit_uniform_sender':'PASS','sender_nickname_projection':'PASS','stale_sender_preview':'PASS','single_account_change_requires_review':'PASS','batch_and_scope_regressions':'PASS','js_syntax':'PASS','native_UI_visual_review':'NOT_RUN_PREVIOUS_AUTOMATION_APPROVAL_BLOCK','real_AI_calls':0,'real_sends':0,'real_collection':0}
write(T/'VALIDATION.json',validation)
spec=importlib.util.spec_from_file_location('existing_entry_builder',N/'freeze_ui.py')
builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
body=builder.launcher_source(staged['release_id'],staged['manifest_sha256'],files['ui_native_host.py']['sha256'],files['lifecycle_log.py']['sha256'])
needle="RELEASE = ROOT / 'releases/"+staged['release_id']+"'";assert body.count(needle)==1
body=body.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v39/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+staged['release_id']+"'\nBINDING_SHA256 = '"+binding+"'")
assert body.count('project_root=ROOT.parent.parent')==1
body=body.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)";assert body.count(needle)==1
body=body.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(body,'run_workbench.py','exec')
launcher=N/('run_delegated_candidate.'+staged['release_id']+'.py')
with launcher.open('xb') as out:out.write(body.encode('utf-8'))
entry=F/'entry-v39';entry.mkdir(exist_ok=False)
plan={'status':'PREPARED_NOT_INSTALLED','release_id':staged['release_id'],'release':staged['release'],
    'manifest_sha256':staged['manifest_sha256'],'launcher':str(launcher),'launcher_sha256':sha(launcher).upper(),
    'expected_previous_launcher_sha256':sha(N/'run_workbench.py').upper(),'expected_previous_frozen_sha256':sha(N/'FROZEN.json').upper(),
    'runtime_project_root':str(PROJECT),'installation_state_root':str(N/'state'),'workspace_binding_sha256':binding,
    'full_closure_files_verified':len(pins['files']),'full_closure_manifest_sha256':sha(C/'UNIFIED-PINS.json').upper(),
    'validation':str(T/'VALIDATION.json'),'installed':False,'component_use_policy':'pending',
    'production_cloud_activation':False,'compiled_cli_executed':False,'production_data_migration':False}
write(entry/'CANONICAL-DELEGATION-PREPARED.json',plan)
write(T/'CHANGES.json',[{'path':k,'before':before.get(k),'after':after[k]} for k in sorted(changed)])
print(json.dumps({'prepared':True,'release':staged['release_id'],'files':len(pins['files']),'changes':len(changed)}))
