"""Prepare evidence-bound AI context from a read-only local customer database.

This module does not call a model, read account cookies, or send messages.
``ready`` only means local identity and representative text are sufficient to
start analysis; it is never authorization or confirmation that a reply is safe.
"""
import argparse
from collections import Counter, defaultdict
from contextlib import closing
import json
from pathlib import Path
import re
import sqlite3
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent


def note_id(value):
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = urlsplit(value)
        if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('xiaohongshu.com', 'www.xiaohongshu.com'):
            return None
        m = re.search(r'/(?:explore|discovery/item)/([0-9a-fA-F]{24})(?:/|$)', parsed.path)
        return m.group(1) if m else None
    except ValueError:
        return None


def extract(database, batch, account_uid):
    database = Path(database).resolve(strict=True)
    with closing(sqlite3.connect(database.as_uri() + '?mode=ro', uri=True, timeout=2)) as conn:
        conn.execute('PRAGMA query_only=ON')
        conn.execute('BEGIN')
        data = conn.execute("SELECT entity, id, tenant_id, body FROM records WHERE entity IN ('leads','customer_intent_projection_v1')").fetchall()
        conn.rollback()
    leads, projections = {}, []
    for entity, row_id, tenant, raw in data:
        row=json.loads(raw)
        if not isinstance(row,dict) or not isinstance(tenant,str) or not tenant:
            raise ValueError('invalid source record')
        if entity=='leads':
            if row.get('id') != row_id or (tenant,row_id) in leads: raise ValueError('ambiguous lead identity')
            leads[(tenant,row_id)]=row
        else:
            projections.append((tenant,row))
    by_comment=defaultdict(list)
    for (tenant,_),row in leads.items():
        if row.get('platform') and row.get('comment_id'):
            by_comment[(tenant,row['platform'],row['comment_id'])].append(row)
    selected=None
    if batch is not None:
        if not isinstance(batch,dict) or not isinstance(batch.get('rows'),list): raise ValueError('invalid batch')
        bound_account=batch.get('intended_account_uid')
        if bound_account is not None and (not isinstance(bound_account,str) or not bound_account): raise ValueError('invalid batch account')
        if account_uid and bound_account and account_uid!=bound_account: raise ValueError('batch account mismatch')
        account_uid=account_uid or bound_account
        selected={}
        for row in batch['rows']:
            if not isinstance(row,dict) or not isinstance(row.get('customer_id'),str) or not row['customer_id'] or row['customer_id'] in selected:
                raise ValueError('invalid or duplicate batch customer')
            selected[row['customer_id']]=row
    if account_uid is not None and (not isinstance(account_uid,str) or not account_uid.strip()): raise ValueError('invalid account uid')
    customers=[]; seen=set()
    for tenant,projection in projections:
        cid=projection.get('customer_id')
        if not isinstance(cid,str) or not cid: raise ValueError('invalid customer id')
        if selected is not None and cid not in selected: continue
        if cid in seen: raise ValueError('ambiguous customer across tenant or store scope')
        seen.add(cid)
        members=projection.get('members')
        if not isinstance(members,list): raise ValueError('invalid projection members')
        issues=[]; own=[]; uids=set(); platform=projection.get('platform'); member_ids=set()
        for member in members:
            lid=member.get('lead_id') if isinstance(member,dict) else None
            if not isinstance(lid,str) or not lid or lid in member_ids:
                issues.append('invalid_or_duplicate_member'); continue
            member_ids.add(lid); row=leads.get((tenant,lid))
            if row is None:
                issues.append('missing_member'); continue
            if row.get('platform')!=platform:
                issues.append('platform_mismatch'); continue
            uid=row.get('author_id')
            if isinstance(uid,str) and uid.strip(): uids.add(uid)
            else: issues.append('platform_uid_missing')
            missing=['post_body_missing','direct_reply_target_not_verified']
            nid=note_id(row.get('note_url'))
            if not nid: missing.append('post_id_missing')
            if not row.get('content_title'): missing.append('post_title_missing')
            if not row.get('published_at'): missing.append('comment_time_missing')
            pid=row.get('parent_id') or None; parent=None
            if pid:
                candidates=by_comment.get((tenant,platform,pid),[])
                candidates=[x for x in candidates if nid and note_id(x.get('note_url'))==nid]
                if len(candidates)==1:
                    parent={'comment_id':pid,'text':candidates[0].get('text') or None,'author_uid':candidates[0].get('author_id') or None,
                            'relationship':'root_or_parent_not_direct_verified'}
                    if not parent['text']:missing.append('parent_text_missing')
                else:
                    parent={'comment_id':pid,'text':None,'author_uid':None,'relationship':'root_or_parent_not_direct_verified'}
                    missing.append('parent_not_available' if not candidates else 'parent_ambiguous')
            text=row.get('text')
            if not isinstance(text,str) or not text.strip():
                missing.append('comment_text_missing'); issues.append('comment_text_missing')
            elif text!=text.strip() or len(text)>5000:
                missing.append('comment_text_format_requires_review'); issues.append('comment_text_format_requires_review')
            if not isinstance(row.get('comment_id'),str) or not row['comment_id'].strip():issues.append('comment_id_missing')
            if not nid:issues.append('post_id_missing')
            own.append({'lead_id':lid,'comment_id':row.get('comment_id') or None,'author_uid':uid or None,
                        'text':row.get('text') or None,'published_at':row.get('published_at') or None,
                        'post':{'note_id':nid,'title':row.get('content_title') or None,'body':None},'parent':parent,
                        'missing_context':missing})
        if len(uids)>1: issues.append('platform_uid_conflict')
        if not uids: issues.append('platform_uid_missing')
        puid=next(iter(uids)) if len(uids)==1 and 'missing_member' not in issues and 'platform_uid_missing' not in issues else None
        customer=projection.get('customer') if isinstance(projection.get('customer'),dict) else {}
        selection=selected.get(cid) if selected is not None else None
        representative=customer.get('representativeLeadId')
        if selection is not None:
            candidates=[x for x in own if x['comment_id']==selection.get('comment_id')]
            if len(candidates)!=1: issues.append('batch_comment_mismatch')
            else:
                representative=candidates[0]['lead_id']
                if candidates[0]['post']['note_id']!=selection.get('note_id'): issues.append('batch_note_mismatch')
            if not puid or selection.get('customer_uid')!=puid: issues.append('batch_uid_mismatch')
        target=[x for x in own if x['lead_id']==representative]
        if len(target)!=1: issues.append('representative_missing')
        elif not target[0]['text']: issues.append('comment_text_missing')
        if not account_uid: issues.append('account_uid_missing')
        customer_region=customer.get('regionMatch') if isinstance(customer.get('regionMatch'),dict) else {}
        eligibility=customer.get('storeEligibility') if isinstance(customer.get('storeEligibility'),dict) else {}
        assessment={'interest_status':customer.get('interestStatus'),'interest_level':customer.get('interestLevel'),
                    'demand_state':customer.get('demandState'),'region_state':customer_region.get('state'),
                    'eligibility_state':eligibility.get('state'),'role':eligibility.get('role'),
                    'source':'local_historical_projection_not_current_verification'}
        customers.append({'customer_id':cid,'platform':platform,'platform_uid':puid,
                          'identity_evidence':'local_source_consistency_only',
                          'account':{'uid':account_uid,'role_facts':None,'missing_context':['account_role_facts_not_attached']},
                          'assessment':assessment,'representative_lead_id':representative,'comments':own,
                          'state':'needs_review' if issues else 'ready','issues':sorted(set(issues))})
    if selected is not None and seen!=set(selected): raise ValueError('batch customer missing from local projections')
    customers.sort(key=lambda x:x['customer_id'])
    counts=Counter(x['state'] for x in customers)
    return {'schema':'xhs-ai-context-v1','limitations':['local_snapshot_only','post_body_not_provided',
            'platform_reply_history_not_checked','account_role_facts_not_attached','ready_means_ai_input_only_not_send_authorization'],
            'summary':{'customers':len(customers),'comments':sum(len(x['comments']) for x in customers),
                       'ready_for_ai_input':counts['ready'],'needs_review':counts['needs_review'],
                       'unique_platform_uids':len({x['platform_uid'] for x in customers if x['platform_uid']})},'customers':customers}


def blocked_customers(ledger, customers):
    """Conservatively exclude any locally sent, reserved or unresolved identity."""
    path=Path(ledger).resolve(strict=True)
    with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=2)) as conn:
        conn.execute('PRAGMA query_only=ON')
        conn.execute('BEGIN')
        leads=conn.execute("SELECT customer,status FROM leads WHERE platform='xiaohongshu'").fetchall()
        reservations=conn.execute("SELECT customer,status FROM reservations WHERE platform='xiaohongshu'").fetchall()
        deliveries=conn.execute("SELECT customer,delivery_state FROM historical_deliveries WHERE platform='xiaohongshu'").fetchall()
        aliases=conn.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'").fetchall()
        conn.rollback()
    blocked_ids={cid for cid,status in leads if status in ('reserved','unknown','sent')}
    blocked_ids.update(cid for cid,status in reservations if status in ('reserved','unknown','sent','submitted'))
    blocked_ids.update(cid for cid,status in deliveries if status!='not_sent')
    alias_map=defaultdict(set)
    for alias,canonical in aliases: alias_map[alias].add(canonical)
    blocked=set()
    for customer in customers:
        cid=customer['customer_id']; uid=customer.get('platform_uid')
        # A conflicting legacy alias or records under either key require review.
        if cid in blocked_ids or uid in blocked_ids or (uid in alias_map and alias_map[uid]!={cid}):
            blocked.add(cid)
    return blocked


def pipeline_rows(contexts, blocked):
    result=[]
    for customer in contexts['customers']:
        if customer['state']!='ready' or customer['customer_id'] in blocked: continue
        selected=[x for x in customer['comments'] if x['lead_id']==customer['representative_lead_id']]
        if len(selected)!=1: continue
        target=selected[0]
        if not target['comment_id'] or not target['post']['note_id'] or not target['text']: continue
        def comment(row):
            parent=row['parent'] or {}
            missing=list(row['missing_context'])
            if not row['parent']:missing.append('parent_absent_or_not_captured')
            return {'comment_id':row['comment_id'] or '', 'note_id':row['post']['note_id'] or '',
                    'comment_text':row['text'] or '', 'parent_text':parent.get('text') or '',
                    'parent_relationship':parent.get('relationship') or 'unknown',
                    'post_title':row['post']['title'] or '', 'post_text':row['post']['body'] or '',
                    'published_at':row['published_at'] or '', 'missing_context':sorted(set(missing))}
        item={'customer_id':customer['customer_id'],'customer_uid':customer['platform_uid'],**comment(target),
              'other_comments':[comment(x) for x in customer['comments'] if x['lead_id']!=target['lead_id']]}
        result.append(item)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--database',required=True,help='Existing source database; opened read only')
    p.add_argument('--batch',help='Optional prepared batch with customer and comment IDs')
    p.add_argument('--account-uid',help='Sender UID; not a verified account identity or role')
    p.add_argument('--output',required=True,help='New JSON file inside this adapter directory')
    p.add_argument('--ledger',help='Existing shared ledger; opened read only')
    p.add_argument('--pipeline-output',help='New AI pipeline input array in this adapter directory; requires --ledger')
    a=p.parse_args()
    output=Path(a.output).resolve()
    if output==ROOT or not output.is_relative_to(ROOT):raise ValueError('output must stay in adapter directory')
    pipeline_output=Path(a.pipeline_output).resolve() if a.pipeline_output else None
    if pipeline_output and (not a.ledger or pipeline_output==ROOT or not pipeline_output.is_relative_to(ROOT) or pipeline_output==output):
        raise ValueError('pipeline output requires ledger and a distinct path in adapter directory')
    batch=json.loads(Path(a.batch).read_text(encoding='utf-8-sig')) if a.batch else None
    result=extract(a.database,batch,a.account_uid)
    blocked=blocked_customers(a.ledger,result['customers']) if pipeline_output else set()
    rows=pipeline_rows(result,blocked) if pipeline_output else None
    if output.exists() or pipeline_output and pipeline_output.exists():raise ValueError('output already exists')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    if pipeline_output:
        pipeline_output.parent.mkdir(parents=True,exist_ok=True)
        with pipeline_output.open('x',encoding='utf-8') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
    print(json.dumps({**result['summary'],'blocked_by_local_history':len(blocked),'pipeline_customers':len(rows) if rows is not None else None},ensure_ascii=False))


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,sqlite3.Error,json.JSONDecodeError) as exc:
        print(json.dumps({'error':str(exc)},ensure_ascii=False),file=__import__('sys').stderr)
        raise SystemExit(1)
