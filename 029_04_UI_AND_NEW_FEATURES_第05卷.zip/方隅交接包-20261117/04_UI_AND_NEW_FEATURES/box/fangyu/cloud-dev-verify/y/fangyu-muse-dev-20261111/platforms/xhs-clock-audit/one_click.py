"""Opt-in AI preparation then existing standalone CLI, using a chosen model."""
from contextlib import closing
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

import pipeline

LOCK_DIR=Path(__file__).resolve().parent/'workflow-locks'


class WorkflowError(RuntimeError): pass


class WorkflowLock:
    """Cooperating processes share a per-account lock distinct from sender locks."""
    def __init__(self,directory,sender_uid):
        if not isinstance(sender_uid,str) or not sender_uid.strip():
            raise WorkflowError('缺少账号标识，无法启动')
        self.path=Path(directory)/('ai-workflow-'+hashlib.sha256(sender_uid.encode('utf8')).hexdigest()+'.lock')
        self.file=None

    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open('a+b')
        try:
            self.file.seek(0,os.SEEK_END)
            if self.file.tell()==0:
                self.file.write(b'0');self.file.flush()
            self.file.seek(0)
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.file.close();self.file=None
            raise WorkflowError('该账号已有 AI 工作流在运行，未重复启动') from None
        return self

    def __exit__(self,exc_type,exc,tb):
        if self.file is not None:
            try:
                self.file.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(self.file.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(self.file.fileno(),fcntl.LOCK_UN)
            finally:self.file.close();self.file=None


def filter_unattempted(records,ledger):
    pipeline.validate_records(records)
    path=Path(ledger).resolve(strict=True)
    with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=2)) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        attempted=db.execute("SELECT r.customer,r.comment,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform='xiaohongshu' AND r.status IN ('reserved','unknown','sent')").fetchall()
        historical=db.execute("SELECT customer,comment FROM historical_deliveries WHERE platform='xiaohongshu' AND delivery_state<>'not_sent'").fetchall()
        aliases=db.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'").fetchall()
        db.rollback()
    customers=set();comments=set();users=set()
    for customer,comment,payload in attempted:
        customers.add(customer);comments.add(comment)
        if not payload: raise WorkflowError('历史发送记录缺少用户关联，需先核对')
        try:
            user=json.loads(payload)['plan']['customer_uid']
            if not isinstance(user,str) or not user:raise ValueError('invalid uid')
        except (ValueError,KeyError,TypeError,AttributeError):raise WorkflowError('历史发送记录用户关联无效，需先核对') from None
        users.add(user)
    for customer,comment in historical:customers.add(customer);comments.add(comment)
    mapping={alias:canonical for alias,canonical in aliases}
    selected=[];skipped=[]
    for row in records:
        comment_ids={x['comment_id'] for x in [row,*row.get('other_comments',[])]}
        reason=None
        if mapping.get(row['customer_uid'],row['customer_id'])!=row['customer_id']:
            reason='identity_conflict'
        elif row['customer_id'] in customers or row['customer_uid'] in users or comments.intersection(comment_ids):
            reason='known_local_history'
        if reason:skipped.append({'customer_id':row['customer_id'],'reason':reason})
        else:selected.append(row)
    return selected,skipped


def run_workflow(*,input_path,output_dir,ledger,sender_uid,account,samples,provider,send,execute):
    if not execute:raise WorkflowError('没有显式启动；未访问模型或平台')
    if provider is None:raise WorkflowError('没有配置 AI 模型；未启动')
    # Separate from the sender's account lock. Fixed acquisition order and
    # nonblocking locks avoid deadlocks while covering both shared resources.
    checkpoint_key='checkpoint:'+str(Path(output_dir).resolve())
    with WorkflowLock(LOCK_DIR,sender_uid), WorkflowLock(LOCK_DIR,checkpoint_key):
        return _run_workflow_locked(input_path=input_path,output_dir=output_dir,ledger=ledger,sender_uid=sender_uid,
                                    account=account,samples=samples,provider=provider,send=send)


def _run_workflow_locked(*,input_path,output_dir,ledger,sender_uid,account,samples,provider,send):
    source=Path(input_path).resolve(strict=True)
    records=pipeline.validate_records(json.loads(source.read_text(encoding='utf-8-sig')))
    out=Path(output_dir).resolve();out.mkdir(parents=True,exist_ok=True)
    snapshot=out/'selection.json'
    binding=out/'selection-binding.json'
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    if binding.exists() or snapshot.exists():
        if not (binding.is_file() and snapshot.is_file()):raise WorkflowError('已有筛选快照不完整，不能继续')
        info=json.loads(binding.read_text(encoding='utf8'))
        if info.get('input_sha256')!=source_hash or info.get('sender_uid')!=sender_uid:
            raise WorkflowError('原始资料或账号变化，不能复用旧快照')
        try:review_as_of=pipeline.validate_review_as_of(info.get('review_as_of'))
        except pipeline.InvalidInput:raise WorkflowError('旧筛选快照缺少有效分析时间') from None
        selected=pipeline.validate_records(json.loads(snapshot.read_text(encoding='utf8')))
        if info.get('selection_sha256')!=hashlib.sha256(snapshot.read_bytes()).hexdigest():raise WorkflowError('筛选快照已变化')
        skipped_count=info['skipped_count']
    else:
        selected,skipped=filter_unattempted(records,ledger)
        skipped_count=len(skipped)
        if not selected:return {'selected':0,'skipped':skipped_count,'result':'nothing_to_analyze'}
        review_as_of=pipeline.validate_review_as_of(pipeline.now_shanghai())
        pipeline._write_once(snapshot,pipeline.packed(selected))
        info={'input_sha256':source_hash,'sender_uid':sender_uid,'skipped_count':skipped_count,
              'selection_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),'review_as_of':review_as_of}
        pipeline._write_once(binding,pipeline.packed(info))
    analysis=out/'analysis'
    if (analysis/'batch.json').is_file():
        checkpoint=json.loads((analysis/'checkpoint.json').read_text(encoding='utf8'))
        expected_provider=type(provider).__module__+'.'+type(provider).__qualname__
        expected_config=hashlib.sha256(pipeline.packed({'account':account,'samples':samples}).encode('utf8')).hexdigest()
        if (checkpoint.get('input_sha256')!=pipeline.digest(snapshot) or checkpoint.get('version')!=pipeline.VERSION or
            checkpoint.get('instruction_sha256')!=hashlib.sha256(pipeline.SYSTEM.encode('utf8')).hexdigest() or
            checkpoint.get('account_and_style_sha256')!=expected_config or checkpoint.get('sender_uid')!=sender_uid or
            checkpoint.get('review_as_of')!=review_as_of or
            checkpoint.get('provider')!=expected_provider or checkpoint.get('model')!=getattr(provider,'model',expected_provider) or
            checkpoint.get('settings')!=getattr(provider,'settings',{})):
            raise WorkflowError('旧分析与当前模型、规则或账号不一致')
    else:
        pipeline.create_batch(snapshot,analysis,sender_uid,account,samples,provider,review_as_of=review_as_of)
    batch=json.loads((analysis/'batch.json').read_text(encoding='utf8'))
    analysis_record=json.loads((analysis/'analysis.json').read_text(encoding='utf8'))
    if batch.get('review_as_of')!=review_as_of or analysis_record.get('review_as_of')!=review_as_of:
        raise WorkflowError('分析结果的冻结时间与当前批次不一致')
    if batch['count']:
        send(analysis/'batch.json',analysis/'source-manifest.json')
    return {'selected':batch['count'],'skipped':skipped_count,'result':'sender_invoked' if batch['count'] else 'no_qualified_drafts'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('input','output','ledger','sender-uid','account','style','project-root','session-home'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--provider',choices=('codex','deepseek'),default='codex')
    p.add_argument('--model')
    p.add_argument('--interval',type=float,default=1.0)
    p.add_argument('--execute',action='store_true')
    args=p.parse_args()
    if not args.execute:raise WorkflowError('没有显式启动；未访问模型或平台')
    if args.interval<1:raise WorkflowError('发送间隔不能低于1秒')
    account=json.loads(Path(args.account).read_text(encoding='utf-8-sig'))
    samples=json.loads(Path(args.style).read_text(encoding='utf-8-sig'))
    if args.provider=='codex':
        provider=pipeline.CodexProvider(args.model or 'gpt-6.1-sol')
    else:
        secret=os.environ.get('DEEPSEEK_API_KEY','')
        if not secret:raise WorkflowError('未配置 DeepSeek 密钥，未开始 AI 分析或发送')
        provider=pipeline.DeepSeekProvider(secret,args.model or 'deepseek-flash')
    root=Path(args.project_root).resolve(strict=True)
    cli=root/'work'/'xhs-cli-standalone-entry'/'standalone_cli.py'
    if not cli.is_file():raise WorkflowError('未找到现有独立发送 CLI')
    def send(batch,manifest):
        command=[sys.executable,'-X','utf8',str(cli),'--project-root',str(root),'--ledger',str(Path(args.ledger).resolve()),
          '--batch',str(batch),'--source-manifest',str(manifest),'--session-home',args.session_home,
          '--sender-uid',args.sender_uid,'--interval',str(args.interval),'--execute','run']
        proc=subprocess.run(command,check=False)
        if proc.returncode!=0:raise WorkflowError('发送程序已停止；请看账本状态，不要自动重试')
    result=run_workflow(input_path=args.input,output_dir=args.output,ledger=args.ledger,sender_uid=args.sender_uid,
                        account=account,samples=samples,provider=provider,send=send,execute=True)
    print(pipeline.packed(result))


if __name__=='__main__':
    try:main()
    except (WorkflowError,pipeline.InvalidInput,pipeline.InvalidResult,pipeline.ProviderError,OSError,ValueError,sqlite3.Error) as exc:
        print('停止：'+str(exc),file=sys.stderr);sys.exit(2)
