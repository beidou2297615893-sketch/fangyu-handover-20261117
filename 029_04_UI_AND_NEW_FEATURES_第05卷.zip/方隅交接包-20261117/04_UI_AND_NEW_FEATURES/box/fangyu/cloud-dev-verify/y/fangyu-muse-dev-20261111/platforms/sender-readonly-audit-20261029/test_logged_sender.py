import unittest,sys,importlib.util,tempfile,sqlite3,json,time
from pathlib import Path
from contextlib import closing
from types import SimpleNamespace
from unittest.mock import patch
from logged_sender_candidate import attach
from journal_hooks_candidate import JournalFailure
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'xhs-local-ledger-sender-candidate'));sys.path.insert(0,str(ROOT/'xhs-standalone-reply'))
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
project=load('project_log_test',ROOT/'xhs-recording-audit/project_send_log.py')
class Client:
 def __init__(self,p,result=None,error=None):self.plan=p;self.result=result;self.error=error;self.calls=0;self._armed=False
 def identity(self):pass
 def send_once(self):
  self.calls+=1
  if self.error:raise self.error
  return self.result
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent);self.root=Path(self.tmp.name);self.db=self.root/'synthetic.sqlite3';self.log=self.root/'events.txt'
  self.s=load('sender_isolated_'+str(id(self)),ROOT/'xhs-cli-standalone-entry/backend/xhs-local-ledger-sender-candidate/production_sender.py');self.s.ROOT=self.root
  # Use existing schema, no production DB opens.
  import subprocess
  subprocess.run([sys.executable,str(ROOT/'shared-acquisition-ledger/ledger.py'),'--db',str(self.db),'init'],capture_output=True,check=True)
  with closing(sqlite3.connect(self.db)) as c:
   c.execute('create table local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token))')
   c.execute("insert into leads(platform,customer,comment,status,source) values('xiaohongshu','c','comment','unverified','fixture')")
   c.commit()
  self.plan=self.s.SendPlan('sender','uid','note','comment','reply','attempt',True,'fixture',int(time.time())+200,'fixture','c')
 def tearDown(self):self.tmp.cleanup()
 def run_client(self,client):return self.s.Runner(self.db,client,synthetic=True).submit(self.plan)
 def events(self):return [json.loads(x) for x in self.log.read_text('utf8').splitlines()]
 def test_success_records_reserve_and_receipt(self):
  attach(self.s,self.db,self.log,project.sync);cl=Client(self.plan,{'comment':{'id':'receipt'}})
  self.assertEqual(self.run_client(cl),'receipt_received_unverified');self.assertEqual(cl.calls,1);self.assertEqual(len(self.events()),2)
 def test_unknown_records_and_still_blocks_retry(self):
  attach(self.s,self.db,self.log,project.sync);cl=Client(self.plan,error=TimeoutError())
  with self.assertRaises(self.s.Unknown):self.run_client(cl)
  self.assertEqual(cl.calls,1);self.assertEqual(len(self.events()),2)
  other=Client(self.plan)
  with self.assertRaises(self.s.Refused):self.run_client(other)
  self.assertEqual(other.calls,0)
 def test_missing_receipt_stays_unknown(self):
  attach(self.s,self.db,self.log,project.sync)
  with self.assertRaises(self.s.Unknown):self.run_client(Client(self.plan,{}))
  self.assertIn('未知',self.events()[-1]['状态'])
 def test_projection_failure_after_reserve_zero_post(self):
  n=[0]
  def sync(*a):
   n[0]+=1
   if n[0]>1:raise OSError()
   return project.sync(*a)
  attach(self.s,self.db,self.log,sync);cl=Client(self.plan)
  with self.assertRaises(JournalFailure):self.run_client(cl)
  self.assertEqual(cl.calls,0)
  project.sync(self.db,self.log);self.assertEqual(len(self.events()),1)
 def test_crash_committed_reservation_recovered_no_retry(self):
  self.s._reserve(self.db,self.plan,True)
  attach(self.s,self.db,self.log,project.sync);self.assertEqual(len(self.events()),1)
  cl=Client(self.plan)
  with self.assertRaises(self.s.Refused):self.run_client(cl)
  self.assertEqual(cl.calls,0)
 def test_user_stop_before_reserve(self):
  attach(self.s,self.db,self.log,project.sync,lambda:True);cl=Client(self.plan)
  with self.assertRaises(JournalFailure):self.run_client(cl)
  self.assertEqual(cl.calls,0)
 def test_user_stop_after_reserve(self):
  n=[0]
  def stop():n[0]+=1;return n[0]>1
  attach(self.s,self.db,self.log,project.sync,stop);cl=Client(self.plan)
  with self.assertRaises(JournalFailure):self.run_client(cl)
  self.assertEqual(cl.calls,0);self.assertEqual(len(self.events()),1)
 def test_outcome_log_failure_stops_and_recovers(self):
  n=[0]
  def sync(*a):
   n[0]+=1
   if n[0]>=3:raise OSError()
   return project.sync(*a)
  attach(self.s,self.db,self.log,sync);cl=Client(self.plan,{'comment':{'id':'receipt'}})
  with self.assertRaises(self.s.Unknown):self.run_client(cl)
  self.assertEqual(cl.calls,1);project.sync(self.db,self.log);self.assertEqual(len(self.events()),2)
 def test_stop_at_post_wire_zero_http(self):
  attach(self.s,self.db,self.log,project.sync,lambda:True)
  # No client construction and no HTTP: wrapper must reject before original wire.
  with self.assertRaises(self.s.Refused):
   self.s.OneAttemptClient._request_with_retry(object(),'POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post')
if __name__=='__main__':unittest.main()


