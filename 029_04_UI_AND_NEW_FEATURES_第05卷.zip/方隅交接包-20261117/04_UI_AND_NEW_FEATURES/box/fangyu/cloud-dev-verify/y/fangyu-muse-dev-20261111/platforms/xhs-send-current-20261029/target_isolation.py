"""User-authorized frozen batch with durable per-target business-error isolation."""
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import scoped_isolation as scope

HISTORICAL_SOURCE_SHA = 'a99c45c42b9118fef4056bc698a3e012ac30883328c032413d46d37340d87a23'
HELD4_SOURCE_SHA = 'f2d7bc983d6b6c02d1761fabde14cdb28b109b9bffebb9fb6db439a745a987f2'
HELD4_NOTES = frozenset(('fresh_authoritative_dedup_required','current_need_unknown','platform_thread_not_checked'))


def reviewed_historical_entry(entry, source_sha):
    holds=entry.get('hold_reasons')
    if not isinstance(holds,list) or any(not isinstance(item,str) for item in holds):return False
    allowed=HELD4_NOTES if source_sha==HELD4_SOURCE_SHA else frozenset()
    return (set(holds)<=allowed and entry.get('semantic_invalid') is not True and
        entry.get('fact_assertion_unverified') is not True and entry.get('current_need_confirmed') is False and
        entry.get('actual_housing_facts_verified') is False and entry.get('review_notes_not_cleared') is True and
        entry.get('factual_scope')=='offer_to_check_not_assertion_of_inventory_price_location_or_appointment')


def complete_business_rejection(data):
    return (isinstance(data, dict) and type(data.get('http_status')) is int and data['http_status'] == 200 and
        data.get('success') is False and type(data.get('api_code')) is int and
        data.get('verification_header_present') is False and data.get('endpoint') == 'comment_post' and
        data.get('request_started') is True and not scope.known_restriction(data))


def plan_matches(row, plan, sender_uid):
    return (plan.get('sender_uid') == sender_uid and all(row.get(k) == plan.get(f) for k,f in (
        ('attempt_id','attempt_id'),('customer_id','canonical_customer'),('customer_uid','customer_uid'),
        ('comment_id','comment_id'),('note_id','note_id'),('text','text'))))


@dataclass(frozen=True)
class AuthorizedTargetIsolationPolicy:
    schema: str
    policy_id: str
    sender_uid: str
    original_batch_path: str
    original_batch_sha256: str
    batch_sha256: str
    batch_count: int
    tone_approval_path: str
    tone_approval_sha256: str
    history_manifest_path: str
    history_manifest_sha256: str
    platform_state_path: str
    platform_state_sha256: str
    halt_marker_path: str
    halt_marker_sha256: str
    acknowledged_revocations: list
    authorization_path: str
    authorization_sha256: str
    historical_age_override: dict | None = None

    @classmethod
    def from_mapping(cls, value):
        required=set(cls.__dataclass_fields__)-{'historical_age_override'}
        if (not isinstance(value,dict) or not required <= set(value) or not set(value) <= set(cls.__dataclass_fields__) or
            type(value.get('batch_count')) is not int or not 1 <= value['batch_count'] <= 567 or
            not isinstance(value.get('acknowledged_revocations'),list) or
            (value.get('historical_age_override') is not None and not isinstance(value['historical_age_override'],dict)) or
            any(not isinstance(v,str) or not v for k,v in value.items() if k not in ('batch_count','acknowledged_revocations','historical_age_override'))):
            raise scope.ScopeRefused('target_isolation_schema_invalid')
        return cls(**value)

    def allows_historical_age(self, row, meta, *, batch_path):
        """Only waive this reviewed source's age hold; never assert current need."""
        try:
            override=self.historical_age_override
            if (not isinstance(override,dict) or set(override)!={'source_path','source_sha256'} or
                override.get('source_sha256') not in (HISTORICAL_SOURCE_SHA,HELD4_SOURCE_SHA)):return False
            source_sha=override['source_sha256']
            authorization=scope.checked_json(self.authorization_path,self.authorization_sha256)
            if (authorization.get('sender_uid')!=self.sender_uid or authorization.get('source')!='user_direct_current_turn' or
                authorization.get('send_all_authorized') is not True or authorization.get('historical_over_60_days_authorized') is not True or
                authorization.get('historical_priority')!='after_recent_batches' or
                authorization.get('historical_source_sha256')!=source_sha):return False
            rows,_=self.validate_context(batch_path,self.sender_uid)
            if len([entry for entry in rows if entry==row])!=1:return False
            path=Path(override['source_path'])
            if not path.is_absolute() or path.is_symlink():return False
            raw=path.read_bytes()
            if hashlib.sha256(raw).hexdigest()!=source_sha:return False
            candidates=[json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
            matches=[entry for entry in candidates if entry.get('comment_id')==row['comment_id']]
            if len(matches)!=1:return False
            entry=matches[0]
            if not reviewed_historical_entry(entry,source_sha):return False
            return (all(entry.get(k)==row.get(k) for k in ('customer_id','customer_uid','comment_id','note_id','text')) and
                entry.get('original_comment')==meta.get('original_comment') and entry.get('post_title')==meta.get('post_title') and
                entry.get('published_at')==meta.get('published_at'))
        except (scope.ScopeRefused,OSError,ValueError,TypeError,KeyError,AttributeError):return False

    def validate_context(self, batch_path, sender_uid):
        if Path(__file__).with_name("retired-historical-scopes.json").exists():
            raise scope.ScopeRefused("historical_scope_retired_after_retention_cleanup")
        if (sender_uid != scope.SCOPED_UID or self.sender_uid != sender_uid or
            self.schema != 'xhs-authorized-target-isolation-batch-v1' or self.original_batch_sha256 != scope.APPROVED_SHA):
            raise scope.ScopeRefused('target_isolation_binding_invalid')
        authorization=scope.checked_json(self.authorization_path,self.authorization_sha256)
        if (authorization.get('sender_uid') != sender_uid or authorization.get('source') != 'user_direct_current_turn' or
            not authorization.get('user_instruction')):
            raise scope.ScopeRefused('target_isolation_authorization_missing')
        original=scope.checked_json(self.original_batch_path,self.original_batch_sha256)
        batch=scope.checked_json(batch_path,self.batch_sha256)
        approval=scope.checked_json(self.tone_approval_path,self.tone_approval_sha256)
        if (original.get('count') != 567 or len(original.get('rows',[])) != 567 or
            batch.get('schema') != 'xhs-local-plan-v1' or batch.get('intended_account_uid') != sender_uid or
            batch.get('count') != self.batch_count or len(batch.get('rows',[])) != self.batch_count or
            approval.get('schema') != 'xhs-approved-tone-entry-v1' or len(approval.get('entries',[])) != self.batch_count):
            raise scope.ScopeRefused('target_isolation_batch_invalid')
        def index(rows):
            result={r['comment_id']:r for r in rows}
            if len(result) != len(rows):raise scope.ScopeRefused('target_isolation_duplicate_target')
            return result
        originals=index(original['rows']);tones=index(approval['entries']);targets=index(batch['rows'])
        if set(tones) != set(targets) or len({r['customer_uid'] for r in batch['rows']}) != self.batch_count:
            raise scope.ScopeRefused('target_isolation_target_set_changed')
        files,hashes=approval.get('source_files',[]),approval.get('source_hashes',[])
        if not files or len(files) != len(hashes):raise scope.ScopeRefused('target_isolation_candidates_missing')
        candidates={}
        for path,sha in zip(files,hashes):
            raw=Path(path).read_bytes()
            if hashlib.sha256(raw).hexdigest() != sha:raise scope.ScopeRefused('target_isolation_candidates_changed')
            for line in raw.decode('utf-8-sig').splitlines():
                if not line.strip():continue
                item=json.loads(line);key=item['comment_id']
                if sha==HELD4_SOURCE_SHA and not reviewed_historical_entry(item,sha):
                    raise scope.ScopeRefused('target_isolation_reviewed_source_hold_invalid')
                if key in candidates and any(item.get(k) != candidates[key].get(k) for k in ('customer_id','customer_uid','note_id','text')):
                    raise scope.ScopeRefused('target_isolation_candidate_conflict')
                candidates[key]=item
        for key,target in targets.items():
            if key not in originals or key not in candidates:raise scope.ScopeRefused('target_isolation_outside_source')
            if any(target.get(k) != originals[key].get(k) for k in ('customer_id','customer_uid','comment_id','note_id')):
                raise scope.ScopeRefused('target_isolation_identity_changed')
            if any(target.get(k) != source.get(k) for source in (tones[key],candidates[key]) for k in ('customer_id','customer_uid','comment_id','note_id','text')):
                raise scope.ScopeRefused('target_isolation_text_changed')
        history=scope.checked_json(self.history_manifest_path,self.history_manifest_sha256);entries=history.get('entries',[])
        accepted=authorization.get('known_prior_receipts');unknown=authorization.get('known_prior_unknowns')
        if (type(accepted) is not int or type(unknown) is not int or accepted < 0 or unknown < 0 or
            history.get('sender_uid') != sender_uid or len(entries) != accepted+unknown or
            len({e['attempt_id'] for e in entries}) != len(entries) or
            sum(e.get('state') == 'accepted' for e in entries) != accepted or sum(e.get('state') == 'unknown' for e in entries) != unknown):
            raise scope.ScopeRefused('target_isolation_history_invalid')
        chain=[{'path':self.halt_marker_path,'sha256':self.halt_marker_sha256}]+self.acknowledged_revocations
        if len(chain)>65:raise scope.ScopeRefused('target_isolation_revocation_chain_invalid')
        previous=None
        for ref in chain:
            if previous is not None and Path(ref['path']).resolve() != scope.revocation_path(previous).resolve():
                raise scope.ScopeRefused('target_isolation_revocation_chain_invalid')
            state=scope.checked_json(ref['path'],ref['sha256'])
            if state.get('sender_uid') != sender_uid or scope.known_restriction(state):raise scope.ScopeRefused('target_isolation_known_restriction')
            previous=ref['path']
        next_marker=scope.revocation_path(previous)
        if next_marker.exists() or next_marker.is_symlink():raise scope.ScopeRefused('target_isolation_new_platform_halt')
        state=scope.checked_json(self.platform_state_path,self.platform_state_sha256)
        if (state.get('sender_uid') != sender_uid or state.get('state') != 'unknown_requires_reconciliation' or scope.known_restriction(state)):
            raise scope.ScopeRefused('target_isolation_known_restriction')
        for key,expected in (('original_batch',self.original_batch_sha256),('tone_approval',self.tone_approval_sha256),('exclusions',self.history_manifest_sha256)):
            if batch.get('source_sha256',{}).get(key) != expected:raise scope.ScopeRefused('target_isolation_sources_changed')
        return batch['rows'],entries

    def validate_ledger(self,db,plan,batch_path):
        try:
            rows,entries=self.validate_context(batch_path,plan.sender_uid)
            targets=[r for r in rows if r['attempt_id'] == plan.attempt_id]
            if len(targets)!=1 or not plan_matches(targets[0],vars(plan),self.sender_uid):return False
            for entry in entries:
                row=db.execute('SELECT r.status,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token WHERE r.token=? AND r.platform=?',(entry['attempt_id'],'xiaohongshu')).fetchone()
                if not row or hashlib.sha256(row['data'].encode()).hexdigest()!=entry['record_raw_sha256']:return False
                data=json.loads(row['data']);p=data.get('plan',{});result=data.get('result',{})
                if p.get('sender_uid')!=self.sender_uid or p.get('customer_uid')!=entry['customer_uid'] or p.get('comment_id')!=entry['comment_id']:return False
                if entry['state']=='accepted':
                    if row['status'] not in ('unknown','sent') or result.get('kind')!='platform_receipt' or not entry.get('receipt_id') or result.get('receipt_id')!=entry['receipt_id']:return False
                elif row['status']!='unknown' or result.get('kind')!='unknown' or scope.known_restriction(result):return False
            return True
        except (scope.ScopeRefused,OSError,ValueError,TypeError,KeyError,AttributeError):return False

    def permits(self,plan,old_row,batch_path,*,db=None):
        if db is None or old_row['status']!='unknown' or not self.validate_ledger(db,plan,batch_path):return False
        try:
            rows,entries=self.validate_context(batch_path,plan.sender_uid)
            old=json.loads(old_row['data'])
            historic=[e for e in entries if e['attempt_id']==old_row['token'] and e['state']=='unknown']
            if historic:return hashlib.sha256(old_row['data'].encode()).hexdigest()==historic[0]['record_raw_sha256']
            targets=[r for r in rows if r['attempt_id']==old_row['token']]
            return (len(targets)==1 and plan_matches(targets[0],old.get('plan',{}),self.sender_uid) and
                old.get('result',{}).get('kind')=='unknown' and complete_business_rejection(old['result']))
        except (scope.ScopeRefused,OSError,ValueError,TypeError,KeyError,AttributeError):return False
