"""Passive QR observer; no navigation, polling, cookies, or platform calls."""
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

import qrcode

CREATE_PATH = '/api/sns/web/v1/login/qrcode/create'
HOSTS = {'www.xiaohongshu.com', 'edith.xiaohongshu.com'}


class QrDisplayObserver:
    def __init__(self, directory, on_update=None):
        self.directory = Path(directory).resolve(strict=True)
        if not self.directory.is_dir() or (self.directory / 'status.json').exists():
            raise ValueError('fresh_display_directory_required')
        self.on_update = on_update
        self.notification_failed = False
        self._digest = None  # Only in memory, never written to the record.
        self.state = {'status': 'unavailable', 'generation': 0, 'image': None, 'previous': []}

    def attach(self, page):
        page.on('response', self.handle_response)

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    def _publish(self):
        path = self.directory / 'status.json'
        tmp = self.directory / 'status.json.tmp'
        with tmp.open('w', encoding='utf8') as stream:
            json.dump(self.state, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
        if self.on_update is not None:
            try:
                self.on_update(deepcopy(self.state))
            except Exception:
                self.notification_failed = True  # Never log exception text.

    def _retire_current(self, status):
        if self.state['image'] is not None:
            self.state['previous'].append({'generation': self.state['generation'],
                'image': self.state['image'], 'status': status, 'changed_at': self._now()})
        self.state['image'] = None
        self._digest = None

    def invalidate(self, status):
        if status not in {'expired', 'unavailable', 'platform_verification_required', 'finished'}:
            raise ValueError('invalid_status')
        self._retire_current(status)
        self.state['status'] = status
        self.state['updated_at'] = self._now()
        self._publish()

    def mark_expired(self):
        # Only call when the page or platform explicitly shows expiry.
        self.invalidate('expired')

    def handle_response(self, response):
        try:
            parsed = urlsplit(response.url)
            if (parsed.scheme != 'https' or parsed.hostname not in HOSTS or parsed.port not in (None, 443)
                    or parsed.path != CREATE_PATH or response.request.method != 'POST'):
                return
        except Exception:
            return
        try:
            if response.status in (461, 471):
                self.invalidate('platform_verification_required')
                return
            if response.status != 200:
                self.invalidate('unavailable')
                return
            payload = response.json()
            if not isinstance(payload, dict) or payload.get('success') is False:
                self.invalidate('unavailable')
                return
            payload = payload.get('data', payload)
            value = payload.get('url') if isinstance(payload, dict) else None
            if not isinstance(value, str) or not value.strip() or len(value) > 4096:
                self.invalidate('unavailable')
                return
            digest = sha256(value.encode('utf8')).digest()
            if digest == self._digest and self.state['image'] is not None:
                return
            next_number = self.state['generation'] + 1
            filename = f'qr-{next_number:04d}.png'
            dest = self.directory / filename
            temp = self.directory / (filename + '.tmp')
            if dest.exists() or temp.exists():
                self.invalidate('unavailable')
                return
            with temp.open('xb') as stream:
                qrcode.make(value).save(stream, format='PNG')
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, dest)
            self._retire_current('superseded')
            self._digest = digest
            self.state.update(status='awaiting_scan', generation=next_number,
                              image=filename, updated_at=self._now())
            self._publish()
        except Exception:
            # Exception text may contain a QR URL, response body or credentials.
            try:
                self.invalidate('unavailable')
            except Exception:
                self._retire_current('unavailable')
                self.state['status'] = 'unavailable'
