import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const S='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview';
const H=path.dirname(fileURLToPath(import.meta.url));
const mode=process.argv.includes('--expect-fixed')?'fixed':'baseline';
const read=f=>fs.readFileSync(path.join(S,f),'utf8');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const source=read('pages/reply-connected.mjs');
const calls=[];
const sandbox={console,URL,Date,JSON,Promise,Set,Map,queueMicrotask,crypto:{randomUUID:()=> 'synthetic-operation'},
  customerAvatar:()=>'<img alt="">',postCover:()=>'<img alt="">',bindCustomerAvatars:()=>{},warmCustomerMedia:()=>{},
  renderDelivery:()=>'',bindDelivery:()=>{},prepareReviewed:()=>{calls.push('prepareReviewed');},renderBatch:()=>'',bindBatch:()=>{},
  workflowScope:()=> 'synthetic-scope',assessmentLabel:()=>'',evidenceSummary:()=>'',personaChoices:{employee:'员工',customer:'客户'}};
vm.createContext(sandbox);
const executable=source.replace(/^import\s.*?;\s*$/gm,'').replace(/^export\s+/gm,'');
vm.runInContext(executable+'\nglobalThis.tested={renderConnected,selectCustomer,mutate};',sandbox,{filename:'actual-reply-connected.mjs'});
const state={connection:'connected',session:{},page:'reply',user:'synthetic-employee',storeId:'synthetic-store',authEpoch:1,activePlatform:'xiaohongshu'};
const a={id:'customer_a',name:'A',postTitle:'POST_A',quote:'COMMENT_A',platform:'xiaohongshu',accounts:[]};
const b={id:'customer_b',name:'B',postTitle:'PREVIEW_POST_B',quote:'PREVIEW_COMMENT_B',platform:'xiaohongshu',accounts:[],publishedAt:'2026-10-19'};
state.replyLive={actor:'1|synthetic-employee|synthetic-store|xiaohongshu',status:'ready',items:[a,b],stats:{total:2,replied:0},tab:'pending',groupBy:'post',query:'',page:1,pages:1,total:2,generation:0,selectedId:'customer_a',leadId:'lead_a',text:'PREVIOUS_DRAFT_A',accountId:'account_a',busy:false,pending:null,error:'',detail:{item:a,comments:[{id:'lead_a',text:'COMMENT_A',postTitle:'POST_A',accounts:[],canSave:true,draft:{text:'PREVIOUS_DRAFT_A'}}]},collapsedGroups:[],intent:'all',checkedIds:[]};
const ctx={state,update:fn=>fn(state),replyRead:()=>new Promise(()=>{}),replyError:()=>{},replySave:()=>{calls.push('replySave');throw Error('No writes permitted');},replyReview:()=>{calls.push('replyReview');throw Error('No writes permitted');}};
void sandbox.tested.selectCustomer(state,ctx,state.replyLive,'customer_b');
const html=sandbox.tested.renderConnected(state),editor=html.match(/<aside\b[^>]*class="rp-editor"[^>]*>([\s\S]*?)<\/aside>/)?.[1]||'';
const previewVisible=editor.includes('PREVIEW_COMMENT_B')&&editor.includes('PREVIEW_POST_B');
let mutationOutcome;
try{mutationOutcome=await sandbox.tested.mutate(state,ctx,state.replyLive,false);}catch(error){mutationOutcome=error.message;}
const noPreviewWrite=calls.length===0;
const cssFiles=['styles.css','pages/reply.css','canvas-fit.css','redesign.css'];
const rules=[];
for(const file of cssFiles){const css=read(file);for(const match of css.matchAll(/([^{}]+)\{([^{}]+)\}/g)){const selectors=match[1].trim();const decl={};for(const part of match[2].split(';')){const cut=part.indexOf(':');if(cut>0)decl[part.slice(0,cut).trim()]=part.slice(cut+1).trim();}rules.push({file,selectors,decl});}}
function specificity(selector){
  const base=sel=>(sel.match(/#[\w-]+/g)||[]).length*100+(sel.match(/\.[\w-]+|\[[^\]]+\]|:(?!:)[\w-]+/g)||[]).length*10+(sel.match(/(?:^|\s|>)(?:strong|textarea|p)(?:\b|$)/g)||[]).length;
  let extra=0;const plain=selector.replace(/:is\(([^)]+)\)/g,(_,choices)=>{extra+=Math.max(...choices.split(',').map(base));return '';});
  return base(plain)+extra;
}
function valueFor(target,property,{platform='xiaohongshu',inline}={}){
  let winner=inline?{value:inline,important:0,score:1000}:null;
  for(const rule of rules){
    for(const selector of rule.selectors.split(/,(?![^()]*\))/)){
      const sel=selector.trim();if(!sel.includes(target))continue;
      if(sel.includes('[data-platform=douyin]')&&platform!=='douyin')continue;
      if(sel.includes('[data-platform=xiaohongshu]')&&platform!=='xiaohongshu')continue;
      if(target==='.rp-empty'&&/\.rp-empty\s+(?:strong|span)/.test(sel))continue;
      const raw=rule.decl[property];if(!raw)continue;
      const important=raw.includes('!important')?1:0;
      const score=specificity(sel);
      if(!winner||important>winner.important||important===winner.important&&score>=winner.score)winner={value:raw.replace(/!important/g,'').trim(),important,score,file:rule.file,selector:sel};
    }
  }return winner;
}
const postFont=valueFor('.rp-selected-source strong','font-size',{inline:'16px'});
const draftFont=valueFor('.rp-composer textarea','font-size');
const emptyBackground=valueFor('.rp-empty','background',{platform:'douyin'});
const fontHierarchy=parseFloat(postFont?.value)>parseFloat(draftFont?.value)&&parseFloat(postFont?.value)>=18&&parseFloat(draftFont?.value)<=14;
const darkEmpty=Boolean(emptyBackground&&!/255\s*,\s*255\s*,\s*255|#fff\b|#ffffff\b|white\b/.test(emptyBackground.value));
const app=read('app.mjs'),navText=app.slice(app.indexOf('function navigate(page)'),app.indexOf('function toast('));
const task={id:'synthetic-running-task',status:'running'};const navCalls=[];
const navScope={state:{page:'acquire',connection:'connected',session:{},platform:{acquisition:task}},titles:{acquire:[],reply:[],customers:[]},location:{hash:'#acquire'},history:{replaceState:()=>navCalls.push('hash')},render:()=>navCalls.push('render'),window:{scrollTo:()=>{}},backend:new Proxy({},{get:()=>()=>{throw Error('Navigation must not call backend');}})};
vm.createContext(navScope);vm.runInContext(navText+'\nnavigate("reply");navigate("customers");navigate("acquire");',navScope);
const navigationKeepsTask=navScope.state.platform.acquisition===task&&task.status==='running'&&navCalls.filter(x=>x==='render').length===3&&!/pauseAcquisition|cancelAccount|stopAcquisition|acquisition_pause/.test(navText);
const results={mode,previewVisible,noPreviewWrite,fontHierarchy,darkEmpty,navigationKeepsTask,observed:{editorHasLoading:editor.includes('正在读取'),previousDraftVisible:editor.includes('PREVIOUS_DRAFT_A'),postFont,draftFont,emptyBackground,writeCalls:calls,mutationOutcome},source_sha256:{'pages/reply-connected.mjs':hash(source),'app.mjs':hash(app),...Object.fromEntries(cssFiles.map(f=>[f,hash(read(f))]))},platform_requests:0,model_requests:0,UI_operations:0,product_edits:0};
results.status=mode==='baseline'?!previewVisible&&!fontHierarchy&&!darkEmpty&&navigationKeepsTask&&noPreviewWrite?'EXPECTED_BASELINE_REPRODUCED':'BASELINE_CHANGED':previewVisible&&fontHierarchy&&darkEmpty&&navigationKeepsTask&&noPreviewWrite?'PASS_INCREMENTAL_UI':'FAIL';
fs.writeFileSync(path.join(H,mode==='baseline'?'BASELINE.json':'PATCH-RESULT.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results,null,2));
if((mode==='baseline'&&results.status!=='EXPECTED_BASELINE_REPRODUCED')||(mode==='fixed'&&results.status!=='PASS_INCREMENTAL_UI'))process.exitCode=1;
