"""Opt-in independent-account collection adapter; no login or send capability.

Imports have no platform I/O. run_batch owns a single synchronous batch and
never retries. The old collector/register implementations remain untouched.
"""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import sys

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
PINNED = {
    'collector': '108cce376ded3f17634bedc5d3ba2502af52fbf2b106116fba81ee2a7c48590f',
    'register': '7a1296df9711ed5c34764837ca678a4566e2ae833123e4221a9a00a2c1f32cc2',
}
REAL_LEDGER = PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'


class Refused(ValueError):
    pass


def identify(payload):
    """Read only documented identity containers; require explicit boolean guest=False."""
    if not isinstance(payload, dict):
        raise Refused('identity_payload_invalid')
    containers = [payload]
    for key in ('user_info', 'basic_info'):
        if key in payload:
            if not isinstance(payload[key], dict):
                raise Refused('identity_container_invalid')
            containers.append(payload[key])
    uids, guests, names = set(), [], []
    for item in containers:
        for key in ('user_id', 'userid', 'uid'):
            if key in item:
                value = item[key]
                if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', value):
                    raise Refused('identity_uid_invalid')
                uids.add(value)
        if 'guest' in item:
            if type(item['guest']) is not bool:
                raise Refused('identity_guest_invalid')
            guests.append(item['guest'])
        value = item.get('nickname')
        if isinstance(value, str) and value.strip() and len(value) <= 100:
            names.append(value.strip())
    if len(uids) != 1 or not guests or any(guests):
        raise Refused('identity_unverified_guest_or_conflict')
    return {'uid': next(iter(uids)), 'guest': False, 'nickname': names[0] if names else 'unknown',
            'proof_source': 'same_client_user_me', 'verified_at': now()}


def now():
    return datetime.now(timezone.utc).isoformat()


def dependencies():
    """Load exact reviewed local implementations without altering their files."""
    base = PROJECT/'work/xhs-collection-candidate'
    selector=PROJECT/'work/xhs-continuous-runner/runner.py'
    if hashlib.sha256(selector.read_bytes()).hexdigest() != 'd6f4c29842ad55cf08d1fd774f5a302c097b4a2271ce599782d3d4f109fcaac2':
        raise Refused('selector_dependency_changed_review_required')
    for name, digest in PINNED.items():
        if hashlib.sha256((base/(name+'.py')).read_bytes()).hexdigest() != digest:
            raise Refused('dependency_changed_review_required')
    for name in PINNED:
        if name in sys.modules and Path(sys.modules[name].__file__).resolve() != base/(name+'.py'):
            raise Refused('dependency_module_collision')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(base))
    import collector
    import register
    return collector, register


def write_new(path, value):
    """New file only; flush/fsync before a subsequent stage can use it."""
    with path.open('x', encoding='utf8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())


def safe_failure(client, exc):
    """Allow only fixed categories and explicitly typed platform diagnostics."""
    fixed={'account_changed_no_retry','session_changed_no_retry','independent_session_file_changed',
        'identity_payload_invalid','identity_container_invalid','identity_uid_invalid','identity_guest_invalid',
        'identity_unverified_guest_or_conflict','batch_account_binding_changed','search_shape_invalid'}
    category=str(exc) if type(exc) is Refused and str(exc) in fixed else 'request_or_local_stage_failed'
    clean={}
    detail=getattr(client,'last_failure_detail',None)
    if isinstance(detail,dict):
        values={
            'error_type':{'HTTPError','Timeout','NetworkError','ReadFailure','XhsApiError','NeedVerifyError','SessionExpiredError','IpBlockedError','SignatureError','OtherPlatformError'},
            'stage':{'identity','search','comments','unknown'},
            'endpoint':{'identity','prewarm_onebox','prewarm_filter','search_notes','recommend','comments','unknown'},
        }
        for key,allowed in values.items():
            if isinstance(detail.get(key),str) and detail[key] in allowed: clean[key]=detail[key]
        for key,low,high in (('http_status',100,599),('api_code',-1000000000,1000000000)):
            if type(detail.get(key)) is int and low<=detail[key]<=high: clean[key]=detail[key]
        if type(detail.get('request_started')) is bool: clean['request_started']=detail['request_started']
    return {'category':category,'platform':clean,'retry_allowed':False}


def run_batch(*, workspace, batch_name, client, ledger, source_db, keyword,
              search_page, task, operator=None, known_notes=None, identity_loader=None,
              max_notes=10, max_pages=2, allow_real_ledger=False,known_comments=None):
    """Bind same client across collection/registration; all outputs stay in candidate.

    identity_loader is an injectable read-only local source adapter for offline
    fixtures. Production callers omit it. The shared-ledger exception is exact,
    opt-in, and still uses the original global lock and registration transaction.
    """
    workspace = Path(workspace).resolve(strict=True)
    runtime = (HERE/'runtime').resolve(strict=True)
    if workspace == runtime or not workspace.is_relative_to(runtime):
        raise Refused('dedicated_candidate_workspace_required')
    if not isinstance(batch_name, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', batch_name):
        raise Refused('new_safe_batch_name_required')
    batch = workspace/batch_name
    if batch.exists():
        raise Refused('existing_batch_no_retry')
    ledger = Path(ledger).resolve(strict=True)
    source_db = Path(source_db).resolve(strict=True)
    real = ledger == REAL_LEDGER.resolve()
    if (not ledger.is_relative_to(workspace) and not (allow_real_ledger is True and real)) or source_db == ledger:
        raise Refused('ledger_outside_candidate_requires_explicit_shared_ledger_opt_in')
    for text in (keyword, task):
        if not isinstance(text,str) or not text.strip() or len(text)>500:
            raise Refused('task_or_keyword_invalid')
    if operator is not None and (not isinstance(operator,str) or not operator.strip() or len(operator)>100):
        raise Refused('operator_invalid')
    if type(search_page) is not int or not 1<=search_page<=100 or any(type(x) is not int or not 1<=x<=20 for x in (max_notes,max_pages)):
        raise Refused('bounded_range_required')
    collector, register = dependencies()
    lock = ledger.parent/'.xhs-collection-runner.lock' if real else workspace/'.account-switch.lock'
    try:
        lock.mkdir()
    except FileExistsError:
        raise Refused('collection_lock_busy_no_retry') from None
    account = None
    registration_started = False
    # This client was created from one independent cookie snapshot. A later
    # login/file replacement must never silently change the batch's account.
    cookie_snapshot=dict(getattr(client,'cookies',{}))
    def unchanged_session():
        if dict(getattr(client,'cookies',{})) != cookie_snapshot:
            raise Refused('session_changed_no_retry')
        check=getattr(client,'_independent_session_guard',None)
        if check is not None: check()
    try:
        write_new(lock/'owner.json', {'pid':os.getpid(),'entry':'account-switch-candidate','started_at':now()})
        batch.mkdir(exist_ok=False)
        def event(status, **extra):
            record = {'at':now(), 'status':status, 'account':account, 'operator':operator or 'unknown',
                'task':task, 'keyword':keyword, 'search_page':search_page, 'batch':batch_name,
                'rule_source':'user_any_verified_login_account_2026-10-29', **extra}
            with (batch/'account-audit.jsonl').open('a',encoding='utf8') as stream:
                stream.write(json.dumps(record,ensure_ascii=False)+'\n')
                stream.flush(); os.fsync(stream.fileno())
        def current(expected=None):
            # Never log upstream exception text or response bodies.
            unchanged_session()
            info = identify(client.get_self_info())
            unchanged_session()
            if expected is not None and info['uid'] != expected:
                raise Refused('account_changed_no_retry')
            return info
        event('identity_check_started')
        account = current()
        write_new(batch/'account-binding.json', account)
        event('account_bound')
        loader = identity_loader or collector.load_identity_map
        identity_map = collector.merge_ledger_identity_map(loader(source_db, account['uid']),ledger)
        with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
            seen_comments={r[0] for r in db.execute("SELECT comment FROM leads WHERE platform='xiaohongshu'")}
        seen_comments.update(known_comments or ())
        note_history=set(known_notes or ())
        attempts=[]
        stats={'skipped_notes':0,'duplicate_comments':0}
        class BoundClient:
            # No send, login, cookie, browser, or generic request interface.
            def get_self_info(self):
                # The unchanged original collector expects a preflight here.
                # Supply this batch's already-live-verified same-client binding,
                # with local snapshot checks, not another platform request.
                unchanged_session()
                return {'user_id':account['uid'],'guest':False}
            def search_notes(self, **kwargs):
                unchanged_session()
                value=client.search_notes(**kwargs)
                unchanged_session()
                if not isinstance(value,dict) or not isinstance(value.get('items'),list):
                    raise Refused('search_shape_invalid')
                items=[]
                for raw in value['items']:
                    parsed=collector.note_items({'items':[raw]},1)
                    if parsed and parsed[0]['note_id'] in note_history:
                        stats['skipped_notes']+=1
                    else:
                        items.append(raw)
                return {**value,'items':items}
            def get_comments(self, note_id, **kwargs):
                unchanged_session()
                if not any(x['note_id']==note_id for x in attempts):
                    attempts.append({'note_id':note_id,'account_uid':account['uid'],'at':now()})
                    # Incremental attempts survive later platform failure.
                    with (batch/'attempt-events.jsonl').open('a',encoding='utf8') as stream:
                        stream.write(json.dumps(attempts[-1],ensure_ascii=False)+'\n')
                        stream.flush(); os.fsync(stream.fileno())
                value=client.get_comments(note_id,**kwargs)
                unchanged_session()
                if isinstance(value,dict) and isinstance(value.get('comments'),list):
                    retained=[]
                    for row in value['comments']:
                        cid=row.get('id') if isinstance(row,dict) else None
                        if cid and cid in seen_comments:
                            stats['duplicate_comments']+=1
                        else:
                            retained.append(row)
                            if cid: seen_comments.add(cid)
                    return {**value,'comments':retained}
                return value
        checkpoint_count = 0
        def checkpoint(value):
            nonlocal checkpoint_count
            checkpoint_count += 1
            write_new(batch/f'partial-{checkpoint_count:04d}.json', {**value,'collection_account':account})
        try:
            data=collector.collect(BoundClient(), account['uid'], keyword, identity_map,
                max_notes=max_notes,max_pages=max_pages,search_page=search_page,on_progress=checkpoint)
        finally:
            write_new(batch/'attempted-notes.json',attempts)
            write_new(batch/'dedup-summary.json',stats)
        data['collection_account']=dict(account)
        data['collection_task']={'task':task,'operator':operator or 'unknown','search_page':search_page}
        write_new(batch/'collection.json',data)
        write_new(batch/'ai-input.json',data['customers'])
        event('collection_saved', usable_comments=data['summary']['usable_comments'])
        # Re-read exactly the persisted batch binding, never an unrelated --sender-uid.
        persisted=json.loads((batch/'collection.json').read_text(encoding='utf8'))
        binding=json.loads((batch/'account-binding.json').read_text(encoding='utf8'))
        if persisted.get('collection_account') != binding or binding != account:
            raise Refused('batch_account_binding_changed')
        current(binding['uid'])
        registration_started = True
        event('registration_started', sender_uid=binding['uid'])
        result=register.register(ledger,persisted,identity_map,'collection:'+str(batch/'collection.json'),apply=True)
        write_new(batch/'register-result.json', {'account':binding,'result':result})
        selector_path=PROJECT/'work/xhs-continuous-runner/runner.py'
        spec=importlib.util.spec_from_file_location('account_switch_original_selector',selector_path)
        selector=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(selector)
        selected=selector.select_new(persisted,ledger,batch/'collection.json',result['inserted'])
        write_new(batch/'new-ai-input.json',selected)
        write_new(batch/'registered-ready.json', {'registered':True,'account_uid':binding['uid'],
            'inserted_comments':result['inserted'],'input':'new-ai-input.json'})
        event('registered',sender_uid=binding['uid'],result=result)
        return {'account':binding,'result':result,'batch':str(batch)}
    except Exception as exc:
        # Commit/report ambiguity is never treated as a failed insert or retried.
        if batch.is_dir():
            failure=safe_failure(client,exc)
            if not (batch/'failure-diagnostic.json').exists(): write_new(batch/'failure-diagnostic.json',failure)
            event('registration_outcome_unknown_check_ledger' if registration_started else 'stopped_before_registration',failure=failure)
        raise Refused('registration_outcome_unknown_check_ledger' if registration_started else 'batch_stopped_no_retry') from None
    finally:
        (lock/'owner.json').unlink(missing_ok=True)
        lock.rmdir()
