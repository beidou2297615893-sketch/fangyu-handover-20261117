"""Offline prototype: wait for platform-native manual completion.

No networking, browser launch, cookie handling, retries or automatic solving.
The caller keeps its existing visible official page open. Responses arrive from
the page's existing requests; this module never sends a request.
"""
import time


class ManualVerificationStopped(Exception):
    pass


def await_completion(next_response, *, timeout_s=240, clock=time.monotonic,
                     on_event=lambda event: None):
    """next_response(remaining_ms) supplies ONLY the expected completion route.

    Adapter must filter exact HTTPS official host/path and method. Response has
    status and payload fields; arbitrary URLs, headers and bodies aren't logged.
    User cancellation or unexpected business failures stop rather than retry.
    """
    deadline = clock() + timeout_s
    prompted = False
    while True:
        remaining = deadline - clock()
        if remaining <= 0:
            raise ManualVerificationStopped('manual_verification_timeout')
        try:
            response = next_response(max(1, int(remaining * 1000)))
        except Exception:
            raise ManualVerificationStopped('manual_verification_unavailable') from None
        if response.status in (461, 471):
            if not prompted:
                on_event('请在当前小红书官方页面手动完成安全验证。')
                prompted = True
            continue
        if response.status != 200:
            raise ManualVerificationStopped('completion_http_error')
        payload = response.payload
        if not isinstance(payload, dict) or payload.get('success') is not True:
            raise ManualVerificationStopped('completion_not_confirmed')
        data = payload.get('data')
        if not isinstance(data, dict):
            raise ManualVerificationStopped('completion_payload_invalid')
        on_event('平台已返回完成结果；还需核对登录身份。')
        return data
