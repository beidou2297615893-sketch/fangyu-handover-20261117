import unittest
from prepare_logged_sender import candidate_pending

class CandidateHistoryTests(unittest.TestCase):
    def setUp(self):
        self.row={'customer_id':'canonical','customer_uid':'public','comment_id':'comment','note_id':'note','text':'approved'}
        self.states={'events':[],'token':{},'comment':{},'customer':{},'uid':{}}
    def add(self,state,key='customer'):
        self.states['events'].append({'state':state})
        value={'customer':'canonical','comment':'comment','uid':'public'}[key]
        self.states[key][('xiaohongshu',value)]={0}
    def test_raw_draft_without_attempt_id_can_be_prepared(self):
        self.assertTrue(candidate_pending(self.row,self.states))
    def test_unknown_customer_is_excluded(self):
        self.add('blocked')
        self.assertFalse(candidate_pending(self.row,self.states))
    def test_other_account_known_uid_is_excluded(self):
        self.add('accepted','uid')
        self.assertFalse(candidate_pending(self.row,self.states))
    def test_confirmed_not_sent_is_eligible(self):
        self.add('not_sent','comment')
        self.assertTrue(candidate_pending(self.row,self.states))
    def test_missing_identity_is_excluded(self):
        self.assertFalse(candidate_pending({**self.row,'customer_uid':''},self.states))

if __name__=='__main__':unittest.main()
