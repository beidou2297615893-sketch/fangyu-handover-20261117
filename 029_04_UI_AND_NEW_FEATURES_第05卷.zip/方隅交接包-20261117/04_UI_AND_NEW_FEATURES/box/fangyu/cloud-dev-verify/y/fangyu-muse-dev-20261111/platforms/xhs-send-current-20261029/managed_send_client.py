"""Managed identity cookies on the existing one-attempt reply client.

No platform requests occur on import. The caller supplies the reviewed sender
module, frozen plan and a private, exclusively owned session file. Runner,
reservation protocol, account lock, exact POST guard and result semantics stay
in the original sender. Authentication-cookie changes halt before any POST.
"""
import hashlib
import importlib.util
import json
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
SOURCE=PROJECT/'work/xhs-new-task-session-fix-20261029/managed_session.py'
# Re-reviewed: only additive, redacted HTTP-failure diagnostics changed.
# Reversing that addition reconstructs the previous pinned SHA256 exactly.
SOURCE_SHA256='c056f2bcf346059203bdaedc743e763161bf442ccbf9f0d77a2140ac22436b3e'
if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!=SOURCE_SHA256:
    raise RuntimeError('Reviewed cookie validation dependency changed')
spec=importlib.util.spec_from_file_location('reply_managed_cookie_validation',SOURCE)
managed=importlib.util.module_from_spec(spec);spec.loader.exec_module(managed)
IDENTITY='https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
POST='https://edith.xiaohongshu.com/api/sns/web/v1/comment/post'


def make_client(sender,session_path,plan,*,transport=None,save_writer=None):
    """Return an original OneAttemptClient subclass; no HOME/browser fallback."""
    class ManagedSendClient(sender.OneAttemptClient):
        _updated=managed.ManagedClient._updated
        _cookie_review_stop=managed.ManagedClient._cookie_review_stop
        _identity=managed.ManagedClient._identity

        def __init__(self):
            raw_path=Path(session_path)
            if raw_path.is_symlink() or any(p.is_symlink() for p in raw_path.parents):
                raise sender.Refused('Session link refused')
            self.path=raw_path.resolve(strict=True)
            self._raw_path=raw_path.absolute()
            if not self.path.is_file():raise sender.Refused('Session file required')
            raw=self.path.read_bytes()
            data=json.loads(raw.decode('utf-8-sig'))
            if not isinstance(data,dict) or not all(isinstance(data.get(k),str) and data[k] for k in ('a1','web_session')):
                raise sender.Refused('Session incomplete')
            cookies={k:v for k,v in data.items() if isinstance(v,str)}
            super().__init__(cookies,plan,transport=transport)
            self.expected_uid=plan.sender_uid
            self._digest=hashlib.sha256(raw).digest()
            self._trusted=dict(cookies)
            self._managed_locked=False
            self._managed_identity_verified=False
            self._writer=save_writer or managed.atomic_write
            self.last_managed_stop=None
            self.last_cookie_review=None
            self.managed_request_context={'stage':'unknown','endpoint':'unknown','request_started':False}
            self._http.event_hooks['request'].append(lambda r:self.managed_request_context.update(request_started=True))
            self._http.event_hooks['response'].append(lambda r:self.managed_request_context.update(http_status=r.status_code))

        def _stop(self,reason):
            # All callers use fixed local reason codes. Never preserve headers,
            # cookie values, response body or arbitrary exception text here.
            self.last_managed_stop={'reason':reason,**self.managed_request_context}
            self._managed_locked=True
            raise sender.Refused('Managed session stopped: '+reason)

        def _guard(self):
            if self._managed_locked:raise sender.Refused('Managed session locked')
            try:
                if self._raw_path.is_symlink() or any(p.is_symlink() for p in self._raw_path.parents) or hashlib.sha256(self.path.read_bytes()).digest()!=self._digest:
                    self._stop('external_session_replaced')
            except OSError:self._stop('session_file_unavailable')
            if dict(self.cookies)!=self._trusted:self._stop('external_memory_session_changed')

        def _save_transport_update(self,response):
            # Identity and explicit guest=false are checked against the exact
            # successful response before considering any incoming cookie.
            self._identity(response)
            updated=self._updated(response)
            changed={k for k in set(updated)|set(self.cookies) if updated.get(k)!=self.cookies.get(k)}
            if changed-managed.TRANSPORT_COOKIE_NAMES:
                self._stop('authentication_update_requires_relogin')
            if not changed:return
            self._guard()
            raw=json.dumps({**updated,'saved_at':time.time()},ensure_ascii=False).encode('utf8')
            try:
                self._writer(self.path,raw,self._digest)
                if self.path.read_bytes()!=raw:self._stop('session_save_unknown')
            except Exception:self._stop('session_save_failed_or_unknown')
            self.cookies.clear();self.cookies.update(updated)
            self._trusted=dict(updated)
            self._digest=hashlib.sha256(raw).digest()

        def _request_with_retry(self,method,url,**kwargs):
            self.managed_request_context={'stage':'identity' if url==IDENTITY else 'send',
                'endpoint':'identity' if url==IDENTITY else 'comment_post','request_started':False}
            self._guard()
            try:
                # The original superclass keeps its exact endpoint/payload,
                # authorization lifetime, armed/identity and single-POST checks.
                response=super()._request_with_retry(method,url,**kwargs)
                self._guard()
                if method=='GET' and url==IDENTITY:
                    payload=response.json()
                    if isinstance(payload,dict) and payload.get('success') is True:
                        self._save_transport_update(response)
                        self._managed_identity_verified=True
                    # Failed API envelopes are handled by the original client.
                return response
            except BaseException:
                self._managed_locked=True
                raise

        def identity(self):
            try:
                # _save_transport_update has already required the same UID and
                # explicit non-guest response. Preserve the original flag logic.
                self._managed_identity_verified=False
                self._identity_checked=False
                result=super().identity()
                if self._managed_identity_verified is not True:
                    self._identity_checked=False
                    self._stop('identity_unverified')
                return result
            except BaseException:
                self._managed_locked=True
                raise

    return ManagedSendClient()
