'use strict';
// Each browser expression performs at most one comments request. No writes.
function buildPageCheck(video, target, cursor, includeDetail, timeoutMs=8000) {
 return `(async()=>{
  const video=${JSON.stringify(String(video))},target=${JSON.stringify(String(target))};
  let timer;
  const read=(async()=>{
   let result={detail_status:0,video_present:true};
   if(${JSON.stringify(includeDetail)}){
    const d=await window.__bridge.getDetail(video);
    const id=d.aweme_detail?.aweme_id_str??d.aweme_detail?.aweme_id;
    result={detail_status:d.status_code,video_present:String(id)===video};
    if(d.status_code!==0||!result.video_present)return {...result,no_video_detail:!d.aweme_detail};
   }
   const d=await window.__bridge.getComments(video,${JSON.stringify(cursor)},50);
   if(d.status_code!==0||!Array.isArray(d.comments))return {...result,comments_status:d.status_code,incomplete:true};
   const found=d.comments.some(c=>String(c.cid_str??c.cid)===target&&(c.aweme_id_str==null&&c.aweme_id==null||String(c.aweme_id_str??c.aweme_id)===video));
   const exhausted=d.has_more===0||d.has_more===false;
   return {...result,comments_status:0,target_present:found,has_more:exhausted?0:1,count:d.comments.length,next_cursor:d.cursor};
  })();
  try{return await Promise.race([read,new Promise(resolve=>{timer=setTimeout(()=>resolve({incomplete:true,read_timeout:true}),${Number(timeoutMs)});})]);}
  finally{clearTimeout(timer);}
 })()`;
}

async function readTarget(client,connId,video,target,options={}){
 const started=Date.now(), budget=options.budgetMs??45000;
 let checkpoint=options.checkpoint;
 if(!checkpoint||checkpoint.video!==video||checkpoint.target!==target||Date.now()-checkpoint.at>600000)checkpoint=null;
 let cursor=checkpoint?.cursor??0,count=checkpoint?.count??0,pages=checkpoint?.pages??0;
 const seen=new Set();
 let last={incomplete:true};
 for(let n=0;n<100;n++){
  if(seen.has(String(cursor)))break;
  seen.add(String(cursor));
  const response=await client.call({site:'douyin.com',connId,timeout:12000,
   expression:buildPageCheck(video,target,cursor,n===0)});
  if(!response.ok||response.connection!==connId)throw Error(response.error||'只读分页连接未返回');
  last=response.value||{};
  if(last.read_timeout)return {...last,count,pages};
  if(last.detail_status!==0||!last.video_present||last.comments_status!==0)return last;
  count+=last.count;pages++;
  if(last.target_present||last.has_more===0){options.clearCheckpoint?.();return {...last,count,pages};}
  if(last.next_cursor==null)break;
  cursor=last.next_cursor;
  options.onProgress?.({at:Date.now(),video,target,cursor,count,pages});
  if(Date.now()-started>=budget)return {...last,target_present:undefined,incomplete:true,scan_budget:true,count,pages};
 }
 return {...last,target_present:undefined,incomplete:true,count,pages};
}

// Pure matcher. A hit must be our account, the exact reply text, and under the target comment.
function matchOwnReply(comments, spec) {
 if (!spec || typeof spec.text !== 'string' || !spec.text || !spec.accountUid || !spec.target) return null;
 if (comments && typeof comments === 'object' && !Array.isArray(comments)
     && (comments.cid != null || comments.cid_str != null || typeof comments.text === 'string')) {
  comments = [comments];
 }
 if (!Array.isArray(comments)) return null;
 const target = String(spec.target);
 const accountUid = String(spec.accountUid);
 for (const comment of comments) {
  if (!comment || typeof comment !== 'object') continue;
  const id = comment.cid_str ?? comment.cid;
  const parent = comment.reply_id ?? comment.reply_to_comment_id ?? comment.root_comment_id;
  const uid = comment.user && (comment.user.sec_uid || comment.user.sec_user_id);
  const linked = spec.assumeUnderTarget === true || (parent != null && String(parent) === target);
  if (linked && id != null && String(uid || '') === accountUid && comment.text === spec.text) {
   return {cid: String(id), text: comment.text, sec_uid: String(uid), reply_id: target};
  }
  const nested = comment.reply_comment || comment.reply_list || comment.replies;
  const child = {...spec, assumeUnderTarget: spec.assumeUnderTarget === true || String(id) === target};
  const found = matchOwnReply(nested, child);
  if (found) return found;
 }
 return null;
}

// One browser expression, one comment or reply page. No publish call.
function buildReplyPageCheck(video, target, accountUid, text, cursor, options={}) {
 const kind = options.kind === 'replies' ? 'replies' : 'comments';
 const includeDetail = options.includeDetail === true;
 const timeoutMs = Number(options.timeoutMs ?? 8000);
 return `(async()=>{
  const video=${JSON.stringify(String(video))},target=${JSON.stringify(String(target))};
  const accountUid=${JSON.stringify(String(accountUid))},expected=${JSON.stringify(String(text))};
  const cursor=${JSON.stringify(cursor)},kind=${JSON.stringify(kind)};
  const matchOwnReply=${matchOwnReply.toString()};
  const statusNumber=code=>{
   if(code===0||code==='0')return 0;
   if(typeof code==='number'&&Number.isFinite(code))return code;
   if(typeof code==='string'&&/^-?[0-9]{1,9}$/.test(code))return Number(code);
   return null;
  };
  const replyNodes=value=>{
   if(Array.isArray(value))return value;
   if(value&&typeof value==='object'&&(value.cid!=null||value.cid_str!=null||typeof value.text==='string'))return [value];
   return [];
  };
  let timer;
  const read=(async()=>{
   let result={detail_status:0,video_present:true};
   if(${JSON.stringify(includeDetail)}){
    const raw=await window.__bridge.getDetail(video);
    const detail=raw&&typeof raw==='object'?raw:{};
    const aweme=detail.aweme_detail;
    const id=aweme&&(aweme.aweme_id_str??aweme.aweme_id);
    const detailStatus=statusNumber(detail.status_code);
    const videoPresent=detailStatus===0&&String(id)===video;
    result={detail_status:detailStatus,video_present:videoPresent,no_video_detail:!aweme};
    if(detailStatus!==0||!videoPresent)return {...result,own_reply:null,incomplete:true};
   }
   let data;
   if(kind==='replies'){
    if(typeof window.__bridge.getReplies!=='function')return {...result,comments_status:0,replies_unsupported:true,own_reply:null};
    data=await window.__bridge.getReplies(video,target,cursor,50);
   }else{
    data=await window.__bridge.getComments(video,cursor,50);
   }
   const status=statusNumber(data&&data.status_code);
   const exhausted=!!data&&(data.has_more===0||data.has_more===false||data.has_more==='0');
   let list=data&&Array.isArray(data.comments)?data.comments:null;
   if(status===0&&list===null&&exhausted)list=[];
   if(status!==0||list===null)return {...result,comments_status:status,incomplete:true,own_reply:null};
   const own=matchOwnReply(list,{accountUid,text:expected,target,assumeUnderTarget:kind==='replies'});
   let targetPresent=false,replyTotal=null,inlineReplyCount=0;
   for(const comment of list){
    if(!comment||String(comment.cid_str??comment.cid??'')!==target)continue;
    targetPresent=true;
    const totals=[];
    for(const value of [comment.reply_comment_total,comment.reply_count,comment.reply_total]){
     if(typeof value==='number'&&value>=0&&value<=999999)totals.push(value);
     else if(typeof value==='string'&&/^[0-9]{1,6}$/.test(value))totals.push(Number(value));
    }
    if(totals.length)replyTotal=Math.max(...totals);
    inlineReplyCount=replyNodes(comment.reply_comment||comment.reply_list||comment.replies).length;
   }
   return {...result,comments_status:0,own_reply:own,target_present:targetPresent,reply_total:replyTotal,
    inline_reply_count:inlineReplyCount,has_more:exhausted?0:1,count:list.length,next_cursor:data.cursor};
  })();
  try{return await Promise.race([read,new Promise(resolve=>{timer=setTimeout(()=>resolve({incomplete:true,read_timeout:true,own_reply:null}),${timeoutMs});})]);}
  finally{clearTimeout(timer);}
 })()`;
}

async function readOwnReply(client, connId, video, target, options={}) {
 const accountUid = options.accountUid;
 const text = options.text;
 if (!accountUid || typeof text !== 'string' || !text) throw Error('缺少只读核对所需的账号或正文');
 const started = Date.now();
 const budget = options.budgetMs ?? 45000;
 const base = {submission_attempted: false, automatic_retry: false};
 const call = async expression => {
  const response = await client.call({site: 'douyin.com', connId, timeout: 12000, expression});
  if (!response.ok || response.connection !== connId) throw Error(response.error || '只读核对连接未返回');
  return response.value || {};
 };
 const unfinished = (reason, page={}) => ({...base, own_reply_state: 'unchecked', reason,
  read_timeout: page.read_timeout === true, comments_status: page.comments_status,
  detail_status: page.detail_status, video_present: page.video_present,
  target_present: page.target_present === true});
 let cursor = 0;
 const seen = new Set();
 let targetSeen = false;
 let replyTotal = null;
 let inlineScanned = 0;
 let last = {};
 let commentsExhausted = false;
 for (let n = 0; n < 100; n++) {
  if (Date.now() - started >= budget) return unfinished('scan_budget', last);
  const key = 'c:' + String(cursor);
  if (seen.has(key)) break;
  seen.add(key);
  last = await call(buildReplyPageCheck(video, target, accountUid, text, cursor,
   {kind: 'comments', includeDetail: n === 0, timeoutMs: options.timeoutMs}));
  if (last.read_timeout) return unfinished('read_timeout', last);
  if (last.detail_status !== 0 || last.video_present === false) {
   return unfinished(last.no_video_detail ? 'no_video_detail' : 'video_unverified', last);
  }
  if (last.comments_status !== 0) return unfinished('comments_status', last);
  if (last.own_reply) return {...base, own_reply_state: 'found', own_reply: last.own_reply, target_present: true};
  if (last.target_present) {
   targetSeen = true;
   if (typeof last.reply_total === 'number') replyTotal = last.reply_total;
   inlineScanned += last.inline_reply_count || 0;
  }
  if (last.has_more === 0) { commentsExhausted = true; break; }
  if (last.next_cursor == null) return unfinished('incomplete', last);
  cursor = last.next_cursor;
 }
 if (!commentsExhausted) return unfinished('incomplete', last);
 if (!targetSeen) return unfinished('target_not_visible', last);
 if (replyTotal === 0 || (typeof replyTotal === 'number' && inlineScanned >= replyTotal)) {
  return {...base, own_reply_state: 'not_found', check_complete: true, target_present: true,
   reply_total: replyTotal, inline_reply_count: inlineScanned};
 }
 cursor = 0;
 const replySeen = new Set();
 for (let n = 0; n < 100; n++) {
  if (Date.now() - started >= budget) return unfinished('scan_budget', last);
  const key = 'r:' + String(cursor);
  if (replySeen.has(key)) break;
  replySeen.add(key);
  last = await call(buildReplyPageCheck(video, target, accountUid, text, cursor,
   {kind: 'replies', includeDetail: false, timeoutMs: options.timeoutMs}));
  if (last.read_timeout) return unfinished('read_timeout', last);
  if (last.replies_unsupported) return unfinished('reply_list_unavailable', last);
  if (last.comments_status !== 0) return unfinished('comments_status', last);
  if (last.own_reply) return {...base, own_reply_state: 'found', own_reply: last.own_reply, target_present: true};
  if (last.has_more === 0) return {...base, own_reply_state: 'not_found', check_complete: true, target_present: true, reply_total: replyTotal};
  if (last.next_cursor == null) return unfinished('incomplete', last);
  cursor = last.next_cursor;
 }
 return unfinished('incomplete', last);
}

module.exports={buildPageCheck,readTarget,matchOwnReply,buildReplyPageCheck,readOwnReply};
