# resume007 offline tests package
