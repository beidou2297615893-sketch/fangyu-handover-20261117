from pathlib import Path
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');W=S/'work/ui-approved-implementation/ui-preview/pages'
def edit(p,old,new):
 s=p.read_text('utf-8');assert s.count(old)==1,(p.name,old[:80],s.count(old));p.write_text(s.replace(old,new),encoding='utf-8')
(W/'reply-account.mjs').write_text('''// Display public account identity; sending still binds the immutable account ID.
export function senderName(account){
  if(!account)return '尚未选择';
  const nickname=String(account.platformNickname||account.platform_nickname||account.name||'昵称未读取').trim();
  const remark=String(account.remarks||'').trim();
  return remark&&remark!==nickname?`${nickname}（${remark}）`:nickname;
}
export function batchAccounts(state,v){
  const platform=state.activePlatform||'xiaohongshu';
  const accounts=state.platform?.accounts;
  if(Array.isArray(accounts))return accounts.filter(a=>a.platform===platform&&['ready','connected','online'].includes(a.status));
  return (v.detail?.comments?.find(r=>r.id===v.leadId)?.accounts||[]).filter(a=>!a.platform||a.platform===platform);
}
''',encoding='utf-8')
p=W/'reply-batch.mjs';edit(p,"import {prepareReviewedBatch} from './reply-delivery.mjs';","import {prepareReviewedBatch} from './reply-delivery.mjs';\nimport {senderName,batchAccounts} from './reply-account.mjs';")
edit(p,"const ids=v.checkedIds||[],locked=v.busy||v.pending||v.batchBusy||v.batchPending;", "const ids=v.checkedIds||[],locked=v.busy||v.pending||v.batchBusy||v.batchPending,accounts=batchAccounts(s,v),sender=accounts.find(a=>a.id===v.batchAccountId);")
edit(p,'<span>已选 ${ids.length} 位</span><select data-batch-role aria-label="批量 SOP"', '<span>已选 ${ids.length} 位</span><label class="rp-batch-sender">批量发送账号<select data-batch-account aria-label="批量发送账号" ${locked?\'disabled\':\'\'}><option value="">请先选择发送账号</option>${accounts.map(a=>`<option value="${esc(a.id)}" ${a.id===v.batchAccountId?\'selected\':\'\'}>${esc(senderName(a))}</option>`).join(\'\')}</select></label><span class="rp-batch-sender-name" role="status">${sender?\'本批统一使用：\'+esc(senderName(sender)):\'尚未选择发送账号\'}</span><select data-batch-role aria-label="批量 SOP"')
edit(p,"${!ids.length||locked?'disabled':''}","${!ids.length||!sender||locked?'disabled':''}")
edit(p," root.querySelector('[data-batch-role]')", " root.querySelector('[data-batch-account]')?.addEventListener('change',e=>{if(locked())return;v.batchAccountId=e.target.value;v.batchAccountRevision=(v.batchAccountRevision||0)+1;v.batchError='';redraw();});\n root.querySelector('[data-batch-role]')")
edit(p,"const ids=[...new Set(v.checkedIds||[])];if(!ids.length||ids.length>20)return;", "const ids=[...new Set(v.checkedIds||[])];if(!ids.length||ids.length>20)return;\n   const accountId=v.batchAccountId,accountRevision=v.batchAccountRevision||0,sender=batchAccounts(s,v).find(a=>a.id===accountId);\n   if(!sender){ctx.toast('请先选择本批发送账号。');return;}\n   const senderLabel=senderName(sender);")
edit(p,"const account=row?.accounts?.find(a=>a.id===v.accountId)||(row?.accounts?.length===1?row.accounts[0]:null);", "const account=row?.accounts?.find(a=>a.id===accountId);")
edit(p,'accountName:account.name,comment:', 'accountName:senderLabel,comment:')
edit(p,'html:`<p>每位客户处理一条评论。', 'html:`<div class="rp-sender-confirm"><span>本批发送账号</span><strong>${esc(senderLabel)}</strong></div><p>每位客户处理一条评论。')
edit(p,"另有 '+skipped.length+' 位暂不可处理。", "另有 '+skipped.length+' 位因该账号不可用或评论不可编辑而跳过。")
edit(p,'${esc(r.name)} · ${esc(r.accountName)}</h3>', '${esc(r.name)}</h3><p>发送账号：${esc(r.accountName)}</p>')
edit(p,"if(!owns()||v.batchBusy||v.batchPending||v.busy||v.pending)return false;", "if(!owns()||v.batchBusy||v.batchPending||v.busy||v.pending)return false;\n       if(v.batchAccountId!==accountId||(v.batchAccountRevision||0)!==accountRevision||!batchAccounts(s,v).some(a=>a.id===accountId)){ctx.toast('发送账号已变化，请重新预览本批草稿。');return false;}")
p=W/'reply-connected.mjs';edit(p,"import {bindBatch,renderBatch} from './reply-batch.mjs';", "import {bindBatch,renderBatch} from './reply-batch.mjs';\nimport {senderName} from './reply-account.mjs';")
edit(p,'<label>核对账号 <select data-live-account', '<label class="rp-sender-choice"><span>发送账号</span><strong class="rp-sender-name">${esc(senderName(row.accounts.find(a=>a.id===v.accountId)))}</strong><select data-live-account aria-label="发送账号"')
edit(p,'${esc(a.name)}</option>', '${esc(senderName(a))}</option>')
edit(p,'${disclosure}${sourceControls}', '${disclosure}')
edit(p,'editor=`<div class="rp-person-summary"', 'editor=`${sourceControls}<div class="rp-person-summary"')
edit(p,'<p>账号：${esc(account?.name)}</p>', '<div class="rp-sender-confirm"><span>发送账号</span><strong>${esc(senderName(account))}</strong></div>')
edit(p,"'请先选择本人核对账号。'", "'请先选择发送账号。'")
edit(p,'>选择员工 / 客户 SOP</button>', '>选择员工 / 客户 SOP</button>')
p=W/'reply-delivery.mjs';edit(p,'function fullList(plan){return `<p>', 'function fullList(plan){const names=[...new Set(plan.items.map(r=>r.accountName||\'昵称未读取\'))];return `<div class="rp-sender-confirm"><span>本批发送账号</span><strong>${names.map(esc).join(\'、\')}</strong></div><p>')
edit(p,'${esc(r.customerName)} · ${esc(r.accountName)}</h3>', '${esc(r.customerName)}</h3><p><strong>发送账号：${esc(r.accountName)}</strong></p>')
# Keep names visible when reopening an existing prepared plan or checking sent results.
edit(p,'${esc(r.customerName)} · ${esc(itemLabels[r.status]', '${esc(r.customerName)} · 发送账号：${esc(r.accountName||\'昵称未读取\')} · ${esc(itemLabels[r.status]')
# Backend names come from the verified platform nickname, never a UI-only alias.
p=S/'work/ui-native-r57/reply_workbench.py';edit(p,"'name':str(account.get('name') or '平台账号'),", "'name':str(account.get('platform_nickname') or account.get('name') or '平台账号'),\n                            'platformNickname':str(account.get('platform_nickname') or ''),'remarks':str(account.get('remarks') or ''),")
p=S/'work/ui-native-r57/reply_delivery.py';edit(p,"'accountName':str(account.get('name') or '本人账号')", "'accountName':str(account.get('platform_nickname') or account.get('name') or '本人账号')")
p=W/'reply.css';p.write_text(p.read_text('utf-8')+'''
/* Sender identity stays above the composer and remains legible in narrow panes. */
.reply-page.rp-connected .rp-source-controls{flex-shrink:0;display:flex;flex-direction:column;margin:0 0 16px;gap:12px}
.reply-page.rp-connected .rp-sender-choice{display:grid;gap:8px;background:#eef7f6;border:1px solid #9bc9c4;border-left:4px solid #237e76;border-radius:9px;padding:12px 14px;color:#183e49;font-size:18px;font-weight:700;min-width:0}
.reply-page.rp-connected .rp-sender-name{font-size:20px;line-height:1.4;overflow-wrap:anywhere}
.reply-page.rp-connected .rp-sender-choice select{width:100%;min-width:0;max-width:100%;height:auto;min-height:44px;font-size:18px;font-weight:600;background:#fff;color:#183e49;border:1px solid #719e9b;padding:8px;border-radius:6px}
.reply-page.rp-connected .rp-persona-controls button{height:auto;min-height:44px;padding:10px 14px;font-size:18px;font-weight:700;color:#185c60;background:#eff8f7;border:1px solid #86b6b3;white-space:normal;text-align:left}
.rp-batch-bar .rp-batch-sender{display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:18px;font-weight:700;color:#183e49;max-width:100%;min-width:0}
.rp-batch-bar [data-batch-account]{min-height:44px;max-width:100%;min-width:0;font-size:18px;font-weight:600;border-color:#719e9b}
.rp-batch-bar .rp-batch-sender-name{font-size:17px;font-weight:600;color:#185c60;overflow-wrap:anywhere}
.rp-batch-bar [data-batch-role],.rp-batch-bar [data-batch-prepare]{min-height:44px;font-size:18px;font-weight:600}
.rp-sender-confirm{display:grid;gap:6px;padding:14px 16px;margin:0 0 14px;background:#eef7f6;border:1px solid #9bc9c4;border-left:4px solid #237e76;border-radius:8px;color:#183e49;overflow-wrap:anywhere}
.rp-sender-confirm span{font-size:18px;font-weight:600}.rp-sender-confirm strong{font-size:22px;line-height:1.4}
.shell:has(.pt-douyin) .reply-page.rp-connected .rp-sender-choice{background:#23343c;border-color:#5a828c;color:#edf7f8}
.shell:has(.pt-douyin) .reply-page.rp-connected .rp-sender-choice select{background:#172831;color:#edf7f8;border-color:#7398a1}
.shell:has(.pt-douyin) .reply-page.rp-connected .rp-persona-controls button{background:#23343c;color:#edf7f8;border-color:#7398a1}
.shell:has(.pt-douyin) .rp-batch-bar .rp-batch-sender,.shell:has(.pt-douyin) .rp-batch-bar .rp-batch-sender-name{color:#edf7f8}
''',encoding='utf-8')
print('Updated explicit batch sender, nickname projections and prominent sender/SOP controls.')
