"""Consume a hash-verified Douyin classification snapshot for business-row exclusion."""
import hashlib
import json
import sqlite3
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = frozenset(('low', 'non_customer', 'ended'))
LOCKED_VERSION = 'fangyu-commercial-fit-v4.3-20261106'


def digest(value):
    return hashlib.sha256(value).hexdigest()


def exclusion_fingerprint(cid):
    return digest(('douyin\0' + cid).encode())


def verified_snapshot(handoff_path, locked_version=LOCKED_VERSION):
    handoff = json.loads(Path(handoff_path).read_text(encoding='utf-8-sig'))
    contract = handoff['commercial_fit']
    if contract['version'] != locked_version:
        raise ValueError('classification_rule_version_not_locked')
    path = Path(contract['all_pool_file'])
    content = path.read_bytes()
    if digest(content) != contract['all_pool_sha256']:
        raise ValueError('classification_snapshot_sha_mismatch')
    rows = [json.loads(line) for line in content.decode('utf-8-sig').splitlines() if line.strip()]
    if any(row.get('platform') != 'douyin' or row.get('commercial_fit', {}).get('version') != contract['version'] for row in rows):
        raise ValueError('classification_snapshot_version_mismatch')
    return contract, rows


def prune_classified(database, handoff_path=None, batch_size=200, locked_version=LOCKED_VERSION):
    handoff_path=Path(handoff_path or ROOT / 'classification-handoff-status.json')
    contract, rows = verified_snapshot(handoff_path, locked_version)
    db = sqlite3.connect(database, timeout=2)
    db.execute('CREATE TABLE IF NOT EXISTS excluded_comment_fingerprints(digest TEXT PRIMARY KEY, classification_version TEXT NOT NULL, lead_intent TEXT NOT NULL, snapshot_sha256 TEXT NOT NULL)')
    db.execute('CREATE INDEX IF NOT EXISTS items_retention_identity ON items(kind,source_id)')
    db.commit()
    decisions = {}
    conflicts = set()
    rule_conflicts=set()
    for row in rows:
        cid = row.get('comment_id')
        text = row.get('comment_text')
        fit = row.get('commercial_fit', {})
        if not isinstance(cid, str) or not cid.isdigit() or not isinstance(text, str):
            continue
        if row.get('source_version_conflict') is True or digest(text.encode()) != row.get('source_comment_sha256'):
            conflicts.add(cid)
            continue
        reasons=set(fit.get('exclusion_reasons',[]))
        if reasons.intersection({'whole_home_monthly_budget_below_3000','source_post_advertised_rent_below_3000'}) and fit.get('lead_intent') in ('medium','high','super_high'):
            rule_conflicts.add(cid)
            conflicts.add(cid)
            continue
        current = (fit.get('lead_intent'), text)
        if cid in decisions and decisions[cid] != current:
            conflicts.add(cid)
        decisions[cid] = current
    candidates = [(cid, intent, text) for cid, (intent, text) in decisions.items() if intent in EXCLUDED and cid not in conflicts]
    deleted = Counter()
    accepted = Counter()
    mismatched = len(conflicts)
    superseded=False
    for start in range(0, len(candidates), batch_size):
        current=json.loads(handoff_path.read_text(encoding='utf-8-sig'))['commercial_fit']
        if current['version'] != contract['version'] or current['all_pool_sha256'] != contract['all_pool_sha256']:
            superseded=True
            break
        with db:
            # Re-read inside each short write transaction so a changed source
            # cannot be deleted against a stale classification text.
            db.execute('BEGIN IMMEDIATE')
            for cid, intent, text in candidates[start:start + batch_size]:
                entities = db.execute("SELECT stable_key,data FROM entities WHERE kind='comments' AND source_id=?", (cid,)).fetchall()
                if not entities:
                    continue
                keys = [key for key, _ in entities]
                source_rows = [raw for _, raw in entities]
                source_rows += [r[0] for r in db.execute("SELECT data FROM items WHERE kind='comments' AND source_id=?", (cid,))]
                for key in keys:
                    source_rows += [r[0] for r in db.execute("SELECT data FROM observations WHERE kind='comments' AND stable_key=?", (key,))]
                if any(json.loads(raw).get('cid') != cid or json.loads(raw).get('text', '') != text for raw in source_rows):
                    mismatched += 1
                    continue
                db.execute('INSERT OR IGNORE INTO excluded_comment_fingerprints VALUES(?,?,?,?)',
                           (exclusion_fingerprint(cid), contract['version'], intent, contract['all_pool_sha256']))
                for key in keys:
                    deleted['observations'] += db.execute("DELETE FROM observations WHERE kind='comments' AND stable_key=?", (key,)).rowcount
                for table in ('items', 'entities'):
                    deleted[table] += db.execute(f"DELETE FROM {table} WHERE kind='comments' AND source_id=?", (cid,)).rowcount
                if db.execute("SELECT 1 FROM sqlite_master WHERE name='recent_comment_backfill'").fetchone():
                    deleted['backfill'] += db.execute('DELETE FROM recent_comment_backfill WHERE cid=?', (cid,)).rowcount
                accepted[intent] += 1
    remaining = db.execute("SELECT COUNT(*) FROM entities WHERE kind='comments'").fetchone()[0]
    db.close()
    return dict(version=contract['version'], snapshot_sha256=contract['all_pool_sha256'], deleted_rows=dict(deleted), excluded_cids=dict(accepted), source_or_snapshot_mismatch=mismatched, snapshot_superseded=superseded, rule_conflict_cids=len(rule_conflicts), remaining_business_comments=remaining)


if __name__ == '__main__':
    print(json.dumps(prune_classified(ROOT / 'runtime/collection.sqlite3')))
