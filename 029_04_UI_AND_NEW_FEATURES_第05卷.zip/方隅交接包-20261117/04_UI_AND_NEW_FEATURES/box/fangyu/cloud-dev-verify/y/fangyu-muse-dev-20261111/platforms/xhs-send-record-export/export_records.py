"""Read-only cumulative attempt reconciliation. No sender, session, or network imports."""
import argparse
from collections import Counter,defaultdict
from contextlib import closing
import csv
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sqlite3

LABELS={'receipt':'已取得平台回执','unknown':'结果未知，请勿重发','in_flight':'已预留，提交结果待核对','unconfirmed':'仅有运行记录，尚未与账本对应'}
PLAN_KEYS=('attempt_id','customer_uid','comment_id','note_id','text')


def collect(runs,ledger,mapping,sender_uid):
    runs=Path(runs).resolve();ledger=Path(ledger).resolve();mapping=Path(mapping).resolve()
    warnings=[];sources=[]
    def warn(reason,attempt_id='',source=''):
        warnings.append({'reason':reason,'attempt_id':attempt_id,'source':source})
    def read(path):
        raw=path.read_bytes();sources.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()})
        return raw
    metadata={}
    value=json.loads(read(mapping).decode('utf-8-sig'))
    for item in value:
        key=item['comment_id']
        if key in metadata and metadata[key]!=item:raise ValueError('mapping_comment_conflict')
        metadata[key]=item
    prepared=defaultdict(list);batches=[]
    for path in sorted(runs.rglob('prepared-batch.json')):
        batch=json.loads(read(path).decode('utf-8-sig'))
        if batch.get('intended_account_uid')!=sender_uid:continue
        rows=batch.get('rows',[])
        batches.append({'source':str(path),'prepared_count':len(rows),'attempt_ids':[r['attempt_id'] for r in rows]})
        for row in rows:prepared[row['attempt_id']].append(row)
    events=defaultdict(list);run_summaries=[]
    for path in sorted(runs.rglob('events.jsonl')):
        raw=read(path);lines=raw.splitlines();run_accepted=set();belongs=False
        for index,line in enumerate(lines):
            if not line.strip():continue
            try:event=json.loads(line)
            except (ValueError,UnicodeError):
                if index==len(lines)-1 and not raw.endswith(b'\n'):
                    warn('partial_event_tail',source=str(path));continue
                raise ValueError('invalid_event_line') from None
            if event.get('sender_uid')==sender_uid:belongs=True
            if event.get('sender_uid')==sender_uid and event.get('attempt_id'):
                events[event['attempt_id']].append(event)
                if event.get('event')=='accepted':run_accepted.add(event['attempt_id'])
        if not belongs:continue
        summary=path.with_name('summary.json')
        if summary.exists():
            data=json.loads(read(summary).decode('utf-8-sig'))
            if type(data.get('accepted')) is int and data['accepted']!=len(run_accepted):
                warn('run_summary_accepted_mismatch',source=str(summary))
            # Safe scalar projection; no arbitrary diagnostic/body passthrough.
            run_summaries.append({'source':str(summary),'status':data.get('status') if data.get('status') in
                ('complete','stopped','stopped_unknown','stopped_before_post','paused_by_user','stopped_accepted_restriction') else 'other_or_running',
                **{k:data[k] for k in ('accepted','post_attempts','target_unknown_isolated') if type(data.get(k)) is int}})
        else:run_summaries.append({'source':str(path),'status':'summary_not_present'})
    # SQLite mode=ro plus query_only and a single read transaction; no migration or writes.
    with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True,timeout=5)) as db:
        db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        native=db.execute('SELECT r.token,r.customer,r.comment,r.status,r.created,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? ORDER BY r.created,r.token',('xiaohongshu',)).fetchall()
    records=[];seen=set()
    for stored in native:
        if stored['data'] is None:
            warn('reservation_without_plan',stored['token']);continue
        data=json.loads(stored['data']);plan=data.get('plan') or data.get('local_mode',{}).get('plan') or {}
        if plan.get('sender_uid')!=sender_uid:continue
        attempt=stored['token'];seen.add(attempt);result=data.get('result') or {}
        if not isinstance(result,dict):result={};warn('invalid_native_result',attempt)
        if plan.get('attempt_id')!=attempt or plan.get('canonical_customer')!=stored['customer'] or plan.get('comment_id')!=stored['comment']:
            warn('reservation_plan_identity_mismatch',attempt)
        receipt=result.get('receipt_id') if result.get('kind')=='platform_receipt' and isinstance(result.get('receipt_id'),str) and result['receipt_id'] else ''
        outcome='receipt' if receipt else ('in_flight' if stored['status']=='reserved' else 'unknown')
        if attempt not in prepared:warn('prepared_attempt_not_found',attempt)
        for frozen in prepared[attempt]:
            if any(frozen.get(k)!=plan.get(k) for k in PLAN_KEYS) or frozen.get('customer_id')!=plan.get('canonical_customer'):
                warn('frozen_plan_mismatch',attempt)
        meta=metadata.get(plan.get('comment_id'),{})
        if meta and meta.get('customer_uid')!=plan.get('customer_uid'):
            warn('mapping_identity_mismatch',attempt);meta={}
        if not meta:warn('original_comment_missing',attempt)
        timeline=events.get(attempt,[])
        for event in timeline:
            if event.get('event')=='accepted' and event.get('receipt_id')!=receipt:warn('event_receipt_mismatch',attempt)
            for key in ('customer_uid','comment_id','note_id'):
                if key in event and event[key]!=plan.get(key):warn('event_identity_mismatch',attempt)
            if 'approved_reply' in event and event['approved_reply']!=plan.get('text'):warn('event_reply_mismatch',attempt)
        accepted=[e for e in timeline if e.get('event')=='accepted' and e.get('receipt_id')==receipt]
        if receipt and not accepted:warn('receipt_event_missing',attempt)
        record={k:plan.get(k,'') for k in PLAN_KEYS}
        record.update(sender_uid=sender_uid,customer_id=plan.get('canonical_customer',''),outcome=outcome,
            receipt_id=receipt,original_comment=meta.get('original_comment',''),post_title=meta.get('post_title',''),
            reply=plan.get('text',''),created_at=stored['created'],accepted_at=accepted[0].get('at','') if accepted else '',
            public_visibility='unverified',native_record_sha256=hashlib.sha256(stored['data'].encode('utf8')).hexdigest())
        for key in ('api_code','http_status'):
            if type(result.get(key)) is int:record[key]=result[key]
        if type(result.get('verification_header_present')) is bool:record['verification_header_present']=result['verification_header_present']
        records.append(record)
    for attempt,timeline in events.items():
        if attempt in seen or not any(e.get('event') in ('submission_starting','accepted','unknown','stopped') for e in timeline):continue
        frozen=prepared.get(attempt,[{}])[0];meta=metadata.get(frozen.get('comment_id'),{})
        warn('event_attempt_not_in_ledger',attempt)
        records.append({'attempt_id':attempt,'sender_uid':sender_uid,'outcome':'unconfirmed','receipt_id':'',
            'customer_uid':frozen.get('customer_uid',''),'comment_id':frozen.get('comment_id',''),
            'original_comment':meta.get('original_comment','') if meta.get('customer_uid')==frozen.get('customer_uid') else '',
            'reply':frozen.get('text',''),'post_title':meta.get('post_title',''),'accepted_at':'','public_visibility':'unverified'})
    counts={k:sum(r['outcome']==k for r in records) for k in LABELS}
    outcomes={r['attempt_id']:r['outcome'] for r in records}
    for batch in batches:
        batch['submitted_counts']=dict(Counter(outcomes[a] for a in batch.pop('attempt_ids') if a in outcomes))
    return {'schema':'xhs-cumulative-send-records-v1','snapshot_at':datetime.now(timezone.utc).isoformat(),
        'sender_uid':sender_uid,'snapshot_only':True,'reconciled':not warnings,'counts':counts,'records':records,
        'warnings':warnings,'batches':batches,'run_summaries':run_summaries,'sources':sources,
        'visibility_note':'平台回执仅证明提交获受理，公开可见性未核实。'}


def write_export(snapshot,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    # Dedicated new directory only; callers cannot overwrite a prior export or active run.
    with (output/'评论回复记录.csv').open('x',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['提交结果','原帖标题','客户原评论','回复内容','取得回执时间','公开可见性'])
        for row in snapshot['records']:
            fields=[LABELS[row['outcome']],row.get('post_title',''),row.get('original_comment',''),row.get('reply',''),row.get('accepted_at',''),'尚未核实']
            writer.writerow(["'"+str(s) if str(s).lstrip().startswith(('=','+','-','@')) else s for s in fields])
    audit=output/'audit';audit.mkdir()
    (audit/'records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in snapshot['records']),encoding='utf8')
    (audit/'reconciliation.json').write_text(json.dumps({k:v for k,v in snapshot.items() if k!='records'},ensure_ascii=False,indent=2),encoding='utf8')
    counts=snapshot['counts']
    note=f"本次为只读快照。平台回执{counts['receipt']}条，结果未知{counts['unknown']}条，预留待核对{counts['in_flight']}条，尚未与账本对应{counts['unconfirmed']}条。\n平台回执仅证明提交获受理，公开可见性尚未核实。未知结果请勿重发。\n"
    note+='记录已完成一致性核对。\n' if snapshot['reconciled'] else '存在待核对项；请核查后再将快照作为正式记录。\n'
    (output/'记录说明.txt').write_text(note,encoding='utf8')


def main():
    parser=argparse.ArgumentParser(description='只读导出评论回复累计快照；输出目录必须不存在。')
    for name in ('runs','ledger','mapping','sender-uid','output'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();snapshot=collect(args.runs,args.ledger,args.mapping,args.sender_uid)
    write_export(snapshot,args.output)
    print(json.dumps({'counts':snapshot['counts'],'reconciled':snapshot['reconciled'],'warnings':len(snapshot['warnings'])}))


if __name__=='__main__':main()
