import csv
import importlib.util
import json
from pathlib import Path
import sqlite3
from contextlib import closing
import tempfile
import unittest

SCRIPT=Path(__file__).with_name('export_records.py')


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.runs=self.root/'runs';self.runs.mkdir();self.db=self.root/'ledger.sqlite3'
        with closing(sqlite3.connect(self.db)) as db:
            db.executescript('CREATE TABLE reservations(token TEXT,platform TEXT,customer TEXT,comment TEXT,status TEXT,evidence TEXT,created INTEGER);CREATE TABLE local_sender_plans(token TEXT,data TEXT);')
        self.mapping=self.root/'mapping.json'
        self.mapping.write_text(json.dumps([{'comment_id':'c1','customer_uid':'u1','original_comment':'=test','post_title':'房子'},
            {'comment_id':'c2','customer_uid':'u2','original_comment':'原问句','post_title':'房子'}]),encoding='utf8')
        self.batch=self.runs/'prepared';self.batch.mkdir()
        self.rows=[{'attempt_id':'a'+str(i),'customer_id':'k'+str(i),'customer_uid':'u'+str(i),'comment_id':'c'+str(i),'note_id':'n'+str(i),'text':'reply'+str(i)} for i in (1,2,3,4)]
        (self.batch/'prepared-batch.json').write_text(json.dumps({'intended_account_uid':'sender','rows':self.rows}),encoding='utf8')
        spec=importlib.util.spec_from_file_location('export_records',SCRIPT)
        self.module=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.module)

    def tearDown(self):self.tmp.cleanup()

    def add(self,i,status,result=None,sender='sender'):
        row=self.rows[i-1];plan={**row,'sender_uid':sender,'canonical_customer':row['customer_id']}
        raw=json.dumps({'plan':plan,'result':result,'cookie':'SECRET-cookie','headers':{'token':'SECRET-token'}})
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',(row['attempt_id'],'xiaohongshu',row['customer_id'],row['comment_id'],status,None,100))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',(row['attempt_id'],raw))
            db.commit()

    def events(self,entries,tail=''):
        run=self.runs/'live';run.mkdir(exist_ok=True)
        (run/'events.jsonl').write_text(''.join(json.dumps({'sender_uid':'sender',**e})+'\n' for e in entries)+tail,encoding='utf8')

    def collect(self):return self.module.collect(self.runs,self.db,self.mapping,'sender')

    def test_authoritative_receipt_unknown_and_reserved_are_distinct_readonly_and_redacted(self):
        self.add(1,'unknown',{'kind':'platform_receipt','receipt_id':'r1'})
        self.add(2,'unknown',{'kind':'unknown','api_code':-9131,'http_status':200})
        self.add(3,'reserved');self.add(4,'unknown',{'kind':'platform_receipt','receipt_id':'other'},sender='other')
        before=self.db.read_bytes();snapshot=self.collect()
        self.assertEqual([r['outcome'] for r in snapshot['records']],['receipt','unknown','in_flight'])
        self.assertEqual(snapshot['records'][0]['original_comment'],'=test')
        self.assertEqual(self.db.read_bytes(),before)
        self.assertNotIn('SECRET',json.dumps(snapshot))
        self.assertEqual(snapshot['counts'],{'receipt':1,'unknown':1,'in_flight':1,'unconfirmed':0})

    def test_duplicate_events_do_not_inflate_receipts_and_mismatch_is_reported(self):
        self.add(1,'unknown',{'kind':'platform_receipt','receipt_id':'r1'})
        self.events([{'event':'accepted','attempt_id':'a1','receipt_id':'wrong'},
            {'event':'accepted','attempt_id':'a1','receipt_id':'wrong'}])
        result=self.collect();self.assertEqual(result['counts']['receipt'],1)
        self.assertTrue(any(w['reason']=='event_receipt_mismatch' for w in result['warnings']))
        self.assertFalse(result['reconciled'])

    def test_event_only_is_unconfirmed_never_receipt_partial_tail_is_tolerated(self):
        self.events([{'event':'accepted','attempt_id':'a2','receipt_id':'unproven'}],tail='{"partial":')
        result=self.collect();self.assertEqual(result['counts']['receipt'],0)
        self.assertEqual(result['counts']['unconfirmed'],1)
        self.assertTrue(any(w['reason']=='partial_event_tail' for w in result['warnings']))

    def test_csv_is_human_readable_formula_safe_and_output_cannot_overwrite(self):
        self.add(1,'unknown',{'kind':'platform_receipt','receipt_id':'r1'})
        result=self.collect();output=self.root/'new-snapshot'
        self.module.write_export(result,output)
        with (output/'评论回复记录.csv').open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(rows[0]['客户原评论'],"'=test")
        self.assertEqual(rows[0]['提交结果'],'已取得平台回执')
        self.assertNotIn('attempt_id',rows[0])
        with self.assertRaises(FileExistsError):self.module.write_export(result,output)

    def test_frozen_plan_and_original_uid_mismatch_fail_reconciliation_without_false_matching(self):
        self.add(1,'unknown',{'kind':'platform_receipt','receipt_id':'r1'})
        self.mapping.write_text(json.dumps([{'comment_id':'c1','customer_uid':'different','original_comment':'wrong'}]),encoding='utf8')
        value=json.loads((self.batch/'prepared-batch.json').read_text());value['rows'][0]['text']='changed'
        (self.batch/'prepared-batch.json').write_text(json.dumps(value),encoding='utf8')
        result=self.collect();self.assertEqual(result['records'][0]['original_comment'],'')
        reasons={w['reason'] for w in result['warnings']}
        self.assertIn('frozen_plan_mismatch',reasons);self.assertIn('mapping_identity_mismatch',reasons)

    def test_run_summary_must_match_unique_accepted_events(self):
        self.add(1,'unknown',{'kind':'platform_receipt','receipt_id':'r1'})
        self.events([{'event':'accepted','attempt_id':'a1','receipt_id':'r1'}])
        (self.runs/'live'/'summary.json').write_text(json.dumps({'status':'complete','accepted':2}),encoding='utf8')
        result=self.collect();self.assertFalse(result['reconciled'])
        self.assertTrue(any(w['reason']=='run_summary_accepted_mismatch' for w in result['warnings']))


if __name__=='__main__':unittest.main()
