import json
import unittest

import httpx
import collector


class AllowlistDiagnosticsTests(unittest.TestCase):
    def reject(self, method, url):
        calls = []
        client = collector.ReadClient(
            {'a1': 'fixture', 'web_session': 'fixture'},
            transport=httpx.MockTransport(lambda request: calls.append(request)), delay=0)
        client._last_stage = 'comments'
        try:
            with self.assertRaises(collector.Halt) as caught:
                client._request_with_retry(method, url, headers={'cookie': 'cookie-secret'})
        finally:
            client.close()
        self.assertEqual(calls, [])
        message = str(caught.exception)
        detail = json.loads(message.split('：', 1)[1])
        self.assertFalse(detail['request_started'])
        self.assertEqual(detail['stage'], 'comments')
        for secret in ('query-secret', 'fragment-secret', 'cookie-secret', 'private-user'):
            self.assertNotIn(secret, message)
        return detail

    def test_fragment_rejection_retains_safe_route_without_fragment_contents(self):
        detail = self.reject('GET', 'https://edith.xiaohongshu.com/api/sns/web/v2/comment/page?token=query-secret#fragment-secret')
        self.assertEqual(detail['method'], 'GET')
        self.assertEqual(detail['host'], 'edith.xiaohongshu.com')
        self.assertEqual(detail['path'], '/api/sns/web/v2/comment/page')
        self.assertTrue(detail['fragment_present'])

    def test_post_still_rejected_with_safe_diagnostic(self):
        detail = self.reject('POST', 'https://edith.xiaohongshu.com/api/sns/web/v1/comment/post?token=query-secret')
        self.assertEqual(detail['path'], '/api/sns/web/v1/comment/post')
        self.assertFalse(detail['fragment_present'])

    def test_html_fallback_redacts_user_or_note_identifier(self):
        detail = self.reject('GET', 'https://www.xiaohongshu.com/explore/private-user?token=query-secret')
        self.assertEqual(detail['path'], '/explore/[redacted]')
        self.assertEqual(detail['host'], 'www.xiaohongshu.com')

    def test_untrusted_host_path_and_method_are_redacted(self):
        detail = self.reject('private-user', 'https://private-user.example/private-user?token=query-secret')
        self.assertEqual(detail['method'], 'OTHER')
        self.assertEqual(detail['host'], '[redacted]')
        self.assertEqual(detail['path'], '[redacted]')


if __name__ == '__main__':
    unittest.main()
