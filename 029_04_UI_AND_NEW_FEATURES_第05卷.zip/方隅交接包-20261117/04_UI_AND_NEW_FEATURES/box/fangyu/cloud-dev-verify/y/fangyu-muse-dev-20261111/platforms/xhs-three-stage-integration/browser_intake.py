"""Immutable visible-browser increment -> existing AI pipeline; never sends or registers."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def ai_module():
    spec = importlib.util.spec_from_file_location('intake_ai', ROOT/'work/xhs-ai-standalone/pipeline.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def normalize(raw):
    if raw.get('source') != 'chrome_visible_dom' or raw.get('complete') is not True:
        raise ValueError('Only explicitly completed visible-browser capture is accepted')
    if raw.get('displayed_comment_count') != len(raw.get('comments', [])):
        raise ValueError('Visible count and captured comments differ')
    groups = {}
    seen = set()
    for comment in raw['comments']:
        if comment['id'] in seen or comment.get('parent'):
            raise ValueError('Duplicate or unresolved parent comment')
        seen.add(comment['id'])
        uid = comment['uid']
        flags = ['publication_year_missing']
        if raw.get('body_text_missing'): flags.append('post_body_missing')
        item = {'comment_id': comment['id'], 'note_id': raw['note_id'],
                'comment_text': comment['text'], 'parent_text': '',
                'parent_relationship': 'top_level_comment_on_post',
                'post_title': raw.get('title', ''), 'post_text': '' if raw.get('body_text_missing') else raw.get('post_text', ''),
                'visible_hashtag_text': raw.get('post_text', '') if raw.get('body_text_missing') else '',
                'published_at': '', 'published_at_display': comment.get('date', ''),
                'missing_context': flags}
        if uid in groups:
            groups[uid]['other_comments'].append(item)
        else:
            groups[uid] = {'customer_id': 'xhs_new_'+hashlib.sha256(('xiaohongshu:'+uid).encode()).hexdigest(),
                           'customer_uid': uid, **item, 'other_comments': []}
    rows = list(groups.values())
    ai_module().validate_records(rows)
    return rows


def prepare(source, output):
    source, output = Path(source).resolve(strict=True), Path(output).resolve()
    raw_bytes = source.read_bytes()
    rows = normalize(json.loads(raw_bytes.decode('utf-8-sig')))
    # Never replace or revise an existing intake, including a partly written one.
    output.mkdir(parents=True, exist_ok=False)
    (output/'browser-source.json').write_bytes(raw_bytes)
    (output/'ai-input.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf8')
    manifest = {'schema': 'xhs-browser-increment-v1', 'source_sha256': hashlib.sha256(raw_bytes).hexdigest(),
                'customers': len(rows), 'comments': sum(1+len(r['other_comments']) for r in rows),
                'status': 'ready_for_isolated_analysis', 'registered_in_production_ledger': False,
                'send': False, 'body_text_missing': bool(json.loads(raw_bytes.decode('utf-8-sig')).get('body_text_missing')),
                'publication_dates': 'display text retained; year unknown; no guessed timestamps'}
    (output/'intake.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--analyse', action='store_true')
    parser.add_argument('--sender-uid')
    parser.add_argument('--account')
    parser.add_argument('--style')
    args = parser.parse_args()
    if args.analyse and not all((args.sender_uid, args.account, args.style)):
        parser.error('analysis requires the existing sender UID, account and style files')
    manifest = prepare(args.source, args.output)
    if args.analyse:
        ai = ai_module()
        ai.create_batch(Path(args.output)/'ai-input.json', Path(args.output)/'analysis', args.sender_uid,
                        json.loads(Path(args.account).read_text('utf-8-sig')),
                        json.loads(Path(args.style).read_text('utf-8-sig')), ai.CodexProvider())
        manifest['status'] = 'analysis_and_drafts_completed_not_approved'
        (Path(args.output)/'analysis-receipt.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == '__main__':
    main()
