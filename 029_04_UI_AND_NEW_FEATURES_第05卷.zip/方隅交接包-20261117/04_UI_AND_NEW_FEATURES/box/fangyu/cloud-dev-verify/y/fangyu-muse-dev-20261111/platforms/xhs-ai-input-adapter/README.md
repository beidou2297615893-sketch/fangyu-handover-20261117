# 小红书评论 AI 输入适配

从现有客户 SQLite 库的本地评论和客户聚合中准备 AI 输入。只读数据源和本地账本，不联网、不调用模型、不发送评论，也不读取 Cookie、令牌或其他凭据。

AI 输入按客户拆分本人代表评论、同人其他评论、对应帖子标题与上级/根评论。上级或根评论不是已确认的直接回复对象；缺失原帖正文、父级与时间用空字符串配合缺失标记，不推断为空或不存在。不会把评论链接、查询参数或访问令牌输出到 AI 输入。每位客户的历史意向仅作为旧数据，不能代替新判断。

`ready` 只代表具备本地身份映射和代表评论，**不代表AI已经分析、不代表可发送**。账户角色、住户与优惠真实性需另从已确认来源提供，不从顾客评论推断。未接入本地账本的其他账号和程序的历史仍是未知。

## 当前已暂停的15位

在本文件夹执行：

```powershell
python -X utf8 adapter.py --database 'C:\Users\rmsama\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Local\fangyu-apartment-clientWorkspace\workspace.sqlite3' --batch 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-gubei-pending-refresh\pending-batch.json' --ledger 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3' --output 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-ai-input-adapter\work\本次核查.json' --pipeline-output 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-ai-input-adapter\work\本次输入.json'
```

每次输出使用未存在的新文件名，程序不会覆盖已有结果；输出限制在本目录内。`--batch` 所含账号 UID 会与 `--account-uid`（如果提供）核对；不通过不输出。AI 输入之前只读核查共享账本，排除本地有已发、在途、未知或未结历史的客户；发送时仍须在同一账本重新做并发检查。输出包含客户原话，属于客户私有数据，应只保存在项目内，不得放入通用核心或其他客户项目。

2026-10-28：只读当前15人批次得到15人/28条本人评论、15个本地UID、0本地历史阻断。旧46人批次得到46人/66条本人评论，其中31位已有本地受理回执被排除，剩15位进入AI输入。当前业务库只读统计1869客户、3069评论；1869个UID本地一致，57位有本人评论正文缺失或首尾格式异常，暂列待核，1812位具备AI输入基础。结合账本排除本地已发/未知/在途后得到1778位候选，逐人通过AI输入格式校验；这些数字都不代表已分析、可发送或平台实时身份/回复已核验。

运行隔离测试：`python -X utf8 -m unittest -v test_adapter`。
