"""Create offline, source-preserving human review exports; never writes input snapshots."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime
import json, re, hashlib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
OUT = ROOT / 'outputs' / '评论需求分类与校准'
OLD = BASE / 'old-snapshot.jsonl'
NEW = BASE / 'new-snapshot.jsonl'
REMAINDER = BASE / 'ledger-remainder.jsonl'
VERSION = '评论需求词面候选-20261029-v2'

def read(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]

def clean(value):
    if value is None: return '未记录'
    s = str(value).strip()
    if not s: return '未记录'
    s = re.sub(r'https?://\S+', '【链接已隐去】', s, flags=re.I)
    s = re.sub(r'(?<!\d)(?:\+?86[- ]?)?1[3-9]\d(?:[- ]?\d){8}(?!\d)', '【联系方式已隐去】', s)
    s = re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '【邮箱已隐去】', s)
    s = re.sub(r'(?i)(微信|vx|v信|威信|微)(?:号|:|：|是|加)?\s*[A-Za-z][A-Za-z0-9_-]{5,}', r'\1【联系方式已隐去】', s)
    s = re.sub(r'@[\w\u4e00-\u9fff_-]+', '【提及账号已隐去】', s)
    s = re.sub(r'\s+', ' ', s)
    return s

def safe_join(values, fallback='未记录'):
    out=[]
    for v in values:
        s=clean(v)
        if s!='未记录' and s not in out: out.append(s)
    return '；'.join(out) if out else fallback

def humanize_judgment(value):
    """Translate machine terms in judgments only, never customer or post text."""
    text = clean(value)
    terms = {'very_low':'很低意向','super_high':'超高意向','high':'高意向','medium':'中意向',
             'low':'低意向','graded':'已评估','unknown':'未知','uid':'客户身份',
             'root':'原帖','direct':'直接','unrelated':'无关','uncertain':'不确定',
             'supply':'供给','demand':'求租','historical':'历史需求',
             'active':'当时有需求','future':'未来需求','ended':'当时判断已结束'}
    pattern = r'(?<![A-Za-z_])(?:' + '|'.join(map(re.escape, terms)) + r')(?![A-Za-z_])'
    return re.sub(pattern, lambda m: terms[m.group().lower()], text, flags=re.I)

def labels(candidate):
    topics=candidate.get('topics') or []
    evidence=candidate.get('evidence') or []
    pairs=[]
    for topic in topics:
        hits=[]
        for item in evidence:
            if item.get('topic')==topic and item.get('quote') not in hits: hits.append(item.get('quote'))
        pairs.append(clean(topic)+'（'+safe_join(hits, '原词未记录')+'）')
    return '；'.join(pairs) if pairs else '未命中词面主题，仍可能有需求'

def warnings(text, candidates, refs, analyses):
    reasons=['词面候选未经逐条语义核对', '评论对象与当前需求仍需结合上下文核对']
    for cand in candidates:
        reasons.extend(cand.get('review_reasons') or [])
    if not any((r.get('parent_text') or '').strip() for r in refs): reasons.append('父评论未提供或无父评论，需核对')
    if not any((r.get('post_title') or '').strip() for r in refs): reasons.append('帖子标题缺失')
    if not any((r.get('post_text') or '').strip() for r in refs): reasons.append('帖子正文缺失或未提供')
    if re.search('转租|出租|房东直租|中介|推荐给你|需要租房吗',text): reasons.append('可能涉及供给或推荐，待核对')
    if re.search('已经租到|已经找到了|已租到|不用找|不找了|已解决',text): reasons.append('可能已结束，待核对')
    if re.search('不要|不考虑|不能|不接受|不养|不可以|拒绝',text): reasons.append('有否定或限制条件，待核对作用范围')
    if any(str(a.get('role','')).lower()=='supply' for a in analyses): reasons.append('原分析标记供给，待核对')
    if any(str(a.get('demand_state','')).lower() in ('closed','ended','historical') for a in analyses): reasons.append('原分析提示需求结束或历史时效，待核对')
    return safe_join(reasons)

def tags_versions(a):
    trans={'high':'高意向','super_high':'超高意向','medium':'中意向','low':'低意向','very_low':'很低意向','graded':'已评估','unknown':'未知','uncertain':'不确定','unrelated':'无关','demand':'求租','supply':'供给','mixed':'求租与供给混合','historical':'历史需求','current':'当前需求','active':'当时有需求','future':'未来需求','ended':'当时判断已结束','match':'匹配','other':'其他地区','needs_review':'待核','closed':'已结束'}
    return trans.get(str(a),clean(a))

def main():
    old=read(OLD);new=read(NEW);remainder=read(REMAINDER)
    for x in new:x['_export_source']='新分析快照'
    for x in remainder:
        x['_export_source']='账本补充记录'
        x['customer_uids']=[x['uid_from_local_observation']] if x.get('uid_from_local_observation') else []
    old_hi={x['platform_uid'] for x in old if x.get('observed_high_interest') and x.get('platform_uid')}
    new_hi={u for x in new if x.get('snapshot_high_or_super_high') for u in x.get('customer_uids',[]) if u}
    remainder_hi={u for x in remainder if x.get('snapshot_high_or_super_high') for u in x.get('customer_uids',[]) if u}
    # Never join records across ambiguous or missing identities.
    groups=defaultdict(lambda:{'old':[],'new':[]})
    for i,x in enumerate(old):
        uid=x.get('platform_uid');key=('xiaohongshu',uid) if uid and x.get('platform')=='xiaohongshu' else ('old_unresolved',i)
        groups[key]['old'].append(x)
    for i,x in enumerate(new+remainder):
        uids=x.get('customer_uids') or []
        key=('xiaohongshu',uids[0]) if len(uids)==1 and uids[0] else ('new_unresolved',i)
        groups[key]['new'].append(x)
    customer_records=[]; map_rows=[]; counts=Counter(); high_count=Counter()
    for number,(key,g) in enumerate(groups.items(),1):
        uid=key[1] if key[0]=='xiaohongshu' else None
        high=bool(uid and (uid in old_hi or uid in new_hi or uid in remainder_hi)) or any(x.get('observed_high_interest') for x in g['old']) or any(x.get('snapshot_high_or_super_high') for x in g['new'])
        origins=[]
        if uid in old_hi or any(x.get('observed_high_interest') for x in g['old']):origins.append('旧备份观察兴趣高')
        if uid in new_hi:origins.append('新快照曾评高或超高')
        if uid in remainder_hi:origins.append('账本补充中曾评高或超高，身份交叉待核')
        if not uid and any(x.get('snapshot_high_or_super_high') for x in g['new']):origins.append('历史高意向记录，身份关联待核')
        if not origins:origins=['其他已分析或待分析']
        rows=[]
        for x in g['old']:
            projection=(x.get('projection_original') or {}).get('customer') or {}
            for item in x.get('comments') or []:
                o=item.get('original_fields') or {};c=item.get('topic_candidate') or {}; ai=o.get('ai_intent') or {}
                text=o.get('text') or ''; refs=[{'post_title':o.get('content_title'),'parent_text':o.get('parent_text'),'post_text':''}]
                review=warnings(text,[c],refs,[{'role':(projection.get('storeEligibility') or {}).get('role'),'demand_state':projection.get('demandState')}])
                rows.append({'source':'旧备份','id':o.get('comment_id') or o.get('source_id') or o.get('id'), 'text':text,'candidates':[c], 'refs':refs,
                  'status':'客户历史判断：'+safe_join([tags_versions(projection.get('interestLevel')),tags_versions(projection.get('demandState')),humanize_judgment(projection.get('reason'))])+'；评论历史判断：'+safe_join([tags_versions(ai.get('level')),tags_versions(ai.get('status')),humanize_judgment(ai.get('reason'))]),
                  'region':'原地区字段：'+clean(o.get('region'))+'；原地域判断：'+tags_versions((projection.get('regionMatch') or {}).get('state'))+'；是否符合当前地点待核',
                  'time':'评论时间：'+clean(o.get('published_at'))+'；需求当前是否有效待核','review':review})
                counts['old_comment_observations']+=1
        for x in g['new']:
            refs=[z.get('data') or {} for z in x.get('input_observations') or []]
            variations=x.get('comment_text_variants') or ['']
            candidates=x.get('topic_candidates_by_text') or []
            analyses=[(a.get('analysis') or {}).get('result') or {} for a in x.get('analysis_versions') or []]
            for vi,text in enumerate(variations):
                c=candidates[vi] if vi<len(candidates) else {}
                vers=[]
                for a in analyses:vers.append('意向：'+tags_versions(a.get('interest'))+'，状态：'+tags_versions(a.get('demand_state'))+'，角色：'+tags_versions(a.get('role'))+'，原因：'+humanize_judgment(a.get('reason')))
                regions=['原分析：'+tags_versions(a.get('region'))+'（依据：'+('未知' if str(a.get('region_evidence')).strip().lower()=='unknown' else clean(a.get('region_evidence')))+'）' for a in analyses]
                times=[z.get('published_at') for z in refs if z.get('published_at')]
                review=warnings(text,[c],refs,analyses)
                if x.get('interest_conflict'):review+='；多版意向判断有冲突，需核对'
                if len(variations)>1:review+='；同一评论存在不同原文版本，需核对'
                rows.append({'source':x['_export_source']+('（原文版本分别保留）' if len(variations)>1 else ''),'id':x.get('comment_id'), 'text':text,'candidates':[c],'refs':refs,
                 'status':'历史分析：'+safe_join(vers,'尚无分析，待分析')+'；这些判断未经本人逐条确认',
                 'region':safe_join(regions,'地区未知')+'；当前地点待核',
                 'time':'评论时间：'+safe_join(times)+'；需求当前是否有效待核', 'review':review})
            counts['remainder_comment_observations' if x['_export_source']=='账本补充记录' else 'new_comment_observations']+=1
        if not rows:continue
        counts['customers']+=1; counts['comment_variants']+=len(rows)
        if high:high_count['customers']+=1;high_count['comment_variants']+=len(rows)
        for row in rows:
            cs=row['candidates'];topicset={t for c in cs for t in c.get('topics') or []}
            for t in topicset:counts['topic:'+t]+=1;high_count['topic:'+t]+=int(high)
            counts['unmatched']+=int(not topicset); high_count['unmatched']+=int(high and not topicset)
        map_rows.append({'export_customer_number':number,'identity_type':key[0],'uid':uid,'old_customer_ids':[x.get('customer_id') for x in g['old']],'new_comment_ids':[x.get('comment_id') for x in g['new']],'high_sources':origins,'comment_keys':[{'source':r['source'],'id':r['id']} for r in rows]})
        customer_records.append((high,origins,rows))
    def render(customer_records,high_only):
        out=['# 评论需求分类对照', '', '这是已有资料的离线词面候选，全部仍待结合原文与上下文核对；不是回复名单，也不代表房源、身份或现时需求已核实。', '同一客户多条评论保留；不同来源或不同原文版本分别展示。帖子和上级评论只用于理解上下文，不自动视为客户需求。', '原地区字段可能是账号地区或平台记录，不能当作本人明确求租地区。', '']
        for high,origin,rows in customer_records:
            if high_only and not high:continue
            out.extend(['────────────────────────','客户记录：'+'、'.join(origin)])
            for r in rows:
                refs=r['refs'];cs=r['candidates']; ts={t for c in cs for t in c.get('topics') or []}
                out.extend(['','资料来源：'+r['source'],'客户原评论：'+clean(r['text']), '帖子标题：'+safe_join([z.get('post_title') for z in refs]), '帖子正文：'+safe_join([z.get('post_text') for z in refs], '未记录'), '上级评论：'+safe_join([z.get('parent_text') for z in refs], '未记录或不适用'),
                  '主题候选及命中原词：'+safe_join([labels(c) for c in cs], '未命中词面主题，仍可能有需求'), '多主题：'+('是（仅词面候选）' if len(ts)>1 else '未发现多个词面主题，仍需核对'),r['status'],r['region'],r['time'],'需要核对：'+r['review']])
        return '\n'.join(out)+'\n'
    OUT.mkdir(parents=True,exist_ok=True)
    paths=[OUT/'高意向历史记录_评论分类对照.txt',OUT/'全部历史评论_分类对照.txt',OUT/'分类覆盖与校准说明.md',BASE/'export-map.jsonl',BASE/'export-verification.json']
    if any(p.exists() for p in paths):
        previous = json.loads(paths[4].read_text(encoding='utf-8')) if paths[4].exists() else None
        if not previous or any(not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=previous.get('output_file_sha256',{}).get(p.name) for p in paths[:3]):
            raise FileExistsError('Existing outputs differ from our verified prior run; preserve them.')
    hightext=render(customer_records,True);fulltext=render(customer_records,False)
    old_n=len(old);new_n=len(new); both=len(old_hi&new_hi); union=len(old_hi|new_hi)
    report='''# 评论需求分类与校准说明

这是一份用于和你逐类讨论口吻的离线初步整理，现有分类都是候选，需要结合真实评论和上下文逐条核对。不是可以直接回复的名单；今天没有采集或发送，也没有接入软件。

## 已整理范围

- 旧备份：{old_n} 位客户、{old_comments} 条评论；当时“观察兴趣高” {old_high} 位，其中古北门店当前高匹配的历史判断为 47 位。两种判断口径不同，不能互换。
- 新分析快照：{new_comments} 条不同评论，其中历史标记高或超高的 {new_high} 位客户。与旧备份对照，双方都出现 {both} 位，合并识别到 {union} 位；这只是两个快照的范围。
- 账本补充：两份快照外另有 {remainder_comments} 条账本评论，70 条找到历史分析、1 条未找到；其中 25 位曾被标为高意向。与前两份快照按本地记录的客户身份对照，有 1 位重合、新增 24 位，三份资料合计 481 位历史高或超高候选；其中 1 条存在高意向与不确定的不同判断，暂按曾评高保留待核。这不是全部高意向，也不表示都适合回复，本地身份尚未通过平台重新验证。
- 新分析快照中有 56 条尚待意向分析；账本补充中有 1 条未找到既有分析。这些都已保留在全部历史评论对照中，不能当作无意向或已完成审核。
- 账本共 5728 条评论，之前两份快照覆盖其中 5657 条，补充的 {remainder_comments} 条是其余部分；另有 12 条快照评论不在该账本。全部对照保留 {old_comments} 条旧评论、{new_comments} 条新快照记录和 {remainder_comments} 条账本补充记录。不同来源可能有重复评论；同一来源不同原文版本也分别显示，不能把展示条数当客户或独立评论总数。
- 高意向历史记录文件按客户身份包含三份资料中这些客户可找到的全部评论；每条展示来源、原评论、可得标题、正文与上级评论、候选主题、命中原词、历史意向判断及地域、时间和待核提示。多主题可并列，不自动认定主问题。

## 如何理解结果

本次词面分类使用 10 月 29 日的初步版本，仅对客户评论中的字词作候选提取，不理解完整语义；标题或上级评论仅作为人工核对材料。未命中不代表没有需求；已命中也不代表本人确有该需求，更不等于当前有效或可回复。原评估里的意向、地区和时间是历史判断，仍需分别复核；供给方、已经租到、否定条件、指代不清及需求已过期都需要单独看。

此前 32 条非随机难例中，修订版在所比较的12类主题集合中有 24 条一致、8 条遗漏；另有独立挑选的 22 条高候选难例中 11 条有明确主题遗漏，另 1 条可能存在状态缺口。两组都不是随机样本，不能代表总体准确率，也未覆盖全部业务维度。当前词面提取不足以定稿或直接用于自动话术，所有语义都待核。地名、楼层限制、房源是否租出、供给和否定范围等均可能漏判。全部对照包含的主题次数仅供查漏，可能重复，不应当作已确认需求人数。

## 待与你确认的分类方向

价格预算、位置通勤、户型面积与居住方式、配套及宠物、入住和租期、房源状态、费用合同、看房联系、人数与特殊条件，以及多需求综合。它们都只是讨论起点；现有自动词表未覆盖所有类别，后续结合真实评论调整。先一起校准少量母句，认可后再扩充，未经确认不自动生成和发送。

## 已知资料限制

旧资料记录的帖子正文缺失；新资料的标题、正文、父评论是否存在逐条展示。已有客户身份用于两快照内部对照，并不代表账号、优惠、门店房源或平台发送状态已核实。可能存在身份映射待核、历史状态冲突和原评论版本差异，保留原判断供复核。
'''.format(old_n=old_n,old_comments=counts['old_comment_observations'],old_high=len(old_hi),new_comments=counts['new_comment_observations'],new_high=len(new_hi),remainder_comments=counts['remainder_comment_observations'],both=both,union=union)
    paths[0].write_text(hightext,encoding='utf-8-sig');paths[1].write_text(fulltext,encoding='utf-8-sig');paths[2].write_text(report,encoding='utf-8-sig')
    paths[3].write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in map_rows),encoding='utf-8')
    result={'version':VERSION,'old_file_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_file_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'remainder_sha256':hashlib.sha256(REMAINDER.read_bytes()).hexdigest(),'old_high_uids':len(old_hi),'new_high_uids':len(new_hi),'remainder_high_uids':len(remainder_hi),'overlap_uids':both,'union_uids':union,'three_source_high_union_provisional':len(old_hi|new_hi|remainder_hi),'counts':dict(counts),'high_counts':dict(high_count),'output_file_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths[:3]},'ambiguous_groups':sum(k[0]!='xiaohongshu' for k in groups),'candidate_semantic_reviewed':False}
    assert counts['old_comment_observations']==sum(len(x.get('comments') or []) for x in old)
    assert counts['new_comment_observations']==len(new)
    assert counts['remainder_comment_observations']==len(remainder)
    assert high_count['customers']>=len(old_hi|new_hi|remainder_hi)
    assert all((x.get('uid') in old_hi or x.get('uid') in new_hi or x.get('uid') in remainder_hi) for x in map_rows if x['high_sources']!=['其他已分析或待分析'] and x['identity_type']=='xiaohongshu')
    paths[4].write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
