"""Opt-in single-page manual login capture; never collects or sends.

The browser is created here before any login starts. This cannot attach to an
already running browser. Platform verification is always performed by a person.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import urlsplit

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
LOGIN_URL='https://www.xiaohongshu.com/login'
IDENTITY_URL='https://edith.xiaohongshu.com/api/sns/web/v2/user/me'

def now(): return datetime.now(timezone.utc).isoformat()

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def manual_controller():
    root=PROJECT/'work/xhs-manual-login-resume-candidate-20261029'
    # The reused controller imports its sibling resume module.
    if 'resume' in sys.modules and Path(sys.modules['resume'].__file__).resolve()!=root/'resume.py':
        raise RuntimeError('dependency_module_conflict')
    sys.path.insert(0,str(root))
    return load_module('xhs_live_manual_controller',root/'entry.py').ManualResume

def make_identity_client(cookies,transport=None):
    path=PROJECT/'work/xhs-collection-candidate/collector.py'
    if hashlib.sha256(path.read_bytes()).hexdigest()!='108cce376ded3f17634bedc5d3ba2502af52fbf2b106116fba81ee2a7c48590f':
        raise RuntimeError('identity_dependency_changed')
    collector=load_module('xhs_live_identity_transport',path)
    class IdentityOnly(collector.ReadClient):
        _ALLOWED={('GET',IDENTITY_URL)}
    return IdentityOnly(dict(cookies),transport=transport,delay=1.0)

def write_new(path,value):
    with Path(path).open('x',encoding='utf8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.flush(); os.fsync(stream.fileno())

def save_session(home,cookies,identity):
    """No overwrite; CLI-compatible file, secret never included in a receipt."""
    home=Path(home)
    target_dir=home/'.xiaohongshu-cli'; target_dir.mkdir(exist_ok=True)
    target=target_dir/'cookies.json'
    temp=target_dir/'cookies.pending'
    if target.exists() or temp.exists(): raise RuntimeError('existing_session_no_overwrite')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'w',encoding='utf8') as stream:
            json.dump({**cookies,'saved_at':time.time()},stream)
            stream.flush(); os.fsync(stream.fileno())
        os.link(temp,target)  # Atomic publication which refuses an existing target.
        temp.unlink()
        write_new(home/'identity-receipt.json',{'uid':identity['uid'],'guest':False,
                  'verified_at':now(),'source':'same_page_session_single_identity_request',
                  'saved':True,'retry_allowed':False})
    except Exception:
        # A published session may exist; caller reports unknown and never retries.
        raise

def capture_once(page,home,*,client_factory=make_identity_client,expected_uid=None):
    logging.disable(logging.CRITICAL)
    controller=manual_controller()(page,client_factory,
                 lambda cookies,identity:save_session(home,cookies,identity),expected_uid)
    return controller.check(user_confirmed=True)

def private_directory(path):
    """Protect only a fresh, explicitly selected credential directory."""
    path=Path(path).resolve()
    path.mkdir(parents=True,exist_ok=False)
    if os.name=='nt':
        info=subprocess.run(['whoami','/user','/fo','csv','/nh'],capture_output=True,text=True,errors='replace',check=True)
        rows=list(csv.reader(info.stdout.strip().splitlines()))
        sid=rows[0][-1] if rows and rows[0] else ''
        if not sid.startswith('S-1-'): raise RuntimeError('private_directory_acl_unavailable')
        result=subprocess.run(['icacls',str(path),'/inheritance:r','/grant:r','*'+sid+':(OI)(CI)F',
                    '/grant:r','*S-1-5-18:(OI)(CI)F'],capture_output=True)
        if result.returncode: raise RuntimeError('private_directory_acl_unavailable')
    else:
        path.chmod(0o700)
    return path

class LoginWindow:
    """Passive browser events plus one explicit file-triggered identity check."""
    def __init__(self,page,home,*,client_factory=make_identity_client):
        self.page=page; self.home=Path(home); self.client_factory=client_factory
        self.attempted=False; self.saved=False
        self.challenge=False
        display=PROJECT/'work/qr-display-observer-20261029/qr_display.py'
        self.qr=load_module('xhs_live_qr_observer',display).QrDisplayObserver(
            self.home,on_update=self.qr_updated)
    def event(self,status,**fields):
        safe={'at':now(),'status':status,**fields}
        with (self.home/'events.jsonl').open('a',encoding='utf8') as stream:
            stream.write(json.dumps(safe,ensure_ascii=False)+'\n'); stream.flush(); os.fsync(stream.fileno())
        print(status,flush=True)
    def qr_updated(self,state):
        self.event('qr_updated',generation=state['generation'],image=state['image'],display_status=state['status'])
    def on_response(self,response):
        try:
            if response.frame.page is not self.page: return
            parsed=urlsplit(response.url)
            if (parsed.scheme!='https' or parsed.hostname not in
                    {'www.xiaohongshu.com','edith.xiaohongshu.com'} or parsed.port not in (None,443)):
                return
            self.qr.handle_response(response)
            if response.status in (461,471) and parsed.path.startswith('/api/'):
                self.challenge=True
                endpoint={
                    '/api/sns/web/v2/user/me':'identity',
                    '/api/sns/web/v1/search/onebox':'search_prewarm',
                    '/api/sns/web/v1/search/filter':'search_filter',
                    '/api/sns/web/v1/search/notes':'search',
                    '/api/sns/web/v1/feed':'note_detail',
                    '/api/sns/web/v2/comment/page':'comments',
                    '/api/sns/web/v2/comment/sub/page':'subcomments',
                }.get(parsed.path,'other_api')
                self.event('api_challenge_response_browser_kept_open',http_status=response.status,
                    endpoint=endpoint,visible_dialog='not_observed_by_network_listener')
        except Exception:
            self.event('browser_event_unavailable')
    def attach(self): self.page.on('response',self.on_response)
    def step(self):
        marker=self.home/'capture.flag'
        if self.attempted or not marker.exists(): return
        self.attempted=True
        try:
            if marker.is_symlink() or marker.read_text(encoding='utf8').strip()!='capture-current-page':
                self.event('capture_refused_invalid_confirmation'); return
            marker.rename(self.home/'capture.used')
        except Exception:
            self.event('capture_confirmation_unknown_no_retry'); return
        self.event('identity_check_started')
        result=capture_once(self.page,self.home,client_factory=self.client_factory)
        self.saved=result.get('status')=='saved'
        self.event(result.get('status','capture_stopped'))
        if self.saved: self.qr.invalidate('finished')

def run(home):
    logging.disable(logging.CRITICAL)
    home=private_directory(home)
    from camoufox.sync_api import Camoufox
    # No attach, no HTTP login fallback, no browser-cookie extraction.
    with Camoufox(headless=False) as browser:
        page=browser.new_page()
        window=LoginWindow(page,home); window.attach()
        window.event('login_window_opened')
        try:
            page.goto(LOGIN_URL,wait_until='domcontentloaded',timeout=45000)
        except Exception:
            window.event('initial_navigation_failed_browser_kept_open')
        try:
            while not page.is_closed():
                window.step()
                page.wait_for_timeout(250)
        except Exception:
            window.event('browser_event_loop_stopped')
        finally:
            window.qr.invalidate('finished')
            window.event('window_closed',session_saved=window.saved)
    return 0 if window.saved else 2

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-home',required=True)
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args(argv)
    if not args.execute:
        print(json.dumps({'mode':'preview','browser':False,'network':False,'credential_write':False}))
        return 0
    try: return run(args.run_home)
    except (Exception,KeyboardInterrupt):
        print('login_adapter_stopped',flush=True); return 1

if __name__=='__main__': raise SystemExit(main())
