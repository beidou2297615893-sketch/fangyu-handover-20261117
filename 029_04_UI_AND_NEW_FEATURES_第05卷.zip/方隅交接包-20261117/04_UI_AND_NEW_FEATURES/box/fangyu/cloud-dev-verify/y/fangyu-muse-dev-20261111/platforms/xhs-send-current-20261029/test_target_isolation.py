import json,hashlib,sqlite3,unittest
from contextlib import closing
from datetime import datetime,timezone
from types import SimpleNamespace
from dataclasses import asdict
import httpx
import bulk_run as bulk
import scoped_isolation as scope
import target_isolation as policy_module
import test_tone_batch as base
from managed_send_client import make_client
from prepare_logged_sender import load_cli


class Tests(unittest.TestCase):
    def setUp(self):
        self.fixture=base.Tests('test_receipt_qualified_137_allows_pending_and_cat_dedup_skips')
        self.fixture.setUp();q=self.fixture;self.b=q.base.base
        self.approval=q.approval
        approval=bulk.read_json(self.approval)
        approval['source_files']=[str(q.ready)];approval['source_hashes']=[bulk.digest(q.ready)]
        self.approval.write_text(json.dumps(approval),encoding='utf8')
        batch=bulk.read_json(q.batch);batch['source_sha256']['tone_approval']=bulk.digest(self.approval)
        q.batch.write_text(json.dumps(batch),encoding='utf8')
        self.authorization=self.b.root/'authorization.json'
        self.authorization.write_text(json.dumps({'source':'user_direct_current_turn','sender_uid':self.b.uid,
            'user_instruction':'isolate complete business rejections; never retry target',
            'known_prior_receipts':20,'known_prior_unknowns':2}),encoding='utf8')
        self.policy=policy_module.AuthorizedTargetIsolationPolicy.from_mapping({
            'schema':'xhs-authorized-target-isolation-batch-v1','policy_id':'synthetic-frozen-batch','sender_uid':self.b.uid,
            'original_batch_path':str(self.b.approved),'original_batch_sha256':bulk.digest(self.b.approved),
            'batch_sha256':bulk.digest(q.batch),'batch_count':137,'tone_approval_path':str(self.approval),
            'tone_approval_sha256':bulk.digest(self.approval),'history_manifest_path':str(q.base.exclusions),
            'history_manifest_sha256':bulk.digest(q.base.exclusions),'platform_state_path':str(self.b.state),
            'platform_state_sha256':bulk.digest(self.b.state),'halt_marker_path':str(self.b.marker),
            'halt_marker_sha256':bulk.digest(self.b.marker),'acknowledged_revocations':[{
                'path':str(q.base.revoked),'sha256':bulk.digest(q.base.revoked)}],
            'authorization_path':str(self.authorization),'authorization_sha256':bulk.digest(self.authorization)})
        with closing(sqlite3.connect(self.b.db)) as db:
            db.execute('INSERT INTO leads VALUES(?,?,?,?,NULL,NULL,NULL,?)',('xiaohongshu','customer-1','comment-1','unverified','synthetic'))
            db.commit()

    def tearDown(self):self.fixture.tearDown()

    def execute(self,mode='business',rollback_result=False,error_type=None):
        q=self.fixture;b=self.b
        session=b.root/'synthetic-isolation-session.json'
        session.write_text(json.dumps({'a1':'synthetic','webId':'synthetic','web_session':'synthetic'}),encoding='utf8')
        calls=[]
        def response(request):
            calls.append(request)
            if request.method=='GET':return httpx.Response(200,json={'success':True,'data':{'user_id':b.uid,'guest':False}},
                headers={'set-cookie':'[REDACTED:cookie_kv]; Path=/'})
            if json.loads(request.content)['target_comment_id']=='comment-0':
                if mode=='timeout':raise httpx.ReadTimeout('synthetic',request=request)
                if mode=='nonjson':return httpx.Response(200,text='not JSON')
                if mode=='missing_receipt':return httpx.Response(200,json={'success':True,'data':{}})
                return httpx.Response(200,json={'success':False,'code':-9131,'msg':'普通业务错误'},
                    headers={'verifyuuid':'synthetic-private'} if mode=='verification' else None)
            return httpx.Response(200,json={'success':True,'code':0,'data':{'comment':{'id':'synthetic-next-receipt'}}})
        adapter=bulk.LiveAdapter.__new__(bulk.LiveAdapter)
        adapter.sender=b.sender;adapter.expected_uid=b.uid;adapter.ledger=b.db;adapter.batch=bulk.read_json(q.batch)
        adapter.cli=load_cli();adapter.session=session;adapter.session_digest=bulk.digest(session)
        adapter.platform_access_state=b.state;adapter.platform_access_state_digest=bulk.digest(b.state)
        adapter.initial_identity_receipt=None;adapter._permanent_halt=False;adapter.halt_writer=bulk.atomic_platform_state
        adapter.scoped_isolation_policy=self.policy;adapter.post_attempts=0;adapter.last_client=None;adapter.token_cache={}
        adapter.identity=lambda:{'uid':b.uid,'guest':False}
        adapter.send_client=SimpleNamespace(make_client=lambda sender,path,plan:make_client(sender,path,plan,transport=httpx.MockTransport(response)))
        def submit(row):
            plan=adapter.cli.make_plan(b.sender,row,b.uid,adapter.batch['schema'])
            with adapter._client('send',plan) as client:
                try:return b.sender.Runner(b.db,client,synthetic=True,direct_id=True,scoped_isolation_policy=self.policy).submit(plan)
                finally:
                    adapter.post_attempts+=int(client._post_started)
                    if rollback_result and row['comment_id']=='comment-0':
                        with closing(sqlite3.connect(b.db)) as db:
                            record=json.loads(db.execute('SELECT data FROM local_sender_plans WHERE token=?',(row['attempt_id'],)).fetchone()[0]);record['result']=None
                            db.execute('UPDATE local_sender_plans SET data=? WHERE token=?',(json.dumps(record),row['attempt_id']));db.commit()
        adapter.submit=submit
        if error_type is not None:
            adapter.diagnostic=lambda exc:{'http_status':200,'success':False,'api_code':-1,
                'verification_header_present':False,'endpoint':'comment_post','request_started':True,
                'message_category':'unknown','error_type':error_type}
        rows=q.rows[:2]
        mapping={r['comment_id']:{'customer_uid':r['customer_uid'],'canonical_customer':r['customer_id'],
            'post_title':'available apartment','original_comment':'synthetic original','published_at':datetime.now(timezone.utc).isoformat()} for r in rows}
        report=bulk.run(rows,mapping,sender_uid=b.uid,session_home=b.root,run_dir=b.root/'run',execute=True,
            direct_id=True,adapter_factory=lambda root:adapter,interval=0)
        return report,calls,adapter

    def test_business_unknown_is_durably_verified_then_next_customer_posts_and_cookie_digest_matches(self):
        before=self.b.state.read_bytes(),self.b.marker.read_bytes(),self.fixture.base.revoked.read_bytes()
        report,calls,adapter=self.execute()
        self.assertEqual(report['status'],'complete');self.assertEqual(report['target_unknown_isolated'],1)
        self.assertEqual(report['accepted'],1);self.assertEqual(report['post_attempts'],2)
        self.assertEqual(adapter.session_digest,bulk.digest(adapter.session))
        self.assertIn('[REDACTED:cookie_kv]',next(r for r in reversed(calls) if r.method=='POST').headers['cookie'])
        self.assertEqual((self.b.state.read_bytes(),self.b.marker.read_bytes(),self.fixture.base.revoked.read_bytes()),before)
        self.assertEqual(load_cli().row_state(self.fixture.rows[0],load_cli().ledger_states(self.b.db)),'blocked')

    def test_complete_response_without_confirmed_native_unknown_never_continues(self):
        report,calls,_=self.execute(rollback_result=True)
        self.assertEqual(report['status'],'stopped_unknown');self.assertEqual(report['target_unknown_isolated'],0)
        self.assertEqual(sum(r.method=='POST' for r in calls),1)

    def test_incomplete_response_or_verification_stops_and_revokes(self):
        # Separate fixture for every failure, no cross-scenario state reuse.
        for mode in ('verification','timeout','nonjson','missing_receipt'):
            if mode!='verification':self.tearDown();self.setUp()
            report,calls,_=self.execute(mode)
            self.assertEqual(report['target_unknown_isolated'],0)
            self.assertEqual(sum(r.method=='POST' for r in calls),1)
            with self.assertRaises(bulk.Stop):bulk.require_platform_access(self.b.state,self.b.uid,
                scoped_grant=self.policy,batch_path=self.fixture.batch)

    def test_typed_restrictions_never_qualify_as_business_rejection_and_native_blocks(self):
        full={'http_status':200,'success':False,'api_code':-1,'verification_header_present':False,
              'endpoint':'comment_post','request_started':True,'message_category':'unknown'}
        for kind in ('NeedVerifyError','SessionExpiredError','IpBlockedError','SignatureError'):
            diagnostic={**full,'error_type':kind}
            self.assertFalse(policy_module.complete_business_rejection(diagnostic))
            with closing(sqlite3.connect(self.b.db)) as db:
                plan=self.fixture.plan
                data={'plan':asdict(plan),'result':{'kind':'unknown',**diagnostic}}
                db.execute('INSERT OR REPLACE INTO reservations VALUES(?,?,?,?,?,?,?)',(plan.attempt_id,'xiaohongshu',plan.canonical_customer,plan.comment_id,'unknown',None,30))
                db.execute('INSERT OR REPLACE INTO local_sender_plans VALUES(?,?)',(plan.attempt_id,json.dumps(data)));db.commit()
            next_plan=self.b.sender.SendPlan(**{**asdict(plan),'attempt_id':'batch-1','canonical_customer':'customer-1','customer_uid':'uid-1','comment_id':'comment-1','note_id':'note-1','text':'new approved 1'})
            with self.assertRaises(self.b.sender.Refused):self.b.sender._reserve(self.b.db,next_plan,True,direct_id=True,scoped_isolation_policy=self.policy)

    def test_each_explicit_error_type_halts_bulk_and_writes_new_revocation(self):
        for index,kind in enumerate(('NeedVerifyError','SessionExpiredError','IpBlockedError','SignatureError')):
            if index:self.tearDown();self.setUp()
            report,calls,_=self.execute(error_type=kind)
            self.assertEqual(report['target_unknown_isolated'],0)
            self.assertEqual(sum(r.method=='POST' for r in calls),1)
            self.assertEqual(bulk.read_json(self.b.state)['state'],'verification_response_unresolved')
            with self.assertRaises(bulk.Stop):bulk.require_platform_access(self.b.state,self.b.uid,
                scoped_grant=self.policy,batch_path=self.fixture.batch)
