# 回复字体、抖音空态与切页采集：只读定位

本次只读实际 stage-02/project/work/ui-approved-implementation/ui-preview；未改产品、未操作 UI、未请求平台或模型。按根要求将证据写在当前 cwd 的 `work/live-stop-repair/ui-audit`。

## 实际字体覆盖

真实回复入口是 `pages/reply.mjs` 转调 `pages/reply-connected.mjs`，不是预览 PEOPLE 数据。`canvas.html` 的加载顺序为 styles.css、各页 CSS（含 reply.css）、canvas-fit.css、管理 CSS、redesign.css、ai-model.css。

| 对象 | 实际 DOM | 现行最终 CSS | 最小建议 |
| --- | --- | --- | --- |
| 左边按帖分组标题 | reply-connected.mjs:23 `.rp-post-name strong` | canvas-fit.css:123 将 reply.css:73 的 22px 压成 16px | 22px，line-height 1.45，保留两行，字重 600 |
| 右边原帖标题 | reply-connected.mjs:47 `.rp-selected-source strong`，行内 16px | canvas-fit.css:123 的 13px!important 又压过行内字号 | 19–20px!important，line-height 1.5，正常换行 |
| 右边原评论正文 | reply-connected.mjs:46 `.rp-detail-copy p` | canvas-fit.css:123，15px/1.65 | 17px/1.65，保持可滚动上限，不截断来源 |
| 回复草稿 | reply-connected.mjs:50 `.rp-composer textarea` | canvas-fit.css:123，15px/1.7 | 14px/1.6，保留可输入/可滚动，不改正文 |

“放大原帖、缩小草稿”应落实在以上字体层级，而不再放大图片、整栏宽度或上下卡片尺寸。现行缩略图在同一 canvas-fit.css 被固定为 48×48!important；本需求可保持这一尺寸和原分栏。

最小可只改 canvas-fit.css 当前已有对应规则，避免再次叠加无效的低优先级 CSS。若移除 DOM 行内字号并改语义 class，也须同步处理现存 !important；单改 reply.css 或 DOM 行内 16px 不会生效。

## 抖音白色空态的准确位置

精确文案“当前没有符合条件的客户”只有 `pages/reply-connected.mjs:56` 的 `.rp-empty`，位于回复页左侧列表。客户页 customers.mjs 的空态文案是“还没有客户记录”，类名 `.cs-state-screen`。应避免只修客户页而漏掉用户看到的白块。

shell 已有 `data-platform="douyin"`（app.mjs:568）。redesign.css:14–15 已设抖音深色变量，并覆盖 .rp-post/.rp-editor，但没有 .rp-empty；reply.css:1 的 .rp-empty 仍使用 rgba(255,255,255,.94)。

建议在 redesign.css 内补抖音定域规则：

```css
.shell[data-platform=douyin] .rp-empty {
  background:var(--panel);border-color:var(--rule);color:var(--soft-ink);
}
.shell[data-platform=douyin] .rp-empty strong {color:var(--ink)}
```

同区需一并核对仍有白色底的 `.rp-composer` 外框、`.rp-editor-actions` sticky 背景、`.rp-comment`（尤其 is-selected）、`.rp-source-controls label` 字色、原评论文字和链接。可复用现有 --panel/--rule/--ink/--soft-ink，不引入新配色或视觉库；所有规则限 `.shell[data-platform=douyin]`，小红书保留浅色。不要统一给 .rp-empty 加深色。

## 页面切换是否取消采集

静态结论：前端普通导航/平台切换没有调用 pause、cancel 或 stop，不能把切页时状态停止刷新当成后台采集已终止。

- `app.mjs:29 navigate`：只改 page、hash、render、scroll；不改后台任务。
- `app.mjs:607–614 render`：会运行上一页 cleanup；真实 `acquire.mjs:124–163 bindConnected` 返回的 cleanup 只清前端 progressTimer。
- `app.mjs:569–586 switchPlatform`：保留各平台视图，递增请求 generation 并清前端轮询；未发 backend.pauseAcquisition 或 cancelAccount。
- 真暂停入口为 `app.mjs:493–501 pauseAcquisition`，由 acquire.mjs:142 附近的暂停按钮显式触发。
- `app.mjs:214 pollingScope` 只允许 accounts/acquire 页且窗口 visible；`syncPlatformPolling:252` 会在离开时清状态定时器，旧返回也会因 generation/scope 不同被丢弃。返回获客页后才重新刷新。因此切到回复/客户时任务快照可能停留，但这条路径本身不取消后端线程。

如根需保持跨页可见进度，最小方案是将任务状态刷新与当前页面分开，并只在相关页面重绘。不可只扩大 pollingScope 后无差别 render：`refreshPlatform:244` 当前仅排除 select/input 活跃焦点，没有排除 textarea；跨页每 3.5 秒重绘可能替换员工正输入的草稿节点，丢光标/选区。后台仅存快照、获客页再重绘更稳妥。

本审计未证明后端任务为何停止，也未检查服务器真实 lease 时间；应与其他代理取得的最新真实任务结果合并判断。不得据此清风险或放宽租约。

## 设计技能与执行边界

已实际读取并应用 `C:/Users/rmsama/.codex/skills/redesign-skill/SKILL.md` 的 Scan → Diagnose 及“现有栈、局部可审改动、保留功能”原则；同时读取 `C:/积木软件工坊/设计方法库/README.md` 与 `场景选择规则.md`。这是只读定位，不做新视觉方案、生图或产品实现，也不把静态代码审查说成真实视觉验收。当前目标无需新增组件库或框架。
