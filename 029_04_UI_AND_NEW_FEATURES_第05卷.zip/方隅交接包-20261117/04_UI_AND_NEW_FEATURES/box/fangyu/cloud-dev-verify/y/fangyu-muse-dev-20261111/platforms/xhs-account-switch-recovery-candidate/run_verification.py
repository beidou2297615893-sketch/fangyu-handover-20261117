"""Offline regression; imported original tests are executed in candidate storage."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import unittest

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import account_switch as candidate
candidate.dependencies()
sys.path.insert(0,str(candidate.PROJECT/'work/xhs-ai-standalone'))
sys.dont_write_bytecode=True
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['PYTHONPATH']=str(candidate.PROJECT/'work/xhs-collection-candidate')
suite=unittest.TestSuite()
for name in ('test_collection','test_register'):
    source=candidate.PROJECT/'work/xhs-collection-candidate'/(name+'.py')
    copied=HERE/('regression_'+name+'.py')
    if not copied.exists(): shutil.copyfile(source,copied)
    if copied.read_bytes()!=source.read_bytes(): raise RuntimeError('Regression copy mismatch')
    spec=importlib.util.spec_from_file_location('regression_'+name,copied)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
suite.addTests(unittest.defaultTestLoader.discover(str(HERE),pattern='test_account_switch.py'))
original_connect=socket.socket.connect
def deny(*args,**kwargs): raise AssertionError('Offline verification forbids network')
socket.socket.connect=deny
try:
    result=unittest.TextTestRunner(verbosity=2).run(suite)
finally:
    socket.socket.connect=original_connect
(HERE/'verification-result.json').write_text(json.dumps({'tests':result.testsRun,'success':result.wasSuccessful(),
    'failures':len(result.failures),'errors':len(result.errors),'platform_requests':0,
    'scope':'candidate tests plus exact copies of existing collector/register tests'},ensure_ascii=False,indent=2),encoding='utf8')
sys.exit(0 if result.wasSuccessful() else 1)
