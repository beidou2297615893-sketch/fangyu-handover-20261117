"""Read-only legacy checkpoint projection and a closed reviewed-step boundary.

This module never imports an existing runtime, opens a session/database, launches
commands, removes stops or executes a platform operation. Metadata is evidence,
never authorization. The default adapter has no executable implementation.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path


class MetadataRefused(ValueError):
    pass


class ExecutionRefused(RuntimeError):
    pass


REQUIRED_CONFIG = ('session_home', 'ledger', 'source_db', 'shared_ledger',
                   'max_comment_pages', 'task', 'operator', 'expected_uid', 'delay')
_ALLOWED_NAMES = {'state.json', 'task-config.json', 'STOP', 'stop-today.json',
                  'stop-today-resume007.json'}


def _metadata_path(path):
    path = Path(path).absolute()
    if path.name not in _ALLOWED_NAMES:
        raise MetadataRefused('only_named_task_metadata_allowed')
    for item in (path, *path.parents):
        if item.is_symlink() or getattr(item, 'is_junction', lambda: False)():
            raise MetadataRefused('redirected_metadata_path_refused')
    if path.resolve() != path:
        raise MetadataRefused('noncanonical_metadata_path_refused')
    return path


def _read_metadata(path, hashes):
    path = _metadata_path(path)
    if path.stat().st_size > 1024 * 1024:
        raise MetadataRefused('metadata_too_large')
    raw = path.read_bytes()
    hashes[str(path)] = hashlib.sha256(raw).hexdigest()
    value = json.loads(raw.decode('utf-8-sig'))
    if not isinstance(value, dict):
        raise ValueError('metadata_object_required')
    return value


def _config_value_valid(key, value):
    if key == 'shared_ledger':
        return value is True
    if key == 'max_comment_pages':
        return type(value) is int and 1 <= value <= 20
    if key == 'delay':
        return type(value) in (int, float) and math.isfinite(value) and value >= 10
    return isinstance(value, str) and bool(value.strip())


def _checkpoint_valid(state):
    plan, cursor, batch = state.get('plan'), state.get('cursor'), state.get('next_batch')
    if (not isinstance(plan, list) or not plan or type(cursor) is not int
            or not 0 <= cursor <= len(plan) or type(batch) is not int or batch < 1):
        return False
    entries = []
    for item in plan:
        if (not isinstance(item, dict) or set(item) != {'keyword', 'page'}
                or not isinstance(item['keyword'], str) or not item['keyword'].strip()
                or type(item['page']) is not int or not 1 <= item['page'] <= 100):
            return False
        entries.append((item['keyword'], item['page']))
    if len(set(entries)) != len(entries):
        return False
    inflight = state.get('inflight')
    if inflight is not None:
        if not isinstance(inflight, dict) or cursor >= len(plan):
            return False
        expected = plan[cursor]
        if (inflight.get('batch') != f'batch-{batch:04d}'
                or any(inflight.get(k) != expected[k] for k in ('keyword', 'page'))):
            return False
    return True


def inspect_checkpoint(parent, *, stop_paths=(), evidence_configs=()):
    """Project explicitly named local metadata; never infer missing settings.

    Extra configuration evidence must be explicit task-config.json files. Every
    nonidentical supplied value is a blocking conflict, not a last-writer win.
    SQLite reconciliation is deliberately absent: opening a live WAL database
    can interact with shared-memory files. A later reviewed adapter must supply
    its own tested ledger transaction contract; this preview cannot do so.
    """
    parent = Path(parent).absolute()
    # Validate all explicit paths before reading anything, including missing ones.
    state_path = _metadata_path(parent / 'state.json')
    config_paths = [_metadata_path(parent / 'task-config.json')]
    for item in evidence_configs:
        item = _metadata_path(item)
        if item.name != 'task-config.json':
            raise MetadataRefused('configuration_evidence_must_be_task_config')
        config_paths.append(item)
    markers = [_metadata_path(parent / 'STOP'), _metadata_path(parent / 'stop-today.json')]
    markers.extend(_metadata_path(item) for item in stop_paths)
    if any(p.name not in {'STOP', 'stop-today.json', 'stop-today-resume007.json'} for p in markers):
        raise MetadataRefused('stop_evidence_name_invalid')
    markers = list(dict.fromkeys(markers))
    hashes, unmet = {}, set()
    try:
        state = _read_metadata(state_path, hashes)
    except (OSError, ValueError, UnicodeError):
        state = {}
        unmet.add('metadata_missing_or_invalid')
    config, sources, conflicts = {}, {}, []
    for path in dict.fromkeys(config_paths):
        try:
            evidence = _read_metadata(path, hashes)
        except (OSError, ValueError, UnicodeError):
            unmet.add('metadata_missing_or_invalid')
            continue
        for key in REQUIRED_CONFIG:
            if key not in evidence:
                continue
            value = evidence[key]
            if key in config and (type(config[key]) is not type(value) or config[key] != value):
                conflicts.append(key)
            else:
                config[key] = value
                sources.setdefault(key, str(path))
    if conflicts:
        unmet.add('config_evidence_conflict')
    missing = [key for key in REQUIRED_CONFIG if key not in config]
    invalid = [key for key in REQUIRED_CONFIG if key in config and not _config_value_valid(key, config[key])]
    if missing:
        unmet.add('executor_config_incomplete')
    if invalid:
        unmet.add('executor_config_invalid')
    valid = _checkpoint_valid(state)
    if not valid:
        unmet.add('invalid_checkpoint')
    if state.get('status') == 'outcome_unknown':
        unmet.add('parent_outcome_unknown')
    if state.get('inflight') is not None:
        unmet.add('inflight_requires_reconciliation')
    if state.get('parent_unknown_preserved') is True:
        unmet.add('ancestor_outcome_unknown')
    if state.get('collection_authorized') is not True:
        unmet.add('collection_authorization_absent')
    present = []
    for marker in markers:
        if marker.exists():
            # Presence alone blocks; never infer clearance from a date/parse error.
            present.append(str(marker))
            unmet.add('stop_marker_present')
    for path, expected in tuple(hashes.items()):
        try:
            if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
                unmet.add('metadata_changed_during_inspection')
        except OSError:
            unmet.add('metadata_changed_during_inspection')
    unmet.update({'reviewed_platform_step_not_attached', 'ledger_reconciliation_not_supplied',
                  'live_identity_not_verified', 'cross_mode_owner_not_acquired'})
    revision = hashlib.sha256(json.dumps({'hashes': hashes, 'stops': present}, sort_keys=True).encode()).hexdigest()
    checkpoint = {key: state[key] for key in ('status', 'cursor', 'next_batch')
                  if key in state and type(state[key]) in (str, int)}
    inflight = state.get('inflight')
    checkpoint['inflight'] = ({key: inflight[key] for key in ('batch', 'keyword', 'page', 'remaining')
                              if key in inflight and type(inflight[key]) in (str, int)}
                             if isinstance(inflight, dict) else None)
    checkpoint['plan'] = [{key: entry[key] for key in ('keyword', 'page')
                           if key in entry and type(entry[key]) in (str, int)}
                          for entry in state.get('plan', []) if isinstance(entry, dict)] \
        if isinstance(state.get('plan'), list) else []
    return {'schema': 'xhs-readonly-checkpoint-review/1', 'parent_task': str(parent),
            'checkpoint': checkpoint, 'checkpoint_valid': valid, 'checkpoint_revision': revision,
            'executor_config': {key: value for key, value in config.items() if _config_value_valid(key, value)},
            'config_sources': sources, 'missing_config': missing,
            'invalid_config': invalid, 'conflicting_config': sorted(set(conflicts)),
            'stop_markers': present, 'source_hashes': hashes, 'unmet': sorted(unmet),
            'cannot_execute': True, 'can_collect': False, 'can_send': False,
            'automatic_retry': False, 'ledger_opened': False, 'session_read': False,
            'platform_requests': 0, 'read_only': True}


@dataclass(frozen=True)
class ReviewedStep:
    """Identity of a single reviewed operation; never a command or shell string."""
    operation_id: str
    mode: str
    checkpoint_revision: str

    def __post_init__(self):
        if (self.mode not in ('collect', 'send')
                or not all(isinstance(x, str) and x.strip() for x in (self.operation_id, self.checkpoint_revision))):
            raise ValueError('valid_reviewed_step_identity_required')


@dataclass(frozen=True)
class StepOutcome:
    """A future reviewed adapter must return durable evidence, not stdout success.

    The supervisor must recheck ledger/receipt evidence before advancing its
    checkpoint. Receipt acceptance does not establish public visibility.
    """
    operation_id: str
    status: str
    checkpoint_revision: str
    evidence_refs: tuple = ()


class ReviewedStepAdapter(ABC):
    @abstractmethod
    def review(self):
        """Read-only preconditions including current checkpoint/ledger evidence."""

    @abstractmethod
    def advance(self, step: ReviewedStep) -> StepOutcome:
        """One reviewed step with durable intent/reservation before external I/O.

        Implementations must hold one shared collect/send owner for the entire
        step, compare checkpoint revision, preserve ledger dedup/reservations,
        and persist a terminal outcome. Death without terminal evidence is
        outcome_unknown. They must never retry send POST or reinterpret a
        reservation/unknown as not_sent. This class attaches no implementation.
        """


class BlockedCheckpointAdapter(ReviewedStepAdapter):
    def __init__(self, parent, *, stop_paths=(), evidence_configs=()):
        self.parent = parent
        self.stop_paths = tuple(stop_paths)
        self.evidence_configs = tuple(evidence_configs)

    def review(self):
        return inspect_checkpoint(self.parent, stop_paths=self.stop_paths,
                                  evidence_configs=self.evidence_configs)

    def advance(self, step: ReviewedStep) -> StepOutcome:
        raise ExecutionRefused('reviewed_platform_step_not_attached; cannot_execute')
