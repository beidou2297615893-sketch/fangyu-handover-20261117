# 只读采集安全停机候选

这是未接入生产的离线候选。它改善平台拒绝与会话变化时的停止及诊断，**不解除真实平台限流，不自动恢复采集，也没有恢复 Cookie 持久化能力**。没有真实平台请求、浏览器操作、凭据导出或既有会话写入。

## 已实现

- 继承原 `collector.ReadClient`，保留原传输、签名、UA、只读接口白名单和零重试策略。
- 461/471 归类为 `restriction_or_verification_required`。仅保存 `verifytype`/`verifyuuid` 是否存在的布尔值，不保存原值，不推断验证码或限流原因。若同一响应带 Cookie 更新，461/471 仍为首要停止原因。
- 200 响应的普通合法 Cookie 更新在临时内存副本中按上游合并行为比较；发现变化立即停止当前读取，并锁定该客户端。原 `client.cookies` 不变，下一次读取不发请求。同值更新可正常读取；删除、过期、外域、范围不适合现有扁平 Cookie 字典、格式不明等情形保守停止。
- 请求前后检查原内存会话及既有 `_independent_session_guard`。未删除或修改原 `account_switch` 的整字典、外部文件、UID、游客状态和登记前身份检查。
- 超时已发起请求时记录 `request_started=true`；本地接口拒绝记录为 false。HTTP200 平台错误仍保留已白名单化的 `SessionExpiredError/-100`、`XhsApiError/300013`、响应形状和 prewarm 安全诊断。

本候选没有重新绑定、登录、清除锁定、保存会话或自动继续接口。Cookie 更新的处理是明确停机与要求受管会话重新核验，不能称为“正常更新已经无缝恢复”。旧 `cookie-tests/README.md` 中讨论的自动接续方向不属于本次实现。

## 未来集成接口

文件：`safe_stop_rebind.py`。

- `ReadClient(cookies, transport=None, delay=1.0)` 与原只读客户端构造参数一致。原调用方须继续保留依赖校验、同一客户端的账号绑定流程及现有文件 guard，不能仅换客户端后删除这些保护。
- `SafeReadStop` 继承原 `collector.Halt`，会传播出原预热/HTML 回退路径，停止本批。
- `safe_stop_diagnostic(exc)` 返回封闭白名单诊断，只有固定类别、已知错误类型、整数状态/错误码、布尔值及已知信号标签，无任意响应文本或凭据。

**旧 `account_switch.safe_failure()` 会过滤掉新增分类和布尔字段。** 未来接入必须在该失败记录函数捕获到 `SafeReadStop`、尚未包装为批次错误时，使用 `safe_stop_diagnostic(exc)` 填入原诊断账本结构。本次没有修改原失败记录函数或任何生产入口，因此当前软件不会因本目录存在而改变行为。

停止后继续保留原数据、已登记数和未登记批次状态；何时取得官方解除限制信号、如何正常重绑受管会话，以及同 UID 的前后验证，仍由既有受管流程负责。不能靠创建新客户端规避停止状态。

## 验证证据与边界

- `red-original-behavior.txt`：实现前对原读取器运行首批 14 项期望行为测试，19 个含子测试的断言失败，证明缺失行为。
- `red-regression-review.txt`：独立审查后增补回归测试，修复前 17 项中 3 个子断言失败，涉及超时状态与 HTTP200 API 错误类型。
- `green-candidate.txt`：最终 **17 项测试全部通过**，真实 `httpx.MockTransport`，同时禁止 socket 连接；主窗口另已独立重跑通过，Astra 源码复审无阻断。
- `source-manifest.json`：记录原依赖与冻结候选/测试文件的 SHA-256。

测试覆盖原 `run_batch()` 在响应 Cookie 变化后不绑定账号、不登记数据；内存/文件 guard 保留；客户端停止后不再请求。测试中的无关 checkpoint 文件未变，仅证明本候选不写该文件，**不证明完整调度器分页断点恢复**。本候选未接真实调度器、软件 UI、持久会话库或生产失败记录链路。

主任务另有官方原帖页面 `300013 / Too many requests` 的独立证据，当前实际限制据此记录；该结论不能从本候选的 461 分类推导。离线测试通过不能证明平台限制已解除。

项目根目录的重跑命令：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest discover -s 'work/xhs-461-rootcause-20261029/repair' -p 'test_safe_stop_rebind.py' -v
```

完整目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-461-rootcause-20261029\repair`。
