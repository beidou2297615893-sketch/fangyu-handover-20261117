import sqlite3,json,pathlib,datetime
b=pathlib.Path('.');a=json.loads((b/'active-runner.json').read_text(encoding='utf-8-sig'));p=json.loads((b/a['plan']).read_text(encoding='utf-8-sig'));policy=json.loads((b/'runner-audit-myeaj720/runner-qualification-policy.json').read_text(encoding='utf-8-sig'));accounts=set(p['collection_accounts']);approved=set(policy['qualified_request_ids']);ids=set();db=sqlite3.connect('file:runtime/collection.sqlite3?mode=ro',uri=True);db.row_factory=sqlite3.Row
for r in db.execute("select request_id,spec,response from attempts where state='parsed'"):
 s=json.loads(r['spec']);e=s.get('eligibility');e=e if isinstance(e,dict) else {}
 if s.get('account_uid') in accounts and s.get('kind')=='comments' and (e.get('state')=='eligible' or (s.get('account_uid')==policy['account_uid'] and r['request_id'] in approved)):
  for x in (json.loads(r['response']).get('value',{}).get('comments') or []):
   if x.get('cid') is not None:ids.add(str(x['cid']))
control=json.loads((b/a['directory']/'control.json').read_text(encoding='utf-8-sig'));latest=[dict(r) for r in db.execute("select request_id,collected_at,state,added,json_extract(spec,'$.kind') kind from attempts where json_extract(spec,'$.account_uid')=? order by rowid desc limit 3",(p['account_uid'],))];halts=[dict(r) for r in db.execute('select request_id,state,detail from account_halts where account_uid=?',(p['account_uid'],))]
out=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualified_comments=len(ids),new_since_resume=len(ids)-34842,stopped=control['stopped'],pending_phase=(control.get('pending')or{}).get('phase'),current_account_halts=halts,latest=latest)
(b/'resume-20261101-outcome.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=True))
