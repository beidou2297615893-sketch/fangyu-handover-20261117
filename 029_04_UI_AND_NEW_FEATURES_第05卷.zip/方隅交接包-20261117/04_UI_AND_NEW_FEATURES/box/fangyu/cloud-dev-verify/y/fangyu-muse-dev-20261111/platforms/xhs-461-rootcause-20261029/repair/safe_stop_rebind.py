"""Isolated, opt-in safe stopping; no login, rebind, export, or resume capability.

The original transport, signing, headers, endpoint allowlist, immutable account
guard and external session-file guard remain in force. Cookie updates require a
new independently verified managed session, never an automatic continuation.
"""
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from http.cookies import CookieError, SimpleCookie
import json
from types import MappingProxyType, SimpleNamespace
from urllib.parse import urlsplit

import httpx
from collector import ReadClient as OriginalReadClient, Halt, LocalRequestRejected
from xhs_cli.client import XhsClient

_CATEGORIES = frozenset({
    'restriction_or_verification_required', 'session_update_requires_rebind',
    'cookie_update_requires_review', 'session_changed_no_retry',
    'independent_session_file_changed', 'request_failed_no_retry',
})
_STAGES = frozenset({'identity', 'search', 'comments', 'unknown'})
_ENDPOINTS = frozenset({'identity', 'prewarm_onebox', 'prewarm_filter',
                      'search_notes', 'recommend', 'comments', 'unknown'})
_ERROR_TYPES = frozenset({'HTTPError', 'Timeout', 'NetworkError', 'ReadFailure',
    'XhsApiError', 'NeedVerifyError', 'SessionExpiredError', 'IpBlockedError',
    'SignatureError', 'OtherPlatformError'})
_PREWARM_FLAGS = frozenset({'optional_prewarm_endpoint', 'exact_base_error', 'http_ok',
    'verification_header_present', 'payload_is_object', 'allowed_fieldset',
    'success_false', 'integer_code_zero', 'data_empty', 'messages_empty',
    'messages_known_success_only'})
_MESSAGE_SIGNALS = frozenset({'empty', 'safety_verification', 'rate_limit', 'login',
    'network', 'invalid_parameter', 'service_unavailable', 'not_supported',
    'success_text', 'other'})


def _allowed(value, choices):
    return isinstance(value, str) and value in choices


def _clean(detail):
    """Closed diagnostic schema: no arbitrary text, URLs, Cookie or header values."""
    result = {'category': detail.get('category') if _allowed(detail.get('category'), _CATEGORIES)
              else 'request_failed_no_retry', 'retry_allowed': False,
              'resume_automatically': False}
    for key, allowed in (('stage', _STAGES), ('endpoint', _ENDPOINTS)):
        result[key] = detail.get(key) if _allowed(detail.get(key), allowed) else 'unknown'
    for key in ('request_started', 'verify_type_present', 'verify_uuid_present',
                'server_cookie_update_present'):
        if type(detail.get(key)) is bool:
            result[key] = detail[key]
    status = detail.get('http_status')
    if type(status) is int and 100 <= status <= 599:
        result['http_status'] = status
    # Preserve the original collector's typed platform diagnostics, never its text.
    error = detail.get('error_type')
    result['error_type'] = error if _allowed(error, _ERROR_TYPES) else (
        'HTTPError' if status is not None and status != 200 else 'ReadFailure')
    code = detail.get('api_code')
    if type(code) is int and -1000000000 <= code <= 1000000000:
        result['api_code'] = code
    for key in ('success_type', 'code_type', 'data_type'):
        if _allowed(detail.get(key), {'null', 'boolean', 'number', 'string',
                                     'object', 'array', 'other', 'missing'}):
            result[key] = detail[key]
    if type(detail.get('success_value')) is bool:
        result['success_value'] = detail['success_value']
    prewarm = detail.get('prewarm_conditions')
    if isinstance(prewarm, dict):
        safe = {key:prewarm[key] for key in _PREWARM_FLAGS if type(prewarm.get(key)) is bool}
        count = prewarm.get('unknown_field_count')
        if type(count) is int and 0 <= count <= 1000000:
            safe['unknown_field_count'] = count
        signals = prewarm.get('message_signal_categories')
        if isinstance(signals, list):
            safe['message_signal_categories'] = [value for value in signals[:10]
                if _allowed(value, _MESSAGE_SIGNALS)]
        result['prewarm_conditions'] = safe
    return result


class SafeReadStop(Halt):
    def __init__(self, detail):
        self.detail = MappingProxyType(_clean(detail))
        super().__init__(json.dumps(dict(self.detail), ensure_ascii=False))


def safe_stop_diagnostic(exc):
    """For a future caller's failure sink; the old sink drops these new fields."""
    return _clean(dict(exc.detail)) if isinstance(exc, SafeReadStop) else _clean({})


def _path_matches(request_path, cookie_path):
    return request_path == cookie_path or (request_path.startswith(cookie_path)
        and (cookie_path.endswith('/') or request_path[len(cookie_path):].startswith('/')))


class ReadClient(OriginalReadClient):
    """Stop on restrictions or cookie changes. A stopped instance cannot resume."""
    def __init__(self, cookies, transport=None, delay=1.0):
        super().__init__(cookies, transport=transport, delay=delay)
        self._original_cookie_container = self.cookies
        self._initial_snapshot = dict(self.cookies)
        self._locked_detail = None
        self._observed_response = None
        self._http.event_hooks['response'].append(self._observe_response)

    def _observe_response(self, response):
        # In-process observation only: no second request, redirects or body read.
        self._observed_response = response

    def _stop(self, category, *, response=None, request_started=False,
              platform_detail=None, **metadata):
        detail = {**(platform_detail if isinstance(platform_detail, dict) else {}),
                  'category': category, 'stage': self._last_stage,
                  'endpoint': self._last_endpoint_kind, 'request_started': request_started,
                  **metadata}
        if response is not None:
            detail['http_status'] = response.status_code
        self._locked_detail = _clean(detail)
        self.last_failure_detail = dict(self._locked_detail)
        raise SafeReadStop(self._locked_detail) from None

    def _assert_guards(self, request_started=False):
        if self._locked_detail is not None:
            raise SafeReadStop(self._locked_detail) from None
        if self.cookies is not self._original_cookie_container or self.cookies != self._initial_snapshot:
            self._stop('session_changed_no_retry', request_started=request_started)
        check = getattr(self, '_independent_session_guard', None)
        if check is not None:
            try:
                check()
            except Exception:
                self._stop('independent_session_file_changed', request_started=request_started)

    def _cookie_effect(self, response):
        """Return unchanged/changed/review; never install a response session.

        Flattening arbitrary scoped cookies would be unsafe. For this temporary
        flat-jar adapter, only scopes covering every allowed API path are known;
        narrower, ambiguous, duplicate or malformed headers require review.
        """
        raw_headers = response.headers.get_list('set-cookie')
        if not raw_headers:
            return 'unchanged'
        request = response.request.url
        if (response.request.method, str(request.copy_with(query=None, fragment=None))) not in self._ALLOWED:
            return 'review'
        allowed_paths = {urlsplit(url).path for _, url in self._ALLOWED}
        seen = set()
        for raw in raw_headers:
            if len(raw) > 8192:
                return 'review'
            try:
                parsed = SimpleCookie()
                parsed.load(raw)
            except CookieError:
                return 'review'
            if len(parsed) != 1:
                return 'review'
            name, item = next(iter(parsed.items()))
            if name in seen:
                return 'review'
            seen.add(name)
            domain = item['domain'].lstrip('.').lower()
            if domain and domain not in {request.host, 'xiaohongshu.com'}:
                return 'review'
            scope = item['path'] or request.path.rsplit('/', 1)[0] or '/'
            if not all(_path_matches(path, scope) for path in allowed_paths):
                return 'review'
            if not item.value:
                return 'changed'
            if item['max-age']:
                try:
                    lifetime = int(item['max-age'])
                except ValueError:
                    return 'review'
                if lifetime <= 0:
                    return 'changed'
            elif item['expires']:
                try:
                    expires = parsedate_to_datetime(item['expires'])
                    if expires.tzinfo is None:
                        expires = expires.replace(tzinfo=timezone.utc)
                except (ValueError, TypeError, OverflowError):
                    return 'review'
                if expires <= datetime.now(timezone.utc):
                    return 'changed'
        # Use the installed upstream merge to compare nonempty normal updates.
        # It runs on a temporary copy and never touches this client's session.
        comparison = SimpleNamespace(cookies=dict(self._initial_snapshot))
        try:
            XhsClient._merge_response_cookies(comparison, response)
        except Exception:
            return 'review'
        return 'changed' if comparison.cookies != self._initial_snapshot else 'unchanged'

    def _request_with_retry(self, method, url, **kwargs):
        self._assert_guards()
        self._observed_response = None
        try:
            try:
                response = super()._request_with_retry(method, url, **kwargs)
            except Halt as exc:
                response = self._observed_response
                if response is not None and response.status_code in (461, 471):
                    self._stop('restriction_or_verification_required', response=response,
                        request_started=True,
                        verify_type_present='verifytype' in response.headers,
                        verify_uuid_present='verifyuuid' in response.headers)
                context = exc.__context__
                error = ('Timeout' if isinstance(context, httpx.TimeoutException) else
                         'NetworkError' if isinstance(context, httpx.HTTPError) else None)
                self._stop('request_failed_no_retry', response=response,
                    request_started=not isinstance(exc, LocalRequestRejected),
                    error_type=error)
            self._assert_guards(request_started=True)
            effect = self._cookie_effect(response)
            if effect != 'unchanged':
                self._stop('session_update_requires_rebind' if effect == 'changed'
                    else 'cookie_update_requires_review', response=response,
                    request_started=True, server_cookie_update_present=True)
            return response
        finally:
            self._observed_response = None

    def _handle_response(self, response):
        try:
            return super()._handle_response(response)
        except Halt:
            self._stop('request_failed_no_retry', response=response, request_started=True,
                       platform_detail=self.last_failure_detail)
