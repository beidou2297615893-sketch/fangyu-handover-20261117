import csv,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import run as m
out=m.ROOT/'outputs/小红书分析结果';out.mkdir(parents=True,exist_ok=True)
inputs={r['comment_id']:r for r in m.prepare()};results=m.load(m.OUT/'analysis.json')
intent={'super_high':'超高意向线索','high':'高意向线索','medium':'中意向线索','low':'低意向线索','very_low':'很低意向线索','uncertain':'信息不足待核','unrelated':'未见本人租房需求'}
role={'demand':'需求方','supply':'房源提供或推广方','mixed':'身份混合待核','unknown':'身份不明'}
timing={'active':'当前需求线索','future':'未来需求线索','historical':'历史需求待核','unknown':'当前是否仍找房未知','ended':'需求已结束线索','unrelated':'未见租房需求'}
rank={k:i for i,k in enumerate(intent)}
def human(item):
 r=inputs[item['comment_id']];a=item['result'];source=a['region_source'];region=a['region']
 if source in ('title','post'):geo='仅帖子地区线索，未确认本人找房区域'
 elif source=='parent':geo='仅对话地区线索，需核对本人需求'
 elif source=='own':geo={'match':'本人原话含古北线索，具体门店适配待核','other':'本人提到其他地区','unknown':'本人找房地区不明','conflict':'本人地区说法存在冲突'}[region]
 else:geo='本人找房地区不明'
 return {'帖子标题':r.get('post_title',''),'评论内容':r['comment_text'],'初筛意向':intent[a['interest']],'需求角色':role[a['role']],'需求时效':timing[a['demand_state']],'地区判断':geo,'地区原话依据':a['region_evidence'],'正文状态':'正文尚未补齐','判断说明':a['reason'],'待核信息':'；'.join(a['unknown']),'回复状态':'未发送，未形成可发送名单'}
for name,ordered in [('按意向查看.csv',sorted(results,key=lambda x:(rank[x['result']['interest']],x['note_id'],x['comment_id']))),('按帖子查看.csv',sorted(results,key=lambda x:(inputs[x['comment_id']].get('post_title',''),x['note_id'],rank[x['result']['interest']],x['comment_id'])))]:
 with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(human(ordered[0])));writer.writeheader();writer.writerows(human(x) for x in ordered)
(out/'阅读说明.txt').write_text('本次已完成887条评论的本地初筛。超高意向线索1条，高意向线索94条，中意向14条，低意向4条，很低意向1条，信息不足待核194条，未见本人租房需求579条。\n\n这些是评论记录数，不等于客户人数，也不等于可回复人数。全部887条尚缺完整帖子正文，模型依据本人评论、现有标题和对话信息先行分级。古北出现在帖子标题里，不代表评论者本人就在古北找房；地区、需求时效、身份和房源适配仍须核对。\n\n“未见本人租房需求”包括大量房源提供和推广评论；信息不足与不相关分开保留。没有自动发送，也没有形成发送名单。\n\n按意向查看和按帖子查看是同一批887条资料的两种排序，不能相加。此前已完成的55条评论没有重复纳入。\n',encoding='utf-8-sig')
print(str(out))
