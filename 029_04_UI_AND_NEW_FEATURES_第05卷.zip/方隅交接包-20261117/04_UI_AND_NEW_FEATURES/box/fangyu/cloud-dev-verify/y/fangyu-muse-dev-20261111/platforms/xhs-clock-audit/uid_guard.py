"""Optional local dedupe guard. Caller MUST hold BEGIN IMMEDIATE through reservation."""
import json


class Blocked(RuntimeError): pass


def check_in_transaction(db, platform, uid, canonical, comment):
    """Check known attempts by platform user and comment, without claiming other accounts are covered.

    `db.in_transaction` only establishes a transaction exists; the caller must actually
    start BEGIN IMMEDIATE and keep it open through insertion. This function does not send.
    """
    if not db.in_transaction:
        raise Blocked('must check inside the same transaction as the reservation')
    if any(not isinstance(x,str) or not x.strip() for x in (platform,uid,canonical,comment)):
        raise Blocked('identity fields are required')
    row=db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',(platform,uid)).fetchone()
    if row and row[0]!=canonical:
        raise Blocked('platform user has conflicting customer mapping')
    rows=db.execute("SELECT r.customer,r.comment,r.status,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown','sent')",(platform,)).fetchall()
    for old_canonical,old_comment,status,payload in rows:
        if old_canonical==canonical or old_comment==comment:
            raise Blocked('customer or comment has an existing attempt')
        if not payload:
            raise Blocked('legacy reservation identity not available')
        try:
            data=json.loads(payload)
            old_uid=data['plan']['customer_uid']
            if not isinstance(old_uid,str) or not old_uid:raise ValueError('missing uid')
        except (ValueError, TypeError, KeyError, AttributeError):
            raise Blocked('prior reservation identity cannot be read') from None
        if old_uid==uid:
            raise Blocked('platform user already has an existing attempt')
