# 方隅小红书 resume007 离线验收笔记

## 产出
`/workspace/project-intake/fangyu/review/xhs-resume007-out/`  
含 `resume007.py`、`tests/`、`ACCEPTANCE.md`。**未改** `xhs-resume007-src/`（T6 SHA 与基线一致）。

## 修订记录（2026-11-09 审查后）
| # | 审查点 | 处理 |
|---|--------|------|
| 1 | 执行期加锁 | **已实现**：`session_home/.managed-use.lock` mkdir 原子锁 + `owner.json`，`finally` 释放；预置锁 → `active_lock`。先锁后建 ROOT。测试见 `test_lock.py` |
| 2 | inflight 回落 index 0 | **已修**：batch-0023 词页未命中 plan → `None` → `prior_state_changed`。测试见 `test_inflight_index.py` |
| 3 | 去重装饰性 | **运行时包装** `once.history_index` 强制纳入 `RESUME006_ROOT`（不改 src）。删装饰 bootstrap 无用结果。T3 真 sqlite 双跑断言 `(customer,comment)` 不增。入账去重同时靠账本已有行 |
| 4 | max-comment-requests-per-batch | **已删除**：生效需改 runner LiveExecutor argv（属 src），故去掉参数；勿传 |
| 次 | 重复分支 | `_validate_prior_state` 收紧为必须 `batch==batch-0023` 且词页命中 |
| 次 | continuation-receipt 计数 | 读 `RESUME006_ROOT/continuation-receipt.json`；缺省则 3566/30 并记 `prior_counts_source` |
| 次 | stop-today | **仅 resume007 写入**；resume006 历史 461 **不**自动算今日停。登录后可试一次，再遇 461 则当天停 |

## 测试
```bash
cd /workspace/project-intake/fangyu/review/xhs-resume007-out
python3 -m unittest discover -s tests -v
# Ran 24 tests … OK
```
T1–T7 + lock + inflight 全过。

## 模型
- DeepSeek `deepseek-v4-pro`：初稿 1 次（`方隅负责人-xhs-resume007`）+ 修订起草 1 次（`方隅负责人-xhs-resume007-fix`）
- 本窗审改锁顺序/删装饰调用/补测试与 fake 账本写入
- **未用** OpenAI

## 仅 fake / 用户机复测
1. integration sha256 源码替换加载  
2. ManagedClient `/user/me` 真身份  
3. 真实 ReadClient delay  
4. 真共享账本 batch-0023=0 与 continuation-receipt 现场值  
5. 包装后的 `history_index` 在真实 `once.main` 路径下扫描 resume006 partial（box 用 FakeOnce 验证 roots 含 r6）  
6. 进度面板未实现（可选）  
7. 进程枚举「无其他 resume00x」未做（仅锁文件）

## stop-today 语义（重申）
今日停线标记只由 **本入口** 在执行期遇 461/验证停时写入。历史 resume006 的 461 **不会**阻止当天首次 resume007；若本次再 461，则当天不可再启。

## 修订 2026-11-09 16:3x（小红书链路复审）
- refresh_paths 默认 PROJECT 由 parents[1]（误为 R\work）改为 parents[2]（=R），与 L14 一致。
- 新增 tests/test_default_paths.py：不设任何 XHS_RESUME007_* 环境变量，按 R/work/<task>/ 假目录结构断言 PROJECT/HERE/LEDGER/RESUME006_ROOT。
- 更正：integration L77 已把 HERE/runtime/live-tasks 纳入 roots，resume006 ROOT 原本即被扫描；resume007 的 history_index 包装冗余但无害（路径 setdefault 合并、ID 集合去重）。
- 18:08 用户在小红书链路窗口定 delay=10 秒：--delay 默认改为 10.0（≤3.0 仍拒绝）；测试 fake 内部 delay 不影响。
