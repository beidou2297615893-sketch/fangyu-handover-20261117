import unittest
from entry import ManualResume

class FakeContext:
    def __init__(self):
        self.items=[{'name':'a1','value':'a','domain':'.xiaohongshu.com'},
                    {'name':'webId','value':'w','domain':'.xiaohongshu.com'},
                    {'name':'web_session','value':'s','domain':'.xiaohongshu.com'}]
    def cookies(self): return [dict(x) for x in self.items]
class FakePage:
    def __init__(self): self.context=FakeContext();self.closed=False
    def is_closed(self): return self.closed
class FakeClient:
    def __init__(self, cookies): self.cookies=dict(cookies);self.calls=0;self.closed=False
    def get_self_info(self): self.calls+=1;return {'user_id':'u123','guest':False}
    def close(self): self.closed=True
class EntryTest(unittest.TestCase):
    def test_manual_check_saves_only_after_single_identity_read(self):
        page=FakePage();clients=[];saved=[]
        def factory(c):
            client=FakeClient(c);clients.append(client);return client
        flow=ManualResume(page,factory,lambda c,i:saved.append((c,i)))
        self.assertEqual(flow.check(user_confirmed=False),{'status':'awaiting_user'})
        self.assertEqual(clients,[])
        self.assertEqual(flow.check(user_confirmed=True),{'status':'saved','uid':'u123'})
        self.assertEqual(clients[0].calls,1)
        self.assertTrue(clients[0].closed)
        self.assertEqual(len(saved),1)
        self.assertEqual(flow.check(user_confirmed=True),{'status':'already_attempted'})

    def test_failed_identity_request_never_retries_and_redacts(self):
        page=FakePage();clients=[];saved=[]
        class FailedClient(FakeClient):
            def get_self_info(self): self.calls+=1;raise RuntimeError('secret value')
        def factory(c):
            client=FailedClient(c);clients.append(client);return client
        flow=ManualResume(page,factory,lambda c,i:saved.append(i))
        self.assertEqual(flow.check(user_confirmed=True),{'status':'identity_request_failed_no_retry'})
        self.assertEqual(flow.check(user_confirmed=True),{'status':'already_attempted'})
        self.assertEqual(clients[0].calls,1);self.assertEqual(saved,[])

    def test_cookie_change_during_identity_stops(self):
        page=FakePage();saved=[]
        class ChangedClient(FakeClient):
            def get_self_info(self):
                page.context.items[-1]['value']='changed'
                return super().get_self_info()
        flow=ManualResume(page,ChangedClient,lambda c,i:saved.append(i))
        self.assertEqual(flow.check(user_confirmed=True),{'status':'session_changed'})
        self.assertEqual(saved,[])

    def test_conflicting_expected_identity_stops(self):
        page=FakePage();saved=[]
        flow=ManualResume(page,FakeClient,lambda c,i:saved.append(i),expected_uid='another')
        self.assertEqual(flow.check(user_confirmed=True),{'status':'identity_conflict'})
        self.assertEqual(saved,[])

    def test_guest_or_missing_guest_never_saves(self):
        page=FakePage();saved=[]
        class GuestClient(FakeClient):
            def get_self_info(self): return {'user_id':'u123'}
        flow=ManualResume(page,GuestClient,lambda c,i:saved.append(i))
        self.assertEqual(flow.check(user_confirmed=True),{'status':'identity_unverified'})
        self.assertEqual(saved,[])

    def test_closing_during_identity_stops(self):
        page=FakePage();saved=[]
        class ClosingClient(FakeClient):
            def get_self_info(self):
                page.closed=True
                return super().get_self_info()
        flow=ManualResume(page,ClosingClient,lambda c,i:saved.append(i))
        self.assertEqual(flow.check(user_confirmed=True),{'status':'page_closed'})
        self.assertEqual(saved,[])

if __name__=='__main__': unittest.main()
