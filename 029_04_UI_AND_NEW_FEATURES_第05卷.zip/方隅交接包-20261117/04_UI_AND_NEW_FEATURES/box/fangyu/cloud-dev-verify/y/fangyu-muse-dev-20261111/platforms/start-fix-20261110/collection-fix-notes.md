# 采集启动修复记录

2026-11-10。只改入口与进度显示，不启动采集，不调用平台，不删除现场停止标记和租约。

## 根因

1. continue_collection.py 对任意 runner-lease 文件一律硬挡，没有辨认进程是否已经退出。
2. continue-collection.lock 是持久 PID 文件，异常退出可能留下死锁。
3. new_round.py 与 continue_collection.py 没有共用启动互斥；new_round.py 也没在启动前尊重 auto-collect.stop。
4. active-runner.json 的 running 是旧记录；界面应读真实 PID 并解释主动暂停，不能把文件状态当进程状态。

## 代码

- 新增 work/fangyu-douyin-independent/collection_startup.py：Windows 操作系统文件锁，所有启动/继续入口共用；进程死亡自动释放。死租约按原字节移入 startup-recovery 专属目录，活 PID 或不明归属均阻断，整组先核对再归档。
- continue_collection.py：优先尊重 auto-collect.stop；共用锁；归档确认死锁后沿现有回执/游标/未知保护接续；连接无响应提示刷新原登录页面；普通接续也做当前身份核验。
- new_round.py：共用同一锁、同一死租约处理和主动暂停检查；一页验证及后台执行前再次检查暂停。
- collection_progress_window.py：主动暂停单独显示；按钮点击返回具体原因，不把旧验证码标记覆盖主动暂停。
- 新增 test_collection_startup.py：临时目录离线回归，生产 ROOT 和平台调用替换为测试边界；不操作实际状态。

源码备份：work/start-fix-20261110/before-collection。

## 验证

新加的主动暂停回归在旧代码上实际 FAIL，修复后通过。

`python -B -m unittest -v test_collection_startup test_scoped_recovery`：最终 25 项通过，其中 17 项新增启动测试，8 项已有作用域恢复测试。

`node --test runner_test.cjs`：22 项通过，runner.cjs 未修改。

采集 Python 全发现检查与旧缓存测试没有全绿：旧库幂等/时间保留/90天回填及无时间样本计数存在失败。使用 before-collection 的旧入口和其余未改源文件在 baseline-collection 的独立副本重跑，复现 35 项中的 6 failure + 2 error；这次没有改账本内部逻辑来消除既有失败。

失败方法：

- test_same_request_id_is_idempotent_but_conflicting_payload_rejected
- test_mixed_pages_preserve_raw_and_gate_business_rows（包含 subtest error 和后续 assertion failure）
- test_ninety_day_boundaries_and_idempotent_backfill_update_warm_cache
- test_authorized_account_transition_counts_globally_and_skips_prior_videos
- test_excluded_relation_does_not_ban_cid_on_later_eligible_source
- test_legacy_fingerprint_incremental_partial_overlap_and_checkpoint
- test_scale_100000_entities_and_5000_pages_decode_once

日志：collection-startup-tests.log、baseline-existing-test-failures.log。

collection-runtime-protection.json 记录 active、auto-collect.stop、wait state 与两个原租约的 hash；隔离测试后核对一致。生产停止标记仍在，原陈旧租约没有现在就清掉；下次用户合法启动且不再处于主动暂停时才执行恢复逻辑。

## 运行边界

未启动或重开任何生产进程；未点击按钮；未做真实平台验收。已打开的采集进度 Python 窗口若缓存了旧模块，需要员工正常关闭、再从原入口打开后加载新代码。发送期间的 auto-collect.stop 不由本次修复自动解除。

## 后续发现并修复的同入口卡点

现场原 control.pending.phase=dispatching，原始响应为空。增加 prepare_orphaned_scope：仅员工明确点击、当前无有效halt且fresh strict同UID验证之后，保留原control/raw原字节，将未知目标和已尝试目标排除，新scope继承已有效的同账号review并收窄范围。不制造平台response或修改原请求结论。

新scope在第一新页业务派发之前原子写active指针，保存needs_first_page_validation；初始化尚未产生control时只在明确标记且目录空的条件恢复。已有请求痕迹却丢control则阻断，不猜游标。验证后再检查auto.stop、目录STOP和新halt，避免检查中用户暂停却启动主runner。

明确prepared且未派发、原文证据一致的意图，员工点击后走现有--resume-local严格本地取消；dispatching不使用此分支。采集入口的只读gate句柄也改为明确关闭，避免Windows读连接滞留。

collection_confirmed_scope.py有额外源码备份。新增离线测试包含上述入口串联（平台和Popen均替身）、原记录不变、首新页前指针、验证期间暂停、初始化缺断点和未派发本地取消；没有运行生产入口。
