// Real reply module in a VM, deferred in-memory receipts; no UI/server/network.
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const P='C:/积木软件工坊/项目/方隅公寓客户版';
const file=P+'/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs';
const O='C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/live-stop-repair/reply-audit';
const raw=fs.readFileSync(file,'utf8'),results=[];
const source=raw.replace(/^import .*?;\r?\n/gm,'').replace(/\bexport (?=(?:async )?(?:function|const|let))/g,'')+'\n;globalThis.subject={model,renderConnected,selectCustomer};';
function make(){
 const space={Date,URL,console,setTimeout,clearTimeout,queueMicrotask,crypto:{randomUUID:()=> 'isolated-request'},customerAvatar:()=>'<img alt="isolated-avatar">',postCover:()=>'<img alt="isolated-cover">',bindCustomerAvatars:()=>{},warmCustomerMedia:()=>{},workflowScope:s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId,s.activePlatform]),evidenceSummary:()=>'',assessmentLabel:()=>'',renderDelivery:()=>'',bindDelivery:()=>{},prepareReviewed:()=>{},personaChoices:[],renderBatch:()=>'',bindBatch:()=>{}};
 vm.createContext(space);vm.runInContext(source,space,{filename:file});
 const state={authEpoch:1,connection:'connected',session:{user:{username:'isolated-worker'}},user:'isolated-worker',storeId:'isolated-store',activePlatform:'xiaohongshu',page:'reply'};
 const requests=[],ctx={state,update:()=>{},replyError:()=>{},replyRead:data=>new Promise((resolve,reject)=>requests.push({data,resolve,reject}))};
 const v=space.subject.model(state);
 v.items=[{id:'A',name:'隔离客户甲',quote:'隔离评论甲',postTitle:'隔离原帖甲',tone:'medium',level:'中意向',contactLabel:'待处理'},{id:'B',name:'隔离客户乙',quote:'隔离评论乙',postTitle:'隔离原帖乙',tone:'low',level:'低意向',contactLabel:'待处理'}];
 v.stats={total:2,replied:0};v.status='ready';
 const render=()=>space.subject.renderConnected(state),aside=html=>html.slice(html.indexOf('<aside class="rp-editor"'));
 const response=id=>({replyWorkspace:{actor:{username:state.user,storeId:state.storeId},customerId:id,item:v.items.find(p=>p.id===id),comments:[{id:'comment-'+id,text:'新鉴权评论'+id,postTitle:'新鉴权原帖'+id,accounts:[],canSave:true,draft:null}]}});
 return {space,state,v,ctx,requests,render,aside,response};
}
async function check(name,fn){try{await fn();results.push({name,status:'PASS'});}catch(error){results.push({name,status:'FAIL',error:error.message});}}
await check('already returned row immediately appears read-only while fresh detail waits',async()=>{
 const h=make(),pending=h.space.subject.selectCustomer(h.state,h.ctx,h.v,'A'),html=h.aside(h.render());
 assert(html.includes('隔离评论甲'),'Selected comment preview is missing');assert(html.includes('隔离原帖甲'),'Selected post preview is missing');assert(html.includes('隔离客户甲'),'Selected person preview is missing');
 for(const field of ['data-live-draft','data-live-save','data-live-review','data-live-tone'])assert(!html.includes(field),'Write entry exists before fresh receipt: '+field);
 h.requests[0].resolve(h.response('A'));await pending;assert(!h.v.detailLoading);assert(h.aside(h.render()).includes('data-live-draft'),'Fresh authorized detail did not open editor');
});
await check('late prior selected-customer receipt cannot replace the newer preview/editor',async()=>{
 const h=make(),a=h.space.subject.selectCustomer(h.state,h.ctx,h.v,'A'),b=h.space.subject.selectCustomer(h.state,h.ctx,h.v,'B');
 h.requests[0].resolve(h.response('A'));await a;assert.equal(h.v.selectedId,'B');assert.equal(h.v.detail,null);assert(h.aside(h.render()).includes('隔离评论乙'));assert(!h.aside(h.render()).includes('data-live-draft'));
 h.requests[1].resolve(h.response('B'));await b;assert.equal(h.v.detail.customerId,'B');assert(h.aside(h.render()).includes('新鉴权评论B'));
});
await check('plain read failure ends loading without granting write availability',async()=>{
 const h=make(),pending=h.space.subject.selectCustomer(h.state,h.ctx,h.v,'A');const error=Error('隔离读取超时');error.code='timeout';h.requests[0].reject(error);await pending;
 assert.equal(h.v.detailLoading,false);assert.equal(h.v.detail,null);assert.equal(h.v.error,'隔离读取超时');assert(!h.aside(h.render()).includes('data-live-draft'));
});
await check('scope change rejects prior customer receipt',async()=>{
 const h=make(),pending=h.space.subject.selectCustomer(h.state,h.ctx,h.v,'A');h.state.activePlatform='douyin';h.requests[0].resolve(h.response('A'));await pending;assert.equal(h.v.detail,null);
 const newModel=h.space.subject.model(h.state);assert.notEqual(newModel,h.v);assert.equal(newModel.detail,null);assert.equal(newModel.selectedId,'');
});
const report={status:results.every(r=>r.status==='PASS')?'PASS_REPLY_PREVIEW_INCREMENTAL':'FAIL_REPLY_PREVIEW_INCREMENTAL',at_utc:new Date().toISOString(),checks:results.length,passed:results.filter(r=>r.status==='PASS').length,results,source_sha256:crypto.createHash('sha256').update(raw).digest('hex'),real_HTTP_requests:0,real_platform_requests:0,UI_operations:0,product_edits:0,test_kind:'Real reply module functions, in-memory deferred receipts. No production speed acceptance.'};
fs.writeFileSync(O+'/PREVIEW-CHECK.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));process.exitCode=report.status.startsWith('PASS')?0:1;
