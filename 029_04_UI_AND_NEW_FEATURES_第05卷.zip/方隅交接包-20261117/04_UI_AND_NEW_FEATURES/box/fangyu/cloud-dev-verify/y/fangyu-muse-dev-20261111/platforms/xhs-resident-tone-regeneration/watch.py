import subprocess,sys,time,json,os
from pathlib import Path
P=Path(__file__).resolve().parent
def invoke(name):
 r=subprocess.run([sys.executable,str(P/name)],cwd=P.parents[1],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 if r.returncode:raise RuntimeError(name+' failed; requires review')
start=time.monotonic();previous=None
while time.monotonic()-start<1800:
 if (P/'STOP').exists():break
 # Generation only invokes models for additions; completed validated batches remain cached.
 invoke('regenerate.py');invoke('verify.py');invoke('export.py')
 m=json.loads((P/'manifest.json').read_text('utf8'))
 print(json.dumps({'analysis':m['analysed_comments'],'remaining_analysis':m['pending_analysis_comments'],'draft_candidates':m['selected_unique_customers']},ensure_ascii=False),flush=True)
 if m['pending_analysis_comments']==0:break
 time.sleep(15)
