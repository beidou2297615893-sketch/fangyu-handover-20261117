"""构建合法/非法 fixture 树。"""
import json
import sqlite3
from pathlib import Path


def create_ledger(path):
    """创建空 sqlite 账本。"""
    conn = sqlite3.connect(path)
    conn.execute('''
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT,
            source TEXT,
            customer TEXT,
            comment TEXT
        )
    ''')
    conn.commit()
    conn.close()


def build_valid_fixture(resume006_root, session_home, uid, here_dir):
    """构建合法 fixture。"""
    resume006_root.mkdir(parents=True, exist_ok=True)

    # 构建 plan：129 项（cursor=22 时剩余 107？ 实际需要剩余 128 页）
    # 剩余页数 = len(plan) - idx，要让 remaining=128，则 idx=0，len(plan)=128
    # 但 batch-0023 是第 23 项，所以 plan 至少 23 项。为了 remaining=128，需要 plan 长度=128+22=150
    plan = [{'keyword': f'keyword-{i}', 'page': (i % 100) + 1} for i in range(150)]
    # inflight 指向 plan[22]（第 23 项）
    inflight_item = plan[22]

    state = {
        'version': 1,
        'plan': plan,
        'cursor': 22,
        'next_batch': 23,
        'target': 2147483647,
        'inserted': 0,
        'count_basis': 'comments',
        'rule_source': 'test',
        'created_at': '2026-11-03T00:00:00',
        'status': 'outcome_unknown',
        'inflight': {
            'batch': 'batch-0023',
            'keyword': inflight_item['keyword'],
            'page': inflight_item['page'],
            'remaining': 127,
        },
    }
    (resume006_root / 'state.json').write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')

    # run-receipts.jsonl
    receipt = {
        'at': '2026-11-03T00:00:01',
        'status': 'outcome_unknown',
        'new_registered': 0,
        'inflight': {
            'batch': 'batch-0023',
            'keyword': inflight_item['keyword'],
            'page': inflight_item['page'],
            'remaining': 127,
        },
        'automatic_retry': False,
    }
    (resume006_root / 'run-receipts.jsonl').write_text(json.dumps(receipt) + '\n', encoding='utf-8')

    # batch-0023 目录
    batch_dir = resume006_root / 'batch-0023'
    batch_dir.mkdir(exist_ok=True)

    # failure-diagnostic.json
    failure = {
        'category': 'platform_verification',
        'platform': {
            'error_type': 'http_461',
            'stage': 'comments',
            'endpoint': 'comments',
            'http_status': 461,
            'request_started': True,
        },
        'retry_allowed': False,
        'http_evidence': {
            'http_status': 461,
            'stage': 'comments',
            'endpoint': 'comments',
            'verification_header_present': False,
            'visible_dialog': '验证',
            'account_restriction_proven': False,
            'body_kind': 'json',
            'api_code': 461,
            'message_signals': ['验证'],
        },
    }
    (batch_dir / 'failure-diagnostic.json').write_text(json.dumps(failure, ensure_ascii=False, indent=2), encoding='utf-8')

    # dedup-summary.json
    dedup = {
        'skipped_notes': 6,
        'duplicate_comments': 8,
    }
    (batch_dir / 'dedup-summary.json').write_text(json.dumps(dedup, ensure_ascii=False, indent=2), encoding='utf-8')

    # identity-check-resume006-verified.json
    identity = {
        'status': 'verified',
        'uid': uid,
        'session_home': str(session_home),
        'verified_at': '2026-11-03T00:00:00',
    }

    # resume006 continuation-receipt（供 prior_registered 读取）
    receipt = {
        'status': 'locally_reconciled',
        'prior_registered': 3566,
        'partial_registered_preserved': 30,
        'next_batch': 23,
        'remaining_pages': 128,
        'network': False,
    }
    (resume006_root / 'continuation-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')

    (here_dir / 'identity-check-resume006-verified.json').write_text(json.dumps(identity, ensure_ascii=False, indent=2), encoding='utf-8')


def make_invalid(reason, resume006_root, session_home, uid, here_dir):
    """根据 reason 修改 fixture 使其非法。"""
    if reason == 'prior_state_changed':
        state_path = resume006_root / 'state.json'
        state = json.loads(state_path.read_text(encoding='utf-8'))
        state['status'] = 'paused'
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
    elif reason == 'unknown_registration':
        # 创建注册产物
        (resume006_root / 'batch-0023' / 'register-result.json').write_text('{}', encoding='utf-8')
    elif reason == 'failure_changed':
        failure_path = resume006_root / 'batch-0023' / 'failure-diagnostic.json'
        failure = json.loads(failure_path.read_text(encoding='utf-8'))
        failure['platform']['http_status'] = 500
        failure_path.write_text(json.dumps(failure, ensure_ascii=False, indent=2), encoding='utf-8')
    elif reason == 'verified_account_required':
        # 删除身份文件或修改 uid
        ident_path = here_dir / 'identity-check-resume006-verified.json'
        ident = json.loads(ident_path.read_text(encoding='utf-8'))
        ident['uid'] = 'wrong-uid'
        ident_path.write_text(json.dumps(ident, ensure_ascii=False, indent=2), encoding='utf-8')
    elif reason == 'active_lock':
        (session_home / '.managed-use.lock').mkdir()
    elif reason == 'verification_stop_today':
        # 创建当日 stop-today
        stop_path = here_dir / 'stop-today-resume007.json'
        stop_path.write_text(json.dumps({'date': '2026-11-03'}, ensure_ascii=False, indent=2), encoding='utf-8')
    elif reason == 'delay_too_small':
        # 无需修改 fixture，调用时传 delay<=3.0
        pass
