"""Local deterministic supervision; no SDK, credentials, shell worker or platform I/O.

Adapters are reviewed in-process objects, never user-supplied executable commands.
An adapter must reconcile the shared ledger before claiming a checkpoint is safe.
CLI installation/execution is deliberately gated separately in entry.py.
"""
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import time
import uuid


class Busy(RuntimeError):
    pass


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temp.open('x', encoding='utf8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


class ProjectLock:
    """Kernel-held project mutex, shared by both lanes and all accounts.

    Lock file is never deleted: deleting and recreating it would split the mutex.
    Only cooperating candidate processes share this lock; old programs are NOT
    magically covered. Installation must also acquire their existing session lock.
    """
    def __init__(self, root):
        self.path = Path(root) / 'execution.lock'
        self.file = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open('a+b')
        self.file.seek(0, os.SEEK_END)
        if self.file.tell() == 0:
            self.file.write(b'0')
            self.file.flush()
        self.file.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            self.file = None
            raise Busy('another_candidate_execution_active') from None
        return self

    def __exit__(self, *_):
        if self.file is not None:
            try:
                self.file.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.file, fcntl.LOCK_UN)
            finally:
                self.file.close()
                self.file = None


@dataclass
class Snapshot:
    uid: str = ''
    verified_uid: str = ''
    identity_verified: bool = False
    ledger_ready: bool = False
    checkpoint_safe: bool = False
    count_known: bool = False
    sent_today: int = 0
    count_day: str = ''
    platform_blocked: bool = False
    validation_required: bool = False
    current_unknown: bool = False
    pending_submission: bool = False
    recovered_no_submission: bool = False
    consecutive_rejections: int = 0


@dataclass
class Outcome:
    kind: str
    next_checkpoint: dict = None
    post_started: bool = False
    receipt_confirmed: bool = False
    new_items: int = 0
    definitive_rejection: bool = False


HARD_STOPS = frozenset({'verification', 'identity_error', 'outcome_unknown',
    'platform_halt', 'state_invalid', 'checkpoint_unsafe', 'ledger_unavailable',
    'account_change_requires_review', 'rate_limit', 'adapter_error'})
RETRYABLE = frozenset({'network_error', 'timeout', 'process_lost'})
ACTIONS = {'verification': '过验证', 'identity_error': '核对账号',
    'daily_limit': '换号', 'consecutive_rejections': '换号',
    'outcome_unknown': '待核对', 'platform_halt': '待核对',
    'rate_limit': '按平台提示处理', 'completed': '查看结果',
    'user_paused': '按启动', 'network_error': '自动续接',
    'timeout': '自动续接', 'process_lost': '按启动',
    'retry_exhausted': '按启动'}
HUMAN_REASONS = {
    'verification': '平台要求验证，任务已停止',
    'identity_error': '当前账号与本次核验不一致，任务已停止',
    'daily_limit': '本号今日已发达到设定数量，任务已停止',
    'consecutive_rejections': '平台连续明确退回，任务已停止',
    'outcome_unknown': '本次结果尚未确认，已停止且不会重发',
    'platform_halt': '已有平台停线尚未处理，任务未启动',
    'rate_limit': '平台要求暂停访问，任务已停止',
    'completed': '当前已授权任务已完成',
    'user_paused': '任务已按要求暂停',
    'network_error': '网络暂时中断，正在有限次数等待续接',
    'timeout': '请求等待超时，已确认无未知提交，正在等待续接',
    'process_lost': '执行进程已退出，请核对后按启动',
    'retry_exhausted': '连续重试仍未恢复，任务已停止',
    'count_unconfirmed': '今日已发数量证据不完整，任务未启动',
    'checkpoint_unsafe': '断点尚未核对，任务未启动',
    'ledger_unavailable': '共享账本暂时不可用，任务未启动',
    'state_invalid': '任务记录无法读取，已保留原文件等待核对',
    'account_change_requires_review': '原账号的未知结果仍待核对，不能换号重发',
    'adapter_error': '续接接口返回不完整，任务已停止',
    'step_budget_reached': '本次运行已到检查点，请查看结果后继续',
}


def beijing_day(value):
    if not isinstance(value, datetime) or value.tzinfo is None:
        raise ValueError('aware_time_required')
    return value.astimezone(timezone(timedelta(hours=8))).date().isoformat()


class Controller:
    def __init__(self, root, *, lane, uid, notify, sleep=time.sleep,
                 retry_delays=(5, 10, 20), daily_limit=200, rejection_limit=3,
                 clock=lambda: datetime.now(timezone.utc)):
        if lane not in {'collect', 'send'} or not isinstance(uid, str) or not uid:
            raise ValueError('lane_and_actual_uid_required')
        if type(daily_limit) is not int or daily_limit < 1:
            raise ValueError('positive_daily_limit_required')
        if type(rejection_limit) is not int or rejection_limit < 1:
            raise ValueError('positive_rejection_limit_required')
        if len(retry_delays) > 3 or any(type(d) not in (int, float) or not 0 < d <= 300 for d in retry_delays):
            raise ValueError('bounded_positive_backoff_required')
        self.root = Path(root).absolute()
        if self.root.is_symlink() or self.root.resolve() != self.root:
            raise ValueError('canonical_runtime_required')
        self.root.mkdir(parents=True, exist_ok=True)
        self.lane, self.uid = lane, uid
        self.notify, self.sleep = notify, sleep
        self.delays = tuple(retry_delays)
        self.daily_limit, self.rejection_limit = daily_limit, rejection_limit
        self.clock = clock
        self.path = self.root / (lane + '-state.json')
        self.invalid = False
        self.state = {'schema': 1, 'lane': lane, 'uid': uid, 'status': 'idle',
            'checkpoint': {}, 'inflight': False, 'success': 0, 'failed': 0,
            'unknown': 0, 'new_items': 0, 'today_sent': None, 'reason': '',
            'action': '按启动', 'generation': uuid.uuid4().hex,
            'retries': 0, 'consecutive_rejections': 0,
            'notification_failed': False}
        if self.path.exists():
            try:
                value = json.loads(self.path.read_text('utf-8-sig'))
                if (not isinstance(value, dict) or value.get('schema') != 1
                    or value.get('lane') != lane or not isinstance(value.get('uid'), str)
                    or not isinstance(value.get('checkpoint'), dict)
                    or type(value.get('inflight')) is not bool
                    or not isinstance(value.get('generation'), str)):
                    raise ValueError('shape')
                self.state.update(value)
            except (OSError, ValueError):
                self.invalid = True

    def _persist(self, **updates):
        self.state.update(updates)
        self.state['updated_at'] = datetime.now(timezone.utc).isoformat()
        self.state['supervisor_pid'] = os.getpid()
        if not self.invalid:
            atomic_json(self.path, self.state)
        self._publish()

    def _publish(self):
        # Separate progress projection; never reads account/session files.
        projection = {'schema': 1, 'lanes': {}}
        target = self.root / 'controller-status.json'
        if target.is_file():
            try:
                old = json.loads(target.read_text('utf-8-sig'))
                if isinstance(old.get('lanes'), dict):
                    projection['lanes'] = old['lanes']
            except (OSError, ValueError, AttributeError):
                pass
        projection['lanes'][self.lane] = dict(self.state)
        projection['production_installed'] = False
        atomic_json(target, projection)

    def _notice(self, reason, action):
        material = f"{self.state['generation']}:{self.lane}:{reason}:{self.state.get('notice_seq', 0)}"
        event_id = hashlib.sha256(material.encode()).hexdigest()[:24]
        try:
            result = self.notify(event_id, '采集' if self.lane == 'collect' else '回复',
                HUMAN_REASONS.get(reason, '任务已停止，请核对后处理'), action,
                {'uid': self.uid, 'status': self.state['status']})
            if isinstance(result, dict) and result.get('delivery_status') in {'failed', 'unknown', 'delivery_failed', 'delivery_unknown'}:
                self._persist(notification_failed=True)
        except Exception:
            # Raw exceptions can contain authentication or transport material.
            self._persist(notification_failed=True)

    def _stop(self, reason, *, action=None, status='stopped', preserve_inflight=False):
        action = action or ACTIONS.get(reason, '待核对')
        updates = {'status': status, 'reason': reason, 'action': action,
                   'reason_text': HUMAN_REASONS.get(reason, '任务已停止，请核对后处理'),
                   'notice_seq': self.state.get('notice_seq', 0) + 1}
        if not preserve_inflight:
            updates['inflight'] = False
        if reason == 'outcome_unknown':
            updates['unknown'] = max(1, self.state.get('unknown', 0))
        self._persist(**updates)
        self._notice(reason, action)
        return dict(self.state)

    def _gate(self, s):
        if not isinstance(s, Snapshot):
            return 'adapter_error'
        booleans = ('identity_verified', 'ledger_ready', 'checkpoint_safe',
                    'count_known', 'platform_blocked', 'validation_required',
                    'current_unknown', 'pending_submission', 'recovered_no_submission')
        if any(type(getattr(s, name)) is not bool for name in booleans):
            return 'adapter_error'
        if s.validation_required:
            return 'verification'
        if s.platform_blocked:
            return 'platform_halt'
        if not s.identity_verified or s.uid != self.uid or s.verified_uid != self.uid:
            return 'identity_error'
        if s.current_unknown or s.pending_submission:
            return 'outcome_unknown'
        if not s.ledger_ready:
            return 'ledger_unavailable'
        if not s.checkpoint_safe:
            return 'checkpoint_unsafe'
        if self.lane == 'send':
            if s.count_day != beijing_day(self.clock()):
                return 'count_unconfirmed'
            if not s.count_known or type(s.sent_today) is not int or s.sent_today < 0:
                return 'count_unconfirmed'
            if s.sent_today >= self.daily_limit:
                return 'daily_limit'
            if type(s.consecutive_rejections) is not int or s.consecutive_rejections < 0:
                return 'adapter_error'
            if s.consecutive_rejections >= self.rejection_limit:
                return 'consecutive_rejections'
        return None

    def _merge_count(self, snapshot):
        if (isinstance(snapshot, Snapshot) and self.lane == 'send'
            and type(snapshot.sent_today) is int and snapshot.sent_today >= 0
            and snapshot.count_day == beijing_day(self.clock())
            and self.state.get('count_day') == snapshot.count_day
            and self.state.get('counter_uid') == self.uid):
            snapshot.sent_today = max(snapshot.sent_today,
                                      self.state.get('today_sent_lower_bound', 0))
        return snapshot

    def run(self, adapter, *, max_steps=100000):
        if type(max_steps) is not int or not 1 <= max_steps <= 100000:
            raise ValueError('bounded_step_budget_required')
        with ProjectLock(self.root):
            # Reload after lock acquisition. A preceding process may have moved
            # the checkpoint since this Controller instance was constructed.
            if self.path.exists() and not self.invalid:
                try:
                    latest = json.loads(self.path.read_text('utf-8-sig'))
                    if (not isinstance(latest, dict) or latest.get('schema') != 1
                        or latest.get('lane') != self.lane
                        or not isinstance(latest.get('checkpoint'), dict)
                        or type(latest.get('inflight')) is not bool):
                        raise ValueError('shape')
                    self.state.update(latest)
                except (ValueError, OSError):
                    self.invalid = True
            if self.invalid:
                return self._stop('state_invalid')
            previous_uid = self.state.get('uid')
            if previous_uid != self.uid and (self.state.get('inflight') or self.state.get('reason') in HARD_STOPS):
                return self._stop('account_change_requires_review', preserve_inflight=True)
            if self.state.get('reason') in HARD_STOPS:
                return dict(self.state)
            self._persist(uid=self.uid)
            for _ in range(max_steps):
                try:
                    snapshot = self._merge_count(adapter.inspect(dict(self.state['checkpoint'])))
                except Exception:
                    return self._stop('adapter_error', preserve_inflight=True)
                blocked = self._gate(snapshot)
                if blocked:
                    return self._stop(blocked, preserve_inflight=True)
                self._persist(today_sent=snapshot.sent_today if self.lane == 'send' else None,
                              count_day=snapshot.count_day, counter_uid=self.uid)
                if self.state.get('inflight') and not snapshot.recovered_no_submission:
                    return self._stop('outcome_unknown', preserve_inflight=True)
                # Write-ahead ownership: a process death beyond here requires
                # affirmative ledger reconciliation, never an assumed failure.
                self._persist(status='running', inflight=True, reason='', action='运行中')
                try:
                    outcome = adapter.step(dict(self.state['checkpoint']))
                except Exception:
                    return self._stop('outcome_unknown', preserve_inflight=True)
                if not isinstance(outcome, Outcome) or type(outcome.post_started) is not bool:
                    return self._stop('outcome_unknown', preserve_inflight=True)
                kind = outcome.kind
                if kind in {'verification', 'identity_error', 'rate_limit'} and outcome.post_started:
                    self._persist(platform_stop_reason=kind)
                    return self._stop('outcome_unknown', action=ACTIONS[kind], preserve_inflight=True)
                if kind == 'completed':
                    if outcome.post_started:
                        return self._stop('outcome_unknown', preserve_inflight=True)
                    return self._stop('completed', status='completed')
                if kind == 'success':
                    if (not isinstance(outcome.next_checkpoint, dict)
                        or outcome.next_checkpoint == self.state['checkpoint']
                        or type(outcome.new_items) is not int or outcome.new_items < 0
                        or (self.lane == 'send' and outcome.receipt_confirmed is not True)):
                        return self._stop('outcome_unknown', preserve_inflight=True)
                    self._persist(checkpoint=outcome.next_checkpoint, inflight=False,
                                  success=self.state['success'] + 1,
                                  new_items=self.state['new_items'] + outcome.new_items,
                                  retries=0, consecutive_rejections=0,
                                  today_sent=snapshot.sent_today + 1 if self.lane == 'send' else None,
                                  today_sent_lower_bound=snapshot.sent_today + 1 if self.lane == 'send' else 0)
                    continue
                if kind == 'rejected':
                    if (outcome.definitive_rejection is not True
                        or not isinstance(outcome.next_checkpoint, dict)
                        or outcome.next_checkpoint == self.state['checkpoint']):
                        return self._stop('outcome_unknown', preserve_inflight=True)
                    rejects = self.state['consecutive_rejections'] + 1
                    self._persist(checkpoint=outcome.next_checkpoint, inflight=False,
                                  failed=self.state['failed'] + 1,
                                  consecutive_rejections=rejects, retries=0)
                    if rejects >= self.rejection_limit:
                        return self._stop('consecutive_rejections')
                    continue
                if kind in RETRYABLE:
                    if outcome.post_started:
                        return self._stop('outcome_unknown', preserve_inflight=True)
                    # Inspect again after failure: conditions may have changed.
                    try:
                        after = self._merge_count(adapter.inspect(dict(self.state['checkpoint'])))
                    except Exception:
                        return self._stop('adapter_error', preserve_inflight=True)
                    blocked = self._gate(after)
                    if blocked:
                        return self._stop(blocked, preserve_inflight=True)
                    retry = self.state['retries']
                    if retry >= len(self.delays):
                        return self._stop('retry_exhausted')
                    self._stop(kind, action='自动续接', status='retry_wait')
                    self._persist(retries=retry + 1)
                    self.sleep(self.delays[retry])
                    continue
                if kind in {'verification', 'identity_error', 'rate_limit', 'outcome_unknown', 'user_paused'}:
                    return self._stop(kind, preserve_inflight=kind == 'outcome_unknown')
                return self._stop('adapter_error', preserve_inflight=True)
            return self._stop('step_budget_reached', action='按启动')

    def observe_exit(self, *, worker_alive):
        """Separate watcher can persist an exit, without launching any worker."""
        if type(worker_alive) is not bool:
            raise ValueError('explicit_process_liveness_required')
        if worker_alive or self.state.get('status') != 'running':
            return dict(self.state)
        # Observer never takes/removes worker lock: a dead owner releases its
        # kernel lock, but a live/delayed owner must not be overwritten.
        with ProjectLock(self.root):
            if self.path.is_file():
                try:
                    self.state.update(json.loads(self.path.read_text('utf-8-sig')))
                except (ValueError, OSError, TypeError):
                    self.invalid = True
                    return self._stop('state_invalid')
            if self.state.get('status') != 'running':
                return dict(self.state)
            reason = 'outcome_unknown' if self.state.get('inflight') else 'process_lost'
            return self._stop(reason, preserve_inflight=bool(self.state.get('inflight')))

