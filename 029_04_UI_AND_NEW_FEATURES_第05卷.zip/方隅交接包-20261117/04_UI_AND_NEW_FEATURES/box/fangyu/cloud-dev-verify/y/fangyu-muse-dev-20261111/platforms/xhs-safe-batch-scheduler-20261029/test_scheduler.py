import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location('scheduler', HERE/'scheduler.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class Executor:
    # An offline stand-in for a separately reviewed, bounded batch adapter.

    def __init__(self, counts):
        self.counts=list(counts); self.calls=[]
    def run(self, batch, keyword, page, limit):
        self.calls.append((batch, keyword, page, limit))
        value=self.counts.pop(0)
        if isinstance(value, BaseException): raise value
        return {'status':'registered', 'inserted':value, 'analysis_input':f'{batch}/new-ai-input.json'}

class SchedulerBehavior(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.path=Path(self.tmp.name)
        self.plan=[{'keyword':'古北找房','page':5},{'keyword':'古北找房','page':6}]
    def tearDown(self): self.tmp.cleanup()
    def init(self, target=10000):
        return module.initialize(self.path, self.plan, first_batch=20, target=target)
    def test_new_run_count_excludes_old_historical_batches(self):
        state=self.init(); self.assertEqual(state['inserted'],0)
        self.assertEqual(state['count_basis'],'new_registered_unique_comments_since_this_resume')
        self.assertEqual(state['target'],10000)
        self.assertEqual(state['rule_source'],'user_resume_new_10000_2026-10-29')
        persisted=json.loads((self.path/'state.json').read_text(encoding='utf8'))
        self.assertEqual(persisted['count_basis'],state['count_basis'])
    def test_exact_target_passes_remaining_progress_and_stops(self):
        self.init(3); e=Executor([2,1]); result=module.run(self.path,e)
        self.assertEqual(result['status'],'target_reached'); self.assertEqual(result['inserted'],3)
        self.assertEqual([c[-1] for c in e.calls],[3,1]); self.assertEqual(len(e.calls),2)
        events=module.read_events(self.path); self.assertEqual(len(events),5)
        self.assertEqual(events[-1]['kind'],'target_reached')
        self.assertEqual(events[-1]['inserted'],3); self.assertEqual(events[-1]['over_target'],0)
        module.run(self.path,e); self.assertEqual(len(module.read_events(self.path)),5)
    def test_complete_batch_can_cross_target_then_stops(self):
        self.init(3); e=Executor([2,2])
        result=module.run(self.path,e)
        self.assertEqual(result['status'],'target_reached'); self.assertEqual(result['inserted'],4)
        self.assertEqual(result['over_target'],1); self.assertEqual(len(e.calls),2)
    def test_stop_before_batch_no_call(self):
        self.init(); (self.path/'STOP').touch(); e=Executor([1])
        self.assertEqual(module.run(self.path,e)['status'],'paused'); self.assertEqual(e.calls,[])
    def test_pause_is_checked_after_each_batch(self):
        self.init(); e=Executor([2,1]); original=e.run
        def once(*args):
            value=original(*args); (self.path/'STOP').touch(); return value
        e.run=once
        result=module.run(self.path,e)
        self.assertEqual(result['status'],'paused'); self.assertEqual(result['inserted'],2)
        self.assertEqual(len(e.calls),1)
    def test_existing_batch_is_not_reused(self):
        self.init(); (self.path/'batch-0020').mkdir(); e=Executor([1])
        self.assertEqual(module.run(self.path,e)['status'],'batch_already_exists'); self.assertEqual(e.calls,[])
    def test_exception_is_unknown_and_never_retried(self):
        self.init(); e=Executor([RuntimeError('private detail')])
        self.assertEqual(module.run(self.path,e)['status'],'outcome_unknown')
        second=Executor([1]); self.assertEqual(module.run(self.path,second)['status'],'outcome_unknown')
        self.assertEqual(second.calls,[]); self.assertNotIn('private detail',(self.path/'events.jsonl').read_text(encoding='utf8'))
    def test_existing_lease_blocks_without_call(self):
        self.init(); (self.path/'scheduler.lock').mkdir(); e=Executor([1])
        self.assertEqual(module.run(self.path,e)['status'],'lock_busy'); self.assertEqual(e.calls,[])
    def test_completed_plan_is_not_global_completion(self):
        self.init(); e=Executor([2,2]); result=module.run(self.path,e)
        self.assertEqual(result['status'],'plan_exhausted'); self.assertEqual(result['inserted'],4)
    def test_invalid_result_becomes_unknown(self):
        self.init(1); e=Executor([-1]); result=module.run(self.path,e)
        self.assertEqual(result['status'],'outcome_unknown'); self.assertEqual(result['inserted'],0)
        self.assertEqual(module.run(self.path,Executor([1]))['status'],'outcome_unknown')
    def test_initialization_never_replaces_existing_state(self):
        self.init(); before=(self.path/'state.json').read_bytes()
        with self.assertRaises(FileExistsError): self.init()
        self.assertEqual((self.path/'state.json').read_bytes(),before)
    def test_resume_after_persisted_start_is_blocked(self):
        self.init(); state=json.loads((self.path/'state.json').read_text(encoding='utf8'))
        state['inflight']={'batch':'batch-0020','keyword':'古北找房','page':5,'limit':10000}
        (self.path/'state.json').write_text(json.dumps(state),encoding='utf8')
        e=Executor([1]); self.assertEqual(module.run(self.path,e)['status'],'outcome_unknown'); self.assertEqual(e.calls,[])

if __name__=='__main__': unittest.main()






