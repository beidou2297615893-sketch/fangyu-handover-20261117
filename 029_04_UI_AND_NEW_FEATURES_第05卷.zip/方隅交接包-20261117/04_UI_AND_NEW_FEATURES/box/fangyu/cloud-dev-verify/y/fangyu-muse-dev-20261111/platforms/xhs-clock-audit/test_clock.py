import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import one_click
import pipeline
from test_pipeline import record, answer
from test_one_click import TestOneClick

FIRST='2026-10-28T23:59:59+08:00'
LATER='2026-10-29T00:00:02+08:00'


class ClockTests(unittest.TestCase):
    def test_model_receives_frozen_shanghai_time_and_evidence(self):
        messages=pipeline.build_messages(record(),{},[],review_as_of=FIRST)
        payload=json.loads(messages[1]['content'])
        self.assertEqual(payload['review_as_of'],FIRST)
        self.assertEqual(payload['review_timezone'],'Asia/Shanghai')
        self.assertIn('review_as_of',messages[0]['content'])

    def test_resume_uses_first_clock_across_midnight(self):
        class Fixture:
            model='fixture'
            def __init__(self,fail=False):self.fail=fail;self.seen=[];self.review_as_of=None
            def bind_review_as_of(self,value):self.review_as_of=value
            def analyze(self,row,*args):
                self.seen.append((row['customer_id'],self.review_as_of))
                if self.fail and row['customer_id']=='internal2':raise pipeline.ProviderError('test')
                return answer(target_comment_id=row['comment_id'],reply='看看方隅公寓吧')
        one=record();two=dict(record(),customer_id='internal2',customer_uid='uid2',comment_id='comment2')
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            root=Path(tmp);src=root/'source.json';src.write_text(json.dumps([one,two],ensure_ascii=False),encoding='utf8')
            first=Fixture(True)
            with patch.object(pipeline,'now_shanghai',return_value=FIRST):
                with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,root/'out','sender',{},[],first)
            resumed=Fixture()
            with patch.object(pipeline,'now_shanghai',return_value=LATER):
                pipeline.create_batch(src,root/'out','sender',{},[],resumed)
            self.assertEqual(first.seen,[('internal1',FIRST),('internal2',FIRST)])
            self.assertEqual(resumed.seen,[('internal2',FIRST)])
            for name in ('checkpoint.json','analysis.json','batch.json'):
                self.assertEqual(json.loads((root/'out'/name).read_text(encoding='utf8'))['review_as_of'],FIRST)

    def test_resume_rejects_changed_explicit_clock_and_non_shanghai_offset(self):
        class Fixture:
            model='fixture'
            def bind_review_as_of(self,value):self.clock=value
            def analyze(self,*args):raise pipeline.ProviderError('offline')
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            root=Path(tmp);src=root/'source.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
            with self.assertRaises(pipeline.ProviderError):pipeline.create_batch(src,root/'out','sender',{},[],Fixture(),review_as_of=FIRST)
            with self.assertRaises(pipeline.InvalidInput):pipeline.create_batch(src,root/'out','sender',{},[],Fixture(),review_as_of=LATER)
            with self.assertRaises(pipeline.InvalidInput):pipeline.create_batch(src,root/'out2','sender',{},[],Fixture(),review_as_of='2026-10-28T15:59:59+00:00')


class WorkflowClockTests(TestOneClick):
    def test_reused_complete_batch_rejects_clock_tampering(self):
        class Fake:
            model='fake'
            def bind_review_as_of(self,value):self.clock=value
            def analyze(self,row,*args):return answer(reply='看看方隅公寓吧')
        src=self.root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        out=self.root/'out';provider=Fake();sends=[]
        with patch.object(pipeline,'now_shanghai',return_value=FIRST):
            one_click.run_workflow(input_path=src,output_dir=out,ledger=self.db,sender_uid='sender',account={},samples=[],provider=provider,send=lambda *x:sends.append(x),execute=True)
        checkpoint=out/'analysis'/'checkpoint.json';data=json.loads(checkpoint.read_text(encoding='utf8'));data['review_as_of']=LATER
        checkpoint.write_text(json.dumps(data),encoding='utf8')
        with self.assertRaises(one_click.WorkflowError):
            one_click.run_workflow(input_path=src,output_dir=out,ledger=self.db,sender_uid='sender',account={},samples=[],provider=provider,send=lambda *x:sends.append(x),execute=True)
        self.assertEqual(len(sends),1)

if __name__=='__main__':unittest.main(verbosity=2)
