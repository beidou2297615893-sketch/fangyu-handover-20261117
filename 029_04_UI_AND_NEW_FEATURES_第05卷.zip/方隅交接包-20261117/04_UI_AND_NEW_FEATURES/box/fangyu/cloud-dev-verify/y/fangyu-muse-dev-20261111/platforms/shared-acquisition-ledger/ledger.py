import argparse, csv, json, sqlite3, sys, time
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8'); sys.stderr.reconfigure(encoding='utf-8')
p=argparse.ArgumentParser(); p.add_argument('--db',required=True); sp=p.add_subparsers(dest='cmd',required=True)
def command(name,*args):
 q=sp.add_parser(name)
 for x in args:q.add_argument(x)
command('assess','platform','customer','comment','path'); command('init'); command('lead','platform','customer','comment'); command('identity-bind','platform','customer','canonical','evidence'); command('history-clear','platform','customer','comment','operator','evidence'); command('review','platform','customer','comment','operator','evidence'); command('reserve','platform','customer','comment','token'); command('outcome','token','status','evidence'); command('import-history','path'); command('import-assessments','path'); command('import-deliveries','path'); command('import-words','path','kind'); command('word-list'); command('lead-list'); command('search','event','store','platform','keyword','status','result'); command('search-list'); command('check','platform','customer','comment')
a=p.parse_args()
def require(*values):
 if any(not isinstance(x,str) or not x.strip() for x in values):raise ValueError('invalid or empty identifier or evidence')
def platform(v):
 if v not in ('xiaohongshu','douyin'):raise ValueError('invalid platform')
def now():return int(time.time())
def output(obj):print(json.dumps(obj,ensure_ascii=False))
try:
 if a.cmd!='init' and not Path(a.db).is_file():raise ValueError('ledger database not found; refusing to create a new one')
 db=sqlite3.connect(a.db,timeout=30,isolation_level=None); db.row_factory=sqlite3.Row; db.execute('PRAGMA busy_timeout=30000'); db.execute('PRAGMA journal_mode=WAL'); db.execute('PRAGMA foreign_keys=ON')
 db.executescript('''CREATE TABLE IF NOT EXISTS leads(platform TEXT NOT NULL, customer TEXT NOT NULL, comment TEXT NOT NULL, status TEXT NOT NULL, review_time INTEGER, evidence TEXT, operator TEXT, source TEXT NOT NULL, PRIMARY KEY(platform,customer,comment), UNIQUE(platform,comment));
 CREATE TABLE IF NOT EXISTS assessments(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,data TEXT NOT NULL,updated INTEGER NOT NULL,PRIMARY KEY(platform,customer,comment), FOREIGN KEY(platform,customer,comment) REFERENCES leads(platform,customer,comment));
 CREATE TABLE IF NOT EXISTS reservations(token TEXT PRIMARY KEY, platform TEXT NOT NULL, customer TEXT NOT NULL, comment TEXT NOT NULL, status TEXT NOT NULL, evidence TEXT, created INTEGER NOT NULL, FOREIGN KEY(platform,customer,comment) REFERENCES leads(platform,customer,comment));
 CREATE TABLE IF NOT EXISTS searches(event TEXT PRIMARY KEY, store TEXT NOT NULL, platform TEXT NOT NULL, keyword TEXT NOT NULL, status TEXT NOT NULL, result TEXT NOT NULL, recorded INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS words(store TEXT NOT NULL, keyword TEXT NOT NULL, category TEXT NOT NULL, priority TEXT NOT NULL, evidence TEXT NOT NULL, condition TEXT NOT NULL, source TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'candidate', PRIMARY KEY(store,keyword,source));
 CREATE TABLE IF NOT EXISTS identity_aliases(platform TEXT NOT NULL, alias TEXT NOT NULL, canonical TEXT NOT NULL, evidence TEXT NOT NULL, verified INTEGER NOT NULL, PRIMARY KEY(platform,alias));
 CREATE TABLE IF NOT EXISTS historical_assessments(platform TEXT NOT NULL,customer TEXT NOT NULL,source TEXT NOT NULL,data TEXT NOT NULL,recorded INTEGER NOT NULL,PRIMARY KEY(platform,customer,source));
 CREATE TABLE IF NOT EXISTS historical_deliveries(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,reference TEXT NOT NULL,delivery_state TEXT NOT NULL,source TEXT NOT NULL,recorded INTEGER NOT NULL,PRIMARY KEY(platform,reference,comment));''')
 if db.execute('SELECT 1 FROM identity_aliases a JOIN identity_aliases b ON a.platform=b.platform AND a.canonical=b.alias WHERE b.canonical<>a.canonical LIMIT 1').fetchone():raise ValueError('legacy identity chain requires manual reconciliation')
 if db.execute('SELECT 1 FROM identity_aliases a JOIN leads l ON a.platform=l.platform AND a.alias=l.customer WHERE a.alias<>a.canonical LIMIT 1').fetchone():raise ValueError('legacy split identity history requires manual reconciliation')
 if db.execute('SELECT 1 FROM identity_aliases a JOIN historical_assessments h ON a.platform=h.platform AND a.alias=h.customer WHERE a.alias<>a.canonical LIMIT 1').fetchone():raise ValueError('legacy split identity assessments require manual reconciliation')
 if db.execute('SELECT 1 FROM identity_aliases a JOIN historical_deliveries h ON a.platform=h.platform AND a.alias=h.customer WHERE a.alias<>a.canonical LIMIT 1').fetchone():raise ValueError('legacy split identity deliveries require manual reconciliation')
 def resolve(pl,customer):
  alias=db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',(pl,customer)).fetchone()
  return alias['canonical'] if alias else customer
 if a.cmd=='init': output({'ok':True})
 elif a.cmd=='identity-bind':
  platform(a.platform); require(a.customer,a.canonical,a.evidence); db.execute('BEGIN IMMEDIATE')
  canonical_alias=db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',(a.platform,a.canonical)).fetchone()
  if canonical_alias and canonical_alias['canonical']!=a.canonical:raise ValueError('identity chain forbidden')
  if a.customer!=a.canonical and db.execute('SELECT 1 FROM identity_aliases WHERE platform=? AND canonical=? AND alias<>? LIMIT 1',(a.platform,a.customer,a.customer)).fetchone():raise ValueError('identity chain forbidden')
  row=db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',(a.platform,a.customer)).fetchone()
  if row and row['canonical']!=a.canonical:raise ValueError('identity alias conflict')
  if not row:
   if a.customer!=a.canonical and db.execute('SELECT 1 FROM leads WHERE platform=? AND customer=? LIMIT 1',(a.platform,a.customer)).fetchone():raise ValueError('alias already has separate history; reconcile before binding')
   if a.customer!=a.canonical and db.execute('SELECT 1 FROM historical_assessments WHERE platform=? AND customer=? LIMIT 1',(a.platform,a.customer)).fetchone():raise ValueError('alias already has separate assessment; reconcile before binding')
   if a.customer!=a.canonical and db.execute('SELECT 1 FROM historical_deliveries WHERE platform=? AND customer=? LIMIT 1',(a.platform,a.customer)).fetchone():raise ValueError('alias already has separate delivery history; reconcile before binding')
   db.execute('INSERT INTO identity_aliases VALUES(?,?,?,?,?)',(a.platform,a.customer,a.canonical,a.evidence,now()))
  else:db.execute('UPDATE identity_aliases SET evidence=?,verified=? WHERE platform=? AND alias=?',(a.evidence,now(),a.platform,a.customer))
  db.commit(); output({'status':'identity_bound','canonical':a.canonical})
 elif a.cmd=='lead':
  platform(a.platform); require(a.customer,a.comment); db.execute('BEGIN IMMEDIATE'); a.customer=resolve(a.platform,a.customer); db.execute("INSERT OR IGNORE INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,'unverified','cli')",(a.platform,a.customer,a.comment)); row=db.execute('SELECT * FROM leads WHERE platform=? AND comment=?',(a.platform,a.comment)).fetchone()
  if not row or row['customer']!=a.customer:raise ValueError('comment identity conflict')
  db.commit(); output(dict(row))
 elif a.cmd=='assess':
  platform(a.platform); require(a.customer,a.comment); data=json.loads(Path(a.path).read_text(encoding='utf-8-sig')); required=('source','intent','store','match','pending','draft','peer_reply')
  if not isinstance(data,dict) or any(k not in data for k in required):raise ValueError('missing screening field')
  require(data['source'],data['store']);
  if not isinstance(data['pending'],str) or not isinstance(data['draft'],str):raise ValueError('invalid screening text')
  if data['intent']=='rental' and data['match']=='match' and data['peer_reply']=='none':require(data['draft'])
  if data['intent'] not in ('rental','unverified','exclude') or data['match'] not in ('match','unverified','not_match') or data['peer_reply'] not in ('none','unknown','replied'):raise ValueError('invalid screening status')
  db.execute('BEGIN IMMEDIATE'); a.customer=resolve(a.platform,a.customer); row=db.execute('SELECT status FROM leads WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone()
  if not row or row['status'] not in ('unverified','reviewed'):raise ValueError('cannot change screening for unresolved or sent record')
  db.execute('INSERT INTO assessments VALUES(?,?,?,?,?) ON CONFLICT(platform,customer,comment) DO UPDATE SET data=excluded.data,updated=excluded.updated',(a.platform,a.customer,a.comment,json.dumps(data,ensure_ascii=False),now())); db.execute("UPDATE leads SET status='unverified',review_time=NULL WHERE platform=? AND customer=? AND comment=?",(a.platform,a.customer,a.comment)); db.commit(); output({'status':'screened'})
 elif a.cmd=='review':
  platform(a.platform); require(a.customer,a.comment,a.operator,a.evidence); db.execute('BEGIN IMMEDIATE'); a.customer=resolve(a.platform,a.customer); row=db.execute('SELECT * FROM leads WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone()
  if not row or row['status'] not in ('unverified','reviewed'):raise ValueError('cannot review: missing or unresolved/sent')
  db.execute("UPDATE leads SET status='reviewed',review_time=?,operator=?,evidence=? WHERE platform=? AND customer=? AND comment=?",(now(),a.operator,a.evidence,a.platform,a.customer,a.comment)); db.commit(); output({'status':'reviewed'})
 elif a.cmd=='history-clear':
  platform(a.platform); require(a.customer,a.comment,a.operator,a.evidence); db.execute('BEGIN IMMEDIATE'); a.customer=resolve(a.platform,a.customer)
  row=db.execute('SELECT status FROM leads WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone()
  if not row or row['status'] not in ('unverified','reviewed','history_clear'):raise ValueError('history cannot be cleared: missing or unresolved/sent')
  db.execute("UPDATE leads SET status='history_clear',review_time=?,operator=?,evidence=? WHERE platform=? AND customer=? AND comment=?",(now(),a.operator,a.evidence,a.platform,a.customer,a.comment)); db.commit(); output({'status':'history_clear','warning':'Human assertion only; no platform verification performed.'})
 elif a.cmd=='reserve':
  platform(a.platform); require(a.customer,a.comment,a.token); db.execute('BEGIN IMMEDIATE'); a.customer=resolve(a.platform,a.customer); old=db.execute('SELECT * FROM reservations WHERE token=?',(a.token,)).fetchone()
  if old:
   if (old['platform'],old['customer'],old['comment'])!=(a.platform,a.customer,a.comment):raise ValueError('token conflict')
   db.commit(); output({**dict(old),'granted':False})
  else:
   row=db.execute('SELECT * FROM leads WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone()
   if not row or row['status']!='reviewed' or not row['review_time'] or now()-row['review_time']>86400:raise ValueError('not reviewed or review expired')
   if not db.execute('SELECT 1 FROM identity_aliases WHERE platform=? AND canonical=? AND verified>=? LIMIT 1',(a.platform,a.customer,now()-86400)).fetchone():raise ValueError('verified identity and history mapping required')
   screened=db.execute('SELECT data FROM assessments WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone()
   if not screened:raise ValueError('screening missing')
   data=json.loads(screened['data'])
   if data['intent']!='rental' or data['match']!='match' or data['peer_reply']!='none':raise ValueError('screening not eligible')
   other=db.execute("SELECT count(*) FROM leads WHERE platform=? AND customer=? AND comment<>? AND (status<>'history_clear' OR review_time IS NULL OR review_time<?)",(a.platform,a.customer,a.comment,now()-86400)).fetchone()[0]
   if other:raise ValueError('other customer history unresolved or already replied')
   db.execute("INSERT INTO reservations VALUES(?,?,?,?, 'reserved',NULL,?)",(a.token,a.platform,a.customer,a.comment,now())); db.execute("UPDATE leads SET status='reserved' WHERE platform=? AND customer=? AND comment=?",(a.platform,a.customer,a.comment)); db.commit(); output({'token':a.token,'status':'reserved','granted':True})
 elif a.cmd=='outcome':
  require(a.token,a.evidence)
  if a.status not in ('sent','unknown','not_sent'):raise ValueError('invalid outcome')
  db.execute('BEGIN IMMEDIATE'); row=db.execute('SELECT * FROM reservations WHERE token=?',(a.token,)).fetchone()
  if not row:raise ValueError('missing reservation')
  if row['status']==a.status:
   if row['evidence']!=a.evidence:raise ValueError('outcome evidence conflict')
  elif row['status'] not in ('reserved','unknown') or (row['status']=='unknown' and a.status=='unknown'):raise ValueError('invalid transition')
  else:
   db.execute('UPDATE reservations SET status=?,evidence=? WHERE token=?',(a.status,a.evidence,a.token)); db.execute('UPDATE leads SET status=?,review_time=NULL WHERE platform=? AND customer=? AND comment=?',('unverified' if a.status=='not_sent' else a.status,row['platform'],row['customer'],row['comment']))
   if a.status=='not_sent':db.execute('DELETE FROM assessments WHERE platform=? AND customer=? AND comment=?',(row['platform'],row['customer'],row['comment']))
  db.commit(); output({'token':a.token,'status':a.status})
 elif a.cmd=='import-history':
  path=Path(a.path); data=json.loads(path.read_text(encoding='utf-8-sig')); db.execute('BEGIN IMMEDIATE'); count=0
  for r in data['records']:
   pl=r['platform']; platform(pl); customer=r.get('customer_id'); comment=r.get('comment_id'); require(customer,comment); customer=resolve(pl,customer)
   cur=db.execute("INSERT OR IGNORE INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,'unverified',?)",(pl,customer,comment,str(path.resolve())))
   row=db.execute('SELECT customer FROM leads WHERE platform=? AND comment=?',(pl,comment)).fetchone()
   if not row or row['customer']!=customer:raise ValueError('history identity conflict')
   count+=cur.rowcount
  db.commit(); output({'inserted':count,'source_count':len(data['records']),'status':'unverified'})
 elif a.cmd=='import-assessments':
  path=Path(a.path); db.execute('BEGIN IMMEDIATE'); count=0; total=0
  with path.open(encoding='utf-8-sig') as f:
   for line in f:
    if not line.strip():continue
    item=json.loads(line); pl=item['platform']; customer=item['customer_id']; assessment=item['existing_assessment']; platform(pl); require(customer)
    if not isinstance(assessment,dict):raise ValueError('invalid historical assessment')
    customer=resolve(pl,customer); payload=json.dumps(assessment,ensure_ascii=False,sort_keys=True)
    existing=db.execute('SELECT data FROM historical_assessments WHERE platform=? AND customer=? AND source=?',(pl,customer,str(path.resolve()))).fetchone()
    if existing and existing['data']!=payload:raise ValueError('historical assessment conflict')
    if not existing:
     db.execute('INSERT INTO historical_assessments VALUES(?,?,?,?,?)',(pl,customer,str(path.resolve()),payload,now()));count+=1
    total+=1
  db.commit(); output({'inserted':count,'source_count':total,'status':'historical_unverified'})
 elif a.cmd=='import-deliveries':
  path=Path(a.path); data=json.loads(path.read_text(encoding='utf-8-sig')); db.execute('BEGIN IMMEDIATE'); count=0
  for item in data['records']:
   pl=item['platform'];customer=item['customer_id'];comment=item['comment_id'];state=item['delivery_state'];ref=item['reference'];platform(pl);require(customer,comment,state,ref);customer=resolve(pl,customer)
   if state not in ('prepared','blocked','submitted'):raise ValueError('unrecognized historical delivery state')
   if not db.execute('SELECT 1 FROM leads WHERE platform=? AND customer=? AND comment=?',(pl,customer,comment)).fetchone():raise ValueError('historical delivery target not mapped')
   old=db.execute('SELECT customer,delivery_state FROM historical_deliveries WHERE platform=? AND reference=? AND comment=?',(pl,ref,comment)).fetchone()
   if old and (old['customer']!=customer or old['delivery_state']!=state):raise ValueError('historical delivery conflict')
   if not old:db.execute('INSERT INTO historical_deliveries VALUES(?,?,?,?,?,?,?)',(pl,customer,comment,ref,state,str(path.resolve()),now()));count+=1
   if state=='submitted':db.execute("UPDATE leads SET status='unknown',review_time=NULL,evidence='Prior software submitted; platform receipt unknown' WHERE platform=? AND customer=? AND comment=? AND status IN ('unverified','reviewed','history_clear')",(pl,customer,comment))
  db.commit(); output({'inserted':count,'source_count':len(data['records']),'status':'historical_unverified'})
 elif a.cmd=='import-words':
  path=Path(a.path); rows=list(csv.DictReader(path.open(encoding='utf-8-sig',newline=''))); db.execute('BEGIN IMMEDIATE'); count=0
  for r in rows:
   if a.kind=='gubei': vals=('古北店',r['搜索词'],r['类别'],r['优先级'],r['来源依据'],r['使用条件'])
   elif a.kind=='shared':
    group=r['group']; vals=(group.split('/')[0],r['keyword'],group,r['priority'],'历史候选词，具体依据待核','原文件未启用；资料待核')
   else:raise ValueError('invalid word source kind')
   require(*vals); cur=db.execute('INSERT OR IGNORE INTO words(store,keyword,category,priority,evidence,condition,source) VALUES(?,?,?,?,?,?,?)',(*vals,str(path.resolve()))); count+=cur.rowcount
  db.commit(); output({'inserted':count,'source_count':len(rows),'status':'candidate'})
 elif a.cmd=='search':
  platform(a.platform); require(a.event,a.store,a.keyword,a.result)
  if a.status not in ('started','completed','failed','partial'):raise ValueError('invalid search status')
  db.execute('BEGIN IMMEDIATE'); fields=(a.store,a.platform,a.keyword,a.status,a.result); row=db.execute('SELECT * FROM searches WHERE event=?',(a.event,)).fetchone()
  if row and tuple(row[k] for k in ('store','platform','keyword','status','result'))!=fields:raise ValueError('event conflict; use new event for each state')
  if not row:db.execute('INSERT INTO searches VALUES(?,?,?,?,?,?,?)',(a.event,*fields,now()))
  db.commit(); output({'event':a.event,'status':a.status})
 elif a.cmd in ('word-list','lead-list','search-list'):
  table={'word-list':'words','lead-list':'leads','search-list':'searches'}[a.cmd]; output({'records':[dict(x) for x in db.execute('SELECT * FROM '+table)]})
 elif a.cmd=='check':
  platform(a.platform); require(a.customer,a.comment); db.execute('BEGIN'); a.customer=resolve(a.platform,a.customer); row=db.execute('SELECT * FROM leads WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone(); related=db.execute('SELECT comment,status FROM leads WHERE platform=? AND customer=?',(a.platform,a.customer)).fetchall(); screen=db.execute('SELECT data FROM assessments WHERE platform=? AND customer=? AND comment=?',(a.platform,a.customer,a.comment)).fetchone(); historical=db.execute('SELECT source,data,recorded FROM historical_assessments WHERE platform=? AND customer=?',(a.platform,a.customer)).fetchall(); deliveries=db.execute('SELECT comment,reference,delivery_state,source,recorded FROM historical_deliveries WHERE platform=? AND customer=?',(a.platform,a.customer)).fetchall(); db.commit(); output({'target':dict(row) if row else None,'assessment':json.loads(screen['data']) if screen else None,'historical_assessments':[{'source':x['source'],'data':json.loads(x['data']),'recorded':x['recorded']} for x in historical],'historical_deliveries':[dict(x) for x in deliveries],'related':[dict(x) for x in related],'warning':'Historical assessments and deliveries are snapshots, not current platform receipts. No platform check performed.'})
except Exception as e:
 try:db.rollback()
 except Exception:pass
 output({'error':str(e)}); sys.exit(1)
