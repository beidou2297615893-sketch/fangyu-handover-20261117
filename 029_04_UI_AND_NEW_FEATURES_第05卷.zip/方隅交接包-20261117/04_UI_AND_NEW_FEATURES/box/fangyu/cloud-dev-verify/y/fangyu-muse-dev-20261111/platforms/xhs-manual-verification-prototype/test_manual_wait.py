import unittest
from types import SimpleNamespace
from manual_wait import await_completion, ManualVerificationStopped


class Tests(unittest.TestCase):
    def test_challenge_retains_page_and_waits_for_its_success(self):
        responses = iter([SimpleNamespace(status=461), SimpleNamespace(status=471),
                          SimpleNamespace(status=200, payload={'success': True, 'data': {'login_info': {}}})])
        events = []
        result = await_completion(lambda _: next(responses), on_event=events.append)
        self.assertEqual(result, {'login_info': {}})
        self.assertEqual(len(events), 2)

    def test_unknown_failure_stops_without_retry(self):
        calls = []
        def respond(_):
            calls.append(1)
            return SimpleNamespace(status=429)
        with self.assertRaisesRegex(ManualVerificationStopped, 'http_error'):
            await_completion(respond)
        self.assertEqual(len(calls), 1)

    def test_false_business_success_never_authenticates(self):
        response = SimpleNamespace(status=200, payload={'success': False, 'data': {}})
        with self.assertRaisesRegex(ManualVerificationStopped, 'not_confirmed'):
            await_completion(lambda _: response)

    def test_timeout_is_bounded(self):
        times = iter([0, 0, 3])
        with self.assertRaisesRegex(ManualVerificationStopped, 'timeout'):
            await_completion(lambda _: SimpleNamespace(status=461), timeout_s=2,
                             clock=lambda: next(times))

    def test_sensitive_error_does_not_escape(self):
        def respond(_):
            raise ValueError('SECRET URL TOKEN')
        with self.assertRaises(ManualVerificationStopped) as caught:
            await_completion(respond)
        self.assertNotIn('SECRET', str(caught.exception))


if __name__ == '__main__':
    unittest.main()
