"""Bind the frozen current batch to a normally logged-in account; no sends."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]

def load_cli():
    spec=importlib.util.spec_from_file_location('current_frozen_reply_cli',PROJECT/'work/xhs-cli-standalone-entry/standalone_cli.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def candidate_pending(row,states):
    """Check history before a real attempt ID has been allocated by prepare_batch."""
    platform=row.get('platform','xiaohongshu')
    keys={'comment':row.get('comment_id'),'customer':row.get('customer_id'),'uid':row.get('customer_uid')}
    if not all(isinstance(x,str) and x.strip() for x in (platform,*keys.values())):return False
    indices=set()
    for key,value in keys.items():indices.update(states[key].get((platform,value),set()))
    return all(states['events'][i].get('state')=='not_sent' for i in indices)

def prepare(home,run_name):
    home=Path(home).resolve(strict=True)
    allowed=(PROJECT/'work/xhs-standalone-session').resolve(strict=True)
    if not home.is_relative_to(allowed) or home==allowed:
        raise ValueError('explicit_private_login_home_required')
    receipt=json.loads((home/'identity-receipt.json').read_text(encoding='utf8'))
    if receipt.get('guest') is not False or receipt.get('saved') is not True:
        raise ValueError('successful_normal_login_required')
    uid=receipt.get('uid')
    if not isinstance(uid,str) or not uid.strip():raise ValueError('sender_uid_missing')
    sources=json.loads((HERE/'source-manifest.json').read_text(encoding='utf8'))
    frozen=json.loads((HERE/'frozen-source-receipt.json').read_text(encoding='utf8'))
    for item in frozen.values():
        if hashlib.sha256(Path(item['frozen']).read_bytes()).hexdigest()!=item['sha256']:
            raise ValueError('frozen_source_changed')
    cli=load_cli()
    ledger=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'
    states=cli.ledger_states(ledger)
    rows=json.loads((HERE/'input.json').read_text(encoding='utf8'))
    pending=[row for row in rows if candidate_pending(row,states)]
    if not pending:raise ValueError('no_locally_pending_targets')
    root=HERE/'runs'/run_name
    root.mkdir(parents=True,exist_ok=False)
    (root/'input.json').write_text(json.dumps(pending,ensure_ascii=False,indent=2),encoding='utf8')
    (root/'first-input.json').write_text(json.dumps(pending[:1],ensure_ascii=False,indent=2),encoding='utf8')
    args=SimpleNamespace(input=str(root/'input.json'),output=str(root/'prepared-batch.json'),source_manifest=str(HERE/'source-manifest.json'),sender_uid=uid)
    cli.prepare_batch(args)
    args.input=str(root/'first-input.json');args.output=str(root/'prepared-first.json')
    cli.prepare_batch(args)
    report={'status':'prepared_not_sent','sender_uid':uid,'normal_login_receipt':str(home/'identity-receipt.json'),
        'pending':len(pending),'excluded_existing_local_states':len(rows)-len(pending),
        'priority':'super_high_high_medium','current_platform_identity_recheck_required':True,
        'target_readback_required_before_first_submit':True,'platform_history_checked':False,
        'send_attempts':0,'shared_ledger_mutations':0}
    (root/'preparation-receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session-home')
    parser.add_argument('--run-name',default='account-001')
    parser.add_argument('--prepare',action='store_true')
    args=parser.parse_args()
    if not args.prepare:
        print(json.dumps({'mode':'preview','network':False,'ledger_write':False,'send':False}))
    else:
        if not args.session_home:parser.error('--session-home required')
        if not args.run_name.replace('-','').replace('_','').isalnum():parser.error('invalid run name')
        print(json.dumps(prepare(args.session_home,args.run_name),ensure_ascii=False))
