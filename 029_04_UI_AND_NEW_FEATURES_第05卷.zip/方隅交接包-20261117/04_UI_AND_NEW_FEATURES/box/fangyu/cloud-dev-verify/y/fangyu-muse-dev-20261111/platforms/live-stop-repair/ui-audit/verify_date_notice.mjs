import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const H=path.dirname(fileURLToPath(import.meta.url)),S='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview';
const file=path.join(S,'pages/reply-connected.mjs'),source=fs.readFileSync(file,'utf8');const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const additions=['${preview.sourceNotice?`<p class="rp-loading-note">${esc(preview.sourceNotice)}</p>`:\'\'}','${row.sourceNotice?`<small class="rp-loading-note">${esc(row.sourceNotice)}</small>`:\'\'}'];
let previous=source;for(const text of additions){if(previous.split(text).length!==2)throw Error('Expected exact one readonly notice addition');previous=previous.replace(text,'');}
const previousBytes=hash(previous)==='0dfac2ff17eaa65e25fb833e8a293507c5ab9a743eea452cae0be7e4b738a474'?previous:previous.replace(/\r\n/g,'\n');
if(hash(previousBytes)!=='0dfac2ff17eaa65e25fb833e8a293507c5ab9a743eea452cae0be7e4b738a474')throw Error('Other reply source changes require review');
const scope={console,URL,Date,JSON,Promise,Set,Map,queueMicrotask,customerAvatar:()=>'<img alt="">',postCover:()=>'<img alt="">',renderBatch:()=>'',renderDelivery:()=>'',workflowScope:()=>'',personaChoices:{employee:'员工'}};
vm.createContext(scope);vm.runInContext(source.replace(/^import\s.*?;\s*$/gm,'').replace(/^export\s+/gm,'')+'\nglobalThis.renderTest=renderConnected;',scope);
const tests=[];
for(const detail of [false,true])for(const unsafe of [false,true]){
 const notice=unsafe?'<script>alert("notice")</script>':'帖子日期未提供，时间范围待核实';
 const item={id:'a',name:'Synthetic customer',postTitle:'Synthetic post',quote:'Synthetic comment',sourceNotice:notice,platform:'xiaohongshu'};
 const state={connection:'connected',session:{},page:'reply',user:'employee',storeId:'store',authEpoch:1,activePlatform:'xiaohongshu'};
 state.replyLive={actor:'1|employee|store|xiaohongshu',status:'ready',items:[item],stats:{total:1,replied:0},tab:'pending',groupBy:'post',query:'',page:1,total:1,pages:1,generation:0,selectedId:'a',leadId:detail?'lead_a':'',text:detail?'DRAFT':'',accountId:'',busy:false,pending:null,error:'',detail:detail?{item,customerId:'a',comments:[{id:'lead_a',text:item.quote,postTitle:item.postTitle,sourceNotice:notice,accounts:[],canSave:true}]}:null,detailLoading:!detail,collapsedGroups:[],intent:'all',checkedIds:[]};
 const html=scope.renderTest(state),editor=html.match(/<aside\b[^>]*class="rp-editor"[^>]*>([\s\S]*?)<\/aside>/)?.[1]||'';
 const escaped=unsafe?editor.includes('&lt;script&gt;alert(&quot;notice&quot;)&lt;/script&gt;')&&!editor.includes('<script>'):editor.includes(notice);
 const readOnly=detail||!/textarea|data-live-save|data-live-review/.test(editor);
 tests.push({name:(detail?'authoritative source':'readonly preview')+(unsafe?' escapes injected HTML':' shows date uncertainty'),passed:escaped&&readOnly});
 if(detail&&!unsafe){
   state.replyLive.detail.item.sourceNotice='OTHER_REPRESENTATIVE_NOTICE';
   const exact=scope.renderTest(state).match(/<aside\b[^>]*class="rp-editor"[^>]*>([\s\S]*?)<\/aside>/)?.[1]||'';
   tests.push({name:'detail notice belongs to selected original comment, not customer representative',passed:exact.includes(notice)&&!exact.includes('OTHER_REPRESENTATIVE_NOTICE')});
   state.replyLive.detail.comments[0].sourceNotice='';
   const verified=scope.renderTest(state).match(/<aside\b[^>]*class="rp-editor"[^>]*>([\s\S]*?)<\/aside>/)?.[1]||'';
   tests.push({name:'verified selected source does not inherit another post uncertainty',passed:!verified.includes(notice)&&!verified.includes('OTHER_REPRESENTATIVE_NOTICE')});
 }
}
const report={status:tests.every(t=>t.passed)?'PASS_DATE_NOTICE_ONLY':'FAIL',tests,checks:tests.length,passed:tests.filter(t=>t.passed).length,only_two_escaped_readonly_additions:true,line_endings_normalized_to_LF:previous!==previousBytes,previous_reviewed_sha256:hash(previousBytes),new_source_sha256:hash(source),source_stable:source===fs.readFileSync(file,'utf8'),old_17_matrix_rerun:false,platform_requests:0,model_requests:0,UI_operations:0,product_edits:0};
fs.writeFileSync(path.join(H,'DATE-NOTICE-REVIEW.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(report.status!=='PASS_DATE_NOTICE_ONLY')process.exitCode=1;
