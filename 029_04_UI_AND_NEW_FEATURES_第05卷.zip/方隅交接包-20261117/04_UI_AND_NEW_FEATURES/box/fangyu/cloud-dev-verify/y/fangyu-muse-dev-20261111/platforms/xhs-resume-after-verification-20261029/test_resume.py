import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timezone
import resume

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf8')

class ResumeTests(unittest.TestCase):
    def setUp(self):
        runtime=Path(__file__).resolve().parent/'runtime';runtime.mkdir(exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=runtime);self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.ledger=self.root/'ledger.sqlite3'
        with closing(sqlite3.connect(self.ledger)) as db:
            db.execute('CREATE TABLE leads(platform,customer,comment,source)')
            db.commit()
        self.session=self.root/'session';write(self.session/'.xiaohongshu-cli/cookies.json',{})
        write(self.session/'identity-receipt.json',{'uid':'ACCOUNT','guest':False,
              'verified_at':datetime.now(timezone.utc).isoformat(),'saved':True})
        self.old=self.root/'old';self.active=self.root/'active'
        self.segment(self.old,23,2,100,False)
        self.segment(self.active,39,3,98,True)
        self.campaign=self.root/'campaign.json'
        write(self.campaign,{'global_target':100,'active_root':str(self.active),'active_baseline':2,
              'completed_segments':[{'root':str(self.old),'registered_comments':2}]})
    def segment(self,root,first,count,target,blocked):
        keyword='红松东路租房';plan=[{'keyword':keyword,'page':1},{'keyword':keyword,'page':2}]
        if not blocked:plan=plan[:1]
        state={'status':'outcome_unknown' if blocked else 'plan_exhausted','cursor':1,
               'next_batch':first+1,'plan':plan,'target':target,'inserted':count,
               'inflight':{'batch':f'batch-{first+1:04d}','keyword':keyword,'page':2,'remaining':target-count} if blocked else None}
        config={'first_batch':first,'source_db':str(self.root/'source.sqlite3'),'session_home':str(self.session),
                'ledger':str(self.ledger),'max_comment_pages':2,'target':target,'plan':plan}
        write(root/'state.json',state);write(root/'task-config.json',config)
        batch=f'batch-{first:04d}';folder=root/batch
        account={'uid':'ACCOUNT','guest':False}
        customers=[{'customer_id':f'U{first}-{i}','customer_uid':f'UID{first}-{i}',
                    'comment_id':f'C{first}-{i}','note_id':'NOTE','comment_text':'TEXT'} for i in range(count)]
        write(folder/'account-binding.json',account)
        write(folder/'collection.json',{'collection_account':account,'customers':customers,'keyword':keyword})
        write(folder/'new-ai-input.json',customers)
        write(folder/'register-result.json',{'account':account,'result':{'inserted':count,'mode':'apply'}})
        write(folder/'registered-ready.json',{'registered':True,'account_uid':'ACCOUNT','inserted_comments':count,'input':'new-ai-input.json'})
        source='collection:'+str((folder/'collection.json').resolve())
        with closing(sqlite3.connect(self.ledger)) as db:
            db.executemany('INSERT INTO leads VALUES(?,?,?,?)',[('xiaohongshu',x['customer_id'],x['comment_id'],source) for x in customers])
            db.commit()
        event={'batch':batch,'keyword':keyword,'page':1,'inserted_comments':count,'account_uid':'ACCOUNT',
               'input':f'{batch}/new-ai-input.json','registration_source':source,
               'sha256':hashlib.sha256((folder/'new-ai-input.json').read_bytes()).hexdigest(),
               'status':'registered_ready_for_classification'}
        (root/'analysis-manifest.jsonl').write_text(json.dumps(event)+'\n',encoding='utf8')
        if blocked:
            failed=root/f'batch-{first+1:04d}'
            write(failed/'account-binding.json',account)
            (failed/'account-audit.jsonl').write_text(json.dumps({'status':'stopped_before_registration'})+'\n',encoding='utf8')
    def test_resume_preserves_global_base_and_uses_new_batch(self):
        result=resume.prepare(self.campaign,self.session)
        self.assertEqual(result['base_inserted'],5)
        self.assertEqual(result['remaining_target'],95)
        self.assertEqual(result['first_batch'],41)
        self.assertEqual(result['plan'],[{'keyword':'红松东路租房','page':2}])
    def test_failed_batch_ledger_write_refuses_resume(self):
        with closing(sqlite3.connect(self.ledger)) as db:
            db.execute('INSERT INTO leads VALUES(?,?,?,?)',('xiaohongshu','BAD','BAD','collection:'+str((self.active/'batch-0040/collection.json').resolve())))
            db.commit()
        with self.assertRaises(ValueError):resume.prepare(self.campaign,self.session)
    def test_started_registration_refuses_resume(self):
        audit=self.active/'batch-0040/account-audit.jsonl'
        audit.write_text(json.dumps({'status':'registration_started'})+'\n'+json.dumps({'status':'stopped_before_registration'})+'\n',encoding='utf8')
        with self.assertRaises(ValueError):resume.prepare(self.campaign,self.session)

if __name__=='__main__':unittest.main()
