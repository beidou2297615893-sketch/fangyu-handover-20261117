"""Exact batch22 local registration wrapper; no network capability."""
import argparse,hashlib,importlib.util,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
SOURCE=PROJECT/'work/xhs-partial-registration-recovery-20261029/recover.py'
if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!='2029b5642224d664753bf24136b37ea774d04acd81964e8ce135d4a9f5ab5b17':raise RuntimeError('recovery_dependency_changed')
spec=importlib.util.spec_from_file_location('reviewed_local_partial_recovery',SOURCE)
rec=importlib.util.module_from_spec(spec);spec.loader.exec_module(rec)
ROOT=PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume005-20261103'
PARTIAL=ROOT/'batch-0022/partial-0007.json'
OUTPUT=PROJECT/'work/xhs-partial-registration-recovery-20261029/runtime/stores15-resume005-batch22-recovery'
# Narrow path adaptation only. Every original hash/UID/claim/transaction check remains.
rec.RECOVERY=ROOT
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    proof=None
    if a.execute:
        binding=rec.read(PARTIAL.parent/'account-binding.json')
        if binding.get('uid')!='5aa9b337e8ac2b4ab2d21957' or binding.get('guest') is not False or binding.get('proof_source')!='same_client_user_me':raise ValueError('real_identity_required')
        proof=HERE/'partial-registration-identity.json'
        value={'status':'verified','account':{'uid':binding['uid'],'guest':False},'proof_source':binding['proof_source'],'verified_at':binding['verified_at']}
        if proof.exists():
            if rec.read(proof)!=value:raise ValueError('identity_receipt_conflict')
        else:rec.write(proof,value)
    result=rec.recover(PARTIAL,ledger=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3',source_db=PROJECT/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3',output=OUTPUT,identity_receipt=proof,execute=a.execute,allow_real_ledger=a.execute)
    print(json.dumps({k:v for k,v in result.items() if k not in ('existing_comments','not_yet_registered_comment_ids')},ensure_ascii=False))
if __name__=='__main__':main()
