"""Execute only named real method bodies against in-memory fakes, never Core/HTTP."""
from pathlib import Path
from types import SimpleNamespace,MethodType
import ast,hashlib,json,re,sys,threading
from datetime import datetime,timezone

P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
N=P/'work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-native-r57'
O=Path(__file__).resolve().parent
mode='baseline' if '--baseline' in sys.argv else 'after'
hashes={}
def method(file,cls,name,extra=None):
    path=N/file;raw=path.read_bytes();hashes[file]=hashlib.sha256(raw).hexdigest()
    tree=ast.parse(raw.decode('utf-8-sig'));klass=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name==cls)
    fn=next(node for node in klass.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==name)
    fn.decorator_list=[]
    space={} if extra is None else dict(extra)
    exec(compile(ast.Module(body=[fn],type_ignores=[]),str(path),'exec'),space)
    return space[name]
class Error(ValueError):
    def __init__(self,code,message='',status=400):self.code,self.status=code,status;super().__init__(message)
def fail(code,message,status=400):raise Error(code,message,status)
user={'id':'owned-user','tenant_id':'owned-tenant','username':'owned-worker','role':'operator','cloud_bound':True,'disabled':False}

calls=[]
class History:
    def customer_detail(self,ident,actor):calls.append('history.customer_detail');return {'comments':[],'id':ident}
core=SimpleNamespace(lock=threading.RLock())
customer=SimpleNamespace(core=core,platform_filter=lambda data:data['platform'],_actor=lambda actor,store:(dict(user),{'username':user['username'],'storeId':store}),_history=lambda *a:History(),_with_rental_assessment=lambda *a:None,_project=lambda person,**kw:{'id':person['id']},_handoff_records=lambda *a:[],_handoff_summary=lambda *a:None)
extra={'KEY':re.compile('[0-9a-f]{64}\\Z'),'CoreError':Error,'_fail':fail,'SCOPE':'employee-local-history'}
customer.detail=MethodType(method('customer_workbench.py','CustomerWorkbench','detail',extra),customer)
if mode=='after':
    customer.detail_context=MethodType(method('customer_workbench.py','CustomerWorkbench','detail_context',extra),customer)
reply=SimpleNamespace(customers=customer)
context=method('reply_workbench.py','ReplyWorkbench','_context')
context(reply,user,'owned-store','a'*64,platform='xiaohongshu')
history_count=len(calls)
assert history_count==(2 if mode=='baseline' else 1),f'Unexpected history count: {history_count}'

entered,release=threading.Event(),threading.Event();errors=[]
lock=threading.RLock();selected_calls=[]
def identity(*a,**kw):entered.set();assert release.wait(2),'Isolated verifier release missing';return dict(user),{'stores':[{'id':'owned-store'}]}
def selected_store(*a):selected_calls.append(True);return 'owned-store'
backend=SimpleNamespace(lock=lock,closed=False,core=SimpleNamespace(session=lambda token:dict(user)),_identity=identity,_selected_store=selected_store,_load_selection=lambda *a,**kw:{'storeId':'owned-store'},_stores=lambda *a:[{'id':'owned-store'}],customer_workbench=SimpleNamespace(media=lambda *a:(b'isolated-image','image/png')))
media=method('workbench_backend.py','WorkbenchBackend','media',{'re':re,'STORE_ID':re.compile('[A-Za-z0-9_-]{1,80}\\Z'),'WorkbenchError':Error,'_ReadOnlyDeliveryIntegrations':lambda core:SimpleNamespace(core=core),'_MediaReadIntegrations':lambda core:SimpleNamespace(core=core)})
def invoke():
    try:media(backend,'isolated-token',{'storeId':'owned-store','leadId':'a'*32,'kind':'author'})
    except Exception as error:errors.append(type(error).__name__+': '+str(error))
thread=threading.Thread(target=invoke,daemon=True);thread.start();assert entered.wait(2),'Method did not reach identity: '+repr(errors)
available=lock.acquire(timeout=.05)
if available:lock.release()
release.set();thread.join(2);assert not thread.is_alive();assert not errors,errors
assert available is (mode!='baseline'),f'Unexpected backend lock availability during media identity: {available}'
if mode=='after':assert not selected_calls,'New media must not call _selected_store hidden network activation'
report={'status':'REPRODUCED_BASELINE_BOTTLENECKS' if mode=='baseline' else 'PASS_INCREMENTAL_READ_LATENCY_CHECKS','at_utc':datetime.now(timezone.utc).isoformat(),'context_history_build_calls':history_count,'backend_lock_available_while_media_verifies':available,'source_sha256':hashes,'actual_core_imported':False,'real_HTTP_requests':0,'real_platform_requests':0,'product_edits':0,'DB_writes':0,'UI_operations':0,'test_kind':'Real AST method bodies, in-memory fakes, thread barrier; no production latency claim'}
(O/('BASELINE.json' if mode=='baseline' else 'AFTER.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
