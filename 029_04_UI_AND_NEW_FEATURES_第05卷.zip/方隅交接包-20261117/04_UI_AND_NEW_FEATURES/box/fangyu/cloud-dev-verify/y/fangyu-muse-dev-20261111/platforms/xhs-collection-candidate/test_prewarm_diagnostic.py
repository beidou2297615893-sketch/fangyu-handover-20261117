import json
import os
import sys
import tempfile
from types import SimpleNamespace
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx

import collector


class PrewarmDiagnosticTests(unittest.TestCase):
    def fail_onebox(self, payload, headers=None):
        calls = []
        def respond(request):
            calls.append(request.url.path)
            return httpx.Response(200, request=request, json=payload, headers=headers)
        client = collector.ReadClient({'a1': 'fixture', 'web_session': 'fixture'},
                                      transport=httpx.MockTransport(respond), delay=0)
        try:
            with patch('xhs_cli.client_mixins._acquire_search_session', return_value=('fixture', True)), \
                 patch('xhs_cli.client.sign_main_api', return_value={}):
                with self.assertRaises(collector.Halt):
                    client.search_notes('古北', page=1)
            self.assertEqual(calls, ['/api/sns/web/v1/search/onebox'])
            return client.last_failure_detail
        finally:
            client.close()

    def test_distinguishes_nonempty_data_without_saving_its_content(self):
        detail = self.fail_onebox({'code': 0, 'success': False, 'data': {'cookie': 'SECRET'}})
        checks = detail['prewarm_conditions']
        self.assertFalse(checks['data_empty'])
        self.assertTrue(checks['messages_empty'])
        self.assertTrue(checks['allowed_fieldset'])
        self.assertNotIn('SECRET', json.dumps(detail))
        self.assertNotIn('cookie', json.dumps(detail))

    def test_unknown_keys_messages_and_verification_remain_fatal_and_redacted(self):
        detail = self.fail_onebox({'code': 0, 'success': False, 'msg': 'SECRET',
                                  'SECRET_FIELD': 'token'}, {'verifytype': 'SECRET_HEADER'})
        checks = detail['prewarm_conditions']
        self.assertEqual(checks['unknown_field_count'], 1)
        self.assertFalse(checks['allowed_fieldset'])
        self.assertFalse(checks['messages_empty'])
        self.assertTrue(checks['verification_header_present'])
        self.assertNotIn('SECRET', json.dumps(detail))

    def test_known_message_signals_are_labeled_without_retaining_text_or_parameters(self):
        examples = [
            ('请完成安全验证 token=SECRET', 'safety_verification'),
            ('请求太频繁，请稍后再试 user=SECRET', 'rate_limit'),
            ('请先登录 account=SECRET', 'login'),
            ('网络异常 request=SECRET', 'network'),
        ]
        for message, expected in examples:
            with self.subTest(category=expected):
                detail = self.fail_onebox({'code': 0, 'success': False, 'msg': message, 'data': {'not_empty': True}})
                self.assertEqual(detail['prewarm_conditions']['message_signal_categories'], [expected])
                serialized = json.dumps(detail, ensure_ascii=False)
                self.assertNotIn('SECRET', serialized)
                self.assertNotIn(message, serialized)

    def test_unknown_malformed_and_mixed_messages_are_not_guessed(self):
        for message in ('任意未知响应 SECRET', {'token': 'SECRET'}, 'x' * 2050):
            detail = self.fail_onebox({'code': 0, 'success': False, 'msg': message})
            self.assertEqual(detail['prewarm_conditions']['message_signal_categories'], ['other'])
            self.assertFalse(detail['prewarm_conditions']['messages_empty'])
            self.assertNotIn('SECRET', json.dumps(detail))
        detail = self.fail_onebox({'code': 0, 'success': False, 'msg': '请先登录',
                                  'message': '需要验证码 SECRET'})
        self.assertEqual(detail['prewarm_conditions']['message_signal_categories'], ['safety_verification', 'login'])

    def test_labels_do_not_change_optional_response_decision(self):
        detail = self.fail_onebox({'code': 0, 'success': False, 'msg': '网络异常'})
        self.assertFalse(collector.empty_prewarm_allowed(detail['prewarm_conditions']))

    def test_additional_literal_message_signals_remain_redacted_and_fatal(self):
        examples = [('成功', 'success_text'), ('参数错误 SECRET', 'invalid_parameter'),
                    ('系统繁忙 SECRET', 'service_unavailable'), ('暂不支持 SECRET', 'not_supported')]
        for message, expected in examples:
            with self.subTest(category=expected):
                detail = self.fail_onebox({'code': 0, 'success': False, 'msg': message, 'data': {'not_empty': True}})
                self.assertEqual(detail['prewarm_conditions']['message_signal_categories'], [expected])
                self.assertFalse(collector.empty_prewarm_allowed(detail['prewarm_conditions']))
                self.assertNotIn('SECRET', json.dumps(detail, ensure_ascii=False))

    def test_success_signal_is_exact_and_does_not_hide_safety_text(self):
        detail = self.fail_onebox({'code': 0, 'success': False, 'msg': '请求成功但需要验证码 SECRET'})
        self.assertEqual(detail['prewarm_conditions']['message_signal_categories'], ['safety_verification'])

    def test_main_persists_fixed_diagnostic_before_reraising(self):
        detail = {'stage': 'search', 'endpoint': 'prewarm_onebox',
                  'prewarm_conditions': {'data_empty': False}}
        class FakeClient:
            last_failure_detail = detail
            def __init__(self, *args): pass
            def close(self): pass
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'new'
            with patch.object(collector, 'load_identity_map', return_value={}), \
                 patch.object(collector, 'merge_ledger_identity_map', return_value={}), \
                 patch.object(collector, 'ReadClient', FakeClient), \
                 patch.dict(sys.modules, {'standalone_reply': SimpleNamespace(load_independent_cookies=lambda home: {})}), \
                 patch.dict(os.environ), \
                 patch.object(collector, 'collect', side_effect=collector.Halt('stopped')):
                with self.assertRaises(collector.Halt):
                    collector.main(['--keyword', '古北', '--output', str(output),
                                    '--session-home', tmp, '--sender-uid', 'fixture',
                                    '--source-db', 'unused', '--ledger', 'unused', '--execute'])
            self.assertEqual(json.loads((output / 'failure-diagnostic.json').read_text(encoding='utf8')), detail)


if __name__ == '__main__':
    unittest.main(verbosity=2)
