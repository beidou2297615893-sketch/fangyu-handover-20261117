from pathlib import Path
import datetime, hashlib, json
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
F=P/'work/parallel-integration-20261018/final-integration'
N=P/'work/ui-native-r57'
def read(path):return json.loads(path.read_text('utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
entry=read(F/'entry-v20/CANONICAL-DELEGATION-INSTALL.json')
assert entry['status']=='INSTALLED_AWAITING_ACTUAL_ORIGINAL_ENTRY_VERIFICATION'
check=read(T/'ENTRY-CHECK.json')
candidate=read(T/'CANDIDATE-VALIDATION.json')
active=read(N/'state/active.json')
reports=[T/'collection-audit/FINAL-REVIEW.json',T/'reply-audit/FINAL-REVIEW.json',T/'ui-audit/PLATFORM-NOTICE-REVIEW.json',T/'ui-audit/V20-CLOSURE-REVIEW.json']
for path in reports:assert path.is_file(),path
result={
 'status':'INSTALLED_ORIGINAL_ENTRY_CHECKED_MANUAL_REOPEN_PENDING',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'release':candidate['release'],'original_launcher_sha256':sha(N/'run_workbench.py'),
 'closure_sha256':candidate['closure_sha256'],'closure_files':candidate['verified_files'],
 'active_record_release':active.get('release'),'active_record_pid':active.get('pid'),
 'active_record_is_not_process_liveness_probe':True,
 'changed_sources':candidate['changed_files'],
 'checks':{'original_entry':check,'reports':[{'path':str(p),'sha256':sha(p)} for p in reports]},
 'changes':[
  'Explicit captcha signal becomes visible platform verification notice; bare 461 does not become login failure.',
  'Cross-page/platform task monitor updates only alert DOM and cannot be postponed by ordinary renders.',
  'All-comment acquisition filters post dates, not individual comment dates; unknown post date is explicitly pending.',
  'Reply preview immediately uses already-authorized row; full editor waits for fresh response.',
  'Reply history/reply/account indexes read once per request; media no longer blocks foreground lock during network identity check.',
  'Original post typography larger, draft smaller, Douyin empty reply area dark.'
 ],
 'observed_existing_real_data':{'latest_task':'50df39c35e6c41e3b1da447cfcf32c5d','read_comments':17,'old_comment_date_stage_rejections':17,'retained_at_new_date_stage_in_cache_check':17,'verified_recent_posts':0,'final_stop':'Explicit Captcha required / type 124, HTTP 461','cache_check_imported':False,'cache_check_analysed':False},
 'new_real_collection':0,'real_platform_requests':0,'real_model_calls':0,'real_sends':0,
 'UI_operations':0,'production_business_DB_writes':0,'CLI_rebuilt':False,
 'old_suites_rerun':False,'real_continuous_throughput_verified':False,'platform_captcha_solved':False,
 'native_visual_acceptance':False,'manual_reopen_pending':True,'component_use_policy':'pending',
 'production_cloud_activation':False,'rejected_candidates_never_installed':['v18','v19'],
 'original_company_and_binding_preserved':candidate['original_company_binding_preserved']}
write(T/'DELIVERY.json',result)
summary=P/'work/当前续行摘要.md'
backup=T/'PREVIOUS-CONTINUATION.md'
if not backup.exists():backup.write_bytes(summary.read_bytes())
text=f'''# 当前续行：v20 已装原桌面入口，待用户手动重开

更新：2026-10-19。当前独立证据：{T.as_posix()}/DELIVERY.json。只读这份与按需命名短证据，不重读巨大聊天。旧摘要保存在本任务 PREVIOUS-CONTINUATION.md。

## 当前用户要求和边界
- 优先连续真实获客、同步 DeepSeek；修反复停止、回复读取、头像、帖子/草稿字号、抖音白色空态。新增要求：平台验证码/掉线/网络问题必须在客户端明确提示员工原因和下一步，跨页面也看得到。
- 用户正在用电脑，禁止操作UI、代重启、代扫码/找密码。用户手动重开；不等登录，不自动重放拒绝请求、不清风险、不改journal、不扩大权限、不真实发送、不付费模型验证。
- root唯一产品作者，代理独立只读审查。旧17小时截止已过，不重启心跳、不reset。旧总控合并曾被自动审批拒绝，不绕过，只存本任务证据及本摘要。

## 当前安装和编辑源
- release {candidate['release']}；原launcher SHA {result['original_launcher_sha256']}。
- 活动依赖 F/candidate-unified-v20/project，2722文件，pins {candidate['closure_sha256']}；F={F.as_posix()}。不可清理任何活动闭包/旧90a/旧CLI。
- 可编辑源 F/stage-02/project；新改必须新固化，不能修改冻结目录。
- 原入口 --check 已通过且不开窗口。active.json最后仍记v17/PID74668，不能声称正在打开的窗口已经切换新版本；也未探测进程存活。
- 原state/原company/设备绑定不变；用途仍pending、云新规则未激活。v18因写入换行问题、v19因通知timer饥饿均未安装；已修后才固化v20。

## 本轮实际原因与已修项目
- v17中文CLI协议已正常ACK，不是EOF/一条上限。最新真实任务 50df39c35e6c41e3b1da447cfcf32c5d：search200→comments200(1)→comments200(16)→subcomments461，原响应明确 Captcha required/type124。不等同掉线，不知道触发原因；不应推断频率导致。
- 找到真正本地漏客：界面帖子7天+评论全部时间，旧代码却用评论日期筛，17条全排。现只对精确普通search_comments模式用帖子日期；帖子日期缺失保留并标待核实，已知超范围帖子先跳过。17条只是旧缓存日期分支对照，未新增入库/分析，其他过滤不变。
- 明确captcha信号映射 verification_required；泛461继续platform_rejected，不自动清cookie/降登录态。
- 全局提示条说明验证码/失效/网络等以及下一步，点击只去账号页；验证码在平台网页处理。后台已知运行任务每5秒只读状态，跨页/跨平台保留提示；身份/任务迟到丢弃、停止后不轮询、反复render不推迟timer、不重绘草稿。
- 回复先显示已授权缓存行，再等fresh detail开放编辑；历史扫描2→1，回复/账号索引每请求1次；头像独立鉴权不占前台锁，前后范围校验仍在。
- 原帖字大/草稿字小，抖音回复空态变暗；日期缺失提示绑定确切原评论。无真实客户端截图验收。
- 共13源变化；CLI不重编。customer_list与DY pipeline精确内部依赖pin同步，其他owner/private用途常量不变。

## 验证口径和遗留
- 本轮20项日期/captcha、29媒体安全、6索引、4预览、5来源提示、18新平台通知等为隔离增量检查；完整新闭包与新入口核对通过，不重跑旧GUI/导出/CLI套件。
- 本轮真实新采集0、模型0、平台0、发送0、UI0、业务DB写0。真实平台验证码未解决、连续吞吐未验证，禁止把缓存/模拟条数当成果。
- DeepSeek已接且管理→AI模型可看/保存；当前deepseek-flash，历史29条为真实分析，本轮没有新模型调用。旧1000条是模拟。
- 抖音最后账号logging_in/conn_id空，不能借旧会话ID绑定；真实抖音采集仍跳过。完整原验收未全通过。
- 下一步只基于用户手动重开后的确切release/任务短回执继续；不要让员工只见“已暂停”，也不要隐瞒平台验证。原平台验证只能由用户/员工处理，不能自动绕过。
'''
summary.write_bytes(text.encode('utf-8'))
print(json.dumps({'status':result['status'],'release':result['release'],'new_real_collection':0,'manual_reopen_pending':True},ensure_ascii=False))
