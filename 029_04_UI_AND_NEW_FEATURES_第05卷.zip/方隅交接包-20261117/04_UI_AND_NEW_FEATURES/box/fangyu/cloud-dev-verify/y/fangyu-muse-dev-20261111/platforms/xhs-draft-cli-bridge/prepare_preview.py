"""Prepare a fixed review snapshot for the existing CLI, without contacting the platform."""
from __future__ import annotations
from collections import Counter
from contextlib import closing
from datetime import datetime
import importlib.util
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
CLI = ROOT / 'work/xhs-cli-standalone-entry/standalone_cli.py'
PYTHON = ROOT / 'work/vendor/cli-runtime/Scripts/python.exe'
LEDGER = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
SENDER = '5aa9b337e8ac2b4ab2d21957'
OUT = Path(__file__).resolve().parent / 'preview'


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    if OUT.exists():
        raise RuntimeError('Preview exists; do not overwrite the earlier review snapshot')
    OUT.mkdir(parents=True)
    snapshots = OUT / 'sources'
    snapshots.mkdir()
    sources = [ROOT / 'work/xhs-intent-drafts/drafts.json']
    for folder in sorted((ROOT / 'work/xhs-three-stage-integration/live-consumer').glob('batch-*')):
        state, drafts = folder/'state.json', folder/'drafts.json'
        if state.is_file() and drafts.is_file() and load(state).get('status') == 'completed':
            sources.append(drafts)
    entries = []
    manifest = {}
    for idx, source in enumerate(sources):
        copy = snapshots / f'source-{idx:03d}.json'
        shutil.copyfile(source, copy)
        manifest[f'source_{idx:03d}'] = str(copy.resolve())
        records = load(copy)
        if not isinstance(records, list):
            raise ValueError('Invalid draft source')
        entries.extend(records)
    spec = importlib.util.spec_from_file_location('read_only_cli', CLI)
    cli = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cli)
    states = cli.ledger_states(LEDGER)
    with closing(sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro', uri=True, timeout=5)) as db:
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')
        rows = db.execute("SELECT customer,comment,status FROM leads WHERE platform='xiaohongshu'").fetchall()
        aliases = db.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'").fetchall()
        db.rollback()
    led = {(customer, comment): status for customer, comment, status in rows}
    alias_map = dict(aliases)
    blocked_users = {customer for customer, _, status in rows if status in ('reserved','unknown','sent','sending','submitted')}
    selected, excluded = [], []
    seen_comments, seen_customers, seen_uids = set(), set(), set()
    for record in entries:
        cid, customer, uid, note = (record.get(k, '') for k in ('comment_id','customer_id','customer_uid','note_id'))
        interest = ((record.get('source_analysis') or {}).get('result') or {}).get('interest')
        text = record.get('draft', '')
        reason = ''
        if interest not in ('high','super_high'):
            continue
        if not isinstance(text, str) or not text.strip(): reason = '暂缓草稿'
        elif not all(isinstance(x,str) and x.strip() and x==x.strip() for x in (cid, customer, uid, note)): reason = '身份资料不完整'
        elif not record.get('own_region_confirmed') and '古北' in text: reason = '地区不明却写具体地区'
        elif (customer,cid) not in led: reason = '未匹配现有账本'
        elif led[(customer,cid)] not in ('unverified','reviewed','history_clear'): reason = '账本状态待核'
        elif {uid,customer,alias_map.get(uid,''),alias_map.get(customer,'')} & blocked_users: reason = '客户有历史回执需核对'
        elif record.get('source_record', {}).get('own_reply_visible'): reason = '已有本人回复'
        elif cid in seen_comments or customer in seen_customers or uid in seen_uids: reason = '同一客户或评论重复'
        elif cli.row_state({'attempt_id':'preview-only','platform':'xiaohongshu','customer_id':customer,'customer_uid':uid,'comment_id':cid}, states) != 'pending': reason = '发送记录待核'
        if reason:
            excluded.append({'comment_id':cid, 'reason':reason})
            continue
        seen_comments.add(cid); seen_customers.add(customer); seen_uids.add(uid)
        selected.append({'customer_id':customer, 'customer_uid':uid, 'comment_id':cid, 'note_id':note, 'text':text.strip()})
    save(OUT/'input.json', selected)
    save(OUT/'source-manifest.json', manifest)
    save(OUT/'review-flags.json', [{'comment_id':r['comment_id'], 'review_notes':r.get('review_notes', []),
                                    'current_time_confirmed':r.get('current_time_confirmed', False),
                                    'own_region_confirmed':r.get('own_region_confirmed', False)}
                                   for r in entries if r.get('comment_id') in seen_comments])
    report = {'created_at':datetime.now().astimezone().isoformat(), 'source_files':len(sources),
              'selected_high_drafts':len(selected), 'excluded':dict(Counter(x['reason'] for x in excluded)),
              'history_and_current_demand_verified':False, 'sender_uid_verified_by_previous_collection':True,
              'send_authorized':False, 'platform_requests':0}
    save(OUT/'excluded.json', excluded)
    save(OUT/'report.json', report)
    if not selected:
        print(json.dumps(report,ensure_ascii=False));return
    common = [str(PYTHON), '-X', 'utf8', str(CLI), '--project-root', str(ROOT),
              '--source-manifest', str(OUT/'source-manifest.json'), '--sender-uid', SENDER]
    prepare = subprocess.run([*common, '--input', str(OUT/'input.json'), '--output', str(OUT/'prepared.json'), 'prepare'],
                             capture_output=True, text=True, encoding='utf8', errors='replace', timeout=20)
    if prepare.returncode:
        raise RuntimeError('Existing CLI prepare failed: ' + prepare.stderr[:300])
    result = subprocess.run([*common, '--batch', str(OUT/'prepared.json'), 'status'],
                            capture_output=True, text=True, encoding='utf8', errors='replace', timeout=20)
    if result.returncode:
        raise RuntimeError('Existing CLI status failed: ' + result.stderr[:300])
    status = json.loads(result.stdout)
    save(OUT/'status.json', status)
    report.update(prepare_passed=True, readonly_status_passed=True, cli_status=status)
    save(OUT/'report.json', report)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
