# 跨页平台提示与只读监控：独立增量复核通过

直接导入本次实际 platform-notice.mjs，以假时钟和隔离提示容器验证 18/18 通过；未操作真实 UI，没有平台、模型、登录、暂停或发送请求。原 UI 17 项及其他旧套件未重跑。

已覆盖：在回复页和另一平台的获客页，原 active 任务转为验证码后均能显示对应平台的明确提示；快照写回正确平台空间；任务终止后不再排后续计时器；员工、门店、认证 epoch、会话、连接、taskId 或平台变化时丢弃不匹配的迟到结果。普通只读状态请求失败保留原快照，不推断验证码；平台拒绝单独说明不能确认是登录问题。验证码、登录失效、限频、网络、兼容、结果未知各有下一步文字。

提示模块只修改独立 host。app 的 monitor changed 回调是 showPlatformNotice，未调用 render 或替换 page-content；隔离草稿文本、节点身份和光标位置保持。重复相同提示不重写 host。没有自动账号操作，提示按钮仅在本人点击时调用账号页导航。

首次发现并复现了一个真实缺陷：每次 render 调用 sync 都将原 5 秒计时器重置，前台 3.5 秒刷新可让后台检查永久推迟。根作者已修为同 identity、有目标且已有计时器时保留原截止；仅无目标或 identity 改变取消。新增边界确认原 5000ms 时已执行一次检查，且反复 sync 始终单计时器、单并行请求。原 RED 保留在 MONITOR-CADENCE-BASELINE.json 与 PLATFORM-NOTICE-RED.json；本次新候选才可采用修正后的源。

## 精确 SHA256

| ui-preview 下文件 | SHA256 |
| --- | --- |
| platform-notice.mjs | 72bc8c7c48da886498bcbdd5fd9970d4c47354d44c7bd61bca6e6cae5f0c4a1c |
| app.mjs | 03daa04c73b1cb2f01d42fd99987671d0928db8d4c3c06fb08f3643c5b55463d |
| canvas-fit.css | a13d6939ac0c4d12ff71418461375a15e628ec0a7c0529b00bd83ac2787a4061 |

证据 PLATFORM-NOTICE-REVIEW.json，脚本 verify_platform_notice.mjs。测试前后源码一致。

此模块消费后台已经明确分类的、本员工本门店原任务快照；它不主动操作平台网页，也不把状态读取失败或一般 HTTP 拒绝猜成验证码。复核不代表实际平台网页已触发这些状态或真实客户端视觉已验收。候选装配还须确认新 module 被 release web、完整 pins 和加载入口一并包含。
