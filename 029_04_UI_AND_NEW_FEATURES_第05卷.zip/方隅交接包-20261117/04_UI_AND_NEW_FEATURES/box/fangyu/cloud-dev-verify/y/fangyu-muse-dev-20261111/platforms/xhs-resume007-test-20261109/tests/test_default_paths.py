"""不设 XHS_RESUME007_* 环境变量时，默认路径应解析到 R（R/work/<task>/resume007.py）。"""
import importlib.util, os, shutil, tempfile, unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / 'resume007.py'


class DefaultPathTest(unittest.TestCase):
    def test_defaults_without_env(self):
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith('XHS_RESUME007_')}
        tmp = Path(tempfile.mkdtemp())
        try:
            R = tmp / 'R'
            task = R / 'work' / 'xhs-resume007-task'
            task.mkdir(parents=True)
            dst = task / 'resume007.py'
            shutil.copy(SRC, dst)
            spec = importlib.util.spec_from_file_location('r007_default', dst)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            m.refresh_paths()
            self.assertEqual(m.PROJECT.resolve(), R.resolve())
            self.assertEqual(m.HERE.resolve(), task.resolve())
            self.assertEqual(m.LEDGER, R.resolve() / 'work/shared-acquisition-ledger/shared.sqlite3')
            self.assertEqual(m.RESUME006_ROOT, R.resolve() / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103')
        finally:
            os.environ.update(saved)
            shutil.rmtree(tmp)


if __name__ == '__main__':
    unittest.main()
