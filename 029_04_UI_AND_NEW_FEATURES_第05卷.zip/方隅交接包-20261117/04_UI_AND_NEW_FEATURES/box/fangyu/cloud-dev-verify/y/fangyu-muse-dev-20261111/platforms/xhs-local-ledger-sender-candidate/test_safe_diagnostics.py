"""Synthetic-only failure diagnostics; never accesses the real platform."""
import json
import sqlite3
from contextlib import closing
from unittest import mock

import collector
import httpx
import production_sender as sender
from xhs_cli.exceptions import XhsApiError, SessionExpiredError, NeedVerifyError
from test_production_sender import Tests, Client


class SenderDiagnostics(Tests):
    def test_identity_error_does_not_post_or_leak_response(self):
        class BadIdentity(Client):
            def identity(self):
                raise XhsApiError('private-secret',code=-100,response={'cookie':'private-secret'})
        client=BadIdentity(self.plan)
        client._post_started=False
        with self.assertRaises(sender.Refused) as caught:self.run_plan(self.plan,client)
        self.assertEqual(client.calls,0)
        self.assertIn('identity',str(caught.exception))
        self.assertIn('-100',str(caught.exception))
        self.assertNotIn('private-secret',str(caught.exception))
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM reservations').fetchone()[0],0)

    def test_numeric_api_code_and_request_started_saved_without_secret(self):
        error = XhsApiError('Cookie=secret; personal-text', code=123456, response={'token':'secret'})
        client = Client(self.plan, error=error)
        client._post_started = True
        with self.assertRaises(sender.Unknown): self.run_plan(self.plan, client)
        self.assertEqual(client.calls, 1)
        with closing(sqlite3.connect(self.db)) as db:
            record = json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])
        detail=record['result']
        self.assertEqual(detail['kind'],'unknown')
        self.assertEqual(detail['api_code'],123456)
        self.assertEqual(detail['error_type'],'XhsApiError')
        self.assertEqual(detail['stage'],'post_started_or_unknown')
        self.assertTrue(detail['request_started'])
        self.assertNotIn('secret',json.dumps(detail))
        self.assertNotIn('personal-text',json.dumps(detail))

    def test_no_receipt_remains_unknown_and_records_safe_stage(self):
        client = Client(self.plan,result={})
        client._post_started = True
        with self.assertRaises(sender.Unknown): self.run_plan(self.plan,client)
        with closing(sqlite3.connect(self.db)) as db:
            detail=json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])['result']
        self.assertEqual(detail['kind'],'unknown')
        self.assertEqual(detail['error_type'],'Unknown')
        self.assertNotIn('api_code',detail)
        self.assertTrue(detail['request_started'])
        with self.assertRaises(sender.Refused): self.run_plan(self.plan,Client(self.plan))

    def test_pre_post_failure_is_not_claimed_to_have_sent(self):
        client = Client(self.plan,error=RuntimeError('secret'))
        client._post_started = False
        with self.assertRaises(sender.Unknown): self.run_plan(self.plan,client)
        with closing(sqlite3.connect(self.db)) as db:
            detail=json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])['result']
        self.assertEqual(detail['kind'],'unknown')
        self.assertFalse(detail['request_started'])
        self.assertEqual(detail['stage'],'after_reservation_before_post')
        self.assertNotIn('secret',json.dumps(detail))


class CollectorDiagnostics(__import__('unittest').TestCase):
    def test_safe_api_error_keeps_number_and_category_only(self):
        meta=collector.safe_api_error(XhsApiError('secret-content',code=987,response={'token':'secret'}),'search')
        self.assertEqual(meta['stage'],'search')
        self.assertEqual(meta['error_type'],'XhsApiError')
        self.assertEqual(meta['api_code'],987)
        self.assertNotIn('secret',json.dumps(meta))

    def test_missing_code_or_untrusted_fields_not_echoed(self):
        meta=collector.safe_api_error(NeedVerifyError('secret-type','secret-uuid'),'secret-stage')
        self.assertEqual(meta['stage'],'unknown')
        self.assertEqual(meta['error_type'],'NeedVerifyError')
        self.assertNotIn('secret',json.dumps(meta))
        self.assertEqual(collector.safe_api_error(SessionExpiredError(),'identity')['api_code'],-100)
        self.assertEqual(collector.safe_api_error(XhsApiError('private',code='-100'),'identity')['api_code'],-100)
        self.assertNotIn('api_code',collector.safe_api_error(XhsApiError('private',code='-100-secret'),'identity'))

    def test_sender_cannot_echo_non_numeric_http_status(self):
        error=sender.HttpUnknown('secret')
        meta=sender.failure_diagnostics(error,object())
        self.assertNotIn('http_status',meta)
        self.assertNotIn('secret',json.dumps(meta))

    def test_collector_reports_200_api_failure_without_body(self):
        client=collector.ReadClient({'a1':'synthetic'},delay=0)
        client._last_stage='comments'
        try:
            with self.assertRaises(collector.Halt) as caught:
                client._handle_response(httpx.Response(200,json={'success':False,'code':-100,'data':'secret'}))
            self.assertIn('"api_code": -100',str(caught.exception))
            self.assertIn('"stage": "comments"',str(caught.exception))
            self.assertNotIn('secret',str(caught.exception))
        finally:client.close()

    def test_http_461_is_one_request_and_safe_metadata(self):
        calls=[]
        def handler(req): calls.append(req); return httpx.Response(461,content=b'secret')
        client=collector.ReadClient({'a1':'synthetic'},transport=httpx.MockTransport(handler),delay=0)
        try:
            with mock.patch('socket.socket.connect',side_effect=AssertionError('network forbidden')):
                with self.assertRaises(collector.Halt) as caught:
                    client._request_with_retry('GET','https://edith.xiaohongshu.com/api/sns/web/v2/comment/page?token=secret')
            self.assertEqual(len(calls),1)
            self.assertIn('461',str(caught.exception))
            self.assertIn('comments',str(caught.exception))
            self.assertNotIn('secret',str(caught.exception))
        finally:client.close()
