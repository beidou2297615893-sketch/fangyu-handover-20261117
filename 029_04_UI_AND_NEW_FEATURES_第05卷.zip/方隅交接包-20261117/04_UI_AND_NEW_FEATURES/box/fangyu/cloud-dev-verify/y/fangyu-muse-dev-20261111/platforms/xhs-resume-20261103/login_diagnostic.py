"""Task-local HTTP QR diagnostics. Import and default CLI mode never access network."""
import argparse,json,logging,sys
from pathlib import Path
from datetime import datetime,timezone
from xhs_cli.client import XhsClient
from xhs_cli.exceptions import NeedVerifyError
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
sys.path.insert(0,str(PROJECT/'work/xhs-standalone-session/diagnostics'))
from qr_http_adapter import poll_confirmed_login,QrFlowError

def evidence(resp,stage):
    r={'stage':stage,'http_status':resp.status_code,'verification_header_present':any(k.lower().startswith(('verify','x-verify')) for k in resp.headers),'visible_dialog':'not_assessed','account_restriction_proven':False}
    try:data=resp.json()
    except Exception:r['body_kind']='non_json';return r
    r['body_kind']='json'
    if isinstance(data,dict):
        code=data.get('code')
        if type(code) is int:r['business_code']=code
        if type(data.get('success')) is bool:r['success']=data['success']
        message=str(data.get('msg') or data.get('message') or '').lower()
        r['message_category']=next((category for category,words in [('verification',['验证','captcha','verify']),('rate_limit',['频繁','过多','too many']),('authentication',['登录','session','login']),('signature',['签名','signature'])] if any(w in message for w in words)),'other_or_absent')
    return r

class DiagnosticClient(XhsClient):
    def __init__(self,*args,emit,**kwargs):
        super().__init__(*args,**kwargs);self.emit=emit;self.stage='activation'
    def _request_with_retry(self,method,url,**kwargs):
        try:resp=self._http.request(method,url,**kwargs)
        except Exception as exc:
            self.emit({'stage':self.stage,'category':'transport_error','error_type':type(exc).__name__});raise QrFlowError('transport_error') from None
        self.emit(evidence(resp,self.stage))
        if resp.status_code in (461,471):raise NeedVerifyError('not_recorded','not_recorded')
        if resp.status_code!=200:raise QrFlowError('http_error')
        self._merge_response_cookies(resp);return resp
    def _handle_response(self,resp):
        try:data=resp.json()
        except Exception:raise QrFlowError('invalid_json') from None
        if not isinstance(data,dict) or data.get('success') is not True:raise QrFlowError('business_error')
        return data.get('data',True)
    def check_qr_status(self,*args,**kwargs):self.stage='status';return super().check_qr_status(*args,**kwargs)
    def complete_qr_login(self,*args,**kwargs):self.stage='completion';return super().complete_qr_login(*args,**kwargs)
    def get_self_info(self,*args,**kwargs):self.stage='self_info';return super().get_self_info(*args,**kwargs)

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--session-home',required=True);a=p.parse_args()
    if not a.execute:print('PREVIEW_NO_NETWORK');return
    logging.disable(logging.CRITICAL)
    import qrcode
    import xhs_cli.cookies as storage
    from xhs_cli.qr_login import _generate_a1,_generate_webid,_apply_session_cookies
    home=Path(a.session_home);config=home/'.xiaohongshu-cli';config.mkdir(parents=True,exist_ok=False)
    storage.get_config_dir=lambda:config
    log=home/'login-diagnostics.jsonl'
    def emit(row):
        row={'at':datetime.now(timezone.utc).isoformat(),**row}
        with log.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
        print(json.dumps(row,ensure_ascii=False),flush=True)
    try:
        with DiagnosticClient({'a1':_generate_a1(),'webId':_generate_webid()},emit=emit,request_delay=0) as c:
            activation=c.login_activate();_apply_session_cookies(c,activation)
            c.stage='create';qr=c.create_qr_login();qrcode.make(qr['url']).save(home/'login-qr.png');emit({'category':'QR_READY'})
            cookies=poll_confirmed_login(c,qr['qr_id'],qr['code'],verify_error=NeedVerifyError,on_event=emit,completion_attempts=1)
            storage.save_cookies(cookies);emit({'category':'LOGIN_SUCCESS'})
    except (NeedVerifyError,QrFlowError) as exc:emit({'category':'LOGIN_STOPPED','reason':getattr(exc,'category','platform_verification_response')})
    except Exception as exc:emit({'category':'LOGIN_STOPPED','error_type':type(exc).__name__})
if __name__=='__main__':main()

