"""Authorized 15-store rotation using the existing managed collector."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
sys.path.insert(0,str(PROJECT/'work/xhs-new-task-session-fix-20261029'))
from integration import load,client_factory

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--resume-after-login',action='store_true')
    parser.add_argument('--continue-after-comment-login',action='store_true')
    parser.add_argument('--session-home')
    parser.add_argument('--run-name')
    parser.add_argument('--previous-empty-attempt')
    args=parser.parse_args()
    q=json.loads((HERE/'keyword-plan.json').read_text(encoding='utf8'))
    if hashlib.sha256(Path(q['source_csv']).read_bytes()).hexdigest()!=q['source_csv_sha256']:
        raise ValueError('keyword_source_changed')
    scopes={(x['keyword'],x['page']):x for x in q['queue']}
    if len(scopes)!=len(q['queue']):raise ValueError('duplicate_store_query_needs_review')
    plan=[{'keyword':x['keyword'],'page':x['page']} for x in q['queue']]
    prior=PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-segment001-20261029'
    resume=None
    if args.resume_after_login or args.continue_after_comment_login:
        from resume_guard import reconcile
        resume=reconcile(prior,PROJECT/'work/shared-acquisition-ledger/shared.sqlite3',plan,'5aa9b337e8ac2b4ab2d21957')
        plan=plan[resume['cursor']:]
    if args.continue_after_comment_login:
        from resume_guard import reconcile_comment_interruption
        followup=reconcile_comment_interruption(PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume001-20261030',PROJECT/'work/shared-acquisition-ledger/shared.sqlite3',PROJECT/'work/xhs-partial-registration-recovery-20261029/runtime/stores15-resume001-batch3-recovery','5aa9b337e8ac2b4ab2d21957',plan[0])
        resume={**resume,**followup,'base_registered':resume['base_registered']+followup['recovered_registered'],'first_batch':followup['next_batch']}
    if args.previous_empty_attempt:
        if not args.continue_after_comment_login:raise ValueError('explicit_continuation_required')
        from resume_guard import reconcile_empty_attempt
        previous=Path(args.previous_empty_attempt).resolve(strict=True)
        production=(PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks').resolve()
        if previous.parent!=production:raise ValueError('production_attempt_required')
        empty=reconcile_empty_attempt(previous,PROJECT/'work/shared-acquisition-ledger/shared.sqlite3','5aa9b337e8ac2b4ab2d21957',plan[0])
        resume={**resume,**empty,'first_batch':empty['next_batch']}
    if not args.execute:
        print(json.dumps({'mode':'preview','stores':len({x['source_store'] for x in q['queue']}),
            'first_round':q['first_round_count'],'planned_pages':len(plan),'resume':resume,'network':False,'ledger_write':False,'send':False},ensure_ascii=False))
        return 0
    home=PROJECT/'work/xhs-standalone-session/leimu-15stores-login-20261029'
    if resume:home=PROJECT/'work/xhs-standalone-session/stores15-resume-login-20261030-01'
    if args.continue_after_comment_login:home=PROJECT/'work/xhs-standalone-session/stores15-user-relogin-20261030-02'
    if args.session_home:
        home=Path(args.session_home).resolve(strict=True)
        if not args.continue_after_comment_login or home.parent!=(PROJECT/'work/xhs-standalone-session').resolve():raise ValueError('explicit_task_session_required')
    identity=json.loads((home/'identity-receipt.json').read_text(encoding='utf8'))
    uid='5aa9b337e8ac2b4ab2d21957'
    if identity.get('uid')!=uid or identity.get('guest') is not False or identity.get('saved') is not True:
        raise ValueError('normal_leimu_login_required')
    live,candidate,once,scheduling=load()
    root=PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-segment001-20261029'
    if resume:root=PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume001-20261030'
    if args.continue_after_comment_login:root=PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume002-20261030'
    if args.run_name:
        if not args.continue_after_comment_login or not re.fullmatch(r'stores15-resume[0-9]{3}-[0-9]{8}',args.run_name):raise ValueError('task_runtime_name_required')
        root=root.parent/args.run_name
    lock=home/'.managed-use.lock';lock.mkdir()
    try:
        root.mkdir(exist_ok=False)
        if resume:live.write_new(root/'continuation-receipt.json',resume)
        config={'session_home':str(home),'ledger':str(PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'),
            'source_db':str(PROJECT/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'),
            'shared_ledger':True,'max_comment_pages':2,'operator':'current_chat_15_store_collection',
            'task':'15家门店独立关键词采集'}
        live.write_new(root/'task-config.json',{**config,'plan':q,'expected_uid':uid,'send_authorized':False,
            'source_store_is_customer_assignment':False,'plan_exhaustion_is_overall_completion':False})
        scheduling.initialize(root,plan,first_batch=resume['first_batch'] if resume else 1,target=2147483647)
        class PerStoreExecutor:
            def run(self,batch,keyword,page,remaining):
                scope=scopes[(keyword,page)]
                metadata={'source_store':scope['source_store'],'source_city':scope['city'],
                    'keyword':keyword,'page':page,'round':scope['round'],'source_csv_row':scope['source_csv_row'],
                    'customer_store_assignment':'unverified','account_uid':uid}
                live.write_new(root/(batch+'-store-scope.json'),metadata)
                executor=live.LiveExecutor(root,{**config,'task':scope['source_store']+'关键词采集；客户地区另核'},
                    candidate,once,client_factory(uid,delay=3.0))
                result=executor.run(batch,keyword,page,remaining)
                live.append(root/'store-analysis-manifest.jsonl',{'at':live.now(),'batch':batch,**metadata,
                    'inserted_comments':result['inserted'],'analysis_input':result['analysis_input'],
                    'status':'registered_ready_for_classification'})
                print(json.dumps({'store':scope['source_store'],'keyword':keyword,'page':page,
                    'new_registered':result['inserted'],'status':'registered'},ensure_ascii=False),flush=True)
                return result
        result=scheduling.run(root,PerStoreExecutor())
        live.append(root/'run-receipts.jsonl',{'at':live.now(),'status':result['status'],
            'new_registered':result.get('inserted',0),'inflight':result.get('inflight'),'automatic_retry':False})
        print(json.dumps({'status':result['status'],'new_registered':result.get('inserted',0)},ensure_ascii=False),flush=True)
        return 0 if result['status'] in ('plan_exhausted','paused','target_reached') else 2
    finally:
        lock.rmdir()

if __name__=='__main__':
    raise SystemExit(main())
