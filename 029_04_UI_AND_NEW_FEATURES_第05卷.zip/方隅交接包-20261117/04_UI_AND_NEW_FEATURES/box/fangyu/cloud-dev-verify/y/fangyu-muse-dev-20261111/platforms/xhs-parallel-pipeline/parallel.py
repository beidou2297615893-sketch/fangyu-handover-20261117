"""Durable independent collection, context and AI queues. Never sends comments."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import threading

ROOT=Path(__file__).resolve().parents[2]
PYTHON=ROOT/'work/vendor/cli-runtime/Scripts/python.exe'
COLLECT=ROOT/'work/xhs-collection-candidate/collector.py'
REGISTER=ROOT/'work/xhs-collection-candidate/register.py'
CONTEXT=ROOT/'work/xhs-context-controlled/context_pipeline.py'
AI=ROOT/'work/xhs-ai-standalone/pipeline.py'

class Stop(Exception):pass

def load(path):return json.loads(Path(path).read_text('utf-8-sig'))

def save(path,value):
    path=Path(path);temporary=path.with_name(path.name+'.tmp')
    with temporary.open('w',encoding='utf8') as out:
        json.dump(value,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())
    os.replace(temporary,path)

class Store:
    def __init__(self,root,state):
        self.root=Path(root);self.state=state;self.cv=threading.Condition(threading.RLock())
    @classmethod
    def create(cls,root,jobs,binding):
        root=Path(root)
        if root.exists() and any(root.iterdir()):raise Stop('输出目录非空，禁止覆盖')
        root.mkdir(parents=True,exist_ok=True)
        state={'version':1,'binding':binding,'status':'ready','send':False,'automatic_retry':False,
               'jobs':[dict(job,index=i,collection='pending',context='pending',analysis='pending') for i,job in enumerate(jobs)]}
        result=cls(root,state);result.persist();return result
    @classmethod
    def resume(cls,root,binding):
        state=load(Path(root)/'state.json')
        if state.get('binding')!=binding:raise Stop('恢复参数与原任务不一致')
        if any(job.get(stage)=='running' for job in state['jobs'] for stage in ('collection','context','analysis')):
            state['status']='blocked';save(Path(root)/'state.json',state)
            raise Stop('发现上次执行结果未确认，先核对批次和账本，禁止自动重试')
        if state.get('status') not in ('paused','ready') or any(job.get(stage)=='failed' for job in state['jobs'] for stage in ('collection','context','analysis')):
            raise Stop('存在失败或不安全断点，请先核对记录')
        return cls(root,state)
    def persist(self):save(self.root/'state.json',self.state)
    def snapshot(self):
        with self.cv:return deepcopy(self.state)
    def change(self,index,stage,value,**fields):
        with self.cv:
            self.state['jobs'][index][stage]=value;self.state['jobs'][index].update(fields)
            self.persist();self.cv.notify_all()

class PlatformGate:
    """One platform stage at a time; bounded fairness keeps both queues moving."""
    def __init__(self):
        self.cv=threading.Condition();self.busy=False;self.collectors=0;self.contexts=0;self.last=None
    @contextmanager
    def enter(self,collection=False):
        with self.cv:
            if collection:self.collectors+=1
            else:self.contexts+=1
            self.cv.wait_for(lambda:not self.busy and
                ((self.contexts==0 or self.last!='collection') if collection else (self.collectors==0 or self.last=='collection')))
            if collection:self.collectors-=1
            else:self.contexts-=1
            self.busy=True
        try:yield
        finally:
            with self.cv:self.busy=False;self.last='collection' if collection else 'context';self.cv.notify_all()

def run(store,collect_fn,context_fn,analysis_fn,stop_file=None):
    stopped=threading.Event();producer_done=threading.Event();context_done=threading.Event();gate=PlatformGate()
    def requested():
        if stop_file and Path(stop_file).exists():stopped.set()
        return stopped.is_set()
    def execute(job,stage,fn):
        store.change(job['index'],stage,'running')
        try:
            result=fn(deepcopy(job)) or {}
            store.change(job['index'],stage,'done',**result)
            return result
        except Exception as exc:
            # Vendor text can contain signed URLs. Only the exception class is retained.
            store.change(job['index'],stage,'failed',error_stage=stage,error_type=type(exc).__name__)
            if stage!='analysis':stopped.set()
            return None
    def producer():
        try:
            for job in store.snapshot()['jobs']:
                if requested():break
                if job['collection']!='pending':continue
                with gate.enter(collection=True):
                    if requested():break
                    result=execute(job,'collection',collect_fn)
                if result is None:break
                if not result.get('inserted'):
                    store.change(job['index'],'context','skipped');store.change(job['index'],'analysis','skipped')
        finally:
            producer_done.set()
            with store.cv:store.cv.notify_all()
    def context_worker():
        try:
            while not requested():
                with store.cv:
                    ready=next((deepcopy(j) for j in store.state['jobs'] if j['collection']=='done' and j.get('inserted',0)>0 and j['context']=='pending'),None)
                    if ready is None:
                        if producer_done.is_set():break
                        store.cv.wait(.1);continue
                with gate.enter():
                    if requested():break
                    if execute(ready,'context',context_fn) is None:break
        finally:
            context_done.set()
            with store.cv:store.cv.notify_all()
    def analysis_worker():
        while True:
            with store.cv:
                ready=next((deepcopy(j) for j in store.state['jobs'] if j['context']=='done' and j['analysis']=='pending'),None)
                if ready is None:
                    if context_done.is_set():break
                    store.cv.wait(.1);continue
            if execute(ready,'analysis',analysis_fn) is None:break
    with store.cv:store.state['status']='running';store.persist()
    threads=[threading.Thread(target=target,name=name) for target,name in ((producer,'collection'),(context_worker,'context'),(analysis_worker,'analysis'))]
    for thread in threads:thread.start()
    try:
        for thread in threads:thread.join()
    except KeyboardInterrupt:
        # Keep the shared lock until active stages finish and durable state is saved.
        stopped.set()
        with store.cv:store.cv.notify_all()
        for thread in threads:
            if thread.is_alive():thread.join()
    with store.cv:
        failures=any(j[stage]=='failed' for j in store.state['jobs'] for stage in ('collection','context','analysis'))
        store.state['status']='stopped' if failures else ('paused' if stopped.is_set() else 'completed')
        store.persist()
    return store.snapshot()

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str(Path(path).parent));spec.loader.exec_module(value);return value

def invoke(command):
    result=subprocess.run([str(PYTHON),'-X','utf8',*map(str,command)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
    if result.returncode:raise Stop('子步骤失败，保留结果后停止')

def callbacks(root,args):
    registrar=module(ROOT/'work/xhs-continuous-runner/runner.py','parallel_selection')
    def batch(job):return root/f"batch-{job['index']+1:04d}"
    def collect(job):
        path=batch(job)
        if path.exists():raise Stop('批次已存在，禁止自动重复执行')
        path.mkdir();out=path/'collection'
        save(path/'collection-stage.json',{'stage':'collection','status':'started'})
        invoke([COLLECT,'--keyword',job['keyword'],'--search-page',job['page'],'--max-notes',args.max_notes,'--max-pages',args.max_pages,
                '--output',out,'--session-home',args.session_home,'--sender-uid',args.sender_uid,'--source-db',args.source_db,'--ledger',args.ledger,'--execute'])
        source=out/'collection.json'
        if not source.is_file():raise Stop('采集未完整结束，请核对 partial')
        common=[REGISTER,'--collection',source,'--ledger',args.ledger,'--source-db',args.source_db,'--sender-uid',args.sender_uid]
        save(path/'collection-stage.json',{'stage':'registration_preview','status':'started'})
        invoke([*common,'--report',path/'register-preview.json'])
        expected=load(path/'register-preview.json')['would_insert']
        save(path/'collection-stage.json',{'stage':'registration_commit','status':'started','expected_inserted':expected})
        invoke([*common,'--apply','--report',path/'register-applied.json'])
        actual=load(path/'register-applied.json')['inserted']
        if expected!=actual:raise Stop('登记结果变化，停止核查')
        data=load(source);chosen=registrar.select_new(data,args.ledger,source,actual)
        save(path/'new-ai-input.json',chosen)
        save(path/'collection-stage.json',{'stage':'registered','status':'completed','inserted':actual})
        return {'inserted':actual,'new_customers':len(chosen),'comments':data.get('summary',{}).get('usable_comments')}
    def context(job):
        path=batch(job)
        invoke([CONTEXT,'--collection',path/'collection/collection.json','--selected-input',path/'new-ai-input.json',
                '--output',path/'context','--session-home',args.session_home,'--sender-uid',args.sender_uid,'--execute'])
        if not (path/'context/ai-input.json').is_file():raise Stop('正文补读未完成')
        return {}
    def analyse(job):
        path=batch(job);ai=module(AI,'parallel_ai')
        ai.create_batch(path/'context/ai-input.json',path/'analysis',args.sender_uid,load(args.account),load(args.style),ai.CodexProvider())
    return collect,context,analyse

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--keyword',action='append',required=True);parser.add_argument('--output',required=True)
    for name in ('session-home','sender-uid','source-db','ledger','account','style'):parser.add_argument('--'+name)
    parser.add_argument('--max-notes',type=int,default=20);parser.add_argument('--max-pages',type=int,default=2)
    parser.add_argument('--search-start-page',type=int,default=1);parser.add_argument('--search-pages',type=int,default=3)
    parser.add_argument('--execute',action='store_true');parser.add_argument('--resume',action='store_true')
    args=parser.parse_args(argv)
    if not args.keyword or len(set(args.keyword))!=len(args.keyword) or any(not word.strip() or word!=word.strip() for word in args.keyword):raise Stop('关键词为空或重复')
    if not 1<=args.max_notes<=20 or not 1<=args.max_pages<=20 or not 1<=args.search_pages<=20 or not 1<=args.search_start_page<=100 or args.search_start_page+args.search_pages>101:raise Stop('分页范围不合法')
    jobs=[{'keyword':word,'page':page} for word in args.keyword for page in range(args.search_start_page,args.search_start_page+args.search_pages)]
    if not args.execute:
        print(json.dumps({'mode':'preview','network':False,'send':False,'jobs':len(jobs),'independent_queues':['collection','context','analysis']},ensure_ascii=False));return 0
    for key in ('session_home','sender_uid','source_db','ledger','account','style'):
        if not getattr(args,key):raise Stop('缺少现有账号或账本配置')
    for key in ('session_home','source_db','ledger','account','style'):setattr(args,key,str(Path(getattr(args,key)).resolve(strict=True)))
    root=Path(args.output).resolve()
    binding=hashlib.sha256(json.dumps(vars(args)|{'execute':False,'resume':False,'output':str(root)},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    lock=Path(args.ledger).parent/'.xhs-collection-runner.lock'
    descriptor=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.close(descriptor)
    try:
        store=Store.resume(root,binding) if args.resume else Store.create(root,jobs,binding)
        result=run(store,*callbacks(root,args),stop_file=root/'STOP')
        counts={stage:{value:sum(j[stage]==value for j in result['jobs']) for value in ('done','failed','pending','skipped')} for stage in ('collection','context','analysis')}
        print(json.dumps({'status':result['status'],'queues':counts,'send':False},ensure_ascii=False));return 0 if result['status']=='completed' else 2
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':
    try:raise SystemExit(main())
    except (Stop,OSError,ValueError) as exc:
        print('停止：'+(str(exc) if isinstance(exc,Stop) else type(exc).__name__),file=sys.stderr);raise SystemExit(2)
