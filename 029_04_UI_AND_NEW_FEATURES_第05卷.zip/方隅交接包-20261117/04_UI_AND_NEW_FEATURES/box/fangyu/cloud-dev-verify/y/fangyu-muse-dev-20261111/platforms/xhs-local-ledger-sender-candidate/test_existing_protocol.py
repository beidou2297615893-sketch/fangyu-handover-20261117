"""Offline checks for the current shared ledger, using only synthetic local data."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
LEDGER = ROOT.parent / 'shared-acquisition-ledger' / 'ledger.py'


class ProtocolTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.base = Path(self.tmp.name)
        self.db = self.base / 'synthetic.sqlite3'
        self.call('init')

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, *args, ok=True):
        p = subprocess.run([sys.executable, '-B', str(LEDGER), '--db', str(self.db), *args],
                           capture_output=True, text=True, encoding='utf-8')
        self.assertEqual(p.returncode == 0, ok, p.stderr + p.stdout)
        return json.loads(p.stdout)

    def test_local_history_and_unknown_peer_reply_do_not_grant_reservation(self):
        self.call('lead', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment')
        self.call('identity-bind', 'xiaohongshu', 'synthetic_uid', 'synthetic_uid', 'synthetic evidence')
        assessment = self.base / 'assessment.json'
        assessment.write_text(json.dumps({'source': 'synthetic', 'intent': 'rental', 'store': '古北',
                                          'match': 'match', 'pending': '平台回复未查',
                                          'draft': 'synthetic', 'peer_reply': 'unknown'}, ensure_ascii=False),
                              encoding='utf-8')
        self.call('assess', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment', str(assessment))
        self.call('review', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment', 'test', 'local only')
        result = self.call('reserve', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment', 'synthetic_token', ok=False)
        self.assertIn('screening not eligible', json.dumps(result))
        self.assertEqual(self.call('check', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment')['target']['status'], 'reviewed')

    def test_prior_unknown_submission_blocks_even_after_review(self):
        self.call('lead', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment')
        self.call('identity-bind', 'xiaohongshu', 'synthetic_uid', 'synthetic_uid', 'synthetic evidence')
        payload = self.base / 'delivery.json'
        payload.write_text(json.dumps({'records': [{'platform': 'xiaohongshu', 'customer_id': 'synthetic_uid',
                              'comment_id': 'synthetic_comment', 'delivery_state': 'submitted',
                              'reference': 'synthetic_previous'}]}), encoding='utf-8')
        self.call('import-deliveries', str(payload))
        self.call('review', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment', 'test', 'local only', ok=False)
        target = self.call('check', 'xiaohongshu', 'synthetic_uid', 'synthetic_comment')['target']
        self.assertEqual(target['status'], 'unknown')


if __name__ == '__main__':
    unittest.main(verbosity=2)
