"""Narrow collection-only recovery after explicit human verification confirmation."""
import hashlib
import json
import sqlite3
from contextlib import closing
from datetime import datetime

from scoped_recovery import effective_halt, verification_resume_evidence


def confirmable(attempt):
    if not attempt or attempt['added'] != 0:
        return False
    return verification_resume_evidence(attempt['state'], json.loads(attempt['response']))


def prepare_scope(database, plan, confirmed_id, new_scope, authorization, identity_file):
    uid, old_scope = plan['account_uid'], plan['scan_id']
    words = set(plan.get('deferred_previous_account_searches', []))
    videos = set(plan.get('excluded_historical_videos', []))
    with closing(sqlite3.connect(database, timeout=10)) as db, db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN IMMEDIATE')
        halt = effective_halt(db, uid, old_scope)
        if not halt or halt['request_id'] != confirmed_id:
            raise ValueError('confirmed event no longer matches the current stop')
        attempt = db.execute('SELECT * FROM attempts WHERE request_id=?', (confirmed_id,)).fetchone()
        if not confirmable(attempt):
            raise ValueError('this halt does not allow human verification continuation')
        spec = json.loads(attempt['spec'])
        if spec['account_uid'] != uid or spec['scan_id'] != old_scope:
            raise ValueError('confirmation does not match the active account and scope')
        for row in db.execute('SELECT spec FROM attempts'):
            prior = json.loads(row[0])
            if prior['kind'] == 'search':
                words.add(prior['target'])
            elif prior['kind'] == 'comments':
                videos.add(prior['target'])
        words.add(spec['keyword'])
        stores = [dict(store, keywords=[word for word in store['keywords'] if word not in words])
                  for store in plan['stores']]
        if not all(store['keywords'] for store in stores):
            raise ValueError('a store has no untried search terms')
        allowed = sorted({word for store in stores for word in store['keywords']})
        old_review = db.execute('SELECT * FROM collection_scope_reviews WHERE account_uid=? AND scan_id=?',
                                (uid, old_scope)).fetchone()
        now = datetime.now().astimezone().isoformat()
        inherited = old_review['reviewed_request_id'] if old_review else confirmed_id
        db.execute('INSERT INTO collection_scope_reviews VALUES(?,?,?,?,?,?,?)',
                   (uid, new_scope, inherited, json.dumps(allowed), json.dumps(sorted(videos)), authorization, now))
        db.execute('''INSERT INTO collection_event_reviews
                      SELECT account_uid,?,request_id,response_sha256,authorization,evidence,reviewed_at
                      FROM collection_event_reviews WHERE account_uid=? AND scan_id=?''', (new_scope, uid, old_scope))
        digest = hashlib.sha256(attempt['response'].encode()).hexdigest()
        db.execute('INSERT INTO collection_event_reviews VALUES(?,?,?,?,?,?,?)',
                   (uid, new_scope, confirmed_id, digest, authorization, identity_file, now))
        if effective_halt(db, uid, new_scope):
            raise ValueError('an effective halt remains in the new scope')
    updated = dict(plan, scan_id=new_scope, stores=stores, recovery_from_scan=old_scope,
                   deferred_previous_account_searches=sorted(words), excluded_historical_videos=sorted(videos))
    evidence = dict(request_id=confirmed_id, original_state=attempt['state'], response_sha256=digest,
                    old_scope=old_scope, new_scope=new_scope, excluded_target=spec['target'],
                    excluded_keyword=spec['keyword'], authorization=authorization, identity_evidence=identity_file)
    return updated, evidence
