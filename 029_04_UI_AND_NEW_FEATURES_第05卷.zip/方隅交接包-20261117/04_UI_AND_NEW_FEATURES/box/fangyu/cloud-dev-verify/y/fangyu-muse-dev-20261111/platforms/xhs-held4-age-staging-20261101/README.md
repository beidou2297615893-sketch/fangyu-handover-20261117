# Final four reviewed candidates: offline staging patch

Not applied to the active sender. No network, real ledger, state, or credential access.

`held4-age-only.patch` changes only `target_isolation.py`, based on the already merged historical180 age support. `candidate/bulk_run.py` is an unchanged baseline used by the offline mapping tests.

The original180 source SHA remains supported. The additional exact source is:

`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-tone-candidates-20261101/held95-independent-20261101/candidates.jsonl`

SHA256: `f2d7bc983d6b6c02d1761fabde14cdb28b109b9bffebb9fb6db439a745a987f2`.

No grant-schema change. Set the existing optional `historical_age_override` to `{source_path: <absolute source path>, source_sha256: <source SHA>}`. Existing authorization must include `send_all_authorized: true`, `historical_over_60_days_authorized: true`, `historical_priority: "after_recent_batches"`, and `historical_source_sha256: <same source SHA>`, alongside the existing original instruction, sender UID, history, and revocation bindings.

`allows_historical_age(row, meta, *, batch_path)` waives only the age hold for seq377/523 when all bindings match. Source verification also applies to recent seq557/560: active `hold_reasons` may contain only `fresh_authoritative_dedup_required`, `current_need_unknown`, `platform_thread_not_checked`. Every other active hold is refused. Current need and housing facts must remain unconfirmed, review notes preserved, and factual scope limited to offering to check. Original immutable source and unknown annotations are never rewritten. Old historical180 retains empty active holds.

Use sequence order 377,523,557,560. The preparation helper must freeze exact original567 target identities, approved source wording, source manifest, current authoritative history and all revocation versions; native reservation still revalidates all policy/history inside its transaction. No original-post search is added. Same-customer/comment/UID defenses still run before the account-level exception.

Verification: 9 staging tests and 100 existing core tests passed; `verification.json` records hashes and confirms active files unchanged. The new tests were observed failing before implementation. Synthetic native-reservation tests confirm existing history stays byte-identical and a second comment for the same customer is rejected. Review and merge only when the active batch has exited.

Run staging tests from this folder with `../vendor/cli-runtime/Scripts/python.exe -B -X utf8 -m unittest test_age_override -v`.
