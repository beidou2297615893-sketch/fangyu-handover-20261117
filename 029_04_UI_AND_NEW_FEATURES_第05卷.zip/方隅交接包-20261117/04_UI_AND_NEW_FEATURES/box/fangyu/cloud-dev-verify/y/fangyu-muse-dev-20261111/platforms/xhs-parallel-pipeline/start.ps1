param(
    [switch]$Execute,
    [switch]$Resume,
    [string[]]$Keywords = @('古北租房','古北求租','古北找房'),
    [int]$SearchStartPage = 1,
    [int]$SearchPages = 5,
    [int]$MaxNotes = 10,
    [int]$MaxPages = 2,
    [string]$Output = ''
)
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskPython = Join-Path $taskRoot 'work/vendor/cli-runtime/Scripts/python.exe'
$taskEntry = Join-Path $PSScriptRoot 'parallel.py'
if (-not $Output) { $Output = Join-Path $PSScriptRoot 'work/gubei-parallel-live' }
$taskArguments = @('-X','utf8',$taskEntry,'--output',$Output,'--search-start-page',"$SearchStartPage",'--search-pages',"$SearchPages",'--max-notes',"$MaxNotes",'--max-pages',"$MaxPages")
foreach ($taskKeyword in $Keywords) { $taskArguments += @('--keyword',$taskKeyword) }
if (-not $Execute) { & $taskPython @taskArguments; exit $LASTEXITCODE }

# Obtain only the already-verified public account UID from prior local analysis.
# Cookie/Token stores are never loaded by this launcher or printed.
$taskIdentityFile = Join-Path $taskRoot 'work/xhs-continuous-runner/work/live-20261028-sample/batch-0001/context-and-ai/analysis/checkpoint.json'
$taskIdentity = Get-Content -Raw -LiteralPath $taskIdentityFile | ConvertFrom-Json
if (-not ($taskIdentity.sender_uid -is [string]) -or $taskIdentity.sender_uid -notmatch '^[a-fA-F0-9]{24}$') { throw '已核对的账号标识缺失，先检查原采集记录。' }
$taskLedger = Join-Path $taskRoot 'work/shared-acquisition-ledger/shared.sqlite3'
$taskLock = Join-Path (Split-Path $taskLedger -Parent) '.xhs-collection-runner.lock'
if (Test-Path -LiteralPath $taskLock) { throw '账本采集锁存在，请先核对其他采集任务。' }
$taskArguments += @('--session-home',(Join-Path $taskRoot 'work/xhs-standalone-session/cli-login-20261028-165417'),
    '--sender-uid',$taskIdentity.sender_uid,
    '--source-db',(Join-Path $taskRoot 'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'),
    '--ledger',$taskLedger,
    '--account',(Join-Path $taskRoot 'work/xhs-ai-standalone/account-leimu.json'),
    '--style',(Join-Path $taskRoot 'work/xhs-ai-standalone/style-leimu.json'),'--execute')
if ($Resume) { $taskArguments += '--resume' }
$taskLogDirectory = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Path $taskLogDirectory -Force | Out-Null
$taskStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$taskOutLog = Join-Path $taskLogDirectory ($taskStamp + '-stdout.txt')
$taskErrLog = Join-Path $taskLogDirectory ($taskStamp + '-stderr.txt')
# Start-Process flattens ArgumentList on Windows: explicitly quote every value.
$taskQuotedArguments = $taskArguments | ForEach-Object { '"' + ([string]$_).Replace('"','\"') + '"' }
$taskProcess = Start-Process -FilePath $taskPython -ArgumentList $taskQuotedArguments -WorkingDirectory $taskRoot -WindowStyle Hidden -RedirectStandardOutput $taskOutLog -RedirectStandardError $taskErrLog -PassThru
@{pid=$taskProcess.Id;output=$Output;stdout=$taskOutLog;stderr=$taskErrLog;send=$false} | ConvertTo-Json | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $taskLogDirectory ($taskStamp+'-process.json'))
Write-Output ('采集进程已启动：' + $taskProcess.Id)
Write-Output ('状态文件：' + (Join-Path $Output 'state.json'))
