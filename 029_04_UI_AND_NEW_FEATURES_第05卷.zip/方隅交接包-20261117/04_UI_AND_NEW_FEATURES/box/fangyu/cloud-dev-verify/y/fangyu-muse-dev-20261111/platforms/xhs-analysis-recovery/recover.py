import sys,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'work/xhs-context-lite-analysis'));import run as c
out=root/'work/xhs-analysis-recovery';rows=c.load(out/'redo-input.json');c.OUT=out/'analysis';c.OUT.mkdir(exist_ok=True)
c.REVIEW=c.load(root/'work/xhs-three-stage-integration/live-consumer/batch-0004/analysis/batches/001/input.json')['review_as_of']
c.ai.SYSTEM+='\n严格逐字拷贝target_comment_id。own_evidence与region_evidence必须使用原文连续子串，不得把不换行空格改为普通空格，不得改标点。'
provider=c.ai.CodexProvider();account=c.load(root/'work/xhs-ai-standalone/account-leimu.json')
if c.ai.digest(provider.executable)!=provider.executable_sha256:raise ValueError('executable changed')
result=c.execute_batch(0,rows,provider,account)
combined=c.load(out/'reused-analysis.json')+result
original=c.load(root/'work/xhs-three-stage-integration/live-consumer/batch-0004/input.json')
if len(combined)!=len(original) or {x['comment_id'] for x in combined}!={x['comment_id'] for x in original}:raise ValueError('incomplete or duplicate')
c.save(out/'analysis.json',combined);c.save(out/'state.json',{'status':'analysis_completed','comments':len(combined),'reused':len(combined)-len(result),'rerun':len(result),'send':False,'platform_requests':0,'original_untouched':True})
print('RECOVERY_ANALYSIS_COMPLETE',len(combined))
