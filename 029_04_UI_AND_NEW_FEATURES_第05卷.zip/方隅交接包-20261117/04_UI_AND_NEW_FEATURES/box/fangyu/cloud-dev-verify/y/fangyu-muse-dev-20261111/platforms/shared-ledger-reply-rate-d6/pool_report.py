"""Read-only candidate for the next progress display. Never changes state."""
import hashlib,json,sqlite3,time
from contextlib import closing
from pathlib import Path
from pool_counts import count_pool
from reply_rate import ROOT,LEDGER

CONTROL=ROOT/'work/douyin-local-control'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def report():
    handoff=read(ROOT/'work/fangyu-douyin-independent/classification-handoff-status.json')
    fit=handoff['commercial_fit'];digest=hashlib.sha256();eligible={};now=time.time()
    with Path(fit['all_pool_file']).open('rb') as f:
        for line in f:
            digest.update(line)
            if not line.strip():continue
            row=json.loads(line);match=row.get('commercial_fit') or {}
            if match.get('lead_intent') not in ('medium','high','super_high') or match.get('eligible_candidate') is not True:continue
            value=row.get('published_at_unix')
            try:
                value=float(value); value=value/1000 if value>100000000000 else value
            except (TypeError,ValueError):continue
            if not now-30*86400<=value<=now+3600:continue
            cid=str(row.get('comment_id') or '');uid=str(row.get('customer_uid') or '')
            if cid and uid:eligible[cid]=uid
    if digest.hexdigest()!=fit['all_pool_sha256']:raise RuntimeError('分类快照正在更新')
    with closing(sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('BEGIN')
        reservations=db.execute("SELECT customer,status FROM reservations WHERE platform='douyin'").fetchall()
        leads=db.execute("SELECT customer,status FROM leads WHERE platform='douyin'").fetchall()
        records=reservations+leads
        blocked={str(uid) for uid,_ in reservations}
        blocked.update(str(uid) for uid,status in leads if status in ('sent','unknown','reserved'))
    legacy=ROOT/'Codex获客工作台/work/reply_receipts.sqlite3'
    with closing(sqlite3.connect(legacy.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        for uid,status in db.execute('SELECT uid,status FROM sends'):
            if not uid:continue
            blocked.add(str(uid))
            records.append((str(uid),'sent' if status=='SENT_VERIFIED' else 'unknown'))
    result=count_pool(set(eligible.values()),records)
    active=read(CONTROL/'active.json');task=Path(active['task']);manifest=read(task/'approved-cli-queue.json')
    raw=json.dumps(manifest['items'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    if hashlib.sha256(raw).hexdigest()!=manifest.get('items_sha256'):raise RuntimeError('发送清单正在更新')
    excluded=read(task/'unavailable-targets.json') if (task/'unavailable-targets.json').exists() else {}
    pending=set()
    for item in manifest['items']:
        cid=str(item.get('cid') or '');uid=str(item.get('uid') or '')
        if (eligible.get(cid)!=uid or uid in blocked or cid in excluded.get('comments',{})
            or item.get('video') in excluded.get('operator_skipped_videos',{})
            or (task/(cid+'.json')).exists() or (task/(cid+'.json.submitted')).exists()):continue
        pending.add(uid)
    result['pending']=len(pending)
    result['scope']='近30天符合业务条件的中高意向客户；本批待回复为批准清单去重余量'
    return result

if __name__=='__main__':print(json.dumps(report(),ensure_ascii=False))
