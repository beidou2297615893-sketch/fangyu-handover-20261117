from pathlib import Path
import collections
import datetime as dt
import json
import sqlite3

OUT = Path(__file__).resolve().parent
DATA = Path('C:/Users/rmsama/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/fangyu-apartment-clientWorkspace')
LOG = DATA / 'accounts/cloud-5f633971ed95c5a0e0187b71/7dadec8b3e6241d583f8b234619ae32c/platform-activity.jsonl'
CN = dt.timezone(dt.timedelta(hours=8))
CUTOFF = dt.datetime(2026, 10, 19, 18, 51, tzinfo=CN).timestamp()
DAY = dt.datetime(2026, 10, 19, tzinfo=CN).timestamp()
events = [json.loads(line) for line in LOG.read_text('utf-8').splitlines() if line.strip()]

def timestamp(event):
    value = event.get('at')
    return float(value) if isinstance(value, (float, int)) else None

def local_time(value):
    return dt.datetime.fromtimestamp(value, CN).isoformat(timespec='seconds')

def count(rows, field):
    return dict(collections.Counter(str(row.get(field)) for row in rows))

def summarize(rows):
    starts = [r for r in rows if r.get('stage') == 'started']
    finishes = [r for r in rows if r.get('stage') == 'finished']
    return {'event_count': len(rows), 'started_request_count': len(starts),
            'started_kind_counts': count(starts, 'kind'),
            'started_method_counts': count(starts, 'method'),
            'finished_status_counts': count(finishes, 'status')}

today = [r for r in events if timestamp(r) is not None and timestamp(r) >= DAY]
before = [r for r in today if timestamp(r) < CUTOFF]
after = [r for r in today if timestamp(r) >= CUTOFF]
blocked = [r for r in today if r.get('stage') == 'finished' and r.get('status') in (461, 471)]
timeline = []
for hour in sorted({int((timestamp(r) - DAY) // 3600) for r in today}):
    rows = [r for r in today if int((timestamp(r) - DAY) // 3600) == hour]
    timeline.append({'hour_china': f'{hour:02d}:00', **summarize(rows)})

connection = sqlite3.connect(DATA.joinpath('workspace.sqlite3').as_uri() + '?mode=ro', uri=True)
replies = [json.loads(row[0]) for row in connection.execute("select body from records where entity='replies'")]
plans = [json.loads(row[0]) for row in connection.execute("select body from records where entity='ui_reply_delivery_plans_v1'")]
connection.close()

report = {
    'audited_at_china': dt.datetime.now(CN).isoformat(timespec='seconds'),
    'scope': 'Existing local account activity log and read-only local database; no platform calls.',
    'screenshot_profile_reset_time_china': local_time(CUTOFF),
    'freeze_start_time': 'Not separately shown; permanent effect is shown in screenshot.',
    'all_logged_history': summarize(events),
    'oct19_before_1851': summarize(before),
    'oct19_at_or_after_1851': summarize(after),
    'hourly_oct19': timeline,
    'first_461_or_471_oct19': local_time(timestamp(blocked[0])) if blocked else None,
    'blocked_times_oct19': [local_time(timestamp(r)) for r in blocked],
    'reply_status_counts': count(replies, 'status'),
    'delivery_plan_state_counts': count(plans, 'state'),
    'historical_reply_requests': [
        {'time_china': local_time(timestamp(r)), **{k: r.get(k) for k in ('stage', 'kind', 'method', 'status')}}
        for r in events if r.get('kind') == 'reply'
    ],
    'last_12_request_events': [
        {'time_china': local_time(timestamp(r)), **{k: r.get(k) for k in ('stage', 'kind', 'method', 'status')}}
        for r in [r for r in today if r.get('stage') in ('started', 'finished')][-12:]
    ],
    'limitations': [
        'Local log is not a platform-side audit or a record of actions outside this app.',
        'HTTP 461/471 indicates a verification response; it does not prove the cause of permanent account freeze.',
        'The screenshot timestamp is minute precision. Counts around that minute cannot establish exact ordering.',
        '18:51 is shown under the profile-reset measure; the separate freeze measure shows permanent effect without an exact start timestamp.',
        'No sent rows in the current replies table does not prove no historical sends: independent CLI tests have their own journals.',
    ],
}
historical_result = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/collect/work/wallpaper-real-500/repair/ten-reply-test/RESULT.json')
historical_plan = historical_result.with_name('plan.json')
result = json.loads(historical_result.read_text('utf-8'))
plan = json.loads(historical_plan.read_text('utf-8'))
report['oct18_independent_reply_test'] = {
    k: result.get(k) for k in ('status', 'started_at', 'finished_at', 'planned', 'confirmed', 'visible_confirmed', 'individual_confirmed', 'sop_batch_confirmed')
}
report['oct18_independent_reply_test']['distinct_reply_texts'] = len({r.get('content') for r in plan})
report['oct18_independent_reply_test']['all_have_platform_reply_id'] = all(bool(r.get('platform_comment_id')) for r in plan)
(OUT / 'LOCAL-READONLY-AUDIT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=True))
