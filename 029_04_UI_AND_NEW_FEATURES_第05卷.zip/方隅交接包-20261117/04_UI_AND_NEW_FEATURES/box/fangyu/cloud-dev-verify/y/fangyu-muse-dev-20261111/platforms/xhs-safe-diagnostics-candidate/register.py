"""Preview or atomically register collected comment IDs in an existing ledger.

Default operation opens the ledger read-only. ``--apply`` is an explicit local
database write; this module never contacts the platform, a model, or a browser.
The collected source is evidence, not proof of platform reply history.
"""
from contextlib import closing
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time

import collector

PLATFORM = 'xiaohongshu'
BLOCKING = ('reserved', 'unknown', 'sent', 'submitted')
UID_TABLE = 'collection_uid_observations'
UID_DDL = '''CREATE TABLE collection_uid_observations(
    platform TEXT NOT NULL, platform_uid TEXT NOT NULL, canonical TEXT NOT NULL,
    basis TEXT NOT NULL, source TEXT NOT NULL, observed_at INTEGER NOT NULL,
    PRIMARY KEY(platform,platform_uid), UNIQUE(platform,canonical))'''


class Invalid(ValueError): pass


def _new_customer(uid):
    return 'xhs_new_' + hashlib.sha256((PLATFORM + ':' + uid).encode('utf8')).hexdigest()


def _unique_indexes(db, table):
    result=[]
    for row in db.execute('PRAGMA index_list("'+table+'")'):
        if row[2] and not row[4]:
            name=row[1].replace('"','""')
            result.append([item[2] for item in db.execute('PRAGMA index_info("'+name+'")')])
    return result


def _validate_schema(db):
    required={
        'leads':{'platform','customer','comment','status','source'},
        'reservations':{'token','platform','customer','comment','status'},
        'identity_aliases':{'platform','alias','canonical'},
        'historical_deliveries':{'platform','customer','delivery_state'},
        'local_sender_plans':{'token','data'},
    }
    for table, expected in required.items():
        columns={row[1] for row in db.execute('PRAGMA table_info("'+table+'")')}
        if not expected <= columns:
            raise Invalid('共享账本结构不兼容：'+table)
    lead_indexes=_unique_indexes(db,'leads')
    if ['platform','comment'] not in lead_indexes or ['platform','customer','comment'] not in lead_indexes:
        raise Invalid('共享账本缺少评论唯一约束')
    if ['platform','alias'] not in _unique_indexes(db,'identity_aliases'):
        raise Invalid('共享账本缺少身份别名唯一约束')
    if ['token'] not in _unique_indexes(db,'reservations') or ['token'] not in _unique_indexes(db,'local_sender_plans'):
        raise Invalid('共享账本缺少预留唯一约束')
    foreign_keys={(r[2],r[3],r[4]) for r in db.execute('PRAGMA foreign_key_list(local_sender_plans)')}
    if ('reservations','token','token') not in foreign_keys:
        raise Invalid('发送计划缺少预留关联')


def validate_batch(data):
    if not isinstance(data,dict) or data.get('schema') != 'xhs-collected-ai-input-v1' or not isinstance(data.get('customers'),list):
        raise Invalid('采集结果格式无效')
    users, customers, comments = set(), set(), set()
    for row in data['customers']:
        if not isinstance(row,dict): raise Invalid('客户记录无效')
        uid, cid = row.get('customer_uid'), row.get('customer_id')
        if not all(isinstance(v,str) and v and v==v.strip() and len(v)<=5000 for v in (uid,cid)):
            raise Invalid('缺少客户或平台用户标识')
        if uid in users or cid in customers: raise Invalid('重复客户或平台用户，须先归并')
        users.add(uid); customers.add(cid)
        others=row.get('other_comments',[])
        if not isinstance(others,list) or len(others)>100: raise Invalid('客户评论列表无效')
        for item in [row,*others]:
            if not isinstance(item,dict): raise Invalid('评论记录无效')
            comment, note, text = item.get('comment_id'), item.get('note_id'), item.get('comment_text')
            if not all(isinstance(v,str) and v and v==v.strip() and len(v)<=5000 for v in (comment,note,text)):
                raise Invalid('评论标识、帖子标识或原文缺失')
            if comment in comments: raise Invalid('同一评论在批次中重复')
            comments.add(comment)
    return data['customers']


def _stored_plans(db):
    tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    required={'leads','reservations','identity_aliases','historical_deliveries','local_sender_plans'}
    if not required <= tables: raise Invalid('共享账本结构不完整，不能导入')
    rows=db.execute("SELECT r.customer,r.comment,r.status,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=?",(PLATFORM,)).fetchall()
    plans=[]
    for customer,comment,status,payload in rows:
        if payload is None:
            plans.append({'customer':customer,'comment':comment,'status':status,'uid':None})
            continue
        try:
            doc=json.loads(payload)
            plan=doc.get('plan') or doc.get('local_mode',{}).get('plan')
            uid=plan.get('customer_uid')
            canonical=plan.get('canonical_customer') or customer
            if not isinstance(uid,str) or not uid or canonical!=customer:
                raise ValueError('identity mismatch')
        except (ValueError,TypeError,KeyError,AttributeError):
            raise Invalid('历史发送计划无法解析，停止导入') from None
        plans.append({'customer':customer,'comment':comment,'status':status,'uid':uid})
    return plans


def _identity_observations(db, *, apply):
    entry=db.execute("SELECT type FROM sqlite_master WHERE name=?",(UID_TABLE,)).fetchone()
    if entry is None:
        if apply: db.execute(UID_DDL)
        return {}, {}, False
    if entry[0]!='table': raise Invalid('UID观察表名称被其他对象占用')
    columns=[(r[1],r[2].upper(),r[3],r[5]) for r in db.execute('PRAGMA table_info(collection_uid_observations)')]
    expected=[('platform','TEXT',1,1),('platform_uid','TEXT',1,2),('canonical','TEXT',1,0),
              ('basis','TEXT',1,0),('source','TEXT',1,0),('observed_at','INTEGER',1,0)]
    if columns!=expected:
        raise Invalid('UID观察表结构不兼容，停止导入')
    unique=[]
    for row in db.execute('PRAGMA index_list(collection_uid_observations)'):
        if row[2] and not row[4]:
            unique.append([x[2] for x in db.execute('PRAGMA index_info("'+row[1]+'")')])
    if ['platform','platform_uid'] not in unique or ['platform','canonical'] not in unique:
        raise Invalid('UID观察表缺少身份唯一约束')
    rows=db.execute('SELECT platform_uid,canonical,basis,source,observed_at FROM collection_uid_observations WHERE platform=?',(PLATFORM,)).fetchall()
    for uid,cid,basis,source,observed in rows:
        if (not isinstance(uid,str) or not uid.strip() or not isinstance(cid,str) or not cid.strip()
                or basis not in ('local_source_consistency_only','new_uid_candidate_not_platform_verified')
                or not isinstance(source,str) or not source.strip() or type(observed) is not int or observed<=0):
            raise Invalid('UID观察证据无效，停止导入')
    return {r[0]:r[1] for r in rows}, {r[1]:r[0] for r in rows}, True


def register(path, data, identity_map, source, *, apply=False):
    rows=validate_batch(data)
    if not isinstance(identity_map,dict) or not isinstance(source,str) or not source.strip():
        raise Invalid('身份映射或来源缺失')
    path=Path(path).resolve(strict=True)
    uri=path.as_uri()+('?mode=rw' if apply else '?mode=ro')
    with closing(sqlite3.connect(uri,uri=True,timeout=10,isolation_level=None)) as db:
        db.execute('PRAGMA foreign_keys=ON')
        if not apply: db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN IMMEDIATE' if apply else 'BEGIN')
        try:
            _validate_schema(db)
            plans=_stored_plans(db)
            observed_uid, observed_canonical, table_existed = _identity_observations(db,apply=apply)
            aliases=db.execute('SELECT alias,canonical FROM identity_aliases WHERE platform=?',(PLATFORM,)).fetchall()
            alias_map={a:c for a,c in aliases}
            reverse={}
            for uid,cid in identity_map.items():
                if isinstance(uid,str) and isinstance(cid,str) and uid and cid:
                    reverse.setdefault(cid,set()).add(uid)
            existing=db.execute('SELECT customer,comment,status FROM leads WHERE platform=?',(PLATFORM,)).fetchall()
            comments={comment:(customer,status) for customer,comment,status in existing}
            leads_by_customer={}
            for customer,comment,status in existing:
                leads_by_customer.setdefault(customer,[]).append((comment,status))
            deliveries=db.execute('SELECT customer,delivery_state FROM historical_deliveries WHERE platform=?',(PLATFORM,)).fetchall()
            result={'mode':'apply' if apply else 'preview','customers':len(rows),'inserted':0,'would_insert':0,
                    'already_present':0,'blocked_customers':0,'blocked':[],'platform_reply_history_checked':False,
                    'uid_observation_table_existed':table_existed}
            for row in rows:
                uid,cid=row['customer_uid'],row['customer_id']
                item_comments=[x['comment_id'] for x in [row,*row.get('other_comments',[])]]
                reason=None
                if uid in identity_map:
                    if not isinstance(identity_map[uid],str) or not identity_map[uid] or identity_map[uid]!=cid:
                        reason='本地身份映射冲突或待核'
                elif cid!=_new_customer(uid):
                    reason='新用户的本地标识不匹配'
                if not reason and len(reverse.get(cid,set())-{uid})>0:
                    reason='本地客户编号对应其他平台用户'
                if not reason and uid in alias_map and alias_map[uid]!=cid:
                    reason='现有身份别名冲突'
                if not reason and uid in observed_uid and observed_uid[uid]!=cid:
                    reason='平台用户已关联其他本地客户'
                if not reason and cid in observed_canonical and observed_canonical[cid]!=uid:
                    reason='本地客户已关联其他平台用户'
                if not reason:
                    for prior in plans:
                        if prior['uid']==uid and prior['customer']!=cid:
                            reason='平台用户已有其他本地客户记录'
                            break
                        if prior['customer']==cid and prior['uid'] and prior['uid']!=uid:
                            reason='本地客户记录对应其他平台用户'
                            break
                        if prior['status'] in BLOCKING and (prior['customer']==cid or prior['uid']==uid or prior['comment'] in item_comments):
                            reason='已有已提交、在途或结果未知记录'
                            break
                        if (prior['status'] in BLOCKING and prior['uid'] is None and prior['customer'] not in reverse
                                and prior['customer'] not in observed_canonical and prior['customer'] not in alias_map.values()):
                            reason='历史未确认记录缺少可核对的平台身份'
                            break
                if not reason and any(customer==cid and state!='not_sent' for customer,state in deliveries):
                    reason='旧软件已有未确认投递记录'
                if not reason and any(state!='not_sent' and customer not in reverse and customer not in observed_canonical
                                      and customer not in alias_map.values() for customer,state in deliveries):
                    reason='旧软件历史记录缺少可核对的平台身份'
                if not reason and any(status not in ('unverified','reviewed','history_clear') for _,status in leads_by_customer.get(cid,[])):
                    reason='客户已有已发送或待核记录'
                if not reason and any(c in comments and comments[c][0]!=cid for c in item_comments):
                    reason='评论已属于其他客户'
                if reason:
                    result['blocked_customers']+=1
                    result['blocked'].append({'customer_id':cid,'reason':reason})
                    continue
                if uid not in observed_uid:
                    if apply:
                        basis='local_source_consistency_only' if uid in identity_map else 'new_uid_candidate_not_platform_verified'
                        db.execute('INSERT INTO collection_uid_observations(platform,platform_uid,canonical,basis,source,observed_at) VALUES(?,?,?,?,?,?)',
                                   (PLATFORM,uid,cid,basis,source,int(time.time())))
                    observed_uid[uid]=cid
                    observed_canonical[cid]=uid
                for comment in item_comments:
                    if comment in comments:
                        result['already_present']+=1
                        continue
                    result['would_insert']+=1
                    if apply:
                        db.execute("INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,'unverified',?)",(PLATFORM,cid,comment,source))
                        result['inserted']+=1
                    comments[comment]=(cid,'unverified')
                    leads_by_customer.setdefault(cid,[]).append((comment,'unverified'))
            if apply: db.commit()
            else: db.rollback()
            return result
        except BaseException:
            db.rollback()
            raise


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection',required=True,help='采集结果 collection.json')
    parser.add_argument('--ledger',required=True,help='已有共享账本')
    parser.add_argument('--source-db',required=True,help='用于只读核对本地UID映射的客户数据库')
    parser.add_argument('--sender-uid',required=True,help='用于提取本地资料的当前账号UID')
    parser.add_argument('--apply',action='store_true',help='明确写入已有共享账本；默认只读预览')
    parser.add_argument('--report',help='可选：写入新的本地报告，保留逐客户待核原因')
    args=parser.parse_args(argv)
    report=Path(args.report).resolve() if args.report else None
    if report and (report.exists() or not report.parent.is_dir()):
        raise Invalid('报告目录不存在或报告文件已经存在')
    source=Path(args.collection).resolve(strict=True)
    data=json.loads(source.read_text(encoding='utf-8-sig'))
    identity_map=collector.load_identity_map(args.source_db,args.sender_uid)
    result=register(args.ledger,data,identity_map,'collection:'+str(source),apply=args.apply)
    if report:
        try:
            with report.open('x',encoding='utf8') as file:
                json.dump(result,file,ensure_ascii=False,indent=2)
        except OSError:
            if args.apply:
                print('账本可能已提交，但本地报告保存失败；请先核对账本，不要自动重试。',file=sys.stderr)
            raise
    summary={k:v for k,v in result.items() if k!='blocked'}
    summary['blocked_reasons']={reason:sum(1 for x in result['blocked'] if x['reason']==reason)
                                for reason in sorted({x['reason'] for x in result['blocked']})}
    if report: summary['report_saved']=True
    print(json.dumps(summary,ensure_ascii=False))
    return 0


if __name__=='__main__':
    try: raise SystemExit(main())
    except (Invalid,collector.Halt,OSError,ValueError,sqlite3.Error) as exc:
        print('停止：'+str(exc),file=sys.stderr);raise SystemExit(2)
