"""Controlled note-body enrichment. Preview by default; never searches or sends."""
from __future__ import annotations
import argparse
from copy import deepcopy
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('controlled_context_collector', ROOT.parent/'xhs-collection-candidate'/'collector.py')
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)
Halt = collector.Halt


class ContextClient(collector.ReadClient):
    # A POST here only reads an individual note. No search, comments, history,
    # browser/HTML fallback, interaction or mutation endpoint is authorized.
    _ALLOWED = {
        ('GET', 'https://edith.xiaohongshu.com/api/sns/web/v2/user/me'),
        ('POST', 'https://edith.xiaohongshu.com/api/sns/web/v1/feed'),
    }


def selected_records(records, analysis):
    if not isinstance(records,list) or not isinstance(analysis,dict) or not isinstance(analysis.get('items'),list):
        raise Halt('上下文输入格式错误')
    selected={x.get('comment_id') for x in analysis['items'] if isinstance(x,dict) and isinstance(x.get('result'),dict) and x['result'].get('role')=='unknown'}
    result=[deepcopy(x) for x in records if isinstance(x,dict) and x.get('comment_id') in selected]
    if not selected or len(result)!=len(selected):raise Halt('待核评论与原始资料不一致')
    notes=set()
    for row in result:
        for item in [row,*row.get('other_comments',[])]:
            if not isinstance(item,dict) or not isinstance(item.get('note_id'),str) or not item['note_id']:
                raise Halt('待核评论缺少帖子标识')
            notes.add(item['note_id'])
    if len(notes)>3:raise Halt('一次最多补读三篇帖子')
    return result, sorted(notes)


def cached_context(home, notes, now=None):
    from xhs_cli.constants import CONFIG_DIR_NAME, TOKEN_CACHE_FILE
    path=Path(home)/CONFIG_DIR_NAME/TOKEN_CACHE_FILE
    if not path.is_file() or not path.resolve().is_relative_to(Path(home).resolve()):raise Halt('本地帖子访问上下文缺失')
    try:data=json.loads(path.read_text('utf-8-sig'))
    except (ValueError,OSError):raise Halt('本地帖子访问上下文不可读') from None
    result={}; now=time.time() if now is None else now
    for note in notes:
        ctx=data.get(note) if isinstance(data,dict) else None
        if not isinstance(ctx,dict) or not isinstance(ctx.get('token'),str) or not ctx['token'] or ctx.get('source')!='pc_search':
            raise Halt('帖子没有现成的搜索访问上下文，停止补读')
        stamp=ctx.get('ts')
        if type(stamp) not in (int,float) or not 0<=now-stamp<=86400:raise Halt('帖子访问上下文已过期，停止补读')
        result[note]={'token':ctx['token'],'source':ctx['source']}
    return result


def note_body(payload, expected):
    if not isinstance(payload,dict) or not isinstance(payload.get('items'),list):raise Halt('帖子正文响应格式异常')
    cards=[x.get('note_card') for x in payload['items'] if isinstance(x,dict) and isinstance(x.get('note_card'),dict) and x['note_card'].get('note_id')==expected]
    if len(cards)!=1:raise Halt('帖子正文身份无法核对')
    card=cards[0];title=card.get('title','');body=card.get('desc','')
    if not isinstance(title,str) or not isinstance(body,str) or max(len(title),len(body))>20000:raise Halt('帖子正文格式或长度异常')
    if not title and not body:raise Halt('帖子正文为空，未补齐上下文')
    return {'note_id':expected,'title':title,'body':body}


def enrich(client, sender_uid, records, contexts, top_level=False, on_progress=None):
    collector.verify_identity(client,sender_uid)
    acquired={}
    for note_id,ctx in contexts.items():
        # Deliberately call the direct method, never get_note_detail, whose
        # automatic HTML fallback is outside this controlled operation.
        payload=client.get_note_by_id(note_id,xsec_token=ctx['token'],xsec_source=ctx['source'])
        acquired[note_id]=note_body(payload,note_id)
        if on_progress:on_progress(acquired)
    result=deepcopy(records)
    for row in result:
        for item in [row,*row.get('other_comments',[])]:
            body=acquired[item['note_id']]
            if body['title']:item['post_title']=body['title']
            item['post_text']=body['body']
            removed={'post_body_missing'} if body['body'] else set()
            if top_level:
                item['parent_text']=''
                item['parent_relationship']='top_level_comment_on_post'
                removed.add('parent_not_collected')
            item['missing_context']=[x for x in item.get('missing_context',[]) if x not in removed]
    return result, acquired


def save(path,data):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True);p.add_argument('--review-analysis',required=True)
    p.add_argument('--output',required=True);p.add_argument('--session-home');p.add_argument('--sender-uid')
    p.add_argument('--source-top-level',action='store_true',help='Only when input is proven to consist of top-level main comments')
    p.add_argument('--execute',action='store_true');args=p.parse_args(argv)
    records,notes=selected_records(json.loads(Path(args.input).read_text('utf-8-sig')),json.loads(Path(args.review_analysis).read_text('utf-8-sig')))
    if not args.execute:
        print(json.dumps({'mode':'preview','customers':len(records),'posts':len(notes),'network':False,'send':False},ensure_ascii=False));return 0
    if not args.session_home or not args.sender_uid:raise Halt('执行需明确指定现有独立会话和账号')
    output=Path(args.output).resolve()
    if output.exists():raise Halt('输出目录已存在')
    home=Path(args.session_home).resolve(strict=True)
    contexts=cached_context(home,notes)
    # Required by the existing independent session reader; no browser fallback.
    os.environ['HOME']=str(home);os.environ['USERPROFILE']=str(home)
    sys.path.insert(0,str(ROOT.parent/'xhs-standalone-reply'))
    from standalone_reply import load_independent_cookies
    client=ContextClient(load_independent_cookies(home))
    output.mkdir(parents=True,exist_ok=False)
    try:
        result,bodies=enrich(client,args.sender_uid,records,contexts,args.source_top_level,lambda x:save(output/'partial-context.json',list(x.values())))
        save(output/'ai-input.json',result)
        save(output/'note-context.json',list(bodies.values()))
        state={'status':'completed','customers':len(result),'posts':len(bodies),'send':False}
        save(output/'state.json',state);print(json.dumps(state,ensure_ascii=False));return 0
    except Exception as exc:
        # Only our scrubbed Halt messages are safe. Vendor error messages may
        # contain response data or tokens, so retain their type only.
        reason=str(exc) if isinstance(exc,Halt) else type(exc).__name__
        save(output/'state.json',{'status':'stopped','reason':reason,'send':False})
        print('停止：'+reason,file=sys.stderr);return 2
    finally:client.close()


if __name__=='__main__':
    try:raise SystemExit(main())
    except (Halt,OSError,ValueError) as exc:
        print('停止：'+(str(exc) if isinstance(exc,Halt) else type(exc).__name__),file=sys.stderr);raise SystemExit(2)
