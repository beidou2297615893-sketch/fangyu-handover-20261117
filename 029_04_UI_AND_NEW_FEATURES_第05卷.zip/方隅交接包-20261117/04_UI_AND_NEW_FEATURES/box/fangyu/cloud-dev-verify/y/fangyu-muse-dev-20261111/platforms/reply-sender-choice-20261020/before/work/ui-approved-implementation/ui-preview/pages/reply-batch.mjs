import {sopText,personaChoices} from './management-tone.mjs';
import {prepareReviewedBatch} from './reply-delivery.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scope=s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId,s.activePlatform]);
const match=(s,p)=>p?.actor?.username===s.user&&p?.actor?.storeId===s.storeId;
export function renderBatch(s,v){
  v.batchRole ||= 'employee';
  const ids=v.checkedIds||[],locked=v.busy||v.pending||v.batchBusy||v.batchPending;
  return `<div class="rp-batch-bar"><label><input type="checkbox" data-batch-all ${v.items.length&&v.items.every(p=>ids.includes(p.id))?'checked':''} ${locked?'disabled':''}> 全选本页</label><span>已选 ${ids.length} 位</span><select data-batch-role aria-label="批量 SOP" ${locked?'disabled':''}>${Object.entries(personaChoices).map(([id,label])=>`<option value="${id}" ${v.batchRole===id?'selected':''}>${label}</option>`).join('')}</select><button type="button" class="rp-secondary" data-batch-prepare ${!ids.length||locked?'disabled':''}>${v.batchBusy?'正在准备…':'套用 SOP 并预览'}</button><small>使用管理页 SOP · 每批最多20位 · 保存后仍需确认发送</small>${v.batchPending?'<button type="button" data-batch-check>核对上次草稿操作</button>':''}${v.batchError?`<span role="status">${esc(v.batchError)}</span>`:''}</div>`;
}
export function bindBatch(root,ctx,v){
 const s=ctx.state,origin=scope(s),owns=()=>s.replyLive===v&&scope(s)===origin;
 const locked=()=>v.busy||v.pending||v.batchBusy||v.batchPending;
 const redraw=()=>{if(owns())ctx.update(()=>{});};
 root.querySelector('[data-batch-all]')?.addEventListener('change',e=>{if(locked())return;v.checkedIds=e.target.checked?v.items.map(p=>p.id):[];redraw();});
 root.querySelectorAll('[data-live-check-customer]').forEach(el=>{el.disabled=Boolean(locked());el.addEventListener('change',()=>{if(locked())return;v.checkedIds=el.checked?[...new Set([...(v.checkedIds||[]),el.dataset.liveCheckCustomer])]:(v.checkedIds||[]).filter(id=>id!==el.dataset.liveCheckCustomer);redraw();});});
 root.querySelector('[data-batch-role]')?.addEventListener('change',e=>{if(!locked())v.batchRole=e.target.value;});
 root.querySelector('[data-batch-check]')?.addEventListener('click',async()=>{
   if(!v.batchPending||v.batchBusy)return;const pending={...v.batchPending};v.batchBusy=true;redraw();
   try{const result=await ctx.replyCheck({storeId:s.storeId,...pending});if(!owns())return;const r=result.replyWorkspace;if(!match(s,r)||r.customerId!==pending.customerId)throw Error('操作结果范围已变化。');if(['accepted','observed','not_found','not_applied','rejected','changed'].includes(r.receipt?.state)){v.batchPending=null;v.batchError='已核对原操作，请重新选择并预览；没有自动续发。';}else v.batchError='上次操作仍未确认，请稍后核对。';}
   catch(error){if(owns()){v.batchError=error.message;ctx.replyError(error);}}
   finally{if(owns()){v.batchBusy=false;redraw();}}
 });
 root.querySelector('[data-batch-prepare]')?.addEventListener('click',async()=>{
   if(locked()||v.dirty){ctx.toast('请先保存或放弃当前草稿。');return;}
   const ids=[...new Set(v.checkedIds||[])];if(!ids.length||ids.length>20)return;
   let text;try{if(!match(s,s.tonePreferences))await ctx.readTonePreferences();if(!owns()||!match(s,s.tonePreferences))return;text=sopText(s.tonePreferences,v.batchRole||'employee');}catch(error){ctx.toast(error.message);return;}
   v.batchBusy=true;v.batchError='';redraw();const rows=[],skipped=[];
   try{
     for(const customerId of ids){
       if(!owns())return;const result=await ctx.replyRead({storeId:s.storeId,customerId});if(!owns())return;const d=result.replyWorkspace;
       if(!match(s,d)||d.customerId!==customerId)throw Error('客户范围已变化，请重新读取。');
       const row=d.comments.find(c=>c.canSave&&!c.pendingRequestId&&!['sending','unknown','sent','copied','superseded'].includes(c.draft?.status));
       const account=row?.accounts?.find(a=>a.id===v.accountId)||(row?.accounts?.length===1?row.accounts[0]:null);
       if(!row||!account){skipped.push(d.item.name);continue;}
       rows.push({customerId,leadId:row.id,sourceDigest:row.sourceDigest,expectedVersion:row.draft?.version||0,expectedReplyId:row.draft?.id||'',accountId:account.id,name:d.item.name,accountName:account.name,comment:row.text,text});
     }
     if(!owns())return;
     if(!rows.length){v.batchError='所选客户没有可用的回复账号或可编辑评论。';return;}
     ctx.modal({title:`核对 ${rows.length} 位客户的草稿`,html:`<p>每位客户处理一条评论。${skipped.length?'另有 '+skipped.length+' 位暂不可处理。':''}</p><div class="rp-batch-preview">${rows.map(r=>`<section><h3>${esc(r.name)} · ${esc(r.accountName)}</h3><blockquote>${esc(r.comment)}</blockquote><p>回复正文</p><blockquote>${esc(r.text)}</blockquote></section>`).join('')}</div>`,confirmLabel:'保存并核对这些草稿',onConfirm:async()=>{
       if(!owns()||v.batchBusy||v.batchPending||v.busy||v.pending)return false;
       v.batchBusy=true;redraw();const reviewed=[];
       try{
         for(const item of rows){
           if(!owns())return false;
           const requestId=crypto.randomUUID();v.batchPending={customerId:item.customerId,leadId:item.leadId,requestId};
           const saved=await ctx.replySave({storeId:s.storeId,customerId:item.customerId,leadId:item.leadId,sourceDigest:item.sourceDigest,expectedVersion:item.expectedVersion,expectedReplyId:item.expectedReplyId,text:item.text,requestId});
           if(!owns())return false;
           if(!match(s,saved.replyWorkspace)||saved.replyWorkspace.customerId!==item.customerId){const error=Error('草稿保存结果尚未核对。');error.code='REPLY_RESULT_UNCONFIRMED';throw error;}
           v.batchPending=null;const row=saved.replyWorkspace.comments.find(c=>c.id===item.leadId);
           if(!row||row.draft?.text!==item.text||row.sourceDigest!==item.sourceDigest||!row.canReview)throw Error('草稿或来源已变化，请重新核对。');
           const reviewId=crypto.randomUUID();v.batchPending={customerId:item.customerId,leadId:item.leadId,requestId:reviewId};
           const result=await ctx.replyReview({storeId:s.storeId,customerId:item.customerId,leadId:item.leadId,sourceDigest:row.sourceDigest,expectedVersion:row.draft.version,expectedReplyId:row.draft.id,accountId:item.accountId,confirmed:true,requestId:reviewId});
           if(!owns())return false;
           if(!match(s,result.replyWorkspace)||result.replyWorkspace.customerId!==item.customerId){const error=Error('审核结果尚未核对。');error.code='REPLY_RESULT_UNCONFIRMED';throw error;}
           v.batchPending=null;const checked=result.replyWorkspace.comments.find(c=>c.id===item.leadId);
           if(!checked?.reviewCurrent||checked.draft?.text!==item.text||checked.draft.review_account_id!==item.accountId)throw Error('回复尚未完整核对。');
           reviewed.push({...item,replyId:checked.draft.id,version:checked.draft.version,sourceDigest:checked.sourceDigest});
         }
         v.checkedIds=[];v.detail=null;v.batchBusy=false;
         return await prepareReviewedBatch(s,ctx,v,reviewed);
       }catch(error){if(owns()){if(!['RESULT_UNCONFIRMED','REPLY_RESULT_UNCONFIRMED','timeout','connection_failed'].includes(error.code))v.batchPending=null;v.batchError=error.message;ctx.replyError(error);}return false;}
       finally{if(owns()){v.batchBusy=false;redraw();}}
     }});
   }catch(error){if(owns()){v.batchError=error.message;ctx.replyError(error);}}
   finally{if(owns()){v.batchBusy=false;redraw();}}
 });
}
