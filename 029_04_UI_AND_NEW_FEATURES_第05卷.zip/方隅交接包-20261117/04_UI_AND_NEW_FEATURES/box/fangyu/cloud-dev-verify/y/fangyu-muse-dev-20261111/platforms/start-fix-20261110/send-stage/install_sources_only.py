from pathlib import Path
import hashlib, json, msvcrt, os, shutil, subprocess, tempfile
base=Path.cwd().resolve()
source=base/'work/start-fix-20261110/send-stage'
dest=base/'work/douyin-local-control'
backup=source.parent/'send-source-before'
names=["control.py","page_guard.cjs","target_reader.cjs","account_probe.cjs","unknown_resolution.py","attempt_recovery.py","panel.py","test_employee_resume.py","test_send_resume_runner.py","test_page_guard.cjs","startup_recovery.py"]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def running_sender():
    command="""$ErrorActionPreference='Stop'; @(Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" | Where-Object {$_.CommandLine -match '(?i)(?:^|[\\\\/\\s"])control\\.py(?:[\\s"]|$)|(?:^|[\\\\/\\s"])batch_reply_runner\\.py(?:[\\s"]|$)'}).Count"""
    return int(subprocess.check_output(['powershell.exe','-NoProfile','-Command',command],encoding='ascii').strip())
def replace(path,payload):
    fd,name=tempfile.mkstemp(prefix='.employee-resume-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as out: out.write(payload)
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)
assert running_sender()==0, 'A live sender exists; no install.'
for n in names:
    p=source/n
    if n.endswith('.py'):compile(p.read_text(encoding='utf-8-sig'),str(p),'exec')
    else:subprocess.run(['node','--check',str(p)],check=True)
backup.mkdir(exist_ok=False)
with (dest/'control.lock').open('r+b') as lock:
    lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    try:
        assert running_sender()==0, 'A live sender exists; no install.'
        for n in names:
            if (dest/n).exists(): shutil.copy2(dest/n,backup/n)
        # The first replacement gates the old daemon, and version readiness goes in last.
        for n in names:
            replace(dest/n,(source/n).read_bytes())
            assert digest(dest/n)==digest(source/n)
    finally:
        lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
print('Installed source only under controller lock.', len(names),'files.')
