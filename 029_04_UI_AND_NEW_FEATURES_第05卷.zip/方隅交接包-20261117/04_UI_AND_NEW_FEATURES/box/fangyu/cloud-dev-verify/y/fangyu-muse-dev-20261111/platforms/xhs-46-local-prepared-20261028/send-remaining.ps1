$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统'
$sessionHome = Join-Path $taskRoot 'work\xhs-standalone-session\cli-login-20261028-165417'
$runtime = Join-Path $taskRoot 'work\vendor\cli-runtime\Scripts\python.exe'
$sender = Join-Path $taskRoot 'work\xhs-local-ledger-sender-candidate\production_sender.py'
$batchPath = Join-Path $taskRoot 'work\xhs-46-local-prepared-20261028\gubei-46-plan.json'
$planDir = Join-Path $taskRoot 'work\xhs-46-local-prepared-20261028\frozen-plans'
$env:HOME = $sessionHome
$env:USERPROFILE = $sessionHome
New-Item -ItemType Directory -Path $planDir -ErrorAction SilentlyContinue | Out-Null
$batch = Get-Content -LiteralPath $batchPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($batch.count -ne 46 -or @($batch.rows).Count -ne 46) { throw 'Batch count changed' }
foreach ($row in $batch.rows) {
    if ($row.sequence -eq 5) { continue }
    $plan = [ordered]@{
        sender_uid = '5aa9b337e8ac2b4ab2d21957'
        customer_uid = $row.customer_uid
        note_id = $row.note_id
        comment_id = $row.comment_id
        text = $row.text
        attempt_id = $row.attempt_id
        authorized = $true
        verification_evidence = 'Local source mapping and customer projection; platform replies and other accounts unknown'
        valid_until = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() + 240
        source = 'gubei-46-local-plan-v1'
        canonical_customer = $row.customer_id
    }
    $planPath = Join-Path $planDir ('reply-' + $row.sequence + '.json')
    $stream = [System.IO.File]::Open($planPath, [System.IO.FileMode]::CreateNew)
    try {
        $writer = [System.IO.StreamWriter]::new($stream, [System.Text.UTF8Encoding]::new($false))
        try { $writer.Write(($plan | ConvertTo-Json -Depth 5)) } finally { $writer.Dispose() }
    } finally { $stream.Dispose() }
    $response = & $runtime -X utf8 $sender --plan $planPath --session-home $sessionHome --execute 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Output ('STOP sequence=' + $row.sequence + ' ' + ($response -join ' '))
        exit 1
    }
    try { $parsed = ($response -join "`n") | ConvertFrom-Json } catch { Write-Output ('STOP sequence=' + $row.sequence + ' invalid response'); exit 1 }
    if ($parsed.result -ne 'receipt_received_unverified') { Write-Output ('STOP sequence=' + $row.sequence + ' unexpected result'); exit 1 }
    Write-Output ('accepted sequence=' + $row.sequence)
    Start-Sleep -Seconds 2
}
Write-Output 'BATCH_FINISHED'
