"""Explicit, bounded queue execution for an existing independent XHS session.

Preview is default. There is no login, send, verification solver or retry.
"""
import argparse
from contextlib import closing, redirect_stdout
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import sys

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
RECOVERY=PROJECT/'work/xhs-account-switch-recovery-candidate'
SCHEDULER=PROJECT/'work/xhs-safe-batch-scheduler-20261029/scheduler.py'

def now(): return datetime.now(timezone.utc).isoformat()

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write_new(path,value):
    with Path(path).open('x',encoding='utf8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.flush(); os.fsync(stream.fileno())

def append(path,value):
    with Path(path).open('a',encoding='utf8') as stream:
        stream.write(json.dumps(value,ensure_ascii=False)+'\n')
        stream.flush(); os.fsync(stream.fileno())

def components():
    lock=read(HERE/'dependency-lock.json')
    for relative,digest in lock.items():
        if hashlib.sha256((PROJECT/relative).read_bytes()).hexdigest()!=digest:
            raise ValueError('dependency_changed_review_required')
    sys.dont_write_bytecode=True
    sys.path.insert(0,str(RECOVERY))
    for name in ('account_switch','collect_once'):
        if name in sys.modules and Path(sys.modules[name].__file__).resolve()!=RECOVERY/(name+'.py'):
            raise ValueError('dependency_module_collision')
    candidate=importlib.import_module('account_switch')
    once=importlib.import_module('collect_once')
    spec=importlib.util.spec_from_file_location('xhs_live_scheduler',SCHEDULER)
    scheduling=importlib.util.module_from_spec(spec); spec.loader.exec_module(scheduling)
    return candidate,once,scheduling

def search_without_recommend(client, keyword, page=1, page_size=20, sort='general', note_type=0):
    """Keep installed search preparation/parameters; omit optional recommendation.

    No response failure is swallowed beyond the installed prewarm contract.
    ReadClient converts every unsafe or unknown prewarm/API error into Halt.
    """
    import xhs_cli.client_mixins as mixins
    from xhs_cli.exceptions import XhsApiError
    search_id,is_new_session=mixins._acquire_search_session(keyword,sort,note_type)
    if is_new_session:
        request_id=client._search_request_id()
        try:
            client._main_api_post('/api/sns/web/v1/search/onebox',{
                'keyword':keyword,'search_id':search_id,'biz_type':'web_search_user','request_id':request_id})
            client._main_api_get('/api/sns/web/v1/search/filter',{'keyword':keyword,'search_id':search_id})
        except XhsApiError:
            # Exactly the upstream optional prewarm contract. Hardened ReadClient
            # only leaves its narrowly allowed empty code-zero placeholder here.
            pass
    return client._main_api_post('/api/sns/web/v1/search/notes',{
        'keyword':keyword,'page':page,'page_size':page_size,'search_id':search_id,
        'sort':sort,'note_type':note_type,'ext_flags':[],
        'filters':mixins._SEARCH_DEFAULT_FILTERS,'geo':'','image_formats':['jpg','webp','avif']})

def addressable_search_page(value):
    """Keep addressable note cards, without business/ad-label filtering."""
    if not isinstance(value,dict) or not isinstance(value.get('items'),list):
        raise ValueError('search_response_shape_invalid')
    def id_pattern(item):
        if item is None or item=='': return 'missing'
        if not isinstance(item,str): return 'invalid_type'
        if re.fullmatch(r'[0-9a-fA-F]{24}',item): return '24hex'
        if re.fullmatch(r'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}#[0-9]+',item): return 'uuid_timestamp'
        return 'other'
    def tally(table,key): table[key]=table.get(key,0)+1
    retained=[]; note_ids=set()
    evidence={'shape_valid':True,'raw_items':len(value['items']),'discarded_items':0,
        'discard_reasons':{},'card_types':{},'discarded_card_types':{},'raw_id_patterns':{},
        'note_id_sources':{},'ambiguous_items':0}
    for raw in value['items']:
        model=raw.get('model_type') if isinstance(raw,dict) else None
        kind=model if model in ('note','ad','user','recommend','recommendation','hot_query','query') else ('missing' if model is None else 'other')
        tally(evidence['card_types'],kind)
        raw_id=raw.get('id') if isinstance(raw,dict) else None
        tally(evidence['raw_id_patterns'],id_pattern(raw_id))
        reason=None
        if not isinstance(raw,dict): reason='not_object'
        elif not isinstance(raw.get('note_card'),dict): reason='not_note_card'
        else:
            card_id=raw['note_card'].get('note_id')
            item_valid=id_pattern(raw_id)=='24hex'; card_valid=id_pattern(card_id)=='24hex'
            if item_valid and card_valid and raw_id.lower()!=card_id.lower():
                reason='conflicting_note_ids'; evidence['ambiguous_items']+=1
            elif item_valid or card_valid:
                note_id=(raw_id if item_valid else card_id).lower()
                retained.append({**raw,'id':note_id}); note_ids.add(note_id)
                tally(evidence['note_id_sources'],'item_id' if item_valid else 'note_card_note_id')
            else: reason='no_addressable_note_id'
        if reason:
            evidence['discarded_items']+=1
            tally(evidence['discard_reasons'],reason); tally(evidence['discarded_card_types'],kind)
    evidence['valid_notes']=len(note_ids); evidence['note_ids']=sorted(note_ids)
    evidence['validation_basis']='24hex_id_and_note_card_shape_only'
    return {**value,'items':retained},evidence
def make_plan(schedule, state):
    if state.get('status')!='stopped' or state.get('keyword')!='古北找房' or state.get('search_page')!=5 or state.get('batch')!=19:
        raise ValueError('resume_checkpoint_changed_review_required')
    tasks=schedule.get('tasks')
    if not isinstance(tasks,list): raise ValueError('explicit_saved_queue_required')
    result=[]; found=False
    for task in tasks:
        if not found:
            if task.get('keyword')!=state['keyword']: continue
            found=True
        keyword=task.get('keyword'); first=task.get('first_page'); last=task.get('last_page')
        if keyword not in ('古北找房','古北求租','古北租房') or type(first) is not int or type(last) is not int or not 1<=first<=last<=100:
            raise ValueError('saved_queue_invalid')
        first=max(first,state['search_page']) if keyword==state['keyword'] else first
        result.extend({'keyword':keyword,'page':page} for page in range(first,last+1))
    if not result or len({(x['keyword'],x['page']) for x in result})!=len(result):
        raise ValueError('saved_queue_invalid')
    return result

class ObservedClient:
    def __init__(self,client,root,batch,keyword,page,collector):
        self.client=client; self.root=root; self.batch=batch
        self.keyword=keyword; self.page=page; self.collector=collector
    @property
    def cookies(self): return self.client.cookies
    @property
    def last_failure_detail(self): return getattr(self.client,'last_failure_detail',None)
    def _independent_session_guard(self):
        guard=getattr(self.client,'_independent_session_guard',None)
        if guard is not None: guard()
    def get_self_info(self): return self.client.get_self_info()
    def get_comments(self,*args,**kwargs): return self.client.get_comments(*args,**kwargs)
    def close(self): self.client.close()
    def search_notes(self,**kwargs):
        raw=search_without_recommend(self.client,**kwargs)
        try:
            value,counts=addressable_search_page(raw)
        except ValueError:
            write_new(self.root/f'search-evidence-{self.batch}.json',{'at':now(),'batch':self.batch,
                'keyword':self.keyword,'page':self.page,'shape_valid':False,
                'reason':'search_response_shape_invalid'})
            raise
        evidence={'at':now(),'batch':self.batch,'keyword':self.keyword,'page':self.page,**counts,
            'has_more':value.get('has_more') if type(value.get('has_more')) is bool else None,
            'interpretation':'one_observed_search_page_not_keyword_exhaustion'}
        write_new(self.root/f'search-evidence-{self.batch}.json',evidence)
        if counts['ambiguous_items']: raise ValueError('search_note_identity_conflict')
        if counts['valid_notes']>20: raise ValueError('search_page_overflow_local_review_required')
        return value

def comment_rows(customers):
    if not isinstance(customers,list): raise ValueError('analysis_rows_invalid')
    result={}
    for customer in customers:
        for comment in [customer,*customer.get('other_comments',[])]:
            key=(customer.get('customer_id'),comment.get('comment_id'))
            if not all(isinstance(v,str) and v for v in key) or key in result:
                raise ValueError('analysis_comment_invalid')
            result[key]=(customer.get('customer_uid'),comment.get('note_id'),comment.get('comment_text'),
                comment.get('published_at'),comment.get('ip_location'))
    return result

class LiveExecutor:
    def __init__(self,root,config,candidate,once,client_factory):
        self.root=root; self.config=config; self.candidate=candidate; self.once=once
        self.client_factory=client_factory or once.create_client
    def run(self,batch,keyword,page,remaining):
        collector,_=self.candidate.dependencies()
        def factory(home,cache):
            return ObservedClient(self.client_factory(home,cache),self.root,batch,keyword,page,collector)
        argv=['--workspace',str(self.root),'--batch',batch,'--keyword',keyword,'--search-page',str(page),
            '--session-home',self.config['session_home'],'--ledger',self.config['ledger'],
            '--source-db',self.config['source_db'],'--task',self.config['task'],
            '--max-notes','20','--max-pages',str(self.config['max_comment_pages']),'--execute']
        if self.config['shared_ledger']: argv.append('--apply-to-shared-ledger')
        if self.config['operator']: argv.extend(['--operator',self.config['operator']])
        with redirect_stdout(io.StringIO()): self.once.main(argv,client_factory=factory)
        folder=self.root/batch
        binding=read(folder/'account-binding.json'); receipt=read(folder/'register-result.json')
        ready=read(folder/'registered-ready.json'); collection=read(folder/'collection.json')
        selected=read(folder/'new-ai-input.json')
        count=receipt.get('result',{}).get('inserted')
        if (type(count) is not int or count<0 or binding.get('guest') is not False
            or receipt.get('account')!=binding or collection.get('collection_account')!=binding
            or ready.get('registered') is not True or ready.get('account_uid')!=binding['uid']
            or ready.get('inserted_comments')!=count or ready.get('input')!='new-ai-input.json'):
            raise ValueError('registration_evidence_conflict')
        original=comment_rows(collection['customers']); analysis=comment_rows(selected)
        source='collection:'+str((folder/'collection.json').resolve(strict=True))
        ledger=Path(self.config['ledger'])
        with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
            rows=db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchall()
        if (len(rows)!=len(set(rows)) or len(rows)!=count or set(rows)!=set(analysis)
            or any(key not in original or analysis[key]!=original[key] for key in analysis)):
            raise ValueError('registration_ledger_analysis_conflict')
        append(self.root/'analysis-manifest.jsonl',{'at':now(),'batch':batch,'keyword':keyword,'page':page,
            'account_uid':binding['uid'],'operator':self.config['operator'] or 'unknown',
            'inserted_comments':count,'input':f'{batch}/new-ai-input.json',
            'sha256':hashlib.sha256((folder/'new-ai-input.json').read_bytes()).hexdigest(),
            'registration_source':source,'status':'registered_ready_for_classification',
            'rule_source':'user_new_10000_resume_2026-10-29'})
        return {'status':'registered','inserted':count,'analysis_input':f'{batch}/new-ai-input.json'}

def run_task(root,plan,*,session_home,ledger,source_db,target=10000,first_batch=20,
             client_factory=None,shared_ledger=False,resume=False,max_comment_pages=2,operator=None):
    candidate,once,scheduling=components()
    root=Path(root).resolve(strict=True); runtime=(RECOVERY/'runtime').resolve(strict=True)
    if root==runtime or not root.is_relative_to(runtime): raise ValueError('candidate_runtime_workspace_required')
    ledger=Path(ledger).resolve(strict=True); source_db=Path(source_db).resolve(strict=True)
    if not ledger.is_relative_to(root) and not (shared_ledger is True and ledger==candidate.REAL_LEDGER.resolve()):
        raise ValueError('explicit_shared_ledger_opt_in_required')
    if type(max_comment_pages) is not int or not 1<=max_comment_pages<=20:
        raise ValueError('bounded_comment_pages_required')
    config={'version':1,'plan':plan,'session_home':str(Path(session_home).resolve()),'ledger':str(ledger),
        'source_db':str(source_db),'target':target,'first_batch':first_batch,
        'shared_ledger':shared_ledger,'max_notes':20,'max_comment_pages':max_comment_pages,'operator':operator,
        'task':'古北本次新增一万条评论采集','count_basis':'new_registered_unique_comments_since_this_resume'}
    if resume:
        if read(root/'task-config.json')!=config: raise ValueError('resume_config_changed')
    else:
        write_new(root/'task-config.json',config)
        scheduling.initialize(root,plan,first_batch=first_batch,target=target)
    result=scheduling.run(root,LiveExecutor(root,config,candidate,once,client_factory))
    append(root/'run-receipts.jsonl',{'at':now(),'status':result['status'],'inserted':result.get('inserted',0),
        'target':target,'inflight':result.get('inflight'),'automatic_retry':False})
    return result

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-home',required=True)
    parser.add_argument('--session-home',required=True)
    parser.add_argument('--ledger',default=str(PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'))
    parser.add_argument('--source-db',default=str(PROJECT/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'))
    parser.add_argument('--max-comment-pages',type=int,default=2)
    parser.add_argument('--first-batch',type=int,default=20)
    parser.add_argument('--operator')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--apply-to-shared-ledger',action='store_true')
    args=parser.parse_args(argv)
    schedule=read(PROJECT/'work/xhs-standalone-session/collection-live/related-schedule.json')
    checkpoint=read(PROJECT/'work/xhs-standalone-session/collection-live/state.json')
    plan=make_plan(schedule,checkpoint)
    if not args.execute:
        if args.first_batch<20: raise ValueError('new_batch_number_required')
        print(json.dumps({'mode':'preview','first_batch':f'batch-{args.first_batch:04d}','target':10000,'plan':plan,
            'network':False,'ledger_write':False,'send':False},ensure_ascii=False)); return 0
    if not args.apply_to_shared_ledger: raise ValueError('explicit_shared_ledger_opt_in_required')
    if args.first_batch<20: raise ValueError('new_batch_number_required')
    root=Path(args.run_home).resolve()
    runtime=(RECOVERY/'runtime').resolve(strict=True)
    if root==runtime or not root.is_relative_to(runtime): raise ValueError('candidate_runtime_workspace_required')
    if not args.resume: root.mkdir(exist_ok=False)
    result=run_task(root,plan,session_home=args.session_home,ledger=args.ledger,source_db=args.source_db,
        shared_ledger=True,resume=args.resume,max_comment_pages=args.max_comment_pages,operator=args.operator,
        first_batch=args.first_batch)
    print(json.dumps({'status':result['status'],'inserted':result.get('inserted',0),'target':10000,
        'analysis_manifest':str(root/'analysis-manifest.jsonl'),'automatic_retry':False},ensure_ascii=False))
    return 0 if result['status'] in ('target_reached','paused','plan_exhausted') else 2

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception:
        print(json.dumps({'status':'stopped','reason':'inspect_local_receipts','automatic_retry':False}),file=sys.stderr)
        raise SystemExit(2) from None
