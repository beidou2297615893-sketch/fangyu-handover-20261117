"""Isolated tests for the single-attempt, explicit-local-history sender."""
import json
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from contextlib import closing
from unittest.mock import patch
import httpx
import xhs_cli.client as vendor

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'xhs-standalone-reply'))
import standalone_reply
import frozen_sender


class FakeClient:
    def __init__(self, plan, result=None, error=None):
        self.plan, self.result, self.error = plan, result, error
        self.identities = self.calls = 0
        self._armed = False
    def identity(self):
        self.identities += 1
    def send_once(self):
        if not self._armed: raise AssertionError('client was not armed')
        self.calls += 1
        if self.error: raise self.error
        return self.result


class FrozenSenderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.db = Path(self.tmp.name) / 'synthetic.sqlite3'
        p = subprocess.run([sys.executable, str(ROOT.parent/'shared-acquisition-ledger'/'ledger.py'), '--db', str(self.db), 'init'], capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)', ('xiaohongshu','uid','comment','unverified','fixture'))
            db.execute('INSERT INTO identity_aliases VALUES(?,?,?,?,?)', ('xiaohongshu','uid','uid','fixture identity',int(time.time())))
            db.commit()
        self.plan = standalone_reply.FrozenReply('sender','uid','note','comment','reply','attempt',True,'fixture evidence',int(time.time())+200,'fixture source')

    def tearDown(self): self.tmp.cleanup()

    def test_exact_plan_authorized_identity_and_receipt_recorded_without_visible_claim(self):
        client = FakeClient(self.plan, {'comment':{'id':'fixture_receipt'}})
        result = frozen_sender.Runner(self.db, client).submit(self.plan)
        self.assertEqual(result, 'receipt_received_unverified')
        self.assertEqual((client.identities,client.calls), (1,1))
        with closing(sqlite3.connect(self.db)) as db:
            status, evidence = db.execute('SELECT status,evidence FROM reservations').fetchone()
            data = json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])
        self.assertEqual(status, 'unknown')
        self.assertIn('fixture_receipt', evidence)
        self.assertFalse(data['local_mode']['platform_replies_checked'])
        self.assertTrue(data['local_mode']['plan']['authorized'])
        self.assertEqual(data['local_mode']['plan']['text'], 'reply')

    def test_bad_auth_and_client_plan_mismatch_refuse_before_send(self):
        from dataclasses import replace
        for plan, client_plan in [(replace(self.plan,authorized=False),self.plan), (self.plan,replace(self.plan,text='other'))]:
            client = FakeClient(client_plan)
            with self.assertRaises(Exception): frozen_sender.Runner(self.db, client).submit(plan)
            self.assertEqual(client.calls, 0)

    def test_error_or_461_stops_one_attempt_and_prevents_repeat(self):
        client = FakeClient(self.plan, error=standalone_reply.Unknown('HTTP 461'))
        with self.assertRaises(standalone_reply.Unknown): frozen_sender.Runner(self.db,client).submit(self.plan)
        with self.assertRaises(Exception): frozen_sender.Runner(self.db,client).submit(self.plan)
        self.assertEqual(client.calls,1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM reservations').fetchone()[0],'unknown')

    def test_absent_receipt_is_unknown_and_halts(self):
        client=FakeClient(self.plan,result={})
        with self.assertRaises(standalone_reply.Unknown): frozen_sender.Runner(self.db,client).submit(self.plan)
        self.assertEqual(client.calls,1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM reservations').fetchone()[0],'unknown')

    def test_vendor_wire_461_stops_after_one_post(self):
        calls = []
        def wire(req):
            calls.append(req)
            if req.method == 'GET':
                return httpx.Response(200, json={'success':True,'data':{'user_id':'sender'}})
            return httpx.Response(461, json={'success':False})
        client=standalone_reply.ControlledClient({'a1':'synthetic'},self.plan,httpx.MockTransport(wire))
        try:
            with patch('socket.socket.connect', side_effect=AssertionError('network forbidden')), patch.object(vendor,'sign_main_api',return_value={}):
                with self.assertRaises(standalone_reply.Unknown): frozen_sender.Runner(self.db,client).submit(self.plan)
                with self.assertRaises(Exception): frozen_sender.Runner(self.db,client).submit(self.plan)
            self.assertEqual([req.method for req in calls], ['GET','POST'])
            self.assertEqual(json.loads(calls[1].content), {'note_id':'note','content':'reply','target_comment_id':'comment','at_users':[]})
        finally:
            client.close()

    def test_vendor_wire_receipt_is_preserved_without_claiming_visibility(self):
        calls = []
        def wire(req):
            calls.append(req)
            if req.method == 'GET':
                return httpx.Response(200, json={'success':True,'data':{'user_id':'sender'}})
            return httpx.Response(200, json={'success':True,'data':{'comment':{'id':'vendor_receipt'}}})
        client=standalone_reply.ControlledClient({'a1':'synthetic'},self.plan,httpx.MockTransport(wire))
        try:
            with patch('socket.socket.connect', side_effect=AssertionError('network forbidden')), patch.object(vendor,'sign_main_api',return_value={}):
                self.assertEqual(frozen_sender.Runner(self.db,client).submit(self.plan),'receipt_received_unverified')
            self.assertEqual([req.method for req in calls], ['GET','POST'])
            with closing(sqlite3.connect(self.db)) as db:
                status, evidence = db.execute('SELECT status,evidence FROM reservations').fetchone()
            self.assertEqual(status,'unknown')
            self.assertIn('vendor_receipt',evidence)
        finally:
            client.close()

if __name__ == '__main__': unittest.main()
