import json
import sqlite3
import unittest

import uid_guard

class GuardTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:',isolation_level=None)
        self.db.executescript('CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT); CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT); CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT);')

    def tearDown(self):self.db.close()

    def add(self,uid,canonical,comment,status='unknown',kind='platform_receipt'):
        token='t'+str(self.db.execute('SELECT COUNT(*) FROM reservations').fetchone()[0])
        self.db.execute('INSERT INTO reservations VALUES(?,?,?,?,?)',(token,'xiaohongshu',canonical,comment,status))
        self.db.execute('INSERT INTO local_sender_plans VALUES(?,?)',(token,json.dumps({'plan':{'customer_uid':uid},'result':{'kind':kind}})))

    def test_same_platform_user_with_changed_canonical_is_blocked(self):
        self.add('uid1','old','old-comment')
        self.db.execute('BEGIN IMMEDIATE')
        with self.assertRaises(uid_guard.Blocked):uid_guard.check_in_transaction(self.db,'xiaohongshu','uid1','new','new-comment')
        self.db.rollback()

    def test_same_comment_even_different_id_is_blocked(self):
        self.add('uid1','old','comment1')
        self.db.execute('BEGIN IMMEDIATE')
        with self.assertRaises(uid_guard.Blocked):uid_guard.check_in_transaction(self.db,'xiaohongshu','uid2','new','comment1')
        self.db.rollback()

    def test_legacy_missing_identity_must_not_be_assumed_clear(self):
        self.db.execute("INSERT INTO reservations VALUES('t','xiaohongshu','x','old','unknown')")
        self.db.execute('BEGIN IMMEDIATE')
        with self.assertRaises(uid_guard.Blocked):uid_guard.check_in_transaction(self.db,'xiaohongshu','new','new','new')
        self.db.rollback()

    def test_must_be_in_write_transaction(self):
        with self.assertRaises(uid_guard.Blocked):uid_guard.check_in_transaction(self.db,'xiaohongshu','uid','local','comment')

    def test_other_platform_does_not_block_and_new_user_allowed(self):
        self.db.execute("INSERT INTO reservations VALUES('t','douyin','x','c','unknown')")
        self.db.execute('BEGIN IMMEDIATE')
        uid_guard.check_in_transaction(self.db,'xiaohongshu','uid','local','comment')
        self.db.rollback()

if __name__=='__main__':unittest.main()
