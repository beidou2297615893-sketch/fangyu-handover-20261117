# 小红书评论回复通知接续

本模块读取指定已保存账号的“评论和 @”通知，与共享账本的真实发送回执对应，生成待跟进列表。不会发评论、发私信、标记跟进完成、修改共享账本、重新登录或保存会话。读取通知接口是否影响平台自身未读标记尚未验证；程序不调用任何独立标记已读接口。

## 真实能力与边界

- 只允许两种 GET：`/api/sns/web/v2/user/me`、`/api/sns/web/v1/you/mentions`，必须先核验显式指定 UID。没有浏览器、其他账号或 HOME 回退。
- 复用本地已安装小红书 CLI 签名方法，以及已审核 managed_session 的会话完整性检查。任何响应 Cookie 变化均停止，不写回。
- HTTP 非 200、HTTP 200 验证头、业务未成功、身份变化、结构异常均停止，不自动重试。进程发生读取故障后不会在下一周期恢复请求。
- 必须以 `comment_info.target_comment.id` 等明确回复目标等于共享账本 `platform_receipt.receipt_id` 进行关联，绝不按同笔记猜关联。目标作者 UID 若存在必须等于当前账号；笔记 ID 若存在必须一致。
- 真实通知结构 `user_info.userid`、`item_info.type=note_info`、`comment_info.target_comment` 已接入。原客户/其他参与者/身份未知分开标注，不能凭昵称认定同行。
- “可能拒绝联系”“可能已找到房”为本地字面提示，保留原话，需要人工判断；不会据此自动回复或修改客户状态。
- 收到回复的通知说明出现了相关互动，并不等于全部已发送评论均公开可见，更不是私信已读。此模块不读取私信。

## 一次同步

在项目目录执行，使用本项目 Python：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 'work/xhs-reply-inbox/inbox.py' `
  --session 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/huihuijiang-send-20261101-01/.xiaohongshu-cli/cookies.json' `
  --ledger 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/shared.sqlite3' `
  --uid '5f469df5000000000101ec0b' `
  --output 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-reply-inbox/runtime/huihuijiang' `
  --max-pages 5
```

`--watch --interval 300` 开启每五分钟同步。只有本轮读到明确末尾才进入等待；达到页数上限或无法确认末尾时标记部分完成并退出，`checkpoint.json` 保留下一页，重新运行同目录从断点继续。读取完整轮次后清空断点，下一轮从最新通知开始。页数允许 1–20，间隔不能低于 60 秒。不能把部分完成称全部读尽。

持续接收最新回复推荐加 `--recent-only --watch --interval 300`：每轮从头页开始，最多读 `--max-pages` 页；遇到整页已存在通知可结束本轮。达到上限也只表示“本轮最新窗口已读取”，`coverage_scope=recent_window`、`history_complete=false`，不是全部历史已读完。此模式不读取、不覆盖历史 `checkpoint.json`。平台异常、身份/会话变化、验证或结构无法确认仍会停止，绝不把错误当窗口完成。

可加 `--publish-dir 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/outputs/小红书评论回复跟进/慧慧酱'`，每轮原子发布 `progress.html` 和两份中文 CSV。技术 JSON、SQLite、日志、断点仍只放运行目录。页面按平台通知时间倒序，优先显示精确关联回复，其他通知折叠显示。

打开输出目录的 `progress.html` 查看自动刷新进度；该页面是本地静态文件。关闭页面不会停止进程。需要停止时，在输出目录创建名为 `STOP` 的文件；再次运行前须明确恢复并移除该停止文件。模块按 UID 在自身目录加排他锁，防不同输出目录重复启动。崩溃遗留锁必须确认无进程后由操作者处理，不自动删锁。

## 给软件窗口的消费接口

所有文件只在指定输出目录，本模块不改已有生产数据：

| 文件 | 用途 |
|---|---|
| `status.json` | 本轮状态、结束原因、页数、新增数、累计关联数、更新时间、`coverage_scope`、`history_complete`；`complete` 在 recent-only 模式仅指最新窗口处理完成 |
| `followups.json` | 精确匹配发送回执的待人工跟进通知 |
| `notifications.json` | 所有读取到的通知，包括待确认关联项 |
| `待跟进通知.csv` | 已关联项，中文列和北京时间 |
| `待确认关联通知.csv` | 尚不能确定与发送记录关系的通知 |
| `inbox.sqlite3` | 本模块独立持久去重库，`notifications.key` 为账号+通知 ID 的 SHA256（无 ID 时为固定投影指纹） |
| `runs.jsonl` | 每轮统计与停止原因，不存原始响应 |
| `checkpoint.json` | 读取分页游标，非登录凭据 |
| `latest-shape.json` / `schema-review.json` | 只保存字段结构、类型，不保存任意字段内容 |

通知字段：`notification_key`、`account_uid`、`notification_id`、`received_at`、`user_uid`、`nickname`、`reply_text`、`note_id`、`incoming_comment_id`、`association`、`matched_sent_reply_id`、`original_comment_id`、`original_customer_id`、`our_reply_text`、`actor_relation`、`review_flags`、`followup_status`、`observed_at`、`field_projection`。

`association=exact_reply_id` 才能展示为已关联。`unmatched` 不等于无效通知；应保留待确认。`actor_relation=other_participant` 不等于同行。`followup_status=pending_review` 不代表可自动发送；软件可在自己的状态层记录人工处理结果，不应直接覆盖本模块快照。

JSON、CSV、HTML采用临时文件原子替换；SQLite事务去重。共享账本以只读模式打开。输出仅固定字段投影，不存原始 Cookie、Token、签名、响应头、头像链接、带访问参数的原帖链接。未知结构不会被当成空列表成功；无法解析条目仍以未知通知保留。

## 离线验证

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest discover -s work/xhs-reply-inbox -p test_inbox.py -v
```

12 项测试通过：真实层级精确关联、同笔记不误关联、目标 UID/笔记错配拒绝、通知去重/未知保留、分页断点/HTML转义、结构变化停机、共享账本字节不变、POST硬拒绝/验证头单次停机，以及最新窗口头页与断点隔离、最新窗口异常停机、真实拒绝/已租提示正负例、只发布三份人读输出。测试使用合成数据和 MockTransport，无真实平台请求。

父任务执行真实读取验收；本实现子任务没有发起网络请求或改动旧生产文件。真实运行结果以指定输出目录状态和列表为准。
