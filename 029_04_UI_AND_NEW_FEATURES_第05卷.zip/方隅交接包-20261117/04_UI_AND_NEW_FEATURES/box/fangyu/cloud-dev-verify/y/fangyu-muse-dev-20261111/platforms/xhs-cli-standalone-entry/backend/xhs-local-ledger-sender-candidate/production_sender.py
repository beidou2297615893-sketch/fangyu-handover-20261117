"""One-attempt local-history sender. Preview is default; never retries a POST.

The live ledger must first receive the separately reviewed additive migration.
Platform reply history and other accounts remain unknown, not checked. A returned
comment ID is an acceptance receipt, not proof of public visibility.
"""
from contextlib import closing
from dataclasses import asdict, dataclass
import argparse
import hashlib
import json
import re
from pathlib import Path
import sqlite3
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'xhs-standalone-reply'))
from standalone_reply import AccountLock, ControlledClient, FrozenReply, Refused, Unknown, load_independent_cookies
from migration_candidate import REAL_LEDGER
from xhs_cli.exceptions import XhsApiError
_scoped_dir=str(Path(__file__).resolve().parents[4]/'work/xhs-send-current-20261029')
if _scoped_dir not in sys.path:sys.path.insert(0,_scoped_dir)
from scoped_isolation import ScopedUnknownIsolationPolicy,ReceiptQualifiedIsolationPolicy,known_restriction
from tone_singleton import TwoUnknownToneSingletonPolicy
from tone_batch import NewToneBatchReceiptPolicy
from target_isolation import AuthorizedTargetIsolationPolicy

PREPARED_BATCH=ROOT.parent/'xhs-46-local-prepared-20261028'/'gubei-46-plan.json'
SOURCE_FILES={
 'mapping': ROOT.parent/'xhs-identity-audit'/'mapping-20261028-154115.json',
 'inputs': ROOT.parent/'cli-independent-20261027'/'followup-analysis-input.jsonl',
 'snapshot': ROOT.parent/'xhs-high-intent-157'/'priority-snapshot-20261028-173048.json',
 'preview': ROOT.parent.parent/'outputs'/'古北高意向回复预览'/'46位客户原话与拟回复.txt',
}

# This is one reviewed historical record, never a general ignore-unknown switch.
LEGACY_APPROVED_BATCH_SHA256='10cf9aed2567d50f0cae842e2be035a30bf82b11fb74b6c45870305b98bdbfa2'
LEGACY_RECORD_RAW_SHA256='8210ec95a5b8d80de5d947ab162e128f86bdfd6ff9654b518495bccc814df7ac'
LEGACY_SENDER_UID='5aa9b337e8ac2b4ab2d21957'
LEGACY_ATTEMPT_ID='b1fe75b7-4d87-5f19-bd5f-e1a51dbef7cb'


@dataclass(frozen=True)
class LegacyAccountGuardPolicy:
    schema: str
    policy_id: str
    sender_uid: str
    batch_sha256: str
    legacy_attempt_id: str
    legacy_record_raw_sha256: str

    @classmethod
    def from_mapping(cls,value):
        fields=set(cls.__dataclass_fields__)
        if not isinstance(value,dict) or set(value)!=fields or any(not isinstance(v,str) or not v for v in value.values()):
            raise Refused('Exact legacy account policy schema required')
        return cls(**value)

    def permits(self,plan,row):
        if (self.schema!='xhs-exact-legacy-account-guard-v1' or
            self.policy_id!='leimu-567-legacy-account-guard-v1' or
            self.sender_uid!=LEGACY_SENDER_UID or plan.sender_uid!=LEGACY_SENDER_UID or
            self.batch_sha256!=LEGACY_APPROVED_BATCH_SHA256 or
            self.legacy_attempt_id!=LEGACY_ATTEMPT_ID or row['token']!=LEGACY_ATTEMPT_ID or
            row['status']!='unknown' or self.legacy_record_raw_sha256!=LEGACY_RECORD_RAW_SHA256):
            return False
        try:
            return (hashlib.sha256(Path(PREPARED_BATCH).read_bytes()).hexdigest()==self.batch_sha256 and
                    hashlib.sha256(row['data'].encode('utf8')).hexdigest()==self.legacy_record_raw_sha256)
        except (OSError,AttributeError,TypeError):
            return False


@dataclass(frozen=True)
class SendPlan(FrozenReply):
    canonical_customer: str
    def validate(self):
        super().validate()
        if not isinstance(self.canonical_customer, str) or not self.canonical_customer.strip():
            raise Refused('Local customer identity is required')


class HttpUnknown(Unknown):
    def __init__(self,status):
        self.status=status
        super().__init__('HTTP '+str(status)+'; no retry')


MESSAGE_CATEGORIES=frozenset({'rate_limit','verification','login','permission',
    'target_unavailable','signature','system_error','unknown'})


def business_code(value):
    if isinstance(value,str) and re.fullmatch(r'-?[0-9]{1,10}',value):value=int(value)
    return value if type(value) is int and -1000000000<=value<=1000000000 else None


def message_category(payload):
    """Only fixed labels escape this function; original messages never do."""
    text=' '.join(payload[k][:4096].lower() for k in ('msg','message','error_msg')
                  if isinstance(payload.get(k),str))
    categories=(
        ('signature',('签名','signature')),
        ('verification',('验证码','验证','安全校验','captcha','verification','verify','challenge')),
        ('login',('登录','登陆','session expired','not logged','login required')),
        ('permission',('权限','无权','禁止访问','禁言','账号受限','限制评论','permission','forbidden','not allowed')),
        ('target_unavailable',('评论不存在','笔记不存在','内容不存在','已删除','不可见','not found','deleted','unavailable')),
        ('rate_limit',('频繁','频率','操作太快','请求过多','次数过多','too many requests','rate limit','frequent')),
        ('system_error',('系统','服务异常','服务器','服务开小差','server error','system error','internal error')))
    return next((name for name,terms in categories if any(term in text for term in terms)),'unknown')


def response_diagnostics(response=None,*,payload=None):
    """Read the same in-memory response only; no requests or raw data retained."""
    data={}
    if response is not None:
        status=getattr(response,'status_code',None)
        if type(status) is int and 100<=status<=599:data['http_status']=status
        try:
            data['verification_header_present']=any(name in response.headers for name in ('verifytype','verifyuuid'))
            if len(response.content)<=65536:payload=response.json()
        except Exception:pass
    if isinstance(payload,dict):
        if type(payload.get('success')) is bool:data['success']=payload['success']
        code=business_code(payload.get('code'))
        if code is not None:data['api_code']=code
        data['message_category']=message_category(payload)
    return data


def failure_diagnostics(exc, client):
    """Never persist exception messages, response bodies, identifiers or secrets."""
    allowed={'XhsApiError','NeedVerifyError','SessionExpiredError','IpBlockedError','SignatureError',
             'HttpUnknown','Unknown','TimeoutException','ConnectError','ReadTimeout'}
    name=type(exc).__name__
    started=getattr(client,'_post_started',None)
    if type(started) is not bool:started=None
    data={'kind':'unknown','error_type':name if name in allowed else 'OtherError',
          'stage':'after_reservation_before_post' if started is False else 'post_started_or_unknown',
          'request_started':started}
    observed=getattr(client,'last_response_diagnostics',{})
    if isinstance(observed,dict):
        for key in ('http_status','api_code'):
            if type(observed.get(key)) is int:data[key]=observed[key]
        for key in ('success','verification_header_present'):
            if type(observed.get(key)) is bool:data[key]=observed[key]
        if observed.get('message_category') in MESSAGE_CATEGORIES:data['message_category']=observed['message_category']
    context=getattr(client,'last_request_context',None) or getattr(client,'managed_request_context',{})
    if isinstance(context,dict):
        if context.get('endpoint') in ('identity','comment_post'):data['endpoint']=context['endpoint']
        if context.get('stage') in ('identity','send'):data['request_stage']=context['stage']
    # Runner preserves a cause when wrapping Unknown. Inspect only typed safe
    # fields, never exception text, repr, arbitrary headers or response bodies.
    current=exc;seen=set()
    for _ in range(4):
        if current is None or id(current) in seen:break
        seen.add(id(current))
        if isinstance(current,HttpUnknown):
            if type(current.status) is int and 100<=current.status<=599:data['http_status']=current.status
            data['error_type']='HttpUnknown'
        if isinstance(current,XhsApiError):
            data.update(response_diagnostics(payload=getattr(current,'response',None)))
            code=business_code(getattr(current,'code',None))
            if code is not None:data['api_code']=code
            kind=type(current).__name__
            data['error_type']=kind if kind in allowed else 'XhsApiError'
        current=getattr(current,'__cause__',None)
    return data


class OneAttemptClient(ControlledClient):
    """Keep the original exact-endpoint guard while preserving safe HTTP codes."""
    def _request_with_retry(self,method,url,**kwargs):
        self.last_response_diagnostics={}
        endpoint={('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me'):'identity',
                  ('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post'):'comment_post'}.get((method,url),'unknown')
        self.last_request_context={'stage':'identity' if endpoint=='identity' else 'send' if endpoint=='comment_post' else 'unknown',
            'endpoint':endpoint}
        if method=='GET' and url=='https://edith.xiaohongshu.com/api/sns/web/v2/user/me':
            if self._post_started:raise Refused('No requests after submission')
        elif method=='POST' and url=='https://edith.xiaohongshu.com/api/sns/web/v1/comment/post':
            self.plan.validate()
            expected={'note_id':self.plan.note_id,'content':self.plan.text,'target_comment_id':self.plan.comment_id,'at_users':[]}
            if not self._armed or not self._identity_checked or self._post_started or json.loads(kwargs.get('content','null'))!=expected:
                raise Refused('Frozen wire request mismatch or repeated attempt')
            self._post_started=True
        else:raise Refused('Endpoint outside single-attempt scope')
        response=self._http.request(method,url,**kwargs,follow_redirects=False)
        self.last_response_diagnostics=response_diagnostics(response)
        if response.status_code!=200:raise HttpUnknown(response.status_code)
        return response


def validate_prepared(plan,path,require_hashes=False):
    try: batch=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError,ValueError) as exc: raise Refused('Prepared batch unreadable') from exc
    rows=batch.get('rows') if isinstance(batch,dict) else None
    if (batch.get('schema')!='gubei-46-local-plan-v1' or batch.get('intended_account')!='蕾姆' or
        not isinstance(rows,list) or batch.get('count')!=len(rows)):
        raise Refused('Prepared batch schema invalid')
    matches=[r for r in rows if isinstance(r,dict) and r.get('attempt_id')==plan.attempt_id]
    if len(matches)!=1:raise Refused('Attempt must select exactly one prepared customer')
    row=matches[0]
    expected={'customer_id':plan.canonical_customer,'customer_uid':plan.customer_uid,'comment_id':plan.comment_id,
              'note_id':plan.note_id,'text':plan.text,'source_identity':'local_source_consistency_only',
              'platform_reply_history':'unknown','other_accounts_history':'unknown','send_status':'not_attempted_in_this_plan'}
    if any(row.get(k)!=v for k,v in expected.items()):raise Refused('Prepared customer or reply changed')
    if require_hashes:
        hashes=batch.get('source_sha256')
        if not isinstance(hashes,dict) or set(hashes)!=set(SOURCE_FILES):raise Refused('Prepared source hashes missing')
        for key,file in SOURCE_FILES.items():
            try: actual=hashlib.sha256(file.read_bytes()).hexdigest()
            except OSError as exc:raise Refused('Prepared source unavailable: '+key) from exc
            if actual!=hashes[key]:raise Refused('Prepared source changed: '+key)


def connect(path, synthetic=False):
    path = Path(path).resolve(strict=True)
    if synthetic:
        if not path.is_relative_to(ROOT) or path.name != 'synthetic.sqlite3':
            raise Refused('Test database must be an isolated synthetic database')
    elif path != REAL_LEDGER:
        raise Refused('Live operation requires exact shared ledger')
    db = sqlite3.connect(path.as_uri() + '?mode=rw', uri=True, timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db


def _check_observation_table(db, plan):
    """Check optional collected UID evidence under the reservation transaction."""
    entry=db.execute("SELECT type FROM sqlite_master WHERE name=?",('collection_uid_observations',)).fetchone()
    if entry is None:return
    if entry['type']!='table':raise Refused('Collection identity observation schema is incompatible')
    columns=db.execute('PRAGMA table_info("collection_uid_observations")').fetchall()
    actual=[(r['name'],r['type'].upper(),r['notnull'],r['pk']) for r in columns]
    expected=[('platform','TEXT',1,1),('platform_uid','TEXT',1,2),('canonical','TEXT',1,0),
              ('basis','TEXT',1,0),('source','TEXT',1,0),('observed_at','INTEGER',1,0)]
    if actual!=expected:raise Refused('Collection identity observation schema is incompatible')
    unique_indexes=set()
    for index in db.execute('PRAGMA index_list("collection_uid_observations")'):
        if not index['unique'] or index['partial']:continue
        name=index['name'].replace('"','""')
        unique_indexes.add(tuple(r['name'] for r in db.execute('PRAGMA index_info("'+name+'")')))
    if not {('platform','platform_uid'),('platform','canonical')}.issubset(unique_indexes):
        raise Refused('Collection identity observation constraints are incompatible')
    rows=db.execute('SELECT platform_uid,canonical,basis,source,observed_at FROM collection_uid_observations '
                    'WHERE platform=? AND (platform_uid=? OR canonical=?)',
                    ('xiaohongshu',plan.customer_uid,plan.canonical_customer)).fetchall()
    for row in rows:
        if (row['basis'] not in ('local_source_consistency_only','new_uid_candidate_not_platform_verified') or
            not isinstance(row['source'],str) or not row['source'].strip() or
            type(row['observed_at']) is not int or row['observed_at']<=0):
            raise Refused('Collection identity observation evidence is invalid')
        if row['platform_uid']!=plan.customer_uid or row['canonical']!=plan.canonical_customer:
            raise Refused('Collection UID and local customer mapping conflict')


def _reserve(path, plan, synthetic, *, legacy_account_policy=None, direct_id=False,scoped_isolation_policy=None):
    plan.validate()
    if legacy_account_policy is not None and scoped_isolation_policy is not None:
        raise Refused('Account exception policies are mutually exclusive')
    with closing(connect(path, synthetic)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='local_sender_plans'").fetchone():
                raise Refused('Reviewed additive ledger migration is required')
            _check_observation_table(db,plan)
            if db.execute('SELECT 1 FROM identity_aliases a JOIN identity_aliases b ON a.platform=b.platform AND a.canonical=b.alias WHERE b.canonical<>a.canonical LIMIT 1').fetchone():
                raise Refused('Identity chain needs reconciliation')
            for table in ('leads','historical_assessments','historical_deliveries'):
                if db.execute(f'SELECT 1 FROM identity_aliases a JOIN {table} h ON a.platform=h.platform AND a.alias=h.customer WHERE a.alias<>a.canonical LIMIT 1').fetchone():
                    raise Refused('Split local identity history requires review')
            old=db.execute('SELECT * FROM reservations WHERE token=?',(plan.attempt_id,)).fetchone()
            if old:
                raise Refused('Attempt already exists; no repeat')
            target=db.execute('SELECT * FROM leads WHERE platform=? AND comment=?',('xiaohongshu',plan.comment_id)).fetchone()
            if not target or target['customer']!=plan.canonical_customer or target['status'] not in ('unverified','reviewed','history_clear'):
                raise Refused('Local target missing, changed or blocked')
            alias=db.execute('SELECT * FROM identity_aliases WHERE platform=? AND alias=?',('xiaohongshu',plan.customer_uid)).fetchone()
            if alias and alias['canonical']!=plan.canonical_customer:
                raise Refused('Platform UID maps to a conflicting local customer')
            chain=db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',('xiaohongshu',plan.canonical_customer)).fetchone()
            if chain and chain['canonical']!=plan.canonical_customer:
                raise Refused('Identity chain requires reconciliation')
            if plan.customer_uid!=plan.canonical_customer:
                for table in ('leads','historical_assessments','historical_deliveries'):
                    if db.execute(f'SELECT 1 FROM {table} WHERE platform=? AND customer=? LIMIT 1',('xiaohongshu',plan.customer_uid)).fetchone():
                        raise Refused('Separate history exists for this UID')
            if db.execute("SELECT 1 FROM leads WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent') LIMIT 1",('xiaohongshu',plan.canonical_customer)).fetchone():
                raise Refused('Customer has existing unresolved or sent local history')
            if db.execute("SELECT 1 FROM reservations WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent') LIMIT 1",('xiaohongshu',plan.canonical_customer)).fetchone():
                raise Refused('Customer has existing reservation')
            if db.execute("SELECT 1 FROM historical_deliveries WHERE platform=? AND customer=? AND delivery_state<>'not_sent' LIMIT 1",('xiaohongshu',plan.canonical_customer)).fetchone():
                raise Refused('Customer has unresolved previous software delivery')
            # A later import can assign the same platform user a new internal key.
            # Check durable submitted plans inside this reservation transaction.
            prior_plans=db.execute("SELECT p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown','sent')",('xiaohongshu',)).fetchall()
            for prior in prior_plans:
                try:
                    prior_record=json.loads(prior['data'])
                    prior_plan=prior_record.get('plan') or prior_record.get('local_mode',{}).get('plan')
                    prior_uid=prior_plan['customer_uid']
                    if not isinstance(prior_uid,str) or not prior_uid:raise ValueError('missing platform UID')
                except (ValueError,TypeError,KeyError,AttributeError):
                    raise Refused('Prior reservation identity cannot be interpreted')
                if prior_uid==plan.customer_uid:
                    raise Refused('Platform UID has an existing unresolved or accepted local submission')
            if isinstance(scoped_isolation_policy,(TwoUnknownToneSingletonPolicy,NewToneBatchReceiptPolicy,AuthorizedTargetIsolationPolicy)):
                if direct_id is not True or not scoped_isolation_policy.validate_ledger(db,plan,PREPARED_BATCH):
                    raise Refused('Latest tone singleton isolation proof invalid')
            if isinstance(scoped_isolation_policy,ReceiptQualifiedIsolationPolicy):
                anchor=db.execute('SELECT r.token,r.status,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token '
                    'WHERE r.token=? AND r.platform=?',(scoped_isolation_policy.isolated_attempt_id,'xiaohongshu')).fetchone()
                if direct_id is not True or not anchor or not scoped_isolation_policy.permits(plan,anchor,PREPARED_BATCH,db=db):
                    raise Refused('Receipt-qualified isolation proof invalid')
            exception_used=None
            rows=db.execute("SELECT r.token,r.status,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown')",('xiaohongshu',)).fetchall()
            for row in rows:
                if not row['data']:
                    raise Refused('Unattributed unresolved reservation requires reconciliation')
                try:
                    data=json.loads(row['data']); prior_sender=data['plan']['sender_uid']; result=data.get('result',{})
                except (ValueError,TypeError,KeyError):
                    raise Refused('Uninterpretable previous reservation')
                if prior_sender==plan.sender_uid:
                    if row['status']!='unknown' or result.get('kind')!='platform_receipt' or not result.get('receipt_id'):
                        if (direct_id is True and isinstance(legacy_account_policy,LegacyAccountGuardPolicy) and
                            legacy_account_policy.permits(plan,row)):
                            exception_used={'policy_id':legacy_account_policy.policy_id,
                                'legacy_attempt_id':legacy_account_policy.legacy_attempt_id,
                                'batch_sha256':legacy_account_policy.batch_sha256,
                                'legacy_record_raw_sha256':legacy_account_policy.legacy_record_raw_sha256}
                            continue
                        if (direct_id is True and isinstance(scoped_isolation_policy,(ScopedUnknownIsolationPolicy,ReceiptQualifiedIsolationPolicy,TwoUnknownToneSingletonPolicy,NewToneBatchReceiptPolicy,AuthorizedTargetIsolationPolicy)) and
                            scoped_isolation_policy.permits(plan,row,PREPARED_BATCH,db=db)):
                            if isinstance(scoped_isolation_policy,AuthorizedTargetIsolationPolicy):
                                exception_used={'policy_id':scoped_isolation_policy.policy_id,
                                    'scope':'frozen_authorized_batch_target_error_isolation',
                                    'batch_sha256':scoped_isolation_policy.batch_sha256,
                                    'isolated_account_guard_attempt':row['token']}
                                continue
                            if isinstance(scoped_isolation_policy,(TwoUnknownToneSingletonPolicy,NewToneBatchReceiptPolicy)):
                                exception_used={'policy_id':scoped_isolation_policy.policy_id,
                                    'isolated_attempt_ids':[v['attempt_id'] for v in scoped_isolation_policy.isolated_attempts],
                                    'scope':'latest_approved_tone_singleton' if isinstance(scoped_isolation_policy,TwoUnknownToneSingletonPolicy) else 'exact_new_tone_137_receipt_qualified'}
                                if isinstance(scoped_isolation_policy,TwoUnknownToneSingletonPolicy):
                                    exception_used['allowed_attempt_id']=scoped_isolation_policy.allowed_attempt_id
                                else:
                                    exception_used['proof_attempt_id']=scoped_isolation_policy.proof_attempt_id
                                    exception_used['proof_receipt_id']=scoped_isolation_policy.proof_receipt_id
                                continue
                            exception_used={'policy_id':scoped_isolation_policy.policy_id,
                                'isolated_attempt_id':scoped_isolation_policy.isolated_attempt_id,
                                'isolated_record_raw_sha256':scoped_isolation_policy.isolated_record_raw_sha256,
                                'scope':'single_preapproved_next_target' if isinstance(scoped_isolation_policy,ScopedUnknownIsolationPolicy) else 'receipt_qualified_original_approved_batch'}
                            if isinstance(scoped_isolation_policy,ScopedUnknownIsolationPolicy):
                                exception_used['allowed_attempt_id']=scoped_isolation_policy.allowed_attempt_id
                            else:
                                exception_used['proof_attempt_id']=scoped_isolation_policy.proof_attempt_id
                                exception_used['proof_receipt_id']=scoped_isolation_policy.proof_receipt_id
                            continue
                        raise Refused('Account has a previous unresolved submission')
            record={'plan':asdict(plan),'platform_replies_checked':False,'all_accounts_history_checked':False,
                    'identity_basis':'local_mapping_only','peer_reply':'unknown', 'result':None}
            if exception_used is not None:record['account_guard_exception']=exception_used
            db.execute("INSERT INTO reservations VALUES(?,?,?,?, 'reserved',NULL,?)",(plan.attempt_id,'xiaohongshu',plan.canonical_customer,plan.comment_id,int(time.time())))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',(plan.attempt_id,json.dumps(record,ensure_ascii=False)))
            db.execute("UPDATE leads SET status='reserved',review_time=NULL WHERE platform=? AND customer=? AND comment=?",('xiaohongshu',plan.canonical_customer,plan.comment_id))
            db.commit()
        except BaseException:
            db.rollback();raise


def _outcome(path,plan,synthetic,result):
    with closing(connect(path,synthetic)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            row=db.execute('SELECT * FROM reservations WHERE token=?',(plan.attempt_id,)).fetchone()
            stored=db.execute('SELECT data FROM local_sender_plans WHERE token=?',(plan.attempt_id,)).fetchone()
            if not row or row['status']!='reserved' or row['comment']!=plan.comment_id or row['customer']!=plan.canonical_customer or not stored:
                raise Refused('Reservation changed during submission')
            data=json.loads(stored['data'])
            if data.get('plan')!=asdict(plan):raise Refused('Stored plan changed')
            data['result']=result
            evidence=('Platform acceptance receipt '+result['receipt_id']+'; public visibility unverified' if result['kind']=='platform_receipt' else 'Single attempt unresolved; no retry')
            db.execute('UPDATE local_sender_plans SET data=? WHERE token=?',(json.dumps(data,ensure_ascii=False),plan.attempt_id))
            db.execute("UPDATE reservations SET status='unknown',evidence=? WHERE token=?",(evidence,plan.attempt_id))
            db.execute("UPDATE leads SET status='unknown',review_time=NULL WHERE platform=? AND customer=? AND comment=?",('xiaohongshu',plan.canonical_customer,plan.comment_id))
            db.commit()
        except BaseException:
            db.rollback();raise


class Runner:
    def __init__(self,db,client,synthetic=False,*,legacy_account_policy=None,direct_id=False,scoped_isolation_policy=None):
        self.db=Path(db);self.client=client;self.synthetic=synthetic
        self.legacy_account_policy=legacy_account_policy;self.direct_id=direct_id
        self.scoped_isolation_policy=scoped_isolation_policy
    def submit(self,plan):
        plan.validate()
        if plan!=self.client.plan:raise Refused('Frozen request differs from plan')
        if not self.synthetic:validate_prepared(plan,PREPARED_BATCH,require_hashes=True)
        lock=(ROOT/'test-locks' if self.synthetic else ROOT.parent/'xhs-standalone-reply'/'account-locks')
        with AccountLock(lock,plan.sender_uid):
            try:self.client.identity()
            except Exception as exc:
                detail=failure_diagnostics(exc,self.client);detail['stage']='identity';detail['request_started']=False
                raise Refused('身份核对失败：'+json.dumps(detail,ensure_ascii=False)) from None
            if known_restriction(getattr(self.client,'last_response_diagnostics',{})):
                raise Refused('Current identity response has restriction signal')
            plan.validate()
            _reserve(self.db,plan,self.synthetic,legacy_account_policy=self.legacy_account_policy,direct_id=self.direct_id,
                     scoped_isolation_policy=self.scoped_isolation_policy)
            try:
                if not self.synthetic:validate_prepared(plan,PREPARED_BATCH,require_hashes=True)
                plan.validate();self.client._armed=True
                data=self.client.send_once()
                receipt=data.get('comment') if isinstance(data,dict) else None
                receipt_id=receipt.get('id') if isinstance(receipt,dict) else None
                if not isinstance(receipt_id,str) or not receipt_id.strip() or len(receipt_id)>200 or not receipt_id.isprintable():
                    raise Unknown('Platform receipt missing')
                _outcome(self.db,plan,self.synthetic,{'kind':'platform_receipt','receipt_id':receipt_id,'public_visibility_checked':False})
                return 'receipt_received_unverified'
            except BaseException as exc:
                result=failure_diagnostics(exc,self.client)
                try:_outcome(self.db,plan,self.synthetic,result)
                except BaseException:pass
                suffix=('; HTTP '+str(result['http_status'])) if 'http_status' in result else ''
                if 'api_code' in result:suffix+='; platform code '+str(result['api_code'])
                raise Unknown('Single attempt unresolved; no retry'+suffix) from exc
            finally:self.client._armed=False


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',required=True,help='Exact frozen JSON target and authorized text')
    p.add_argument('--session-home',help='Already authenticated isolated CLI HOME')
    p.add_argument('--execute',action='store_true',help='Perform one single actual reply')
    args=p.parse_args()
    plan=SendPlan(**json.loads(Path(args.plan).read_text(encoding='utf-8-sig')));plan.validate()
    if not args.execute:
        print(json.dumps({'mode':'preview','plan':asdict(plan)},ensure_ascii=False));return
    if not args.session_home:raise Refused('Isolated CLI session is required')
    client=OneAttemptClient(load_independent_cookies(args.session_home),plan)
    try:result=Runner(REAL_LEDGER,client).submit(plan)
    finally:client.close()
    print(json.dumps({'result':result,'public_visibility_checked':False},ensure_ascii=False))


if __name__=='__main__':
    try:main()
    except (Refused,Unknown,sqlite3.Error,OSError,ValueError) as exc:
        print(json.dumps({'error':str(exc)},ensure_ascii=False),file=sys.stderr);raise SystemExit(2)
