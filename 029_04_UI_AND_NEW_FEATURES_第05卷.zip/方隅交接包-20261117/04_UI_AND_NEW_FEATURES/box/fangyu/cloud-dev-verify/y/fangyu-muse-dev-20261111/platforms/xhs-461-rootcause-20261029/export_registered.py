"""Read-only, source-audited export and consistent SQLite ledger backup."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import csv
import hashlib
import json
import sqlite3

PROJECT=Path(__file__).resolve().parents[2]
OUT=PROJECT/'outputs/古北采集数据与去重账本'
LEDGER=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'

def main():
    rows=[]; sources={}; seen=set(); input_proofs=[]
    fields=('comment_id','note_id','comment_text','parent_text','parent_relationship',
        'post_title','post_text','published_at','missing_context','identity_evidence',
        'ip_location','region','ip_location_source')
    for suffix in ('23','39'):
        root=PROJECT/('work/xhs-account-switch-recovery-candidate/runtime/resume-new10000-20261029-batch'+suffix)
        for line in (root/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines():
            manifest=json.loads(line)
            path=root/manifest['input']
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            assert digest==manifest['sha256']
            source=manifest['registration_source']; expected=set()
            for customer in json.loads(path.read_text(encoding='utf8')):
                for comment in [customer,*customer.get('other_comments',[])]:
                    identifier=comment['comment_id']
                    assert identifier not in seen
                    seen.add(identifier)
                    row={k:comment[k] for k in fields if k in comment}
                    row.update(customer_id=customer['customer_id'],customer_uid=customer['customer_uid'],
                        source_batch=manifest['batch'],source_keyword=manifest['keyword'],
                        source_page=manifest['page'],source_account_uid=manifest['account_uid'])
                    rows.append(row); expected.add((customer['customer_id'],identifier))
            assert len(expected)==manifest['inserted_comments']
            sources[source]=expected; input_proofs.append({'path':str(path),'sha256':digest})
    assert len(rows)==2755==len(seen)
    OUT.mkdir(exist_ok=False)
    snapshot=OUT/'去重账本快照.sqlite3'
    with closing(sqlite3.connect(LEDGER.as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('PRAGMA query_only=ON')
        with closing(sqlite3.connect(snapshot)) as dest: db.backup(dest)
    with closing(sqlite3.connect(snapshot.as_uri()+'?mode=ro',uri=True)) as db:
        assert db.execute('PRAGMA quick_check').fetchone()[0]=='ok'
        for source,expected in sources.items():
            actual=set(db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)))
            assert actual==expected
    data=OUT/'本次已登记评论2755条.jsonl'
    with data.open('x',encoding='utf8') as stream:
        for row in rows: stream.write(json.dumps(row,ensure_ascii=False)+'\n')
    columns={'customer_uid':'客户标识','comment_id':'评论标识','comment_text':'评论原文',
        'published_at':'评论发布时间','ip_location':'公开IP属地','region':'原记录地区',
        'post_title':'原帖标题','post_text':'原帖正文','parent_text':'父评论原文',
        'source_keyword':'采集搜索词','source_page':'搜索页','note_id':'笔记标识'}
    def cell(value):
        value=json.dumps(value,ensure_ascii=False) if isinstance(value,(dict,list)) else str(value or '')
        return "'"+value if value.lstrip().startswith(('=','+','-','@')) or value.startswith(('\t','\r')) else value
    human=OUT/'本次已登记评论2755条.csv'
    with human.open('x',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream); writer.writerow(columns.values())
        writer.writerows([cell(row.get(k,'')) for k in columns] for row in rows)
    note=OUT/'先看这里.txt'
    note.write_text('本次恢复后已登记评论共2,755条，来自17个登记批次，已逐条与去重账本核对。\n'
        '未登记的中断批次部分数据不计入。CSV供直接查看；JSONL保留机器可读字段。\n'
        '缺失的原帖、父评论、发布时间和地区保持为空或原记录状态，未补写。\n'
        'CSV对可能被表格软件识别为公式的文字加了显示保护；JSONL保留原文。\n'
        '去重账本快照包含历史记录和本次登记数据，是一致性备份；不会随后续采集更新。\n'
        '本文件夹不含登录凭据。\n',encoding='utf8')
    proof={'created_at':datetime.now(timezone.utc).isoformat(),'registered_comments':len(rows),
        'source_batches':len(sources),'all_registered_pairs_verified':True,
        'ledger_snapshot_quick_check':'ok','live_ledger_unchanged':True,'platform_requests':0,
        'files':{x.name:{'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}
            for x in (data,human,snapshot,note)},'inputs':input_proofs}
    (Path(__file__).parent/'export-verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf8')
    assert len(data.read_text(encoding='utf8').splitlines())==2755
    with human.open(encoding='utf-8-sig',newline='') as stream: assert sum(1 for _ in csv.reader(stream))==2756
    print(json.dumps({'verified':True,'comments':2755,'batches':len(sources),'folder':str(OUT)},ensure_ascii=False))

if __name__=='__main__': main()
