"""Create the 15-store read-only search plan from approved source candidates."""
import csv, json
from collections import defaultdict
from pathlib import Path
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / 'outputs/方隅双平台文本业务/15家门店关键词/15家门店关键词总表.csv'
identity = json.loads((ROOT/'identity-probe.json').read_text(encoding='utf-8'))
stores = defaultdict(list)
with SOURCE.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
for priority in ('主动求租与找房', '地域与租住条件', '补充探索'):
    for row in rows:
        if row['搜索顺序'] == priority and row['关键词'] not in stores[row['门店名称']]:
            stores[row['门店名称']].append(row['关键词'])
if len(stores) != 15 or sum(map(len, stores.values())) != 3000:
    raise ValueError('Source count or category labels changed; do not guess')
plan = {'scan_id':'douyin-20261029-initial', 'account_uid':identity['account']['sec_uid'],
        'connection_id':identity['connection_id'], 'target_comments':100000,
        'rule_source':'方隅双平台文本业务/15家门店关键词；用户2026-10-29采集要求',
        'plan_source':str(SOURCE),
        'stores':[{'store_id':name,'name':name,'keywords':terms} for name,terms in stores.items()]}
out=ROOT/'15-store-plan.json'
if out.exists():
    raise FileExistsError('Preserve the prior plan; use a separately reviewed revision')
out.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'stores':len(stores),'keywords':sum(map(len,stores.values())),'target_comments':100000}))
