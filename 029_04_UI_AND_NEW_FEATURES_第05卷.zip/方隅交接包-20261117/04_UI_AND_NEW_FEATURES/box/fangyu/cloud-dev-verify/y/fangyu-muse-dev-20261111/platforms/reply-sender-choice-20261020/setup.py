from pathlib import Path
import json,shutil,hashlib
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/reply-sender-choice-20261020');S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
files=['work/ui-approved-implementation/ui-preview/pages/'+n for n in ['reply-connected.mjs','reply-batch.mjs','reply-delivery.mjs','reply.css']]+['work/ui-native-r57/reply_workbench.py','work/ui-native-r57/reply_delivery.py']
for name in files:
 p=T/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();shutil.copyfile(S/name,p)
(T/'ADDED.json').write_text(json.dumps(['work/ui-approved-implementation/ui-preview/pages/reply-account.mjs']),encoding='utf-8')
(T/'PLAN.md').write_text('仅改回复账号区域、批量统一账号及昵称投影；沿用浅色蓝绿、原生select。单条发送账号18px加粗，昵称20px；SOP入口18px半粗。批量先明确选账号，无自动回退；预览与最终授权再显示昵称。复用已确认的render/bind与隔离后台接口测试边界，不触发真实发送/平台请求、不改数据与会话。修改范围为before清单及reply-account.mjs；来源v38。',encoding='utf-8')
print('Backed up six source files; scope registered.')
