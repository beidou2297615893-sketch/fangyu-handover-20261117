import unittest
from unittest.mock import patch

import httpx

import collector


class PrewarmCompatibilityTests(unittest.TestCase):
    def search(self, endpoint, body, status=200, headers=None):
        calls = []
        def respond(request):
            calls.append(request.url.path)
            if request.url.path.endswith(endpoint):
                return httpx.Response(status, request=request, json=body, headers=headers)
            if request.url.path.endswith('/notes'):
                return httpx.Response(200, request=request, json={'success': True, 'data': {'items': []}})
            return httpx.Response(200, request=request, json={'success': True, 'data': {}})
        client = collector.ReadClient({'a1': 'fixture', 'web_session': 'fixture'},
                                      transport=httpx.MockTransport(respond), delay=0)
        try:
            with patch('xhs_cli.client_mixins._acquire_search_session', return_value=('fixture', True)), \
                 patch('xhs_cli.client.sign_main_api', return_value={}):
                try:
                    result = client.search_notes('古北', page=1)
                    return calls, result, None
                except collector.Halt as error:
                    return calls, None, str(error)
        finally:
            client.close()

    def test_empty_unsuccessful_onebox_allows_actual_search_once(self):
        calls, result, error = self.search('/onebox', {'code': 0, 'success': False, 'data': {}})
        self.assertIsNone(error)
        self.assertEqual(result, {'items': []})
        self.assertEqual(calls.count('/api/sns/web/v1/search/onebox'), 1)
        self.assertEqual(calls.count('/api/sns/web/v1/search/notes'), 1)

    def test_empty_unsuccessful_filter_allows_actual_search(self):
        calls, result, error = self.search('/filter', {'code': 0, 'success': False, 'data': None})
        self.assertIsNone(error)
        self.assertEqual(result, {'items': []})
        self.assertIn('/api/sns/web/v1/search/notes', calls)

    def test_formal_search_failure_remains_fatal(self):
        calls, result, error = self.search('/notes', {'code': 0, 'success': False, 'data': {}})
        self.assertIsNotNone(error)
        self.assertIsNone(result)
        self.assertNotIn('/api/sns/web/v1/search/recommend', calls)

    def test_exact_success_literal_on_empty_prewarm_allows_notes_once(self):
        for literal in ('成功', '请求成功', '操作成功', 'success', 'ok'):
            with self.subTest(literal=literal):
                calls, result, error = self.search('/onebox', {'code': 0, 'success': False, 'data': {}, 'msg': literal})
                self.assertIsNone(error)
                self.assertEqual(result, {'items': []})
                self.assertEqual(calls.count('/api/sns/web/v1/search/notes'), 1)

    def test_success_text_does_not_allow_mixed_or_unknown_messages_or_data(self):
        cases = [
            {'code': 0, 'success': False, 'msg': '成功', 'message': '请先登录'},
            {'code': 0, 'success': False, 'msg': 'success token=SECRET'},
            {'code': 0, 'success': False, 'msg': '成功', 'data': {'anything': 1}},
        ]
        for body in cases:
            calls, result, error = self.search('/onebox', body)
            self.assertIsNotNone(error)
            self.assertEqual(calls, ['/api/sns/web/v1/search/onebox'])

    def test_unknown_or_security_prewarm_responses_stop_before_search(self):
        cases = [
            ({'code': 0, 'success': False, 'msg': '需要验证码'}, 200, None),
            ({'code': 0, 'success': False, 'data': {'verify': True}}, 200, None),
            ({'code': 0, 'success': False, 'verifytype': 'captcha'}, 200, None),
            ({'code': 0, 'success': False}, 200, {'verifytype': 'captcha'}),
            ({'code': 300012, 'success': False}, 200, None),
            ({'code': 300015, 'success': False}, 200, None),
            ({'code': -100, 'success': False}, 200, None),
            ({'code': 0, 'success': False}, 461, None),
            ({'code': 0, 'success': False}, 429, None),
        ]
        for body, status, headers in cases:
            with self.subTest(body=body, status=status, headers=headers):
                calls, result, error = self.search('/onebox', body, status, headers)
                self.assertIsNotNone(error)
                self.assertIsNone(result)
                self.assertEqual(calls, ['/api/sns/web/v1/search/onebox'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
