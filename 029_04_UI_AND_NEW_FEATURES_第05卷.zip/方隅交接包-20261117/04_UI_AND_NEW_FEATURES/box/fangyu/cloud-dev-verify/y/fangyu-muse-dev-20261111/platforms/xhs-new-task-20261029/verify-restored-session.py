import importlib.util,json
from pathlib import Path
P=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('restored_session_live',P/'work/xhs-live-collection-runner-20261029/runner.py')
live=importlib.util.module_from_spec(s);s.loader.exec_module(live)
r=P/'work/xhs-account-switch-recovery-candidate/runtime/new-task-session-verified-sample-20261029'
r.mkdir(exist_ok=False)
try:
 result=live.run_task(r,[{'keyword':'古北服务公寓','page':2}],session_home=P/'work/xhs-standalone-session/new-task-session-repair-20261029-1720',ledger=P/'work/shared-acquisition-ledger/shared.sqlite3',source_db=P/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3',target=1000000000,first_batch=9,shared_ledger=True,max_comment_pages=2,operator='current_chat_verified_session')
 print(json.dumps({'status':result['status'],'inserted':result.get('inserted',0)},ensure_ascii=False),flush=True)
except Exception:
 print(json.dumps({'status':'stopped_inspect_persistent_receipts','automatic_retry':False}),flush=True)
 raise SystemExit(2)
