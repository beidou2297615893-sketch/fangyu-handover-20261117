import unittest
from unittest.mock import patch
from urllib.parse import urlsplit

import httpx
from xhs_cli.signing import build_get_uri

import collector


class LocalFragmentTests(unittest.TestCase):
    def test_installed_builder_leaves_fragment_delimiter_in_opaque_cursor(self):
        uri = build_get_uri('/api/sns/web/v2/comment/page', {'cursor': 'synthetic#part', 'xsec_token': 'fixture'})
        self.assertTrue(urlsplit(uri).fragment)

    def test_local_fragment_blocks_before_wire_preserves_partial_and_continues_other_notes(self):
        calls, progress = [], []
        def respond(request):
            calls.append(request)
            note = request.url.params['note_id']
            data = {'comments': [{'id': 'comment_' + note, 'content': '本人求租',
                                  'user_info': {'user_id': 'user_' + note}}],
                    'has_more': note == 'note1', 'cursor': 'synthetic#part' if note == 'note1' else ''}
            return httpx.Response(200, request=request, json={'success': True, 'data': data})
        class Client(collector.ReadClient):
            def get_self_info(self): return {'user_id': 'sender'}
            def search_notes(self, **kwargs):
                return {'items': [{'id': note, 'xsec_token': 'fixture', 'note_card': {'title': '古北'}}
                                  for note in ('note1', 'note2')]}
        client = Client({'a1': 'fixture', 'web_session': 'fixture'},
                        transport=httpx.MockTransport(respond), delay=0)
        try:
            with patch('xhs_cli.client.sign_main_api', return_value={}), \
                 patch('xhs_cli.client_mixins.get_cached_note_context', return_value={}), \
                 patch('xhs_cli.client_mixins.cache_note_context'):
                result = collector.collect(client, 'sender', '古北', {}, max_notes=2, max_pages=2,
                                           on_progress=progress.append)
        finally:
            client.close()
        self.assertEqual(len(calls), 2)
        self.assertEqual(result['summary']['usable_comments'], 2)
        self.assertEqual(result['summary']['truncated_note_pages'], 1)
        self.assertEqual(result['pending'][0]['reason'], 'local_comment_url_fragment_before_request')
        self.assertEqual(result['pending'][0]['note_id'], 'note1')
        self.assertEqual(progress[-1]['pending'], result['pending'])
        self.assertNotIn('synthetic', str(result))

    def test_actual_platform_failure_still_halts_entire_collection(self):
        class Client:
            def get_self_info(self): return {'user_id': 'sender'}
            def search_notes(self, **kwargs):
                return {'items': [{'id': 'note1', 'xsec_token': 'fixture', 'note_card': {}}]}
            def get_comments(self, *args, **kwargs):
                raise collector.Halt('HTTP 461')
        with self.assertRaisesRegex(collector.Halt, '461'):
            collector.collect(Client(), 'sender', '古北', {})

    def test_other_local_rejections_are_not_swallowed(self):
        base = {'method': 'GET', 'host': 'edith.xiaohongshu.com',
                'path': '/api/sns/web/v2/comment/page',
                'request_started': False, 'fragment_present': True}
        cases = [(base, False), ({**base, 'path': '/explore/[redacted]'}, True),
                 ({**base, 'request_started': True}, True)]
        for detail, allowed in cases:
            class Client:
                def get_self_info(self): return {'user_id': 'sender'}
                def search_notes(self, **kwargs):
                    return {'items': [{'id': 'note1', 'xsec_token': 'fixture', 'note_card': {}}]}
                def get_comments(self, *args, **kwargs):
                    raise collector.LocalRequestRejected(detail, allowed)
            with self.subTest(detail=detail, allowed=allowed), self.assertRaises(collector.LocalRequestRejected):
                collector.collect(Client(), 'sender', '古北', {})


if __name__ == '__main__':
    unittest.main(verbosity=2)
