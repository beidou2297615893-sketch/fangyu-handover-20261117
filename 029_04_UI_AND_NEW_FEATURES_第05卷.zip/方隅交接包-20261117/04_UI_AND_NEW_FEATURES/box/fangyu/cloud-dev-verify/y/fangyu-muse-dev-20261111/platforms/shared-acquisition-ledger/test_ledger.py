import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).parent
CLI=ROOT/'ledger.py'
class LedgerTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.db=str(Path(self.t.name)/'test.db'); self.runcli('init')
 def tearDown(self): self.t.cleanup()
 def runcli(self,*args,ok=True):
  p=subprocess.run([sys.executable,str(CLI),'--db',self.db,*args],capture_output=True,text=True,encoding='utf-8'); self.assertEqual(p.returncode==0,ok,p.stderr); return json.loads(p.stdout)
 def assess(self,platform,person,comment,bind=True):
  if bind:self.runcli('identity-bind',platform,person,person,'verified identity and history in test')
  p=Path(self.t.name)/'good.json'; p.write_text(json.dumps({'source':'https://example.test','intent':'rental','store':'store','match':'match','pending':'','draft':'hello','peer_reply':'none'}),encoding='utf-8'); self.runcli('assess',platform,person,comment,str(p))
 def test_unknown_and_sent_block(self):
  self.runcli('lead','xiaohongshu','person','comment'); self.runcli('reserve','xiaohongshu','person','comment','first',ok=False)
  self.assess('xiaohongshu','person','comment'); self.runcli('review','xiaohongshu','person','comment','operator','evidence'); self.runcli('reserve','xiaohongshu','person','comment','first'); self.runcli('outcome','first','sent','receipt'); self.runcli('reserve','xiaohongshu','person','comment','second',ok=False)
 def test_concurrent_reservation_and_idempotence(self):
  self.runcli('lead','douyin','person','comment'); self.assess('douyin','person','comment'); self.runcli('review','douyin','person','comment','operator','evidence')
  procs=[subprocess.Popen([sys.executable,str(CLI),'--db',self.db,'reserve','douyin','person','comment',str(i)],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for i in range(8)]
  outcomes=[p.communicate() or p.returncode for p in procs]; self.assertEqual(sum(p.returncode==0 for p in procs),1)
  winner=str(next(i for i,p in enumerate(procs) if p.returncode==0)); self.assertFalse(self.runcli('reserve','douyin','person','comment',winner)['granted'])
  self.runcli('outcome',winner,'unknown','transport timed out'); self.runcli('reserve','douyin','person','comment','new',ok=False)
 def test_same_token_concurrency_grants_only_once(self):
  self.runcli('lead','douyin','p','c'); self.assess('douyin','p','c'); self.runcli('review','douyin','p','c','op','evidence')
  ps=[subprocess.Popen([sys.executable,str(CLI),'--db',self.db,'reserve','douyin','p','c','same'],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for _ in range(4)]
  answers=[json.loads(p.communicate()[0].decode('utf-8')) for p in ps]; self.assertEqual(sum(bool(x.get('granted')) for x in answers),1)
 def test_missing_database_cannot_create(self):
  missing=str(Path(self.t.name)/'missing.db'); p=subprocess.run([sys.executable,str(CLI),'--db',missing,'check','douyin','p','c'],capture_output=True); self.assertNotEqual(p.returncode,0); self.assertFalse(Path(missing).exists())
 def test_search_idempotence_and_conflict(self):
  self.runcli('search','e1','古北','xiaohongshu','古北租房','completed','3'); self.runcli('search','e1','古北','xiaohongshu','古北租房','completed','3'); self.runcli('search','e1','古北','xiaohongshu','古北租房','failed','0',ok=False)
  self.assertEqual(len(self.runcli('search-list')['records']),1)
 def test_import_history_never_releases_and_import_idempotent(self):
  p=Path(self.t.name)/'snapshot.json'; p.write_text(json.dumps({'records':[{'platform':'xiaohongshu','customer_id':'p','comment_id':'c','state':'unverified'}]}),encoding='utf-8')
  self.runcli('import-history',str(p)); self.runcli('import-history',str(p)); self.runcli('reserve','xiaohongshu','p','c','r',ok=False)
  self.assertEqual(len(self.runcli('lead-list')['records']),1)
 def test_screening_records_and_blocks_unqualified(self):
  self.runcli('lead','douyin','x','c'); f=Path(self.t.name)/'assessment.json'; f.write_text(json.dumps({'source':'https://example.test','intent':'unverified','store':'古北','match':'unverified','pending':'时效','draft':'','peer_reply':'unknown'},ensure_ascii=False),encoding='utf-8'); self.runcli('assess','douyin','x','c',str(f)); self.runcli('review','douyin','x','c','op','evidence'); self.runcli('reserve','douyin','x','c','r',ok=False)
 def test_same_customer_other_comment_blocks(self):
  self.runcli('lead','xiaohongshu','p','a'); self.runcli('lead','xiaohongshu','p','b'); self.assess('xiaohongshu','p','a'); self.runcli('review','xiaohongshu','p','a','op','evidence'); self.runcli('reserve','xiaohongshu','p','a','r',ok=False)
 def test_other_comment_cannot_bypass_inflight_or_sent(self):
  for c in ('a','b'):
   self.runcli('lead','douyin','p',c); self.assess('douyin','p',c); self.runcli('review','douyin','p',c,'op','evidence')
  self.runcli('history-clear','douyin','p','b','op','checked history and no outgoing reply')
  self.runcli('reserve','douyin','p','a','first'); self.runcli('reserve','douyin','p','b','second',ok=False); self.runcli('outcome','first','sent','receipt'); self.runcli('reserve','douyin','p','b','second',ok=False)
 def test_candidate_import_idempotence(self):
  p=Path(self.t.name)/'words.csv'; p.write_text('keyword,group,priority,enabled\nword,shop/group,90,false\n',encoding='utf-8'); self.runcli('import-words',str(p),'shared'); self.runcli('import-words',str(p),'shared'); self.assertEqual(len(self.runcli('word-list')['records']),1)
 def test_invalid_screening_fields_are_rejected(self):
  self.runcli('lead','xiaohongshu','p','c'); f=Path(self.t.name)/'invalid.json'
  f.write_text(json.dumps({'source':None,'intent':'rental','store':None,'match':'match','pending':'','draft':'','peer_reply':'none'}),encoding='utf-8')
  self.runcli('assess','xiaohongshu','p','c',str(f),ok=False)
 def test_unmapped_identity_cannot_reserve(self):
  self.runcli('lead','xiaohongshu','p','c'); self.assess('xiaohongshu','p','c',bind=False); self.runcli('review','xiaohongshu','p','c','op','evidence')
  self.runcli('reserve','xiaohongshu','p','c','r',ok=False)
 def test_not_sent_requires_new_screening(self):
  self.runcli('lead','xiaohongshu','p','c'); self.runcli('identity-bind','xiaohongshu','p','p','evidence'); self.assess('xiaohongshu','p','c'); self.runcli('review','xiaohongshu','p','c','op','evidence'); self.runcli('reserve','xiaohongshu','p','c','r'); self.runcli('outcome','r','not_sent','confirmed no request')
  self.runcli('review','xiaohongshu','p','c','op','new evidence'); self.runcli('reserve','xiaohongshu','p','c','new',ok=False)
 def test_alias_links_history_and_conflicts(self):
  self.runcli('lead','xiaohongshu','legacy','old'); self.runcli('identity-bind','xiaohongshu','platform_uid','legacy','identity evidence')
  self.runcli('lead','xiaohongshu','platform_uid','old'); self.runcli('lead','xiaohongshu','platform_uid','new'); self.assess('xiaohongshu','platform_uid','new',bind=False); self.runcli('review','xiaohongshu','platform_uid','new','op','evidence')
  self.runcli('reserve','xiaohongshu','platform_uid','new','r',ok=False)
  self.runcli('identity-bind','xiaohongshu','platform_uid','other','conflict',ok=False)
 def test_alias_chains_are_rejected(self):
  self.runcli('identity-bind','xiaohongshu','A','B','evidence')
  self.runcli('identity-bind','xiaohongshu','B','C','evidence',ok=False)
  self.runcli('identity-bind','xiaohongshu','D','A','evidence',ok=False)
 def test_import_history_after_binding_resolves_alias(self):
  self.runcli('identity-bind','xiaohongshu','uid','legacy','evidence')
  p=Path(self.t.name)/'snapshot.json';p.write_text(json.dumps({'records':[{'platform':'xiaohongshu','customer_id':'uid','comment_id':'old'}]}),encoding='utf-8')
  self.runcli('import-history',str(p)); self.runcli('lead','xiaohongshu','uid','new'); self.assess('xiaohongshu','uid','new',bind=False);self.runcli('review','xiaohongshu','uid','new','op','evidence')
  self.runcli('reserve','xiaohongshu','uid','new','r',ok=False)
 def test_legacy_identity_chains_fail_closed(self):
  import sqlite3,contextlib
  with contextlib.closing(sqlite3.connect(self.db)) as c:
   c.execute('insert into identity_aliases values(?,?,?,?,?)',('xiaohongshu','A','B','legacy',1))
   c.execute('insert into identity_aliases values(?,?,?,?,?)',('xiaohongshu','B','C','legacy',1))
   c.commit()
  self.runcli('check','xiaohongshu','A','comment',ok=False)
 def test_review_alone_does_not_clear_other_history(self):
  self.runcli('lead','xiaohongshu','p','old');self.runcli('lead','xiaohongshu','p','new');self.assess('xiaohongshu','p','new');self.runcli('review','xiaohongshu','p','new','op','evidence')
  self.runcli('review','xiaohongshu','p','old','op','generic review');self.runcli('reserve','xiaohongshu','p','new','r',ok=False)
  self.runcli('history-clear','xiaohongshu','p','old','op','checked no outbound reply');self.runcli('reserve','xiaohongshu','p','new','r')
 def test_history_assessment_is_visible_but_not_send_approval(self):
  self.runcli('lead','xiaohongshu','legacy','old'); self.runcli('identity-bind','xiaohongshu','uid','legacy','identity evidence')
  p=Path(self.t.name)/'history.jsonl';p.write_text(json.dumps({'platform':'xiaohongshu','customer_id':'legacy','existing_assessment':{'interestLevel':'high','status':'uncertain','reason':'unknown region'}})+'\n',encoding='utf-8')
  self.runcli('import-assessments',str(p));self.assertEqual(self.runcli('check','xiaohongshu','uid','old')['historical_assessments'][0]['data']['status'],'uncertain')
  self.runcli('reserve','xiaohongshu','uid','old','r',ok=False)
 def test_legacy_split_identity_records_fail_closed(self):
  import sqlite3,contextlib
  with contextlib.closing(sqlite3.connect(self.db)) as c:
   c.execute('insert into identity_aliases values(?,?,?,?,?)',('xiaohongshu','legacy','uid','old evidence',1))
   c.execute('insert into leads(platform,customer,comment,status,source) values(?,?,?,?,?)',('xiaohongshu','legacy','old','unverified','legacy'))
   c.commit()
  self.runcli('check','xiaohongshu','uid','new',ok=False)
 def test_submitted_historical_delivery_blocks_review(self):
  self.runcli('lead','xiaohongshu','p','c');p=Path(self.t.name)/'delivery.json'
  p.write_text(json.dumps({'records':[{'platform':'xiaohongshu','customer_id':'p','comment_id':'c','delivery_state':'submitted','reference':'old-queue'}]}),encoding='utf-8')
  self.runcli('import-deliveries',str(p));self.assertEqual(self.runcli('check','xiaohongshu','p','c')['target']['status'],'unknown')
  self.runcli('review','xiaohongshu','p','c','op','evidence',ok=False)
if __name__=='__main__': unittest.main()
