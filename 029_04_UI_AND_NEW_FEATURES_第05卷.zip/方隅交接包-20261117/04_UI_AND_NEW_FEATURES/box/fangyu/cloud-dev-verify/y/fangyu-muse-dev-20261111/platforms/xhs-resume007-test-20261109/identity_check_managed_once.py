﻿import importlib.util, json
from pathlib import Path
from datetime import datetime, timezone

PROJECT = Path(__file__).resolve().parents[2]
SESSION = PROJECT / "work" / "xhs-standalone-session" / "yumicha-login-20261110-03"
UID = "5f469df5000000000101ec0b"
COOKIE = SESSION / ".xiaohongshu-cli" / "cookies.json"
spec = importlib.util.spec_from_file_location(
    "managed_session",
    PROJECT / "work" / "xhs-new-task-session-fix-20261029" / "managed_session.py",
)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
out = {
    "at": datetime.now(timezone.utc).isoformat(),
    "uid": UID,
    "session_home": str(SESSION.resolve()),
    "automatic_retry": False,
}
c = None
try:
    c = m.ManagedClient(COOKIE, UID, delay=3.0)
    info = c.get_self_info()
    identity = m.account.identify(info)
    got = identity["uid"]
    if got != UID:
        out.update(status="stopped", error_type="SessionStop", reason="account_mismatch")
    else:
        out.update(status="verified", uid=got)
except Exception as e:
    out.update(status="stopped", error_type=type(e).__name__)
    reason = str(e)
    allowed = set(getattr(m, "MANAGED_STOP_REASONS", ())) | {
        "session_update_requires_review",
        "account_mismatch",
        "verification_required",
        "identity_unverified",
        "account_changed_no_retry",
    }
    if reason in allowed:
        out["reason"] = reason
    if c is not None:
        stop = getattr(c, "last_managed_stop", None)
        if isinstance(stop, dict) and stop.get("reason"):
            out["reason"] = stop.get("reason")
            ctx = {k: stop[k] for k in ("stage", "endpoint", "request_started", "http_status") if k in stop}
            if ctx:
                out["managed_request_context"] = ctx
finally:
    if c is not None and hasattr(c, "close"):
        try:
            c.close()
        except Exception:
            pass

public = {k: v for k, v in out.items() if k != "uid"}
if out.get("uid"):
    public["uid_tail"] = str(out["uid"])[-4:]
if out.get("status") == "verified":
    text = json.dumps(out, ensure_ascii=False, indent=2)
    dests = [
        PROJECT / "work" / "xhs-resume-20261103" / "identity-check-resume006-verified.json",
        PROJECT / "work" / "xhs-resume007-test-20261109" / "identity-check-resume006-verified.json",
    ]
    for dest in dests:
        dest.write_text(text, encoding="utf-8")
    public["written"] = [str(d) for d in dests]
print(json.dumps(public, ensure_ascii=False))
