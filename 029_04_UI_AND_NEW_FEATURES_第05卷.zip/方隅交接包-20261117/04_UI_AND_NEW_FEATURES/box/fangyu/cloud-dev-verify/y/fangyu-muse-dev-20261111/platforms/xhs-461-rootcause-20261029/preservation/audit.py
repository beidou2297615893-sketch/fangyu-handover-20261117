"""Read-only preservation audit. Never invokes collection or registration."""
import hashlib
import json
import sqlite3
import sys
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
PROJECT = Path.cwd().resolve()
RUNTIME = PROJECT / 'work/xhs-account-switch-recovery-candidate/runtime'
OUT = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def comment_map(rows):
    result = {}
    for row in rows:
        for item in [row, *row.get('other_comments', [])]:
            key = (row.get('customer_id'), item.get('comment_id'))
            assert all(isinstance(v, str) and v for v in key) and key not in result
            result[key] = (row.get('customer_uid'), item.get('note_id'), item.get('comment_text'),
                           item.get('published_at'), item.get('ip_location'))
    return result

def state_summary(state):
    inflight = state.get('inflight')
    return {'status': state.get('status'), 'cursor': state.get('cursor'),
            'plan_count': len(state.get('plan', [])), 'next_batch': state.get('next_batch'),
            'inserted': state.get('inserted'),
            'inflight': None if inflight is None else {'batch': inflight.get('batch'),
                 'page': inflight.get('page'), 'remaining': inflight.get('remaining')}}

def main():
    roots = {s: RUNTIME / ('resume-new10000-20261029-batch' + s) for s in ('23','39','41','42')}
    states = {s: read(p/'state.json') for s,p in roots.items()}
    configs = {s: read(p/'task-config.json') for s,p in roots.items()}
    ledgers = {Path(c['ledger']).resolve(strict=True) for c in configs.values()}
    assert len(ledgers) == 1
    ledger = ledgers.pop()
    fingerprints = {}
    def record(path):
        fingerprints[str(path.relative_to(PROJECT))] = sha(path)
    for s,root in roots.items():
        record(root/'state.json'); record(root/'task-config.json')
        if (root/'analysis-manifest.jsonl').exists(): record(root/'analysis-manifest.jsonl')
    for p in (PROJECT/'work/xhs-collection-candidate/collector.py',
              PROJECT/'work/xhs-collection-candidate/register.py',
              PROJECT/'work/xhs-account-switch-recovery-candidate/account_switch.py',
              PROJECT/'work/xhs-queue-successor-20261029/successor.py'):
        record(p)
    assert fingerprints['work\\xhs-collection-candidate\\collector.py'] == '108cce376ded3f17634bedc5d3ba2502af52fbf2b106116fba81ee2a7c48590f'
    assert fingerprints['work\\xhs-collection-candidate\\register.py'] == '7a1296df9711ed5c34764837ca678a4566e2ae833123e4221a9a00a2c1f32cc2'
    per_root = {}; all_pairs=set(); all_comment_ids=set(); sources=[]
    with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('PRAGMA query_only=ON'); db.execute('BEGIN')
        for suffix in ('23','39'):
            root=roots[suffix]; state=states[suffix]; config=configs[suffix]
            events=[json.loads(line) for line in (root/'analysis-manifest.jsonl').read_text(encoding='utf-8-sig').splitlines() if line]
            assert len(events)==state['cursor'] and config['first_batch']+len(events)==state['next_batch']
            total=0; account_uid=None
            for index,event in enumerate(events):
                batch=f"batch-{config['first_batch']+index:04d}"; folder=root/batch
                binding=read(folder/'account-binding.json'); receipt=read(folder/'register-result.json')
                ready=read(folder/'registered-ready.json'); collection=read(folder/'collection.json')
                selected=read(folder/'new-ai-input.json'); count=receipt['result']['inserted']
                source='collection:'+str((folder/'collection.json').resolve(strict=True))
                assert event['batch']==batch and event['keyword']==state['plan'][index]['keyword'] and event['page']==state['plan'][index]['page']
                assert isinstance(count,int) and not isinstance(count,bool) and count>=0
                assert event['inserted_comments']==count and event['status']=='registered_ready_for_classification'
                assert event['registration_source']==source and event['input']==f'{batch}/new-ai-input.json'
                assert event['sha256']==sha(folder/'new-ai-input.json')
                assert binding.get('guest') is False and binding.get('uid') and event['account_uid']==binding['uid']
                assert receipt['account']==binding and collection['collection_account']==binding
                assert ready['registered'] is True and ready['account_uid']==binding['uid']
                assert ready['inserted_comments']==count and ready['input']=='new-ai-input.json'
                assert account_uid in (None,binding['uid']); account_uid=binding['uid']
                original=comment_map(collection['customers']); analysis=comment_map(selected)
                rows=db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchall()
                assert len(rows)==count and len(set(rows))==count and set(rows)==set(analysis)
                assert all(key in original and analysis[key]==original[key] for key in analysis)
                assert not (all_pairs & set(rows))
                ids={row[1] for row in rows}
                assert len(ids)==count and not (all_comment_ids & ids)
                all_pairs.update(rows); all_comment_ids.update(ids); total+=count
                sources.append({'batch':batch,'manifest_count':count,'source_rows':len(rows)})
                for name in ('register-result.json','registered-ready.json','new-ai-input.json','collection.json','account-binding.json'): record(folder/name)
            assert total==state['inserted']
            per_root[suffix]={'manifest_events':len(events),'inserted':total,'source_rows':total}
        assert per_root['23']['inserted']==2550 and per_root['39']['inserted']==205 and len(all_comment_ids)==2755
        assert states['23']['status']=='plan_exhausted' and states['23']['inflight'] is None
        assert states['39']['status']=='outcome_unknown' and states['39']['cursor']==1 and states['39']['next_batch']==40
        partial=roots['39']/'batch-0040/partial-0023.json'; record(partial)
        part=read(partial); partial_comments=comment_map(part['customers'])
        assert len(partial_comments)==62 and part['summary']['usable_comments']==62
        unregistered_batches={}
        for suffix,batch in (('39','batch-0040'),('41','batch-0041'),('42','batch-0042')):
            folder=roots[suffix]/batch
            source='collection:'+str((folder/'collection.json').resolve())
            n=db.execute("SELECT count(*) FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchone()[0]
            receipts=[name for name in ('register-result.json','registered-ready.json','collection.json') if (folder/name).exists()]
            assert n==0 and not receipts
            unregistered_batches[batch]={'source_rows':n,'registration_files':receipts}
        for s in ('41','42'):
            assert states[s]['status']=='outcome_unknown' and states[s]['cursor']==0 and states[s]['next_batch']==int(s)
            assert not (roots[s]/'analysis-manifest.jsonl').exists()
        assert states['39']['inflight']['page']==states['41']['inflight']['page']==states['42']['inflight']['page']==2
        db.rollback()
    result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'read_only':True,
            'ledger_path':str(ledger),'registered_total':len(all_comment_ids),
            'source_rows_total':sum(x['source_rows'] for x in sources),
            'comment_ids_unique_and_nonoverlapping':True,'roots':per_root,'sources':sources,
            'states':{s:state_summary(v) for s,v in states.items()},
            'partial_0040_0023':{'customers':len(part['customers']),'usable_comments':len(partial_comments),
                                 'counted_in_registered_total':False,'pending':part['summary']['pending']},
            'unregistered_batches':unregistered_batches,'sha256':fingerprints}
    output=OUT/'preservation-audit.json'
    with output.open('x',encoding='utf8') as f: json.dump(result,f,ensure_ascii=False,indent=2)
    summary={'status':'pass','registered_total':result['registered_total'],'roots':per_root,
             'source_rows_total':result['source_rows_total'],'states':result['states'],
             'partial_0040_0023':result['partial_0040_0023'],'unregistered_batches':unregistered_batches,
             'full_result':str(output)}
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__': main()
