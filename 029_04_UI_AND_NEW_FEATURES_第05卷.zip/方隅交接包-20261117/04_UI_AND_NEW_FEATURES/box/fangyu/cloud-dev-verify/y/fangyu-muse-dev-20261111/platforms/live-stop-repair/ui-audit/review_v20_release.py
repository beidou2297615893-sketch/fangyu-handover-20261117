from pathlib import Path
import ast,datetime,hashlib,json,re,sys
sys.dont_write_bytecode=True
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/live-stop-repair');H=T/'ui-audit'
C=F/'candidate-unified-v20';J=C/'project';OLD=F/'candidate-unified-v17/project';N=P/'work/ui-native-r57'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def assignment(p,name):
    for n in ast.parse(p.read_text('utf-8-sig')).body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets):return ast.literal_eval(n.value)
    raise AssertionError('Missing assignment '+name)
checks=[]
def check(name,fn):
    try:checks.append({'name':name,'passed':True,'detail':fn()})
    except BaseException as e:checks.append({'name':name,'passed':False,'error':type(e).__name__,'message':str(e)})
pins=read(C/'UNIFIED-PINS.json');staged=read(C/'STAGED.json');R=Path(staged['release']);manifest=read(R/'RELEASE.json')
planfile=F/'entry-v20/CANONICAL-DELEGATION-PREPARED.json';plan=read(planfile)
declared=read(T/'SOURCE-CHANGES.json');before=read(F/'candidate-unified-v17/INPUT-SNAPSHOT.json')['files'];after=read(C/'INPUT-SNAPSHOT.json')['files'];stage=Path(read(C/'INPUT-SNAPSHOT.json')['source'])
def source_changes():
    changes={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
    assert len(changes)==len(declared)==13 and changes=={r['path'] for r in declared}
    for r in declared:
        k=r['path'];assert before.get(k)==r['before'] and after[k]==r['after']==sha(J/k)==sha(stage/k),k
    return {'count':len(changes),'exact_sha256':{r['path']:r['after'] for r in declared},'all_other_input_sources_unchanged':True}
check('exact 13 source changes match declared before/after, stage and frozen bytes',source_changes)
def closure():
    assert len(pins['files'])==2722 and sha(C/'UNIFIED-PINS.json')=='587e8ab7ff526244220013080559ac40a2f0dca6ca49e6ed2c370fc695e469b3'
    names=set()
    for r in pins['files']:
        p=J/r['path'];assert r['path'] not in names;names.add(r['path'])
        assert p.resolve().is_relative_to(J.resolve()) and not p.is_symlink()
        assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],r['path']
    assert pins['component_use_policy']=='pending' and not pins.get('promoted') and not pins.get('compiled_cli_executed')
    return {'count':len(names),'sha256':sha(C/'UNIFIED-PINS.json'),'component_use_policy':'pending'}
check('all 2722 closure pins and pending use policy',closure)
def releases():
    assert manifest['release_id']==staged['release_id']==plan['release_id']=='ui-r57-20261019T083811Z-b90fb0c3'
    assert R==J/'work/ui-native-r57/releases'/manifest['release_id']
    assert sha(R/'RELEASE.json')==staged['manifest_sha256'].lower()==plan['manifest_sha256'].lower()
    names=set()
    for r in manifest['files']:
        p=R/r['path'];assert r['path'] not in names;names.add(r['path'])
        assert p.stat().st_size==r['size'] and sha(p)==r['sha256'].lower(),r['path']
    assert len(names)==staged['files']
    return {'verified_files':len(names),'manifest_sha256':sha(R/'RELEASE.json')}
check('all release manifest bytes/hashes and staged/entry agreement',releases)
def dependencies():
    d=read(R/'resources/backend-dependencies.json')
    for row in d['files']:
        p=J/d['source']/row['path'];assert p.stat().st_size==row['size'] and sha(p)==row['sha256'].lower(),row['path']
    for r in declared:
        k=r['path']
        if k.startswith('work/ui-runtime-r55/src/'):continue
        if k.startswith('work/ui-native-r57/'):p=R/k.removeprefix('work/ui-native-r57/')
        elif k.startswith('work/ui-approved-implementation/ui-preview/'):p=R/'web'/k.removeprefix('work/ui-approved-implementation/ui-preview/')
        else:p=R/'resources/platform-runtime'/k.removeprefix('work/shared-backend-integration/')
        assert sha(p)==r['after'],k
    return {'all_backend_rows':len(d['files']),'all_changed_release_copies_match':True}
check('all backend dependencies plus every changed release copy',dependencies)
def syntax():
    files=[]
    for r in declared:
        if r['path'].endswith('.py'):
            raw=(J/r['path']).read_bytes();compile(raw,str(J/r['path']),'exec');files.append(r['path'])
    assert len(files)==8
    return {'frozen_python_readback_compiled_without_import':files,'bytecode_written':False}
check('eight actual frozen Python source readbacks compile without imports or writes',syntax)
def nested_pins():
    core=J/'work/ui-runtime-r55/src';native=J/'work/ui-native-r57'
    customer=assignment(native/'customer_workbench.py','DEPENDENCY_SHA256')
    for name,value in customer.items():assert sha(core/name)==value.lower(),name
    old=assignment(OLD/'work/ui-native-r57/customer_workbench.py','DEPENDENCY_SHA256')
    assert {k:v for k,v in customer.items() if k!='assistant/customer_list.py'}=={k:v for k,v in old.items() if k!='assistant/customer_list.py'}
    overlay=J/'work/shared-backend-integration/vendor-src/douyin_pipeline_overlay.py'
    assert assignment(overlay,'_PIPELINE_SHA').lower()==sha(core/'core/pipeline.py')
    assert assignment(overlay,'_PAGES_SHA').lower()==sha(core/'core/douyin_pages.py')
    a=ast.parse(overlay.read_text('utf8'));b=ast.parse((OLD/'work/shared-backend-integration/vendor-src/douyin_pipeline_overlay.py').read_text('utf8'))
    def without_pipeline(tree):
        tree.body=[n for n in tree.body if not(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_PIPELINE_SHA' for t in n.targets))];return ast.dump(tree,include_attributes=False)
    assert without_pipeline(a)==without_pipeline(b),'Overlay changed more than exact dependency pin'
    return {'customer_dependency_rows':len(customer),'customer_list_sha256':sha(core/'assistant/customer_list.py'),'pipeline_sha256':sha(core/'core/pipeline.py'),'DY_pages_sha256':sha(core/'core/douyin_pages.py'),'overlay_other_logic_unchanged':True}
check('customer_list and customer-only DY overlay pins match actual sources; overlay guards unchanged',nested_pins)
def new_module_and_copy():
    rel='work/ui-approved-implementation/ui-preview/platform-notice.mjs';module=J/rel
    assert sha(module)=='b982e52e3c52401d86a1f4437294845002932e98391148ac96ec705cd4bb6282'
    assert sha(R/'web/platform-notice.mjs')==sha(module)
    text=module.read_bytes();new='请在这个账号的平台网页按提示完成验证，再回获客页点“继续原任务”；没有验证入口时联系管理员。'.encode()
    old='平台要求人工验证。查看账号页面的提示，完成后回到获客页继续。'.encode()
    assert text.count(new)==1 and text.count('查看账号</button>'.encode())==1
    previous=text.replace(new,old).replace('查看账号</button>'.encode(),'查看平台提示</button>'.encode())
    assert digest(previous)=='72bc8c7c48da886498bcbdd5fd9970d4c47354d44c7bd61bca6e6cae5f0c4a1c','Copy change alters reviewed functionality'
    app=(R/'web/app.mjs').read_text('utf8')
    assert "import {updatePlatformNotice,createCollectionMonitor} from './platform-notice.mjs';" in app
    assert 'read:data=>backend.platform(data),changed:showPlatformNotice' in app
    show=app[app.index('function showPlatformNotice(){'):app.index('const collectionMonitor=')]
    assert not re.search(r'\brender\s*\(',show)
    return {'new_module_in_source_and_web':True,'module_sha256':sha(module),'previous_reviewed_module_sha256':digest(previous),'exact_two_copy_changes_only':True,'independent_banner_callback_no_editor_render':True}
check('new notification module served and pinned; exact two copy-only changes from reviewed functionality',new_module_and_copy)
def ui_review_links():
    ui=J/'work/ui-approved-implementation/ui-preview'
    s=(ui/'pages/reply-connected.mjs').read_text('utf8')
    for add in ('${preview.sourceNotice?`<p class="rp-loading-note">${esc(preview.sourceNotice)}</p>`:\'\'}','${row.sourceNotice?`<small class="rp-loading-note">${esc(row.sourceNotice)}</small>`:\'\'}'):
        assert s.count(add)==1;s=s.replace(add,'')
    assert digest(s.replace('\r\n','\n').encode())=='0dfac2ff17eaa65e25fb833e8a293507c5ab9a743eea452cae0be7e4b738a474'
    a=(ui/'pages/acquire.mjs').read_text('utf8')
    assert digest(a.replace('\n','\r\n').encode())=='184be4fe26efdc35fecdc6eff834562f99707a284362e9fd4f6ea355cd7037be'
    assert sha(ui/'app.mjs')=='03daa04c73b1cb2f01d42fd99987671d0928db8d4c3c06fb08f3643c5b55463d'
    assert sha(ui/'canvas-fit.css')=='a13d6939ac0c4d12ff71418461375a15e628ec0a7c0529b00bd83ac2787a4061'
    return {'preview_and_notice_semantics_match_previous_review_after_lineending_normalization':True,'behavior_suites_rerun':False}
check('prior independently reviewed UI semantics preserved across source newline normalization',ui_review_links)
def preserved():
    assert sha(P/'work/app/company.json')=='bd71d4b7e6b05581702782bda87f0e228c84804decd36a0c4eaf54e0abc6077e'
    assert (J/'work/app/company.json').read_bytes()==(OLD/'work/app/company.json').read_bytes()
    assert sha(N/'state/production-workspace.json')=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
    assert (J/'work/ui-native-r57/state/production-workspace.json').read_bytes()==(N/'state/production-workspace.json').read_bytes()
    prefix='work/speed-collection-worker/component/artifacts/platform-cli-guarded/'
    rows={r['path']:r['sha256'] for r in pins['files'] if r['path'].startswith(prefix)}
    prior={r['path']:r['sha256'] for r in read(F/'candidate-unified-v17/UNIFIED-PINS.json')['files'] if r['path'].startswith(prefix)}
    assert rows==prior
    return {'company_and_binding_unchanged':True,'entire_frozen_CLI_rows_unchanged':len(rows),'CLI_exe_sha256':sha(J/(prefix+'platform-cli.exe')),'purpose_manifest_unchanged':True}
check('original company/state and whole old CLI artifact/use guard preserved',preserved)
def entry():
    assert plan['status']=='PREPARED_NOT_INSTALLED' and plan['installed'] is False
    candidate=Path(plan['launcher']);assert candidate.parent==N and sha(candidate)==plan['launcher_sha256'].lower()
    assert sha(N/'run_workbench.py')==plan['expected_previous_launcher_sha256'].lower()=='b4260f7ae65bf03f0ea5c08100444ec895f70397b6b0e97e5985b6d8fec6a262'
    assert sha(N/'FROZEN.json')==plan['expected_previous_frozen_sha256'].lower()=='112dda7a5157723a2c9572609b5572ab7d73f9b0cfa62ab05831112a8bc06b44'
    assert plan['runtime_project_root']==str(J) and plan['installation_state_root']==str(N/'state')
    raw=candidate.read_text('utf8');compile(raw,str(candidate),'exec')
    assert "candidate-unified-v20/project'" in raw and "module.main(RELEASE, MANIFEST_SHA256, ROOT / 'state', project_root=PROJECT_ROOT)" in raw
    assert "pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)" in raw
    assert "pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)" in raw
    assert plan['full_closure_files_verified']==2722 and plan['full_closure_manifest_sha256'].lower()==sha(C/'UNIFIED-PINS.json')
    assert plan['component_use_policy']=='pending' and not plan['production_cloud_activation'] and not plan['production_data_migration']
    return {'launcher_sha256':sha(candidate),'expected_current_v17_launcher_sha256':sha(N/'run_workbench.py'),'expected_current_v17_frozen_sha256':sha(N/'FROZEN.json'),'original_state_plus_v20_project':True,'not_installed_by_review':True}
check('prepared v20 launcher plus original v17 two-file CAS and state binding',entry)
def installer():
    text=(T/'install_v20.py').read_text('utf8');assert "installer.HERE=F/'entry-v20'" in text and "installer.OUT=F/'candidate-unified-v20'" in text
    base=F.parent/'integration/entry/install_canonical_delegation.py';body=base.read_text('utf8')
    assert "new = {launcher: new_launcher, frozen:" in body and 'exact(path, digest(old[path]))' in body and 'ROLLBACK_CONFLICT' in body
    return {'wrapper_sha256':sha(T/'install_v20.py'),'original_two_file_CAS_sha256':sha(base),'exclusive_backup_and_conflict_rollback':True,'executed':False}
check('original installer still only launcher/FROZEN with CAS, backup and rollback',installer)
report={'status':'PASS_V20_INDEPENDENT_CLOSURE_REVIEW' if all(c['passed'] for c in checks) else 'FAIL','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release_id':plan['release_id'],'checks':checks,'prepared_plan_sha256':sha(planfile),'component_use_policy':'pending','old_behavior_tests_rerun':False,'UI_operations':0,'platform_requests':0,'model_requests':0,'production_writes':0,'real_cookie_read':False,'entry_installed_by_review':False,'real_collection_or_throughput_verified':False}
(H/'V20-CLOSURE-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'checks':len(checks),'passed':sum(c['passed'] for c in checks),'failures':[c for c in checks if not c['passed']],'report_sha256':sha(H/'V20-CLOSURE-REVIEW.json')},ensure_ascii=False,indent=2))
if not all(c['passed'] for c in checks):raise SystemExit(1)
