"""Targeted date notice only; no rerun of prior security/index suites."""
from pathlib import Path
from types import SimpleNamespace,MethodType
from copy import deepcopy
import ast,hashlib,json,re
from datetime import datetime,timezone,timedelta
from check_reply_indexes import run,new

O=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
C=S/'work/ui-native-r57/customer_workbench.py';H=S/'work/ui-runtime-r55/src/assistant/customer_list.py'
tree=ast.parse(C.read_text('utf-8-sig'));cl=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CustomerWorkbench')
methods=[n for n in cl.body if isinstance(n,ast.FunctionDef) and n.name in ('_project','_representative_source')]
for fn in methods:fn.decorator_list=[]
space={'_avatar_url':lambda person:'','_text':lambda value,n:str(value or '')[:n],'_time':lambda value:'','_epoch':lambda value:0,'LEVELS':{'high':('高意向',2,'high')},'CONTACT_LABELS':{'uncontacted':'待处理'},'PLATFORMS':{'xiaohongshu':'小红书'},'datetime':datetime,'timezone':timezone,'timedelta':timedelta}
exec(compile(ast.Module(body=methods,type_ignores=[]),str(C),'exec'),space)
customer=SimpleNamespace(history_type=SimpleNamespace(_top_level=lambda person:'high'),_media_url=lambda *a:'/isolated-saved-media',_rental_evidence=lambda value:[],_financial_fields=lambda value:{})
customer._representative_source=space['_representative_source'];customer._project=MethodType(space['_project'],customer)
ht=ast.parse(H.read_text('utf-8-sig'));hc=next(n for n in ht.body if isinstance(n,ast.ClassDef) and n.name=='CustomerHistory');hb=next(n for n in hc.body if isinstance(n,ast.FunctionDef) and n.name=='_build')
projection=next(v for node in ast.walk(hb) if isinstance(node,ast.Dict) for k,v in zip(node.keys,node.values) if isinstance(k,ast.Constant) and k.value=='lead' and isinstance(v,ast.DictComp))
expr=compile(ast.Expression(body=projection),str(H),'eval')
def comment(ident,status):
    lead={'id':ident,'task_id':'owned-task','platform':'xiaohongshu','content_title':'原帖'+ident,'post_date_status':status}
    projected=eval(expr,{'lead':lead})
    return {'lead_id':ident,'text':'评论'+ident,'post_key':ident,'lead':projected,'intent':{},'note_url':'','created_at':''}
def person(representative,order=('A','B')):
    comments={'A':comment('A','verified'),'B':comment('B','unverified')}
    return {'comments':[comments[key] for key in order],'representative_intent_lead_id':representative,'posts':[],'author_key':'isolated-customer','platform':'xiaohongshu','contact_state':'uncontacted','nickname':'隔离客户'}
results=[]
def check(name,fn):
    try:fn();results.append({'name':name,'status':'PASS'})
    except Exception as error:results.append({'name':name,'status':'FAIL','error':str(error)})
def projected():assert comment('B','unverified')['lead'].get('post_date_status')=='unverified'
check('actual history field projection preserves only the needed post date status',projected)
def source(representative,order,expected):
    result=customer._project(person(representative,order),store_id='store');assert bool(result['sourceNotice']) is expected,(representative,order,result['sourceNotice']);assert result['postTitle']=='原帖'+(representative or order[0])
check('known representative source is not contaminated by another unknown post',lambda:source('A',('A','B'),False))
check('unknown representative source retains its notice beside known other post',lambda:source('B',('A','B'),True))
check('fallback source uses first comment consistently when representative is absent',lambda:source('',('B','A'),True))
def exact_comments():
    result,reads,permissions,accounts=run(new,'mixed-notice');rows=result['comments'];assert rows[0]['sourceNotice']=='';assert rows[1]['sourceNotice'];assert rows[2]['sourceNotice']==''
check('actual reply read emits notice per original lead, not per customer',exact_comments)
report={'status':'PASS_TARGETED_SOURCE_NOTICE' if all(r['status']=='PASS' for r in results) else 'FAIL_TARGETED_SOURCE_NOTICE','at_utc':datetime.now(timezone.utc).isoformat(),'checks':len(results),'passed':sum(r['status']=='PASS' for r in results),'results':results,'source_sha256':{str(path.relative_to(S)).replace('\\','/'):hashlib.sha256(path.read_bytes()).hexdigest() for path in (C,H,new)},'real_HTTP_requests':0,'actual_core_imported':False,'production_writes':0,'UI_operations':0}
(O/'SOURCE-NOTICE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(0 if report['status'].startswith('PASS') else 1)
