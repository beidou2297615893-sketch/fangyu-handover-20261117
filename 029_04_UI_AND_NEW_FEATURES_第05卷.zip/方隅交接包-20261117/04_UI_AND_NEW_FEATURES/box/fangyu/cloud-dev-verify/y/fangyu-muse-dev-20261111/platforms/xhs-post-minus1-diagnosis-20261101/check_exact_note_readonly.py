"""Read the exact target's ordinary note URL once with the existing CLI session."""
from pathlib import Path
from datetime import datetime, timezone
import json
import logging
import sys
from urllib.parse import urlsplit, parse_qs

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
HOME = PROJECT / 'work/xhs-standalone-session/huihuijiang-send-20261101-01'
NOTE = '6ad9e374000000002403ce0a'
UID = '5f469df5000000000101ec0b'


def main():
    logging.disable(logging.CRITICAL)
    destination = ROOT / 'exact-note-readonly-01.json'
    if destination.exists():
        raise RuntimeError('One-time read already recorded; no automatic repeat')
    report = {'at': datetime.now(timezone.utc).isoformat(), 'note_id': NOTE,
              'sender_uid': UID, 'comment_post_requests': 0, 'retry': False,
              'ledger_mutations': 0, 'responses': [], 'state': 'not_started'}
    sys.path.insert(0, str(PROJECT / 'work/xhs-new-task-session-fix-20261029'))
    from managed_session import ManagedClient, account
    from xhs_cli.html_parser import parse_initial_state

    class ExactNoteReader(ManagedClient):
        _ALLOWED = {('GET', 'https://edith.xiaohongshu.com/api/sns/web/v2/user/me'),
                    ('GET', 'https://www.xiaohongshu.com/explore/' + NOTE)}

    client = None
    try:
        client = ExactNoteReader(HOME / '.xiaohongshu-cli/cookies.json', UID, delay=3.0)

        def observe(response):
            item = {'endpoint': 'identity' if response.request.url.path.endswith('/user/me') else 'exact_note_html',
                    'http_status': response.status_code,
                    'verification_header_present': bool(response.headers.get('verifytype') or response.headers.get('verifyuuid'))}
            location = response.headers.get('location')
            if location:
                parsed = urlsplit(location)
                item['redirect_category'] = ('unavailable_page' if '/404' in parsed.path else
                                              'login_page' if 'login' in parsed.path else 'other')
                for key in ('code', 'error_code'):
                    value = parse_qs(parsed.query).get(key, [''])[0]
                    if value.lstrip('-').isdigit():
                        item['redirect_error_code'] = int(value)
            report['responses'].append(item)
            if response.status_code in (461, 471, 429) or item['verification_header_present']:
                raise RuntimeError('Read stopped at platform verification or rate response')

        client._http.event_hooks['response'].append(observe)
        identity = account.identify(client.get_self_info())
        if identity['uid'] != UID or identity['guest'] is not False:
            raise RuntimeError('Wrong account')
        report['identity_verified'] = True
        html = client._fetch_note_html(NOTE)
        state = parse_initial_state(html)
        detail = state.get('note', {}).get('noteDetailMap', {}).get(NOTE)
        if not isinstance(detail, dict):
            report['state'] = 'exact_note_missing_from_server_state'
        else:
            note = detail.get('note')
            report['exact_note_found'] = isinstance(note, dict) and note.get('noteId', note.get('note_id', note.get('id'))) == NOTE
            if report['exact_note_found']:
                report['title'] = note.get('title')
                report['note_type'] = note.get('type')
                report['state'] = 'exact_note_readable'
            else:
                report['state'] = 'exact_note_identity_unproven'
    except Exception as exc:
        report['state'] = 'read_stopped_no_retry'
        report['error_type'] = type(exc).__name__
        if client is not None:
            report['diagnostic'] = account.safe_failure(client, exc)
    finally:
        if client is not None:
            client.close()
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
        print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
