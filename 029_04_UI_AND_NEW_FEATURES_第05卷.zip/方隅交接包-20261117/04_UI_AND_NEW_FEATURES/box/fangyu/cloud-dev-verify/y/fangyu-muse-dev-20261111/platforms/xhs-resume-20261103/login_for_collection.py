"""Explicit user-requested CLI QR login into one isolated collection session."""
from pathlib import Path
import runpy
import sys
import xhs_cli.cookies as storage

project = Path(__file__).resolve().parents[2]
session = project / 'work/xhs-standalone-session/stores15-dedicated-login-20261103-01'
cookie_dir = session / '.xiaohongshu-cli'
cookie_dir.mkdir(parents=True, exist_ok=True)
if (cookie_dir / 'cookies.json').exists():
    raise SystemExit('SESSION_ALREADY_SAVED_NO_RELOGIN')
storage.get_config_dir = lambda: cookie_dir
diagnostics = project / 'work/xhs-standalone-session/diagnostics'
sys.path.insert(0, str(diagnostics))
sys.argv = [str(diagnostics / 'new_login.py'), str(session / 'login-qr.png')]
runpy.run_path(str(diagnostics / 'new_login.py'), run_name='__main__')
