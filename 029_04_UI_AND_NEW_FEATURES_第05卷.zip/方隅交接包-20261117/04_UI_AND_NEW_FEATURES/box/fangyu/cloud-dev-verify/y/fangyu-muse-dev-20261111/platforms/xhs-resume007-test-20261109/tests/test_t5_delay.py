"""T5: delay 默认 >3.0；传入值传到 client_factory；fake 记录 sleep ≥ delay。"""
import json
import os
import sys
import unittest
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SRC_DIR))

import resume007
from tests.fixture_builder import build_valid_fixture, create_ledger
from tests.fakes import FakeLive, FakeOnce, FakeScheduling, FakeClientFactory


class TestDelay(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        self.resume006_root = self.project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
        self.resume006_root.mkdir(parents=True)
        self.ledger = self.project / 'work/shared-acquisition-ledger/shared.sqlite3'
        self.ledger.parent.mkdir(parents=True)
        create_ledger(self.ledger)
        self.stop_today = self.project / 'work/xhs-resume-20261103/stop-today-resume007.json'
        self.stop_today.parent.mkdir(parents=True)
        self.session_home = Path(self.tmp.name) / 'session-home'
        self.session_home.mkdir()
        self.here_dir = Path(self.tmp.name) / 'here'
        self.here_dir.mkdir()

        self.env = {
            'XHS_RESUME007_RESUME006_ROOT': str(self.resume006_root),
            'XHS_RESUME007_LEDGER': str(self.ledger),
            'XHS_RESUME007_STOP_TODAY': str(self.stop_today),
            'XHS_RESUME007_HERE': str(self.here_dir),
            'XHS_RESUME007_PROJECT': str(self.project),
        }
        for k, v in self.env.items():
            os.environ[k] = v

        self.sleep_log = []
        self.live = FakeLive()
        self.once = FakeOnce()
        self.scheduling = FakeScheduling(max_batches=1)
        self.client_factory = FakeClientFactory(
            'test-uid', delay=6.0, sleep_fn=lambda s: self.sleep_log.append(s),
        )
        resume007._LOAD = lambda: (self.live, None, self.once, self.scheduling)
        resume007._CLIENT_FACTORY = self.client_factory
        self.uid = '123456789012345678901234'
        build_valid_fixture(self.resume006_root, self.session_home, self.uid, self.here_dir)

    def tearDown(self):
        for k in self.env:
            os.environ.pop(k, None)
        resume007._LOAD = None
        resume007._CLIENT_FACTORY = None
        self.tmp.cleanup()

    def _run(self, args_list):
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            old = sys.argv
            sys.argv = ['resume007.py'] + args_list
            try:
                code = resume007.main()
            finally:
                sys.argv = old
        return code, f.getvalue().strip()

    def test_default_delay_gt_3(self):
        code, out = self._run(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertEqual(code, 0)
        data = json.loads(out)
        self.assertGreater(data['delay'], 3.0)
        self.assertEqual(data['delay'], 10.0)

    def test_delay_passed_to_client(self):
        delay = 6.5
        code, out = self._run([
            '--uid', self.uid, '--session-home', str(self.session_home),
            '--delay', str(delay), '--execute',
        ])
        self.assertEqual(code, 0, out)
        self.assertEqual(self.client_factory.last_call_delay, delay)
        self.assertTrue(self.client_factory.created_clients)
        client = self.client_factory.created_clients[0]
        self.assertEqual(client.delay, delay)
        # 相邻请求经 throttle；sleep_log 中每项应 ≥ delay（首请求无 sleep）
        for s in client.sleep_log:
            self.assertGreaterEqual(s, delay - 1e-3)

    def test_delay_rejected_if_too_small(self):
        code, out = self._run([
            '--uid', self.uid, '--session-home', str(self.session_home), '--delay', '2.0',
        ])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['reason'], 'delay_too_small')


if __name__ == '__main__':
    unittest.main()
