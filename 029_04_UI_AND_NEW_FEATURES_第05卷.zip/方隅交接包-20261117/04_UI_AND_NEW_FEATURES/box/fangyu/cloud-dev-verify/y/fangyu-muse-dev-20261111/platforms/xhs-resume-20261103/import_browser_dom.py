"""Offline DOM import into the existing shared registrar; preview by default."""
import argparse,hashlib,importlib.util,json,sqlite3
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[1]
LEDGER=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2)
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--apply',action='store_true');a=p.parse_args()
    raw=Path(a.input).resolve();output=Path(a.output).resolve();doc=read(raw)
    spec=importlib.util.spec_from_file_location('dom_recovery_helpers',PROJECT/'work/xhs-partial-registration-recovery-20261029/recover.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    helpers,collector,registrar,selector=m.components()
    account=doc.get('account') or {'uid':doc.get('account_uid'),'proof_source':doc.get('identity_evidence'),'verified_at':doc.get('observed_at')}
    doc.setdefault('captured_at',doc.get('observed_at'));doc.setdefault('source_url',doc.get('url',''))
    if account.get('uid')!='5f469df5000000000101ec0b' or account.get('proof_source')!='browser_dom_profile_link' or not account.get('verified_at'):raise ValueError('browser_account_evidence_required')
    plan=read(PROJECT/'work/xhs-15-store-collection-20261029/keyword-plan.json')
    matches={x.get('source_store') for x in plan['queue'] if x.get('keyword')==doc['keyword']}
    if not doc.get('source_store') and len(matches)==1:doc['source_store']=next(iter(matches))
    ids=collector.merge_ledger_identity_map(collector.load_identity_map(PROJECT/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3',account['uid']),LEDGER)
    users={};seen=set()
    for item in doc['comments']:
        uid=item['customer_uid'];cid=item['comment_id']
        if cid in seen:raise ValueError('duplicate_dom_comment')
        seen.add(cid)
        row={**item,'note_id':doc['note_id'],'post_title':doc.get('post_title',''),'post_text':doc.get('post_text',''),'published_at':item.get('published_at',''),'published_at_raw':item.get('published_at_raw',item.get('time_raw','')),'ip_location':item.get('ip_location',item.get('region_raw','')),'region':item.get('ip_location',item.get('region_raw','')),'ip_location_source':'browser_visible_comment','source_url':doc.get('source_url',''),'captured_at':doc['captured_at'],'parent_relationship':'browser_dom_observed' if item.get('parent_comment_id') else 'not_established','reply_history_checked':False,'post_text_transcription':doc.get('post_text_transcription',''),'post_time_raw':doc.get('post_time_raw',''),'post_region_raw':doc.get('post_region_raw','')}
        row['comment_text']=row['comment_text'].strip()
        if uid not in users:
            users[uid]={'customer_id':ids.get(uid) or registrar._new_customer(uid),'customer_uid':uid,**row,'other_comments':[]}
        else:users[uid]['other_comments'].append(row)
    batch={'schema':'xhs-collected-ai-input-v1','keyword':doc['keyword'],'customers':list(users.values()),'pending':[],'summary':{'customers':len(users),'usable_comments':len(seen)},'collection_account':account,'collection_method':'browser_dom','source_store':doc.get('source_store'),'source_store_is_customer_assignment':False,'raw_evidence':str(raw),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'limits':['reply_history_not_checked','not_analyzed_or_send_authorized','visible_dom_only_not_all_comments_proven']}
    registrar.validate_batch(batch);source='collection:'+str(output/'collection.json')
    preview=registrar.register(LEDGER,batch,ids,source,apply=False)
    if not a.apply:print(json.dumps(preview,ensure_ascii=False));return
    output.mkdir(parents=True,exist_ok=False)
    write(output/'collection.json',batch);write(output/'account-binding.json',account)
    write(output/'registration-started.json',{'source':source,'at':datetime.now(timezone.utc).isoformat(),'automatic_retry':False})
    result=registrar.register(LEDGER,batch,ids,source,apply=True)
    write(output/'register-result.json',{'account':account,'result':result})
    chosen=selector.select_new(batch,LEDGER,output/'collection.json',result['inserted'])
    selected=helpers.comment_rows(chosen)
    with sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro',uri=True) as db:rows=set(db.execute('SELECT customer,comment FROM leads WHERE platform=? AND source=?',('xiaohongshu',source)))
    if rows!=set(selected) or len(rows)!=result['inserted']:raise ValueError('registration_unknown_reconcile_required')
    write(output/'new-ai-input.json',chosen);write(output/'registered-ready.json',{'registered':True,'inserted_comments':result['inserted'],'account_uid':account['uid']})
    event={'at':datetime.now(timezone.utc).isoformat(),'status':'registered_ready_for_classification','account_uid':account['uid'],'inserted_comments':result['inserted'],'registration_source':source,'sha256':hashlib.sha256((output/'new-ai-input.json').read_bytes()).hexdigest(),'collection_method':'browser_dom','source_store':doc.get('source_store'),'note_completion_proven':False}
    (output/'analysis-manifest.jsonl').write_text(json.dumps(event,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
