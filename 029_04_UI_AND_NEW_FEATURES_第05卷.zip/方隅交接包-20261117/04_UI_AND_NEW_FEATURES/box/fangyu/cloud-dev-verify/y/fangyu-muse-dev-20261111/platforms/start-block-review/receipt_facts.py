"""Read only page receipt metadata; never print payloads, URLs or credentials."""
from pathlib import Path
from collections import Counter
import datetime, hashlib, json, sqlite3

here=Path(__file__).resolve().parent
native=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/ui-native-r57')
binding=json.loads((native/'state/production-workspace.json').read_text('utf-8-sig'))
tenant='cloud-'+hashlib.sha256((binding['environment_id']+'\n'+binding['company_id']).encode()).hexdigest()[:24]
root=Path(binding['data_dir'])
con=sqlite3.connect((root/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
con.execute('PRAGMA query_only=ON')
tasks=[json.loads(row[0]) for row in con.execute("SELECT body FROM records WHERE entity='tasks' AND tenant_id=?",(tenant,))]
tasks=sorted((row for row in tasks if row.get('cloud_owner')==binding['owner']),key=lambda row:row.get('created_at',''),reverse=True)[:2]
con.close()
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'access':'read_only','tasks':[]}
for task in tasks:
    receipts=root/'accounts'/tenant/task['account_id']/'.workbench-page-receipts'/task['id']
    facts=[]
    if receipts.is_dir():
        for path in receipts.glob('*.json'):
            row=json.loads(path.read_text('utf-8'))
            fact={key:row[key] for key in ('operation','state','created_at','received_at','updated_at','error_type','wire_allow_attempts','worker_ready','exit_code','process_exited','stderr_bytes') if key in row}
            fact['file']=path.name
            result=row.get('result')
            if isinstance(result,dict):
                fact['returncode']=result.get('returncode')
                fact['stdout_bytes']=len(str(result.get('stdout','')).encode('utf8'))
            if type(row.get('updated_at')) in (int,float) and type(row.get('created_at')) in (int,float):
                fact['elapsed_seconds']=round(row['updated_at']-row['created_at'],3)
            facts.append(fact)
    report['tasks'].append({'taskId':task['id'],'receiptCount':len(facts),'states':dict(Counter(row.get('state') for row in facts)),
        'operations':dict(Counter(row.get('operation') for row in facts)),'unconfirmed':[row for row in facts if row.get('state') not in ('received','acknowledged')],
        'latest':sorted(facts,key=lambda row:row.get('created_at',0),reverse=True)[:3]})
(here/'RECEIPT-FACTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=True))
