"""Run isolated suites, preserve logs; never starts the original application."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
old="import socket,runpy,sys,unittest;from pathlib import Path; socket.socket.connect=lambda *a,**k:(_ for _ in ()).throw(AssertionError('network prohibited'));base=Path(sys.argv[1]);suite=unittest.TestSuite();[suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(v)) for name in ['test_reply_policy.py','test_reply_worker.py'] for v in runpy.run_path(str(base/name)).values() if isinstance(v,type) and issubclass(v,unittest.TestCase)];result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())"
jobs={
    'owned-parent-and-ledger':[sys.executable,'-X','utf8','-B','-m','unittest','discover','-s',str(ROOT/'tests'),'-v'],
    'original-policy-worker':[sys.executable,'-X','utf8','-B','-c',old,str(ROOT/'sender/tests')],
    'original-ledger':[sys.executable,'-X','utf8','-B',str(ROOT/'reference/test_ledger.py')],
}
def run(item):
    name,argv=item
    r=subprocess.run(argv,capture_output=True,encoding='utf-8',timeout=120)
    (ROOT/'evidence'/f'{name}.log').write_text(r.stdout+r.stderr,encoding='utf-8')
    return name,{'returncode':r.returncode,'argv':argv,'log':str(ROOT/'evidence'/f'{name}.log')}
with ThreadPoolExecutor(max_workers=3) as pool:result=dict(pool.map(run,jobs.items()))
(ROOT/'evidence/VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(any(r['returncode'] for r in result.values()))
