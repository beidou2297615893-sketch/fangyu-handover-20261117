"""Rebuild a local, read-only index of browser-observed comments."""
from collections import Counter
from contextlib import closing
import json
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
# Browser-confirmed account UID, not a nickname match.
OWN_UID = '5aa9b337e8ac2b4ab2d21957'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf8')
    tmp.replace(path)


def normalize_browser_raw(path, *, post_date_conflict=None, search_location_not_verified=None):
    raw = load(path)
    note_id = raw['note_id']
    if path.name != note_id + '-browser-raw.json':
        raise ValueError('Raw filename mismatch')
    body_path = path.parent / (note_id + '.json')
    comments_path = path.parent / (note_id + '-comments.json')
    if body_path.exists() or comments_path.exists():
        raise FileExistsError('Normalized files already exist; preserve existing records')
    note = {'note_id': note_id, 'title': raw['title'], 'body': raw['post_text'],
            'author_uid': raw['author_uid'], 'source': raw['source'] if 'source' in raw else 'chrome_visible_dom',
            'captured_local_date': raw.get('captured_local_date', ''),
            'post_date_conflict': raw.get('post_date_conflict', False) if post_date_conflict is None else post_date_conflict,
            'search_location_not_verified': raw.get('search_location_not_verified', False) if search_location_not_verified is None else search_location_not_verified,
            'unread_post_media': True}
    comments = []
    for item in raw['comments']:
        text = item.get('text', '')
        unread = not text.strip() or bool(re.search(r'\[(?:图片|视频)\]', text))
        visible_text = re.sub(r'\[(?:图片|视频)\](?:\d+\s*s)?', '', text, flags=re.I).strip()
        comments.append({'comment_id': item['id'], 'customer_uid': item['uid'], 'nickname': item.get('name', ''),
                         'comment_text': text, 'date_display': item.get('date', ''),
                         'parent_comment_id': item.get('parent', ''),
                         'parent_relationship': 'reply' if item.get('parent') else 'top_level',
                         'unread_media': unread, 'text_evidence_available': bool(visible_text)})
    data = {'note_id': note_id, 'source': raw.get('source', 'chrome_visible_dom'),
            'captured_local_date': raw.get('captured_local_date', ''),
            'displayed_comment_count': raw.get('displayed_comment_count'),
            'complete': raw.get('complete') is True, 'comments': comments}
    save(body_path, note)
    save(comments_path, data)


def refresh(root=ROOT):
    folder = root / 'work/xhs-browser-context-recovery'
    dbpath = root / 'work/shared-acquisition-ledger/shared.sqlite3'
    with closing(sqlite3.connect(dbpath.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)) as db:
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')
        leads = db.execute("SELECT comment,customer,status FROM leads WHERE platform='xiaohongshu'").fetchall()
        observed = db.execute("SELECT platform_uid,canonical FROM collection_uid_observations WHERE platform='xiaohongshu'").fetchall()
        db.rollback()
    by_comment = {}
    for cid, customer, status in leads:
        by_comment.setdefault(cid, []).append({'customer_id': customer, 'status': status})
    known_uids = {uid for uid, _ in observed}
    previous_ids = set(by_comment)
    for source in ('xhs-continuous-runner', 'xhs-collection-candidate', 'xhs-context-controlled'):
        for path in (root / 'work' / source / 'work').glob('**/*ai-input.json'):
            items = load(path)
            if not isinstance(items, list):
                raise ValueError('Invalid existing input: ' + str(path))
            for item in items:
                for row in [item, *item.get('other_comments', [])]:
                    if row.get('comment_id'):
                        previous_ids.add(row['comment_id'])
                    if row.get('customer_uid'):
                        known_uids.add(row['customer_uid'])
    rows, notes, seen = [], [], {}
    for path in sorted(folder.glob('*-comments.json')):
        data = load(path)
        note_id = data['note_id']
        if path.name != note_id + '-comments.json':
            raise ValueError('Note filename mismatch')
        note = load(folder / (note_id + '.json'))
        if note.get('note_id') != note_id or not isinstance(data.get('comments'), list):
            raise ValueError('Note and comments mismatch')
        author_uid = note.get('author_uid', '')
        notes.append({'note_id': note_id, 'complete': data.get('complete') is True,
                      'displayed_comment_count': data.get('displayed_comment_count'),
                      'author_confirmed': bool(author_uid)})
        for item in data['comments']:
            cid, uid = item.get('comment_id'), item.get('customer_uid')
            if not isinstance(cid, str) or not cid or not isinstance(uid, str) or not uid:
                raise ValueError('Comment missing identity')
            if cid in seen:
                if seen[cid] != (note_id, item):
                    raise ValueError('Conflicting duplicate comment ID')
                continue
            seen[cid] = (note_id, item)
            role = 'own' if uid == OWN_UID else ('identity_review' if not author_uid else ('author' if uid == author_uid else 'customer'))
            rows.append({**item, 'note_id': note_id, 'role': role,
                         'previously_stored': cid in previous_ids,
                         'ledger_matches': by_comment.get(cid, []),
                         'uid_seen_in_local_sources': uid in known_uids})
    own_parents = {r.get('parent_comment_id') for r in rows if r['role'] == 'own' and r.get('parent_comment_id')}
    lookup = {r['comment_id']: r for r in rows}
    inputs = []
    for row in rows:
        if row['role'] != 'customer':
            continue
        note = load(folder / (row['note_id'] + '.json'))
        parent = lookup.get(row.get('parent_comment_id', ''), {})
        matches = row['ledger_matches']
        inputs.append({'customer_id': matches[0]['customer_id'] if len(matches) == 1 else '',
                       'customer_uid': row['customer_uid'], 'comment_id': row['comment_id'],
                       'note_id': row['note_id'], 'comment_text': row.get('comment_text', ''),
                       'parent_comment_id': row.get('parent_comment_id', ''),
                       'parent_text': parent.get('comment_text', ''),
                       'parent_relationship': row.get('parent_relationship', ''),
                       'post_title': note.get('title', ''), 'post_text': note.get('body', ''),
                       'published_at': '', 'date_display': row.get('date_display', ''),
                       'region_display': row.get('region_display', ''),
                       'region_display_is_ip_not_customer_demand': True,
                       'unread_media': row.get('unread_media', False),
                       'text_evidence_available': row.get('text_evidence_available', bool(row.get('comment_text', '').strip())),
                       'unread_post_media': note.get('unread_post_media', False),
                       'post_date_conflict': note.get('post_date_conflict', False),
                       'search_location_not_verified': note.get('search_location_not_verified', False),
                       'context_missing': not bool(note.get('body')),
                       'own_reply_visible': row['comment_id'] in own_parents,
                       'previously_stored': row['previously_stored'], 'send_authorized': False})
    counts = Counter(row['role'] for row in rows)
    new_customers = [r for r in rows if r['role'] == 'customer' and not r['previously_stored']]
    report = {'notes': len(notes), 'complete_notes': sum(n['complete'] for n in notes),
              'visible_comments': len(rows), 'previously_stored_comments': sum(r['previously_stored'] for r in rows),
              'not_previously_stored_visible_comments': sum(not r['previously_stored'] for r in rows),
              'new_comments': len(new_customers),
              'new_customer_comments': len(new_customers),
              'new_customer_uid_candidates': len({r['customer_uid'] for r in new_customers if not r['uid_seen_in_local_sources']}),
              'own_visible_replies': counts['own'], 'author_comments': counts['author'],
              'identity_review_comments': counts['identity_review'], 'analysis_input_comments': len(inputs),
              'notes_detail': notes,
              'interpretation': '新增客户仅为本地未匹配的UID候选，身份和意向待核对；历史可见回复不是本次发送回执。'}
    save(folder / 'local-index.json', {'notes': notes, 'comments': rows})
    save(folder / 'ai-input.json', inputs)
    save(folder / 'report.json', report)
    return report


if __name__ == '__main__':
    print(json.dumps(refresh(), ensure_ascii=False, indent=2))
