"""Offline, read-only shared-ledger quota evidence projection.

This is a stop check, never a send authorization or atomic reservation. The
default 200 is a user operating threshold, not an official platform limit.
"""
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3

BEIJING = timezone(timedelta(hours=8))
PLATFORM = 'xiaohongshu'


@dataclass(frozen=True)
class QuotaSnapshot:
    sender_uid: str
    day: str
    threshold: int
    confirmed_sent_today: int
    unknown_today: int
    in_flight_today: int
    unresolved_total: int
    unassigned_total: int
    unconfirmed_receipts: int
    remaining: int
    allowed_for_quota: bool
    reasons: tuple[str, ...]


def _instant(value):
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError('timezone_aware_timestamp_required')
    return value.astimezone(timezone.utc)


def _identifier(value):
    return isinstance(value, str) and bool(value.strip()) and value == value.strip()


def _rows(db):
    required = {
        'reservations': {'token', 'platform', 'customer', 'comment', 'status', 'created'},
        'local_sender_plans': {'token', 'data'},
    }
    for table, columns in required.items():
        info = list(db.execute(f'PRAGMA table_info({table})'))
        if not columns <= {r[1] for r in info} or not any(r[1] == 'token' and r[5] == 1 for r in info):
            raise ValueError('ledger_schema_missing_or_incompatible')
    # Project identifiers and outcome facts in SQLite; no reply/comment body is
    # selected. CASE handles corrupt JSON without leaking its content in errors.
    def field(path):
        return f"CASE WHEN json_valid(p.data) THEN json_extract(p.data,'{path}') END"
    fields = {
        'sender': "COALESCE(" + field('$.plan.sender_uid') + ',' + field('$.local_mode.plan.sender_uid') + ')',
        'attempt': "COALESCE(" + field('$.plan.attempt_id') + ',' + field('$.local_mode.plan.attempt_id') + ')',
        'canonical': "COALESCE(" + field('$.plan.canonical_customer') + ',' + field('$.local_mode.plan.canonical_customer') + ')',
        'plan_comment': "COALESCE(" + field('$.plan.comment_id') + ',' + field('$.local_mode.plan.comment_id') + ')',
        'result_kind': field('$.result.kind'), 'receipt': field('$.result.receipt_id'),
    }
    select = ','.join(v + ' AS ' + k for k, v in fields.items())
    return db.execute('SELECT r.token,r.customer,r.comment,r.status,r.created,' + select +
        ' FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? ORDER BY r.created,r.token', (PLATFORM,)).fetchall()


def _unmapped_legacy_count(db):
    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    sources = []
    if 'leads' in tables:
        sources.append("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND status IN ('sent','unknown','reserved')")
    if 'historical_deliveries' in tables:
        sources.append("SELECT customer,comment FROM historical_deliveries WHERE platform='xiaohongshu' AND delivery_state='submitted'")
    if not sources:
        return 0
    return db.execute('SELECT count(*) FROM (' + ' UNION '.join(sources) + ") h WHERE NOT EXISTS (SELECT 1 FROM reservations r WHERE r.platform='xiaohongshu' AND r.customer=h.customer AND r.comment=h.comment AND r.status IN ('reserved','unknown','sent'))").fetchone()[0]


def inspect_quota(ledger, sender_uid, *, now=None, accepted_events=(), threshold=200, stop_signal=False):
    """Return a fresh consistent snapshot, including updates to old tokens.

    accepted_events is a replayable iterable of safe projections with event=
    accepted, platform=xiaohongshu, sender_uid, attempt_id, receipt_id, and aware
    ISO at. Acceptance requires matching durable ledger receipt AND event time.
    Unknown/submitting records never become success. Errors block, not zero-pass.
    """
    now = _instant(now if now is not None else datetime.now(timezone.utc))
    if not _identifier(sender_uid):
        raise ValueError('actual_sender_uid_required')
    if type(threshold) is not int or threshold <= 0 or type(stop_signal) is not bool:
        raise ValueError('invalid_quota_configuration')
    day = now.astimezone(BEIJING).date()
    reasons = set()
    success = unknown = pending = unresolved = unassigned = unconfirmed = 0
    events = {}
    try:
        for event in accepted_events:
            if not isinstance(event, dict):
                raise ValueError('invalid_acceptance_evidence')
            if event.get('event') != 'accepted' or event.get('platform') != PLATFORM:
                continue
            token, uid, receipt = (event.get(k) for k in ('attempt_id', 'sender_uid', 'receipt_id'))
            if not all(_identifier(x) for x in (token, uid, receipt)):
                raise ValueError('invalid_acceptance_evidence')
            at = _instant(event.get('at'))
            if at > now:
                raise ValueError('acceptance_evidence_in_future')
            fact = (uid, receipt, at)
            if token in events and events[token] != fact:
                raise ValueError('conflicting_acceptance_evidence')
            events[token] = fact
        path = Path(ledger).resolve()
        with closing(sqlite3.connect(path.as_uri()+'?mode=ro', uri=True, timeout=5)) as db:
            db.row_factory = sqlite3.Row
            db.execute('PRAGMA query_only=ON')
            db.execute('BEGIN')
            rows = _rows(db)
            unassigned = _unmapped_legacy_count(db)
            if unassigned:
                reasons.add('unattributed_shared_history')
        seen = set()
        receipts = set()
        for row in rows:
            token, uid, state = row['token'], row['sender'], row['status']
            seen.add(token)
            if state == 'not_sent':
                if token in events or row['result_kind'] == 'platform_receipt':
                    reasons.add('not_sent_conflicts_with_acceptance')
                continue
            if state not in ('sent', 'unknown', 'reserved'):
                reasons.add('unrecognized_ledger_status')
                continue
            if not _identifier(uid):
                unassigned += 1
                reasons.add('unattributed_shared_history')
                continue
            valid_plan = (row['attempt'] == token and row['canonical'] == row['customer'] and
                          row['plan_comment'] == row['comment'])
            if not valid_plan:
                reasons.add('ledger_plan_identity_mismatch')
                continue
            has_receipt = row['result_kind'] == 'platform_receipt' and _identifier(row['receipt'])
            accepted = events.get(token)
            if accepted is not None and (accepted[0] != uid or accepted[1] != row['receipt'] or not has_receipt):
                reasons.add('receipt_event_identity_mismatch')
                accepted = None
            duplicate_receipt = False
            if has_receipt:
                if row['receipt'] in receipts:
                    reasons.add('duplicate_receipt_across_attempts')
                    duplicate_receipt = True
                receipts.add(row['receipt'])
            if uid != sender_uid:
                continue
            if has_receipt and accepted is not None and state in ('unknown', 'sent'):
                if not duplicate_receipt and accepted[2].astimezone(BEIJING).date() == day:
                    success += 1
                continue
            unresolved += 1
            if has_receipt:
                unconfirmed += 1
                reasons.add('receipt_acceptance_time_unproven')
            else:
                reasons.add('account_has_unresolved_submission')
            if type(row['created']) is not int:
                reasons.add('reservation_time_invalid')
                continue
            created = datetime.fromtimestamp(row['created'], timezone.utc)
            if created > now:
                reasons.add('reservation_time_in_future')
            if created.astimezone(BEIJING).date() == day:
                if state == 'reserved':
                    pending += 1
                else:
                    unknown += 1
        if any(fact[0] == sender_uid and token not in seen for token, fact in events.items()):
            reasons.add('accepted_event_without_shared_reservation')
    except (sqlite3.Error, OSError, ValueError, TypeError, OverflowError):
        reasons.add('ledger_or_acceptance_evidence_unavailable')
    if success >= threshold:
        reasons.add('user_daily_threshold_reached')
    if stop_signal:
        reasons.add('caller_business_rejection_stop')
    return QuotaSnapshot(sender_uid, day.isoformat(), threshold, success, unknown, pending,
        unresolved, unassigned, unconfirmed, max(0, threshold-success), not reasons, tuple(sorted(reasons)))


class BusinessRejectionGuard:
    """Explicit caller classifications only; no inference from HTTP/network text.

    Network errors do not increment or clear a business-rejection streak.
    Accepted/other outcomes reset the streak; a stopped guard stays stopped.
    """
    def __init__(self, limit=2):
        if type(limit) is not int or limit <= 0:
            raise ValueError('invalid_rejection_limit')
        self.limit = limit
        self.consecutive = 0
        self.stopped = False

    def observe(self, outcome):
        if outcome not in ('business_rejection', 'network_error', 'accepted', 'other'):
            raise ValueError('explicit_outcome_classification_required')
        if outcome == 'business_rejection':
            self.consecutive += 1
        elif outcome != 'network_error':
            self.consecutive = 0
        self.stopped = self.stopped or self.consecutive >= self.limit
        return self.stopped
