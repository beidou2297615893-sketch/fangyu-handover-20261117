"""Local, idempotent notification inbox; never sends or edits shared ledger."""
import argparse,csv,hashlib,html,json,os,sqlite3,time,shutil
from datetime import datetime,timezone
from pathlib import Path
from client import InboxClient,InboxStop,projection,shape

def now():return datetime.now(timezone.utc).isoformat()
def compact(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def text(x):return str(x) if type(x) in (str,int) else ''
def obj(x):return x if isinstance(x,dict) else {}
def display_time(value):
    from datetime import timedelta
    try:
        stamp=float(value)
        if stamp>1e12:stamp/=1000
        return datetime.fromtimestamp(stamp,timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
    except (ValueError,TypeError,OverflowError,OSError):return value

def receipts(path,uid):
    db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)
    db.execute('PRAGMA query_only=ON')
    found={}
    try:
        for customer,comment,raw in db.execute("SELECT r.customer,r.comment,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token WHERE r.platform='xiaohongshu'"):
            d=json.loads(raw);p=d.get('plan') or obj(d.get('local_mode')).get('plan') or {};r=d.get('result') or {}
            if p.get('sender_uid')!=uid or r.get('kind')!='platform_receipt' or not r.get('receipt_id'):continue
            rid=str(r['receipt_id']);row={'sent_reply_id':rid,'original_comment_id':comment,'customer_id':customer,'customer_uid':text(p.get('customer_uid')),'note_id':text(p.get('note_id')),'sent_text':text(p.get('reply_text') or p.get('text') or p.get('content'))}
            if rid in found and found[rid]!=row:raise InboxStop('ambiguous_ledger_receipt')
            found[rid]=row
    finally:db.close()
    return found

def normalize(item,uid,known):
    p=projection(item);user=obj(p.get('user_info'));comment=obj(p.get('comment') or p.get('comment_info'));target=obj(p.get('target_comment') or p.get('target_comment_info') or p.get('parent_comment') or comment.get('target_comment') or comment.get('target_comment_info') or comment.get('parent_comment'));note=obj(p.get('note') or p.get('note_info'));info=obj(p.get('item_info'))
    refs={text(p.get(k)) for k in ('target_comment_id','parent_comment_id')}|{text(comment.get(k)) for k in ('target_comment_id','parent_comment_id')}|{text(target.get('id') or target.get('comment_id'))};refs.discard('')
    hits=refs&known.keys();match=known[next(iter(hits))] if len(hits)==1 else None
    note_id=text(p.get('note_id') or note.get('id') or note.get('note_id') or info.get('note_id') or (info.get('id') if info.get('type') in ('note','note_info','video','image') else ''))
    target_user=obj(target.get('user_info'));target_uid=text(target_user.get('userid') or target_user.get('user_id') or target_user.get('uid'))
    if match and target_uid and target_uid!=uid:match=None
    if match and note_id and match['note_id'] and note_id!=match['note_id']:match=None
    actor_uid=text(user.get('userid') or user.get('user_id') or user.get('uid'))
    body=text(comment.get('content') or p.get('content'))
    flags=[]
    if any(x in body for x in ('不要发','别发','别骚扰','不需要','不用了','不用啦','不用问了','不考虑')):flags.append('possible_contact_refusal')
    if any(x in body for x in ('租到了','已经租','已租','不找了','找到了','已经找到房','我不租房','不租房了')) and not any(x in body for x in ('还没找到','还没有找到','尚未找到','没有租到','还没租到')):flags.append('possible_need_ended')
    native_id=text(p.get('message_id') or p.get('notification_id') or p.get('id'))
    key=hashlib.sha256((uid+'|'+(native_id if native_id else compact(p) if p else compact(item))).encode()).hexdigest()
    return {'notification_key':key,'account_uid':uid,'notification_id':native_id,'received_at':text(p.get('time') or p.get('timestamp')),'user_uid':actor_uid,'nickname':text(user.get('nickname')),'reply_text':body,'title':text(p.get('title')),'note_id':note_id,'incoming_comment_id':text(comment.get('id') or comment.get('comment_id') or p.get('comment_id')),'association':'exact_reply_id' if match else 'unmatched','matched_sent_reply_id':match['sent_reply_id'] if match else '', 'original_comment_id':match['original_comment_id'] if match else '', 'original_customer_id':match['customer_id'] if match else '', 'our_reply_text':match['sent_text'] if match else '', 'actor_relation':('original_customer' if actor_uid==match.get('customer_uid') else 'other_participant') if match and actor_uid and match.get('customer_uid') else 'unknown','review_flags':flags,'followup_status':'pending_review','observed_at':now(),'field_projection':p}

def open_db(root):
    db=sqlite3.connect(root/'inbox.sqlite3')
    db.execute('CREATE TABLE IF NOT EXISTS notifications(key TEXT PRIMARY KEY, account_uid TEXT NOT NULL, data TEXT NOT NULL, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL)');db.commit();return db

def save_items(db,items,uid,known):
    new=0;linked=0;unrecognized=0
    with db:
        for item in items:
            if not isinstance(item,dict):item={'_unrecognized_type':type(item).__name__,'_hash':hashlib.sha256(compact(item).encode()).hexdigest()}
            row=normalize(item,uid,known);key=row['notification_key'];old=db.execute('SELECT data FROM notifications WHERE key=?',(key,)).fetchone()
            if not row['field_projection']:unrecognized+=1
            if row['association']=='exact_reply_id':linked+=1
            if old:
                previous=json.loads(old[0]);row['followup_status']=previous.get('followup_status','pending_review');db.execute('UPDATE notifications SET data=?,last_seen=? WHERE key=?',(compact(row),now(),key))
            else:new+=1;db.execute('INSERT INTO notifications VALUES(?,?,?,?,?)',(key,uid,compact(row),now(),now()))
    return new,linked,unrecognized

def atomic_json(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)

def render(root,db,status,uid,publish_dir=None):
    rows=[json.loads(x[0]) for x in db.execute('SELECT data FROM notifications WHERE account_uid=? ORDER BY first_seen DESC',(uid,))]
    def sent_time(row):
        try:
            stamp=float(row.get('received_at') or 0)
            return stamp/1000 if stamp>1e12 else stamp
        except (ValueError,TypeError):return 0
    rows.sort(key=sent_time,reverse=True)
    linked=[r for r in rows if r['association']=='exact_reply_id']
    status.update(total_notifications=len(rows),associated_notifications=len(linked),unmatched_notifications=len(rows)-len(linked),updated_at=now(),automatic_reply=False,public_visibility_proven=False)
    atomic_json(root/'status.json',status);atomic_json(root/'notifications.json',rows);atomic_json(root/'followups.json',linked)
    for name,selected in [('待跟进通知.csv',linked),('待确认关联通知.csv',[r for r in rows if r['association']!='exact_reply_id'])]:
        csv_path=root/name;csv_tmp=csv_path.with_suffix('.csv.tmp')
        with csv_tmp.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow(['通知时间','对方昵称','对方回复','关联状态','我们原回复','跟进提醒'])
            for r in selected:
                hints=['可能明确拒绝联系' if x=='possible_contact_refusal' else '可能已找到房' for x in r.get('review_flags',[])]
                vals=[display_time(r['received_at']),r['nickname'],r['reply_text'],'已关联发送记录' if r['association']=='exact_reply_id' else '待人工确认关联',r['our_reply_text'],'；'.join(hints) or '待查看']
                w.writerow(["'"+v if v.startswith(('=','+','-','@')) else v for v in vals])
        os.replace(csv_tmp,csv_path)
    def table(selected):
        return '<table><tr><th>通知时间</th><th>对方</th><th>回复</th><th>关联</th></tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in [display_time(r['received_at']),r['nickname'],r['reply_text'],'已关联' if r['association']=='exact_reply_id' else '待确认'])+'</tr>' for r in selected[:300])+'</table>'
    body='<h2>已关联发送记录的回复</h2>'+table(linked)+'<details><summary>其他待确认关联通知（'+str(len(rows)-len(linked))+'条）</summary>'+table([r for r in rows if r['association']!='exact_reply_id'])+'</details>'
    states={'reading':'正在读取','complete':'本轮读取完成','waiting':'等待下次同步','partial':'部分完成，尚未读尽','stopped':'已停止'}
    reasons={'feed_end':'已读到本轮接口返回的通知末尾','page_limit_reached':'达到本轮页数上限，断点已保留','recent_window_page_limit':'本轮最新通知窗口已读取，历史未读尽','recent_seen_page':'最新通知已衔接到本地已有记录，历史未核全','user_stop':'用户停止','pagination_completion_unproven':'平台未提供可确认的翻页结束标记','notification_schema_unrecognized':'通知结构变化，等待核查','read_failed_no_retry':'读取失败，未自动重试','platform_business_error':'平台返回未成功结果，等待核查','session_update_requires_review':'会话发生变化，等待核查','verification_required':'平台要求验证，等待处理'}
    elapsed=round((datetime.now(timezone.utc)-datetime.fromisoformat(status['started_at'])).total_seconds(),1) if status.get('started_at') else 0
    progress={'账号':'慧慧酱（玉米碴）' if uid=='5f469df5000000000101ec0b' else '已核验账号','账号尾号':uid[-4:],'同步范围':'最新通知窗口，非全历史' if status.get('coverage_scope')=='recent_window' else '历史分页读取','最近同步时间':display_time(datetime.fromisoformat(status['updated_at']).timestamp()),'本轮耗时（秒）':elapsed,'运行状态':states.get(status.get('status'),'等待核查'),'停止原因':reasons.get(status.get('stop_reason'),'需要核查' if status.get('stop_reason') else ''),'已读取页数':status.get('pages_read',0),'本轮读取通知':status.get('received_this_sync',0),'本轮新增通知':status.get('new_this_sync',0),'累计通知':len(rows),'已关联回复':len(linked),'待确认关联':len(rows)-len(linked)}
    page='<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="10"><title>小红书评论回复跟进</title><style>body{font:16px sans-serif;margin:30px;background:#f6f7fa}td,th{padding:12px;border-bottom:1px solid #ddd;text-align:left}table{background:white;width:100%}details{margin-top:24px}</style><h1>小红书评论回复跟进</h1><p>只读同步，不会自动回复。关闭此页面不会停止同步；停止请在任务目录创建 STOP 文件。</p><pre>'+html.escape(json.dumps(progress,ensure_ascii=False,indent=2))+'</pre>'+body
    html_tmp=root/'progress.html.tmp';html_tmp.write_text(page,encoding='utf-8');os.replace(html_tmp,root/'progress.html')
    if publish_dir is not None:
        publish=Path(publish_dir).resolve();publish.mkdir(parents=True,exist_ok=True)
        for name in ('progress.html','待跟进通知.csv','待确认关联通知.csv'):
            dest=publish/name;tmp=dest.with_suffix(dest.suffix+'.tmp');shutil.copyfile(root/name,tmp);os.replace(tmp,dest)

def sync(root,db,session,ledger,uid,max_pages=5,client_factory=InboxClient,recent_only=False,publish_dir=None):
    st={'status':'reading','pages_read':0,'received_this_sync':0,'new_this_sync':0,'unrecognized_items':0,'started_at':now(),'stop_reason':'','coverage_scope':'recent_window' if recent_only else 'historical_pages','history_complete':False};render(root,db,st,uid,publish_dir)
    c=None;cursor='';seen=set()
    checkpoint=root/'checkpoint.json'
    if not recent_only and checkpoint.exists():
        cp=json.loads(checkpoint.read_text(encoding='utf-8'));cursor=cp.get('cursor','') if cp.get('account_uid')==uid else ''
    try:
        known=receipts(ledger,uid);c=client_factory(session,uid);c.verify()
        for page in range(max_pages):
            if (root/'STOP').exists():st.update(status='stopped',stop_reason='user_stop');break
            data=c.get_notification_mentions(cursor=cursor,num=20)
            items=data.get('message_list')
            if not isinstance(items,list):
                atomic_json(root/'schema-review.json',{'shape':shape(data),'reason':'message_list_missing_or_invalid'});raise InboxStop('notification_schema_unrecognized')
            atomic_json(root/'latest-shape.json',shape(data))
            n,linked,unknown=save_items(db,items,uid,known)
            st['pages_read']+=1;st['received_this_sync']+=len(items);st['new_this_sync']+=n;st['unrecognized_items']+=unknown
            render(root,db,st,uid,publish_dir)
            more=data.get('has_more')
            if more is False or more==0:
                if not recent_only:atomic_json(checkpoint,{'account_uid':uid,'cursor':''})
                st.update(status='complete',stop_reason='feed_end',history_complete=not recent_only);break
            if more is not True and more!=1:
                st.update(status='partial',stop_reason='pagination_completion_unproven');break
            if recent_only and items and n==0:
                st.update(status='complete',stop_reason='recent_seen_page');break
            nxt=data.get('strCursor') or data.get('next_cursor') or data.get('cursor')
            if type(nxt) is int:nxt=str(nxt)
            if not isinstance(nxt,str) or not nxt or nxt in seen or nxt==cursor:raise InboxStop('pagination_cursor_invalid')
            seen.add(nxt);cursor=nxt
            if not recent_only:atomic_json(checkpoint,{'account_uid':uid,'cursor':cursor})
        else:st.update(status='complete' if recent_only else 'partial',stop_reason='recent_window_page_limit' if recent_only else 'page_limit_reached')
    except Exception as e:
        st.update(status='stopped',stop_reason=str(e) if type(e) is InboxStop else 'read_failed_no_retry',error_type=type(e).__name__,diagnostic=getattr(c,'safe_error',{}))
    finally:
        if c is not None:c._http.close()
        render(root,db,st,uid,publish_dir)
        with (root/'runs.jsonl').open('a',encoding='utf-8') as f:f.write(compact(st)+'\n')
    return st

def main():
    p=argparse.ArgumentParser();p.add_argument('--session',required=True);p.add_argument('--ledger',required=True);p.add_argument('--uid',required=True);p.add_argument('--output',required=True);p.add_argument('--max-pages',type=int,default=5);p.add_argument('--watch',action='store_true');p.add_argument('--publish-dir');p.add_argument('--recent-only',action='store_true');p.add_argument('--interval',type=int,default=300);a=p.parse_args()
    if not 1<=a.max_pages<=20 or a.interval<60:p.error('max-pages 1..20; interval >=60')
    root=Path(a.output).resolve();root.mkdir(parents=True,exist_ok=True)
    # One account reader lock shared across output folders, no stale-lock deletion.
    lock=Path(__file__).resolve().parent/('account-'+hashlib.sha256(a.uid.encode()).hexdigest()+'.lock')
    try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise SystemExit('account_reader_already_locked')
    os.write(fd,str(os.getpid()).encode());os.close(fd);db=None
    try:
        db=open_db(root)
        while not (root/'STOP').exists():
            st=sync(root,db,a.session,a.ledger,a.uid,a.max_pages,recent_only=a.recent_only,publish_dir=a.publish_dir)
            print(compact({k:st.get(k) for k in ('status','stop_reason','new_this_sync','associated_notifications')}),flush=True)
            if not a.watch or st['status']!='complete':break
            st.update(status='waiting',stop_reason='');render(root,db,st,a.uid,a.publish_dir)
            deadline=time.monotonic()+a.interval
            while time.monotonic()<deadline and not (root/'STOP').exists():time.sleep(1)
        if (root/'STOP').exists():render(root,db,{'status':'stopped','stop_reason':'user_stop'},a.uid,a.publish_dir)
    finally:
        if db is not None:db.close()
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
