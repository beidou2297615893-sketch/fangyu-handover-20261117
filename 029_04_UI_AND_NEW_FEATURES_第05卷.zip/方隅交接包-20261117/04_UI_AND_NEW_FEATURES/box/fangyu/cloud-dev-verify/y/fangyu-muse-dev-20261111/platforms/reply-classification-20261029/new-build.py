"""Build a read-only, review-only new analysis snapshot; never calls a platform."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, importlib.util, json, sqlite3, re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'work/xhs-resident-tone-regeneration/manifest.json'
LEDGER = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
TOPIC = ROOT / 'work/xhs-topic-pool-spike-v2/topic_candidate.py'
load = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
manifest = load(MANIFEST)
spec = importlib.util.spec_from_file_location('topic_candidate_readonly', TOPIC)
topic = importlib.util.module_from_spec(spec)
spec.loader.exec_module(topic)
def sanitize(value):
    """Keep useful public URL paths, drop URL query/fragment and credential fields."""
    if isinstance(value, dict):
        return {k: sanitize(v) for k, v in value.items()
                if k.lower() not in ('reply', 'draft') and
                not re.search(r'cookie|token|authorization|credential|secret|password', k, re.I)}
    if isinstance(value, list): return [sanitize(v) for v in value]
    if isinstance(value, str):
        return re.sub(r'https?://[^\s"<>]+', lambda m: re.split(r'[?#]', m.group(0), 1)[0], value)
    return value
analyses = defaultdict(dict)
source_hashes = {}
for source in manifest['sources']:
    path = Path(source['path'])
    source_hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    for item in load(path):
        if not isinstance(item, dict) or not isinstance(item.get('result'), dict):
            continue
        cid = item.get('comment_id')
        if not cid: continue
        serialized = json.dumps(item, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        key = hashlib.sha256(serialized.encode('utf-8')).hexdigest()
        if key not in analyses[cid]: analyses[cid][key] = {'analysis': sanitize(item), 'sources': []}
        analyses[cid][key]['sources'].append(str(path))

pending = set(manifest['pending_ids'])
candidate_rows = load(ROOT / 'work/xhs-resident-tone-regeneration/candidates.json')
candidate_ids = {r['row']['comment_id'] for r in candidate_rows}
candidate_customers = {r['row']['customer_id'] for r in candidate_rows}
inputs = set()
with sqlite3.connect(LEDGER.as_uri() + '?mode=ro', uri=True) as db:
    for (src,) in db.execute("select distinct source from leads where source like 'collection:%'"):
        inputs.add(Path(src[len('collection:'):]))
    uid_map = dict(db.execute("select platform_uid,canonical from collection_uid_observations where platform='xiaohongshu'"))
    old_high = {r[0] for r in db.execute("select customer from historical_assessments where platform='xiaohongshu' and json_extract(data,'$.interestLevel')='high'")}
for pattern in ('work/xhs-continuous-runner/work/*/new-ai-input.json',
                'work/xhs-standalone-session/collection-live/batch-*/new-ai-input.json',
                'work/xhs-three-stage-integration/live-consumer/batch-*/input.json'):
    inputs.update(ROOT.glob(pattern))
inputs.add(ROOT / 'work/xhs-browser-context-recovery/batch-001-ai-input.json')
inputs.add(ROOT / 'work/xhs-context-controlled/work/live-20261028-larger-43/ai-input.json')
inputs.add(ROOT / 'work/xhs-continuous-runner/work/live-20261028-sample/batch-0001/context-and-ai/ai-input.json')
fields = ('customer_id','customer_uid','comment_id','note_id','comment_text','parent_text',
          'parent_comment_id','parent_relationship','post_title','post_text','published_at','missing_context',
          'identity_evidence','context_missing')
observations = defaultdict(dict)
target = set(analyses) | pending
def add(row, path):
    if not isinstance(row, dict) or row.get('comment_id') not in target: return
    data = sanitize({k: row[k] for k in fields if k in row})
    key = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    digest = hashlib.sha256(key.encode('utf8')).hexdigest()
    if digest not in observations[row['comment_id']]: observations[row['comment_id']][digest] = {'data': data, 'sources': []}
    observations[row['comment_id']][digest]['sources'].append(str(path))
for path in sorted(inputs):
    if not path.exists(): continue
    value = load(path)
    items = value.get('customers', []) if isinstance(value, dict) else value
    if not isinstance(items, list): continue
    for parent in items:
        if not isinstance(parent, dict): continue
        add(parent, path)
        for child in parent.get('other_comments', []) or []:
            if not isinstance(child, dict): continue
            # Inherit only shared post/customer identifiers, never the parent's own comment or reply context.
            merged = {k: parent[k] for k in ('customer_id','customer_uid','note_id','post_title','post_text') if k in parent}
            merged.update(child)
            add(merged, path)
for entry in candidate_rows: add(entry['row'], ROOT / 'work/xhs-resident-tone-regeneration/candidates.json')

output = []
for cid in sorted(target):
    versions = list(analyses.get(cid, {}).values())
    obs = list(observations.get(cid, {}).values())
    texts = sorted({o['data'].get('comment_text','') for o in obs if o['data'].get('comment_text','')})
    topic_results = [topic.classify({'source_comment_id': cid, 'text': text})['topic_analysis'] for text in texts]
    interests = sorted({v['analysis']['result'].get('interest','unknown') for v in versions})
    customer_ids = sorted({v['analysis'].get('customer_id','') for v in versions if v['analysis'].get('customer_id')} | {o['data'].get('customer_id','') for o in obs if o['data'].get('customer_id')})
    uids = sorted({o['data'].get('customer_uid','') for o in obs if o['data'].get('customer_uid')})
    mapped = {uid_map[u] for u in uids if u in uid_map}
    output.append({'comment_id':cid, 'customer_ids':customer_ids,'customer_uids':uids,
       'analysis_versions':versions, 'interest_versions':interests,'interest_conflict':len(interests)>1,
       'snapshot_high_or_super_high': bool({'high','super_high'} & set(interests)),
       'selected_candidate_comment': cid in candidate_ids,
       'selected_candidate_customer': bool(set(customer_ids) & candidate_customers),
       'pending_analysis': cid in pending, 'input_observations':obs,
       'comment_text_variants':texts,'topic_candidates_by_text':topic_results,
       'old_high_canonical_overlap':bool((set(customer_ids)|mapped)&old_high),
       'context_status':{'text_found':bool(texts),
          'post_title_found':any(o['data'].get('post_title') for o in obs),
          'post_body_found':any(o['data'].get('post_text') for o in obs),
          'parent_text_found':any(o['data'].get('parent_text') for o in obs),
          'uid_found':bool(uids), 'multiple_customer_ids':len(customer_ids)>1,
          'multiple_uid':len(uids)>1,'multiple_comment_texts':len(texts)>1},
       'classification_status':'词面候选，待语义及上下文复核', 'eligible_to_reply':False})
summary = {'manifest_source_files':len(source_hashes),'manifest_source_sha256':source_hashes,
    'manifest_source_rows':manifest['source_rows'],'manifest_analysed_comments':manifest['analysed_comments'],
    'manifest_pending_comments':manifest['pending_analysis_comments'],'manifest_high_comments':manifest['high_super_high_comments'],
    'manifest_selected_customers':manifest['selected_unique_customers'],
    'unique_comment_rows':len(output),'analysis_unique_comments':len(analyses),
    'pending_ids':len(pending),'analysis_pending_overlap':len(set(analyses)&pending),
    'high_comments_any_version':sum(x['snapshot_high_or_super_high'] for x in output),
    'high_customer_ids_any_version':len({v['analysis']['customer_id'] for x in output for v in x['analysis_versions'] if v['analysis']['result'].get('interest') in ('high','super_high') and v['analysis'].get('customer_id')}),
    'interest_conflicts':sum(x['interest_conflict'] for x in output),
    'candidate_comments':len(candidate_ids),'candidate_customers':len(candidate_customers),
    'observation_coverage':{k:sum(x['context_status'][k] for x in output) for k in ('text_found','post_title_found','post_body_found','parent_text_found','uid_found','multiple_customer_ids','multiple_uid','multiple_comment_texts')},
    'high_observation_coverage':{k:sum(x['context_status'][k] for x in output if x['snapshot_high_or_super_high']) for k in ('text_found','post_title_found','post_body_found','parent_text_found','uid_found')},
    'topic_counts_first_text':dict(Counter(t for x in output if x['topic_candidates_by_text'] for t in x['topic_candidates_by_text'][0]['topics'])),
    'topic_rule_version':topic.RULE_VERSION,'topic_semantics':'仅评论自身词面候选，可能漏检或误判；不可用于发送资格',
    'platform_calls':0,'source_or_ledger_writes':0,'automatic_drafts':0}
OUT.mkdir(parents=True, exist_ok=True)
with (OUT/'new-snapshot.jsonl').open('w',encoding='utf-8',newline='\n') as f:
    for row in output:f.write(json.dumps(row,ensure_ascii=False)+'\n')
with (OUT/'new-summary.json').open('w',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='manifest_source_sha256'},ensure_ascii=False,indent=2))
