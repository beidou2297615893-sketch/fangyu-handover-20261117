"""Offline rehearsal with an exact candidate copy and a synthetic client.
No live adapter or platform access. Temporary data stays in this directory.
"""
from contextlib import closing
import json
from pathlib import Path
import socket
import subprocess
import sys
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import account_switch as candidate
import collect_once
import scheduler

HERE=Path(__file__).resolve().parent

class SyntheticClient:
    def __init__(self,page,empty=False,error=False):
        self.page=page; self.empty=empty; self.error=error; self.calls=[]
        self.cookies={'a1':'synthetic','web_session':'synthetic'}
    def get_self_info(self):
        self.calls.append('identity'); return {'user_id':'fixture-account','guest':False}
    def search_notes(self,**kwargs):
        self.calls.append('search')
        return {'items': [] if self.empty else [{'id':f'note-{self.page}', 'xsec_token':'synthetic', 'note_card':{'title':'fixture'}}]}
    def get_comments(self,note_id,**kwargs):
        self.calls.append('comments')
        if self.error: raise TimeoutError('synthetic secret never log')
        return {'comments':[{'id':f'comment-{self.page}','content':'合成求租','user_info':{'user_id':'user-1'},
                             'create_time':1700000000,'ip_location':'上海'}], 'has_more':False}

class OfflineAdapter:
    def __init__(self,root,ledger,source,*,empty_pages=(),fail_pages=()):
        self.root=root; self.ledger=ledger; self.source=source
        self.empty_pages=set(empty_pages); self.fail_pages=set(fail_pages); self.clients=[]
    def run(self,batch,keyword,page,remaining):
        client=SyntheticClient(page,page in self.empty_pages,page in self.fail_pages)
        self.clients.append(client)
        history=collect_once.history_index([self.root],ledger=self.ledger)
        result=candidate.run_batch(workspace=self.root,batch_name=batch,client=client,ledger=self.ledger,
            source_db=self.source,keyword=keyword,search_page=page,task='离线测试',operator=None,
            identity_loader=lambda *_:{},known_notes=history['completed_notes'],
            known_comments=history['known_comments'],history_snapshot=history,max_notes=2,max_pages=1)
        directory=self.root/batch
        registered=json.loads((directory/'registered-ready.json').read_text(encoding='utf8'))
        receipt=json.loads((directory/'register-result.json').read_text(encoding='utf8'))
        analysis=json.loads((directory/'new-ai-input.json').read_text(encoding='utf8'))
        count=result['result']['inserted']
        assert registered['registered'] is True and registered['inserted_comments']==count
        assert receipt['result']['inserted']==count and receipt['account']['uid']=='fixture-account'
        assert sum(1+len(x['other_comments']) for x in analysis)==count
        return {'status':'registered','inserted':count,'analysis_input':f'{batch}/new-ai-input.json'}

class RealCandidateRehearsal(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=HERE/'runtime'); self.root=Path(self.tmp.name)
        self.ledger=self.root/'fixture.sqlite3'; self.source=self.root/'fixture-source.sqlite3'
        self.source.write_bytes(b'synthetic')
        with closing(sqlite3.connect(self.ledger)) as db:
            db.executescript('''CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
                CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT);
                CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,PRIMARY KEY(platform,alias));
                CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,delivery_state TEXT);
                CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));''')
        self.guard=patch.object(socket.socket,'connect',side_effect=AssertionError('Network forbidden')); self.guard.start()
    def tearDown(self): self.guard.stop(); self.tmp.cleanup()
    def init(self,target=2):
        scheduler.initialize(self.root,[{'keyword':'合成求租','page':5},{'keyword':'合成求租','page':6}],first_batch=20,target=target)
        return OfflineAdapter(self.root,self.ledger,self.source)
    def test_real_candidate_two_batches_receipts_and_analysis(self):
        adapter=self.init(); state=scheduler.run(self.root,adapter)
        self.assertEqual(state['status'],'target_reached'); self.assertEqual(state['inserted'],2)
        self.assertEqual([x.page for x in adapter.clients],[5,6])
        with closing(sqlite3.connect(self.ledger)) as db:
            rows=db.execute('SELECT comment,source FROM leads ORDER BY comment').fetchall()
        self.assertEqual([x[0] for x in rows],['comment-5','comment-6'])
        for n in (20,21):
            folder=self.root/f'batch-{n:04}'
            self.assertTrue((folder/'account-audit.jsonl').is_file())
            ai=json.loads((folder/'new-ai-input.json').read_text(encoding='utf8'))
            self.assertEqual(ai[0]['ip_location'],'上海'); self.assertTrue(ai[0]['published_at'])
    def test_synthetic_checkpoint_reaches_10000_and_stops(self):
        adapter=self.init(target=10000)
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        state['inserted']=9999  # Synthetic checkpoint, not a real ledger reconciliation.
        (self.root/'state.json').write_text(json.dumps(state),encoding='utf8')
        outcome=scheduler.run(self.root,adapter)
        self.assertEqual(outcome['status'],'target_reached'); self.assertEqual(outcome['inserted'],10000)
        self.assertEqual(outcome['over_target'],0); self.assertEqual(len(adapter.clients),1)
    def stage_committed_unaccounted(self):
        adapter=self.init()
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        start={'batch':'batch-0020','keyword':'合成求租','page':5,'remaining':2}
        state['inflight']=start; state['status']='inflight'
        (self.root/'state.json').write_text(json.dumps(state),encoding='utf8')
        scheduler._event(self.root,'batch_started',**start)
        adapter.run('batch-0020','合成求租',5,2)
        return adapter
    def test_reconciliation_once_then_resume(self):
        self.stage_committed_unaccounted()
        self.assertTrue(hasattr(scheduler,'reconcile_offline'))
        outcome=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(outcome['status'],'reconciled'); self.assertEqual(outcome['inserted'],1)
        self.assertEqual(outcome['cursor'],1); self.assertIsNone(outcome['inflight'])
        self.assertEqual(scheduler.reconcile_offline(self.root,self.ledger)['status'],'nothing_to_reconcile')
        resumed=OfflineAdapter(self.root,self.ledger,self.source)
        result=scheduler.run(self.root,resumed)
        self.assertEqual(result['status'],'target_reached'); self.assertEqual(result['inserted'],2)
        self.assertEqual([x.page for x in resumed.clients],[6])
    def test_reconciliation_refuses_missing_evidence_without_advancing(self):
        self.stage_committed_unaccounted(); (self.root/'batch-0020'/'registered-ready.json').unlink()
        self.assertTrue(hasattr(scheduler,'reconcile_offline'))
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'outcome_unknown'); self.assertEqual(result['inserted'],0)
        self.assertIsNotNone(result['inflight'])
    def test_reconciliation_refuses_ledger_or_analysis_mismatch(self):
        self.stage_committed_unaccounted()
        (self.root/'batch-0020'/'new-ai-input.json').write_text('[]',encoding='utf8')
        self.assertTrue(hasattr(scheduler,'reconcile_offline'))
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'outcome_unknown'); self.assertEqual(result['inserted'],0)
        self.assertIsNotNone(result['inflight'])
    def test_reconciliation_refuses_account_conflict(self):
        self.stage_committed_unaccounted()
        path=self.root/'batch-0020'/'registered-ready.json'
        ready=json.loads(path.read_text(encoding='utf8')); ready['account_uid']='other'
        path.write_text(json.dumps(ready),encoding='utf8')
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'outcome_unknown'); self.assertEqual(result['inserted'],0)
    def test_recovery_event_before_state_update_is_idempotent(self):
        self.stage_committed_unaccounted()
        start={'batch':'batch-0020','keyword':'合成求租','page':5,'remaining':2}
        scheduler._event(self.root,'batch_recovered',**start,inserted=1,account_uid='fixture-account',analysis_input='batch-0020/new-ai-input.json')
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'reconciled'); self.assertEqual(result['inserted'],1)
        recovered=[e for e in scheduler.read_events(self.root) if e['kind']=='batch_recovered']
        self.assertEqual(len(recovered),1)
    def test_reconciliation_refuses_candidate_lock(self):
        self.stage_committed_unaccounted(); (self.root/'.account-switch.lock').mkdir()
        self.assertEqual(scheduler.reconcile_offline(self.root,self.ledger)['status'],'lock_busy')
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        self.assertEqual(state['inserted'],0); self.assertIsNotNone(state['inflight'])
    def test_reconciliation_rejects_real_or_outside_ledger(self):
        self.stage_committed_unaccounted()
        with self.assertRaises(ValueError): scheduler.reconcile_offline(self.root,HERE/'scheduler.py')
    def test_reconciliation_bad_receipt_shape_is_unknown(self):
        self.stage_committed_unaccounted()
        (self.root/'batch-0020'/'registered-ready.json').write_text('[]',encoding='utf8')
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'outcome_unknown'); self.assertEqual(result['inserted'],0)
    def test_reconciliation_conflicting_recovery_event_is_unknown(self):
        self.stage_committed_unaccounted()
        start={'batch':'batch-0020','keyword':'合成求租','page':5,'remaining':2}
        scheduler._event(self.root,'batch_recovered',**start,inserted=1,account_uid='wrong',analysis_input='wrong')
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'outcome_unknown'); self.assertEqual(result['inserted'],0)
    def test_state_write_failure_after_recovery_event_remains_recoverable(self):
        self.stage_committed_unaccounted()
        with patch.object(scheduler,'_replace',side_effect=OSError('fixture failure')):
            unknown=scheduler.reconcile_offline(self.root,self.ledger)
            self.assertEqual(unknown['status'],'outcome_unknown'); self.assertEqual(unknown['inserted'],0)
            self.assertIsNotNone(unknown['inflight'])
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        self.assertEqual(state['inserted'],0); self.assertIsNotNone(state['inflight'])
        self.assertEqual(scheduler.reconcile_offline(self.root,self.ledger)['inserted'],1)
        self.assertEqual(len([e for e in scheduler.read_events(self.root) if e['kind']=='batch_recovered']),1)
    def test_zero_insert_registration_reconciles_without_false_count(self):
        adapter=self.init()
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        start={'batch':'batch-0020','keyword':'合成求租','page':5,'remaining':2}
        state['inflight']=start; state['status']='inflight'
        (self.root/'state.json').write_text(json.dumps(state),encoding='utf8')
        scheduler._event(self.root,'batch_started',**start)
        adapter.empty_pages={5}; adapter.run('batch-0020','合成求租',5,2)
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'reconciled'); self.assertEqual(result['inserted'],0); self.assertEqual(result['cursor'],1)
    def test_registered_event_before_state_update_does_not_double_count(self):
        self.stage_committed_unaccounted()
        start={'batch':'batch-0020','keyword':'合成求租','page':5,'remaining':2}
        scheduler._event(self.root,'batch_registered',**start,inserted=1,analysis_input='batch-0020/new-ai-input.json')
        result=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(result['status'],'reconciled'); self.assertEqual(result['inserted'],1)
        self.assertEqual(scheduler.reconcile_offline(self.root,self.ledger)['status'],'nothing_to_reconcile')
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        self.assertEqual(state['inserted'],1)
    def test_process_exit_after_commit_can_reconcile_once(self):
        self.init()
        state=json.loads((self.root/'state.json').read_text(encoding='utf8'))
        start={'batch':'batch-0020','keyword':'合成求租','page':5,'remaining':2}
        state['inflight']=start; state['status']='inflight'
        (self.root/'state.json').write_text(json.dumps(state),encoding='utf8')
        scheduler._event(self.root,'batch_started',**start)
        script="""import os, socket, sys
from pathlib import Path
from unittest.mock import patch
from test_offline_integration import OfflineAdapter
with patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):
    OfflineAdapter(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])).run('batch-0020','合成求租',5,2)
os._exit(17)
"""
        proc=subprocess.run([sys.executable,'-B','-X','utf8','-c',script,str(self.root),str(self.ledger),str(self.source)],cwd=HERE,capture_output=True,timeout=20)
        self.assertEqual(proc.returncode,17,proc.stderr.decode('utf8','replace'))
        outcome=scheduler.reconcile_offline(self.root,self.ledger)
        self.assertEqual(outcome['status'],'reconciled'); self.assertEqual(outcome['inserted'],1)
        self.assertEqual(scheduler.reconcile_offline(self.root,self.ledger)['status'],'nothing_to_reconcile')
    def test_actual_candidate_fault_stops_and_never_retries(self):
        adapter=self.init(); adapter.fail_pages={5}
        state=scheduler.run(self.root,adapter); self.assertEqual(state['status'],'outcome_unknown')
        self.assertEqual(len(adapter.clients),1)
        self.assertTrue((self.root/'batch-0020'/'failure-diagnostic.json').is_file())
        restarted=OfflineAdapter(self.root,self.ledger,self.source)
        self.assertEqual(scheduler.run(self.root,restarted)['status'],'outcome_unknown')
        self.assertEqual(restarted.clients,[])
    def test_candidate_lock_busy_never_touches_client(self):
        adapter=self.init(); (self.root/'.account-switch.lock').mkdir()
        state=scheduler.run(self.root,adapter); self.assertEqual(state['status'],'outcome_unknown')
        self.assertEqual(adapter.clients[0].calls,[])
    def test_empty_pages_are_not_claimed_globally_exhausted(self):
        adapter=self.init(); adapter.empty_pages={5,6}
        state=scheduler.run(self.root,adapter)
        self.assertEqual(state['status'],'plan_exhausted'); self.assertEqual(state['inserted'],0)
        self.assertEqual([x.page for x in adapter.clients],[5,6])
        self.assertEqual(json.loads((self.root/'batch-0020'/'new-ai-input.json').read_text()),[])

if __name__=='__main__': unittest.main()









