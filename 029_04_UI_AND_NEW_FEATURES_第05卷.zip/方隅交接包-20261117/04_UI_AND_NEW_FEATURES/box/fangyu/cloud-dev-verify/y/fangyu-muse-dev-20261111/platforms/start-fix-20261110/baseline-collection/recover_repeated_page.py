"""Close only a verified repeated comment stream locally; never retry it."""
import datetime,json,pathlib,sqlite3
ROOT=pathlib.Path(__file__).resolve().parent
REQUEST='d90ec76b-1434-42ad-aa84-44e2d4b228c7'

def main():
    controlpath=ROOT/'runner-live-v2/control.json'
    before=controlpath.read_bytes();control=json.loads(before)
    assert control.get('pending') is None and control.get('stopped')=='ledger_unknown'
    assert not list(ROOT.glob('runner-lease-*'))
    database=ROOT/'runtime/collection.sqlite3'
    backup=ROOT/('repeated-page-backup-'+REQUEST);backup.mkdir()
    (backup/'control.json').write_bytes(before)
    with sqlite3.connect(database) as db,sqlite3.connect(backup/'collection.sqlite3') as dst:db.backup(dst)
    with sqlite3.connect(database) as db:
        db.row_factory=sqlite3.Row;db.execute('BEGIN IMMEDIATE')
        h=db.execute('select * from account_halts').fetchall()
        assert len(h)==1 and h[0]['request_id']==REQUEST and h[0]['state']=='unknown'
        r=db.execute('select * from attempts where request_id=?',(REQUEST,)).fetchone()
        s=json.loads(r['spec']);response=json.loads(r['response']);v=response['value']
        assert r['state']=='unknown' and r['added']==0 and s['kind']=='comments'
        assert response['transport_error']=='same_items_page_repeated_with_new_cursor'
        assert response['ok'] is True and response['connection']==s['connection_id'] and v['status_code']==0
        ids=sorted({x['cid'] for x in v['comments']});assert ids
        matches=[]
        for old in db.execute("select * from attempts where state='parsed'"):
            os=json.loads(old['spec'])
            if all(os.get(k)==s[k] for k in ('account_uid','kind','target')):
                ov=json.loads(old['response'])['value']
                if sorted({x['cid'] for x in ov.get('comments') or []})==ids:matches.append(old['request_id'])
        assert matches
        fields=('scan_id','account_uid','kind','target','store_id','keyword');scope=tuple(s[k] for k in fields)
        cp=db.execute('select * from scan_streams where scan_id=? and account_uid=? and kind=? and target=? and store_id=? and keyword=?',scope).fetchone()
        assert cp and cp['cursor']==s['cursor'] and not cp['exhausted']
        db.execute('insert into recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) values(?,?,?,?,?,?)',
          (s['account_uid'],REQUEST,'Codex本地重复页核验','返回的全部20个评论ID与先前已解析页完全相同；该作品停止翻页并保留当前游标，不重发该请求；原异常保留。匹配记录：'+','.join(matches),'用户持续采集及不得重复已采页面要求',datetime.datetime.now(datetime.timezone.utc).isoformat()))
        db.execute('update scan_streams set exhausted=1 where scan_id=? and account_uid=? and kind=? and target=? and store_id=? and keyword=?',scope)
        db.execute('delete from account_halts where account_uid=? and request_id=?',(s['account_uid'],REQUEST))
        assert controlpath.read_bytes()==before
        db.commit()
    control['stopped']=None
    temp=controlpath.with_suffix('.repeated.tmp');temp.write_text(json.dumps(control,ensure_ascii=False),encoding='utf8');temp.replace(controlpath)
    print('Repeated stream closed locally; original evidence preserved; no network requests.')

if __name__=='__main__':main()
