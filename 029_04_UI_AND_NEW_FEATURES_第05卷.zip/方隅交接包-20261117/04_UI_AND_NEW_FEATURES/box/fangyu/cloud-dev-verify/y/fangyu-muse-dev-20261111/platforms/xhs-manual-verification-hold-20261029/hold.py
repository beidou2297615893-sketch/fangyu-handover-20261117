"""Offline-first isolated manual verification hold candidate."""

def wrap_response_check(original, verification_error, wait_for_person, emit):
    def wrapped(response):
        try:
            return original(response)
        except verification_error:
            emit('verification_required')
            wait_for_person(response)
            raise
    return wrapped


def wait_until_closed(response):
    """Keep this same live page open until its owner closes it.

    No navigation, response resubmission, solving or login continuation.
    """
    page = response.frame.page
    if not page.is_closed():
        page.wait_for_event('close', timeout=0)


def run(run_home):
    import json
    import logging
    import os
    from datetime import datetime, timezone
    from pathlib import Path
    import qrcode
    import xhs_cli.cookies as cookie_storage
    import xhs_cli.qr_login as qr
    from xhs_cli.exceptions import NeedVerifyError

    run_home = Path(run_home).resolve()
    run_home.mkdir(parents=True, exist_ok=False)
    cookie_dir = run_home / '.xiaohongshu-cli'
    cookie_dir.mkdir()
    cookie_storage.get_config_dir = lambda: cookie_dir
    logging.disable(logging.CRITICAL)
    receipt = run_home / 'events.jsonl'
    def emit(event):
        permitted = {'qr_ready','scan_detected','phone_confirmed',
                     'verification_required','stopped','login_saved','stopped_other'}
        if event not in permitted:
            raise ValueError('unexpected event')
        with receipt.open('a', encoding='utf8') as stream:
            stream.write(json.dumps({'event':event,'at':datetime.now(timezone.utc).isoformat()})+'\n')
            stream.flush()
            os.fsync(stream.fileno())
        print(event, flush=True)
    def show_qr(value):
        qrcode.make(value).save(run_home / 'login-qr.png')
        emit('qr_ready')
        return True
    def status(message):
        if 'Scanned!' in message:
            emit('scan_detected')
        elif 'Login confirmed!' in message:
            emit('phone_confirmed')
    qr._display_qr_in_terminal = show_qr
    qr._raise_for_browser_response = wrap_response_check(
        qr._raise_for_browser_response, NeedVerifyError, wait_until_closed, emit)
    try:
        qr._browser_assisted_qrcode_login(on_status=status)
        emit('login_saved')
        return 0
    except NeedVerifyError:
        emit('stopped')
        return 2
    except (Exception, KeyboardInterrupt):
        emit('stopped_other')
        return 1


if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        raise SystemExit('A fresh run directory is required')
    raise SystemExit(run(sys.argv[1]))
