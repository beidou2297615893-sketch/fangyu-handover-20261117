import argparse
from contextlib import closing, redirect_stdout, redirect_stderr
from io import StringIO
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import standalone_cli as cli


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.root = Path(self.tmp.name)
        self.db = self.root / 'outside.sqlite3'
        self.batch = self.root / 'batch.json'
        self.rows = [dict(attempt_id='a', sequence=1, text='一',customer_id='c1',customer_uid='u1',comment_id='m1'), dict(attempt_id='b', sequence=2, text='二',customer_id='c2',customer_uid='u2',comment_id='m2')]
        self.batch.write_text(json.dumps({'schema':'xhs-local-plan-v1', 'count':2, 'rows':self.rows}), encoding='utf-8')
        with closing(sqlite3.connect(self.db)) as db:
            db.executescript('CREATE TABLE reservations(token TEXT,status TEXT,platform TEXT,customer TEXT,comment TEXT); CREATE TABLE local_sender_plans(token TEXT,data TEXT); CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,comment TEXT,delivery_state TEXT); CREATE TABLE leads(platform TEXT,customer TEXT,comment TEXT,status TEXT);')

    def tearDown(self): self.tmp.cleanup()

    def add(self, token, state, result=None, customer=None, uid=None, comment=None, platform='xiaohongshu'):
        row=next((r for r in self.rows if r['attempt_id']==token),self.rows[0])
        customer=customer or row['customer_id']; uid=uid or row['customer_uid']; comment=comment or row['comment_id']
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?)', (token, state,platform,customer,comment))
            if result is not None:
                db.execute('INSERT INTO local_sender_plans VALUES(?,?)', (token, json.dumps({'plan':{'canonical_customer':customer,'customer_uid':uid,'comment_id':comment},'result':result})))
            db.commit()

    def args(self, action, *extra):
        return ['--project-root', str(self.root), '--ledger', str(self.db), '--batch', str(self.batch), *extra, action]

    def test_status_uses_explicit_external_ledger_and_is_read_only(self):
        self.add('a', 'unknown', {'kind':'platform_receipt', 'receipt_id':'receipt'})
        before = self.db.read_bytes()
        with redirect_stdout(StringIO()) as output, patch.object(cli, 'load_sender', side_effect=AssertionError('network not allowed')):
            self.assertEqual(cli.main(self.args('status')), 0)
        self.assertEqual(json.loads(output.getvalue())['已受理'], 1)
        self.assertEqual(before, self.db.read_bytes())

    def test_preview_never_loads_sender(self):
        with redirect_stdout(StringIO()) as out, patch.object(cli, 'load_sender', side_effect=AssertionError('network not allowed')):
            self.assertEqual(cli.main(self.args('preview')), 0)
        self.assertIn('拟回复', out.getvalue())

    def test_run_without_execute_never_loads_sender(self):
        with redirect_stdout(StringIO()), redirect_stderr(StringIO()), patch.object(cli, 'load_sender', side_effect=AssertionError('network not allowed')):
            self.assertEqual(cli.main(self.args('run')), 1)

    def test_unconfirmed_attempt_blocks_before_loading_sender(self):
        self.add('a', 'unknown', {'kind':'unknown'})
        with redirect_stdout(StringIO()), redirect_stderr(StringIO()), patch.object(cli, 'load_sender', side_effect=AssertionError('network not allowed')):
            result = cli.main(self.args('run','--execute','--sender-uid','uid','--session-home',str(self.root)))
        self.assertEqual(result, 1)

    def test_new_attempt_same_comment_and_author_still_reports_accepted(self):
        self.add('new-a','unknown',{'kind':'platform_receipt','receipt_id':'r'})
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['已受理'],1)
        self.assertEqual(json.loads(out.getvalue())['待处理'],1)

    def test_new_attempt_same_comment_unknown_remains_blocked(self):
        self.add('new-a','unknown',{'kind':'unknown'})
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['结果不明'],1)

    def test_same_customer_other_comment_is_blocked_not_reported_as_accepted(self):
        self.add('new-a','unknown',{'kind':'platform_receipt','receipt_id':'r'},comment='another')
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['结果不明'],1)
        self.assertEqual(json.loads(out.getvalue())['已受理'],0)

    def test_conflicting_comment_or_user_identity_cannot_be_merged(self):
        self.add('new-a','unknown',{'kind':'platform_receipt','receipt_id':'r'},customer='different',uid='different')
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['结果不明'],1)
        self.assertEqual(json.loads(out.getvalue())['已受理'],0)

    def test_same_platform_uid_different_canonical_is_blocked(self):
        self.add('new-a','unknown',{'kind':'platform_receipt','receipt_id':'r'},customer='different',comment='another')
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['结果不明'],1)

    def test_cross_platform_same_identity_does_not_merge(self):
        self.add('new-a','unknown',{'kind':'platform_receipt','receipt_id':'r'},platform='douyin')
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['待处理'],2)

    def test_accepted_plus_unknown_for_same_target_is_blocked(self):
        self.add('a','unknown',{'kind':'platform_receipt','receipt_id':'r'})
        self.add('new-a','unknown',{'kind':'unknown'})
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['结果不明'],1)

    def test_unlinked_unknown_lead_blocks_same_customer(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads VALUES(?,?,?,?)',('xiaohongshu','c1','other','unknown'));db.commit()
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status')),0)
        self.assertEqual(json.loads(out.getvalue())['结果不明'],1)

    def test_analysis_report_counts_only_still_pending_review(self):
        self.add('a','unknown',{'kind':'platform_receipt','receipt_id':'r'})
        report=self.root/'analysis.json';report.write_text(json.dumps({'items':[{'comment_id':'m1','needs_review':True},{'comment_id':'m2','needs_review':True}]}),encoding='utf-8')
        with redirect_stdout(StringIO()) as out:self.assertEqual(cli.main(self.args('status','--analysis-report',str(report))),0)
        self.assertEqual(json.loads(out.getvalue())['AI待核'],1)

    def test_run_skips_accepted_and_uses_one_second_interval(self):
        self.add('a', 'unknown', {'kind':'platform_receipt','receipt_id':'receipt'})
        class Client:
            def __init__(self, cookies, plan): self.plan=plan
            def close(self): pass
        seen=[]
        class Runner:
            def __init__(self, ledger, client): self.client=client
            def submit(self, plan): seen.append(plan); return 'receipt_received_unverified'
        class Module:
            OneAttemptClient=Client
            @staticmethod
            def Runner(ledger, client): return Runner(ledger,client)
            @staticmethod
            def load_independent_cookies(home): return {}
        with patch.object(cli, 'load_sender', return_value=Module()), patch.object(cli, 'make_plan', side_effect=lambda m,r,u,s:r['attempt_id']), patch.object(cli.time, 'sleep') as sleep, redirect_stdout(StringIO()):
            code = cli.main(self.args('run','--execute','--sender-uid','uid','--session-home',str(self.root)))
        self.assertEqual(code,0)
        self.assertEqual(seen,['b'])
        sleep.assert_called_once_with(1.0)

    def test_unknown_attempt_stops_batch_and_reports_unknown(self):
        class Client:
            def __init__(self,cookies,plan):self.plan=plan
            def close(self):pass
        outer=self;seen=[]
        class Runner:
            def __init__(self,ledger,client):pass
            def submit(self,plan):
                seen.append(plan)
                outer.add(plan,'unknown',{'kind':'unknown'})
                raise RuntimeError('HTTP 461')
        class Module:
            OneAttemptClient=Client
            Unknown=RuntimeError
            @staticmethod
            def Runner(ledger,client):return Runner(ledger,client)
            @staticmethod
            def load_independent_cookies(home):return {}
        with patch.object(cli,'load_sender',return_value=Module()),patch.object(cli,'make_plan',side_effect=lambda m,r,u,s:r['attempt_id']),patch.object(cli.time,'sleep') as sleep,redirect_stdout(StringIO()),redirect_stderr(StringIO()) as errors:
            code=cli.main(self.args('run','--execute','--sender-uid','uid','--session-home',str(self.root)))
        self.assertEqual(code,1)
        self.assertEqual(seen,['a'])
        self.assertIn('结果不明',errors.getvalue())
        self.assertIn('461',errors.getvalue())
        sleep.assert_not_called()

    def test_malformed_attempts_are_not_silently_deduplicated(self):
        self.batch.write_text(json.dumps({'count':2,'rows':[self.rows[0],self.rows[0]]}),encoding='utf-8')
        with redirect_stdout(StringIO()),redirect_stderr(StringIO()):
            self.assertEqual(cli.main(self.args('status')),1)

    def test_generic_prepare_binds_uid_and_source_and_never_overwrites(self):
        source=self.root/'comments.txt';source.write_text('source',encoding='utf-8')
        manifest=self.root/'sources.json';manifest.write_text(json.dumps({'comments':str(source)}),encoding='utf-8')
        raw=self.root/'raw.json';raw.write_text(json.dumps([dict(customer_id='customer',customer_uid='user',note_id='note',comment_id='comment',text='你好')]),encoding='utf-8')
        dest=self.root/'prepared.json'
        args=['--project-root',str(self.root),'--sender-uid','different-account','--source-manifest',str(manifest),'--input',str(raw),'--output',str(dest),'prepare']
        with redirect_stdout(StringIO()):self.assertEqual(cli.main(args),0)
        batch=cli.load_batch(dest)
        self.assertEqual(batch['intended_account_uid'],'different-account')
        row=batch['rows'][0]
        plan=SimpleNamespace(sender_uid='different-account',canonical_customer='customer',customer_uid='user',note_id='note',comment_id='comment',text='你好',attempt_id=row['attempt_id'])
        cli.verify_prepared(plan,dest,{'comments':source},True)
        plan.sender_uid='wrong-account'
        with self.assertRaises(cli.Halt):cli.verify_prepared(plan,dest,{'comments':source},True)
        plan.sender_uid='different-account';source.write_text('changed',encoding='utf-8')
        with self.assertRaises(cli.Halt):cli.verify_prepared(plan,dest,{'comments':source},True)
        with redirect_stdout(StringIO()),redirect_stderr(StringIO()):self.assertEqual(cli.main(args),1)

    def test_generic_prepare_refuses_same_customer_twice(self):
        source=self.root/'source.txt';source.write_text('evidence',encoding='utf-8')
        manifest=self.root/'sources.json';manifest.write_text(json.dumps({'s':str(source)}),encoding='utf-8')
        raw=self.root/'raw.json'
        raw.write_text(json.dumps([dict(customer_id='same',customer_uid='user',note_id='a',comment_id='1',text='one'),dict(customer_id='same',customer_uid='user',note_id='b',comment_id='2',text='two')]),encoding='utf-8')
        dest=self.root/'prepared.json'
        args=['--project-root',str(self.root),'--sender-uid','uid','--source-manifest',str(manifest),'--input',str(raw),'--output',str(dest),'prepare']
        with redirect_stdout(StringIO()),redirect_stderr(StringIO()):self.assertEqual(cli.main(args),1)
        self.assertFalse(dest.exists())


if __name__ == '__main__': unittest.main(verbosity=2)
