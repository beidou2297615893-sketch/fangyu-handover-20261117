"""Offline immutable draft preparation; source classification and ledgers stay read-only."""
import collections
import datetime as dt
import hashlib
import importlib.util
import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEXT = ROOT / 'work/fangyu-text-business-20261029'
OUT = Path(__file__).resolve().parent

def sha(raw): return hashlib.sha256(raw).hexdigest()
def dump(obj): return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def lines(path): return [json.loads(x) for x in path.read_text(encoding='utf-8-sig').splitlines() if x.strip()]

def main():
    sources = {}
    def pin(path):
        path = path.resolve(); sources[str(path)] = sha(path.read_bytes()); return path
    batchpath = pin(ROOT/'work/xhs-send-current-20261029/runs/huihuijiang-batch-20261101-01/prepared-batch.json')
    poolpath = pin(TEXT/'high-intent-pools-20261101/all-high-intent-pools.jsonl')
    pointer = read(pin(TEXT/'当前双平台回复结果指针.json'))
    sidepath = pin(Path(pointer['platforms']['xiaohongshu']['reply_sidecar_file']))
    templates = read(pin(TEXT/'pool-mother-review/pool-mother-short-variants.json'))['templates']
    templates.update(read(pin(TEXT/'pool-mother-review/approved-mother-overrides-20261101.json'))['templates'])
    pin(TEXT/'rules/按池选母句与微调执行方式.json')
    pin(TEXT/'rules/地域与品牌母句执行方式.json')
    rendererpath = pin(TEXT/'douyin-registered-v2/increments/f98cc21138910fb9/batch_short_mothers.py')
    spec = importlib.util.spec_from_file_location('bounded_original_renderer', rendererpath)
    renderer = importlib.util.module_from_spec(spec); spec.loader.exec_module(renderer)
    contract = {'families': {k: {'template': templates[k], 'required_fill': []} for k in ('price','location','available','pet_cat')}}
    batch = read(batchpath)['rows']
    pools = {r['comment_id']: r for r in lines(poolpath) if r['platform']=='xiaohongshu'}
    sides = {r['comment_id']: r for r in lines(sidepath)}
    stamp = dt.datetime.now(dt.timezone.utc)
    # A single read transaction gives a consistent local-history snapshot, without writes.
    con = sqlite3.connect((ROOT/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro', uri=True)
    con.execute('PRAGMA query_only=ON'); con.execute('BEGIN')
    reservations = list(con.execute("SELECT token,customer,comment,status FROM reservations WHERE platform='xiaohongshu'"))
    history = list(con.execute("SELECT customer,comment,delivery_state FROM historical_deliveries WHERE platform='xiaohongshu'"))
    leads = list(con.execute("SELECT customer,comment,status FROM leads WHERE platform='xiaohongshu'"))
    plans = [json.loads(r[0]) for r in con.execute("SELECT data FROM local_sender_plans")]
    aliases = dict(con.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'"))
    con.close()
    blocked_customers=set(); blocked_comments=set(); blocked_uids=set()
    for _,customer,cid,status in reservations:
        if status in ('reserved','unknown','sent'): blocked_customers.add(customer); blocked_comments.add(cid)
    for customer,cid,status in leads:
        if status in ('reserved','unknown','sent'): blocked_customers.add(customer); blocked_comments.add(cid)
    for customer,cid,state in history:
        if state!='not_sent': blocked_customers.add(customer); blocked_comments.add(cid)
    for record in plans:
        p=record.get('plan',{})
        if p.get('comment_id') in blocked_comments or p.get('canonical_customer') in blocked_customers:
            blocked_uids.add(p.get('customer_uid'))
    # Full-string matching only validates a narrow wording family after the existing AI pool decision.
    patterns={
      'price': r'(?:你好|您好|宝宝)?(?:请问一下|请问|礼貌|想|求|问一下|问下|问问|问|询问|询)?(?:一下)?(?:询价|问价|价格|價錢|價格|租金|多少钱|多钱|什么价|什么价格|价钱|价|多少)(?:多少|多钱|多少钱)?(?:呀|啊|呢|哩|哇|嘛|吗|me|谢谢)*',
      'location': r'(?:你好|您好|宝宝)?(?:请问一下|请问|礼貌|求|问一下|问下|问|想问)?(?:具体)?(?:位置在哪里|位置在哪|具体位置|什么位置|在哪里|在哪|哪里|位置|地址|地点)(?:啊|呀|呢|哇|嘛|吗|谢谢)*',
      'available': r'(?:你好|您好|宝宝)?(?:请问|礼貌)?(?:还有|还在|问房)(?:吗|嘛|么|不|呢|呀|啊)*',
    }
    expected={'price':['价格预算'],'location':['位置通勤'],'available':['房源状态'],'pet_cat':['宠物']}
    results=[]; chosen_uids=set()
    for row in batch:
        s=sides.get(row['comment_id']); p=pools.get(row['comment_id']); reasons=[]; family=None
        if not s: reasons.append('source_mapping_missing')
        if s:
            raw=s.get('original_raw_record',{}); own=s['comment_text']; cls=(p or {}).get('original_classification') or s.get('source_record',{}).get('classification',{})
            if s.get('customer_uid')!=row['customer_uid'] or s.get('note_id')!=row['note_id']: reasons.append('uid_or_note_mismatch')
            if sha(own.encode())!=s.get('comment_text_sha256'): reasons.append('original_comment_hash_mismatch')
            if p and (p['customer_uid']!=row['customer_uid'] or p['comment_text']!=own): reasons.append('pool_identity_or_text_mismatch')
            title=raw.get('post_title','')
            if not title: reasons.append('post_title_missing')
            if any(w in title for w in ('已出租','已租出','已成交')): reasons.append('post_no_longer_available')
            try:
                date=dt.datetime.fromisoformat(s['published_at'].replace('Z','+00:00'))
                if not date.tzinfo: raise ValueError()
                if (stamp-date).total_seconds()>60*86400: reasons.append('existing_sender_60_day_hold')
            except (KeyError,ValueError,TypeError): reasons.append('date_unknown')
            if cls.get('role')!='demand' or cls.get('demand_state')!='active_at_comment': reasons.append('existing_role_or_demand_state_hold')
            if cls.get('needs_review') or cls.get('possible_topics') or cls.get('pending_pools') or cls.get('other_constraints'): reasons.append('unresolved_semantics_or_conditions')
            if cls.get('target_regions') or cls.get('time_mentions'): reasons.append('explicit_time_or_region_requires_specific_family')
            if s.get('contact_boundaries') or cls.get('contact_boundaries'): reasons.append('contact_boundary_requires_review')
            plan=s.get('reply_plan') or {}; policy=plan.get('contact_policy')
            if policy in ('no_contact','identity_restricted','manual_review','manual'): reasons.append('existing_contact_policy_hold')
            topics=cls.get('actual_pools') or cls.get('topics') or []
            if any(isinstance(t,dict) and (t.get('subject')!='own_demand' or t.get('polarity') in ('reject','not_required','conditional','unknown') or t.get('condition_scope')) for t in topics): reasons.append('nonpositive_or_scoped_topic')
            # No fresh semantic labels are invented for the 15 medium entries.
            if not p: reasons.append('not_in_latest_high_pool_index')
            if p and p.get('reply_text_candidate') and p.get('cat_positive_user_approved') and not p.get('cat_additional_conditions'): family='pet_cat'
            else:
                clean=re.sub(r'\[[^\]]*\]','',own)
                clean=re.sub(r'[\s，。？！、,.!?～~：:👋🙋]','',clean)
                family=next((f for f,pattern in patterns.items() if re.fullmatch(pattern,clean)),None)
            if not family: reasons.append('no_complete_bounded_template_match')
            elif not p or p['demand_pools']!=expected[family]: reasons.append('pool_template_mismatch_or_multiple_pools')
        else: own='';cls={};raw={};title=''
        if row['comment_id'] in blocked_comments or row['customer_id'] in blocked_customers or row['customer_uid'] in blocked_customers or row['customer_uid'] in blocked_uids or aliases.get(row['customer_uid']) in blocked_customers:
            reasons.append('prior_submission_receipt_unknown_or_reservation')
        if row['customer_uid'] in chosen_uids: reasons.append('same_customer_already_selected_in_this_draft_batch')
        text=None
        if not reasons:
            # Contact allow here describes this authorized public reply scope, not a fabricated historical check.
            render_row={'role':cls['role'],'demand_state':cls['demand_state'],'interest_at_comment':cls['interest'],
                        'reply_plan':{'local_mother':{'family':family,'fill':{},'evidence':[]},'contact_policy':'allow','tone':'normal'}}
            rendered=renderer.render_plan(render_row,own,contract); text=rendered['text']
            assert text and text!= '宝宝，我住方隅公寓这边，介绍有优惠的。'
            chosen_uids.add(row['customer_uid'])
        result={k:row[k] for k in ('sequence','customer_id','customer_uid','comment_id','note_id')}
        result.update(platform='xiaohongshu', original_attempt_id=row['attempt_id'], original_comment=own,
          comment_sha256=sha(own.encode()), post_title=title, published_at=s.get('published_at') if s else None,
          ip_location_raw=s.get('original_ip') if s else None, assigned_store=None,
          demand_pools=p.get('demand_pools') if p else None, classification_sha256=sha(dump(cls).encode()),
          family=family if text else None, text=text, text_sha256=sha(text.encode()) if text else None,
          status='draft_ready_for_sender_recheck' if text else 'held', hold_reasons=reasons,
          local_history_snapshot_at=stamp.isoformat(),platform_calls=0,send_attempted=False,
          platform_reply_history='unknown',other_accounts_history='local_shared_ledger_snapshot_only',
          public_visibility_checked=False, source_batch_sha256=sources[str(batchpath)],
          actual_housing_facts_verified=False, wording_basis='approved_short_family_plus_20261101_cat_override',
          factual_scope='cat_policy_user_confirmed' if family=='pet_cat' and text else 'offer_to_check_not_assertion_of_inventory_price_or_location',
          next_gate='fresh_authoritative_dedup_and_sender_identity_platform_state_required')
        results.append(result)
    ready=[r for r in results if r['status']=='draft_ready_for_sender_recheck']
    for path,digest in sources.items(): assert sha(Path(path).read_bytes())==digest, path+' changed during preparation'
    payload=''.join(dump(r)+'\n' for r in results); package=OUT/('frozen-'+sha(payload.encode())[:16]);package.mkdir(exist_ok=False)
    def write(name, content):
        with (package/name).open('x',encoding='utf-8',newline='\n') as f:f.write(content)
    write('all-567-dispositions.jsonl',payload)
    write('ready-drafts.jsonl',''.join(dump(r)+'\n' for r in ready))
    write('held-drafts.jsonl',''.join(dump(r)+'\n' for r in results if r['status']=='held'))
    manifest={'created_at':stamp.isoformat(),'source_hashes':sources,'batch_rows':len(results),'ready_drafts':len(ready),
      'held':len(results)-len(ready),'family_counts':dict(collections.Counter(r['family'] for r in ready)),
      'hold_reason_counts_overlap':dict(collections.Counter(v for r in results for v in r['hold_reasons'])),
      'local_history_digest':sha(dump({'reservations':reservations,'history':history,'leads':leads,'plans':plans,'aliases':aliases}).encode()),
      'platform_calls':0,'ledger_writes':0,'originals_overwritten':False,'not_executable_send_queue':True,
      'runtime_eligibility_not_certified':True,'checks':{'rows567':len(results)==567,'unique_uid_ready':len({r['customer_uid'] for r in ready})==len(ready),'uid_note_comment_hash_verified':True},
      'files':{n:sha((package/n).read_bytes()) for n in ('all-567-dispositions.jsonl','ready-drafts.jsonl','held-drafts.jsonl')}}
    write('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'package':str(package),'ready':len(ready),'held':len(results)-len(ready),'families':manifest['family_counts'],'holds':manifest['hold_reason_counts_overlap']},ensure_ascii=False))

if __name__=='__main__':main()
