"""Infer approximate closed rounds from immutable local logs, never write to tasks."""
import json
from collections import defaultdict

def parse_rounds(task_name,log_lines,selections):
    selected=[]
    for line in log_lines:
        if line.startswith('选取原评论日期：'):
            selected.append(line.split('：',1)[1].split('｜',1)[0].strip())
    source_dates=[str(x.get('original_time') or '') for x in selections]
    ignored_prefix=0
    if selected != source_dates:
        # The on-disk run log may have been truncated while older evidence
        # remains. Accept only a unique exact suffix; never guess gaps.
        offsets=[i for i in range(max(0,len(source_dates)-len(selected))+1)
                 if selected and source_dates[i:i+len(selected)]==selected]
        if len(offsets)!=1 or offsets[0]+len(selected)!=len(source_dates):
            return {}, {'aligned':False,'reason':'selection_sequence_mismatch','closed_rounds':0}
        ignored_prefix=offsets[0]
        selections=selections[ignored_prefix:]
    index=0; batch=0; active=None; current=None; rounds=[]
    for line in log_lines:
        if line.startswith('持续处理已批准队列'):
            if active is not None:rounds.append(active)
            batch+=1;active={'id':f'{task_name}:{batch}','closed':False,'entries':[]};current=None
        elif line.startswith('选取原评论日期：'):
            event=selections[index];index+=1;current=event
        elif line.startswith('SUCCESS') and active is not None and current is not None:
            active['entries'].append(current);current=None
        elif (line.startswith('已停止：') or '本轮已批准队列处理完毕' in line) and active is not None:
            active['closed']=True;rounds.append(active);active=None;current=None
    if active is not None:rounds.append(active)
    by_comment=defaultdict(set)
    for item in rounds:
        if item['closed']:
            for event in item['entries']:
                if event.get('cid'):by_comment[str(event['cid'])].add(item['id'])
    mapping={cid:next(iter(ids)) for cid,ids in by_comment.items() if len(ids)==1}
    return mapping, {'aligned':True,'ignored_evidence_prefix':ignored_prefix,'closed_rounds':sum(x['closed'] for x in rounds),
        'unclosed_rounds':sum(not x['closed'] for x in rounds),'successes_in_closed_rounds':len(mapping)}

def read_task(task):
    log=task/'runner-stdout.log'; source=task/'selection-evidence.jsonl'
    if not log.exists() or not source.exists():return {},{'aligned':False,'reason':'missing_log_or_evidence'}
    try:
        lines=log.read_text(encoding='utf-8',errors='replace').splitlines()
        selections=[json.loads(line) for line in source.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
        return parse_rounds(task.name,lines,selections)
    except (OSError,ValueError,TypeError):return {},{'aligned':False,'reason':'unreadable'}
