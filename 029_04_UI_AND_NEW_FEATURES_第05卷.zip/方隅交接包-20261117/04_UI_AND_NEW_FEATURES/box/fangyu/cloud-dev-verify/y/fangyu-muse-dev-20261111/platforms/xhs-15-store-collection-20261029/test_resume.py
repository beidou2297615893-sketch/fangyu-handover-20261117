import hashlib
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from resume_guard import reconcile, reconcile_comment_interruption, reconcile_empty_attempt

class ResumeGuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)/'prior'; self.root.mkdir()
        self.db=Path(self.tmp.name)/'ledger.sqlite3'
        with closing(sqlite3.connect(self.db)) as c:
            c.execute('CREATE TABLE leads(platform TEXT,customer TEXT,comment TEXT,source TEXT)')
            c.commit()
        self.plan=[{'keyword':'a','page':1},{'keyword':'b','page':1}]
        self.write('state.json',{'status':'outcome_unknown','plan':self.plan,'cursor':1,'next_batch':2,'inserted':1,'inflight':{'batch':'batch-0002','keyword':'b','page':1}})
        (self.root/'batch-0001').mkdir(); (self.root/'batch-0002').mkdir()
        self.write('batch-0001/new-ai-input.json',[])
        self.write('batch-0001/account-binding.json',{'uid':'expected','guest':False})
        self.write('batch-0001/register-result.json',{'account':{'uid':'expected','guest':False},'result':{'mode':'apply','inserted':1}})
        self.write('batch-0001/registered-ready.json',{'registered':True,'inserted_comments':1,'account_uid':'expected','input':'new-ai-input.json'})
        source='collection:'+str((self.root/'batch-0001/collection.json').resolve())
        manifest={'batch':'batch-0001','keyword':'a','page':1,'account_uid':'expected','inserted_comments':1,'input':'batch-0001/new-ai-input.json','sha256':hashlib.sha256((self.root/'batch-0001/new-ai-input.json').read_bytes()).hexdigest(),'registration_source':source}
        (self.root/'analysis-manifest.jsonl').write_text(json.dumps(manifest)+'\n',encoding='utf8')
        with closing(sqlite3.connect(self.db)) as c:
            c.execute('INSERT INTO leads VALUES(?,?,?,?)',('xiaohongshu','customer','comment',source)); c.commit()
        self.write('batch-0002/failure-diagnostic.json',{'platform':{'stage':'search','endpoint':'prewarm_onebox','http_status':461}})
    def write(self,name,data):
        (self.root/name).write_text(json.dumps(data),encoding='utf8')
    def test_resumes_only_unfinished_suffix(self):
        r=reconcile(self.root,self.db,self.plan,'expected')
        self.assertEqual((r['cursor'],r['base_registered'],r['first_batch']),(1,1,2))
    def test_ledger_disagreement_holds(self):
        with closing(sqlite3.connect(self.db)) as c:
            c.execute('DELETE FROM leads'); c.commit()
        with self.assertRaises(ValueError):reconcile(self.root,self.db,self.plan,'expected')
    def test_partial_data_holds(self):
        self.write('batch-0002/partial-0001.json',{'customers':[]})
        with self.assertRaises(ValueError):reconcile(self.root,self.db,self.plan,'expected')
    def test_active_lock_holds(self):
        (self.root/'scheduler.lock').mkdir()
        with self.assertRaises(ValueError):reconcile(self.root,self.db,self.plan,'expected')
    def test_changed_plan_holds(self):
        with self.assertRaises(ValueError):reconcile(self.root,self.db,self.plan[::-1],'expected')
    def test_comment_unknown_without_recovery_holds(self):
        with self.assertRaises((ValueError,FileNotFoundError)):
            reconcile_comment_interruption(self.root,self.db,self.root/'recovery','expected',self.plan[1])
    def test_comment_failure_cannot_be_called_complete(self):
        self.write('batch-0002/failure-diagnostic.json',{'platform':{'stage':'comments','endpoint':'comments','http_status':461}})
        with self.assertRaises((ValueError,FileNotFoundError)):
            reconcile_comment_interruption(self.root,self.db,self.root/'recovery','expected',self.plan[1])
    def test_reconciled_partial_keeps_keyword_unfinished(self):
        self.write('state.json',{'status':'outcome_unknown','plan':[self.plan[1]],'cursor':0,'next_batch':2,'inserted':0,'inflight':{'batch':'batch-0002',**self.plan[1]}})
        self.write('batch-0002/failure-diagnostic.json',{'platform':{'stage':'comments','endpoint':'comments','http_status':461}})
        (self.root/'recovery').mkdir()
        self.write('recovery/new-ai-input.json',[])
        source='collection:'+str((self.root/'recovery/collection.json').resolve())
        with closing(sqlite3.connect(self.db)) as c:
            c.execute('INSERT INTO leads VALUES(?,?,?,?)',('xiaohongshu','c2','c2',source)); c.commit()
        self.write('recovery/register-result.json',{'account':{'uid':'expected','guest':False},'result':{'mode':'apply','inserted':1}})
        self.write('recovery/registered-ready.json',{'registered':True,'account_uid':'expected','inserted_comments':1})
        m={'original_batch':'batch-0002','keyword':'b','page':1,'account_uid':'expected','registration_source':source,'inserted_comments':1,'input':'new-ai-input.json','sha256':hashlib.sha256((self.root/'recovery/new-ai-input.json').read_bytes()).hexdigest(),'note_completion_proven':False}
        (self.root/'recovery/analysis-manifest.jsonl').write_text(json.dumps(m)+'\n',encoding='utf8')
        result=reconcile_comment_interruption(self.root,self.db,self.root/'recovery','expected',self.plan[1])
        self.assertEqual(result['recovered_registered'],1)
        self.assertFalse(result['keyword_complete'])
    def test_empty_failed_attempt_is_not_counted(self):
        self.write('state.json',{'status':'outcome_unknown','inserted':0,'inflight':{'batch':'batch-0002',**self.plan[1]}})
        self.write('batch-0002/account-binding.json',{'uid':'expected','guest':False})
        self.write('batch-0002/failure-diagnostic.json',{'platform':{'stage':'comments','endpoint':'comments','http_status':461}})
        self.assertEqual(reconcile_empty_attempt(self.root,self.db,'expected',self.plan[1])['registered'],0)
    def test_empty_claim_rejects_partial(self):
        self.write('state.json',{'status':'outcome_unknown','inserted':0,'inflight':{'batch':'batch-0002',**self.plan[1]}})
        self.write('batch-0002/partial-0001.json',{})
        with self.assertRaises(ValueError):reconcile_empty_attempt(self.root,self.db,'expected',self.plan[1])

if __name__=='__main__':unittest.main()
