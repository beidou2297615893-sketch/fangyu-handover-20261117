# 独立人工登录接续入口候选

本目录已接实际本机上游 API，并有可运行入口；尚未执行真实平台或启动新浏览器。它不修改现有浏览器、上游 CLI、旧账号或正式账本，不能接管正在运行的旧 `hold.py` 窗口。

先做默认预览（无浏览器、网络及凭据写入）：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 'work/xhs-live-login-adapter-20261029/adapter.py' --run-home 'work/xhs-standalone-session/新的唯一目录'
```

真实运行只由主任务在本人授权、确认没有其他正在登录的进程后增加 `--execute`。目录必须不存在。Windows 会为新的目录设置仅当前用户与 SYSTEM 可访问的 ACL，设置失败即停止；不改变其他目录权限。

入口打开官方小红书登录页，监听页面自身正常返回的二维码创建事件，生成版本图片及 `status.json`；验证码出现时浏览器继续保持，员工本人操作。程序不会请求二维码状态、解题、重放登录请求、切号、发送或采集。网页自己发出的正常请求由网页负责。

当本人明确完成扫码/验证码，且当前**同一窗口**已进入正常登录状态后，由调用者在该次目录创建 `capture.flag`，UTF-8 内容必须为 `capture-current-page`。该标记会先改名 `capture.used`，随后只请求一次身份接口；没有标记不会发身份请求。身份传输复用已审的本机 `ReadClient`，但把允许端点收窄至 GET `/api/sns/web/v2/user/me`，禁重定向/重试。使用该同一页面的内存会话快照，前后稳定才接受；唯一 UID、明确布尔 `guest=false` 和必要会话字段均必须成立，未知/游客/冲突/验证/异常都停止且不重试。

通过后在新目录内原子、不覆盖地保存 `.xiaohongshu-cli/cookies.json`，格式兼容现有 CLI；账号 UID 与非游客证据另存 `identity-receipt.json`，事件不含 Cookie、二维码 URL、响应正文或异常原文。写盘后如果回执失败，结果为未知，先核对文件，禁止自动重试。成功也保持窗口，直到本人关闭。采集必须由外层另行核验并启动。

## 真实限制

- 此入口不能热接旧进程；如当前已验证会话能通过已授权精确范围复用，优先复用，避免再次扫码。
- 真实身份响应是否提供 `guest=false` 尚未验证。缺失时不会放宽。
- 正常网页行为、验证码是否呈现、同账号跨请求一致性、实际 CLI 采集链路尚未验。
- 仅本机新目录有访问限制，不代表跨电脑会话共享或正式软件集成。
- 不把预览、Mock 测试或保存文件当作实际平台采集已完成。

## 离线验证

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest discover -s 'work/xhs-live-login-adapter-20261029' -v
```

初始实现桩的行为检查出现 6 项预期断言失败和 1 项缺少客户端错误；实现后检查实际签名传输使用 `httpx.MockTransport`，测试禁用 socket connect。完整入口使用合成浏览器页完成本地会话保存，不请求平台；Windows 新目录 ACL 在该入口小样中实际执行。
