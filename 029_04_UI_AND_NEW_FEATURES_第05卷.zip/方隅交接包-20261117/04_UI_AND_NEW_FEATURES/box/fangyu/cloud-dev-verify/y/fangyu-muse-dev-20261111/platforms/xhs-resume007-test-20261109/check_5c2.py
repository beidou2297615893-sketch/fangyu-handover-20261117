﻿import sqlite3, re
from pathlib import Path
L = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3')
db = sqlite3.connect(L.resolve().as_uri() + '?mode=ro', uri=True)
rows = db.execute("select source, count(*) from leads where platform='xiaohongshu' group by source order by 2 desc").fetchall()
print('distinct xhs sources:', len(rows))
shapes = {}
for s, c in rows:
    s = s or ''
    if not re.search(r'[\\/]', s) and len(s) > 0 and not s.startswith(('batch','stores','xhs','work')):
        k = '<non-path len%d>' % min(len(s)//20*20, 200)
    else:
        k = re.sub(r'\d', '#', s)[-110:]
    shapes[k] = shapes.get(k, 0) + c
for k, c in sorted(shapes.items(), key=lambda x: -x[1])[:15]: print(c, k)
print('resume006 any:', db.execute("select count(*) from leads where source like '%resume006%'").fetchone()[0])
print('batch-0023 by platform:', db.execute("select platform,count(*) from leads where source like '%batch-0023%' group by platform").fetchall())
db.close()
