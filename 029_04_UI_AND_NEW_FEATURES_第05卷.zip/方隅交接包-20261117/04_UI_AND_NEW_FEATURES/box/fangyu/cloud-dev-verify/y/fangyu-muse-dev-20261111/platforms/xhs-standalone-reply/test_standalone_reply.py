import json, os, socket, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import httpx
import xhs_cli.client as vendor
try:
 from standalone_reply import FrozenReply, ControlledClient, Runner, SharedLedger, Refused, Unknown
except ImportError:
 FrozenReply = None

LEDGER=Path(__file__).resolve().parents[1]/'shared-acquisition-ledger'/'ledger.py'
class OfflineTests(unittest.TestCase):
 def setUp(self):
  self.network=patch('socket.socket.connect',side_effect=AssertionError('network forbidden')); self.network.start(); self.addCleanup(self.network.stop)
  self.sign=patch.object(vendor,'sign_main_api',return_value={});self.sign.start();self.addCleanup(self.sign.stop)
  self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent);self.addCleanup(self.tmp.cleanup)
 def test_implementation_required(self): self.assertIsNotNone(FrozenReply,'independent implementation missing')
 def setup_case(self, outcome='ok', uid='sender'):
  if FrozenReply is None:self.fail('independent implementation missing')
  self.plan=FrozenReply('sender','customer','note','comment','exact text','attempt-1',True,'checked all accounts and live target',int(__import__("time").time())+240,'synthetic')
  self.calls=[]
  def http(req):
   self.calls.append(req)
   if req.method=='GET':return httpx.Response(200,json={'success':True,'data':{'user_id':uid}})
   if outcome=='timeout':raise httpx.ReadTimeout('synthetic timeout',request=req)
   if outcome!='ok':return httpx.Response(int(outcome),json={'success':False})
   return httpx.Response(200,json={'success':True,'data':{'comment':{'id':'receipt'}}})
  self.client=ControlledClient({'a1':'synthetic'},self.plan,httpx.MockTransport(http));self.addCleanup(self.client.close)
  self.db=Path(self.tmp.name)/'ledger.sqlite3';self.ledger=SharedLedger(LEDGER,self.db,sys.executable)
  self.ledger.command('init')
  self.ledger.command('identity-bind','xiaohongshu','customer','customer','synthetic historical identity coverage')
  self.ledger.command('lead','xiaohongshu','customer','comment')
  assessment=Path(self.tmp.name)/'assessment.json';assessment.write_text(json.dumps({'source':'synthetic','intent':'rental','store':'store','match':'match','pending':'','draft':'exact text','peer_reply':'none','reply_binding':{'platform':'xiaohongshu',**__import__('dataclasses').asdict(self.plan)},'verification_facts':{'sender_uid':'sender','customer_uid':'customer','note_id':'note','comment_id':'comment','source':'synthetic','all_account_history_checked':True,'target_and_peer_replies_checked':True,'user_authorized':True}}),encoding='utf-8')
  self.ledger.command('assess','xiaohongshu','customer','comment',str(assessment))
  self.ledger.command('review','xiaohongshu','customer','comment','tester',self.plan.verification_evidence)
  return Runner(self.ledger,self.client)
 def test_exact_vendor_payload_and_shared_reservation(self):
  r=self.setup_case();self.assertEqual(r.submit(self.plan),'receipt_received')
  self.assertEqual([x.method for x in self.calls],['GET','POST'])
  self.assertEqual(json.loads(self.calls[1].content),{'note_id':'note','content':'exact text','target_comment_id':'comment','at_users':[]})
  with self.assertRaises(Refused):r.submit(self.plan)
  self.assertEqual(sum(x.method=='POST' for x in self.calls),1)
 def test_wrong_identity_never_reserves_or_posts(self):
  r=self.setup_case(uid='wrong')
  with self.assertRaises(Refused):r.submit(self.plan)
  self.assertEqual([x.method for x in self.calls],['GET'])
 def test_failures_unknown_no_retry(self):
  for outcome in ('timeout',302,429,500,502,503,504):
   with self.subTest(outcome=outcome):
    r=self.setup_case(outcome)
    with self.assertRaises(Unknown):r.submit(self.plan)
    self.assertEqual([x.method for x in self.calls],['GET','POST'])
    with self.assertRaises(Refused):r.submit(self.plan)
    import sqlite3
    with __import__("contextlib").closing(sqlite3.connect(self.db)) as db:self.assertEqual(db.execute('select status from reservations').fetchone()[0],'unknown')
    self.db.unlink()
 def test_unverified_other_history_blocks(self):
  r=self.setup_case();self.ledger.command('lead','xiaohongshu','customer','other-comment')
  with self.assertRaises(Refused):r.submit(self.plan)
  self.assertEqual([x.method for x in self.calls],['GET'])
 def test_strict_granted_true(self):
  r=self.setup_case()
  for granted in (False,1,'true',None):
   with patch.object(self.ledger,'reserve',return_value={'granted':granted}):
    with self.assertRaises(Refused):r.submit(self.plan)
  self.assertFalse(any(x.method=='POST' for x in self.calls))
 def test_changed_frozen_fields_refused(self):
  r=self.setup_case()
  import dataclasses
  for field in ('sender_uid','customer_uid','note_id','comment_id','text','attempt_id'):
   with self.subTest(field=field):
    with self.assertRaises(Refused):r.submit(dataclasses.replace(self.plan,**{field:'changed'}))
  self.assertEqual(self.calls,[])
 def test_false_authorization_refused(self):
  r=self.setup_case()
  import dataclasses
  with self.assertRaises(Refused):r.submit(dataclasses.replace(self.plan,authorized=1))
  self.assertEqual(self.calls,[])



class IsolationTests(unittest.TestCase):
 def test_home_loader_requires_both_variables_and_never_falls_back(self):
  import standalone_reply as m
  self.assertTrue(callable(getattr(m,'load_independent_cookies',None)),'independent session loader missing')
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
   home=Path(directory).resolve()
   with patch.dict(os.environ,{'HOME':str(home),'USERPROFILE':'different'}):
    with self.assertRaises(Refused):m.load_independent_cookies(home)
   with patch.dict(os.environ,{'HOME':str(home),'USERPROFILE':str(home)}):
    with self.assertRaises(Refused):m.load_independent_cookies(home)
    from xhs_cli.constants import CONFIG_DIR_NAME,COOKIE_FILE
    target=home/CONFIG_DIR_NAME/COOKIE_FILE;target.parent.mkdir();target.write_text('{"a1":"synthetic","web_session":"synthetic"}',encoding='utf-8')
    self.assertEqual(m.load_independent_cookies(home)['a1'],'synthetic')
 def test_account_lock_refuses_other_process(self):
  import standalone_reply as m
  self.assertTrue(callable(getattr(m,'AccountLock',None)),'cross-process lock missing')
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
   with m.AccountLock(directory,'sender'):
    script='from standalone_reply import AccountLock,Refused; import sys\ntry:\n with AccountLock(sys.argv[1],"sender"): sys.exit(9)\nexcept Refused: sys.exit(0)'
    result=subprocess.run([sys.executable,'-B','-c',script,directory],cwd=Path(__file__).parent,capture_output=True)
    self.assertEqual(result.returncode,0,result.stderr)


class CompetitionTests(unittest.TestCase):
 setUp=OfflineTests.setUp
 setup_case=OfflineTests.setup_case
 def test_two_processes_share_one_reservation(self):
  self.setup_case()
  jobs=[subprocess.Popen([sys.executable,'-B','-X','utf8',str(LEDGER),'--db',str(self.db),'reserve','xiaohongshu','customer','comment',token],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for token in ('race-a','race-b')]
  results=[job.communicate() for job in jobs]
  self.assertEqual(sum(job.returncode==0 and json.loads(out[0]).get('granted') is True for job,out in zip(jobs,results)),1)


class EntryTests(unittest.TestCase):
 def test_entry_preview_needs_no_home_or_network(self):
  import standalone_reply as m
  self.assertTrue(callable(getattr(m,'main',None)),'CLI entry missing')
  with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
   plan=Path(directory)/'plan.json'
   plan.write_text(json.dumps(dict(sender_uid='sender',customer_uid='customer',note_id='note',comment_id='comment',text='exact',attempt_id='token',authorized=True,verification_evidence='synthetic live review',valid_until=int(__import__('time').time())+240,source='synthetic')),encoding='utf-8')
   with patch('socket.socket.connect',side_effect=AssertionError('no network')):
    self.assertEqual(m.main(['--plan',str(plan)]),0)




class BindingTests(unittest.TestCase):
 setUp=OfflineTests.setUp
 setup_case=OfflineTests.setup_case
 def test_real_entry_changed_json_fields_refused_against_reviewed_ledger(self):
  import dataclasses,standalone_reply as m
  for field in ('text','sender_uid','customer_uid','note_id','comment_id','attempt_id','source','verification_evidence','valid_until'):
   with self.subTest(field=field):
    self.setup_case()
    altered=dataclasses.asdict(self.plan);altered[field]=(altered[field]+1 if field=='valid_until' else 'unreviewed replacement')
    plan_file=Path(self.tmp.name)/'entry-plan.json';plan_file.write_text(json.dumps(altered),encoding='utf-8')
    def make_client(cookies,plan):
     def wire(req):
      self.calls.append(req)
      if req.method=='GET':return httpx.Response(200,json={'success':True,'data':{'user_id':plan.sender_uid}})
      return httpx.Response(200,json={'success':True,'data':{'comment':{'id':'receipt'}}})
     return ControlledClient(cookies,plan,httpx.MockTransport(wire))
    with patch.object(m,'SharedLedger',return_value=self.ledger),patch.object(m,'load_independent_cookies',return_value={'a1':'synthetic'}),patch.object(m,'ControlledClient',side_effect=make_client):
     with self.assertRaises(Refused):m.main(['--plan',str(plan_file),'--execute','--session-home',self.tmp.name])
    self.assertFalse(any(r.method=='POST' for r in self.calls))
 def test_missing_independent_binding_refused(self):
  r=self.setup_case()
  import sqlite3
  with __import__('contextlib').closing(sqlite3.connect(self.db)) as db:
   db.execute("update assessments set data=json_remove(data,'$.reply_binding')");db.commit()
  with self.assertRaises(Refused):r.submit(self.plan)
  self.assertFalse(any(r.method=='POST' for r in self.calls))
 def test_ledger_change_after_reservation_blocks_before_post(self):
  r=self.setup_case()
  original=self.ledger.reserve
  def change(plan):
   result=original(plan)
   import sqlite3
   with __import__('contextlib').closing(sqlite3.connect(self.db)) as db:
    db.execute("update assessments set data=json_set(data,'$.draft','changed during reservation')");db.commit()
   return result
  with patch.object(self.ledger,'reserve',side_effect=change):
   with self.assertRaises(Unknown):r.submit(self.plan)
  self.assertFalse(any(req.method=='POST' for req in self.calls))



class WireExpiryTests(unittest.TestCase):
 setUp=OfflineTests.setUp
 setup_case=OfflineTests.setup_case
 def test_plan_expired_during_second_check_never_reaches_post_transport(self):
  import standalone_reply as m
  self.setup_case()
  runner=Runner(self.ledger,self.client)
  original=self.ledger.reviewed_binding
  clock={'now':int(__import__('time').time())}
  def delayed_check(plan,status):
   result=original(plan,status)
   if status=='reserved':clock['now']=plan.valid_until+1
   return result
  with patch.object(self.ledger,'reviewed_binding',side_effect=delayed_check),patch.object(m.time,'time',side_effect=lambda:clock['now']):
   with self.assertRaises(Unknown):runner.submit(self.plan)
  self.assertFalse(any(req.method=='POST' for req in self.calls))
  import sqlite3
  with __import__('contextlib').closing(sqlite3.connect(self.db)) as db:
   self.assertEqual(db.execute('select status from reservations').fetchone()[0],'unknown')

if __name__=='__main__':unittest.main()
