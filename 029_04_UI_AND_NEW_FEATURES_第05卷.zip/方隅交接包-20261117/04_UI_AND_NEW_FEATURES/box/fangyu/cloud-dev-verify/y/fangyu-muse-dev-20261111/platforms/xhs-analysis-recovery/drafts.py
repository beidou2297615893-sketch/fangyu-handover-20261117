import sys,importlib.util,sqlite3
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'work/xhs-context-lite-analysis'));import run as c
spec=importlib.util.spec_from_file_location('consumer',root/'work/xhs-three-stage-integration/live_consumer.py');consumer=importlib.util.module_from_spec(spec);spec.loader.exec_module(consumer)
out=root/'work/xhs-analysis-recovery';rows=c.load(root/'work/xhs-three-stage-integration/live-consumer/batch-0004/input.json');analyses=c.load(out/'analysis.json')
entries,excluded=consumer.candidate_entries(rows,analyses,out)
# Include durable per-batch draft outputs, including those not yet aggregated by a running consumer.
with sqlite3.connect((root/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro',uri=True) as db:aliases=dict(db.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'"))
canon=lambda uid:aliases.get(uid,uid)
known=set()
for p in list((root/'work/xhs-three-stage-integration/live-consumer').glob('batch-*/draft-stage/batches/*/validated.json'))+list((root/'work/xhs-intent-drafts/batches').glob('*/validated.json')):
 for r in c.load(p):known.add(canon(r['customer_uid']))
safe=[]
for e in entries:
 uid=canon(e['row']['customer_uid'])
 if uid in known:excluded.append({'comment_id':e['row']['comment_id'],'reason':'既有草稿或同一归并客户'})
 else:known.add(uid);safe.append(e)
c.save(out/'draft-candidates.json',safe);c.save(out/'excluded.json',excluded)
spec=importlib.util.spec_from_file_location('drafts',root/'work/xhs-intent-drafts/run.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d);d.OUT=out/'draft-stage';d.OUT.mkdir(exist_ok=True)
provider=c.ai.CodexProvider();generated=[]
for i in range(0,len(safe),25):generated.extend(d.batch(i//25,safe[i:i+25],provider))
for r in generated:r['current_time_confirmed']=False;r['review_notes'].append('未在线复核客户当前是否仍在找房')
c.save(out/'drafts.json',generated);state=c.load(out/'state.json');state.update(status='completed',drafts=len(generated),nonempty_drafts=sum(bool(x['draft']) for x in generated),excluded=len(excluded),ledger_imported=False);c.save(out/'state.json',state);print(state)
