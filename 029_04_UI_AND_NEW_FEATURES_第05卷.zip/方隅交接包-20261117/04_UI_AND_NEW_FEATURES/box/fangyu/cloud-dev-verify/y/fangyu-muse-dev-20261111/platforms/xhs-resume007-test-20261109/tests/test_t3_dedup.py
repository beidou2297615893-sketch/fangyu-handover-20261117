"""T3: 真 sqlite 双跑，不重复增行；history_index 包装含 resume006 ROOT。"""
import json
import os
import sqlite3
from contextlib import closing
import sys
import time
import unittest
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SRC_DIR))

import resume007
from tests.fixture_builder import build_valid_fixture, create_ledger
from tests.fakes import FakeLive, FakeOnce, FakeScheduling, FakeClientFactory


class TestDedup(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        self.resume006_root = self.project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
        self.resume006_root.mkdir(parents=True)
        self.ledger = self.project / 'work/shared-acquisition-ledger/shared.sqlite3'
        self.ledger.parent.mkdir(parents=True)
        create_ledger(self.ledger)
        self.stop_today = self.project / 'work/xhs-resume-20261103/stop-today-resume007.json'
        self.stop_today.parent.mkdir(parents=True)
        self.session_home = Path(self.tmp.name) / 'session-home'
        self.session_home.mkdir()
        self.here_dir = Path(self.tmp.name) / 'here'
        self.here_dir.mkdir()
        self.env = {
            'XHS_RESUME007_RESUME006_ROOT': str(self.resume006_root),
            'XHS_RESUME007_LEDGER': str(self.ledger),
            'XHS_RESUME007_STOP_TODAY': str(self.stop_today),
            'XHS_RESUME007_HERE': str(self.here_dir),
            'XHS_RESUME007_PROJECT': str(self.project),
        }
        for k, v in self.env.items():
            os.environ[k] = v

        # 固定搜索结果，便于双跑对比
        self.fixed_notes = [{'note_id': f'n{i}', 'title': f'T{i}'} for i in range(4)]
        self.live = FakeLive()
        self.once = FakeOnce({
            'completed_notes': ['n0'],  # 首跑跳过 1 笔记
            'known_comments': [],
        })
        self.scheduling = FakeScheduling(max_batches=1)
        self.client_factory = FakeClientFactory('test-uid', delay=6.0, search_notes=self.fixed_notes)
        resume007._LOAD = lambda: (self.live, None, self.once, self.scheduling)
        resume007._CLIENT_FACTORY = self.client_factory
        self.uid = '123456789012345678901234'
        build_valid_fixture(self.resume006_root, self.session_home, self.uid, self.here_dir)

    def tearDown(self):
        for k in self.env:
            os.environ.pop(k, None)
        resume007._LOAD = None
        resume007._CLIENT_FACTORY = None
        self.tmp.cleanup()

    def _run(self, args):
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            old = sys.argv
            sys.argv = ['resume007.py'] + args
            try:
                code = resume007.main()
            finally:
                sys.argv = old
        return code, f.getvalue().strip()

    def _ledger_pairs(self):
        with closing(sqlite3.connect(self.ledger)) as db, db:
            return set(db.execute("SELECT customer, comment FROM leads WHERE platform='xiaohongshu'"))

    def test_preview_dedup_summary(self):
        code, out = self._run(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['already_known_notes'], 6)
        self.assertEqual(data['already_known_comments'], 8)

    def test_history_wrap_includes_resume006(self):
        code, out = self._run(['--uid', self.uid, '--session-home', str(self.session_home), '--execute'])
        self.assertEqual(code, 0, out)
        flat = [str(x) for group in self.once.all_roots for x in group]
        self.assertTrue(
            any(str(self.resume006_root.resolve()) == str(Path(x).resolve()) for x in flat),
            flat,
        )

    def test_sqlite_double_run_no_duplicate_rows(self):
        args = ['--uid', self.uid, '--session-home', str(self.session_home), '--execute']
        code1, out1 = self._run(args)
        self.assertEqual(code1, 0, out1)
        pairs1 = self._ledger_pairs()
        self.assertGreater(len(pairs1), 0)
        # 释放同秒 ROOT 名冲突：稍等或改时间戳依赖 — 新 ROOT 用 HHMMSS，同秒会 FileExistsError
        time.sleep(1.05)
        # 清 stop-today（若有）不影响；本测非 461
        if self.stop_today.exists():
            self.stop_today.unlink()
        code2, out2 = self._run(args)
        self.assertEqual(code2, 0, out2)
        pairs2 = self._ledger_pairs()
        self.assertEqual(pairs1, pairs2, '第二次执行不应新增重复 (customer,comment)')
        data2 = json.loads(out2)
        self.assertEqual(data2.get('new_registered'), 0)


if __name__ == '__main__':
    unittest.main()
