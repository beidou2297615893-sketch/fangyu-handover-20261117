import json,pathlib,sqlite3,shutil,datetime,os
b=pathlib.Path(__file__).resolve().parent
read=lambda p:json.loads((b/p).read_text(encoding='utf-8-sig'))
a=read('active-runner.json');p=read(a['plan']);c=read(a['directory']+'/control.json');identity=read('identity-account2-20261031.json');proof=read('strict-proof-account2-20261031.json')
now=datetime.datetime.now(datetime.timezone.utc);request='d63f1493-db7e-4bdd-99c9-1af91c3e94c6'
assert identity['account']['sec_uid']==p['account_uid']==proof['account_uid']
assert proof['verified'] and identity['connection_id']==proof['connection_id']
assert (now-datetime.datetime.fromisoformat(identity['observed_at'].replace('Z','+00:00'))).total_seconds()<300
assert not list(b.glob('runner-lease-*.json')) and c['pending'] is None and c['stopped']=='ledger_unknown'
backup=b/'resume-20261031-backup';backup.mkdir(exist_ok=False)
for source in ['active-runner.json',a['plan'],a['identity'],a['strict_proof'],a['directory']+'/control.json','last-failure-report.json','daily-report-state.json']:
 src=b/source
 if src.exists():shutil.copy2(src,backup/src.name)
db=sqlite3.connect(b/'runtime/collection.sqlite3',timeout=30);db.row_factory=sqlite3.Row
with sqlite3.connect(backup/'collection.sqlite3') as out:db.backup(out)
db.execute('BEGIN IMMEDIATE')
halt=db.execute('select * from account_halts where account_uid=?',(p['account_uid'],)).fetchone();assert halt and halt['request_id']==request and halt['state']=='unknown'
r=db.execute('select * from attempts where request_id=?',(request,)).fetchone();assert r['state']=='unknown' and r['added']==0
s=json.loads(r['spec']);response=json.loads(r['response']);assert s['kind']=='comments' and s['cursor']==280 and s['account_uid']==p['account_uid'] and response['transport_error']=='bridge_result_not_established'
assert db.execute('select count(*) from scan_pages where request_id=?',(request,)).fetchone()[0]==0
streams=[dict(x) for x in db.execute("select * from scan_streams where scan_id=? and account_uid=? and kind='comments' and target=?",(s['scan_id'],s['account_uid'],s['target']))]
assert streams and len(streams)==1 and streams[0]['cursor']==s['cursor'] and streams[0]['exhausted']==0
reason='用户2026-10-31明确要求继续抖音采集；已核验浏览器当前账号仍为北极学长且严格连接匹配。保留原未知请求和已完成分页，将该视频剩余分页本地暂留，不代表平台耗尽，不重发未知分页，不重置游标；继续其他已授权来源。'
db.execute("update scan_streams set exhausted=1 where scan_id=? and account_uid=? and kind='comments' and target=?",(s['scan_id'],s['account_uid'],s['target']))
db.execute('insert into recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) values(?,?,?,?,?,?)',(p['account_uid'],request,'user_explicit_resume_verified_same_account',reason,'用户本聊天2026-10-31继续采集并与回复语气窗口节省token筛选',now.isoformat()))
db.execute('delete from account_halts where account_uid=? and request_id=?',(p['account_uid'],request));assert db.execute('select changes()').fetchone()[0]==1
assert read(a['directory']+'/control.json')==c
db.commit();db.close()
review=dict(at=now.isoformat(),request_id=request,unknown_preserved=True,local_deferral_not_platform_exhaustion=True,isolated_video=s['target'],deferred_cursor=s['cursor'],previous_streams=streams,account_matches=True,reason=reason,baseline_qualified_comments=34840)
(b/'resume-20261031-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
p['previous_plan']=a['plan'];p['connection_id']=identity['connection_id'];p['resume_authorization']=reason;p['local_comment_deferrals']=[dict(request_id=request,video=s['target'],cursor=s['cursor'],reason='local_hold_unknown_result_not_platform_exhaustion')]
(b/'15-store-plan-account2-20261031.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
newdir=b/'runner-live-account2-20261031';newdir.mkdir(exist_ok=False);c['stopped']=None;c['plan_digest']='pending_offline_normalization';c['resumed_from']=a['directory'];c['resume_review']='resume-20261031-review.json'
(newdir/'control.json').write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(recovery_recorded=True,unknown_preserved=True,partial_cursor_preserved=s['cursor'],local_video_deferred=s['target'],backup_created=True)))
