# 独立账号采集候选

本目录是独立候选，原采集脚本、19号失败批次、真实账本和发送器没有修改。本次仅执行离线测试，未登录、未请求平台、未采集或回复。

账号不再写死。每批先向传入的同一个独立客户端核对真实 UID，必须明确 `guest=false`，有多个不一致身份、缺身份或游客标记不明确均停止。核对后才按这个 UID 读取本地客户映射；登记前再次实时核验，登记使用本批落盘的相同账号绑定。搜索和评论读取前后检查同一客户端的内存会话快照与独立会话文件指纹有无变化，不额外请求身份接口。昵称只展示，UID才用于绑定。操作者不明确时记为 `unknown`，不会伪造员工身份。

跨账号历史帖子、尝试过的帖子和评论仍全局防重。评论ID覆盖原历史JSON、共享账本及同批已读ID，不因换号失效。客户UID归并、已发送/在途/未知阻断、唯一约束和原子登记直接复用现有 collector/register，源码哈希固定。只有本批真正新增且与账本来源逐条匹配的评论进入 `new-ai-input.json`，不会把被挡住的客户交给后续分析。

## 验证

在项目根目录执行：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 'work/xhs-account-switch-candidate/run_verification.py'
```

最新测试为70项全部通过：28项候选测试及42项原collector/register回归。结果在本目录 `verification-result.json` 与 `full-verification.txt`。原测试以逐字复制件在候选目录运行，不改原测试；临时账本、合成账号和原文均在本目录。网络连接被测试护栏禁止。真实ReadClient经MockTransport模拟461与登录过期，核对不同脱敏诊断确实持久保存；不代表实际平台请求。

## 给接入者的运行方法

由当前主聊天先确认新账号登录成功及本次恢复授权。候选不提供登录、验证码处理、自动换号或发送功能。

先在本目录 `runtime` 内建立一个全新的专用任务目录，例如 `runtime/resume-20261029`。不要复用失败目录，不改19号批次。下一批以 `batch-0020`、关键词“古北找房”、第5页开始。下列命令默认只是预览，不读取会话、不请求平台、不写账本：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 'work/xhs-account-switch-candidate/collect_once.py' `
  --workspace 'work/xhs-account-switch-candidate/runtime/resume-20261029' `
  --batch batch-0020 --keyword '古北找房' --search-page 5 `
  --session-home 'work/xhs-standalone-session/browser-cli-new-account-20261029' `
  --ledger 'work/shared-acquisition-ledger/shared.sqlite3' `
  --source-db 'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'
```

确需执行时，在同一已审核命令末尾同时增加 `--execute --apply-to-shared-ledger`。这是实际平台读取和本地共享账本登记，不能把预览成功当作真实验收。代码只容许这个项目已有共享账本的精确路径作为显式例外；通常测试仅容许任务目录内账本。继续使用原 `.xhs-collection-runner.lock`，锁存在即停止，不自动删除旧锁。

真实执行读取指定独立目录中的既有会话，不复制或写出凭据，不改 HOME/USERPROFILE，不启用浏览器或默认账号兜底。上游帖子访问令牌与搜索会话缓存只留内存；本进程配置目录重定向到候选工作区。每次命令仅采一个明确页号的有界批次，成功后由调度层决定下一批/关键词，不能把单批完成称为持续任务结束。

每批保存 `account-binding.json`、`account-audit.jsonl`、带采集账号的 `collection.json`、增量 partial、尝试记录、防重统计、登记回执及新增AI输入。审计记账号、操作者或未知、任务、关键词、页码、时间和结果。账号审计与 leads 的 source 文件逐项关联；未改变 leads 表结构。失败另存 `failure-diagnostic.json`，只允许固定类别、HTTP状态、API错误码和阶段等白名单字段，不写异常原文、响应原文、Cookie、令牌或会话指纹。注册后写报告/选择失败一律标为 `registration_outcome_unknown_check_ledger`，先查账本，禁止自动重跑。

## 限制

- 这是经离线验证的单批候选，尚未真实平台验收，不代表整个CLI自动换号或发送链已经打通。
- 成功批次实时身份接口只请求2次，位于批首和登记前；中间用不可变内存会话快照和独立会话文件指纹检查变化。指纹只留内存，不写审计。原客户端每次读取至少间隔1秒；遇验证码、461、限流或请求异常停止，绝不重试或绕过。这是离线验证的优化，不承诺实际平台速度。
- 账号 `guest` 字段若真实响应未提供明确布尔值 false，会安全停止，不能擅自放宽。
- 全局锁只协调同机、同账本使用此锁的运行器；不是跨电脑共享锁，也不约束忽略该锁的其他程序。
- 工作区 `STOP` 只在这次命令开始前检查。已经发出的有限单批不会自动中断；跨批暂停由外部调度器负责。
- 一旦输出目录已存在（含失败或未知），拒绝复用；保留原 evidence。不会自动重发或自动重采未知结果。
- 有效身份来自实时同客户端读取，不从昵称、旧账号配置或扫码文件名推断；无法确认的员工写未知。

文件完整路径：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-account-switch-candidate/collect_once.py`

文件夹完整路径：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-account-switch-candidate`
