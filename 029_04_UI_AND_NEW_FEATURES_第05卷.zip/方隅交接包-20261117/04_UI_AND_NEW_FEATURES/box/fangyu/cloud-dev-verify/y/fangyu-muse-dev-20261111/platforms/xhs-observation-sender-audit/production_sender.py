"""One-attempt local-history sender. Preview is default; never retries a POST.

The live ledger must first receive the separately reviewed additive migration.
Platform reply history and other accounts remain unknown, not checked. A returned
comment ID is an acceptance receipt, not proof of public visibility.
"""
from contextlib import closing
from dataclasses import asdict, dataclass
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'xhs-standalone-reply'))
from standalone_reply import AccountLock, ControlledClient, FrozenReply, Refused, Unknown, load_independent_cookies
from migration_candidate import REAL_LEDGER

PREPARED_BATCH=ROOT.parent/'xhs-46-local-prepared-20261028'/'gubei-46-plan.json'
SOURCE_FILES={
 'mapping': ROOT.parent/'xhs-identity-audit'/'mapping-20261028-154115.json',
 'inputs': ROOT.parent/'cli-independent-20261027'/'followup-analysis-input.jsonl',
 'snapshot': ROOT.parent/'xhs-high-intent-157'/'priority-snapshot-20261028-173048.json',
 'preview': ROOT.parent.parent/'outputs'/'古北高意向回复预览'/'46位客户原话与拟回复.txt',
}


@dataclass(frozen=True)
class SendPlan(FrozenReply):
    canonical_customer: str
    def validate(self):
        super().validate()
        if not isinstance(self.canonical_customer, str) or not self.canonical_customer.strip():
            raise Refused('Local customer identity is required')


class HttpUnknown(Unknown):
    def __init__(self,status):
        self.status=status
        super().__init__('HTTP '+str(status)+'; no retry')


class OneAttemptClient(ControlledClient):
    """Keep the original exact-endpoint guard while preserving safe HTTP codes."""
    def _request_with_retry(self,method,url,**kwargs):
        if method=='GET' and url=='https://edith.xiaohongshu.com/api/sns/web/v2/user/me':
            if self._post_started:raise Refused('No requests after submission')
        elif method=='POST' and url=='https://edith.xiaohongshu.com/api/sns/web/v1/comment/post':
            self.plan.validate()
            expected={'note_id':self.plan.note_id,'content':self.plan.text,'target_comment_id':self.plan.comment_id,'at_users':[]}
            if not self._armed or not self._identity_checked or self._post_started or json.loads(kwargs.get('content','null'))!=expected:
                raise Refused('Frozen wire request mismatch or repeated attempt')
            self._post_started=True
        else:raise Refused('Endpoint outside single-attempt scope')
        response=self._http.request(method,url,**kwargs,follow_redirects=False)
        if response.status_code!=200:raise HttpUnknown(response.status_code)
        return response


def validate_prepared(plan,path,require_hashes=False):
    try: batch=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError,ValueError) as exc: raise Refused('Prepared batch unreadable') from exc
    rows=batch.get('rows') if isinstance(batch,dict) else None
    if (batch.get('schema')!='gubei-46-local-plan-v1' or batch.get('intended_account')!='蕾姆' or
        not isinstance(rows,list) or batch.get('count')!=len(rows)):
        raise Refused('Prepared batch schema invalid')
    matches=[r for r in rows if isinstance(r,dict) and r.get('attempt_id')==plan.attempt_id]
    if len(matches)!=1:raise Refused('Attempt must select exactly one prepared customer')
    row=matches[0]
    expected={'customer_id':plan.canonical_customer,'customer_uid':plan.customer_uid,'comment_id':plan.comment_id,
              'note_id':plan.note_id,'text':plan.text,'source_identity':'local_source_consistency_only',
              'platform_reply_history':'unknown','other_accounts_history':'unknown','send_status':'not_attempted_in_this_plan'}
    if any(row.get(k)!=v for k,v in expected.items()):raise Refused('Prepared customer or reply changed')
    if require_hashes:
        hashes=batch.get('source_sha256')
        if not isinstance(hashes,dict) or set(hashes)!=set(SOURCE_FILES):raise Refused('Prepared source hashes missing')
        for key,file in SOURCE_FILES.items():
            try: actual=hashlib.sha256(file.read_bytes()).hexdigest()
            except OSError as exc:raise Refused('Prepared source unavailable: '+key) from exc
            if actual!=hashes[key]:raise Refused('Prepared source changed: '+key)


def connect(path, synthetic=False):
    path = Path(path).resolve(strict=True)
    if synthetic:
        if not path.is_relative_to(ROOT) or path.name != 'synthetic.sqlite3':
            raise Refused('Test database must be an isolated synthetic database')
    elif path != REAL_LEDGER:
        raise Refused('Live operation requires exact shared ledger')
    db = sqlite3.connect(path.as_uri() + '?mode=rw', uri=True, timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db


def _check_observation_table(db, plan):
    """Check optional collected UID evidence while holding the reservation lock.

    Old ledgers without this table retain the previous sender contract. If a
    table is present, schema and both unique constraints must match the importer;
    local observations do not claim that platform reply history was checked.
    """
    entry=db.execute("SELECT type FROM sqlite_master WHERE name=?",('collection_uid_observations',)).fetchone()
    if entry is None:
        return
    if entry['type']!='table':
        raise Refused('Collection identity observation schema is incompatible')
    columns=db.execute('PRAGMA table_info("collection_uid_observations")').fetchall()
    actual=[(r['name'],r['type'].upper(),r['notnull'],r['pk']) for r in columns]
    expected=[('platform','TEXT',1,1),('platform_uid','TEXT',1,2),('canonical','TEXT',1,0),
              ('basis','TEXT',1,0),('source','TEXT',1,0),('observed_at','INTEGER',1,0)]
    if actual!=expected:
        raise Refused('Collection identity observation schema is incompatible')
    unique_indexes=set()
    for index in db.execute('PRAGMA index_list("collection_uid_observations")'):
        if not index['unique'] or index['partial']:
            continue
        name=index['name'].replace('"','""')
        fields=tuple(r['name'] for r in db.execute('PRAGMA index_info("'+name+'")'))
        unique_indexes.add(fields)
    if not {('platform','platform_uid'),('platform','canonical')}.issubset(unique_indexes):
        raise Refused('Collection identity observation constraints are incompatible')
    rows=db.execute('SELECT platform_uid,canonical,basis,source,observed_at FROM collection_uid_observations '
                    'WHERE platform=? AND (platform_uid=? OR canonical=?)',
                    ('xiaohongshu',plan.customer_uid,plan.canonical_customer)).fetchall()
    for row in rows:
        if (row['basis'] not in ('local_source_consistency_only','new_uid_candidate_not_platform_verified') or
            not isinstance(row['source'],str) or not row['source'].strip() or
            type(row['observed_at']) is not int or row['observed_at']<=0):
            raise Refused('Collection identity observation evidence is invalid')
        if row['platform_uid']!=plan.customer_uid or row['canonical']!=plan.canonical_customer:
            raise Refused('Collection UID and local customer mapping conflict')


def _reserve(path, plan, synthetic):
    plan.validate()
    with closing(connect(path, synthetic)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='local_sender_plans'").fetchone():
                raise Refused('Reviewed additive ledger migration is required')
            _check_observation_table(db,plan)
            if db.execute('SELECT 1 FROM identity_aliases a JOIN identity_aliases b ON a.platform=b.platform AND a.canonical=b.alias WHERE b.canonical<>a.canonical LIMIT 1').fetchone():
                raise Refused('Identity chain needs reconciliation')
            for table in ('leads','historical_assessments','historical_deliveries'):
                if db.execute(f'SELECT 1 FROM identity_aliases a JOIN {table} h ON a.platform=h.platform AND a.alias=h.customer WHERE a.alias<>a.canonical LIMIT 1').fetchone():
                    raise Refused('Split local identity history requires review')
            old=db.execute('SELECT * FROM reservations WHERE token=?',(plan.attempt_id,)).fetchone()
            if old:
                raise Refused('Attempt already exists; no repeat')
            target=db.execute('SELECT * FROM leads WHERE platform=? AND comment=?',('xiaohongshu',plan.comment_id)).fetchone()
            if not target or target['customer']!=plan.canonical_customer or target['status'] not in ('unverified','reviewed','history_clear'):
                raise Refused('Local target missing, changed or blocked')
            alias=db.execute('SELECT * FROM identity_aliases WHERE platform=? AND alias=?',('xiaohongshu',plan.customer_uid)).fetchone()
            if alias and alias['canonical']!=plan.canonical_customer:
                raise Refused('Platform UID maps to a conflicting local customer')
            chain=db.execute('SELECT canonical FROM identity_aliases WHERE platform=? AND alias=?',('xiaohongshu',plan.canonical_customer)).fetchone()
            if chain and chain['canonical']!=plan.canonical_customer:
                raise Refused('Identity chain requires reconciliation')
            if plan.customer_uid!=plan.canonical_customer:
                for table in ('leads','historical_assessments','historical_deliveries'):
                    if db.execute(f'SELECT 1 FROM {table} WHERE platform=? AND customer=? LIMIT 1',('xiaohongshu',plan.customer_uid)).fetchone():
                        raise Refused('Separate history exists for this UID')
            if db.execute("SELECT 1 FROM leads WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent') LIMIT 1",('xiaohongshu',plan.canonical_customer)).fetchone():
                raise Refused('Customer has existing unresolved or sent local history')
            if db.execute("SELECT 1 FROM reservations WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent') LIMIT 1",('xiaohongshu',plan.canonical_customer)).fetchone():
                raise Refused('Customer has existing reservation')
            if db.execute("SELECT 1 FROM historical_deliveries WHERE platform=? AND customer=? AND delivery_state<>'not_sent' LIMIT 1",('xiaohongshu',plan.canonical_customer)).fetchone():
                raise Refused('Customer has unresolved previous software delivery')
            # A later import can assign the same platform user a new internal key.
            # Check durable submitted plans inside this reservation transaction.
            prior_plans=db.execute("SELECT p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown','sent')",('xiaohongshu',)).fetchall()
            for prior in prior_plans:
                try:
                    prior_record=json.loads(prior['data'])
                    prior_plan=prior_record.get('plan') or prior_record.get('local_mode',{}).get('plan')
                    prior_uid=prior_plan['customer_uid']
                    if not isinstance(prior_uid,str) or not prior_uid:raise ValueError('missing platform UID')
                except (ValueError,TypeError,KeyError,AttributeError):
                    raise Refused('Prior reservation identity cannot be interpreted')
                if prior_uid==plan.customer_uid:
                    raise Refused('Platform UID has an existing unresolved or accepted local submission')
            rows=db.execute("SELECT r.status,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? AND r.status IN ('reserved','unknown')",('xiaohongshu',)).fetchall()
            for row in rows:
                if not row['data']:
                    raise Refused('Unattributed unresolved reservation requires reconciliation')
                try:
                    data=json.loads(row['data']); prior_sender=data['plan']['sender_uid']; result=data.get('result',{})
                except (ValueError,TypeError,KeyError):
                    raise Refused('Uninterpretable previous reservation')
                if prior_sender==plan.sender_uid:
                    if row['status']!='unknown' or result.get('kind')!='platform_receipt' or not result.get('receipt_id'):
                        raise Refused('Account has a previous unresolved submission')
            record={'plan':asdict(plan),'platform_replies_checked':False,'all_accounts_history_checked':False,
                    'identity_basis':'local_mapping_only','peer_reply':'unknown', 'result':None}
            db.execute("INSERT INTO reservations VALUES(?,?,?,?, 'reserved',NULL,?)",(plan.attempt_id,'xiaohongshu',plan.canonical_customer,plan.comment_id,int(time.time())))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',(plan.attempt_id,json.dumps(record,ensure_ascii=False)))
            db.execute("UPDATE leads SET status='reserved',review_time=NULL WHERE platform=? AND customer=? AND comment=?",('xiaohongshu',plan.canonical_customer,plan.comment_id))
            db.commit()
        except BaseException:
            db.rollback();raise


def _outcome(path,plan,synthetic,result):
    with closing(connect(path,synthetic)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            row=db.execute('SELECT * FROM reservations WHERE token=?',(plan.attempt_id,)).fetchone()
            stored=db.execute('SELECT data FROM local_sender_plans WHERE token=?',(plan.attempt_id,)).fetchone()
            if not row or row['status']!='reserved' or row['comment']!=plan.comment_id or row['customer']!=plan.canonical_customer or not stored:
                raise Refused('Reservation changed during submission')
            data=json.loads(stored['data'])
            if data.get('plan')!=asdict(plan):raise Refused('Stored plan changed')
            data['result']=result
            evidence=('Platform acceptance receipt '+result['receipt_id']+'; public visibility unverified' if result['kind']=='platform_receipt' else 'Single attempt unresolved; no retry')
            db.execute('UPDATE local_sender_plans SET data=? WHERE token=?',(json.dumps(data,ensure_ascii=False),plan.attempt_id))
            db.execute("UPDATE reservations SET status='unknown',evidence=? WHERE token=?",(evidence,plan.attempt_id))
            db.execute("UPDATE leads SET status='unknown',review_time=NULL WHERE platform=? AND customer=? AND comment=?",('xiaohongshu',plan.canonical_customer,plan.comment_id))
            db.commit()
        except BaseException:
            db.rollback();raise


class Runner:
    def __init__(self,db,client,synthetic=False):
        self.db=Path(db);self.client=client;self.synthetic=synthetic
    def submit(self,plan):
        plan.validate()
        if plan!=self.client.plan:raise Refused('Frozen request differs from plan')
        if not self.synthetic:validate_prepared(plan,PREPARED_BATCH,require_hashes=True)
        lock=(ROOT/'test-locks' if self.synthetic else ROOT.parent/'xhs-standalone-reply'/'account-locks')
        with AccountLock(lock,plan.sender_uid):
            self.client.identity()
            plan.validate()
            _reserve(self.db,plan,self.synthetic)
            try:
                if not self.synthetic:validate_prepared(plan,PREPARED_BATCH,require_hashes=True)
                plan.validate();self.client._armed=True
                data=self.client.send_once()
                receipt=data.get('comment') if isinstance(data,dict) else None
                receipt_id=receipt.get('id') if isinstance(receipt,dict) else None
                if not isinstance(receipt_id,str) or not receipt_id.strip() or len(receipt_id)>200 or not receipt_id.isprintable():
                    raise Unknown('Platform receipt missing')
                _outcome(self.db,plan,self.synthetic,{'kind':'platform_receipt','receipt_id':receipt_id,'public_visibility_checked':False})
                return 'receipt_received_unverified'
            except BaseException as exc:
                result={'kind':'unknown'}
                if isinstance(exc,HttpUnknown):result['http_status']=exc.status
                try:_outcome(self.db,plan,self.synthetic,result)
                except BaseException:pass
                suffix=('; HTTP '+str(exc.status)) if isinstance(exc,HttpUnknown) else ''
                raise Unknown('Single attempt unresolved; no retry'+suffix) from exc
            finally:self.client._armed=False


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',required=True,help='Exact frozen JSON target and authorized text')
    p.add_argument('--session-home',help='Already authenticated isolated CLI HOME')
    p.add_argument('--execute',action='store_true',help='Perform one single actual reply')
    args=p.parse_args()
    plan=SendPlan(**json.loads(Path(args.plan).read_text(encoding='utf-8-sig')));plan.validate()
    if not args.execute:
        print(json.dumps({'mode':'preview','plan':asdict(plan)},ensure_ascii=False));return
    if not args.session_home:raise Refused('Isolated CLI session is required')
    client=OneAttemptClient(load_independent_cookies(args.session_home),plan)
    try:result=Runner(REAL_LEDGER,client).submit(plan)
    finally:client.close()
    print(json.dumps({'result':result,'public_visibility_checked':False},ensure_ascii=False))


if __name__=='__main__':
    try:main()
    except (Refused,Unknown,sqlite3.Error,OSError,ValueError) as exc:
        print(json.dumps({'error':str(exc)},ensure_ascii=False),file=sys.stderr);raise SystemExit(2)
