"""inflight.batch=batch-0023 但词页未命中 plan → prior_state_changed（不回落 index 0）。"""
import json
import os
import sys
import unittest
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SRC_DIR))

import resume007
from tests.fixture_builder import build_valid_fixture, create_ledger
from tests.fakes import FakeLive, FakeOnce, FakeScheduling, FakeClientFactory


class TestInflightIndex(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        self.resume006_root = self.project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
        self.resume006_root.mkdir(parents=True)
        self.ledger = self.project / 'work/shared-acquisition-ledger/shared.sqlite3'
        self.ledger.parent.mkdir(parents=True)
        create_ledger(self.ledger)
        self.stop_today = self.project / 'work/xhs-resume-20261103/stop-today-resume007.json'
        self.stop_today.parent.mkdir(parents=True)
        self.session_home = Path(self.tmp.name) / 'session-home'
        self.session_home.mkdir()
        self.here_dir = Path(self.tmp.name) / 'here'
        self.here_dir.mkdir()
        self.env = {
            'XHS_RESUME007_RESUME006_ROOT': str(self.resume006_root),
            'XHS_RESUME007_LEDGER': str(self.ledger),
            'XHS_RESUME007_STOP_TODAY': str(self.stop_today),
            'XHS_RESUME007_HERE': str(self.here_dir),
            'XHS_RESUME007_PROJECT': str(self.project),
        }
        for k, v in self.env.items():
            os.environ[k] = v
        self.live = FakeLive()
        self.once = FakeOnce()
        self.scheduling = FakeScheduling()
        self.client_factory = FakeClientFactory('u', delay=6.0)
        resume007._LOAD = lambda: (self.live, None, self.once, self.scheduling)
        resume007._CLIENT_FACTORY = self.client_factory
        self.uid = '123456789012345678901234'
        build_valid_fixture(self.resume006_root, self.session_home, self.uid, self.here_dir)

    def tearDown(self):
        for k in self.env:
            os.environ.pop(k, None)
        resume007._LOAD = None
        resume007._CLIENT_FACTORY = None
        self.tmp.cleanup()

    def _run(self, args):
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            old = sys.argv
            sys.argv = ['resume007.py'] + args
            try:
                code = resume007.main()
            finally:
                sys.argv = old
        return code, f.getvalue().strip()

    def test_batch0023_wrong_keyword_rejected(self):
        state_path = self.resume006_root / 'state.json'
        state = json.loads(state_path.read_text(encoding='utf-8'))
        state['inflight'] = {
            'batch': 'batch-0023',
            'keyword': 'NOT-IN-PLAN',
            'page': 99,
            'remaining': 1,
        }
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
        # unit: index is None
        resume007.refresh_paths()
        self.assertIsNone(resume007._inflight_plan_index(state))
        code, out = self._run(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        self.assertEqual(json.loads(out)['reason'], 'prior_state_changed')
        roots = [p for p in self.resume006_root.parent.iterdir() if p.name.startswith('stores15-resume007-')]
        self.assertEqual(roots, [])


if __name__ == '__main__':
    unittest.main()
