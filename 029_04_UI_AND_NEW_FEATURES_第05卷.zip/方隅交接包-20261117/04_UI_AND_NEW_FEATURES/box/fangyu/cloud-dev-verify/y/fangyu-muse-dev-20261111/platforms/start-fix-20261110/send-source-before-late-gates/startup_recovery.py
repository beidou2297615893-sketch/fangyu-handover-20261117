"""Versioned repairs installed only after the controller holds all send locks."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path

P = Path(__file__).resolve().parent
VERSION = 'employee-resume-20261110'
VERIFY_BRANCH = """  if(verifyOwn){
   const [videoId,commentId]=process.argv.slice(3,5);
   if(!/^\\d+$/.test(videoId||'')||!/^\\d+$/.test(commentId||''))throw Error('目标编号无效');
   const attemptPath=path.join(__dirname,commentId+'.json');
   if(!fs.existsSync(attemptPath))throw Error('缺少原尝试记录，无法只读核对');
   const attempt=read(attemptPath);
   if(attempt.account_uid!==accountUid||String(attempt.comment_id||commentId)!==commentId)throw Error('Task account mismatch');
   const draft=attempt.reply&&attempt.reply.draft_text;
   if(typeof draft!=='string'||!draft)throw Error('缺少原文，无法只读核对');
   const {readOwnReply}=require('../douyin-local-control/target_reader.cjs');
   const diagnosis=await readOwnReply(client,connId,videoId,commentId,{accountUid,text:draft});
   console.log(JSON.stringify({status:'own_reply_check',diagnosis,submission_attempted:false,automatic_retry:false}));
   return;
  }
"""


def ensure_own_reply_verify(source):
    """Insert the read-only reply check into an older adapter. Never adds a publish path."""
    if "--verify-own-reply" in source:
        return source
    anchors = (
        "const preflight=process.argv[2]==='--preflight';\n",
        "const task=identityOnly||preflight?null:read(process.argv[2]);\n",
        "const connId=(preflight && process.argv[5]) ||",
        " if(identityOnly||preflight){\n",
        "   console.log(JSON.stringify({status:'target_check',diagnosis}));return;\n  }\n",
    )
    if any(source.count(anchor) != 1 for anchor in anchors):
        return source
    updated = source.replace(
        "const preflight=process.argv[2]==='--preflight';\n",
        "const preflight=process.argv[2]==='--preflight';\nconst verifyOwn=process.argv[2]==='--verify-own-reply';\n",
        1)
    updated = updated.replace(
        "const task=identityOnly||preflight?null:read(process.argv[2]);\n",
        "const task=identityOnly||preflight||verifyOwn?null:read(process.argv[2]);\n",
        1)
    updated = updated.replace(
        "const connId=(preflight && process.argv[5]) ||",
        "const connId=((preflight||verifyOwn) && process.argv[5]) ||",
        1)
    updated = updated.replace(" if(identityOnly||preflight){\n", " if(identityOnly||preflight||verifyOwn){\n", 1)
    needle = "   console.log(JSON.stringify({status:'target_check',diagnosis}));return;\n  }\n"
    updated = updated.replace(needle, needle + VERIFY_BRANCH, 1)
    if "--verify-own-reply" not in updated or "await post(" in VERIFY_BRANCH:
        return source
    return updated


def ensure_adapter_file(task):
    path = Path(task) / 'send_cli_once.cjs'
    old = path.read_text(encoding='utf-8-sig')
    updated = ensure_own_reply_verify(old)
    if updated == old:
        return False
    temporary = path.with_suffix('.verify.tmp')
    temporary.write_text(updated, encoding='utf-8')
    temporary.replace(path)
    with (Path(task) / 'startup-repairs.jsonl').open('a', encoding='utf-8') as log:
        log.write(json.dumps({'at': datetime.datetime.now().astimezone().isoformat(),
            'version': VERSION, 'files': [path.name],
            'hashes': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()},
            'submission_attempted': False}, ensure_ascii=False) + '\n')
    return True
PREFLIGHT = "        preflight = run_json([NODE, ADAPTER, '--preflight', item['video'], item['cid']])\n"
READ_TIMEOUT = '''        if (preflight.get('status') != 'target_check'
                and 'Request timeout' in (preflight.get('error') or '')):
            consecutive_read_timeouts += 1
            with (HERE / 'target-read-skips.jsonl').open('a', encoding='utf-8') as log:
                log.write(json.dumps({'at': now(), 'cid': item['cid'], 'video': item['video'],
                    'error': preflight['error'], 'submission_attempted': False}, ensure_ascii=False) + '\\n')
            if consecutive_read_timeouts >= 3:
                raise RuntimeError('连续3个目标读取超时，浏览器连接未及时响应，请检查抖音页面。')
            print('本条目标读取超时，尚未提交，暂跳过并继续下一条。', flush=True)
            continue
        consecutive_read_timeouts = 0
'''
ABSENT = '''                excluded.setdefault('comments', {})[item['cid']] = {
                    'reason': 'Target absent from exhausted comment list before submission',
                    'diagnosis': check, 'at': now(), 'submission_attempted': False}
                save(excluded_path, excluded)
                print('完整评论列表未找到该目标，已记录并跳过，继续下一条。', flush=True)'''


def ensure_local_bridge():
    # Reuse the already configured local service; never change its credentials.
    source = P.parents[1] / '抖音自用采集台/app.py'
    spec = importlib.util.spec_from_file_location('existing_douyin_bridge_launcher', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ensure_bridge()


def upgrade_task(task):
    changes = []
    runner = task / 'batch_reply_runner.py'
    old = runner.read_text(encoding='utf-8-sig')
    updated = old
    if 'consecutive_read_timeouts' not in updated and 'recover_preflight(' not in updated:
        if updated.count(PREFLIGHT) != 1 or updated.count('    new_sent = 0\n') != 1:
            raise RuntimeError('本地恢复修复未匹配当前程序版本，原文件保持不变')
        updated = updated.replace('    new_sent = 0\n', '    new_sent = 0\n    consecutive_read_timeouts = 0\n')
        updated = updated.replace(PREFLIGHT, PREFLIGHT + READ_TIMEOUT)
    if "'status': 'checking_target'" not in updated:
        updated = updated.replace(PREFLIGHT, "        save(HERE / 'batch-runner-status.json', {\n"
            "             'status': 'checking_target', 'reason': '正在读取下一目标；不可见的目标会跳过。',\n"
            "             'updated_at': now(), 'confirmed_sent': used, 'process_id': os.getpid()})\n" + PREFLIGHT)
    updated = updated.replace("                print('本轮评论列表未找到该目标，暂跳过。', flush=True)", ABSENT)
    updated = updated.replace("raise RuntimeError('平台目标核验未完成，已停止发送')",
        "raise RuntimeError(preflight.get('error') or '平台目标核验未完成，请检查页面提示。')")
    if 'read_timeout_skips = 0' not in updated:
        updated = updated.replace('    new_sent = 0\n', '    new_sent = 0\n    read_timeout_skips = 0\n')
        updated = updated.replace('            consecutive_read_timeouts += 1\n',
            '            consecutive_read_timeouts += 1\n            read_timeout_skips += 1\n')
        updated = updated.replace("{'status': 'queue_complete',",
            "{'status': 'queue_partial' if read_timeout_skips else 'queue_complete',")
        updated = updated.replace("'reason': f'本轮近期队列已处理完毕，新增成功回执 {new_sent} 条。',",
            "'reason': (f'本轮新增成功回执 {new_sent} 条；{read_timeout_skips} 条只读超时未提交，下次启动可再读取。' if read_timeout_skips else f'本轮近期队列已处理完毕，新增成功回执 {new_sent} 条。'),")
    if 'recover_preflight(' not in updated:
        first=updated.index("        if (preflight.get('status') != 'target_check'")
        last=updated.index('        check = preflight.get', first)
        updated=updated[:first]+updated[last:]
        updated=updated.replace('    consecutive_read_timeouts = 0\n','')
        updated=updated.replace(PREFLIGHT,
            "        from read_recovery import recover_preflight\n"
            "        def report_recovery(message):\n"
            "            print(message, flush=True)\n"
            "            save(HERE / 'batch-runner-status.json', {'status': 'reconnecting', 'reason': message,\n"
            "                 'confirmed_sent': used, 'updated_at': now(), 'process_id': os.getpid()})\n"
            "        preflight = recover_preflight(HERE, ACCOUNT,\n"
            "            lambda: run_json([NODE, ADAPTER, '--preflight', item['video'], item['cid']]),\n"
            "            require_send_allowed, report_recovery)\n")
        branch="        if check.get('target_present') is not True:\n"
        updated=updated.replace(branch,branch+
            "            if check.get('incomplete') and check.get('comments_status', 0) == 0:\n"
            "                read_timeout_skips += 1\n"
            "                with (HERE / 'target-read-skips.jsonl').open('a', encoding='utf-8') as log:\n"
            "                    log.write(json.dumps({'at': now(), 'cid': item['cid'], 'video': item['video'],\n"
            "                        'diagnosis': check, 'submission_attempted': False}, ensure_ascii=False) + '\\n')\n"
            "                print('本条只读分页暂未完成，进度已保存，暂跳过并继续下一条。', flush=True)\n"
            "                continue\n")
        # Page timeouts do not mean an absent target or an offline browser.
        updated=updated.replace("        if preflight.get('status') != 'target_check' or check.get('detail_status') != 0:",
            "        if check.get('read_timeout'):\n"
            "            read_timeout_skips += 1\n"
            "            with (HERE / 'target-read-skips.jsonl').open('a', encoding='utf-8') as log:\n"
            "                log.write(json.dumps({'at': now(), 'cid': item['cid'], 'video': item['video'],\n"
            "                    'diagnosis': check, 'submission_attempted': False}, ensure_ascii=False) + '\\n')\n"
            "            print('本条只读请求暂未返回，尚未提交；继续下一条。', flush=True)\n"
            "            continue\n"
            "        if preflight.get('status') != 'target_check' or check.get('detail_status') != 0:")
    if "if manifest.get('live_preflight', False):" not in updated:
        # User requested CLI to consume the approved list directly. Keep the
        # optional read-only diagnostic path, but do not scan before publishing.
        begin=updated.index("        save(HERE / 'batch-runner-status.json', {\n             'status': 'checking_target'")
        end=updated.index('        if prepared:\n            priority =',begin)
        diagnostic=updated[begin:end]
        updated=updated[:begin]+"        if manifest.get('live_preflight', False):\n"+''.join('    '+line if line.strip() else line for line in diagnostic.splitlines(True))+"        else:\n            check = {'verification_basis': 'approved_upstream_queue', 'live_target_check_performed': False}\n"+updated[end:]
        begin=updated.index("        if check.get('read_timeout'):")
        end=updated.index('        require_send_allowed()\n        args =',begin)
        checks=updated[begin:end]
        updated=updated[:begin]+"        if manifest.get('live_preflight', False):\n"+''.join('    '+line if line.strip() else line for line in checks.splitlines(True))+updated[end:]
    if 'preserve_unavailable(HERE' not in updated and 'from attempt_recovery import finish_attempt' not in updated:
        updated=updated.replace("        if status != 'sent':\n",
            "        if status != 'sent':\n"
            "            from publish_recovery import preserve_unavailable\n"
            "            if status == 'unknown' and preserve_unavailable(HERE, item['cid'], result):\n"
            "                print('本条未取得成功回执且视频详情不可用；保留未知记录、不重发，继续下一条。', flush=True)\n"
            "                continue\n")
        updated=updated.replace("        print(f'正在处理第 {used + 1} 条：{item[\"text\"]}', flush=True)",
            "        save(HERE / 'batch-runner-status.json', {'status': 'publishing', 'reason': '正在提交下一条并等待平台回执。',\n"
            "             'confirmed_sent': used, 'updated_at': now(), 'process_id': os.getpid()})\n"
            "        print(f'正在处理第 {used + 1} 条：{item[\"text\"]}', flush=True)")
    if 'status_replace_retry_v1' not in updated:
        begin=updated.index('def save(path, data):\n')
        end=updated.index('\ndef digest(',begin)
        updated=updated[:begin]+'''def save(path, data):
    # status_replace_retry_v1: Windows readers may briefly hold the target open.
    import tempfile
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out, ensure_ascii=False, indent=2)
        for attempt in range(20):
            try:
                os.replace(name, path)
                return
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        if os.path.exists(name):
            os.unlink(name)
''' + updated[end:]
    if 'from attempt_recovery import finish_attempt' not in updated:
        begin=updated.index("        if status != 'sent':", updated.index('        record_outcome(task, status, result)'))
        end=updated.index("        print(f'SUCCESS",begin)
        updated=updated[:begin]+"""        if status != 'sent':
            from attempt_recovery import finish_attempt, skipped_count
            confirmed = finish_attempt(HERE, task, result, run_json=run_json, node=NODE,
                adapter=ADAPTER, record=record_outcome, load=load, save=save, now=now)
            if not confirmed:
                consecutive_skips = skipped_count(consecutive_skips)
                print(f'本条已留账并跳过，连续{consecutive_skips}条，继续下一条。', flush=True)
                continue
        consecutive_skips = 0
"""+updated[end:]
        updated=updated.replace('    new_sent = 0\n','    new_sent = 0\n    consecutive_skips = int(os.environ.get("DOUYIN_RESUME_SKIPS", "0"))\n',1)
        # Count new preflight skips, not old rows already in the ledger.
        first=updated.index("        if manifest.get('live_preflight', False):")
        end=updated.index('        args = [sys.executable',first)
        lines=updated[first:end].splitlines(True)
        for index,line in enumerate(lines):
            if line.strip()=='continue':
                indent=line[:len(line)-len(line.lstrip())]
                lines[index]=indent+'from attempt_recovery import skipped_count\n'+indent+'consecutive_skips = skipped_count(consecutive_skips)\n'+line
        updated=updated[:first]+''.join(lines)+updated[end:]
        legacy="    approved = set(load(auth_path).get('preserve_unknown_comments', [])) if auth_path.exists() else set()"
        updated=updated.replace(legacy,"    auth = load(auth_path) if auth_path.exists() else {}\n"
            "    approved = set(auth.get('preserve_unknown_comments', [])) | set(auth.get('isolated_unknown_comments', []))")
    for path, before, after in [(runner, old, updated)]:
        if before != after:
            compile(after, str(path), 'exec')
            changes.append((path, before, after))
    resume = task / 'resume_after_confirmation.py'
    old = resume.read_text(encoding='utf-8-sig')
    updated = old.replace("receipt.get('receipt', {}).get('status_code')", "(receipt.get('receipt') or {}).get('status_code')")
    if old != updated:
        compile(updated, str(resume), 'exec')
        changes.append((resume, old, updated))
    adapter=task/'send_cli_once.cjs'
    old=adapter.read_text(encoding='utf-8-sig')
    updated=old
    if 'readTarget(client' not in old:
        start=old.index('   const check=await client.call',old.index('if(preflight)'))
        end=old.index('\n  }',start)
        replacement="""   const {readTarget}=require('../douyin-local-control/target_reader.cjs');
   const checkpointPath=path.join(__dirname,commentId+'-read-checkpoint.json');
   const checkpoint=fs.existsSync(checkpointPath)?read(checkpointPath):null;
   const diagnosis=await readTarget(client,connId,videoId,commentId,{checkpoint,
    onProgress:point=>{fs.writeFileSync(checkpointPath,JSON.stringify(point));
     const statePath=path.join(__dirname,'batch-runner-status.json');
     if(fs.existsSync(statePath)){const state=read(statePath);state.reason='正在分段读取目标评论，第'+point.pages+'页；尚未提交。';state.updated_at=new Date().toISOString();fs.writeFileSync(statePath,JSON.stringify(state));}},
    clearCheckpoint:()=>{if(fs.existsSync(checkpointPath))fs.unlinkSync(checkpointPath);}});
   console.log(JSON.stringify({status:'target_check',diagnosis}));return;"""
        updated=old[:start]+replacement+old[end:]
    updated=ensure_own_reply_verify(updated)
    if 'assertPageReady(client' not in updated:
        anchor='(async()=>{try{\n'
        if updated.count(anchor)!=1 or '--verify-own-reply' not in updated:
            raise RuntimeError('发送适配器版本无法核验，已停止。')
        updated=updated.replace(anchor,anchor+" const {assertPageReady}=require('../douyin-local-control/page_guard.cjs');\n"
            " await assertPageReady(client,connId);\n",1)
    if updated!=old:
        changes.append((adapter,old,updated))
    for path, before, after in changes:
        backup = path.with_name(path.name + '.before-' + VERSION)
        if not backup.exists():
            backup.write_text(before, encoding='utf-8')
        temporary = path.with_suffix('.recovery.tmp')
        temporary.write_text(after, encoding='utf-8')
        temporary.replace(path)
    if changes:
        with (task / 'startup-repairs.jsonl').open('a', encoding='utf-8') as log:
            log.write(json.dumps({'at': datetime.datetime.now().astimezone().isoformat(),
                'version': VERSION, 'files': [p.name for p, _, _ in changes],
                'hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p, _, _ in changes},
                'submission_attempted': False}, ensure_ascii=False) + '\n')
