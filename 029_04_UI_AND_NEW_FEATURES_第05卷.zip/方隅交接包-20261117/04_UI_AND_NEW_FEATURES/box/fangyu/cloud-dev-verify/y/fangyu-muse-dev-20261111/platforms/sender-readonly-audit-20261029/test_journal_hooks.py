import unittest
from types import SimpleNamespace
from journal_hooks_candidate import install,JournalFailure
class T(unittest.TestCase):
 def test_order(self):
  events=[]
  s=SimpleNamespace(_reserve=lambda *a:events.append("reserve_commit"),_outcome=lambda *a:events.append("outcome_commit"))
  install(s,"db","log",lambda *a:events.append("sync"));s._reserve();s._outcome()
  self.assertEqual(events,["sync","reserve_commit","sync","outcome_commit","sync"])
 def test_start_failure_blocks_install(self):
  s=SimpleNamespace(_reserve=lambda:None,_outcome=lambda:None);original=s._reserve
  with self.assertRaises(OSError):install(s,"db","log",lambda *a:(_ for _ in ()).throw(OSError()))
  self.assertIs(s._reserve,original)
 def test_reserve_log_failure_propagates_before_post(self):
  events=[]
  def sync(*a):
   events.append("sync")
   if len(events)>1:raise OSError()
  s=SimpleNamespace(_reserve=lambda:events.append("committed"),_outcome=lambda:None)
  install(s,"db","log",sync)
  with self.assertRaises(JournalFailure):s._reserve()
  self.assertEqual(events,["sync","committed","sync"])
 def test_outcome_failure_cannot_be_success(self):
  calls=[0]
  def sync(*a):
   calls[0]+=1
   if calls[0]>1:raise OSError()
  s=SimpleNamespace(_reserve=lambda:None,_outcome=lambda:"committed")
  install(s,"db","log",sync)
  with self.assertRaises(JournalFailure):s._outcome()
if __name__=="__main__":unittest.main()
