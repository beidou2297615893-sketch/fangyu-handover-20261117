"""Offline candidate-only age-gate tests; no live sender files are edited."""
import ast
from dataclasses import asdict
from datetime import datetime,timezone
import importlib.util
import hashlib
import json
import sqlite3
from contextlib import closing
from dataclasses import replace
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

STAGE=Path(__file__).resolve().parent
LIVE=STAGE.parent/'xhs-send-current-20261029'
sys.path.insert(0,str(LIVE))
import test_target_isolation as fixtures

spec=importlib.util.spec_from_file_location('staged_age_policy',STAGE/'candidate/target_isolation.py')
candidate=importlib.util.module_from_spec(spec);sys.modules[spec.name]=candidate;spec.loader.exec_module(candidate)
tree=ast.parse((STAGE/'candidate/bulk_run.py').read_text(encoding='utf8'))
function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='mapping_reason')
namespace={'datetime':datetime,'timezone':timezone,'CLOSED_WORDS':('已出租','已租出','已成交'),
           'AuthorizedTargetIsolationPolicy':candidate.AuthorizedTargetIsolationPolicy}
exec(compile(ast.Module(body=[function],type_ignores=[]),'candidate/bulk_run.py','exec'),namespace)
mapping_reason=namespace['mapping_reason']


class Tests(unittest.TestCase):
    def setUp(self):
        self.fixture=fixtures.Tests('test_business_unknown_is_durably_verified_then_next_customer_posts_and_cookie_digest_matches')
        # Existing synthetic fixture writes are redirected into this staging root.
        with patch('test_bulk_run.__file__',str(STAGE/'offline_fixture.py')):self.fixture.setUp()
        f=self.fixture;self.row=dict(f.fixture.rows[0]);self.meta={
            'customer_uid':self.row['customer_uid'],'canonical_customer':self.row['customer_id'],
            'original_comment':'synthetic original question','post_title':'available apartment',
            'published_at':'2026-07-28T00:00:00+00:00'}
        self.history_path=f.b.root/'historical.jsonl'
        self.history={**self.row,'original_comment':self.meta['original_comment'],'post_title':self.meta['post_title'],
            'published_at':self.meta['published_at'],'current_need_confirmed':False,'actual_housing_facts_verified':False,
            'hold_reasons':[],'factual_scope':'offer_to_check_not_assertion_of_inventory_price_location_or_appointment',
            'review_notes_not_cleared':True,'historical_comment_days_old':95.87}
        self.history_path.write_text(json.dumps(self.history)+'\n',encoding='utf8')
        self.sha=hashlib.sha256(self.history_path.read_bytes()).hexdigest()
        self.constant=patch.object(candidate,'HISTORICAL_SOURCE_SHA',self.sha,create=True);self.constant.start()
        auth=json.loads(f.authorization.read_text(encoding='utf8'))
        auth.update(send_all_authorized=True,historical_over_60_days_authorized=True,
            historical_priority='after_recent_batches',historical_source_sha256=self.sha)
        f.authorization.write_text(json.dumps(auth),encoding='utf8')
        data=asdict(f.policy);data['authorization_sha256']=hashlib.sha256(f.authorization.read_bytes()).hexdigest()
        data['historical_age_override']={'source_path':str(self.history_path),'source_sha256':self.sha}
        self.data=data

    def tearDown(self):self.constant.stop();self.fixture.tearDown()

    def policy(self):return candidate.AuthorizedTargetIsolationPolicy.from_mapping(self.data)

    def reason(self,policy=None,meta=None,row=None):
        return mapping_reason(row or self.row,meta or self.meta,'2026-11-01',policy=policy,batch_path=self.fixture.fixture.batch)

    def test_default_age_hold_remains_and_explicit_qualified_override_only_removes_age(self):
        self.assertEqual(self.reason(),'comment_older_than_60_days')
        old=dict(self.data);old.pop('historical_age_override')
        self.assertEqual(self.reason(candidate.AuthorizedTargetIsolationPolicy.from_mapping(old)),'comment_older_than_60_days')
        before=self.history_path.read_bytes()
        self.assertIsNone(self.reason(self.policy()))
        self.assertEqual(self.history_path.read_bytes(),before)
        self.assertIs(self.history['current_need_confirmed'],False)
        self.assertIs(self.history['review_notes_not_cleared'],True)

    def test_all_authorization_without_explicit_historical_scope_cannot_clear_age(self):
        auth=json.loads(self.fixture.authorization.read_text(encoding='utf8'));auth['historical_over_60_days_authorized']=False
        self.fixture.authorization.write_text(json.dumps(auth),encoding='utf8')
        self.data['authorization_sha256']=hashlib.sha256(self.fixture.authorization.read_bytes()).hexdigest()
        self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_changed_source_or_original_text_never_clears_age(self):
        self.assertEqual(self.reason(self.policy(),meta={**self.meta,'original_comment':'changed'}),'comment_older_than_60_days')
        self.history_path.write_text('{}\n',encoding='utf8')
        self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_closed_title_identity_and_unknown_date_keep_their_original_holds(self):
        policy=self.policy()
        for meta,expected in [({**self.meta,'post_title':'已出租 apartment'},'post_no_longer_available'),
            ({**self.meta,'customer_uid':'other'},'target_mapping_conflict'),
            ({**self.meta,'published_at':'unknown'},'comment_date_unknown')]:
            self.assertEqual(self.reason(policy,meta=meta),expected)

    def test_active_semantic_or_fact_holds_cannot_be_cleared(self):
        for key,value in [('hold_reasons',['semantic_unresolved']),('semantic_invalid',True),
                          ('fact_assertion_unverified',True),('factual_scope','unverified_inventory_assertion')]:
            changed={**self.history,key:value}
            self.history_path.write_text(json.dumps(changed)+'\n',encoding='utf8')
            sha=hashlib.sha256(self.history_path.read_bytes()).hexdigest()
            self.data['historical_age_override']['source_sha256']=sha
            auth=json.loads(self.fixture.authorization.read_text(encoding='utf8'));auth['historical_source_sha256']=sha
            self.fixture.authorization.write_text(json.dumps(auth),encoding='utf8')
            self.data['authorization_sha256']=hashlib.sha256(self.fixture.authorization.read_bytes()).hexdigest()
            with patch.object(candidate,'HISTORICAL_SOURCE_SHA',sha):
                self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_known_platform_restriction_is_not_cleared_by_age_authorization(self):
        state=json.loads(self.fixture.b.state.read_text(encoding='utf8'))
        state['diagnostic']={'verification_header_present':True}
        self.fixture.b.state.write_text(json.dumps(state),encoding='utf8')
        self.data['platform_state_sha256']=hashlib.sha256(self.fixture.b.state.read_bytes()).hexdigest()
        self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def held_source(self,extra_hold=None):
        q=self.fixture.fixture
        labels=['fresh_authoritative_dedup_required','current_need_unknown','platform_thread_not_checked']
        entries=[{**row,**{k:v for k,v in self.history.items() if k not in self.row},
                  'hold_reasons':labels+([extra_hold] if extra_hold else [])} for row in q.rows]
        q.ready.write_text('\n'.join(json.dumps(e) for e in entries),encoding='utf8')
        sha=hashlib.sha256(q.ready.read_bytes()).hexdigest()
        approval=json.loads(q.approval.read_text(encoding='utf8'));approval['source_files']=[str(q.ready)];approval['source_hashes']=[sha]
        q.approval.write_text(json.dumps(approval),encoding='utf8')
        tone_sha=hashlib.sha256(q.approval.read_bytes()).hexdigest()
        batch=json.loads(q.batch.read_text(encoding='utf8'));batch['source_sha256']['tone_approval']=tone_sha
        q.batch.write_text(json.dumps(batch),encoding='utf8')
        auth=json.loads(self.fixture.authorization.read_text(encoding='utf8'));auth['historical_source_sha256']=sha
        self.fixture.authorization.write_text(json.dumps(auth),encoding='utf8')
        self.data.update(tone_approval_sha256=tone_sha,batch_sha256=hashlib.sha256(q.batch.read_bytes()).hexdigest(),
            authorization_sha256=hashlib.sha256(self.fixture.authorization.read_bytes()).hexdigest(),
            historical_age_override={'source_path':str(q.ready),'source_sha256':sha})
        return patch.object(candidate,'HELD4_SOURCE_SHA',sha,create=True)

    def test_held4_three_notes_allow_age_only_and_preserve_unknown_notes(self):
        with self.held_source():
            source=self.fixture.fixture.ready;before=source.read_bytes()
            self.assertIsNone(self.reason(self.policy()))
            self.assertEqual(source.read_bytes(),before)
            self.assertIs(json.loads(before.splitlines()[0])['current_need_confirmed'],False)

    def test_held4_any_other_active_hold_refuses_even_recent_target(self):
        with self.held_source('fact_or_identity_unresolved'):
            with self.assertRaises(candidate.scope.ScopeRefused):
                self.policy().validate_context(self.fixture.fixture.batch,self.fixture.b.uid)
            self.assertEqual(self.reason(self.policy()),'comment_older_than_60_days')

    def test_held4_native_transaction_preserves_old_history_and_duplicate_customer_guard(self):
        with self.held_source():
            b=self.fixture.b;plan=self.fixture.fixture.plan
            with closing(sqlite3.connect(b.db)) as db:
                before=dict(db.execute('SELECT token,data FROM local_sender_plans').fetchall())
            with patch.object(b.sender,'AuthorizedTargetIsolationPolicy',candidate.AuthorizedTargetIsolationPolicy):
                b.sender._reserve(b.db,plan,True,direct_id=True,scoped_isolation_policy=self.policy())
                with closing(sqlite3.connect(b.db)) as db:
                    db.execute('INSERT INTO leads VALUES(?,?,?,?,NULL,NULL,NULL,?)',
                        ('xiaohongshu',plan.canonical_customer,'synthetic-other-comment','unverified','synthetic'))
                    db.commit()
                with self.assertRaisesRegex(b.sender.Refused,'Customer has existing unresolved'):
                    b.sender._reserve(b.db,replace(plan,attempt_id='synthetic-no-retry',comment_id='synthetic-other-comment'),True,
                        direct_id=True,scoped_isolation_policy=self.policy())
            with closing(sqlite3.connect(b.db)) as db:
                after=dict(db.execute('SELECT token,data FROM local_sender_plans').fetchall())
            self.assertEqual({k:after[k] for k in before},before)


if __name__=='__main__':unittest.main()
