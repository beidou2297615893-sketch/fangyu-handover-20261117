import unittest
from resume import verified_session, ManualSessionObserver

class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.saved=[]
        self.args=dict(user_confirmed=True, browser_open=True,
            response={'after_challenge':True, 'status':200, 'host':'www.xiaohongshu.com',
                      'path':'/api/sns/web/v2/user/me','body':{'user_id':'u123','guest':False}},
            cookie_items=[{'name':'a1','value':'a','domain':'.xiaohongshu.com'},
                          {'name':'webId','value':'w','domain':'.xiaohongshu.com'},
                          {'name':'web_session','value':'s','domain':'.xiaohongshu.com'}],
            save=lambda cookies,identity:self.saved.append((cookies,identity)))

    def test_manually_confirmed_authenticated_response_saves_once(self):
        saved=[]
        result=verified_session(user_confirmed=True, browser_open=True,
            response={'after_challenge':True,'status':200,'host':'www.xiaohongshu.com','path':'/api/sns/web/v2/user/me',
                      'body':{'user_id':'u123','guest':False}},
            cookie_items=[{'name':'a1','value':'a','domain':'.xiaohongshu.com'},
                          {'name':'webId','value':'w','domain':'.xiaohongshu.com'},
                          {'name':'web_session','value':'s','domain':'.xiaohongshu.com'}],
            save=lambda cookies, identity:saved.append((cookies,identity)))
        self.assertEqual(result, {'status':'saved','uid':'u123'})
        self.assertEqual(len(saved),1)

    def test_error_envelope_never_counts_as_identity(self):
        self.args['response']['body']={'code':-100, 'data':{'user_id':'u123','guest':False}}
        self.assertEqual(verified_session(**self.args)['status'],'no_auth_evidence')
        self.assertEqual(self.saved,[])

    def test_no_user_trigger_never_reads_or_saves(self):
        self.args['user_confirmed']=False
        self.assertEqual(verified_session(**self.args)['status'],'awaiting_user')
        self.assertEqual(self.saved,[])

    def test_closed_browser_never_saves(self):
        self.args['browser_open']=False
        self.assertEqual(verified_session(**self.args)['status'],'page_closed')
        self.assertEqual(self.saved,[])

    def test_pre_challenge_response_is_stale(self):
        self.args['response']['after_challenge']=False
        self.assertEqual(verified_session(**self.args)['status'],'no_auth_evidence')

    def test_validation_error_and_wrong_origin_refused(self):
        for key,value in [('status',461),('host','example.xiaohongshu.com'),('path','/wrong')]:
            with self.subTest(key=key):
                response=dict(self.args['response']);response[key]=value
                self.assertEqual(verified_session(**{**self.args,'response':response})['status'],'no_auth_evidence')
        self.assertEqual(self.saved,[])

    def test_guest_or_missing_guest_or_conflicting_ids_refused(self):
        for body in ({'user_id':'u','guest':True}, {'user_id':'u'},
                     {'user_id':'u','guest':False,'basic_info':{'uid':'other'}},
                     {'user_id':'u','guest':'false'}):
            with self.subTest(body=body):
                response={**self.args['response'],'body':body}
                self.assertEqual(verified_session(**{**self.args,'response':response})['status'],'identity_unverified')

    def test_expected_uid_conflict_refused(self):
        self.assertEqual(verified_session(**self.args,expected_uid='different')['status'],'identity_conflict')

    def test_cookie_conflicts_or_lookalike_domain_refused(self):
        items=self.args['cookie_items']+[{'name':'web_session','value':'other','domain':'.xiaohongshu.com'}]
        self.assertEqual(verified_session(**{**self.args,'cookie_items':items})['status'],'session_conflict')
        items=[{**item,'domain':'.xiaohongshu.com.evil.org'} for item in self.args['cookie_items']]
        self.assertEqual(verified_session(**{**self.args,'cookie_items':items})['status'],'session_incomplete')

    def test_save_unknown_never_retries_and_does_not_disclose_exception(self):
        calls=[]
        def fail(*args):
            calls.append(True);raise RuntimeError('sensitive value')
        result=verified_session(**{**self.args,'save':fail})
        self.assertEqual(result,{'status':'save_outcome_unknown'})
        self.assertEqual(len(calls),1)

    def test_observer_saves_only_after_person_triggers_with_same_page_natural_response(self):
        class Context:
            calls=0
            def cookies(self):
                self.calls+=1
                return [{'name':'a1','value':'a','domain':'.xiaohongshu.com'},
                        {'name':'webId','value':'w','domain':'.xiaohongshu.com'},
                        {'name':'web_session','value':'s','domain':'.xiaohongshu.com'}]
        class Page:
            def __init__(self): self.context=Context()
            def is_closed(self): return False
        page=Page()
        class Frame: pass
        frame=Frame();frame.page=page
        class Response:
            url='https://www.xiaohongshu.com/api/sns/web/v2/user/me'
            status=200
            class request: method='GET'
            def json(self): return {'user_id':'u123','guest':False}
        response=Response();response.frame=frame
        obs=ManualSessionObserver(page,lambda c,i:self.saved.append((c,i)))
        obs.on_response(response)
        self.assertEqual(page.context.calls,0)
        self.assertEqual(self.saved,[])
        self.assertEqual(obs.finish_by_person(),{'status':'saved','uid':'u123'})
        self.assertEqual(page.context.calls,1)

    def test_observer_does_not_save_when_page_closes_during_cookie_read(self):
        class Page:
            closed=False
            def is_closed(self): return self.closed
        page=Page()
        class Context:
            def cookies(self):
                page.closed=True
                return self.items
        page.context=Context();page.context.items=self.args['cookie_items']
        class Frame: pass
        frame=Frame();frame.page=page
        class Response:
            url='https://www.xiaohongshu.com/api/sns/web/v2/user/me'
            status=200
            class request: method='GET'
            def json(self): return {'user_id':'u123','guest':False}
        response=Response();response.frame=frame
        obs=ManualSessionObserver(page,lambda c,i:self.saved.append((c,i)))
        obs.on_response(response)
        self.assertEqual(obs.finish_by_person(),{'status':'page_closed'})
        self.assertEqual(self.saved,[])

if __name__ == '__main__': unittest.main()
