import importlib.util
import json
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
from contextlib import closing
from datetime import datetime,timezone
from types import SimpleNamespace
import tempfile
import time
import unittest
from unittest.mock import patch
import httpx
from managed_send_client import make_client

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('send_adapter_existing_cli',PROJECT/'work/xhs-cli-standalone-entry/standalone_cli.py')
cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
UID='synthetic-sender'
IDENTITY='/api/sns/web/v2/user/me'
POST='/api/sns/web/v1/comment/post'

class Tests(unittest.TestCase):
 def setUp(self):
  self.guard=patch.object(socket.socket,'connect',side_effect=AssertionError('network_forbidden'));self.guard.start()
  self.temp=tempfile.TemporaryDirectory(dir=HERE);self.root=Path(self.temp.name)
  self.session=self.root/'cookies.json';self.original={'a1':'synthetic-a1','webId':'synthetic-web','web_session':'synthetic-session'}
  self.session.write_text(json.dumps(self.original),encoding='utf8')
  self.batch=self.root/'batch.json';self.batch.write_text('{}')
  self.db=self.root/'synthetic.sqlite3';self.db.write_bytes(b'')
  self.sender=cli.load_sender(PROJECT,self.db,self.batch,{})
  self.plan=self.sender.SendPlan(sender_uid=UID,customer_uid='synthetic-user',note_id='synthetic-note',comment_id='synthetic-comment',text='exact approved text',attempt_id='synthetic-attempt',authorized=True,verification_evidence='synthetic-only',valid_until=int(time.time())+240,source='synthetic',canonical_customer='synthetic-canonical')
  self.calls=[]
 def tearDown(self):
  self.temp.cleanup();self.guard.stop()
 def response(self,request,*,uid=UID,guest=False,headers=None):
  data={'user_id':uid,'guest':guest} if request.url.path==IDENTITY else {'comment':{'id':'synthetic-receipt'}}
  return httpx.Response(200,json={'success':True,'data':data},headers=headers)
 def client(self,handler=None,**kwargs):
  def call(request):
   self.calls.append(request)
   return (handler or self.response)(request)
  return make_client(self.sender,self.session,self.plan,transport=httpx.MockTransport(call),**kwargs)
 def test_transport_cookie_identity_updates_persist_and_reach_exact_post(self):
  def handler(request):
   return self.response(request,headers={'set-cookie':'[REDACTED:cookie_kv]; Domain=.xiaohongshu.com; Path=/; Secure'} if request.url.path==IDENTITY else None)
  with self.client(handler) as client:
   client.identity();client._armed=True;data=client.send_once()
  self.assertEqual([r.url.path for r in self.calls],[IDENTITY,POST])
  self.assertIn('[REDACTED:cookie_kv]',self.calls[1].headers['cookie'])
  self.assertEqual(json.loads(self.calls[1].content),{'note_id':'synthetic-note','content':'exact approved text','target_comment_id':'synthetic-comment','at_users':[]})
  self.assertEqual(json.loads(self.session.read_text())['acw_tc'],'synthetic-new')
  self.assertEqual(data['comment']['id'],'synthetic-receipt')
 def test_guest_or_wrong_uid_never_posts(self):
  for uid,guest in [(UID,True),('synthetic-other',False)]:
   with self.subTest(uid=uid,guest=guest):
    self.calls=[]
    with self.client(lambda r:self.response(r,uid=uid,guest=guest)) as client:
     with self.assertRaises(Exception):client.identity()
     client._armed=True
     with self.assertRaises(Exception):client.send_once()
    self.assertEqual([r.url.path for r in self.calls],[IDENTITY])
 def test_authentication_cookie_change_stops_before_post(self):
  with self.client(lambda r:self.response(r,headers={'set-cookie':'[REDACTED:cookie_kv]; Domain=.xiaohongshu.com; Path=/'})) as client:
   with self.assertRaises(Exception):client.identity()
   client._armed=True
   with self.assertRaises(Exception):client.send_once()
  self.assertEqual(len(self.calls),1)
  self.assertEqual(json.loads(self.session.read_text()),self.original)
 def test_external_session_replacement_after_identity_stops_before_post(self):
  with self.client() as client:
   client.identity();self.session.write_text('{}');client._armed=True
   with self.assertRaises(Exception):client.send_once()
  self.assertEqual([r.url.path for r in self.calls],[IDENTITY])
 def test_save_failure_stops_before_post(self):
  def fail(*args):raise OSError('synthetic save failure')
  with self.client(lambda r:self.response(r,headers={'set-cookie':'[REDACTED:cookie_kv]; Path=/'}),save_writer=fail) as client:
   with self.assertRaises(Exception):client.identity()
   client._armed=True
   with self.assertRaises(Exception):client.send_once()
  self.assertEqual(len(self.calls),1)
 def test_http_461_is_single_attempt_and_does_not_post(self):
  with self.client(lambda r:httpx.Response(461,json={'success':False})) as client:
   with self.assertRaises(Exception):client.identity()
   client._armed=True
   with self.assertRaises(Exception):client.send_once()
  self.assertEqual(len(self.calls),1)
 def test_post_timeout_is_unknown_and_never_retried(self):
  def handler(r):
   if r.url.path==POST:raise httpx.ReadTimeout('synthetic timeout',request=r)
   return self.response(r)
  with self.client(handler) as client:
   client.identity();client._armed=True
   with self.assertRaises(Exception) as caught:client.send_once()
   diagnostic=self.sender.failure_diagnostics(caught.exception,client)
   self.assertNotIn('success',diagnostic)
   self.assertNotIn('http_status',diagnostic)
   with self.assertRaises(Exception):client.send_once()
  self.assertEqual([r.url.path for r in self.calls],[IDENTITY,POST])
 def test_modified_wire_body_keeps_original_refusal(self):
  for note,comment,text in [('changed-note',self.plan.comment_id,self.plan.text),(self.plan.note_id,'changed-comment',self.plan.text),(self.plan.note_id,self.plan.comment_id,'changed-text')]:
   with self.subTest(note=note,comment=comment,text=text):
    self.calls=[]
    with self.client() as client:
     client.identity();client._armed=True
     with self.assertRaises(Exception):client.reply_comment(note,comment,text)
    self.assertEqual([r.url.path for r in self.calls],[IDENTITY])

 def test_http200_minus_one_message_categories_are_safe_and_never_retry(self):
  messages=[('操作太频繁，请稍后再试','rate_limit'),('请完成安全验证','verification'),
   ('请先登录','login'),('没有访问权限','permission'),('评论不存在或已删除','target_unavailable'),
   ('请求签名错误','signature'),('系统错误，请稍后再试','system_error'),('请求失败','unknown')]
  for message,category in messages:
   with self.subTest(category=category):
    self.calls=[]
    def handler(r):
     if r.url.path==IDENTITY:return self.response(r)
     return httpx.Response(200,json={'success':False,'code':-1,'msg':message+' SECRET-MESSAGE',
      'token':'SECRET-BODY-TOKEN'},headers={'x-private-header':'SECRET-HEADER'})
    with self.client(handler) as client:
     client.identity();client._armed=True
     try:client.send_once()
     except self.sender.XhsApiError as exc:diagnostic=self.sender.failure_diagnostics(exc,client)
     else:self.fail('API failure must remain a failure')
     with self.assertRaises(Exception):client.send_once()
    self.assertEqual(diagnostic['api_code'],-1)
    self.assertEqual(diagnostic['http_status'],200)
    self.assertIs(diagnostic['success'],False)
    self.assertEqual(diagnostic['message_category'],category)
    self.assertIs(diagnostic['verification_header_present'],False)
    self.assertNotIn('SECRET',json.dumps(diagnostic))
    self.assertEqual(sum(r.url.path==POST for r in self.calls),1)

 def test_http200_verification_header_presence_is_boolean_only(self):
  def handler(r):
   if r.url.path==IDENTITY:return self.response(r)
   return httpx.Response(200,json={'success':False,'code':-1,'msg':'系统错误'},
     headers={'verifytype':'SECRET-TYPE','verifyuuid':'SECRET-UUID'})
  with self.client(handler) as client:
   client.identity();client._armed=True
   try:client.send_once()
   except self.sender.XhsApiError as exc:diagnostic=self.sender.failure_diagnostics(exc,client)
   else:self.fail('must fail')
  self.assertIs(diagnostic['verification_header_present'],True)
  self.assertEqual(diagnostic['http_status'],200)
  self.assertNotIn('SECRET',json.dumps(diagnostic))

 def test_api_exception_response_payload_is_classified_without_message_leak(self):
  exc=self.sender.XhsApiError('SECRET-EXCEPTION',code='-1',response={
   'success':False,'code':-1,'msg':'没有权限 SECRET-TOKEN','data':{'token':'SECRET'}})
  client=SimpleNamespace(_post_started=True,managed_request_context={'stage':'send','endpoint':'comment_post'})
  diagnostic=self.sender.failure_diagnostics(exc,client)
  self.assertEqual(diagnostic['message_category'],'permission')
  self.assertEqual(diagnostic['api_code'],-1)
  self.assertNotIn('SECRET',json.dumps(diagnostic))

 def test_native_runner_unknown_retains_safe_response_in_ledger_and_bulk_event(self):
  import bulk_run as bulk
  subprocess.run([sys.executable,'-B','-X','utf8',str(PROJECT/'work/shared-acquisition-ledger/ledger.py'),
   '--db',str(self.db),'init'],check=True,capture_output=True)
  with closing(sqlite3.connect(self.db)) as db:
   db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL)')
   db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',
    ('xiaohongshu','synthetic-canonical','synthetic-comment','unverified','synthetic'))
   db.commit()
  self.sender.ROOT=self.root
  def handler(r):
   if r.url.path==IDENTITY:return self.response(r)
   return httpx.Response(200,json={'success':False,'code':-1,'msg':'系统错误 SECRET-BODY'},
    headers={'verifyuuid':'SECRET-UUID'})
  row={'customer_id':self.plan.canonical_customer,'customer_uid':self.plan.customer_uid,
   'note_id':self.plan.note_id,'comment_id':self.plan.comment_id,'attempt_id':self.plan.attempt_id,
   'text':self.plan.text}
  mapping={row['comment_id']:{'customer_uid':row['customer_uid'],'canonical_customer':row['customer_id'],
   'original_comment':'synthetic original','post_title':'available synthetic apartment',
   'published_at':datetime.now(timezone.utc).isoformat()}}
  with self.client(handler) as client:
   adapter=bulk.LiveAdapter.__new__(bulk.LiveAdapter)
   adapter.sender=self.sender;adapter.last_client=client;adapter.post_attempts=0
   adapter.identity=lambda:{'uid':UID,'guest':False};adapter.state=lambda row:'pending'
   adapter.close=lambda:None
   adapter.persist_platform_halt=lambda *args,**kwargs:{'halted':True}
   def submit(row):
    try:return self.sender.Runner(self.db,client,synthetic=True).submit(self.plan)
    finally:adapter.post_attempts+=int(client._post_started)
   adapter.submit=submit
   report=bulk.run([row],mapping,sender_uid=UID,session_home=self.root,run_dir=self.root/'bulk-run',
    execute=True,direct_id=True,adapter_factory=lambda root:adapter,interval=0)
  self.assertEqual(report['status'],'stopped_unknown')
  self.assertEqual(report['accepted'],0)
  self.assertEqual(sum(r.url.path==POST for r in self.calls),1)
  with closing(sqlite3.connect(self.db)) as db:
   self.assertEqual(db.execute('SELECT status FROM reservations').fetchone()[0],'unknown')
   native=json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])['result']
  events=[json.loads(line) for line in (self.root/'bulk-run/events.jsonl').read_text(encoding='utf8').splitlines()]
  event=next(event for event in events if event['event']=='unknown')['diagnostic']
  for diagnostic in (native,event):
   self.assertEqual(diagnostic['api_code'],-1)
   self.assertEqual(diagnostic['http_status'],200)
   self.assertIs(diagnostic['success'],False)
   self.assertEqual(diagnostic['message_category'],'system_error')
   self.assertIs(diagnostic['verification_header_present'],True)
   self.assertEqual(diagnostic['endpoint'],'comment_post')
   self.assertNotIn('SECRET',json.dumps(diagnostic))
 def test_nonboolean_success_or_missing_guest_never_arms_identity(self):
  for envelope in [{'success':1,'data':{'user_id':UID,'guest':True}},{'success':True,'data':{'user_id':UID}}]:
   with self.subTest(envelope=envelope):
    self.calls=[]
    with self.client(lambda r:httpx.Response(200,json=envelope)) as client:
     with self.assertRaises(Exception):client.identity()
     client._armed=True
     with self.assertRaises(Exception):client.send_once()
    self.assertEqual([r.url.path for r in self.calls],[IDENTITY])


 def test_original_runner_keeps_unknown_receipt_and_refuses_repeat(self):
  subprocess.run([sys.executable,'-B','-X','utf8',str(PROJECT/'work/shared-acquisition-ledger/ledger.py'),'--db',str(self.db),'init'],check=True,capture_output=True)
  with closing(sqlite3.connect(self.db)) as db:
   db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token))')
   db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',('xiaohongshu','synthetic-canonical','synthetic-comment','unverified','synthetic'))
   db.commit()
  self.sender.ROOT=self.root
  def handler(r):return self.response(r,headers={'set-cookie':'[REDACTED:cookie_kv]; Path=/'} if r.url.path==IDENTITY else None)
  with self.client(handler) as client:
   result=self.sender.Runner(self.db,client,synthetic=True).submit(self.plan)
  self.assertEqual(result,'receipt_received_unverified')
  with closing(sqlite3.connect(self.db)) as db:
   self.assertEqual(db.execute('SELECT status FROM reservations').fetchone()[0],'unknown')
   record=json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])
   self.assertEqual(record['result']['receipt_id'],'synthetic-receipt')
   self.assertIs(record['platform_replies_checked'],False)
   self.assertIs(record['all_accounts_history_checked'],False)
  with self.client(handler) as client:
   with self.assertRaises(Exception):self.sender.Runner(self.db,client,synthetic=True).submit(self.plan)
  self.assertEqual(sum(r.url.path==POST for r in self.calls),1)

if __name__=='__main__':unittest.main()
