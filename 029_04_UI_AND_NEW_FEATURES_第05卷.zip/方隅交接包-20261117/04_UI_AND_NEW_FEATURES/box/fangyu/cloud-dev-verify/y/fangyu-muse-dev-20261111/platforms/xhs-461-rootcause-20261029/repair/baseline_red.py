"""Run desired behavior against the untouched original reader, intentionally red."""
import os
import sys
import unittest
os.environ['XHS_SAFE_STOP_BASELINE'] = '1'
import test_safe_stop_rebind
result = unittest.TextTestRunner(verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromModule(test_safe_stop_rebind))
sys.exit(0 if result.wasSuccessful() else 1)
