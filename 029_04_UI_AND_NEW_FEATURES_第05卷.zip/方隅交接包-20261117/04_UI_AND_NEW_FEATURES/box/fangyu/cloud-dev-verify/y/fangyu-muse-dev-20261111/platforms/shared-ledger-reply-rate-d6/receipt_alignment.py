"""Read-only counts of already-persisted sent receipts, with no platform calls."""
import json,sqlite3
from collections import Counter
from contextlib import closing
from reply_rate import ROOT,LEDGER

def inspect():
    with closing(sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute("SELECT token,comment,customer,evidence FROM reservations WHERE platform='douyin' AND status='sent'").fetchall()
    tasks=[p for p in (ROOT/'work').glob('douyin-*') if p.is_dir()]
    counts=Counter()
    for token,cid,customer,evidence in rows:
        counts['sent_records']+=1
        matches=[p for p in tasks if str(token).startswith(p.name+'-')]
        if len(matches)!=1:counts['missing_unique_task']+=1;continue
        try:
            attempt=json.loads((matches[0]/(str(cid)+'.json')).read_text(encoding='utf-8-sig'))
            receipt=(json.loads(evidence or '{}').get('receipt') or {})
        except (OSError,ValueError,TypeError):counts['missing_attempt_or_receipt']+=1;continue
        flags={'token_customer':attempt.get('attempt_id')==token and str(attempt.get('customer_uid'))==str(customer),
         'success_reply_id':receipt.get('status_code')==0 and str(receipt.get('cid') or '').isdigit(),
         'account':bool(attempt.get('account_uid')) and receipt.get('sec_uid')==attempt['account_uid'],
         'parent':str(receipt.get('reply_id') or '')==str(cid),
         'text':bool((attempt.get('reply') or {}).get('draft_text')) and receipt.get('text')==(attempt.get('reply') or {}).get('draft_text'),
         'video':str(attempt.get('video_id') or '').isdigit()}
        for key,valid in flags.items():
            if not valid:counts['needs_'+key]+=1
        if all(flags.values()):counts['aligned_for_future_check']+=1
        else:counts['not_aligned']+=1
    return dict(counts)

if __name__=='__main__':print(json.dumps(inspect(),ensure_ascii=False))
