"""Prepare a local, unsent 15-person batch; does not call a platform."""
import hashlib
import json
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
ORIGINAL = ROOT / 'work/xhs-46-local-prepared-20261028/gubei-46-plan.json'
PREVIOUS_PREVIEW = ROOT / 'outputs/古北高意向回复预览/46位客户原话与拟回复.txt'
LEDGER = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
MAPPING = ROOT / 'work/xhs-identity-audit/mapping-20261028-154115.json'
INPUTS = ROOT / 'work/cli-independent-20261027/followup-analysis-input.jsonl'
SNAPSHOT = ROOT / 'work/xhs-high-intent-157/priority-snapshot-20261028-173048.json'
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/方隅公寓待回复预览'
PREVIEW = OUT / '待回复客户原话与新版回复.txt'
ACCOUNT = '5aa9b337e8ac2b4ab2d21957'

REPLIES = {
 32:'两房也可以看看方隅公寓，我介绍有优惠～',
 33:'宝宝，方隅公寓也可以了解一下，我介绍有优惠～',
 34:'如果还在找房，可以看看方隅公寓呀～',
 35:'一房也可以看看方隅公寓，我住这里，介绍有优惠～',
 36:'方隅公寓也可以了解一下，我介绍有优惠～',
 37:'找一房的话，可以看看方隅公寓呀～',
 38:'方隅公寓也可以看看，我就住这里，介绍有优惠～',
 39:'找房的话可以顺便了解一下方隅公寓～',
 40:'一房也可以看看方隅公寓，介绍有优惠呀～',
 41:'想看两房的话，可以了解一下方隅公寓，我介绍有优惠～',
 42:'方隅公寓可以了解下，我就住这里，介绍有优惠的～',
 43:'宝宝，方隅公寓还不错，我住这里，介绍有优惠呀～',
 44:'两房也可以看看方隅公寓，我介绍有优惠呀～',
 45:'方隅公寓也可以关注一下，我介绍有优惠～',
 46:'也可以看看方隅公寓，我住这儿，介绍有优惠～',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    batch = json.loads(ORIGINAL.read_text(encoding='utf-8-sig'))
    selected = [row for row in batch['rows'] if row['sequence'] in REPLIES]
    if len(selected) != 15 or set(row['sequence'] for row in selected) != set(REPLIES):
        raise ValueError('Pending batch membership mismatch')
    if len({row['customer_uid'] for row in selected}) != 15 or len({row['comment_id'] for row in selected}) != 15:
        raise ValueError('Repeated customer or comment')
    with sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro', uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        for row in selected:
            if db.execute('SELECT 1 FROM reservations WHERE token=?', (row['attempt_id'],)).fetchone():
                raise ValueError('Pending attempt already in the ledger')
            target = db.execute('SELECT customer,status FROM leads WHERE platform=? AND comment=?',('xiaohongshu',row['comment_id'])).fetchone()
            if not target or target[0] != row['customer_id'] or target[1] not in ('unverified','reviewed','history_clear'):
                raise ValueError('Pending lead changed or blocked')
            if db.execute("SELECT 1 FROM reservations WHERE platform=? AND customer=? AND status IN ('reserved','unknown','sent')",('xiaohongshu',row['customer_id'])).fetchone():
                raise ValueError('Customer already has a delivery reservation')
            if db.execute("SELECT 1 FROM historical_deliveries WHERE platform=? AND customer=? AND delivery_state<>'not_sent'",('xiaohongshu',row['customer_id'])).fetchone():
                raise ValueError('Customer has previous delivery history')
    text = PREVIOUS_PREVIEW.read_text(encoding='utf-8-sig')
    blocks = re.findall(r'第(\d+)位：([^\r\n]+)\r?\n帖子：([^\r\n]+)\r?\n对方说：([^\r\n]+)\r?\n拟回复：([^\r\n]+)',text)
    by_seq={int(number):(name,title,said) for number,name,title,said,_ in blocks}
    if len(blocks)!=46 or set(REPLIES)-set(by_seq): raise ValueError('Source preview cannot be matched')
    if any('古北' in reply or '方隅公寓' not in reply for reply in REPLIES.values()):
        raise ValueError('Unexpected locality or brand in reply')
    OUT.mkdir(parents=True,exist_ok=True)
    lines=['方隅公寓待回复客户与新版回复','', '以下15位尚未发送。地区统一使用“方隅公寓”；已受理客户和历史结果待核客户不在本名单中。','']
    for row in selected:
        name,title,said=by_seq[row['sequence']]
        lines += [f'客户：{name}',f'帖子：{title}',f'对方说：{said}',f'拟回复：{REPLIES[row["sequence"]]}','']
    with PREVIEW.open('x',encoding='utf-8',newline='\n') as f:f.write('\n'.join(lines))
    sources={'original_batch': ORIGINAL,'mapping': MAPPING,'inputs': INPUTS,'snapshot': SNAPSHOT,'updated_preview': PREVIEW}
    result={'schema':'xhs-local-plan-v1','intended_account_uid':ACCOUNT,
            'source_sha256':{name:digest(path) for name,path in sources.items()},'count':len(selected),'rows':[]}
    for row in selected:
        entry={k:row[k] for k in ('customer_id','customer_uid','comment_id','note_id','attempt_id','sequence',
                                   'source_identity','platform_reply_history','other_accounts_history','send_status')}
        entry['text']=REPLIES[row['sequence']]
        result['rows'].append(entry)
    with (WORK/'pending-batch.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    with (WORK/'source-manifest.json').open('x',encoding='utf-8') as f:json.dump({k:str(v.resolve()) for k,v in sources.items()},f,ensure_ascii=False,indent=2)
    print(json.dumps({'pending':len(selected),'sequences':[r['sequence'] for r in selected],
                      'old_attempt_ids_preserved':True,'network_requests':0},ensure_ascii=False))

if __name__=='__main__':main()
