"""Read-only Douyin keyword audit. Never imports or calls a platform transport."""
import collections,csv,datetime,json,pathlib,sqlite3
from runner_ledger_adapter import assess

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs'/'方隅抖音采集词效果'
master=json.loads((ROOT/'15-store-plan-strict.json').read_text(encoding='utf8'))
active=json.loads((ROOT/'active-runner.json').read_text(encoding='utf-8-sig'))
plan=json.loads((ROOT/active['plan']).read_text(encoding='utf8'))
accounts=set(plan.get('collection_accounts',[plan['account_uid']]))
stores={s['store_id']:s for s in master['stores']}
policy=json.loads((ROOT/'runner-audit-myeaj720/runner-qualification-policy.json').read_text(encoding='utf8'))
approved=set(policy['qualified_request_ids'])
with (ROOT.parent.parent/'outputs/方隅双平台文本业务/15家门店关键词/15家门店关键词总表.csv').open(encoding='utf-8-sig') as f:words=list(csv.DictReader(f))
metadata={r['关键词']:r for r in words}
metrics=collections.defaultdict(lambda:dict(pages=0,videos=set(),eligible_videos=set(),comments=set(),unknown=0))
all_comments=set();dates={};last_at=None
db=sqlite3.connect((ROOT/'runtime/collection.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;db.execute('BEGIN')
for a in db.execute('SELECT request_id,state,collected_at,spec,response FROM attempts ORDER BY rowid'):
 s=json.loads(a['spec'])
 if s['account_uid'] not in accounts:continue
 last_at=a['collected_at'];word=s.get('keyword','');m=metrics[word]
 if a['state']!='parsed':
  if s['kind']=='search' and a['state']=='unknown':m['unknown']+=1
  continue
 v=json.loads(a['response']).get('value',{})
 if s['kind']=='search':
  m['pages']+=1;store=stores.get(s.get('store_id'))
  for card in v.get('data') or []:
   post=card.get('aweme_info') if isinstance(card,dict) else None
   if not isinstance(post,dict) or post.get('aweme_id') is None:continue
   vid=str(post['aweme_id']);m['videos'].add(vid)
   if store and assess(post.get('desc') or '',store)['state']=='eligible':m['eligible_videos'].add(vid)
 elif s['kind']=='comments':
  e=s.get('eligibility');eligible=isinstance(e,dict) and e.get('state')=='eligible'
  if not eligible and not(a['request_id'] in approved and s['account_uid']==policy['account_uid']):continue
  for item in v.get('comments') or []:
   if item.get('cid') is None:continue
   cid=str(item['cid']);all_comments.add(cid);m['comments'].add(cid)
   t=item.get('create_time')
   if type(t) is int and t>0:dates[cid]=t
halts=[dict(x) for x in db.execute('SELECT request_id,state FROM account_halts WHERE account_uid=?',(plan['account_uid'],))]
db.close()
status=json.loads((ROOT.parent/'fangyu-text-business-20261029/当前文本处理运行状态.json').read_text(encoding='utf8'))['douyin']
classified={}
for line in pathlib.Path(status['result_file']).read_text(encoding='utf8').splitlines():
 if line.strip():
  r=json.loads(line);classified[str(r['comment_id'])]=r.get('interest_at_comment')
analyzed=set(classified)&all_comments;positive={cid for cid in analyzed if classified[cid] in ('high','super_high','medium')}
groups=collections.defaultdict(lambda:dict(configured=0,searched=set(),videos=set(),eligible_videos=set(),comments=set(),pages=0))
records=[]
for r in words:
 word=r['关键词'];m=metrics[word];group=groups[r['搜索顺序']];group['configured']+=1
 if m['pages']:group['searched'].add(word)
 for field in ('videos','eligible_videos','comments'):group[field].update(m[field])
 group['pages']+=m['pages'];covered=m['comments']&analyzed;highmed=covered&positive
 state='未搜索' if not m['pages'] else ('已有评论入账' if m['comments'] else '已搜索，暂无入口评论入账')
 if m['unknown']:state+='；有未知结果已隔离'
 records.append({'门店':r['门店名称'],'采集词':word,'词类':r['搜索顺序'],'搜索成功页数':m['pages'],'带回去重视频数':len(m['videos']),'符合租房地域条件视频数':len(m['eligible_videos']),'作为主入口采到去重评论数':len(m['comments']),'其中已完成意向分析评论数':len(covered),'其中初筛中高意向评论数':len(highmed),'进度':state})
now=datetime.datetime.now(datetime.timezone.utc);fresh=collections.Counter()
for cid in all_comments:
 t=dates.get(cid)
 if t is None:fresh['时间缺失']+=1;continue
 age=(now.timestamp()-t)/86400
 fresh['近30天' if age<=30 else '31至90天' if age<=90 else '91至365天' if age<=365 else '超过一年']+=1
summary={'snapshot_at':last_at,'total_comments':len(all_comments),'configured':len(words),'searched':sum(bool(metrics[r['关键词']]['pages']) for r in words),'comment_producing_keywords':sum(bool(metrics[r['关键词']]['comments']) for r in words),'current_account_halts':halts,'analysis_covered':len(analyzed),'analysis_highmed':len(positive),'freshness':dict(fresh),'groups':{k:{f:len(v) if isinstance(v,set) else v for f,v in g.items()} for k,g in groups.items()},'top_comment_keywords':sorted(records,key=lambda x:x['作为主入口采到去重评论数'],reverse=True)[:10],'top_analyzed_keywords':sorted(records,key=lambda x:x['其中初筛中高意向评论数'],reverse=True)[:10]}
OUT.mkdir(parents=True,exist_ok=True)
with (OUT/'全部采集词效果核对.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
(ROOT/'keyword-effectiveness-snapshot.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
report=['# 抖音采集词实际效果核对','',f'本次核对累计{len(all_comments):,}条租房相关来源去重评论；配置{len(words):,}词，成功搜索{summary["searched"]:,}词，已有{summary["comment_producing_keywords"]:,}词作为主入口产生评论。','', '这里只评价当前采集与初筛效果。租房相关视频不等于评论人正在求租；中高意向为已完成分析部分的内容初筛，不是确认客户。','', '| 词类 | 配置数 | 已搜索词 | 带回视频 | 符合租房地域条件的视频 | 主入口评论 | 已分析评论 | 初筛中高意向 |','|---|---:|---:|---:|---:|---:|---:|---:|']
for category,g in groups.items():
 report.append(f'| {category} | {g["configured"]} | {len(g["searched"])} | {len(g["videos"])} | {len(g["eligible_videos"])} | {len(g["comments"])} | {len(g["comments"]&analyzed)} | {len(g["comments"]&positive)} |')
report+=['','各行按本行去重；同一视频、评论可关联不同来源，不能把各行直接相加。来源条件按当前地域与租房规则离线复核。主入口评论采用实际采集时的来源词，属于调度结果，不是关键词独占贡献。意向分析覆盖不同，不能直接用数量给各类词判定优劣。','',f'已完成意向分析覆盖{len(analyzed):,}条，其中中高意向初筛{len(positive):,}条，其余评论尚不能据此评价意向。','', '## 评论时间分布','']
report += [f'- {k}：{v:,}条' for k,v in fresh.items()]
report += ['','时间使用评论原始发布时间；旧评论的当时意向不能当成现在仍有需求。','', '## 已产生较多评论的采集入口','', '| 采集词 | 主入口评论 | 已分析评论 | 初筛中高意向 |','|---|---:|---:|---:|']
for r in summary['top_comment_keywords']:report.append(f'| {r["采集词"]} | {r["作为主入口采到去重评论数"]} | {r["其中已完成意向分析评论数"]} | {r["其中初筛中高意向评论数"]} |')
(OUT/'采集词效果核对.md').write_text('\n'.join(report),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
