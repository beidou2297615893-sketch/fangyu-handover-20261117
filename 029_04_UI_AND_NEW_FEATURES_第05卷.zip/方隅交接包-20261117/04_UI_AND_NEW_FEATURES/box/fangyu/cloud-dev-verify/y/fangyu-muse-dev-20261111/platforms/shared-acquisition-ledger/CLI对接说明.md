# 方隅共用获客台账：CLI 对接说明

本目录仅为独立台账，未改现有软件和生产库。两个 CLI 必须使用同一绝对数据库路径和以下协议；没有接入之前，台账不能拦截绕过它的发送。此工具不调用平台、不授权发送。保留平台身份与授权核验、实时平台检查、原 CLI 限制及异常停机规则。

## 固定路径（PowerShell）

```powershell
$env:PYTHONUTF8='1'
$ledger='C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/ledger.py'
$db='C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/shared.sqlite3'
```

`python $ledger --db $db word-list` 列出全部候选词，`search-list` 列出搜索事件。不要把词库候选称作已启用或已搜索。各搜索状态用不同的唯一事件名记录，不覆盖历史：

```powershell
python $ledger --db $db search '此次搜索唯一事件名' '古北店' xiaohongshu '上海古北租房' completed '结果数量及来源说明'
```

平台仅用 `xiaohongshu`、`douyin`；状态仅用 `started`、`completed`、`partial`、`failed`。事件时间由台账记录。再次提交完全相同事件为幂等，内容不同则报错。

## 客户核对与预留

1. 先依据平台本人标识、原评论及原库证据，核对历史覆盖；再执行 `identity-bind`，把平台稳定客户标识映射到原库内部客户编号。没有旧记录也须经实际核查，以平台标识自身作为规范标识并记录证据；禁止猜测或因为新台账查不到就断言没有历史。该映射24小时有效，过期需重新绑定证据。随后将平台稳定客户标识及评论标识传入 `lead`，通过 `check` 查看同平台同一客户的所有已知记录。历史快照中的 `customer_id` 是软件内部哈希，无法自动等同 CLI 平台用户 ID；逐人核对真实身份映射、历史覆盖，不能因 ID 不匹配就断言无历史或用它绕过阻断。不同平台的人不会被自动合并，疑似同人必须人工查证。平台评论 ID 冲突报错。
2. 先将筛选信息放入 UTF-8 JSON 文件，内容如下，真实值应依据原帖、评论、时间和实时核验填写；切勿把示例当成证据：

```json
{"source":"原帖或评论链接", "intent":"rental", "store":"古北店", "match":"match", "pending":"仍需确认的事项", "draft":"拟回复草稿", "peer_reply":"none"}
```

`intent` 为 `rental`（明确求租）、`unverified`（待核实）或 `exclude`；`match` 为 `match`、`unverified`、`not_match`；`peer_reply` 为 `none`、`unknown`、`replied`。只有明确求租、门店匹配且确认对方未回复等于 `none` 才可能预留。无证据不得选已确认。筛选不等于实时平台回执。
3. 在确认我方全部相关账号历史及该客户关联标识，实时查看目标评论与回复后，`review` 记录操作者及具体证据；它是人工核实声明而非自动平台查询。未核实、已回复、进行中及回执未知一律禁止发；确认无重复后，24 小时内预留。不能仅凭历史快照或空字段做 `review`。

```powershell
python $ledger --db $db identity-bind xiaohongshu '平台客户稳定标识' '证据确认的原库客户编号' '身份对应、原库历史与平台已核查的具体证据'
python $ledger --db $db lead xiaohongshu '平台客户稳定标识' '平台评论稳定标识'
python $ledger --db $db check xiaohongshu '平台客户稳定标识' '平台评论稳定标识'
python $ledger --db $db assess xiaohongshu '平台客户稳定标识' '平台评论稳定标识' '筛选信息.json的完整路径'
python $ledger --db $db review xiaohongshu '平台客户稳定标识' '平台评论稳定标识' '操作者' '身份映射、历史及平台逐条核对证据'
python $ledger --db $db reserve xiaohongshu '平台客户稳定标识' '平台评论稳定标识' '本次尝试唯一随机标识'
```

调用方必须检查退出码为 0 且 JSON `granted` **严格为 true**，才获得唯一一次预留；仅退出码为 0 不够。相同标识再次调用会返回 `granted:false`，不得重复发送。其他失败均不得发送。获得预留后，发送前还须再次核实目标身份、评论、内容、平台状态和用户授权；如果核验失败，保留预留直到可证明未发送，再按下述流程处理。

无超时自动解锁：异常、中断、无回执保持阻断。平台明确成功、可能已提交但回执不明、以及有证据确认未发送，分别记录：

```powershell
python $ledger --db $db outcome '本次尝试唯一随机标识' sent '平台成功回执或可复核证据'
python $ledger --db $db outcome '本次尝试唯一随机标识' unknown '超时或回执不明的具体事实'
python $ledger --db $db outcome '本次尝试唯一随机标识' not_sent '确认请求从未发出或平台明确未发送的证据'
```

三条是互斥示例；`unknown` 只能在后来取得确凿证据后记录 `sent` 或 `not_sent`。`not_sent` 后重新筛选和实时核验。已确认发送不会自动解锁。各动作应由同一封装执行，禁止程序或人员先发送再补台账。

## 范围和验收

截至本次导入：1,869 位客户的 3,069 条历史评论标识全为 unverified；古北 1,319 条和跨店 290 条是独立来源候选，存在重合可能，不能简单作为去重总词数。跨店原资料标记未启用，细项依据需回到原门店资料核验。没有抖音历史导入证据，也没有实时平台回执。当前没有自动搜索、没有双 CLI 接线和真实发送验证。SQLite WAL 使用本机同一路径，不支持跨电脑/网络共享作为安全保证；禁止复制数据库后各自独立写入。定期一致性备份应使用 SQLite backup API，不能单独复制运行中的数据库主文件。

验证：`python C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/test_ledger.py`。测试使用隔离合成数据，不碰共享数据库。

## 2026-10-28 防重修订

身份映射必须显式记录证据，已有独立记录的别名不可静默合并；同一客户其他未核实评论、已发送、进行中或结果未知记录均阻断预留。一般 review 不会解除其他历史记录的阻断；只有实际核实该历史未发生我方回复时，才能以 history-clear 命令明确记录操作者和具体核验依据，24小时后需重新核查。不能把空库、普通审核或名字相同视为核实。有效候选需要非空来源、门店和草稿；结果确认为未发送后删除旧筛选，必须重新筛选及核验。预留不是发送许可，真实发送之前仍须重新核验身份、目标、正文、授权、账号互斥及最新状态；不同平台不能自动认定同一人。原软件发送链路尚未接入，可能绕过此台账；在真实桥接验证前不能称全局防重已生效。

历史逐条核实命令：`python $ledger --db $db history-clear xiaohongshu 平台客户稳定标识 旧评论标识 操作者 逐条核实未发送的具体证据`。这只是操作者声明，不是系统自动核验平台，证据不足不得调用。身份映射链、环或冲突禁止自动合并；发现旧链时全部操作失败并交由人工排查。

历史分析同时以快照形式载入，check 可查看历史判断、地域及理由；只是历史依据，不改变发送状态，不替代平台当前回读。发现旧版遗留身份映射链或身份分裂时，程序拒绝运行并等待人工核查，不自动合并。

已映射导入5条原软件历史投递记录（prepared 3、blocked 1、submitted 1）。submitted 标记 unknown 并阻断；其余记录只作为历史线索，不能推定为已发送或当前可发。每次仍核原软件及平台最新状态，历史快照不会自动更新。原库的古北租房历史请求仅以 partial 记录，不代表完成。
