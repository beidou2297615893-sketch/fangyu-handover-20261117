"""Offline integration candidate. send() is permanently fail-closed.

Only a built-in synthetic transport is available; no real transport injection,
credential loading, platform CLI dispatch, browser or network support exists.
"""
from dataclasses import dataclass, fields
from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parent
LEDGER_PROGRAM = ROOT.parent / 'shared-acquisition-ledger' / 'ledger.py'
OFFLINE_SOURCE = ROOT.parent / 'cli-independent-20261027' / 'offline-single-attempt' / 'reply_candidate.py'
spec = importlib.util.spec_from_file_location('original_offline_candidate', OFFLINE_SOURCE)
offline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(offline)

class Refused(RuntimeError): pass
class Unknown(RuntimeError): pass
@dataclass(frozen=True)
class Binding:
    internal_id: str
    platform_uid: str
    sender_uid: str
    note_id: str
    comment_id: str
    text: str
    mapping_evidence: str
class IsolatedLedger:
    """Runs unchanged ledger CLI only against a fresh database under this folder."""
    def __init__(self, path):
        self.path = Path(path).resolve()
        if not self.path.is_relative_to(ROOT) or self.path.exists():
            raise Refused('Fresh isolated database inside candidate folder required')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._run('init')

    def _run(self, *args):
        result = subprocess.run([sys.executable, str(LEDGER_PROGRAM), '--db', str(self.path), *args],
                                capture_output=True, encoding='utf-8', check=False)
        try: value = json.loads(result.stdout)
        except (ValueError, TypeError): raise Refused('Ledger response unavailable') from None
        if result.returncode != 0: raise Refused('Ledger refused operation: ' + str(value.get('error')))
        return value

    def seed(self, binding):
        """Synthetic fixture only. This is never evidence for a real customer."""
        self._run('identity-bind', 'xiaohongshu', binding.platform_uid, binding.internal_id,
                  'SYNTHETIC OFFLINE FIXTURE; ' + binding.mapping_evidence)
        self._run('lead', 'xiaohongshu', binding.platform_uid, binding.comment_id)
        data = {'source': 'SYNTHETIC OFFLINE FIXTURE', 'intent': 'rental', 'store': 'test',
                'match': 'match', 'pending': '', 'draft': binding.text, 'peer_reply': 'none'}
        fixture = self.path.parent / ('fixture-' + uuid.uuid4().hex + '.json')
        fixture.write_text(json.dumps(data), encoding='utf-8')
        self._run('assess', 'xiaohongshu', binding.platform_uid, binding.comment_id, str(fixture))
        self._run('review', 'xiaohongshu', binding.platform_uid, binding.comment_id,
                  'OFFLINE TEST', 'SYNTHETIC TEST ONLY; ' + binding.mapping_evidence)

    def check(self, binding):
        return self._run('check', 'xiaohongshu', binding.platform_uid, binding.comment_id)

    def reserve(self, binding, token):
        raise Refused('PAUSED: new upstream deduplication defects; reservation disabled')

    def _disabled_reserve_candidate(self, binding, token):
        raise Refused('PAUSED: no reservation permitted')
        return self._run('reserve', 'xiaohongshu', binding.platform_uid, binding.comment_id, token)

    def outcome(self, token, status):
        return self._run('outcome', token, status, 'SYNTHETIC OFFLINE ' + status)


class _SyntheticTransport:
    def __init__(self, binding, fault): self.binding, self.fault = binding, fault
    def identity(self): return self.binding.sender_uid
    def post_reply(self, *, note_id, comment_id, text, follow_redirects):
        if (note_id, comment_id, text, follow_redirects) != (self.binding.note_id, self.binding.comment_id, self.binding.text, False):
            raise Refused('Original runner target or redirect policy changed')
        if self.fault == 'timeout': raise TimeoutError('SYNTHETIC TIMEOUT')
        return {'status': 200, 'comment_id': 'SYNTHETIC-NOT-A-REAL-RECEIPT'}


class Candidate:
    def __init__(self, ledger): self.ledger = ledger

    def simulate(self, reviewed, current, fault=None):
        raise Refused('PAUSED: new upstream deduplication defects; simulation disabled')

    def _disabled_simulation_candidate(self, reviewed, current, fault=None):
        raise Refused('PAUSED: retained implementation cannot reserve or run')
        if not isinstance(reviewed, Binding) or not isinstance(current, Binding):
            raise Refused('Reviewed immutable binding required')
        if any(not isinstance(getattr(reviewed, field.name), str) or not getattr(reviewed, field.name).strip()
               for field in fields(Binding)) or reviewed != current:
            raise Refused('Mapping evidence, sender, exact text and target must all match')
        if fault not in (None, 'timeout', 'before_runner'):
            raise Refused('Unsupported synthetic fault')
        token = uuid.uuid4().hex
        result = self.ledger.reserve(reviewed, token)
        if not isinstance(result, dict) or result.get('granted') is not True:
            raise Refused('Literal true reservation required')
        try:
            if fault == 'before_runner': raise RuntimeError('SYNTHETIC interruption after reservation')
            local = offline.Ledger(self.ledger.path.parent / ('single-attempt-' + token + '.sqlite3'))
            runner = offline.ReplyRunner(local, _SyntheticTransport(reviewed, fault))
            outcome = runner.submit(expected_uid=reviewed.sender_uid, note_id=reviewed.note_id,
                                    comment_id=reviewed.comment_id, text=reviewed.text)
            self.ledger.outcome(token, 'sent')
            return outcome
        except BaseException:
            try: self.ledger.outcome(token, 'unknown')
            except BaseException: pass  # Original reservation remains blocking if write fails.
            raise Unknown('Offline result unresolved; reservation remains blocked') from None

    def send(self, *args, **kwargs):
        raise Refused('Real controlled-send interface adaptation is unproven; live sending is disabled')
