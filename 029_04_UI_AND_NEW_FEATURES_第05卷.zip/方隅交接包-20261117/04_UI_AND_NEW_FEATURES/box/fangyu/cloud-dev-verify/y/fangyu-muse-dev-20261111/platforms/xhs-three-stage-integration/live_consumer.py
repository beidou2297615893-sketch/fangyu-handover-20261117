"""Consume registered CLI increments without blocking collection or accessing platform."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'work/xhs-context-lite-analysis'))
import run as classifier


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def candidate_entries(rows, analyses, output):
    # Same durable protections as the original draft producer, applied only to this increment.
    path = ROOT/'work/shared-acquisition-ledger/shared.sqlite3'
    with sqlite3.connect(path.resolve().as_uri()+'?mode=ro', uri=True) as db:
        aliases = dict(db.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'"))
        blocked, users = set(), set()
        for customer, comment, status in db.execute("SELECT customer,comment,status FROM leads WHERE platform='xiaohongshu'"):
            if status in ('sent','unknown','reserved','sending','submitted'):
                blocked.add(comment); users.add(customer)
        for customer, comment, status in db.execute("SELECT customer,comment,delivery_state FROM historical_deliveries WHERE platform='xiaohongshu'"):
            if status not in ('not_sent','failed','cancelled'):
                blocked.add(comment); users.add(customer)
    known = set()
    prior = [ROOT/'work/xhs-intent-drafts/drafts.json', *(HERE/'live-consumer').glob('batch-*/drafts.json')]
    for file in prior:
        if file.exists() and file.parent != output:
            for item in classifier.load(file): known.add(item['customer_uid'])
    byid = {r['comment_id']:r for r in rows}; entries, excluded = [], []
    for item in analyses:
        row = byid[item['comment_id']]; a = item['result']; uid = row['customer_uid']
        identities = {uid,row['customer_id'],aliases.get(uid,''),aliases.get(row['customer_id'],'')}
        reason = ''
        if a['interest'] not in ('super_high','high','medium'): reason = '意向尚不足'
        elif row.get('own_reply_visible') or item.get('own_reply_visible'): reason = '已有本人回复'
        elif row['comment_id'] in blocked or identities & users: reason = '历史发送或结果待核'
        elif uid in known: reason = '该客户已有待审稿'
        if reason: excluded.append({'comment_id':row['comment_id'],'reason':reason}); continue
        known.add(uid); entries.append({'row':row,'analysis':item})
    return entries, excluded


def consume(batch, destination, provider):
    ready = classifier.load(batch/'registered-ready.json')
    if ready != {'registered':True,'inserted_comments':ready.get('inserted_comments'),'input':'new-ai-input.json'}:
        raise ValueError('unrecognized ready receipt')
    report = classifier.load(batch/'register-result.json')
    if report.get('mode') != 'apply' or report.get('inserted') != ready['inserted_comments']:
        raise ValueError('registration receipt differs')
    registrar = module('consumer_registration', ROOT/'work/xhs-continuous-runner/runner.py')
    exact = registrar.select_new(classifier.load(batch/'collection.json'), ROOT/'work/shared-acquisition-ledger/shared.sqlite3',
                                 batch/'collection.json', ready['inserted_comments'])
    selected = classifier.load(batch/'new-ai-input.json')
    if selected != exact: raise ValueError('increment is not exact registered transaction')
    fingerprint = hashlib.sha256(classifier.ai.packed(selected).encode()).hexdigest()
    receipt = destination/'state.json'
    if receipt.exists():
        state = classifier.load(receipt)
        if state.get('input_sha256') != fingerprint: raise ValueError('source changed')
        if state['status'] == 'completed': return
        raise ValueError('prior incomplete/unknown consumer result requires review')
    destination.mkdir(parents=True, exist_ok=False)
    state = {'status':'running','input_sha256':fingerprint,'send':False,'platform_requests':0}
    classifier.save(receipt,state)
    try:
        rows = []
        for customer in selected:
            for item in [customer,*customer.get('other_comments',[])]:
                row = {**customer,**item};row.pop('other_comments',None)
                row['context_missing'] = not bool(row.get('post_text'))
                rows.append(row)
        classifier.save(destination/'input.json',rows)
        classifier.OUT = destination/'analysis'; classifier.OUT.mkdir()
        classifier.ai.SYSTEM += '\n意向强度、需求时效、本人地域独立判断，近期且本人明确古北优先；标题仅帖子地区。正文未知先初筛，不编造正文或把作者需求给评论者。'
        account = classifier.load(ROOT/'work/xhs-ai-standalone/account-leimu.json')
        chunks = [rows[i:i+45] for i in range(0,len(rows),45)]
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(classifier.execute_batch,i,part,provider,account) for i,part in enumerate(chunks)]
            analyses = [item for future in futures for item in future.result()]
        classifier.save(destination/'analysis.json',analyses)
        entries, excluded = candidate_entries(rows,analyses,destination)
        classifier.save(destination/'draft-candidates.json',entries);classifier.save(destination/'excluded.json',excluded)
        drafts = module('consumer_drafts', ROOT/'work/xhs-intent-drafts/run.py')
        drafts.OUT = destination/'draft-stage';drafts.OUT.mkdir()
        draft_chunks = [entries[i:i+25] for i in range(0,len(entries),25)]
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(drafts.batch,i,part,provider) for i,part in enumerate(draft_chunks)]
            generated = [item for future in futures for item in future.result()]
        # Today's need has not been verified by a reply from the customer.
        for item in generated:
            item['current_time_confirmed'] = False
            item['review_notes'].append('未在线复核客户当前是否仍在找房')
        classifier.save(destination/'drafts.json',generated)
        state.update(status='completed',comments=len(rows),drafts=len(generated),held=sum(not r['draft'] for r in generated))
        classifier.save(receipt,state)
        print(json.dumps({'batch':batch.name,**state},ensure_ascii=False),flush=True)
    except BaseException as exc:
        state.update(status='stopped_requires_review',error_type=type(exc).__name__)
        classifier.save(receipt,state);raise


def main():
    parser = argparse.ArgumentParser();parser.add_argument('--watch',action='store_true')
    parser.add_argument('--max-seconds',type=int,default=3600);args=parser.parse_args()
    destination = HERE/'live-consumer';destination.mkdir(exist_ok=True)
    lock = destination/'consumer.lock'
    descriptor = os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.close(descriptor)
    try:
        provider = classifier.ai.CodexProvider()
        if classifier.ai.digest(provider.executable) != provider.executable_sha256: raise ValueError('official CLI changed')
        auth = subprocess.run([str(provider.executable),'login','status'],capture_output=True,text=True,timeout=30,
                              env=provider._environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if auth.returncode or 'Logged in using ChatGPT' not in auth.stdout+auth.stderr: raise ValueError('subscription login missing')
        start=time.monotonic()
        while True:
            for marker in sorted((ROOT/'work/xhs-standalone-session/collection-live').glob('batch-*/registered-ready.json')):
                result_dir = destination/marker.parent.name
                receipt = result_dir/'state.json'
                if receipt.exists() and classifier.load(receipt).get('status') in ('stopped_requires_review','running'):
                    # Do not auto-retry an uncertain model call. Other safe increments continue.
                    continue
                try:
                    consume(marker.parent,result_dir,provider)
                except Exception as exc:
                    print(json.dumps({'batch':marker.parent.name,'status':'blocked_requires_review','error_type':type(exc).__name__}),flush=True)
                    if not args.watch: raise
            if not args.watch or (destination/'STOP').exists() or time.monotonic()-start>=args.max_seconds: break
            time.sleep(3)
    finally:
        lock.unlink(missing_ok=True)


if __name__ == '__main__': main()
