import datetime, hashlib, json, pathlib, shutil, sqlite3, subprocess

b = pathlib.Path(__file__).resolve().parent
read = lambda f: json.loads((b / f).read_text(encoding='utf-8-sig'))
a = read('active-runner.json')
p = read(a['plan'])
c = read(a['directory'] + '/control.json')
identity = read('identity-account2-20261101.json')
proof = read('strict-proof-account2-20261101.json')
request = '8b6ff2e7-c41a-4396-b0ba-6a479618ec01'
now = datetime.datetime.now(datetime.timezone.utc)
assert identity['account']['sec_uid'] == p['account_uid'] == proof['account_uid']
assert proof['verified'] and identity['connection_id'] == proof['connection_id']
assert (now - datetime.datetime.fromisoformat(identity['observed_at'].replace('Z', '+00:00'))).total_seconds() < 300
assert not list(b.glob('runner-lease-*.json'))
assert c['pending'] is None and c['stopped'] == 'ledger_invalid_response'
assert subprocess.run(['powershell', '-NoProfile', '-Command', f'[bool](Get-Process -Id {int(a["pid"])} -ErrorAction SilentlyContinue)'], capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip() == 'False'
backup = b / 'resume-20261101-backup'
backup.mkdir(exist_ok=False)
for source in ['active-runner.json', a['plan'], a['identity'], a['strict_proof'], a['directory'] + '/control.json', 'last-failure-report.json', 'daily-report-state.json']:
    src = b / source
    if src.exists():
        shutil.copy2(src, backup / src.name)
db = sqlite3.connect(b / 'runtime/collection.sqlite3', timeout=30)
db.row_factory = sqlite3.Row
with sqlite3.connect(backup / 'collection.sqlite3') as out:
    db.backup(out)
db.execute('BEGIN IMMEDIATE')
halt = db.execute('select * from account_halts where account_uid=?', (p['account_uid'],)).fetchone()
assert halt and halt['request_id'] == request and halt['state'] == 'invalid_response'
r = db.execute('select * from attempts where request_id=?', (request,)).fetchone()
assert r['state'] == 'invalid_response' and r['added'] == 0
digest_before = hashlib.sha256(json.dumps(dict(r), sort_keys=True).encode()).hexdigest()
s = json.loads(r['spec'])
response = json.loads(r['response'])
v = response['value']
assert s['kind'] == 'comments' and s['cursor'] == 760 and s['target'] == '7684579684550283702' and s['account_uid'] == p['account_uid']
assert v['status_code'] == 0 and v['comments'] is None and v['has_more'] == 0 and 'cursor' not in v and 'total' not in v
assert db.execute('select count(*) from scan_pages where request_id=?', (request,)).fetchone()[0] == 0
streams = [dict(x) for x in db.execute("select * from scan_streams where scan_id=? and account_uid=? and kind='comments' and target=?", (s['scan_id'], s['account_uid'], s['target']))]
assert len(streams) == 1 and streams[0]['cursor'] == 760 and streams[0]['exhausted'] == 0
reason = '用户2026-11-01在获知异常停采后明确要求继续；已核验当前浏览器仍为北极学长且严格连接匹配。原异常请求和已完成分页保持不变，该视频剩余分页本地暂留，不代表平台耗尽，不重发异常分页，不重置游标；继续其他已授权来源。'
p['previous_plan'] = a['plan']
p['connection_id'] = identity['connection_id']
p['resume_authorization'] = reason
p.setdefault('local_comment_deferrals', []).append(dict(request_id=request, video=s['target'], cursor=s['cursor'], reason='local_hold_invalid_response_not_platform_exhaustion'))
plan_name = '15-store-plan-account2-20261101.json'
(b / plan_name).write_text(json.dumps(p, ensure_ascii=False, indent=2), encoding='utf-8')
newdir = b / 'runner-live-account2-20261101'
newdir.mkdir(exist_ok=False)
db.execute("update scan_streams set exhausted=1 where scan_id=? and account_uid=? and kind='comments' and target=?", (s['scan_id'], s['account_uid'], s['target']))
assert db.execute('select changes()').fetchone()[0] == 1
db.execute('insert into recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) values(?,?,?,?,?,?)', (p['account_uid'], request, 'user_explicit_resume_verified_same_account', reason, '用户本聊天2026-11-01：多少了；获知34842条及异常停采后要求继续', now.isoformat()))
db.execute('delete from account_halts where account_uid=? and request_id=?', (p['account_uid'], request))
assert db.execute('select changes()').fetchone()[0] == 1
after = dict(db.execute('select * from attempts where request_id=?', (request,)).fetchone())
assert hashlib.sha256(json.dumps(after, sort_keys=True).encode()).hexdigest() == digest_before
assert read(a['directory'] + '/control.json') == c
db.commit()
db.close()
review = dict(at=now.isoformat(), request_id=request, original_attempt_unchanged=True, local_deferral_not_platform_exhaustion=True, isolated_video=s['target'], deferred_cursor=s['cursor'], previous_streams=streams, account_matches=True, reason=reason, baseline_qualified_comments=34842)
(b / 'resume-20261101-review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding='utf-8')
c.update(stopped=None, plan_digest='pending_offline_normalization', resumed_from=a['directory'], resume_review='resume-20261101-review.json')
(newdir / 'control.json').write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(recovery_recorded=True, original_attempt_unchanged=True, cursor_preserved=760, backup_created=True)))
