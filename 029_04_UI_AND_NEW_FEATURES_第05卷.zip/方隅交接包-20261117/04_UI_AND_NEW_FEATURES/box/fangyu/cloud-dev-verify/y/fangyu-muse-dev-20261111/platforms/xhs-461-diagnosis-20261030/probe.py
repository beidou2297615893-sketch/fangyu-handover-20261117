"""One diagnostic sequence with existing session; no retry or ledger writes."""
import json
import logging
import sys
from pathlib import Path
from datetime import datetime,timezone

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
sys.path.insert(0,str(PROJECT/'work/xhs-new-task-session-fix-20261029'))
from integration import load,client_factory

def save(name,value):
    with (HERE/name).open('x',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2)

def main():
    logging.disable(logging.CRITICAL)
    save('started.json',{'at':datetime.now(timezone.utc).isoformat(),'login':False,'retry':False,'send':False,'ledger_write':False})
    uid='5aa9b337e8ac2b4ab2d21957'
    home=PROJECT/'work/xhs-standalone-session/stores15-user-relogin-20261030-03'
    lock=home/'.managed-use.lock'; lock.mkdir()
    client=None
    try:
        live,candidate,once,scheduler=load()
        client=client_factory(uid,delay=3.0)(home,HERE/'cache')
        client.get_self_info()
        save('identity.json',{'uid':uid,'guest':False,'verified':True})
        search=live.search_without_recommend(client,'上海季乐路个人求租',1)
        collector,_=candidate.dependencies()
        notes=collector.note_items(search,20)
        target=next((n for n in notes if n['note_id']=='6acc346d0000000014031d69'),None)
        if target is None or not target['token']:raise ValueError('same_note_context_unavailable')
        response=client.get_comments(target['note_id'],xsec_token=target['token'],xsec_source='pc_search')
        rows=[]
        for c in response.get('comments',[]):
            if not isinstance(c,dict):continue
            u=c.get('user_info') or {}
            rows.append({'note_id':target['note_id'],'comment_id':c.get('id'),
                'comment_text':c.get('content'),'published_at':c.get('create_time'),
                'ip_location':c.get('ip_location'),'customer_uid':u.get('user_id'),
                'customer_name':u.get('nickname')})
        save('probe-comments.json',rows)
        result={'status':'comment_read_succeeded','uid':uid,'comments':len(rows),
                'has_more':response.get('has_more'),'registered':False,'automatic_retry':False}
        save('result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
    except Exception as exc:
        result={'status':'diagnostic_stopped','automatic_retry':False}
        if client is not None:result['diagnostic']=candidate.safe_failure(client,exc)
        else:result['category']='local_initialization_failed'
        save('result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
        return 2
    finally:
        if client is not None:client.close()
        lock.rmdir()
    return 0

if __name__=='__main__':raise SystemExit(main())
