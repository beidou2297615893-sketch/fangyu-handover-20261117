import json
from contextlib import closing
import hashlib
from pathlib import Path
import sqlite3
import tempfile
import types
import unittest
from unittest.mock import patch

import runner

class RunnerTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.ledger=self.root/'ledger.sqlite'
        with closing(sqlite3.connect(self.ledger)) as db:
            db.execute('CREATE TABLE leads(platform TEXT, customer TEXT, comment TEXT, status TEXT, source TEXT)')
            db.commit()
        self.args=types.SimpleNamespace(session_home='home',sender_uid='uid',source_db='source',ledger=self.ledger,
            max_notes=2,max_pages=1,account='account',style='style')
        self.state={'keywords':['古北'],'next_index':0,'completed':[]}
        self.row={'customer_id':'customer','customer_uid':'uid','comment_id':'old','note_id':'n1',
                  'comment_text':'old text','other_comments':[{'comment_id':'new','note_id':'n2','comment_text':'new text'}]}

    def tearDown(self):self.tmp.cleanup()

    def test_select_exact_source_and_promote_new_comment(self):
        source=self.root/'collection.json';source.write_text('{}',encoding='utf8')
        with closing(sqlite3.connect(self.ledger)) as db:
            db.execute('INSERT INTO leads VALUES(?,?,?,?,?)',('xiaohongshu','customer','old','unverified','other'))
            db.execute('INSERT INTO leads VALUES(?,?,?,?,?)',('xiaohongshu','customer','new','unverified','collection:'+str(source.resolve())))
            db.commit()
        rows=runner.select_new({'customers':[self.row]},self.ledger,source,1)
        self.assertEqual(rows[0]['comment_id'],'new')
        self.assertEqual(rows[0]['customer_uid'],'uid')
        self.assertEqual(rows[0]['other_comments'],[])

    def test_unmatched_count_stops(self):
        source=self.root/'collection.json';source.write_text('{}',encoding='utf8')
        with self.assertRaises(runner.Stop):runner.select_new({'customers':[self.row]},self.ledger,source,1)

    def test_collection_failure_preserves_partial_and_never_registers(self):
        calls=[]
        def fake(command):
            calls.append(command[0])
            out=Path(command[command.index('--output')+1]);out.mkdir()
            (out/'partial.json').write_text('{}',encoding='utf8')
            raise runner.Stop('业务失败')
        with self.assertRaises(runner.Stop):runner.run_batches(self.state,self.root,self.args,fake)
        self.assertEqual(calls,[runner.COLLECT])
        self.assertTrue((self.root/'batch-0001/collection/partial.json').exists())
        self.assertEqual(runner.read(self.root/'state.json')['status'],'stopped')

    def test_empty_batch_completes_without_ai_or_network_again(self):
        calls=[]
        def fake(command):
            calls.append(command[0])
            if command[0]==runner.COLLECT:
                out=Path(command[command.index('--output')+1]);out.mkdir()
                runner.save(out/'collection.json',{'customers':[],'summary':{'usable_comments':0,'truncated_note_pages':0}})
            elif command[0]==runner.REGISTER:
                report=Path(command[command.index('--report')+1])
                runner.save(report,{'would_insert':0,'inserted':0})
        runner.run_batches(self.state,self.root,self.args,fake)
        self.assertEqual(calls,[runner.COLLECT,runner.REGISTER,runner.REGISTER])
        self.assertEqual(runner.read(self.root/'state.json')['status'],'completed')

    def test_preview_commit_difference_stops_before_analysis(self):
        calls=[]
        def fake(command):
            calls.append(command[0])
            if command[0]==runner.COLLECT:
                out=Path(command[command.index('--output')+1]);out.mkdir()
                runner.save(out/'collection.json',{'customers':[],'summary':{}})
            else:
                report=Path(command[command.index('--report')+1])
                runner.save(report,{'would_insert':1,'inserted':0})
        with self.assertRaises(runner.Stop):runner.run_batches(self.state,self.root,self.args,fake)
        self.assertNotIn(runner.CONTEXT,calls)
        self.assertEqual(runner.read(self.root/'state.json')['phase'],'registration_commit')

    def test_failed_search_page_does_not_advance_to_next(self):
        self.state['jobs']=[{'keyword':'古北','page':1},{'keyword':'古北','page':2}]
        calls=[]
        def fake(command):
            calls.append(command)
            raise runner.Stop('预热失败')
        with self.assertRaises(runner.Stop):runner.run_batches(self.state,self.root,self.args,fake)
        state=runner.read(self.root/'state.json')
        self.assertEqual(state['search_page'],1)
        self.assertEqual(state['next_index'],0)
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0][calls[0].index('--search-page')+1],1)

    def test_ai_failure_stops_and_keeps_inserted_checkpoint(self):
        calls=[]
        def fake(command):
            calls.append(command[0])
            if command[0]==runner.COLLECT:
                out=Path(command[command.index('--output')+1]);out.mkdir()
                runner.save(out/'collection.json',{'customers':[self.row],'summary':{}})
            elif command[0]==runner.REGISTER:
                report=Path(command[command.index('--report')+1])
                runner.save(report,{'would_insert':1,'inserted':1})
            else:raise runner.Stop('正文失败')
        with self.assertRaises(runner.Stop):runner.run_batches(self.state,self.root,self.args,fake,lambda *args:[self.row])
        state=runner.read(self.root/'state.json')
        self.assertEqual(state['phase'],'context_and_ai')
        self.assertEqual(state['inserted'],1)
        self.assertTrue((self.root/'batch-0001/new-ai-input.json').exists())
        self.assertEqual(calls.count(runner.CONTEXT),1)

    def test_real_registrar_and_selection_contract(self):
        import sys
        sys.path.insert(0,str(runner.REGISTER.parent))
        try:
            import register
            with closing(sqlite3.connect(self.ledger)) as db:
                db.executescript('''
                    DROP TABLE leads;
                    CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,review_time INTEGER,evidence TEXT,operator TEXT,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
                    CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT,evidence TEXT,created INTEGER);
                    CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,evidence TEXT,verified INTEGER,PRIMARY KEY(platform,alias));
                    CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,comment TEXT,reference TEXT,delivery_state TEXT,source TEXT,recorded INTEGER);
                    CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));
                ''')
                db.commit()
            cid='xhs_new_'+hashlib.sha256(b'xiaohongshu:fixture').hexdigest()
            row={'customer_id':cid,'customer_uid':'fixture','comment_id':'c1','note_id':'n1','comment_text':'求租','post_title':'古北',
                 'other_comments':[{'comment_id':'c2','note_id':'n1','comment_text':'咨询'}]}
            data={'schema':'xhs-collected-ai-input-v1','customers':[row]}
            source=self.root/'collection.json';runner.save(source,data)
            preview=register.register(self.ledger,data,{},'collection:'+str(source.resolve()),apply=False)
            applied=register.register(self.ledger,data,{},'collection:'+str(source.resolve()),apply=True)
            self.assertEqual(preview['would_insert'],2)
            self.assertEqual(applied['inserted'],2)
            selected=runner.select_new(data,self.ledger,source,applied['inserted'])
            self.assertEqual([selected[0]['comment_id'],selected[0]['other_comments'][0]['comment_id']],['c1','c2'])
            self.assertEqual(register.register(self.ledger,data,{},'repeat',apply=False)['would_insert'],0)
        finally:sys.path.pop(0)

    def test_resume_only_at_completed_batch_boundary(self):
        home=self.root/'home';home.mkdir()
        paths=[]
        for name in ('source','account','style'):
            path=self.root/name;path.write_text('{}',encoding='utf8');paths.append(path)
        output=self.root/'run'
        argv=['--keyword','古北','--keyword','虹桥','--output',str(output),'--session-home',str(home),
              '--sender-uid','fixture','--source-db',str(paths[0]),'--ledger',str(self.ledger),
              '--account',str(paths[1]),'--style',str(paths[2]),'--execute']
        def interruption(state,root,args):
            state.update(status='ready',phase='between_batches',next_index=1)
            runner.save(root/'state.json',state)
            raise KeyboardInterrupt()
        with patch.object(runner,'run_batches',interruption):
            with self.assertRaises(KeyboardInterrupt):runner.main(argv)
        def finish(state,root,args):
            self.assertEqual(state['next_index'],1)
            state.update(status='completed',phase='complete')
            runner.save(root/'state.json',state)
        with patch.object(runner,'run_batches',finish):self.assertEqual(runner.main([*argv,'--resume']),0)
        with self.assertRaises(runner.Stop):runner.main([*argv,'--resume'])

if __name__=='__main__':unittest.main()
