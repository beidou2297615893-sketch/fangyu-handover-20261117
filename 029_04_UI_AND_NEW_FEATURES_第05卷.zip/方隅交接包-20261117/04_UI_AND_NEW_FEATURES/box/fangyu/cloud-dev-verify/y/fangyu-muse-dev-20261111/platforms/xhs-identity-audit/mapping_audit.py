import collections, datetime, hashlib, json, pathlib, sqlite3

OUT = pathlib.Path(__file__).parent
ROOT = OUT.parent.parent
DB = pathlib.Path('C:/Users/rmsama/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/fangyu-apartment-clientWorkspace/workspace.sqlite3')
DRAFT = ROOT/'work/cli-independent-20261027/reply-style-46-short.json'
INITIAL = DRAFT.with_name('reply-ledger-initial-snapshot.json')
CONTEXT = pathlib.Path('C:/积木软件工坊/项目/方隅公寓客户版/work/region-followup-20261027/voice-review-47/hook-revision/context.json')
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
drafts=load(DRAFT)['rows']; old={r['customerId']:r for r in load(CONTEXT)['customers']}
con=sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True)
con.execute('PRAGMA query_only=ON'); con.execute('BEGIN')
entities=['leads','replies','reply_queues','customer_intent_projection_v1','ui_reply_delivery_v1']
data={e:[json.loads(r[0]) for r in con.execute('SELECT body FROM records WHERE entity=?',(e,))] for e in entities}
events=[(s,r,k,json.loads(p)) for s,r,k,p in con.execute('SELECT sequence,reply_id,kind,payload FROM contact_events')]
leads={r['id']:r for r in data['leads']}; projections=collections.defaultdict(list)
for p in data['customer_intent_projection_v1']: projections[p['customer_id']].append(p)
rows=[]
for d in drafts:
 cid,lid=d['customerId'],d['targetLeadId']; target=leads.get(lid,{})
 tenant,platform,uid=target.get('tenant_id'),target.get('platform'),target.get('author_id')
 ps=[p for p in projections[cid] if p.get('tenant_id')==tenant]
 members=sorted({m['lead_id'] for p in ps for m in p.get('members',[])})
 history=[l for l in leads.values() if uid and l.get('tenant_id')==tenant and l.get('platform')==platform and l.get('author_id')==uid]
 hids={l['id'] for l in history}; comments=sorted({l['comment_id'] for l in history if l.get('comment_id')})
 def match(l,r): return l in hids or (r.get('platform')==platform and r.get('comment_id') in comments)
 replies=[{'replyId':r['id'],'leadId':r.get('lead_id'),'commentId':r.get('recipient',{}).get('comment_id'),'status':r.get('status')} for r in data['replies'] if match(r.get('lead_id'),r.get('recipient',{}))]
 queues=[]
 for q in data['reply_queues']:
  hits=[{'replyId':s.get('reply_id'),'commentId':s.get('recipient',{}).get('comment_id')} for s in q.get('snapshots',[]) if match(None,s.get('recipient',{})) or s.get('reply_id') in {r['replyId'] for r in replies}]
  if hits: queues.append({'queueId':q['id'],'status':q.get('status'),'hits':hits})
 ev=[{'sequence':s,'replyId':r,'kind':k,'leadId':p.get('lead',{}).get('id'),'commentId':p.get('lead',{}).get('comment_id')} for s,r,k,p in events if match(p.get('lead',{}).get('id'),p.get('lead',{}))]
 oldr=old.get(cid,{})
 rows.append({'sequence':d['sequence'],'customerId':cid,'targetLeadId':lid,'tenantId':tenant,'platform':platform,'platformAuthorId':uid,'targetCommentId':target.get('comment_id'),'contextAuthorId':oldr.get('uid'),'contextUidMatchesTarget':oldr.get('uid')==uid,'projectionCount':len(ps),'projectionIds':[p['id'] for p in ps],'targetInProjectionMembership':lid in members,'projectionMemberLeadIds':members,'projectionMemberAuthorIds':sorted({leads[m].get('author_id','') for m in members if m in leads}),'historyLeadIds':sorted(hids),'historicalCommentIds':comments,'historicalCommentIdCount':len(comments),'membershipOutsideSameUidHistory':sorted(set(members)-hids),'sameUidHistoryOutsideMembership':sorted(hids-set(members)),'localReplies':replies,'localQueueIntersections':queues,'localContactEvents':ev,'localIntersectionConclusion':'local_record_found' if replies or queues or ev else 'no_local_record_found_not_proof_of_platform_no_reply','sameLiteralUidOtherPlatforms':sorted({l.get('platform') for l in leads.values() if uid and l.get('author_id')==uid and l.get('platform')!=platform})})
con.rollback();con.close()
summary={'schema':'xhs-46-identity-mapping-readonly-v1','generatedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'draftCount':len(rows),'uniqueCustomerIdCount':len({r['customerId'] for r in rows}),'uniqueTargetLeadIdCount':len({r['targetLeadId'] for r in rows}),'uniquePlatformAuthorIdCount':len({(r['platform'],r['platformAuthorId']) for r in rows}),'uniqueTargetCommentIdCount':len({r['targetCommentId'] for r in rows}),'missingTargetLeadCount':sum(not r['targetCommentId'] for r in rows),'targetMembershipFailureCount':sum(not r['targetInProjectionMembership'] for r in rows),'contextUidMismatchCount':sum(not r['contextUidMatchesTarget'] for r in rows),'localIntersectionCustomerCount':sum(bool(r['localReplies'] or r['localQueueIntersections'] or r['localContactEvents']) for r in rows),'historicalCommentCountDistribution':dict(collections.Counter(r['historicalCommentIdCount'] for r in rows)),'sources':[{'path':str(p),'sha256':sha(p)} for p in [DRAFT,INITIAL,CONTEXT]],'database':{'path':str(DB),'mode':'ro','queryOnly':True,'transaction':'consistent read transaction','selectedEntities':entities,'selectedExtraTables':['contact_events'],'sessionsOrCookiesRead':False},'limitations':['customerId is an internal projection key, not a platform UID.','Author identity is scoped by tenant and platform; equal nicknames or equal literal UIDs across platforms do not establish one person.','History covers saved local leads only, not all platform comments.','No local reply/queue/event intersection does not prove absence of a platform reply; receipts and live platform state were not checked.','Production data and shared ledger were not written; no sending, reservation, session reads, or Cookie reads occurred.']}
assert len(rows)==46 and summary['uniqueCustomerIdCount']==46 and summary['uniqueTargetLeadIdCount']==46
save('mapping_rows.json',rows);save('mapping_summary.json',summary)
print(json.dumps(summary,ensure_ascii=True))
