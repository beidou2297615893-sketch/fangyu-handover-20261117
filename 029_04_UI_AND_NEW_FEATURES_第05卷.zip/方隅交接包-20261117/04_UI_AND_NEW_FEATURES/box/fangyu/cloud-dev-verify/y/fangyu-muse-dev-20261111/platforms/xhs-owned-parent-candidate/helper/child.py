"""Test executable endpoint: real serve/gate, synthetic HTTP only, no credentials."""
import importlib.util
import json
import os
from pathlib import Path
import socket
import sys

def denied(*a, **k):
    raise AssertionError('All network is prohibited in the isolated helper')

socket.socket.connect = denied
socket.socket.connect_ex = denied
socket.create_connection = denied
socket.getaddrinfo = denied
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('owned_original_worker', ROOT/'candidate/runtime/assistant/xhs_reply_worker.py')
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)

def setup(gate):
    # Explicit test setup callback; never enter production _setup or load cookies.
    config = json.loads(os.environ['OWNED_SYNTHETIC_CONFIG'])
    trace = Path(config['trace']).resolve()
    if not trace.is_relative_to(ROOT/'tests'):
        raise ValueError('Synthetic trace must remain in the candidate')
    def record(kind):
        with trace.open('a', encoding='utf-8') as f:
            f.write(kind+'\n')
    class Client:
        def get_self_info(self):
            gate('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me',{})
            record('GET')
            return {'user_id':config.get('uid','sender')}
        def reply_comment(self, note, comment, text):
            body = {'note_id':note,'content':text,'target_comment_id':comment,'at_users':[]}
            gate('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post',{'content':json.dumps(body)})
            record('POST')
            if config.get('fault') == 'timeout':
                raise TimeoutError('Synthetic uncertain outcome')
            if config.get('fault') == 'crash_after_post':
                os._exit(21)
            if config.get('fault') == 'bad_receipt':
                return {'comment':{'id':'receipt','user_id':'other'}}
            return {'comment':{'id':'receipt','user_id':'sender'}}
        def close(self):
            record('CLOSE')
    return Client()

if sys.argv[1:] != ['--owned-xhs-reviewed-reply']:
    raise SystemExit(2)
class FaultyPipe:
    """Fault injection at pipe boundary; original serve/protocol code untouched."""
    def __init__(self,stream):self.stream=stream
    def write(self,raw):
        fault=json.loads(os.environ['OWNED_SYNTHETIC_CONFIG']).get('fault')
        frame=json.loads(raw)
        if frame.get('type')=='authorize':
            if fault=='invalid_nonce':frame['nonce']='0'*64
            if fault=='invalid_stage':frame['stage']='post'
        return self.stream.write(json.dumps(frame,ensure_ascii=False)+'\n')
    def flush(self):return self.stream.flush()
raise SystemExit(worker.serve(sys.stdin,FaultyPipe(sys.stdout),setup=setup))
