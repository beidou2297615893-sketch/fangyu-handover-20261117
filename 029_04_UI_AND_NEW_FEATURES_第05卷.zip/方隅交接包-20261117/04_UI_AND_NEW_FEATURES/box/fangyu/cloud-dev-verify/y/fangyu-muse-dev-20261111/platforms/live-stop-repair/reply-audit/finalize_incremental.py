"""No test reruns: verify exact tested hashes and the later date-only delta/pin."""
from pathlib import Path
import ast,hashlib,json,re
from datetime import datetime,timezone
O=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
def read(name):return json.loads((O/name).read_text('utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def matches_prior_bytes(raw,expected):
    # Root normalized line endings after the rejected, uninstalled v18. Keep
    # every other byte exact; do not rerun the already passing behavior suites.
    normalized=re.sub(rb'\r+\n',b'\n',raw)
    return expected in (sha(normalized),sha(normalized.replace(b'\n',b'\r\n')))
checks={name:read(name) for name in ('AFTER.json','MEDIA-SAFETY.json','REPLY-INDEX.json','PREVIEW-CHECK.json','SOURCE-NOTICE.json')}
assert all(row['status'].startswith('PASS') for row in checks.values())
backend=S/'work/ui-native-r57/workbench_backend.py';customer=S/'work/ui-native-r57/customer_workbench.py';reply=S/'work/ui-native-r57/reply_workbench.py';history=S/'work/ui-runtime-r55/src/assistant/customer_list.py';ui=S/'work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs'
assert matches_prior_bytes(backend.read_bytes(),checks['MEDIA-SAFETY.json']['source_sha256'])
assert matches_prior_bytes(backend.read_bytes(),checks['AFTER.json']['source_sha256']['workbench_backend.py'])
for path in (customer,history,reply):assert sha(path.read_bytes())==checks['SOURCE-NOTICE.json']['source_sha256'][str(path.relative_to(S)).replace('\\','/')]
tr=ast.parse(customer.read_text('utf-8-sig'));pin=None
for node in tr.body:
    if isinstance(node,ast.Assign):
        try:value=ast.literal_eval(node.value)
        except (ValueError,TypeError):continue
        if isinstance(value,dict) and 'assistant/customer_list.py' in value:pin=value['assistant/customer_list.py']
assert pin and pin.lower()==sha(history.read_bytes()),'Customer history source pin does not match exact file bytes'
# These two files changed after successful behavior checks only to present the
# independently checked per-source date notice. Undo that exact delta in memory.
raw=reply.read_bytes();normalized=re.sub(rb"^[ \t]*'sourceNotice':'[^\r\n]*\r?\n",b'',raw,flags=re.M)
assert matches_prior_bytes(normalized,checks['REPLY-INDEX.json']['source_sha256']),'Reply has a later change beyond the reviewed notice field'
raw_ui=ui.read_bytes()
for snippet in [b'${preview.sourceNotice?`<p class="rp-loading-note">${esc(preview.sourceNotice)}</p>`:\'\'}',b'${row.sourceNotice?`<small class="rp-loading-note">${esc(row.sourceNotice)}</small>`:\'\'}']:
    assert raw_ui.count(snippet)==1;raw_ui=raw_ui.replace(snippet,b'')
assert matches_prior_bytes(raw_ui,checks['PREVIEW-CHECK.json']['source_sha256']),'Reply UI changed beyond the reviewed escaped notice fields'
# The source/pin-only customer follow-up must not alter the tested context path.
customer_before=re.sub(rb"^[ \t]*'sourceNotice':'[^\r\n]*\r?\n[ \t]*[^\r\n]*post_date_status[^\r\n]*\r?\n",b'',customer.read_bytes(),flags=re.M)
prior_pin=sha((S.parents[1]/'candidate-unified-v17/project/work/ui-runtime-r55/src/assistant/customer_list.py').read_bytes()).upper().encode('ascii')
customer_before=customer_before.replace(pin.encode('ascii'),prior_pin)
assert matches_prior_bytes(customer_before,checks['AFTER.json']['source_sha256']['customer_workbench.py']),'Customer context changed beyond the reviewed notice/pin delta'
source_rows=json.loads((O.parent/'SOURCE-CHANGES.json').read_text('utf-8-sig'))
syntax=[]
for row in source_rows:
    path=S/row['path'];raw=path.read_bytes()
    assert sha(raw)==row['after'],row['path']+' differs from declared source changes'
    if path.suffix=='.py':compile(raw,str(path),'exec');syntax.append({'path':row['path'],'status':'PASS_BYTES_COMPILE'})
paths=[backend,customer,reply,history,ui,S/'work/ui-approved-implementation/ui-preview/pages/acquire.mjs',S/'work/ui-approved-implementation/ui-preview/canvas-fit.css']
matrix={str(path.relative_to(S)).replace('\\','/'):sha(path.read_bytes()) for path in paths}
report={'status':'PASS_INDEPENDENT_INCREMENTAL_REPLY_REVIEW','at_utc':datetime.now(timezone.utc).isoformat(),'baseline':'BASELINE.json','evidence':{name:{'status':row['status'],'passed':row.get('passed'),'checks':row.get('checks')} for name,row in checks.items()},'confirmed_changes':{'history_builds_per_reply':{'before':2,'after':1},'backend_lock_available_during_media_identity':{'before':False,'after':True},'per_request_replies_accounts_reads_for_three_comments':{'before':[3,3],'after':[1,1]},'preview':'Already returned row immediately visible, no editor before fresh detail.','date_notice':'Exact selected original source; history field and source pin preserved.'},'final_reviewed_source_sha256':matrix,'history_dependency_pin_exact':True,'later_reply_and_UI_delta_only_reviewed_notice':True,'line_endings_normalized_bytes_otherwise_equal':True,'python_readback_syntax':syntax,'resolved_blocker':'PIN-BLOCKER.json was caused by the pin-write CRLF expansion; corrected bytes compile and new notice checks pass. Candidate v18 rejected before install.','blocking_findings':0,'product_edits':0,'real_HTTP_requests':0,'real_platform_requests':0,'DB_writes':0,'UI_operations':0,'old_suites_rerun':False,'limitations':['Isolated fake dependencies, not real platform/CDN or native UI speed acceptance.','Collection adapter/pipeline/engine changes are outside this review; use their assigned review.','Lifecycle logs do not contain reply API timings.']}
js_syntax=read('JS-SYNTAX.json');assert js_syntax['status']=='PASS_NODE_CHECK'
for row in js_syntax['checks']:assert row['exit_code']==0 and sha((S/row['path']).read_bytes())==row['sha256']
report['javascript_readback_syntax']=js_syntax
(O/'FINAL-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'blocking_findings':0,'final_reviewed_source_sha256':matrix},ensure_ascii=False,indent=2))
