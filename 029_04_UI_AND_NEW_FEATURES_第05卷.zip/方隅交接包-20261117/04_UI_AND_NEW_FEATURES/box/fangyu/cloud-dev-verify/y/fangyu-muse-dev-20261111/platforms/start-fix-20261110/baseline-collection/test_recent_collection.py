import datetime as dt
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import ledger
from backfill_recent_90 import backfill
from runner_ledger_adapter import Cache, ingest_local


class RecentCollection(unittest.TestCase):
    def test_ninety_day_boundaries_and_idempotent_backfill_update_warm_cache(self):
        with tempfile.TemporaryDirectory(dir=ledger.ROOT) as tmp:
            root = Path(tmp)
            shared = root / 'shared.sqlite3'
            with closing(sqlite3.connect(shared)) as db, db:
                db.executescript("""CREATE TABLE leads(platform,comment);
                    CREATE TABLE reservations(platform,comment);
                    CREATE TABLE historical_deliveries(platform,comment);
                    INSERT INTO reservations VALUES('douyin','202');""")
            journal = ledger.Ledger(root / 'collection.sqlite3', shared_ledger=shared)
            observed = dt.datetime.fromisoformat('2026-11-05T00:05:00+08:00')
            ages = (15, 16, 30, 31, 60, 61, 90, 91)

            def page(rid, video, offset, version, limit=None):
                policy = {'version':version, 'observed_at':observed.isoformat()}
                if limit is not None:
                    policy['admission_limit'] = limit
                spec = dict(request_id=rid, account_uid='a', connection_id='c', scan_id='s', cursor=0,
                            kind='comments', target=video, rule_source='test', recent_collection=policy,
                            eligibility={'state':'eligible'})
                rows = [{'cid': str(offset+i), 'create_time': int((observed-dt.timedelta(days=age)).timestamp())}
                        for i, age in enumerate(ages)]
                return spec, {'ok':True, 'connection':'c', 'value':{'status_code':0,'has_more':False,'cursor':1,'comments':rows}}

            old = page('original', '100', 100, ledger.RECENT_VERSION)
            old_receipt = journal.ingest(*old)
            plan = {'account_uid':'a', 'target_comments':100}
            cache = Cache(journal.path)
            with closing(cache.db):
                cache.sync()
                self.assertEqual(cache.qualified(plan), 3)
            result = backfill(journal, plan, observed)
            self.assertEqual((result['days_31_to_60'],result['days_61_to_90'],result['qualified_after']), (2,2,7))
            self.assertEqual(backfill(journal,plan,observed)['added'], 0)
            self.assertEqual(journal.ingest(*old), old_receipt)
            fresh = journal.ingest(*page('fresh','101',200,ledger.RECENT_90_VERSION,5))
            self.assertEqual(fresh['recent_counts']['days_31_to_60'], 2)
            self.assertEqual(fresh['recent_counts']['days_61_to_90'], 1)
            self.assertEqual(fresh['recent_counts']['deduplicated'], 1)
            self.assertEqual(fresh['recent_counts']['expired'], 1)
            self.assertEqual(fresh['recent_counts']['deferred_at_target'], 1)
            with closing(sqlite3.connect(journal.path)) as db:
                saved = json.loads(db.execute("SELECT response FROM attempts WHERE request_id='original'").fetchone()[0])
                self.assertEqual(saved, old[1])
                self.assertEqual(db.execute("SELECT count(*) FROM recent_comment_backfill").fetchone()[0],4)

    def test_local_ingest_retries_busy_only_and_is_bounded(self):
        busy = sqlite3.OperationalError('database is locked')
        busy.sqlite_errorcode = sqlite3.SQLITE_BUSY
        other = sqlite3.OperationalError('no such table')
        other.sqlite_errorcode = sqlite3.SQLITE_ERROR
        data = {'spec': {}, 'response': {}}
        with patch('runner_ledger_adapter.Ledger') as ledger_factory, patch('runner_ledger_adapter.time.sleep') as sleep:
            ingest = ledger_factory.return_value.ingest
            ingest.side_effect = [busy, {'state': 'parsed'}]
            self.assertEqual(ingest_local(Path('test.sqlite3'), data, None), {'state': 'parsed'})
            self.assertEqual(ingest.call_count, 2)
            sleep.assert_called_once_with(0.25)
            ingest.reset_mock()
            ingest.side_effect = busy
            with self.assertRaises(sqlite3.OperationalError):
                ingest_local(Path('test.sqlite3'), data, None)
            self.assertEqual(ingest.call_count, 3)
            ingest.reset_mock()
            ingest.side_effect = other
            with self.assertRaises(sqlite3.OperationalError):
                ingest_local(Path('test.sqlite3'), data, None)
            self.assertEqual(ingest.call_count, 1)

    def test_mixed_pages_preserve_raw_and_gate_business_rows(self):
        with tempfile.TemporaryDirectory(dir=ledger.ROOT) as tmp:
            root = Path(tmp)
            shared = root / 'shared.sqlite3'
            with closing(sqlite3.connect(shared)) as db, db:
                db.executescript("""CREATE TABLE leads(platform, comment, status);
                    CREATE TABLE reservations(platform, comment, status);
                    CREATE TABLE historical_deliveries(platform, comment, delivery_state);
                    INSERT INTO leads VALUES('douyin','700','sent');
                    INSERT INTO reservations VALUES('douyin','701','unknown'),('douyin','702','reserved');
                    INSERT INTO historical_deliveries VALUES('douyin','703','sent');
                    INSERT INTO leads VALUES('xiaohongshu','9','sent');""")
            path = root / 'collection.sqlite3'
            journal = ledger.Ledger(path, shared_ledger=shared)
            anchor = dt.datetime.fromisoformat('2026-11-04T00:05:00+08:00')

            def item(cid, days, minutes=0):
                return {'cid': str(cid), 'create_time': int((anchor - dt.timedelta(days=days, minutes=minutes)).timestamp())}

            def page(rid, cursor, more, rows, *, recent=True, target='100'):
                spec = dict(request_id=rid, account_uid='account', connection_id='conn', scan_id='scan',
                            kind='comments', target=target, cursor=cursor, rule_source='test', eligibility={'state':'eligible'})
                if recent:
                    spec['recent_collection'] = {'version': 'recent-collection-20261104', 'observed_at': anchor.isoformat()}
                value = {'status_code':0,'has_more':more,'cursor':cursor+1,'comments':rows}
                response = {'ok':True, 'connection':'conn', 'value':value}
                return spec, response

            journal.ingest(*page('historical', 0, False, [item(800, 50)], recent=False, target='101'))
            raw = [item(1, 31), item(2, 30), item(3, 16), item(4, 15), item(5, 2),
                   item(6, 0, 6), item(7, 0, 1), {'cid':'8'}, item(9, 0), item(11, 0, -1),
                   *[item(cid, 0) for cid in (700, 701, 702, 703)], item(7, 0, 1)]
            with self.subTest('freshness and dedup'):
                first = page('p1', 0, True, raw)
                receipt = journal.ingest(*first)
                self.assertEqual(receipt['recent_counts'], {
                    'within_15_days':5, 'days_16_to_30':2, 'expired':1, 'unknown':2,
                    'deduplicated':5, 'today':2, 'yesterday':1, 'day_before_yesterday':1})
                self.assertEqual(journal.ingest(*first), receipt)
                self.assertEqual(journal.scan_checkpoint('account','comments','100','scan')['cursor'], 1)
                second = journal.ingest(*page('p2', 1, False, [item(10, 0), item(7, 0)]))
                self.assertEqual(second['added'], 1)
                self.assertEqual(second['recent_counts']['deduplicated'], 1)
            with closing(sqlite3.connect(path)) as db:
                saved = json.loads(db.execute("SELECT response FROM attempts WHERE request_id='p1'").fetchone()[0])
                self.assertEqual(saved, first[1])
                self.assertEqual({row[0] for row in db.execute("SELECT source_id FROM entities")},
                                 {'800','2','3','4','5','6','7','9','10'})
                ordered = [json.loads(row[0])['cid'] for row in db.execute("SELECT data FROM observations WHERE request_id='p1' ORDER BY rowid")]
                self.assertEqual(ordered, ['9','7','6','5','4','3','2'])
                self.assertEqual({r[0] for r in db.execute("SELECT cid FROM recent_comment_date_review")}, {'8','11'})
            cache = Cache(path)
            try:
                cache.sync()
                self.assertEqual(cache.qualified({'account_uid':'account'}), 9)
            finally:
                cache.db.close()


if __name__ == '__main__':
    unittest.main()
