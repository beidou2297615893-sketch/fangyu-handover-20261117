const assert=require('node:assert/strict');
const vm=require('node:vm');
const {findFollowup,scan}=require('./read_replies.cjs');
(async()=>{
 const spec={video:'1',root:'2',customer:'3',ourReply:'4'};
 assert.equal(findFollowup([{cid:'5',user:{uid:'3'},reply_to_reply_id:'4'}],'3','4').found,true);
 assert.equal(findFollowup([{cid:'5',user:{uid:'8'},reply_to_reply_id:'4'}],'3','4').found,false);
 assert.equal(findFollowup([{cid:'5',user:{uid:'3'},reply_id:'2'}],'3','4').found,false);
 assert.equal(findFollowup([{cid:'5',user:{uid:9007199254740992},reply_to_reply_id:'4'}],'9007199254740992','4').found,false);
 const call=value=>({call:async()=>({ok:true,connection:'x',value})});
 assert.equal((await scan(call({status_code:0,comments:[],has_more:0}),'x',spec)).state,'unknown');
 assert.equal((await scan(call({status_code:0,comments:[{cid:'5',user:{uid:'3'},reply_to_reply_id:'4'}],has_more:0}),'x',spec)).state,'replied');
 assert.equal((await scan(call({status_code:0,comments:[],has_more:1}),'x',spec)).reason,'missing_cursor');
 assert.equal((await scan(call({status_code:429,comments:[]}), 'x',spec)).reason,'platform_verification');
 let pageCalls=0;
 const browser={__bridge:{replies:async(root,video,cursor)=>{pageCalls++;return cursor===0?
  {status_code:0,comments:[],has_more:1,cursor:1}:
  {status_code:0,comments:[{cid:'5',user:{uid:'3'},reply_to_reply_id:'4'}],has_more:0};}}};
 const bridge={call:async args=>({ok:true,connection:'x',value:await vm.runInNewContext(args.expression,{window:browser,setTimeout,clearTimeout})})};
 assert.equal((await scan(bridge,'x',spec)).state,'replied');assert.equal(pageCalls,2);
 console.log('只读接话匹配和不完整分页：PASS');
})().catch(e=>{console.error(e);process.exitCode=1});
