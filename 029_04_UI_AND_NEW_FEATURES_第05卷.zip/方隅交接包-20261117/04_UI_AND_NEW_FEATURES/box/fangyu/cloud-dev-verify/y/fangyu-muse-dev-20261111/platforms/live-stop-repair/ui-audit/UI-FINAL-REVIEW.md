# 本轮回复界面增量独立复核：通过

旧基线已复现，修补后 5 项主目标及 17 项新增边界验证均通过。未改产品、未操作浏览器/真实客户端，平台请求与模型请求均为 0；这是实际源码函数的隔离验证及静态 CSS 级联核对，不冒充真实视觉验收。

即时预览只显示当前已授权列表行的原帖标题、客户和评论，不建立 detail.comments，不出现 textarea、保存、核对或打开来源操作；直接调用保存/审核函数也没有发出请求。只有后端详情归属校验成功后，才显示真实已保存草稿的编辑器。选人时原 leadId、旧正文和 dirty 状态一并清空，未把上一人的草稿挪入预览。

新增边界已覆盖：快速 B→C 后旧 B 迟到；账号认证 epoch、员工、门店、平台变化；登出；后端返回错误员工或错误客户；读取失败后的只读预览及重选重试；选中不在已授权列表内的 id；来源文本 HTML 转义。以上均保持隔离且无写入。正常切到其他页后，同一合法详情响应可以保留，但不强制重绘隐藏页、不取消后台任务。

实际样式覆层核对结果：左侧帖标题 22px、右侧原帖标题 20px!important、原评论 17px、草稿 14px。根改动追加在 canvas-fit.css 末尾，原 CSS 字节前缀保持。抖音 `.rp-empty` 最终背景为 `linear-gradient(145deg,#18354d,#11293f)`；新增背景规则均带 `.shell[data-platform=douyin]`，保留小红书浅色。图片尺寸和左右分栏没有为本次字体调整而改大。

获客页“后台继续”的提示在 running 状态出现，验证码与平台拒绝显示不同标题。原页面导航函数没有变化，仍只切换视图；未新增暂停、取消或外发调用。原回复写入、来源、账号与迟到响应校验代码与 v17 相比未被削弱；reply-connected 只有只读预览块及选人清空字段两处变化。

## 精确源码 SHA256

| stage-02/project/work/ui-approved-implementation/ui-preview 下文件 | SHA256 |
| --- | --- |
| pages/reply-connected.mjs | 0dfac2ff17eaa65e25fb833e8a293507c5ab9a743eea452cae0be7e4b738a474 |
| canvas-fit.css | a3ec5f64930b396e5cbac5a78fdc0596b16019c9430a4dde602b0b67309a0df0 |
| pages/acquire.mjs | 184be4fe26efdc35fecdc6eff834562f99707a284362e9fd4f6ea355cd7037be |

证据：BASELINE.json、PATCH-RESULT.json、PREVIEW-EDGES.json；脚本 verify_ui.mjs、verify_preview_edges.mjs。初次新增 acquire 隔离夹具误将带 div 的 HTML 整体作为 JSON 解析，已修正为捕获真实 statusRow 参数；初次夹具结果另存 PREVIEW-EDGES-HARNESS.json，未改产品来迁就测试。

本报告只覆盖本轮 3 份 UI 源码，后台暂停与批次修复由对应审查者负责。未重复旧 29 项、GUI、平台采集、AI 或构建测试；未证明真实获客吞吐、头像下载或界面已经安装。
