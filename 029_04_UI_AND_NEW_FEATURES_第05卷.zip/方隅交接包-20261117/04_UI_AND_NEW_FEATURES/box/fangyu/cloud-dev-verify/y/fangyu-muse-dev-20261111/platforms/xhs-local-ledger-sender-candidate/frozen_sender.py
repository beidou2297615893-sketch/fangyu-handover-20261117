"""Synthetic-ledger experiment. No live database or platform client is instantiated."""
from pathlib import Path
import local_mode
from standalone_reply import AccountLock, Refused, Unknown


class Runner:
    def __init__(self, db, client):
        self.db = Path(db)
        self.client = client

    def submit(self, plan):
        plan.validate()
        if plan != self.client.plan:
            raise Refused('Client plan differs from authorized plan')
        # This directory is test-only. Production locks must be shared with
        # every cooperating sender and separately reviewed.
        with AccountLock(self.db.parent / 'synthetic-locks', plan.sender_uid):
            self.client.identity()
            plan.validate()
            if not local_mode.reserve(self.db, plan):
                raise Refused('Attempt already exists')
            try:
                plan.validate()
                self.client._armed = True
                data = self.client.send_once()
                comment = data.get('comment') if isinstance(data,dict) else None
                receipt = comment.get('id') if isinstance(comment,dict) else None
                if not isinstance(receipt,str) or not receipt.strip() or len(receipt)>200 or not receipt.isprintable():
                    raise Unknown('Missing reply receipt')
                local_mode.mark_unknown(self.db, plan, 'Platform returned receipt ' + receipt + '; visibility not independently confirmed')
                return 'receipt_received_unverified'
            except BaseException as exc:
                try:
                    local_mode.mark_unknown(self.db, plan, 'One attempt failed or had no confirmed receipt; no retry')
                except BaseException:
                    pass
                raise Unknown('One attempt unresolved; no retry') from exc
            finally:
                self.client._armed = False
