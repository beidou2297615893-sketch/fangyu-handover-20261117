"""Explicit user-requested continuation; quarantine one unknown search, no retry."""
import datetime,json,pathlib,sqlite3
ROOT=pathlib.Path(__file__).resolve().parent
REQUEST='a555afcc-b50c-45a4-acc4-06e246cc83e6'
def main():
    proof=json.loads((ROOT/'resume-identity-check.json').read_text(encoding='utf8'))
    assert proof['ok'] is True and proof['connection_matches'] is True
    assert proof['value']['http']==200 and proof['value']['status_code']==0 and proof['value']['account_matches'] is True
    assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(proof['at'].replace('Z','+00:00'))).total_seconds()<300
    ctl=ROOT/'runner-live-v2/control.json';before=ctl.read_bytes();control=json.loads(before)
    assert control.get('pending') is None and control.get('stopped')=='ledger_unknown'
    assert not list(ROOT.glob('runner-lease-*'))
    database=ROOT/'runtime/collection.sqlite3';backup=ROOT/('bridge-unknown-backup-'+REQUEST);backup.mkdir()
    (backup/'control.json').write_bytes(before)
    with sqlite3.connect(database) as db,sqlite3.connect(backup/'collection.sqlite3') as dst:db.backup(dst)
    with sqlite3.connect(database) as db:
        db.row_factory=sqlite3.Row;db.execute('BEGIN IMMEDIATE')
        h=db.execute('select * from account_halts').fetchall();assert len(h)==1 and h[0]['request_id']==REQUEST and h[0]['state']=='unknown'
        r=db.execute('select * from attempts where request_id=?',(REQUEST,)).fetchone();s=json.loads(r['spec']);response=json.loads(r['response'])
        assert r['state']=='unknown' and r['added']==0 and s['kind']=='search' and s['cursor']==0
        assert response.get('transport_error')=='bridge_result_not_established' and response.get('ok') is False
        fields=('scan_id','account_uid','kind','target','store_id','keyword');scope=tuple(s[k] for k in fields)
        assert db.execute('select 1 from scan_pages where request_id=?',(REQUEST,)).fetchone() is None
        cp=db.execute('select * from scan_streams where scan_id=? and account_uid=? and kind=? and target=? and store_id=? and keyword=?',scope).fetchone();assert cp is None
        reason='用户明确要求继续；原账号身份核验成功。原搜索结果仍未知，保留unknown并本地隔离该搜索词，非平台耗尽，不重发；继续其他搜索。'
        db.execute('insert into recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) values(?,?,?,?,?,?)',(s['account_uid'],REQUEST,'用户继续指令及Codex本地账号核验',reason,'用户：卡哪了，继续呀',datetime.datetime.now(datetime.timezone.utc).isoformat()))
        db.execute('insert into scan_streams values(?,?,?,?,?,?,?,?,?)',scope+(s['cursor'],1,REQUEST))
        db.execute('delete from account_halts where account_uid=? and request_id=?',(s['account_uid'],REQUEST))
        assert ctl.read_bytes()==before;db.commit()
    control['stopped']=None
    temp=ctl.with_suffix('.resume-bridge.tmp');temp.write_text(json.dumps(control,ensure_ascii=False),encoding='utf8');temp.replace(ctl)
    print('Unknown attempt preserved and quarantined; continuation recorded; no collection request retried.')
if __name__=='__main__':main()
