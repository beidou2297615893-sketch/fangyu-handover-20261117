"""Run only the new six visible comments through existing classification-only batch API."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'work/xhs-context-lite-analysis'))
import run as base

OUT = Path(__file__).resolve().parent/'browser-six-analysis'
NOTE = '6a3e040d000000000f017545'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--note', default=NOTE)
    parser.add_argument('--expected-count', type=int, default=6)
    args = parser.parse_args()
    note = args.note
    source = ROOT/'work/xhs-browser-context-recovery/ai-input.json'
    raw = base.load(ROOT/'work/xhs-browser-context-recovery'/f'{note}-browser-raw.json')
    expected = {c['id'] for c in raw['comments'] if c['uid'] != raw['author_uid']}
    rows = [r for r in base.load(source) if r['note_id'] == note]
    if len(rows) != args.expected_count or {r['comment_id'] for r in rows} != expected:
        raise ValueError('increment comment identity set changed')
    excluded = [r['comment_id'] for r in rows if r.get('own_reply_visible') or r.get('previously_stored')]
    rows = [r for r in rows if r['comment_id'] not in excluded]
    for row in rows:
        row['customer_id'] = row.get('customer_id') or 'review_'+row['comment_id']
        if raw.get('body_text_missing') and (row.get('post_text') or row.get('context_missing') is not True):
            raise ValueError('missing body must remain explicitly missing')
    output = OUT if note == NOTE else Path(__file__).resolve().parent/('browser-increment-'+note)
    output.mkdir(exist_ok=True)
    base.OUT = output
    original = base.make_payload
    def payload(records):
        data = original(records)
        for item, row in zip(data['comments'], records):
            for key in ('date_display', 'region_display_is_ip_not_customer_demand', 'unread_post_media', 'own_reply_visible', 'send_authorized'):
                item[key] = row.get(key)
        return data
    base.make_payload = payload
    base.ai.SYSTEM += '\n本批仅做分类，不生成回复或草稿。年份不明，不能将07-24等显示日期猜作2026年或断定过期/仍有效；相对日期保留原文不要猜精确时间。正文或图片未读必须unknown，不能编造房源细节；标题的古北仅证明帖子位置，不能证明本人区域偏好。还在吗是对出租房源询租但当前有效性待核。IP展示不能用于需求地域。意向强度、时效和本人地域必须分轴，近期且本人明确古北的需求才优先；只dd不得虚构求租，评论者提供房源应判供给。'
    provider = base.ai.CodexProvider()
    if base.ai.digest(provider.executable).lower() != provider.executable_sha256.lower():
        raise ValueError('official executable changed')
    auth = subprocess.run([str(provider.executable), 'login', 'status'], capture_output=True, text=True,
                          timeout=30, env=provider._environment(), creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if auth.returncode or 'Logged in using ChatGPT' not in auth.stdout+auth.stderr:
        raise ValueError('subscription login not confirmed')
    base.save(output/'manifest.json', {'comments':len(rows), 'ids':sorted(r['comment_id'] for r in rows), 'excluded_ids':excluded, 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                                  'capture_complete':raw.get('complete'), 'displayed_count':raw.get('displayed_comment_count'),
                                  'send':False, 'drafts':False, 'ledger_writes':False})
    result = base.execute_batch(0, rows, provider, base.load(ROOT/'work/xhs-ai-standalone/account-leimu.json'))
    base.save(output/'analysis.json', result)
    state = {'status':'completed', 'comments':len(result), 'interest_counts':dict(collections.Counter(r['result']['interest'] for r in result)),
             'role_counts':dict(collections.Counter(r['result']['role'] for r in result)), 'send':False, 'drafts':False}
    base.save(output/'state.json', state)
    print(json.dumps(state, ensure_ascii=False))


if __name__ == '__main__':
    main()
