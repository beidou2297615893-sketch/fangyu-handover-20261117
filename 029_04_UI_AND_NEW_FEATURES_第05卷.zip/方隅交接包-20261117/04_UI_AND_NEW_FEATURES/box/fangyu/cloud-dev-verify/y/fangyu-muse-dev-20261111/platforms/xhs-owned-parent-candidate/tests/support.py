"""Synthetic fixture around unchanged original parent checks and real subprocess bridge."""
import ast
from contextlib import contextmanager, closing
import copy
import importlib.util
import json
import os
import sqlite3
import subprocess
import socket
from pathlib import Path
import sys
import threading
import time
import types

ROOT=Path(__file__).resolve().parents[1]
def deny_network(*args,**kwargs):raise AssertionError('No network in isolated parent fixture')
socket.socket.connect=deny_network
socket.socket.connect_ex=deny_network
socket.create_connection=deny_network
socket.getaddrinfo=deny_network
RUNTIME=ROOT/'candidate/runtime'
for name,path in [('core',RUNTIME/'core'),('assistant',RUNTIME/'assistant')]:
    mod=types.ModuleType(name);mod.__path__=[str(path)];sys.modules[name]=mod

# Execute the *unchanged AST* of original account lock and AdapterBusy only.
# Unrelated platform imports are deliberately not loaded. Source is retained.
source=ROOT/'reference/adapters.py'
tree=ast.parse(source.read_text('utf-8-sig'))
names={'AdapterBusy','account_execution_lock','_account_locks_guard','_account_locks','_account_lock_owner'}
nodes=[]
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names:
        nodes.append(node)
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in node.targets):
        nodes.append(node)
assert len(nodes)==5
from contextlib import contextmanager
adapter=types.ModuleType('core.adapters')
adapter.__dict__.update(contextmanager=contextmanager,Path=Path,threading=threading,os=os)
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),adapter.__dict__)
sys.modules['core.adapters']=adapter

from core import reply_execution_policy as policy
spec=importlib.util.spec_from_file_location('owned_original_bridge',ROOT/'candidate/send/reviewed_reply_bridge.py')
bridge=importlib.util.module_from_spec(spec);spec.loader.exec_module(bridge)

class Fixture:
    def __init__(self, directory, fault=None, existing=False):
        self.directory=Path(directory).resolve()
        assert self.directory.is_relative_to(ROOT/'tests')
        self.uid='sender';self.lease=True;self.bound=True;self.safe=True;self.platform=True
        self.closed=False;self.remote_safety_hold=False;self.deployment_config={'runtime':{}}
        self.runtime=self
        self.actor={'id':'operator','tenant_id':'tenant','username':'synthetic','role':'operator','cloud_bound':True,'can_reply':True,'permission_revision':'v1','disabled':False,'_workbench_store_id':'store'}
        self.account={'id':'account','tenant_id':'tenant','cloud_owner':'synthetic','store_id':'store','platform':'xiaohongshu','platform_uid':'sender','conn_id':'conn','auth_generation':1,'identity_revalidation_generation':1,'status':'ready'}
        self.lead={'id':'lead','tenant_id':'tenant','author_id':'platformUser','comment_id':'comment','note_url':'https://www.xiaohongshu.com/explore/note'}
        self.reply={'id':'reply','tenant_id':'tenant','text':'合成精确正文','version':1,'approval_snapshot':'snapshot'}
        self.row={'replyId':'reply','text':'合成精确正文','version':1,'leadId':'lead','snapshot':'snapshot','authorId':'platformUser','accountId':'account'}
        self.queue={'id':'queue','tenant_id':'tenant','status':'running','reviewed':True,'reply_ids':['reply'],'snapshots':['snapshot'],'account_id':'account','authorized_by':'operator'}
        self.store=types.SimpleNamespace(directory=self.directory)
        self.session=types.SimpleNamespace(check=self._session_check)
        self.executor=types.SimpleNamespace(_xhs_app_session=self.session)
        self.service=types.SimpleNamespace(state='online',closed=False,executor=self.executor,device={'id':'device'})
        self.adapters=types.SimpleNamespace(channel_guard=threading.Lock(),channel_locks={},lifecycle_lock=threading.Lock(),closed=False,processes={},process_accounts={},job_processes={},require_account_safe=self._safe,_guard_platform=self._platform,account_spec=self._account_spec)
        self.trace=self.directory/'trace.txt';self.fault=fault
        self.before_stage=None;self.stages=[]
        sources=['helper/child.py','candidate/runtime/core/owned_ledger.py','candidate/runtime/core/reply_execution_policy.py','candidate/runtime/assistant/xhs_reply_worker.py','candidate/send/reviewed_reply_bridge.py','reference/ledger.py','reference/adapters.py']
        manifest={'version':1,'protocol':'reviewed-reply-v1','helperFlag':'--owned-xhs-reviewed-reply','executable':'helper/owned-helper.exe','executableSha256':policy.file_digest(ROOT/'helper/owned-helper.exe'),'sources':{name:policy.file_digest(ROOT/name) for name in sources}}
        self.reg=policy.register(self,ROOT,manifest,bridge.transport,expected_manifest_digest=policy.digest(manifest))
        self.plan={'queueId':'queue','items':[self.row]}
        self.decision=policy.mint(self,self,self.plan,self.actor,self.live_guard)
        self.seed_ledger(existing=existing)
    def ledger_cli(self,*args):
        result=subprocess.run([sys.executable,'-X','utf8','-B',str(ROOT/'reference/ledger.py'),'--db',str(self.directory/'ledger.sqlite3'),*args],capture_output=True,encoding='utf-8')
        if result.returncode:raise RuntimeError(result.stdout+result.stderr)
        return json.loads(result.stdout)
    def seed_ledger(self,existing=False):
        from core.owned_ledger import IsolatedLedger
        if not existing:
            self.ledger_cli('init')
            self.ledger_cli('identity-bind','xiaohongshu','platformUser','canonical','SYNTHETIC exact original lead and full history evidence')
            self.ledger_cli('lead','xiaohongshu','platformUser','comment')
            assess=self.directory/'assessment.json'
            assess.write_text(json.dumps({'source':'SYNTHETIC source','intent':'rental','store':'store','match':'match','pending':'','draft':'合成精确正文','peer_reply':'none'}),encoding='utf-8')
            self.ledger_cli('assess','xiaohongshu','platformUser','comment',str(assess))
            self.ledger_cli('review','xiaohongshu','platformUser','comment','operator','SYNTHETIC full history and current target evidence')
        self.binding={'tenant':'tenant','actor':'operator','account':'account','sender':'sender','platform_uid':'platformUser','canonical':'canonical','lead':'lead','note':'note','comment':'comment','text':'合成精确正文','mapping_evidence':'SYNTHETIC exact original lead and full history evidence'}
        self._owned_ledger=IsolatedLedger(self.directory/'ledger.sqlite3',self.binding)
    def ledger_state(self):
        with closing(sqlite3.connect(self.directory/'ledger.sqlite3')) as db:
            return db.execute("SELECT status FROM leads WHERE comment='comment'").fetchone()[0]
    def _session_check(self):
        if self.uid!='sender':raise ValueError('Synthetic session changed')
    def _safe(self,*a):
        if not self.safe:raise ValueError('Synthetic account unsafe')
    def _platform(self,*a):
        if not self.platform:raise ValueError('Synthetic platform guard denies')
    def _account_spec(self,platform,home,argv):
        return {'env':{'HOME':str(home),'USERPROFILE':str(home),'OWNED_SYNTHETIC_CONFIG':json.dumps({'trace':str(self.trace),'fault':self.fault,'uid':self.uid})}}
    def _principal(self,user):return copy.deepcopy(self.actor)
    def _executor(self,*a,**k):return self.executor
    def _device(self,*a):return {'bound':self.bound}
    def _account(self,*a):return copy.deepcopy(self.account)
    def require_current_reviewed_send_lease(self,*a):
        if not self.lease:raise ValueError('Synthetic lease denies')
    def _get(self,table,id,tenant):
        assert tenant=='tenant'
        return copy.deepcopy({'reply_queues':self.queue,'leads':self.lead,'accounts':self.account}[table])
    def _resolved_reply_lead(self,lead,*a,**k):return copy.deepcopy(lead)
    def live_guard(self):pass
    def send(self):
        with policy.reviewed_scope(self.decision):
            return self.decision.send(self.reply,self.lead,self.account,self.decision.home)
    def wires(self):return self.trace.read_text('utf-8').splitlines() if self.trace.exists() else []
