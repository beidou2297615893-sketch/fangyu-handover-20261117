"""Offline tests: never use the real Windows notification backend."""
import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor


MODULE_PATH = Path(__file__).with_name("notifications.py")


class NotificationTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(MODULE_PATH.exists(), "notification feature is not implemented")
        spec = importlib.util.spec_from_file_location("candidate_notifications", MODULE_PATH)
        self.mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.mod)
        self.tmp = tempfile.TemporaryDirectory(prefix="xhs-notifications-offline-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.calls = []

    def notifier(self, backend=None):
        return self.mod.Notifier(self.root, backend=self.calls.append if backend is None else backend)

    def emit(self, notifier, event_id="stopped-1"):
        return notifier.emit(event_id, "回复", "账号需要验证，回复已停止", "过验证后按启动", {"attempt": 1})

    def test_persist_before_backend_and_red_snapshot(self):
        def backend(alert):
            state = self.notifier().snapshot()
            self.assertEqual(state["alerts"][0]["event_id"], alert["event_id"])
            self.assertEqual(state["alerts"][0]["delivery_status"], "unknown")
        alert = self.emit(self.notifier(backend))
        self.assertEqual(alert["delivery_status"], "submitted")
        state = self.notifier().snapshot()
        self.assertEqual(state["severity"], "red")
        self.assertEqual(state["unread_count"], 1)
        self.assertIn("过验证", state["alerts"][0]["action"])

    def test_event_dedup_survives_new_notifier_without_clearing_old(self):
        self.emit(self.notifier())
        self.emit(self.notifier())
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.notifier().snapshot()["unread_count"], 1)

    def test_failure_is_visible_and_does_not_auto_retry(self):
        def broken(alert):
            raise RuntimeError("desktop unavailable")
        alert = self.emit(self.notifier(broken))
        self.assertEqual(alert["delivery_status"], "failed")
        self.assertIn("desktop unavailable", alert["delivery_error"])
        self.emit(self.notifier())
        state = self.notifier().snapshot()
        self.assertEqual(len(self.calls), 0)
        self.assertEqual(state["delivery_failures"], 1)
        self.assertIn("通知未送达", state["headline"])

    def test_explicit_retry_only_after_failure(self):
        def broken(alert):
            raise OSError("denied")
        self.emit(self.notifier(broken))
        fixed = self.notifier()
        self.assertEqual(fixed.retry_delivery("stopped-1")["delivery_status"], "submitted")
        fixed.retry_delivery("stopped-1")
        self.assertEqual(len(self.calls), 1)

    def test_crash_during_notification_keeps_unknown_and_no_replay(self):
        def crash(alert):
            raise SystemExit("simulated process disappearance")
        with self.assertRaises(SystemExit):
            self.emit(self.notifier(crash))
        alert = self.emit(self.notifier())
        self.assertEqual(alert["delivery_status"], "unknown")
        self.assertIn("待核对", self.notifier().snapshot()["headline"])
        self.assertEqual(len(self.calls), 0)

    def test_acknowledge_does_not_clear_alert_or_unknown_business_state(self):
        self.emit(self.notifier())
        self.notifier().acknowledge("stopped-1")
        state = self.notifier().snapshot()
        self.assertEqual(state["unread_count"], 0)
        self.assertEqual(state["severity"], "red")
        self.assertEqual(len(state["alerts"]), 1)
        self.assertEqual(state["alerts"][0]["reason"], "账号需要验证，回复已停止")

    def test_different_stop_events_are_independent(self):
        self.emit(self.notifier(), "collection-stop")
        self.emit(self.notifier(), "reply-stop")
        self.assertEqual(self.notifier().snapshot()["unread_count"], 2)
        self.assertEqual(len(self.calls), 2)

    def test_concurrent_duplicate_only_calls_backend_once(self):
        lock = threading.Lock()
        def backend(alert):
            with lock:
                self.calls.append(alert)
        notifier = self.notifier(backend)
        with ThreadPoolExecutor(max_workers=6) as pool:
            list(pool.map(lambda _: self.emit(notifier), range(12)))
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(len(notifier.snapshot()["alerts"]), 1)

    def test_empty_id_or_reason_is_rejected_without_notification(self):
        for field in ("event_id", "reason", "action", "lane"):
            args = dict(event_id="stop", lane="采集", reason="停止", action="按启动")
            args[field] = " "
            with self.assertRaises(ValueError):
                self.notifier().emit(**args)
        self.assertEqual(len(self.calls), 0)

    def test_secret_details_and_backend_error_are_redacted(self):
        def broken(alert):
            raise RuntimeError("Cookie=secret-cookie; Token=secret-token")
        notifier = self.notifier(broken)
        notifier.emit("e", "采集", "停止", "待核对", {"Cookie": "raw-cookie", "nested": {"token": "raw-token"}})
        data = json.dumps(notifier.snapshot(), ensure_ascii=False)
        for secret in ("raw-cookie", "raw-token", "secret-cookie", "secret-token"):
            self.assertNotIn(secret, data)

    def test_windows_backend_uses_fake_runner_and_falls_back(self):
        invocations = []
        def runner(command, **kwargs):
            invocations.append((command, kwargs))
            if len(invocations) == 1:
                raise OSError("toast unavailable")
        backend = self.mod.WindowsBackend(runner=runner)
        backend({"lane": "回复", "reason": "进程消失", "action": "待核对后按启动"})
        self.assertEqual(len(invocations), 2)
        self.assertIn("-EncodedCommand", invocations[0][0])
        self.assertFalse(invocations[0][1]["shell"])
        self.assertTrue(all(kwargs["timeout"] <= 1.4 for _, kwargs in invocations))

    def test_windows_backend_reports_failure_of_both_paths(self):
        def broken(*args, **kwargs):
            raise OSError("unavailable")
        with self.assertRaisesRegex(RuntimeError, "通知.*失败"):
            self.mod.WindowsBackend(runner=broken)({"lane": "采集", "reason": "已停止", "action": "换号"})

    def view_module(self):
        path = MODULE_PATH.with_name("progress_view.py")
        self.assertTrue(path.exists(), "read-only progress view is not implemented")
        spec = importlib.util.spec_from_file_location("candidate_progress_view", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_progress_view_is_read_only_and_start_is_disabled(self):
        view = self.view_module()
        status = {"lanes": {"collect": {"status": "stopped", "uid": "offline-uid", "reason": "需要验证", "action": "过验证"},
                            "send": {"status": "paused", "today_sent": 7, "success": 4, "failed": 2, "unknown": 1}}}
        status_path = self.root / "controller-status.json"
        status_path.write_text(json.dumps(status), encoding="utf-8")
        before = status_path.read_bytes()
        self.emit(self.notifier())
        model = view.load_view(self.root)
        self.assertEqual(model["lanes"]["collect"]["uid"], "offline-uid")
        self.assertEqual(model["lanes"]["send"]["today_sent"], 7)
        self.assertFalse(model["start_enabled"])
        self.assertIn("未安装", model["installation_note"])
        self.assertEqual(model["severity"], "red")
        self.assertEqual(status_path.read_bytes(), before)

    def test_progress_view_missing_or_corrupt_files_are_red_and_human_readable(self):
        view = self.view_module()
        model = view.load_view(self.root)
        self.assertEqual(model["severity"], "red")
        self.assertIn("尚未", model["read_errors"][0])
        (self.root / "controller-status.json").write_text("{broken", encoding="utf-8")
        model = view.load_view(self.root)
        self.assertTrue(any("无法读取" in item for item in model["read_errors"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
