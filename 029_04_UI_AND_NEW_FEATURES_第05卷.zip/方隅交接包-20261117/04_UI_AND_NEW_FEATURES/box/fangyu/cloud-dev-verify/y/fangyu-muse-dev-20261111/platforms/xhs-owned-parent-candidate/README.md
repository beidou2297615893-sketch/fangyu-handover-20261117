# 原受控父进程与台账：独立离线接入候选

本目录完成的是**真实原父子协议与新版台账之间的隔离接入验证**，不是原软件安装升级，也不是平台真实发送验收。所有账号、队列、用户、身份映射、正文、历史和回执均为合成数据。原软件、生产库、真实会话和共享台账未修改；没有平台网络请求。适配器只接受本目录tests下已经存在的数据库，没有生产启用开关。

## 实际复用与改动

原reviewed_reply_bridge.py与xhs_reply_worker.py逐字不变。父进程实际启动本地owned-helper.exe，经标准管道运行原worker.serve；nonce、preflight/identity/before_post/post、逐次allow、结果digest、ack和子进程退出检查均走原代码。新增C# helper仅转发管道，child.py仅通过原serve的setup参数提供合成客户端，不进入生产_setup、不读Cookie。非法nonce/乱序阶段通过管道边界故障注入验证拒绝，没有替换原握手实现。

原ReviewedDecision.check/mint/matches、reviewed_scope、registration.check均保留。合成fixture提供员工、设备、许可和账号安全响应，原check真实执行，没有替换恒真check；这不是实际认证服务或平台安全状态验证。原账号跨线程/跨进程锁从逐字adapters.py快照选取未改AST执行，仅加载锁与AdapterBusy，不加载无关平台模块；不是完整Adapters集成。

唯一原业务源码补丁为candidate/runtime/core/reply_execution_policy.py的send方法，见evidence/parent-ledger.patch；新增candidate/runtime/core/owned_ledger.py。其余新增文件为合成helper、测试和证据脚本。reference/ledger.py是新版原台账逐字副本，未改协议或程序。

## 接入顺序

1. 必须具备精确IsolatedLedger类型，缺失/伪造对象不降级。冻结操作者、租户、账号、发送UID、客户平台UID、canonical历史ID、lead、帖子、评论、逐字正文和映射证据。
2. 原阶段守卫通过，authorize('post')核对精确body后检查冻结绑定、映射和台账草稿，再调用原reserve。必须字面granted is True；重复预留或1/字符串true均不放行。
3. 预留提交后提交原consume_budget；再次核对原身份、权限、队列、账号及同一个台账能力，之后原bridge才写allow。部分提交保持阻断，不自动释放。
4. 原结果校验通过后写sent；写回失败不返回成功。异常写unknown，写回也失败则保留reserved；BaseException或父进程os._exit硬退出不会释放预留。

映射校验对照冻结证据与真实台账查询，不能证明人工证据本身真实；真实接入仍需从原members/投影/lead及平台逐人核验。原台账保护reserved后的筛选/审核不再改写，canonical映射不可重绑；适配器预留前后都核对映射与正文。不声称能阻止绕开候选的外部进程直接改数据库，或能在平台请求与后来新增历史之间建立跨系统事务。

## 运行与证据

运行python -X utf8 -B run_verification.py。返回码及日志保存在evidence/VERIFICATION.json和对应log。运行python -X utf8 -B build_evidence.py重验原源hash并生成补丁及候选hash。

候选覆盖：原管道一次发送/阻重、无上下文拒绝、正文变化、许可撤销、非法nonce/阶段、11维绑定、未核实历史、严格true、成功写回、未知回执、预留后致命异常与硬退出、写回失败、全部写回失败、预留后权限变化/adapter替换、adapter路径越界、4线程及4个独立父进程竞争仅1次合成POST。另运行原policy/worker8项及原台账21项回归。最终数量与状态以日志为准。

SOURCE-HASHES.json是改动前7份快照的原源记录，不代表修改后的候选仍等于原源。evidence/FINAL-PROVENANCE.json列原源当前hash、是否保持不变与候选修改范围；FINAL-CANDIDATE-HASHES.json固定最终候选。旧失败运行的tmp文件夹只含合成数据库。

## 验收边界

已证明保留原守卫代码与原父子握手时，离线台账能在post allow前持久预留，在回执核验后写回。没有部署到现用软件，没有真实会话、云端发送许可或平台回执；不能称全局防重或真实发送成功。

fixture没有完整Core/Store/原UI队列操作入口。原Adapters环境构建、生产helper闭包、Cookie摘要守卫和真实网络transport未执行。上线前需完整候选依赖闭包与合法注册hash、原队列成员/历史映射核验、真实云端许可及会话验证，以及用户明确授权的一条真实发送验收。不得将本合成helper替换成真实平台CLI绕过现用guard。
