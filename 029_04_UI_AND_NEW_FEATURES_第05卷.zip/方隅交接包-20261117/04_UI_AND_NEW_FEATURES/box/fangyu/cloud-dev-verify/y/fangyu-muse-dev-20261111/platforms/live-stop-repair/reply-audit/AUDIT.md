# 回复读取与采集期间按钮：独立只读审计

本轮仅读取 v17 源码、当前活动版本记录及生命周期日志。没有操作桌面、启动客户端、调用真实平台或云接口、写入产品与数据库，也未重跑旧测试。

## 已确认的调用链

1. `ui-preview/pages/reply-connected.mjs:88` 的 `selectCustomer` 每次选择不同客户时清空 `v.detail`，设置 `detailLoading=true`，然后等待 `ctx.replyRead`。这期间右侧只显示“正在读取原评论与草稿”，即使左侧已存在姓名、原评论摘要、帖子和图片。
2. `ui-preview/backend.mjs:6,98–103` 将 `reply_read` 视为普通只读请求，默认 15 秒前端超时。它使用 POST，但不应标记写结果未知。源码没有让它无限等待的定时器。
3. `ui_native_host.py:303` 的 `dispatch_api` 对整条业务调用持 `server.api_lock`；`workbench_backend.py` 的回复分发另持 `self.lock`。同一时刻其它业务 API 会排队。
4. `WorkbenchBackend._identity:241–276` 每个请求强制刷新云身份，并读取中央门店目录。`_selected_store:514–519` 还会调用 `_activate_central_config`，它不是纯本地短检查。
5. `ReplyWorkbench._context:35–40` 先调用 `customers.detail`；后者在 `CustomerWorkbench.detail:568–585` 内执行一次 `history.customer_detail`。紧接着 `_context` 再调用一次 `_history(...).customer_detail`。`CustomerHistory.customer_detail:549–553` 每次都调用 `_build`，因此一次回复详情有重复全历史构建。
6. `ReplyWorkbench.read:54–110` 对该客户每条评论调用 `_latest` 扫全体回复，并再次扫描账号；这些可以在本次请求内预索引，而不能绕过逐条权限与收件人校验。

这些是已确认的调用和重复工作。没有真实请求耗时样本，不能把其中某一项宣称为已量测的唯一瓶颈。

## 图片锁的准确结论

`WorkbenchBackend.media:226–232` 在 `self.lock` 内执行身份和当前门店检查，真正的图片读取在锁外。`CustomerWorkbench.media:357–363` 在 `core.lock` 内检查可见性，锁外调用 `saved_avatar`，结束后再锁内检查。下载本身已经移出锁，不应重复做这一改动。

实际仍可能排队的是每张头像请求在 `self.lock` 内进行云身份/门店目录核验。可复用 `_ReadOnlyDeliveryIntegrations(self.core)` 为每个媒体请求建立独立验证实例，在锁外执行现有 `_identity(..., verification=...)`，避免共享缓存/profile和会话续期。短锁中只检查关闭状态、本地 session完整身份和 `_load_selection(...)[storeId]`。不要在短锁调用 `_selected_store`，因为它会隐式联网和激活配置。图片返回前再检查本地身份/选店，原客户媒体前后可见性检查全部保留。

## 最小修改建议

- 将 `CustomerWorkbench.detail` 的单次构建抽成内部 `detail_context`，返回内部 person 与公开 detail。公开方法保持原 JSON 投影；`ReplyWorkbench._context` 重用该次已检查的 person，避免第二次全历史构建。
- `ReplyWorkbench.read` 在本请求内一次读取 replies/accounts 并索引；保留版本合法性、逐 lead 的回复权限/目标核验、逐账号 `_account_access`、门店/平台边界和未知回执处理。
- `selectCustomer` 立即使用当前已返回列表行显示只读预览，或严格绑定 authEpoch/user/store/platform/customer 的旧详情只读缓存。新详情返回前不生成可编辑 comment，不允许 SOP覆盖、草稿编辑、保存、核对和发送。身份/门店/平台变化清理；新响应失效不能覆盖当前客户。
- 读取失败结束 loading，并提供简短的重读入口；原 dirty/pending/journal 不得被只读缓存覆盖。

## 采集期间按钮的现状

| 操作 | 源码行为 | 建议 |
| --- | --- | --- |
| 获客/回复/客户/账号/管理之间切页 | `app.navigate:29` 只变页面并渲染；获客页 cleanup 只清前端 timer，没有暂停/取消任务调用 | 保持可用；明确“采集会在后台继续” |
| 切平台视图 | `app.switchPlatform:569–587` 保存平台工作区、失效读请求、换页面数据；无暂停/取消任务调用 | 可保留视图切换；未确认写/采集启动期间必须禁用并说明原因 |
| 获客页门店和帖子时间 | `acquire.renderConnected:106–122` 的 locked 包含 running/queued/pausing/resuming/stopping；`controls:26,28` 输出 disabled | 保持锁定条件并加可见或 title/aria 说明“采集中，暂停后可更改” |
| 选用平台账号 | `accounts.mjs:92–98` 点击后检查采集状态并 toast；呈现时尚未按采集状态 disabled | 将已有拒绝条件同步到 disabled +说明，避免可点却拒绝 |
| 再次开始 | 活跃状态时按钮禁用，事件再次检查 activeStatuses | 保留，说明正在采集；暂停仍按真实 canPause 开放 |
| 其它入口的门店/预设变更 | `_save_selection` 更新偏好，不调用任务暂停/取消；当前前端 selectStore 只守 busy/未知写，没有统一采集中变更说明 | 对影响本次范围的变更加统一采集锁；纯查看保持开放 |

切页会停止该页的状态轮询，但这不等同后台任务停止。当前前端没有证据表明普通切页调用暂停。真实平台拒绝、任务停止原因由采集审计另行核对，不从 UI 状态推断。

## 增量安全回归清单

1. 每次媒体请求仍 fresh me/目录；使用独立 verifier；主 integrations cache/profile 和加密会话不被媒体请求改写。过期/401/403/服务失败都不能返回图片。
2. 用隔离事件屏障暂停媒体身份核验，另一线程仍可获取 backend.lock；媒体下载前后 logout、disabled、role/user/tenant变化、切店均拒绝返回。原 lead/task/store 可见性前后检查保留。
3. 一次回复详情仅一次 history.customer_detail；公开 detail 输出与原行为一致，内部 person 永不序列化到 JSON。
4. replies/accounts预索引后，跨 owner/平台/门店账号被拒；版本冲突、未知回执与原目标验证不变。
5. 只读列表预览/缓存立即出现；fresh成功前所有写入口不可用；超时退出loading；A→B的迟到A不覆盖B；auth/store/platform变化清缓存；脏稿和未知写不丢。
6. 隔离交互记录中切页/纯视图不产生 pause/cancel；会改本次范围的控件 disabled且附说明；显式暂停按钮才提交 pause。

## 当前运行证据限制

`state/active.json` 与生命周期日志确认最新活动版本为 `ui-r57-20261019T075625Z-e6716b13`，最近一次启动到 `native_ready`。`StaticHandler.log_message` 为 no-op，生命周期日志只包含启动/异常阶段，不包含 reply_read/media 云核验或锁等待耗时。因此不能从这些日志计算评论详情的实际延迟；后续仅需在本轮改动的隔离行为验证中记录耗时/锁阶段，不能虚构生产性能验收。
