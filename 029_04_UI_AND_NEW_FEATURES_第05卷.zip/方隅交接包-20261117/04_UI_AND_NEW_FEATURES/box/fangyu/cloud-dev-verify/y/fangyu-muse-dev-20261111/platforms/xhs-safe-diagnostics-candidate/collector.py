"""Isolated, opt-in Xiaohongshu collection candidate; never sends comments.

The collector writes an AI input draft and an import candidate, not the shared
ledger. Platform-visible reply history is deliberately not queried. No network
operation happens unless ``--execute`` is explicitly passed.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path
import sqlite3
import sys
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit

import httpx
from xhs_cli.client import XhsClient
from xhs_cli.exceptions import XhsApiError

ROOT = Path(__file__).resolve().parent


class Halt(RuntimeError):
    """A collection limit, account failure or platform challenge: do not retry."""


def safe_api_error(exc, stage):
    """Return only known categories and numeric platform codes; never raw errors."""
    names={'XhsApiError','NeedVerifyError','SessionExpiredError','IpBlockedError','SignatureError'}
    category=type(exc).__name__
    result={'stage':stage if stage in ('identity','search','comments') else 'unknown',
            'error_type':category if category in names else 'OtherPlatformError'}
    code=getattr(exc,'code',None)
    if isinstance(code,str) and re.fullmatch(r'-?[0-9]{1,10}',code):code=int(code)
    if type(code) is int and -1000000000<=code<=1000000000:result['api_code']=code
    return result


class ReadClient(XhsClient):
    """Use the installed CLI's signed read API with no browser or retry fallback."""
    _ALLOWED = {
        ('GET', 'https://edith.xiaohongshu.com/api/sns/web/v2/user/me'),
        ('POST', 'https://edith.xiaohongshu.com/api/sns/web/v1/search/onebox'),
        ('GET', 'https://edith.xiaohongshu.com/api/sns/web/v1/search/filter'),
        ('POST', 'https://edith.xiaohongshu.com/api/sns/web/v1/search/notes'),
        ('GET', 'https://edith.xiaohongshu.com/api/sns/web/v1/search/recommend'),
        ('GET', 'https://edith.xiaohongshu.com/api/sns/web/v2/comment/page'),
    }

    def __init__(self, cookies, transport=None, delay=1.0):
        super().__init__(dict(cookies), request_delay=0, max_retries=1)
        self._http.close()
        self._http = httpx.Client(timeout=30, follow_redirects=False, trust_env=False, transport=transport)
        self._minimum_delay = delay
        self._last_read = 0.0
        self._last_stage = 'unknown'

    def _request_with_retry(self, method, url, **kwargs):
        parsed = urlsplit(url)
        endpoint = parsed.scheme + '://' + parsed.netloc + parsed.path
        if parsed.fragment or (method, endpoint) not in self._ALLOWED:
            raise Halt('拒绝非采集接口')
        self._last_stage = ('identity' if endpoint.endswith('/user/me') else
                            'comments' if endpoint.endswith('/comment/page') else 'search')
        wait = self._minimum_delay - (time.monotonic() - self._last_read)
        if wait > 0:
            time.sleep(wait)
        try:
            response = self._http.request(method, url, **kwargs, follow_redirects=False)
        except httpx.HTTPError as exc:
            name = 'Timeout' if isinstance(exc,httpx.TimeoutException) else 'NetworkError'
            raise Halt('平台请求失败：'+json.dumps({'stage':self._last_stage,'error_type':name,'request_started':True},ensure_ascii=False)+'，已停止，不自动重试') from None
        self._last_read = time.monotonic()
        if response.status_code != 200:
            detail={'stage':self._last_stage,'error_type':'HTTPError','http_status':response.status_code,'request_started':True}
            raise Halt('平台读取失败：'+json.dumps(detail,ensure_ascii=False)+'，已停止，不自动重试')
        return response

    def _handle_response(self, response):
        try:
            return super()._handle_response(response)
        except XhsApiError as exc:
            # Do not expose tokens or let vendor prewarm/HTML fallback swallow a challenge.
            detail=safe_api_error(exc,self._last_stage)
            detail['http_status']=response.status_code
            detail['request_started']=True
            raise Halt('平台读取失败：'+json.dumps(detail,ensure_ascii=False)+'，已停止，不自动重试') from None


def verify_identity(client, expected_uid):
    if not isinstance(expected_uid, str) or not expected_uid.strip():
        raise Halt('必须指定登录账号')
    data = client.get_self_info()
    if not isinstance(data, dict):
        raise Halt('无法确认登录账号')
    found = []
    for item in (data, data.get('user_info'), data.get('basic_info')):
        if isinstance(item, dict):
            found += [item[k] for k in ('user_id', 'userid', 'uid') if isinstance(item.get(k), str) and item[k]]
    if not found or set(found) != {expected_uid}:
        raise Halt('当前登录账号与指定账号不一致')


def note_items(data, maximum):
    if not isinstance(data, dict) or not isinstance(data.get('items'), list):
        raise Halt('搜索结果格式异常，已停止')
    results, seen = [], set()
    for item in data['items']:
        if not isinstance(item, dict):
            continue
        card = item.get('note_card') or {}
        if not isinstance(card, dict):
            continue
        note_id = item.get('id') or card.get('note_id')
        token = item.get('xsec_token') or card.get('xsec_token')
        if not isinstance(note_id, str) or not note_id or note_id in seen:
            continue
        seen.add(note_id)
        title = card.get('display_title') or card.get('title') or ''
        if not isinstance(title, str):
            title = ''
        results.append({'note_id': note_id, 'title': title, 'token': token if isinstance(token, str) else ''})
        if len(results) >= maximum:
            break
    return results


def published_at(value):
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0:
        seconds = value / 1000 if value > 100_000_000_000 else value
        try:
            return datetime.fromtimestamp(seconds, timezone.utc).isoformat()
        except (ValueError, OverflowError, OSError):
            return ''
    return ''


def build_result(observations, pending, keyword, pages, truncated):
    pending = list(pending)
    by_comment = {}
    duplicates = 0
    for item in observations:
        by_comment.setdefault(item['comment_id'], []).append(item)
    grouped, conflicts = {}, []
    for cid, entries in by_comment.items():
        unique = {json.dumps(x, ensure_ascii=False, sort_keys=True) for x in entries}
        if len(unique) > 1:
            conflicts.append({'reason': 'same_comment_conflicting_observations', 'observations': entries})
            continue
        duplicates += len(entries) - 1
        x = entries[0]
        customer = grouped.setdefault(x['customer_uid'], [])
        customer.append(x)
    customers=[]
    for uid, items in sorted(grouped.items()):
        if len(items) > 101:
            pending.append({'reason': 'too_many_comments_for_ai_input', 'observations': items})
            continue
        def source(x):
            return {'comment_id': x['comment_id'], 'note_id': x['note_id'], 'comment_text': x['comment_text'],
                    'parent_text': '', 'parent_relationship': 'not_collected', 'post_title': x['post_title'],
                    'post_text': '', 'published_at': x['published_at'],
                    'missing_context': ['post_body_missing', 'parent_not_collected', 'subcomments_not_collected']}
        lead = source(items[0])
        customers.append({'customer_id': items[0]['customer_id'], 'customer_uid': uid, **lead,
                          'other_comments': [source(x) for x in items[1:]],
                          'identity_evidence': items[0]['identity_evidence']})
    return {'schema': 'xhs-collected-ai-input-v1', 'keyword': keyword,
            'limits': ['local_identity_map_only', 'post_body_missing', 'subcomments_not_collected',
                       'reply_history_not_checked', 'not_imported_into_shared_ledger', 'not_analyzed_or_send_authorized'],
            'summary': {'customers': len(customers), 'usable_comments': sum(1+len(x['other_comments']) for x in customers),
                        'duplicate_observations': duplicates, 'conflicted_comments': len(conflicts),
                        'pending': len(pending), 'comment_pages': pages, 'truncated_note_pages': truncated},
            'customers': customers, 'pending': pending, 'conflicts': conflicts}


def collect(client, expected_uid, keyword, identity_map, max_notes=3, max_pages=1, on_progress=None):
    if not isinstance(keyword, str) or not keyword.strip() or keyword != keyword.strip():
        raise Halt('请输入搜索词')
    if not isinstance(identity_map, dict):
        raise Halt('客户身份映射格式错误')
    verify_identity(client, expected_uid)
    notes = note_items(client.search_notes(keyword=keyword, page=1), max_notes)
    observations, pending, pages, truncated = [], [], 0, 0
    for note in notes:
        if not note['token']:
            pending.append({'reason': 'note_access_context_missing', 'note_id': note['note_id']})
            continue
        cursor = ''
        for page_number in range(max_pages):
            response = client.get_comments(note['note_id'], cursor=cursor, xsec_token=note['token'], xsec_source='pc_search')
            if not isinstance(response, dict) or not isinstance(response.get('comments'), list):
                raise Halt('评论结果格式异常，已停止')
            pages += 1
            for item in response['comments']:
                if not isinstance(item, dict):
                    pending.append({'reason': 'invalid_comment_record', 'note_id': note['note_id']})
                    continue
                user = item.get('user_info') or {}
                uid = user.get('user_id') if isinstance(user, dict) else None
                cid, text = item.get('id'), item.get('content')
                if not all(isinstance(x, str) and x.strip() and x == x.strip() and len(x) <= 5000 for x in (uid, cid, text)):
                    pending.append({'reason': 'missing_or_invalid_identity_or_text', 'note_id': note['note_id'],
                                    'comment_id': cid if isinstance(cid, str) else '', 'text': text if isinstance(text, str) else ''})
                    continue
                known = identity_map.get(uid)
                if uid in identity_map and (not isinstance(known, str) or not known):
                    pending.append({'reason': 'local_identity_conflict', 'note_id': note['note_id'], 'comment_id': cid, 'text': text})
                    continue
                canonical = known or 'xhs_new_' + hashlib.sha256(('xiaohongshu:' + uid).encode('utf8')).hexdigest()
                observations.append({'customer_id': canonical, 'customer_uid': uid, 'comment_id': cid,
                                     'note_id': note['note_id'], 'comment_text': text, 'post_title': note['title'],
                                     'published_at': published_at(item.get('create_time')),
                                     'identity_evidence': 'local_source_consistency_only' if known else 'new_uid_needs_ledger_import'})
            if on_progress:
                on_progress(build_result(observations, pending, keyword, pages, truncated))
            next_cursor = response.get('cursor') or ''
            if not response.get('has_more'):
                break
            if not isinstance(next_cursor, str) or not next_cursor or next_cursor == cursor:
                pending.append({'reason': 'pagination_cursor_missing_or_repeated', 'note_id': note['note_id']})
                break
            cursor = next_cursor
            if page_number == max_pages - 1:
                truncated += 1
    return build_result(observations, pending, keyword, pages, truncated)


def index_identities(customers):
    mapping = {}
    for customer in customers:
        if customer.get('platform') != 'xiaohongshu':
            continue
        cid = customer.get('customer_id')
        uid = customer.get('platform_uid')
        members = customer.get('comments') or []
        candidates = {x.get('author_uid') for x in members if isinstance(x, dict) and isinstance(x.get('author_uid'), str) and x['author_uid']}
        if isinstance(uid, str) and uid:
            candidates.add(uid)
        for candidate in candidates:
            resolved = cid if uid == candidate and isinstance(cid, str) and cid else None
            if candidate in mapping and mapping[candidate] != resolved:
                mapping[candidate] = None
            elif candidate not in mapping:
                mapping[candidate] = resolved
    return mapping


def load_identity_map(database, account_uid):
    adapter = ROOT.parent / 'xhs-ai-input-adapter' / 'adapter.py'
    spec = importlib.util.spec_from_file_location('xhs_local_identity_adapter', adapter)
    if spec is None or spec.loader is None:
        raise Halt('未找到本地身份适配器')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = module.extract(database, None, account_uid)
    return index_identities(result['customers'])


def merge_ledger_identity_map(mapping, ledger):
    """Merge local observations without upgrading them to platform verification."""
    result=dict(mapping)
    path=Path(ledger).resolve(strict=True)
    db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=2)
    try:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'identity_aliases','reservations','local_sender_plans'} <= tables:
            raise Halt('共享账本缺少身份或发送记录表')
        rows=list(db.execute("SELECT alias,canonical FROM identity_aliases WHERE platform='xiaohongshu'"))
        if 'collection_uid_observations' in tables:
            import register
            observed,_,_=register._identity_observations(db,apply=False)
            rows += list(observed.items())
        for customer,payload in db.execute("SELECT r.customer,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token WHERE r.platform='xiaohongshu'"):
            try:
                record=json.loads(payload)
                plan=record.get('plan') or record.get('local_mode',{}).get('plan')
                uid=plan['customer_uid']; canonical=plan.get('canonical_customer') or customer
                if not isinstance(uid,str) or not uid or canonical!=customer:raise ValueError('invalid identity')
            except (ValueError,TypeError,KeyError,AttributeError):
                raise Halt('历史发送身份记录无法解析') from None
            rows.append((uid,canonical))
        db.rollback()
    finally:
        db.close()
    for uid,cid in rows:
        if not isinstance(uid,str) or not uid or not isinstance(cid,str) or not cid:
            raise Halt('账本身份记录格式无效')
        if uid in result and result[uid]!=cid:
            result[uid]=None
        elif uid not in result:
            result[uid]=cid
    return result


def write_json(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    os.replace(tmp, path)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--keyword', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--session-home')
    p.add_argument('--sender-uid')
    p.add_argument('--source-db')
    p.add_argument('--ledger')
    p.add_argument('--max-notes', type=int, default=3)
    p.add_argument('--max-pages', type=int, default=1)
    p.add_argument('--execute', action='store_true')
    args = p.parse_args(argv)
    if not args.execute:
        print(json.dumps({'mode': 'preview', 'keyword': args.keyword, 'network': False, 'send': False}, ensure_ascii=False))
        return 0
    if not args.session_home or not args.sender_uid or not args.source_db or not args.ledger:
        raise Halt('执行前必须指定独立登录目录、账号、本地客户数据库和共享账本')
    if not 1 <= args.max_notes <= 20 or not 1 <= args.max_pages <= 20:
        raise Halt('采集范围无效')
    output = Path(args.output).resolve()
    if output.exists():
        raise Halt('输出目录已存在，请使用新目录')
    identity_map = merge_ledger_identity_map(load_identity_map(args.source_db, args.sender_uid),args.ledger)
    home = Path(args.session_home).resolve(strict=True)
    os.environ['HOME'] = str(home); os.environ['USERPROFILE'] = str(home)
    sys.path.insert(0, str(ROOT.parent / 'xhs-standalone-reply'))
    from standalone_reply import load_independent_cookies
    client = ReadClient(load_independent_cookies(home))
    output.mkdir(parents=True, exist_ok=False)
    try:
        result = collect(client, args.sender_uid, args.keyword, identity_map,
                         max_notes=args.max_notes, max_pages=args.max_pages,
                         on_progress=lambda value: write_json(output / 'partial.json', value))
        write_json(output / 'collection.json', result)
        write_json(output / 'ai-input.json', result['customers'])
        write_json(output / 'ledger-import-candidates.json', {'records': [
            {'platform': 'xiaohongshu', 'customer_id': row['customer_id'], 'comment_id': c['comment_id']}
            for row in result['customers'] for c in [row, *row['other_comments']]]})
        print(json.dumps(result['summary'], ensure_ascii=False))
    finally:
        client.close()
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Halt, OSError, ValueError, sqlite3.Error, httpx.HTTPError) as exc:
        print('停止：' + str(exc), file=sys.stderr)
        raise SystemExit(2)
