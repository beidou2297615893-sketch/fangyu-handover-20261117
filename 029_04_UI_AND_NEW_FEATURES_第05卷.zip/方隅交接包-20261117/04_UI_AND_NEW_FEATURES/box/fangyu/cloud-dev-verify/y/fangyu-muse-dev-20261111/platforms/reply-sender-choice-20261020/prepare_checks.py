from pathlib import Path
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/reply-sender-choice-20261020')
p=T.parent/'overnight-verification/round-10-batch-sop/test_batch.mjs';s=p.read_text('utf-8').replace("accountId:'account-b',batchRole", "accountId:'account-b',batchAccountId:'account-b',batchRole")
s=s.replace(" const ctx={state,", " state.platform={accounts:[{id:'account-b',platform:'xiaohongshu',status:'ready',name:'二号'}]};\n const ctx={state,")
(T/'test_batch_regression.mjs').write_text(s,encoding='utf-8')
p=T/'test_sender.mjs';s=p.read_text('utf-8');s+=r'''
const {renderConnected}=await import(pathToFileURL(W+'/pages/reply-connected.mjs'));
const {bindDelivery}=await import(pathToFileURL(W+'/pages/reply-delivery.mjs'));
const single=fixture();single.v.actor='0|employee|store|xiaohongshu';single.v.items=[];single.v.stats={};single.v.page=1;single.v.checkedIds=[];single.v.collapsedGroups=[];single.v.selectedId='p';single.v.leadId='comment-p';single.v.text='模拟草稿';single.v.accountId='account-b';single.v.detail={item:{id:'p',name:'模拟客户',tone:'medium',level:'中意向'},comments:[{id:'comment-p',accounts:[{id:'account-a',name:'一号'},{id:'account-b',name:'二号备注',platformNickname:'小红薯乙'}],draft:{status:'approved',review_account_id:'account-a',id:'saved',version:1},reviewCurrent:true,text:'原评论',canSave:true}]};
const singleHtml=renderConnected(single.state);assert.match(singleHtml,/发送账号/);assert.doesNotMatch(singleHtml,/核对账号/);assert.match(singleHtml,/小红薯乙/);assert.ok(singleHtml.indexOf('rp-sender-choice')<singleHtml.indexOf('rp-person-summary'),'sender is visible at the top of the editor');assert.match(singleHtml,/选择员工 \/ 客户 SOP/);
const deliveryHandlers={};const root={querySelector:q=>q==='[data-delivery-single]'?{addEventListener:(_,fn)=>deliveryHandlers.single=fn}:null,querySelectorAll:()=>[]};bindDelivery(root,single.ctx,single.v,()=>{});deliveryHandlers.single();assert.equal(single.calls.length,0,'changing sender cannot prepare an approval bound to old account');
console.log('PASS: sender nickname at top, SOP visible, changed single sender requires fresh review');
''';p.write_text(s,encoding='utf-8')
# Reuse the verified canonical installation pipeline without launching the GUI.
p=T.parent/'overnight-verification/round-17-task-resume/prepare_v38.py';s=p.read_text('utf-8').replace('v38','v39').replace('v37','v38');s=s.replace("'status':'PASS_SOURCE_CLOSURE_AND_TASK_RESUME'", "'status':'PASS_SOURCE_CLOSURE_AND_EXPLICIT_REPLY_SENDER'")
a=s.index(",'same_gateway_scope_resumes'");b=s.index(",'native_UI_visual_review'",a);s=s[:a]+",'explicit_uniform_sender':'PASS','sender_nickname_projection':'PASS','stale_sender_preview':'PASS','single_account_change_requires_review':'PASS','batch_and_scope_regressions':'PASS','js_syntax':'PASS'"+s[b:];s=s.replace("'native_UI_visual_review':'PENDING_EXPLICIT_AUTOMATION_APPROVAL'", "'native_UI_visual_review':'NOT_RUN_PREVIOUS_AUTOMATION_APPROVAL_BLOCK'")
(T/'prepare_v39.py').write_text(s,encoding='utf-8')
s=(T.parent/'overnight-verification/round-17-task-resume/install_v38.py').read_text('utf-8').replace('v38','v39');(T/'install_v39.py').write_text(s,encoding='utf-8')
