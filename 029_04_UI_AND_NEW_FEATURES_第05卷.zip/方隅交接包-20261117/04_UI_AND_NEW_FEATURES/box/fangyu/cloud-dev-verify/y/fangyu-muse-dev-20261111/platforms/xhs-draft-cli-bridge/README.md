# 新草稿接独立 CLI：固定预览候选

此目录对既有草稿和账本做只读快照，生成供人工复核的预览，不会访问小红书或发送。`preview/` 是首次运行时的固定快照；分析仍在进行，后续结果不会自动加入。

2026-10-29 01:21 快照：101 条高或超高意向草稿匹配本地账本；4 条暂缓，14 条未能与账本精确匹配，均未纳入。原 CLI 的 `prepare` 和只读 `preview` 实际通过，显示 101 条待处理。100% 评论者地区和当前需求仍待核；回复统一称“方隅公寓”。这不是全部已采评论的分析结果，也不是发送授权。

原 CLI 默认菜单仍引用旧的草稿和旧会话。当前蕾姆账号已通过独立采集会话核实，但本候选没有修改菜单，也没有测试该新会话的真实发送。只读账本发现该账号另有 1 条发送结果未知；现有发送器会在账号级别阻止后续发送，须先凭真实证据核对，不能自动重发或修改未知状态。

原 CLI 的预览（不会发送）可以在项目根目录运行：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -X utf8 'work/xhs-cli-standalone-entry/standalone_cli.py' --project-root (Get-Location).Path --batch 'work/xhs-draft-cli-bridge/preview/prepared.json' --source-manifest 'work/xhs-draft-cli-bridge/preview/source-manifest.json' preview
```

供人阅读的 CSV 在项目 `outputs/高意向回复审核/`。`preview/report.json`、来源快照、排除原因及逐条待核项供后续开发核查。新批次应单独创建新快照并核对账本与来源，不覆盖已审核的现有快照。任何实际发送须先核对身份、历史及用户希望使用的具体批次；不得把本地预览当作平台发送或可见性验证。
