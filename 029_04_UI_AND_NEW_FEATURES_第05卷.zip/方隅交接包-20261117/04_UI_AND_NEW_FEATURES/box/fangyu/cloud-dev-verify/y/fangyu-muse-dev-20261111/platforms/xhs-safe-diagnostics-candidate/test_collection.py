import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx

import collector


def note(note_id='n1', token='secret-token', title='古北租房'):
    return {'id': note_id, 'xsec_token': token, 'note_card': {'display_title': title}}


def comment(cid, uid, text):
    return {'id': cid, 'content': text, 'user_info': {'user_id': uid}, 'create_time': 1793150000000}


class FakeClient:
    def __init__(self, pages=None, error=None, account='sender', notes=None):
        self.pages = pages or {}
        self.error = error
        self.account = account
        self.notes = notes or [note()]
        self.calls = []

    def get_self_info(self):
        self.calls.append(('identity',))
        return {'user_id': self.account}

    def search_notes(self, **kwargs):
        self.calls.append(('search', kwargs['keyword']))
        return {'items': self.notes}

    def get_comments(self, note_id, **kwargs):
        self.calls.append(('comments', note_id))
        if self.error:
            raise self.error
        value = self.pages[note_id]
        if isinstance(value, Exception):
            raise value
        return value


class CollectionTests(unittest.TestCase):
    def test_identity_checked_before_search_and_rejects_wrong_account(self):
        client = FakeClient(account='other')
        with self.assertRaises(collector.Halt):
            collector.collect(client, 'sender', '古北租房', {}, max_notes=1, max_pages=1)
        self.assertEqual(client.calls, [('identity',)])

    def test_one_person_multiple_comments_grouped_source_and_no_token(self):
        client = FakeClient({'n1': {'comments': [comment('c1','u1','求租'), comment('c2','u1','预算')], 'has_more': False}})
        result = collector.collect(client, 'sender', '古北租房', {'u1':'old-customer'}, max_notes=1, max_pages=1)
        self.assertEqual(len(result['customers']), 1)
        self.assertEqual(result['customers'][0]['customer_id'], 'old-customer')
        self.assertEqual(len(result['customers'][0]['other_comments']), 1)
        self.assertEqual(result['customers'][0]['post_title'], '古北租房')
        self.assertNotIn('secret-token', json.dumps(result, ensure_ascii=False))
        self.assertIn('post_body_missing', result['customers'][0]['missing_context'])

    def test_duplicate_comment_is_deduplicated_and_conflicting_owners_excluded(self):
        client = FakeClient({'n1': {'comments':[comment('c1','u1','求租'),comment('c1','u1','求租'),comment('c2','u2','问价'),comment('c2','u3','问价')], 'has_more':False}})
        result = collector.collect(client, 'sender', '古北租房', {}, max_notes=1, max_pages=1)
        self.assertEqual(result['summary']['duplicate_observations'], 1)
        self.assertEqual(result['summary']['conflicted_comments'], 1)
        self.assertEqual(result['summary']['usable_comments'], 1)

    def test_missing_user_or_text_marked_pending_not_guessed(self):
        client = FakeClient({'n1': {'comments':[comment('c1','','求租'),comment('c2','u2','')], 'has_more':False}})
        result = collector.collect(client, 'sender', '古北租房', {}, max_notes=1, max_pages=1)
        self.assertEqual(result['summary']['pending'], 2)
        self.assertEqual(result['summary']['usable_comments'], 0)

    def test_conflicting_existing_identity_is_not_assigned_new_customer(self):
        client = FakeClient({'n1': {'comments':[comment('c1','u1','求租')], 'has_more':False}})
        result = collector.collect(client, 'sender', '古北租房', {'u1': None}, max_notes=1, max_pages=1)
        self.assertEqual(result['summary']['pending'], 1)
        self.assertEqual(result['summary']['usable_comments'], 0)

    def test_unresolved_existing_members_block_uid_from_becoming_new_identity(self):
        customers=[{'platform':'xiaohongshu','platform_uid':None,'customer_id':'old','issues':['missing_member'],
                    'comments':[{'author_uid':'u1'}]}]
        mapping=collector.index_identities(customers)
        self.assertIn('u1',mapping)
        self.assertIsNone(mapping['u1'])

    def test_other_platform_identity_is_never_used_for_xhs_mapping(self):
        mapping=collector.index_identities([{'platform':'douyin','platform_uid':'u1','customer_id':'dy-person',
                                             'comments':[{'author_uid':'u1'}]}])
        self.assertNotIn('u1',mapping)

    def test_ledger_uid_observations_are_merged_without_overwriting_conflicts(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            import sqlite3
            from contextlib import closing
            ledger=Path(tmp)/'fixture.sqlite3'
            with closing(sqlite3.connect(ledger)) as db:
                db.executescript('''
                    CREATE TABLE identity_aliases(platform,alias,canonical);
                    CREATE TABLE collection_uid_observations(platform TEXT NOT NULL,platform_uid TEXT NOT NULL,canonical TEXT NOT NULL,basis TEXT NOT NULL,source TEXT NOT NULL,observed_at INTEGER NOT NULL,PRIMARY KEY(platform,platform_uid),UNIQUE(platform,canonical));
                    CREATE TABLE reservations(token,platform,customer,status);
                    CREATE TABLE local_sender_plans(token,data);
                ''')
                db.execute("INSERT INTO collection_uid_observations VALUES('xiaohongshu','u1','old','local_source_consistency_only','fixture',1)")
                db.execute("INSERT INTO collection_uid_observations VALUES('douyin','u2','dy-old','local_source_consistency_only','fixture',1)")
                db.commit()
            result=collector.merge_ledger_identity_map({'u1':'different'},ledger)
            self.assertIsNone(result['u1'])
            self.assertNotIn('u2',result)

    def test_corrupt_observation_table_is_not_used(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            import sqlite3
            from contextlib import closing
            ledger=Path(tmp)/'fixture.sqlite3'
            with closing(sqlite3.connect(ledger)) as db:
                db.executescript('CREATE TABLE identity_aliases(platform,alias,canonical); CREATE TABLE collection_uid_observations(platform,platform_uid,canonical); CREATE TABLE reservations(token,platform,customer,status); CREATE TABLE local_sender_plans(token,data);')
                db.commit()
            with self.assertRaises(ValueError):collector.merge_ledger_identity_map({},ledger)

    def test_pagination_cap_marks_truncation_and_does_not_fetch_extra_page(self):
        client=FakeClient({'n1':{'comments':[comment('c1','u1','求租')],'has_more':True,'cursor':'next'}})
        result=collector.collect(client,'sender','古北租房',{},max_notes=1,max_pages=1)
        self.assertEqual(result['summary']['truncated_note_pages'],1)
        self.assertEqual([c[0] for c in client.calls].count('comments'),1)

    def test_expired_session_during_prewarm_does_not_fall_back_or_switch(self):
        calls=[]
        def respond(request):
            calls.append(request.url.path)
            return httpx.Response(200,request=request,json={'success':False,'code':-100})
        client=collector.ReadClient({'a1':'fake','web_session':'fake'},transport=httpx.MockTransport(respond),delay=0)
        with self.assertRaises(collector.Halt):
            client.search_notes('古北租房',page=1)
        client.close()
        self.assertEqual(len(calls),1)

    def test_oversized_customer_text_stays_pending_not_invalid_ai_input(self):
        client=FakeClient({'n1':{'comments':[comment('c1','u1','租' * 5001)],'has_more':False}})
        result=collector.collect(client,'sender','古北租房',{},max_notes=1,max_pages=1)
        self.assertEqual(result['summary']['pending'],1)
        self.assertEqual(result['summary']['usable_comments'],0)

    def test_oversized_comment_group_is_preserved_as_pending(self):
        observations=[{'customer_id':'old','customer_uid':'u1','comment_id':'c'+str(i),'note_id':'n1',
                       'comment_text':'求租','post_title':'古北租房','published_at':'',
                       'identity_evidence':'local_source_consistency_only'} for i in range(102)]
        result=collector.build_result(observations,[],'古北租房',1,0)
        self.assertEqual(result['summary']['customers'],0)
        self.assertEqual(result['summary']['pending'],1)
        self.assertEqual(len(result['pending'][0]['observations']),102)

    def test_challenge_stops_without_followup(self):
        client = FakeClient(error=collector.Halt('HTTP 461'))
        with self.assertRaises(collector.Halt):
            collector.collect(client, 'sender', '古北租房', {}, max_notes=1, max_pages=1)
        self.assertEqual([x[0] for x in client.calls], ['identity', 'search', 'comments'])

    def test_partial_results_survive_later_challenge_via_checkpoint(self):
        pages={'n1':{'comments':[comment('c1','u1','求租')],'has_more':False}, 'n2':collector.Halt('HTTP 461')}
        client=FakeClient(pages=pages, notes=[note('n1'),note('n2')])
        checkpoints=[]
        with self.assertRaises(collector.Halt):
            collector.collect(client,'sender','古北租房',{},max_notes=2,max_pages=1,on_progress=checkpoints.append)
        self.assertEqual(checkpoints[-1]['summary']['usable_comments'],1)
        self.assertNotIn('secret-token',json.dumps(checkpoints,ensure_ascii=False))

    def test_ai_input_shape_passes_current_pipeline_validator(self):
        client=FakeClient({'n1':{'comments':[comment('c1','u1','求租'),comment('c2','u1','预算')],'has_more':False}})
        result=collector.collect(client,'sender','古北租房',{'u1':'old'},max_notes=1,max_pages=1)
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'xhs-ai-standalone'))
        import pipeline
        self.assertEqual(pipeline.validate_records(result['customers']),result['customers'])

    def test_http_461_is_not_swallowed_by_vendor_search_prewarm(self):
        calls=[]
        def respond(request):
            calls.append(request.url.path)
            return httpx.Response(461, request=request)
        client=collector.ReadClient({'a1':'fake','web_session':'fake'}, transport=httpx.MockTransport(respond), delay=0)
        with self.assertRaises(collector.Halt):
            client.search_notes('古北租房', page=1)
        client.close()
        self.assertEqual(len(calls), 1)

    def test_unknown_and_post_endpoints_are_never_permitted(self):
        client=collector.ReadClient({'a1':'fake','web_session':'fake'}, transport=httpx.MockTransport(lambda req:httpx.Response(200,request=req)), delay=0)
        with self.assertRaises(collector.Halt):
            client._request_with_retry('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post')
        client.close()

    def test_allowed_read_endpoint_accepts_its_encoded_query(self):
        calls=[]
        client=collector.ReadClient({'a1':'fake','web_session':'fake'}, transport=httpx.MockTransport(lambda req:(calls.append(req.url.path) or httpx.Response(200,request=req))), delay=0)
        response=client._request_with_retry('GET','https://edith.xiaohongshu.com/api/sns/web/v2/comment/page?note_id=n1&cursor=')
        self.assertEqual(response.status_code,200)
        self.assertEqual(calls,['/api/sns/web/v2/comment/page'])
        client.close()

    def test_vendor_client_wire_reads_identity_search_and_comments_without_network(self):
        calls=[]
        def respond(request):
            path=request.url.path; calls.append(path)
            data={'user_id':'sender'} if path.endswith('/user/me') else (
                {'items':[note()]} if path.endswith('/search/notes') else (
                    {'comments':[comment('c1','u1','求租')],'has_more':False} if path.endswith('/comment/page') else {}))
            return httpx.Response(200,request=request,json={'success':True,'data':data})
        client=collector.ReadClient({'a1':'fake','web_session':'fake'},transport=httpx.MockTransport(respond),delay=0)
        with patch('xhs_cli.client_mixins.cache_note_context'), patch('xhs_cli.client_mixins.get_cached_note_context',return_value={}):
            result=collector.collect(client,'sender','古北租房',{},max_notes=1,max_pages=1)
        client.close()
        self.assertEqual(result['summary']['usable_comments'],1)
        self.assertEqual(calls[0],'/api/sns/web/v2/user/me')
        self.assertIn('/api/sns/web/v1/search/notes',calls)
        self.assertIn('/api/sns/web/v2/comment/page',calls)

    def test_cli_preview_no_session_and_no_network(self):
        with patch.object(collector,'ReadClient',side_effect=AssertionError('network must not start')):
            code=collector.main(['--keyword','古北租房','--output','unused'])
        self.assertEqual(code, 0)


if __name__ == '__main__': unittest.main()
