"""Export a plain-language review of the frozen, non-sending CLI preview."""
from datetime import datetime
from pathlib import Path
import csv
import json

ROOT=Path(__file__).resolve().parents[2]
SNAP=Path(__file__).resolve().parent/'preview'
OUTPUT=ROOT/'outputs/高意向回复审核'

def load(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def main():
    if OUTPUT.exists(): raise RuntimeError('Output already exists; preserve the previous user review')
    OUTPUT.mkdir(parents=True)
    records={}
    for file in sorted((SNAP/'sources').glob('source-*.json')):
        for record in load(file): records.setdefault(record.get('comment_id'),record)
    inputs=load(SNAP/'input.json')
    with (OUTPUT/'高意向回复草稿.csv').open('w',encoding='utf-8-sig',newline='') as f:
        columns=['客户评论','意向','评论时间','拟回复','地区','当前需求','审核状态']
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
        for item in inputs:
            record=records[item['comment_id']]
            date=record.get('date_display') or ''
            if not date and record.get('published_at'):
                try: date=datetime.fromisoformat(record['published_at'].replace('Z','+00:00')).astimezone().strftime('%Y年%m月%d日 %H:%M')
                except ValueError: date=''
            interest=record['source_analysis']['result']['interest']
            writer.writerow({'客户评论':record.get('comment_text',''), '意向':'超高' if interest=='super_high' else '高',
                             '评论时间':date or '未知', '拟回复':item['text'],
                             '地区':'客户本人找房地区待核' if not record.get('own_region_confirmed') else '客户本人提及地区',
                             '当前需求':'待核', '审核状态':'待审核'})
    (OUTPUT/'阅读说明.txt').write_text('这份表是一次固定时间的高意向草稿预览，供核对语气和客户原话。共101条，地区和当前需求均待核；没有自动发送。\n\n另有部分草稿暂缓或尚未匹配本地账本，未放进这份表。本次新采评论仍有分析未完成，因此这不是全部高意向客户名单。\n\n当前账号有一条历史回复结果尚未确认，现有发送程序会暂停并要求核对。草稿预览通过不代表可以直接发送。\n',encoding='utf-8')
    print(json.dumps({'review_rows':len(inputs),'platform_requests':0,'send':False},ensure_ascii=False))

if __name__=='__main__':main()
