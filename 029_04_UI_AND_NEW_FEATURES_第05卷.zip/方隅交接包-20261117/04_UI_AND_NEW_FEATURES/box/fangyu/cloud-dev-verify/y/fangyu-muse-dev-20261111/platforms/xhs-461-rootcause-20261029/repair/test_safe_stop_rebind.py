"""Synthetic-only behavior tests for the isolated safe-stop candidate."""
from contextlib import closing
import importlib.util
import json
import os
from pathlib import Path
import socket
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

import httpx

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.path.insert(0, str(PROJECT/'work/xhs-collection-candidate'))
import collector
from xhs_cli.constants import USER_AGENT

if os.environ.get('XHS_SAFE_STOP_BASELINE') == '1':
    # Explicit red run executes real original behavior before any implementation.
    ReadClient = collector.ReadClient
    SafeReadStop = collector.Halt
    def safe_stop_diagnostic(exc):
        return {}
else:
    from safe_stop_rebind import ReadClient, SafeReadStop, safe_stop_diagnostic

INITIAL = {'a1': 'a'*52, 'webId': 'SYNTHETIC-WEB-ID',
           'web_session': 'SYNTHETIC-INITIAL-DO-NOT-LOG'}
ROTATED = 'SYNTHETIC-ROTATED-DO-NOT-LOG'
SECRET = 'SYNTHETIC-VERIFY-UUID-DO-NOT-LOG'
IDENTITY = {'success': True, 'code': 0,
            'data': {'user_id': 'account-A', 'guest': False}}


def account_module():
    source = PROJECT/'work/xhs-account-switch-recovery-candidate/account_switch.py'
    spec = importlib.util.spec_from_file_location('safe_stop_original_account_guard', source)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    value.HERE = HERE  # private module object only, never the original source
    return value


def ledger(path):
    with closing(sqlite3.connect(path)) as db:
        db.executescript('''
            CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,
                comment TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,
                PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
            CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,
                customer TEXT,comment TEXT,status TEXT);
            CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,
                PRIMARY KEY(platform,alias));
            CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,delivery_state TEXT);
            CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL);
        ''')


class SafeStopTests(unittest.TestCase):
    def setUp(self):
        self.network_guard = patch.object(socket.socket, 'connect',
            side_effect=AssertionError('Network forbidden'))
        self.network_guard.start()
        (HERE/'runtime').mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=HERE/'runtime')
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()
        self.network_guard.stop()

    def client(self, *, status=200, headers=None, mutator=None, payload=None):
        requests = []
        def handler(request):
            requests.append(request)
            if mutator:
                mutator()
            return httpx.Response(status, headers=headers or {}, json=IDENTITY if payload is None else payload)
        client = ReadClient(dict(INITIAL), transport=httpx.MockTransport(handler), delay=0)
        self.addCleanup(client.close)
        return client, requests

    def halt(self, client, category):
        with self.assertRaises(SafeReadStop) as caught:
            client.get_self_info()
        detail = safe_stop_diagnostic(caught.exception)
        self.assertEqual(detail.get('category'), category)
        self.assertIs(detail.get('retry_allowed'), False)
        self.assertIs(detail.get('resume_automatically'), False)
        rendered = str(caught.exception) + json.dumps(detail) + json.dumps(client.last_failure_detail)
        for value in (*INITIAL.values(), ROTATED, SECRET, 'evil-type-'+SECRET):
            self.assertNotIn(value, rendered)
        return detail

    def test_normal_unchanged_identity_reads_keep_original_user_agent(self):
        client, requests = self.client()
        self.assertEqual(client.get_self_info(), IDENTITY['data'])
        self.assertEqual(client.get_self_info(), IDENTITY['data'])
        self.assertEqual(len(requests), 2)
        self.assertEqual({r.headers['user-agent'] for r in requests}, {USER_AGENT})
        self.assertEqual(client.cookies, INITIAL)

    def test_same_value_set_cookie_does_not_require_rebind(self):
        client, requests = self.client(headers={'set-cookie':
            'web_session='+INITIAL['web_session']+'; Domain=.xiaohongshu.com; Path=/'})
        client.get_self_info()
        client.get_self_info()
        self.assertEqual(len(requests), 2)
        self.assertEqual(client.cookies, INITIAL)

    def test_461_and_471_keep_unresolved_restriction_and_safe_header_presence(self):
        for status in (461, 471):
            with self.subTest(status=status):
                client, requests = self.client(status=status, headers={
                    'verifytype':'evil-type-'+SECRET, 'verifyuuid':SECRET})
                detail = self.halt(client, 'restriction_or_verification_required')
                self.assertEqual(detail['http_status'], status)
                self.assertIs(detail['verify_type_present'], True)
                self.assertIs(detail['verify_uuid_present'], True)
                self.halt(client, 'restriction_or_verification_required')
                self.assertEqual(len(requests), 1)

    def test_461_without_verification_headers_does_not_invent_a_challenge(self):
        client, requests = self.client(status=461)
        detail = self.halt(client, 'restriction_or_verification_required')
        self.assertIs(detail['verify_type_present'], False)
        self.assertIs(detail['verify_uuid_present'], False)
        self.assertNotIn('captcha', json.dumps(detail))
        self.assertNotIn('rate_limited', json.dumps(detail))
        self.assertEqual(len(requests), 1)

    def test_461_with_cookie_update_keeps_461_as_primary_failure(self):
        client, requests = self.client(status=461, headers={'set-cookie':
            'web_session='+ROTATED+'; Domain=.xiaohongshu.com; Path=/'})
        detail = self.halt(client, 'restriction_or_verification_required')
        self.assertEqual(detail['http_status'], 461)
        self.assertEqual(client.cookies, INITIAL)
        self.assertEqual(len(requests), 1)

    def test_200_session_rotation_stops_current_read_and_locks_next_request(self):
        client, requests = self.client(headers={'set-cookie':
            'web_session='+ROTATED+'; Domain=.xiaohongshu.com; Path=/'})
        detail = self.halt(client, 'session_update_requires_rebind')
        self.assertIs(detail['server_cookie_update_present'], True)
        self.assertEqual(client.cookies, INITIAL)
        self.halt(client, 'session_update_requires_rebind')
        self.assertEqual(len(requests), 1)

    def test_new_non_auth_cookie_also_requires_explicit_rebind(self):
        client, requests = self.client(headers={'set-cookie':
            'acw_tc='+ROTATED+'; Domain=.xiaohongshu.com; Path=/'})
        self.halt(client, 'session_update_requires_rebind')
        self.assertNotIn('acw_tc', client.cookies)
        self.assertEqual(len(requests), 1)

    def test_cookie_deletion_and_expiry_are_not_ignored_as_empty_updates(self):
        for cookie in (
            'web_session=; Domain=.xiaohongshu.com; Path=/',
            'web_session='+ROTATED+'; Domain=.xiaohongshu.com; Path=/; Max-Age=0',
            'web_session='+ROTATED+'; Domain=.xiaohongshu.com; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT',
        ):
            with self.subTest(cookie_kind=cookie.split(';')[-1].split('=')[0]):
                client, requests = self.client(headers={'set-cookie':cookie})
                self.halt(client, 'session_update_requires_rebind')
                self.assertEqual(client.cookies, INITIAL)
                self.assertEqual(len(requests), 1)

    def test_invalid_domain_or_scoped_path_is_never_accepted_into_session(self):
        for attributes in ('Domain=.evil.example; Path=/',
                           'Domain=www.xiaohongshu.com; Path=/',
                           'Domain=.xiaohongshu.com; Path=/private',
                           'Domain=.xiaohongshu.com; Path=/api/sns/web/v2/user'):
            with self.subTest(attributes=attributes):
                client, requests = self.client(headers={'set-cookie':'web_session='+ROTATED+'; '+attributes})
                self.halt(client, 'cookie_update_requires_review')
                self.assertEqual(client.cookies, INITIAL)
                self.assertEqual(len(requests), 1)

    def test_malformed_cookie_stops_conservatively(self):
        client, requests = self.client(headers={'set-cookie':'not a cookie '+SECRET})
        self.halt(client, 'cookie_update_requires_review')
        self.assertEqual(len(requests), 1)

    def test_external_memory_mutation_is_rejected_before_network(self):
        client, requests = self.client()
        client.cookies['web_session'] = ROTATED
        self.halt(client, 'session_changed_no_retry')
        self.assertEqual(requests, [])

    def test_external_memory_mutation_during_request_is_not_merged_away(self):
        holder = {}
        client, requests = self.client(mutator=lambda:holder['client'].cookies.update(web_session=ROTATED))
        holder['client'] = client
        self.halt(client, 'session_changed_no_retry')
        self.assertEqual(len(requests), 1)

    def test_existing_file_guard_is_still_called_before_and_after_network(self):
        candidate = account_module()
        for during in (False, True):
            with self.subTest(during=during):
                source = self.root/('source-'+str(during)+'.json')
                source.write_text('synthetic-original-file', encoding='utf8')
                original = source.read_bytes()
                def guard():
                    if source.read_bytes() != original:
                        raise candidate.Refused('independent_session_file_changed')
                mutation = lambda:source.write_text('synthetic-replaced-file', encoding='utf8')
                client, requests = self.client(mutator=mutation if during else None)
                client._independent_session_guard = guard
                if not during:
                    mutation()
                self.halt(client, 'independent_session_file_changed')
                self.assertEqual(len(requests), int(during))

    def test_timeout_started_one_request_and_stays_locked(self):
        calls = []
        def handler(request):
            calls.append(request)
            raise httpx.ReadTimeout(SECRET, request=request)
        client = ReadClient(dict(INITIAL), transport=httpx.MockTransport(handler), delay=0)
        self.addCleanup(client.close)
        detail = self.halt(client, 'request_failed_no_retry')
        self.assertIs(detail['request_started'], True)
        self.halt(client, 'request_failed_no_retry')
        self.assertEqual(len(calls), 1)

    def test_local_rejection_never_claims_transport_started(self):
        client, calls = self.client()
        with self.assertRaises(SafeReadStop) as caught:
            client._request_with_retry('DELETE', 'https://example.invalid/'+SECRET)
        self.assertIs(safe_stop_diagnostic(caught.exception)['request_started'], False)
        self.assertEqual(calls, [])

    def test_200_platform_api_errors_keep_existing_safe_error_fields(self):
        for code, expected_type in ((-100, 'SessionExpiredError'), (300013, 'XhsApiError')):
            with self.subTest(code=code):
                client, calls = self.client(payload={
                    'success':False, 'code':code, 'msg':SECRET, 'data':None})
                detail = self.halt(client, 'request_failed_no_retry')
                self.assertEqual(detail['http_status'], 200)
                self.assertEqual(detail['error_type'], expected_type)
                self.assertEqual(detail['api_code'], code)
                if code == 300013:
                    self.assertEqual(detail['success_type'], 'boolean')
                    self.assertEqual(detail['prewarm_conditions']['message_signal_categories'], ['other'])
                self.halt(client, 'request_failed_no_retry')
                self.assertEqual(len(calls), 1)

    def test_old_batch_guard_stops_before_registration_and_unrelated_fixture_stays_unchanged(self):
        candidate = account_module()
        database = self.root/'ledger.sqlite3'
        ledger(database)
        source = self.root/'source.sqlite3'
        source.write_bytes(b'synthetic')
        checkpoint = self.root/'checkpoint.json'
        checkpoint.write_text('{"registered":2755,"cursor":"original-synthetic"}', encoding='utf8')
        before = checkpoint.read_bytes()
        client, requests = self.client(headers={'set-cookie':
            'web_session='+ROTATED+'; Domain=.xiaohongshu.com; Path=/'})
        with self.assertRaises(candidate.Refused):
            candidate.run_batch(workspace=self.root, batch_name='stopped', client=client,
                ledger=database, source_db=source, keyword='synthetic keyword', search_page=1,
                task='synthetic test', identity_loader=lambda *_:{})
        with closing(sqlite3.connect(database)) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM leads').fetchone()[0], 0)
        self.assertEqual(checkpoint.read_bytes(), before)
        self.assertFalse((self.root/'stopped/account-binding.json').exists())
        self.assertFalse((self.root/'stopped/register-result.json').exists())
        self.assertEqual(len(requests), 1)


if __name__ == '__main__':
    unittest.main()
