"""One identity/read-only search diagnostic; no retries, comments or ledger writes."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
SESSION = ROOT / 'work/xhs-standalone-session/cli-login-20261028-165417'
os.environ['HOME'] = str(SESSION)
os.environ['USERPROFILE'] = str(SESSION)
sys.path.insert(0, str(ROOT / 'work/xhs-standalone-reply'))
import collector
from standalone_reply import load_independent_cookies


def main():
    out = ROOT / 'work/xhs-collection-candidate/work/message-diagnostic-20261028-h'
    out.mkdir(exist_ok=False)
    checkpoint = json.loads((ROOT / 'work/xhs-collection-candidate/work/gubei-continue-20261028-a/new-ai-review/checkpoint.json').read_text(encoding='utf8'))
    expected = checkpoint['sender_uid']
    state = {'identity': 'not_checked', 'search': 'not_started', 'requests': [], 'send': False}
    class DiagnosticClient(collector.ReadClient):
        def _request_with_retry(self, method, url, **kwargs):
            try:
                return super()._request_with_retry(method, url, **kwargs)
            finally:
                state['requests'].append(self._last_endpoint_kind)
    client = DiagnosticClient(load_independent_cookies(SESSION))
    try:
        collector.verify_identity(client, expected)
        state['identity'] = 'authenticated_expected_account'
        state['search'] = 'started'
        result = client.search_notes(keyword='古北找房', page=1)
        state['search'] = 'success'
        state['search_item_count'] = len(result.get('items', [])) if isinstance(result, dict) else None
    except collector.Halt:
        state['search'] = 'stopped' if state['search'] == 'started' else 'not_started'
        state['failure'] = client.last_failure_detail or {'reason': 'unclassified_failure'}
    finally:
        client.close()
        collector.write_json(out / 'state.json', state)
    print(json.dumps(state, ensure_ascii=False))


if __name__ == '__main__':
    main()
