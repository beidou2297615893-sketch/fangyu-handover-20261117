﻿import sqlite3, unittest, sys
_orig = sqlite3.connect
class C:
    def __init__(s, c): s._c = c
    def __getattr__(s, n): return getattr(s._c, n)
    def __enter__(s): s._c.__enter__(); return s
    def __exit__(s, *a):
        r = s._c.__exit__(*a); s._c.close(); return r
def connect(*a, **k): return C(_orig(*a, **k))
sqlite3.connect = connect
sys.argv = ['x', 'discover', '-s', 'tests', '-v']
unittest.main(module=None)
