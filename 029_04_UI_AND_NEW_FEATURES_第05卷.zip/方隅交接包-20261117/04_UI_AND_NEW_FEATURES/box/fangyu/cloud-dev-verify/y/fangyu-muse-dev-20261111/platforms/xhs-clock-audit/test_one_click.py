import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from contextlib import closing
import subprocess
import sys
import time

import one_click
from test_pipeline import record,answer


class TestOneClick(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent);self.root=Path(self.temp.name)
        self.db=self.root/'ledger.sqlite3'
        with closing(sqlite3.connect(self.db)) as c:
            c.executescript('CREATE TABLE reservations(token TEXT,platform TEXT,customer TEXT,comment TEXT,status TEXT); CREATE TABLE local_sender_plans(token TEXT,data TEXT); CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,comment TEXT,delivery_state TEXT); CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT);')
            c.commit()
    def tearDown(self):self.temp.cleanup()

    def test_same_uid_across_different_internal_key_is_excluded(self):
        with closing(sqlite3.connect(self.db)) as c:
            c.execute('INSERT INTO reservations VALUES(?,?,?,?,?)',('a','xiaohongshu','old','oldcomment','unknown'))
            c.execute('INSERT INTO local_sender_plans VALUES(?,?)',('a',json.dumps({'plan':{'customer_uid':'uid1'}})))
            c.commit()
        selected,skipped=one_click.filter_unattempted([record()],self.db)
        self.assertEqual(selected,[]);self.assertEqual(skipped[0]['reason'],'known_local_history')

    def test_unknown_legacy_reservation_fails_closed(self):
        with closing(sqlite3.connect(self.db)) as c:
            c.execute('INSERT INTO reservations VALUES(?,?,?,?,?)',('a','xiaohongshu','old','oldcomment','unknown'))
            c.commit()
        with self.assertRaises(one_click.WorkflowError):one_click.filter_unattempted([record()],self.db)

    def test_missing_model_key_prevents_sender_call(self):
        called=[]
        with self.assertRaises(one_click.WorkflowError):
            one_click.run_workflow(input_path=self.root/'none',output_dir=self.root/'out',ledger=self.db,
                sender_uid='sender',account={},samples=[],provider=None,send=lambda *a:called.append(a),execute=True)
        self.assertFalse(called)

    def test_analysis_finishes_before_sender_receives_batch(self):
        class Fake:
            model='fake'
            def analyze(self,row,*args):return answer(reply='看看方隅公寓吧')
        input_path=self.root/'input.json';input_path.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        called=[]
        result=one_click.run_workflow(input_path=input_path,output_dir=self.root/'out',ledger=self.db,
                sender_uid='sender',account={},samples=[],provider=Fake(),send=lambda *a:called.append(a),execute=True)
        self.assertEqual(len(called),1);self.assertEqual(result['selected'],1)
        self.assertEqual(json.loads((self.root/'out'/'analysis'/'batch.json').read_text(encoding='utf8'))['count'],1)

    def test_model_failure_never_invokes_sender(self):
        class Fake:
            model='fake'
            def analyze(self,*args):raise RuntimeError('offline')
        input_path=self.root/'input.json';input_path.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        called=[]
        with self.assertRaises(RuntimeError):one_click.run_workflow(input_path=input_path,output_dir=self.root/'out',ledger=self.db,
                sender_uid='sender',account={},samples=[],provider=Fake(),send=lambda *a:called.append(a),execute=True)
        self.assertFalse(called)

    def test_completed_draft_can_resume_without_recalling_model(self):
        class Fake:
            model='fake'
            def __init__(self):self.calls=0
            def analyze(self,row,*args):self.calls+=1;return answer(reply='看看方隅公寓吧')
        src=self.root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        provider=Fake()
        def interrupted(*args):raise one_click.WorkflowError('stopped')
        with self.assertRaises(one_click.WorkflowError):one_click.run_workflow(input_path=src,output_dir=self.root/'out',ledger=self.db,
            sender_uid='sender',account={},samples=[],provider=provider,send=interrupted,execute=True)
        called=[]
        one_click.run_workflow(input_path=src,output_dir=self.root/'out',ledger=self.db,sender_uid='sender',account={},samples=[],
                              provider=provider,send=lambda *args:called.append(args),execute=True)
        self.assertEqual(provider.calls,1);self.assertEqual(len(called),1)

    def test_real_subprocesses_exclude_same_account_but_not_another(self):
        script='''
import sys,time
from pathlib import Path
import one_click
locks=Path(sys.argv[1]);account=sys.argv[2];ready=Path(sys.argv[3]);release=Path(sys.argv[4])
try:
 with one_click.WorkflowLock(locks,account):
  ready.write_text('ready',encoding='utf8')
  deadline=time.monotonic()+10
  while not release.exists() and time.monotonic()<deadline:time.sleep(.05)
except one_click.WorkflowError:sys.exit(7)
'''
        ready=self.root/'ready';release=self.root/'release';other_ready=self.root/'other-ready'
        holder=subprocess.Popen([sys.executable,'-X','utf8','-c',script,str(self.root/'locks'),'account1',str(ready),str(release)],cwd=Path(__file__).parent)
        try:
            end=time.monotonic()+5
            while not ready.exists() and time.monotonic()<end and holder.poll() is None:time.sleep(.05)
            self.assertTrue(ready.exists(),'first process failed to obtain account lock')
            same=subprocess.run([sys.executable,'-X','utf8','-c',script,str(self.root/'locks'),'account1',str(self.root/'same-ready'),str(release)],cwd=Path(__file__).parent,timeout=5)
            self.assertEqual(same.returncode,7)
            other=subprocess.Popen([sys.executable,'-X','utf8','-c',script,str(self.root/'locks'),'account2',str(other_ready),str(release)],cwd=Path(__file__).parent)
            try:
                end=time.monotonic()+5
                while not other_ready.exists() and time.monotonic()<end and other.poll() is None:time.sleep(.05)
                self.assertTrue(other_ready.exists(),'different account unexpectedly blocked')
            finally:
                release.write_text('release',encoding='utf8');other.wait(timeout=5)
        finally:
            release.write_text('release',encoding='utf8');holder.wait(timeout=5)
        self.assertEqual(holder.returncode,0)

    def test_workflow_holds_account_lock_through_sender(self):
        class Fake:
            model='fake'
            def analyze(self,row,*args):return answer(reply='看看方隅公寓吧')
        src=self.root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        old=one_click.LOCK_DIR;one_click.LOCK_DIR=self.root/'locks'
        try:
            def send(*args):
                script="import sys;from pathlib import Path;from one_click import WorkflowLock,WorkflowError\ntry:\n with WorkflowLock(Path(sys.argv[1]),'sender'):pass\nexcept WorkflowError:sys.exit(7)"
                other=subprocess.run([sys.executable,'-X','utf8','-c',script,str(one_click.LOCK_DIR)],cwd=Path(__file__).parent,timeout=5)
                self.assertEqual(other.returncode,7)
            one_click.run_workflow(input_path=src,output_dir=self.root/'out',ledger=self.db,sender_uid='sender',account={},samples=[],provider=Fake(),send=send,execute=True)
        finally:one_click.LOCK_DIR=old

    def test_workflow_excludes_same_checkpoint_for_different_account(self):
        class Fake:
            model='fake'
            def analyze(self,row,*args):return answer(reply='看看方隅公寓吧')
        src=self.root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        old=one_click.LOCK_DIR;one_click.LOCK_DIR=self.root/'locks'
        try:
            def send(*args):
                script="import sys;from pathlib import Path;from one_click import WorkflowLock,WorkflowError\ntry:\n with WorkflowLock(Path(sys.argv[1]),'checkpoint:'+str(Path(sys.argv[2]).resolve())):pass\nexcept WorkflowError:sys.exit(7)"
                other=subprocess.run([sys.executable,'-X','utf8','-c',script,str(one_click.LOCK_DIR),str(self.root/'out')],cwd=Path(__file__).parent,timeout=5)
                self.assertEqual(other.returncode,7)
            one_click.run_workflow(input_path=src,output_dir=self.root/'out',ledger=self.db,sender_uid='sender1',account={},samples=[],provider=Fake(),send=send,execute=True)
        finally:one_click.LOCK_DIR=old

    def test_workflow_releases_both_locks_on_sender_error(self):
        class Fake:
            model='fake'
            def analyze(self,row,*args):return answer(reply='看看方隅公寓吧')
        src=self.root/'input.json';src.write_text(json.dumps([record()],ensure_ascii=False),encoding='utf8')
        old=one_click.LOCK_DIR;one_click.LOCK_DIR=self.root/'locks'
        try:
            def send(*args):raise one_click.WorkflowError('synthetic transport error')
            with self.assertRaises(one_click.WorkflowError):
                one_click.run_workflow(input_path=src,output_dir=self.root/'out',ledger=self.db,sender_uid='sender',account={},samples=[],provider=Fake(),send=send,execute=True)
            with one_click.WorkflowLock(one_click.LOCK_DIR,'sender'), one_click.WorkflowLock(one_click.LOCK_DIR,'checkpoint:'+str((self.root/'out').resolve())):
                pass
        finally:one_click.LOCK_DIR=old

if __name__=='__main__':unittest.main()
