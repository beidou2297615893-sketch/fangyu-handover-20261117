const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..'), runtime=path.join(root,'work/runtime/douyin-bridge');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const {BridgeClient}=require(path.join(runtime,'lib/client/bridge-client'));
const client=new BridgeClient(read(path.join(root,'抖音自用采集台/data/bridge.json')).bridge);
(async()=>{try{
 const status=await client.status();
 const pages=(status.connections?.['douyin.com']||[]).filter(c=>c.alive);
 if(pages.some(c=>c.url.includes('/ucenter/security/')))throw Error('CURRENT_GATE:captcha');
 const found=[];
 for(const page of pages){
  const {assertPageReady}=require('./page_guard.cjs');
  await assertPageReady(client,page.id);
  const r=await client.call({site:'douyin.com',connId:page.id,timeout:10000,expression:`(async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include'});const d=await r.json();return {status_code:d.status_code,account_uid:d.user?.sec_uid,nickname:d.user?.nickname}})()`});
  if(r.ok&&r.connection===page.id&&r.value?.status_code===0&&r.value.account_uid)found.push({...r.value,connection_id:page.id});
 }
 if(!found.length)throw Error('未找到可用的已登录抖音连接');
 if(new Set(found.map(x=>x.account_uid)).size!==1)throw Error('检测到多个不同账号，请只保留本任务的抖音连接');
 console.log(JSON.stringify(found[0]));
}catch(e){console.log(JSON.stringify({error:e.message}));process.exitCode=1;}})();
