import dataclasses
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from candidate import Candidate, Binding, Refused, Unknown, IsolatedLedger


class CandidateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(self.temp.cleanup)
        self.ledger = IsolatedLedger(Path(self.temp.name) / 'test.sqlite3')
        self.binding = Binding('internal-1', 'platform-1', 'sender-1', 'note-1', 'comment-1', 'reviewed text', 'mapping evidence')
        self.ledger.seed(self.binding)
        self.guard = Candidate(self.ledger)

    def test_missing_mapping_never_reserves(self):
        for field in ('internal_id', 'platform_uid', 'mapping_evidence'):
            with self.assertRaises(Refused):
                self.guard.simulate(dataclasses.replace(self.binding, **{field: ''}), self.binding)
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'reviewed')

    def test_sender_body_and_target_are_bound_before_reserving(self):
        for field in ('sender_uid', 'text', 'platform_uid', 'note_id', 'comment_id', 'internal_id'):
            with self.assertRaises(Refused):
                self.guard.simulate(self.binding, dataclasses.replace(self.binding, **{field: 'changed'}))
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'reviewed')

    def test_success_uses_original_offline_runner_and_blocks_duplicate(self):
        self.assertEqual(self.guard.simulate(self.binding, self.binding), 'receipt_received')
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'sent')
        with self.assertRaises(Refused): self.guard.simulate(self.binding, self.binding)

    def test_only_literal_true_grant_can_reach_simulation(self):
        for grant in (False, 1, 'true', None, {}, []):
            with self.subTest(grant=grant):
                class BadLedger:
                    def reserve(self, *args): return {'granted': grant}
                with self.assertRaises(Refused): Candidate(BadLedger()).simulate(self.binding, self.binding)

    def test_timeout_is_unknown_and_blocks_next_attempt(self):
        with self.assertRaises(Unknown): self.guard.simulate(self.binding, self.binding, fault='timeout')
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'unknown')
        with self.assertRaises(Refused): self.guard.simulate(self.binding, self.binding)

    def test_failure_after_reserve_keeps_blocked(self):
        with self.assertRaises(Unknown): self.guard.simulate(self.binding, self.binding, fault='before_runner')
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'unknown')
        with self.assertRaises(Refused): self.guard.simulate(self.binding, self.binding)

    def test_concurrent_attempts_have_one_winner(self):
        def attempt(_):
            try: return self.guard.simulate(self.binding, self.binding)
            except Refused: return 'refused'
        with ThreadPoolExecutor(max_workers=4) as pool: results = list(pool.map(attempt, range(4)))
        self.assertEqual(results.count('receipt_received'), 1)
        self.assertEqual(results.count('refused'), 3)

    def test_no_live_send_entry(self):
        with self.assertRaises(Refused): self.guard.send(self.binding, self.binding)
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'reviewed')

    def test_all_other_comments_must_be_reviewed(self):
        self.ledger._run('lead', 'xiaohongshu', self.binding.internal_id, 'comment-2')
        with self.assertRaises(Refused): self.guard.simulate(self.binding, self.binding)
        self.assertEqual(self.ledger.check(self.binding)['target']['status'], 'reviewed')
        self.ledger._run('review', 'xiaohongshu', self.binding.internal_id, 'comment-2',
                         'OFFLINE TEST', 'SYNTHETIC individually checked second comment')
        self.assertEqual(self.guard.simulate(self.binding, self.binding), 'receipt_received')

    def test_unknown_blocks_another_comment_for_same_customer(self):
        other = dataclasses.replace(self.binding, comment_id='comment-2')
        self.ledger.seed(other)
        with self.assertRaises(Unknown): self.guard.simulate(self.binding, self.binding, fault='timeout')
        with self.assertRaises(Refused): self.guard.simulate(other, other)

    def test_mapping_is_canonical_in_real_ledger(self):
        self.assertEqual(self.ledger.check(self.binding)['target']['customer'], 'internal-1')


if __name__ == '__main__': unittest.main()
