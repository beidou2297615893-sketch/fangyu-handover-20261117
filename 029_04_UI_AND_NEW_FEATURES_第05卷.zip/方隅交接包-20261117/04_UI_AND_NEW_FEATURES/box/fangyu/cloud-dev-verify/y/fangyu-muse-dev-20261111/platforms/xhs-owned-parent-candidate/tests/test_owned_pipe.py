import socket
import tempfile
import unittest
from unittest.mock import patch
from support import Fixture,ROOT,policy,bridge

class OwnedPipeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=ROOT/'tests');self.addCleanup(self.temp.cleanup)
        for method in ('connect','connect_ex'):
            p=patch.object(socket.socket,method,side_effect=AssertionError('network prohibited'));p.start();self.addCleanup(p.stop)
    def fixture(self,**kwargs):return Fixture(self.temp.name,**kwargs)
    def test_real_parent_pipe_to_original_serve_yields_one_exact_reply(self):
        f=self.fixture();result=f.send()
        self.assertEqual(result['platformCommentId'],'receipt')
        self.assertEqual(f.wires(),['GET','POST','CLOSE'])
        with self.assertRaises(RuntimeError):f.send()
        self.assertEqual(f.wires().count('POST'),1)
    def test_no_original_context_cannot_enter_bridge(self):
        f=self.fixture()
        with self.assertRaises(policy.ReplyPolicyError):bridge.transport(f.decision,{},lambda *a:None)
        self.assertEqual(f.wires(),[])
    def test_live_permission_revocation_after_mint_is_rejected(self):
        f=self.fixture();f.lease=False
        with self.assertRaises(ValueError):f.send()
        self.assertEqual(f.wires(),[])
    def test_approved_body_change_is_rejected(self):
        f=self.fixture();f.reply['text']='不同正文'
        with self.assertRaises(ValueError):f.send()
        self.assertEqual(f.wires(),[])
    def test_unconfirmed_reply_is_unknown_and_original_budget_blocks_retry(self):
        f=self.fixture(fault='timeout')
        with self.assertRaises(RuntimeError):f.send()
        with self.assertRaises(Exception):f.send()
        self.assertEqual(f.wires().count('POST'),1)
    def test_original_parent_rejects_corrupted_nonce_and_stage(self):
        for fault in ('invalid_nonce','invalid_stage'):
            with self.subTest(fault=fault),tempfile.TemporaryDirectory(dir=ROOT/'tests') as directory:
                f=Fixture(directory,fault=fault)
                with self.assertRaises(Exception):f.send()
                self.assertNotIn('GET',f.wires())
                self.assertNotIn('POST',f.wires())

if __name__=='__main__':unittest.main()
