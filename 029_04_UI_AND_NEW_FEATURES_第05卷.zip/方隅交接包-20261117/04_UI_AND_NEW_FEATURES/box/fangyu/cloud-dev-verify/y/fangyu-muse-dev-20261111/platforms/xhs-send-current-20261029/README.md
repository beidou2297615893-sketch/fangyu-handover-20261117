# 当前批次受管单次回复客户端

本目录仅补发送客户端会话处理，未启动真实平台请求，未读真实凭据，未写共享账本。主任务的 input.json、source-manifest.json 和 frozen-source 由主任务准备，本适配器没有改这些资料。

## 接入

```python
from managed_send_client import make_client
# sender_module = existing_cli.load_sender(project_root, ledger, batch_path, source_files)
client = make_client(sender_module, private_session_home / '.xiaohongshu-cli/cookies.json', plan)
try:
    result = sender_module.Runner(shared_ledger, client).submit(plan)
finally:
    client.close()
```

`plan`仍由原Sender的SendPlan和原批次校验生成。本目录不生成授权、不补假review、不清除历史阻断，不改Runner的预留、账号锁和结果记录。原发送器返回receipt_received_unverified时仍只代表平台受理回执，公开可见性必须由主任务独立回读，不能直接报发送成功或自动重发。

客户端继承实际production_sender.OneAttemptClient，所有POST仍通过原精确端点、目标评论、正文、5分钟有效期、armed、身份和单POST检查。正常身份GET成功后要求同UID、显式guest=false；正常acw_tc更新复用已审ManagedClient的字段、域、路径、删除和过期校验以及原子保存。只有此传输字段变化时接受保存；其他认证或设备字段变化一律停止，交主任务正常重登/重新准备，不在发送器内尝试隐式刷新。

从显式会话文件加载，不改HOME/USERPROFILE，不读其他浏览器。会话原始路径/父目录链接、文件哈希和内存变化均检查；失败后锁定客户端。保存复用已审atomic_write，即在独占前提下保存前后哈希检查+原子替换，不是对不合作写入者的OS级CAS。

调用者必须事先建立私有ACL受控的专属会话目录并确保没有其他写入者；本目录不修改已有目录权限。适配器只加载会话JSON里的字符串字段，凭据值不写诊断。固定本地停止原因可读client.last_managed_stop，Cookie审查类别可读client.last_cookie_review，不要记录或打印原响应、原Cookie头或异常链原文。生产Sender自身的HTTP/unknown诊断仍保留。

## 离线验证

运行：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest discover -s 'work/xhs-send-current-20261029' -v
```

10项通过：acw_tc保存并用于原精确POST；游客/不同UID拒绝；认证cookie变化停止；文件替换停止；保存失败停止；461单请求停止；POST超时仅一次；改笔记/目标评论/正文被原wire guard拒绝；非布尔success或缺guest拒绝；原Runner+合成SQLite的预留与平台receipt仍记unknown并禁止重复。

TDD证据：初版直接复用原OneAttemptClient的基线8测出现5个断言失败，复现遗漏合并/保存、guest校验及文件变更保护；修复后8测通过。新增身份响应边界先出现success=1绕过的断言失败，再修复通过。最后追加原Runner兼容性测试，10测全过。测试仅httpx.MockTransport，socket.connect被禁止；SQLite只在本目录临时合成库内运行，测试清理完成。

尚未验收：真实新账号会话形状、真实POST与公开回读。不得把这些离线结果当作平台限制已解除或真实发送完成。

## 独立回读客户端（仅离线验收）

`readback_client.py` 复用已审受管会话，白名单仅身份、普通评论、子评论三个正常 GET。不会发送评论；没有 get_all_comments、网页或隐式 token 回退。缺少显式原笔记 token 在身份请求前拒绝；首次读取自动检查指定 UID 且 guest=false。会话文件、Cookie 更新与锁停仍由 ManagedClient 处理。

```python
from readback_client import ReadbackClient, match_receipt
client = ReadbackClient(session_path, expected_uid, min_delay=2)
try:
    for page in client.iter_subcomment_pages(note_id, root_comment_id, xsec_token,
                                            cursor='', num=30, max_pages=20):
        for comment in page['comments']:
            result = match_receipt(comment, reply_id=receipt_reply_id,
                                   sender_uid=expected_uid,
                                   root_comment_id=root_comment_id, text=approved_text)
            # Only result['status'] == 'verified' establishes the exact match.
finally:
    client.close()
```

也可单页 `client.read_subcomments(note_id, root_comment_id, xsec_token, cursor='', num=30)`；普通评论 `client.get_comments(note_id, xsec_token=xsec_token)`。不要记录 token、Cookie 或异常原文；故障只取 `client.diagnostic(exc)` 的脱敏信息。子评论错误归为 comments，另有 read_kind=subcomments。461/429/-100 后锁停，没有自动重试。

纯函数匹配要求回复 ID、发送 UID、根目标关系、正文四项逐字相同且无字段冲突，缺失或不符均 unknown。未看见不等于未发送。分页只在 has_more=false 正常结束；游标重复、缺失、响应形状未知或页数上限会明确停止。调用者保留已得到的页面和 unknown 状态，不据此重发。

本次新增 10 项回读测试，先用未补白名单/身份/参数校验的基线复现 7 项失败、3 项错误，再修复。最终发送 10 项与回读 10 项共 20 项全通过，最新证据 green-all.txt；均用合成会话与 MockTransport，socket.connect 禁止。readback-verification.json 独立记录本次文件和依赖哈希。原发送适配器的验证文件和冻结输入未改动；真实登录、平台回读及公开可见性仍由主任务单独验收。
