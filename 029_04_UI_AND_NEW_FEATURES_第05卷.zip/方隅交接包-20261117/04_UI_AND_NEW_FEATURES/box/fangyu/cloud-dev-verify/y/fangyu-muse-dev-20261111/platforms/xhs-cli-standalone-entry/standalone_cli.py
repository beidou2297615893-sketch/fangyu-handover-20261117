"""Standalone entry for an existing local Xiaohongshu reply workspace.

Preview/status never contact the platform. Sending requires an explicit run
with --execute. The existing controlled sender and one shared ledger are used.
"""
import argparse
from contextlib import closing
from dataclasses import asdict
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time
import uuid


class Halt(RuntimeError):
    pass


def load_batch(path):
    batch = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    rows = batch.get('rows') if isinstance(batch, dict) else None
    if not isinstance(rows, list) or batch.get('count') != len(rows):
        raise Halt('批次格式或数量不一致')
    tokens = [r.get('attempt_id') for r in rows if isinstance(r, dict)]
    if len(tokens) != len(rows) or not all(isinstance(x, str) and x for x in tokens) or len(set(tokens)) != len(tokens):
        raise Halt('批次尝试标识缺失或重复')
    return batch


def ledger_states(path):
    path = Path(path).resolve(strict=True)
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=2)) as db:
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')
        data = db.execute('SELECT r.token,r.platform,r.customer,r.comment,r.status,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token').fetchall()
        historical = db.execute("SELECT platform,customer,comment,delivery_state FROM historical_deliveries WHERE delivery_state<>'not_sent'").fetchall()
        unlinked = db.execute("SELECT l.platform,l.customer,l.comment,l.status FROM leads l LEFT JOIN reservations r ON r.platform=l.platform AND r.customer=l.customer AND r.comment=l.comment WHERE l.status IN ('unknown','reserved','sent') AND r.token IS NULL").fetchall()
        db.rollback()
    result = {'events':[], 'token':{}, 'comment':{}, 'customer':{}, 'uid':{}}
    def add(event):
        number=len(result['events']);result['events'].append(event)
        for key in ('token','comment','customer','uid'):
            value=event.get(key)
            if value:
                lookup=value if key=='token' else (event['platform'],value)
                result[key].setdefault(lookup,set()).add(number)
    for token, platform, customer, comment, status, payload in data:
        try:
            entry = json.loads(payload) if payload else {}
            outcome = entry.get('result') or {}
            plan = entry.get('plan') or {}
            if not isinstance(outcome,dict) or not isinstance(plan,dict): raise ValueError('invalid ledger plan')
        except (ValueError, TypeError, AttributeError):
            outcome = {};plan = {}
        state = 'accepted' if (status == 'unknown' and outcome.get('kind') == 'platform_receipt' and outcome.get('receipt_id')) or status == 'sent' else ('not_sent' if status=='not_sent' else 'blocked')
        if plan.get('canonical_customer') not in (None,customer) or plan.get('comment_id') not in (None,comment): state='blocked'
        add({'token':token,'platform':platform,'customer':customer,'comment':comment,
             'uid':plan.get('customer_uid'),'state':state})
    for platform,customer,comment,_ in historical+unlinked:
        add({'platform':platform,'customer':customer,'comment':comment,'state':'blocked'})
    return result


def row_state(row, states):
    token=row.get('attempt_id'); platform=row.get('platform','xiaohongshu')
    comment=row.get('comment_id'); customer=row.get('customer_id'); uid=row.get('customer_uid')
    if not all(isinstance(x,str) and x for x in (token,platform,comment,customer,uid)):
        return 'blocked'
    indices=set(states['token'].get(token,set()))
    for key,value in (('comment',comment),('customer',customer),('uid',uid)):
        indices.update(states[key].get((platform,value),set()))
    accepted=False
    for index in indices:
        event=states['events'][index]
        if event.get('state')=='not_sent' and event.get('token')!=token:
            continue
        # Only exact comment and both matching identity fields support an accepted claim.
        exact=(event.get('platform')==platform and event.get('comment')==comment and
               event.get('customer')==customer and event.get('uid')==uid)
        if exact and event.get('state')=='accepted':
            accepted=True
        else:
            return 'blocked'
    return 'accepted' if accepted else 'pending'


def planned_rows(batch, states):
    for row in batch['rows']:
        state = row_state(row, states)
        yield row, state


def source_manifest(path):
    path = Path(path).resolve(strict=True)
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict) or not data or not all(isinstance(k,str) and k and isinstance(v,str) and v for k,v in data.items()):
        raise Halt('来源文件清单必须是非空的名称到文件路径的 JSON 对象')
    return {k:(Path(v) if Path(v).is_absolute() else path.parent / v).resolve(strict=True) for k,v in data.items()}


def verify_prepared(plan, path, source_files, require_hashes=False):
    batch = load_batch(path)
    schema = batch.get('schema')
    if schema == 'xhs-local-plan-v1':
        if batch.get('intended_account_uid') != plan.sender_uid:
            raise Halt('批次指定的账号和当前账号不一致')
    elif schema == 'gubei-46-local-plan-v1':
        if batch.get('intended_account') != '蕾姆' or plan.sender_uid != '5aa9b337e8ac2b4ab2d21957':
            raise Halt('旧批次只适用于原来指定的账号')
    else:
        raise Halt('不支持的批次格式')
    matches = [r for r in batch['rows'] if r['attempt_id'] == plan.attempt_id]
    if len(matches) != 1:
        raise Halt('无法唯一对应目标')
    row = matches[0]
    expected = {'customer_id':plan.canonical_customer,'customer_uid':plan.customer_uid,
                'comment_id':plan.comment_id,'note_id':plan.note_id,'text':plan.text,
                'source_identity':'local_source_consistency_only', 'platform_reply_history':'unknown',
                'other_accounts_history':'unknown','send_status':'not_attempted_in_this_plan'}
    if any(row.get(k) != v for k,v in expected.items()):
        raise Halt('客户、评论或回复与批次不一致')
    if require_hashes:
        hashes = batch.get('source_sha256')
        if not isinstance(hashes,dict) or not hashes or set(hashes) != set(source_files):
            raise Halt('来源文件清单与批次不一致')
        for key,file in source_files.items():
            if hashlib.sha256(Path(file).read_bytes()).hexdigest() != hashes[key]:
                raise Halt('来源资料发生变化：'+key)


def prepare_batch(args):
    if not args.input or not args.output or not args.source_manifest or not args.sender_uid:
        raise Halt('准备批次需要 --input、--output、--source-manifest 和 --sender-uid')
    rows = json.loads(Path(args.input).read_text(encoding='utf-8-sig'))
    if not isinstance(rows,list) or not rows:
        raise Halt('输入必须是非空 JSON 数组')
    sources = source_manifest(args.source_manifest)
    prepared=[]
    seen_comments=set()
    seen_customers=set()
    seen_platform_users=set()
    for row in rows:
        if not isinstance(row,dict): raise Halt('输入客户必须为对象')
        fields=('customer_id','customer_uid','comment_id','note_id','text')
        if any(not isinstance(row.get(k),str) or not row[k].strip() or row[k] != row[k].strip() for k in fields):
            raise Halt('客户、评论、帖子标识与回复内容都必须是非空字符串')
        if row['comment_id'] in seen_comments: raise Halt('评论标识重复，须先去重')
        if row['customer_id'] in seen_customers or row['customer_uid'] in seen_platform_users: raise Halt('同一客户在批次中重复，须先去重')
        seen_comments.add(row['comment_id'])
        seen_customers.add(row['customer_id'])
        seen_platform_users.add(row['customer_uid'])
        item = {k:row[k] for k in fields}
        item.update(sequence=row.get('sequence',len(prepared)+1),attempt_id=str(uuid.uuid4()),
                    source_identity='local_source_consistency_only',platform_reply_history='unknown',
                    other_accounts_history='unknown',send_status='not_attempted_in_this_plan')
        prepared.append(item)
    batch={'schema':'xhs-local-plan-v1','intended_account_uid':args.sender_uid,
           'source_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in sources.items()},
           'count':len(prepared),'rows':prepared}
    with Path(args.output).open('x',encoding='utf-8') as f:
        json.dump(batch,f,ensure_ascii=False,indent=2)
    print(json.dumps({'已准备':len(prepared),'文件':str(Path(args.output).resolve())},ensure_ascii=False))


def load_sender(project_root, ledger, batch_path, source_files):
    sender_path = Path(__file__).resolve().parent / 'backend' / 'xhs-local-ledger-sender-candidate' / 'production_sender.py'
    sender_dir = str(sender_path.parent)
    if sender_dir not in sys.path:
        sys.path.insert(0, sender_dir)
    spec = importlib.util.spec_from_file_location('xhs_local_sender_standalone', sender_path)
    if spec is None or spec.loader is None:
        raise Halt('未找到现有发送组件')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.REAL_LEDGER = Path(ledger).resolve(strict=True)
    module.PREPARED_BATCH = Path(batch_path).resolve(strict=True)
    module.SOURCE_FILES = {k: Path(v).resolve(strict=True) for k, v in source_files.items()}
    # Preserve the original per-project account lock location across copied clients.
    module.ROOT = project_root / 'work' / 'xhs-local-ledger-sender-candidate'
    module.validate_prepared = lambda plan,path,require_hashes=False: verify_prepared(plan,path,module.SOURCE_FILES,require_hashes)
    return module


def make_plan(module, row, sender_uid, source):
    return module.SendPlan(
        sender_uid=sender_uid, customer_uid=row['customer_uid'], note_id=row['note_id'],
        comment_id=row['comment_id'], text=row['text'], attempt_id=row['attempt_id'],
        authorized=True, verification_evidence='Local source mapping and customer projection; platform replies and other accounts unknown',
        valid_until=int(time.time()) + 240, source=source, canonical_customer=row['customer_id'])


def run(args):
    root = Path(args.project_root).resolve(strict=True)
    if args.action == 'prepare':
        prepare_batch(args)
        return
    batch_path = Path(args.batch or root / 'work' / 'xhs-46-local-prepared-20261028' / 'gubei-46-plan.json').resolve(strict=True)
    ledger = Path(args.ledger or root / 'work' / 'shared-acquisition-ledger' / 'shared.sqlite3').resolve(strict=True)
    batch = load_batch(batch_path)
    sources = {
        'mapping': Path(args.source_mapping or root / 'work' / 'xhs-identity-audit' / 'mapping-20261028-154115.json'),
        'inputs': Path(args.source_inputs or root / 'work' / 'cli-independent-20261027' / 'followup-analysis-input.jsonl'),
        'snapshot': Path(args.source_snapshot or root / 'work' / 'xhs-high-intent-157' / 'priority-snapshot-20261028-173048.json'),
        'preview': Path(args.source_preview or root / 'outputs' / '古北高意向回复预览' / '46位客户原话与拟回复.txt'),
    }
    if args.source_manifest:
        sources = source_manifest(args.source_manifest)
    states = ledger_states(ledger)
    items = list(planned_rows(batch, states))
    summary={'客户数':len(items), '已受理':sum(s == 'accepted' for _,s in items),
             '待处理':sum(s == 'pending' for _,s in items), '结果不明':sum(s == 'blocked' for _,s in items)}
    if args.analysis_report:
        report=json.loads(Path(args.analysis_report).read_text(encoding='utf-8-sig'))
        report_items=report.get('items') if isinstance(report,dict) else None
        if not isinstance(report_items,list):raise Halt('AI分析报告格式不正确')
        review_comments={x.get('comment_id') for x in report_items if isinstance(x,dict) and x.get('needs_review') is True}
        summary['AI待核']=sum(state=='pending' and row.get('comment_id') in review_comments for row,state in items)
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    if args.action == 'status':
        return
    if args.action == 'preview':
        for row,state in items:
            print(json.dumps({'序号':row.get('sequence'), '状态':state, '拟回复':row.get('text')}, ensure_ascii=False))
        return
    if not args.execute:
        raise Halt('发送未启动：需要显式传入 --execute')
    if not args.sender_uid or not args.session_home:
        raise Halt('发送需要指定实际登录账号 UID 与独立登录目录')
    if args.interval < 1:
        raise Halt('间隔不能少于1秒')
    if any(s == 'blocked' for _,s in items):
        raise Halt('本批有未确认结果，停止并先核实')
    module = load_sender(root, ledger, batch_path, sources)
    home = Path(args.session_home).resolve(strict=True)
    os.environ['HOME'] = str(home)
    os.environ['USERPROFILE'] = str(home)
    cookies = module.load_independent_cookies(home)
    for row,state in items:
        if state == 'accepted':
            continue
        # Another process may have acted since the initial snapshot.
        current = row_state(row,ledger_states(ledger))
        if current == 'accepted':
            continue
        if current != 'pending':
            raise Halt('该客户存在未确认结果，停止')
        plan = make_plan(module, row, args.sender_uid, batch['schema'])
        client = module.OneAttemptClient(cookies, plan)
        try:
            try:
                result = module.Runner(ledger, client).submit(plan)
            except Exception as exc:
                current = row_state(row,ledger_states(ledger))
                if current == 'blocked':
                    detail = str(exc) if isinstance(exc, module.Unknown) else '需核对账本'
                    raise Halt('序号 '+str(row.get('sequence'))+'：结果不明，已停止。'+detail) from None
                if isinstance(exc,module.Refused) and str(exc).startswith('身份核对失败：'):
                    raise Halt('序号 '+str(row.get('sequence'))+'：'+str(exc)) from None
                raise Halt('序号 '+str(row.get('sequence'))+'：提交前被拒绝，已停止；本次未获得可用回执') from None
        finally:
            client.close()
        if result != 'receipt_received_unverified':
            raise Halt('平台结果不明，停止')
        print(json.dumps({'序号':row.get('sequence'), '状态':'平台已受理，页面可见性未核实'}, ensure_ascii=False), flush=True)
        time.sleep(args.interval)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', required=True, help='项目路径；不依赖 Codex 运行')
    parser.add_argument('--ledger', help='共享账本完整路径')
    parser.add_argument('--batch', help='已准备批次 JSON 完整路径')
    parser.add_argument('--input', help='prepare 使用的客户 JSON 数组')
    parser.add_argument('--output', help='prepare 新建批次文件路径')
    parser.add_argument('--source-manifest', help='来源文件名称到路径的 JSON 映射')
    parser.add_argument('--analysis-report', help='可选的 AI 分析报告，用于显示仍待核的数量')
    for key in ('mapping','inputs','snapshot','preview'):
        parser.add_argument('--source-'+key, help='关联原始资料完整路径')
    parser.add_argument('--session-home', help='已登录的独立 CLI 账号目录')
    parser.add_argument('--sender-uid', help='实际登录的账号 UID')
    parser.add_argument('--interval', type=float, default=1.0, help='两次发送之间等待秒数，默认1秒')
    parser.add_argument('--execute', action='store_true', help='显式允许 run 提交')
    parser.add_argument('action', choices=('prepare','status','preview','run'))
    args = parser.parse_args(argv)
    try:
        run(args)
    except (Halt, OSError, ValueError, sqlite3.Error, KeyError, ImportError) as exc:
        print('停止：'+str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
