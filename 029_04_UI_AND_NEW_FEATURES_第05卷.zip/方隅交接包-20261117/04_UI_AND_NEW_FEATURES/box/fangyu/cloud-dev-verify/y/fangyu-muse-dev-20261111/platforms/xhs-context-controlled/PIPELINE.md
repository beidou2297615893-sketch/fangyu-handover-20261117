# 采集后自动补正文并交给 Codex

入口：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-context-controlled/context_pipeline.py`

目录：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-context-controlled`

本入口复用已验证的采集器、独立账号读取层、正文解析和 Codex 分析规则。输入是现有采集器保存的 `collection.json` 或 `partial.json`；先通过既有登记器核对账本，只将新增、无阻断的客户选择文件交给它。不会重新搜索，也不发送回复或修改账本。

每个不同帖子只补读一次正文。帖子标题、完整正文、本人评论原文和已核实的顶层主评论关系会传入现有 AI 提示词。搜索标题另行保留，原始采集文件和登记后的客户选择也保留副本。顶层主评论不再被错误标记为“缺父评论”；尚未读取的楼中楼仍明确标记，不凭空生成。

在工程根目录预览本次已有数据（已离线验证为 10 位、4 篇；不访问平台或调用模型）：

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -X utf8 'work/xhs-context-controlled/context_pipeline.py' --collection 'work/xhs-collection-candidate/work/gubei-continue-20261028-a/partial.json' --selected-input 'work/xhs-collection-candidate/work/gubei-continue-20261028-a/new-ai-input.json' --output 'work/xhs-context-controlled/work/integrated-a'
```

真正补读并接 Codex 时，在预览命令末尾追加以下参数，由执行者填入已核对的账号 UID。不要原样执行占位符：

```text
--session-home work/xhs-standalone-session/cli-login-20261028-165417 --sender-uid <已核对的蕾姆UID> --account work/xhs-ai-standalone/account-leimu.json --style work/xhs-ai-standalone/style-leimu.json --analyse --execute
```

新的采集批次替换两个输入文件和输出目录即可。输出目录必须不存在，不覆盖旧结果。若只想补读正文后另行分析，省略 `--analyse`、账号资料和语气参数。

读取使用现成且 24 小时内的帖子搜索访问上下文，先核对账号，再直接调用既有只读帖子详情接口。不会自动搜索刷新、不走 HTML 回退、不读取历史发送记录。任何读取错误、验证、461、429等都停止，不重试；已读正文写入 `partial-context.json`，原始资料及停止阶段保留在输出目录。所有正文读取成功后才生成 `ai-input.json` 并进入 Codex 分析。模型出错则使用原流程保留完成断点，不生成完整发送批次。

正文补读受限于单批最多 20 篇。空正文会保持缺失标记；本入口不承诺所有帖子正文都存在，也不会把模型判断当成用户真实身份或意图的确认。此处生成的草稿不自动接入旧 CMD 菜单或软件；外部发送仍应经过现有账本和发送准入检查。

验证：受控正文目录共 16 项离线测试通过，覆盖主入口、正文进入模型输入、同帖只读一次、原话保留、原数据不覆盖、已有评论被过滤后重新选主评论、身份/读取失败停止和部分数据保存。现有采集目录 57 项离线回归通过。本次集成尚未做真实平台或真实模型运行，不能把离线测试当成已完成采集。
