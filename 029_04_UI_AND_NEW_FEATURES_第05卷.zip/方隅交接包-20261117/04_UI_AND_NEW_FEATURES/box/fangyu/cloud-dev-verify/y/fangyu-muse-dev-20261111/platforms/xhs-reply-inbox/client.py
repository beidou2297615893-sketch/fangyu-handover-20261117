"""Strict one-attempt, saved-session notification reader. No session writes."""
import importlib.util
import json
from pathlib import Path
from urllib.parse import urlsplit

PROJECT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('inbox_managed',PROJECT/'work/xhs-new-task-session-fix-20261029/managed_session.py')
managed=importlib.util.module_from_spec(spec);spec.loader.exec_module(managed)
IDENTITY='https://edith.xiaohongshu.com/api/sns/web/v2/user/me'
MENTIONS='https://edith.xiaohongshu.com/api/sns/web/v1/you/mentions'

class InboxStop(RuntimeError): pass

class InboxClient(managed.ManagedClient):
    _ALLOWED=frozenset({('GET',IDENTITY),('GET',MENTIONS)})
    def __init__(self,path,expected_uid,**kwargs):
        super().__init__(path,expected_uid,**kwargs)
        self.verified=False
        self.safe_error={}
    def _request_with_retry(self,method,url,**kwargs):
        endpoint=urlsplit(url)._replace(query='',fragment='').geturl()
        if endpoint==MENTIONS and not self.verified:raise InboxStop('identity_required')
        self.assert_managed_session()
        try:
            response=managed.ReadClient._request_with_retry(self,method,url,**kwargs)
            if any(k.lower().startswith(('verify','x-verify')) for k in response.headers):
                self.safe_error={'http_status':response.status_code,'verification_header_present':True}
                raise InboxStop('verification_required')
            changed=self._updated(response)
            if changed!=self.cookies:
                # Never save or silently adopt authentication/transport updates.
                raise InboxStop('session_update_requires_review')
            self.assert_managed_session()
            return response
        except Exception:
            self._locked=True
            raise
    def _handle_response(self,response):
        # Do not let upstream error logging serialize the raw body.
        try: payload=response.json()
        except Exception:raise InboxStop('invalid_json') from None
        if not isinstance(payload,dict) or payload.get('success') is not True:
            self.safe_error={'http_status':response.status_code,'success':False}
            if isinstance(payload,dict) and type(payload.get('code')) is int:self.safe_error['api_code']=payload['code']
            self._locked=True
            raise InboxStop('platform_business_error')
        if not isinstance(payload.get('data'),dict):raise InboxStop('invalid_data')
        return payload['data']
    def verify(self):
        identity=managed.account.identify(self.get_self_info())
        if identity['uid']!=self.expected_uid:raise InboxStop('account_mismatch')
        self.verified=True
        return {'uid':identity['uid'],'verified':True}

def shape(value,depth=0):
    if depth>5:return type(value).__name__
    if isinstance(value,dict):return {k:shape(v,depth+1) for k,v in value.items() if isinstance(k,str) and len(k)<80 and not any(x in k.lower() for x in ('token','cookie','ticket','secret','sign','verify','header'))}
    if isinstance(value,list):return {'type':'list','count':len(value),'sample_shapes':[shape(v,depth+1) for v in value[:3]]}
    return type(value).__name__

def projection(value,depth=0):
    """Whitelist only notification IDs/text; never URLs, tokens, arbitrary raw fields."""
    if depth>4 or not isinstance(value,dict):return {}
    scalar={'id','message_id','notification_id','comment_id','target_comment_id','parent_comment_id','root_comment_id','note_id','user_id','userid','uid','nickname','content','title','time','timestamp','type','business_type'}
    nested={'user_info','item_info','comment','comment_info','target_comment','target_comment_info','parent_comment','note','note_info'}
    out={}
    for k,v in value.items():
        if k in scalar and type(v) in (str,int,float,bool):out[k]=v[:4000] if isinstance(v,str) else v
        elif k in nested and isinstance(v,dict):out[k]=projection(v,depth+1)
    return out

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--session',required=True);p.add_argument('--uid',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    c=None
    try:
        c=InboxClient(a.session,a.uid);identity=c.verify();data=c.get_notification_mentions(num=20)
        report={'status':'read_succeeded','identity':identity,'shape':shape(data),'items':[projection(x) for x in data.get('message_list',[]) if isinstance(x,dict)]}
    except Exception as e:
        report={'status':'stopped','error_type':type(e).__name__,'reason':str(e) if type(e) is InboxStop else 'read_failed_no_retry','diagnostic':getattr(c,'safe_error',{})}
    finally:
        if c is not None:c._http.close()
    (out/'probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':report['status'],'output':str(out/'probe.json')},ensure_ascii=False))
