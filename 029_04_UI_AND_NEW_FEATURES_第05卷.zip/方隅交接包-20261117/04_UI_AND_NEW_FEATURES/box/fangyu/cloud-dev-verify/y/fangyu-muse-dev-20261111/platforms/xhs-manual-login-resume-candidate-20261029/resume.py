"""Offline-only acceptance gate; never opens a browser or makes a request.

Caller must pass a same-page response observed after the verification challenge.
This module has no logging or implicit persistence; save is called at most once.
"""
import re
from urllib.parse import urlsplit

COOKIE_NAMES = frozenset({'a1', 'webId', 'web_session', 'web_session_sec',
                          'id_token', 'websectiga', 'sec_poison_id', 'xsecappid',
                          'gid', 'abRequestId', 'webBuild', 'loadts'})

class ManualSessionObserver:
    """Passive observer only; attach after the original challenge response.

    A person must explicitly call finish_by_person. No navigation or fetch.
    """
    def __init__(self, page, save, expected_uid=None):
        self.page=page
        self.save=save
        self.expected_uid=expected_uid
        self.last_response=None
        self.finished=False
    def attach(self):
        self.page.on('response',self.on_response)
    def on_response(self,response):
        try:
            url=urlsplit(response.url)
            if (response.frame.page is not self.page or url.scheme!='https' or
                url.netloc!='www.xiaohongshu.com' or
                url.path!='/api/sns/web/v2/user/me' or response.request.method!='GET'):
                return
            body=response.json() if response.status==200 else None
            self.last_response={'after_challenge':True,'status':response.status,
                                'host':url.hostname,'path':url.path,'body':body}
        except Exception:
            # If we cannot bind evidence to this exact page, discard it.
            self.last_response=None
    def finish_by_person(self):
        if self.finished:
            return {'status':'already_finished'}
        try:
            opened=not self.page.is_closed()
        except Exception:
            return {'status':'page_unavailable'}
        preflight=verified_session(user_confirmed=True,browser_open=opened,
            response=self.last_response,cookie_items=[],save=lambda *_:None,
            expected_uid=self.expected_uid)
        if preflight['status']!='session_incomplete':
            return preflight
        try:
            cookies=self.page.context.cookies()
        except Exception:
            return {'status':'session_unavailable'}
        try:
            if self.page.is_closed():
                return {'status':'page_closed'}
        except Exception:
            return {'status':'page_unavailable'}
        # Once save is attempted its outcome may be unknown; never auto-repeat.
        result=verified_session(user_confirmed=True,browser_open=opened,
            response=self.last_response,cookie_items=cookies,save=self.save,
            expected_uid=self.expected_uid)
        if result['status'] in ('saved','save_outcome_unknown'):
            self.finished=True
        return result

def verified_session(*, user_confirmed, browser_open, response, cookie_items, save,
                     expected_uid=None):
    if user_confirmed is not True:
        return {'status':'awaiting_user'}
    if browser_open is not True:
        return {'status':'page_closed'}
    if not isinstance(response, dict) or response.get('after_challenge') is not True:
        return {'status':'no_auth_evidence'}
    if response.get('status') != 200 or response.get('host') != 'www.xiaohongshu.com' or response.get('path') != '/api/sns/web/v2/user/me':
        return {'status':'no_auth_evidence'}
    body=response.get('body')
    if not isinstance(body, dict):
        return {'status':'no_auth_evidence'}
    if body.get('success') is False:
        return {'status':'no_auth_evidence'}
    if 'code' in body and (type(body['code']) is not int or body['code'] != 0):
        return {'status':'no_auth_evidence'}
    body=body.get('data',body)
    if not isinstance(body, dict):
        return {'status':'no_auth_evidence'}
    containers=[body]
    for key in ('user_info','basic_info'):
        if key in body:
            if not isinstance(body[key],dict):
                return {'status':'no_auth_evidence'}
            containers.append(body[key])
    uids=set(); guests=[]
    for item in containers:
        for key in ('user_id','userid','uid'):
            if key in item:
                value=item[key]
                if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',value):
                    return {'status':'identity_unverified'}
                uids.add(value)
        if 'guest' in item:
            if type(item['guest']) is not bool:
                return {'status':'identity_unverified'}
            guests.append(item['guest'])
    if len(uids)!=1 or not guests or any(guests):
        return {'status':'identity_unverified'}
    uid=next(iter(uids))
    if expected_uid is not None and expected_uid!=uid:
        return {'status':'identity_conflict'}
    if not isinstance(cookie_items,list):
        return {'status':'session_incomplete'}
    selected={}
    for item in cookie_items:
        if not isinstance(item,dict):
            return {'status':'session_incomplete'}
        name=item.get('name'); value=item.get('value'); domain=item.get('domain')
        if not isinstance(name,str) or name not in COOKIE_NAMES:
            continue
        if not isinstance(domain,str) or domain.lstrip('.').lower() not in ('xiaohongshu.com','www.xiaohongshu.com'):
            continue
        if not isinstance(value,str) or not value:
            continue
        if name in selected and selected[name]!=value:
            return {'status':'session_conflict'}
        selected[name]=value
    if not all(selected.get(name) for name in ('a1','webId','web_session')):
        return {'status':'session_incomplete'}
    try:
        save(selected, {'uid':uid,'guest':False})
    except Exception:
        return {'status':'save_outcome_unknown'}
    return {'status':'saved','uid':uid}
