"""Synthetic-only verification of local-history sender candidate."""
import json
from contextlib import closing
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path

import local_mode

ROOT = Path(__file__).resolve().parent
LEDGER = ROOT.parent / 'shared-acquisition-ledger' / 'ledger.py'


class LocalModeTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.base = Path(self.tmp.name)
        self.db = self.base / 'synthetic.sqlite3'
        p = subprocess.run([sys.executable, '-B', str(LEDGER), '--db', str(self.db), 'init'], capture_output=True)
        self.assertEqual(p.returncode, 0)
        self.plan = local_mode.Plan('sender', 'uid', 'comment', 'note', 'hello', 'attempt')
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'uid', 'comment', 'unverified', 'synthetic'))
            db.execute('INSERT INTO identity_aliases VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'uid', 'uid', 'synthetic mapping', 2147483647))
            db.commit()

    def tearDown(self):
        self.tmp.cleanup()

    def test_reserve_retains_truthful_unknown_platform_and_exact_plan(self):
        self.assertTrue(local_mode.reserve(self.db, self.plan))
        with closing(sqlite3.connect(self.db)) as db:
            data = json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])
            self.assertEqual(data['peer_reply'], 'unknown')
            self.assertFalse(data['local_mode']['platform_replies_checked'])
            self.assertFalse(data['local_mode']['all_accounts_history_checked'])
            self.assertEqual(data['draft'], self.plan.text)

    def test_existing_assessment_is_preserved_byte_for_byte(self):
        original = '{"source":"original","reason":"must remain unchanged"}'
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO assessments VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'uid', 'comment', original, 123))
            db.commit()
        self.assertTrue(local_mode.reserve(self.db, self.plan))
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT data,updated FROM assessments').fetchone(), (original, 123))
            data = json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])
            self.assertEqual(data['peer_reply'], 'unknown')

    def test_customer_unverified_collected_comment_not_automatically_a_send(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'uid', 'other', 'unverified', 'synthetic'))
            db.commit()
        self.assertTrue(local_mode.reserve(self.db, self.plan))

    def test_unknown_submission_and_sent_block_customer(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'uid', 'old', 'unknown', 'synthetic'))
            db.commit()
        with self.assertRaises(local_mode.Refused):
            local_mode.reserve(self.db, self.plan)

    def test_unresolved_software_delivery_blocks_customer(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO historical_deliveries VALUES(?,?,?,?,?,?,?)',
                       ('xiaohongshu', 'uid', 'comment', 'old', 'submitted', 'synthetic', 1))
            db.commit()
        with self.assertRaises(local_mode.Refused):
            local_mode.reserve(self.db, self.plan)

    def test_missing_uid_mapping_fails_closed(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('DELETE FROM identity_aliases')
            db.commit()
        with self.assertRaises(local_mode.Refused):
            local_mode.reserve(self.db, self.plan)

    def test_concurrent_reserve_grants_only_once(self):
        outcomes = []
        def run():
            try: outcomes.append(local_mode.reserve(self.db, self.plan))
            except local_mode.Refused: outcomes.append(False)
        workers = [threading.Thread(target=run) for _ in range(5)]
        for worker in workers: worker.start()
        for worker in workers: worker.join()
        self.assertEqual(sum(outcomes), 1)

    def test_transport_called_once_and_unconfirmed_result_blocks_retry(self):
        calls = []
        def fake_send(plan):
            calls.append(plan)
            return {'receipt_id': 'synthetic_receipt'}
        self.assertEqual(local_mode.submit_once(self.db, self.plan, fake_send), 'unknown')
        with self.assertRaises(local_mode.Refused):
            local_mode.submit_once(self.db, self.plan, fake_send)
        self.assertEqual(len(calls), 1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM reservations').fetchone()[0], 'unknown')

    def test_transport_exception_marks_unknown_and_never_retries(self):
        calls = []
        def fail(plan):
            calls.append(plan)
            raise TimeoutError('synthetic timeout')
        self.assertEqual(local_mode.submit_once(self.db, self.plan, fail), 'unknown')
        self.assertEqual(len(calls), 1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM leads').fetchone()[0], 'unknown')

    def test_unknown_attempt_halts_same_account_for_another_customer(self):
        self.assertEqual(local_mode.submit_once(self.db, self.plan, lambda plan: None), 'unknown')
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'other_uid', 'other_comment', 'unverified', 'synthetic'))
            db.execute('INSERT INTO identity_aliases VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'other_uid', 'other_uid', 'synthetic mapping', 2147483647))
            db.commit()
        next_plan = local_mode.Plan('sender', 'other_uid', 'other_comment', 'note', 'hello', 'next')
        with self.assertRaises(local_mode.Refused):
            local_mode.reserve(self.db, next_plan)

    def test_existing_unknown_from_other_sender_path_remains_blocking(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'other_uid', 'other_comment', 'unknown', 'synthetic old sender'))
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                       ('old_attempt', 'xiaohongshu', 'other_uid', 'other_comment', 'unknown', 'unresolved', 1))
            db.commit()
        with self.assertRaises(local_mode.Refused):
            local_mode.reserve(self.db, self.plan)

    def test_identity_split_in_historical_delivery_blocks(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO identity_aliases VALUES(?,?,?,?,?)',
                       ('xiaohongshu', 'alias', 'uid', 'synthetic mapping', 2147483647))
            db.execute('INSERT INTO historical_deliveries VALUES(?,?,?,?,?,?,?)',
                       ('xiaohongshu', 'alias', 'old', 'prior', 'submitted', 'synthetic', 1))
            db.commit()
        with self.assertRaises(local_mode.Refused):
            local_mode.reserve(self.db, self.plan)


if __name__ == '__main__':
    unittest.main(verbosity=2)
