import hashlib
import json
import sqlite3
import tempfile
import subprocess
import sys
import time
import unittest
import io
from pathlib import Path
from contextlib import closing
from contextlib import redirect_stdout
from unittest.mock import patch

import register


def new_id(uid):
    return 'xhs_new_' + hashlib.sha256(('xiaohongshu:' + uid).encode()).hexdigest()


def customer(uid, cid=None, comments=('c1',)):
    cid=cid or new_id(uid)
    def comment(c):
        return {'comment_id':c,'note_id':'note','comment_text':'求租', 'post_title':'古北租房'}
    return {'customer_id':cid,'customer_uid':uid,**comment(comments[0]),'other_comments':[comment(x) for x in comments[1:]]}


def batch(*items):
    return {'schema':'xhs-collected-ai-input-v1','customers':list(items)}


class RegistrationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.path=Path(self.temp.name)/'test.sqlite3'
        with closing(sqlite3.connect(self.path)) as db:
            db.executescript('''
              CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,review_time INTEGER,evidence TEXT,operator TEXT,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
              CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT,evidence TEXT,created INTEGER);
              CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,evidence TEXT,verified INTEGER,PRIMARY KEY(platform,alias));
              CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,comment TEXT,reference TEXT,delivery_state TEXT,source TEXT,recorded INTEGER);
              CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));
            ''')
            db.commit()
    def tearDown(self): self.temp.cleanup()
    def leads(self):
        with closing(sqlite3.connect(self.path)) as db:return db.execute('SELECT platform,customer,comment,status,source FROM leads ORDER BY comment').fetchall()
    def run_import(self,data,mapping=None,apply=True):
        return register.register(self.path,data,mapping or {},'synthetic-evidence',apply=apply)

    def test_default_preview_does_not_write(self):
        self.assertEqual(self.run_import(batch(customer('u1')),apply=False)['would_insert'],1)
        self.assertEqual(self.leads(),[])

    def test_new_customer_multiple_comments_atomic_and_idempotent(self):
        data=batch(customer('u1',comments=('c1','c2')))
        self.assertEqual(self.run_import(data)['inserted'],2)
        self.assertEqual(self.run_import(data)['already_present'],2)
        self.assertEqual(len(self.leads()),2)
        self.assertTrue(all(x[3]=='unverified' for x in self.leads()))

    def test_existing_known_uid_reuses_real_canonical_without_alias_write(self):
        self.run_import(batch(customer('u1','historic')),{'u1':'historic'})
        self.assertEqual(self.leads()[0][1],'historic')
        with closing(sqlite3.connect(self.path)) as db:self.assertEqual(db.execute('SELECT count(*) FROM identity_aliases').fetchone()[0],0)

    def test_same_comment_different_customer_blocks_entire_customer(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("INSERT INTO leads(platform,customer,comment,status,source) VALUES('xiaohongshu','other','c1','unverified','old')")
            db.commit()
        result=self.run_import(batch(customer('u1',comments=('c1','c2'))))
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual([x[2] for x in self.leads()],['c1'])

    def test_identity_conflict_in_database_is_not_treated_as_new(self):
        result=self.run_import(batch(customer('u1')),{'u1':None})
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual(self.leads(),[])

    def test_known_uid_with_changed_canonical_stays_blocked(self):
        result=self.run_import(batch(customer('u1','wrong')),{'u1':'right'})
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual(self.leads(),[])

    def test_prior_uid_receipt_under_different_canonical_blocks(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("INSERT INTO reservations VALUES('old','xiaohongshu','old-customer','old-comment','unknown',NULL,0)")
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',('old',json.dumps({'plan':{'customer_uid':'u1','canonical_customer':'old-customer'},'result':{'kind':'platform_receipt','receipt_id':'receipt'}})))
            db.commit()
        result=self.run_import(batch(customer('u1')))
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual(self.leads(),[])

    def test_unknown_historical_delivery_same_customer_blocks(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("INSERT INTO historical_deliveries VALUES('xiaohongshu','historic','old','ref','submitted','fixture',0)")
            db.commit()
        result=self.run_import(batch(customer('u1','historic')),{'u1':'historic'})
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual(self.leads(),[])

    def test_different_platform_does_not_block_same_uid(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("INSERT INTO reservations VALUES('old','douyin','else','old','unknown',NULL,0)")
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',('old',json.dumps({'plan':{'customer_uid':'u1','canonical_customer':'else'}})))
            db.commit()
        self.assertEqual(self.run_import(batch(customer('u1')))['inserted'],1)

    def test_rejects_duplicate_uid_in_batch_before_any_write(self):
        with self.assertRaises(register.Invalid):self.run_import(batch(customer('u1',comments=('c1',)),customer('u1',comments=('c2',))))
        self.assertEqual(self.leads(),[])

    def test_uid_with_new_canonical_in_later_batch_is_blocked(self):
        self.assertEqual(self.run_import(batch(customer('u1',comments=('c1',))))['inserted'],1)
        result=self.run_import(batch(customer('u1','different',comments=('c2',))),{'u1':'different'})
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual([x[2] for x in self.leads()],['c1'])

    def test_canonical_with_other_uid_in_later_batch_is_blocked(self):
        self.assertEqual(self.run_import(batch(customer('u1',comments=('c1',))))['inserted'],1)
        cid=new_id('u1')
        result=self.run_import(batch(customer('u2',cid,comments=('c2',))),{'u2':cid})
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual([x[2] for x in self.leads()],['c1'])

    def test_unmapped_legacy_unknown_is_preserved_as_pending(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("INSERT INTO reservations VALUES('old','xiaohongshu','unmapped','old-comment','unknown',NULL,0)")
            db.commit()
        result=self.run_import(batch(customer('u1')))
        self.assertEqual(result['blocked_customers'],1)
        self.assertEqual(self.leads(),[])

    def test_known_different_legacy_identity_does_not_block_new_user(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("INSERT INTO reservations VALUES('old','xiaohongshu','old-customer','old-comment','unknown',NULL,0)")
            db.commit()
        result=self.run_import(batch(customer('u1')),{ 'u2':'old-customer' })
        self.assertEqual(result['inserted'],1)

    def test_two_processes_same_uid_different_canonical_only_one_writes(self):
        script='''
import json, sys, time
from pathlib import Path
import register
Path(sys.argv[4]).touch()
deadline=time.monotonic()+8
while not Path(sys.argv[5]).exists():
    if time.monotonic()>deadline: raise RuntimeError('fixture barrier timeout')
    time.sleep(.005)
data=json.loads(sys.argv[2]); mapping=json.loads(sys.argv[3])
result=register.register(sys.argv[1],data,mapping,'fixture',apply=True)
print(str(result['inserted'])+':'+str(result['blocked_customers']))
'''
        base=Path(self.temp.name); gate=base/'go'; ready=[base/'ready1',base/'ready2']
        data=[batch(customer('u1',comments=('c1',))),batch(customer('u1','alternate',comments=('c2',)))]
        maps=[{}, {'u1':'alternate'}]
        procs=[subprocess.Popen([sys.executable,'-X','utf8','-c',script,str(self.path),json.dumps(data[i]),json.dumps(maps[i]),str(ready[i]),str(gate)],
               cwd=Path(__file__).parent,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for i in range(2)]
        deadline=time.monotonic()+8
        while not all(p.exists() for p in ready):
            if time.monotonic()>deadline:
                for proc in procs:proc.kill()
                self.fail('fixture process barrier timeout')
            time.sleep(.005)
        gate.touch(); result=[]
        for proc in procs:
            out,err=proc.communicate(timeout=15)
            self.assertEqual(proc.returncode,0,err)
            result.append(out.strip())
        self.assertEqual(sorted(result),['0:1','1:0'])
        self.assertEqual(len(self.leads()),1)

    def test_ledger_without_platform_comment_uniqueness_is_rejected(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute('DROP TABLE leads')
            db.execute('CREATE TABLE leads(platform,customer,comment,status,source)')
            db.commit()
        with self.assertRaises(register.Invalid):
            self.run_import(batch(customer('u1')))
        self.assertEqual(self.leads(),[])

    def test_partial_uid_indexes_do_not_count_as_identity_uniqueness(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.executescript('''CREATE TABLE collection_uid_observations(platform TEXT,platform_uid TEXT,canonical TEXT,basis TEXT,source TEXT,observed_at INTEGER);
                CREATE UNIQUE INDEX uid_partial ON collection_uid_observations(platform,platform_uid) WHERE platform='xiaohongshu';
                CREATE UNIQUE INDEX canonical_partial ON collection_uid_observations(platform,canonical) WHERE platform='xiaohongshu';''')
            db.commit()
        with self.assertRaises(register.Invalid): self.run_import(batch(customer('u1')))
        self.assertEqual(self.leads(),[])

    def test_existing_observation_with_invalid_basis_is_not_trusted(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute(register.UID_DDL)
            db.execute("INSERT INTO collection_uid_observations VALUES('xiaohongshu','other','other-cid','fake','old',1)")
            db.commit()
        with self.assertRaises(register.Invalid): self.run_import(batch(customer('u1')))
        self.assertEqual(self.leads(),[])

    def test_observation_name_occupied_by_view_is_rejected_in_preview(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute('CREATE VIEW collection_uid_observations AS SELECT 1 AS fake')
            db.commit()
        with self.assertRaises(register.Invalid): self.run_import(batch(customer('u1')),apply=False)
        self.assertEqual(self.leads(),[])

    def test_cli_optional_report_preserves_block_reasons_without_exposing_them_in_stdout(self):
        base=Path(self.temp.name); source=base/'collection.json'; report=base/'report.json'
        source.write_text(json.dumps(batch(customer('u1','wrong'))),encoding='utf8')
        output=io.StringIO()
        with patch.object(register.collector,'load_identity_map',return_value={'u1':'right'}), redirect_stdout(output):
            self.assertEqual(register.main(['--collection',str(source),'--ledger',str(self.path),'--source-db','fixture',
                                            '--sender-uid','sender','--report',str(report)]),0)
        self.assertNotIn('wrong',output.getvalue())
        details=json.loads(report.read_text(encoding='utf8'))
        self.assertEqual(details['blocked_customers'],1)
        self.assertEqual(details['blocked'][0]['customer_id'],'wrong')
        self.assertTrue(details['blocked'][0]['reason'])


if __name__=='__main__': unittest.main()
