"""Synthetic SQLite only. Removing evidence/day/UID validation must break these tests."""
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from contextlib import contextmanager
from datetime import datetime

try:
    import quota
except ModuleNotFoundError:
    quota = None

NOW = datetime.fromisoformat('2026-11-10T12:00:00+08:00')


@contextmanager
def fixture_connection(path):
    c=sqlite3.connect(path)
    try:
        with c:
            yield c
    finally:
        c.close()


class QuotaTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(quota, 'quota module must implement the quota contract')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / 'shared.sqlite3'
        with fixture_connection(self.db) as c:
            c.executescript('''CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT NOT NULL,
              customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,evidence TEXT,created INTEGER NOT NULL);
              CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL);''')
        self.events = []

    def add(self, token, uid='A', status='unknown', receipt=None, at=None,
            created=1794265200, platform='xiaohongshu', legacy=False):
        plan = dict(sender_uid=uid, attempt_id=token, customer_uid='user-'+token,
                    canonical_customer='customer-'+token, comment_id='comment-'+token)
        result = dict(kind='platform_receipt', receipt_id=receipt) if receipt else dict(kind='unknown')
        data = {'result': result, 'local_mode': {'sender_uid': uid, 'plan': plan}} if legacy else {'plan': plan, 'result': result}
        with fixture_connection(self.db) as c:
            c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                      (token,platform,plan['canonical_customer'],plan['comment_id'],status,'synthetic evidence',created))
            c.execute('INSERT INTO local_sender_plans VALUES(?,?)',(token,json.dumps(data)))
        if at:
            self.events.append(dict(event='accepted',platform=platform,sender_uid=uid,
                attempt_id=token,receipt_id=receipt,at=at))

    def read(self, uid='A', **kw):
        return quota.inspect_quota(self.db, uid, now=NOW, accepted_events=self.events, **kw)

    def test_beijing_day_uses_acceptance_time_not_reservation_time(self):
        self.add('before',receipt='r0',at='2026-11-09T15:59:59+00:00')
        self.add('start',receipt='r1',at='2026-11-09T16:00:00+00:00',created=1)
        self.add('today',receipt='r2',at='2026-11-10T11:59:59+08:00',created=1)
        s=self.read()
        self.assertEqual((s.day,s.confirmed_sent_today,s.remaining),('2026-11-10',2,198))
        self.assertTrue(s.allowed_for_quota)

    def test_actual_sender_uid_platform_and_replayed_events_are_independent(self):
        self.add('one',receipt='r1',at='2026-11-10T08:00:00+08:00',legacy=True)
        self.add('two',uid='B',receipt='r2',at='2026-11-10T09:00:00+08:00')
        self.add('three',receipt='r3',at='2026-11-10T09:00:00+08:00',platform='douyin')
        self.events.append(dict(self.events[0]))
        self.assertEqual(self.read().confirmed_sent_today,1)
        self.assertEqual(self.read('B').confirmed_sent_today,1)

    def test_unknown_and_reserved_never_count_as_success_and_block_account(self):
        self.add('unknown')
        self.add('reserved',status='reserved')
        s=self.read()
        self.assertEqual((s.confirmed_sent_today,s.unknown_today,s.in_flight_today,s.unresolved_total),(0,1,1,2))
        self.assertFalse(s.allowed_for_quota)

    def test_other_account_unresolved_does_not_block_known_sender(self):
        self.add('other',uid='B')
        self.assertTrue(self.read().allowed_for_quota)

    def test_threshold_is_configurable_and_never_switches_account(self):
        self.add('one',receipt='r1',at='2026-11-10T08:00:00+08:00')
        self.assertFalse(self.read(threshold=1).allowed_for_quota)
        self.assertTrue(self.read(threshold=2).allowed_for_quota)
        self.assertEqual(self.read(threshold=1).sender_uid,'A')

    def test_missing_acceptance_timestamp_fails_closed_even_with_receipt(self):
        self.add('receipt',receipt='r1')
        s=self.read()
        self.assertFalse(s.allowed_for_quota)
        self.assertEqual((s.confirmed_sent_today,s.unconfirmed_receipts),(0,1))

    def test_missing_schema_or_database_fails_closed_without_creating_database(self):
        absent=Path(self.tmp.name)/'absent.db'
        self.assertFalse(quota.inspect_quota(absent,'A',now=NOW).allowed_for_quota)
        self.assertFalse(absent.exists())
        with fixture_connection(self.db) as c: c.execute('DROP TABLE local_sender_plans')
        self.assertFalse(self.read().allowed_for_quota)

    def test_unattributed_or_malformed_evidence_fails_closed(self):
        self.add('x')
        with fixture_connection(self.db) as c:
            c.execute("UPDATE local_sender_plans SET data='{}'")
        s=self.read()
        self.assertFalse(s.allowed_for_quota)
        self.assertEqual(s.unassigned_total,1)

    def test_wrong_receipt_uid_and_naive_timestamp_fail_closed(self):
        for change in ({'receipt_id':'wrong'},{'sender_uid':'B'},{'at':'2026-11-10T08:00:00'}):
            with self.subTest(change=change):
                with fixture_connection(self.db) as c:
                    c.execute('DELETE FROM reservations');c.execute('DELETE FROM local_sender_plans')
                self.events=[]
                self.add('one',receipt='r1',at='2026-11-10T08:00:00+08:00')
                self.events[0].update(change)
                self.assertFalse(self.read().allowed_for_quota)

    def test_refresh_observes_existing_row_update_not_only_new_tokens(self):
        self.add('one',status='reserved')
        self.assertFalse(self.read().allowed_for_quota)
        with fixture_connection(self.db) as c:
            data=json.loads(c.execute('SELECT data FROM local_sender_plans').fetchone()[0])
            data['result']={'kind':'platform_receipt','receipt_id':'r1'}
            c.execute('UPDATE local_sender_plans SET data=?',(json.dumps(data),))
            c.execute("UPDATE reservations SET status='unknown'")
        self.events.append(dict(event='accepted',platform='xiaohongshu',sender_uid='A',attempt_id='one',receipt_id='r1',at='2026-11-10T08:00:00+08:00'))
        self.assertEqual(self.read().confirmed_sent_today,1)
        self.assertTrue(self.read().allowed_for_quota)

    def test_stop_signal_blocks_and_network_error_is_not_business_rejection(self):
        guard=quota.BusinessRejectionGuard(limit=2)
        self.assertFalse(guard.observe('network_error'))
        self.assertFalse(guard.observe('business_rejection'))
        self.assertFalse(guard.observe('network_error'))
        self.assertTrue(guard.observe('business_rejection'))
        self.assertFalse(self.read(stop_signal=guard.stopped).allowed_for_quota)

    def test_read_only_no_ledger_content_changes(self):
        self.add('one',receipt='r1',at='2026-11-10T08:00:00+08:00')
        before=self.db.read_bytes()
        self.read()
        self.assertEqual(self.db.read_bytes(),before)

    def test_duplicate_receipt_does_not_inflate_confirmed_count(self):
        self.add('one',receipt='same',at='2026-11-10T08:00:00+08:00')
        self.add('two',receipt='same',at='2026-11-10T08:00:00+08:00')
        s=self.read()
        self.assertEqual(s.confirmed_sent_today,1)
        self.assertFalse(s.allowed_for_quota)

    def test_not_sent_with_acceptance_evidence_fails_closed(self):
        self.add('one',status='not_sent',receipt='r1',at='2026-11-10T08:00:00+08:00')
        self.assertFalse(self.read().allowed_for_quota)

    def test_unmapped_legacy_history_prevents_assuming_zero(self):
        with fixture_connection(self.db) as c:
            c.executescript('''CREATE TABLE leads(platform,customer,comment,status);
              INSERT INTO leads VALUES('xiaohongshu','legacy','comment','unknown');''')
        s=self.read()
        self.assertFalse(s.allowed_for_quota)
        self.assertEqual(s.unassigned_total,1)

    def test_historical_software_submission_prevents_assuming_zero(self):
        with fixture_connection(self.db) as c:
            c.executescript('''CREATE TABLE historical_deliveries(platform,customer,comment,delivery_state);
              INSERT INTO historical_deliveries VALUES('xiaohongshu','legacy','comment','submitted');''')
        self.assertFalse(self.read().allowed_for_quota)

    def test_orphan_acceptance_and_conflicting_replay_fail_closed(self):
        self.events=[dict(event='accepted',platform='xiaohongshu',sender_uid='A',attempt_id='absent',receipt_id='r1',at='2026-11-10T08:00:00+08:00')]
        self.assertFalse(self.read().allowed_for_quota)
        self.add('one',receipt='r1',at='2026-11-10T08:00:00+08:00')
        self.events=[self.events[-1],dict(self.events[-1],receipt_id='different')]
        self.assertFalse(self.read().allowed_for_quota)

    def test_invalid_configuration_is_rejected_and_future_evidence_blocks(self):
        with self.assertRaises(ValueError):self.read(threshold=True)
        with self.assertRaises(ValueError):self.read(uid='')
        with self.assertRaises(ValueError):quota.inspect_quota(self.db,'A',now=datetime(2026,11,10))
        self.add('one',receipt='r1',at='2026-11-10T13:00:00+08:00')
        self.assertFalse(self.read().allowed_for_quota)


if __name__=='__main__':
    unittest.main()
