import json,csv,collections,re,hashlib
from datetime import datetime,timezone,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
rows=json.loads((WORK/'drafts.json').read_text('utf8'))
OUT=ROOT/'outputs/小红书意向回复草稿';OUT.mkdir(parents=True,exist_ok=True)
labels={'super_high':'超高','high':'高','medium':'中'}
internal_hash=hashlib.sha256((WORK/'drafts.json').read_bytes()).hexdigest()
NOTE_LABELS={
 'apartment_rejection':'客户明确表示不考虑公寓，不宜推荐',
 'customer_role_unverified':'尚未确认客户是在找房还是提供房源',
 'demand_time_unverified':'尚未确认客户现在是否仍在找房',
 'possible_supply_not_demand':'评论可能是在提供房源，需要先核实',
 'post_body_not_collected':'尚未取得帖子正文，判断依据不完整',
 'post_region_not_customer_region':'帖子所在地不能代表客户想找房的地区',
 'region_unverified':'客户想找房的地区尚未确认',
 'strong_intent_evidence_insufficient':'客户的明确求租证据不足，需要复核意向',
 'super_high_action_unverified':'尚未确认客户是否真的准备约看或签约',
}
def local_time(value):
 if not value:return '未知'
 try:
  date=datetime.fromisoformat(value)
  if date.tzinfo is None:return value
  return date.astimezone(timezone(timedelta(hours=8))).strftime('%Y年%m月%d日 %H:%M（北京时间）')
 except (ValueError,TypeError):return value
def business_notes(row):
 result=[];seen=set()
 def add(text,category=None):
  key=category or re.sub(r'[，、。；～\s]','',text)
  if key not in seen and text not in result:seen.add(key);result.append(text)
 if not row['own_region_confirmed']:add('客户想找房的地区尚未确认，不能仅凭帖子所在地判断','region')
 if not row['current_time_confirmed']:add('尚未确认客户现在是否仍在找房','time')
 if not row['source_record'].get('post_text'):add('尚未取得帖子正文，判断依据不完整','body')
 for raw in row['review_notes']:
  translated=NOTE_LABELS.get(raw,raw)
  if re.fullmatch(r'[a-z]+(?:_[a-z]+)+',translated):raise ValueError('Unmapped internal note')
  translated=translated.replace('父级及子评论','上下文对话').replace('父评论及子评论','上下文对话').replace('父级','上文评论').replace('IP属地','网络属地').replace('IP信息','网络属地信息').replace('P3','第三张图片')
  for note in translated.split('；'):
   note=note.strip('，。； ')
   if not note:continue
   if note in ('保留原分类与分析','保留原分类及分析','保留原分类和原分析'):continue
   if note.startswith(('按本次规则','保留原分类','草稿为另行推荐')):continue
   if note in ('正文未采集','尚未取得帖子正文，判断依据不完整'):add('尚未取得帖子正文，判断依据不完整','body');continue
   if note in ('帖子地域不等于本人需求地区','帖子所在地不能代表客户想找房的地区','标题地点不代表本人需求','标题不代表本人需求','标题不能代替本人需求','不能把标题地区当作本人确认','保留原始发表时间显示，不推测绝对日期'):
    continue
   if ('当前' in note and any(s in note for s in ('找房','需求','求租','时效'))) or '未在线复核客户' in note:
    add('尚未确认客户现在是否仍在找房','time')
    # Preserve specific dates and conditions; omit repeated generic time caveats.
    if not re.search(r'\d|个月|短租|换房|两人|月底|十一月',note):continue
   if note.startswith(('本人求租地区','本人找房地区','本人需求地区','求租地区','地区不明','客户想找房的地区','帖子所在地不能')):
    add('客户想找房的地区尚未确认，不能仅凭帖子所在地判断','region')
    if not any(s in note for s in ('具体条件','入住时间','角色','户型','房型','设施','门店')):continue
   if note.startswith('当前需求时效待核；'):continue
   if note=='当前需求时效待核':continue
   add(note)
 return '；'.join(result)
with (OUT/'待审核回复草稿.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['客户原话','意向','发表时间','页面显示的原始时间','距分析时已过天数','本人找房地区','需求时效','回复草稿','待核事项','状态'])
 for r in rows:w.writerow([r['comment_text'],labels[r['source_analysis']['result']['interest']],local_time(r.get('published_at','')),r.get('date_display') or '未知',r.get('comment_age_days') if r.get('comment_age_days') is not None else '未知','古北已确认' if r['own_region_confirmed'] else '待核','当前有效已确认' if r['current_time_confirmed'] else '待核',r['draft'],business_notes(r),r['draft_status']])
summary={'customers':len(rows),'drafts':sum(bool(r['draft']) for r in rows),'held':sum(not bool(r['draft']) for r in rows),'own_region_confirmed':sum(r['own_region_confirmed'] for r in rows),'missing_body':sum(not r['source_record'].get('post_text') for r in rows),'interest':dict(collections.Counter(r['source_analysis']['result']['interest'] for r in rows)),'platform_requests':0,'sent':0}
(WORK/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'阅读说明.md').write_text(f'''本次整理了{len(rows)}位客户的待审核建议，其中{summary['drafts']}条有回复草稿，{summary['held']}条暂缓。全部尚未发送。

按本人地区证据、需求时效及原评论发表时间排序。只有帖子标题或正文提到古北，不能认定客户本人正在古北找房。本人地区明确的有{summary['own_region_confirmed']}位；缺帖子正文的有{summary['missing_body']}位，已逐条标记。

草稿采用已确认的住户账号口吻，统一称方隅公寓。没有替别人的房源承诺价格、库存、房型或具体优惠。评论发表时间、当前是否仍有需求及地区仍需审核；相对日期保留原始显示，不伪造绝对日期。意向强弱不等于当前可发送。

同客户及已回复、发送状态不明的保护记录已去重。完整身份、来源和判断证据保留在内部工作资料中。
''',encoding='utf8')
assert len({r['customer_uid'] for r in rows})==len(rows)
assert len({r['comment_id'] for r in rows})==len(rows)
assert all(not r['send_authorized'] and r['platform_requests']==0 and '古北' not in r['draft'] for r in rows)
assert all(not r['draft'] or len(r['draft'])<=200 for r in rows)
assert hashlib.sha256((WORK/'drafts.json').read_bytes()).hexdigest()==internal_hash
with (OUT/'待审核回复草稿.csv').open(encoding='utf-8-sig',newline='') as f:exported=list(csv.DictReader(f))
assert len(exported)==len(rows)==120
assert sum(bool(r['回复草稿']) for r in exported)==116
assert sum(r['状态']=='暂缓草稿' for r in exported)==4
for original,record in zip(rows,exported):
 assert record['客户原话']==original['comment_text'] and record['回复草稿']==original['draft']
 for cell in record.values():
  assert not re.search(r'\b[a-z]+(?:_[a-z]+)+\b|[A-Za-z]:[\\/]|\b[0-9a-f]{24,64}\b|\d{4}-\d\d-\d\dT\d\d:',cell),cell
 assert len(record['待核事项'].split('；'))==len(set(record['待核事项'].split('；')))
print(json.dumps(summary,ensure_ascii=False))
