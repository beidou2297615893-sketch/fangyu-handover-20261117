"""Import our explicitly checked initial probes into the separate local ledger.

Probe files retained the value and verified connection, rather than the complete
Bridge envelope. The wrapper reconstructed here is a derived record: each probe
only saved a file after checking both ok=true and exact connection equality.
"""
import json
from pathlib import Path
from ledger import Ledger

ROOT = Path(__file__).resolve().parent
SCAN = 'douyin-20261029-initial'
NAMES = ('first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'eleventh', 'twelfth', 'thirteenth', 'fourteenth', 'fifteenth', 'thirteenth-page2', 'ninth-rental', 'sixteenth')
ALIASES = {'上海古北店': '上海古北方隅服务公寓'}

def main():
    identity = json.loads((ROOT / 'identity-probe.json').read_text(encoding='utf-8'))
    strict_identity = json.loads((ROOT / 'identity-strict.json').read_text(encoding='utf-8'))
    if strict_identity['account']['sec_uid'] != identity['account']['sec_uid']:
        raise ValueError('account changed while switching services')
    connection_ids = {identity['connection_id'], strict_identity['connection_id']}
    ledger = Ledger(ROOT / 'runtime' / 'collection.sqlite3')
    results = []
    for name in NAMES:
        for kind in ('search', 'comments'):
            path = ROOT / f'{name}-{kind}-raw.json'
            if not path.exists():
                continue
            x = json.loads(path.read_text(encoding='utf-8'))
            if x['connection_id'] not in connection_ids or x['account_uid'] != identity['account']['sec_uid']:
                raise ValueError('probe identity or connection does not match')
            correction = x.get('source_correction', {})
            source_store = correction.get('store', x['store'])
            keyword = correction.get('keyword', x['keyword'])
            store = ALIASES.get(source_store, source_store)
            spec = {'request_id': f'initial-{name}-{kind}-0', 'account_uid': x['account_uid'],
                    'connection_id': x['connection_id'], 'kind': kind,
                    'target': keyword if kind == 'search' else x['video'], 'cursor': x.get('request_cursor', 0),
                    'rule_source': '用户授权及方隅双平台文本业务/15家门店关键词',
                    'scan_id': SCAN, 'store_id': store, 'keyword': keyword,
                    'source_file': path.name, 'source_timestamp': x['at'],
                    'envelope_provenance': 'derived: original probe checked ok and exact connection before saving value'}
            if correction:
                spec['eligibility'] = 'excluded_irrelevant'
                spec['source_correction_reason'] = correction['reason']
            response = {'ok': True, 'connection': x['connection_id'], 'value': x['response']}
            result = ledger.ingest(spec, response)
            results.append({'file': path.name, 'state': result['state'], 'added': result['added']})
            if result['state'] != 'parsed':
                print(json.dumps({'results': results, 'stopped': True}, ensure_ascii=False))
                return 1
    print(json.dumps({'results': results, 'summary': ledger.summary()}, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
