# 独立评论去重工具

已完成离线可用的独立 CLI，不需要联网或第三方依赖。支持 Windows Python 3.10 以上。只读原资料，不修改共享台账、原软件、账号或发送队列；不会调用平台或发送回复。

## 直接运行

在当前项目根目录的 PowerShell 中执行。输出文件夹必须尚不存在；重复运行请更换末尾文件夹名。

```powershell
python work/xhs-dedupe-standalone/dedupe.py --ledger work/shared-acquisition-ledger/shared.sqlite3 --output work/xhs-dedupe-standalone/work/我的第一次去重
```

继续导入时保留旧结果，将新旧证据合并到新文件夹：

```powershell
python work/xhs-dedupe-standalone/dedupe.py --ledger work/shared-acquisition-ledger/shared.sqlite3 --previous work/xhs-dedupe-standalone/work/我的第一次去重/result.json --output work/xhs-dedupe-standalone/work/我的第二次去重
```

导入 CLI 已保存的 JSON：将 `--ledger` 换成 `--input 评论.json`。支持多次使用 `--input` 和 `--ledger`，同时合并多个来源。仅支持明确的 JSON 数组或 `{"records": [...]}`，不递归猜测其他结构，不把 CSV、平台 API 或浏览器自动化接入此工具。

## 去重规则

- 相同平台、相同评论标识合成一条评论，保留每份不同原始记录、时间、来源和状态；不同评论不因属于同一用户而删除。
- 相同平台、相同平台用户 UID 分组。不同昵称可属于同一 UID；相同昵称不会自动合并；跨平台不会自动合并。
- JSON 评论标识字段支持 `comment_id`、`commentID`、`comment`；平台 UID 字段支持 `uid`、`UID`、`user_id`。标识必须是无首尾空白的字符串，不转换数字、不忽略大小写，避免大整数精度损失或误合并。
- `customer_id`、`customer` 仅是内部客户键，单独展示内部客户分组，不能当成平台 UID。现有真实共享台账没有平台 UID，本次不能确认跨账户的全局客户去重。
- 缺少平台或评论标识、同条记录存在互相冲突的评论标识进入待核；缺 UID 的有效评论仍保留，但客户身份待核。同评论的多个 UID、不同正文、帖子标识或内部客户键全部保留并标冲突。
- 原始记录完全相同时仅保留一次；同一来源重跑不增加数量。增量不删除旧证据，不按时间静默覆盖未知、冲突或已回复状态。来源文件路径变化视为不同来源保留。

## 回复状态的边界

JSON 中的 `status`、`reply_status`、`peer_reply`、`delivery_state` 必须代表回复/投递状态。`sent`、`replied` 保守视为已有回复；`reserved`、`in_progress`、`sending` 视为处理中；`unknown`、`submitted`、`prepared`、普通 `success`、空缺及其他无法解释的状态均待核。只有全部相关证据明确为 `none` 或 `unreplied` 才显示未回复；任何已回复或不明证据不会降成未回复。状态同时存在时依次保留已回复、处理中、未知的阻断含义，原状态不删除。

共享账本的 leads/reservations/historical_deliveries 直接保留其回复状态；评估原文和历史分析仅保留证据，不解析成当前平台回执。所有结果的 `send_authorized` 永远为 false，即使显示未回复也不等于可发送。当前平台状态、全部我方账号历史、身份映射、发送许可和回执仍须另外核实。

## 输出与衔接

每次新文件夹包含 `result.json`（完整机器结果）和 `summary.json`（数量）。输出只允许写到本独立工具文件夹之下，已存在文件夹拒绝覆盖。

`result.json` 含：comments 评论、customers 平台 UID 客户分组、internal_customer_groups 内部键分组、pending 待核原始记录、observations 全部去重后证据。客户分组只引用评论键，原始明细在评论内。冲突 UID 可同时关联两个候选客户，不能把分组评论数相加当成独立评论总数。

当前工具不写回台账、不创建预留、不升级审核、不修复身份映射、不挂接原软件。需要后续接入时，由软件代码窗口另行审核接口及写入授权，不能直接把本工具输出当作发送前置锁。不要手工删除旧证据后称增量完整，也不要将复制出来的台账作为第二个可写生产台账。

SQLite 使用只读 URI、query_only、一致性事务和一秒锁超时；不执行共享 ledger.py，不切换日志模式、不建表、不执行备份写入。遇锁直接失败，不能强制解锁、停止其他程序或复制运行中的主数据库冒充完整快照。

## 验证

```powershell
python -m unittest discover -s work/xhs-dedupe-standalone -v
```

14 组隔离测试通过，覆盖精确匹配、UID/昵称/跨平台隔离、冲突保留、缺稳定标识、未知/已回复阻断、非投递表状态隔离、增量幂等、只读 SQLite、独占锁失败、输出限制及拒覆盖。只在本目录内创建合成数据库和临时文件。实现先经历失败测试再实现；普通 success 错当回执和评估表状态混用的问题也先重现失败再修正。

真实共享账本只读验证：3,069 条不同评论、1,869 个内部客户组、平台 UID 客户组 0；4,943 份不同证据。另有1,869份客户历史分析不带评论键，保留在待核资料中；不是新增客户。3,069条评论回复状态全部待核，不能称未回复。重复增量结果完全一致，主数据库与 WAL 的 SHA-256 前后相同。证据在 `work/readonly-validation.json`；真实结果 `work/real-readonly-02/result.json`，含私有客户资料，仅供本地核查。

## 方案来源与限制

复用现有共享账本真实字段和 Python 标准库 SQLite/JSON。已核对本地既有 dedupeio/dedupe 与 Splink 候选方向，概率/模糊匹配不适合本次严格 ID 去重，因此未安装或导入它们。未触网安装、未调用远端服务。全量结果在内存聚合，当前三千评论规模验证通过，更大规模尚未压测；只支持已声明格式，不自动猜测平台导出结构。
