import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import pipeline
import one_click
from test_pipeline import record, answer


class CodexProviderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.exe = Path(self.temp.name) / 'codex.exe'
        self.exe.write_bytes(b'fixture-official-binary')
        self.sha = hashlib.sha256(self.exe.read_bytes()).hexdigest()
        self.account = {'role':'住户','facts_confirmed':True,'discount_confirmed':True,'allow_named_region':False}

    def tearDown(self): self.temp.cleanup()

    def provider(self, runner, probe=None, sha=None):
        return pipeline.CodexProvider(executable=self.exe, executable_sha256=sha or self.sha,
            runner=runner, auth_probe=probe or (lambda *a, **k:SimpleNamespace(returncode=0, stdout='Logged in using ChatGPT\n', stderr='')))

    def test_schema_and_prompt_forwarded_to_official_cli_without_network_tools(self):
        seen=[]
        def runner(args, **kw):
            seen.append((args,kw))
            schema=json.loads(Path(args[args.index('--output-schema')+1]).read_text(encoding='utf8'))
            self.assertEqual(schema['additionalProperties'],False)
            self.assertIn('target_comment_id',schema['required'])
            Path(args[args.index('-o')+1]).write_text(json.dumps(answer(),ensure_ascii=False),encoding='utf8')
            return SimpleNamespace(returncode=0, stdout='', stderr='')
        result=self.provider(runner).analyze(record(),self.account,[])
        self.assertEqual(result['reply'],answer()['reply'])
        argv,kwargs=seen[0]
        self.assertIn('--ignore-user-config',argv)
        self.assertIn('--ephemeral',argv)
        self.assertIn('--output-schema',argv)
        self.assertIn('features.shell_tool=false',argv)
        self.assertIn('web_search="disabled"',argv)
        self.assertIn('我想租古北一房',kwargs['input'])
        self.assertNotIn('OPENAI_API_KEY',kwargs['env'])

    def test_invalid_auth_hash_timeout_or_output_never_returns_draft(self):
        called=[]
        def runner(*a,**kw):called.append(1);return SimpleNamespace(returncode=0,stdout='',stderr='')
        with self.assertRaises(pipeline.ProviderError):
            self.provider(runner,probe=lambda *a,**kw:SimpleNamespace(returncode=1,stdout='',stderr='secret')).analyze(record(),self.account,[])
        self.assertEqual(called,[])
        with self.assertRaises(pipeline.ProviderError):self.provider(runner,sha='0'*64).analyze(record(),self.account,[])
        self.assertEqual(called,[])
        with self.assertRaises(pipeline.ProviderError):
            self.provider(lambda *a,**kw: (_ for _ in ()).throw(subprocess.TimeoutExpired('codex',1))).analyze(record(),self.account,[])
        with self.assertRaises(pipeline.ProviderError):self.provider(runner).analyze(record(),self.account,[])

    def test_semantically_invalid_result_is_refused(self):
        def runner(args,**kw):
            Path(args[args.index('-o')+1]).write_text(json.dumps(answer(own_evidence='不是本人原话'),ensure_ascii=False),encoding='utf8')
            return SimpleNamespace(returncode=0,stdout='',stderr='')
        with self.assertRaises(pipeline.ProviderError):self.provider(runner).analyze(record(),self.account,[])

    def test_one_click_selects_codex_without_deepseek_key(self):
        folder=Path(self.temp.name)
        account=folder/'account.json';account.write_text(json.dumps(self.account),encoding='utf8')
        style=folder/'style.json';style.write_text('[]',encoding='utf8')
        root=Path(__file__).resolve().parent.parent.parent
        argv=['one_click.py','--input',str(folder/'in.json'),'--output',str(folder/'out'),
              '--ledger',str(folder/'ledger.sqlite'),'--sender-uid','sender','--account',str(account),
              '--style',str(style),'--project-root',str(root),'--session-home',str(folder),
              '--execute','--provider','codex']
        obj=SimpleNamespace(model='gpt-6.1-sol')
        with mock.patch.object(sys,'argv',argv),mock.patch.dict('os.environ',{'DEEPSEEK_API_KEY':''}), \
             mock.patch.object(pipeline,'CodexProvider',return_value=obj), \
             mock.patch.object(one_click,'run_workflow',return_value={'selected':0}) as workflow, \
             mock.patch('builtins.print'):
            one_click.main()
        self.assertIs(workflow.call_args.kwargs['provider'],obj)

if __name__ == '__main__': unittest.main(verbosity=2)
