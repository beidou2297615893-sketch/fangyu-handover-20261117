# 历史候选年龄例外：离线候选补丁

本目录只供188及78流程自然结束后审查合入。活动发送源、真实账本、账号会话、state及marker未修改；未启动平台请求，也没有创建真实历史发送批次。

`original/`为取样时的发送源副本，`candidate/`为候选副本；`historical-age-only.patch`只涉及原年龄分支与可选授权字段。`verification.json`记录取样、候选和活动源哈希。

grant在原AuthorizedTargetIsolationPolicy字段之外，可选新增：

```json
{"historical_age_override":{"source_path":"历史候选JSONL的绝对路径","source_sha256":"a99c45c42b9118fef4056bc698a3e012ac30883328c032413d46d37340d87a23"}}
```

authorization继续保留当前UID、`source=user_direct_current_turn`和用户原话，并增加：

```json
{"send_all_authorized":true,"historical_over_60_days_authorized":true,"historical_priority":"after_recent_batches","historical_source_sha256":"a99c45c42b9118fef4056bc698a3e012ac30883328c032413d46d37340d87a23"}
```

prepared row无需添加字段。例外须同时匹配冻结批次、固定历史文件SHA、该条客户/UID/comment/note/text、原评论、标题和时间；仅对年龄超过60天的本地hold有效。已出租、身份冲突、时间未知、活动语义/事实hold及平台限制不会被该例外清除。无此完整资格时，所有旧任务仍保留60天hold。

历史文件180条均保留`review_notes_not_cleared=true`等原记录，`current_need_confirmed=false`不改变；只有明确“提供核实帮助、不断言库存/价格/地点/约看事实”的原冻结文案才可能移除年龄hold。这不是180条均可发送的证明。新准备批次仍须在78的真实complete、事件与权威账本一致、完整最新去重和连续撤销版本核对后生成，未知目标和已受理客户不得重发。

6项离线测试覆盖默认hold、明确历史授权、源或原文变化、标题/身份/时间hold、语义/事实hold和平台限制。测试只在本staging目录内写合成fixture，禁止socket连接；候选mapping函数从实际候选源码提取执行，未运行任何发送入口。

从本目录运行：

```powershell
& '../vendor/cli-runtime/Scripts/python.exe' -B -X utf8 -m unittest test_age_override -v
```

候选副本不是独立发送入口。合入前应重新核对活动源是否仍与baseline一致，合并后再由父任务检查整个发送与准备链；本目录没有自动合入或自动启动脚本。
