"""测试 461 停止逻辑。"""
import json
import os
import sys
import unittest
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SRC_DIR))

import resume007
from tests.fixture_builder import build_valid_fixture, create_ledger
from tests.fakes import FakeLive, FakeOnce, FakeScheduling, FakeClientFactory


class Test461Stop(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        self.resume006_root = self.project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
        self.resume006_root.mkdir(parents=True)
        self.ledger_dir = self.project / 'work/shared-acquisition-ledger'
        self.ledger_dir.mkdir(parents=True)
        self.ledger = self.ledger_dir / 'shared.sqlite3'
        create_ledger(self.ledger)
        self.stop_today = self.project / 'work/xhs-resume-20261103/stop-today-resume007.json'
        self.stop_today.parent.mkdir(parents=True)
        self.session_home = Path(self.tmp.name) / 'session-home'
        self.session_home.mkdir()
        self.here_dir = Path(self.tmp.name) / 'here'
        self.here_dir.mkdir()

        self.env = {
            'XHS_RESUME007_RESUME006_ROOT': str(self.resume006_root),
            'XHS_RESUME007_LEDGER': str(self.ledger),
            'XHS_RESUME007_STOP_TODAY': str(self.stop_today),
            'XHS_RESUME007_HERE': str(self.here_dir),
            'XHS_RESUME007_PROJECT': str(self.project),
        }
        for k, v in self.env.items():
            os.environ[k] = v

        # 客户端在第一次 comments 时返回 461
        self.live = FakeLive()
        self.once = FakeOnce()
        self.scheduling = FakeScheduling()
        self.client_factory = FakeClientFactory('test-uid', delay=6.0, fail_on_comment=1)
        resume007._LOAD = lambda: (self.live, None, self.once, self.scheduling)
        resume007._CLIENT_FACTORY = self.client_factory

        self.uid = '123456789012345678901234'
        build_valid_fixture(self.resume006_root, self.session_home, self.uid, self.here_dir)

    def tearDown(self):
        for k in self.env:
            os.environ.pop(k, None)
        resume007._LOAD = None
        resume007._CLIENT_FACTORY = None
        self.tmp.cleanup()

    def _run_main(self, args_list):
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            old_argv = sys.argv
            sys.argv = ['resume007.py'] + args_list
            try:
                code = resume007.main()
            finally:
                sys.argv = old_argv
        return code, f.getvalue().strip()

    def test_461_stops_and_writes_stop_today(self):
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home), '--execute'])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'stopped')
        # 检查新 ROOT 的 stop-today.json
        new_roots = [p for p in self.resume006_root.parent.iterdir() if p.name.startswith('stores15-resume007-')]
        self.assertEqual(len(new_roots), 1)
        new_root = new_roots[0]
        stop_file = new_root / 'stop-today.json'
        self.assertTrue(stop_file.exists())
        stop_data = json.loads(stop_file.read_text(encoding='utf-8'))
        self.assertIn('date', stop_data)
        # 检查固定 stop-today 标记
        self.assertTrue(self.stop_today.exists())
        fixed_stop = json.loads(self.stop_today.read_text(encoding='utf-8'))
        self.assertIn('date', fixed_stop)

    def test_same_day_restart_rejected(self):
        # 先执行一次触发 461，然后再次尝试应被拒绝
        self._run_main(['--uid', self.uid, '--session-home', str(self.session_home), '--execute'])
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'verification_stop_today')


if __name__ == '__main__':
    unittest.main()
