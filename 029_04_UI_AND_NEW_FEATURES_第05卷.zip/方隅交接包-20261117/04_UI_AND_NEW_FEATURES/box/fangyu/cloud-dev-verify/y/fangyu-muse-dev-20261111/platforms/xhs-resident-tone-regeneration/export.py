import json,csv
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
load=lambda p:json.loads(p.read_text('utf8'))
translations={'apartment_rejection':'本人可能不接受公寓，暂缓推荐','demand_time_unverified':'尚未确认目前是否仍在找房','possible_supply_not_demand':'可能包含出租或转租信息，需区分真实找房需求','post_body_not_collected':'帖子正文未采集','post_region_not_customer_region':'帖子地点不能代表本人想租的地区','region_unverified':'本人想租的地区尚不明确','rental_context_unverified':'租房相关上下文尚不完整','strong_intent_evidence_insufficient':'找房意愿较强，但证据仍不充分','super_high_action_unverified':'有看房或联系意愿，但尚未核实后续行动'}
def notes(row):
 vals=[]
 for n in row['review_notes']:
  n=translations.get(n,n).strip().rstrip('。；')
  if n in ('正文未采集','帖子正文未采集'):n='帖子正文未采集'
  if n.startswith('当前需求时效待核') or n=='未在线复核客户当前是否仍在找房':n='尚未确认目前是否仍在找房'
  if n.startswith('本人找房地区待核'):n='本人想租的地区尚不明确；帖子地点不能代表本人想租的地区'
  if n and n not in vals:vals.append(n)
 return '；'.join(vals)
rows=[r for p in sorted((P/'batches').glob('*/validated.json')) for r in load(p)]
manifest=load(P/'manifest.json')
out=ROOT/'outputs/新版住户口吻回复备案';out.mkdir(parents=True,exist_ok=True)
lines=['新版住户口吻回复阶段性备案','以下是本地生成的回复草稿，没有发送。','已分析评论：'+str(manifest['analysed_comments'])+'；等待分析：'+str(manifest['pending_analysis_comments']),'已完成草稿记录：'+str(len(rows)),'']
for i,r in enumerate(rows,1):
 lines.extend([f'第{i}位',f'本人留言：{r["comment_text"]}',f'回复草稿：{r["draft"] or "暂缓，不推荐"}',f'需留意：{notes(r)}',''])
(out/'全部回复草稿.txt').write_text('\n'.join(lines),encoding='utf8')
with (out/'全部回复草稿.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.writer(f);writer.writerow(['序号','本人留言','回复草稿','处理情况','留言时间','需留意','原帖链接'])
 for i,r in enumerate(rows,1):writer.writerow([i,r['comment_text'],r['draft'],'可供审看' if r['draft'] else '暂缓推荐',r.get('published_at',''),notes(r),'https://www.xiaohongshu.com/explore/'+r['note_id']])
state=load(P/'state.json');state.update(status='generation_completed_analysis_pending' if manifest['pending_analysis_comments'] else 'completed',pending_analysis_comments=manifest['pending_analysis_comments'],analysed_comments=manifest['analysed_comments']);(P/'state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
for p in (out/'全部回复草稿.txt',out/'全部回复草稿.csv'):
 text=p.read_text('utf-8-sig')
 if any(k in text for k in translations):raise ValueError('internal code leaked')
(P/'operation-record.md').write_text('''# 本轮本地操作记录

- 仅读取本人原评论、完整已完成分析及共享账本；未发平台请求、未发送、未写共享账本。
- 按用户新认可的自然简短住户口吻，用官方 Codex CLI 的 GPT-6.1 Terra Ultra 重新生成。先8条样例核验，再3并行扩批；旧草稿文本不复用。
- 覆盖既有887、恢复正文44、新增注册批0001至0018（1700条）、第0004批173条独立恢复。按comment_id合并，按真实UID及账本别名去重；历史已回复及未知/在途保护。
- 高及超高原文证据须逐字包含在本人原评论，目标ID、帖子ID、本人UID精确绑定；不匹配者不进入候选。
- 批007第一次25条中1条输出ID漏零，被严格校验拒绝；因整批重试已启动，未再另起单条任务，保留第一次原始输出为rejected-id-mismatch-raw.json。其余已完成批复用缓存。
- 来源及截止范围详见manifest.json，实际生成模型/耗时见各批meta.json；内容和身份核验见verification.json；每条完整原文、草稿及分析证据保存在validated.json。
- 全部发送前须重新检查实时账本保护及用户实际授权；本目录生成过程不进行发送。
''',encoding='utf8')
print(str(out/'全部回复草稿.txt'))
