# 今日发送计数候选：离线开发说明

本组件未接入现用程序，没有平台、网络、登录态或平台 SDK 依赖。没有登录、采集、发送、改动现用账本或解除停止状态。只提供读取与停机判断；不能把 `allowed_for_quota=True` 当成发送授权。

## 已核对的本机事实

2026-11-10 读取现有 `work/shared-acquisition-ledger/ledger.py`、`work/xhs-local-ledger-sender-candidate/production_sender.py`、`work/xhs-send-record-export/export_records.py`，并以 SQLite `mode=ro` + `query_only` 查询真实账本的表结构，没有查询真实客户正文、发送正文或任何凭据。

- `reservations`：`token` 主键，`platform/customer/comment/status/evidence/created`。`created` 是预留时间；outcome 更新不会记录完成时间，不能把它当作发送时间。
- `local_sender_plans`：`token` 主键，`data` JSON；发送者 UID 位于 `plan.sender_uid`。候选也识别 `local_mode.plan` 嵌套，但缺少 canonical 归属等关键事实会保守停止，不猜补。
- 平台受理结果存于 `result.kind='platform_receipt'`、`result.receipt_id`；原发送模块即使取得该回执，`reservations.status` 仍为 `unknown`。因此不能仅依据 status 判断成功，不能把所有 unknown 都统计成成功。
- 原导出模块从独立 `accepted` 事件获取 `at`；本组件沿用“账本回执 + 同 attempt/UID/receipt 的时间证据”交叉核对思路，不执行其导出或扫描真实事件。
- `leads` 和 `historical_deliveries` 可能包含旧提交。存在这些表时，对无法对应有效 reservation 的 `sent/unknown/reserved` 或历史 `submitted` 做去重聚合，视为无法归属的历史证据，阻止放行。

复用现有共享账本契约、Python 标准库 sqlite3 和 datetime，不新建第二个账号账本，不引入网络依赖。这是既有确定性 SQLite 路线的独立候选；本轮用户限定离线，没有进行外部选型、安装或联网检索。

## Python API

```python
from datetime import datetime
from quota import inspect_quota, BusinessRejectionGuard

snapshot = inspect_quota(
    shared_ledger_path,
    actual_sender_uid,
    now=datetime.fromisoformat('2026-11-10T12:00:00+08:00'),
    accepted_events=[{
        'event': 'accepted',
        'platform': 'xiaohongshu',
        'sender_uid': actual_sender_uid,
        'attempt_id': 'fixture-attempt',
        'receipt_id': 'fixture-receipt',
        'at': '2026-11-10T08:00:00+08:00',
    }],
    threshold=200,
    stop_signal=False,
)
```

调用方必须传入已核对的实际 sender UID，不能使用预期账号、账号名称或昵称代替。`accepted_events` 是调用方从可信、本地回执账本/事件中提供的安全字段投影；本组件不自行扫描目录、不读取 Cookie、不核验平台在线身份。事件必须显式带平台及带时区时间。回执代表平台受理，不证明公开可见。

返回不可变 `QuotaSnapshot`：

| 字段 | 含义 |
| --- | --- |
| `sender_uid/day/threshold` | 实际 UID、北京时间自然日、用户运营阈值 |
| `confirmed_sent_today` | 账本与受理时间证据一致的今日平台受理数；同一 attempt 重放只计一次 |
| `unknown_today/in_flight_today` | 按预留日单列的今日未知数/处理中数，绝不当作成功 |
| `unresolved_total` | 本账号全部未解决提交数，包括跨日未解决；会阻止继续 |
| `unassigned_total` | 无法归属账号或未映射历史提交的数量；会保守阻止所有账号 |
| `unconfirmed_receipts` | 本账号存在回执但无可靠受理时间证据的数目 |
| `remaining` | `max(0, threshold-confirmed_sent_today)` 的算术差，仅作已证实计数参考；证据不足时不表示可继续发送数量 |
| `allowed_for_quota/reasons` | 额度与证据是否没有阻止；排序后的停机原因代码 |

其他账号的已明确归属 unknown 不混入本账号配额；平台仅统计小红书。缺库、缺必要 schema、坏 JSON、归属冲突、回执冲突、事件缺失、无时区时间、未来时间和未知历史均保守阻止。无数据库时只读连接不会创建库。用户配置错误（空 UID、非正整数阈值、无时区 now）抛 `ValueError`，调用方应视为不可发送。

`200` 是用户运营阈值，并非平台官方限额，可配置且不自动切换账号。组件没有发送或换号功能。

```python
guard = BusinessRejectionGuard(limit=2)
guard.observe('business_rejection')
guard.observe('network_error')       # 不增加拒绝次数，也不清空已有拒绝证据
guard.observe('business_rejection')  # stopped=True
snapshot = inspect_quota(shared_ledger_path, actual_sender_uid,
                         accepted_events=projected_events,
                         stop_signal=guard.stopped)
```

调用方必须保守、明确分类业务拒绝，不能把超时、断网、一般 HTTP 错误猜成业务拒绝。`accepted/other` 清空连续拒绝计数；已 stopped 后仍保持 stopped，不因后来事件自动恢复。`guard` 本身是进程内辅助状态；实际任务若跨进程恢复，调用方必须从已有持久事件恢复或直接传入持久 stop 信号，不能靠重启清零绕过停止。

## 增量与防重边界

每次调用重新读取同一共享账本的一致快照，能看到新 token，也能看到旧 reserved token 更新为回执；不只依赖新增行高水位。调用方可将新增安全事件与已有事件集合合并后再次调用，同 attempt 的相同事件重放幂等，冲突重放停止。没有第二份持久计数，避免本机不同账号、不同批次因计数缓存分叉。复杂度约为共享小红书 reservation 数和输入事件数的线性量级，未做真实大规模性能基准。

此函数只读，不能解决“读取额度后另一进程又发送”的竞争。日后如接入真实发送，必须在原有共享账号锁和共享原子 reservation 约束内最终复核计数、账号身份、所有账号客户 UID 防重与未知记录；锁、提交和回执仍由原链路负责。本轮没有接入或修改它们。原所有账号共用账本的客户防重语义保持原样。

## 离线验收

- `red-quota.txt` 保留首次实现缺失时 12 个断言失败，以及新增安全行为测试在补实现前 4 项失败的真实输出。
- `green-quota.txt` 为当前 18 项合成 SQLite 测试通过；覆盖北京时间跨日、预留时间不能替代受理时间、UID 独立、平台限定、重复事件、重复回执、unknown/reserved、缺库/表/归属/时间、旧历史、冲突、旧 token 更新、阈值、拒绝停机、网络失败和文件只读。
- 测试使用临时合成 SQLite 数据；没有生产业务数据写入，没有真实平台验收。
- 可重跑：`python -B -m unittest -v test_quota`（在本文件所在目录）。候选整体整合测试由主任务汇总，本模块不冒称现用软件或全部候选已验收。
