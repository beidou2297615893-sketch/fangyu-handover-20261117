"""Offline exact-key deduplication. No platform calls or send permission."""
import argparse
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parent
PLATFORMS = {'xiaohongshu', 'douyin'}


def packed(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def values(row, names):
    found = []
    for name in names:
        value = row.get(name)
        if value is None or value == '':
            continue
        if not isinstance(value, str) or value != value.strip():
            raise ValueError('identifiers must be exact strings without surrounding whitespace: ' + name)
        if value not in found:
            found.append(value)
    return found


def reply_state(observations):
    states = []
    for row in observations:
        provenance = row.get('_provenance')
        table = provenance.get('table') if isinstance(provenance, dict) else None
        if table is not None and table not in ('leads', 'reservations', 'historical_deliveries'):
            states.append('unknown')
            continue
        fields = [row[k] for k in ('status', 'reply_status', 'peer_reply', 'delivery_state') if row.get(k) is not None]
        if not fields:
            fields = ['unknown']
        for value in fields:
            if value in ('sent', 'replied'):
                states.append('replied')
            elif value in ('reserved', 'in_progress', 'sending'):
                states.append('in_progress')
            elif value in ('none', 'unreplied'):
                states.append('unreplied')
            else:
                states.append('unknown')
    for state in ('replied', 'in_progress', 'unknown', 'unreplied'):
        if state in states:
            return state
    return 'unknown'


def aggregate(rows, previous=None):
    observations = {}
    if previous is not None:
        if previous.get('format_version') != 1 or not isinstance(previous.get('observations'), list):
            raise ValueError('unsupported previous result')
        rows = previous['observations'] + list(rows)
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('each record must be an object')
        observations[packed(row)] = row
    comments, pending = {}, []
    for fingerprint, row in sorted(observations.items()):
        platform = row.get('platform')
        ids = values(row, ('comment_id', 'commentID', 'comment'))
        values(row, ('uid', 'UID', 'user_id', 'customer_id', 'customer'))
        if platform not in PLATFORMS or len(ids) != 1:
            pending.append({'reason': 'missing_or_conflicting_platform_or_comment_id', 'observation': row})
            continue
        key = (platform, ids[0])
        comments.setdefault(key, []).append(row)
    result_comments, groups, internal_groups = [], {}, {}
    for key, obs in sorted(comments.items()):
        uids = sorted({v for row in obs for v in values(row, ('uid', 'UID', 'user_id'))})
        internal = sorted({v for row in obs for v in values(row, ('customer_id', 'customer'))})
        conflicts = []
        if len(uids) > 1:
            conflicts.append('uid')
        for field in ('text', 'content', 'note_id', 'post_id'):
            if len({packed(row[field]) for row in obs if row.get(field) not in (None, '')}) > 1:
                conflicts.append(field)
        if len(internal) > 1:
            conflicts.append('internal_customer_id')
        comment = dict(platform=key[0], comment_id=key[1], uids=uids,
                       internal_customer_ids=internal, observations=obs, conflicts=conflicts,
                       reply_state=reply_state(obs), needs_review=not uids or bool(conflicts),
                       send_authorized=False)
        result_comments.append(comment)
        for uid in uids:
            groups.setdefault((key[0], uid), []).append(comment)
        for customer in internal:
            internal_groups.setdefault((key[0], customer), []).append(comment)
    def grouped(mapping, id_field):
        return [dict(platform=k[0], **{id_field:k[1]}, comment_keys=[[c['platform'], c['comment_id']] for c in cs],
                     needs_review=any(c['needs_review'] for c in cs),
                     reply_states=sorted({c['reply_state'] for c in cs}), send_authorized=False)
                for k, cs in sorted(mapping.items())]
    return dict(format_version=1, observations=[observations[k] for k in sorted(observations)],
                comments=result_comments, customers=grouped(groups, 'uid'),
                internal_customer_groups=grouped(internal_groups, 'internal_customer_id'), pending=pending,
                summary=dict(observations=len(observations), comments=len(result_comments),
                             uid_customers=len(groups), internal_customer_groups=len(internal_groups),
                             pending=len(pending), conflicts=sum(bool(c['conflicts']) for c in result_comments)))


def read_ledger(path):
    """Read a consistent transaction; never execute ledger.py or its schema mutations."""
    path = Path(path).resolve(strict=True)
    result = []
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=1)) as db:
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')
        available = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'leads' not in available:
            raise ValueError('not a supported shared ledger: missing leads')
        for table in ('leads', 'assessments', 'reservations', 'historical_deliveries', 'historical_assessments', 'identity_aliases'):
            if table not in available:
                continue
            for item in db.execute('SELECT * FROM ' + table):
                row = dict(item)
                row['_provenance'] = {'file': str(path), 'table': table}
                # Ledger customer is an internal canonical key, never asserted to be platform UID.
                result.append(row)
        db.rollback()
    return result


def read_json(path):
    path = Path(path).resolve(strict=True)
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    records = data if isinstance(data, list) else data.get('records') if isinstance(data, dict) else None
    if not isinstance(records, list):
        raise ValueError('JSON requires an array or {"records": [...]}')
    result = []
    for row in records:
        if not isinstance(row, dict):
            raise ValueError('each record must be an object')
        row = dict(row)
        row['_provenance'] = {'file': str(path), 'original': row.get('_provenance')}
        result.append(row)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', action='append', default=[], help='JSON rows, repeatable')
    parser.add_argument('--ledger', action='append', default=[], help='shared SQLite, READ ONLY, repeatable')
    parser.add_argument('--previous', help='previous result.json for append-only evidence union')
    parser.add_argument('--output', required=True, help='new directory under this standalone project')
    args = parser.parse_args()
    if not (args.input or args.ledger):
        parser.error('at least one --input or --ledger is required')
    out = Path(args.output).resolve()
    if out == ROOT or not out.is_relative_to(ROOT):
        raise ValueError('output must be a new subdirectory of the standalone project')
    if out.exists():
        raise ValueError('output already exists; choose a new directory')
    rows = []
    for file in args.input:
        rows.extend(read_json(file))
    for file in args.ledger:
        rows.extend(read_ledger(file))
    previous = json.loads(Path(args.previous).read_text(encoding='utf-8-sig')) if args.previous else None
    result = aggregate(rows, previous)
    out.mkdir(parents=True, exist_ok=False)
    with (out/'result.json').open('x', encoding='utf-8') as file:
        json.dump(result, file, ensure_ascii=False, indent=2, allow_nan=False)
    with (out/'summary.json').open('x', encoding='utf-8') as file:
        json.dump(result['summary'], file, ensure_ascii=False, indent=2)
    print(packed(result['summary']))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, sqlite3.Error, json.JSONDecodeError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
