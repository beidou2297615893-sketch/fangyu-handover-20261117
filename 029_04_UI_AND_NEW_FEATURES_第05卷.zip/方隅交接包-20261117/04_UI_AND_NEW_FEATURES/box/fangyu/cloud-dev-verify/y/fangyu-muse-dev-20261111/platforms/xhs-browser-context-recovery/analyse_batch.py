import sys,json,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/xhs-context-lite-analysis'))
import run as m
SOURCE=Path(__file__).parent/'batch-001-ai-input.json'
OUTPUT=Path(__file__).parent/'analysis'
def main():
 rows=m.load(SOURCE)
 if len(rows)!=44 or len({r['comment_id'] for r in rows})!=44:raise ValueError('fixed review input changed')
 for row in rows:
  row['customer_id']=row.get('customer_id') or 'review_'+row['comment_id']
  row['context_missing']=bool(row.get('context_missing',not bool(row.get('post_text'))))
 OUTPUT.mkdir(exist_ok=True);m.OUT=OUTPUT
 original=m.make_payload
 def payload(records):
  data=original(records)
  for comment,row in zip(data['comments'],records):
   for key in ('date_display','region_display','region_display_is_ip_not_customer_demand','unread_media','text_evidence_available','unread_post_media','post_date_conflict','search_location_not_verified','own_reply_visible','send_authorized'):
    comment[key]=row.get(key)
  return data
 m.make_payload=payload
 m.ai.SYSTEM+='\n本批网页原文复核：显示IP不能推断本人找房区域；日期展示缺年份或采集锚点时不能猜精确日期或当前有效性；帖子正文入住日期10月20/30冲突应保留不确定，不替作者确定。媒体未读、空白或只有[图片]等不可当有效语义；搜索古北命中不能证明帖子或本人匹配古北。own_reply_visible=true表示我方历史回复已可见，必须保留跳过，绝不新发。原帖可能为求租帖，评论者大量在提供房源，严禁把作者求租分给所有评论者。所有记录send_authorized=false，只分类无草稿。'
 account=m.load(ROOT/'work/xhs-ai-standalone/account-leimu.json')
 m.save(OUTPUT/'state.json',{'status':'running','comments':0,'total':44,'send':False})
 try:
  data=m.execute_batch(0,rows,m.ai.CodexProvider(),account)
  byid={r['comment_id']:r for r in rows}
  for item in data:
   row=byid[item['comment_id']]
   for key in ('own_reply_visible','unread_media','unread_post_media','post_date_conflict','search_location_not_verified'):item[key]=bool(row.get(key))
   item['skip_historical_reply']=bool(row.get('own_reply_visible'))
   if item['skip_historical_reply']:item['review_reasons'].append('own_historical_reply_visible_skip')
  m.save(OUTPUT/'analysis.json',data)
  state={'status':'completed','comments':len(data),'total':44,'posts':len(set(r['note_id'] for r in rows)),'interest_counts':dict(collections.Counter(r['result']['interest'] for r in data)),'role_counts':dict(collections.Counter(r['result']['role'] for r in data)),'historical_reply_skip':sum(r['skip_historical_reply'] for r in data),'unread_media':sum(r['unread_media'] for r in data),'send':False}
  m.save(OUTPUT/'state.json',state);print(json.dumps(state),flush=True)
 except Exception as exc:
  m.save(OUTPUT/'state.json',{'status':'stopped','error_type':type(exc).__name__,'comments':0,'total':44,'send':False});raise
if __name__=='__main__':main()
