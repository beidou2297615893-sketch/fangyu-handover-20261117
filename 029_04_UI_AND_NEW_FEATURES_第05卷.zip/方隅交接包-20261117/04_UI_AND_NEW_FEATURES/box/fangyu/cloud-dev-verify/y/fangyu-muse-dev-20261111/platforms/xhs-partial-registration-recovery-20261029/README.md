# 中断采集快照的本地登记候选

这是独立本地恢复入口 `recover.py`。本轮只使用合成账本离线测试，没有平台请求、浏览器操作或正式账本写入，没有改正在运行的采集器、原第22批或其快照。实际第23批可能已重新读取旧快照中的评论，因此当前不能自动执行旧快照恢复；必须先逐条对账。

## 默认预览

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -u -B -X utf8 'work/xhs-partial-registration-recovery-20261029/recover.py' `
  --partial 'work/xhs-account-switch-recovery-candidate/runtime/resume-new10000-20261029-batch22/batch-0022/partial-0005.json' `
  --output 'work/xhs-partial-registration-recovery-20261029/runtime/batch22-local-recovery' `
  --ledger 'work/shared-acquisition-ledger/shared.sqlite3' `
  --source-db 'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'
```

预览只读账本和原文件，不建输出目录或运行锁，不写数据库；返回有效评论数量、可新增数量、现存每条评论的客户归属/状态/source和仍未登记的评论ID。旧partial的14条如果已被第23批全部登记，可新增为零，真实执行会拒绝重复登记或重复计数。

## 真实登记的要求

仅在本人正常重新登录后，由主任务做一次实时身份核验，明确同一采集UID且guest=false。该真实核验产生白名单回执：

```json
{"status":"verified","account":{"uid":"本次实际UID","guest":false},"proof_source":"same_client_user_me","verified_at":"带时区的实际核验时间"}
```

回执必须5分钟内，拒绝游客、不同UID、无时区、过期或未来异常时间。不能拿旧登录文件或用户说已进首页代替；此恢复器自身没有平台访问能力。实际登记在预览命令上追加 `--identity-receipt <真实核验回执路径> --execute --apply-to-shared-ledger`。输出目录必须全新且在本目录 `runtime` 内。

执行前核对原批确实在登记前停止、没有最终collection/登记回执、原source在账本为零、partial为该批最新快照、账号和目标一致。原文件哈希持久保存且临登记前复查。取得原全局采集锁后，创建同partial内容与账号的唯一持久认领；已认领不再执行。登记沿用原collector身份映射和register事务，生成新的collection副本和唯一source；不会覆盖原partial、不会创建帖子采完证明。

成功时只从本次新source逐条选出真正新增的评论，核对ID及原文/时间/属地一致后生成 `new-ai-input.json`、`registered-ready.json` 和 `analysis-manifest.jsonl`。pending/conflicts保留在快照副本中，不自动处理。计入一万目标的只是真正新增登记数；原采集器未知状态不被自动改成成功，也不自动跳页或重发平台请求。

如果登记可能已提交而回执/文件阶段失败，保存 `registration_outcome_unknown_check_ledger`，保留唯一认领，拒绝自动重试；先核对账本。已经被后续批次登记的评论只在预览列明，不增加本次计数。

## 验证

10项离线测试通过，覆盖：预览不变、有效评论与pending保留、来源及新增分析对账、身份不符/过期、原登记冲突、锁占用、同快照防重、提交后回执失败未知、后续批次已经登记一部分/全部。证据 `green.txt`；初始行为红测 `red.txt`，认领回执边界红测 `red-claim.txt`。所有测试用合成SQLite，socket连接禁止。

仍未做：实际本人重新登录回执的接入、真实共享账本执行验收、整个采集任务计数与恢复器计数的统一软件接线；原第22批pending还需分类或人工核对。不承诺恢复器能解决平台会话失效。

源文件完整路径：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-partial-registration-recovery-20261029/recover.py`

所在文件夹完整路径：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-partial-registration-recovery-20261029`
