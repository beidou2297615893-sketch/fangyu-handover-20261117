from pathlib import Path
import json
import re
import urllib.request
import urllib.parse
from html.parser import HTMLParser

OUT = Path(__file__).resolve().parent
URL = 'https://agree.xiaohongshu.com/h5/terms/ZXXY20220331001/-1'
request = urllib.request.Request(URL, headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(request, timeout=25) as response:
    content = response.read().decode('utf-8')
(OUT / 'official-terms-page.html').write_text(content, encoding='utf-8')
print(json.dumps({'url': URL, 'bytes': len(content)}, ensure_ascii=True))

# Public text-loading operation used by the official agreement page. No cookies.
query = urllib.parse.urlencode({'id': '-1', 'contractNo': 'ZXXY20220331001'})
endpoint = 'https://oacontract.xiaohongshu.com/oacontract/v1/contract/findContractContent?' + query
request = urllib.request.Request(endpoint, data=b'{}', method='POST', headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(request, timeout=25) as response:
    result = json.loads(response.read())
(OUT / 'official-terms-response.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
html = result.get('data', '')
assert result.get('statusCode') == 200 and isinstance(html, str), 'Public agreement retrieval failed'

class Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
    def handle_data(self, data):
        self.parts.append(data)
    def handle_endtag(self, tag):
        if tag in ('p', 'li', 'h1', 'h2', 'h3', 'div'):
            self.parts.append('\n')

parser = Text()
parser.feed(html)
plain = ''.join(parser.parts)
(OUT / 'official-terms-text.txt').write_text(plain, encoding='utf-8')
lines = [line.strip() for line in plain.splitlines() if line.strip()]
keys = ('更新日期', '平台使用规范', '第三方软件', '非法抓取', '账号违规处置', '永久封禁', '5.1', '封禁账号')
print(json.dumps({'public_endpoint_status': result.get('statusCode'), 'relevant_lines': [line for line in lines if any(key in line for key in keys)]}, ensure_ascii=True))
