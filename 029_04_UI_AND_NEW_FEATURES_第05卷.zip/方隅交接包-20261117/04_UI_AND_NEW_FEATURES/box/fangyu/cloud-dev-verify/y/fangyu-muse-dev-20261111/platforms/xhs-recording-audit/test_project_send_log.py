import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
import project_send_log as journal


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.ledger=self.root/'fixture.db';self.output=self.root/'journal.jsonl'
        with closing(sqlite3.connect(self.ledger)) as db, db:
            db.executescript('CREATE TABLE reservations(token TEXT,platform TEXT,customer TEXT,comment TEXT,status TEXT,created INTEGER);CREATE TABLE local_sender_plans(token TEXT,data TEXT);')
            self.plan={'sender_uid':'account','customer_uid':'customer','note_id':'note','comment_id':'comment','text':'方隅公寓可以看看～','attempt_id':'sensitive-attempt','canonical_customer':'canonical'}
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?)',('sensitive-attempt','xiaohongshu','canonical','comment','reserved',1793200000))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',('sensitive-attempt',json.dumps({'plan':self.plan,'result':None})))
    def tearDown(self):self.temp.cleanup()
    def accepted(self):
        with closing(sqlite3.connect(self.ledger)) as db, db:
            db.execute("UPDATE reservations SET status='unknown'")
            db.execute('UPDATE local_sender_plans SET data=?',(json.dumps({'plan':self.plan,'result':{'kind':'platform_receipt','receipt_id':'receipt','public_visibility_checked':False}}),))
    def test_idempotent_and_receipt_state_distinct(self):
        self.assertEqual(journal.sync(self.ledger,self.output)['new_records'],1)
        self.assertEqual(journal.sync(self.ledger,self.output)['new_records'],0)
        self.accepted();self.assertEqual(journal.sync(self.ledger,self.output)['new_records'],1)
        raw=self.output.read_text(encoding='utf8');items=[json.loads(s) for s in raw.splitlines()]
        self.assertEqual(len(items),2);self.assertIn('公开显示未核实',items[1]['状态'])
        self.assertNotIn('sensitive-attempt',raw)
    def test_failed_result_remains_unknown(self):
        with closing(sqlite3.connect(self.ledger)) as db, db:
            db.execute("UPDATE reservations SET status='unknown'")
            db.execute('UPDATE local_sender_plans SET data=?',(json.dumps({'plan':self.plan,'result':{'kind':'unknown','error_type':'TimeoutError','http_status':503}}),))
        journal.sync(self.ledger,self.output);row=json.loads(self.output.read_text(encoding='utf8'))
        self.assertIn('结果未知',row['状态']);self.assertEqual(row['HTTP状态'],503)
    def test_partial_tail_backed_up_and_replayed_once(self):
        journal.sync(self.ledger,self.output);self.accepted()
        with self.output.open('ab') as out:out.write(b'{"incomplete":')
        self.assertEqual(journal.sync(self.ledger,self.output)['new_records'],1)
        self.assertEqual(journal.sync(self.ledger,self.output)['new_records'],0)
        self.assertEqual(len(self.output.read_text(encoding='utf8').splitlines()),2)
        self.assertEqual(len(list(self.root.glob('journal.jsonl.interrupted.*'))),1)
    def test_identity_mismatch_writes_nothing(self):
        with closing(sqlite3.connect(self.ledger)) as db, db:db.execute("UPDATE reservations SET comment='different'")
        with self.assertRaises(ValueError):journal.sync(self.ledger,self.output)
        self.assertFalse(self.output.exists())
    def test_completed_corrupt_line_fails_closed(self):
        self.output.write_bytes(b'corrupt\n')
        with self.assertRaises(ValueError):journal.sync(self.ledger,self.output)
        self.assertEqual(self.output.read_bytes(),b'corrupt\n')
    def test_concurrent_writer_lock_does_not_duplicate(self):
        lock=self.root/'journal.jsonl.lock'
        with journal.lock_file(lock):
            with self.assertRaises(OSError):journal.sync(self.ledger,self.output)
        self.assertEqual(journal.sync(self.ledger,self.output)['new_records'],1)


if __name__=='__main__':unittest.main()
