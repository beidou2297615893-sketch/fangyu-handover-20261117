"""Independent xhs_cli one-attempt adapter. No original application imports."""
from __future__ import annotations
import json, os, subprocess, time
from dataclasses import dataclass, asdict
from pathlib import Path
import httpx
from xhs_cli.client import XhsClient

class Refused(RuntimeError): pass
class Unknown(RuntimeError): pass

@dataclass(frozen=True)
class FrozenReply:
 sender_uid: str
 customer_uid: str
 note_id: str
 comment_id: str
 text: str
 attempt_id: str
 authorized: bool
 verification_evidence: str
 valid_until: int
 source: str
 def validate(self):
  if self.authorized is not True: raise Refused('Exact reply authorization required')
  if any(not isinstance(v,str) or not v.strip() for v in (self.sender_uid,self.customer_uid,self.note_id,self.comment_id,self.text,self.attempt_id,self.verification_evidence,self.source)):
   raise Refused('Incomplete exact target and history verification')
  if type(self.valid_until) is not int or not time.time()<self.valid_until<=time.time()+300:
   raise Refused('Live verification expired or more than five minutes in future')

class SharedLedger:
 def __init__(self,script,db,python):
  self.script=Path(script).resolve();self.db=Path(db).resolve();self.python=python
 def command(self,*args):
  try:
   p=subprocess.run([self.python,'-B','-X','utf8',str(self.script),'--db',str(self.db),*args],capture_output=True,text=True,encoding='utf-8',timeout=40)
   value=json.loads(p.stdout)
  except Exception as exc:raise Refused('Ledger result unavailable; do not send') from exc
  if p.returncode!=0 or not isinstance(value,dict):raise Refused('Ledger refused operation')
  return value
 def reviewed_binding(self,p,status):
  snapshot=self.command('check','xiaohongshu',p.customer_uid,p.comment_id)
  target=snapshot.get('target');assessment=snapshot.get('assessment')
  exact={'platform':'xiaohongshu',**asdict(p)}
  def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)
  facts={'sender_uid':p.sender_uid,'customer_uid':p.customer_uid,'note_id':p.note_id,'comment_id':p.comment_id,'source':p.source,'all_account_history_checked':True,'target_and_peer_replies_checked':True,'user_authorized':True}
  if (not isinstance(target,dict) or not isinstance(assessment,dict) or
      target.get('platform')!='xiaohongshu' or target.get('comment')!=p.comment_id or
      target.get('status')!=status or target.get('evidence')!=p.verification_evidence or
      not isinstance(target.get('operator'),str) or not target['operator'].strip() or
      type(target.get('review_time')) is not int or not 0<=time.time()-target['review_time']<=300 or
      assessment.get('source')!=p.source or assessment.get('draft')!=p.text or
      assessment.get('intent')!='rental' or assessment.get('match')!='match' or assessment.get('peer_reply')!='none' or
      canonical(assessment.get('reply_binding'))!=canonical(exact) or
      canonical(assessment.get('verification_facts'))!=canonical(facts)):
   raise Refused('Reviewed ledger facts and exact authorization do not match reply plan')
  normalized=json.loads(canonical(snapshot));normalized['target']['status']='reviewed'
  for related in normalized.get('related',[]):
   if related.get('comment')==p.comment_id and related.get('status')==status:related['status']='reviewed'
  return canonical(normalized)
 def reserve(self,p):return self.command('reserve','xiaohongshu',p.customer_uid,p.comment_id,p.attempt_id)
 def outcome(self,p,state,evidence):return self.command('outcome',p.attempt_id,state,evidence)

class ControlledClient(XhsClient):
 def __init__(self,cookies,plan,transport=None):
  super().__init__(dict(cookies),request_delay=0,max_retries=1)
  self._http.close()
  self._http=httpx.Client(timeout=30,follow_redirects=False,transport=transport,trust_env=False)
  self.plan=plan;self._armed=False;self._post_started=False;self._identity_checked=False
 def _request_with_retry(self,method,url,**kwargs):
  if method=='GET' and url=='https://edith.xiaohongshu.com/api/sns/web/v2/user/me':
   if self._post_started:raise Refused('No requests after submission')
  elif method=='POST' and url=='https://edith.xiaohongshu.com/api/sns/web/v1/comment/post':
   self.plan.validate() # Last gate after signing and potentially slow ledger checks.
   expected={'note_id':self.plan.note_id,'content':self.plan.text,'target_comment_id':self.plan.comment_id,'at_users':[]}
   if not self._armed or not self._identity_checked or self._post_started or json.loads(kwargs.get('content','null'))!=expected:
    raise Refused('Frozen wire request mismatch or repeated attempt')
   self._post_started=True
  else:raise Refused('Endpoint outside independent one-attempt scope')
  response=self._http.request(method,url,**kwargs,follow_redirects=False)
  if response.status_code!=200:raise Unknown('Unexpected HTTP response; never retry')
  return response
 def identity(self):
  data=self.get_self_info()
  if not isinstance(data,dict):raise Refused('Identity response malformed')
  candidates=[]
  for obj in (data,data.get('user_info'),data.get('basic_info')):
   if isinstance(obj,dict):
    candidates.extend(obj[k] for k in ('user_id','userid','uid') if isinstance(obj.get(k),str) and obj[k])
  if not candidates or set(candidates)!={self.plan.sender_uid}:raise Refused('Measured identity does not match')
  self._identity_checked=True
 def send_once(self):
  return self.reply_comment(self.plan.note_id,self.plan.comment_id,self.plan.text)

class Runner:
 def __init__(self,ledger,client):self.ledger=ledger;self.client=client
 def submit(self,plan):
  with AccountLock(Path(__file__).resolve().parent/"account-locks",plan.sender_uid):
   return self._submit_locked(plan)
 def _submit_locked(self,plan):
  plan.validate()
  if plan!=self.client.plan:raise Refused('Frozen reviewed request changed')
  reviewed=self.ledger.reviewed_binding(plan,'reviewed')
  self.client.identity()
  reservation=self.ledger.reserve(plan)
  if reservation.get('granted') is not True:raise Refused('No unique shared reservation')
  try:
   plan.validate()
   if self.ledger.reviewed_binding(plan,'reserved')!=reviewed:raise Refused('Reviewed ledger changed during reservation')
   self.client._armed=True
   data=self.client.send_once()
   receipt=data.get('comment') if isinstance(data,dict) else None
   receipt_id=receipt.get('id') if isinstance(receipt,dict) else None
   if not isinstance(receipt_id,str) or not receipt_id.strip():raise Unknown('Missing receipt')
   # Conservative: a receipt is not independent platform readback.
   self.ledger.outcome(plan,'unknown','Receipt received, pending independent platform readback: '+receipt_id)
   return 'receipt_received'
  except BaseException as exc:
   try:self.ledger.outcome(plan,'unknown','Single attempt interrupted or unconfirmed; no automatic retry')
   except BaseException:pass # Existing reservation remains blocking even if recording fails.
   raise Unknown('Result unconfirmed; reservation remains blocked') from exc
  finally:self.client._armed=False

class AccountLock:
 """Windows process lock for all cooperating instances of this adapter."""
 def __init__(self,directory,sender_uid):
  import hashlib
  self.path=Path(directory)/('account-'+hashlib.sha256(sender_uid.encode()).hexdigest()+'.lock')
 def __enter__(self):
  import msvcrt
  self.path.parent.mkdir(parents=True,exist_ok=True)
  self.file=self.path.open('a+b');self.file.seek(0);self.file.write(b'0');self.file.flush();self.file.seek(0)
  try:msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
  except OSError:
   self.file.close();raise Refused('Account is busy in another independent CLI process') from None
  return self
 def __exit__(self,*args):
  import msvcrt
  self.file.seek(0);msvcrt.locking(self.file.fileno(),msvcrt.LK_UNLCK,1);self.file.close()

def load_independent_cookies(home):
 """Read only explicitly injected standalone HOME; no browser fallback/refresh."""
 from xhs_cli.constants import CONFIG_DIR_NAME,COOKIE_FILE
 home=Path(home).resolve()
 if home==Path(__file__).resolve().parent or not home.is_dir():raise Refused('Dedicated existing HOME required')
 for variable in ('HOME','USERPROFILE'):
  if not os.environ.get(variable) or Path(os.environ[variable]).resolve()!=home:raise Refused('Both HOME and USERPROFILE must name dedicated session directory')
 path=home/CONFIG_DIR_NAME/COOKIE_FILE
 if not path.is_file() or not path.resolve().is_relative_to(home):raise Refused('Independent login required; no browser fallback')
 try:data=json.loads(path.read_text('utf-8-sig'))
 except Exception as exc:raise Refused('Independent session unreadable') from exc
 if not isinstance(data,dict) or not all(isinstance(data.get(k),str) and data[k] for k in ('a1','web_session')):raise Refused('Independent session incomplete')
 return {k:v for k,v in data.items() if isinstance(v,str)}


def main(argv=None):
 import argparse, sys
 parser=argparse.ArgumentParser(description='Independent controlled single reply; preview by default')
 parser.add_argument('--plan',required=True)
 parser.add_argument('--execute',action='store_true')
 parser.add_argument('--session-home')
 args=parser.parse_args(argv)
 plan=FrozenReply(**json.loads(Path(args.plan).read_text('utf-8-sig')))
 plan.validate()
 if not args.execute:
  print(json.dumps({'mode':'preview','sender_uid':plan.sender_uid,'customer_uid':plan.customer_uid,'note_id':plan.note_id,'comment_id':plan.comment_id,'text':plan.text,'attempt_id':plan.attempt_id},ensure_ascii=False))
  return 0
 if not args.session_home:raise Refused('Dedicated session HOME required')
 cookies=load_independent_cookies(args.session_home)
 shared=Path(__file__).resolve().parents[1]/'shared-acquisition-ledger'
 ledger=SharedLedger(shared/'ledger.py',shared/'shared.sqlite3',sys.executable)
 client=ControlledClient(cookies,plan)
 try:result=Runner(ledger,client).submit(plan)
 finally:client.close()
 print(json.dumps({'result':result,'readback_verified':False},ensure_ascii=False))
 return 0

if __name__=='__main__':
 try:raise SystemExit(main())
 except (Refused,Unknown) as exc:
  print(json.dumps({'error':str(exc)},ensure_ascii=False));raise SystemExit(2)
