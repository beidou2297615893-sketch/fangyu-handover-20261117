"""Resume an identical local Codex batch; no platform or ledger access."""
import json
import argparse
import os
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/xhs-context-controlled'))
import context_pipeline

BASE = None
LOG = None
LOCK = threading.Lock()

def record(event, **fields):
    data = {'event': event, 'time': time.time(), **fields}
    with LOCK:
        with LOG.open('a', encoding='utf8') as stream:
            stream.write(json.dumps(data, ensure_ascii=False) + '\n')
        print(json.dumps(data, ensure_ascii=False), flush=True)

def safe_categories(text):
    value = (text or '').lower()
    return [name for name, terms in (
        ('authentication', ('unauthorized', 'authentication', 'login required', 'token expired')),
        ('rate_limit', ('rate limit', 'too many requests', '429')),
        ('network', ('connection', 'network', 'timed out', 'timeout', 'dns')),
        ('service', ('502', '503', '504', 'server error', 'overloaded')),
        ('schema', ('schema', 'invalid json', 'validation')),
    ) if any(term in value for term in terms)] or ['unclassified']

def run_logged(argv, **kwargs):
    call = uuid.uuid4().hex[:12]
    start = time.monotonic()
    record('model_started', call=call)
    try:
        result = subprocess.run(argv, **kwargs)
        record('model_returned', call=call, seconds=round(time.monotonic()-start, 2),
               returncode=result.returncode, stderr_present=bool(result.stderr),
               signal_categories=safe_categories(result.stderr) if result.returncode else [])
        return result
    except subprocess.TimeoutExpired:
        record('model_timeout', call=call, seconds=round(time.monotonic()-start, 2))
        raise
    except Exception as exc:
        record('model_process_error', call=call, exception_type=type(exc).__name__)
        raise

def main():
    global BASE, LOG
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', choices=('sample', 'larger43'), default='sample')
    args = parser.parse_args()
    BASE = ROOT / ('work/xhs-continuous-runner/work/live-20261028-sample/batch-0001/context-and-ai'
                   if args.batch == 'sample' else 'work/xhs-context-controlled/work/live-20261028-larger-43')
    LOG = Path(__file__).resolve().parent / (args.batch+'-recovery-events.jsonl')
    recovery_lock = BASE/'analysis/recovery.lock'
    descriptor = os.open(recovery_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with os.fdopen(descriptor, 'w', encoding='utf8') as stream:
        stream.write(json.dumps({'pid':os.getpid(), 'batch':args.batch}))
    try:
        return resume()
    finally:
        recovery_lock.unlink(missing_ok=True)

def resume():
    ai = context_pipeline._ai_module()
    checkpoint = json.loads((BASE/'analysis/checkpoint.json').read_text('utf-8-sig'))
    account = json.loads((ROOT/'work/xhs-ai-standalone/account-leimu.json').read_text('utf-8-sig'))
    style = json.loads((ROOT/'work/xhs-ai-standalone/style-leimu.json').read_text('utf-8-sig'))
    state = json.loads((BASE/'state.json').read_text('utf-8-sig'))
    state.update(status='started', phase='analysis', recovery=True)
    state.pop('reason', None)
    context_pipeline.save(BASE/'state.json', state)
    rows = json.loads((BASE/'ai-input.json').read_text('utf-8-sig'))
    completed = len(list((BASE/'analysis/completed').glob('*.json')))
    record('recovery_started', completed_before=completed, missing_before=len(rows)-completed, send=False, platform_requests=False)
    try:
        provider = ai.CodexProvider(runner=run_logged)
        ai.create_batch(BASE/'ai-input.json', BASE/'analysis', checkpoint['sender_uid'], account, style, provider)
        state.update(status='completed', phase='analysis')
        context_pipeline.save(BASE/'state.json', state)
        record('recovery_completed', send=False)
        return 0
    except Exception as exc:
        state.update(status='stopped', phase='analysis', reason=type(exc).__name__)
        context_pipeline.save(BASE/'state.json', state)
        record('recovery_stopped', exception_type=type(exc).__name__,
               timeout_message='超时' in str(exc), validation_message='未通过校验' in str(exc), send=False)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
