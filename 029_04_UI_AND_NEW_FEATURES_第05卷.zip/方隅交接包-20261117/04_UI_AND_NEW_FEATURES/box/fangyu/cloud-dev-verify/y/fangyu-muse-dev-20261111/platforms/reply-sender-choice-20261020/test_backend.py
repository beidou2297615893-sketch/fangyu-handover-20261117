from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
sys.path.insert(0,str(T.parent/'account-verification-entry/flow-audit'))
from test_delivery import DeliveryTests

def audit(event,args):
 if event in ('socket.connect','subprocess.Popen','os.system','os.startfile'):raise AssertionError('Forbidden external action: '+event)
sys.addaudithook(audit)
f=DeliveryTests(methodName='test_three_item_authorized_batch_completes_in_original_queue_order');f.setUp()
try:
 b=f.backend;c=b.core;a=c.store.get('accounts','fixture-account');a['platform_nickname']='昵称甲';a['name']='本地备注甲';a['remarks']='前台甲';c.store.put('accounts',a)
 read=b.dispatch('reply_read',{'storeId':'fixture-store-a','customerId':f.customer},f.token)['replyWorkspace'];assert read['comments'][0]['accounts'][0]['name']=='昵称甲';assert read['comments'][0]['accounts'][0]['platformNickname']=='昵称甲'
 item=f.draft();prepared=f.call('reply_delivery_prepare',items=[item]);assert prepared['items'][0]['accountName']=='昵称甲'
 # A later rename does not silently rewrite an already prepared, authorized snapshot.
 a['platform_nickname']='昵称变更后';c.store.put('accounts',a)
 status=f.call('reply_delivery_status',id=prepared['id']);assert status['items'][0]['accountName']=='昵称甲'
 assert not f.calls
 result={'status':'PASS','public_account_nickname':'PASS','prepared_sender_nickname':'PASS','saved_plan_identity_not_silently_relabelled':'PASS','real_platform_calls':0,'real_sends':0,'production_workspace_access':False}
 (T/'BACKEND-CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result))
finally:f.tearDown()
