"""Bounded, recoverable collection batches. Never sends platform messages."""
from __future__ import annotations
import argparse
from copy import deepcopy
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
COLLECT = ROOT / 'work/xhs-collection-candidate/collector.py'
REGISTER = ROOT / 'work/xhs-collection-candidate/register.py'
CONTEXT = ROOT / 'work/xhs-context-controlled/context_pipeline.py'
PYTHON = ROOT / 'work/vendor/cli-runtime/Scripts/python.exe'

class Stop(Exception):
    pass

def save(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('w', encoding='utf8') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.flush()
        os.fsync(out.fileno())
    os.replace(tmp, path)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def select_new(data, ledger, source, count):
    """Select only rows this exact registrar transaction inserted.

    Existing records are excluded by source, not guessed from an aggregate count.
    Matching customer+comment and count rejects mismatches before any AI access.
    """
    uri = Path(ledger).resolve(strict=True).as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True)) as db:
        inserted = db.execute('SELECT customer, comment FROM leads WHERE platform=? AND source=?',
                              ('xiaohongshu', 'collection:' + str(Path(source).resolve()))).fetchall()
    keys = set(inserted)
    if len(keys) != len(inserted) or len(keys) != count:
        raise Stop('登记结果与账本来源不一致，请先核对账本')
    selected = []
    for row in data['customers']:
        items = [row, *row.get('other_comments', [])]
        chosen = [item for item in items if (row['customer_id'], item['comment_id']) in keys]
        if not chosen:
            continue
        first = deepcopy(row)
        if chosen[0] is not row:
            for key, value in chosen[0].items():
                first[key] = deepcopy(value)
        first['other_comments'] = [deepcopy(item) for item in chosen[1:]]
        selected.append(first)
    found = {(row['customer_id'], item['comment_id']) for row in selected
             for item in [row, *row.get('other_comments', [])]}
    if found != keys:
        raise Stop('新增评论与采集来源不一致，请先核对账本')
    return selected

def invoke(command):
    result = subprocess.run([str(PYTHON), '-X', 'utf8', *map(str, command)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    if result.returncode != 0:
        raise Stop('子步骤失败；已停止，检查当前批次记录后再处理')

def run_batches(state, root, args, invoke_fn=invoke, selector=select_new):
    root = Path(root)
    statefile = root / 'state.json'
    def phase(name, **more):
        state.update(status='running', phase=name, **more)
        save(statefile, state)
    try:
        jobs = state.get('jobs') or [{'keyword':word,'page':1} for word in state['keywords']]
        for index in range(state['next_index'], len(jobs)):
            keyword, search_page = jobs[index]['keyword'], jobs[index]['page']
            batch = root / f'batch-{index+1:04d}'
            if batch.exists():
                raise Stop('批次目录已存在；请先核对账本及批次，避免重复执行')
            batch.mkdir()
            out = batch / 'collection'
            phase('collection', batch=index+1, search_page=search_page)
            invoke_fn([COLLECT, '--keyword', keyword, '--output', out,
                       '--session-home', args.session_home, '--sender-uid', args.sender_uid,
                       '--source-db', args.source_db, '--ledger', args.ledger,
                       '--max-notes', args.max_notes, '--max-pages', args.max_pages,
                       '--search-page', search_page, '--execute'])
            source = out / 'collection.json'
            if not source.is_file():
                raise Stop('采集结果缺失；请查看 partial 文件')
            data = read(source)
            phase('registration_preview')
            preview = batch / 'register-preview.json'
            common = [REGISTER, '--collection', source, '--ledger', args.ledger,
                      '--source-db', args.source_db, '--sender-uid', args.sender_uid]
            invoke_fn([*common, '--report', preview])
            expected = read(preview)['would_insert']
            phase('registration_commit', expected_new=expected)
            applied = batch / 'register-applied.json'
            invoke_fn([*common, '--apply', '--report', applied])
            actual = read(applied)['inserted']
            if actual != expected:
                raise Stop('预览与登记数量不一致，请先核对账本')
            phase('select_new', inserted=actual)
            chosen = selector(data, args.ledger, source, actual)
            selected = batch / 'new-ai-input.json'
            save(selected, chosen)
            if chosen:
                phase('context_and_ai', customers=len(chosen))
                invoke_fn([CONTEXT, '--collection', source, '--selected-input', selected,
                           '--output', batch / 'context-and-ai', '--session-home', args.session_home,
                           '--sender-uid', args.sender_uid, '--account', args.account, '--style', args.style,
                           '--analyse', '--execute'])
            state.setdefault('completed', []).append({'batch': index+1, 'keyword': keyword, 'search_page':search_page,
                'comments': data.get('summary', {}).get('usable_comments'), 'inserted': actual,
                'customers_for_analysis': len(chosen), 'truncated_posts': data.get('summary', {}).get('truncated_note_pages')})
            state.update(status='ready', phase='between_batches', next_index=index+1)
            save(statefile, state)
        state.update(status='completed', phase='complete')
        save(statefile, state)
    except Exception as exc:
        state.update(status='stopped', reason=str(exc) if isinstance(exc, Stop) else type(exc).__name__)
        save(statefile, state)
        raise

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--keyword', action='append', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--session-home');parser.add_argument('--sender-uid')
    parser.add_argument('--source-db');parser.add_argument('--ledger')
    parser.add_argument('--account');parser.add_argument('--style')
    parser.add_argument('--max-notes', type=int, default=20)
    parser.add_argument('--max-pages', type=int, default=2)
    parser.add_argument('--search-start-page', type=int, default=1)
    parser.add_argument('--search-pages', type=int, default=3)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--resume', action='store_true', help='仅从已完成批次之间的安全断点继续')
    args=parser.parse_args(argv)
    if any(not x.strip() or x != x.strip() for x in args.keyword) or len(set(args.keyword)) != len(args.keyword):
        raise Stop('关键词不能为空或重复')
    if not 1 <= args.max_notes <= 20 or not 1 <= args.max_pages <= 20:
        raise Stop('采集范围必须在1到20之间')
    if not 1 <= args.search_start_page <= 100 or not 1 <= args.search_pages <= 20 or args.search_start_page + args.search_pages - 1 > 100:
        raise Stop('搜索页范围不合法')
    if not args.execute:
        print(json.dumps({'mode':'preview','keywords':args.keyword,'network':False,'send':False,
                          'search_start_page':args.search_start_page,'search_pages':args.search_pages,
                          'note':'按指定搜索页逐批采集；分页排序可能变化，无法保证不漏帖'},ensure_ascii=False))
        return 0
    if not all((args.session_home,args.sender_uid,args.source_db,args.ledger,args.account,args.style)):
        raise Stop('缺少已有账号、账本、客户库或口吻配置')
    for item in (args.session_home,args.source_db,args.ledger,args.account,args.style):
        Path(item).resolve(strict=True)
    root=Path(args.output).resolve()
    binding = hashlib.sha256(json.dumps({
        'keywords':args.keyword,'session':str(Path(args.session_home).resolve()),
        'sender_uid':args.sender_uid,'source_db':str(Path(args.source_db).resolve()),
        'ledger':str(Path(args.ledger).resolve()),'account':str(Path(args.account).resolve()),
        'style':str(Path(args.style).resolve()),'max_notes':args.max_notes,'max_pages':args.max_pages,
        'search_start_page':args.search_start_page,'search_pages':args.search_pages,
    }, sort_keys=True, ensure_ascii=False).encode('utf8')).hexdigest()
    if args.resume:
        if not root.is_dir():raise Stop('断点目录不存在')
        state=read(root/'state.json')
        if state.get('binding') != binding or state.get('status') != 'ready' or state.get('phase') != 'between_batches':
            raise Stop('断点不安全或参数不一致；请先核对账本及批次')
    else:
        if root.exists():raise Stop('输出目录已存在；先核对已有状态')
        root.mkdir(parents=True)
        jobs=[{'keyword':word,'page':page} for word in args.keyword
              for page in range(args.search_start_page,args.search_start_page+args.search_pages)]
        state={'status':'ready','phase':'initial','keywords':args.keyword,'jobs':jobs,'next_index':0,'completed':[],
               'send':False,'automatic_retry':False,'binding':binding}
    # All copies of this launcher using the same ledger share one lock.
    # A stale lock after an abnormal exit must be inspected, not auto-deleted.
    lock=Path(args.ledger).resolve().parent/'.xhs-collection-runner.lock'
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    os.close(fd)
    save(root/'state.json',state)
    try:run_batches(state,root,args)
    finally:lock.unlink(missing_ok=True)
    print(json.dumps({'status':state['status'],'completed':state['completed']},ensure_ascii=False))
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (Stop,OSError,ValueError,sqlite3.Error) as exc:
        print('停止：'+(str(exc) if isinstance(exc,Stop) else type(exc).__name__),file=sys.stderr)
        raise SystemExit(2)
