"""Resume the frozen 15-store plan after local reconciliation; preview by default."""
import argparse,hashlib,html,json,os,sqlite3,sys,threading,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
sys.path.insert(0,str(PROJECT/'work/xhs-new-task-session-fix-20261029'))
from integration import load,client_factory
OLD_UID='5aa9b337e8ac2b4ab2d21957'
UID='5f469df5000000000101ec0b'
PRIOR=PROJECT/'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume004-20261030'
ROOT=PRIOR.parent/'stores15-resume006-20261103'
HOME=Path(os.environ.get('XHS_COLLECTION_SESSION_HOME',str(PROJECT/'work/xhs-standalone-session/stores15-ec0b-pending-20261103')))
LEDGER=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,d):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)
def reconcile():
    live,_,_,_=load()
    s=read(PRIOR/'state.json')
    if s['status']!='outcome_unknown' or s['cursor']!=15 or s['next_batch']!=21:raise ValueError('prior_state_changed')
    if (PRIOR/'scheduler.lock').exists() or (PRIOR/'.account-switch.lock').exists() or (HOME/'.managed-use.lock').exists():raise ValueError('active_lock')
    events=[json.loads(x) for x in (PRIOR/'analysis-manifest.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    if len(events)!=15 or len({x['batch'] for x in events})!=15:raise ValueError('manifest_count')
    total=0
    with sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        for i,e in enumerate(events):
            b=f'batch-{6+i:04d}';folder=PRIOR/b
            if e['batch']!=b or e['account_uid']!=OLD_UID or {'keyword':e['keyword'],'page':e['page']}!=s['plan'][i]:raise ValueError('manifest_scope')
            if hashlib.sha256((folder/'new-ai-input.json').read_bytes()).hexdigest()!=e['sha256']:raise ValueError('input_hash')
            selected=live.comment_rows(read(folder/'new-ai-input.json'));original=live.comment_rows(read(folder/'collection.json')['customers'])
            receipt=read(folder/'register-result.json');ready=read(folder/'registered-ready.json')
            binding=read(folder/'account-binding.json')
            source='collection:'+str((folder/'collection.json').resolve())
            rows=set(db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)))
            n=e['inserted_comments']
            if source!=e['registration_source'] or binding.get('uid')!=OLD_UID or binding.get('guest') is not False or receipt['account']!=binding or receipt['result']['inserted']!=n or ready.get('registered') is not True or ready.get('inserted_comments')!=n or rows!=set(selected) or len(rows)!=n or any(k not in original or v!=original[k] for k,v in selected.items()):raise ValueError('ledger_receipt_mismatch')
            total+=n
        empty=PRIOR/'batch-0021';failure=read(empty/'failure-diagnostic.json')
        if read(empty/'attempted-notes.json')!=[] or any((empty/n).exists() for n in ['collection.json','register-result.json','registered-ready.json','new-ai-input.json']):raise ValueError('interrupted_data_requires_reconciliation')
        if list(empty.glob('partial-*.json')) or db.execute("SELECT count(*) FROM leads WHERE source LIKE ?",('%stores15-resume004-20261030%batch-0021%',)).fetchone()[0]:raise ValueError('unknown_registration')
        if failure.get('platform',{}).get('endpoint')!='prewarm_onebox' or failure.get('platform',{}).get('http_status')!=461:raise ValueError('failure_changed')
    if total!=s['inserted'] or total!=3566:raise ValueError('count_mismatch')
    if s['inflight']['keyword']!=s['plan'][15]['keyword'] or s['inflight']['page']!=s['plan'][15]['page']:raise ValueError('inflight_scope')
    recovery=PROJECT/'work/xhs-partial-registration-recovery-20261029/runtime/stores15-resume005-batch22-recovery'
    event=json.loads((recovery/'analysis-manifest.jsonl').read_text(encoding='utf-8').strip())
    ready=read(recovery/'registered-ready.json');receipt=read(recovery/'register-result.json')
    if hashlib.sha256((recovery/'new-ai-input.json').read_bytes()).hexdigest()!=event['sha256']:raise ValueError('recovery_hash_changed')
    with sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro',uri=True) as db:
        rows=set(db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(event['registration_source'],)))
    selected=set(live.comment_rows(read(recovery/'new-ai-input.json')))
    if rows!=selected or len(rows)!=30 or event['inserted_comments']!=30 or receipt['result']['inserted']!=30 or ready.get('registered') is not True:raise ValueError('recovery_reconciliation_failed')
    previous=read(PRIOR.parent/'stores15-resume005-20261103'/'state.json')
    if previous['cursor']!=0 or previous['status']!='outcome_unknown':raise ValueError('resume005_state_changed')
    q=read(PROJECT/'work/xhs-15-store-collection-20261029/keyword-plan.json')
    if hashlib.sha256(Path(q['source_csv']).read_bytes()).hexdigest()!=q['source_csv_sha256']:raise ValueError('keyword_source_changed')
    scopes={(x['keyword'],x['page']):x for x in q['queue']}
    plan=s['plan'][15:]
    if not all((x['keyword'],x['page']) in scopes for x in plan):raise ValueError('plan_scope')
    return {'status':'locally_reconciled','prior_registered':total,'interrupted_batch_inserted':0,'next_batch':23,'partial_registered_preserved':30,'account_uid':UID,'remaining_pages':len(plan),'first':plan[0],'old_state_unchanged':True,'network':False},plan,scopes
def panel(done):
    out=PROJECT/'outputs/小红书15店采集进度';out.mkdir(parents=True,exist_ok=True)
    started=time.monotonic()
    while True:
        try:
            s=read(ROOT/'state.json');flight=s.get('inflight') or {}
            d={'账号':'玉米碴（慧慧酱）','状态':{'ready':'准备下一批','inflight':'采集中','outcome_unknown':'已停止，需核对本批结果','paused':'已暂停','plan_exhausted':'本段结束，待接续'}.get(s['status'],s['status']),'本轮新增入账':s.get('inserted',0),'已完成词页':s.get('cursor',0),'当前搜索词':flight.get('keyword',''),'耗时秒':int(time.monotonic()-started),'采集不等于已分类或已发送':True}
            put(HERE/'progress.json',d)
            doc='<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="5"><title>小红书15店采集</title><h1>小红书15店采集</h1><p>关闭页面不会停止采集。暂停请在本任务运行目录创建 STOP 文件。</p><pre>'+html.escape(json.dumps(d,ensure_ascii=False,indent=2))+'</pre>'
            tmp=out/'进度.tmp';tmp.write_text(doc,encoding='utf-8');os.replace(tmp,out/'进度.html')
        except (OSError,ValueError):pass
        if done.wait(2):
            if done.is_set():
                # One final pass after worker has saved its result.
                try:
                    s=read(ROOT/'state.json');d['状态']={'outcome_unknown':'已停止，需核对本批结果','paused':'已暂停','plan_exhausted':'本段结束，待接续'}.get(s['status'],s['status']);d['本轮新增入账']=s.get('inserted',0);put(HERE/'progress.json',d)
                    (out/'进度.html').write_text('<meta charset="utf-8"><h1>小红书15店采集</h1><pre>'+html.escape(json.dumps(d,ensure_ascii=False,indent=2))+'</pre>',encoding='utf-8')
                except (OSError,ValueError):pass
                return
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    evidence,plan,scopes=reconcile();put(HERE/'reconciliation-resume006.json',evidence)
    if not a.execute:print(json.dumps(evidence,ensure_ascii=False));return 0
    identity=read(HERE/'identity-check-resume006-verified.json')
    if identity.get('status')!='verified' or identity.get('uid')!=UID or Path(identity.get('session_home','')).resolve()!=HOME.resolve():raise ValueError('verified_new_account_required')
    # The execution client independently rechecks identity; this file is documentary only.
    live,candidate,once,scheduling=load();lock=HOME/'.managed-use.lock';lock.mkdir()
    done=threading.Event();thread=None
    try:
        ROOT.mkdir(exist_ok=False);live.write_new(lock/'owner.json',{'pid':os.getpid(),'task':'stores15-resume006-20261103','at':live.now()})
        config={'session_home':str(HOME),'ledger':str(LEDGER),'source_db':str(PROJECT/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3'),'shared_ledger':True,'max_comment_pages':2,'operator':'current_chat_15_store_collection_20261103','task':'15家门店续采'}
        live.write_new(ROOT/'task-config.json',{**config,'plan':plan,'expected_uid':UID,'send_authorized':False,'source_store_is_customer_assignment':False,'plan_exhaustion_is_overall_completion':False})
        live.write_new(ROOT/'continuation-receipt.json',evidence)
        scheduling.initialize(ROOT,plan,first_batch=23,target=2147483647)
        thread=threading.Thread(target=panel,args=(done,),daemon=True);thread.start()
        class Executor:
            def run(self,batch,keyword,page,remaining):
                scope=scopes[(keyword,page)];meta={k:scope.get(k) for k in ['source_store','city','round','source_csv_row']};meta.update(keyword=keyword,page=page,account_uid=UID,customer_store_assignment='unverified')
                live.write_new(ROOT/(batch+'-store-scope.json'),meta)
                result=live.LiveExecutor(ROOT,config,candidate,once,client_factory(UID,delay=3.0)).run(batch,keyword,page,remaining)
                live.append(ROOT/'store-analysis-manifest.jsonl',{'at':live.now(),'batch':batch,**meta,'inserted_comments':result['inserted'],'analysis_input':result['analysis_input'],'status':'registered_ready_for_classification'})
                print(json.dumps({'store':scope['source_store'],'new_registered':result['inserted'],'status':'registered'},ensure_ascii=False),flush=True)
                return result
        result=scheduling.run(ROOT,Executor());live.append(ROOT/'run-receipts.jsonl',{'at':live.now(),'status':result['status'],'new_registered':result.get('inserted',0),'inflight':result.get('inflight'),'automatic_retry':False})
        print(json.dumps({'status':result['status'],'new_registered':result.get('inserted',0)},ensure_ascii=False),flush=True)
        return 0 if result['status'] in ['paused','plan_exhausted'] else 2
    finally:
        done.set()
        if thread:thread.join(5)
        (lock/'owner.json').unlink(missing_ok=True);lock.rmdir()
if __name__=='__main__':raise SystemExit(main())
