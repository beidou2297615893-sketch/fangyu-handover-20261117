from contextlib import closing
from datetime import datetime,timezone,timedelta
import hashlib
import json
from pathlib import Path
import socket
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
import recover

HERE=Path(__file__).resolve().parent

def write(path,value): path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf8')

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=HERE/'runtime'); self.root=Path(self.tmp.name)
        self.batch=self.root/'original-run'/'batch-0022'; self.batch.mkdir(parents=True)
        self.ledger=self.root/'fixture.sqlite3'; self.source=self.root/'source.sqlite3'
        with closing(sqlite3.connect(self.ledger)) as db:
            db.executescript('''CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
            CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT);
            CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,PRIMARY KEY(platform,alias));
            CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,delivery_state TEXT);
            CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));''')
        with closing(sqlite3.connect(self.source)) as db: db.execute('CREATE TABLE records(entity TEXT,id TEXT,tenant_id TEXT,body TEXT)')
        self.uid='fixture-account'
        self.binding={'uid':self.uid,'guest':False,'nickname':'合成账号','proof_source':'same_client_user_me','verified_at':'2026-10-29T00:00:00+00:00'}
        self.customer='xhs_new_'+hashlib.sha256(b'xiaohongshu:fixture-customer').hexdigest()
        self.data={'schema':'xhs-collected-ai-input-v1','keyword':'古北找房',
            'collection_account':self.binding,'summary':{'customers':1,'usable_comments':2,'pending':1},
            'customers':[{'customer_id':self.customer,'customer_uid':'fixture-customer','comment_id':'comment-1',
                'note_id':'0123456789abcdef01234567','comment_text':'合成求租','published_at':'2026-10-28T01:02:03+00:00','ip_location':'上海',
                'other_comments':[{'comment_id':'comment-2','note_id':'0123456789abcdef01234567','comment_text':'第二条合成评论','published_at':'2026-10-28T01:03:04+00:00','ip_location':'上海'}]}],
            'pending':[{'note_id':'fedcba987654321001234567','reason':'missing_identity'}],'conflicts':[]}
        self.partial=self.batch/'partial-0005.json'; write(self.partial,self.data)
        write(self.batch/'account-binding.json',self.binding)
        (self.batch/'account-audit.jsonl').write_text(json.dumps({'status':'stopped_before_registration',
            'task':'古北本次新增一万条评论采集','keyword':'古北找房','search_page':5,'batch':'batch-0022',
            'operator':'unknown','account':self.binding,'at':'2026-10-29T00:00:10+00:00'})+'\n',encoding='utf8')
        write(self.batch/'failure-diagnostic.json',{'category':'request_or_local_stage_failed','platform':{'api_code':-100,'stage':'comments'}})
        self.identity=self.root/'verified-identity.json'
        write(self.identity,{'status':'verified','account':{'uid':self.uid,'guest':False},'proof_source':'same_client_user_me','verified_at':datetime.now(timezone.utc).isoformat()})
        self.output=self.root/'recovery-1'
        self.original_hash=hashlib.sha256(self.partial.read_bytes()).hexdigest()
        self.guard=patch.object(socket.socket,'connect',side_effect=AssertionError('Network forbidden')); self.guard.start()
    def tearDown(self): self.guard.stop(); self.tmp.cleanup()
    def go(self,execute=False,output=None,**kwargs):
        return recover.recover(self.partial,ledger=self.ledger,source_db=self.source,
            output=output or self.output,identity_receipt=self.identity,execute=execute,**kwargs)
    def count(self):
        with closing(sqlite3.connect(self.ledger)) as db: return db.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
    def test_preview_leaves_ledger_and_original_files_unchanged(self):
        result=self.go()
        self.assertEqual(result['status'],'preview'); self.assertEqual(result['would_insert'],2)
        self.assertFalse(self.output.exists()); self.assertEqual(self.count(),0)
        self.assertEqual(hashlib.sha256(self.partial.read_bytes()).hexdigest(),self.original_hash)
    def test_execute_registers_valid_comments_and_keeps_pending(self):
        result=self.go(True)
        self.assertEqual(result['status'],'registered'); self.assertEqual(result['inserted'],2)
        self.assertEqual(self.count(),2)
        data=json.loads((self.output/'collection.json').read_text(encoding='utf8'))
        self.assertEqual(data['pending'],self.data['pending']); self.assertEqual(data['collection_account'],self.binding)
        self.assertEqual(data['customers'][0]['published_at'],'2026-10-28T01:02:03+00:00')
        self.assertFalse((self.output/'completed-notes.json').exists())
        selected=json.loads((self.output/'new-ai-input.json').read_text(encoding='utf8'))
        self.assertEqual(selected[0]['comment_id'],'comment-1'); self.assertEqual(selected[0]['other_comments'][0]['comment_id'],'comment-2')
        manifest=[json.loads(x) for x in (self.output/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(manifest[0]['inserted_comments'],2); self.assertEqual(manifest[0]['original_batch'],'batch-0022')
        self.assertEqual(hashlib.sha256(self.partial.read_bytes()).hexdigest(),self.original_hash)
    def test_mismatched_or_stale_identity_refuses_before_registration(self):
        for entry in ({'status':'verified','account':{'uid':'different','guest':False},'proof_source':'same_client_user_me','verified_at':datetime.now(timezone.utc).isoformat()},
                      {'status':'verified','account':{'uid':self.uid,'guest':False},'proof_source':'same_client_user_me','verified_at':(datetime.now(timezone.utc)-timedelta(hours=1)).isoformat()}):
            write(self.identity,entry)
            with self.assertRaises(ValueError): self.go(True)
            self.assertEqual(self.count(),0); self.assertFalse(self.output.exists())
    def test_second_recovery_of_same_partial_is_refused(self):
        self.go(True)
        with self.assertRaises(ValueError): self.go(True,output=self.root/'recovery-2')
        self.assertEqual(self.count(),2)
    def test_original_registration_or_inflight_registration_refuses(self):
        with closing(sqlite3.connect(self.ledger)) as db:
            db.execute("INSERT INTO leads VALUES('xiaohongshu',?,'prior','unverified',?)",(self.customer,'collection:'+str((self.batch/'collection.json').resolve()))); db.commit()
        with self.assertRaises(ValueError): self.go(True)
        self.assertEqual(self.count(),1); self.assertFalse(self.output.exists())
    def test_existing_global_lock_prevents_registration(self):
        (self.ledger.parent/'.xhs-collection-runner.lock').mkdir()
        with self.assertRaises(ValueError): self.go(True)
        self.assertEqual(self.count(),0)
    def test_duplicate_claim_does_not_append_false_failure_to_completed_claim(self):
        self.go(True)
        claim_events=next((self.ledger.parent/'.xhs-partial-recovery-claims').glob('*/events.jsonl'))
        before=claim_events.read_bytes()
        with self.assertRaises(ValueError): self.go(True,output=self.root/'recovery-2')
        self.assertEqual(claim_events.read_bytes(),before)
    def test_preview_accounts_for_comments_already_registered_by_later_batch(self):
        with closing(sqlite3.connect(self.ledger)) as db:
            db.execute("INSERT INTO leads VALUES('xiaohongshu',?,'comment-1','unverified','collection:later-batch')",(self.customer,)); db.commit()
        result=self.go()
        self.assertEqual(result['would_insert'],1); self.assertEqual(result['already_present'],1)
        self.assertEqual(result['not_yet_registered_comment_ids'],['comment-2'])
        self.assertEqual(result['existing_comments'][0]['source'],'collection:later-batch')
        self.assertEqual(self.count(),1); self.assertFalse(self.output.exists())
    def test_all_comments_already_in_later_batch_refuses_write_and_new_count(self):
        with closing(sqlite3.connect(self.ledger)) as db:
            db.executemany("INSERT INTO leads VALUES('xiaohongshu',?,?,'unverified','collection:later-batch')",[(self.customer,'comment-1'),(self.customer,'comment-2')]); db.commit()
        result=self.go()
        self.assertEqual(result['would_insert'],0); self.assertEqual(result['already_present'],2)
        with self.assertRaisesRegex(ValueError,'no_new_comments_to_register'): self.go(True)
        self.assertFalse(self.output.exists()); self.assertEqual(self.count(),2)
    def test_commit_then_report_failure_is_unknown_and_never_repeated(self):
        registrar=recover.components()[2]
        original=registrar.register
        def committed_then_failed(*args,**kwargs):
            result=original(*args,**kwargs)
            if kwargs.get('apply'): raise OSError('SYNTHETIC SECRET NEVER LOG')
            return result
        with patch.object(registrar,'register',side_effect=committed_then_failed):
            with self.assertRaises(OSError): self.go(True)
        self.assertEqual(self.count(),2)
        text=(self.output/'recovery-audit.jsonl').read_text(encoding='utf8')
        self.assertIn('registration_outcome_unknown_check_ledger',text); self.assertNotIn('SYNTHETIC SECRET',text)
        with self.assertRaises(ValueError): self.go(True,output=self.root/'recovery-2')
        self.assertEqual(self.count(),2)

if __name__=='__main__': unittest.main()
