﻿param($out)
$R='C:\Users\rmsama\Documents\ChatGPT\自动获客系统'
$files=@()
foreach($d in 'work\xhs-new-task-session-fix-20261029','work\xhs-live-collection-runner-20261029','work\xhs-account-switch-recovery-candidate','work\xhs-safe-batch-scheduler-20261029'){
  $files += Get-ChildItem "$R\$d" -Recurse -Filter *.py -File | where { $_.FullName -notlike "$R\work\xhs-new-task-session-fix-20261029\runtime\*" }
}
$files += Get-Item "$R\work\shared-acquisition-ledger\shared.sqlite3"
$files += Get-ChildItem "$R\work\xhs-new-task-session-fix-20261029\runtime\live-tasks\stores15-resume006-20261103" -File
$files | sort FullName | % { (Get-FileHash $_.FullName -Algorithm SHA256).Hash + '  ' + $_.FullName.Substring($R.Length+1) } | Out-File -Encoding utf8 $out
