"""Receipt-qualified continuation; all files and SQLite records are synthetic."""
from contextlib import closing
from dataclasses import asdict, replace
from datetime import datetime, timedelta, timezone
import hashlib
import json
import sqlite3
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import bulk_run as bulk
import scoped_isolation as scope
import test_scoped_isolation as base


class Tests(unittest.TestCase):
    def setUp(self):
        self.base = base.Tests('test_default_closed_exact_grant_only_allows_bound_singleton_without_altering_old_rows')
        self.base.setUp()
        b = self.base
        self.proof_data = json.dumps({'plan': asdict(b.plan), 'result': {
            'kind': 'platform_receipt', 'receipt_id': scope.PROOF_RECEIPT_ID, 'public_visibility_checked': False}})
        self.plan = replace(b.plan, attempt_id='pending-attempt', customer_uid='pending-uid',
            canonical_customer='pending-customer', comment_id='pending-comment', note_id='pending-note')
        row = {'attempt_id': self.plan.attempt_id, 'customer_uid': self.plan.customer_uid,
            'customer_id': self.plan.canonical_customer, 'comment_id': self.plan.comment_id,
            'note_id': self.plan.note_id, 'text': self.plan.text}
        approved = bulk.read_json(b.approved)
        approved['rows'][0] = row
        b.approved.write_text(json.dumps(approved), encoding='utf8')
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                (scope.ALLOWED_ATTEMPT, 'xiaohongshu', b.plan.canonical_customer, b.plan.comment_id, 'unknown', 'receipt', 2))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)', (scope.ALLOWED_ATTEMPT, self.proof_data))
            db.execute('INSERT INTO leads VALUES(?,?,?,?,NULL,NULL,NULL,?)',
                ('xiaohongshu', self.plan.canonical_customer, self.plan.comment_id, 'unverified', 'synthetic'))
            db.commit()
        for path in (b.state, b.marker):
            state = bulk.read_json(path)
            state['halted_at'] = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
            path.write_text(json.dumps(state), encoding='utf8')
        self.event = b.root / 'accepted-proof.json'
        self.event.write_text(json.dumps({'event': 'accepted', 'sender_uid': b.uid,
            'at': datetime.now(timezone.utc).isoformat(), 'attempt_id': scope.ALLOWED_ATTEMPT,
            'receipt_id': scope.PROOF_RECEIPT_ID, 'diagnostic': {'success': True, 'http_status': 200,
                'api_code': 0, 'verification_header_present': False, 'message_category': 'unknown'}}), encoding='utf8')
        self.constants = patch.multiple(scope, APPROVED_SHA=bulk.digest(b.approved),
            STATE_SHA=bulk.digest(b.state), MARKER_SHA=bulk.digest(b.marker),
            PROOF_RECORD_SHA=hashlib.sha256(self.proof_data.encode()).hexdigest(), PROOF_EVENT_SHA=bulk.digest(self.event))
        self.constants.start()
        self.grant = scope.ReceiptQualifiedIsolationPolicy.from_mapping({
            'schema': 'xhs-receipt-qualified-unknown-isolation-v1',
            'policy_id': 'huihui-unknown8-receipt-qualified-approved567-v1', 'sender_uid': b.uid,
            'approved_batch_path': str(b.approved), 'approved_batch_sha256': bulk.digest(b.approved),
            'isolated_attempt_id': scope.ISOLATED_ATTEMPT, 'isolated_record_raw_sha256': scope.ISOLATED_RECORD_SHA,
            'platform_state_path': str(b.state), 'platform_state_sha256': bulk.digest(b.state),
            'halt_marker_path': str(b.marker), 'halt_marker_sha256': bulk.digest(b.marker),
            'proof_attempt_id': scope.ALLOWED_ATTEMPT, 'proof_record_raw_sha256': scope.PROOF_RECORD_SHA,
            'proof_receipt_id': scope.PROOF_RECEIPT_ID, 'proof_event_path': str(self.event), 'proof_event_sha256': bulk.digest(self.event)})
        b.sender.PREPARED_BATCH = b.approved

    def tearDown(self):
        self.constants.stop()
        self.base.tearDown()

    def reserve(self, grant=None):
        self.base.sender._reserve(self.base.db, self.plan, True, direct_id=True, scoped_isolation_policy=grant)

    def test_qualified_receipt_allows_pending_target_and_preserves_old_unknown(self):
        b = self.base
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(b.state, b.uid)
        bulk.require_platform_access(b.state, b.uid, scoped_grant=self.grant, batch_path=b.approved)
        state, marker = b.state.read_bytes(), b.marker.read_bytes()
        self.reserve(self.grant)
        with closing(sqlite3.connect(b.db)) as db:
            self.assertEqual(db.execute('SELECT data FROM local_sender_plans WHERE token=?',
                (scope.ISOLATED_ATTEMPT,)).fetchone()[0], b.old_data)
        self.assertEqual((b.state.read_bytes(), b.marker.read_bytes()), (state, marker))

    def test_bad_proof_hash_receipt_uid_or_changed_target_is_rejected(self):
        for bad in (replace(self.grant, proof_record_raw_sha256='0'*64),
                    replace(self.grant, proof_receipt_id='wrong'), replace(self.grant, sender_uid='wrong'),
                    replace(self.grant, proof_event_sha256='0'*64)):
            with self.assertRaises(self.base.sender.Refused):
                self.reserve(bad)
        batch = bulk.read_json(self.base.approved)
        batch['rows'][0]['text'] = 'changed text'
        self.base.approved.write_text(json.dumps(batch), encoding='utf8')
        with self.assertRaises(self.base.sender.Refused):
            self.reserve(self.grant)

    def test_native_proof_tampering_or_new_unknown_still_blocks(self):
        b = self.base
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('UPDATE local_sender_plans SET data=? WHERE token=?', ('{}', scope.ALLOWED_ATTEMPT))
            db.commit()
        with self.assertRaises(b.sender.Refused):
            self.reserve(self.grant)

    def test_new_halt_revokes_old_grants_even_when_primary_state_write_fails(self):
        b = self.base
        single = replace(b.grant, approved_batch_sha256=bulk.digest(b.approved),
            platform_state_sha256=bulk.digest(b.state), halt_marker_sha256=bulk.digest(b.marker))
        single.validate_context(b.singleton, b.uid)
        self.grant.validate_context(b.approved, b.uid)
        before = b.state.read_bytes(), b.marker.read_bytes()
        adapter = bulk.LiveAdapter.__new__(bulk.LiveAdapter)
        adapter.expected_uid = b.uid
        adapter.platform_access_state = b.state
        adapter.platform_access_state_digest = bulk.digest(b.state)
        adapter.initial_identity_receipt = None
        adapter._permanent_halt = False
        adapter.last_client = SimpleNamespace(_locked=False,
            managed_request_context={'request_started': True, 'stage': 'send'})
        def fail_primary(*args):
            raise OSError('synthetic primary write failure')
        adapter.halt_writer = fail_primary
        result = adapter.persist_platform_halt(RuntimeError('synthetic receipt with verification signal'),
            diagnostic={'success': True, 'http_status': 200, 'api_code': 0, 'verification_header_present': True},
            post_started=True)
        self.assertFalse(result['state_written'])
        self.assertTrue(result['emergency_marker_written'])
        self.assertEqual((b.state.read_bytes(), b.marker.read_bytes()), before)
        for policy, batch in ((single, b.singleton), (self.grant, b.approved)):
            with self.assertRaises(scope.ScopeRefused):
                policy.validate_context(batch, b.uid)
            with self.assertRaises(bulk.Stop):
                bulk.require_platform_access(b.state, b.uid, scoped_grant=policy, batch_path=batch)
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(b.state, b.uid)
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('UPDATE local_sender_plans SET data=? WHERE token=?', (self.proof_data, scope.ALLOWED_ATTEMPT))
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                ('new-unknown', 'xiaohongshu', 'other', 'other-comment', 'unknown', None, 3))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)', ('new-unknown', b.old_data))
            db.commit()
        with self.assertRaises(b.sender.Refused):
            self.reserve(self.grant)


if __name__ == '__main__':
    unittest.main()
