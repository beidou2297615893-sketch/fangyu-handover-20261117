import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
import successor

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf8')

class SuccessorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name); self.old=self.root/'old'; self.old.mkdir()
        self.db=self.root/'ledger.sqlite3'
        con=sqlite3.connect(self.db)
        con.execute('CREATE TABLE leads(platform TEXT,customer TEXT,comment TEXT,source TEXT)')
        con.close()
        self.words=self.root/'words.txt'; self.words.write_text('词一\n词二\n',encoding='utf8')
        self.queue=self.root/'queue.json'
        write(self.queue,{'source':str(self.words),'source_sha256':hashlib.sha256(self.words.read_bytes()).hexdigest(),
            'do_not_enable_new3000':True,'keywords':[{'keyword':'词一','initial_pages_if_never_searched':[1,2,3]},
            {'keyword':'词二','initial_pages_if_never_searched':[1,2,3]}]})
        self.make_old()
    def tearDown(self): self.tmp.cleanup()
    def make_old(self):
        write(self.old/'state.json',{'status':'plan_exhausted','inflight':None,'inserted':2,'target':10000,
            'cursor':1,'next_batch':24,'plan':[{'keyword':'旧词','page':5}]})
        write(self.old/'task-config.json',{'first_batch':23,'target':10000,'ledger':str(self.db),
            'session_home':'session','source_db':'source','shared_ledger':True,'max_comment_pages':2,'operator':None})
        folder=self.old/'batch-0023'; folder.mkdir(exist_ok=True)
        account={'uid':'account','guest':False}
        rows=[{'customer_id':'customer','customer_uid':'person','comment_id':'c1','comment_text':'A','note_id':'n'},
              {'customer_id':'customer2','customer_uid':'person2','comment_id':'c2','comment_text':'B','note_id':'n'}]
        write(folder/'account-binding.json',account)
        write(folder/'collection.json',{'collection_account':account,'customers':rows})
        write(folder/'register-result.json',{'account':account,'result':{'inserted':2}})
        write(folder/'registered-ready.json',{'registered':True,'account_uid':'account','inserted_comments':2,'input':'new-ai-input.json'})
        write(folder/'new-ai-input.json',rows)
        source='collection:'+str((folder/'collection.json').resolve())
        manifest={'batch':'batch-0023','keyword':'旧词','page':5,'account_uid':'account','inserted_comments':2,
            'input':'batch-0023/new-ai-input.json','sha256':hashlib.sha256((folder/'new-ai-input.json').read_bytes()).hexdigest(),
            'registration_source':source,'status':'registered_ready_for_classification'}
        (self.old/'analysis-manifest.jsonl').write_text(json.dumps(manifest)+'\n',encoding='utf8')
        con=sqlite3.connect(self.db);con.executemany('INSERT INTO leads VALUES(?,?,?,?)',
            [('xiaohongshu',r['customer_id'],r['comment_id'],source) for r in rows]);con.commit();con.close()
    def test_carries_count_and_next_batch_without_changing_predecessor(self):
        before=(self.old/'state.json').read_bytes()
        prepared=successor.prepare(self.old,self.queue,self.db)
        self.assertEqual(prepared['base_inserted'],2)
        self.assertEqual(prepared['remaining_target'],9998)
        self.assertEqual(prepared['first_batch'],24)
        self.assertEqual(prepared['plan'],[{'keyword':k,'page':p} for k in ['词一','词二'] for p in [1,2,3]])
        self.assertEqual((self.old/'state.json').read_bytes(),before)
    def test_refuses_inflight_or_paused_state(self):
        for status in ['inflight','paused','outcome_unknown']:
            d=json.loads((self.old/'state.json').read_text()); d['status']=status
            write(self.old/'state.json',d)
            with self.assertRaisesRegex(ValueError,'predecessor_not_completed'): successor.prepare(self.old,self.queue,self.db)
    def test_refuses_live_process_or_lock(self):
        with self.assertRaisesRegex(ValueError,'predecessor_still_running'):
            successor.prepare(self.old,self.queue,self.db,process_check=lambda _:True)
        (self.old/'scheduler.lock').mkdir()
        with self.assertRaisesRegex(ValueError,'collection_lock_busy'):
            successor.prepare(self.old,self.queue,self.db)
    def test_refuses_ledger_disagreement(self):
        con=sqlite3.connect(self.db);con.execute("DELETE FROM leads WHERE comment='c2'");con.commit();con.close()
        with self.assertRaisesRegex(ValueError,'registration_evidence_conflict'): successor.prepare(self.old,self.queue,self.db)
    def test_refuses_source_hash_change_or_new_word(self):
        self.words.write_text('changed',encoding='utf8')
        with self.assertRaisesRegex(ValueError,'authorized_source_changed'): successor.prepare(self.old,self.queue,self.db)

if __name__=='__main__': unittest.main()
