"""Independent sub-comment adapter for the existing PR 81 request shape.

The caller must supply a single-attempt client. This adapter neither retries
nor handles platform verification, and does not claim completeness.
"""

def read_subcomments(client, note_id, root_comment_id, xsec_token, *, cursor="", num=30):
    if any(not isinstance(x, str) or not x.strip() for x in (note_id, root_comment_id, xsec_token)):
        raise ValueError("The note, root comment and original access context are required")
    if not isinstance(cursor, str) or type(num) is not int or not 1 <= num <= 100:
        raise ValueError("Invalid pagination parameters")
    return client._main_api_get("/api/sns/web/v2/comment/sub/page", {
        "note_id": note_id,
        "root_comment_id": root_comment_id,
        "num": num,
        "cursor": cursor,
        "image_formats": "jpg,webp,avif",
        "top_comment_id": "",
        "xsec_token": xsec_token,
    })
