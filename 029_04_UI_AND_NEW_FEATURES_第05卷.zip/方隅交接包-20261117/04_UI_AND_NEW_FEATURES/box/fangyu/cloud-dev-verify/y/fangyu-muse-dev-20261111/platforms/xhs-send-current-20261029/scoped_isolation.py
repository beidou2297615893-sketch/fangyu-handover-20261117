"""One exact approved next target; no general stop-state clearance facility."""
from dataclasses import dataclass
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

SCOPED_UID = '5f469df5000000000101ec0b'
ISOLATED_ATTEMPT = '4c5c7b52-6558-4a64-b1c1-111fe6af42d1'
ALLOWED_ATTEMPT = 'b1d3326d-98e3-46a8-ab1c-1ddef6e287c1'
APPROVED_SHA = '5cc50b5e0e9dfd407e9899586102aa464e2adef96ef61f3155735dcdd851a31e'
SINGLETON_SHA = 'daaedc389747898d1a0fa7f134f8dea9e622bf1a086c91f44cc0fc1eb5b9d855'
ISOLATED_RECORD_SHA = '8c62140a954938c5acf85967d0c6752d1657dc68fddfcd970b6ba8cc92c04659'
STATE_SHA = 'e9c61593f315d978435c49b93a2944d02f4748ff5fd566f5546f77119f752715'
MARKER_SHA = '8f3cafcccef6c85e4773562fa122f69aa02373a2cc61e105770f114a731e7800'
PROOF_RECORD_SHA = '073dd2458dbc58a5287085341a45a97f0f1b13b905ca9b80b793e7f931ab17d1'
PROOF_RECEIPT_ID = '6ae6e97c000000001403ace8'
PROOF_EVENT_SHA = '38329ed423a71779c78130d8c9632c16db615e3d7559d48863fc93cd85ce0150'


class ScopeRefused(ValueError):
    pass


def revocation_path(marker_path):
    marker = Path(marker_path)
    return marker.with_name(marker.stem + '.revoked.json')


def reject_revoked(marker_path):
    revoked = revocation_path(marker_path)
    if revoked.exists() or revoked.is_symlink():
        raise ScopeRefused('scope_revoked_by_new_halt')


def known_restriction(value):
    if not isinstance(value, dict):
        return False
    if (value.get('error_type') in ('NeedVerifyError','SessionExpiredError','IpBlockedError','SignatureError') or
        value.get('verification_header_present') is True or
        value.get('http_status') in (461, 471, 429) or
        value.get('api_code') in (-100, 300012, 300015) or
        value.get('message_category') in ('verification', 'login', 'rate_limit', 'permission', 'signature')):
        return True
    return any(known_restriction(v) for v in value.values() if isinstance(v, dict))


def checked_json(path, expected):
    path = Path(path)
    if not path.is_absolute() or path.is_symlink():
        raise ScopeRefused('scope_path_invalid')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ScopeRefused('scope_evidence_changed')
    return json.loads(raw.decode('utf-8-sig'))


@dataclass(frozen=True)
class ScopedUnknownIsolationPolicy:
    schema: str
    policy_id: str
    sender_uid: str
    approved_batch_path: str
    approved_batch_sha256: str
    singleton_batch_sha256: str
    isolated_attempt_id: str
    isolated_record_raw_sha256: str
    allowed_attempt_id: str
    platform_state_path: str
    platform_state_sha256: str
    halt_marker_path: str
    halt_marker_sha256: str

    @classmethod
    def from_mapping(cls, value):
        if (not isinstance(value, dict) or set(value) != set(cls.__dataclass_fields__) or
            any(not isinstance(v, str) or not v for v in value.values())):
            raise ScopeRefused('scope_schema_invalid')
        return cls(**value)

    def validate_context(self, batch_path, sender_uid):
        if Path(__file__).with_name("retired-historical-scopes.json").exists():
            raise ScopeRefused("historical_scope_retired_after_retention_cleanup")
        reject_revoked(self.halt_marker_path)
        expected = {'schema': 'xhs-single-authorized-unknown-isolation-v1',
            'policy_id': 'huihui-unknown8-next-authorized-once-v1', 'sender_uid': SCOPED_UID,
            'approved_batch_sha256': APPROVED_SHA, 'singleton_batch_sha256': SINGLETON_SHA,
            'isolated_attempt_id': ISOLATED_ATTEMPT, 'isolated_record_raw_sha256': ISOLATED_RECORD_SHA,
            'allowed_attempt_id': ALLOWED_ATTEMPT, 'platform_state_sha256': STATE_SHA,
            'halt_marker_sha256': MARKER_SHA}
        if sender_uid != SCOPED_UID or any(getattr(self, k) != v for k, v in expected.items()):
            raise ScopeRefused('scope_binding_invalid')
        approved = checked_json(self.approved_batch_path, self.approved_batch_sha256)
        singleton = checked_json(batch_path, self.singleton_batch_sha256)
        for item, count in ((approved, 567), (singleton, 1)):
            if (not isinstance(item, dict) or item.get('schema') != 'xhs-local-plan-v1' or
                item.get('intended_account_uid') != sender_uid or item.get('count') != count or
                not isinstance(item.get('rows'), list) or len(item['rows']) != count):
                raise ScopeRefused('scope_batch_invalid')
        matches = [r for r in approved['rows'] if isinstance(r, dict) and r.get('attempt_id') == self.allowed_attempt_id]
        if (len(matches) != 1 or singleton['rows'] != matches or
            singleton.get('source_sha256') != approved.get('source_sha256')):
            raise ScopeRefused('scope_target_changed')
        for path, sha in ((self.platform_state_path, self.platform_state_sha256),
                          (self.halt_marker_path, self.halt_marker_sha256)):
            state = checked_json(path, sha)
            if (not isinstance(state, dict) or state.get('sender_uid') != sender_uid or
                state.get('state') != 'unknown_requires_reconciliation' or state.get('cleared') is not False or
                known_restriction(state)):
                raise ScopeRefused('scope_has_known_restriction_or_wrong_state')
        return matches[0]

    def permits(self, plan, old_row, batch_path, *, db=None):
        try:
            target = self.validate_context(batch_path, plan.sender_uid)
            if (old_row['token'] != self.isolated_attempt_id or old_row['status'] != 'unknown' or
                hashlib.sha256(old_row['data'].encode('utf8')).hexdigest() != self.isolated_record_raw_sha256):
                return False
            old = json.loads(old_row['data'])
            if known_restriction(old):
                return False
            fields = {'attempt_id': plan.attempt_id, 'customer_uid': plan.customer_uid,
                'customer_id': plan.canonical_customer, 'comment_id': plan.comment_id,
                'note_id': plan.note_id, 'text': plan.text}
            return all(target.get(k) == v for k, v in fields.items())
        except (ScopeRefused, OSError, ValueError, TypeError, KeyError, AttributeError):
            return False


@dataclass(frozen=True)
class ReceiptQualifiedIsolationPolicy:
    schema: str
    policy_id: str
    sender_uid: str
    approved_batch_path: str
    approved_batch_sha256: str
    isolated_attempt_id: str
    isolated_record_raw_sha256: str
    platform_state_path: str
    platform_state_sha256: str
    halt_marker_path: str
    halt_marker_sha256: str
    proof_attempt_id: str
    proof_record_raw_sha256: str
    proof_receipt_id: str
    proof_event_path: str
    proof_event_sha256: str

    @classmethod
    def from_mapping(cls, value):
        if (not isinstance(value, dict) or set(value) != set(cls.__dataclass_fields__) or
            any(not isinstance(v, str) or not v for v in value.values())):
            raise ScopeRefused('qualified_scope_schema_invalid')
        return cls(**value)

    def validate_context(self, batch_path, sender_uid):
        if Path(__file__).with_name("retired-historical-scopes.json").exists():
            raise ScopeRefused("historical_scope_retired_after_retention_cleanup")
        reject_revoked(self.halt_marker_path)
        expected = {'schema': 'xhs-receipt-qualified-unknown-isolation-v1',
            'policy_id': 'huihui-unknown8-receipt-qualified-approved567-v1', 'sender_uid': SCOPED_UID,
            'approved_batch_sha256': APPROVED_SHA, 'isolated_attempt_id': ISOLATED_ATTEMPT,
            'isolated_record_raw_sha256': ISOLATED_RECORD_SHA, 'platform_state_sha256': STATE_SHA,
            'halt_marker_sha256': MARKER_SHA, 'proof_attempt_id': ALLOWED_ATTEMPT,
            'proof_record_raw_sha256': PROOF_RECORD_SHA, 'proof_receipt_id': PROOF_RECEIPT_ID,
            'proof_event_sha256': PROOF_EVENT_SHA}
        if sender_uid != SCOPED_UID or any(getattr(self, k) != v for k, v in expected.items()):
            raise ScopeRefused('qualified_scope_binding_invalid')
        approved = checked_json(self.approved_batch_path, self.approved_batch_sha256)
        batch = checked_json(batch_path, self.approved_batch_sha256)
        if (approved != batch or not isinstance(batch, dict) or batch.get('schema') != 'xhs-local-plan-v1' or
            batch.get('intended_account_uid') != sender_uid or batch.get('count') != 567 or
            not isinstance(batch.get('rows'), list) or len(batch['rows']) != 567):
            raise ScopeRefused('qualified_scope_batch_invalid')
        halted = []
        for path, sha in ((self.platform_state_path, self.platform_state_sha256),
                          (self.halt_marker_path, self.halt_marker_sha256)):
            state = checked_json(path, sha)
            if (not isinstance(state, dict) or state.get('sender_uid') != sender_uid or
                state.get('state') != 'unknown_requires_reconciliation' or state.get('cleared') is not False or
                known_restriction(state)):
                raise ScopeRefused('qualified_scope_has_restriction')
            halted.append(state)
        event = checked_json(self.proof_event_path, self.proof_event_sha256)
        diagnostic = event.get('diagnostic') if isinstance(event, dict) else None
        if (not isinstance(event, dict) or event.get('event') != 'accepted' or
            event.get('sender_uid') != sender_uid or event.get('attempt_id') != self.proof_attempt_id or
            event.get('receipt_id') != self.proof_receipt_id or not isinstance(diagnostic, dict) or
            diagnostic.get('success') is not True or diagnostic.get('http_status') != 200 or
            diagnostic.get('api_code') != 0 or diagnostic.get('verification_header_present') is not False or
            known_restriction(diagnostic)):
            raise ScopeRefused('qualified_scope_proof_invalid')
        def timestamp(value):
            parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
            if parsed.tzinfo is None:raise ScopeRefused('qualified_scope_timestamp_invalid')
            return parsed
        proof_time = timestamp(event['at'])
        if (any(proof_time <= timestamp(state['halted_at']) for state in halted) or
            (proof_time - datetime.now(timezone.utc)).total_seconds() > 30):
            raise ScopeRefused('qualified_scope_proof_not_after_halt')
        return batch['rows']

    def permits(self, plan, old_row, batch_path, *, db=None):
        try:
            rows = self.validate_context(batch_path, plan.sender_uid)
            if (db is None or old_row['token'] != self.isolated_attempt_id or old_row['status'] != 'unknown' or
                hashlib.sha256(old_row['data'].encode('utf8')).hexdigest() != self.isolated_record_raw_sha256 or
                known_restriction(json.loads(old_row['data']))):
                return False
            proof = db.execute('SELECT r.status,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token '
                'WHERE r.token=? AND r.platform=?', (self.proof_attempt_id, 'xiaohongshu')).fetchone()
            if (not proof or proof['status'] not in ('unknown', 'sent') or
                hashlib.sha256(proof['data'].encode('utf8')).hexdigest() != self.proof_record_raw_sha256):
                return False
            record = json.loads(proof['data'])
            result, proof_plan = record.get('result', {}), record.get('plan', {})
            if (result.get('kind') != 'platform_receipt' or result.get('receipt_id') != self.proof_receipt_id or
                proof_plan.get('sender_uid') != self.sender_uid or proof_plan.get('attempt_id') != self.proof_attempt_id):
                return False
            def matches(target, candidate):
                fields = {'attempt_id': candidate['attempt_id'], 'customer_uid': candidate['customer_uid'],
                    'customer_id': candidate['canonical_customer'], 'comment_id': candidate['comment_id'],
                    'note_id': candidate['note_id'], 'text': candidate['text']}
                return all(target.get(k) == v for k, v in fields.items())
            target = [r for r in rows if r.get('attempt_id') == plan.attempt_id]
            proof_target = [r for r in rows if r.get('attempt_id') == self.proof_attempt_id]
            return (len(target) == len(proof_target) == 1 and matches(target[0], vars(plan)) and
                    matches(proof_target[0], proof_plan))
        except (ScopeRefused, OSError, ValueError, TypeError, KeyError, AttributeError):
            return False


def parse_isolation_policy(value):
    if isinstance(value, dict) and value.get('schema') == 'xhs-authorized-target-isolation-batch-v1':
        from target_isolation import AuthorizedTargetIsolationPolicy
        return AuthorizedTargetIsolationPolicy.from_mapping(value)
    if isinstance(value, dict) and value.get('schema') == 'xhs-two-unknown-new-tone-137-qualified-v1':
        from tone_batch import NewToneBatchReceiptPolicy
        return NewToneBatchReceiptPolicy.from_mapping(value)
    if isinstance(value, dict) and value.get('schema') == 'xhs-two-unknown-new-tone-singleton-v1':
        from tone_singleton import TwoUnknownToneSingletonPolicy
        return TwoUnknownToneSingletonPolicy.from_mapping(value)
    if isinstance(value, dict) and value.get('schema') == 'xhs-receipt-qualified-unknown-isolation-v1':
        return ReceiptQualifiedIsolationPolicy.from_mapping(value)
    return ScopedUnknownIsolationPolicy.from_mapping(value)
