"""Read-only handoff audit and explicit successor launch; no login or retry."""
import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
LIVE=PROJECT/'work/xhs-live-collection-runner-20261029/runner.py'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def lines(path):
    return [json.loads(x) for x in Path(path).read_text(encoding='utf8').splitlines() if x]
def now(): return datetime.now(timezone.utc).isoformat()
def write_new(path,value):
    with Path(path).open('x',encoding='utf8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.flush();os.fsync(stream.fileno())
def comments(rows):
    if not isinstance(rows,list): raise ValueError('registration_evidence_conflict')
    out={}
    for row in rows:
        if not isinstance(row,dict): raise ValueError('registration_evidence_conflict')
        for item in [row,*row.get('other_comments',[])]:
            key=(row.get('customer_id'),item.get('comment_id'))
            if not all(isinstance(x,str) and x for x in key) or key in out:
                raise ValueError('registration_evidence_conflict')
            out[key]=(row.get('customer_uid'),item.get('note_id'),item.get('comment_text'),
                      item.get('published_at'),item.get('ip_location'))
    return out

def audit_registered(root,ledger):
    root=Path(root).resolve(strict=True)
    state=read(root/'state.json'); config=read(root/'task-config.json')
    if (state.get('status') not in ('plan_exhausted','target_reached') or state.get('inflight') is not None
        or state.get('cursor')!=len(state.get('plan',[])) and state.get('status')!='target_reached'):
        raise ValueError('predecessor_not_completed')
    manifest=lines(root/'analysis-manifest.jsonl')
    if len(manifest)!=state['cursor'] or config.get('first_batch',0)+len(manifest)!=state.get('next_batch'):
        raise ValueError('registration_evidence_conflict')
    total=0; observed=set(); account_uid=None
    with closing(sqlite3.connect(Path(ledger).resolve(strict=True).as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        for index,event in enumerate(manifest):
            batch=f"batch-{config['first_batch']+index:04d}"
            folder=root/batch
            binding=read(folder/'account-binding.json'); receipt=read(folder/'register-result.json')
            ready=read(folder/'registered-ready.json'); collected=read(folder/'collection.json')
            selected=read(folder/'new-ai-input.json')
            expected=state['plan'][index]
            count=receipt.get('result',{}).get('inserted')
            source='collection:'+str((folder/'collection.json').resolve(strict=True))
            if (event.get('batch')!=batch or event.get('keyword')!=expected['keyword'] or event.get('page')!=expected['page']
                or type(count) is not int or count<0 or event.get('inserted_comments')!=count
                or event.get('status')!='registered_ready_for_classification' or event.get('registration_source')!=source
                or event.get('input')!=f'{batch}/new-ai-input.json'
                or event.get('sha256')!=hashlib.sha256((folder/'new-ai-input.json').read_bytes()).hexdigest()
                or binding.get('guest') is not False or not binding.get('uid')
                or event.get('account_uid')!=binding['uid'] or receipt.get('account')!=binding
                or collected.get('collection_account')!=binding or ready.get('registered') is not True
                or ready.get('account_uid')!=binding['uid'] or ready.get('inserted_comments')!=count
                or ready.get('input')!='new-ai-input.json'):
                raise ValueError('registration_evidence_conflict')
            if account_uid is not None and account_uid!=binding['uid']: raise ValueError('registration_evidence_conflict')
            account_uid=binding['uid']
            original=comments(collected.get('customers')); analysis=comments(selected)
            rows=db.execute("SELECT customer,comment FROM leads WHERE platform='xiaohongshu' AND source=?",(source,)).fetchall()
            if (len(rows)!=count or len(set(rows))!=count or set(rows)!=set(analysis)
                or any(key not in original or analysis[key]!=original[key] for key in analysis)
                or observed.intersection(rows)):
                raise ValueError('registration_evidence_conflict')
            observed.update(rows);total+=count
        db.rollback()
    if total!=state.get('inserted'): raise ValueError('registration_evidence_conflict')
    return state,config,manifest,account_uid

def authorized_queue(path):
    queue=read(path);source=Path(queue['source']).resolve(strict=True)
    if hashlib.sha256(source.read_bytes()).hexdigest()!=queue.get('source_sha256'):
        raise ValueError('authorized_source_changed')
    allowed={line.strip() for line in source.read_text(encoding='utf-8-sig').splitlines() if line.strip()}
    entries=queue.get('keywords')
    if queue.get('do_not_enable_new3000') is not True or not isinstance(entries,list) or not entries:
        raise ValueError('authorized_queue_invalid')
    words=[x.get('keyword') for x in entries]
    if len(set(words))!=len(words) or any(not isinstance(x,str) or x not in allowed for x in words):
        raise ValueError('authorized_queue_invalid')
    return queue,words

def history_pages(path,words):
    if path is None: return {word:set() for word in words}
    report=read(path); rows=report.get('keywords',report.get('results'))
    if not isinstance(rows,list): raise ValueError('history_review_invalid')
    result={}
    for row in rows:
        word=row.get('keyword')
        if word not in words: continue
        if row.get('unknown_attempts') or row.get('unresolved_attempts'):
            raise ValueError('history_unknown_requires_review')
        pages=row.get('trusted_success_pages',[])
        if any(type(x) is not int or not 1<=x<=100 for x in pages): raise ValueError('history_review_invalid')
        result[word]=set(pages)
    if set(result)!=set(words): raise ValueError('history_review_incomplete')
    return result

def prepare(predecessor,queue_file,ledger,*,process_check=lambda _:False,history_report=None):
    predecessor=Path(predecessor).resolve(strict=True)
    state=read(predecessor/'state.json')
    if state.get('status') not in ('plan_exhausted','target_reached') or state.get('inflight') is not None:
        raise ValueError('predecessor_not_completed')
    if process_check(predecessor): raise ValueError('predecessor_still_running')
    if (predecessor/'scheduler.lock').exists() or (Path(ledger).parent/'.xhs-collection-runner.lock').exists():
        raise ValueError('collection_lock_busy')
    state,config,manifest,uid=audit_registered(predecessor,ledger)
    queue,words=authorized_queue(queue_file)
    completed=history_pages(history_report,words)
    plan=[]
    for word in words:
        start=max(completed[word],default=0)+1
        plan.extend({'keyword':word,'page':page} for page in range(start,min(start+3,101)))
    return {'predecessor':str(predecessor),'base_inserted':state['inserted'],
        'target':state['target'],'remaining_target':max(0,state['target']-state['inserted']),
        'first_batch':state['next_batch'],'account_uid':uid,'plan':plan,
        'predecessor_config':config,'predecessor_manifest_count':len(manifest),
        'queue_source_sha256':queue['source_sha256'],'history_report':str(history_report) if history_report else None,
        'scope':'initial_three_page_coverage_not_overall_completion'}

def pids_alive(pids):
    if os.name!='nt': raise ValueError('windows_process_check_required')
    for pid in pids:
        if type(pid) is not int or not 1<=pid<2**31: raise ValueError('invalid_predecessor_pid')
        result=subprocess.run(['tasklist','/FI',f'PID eq {pid}','/FO','CSV','/NH'],
            capture_output=True,text=True,encoding='mbcs',errors='replace',
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=10)
        if result.returncode: raise ValueError('process_check_unavailable')
        if re.search(r'"'+str(pid)+r'"',result.stdout): return True
    return False

def live_module():
    spec=importlib.util.spec_from_file_location('successor_live_runner',LIVE)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result

def launch(prepared,root,ledger,*,runner=None):
    runner=runner or live_module();root=Path(root).resolve()
    runtime=PROJECT/'work/xhs-account-switch-recovery-candidate/runtime'
    if root==runtime or not root.is_relative_to(runtime.resolve()): raise ValueError('candidate_runtime_workspace_required')
    if prepared['remaining_target']<=0: return {'status':'target_reached','total_inserted':prepared['base_inserted']}
    root.mkdir(exist_ok=False)
    write_new(root/'predecessor-proof.json',prepared)
    config=prepared['predecessor_config']
    result=runner.run_task(root,prepared['plan'],session_home=config['session_home'],ledger=ledger,
        source_db=config['source_db'],target=prepared['remaining_target'],first_batch=prepared['first_batch'],
        shared_ledger=True,max_comment_pages=config['max_comment_pages'],operator=config.get('operator'))
    # This receipt does not reinterpret an unknown result as failure or success.
    total=prepared['base_inserted']+result.get('inserted',0)
    receipt={'at':now(),'status':result['status'],'base_inserted':prepared['base_inserted'],
        'local_inserted':result.get('inserted',0),'total_inserted':total,'global_target':prepared['target'],
        'automatic_retry':False,'next_batch':result.get('next_batch'),'inflight':result.get('inflight')}
    write_new(root/'cumulative-receipt.json',receipt)
    return receipt

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--predecessor',required=True)
    parser.add_argument('--queue',required=True)
    parser.add_argument('--history-report')
    parser.add_argument('--run-home',required=True)
    parser.add_argument('--predecessor-pid',action='append',type=int,default=[])
    parser.add_argument('--wait',action='store_true')
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--apply-to-shared-ledger',action='store_true')
    args=parser.parse_args(argv)
    old=Path(args.predecessor).resolve(strict=True)
    ledger=Path(read(old/'task-config.json')['ledger']).resolve(strict=True)
    if args.execute and (not args.predecessor_pid or not args.apply_to_shared_ledger or not args.history_report):
        raise ValueError('explicit_execution_inputs_required')
    while True:
        state=read(old/'state.json')
        waiting=state.get('status') in ('inflight','ready') or state.get('status') in ('plan_exhausted','target_reached') and (
            (old/'scheduler.lock').exists() or pids_alive(args.predecessor_pid) if args.predecessor_pid else (old/'scheduler.lock').exists())
        if not args.execute or not args.wait or not waiting: break
        if (Path(args.run_home).parent/'STOP').exists(): raise ValueError('user_pause_marker_present')
        time.sleep(2)
    prepared=prepare(old,args.queue,ledger,history_report=args.history_report,
        process_check=(lambda _:pids_alive(args.predecessor_pid)) if args.predecessor_pid else (lambda _:False))
    if not args.execute:
        print(json.dumps({'mode':'preview','network':False,'ledger_write':False,**prepared},ensure_ascii=False));return 0
    result=launch(prepared,args.run_home,ledger)
    print(json.dumps(result,ensure_ascii=False));return 0 if result['status'] in ('target_reached','plan_exhausted','paused') else 2

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception:
        print(json.dumps({'status':'stopped','automatic_retry':False,'reason':'inspect_successor_inputs_or_receipts'}))
        raise SystemExit(2) from None
