﻿import socket, sys, os, json
ATT = []
def _blk(self, addr, *a, **k): ATT.append(repr(addr)); raise OSError('blocked')
socket.socket.connect = _blk; socket.socket.connect_ex = _blk
_cc = socket.create_connection
def _ccb(addr, *a, **k): ATT.append('cc ' + repr(addr)); raise OSError('blocked')
socket.create_connection = _ccb
sys.path.insert(0, os.getcwd())
import resume007 as m
UID = '5f469df5000000000101ec0b'
SH = r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-standalone-session\yumicha-login-20261109-02'
m._get_verified_identity = lambda uid, sh: {'uid': UID}
CF = []
sys.path.insert(0, r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-new-task-session-fix-20261029')
import integration
def _spy(*a, **k): CF.append(1); raise RuntimeError('client_factory called')
integration.client_factory = _spy
HI = []
orig_rt = m._get_runtime
def rt():
    live, cand, once, sched, cf = orig_rt()
    oh = once.history_index
    def hi(*a, **k): HI.append(1); return oh(*a, **k)
    once.history_index = hi
    return live, cand, once, sched, cf
m._get_runtime = rt
rc = m.main(['--uid', UID, '--session-home', SH, '--delay', '10'])
print('rc =', rc, ' client_factory calls =', len(CF), ' history_index calls =', len(HI), ' network attempts =', ATT)
