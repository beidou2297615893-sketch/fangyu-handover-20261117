from pathlib import Path
import json,hashlib,datetime
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/reply-sender-choice-20261020');P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration';N=P/'work/ui-native-r57';S=F/'stage-02/project';plan=json.loads((F/'entry-v39/CANONICAL-DELEGATION-PREPARED.json').read_text('utf-8-sig'));release=Path(plan['release']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
assert sha(N/'run_workbench.py')==plan['launcher_sha256'];assert sha(N/'state/production-workspace.json')==plan['workspace_binding_sha256']
for n in ['reply-connected.mjs','reply-batch.mjs','reply-delivery.mjs','reply-account.mjs','reply.css']:assert (release/'web/pages'/n).read_bytes()==(S/'work/ui-approved-implementation/ui-preview/pages'/n).read_bytes(),n
for n in ['reply_workbench.py','reply_delivery.py']:assert (release/n).read_bytes()==(S/'work/ui-native-r57'/n).read_bytes(),n
result={'status':'INSTALLED_SOURCE_VERIFIED','release_id':plan['release_id'],'canonical_sha256':sha(N/'run_workbench.py'),'closure_files':2733,'release_check_files':137,'changed_source_files':7,'uniform_sender_required':True,'nickname_projection_verified':True,'stale_preview_rejected':True,'single_changed_sender_requires_review':True,'batch_cancel_unknown_scope_regressions':'PASS','native_UI':'NOT_REOPENED_OR_VISUALLY_VERIFIED','real_platform_requests':0,'real_sends':0,'production_data_migration':False}
(T/'FINAL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
text='''发送账号改造已接原入口（v39）。
- 单条“核对账号”改“发送账号”，移到回复编辑区顶部，突出平台昵称；选择框18px、昵称20px，员工/客户SOP入口18px加粗、高对比，窄面板允许换行。
- 批量工具栏新增独立“批量发送账号”，必须明确选择；捕获账号ID应用整批，没有不可用时退回其他账号。预览与最终授权都再次突出发送账号昵称，结果列表也显示账号。
- 中途改批量账号使旧预览失效；单条改账号后旧账号审核不能直接准备发送。保留逐条核对、最终授权、未知结果防重与跨账号保护。
- 先RED后GREEN：初始无统一账号时仍读取客户为2、预期0；修改后通过。单条/批量界面render/bind、取消/未知锁、平台切换及刷新回归通过；隔离后台nickname投影和准备后快照昵称保持通过。未触发真实平台/AI/发送。
- 源码及发布逐字节一致，2733 closure/137 release --check通过；canonical SHA3BE27375F3FFA9D34C7891A25B9DD78109F8B692E62818A7CE67D7353FD8B44A；entry-v39/canonical-entry-before备份v38。绑定hash未改，未动会话/断点/数据库。
- 未关闭或重启用户当前客户端，最新真实窗口待用户保存草稿后重开原入口查看。不能把隔离检查当实窗/真实发送验证。原夜间整体验证goal仍blocked，不标complete；旧监控原rrule已截止北京时间08:00，未恢复或新增。
'''
(T/'CONTINUE.md').write_text(text,encoding='utf-8')
with (T.parent/'overnight-verification/CONTINUE.md').open('a',encoding='utf-8') as h:h.write('\n## 2026-10-20 上午用户新要求：发送账号明确化\n'+text+'\n详见work/reply-sender-choice-20261020/FINAL.json与CONTINUE.md；旧v38最新入口指针已被v39取代，下一变更before必须v39。\n')
session=P/'memory/sessions/2026-10-20-reply-sender-choice.md';session.parent.mkdir(parents=True,exist_ok=True);session.write_text(text,encoding='utf-8')
print(json.dumps(result))
