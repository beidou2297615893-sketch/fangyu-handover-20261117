import importlib.util
from pathlib import Path
import tempfile
import threading
import unittest
import hashlib
import sqlite3
from contextlib import closing
from types import SimpleNamespace
from unittest.mock import patch

SPEC=importlib.util.spec_from_file_location('parallel',Path(__file__).with_name('parallel.py'))
p=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(p)

class PipelineTests(unittest.TestCase):
    def test_collection_advances_while_analysis_waits(self):
        with tempfile.TemporaryDirectory() as td:
            started=threading.Event();second=threading.Event();release=threading.Event()
            def collect(job):
                if job['index']==1:second.set()
                return {'inserted':1}
            def analyse(job):
                started.set();self.assertTrue(second.wait(3));release.set()
            store=p.Store.create(Path(td),[{'keyword':'古北租房','page':1},{'keyword':'古北求租','page':1}],'test')
            result=p.run(store,collect,lambda job:{},analyse)
            self.assertTrue(started.is_set());self.assertTrue(release.is_set())
            self.assertEqual(result['status'],'completed')
            self.assertTrue(all(j['analysis']=='done' for j in result['jobs']))

    def test_platform_error_stops_next_collection_and_preserves_job(self):
        with tempfile.TemporaryDirectory() as td:
            seen=[]
            def collect(job):seen.append(job['index']);raise p.Stop('platform')
            store=p.Store.create(Path(td),[{'keyword':'古北','page':1},{'keyword':'古北','page':2}],'test')
            result=p.run(store,collect,lambda job:{},lambda job:None)
            self.assertEqual(seen,[0]);self.assertEqual(result['status'],'stopped')
            self.assertEqual(result['jobs'][0]['collection'],'failed')
            self.assertEqual(result['jobs'][1]['collection'],'pending')

    def test_resume_does_not_retry_inflight_unknown(self):
        with tempfile.TemporaryDirectory() as td:
            store=p.Store.create(Path(td),[{'keyword':'古北','page':1}],'test')
            store.change(0,'collection','running')
            with self.assertRaises(p.Stop):p.Store.resume(Path(td),'test')
            self.assertEqual(p.load(Path(td)/'state.json')['status'],'blocked')

    def test_zero_new_skips_context_and_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            def forbidden(job):self.fail('empty batch must not request context or AI')
            store=p.Store.create(Path(td),[{'keyword':'古北','page':1}],'test')
            result=p.run(store,lambda job:{'inserted':0},forbidden,forbidden)
            self.assertEqual(result['status'],'completed')
            self.assertEqual(result['jobs'][0]['context'],'skipped')

    def test_analysis_failure_does_not_stop_collection(self):
        with tempfile.TemporaryDirectory() as td:
            seen=[]
            def collect(job):seen.append(job['index']);return {'inserted':1}
            def analyse(job):raise p.Stop('model')
            store=p.Store.create(Path(td),[{'keyword':'古北','page':i} for i in range(1,4)],'test')
            result=p.run(store,collect,lambda job:{},analyse)
            self.assertEqual(seen,[0,1,2]);self.assertEqual(result['status'],'stopped')

    def test_real_registration_and_separate_context_boundary(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);ledger=root/'ledger.sqlite'
            with closing(sqlite3.connect(ledger)) as db:
                db.executescript('''CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,review_time INTEGER,evidence TEXT,operator TEXT,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
                CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT,evidence TEXT,created INTEGER);
                CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,evidence TEXT,verified INTEGER,PRIMARY KEY(platform,alias));
                CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,comment TEXT,reference TEXT,delivery_state TEXT,source TEXT,recorded INTEGER);
                CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));''');db.commit()
            registrar=p.module(p.REGISTER,'parallel_test_register')
            row={'customer_id':'xhs_new_'+hashlib.sha256(b'xiaohongshu:fixture').hexdigest(),'customer_uid':'fixture','comment_id':'c1','note_id':'n1','comment_text':'古北求租','other_comments':[]}
            source={'schema':'xhs-collected-ai-input-v1','customers':[row],'summary':{'usable_comments':1}}
            args=SimpleNamespace(session_home='fixture',sender_uid='fixture_sender',source_db='fixture',ledger=ledger,max_notes=1,max_pages=1,account='fixture',style='fixture')
            def fake_invoke(command):
                if command[0]==p.COLLECT:
                    out=Path(command[command.index('--output')+1]);out.mkdir();p.save(out/'collection.json',source)
                elif command[0]==p.REGISTER:
                    src=Path(command[command.index('--collection')+1]);report=Path(command[command.index('--report')+1])
                    value=registrar.register(ledger,p.load(src),{},'collection:'+str(src.resolve()),apply='--apply' in command)
                    p.save(report,value)
                elif command[0]==p.CONTEXT:
                    self.assertNotIn('--analyse',command)
                    out=Path(command[command.index('--output')+1]);out.mkdir();p.save(out/'ai-input.json',[dict(row,post_text='真实测试正文')])
                else:self.fail('unexpected stage')
            store=p.Store.create(root/'run',[{'keyword':'古北','page':1}],'test')
            with patch.object(p,'invoke',fake_invoke):
                collect,context,_=p.callbacks(root/'run',args)
                observed=[]
                result=p.run(store,collect,context,lambda job:observed.extend(p.load(root/'run/batch-0001/context/ai-input.json')))
            self.assertEqual(result['status'],'completed',result);self.assertEqual(result['jobs'][0]['inserted'],1)
            self.assertEqual(observed[0]['post_text'],'真实测试正文')
            with closing(sqlite3.connect(ledger)) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM leads').fetchone()[0],1)

if __name__=='__main__':unittest.main()
