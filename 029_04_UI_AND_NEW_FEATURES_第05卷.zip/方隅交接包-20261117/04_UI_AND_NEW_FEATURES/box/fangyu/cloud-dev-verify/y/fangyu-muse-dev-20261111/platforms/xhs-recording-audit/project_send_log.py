"""Read-only ledger projection into a durable text journal. Never sends.

The journal mirrors observable current ledger facts, not every overwritten state.
Run at checkpoints and after each committed sending transaction; SQLite remains
the authoritative source. This isolated candidate is not production-integrated.
"""
import argparse
from contextlib import closing, contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3


@contextmanager
def lock_file(path):
    """OS advisory lock is released even if the process terminates."""
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        if os.name == 'nt':
            import msvcrt
            if os.fstat(fd).st_size == 0:
                os.write(fd, b'0'); os.fsync(fd)
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)


def recover_and_read(path):
    if not path.exists():
        return set()
    content = path.read_bytes()
    if content and not content.endswith(b'\n'):
        # Preserve the entire interrupted write before repairing only its tail.
        backup = path.with_name(path.name + '.interrupted.' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
        with backup.open('xb') as out:
            out.write(content); out.flush(); os.fsync(out.fileno())
        good = content.rfind(b'\n') + 1
        with path.open('r+b') as out:
            out.truncate(good); out.flush(); os.fsync(out.fileno())
        content = content[:good]
    existing = set()
    for line in content.splitlines():
        try:
            obj = json.loads(line.decode('utf8'))
            key = obj['event_id']
            if not isinstance(key, str) or not re.fullmatch('[0-9a-f]{64}', key) or key in existing:
                raise ValueError('invalid or duplicated event id')
            existing.add(key)
        except (UnicodeError, json.JSONDecodeError, KeyError, TypeError) as exc:
            raise ValueError('journal contains a corrupt completed line; manual review required') from exc
    return existing


def snapshot(ledger):
    uri = Path(ledger).resolve(strict=True).as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=5)) as db:
        db.execute('PRAGMA query_only=ON'); db.execute('BEGIN')
        rows = db.execute("SELECT r.token,r.customer,r.comment,r.status,r.created,p.data FROM reservations r LEFT JOIN local_sender_plans p ON p.token=r.token WHERE r.platform=? ORDER BY r.created,r.token", ('xiaohongshu',)).fetchall()
        db.rollback()
    events = []
    for attempt, customer, comment, status, created, payload in rows:
        if status not in ('reserved','unknown','sent','not_sent') or not payload:
            raise ValueError('uninterpretable reservation; do not produce partial projection')
        record = json.loads(payload); plan = record.get('plan'); result = record.get('result') or {}
        if not isinstance(plan, dict) or not isinstance(result, dict) or plan.get('attempt_id') != attempt or plan.get('canonical_customer') != customer or plan.get('comment_id') != comment:
            raise ValueError('ledger identities do not match; review required')
        for k in ('sender_uid','customer_uid','note_id','comment_id','text'):
            if not isinstance(plan.get(k),str) or not plan[k].strip():
                raise ValueError('missing target or account identity')
        receipt = result.get('receipt_id') if result.get('kind') == 'platform_receipt' else None
        if receipt is not None and (not isinstance(receipt,str) or not receipt.strip()):
            raise ValueError('invalid receipt')
        if status == 'reserved': state = '已预留，发送结果尚未确认'
        elif status == 'unknown' and receipt: state = '平台已受理，公开显示未核实'
        elif status == 'unknown': state = '发送结果未知，禁止自动重发'
        elif status == 'sent': state = '账本已确认发送'
        else: state = '账本已确认未发送'
        # Identity and receipt are used internally in the hash but never print
        # session credentials, raw attempt tokens, platform tokens or raw errors.
        key = hashlib.sha256(json.dumps([attempt,status,result.get('kind'),receipt],ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest()
        item = {'event_id':key,'记录类型':'账本事实快照','记录时间':datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'),
                '预留时间':datetime.fromtimestamp(created,timezone.utc).astimezone().isoformat(timespec='seconds'),
                '平台':'小红书','账号标识':plan['sender_uid'],'客户标识':plan['customer_uid'],
                '帖子标识':plan['note_id'],'评论标识':comment,'回复内容':plan['text'],'状态':state}
        if receipt: item['平台回执标识'] = receipt
        error_type=result.get('error_type')
        if isinstance(error_type,str) and re.fullmatch('[A-Za-z0-9_]{1,80}',error_type): item['错误类型']=error_type
        for key_name,label in [('http_status','HTTP状态'),('api_code','平台返回码')]:
            if type(result.get(key_name)) is int: item[label]=result[key_name]
        events.append(item)
    return events


def sync(ledger, journal):
    journal = Path(journal); journal.parent.mkdir(parents=True,exist_ok=True)
    with lock_file(journal.with_name(journal.name+'.lock')):
        known = recover_and_read(journal)
        rows = snapshot(ledger)
        pending = [row for row in rows if row['event_id'] not in known]
        if pending:
            fd = os.open(journal,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
            try:
                for row in pending:
                    data=(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf8')
                    total=0
                    while total<len(data):
                        written=os.write(fd,data[total:])
                        if written<=0: raise OSError('journal write failed')
                        total+=written
                    os.fsync(fd)
            finally: os.close(fd)
        return {'ledger_rows':len(rows),'new_records':len(pending),'journal_records':len(known)+len(pending)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ledger',required=True);parser.add_argument('--journal',required=True)
    args=parser.parse_args()
    print(json.dumps(sync(args.ledger,args.journal),ensure_ascii=False))


if __name__=='__main__': main()
