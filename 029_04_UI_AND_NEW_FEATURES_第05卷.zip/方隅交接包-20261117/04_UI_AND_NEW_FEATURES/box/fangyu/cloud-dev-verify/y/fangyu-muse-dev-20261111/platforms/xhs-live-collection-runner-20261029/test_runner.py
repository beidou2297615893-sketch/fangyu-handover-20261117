import importlib.util
import io
import json
from pathlib import Path
import socket
import sqlite3
import sys
import tempfile
import unittest
from contextlib import closing, redirect_stdout
from unittest.mock import patch

import runner

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]

class PlanTests(unittest.TestCase):
    def test_saved_queue_resumes_failed_page_with_new_batch(self):
        schedule={'tasks':[{'keyword':'古北找房','first_page':1,'last_page':8},
            {'keyword':'古北求租','first_page':9,'last_page':14},
            {'keyword':'古北租房','first_page':11,'last_page':16}]}
        state={'keyword':'古北找房','search_page':5,'batch':19,'status':'stopped'}
        plan=runner.make_plan(schedule,state)
        self.assertEqual(plan[:4],[{'keyword':'古北找房','page':5},{'keyword':'古北找房','page':6},
            {'keyword':'古北找房','page':7},{'keyword':'古北找房','page':8}])
        self.assertEqual(plan[4],{'keyword':'古北求租','page':9})
        self.assertEqual(plan[-1],{'keyword':'古北租房','page':16})
        self.assertEqual(len(plan),16)
    def test_explicit_next_batch_number_reaches_cli_preview(self):
        with redirect_stdout(io.StringIO()) as stream:
            try:
                result=runner.main(['--run-home','unused-preview','--session-home','unused-session','--first-batch','21'])
            except SystemExit as exc:
                result=exc.code
        self.assertEqual(result,0)
        self.assertEqual(json.loads(stream.getvalue())['first_batch'],'batch-0021')

class SearchRequestTests(unittest.TestCase):
    def setUp(self):
        import xhs_cli.client_mixins as mixins
        self.mixins=mixins
        self.tmp=tempfile.TemporaryDirectory(dir=HERE)
        self.directory=Path(self.tmp.name)
        self.cache_guard=patch.object(mixins,'get_config_dir',return_value=self.directory); self.cache_guard.start()
        self.save_guard=patch.object(mixins,'_save_search_session_cache',return_value=None); self.save_guard.start()
        self.network=patch.object(socket.socket,'connect',side_effect=AssertionError('Network forbidden')); self.network.start()
    def tearDown(self):
        self.network.stop(); self.save_guard.stop(); self.cache_guard.stop(); self.tmp.cleanup()
    def test_search_omits_optional_recommend_request_and_preserves_parameters(self):
        mixins=self.mixins
        class ProtocolClient(mixins.ReadingEndpointsMixin):
            def __init__(self): self.requests=[]
            def _search_request_id(self): return 'fixture-request'
            def _main_api_post(self,path,payload):
                self.requests.append(('POST',path,payload))
                return {'items':[{'id':'note-fixture'}]} if path.endswith('/notes') else {}
            def _main_api_get(self,path,payload):
                self.requests.append(('GET',path,payload))
                if path.endswith('/recommend'):
                    from xhs_cli.exceptions import XhsApiError
                    raise XhsApiError('unknown optional error',code=3002)
                return {}
        client=ProtocolClient()
        result=runner.search_without_recommend(client,keyword='古北找房',page=5,page_size=20,sort='general',note_type=0)
        self.assertEqual(result,{'items':[{'id':'note-fixture'}]})
        self.assertEqual([x[1] for x in client.requests],['/api/sns/web/v1/search/onebox',
            '/api/sns/web/v1/search/filter','/api/sns/web/v1/search/notes'])
        payload=client.requests[-1][2]
        self.assertEqual(payload['keyword'],'古北找房'); self.assertEqual(payload['page'],5)
        self.assertEqual(payload['page_size'],20); self.assertEqual(payload['sort'],'general')
        self.assertEqual(payload['note_type'],0); self.assertEqual(payload['ext_flags'],[])
        self.assertEqual(payload['geo'],''); self.assertEqual(payload['image_formats'],['jpg','webp','avif'])
        self.assertEqual(payload['search_id'],client.requests[0][2]['search_id'])
        self.assertEqual(payload['search_id'],client.requests[1][2]['search_id'])
        self.assertEqual(payload['filters'],[
            {'tags':['general'],'type':'sort_type'},{'tags':['不限'],'type':'filter_note_type'},
            {'tags':['不限'],'type':'filter_note_time'},{'tags':['不限'],'type':'filter_note_range'},
            {'tags':['不限'],'type':'filter_pos_distance'}])
    def test_non_note_cards_do_not_consume_the_twenty_note_limit(self):
        notes=[{'id':f'{i:024x}','model_type':'note','note_card':{'title':'fixture'}} for i in range(1,21)]
        records=notes+[
            {'id':'5d68fa36-624a-4f20-bd4e-99f59f7fc8f4#1793258094364','model_type':'recommend','note_card':{}},
            {'model_type':'ad','title':'MUST-NOT-LOG-BODY','xsec_token':'MUST-NOT-LOG-TOKEN'}]
        filtered,evidence=runner.addressable_search_page({'items':records})
        self.assertEqual(len(filtered['items']),20)
        self.assertEqual(evidence['valid_notes'],20); self.assertEqual(evidence['discarded_items'],2)
        self.assertEqual(evidence['raw_id_patterns']['uuid_timestamp'],1)
        self.assertNotIn('MUST-NOT-LOG',json.dumps(evidence))
    def test_addressable_ad_note_is_kept(self):
        note={'id':'0123456789abcdef01234567','model_type':'ad','note_card':{'title':'advertised but addressable'}}
        filtered,evidence=runner.addressable_search_page({'items':[note]})
        self.assertEqual(filtered['items'],[note]); self.assertEqual(evidence['valid_notes'],1)
        self.assertEqual(evidence['discarded_items'],0)
    def test_note_card_id_fallback_keeps_addressable_note(self):
        raw={'id':'non-note-wrapper','note_card':{'note_id':'0123456789abcdef01234567'}}
        filtered,evidence=runner.addressable_search_page({'items':[raw]})
        self.assertEqual(filtered['items'][0]['id'],'0123456789abcdef01234567')
        self.assertEqual(evidence['valid_notes'],1)
    def test_malformed_search_page_stops(self):
        for raw in (None,[],{}, {'items':'not-list'}):
            with self.subTest(raw=raw),self.assertRaises(ValueError): runner.addressable_search_page(raw)
    def exercise_read_client(self,blocked_path,*,status=200,code=3002,placeholder=False):
        import httpx
        collector,_=runner.components()[0].dependencies()
        requests=[]
        def respond(request):
            path=request.url.path; requests.append(path)
            if path==blocked_path:
                body={'success':False,'code':0 if placeholder else code,'data':None,'msg':'' if placeholder else '未知错误'}
                return httpx.Response(status,json=body,request=request)
            return httpx.Response(200,json={'success':True,'data':{'items':[]}},request=request)
        client=collector.ReadClient({'a1':'synthetic','webId':'synthetic','web_session':'synthetic'},
            transport=httpx.MockTransport(respond),delay=0)
        try:
            if placeholder:
                runner.search_without_recommend(client,keyword='独立测试词',page=5)
            else:
                with self.assertRaises(collector.Halt):
                    runner.search_without_recommend(client,keyword='独立测试词',page=5)
        finally: client.close()
        return requests
    def test_main_search_unknown_error_is_not_ignored_or_retried(self):
        paths=self.exercise_read_client('/api/sns/web/v1/search/notes')
        self.assertEqual(paths,['/api/sns/web/v1/search/onebox','/api/sns/web/v1/search/filter','/api/sns/web/v1/search/notes'])
    def test_prewarm_verification_stops_before_main_search(self):
        paths=self.exercise_read_client('/api/sns/web/v1/search/onebox',status=461)
        self.assertEqual(paths,['/api/sns/web/v1/search/onebox'])
    def test_filter_unknown_error_stops_before_main_search(self):
        paths=self.exercise_read_client('/api/sns/web/v1/search/filter')
        self.assertEqual(paths,['/api/sns/web/v1/search/onebox','/api/sns/web/v1/search/filter'])
    def test_only_existing_empty_code_zero_prewarm_contract_continues(self):
        paths=self.exercise_read_client('/api/sns/web/v1/search/onebox',placeholder=True)
        self.assertEqual(paths,['/api/sns/web/v1/search/onebox','/api/sns/web/v1/search/notes'])

class SyntheticClient:
    def __init__(self,page,*,empty=False,fail=False,many=False,duplicate=False):
        self.page=page; self.empty=empty; self.fail=fail; self.many=many; self.duplicate=duplicate
        self.cookies={'a1':'SYNTHETIC-NOT-A-REAL-COOKIE','web_session':'SYNTHETIC'}
        self.calls=[]
    def get_self_info(self):
        self.calls.append('identity')
        return {'user_id':'fixture-account','guest':False,'nickname':'合成账号'}
    def search_notes(self,**kwargs):
        self.calls.append('search')
        n=21 if self.many else (0 if self.empty else 1)
        return {'items':[{'id':f'{self.page:08x}{i:016x}','xsec_token':'SYNTHETIC-TOKEN',
            'note_card':{'title':'合成帖子'}} for i in range(n)]}
    def _search_request_id(self): return 'fixture-request'
    def _main_api_post(self,path,payload):
        return self.search_notes(**payload) if path.endswith('/notes') else {}
    def _main_api_get(self,path,payload):
        if path.endswith('/recommend'): raise AssertionError('Unnecessary recommendation request')
        return {}
    def get_comments(self,note_id,**kwargs):
        self.calls.append('comments')
        if self.fail: raise TimeoutError('SYNTHETIC SECRET MUST NOT APPEAR')
        return {'comments':[{'id':'same-comment' if self.duplicate else f'comment-{self.page}',
            'content':'合成求租','user_info':{'user_id':'fixture-customer'},
            'create_time':1700000000,'ip_location':'上海'}],'has_more':False}
    def close(self): self.calls.append('close')

class ExecutionTests(unittest.TestCase):
    def setUp(self):
        runtime=PROJECT/'work/xhs-account-switch-recovery-candidate/runtime'
        self.tmp=tempfile.TemporaryDirectory(dir=runtime); self.root=Path(self.tmp.name)
        self.ledger=self.root/'fixture.sqlite3'; self.source=self.root/'source.sqlite3'
        with closing(sqlite3.connect(self.ledger)) as db:
            db.executescript('''CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
            CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT);
            CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,PRIMARY KEY(platform,alias));
            CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,delivery_state TEXT);
            CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));''')
        with closing(sqlite3.connect(self.source)) as db:
            db.execute('CREATE TABLE records(entity TEXT,id TEXT,tenant_id TEXT,body TEXT)')
        self.clients=[]; self.empty=set(); self.fail_pages=set(); self.many=set(); self.duplicate=False
        self.guard=patch.object(socket.socket,'connect',side_effect=AssertionError('Network forbidden')); self.guard.start()
    def tearDown(self): self.guard.stop(); self.tmp.cleanup()
    def factory(self,home,cache):
        runner.components()[1].configure_runtime_cache(cache)
        page=5+len(self.clients)
        client=SyntheticClient(page,empty=page in self.empty,fail=page in self.fail_pages,many=page in self.many,duplicate=self.duplicate)
        self.clients.append(client); return client
    def go(self,target=2,resume=False):
        return runner.run_task(self.root,[{'keyword':'古北找房','page':5},{'keyword':'古北找房','page':6}],
            session_home=self.root,ledger=self.ledger,source_db=self.source,target=target,first_batch=20,
            client_factory=self.factory,resume=resume)
    def test_two_real_batches_register_and_publish_manifest(self):
        result=self.go()
        self.assertEqual(result['status'],'target_reached'); self.assertEqual(result['inserted'],2)
        with closing(sqlite3.connect(self.ledger)) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM leads').fetchone()[0],2)
        manifest=[json.loads(x) for x in (self.root/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual([x['batch'] for x in manifest],['batch-0020','batch-0021'])
        self.assertEqual([x['inserted_comments'] for x in manifest],[1,1])
        for row in manifest:
            self.assertEqual(row['account_uid'],'fixture-account')
            data=json.loads((self.root/row['input']).read_text(encoding='utf8'))
            self.assertEqual(data[0]['ip_location'],'上海')
    def test_target_stops_before_next_platform_batch(self):
        result=self.go(target=1)
        self.assertEqual(result['status'],'target_reached'); self.assertEqual(result['inserted'],1)
        self.assertEqual(len(self.clients),1)
    def test_stop_marker_prevents_any_client(self):
        (self.root/'STOP').write_text('user pause',encoding='utf8')
        result=self.go()
        self.assertEqual(result['status'],'paused'); self.assertEqual(self.clients,[])
    def test_failure_preserves_inflight_and_resume_never_retries(self):
        self.fail_pages.add(5)
        result=self.go()
        self.assertEqual(result['status'],'outcome_unknown'); self.assertIsNotNone(result['inflight'])
        again=self.go(resume=True)
        self.assertEqual(again['status'],'outcome_unknown'); self.assertEqual(len(self.clients),1)
        text=''.join(p.read_text(encoding='utf8') for p in self.root.rglob('*.jsonl'))
        self.assertNotIn('SYNTHETIC SECRET',text)
    def test_empty_pages_only_exhaust_this_explicit_plan(self):
        self.empty={5,6}
        result=self.go()
        self.assertEqual(result['status'],'plan_exhausted'); self.assertEqual(result['inserted'],0)
        self.assertEqual(len(self.clients),2)
        self.assertFalse(result.get('all_keywords_exhausted',False))
    def test_search_overflow_stops_before_reading_comments(self):
        self.many.add(5)
        result=self.go()
        self.assertEqual(result['status'],'outcome_unknown')
        self.assertNotIn('comments',self.clients[0].calls)
        evidence=json.loads((self.root/'search-evidence-batch-0020.json').read_text(encoding='utf8'))
        self.assertEqual(evidence['valid_notes'],21)
    def test_cross_batch_duplicate_not_counted_twice(self):
        self.duplicate=True
        result=self.go(target=5)
        self.assertEqual(result['status'],'plan_exhausted'); self.assertEqual(result['inserted'],1)
        manifest=[json.loads(x) for x in (self.root/'analysis-manifest.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual([x['inserted_comments'] for x in manifest],[1,0])
    def test_stop_between_completed_batches_leaves_second_page_unrequested(self):
        original=self.factory
        def factory(home,cache):
            client=original(home,cache)
            close=client.close
            def close_then_pause():
                close(); (self.root/'STOP').write_text('user pause',encoding='utf8')
            client.close=close_then_pause
            return client
        self.factory=factory
        result=self.go()
        self.assertEqual(result['status'],'paused'); self.assertEqual(result['inserted'],1)
        self.assertEqual(result['cursor'],1); self.assertEqual(len(self.clients),1)
    def test_resume_cannot_change_task_account_source_or_target(self):
        (self.root/'STOP').write_text('pause',encoding='utf8')
        self.go(target=2)
        with self.assertRaisesRegex(ValueError,'resume_config_changed'): self.go(target=3,resume=True)
        self.assertEqual(self.clients,[])
    def test_preview_creates_no_task_or_session_files(self):
        home=self.root/'preview-unused'
        with redirect_stdout(io.StringIO()) as stream:
            result=runner.main(['--run-home',str(home),'--session-home',str(home/'session')])
        response=json.loads(stream.getvalue())
        self.assertEqual(result,0); self.assertFalse(response['network']); self.assertFalse(response['ledger_write'])
        self.assertFalse(home.exists()); self.assertEqual(self.clients,[])
    def test_real_batch_reads_twenty_notes_despite_two_non_note_cards(self):
        original=self.factory
        def factory(home,cache):
            client=original(home,cache)
            client.search_notes=lambda **kwargs:{'items':[
                {'id':f'{i:024x}','xsec_token':'SYNTHETIC-TOKEN','note_card':{'title':'fixture'}} for i in range(1,21)]+[
                {'id':'5d68fa36-624a-4f20-bd4e-99f59f7fc8f4#1793258094364','note_card':{}},
                {'model_type':'ad'}]}
            def comments(note_id,**kwargs):
                client.calls.append('comments')
                return {'comments':[{'id':f'fixture-comment-{note_id}','content':'合成求租',
                    'user_info':{'user_id':'fixture-customer'}}],'has_more':False}
            client.get_comments=comments
            return client
        self.factory=factory
        result=self.go(target=20)
        self.assertEqual(result['status'],'target_reached'); self.assertEqual(result['inserted'],20)
        self.assertEqual(len(self.clients),1); self.assertEqual(self.clients[0].calls.count('comments'),20)
        evidence=json.loads((self.root/'search-evidence-batch-0020.json').read_text(encoding='utf8'))
        self.assertEqual(evidence['valid_notes'],20); self.assertEqual(evidence['discarded_items'],2)
    def test_malformed_shape_has_evidence_and_reads_no_comments(self):
        original=self.factory
        def factory(home,cache):
            client=original(home,cache); client.search_notes=lambda **kwargs:{'items':'invalid'}
            return client
        self.factory=factory
        result=self.go()
        self.assertEqual(result['status'],'outcome_unknown'); self.assertNotIn('comments',self.clients[0].calls)
        evidence=json.loads((self.root/'search-evidence-batch-0020.json').read_text(encoding='utf8'))
        self.assertFalse(evidence['shape_valid'])

if __name__=='__main__': unittest.main()



