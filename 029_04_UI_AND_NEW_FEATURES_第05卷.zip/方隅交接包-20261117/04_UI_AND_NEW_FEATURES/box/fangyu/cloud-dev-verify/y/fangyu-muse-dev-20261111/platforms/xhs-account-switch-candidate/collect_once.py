"""One bounded batch with dynamic verified identity. Preview is default.

No QR login, automatic account switching, sending, or retry exists here.
Caller uses an already separately authorized and authenticated session.
"""
import argparse
import hashlib
import json
import logging
from pathlib import Path
import re
import sys
import account_switch as candidate


def historical_ids(roots):
    found,comments=set(),set()
    def visit(value):
        if isinstance(value,dict):
            if isinstance(value.get('note_id'),str) and value['note_id']:
                found.add(value['note_id'])
            if isinstance(value.get('comment_id'),str) and value['comment_id']:
                comments.add(value['comment_id'])
            for item in value.values(): visit(item)
        elif isinstance(value,list):
            for item in value: visit(item)
    for root in roots:
        root=Path(root)
        if not root.is_dir(): continue
        for path in root.rglob('*.json'):
            if (path.name in {'collection.json','partial.json','attempted-notes.json','ai-input.json'}
                    or path.name.startswith('partial-')
                    or root.name=='xhs-browser-context-recovery'):
                visit(json.loads(path.read_text(encoding='utf-8-sig')))
        for path in root.rglob('attempt-events.jsonl'):
            for line in path.read_text(encoding='utf8').splitlines():
                if line: visit(json.loads(line))
    return found,comments


def historical_notes(roots):
    return historical_ids(roots)[0]


def load_cookies(home):
    # No HOME/USERPROFILE mutation, browser fallback, token refresh or login.
    home=Path(home).resolve(strict=True)
    allowed=(candidate.PROJECT/'work/xhs-standalone-session').resolve(strict=True)
    if home==allowed or not home.is_relative_to(allowed) or not home.is_dir():
        raise candidate.Refused('independent_session_required')
    path=(home/'.xiaohongshu-cli/cookies.json').resolve(strict=True)
    if not path.is_relative_to(home):
        raise candidate.Refused('session_path_escape')
    value=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(value,dict) or not all(isinstance(value.get(k),str) and value[k] for k in ('a1','web_session')):
        raise candidate.Refused('independent_session_incomplete')
    return {k:v for k,v in value.items() if isinstance(v,str)}


def configure_runtime_cache(cache):
    # Installed mixins import get_config_dir by value, so both namespaces must
    # be scoped. Keep xsec tokens and search-session IDs in memory only.
    import xhs_cli.cookies as storage
    import xhs_cli.client_mixins as mixins
    cache.mkdir(exist_ok=False)
    storage.get_config_dir=lambda: cache
    mixins.get_config_dir=lambda: cache
    mixins.cache_note_context=lambda *args,**kwargs: None
    mixins.get_cached_note_context=lambda *args,**kwargs: {}
    mixins.invalidate_note_context=lambda *args,**kwargs: None
    mixins._save_search_session_cache=lambda *args,**kwargs: None


def create_client(home, cache):
    logging.disable(logging.CRITICAL)
    cookies=load_cookies(home)
    collector,_=candidate.dependencies()
    configure_runtime_cache(cache)
    # Hash stays in memory. It detects a normal re-login replacing the selected
    # file and never appears in the batch audit or exception text.
    session=(Path(home).resolve(strict=True)/'.xiaohongshu-cli/cookies.json').resolve(strict=True)
    raw=session.read_bytes()
    latest=json.loads(raw.decode('utf-8-sig'))
    if not isinstance(latest,dict) or {k:v for k,v in latest.items() if isinstance(v,str)}!=cookies:
        raise candidate.Refused('independent_session_file_changed')
    digest=hashlib.sha256(raw).digest()
    client=collector.ReadClient(cookies)
    def unchanged_file():
        try:
            unchanged=session.is_file() and hashlib.sha256(session.read_bytes()).digest()==digest
        except OSError:
            unchanged=False
        if not unchanged: raise candidate.Refused('independent_session_file_changed')
    client._independent_session_guard=unchanged_file
    install_response_audit(client)
    return client


def install_response_audit(client):
    # HTTP failures occur before upstream response parsing, so capture only
    # the fixed status/endpoint metadata here; never store body or headers.
    def observe_response(response):
        if response.status_code!=200:
            client.last_failure_detail={'http_status':response.status_code,'error_type':'HTTPError',
                'stage':client._last_stage,'endpoint':client._last_endpoint_kind,'request_started':True}
    client._http.event_hooks['response'].append(observe_response)


def main(argv=None, *, client_factory=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace',required=True)
    parser.add_argument('--batch',required=True)
    parser.add_argument('--keyword',required=True)
    parser.add_argument('--search-page',type=int,required=True)
    parser.add_argument('--session-home')
    parser.add_argument('--ledger')
    parser.add_argument('--source-db')
    parser.add_argument('--task',default='独立账号关键词采集')
    parser.add_argument('--operator')
    parser.add_argument('--max-notes',type=int,default=10)
    parser.add_argument('--max-pages',type=int,default=2)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--apply-to-shared-ledger',action='store_true')
    args=parser.parse_args(argv)
    if not args.execute:
        print(json.dumps({'mode':'preview','batch':args.batch,'search_page':args.search_page,
            'network':False,'login':False,'send':False,'ledger_write':False},ensure_ascii=False))
        return 0
    if not all((args.session_home,args.ledger,args.source_db)):
        raise candidate.Refused('explicit_session_source_ledger_required')
    workspace=Path(args.workspace).resolve(strict=True)
    if not workspace.is_relative_to((candidate.HERE/'runtime').resolve(strict=True)) or workspace==candidate.HERE/'runtime':
        raise candidate.Refused('dedicated_candidate_workspace_required')
    if (workspace/'STOP').exists():
        raise candidate.Refused('user_pause_marker_present')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',args.batch):
        raise candidate.Refused('new_safe_batch_name_required')
    if (workspace/args.batch).exists():
        raise candidate.Refused('existing_batch_no_retry')
    ledger=Path(args.ledger).resolve(strict=True)
    if not ledger.is_relative_to(workspace) and not (args.apply_to_shared_ledger and ledger==candidate.REAL_LEDGER.resolve()):
        raise candidate.Refused('shared_ledger_opt_in_required')
    if type(args.search_page) is not int or not 1<=args.search_page<=100 or any(not 1<=n<=20 for n in (args.max_notes,args.max_pages)):
        raise candidate.Refused('bounded_range_required')
    areas=('xhs-continuous-runner/work','xhs-parallel-pipeline/work','xhs-browser-context-recovery',
        'xhs-collection-candidate/work','xhs-context-controlled/work','xhs-standalone-session/collection-live',
        'xhs-account-switch-candidate/runtime')
    notes,comments=historical_ids([candidate.PROJECT/'work'/area for area in areas])
    factory=client_factory or create_client
    client=factory(args.session_home,workspace/('cache-'+args.batch))
    try:
        result=candidate.run_batch(workspace=workspace,batch_name=args.batch,client=client,
            ledger=args.ledger,source_db=args.source_db,keyword=args.keyword,search_page=args.search_page,
            task=args.task,operator=args.operator,known_notes=notes,max_notes=args.max_notes,max_pages=args.max_pages,
            allow_real_ledger=args.apply_to_shared_ledger,known_comments=comments)
        print(json.dumps({'status':'registered','account':result['account'],'result':result['result']},ensure_ascii=False))
    finally:
        client.close()
    return 0


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception:
        # Fixed category: upstream exceptions can contain response/session data.
        print(json.dumps({'status':'stopped','automatic_retry':False,'action':'inspect_batch_audit_and_ledger'},ensure_ascii=False),file=sys.stderr)
        raise SystemExit(2) from None
