"""Isolated sidecar: append observations and calculate lower-bound counts.

No publishing, no mutation of the shared ledger. A read-only adapter must
produce observations; absence is unknown pending verified platform semantics.
"""
import argparse
import datetime
import json
import sqlite3
import subprocess
import sys
from pathlib import Path
from contextlib import closing

ROOT=Path(__file__).resolve().parents[2]
LEDGER=ROOT/'work/shared-acquisition-ledger/shared.sqlite3'
SIDECAR=Path(__file__).with_name('reply-observations.sqlite3')

def initialize(path=SIDECAR):
    with closing(sqlite3.connect(path)) as db, db:
        db.execute('''CREATE TABLE IF NOT EXISTS reply_observations (
          id INTEGER PRIMARY KEY, token TEXT NOT NULL, observed_at TEXT NOT NULL,
          state TEXT NOT NULL CHECK(state IN ('replied','unknown')),
          reason TEXT NOT NULL, followup_id TEXT, pages INTEGER NOT NULL)''')
        db.execute('CREATE INDEX IF NOT EXISTS observation_token ON reply_observations(token,id)')

def record(token,result,ledger=LEDGER,sidecar=SIDECAR):
    with closing(sqlite3.connect(ledger.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        row=db.execute("SELECT status FROM reservations WHERE token=? AND platform='douyin'",(token,)).fetchone()
    if not row or row[0]!='sent':raise ValueError('仅允许记录已确认成功的发送')
    state=result.get('state'); reason=result.get('reason'); follow=result.get('followup_id')
    if state not in ('replied','unknown') or not isinstance(reason,str) or len(reason)>80:raise ValueError('无效观察结果')
    if state=='replied' and (reason!='exact_identity_and_target' or not str(follow or '').isdigit()):raise ValueError('缺少精确接话证据')
    if state=='unknown' and follow is not None:raise ValueError('未知结果不能包含确认标识')
    pages=result.get('pages',0)
    if not isinstance(pages,int) or not 0<=pages<=100:raise ValueError('无效页数')
    initialize(sidecar)
    with closing(sqlite3.connect(sidecar)) as db, db:
        db.execute('INSERT INTO reply_observations(token,observed_at,state,reason,followup_id,pages) VALUES(?,?,?,?,?,?)',
          (token,datetime.datetime.now(datetime.timezone.utc).isoformat(),state,reason,follow,pages))

def report(ledger=LEDGER,sidecar=SIDECAR):
    with closing(sqlite3.connect(ledger.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute("SELECT token,comment,customer FROM reservations WHERE platform='douyin' AND status='sent'").fetchall()
    latest={}
    if sidecar.exists():
        with closing(sqlite3.connect(sidecar.resolve().as_uri()+'?mode=ro',uri=True)) as db:
            latest=dict(db.execute("SELECT token,CASE WHEN MAX(state='replied')=1 THEN 'replied' ELSE 'unknown' END FROM reply_observations GROUP BY token").fetchall())
    # Stable customer IDs are only compared within this platform.
    customers={};checked=set()
    for token,cid,uid in rows:
        if not uid:continue
        uid=str(uid)
        if token in latest:checked.add(uid)
        state=latest.get(token,'unknown')
        if uid not in customers or state=='replied':customers[uid]=state
    total=len(customers);replied=sum(x=='replied' for x in customers.values())
    return {'confirmed_sent_customers':total,'confirmed_customer_followups':replied,
            'checked_customers':len(checked),'unknown_customers':total-replied,
            'confirmed_minimum_percent':round(100*replied/total,2) if total and checked else None}

def check(token,task):
    task=Path(task).resolve()
    if task.parent != ROOT/'work' or not task.name.startswith('douyin-'):
        raise ValueError('任务目录不在允许的工作区')
    with closing(sqlite3.connect(LEDGER.resolve().as_uri()+'?mode=ro',uri=True)) as db:
        row=db.execute("SELECT comment,customer,evidence,status FROM reservations WHERE token=? AND platform='douyin'",(token,)).fetchone()
    if not row or row[3]!='sent':raise ValueError('只允许核对有成功记录的回复')
    cid,customer,evidence,_=row
    receipt=(json.loads(evidence).get('receipt') or {})
    if receipt.get('status_code')!=0 or not str(receipt.get('cid') or '').isdigit():raise ValueError('原成功回执缺少平台回复编号')
    attempt=json.loads((task/(str(cid)+'.json')).read_text(encoding='utf-8-sig'))
    if attempt.get('attempt_id')!=token or str(attempt.get('customer_uid'))!=str(customer):raise ValueError('任务与账本身份不一致')
    if (not attempt.get('account_uid') or receipt.get('sec_uid')!=attempt['account_uid']
            or str(receipt.get('reply_id') or '')!=str(cid)
            or not (attempt.get('reply') or {}).get('draft_text')
            or receipt.get('text')!=(attempt.get('reply') or {}).get('draft_text')):
        raise ValueError('原成功回执的账号、回复目标或正文不完整，不进行平台查询')
    spec={'video':str(attempt.get('video_id') or ''),'root':str(cid),'customer':str(customer),
          'ourReply':str(receipt['cid']),'accountUid':attempt.get('account_uid'),'task':str(task)}
    if not all(spec[k].isdigit() for k in ('video','root','customer','ourReply')) or not spec['accountUid']:raise ValueError('只读核对所需字段不完整')
    node=ROOT/'work/runtime/douyin-bridge/node.exe'
    try:
        run=subprocess.run([str(node),str(Path(__file__).with_name('verify_cli.cjs'))],
            input=json.dumps(spec,ensure_ascii=False),capture_output=True,text=True,encoding='utf-8',timeout=90,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
        try:result=json.loads(run.stdout.strip().splitlines()[-1])
        except (ValueError,IndexError):result={'state':'unknown','reason':'adapter_failed','pages':0}
    except (subprocess.TimeoutExpired,OSError):
        result={'state':'unknown','reason':'adapter_timeout_or_unavailable','pages':0}
    record(token,result)
    return {k:v for k,v in result.items() if k!='followup_id'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='隔离的客户接话只读统计')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('report')
    query=sub.add_parser('check');query.add_argument('--token',required=True);query.add_argument('--task',required=True)
    args=parser.parse_args()
    print(json.dumps(report() if args.command=='report' else check(args.token,args.task),ensure_ascii=False))
