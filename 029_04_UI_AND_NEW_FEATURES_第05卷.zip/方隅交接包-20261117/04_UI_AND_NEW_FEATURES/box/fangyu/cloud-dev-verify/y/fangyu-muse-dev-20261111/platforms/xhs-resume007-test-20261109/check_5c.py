﻿import sqlite3
from pathlib import Path
L = Path(r'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3')
db = sqlite3.connect(L.resolve().as_uri() + '?mode=ro', uri=True)
db.execute('PRAGMA query_only=ON')
tabs = [r[0] for r in db.execute("select name from sqlite_master where type='table'")]
print('tables:', tabs)
cols = [r[1] for r in db.execute('pragma table_info(leads)')]
print('leads columns:', cols)
q = lambda s, p=(): db.execute(s, p).fetchone()[0]
print('leads total:', q('select count(*) from leads'))
if 'platform' in cols:
    for r in db.execute('select platform, count(*) from leads group by platform'): print('  platform', r[0], r[1])
xc = "platform='xiaohongshu'" if 'platform' in cols else '1=1'
print('xhs total:', q(f'select count(*) from leads where {xc}'))
if 'source' in cols:
    print('xhs source like %stores15-resume006-20261103%:', q(f"select count(*) from leads where {xc} and source like ?", ('%stores15-resume006-20261103%',)))
    print('source like %stores15-resume006-20261103%batch-0023% (resume007 pattern):', q("select count(*) from leads where source like ?", ('%stores15-resume006-20261103%batch-0023%',)))
    print('source like %batch-0023% (any task):', q("select count(*) from leads where source like ?", ('%batch-0023%',)))
db.close()
