import json
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import adapter

def cookies(session='SESSION'):
    return [{'name':key,'value':value,'domain':'.xiaohongshu.com'} for key,value in
            [('a1','A1'),('webId','WEB'),('web_session',session)]]

class Page:
    def __init__(self,values=None):
        self.values=values or [cookies(),cookies()]
        self.context=self
        self.closed=False
        self.handlers={}
    def is_closed(self): return self.closed
    def cookies(self): return self.values.pop(0) if len(self.values)>1 else self.values[0]
    def on(self,name,callback): self.handlers[name]=callback

class Client:
    def __init__(self,values,payload=None,error=None):
        self.cookies=dict(values); self.calls=0; self.closed=False
        self.payload=payload or {'user_id':'USER','guest':False}
        self.error=error
    def get_self_info(self):
        self.calls+=1
        if self.error: raise self.error
        return self.payload
    def close(self): self.closed=True

class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=HERE)
        self.home=Path(self.temp.name)
        self.network=patch.object(socket.socket,'connect',side_effect=AssertionError('no live network'))
        self.network.start()
    def tearDown(self): self.network.stop(); self.temp.cleanup()
    def test_background_challenge_does_not_claim_visible_dialog(self):
        page=Page(); window=adapter.LoginWindow(page,self.home)
        window.on_response(SimpleNamespace(frame=SimpleNamespace(page=page),url='https://edith.xiaohongshu.com/api/sns/web/v2/comment/page?xsec_token=SECRET',status=461))
        events=[json.loads(x) for x in (self.home/'events.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(events[-1]['status'],'api_challenge_response_browser_kept_open')
        self.assertEqual(events[-1]['http_status'],461)
        self.assertEqual(events[-1]['endpoint'],'comments')
        self.assertEqual(events[-1]['visible_dialog'],'not_observed_by_network_listener')
        self.assertNotIn('SECRET',json.dumps(events))
    def test_unrecognized_api_path_is_never_logged(self):
        page=Page(); window=adapter.LoginWindow(page,self.home)
        window.on_response(SimpleNamespace(frame=SimpleNamespace(page=page),url='https://www.xiaohongshu.com/api/PRIVATE_VALUE?token=SECRET',status=471))
        events=[json.loads(x) for x in (self.home/'events.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(events[-1]['endpoint'],'other_api')
        self.assertNotIn('PRIVATE_VALUE',json.dumps(events))
    def capture(self,page=None,payload=None,error=None):
        holder=[]
        def factory(value):
            client=Client(value,payload,error); holder.append(client); return client
        result=adapter.capture_once(page or Page(),self.home,client_factory=factory)
        return result,holder
    def test_same_page_verified_identity_is_saved_in_cli_shape(self):
        result,clients=self.capture()
        self.assertEqual(result['status'],'saved')
        value=json.loads((self.home/'.xiaohongshu-cli/cookies.json').read_text())
        self.assertEqual(value['web_session'],'SESSION')
        self.assertIsInstance(value['saved_at'],float)
        self.assertEqual(clients[0].calls,1)
        self.assertTrue(clients[0].closed)
        receipt=json.loads((self.home/'identity-receipt.json').read_text())
        self.assertEqual(receipt['uid'],'USER')
        self.assertNotIn('SESSION',json.dumps(receipt))
    def test_closed_page_makes_zero_identity_requests(self):
        page=Page(); page.closed=True
        result,clients=self.capture(page)
        self.assertEqual(result['status'],'page_closed'); self.assertEqual(clients,[])
    def test_guest_missing_is_not_saved(self):
        result,clients=self.capture(payload={'user_id':'USER'})
        self.assertEqual(result['status'],'identity_unverified')
        self.assertFalse((self.home/'.xiaohongshu-cli/cookies.json').exists())
    def test_session_change_during_identity_is_not_saved(self):
        result,clients=self.capture(Page([cookies(),cookies('OTHER')]))
        self.assertEqual(result['status'],'session_changed')
        self.assertFalse((self.home/'.xiaohongshu-cli/cookies.json').exists())
    def test_request_failure_is_fixed_and_never_retried(self):
        result,clients=self.capture(error=RuntimeError('SECRET_RESPONSE'))
        self.assertEqual(result['status'],'identity_request_failed_no_retry')
        self.assertEqual(clients[0].calls,1)
        self.assertNotIn('SECRET',json.dumps(result))
    def test_existing_session_is_never_overwritten(self):
        path=self.home/'.xiaohongshu-cli'; path.mkdir()
        (path/'cookies.json').write_text('ORIGINAL')
        result,clients=self.capture()
        self.assertEqual(result['status'],'save_outcome_unknown')
        self.assertEqual((path/'cookies.json').read_text(),'ORIGINAL')
    def test_real_identity_client_signs_only_one_identity_request(self):
        import httpx
        requests=[]
        def respond(request):
            requests.append(request)
            return httpx.Response(200,json={'success':True,'code':0,'data':{'user_id':'USER','guest':False}})
        client=adapter.make_identity_client({'a1':'A1','webId':'WEB','web_session':'SESSION'},
                                            transport=httpx.MockTransport(respond))
        try:
            value=client.get_self_info()
            self.assertEqual(value['user_id'],'USER')
            self.assertEqual(len(requests),1)
            self.assertEqual(requests[0].method,'GET')
            self.assertEqual(requests[0].url.path,'/api/sns/web/v2/user/me')
            with self.assertRaises(Exception): client.search_notes(keyword='never')
            self.assertEqual(len(requests),1)
        finally: client.close()
    def test_no_marker_means_no_identity_request(self):
        calls=[]
        window=adapter.LoginWindow(Page(),self.home,client_factory=lambda value:calls.append(value))
        window.step()
        self.assertEqual(calls,[])
        self.assertFalse(window.attempted)
    def test_explicit_marker_captures_once_and_keeps_page_open(self):
        holder=[]; page=Page()
        def factory(value):
            item=Client(value); holder.append(item); return item
        window=adapter.LoginWindow(page,self.home,client_factory=factory)
        (self.home/'capture.flag').write_text('capture-current-page',encoding='utf8')
        window.step(); window.step()
        self.assertTrue(window.saved)
        self.assertEqual(len(holder),1)
        self.assertFalse(page.closed)
        self.assertTrue((self.home/'capture.used').exists())
    def test_marker_failure_does_not_retry_even_after_replacement(self):
        calls=[]
        window=adapter.LoginWindow(Page(),self.home,client_factory=lambda value:calls.append(value))
        marker=self.home/'capture.flag'; marker.write_text('unrelated')
        window.step(); marker.write_text('capture-current-page'); window.step()
        self.assertEqual(calls,[])
        self.assertTrue(window.attempted)
    def test_461_retains_same_page_without_identity_request(self):
        page=Page(); window=adapter.LoginWindow(page,self.home)
        response=SimpleNamespace(frame=SimpleNamespace(page=page),
                 url='https://www.xiaohongshu.com/api/sns/web/v1/login/qrcode/status',
                 status=461,request=SimpleNamespace(method='GET'))
        window.on_response(response)
        self.assertTrue(window.challenge)
        self.assertFalse(page.closed)
        self.assertFalse(window.attempted)
    def test_other_page_cannot_supply_qr_or_challenge_evidence(self):
        page=Page(); window=adapter.LoginWindow(page,self.home)
        response=SimpleNamespace(frame=SimpleNamespace(page=Page()),
                 url='https://www.xiaohongshu.com/api/sns/web/v1/login/qrcode/status',
                 status=461,request=SimpleNamespace(method='GET'))
        window.on_response(response)
        self.assertFalse(window.challenge)
    def test_actual_identity_transport_461_is_one_request_no_retry(self):
        import httpx
        requests=[]
        def respond(request):
            requests.append(request); return httpx.Response(461)
        client=adapter.make_identity_client({'a1':'A1','webId':'WEB','web_session':'SESSION'},
                         transport=httpx.MockTransport(respond))
        try:
            with self.assertRaises(Exception): client.get_self_info()
            self.assertEqual(len(requests),1)
        finally: client.close()
    def test_real_entry_composes_browser_capture_and_private_saved_directory(self):
        from camoufox import sync_api
        home=self.home/'fresh-login'
        page=Page()
        page.gotos=[]
        def goto(url,**kwargs):
            page.gotos.append(url)
            (home/'capture.flag').write_text('capture-current-page',encoding='utf8')
        page.goto=goto
        page.wait_for_timeout=lambda timeout:setattr(page,'closed',True)
        class Browser:
            def __enter__(self): return self
            def __exit__(self,*args): pass
            def new_page(self): return page
        factory=lambda value:Client(value)
        original=adapter.LoginWindow
        def controller(observed,selected): return original(observed,selected,client_factory=factory)
        with patch.object(sync_api,'Camoufox',return_value=Browser()) as browser,\
             patch.object(adapter,'LoginWindow',side_effect=controller):
            result=adapter.run(home)
        self.assertEqual(result,0)
        browser.assert_called_once_with(headless=False)
        self.assertEqual(page.gotos,[adapter.LOGIN_URL])
        self.assertTrue((home/'.xiaohongshu-cli/cookies.json').exists())
        receipt=json.loads((home/'identity-receipt.json').read_text())
        self.assertTrue(receipt['saved'])

if __name__=='__main__': unittest.main()
