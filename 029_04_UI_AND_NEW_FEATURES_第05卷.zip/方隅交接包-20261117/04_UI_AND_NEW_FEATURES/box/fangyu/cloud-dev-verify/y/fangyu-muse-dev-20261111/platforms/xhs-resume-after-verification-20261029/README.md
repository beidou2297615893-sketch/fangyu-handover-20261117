# 人工验证后新批次接续

此入口仅用于本次已审查的中断布局：前段完成2550条，接续段已完成205条，第40批明确在登记前因平台验证停止。它只读核对成功批次清单、内容散列、账号绑定、正式账本同源评论与计数，确认失败批没有开始登记、没有登记回执和账本来源行后，以新批号从同一页接续。不会复用第40批、修改原partial或把未登记观察计入新增。

默认预览，不访问平台、不写账本。显式执行复用原实际运行器；账号将在首批中再次实时核验。调用者须先确认原worker已结束且本人已明确完成验证并要求继续。

```powershell
& 'work/vendor/cli-runtime/Scripts/python.exe' -u -B -X utf8 'work/xhs-resume-after-verification-20261029/resume.py' --campaign 'work/xhs-acquisition-campaign-20261029/current.json' --session-home 'work/xhs-standalone-session/browser-cli-verified-import-20261029-attempt4' --run-home 'work/xhs-account-switch-recovery-candidate/runtime/resume-new10000-20261029-batch41'
```

真正执行需要在上述命令增加 `--execute --apply-to-shared-ledger`。根窗口已自行启动第41批时禁止再执行，不启动第二worker。

本候选只处理“已完成段＋一个明确登记前失败的活跃段”布局；连续多次中断、登记已开始、回执缺失或不明、已经改过的campaign布局，需要重新审查，不可盲用。网页验证码由本人处理；此入口不登录、不解题、不发送。

3项合成SQLite行为测试通过：累计跨段计数不归零并使用新批号、失败批若有账本行拒绝、失败批若曾开始登记拒绝。初次红测暴露测试夹具未关闭SQLite连接导致Windows清理错误，已修正夹具，随后保留3项预期断言失败记录并实现通过。没有真实平台测试或生产写入。

对真实路径执行只读prepare时，父任务已经重新运行，入口按全局锁返回 `collection_lock_busy`，未进行重复启动。
