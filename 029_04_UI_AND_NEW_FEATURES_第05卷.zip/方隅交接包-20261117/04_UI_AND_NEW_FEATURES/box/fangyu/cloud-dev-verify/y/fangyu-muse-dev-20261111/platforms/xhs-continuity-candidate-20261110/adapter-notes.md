# 小红书断点适配候选：离线证据与边界

本候选完成了旧任务元数据的只读诊断与单步接口定义，没有接上真实采集或发送。换任务目录、换账号路径、重新登录或日期变化，都不解除旧未知记录和停止标记。

## 本次实际父任务检查

只读取 `work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume007-20261110-135323/state.json`、同目录 `task-config.json`，以及检查明确停止文件的存在状态。未导入旧脚本、未打开现场账本、未读取会话/凭据/浏览器库、未请求平台、未启动或停止现场进程。

- 父状态为 `outcome_unknown`，cursor=0，next_batch=23，inflight=batch-0023。断点形状有效，不等于结果已核对。
- 第一个未完成页为“上海季乐路求租”第1页。
- 父任务配置里已有本适配要求的9项字段，missing_config/invalid_config/conflicting_config 均为空；没有推测 source_db。独立 stopped successor 的简化配置则确实不包含全部执行字段，不可直接当旧 LiveExecutor 配置。
- 父目录 `stop-today.json` 与 `work/xhs-resume007-test-20261109/stop-today-resume007.json` 均存在。
- 诊断未满足项：`parent_outcome_unknown`、`inflight_requires_reconciliation`、`stop_marker_present`、`collection_authorization_absent`、`ledger_reconciliation_not_supplied`、`live_identity_not_verified`、`cross_mode_owner_not_acquired`、`reviewed_platform_step_not_attached`。
- 结论固定为 `cannot_execute=true`、`can_collect=false`、`can_send=false`、`automatic_retry=false`。账本未打开，平台请求为0。旧配置没有新候选明确授权字段，不据此否定历史授权，只说明本候选不能继承为本轮真实执行许可。

## 新接口

`inspect_checkpoint(parent, *, stop_paths=(), evidence_configs=())`：只读取白名单命名元数据，投影固定字段，给出 checkpoint、配置来源、缺失/非法/冲突项、停止文件、源SHA256与诊断revision。补配置必须显式提供另一个 `task-config.json`；存在冲突就阻断，不能最后写入覆盖。revision 是审阅快照标识，不是执行许可。现场账本可能是WAL，本模块不为预检打开它，也不将账本路径存在当成事务证据。

`ReviewedStepAdapter`：抽象 `review()` / `advance(ReviewedStep)->StepOutcome`；输入只有 operation_id、collect/send、checkpoint_revision，没有任意shell或命令参数。真实实现必须由后续审阅的适配器提供。

`BlockedCheckpointAdapter`：本次唯一具体实现，review给出上述诊断，advance始终抛出 ExecutionRefused。不存在可打开的执行开关。

## 现成模块的可复用契约和缺口

1. `work/xhs-live-collection-runner-20261029/runner.py:181` 的 `LiveExecutor(root, config, candidate, once, client_factory).run(batch,keyword,page,remaining)` 调用一次有界采集，随后核对 binding、register-result、registered-ready、collection、new-ai-input 与共享账本同source的评论集合；只有一致才返回 registered。
2. `work/xhs-safe-batch-scheduler-20261029/scheduler.py:78` 的 run先持久化 inflight，再执行；任何异常置 outcome_unknown。成功注册事件和 state.json 更新不在同一事务。它不包含“普通网络失败自动续”的实现。`reconcile_offline` 明确仅支持它自己的合成runtime及夹内账本，不可用于今日现场。
3. `work/xhs-account-switch-recovery-candidate/account_switch.py:115` 的 run_batch 强制 workspace 位于 candidate.HERE/runtime。`work/xhs-new-task-session-fix-20261029/integration.py` 会把 HERE/RECOVERY 固定到既有候选；新 continuity 目录不能直接调用而假装已继承。后续应在独立受审源码闭包中显式注入允许的runtime根，不修改旧源码、不绕过路径检查。
4. `collect_once.history_index(roots, ledger=...)` 只有显式帖耗尽证据、最终collection和全部观察评论在账本的证明齐全时才跳过帖子。新适配必须把父历史和本候选历史加入roots，保持共享账本权威；不能只看 attempted-notes 或只看旧计数。
5. `work/xhs-collection-candidate/register.py:139` 的 register使用 BEGIN IMMEDIATE；同事务维护UID观察与评论唯一注册，冲突阻断。注册提交后、JSON回执生成前崩溃，可能已经入库；不得当失败重采或重复加计数。
6. `work/xhs-send-current-20261029/bulk_run.py:154` 的 run支持 adapter_factory 注入，但真实默认适配会读取会话并执行平台逻辑，本次没有构造。state必须pending；submit后要求权威账本回执；receipt_received_unverified 只表示接受回执，公开可见性另验。
7. `work/xhs-cli-standalone-entry/backend/xhs-local-ledger-sender-candidate/production_sender.py:260` 的 _reserve在 BEGIN IMMEDIATE 中核对attempt/customer/UID/账号旧未知并写reservation+plan；submit在保留reservation后只send_once；_outcome再事务记录unknown或平台回执。旧未知和同UID已有历史不能由新attempt_id绕过。进程死于reserve后时reservation可能仍是reserved，必须停止核对。

## 可自动续与必须人工处理

可自动续只能由未来经过离线故障注入验收的适配器报告：明确的读取操作（身份/搜索/评论；搜索虽然是HTTP POST，业务语义仍是读取）、已确认普通连接/超时、没有验证/限流/身份/会话信号、没有登记提交歧义、checkpoint和partial证据持久且一致。采用有界退避，并为每次读取尝试留不同事件标识。不能根据任意异常名称或进程退出码认定安全。

以下全部停止或待本人/现场负责人核对：HTTP461/429/401/403及验证码/限流/登录/签名限制、会话被替换或身份变化、STOP/stop-today、outcome_unknown、inflight无法核对、账本身份冲突、登记事务结果不明、任何发送POST已开始或是否开始不明、reserved没有终态、回执缺失/持久化失败。发送HTTP500/读超时也不能自动重发。完整拒绝响应的旧定向隔离政策不可泛化为允许整个continuity继续。

## 全局互斥与崩溃要求

旧采集与发送都用 session_home/.managed-use.lock 的原子mkdir，只能保护同一会话目录；采集还有账本旁 .xhs-collection-runner.lock，发送Runner另有sender UID AccountLock。这些不是已统一的跨模式单实例锁。

新监管器应在候选根持有同一collect/send owner，从review到单步结果落盘全过程覆盖；同时保留旧会话/采集/发送自身锁。不同session路径同UID也不能并发。目录锁不可见旧进程就擅自删除；OS锁即使随进程死释放，也必须先看持久checkpoint。新候选锁只约束使用新监管器的入口，不能声称未改造旧入口已受全局保护。

每步先持久intent（operation_id、mode、checkpoint revision、账号和账本标识），再进入受控事务/平台动作；账本是去重、reservation和结果的权威。checkpoint只在终态证据与账本集合/计数/回执逐项一致后CAS推进。文件和SQLite无法天然同事务，必须覆盖提交前、提交后回执前、事件后checkpoint前崩溃：恢复时有inflight/reservation而缺可靠终态则保持unknown，不启动下一条，不把死亡当not_sent，不自动清锁并重放。今日父未知属于这种阻断，独立目录不得绕过。

## 离线验收

`python -B -m unittest discover -s work/xhs-continuity-candidate-20261110 -p test_checkpoint_adapter.py -v`：8项通过。覆盖未知+停止标记、配置有据补全、冲突与非法断点、白名单拒绝、禁止任意嵌套字段外泄、只读不改父文件、默认advance拒绝、元数据缺失。

RED与GREEN记录：同目录 red-adapter.txt、green-adapter.txt。只执行本次新测试；没有运行旧脚本（包括--help）或旧测试。没有真实平台单步验收、登录验收、共享账本恢复验收、现有任务互斥验收；不能称真实持续采集/发送已接通。
