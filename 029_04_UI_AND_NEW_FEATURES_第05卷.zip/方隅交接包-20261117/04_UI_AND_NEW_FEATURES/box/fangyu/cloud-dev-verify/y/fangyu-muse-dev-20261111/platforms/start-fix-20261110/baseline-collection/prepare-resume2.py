import json,sqlite3,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
b=Path('work/fangyu-douyin-independent');sys.path.insert(0,str(b));from scoped_recovery import initialize,effective_halt
p=json.loads((b/'15-store-plan-collection-20261102.json').read_text(encoding='utf-8'));a=json.loads((b/'active-runner.json').read_text(encoding='utf-8'));c=sqlite3.connect(b/'runtime/collection.sqlite3');c.row_factory=sqlite3.Row;initialize(c)
oldscan=p['scan_id'];p['scan_id']='douyin-20261102-resume-timeout-reviewed'; now=datetime.now(timezone.utc).isoformat()
words=set(p['deferred_previous_account_searches']);videos=set(p['excluded_historical_videos'])
for r in c.execute('select spec from attempts'):
 s=json.loads(r[0])
 if s.get('kind')=='search':words.add(s['target'])
 elif s.get('kind')=='comments':videos.add(s['target'])
for st in p['stores']:st['keywords']=[k for k in st['keywords'] if k not in words]
p['deferred_previous_account_searches']=sorted(words);p['excluded_historical_videos']=sorted(videos);p['previous_plan']=a['plan'];p['explicit_recovery_review']='collection-event-review-20261102-resume2.json';p['resume_authorization']='User explicitly requested resume; one never-requested search page validation only, stop on any new unknown or platform block.'
allowed=sorted({k for st in p['stores'] for k in st['keywords']});assert allowed
oldreview=c.execute('select * from collection_scope_reviews where account_uid=? and scan_id=?',(p['account_uid'],oldscan)).fetchone();assert oldreview
c.execute('insert into collection_scope_reviews values(?,?,?,?,?,?,?)',(p['account_uid'],p['scan_id'],oldreview['reviewed_request_id'],json.dumps(allowed),json.dumps(sorted(videos)),p['resume_authorization'],now))
rid='58bfc4dd-7114-45ef-85e5-b00a365cb979';attempt=c.execute('select * from attempts where request_id=?',(rid,)).fetchone();assert attempt
review={'account_uid':p['account_uid'],'scan_id':p['scan_id'],'request_id':rid,'response_sha256':hashlib.sha256(attempt['response'].encode()).hexdigest(),'authorization':p['resume_authorization'],'evidence':'identity-collection-resume2-20261102.json; same connection and UID, loaded Douyin jingxuan page without visible challenge; business still requires one bounded validation','reviewed_at':now,'unknown_preserved':True,'unknown_target_excluded':json.loads(attempt['spec'])['target'],'validation_limit':1}
c.execute('insert into collection_event_reviews values(?,?,?,?,?,?,?)',tuple(review[k] for k in ['account_uid','scan_id','request_id','response_sha256','authorization','evidence','reviewed_at']))
assert effective_halt(c,p['account_uid'],p['scan_id']) is None
assert effective_halt(c,p['account_uid'],oldscan) is not None
c.commit();c.close()
(b/'15-store-plan-collection-resume2-20261102.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8');(b/p['explicit_recovery_review']).write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
a.update(plan='15-store-plan-collection-resume2-20261102.json',directory='runner-live-collection-resume2-20261102',identity='identity-collection-resume2-20261102.json',explicit_recovery_review=p['explicit_recovery_review'],status='validating_single_page',stdout='runner-collection-resume2-20261102-stdout.log',stderr='runner-collection-resume2-20261102-stderr.log',effective_halt_source='scoped_recovery.effective_halt: all event halts, exact response-hash manual reviews for this scope only; any new halt blocks')
(b/'active-runner.json').write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'allowed_keywords':len(allowed),'excluded_words':len(words),'excluded_videos':len(videos),'scope':p['scan_id']}))
