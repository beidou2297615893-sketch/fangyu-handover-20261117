import json
import hashlib
from contextlib import closing
from dataclasses import replace
from types import SimpleNamespace
import sqlite3
import httpx
import unittest
from unittest.mock import patch
import bulk_run as bulk
import scoped_isolation as scope
import tone_singleton as tone
import test_scoped_isolation as base
from managed_send_client import make_client


class Tests(unittest.TestCase):
    def setUp(self):
        self.base = base.Tests('test_default_closed_exact_grant_only_allows_bound_singleton_without_altering_old_rows')
        self.base.setUp(); b = self.base
        self.plan = replace(b.plan, attempt_id=tone.ALLOWED_ATTEMPT, comment_id=tone.TARGET_COMMENT, text=tone.TEXT)
        self.entries = []; self.isolated = {}
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('DELETE FROM local_sender_plans'); db.execute('DELETE FROM reservations')
            db.execute('UPDATE leads SET comment=? WHERE comment=?', (tone.TARGET_COMMENT, b.plan.comment_id))
            for index in range(22):
                token = list(tone.ISOLATED)[index] if index < 2 else 'accepted-' + str(index)
                uid, comment = 'old-uid-' + str(index), 'old-comment-' + str(index)
                record = {'plan': {'sender_uid': b.uid, 'customer_uid': uid, 'comment_id': comment},
                    'result': {'kind': 'unknown', 'api_code': -1} if index < 2 else {'kind': 'platform_receipt', 'receipt_id': 'receipt-' + str(index)}}
                raw = json.dumps(record); sha = hashlib.sha256(raw.encode()).hexdigest()
                db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)', (token, 'xiaohongshu', 'old-customer-' + str(index), comment, 'unknown', None, index))
                db.execute('INSERT INTO local_sender_plans VALUES(?,?)', (token, raw))
                self.entries.append({'attempt_id': token, 'customer_uid': uid, 'comment_id': comment,
                    'state': 'unknown' if index < 2 else 'accepted', 'receipt_id': None if index < 2 else 'receipt-' + str(index), 'record_raw_sha256': sha})
                if index < 2:self.isolated[token] = (sha, uid, comment)
            db.commit()
        self.revoked = scope.revocation_path(b.marker)
        self.revoked.write_bytes(b.marker.read_bytes())
        approved = bulk.read_json(b.approved)
        approved['rows'][-1]['comment_id'] = tone.TARGET_COMMENT
        b.approved.write_text(json.dumps(approved), encoding='utf8')
        self.tone_path = b.root/'tone.json'; self.exclusions = b.root/'exclusions.json'
        target = {**b.row, 'attempt_id': self.plan.attempt_id, 'comment_id': tone.TARGET_COMMENT, 'text': tone.TEXT}
        self.tone_path.write_text(json.dumps({'schema': 'xhs-approved-tone-entry-v1', 'source': 'synthetic approved source', 'entries': [target]}), encoding='utf8')
        self.exclusions.write_text(json.dumps({'sender_uid': b.uid, 'entries': self.entries}), encoding='utf8')
        batch = bulk.read_json(b.singleton)
        batch['rows'] = [target]
        batch['source_sha256'] = {'original_batch': bulk.digest(b.approved), 'tone_approval': bulk.digest(self.tone_path), 'exclusions': bulk.digest(self.exclusions)}
        b.singleton.write_text(json.dumps(batch), encoding='utf8')
        self.constants = patch.multiple(tone, BATCH_SHA=bulk.digest(b.singleton), TONE_SHA=bulk.digest(self.tone_path),
            EXCLUSION_SHA=bulk.digest(self.exclusions), ISOLATED=self.isolated)
        self.constants.start()
        self.original_sha = patch.object(scope, 'APPROVED_SHA', bulk.digest(b.approved)); self.original_sha.start()
        self.policy = tone.TwoUnknownToneSingletonPolicy.from_mapping({
            'schema': 'xhs-two-unknown-new-tone-singleton-v1', 'policy_id': 'huihui-latest-tone-cat-singleton-20261101-v1',
            'sender_uid': b.uid, 'original_batch_path': str(b.approved), 'original_batch_sha256': bulk.digest(b.approved),
            'singleton_batch_sha256': bulk.digest(b.singleton), 'tone_approval_path': str(self.tone_path),
            'tone_approval_sha256': bulk.digest(self.tone_path), 'exclusion_manifest_path': str(self.exclusions),
            'exclusion_manifest_sha256': bulk.digest(self.exclusions), 'isolated_attempts': [
                {'attempt_id': k, 'record_raw_sha256': v[0], 'customer_uid': v[1], 'comment_id': v[2]} for k, v in self.isolated.items()],
            'allowed_attempt_id': self.plan.attempt_id, 'platform_state_path': str(b.state), 'platform_state_sha256': bulk.digest(b.state),
            'halt_marker_path': str(b.marker), 'halt_marker_sha256': bulk.digest(b.marker),
            'revocation_path': str(self.revoked), 'revocation_sha256': bulk.digest(self.revoked)})

    def tearDown(self):
        self.original_sha.stop(); self.constants.stop(); self.base.tearDown()

    def reserve(self, policy=None, plan=None):
        b = self.base
        b.sender._reserve(b.db, plan or self.plan, True, direct_id=True, scoped_isolation_policy=policy)

    def test_exact_new_tone_scope_allows_only_one_pending_target_preserving_22_records(self):
        b = self.base
        with self.assertRaises(b.sender.Refused):self.reserve()
        before = (b.state.read_bytes(), b.marker.read_bytes(), self.revoked.read_bytes())
        bulk.require_platform_access(b.state, b.uid, scoped_grant=self.policy, batch_path=b.singleton)
        self.reserve(self.policy)
        with closing(sqlite3.connect(b.db)) as db:
            for entry in self.entries:
                raw = db.execute('SELECT data FROM local_sender_plans WHERE token=?', (entry['attempt_id'],)).fetchone()[0]
                self.assertEqual(hashlib.sha256(raw.encode()).hexdigest(), entry['record_raw_sha256'])
        self.assertEqual((b.state.read_bytes(), b.marker.read_bytes(), self.revoked.read_bytes()), before)
        with self.assertRaises(b.sender.Refused):self.reserve(self.policy)

    def test_wrong_text_target_or_any_new_unknown_is_not_exempt(self):
        b = self.base
        for plan in (replace(self.plan, text='changed'), replace(self.plan, comment_id='outside'), replace(self.plan, customer_uid=self.entries[0]['customer_uid'])):
            with self.assertRaises(b.sender.Refused):self.reserve(self.policy, plan)
        with closing(sqlite3.connect(b.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)', ('new-unknown', 'xiaohongshu', 'extra', 'extra-comment', 'unknown', None, 23))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)', ('new-unknown', json.dumps({'plan': {'sender_uid': b.uid, 'customer_uid': 'extra-uid'}, 'result': {'kind': 'unknown'}})))
            db.commit()
        with self.assertRaises(b.sender.Refused):self.reserve(self.policy)

    def test_new_halt_generation_blocks_this_grant_when_state_write_fails(self):
        b = self.base
        adapter = bulk.LiveAdapter.__new__(bulk.LiveAdapter)
        adapter.expected_uid = b.uid; adapter.platform_access_state = b.state
        adapter.platform_access_state_digest = bulk.digest(b.state); adapter.initial_identity_receipt = None
        adapter.last_client = SimpleNamespace(_locked=False, managed_request_context={'request_started': True})
        adapter._permanent_halt = False
        def failed(*args):raise OSError('synthetic primary failure')
        adapter.halt_writer = failed
        adapter.persist_platform_halt(RuntimeError('synthetic new failure'), diagnostic={'verification_header_present': True}, post_started=True)
        with self.assertRaises(bulk.Stop):bulk.require_platform_access(b.state, b.uid, scoped_grant=self.policy, batch_path=b.singleton)

    def test_real_native_runner_uses_exact_new_cat_body_and_one_post(self):
        b = self.base
        session = b.root/'synthetic-cat-session.json'
        session.write_text(json.dumps({'a1':'synthetic','webId':'synthetic','web_session':'synthetic'}), encoding='utf8')
        calls = []
        def response(request):
            calls.append(request)
            if request.method == 'GET':return httpx.Response(200,json={'success':True,'data':{'user_id':b.uid,'guest':False}})
            return httpx.Response(200,json={'success':True,'code':0,'data':{'comment':{'id':'synthetic-cat-receipt'}}})
        before = b.state.read_bytes(), b.marker.read_bytes(), self.revoked.read_bytes()
        with make_client(b.sender, session, self.plan, transport=httpx.MockTransport(response)) as client:
            result = b.sender.Runner(b.db, client, synthetic=True, direct_id=True,
                scoped_isolation_policy=self.policy).submit(self.plan)
        self.assertEqual(result, 'receipt_received_unverified')
        posts = [request for request in calls if request.method == 'POST']
        self.assertEqual(len(posts), 1)
        self.assertEqual(json.loads(posts[0].content)['content'], tone.TEXT)
        self.assertEqual(json.loads(posts[0].content)['target_comment_id'], tone.TARGET_COMMENT)
        self.assertEqual((b.state.read_bytes(), b.marker.read_bytes(), self.revoked.read_bytes()), before)


if __name__ == '__main__':unittest.main()
