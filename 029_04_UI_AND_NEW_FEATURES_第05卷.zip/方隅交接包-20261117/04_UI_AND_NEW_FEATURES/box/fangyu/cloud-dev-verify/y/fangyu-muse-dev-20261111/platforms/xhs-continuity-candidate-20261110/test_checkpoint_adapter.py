"""Offline adapter contract tests; fixtures never load platform modules."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent


class CheckpointAdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.assert_adapter = HERE / 'checkpoint_adapter.py'

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=HERE)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.parent = self.root / 'parent'
        self.parent.mkdir()
        self.write(self.parent / 'state.json', {'status': 'outcome_unknown', 'cursor': 0,
            'next_batch': 46, 'plan': [{'keyword': '找房', 'page': 2}],
            'inflight': {'batch': 'batch-0046', 'keyword': '找房', 'page': 2}})
        self.write(self.parent / 'task-config.json', {'expected_uid': 'fixture-uid',
            'ledger': str(self.root / 'never-open.sqlite3'), 'session_home': str(self.root / 'never-read-session'),
            'delay': 10, 'send_authorized': False})

    def write(self, path, data):
        path.write_text(json.dumps(data), encoding='utf8')

    def adapter(self):
        self.assertTrue(self.assert_adapter.exists(), 'checkpoint adapter implementation is missing')
        spec = importlib.util.spec_from_file_location('checkpoint_adapter', self.assert_adapter)
        mod = importlib.util.module_from_spec(spec)
        import sys
        sys.modules[spec.name] = mod
        spec.loader.exec_module(mod)
        return mod

    def test_unknown_parent_and_markers_never_allow_execution(self):
        mod = self.adapter()
        stop = self.root / 'stop-today-resume007.json'
        self.write(stop, {'date': '2026-11-10', 'reason': 'outcome_unknown'})
        (self.parent / 'STOP').write_text('stop', encoding='utf8')
        report = mod.inspect_checkpoint(self.parent, stop_paths=[stop])
        self.assertTrue(report['cannot_execute'])
        self.assertFalse(report['can_collect'])
        self.assertFalse(report['can_send'])
        self.assertIn('parent_outcome_unknown', report['unmet'])
        self.assertIn('inflight_requires_reconciliation', report['unmet'])
        self.assertIn('stop_marker_present', report['unmet'])
        self.assertEqual(46, report['checkpoint']['next_batch'])
        self.assertEqual(2, len(report['stop_markers']))
        self.assertFalse((self.root / 'never-read-session').exists())
        self.assertFalse((self.root / 'never-open.sqlite3').exists())

    def test_config_completion_requires_readable_matching_evidence(self):
        mod = self.adapter()
        report = mod.inspect_checkpoint(self.parent)
        self.assertIn('source_db', report['missing_config'])
        self.assertNotIn('source_db', report['executor_config'])
        prior = self.root / 'older'
        prior.mkdir()
        evidence = prior / 'task-config.json'
        self.write(evidence, {'source_db': 'fixture-source-db', 'shared_ledger': True,
            'max_comment_pages': 2, 'task': 'fixture task', 'operator': 'fixture operator'})
        report = mod.inspect_checkpoint(self.parent, evidence_configs=[evidence])
        self.assertEqual([], report['missing_config'])
        self.assertEqual('fixture-source-db', report['executor_config']['source_db'])
        self.assertEqual(str(evidence.resolve()), report['config_sources']['source_db'])
        self.assertTrue(report['cannot_execute'])

    def test_conflicting_config_and_malformed_checkpoint_are_blocking(self):
        mod = self.adapter()
        evidence = self.root / 'task-config.json'
        self.write(evidence, {'expected_uid': 'other-uid'})
        self.write(self.parent / 'state.json', {'status': 'ready', 'cursor': True,
            'plan': [{'keyword': '找房', 'page': 2}], 'inflight': None})
        report = mod.inspect_checkpoint(self.parent, evidence_configs=[evidence])
        self.assertIn('config_evidence_conflict', report['unmet'])
        self.assertIn('invalid_checkpoint', report['unmet'])
        self.assertTrue(report['cannot_execute'])

    def test_only_named_metadata_and_no_arbitrary_sensitive_fields(self):
        mod = self.adapter()
        evidence = self.root / 'cookies.json'
        evidence.write_text('do not read', encoding='utf8')
        with self.assertRaises(mod.MetadataRefused):
            mod.inspect_checkpoint(self.parent, evidence_configs=[evidence])
        config = json.loads((self.parent / 'task-config.json').read_text())
        config['cookie'] = 'sensitive-fixture-must-not-escape'
        self.write(self.parent / 'task-config.json', config)
        report = mod.inspect_checkpoint(self.parent)
        self.assertNotIn('sensitive-fixture-must-not-escape', json.dumps(report))

    def test_checkpoint_projection_does_not_copy_arbitrary_nested_metadata(self):
        mod = self.adapter()
        path = self.parent / 'state.json'
        state = json.loads(path.read_text())
        state['inflight']['cookie'] = 'nested-sensitive-fixture'
        self.write(path, state)
        report = mod.inspect_checkpoint(self.parent)
        self.assertNotIn('nested-sensitive-fixture', json.dumps(report))

    def test_precheck_does_not_modify_parent_metadata(self):
        mod = self.adapter()
        before = {p.name: p.read_bytes() for p in self.parent.iterdir()}
        mod.inspect_checkpoint(self.parent)
        after = {p.name: p.read_bytes() for p in self.parent.iterdir()}
        self.assertEqual(before, after)

    def test_default_adapter_refuses_every_advance_even_with_ready_metadata(self):
        mod = self.adapter()
        instance = mod.BlockedCheckpointAdapter(self.parent)
        step = mod.ReviewedStep(operation_id='fixture-1', mode='collect', checkpoint_revision='fixture-hash')
        with self.assertRaises(mod.ExecutionRefused):
            instance.advance(step)
        self.assertTrue(instance.review()['cannot_execute'])
        with self.assertRaises(TypeError):
            mod.ReviewedStepAdapter()

    def test_missing_metadata_is_diagnostic_and_never_approved(self):
        mod = self.adapter()
        (self.parent / 'state.json').unlink()
        report = mod.inspect_checkpoint(self.parent)
        self.assertIn('metadata_missing_or_invalid', report['unmet'])
        self.assertTrue(report['cannot_execute'])


if __name__ == '__main__':
    unittest.main()
