'use strict';
// Dedicated read-only adapter: no publish function, and no reply text is returned.
const {responseGate,assertPageReady}=require('../douyin-local-control/page_guard.cjs');
function safeId(value) {
 if(typeof value==='string' && /^\d+$/.test(value))return value;
 if(typeof value==='number' && Number.isSafeInteger(value) && value>=0)return String(value);
 return '';
}
function findFollowup(comments, customer, ourReply) {
 let ambiguous=false;
 for(const item of comments || []) {
  if(safeId(item?.user?.uid_str ?? item?.user?.uid)!==safeId(customer))continue;
  const parent=item.reply_to_reply_id ?? item.reply_to_comment_id ?? item.reply_id;
  if(parent==null){ambiguous=true;continue;}
  if(safeId(parent) && safeId(parent)===safeId(ourReply) && safeId(item.cid_str??item.cid))
   return {found:true,followup_id:safeId(item.cid_str??item.cid)};
 }
 return {found:false,ambiguous};
}
function expression(video, root, cursor){
 return `(async()=>{if(typeof window.__bridge.replies!=='function')return {unsupported:true};let timer;
 const r=await Promise.race([window.__bridge.replies(${JSON.stringify(root)},${JSON.stringify(video)},${JSON.stringify(cursor)},20),new Promise(resolve=>{timer=setTimeout(()=>resolve({read_timeout:true}),8000)})]);clearTimeout(timer);
 return {status_code:r.status_code,status_msg:r.status_msg,has_more:r.has_more,cursor:r.cursor,
 comments:Array.isArray(r.comments)?r.comments.map(c=>({cid:c.cid,cid_str:c.cid_str,user:{uid:c.user?.uid,uid_str:c.user?.uid_str},reply_id:c.reply_id,reply_to_comment_id:c.reply_to_comment_id,reply_to_reply_id:c.reply_to_reply_id})):null};})()`;
}
async function scan(client,conn,spec,options={}) {
 const deadline=Date.now()+(options.budgetMs??45000), seen=new Set();let cursor=0,pages=0;
 for(;pages<100 && Date.now()<deadline;pages++){
  if(seen.has(String(cursor)))return {state:'unknown',reason:'cursor_repeat',pages};seen.add(String(cursor));
  let response;try{response=await client.call({site:'douyin.com',connId:conn,timeout:12000,expression:expression(spec.video,spec.root,cursor)});}catch{return {state:'unknown',reason:'read_error',pages};}
  if(!response.ok||response.connection!==conn)return {state:'unknown',reason:'connection_error',pages};
  const r=response.value||{};if(responseGate(r))return {state:'unknown',reason:'platform_verification',pages};
  if(r.unsupported||r.status_code!==0||!Array.isArray(r.comments))return {state:'unknown',reason:'incomplete_response',pages};
  const result=findFollowup(r.comments,spec.customer,spec.ourReply);
  if(result.found)return {state:'replied',reason:'exact_identity_and_target',pages:pages+1,followup_id:result.followup_id};
  if(r.has_more===0||r.has_more===false)return {state:'unknown',reason:'absence_unverified',pages:pages+1};
  if(r.cursor==null)return {state:'unknown',reason:'missing_cursor',pages:pages+1};cursor=r.cursor;
 }
 return {state:'unknown',reason:'budget_or_page_limit',pages};
}
module.exports={findFollowup,expression,scan};
