"""Explicit latest-tone cat reply: one target, two unchanged unknown records."""
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import scoped_isolation as scope

TARGET_COMMENT = '6ac0e3c2000000000d025e7f'
ALLOWED_ATTEMPT = 'c08819bb-1acc-4b92-bc6e-e1b367836729'
TEXT = '宝宝，我住方隅这边，能带猫的，介绍有优惠。'
BATCH_SHA = '044af577ea053a14ecb4044df7d3bf884c9f0e5f12f935c512649abd6ff54958'
TONE_SHA = '46a8143b958cd525591362a78e4c2f4a45c0a284127c7a92a71c33d292f99efb'
EXCLUSION_SHA = 'b96e18596bef4f716ae332d6de0f32d65000e582eefc6c8c09253db4a1793727'
ISOLATED = {
    '4c5c7b52-6558-4a64-b1c1-111fe6af42d1': ('8c62140a954938c5acf85967d0c6752d1657dc68fddfcd970b6ba8cc92c04659', '59579a7250c4b4550253f01b', '6ae21371000000001203577f'),
    '70ca24e8-4a44-4846-a379-ae407869ceed': ('723842d95c1f2fda21da29ea09e82233e03f7cace57d0b5c41e6ecc1b5e27bce', '5f23bf250000000001000060', '6ae08923000000000a022acc')}


def validate_excluded_records(db, entries, sender_uid):
    for entry in entries:
        row = db.execute('SELECT r.status,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token '
            'WHERE r.token=? AND r.platform=?', (entry['attempt_id'], 'xiaohongshu')).fetchone()
        if not row or hashlib.sha256(row['data'].encode('utf8')).hexdigest() != entry['record_raw_sha256']:
            return False
        record = json.loads(row['data']); old_plan = record.get('plan', {}); result = record.get('result', {})
        if (old_plan.get('sender_uid') != sender_uid or old_plan.get('customer_uid') != entry['customer_uid'] or
            old_plan.get('comment_id') != entry['comment_id']):
            return False
        if entry['state'] == 'accepted':
            if (row['status'] not in ('unknown', 'sent') or result.get('kind') != 'platform_receipt' or
                not entry.get('receipt_id') or result.get('receipt_id') != entry['receipt_id']):
                return False
        elif (row['status'] != 'unknown' or result.get('kind') != 'unknown' or scope.known_restriction(result) or
              (entry['record_raw_sha256'], entry['customer_uid'], entry['comment_id']) != ISOLATED.get(entry['attempt_id'])):
            return False
    return True


@dataclass(frozen=True)
class TwoUnknownToneSingletonPolicy:
    schema: str
    policy_id: str
    sender_uid: str
    original_batch_path: str
    original_batch_sha256: str
    singleton_batch_sha256: str
    tone_approval_path: str
    tone_approval_sha256: str
    exclusion_manifest_path: str
    exclusion_manifest_sha256: str
    isolated_attempts: list
    allowed_attempt_id: str
    platform_state_path: str
    platform_state_sha256: str
    halt_marker_path: str
    halt_marker_sha256: str
    revocation_path: str
    revocation_sha256: str

    @classmethod
    def from_mapping(cls, value):
        if (not isinstance(value, dict) or set(value) != set(cls.__dataclass_fields__) or
            not isinstance(value.get('isolated_attempts'), list) or
            any(not isinstance(v, str) or not v for k, v in value.items() if k != 'isolated_attempts')):
            raise scope.ScopeRefused('tone_singleton_schema_invalid')
        return cls(**value)

    def validate_context(self, batch_path, sender_uid):
        if (sender_uid != scope.SCOPED_UID or self.sender_uid != sender_uid or
            self.schema != 'xhs-two-unknown-new-tone-singleton-v1' or
            self.policy_id != 'huihui-latest-tone-cat-singleton-20261101-v1' or
            self.original_batch_sha256 != scope.APPROVED_SHA or self.singleton_batch_sha256 != BATCH_SHA or
            self.tone_approval_sha256 != TONE_SHA or self.exclusion_manifest_sha256 != EXCLUSION_SHA or
            self.allowed_attempt_id != ALLOWED_ATTEMPT):
            raise scope.ScopeRefused('tone_singleton_binding_invalid')
        if (Path(self.revocation_path).resolve() != scope.revocation_path(self.halt_marker_path).resolve() or
            scope.revocation_path(self.revocation_path).exists() or scope.revocation_path(self.revocation_path).is_symlink()):
            raise scope.ScopeRefused('tone_singleton_grant_revoked')
        for path, sha in ((self.platform_state_path, self.platform_state_sha256),
                          (self.halt_marker_path, self.halt_marker_sha256), (self.revocation_path, self.revocation_sha256)):
            state = scope.checked_json(path, sha)
            if (state.get('sender_uid') != sender_uid or state.get('state') != 'unknown_requires_reconciliation' or
                state.get('cleared') is not False or scope.known_restriction(state)):
                raise scope.ScopeRefused('tone_singleton_has_restriction')
        isolated = {item['attempt_id']: (item['record_raw_sha256'], item['customer_uid'], item['comment_id'])
                    for item in self.isolated_attempts}
        if len(self.isolated_attempts) != 2 or isolated != ISOLATED:
            raise scope.ScopeRefused('tone_singleton_isolation_invalid')
        original = scope.checked_json(self.original_batch_path, self.original_batch_sha256)
        batch = scope.checked_json(batch_path, self.singleton_batch_sha256)
        if (original.get('count') != 567 or len(original.get('rows', [])) != 567 or
            batch.get('schema') != 'xhs-local-plan-v1' or batch.get('intended_account_uid') != sender_uid or
            batch.get('count') != 1 or len(batch.get('rows', [])) != 1):
            raise scope.ScopeRefused('tone_singleton_batch_invalid')
        target = batch['rows'][0]
        original_rows = [r for r in original['rows'] if r.get('comment_id') == TARGET_COMMENT]
        if (len(original_rows) != 1 or target.get('comment_id') != TARGET_COMMENT or target.get('text') != TEXT or
            target.get('attempt_id') != self.allowed_attempt_id or
            any(target.get(k) != original_rows[0].get(k) for k in ('customer_id', 'customer_uid', 'comment_id', 'note_id'))):
            raise scope.ScopeRefused('tone_singleton_target_changed')
        tone = scope.checked_json(self.tone_approval_path, self.tone_approval_sha256)
        if tone.get('schema') != 'xhs-approved-tone-entry-v1' or not tone.get('source') or len(tone.get('entries', [])) != 1:
            raise scope.ScopeRefused('tone_singleton_approval_missing')
        if any(tone['entries'][0].get(k) != target.get(k) for k in ('comment_id', 'customer_uid', 'note_id', 'text')):
            raise scope.ScopeRefused('tone_singleton_approval_mismatch')
        excluded = scope.checked_json(self.exclusion_manifest_path, self.exclusion_manifest_sha256)
        entries = excluded.get('entries', [])
        if (excluded.get('sender_uid') != sender_uid or len(entries) != 22 or
            len({e['attempt_id'] for e in entries}) != 22 or sum(e.get('state') == 'accepted' for e in entries) != 20 or
            {e['attempt_id'] for e in entries if e.get('state') == 'unknown'} != set(ISOLATED) or
            any(e.get('customer_uid') == target.get('customer_uid') or e.get('comment_id') == TARGET_COMMENT for e in entries)):
            raise scope.ScopeRefused('tone_singleton_exclusions_invalid')
        for key, expected in (('tone_approval', self.tone_approval_sha256), ('exclusions', self.exclusion_manifest_sha256),
                              ('original_batch', self.original_batch_sha256)):
            if batch.get('source_sha256', {}).get(key) != expected:
                raise scope.ScopeRefused('tone_singleton_sources_changed')
        return target, entries

    def validate_ledger(self, db, plan, batch_path):
        try:
            target, entries = self.validate_context(batch_path, plan.sender_uid)
            if any(target.get(k) != getattr(plan, field) for k, field in (
                ('attempt_id', 'attempt_id'), ('customer_id', 'canonical_customer'), ('customer_uid', 'customer_uid'),
                ('comment_id', 'comment_id'), ('note_id', 'note_id'), ('text', 'text'))):
                return False
            for entry in entries:
                row = db.execute('SELECT r.status,p.data FROM reservations r JOIN local_sender_plans p ON p.token=r.token '
                    'WHERE r.token=? AND r.platform=?', (entry['attempt_id'], 'xiaohongshu')).fetchone()
                if not row or hashlib.sha256(row['data'].encode('utf8')).hexdigest() != entry['record_raw_sha256']:
                    return False
                record = json.loads(row['data']); old_plan = record.get('plan', {}); result = record.get('result', {})
                if (old_plan.get('sender_uid') != self.sender_uid or old_plan.get('customer_uid') != entry['customer_uid'] or
                    old_plan.get('comment_id') != entry['comment_id']):
                    return False
                if entry['state'] == 'accepted':
                    if (row['status'] not in ('unknown', 'sent') or result.get('kind') != 'platform_receipt' or
                        not entry.get('receipt_id') or result.get('receipt_id') != entry['receipt_id']):
                        return False
                elif (row['status'] != 'unknown' or result.get('kind') != 'unknown' or scope.known_restriction(result) or
                      (entry['record_raw_sha256'], entry['customer_uid'], entry['comment_id']) != ISOLATED.get(entry['attempt_id'])):
                    return False
            return True
        except (scope.ScopeRefused, OSError, ValueError, TypeError, KeyError, AttributeError):
            return False

    def permits(self, plan, old_row, batch_path, *, db=None):
        return (db is not None and old_row['token'] in ISOLATED and self.validate_ledger(db, plan, batch_path) and
                old_row['status'] == 'unknown' and hashlib.sha256(old_row['data'].encode('utf8')).hexdigest() == ISOLATED[old_row['token']][0])
