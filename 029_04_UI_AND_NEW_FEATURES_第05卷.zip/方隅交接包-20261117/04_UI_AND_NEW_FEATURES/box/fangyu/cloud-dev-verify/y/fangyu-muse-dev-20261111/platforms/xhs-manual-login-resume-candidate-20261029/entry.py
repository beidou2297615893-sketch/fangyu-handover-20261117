"""Offline-only manual post-verification controller, no built-in network.

The injected client must do exactly one signed identity request with retries
disabled. Caller must install this before starting a new login, never attach to
an unrelated live browser. No navigation, solving, collection or sending.
"""
from resume import COOKIE_NAMES, verified_session

def snapshot(items):
    if not isinstance(items,list):
        return None
    out={}
    for item in items:
        if not isinstance(item,dict):
            return None
        name,value,domain=(item.get('name'),item.get('value'),item.get('domain'))
        if not isinstance(name,str) or name not in COOKIE_NAMES:
            continue
        if not isinstance(domain,str) or domain.lstrip('.').lower() not in ('xiaohongshu.com','www.xiaohongshu.com'):
            continue
        if not isinstance(value,str) or not value:
            continue
        if name in out and out[name]!=value:
            return None
        out[name]=value
    return out if all(out.get(n) for n in ('a1','webId','web_session')) else None

class ManualResume:
    def __init__(self,page,client_factory,save,expected_uid=None):
        self.page=page; self.factory=client_factory; self.save=save
        self.expected_uid=expected_uid; self.attempted=False
    def check(self,*,user_confirmed):
        if user_confirmed is not True:
            return {'status':'awaiting_user'}
        if self.attempted:
            return {'status':'already_attempted'}
        # After any user-authorized check begins, failure is terminal. Do not
        # reissue an unknown platform request or silently repeat a save.
        self.attempted=True
        try:
            if self.page.is_closed(): return {'status':'page_closed'}
            items=self.page.context.cookies()
            original=snapshot(items)
        except Exception:
            return {'status':'session_unavailable'}
        if original is None:
            return {'status':'session_incomplete_or_conflict'}
        client=None
        try:
            client=self.factory(dict(original))
            payload=client.get_self_info()
            if dict(client.cookies)!=original:
                return {'status':'session_changed'}
        except Exception:
            return {'status':'identity_request_failed_no_retry'}
        finally:
            if client is not None:
                try: client.close()
                except Exception: pass
        try:
            if self.page.is_closed(): return {'status':'page_closed'}
            if snapshot(self.page.context.cookies())!=original:
                return {'status':'session_changed'}
        except Exception:
            return {'status':'session_unavailable'}
        response={'after_challenge':True,'status':200,'host':'www.xiaohongshu.com',
                  'path':'/api/sns/web/v2/user/me','body':payload}
        return verified_session(user_confirmed=True,browser_open=True,response=response,
            cookie_items=items,save=self.save,expected_uid=self.expected_uid)
