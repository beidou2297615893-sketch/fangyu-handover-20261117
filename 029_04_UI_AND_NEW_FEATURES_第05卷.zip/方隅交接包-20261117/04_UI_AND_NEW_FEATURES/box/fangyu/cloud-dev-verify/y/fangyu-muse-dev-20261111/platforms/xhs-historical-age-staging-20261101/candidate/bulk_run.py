"""Sequential approved replies using the existing sender. Preview by default.

No platform I/O on import or preview. Execute owns the private session for the
whole run. Search tokens live only in memory. Events supplement, never rewrite,
the sender's authoritative receipt/unknown ledger semantics. No POST retries.
Explicit --direct-id uses frozen IDs and approved text without searches or
comment reads. Acceptance receipts then remain publicly unverified.
"""
import argparse
from contextlib import closing, contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
from scoped_isolation import (ScopedUnknownIsolationPolicy, ReceiptQualifiedIsolationPolicy,
    ScopeRefused, known_restriction, parse_isolation_policy, revocation_path)
from tone_singleton import TwoUnknownToneSingletonPolicy
from tone_batch import NewToneBatchReceiptPolicy
from target_isolation import AuthorizedTargetIsolationPolicy,complete_business_rejection,plan_matches

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
SENDER_UID = '5aa9b337e8ac2b4ab2d21957'
DEFAULT_HOME = PROJECT / 'work/xhs-standalone-session/stores15-user-relogin-20261030-03'
DEFAULT_BATCH = HERE / 'runs/leimu-readiness-20261030-01/prepared-batch.json'
DEFAULT_PLATFORM_ACCESS_STATE = HERE / 'platform-access-state.json'
EMERGENCY_HALT_ROOT = HERE / 'emergency-platform-halts'
LEDGER = PROJECT / 'work/shared-acquisition-ledger/shared.sqlite3'
CLOSED_WORDS = ('已出租', '已租出', '已成交')


class Stop(RuntimeError):
    """A fixed safe reason code, never a raw HTTP response or exception text."""


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Events:
    def __init__(self, root, sender_uid):
        self.path = root / 'events.jsonl'
        self.stream = self.path.open('x', encoding='utf8')
        self.sender_uid = sender_uid

    def emit(self, event, row=None, **fields):
        data = {'at': now(), 'event': event, 'sender_uid': self.sender_uid,
                'automatic_retry': False, **fields}
        if row:
            # Explicit projection: no arbitrary source/token/session fields.
            data.update({k: row[k] for k in ('sequence', 'attempt_id', 'customer_id',
                         'customer_uid', 'comment_id', 'note_id') if k in row})
        self.stream.write(json.dumps(data, ensure_ascii=False) + '\n')
        self.stream.flush()
        os.fsync(self.stream.fileno())

    def close(self):
        self.stream.close()


@contextmanager
def session_lock(home):
    home = Path(home).resolve(strict=True)
    lock = home / '.managed-use.lock'
    lock.mkdir()  # Atomic exclusive ownership; never reclaim another owner.
    try:
        with (lock / 'owner.json').open('x', encoding='utf8') as stream:
            json.dump({'pid': os.getpid(), 'at': now(), 'task': 'approved_bulk_reply'}, stream)
            stream.flush()
            os.fsync(stream.fileno())
        yield
    finally:
        (lock / 'owner.json').unlink(missing_ok=True)
        lock.rmdir()


def mapping_reason(row, meta, today=None, *, policy=None, batch_path=None):
    if not isinstance(meta, dict):
        return 'target_mapping_missing'
    if meta.get('customer_uid') != row['customer_uid'] or meta.get('canonical_customer') != row['customer_id']:
        return 'target_mapping_conflict'
    if not isinstance(meta.get('original_comment'), str) or not meta['original_comment'].strip():
        return 'original_text_missing'
    title = meta.get('post_title')
    if not isinstance(title, str) or not title.strip():
        return 'post_title_missing'
    if any(word in title for word in CLOSED_WORDS):
        return 'post_no_longer_available'
    try:
        published = datetime.fromisoformat(meta['published_at'].replace('Z', '+00:00'))
        if published.tzinfo is None:
            return 'comment_date_unknown'
        current = datetime.fromisoformat(today).replace(tzinfo=timezone.utc) if today else datetime.now(timezone.utc)
        if (current - published).total_seconds() > 60 * 86400:
            if (not isinstance(policy,AuthorizedTargetIsolationPolicy) or
                not policy.allows_historical_age(row,meta,batch_path=batch_path)):
                return 'comment_older_than_60_days'
    except (ValueError, TypeError, KeyError, AttributeError):
        return 'comment_date_unknown'
    return None


def field_values(comment, fields):
    return [comment[key] for key in fields if key in comment]


def user_values(comment):
    values = field_values(comment, ('user_id',))
    for key in ('user_info', 'user', 'author'):
        if key in comment:
            if not isinstance(comment[key], dict):
                return [None]
            values += field_values(comment[key], ('user_id', 'userid', 'uid', 'id'))
    return values


def target_reason(comment, row, meta):
    if not isinstance(comment, dict):
        return 'target_shape_unknown'
    ids = field_values(comment, ('id', 'comment_id'))
    if not ids or any(value != row['comment_id'] for value in ids):
        return 'target_id_conflict'
    bodies = field_values(comment, ('content', 'comment_text'))
    if not bodies or any(value != meta['original_comment'] for value in bodies):
        return 'target_text_changed'
    users = user_values(comment)
    if not users or any(value != row['customer_uid'] for value in users):
        return 'target_customer_changed'
    parents = field_values(comment, ('root_comment_id', 'target_comment_id', 'parent_comment_id'))
    target = comment.get('target_comment')
    if target is not None:
        if not isinstance(target, dict):
            return 'target_relation_unknown'
        parents += field_values(target, ('id', 'comment_id'))
    if any(value not in (None, '', '0', row['comment_id']) for value in parents):
        return 'target_is_nested'
    return None


def run(rows, mapping, *, sender_uid, session_home, run_dir, execute=False,
        adapter_factory=None, today=None, interval=3.0, direct_id=False):
    """Adapter injection keeps tests offline; every platform fault ends the run."""
    if not execute:
        return {'mode': 'preview', 'count': len(rows), 'network': False,
                'ledger_write': False, 'send': False, 'direct_id': direct_id,
                'sender_uid': sender_uid,
                'local_holds': sum(bool(mapping_reason(r, mapping.get(r['comment_id']), today)) for r in rows)}
    if not callable(adapter_factory) or interval < 0:
        raise ValueError('execution_adapter_and_valid_interval_required')
    root = Path(run_dir)
    root.mkdir(parents=True, exist_ok=False)
    with session_lock(session_home):
        log = Events(root, sender_uid)
        adapter = None
        summary = {'status': 'complete', 'accepted': 0, 'visible_verified': 0,
                   'public_visibility_unverified': 0, 'direct_id': direct_id,
                   'held': 0, 'submit_calls': 0, 'post_attempts': 0,'target_unknown_isolated':0}
        current = None
        submission_started = False
        post_attempts_before = 0
        try:
            log.emit('started', count=len(rows), platform_history_checked=False,
                     all_accounts_history_checked=False, direct_id=direct_id,
                     authorization='user_approved_entire_existing_batch')
            adapter = adapter_factory(root)
            identity = adapter.identity()
            if not isinstance(identity, dict) or identity.get('uid') != sender_uid or identity.get('guest') is not False:
                raise Stop('identity_unverified')
            log.emit('identity_verified', guest=False)
            for current in rows:
                submission_started = False
                if (root / 'STOP').exists():
                    summary['status'] = 'paused_by_user'
                    log.emit('paused', current, reason='user_stop_file')
                    break
                meta = mapping.get(current['comment_id'])
                reason = mapping_reason(current, meta, today,
                    policy=getattr(adapter,'scoped_isolation_policy',None),batch_path=getattr(adapter,'batch_path',None))
                if reason is None and adapter.state(current) != 'pending':
                    reason = 'existing_or_unresolved_local_history'
                if reason:
                    summary['held'] += 1
                    log.emit('held', current, reason=reason)
                    continue
                context = None
                if not direct_id:
                    context = adapter.context(current, meta)
                    if context is None:
                        reason = 'current_note_context_not_found'
                    elif any(word in context.get('title', '') for word in CLOSED_WORDS):
                        reason = 'current_post_no_longer_available'
                    else:
                        reason = adapter.target(current, meta, context)
                    if reason:
                        summary['held'] += 1
                        log.emit('held', current, reason=reason)
                        continue
                log.emit('frozen_target_selected' if direct_id else 'target_verified', current,
                         original_comment=meta['original_comment'], platform_target_read=not direct_id,
                         approved_reply=current['text'], platform_history_checked=False,
                         all_accounts_history_checked=False)
                # Re-read immediately before submit; existing Runner also checks
                # customer/UID/history atomically inside its reservation.
                if adapter.state(current) != 'pending':
                    summary['held'] += 1
                    log.emit('held', current, reason='history_changed_before_submit')
                    continue
                if (root / 'STOP').exists():
                    summary['status'] = 'paused_by_user'
                    log.emit('paused', current, reason='user_stop_file')
                    break
                log.emit('submission_starting', current, approved_reply=current['text'])
                submission_started = True
                post_attempts_before = getattr(adapter, 'post_attempts', 0)
                summary['submit_calls'] += 1
                try:
                    result = adapter.submit(current)
                except Exception as exc:
                    summary['post_attempts']=getattr(adapter,'post_attempts',0)
                    isolate=getattr(adapter,'isolate_target_error',None)
                    safe=project_diagnostic(adapter.diagnostic(exc))
                    verified=(isolate(current,safe) if callable(isolate) and
                        summary['post_attempts']-post_attempts_before==1 and complete_business_rejection(safe) else None)
                    if not isinstance(verified,dict) or verified.get('verified') is not True:raise
                    summary['target_unknown_isolated']+=1
                    log.emit('unknown',current,reason='complete_business_response_target_isolated',diagnostic=safe,
                        isolated_target_only=True,continuing_other_customers=True,retry_allowed=False,
                        ledger_record_sha256=verified['record_raw_sha256'])
                    submission_started=False
                    if interval:time.sleep(interval)
                    continue
                summary['post_attempts'] = getattr(adapter, 'post_attempts', 0)
                if result != 'receipt_received_unverified':
                    raise Stop('submission_result_unknown')
                receipt = adapter.receipt(current)
                if not isinstance(receipt, str) or not receipt.strip():
                    raise Stop('receipt_missing_in_authoritative_ledger')
                summary['accepted'] += 1
                summary['public_visibility_unverified'] += 1
                accepted_diagnostic = getattr(adapter, 'acceptance_diagnostic', None)
                accepted_safe = project_diagnostic(accepted_diagnostic()) if callable(accepted_diagnostic) else {}
                log.emit('accepted', current, receipt_id=receipt, public_visibility_checked=False,
                         public_visibility='unverified', diagnostic=accepted_safe)
                if known_restriction(accepted_safe):
                    submission_started = False  # This exact receipt remains accepted.
                    raise Stop('accepted_receipt_with_restriction_signal')
                if not direct_id:
                    if adapter.verify(current, context, receipt) is not True:
                        raise Stop('receipt_visibility_unconfirmed')
                    summary['visible_verified'] += 1
                    summary['public_visibility_unverified'] -= 1
                    log.emit('visible_verified', current, receipt_id=receipt, exact_reply_id=True,
                             exact_sender_uid=True, exact_root_id=True, exact_text=True,
                             authoritative_ledger_state_unchanged=True)
                submission_started = False
                if interval:
                    time.sleep(interval)
            log.emit('finished', **summary)
        except BaseException as exc:
            summary['post_attempts'] = getattr(adapter, 'post_attempts', 0)
            unresolved_post = submission_started and summary['post_attempts'] > post_attempts_before
            summary['status'] = 'stopped_unknown' if unresolved_post else 'stopped'
            try:
                diagnostic = adapter.diagnostic(exc) if adapter is not None else {}
            except Exception:
                diagnostic = {}
            # An adapter is trusted code, but diagnostics still go through an
            # explicit fixed projection: arbitrary exception strings never pass.
            safe = project_diagnostic(diagnostic)
            halt_result = {}
            persist_halt = getattr(adapter, 'persist_platform_halt', None)
            if callable(persist_halt):
                try:
                    halt_result = persist_halt(exc, diagnostic=safe,
                        post_started=summary['post_attempts'] > post_attempts_before)
                except Exception:
                    halt_result = {'halted': True, 'state_written': False,
                                   'emergency_marker_written': False, 'persistence_failed': True}
            log.emit('unknown' if unresolved_post else 'stopped', current,
                     reason=str(exc) if isinstance(exc, Stop) else 'operation_failed_no_retry',
                     diagnostic=safe, platform_halt=halt_result, retry_allowed=False)
        finally:
            if adapter is not None:
                adapter.close()
            log.close()
        with (root / 'summary.json').open('x', encoding='utf8') as stream:
            json.dump(summary, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        return summary


SAFE_DIAGNOSTIC_VALUES = frozenset({
    'identity', 'search', 'comments', 'send', 'unknown', 'comment_post', 'search_notes',
    'prewarm_onebox', 'prewarm_filter', 'external_session_replaced', 'account_changed_no_retry',
    'identity_unverified', 'authentication_update_requires_relogin', 'session_file_unavailable',
    'session_expired', 'verification_required', 'rate_limited', 'platform_error',
    'external_memory_session_changed', 'session_save_failed_or_unknown', 'session_save_unknown',
    'managed_session_locked', 'cookie_update_requires_review', 'page_budget_exhausted',
    'legacy_account_submission_unresolved', 'local_reservation_guard',
    'after_reservation_before_post', 'post_started_or_unknown'})
SAFE_MESSAGE_CATEGORIES = frozenset({'rate_limit', 'verification', 'login', 'permission',
    'target_unavailable', 'signature', 'system_error', 'unknown'})
SAFE_ERROR_TYPES = frozenset({'XhsApiError', 'NeedVerifyError', 'SessionExpiredError', 'IpBlockedError',
    'SignatureError', 'HttpUnknown', 'Unknown', 'TimeoutException', 'ConnectError', 'ReadTimeout', 'OtherError'})


def project_diagnostic(diagnostic):
    safe = {key: value for key, value in diagnostic.items()
            if key in ('http_status', 'api_code') and type(value) is int}
    for key in ('post_started', 'request_started', 'success', 'verification_header_present'):
        if type(diagnostic.get(key)) is bool:
            safe[key] = diagnostic[key]
    for key in ('stage', 'request_stage', 'endpoint', 'category'):
        value = diagnostic.get(key)
        if isinstance(value, str) and value in SAFE_DIAGNOSTIC_VALUES:
            safe[key] = value
    for key, allowed in (('message_category', SAFE_MESSAGE_CATEGORIES), ('error_type', SAFE_ERROR_TYPES)):
        value = diagnostic.get(key)
        if isinstance(value, str) and value in allowed:
            safe[key] = value
    return safe


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def halt_marker_path(path, sender_uid):
    reference = os.path.normcase(str(Path(path).resolve()))
    key = hashlib.sha256((sender_uid + '\n' + reference).encode('utf8')).hexdigest()
    return EMERGENCY_HALT_ROOT / (key + '.json')


def atomic_platform_state(path, payload, expected_digest):
    """Same-directory atomic replace with pre/post-write source hash checks."""
    path = Path(path)
    if path.is_symlink() or digest(path) != expected_digest:
        raise Stop('platform_access_state_changed')
    raw = json.dumps(payload, ensure_ascii=False, indent=2).encode('utf8')
    fd, temporary = tempfile.mkstemp(prefix='.platform-halt-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        if path.is_symlink() or digest(path) != expected_digest:
            raise Stop('platform_access_state_changed')
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def require_platform_access(path, sender_uid, *, scoped_grant=None, batch_path=None):
    """Keep the known old challenge halted; bind a fresh account to its receipt.

    A normal new-account identity receipt establishes only that account's
    initial access context. It never clears another account's known challenge.
    """
    revoked = revocation_path(halt_marker_path(path, sender_uid))
    if (revoked.exists() or revoked.is_symlink()) and not isinstance(scoped_grant, (TwoUnknownToneSingletonPolicy,NewToneBatchReceiptPolicy,AuthorizedTargetIsolationPolicy)):
        raise Stop('persistent_platform_halt_requires_review')
    if scoped_grant is not None:
        try:
            if not isinstance(scoped_grant, (ScopedUnknownIsolationPolicy, ReceiptQualifiedIsolationPolicy, TwoUnknownToneSingletonPolicy,NewToneBatchReceiptPolicy,AuthorizedTargetIsolationPolicy)):
                raise ScopeRefused('scope_type_invalid')
            scoped_grant.validate_context(batch_path, sender_uid)
            if (Path(path).resolve() != Path(scoped_grant.platform_state_path).resolve() or
                halt_marker_path(path, sender_uid).resolve() != Path(scoped_grant.halt_marker_path).resolve()):
                raise ScopeRefused('scope_state_path_mismatch')
        except (ScopeRefused, OSError, ValueError, TypeError, KeyError):
            raise Stop('scoped_isolation_grant_invalid') from None
        return {'sender_uid': sender_uid, 'state': 'unknown_requires_reconciliation',
                'identity_receipt': read_json(path).get('identity_receipt')}
    # Marker is keyed by both UID and exact state path. A fresh identity receipt
    # or a new run name cannot clear a previous challenge or unknown submission.
    marker = halt_marker_path(path, sender_uid)
    if marker.exists() or marker.is_symlink():
        raise Stop('persistent_platform_halt_requires_review')
    try:
        state = read_json(path)
    except (OSError, ValueError, TypeError):
        raise Stop('platform_access_state_missing_or_invalid') from None
    if not isinstance(state, dict) or state.get('sender_uid') != sender_uid:
        raise Stop('platform_access_state_missing_or_invalid')
    if state.get('state') in ('verification_response_unresolved', 'unknown_requires_reconciliation'):
        raise Stop('platform_verification_pending')
    if sender_uid == SENDER_UID:
        # This UID already has a known challenge. A new-state label, a changed
        # cleared boolean or another account's identity cannot remove it.
        raise Stop('platform_clearance_evidence_review_required')
    if (state.get('schema') != 'xhs-new-account-access-v1' or
            state.get('state') != 'new_account_identity_verified_no_known_challenge'):
        raise Stop('platform_access_state_missing_or_invalid')
    if Path(path).resolve() == DEFAULT_PLATFORM_ACCESS_STATE.resolve():
        raise Stop('new_account_requires_independent_access_state')
    reference = state.get('identity_receipt')
    if (not isinstance(reference, dict) or not isinstance(reference.get('path'), str) or
            not reference['path'].strip() or not isinstance(reference.get('sha256'), str)):
        raise Stop('normal_identity_receipt_required')
    receipt_path = Path(reference['path'])
    if not receipt_path.is_absolute():
        receipt_path = Path(path).parent / receipt_path
    try:
        if receipt_path.is_symlink():
            raise Stop('normal_identity_receipt_required')
        raw = receipt_path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != reference['sha256']:
            raise Stop('normal_identity_receipt_changed')
        receipt = json.loads(raw.decode('utf-8-sig'))
    except (OSError, ValueError, UnicodeError):
        raise Stop('normal_identity_receipt_required') from None
    if (not isinstance(receipt, dict) or receipt.get('uid') != sender_uid or
            receipt.get('sender_uid', sender_uid) != sender_uid or
            receipt.get('guest') is not False or receipt.get('saved') is not True or
            receipt.get('retry_allowed') is not False or
            receipt.get('source') != 'same_page_session_single_identity_request'):
        raise Stop('normal_identity_receipt_unverified')
    try:
        verified = datetime.fromisoformat(receipt['verified_at'].replace('Z', '+00:00'))
        if verified.tzinfo is None:
            raise ValueError('timezone required')
        age = (datetime.now(timezone.utc) - verified).total_seconds()
        if not -30 <= age <= 900:
            raise ValueError('stale or future receipt')
    except (KeyError, ValueError, TypeError, AttributeError):
        raise Stop('normal_identity_receipt_expired_or_invalid') from None
    return {'sender_uid': sender_uid, 'state': state['state'], 'identity_receipt': reference,
            'identity_receipt_sha256': reference['sha256'], 'verified_at': receipt['verified_at']}


class LiveAdapter:
    """Thin composition of reviewed search, readback, ledger and POST adapters."""
    def __init__(self, root, *, home, batch_path, sender_uid, ledger=LEDGER,
                 source_manifest=HERE / 'source-manifest.json', max_pages=3, delay=3.0,
                 direct_id=False, legacy_account_policy=None,
                 platform_access_state=DEFAULT_PLATFORM_ACCESS_STATE, scoped_isolation_grant=None):
        if scoped_isolation_grant is not None and (not direct_id or legacy_account_policy is not None):
            raise Stop('scoped_isolation_requires_exclusive_direct_id')
        try:
            self.scoped_isolation_policy = (parse_isolation_policy(read_json(scoped_isolation_grant))
                                            if scoped_isolation_grant is not None else None)
        except (OSError, ValueError, TypeError):
            raise Stop('scoped_isolation_grant_invalid') from None
        initial_access = require_platform_access(platform_access_state, sender_uid,
            scoped_grant=self.scoped_isolation_policy, batch_path=batch_path)
        if legacy_account_policy is not None and sender_uid != SENDER_UID:
            raise Stop('legacy_policy_sender_mismatch')
        if not direct_id and legacy_account_policy is not None:
            raise Stop('legacy_policy_requires_direct_id')
        if read_json(batch_path).get('intended_account_uid') != sender_uid:
            raise Stop('batch_sender_mismatch')
        if not 1 <= max_pages <= 3:
            raise ValueError('small_bounded_page_budget_required')
        self.home = Path(home).resolve(strict=True)
        self.session = self.home / '.xiaohongshu-cli/cookies.json'
        self.expected_uid = sender_uid
        self.root, self.ledger = Path(root), Path(ledger)
        self.max_pages, self.delay = max_pages, delay
        self.direct_id = direct_id
        self.platform_access_state = Path(platform_access_state)
        self.platform_access_state_digest = digest(self.platform_access_state)
        self.initial_identity_receipt = initial_access.get('identity_receipt')
        self.halt_writer = atomic_platform_state
        self._permanent_halt = False
        self.last_client = None
        self.post_attempts = 0
        self.token_cache = {}
        self.session_digest = digest(self.session)
        # Dependencies load only after --execute and the exclusive session lock.
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(HERE))
        sys.path.insert(0, str(PROJECT / 'work/xhs-new-task-session-fix-20261029'))
        if not direct_id:
            self.integration = load_module('approved_bulk_integration', PROJECT / 'work/xhs-new-task-session-fix-20261029/integration.py')
            self.live, self.account, _, _ = self.integration.load()
        self.cli = load_module('approved_bulk_cli', PROJECT / 'work/xhs-cli-standalone-entry/standalone_cli.py')
        self.readback = load_module('approved_bulk_readback', HERE / 'readback_client.py')
        self.send_client = load_module('approved_bulk_send_client', HERE / 'managed_send_client.py')
        sources = self.cli.source_manifest(source_manifest)
        self.sender = self.cli.load_sender(PROJECT, self.ledger, batch_path, sources)
        self.legacy_account_policy = (self.sender.LegacyAccountGuardPolicy.from_mapping(read_json(legacy_account_policy))
                                      if legacy_account_policy is not None else None)
        self.batch = self.cli.load_batch(batch_path)
        self.batch_path = Path(batch_path)
        if self.batch.get('intended_account_uid') != sender_uid:
            raise Stop('batch_sender_mismatch')
        # Hash each immutable source once before the first network request.
        hashes = self.batch.get('source_sha256')
        if not isinstance(hashes, dict) or set(hashes) != set(sources):
            raise Stop('frozen_source_manifest_conflict')
        if any(digest(path) != hashes[key] for key, path in sources.items()):
            raise Stop('frozen_source_changed')
        for row in self.batch['rows']:
            plan = self.cli.make_plan(self.sender, row, sender_uid, self.batch['schema'])
            self.cli.verify_prepared(plan, batch_path, sources, require_hashes=False)

    def _guard(self):
        if self._permanent_halt:
            raise Stop('persistent_platform_halt_requires_review')
        if digest(self.platform_access_state) != self.platform_access_state_digest:
            raise Stop('platform_access_state_changed')
        if self.session.is_symlink() or any(p.is_symlink() for p in self.session.parents):
            raise Stop('external_session_replaced')
        if digest(self.session) != self.session_digest:
            raise Stop('external_session_replaced')

    @contextmanager
    def _client(self, kind, plan=None):
        self._guard()
        if kind == 'search':
            client = self.integration.client_factory(self.expected_uid, delay=self.delay)(self.home, self.root / 'cache')
        elif kind == 'readback':
            client = self.readback.ReadbackClient(self.session, self.expected_uid, delay=self.delay)
        else:
            client = self.send_client.make_client(self.sender, self.session, plan)
        self.last_client = client
        try:
            yield client
            # Only a successful managed request can advance our trusted digest.
            expected = getattr(client, '_digest', None)
            actual = hashlib.sha256(self.session.read_bytes()).digest()
            if expected != actual:
                raise Stop('external_session_replaced')
            self.session_digest = actual.hex()
        except BaseException:
            observed={**getattr(client,'last_response_diagnostics',{}),**getattr(client,'last_request_context',{}),
                      'request_started':getattr(client,'_post_started',False)}
            if (kind=='send' and complete_business_rejection(observed) and
                getattr(client,'_managed_identity_verified',False) is True):
                client._guard()  # Recheck exact file/memory; never adopt an external replacement.
                expected=getattr(client,'_digest',None)
                actual=hashlib.sha256(self.session.read_bytes()).digest()
                if expected!=actual:raise Stop('external_session_replaced')
                self.session_digest=actual.hex()
            raise
        finally:
            client.close()

    def identity(self):
        with self._client('readback') as client:
            return client.verify_identity()

    def state(self, row):
        return self.cli.row_state(row, self.cli.ledger_states(self.ledger))

    def context(self, row, mapping):
        if self.direct_id:
            raise Stop('direct_id_search_not_enabled')
        note_id = row['note_id']
        if note_id in self.token_cache:
            self._guard()
            return self.token_cache[note_id]
        with self._client('search') as client:
            identity = self.account.identify(client.get_self_info())
            if identity['uid'] != self.expected_uid or identity['guest'] is not False:
                raise Stop('identity_unverified')
            data = self.live.search_without_recommend(client, keyword=mapping['post_title'], page=1)
            if not isinstance(data, dict) or not isinstance(data.get('items'), list):
                raise Stop('search_response_unknown')
            matches = []
            for item in data['items']:
                if not isinstance(item, dict):
                    continue
                card = item.get('note_card')
                if not isinstance(card, dict):
                    continue
                ids = [value for value in (item.get('id'), card.get('note_id')) if value]
                if not ids or any(value != note_id for value in ids):
                    continue
                tokens = [value for value in (item.get('xsec_token'), card.get('xsec_token')) if value]
                if not tokens or not all(isinstance(value, str) and value == tokens[0] for value in tokens):
                    continue
                title = card.get('display_title', card.get('title', ''))
                if not isinstance(title, str):
                    raise Stop('current_title_unknown')
                matches.append({'token': tokens[0], 'title': title})
            if not matches:
                return None
            if any(value != matches[0] for value in matches):
                raise Stop('current_note_context_conflict')
            self.token_cache[note_id] = matches[0]
            return matches[0]

    def target(self, row, mapping, context):
        if self.direct_id:
            raise Stop('direct_id_target_read_not_enabled')
        with self._client('readback') as client:
            client.verify_identity()
            cursor, seen = '', set()
            for _ in range(self.max_pages):
                if cursor in seen:
                    raise Stop('comment_cursor_repeated')
                seen.add(cursor)
                data = client.get_comments(row['note_id'], cursor=cursor, xsec_token=context['token'],
                                           top_comment_id=row['comment_id'])
                if not isinstance(data, dict) or not isinstance(data.get('comments'), list):
                    raise Stop('comment_page_unknown')
                roots = [value for value in data['comments'] if isinstance(value, dict) and
                         row['comment_id'] in field_values(value, ('id', 'comment_id'))]
                if len(roots) > 1:
                    return 'target_ambiguous'
                if roots:
                    return target_reason(roots[0], row, mapping)
                for root in data['comments']:
                    if not isinstance(root, dict):
                        continue
                    for key in ('sub_comments', 'subcomments'):
                        children = root.get(key, [])
                        if isinstance(children, list) and any(isinstance(child, dict) and
                                row['comment_id'] in field_values(child, ('id', 'comment_id')) for child in children):
                            return 'target_is_nested'
                more = data.get('has_more')
                if type(more) is not bool:
                    raise Stop('comment_pagination_unknown')
                if not more:
                    return 'target_not_found'
                cursor = data.get('cursor')
                if not isinstance(cursor, str) or not cursor:
                    raise Stop('comment_cursor_missing')
            return 'target_not_found_within_page_budget'

    def submit(self, row):
        plan = self.cli.make_plan(self.sender, row, self.expected_uid, self.batch['schema'])
        with self._client('send', plan) as client:
            try:
                return self.sender.Runner(self.ledger, client,
                    legacy_account_policy=self.legacy_account_policy, direct_id=self.direct_id,
                    scoped_isolation_policy=self.scoped_isolation_policy).submit(plan)
            finally:
                if getattr(client, '_post_started', False) is True:
                    self.post_attempts += 1

    def receipt(self, row):
        path = self.ledger.resolve(strict=True)
        with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=2)) as db:
            db.execute('PRAGMA query_only=ON')
            record = db.execute('SELECT data FROM local_sender_plans WHERE token=?', (row['attempt_id'],)).fetchone()
        if not record:
            return None
        record = json.loads(record[0])
        plan, result = record.get('plan', {}), record.get('result', {})
        expected = {'sender_uid': self.expected_uid, 'customer_uid': row['customer_uid'],
                    'canonical_customer': row['customer_id'], 'comment_id': row['comment_id'],
                    'note_id': row['note_id'], 'text': row['text'], 'attempt_id': row['attempt_id']}
        if not isinstance(plan, dict) or any(plan.get(key) != value for key, value in expected.items()):
            raise Stop('ledger_receipt_plan_conflict')
        return result.get('receipt_id') if isinstance(result, dict) and result.get('kind') == 'platform_receipt' else None

    def acceptance_diagnostic(self):
        observed = getattr(self.last_client, 'last_response_diagnostics', {})
        context = getattr(self.last_client, 'last_request_context', {})
        return {**observed, **context} if isinstance(observed, dict) and isinstance(context, dict) else {}

    def isolate_target_error(self,row,diagnostic):
        if not isinstance(getattr(self,'scoped_isolation_policy',None),AuthorizedTargetIsolationPolicy) or not complete_business_rejection(diagnostic):return None
        try:
            self._guard()
            self.last_client._guard()
            path=self.ledger.resolve(strict=True)
            with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=2)) as db:
                db.execute('PRAGMA query_only=ON')
                stored=db.execute('SELECT r.status,r.customer,r.comment,p.data,l.status FROM reservations r '
                    'JOIN local_sender_plans p ON p.token=r.token JOIN leads l ON l.platform=r.platform AND l.customer=r.customer AND l.comment=r.comment '
                    'WHERE r.platform=? AND r.token=?',('xiaohongshu',row['attempt_id'])).fetchone()
            if not stored or stored[0]!='unknown' or stored[4]!='unknown' or stored[1]!=row['customer_id'] or stored[2]!=row['comment_id']:return None
            data=json.loads(stored[3]);result=data.get('result',{})
            if (not plan_matches(row,data.get('plan',{}),self.expected_uid) or result.get('kind')!='unknown' or
                not complete_business_rejection(result) or any(result.get(k)!=diagnostic.get(k) for k in
                    ('http_status','api_code','success','verification_header_present','endpoint','message_category'))):return None
            return {'verified':True,'record_raw_sha256':hashlib.sha256(stored[3].encode()).hexdigest()}
        except (OSError,ValueError,TypeError,KeyError,sqlite3.Error,Stop):return None

    def verify(self, row, context, receipt):
        if self.direct_id:
            raise Stop('direct_id_visibility_read_not_enabled')
        # A fresh independently authenticated readback client; sender has closed.
        with self._client('readback') as client:
            client.verify_identity()
            for page in client.iter_subcomment_pages(row['note_id'], row['comment_id'], context['token'],
                                                     max_pages=self.max_pages):
                for comment in page['comments']:
                    match = self.readback.match_receipt(comment, reply_id=receipt, sender_uid=self.expected_uid,
                                                        root_comment_id=row['comment_id'], text=row['text'])
                    if match['status'] == 'verified':
                        return True
            return False

    def diagnostic(self, exc):
        # Fixed local refusal only: never persist arbitrary exception messages.
        if (isinstance(exc, self.sender.Refused) and
                str(exc) == 'Account has a previous unresolved submission'):
            return {'category': 'legacy_account_submission_unresolved',
                    'stage': 'local_reservation_guard', 'post_started': False,
                    'retry_allowed': False}
        client = self.last_client
        context = getattr(client, 'managed_request_context', {})
        data = dict(context) if isinstance(context, dict) else {}
        detail = getattr(client, 'last_failure_detail', {})
        if isinstance(detail, dict):
            data.update(detail)
        native_diagnostics = getattr(self.sender, 'failure_diagnostics', None)
        if callable(native_diagnostics):
            data.update(native_diagnostics(exc, client))
        stop = getattr(client, 'last_managed_stop', None)
        if isinstance(stop, dict):
            data['category'] = stop.get('reason')
        for key in ('status', 'code'):
            value = getattr(exc, key, None)
            if type(value) is int:
                data['http_status' if key == 'status' else 'api_code'] = value
        return data

    def persist_platform_halt(self, exc, *, diagnostic, post_started):
        """Persist only this account's actual platform failure; never clear one."""
        client = self.last_client
        context = getattr(client, 'managed_request_context', {})
        locked = (getattr(client, '_locked', False) is True or
                  getattr(client, '_managed_locked', False) is True)
        started = isinstance(context, dict) and context.get('request_started') is True
        status, code = diagnostic.get('http_status'), diagnostic.get('api_code')
        known_failure = known_restriction(diagnostic)
        session_stop = isinstance(exc, Stop) and str(exc) in {
            'external_session_replaced', 'external_memory_session_changed', 'session_file_unavailable'}
        if not (post_started or known_failure or (locked and started) or session_stop):
            return {'halted': False, 'state_written': False, 'emergency_marker_written': False}
        self._permanent_halt = True
        safe = project_diagnostic(diagnostic)
        safe['post_started'] = bool(post_started)
        target = 'verification_response_unresolved' if known_failure else 'unknown_requires_reconciliation'
        reference = getattr(self, 'initial_identity_receipt', None)
        current = None
        try:
            candidate = read_json(self.platform_access_state)
            if isinstance(candidate, dict) and candidate.get('sender_uid') == self.expected_uid:
                current = candidate
                reference = reference or current.get('identity_receipt')
        except (OSError, ValueError, TypeError):
            pass
        payload = {'schema': 'xhs-platform-halt-marker-v1', 'sender_uid': self.expected_uid,
                   'state': target, 'cleared': False, 'halted_at': now(),
                   'identity_receipt': reference, 'diagnostic': safe,
                   'automatic_retry': False, 'do_not_infer_clearance_from_identity': True}
        marker = halt_marker_path(self.platform_access_state, self.expected_uid)
        marker_written = False
        try:
            marker.parent.mkdir(parents=True, exist_ok=True)
            with marker.open('x', encoding='utf8') as stream:
                json.dump(payload, stream, ensure_ascii=False, indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            marker_written = True
        except FileExistsError:
            # Never reuse an acknowledged halt as evidence of a new halt.
            # Append one generation; grant validators reject the next generation.
            newer = revocation_path(marker)
            for _ in range(66):
                try:
                    with newer.open('x', encoding='utf8') as stream:
                        json.dump({**payload, 'schema': 'xhs-platform-halt-revocation-v1',
                                   'revokes_previous_grants': True}, stream, ensure_ascii=False, indent=2)
                        stream.flush()
                        os.fsync(stream.fileno())
                    marker_written = True
                    break
                except FileExistsError:
                    newer = revocation_path(newer)
                except OSError:
                    break
        except OSError:
            pass
        state_written = False
        if current is not None:
            replacement = {**current, **payload, 'schema': current.get('schema', payload['schema'])}
            try:
                self.halt_writer(self.platform_access_state, replacement, self.platform_access_state_digest)
                state_written = True
            except Exception:
                pass  # Emergency marker still blocks the same UID and state.
        if not (marker_written or state_written):
            raise Stop('platform_halt_persistence_failed')
        return {'halted': True, 'state_written': state_written,
                'emergency_marker_written': marker_written}

    def close(self):
        self.token_cache.clear()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--direct-id', action='store_true',
                        help='Use frozen IDs without search/target reads; receipts remain publicly unverified')
    parser.add_argument('--legacy-account-policy', type=Path,
                        help='Exact reviewed single-record account guard policy; direct-ID only')
    parser.add_argument('--scoped-isolation-grant', type=Path,
                        help='Exact one-target continuation grant; preserves old unknown and halt files')
    parser.add_argument('--sender-uid', default=SENDER_UID,
                        help='Actual approved account UID; must match the prepared batch and live identity')
    parser.add_argument('--platform-access-state', type=Path, default=DEFAULT_PLATFORM_ACCESS_STATE,
                        help='Account-specific normal-identity evidence or unresolved platform halt state')
    parser.add_argument('--batch', type=Path, default=DEFAULT_BATCH)
    parser.add_argument('--mapping', type=Path, default=HERE / 'target-mapping.json')
    parser.add_argument('--source-manifest', type=Path, default=HERE / 'source-manifest.json')
    parser.add_argument('--session-home', type=Path, default=DEFAULT_HOME)
    parser.add_argument('--run-name', help='New, dedicated directory name; never reuse')
    parser.add_argument('--interval', type=float, default=3.0)
    args = parser.parse_args(argv)
    if args.scoped_isolation_grant is not None and (not args.direct_id or args.legacy_account_policy is not None):
        parser.error('scoped grant requires direct-ID and cannot combine account exception policies')
    if args.legacy_account_policy is not None and not args.direct_id:
        parser.error('--legacy-account-policy requires --direct-id')
    if args.legacy_account_policy is not None and args.sender_uid != SENDER_UID:
        parser.error('legacy account policy applies only to its original UID')
    batch = read_json(args.batch)
    rows = batch.get('rows') if isinstance(batch, dict) else None
    if not isinstance(rows, list) or batch.get('count') != len(rows):
        parser.error('invalid batch')
    if batch.get('intended_account_uid') != args.sender_uid:
        parser.error('batch intended UID and explicit sender UID differ')
    raw_mapping = read_json(args.mapping)
    mapping = {item['comment_id']: item for item in raw_mapping}
    if len(mapping) != len(raw_mapping):
        parser.error('ambiguous mapping')
    if args.execute:
        if not args.run_name or not args.run_name.replace('-', '').replace('_', '').isalnum():
            parser.error('--execute requires a new safe --run-name')
        if args.interval < 1:
            parser.error('live interval must be at least one second')
        allowed = (PROJECT / 'work/xhs-standalone-session').resolve(strict=True)
        home = args.session_home.resolve(strict=True)
        if home == allowed or not home.is_relative_to(allowed):
            parser.error('explicit private session home required')
        if digest(args.mapping) != batch.get('source_sha256', {}).get('target_mapping'):
            parser.error('target mapping differs from frozen approved source')
    result = run(rows, mapping, sender_uid=args.sender_uid, session_home=args.session_home,
                 run_dir=HERE / 'runs' / (args.run_name or 'preview-unused'), execute=args.execute,
                 interval=args.interval, direct_id=args.direct_id,
                 adapter_factory=lambda root: LiveAdapter(root, home=args.session_home,
                     batch_path=args.batch, sender_uid=args.sender_uid, direct_id=args.direct_id,
                     legacy_account_policy=args.legacy_account_policy,
                     platform_access_state=args.platform_access_state,
                     source_manifest=args.source_manifest,
                     scoped_isolation_grant=args.scoped_isolation_grant))
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result.get('status', 'complete') in ('complete', 'paused_by_user') else 2


if __name__ == '__main__':
    raise SystemExit(main())
