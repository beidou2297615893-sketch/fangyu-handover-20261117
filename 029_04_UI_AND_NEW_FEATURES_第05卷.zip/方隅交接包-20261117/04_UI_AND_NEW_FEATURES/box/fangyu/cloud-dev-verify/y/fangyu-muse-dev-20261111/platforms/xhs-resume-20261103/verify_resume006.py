"""Single identity read with redacted failure evidence; never prints credentials."""
import argparse,importlib.util,json,sys
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
p=argparse.ArgumentParser();p.add_argument('--session-home',required=True);p.add_argument('--uid',default='5f469df5000000000101ec0b');p.add_argument('--execute',action='store_true');a=p.parse_args()
if not a.execute:
    print(json.dumps({'status':'preview','network':False,'uid':a.uid}));raise SystemExit(0)
spec=importlib.util.spec_from_file_location('identity_inbox',PROJECT/'work/xhs-reply-inbox/client.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r={'at':datetime.now(timezone.utc).isoformat(),'uid':a.uid,'session_home':str(Path(a.session_home).resolve()),'automatic_retry':False};c=None
try:
    c=m.InboxClient(Path(a.session_home)/'.xiaohongshu-cli/cookies.json',a.uid)
    result=c.verify();r.update(status='verified',uid=result['uid'])
except Exception as e:
    r.update(status='stopped',error_type=type(e).__name__)
    reason=str(e)
    allowed=set(m.managed.MANAGED_STOP_REASONS)|{'session_symlink_refused','session_file_invalid','session_file_incomplete','identity_required','verification_required','session_update_requires_review','invalid_json','platform_business_error','invalid_data','account_mismatch'}
    if reason in allowed:r['reason']=reason
    if c is not None:
        for k in ['safe_error','last_managed_stop','last_http_evidence','managed_request_context']:
            v=getattr(c,k,None)
            if isinstance(v,dict):r[k]=v
        review=getattr(c,'last_cookie_review',None)
        if isinstance(review,dict):r['cookie_review_kind']=review.get('kind')
finally:
    if c is not None:c.close()
out=HERE/('identity-check-resume006-verified.json' if r['status']=='verified' else 'identity-check-resume006-latest-failure.json')
out.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(r,ensure_ascii=False))
