"""Local-only ordering of already-authorized rows; never adds targets or texts."""
import hashlib,json
from pathlib import Path

def order_rows(rows, pointer):
    info=json.loads(Path(pointer).read_text(encoding="utf-8-sig"))["platforms"]["xiaohongshu"]
    for key,sha in (("source","source_sha256"),("queue","sha256")):
        if hashlib.sha256(Path(info[key]).read_bytes()).hexdigest()!=info[sha]:
            raise ValueError("daily_time_priority_hash_changed_refresh_required")
    queue=[json.loads(x) for x in Path(info["queue"]).read_text(encoding="utf-8-sig").splitlines() if x.strip()]
    ranks={r["comment_id"]:i for i,r in enumerate(queue)}
    if len(ranks)!=len(queue):raise ValueError("daily_time_priority_duplicate")
    if any(r["comment_id"] not in ranks for r in rows):
        raise ValueError("approved_targets_missing_from_daily_time_priority")
    return sorted(rows,key=lambda r:ranks[r["comment_id"]])
