import tempfile
import unittest
import json
import os
import sqlite3
import subprocess
import sys
import threading
from pathlib import Path
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
from support import Fixture,ROOT,policy

class LedgerPostTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=ROOT/'tests');self.addCleanup(self.temp.cleanup)
    def test_no_ledger_capability_never_releases_original_post(self):
        f=Fixture(self.temp.name)
        if hasattr(f,'_owned_ledger'):del f._owned_ledger
        with self.assertRaises(Exception):f.send()
        self.assertNotIn('POST',f.wires())
    def test_forged_ledger_object_cannot_grant_post(self):
        f=Fixture(self.temp.name)
        class Forged:
            def reserve(self,*args):return {'granted':True}
            def outcome(self,*args):return {'status':'sent'}
        f._owned_ledger=Forged()
        with self.assertRaises(Exception):f.send()
        self.assertNotIn('POST',f.wires())
    def test_original_pipe_success_is_durably_recorded_in_isolated_ledger(self):
        f=Fixture(self.temp.name);result=f.send()
        self.assertEqual(result['platformCommentId'],'receipt')
        self.assertEqual(f.ledger_state(),'sent')
    def test_unknown_response_remains_blocked_in_isolated_ledger(self):
        f=Fixture(self.temp.name,fault='bad_receipt')
        with self.assertRaises(Exception):f.send()
        self.assertEqual(f.ledger_state(),'unknown')
        with self.assertRaises(Exception):f.send()
        self.assertEqual(f.wires().count('POST'),1)
    def test_frozen_mapping_and_review_binding_cannot_change(self):
        for key,value in [('tenant','other'),('actor','other'),('account','other'),('sender','other'),('platform_uid','other'),('canonical','other'),('lead','other'),('note','other'),('comment','other'),('text','other'),('mapping_evidence','other')]:
            with self.subTest(key=key),tempfile.TemporaryDirectory(dir=ROOT/'tests') as directory:
                f=Fixture(directory);binding={**f.binding,key:value}
                f._owned_ledger=type(f._owned_ledger)(f._owned_ledger.path,binding)
                with self.assertRaises(Exception):f.send()
                self.assertNotIn('POST',f.wires())
    def test_historical_unverified_comment_prevents_single_post(self):
        f=Fixture(self.temp.name)
        f.ledger_cli('lead','xiaohongshu','platformUser','older_comment')
        with self.assertRaises(Exception):f.send()
        self.assertNotIn('POST',f.wires())
    def test_nonliteral_true_response_never_allows_post(self):
        for value in (1,'true',False,None):
            with self.subTest(value=value),tempfile.TemporaryDirectory(dir=ROOT/'tests') as directory:
                f=Fixture(directory);original=f._owned_ledger.reserve
                def malformed(*args):
                    original(*args)
                    return {'granted':value}
                with patch.object(f._owned_ledger,'reserve',side_effect=malformed):
                    with self.assertRaises(Exception):f.send()
                self.assertNotIn('POST',f.wires())
                self.assertEqual(f.ledger_state(),'reserved')
    def test_committed_reservation_then_fatal_parent_exception_stays_blocked(self):
        f=Fixture(self.temp.name)
        with patch.object(policy,'consume_budget',side_effect=SystemExit('Synthetic fatal parent interruption')):
            with self.assertRaises(SystemExit):f.send()
        self.assertEqual(f.ledger_state(),'unknown')
        with self.assertRaises(Exception):f.send()
        self.assertNotIn('POST',f.wires())
    def test_sent_writeback_failure_is_never_reported_success(self):
        f=Fixture(self.temp.name);original=f._owned_ledger._run
        def fail_sent(*args):
            if args[0]=='outcome' and args[2]=='sent':raise OSError('Synthetic ledger writeback failure')
            return original(*args)
        with patch.object(f._owned_ledger,'_run',side_effect=fail_sent):
            with self.assertRaises(RuntimeError):f.send()
        self.assertEqual(f.ledger_state(),'unknown')
        with self.assertRaises(Exception):f.send()
        self.assertEqual(f.wires().count('POST'),1)
    def test_permission_revoked_after_reservation_cannot_receive_post_allow(self):
        f=Fixture(self.temp.name);original=f._owned_ledger.reserve
        def revoke(*args):
            result=original(*args);f.lease=False;return result
        with patch.object(f._owned_ledger,'reserve',side_effect=revoke):
            with self.assertRaises(Exception):f.send()
        self.assertEqual(f.ledger_state(),'unknown')
        self.assertNotIn('POST',f.wires())
    def test_replaced_adapter_after_reservation_cannot_allow_post(self):
        f=Fixture(self.temp.name);original=f._owned_ledger.reserve
        def replace(*args):
            result=original(*args)
            f._owned_ledger=type(f._owned_ledger)(f._owned_ledger.path,f.binding)
            return result
        with patch.object(f._owned_ledger,'reserve',side_effect=replace):
            with self.assertRaises(Exception):f.send()
        self.assertNotIn('POST',f.wires())
    def test_mutated_adapter_path_cannot_initialize_outside_test_root(self):
        f=Fixture(self.temp.name)
        with tempfile.TemporaryDirectory(dir=ROOT) as outside:
            database=Path(outside)/'outside.sqlite3';database.touch()
            f._owned_ledger.path=database
            with self.assertRaises(ValueError):f._owned_ledger._run('init')
            self.assertEqual(database.stat().st_size,0)
    def test_writebacks_all_fail_leaves_durable_reservation(self):
        f=Fixture(self.temp.name);original=f._owned_ledger._run
        def fail_outcome(*args):
            if args[0]=='outcome':raise OSError('Synthetic disk failure')
            return original(*args)
        with patch.object(f._owned_ledger,'_run',side_effect=fail_outcome):
            with self.assertRaises(RuntimeError):f.send()
        self.assertEqual(f.ledger_state(),'reserved')
        with self.assertRaises(Exception):f.send()
        self.assertEqual(f.wires().count('POST'),1)
    def test_concurrent_original_parent_calls_only_one_post(self):
        f=Fixture(self.temp.name);barrier=threading.Barrier(4)
        def attempt(_):
            barrier.wait()
            try:f.send();return True
            except Exception:return False
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(attempt,range(4)))
        self.assertEqual(results.count(True),1)
        self.assertEqual(f.wires().count('POST'),1)
        self.assertEqual(f.ledger_state(),'sent')
    def test_four_independent_original_parent_processes_only_one_post(self):
        f=Fixture(self.temp.name)
        script="import sys;sys.path.insert(0,sys.argv[1]);from support import Fixture;f=Fixture(sys.argv[2],existing=True)\ntry:f.send();print('SENT')\nexcept Exception:print('BLOCKED')"
        def attempt(_):
            return subprocess.run([sys.executable,'-X','utf8','-B','-c',script,str(ROOT/'tests'),self.temp.name],capture_output=True,encoding='utf-8',timeout=20)
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(attempt,range(4)))
        self.assertEqual([r.returncode for r in results],[0]*4,[r.stderr for r in results])
        self.assertEqual(sum(r.stdout.strip()=='SENT' for r in results),1)
        self.assertEqual(f.wires().count('POST'),1)
        self.assertEqual(f.ledger_state(),'sent')
    def test_parent_hard_exit_after_reservation_cannot_release_post(self):
        script="import os,sys;sys.path.insert(0,sys.argv[1]);from support import Fixture,policy;f=Fixture(sys.argv[2]);policy.consume_budget=lambda *a:os._exit(91);f.send()"
        result=subprocess.run([sys.executable,'-X','utf8','-B','-c',script,str(ROOT/'tests'),self.temp.name],capture_output=True,timeout=20)
        self.assertEqual(result.returncode,91,result.stderr)
        with closing(sqlite3.connect(os.path.join(self.temp.name,'ledger.sqlite3'))) as db:
            self.assertEqual(db.execute("SELECT status FROM leads WHERE comment='comment'").fetchone()[0],'reserved')
        trace=os.path.join(self.temp.name,'trace.txt')
        if os.path.isfile(trace):
            with open(trace,encoding='utf-8') as f:self.assertNotIn('POST',f.read().splitlines())

if __name__=='__main__':unittest.main()
