import json,sqlite3,tempfile,unittest
from pathlib import Path
from inbox import normalize,open_db,save_items,sync,receipts
from client import projection,InboxClient,InboxStop

UID='5f469df5000000000101ec0b'
KNOWN={'sent1':{'sent_reply_id':'sent1','customer_id':'c','customer_uid':'customer1','original_comment_id':'origin1','note_id':'note1','sent_text':'our reply'}}
def item(**changes):
    d={'id':'notification1','time':1793555180,'user_info':{'userid':'customer1','nickname':'<script>x</script>'},'comment_info':{'id':'incoming1','content':'已经租到了','target_comment':{'id':'sent1','content':'our reply','user_info':{'userid':UID}}},'item_info':{'id':'note1','type':'note_info','link':'https://x/?xsec_token=secret'},'xsec_token':'SECRET'}
    d.update(changes);return d

class Tests(unittest.TestCase):
    def test_true_shape_exact_association(self):
        r=normalize(item(),UID,KNOWN);self.assertEqual(r['note_id'],'note1');self.assertEqual(r['association'],'exact_reply_id');self.assertEqual(r['actor_relation'],'original_customer');self.assertIn('possible_need_ended',r['review_flags']);self.assertNotIn('SECRET',json.dumps(r));self.assertNotIn('xsec_token',json.dumps(r))
    def test_never_associate_note_only(self):
        r=normalize(item(comment_info={'id':'x','content':'hello'}),UID,KNOWN);self.assertEqual(r['association'],'unmatched')
    def test_actual_closed_refusal_and_negative_examples(self):
        for body in ['不用问了宝 我已经找到房子了','我不租房啦 谢谢']:
            r=normalize(item(comment_info={'content':body}),UID,KNOWN);self.assertIn('possible_need_ended',r['review_flags'])
        self.assertIn('possible_contact_refusal',normalize(item(comment_info={'content':'不用啦谢谢'}),UID,KNOWN)['review_flags'])
        for body in ['还没找到房','还没有找到房子，想看看','没有租到，请问还有吗']:
            self.assertNotIn('possible_need_ended',normalize(item(comment_info={'content':body}),UID,KNOWN)['review_flags'])
    def test_target_identity_and_note_mismatch(self):
        d=item();d['comment_info']['target_comment']['user_info']['userid']='wrong';self.assertEqual(normalize(d,UID,KNOWN)['association'],'unmatched')
        self.assertEqual(normalize(item(item_info={'id':'wrong','type':'note_info'}),UID,KNOWN)['association'],'unmatched')
    def test_dedup_and_unknown_retained(self):
        with tempfile.TemporaryDirectory() as d:
            db=open_db(Path(d));self.assertEqual(save_items(db,[item()],UID,KNOWN)[0],1);self.assertEqual(save_items(db,[item()],UID,KNOWN)[0],0);self.assertEqual(save_items(db,[{'alien':'value'}],UID,KNOWN),(1,0,1));self.assertEqual(db.execute('select count(*) from notifications').fetchone()[0],2);db.close()
    def test_true_pagination_checkpoint_and_render(self):
        class Fake:
            calls=[]
            def __init__(self,*a):self._http=self
            def close(self):pass
            def verify(self):return {'uid':UID}
            def get_notification_mentions(self,cursor='',num=20):
                self.calls.append(cursor);return {'message_list':[item()],'has_more':True,'cursor':123,'strCursor':'123'} if not cursor else {'message_list':[],'has_more':False,'cursor':0}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);ledger=root/'ledger';self.ledger(ledger);db=open_db(root)
            first=sync(root,db,'unused',ledger,UID,1,Fake);self.assertEqual(first['stop_reason'],'page_limit_reached');self.assertEqual(json.loads((root/'checkpoint.json').read_text())['cursor'],'123')
            second=sync(root,db,'unused',ledger,UID,1,Fake);self.assertEqual(second['status'],'complete');self.assertEqual(Fake.calls,['','123']);self.assertNotIn('<script>x</script>',(root/'progress.html').read_text());self.assertEqual(len(json.loads((root/'followups.json').read_text())),1);db.close()
    def ledger(self,path):
        db=sqlite3.connect(path);db.executescript('create table reservations(token text,platform text,customer text,comment text);create table local_sender_plans(token text,data text);');db.execute('insert into reservations values(?,?,?,?)',('a','xiaohongshu','c','origin1'));db.execute('insert into local_sender_plans values(?,?)',('a',json.dumps({'plan':{'sender_uid':UID,'customer_uid':'customer1','note_id':'note1','text':'our reply'},'result':{'kind':'platform_receipt','receipt_id':'sent1'}})));db.commit();db.close()
    def test_invalid_schema_stops_not_empty_success(self):
        class Fake:
            def __init__(self,*a):self._http=self
            def close(self):pass
            def verify(self):pass
            def get_notification_mentions(self,**k):return {'new_field':[{'a':'secret'}]}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.ledger(root/'ledger');db=open_db(root);r=sync(root,db,'x',root/'ledger',UID,2,Fake);self.assertEqual(r['stop_reason'],'notification_schema_unrecognized');self.assertNotIn('secret',(root/'schema-review.json').read_text());db.close()
    def test_read_ledger_unchanged(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'ledger';self.ledger(p);before=p.read_bytes();self.assertEqual(receipts(p,UID)['sent1']['sent_text'],'our reply');self.assertEqual(before,p.read_bytes())
    def test_recent_always_head_preserves_history_and_dedups(self):
        class Fake:
            calls=[]
            def __init__(self,*a):self._http=self
            def close(self):pass
            def verify(self):pass
            def get_notification_mentions(self,cursor='',num=20):self.calls.append(cursor);return {'message_list':[item()],'has_more':True,'strCursor':'next'}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.ledger(root/'ledger');db=open_db(root);checkpoint=root/'checkpoint.json';checkpoint.write_text(json.dumps({'account_uid':UID,'cursor':'old-history'}));before=checkpoint.read_bytes()
            a=sync(root,db,'x',root/'ledger',UID,1,Fake,recent_only=True);self.assertEqual(a['stop_reason'],'recent_window_page_limit');self.assertFalse(a['history_complete'])
            b=sync(root,db,'x',root/'ledger',UID,5,Fake,recent_only=True);self.assertEqual(b['stop_reason'],'recent_seen_page');self.assertEqual(b['new_this_sync'],0);self.assertEqual(Fake.calls,['','']);self.assertEqual(before,checkpoint.read_bytes());db.close()
    def test_recent_error_still_stops(self):
        class Fake:
            count=0
            def __init__(self,*a):self._http=self
            def close(self):pass
            def verify(self):pass
            def get_notification_mentions(self,**kw):self.count+=1;raise InboxStop('verification_required')
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.ledger(root/'ledger');db=open_db(root);r=sync(root,db,'x',root/'ledger',UID,5,Fake,recent_only=True);self.assertEqual(r['status'],'stopped');self.assertEqual(r['stop_reason'],'verification_required');db.close()
    def test_publish_contains_only_human_outputs(self):
        class Fake:
            def __init__(self,*a):self._http=self
            def close(self):pass
            def verify(self):pass
            def get_notification_mentions(self,**kw):return {'message_list':[item()],'has_more':False}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'runtime';root.mkdir();pub=Path(d)/'outputs';self.ledger(root/'ledger');db=open_db(root);sync(root,db,'x',root/'ledger',UID,5,Fake,recent_only=True,publish_dir=pub);self.assertEqual({p.name for p in pub.iterdir()},{'progress.html','待跟进通知.csv','待确认关联通知.csv'});self.assertEqual((pub/'待跟进通知.csv').read_bytes(),(root/'待跟进通知.csv').read_bytes());db.close()
    def test_request_hard_allowlist_and_no_retry(self):
        import httpx
        calls=[]
        def transport(req):calls.append(req);return httpx.Response(200,json={'success':True,'data':{}},headers={'verifytype':'1'})
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'cookies.json';p.write_text(json.dumps({'a1':'test','web_session':'test'}));c=InboxClient(p,UID,transport=httpx.MockTransport(transport),delay=0)
            with self.assertRaises(Exception):c._request_with_retry('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post')
            self.assertEqual(calls,[]);c._http.close()
            c=InboxClient(p,UID,transport=httpx.MockTransport(transport),delay=0)
            with self.assertRaises(InboxStop):c._request_with_retry('GET','https://edith.xiaohongshu.com/api/sns/web/v2/user/me')
            self.assertEqual(len(calls),1);self.assertEqual(c.safe_error['verification_header_present'],True);c._http.close()

if __name__=='__main__':unittest.main()
