import pathlib
import subprocess
import unittest


ROOT = pathlib.Path(__file__).resolve().parent
SCRIPT = ROOT / 'launcher.ps1'


class LauncherSafety(unittest.TestCase):
    def run_action(self, action):
        return subprocess.run(
            ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass',
             '-File', str(SCRIPT), '-Action', action],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding='utf-8', timeout=30,
        )

    def test_status_reads_existing_ledger(self):
        result = self.run_action('status')
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('平台已受理', result.stdout)
        self.assertIn('本地待处理', result.stdout)
        self.assertIn('AI 标记待核', result.stdout)

    def test_direct_send_action_is_rejected(self):
        result = self.run_action('send')
        self.assertNotEqual(result.returncode, 0, result.stdout)

    def test_plan_is_only_a_preview_of_explicit_menu_command(self):
        result = self.run_action('plan')
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('pending-batch.json', result.stdout)
        self.assertIn('source-manifest.json', result.stdout)
        self.assertIn('--interval', result.stdout)
        self.assertNotIn('--execute', result.stdout)
        self.assertIn('preview', result.stdout)

    def test_double_click_menu_can_exit(self):
        result = subprocess.run(
            ['cmd.exe', '/c', 'start.cmd'], cwd=ROOT, input='0\n',
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding='utf-8', timeout=20,
        )
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('本地待处理', result.stdout)
        self.assertIn('查看历史待回复草稿（部分需复核）', result.stdout)


if __name__ == '__main__':
    unittest.main(verbosity=2)
