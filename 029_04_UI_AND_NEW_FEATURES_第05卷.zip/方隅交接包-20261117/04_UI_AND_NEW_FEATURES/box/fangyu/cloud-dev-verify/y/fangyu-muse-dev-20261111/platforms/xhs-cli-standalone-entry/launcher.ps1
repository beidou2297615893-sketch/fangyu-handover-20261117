﻿param(
    [ValidateSet('menu', 'status', 'preview', 'plan', 'ai-plan')]
    [string]$Action = 'menu'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$python = Join-Path $projectRoot 'work\vendor\cli-runtime\Scripts\python.exe'
$cli = Join-Path $PSScriptRoot 'standalone_cli.py'
$sentReport = Join-Path $projectRoot 'outputs\古北已回复语气\已受理客户原话与回复.txt'
$pendingReport = Join-Path $projectRoot 'outputs\方隅公寓待回复预览\待回复客户原话与新版回复.txt'
$pendingBatch = Join-Path $projectRoot 'work\xhs-gubei-pending-refresh\pending-batch.json'
$manifest = Join-Path $projectRoot 'work\xhs-gubei-pending-refresh\source-manifest.json'
$sessionHome = Join-Path $projectRoot 'work\xhs-standalone-session\cli-login-20261028-165417'
$senderUid = '5aa9b337e8ac2b4ab2d21957'
$aiRoot = Join-Path $projectRoot 'work\xhs-ai-standalone'
$aiInput = Join-Path $projectRoot 'work\xhs-ai-input-adapter\work\pending15-pipeline-v2.json'
$aiLedger = Join-Path $projectRoot 'work\shared-acquisition-ledger\shared.sqlite3'
$aiOutput = Join-Path $aiRoot 'work\pending15-run-v1'
$aiAnalysis = Join-Path $aiOutput 'analysis\analysis.json'

function Show-Status {
    if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw '未找到本机 Python 运行环境' }
    if (-not (Test-Path -LiteralPath $cli -PathType Leaf)) { throw '未找到小红书命令行入口' }
    $statusArgs = @('-X', 'utf8', $cli, '--project-root', $projectRoot)
    if (Test-Path -LiteralPath $aiAnalysis -PathType Leaf) { $statusArgs += @('--analysis-report', $aiAnalysis) }
    $statusArgs += 'status'
    $old = & $python @statusArgs
    if ($LASTEXITCODE -ne 0) { throw '无法读取本地账本状态' }
    $oldStatus = $old | ConvertFrom-Json
    if ($null -ne $oldStatus.AI待核) {
        Write-Host ("全部客户：{0}；平台已受理：{1}；结果不明：{2}；本地待处理：{3}，其中 AI 标记待核：{4}" -f $oldStatus.客户数, $oldStatus.已受理, $oldStatus.结果不明, $oldStatus.待处理, $oldStatus.AI待核)
    } else {
        Write-Host ("全部客户：{0}；平台已受理：{1}；结果不明：{2}；本地待处理：{3}；AI复核结果未加载" -f $oldStatus.客户数, $oldStatus.已受理, $oldStatus.结果不明, $oldStatus.待处理)
    }
}

function Show-SentReport {
    if (-not (Test-Path -LiteralPath $sentReport -PathType Leaf)) { throw '未找到已受理回复记录' }
    Get-Content -LiteralPath $sentReport -Encoding UTF8
}

function Show-PendingReport {
    if (-not (Test-Path -LiteralPath $pendingReport -PathType Leaf)) { throw '未找到待回复预览' }
    Get-Content -LiteralPath $pendingReport -Encoding UTF8
}

function Get-SendArguments {
    return @('-X', 'utf8', $cli, '--project-root', $projectRoot,
        '--batch', $pendingBatch, '--source-manifest', $manifest,
        '--session-home', $sessionHome, '--sender-uid', $senderUid,
        '--interval', '1', 'preview')
}

function Start-Sending {
    if (-not (Test-Path -LiteralPath $pendingBatch -PathType Leaf)) { throw '未找到新版批次' }
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw '未找到新版来源清单' }
    if (-not (Test-Path -LiteralPath $sessionHome -PathType Container)) { throw '未找到蕾姆的登录目录' }
    $sendArgs = Get-SendArguments
    & $python @sendArgs
    if ($LASTEXITCODE -ne 0) { Write-Host '发送已停止，请查看上方状态。' }
}

function Get-AiArguments {
    return @('-X', 'utf8', (Join-Path $aiRoot 'one_click.py'),
        '--input', $aiInput, '--output', $aiOutput, '--ledger', $aiLedger,
        '--sender-uid', $senderUid, '--account', (Join-Path $aiRoot 'account-leimu.json'),
        '--style', (Join-Path $aiRoot 'style-leimu.json'), '--project-root', $projectRoot,
        '--session-home', $sessionHome, '--provider', 'codex', '--interval', '1', '--execute')
}

function Start-AiSending {
    if (-not (Test-Path -LiteralPath $aiInput -PathType Leaf)) { throw '未找到AI分析所需的客户资料' }
    if (-not (Test-Path -LiteralPath $sessionHome -PathType Container)) { throw '未找到蕾姆的登录目录' }
    Write-Host '将使用本机已登录的官方 Codex 分析客户并发送符合条件的回复。'
    Write-Host 'AI 和发送链路尚未通过真实端到端验证；失败或回执不明会停止。'
    $aiArgs = Get-AiArguments
    & $python @aiArgs
    if ($LASTEXITCODE -ne 0) { Write-Host 'AI分析或发送已停止，请查看上方状态。' }
}

if ($Action -eq 'status') { Show-Status; exit 0 }
if ($Action -eq 'preview') { Show-PendingReport; exit 0 }
if ($Action -eq 'plan') {
    Get-SendArguments | ConvertTo-Json -Compress
    exit 0
}
if ($Action -eq 'ai-plan') { Get-AiArguments | ConvertTo-Json -Compress; exit 0 }

Write-Host '小红书独立命令行 - 当前账号：蕾姆'
Write-Host '平台受理不等于页面已核实显示。'
Show-Status
do {
    Write-Host ''
    Write-Host '1 查看本地进度'
    Write-Host '2 查看新版待回复草稿'
    Write-Host '3 查看历史待回复草稿（部分需复核）'
    Write-Host '4 查看已受理的原话与回复'
    Write-Host '5 Codex分析并发送剩余客户（使用本机已登录账号）'
    Write-Host '0 退出'
    $choice = Read-Host '请输入数字'
    if ($null -eq $choice) { break }
    $choice = $choice.Trim()
    switch ($choice) {
        '1' { Show-Status }
        '2' { Show-PendingReport }
        '3' { Show-PendingReport }
        '4' { Show-SentReport }
        '5' { Start-AiSending }
        '0' { break }
        default { Write-Host '请输入 0、1、2、3、4 或 5。' }
    }
} while ($choice -ne '0')
