"""Scoped read-only failure facts, no credentials or comment bodies."""
from pathlib import Path
import sqlite3,json,hashlib,datetime
T=Path(__file__).resolve().parent;N=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/ui-native-r57')
b=json.loads((N/'state/production-workspace.json').read_text('utf-8-sig'))
tenant='cloud-'+hashlib.sha256((b['environment_id']+'\n'+b['company_id']).encode()).hexdigest()[:24]
con=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON')
def rows(entity):return [json.loads(r[0]) for r in con.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(entity,tenant))]
tasks=sorted([r for r in rows('tasks') if r.get('cloud_owner')==b['owner']],key=lambda r:r.get('created_at',''),reverse=True)
account_ids={r.get('account_id') for r in tasks[:2]}
accounts=[{k:r.get(k) for k in ('id','platform','status','risk_state','connection_state','platform_login_confirmed')} for r in rows('accounts') if r['id'] in account_ids]
entities=['workbench_collection_diagnostic_v1','workbench_collection_run_v1','workbench_collection_page_analysis_v1','ai_jobs']
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'access':'read_only','accounts':accounts,'tasks':[]}
for task in tasks[:2]:
 value={k:task.get(k) for k in ('id','status','created_at','updated_at','pause_reason','target_count','daily_limit','accumulated','sequence_status','exhausted','last_error','error_code','last_message','sequence_message')}
 value['lastResult']={k:(task.get('last_result') or {}).get(k) for k in ('status','code','message','error')}
 summary=(task.get('last_result') or {}).get('summary') or {}
 value['summary']={k:summary.get(k) for k in ('run_id','status','stop_reason','error','error_code','read','filtered','imported','duplicates','can_continue','exhausted','platform_error','remaining') if k in summary}
 value['records']={}
 for entity in entities:
  for row in rows(entity):
   if row.get('id')==task['id'] and row.get('owner',b['owner'])==b['owner']:
    value['records'][entity]={k:row[k] for k in ('state','status','code','exception_kind','connection_state','platform_login_confirmed','binding_verified','updated_at','stage','pages','units','counts','stop_reason','pending','source_module','source_line','call_chain','error_type','provider','model') if k in row}
    if entity=='workbench_collection_diagnostic_v1':value['diagnosticKeys']=list(row)
    if entity=='workbench_collection_page_analysis_v1':value['records'][entity]['pendingLeadCount']=len(row.get('lead_ids',[]))
 report['tasks'].append(value)
con.close();(T/'DIAGNOSTIC.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report,ensure_ascii=False))

