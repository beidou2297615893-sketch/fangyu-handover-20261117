from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import socket
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import account_switch as candidate

HERE = Path(__file__).resolve().parent


class FakeClient:
    def __init__(self, uid='account-A', changes=None, error_at=None):
        self.uid, self.changes, self.error_at = uid, changes or {}, error_at
        self.calls = []
        self.identities = 0
        self.cookies = {'a1':'SYNTHETIC-DO-NOT-LOG','web_session':'SYNTHETIC-SESSION-DO-NOT-LOG'}
        self.last_failure_detail = None

    def get_self_info(self):
        self.identities += 1
        self.calls.append('identity')
        return self.changes.get(self.identities, {'user_id': self.uid, 'guest': False, 'nickname': '合成账号'})

    def search_notes(self, **kwargs):
        self.calls.append('search')
        return {'items': [{'id': 'note-1', 'xsec_token': 'DO-NOT-LOG-ACCESS-TOKEN', 'note_card': {'title': '合成租房'}}]}

    def get_comments(self, note_id, **kwargs):
        self.calls.append('comments')
        if self.error_at == 'comments':
            raise TimeoutError('COOKIE-MUST-NOT-LOG')
        return {'comments': [{'id': 'comment-1', 'content': '合成求租原文', 'user_info': {'user_id': 'customer-1'}}], 'has_more': False}


@contextmanager
def database(path):
    db=sqlite3.connect(path)
    try:
        yield db
        db.commit()
    finally:
        db.close()


def create_ledger(path):
    with database(path) as db:
        db.executescript('''
        CREATE TABLE leads(platform TEXT NOT NULL,customer TEXT NOT NULL,comment TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,PRIMARY KEY(platform,customer,comment),UNIQUE(platform,comment));
        CREATE TABLE reservations(token TEXT PRIMARY KEY,platform TEXT,customer TEXT,comment TEXT,status TEXT);
        CREATE TABLE identity_aliases(platform TEXT,alias TEXT,canonical TEXT,PRIMARY KEY(platform,alias));
        CREATE TABLE historical_deliveries(platform TEXT,customer TEXT,delivery_state TEXT);
        CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT NOT NULL,FOREIGN KEY(token) REFERENCES reservations(token));
        ''')


class CandidateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=HERE / 'runtime')
        self.root = Path(self.tmp.name)
        self.ledger = self.root / 'shared.sqlite3'
        create_ledger(self.ledger)
        self.source = self.root / 'source.sqlite3'
        self.source.write_bytes(b'synthetic-read-only-source')
        self.map_uids = []
        self.socket_guard = patch.object(socket.socket, 'connect', side_effect=AssertionError('Network forbidden'))
        self.socket_guard.start()

    def tearDown(self):
        self.socket_guard.stop()
        self.tmp.cleanup()

    def run_one(self, batch='batch-1', client=None, **extra):
        def loader(path, uid):
            self.map_uids.append(uid)
            return {}
        return candidate.run_batch(workspace=self.root, batch_name=batch, client=client or FakeClient(),
            ledger=self.ledger, source_db=self.source, keyword='合成求租', search_page=1,
            task='离线验证任务', operator=None, identity_loader=loader, **extra)

    def leads(self):
        with database(self.ledger) as db:
            return db.execute('SELECT customer,comment,status FROM leads').fetchall()

    def audit(self, batch='batch-1'):
        return [json.loads(x) for x in (self.root / batch / 'account-audit.jsonl').read_text(encoding='utf8').splitlines()]

    def test_arbitrary_accounts_bind_and_register_same_uid(self):
        first = self.run_one(client=FakeClient('account-A'))
        second = self.run_one('batch-2', FakeClient('account-B'))
        self.assertEqual([first['account']['uid'], second['account']['uid']], ['account-A', 'account-B'])
        self.assertEqual(self.map_uids, ['account-A', 'account-B'])
        self.assertEqual(first['result']['inserted'], 1)
        self.assertEqual(second['result']['inserted'], 0)
        self.assertEqual(len(self.leads()), 1)
        self.assertEqual(self.audit()[-1]['account']['uid'], 'account-A')
        self.assertEqual(self.audit('batch-2')[-1]['account']['uid'], 'account-B')

    def test_guest_or_missing_guest_rejected_before_source_or_search(self):
        for i, info in enumerate(({'user_id':'account-A','guest':True}, {'user_id':'account-A'}, {'guest':False}, {'user_id':'account-A','guest':'false'})):
            client = FakeClient(changes={1:info})
            with self.assertRaises(candidate.Refused): self.run_one('invalid-'+str(i), client)
            self.assertEqual(client.calls, ['identity'])
        self.assertEqual(self.map_uids, [])
        self.assertEqual(self.leads(), [])

    def test_identity_payload_conflicts_and_invalid_flags_rejected(self):
        invalid = [None, {'guest':False,'user_id':'a','uid':'b'},
            {'guest':False,'user_id':'a','basic_info':{'guest':True,'user_id':'a'}},
            {'guest':0,'user_id':'a'}, {'guest':False,'user_id':' a'},
            {'guest':False,'user_id':123}, {'guest':False,'user_id':'a','uid':123},
            {'guest':False,'user_id':'a','user_info':'unexpected'}]
        for info in invalid:
            with self.subTest(info=info), self.assertRaises(candidate.Refused): candidate.identify(info)

    def test_nested_identity_supported_without_arbitrary_recursive_uid(self):
        actual = candidate.identify({'guest':False,'basic_info':{'user_id':'account-C','nickname':'合成丙'},'unrelated':{'uid':'ignored'}})
        self.assertEqual(actual['uid'], 'account-C')
        self.assertEqual(actual['nickname'], '合成丙')

    def test_switch_before_search_stops_with_no_search(self):
        client=FakeClient()
        def mutate(path,uid):
            client.cookies['web_session']='CHANGED-DO-NOT-LOG'
            return {}
        original=self.run_one
        def loader_run():
            return candidate.run_batch(workspace=self.root,batch_name='batch-1',client=client,ledger=self.ledger,
                source_db=self.source,keyword='合成求租',search_page=1,task='test',identity_loader=mutate)
        with self.assertRaises(candidate.Refused): loader_run()
        self.assertNotIn('search',client.calls)
        self.assertEqual(self.leads(), [])
        self.assertEqual(self.audit()[-1]['status'], 'stopped_before_registration')

    def test_switch_before_registration_preserves_collection_and_no_insert(self):
        client=FakeClient(changes={2:{'user_id':'account-B','guest':False}})
        with self.assertRaises(candidate.Refused): self.run_one(client=client)
        self.assertTrue((self.root/'batch-1'/'collection.json').exists())
        self.assertEqual(self.leads(), [])
        self.assertEqual(self.audit()[-1]['status'],'stopped_before_registration')

    def test_guest_before_registration_stops(self):
        client=FakeClient(changes={2:{'user_id':'account-A','guest':True}})
        with self.assertRaises(candidate.Refused): self.run_one(client=client)
        self.assertEqual(self.leads(), [])

    def test_known_notes_are_global_and_attempts_account_bound(self):
        result=self.run_one(known_notes={'note-1'})
        self.assertEqual(result['result']['inserted'],0)
        self.assertEqual(json.loads((self.root/'batch-1'/'attempted-notes.json').read_text()),[])

    def test_unknown_prior_send_blocks_another_account(self):
        canonical='xhs_new_'+hashlib.sha256(b'xiaohongshu:customer-1').hexdigest()
        with database(self.ledger) as db:
            db.execute("INSERT INTO reservations VALUES('attempt','xiaohongshu',?,'old-comment','unknown')",(canonical,))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)',('attempt',json.dumps({'plan':{'sender_uid':'account-Z','customer_uid':'customer-1','canonical_customer':canonical}})))
        result=self.run_one(client=FakeClient('account-B'))
        self.assertEqual(result['result']['blocked_customers'],1)
        self.assertEqual(self.leads(),[])
        self.assertEqual(json.loads((self.root/'batch-1'/'new-ai-input.json').read_text()), [])

    def test_ledger_failure_rolls_back_and_audit_says_unknown(self):
        with database(self.ledger) as db:
            db.execute("CREATE TRIGGER fail_insert BEFORE INSERT ON leads BEGIN SELECT RAISE(ABORT, 'synthetic fault'); END")
        with self.assertRaises(candidate.Refused): self.run_one()
        self.assertEqual(self.leads(),[])
        self.assertEqual(self.audit()[-1]['status'],'registration_outcome_unknown_check_ledger')
        self.assertTrue((self.root/'batch-1'/'collection.json').exists())

    def test_duplicate_batch_not_retried(self):
        self.run_one()
        before=(self.root/'batch-1'/'account-audit.jsonl').read_bytes()
        client=FakeClient()
        with self.assertRaises(candidate.Refused): self.run_one(client=client)
        self.assertEqual(client.calls,[])
        self.assertEqual((self.root/'batch-1'/'account-audit.jsonl').read_bytes(),before)

    def test_report_and_account_metadata_are_durable_without_credentials(self):
        self.run_one()
        info=json.loads((self.root/'batch-1'/'collection.json').read_text(encoding='utf8'))['collection_account']
        self.assertEqual(info['uid'],'account-A')
        audit=self.audit()[-1]
        self.assertEqual(audit['operator'],'unknown')
        self.assertEqual(audit['keyword'],'合成求租')
        self.assertEqual(audit['task'],'离线验证任务')
        self.assertTrue(audit['at'])
        self.assertEqual(audit['search_page'],1)
        all_text=''.join(p.read_text(encoding='utf8') for p in (self.root/'batch-1').iterdir() if p.is_file())
        self.assertNotIn('DO-NOT-LOG-ACCESS-TOKEN',all_text)
        self.assertNotIn('COOKIE-MUST-NOT-LOG',all_text)

    def test_read_exception_is_fixed_category_and_preserves_attempt(self):
        with self.assertRaises(candidate.Refused): self.run_one(client=FakeClient(error_at='comments'))
        self.assertEqual(self.audit()[-1]['status'],'stopped_before_registration')
        self.assertEqual(json.loads((self.root/'batch-1'/'attempted-notes.json').read_text())[0]['note_id'],'note-1')
        self.assertNotIn('COOKIE-MUST-NOT-LOG',(self.root/'batch-1'/'account-audit.jsonl').read_text())

    def test_workspace_and_paths_reject_escape_before_identity(self):
        client=FakeClient()
        for name in ('../escape','a/b','..','a\\b'):
            with self.assertRaises(candidate.Refused): self.run_one(batch=name,client=client)
        outside=HERE.parent/'shared-acquisition-ledger'/'shared.sqlite3'
        with self.assertRaises(candidate.Refused):
            candidate.run_batch(workspace=self.root,batch_name='escape',client=client,ledger=outside,
                source_db=self.source,keyword='合成',search_page=1,task='test')
        self.assertEqual(client.calls,[])

    def test_lock_blocks_concurrent_writers_without_identity(self):
        lock=self.root/'.account-switch.lock'
        lock.mkdir()
        client=FakeClient()
        with self.assertRaises(candidate.Refused): self.run_one(client=client)
        self.assertEqual(client.calls,[])
        self.assertTrue(lock.exists())

    def test_ready_contains_only_verified_inserted_records(self):
        self.run_one()
        self.run_one('batch-2',FakeClient('account-B'))
        ready=json.loads((self.root/'batch-2'/'registered-ready.json').read_text())
        self.assertEqual(ready['input'],'new-ai-input.json')
        self.assertEqual(json.loads((self.root/'batch-2'/'new-ai-input.json').read_text()),[])

    def test_cli_preview_does_not_create_client_or_change_environment(self):
        import collect_once
        import os
        before=dict(os.environ)
        code=collect_once.main(['--workspace',str(self.root),'--batch','batch-0020','--keyword','合成','--search-page','5'],
            client_factory=lambda *args: self.fail('Preview must not create client'))
        self.assertEqual(code,0)
        self.assertEqual(before,dict(os.environ))
        self.assertFalse((self.root/'batch-0020').exists())

    def test_unproven_collection_and_failed_attempt_are_not_completed(self):
        import collect_once
        history=self.root/'history';history.mkdir()
        (history/'attempted-notes.json').write_text(json.dumps([{'note_id':'already-tried','account_uid':'account-Z'}]))
        (history/'collection.json').write_text(json.dumps({'schema':'xhs-collected-ai-input-v1','customers':[{'note_id':'already-collected'}]}))
        # Final output alone does not prove that pagination was exhausted.
        self.assertEqual(collect_once.historical_notes([history]),set())

    def test_cli_requires_independent_session_inside_allowed_area(self):
        import collect_once
        with self.assertRaises(candidate.Refused): collect_once.load_cookies(HERE)

    def test_only_batch_start_and_pre_registration_call_live_identity(self):
        client=FakeClient()
        self.run_one(client=client)
        self.assertEqual(client.calls,['identity','search','comments','identity'])

    def test_cookie_mutation_during_search_stops_before_comments(self):
        client=FakeClient()
        original=client.search_notes
        def search(**kwargs):
            value=original(**kwargs)
            client.cookies['web_session']='COOKIE-CHANGED-DO-NOT-LOG'
            return value
        client.search_notes=search
        with self.assertRaises(candidate.Refused): self.run_one(client=client)
        self.assertNotIn('comments',client.calls)
        self.assertEqual(self.audit()[-1]['failure']['category'],'session_changed_no_retry')

    def test_external_session_file_guard_stops_without_request(self):
        client=FakeClient()
        count=[0]
        def check():
            count[0]+=1
            if count[0]>1: raise candidate.Refused('independent_session_file_changed')
        client._independent_session_guard=check
        with self.assertRaises(candidate.Refused): self.run_one(client=client)
        self.assertEqual(client.calls,['identity'])

    def test_unregistered_comment_is_not_skipped_even_if_passed_as_known(self):
        result=self.run_one(known_comments={'comment-1'})
        self.assertEqual(result['result']['inserted'],1)
        self.assertEqual(json.loads((self.root/'batch-1'/'dedup-summary.json').read_text())['duplicate_comments'],0)

    def test_same_batch_conflicting_comment_text_is_preserved_for_review(self):
        client=FakeClient()
        calls=[0]
        original=client.get_comments
        def comments(note_id,**kwargs):
            calls[0]+=1
            value=original(note_id,**kwargs)
            value['has_more']=calls[0]==1
            value['cursor']='next' if calls[0]==1 else ''
            if calls[0]==2: value['comments'][0]['content']='同ID后来发生变化'
            return value
        client.get_comments=comments
        result=self.run_one(client=client)
        self.assertEqual(result['result']['inserted'],0)
        self.assertEqual(json.loads((self.root/'batch-1'/'dedup-summary.json').read_text())['duplicate_comments'],1)
        data=json.loads((self.root/'batch-1'/'collection.json').read_text(encoding='utf8'))
        self.assertTrue(data['conflicts'] or data['pending'])

    def test_invalid_first_duplicate_does_not_swallow_later_valid_comment(self):
        client=FakeClient()
        original=client.get_comments
        def comments(note_id,**kwargs):
            value=original(note_id,**kwargs)
            value['comments'].insert(0,{'id':'comment-1','content':'','user_info':{}})
            value['comments'][1]['ip_location']='上海'
            return value
        client.get_comments=comments
        result=self.run_one(client=client)
        self.assertEqual(result['result']['inserted'],1)
        data=json.loads((self.root/'batch-1'/'new-ai-input.json').read_text(encoding='utf8'))
        self.assertEqual(data[0]['ip_location'],'上海')

    def test_same_comment_id_conflicting_users_is_not_registered(self):
        client=FakeClient()
        original=client.get_comments
        def comments(note_id,**kwargs):
            value=original(note_id,**kwargs)
            value['comments'][0]['ip_location']='上海'
            value['comments'].append({'id':'comment-1','content':'合成求租原文',
                                      'user_info':{'user_id':'customer-other'},'ip_location':'江苏'})
            return value
        client.get_comments=comments
        result=self.run_one(client=client)
        self.assertEqual(result['result']['inserted'],0)
        data=json.loads((self.root/'batch-1'/'collection.json').read_text(encoding='utf8'))
        self.assertTrue(data['conflicts'] or data['pending'])

    def test_same_comment_id_conflicting_ip_is_not_registered_or_misattributed(self):
        client=FakeClient()
        original=client.get_comments
        def comments(note_id,**kwargs):
            value=original(note_id,**kwargs)
            value['comments'][0]['ip_location']='上海'
            value['comments'].append({**value['comments'][0], 'ip_location':'江苏'})
            return value
        client.get_comments=comments
        result=self.run_one(client=client)
        self.assertEqual(result['result']['inserted'],0)
        data=json.loads((self.root/'batch-1'/'collection.json').read_text(encoding='utf8'))
        self.assertTrue(data['conflicts'] or data['pending'])

    def test_conflicting_variants_of_registered_comment_remain_auditable(self):
        self.run_one()
        client=FakeClient('account-B')
        original=client.get_comments
        def comments(note_id,**kwargs):
            value=original(note_id,**kwargs)
            value['comments'][0]['ip_location']='上海'
            value['comments'].append({**value['comments'][0], 'ip_location':'江苏'})
            return value
        client.get_comments=comments
        result=self.run_one('batch-2',client)
        self.assertEqual(result['result']['inserted'],0)
        data=json.loads((self.root/'batch-2'/'collection.json').read_text(encoding='utf8'))
        self.assertTrue(data['conflicts'] or data['pending'])

    def test_sanitized_failure_461_or_expired_and_no_raw_values(self):
        for i,detail in enumerate(({'http_status':461,'error_type':'HTTPError','stage':'search','endpoint':'search_notes','request_started':True},
            {'api_code':-100,'error_type':'SessionExpiredError','stage':'identity','endpoint':'identity','request_started':True})):
            client=FakeClient(error_at='comments')
            client.last_failure_detail={**detail,'raw_cookie':'COOKIE-MUST-NOT-LOG','msg':'SECRET-DO-NOT-LOG'}
            with self.assertRaises(candidate.Refused): self.run_one('failure-'+str(i),client)
            audit=self.audit('failure-'+str(i))[-1]
            self.assertEqual(audit['failure']['platform'],detail)
            self.assertFalse(audit['failure']['retry_allowed'])
            self.assertNotIn('SECRET-DO-NOT-LOG',json.dumps(audit))

    def test_history_reads_comments_from_unregistered_json(self):
        import collect_once
        history=self.root/'old';history.mkdir()
        (history/'partial.json').write_text(json.dumps({'customers':[{'note_id':'n','comment_id':'c-history'}]}))
        notes,comments=collect_once.historical_ids([history])
        self.assertEqual((notes,comments),(set(),set()))

    def test_partial_and_failed_attempts_have_recovery_records_not_skip_flags(self):
        import collect_once
        history=self.root/'failed';history.mkdir()
        (history/'partial.json').write_text(json.dumps({'customers':[{'note_id':'n-partial','comment_id':'c-unregistered'}]}))
        (history/'attempted-notes.json').write_text(json.dumps([{'note_id':'n-failed'}]))
        (history/'attempt-events.jsonl').write_text(json.dumps({'note_id':'n-event'})+'\n')
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['completed_notes'],[])
        self.assertEqual(index['known_comments'],[])
        self.assertEqual(set(index['incomplete_notes']),{'n-partial','n-failed','n-event'})
        self.assertIn('c-unregistered',index['unregistered_comments'])
        self.assertTrue(index['recovery'])

    def test_final_completed_notes_preserved_but_unregistered_data_queued(self):
        import collect_once
        history=self.root/'final';history.mkdir()
        (history/'collection.json').write_text(json.dumps({'schema':'xhs-collected-ai-input-v1',
            'customers':[{'note_id':'n-complete','comment_id':'c-pending'}],'pending':[]}))
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['completed_notes'],[])
        self.assertEqual(index['known_comments'],[])
        self.assertEqual(index['unregistered_comments'],['c-pending'])
        self.assertEqual(index['recovery'][0]['kind'],'final_collection_requires_local_registration_review')
        self.assertEqual(self.leads(),[])

    def test_ledger_registered_comments_still_skipped_across_accounts(self):
        import collect_once
        history=self.root/'history';history.mkdir()
        (history/'partial.json').write_text(json.dumps({'customers':[{'note_id':'n-partial','comment_id':'c-registered'}]}))
        with database(self.ledger) as db:
            db.execute("INSERT INTO leads VALUES('xiaohongshu','customer','c-registered','unverified','old')")
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['known_comments'],['c-registered'])
        self.assertEqual(index['unregistered_comments'],[])
        self.assertEqual(index['completed_notes'],[])
        self.assertEqual(index['incomplete_notes'],['n-partial'])

    def test_final_batch_pending_note_not_marked_completed(self):
        import collect_once
        history=self.root/'mixed';history.mkdir()
        (history/'collection.json').write_text(json.dumps({'schema':'xhs-collected-ai-input-v1',
            'customers':[{'note_id':'n-complete','comment_id':'c1'}],
            'pending':[{'note_id':'n-incomplete','reason':'local_comment_url_fragment_before_request'}]}))
        (history/'attempted-notes.json').write_text(json.dumps([{'note_id':'n-complete'},{'note_id':'n-incomplete'},{'note_id':'unproven-empty'}]))
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['completed_notes'],[])
        self.assertEqual(set(index['incomplete_notes']),{'n-complete','n-incomplete','unproven-empty'})

    def test_explicit_exhaustion_and_ledger_proof_permits_note_skip(self):
        import collect_once
        history=self.root/'complete'; history.mkdir()
        (history/'collection.json').write_text(json.dumps({'customers':[{'note_id':'n','comment_id':'c'}],'pending':[]}))
        (history/'completed-notes.json').write_text(json.dumps({'exhausted_note_ids':['n']}))
        with database(self.ledger) as db:
            db.execute("INSERT INTO leads VALUES('xiaohongshu','customer','c','unverified','old')")
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['completed_notes'],['n'])
        self.assertEqual(index['known_comments'],['c'])

    def test_unregistered_data_blocks_skipping_even_with_exhaustion_proof(self):
        import collect_once
        history=self.root/'unregistered'; history.mkdir()
        (history/'collection.json').write_text(json.dumps({'customers':[{'note_id':'n','comment_id':'c'}],'pending':[]}))
        (history/'completed-notes.json').write_text(json.dumps({'exhausted_note_ids':['n']}))
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['completed_notes'],[])
        self.assertEqual(index['unregistered_comments'],['c'])

    def test_successful_batch_records_exhaustion_without_credentials(self):
        self.run_one()
        proof=json.loads((self.root/'batch-1'/'completed-notes.json').read_text())
        self.assertEqual(proof['exhausted_note_ids'],['note-1'])
        self.assertNotIn('DO-NOT-LOG-ACCESS-TOKEN',json.dumps(proof))

    def test_truncated_batch_does_not_claim_note_exhausted(self):
        client=FakeClient()
        original=client.get_comments
        def more(note_id,**kwargs):
            return {**original(note_id,**kwargs),'has_more':True,'cursor':'next'}
        client.get_comments=more
        self.run_one(client=client,max_pages=1)
        proof=json.loads((self.root/'batch-1'/'completed-notes.json').read_text())
        self.assertEqual(proof['exhausted_note_ids'],[])

    def test_new_exhaustion_covers_known_registered_partial_but_not_changed_history(self):
        import collect_once
        old=self.root/'old-batch'; old.mkdir()
        partial=old/'partial.json'
        partial.write_text(json.dumps({'customers':[{'note_id':'note-1','comment_id':'comment-1'}]}))
        with database(self.ledger) as db:
            db.execute("INSERT INTO leads VALUES('xiaohongshu','customer','comment-1','unverified','old')")
        before=collect_once.history_index([old],ledger=self.ledger)
        self.run_one(history_snapshot=before)
        after=collect_once.history_index([old,self.root/'batch-1'],ledger=self.ledger)
        self.assertEqual(after['completed_notes'],['note-1'])
        partial.write_text(json.dumps({'customers':[{'note_id':'note-1','comment_id':'another-unknown'}]}))
        changed=collect_once.history_index([old,self.root/'batch-1'],ledger=self.ledger)
        self.assertEqual(changed['completed_notes'],[])
        self.assertIn('another-unknown',changed['unregistered_comments'])

    def test_exhaustion_does_not_hide_unregistered_prior_comment(self):
        import collect_once
        old=self.root/'old-batch'; old.mkdir()
        (old/'partial.json').write_text(json.dumps({'customers':[{'note_id':'note-1','comment_id':'prior-only'}]}))
        before=collect_once.history_index([old],ledger=self.ledger)
        self.run_one(history_snapshot=before)
        after=collect_once.history_index([old,self.root/'batch-1'],ledger=self.ledger)
        self.assertEqual(after['completed_notes'],[])
        self.assertEqual(after['unregistered_comments'],['prior-only'])

    def test_exhaustion_does_not_cover_new_unobserved_incomplete_history(self):
        import collect_once
        old=self.root/'old-batch'; old.mkdir()
        (old/'attempted-notes.json').write_text(json.dumps([{'note_id':'note-1'}]))
        before=collect_once.history_index([old],ledger=self.ledger)
        self.run_one(history_snapshot=before)
        later=self.root/'later'; later.mkdir()
        (later/'attempted-notes.json').write_text(json.dumps([{'note_id':'note-1'}]))
        after=collect_once.history_index([old,later,self.root/'batch-1'],ledger=self.ledger)
        self.assertEqual(after['completed_notes'],[])

    def test_partial_pending_remains_visible_after_later_exhaustion(self):
        import collect_once
        old=self.root/'old-batch'; old.mkdir()
        (old/'partial.json').write_text(json.dumps({'customers':[],
            'pending':[{'note_id':'note-1','reason':'local_identity_conflict'}]}))
        before=collect_once.history_index([old],ledger=self.ledger)
        self.run_one(history_snapshot=before)
        after=collect_once.history_index([old,self.root/'batch-1'],ledger=self.ledger)
        self.assertEqual(after['completed_notes'],[])
        self.assertIn('note-1',after['incomplete_notes'])

    def test_client_creation_failure_has_durable_sanitized_attempt(self):
        import collect_once
        argv=['--workspace',str(self.root),'--batch','client-fail','--keyword','合成求租',
              '--search-page','5','--session-home','unused','--ledger',str(self.ledger),
              '--source-db',str(self.source),'--execute']
        with patch.object(collect_once,'history_index',return_value={'completed_notes':[],
                'known_comments':[],'note_sources':{}}):
            with self.assertRaises(RuntimeError):
                collect_once.main(argv,client_factory=lambda *_: (_ for _ in ()).throw(RuntimeError('SECRET-COOKIE')))
        events=[json.loads(line) for line in (self.root/'attempt-client-fail.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(events[0]['status'],'started')
        self.assertEqual(events[-1]['status'],'stopped_before_batch')
        self.assertEqual(events[-1]['phase'],'create_client')
        self.assertEqual(events[-1]['keyword'],'合成求租')
        self.assertEqual(events[-1]['search_page'],5)
        self.assertNotIn('SECRET-COOKIE',json.dumps(events))

    def test_lock_failure_is_durable_and_does_not_search(self):
        import collect_once
        argv=['--workspace',str(self.root),'--batch','locked','--keyword','合成求租',
              '--search-page','5','--session-home','unused','--ledger',str(self.ledger),
              '--source-db',str(self.source),'--execute']
        client=FakeClient()
        client.close=lambda: None
        with patch.object(collect_once,'history_index',return_value={'completed_notes':[],
                'known_comments':[],'note_sources':{}}), patch.object(candidate,'run_batch',
                side_effect=candidate.Refused('collection_lock_busy_no_retry')):
            with self.assertRaises(candidate.Refused): collect_once.main(argv,client_factory=lambda *_: client)
        events=[json.loads(line) for line in (self.root/'attempt-locked.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(events[-1]['status'],'stopped_before_batch')
        self.assertEqual(events[-1]['phase'],'run_batch')
        self.assertEqual(client.calls,[])

    def test_real_offline_batch_has_attempt_and_registration_receipts(self):
        import collect_once
        argv=['--workspace',str(self.root),'--batch','success','--keyword','合成求租',
              '--search-page','5','--session-home','unused','--ledger',str(self.ledger),
              '--source-db',str(self.source),'--execute']
        client=FakeClient(); client.close=lambda: None
        collector,_=candidate.dependencies()
        with patch.object(collect_once,'history_index',return_value={'completed_notes':[],
                'known_comments':[],'note_sources':{}}), patch.object(collector,'load_identity_map',return_value={}):
            self.assertEqual(collect_once.main(argv,client_factory=lambda *_: client),0)
        events=[json.loads(line) for line in (self.root/'attempt-success.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(events[-1]['status'],'registered')
        self.assertEqual(events[-1]['account'],'account-A')
        self.assertEqual(events[-1]['inserted'],1)
        self.assertEqual(json.loads((self.root/'success'/'registered-ready.json').read_text())['inserted_comments'],1)

    def test_failed_registration_receipt_requires_ledger_review(self):
        import collect_once
        with database(self.ledger) as db:
            db.execute("CREATE TRIGGER fail_insert BEFORE INSERT ON leads BEGIN SELECT RAISE(ABORT, 'synthetic fault'); END")
        argv=['--workspace',str(self.root),'--batch','unknown','--keyword','合成求租',
              '--search-page','5','--session-home','unused','--ledger',str(self.ledger),
              '--source-db',str(self.source),'--execute']
        client=FakeClient(); client.close=lambda: None
        collector,_=candidate.dependencies()
        with patch.object(collect_once,'history_index',return_value={'completed_notes':[],
                'known_comments':[],'note_sources':{}}), patch.object(collector,'load_identity_map',return_value={}):
            with self.assertRaises(candidate.Refused): collect_once.main(argv,client_factory=lambda *_: client)
        events=[json.loads(line) for line in (self.root/'attempt-unknown.jsonl').read_text(encoding='utf8').splitlines()]
        self.assertEqual(events[-1]['status'],'stopped_review_batch_and_ledger')
        self.assertFalse(events[-1]['automatic_retry'])
        self.assertEqual(self.audit('unknown')[-1]['status'],'registration_outcome_unknown_check_ledger')

    def test_comment_time_and_ip_location_survive_collection_and_analysis_input(self):
        client=FakeClient()
        original=client.get_comments
        def comments(note_id,**kwargs):
            value=original(note_id,**kwargs)
            value['comments'][0].update({'ip_location':'上海','create_time':1793150000000})
            value['comments'].append({'id':'comment-2','content':'合成第二条',
                'user_info':{'user_id':'customer-1'},'ip_location':'江苏','create_time':1793150001000})
            return value
        client.get_comments=comments
        self.run_one(client=client)
        collection=json.loads((self.root/'batch-1'/'collection.json').read_text(encoding='utf8'))
        selected=json.loads((self.root/'batch-1'/'new-ai-input.json').read_text(encoding='utf8'))
        for row in (collection['customers'][0],selected[0]):
            self.assertEqual(row['ip_location'],'上海')
            self.assertEqual(row['region'],'上海')
            self.assertTrue(row['published_at'])
            self.assertEqual(row['other_comments'][0]['ip_location'],'江苏')
            self.assertTrue(row['other_comments'][0]['published_at'])
        partial=json.loads(next((self.root/'batch-1').glob('partial-*.json')).read_text(encoding='utf8'))
        self.assertEqual(partial['customers'][0]['ip_location'],'上海')

    def test_missing_ip_is_not_inferred_from_keyword_or_account(self):
        self.run_one()
        selected=json.loads((self.root/'batch-1'/'new-ai-input.json').read_text(encoding='utf8'))
        self.assertEqual(selected[0]['ip_location'],'')
        self.assertEqual(selected[0]['region'],'')

    def test_claimed_ready_without_ledger_does_not_mark_comment_registered(self):
        import collect_once
        history=self.root/'claimed';history.mkdir()
        (history/'collection.json').write_text(json.dumps({'schema':'xhs-collected-ai-input-v1','customers':[{'note_id':'n','comment_id':'c'}]}))
        (history/'registered-ready.json').write_text(json.dumps({'registered':True,'inserted_comments':1}))
        index=collect_once.history_index([history],ledger=self.ledger)
        self.assertEqual(index['known_comments'],[])
        self.assertEqual(index['unregistered_comments'],['c'])

    def test_actual_readclient_461_and_expired_persist_distinct_safe_diagnostics(self):
        import collect_once
        import httpx
        collector,_=candidate.dependencies()
        for i,(status,payload) in enumerate(((461,None),(200,{'success':False,'code':-100,'msg':'SECRET-DO-NOT-LOG'}))):
            def respond(request):
                return httpx.Response(status,request=request,json=payload)
            client=collector.ReadClient({'a1':'SYNTHETIC','web_session':'SYNTHETIC'},transport=httpx.MockTransport(respond),delay=0)
            try:
                collect_once.install_response_audit(client)
                with self.assertRaises(candidate.Refused): self.run_one('wire-'+str(i),client)
                failure=self.audit('wire-'+str(i))[-1]['failure']
                self.assertEqual(failure['platform']['http_status'],status)
                if i==1: self.assertEqual(failure['platform']['api_code'],-100)
                self.assertNotIn('SECRET-DO-NOT-LOG',json.dumps(failure))
            finally:
                client.close()

    def test_vendor_context_tokens_and_search_sessions_not_persisted(self):
        import collect_once
        import xhs_cli.client_mixins as mixins
        import xhs_cli.cookies as storage
        keys=('get_config_dir','cache_note_context','get_cached_note_context','invalidate_note_context','_save_search_session_cache')
        originals={k:getattr(mixins,k) for k in keys}
        storage_original=storage.get_config_dir
        try:
            collect_once.configure_runtime_cache(self.root/'cache')
            mixins.cache_note_context('note','sensitive-token','pc_search')
            mixins._save_search_session_cache(self.root/'cache'/'search-sessions.json')
            self.assertEqual(mixins.get_cached_note_context('note'),{})
            self.assertEqual(list((self.root/'cache').iterdir()),[])
            self.assertEqual(mixins.get_config_dir(),self.root/'cache')
        finally:
            for key,value in originals.items(): setattr(mixins,key,value)
            storage.get_config_dir=storage_original


if __name__=='__main__':
    (HERE/'runtime').mkdir(exist_ok=True)
    unittest.main()
