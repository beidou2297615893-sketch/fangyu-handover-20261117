"""Offline orchestration checks. Every external operation is injected."""
import json
from datetime import datetime, timedelta, timezone
from contextlib import closing, contextmanager
from dataclasses import replace
import hashlib
from pathlib import Path
import socket
import sqlite3
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import bulk_run as bulk


class FakeAdapter:
    def __init__(self):
        self.calls = []
        self.block = None
        self.visible = True
        self.states = {}
        self.identity_value = {'uid': 'sender', 'guest': False}
        self.post_attempts = 0

    def identity(self):
        self.calls.append('identity')
        return self.identity_value

    def state(self, row):
        self.calls.append(('state', row['comment_id']))
        return self.states.get(row['comment_id'], 'pending')

    def context(self, row, mapping):
        self.calls.append(('context', row['comment_id']))
        if self.block:
            raise self.block
        return {'token': 'SECRET-TOKEN', 'title': mapping['post_title']}

    def target(self, row, mapping, context):
        self.calls.append(('target', row['comment_id']))
        return None

    def submit(self, row):
        self.calls.append(('post', row['comment_id']))
        self.post_attempts += 1
        return 'receipt_received_unverified'

    def receipt(self, row):
        self.calls.append(('receipt', row['comment_id']))
        return 'reply-' + row['comment_id']

    def verify(self, row, context, receipt):
        self.calls.append(('verify', row['comment_id']))
        return self.visible

    def diagnostic(self, exc):
        return {'http_status': getattr(exc, 'status', None), 'retry_allowed': False}

    def close(self):
        self.calls.append('close')


class Tests(unittest.TestCase):
    def setUp(self):
        self.net = patch.object(socket.socket, 'connect', side_effect=AssertionError('network_forbidden'))
        self.net.start()
        self.tmp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.root = Path(self.tmp.name)
        self.home = self.root / 'session'
        self.home.mkdir()
        self.adapter = FakeAdapter()
        self.rows = [self.row('a'), self.row('b')]
        self.mapping = {r['comment_id']: self.meta(r) for r in self.rows}

    def tearDown(self):
        self.tmp.cleanup()
        self.net.stop()

    def row(self, value):
        return {'comment_id': value, 'customer_uid': 'uid-' + value, 'customer_id': 'customer-' + value,
                'note_id': 'note-' + value, 'attempt_id': 'attempt-' + value,
                'sequence': 1, 'text': 'Approved original text'}

    def meta(self, row):
        return {'post_title': '上海看房', 'published_at': '2026-10-29T00:00:00+00:00',
                'original_comment': '礼貌问房', 'customer_uid': row['customer_uid'],
                'canonical_customer': row['customer_id']}

    def run_bulk(self, execute=True, name='run', direct_id=False):
        return bulk.run(self.rows, self.mapping, sender_uid='sender', session_home=self.home,
                        run_dir=self.root / name, execute=execute, adapter_factory=lambda _: self.adapter,
                        today='2026-10-30', interval=0, direct_id=direct_id)

    def events(self, name='run'):
        return [json.loads(x) for x in (self.root / name / 'events.jsonl').read_text(encoding='utf8').splitlines()]

    def test_preview_creates_no_adapter_lock_files_or_network(self):
        with patch.object(self, 'adapter', None):
            report = self.run_bulk(execute=False)
        self.assertEqual(report['mode'], 'preview')
        self.assertFalse((self.root / 'run').exists())
        self.assertFalse((self.home / '.managed-use.lock').exists())

    def test_success_verifies_receipt_before_next_post_and_persists_states(self):
        report = self.run_bulk()
        calls = self.adapter.calls
        self.assertLess(calls.index(('verify', 'a')), calls.index(('post', 'b')))
        self.assertEqual(report['visible_verified'], 2)
        events = self.events()
        self.assertEqual(sum(e['event'] == 'accepted' for e in events), 2)
        self.assertEqual(sum(e['event'] == 'visible_verified' for e in events), 2)
        self.assertNotIn('SECRET-TOKEN', (self.root / 'run' / 'events.jsonl').read_text(encoding='utf8'))

    def test_unknown_readback_stops_without_second_submit_or_retry(self):
        self.adapter.visible = False
        report = self.run_bulk()
        self.assertEqual(report['status'], 'stopped_unknown')
        self.assertEqual([c for c in self.adapter.calls if isinstance(c, tuple) and c[0] == 'post'], [('post', 'a')])
        self.assertEqual(sum(e['event'] == 'unknown' for e in self.events()), 1)
        # Another invocation cannot reuse a directory and does no external work.
        calls = list(self.adapter.calls)
        with self.assertRaises(FileExistsError):
            self.run_bulk()
        self.assertEqual(calls, self.adapter.calls)

    def test_failure_statuses_and_session_fault_stop_all_following_calls(self):
        for status in (461, 471, 429, -100, None):
            with self.subTest(status=status):
                self.adapter = FakeAdapter()
                exc = RuntimeError('SECRET-COOKIE')
                exc.status = status
                self.adapter.block = exc
                name = 'stop-' + str(status)
                report = self.run_bulk(name=name)
                self.assertEqual(report['status'], 'stopped')
                self.assertNotIn(('context', 'b'), self.adapter.calls)
                self.assertNotIn(('post', 'a'), self.adapter.calls)
                self.assertNotIn('SECRET-COOKIE', (self.root / name / 'events.jsonl').read_text(encoding='utf8'))
                self.assertEqual(report['submit_calls'], 0)
                self.assertEqual(report['post_attempts'], 0)

    def test_cross_account_duplicate_or_unknown_customer_is_held(self):
        self.adapter.states['a'] = 'blocked'
        report = self.run_bulk()
        self.assertEqual(report['held'], 1)
        self.assertNotIn(('context', 'a'), self.adapter.calls)
        self.assertIn(('post', 'b'), self.adapter.calls)

    def test_ledger_reread_immediately_before_submit_holds_new_history(self):
        count = {'a': 0}
        def state(row):
            count[row['comment_id']] = count.get(row['comment_id'], 0) + 1
            return 'blocked' if row['comment_id'] == 'a' and count['a'] == 2 else 'pending'
        self.adapter.state = state
        self.run_bulk()
        self.assertNotIn(('post', 'a'), self.adapter.calls)
        self.assertIn(('post', 'b'), self.adapter.calls)

    def test_old_or_rented_hold_without_target_requests(self):
        self.mapping['a']['post_title'] = '已出租 公寓'
        self.mapping['b']['published_at'] = '2026-07-28T00:00:00+00:00'
        report = self.run_bulk()
        self.assertEqual(report['held'], 2)
        self.assertFalse(any(isinstance(c, tuple) and c[0] == 'context' for c in self.adapter.calls))

    def test_guest_or_uid_mismatch_never_searches(self):
        for identity in ({'uid': 'sender', 'guest': True}, {'uid': 'other', 'guest': False}):
            self.adapter = FakeAdapter()
            self.adapter.identity_value = identity
            report = self.run_bulk(name='identity-' + identity['uid'])
            self.assertEqual(report['status'], 'stopped')
            self.assertEqual(self.adapter.calls, ['identity', 'close'])

    def test_existing_session_lock_never_opens_adapter(self):
        (self.home / '.managed-use.lock').mkdir()
        with self.assertRaises(FileExistsError):
            self.run_bulk()
        self.assertEqual(self.adapter.calls, [])

    def forbid_platform_reads(self):
        def forbidden(*args, **kwargs):
            self.fail('direct-ID mode must not search, read targets, acquire tokens or read replies')
        self.adapter.context = forbidden
        self.adapter.target = forbidden
        self.adapter.verify = forbidden

    def test_direct_id_receipts_continue_without_search_target_or_readback(self):
        self.forbid_platform_reads()
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['status'], 'complete')
        self.assertEqual(report['accepted'], 2)
        self.assertEqual(report['visible_verified'], 0)
        self.assertEqual(report['public_visibility_unverified'], 2)
        self.assertLess(self.adapter.calls.index(('receipt', 'a')), self.adapter.calls.index(('post', 'b')))
        events = self.events()
        self.assertFalse(any(event['event'] == 'target_verified' for event in events))
        self.assertFalse(any(event['event'] == 'visible_verified' for event in events))
        self.assertTrue(all(event['public_visibility'] == 'unverified' for event in events if event['event'] == 'accepted'))

    def test_direct_id_identity_failure_has_zero_post(self):
        self.forbid_platform_reads()
        self.adapter.identity_value = {'uid': 'sender', 'guest': True}
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['submit_calls'], 0)
        self.assertEqual(report['post_attempts'], 0)
        self.assertEqual(report['accepted'], 0)
        self.assertEqual(self.adapter.calls, ['identity', 'close'])

    def test_direct_id_unknown_or_post_failure_stops_entire_queue(self):
        for failure in ('missing_receipt', 'unknown_result', 461, 471, 429, -100, 'timeout'):
            with self.subTest(failure=failure):
                self.adapter = FakeAdapter()
                self.forbid_platform_reads()
                if failure == 'missing_receipt':
                    self.adapter.receipt = lambda row: None
                elif failure == 'unknown_result':
                    def unknown_post(row):
                        self.adapter.post_attempts += 1
                        return 'unknown'
                    self.adapter.submit = unknown_post
                else:
                    def failed_post(row):
                        self.adapter.calls.append(('post', row['comment_id']))
                        self.adapter.post_attempts += 1
                        raise RuntimeError('post failed; must not retry')
                    self.adapter.submit = failed_post
                report = self.run_bulk(direct_id=True, name='direct-' + str(failure))
                self.assertEqual(report['status'], 'stopped_unknown')
                self.assertEqual(report['accepted'], 0)
                self.assertEqual(report['visible_verified'], 0)
                self.assertEqual(report['submit_calls'], 1)
                self.assertEqual(report['post_attempts'], 1)
                self.assertNotIn(('post', 'b'), self.adapter.calls)

    def test_direct_id_submit_identity_failure_is_before_post_not_unknown_post(self):
        self.forbid_platform_reads()
        def identity_failed_inside_runner(row):
            raise RuntimeError('runner identity refused before any POST')
        self.adapter.submit = identity_failed_inside_runner
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['status'], 'stopped')
        self.assertEqual(report['submit_calls'], 1)
        self.assertEqual(report['post_attempts'], 0)
        self.assertEqual(report['accepted'], 0)
        self.assertFalse(any(event['event'] == 'unknown' for event in self.events()))

    def test_direct_id_preserves_local_history_and_age_holds(self):
        self.forbid_platform_reads()
        self.adapter.states['a'] = 'blocked'
        self.mapping['b']['published_at'] = '2026-07-28T00:00:00+00:00'
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['held'], 2)
        self.assertEqual(report['submit_calls'], 0)

    def test_direct_id_previously_accepted_customer_is_skipped_without_resubmit(self):
        self.forbid_platform_reads()
        self.adapter.states['a'] = 'accepted'
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['held'], 1)
        self.assertEqual(report['accepted'], 1)
        self.assertEqual(report['public_visibility_unverified'], 1)
        self.assertNotIn(('post', 'a'), self.adapter.calls)
        self.assertIn(('post', 'b'), self.adapter.calls)

    def test_direct_id_preview_has_no_external_or_local_writes(self):
        self.forbid_platform_reads()
        report = self.run_bulk(execute=False, direct_id=True)
        self.assertTrue(report['direct_id'])
        self.assertEqual(self.adapter.calls, [])
        self.assertFalse((self.root / 'run').exists())

    def test_receipt_with_restriction_stays_accepted_but_stops_before_next_post(self):
        self.forbid_platform_reads()
        diagnostic = {'success': True, 'api_code': 0, 'http_status': 200,
                      'verification_header_present': True, 'message_category': 'unknown'}
        self.adapter.acceptance_diagnostic = lambda: diagnostic
        self.adapter.diagnostic = lambda exc: diagnostic
        halted = []
        self.adapter.persist_platform_halt = lambda exc, **kwargs: halted.append(kwargs) or {'halted': True}
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['accepted'], 1)
        self.assertEqual(report['post_attempts'], 1)
        self.assertNotIn(('post', 'b'), self.adapter.calls)
        self.assertEqual(sum(e['event'] == 'unknown' for e in self.events()), 0)
        self.assertIs(halted[0]['diagnostic']['verification_header_present'], True)

    def test_stop_after_first_receipt_pauses_without_new_post_unknown_or_halt(self):
        self.forbid_platform_reads()
        original = self.adapter.receipt
        def receipt_and_stop(row):
            (self.root / 'run' / 'STOP').write_text('user requested stop', encoding='utf8')
            return original(row)
        self.adapter.receipt = receipt_and_stop
        self.adapter.persist_platform_halt = lambda *args, **kwargs: self.fail('user stop is not a platform failure')
        report = self.run_bulk(direct_id=True)
        self.assertEqual(report['status'], 'paused_by_user')
        self.assertEqual(report['accepted'], 1)
        self.assertEqual(report['post_attempts'], 1)
        self.assertNotIn(('post', 'b'), self.adapter.calls)
        self.assertEqual(sum(e['event'] == 'unknown' for e in self.events()), 0)


class PureMatching(unittest.TestCase):
    def test_top_level_exact_target_requires_uid_text_and_no_parent(self):
        row = {'comment_id': 'root', 'customer_uid': 'uid'}
        meta = {'original_comment': '礼貌问房'}
        exact = {'id': 'root', 'content': '礼貌问房', 'user_info': {'user_id': 'uid'}}
        self.assertIsNone(bulk.target_reason(exact, row, meta))
        for field, value in [('id', 'different'), ('content', '改了'), ('root_comment_id', 'parent'), ('user_info', {'user_id': 'other'})]:
            value_row = {**exact, field: value}
            self.assertIsNotNone(bulk.target_reason(value_row, row, meta))


class LiveAdapterOffline(unittest.TestCase):
    """Exercise real adapter methods while replacing only external boundaries."""
    def setUp(self):
        self.net = patch.object(socket.socket, 'connect', side_effect=AssertionError('network_forbidden'))
        self.net.start()
        self.adapter = bulk.LiveAdapter.__new__(bulk.LiveAdapter)
        self.adapter.expected_uid = 'sender'
        self.adapter.direct_id = False
        self.adapter.max_pages = 2
        self.adapter.token_cache = {}
        self.adapter._guard = lambda: None
        self.calls = []
        self.row = {'comment_id': 'root', 'customer_uid': 'customer', 'customer_id': 'canonical',
                    'attempt_id': 'attempt', 'note_id': 'exact-note', 'text': 'Approved reply'}
        self.meta = {'original_comment': '礼貌问房', 'post_title': '上海公寓'}

    def tearDown(self):
        self.net.stop()

    def clients(self, client):
        @contextmanager
        def opened(kind, plan=None):
            self.calls.append(kind)
            yield client
        self.adapter._client = opened

    def test_direct_live_adapter_rejects_any_search_target_or_visibility_read_before_client(self):
        self.adapter.direct_id = True
        def forbidden(*args, **kwargs):
            self.fail('No platform read client may be opened')
        self.adapter._client = forbidden
        for action in (lambda: self.adapter.context(self.row, self.meta),
                       lambda: self.adapter.target(self.row, self.meta, {}),
                       lambda: self.adapter.verify(self.row, {}, 'receipt')):
            with self.assertRaises(bulk.Stop):
                action()

    def test_exact_local_reservation_refusal_has_safe_category_without_identity_http_status(self):
        class Refused(ValueError):
            pass
        self.adapter.sender = SimpleNamespace(Refused=Refused)
        self.adapter.last_client = SimpleNamespace(
            managed_request_context={'stage': 'identity', 'endpoint': 'identity', 'http_status': 200})
        exact = Refused('Account has a previous unresolved submission')
        diagnostic = self.adapter.diagnostic(exact)
        self.assertEqual(diagnostic['category'], 'legacy_account_submission_unresolved')
        self.assertEqual(diagnostic['stage'], 'local_reservation_guard')
        self.assertIs(diagnostic['post_started'], False)
        self.assertNotIn('http_status', diagnostic)
        self.assertNotIn(str(exact), json.dumps(diagnostic))
        for exc in (Refused('SECRET arbitrary exception'),
                    RuntimeError('Account has a previous unresolved submission')):
            diagnostic = self.adapter.diagnostic(exc)
            self.assertNotEqual(diagnostic.get('category'), 'legacy_account_submission_unresolved')
            self.assertNotIn('SECRET', json.dumps(diagnostic))

    def test_current_search_caches_only_exact_note_token_in_memory(self):
        client = SimpleNamespace(get_self_info=lambda: {'uid': 'sender', 'guest': False})
        self.clients(client)
        self.adapter.account = SimpleNamespace(identify=lambda value: value)
        def search(actual_client, **kwargs):
            self.assertEqual(kwargs, {'keyword': '上海公寓', 'page': 1})
            self.calls.append('normal_search')
            return {'items': [
                {'id': 'wrong-note', 'xsec_token': 'wrong-token', 'note_card': {}},
                {'id': 'exact-note', 'xsec_token': 'current-token', 'note_card': {'display_title': '新标题'}}]}
        self.adapter.live = SimpleNamespace(search_without_recommend=search)
        first = self.adapter.context(self.row, self.meta)
        second = self.adapter.context(self.row, self.meta)
        self.assertEqual(first, {'token': 'current-token', 'title': '新标题'})
        self.assertIs(first, second)
        self.assertEqual(self.calls, ['search', 'normal_search'])

    def test_target_nested_or_not_found_is_held_with_bounded_reads(self):
        for mode in ('nested', 'missing', 'changed'):
            self.calls = []
            def get_comments(*args, **kwargs):
                self.calls.append(('comments', kwargs['cursor']))
                root = {'id': 'other', 'sub_comments': [{'id': 'root'}]} if mode == 'nested' else (
                    {'id': 'root', 'content': 'changed', 'user_id': 'customer'} if mode == 'changed' else {'id': 'other'})
                return {'comments': [root], 'has_more': True, 'cursor': 'next'}
            self.clients(SimpleNamespace(verify_identity=lambda: None, get_comments=get_comments))
            reason = self.adapter.target(self.row, self.meta, {'token': 'memory-only'})
            self.assertIn(reason, ('target_is_nested', 'target_text_changed', 'target_not_found_within_page_budget'))
            self.assertLessEqual(sum(isinstance(call, tuple) for call in self.calls), 2)

    def test_independent_visibility_uses_real_strict_matcher(self):
        from readback_client import match_receipt
        self.adapter.readback = SimpleNamespace(match_receipt=match_receipt)
        exact = {'id': 'reply', 'content': 'Approved reply', 'user_info': {'user_id': 'sender'},
                 'target_comment': {'id': 'root'}}
        for key, value in [(None, None), ('id', 'different'), ('content', 'changed'),
                           ('user_info', {'user_id': 'other'}), ('target_comment', {'id': 'different'})]:
            comment = dict(exact)
            if key:
                comment[key] = value
            client = SimpleNamespace(verify_identity=lambda: None,
                iter_subcomment_pages=lambda *args, **kwargs: iter([{'comments': [comment]}]))
            self.clients(client)
            self.assertEqual(self.adapter.verify(self.row, {'token': 'memory-only'}, 'reply'), key is None)

    def test_receipt_comes_from_exact_plan_in_readonly_synthetic_ledger(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            self.adapter.ledger = Path(temp) / 'synthetic.sqlite3'
            plan = {'sender_uid': 'sender', 'customer_uid': 'customer', 'canonical_customer': 'canonical',
                    'comment_id': 'root', 'note_id': 'exact-note', 'text': 'Approved reply', 'attempt_id': 'attempt'}
            with closing(sqlite3.connect(self.adapter.ledger)) as db:
                db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY,data TEXT)')
                db.execute('INSERT INTO local_sender_plans VALUES(?,?)', ('attempt', json.dumps({
                    'plan': plan, 'result': {'kind': 'platform_receipt', 'receipt_id': 'receipt'}})))
                db.commit()
            before = self.adapter.ledger.read_bytes()
            self.assertEqual(self.adapter.receipt(self.row), 'receipt')
            self.assertEqual(before, self.adapter.ledger.read_bytes())
            self.row['text'] = 'tampered'
            with self.assertRaises(bulk.Stop):
                self.adapter.receipt(self.row)


class ExactLegacyPolicy(unittest.TestCase):
    """Only synthetic SQLite; exercise the original atomic reserve and Runner."""
    def setUp(self):
        self.net = patch.object(socket.socket, 'connect', side_effect=AssertionError('network_forbidden'))
        self.net.start()
        self.tmp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.root = Path(self.tmp.name)
        self.db = self.root / 'synthetic.sqlite3'
        self.batch = self.root / 'batch.json'
        self.batch.write_text('{"synthetic":true}', encoding='utf8')
        from prepare_logged_sender import load_cli
        self.db.touch()
        self.sender = load_cli().load_sender(bulk.PROJECT, self.db, self.batch, {})
        self.sender.ROOT = self.root
        self.uid = bulk.SENDER_UID
        self.old_id = 'b1fe75b7-4d87-5f19-bd5f-e1a51dbef7cb'
        self.old_data = json.dumps({'plan': {'sender_uid': self.uid, 'customer_uid': 'old-uid'},
                                    'result': {'kind': 'unknown'}}, ensure_ascii=False)
        self.sender.LEGACY_APPROVED_BATCH_SHA256 = bulk.digest(self.batch)
        self.sender.LEGACY_RECORD_RAW_SHA256 = hashlib.sha256(self.old_data.encode('utf8')).hexdigest()
        with closing(sqlite3.connect(self.db)) as db:
            db.executescript('''
                CREATE TABLE leads(platform TEXT, customer TEXT, comment TEXT, status TEXT,
                    review_time INTEGER, evidence TEXT, operator TEXT, source TEXT);
                CREATE TABLE identity_aliases(platform TEXT, alias TEXT, canonical TEXT);
                CREATE TABLE historical_assessments(platform TEXT, customer TEXT);
                CREATE TABLE historical_deliveries(platform TEXT, customer TEXT, comment TEXT, delivery_state TEXT);
                CREATE TABLE reservations(token TEXT PRIMARY KEY, platform TEXT, customer TEXT, comment TEXT,
                    status TEXT, evidence TEXT, created INTEGER);
                CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY, data TEXT);
            ''')
            db.execute('INSERT INTO leads VALUES(?,?,?,?,NULL,NULL,NULL,?)',
                       ('xiaohongshu', 'old-customer', 'old-comment', 'unknown', 'synthetic'))
            db.execute('INSERT INTO leads VALUES(?,?,?,?,NULL,NULL,NULL,?)',
                       ('xiaohongshu', 'new-customer', 'new-comment', 'unverified', 'synthetic'))
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                       (self.old_id, 'xiaohongshu', 'old-customer', 'old-comment', 'unknown', 'unchanged', 1))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)', (self.old_id, self.old_data))
            db.commit()
        self.plan = self.sender.SendPlan(sender_uid=self.uid, customer_uid='new-uid', note_id='note',
            comment_id='new-comment', text='approved original', attempt_id='new-attempt', authorized=True,
            verification_evidence='synthetic only', valid_until=int(time.time()) + 240,
            source='synthetic', canonical_customer='new-customer')

    def tearDown(self):
        self.tmp.cleanup()
        self.net.stop()

    def policy(self):
        return self.sender.LegacyAccountGuardPolicy.from_mapping({
            'schema': 'xhs-exact-legacy-account-guard-v1', 'policy_id': 'leimu-567-legacy-account-guard-v1',
            'sender_uid': self.uid, 'batch_sha256': bulk.digest(self.batch),
            'legacy_attempt_id': self.old_id, 'legacy_record_raw_sha256': self.sender.LEGACY_RECORD_RAW_SHA256})

    def reserve(self, plan=None, policy=None, direct_id=False):
        self.sender._reserve(self.db, plan or self.plan, True, legacy_account_policy=policy, direct_id=direct_id)

    def test_default_and_non_direct_policy_keep_original_account_block(self):
        for policy in (None, self.policy()):
            with self.assertRaisesRegex(self.sender.Refused, '^Account has a previous unresolved submission$'):
                self.reserve(policy=policy)

    def test_exact_policy_only_allows_new_customer_and_preserves_old_record(self):
        self.reserve(policy=self.policy(), direct_id=True)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status,evidence FROM reservations WHERE token=?', (self.old_id,)).fetchone(),
                             ('unknown', 'unchanged'))
            self.assertEqual(db.execute('SELECT data FROM local_sender_plans WHERE token=?', (self.old_id,)).fetchone()[0], self.old_data)
            record = json.loads(db.execute('SELECT data FROM local_sender_plans WHERE token=?', ('new-attempt',)).fetchone()[0])
        self.assertEqual(record['account_guard_exception']['policy_id'], 'leimu-567-legacy-account-guard-v1')
        self.assertEqual(record['account_guard_exception']['legacy_attempt_id'], self.old_id)
        self.assertIs(record['all_accounts_history_checked'], False)

    def test_old_customer_comment_or_uid_remain_blocked(self):
        for plan in (replace(self.plan, canonical_customer='old-customer'),
                     replace(self.plan, comment_id='old-comment', canonical_customer='old-customer'),
                     replace(self.plan, customer_uid='old-uid')):
            with self.assertRaises(self.sender.Refused):
                self.reserve(plan, self.policy(), True)

    def test_wrong_uid_batch_old_hash_or_attempt_cannot_enable_exception(self):
        policy = self.policy()
        for bad in (replace(policy, sender_uid='other'), replace(policy, batch_sha256='0' * 64),
                    replace(policy, legacy_record_raw_sha256='0' * 64), replace(policy, legacy_attempt_id='other')):
            with self.assertRaises(self.sender.Refused):
                self.reserve(policy=bad, direct_id=True)
        self.batch.write_text('{"changed":true}', encoding='utf8')
        with self.assertRaises(self.sender.Refused):
            self.reserve(policy=policy, direct_id=True)

    def test_another_unresolved_record_still_blocks_entire_account(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',
                       ('another', 'xiaohongshu', 'third-customer', 'third-comment', 'unknown', None, 2))
            db.execute('INSERT INTO local_sender_plans VALUES(?,?)', ('another', self.old_data))
            db.commit()
        with self.assertRaises(self.sender.Refused):
            self.reserve(policy=self.policy(), direct_id=True)

    def test_post_unknown_remains_unknown_and_cannot_be_repeated(self):
        calls = []
        class Client:
            plan = self.plan
            _post_started = False
            def identity(inner):
                calls.append('identity')
            def send_once(inner):
                calls.append('POST')
                inner._post_started = True
                raise RuntimeError('synthetic unresolved response')
        runner = self.sender.Runner(self.db, Client(), synthetic=True,
                                    legacy_account_policy=self.policy(), direct_id=True)
        with self.assertRaises(self.sender.Unknown):
            runner.submit(self.plan)
        with self.assertRaises(self.sender.Refused):
            runner.submit(self.plan)
        self.assertEqual(calls.count('POST'), 1)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM reservations WHERE token=?', ('new-attempt',)).fetchone()[0], 'unknown')


class PlatformHalt(unittest.TestCase):
    def test_unresolved_gate_stops_both_modes_before_session_read_or_client(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            path = Path(temp) / 'platform-access-state.json'
            path.write_text(json.dumps({'sender_uid': bulk.SENDER_UID,
                'state': 'verification_response_unresolved', 'cleared': False}), encoding='utf8')
            with patch.object(bulk, 'digest', side_effect=AssertionError('must not read session')), \
                 patch.object(bulk, 'load_module', side_effect=AssertionError('must not load any client')):
                for direct_id in (True, False):
                    with self.subTest(direct_id=direct_id), \
                         self.assertRaisesRegex(bulk.Stop, 'platform_verification_pending'):
                        bulk.LiveAdapter(Path(temp), home=Path(temp) / 'absent-session', batch_path=Path(temp) / 'absent-batch',
                                         sender_uid=bulk.SENDER_UID, direct_id=direct_id, platform_access_state=path)

    def test_missing_corrupt_wrong_uid_or_cleared_boolean_never_clear_halt(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            path = Path(temp) / 'state.json'
            values = (None, '{invalid', json.dumps({'sender_uid': 'other', 'cleared': True}),
                json.dumps({'sender_uid': bulk.SENDER_UID, 'state': 'verification_response_unresolved', 'cleared': True}),
                json.dumps({'sender_uid': bulk.SENDER_UID, 'state': 'verified_normal_access', 'cleared': True,
                            'login_identity_verified': True, 'http_status': 200}))
            for value in values:
                if value is not None:
                    path.write_text(value, encoding='utf8')
                with self.assertRaises(bulk.Stop):
                    bulk.require_platform_access(path, bulk.SENDER_UID)


class NewAccountAccess(unittest.TestCase):
    def setUp(self):
        self.net = patch.object(socket.socket, 'connect', side_effect=AssertionError('network_forbidden'))
        self.net.start()
        self.tmp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.root = Path(self.tmp.name)
        self.marker_root = patch.object(bulk, 'EMERGENCY_HALT_ROOT', self.root / 'emergency-halts')
        self.marker_root.start()
        self.uid = 'aaaaaaaaaaaaaaaaaaaaaaaa'
        self.receipt_path = self.root / 'identity-receipt.json'
        self.state_path = self.root / 'platform-access-state.json'
        self.receipt = {'uid': self.uid, 'guest': False, 'saved': True, 'retry_allowed': False,
            'source': 'same_page_session_single_identity_request',
            'verified_at': datetime.now(timezone.utc).isoformat()}
        self.state = {'schema': 'xhs-new-account-access-v1',
            'state': 'new_account_identity_verified_no_known_challenge', 'sender_uid': self.uid,
            'identity_receipt': {'path': str(self.receipt_path), 'sha256': ''}}
        self.write_proof()

    def tearDown(self):
        self.marker_root.stop()
        self.tmp.cleanup()
        self.net.stop()

    def write_proof(self):
        self.receipt_path.write_text(json.dumps(self.receipt), encoding='utf8')
        self.state['identity_receipt']['sha256'] = bulk.digest(self.receipt_path)
        self.state_path.write_text(json.dumps(self.state), encoding='utf8')

    def test_new_account_exact_fresh_normal_identity_receipt_allows_initial_gate(self):
        bulk.require_platform_access(self.state_path, self.uid)

    def test_new_state_cannot_clear_old_sender_known_challenge(self):
        self.receipt['uid'] = bulk.SENDER_UID
        self.state['sender_uid'] = bulk.SENDER_UID
        self.write_proof()
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state_path, bulk.SENDER_UID)

    def test_new_state_requires_exact_uid_guest_source_saved_and_freshness(self):
        original = dict(self.receipt)
        for key, value in [('uid', 'other'), ('guest', True), ('saved', False),
                ('retry_allowed', True), ('source', 'manually_set_success_booleans'),
                ('verified_at', (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()),
                ('verified_at', (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()),
                ('verified_at', 'not-a-date')]:
            with self.subTest(key=key, value=value):
                self.receipt = {**original, key: value}
                self.write_proof()
                with self.assertRaises(bulk.Stop):
                    bulk.require_platform_access(self.state_path, self.uid)

    def test_changed_or_missing_receipt_or_hash_is_fail_closed(self):
        self.receipt_path.write_text('{}', encoding='utf8')
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state_path, self.uid)
        self.receipt_path.unlink()
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state_path, self.uid)

    def test_new_uid_cleared_boolean_alone_or_unresolved_state_never_passes(self):
        for state in ({'sender_uid': self.uid, 'cleared': True},
                      {**self.state, 'state': 'verification_response_unresolved', 'cleared': True}):
            self.state_path.write_text(json.dumps(state), encoding='utf8')
            with self.assertRaises(bulk.Stop):
                bulk.require_platform_access(self.state_path, self.uid)

    def test_new_uid_cannot_use_legacy_policy_before_any_session_read(self):
        with self.assertRaisesRegex(bulk.Stop, 'legacy_policy_sender_mismatch'):
            bulk.LiveAdapter(self.root, home=self.root / 'absent-home', batch_path=self.root / 'absent-batch',
                sender_uid=self.uid, direct_id=True, legacy_account_policy=self.root / 'old-policy.json',
                platform_access_state=self.state_path)

    def test_new_batch_intended_uid_mismatch_stops_before_session_or_clients(self):
        batch = self.root / 'wrong-account-batch.json'
        batch.write_text(json.dumps({'intended_account_uid': bulk.SENDER_UID}), encoding='utf8')
        with patch.object(bulk, 'digest', side_effect=AssertionError('must not read session')), \
             patch.object(bulk, 'load_module', side_effect=AssertionError('must not load clients')), \
             self.assertRaisesRegex(bulk.Stop, 'batch_sender_mismatch'):
            bulk.LiveAdapter(self.root, home=self.root / 'absent-home', batch_path=batch,
                             sender_uid=self.uid, direct_id=True, platform_access_state=self.state_path)

    def test_new_runtime_identity_must_still_equal_explicit_uid(self):
        home = self.root / 'synthetic-home'
        home.mkdir()
        adapter = FakeAdapter()
        adapter.identity_value = {'uid': 'different-live-uid', 'guest': False}
        report = bulk.run([], {}, sender_uid=self.uid, session_home=home, run_dir=self.root / 'run',
                          execute=True, direct_id=True, adapter_factory=lambda root: adapter, interval=0)
        self.assertEqual(report['status'], 'stopped')
        self.assertEqual(report['post_attempts'], 0)
        self.assertEqual(adapter.calls, ['identity', 'close'])

    def test_explicit_cli_uid_batch_and_platform_state_forwarded_without_live_actions(self):
        batch = self.root / 'batch.json'
        mapping = self.root / 'mapping.json'
        batch.write_text(json.dumps({'schema': 'xhs-local-plan-v1', 'intended_account_uid': self.uid,
                                    'count': 0, 'rows': []}), encoding='utf8')
        mapping.write_text('[]', encoding='utf8')
        argv = ['--sender-uid', self.uid, '--batch', str(batch), '--mapping', str(mapping),
                '--platform-access-state', str(self.state_path), '--session-home', str(self.root), '--direct-id']
        with patch.object(bulk, 'run', return_value={'mode': 'preview'}) as run, \
             patch.object(bulk, 'LiveAdapter', return_value='synthetic-client') as adapter:
            self.assertEqual(bulk.main(argv), 0)
            self.assertEqual(run.call_args.kwargs['sender_uid'], self.uid)
            self.assertFalse(run.call_args.kwargs['execute'])
            run.call_args.kwargs['adapter_factory'](self.root)
            self.assertEqual(adapter.call_args.kwargs['sender_uid'], self.uid)
            self.assertEqual(adapter.call_args.kwargs['platform_access_state'], self.state_path)
        wrong = ['--sender-uid', 'other', '--batch', str(batch), '--mapping', str(mapping)]
        with self.assertRaises(SystemExit), patch.object(bulk, 'run', side_effect=AssertionError('must not start')):
            bulk.main(wrong)

    def halt_adapter(self, status=461):
        adapter = FakeAdapter()
        adapter.expected_uid = self.uid
        adapter.platform_access_state = self.state_path
        adapter.platform_access_state_digest = bulk.digest(self.state_path)
        adapter._permanent_halt = False
        adapter.halt_writer = bulk.atomic_platform_state
        adapter.last_client = SimpleNamespace(_locked=True,
            managed_request_context={'stage': 'identity', 'endpoint': 'identity',
                                     'http_status': status, 'request_started': True})
        adapter.persist_platform_halt = lambda exc, **kwargs: bulk.LiveAdapter.persist_platform_halt(adapter, exc, **kwargs)
        return adapter

    def test_identity_challenge_zero_post_persists_only_current_uid_and_blocks_fresh_restart(self):
        other = self.root / 'old-leimu-platform-state.json'
        other.write_text(json.dumps({'sender_uid': bulk.SENDER_UID, 'state': 'verification_response_unresolved'}), encoding='utf8')
        old_bytes = other.read_bytes()
        adapter = self.halt_adapter()
        def challenged_identity():
            adapter.calls.append('identity')
            raise RuntimeError('synthetic challenge')
        adapter.identity = challenged_identity
        adapter.diagnostic = lambda exc: {'http_status': 461, 'stage': 'identity'}
        home = self.root / 'home'
        home.mkdir()
        report = bulk.run([], {}, sender_uid=self.uid, session_home=home, run_dir=self.root / 'challenged-run',
                          execute=True, direct_id=True, adapter_factory=lambda root: adapter, interval=0)
        self.assertEqual(report['post_attempts'], 0)
        state = bulk.read_json(self.state_path)
        self.assertEqual(state['state'], 'verification_response_unresolved')
        self.assertEqual(state['identity_receipt'], self.state['identity_receipt'])
        self.assertEqual(other.read_bytes(), old_bytes)
        self.write_proof()  # A fresh successful identity alone cannot clear the marker.
        with patch.object(bulk, 'load_module', side_effect=AssertionError('must not load clients')), \
             self.assertRaises(bulk.Stop):
            bulk.LiveAdapter(self.root, home=self.root / 'absent-home', batch_path=self.root / 'absent-batch',
                             sender_uid=self.uid, direct_id=True, platform_access_state=self.state_path)

    def test_primary_halt_write_failure_leaves_emergency_marker_and_restart_is_closed(self):
        before = self.state_path.read_bytes()
        adapter = self.halt_adapter(429)
        def fail_write(*args):
            raise OSError('synthetic state write failure')
        adapter.halt_writer = fail_write
        result = adapter.persist_platform_halt(RuntimeError('synthetic challenge'),
            diagnostic={'http_status': 429, 'stage': 'identity'}, post_started=False)
        self.assertFalse(result['state_written'])
        self.assertTrue(result['emergency_marker_written'])
        self.assertTrue(adapter._permanent_halt)
        self.assertEqual(self.state_path.read_bytes(), before)
        with self.assertRaises(bulk.Stop):
            bulk.require_platform_access(self.state_path, self.uid)

    def test_post_unknown_halts_and_existing_unknown_ledger_data_is_unchanged(self):
        db_path = self.root / 'synthetic-unknown.sqlite3'
        with closing(sqlite3.connect(db_path)) as db:
            db.execute('CREATE TABLE reservations(token TEXT,status TEXT)')
            db.execute('INSERT INTO reservations VALUES(?,?)', ('existing-unknown', 'unknown'))
            db.commit()
        before = db_path.read_bytes()
        adapter = self.halt_adapter(200)
        adapter.last_client._locked = False
        adapter.identity_value = {'uid': self.uid, 'guest': False}
        def unknown_post(row):
            adapter.post_attempts += 1
            adapter.calls.append('POST')
            raise RuntimeError('synthetic POST response unknown')
        adapter.submit = unknown_post
        adapter.diagnostic = lambda exc: {'stage': 'send'}
        home = self.root / 'home'
        home.mkdir()
        row = {'comment_id': 'root', 'customer_uid': 'customer', 'customer_id': 'canonical',
               'note_id': 'note', 'attempt_id': 'attempt', 'text': 'approved original'}
        meta = {'customer_uid': 'customer', 'canonical_customer': 'canonical', 'original_comment': '礼貌问房',
                'post_title': '上海公寓', 'published_at': datetime.now(timezone.utc).isoformat()}
        report = bulk.run([row, {**row, 'comment_id': 'next'}], {'root': meta, 'next': meta},
            sender_uid=self.uid, session_home=home, run_dir=self.root / 'unknown-run', execute=True,
            direct_id=True, adapter_factory=lambda root: adapter, interval=0)
        self.assertEqual(report['status'], 'stopped_unknown')
        self.assertEqual(adapter.calls.count('POST'), 1)
        self.assertEqual(bulk.read_json(self.state_path)['state'], 'unknown_requires_reconciliation')
        self.assertEqual(db_path.read_bytes(), before)

    def test_local_preparation_error_never_writes_platform_halt(self):
        before = self.state_path.read_bytes()
        adapter = self.halt_adapter(200)
        adapter.last_client._locked = False
        result = adapter.persist_platform_halt(bulk.Stop('frozen_source_changed'), diagnostic={}, post_started=False)
        self.assertFalse(result['halted'])
        self.assertEqual(self.state_path.read_bytes(), before)
        self.assertFalse((self.root / 'emergency-halts').exists())

    def test_cas_or_uid_change_never_overwrites_another_account_state(self):
        adapter = self.halt_adapter()
        other_state = {'sender_uid': 'bbbbbbbbbbbbbbbbbbbbbbbb', 'state': 'other-account-state'}
        self.state_path.write_text(json.dumps(other_state), encoding='utf8')
        before = self.state_path.read_bytes()
        result = adapter.persist_platform_halt(RuntimeError('synthetic challenge'),
            diagnostic={'http_status': 461}, post_started=False)
        self.assertFalse(result['state_written'])
        self.assertTrue(result['emergency_marker_written'])
        self.assertEqual(self.state_path.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
