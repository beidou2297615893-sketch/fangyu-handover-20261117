import json
import unittest
from unittest.mock import patch
import httpx
import collector


class SearchDetailTests(unittest.TestCase):
    def run_search(self, endpoint, body, status=200):
        calls=[]
        def respond(req):
            calls.append(req.url.path)
            if req.url.path.endswith(endpoint):
                return httpx.Response(status,request=req,json=body)
            return httpx.Response(200,request=req,json={'success':True,'data':{}})
        client=collector.ReadClient({'a1':'fixture','web_session':'fixture'},transport=httpx.MockTransport(respond),delay=0)
        try:
            with patch('xhs_cli.client_mixins._acquire_search_session',return_value=('fixture',True)), \
                 patch('xhs_cli.client.sign_main_api',return_value={}):
                with self.assertRaises(collector.Halt) as captured:client.search_notes('古北',page=1)
        finally:client.close()
        return calls,str(captured.exception)

    def test_code_zero_false_on_onebox_is_labeled_and_never_continues(self):
        calls,text=self.run_search('/onebox',{'code':0,'success':False,'data':{'cookie':'secret'}})
        self.assertEqual(calls,['/api/sns/web/v1/search/onebox'])
        self.assertIn('prewarm_onebox',text)
        self.assertIn('"api_code": 0',text)
        self.assertIn('"success_type": "boolean"',text)
        self.assertIn('"success_value": false',text)
        self.assertNotIn('secret',text)

    def test_code_zero_missing_success_on_filter_is_labeled_and_stops(self):
        calls,text=self.run_search('/filter',{'code':0,'data':{'token':'secret'}})
        self.assertTrue(calls[-1].endswith('/filter'))
        self.assertEqual(len(calls),2)
        self.assertIn('prewarm_filter',text)
        self.assertIn('"success_type": "missing"',text)
        self.assertNotIn('secret',text)

    def test_notes_code_zero_with_unexpected_types_is_labeled_and_stops(self):
        calls,text=self.run_search('/notes',{'code':0,'success':None,'data':'secret'})
        self.assertTrue(calls[-1].endswith('/notes'))
        self.assertEqual(len(calls),3)
        self.assertIn('search_notes',text)
        self.assertIn('"success_type": "null"',text)
        self.assertIn('"data_type": "string"',text)
        self.assertNotIn('secret',text)

    def test_http_461_never_continues_and_has_only_safe_detail(self):
        calls,text=self.run_search('/onebox',{'code':0,'msg':'secret'},461)
        self.assertEqual(len(calls),1)
        self.assertIn('"http_status": 461',text)
        self.assertIn('prewarm_onebox',text)
        self.assertNotIn('secret',text)

    def test_expired_identity_does_not_continue(self):
        calls,text=self.run_search('/onebox',{'code':-100,'msg':'secret'})
        self.assertEqual(len(calls),1)
        self.assertIn('"api_code": -100',text)
        self.assertNotIn('secret',text)


if __name__=='__main__':unittest.main(verbosity=2)
