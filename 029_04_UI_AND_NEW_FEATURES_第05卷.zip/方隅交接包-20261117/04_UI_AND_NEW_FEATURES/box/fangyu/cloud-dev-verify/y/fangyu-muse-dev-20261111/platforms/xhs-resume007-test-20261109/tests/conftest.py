"""pytest 配置与共享 fixture。"""
import os
import sys
import tempfile
from pathlib import Path

import pytest

# 确保 tests 目录可导入 fakes
sys.path.insert(0, str(Path(__file__).parent))


@pytest.fixture
def temp_project(tmp_path):
    """创建临时 PROJECT 目录结构。"""
    project = tmp_path / 'project'
    project.mkdir()
    # 创建 resume006 ROOT 目录
    resume006_root = project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
    resume006_root.mkdir(parents=True)
    # 创建账本目录
    ledger_dir = project / 'work/shared-acquisition-ledger'
    ledger_dir.mkdir(parents=True)
    # 创建 stop-today 目录
    stop_dir = project / 'work/xhs-resume-20261103'
    stop_dir.mkdir(parents=True)
    # 创建 session home
    session_home = tmp_path / 'session-home'
    session_home.mkdir()
    # 设置环境变量
    env = {
        'XHS_RESUME007_RESUME006_ROOT': str(resume006_root),
        'XHS_RESUME007_LEDGER': str(ledger_dir / 'shared.sqlite3'),
        'XHS_RESUME007_STOP_TODAY': str(stop_dir / 'stop-today-resume007.json'),
    }
    for k, v in env.items():
        os.environ[k] = v
    yield {
        'project': project,
        'resume006_root': resume006_root,
        'ledger': ledger_dir / 'shared.sqlite3',
        'stop_today': stop_dir / 'stop-today-resume007.json',
        'session_home': session_home,
    }
    # 清理环境变量
    for k in env:
        os.environ.pop(k, None)
