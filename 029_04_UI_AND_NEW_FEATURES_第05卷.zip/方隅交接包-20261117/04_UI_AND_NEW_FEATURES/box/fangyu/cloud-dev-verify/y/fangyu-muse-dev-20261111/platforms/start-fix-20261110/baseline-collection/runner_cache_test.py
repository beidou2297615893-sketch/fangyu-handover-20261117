"""Offline safety tests, including historical requests without runner metadata."""
import sys
sys.dont_write_bytecode = True
import hashlib
import json
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from ledger import Ledger
from runner_ledger_adapter import Cache, assess, fingerprint

ROOT = Path(__file__).resolve().parent


class CacheTests(unittest.TestCase):
    def test_authorized_account_transition_counts_globally_and_skips_prior_videos(self):
        self.search(video='123')
        self.ingest('comments','123',dict(status_code=0,comments=[dict(cid='900')],cursor=20,has_more=0))
        for account,cids in [('next-owner',['900','901']),('unrelated-owner',['999'])]:
            spec=dict(request_id=account,scan_id='synthetic',account_uid=account,connection_id='synthetic-page',kind='comments',target='456',cursor=0,store_id='上海合成店',keyword='新词',rule_source='synthetic-only',eligibility={'state':'eligible'})
            self.assertEqual(self.ledger.ingest(spec,dict(ok=True,connection='synthetic-page',value=dict(status_code=0,comments=[dict(cid=x) for x in cids],cursor=20,has_more=0)))['state'],'parsed')
        spec=dict(request_id='next-search',scan_id='synthetic',account_uid='next-owner',connection_id='synthetic-page',kind='search',target='新词',cursor=0,store_id='上海合成店',keyword='新词',rule_source='synthetic-only')
        self.assertEqual(self.ledger.ingest(spec,dict(ok=True,connection='synthetic-page',value=dict(status_code=0,data=[dict(aweme_info=dict(aweme_id='123',desc='上海租房',create_time=100))],cursor=10,has_more=0)))['state'],'parsed')
        plan={**self.plan,'account_uid':'next-owner','collection_accounts':['owner','next-owner'],'account_transition_source':'synthetic explicit authorization','qualification_policy':{'account_uid':'owner','qualified_request_ids':[]}}
        cache=Cache(self.path);cache.sync()
        snap=cache.snapshot(plan)
        self.assertEqual(snap['summary']['comments'],2)
        self.assertEqual(snap['videos'],[])
        self.assertEqual(snap['review_counts'].get('previous_account_source_retained'),1)
        self.assertEqual(cache.snapshot(plan)['summary']['comments'],2)
        cache.db.close()

    def setUp(self):
        self.directory = Path(tempfile.mkdtemp(prefix='runner-cache-test-', dir=ROOT))
        self.path = self.directory / 'collection.sqlite3'
        self.ledger = Ledger(self.path)
        self.plan = dict(scan_id='synthetic', account_uid='owner', stores=[dict(store_id='上海合成店', name='上海合成店', city='上海')], search_tasks=[])

    def ingest(self, kind, target, value, cursor=0, store='上海合成店', keyword='合成找房词'):
        spec = dict(request_id=f'{kind}-{target}-{cursor}-{store}', scan_id='synthetic', account_uid='owner', connection_id='synthetic-page',
                    kind=kind, target=target, cursor=cursor, store_id=store, keyword=keyword, rule_source='synthetic-only',eligibility={'state':'eligible'} if kind=='comments' else None)
        receipt = self.ledger.ingest(spec, dict(ok=True, connection='synthetic-page', value=value))
        self.assertEqual(receipt['state'], 'parsed')
        return spec

    def search(self, target='word', video='123', body='上海租房合成原文'):
        return self.ingest('search', target, dict(status_code=0, data=[dict(aweme_info=dict(aweme_id=video, desc=body, create_time=100))], cursor=10, has_more=0))

    def test_legacy_fingerprint_incremental_partial_overlap_and_checkpoint(self):
        self.search()
        first = [str(1000+i) for i in range(20)]
        second = first[7:]+[str(2000+i) for i in range(7)]
        self.ingest('comments', '123', dict(status_code=0, comments=[dict(cid=x, text='合成') for x in first], cursor=20, has_more=1))
        self.ingest('comments', '123', dict(status_code=0, comments=[dict(cid=x, text='合成') for x in second], cursor=40, has_more=1), cursor=20)
        before = hashlib.sha256(self.path.read_bytes()).hexdigest()
        cache = Cache(self.path)
        cache.sync()
        self.assertEqual(cache.decoded, 3)
        snap = cache.snapshot(self.plan)
        self.assertEqual(snap['summary']['comments'], 27)
        self.assertEqual(snap['videos'][0]['cursor'], 40)
        self.assertEqual(snap['videos'][0]['scope_keyword'], '合成找房词')
        spec = dict(scan_id='synthetic', account_uid='owner', kind='comments', target='123', page_items_digest=fingerprint('comments', dict(comments=[dict(cid=x) for x in first])))
        self.assertTrue(cache.seen(spec))
        spec['page_items_digest'] = fingerprint('comments', dict(comments=[dict(cid=x) for x in second]))
        self.assertTrue(cache.seen(spec))
        self.assertNotEqual(fingerprint('comments', dict(comments=[dict(cid=x) for x in first])), spec['page_items_digest'])
        cache.db.close()
        again = Cache(self.path)
        again.sync()
        self.assertEqual(again.decoded, 0)
        self.assertEqual(again.snapshot(self.plan)['cache_stats']['admissions_computed'], 0)
        with self.assertRaises(sqlite3.OperationalError):
            again.db.execute("UPDATE source.attempts SET detail='must not write'")
        again.db.close()
        self.assertEqual(hashlib.sha256(self.path.read_bytes()).hexdigest(), before)

    def test_existing_comment_scope_wins_over_first_search_source(self):
        self.search()
        self.plan['stores'].append(dict(store_id='上海另一合成店', name='上海另一合成店', city='上海'))
        self.ingest('comments', '123', dict(status_code=0, comments=[dict(cid='900')], cursor=40, has_more=1), store='上海另一合成店', keyword='另一个真实源词')
        cache=Cache(self.path);cache.sync();task=cache.snapshot(self.plan)['videos'][0]
        self.assertEqual(task['cursor'],40)
        self.assertEqual(task['scope_store_id'],'上海另一合成店')
        self.assertEqual(task['scope_keyword'],'另一个真实源词')
        cache.db.close()

    def test_conservative_geography_rental_gate(self):
        store=self.plan['stores'][0]
        for body in ('郑州租房','深圳太福路找房','上海买房首付优惠','找房看这里','上海生活很方便','上海租房，深圳也有',''):
            self.assertEqual(assess(body,store)['state'],'review_required')
        self.assertEqual(assess('上海租房，合成公开原文',store)['state'],'eligible')
        self.search(body='郑州租房')
        cache=Cache(self.path);cache.sync();snap=cache.snapshot(self.plan)
        self.assertEqual(snap['videos'],[])
        self.assertEqual(snap['review_counts']['review_required'],1)
        cache.db.close()

    def test_scale_100000_entities_and_5000_pages_decode_once(self):
        # All rows are synthetic, inserted together to test cache scale rather than ingest speed.
        with self.ledger._db() as db:
            db.executemany('INSERT INTO entities VALUES(?,?,?,?,?)', ((f'comment:{i}', 'comments', str(i), 'synthetic', '{}') for i in range(100000)))
            def attempts():
                for page in range(5000):
                    spec=dict(request_id=f'scale-{page}',scan_id='synthetic',account_uid='owner',connection_id='synthetic-page',kind='comments',target='123',cursor=page*20,store_id='上海合成店',keyword='word',rule_source='synthetic-only',eligibility={'state':'eligible'})
                    response=dict(ok=True,connection='synthetic-page',value=dict(status_code=0,comments=[dict(cid=str(page*20+i)) for i in range(20)],cursor=(page+1)*20,has_more=1))
                    yield(spec['request_id'],'synthetic-time',json.dumps(spec),json.dumps(response),'synthetic-digest','parsed','synthetic',20)
            db.executemany('INSERT INTO attempts VALUES(?,?,?,?,?,?,?,?)',attempts())
        start=time.perf_counter();cache=Cache(self.path);cache.sync()
        self.assertEqual(cache.decoded,5000)
        self.assertEqual(cache.snapshot(self.plan)['summary']['comments'],100000)
        first=time.perf_counter()-start;cache.db.close()
        start=time.perf_counter();again=Cache(self.path);again.sync();snap=again.snapshot(self.plan);second=time.perf_counter()-start
        self.assertEqual(again.decoded,0);self.assertEqual(snap['cache_stats']['admissions_computed'],0)
        self.assertLess(second,first)
        again.db.close()
        print(json.dumps(dict(synthetic_scale_entities=100000,synthetic_pages=5000,initial_cache_seconds=round(first,3),warm_snapshot_seconds=round(second,3),warm_decoded=0)))

    def test_excluded_relation_does_not_ban_cid_on_later_eligible_source(self):
        def add(request,video,eligibility):
            spec=dict(request_id=request,scan_id='synthetic',account_uid='owner',connection_id='synthetic-page',kind='comments',target=video,cursor=0,store_id='上海合成店',keyword='word',rule_source='synthetic-only',eligibility=eligibility)
            self.ledger.ingest(spec,dict(ok=True,connection='synthetic-page',value=dict(status_code=0,comments=[dict(cid='12345')],cursor=20,has_more=0)))
        add('excluded','999','excluded_irrelevant')
        cache=Cache(self.path);cache.sync();snap=cache.snapshot(self.plan)
        self.assertEqual(snap['summary']['comments'],0);self.assertEqual(snap['summary']['total_comments'],1);cache.db.close()
        add('eligible','888',{'state':'eligible'})
        cache=Cache(self.path);cache.sync();snap=cache.snapshot(self.plan)
        self.assertEqual(snap['summary']['comments'],1);self.assertEqual(snap['summary']['total_comments'],1);cache.db.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
