"""测试各种拒绝场景。"""
import json
import os
import sys
import unittest
from pathlib import Path

# 确保可导入 resume007
SRC_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SRC_DIR))

import resume007
from tests.fixture_builder import build_valid_fixture, make_invalid, create_ledger


class TestReject(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        self.resume006_root = self.project / 'work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume006-20261103'
        self.resume006_root.mkdir(parents=True)
        self.ledger_dir = self.project / 'work/shared-acquisition-ledger'
        self.ledger_dir.mkdir(parents=True)
        self.ledger = self.ledger_dir / 'shared.sqlite3'
        create_ledger(self.ledger)
        self.stop_today = self.project / 'work/xhs-resume-20261103/stop-today-resume007.json'
        self.stop_today.parent.mkdir(parents=True)
        self.session_home = Path(self.tmp.name) / 'session-home'
        self.session_home.mkdir()
        self.here_dir = Path(self.tmp.name) / 'here'
        self.here_dir.mkdir()

        # 设置环境变量
        self.env = {
            'XHS_RESUME007_RESUME006_ROOT': str(self.resume006_root),
            'XHS_RESUME007_LEDGER': str(self.ledger),
            'XHS_RESUME007_STOP_TODAY': str(self.stop_today),
            'XHS_RESUME007_HERE': str(self.here_dir),
            'XHS_RESUME007_PROJECT': str(self.project),
        }
        for k, v in self.env.items():
            os.environ[k] = v

        # 注入 fake runtime
        from tests.fakes import FakeLive, FakeOnce, FakeScheduling, FakeClientFactory
        self.live = FakeLive()
        self.once = FakeOnce()
        self.scheduling = FakeScheduling()
        self.client_factory = FakeClientFactory('test-uid', delay=6.0)
        resume007._LOAD = lambda: (self.live, None, self.once, self.scheduling)
        resume007._CLIENT_FACTORY = self.client_factory

        self.uid = '123456789012345678901234'
        build_valid_fixture(self.resume006_root, self.session_home, self.uid, self.here_dir)

    def tearDown(self):
        for k in self.env:
            os.environ.pop(k, None)
        resume007._LOAD = None
        resume007._CLIENT_FACTORY = None
        self.tmp.cleanup()

    def _run_main(self, args_list):
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            old_argv = sys.argv
            sys.argv = ['resume007.py'] + args_list
            try:
                code = resume007.main()
            finally:
                sys.argv = old_argv
        return code, f.getvalue().strip()

    def test_reject_prior_state_changed(self):
        make_invalid('prior_state_changed', self.resume006_root, self.session_home, self.uid, self.here_dir)
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'prior_state_changed')

    def test_reject_unknown_registration(self):
        make_invalid('unknown_registration', self.resume006_root, self.session_home, self.uid, self.here_dir)
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'unknown_registration')

    def test_reject_failure_changed(self):
        make_invalid('failure_changed', self.resume006_root, self.session_home, self.uid, self.here_dir)
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'failure_changed')

    def test_reject_verified_account_required(self):
        make_invalid('verified_account_required', self.resume006_root, self.session_home, self.uid, self.here_dir)
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'verified_account_required')

    def test_reject_active_lock(self):
        make_invalid('active_lock', self.resume006_root, self.session_home, self.uid, self.here_dir)
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home)])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'active_lock')

    def test_reject_delay_too_small(self):
        code, out = self._run_main(['--uid', self.uid, '--session-home', str(self.session_home), '--delay', '2.0'])
        self.assertNotEqual(code, 0)
        data = json.loads(out)
        self.assertEqual(data['status'], 'rejected')
        self.assertEqual(data['reason'], 'delay_too_small')


if __name__ == '__main__':
    unittest.main()
