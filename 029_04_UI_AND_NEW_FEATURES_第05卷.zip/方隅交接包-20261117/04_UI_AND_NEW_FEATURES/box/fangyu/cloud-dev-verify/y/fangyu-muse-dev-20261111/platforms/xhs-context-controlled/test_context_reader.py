import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import httpx
import context_reader as m


class ControlledContextTests(unittest.TestCase):
    def test_preview_does_not_create_output_or_client(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);i=root/'input.json';a=root/'analysis.json'
            i.write_text(json.dumps([{'comment_id':'c','note_id':'n'}]),encoding='utf8')
            a.write_text(json.dumps({'items':[{'comment_id':'c','result':{'role':'unknown'}}]}),encoding='utf8')
            with patch.object(m,'ContextClient',side_effect=AssertionError('must not initialize')):
                self.assertEqual(m.main(['--input',str(i),'--review-analysis',str(a),'--output',str(root/'out')]),0)
            self.assertFalse((root/'out').exists())

    def test_selection_only_unknown_and_three_post_bound(self):
        records=[{'comment_id':str(i),'note_id':str(i)} for i in range(4)]
        analysis={'items':[{'comment_id':str(i),'result':{'role':'unknown'}} for i in range(4)]}
        with self.assertRaises(m.Halt):m.selected_records(records,analysis)
        analysis['items'][3]['result']['role']='supply'
        rows,notes=m.selected_records(records,analysis)
        self.assertEqual(len(rows),3);self.assertEqual(len(notes),3)

    def test_cache_expiry_and_missing_stop_without_logging_token(self):
        from xhs_cli.constants import CONFIG_DIR_NAME,TOKEN_CACHE_FILE
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/CONFIG_DIR_NAME;p.mkdir()
            (p/TOKEN_CACHE_FILE).write_text(json.dumps({'n':{'token':'secret-token','source':'pc_search','ts':1}}),encoding='utf8')
            self.assertEqual(m.cached_context(d,['n'],now=2)['n']['source'],'pc_search')
            for ids,now in [(['n'],90000),(['missing'],2)]:
                with self.assertRaises(m.Halt) as cm:m.cached_context(d,ids,now)
                self.assertNotIn('secret-token',str(cm.exception))

    def test_mutation_html_search_and_subcomments_block_before_wire(self):
        calls=[]
        client=m.ContextClient({},transport=httpx.MockTransport(lambda req:calls.append(req)),delay=0)
        try:
            for method,url in [('POST','https://edith.xiaohongshu.com/api/sns/web/v1/comment/post'),('GET','https://www.xiaohongshu.com/explore/n?xsec_token=secret'),('POST','https://edith.xiaohongshu.com/api/sns/web/v1/search/notes'),('GET','https://edith.xiaohongshu.com/api/sns/web/v2/comment/sub/page')]:
                with self.assertRaises(m.Halt) as cm:client._request_with_retry(method,url)
                self.assertNotIn('secret',str(cm.exception))
            self.assertEqual(calls,[])
        finally:client.close()

    def test_461_429_and_verification_never_retry(self):
        for status,payload in [(461,{}),(429,{}),(200,{'success':False,'code':-100}),(200,{'success':False,'code':300012}),(200,{'success':False,'code':0,'verifyuuid':'secret'})]:
            calls=[]
            def respond(req):
                calls.append(req)
                return httpx.Response(status,json=payload)
            client=m.ContextClient({},transport=httpx.MockTransport(respond),delay=0)
            try:
                with self.assertRaises(m.Halt) as cm:
                    response=client._request_with_retry('POST','https://edith.xiaohongshu.com/api/sns/web/v1/feed')
                    client._handle_response(response)
                self.assertEqual(len(calls),1)
                self.assertNotIn('secret',str(cm.exception))
            finally:client.close()

    def test_direct_enrichment_deduplicates_post_and_preserves_own_text(self):
        class Fake:
            def __init__(self):self.calls=[]
            def get_self_info(self):return {'user_id':'sender'}
            def get_note_by_id(self,note_id,**kwargs):
                self.calls.append(note_id)
                return {'items':[{'note_card':{'note_id':note_id,'title':'古北转租','desc':'一房出租'}}]}
            def get_note_detail(self,*args,**kwargs):raise AssertionError('HTML fallback path forbidden')
        client=Fake()
        records=[{'comment_id':'c'+str(i),'note_id':'n','comment_text':'一房还是两房','parent_text':'','missing_context':['post_body_missing','parent_not_collected','subcomments_not_collected']} for i in range(2)]
        result,bodies=m.enrich(client,'sender',records,{'n':{'token':'secret','source':'pc_search'}},True)
        self.assertEqual(client.calls,['n']);self.assertEqual(result[0]['post_text'],'一房出租')
        self.assertEqual(result[0]['comment_text'],'一房还是两房')
        self.assertEqual(result[0]['parent_relationship'],'top_level_comment_on_post')
        self.assertEqual(result[0]['missing_context'],['subcomments_not_collected'])
        self.assertNotIn('secret',json.dumps(result));self.assertNotIn('secret',json.dumps(bodies))
        self.assertNotIn('post_text',records[0])

    def test_installed_vendor_wire_only_identity_then_direct_feed(self):
        calls=[]
        def respond(req):
            calls.append((req.method,req.url.path))
            data={'user_id':'sender'} if req.url.path.endswith('/user/me') else {'items':[{'note_card':{'note_id':'n','title':'出租','desc':'一房'}}]}
            return httpx.Response(200,json={'success':True,'data':data})
        client=m.ContextClient({},transport=httpx.MockTransport(respond),delay=0)
        try:
            with patch('xhs_cli.client.sign_main_api',return_value={}),patch('xhs_cli.client_mixins.cache_note_context'):
                result,_=m.enrich(client,'sender',[{'note_id':'n','comment_text':'问价'}],{'n':{'token':'secret','source':'pc_search'}})
            self.assertEqual(result[0]['post_text'],'一房')
            self.assertEqual(calls,[('GET','/api/sns/web/v2/user/me'),('POST','/api/sns/web/v1/feed')])
        finally:client.close()

    def test_wrong_or_oversized_post_stops(self):
        for card in [{'note_id':'wrong','title':'x','desc':'x'},{'note_id':'n','desc':'x'*20001},{'note_id':'n'}]:
            with self.assertRaises(m.Halt):m.note_body({'items':[{'note_card':card}]},'n')


if __name__=='__main__':unittest.main()
