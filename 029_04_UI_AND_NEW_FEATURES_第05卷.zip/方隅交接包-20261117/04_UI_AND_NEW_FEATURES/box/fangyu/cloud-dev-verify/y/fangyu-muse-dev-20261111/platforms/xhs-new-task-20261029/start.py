"""New authorized account task, with the existing shared ledger."""
import importlib.util
import json
from pathlib import Path

PROJECT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('new_task_live',PROJECT/'work/xhs-live-collection-runner-20261029/runner.py')
live=importlib.util.module_from_spec(spec)
spec.loader.exec_module(live)
root=PROJECT/'work/xhs-account-switch-recovery-candidate/runtime/new-account-task-20261029-1710'
root.mkdir(exist_ok=False)
queue=live.read(PROJECT/'work/fangyu-text-business-20261029/gubei-existing46-next.json')
# Each bounded page uses the original account/ledger guards and audit receipts.
plan=[{'keyword':item['keyword'],'page':page} for item in queue['keywords'][1:] for page in (1,2,3)]
live.write_new(root/'authorization.json',{'source':'user_current_chat_new_account_task',
    'separate_from_previous_task':True,'shared_ledger':True,'send_authorized':False,
    'stop_on_platform_verification_or_failure':True,'plan_exhaustion_is_not_overall_completion':True})
try:
    result=live.run_task(root,plan,session_home=PROJECT/'work/xhs-standalone-session/new-task-20261029-1710',
        ledger=PROJECT/'work/shared-acquisition-ledger/shared.sqlite3',
        source_db=PROJECT/'outputs/方隅客户资料备份/方隅客户资料_20261027_234130.sqlite3',
        target=1000000000,first_batch=1,shared_ledger=True,max_comment_pages=2,operator='current_chat_new_task')
    print(json.dumps({'status':result['status'],'inserted':result.get('inserted',0)},ensure_ascii=False),flush=True)
except Exception:
    print(json.dumps({'status':'stopped_inspect_persistent_receipts','automatic_retry':False}),flush=True)
    raise SystemExit(2)
