"""Historical drafting only: bounded reuse of existing short/combination mothers, no platform access."""
import collections, datetime as dt, hashlib, importlib.util, json, re, sqlite3, string
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
TEXT=ROOT/'work/fangyu-text-business-20261029'
OUT=Path(__file__).resolve().parent
FIRST=OUT/'frozen-6f9990c0a2438e23'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s]
def clean(s):return re.sub(r'[\s，。？！、,.!?～~：:＋+👋🙋]', '',re.sub(r'\[[^\]]*\]','',s))

def choose(own,pools):
    # Preserve the original selector; add only bounded own-text cases.
    family,fill=previous.choose(own,pools)
    if family:return family,fill
    norm=clean(own);ps=set(pools)
    # Additional historical phrasings are full-string bounded, never prefix matches.
    exact_price={'禮貌問價','價錢','價格','你好问下具体价格','啥价','你好可以问一下价格吗','你好这套价格是'}
    exact_location={'礼貌问位置','小区','地址在哪里'}
    exact_both={'您好问下小区价格位置','请问这个具体在哪多少钱','价格位子','您好具体位置在哪里价格如何','求问价格地址','滴滴位置价格','租金多少在什么区'}
    if ps=={'价格预算'} and norm in exact_price:return 'price',{}
    if ps=={'位置通勤'} and norm in exact_location:return 'location',{}
    if ps=={'价格预算','位置通勤'} and norm in exact_both:return 'price_location',{}
    if ps=={'价格预算','房源状态'} and norm in {'多少钱还在吗','多少钱一月还在吗','还在吗价钱多少'}:return 'combo_available_price',{}
    if ps=={'房源状态'} and norm in {'出租吗','d还有么','房子还在吗想租','这套房子还在吗'}:return 'available',{}
    if ps=={'看房联系'} and norm in {'可以约看房吗','可以去看房吗','看一下房','可以看吗'}:return 'combo_view',{}
    if ps=={'位置通勤','房源状态'} and norm in {'还有么在哪个区呀','哪个小区还在吗'}:return 'combo_available_location',{}
    room_prices={'一室什么价':'一室','一室一厅多少钱':'一室一厅','三室多少钱':'三室','2室价格':'2室','你好一室一厅多少钱呀':'一室一厅','一室一厅价格':'一室一厅'}
    if ps=={'价格预算','户型面积与居住方式'} and norm in room_prices:return 'combo_room_price',{'room':room_prices[norm]}
    if ps=={'价格预算','户型面积与居住方式'} and norm=='2房3房价格':return 'combo_two_rooms_price',{'room_a':'2房','room_b':'3房'}
    if ps=={'户型面积与居住方式'} and norm=='有合适的两房吗':return 'room_available',{'room':'两房'}
    if ps=={'户型面积与居住方式'} and norm in {'几房啊','多少平'}:return 'requirements',{'requirements':'几房' if norm=='几房啊' else '多少平'}
    if ps=={'入住与租期'} and norm=='想短租1到两个月':return 'duration_check',{'duration':'1到两个月'}
    if ps=={'价格预算','入住与租期'} and norm=='想问问短租一个月半左右的价格':return 'duration_price_check',{'duration':'一个月半左右'}
    if ps=={'价格预算','入住与租期'} and norm=='短租两个月可以不顺便问下价格我打招呼次数用完了':return 'duration_price_check',{'duration':'两个月'}
    if ps=={'价格预算'} and re.fullmatch(r'(?:你好|您好|宝宝)?(?:请问一下|请问|礼貌|求|问一下|问下|问问|问|询问)?(?:询价|问价|价格|租金|多少钱|多钱|什么价|什么价格|多少价格|价钱)(?:是多少|多少|多少钱)?(?:呀|啊|呢|哩|哇|吗|谢谢)*',norm):return 'price',{}
    if ps=={'位置通勤'} and re.fullmatch(r'(?:你好|您好|宝宝)?(?:请问一下|请问|求|礼貌|问)?(?:具体)?(?:位置在哪里|位置在哪|具体位置|什么位置|在哪里|在哪|那里|在那里|哪里|位置|地址|哪个小区|是哪个小区)(?:啊|呀|呢|哇|嘛|吗|谢谢)*',norm):return 'location',{}
    if ps=={'房源状态'} and re.fullmatch(r'(?:你好|您好)?(?:请问)?(?:房子)?(?:还有|还在)(?:吗|嘛|么|不|呢|呀|啊)*',norm):return 'available',{}
    if ps=={'价格预算','房源状态'} and norm in {'这套还在吗价格','什么价格还在吗','房子还在吗多少钱一个月','您好问价还在嘛'}:return 'combo_available_price',{}
    if ps=={'价格预算','位置通勤'} and norm in {'请问价格还有哪个区域','问价I和地址'}:return 'price_location',{}
    if ps=={'宠物','价格预算','位置通勤'} and norm=='能养猫吗小区和价格':return 'cat_price_location',{}
    if ps=={'房内设施'} and norm=='有房吗燃气的':return 'feature_available',{'feature':'燃气'}
    if ps=={'户型面积与居住方式'} and norm=='有合租的嘛':return 'room_available',{'room':'合租'}
    literals={
      '请问是整租还是ab套呢':('整租还是ab套',{'户型面积与居住方式'}),
    }
    if norm in literals:
        span,expected=literals[norm]
        if ps==expected and span in own:return 'requirements',{'requirements':span}
    if norm=='是市区吗' and ps=={'位置通勤'}:return 'area_check',{'place':'市区'}
    if norm=='可以短租吗' and ps=={'入住与租期'}:return 'can_check',{'action':'短租'}
    if norm=='能做饭吗' and ps=={'房内设施'}:return 'can_check',{'action':'做饭'}
    return None,{}

def main():
    global previous
    pspec=importlib.util.spec_from_file_location('previous_bounded_selector',OUT/'expand_candidates.py')
    previous=importlib.util.module_from_spec(pspec);pspec.loader.exec_module(previous)
    sourcehash={}
    def pin(path):path=path.resolve();sourcehash[str(path)]=sha(path.read_bytes());return path
    firstman=read(pin(FIRST/'manifest.json'))
    for name,digest in firstman['files'].items():assert sha((FIRST/name).read_bytes())==digest
    first=rows(pin(FIRST/'ready-drafts.jsonl'))+rows(pin(OUT/'expanded-2b7a360391a578ed/added-ready-drafts.jsonl'))
    sending=read(pin(ROOT/'work/xhs-send-current-20261029/runs/huihuijiang-newtone-remaining-20261101-01/prepared-batch.json'))['rows']
    first+=sending
    first+=rows(pin(OUT/'third-73d3f93224e0573a/added-ready-drafts.jsonl'))
    held=[r for r in rows(pin(OUT/'third-73d3f93224e0573a/remaining-held.jsonl')) if any('60_day' in x or '60_days' in x for x in r['hold_reasons']) and not any('submission' in x or 'reservation' in x for x in r['hold_reasons'])]
    assert len(held)==214
    pin(OUT/'expand_candidates.py')
    pool={r['comment_id']:r for r in rows(pin(TEXT/'high-intent-pools-20261101/all-high-intent-pools.jsonl')) if r['platform']=='xiaohongshu'}
    ptr=read(pin(TEXT/'当前双平台回复结果指针.json'));side={r['comment_id']:r for r in rows(pin(Path(ptr['platforms']['xiaohongshu']['reply_sidecar_file'])))}
    short=read(pin(TEXT/'pool-mother-review/pool-mother-short-variants.json'))['templates']
    overrides=read(pin(TEXT/'pool-mother-review/approved-mother-overrides-20261101.json'))['templates'];short.update(overrides)
    contract={'families':{k:{'template':v,'required_fill':[f for _,f,_,_ in string.Formatter().parse(v) if f]} for k,v in short.items()}}
    addon=read(pin(TEXT/'pool-mother-review/legacy-combo-families/contract-addon.json'))
    for f in ('combo_available_price','combo_view','combo_location_view','combo_available_location','combo_room_price','combo_two_rooms_price'):contract['families'][f]=addon['families'][f]
    contract['families']['cat_price_location']={'template':overrides['pet_cat'].replace('介绍有优惠。','位置发你，租金帮你问，介绍有优惠。'),'required_fill':[]}
    contract['families']['feature_available']={'template':'宝宝，我住方隅，带{feature}的空房帮你问，介绍有优惠。','required_fill':['feature']}
    contract['families']['room_available']={'template':addon['families']['combo_room_contact']['template'].replace('点我聊就行，',''),'required_fill':['room']}
    contract['families']['can_check']={'template':'宝宝，我住方隅，能不能{action}我帮你问，介绍有优惠。','required_fill':['action']}
    contract['families']['area_check']={'template':'宝宝，我住方隅，在不在{place}我帮你问，介绍有优惠。','required_fill':['place']}
    contract['families']['duration_check']={'template':'宝宝，我住方隅，{duration}的短租我帮你问，介绍有优惠。','required_fill':['duration']}
    contract['families']['duration_price_check']={'template':'宝宝，我住方隅，{duration}的短租和租金帮你问，介绍有优惠。','required_fill':['duration']}
    rendererpath=pin(TEXT/'douyin-registered-v2/increments/f98cc21138910fb9/batch_short_mothers.py')
    spec=importlib.util.spec_from_file_location('stage_two_existing_renderer',rendererpath);renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
    pin(TEXT/'rules/按池选母句与微调执行方式.json');pin(Path(__file__))
    con=sqlite3.connect((ROOT/'work/shared-acquisition-ledger/shared.sqlite3').resolve().as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
    ledger={t:list(con.execute('SELECT * FROM '+t+" WHERE platform='xiaohongshu'")) for t in ('reservations','leads','historical_deliveries','identity_aliases')}
    priorplans=[json.loads(x[0]) for x in con.execute("SELECT p.data FROM local_sender_plans p JOIN reservations r ON r.token=p.token WHERE r.platform='xiaohongshu' AND r.status IN ('reserved','unknown','sent')")];con.close()
    blocked_c=set();blocked_id=set();blocked_uid={x['plan']['customer_uid'] for x in priorplans}
    for r in ledger['reservations']:
        if r[4] in ('reserved','unknown','sent'):blocked_c.add(r[2]);blocked_id.add(r[3])
    for r in ledger['leads']:
        if r[3] in ('reserved','unknown','sent'):blocked_c.add(r[1]);blocked_id.add(r[2])
    for r in ledger['historical_deliveries']:
        if r[4]!='not_sent':blocked_c.add(r[1]);blocked_id.add(r[2])
    aliases={r[1]:r[2] for r in ledger['identity_aliases']}
    first_uids={r['customer_uid'] for r in first};selected=set();newrows=[];stamp=dt.datetime.now(dt.timezone.utc)
    appointment_notes={'仅询问能否看房，尚未明确预约时间。','尚未约定具体看房时间。','未明确线下看房或预约时间。','泛询看房，未提出具体预约时间。','未提出具体预约时间。','未明确是否约定线下看房。','约看后续结果未知','核对现有房源状态和评论对象。'}
    for prior in held:
        age_days=None
        r=dict(prior);s=side[r['comment_id']];p=pool.get(r['comment_id']);c=p.get('original_classification',{}) if p else s.get('source_record',{}).get('classification',{})
        reasons=[v for v in prior['hold_reasons'] if v not in ('no_complete_bounded_template_match','pool_template_mismatch_or_multiple_pools','unresolved_semantics_or_conditions','existing_semantic_or_fact_review_unresolved','current_60_day_hold','existing_sender_60_day_hold','comment_older_than_60_days')]
        family,fill=choose(r['original_comment'],r['demand_pools'] or [])
        reviews=c.get('needs_review') or []
        inquiry_notes={'评论为历史时点兴趣，当前需求状态未知。','核对现有房源状态和评论对象。','需核对该房源现在是否仍可租。','本人当前需求及所指房源的房态仍待核。','评论时询盘不等于当前房态。','核对当前房源状态。','确认当前是否仍在找房。'}
        inquiry_only=(family in ('price','location','price_location','available','combo_available_price','requirements','can_check','area_check','combo_available_location','combo_room_price','combo_two_rooms_price','room_available','duration_check','duration_price_check') and set(reviews)<=inquiry_notes)
        if family=='can_check' and fill=={'action':'短租'} or family in ('duration_check','duration_price_check'):
            reasons=[x for x in reasons if x!='explicit_time_or_region_requires_specific_family']
        if family=='room_available' and reviews==['合租对象、地区与租期未说明。']:inquiry_only=True
        allow_appointment=(family in ('combo_view','combo_location_view') and set(reviews)<=appointment_notes)
        if c.get('other_constraints') or c.get('possible_topics') or c.get('pending_pools') or (reviews and not allow_appointment and not inquiry_only):reasons.append('existing_semantic_or_fact_review_unresolved')
        if not family:reasons.append('no_complete_bounded_template_match')
        if r['customer_uid'] in first_uids or r['customer_uid'] in selected:reasons.append('customer_already_in_first_or_added_drafts')
        if r['customer_uid'] in blocked_uid or r['customer_id'] in blocked_c or r['customer_uid'] in blocked_c or r['comment_id'] in blocked_id or aliases.get(r['customer_uid']) in blocked_c:reasons.append('latest_ledger_prior_submission_receipt_unknown_or_reservation')
        if s['customer_uid']!=r['customer_uid'] or s['note_id']!=r['note_id'] or s['comment_text']!=r['original_comment'] or sha(s['comment_text'].encode())!=r['comment_sha256']:reasons.append('source_binding_changed')
        if p and (p['comment_text']!=r['original_comment'] or p['customer_uid']!=r['customer_uid'] or sha(dump(c).encode())!=r['classification_sha256']):reasons.append('classification_binding_changed')
        try:
            published=dt.datetime.fromisoformat(r['published_at'].replace('Z','+00:00'))
            if not published.tzinfo:reasons.append('date_unknown')
            age_days=(stamp-published).total_seconds()/86400
            if age_days<=60:reasons.append('not_in_historical_scope')
        except (TypeError,ValueError,AttributeError):reasons.append('date_unknown')
        original_policy=(s.get('reply_plan') or {}).get('contact_policy','unknown')
        if original_policy in ('no_contact','identity_restricted','manual','manual_review') or s.get('contact_boundaries') or c.get('contact_boundaries') or s.get('source_record',{}).get('blocking_reasons'):reasons.append('existing_contact_or_business_hold')
        text=None;rendered=None
        if not reasons:
            evidence=[{'field':k,'quote':v} for k,v in fill.items()]
            plan={'local_mother':{'family':family,'fill':fill,'evidence':evidence},'tone':'normal','contact_policy':original_policy}
            rendered=renderer.render_plan({'role':c['role'],'demand_state':c['demand_state'],'interest':c['interest'],'reply_plan':plan},r['original_comment'],contract)
            text=rendered['validated_plan_text'] # A draft; do not upgrade unknown contact policy.
            selected.add(r['customer_uid'])
        r.update(status='historical_draft_for_review' if text else 'held',text=text,text_sha256=sha(text.encode()) if text else None,
          family=family if text else None,hold_reasons=sorted(set(reasons)),previous_hold_reasons=prior['hold_reasons'],
          prior_package=str(OUT/'third-73d3f93224e0573a'),local_history_snapshot_at=stamp.isoformat(),stage='historical_low_priority_drafts_only',
          historical_comment_days_old=round(age_days,2) if age_days is not None else None,priority='low',current_need_confirmed=False,
          runtime_send_eligible=False,old_age_sending_enabled=False,temporal_send_hold_preserved=True,
          literal_fill=fill if text else {},source_contact_policy=original_policy,contact_policy_upgraded=False,
          semantic_review_notes_preserved=reviews,appointment_not_yet_arranged=bool(text and allow_appointment and reviews),
          review_resolution='inquiry_draft_only_all_original_fact_uncertainties_remain' if text and reviews else None,
          review_notes_not_cleared=True,derived_reusable_family=family in ('cat_price_location','feature_available','room_available','can_check','area_check','duration_check','duration_price_check'),
          template_source='existing_combo_candidate_locally_reviewed' if text and family.startswith('combo_') else 'existing_short_mother',
          actual_housing_facts_verified=False,factual_scope='cat_policy_user_confirmed_other_facts_offered_for_check' if family=='cat_price_location' and text else 'offer_to_check_not_assertion_of_inventory_price_location_or_appointment')
        newrows.append(r)
    ready=[r for r in newrows if r['text']]
    assert len(newrows)==214 and len({r['customer_uid'] for r in ready})==len(ready)
    assert not {r['customer_uid'] for r in ready}&first_uids
    for p,h in sourcehash.items():assert sha(Path(p).read_bytes())==h,p
    payload=''.join(dump(r)+'\n' for r in newrows);target=OUT/('historical-'+sha(payload.encode())[:16]);target.mkdir(exist_ok=False)
    def write(name,txt):
        with (target/name).open('x',encoding='utf-8',newline='\n') as f:f.write(txt)
    write('historical214-dispositions.jsonl',payload);write('historical-review-drafts.jsonl',''.join(dump(r)+'\n' for r in ready));write('remaining-held.jsonl',''.join(dump(r)+'\n' for r in newrows if not r['text']))
    manifest={'created_at':stamp.isoformat(),'source_hashes':sourcehash,'all_previous_batches_preserved':True,'excluded_current_send_batch_rows':len(sending),'input_historical':214,'historical_review_drafts':len(ready),'remaining_held':214-len(ready),'families':dict(collections.Counter(r['family'] for r in ready)),
      'hold_reason_counts_overlap':dict(collections.Counter(v for r in newrows for v in r['hold_reasons'])),
      'ledger_readonly_snapshot_sha256':sha(dump({'ledger':ledger,'plans':priorplans}).encode()),
      'platform_calls':0,'ledger_writes':0,'AI_reply_rewrites':0,'new_intent_classifications':0,'not_executable_send_queue':True,'old_age_sending_enabled':False,'runtime_send_eligible':False,'priority':'low','runtime_eligibility_not_certified':True,
      'files':{name:sha((target/name).read_bytes()) for name in ('historical214-dispositions.jsonl','historical-review-drafts.jsonl','remaining-held.jsonl')}}
    write('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'directory':str(target),'added':len(ready),'remaining':214-len(ready),'families':manifest['families']},ensure_ascii=False))

if __name__=='__main__':main()
