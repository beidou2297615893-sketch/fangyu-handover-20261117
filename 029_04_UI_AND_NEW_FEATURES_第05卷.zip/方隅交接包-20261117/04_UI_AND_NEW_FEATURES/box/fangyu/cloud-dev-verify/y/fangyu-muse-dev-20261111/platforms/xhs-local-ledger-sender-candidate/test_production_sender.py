import json
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'xhs-standalone-reply'))
import standalone_reply
import production_sender as sender
import httpx
import xhs_cli.client as vendor


class Client:
    def __init__(self, plan, result=None, error=None):
        self.plan = plan
        self.result = result
        self.error = error
        self.calls = 0
        self._armed = False

    def identity(self): pass
    def send_once(self):
        assert self._armed
        self.calls += 1
        if self.error: raise self.error
        return self.result


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.db = Path(self.tmp.name) / 'synthetic.sqlite3'
        subprocess.run([sys.executable, str(ROOT.parent/'shared-acquisition-ledger'/'ledger.py'), '--db', str(self.db), 'init'], check=True, capture_output=True)
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY, data TEXT NOT NULL, FOREIGN KEY(token) REFERENCES reservations(token))')
            for cid, mid in [('customer1','comment1'),('customer2','comment2')]:
                db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)', ('xiaohongshu',cid,mid,'unverified','fixture'))
            db.commit()
        self.plan = sender.SendPlan('sender','user1','note1','comment1','reply1','attempt1',True,'fixture local evidence',int(time.time())+200,'fixture source','customer1')

    def tearDown(self): self.tmp.cleanup()

    def run_plan(self, plan, client):
        return sender.Runner(self.db, client, synthetic=True).submit(plan)

    def test_success_receipt_preserves_unknown_and_allows_different_customer(self):
        client = Client(self.plan, {'comment': {'id': 'receipt1'}})
        self.assertEqual(self.run_plan(self.plan, client), 'receipt_received_unverified')
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status FROM reservations').fetchone()[0], 'unknown')
            record = json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])
            self.assertEqual(record['result']['receipt_id'], 'receipt1')
            self.assertFalse(record['platform_replies_checked'])
            self.assertFalse(record['all_accounts_history_checked'])
            self.assertEqual(db.execute('SELECT COUNT(*) FROM identity_aliases').fetchone()[0],0)
        from dataclasses import replace
        second=replace(self.plan, customer_uid='user2',canonical_customer='customer2',comment_id='comment2',attempt_id='attempt2')
        self.assertEqual(self.run_plan(second, Client(second, {'comment': {'id': 'receipt2'}})), 'receipt_received_unverified')
        with self.assertRaises(Exception): self.run_plan(self.plan, Client(self.plan))

    def test_no_receipt_and_461_block_account_after_single_post(self):
        from dataclasses import replace
        client=Client(self.plan,error=standalone_reply.Unknown('461'))
        with self.assertRaises(standalone_reply.Unknown): self.run_plan(self.plan,client)
        self.assertEqual(client.calls,1)
        second=replace(self.plan, customer_uid='user2',canonical_customer='customer2',comment_id='comment2',attempt_id='attempt2')
        with self.assertRaises(Exception): self.run_plan(second,Client(second))

    def test_mismatched_customer_identity_or_existing_delivery_refuses(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO historical_deliveries VALUES(?,?,?,?,?,?,?)',('xiaohongshu','customer1','comment1','ref','submitted','old',1))
            db.commit()
        client=Client(self.plan)
        with self.assertRaises(Exception): self.run_plan(self.plan,client)
        self.assertEqual(client.calls,0)

    def test_preserves_previous_assessment(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO assessments VALUES(?,?,?,?,?)',('xiaohongshu','customer1','comment1','original',42));db.commit()
        self.run_plan(self.plan,Client(self.plan,{'comment':{'id':'receipt'}}))
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT data,updated FROM assessments').fetchone(),('original',42))

    def test_default_path_guard_and_authorization(self):
        from dataclasses import replace
        client=Client(replace(self.plan,authorized=False))
        with self.assertRaises(Exception): self.run_plan(client.plan,client)
        self.assertEqual(client.calls,0)
        with self.assertRaises(Exception): sender.connect(Path(self.tmp.name)/'other.sqlite3',synthetic=True)

    def test_vendor_wire_461_is_recorded_and_blocks_retry(self):
        calls=[]
        def wire(req):
            calls.append(req)
            if req.method=='GET':return httpx.Response(200,json={'success':True,'data':{'user_id':'sender'}})
            return httpx.Response(461,json={'success':False})
        client=sender.OneAttemptClient({'a1':'synthetic'},self.plan,httpx.MockTransport(wire))
        try:
            with patch('socket.socket.connect',side_effect=AssertionError('network forbidden')), patch.object(vendor,'sign_main_api',return_value={}):
                with self.assertRaises(standalone_reply.Unknown):self.run_plan(self.plan,client)
                with self.assertRaises(Exception):self.run_plan(self.plan,client)
            self.assertEqual([r.method for r in calls],['GET','POST'])
            with closing(sqlite3.connect(self.db)) as db:
                result=json.loads(db.execute('SELECT data FROM local_sender_plans').fetchone()[0])['result']
            self.assertEqual(result['kind'],'unknown')
            self.assertEqual(result['http_status'],461)
            self.assertTrue(result['request_started'])
        finally:client.close()

    def test_vendor_wire_receipt_is_accepted_without_visibility_claim(self):
        calls=[]
        def wire(req):
            calls.append(req)
            if req.method=='GET':return httpx.Response(200,json={'success':True,'data':{'user_id':'sender'}})
            return httpx.Response(200,json={'success':True,'data':{'comment':{'id':'receipt'}}})
        client=sender.OneAttemptClient({'a1':'synthetic'},self.plan,httpx.MockTransport(wire))
        try:
            with patch('socket.socket.connect',side_effect=AssertionError('network forbidden')), patch.object(vendor,'sign_main_api',return_value={}):
                self.assertEqual(self.run_plan(self.plan,client),'receipt_received_unverified')
            self.assertEqual([r.method for r in calls],['GET','POST'])
            self.assertEqual(json.loads(calls[1].content),{'note_id':'note1','content':'reply1','target_comment_id':'comment1','at_users':[]})
        finally:client.close()

    def test_frozen_plan_must_match_one_prepared_record(self):
        from dataclasses import replace
        f=Path(self.tmp.name)/'batch.json'
        f.write_text(json.dumps({'schema':'gubei-46-local-plan-v1','intended_account':'蕾姆','count':1,'rows':[{'attempt_id':'attempt1','customer_id':'customer1','customer_uid':'user1','comment_id':'comment1','note_id':'note1','text':'reply1','source_identity':'local_source_consistency_only','platform_reply_history':'unknown','other_accounts_history':'unknown','send_status':'not_attempted_in_this_plan'}]}),encoding='utf-8')
        sender.validate_prepared(self.plan,f)
        with self.assertRaises(standalone_reply.Refused):sender.validate_prepared(replace(self.plan,text='other'),f)
        with self.assertRaises(standalone_reply.Refused):sender.validate_prepared(replace(self.plan,canonical_customer='other'),f)


if __name__=='__main__': unittest.main()
