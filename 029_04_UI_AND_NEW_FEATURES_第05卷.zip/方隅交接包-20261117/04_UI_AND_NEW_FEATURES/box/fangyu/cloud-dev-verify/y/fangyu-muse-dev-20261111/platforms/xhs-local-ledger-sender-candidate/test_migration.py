"""Additive shared-ledger migration tests; every DB is a synthetic fixture."""
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch
import migration_candidate as migration

ROOT=Path(__file__).resolve().parent
LEDGER=ROOT.parent/'shared-acquisition-ledger'/'ledger.py'

class MigrationTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT)
        self.db=Path(self.tmp.name)/'synthetic.sqlite3'
        p=subprocess.run([sys.executable,str(LEDGER),'--db',str(self.db),'init'],capture_output=True)
        self.assertEqual(p.returncode,0,p.stderr)
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('INSERT INTO leads(platform,customer,comment,status,source) VALUES(?,?,?,?,?)',('xiaohongshu','cust','comment','unknown','old'))
            db.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?)',('token','xiaohongshu','cust','comment','unknown','do not clear',123))
            db.execute('INSERT INTO assessments VALUES(?,?,?,?,?)',('xiaohongshu','cust','comment','{"before":true}',123))
            db.commit()
    def tearDown(self): self.tmp.cleanup()
    def tables(self):
        with closing(sqlite3.connect(self.db)) as db:
            return {n:db.execute('SELECT * FROM "'+n+'" ORDER BY 1,2').fetchall() for n, in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'local_sender_plans'")}
    def test_dry_run_is_read_only_and_does_not_create_table(self):
        before=self.db.read_bytes(); plan=migration.preview(self.db)
        self.assertEqual(plan['action'],'create')
        self.assertEqual(before,self.db.read_bytes())
        with closing(sqlite3.connect(self.db)) as db:
            self.assertIsNone(db.execute("SELECT name FROM sqlite_master WHERE name='local_sender_plans'").fetchone())
    def test_additive_idempotent_and_preserves_every_old_row(self):
        before=self.tables(); result=migration.apply(self.db, migration.CONFIRMATION)
        self.assertEqual(result['action'],'created')
        self.assertEqual(before,self.tables())
        self.assertEqual(migration.apply(self.db,migration.CONFIRMATION)['action'],'already_present')
        self.assertEqual(before,self.tables())
    def test_unconfirmed_and_non_synthetic_paths_cannot_be_applied(self):
        with self.assertRaises(migration.Refused): migration.apply(self.db,'')
        external=Path(self.tmp.name)/'other.sqlite3'; external.touch()
        with self.assertRaises(migration.Refused): migration.apply(external,migration.CONFIRMATION)
    def test_incompatible_existing_table_refuses_without_changes(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('CREATE TABLE local_sender_plans(token TEXT PRIMARY KEY, wrong TEXT)'); db.commit()
        before=self.tables()
        with self.assertRaises(migration.Refused): migration.apply(self.db,migration.CONFIRMATION)
        self.assertEqual(before,self.tables())
    def test_incompatible_old_schema_refuses_without_creating_table(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('DROP TABLE assessments'); db.commit()
        with self.assertRaises(migration.Refused): migration.apply(self.db,migration.CONFIRMATION)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertIsNone(db.execute("SELECT name FROM sqlite_master WHERE name='local_sender_plans'").fetchone())
    def test_concurrent_migrations_are_serialized_and_preserve_unknown(self):
        results=[]
        def run():
            try: results.append(migration.apply(self.db,migration.CONFIRMATION)['action'])
            except Exception as exc: results.append(type(exc).__name__)
        workers=[threading.Thread(target=run) for _ in range(4)]
        for worker in workers: worker.start()
        for worker in workers: worker.join()
        self.assertEqual(results.count('created'),1)
        self.assertEqual(results.count('already_present'),3)
        with closing(sqlite3.connect(self.db)) as db:
            self.assertEqual(db.execute('SELECT status,evidence FROM reservations').fetchone(),('unknown','do not clear'))
    def test_explicit_production_entry_rejects_wrong_path_and_confirmation(self):
        with self.assertRaises(migration.Refused): migration.apply_production(self.db,migration.CONFIRMATION)
        with patch.object(migration,'REAL_LEDGER',self.db):
            with self.assertRaises(migration.Refused): migration.apply_production(self.db,'')
            self.assertEqual(migration.apply_production(self.db,migration.CONFIRMATION)['action'],'created')
    def test_incompatible_reservation_foreign_key_is_rejected(self):
        with closing(sqlite3.connect(self.db)) as db:
            db.execute('DROP TABLE reservations')
            db.execute('CREATE TABLE reservations(token TEXT PRIMARY KEY, platform TEXT, customer TEXT, comment TEXT, status TEXT, evidence TEXT, created INTEGER)')
            db.commit()
        with self.assertRaises(migration.Refused): migration.preview(self.db)

if __name__=='__main__': unittest.main()
