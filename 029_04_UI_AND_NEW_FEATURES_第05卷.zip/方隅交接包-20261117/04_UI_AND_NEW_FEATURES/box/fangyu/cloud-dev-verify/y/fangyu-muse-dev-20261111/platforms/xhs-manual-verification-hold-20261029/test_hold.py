import unittest
from hold import wrap_response_check, wait_until_closed


class NeedsVerification(Exception):
    pass


class HoldTests(unittest.TestCase):
    def test_wait_until_owner_closes_without_timeout(self):
        class Page:
            def is_closed(self): return False
            def wait_for_event(self, name, timeout):
                self.observed = (name, timeout)
        class Frame: pass
        class Response: pass
        page, frame, response = Page(), Frame(), Response()
        frame.page, response.frame = page, frame
        wait_until_closed(response)
        self.assertEqual(page.observed, ('close', 0))

    def test_already_closed_does_not_wait(self):
        class Page:
            def is_closed(self): return True
            def wait_for_event(self, *_args, **_kwargs):
                raise AssertionError('already closed')
        class Frame: pass
        class Response: pass
        frame, response = Frame(), Response()
        frame.page, response.frame = Page(), frame
        wait_until_closed(response)

    def test_hold_while_original_browser_context_remains_active(self):
        events = []
        active = [True]
        def check(_):
            events.append('check')
            raise NeedsVerification('private challenge details')
        def wait(_):
            self.assertTrue(active[0])
            events.append('wait')
        wrapped = wrap_response_check(check, NeedsVerification, wait, events.append)
        try:
            try:
                wrapped(object())
            finally:
                active[0] = False
        except NeedsVerification:
            events.append('stopped')
        self.assertEqual(events, ['check', 'verification_required', 'wait', 'stopped'])

    def test_normal_response_returns_without_hold(self):
        events = []
        wrapped = wrap_response_check(lambda _: 'ok', NeedsVerification,
                                      lambda _: events.append('wait'), events.append)
        self.assertEqual(wrapped(object()), 'ok')
        self.assertEqual(events, [])

    def test_other_exception_does_not_hold_or_expose_message(self):
        events = []
        def check(_):
            raise RuntimeError('private response')
        wrapped = wrap_response_check(check, NeedsVerification,
                                      lambda _: events.append('wait'), events.append)
        with self.assertRaises(RuntimeError):
            wrapped(object())
        self.assertEqual(events, [])

    def test_interrupted_wait_never_retries_check(self):
        events = []
        def check(_):
            events.append('check')
            raise NeedsVerification('private')
        def wait(_):
            raise KeyboardInterrupt()
        wrapped = wrap_response_check(check, NeedsVerification, wait, events.append)
        with self.assertRaises(KeyboardInterrupt):
            wrapped(object())
        self.assertEqual(events, ['check', 'verification_required'])


if __name__ == '__main__':
    unittest.main()
