"""Explicit bounded public text jobs; original platform reader only, no model/send."""
from copy import deepcopy
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,threading,time,secrets
from reply_account_profiles import AccountProfiles,EVIDENCE,AUTOMATIC_EVIDENCE,digest

ACTIONS=frozenset(('reply_session_check','reply_public_profile_start','reply_read_status','reply_read_cancel','reply_public_profile_apply'))
JOBS='ui_reply_public_read_jobs_v1';APPLIES='ui_reply_public_read_apply_v1'
class PublicReadError(ValueError):
 status=409;mutation_committed=False
 def __init__(self,code,message,status=409):super().__init__(message);self.code=code;self.status=status

def account_binding(a):return digest({k:a.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id','auth_generation','identity_revalidation_generation')})

class PublicReadWorkflow:
 def __init__(self,backend,reader=None):self.b=backend;self.reader=reader;self.controls={}
 def _identity(self,token,data,*,local=False):
  if local:
   fn=getattr(self.b,'_analysis_local_identity',self.b._identity);user,profile=fn(token)
   store=self.b._selected_store(user,profile)
   if data.get('storeId')!=store or profile.get('can_reply') is False or user.get('disabled'):raise PublicReadError('READ_SCOPE_CHANGED','员工权限或门店已变化，请重新读取')
   return user,[user['tenant_id'],user['id'],user['username'],store,data['platform']]
  return AccountProfiles(self.b).scope(token,data)
 def _account(self,user,scope,aid):
  account=AccountProfiles(self.b).account(user,scope,aid)
  if account.get('platform')!='xiaohongshu' or not account.get('platform_uid'):raise PublicReadError('READ_ACCOUNT_UNVERIFIED','请先连接并核对所选实际账号')
  return account
 def _guard(self,job,token,data,*,allow_completed=False):
  if self.b.closed or self.controls.get(job['id'],{}).get('cancel'):raise PublicReadError('READ_CANCELLED','本次读取已停止，原操作结果保留')
  current=self.b.core.store.get(JOBS,job['id'])
  if not current or current.get('admissionId')!=job.get('admissionId') or current.get('fingerprint')!=job.get('fingerprint') or current.get('scope')!=job.get('scope') or current.get('state') not in (('running','completed') if allow_completed else ('running',)):raise PublicReadError('READ_CANCELLED','原读取操作已停止或结果已结束，不会继续请求')
  user,scope=self._identity(token,data,local=True)
  if scope!=job['scope']:raise PublicReadError('READ_SCOPE_CHANGED','员工或门店范围已变化，已停止读取')
  a=self._account(user,scope,job['accountId'])
  if account_binding(a)!=job['accountBinding']:raise PublicReadError('READ_ACCOUNT_CHANGED','实际账号身份已变化，请重新核对')
  if job['kind']=='profile':
   profiles=AccountProfiles(self.b);workspace,uid=profiles.customer(user,scope,job['customerId'])
   if uid!=job['subjectId'] or digest([(c['id'],c['sourceDigest']) for c in workspace['comments']])!=job['customerBinding']:raise PublicReadError('READ_CUSTOMER_CHANGED','原客户身份或原文范围已变化，已停止读取')
  return user
 def _put(self,row):self.b.core.store.put(JOBS,row)
 def _view(self,row):
  result={k:deepcopy(v) for k,v in row.items() if k not in ('admissionId','scope','tenant_id','accountBinding','customerBinding','fingerprint','rawResult')}
  if row.get('state')=='running' and row['id'] not in self.controls:result.update(state='unknown',message='上次读取已中断，请核对原操作结果，不会自动重复读取')
  output=row.get('rawResult') or {};result.update(deepcopy(output));result['externalActions']={'send':0,'model':0};result['canApply']=row['kind']=='profile' and row.get('state')=='completed';return result
 def _job(self,user,scope,ident):
  if not isinstance(ident,str) or not re.fullmatch('[a-f0-9]{64}',ident):raise PublicReadError('READ_JOB_INVALID','请读取原资料操作')
  row=self.b.core.store.get(JOBS,ident)
  if not row or row.get('scope')!=scope:raise PublicReadError('READ_JOB_FORBIDDEN','该读取操作不属于当前员工门店',403)
  self._account(user,scope,row['accountId'])
  if row['kind']=='profile':AccountProfiles(self.b).customer(user,scope,row['customerId'])
  return row
 def dispatch(self,action,data,token):
  with self.b.lock,getattr(self.b.core,'lock',self.b.lock):
   if not isinstance(data,dict):raise PublicReadError('READ_INPUT_INVALID','资料读取参数无效')
   fields={'reply_session_check':{'storeId','platform','accountId','requestId'},'reply_public_profile_start':{'storeId','platform','accountId','customerId','limitPosts','requestId'},'reply_read_status':{'storeId','platform','jobId'},'reply_read_cancel':{'storeId','platform','jobId'},'reply_public_profile_apply':{'storeId','platform','jobId','expectedEvidenceRevision','requestId'}}
   status_by_request=action=='reply_read_status' and set(data)=={'storeId','platform','requestId'}
   if action not in fields or (set(data)!=fields[action] and not status_by_request) or data.get('platform')!='xiaohongshu':raise PublicReadError('READ_INPUT_INVALID','请选择当前小红书账号与已有客户，不接受外部UID或任意网址')
   user,scope=self._identity(token,data)
   if action in ('reply_session_check','reply_public_profile_start'):
    if not isinstance(data['requestId'],str) or not re.fullmatch('[A-Za-z0-9_-]{1,100}',data['requestId']):raise PublicReadError('READ_INPUT_INVALID','原操作编号无效')
    ident=digest([scope,data['requestId']]);finger=digest([action,data]);saved=self.b.core.store.get(JOBS,ident)
    if saved:
     if saved.get('scope')!=scope or saved.get('fingerprint')!=finger:raise PublicReadError('READ_REQUEST_CONFLICT','原操作编号已用于另一读取请求，请先核对原操作')
     self._job(user,scope,saved['id'])
     return {'replyPublicRead':self._view(saved)}
    account=self._account(user,scope,data['accountId']);kind='profile' if action=='reply_public_profile_start' else 'session'
    row={'id':ident,'admissionId':secrets.token_hex(16),'tenant_id':scope[0],'scope':scope,'fingerprint':finger,'requestId':data['requestId'],'kind':kind,'state':'running','accountId':account['id'],'accountName':str(account.get('platform_nickname') or account.get('name') or '实际账号'),'accountBinding':account_binding(account),'createdAt':datetime.now(timezone.utc).isoformat(),'message':'正在通过该账号独立会话核对实际身份','sourceNotice':'本次核对不切换登录，不授予发送权限'}
    if kind=='profile':
     if type(data['limitPosts']) is not int or not 1<=data['limitPosts']<=5:raise PublicReadError('READ_INPUT_INVALID','近期公开作品只可读取1至5条，最多一页')
     profiles=AccountProfiles(self.b);workspace,uid=profiles.customer(user,scope,data['customerId']);e=profiles.evidence(scope,data['customerId'])
     row.update(customerId=data['customerId'],subjectId=uid,limitPosts=data['limitPosts'],customerBinding=digest([(c['id'],c['sourceDigest']) for c in workspace['comments']]),evidenceRevision=e['revision'])
    with self.b.core.store.connect() as db:
     db.execute('BEGIN IMMEDIATE')
     found=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(JOBS,ident)).fetchone()
     if found:
      prior=json.loads(found['body'])
      if prior.get('scope')!=scope or prior.get('fingerprint')!=finger:raise PublicReadError('READ_REQUEST_CONFLICT','原操作编号已用于另一读取请求')
      return {'replyPublicRead':self._view(prior)}
     fresh_user,fresh_scope=self._identity(token,data,local=True)
     if fresh_scope!=scope or account_binding(self._account(fresh_user,scope,row['accountId']))!=row['accountBinding']:raise PublicReadError('READ_ACCOUNT_CHANGED','账号范围已变化，未创建读取操作')
     db.execute('INSERT INTO records VALUES(?,?,?,?)',(JOBS,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))
    self.controls[ident]={'cancel':False};threading.Thread(target=self._run,args=(deepcopy(row),token,deepcopy(data)),daemon=True).start()
    return {'replyPublicRead':self._view(row)}
   if status_by_request:
    request=data['requestId']
    if not isinstance(request,str) or not re.fullmatch('[A-Za-z0-9_-]{1,100}',request):raise PublicReadError('READ_INPUT_INVALID','原操作编号无效')
    ident=digest([scope,request])
    if self.b.core.store.get(JOBS,ident) is None:return {'replyPublicRead':{'id':None,'requestId':request,'state':'not_found','message':'该编号尚未创建读取操作','canApply':False,'externalActions':{'send':0,'model':0}}}
    row=self._job(user,scope,ident)
   else:row=self._job(user,scope,data['jobId'])
   if action=='reply_read_status':return {'replyPublicRead':self._view(row)}
   if action=='reply_read_cancel':
    self.controls.setdefault(row['id'],{})['cancel']=True
    if row['state']=='running':self._transition(row,{'state':'cancelled','message':'已停止本次读取，不会自动继续'})
    return {'replyPublicRead':self._view(self.b.core.store.get(JOBS,row['id']))}
   return self._apply(user,scope,row,data,token)
 def _transition(self,row,updates,guard=None):
  with self.b.core.store.connect() as db:
   db.execute('BEGIN IMMEDIATE')
   found=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(JOBS,row['id'])).fetchone()
   if not found:return False
   current=json.loads(found['body'])
   if current.get('admissionId')!=row.get('admissionId') or current.get('scope')!=row.get('scope') or current.get('fingerprint')!=row.get('fingerprint') or current.get('state')!='running':return False
   if guard:guard()
   db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(JOBS,current['id'],current['tenant_id'],json.dumps({**current,**updates},ensure_ascii=False)))
   return True
 def _ensure_read_registration(self):
  from assistant.reply_read_session import ReadRegistration,register_read
  existing=getattr(self.b.core,'_reply_read_registration',None)
  if type(existing) is ReadRegistration:existing.check();return
  release=Path(__file__).resolve().parent;review=release/'reply_public_read_materials.json'
  try:
   raw=review.read_bytes();manifest=json.loads((release/'RELEASE.json').read_text('utf-8'))
   entries=[r for r in manifest['files'] if r.get('path')=='reply_public_read_materials.json']
   if manifest.get('schema')!='fangyu_native_ui_release_v1' or manifest.get('company_id')!='fangyu-apartment-client' or len(entries)!=1 or entries[0].get('size')!=len(raw) or entries[0].get('sha256','').lower()!=hashlib.sha256(raw).hexdigest():raise ValueError()
   register_read(self.b.core,self.b.project_root,json.loads(raw))
  except (OSError,ValueError,KeyError,AttributeError,TypeError):raise PublicReadError('READ_MATERIAL_UNREVIEWED','公开资料读取组件尚未完成来源核验，请更新并正常重开客户端') from None
 def _run(self,row,token,data):
  try:
   user=self._guard(row,token,data)
   if self.reader is None:
    from assistant.reply_read_session import run_registered_read
    self._ensure_read_registration()
    runtime=getattr(self.b,'platform_runtime',None)
    if runtime is None:raise PublicReadError('READ_RUNTIME_UNAVAILABLE','原平台读取后台尚未就绪，请正常重开客户端')
    result=run_registered_read(runtime,{**user,'_workbench_store_id':row['scope'][3]},row,lambda:self._guard(row,token,data))
   else:result=self.reader(user,row,lambda:self._guard(row,token,data))
   with self.b.lock,getattr(self.b.core,'lock',self.b.lock):
    self._guard(row,token,data)
    current=self.b.core.store.get(JOBS,row['id'])
    if not current or current['state']!='running':return
    if not isinstance(result,dict) or result.get('actorUid')!=(self.b.core.store.get('accounts',row['accountId']) or {}).get('platform_uid') or not isinstance(result.get('identityProofDigest'),str) or len(result['identityProofDigest'])!=64:raise PublicReadError('READ_IDENTITY_UNVERIFIED','读取结果缺少实际账号核对证据，未保存原文')
    self._transition(row,{'state':'completed','message':'独立会话身份已核对；本次未发送','rawResult':deepcopy(result)},lambda:self._guard(row,token,data))
  except Exception as error:
   with self.b.lock:
    current=self.b.core.store.get(JOBS,row['id'])
    if current and current['state']=='running':
     code=getattr(error,'code','READ_FAILED');unknown=code in ('CLI_PAGE_UNCONFIRMED','CLI_WORKER_STOPPING')
     self._transition(row,{'state':'unknown' if unknown else 'blocked','errorCode':code,'message':str(error) if isinstance(error,ValueError) else '读取未完成，原操作已保留，请核对当前账号；不会自动重复请求'})
  finally:self.controls.pop(row['id'],None)
 def _apply(self,user,scope,row,data,token):
  if row['kind']!='profile' or row['state']!='completed' or not row.get('rawResult'):raise PublicReadError('READ_APPLY_UNAVAILABLE','请先完成该客户原资料读取，未保存任何原文')
  if type(data['expectedEvidenceRevision']) is not int or not isinstance(data['requestId'],str) or not re.fullmatch('[A-Za-z0-9_-]{1,100}',data['requestId']):raise PublicReadError('READ_INPUT_INVALID','请读取当前资料版本后明确采用')
  self._guard(row,token,data,allow_completed=True)
  profiles=AccountProfiles(self.b);profiles.customer(user,scope,row['customerId']);key=profiles.key(scope,'evidence',row['customerId']);rid=digest([scope,data['requestId']]);finger=digest(data)
  output=row['rawResult'];items=[]
  for source in [output.get('profile',{}),*output.get('posts',[])]:
   if not source.get('text'):continue
   if source.get('subjectId')!=row['subjectId']:raise PublicReadError('PUBLIC_SUBJECT_UNVERIFIED','原文作者身份未核对，不能采用')
   items.append({'sourceUrl':source['sourceUrl'],'observedAt':source['observedAt'],'quote':source['text'],'subjectId':source['subjectId'],'source':'guarded_public_read','verified':True,'notice':'原通道读取的公开原文，仅按明确租房需求判断','identityProofDigest':output['identityProofDigest'],**({'identitySource':source['identitySource']} if source is output.get('profile') and source.get('identitySource') in ('response_uid','request_bound_subject') else {})})
  store=self.b.core.store
  with store.connect() as db:
   db.execute('BEGIN IMMEDIATE');self._guard(row,token,data,allow_completed=True)
   old=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(APPLIES,rid)).fetchone()
   if old:
    prior=json.loads(old['body'])
    if prior['fingerprint']!=finger:raise PublicReadError('READ_REQUEST_CONFLICT','原采用操作编号已用于不同内容')
    result=self._view(row);result.update(applied=True,evidenceRevision=prior['revision']);return {'replyPublicRead':result}
   entry=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(EVIDENCE,key)).fetchone();manual=json.loads(entry['body']) if entry else None;value=manual['value'] if manual else {'revision':0,'items':[]}
   if value['revision']!=data['expectedEvidenceRevision']:raise PublicReadError('READ_EVIDENCE_CHANGED','客户原文资料已更新，请重新读取后采用本次结果')
   revision=value['revision']+1
   def put(entity,record):db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,record['id'],scope[0],json.dumps(record,ensure_ascii=False)))
   put(EVIDENCE,{'id':key,'tenant_id':scope[0],'scope':scope,'subject':row['subjectId'],'value':{**value,'revision':revision}})
   put(AUTOMATIC_EVIDENCE,{'id':key,'tenant_id':scope[0],'scope':scope,'subject':row['subjectId'],'value':{'revision':revision,'items':items,'jobId':row['id']}})
   put(APPLIES,{'id':rid,'tenant_id':scope[0],'scope':scope,'fingerprint':finger,'revision':revision})
   row={**row,'applied':True,'evidenceRevision':revision,'applyReceipt':{'requestId':data['requestId'],'state':'accepted','evidenceRevision':revision}}
   put(JOBS,row)
  result=self._view(row);result.update(applied=True,evidenceRevision=revision);return {'replyPublicRead':result}
