"""Persistent, scoped draft jobs. The only model effect is a proposed reply.

Existing reply_save/reply_review remain the exclusive confirmation path.
This module has no reference to platform or delivery APIs.
"""
from copy import deepcopy
from contextlib import nullcontext
import hashlib
import json
import threading
import uuid
from reply_ai_provider import create_provider, validate_output, REPLY_GUARD_VERSION, STYLE_LABELS, STYLE_MODES, selected_wording_preset
from reply_context import conversation
from reply_account_profiles import AccountProfiles, ASSIGNMENTS
from resident_tone_preset import preset_snapshot
from reply_handoff import capture as capture_handoff, revalidate as revalidate_handoff, validate_reply as validate_handoff_reply, validate_preset_claims, redact_material, HandoffExpired
def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

ENTITY='ui_context_reply_jobs_v1'
PREFS='ui_context_reply_tone_v1'
ACTIONS=frozenset(('reply_ai_read','reply_ai_start','reply_ai_status','reply_ai_cancel','reply_ai_edit','reply_ai_confirm','reply_ai_reconcile'))

class ToneRevisionConflict(ValueError):
    code='REPLY_TONE_REVISION_CONFLICT'
    mutation_committed=False

class ReplyBatchNotCreated(ValueError):
    code='REPLY_AI_NOT_CREATED'
    mutation_committed=False

def effective_style(saved,mode):
    resolved=saved['tone'] if mode=='store' else mode
    return {'mode':mode,'resolvedTone':resolved,'label':STYLE_LABELS[resolved],'storeToneRevision':saved['revision']}

class Workflow:
    def __init__(self, backend, provider=None, *, local_identity=None):
        self.backend=backend;self.provider=provider;self.running=set();self.local_identity=local_identity
        if hasattr(backend.reply_workbench,'routing_context'):backend.reply_workbench.account_profiles=AccountProfiles(backend)

    def identity(self, token, data, *, local=False):
        b=self.backend
        if b.closed:raise ValueError('工作台已关闭')
        if local:
            if self.local_identity is not None:user,profile=self.local_identity(token)
            elif self.provider is not None and not hasattr(self.provider,'execute'):
                # Kept only for the established in-memory injected fixtures.
                user,profile=b._identity(token)
            else:
                user,profile=b._analysis_local_identity(token)
        else:user,profile=b._identity(token)
        store=b._selected_store(user,profile)
        if data.get('storeId')!=store or profile.get('can_reply') is False:raise ValueError('门店或回复权限已变化')
        account=b.core.store.get('accounts',data.get('accountId'))
        if not account or any(account.get(k)!=v for k,v in {
            'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':data.get('platform')}.items()):
            raise ValueError('请选择本人当前门店的平台账号')
        b.core._account_access(user,account)
        scope=[user['tenant_id'],user['id'],store,account['id'],account['platform']]
        return user,scope

    def put(self,row):
        store=self.backend.core.store
        if not hasattr(store,'connect'):
            old=store.get(ENTITY,row['id'])
            if old and (old.get('scope')!=row['scope'] or old.get('tenant_id')!=row['tenant_id']):
                raise ValueError('回复批次归属不一致，原记录保留')
            store.put(ENTITY,row);return
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE');self.write_job(db,row)

    @staticmethod
    def write_job(db,row):
        found=db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',(ENTITY,row['id'])).fetchone()
        if found:
            old=json.loads(found['body'])
            if (found['tenant_id']!=row['tenant_id'] or old.get('tenant_id')!=row['tenant_id']
                    or old.get('scope')!=row['scope'] or old.get('id')!=row['id']):
                raise ValueError('回复批次归属不一致，原记录保留')
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
            (ENTITY,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))

    def saved_tone(self,user,scope,token):
        actor,profile=self.backend._identity(token)
        if any(actor.get(k)!=user.get(k) for k in ('id','tenant_id','username','role')):
            raise ValueError('员工身份已变化，请重新读取口吻')
        saved=self.backend._tone_preferences(actor,profile,{'storeId':scope[2]},token,save=False)['preferences']
        account_profile=AccountProfiles(self.backend).profile([scope[0],scope[1],user['username'],scope[2],scope[4]],scope[3])
        preset=preset_snapshot(saved,{'tenantId':scope[0],'userId':scope[1],'storeId':scope[2],'accountId':scope[3],'platform':scope[4]})
        return {'revision':saved['revision'],'tone':saved['tone'],'toneLabel':STYLE_LABELS[saved['tone']],
            'salutation':saved['salutation'],'focus':deepcopy(saved['focus']),
            **({'stylePresetId':preset['id'],'stylePreset':preset} if preset else {}),
            'customerTemplate':saved['templates']['customer'],'identityRule':account_profile['roleFacts'] if account_profile['configured'] else '真实住户',**({'accountProfile':account_profile} if account_profile['configured'] else {})}

    def dispatch(self, action, data, token):
        b=self.backend
        if not isinstance(data,dict):raise ValueError('工作流参数无效')
        with b.lock:
            user,scope=self.identity(token,data)
            key=hashlib.sha256(json.dumps(scope).encode()).hexdigest()
            if action=='reply_ai_read':
                prefs=b.core.store.get(PREFS,key) or {}
                jobs=[r for r in b.core.store.list(ENTITY,user['tenant_id']) if r.get('scope')==scope]
                latest=max(jobs,key=lambda r:r.get('created',0),default=None)
                saved=self.saved_tone(user,scope,token);mode=prefs.get('styleMode','store')
                if mode not in ('store',*STYLE_LABELS):mode='store'
                return {'replyAI':{'tone':prefs.get('tone',''),'accountProfile':AccountProfiles(b).profile([scope[0],scope[1],user['username'],scope[2],scope[4]],scope[3]),'savedTone':saved,'styleModes':deepcopy(STYLE_MODES),
                    'effectiveStyle':effective_style(saved,mode),'job':self.public(latest,user,scope) if latest else None}}
            if action=='reply_ai_start':
                ids=data.get('customerIds');tone=data.get('tone');request=data.get('requestId')
                if set(data)-{'storeId','accountId','platform','customerIds','tone','requestId','styleMode','expectedToneRevision','reopenDraft','selectionMode','gradeBands'}:raise ReplyBatchNotCreated('回复生成参数无效，请重新读取本批口吻')
                if not isinstance(ids,list) or not 1<=len(ids)<=300 or any(not isinstance(x,str) for x in ids) or len(set(ids))!=len(ids):raise ReplyBatchNotCreated('请选择1至300位客户')
                if not isinstance(tone,str) or len(tone)>4000:raise ReplyBatchNotCreated('语气说明最多4000字')
                if not isinstance(request,str) or len(request)>100:raise ReplyBatchNotCreated('请求编号无效')
                qualified='selectionMode' in data or 'gradeBands' in data
                bands=data.get('gradeBands')
                if qualified and (data.get('selectionMode')!='qualified' or not isinstance(bands,list) or not bands or any(not isinstance(x,str) or x not in ('super_high','high','medium','low','very_low') for x in bands) or len(set(bands))!=len(bands)):
                    raise ReplyBatchNotCreated('请重新选择高、中、低意向范围；尚未创建批次')
                reopen=data.get('reopenDraft')
                if reopen is not None and (not isinstance(reopen,dict) or set(reopen)!={'customerId','leadId','expectedReplyId','expectedVersion','sourceDigest'} or len(ids)!=1 or reopen['customerId']!=ids[0] or type(reopen['expectedVersion']) is not int or reopen['expectedVersion']<1):raise ReplyBatchNotCreated('请只选择一位客户的一条原稿，并读取当前版本')
                styled='styleMode' in data or 'expectedToneRevision' in data
                mode=data.get('styleMode');revision=data.get('expectedToneRevision')
                if styled and (mode not in ('store',*STYLE_LABELS) or type(revision) is not int or revision<0):raise ReplyBatchNotCreated('请选择本批风格并读取当前门店口吻版本')
                profiles=AccountProfiles(b)
                has_assignments=any(r.get('scope',[None]*5)[3:5]==[scope[2],scope[4]] and r.get('value',{}).get('accountId') for r in b.core.store.list(ASSIGNMENTS,scope[0]))
                for customer in ids if has_assignments else []:
                    account_scope=[scope[0],scope[1],user['username'],scope[2],scope[4]]
                    profiles.customer(user,account_scope,customer)
                    assigned=profiles.assignment(account_scope,customer).get('accountId')
                    if assigned and (assigned!=scope[3] or not profiles.profile(account_scope,scope[3])['configured']):raise ReplyBatchNotCreated('该客户已有明确回复账号，请使用当前分配或先重新选择；不能降级为旧账号身份')
                routing_inputs=[AccountProfiles(b).capture(user,scope,customer) for customer in ids]
                handoff_inputs={customer:capture_handoff(b,user,scope,customer,token) for customer in ids}
                if qualified:
                    for customer in ids:self.check_qualified(user,scope,customer,handoff_inputs[customer],bands,creating=True)
                handoff_digest=lambda value:digest({k:v for k,v in value.items() if k not in ('sourceDigest','contextBindingDigest')}) if value is not None else None
                fingerprint=digest([ids,tone,mode,revision,*([routing_inputs] if any(x is not None for x in routing_inputs) else [])] if styled else [ids,tone,*([routing_inputs] if any(x is not None for x in routing_inputs) else [])])
                if any(x is not None for x in handoff_inputs.values()):fingerprint=digest([fingerprint,{k:handoff_digest(v) for k,v in handoff_inputs.items()}])
                if reopen is not None:fingerprint=digest([fingerprint,reopen])
                if qualified:fingerprint=digest([fingerprint,{'selectionMode':'qualified','gradeBands':bands}])
                ident=hashlib.sha256(json.dumps([scope,request]).encode()).hexdigest()
                existing=b.core.store.get(ENTITY,ident)
                if existing:
                    if existing.get('tenant_id')!=scope[0] or existing.get('scope')!=scope:
                        raise ReplyBatchNotCreated('原回复批次归属不一致，未创建新批次')
                    if existing.get('requestFingerprint')!=fingerprint:raise ValueError('原分析请求的范围或语气已变化，请先核对原批次')
                    return {'replyAI':self.public(existing,user,scope)}
                style=None
                if styled:
                    saved=self.saved_tone(user,scope,token)
                    if saved['revision']!=revision:raise ToneRevisionConflict('门店口吻已更新，请刷新口吻预览后重新生成；尚未创建本批草稿。')
                    style={'version':1,'savedTone':saved,'effectiveStyle':effective_style(saved,mode),'additionalTone':tone}
                if any(r.get('scope')==scope and r['id'] in self.running for r in b.core.store.list(ENTITY,user['tenant_id'])):raise ReplyBatchNotCreated('本账号已有分析批次，请先等待或停止')
                rows=[]
                for customer in ids:
                    workspace=b.reply_workbench.read(user,scope[2],customer,platform=scope[4])
                    if qualified:self.check_qualified(user,scope,customer,handoff_inputs[customer],bands,workspace,creating=True)
                    for comment in workspace['comments']:
                        if not comment['canSave'] or comment['pendingRequestId']:continue
                        draft=comment.get('draft')
                        if reopen is not None:
                            if comment['id']!=reopen['leadId']:continue
                            if not draft or draft.get('status') not in ('draft','approved') or draft['id']!=reopen['expectedReplyId'] or draft['version']!=reopen['expectedVersion'] or comment['sourceDigest']!=reopen['sourceDigest']:raise ReplyBatchNotCreated('原稿、来源或版本已变化，请重新读取；旧稿保留')
                        elif draft:continue
                        if not any(a['id']==scope[3] for a in comment['accounts']):continue
                        row={'customerId':customer,'leadId':comment['id'],'name':workspace['item']['name'],
                            'sourceDigest':comment['sourceDigest'],'context':comment['conversation'],
                            'historySources':{c['id']:c['sourceDigest'] for c in workspace['comments']},
                            'status':'pending','text':'','selected':False,'analysis':None}
                        row['routingSnapshot']=AccountProfiles(b).capture(user,scope,customer)
                        if reopen is not None:
                            if row['routingSnapshot'] is None:raise ReplyBatchNotCreated('请先设置并确认当前真实账号资料和客户分配')
                            binding=b.reply_workbench.routing_binding(user,scope[2],scope[4],comment['id'])
                            if binding and binding.get('state')!='ready':raise ReplyBatchNotCreated('原稿账号绑定结果待核对，请先核对原操作')
                            row['reopenDraft']={'draft':deepcopy(draft),'bindingDigest':digest(binding),'request':deepcopy(reopen)}
                        row['packet'],row['sourceBinding']=self.capture_packet(user,scope,row,workspace=workspace)
                        handoff=capture_handoff(b,user,scope,customer,token,row)
                        if qualified:
                            self.check_qualified(user,scope,customer,handoff,bands,creating=True)
                            row['qualifiedSelection']={'selectionMode':'qualified','gradeBands':deepcopy(bands)}
                        if handoff is not None:
                            if handoff_digest(handoff)!=handoff_digest(handoff_inputs[customer]):raise ReplyBatchNotCreated('承接偏好或客户资格已变化，请重新读取；未创建本批')
                            row['handoffSnapshot']=handoff;row['handoffDigest']=digest(handoff);row['handoffPreview']=deepcopy(handoff['policy'])
                        rows.append(row)
                if not rows:raise ReplyBatchNotCreated('没有可生成的新评论草稿；已有草稿完整保留，请在原编辑器修改')
                if len(rows)>600:raise ReplyBatchNotCreated('本批评论超过600条，请缩小选择')
                samples=b._voice_samples_dispatch('voice_samples_read',{
                    'storeId':scope[2],'accountId':scope[3],'platform':scope[4]},token)['voiceSamples']
                sample_snapshot=[deepcopy(x) for x in samples.get('items',[]) if isinstance(x.get('reference_text'),str)][-20:]
                refs=[x['reference_text'] for x in sample_snapshot]
                import time
                job={'id':ident,'tenant_id':scope[0],'scope':scope,'created':time.time(),'revision':1,
                     'state':'running','requestId':request,'requestFingerprint':fingerprint,'tone':tone,'rows':rows,'error':'','automaticSending':False,
                     'sampleCount':len(refs),'cancel':False}
                if qualified:job.update(selectionMode='qualified',gradeBands=deepcopy(bands))
                job.update(styleReferences=deepcopy(refs),sampleSnapshot=sample_snapshot,sampleDigest=digest(sample_snapshot))
                if style is not None:job.update(styleSnapshot=style,effectiveStyle=deepcopy(style['effectiveStyle']))
                self.put(job)
                b.core.store.put(PREFS,{'id':key,'tenant_id':scope[0],'scope':scope,'tone':tone,**({'styleMode':mode} if styled else {})})
                self.running.add(ident)
                threading.Thread(target=self.run,args=(ident,deepcopy(data),token,scope,refs),daemon=True).start()
                return {'replyAI':self.public(job,user,scope)}
            job=b.core.store.get(ENTITY,data.get('jobId'))
            if not job or job.get('scope')!=scope:raise ValueError('该批次不属于当前账号或门店')
            if action=='reply_ai_confirm':
                self.confirm(job,user,scope,data,token)
                return {'replyAI':self.public(self.backend.core.store.get(ENTITY,job['id']),user,scope)}
            if action=='reply_ai_reconcile':
                self.recover_generation(job,user,scope,token,data)
                job=b.core.store.get(ENTITY,job['id'])
                self.reconcile(job,user,scope,token)
                return {'replyAI':self.public(self.backend.core.store.get(ENTITY,job['id']),user,scope)}
            if action=='reply_ai_status':return {'replyAI':self.public(job,user,scope)}
            if action=='reply_ai_cancel':
                job['cancel']=True;job['revision']+=1;self.put(job)
                return {'replyAI':self.public(job,user,scope)}
            if action=='reply_ai_edit':
                if job['id'] in self.running:raise ValueError('请等待分析结束再修改')
                if data.get('revision')!=job['revision']:raise ValueError('批次已变化，请重新读取')
                edits=data.get('edits')
                if not isinstance(edits,list) or len(edits)>600:raise ValueError('修改列表无效')
                mapping={r['leadId']:r for r in job['rows']};seen=set();visible=self.visible(user,scope,job)
                for edit in edits:
                    lead=edit.get('leadId');text=edit.get('text');chosen=edit.get('selected')
                    if lead not in mapping or lead in seen or not isinstance(text,str) or len(text.strip())>1000 or type(chosen) is not bool:raise ValueError('修改内容无效')
                    seen.add(lead);row=mapping[lead]
                    if lead not in visible or digest(visible[lead])!=digest(row['context']):
                        row['selected']=False;continue
                    if row['status']!='ready' and chosen:raise ValueError('分析失败的条目不能统一确认')
                    if any(a['state'] in ('save_pending','review_pending') for a in row.get('attempts',[])) and text.strip()!=row['text']:
                        raise ValueError('请先核对这条上次确认结果，再修改正文')
                    candidate={**row,'text':text.strip()}
                    if candidate.get('handoffSnapshot') is not None or selected_wording_preset(job.get('styleSnapshot')):
                        self.checked_row(job,candidate,user,scope,token)
                    row.update(text=text.strip(),selected=chosen)
                job['revision']+=1;self.put(job)
                return {'replyAI':self.public(job,user,scope)}
        raise ValueError('未知工作流操作')

    def visible(self,user,scope,job):
        reader=getattr(self.backend.reply_workbench,'visible_sources',None)
        originals=reader(user,scope[2],scope[4]) if reader else None
        if originals is not None:
            return {r['leadId']:conversation(originals[r['leadId']],originals) for r in job['rows']
                if r['leadId'] in originals and digest(originals[r['leadId']])==r['sourceDigest']}
        # Isolated fixture projections or older adapters still cross the existing
        # customer visibility check. Never treat absence of the fast path as access.
        result={};cache={}
        for row in job['rows']:
            try:
                customer=row['customerId']
                if customer not in cache:cache[customer]=self.backend.reply_workbench.read(user,scope[2],customer,platform=scope[4])
                fresh=next((c for c in cache[customer]['comments'] if c['id']==row['leadId']),None)
                if fresh and fresh['sourceDigest']==row['sourceDigest']:result[row['leadId']]=fresh['conversation']
            except (ValueError,KeyError):continue
        return result

    def capture_packet(self,user,scope,row,*,workspace=None):
        workspace=workspace or self.backend.reply_workbench.read(user,scope[2],row['customerId'],platform=scope[4])
        comments=workspace['comments']
        members={comment['id']:comment['sourceDigest'] for comment in comments}
        if members!=row['historySources']:raise ValueError('该客户的评论集合或原话已变化，请重新读取')
        target=next((comment for comment in comments if comment['id']==row['leadId']),None)
        if (not target or target['sourceDigest']!=row['sourceDigest'] or digest(target['conversation'])!=digest(row['context'])):
            raise ValueError('目标评论及上下文已变化，请重新读取')
        history=[{'id':comment['id'],'sourceDigest':comment['sourceDigest'],'conversation':deepcopy(comment['conversation'])}
            for comment in comments]
        reader=getattr(self.backend.reply_workbench,'visible_sources',None)
        originals=reader(user,scope[2],scope[4]) if reader else None
        dependencies={}
        if originals is not None:
            for comment in comments:
                original=originals.get(comment['id'])
                if original is None or digest(original)!=comment['sourceDigest']:
                    raise ValueError('原评论的来源或权限已变化')
                dependencies[comment['id']]=digest(original)
                related={str(original.get(key) or '') for key in ('parent_id','target_comment_id')}
                related.discard('')
                for ident,source in originals.items():
                    if (source.get('platform')==original.get('platform') and original.get('note_url')
                            and source.get('note_url')==original.get('note_url') and source.get('comment_id') in related):
                        dependencies[ident]=digest(source)
        packet={'target':deepcopy(target['conversation']),
            'sameCustomerHistory':[deepcopy(item['conversation']) for item in history]}
        binding={'members':members,'history':history,'dependencies':dependencies,'packetDigest':digest(packet)}
        return packet,binding

    def checked_packet(self,user,scope,row):
        AccountProfiles(self.backend).check(user,scope,row['customerId'],row.get('routingSnapshot'))
        packet,binding=self.capture_packet(user,scope,row)
        if row.get('sourceBinding') is not None and binding!=row['sourceBinding']:
            raise ValueError('本人历史或上下文来源已变化，请重新读取')
        return packet,binding

    def execution_request(self,job,row,user,scope):
        if not row.get('sourceBinding') or 'styleReferences' not in job:
            raise ValueError('旧批次缺少完整执行快照，已有草稿保留，请读取后新建本批')
        request={'scope':{'tenant_id':scope[0],'owner':user['username'],'actor_id':scope[1],
            'store_id':scope[2],'account_id':scope[3],'platform':scope[4],
            'customer_id':row['customerId'],'lead_id':row['leadId']},
            'source_digest':row['sourceDigest'],
            'context':{'conversation':deepcopy(row['context']),
                'sameCustomerHistory':deepcopy(row['sourceBinding']['history']),
                'sourceBinding':deepcopy(row['sourceBinding'])},
            'tone_snapshot':{'style':deepcopy(job.get('styleSnapshot',job['tone'])),
                'sampleDigest':job['sampleDigest'],**({'accountProfile':deepcopy(row['routingSnapshot'])} if row.get('routingSnapshot') is not None else {})},'style_references':deepcopy(job['styleReferences']),
            'evidence_guard_version':REPLY_GUARD_VERSION,'model':'gpt-6.1-sol',
            'request_id':job['requestId']}
        if row.get('handoffSnapshot') is not None:
            request['tone_snapshot']=redact_material(request['tone_snapshot'])
            request['tone_snapshot']['firstReplyOfferSnapshot']=deepcopy(row['handoffSnapshot'])
            request['context']=redact_material(request['context'])
            request['style_references']=[redact_material(value) for value in request['style_references']]
        return request

    def check_qualified(self,user,scope,customer,snapshot,bands,workspace=None,*,creating=False):
        q=(snapshot or {}).get('qualification') or {}
        workspace=workspace or self.backend.reply_workbench.read(user,scope[2],customer,platform=scope[4])
        if (snapshot is None or q.get('aggregateState')!='current' or q.get('interestStatus')!='graded'
                or q.get('interestLevel') not in bands or q.get('regionMatch')!='match'
                or q.get('demandState') not in ('active','future') or q.get('eligibility')!='no_known_exclusion'
                or q.get('role') not in ('demand','mixed') or workspace.get('item',{}).get('contactState') in ('sent','unknown','sending')):
            error=ReplyBatchNotCreated if creating else HandoffExpired
            raise error('客户资格或联系状态已变化，请刷新范围后重新生成；原草稿保留')

    def checked_handoff(self,user,scope,row,token,db=None):
        revalidate_handoff(self.backend,user,scope,row['customerId'],token,row.get('handoffSnapshot'),row,db=db)
        if row.get('qualifiedSelection') is not None:
            self.check_qualified(user,scope,row['customerId'],row.get('handoffSnapshot'),row['qualifiedSelection']['gradeBands'])

    def provider_authorized(self,ident,row,token,data,scope,*,source=True):
        # Adapter registration already holds SQLite's write reservation. Never
        # wait on an outer UI/Core lock while holding that reservation.
        outer=self.backend.lock;core_lock=getattr(self.backend.core,'lock',outer)
        if not outer.acquire(blocking=False):return False
        acquired_core=False
        try:
            acquired_core=core_lock.acquire(blocking=False)
            if not acquired_core:return False
            actor,current=self.identity(token,data,local=True)
            job=self.backend.core.store.get(ENTITY,ident)
            if current!=scope or not job or job.get('scope')!=scope or source and job.get('cancel'):return False
            if source:
                self.checked_handoff(actor,scope,row,token)
                self.checked_packet(actor,scope,row)
            return True
        except Exception:return False
        finally:
            if acquired_core:core_lock.release()
            outer.release()

    @staticmethod
    def provider_error(error):
        if isinstance(error,HandoffExpired):return 'expired','承接设置、真实身份或当前客户资格已变化；原结果保留，未写入旧草稿'
        code=getattr(error,'code','')
        if code=='REPLY_LOCAL_CODEX_UNKNOWN':
            return 'unknown','原生成请求结果待核对，请核对原批次；不会换请求重复生成'
        if code=='REPLY_LOCAL_CODEX_PREPARATION_REQUIRED':
            return 'not_dispatched','本机 Codex 尚未准备好，请核对订阅登录与用量；未开始模型生成'
        if code=='REPLY_LOCAL_CODEX_REVIEW_REQUIRED':
            return 'review_required','原生成结果需复核，原始回执保留；不会自动重新生成'
        if isinstance(error,PermissionError):
            return 'source_changed','当前账号、门店或上下文已变化，结果保留待核对'
        return 'source_changed',str(error) if isinstance(error,ValueError) else '本条生成未完成，原请求证据保留，请核对本批'

    def commit_generation(self,ident,index,row,result,receipt,token,data,scope):
        b=self.backend;store=b.core.store
        def apply(current,db=None):
            actor,current_scope=self.identity(token,data,local=True)
            if current_scope!=scope or current.get('scope')!=scope:raise ValueError('当前账号范围已变化')
            if current.get('cancel') or b.closed:raise ValueError('本批已停止，未保存迟到生成结果')
            self.checked_handoff(actor,scope,row,token,db)
            self.checked_packet(actor,scope,row)
            validate_handoff_reply(result,row.get('handoffSnapshot'),preset=selected_wording_preset(current.get('styleSnapshot')))
            if row.get('handoffSnapshot') is None and selected_wording_preset(current.get('styleSnapshot')):
                validate_preset_claims(result,{'firstReplyOffer':{'enabled':False},'roleProfile':{}})
            fresh=b.reply_workbench.read(actor,scope[2],row['customerId'],platform=scope[4])
            target=next((item for item in fresh['comments'] if item['id']==row['leadId']),None)
            if not target or (target.get('draft')!=row['reopenDraft']['draft'] if row.get('reopenDraft') else bool(target.get('draft'))):raise ValueError('原草稿或目标已变化，原有内容保留')
            actual=current['rows'][index]
            if (actual['leadId']!=row['leadId'] or actual.get('text','')!=row.get('text','')
                    or actual.get('sourceBinding')!=row.get('sourceBinding')
                    or actual.get('executionRequest')!=row.get('executionRequest')
                    or actual.get('handoffSnapshot')!=row.get('handoffSnapshot')):
                raise ValueError('本条文字或执行快照已变化，请重新核对')
            actual.update(analysis=deepcopy(result),text=result['reply'],selected=result['shouldReply'],
                status='ready',error='',providerState='validated')
            if receipt is not None:actual['executionReceipt']=deepcopy(receipt)
            current['revision']+=1
            if db is None:self.put(current)
            else:self.write_job(db,current)
        with b.lock,getattr(b.core,'lock',b.lock):
            if hasattr(store,'connect'):
                with store.connect() as db:
                    db.execute('BEGIN IMMEDIATE')
                    found=db.execute('SELECT tenant_id,body FROM records WHERE entity=? AND id=?',(ENTITY,ident)).fetchone()
                    if not found or found['tenant_id']!=scope[0]:raise ValueError('原批次不存在或归属已变化')
                    apply(json.loads(found['body']),db)
            else:apply(store.get(ENTITY,ident))

    def recover_generation(self,job,user,scope,token,data):
        if job['id'] in self.running:return
        if self.provider is None:self.provider=create_provider(self.backend.core.store)
        if not hasattr(self.provider,'execute'):return
        for index,saved in enumerate(job['rows']):
            row=deepcopy(saved)
            if row.get('status')=='ready' or not row.get('executionRequest'):continue
            request=row['executionRequest']
            try:
                response=self.provider.execute(request,authorize=lambda:self.provider_authorized(job['id'],row,token,data,scope,source=False),existing_only=True)
                validate_output(response['output'],request)
                self.identity(token,data)
                self.commit_generation(job['id'],index,row,response['output'],response['receipt'],token,data,scope)
            except Exception as error:
                current=self.backend.core.store.get(ENTITY,job['id']);state,message=self.provider_error(error)
                current['rows'][index].update(providerState=state,error=message,status='error',selected=False)
                current['revision']+=1;self.put(current)

    @staticmethod
    def confirmation_key(job,row):
        return digest([job['scope'],job['id'],row['leadId'],row['sourceDigest'],row['context'],row['text'],*([row['routingSnapshot']] if row.get('routingSnapshot') is not None else []),*([row['handoffDigest']] if row.get('handoffDigest') else [])])

    def public(self,job,user,scope):
        visible=self.visible(user,scope,job)
        result=deepcopy(job)
        result.pop('tenant_id',None);result.pop('scope',None)
        for key in ('sampleSnapshot','styleReferences','sampleDigest'):result.pop(key,None)
        counts={'confirmed':0,'pending':0,'notStarted':0,'closed':0}
        latest_by_lead={}
        for reply in self.backend.core.store.list('replies',scope[0]):
            prior=latest_by_lead.get(reply.get('lead_id'))
            if prior is None or (reply.get('version',0),reply['id'])>(prior.get('version',0),prior['id']):latest_by_lead[reply.get('lead_id')]=reply
        for row in result['rows']:
            for internal in ('executionRequest','sourceBinding','packet','executionReceipt','handoffSnapshot','rejectedGeneration'):row.pop(internal,None)
            row.pop('historySources',None);row.pop('history',None)
            attempts=row.pop('attempts',[]);latest=attempts[-1] if attempts else None
            state=latest['state'] if latest else 'not_started'
            message=latest.get('message','') if latest else ''
            if state=='confirmed':
                validator=getattr(self.backend.reply_workbench,'confirmation_current',None)
                if latest.get('key')!=self.confirmation_key(job,row):state='not_started';message='文字已修改，请重新确认'
                elif not validator or not validator(user,scope[2],row['leadId'],latest,latest_by_lead.get(row['leadId'])):state='closed';message='原草稿或确认账号已变化，请重新核对'
            pending=state in ('save_pending','review_pending')
            row['confirmation']={'state':state,'pending':pending,'message':message}
            current=visible.get(row['leadId'])
            original=next(item for item in job['rows'] if item['leadId']==row['leadId'])
            if original.get('sourceBinding'):
                try:self.checked_packet(user,scope,original)
                except (ValueError,KeyError):current=None
            if current is None or digest(current)!=digest(row['context']):
                row.update(context=current,name='来源已变化或不在可见范围',text='',analysis=None,selected=False,status='error',error='原上下文或客户权限已变化，请重新读取并分析')
                row['confirmationKey']=''
                if state=='confirmed':row['confirmation'].update(state='closed',pending=False,message='上下文已变化，原确认只作历史记录')
            else:row['confirmationKey']=self.confirmation_key(job,row)
            state=row['confirmation']['state'];pending=row['confirmation']['pending']
            counts['confirmed' if state=='confirmed' else 'pending' if pending else 'closed' if state=='closed' else 'notStarted']+=1
        if result['state']=='running' and result['id'] not in self.running:
            result['state']='interrupted';result['error']='上次分析已中断，已生成结果保留；不会自动续跑'
        result['completed']=sum(r['status']!='pending' for r in result['rows'])
        result['total']=len(result['rows']);result['confirmationCounts']=counts
        return result

    def checked_row(self,job,row,user,scope,token=None):
        if row.get('handoffSnapshot') is not None:
            if token is None:raise HandoffExpired('请通过原会话重新核对承接候选')
            self.checked_handoff(user,scope,row,token)
            validate_handoff_reply({'reply':row.get('text','')},row['handoffSnapshot'],preset=selected_wording_preset(job.get('styleSnapshot')))
        elif selected_wording_preset(job.get('styleSnapshot')):
            validate_preset_claims({'reply':row.get('text','')},{'firstReplyOffer':{'enabled':False},'roleProfile':{}})
        if row.get('sourceBinding'):self.checked_packet(user,scope,row)
        workspace=self.backend.reply_workbench.read(user,scope[2],row['customerId'],platform=scope[4])
        fresh=next((r for r in workspace['comments'] if r['id']==row['leadId']),None)
        if not fresh or fresh['sourceDigest']!=row['sourceDigest'] or digest(fresh['conversation'])!=digest(row['context']):
            raise ValueError('原评论、直接回复对象或客户权限已变化，请重新分析')
        return fresh

    def capture(self,job,row,attempt,operation,result):
        workspace=result['replyWorkspace'];receipt=workspace.get('receipt') or {}
        state=receipt.get('state');stage=attempt[operation]
        fresh=next((r for r in workspace['comments'] if r['id']==row['leadId']),None)
        bound=receipt.get('reply');current=fresh.get('draft') if fresh else None
        if state in ('accepted','observed'):
            if (not fresh or fresh['sourceDigest']!=row['sourceDigest'] or not bound or not current
                or digest(fresh['conversation'])!=digest(row['context'])
                or any(bound.get(k)!=current.get(k) for k in ('id','version','text')) or current.get('text')!=attempt['text']):
                attempt.update(state='closed',message='原草稿版本已变化，请单独核对')
            elif operation=='save':
                stage['state']=state
                attempt.update(state='saved',draftId=current['id'],draftVersion=current['version'])
            elif fresh.get('reviewCurrent') and current.get('review_account_id')==attempt['accountId']:
                stage['state']=state;attempt.update(state='confirmed',message='已确认，未发送')
                attempt['learningStatus']=(result.get('voiceLearning') or {}).get('status','pending')
                row['selected']=False
            else:attempt.update(state='closed',message='审核版本或账号已变化，请重新核对')
        elif state in ('not_applied','rejected','changed','not_found'):
            stage['state']=state;attempt.update(state='closed',message='上次操作已核对；未完成的部分需要再次明确确认')
        else:attempt.update(message='上次操作结果待核对，后续确认已停止')
        job['revision']+=1;self.put(job)

    def legacy(self,job,row,attempt,operation,token):
        # Persist attempt and exact payload before crossing the legacy mutation.
        self.put(job)
        try:
            scope=job['scope'];expected_cancel=job.get('cancel',False)
            def guard(_db):
                actor,current=self.identity(token,{'storeId':scope[2],'accountId':scope[3],'platform':scope[4]},local=True)
                current_job=self.backend.core.store.get(ENTITY,job['id'])
                if current!=scope or not current_job or current_job.get('cancel',False)!=expected_cancel:
                    raise ValueError('本批账号或停止状态已变化，原内容保留')
                self.checked_handoff(actor,scope,row,token,_db)
                if row.get('handoffSnapshot') is not None:
                    validate_handoff_reply({'reply':attempt['text']},row['handoffSnapshot'],preset=selected_wording_preset(job.get('styleSnapshot')))
                self.checked_packet(actor,scope,row)
            scoped=getattr(self.backend.core.store,'scoped_write_guard',None)
            context=scoped(guard) if callable(scoped) and row.get('sourceBinding') else nullcontext()
            actor,_=self.identity(token,{'storeId':scope[2],'accountId':scope[3],'platform':scope[4]},local=True)
            with context, self.backend.reply_workbench.routing_context(row.get('routingSnapshot'),actor,scope,row.get('reopenDraft')) if row.get('routingSnapshot') is not None else nullcontext():
                result=self.backend._dispatch('reply_'+operation,attempt[operation]['payload'],token)
            self.capture(job,row,attempt,operation,result)
        except Exception:
            attempt['message']='上次操作结果待核对，请先核对本批；不会自动重复确认'
            job['revision']+=1;self.put(job)

    def reconcile(self,job,user,scope,token):
        for row in job['rows']:
            self.identity(token,{'storeId':scope[2],'accountId':scope[3],'platform':scope[4]})
            for attempt in row.get('attempts',[]):
                if attempt['state'] not in ('save_pending','review_pending','confirmed'):continue
                if attempt['state']=='confirmed' and attempt['key']!=self.confirmation_key(job,row):continue
                operation='save' if attempt['state']=='save_pending' else 'review'
                if operation not in attempt:continue
                try:
                    # Recheck current visibility; changed sources must reach the
                    # original check so it can classify the historical receipt.
                    self.backend.reply_workbench.read(user,scope[2],row['customerId'],platform=scope[4])
                    request=attempt[operation]['payload']
                    result=self.backend._dispatch('reply_check',{
                        'storeId':scope[2],'platform':scope[4],'customerId':row['customerId'],
                        'leadId':row['leadId'],'requestId':request['requestId']},token)
                    self.capture(job,row,attempt,operation,result)
                except Exception:
                    attempt['message']='本条暂不能核对，原操作证据保留；其他条目继续核对'
                    job['revision']+=1;self.put(job)

    def confirm(self,job,user,scope,data,token):
        if job['id'] in self.running:raise ValueError('请等待分析完成再确认')
        row=next((r for r in job['rows'] if r['leadId']==data.get('leadId')),None)
        if not row or data.get('confirmed') is not True or row['status']!='ready' or not row['text'].strip():raise ValueError('请明确确认这条回复')
        key=self.confirmation_key(job,row)
        if data.get('confirmationKey')!=key:raise ValueError('本条文字或上下文已变化，请重新核对')
        fresh=self.checked_row(job,row,user,scope,token)
        attempts=row.setdefault('attempts',[]);last=attempts[-1] if attempts else None
        if last and last['state'] in ('save_pending','review_pending'):
            raise ValueError('上次结果待核对，请先核对本批，不会自动重试')
        if last and last['state']=='confirmed' and last['key']==key:
            draft=fresh.get('draft')
            if not fresh.get('reviewCurrent') or not draft or draft['id']!=last.get('draftId') or draft['version']!=last.get('draftVersion') or draft['text']!=last['text'] or draft.get('review_account_id')!=scope[3]:
                raise ValueError('原草稿或确认状态已变化，请重新核对')
            return
        if row.get('selected') is not True:raise ValueError('本条已取消选择，请重新核对后确认')
        if last and last['state']=='saved' and last['key']==key:
            attempt=last
        else:
            if len(attempts)>=20:raise ValueError('本条确认次数过多，请到原编辑器核对')
            current=fresh.get('draft');owned=False
            if current:
                owned=any(a.get('draftId')==current['id'] and a.get('draftVersion')==current['version']
                    and a['text']==current['text'] and (a.get('save') or {}).get('state') in ('accepted','observed') for a in attempts)
                if not owned and row.get('reopenDraft'):
                    binding=self.backend.reply_workbench.routing_binding(user,scope[2],scope[4],row['leadId'])
                    owned=current==row['reopenDraft']['draft'] and digest(binding)==row['reopenDraft']['bindingDigest']
                if not owned:raise ValueError('已有草稿不属于本批，已完整保留，请在原编辑器核对')
            if not fresh.get('canSave'):raise ValueError(fresh.get('reason') or '当前草稿不可编辑')
            attempt={'id':uuid.uuid4().hex,'key':key,'text':row['text'],'sourceDigest':row['sourceDigest'],
                'accountId':scope[3],'state':'save_pending','message':''}
            payload={'storeId':scope[2],'platform':scope[4],'customerId':row['customerId'],'leadId':row['leadId'],
                'sourceDigest':row['sourceDigest'],'expectedVersion':current['version'] if current else 0,
                'expectedReplyId':current['id'] if current else '', 'text':row['text'],'requestId':uuid.uuid4().hex}
            attempt['save']={'state':'submitted','payload':payload};attempts.append(attempt)
            self.legacy(job,row,attempt,'save',token)
            if attempt['state']!='saved':return
        # The proof of ownership is a successful original save receipt, not text equality.
        self.identity(token,data)
        fresh=self.checked_row(job,row,user,scope,token);draft=fresh.get('draft')
        if not draft or draft['id']!=attempt['draftId'] or draft['version']!=attempt['draftVersion'] or draft['text']!=attempt['text'] or not fresh.get('canReview'):
            raise ValueError('本批草稿已变化，已停止确认')
        attempt['state']='review_pending'
        attempt['review']={'state':'submitted','payload':{
            'storeId':scope[2],'platform':scope[4],'customerId':row['customerId'],'leadId':row['leadId'],
            'sourceDigest':row['sourceDigest'],'expectedVersion':draft['version'],'expectedReplyId':draft['id'],
            'accountId':scope[3],'confirmed':True,'requestId':uuid.uuid4().hex}}
        self.legacy(job,row,attempt,'review',token)

    def run(self, ident, data, token, scope, refs):
        b=self.backend
        try:
            index=0
            while True:
                with b.lock:
                    job=b.core.store.get(ENTITY,ident)
                    if job['cancel'] or b.closed:job['state']='stopped';self.put(job);break
                    actor,current=self.identity(token,data)
                    if current!=scope:raise ValueError('账号范围已变化，生成停止')
                    if index>=len(job['rows']):job['state']='done';self.put(job);break
                    row=deepcopy(job['rows'][index]);tone=deepcopy(job.get('styleSnapshot',job['tone']))
                    if row.get('routingSnapshot') is not None:tone={'accountProfile':deepcopy(row['routingSnapshot']),'legacyStyle':tone}
                    if row.get('handoffSnapshot') is not None:tone={'firstReplyOfferSnapshot':deepcopy(row['handoffSnapshot']),'legacyStyle':redact_material(tone),**({'accountProfile':redact_material(row['routingSnapshot'])} if row.get('routingSnapshot') is not None else {})}
                    try:
                        self.checked_handoff(actor,scope,row,token)
                        packet,binding=self.checked_packet(actor,scope,row)
                    except (ValueError,KeyError) as error:
                        state,message=self.provider_error(error)
                        job['rows'][index].update(status='error',selected=False,providerState=state,error=message)
                        job['revision']+=1;self.put(job);index+=1;continue
                    if self.provider is None:self.provider=create_provider(b.core.store)
                    durable=hasattr(self.provider,'execute')
                    if durable:
                        request=self.execution_request(job,row,actor,scope)
                        row['executionRequest']=request
                        job['rows'][index]['executionRequest']=deepcopy(request)
                        job['rows'][index]['providerState']='submitted'
                        job['revision']+=1;self.put(job)
                try:
                    result=None
                    receipt=None
                    if durable:
                        response=self.provider.execute(request,authorize=lambda:self.provider_authorized(ident,row,token,data,scope))
                        result=response['output'];receipt=response['receipt']
                        self.check_execution_receipt(receipt,request)
                        validate_output(result,request)
                    else:
                        # Existing injected fixture functions remain supported;
                        # installed production defaults always use the journal.
                        result=self.provider(redact_material(packet) if row.get('handoffSnapshot') is not None else packet,tone,[redact_material(value) for value in job.get('styleReferences',refs)] if row.get('handoffSnapshot') is not None else job.get('styleReferences',refs))
                        validate_output(result,{})
                    with b.lock:
                        _,current=self.identity(token,data)
                        if current!=scope:raise ValueError('账号范围已变化')
                    self.commit_generation(ident,index,row,result,receipt,token,data,scope)
                except Exception as error:
                    with b.lock:
                        if row.get('handoffSnapshot') is not None:
                            try:self.checked_handoff(actor,scope,row,token)
                            except HandoffExpired as expired:error=expired
                        job=b.core.store.get(ENTITY,ident);state,message=self.provider_error(error)
                        job['rows'][index].update(status='error',selected=False,providerState=state,error=message)
                        if 'result' in locals() and isinstance(result,dict):job['rows'][index]['rejectedGeneration']={'output':deepcopy(result),'reason':state}
                        job['revision']+=1;self.put(job)
                index+=1
        except Exception:
            with b.lock:
                job=b.core.store.get(ENTITY,ident)
                job.update(state='stopped',error='身份、门店或生成环境变化，已停止；已有草稿保留')
                self.put(job)
        finally:
            self.running.discard(ident)

    def check_execution_receipt(self,receipt,request):
        if (not isinstance(receipt,dict) or receipt.get('provider')!='official_codex_reply_local'
                or receipt.get('scope')!=request['scope'] or receipt.get('model')!=request['model']
                or receipt.get('source_digest')!=request['source_digest'] or receipt.get('human_confirmed') is not False
                or not isinstance(receipt.get('receipt_sha256'),str) or len(receipt['receipt_sha256'])!=64):
            raise ValueError('本机生成回执与当前批次不一致，原结果保留')
        expected=getattr(self.provider,'_binding',None)
        if callable(expected) and receipt.get('input_digest')!=digest(expected(request)):
            raise ValueError('本机生成回执未对应完整上下文与口吻快照')
