"""Store-qualified customer intent; source-bound semantic evidence, no I/O."""
from copy import deepcopy
import hashlib,json

VERSION='gubei-customer-region-20261027-v5'
STORE_FACTS={'storeId':'fy_s_d343f3a378f48e1bab55df4f','propertyType':'apartment',
 'source':{'kind':'frozen_existing_store_material_catalog','projectRelativePath':'work/ui-native-r57/store_materials_catalog.json',
 'sha256':'5a24f56e59421f65ff6dcc770febbb543b3768ad386ff8ded89b48f979ad3334',
 'materialKey':'sh_gubei','name':'上海古北方隅服务公寓'},
 'limits':['仅公寓类型事实；不证明地址、通勤、现房、价格、房型和租户资格。']}
REVIEW_CLOCK_POLICY='freeze-request-instant-and-Asia-Shanghai-v1'
LEVELS=('super_high','high','medium','low','very_low')
STATES=('active','future','ended','historical','unknown','unrelated')
REGIONS=('match','other','unknown','conflict')
FIELDS={'status','level','demandState','representativeLeadId','evidence','reason','closedLeadIds','needsConfirmation',
 'interestStatus','interestLevel','regionMatch','storeEligibility'}
REGION_FIELDS={'state','evidence','reason','gaps'}
EVIDENCE_FIELDS={'leadId','source','quote'}
RULES='''古北客户地域适配新规则（gubei-customer-region-20261027-v5）：
1. 必须独立读同UID全部本人评论及其各自帖子/父级/时间，旧saved_ai/manual仅历史上下文，旧high不是答案。先判断本人真实求租、供给方、结束或新需求，再判断租房强度interestStatus/interestLevel；最后判断本门店地域。不可根据关键词命中替代语义。
2. regionMatch四态：match=本人明确接受古北/本门店/已核目标范围，或本人针对明确古北出租房源询租；other=当前有效需求明确在其他片区且没有接受古北，或本人拒绝古北；unknown=仅上海、无地点、范围宽或归属不明；conflict=本人有效新旧要求冲突无法消解。上海同城、检索词、IP、昵称不能作match。地名中含古北不等于真实古北片区。没有已核可达资料不推断通勤可达。
3. 问价、问哪里、泛泛蹲/看看不能仅凭帖有古北自动match；必须确认本人针对该具体出租房源的真实租住咨询。明确古北出租房源下本人询该房租金/房型/设施可match，无需在本人短句重复古北；地域证据分别引用本人询租及准确post_title/post_text/parent地理原文。root父评论与direct回复对象不同需区分；父级报价、预算、已租到、供给广告不能变成本人条件或结束。
4. 同UID时序判断最新有效需求，不能简单最新一条或永久最高。本人明确已租好/拒公寓/停止/供给方等反证不得忽略；帖子标题已租到与本人已租到不同。多区域询盘可确认存在古北有效询盘而不是把任意区域都当仅要其他区；无法明确时保留conflict/unknown及原因。
5. interestStatus/interestLevel仅表示原文所证最新相关需求的观察强度，与当前时效分开。unknown/historical甚至ended仍可保留有本人原文的graded/high；不是永久历史最高。demandState截至context.reviewAsOf判断：明确过期入住目标且无承接可unknown，不自动已租好；无统一天数清除规则。active必须真实需求，future仅low/very_low。只按明确时区冻结时间理解相对日期，不以采集日替代发表日。
6. storeEligibility独立描述角色与门店类型冲突：role demand/supply/mixed/unknown；state no_known_exclusion/excluded/needs_review。只有已知本人拒公寓rejects_apartment或纯供给supply_only可excluded，必须至少一段own原话。拒公寓保留真实租房兴趣，不得写地域other或没有需求。supply无独立本人需求为excluded+supply_only、interest unrelated。mixed仅有独立真实本人需求可no_known_exclusion，模糊needs_review；unknown role必须needs_review。缺预算/入住/租期不因此排除或needs_review；没已知冲突可no_known_exclusion（仅未发现明确冲突，不是已适合）。storeFacts只核公寓类型，没有已核价格库存，不能凭帖子报价判预算排除，也不得推年龄国籍。needsConfirmation始终true。
8. 最终status/level由后端同源确定计算，模型必须一致：interest unrelated或demand ended/unrelated→unrelated/null；其余demand unknown/historical、region非match或eligibility非no_known_exclusion→uncertain/null；其余interest graded且active/future+region match+无已知冲突→graded/interestLevel；其他uncertain/null。high仍需具体真实当前询租，super_high还需具体看房时间/预订签约。unknown不是不相关，region match不等于当前高意向。
7. customer.evidence只引用本人评论连续原文。regionMatch.evidence每段带leadId和source（own/parent/post_title/post_text），quote须为该lead对应源的连续原文<=160字。match必须同时有本人真实需求证据及地理事实证据（可同一own），other/conflict必须有本人原话；unknown保留gaps。原始材料缺失就说明，不能补媒体或地图事实。只输出schema，不联系客户。'''

def _obj(fields):return {'type':'object','properties':fields,'required':list(fields),'additionalProperties':False}
def _arr(item):return {'type':'array','items':item}
_str={'type':'string'}
_status={'type':'string','enum':['graded','uncertain','unrelated']}
_level={'type':['string','null'],'enum':[*LEVELS,None]}
REGION_SCHEMA=_obj({'state':{'type':'string','enum':list(REGIONS)},
 'evidence':_arr(_obj({'leadId':_str,'source':{'type':'string','enum':['own','parent','post_title','post_text']},'quote':_str})),
 'reason':_str,'gaps':_arr(_str)})
ELIGIBILITY_SCHEMA=_obj({'role':{'type':'string','enum':['demand','supply','mixed','unknown']},
 'state':{'type':'string','enum':['no_known_exclusion','excluded','needs_review']},
 'exclusions':_arr(_obj({'code':{'type':'string','enum':['rejects_apartment','supply_only']},
  'evidence':REGION_SCHEMA['properties']['evidence'],'reason':_str})), 'reason':_str,'gaps':_arr(_str)})
CUSTOMER_SCHEMA=_obj({'status':_status,'level':_level,'demandState':{'type':'string','enum':list(STATES)},
 'representativeLeadId':_str,'evidence':_arr(_obj({'leadId':_str,'quote':_str})),
 'reason':_str,'closedLeadIds':_arr(_str),'needsConfirmation':{'type':'boolean'},
 'interestStatus':_status,'interestLevel':_level,'regionMatch':REGION_SCHEMA,'storeEligibility':ELIGIBILITY_SCHEMA})

def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def _text(value,maximum=1000,empty=False):
 if type(value)is not str or len(value)>maximum or '\0' in value or not empty and not value.strip():raise ValueError('invalid region text')
def _list(value,maximum=100):
 if type(value)is not list or len(value)>maximum:raise ValueError('invalid region array')
def _intent(status,level):
 if status not in ('graded','uncertain','unrelated') or (status=='graded' and level not in LEVELS) or (status!='graded' and level is not None):raise ValueError('invalid region intent')

def validate_customer(value,materials):
 if type(value)is not dict or set(value)!=FIELDS:raise ValueError('invalid region customer fields')
 by_id={x['id']:x for x in materials}
 if len(by_id)!=len(materials) or not by_id:raise ValueError('invalid region members')
 _intent(value['status'],value['level']);_intent(value['interestStatus'],value['interestLevel'])
 state=value['demandState'];interest=value['interestStatus'];region=value['regionMatch']
 if (state not in STATES or value['needsConfirmation'] is not True or value['representativeLeadId'] not in by_id
  or state in ('active','future') and interest!='graded'
  or state=='future' and value['interestLevel'] not in ('low','very_low')
  or state=='unrelated' and interest!='unrelated'):raise ValueError('invalid region demand state')
 _text(value['reason'],8000);_list(value['evidence'])
 for item in value['evidence']:
  if type(item)is not dict or set(item)!={'leadId','quote'} or item['leadId'] not in by_id:raise ValueError('invalid own evidence')
  _text(item['quote'],160)
  if item['quote'] not in by_id[item['leadId']]['text']:raise ValueError('customer quote not own source')
 if (interest=='graded' or state=='ended') and not value['evidence']:raise ValueError('own interest evidence missing')
 _list(value['closedLeadIds'],5000)
 if len(set(value['closedLeadIds']))!=len(value['closedLeadIds']) or any(x not in by_id for x in value['closedLeadIds']) or value['closedLeadIds'] and not value['evidence']:raise ValueError('invalid closed demand evidence')
 if type(region)is not dict or set(region)!=REGION_FIELDS or region['state'] not in REGIONS:raise ValueError('invalid region decision')
 _text(region['reason'],2000);_list(region['gaps'],30);_list(region['evidence'],100)
 for gap in region['gaps']:_text(gap,500)
 for item in region['evidence']:
  if type(item)is not dict or set(item)!=EVIDENCE_FIELDS or item['leadId'] not in by_id:raise ValueError('invalid region evidence member')
  _text(item['quote'],160);material=by_id[item['leadId']]
  sources={'own':material.get('text'),'parent':material.get('parent_text'),
   'post_title':material.get('post',{}).get('title'),'post_text':material.get('post',{}).get('text')}
  if item['source'] not in sources or not isinstance(sources[item['source']],str) or item['quote'] not in sources[item['source']]:raise ValueError('region quote not declared source')
 if region['state'] in ('match','other','conflict') and not any(x['source']=='own' for x in region['evidence']):raise ValueError('region requires own source evidence')
 if region['state']=='unknown' and not region['gaps']:raise ValueError('unknown region requires factual gap')
 eligibility=value['storeEligibility']
 if type(eligibility)is not dict or set(eligibility)!={'role','state','exclusions','reason','gaps'}:raise ValueError('invalid store eligibility fields')
 if eligibility['role'] not in ('demand','supply','mixed','unknown') or eligibility['state'] not in ('no_known_exclusion','excluded','needs_review'):raise ValueError('invalid store eligibility state')
 _text(eligibility['reason'],2000);_list(eligibility['gaps'],30);_list(eligibility['exclusions'],10)
 for gap in eligibility['gaps']:_text(gap,500)
 codes=set()
 for exclusion in eligibility['exclusions']:
  if type(exclusion)is not dict or set(exclusion)!={'code','evidence','reason'} or exclusion['code'] not in ('rejects_apartment','supply_only') or exclusion['code'] in codes:raise ValueError('invalid store exclusion')
  codes.add(exclusion['code']);_text(exclusion['reason'],2000);_list(exclusion['evidence'])
  if not exclusion['evidence'] or not any(x.get('source')=='own' for x in exclusion['evidence'] if type(x)is dict):raise ValueError('store exclusion requires own evidence')
  for item in exclusion['evidence']:validate_source_evidence(item,by_id)
 if (eligibility['state']=='excluded')!=bool(codes):raise ValueError('store exclusion/state contradiction')
 if eligibility['role']=='unknown' and eligibility['state']!='needs_review':raise ValueError('unknown role needs review')
 if eligibility['role']=='supply' and (eligibility['state']!='excluded' or 'supply_only' not in codes or interest!='unrelated'):raise ValueError('pure supply cannot become rental demand')
 if 'supply_only' in codes and eligibility['role']!='supply':raise ValueError('supply exclusion requires supply role')
 if eligibility['role']=='mixed' and eligibility['state']=='no_known_exclusion' and (interest!='graded' or not value['evidence']):raise ValueError('mixed role requires independent own demand')
 expected=final_projection(value)
 if (value['status'],value['level'])!=(expected['status'],expected['level']):raise ValueError('final intent differs from deterministic qualification')
 if value['status']=='graded' and value['representativeLeadId'] not in {x['leadId'] for x in value['evidence']}:raise ValueError('representative lacks own evidence')

 return deepcopy(value)

def validate_source_evidence(item,by_id):
 if type(item)is not dict or set(item)!=EVIDENCE_FIELDS or item['leadId'] not in by_id:raise ValueError('invalid eligibility evidence member')
 _text(item['quote'],160);material=by_id[item['leadId']]
 sources={'own':material.get('text'),'parent':material.get('parent_text'),'post_title':material.get('post',{}).get('title'),'post_text':material.get('post',{}).get('text')}
 if item['source'] not in sources or not isinstance(sources[item['source']],str) or item['quote'] not in sources[item['source']]:raise ValueError('eligibility quote not declared source')

def final_projection(customer):
 interest=customer['interestStatus'];demand=customer['demandState']
 if interest=='unrelated' or demand in ('ended','unrelated'):return {'status':'unrelated','level':None}
 if demand in ('unknown','historical') or customer['regionMatch']['state']!='match' or customer['storeEligibility']['state']!='no_known_exclusion':return {'status':'uncertain','level':None}
 if interest=='graded' and demand in ('active','future'):return {'status':'graded','level':customer['interestLevel']}
 return {'status':'uncertain','level':None}

def validate_review_context(review_as_of,store_facts):
 from datetime import datetime
 if type(review_as_of)is not dict or set(review_as_of)!={'instant','timezone'} or review_as_of['timezone']!='Asia/Shanghai':raise ValueError('frozen review clock required')
 stamp=datetime.fromisoformat(review_as_of['instant'].replace('Z','+00:00'))
 if stamp.tzinfo is None or store_facts!=STORE_FACTS:raise ValueError('frozen clock/store facts mismatch')
 return True

def display_label(customer):
 """Priority is a business label, never a contact authorization."""
 eligibility=customer.get('storeEligibility') or {};codes={x.get('code') for x in eligibility.get('exclusions',[])}
 if customer.get('demandState')=='ended':return '需求已结束'
 if 'supply_only' in codes:return '供给信息'
 if 'rejects_apartment' in codes:return '不接受公寓'
 region=(customer.get('regionMatch') or {}).get('state')
 if region=='other' and customer.get('interestStatus')=='graded':return '地域不符'
 if region=='conflict' and customer.get('interestStatus')=='graded':return '地域要求待核对'
 if eligibility.get('state')=='needs_review':return '需求身份待核对'
 if region=='unknown' and customer.get('interestStatus')=='graded':return '地域待确认'
 if customer.get('demandState')=='historical':return '历史需求待确认'
 if customer.get('demandState')=='unknown' and customer.get('interestStatus')=='graded':return '当前需求待确认'
 return None

def breakdown(customers):
 from collections import Counter
 return {'region':dict(Counter(x['regionMatch']['state'] for x in customers)),
  'display':dict(Counter(display_label(x) or x.get('level') or x['status'] for x in customers)),
  'interest':dict(Counter(x.get('interestLevel') or x['interestStatus'] for x in customers)),
  'demandState':dict(Counter(x['demandState'] for x in customers)),
  'storeEligibility':dict(Counter(x['storeEligibility']['state'] for x in customers))}
