"""Shared current intent contract for model review and operator explanation.

The five levels and scoped Gubei policy are read from the running software's
core.intent_policy. This module does not copy or weaken those source rules.
No model, database or platform operation occurs here.
"""
from copy import deepcopy
import hashlib
import json

CONTRACT_SCHEMA = 'fangyu-unified-intent-contract-v3-qualification'
from customer_region_policy import VERSION as REGION_VERSION, RULES as REGION_RULES, STORE_FACTS, REVIEW_CLOCK_POLICY
AGGREGATION_VERSION = 'customer-evidence-continuity-20261027-v3-qualification'
AGGREGATION_RULES = '''客户归并约束：
1. 先逐评论判断，再按同一平台、同一原始UID归并；不得跨人、跨平台、跨员工或门店拼接。保留每条评论的原有出处。昵称相同不能证明是同一人。
2. 使用该客户当前可见的完整评论集合及原帖、上级评论和原始时间；不把最新评论直接当整个客户，也不永久取历史最高。普通闲聊、表情和无关新评论，不自动抹去仍有效且未被否定的真实求租证据。
3. 明确已租好、不找了、放弃或需求结束，会结束对应旧需求；有证据的新需求可重新开启。区分已经结束、过去经历、远期计划、当前有效需求和信息不足。不能仅凭旧高等级、采集日或没有新评论就认定需求一直有效；缺时间和承接关系时说明待确认。
4. 客户级等级仍严格使用现有五级门槛。超高必须有具体看房时间、明确预订该房或签合同等行动；问价、微信和泛约看不能自动超高。不得为提高客户数放宽规则。
5. 聚合依据逐段指向本人的某条原评论，quote必须是那条评论的连续原文；上下文解释放reason。代表评论必须属于当前客户，并支持当前聚合结论；结束需求引用结束证据，不能展示旧高意向原话却给出无来源的新判断。
6. 意向、需求时效、租期、门店匹配和允许联系分别处理。古北店1—12个月例外按现有古北规则执行；其他门店不能据此扩大范围。拒绝联系不抹去真实意向，但不产生主动联系授权。
7. 原文、成员、任务归属或任一AI/人工判断变化后，原客户聚合立即失效并提示重新汇总；不得默默回落为历史最高或最新一条。模型复核不是人工确认，不能伪写人工认可、房源已匹配或真实发送。'''


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def contract():
    from core.intent_policy import (POLICY_VERSION, GUBEI_STORE_ID,
        GUBEI_ANALYSIS_VERSION, GUBEI_ANALYSIS_RULES, DEFAULT_CRITERIA)
    return {'schema': CONTRACT_SCHEMA, 'policyVersion': POLICY_VERSION,
        'criteria': deepcopy(DEFAULT_CRITERIA),
        'gubei': {'storeId': GUBEI_STORE_ID, 'version': GUBEI_ANALYSIS_VERSION,
                  'rules': GUBEI_ANALYSIS_RULES},
        'aggregationVersion': AGGREGATION_VERSION, 'aggregationRules': AGGREGATION_RULES,
        'regionVersion':REGION_VERSION,'regionRules':REGION_RULES,
        'storeFacts':deepcopy(STORE_FACTS),'reviewClockPolicy':REVIEW_CLOCK_POLICY}


def contract_digest():
    return digest(contract())


def provider_rules(task):
    """Exact source used by the existing real single-comment AI request."""
    from core.intent_policy import task_analysis_rules
    return task_analysis_rules(task)


def display_contract(store_id, city=''):
    from core import intent_policy
    value = contract()
    scoped = provider_rules({'store_id': store_id, 'city': city})
    return {'version': value['policyVersion'], 'digest': contract_digest(),
        'criteria': deepcopy(value['criteria']),
        'providerRules': scoped, 'providerRulesVersion': value['gubei']['version'] if scoped else '',
        'aggregationVersion': AGGREGATION_VERSION, 'aggregationRules': AGGREGATION_RULES,
        'regionVersion':REGION_VERSION,'regionRules':REGION_RULES,
        'providerExecutionVerified': False,
        'evidenceGuardVersion':getattr(intent_policy,'EVIDENCE_GUARD_VERSION',intent_policy.POLICY_VERSION)}


def apply_display_contract(document, store_id, city=''):
    """Fill existing management-view fields from the actual request rules."""
    value = display_contract(store_id, city)
    policy = document['activePolicy']
    for row in policy.get('levels', []):
        if row.get('code') in value['criteria']:
            row['text'] = value['criteria'][row['code']]
    scoped = value['providerRules']
    clauses = [line.split('.', 1)[-1] for line in scoped.splitlines()[1:] if line.strip()]
    checks = clauses + [AGGREGATION_RULES.splitlines()[0]] + [
        line.split('. ', 1)[-1] for line in AGGREGATION_RULES.splitlines()[1:]]
    policy['checks'] = checks
    policy['sourceDigest'] = value['digest']
    policy['version'] = value['providerRulesVersion'] or value['version']
    document.update(unifiedIntentContract=value, simpleChecklist=list(checks),
        currentFiveLevels=[{'level':row['level'],'text':row['text']} for row in policy.get('levels',[])],
        currentNote='本页判断标准与本机分析使用同一规则来源；客户汇总结合该客户全部评论，原始判断和历史保留。',
        reviewStatusNote='新评论或判断变化后需要重新汇总；本页规则展示不代表云端规则已发布或模型效果已人工认可。')
    return document


def review_prompt(store_id, city='', *, task=None):
    value = contract()
    levels = '\n'.join(code + '：' + text for code, text in value['criteria'].items())
    scope = deepcopy(task) if isinstance(task, dict) else {'store_id':store_id, 'city':city}
    if scope.get('store_id') != store_id:
        raise ValueError('review task store does not match requested scope')
    scoped = provider_rules(scope) or '沿用本店已确认租期范围；古北1—12个月例外仅对实际匹配专用规则的任务生效。未说租期不能直接判为短租。'
    return '\n\n'.join(('当前严格五级标准（' + value['policyVersion'] + '）：\n' + levels,
        scoped, value['aggregationRules'], value['regionRules'],
        '本次使用请求context.reviewAsOf冻结时点与Asia/Shanghai；本店已核类型事实：'+json.dumps(value['storeFacts'],ensure_ascii=False)))
