"""Pure projection of already authorized evidence; never guesses missing content."""
def conversation(lead, visible_sources=None):
    def text(key):
        value = lead.get(key)
        return value if isinstance(value, str) else ''
    parent = text('parent_text')
    level = lead.get('comment_level')
    if level not in (1, 2):
        level = 2 if text('parent_id') else None
    fields=('content_text','content_description','post_text','content_body')
    materials={key:text(key) for key in fields if text(key).strip()}
    conflict=len(set(materials.values()))>1
    body=next(iter(materials.values()),'') if not conflict else ''
    root = {'id':text('parent_id'), 'author':text('parent_author'),
            'authorId':text('parent_author_id'), 'text':parent}
    direct_id = text('target_comment_id')
    direct_author = text('target_author_id')
    reply_to = {'id':direct_id,'authorId':direct_author,'author':'','text':'','known':False}
    # Root and direct reply target are separate platform relations. Resolve only
    # by captured IDs within the same authorized post, never by display name.
    for source in (visible_sources or {}).values():
        if source.get('platform')!=lead.get('platform'): continue
        if not lead.get('note_url') or source.get('note_url')!=lead.get('note_url'):continue
        if source.get('comment_id')==root['id'] and root['id']:
            root.update(author=str(source.get('author') or ''),authorId=str(source.get('author_id') or ''),text=str(source.get('text') or ''))
        if direct_id and source.get('comment_id')==direct_id:
            if direct_author and source.get('author_id')!=direct_author:continue
            reply_to.update(author=str(source.get('author') or ''),authorId=str(source.get('author_id') or direct_author),text=str(source.get('text') or ''),known=bool(source.get('text')))
    if direct_id and direct_id==root['id'] and root['text']:
        if not direct_author or not root['authorId'] or direct_author==root['authorId']:
            reply_to.update(author=root['author'],text=root['text'],authorId=direct_author or root['authorId'],known=True)
    missing = []
    if conflict:missing.append('帖子正文多个来源内容冲突，未拼接或选择其一')
    if any(lead.get(key) is not None and not isinstance(lead.get(key),str) for key in fields):
        missing.append('帖子正文材料类型异常')
    if not body: missing.append('帖子正文未采集')
    if not text('content_title'): missing.append('帖子标题未采集')
    if level is None: missing.append('评论层级未确认')
    if level == 2 and not parent: missing.append('被回复的评论正文缺失')
    if level == 2 and not reply_to['known']: missing.append('直接回复对象及其正文尚未核实；楼层根评论不等于直接对象')
    # Captured video markers are evidence of media, not a transcript.
    if any(mark in parent + body for mark in ('[视频]', '[图片]')):
        missing.append('图片或视频内容尚未解析')
    post={'title':text('content_title'),'author':text('content_author'),'authorId':text('content_author_id'),'text':body}
    if materials:
        post['materialSource']='conflict' if conflict else next(iter(materials))
        if conflict:post['conflictingMaterials']=materials
    return {'level': level, 'label': {1:'一级评论 · 回应帖子', 2:'二级回复 · 回应评论'}.get(level,'层级待核实'),
            'post':post,
            'parent':root,'root':root,'replyTo':reply_to,
            'target': {'id':text('comment_id'),'authorId':text('author_id'),'author':text('author'), 'text':text('text'), 'publishedAt':text('published_at')},
            'missing':missing, 'coverage':'已采集上下文；未采集的正文、媒体或其他楼层不作推断'}
