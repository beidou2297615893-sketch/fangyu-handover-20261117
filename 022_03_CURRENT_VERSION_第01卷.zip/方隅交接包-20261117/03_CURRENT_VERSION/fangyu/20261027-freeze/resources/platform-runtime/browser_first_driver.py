"""Authorized neutral-browser I/O and one-use handoff into the original account validator."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,os,re,stat,subprocess,sys,threading,time
from uuid import uuid4
INTENTS='workbench_browser_intents_v1'
HELPER_SHA='af6d1082f87cc39c2b8865a24f32d9b3b76689fae9e3a446d723890310caa836'
class Driver:
 def __init__(self,runtime,gateway,errors,digest):self.r=runtime;self.gateway=gateway;self.Error=errors;self.digest=digest
 def supported(self):
  r=self.r.server.company.get('runtime') or {}
  return r.get('xiaohongshu_read_transport')=='guarded_cli_v1' and self.r.core.adapters.xhs_page_runtime is None and 'xiaohongshu' in self.r.server.company.get('platforms',[])
 def scope(self,user):
  return dict(tenant=user['tenant_id'],actor=user['id'],username=user['username'],store=user.get('_workbench_store_id',''),platform='xiaohongshu',device=(self.r.service.device or {}).get('id',''))
 def fresh_guard(self,ctx):
  user,profile=self.gateway._identity(ctx['token']);store=self.gateway._selected_store(user,profile)
  ctx['authorityProfile']=profile;ctx['authorityUser']={**user,'_workbench_store_id':store}
  return self._actor_guard(ctx)
 def _actor_guard(self,ctx):
  if self.r.closed or not self.supported():raise self.Error('BROWSER_UNSUPPORTED')
  user=self.r.core.session(ctx['token']);profile=ctx.get('authorityProfile')
  if not user or profile is None:raise self.Error('BROWSER_SCOPE_CHANGED')
  store=self.gateway._load_selection(user,self.gateway._stores(profile))['storeId']
  user={**user,'_workbench_store_id':store};user=self.r._principal(user)
  self.r._executor(user,read_purpose='xiaohongshu_guarded_read')
  if self.scope(user)!=ctx['scope'] or not store:raise self.Error('BROWSER_SCOPE_CHANGED')
  if ctx.get('isCurrent') is not None and not ctx['isCurrent']():raise self.Error('BROWSER_SCOPE_CHANGED')
  if ctx.get('root'):self._neutral(ctx)
  return user
 def guard(self,ctx):
  user=self._actor_guard(ctx)
  if not self.alive(ctx) or (ctx['stage']/'cancel.flag').exists():raise self.Error('BROWSER_SCOPE_CHANGED')
  return user
 def load_intent(self,ident):return self.r.core.store.get(INTENTS,ident)
 def save_intent(self,row):self.r.core.store.put(INTENTS,dict(row))
 def _plain(self,path,file=False):
  path=Path(path).absolute()
  for part in (path,*path.parents):
   if part.exists():
    info=part.lstat()
    if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise self.Error('BROWSER_SCOPE_CHANGED')
  if file:
   info=path.stat()
   if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise self.Error('BROWSER_SCOPE_CHANGED')
  return path
 def _neutral(self,ctx):
  scope=ctx['scope'];root=self.r.data_dir/'browser-sessions'/scope['tenant']/self.digest(scope)
  if ctx.get('root')!=root or ctx.get('stage')!=root/'work/browser-login'/ctx['id'][:24]:raise self.Error('BROWSER_SCOPE_CHANGED')
  self._plain(root);self._plain(ctx['stage']);return root,ctx['stage']
 def open(self,ctx):
  self.fresh_guard(ctx);root=self.r.data_dir/'browser-sessions'/ctx['scope']['tenant']/self.digest(ctx['scope']);stage=root/'work/browser-login'/ctx['id'][:24]
  ctx.update(root=root,stage=stage);self._neutral(ctx);stage.mkdir(parents=True,exist_ok=False)
  spec=stage/'session.json';raw=json.dumps({'version':1,'id':ctx['id'],'revision':ctx['revision'],'scopeHash':self.digest(ctx['scope'])},separators=(',',':')).encode('ascii')
  with spec.open('xb') as stream:stream.write(raw)
  spec.chmod(0o600)
  helper=Path(__file__).parent/'vendor-src/assistant/browser_first_window.py';self._plain(helper,True)
  if hashlib.sha256(helper.read_bytes()).hexdigest()!=HELPER_SHA:raise self.Error('BROWSER_CHECK_FAILED')
  argv=[sys.executable,'-B',str(helper),'--session-root',str(root),'--stage',str(stage),'--spec-sha',hashlib.sha256(raw).hexdigest()]
  self._actor_guard(ctx);ctx['process']=subprocess.Popen(argv,shell=False,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,cwd=str(self.r.project/'work/ui-runtime-r55/src'),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),env={**os.environ,'FANGYU_LOGIN_SOURCE_ROOT':str(self.r.project/'work/ui-runtime-r55/src')})
  ctx['windowOpen']=True
 def alive(self,ctx):return ctx.get('process') is not None and ctx['process'].poll() is None
 def focus(self,ctx):
  user=self.guard(ctx);_,stage=self._neutral(ctx)
  account=ctx.get('account')
  if account and ctx.get('taskId') and ctx.get('taskAccountId')==account['id']:
   context=self.verification_context(ctx,account)
   if context:
    from core.xhs_verified_resume import receipt_folder
    task=self.r._task(user,ctx['taskId']);directory=self.r.data_dir/'accounts'/user['tenant_id']/account['id']
    path=receipt_folder(directory,task['id'],self.r._source_receipt_partition(task))/(context['page']+'.json')
    self._plain(path,True);raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=context['receipt_sha256']:raise self.Error('BROWSER_SCOPE_CHANGED')
    reason='authentication_required' if json.loads(json.loads(raw)['result']['stdout'])['error']['code']=='not_authenticated' else 'verification_required'
    target='https://www.xiaohongshu.com/explore';pipeline=task.get('pipeline') or {};notes=pipeline.get('notes');index=pipeline.get('note_index')
    if reason=='verification_required' and type(notes) is list and type(index) is int and 0<=index<len(notes):
     from assistant.xhs_cli_page_worker import validate_args
     from urllib.parse import urlsplit
     value=notes[index].get('url') if type(notes[index]) is dict else None
     try:
      validate_args(['comments',value,'--json']);parsed=urlsplit(value)
      if parsed.hostname=='www.xiaohongshu.com' and parsed.path.startswith('/explore/'):target=value
     except (TypeError,ValueError):pass
    request=stage/'verification-watch.json';self._plain(request)
    temporary=stage/('verification-watch-'+uuid4().hex+'.tmp')
    try:
     with temporary.open('x',encoding='utf8') as stream:json.dump(dict(version=1,request=uuid4().hex,reason=reason,url=target),stream)
     self.guard(ctx)
     if self.verification_context(ctx,account)!=context:raise self.Error('BROWSER_SCOPE_CHANGED')
     os.replace(temporary,request)
    finally:temporary.unlink(missing_ok=True)
  self._signal(stage,'focus.flag')
 def _signal(self,stage,name):
  path=self._plain(stage/name)
  try:
   fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600);os.close(fd)
  except FileExistsError:self._plain(path,True)
 def capture(self,ctx):
  self.guard(ctx);root,stage=self._neutral(ctx)
  if not self.alive(ctx):raise self.Error('BROWSER_LOGIN_REQUIRED')
  previous={p.name for p in stage.glob('candidate-*.ready.json')};self._signal(stage,'capture.flag');deadline=time.monotonic()+14
  from assistant.xhs_browser_login import _candidate
  while time.monotonic()<deadline:
   self.guard(ctx)
   if not self.alive(ctx):raise self.Error('BROWSER_LOGIN_REQUIRED')
   markers=[p for p in stage.glob('candidate-*.ready.json') if p.name not in previous]
   if len(markers)>1:raise self.Error('BROWSER_SCOPE_CHANGED')
   if markers:
    selected=_candidate(stage,markers[0])
    if selected is None:raise self.Error('BROWSER_CHECK_FAILED')
    attempt,candidate,cookie=selected;self._plain(cookie,True);raw=cookie.read_bytes()
    if len(raw)>34816:raise self.Error('BROWSER_CHECK_FAILED')
    return dict(context=ctx['id'],revision=ctx['revision'],scopeHash=self.digest(ctx['scope']),attempt=attempt,root=candidate,cookie=cookie,marker=markers[0],sha=hashlib.sha256(raw).hexdigest())
   self.r.service.stop_event.wait(.05)
  raise self.Error('BROWSER_LOGIN_REQUIRED')
 def _candidate(self,ctx,value):
  self.guard(ctx);root,stage=self._neutral(ctx)
  if (value.get('context')!=ctx['id'] or value.get('revision')!=ctx['revision'] or value.get('scopeHash')!=self.digest(ctx['scope'])
      or type(value.get('attempt')) is not int or not 1<=value['attempt']<=999999
      or value.get('root')!=stage/('attempt-%06d'%value['attempt']) or value.get('cookie')!=value['root']/'.xiaohongshu-cli/cookies.json'):
   raise self.Error('BROWSER_SCOPE_CHANGED')
  path=self._plain(value['cookie'],True);raw=path.read_bytes()
  if len(raw)>34816 or hashlib.sha256(raw).hexdigest()!=value['sha']:raise self.Error('BROWSER_IDENTITY_CHANGED')
  return raw
 def discover(self,ctx,candidate):
  self.fresh_guard(ctx);self._candidate(ctx,candidate);root,_=self._neutral(ctx)
  value=self.r.core.adapters.execute('xiaohongshu',['status','--json'],root,timeout=35,candidate_home=candidate['root'])
  self.guard(ctx);outer=value if isinstance(value,dict) else {};data=outer.get('data',outer);data=data if isinstance(data,dict) else {};user=data.get('user') if isinstance(data.get('user'),dict) else {}
  uid=user.get('id') or user.get('user_id') or user.get('red_id');nickname=user.get('nickname') or user.get('nick_name')
  if (outer.get('ok',True) is not True or data.get('authenticated') is not True or user.get('guest') is True
      or not isinstance(uid,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',uid)
      or 'guest' in user and type(user['guest']) is not bool
      or not isinstance(nickname,str) or not nickname.strip() or nickname.strip()=='Unknown' or len(nickname)>100 or any(ord(c)<32 for c in nickname)):return None
  return {'uid':uid,'nickname':nickname.strip()}
 def resolve(self,ctx,identity,intent):
  user=self.fresh_guard(ctx);uid=identity['uid'];uid_hash=self.digest(uid)
  if intent.get('uidHash')!=uid_hash:raise self.Error('BROWSER_IDENTITY_CHANGED')
  with self.r.core.lock:
   self.guard(ctx)
   matches=[a for a in self.r.core.store.list('accounts',user['tenant_id']) if a.get('platform')=='xiaohongshu' and a.get('platform_uid')==uid]
   if len(matches)>1:raise self.Error('BROWSER_IDENTITY_CONFLICT')
   if matches:
    try:account=self.r._account(user,matches[0]['id'])
    except Exception:raise self.Error('BROWSER_ACCOUNT_FORBIDDEN') from None
    if account.get('store_id')!=ctx['scope']['store'] or account.get('cloud_owner')!=user['username']:raise self.Error('BROWSER_ACCOUNT_FORBIDDEN')
   elif intent.get('accountId'):
    account=self.r._account(user,intent['accountId'])
    if account.get('platform_uid') and account['platform_uid']!=uid:raise self.Error('BROWSER_IDENTITY_CHANGED')
   else:
    creation=self.digest(['browser-account-create',self.digest(ctx['scope']),uid_hash])
    proof=dict(intentId=creation,scopeHash=self.digest(ctx['scope']),uidHash=uid_hash,actorId=user['id'],tenantId=user['tenant_id'],storeId=ctx['scope']['store'])
    reservation=self.r.core.store.get('workbench_browser_creations_v1',creation)
    marked=[a for a in self.r.core.store.list('accounts',user['tenant_id']) if a.get('_browser_first_creation')==proof]
    if len(marked)>1:raise self.Error('BROWSER_IDENTITY_CONFLICT')
    if marked:ident=marked[0]['id']
    elif reservation and reservation.get('state')!='denied':
     error=self.Error('BROWSER_RESULT_UNCONFIRMED');error.mutation_committed=None;raise error
    else:
     from core.entitlements import check_account_limit,EntitlementError
     try:check_account_limit(self.r.core._policy(),self.r.core.store.list('accounts',user['tenant_id']))
     except EntitlementError:raise self.Error('BROWSER_ACCOUNT_LIMIT') from None
     self.r.core.store.put('workbench_browser_creations_v1',{'id':creation,'tenant_id':user['tenant_id'],**proof,'state':'creating'})
     def authorize():
      try:return self.guard(ctx)['id']==proof['actorId']
      except Exception:return False
     frame=None
     try:
      with self.r.core._browser_account_creation(proof,authorize) as frame:
       result=self.r.create_account(self.guard(ctx),{'platform':'xiaohongshu','name':identity['nickname']});ident=result['result']['accountId']
     except Exception as original:
      recovered=[a for a in self.r.core.store.list('accounts',user['tenant_id']) if a.get('_browser_first_creation')==proof]
      if len(recovered)!=1:
       if frame is not None and frame.get('writeStarted') is False:
        self.r.core.store.put('workbench_browser_creations_v1',{'id':creation,'tenant_id':user['tenant_id'],**proof,'state':'denied'})
        raise original
       error=self.Error('BROWSER_RESULT_UNCONFIRMED');error.mutation_committed=None;raise error from None
      ident=recovered[0]['id']
    self.r.core.store.put('workbench_browser_creations_v1',{'id':creation,'tenant_id':user['tenant_id'],**proof,'state':'created','accountId':ident})
    intent['accountId']=ident;self.save_intent(intent);account=self.r._account(self.guard(ctx),ident)
   if account.get('disabled') or account.get('status') in ('disabled','revoked','session_recovery_required'):raise self.Error('BROWSER_ACCOUNT_FORBIDDEN')
   intent['accountId']=account['id'];self.save_intent(intent)
   return account
 def admit(self,ctx,account,data):
  user=self.guard(ctx)
  with self.r._run_lock:
   if any(t.is_alive() for t in self.r._runs.values()) or self.r.core.running or self.r.core.sequences:raise self.Error('BROWSER_BUSY')
  head=self.gateway.browser_start_receipt(user,None)
  if head and head.get('state') in ('submitted','unconfirmed'):raise self.Error('BROWSER_RESULT_UNCONFIRMED')
 def verification_context(self,ctx,account):
  if not ctx.get('taskId'):return None
  user=self.guard(ctx);task=self.r._task(user,ctx['taskId'])
  if task.get('account_id')!=account['id']:raise self.Error('BROWSER_IDENTITY_CHANGED')
  category=(self.r._collection_platform_error(task) or {}).get('category')
  if category not in ('verification_required','authentication_required'):return None
  if self.r._source_receipt_partition(task) is not None:raise self.Error('BROWSER_SOURCE_RECOVERY_UNSUPPORTED')
  from core.xhs_verified_resume import failed_page
  root=self.r.data_dir/'accounts'/user['tenant_id']/account['id']
  result=failed_page(root,task['id'],self.r._verified_scope(user,task,account),partition=self.r._source_receipt_partition(task))
  if result is None:raise self.Error('BROWSER_CHECK_FAILED')
  return result
 def commit(self,ctx,candidate,account,verified=None):
  self.fresh_guard(ctx);raw=self._candidate(ctx,candidate);user=self.guard(ctx);directory=self.r.data_dir/'accounts'/user['tenant_id']/account['id']
  self._plain(directory);stage=directory/'work/browser-login'/uuid4().hex[:24];self._plain(stage);stage.mkdir(parents=True,exist_ok=False)
  root=stage/'attempt-000001';cookie=root/'.xiaohongshu-cli/cookies.json'
  try:
   cookie.parent.mkdir(parents=True)
   fd=os.open(cookie,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
   with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
   if hashlib.sha256(cookie.read_bytes()).hexdigest()!=candidate['sha']:raise self.Error('BROWSER_IDENTITY_CHANGED')
   from assistant.xhs_browser_login import validate_browser_candidate
   from assistant.browser_session_commit import account_revision
   revision=account_revision(account)
   job={'id':stage.name,'kind':'browser_first_commit','purpose':'current_browser_handoff','owner_id':user['id'],'tenant_id':user['tenant_id'],'account_id':account['id'],'status':'running','process':ctx['process']}
   def authorize():
    actor=self.guard(ctx);fresh=self.r._account(actor,account['id']);self._candidate(ctx,candidate)
    if (account_revision(fresh)!=revision or fresh.get('store_id')!=ctx['scope']['store'] or fresh.get('cloud_owner')!=actor['username']):raise self.Error('BROWSER_SCOPE_CHANGED')
    if verified is not None:
     task=self.r._task(actor,ctx['taskId'])
     if task.get('account_id')!=account['id'] or self.verification_context(ctx,fresh)!=verified:raise self.Error('BROWSER_SCOPE_CHANGED')
   outcome,_=validate_browser_candidate(self.r.service,user,account,directory,stage,job,ctx['process'],lambda:(1,root,cookie),verified_resume=verified,authorize=authorize)
   if outcome.state!='completed':
    code={'identity_mismatch':'BROWSER_IDENTITY_CHANGED','duplicate_identity':'BROWSER_IDENTITY_CONFLICT',
     'cloud_claim_failed':'BROWSER_CLOUD_CLAIM_FAILED','timeout':'BROWSER_TIMEOUT',
     'identity_unverified':'BROWSER_LOGIN_REQUIRED','access_revoked':'BROWSER_ACCOUNT_FORBIDDEN',
     'account_changed':'BROWSER_SCOPE_CHANGED','cloud_paused':'BROWSER_DEVICE_NOT_READY',
     'safety_paused':'BROWSER_DEVICE_NOT_READY'}.get(outcome.code,'BROWSER_COMMIT_FAILED')
    raise self.Error(code)
   candidate['committed']=True
  finally:
   self._plain(cookie);cookie.unlink(missing_ok=True)
   try:cookie.parent.rmdir();root.rmdir();stage.rmdir()
   except OSError:pass
 def start(self,ctx,account,data):
  self.fresh_guard(ctx);self.guard(ctx);payload={k:v for k,v in data.items() if k not in ('contextId','revision')};payload['accountId']=account['id']
  result=self.gateway._platform_dispatch('acquisition_start',payload,ctx['token']);return result['job']['taskId']
 def resume(self,ctx,task_id):
  self.fresh_guard(ctx);user=self.guard(ctx);result=self.r.resume_acquisition(user,{'taskId':task_id});return result['result']['taskId']
 def task_view(self,ctx,task_id):return self.r.snapshot(ctx['user'],platform='xiaohongshu',task_id=task_id,include_browser=False)['acquisition']
 def receipt(self,ctx,request_id):return self.gateway.browser_start_receipt(ctx['user'],request_id)
 def discard(self,ctx,candidate):
  if not candidate or candidate.get('discarded'):return
  try:
   _,stage=self._neutral(ctx)
   if (candidate.get('context')!=ctx['id'] or candidate.get('root')!=stage/('attempt-%06d'%candidate['attempt'])
       or candidate.get('cookie')!=candidate['root']/'.xiaohongshu-cli/cookies.json'):return
   self._plain(candidate['cookie'],True);self._plain(candidate['marker'],True)
   from assistant.xhs_browser_login import _ack
   candidate['cookie'].unlink(missing_ok=True);candidate['marker'].unlink(missing_ok=True);_ack(ctx['stage'],candidate['attempt'],'completed' if candidate.get('committed') else 'failed')
   candidate['discarded']=True
   try:candidate['cookie'].parent.rmdir();candidate['root'].rmdir()
   except OSError:pass
  except Exception:pass
 def close(self,ctx):
  if ctx.get('stage'):
   try:self._neutral(ctx);self._signal(ctx['stage'],'cancel.flag')
   except Exception:pass
