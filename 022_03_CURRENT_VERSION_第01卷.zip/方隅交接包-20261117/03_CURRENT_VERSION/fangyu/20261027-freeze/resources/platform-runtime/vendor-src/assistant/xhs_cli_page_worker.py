"""One explicit task's read-only CLI process; no standalone login or replay.

Every wire request waits for the original parent's current authorization. A page
must be durably received by that parent before the next command is accepted.
The original transport owns pacing, activity records and first-error stopping.
"""
import hashlib
import io
import json
import os
import re
import secrets
import sys
from contextlib import redirect_stdout,redirect_stderr
from urllib.parse import urlsplit,parse_qsl

LIMIT=4*1024*1024
_IDENT=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_HASH=re.compile(r'[0-9a-f]{64}\Z')

def _text(value,maximum=8192):
    return isinstance(value,str) and 0<len(value)<=maximum and not any(ord(c)<32 or ord(c)==127 for c in value)

def _note(value):
    if not _text(value):raise ValueError('Invalid source')
    p=urlsplit(value)
    if (p.scheme!='https' or p.hostname not in ('www.xiaohongshu.com','xiaohongshu.com')
            or p.username or p.password or p.port or p.fragment
            or not re.fullmatch(r'/(?:explore|search_result)/[A-Za-z0-9]+/?',p.path)):
        raise ValueError('Invalid source')
    return p.path.rstrip('/').split('/')[-1]

def validate_args(args):
    if type(args) is not list or not args or any(not _text(a) for a in args):raise ValueError('Invalid read command')
    op=args[0]
    if op=='whoami':
        if args not in (['whoami','--json'],['whoami','--json','--phase','before'],['whoami','--json','--phase','after']):raise ValueError('Invalid identity read')
    elif op=='user':
        if len(args)!=3 or not _IDENT.fullmatch(args[1]) or args[2]!='--json':raise ValueError('Invalid public profile read')
    elif op=='search':
        if (len(args)!=5 or args[2:4]!=['--json','--page'] or not _text(args[1],500)
                or not re.fullmatch(r'[1-9][0-9]{0,5}',args[4])):raise ValueError('Invalid search page')
    elif op in ('comments','sub-comments'):
        head=2 if op=='comments' else 3
        if len(args)<head+1 or args[head]!='--json':raise ValueError('Invalid comment page')
        if op=='comments':_note(args[1])
        elif not _IDENT.fullmatch(args[1]) or not _IDENT.fullmatch(args[2]):raise ValueError('Invalid comment identity')
        tail=args[head+1:]
        if len(tail)%2:raise ValueError('Invalid page options')
        options=dict(zip(tail[::2],tail[1::2]))
        allowed={'--cursor'} if op=='comments' else {'--cursor','--xsec-token'}
        if len(options)!=len(tail)//2 or set(options)-allowed:raise ValueError('Invalid page options')
        if '--cursor' in options and not _text(options['--cursor'],512):raise ValueError('Invalid cursor')
        if '--xsec-token' in options and not _text(options['--xsec-token'],4096):raise ValueError('Invalid source token')
    elif op in ('user-posts','notifications'):
        if op=='user-posts':
            if len(args)<3 or not _IDENT.fullmatch(args[1]) or args[2]!='--json':raise ValueError('Invalid profile page')
            tail=args[3:];allowed={'--cursor','--max-items'}
        else:
            if len(args)<6 or args[1]!='--json':raise ValueError('Invalid notifications page')
            tail=args[2:];allowed={'--cursor','--type','--num'}
        if len(tail)%2:raise ValueError('Invalid page options')
        options=dict(zip(tail[::2],tail[1::2]))
        if len(options)!=len(tail)//2 or set(options)-allowed:raise ValueError('Invalid page options')
        if '--cursor' in options and not _text(options['--cursor'],512):raise ValueError('Invalid cursor')
        if '--max-items' in options and (op!='user-posts' or options['--max-items'] not in ('1','2','3','4','5')):raise ValueError('Invalid bounded recent posts')
        if op=='notifications' and (options.get('--type') not in ('mentions','likes','connections')
                or not re.fullmatch(r'[1-9][0-9]?',options.get('--num','')) or int(options['--num'])>50):
            raise ValueError('Invalid notification type or count')
    else:raise ValueError('Only fixed read pages are accepted')
    return args

def exact_source_gate(args):
    from core.acquisition_extension.contracts import ReadRequest
    from core.acquisition_extension.guarded_port import compile_xhs_request,SinglePageWireGate
    validate_args(args);op=args[0]
    if op=='whoami':
        request=ReadRequest('user_me',{})
    elif op=='user':
        request=ReadRequest('user_profile',{'user_id':args[1]})
    elif op=='user-posts':
        opt=dict(zip(args[3::2],args[4::2]));request=ReadRequest('user_posts',{'user_id':args[1],'cursor':opt.get('--cursor','')})
    elif op=='notifications':
        opt=dict(zip(args[2::2],args[3::2]));request=ReadRequest('notifications',{'type':opt['--type'],'num':int(opt['--num']),'cursor':opt.get('--cursor','')})
    elif op=='comments':
        # Legacy pages without an explicit token keep the original read route.
        query=dict(parse_qsl(urlsplit(args[1]).query));opt=dict(zip(args[3::2],args[4::2]))
        if not query.get('xsec_token'):return None
        request=ReadRequest('comments',{'note_url':args[1],'cursor':opt.get('--cursor','')})
    elif op=='sub-comments':
        from urllib.parse import urlencode
        opt=dict(zip(args[4::2],args[5::2]))
        if not opt.get('--xsec-token'):return None
        request=ReadRequest('sub_comments',{'note_url':'https://www.xiaohongshu.com/explore/'+args[1]+'?'+urlencode({'xsec_token':opt['--xsec-token']}),
            'root_comment_id':args[2],'cursor':opt.get('--cursor','')})
    else:return None
    return SinglePageWireGate(compile_xhs_request(request))


def page_key(args):
    validate_args(args)
    # Refreshing a note's access token cannot turn an unknown original page
    # into another authorized request. Source arguments still have a CAS hash.
    values=list(args)
    if args[0]=='comments':values[1]=_note(args[1])
    if '--xsec-token' in values:
        i=values.index('--xsec-token');values=values[:i]+values[i+2:]
    return digest(values)

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def _read(stream):
    line=stream.readline(LIMIT+1)
    if not line or len(line.encode('utf-8'))>LIMIT:raise EOFError('Parent stream unavailable')
    value=json.loads(line)
    if type(value) is not dict:raise ValueError('Invalid parent frame')
    return value

def _write(stream,value):
    raw=json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n'
    if len(raw.encode('utf-8'))>LIMIT:raise ValueError('Page response exceeds fixed bound')
    stream.write(raw);stream.flush()

_PROFILE_SEAL=object()
class _ProfileBinding:
    def __init__(self,args):self.seal=_PROFILE_SEAL;self.args=tuple(args)

def project_reply_read(args,stdout,binding=None):
    """Minimize before durable IPC receipts: no demographics or excess posts."""
    op=args[0]
    if op not in ('whoami','user') and not (op=='user-posts' and '--max-items' in args):return stdout
    raw=json.loads(stdout);data=raw
    for _ in range(4):
        if not isinstance(data,dict):raise ValueError('Invalid public read payload')
        if data.get('ok') is False or data.get('error') is not None:return json.dumps({'ok':False,'error':{'code':'public_read_rejected','message':'平台读取未完成，请核对当前账号'}})
        if 'data' in data and isinstance(data['data'],dict):data=data['data']
        else:break
    def bounded(value,limit):
        if not isinstance(value,str) or len(value)>limit:raise ValueError('Public original text out of bound')
        return value
    if op=='whoami':
        user=data.get('user',data.get('basic_info',data))
        positions=[user,data.get('basic_info',{}),data.get('user_info',{})]
        values={v for entry in positions if isinstance(entry,dict) for key in ('user_id','userid','id') for v in [entry.get(key)] if isinstance(v,str) and v}
        if len(values)!=1:raise ValueError('Actual identity ambiguous')
        uid=next(iter(values))
        if not _IDENT.fullmatch(str(uid)) or user.get('guest') is True:raise ValueError('Actual identity missing')
        result={'user':{'id':uid,'nickname':bounded(user.get('nickname',user.get('name','')),300)}}
    elif op=='user':
        basic=data.get('basic_info',data)
        positions=[basic,data,data.get('user',{}),data.get('user_info',{})]
        values=set()
        for entry in positions:
            if not isinstance(entry,dict):continue
            for key in ('user_id','userid','id'):
                value=entry.get(key)
                if value is None or value=='':continue
                if not isinstance(value,str) or not _IDENT.fullmatch(value):raise ValueError('Malformed explicit public subject')
                values.add(value)
        if values and (len(values)!=1 or next(iter(values))!=args[1]):raise ValueError('Public profile subject mismatched')
        result={'subjectId':args[1],'identitySource':'response_uid' if values else 'request_bound_subject','desc':bounded(basic.get('desc',''),4000)}
        if values:result['user_id']=args[1]
        elif type(binding) is not _ProfileBinding or binding.seal is not _PROFILE_SEAL or binding.args!=tuple(args):raise ValueError('Public subject requires exact authorized page binding')
    else:
        limit=int(args[args.index('--max-items')+1]);notes=data.get('notes')
        if not isinstance(notes,list) or len(notes)>100:raise ValueError('Invalid bounded public posts page')
        selected=[]
        for note in notes:
            if not isinstance(note,dict):continue
            card=note.get('note_card',note);author=card.get('user',{})
            author_values={v for source in (author,card.get('author',{})) if isinstance(source,dict) for key in ('user_id','userid') for v in [source.get(key)] if isinstance(v,str) and v}
            uid=next(iter(author_values)) if len(author_values)==1 else ''
            nid=note.get('note_id',note.get('id',card.get('note_id','')))
            if uid!=args[1] or not _IDENT.fullmatch(str(nid)):continue
            selected.append({'note_id':nid,'user_id':uid,'title':bounded(card.get('display_title',card.get('title','')),1000),'desc':bounded(card.get('desc',''),6000)})
            if len(selected)>=limit:break
        result={'notes':selected,'has_more':False,'cursor':'','bounded':True,'authorVerified':True}
    return json.dumps({'ok':True,'schema_version':'1','data':result},ensure_ascii=False,separators=(',',':'))


def _setup(gate):
    # Entry is only the already pinned CLI dispatcher, with its original
    # isolated HOME. No alternate module, executable or cookie path is accepted.
    wrapper=sys.modules.get('__main__')
    if (os.environ.get('LEADSTUDIO_ISOLATED')!='1' or not os.environ.get('WORKSPACE_ACTIVITY_LOG')
            or not callable(getattr(wrapper,'install_xhs_write_guards',None))):
        raise ValueError('Original isolated dispatcher required')
    wrapper._PAGE_WIRE_GATE=gate
    wrapper.install_xhs_write_guards()
    wrapper.install_xhs_profile_avatar_compat()
    wrapper.install_xhs_sub_comments_compat()
    import click
    import xhs_cli.cookies
    from xhs_cli.cli import cli
    from xhs_cli.commands import _common,reading,auth
    xhs_cli.cookies.extract_browser_cookies=lambda *a,**k:None
    cli.commands={name:command for name,command in cli.commands.items() if name in ('search','comments','sub-comments','user-posts','notifications','user','whoami')}
    client=None
    def action(ctx,callback):
        nonlocal client
        if client is None:client=_common.get_client(ctx)
        return callback(client)
    # comments holds a static alias; handle_command resolves through _common.
    _common.run_client_action=reading.run_client_action=auth.run_client_action=action
    def run(args):
        stdout,stderr=io.StringIO(),io.StringIO();code=0
        dispatch_args=list(args)
        if '--phase' in dispatch_args:
            index=dispatch_args.index('--phase');dispatch_args=dispatch_args[:index]+dispatch_args[index+2:]
        if '--max-items' in dispatch_args:
            index=dispatch_args.index('--max-items');dispatch_args=dispatch_args[:index]+dispatch_args[index+2:]
        with redirect_stdout(stdout),redirect_stderr(stderr):
            try:cli.main(args=dispatch_args,prog_name='xhs',standalone_mode=False)
            except SystemExit as error:code=error.code if type(error.code) is int else 1
            except click.exceptions.Exit as error:code=error.exit_code
            except Exception:
                code=1
                if not stdout.getvalue():stdout.write(json.dumps({'error':{'code':'worker_operation_failed','message':'本页读取未完成，原断点已保留'}}))
        try:out=project_reply_read(args,stdout.getvalue(),getattr(gate,'profile_binding',lambda:None)()) if code==0 else stdout.getvalue()
        except (ValueError,TypeError,KeyError):out=json.dumps({'ok':False,'error':{'code':'public_read_identity_unverified','message':'返回原文缺少稳定作者身份，未保存资料'}});code=1
        return out,stderr.getvalue(),code
    def close():
        if client is not None:client.close()
    run.close=close
    return run

def serve(in_stream,out_stream,setup=None):
    hello=_read(in_stream)
    if (set(hello)!={'type','version','nonce','scope','task','account'} or hello.get('type')!='hello'
            or hello.get('version')!=1 or not _HASH.fullmatch(str(hello.get('nonce','')))
            or not _HASH.fullmatch(str(hello.get('scope',''))) or not _IDENT.fullmatch(str(hello.get('task','')))
            or not _IDENT.fullmatch(str(hello.get('account','')))):
        raise ValueError('Invalid task handshake')
    nonce=hello['nonce'];active=None;operation=None;current_args=None;strict_gate=None;profile_binding=None
    def gate(method,url=None):
        nonlocal profile_binding
        if active is None:raise ValueError('No active page')
        endpoint=urlsplit(str(url or ''))
        allowed={'search':{('POST','/api/sns/web/v1/search/onebox'),('GET','/api/sns/web/v1/search/filter'),('POST','/api/sns/web/v1/search/notes'),('GET','/api/sns/web/v1/search/recommend')},
            'comments':{('GET','/api/sns/web/v2/comment/page')},'sub-comments':{('GET','/api/sns/web/v2/comment/sub/page')}}
        note_prewarm=(operation=='comments' and str(method).upper()=='GET' and endpoint.netloc=='www.xiaohongshu.com'
            and endpoint.path=='/explore/'+_note(current_args[1]))
        api_read=endpoint.netloc=='edith.xiaohongshu.com' and (str(method).upper(),endpoint.path) in allowed.get(operation,set())
        if strict_gate is not None:
            strict_gate(str(method).upper(),str(url or ''))
        elif (endpoint.scheme!='https' or endpoint.username or endpoint.password or endpoint.fragment or not (api_read or note_prewarm)):
            raise ValueError('Only the current original read endpoint is accepted')
        wire=secrets.token_hex(16)
        _write(out_stream,{'type':'wire_ready','nonce':nonce,'page':active,'wire':wire,
            'method':str(method).upper() if str(method).upper() in ('GET','POST') else 'OTHER'})
        reply=_read(in_stream)
        if reply!={'type':'wire_allow','nonce':nonce,'page':active,'wire':wire}:
            raise ValueError('Original parent did not authorize this request')
        # Mint only after this exact request passed SinglePageWireGate and the
        # parent explicitly allowed its wire. Reset for every original page.
        if operation=='user' and strict_gate is not None:profile_binding=_ProfileBinding(current_args)
    gate.profile_binding=lambda:profile_binding
    runner=None
    try:
        runner=(setup or _setup)(gate)
        _write(out_stream,{'type':'ready','nonce':nonce,'scope':hello['scope']})
        while True:
            packet=_read(in_stream)
            if packet=={'type':'close','nonce':nonce}:return 0
            if set(packet)!={'type','nonce','page','args'} or packet['type']!='page' or packet['nonce']!=nonce:
                raise ValueError('Invalid page frame')
            args=validate_args(packet['args']);active=page_key(args);operation=args[0];current_args=args
            if packet['page']!=active:raise ValueError('Page identity mismatch')
            strict_gate=exact_source_gate(args);profile_binding=None
            os.environ['WORKSPACE_ACTIVITY_KIND']=args[0]
            stdout,stderr,code=runner(args)
            if type(stdout) is not str or type(stderr) is not str or type(code) is not int:raise ValueError('Invalid CLI result')
            result={'stdout':stdout,'stderr':stderr,'returncode':code}
            value=digest(result)
            _write(out_stream,{'type':'result','nonce':nonce,'page':active,**result,'digest':value})
            ack=_read(in_stream)
            if ack!={'type':'ack','nonce':nonce,'page':active,'digest':value}:raise ValueError('Durable parent receipt required')
            active=None
            if code:return 1
    finally:
        close=getattr(runner,'close',None)
        if callable(close):close()

def main():
    if not sys.stdin or not sys.stdout or sys.stdin.isatty() or sys.stdout.isatty():return 2
    try:return serve(sys.stdin,sys.stdout)
    except Exception:return 2
