"""One-shot, employee-scoped Xiaohongshu response check.

This module never schedules a platform read. Only an explicit start call creates
one bounded job; cancellation takes effect between CLI pages. Observations live
outside leads, so they do not enter the acquisition or AI analysis queues.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import re
import threading
import time
from urllib.parse import urlsplit
from uuid import uuid4

from core import CoreError
from core.continuous import ACTIVE
from core.response_journal import ResponseJournal
from .customer_list import CustomerHistory, _epoch, _person, _post


_ID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
_NOTE = re.compile(r'/(?:explore|search_result)/([A-Za-z0-9]{24})/?\Z')
_TERMINAL = frozenset(('found', 'not_found', 'partial', 'unavailable',
                       'needs_review', 'failed', 'cancelled', 'interrupted'))


class CustomerResponseMonitor:
    MAX_PAGES = 2
    MAX_ROWS = 40

    def __init__(self, executor, *, clock=None, waiter=None):
        self.executor = executor
        self.core = executor.core
        self.response_journal = ResponseJournal(self.core.store)
        self.clock = clock or time.time
        self.waiter = waiter or (lambda stop, seconds: stop.wait(seconds))
        self._lock = threading.RLock()
        self._cancel = {}
        with self.core.store.connect() as db:
            db.executescript('''
              CREATE TABLE IF NOT EXISTS customer_response_jobs(
                id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, cloud_owner TEXT NOT NULL,
                body TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS customer_response_observations(
                tenant_id TEXT NOT NULL, cloud_owner TEXT NOT NULL,
                platform TEXT NOT NULL, note_id TEXT NOT NULL, comment_id TEXT NOT NULL,
                body TEXT NOT NULL,
                PRIMARY KEY(tenant_id,cloud_owner,platform,note_id,comment_id));
              CREATE INDEX IF NOT EXISTS response_observations_owner
                ON customer_response_observations(tenant_id,cloud_owner);
            ''')
            rows=db.execute("SELECT id,body FROM customer_response_jobs WHERE tenant_id=? AND cloud_owner=?",
                            (executor.tenant,executor.owner)).fetchall()
            for row in rows:
                job=json.loads(row['body'])
                if job.get('status') in ('queued','running'):
                    job.update(status='interrupted',message='程序退出，本次检查未自动继续',updated_at=time.time())
                    db.execute('UPDATE customer_response_jobs SET body=? WHERE id=?',
                               (json.dumps(job,ensure_ascii=False),row['id']))

    def _read(self, ident, user):
        with self.core.store.connect() as db:
            row=db.execute('SELECT body FROM customer_response_jobs WHERE id=? AND tenant_id=? AND cloud_owner=?',
                           (ident,self.executor.tenant,user['username'])).fetchone()
        if not row:raise CoreError('回信检查任务不存在或无权访问')
        return json.loads(row['body'])

    def _write(self, job):
        with self._lock:
            job['updated_at']=time.time()
            with self.core.store.connect() as db:
                db.execute('INSERT OR REPLACE INTO customer_response_jobs VALUES(?,?,?,?)',
                           (job['id'],job['tenant_id'],job['cloud_owner'],json.dumps(job,ensure_ascii=False)))

    def _source_digest(self, reply, lead, account, user):
        source={'tenant':self.executor.tenant,'owner':self.executor.owner,'username':user['username'],
                'reply':{key:reply.get(key) for key in ('id','tenant_id','lead_id','account_id','status',
                       'text','platform_reply_id','sent_at','followup_target_id','followup_target_digest')},
                'lead':{key:lead.get(key) for key in ('id','tenant_id','cloud_owner','platform',
                      'author_id','note_url','parent_id','comment_id')},
                'account':{key:account.get(key) for key in ('id','tenant_id','cloud_owner','platform',
                         'status','platform_uid')}}
        return hashlib.sha256(json.dumps(source,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

    def _source_guard(self, job, user):
        if (self.executor.tenant!=job['tenant_id'] or self.executor.owner!=job['cloud_owner'] or
                user.get('username')!=job['cloud_owner'] or user.get('tenant_id')!=job['tenant_id'] or
                user.get('role')!='operator' or user.get('cloud_bound') is not True or
                user.get('development_local_only') is True):
            raise CoreError('回信检查员工身份已变化')
        server=getattr(self.executor,'server',None)
        if server is not None:
            assistant=server.assistant_service
            with assistant.lock:
                if (assistant.executor is not self.executor or assistant.state not in ('online','held') or
                        (assistant.device or {}).get('owner')!=job['cloud_owner'] or
                        not (assistant.device or {}).get('id')):
                    raise CoreError('本机助手绑定员工已变化')
            from .employee_workspace import require_owner
            require_owner(server,user)
            current=self.executor.principal({'owner':job['cloud_owner'],
                'principal':{'username':job['cloud_owner'],'role':'operator'},
                'action':'customer_response_check_status'},read_only=True)
            if current.get('id')!=user.get('id') or current.get('cloud_bound') is not True:
                raise CoreError('本机员工身份已失效')
        reply=self.core._get('replies',job['reply_id'],job['tenant_id'])
        lead=self.core._reply_source(reply,user)
        account=self.core._get('accounts',reply['account_id'],job['tenant_id'])
        self.executor._lead_access(user,lead)
        self.core._account_access(user,account)
        if (self._source_digest(reply,lead,account,user)!=job['source_digest'] or
                self.executor._account_review(account,user).get('requires_review')):
            raise CoreError('回信检查源记录或账号状态已变化')
        self.core._platform_execution_guard('xiaohongshu')
        return reply,lead,account

    @staticmethod
    def _public(job):
        return {key:job[key] for key in ('id','status','message','pages_read','comments_read',
                'observations_saved','matches','has_more','account_id','last_platform_attempt_at',
                'updated_at') if key in job}

    def _request_interval(self):
        configured=getattr(getattr(self.core,'continuous',None),'batch_interval',40)
        return max(40,float(configured)) if type(configured) in (int,float) and 0<configured<3600 else 40

    def _latest_attempt(self, job):
        with self.core.store.connect() as db:
            rows=db.execute('SELECT body FROM customer_response_jobs WHERE tenant_id=?',
                            (job['tenant_id'],)).fetchall()
        latest=0.0
        for row in rows:
            try:other=json.loads(row['body'])
            except (TypeError,ValueError):continue
            stamp=other.get('last_platform_attempt_at')
            if other.get('account_id')==job.get('account_id') and type(stamp) in (int,float):
                latest=max(latest,float(stamp))
        return latest

    def _wait_request_interval(self, job, stop):
        last=self._latest_attempt(job)
        if not last:return
        remaining=self._request_interval()-max(0,self.clock()-last)
        if remaining<=0:return
        job['message']='等待下一次读取';self._write(job)
        if self.waiter(stop,remaining) or stop.is_set():
            raise InterruptedError('已取消；后续页面未读取，本次结果未保存')

    def start(self, data, user):
        if set(data)!={'author_key','reply_id'} or not all(isinstance(v,str) for v in data.values()):
            raise ValueError('回信检查参数无效')
        history=CustomerHistory(self.core,self.executor.tenant,self.executor.owner,
                                lead_access=self.executor._lead_access)
        customer=history.customer_detail(data['author_key'],user)
        reply_id=data['reply_id']
        if not any(reply_id==item.get('id') for comment in customer['comments']
                   for item in comment['reply_history']):
            raise CoreError('发送记录不属于这个客户')
        reply=self.core._get('replies',reply_id,self.executor.tenant)
        lead=self.core._reply_source(reply,user)
        self.executor._lead_access(user,lead)
        if _person(lead)[0]!=data['author_key']:
            raise CoreError('发送记录与客户身份不一致')
        with self._lock:
            with self.core.store.connect() as db:
                rows=db.execute('SELECT body FROM customer_response_jobs WHERE tenant_id=? AND cloud_owner=?',
                                (self.executor.tenant,self.executor.owner)).fetchall()
            if any(json.loads(row['body']).get('status') in ('queued','running') for row in rows):
                raise CoreError('已有回信检查正在进行，请等待结果')
            job={'id':uuid4().hex,'tenant_id':self.executor.tenant,'cloud_owner':user['username'],
                 'author_key':data['author_key'],'reply_id':reply_id,'status':'queued',
                 'message':'已接受本次检查','pages_read':0,'comments_read':0,
                 'observations_saved':0,'matches':0,'has_more':False}
            platform_id=str(reply.get('platform_reply_id') or '')
            if reply.get('status')!='sent' or not _ID.fullmatch(platform_id):
                job.update(status='unavailable',message='历史发送缺平台回复评论 ID，无法自动核验回信')
                self._write(job)
                return self._public(job)
            account=self.core._get('accounts',reply['account_id'],self.executor.tenant)
            self.core._account_access(user,account)
            job['account_id']=account['id']
            job['last_platform_attempt_at']=None
            job['source_digest']=self._source_digest(reply,lead,account,user)
            self._write(job)
            stop=threading.Event();self._cancel[job['id']]=stop
            thread=threading.Thread(target=self._run,args=(job,user,stop),
                                    name='customer-response-check',daemon=True)
            thread.start()
            return self._public(job)

    def status(self, data, user):
        if set(data)!={'job_id'} or not isinstance(data.get('job_id'),str) or not re.fullmatch(r'[a-f0-9]{32}',data['job_id']):
            raise ValueError('回信检查任务标识无效')
        return self._public(self._read(data['job_id'],user))

    def cancel(self, data, user):
        if (set(data)!={'job_id'} or not isinstance(data['job_id'],str) or
                not re.fullmatch(r'[a-f0-9]{32}',data['job_id'])):
            raise ValueError('回信检查任务标识无效')
        with self._lock:
            job=self._read(data['job_id'],user)
            if job['status'] not in _TERMINAL:
                event=self._cancel.get(job['id'])
                if event:event.set()
                job['message']='取消已请求；当前页面读取结束后停止'
                self._write(job)
        return self._public(job)

    def _receipt_verified(self, user, reply, lead):
        local=self.core.contact_journal.receipt(self.executor.tenant,self.executor.owner,reply['id'],lead['id'])
        events=local.get('events')
        if (local.get('local_outcome')!='sent' or local.get('local_integrity')!='ok' or
                not local.get('local_sent_event_id') or not isinstance(events,list) or not 1<=len(events)<=20):
            return False
        expected=[{'event_id':event['event_id'],'payload_hash':event['payload_hash']} for event in events]
        cloud=self.executor._ai_cloud(user,'contact_receipts_verify',{'reply_id':reply['id'],'events':expected})
        found=cloud.get('events') if isinstance(cloud,dict) else None
        if (not isinstance(cloud,dict) or cloud.get('source')!='cloud_ledger' or cloud.get('reply_id')!=reply['id'] or
                cloud.get('cloud_verified') is not True or cloud.get('receipt_status')!='verified' or
                type(cloud.get('verified_at')) is not int or cloud['verified_at']<=0 or
                not isinstance(found,list) or len(found)!=len(expected)):
            return False
        hashes={item['event_id']:item['payload_hash'] for item in expected}
        if len(hashes)!=len(expected) or {row.get('event_id') for row in found}!=set(hashes):return False
        if not all(row.get('status')=='verified' and row.get('payload_hash')==hashes.get(row.get('event_id')) and
                   type(row.get('server_received_at')) is int and row['server_received_at']>0
                   for row in found):return False
        return (any(row.get('event_id')==local['local_sent_event_id'] and row.get('kind')=='sent' and
                    row.get('verification_status')=='paired' for row in found) and
                any(row.get('kind')=='send_started' and row.get('verification_status')=='start_recorded'
                    for row in found))

    def _run(self, job, user, stop):
        lease_owner='response-check:'+job['id'];account_id='';leased=False;phase='receipt'
        try:
            if stop.is_set():raise InterruptedError('已取消，未读取平台')
            reply=self.core._get('replies',job['reply_id'],self.executor.tenant)
            lead=self.core._reply_source(reply,user)
            self.executor._lead_access(user,lead)
            if reply.get('status')!='sent' or not _ID.fullmatch(str(reply.get('platform_reply_id') or '')):
                job.update(status='unavailable',message='历史发送缺平台回复评论 ID，无法自动核验回信');return
            if not self._receipt_verified(user,reply,lead):
                job.update(status='needs_review',message='本机与云端成功发送凭据未完整匹配，未读取平台');return
            if stop.is_set():raise InterruptedError('已取消，未读取平台')
            phase='account'
            reply,lead,account=self._source_guard(job,user)
            account_id=reply['account_id']
            if (account.get('platform')!='xiaohongshu' or account.get('status')!='ready' or
                    lead.get('platform')!='xiaohongshu' or not account.get('platform_uid')):
                job.update(status='needs_review',message='平台账号未确认可用，未读取平台');return
            if self.executor._account_review(account,user).get('requires_review'):
                job.update(status='needs_review',message='账号安全记录需复核，未读取平台');return
            self.executor._claim_xhs_account(account)
            self.core.require_platform('xiaohongshu')
            self.core._platform_execution_guard('xiaohongshu')
            note_url=str(lead.get('note_url') or '')
            parsed=urlsplit(note_url)
            note=_NOTE.fullmatch(parsed.path)
            root=str(lead.get('parent_id') or lead.get('comment_id') or '')
            if (parsed.scheme!='https' or parsed.hostname not in ('www.xiaohongshu.com','xiaohongshu.com')
                    or not note or not _ID.fullmatch(root) or not lead.get('author_id') or
                    not _ID.fullmatch(str(lead.get('comment_id') or ''))):
                job.update(status='unavailable',message='原帖或原评论身份不足，无法定向检查');return
            # No collection may be active, including on another account. Never pause it implicitly.
            with self.core.lock:
                if (any(row.get('status') in ACTIVE or row.get('inflight') for row in
                        self.core.store.list('continuous_tasks',self.executor.tenant)) or
                        self.core.running or self.core.sequences or
                        any(row.get('status') in ('running','awaiting_collection') for row in
                            self.core.store.list('reply_queues',self.executor.tenant))):
                    job.update(status='needs_review',message='采集或发送正在运行，请结束后重新明确检查');return
                self.core.acquire_account_mode(account_id,self.executor.tenant,'collection',lease_owner)
                leased=True
            job.update(status='running',message='正在读取原评论楼中楼');self._write(job)
            phase='platform'
            cursor='';history=set();all_rows=[];has_more=False
            for page in range(self.MAX_PAGES):
                if stop.is_set():raise InterruptedError('已取消；后续页面未读取')
                self._wait_request_interval(job,stop)
                self._source_guard(job,user)
                query={'note_url':note_url,'root_comment_id':root,'next_cursor':cursor,
                       '_account_dir':str(self.core.store.directory/'accounts'/self.executor.tenant/account_id),
                       'id':job['id']}
                job['last_platform_attempt_at']=self.clock();self._write(job)
                rows=self.core.adapters.sub_comments('xiaohongshu',query)
                info=query.get('_page_info') or {}
                job['pages_read']+=1;job['comments_read']+=len(rows)
                if type(info.get('has_more')) is not bool:
                    job.update(status='needs_review',message='楼中楼分页状态未确认，已停止');return
                available=max(0,self.MAX_ROWS-len(all_rows))
                if len(rows)>available:
                    job.update(status='needs_review',message='单页超过本次40条上限，未保存不完整页面');return
                if info['has_more']:
                    next_cursor=info.get('cursor')
                    if (not isinstance(next_cursor,str) or not next_cursor or len(next_cursor)>512 or
                            any(ch.isspace() or ord(ch)<32 or ord(ch)==127 for ch in next_cursor) or
                            next_cursor==cursor or next_cursor in history):
                        job.update(status='needs_review',message='楼中楼分页游标无效，已停止');return
                    history.add(next_cursor);cursor=next_cursor
                has_more=info['has_more']
                all_rows.extend(rows[:available])
                if not has_more or len(all_rows)>=self.MAX_ROWS:break
            job['has_more']=has_more
            with self._lock:
                if stop.is_set():raise InterruptedError('已取消；本次读取结果未保存')
                self._source_guard(job,user)
                saved=self._save_observations(job,lead,note.group(1),root,all_rows)
            job['observations_saved']=saved
            detail=CustomerHistory(self.core,self.executor.tenant,self.executor.owner,
                                   lead_access=self.executor._lead_access).customer_detail(job['author_key'],user)
            exact=[]
            for row in all_rows:
                if (row.get('author_id')==lead.get('author_id') and row.get('target_comment_id')==reply.get('platform_reply_id')
                    and row.get('target_author_id')==account.get('platform_uid') and _epoch(row.get('published_at'))>_epoch(reply.get('sent_at'))):
                    exact.append({'comment_id':row.get('comment_id'),'reply_id':reply['id'],'source':'response_check'})
            local=self.core.contact_journal.receipt(self.executor.tenant,self.executor.owner,reply['id'],lead['id'])
            for item in exact:item['sent_event_id']=local.get('local_sent_event_id')
            detail={**detail,'incoming_replies':exact}
            job['matches']=len(exact)
            phase='outbox'
            reportable=self._queue_matched_responses(job,lead,reply,account,note.group(1),all_rows,detail)
            job.update(status='partial' if has_more else 'found' if job['matches'] else 'not_found',
                       message=('本机检查尚有下一页；云端归档待单独核对' if has_more and reportable else
                                '读取范围尚有下一页，请再次明确检查' if has_more else
                                '本机发现明确回应；云端归档待单独核对' if reportable else
                                '本机发现回应，但云端归档证据不足' if job['matches'] else
                                '本次已检查范围未发现可核实回应'))
        except InterruptedError as exc:
            job.update(status='cancelled',message=str(exc))
        except CoreError:
            job.update(status='needs_review',message='本机绑定、源记录或账号安全状态变化，已停止本次检查')
        except Exception:
            # Existing adapter/identity channels record the concrete platform safety failure.
            job.update(status='needs_review',message={
                'receipt':'云端联系回执暂不可核对，未读取平台',
                'account':'账号身份或安全状态未确认，未读取平台',
                'platform':'平台读取异常，已停止；请核对账号安全记录',
                'outbox':'回应已保存，但同步证据未能持久记录，请核对本机存储'
            }[phase])
        finally:
            if leased:self.core.release_account_mode(account_id,self.executor.tenant,lease_owner)
            self._write(job)
            with self._lock:self._cancel.pop(job['id'],None)

    def _queue_matched_responses(self,job,lead,reply,account,note_id,rows,detail):
        """Only explicit current-platform matches with complete source identity enter the outbox."""
        current={str(row.get('comment_id') or ''):row for row in rows}
        post_key,note_url=_post(lead)
        reportable=0
        for match in detail.get('incoming_replies',[]):
            comment_id=match.get('comment_id')
            row=current.get(comment_id)
            if (not row or match.get('source')!='response_check' or match.get('reply_id')!=reply['id'] or
                    not _ID.fullmatch(str(row.get('target_author_id') or '')) or
                    row.get('target_author_id')!=account.get('platform_uid') or
                    row.get('target_comment_id')!=reply.get('platform_reply_id') or
                    row.get('author_id')!=lead.get('author_id')):
                continue
            with self.core.store.connect() as db:
                saved=db.execute('''SELECT body FROM customer_response_observations
                    WHERE tenant_id=? AND cloud_owner=? AND platform='xiaohongshu'
                    AND note_id=? AND comment_id=?''',
                    (self.executor.tenant,self.executor.owner,note_id,comment_id)).fetchone()
            if not saved:continue
            observation=json.loads(saved['body'])
            if (observation.get('post_key')!=post_key or observation.get('note_url')!=note_url or
                    observation.get('author_id')!=lead.get('author_id') or
                    observation.get('target_comment_id')!=row.get('target_comment_id') or
                    observation.get('target_author_id')!=row.get('target_author_id') or
                    observation.get('text')!=str(row.get('text') or '')[:3000] or
                    _epoch(observation.get('published_at'))!=_epoch(row.get('published_at'))):
                continue
            sent_id=match.get('sent_event_id')
            sent=self.core.contact_journal.sent_snapshot(self.executor.tenant,self.executor.owner,
                                                           sent_id,reply['id'],lead['id'])
            if (not sent or sent.get('lead',{}).get('author_id')!=lead.get('author_id') or
                    sent['lead'].get('comment_id')!=lead.get('comment_id') or
                    sent['lead'].get('note_url')!=note_url or
                    sent.get('reply',{}).get('platform_reply_id')!=reply.get('platform_reply_id') or
                    sent.get('sender',{}).get('platform_uid')!=account.get('platform_uid') or
                    sent['sender'].get('account_id')!=account.get('id') or
                    _epoch(observation.get('published_at'))<=_epoch(reply.get('sent_at'))):
                continue
            self.response_journal.record(self.executor.tenant,self.executor.owner,{
                'sent_event_id':sent_id,'origin_comment_id':lead['comment_id'],
                'local_reply_id':reply['id'],'platform_reply_id':reply['platform_reply_id'],
                'response':{'platform':'xiaohongshu','author_id':lead['author_id'],
                            'note_url':note_url,'comment_id':comment_id,
                            'target_comment_id':observation['target_comment_id'],
                            'target_author_id':observation['target_author_id'],
                            'published_at':_epoch(observation['published_at']),
                            'text':observation['text']}})
            reportable+=1
        return reportable

    def _save_observations(self, job, lead, note_id, root, rows):
        post_key,note_url=_post(lead)
        prepared=[]
        for row in rows:
            comment_id=str(row.get('comment_id') or '')
            author_id=str(row.get('author_id') or '')
            if (not _ID.fullmatch(comment_id) or author_id!=lead.get('author_id') or
                    row.get('platform')!='xiaohongshu' or not _epoch(row.get('published_at')) or
                    row.get('parent_id') not in (None,'',root) or
                    row.get('note_url') and _post({'id':'observed','platform':'xiaohongshu',
                                                   'note_url':row['note_url']})[0]!=post_key):
                continue
            observation={'platform':'xiaohongshu','author_id':author_id,'comment_id':comment_id,
                         'target_comment_id':str(row.get('target_comment_id') or ''),
                         'target_author_id':str(row.get('target_author_id') or ''),
                         'published_at':row['published_at'],'text':str(row.get('text') or '')[:3000],
                         'note_url':note_url,'post_key':post_key,'source_note_title':str(lead.get('content_title') or ''),
                         'observed_at':datetime.now(timezone.utc).isoformat()}
            prepared.append((comment_id,observation))
        count=0
        with self.core.store.connect() as db:
            for comment_id,observation in prepared:
                key=(self.executor.tenant,self.executor.owner,'xiaohongshu',note_id,comment_id)
                prior=db.execute('''SELECT body FROM customer_response_observations
                    WHERE tenant_id=? AND cloud_owner=? AND platform=? AND note_id=? AND comment_id=?''',key).fetchone()
                if prior is None:
                    db.execute('''INSERT INTO customer_response_observations
                        (tenant_id,cloud_owner,platform,note_id,comment_id,body) VALUES(?,?,?,?,?,?)''',
                        (*key,json.dumps(observation,ensure_ascii=False)))
                    count+=1;continue
                old=json.loads(prior['body'])
                identity=('platform','author_id','comment_id','published_at','text','post_key','note_url')
                if any(old.get(field)!=observation.get(field) for field in identity):continue
                old_target=str(old.get('target_comment_id') or '')
                new_target=observation['target_comment_id']
                old_author=str(old.get('target_author_id') or '')
                new_author=observation['target_author_id']
                if (old_target and new_target and old_target!=new_target or
                        old_author and new_author and old_author!=new_author):continue
                changed=False
                if not old_target and _ID.fullmatch(new_target):
                    old['target_comment_id']=new_target;changed=True
                if (not old_author and _ID.fullmatch(new_author) and
                        (old.get('target_comment_id') or '')==new_target):
                    old['target_author_id']=new_author;changed=True
                if changed:
                    db.execute('''UPDATE customer_response_observations SET body=?
                        WHERE tenant_id=? AND cloud_owner=? AND platform=? AND note_id=? AND comment_id=?''',
                        (json.dumps(old,ensure_ascii=False),*key))
                    count+=1
        return count
