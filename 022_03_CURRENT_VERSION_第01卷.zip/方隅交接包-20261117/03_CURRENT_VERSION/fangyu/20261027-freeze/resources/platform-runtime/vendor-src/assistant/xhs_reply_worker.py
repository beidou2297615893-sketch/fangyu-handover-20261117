"""One owned reply, one client, exact GET then POST, no fallback or retry."""
import hashlib,json,os,re,sys,secrets
from urllib.parse import urlsplit
LIMIT=65536
IDENT=re.compile(r'[A-Za-z0-9_-]{1,160}\Z')
HASH=re.compile(r'[a-f0-9]{64}\Z')
class PreflightDenied(ValueError):pass
class UnknownOutcome(RuntimeError):pass
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def validate(r):
 if type(r) is not dict or set(r)!={'attemptId','expectedUid','noteId','commentId','text','requestDigest'}:raise ValueError('Invalid reviewed request')
 if any(not isinstance(r[k],str) or not IDENT.fullmatch(r[k]) for k in ('attemptId','expectedUid','noteId','commentId')) or not HASH.fullmatch(str(r['requestDigest'])):raise ValueError('Invalid reviewed identity')
 if not isinstance(r['text'],str) or not r['text'].strip() or len(r['text'])>2000 or '\x00' in r['text']:raise ValueError('Invalid reviewed text')
 return r
def post_body(r):return {'note_id':r['noteId'],'content':r['text'],'target_comment_id':r['commentId'],'at_users':[]}
class ExactWireGate:
 def __init__(self,request,authorize):self.request=validate(request);self.authorize=authorize;self.phase=0;self.uid=None;self.session_guard=None
 def prove(self,uid):
  if self.phase!=1 or uid!=self.request['expectedUid']:raise PreflightDenied('Actual session identity differs from approved account')
  self.uid=uid
 def __call__(self,method,url,kwargs):
  if self.session_guard is not None:self.session_guard()
  u=urlsplit(str(url));method=str(method).upper()
  if u.scheme!='https' or u.netloc!='edith.xiaohongshu.com' or u.query or u.fragment or u.username or u.password:raise ValueError('Exact reviewed host required')
  if kwargs.get('follow_redirects') not in (None,False) or kwargs.get('params'):raise ValueError('Redirects and query forbidden')
  if self.phase==0 and method=='GET' and u.path=='/api/sns/web/v2/user/me':
   if any(kwargs.get(k) for k in ('content','json','data')):raise ValueError('Identity body forbidden')
   self.authorize('identity',{'method':method,'path':u.path,'query':'','body':None});self.phase=1;return
  if self.phase!=1 or self.uid!=self.request['expectedUid'] or method!='POST' or u.path!='/api/sns/web/v1/comment/post':raise ValueError('Only one reviewed reply after identity is allowed')
  if any(k in kwargs for k in ('json','data')):raise ValueError('Only pinned JSON encoding accepted')
  raw=kwargs.get('content');raw=raw.decode('utf-8') if isinstance(raw,bytes) else raw
  try:body=json.loads(raw)
  except (ValueError,TypeError):raise ValueError('Exact reviewed body required') from None
  if type(body) is not dict or body!=post_body(self.request):raise ValueError('Reply body differs from approval')
  self.authorize('post',{'method':method,'path':u.path,'query':'','body':body});self.phase=2
def _user_candidates(value):
 if not isinstance(value,dict):return []
 if value.get('guest') is True:raise ValueError('Guest identity is not verified')
 values=[value[k] for k in ('user_id','id') if value.get(k) not in (None,'')]
 for key in ('user','basic_info','user_info'):
  if isinstance(value.get(key),dict):values.extend(_user_candidates(value[key]))
 return values
def _consistent_uid(values):
 if not values:return None
 if any(not isinstance(v,str) or not IDENT.fullmatch(v) for v in values) or len(set(values))!=1:raise ValueError('Conflicting or invalid user identities')
 return values[0]
def _sender_uid(response,comment):
 values=[]
 for obj in ([response] if response is comment else [response,comment]):
  values.extend(obj[k] for k in ('user_id','sender_uid','author_id') if obj.get(k) not in (None,''))
  for key in ('user','user_info'):
   if isinstance(obj.get(key),dict):values.extend(_user_candidates(obj[key]))
 return _consistent_uid(values)
def run_once(client,r,authorize,gate=None):
 validate(r);authorize('preflight',None)
 info=client.get_self_info()
 try:uid=_consistent_uid(_user_candidates(info))
 except ValueError:raise PreflightDenied('Actual session identity is inconsistent') from None
 if uid!=r['expectedUid']:raise PreflightDenied('Actual session identity differs from approved account')
 if gate is not None:gate.prove(uid)
 authorize('before_post',{'actualUid':uid})
 try:response=client.reply_comment(r['noteId'],r['commentId'],r['text'])
 except Exception:raise UnknownOutcome('Reply result requires manual verification; never retry') from None
 if gate is not None and gate.session_guard is not None:
  try:gate.session_guard()
  except Exception:raise UnknownOutcome('Original session changed while sending') from None
 if not isinstance(response,dict):raise UnknownOutcome('Reply response missing')
 comment=response.get('comment') if isinstance(response.get('comment'),dict) else response
 ids=[comment.get(k) for k in ('id','comment_id') if comment.get(k) is not None]
 if response is not comment:ids.extend(response[k] for k in ('id','comment_id') if response.get(k) is not None)
 cid=ids[0] if ids else None
 try:sender=_sender_uid(response,comment)
 except ValueError:raise UnknownOutcome('Reply response has conflicting sender identities') from None
 if (not isinstance(cid,str) or not IDENT.fullmatch(cid) or any(x!=cid for x in ids) or (sender is not None and sender!=uid)):
  raise UnknownOutcome('Reply response identity or comment receipt is unconfirmed')
 return {'success':True,'platform_comment_id':cid,'platformCommentId':cid,'actualUid':uid,'responseSenderUid':sender,'identityProofSource':'same_client_preflight_user_me','requestDigest':r['requestDigest'],'attemptId':r['attemptId']}
def _read(stream):
 raw=stream.readline(LIMIT+1)
 if not raw or len(raw.encode())>LIMIT:raise ValueError('Missing private parent frame')
 value=json.loads(raw)
 if type(value) is not dict:raise ValueError('Invalid private frame')
 return value
def _write(stream,v):stream.write(json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n');stream.flush()
def serve(input,output,setup=None):
 hello=_read(input)
 if set(hello)!={'type','version','nonce','scope','request'} or hello['type']!='hello' or hello['version']!=1 or not HASH.fullmatch(str(hello['nonce'])) or not HASH.fullmatch(str(hello['scope'])):raise ValueError('Invalid owned handshake')
 r=validate(hello['request']);nonce=hello['nonce']
 def authorize(stage,detail):
  wire=secrets.token_hex(16);frame={'type':'authorize','nonce':nonce,'wire':wire,'stage':stage,'detail':detail}
  _write(output,frame)
  if _read(input)!={'type':'allow','nonce':nonce,'wire':wire}:raise PreflightDenied('Original parent authorization ended')
 gate=ExactWireGate(r,authorize);client=None
 try:
  client=(setup or _setup)(gate)
  result=run_once(client,r,authorize,gate)
  _write(output,{'type':'result','nonce':nonce,'result':result,'digest':digest(result)})
  if _read(input)!={'type':'ack','nonce':nonce,'digest':digest(result)}:raise UnknownOutcome('Parent receipt unconfirmed')
  return 0
 except PreflightDenied:
  _write(output,{'type':'blocked','nonce':nonce,'code':'identity_or_authorization_changed'});return 3
 except Exception:
  _write(output,{'type':'unknown','nonce':nonce,'code':'result_unconfirmed'});return 4
 finally:
  if client is not None:client.close()
def _setup(gate):
 wrapper=sys.modules.get('__main__')
 if os.environ.get('LEADSTUDIO_ISOLATED')!='1' or not os.environ.get('WORKSPACE_ACTIVITY_LOG') or not callable(getattr(wrapper,'install_xhs_write_guards',None)):raise ValueError('Pinned isolated dispatcher required')
 wrapper._REPLY_WIRE_GATE=gate;wrapper.install_xhs_write_guards()
 import xhs_cli.cookies
 from xhs_cli.client import XhsClient
 xhs_cli.cookies.extract_browser_cookies=lambda *a,**k:None
 from pathlib import Path
 home=Path.home().resolve();cookie_path=xhs_cli.cookies.get_cookie_path().resolve()
 if not cookie_path.is_relative_to(home) or not cookie_path.is_file():raise PreflightDenied('Original isolated session required')
 raw_cookie_digest=hashlib.sha256(cookie_path.read_bytes()).hexdigest()
 cookies=xhs_cli.cookies.load_saved_cookies()
 if not isinstance(cookies,dict) or not cookies.get('a1') or not cookies.get('web_session'):raise PreflightDenied('Original isolated session required')
 cookies.pop('saved_at',None);client=XhsClient(cookies,max_retries=0)
 session_digest=digest({k:cookies.get(k) for k in ('a1','web_session')})
 def session_guard():
  if (Path.home().resolve()!=home or not cookie_path.is_file() or hashlib.sha256(cookie_path.read_bytes()).hexdigest()!=raw_cookie_digest or digest({k:client.cookies.get(k) for k in ('a1','web_session')})!=session_digest):raise PreflightDenied('Original session changed')
 gate.session_guard=session_guard
 return client
def main():
 if not sys.stdin or not sys.stdout or sys.stdin.isatty() or sys.stdout.isatty():return 2
 try:return serve(sys.stdin,sys.stdout)
 except Exception:return 2
