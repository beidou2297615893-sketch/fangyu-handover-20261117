"""Optional diagnostic only. Never authorizes, sends, or records request data.

Output is one of a fixed set of codes. It must not change lease decisions.
"""
import math

FIELDS = frozenset(('schema','allowed','company_id','device_id','owner','version',
                    'purpose','permission_revision','lease_seconds','public_send_allowed','material_sha256'))
CODES = frozenset(('REQUEST_NOT_ATTACHED','HEARTBEAT_ERROR','CLOUD_NO_GRANT',
    'CLOUD_DENIED','LOCAL_REQUEST_INVALID','LOCAL_RESPONSE_INVALID','LOCAL_SAFETY_HOLD',
    'LOCAL_GRANT_FORMAT','LOCAL_GRANT_SCOPE','LOCAL_PERMISSION','LOCAL_EXPIRY',
    'LOCAL_UNCLASSIFIED','LEASE_ACCEPTED','DIAGNOSTIC_ERROR'))

def classify(*, attached, response, request_valid, request_values, user_values,
             poll_started, now, lease_accepted):
    """Classify observed facts only; never use its result to make decisions."""
    try:
        if attached is not True: return 'REQUEST_NOT_ATTACHED'
        if response is None: return 'HEARTBEAT_ERROR'
        if type(response) is not dict: return 'LOCAL_RESPONSE_INVALID'
        grant = response.get('reviewed_reply_release')
        if type(grant) is not dict: return 'CLOUD_NO_GRANT'
        if grant.get('allowed') is not True: return 'CLOUD_DENIED'
        if lease_accepted is True: return 'LEASE_ACCEPTED'
        if request_valid is not True: return 'LOCAL_REQUEST_INVALID'
        if response.get('safety_hold') is not False: return 'LOCAL_SAFETY_HOLD'
        if set(grant) != FIELDS or grant.get('schema') != 'fangyu_reviewed_reply_lease_v1' or grant.get('public_send_allowed') is not True: return 'LOCAL_GRANT_FORMAT'
        if any(grant.get(k) != request_values.get(k) for k in ('material_sha256','purpose','company_id','device_id','owner','version')): return 'LOCAL_GRANT_SCOPE'
        revision=grant.get('permission_revision')
        if (not isinstance(revision,str) or len(revision)!=64 or any(c not in '0123456789abcdef' for c in revision)
            or revision != user_values.get('permission_revision') or user_values.get('can_reply') is not True): return 'LOCAL_PERMISSION'
        seconds=grant.get('lease_seconds')
        if (type(poll_started) not in (int,float) or not math.isfinite(poll_started)
            or poll_started > now or type(seconds) is not int or not 1 <= seconds <= 45
            or poll_started + seconds <= now): return 'LOCAL_EXPIRY'
        return 'LOCAL_UNCLASSIFIED'
    except Exception:
        return 'DIAGNOSTIC_ERROR'

def observe(attached, response, request, runner, poll_started, lease):
    """Best effort: catches all observation failures and emits a fixed code only."""
    try:
        import logging, time
        valid = request.valid(runner) if request is not None else False
        values, user = {}, {}
        if valid:
            user = request.service.server.core.store.get('users', request.executor.user_id) or {}
            values = dict(material_sha256=request.material_sha256, purpose='reviewed_reply',
                company_id=request.service.company_id, device_id=request.device_id,
                owner=request.executor.owner, version=request.version)
        code=classify(attached=attached,response=response,request_valid=valid,
            request_values=values,user_values=user,poll_started=poll_started,
            now=time.monotonic(),lease_accepted=lease is not None)
        logging.getLogger('fangyu.fixed_control_stage').info('reviewed_reply_stage',
            extra={'diagnostic_code':code})
    except Exception:
        pass
