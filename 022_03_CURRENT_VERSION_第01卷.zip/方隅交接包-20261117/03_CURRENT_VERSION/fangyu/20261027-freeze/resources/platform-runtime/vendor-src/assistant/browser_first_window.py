"""Neutral, actor/store-owned WebView. It has no account or task authority."""
import argparse,hashlib,importlib.util,json,os,re,stat,sys,threading
from pathlib import Path
SUPPORT_SHA='e368c59be5558f26c96da1fe0e7b270747f9dcfac352bf01b96285d06c98006d'
def plain(path):
 for part in (path,*path.parents):
  if part.exists():
   info=part.lstat()
   if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('browser_scope_invalid')
 return path
def paths(root,stage):
 root=Path(root).absolute();stage=Path(stage).absolute();plain(root);plain(stage)
 if (not re.fullmatch(r'[a-f0-9]{64}',root.name) or root.parent.parent.name!='browser-sessions'
     or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',root.parent.name)
     or stage.parent!=root/'work/browser-login' or not re.fullmatch(r'[a-f0-9]{24}',stage.name)):
  raise ValueError('browser_scope_invalid')
 return root,stage
def controller_type(module):
 class NeutralController(module.PersistentLoginWindowController):
  def _title(self,message):
   if '通过后工作台会自动继续采集' in message:message='请完成此页面的验证，再回工作台点击“我已完成登录/验证”'
   return super()._title(message)
  def watch_requests(self):
   while not self.finished.wait(.1):
    if self.cancel_file.exists():self.cancel();return
    # Acknowledgements must be consumed before a second explicit capture.
    if self.attempt>self.result_consumed:
     result=self.staging_root/('result-%06d.json'%self.attempt)
     try:
      plain(result);info=result.stat()
      value=json.loads(result.read_text('ascii')) if info.st_size<=1024 and info.st_nlink==1 else None
      if (type(value) is dict and value=={'version':1,'attempt':self.attempt,'status':value.get('status')}
          and value['status'] in ('completed','failed')):
       self.result_consumed=self.attempt;self.stage_path=None
       self.phase='connected' if value['status']=='completed' else 'waiting_manual_check';self.observe()
     except (OSError,ValueError,TypeError):pass
    focus=self.staging_root/'focus.flag'
    if focus.exists():
     try:plain(focus);focus.unlink();self.window.restore();self.window.show()
     except Exception:pass
    capture=self.staging_root/'capture.flag'
    if capture.exists() and self.phase in ('waiting_for_user','waiting_manual_check','connected'):
     try:
      plain(capture)
      if module._is_xhs_origin(self.window.get_current_url()):capture.unlink();self.finish(explicit=True)
     except Exception:pass
    self.watch_verification()
 return NeutralController
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--session-root',type=Path,required=True);parser.add_argument('--stage',type=Path,required=True);parser.add_argument('--spec-sha',required=True);args=parser.parse_args()
 root,stage=paths(args.session_root,args.stage);spec=stage/'session.json';plain(spec)
 raw=spec.read_bytes()
 if len(raw)>2048 or hashlib.sha256(raw).hexdigest()!=args.spec_sha:raise ValueError('browser_scope_invalid')
 support=Path(__file__).with_name('browser_login_window.py');plain(support)
 if hashlib.sha256(support.read_bytes()).hexdigest()!=SUPPORT_SHA:raise ValueError('browser_source_invalid')
 source=Path(os.environ.get('FANGYU_LOGIN_SOURCE_ROOT',''))
 if not source.is_absolute() or not (source/'assistant/browser_login_window.py').is_file():raise ValueError('browser_source_invalid')
 sys.path.insert(0,str(source));import assistant
 module_spec=importlib.util.spec_from_file_location('assistant.browser_login_window',support)
 module=importlib.util.module_from_spec(module_spec);sys.modules[module_spec.name]=module;module_spec.loader.exec_module(module)
 import webview
 def guard():
  try:return not (stage/'cancel.flag').exists() and hashlib.sha256(plain(spec).read_bytes()).hexdigest()==args.spec_sha
  except (OSError,ValueError):return False
 controller=controller_type(module)(mode='live',initial_url=module.XHS_ENTRY_URL,staging_root=stage,cancel_file=stage/'cancel.flag',guard=guard)
 controller.automatic_attempted=True;controller.explicit_capture_only=True
 window=webview.create_window('当前网页 · 登录后回工作台读取',module.XHS_ENTRY_URL,width=1140,height=820)
 controller.window=window;window.events.loaded+=controller.on_loaded;window.events.closed+=controller.on_closed
 threading.Thread(target=controller.watch_requests,daemon=True,name='browser-first-neutral-signals').start()
 profile=root/'xhs-browser-profile';plain(profile);profile.mkdir(parents=True,exist_ok=True)
 try:webview.start(gui='edgechromium',private_mode=False,storage_path=str(profile),debug=False)
 finally:controller.finished.set()
if __name__=='__main__':
 try:main()
 except Exception:raise SystemExit('browser_window_unavailable') from None
