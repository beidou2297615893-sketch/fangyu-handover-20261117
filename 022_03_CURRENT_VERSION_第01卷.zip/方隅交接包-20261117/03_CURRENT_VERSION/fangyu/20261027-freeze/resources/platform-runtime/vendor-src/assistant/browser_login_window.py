"""Owned WebView2 login window with one job-owned candidate staging.

Only --offline is exercised in QA. The caller must run its current safety
guard before launching --live with a fresh, job-owned candidate tempHOME.
New callers explicitly select an account-owned persistent WebView2 profile;
legacy callers without --profile-dir retain a disposable private profile.
The opt-in natural route observes the page's own getMe before staging; the
legacy route still leaves identity verification to the parent's CLI status.
"""

from __future__ import annotations

import argparse
from contextlib import nullcontext
import json
import os
from http.server import ThreadingHTTPServer
from pathlib import Path
import secrets
import re
import stat
import sys
from threading import Event, Lock, Thread
import tempfile
import time
from urllib.parse import urlsplit

if not __package__:
    # The parent supplies the same fixed, manifest-verified r55 source root.
    # Only helper imports are reused; this account's profile stays isolated.
    source_root = Path(os.environ.get('FANGYU_LOGIN_SOURCE_ROOT', ''))
    if (not source_root.is_absolute() or
            not (source_root / 'assistant/browser_login_window.py').is_file()):
        raise SystemExit('helper_source_invalid')
    sys.path.insert(0, str(source_root / 'assistant'))
    sys.path.insert(0, str(source_root))

if __package__:
    from .auth_candidate import (
        CandidateRejected, XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES,
        extract_scoped_cookies, extract_xhs_candidate,
    )
    from .cli_staging import discard_cli_candidate, stage_cli_candidate_once, validate_job_paths
    from .offline_webview_probe import HERE, PROBE_NAME, make_handler
    from .owned_webview2_cookies import read_owned_window_cookies
    from .login_natural_proof import NaturalProofError, PROOF_NAME, read_spec, write_proof
    from .native_login_observer import NativeLoginObserver, NativeLoginError
else:
    from auth_candidate import (
        CandidateRejected, XHS_COOKIE_NAMES, XHS_REQUIRED_NAMES,
        extract_scoped_cookies, extract_xhs_candidate,
    )
    from cli_staging import discard_cli_candidate, stage_cli_candidate_once, validate_job_paths
    from offline_webview_probe import HERE, PROBE_NAME, make_handler
    from owned_webview2_cookies import read_owned_window_cookies
    # Direct script mode starts with only this directory on sys.path.
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from assistant.login_natural_proof import NaturalProofError, PROOF_NAME, read_spec, write_proof
    from assistant.native_login_observer import NativeLoginObserver, NativeLoginError


XHS_ENTRY_URL = "https://www.xiaohongshu.com/explore"
QA_PERSISTENT_NAME = "__qa_persistent"
WINDOW_TIMEOUT_SECONDS = 240
AUTH_CHECK_INTERVAL_SECONDS = 0.8
WEB_PROFILE_NAME = 'xhs-browser-profile'

# Fixed, credential-free evidence survives cleanup of the candidate job.
_RECORDED_OUTCOMES = frozenset({
    'candidate_staged_unverified', 'candidate_staged_natural_verified',
    'cancelled', 'closed', 'timeout', 'safety_hold',
    'cookie_missing', 'cookie_shape_invalid', 'cookie_domain_mismatch',
    'cookie_not_secure', 'cookie_duplicate_or_empty', 'cookie_expiry_invalid',
    'cookie_expiry_missing', 'cookie_expired', 'cookie_oversize', 'cookies_oversize',
    'origin_invalid', 'origin_mismatch', 'candidate_capture_failed', 'window_failed',
    'reader_timeout', 'reader_failed', 'reader_url_failed', 'reader_import_failed',
    'reader_form_failed', 'reader_browser_failed', 'reader_control_failed',
    'reader_identity_failed', 'reader_uninitialized', 'owned_window_invalid',
    'staging_exists', 'staging_write_failed', 'staging_cleanup_failed',
    'profile_path_invalid',
    'natural_identity_unverified', 'natural_proof_invalid',
    'natural_proof_write_failed', 'native_cdp_unavailable',
    'native_initial_source_invalid', 'native_pending',
    'verification_required', 'not_authenticated',
})


def record_live_outcome(staging_root: Path, code: str) -> bool:
    """Record only an enumerated outcome for a validated account-owned job."""
    if code not in _RECORDED_OUTCOMES or not isinstance(staging_root, Path):
        return False
    try:
        if (not staging_root.is_absolute() or not staging_root.is_dir()
                or not re.fullmatch(r'[a-f0-9]{24}', staging_root.name)
                or staging_root.parent.name != 'browser-login'
                or staging_root.parent.parent.name != 'work'
                or not re.fullmatch(r'[a-f0-9]{32}', staging_root.parent.parent.parent.name)):
            return False
        for part in (staging_root, *staging_root.parents):
            attrs = getattr(os.lstat(part), 'st_file_attributes', 0)
            if part.is_symlink() or attrs & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0):
                return False
        output = staging_root.parent / (staging_root.name + '.outcome.json')
        payload = json.dumps({'version': 1, 'helper_outcome': code}, separators=(',', ':')).encode('utf-8')
        fd = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
        return True
    except (OSError, ValueError, TypeError):
        return False

# Read only the visible navigation DOM in this owned window. A guest login
# button, a cookie, or another person's profile link is not an auth signal.
# The profile id must be concrete ("me" and login redirects do not qualify).
OWN_PROFILE_MARKER_JS = r"""(() => {
  if (location.origin !== 'https://www.xiaohongshu.com') return false;
  const visible = (node) => {
    const style = getComputedStyle(node);
    const rect = node.getBoundingClientRect();
    return style.display !== 'none' && style.visibility === 'visible' &&
      Number(style.opacity) > 0 && rect.width > 0 && rect.height > 0;
  };
  return Array.from(document.querySelectorAll('a[href]')).some((link) => {
    if (!visible(link)) return false;
    const nav = link.closest('nav, aside, [role="navigation"], [class*="side-bar"], [class*="sidebar"]');
    if (!nav || !visible(nav)) return false;
    const label = (link.innerText || link.getAttribute('aria-label') || '').trim();
    if (label !== '我' && label !== '我的') return false;
    const target = new URL(link.getAttribute('href'), location.href);
    return target.origin === location.origin &&
      /^\/user\/profile\/[A-Za-z0-9]{8,64}\/?$/.test(target.pathname);
  });
})()"""

# This is only a hint to publish an untrusted candidate. Site layout wrappers
# can change; authority still comes from the parent's CLI/identity/claim/commit.
OWN_PROFILE_CANDIDATE_JS = r"""(() => {
  if (location.origin !== 'https://www.xiaohongshu.com') return false;
  const visible = (node) => {
    const style = getComputedStyle(node);
    const rect = node.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' &&
      Number(style.opacity) > 0 && rect.width > 0 && rect.height > 0;
  };
  return Array.from(document.querySelectorAll('a[href]')).some((link) => {
    if (!visible(link)) return false;
    const label = (link.innerText || link.getAttribute('aria-label') || '').replace(/\s+/g, '');
    if (!['我', '我的', '我的主页', '个人主页'].includes(label)) return false;
    const target = new URL(link.getAttribute('href'), location.href);
    return target.origin === location.origin &&
      /^\/user\/profile\/[A-Za-z0-9]{8,64}\/?$/.test(target.pathname);
  });
})()"""


def _is_xhs_origin(url: str) -> bool:
    try:
        parsed = urlsplit(url)
        return (parsed.scheme == "https" and parsed.hostname == "www.xiaohongshu.com"
                and parsed.port in (None, 443) and not parsed.username
                and not parsed.password)
    except (TypeError, ValueError):
        return False


def _persistent_profile_path(staging_root: Path, profile_dir: Path) -> Path:
    """Accept only this account's fixed XHS profile, never a job or user profile."""
    try:
        expected = staging_root.parent.parent.parent / WEB_PROFILE_NAME
        if (not profile_dir.is_absolute() or profile_dir != expected
                or staging_root.parent.name != 'browser-login'
                or staging_root.parent.parent.name != 'work'):
            raise CandidateRejected('profile_path_invalid')
        for part in (expected.parent, expected):
            if (part.is_symlink() or hasattr(part, 'is_junction') and part.is_junction()
                    or part.exists() and getattr(os.lstat(part), 'st_file_attributes', 0)
                       & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                raise CandidateRejected('profile_path_invalid')
        if expected.exists() and not expected.is_dir():
            raise CandidateRejected('profile_path_invalid')
        return expected
    except (IndexError, OSError, ValueError, TypeError):
        raise CandidateRejected('profile_path_invalid') from None


class LoginWindowController:
    def __init__(self, *, mode: str, initial_url: str, staging_root: Path,
                 cancel_file: Path, guard=None, qa_tokens: tuple[str, str] | None = None,
                 natural_observer=None, before_navigation=None):
        self.mode = mode
        self.initial_url = initial_url
        self.staging_root = staging_root
        self.cancel_file = cancel_file
        self.guard = guard
        self.qa_tokens = qa_tokens
        self.window = None
        self.lock = Lock()
        self.finished = Event()
        self.phase = "waiting_for_user"
        self.finish_count = 0
        self.stage_path: Path | None = None
        self.qa_verified = False
        self.natural_observer = natural_observer
        self.before_navigation = before_navigation
        self.natural_evidence = None
        self.natural_cookies = None

    def attach(self, window):
        self.window = window

    def _guard_current(self) -> bool:
        if self.guard is None:
            return True
        try:
            return self.guard() is True
        except Exception:
            return False

    def finish(self):
        """Produce one candidate; natural mode requires current native evidence."""
        with self.lock:
            if self.phase != "waiting_for_user":
                return
            self.phase = "capturing"
            self.finish_count += 1
        if self.cancel_file.exists():
            self._close_with("cancelled")
            return
        if not self._guard_current():
            self._close_with("safety_hold")
            return
        try:
            current_url = self.window.get_current_url()
            if self.mode == "offline":
                if current_url != self.initial_url:
                    raise CandidateRejected("origin_mismatch")
                names = frozenset({PROBE_NAME, QA_PERSISTENT_NAME})
            else:
                if not _is_xhs_origin(current_url):
                    raise CandidateRejected("origin_mismatch")
                names = XHS_COOKIE_NAMES
            raw = read_owned_window_cookies(
                self.window, expected_url=current_url, allowed_names=names, timeout_s=10,
            )
            if self.mode == "offline":
                cookies = extract_scoped_cookies(
                    raw, current_url=current_url, expected_host="127.0.0.1", scheme="http",
                    allowed_names=names, required_names=names,
                    allowed_cookie_domains=frozenset({"127.0.0.1"}),
                )
                by_name = {item.name: item for item in raw if item.name in names}
                if (set(by_name) != names or not by_name[PROBE_NAME].is_session
                        or by_name[QA_PERSISTENT_NAME].is_session
                        or not all(item.httponly for item in by_name.values())):
                    raise CandidateRejected("qa_cookie_metadata_invalid")
            else:
                cookies = extract_xhs_candidate(raw, current_url=current_url)
            evidence = None
            if self.natural_observer is not None:
                evidence = self.natural_observer.bind_candidate(cookies)
                if evidence is None:
                    raise CandidateRejected('natural_identity_unverified')
            if self.cancel_file.exists():
                raise CandidateRejected("cancelled")
            if not self._guard_current():
                raise CandidateRejected("safety_hold")
            path = stage_cli_candidate_once(
                cookies, staging_root=self.staging_root, cancel_file=self.cancel_file,
                allowed_names=names,
                required_names=names if self.mode == "offline" else XHS_REQUIRED_NAMES,
            )
            with self.lock:
                if self.phase != "capturing":
                    discard_cli_candidate(path)
                    return
                self.stage_path = path
            if self.natural_observer is not None:
                if not self.natural_observer.evidence_current(evidence, cookies):
                    raise CandidateRejected('natural_identity_unverified')
                write_proof(self.staging_root, path, evidence)
                if (self.cancel_file.exists() or not self._guard_current()
                        or not self.natural_observer.evidence_current(evidence, cookies)):
                    raise CandidateRejected('natural_identity_unverified')
            if self.mode == "offline" and self.qa_tokens is not None:
                self._qa_check_stage()
            with self.lock:
                if self.phase != "capturing":
                    discard_cli_candidate(path)
                    return
                self.phase = ("candidate_staged_natural_verified" if evidence is not None
                              else "candidate_staged_unverified")
            self.finished.set()
            self._destroy_window()
        except CandidateRejected as exc:
            self._close_with(exc.code)
        except NaturalProofError as exc:
            self._close_with(exc.code)
        except Exception:
            self._close_with("candidate_capture_failed")

    def check_authenticated(self) -> bool:
        """Inspect only this window's same-origin visible navigation; never log in."""
        if self.mode != "live" or self.window is None:
            return False
        with self.lock:
            if self.phase != "waiting_for_user":
                return False
        if self.cancel_file.exists():
            self.cancel()
            return False
        if not self._guard_current():
            self._close_with("safety_hold")
            return False
        if self.natural_observer is not None:
            code = self.natural_observer.poll()
            if code == 'identity_observed':
                self.finish()
                return self.phase == 'candidate_staged_natural_verified'
            if code not in ('pending', 'guest_waiting', 'awaiting_cookie_proof',
                            'document_untrusted'):
                self._close_with(code if code in ('verification_required',
                                                  'not_authenticated')
                                 else 'natural_identity_unverified')
            return False
        try:
            before = self.window.get_current_url()
            if not _is_xhs_origin(before):
                return False
            marker = self.window.evaluate_js(OWN_PROFILE_MARKER_JS)
            if marker is not True or self.window.get_current_url() != before:
                return False
        except Exception:
            # Loading, navigation and unsupported DOM states remain pending.
            return False
        if self.cancel_file.exists():
            self.cancel()
            return False
        self.finish()
        return True

    def watch_authenticated(self):
        if self.natural_observer is not None:
            try:
                if not self.window.events.shown.wait(15):
                    raise NativeLoginError('native_pending')
                self.natural_observer.attach()
                if self.finished.is_set():
                    return
                if self.before_navigation is not None:
                    self.before_navigation(self.window,self.natural_observer)
                if self.finished.is_set() or self.cancel_file.exists() or not self._guard_current():
                    self._close_with('cancelled');return
                self.window.load_url(self.initial_url)
            except NativeLoginError as error:
                self._close_with(error.code)
                return
            except Exception:
                self._close_with('native_cdp_unavailable')
                return
        while not self.finished.wait(AUTH_CHECK_INTERVAL_SECONDS):
            self.check_authenticated()

    def _qa_check_stage(self):
        """Synthetic QA only; verifies format, never a platform identity."""
        path = self.stage_path
        if path is None or self.qa_tokens is None:
            raise CandidateRejected("qa_stage_missing")
        payload = json.loads(path.read_text(encoding="utf-8"))
        if (set(payload) != {PROBE_NAME, QA_PERSISTENT_NAME, "saved_at"}
                or payload.get(PROBE_NAME) != self.qa_tokens[0]
                or payload.get(QA_PERSISTENT_NAME) != self.qa_tokens[1]
                or not isinstance(payload.get("saved_at"), (int, float))):
            raise CandidateRejected("qa_stage_mismatch")
        self.qa_verified = True
        discard_cli_candidate(path)
        with self.lock:
            self.stage_path = None

    def _destroy_window(self):
        if self.window is not None:
            try:
                self.window.destroy()
            except Exception:
                pass

    def _close_with(self, code: str):
        with self.lock:
            if self.phase not in {"waiting_for_user", "capturing"} and not (
                self.phase == "candidate_staged_unverified" and not self.finished.is_set()
            ):
                return
            self.phase = code
        self.cleanup()
        if self.natural_observer is not None:
            self.natural_observer.cancel()
        self.finished.set()
        self._destroy_window()

    def cancel(self):
        self._close_with("cancelled")

    def on_closed(self):
        with self.lock:
            if self.phase in {"waiting_for_user", "capturing"}:
                self.phase = "closed"
        if self.phase != "candidate_staged_unverified":
            if self.phase != 'candidate_staged_natural_verified':
                self.cleanup()
        self.finished.set()

    def cleanup(self):
        with self.lock:
            path, self.stage_path = self.stage_path, None
        try:
            discard_cli_candidate(path)
            if self.natural_observer is not None:
                (self.staging_root / PROOF_NAME).unlink(missing_ok=True)
        except CandidateRejected:
            with self.lock:
                self.phase = "staging_cleanup_failed"

    def timeout(self):
        if not self.finished.wait(WINDOW_TIMEOUT_SECONDS):
            self._close_with("timeout")

    def watch_cancel(self):
        while not self.finished.wait(0.3):
            if self.cancel_file.exists():
                self.cancel()
                return



class VerificationTransition:
    """An untrusted readiness hint, never authority to mark an account ready.

    A CAPTCHA pause needs a visible challenge or login transition.
    Ordinary clicks and key presses are never evidence of verification.
    """
    def __init__(self, reason):
        self.reason=reason;self.challenge_seen=False;self.guest_seen=False
        self.baseline=None;self.clear_since=None;self.consumed=False

    def update(self, now, value):
        if self.consumed or type(value) is not dict:return False
        if any(type(value.get(k)) is not bool for k in ('logged','challenged','guest')):return False
        activity=value.get('activity')
        if type(activity) is not int or not 0<=activity<=1000000:return False
        if self.baseline is None:self.baseline=activity
        self.challenge_seen|=value['challenged'];self.guest_seen|=value['guest']
        changed=(self.reason=='authentication_required' or self.challenge_seen
            or self.guest_seen)
        if not value['logged'] or value['challenged'] or not changed:
            self.clear_since=None;return False
        if self.clear_since is None:self.clear_since=now
        if now-self.clear_since<3:return False
        self.consumed=True;return True


VERIFICATION_OBSERVATION_JS = r"""(() => {
  if(location.origin!=='https://www.xiaohongshu.com')return null;
  const key='__fangyuHumanVerificationActivityV1';
  if(!window[key]){
    window[key]={activity:0};
    for(const name of ['pointerup','keydown'])document.addEventListener(name,event=>{
      if(event.isTrusted&&window[key])window[key].activity=Math.min(1000000,window[key].activity+1);
    },true);
  }
  const visible=node=>{const r=node.getBoundingClientRect(),s=getComputedStyle(node);
    return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)>0;};
  const pageText=(document.body?.innerText||'').slice(0,100000);
  const identityChallenge=pageText.includes('请通过验证')&&
    (pageText.includes('为保护账号安全')||pageText.includes('扫码验证身份'));
  const challenged=identityChallenge||location.pathname.startsWith('/website-login/captcha')||
    Array.from(document.querySelectorAll('.security-container,.risk-control,.verify-container,.captcha-container,#captcha,iframe[src*="captcha"]')).some(visible);
  const logged=Array.from(document.querySelectorAll('a[href]')).some(link=>{
    if(!visible(link)||!['我','我的','我的主页','个人主页'].includes((link.innerText||link.getAttribute('aria-label')||'').replace(/\s+/g,'')))return false;
    const u=new URL(link.getAttribute('href'),location.href);
    return u.origin===location.origin&&/^\/user\/profile\/[A-Za-z0-9]{8,64}\/?$/.test(u.pathname);
  });
  const guest=!logged&&Array.from(document.querySelectorAll('button,#login-btn,[class*="login-btn"]')).some(node=>visible(node)&&/^(登录|登录后查看|立即登录)/.test((node.innerText||'').trim()));
  return {logged,challenged,guest,activity:window[key].activity};
})()"""

class PersistentLoginWindowController(LoginWindowController):
    """One owned browser, immutable one-use candidates, explicit retries."""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attempt = 0
        self.automatic_attempted = False
        self.explicit_capture_only = False
        self.result_consumed = 0
        self.capture_error = ''
        self.origin_seen = False
        self.profile_marker_seen = False
        self._last_observation = None
        self.verification_request = None
        self.verification_transition = None
        self.verification_poll_at = 0

    def observe(self):
        """Fixed, nonsecret progress survives candidate cleanup for diagnosis."""
        data = {'version': 1, 'phase': self.phase, 'attempt': self.attempt,
                'automatic_attempted': self.automatic_attempted,
                'same_origin_seen': self.origin_seen,
                'profile_marker_seen': self.profile_marker_seen,
                'capture_error': self.capture_error}
        if data == self._last_observation:
            return
        temporary = None
        created_identity = None
        try:
            if (not self.staging_root.is_dir() or self.staging_root.is_symlink() or
                    not re.fullmatch(r'[a-f0-9]{24}', self.staging_root.name) or
                    self.staging_root.parent.name != 'browser-login'):
                return
            parents = (self.staging_root, *self.staging_root.parents)
            parent_ids = {}
            for part in parents:
                info = os.lstat(part)
                if (not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode) or
                        getattr(info, 'st_file_attributes', 0) &
                        getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                    return
                parent_ids[part] = (info.st_dev, info.st_ino)
            path = self.staging_root.parent / (self.staging_root.name + '.browser.json')
            def target_plain():
                try:
                    info = os.lstat(path)
                except FileNotFoundError:
                    return True
                return (stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
                    not stat.S_ISLNK(info.st_mode) and not getattr(info, 'st_file_attributes', 0) &
                    getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))
            if not target_plain():
                return
            temporary = path.with_name(path.name + '.' + secrets.token_hex(12) + '.tmp')
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                         getattr(os, 'O_NOFOLLOW', 0), 0o600)
            with os.fdopen(fd, 'w', encoding='ascii') as stream:
                opened = os.fstat(stream.fileno())
                created_identity = (opened.st_dev, opened.st_ino)
                json.dump(data, stream, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            for part, identity in parent_ids.items():
                info = os.lstat(part)
                if ((info.st_dev, info.st_ino) != identity or not stat.S_ISDIR(info.st_mode) or
                        stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) &
                        getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                    return
            if not target_plain():
                return
            os.replace(temporary, path)
            temporary = None
            self._last_observation = data
        except OSError:
            pass
        finally:
            if temporary is not None and created_identity is not None:
                try:
                    info = os.lstat(temporary)
                    if (info.st_dev, info.st_ino) == created_identity and stat.S_ISREG(info.st_mode):
                        temporary.unlink()
                except OSError:
                    pass

    def timeout(self):
        # Human login and CAPTCHA work has no artificial expiry. The parent
        # still checks fresh access and safety before every status/commit.
        return

    def _mark_cancelled(self):
        try:
            fd=os.open(self.cancel_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
        except FileExistsError:
            pass
        except OSError:
            pass

    def _close_with(self, code):
        with self.lock:
            if self.finished.is_set():
                return
            self.phase=code
            self.finished.set()
        self._mark_cancelled()
        self.cleanup()
        self.observe()
        self._destroy_window()

    def on_closed(self):
        # A native close is a human cancellation of an in-flight candidate.
        # The parent checks this marker before claim and commit as well.
        self._mark_cancelled()
        super().on_closed()
        self.observe()

    def finish(self, *, explicit=False):
        with self.lock:
            if self.phase not in {'waiting_for_user', 'waiting_manual_check'} and not (
                    explicit is True and self.phase == 'connected'):
                return
            self.phase = 'capturing'
            self.attempt += 1
            attempt = self.attempt
        self.capture_error = ''
        self.observe()
        if self.cancel_file.exists() or not self._guard_current():
            self._close_with('cancelled')
            return
        path = None
        try:
            current_url = self.window.get_current_url()
            if not _is_xhs_origin(current_url):
                raise CandidateRejected('origin_mismatch')
            raw = read_owned_window_cookies(self.window, expected_url=current_url,
                allowed_names=XHS_COOKIE_NAMES, timeout_s=10)
            cookies = extract_xhs_candidate(raw, current_url=current_url)
            if self.cancel_file.exists() or not self._guard_current():
                raise CandidateRejected('cancelled')
            candidate_root = self.staging_root / ('attempt-%06d' % attempt)
            candidate_root.mkdir(mode=0o700, exist_ok=False)
            path = stage_cli_candidate_once(cookies, staging_root=candidate_root,
                cancel_file=candidate_root / 'cancel.flag')
            if self.cancel_file.exists() or not self._guard_current():
                raise CandidateRejected('cancelled')
            ready = self.staging_root / ('candidate-%06d.ready.json' % attempt)
            data = json.dumps({'version': 1, 'attempt': attempt,
                               'candidate': candidate_root.name}).encode('ascii')
            fd = os.open(ready, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(data); stream.flush(); os.fsync(stream.fileno())
            with self.lock:
                self.stage_path = path
                self.phase = 'candidate_ready'
            self.observe()
        except CandidateRejected as error:
            discard_cli_candidate(path)
            if error.code == 'cancelled':
                self._close_with('cancelled')
            else:
                self.capture_error = error.code if error.code in _RECORDED_OUTCOMES else 'candidate_capture_failed'
                self.phase = 'waiting_manual_check'
                self.observe()
                self._retry_title('请继续完成网页验证')
        except Exception:
            discard_cli_candidate(path)
            self.phase = 'waiting_manual_check'
            self.capture_error = 'candidate_capture_failed'
            self.observe()
            self._retry_title('本次核对未完成')

    def _retry_title(self,message):
        self._title(message+('；请回到工作台点击“我已完成验证”' if self.explicit_capture_only
            else '；完成后点 账号操作 → 核对连接'))

    def _title(self, value):
        try: self.window.set_title(value)
        except Exception: pass

    def check_authenticated(self):
        if self.automatic_attempted:
            return False
        try:
            self.origin_seen = self.origin_seen or _is_xhs_origin(self.window.get_current_url())
            if (not _is_xhs_origin(self.window.get_current_url()) or
                    self.window.evaluate_js(OWN_PROFILE_CANDIDATE_JS) is not True):
                self.observe()
                return False
        except Exception:
            return False
        self.automatic_attempted = True
        self.profile_marker_seen = True
        self.finish()
        return False

    def watch_verification(self):
        """Observe a human-owned page; no clicks, answers, fetches or API polling."""
        now=time.monotonic()
        if now<self.verification_poll_at:return
        self.verification_poll_at=now+.8
        request=self.staging_root/'verification-watch.json'
        try:
            if request.is_symlink() or request.stat().st_size>12288:return
            value=json.loads(request.read_text('utf-8'))
            if (type(value) is not dict or set(value)!={'version','request','reason','url'}
                    or value['version']!=1 or not re.fullmatch(r'[a-f0-9]{32}',str(value['request']))
                    or value['reason'] not in ('authentication_required','verification_required')
                    or type(value['url']) is not str or len(value['url'])>8192):return
            target=urlsplit(value['url'])
            if (not _is_xhs_origin(value['url']) or target.fragment
                    or not re.fullmatch(r'/explore(?:/[A-Za-z0-9]{1,160})?/?',target.path)):return
            if self.window is None or not _is_xhs_origin(self.window.get_current_url()):return
            sample=self.window.evaluate_js(VERIFICATION_OBSERVATION_JS)
            if value['request']!=self.verification_request:
                self.verification_request=value['request']
                self.verification_transition=VerificationTransition(value['reason'])
                self._title('请完成此页面的验证；通过后工作台会自动继续采集')
                # Show the affected note once, without disturbing a challenge
                # already being completed by the human in this same window.
                if (value['reason']=='verification_required' and type(sample) is dict
                        and sample.get('challenged') is False
                        and self.window.get_current_url()!=value['url']):
                    self.window.load_url(value['url']);return
            if not self.verification_transition.update(time.monotonic(),sample):return
            ready=self.staging_root/('verification-ready-'+value['request']+'.json')
            body={'version':1,'request':value['request'],'state':'ready'}
            with ready.open('x',encoding='ascii') as stream:json.dump(body,stream)
        except Exception:
            # DOM/navigation readiness is not authentication; parent checks
            # status, same UID, account claim and commit after one hint only.
            return

    def watch_requests(self):
        while not self.finished.wait(.2):
            if self.cancel_file.exists():
                self.cancel(); return
            focus = self.staging_root / 'focus.flag'
            if focus.is_file() and not focus.is_symlink():
                focus.unlink(missing_ok=True)
                try: self.window.restore(); self.window.show()
                except Exception: pass
            capture = self.staging_root / 'capture.flag'
            if capture.is_file() and not capture.is_symlink():
                # A reopened owned profile may still be at about:blank. Keep
                # this single explicit signal until its XHS navigation is ready.
                try:ready=_is_xhs_origin(self.window.get_current_url())
                except Exception:ready=False
                if ready:
                    capture.unlink(missing_ok=True)
                    self.finish(explicit=True)
            self.watch_verification()
            if self.attempt <= self.result_consumed:
                continue
            result = self.staging_root / ('result-%06d.json' % self.attempt)
            try:
                if result.is_symlink() or result.stat().st_size > 1024:
                    continue
                data = json.loads(result.read_text('ascii'))
                if (type(data) is not dict or set(data) != {'version', 'attempt', 'status'} or
                        data['version'] != 1 or data['attempt'] != self.attempt or
                        data['status'] not in {'completed', 'failed'}):
                    continue
            except (OSError, ValueError):
                continue
            self.result_consumed = self.attempt
            self.stage_path = None
            self.phase = 'connected' if data['status'] == 'completed' else 'waiting_manual_check'
            self.observe()
            if self.phase == 'connected':self._title('已连接小红书；此窗口会保留，可手动处理网页验证')
            else:self._retry_title('连接尚未通过')


class ManualVerificationWindowController(LoginWindowController):
    """Human webpage only: no capture, identity probe, candidate or login commit."""
    def finish(self, **_kwargs):
        return False

    def check_authenticated(self):
        return False

    def timeout(self):
        return

    def watch_requests(self):
        while not self.finished.wait(.2):
            focus=self.staging_root/'focus.flag'
            if focus.is_file() and not focus.is_symlink():
                focus.unlink(missing_ok=True)
                try:self.window.restore();self.window.show()
                except Exception:pass


def run_login_window(*, mode: str, staging_root: Path, cancel_file: Path,
                     profile_dir: Path | None = None,
                     guard=None, qa_auto_finish: bool = False,
                     natural_identity: bool = False, before_navigation=None,
                     keep_open: bool = False, verification_only: bool = False,
                     explicit_capture_only: bool = False) -> str:
    """Run one browser window, returning only a fixed status code."""
    if mode not in {"offline", "live"}:
        return "mode_invalid"
    if mode == "live" and qa_auto_finish:
        return "qa_mode_invalid"
    if (type(verification_only) is not bool or verification_only and
            (mode!='live' or not keep_open or profile_dir is None or natural_identity or qa_auto_finish)):
        return 'mode_invalid'
    if (type(explicit_capture_only) is not bool or explicit_capture_only and
            (not keep_open or verification_only or natural_identity or mode!='live')):
        return 'mode_invalid'
    if type(keep_open) is not bool or keep_open and (mode != 'live' or profile_dir is None or natural_identity):
        return 'mode_invalid'
    if natural_identity and (mode != 'live' or profile_dir is None):
        return 'mode_invalid'
    try:
        validate_job_paths(staging_root, cancel_file)
    except CandidateRejected as exc:
        return exc.code
    if cancel_file.exists():
        return "cancelled"
    if (staging_root / ".xiaohongshu-cli").exists():
        return "staging_exists"
    persistent_profile = mode == 'live' and profile_dir is not None
    natural_spec = None
    if natural_identity:
        try:
            natural_spec = read_spec(staging_root)
        except NaturalProofError as error:
            return error.code
    if persistent_profile:
        try:
            profile_dir = _persistent_profile_path(staging_root, profile_dir)
            if verification_only and not profile_dir.is_dir():return 'profile_path_invalid'
        except CandidateRejected as exc:
            return exc.code
    if mode == "live" and guard is not None and not callable(guard):
        return "guard_required"
    if guard is not None:
        try:
            if guard() is not True:
                return "safety_hold"
        except Exception:
            return "safety_hold"

    # Import only after mode/path checks; offline QA stays on localhost.
    import webview
    from webview.menu import Menu, MenuAction

    server = None
    thread = None
    qa_tokens = None
    if mode == "offline":
        qa_tokens = (secrets.token_urlsafe(24), secrets.token_urlsafe(24))
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(*qa_tokens))
        server.daemon_threads = True
        thread = Thread(target=server.serve_forever, name="owned-login-qa-http", daemon=True)
        thread.start()
        initial_url = f"http://127.0.0.1:{server.server_port}/"
    else:
        initial_url = XHS_ENTRY_URL

    observer = (NativeLoginObserver(None, job_id=natural_spec['job_id'],
                                    bound_uid=natural_spec['bound_uid'])
                if natural_spec is not None else None)
    controller_type = (ManualVerificationWindowController if verification_only else
                       PersistentLoginWindowController if keep_open else LoginWindowController)
    controller = controller_type(mode=mode, initial_url=initial_url,
                                       staging_root=staging_root, cancel_file=cancel_file,
                                       guard=guard,
                                       qa_tokens=qa_tokens if qa_auto_finish else None,
                                       natural_observer=observer,before_navigation=before_navigation)
    if explicit_capture_only:
        controller.automatic_attempted = True
        controller.explicit_capture_only = True
    actions = [MenuAction('核对连接', lambda: controller.finish(explicit=True))] if keep_open and not verification_only and not explicit_capture_only else []
    menu = [Menu("账号操作", actions + [MenuAction("取消", controller.cancel)])]
    code = "window_failed"
    try:
        window = webview.create_window(
            '小红书人工验证；完成后返回工作台检查连接' if verification_only else
            '小红书网页登录；可手动完成验证码，窗口会保留' if keep_open else
            "请用手机扫码；网页显示本人账号后自动核对",
            'about:blank' if natural_identity else initial_url,
            width=760, height=700, js_api=None, menu=menu,
        )
        controller.attach(window)
        if observer is not None:
            observer.window = window
        window.events.closed += controller.on_closed
        if qa_auto_finish:
            # Python QA callback, no webpage JS bridge or real login.
            window.events.loaded += controller.finish
        Thread(target=controller.timeout, name="owned-login-timeout", daemon=True).start()
        Thread(target=controller.watch_cancel, name="owned-login-cancel", daemon=True).start()
        if mode == "live" and not verification_only:
            Thread(target=controller.watch_authenticated,
                   name="owned-login-auth-marker", daemon=True).start()
        if keep_open:
            Thread(target=controller.watch_requests,
                   name='owned-login-requests', daemon=True).start()
        # New live callers reuse their account-owned profile. Legacy live
        # callers and offline QA use disposable private profiles in the job.
        # Candidate credentials always stay in the separate job staging path.
        if persistent_profile:
            profile_dir.mkdir(mode=0o700, exist_ok=True)
            _persistent_profile_path(staging_root, profile_dir)
        profile_context = (nullcontext(profile_dir) if persistent_profile else
                           tempfile.TemporaryDirectory(prefix="owned-login-profile-", dir=staging_root))
        with profile_context as profile_root:
            storage_path = Path(profile_root) if persistent_profile else Path(profile_root) / 'profile'
            webview.start(gui="edgechromium", private_mode=not persistent_profile,
                          storage_path=str(storage_path), debug=False)
        code = controller.phase
    except Exception:
        code = "window_failed"
    finally:
        controller.finished.set()
        if observer is not None:
            observer.close()
        if code not in ("candidate_staged_unverified", 'candidate_staged_natural_verified'):
            controller.cleanup()
        if server is not None:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
    if qa_auto_finish:
        return ("qa_finish_once_ok" if controller.qa_verified
                and controller.finish_count == 1 and controller.stage_path is None
                and code == "candidate_staged_unverified" else "qa_finish_failed")
    return code


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Owned browser login preparation")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--offline", action="store_true")
    mode.add_argument("--live", action="store_true")
    parser.add_argument("--staging-dir", type=Path)
    parser.add_argument("--cancel-file", type=Path)
    parser.add_argument("--profile-dir", type=Path)
    parser.add_argument("--qa-auto-finish", action="store_true")
    parser.add_argument('--natural-identity', action='store_true')
    parser.add_argument('--keep-open', action='store_true')
    parser.add_argument('--verification-only', action='store_true')
    parser.add_argument('--explicit-capture-only', action='store_true')
    args = parser.parse_args(argv)
    if args.live:
        if args.staging_dir is None or args.cancel_file is None:
            code = "arguments_invalid"
        else:
            code = run_login_window(mode="live", staging_root=args.staging_dir,
                                    cancel_file=args.cancel_file, profile_dir=args.profile_dir,
                                    natural_identity=args.natural_identity,
                                    keep_open=args.keep_open, verification_only=args.verification_only,
                                    explicit_capture_only=args.explicit_capture_only)
    elif (args.staging_dir is not None or args.cancel_file is not None
          or args.profile_dir is not None or args.natural_identity or args.keep_open or args.verification_only or args.explicit_capture_only):
        code = "arguments_invalid"
    else:
        with tempfile.TemporaryDirectory(prefix="offline-login-job-", dir=HERE) as root:
            job = Path(root)
            code = run_login_window(mode="offline", staging_root=job,
                                    cancel_file=job / "cancel.flag",
                                    qa_auto_finish=args.qa_auto_finish)
    if args.live and args.staging_dir is not None:
        record_live_outcome(args.staging_dir, code)
    print(code)
    return 0 if code in {"candidate_staged_unverified",
                         'candidate_staged_natural_verified', "qa_finish_once_ok"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
