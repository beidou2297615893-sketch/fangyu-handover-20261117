"""Current owned browser coordination. Platform I/O remains behind an authorized driver."""
from copy import deepcopy
import hashlib
import json
import threading
import time
from uuid import uuid4

ACTIONS=frozenset(('browser_session_open','browser_session_check','browser_session_status','browser_acquisition_start'))
BASE={'storeId','platform'}
CONTEXT=BASE|{'contextId','revision','requestId'}
START=CONTEXT|{'expectedRevision','region','time','source','commentWindow','execution','previewDigest'}
MESSAGES={
 'BROWSER_LOGIN_REQUIRED':'请在当前网页完成本人登录，再点击“我已完成登录/验证”。',
 'BROWSER_SCOPE_CHANGED':'员工、门店或网页窗口已变化，请打开当前门店的网页后再操作。',
 'BROWSER_IDENTITY_CHANGED':'当前网页身份已变化，原任务与断点保留；请重新核对本次条件后开始。',
 'BROWSER_ACCOUNT_FORBIDDEN':'当前网页身份未获此员工或门店授权，请联系管理员核对。',
 'BROWSER_ACCOUNT_LIMIT':'当前企业可添加的账号数量已达上限，尚未创建新任务；请联系管理员处理。',
 'BROWSER_DEVICE_NOT_READY':'当前电脑的企业连接或读取许可尚未就绪，请先恢复工作连接。',
 'BROWSER_CLOUD_CLAIM_FAILED':'网页登录已通过，但企业账号身份登记尚未确认；请联系管理员核对登记或占用情况。',
 'BROWSER_TIMEOUT':'本次网页登录核对超时，原任务与断点保留；请先刷新操作状态。',
 'BROWSER_VERIFICATION_REQUIRED':'当前网页仍需平台验证，请在此网页完成后再核对；原任务与断点保留。',
 'BROWSER_IDENTITY_CONFLICT':'此网页登录身份存在重复账号登记，请联系管理员处理。',
 'BROWSER_RESULT_UNCONFIRMED':'原操作结果尚未确认，请先刷新本次状态；不会重复提交。',
 'BROWSER_COMMIT_FAILED':'网页身份已读取，但会话尚未安全保存；原任务与断点保留。',
 'BROWSER_REQUEST_CHANGED':'本次条件已变化，请重新核对后开始。',
 'BROWSER_UNSUPPORTED':'当前平台或读取路线尚不支持当前网页获客。',
 'BROWSER_SOURCE_RECOVERY_UNSUPPORTED':'当前来源的验证恢复暂不支持此网页入口，原任务与断点已保留。',
 'BROWSER_BUSY':'当前网页仍在核对本次操作，请等待结果。',
 'BROWSER_CHECK_FAILED':'本次网页核对未完成，原账号、任务和断点保留。'}
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()).hexdigest()
SAFE_ERRORS={'AUTH_REQUIRED':'BROWSER_SCOPE_CHANGED','STORE_FORBIDDEN':'BROWSER_ACCOUNT_FORBIDDEN',
 'ACCOUNT_FORBIDDEN':'BROWSER_ACCOUNT_FORBIDDEN','ACCOUNT_SCOPE_UNCONFIRMED':'BROWSER_RESULT_UNCONFIRMED',
 'DEVICE_NOT_READY':'BROWSER_DEVICE_NOT_READY','DEVICE_LEASE_UNCONFIRMED':'BROWSER_DEVICE_NOT_READY',
 'DEVICE_SESSION_UNAVAILABLE':'BROWSER_DEVICE_NOT_READY','COLLECTION_BUSY':'BROWSER_BUSY',
 'RESULT_UNCONFIRMED':'BROWSER_RESULT_UNCONFIRMED','REQUEST_UNCONFIRMED':'BROWSER_RESULT_UNCONFIRMED',
 'COLLECTION_RESULT_UNCONFIRMED':'BROWSER_RESULT_UNCONFIRMED','VERIFICATION_CLOUD_CLAIM_FAILED':'BROWSER_CLOUD_CLAIM_FAILED',
 'VERIFICATION_COMMIT_FAILED':'BROWSER_COMMIT_FAILED','TASK_SCOPE_CHANGED':'BROWSER_SCOPE_CHANGED'}
class BrowserError(ValueError):
 def __init__(self,code):self.code=code if code in MESSAGES else 'BROWSER_CHECK_FAILED';self.status=409;self.mutation_committed=False;super().__init__(MESSAGES[self.code])

class BrowserSessions:
 def __init__(self,driver):self.driver=driver;self.lock=threading.RLock();self.contexts={};self.threads=[];self.closed=False
 def _key(self,user):return digest(self.driver.scope(user))
 def _context(self,user):return self.contexts.get(self._key(user))
 def _view(self,user,ctx=None,request_id=None):
  ctx=ctx or self._context(user)
  actor={'username':user['username'],'storeId':user.get('_workbench_store_id','')}
  if not ctx:
   prior=self.driver.load_intent(digest([self.driver.scope(user),request_id])) if request_id else None
   operation=self._reconcile(None,user,prior) if prior else None
   return dict(id='',revision=0,platform='xiaohongshu',actor=actor,windowOpen=False,state='closed',identity=None,resolvedAccount=None,operation=operation,currentTask=None)
  with ctx['lock']:
   operation=deepcopy(ctx.get('operation'));task=None
   if request_id and (not operation or operation['requestId']!=request_id):
    prior=self.driver.load_intent(digest([ctx['scope'],request_id]))
    operation=self._reconcile(ctx,user,prior) if prior else None
   elif operation and operation['state']=='unknown':
    prior=self.driver.load_intent(digest([ctx['scope'],operation['requestId']]))
    operation=self._reconcile(ctx,user,prior) if prior else operation
   state=ctx['state'];alive=self.driver.alive(ctx)
   if ctx.get('taskId') and ctx.get('account',{}).get('id')==ctx.get('taskAccountId'):
    task=self.driver.task_view(ctx,ctx['taskId'])
    scope=task.get('taskScope') or {}
    if scope.get('accountId')!=ctx.get('taskAccountId') or scope.get('storeId')!=ctx['scope']['store'] or scope.get('platform')!='xiaohongshu':raise BrowserError('BROWSER_SCOPE_CHANGED')
    if task.get('platformError',{}):
     if task['platformError'].get('category') in ('verification_required','authentication_required'):state='needs_verification'
    elif not ctx['busy'] and task.get('status') in ('running','queued','resuming'):state='reading'
   if not alive and state not in ('opening',):state='closed'
   return dict(id=ctx['id'],revision=ctx['revision'],platform='xiaohongshu',actor=actor,windowOpen=bool(alive and ctx.get('windowOpen')),
    state=state,identity={'displayName':ctx['identity']['nickname']} if ctx.get('identity') else None,
    resolvedAccount={**{key:ctx['account'][key] for key in ('id','name','platform')},'name':ctx['identity']['nickname'] if ctx.get('identity') else ctx['account']['name']} if ctx.get('account') else None,
    operation=operation,currentTask=deepcopy(task))
 def snapshot(self,user):return self._view(user)
 def _reconcile(self,ctx,user,intent):
  op=deepcopy(intent['operation'])
  if intent['state'] in ('pending','unknown') and (ctx is None or not ctx['busy']):
   scope=ctx or {'user':user,'scope':self.driver.scope(user)}
   receipt=self.driver.receipt(scope,op['requestId'])
   if receipt and receipt.get('state')=='accepted' and receipt.get('taskId'):
    op.update(state='accepted',phase='started',taskId=receipt['taskId'],taskCreated=True,mutationCommitted=True,errorCode='',message='已核对原采集请求，原任务已提交。')
   else:op.update(state='unknown',phase='reconcile',mutationCommitted=None,errorCode='BROWSER_RESULT_UNCONFIRMED',message=MESSAGES['BROWSER_RESULT_UNCONFIRMED'])
  return op
 def dispatch(self,action,user,token,data):
  if self.closed:raise BrowserError('BROWSER_SCOPE_CHANGED')
  if action not in ACTIONS or type(data) is not dict:raise BrowserError('BROWSER_REQUEST_CHANGED')
  fields=BASE|{'contextId','requestId'} if action=='browser_session_status' else BASE|{'requestId'} if action=='browser_session_open' else START if action=='browser_acquisition_start' else CONTEXT
  if set(data)-fields or data.get('platform')!='xiaohongshu' or data.get('storeId')!=user.get('_workbench_store_id'):raise BrowserError('BROWSER_SCOPE_CHANGED')
  if not self.driver.supported():raise BrowserError('BROWSER_UNSUPPORTED')
  if action=='browser_session_status':return {'browserContext':self._view(user,request_id=data.get('requestId'))}
  request=data.get('requestId')
  if not isinstance(request,str) or not 1<=len(request)<=160 or any(ord(c)<32 for c in request):raise BrowserError('BROWSER_REQUEST_CHANGED')
  with self.lock:
   ctx=self._context(user)
   if action=='browser_session_open':
    if ctx and self.driver.alive(ctx):
     if ctx['busy'] or (ctx.get('operation') or {}).get('state') in ('pending','unknown'):raise BrowserError('BROWSER_BUSY')
     ident=digest([ctx['scope'],request]);signature=digest([action,{k:v for k,v in data.items() if k!='requestId'}])
     old=self.driver.load_intent(ident)
     if old and old['signature']!=signature:raise BrowserError('BROWSER_REQUEST_CHANGED')
     self.driver.guard(ctx);self.driver.focus(ctx)
     op=dict(requestId=request,action='open',state='accepted',phase='focused',errorCode='',message='当前网页已打开。',taskCreated=False,mutationCommitted=False)
     self.driver.save_intent(dict(id=ident,tenant_id=user['tenant_id'],owner=user['username'],storeId=data['storeId'],signature=signature,uidHash='',accountId='',state='accepted',operation=op))
     return {'browserContext':self._view(user,ctx,request_id=request)}
    revision=ctx['revision']+1 if ctx else 1
    ctx=dict(id=uuid4().hex,revision=revision,scope=self.driver.scope(user),user=deepcopy(user),token=token,state='opening',lock=threading.RLock(),windowOpen=False,operation=None,identity=None,account=None,taskId=None,taskConditions=None,busy=False)
    self.contexts[self._key(user)]=ctx
    ctx['isCurrent']=lambda:self.contexts.get(digest(ctx['scope'])) is ctx and not self.closed
   else:
    if not ctx or data.get('contextId')!=ctx['id'] or data.get('revision')!=ctx['revision']:raise BrowserError('BROWSER_SCOPE_CHANGED')
    self.driver.guard(ctx)
   ident=digest([ctx['scope'],request]);signature=digest([action,{k:v for k,v in data.items() if k not in ('requestId','contextId','revision')}])
   old=self.driver.load_intent(ident)
   if old:
    if old['signature']!=signature:raise BrowserError('BROWSER_REQUEST_CHANGED')
    if old['state'] in ('accepted','unknown','pending','failed') and action!='browser_session_open':
     ctx['operation']=self._reconcile(ctx,user,old);return {'browserContext':self._view(user,ctx)}
   if ctx['busy']:raise BrowserError('BROWSER_BUSY')
   op=dict(requestId=request,action='open' if action.endswith('_open') else 'start' if action=='browser_acquisition_start' else 'check',state='pending',phase='opening' if action.endswith('_open') else 'checking',errorCode='',message='正在打开当前网页…' if action.endswith('_open') else '正在核对当前网页身份…',taskCreated=False,mutationCommitted=False)
   intent=old or dict(id=ident,tenant_id=user['tenant_id'],owner=user['username'],storeId=data['storeId'],signature=signature,uidHash='',accountId='',state='pending')
   intent.update(state='pending',operation=deepcopy(op));self.driver.save_intent(intent)
   ctx.update(operation=op,busy=True,state='opening' if action.endswith('_open') else 'checking')
   thread=threading.Thread(target=self._run,args=(ctx,action,deepcopy(data),intent),daemon=True,name='browser-first-operation');self.threads.append(thread);thread.start()
  return {'browserContext':self._view(user,ctx)}
 def _run(self,ctx,action,data,intent):
  created=False;dispatching=False;candidates=[]
  try:
   if action=='browser_session_open':
    self.driver.open(ctx);ctx['state']='waiting_login';self._finish(ctx,intent,'accepted','opened','当前网页已打开，请完成本人登录。');return
   self.driver.guard(ctx)
   if not self.driver.alive(ctx):raise BrowserError('BROWSER_LOGIN_REQUIRED')
   first=self.driver.capture(ctx);candidates.append(first);identity=self.driver.discover(ctx,first)
   if not identity:raise BrowserError('BROWSER_LOGIN_REQUIRED')
   self.driver.discard(ctx,first)
   uid_hash=digest(identity['uid'])
   if intent.get('uidHash') and intent['uidHash']!=uid_hash:raise BrowserError('BROWSER_IDENTITY_CHANGED')
   intent['uidHash']=uid_hash;self.driver.save_intent(intent)
   self.driver.guard(ctx);account=self.driver.resolve(ctx,identity,intent)
   second=self.driver.capture(ctx);candidates.append(second);fresh=self.driver.discover(ctx,second)
   if not fresh or fresh['uid']!=identity['uid']:raise BrowserError('BROWSER_IDENTITY_CHANGED')
   self.driver.guard(ctx)
   conditions={key:value for key,value in data.items() if key not in ('contextId','revision','requestId')}
   same=ctx.get('taskId') and ctx.get('taskAccountId')==account['id']
   same_conditions=action=='browser_session_check' or ctx.get('taskConditions')==digest(conditions)
   if ctx.get('taskId') and not same:
    ctx.setdefault('history',[]).append(ctx['taskId']);ctx['taskId']=None;ctx['taskAccountId']=None;ctx['taskConditions']=None
   current=self.driver.task_view(ctx,ctx['taskId']) if same else None
   if current:
    scope=current.get('taskScope') or {}
    if scope.get('accountId')!=account['id'] or scope.get('storeId')!=ctx['scope']['store'] or scope.get('platform')!='xiaohongshu':raise BrowserError('BROWSER_SCOPE_CHANGED')
    if current.get('status') in ('running','queued','resuming','pausing','stopping'):
     if not same_conditions:raise BrowserError('BROWSER_BUSY')
     ctx['identity']=fresh;ctx['account']=account;ctx['state']='reading';self._finish(ctx,intent,'accepted','reading','当前网页账号的原任务正在读取。',ctx['taskId']);return
   if action=='browser_acquisition_start' and hasattr(self.driver,'admit'):self.driver.admit(ctx,account,data)
   verified=self.driver.verification_context(ctx,account) if same and same_conditions else None
   self.driver.commit(ctx,second,account,verified=verified)
   self.driver.guard(ctx);ctx['identity']=fresh;ctx['account']=account
   if same and same_conditions and self.driver.task_view(ctx,ctx['taskId']).get('canResume'):
    dispatching=True;intent.update(dispatchStarted=True,dispatchKind='resume');self.driver.save_intent(intent);self.driver.guard(ctx)
    self.driver.resume(ctx,ctx['taskId']);ctx['state']='reading';self._finish(ctx,intent,'accepted','resumed','当前网页账号已核对，原任务已继续。',ctx['taskId']);return
   if action=='browser_acquisition_start':
    ctx['state']='starting';dispatching=True;intent.update(dispatchStarted=True,dispatchKind='start');self.driver.save_intent(intent);self.driver.guard(ctx)
    task_id=self.driver.start(ctx,account,data);created=True;self.driver.guard(ctx)
    ctx['taskId']=task_id;ctx['taskAccountId']=account['id'];ctx['taskConditions']=digest(conditions);ctx['state']='reading';self._finish(ctx,intent,'accepted','started','当前网页账号的采集任务已提交。',task_id,True)
   else:ctx['state']='ready';self._finish(ctx,intent,'accepted','ready','当前网页账号已核对，可以开始读取。')
  except Exception as error:
   code=getattr(error,'code','BROWSER_CHECK_FAILED');code=code if code in MESSAGES else SAFE_ERRORS.get(code,'BROWSER_CHECK_FAILED')
   unknown=created or getattr(error,'mutation_committed',False) is not False or dispatching and not hasattr(error,'mutation_committed')
   waiting=code=='BROWSER_LOGIN_REQUIRED';ctx['state']='waiting_login' if waiting else 'needs_verification' if code=='BROWSER_VERIFICATION_REQUIRED' else 'failed'
   self._finish(ctx,intent,'unknown' if unknown else 'waiting_login' if waiting else 'failed','waiting_login' if waiting else 'failed',MESSAGES[code],error=code,unknown=unknown)
  finally:
   for candidate in candidates:
    try:self.driver.discard(ctx,candidate)
    except Exception:pass
   ctx['busy']=False
 def _finish(self,ctx,intent,state,phase,message,task_id=None,created=False,error='',unknown=False):
  op=dict(requestId=intent['operation']['requestId'],action=intent['operation']['action'],state=state,phase=phase,errorCode=error,message=message,taskCreated=created,mutationCommitted=None if unknown else bool(task_id))
  if task_id:op['taskId']=task_id
  intent.update(state=state,operation=op,taskId=task_id or intent.get('taskId',''));self.driver.save_intent(intent);ctx['operation']=deepcopy(op)
 def close(self):
  self.closed=True
  for ctx in self.contexts.values():self.driver.close(ctx)
