"""Account-scoped voice references for existing SOPs; no model or delivery.

The checked-in MIT upstream parser is reused unchanged. Persistence adapts to
the product's Store transaction, rather than reading the upstream global home
directory or mixing this customer's references with the component library.
The HTTP caller still owns session/selected-store authorization.
"""
from copy import deepcopy
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import unicodedata

ENTITY = 'ui_reply_voice_samples_v1'
COMPANY = 'fangyu-apartment-client'
CONTRACT = 'fangyu-own-voice-samples-v1'
LEARNING_CONTRACT = 'fangyu-confirmed-reply-learning-v1'
REVIEW_ENTITY = 'ui_reply_requests_v1'
SOURCE = {'repo':'xintu1314/xhs-creator-suite',
          'commit':'babb659a96af4d8886b8f343ee8c3c3c32a66656',
          'license':'MIT', 'upstream':'xhs-note-writer/scripts/ingest_style_reference.py'}
PARSER_SHA = '3b20d9faee0669b503f6532ee71fcdcc9e481b45724b0acf6b5b6e7abb806c8a'
LICENSE_SHA = '96eb4018645eabca591866033cdccd1e2a9ac19dec3538a265328eeafa943c16'


class VoiceSampleError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.status = (403 if code in ('VOICE_FORBIDDEN','VOICE_ADMIN_REQUIRED','VOICE_ACCOUNT_CHANGED')
            else 409 if code in ('VOICE_RECORD_INVALID','VOICE_REVISION_CONFLICT','VOICE_SAMPLE_MISSING')
            else 503 if code == 'VOICE_COMPONENT_CHANGED' else 400)


def _fail(code, message):
    raise VoiceSampleError(code, message)


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,
        separators=(',', ':'),allow_nan=False).encode()).hexdigest()


def _text(value, maximum, name, *, empty=False, multiline=False):
    if (not isinstance(value,str) or len(value)>maximum or not empty and not value.strip()
            or any(unicodedata.category(c) in ('Cf','Cs') or ord(c)<32 and
                (not multiline or c not in '\n\r\t') for c in value)):
        _fail('VOICE_INPUT_INVALID',name+'格式无效')
    return value


def _style_reference(value):
    """A bounded data reference, never a prompt or a source of business facts."""
    value=re.sub(r'https?://[^\s，。；;]+|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '（链接略）', value)
    value=re.sub(r'(?i)(?:微信|微x|vx|v信|手机号|电话)\s*[:：]?\s*[A-Za-z0-9_+@.\-]+', '（联系方式略）', value)
    value=re.sub(r'\d+(?:[.,]\d+)*', '（数值略）', value)
    return value[:500]


@dataclass(frozen=True)
class VoiceScope:
    tenant_id: str
    store_id: str
    account_id: str
    platform: str
    company_id: str = COMPANY

    def checked(self):
        if self.company_id != COMPANY or self.platform not in ('xiaohongshu','douyin'):
            _fail('VOICE_SCOPE_INVALID','口吻样本归属无效')
        for key in ('tenant_id','store_id','account_id'):
            value=getattr(self,key)
            if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',value):
                _fail('VOICE_SCOPE_INVALID','口吻样本归属无效')
        return asdict(self)


class VoiceSampleLibrary:
    def __init__(self, store, *, vendor_dir=None, authority_check=None):
        self.store = store
        self.authority_check = authority_check
        parser = (Path(vendor_dir) if vendor_dir is not None else
            Path(__file__).parent/'voice_samples_vendor')/'ingest_style_reference.py'
        if parser.is_symlink() or hashlib.sha256(parser.read_bytes()).hexdigest()!=PARSER_SHA:
            _fail('VOICE_COMPONENT_CHANGED','语气样本组件需要核对')
        license_file=parser.parent/'LICENSE-xintu.txt'
        if license_file.is_symlink() or hashlib.sha256(license_file.read_bytes()).hexdigest()!=LICENSE_SHA:
            _fail('VOICE_COMPONENT_CHANGED','语气样本组件许可需要核对')
        spec=importlib.util.spec_from_file_location('_fangyu_checked_voice_parser',parser)
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.parser=module

    def _authorized(self, db, user, scope, *, save=False):
        values=scope.checked()
        if not isinstance(user,dict) or user.get('tenant_id')!=scope.tenant_id:
            _fail('VOICE_FORBIDDEN','员工与口吻样本归属不一致')
        def get(entity, ident):
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (entity,ident,scope.tenant_id)).fetchone()
            return json.loads(found['body']) if found else None
        saved=get('users',user.get('id'))
        if (not isinstance(saved,dict) or saved.get('disabled') or saved.get('cloud_bound') is not True
                or any(saved.get(k)!=user.get(k) for k in ('id','username','role','tenant_id'))):
            _fail('VOICE_FORBIDDEN','员工身份已变化')
        if save and saved.get('role')!='admin':
            _fail('VOICE_ADMIN_REQUIRED','只有管理员可以维护账号语气样本')
        account=get('accounts',scope.account_id)
        if (not isinstance(account,dict) or account.get('platform')!=scope.platform
                or account.get('cloud_owner')!=saved.get('username')
                or account.get('store_id') not in (None,'',scope.store_id)):
            _fail('VOICE_ACCOUNT_CHANGED','发送账号或所属门店已变化')
        if self.authority_check is not None and self.authority_check(db,saved,scope,save) is not True:
            _fail('VOICE_FORBIDDEN','员工会话或当前门店已变化')
        return values,saved

    def _row(self,db,scope,owner):
        ident=_digest([CONTRACT,scope.checked(),owner])
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (ENTITY,ident,scope.tenant_id)).fetchone()
        try:row=json.loads(found['body']) if found else None
        except (TypeError,ValueError):_fail('VOICE_RECORD_INVALID','语气样本记录需要核对')
        if row is not None and (not isinstance(row,dict) or row.get('scope')!=scope.checked()
                or row.get('owner')!=owner or row.get('id')!=ident
                or type(row.get('revision')) is not int or row['revision']<1
                or not isinstance(row.get('samples'),list) or len(row['samples'])>30):
            _fail('VOICE_RECORD_INVALID','语气样本记录归属或版本需要核对')
        if row is not None:
            seen=set()
            for sample in row['samples']:
                if (not isinstance(sample,dict) or not isinstance(sample.get('id'),str)
                        or not re.fullmatch(r'[a-f0-9]{32}',sample['id']) or sample['id'] in seen
                        or any(not isinstance(sample.get(k),str) or len(sample[k])>maximum
                            for k,maximum in (('label',80),('title',120),('text',3000),('updated_at',80)))):
                    _fail('VOICE_RECORD_INVALID','语气样本内容需要核对')
                seen.add(sample['id'])
                if sample.get('source_type')=='human_confirmed_reply' and (
                        sample.get('learning_contract')!=LEARNING_CONTRACT
                        or type(sample.get('source_reply_version')) is not int
                        or sample['source_reply_version']<1
                        or any(not isinstance(sample.get(k),str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',sample[k])
                            for k in ('source_reply_id','source_request_id'))):
                    _fail('VOICE_RECORD_INVALID','确认回复样本来源需要核对')
        return row or dict(id=ident,tenant_id=scope.tenant_id,scope=scope.checked(),owner=owner,
            revision=0,samples=[])

    @staticmethod
    def _public(row):
        return dict(contract=CONTRACT,scope=deepcopy(row['scope']),revision=row['revision'],
            count=len(row['samples']),items=[{**{k:deepcopy(r[k]) for k in
                ('id','label','title','text','updated_at')},**({'reference_text':_style_reference(r['text'])}
                    if r.get('source_type')=='human_confirmed_reply' else {})} for r in row['samples']],
            voice_anchor='user_library' if len(row['samples'])>=2 else 'insufficient',
            confirmed_sample_count=sum(r.get('source_type')=='human_confirmed_reply' for r in row['samples']),
            confirmed_learning_supported=True,
            generated_reply=False,delivery_allowed=False)

    def read(self,user,scope):
        with self.store.connect() as db:
            db.execute('BEGIN')
            _,actor=self._authorized(db,user,scope)
            row=self._row(db,scope,actor['username'])
            return self._public(row)

    def save(self,user,scope,request):
        allowed={'expected_revision','label','title','text','sample_id'}
        if (not isinstance(request,dict) or set(request)-allowed
                or type(request.get('expected_revision')) is not int or request['expected_revision']<0):
            _fail('VOICE_INPUT_INVALID','请提供当前样本版本')
        label=_text(request.get('label'),80,'样本名称').strip()
        title=_text(request.get('title',''),120,'样本标题',empty=True).strip()
        original=_text(request.get('text'),3000,'本人语气样本',multiline=True)
        # An explicit title keeps the entire reply as body; short opening lines
        # must not disappear through the upstream note-title heuristic.
        parsed_title,body=self.parser.split_title_body(original,title or label)
        sample_id=request.get('sample_id') or _digest([scope.checked(),body])[:32]
        if not isinstance(sample_id,str) or not re.fullmatch(r'[a-f0-9]{32}',sample_id):
            _fail('VOICE_INPUT_INVALID','样本编号格式无效')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            _,actor=self._authorized(db,user,scope,save=True)
            row=self._row(db,scope,actor['username'])
            if request['expected_revision']!=row['revision']:
                _fail('VOICE_REVISION_CONFLICT','语气样本已更新，请重新读取')
            existing=next((r for r in row['samples'] if r['id']==sample_id),None)
            if request.get('sample_id') and existing is None:
                _fail('VOICE_SAMPLE_MISSING','原语气样本已变化')
            if existing is None and len(row['samples'])>=30:
                automatic=next((r for r in row['samples'] if r.get('source_type')=='human_confirmed_reply'),None)
                if automatic is None:_fail('VOICE_LIMIT','每个发送账号最多保存30份语气样本')
                row['samples'].remove(automatic)
            record=dict(id=sample_id,label=label,title=parsed_title,text=body,source_text=original,
                source_type='user_upload',updated_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
            row['samples']=[r for r in row['samples'] if r['id']!=sample_id]+[record]
            row['revision']+=1
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (ENTITY,row['id'],scope.tenant_id,json.dumps(row,ensure_ascii=False,allow_nan=False)))
            return self._public(row)

    def learn_confirmed(self,user,scope,request_id):
        """Collect only a new-version, persisted, personally confirmed review.

        No caller-supplied text, generation, delivery, old-history scan, or prompt
        mutation. The event acknowledgement commits with the sample, so even an
        evicted reference cannot be resurrected by retrying an old receipt.
        """
        if not isinstance(request_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',request_id):
            _fail('VOICE_INPUT_INVALID','确认回复来源无效')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            _,actor=self._authorized(db,user,scope)
            if actor.get('can_reply') is False or user.get('can_reply') is False:
                _fail('VOICE_FORBIDDEN','本人回复权限已变化')
            def get(entity,ident):
                found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    (entity,ident,scope.tenant_id)).fetchone()
                return json.loads(found['body']) if found else None
            key=_digest([scope.tenant_id,actor['id'],scope.store_id,request_id])
            receipt=get(REVIEW_ENTITY,key)
            if (not isinstance(receipt,dict) or receipt.get('action')!='reply_review'
                    or receipt.get('voice_learning_contract')!=LEARNING_CONTRACT
                    or receipt.get('state') not in ('accepted','observed')):
                return dict(status='skipped',reason='not_confirmed_learning_event',delivery_allowed=False)
            intent=receipt.get('intent');proof=receipt.get('reply')
            if (not isinstance(intent,dict) or not isinstance(proof,dict)
                    or receipt.get('owner')!=actor['username'] or receipt.get('storeId')!=scope.store_id
                    or receipt.get('tenant_id')!=scope.tenant_id or receipt.get('id')!=key
                    or receipt.get('requestId')!=request_id
                    or intent.get('requestId')!=request_id or intent.get('storeId')!=scope.store_id
                    or intent.get('accountId')!=scope.account_id
                    or intent.get('leadId')!=receipt.get('leadId')
                    or intent.get('customerId')!=receipt.get('customerId')
                    or receipt.get('signature')!=_digest(['reply_review',{k:v for k,v in intent.items() if k!='expectedStatus'}])):
                _fail('VOICE_RECORD_INVALID','确认回复归属或回执需要核对')
            if intent.get('confirmed') is not True or proof.get('status')!='approved':
                return dict(status='skipped',reason='not_personally_confirmed',delivery_allowed=False)
            ident=intent.get('expectedReplyId');version=intent.get('expectedVersion')
            if (not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident)
                    or type(version) is not int or version<1):
                _fail('VOICE_RECORD_INVALID','确认回复版本需要核对')
            sample_id=_digest([CONTRACT,scope.checked(),'human_confirmed_reply',ident,version])[:32]
            ack=receipt.get('voice_learning')
            if ack is not None:
                if ack!={'contract':LEARNING_CONTRACT,'sample_id':sample_id}:
                    _fail('VOICE_RECORD_INVALID','语气学习回执需要核对')
                return dict(status='already_learned',delivery_allowed=False)
            reply=get('replies',ident)
            if isinstance(reply,dict) and reply.get('status')=='draft':
                return dict(status='skipped',reason='draft_not_confirmed',delivery_allowed=False)
            if (not isinstance(reply,dict) or reply.get('status') not in ('approved','copied','sent')
                    or reply.get('author_id')!=actor['id'] or reply.get('approved_by')!=actor['id']
                    or reply.get('review_account_id')!=scope.account_id
                    or reply.get('version')!=version or type(reply.get('version')) is not int
                    or reply.get('lead_id')!=intent.get('leadId')
                    or any(proof.get(k)!=reply.get(k) for k in ('id','text','version','review_account_id'))):
                _fail('VOICE_RECORD_INVALID','本人确认的回复内容或版本已变化')
            lead=get('leads',reply.get('lead_id'));task=get('tasks',lead.get('task_id')) if isinstance(lead,dict) else None
            if (not isinstance(lead,dict) or not isinstance(task,dict)
                    or task.get('store_id')!=scope.store_id or lead.get('store_id') not in (None,'',scope.store_id)
                    or lead.get('platform')!=scope.platform
                    or lead.get('cloud_owner') not in (None,'',actor['username'])
                    or task.get('cloud_owner') not in (None,'',actor['username'])
                    or not (lead.get('cloud_owner')==actor['username'] or task.get('cloud_owner')==actor['username'])
                    or _digest(lead)!=intent.get('sourceDigest')):
                _fail('VOICE_RECORD_INVALID','原评论、员工或门店来源已变化')
            original=_text(reply.get('text'),1000,'本人确认回复',multiline=True)
            row=self._row(db,scope,actor['username'])
            existing=next((r for r in row['samples'] if r['id']==sample_id),None)
            if existing is None:
                uploaded=[r for r in row['samples'] if r.get('source_type')!='human_confirmed_reply']
                limit=min(20,30-len(uploaded))
                if limit<=0:return dict(status='skipped',reason='manual_library_full',delivery_allowed=False)
                automatic=[r for r in row['samples'] if r.get('source_type')=='human_confirmed_reply']
                title,body=self.parser.split_title_body(original,'本人确认回复')
                record=dict(id=sample_id,label='本人确认回复',title=title,text=body,source_text=original,
                    source_type='human_confirmed_reply',learning_contract=LEARNING_CONTRACT,
                    source_reply_id=ident,source_reply_version=version,source_request_id=request_id,
                    updated_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
                row['samples']=uploaded+automatic[-(limit-1):]+[record] if limit>1 else uploaded+[record]
                row['revision']+=1
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (ENTITY,row['id'],scope.tenant_id,json.dumps(row,ensure_ascii=False,allow_nan=False)))
            receipt['voice_learning']={'contract':LEARNING_CONTRACT,'sample_id':sample_id}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (REVIEW_ENTITY,key,scope.tenant_id,json.dumps(receipt,ensure_ascii=False,allow_nan=False)))
            return dict(status='learned' if existing is None else 'already_learned',count=len(row['samples']),
                revision=row['revision'],delivery_allowed=False)

    def context(self,user,scope,sop_text):
        """Reference card only. The original SOP remains the outgoing draft."""
        _text(sop_text,1000,'SOP',empty=True,multiline=True)
        library=self.read(user,scope)
        references=[dict(id=r['id'],text=r.get('reference_text',r['text'][:500])) for r in library['items'][-3:]]
        payload=dict(scope=scope.checked(),revision=library['revision'],sop_text=sop_text,
            references=references)
        return dict(contract=CONTRACT,revision=library['revision'],sample_count=library['count'],
            context_digest=_digest(payload),sop_text=sop_text,voice_references=references,
            use='tone_reference_only',facts_from_samples_allowed=False,
            automatic_generation=False,delivery_allowed=False,
            note='语气样本只供参考，不复制其中的客户条件、价格或承诺；发送内容仍需本人确认。')

    def context_is_current(self,user,scope,sop_text,digest):
        return (isinstance(digest,str) and
            self.context(user,scope,sop_text)['context_digest']==digest)
