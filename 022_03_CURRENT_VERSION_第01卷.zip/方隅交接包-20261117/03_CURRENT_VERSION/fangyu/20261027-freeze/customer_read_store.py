"""Employee-scoped local read projections, never an authority cache.

The backend checks verified local browse scope and current local session before
calling this module. One read-only transaction covers the projection and its
explicit business fingerprint; control-plane commits cannot invalidate it.
"""
from collections import OrderedDict
from copy import copy, deepcopy
from contextlib import contextmanager
from pathlib import Path
import hashlib
import json
from contextvars import ContextVar
from datetime import datetime
import logging
import math
import os
import sqlite3
import threading
import time
from uuid import uuid4


_READ_SNAPSHOT = ContextVar('customer_projection_snapshot', default=None)
_READ_VALID_UNTIL = ContextVar('customer_projection_valid_until', default=None)
_READ_PROJECTION = ContextVar('customer_projection_shared', default=None)
_BUSINESS_ENTITIES = (
    'leads', 'accounts', 'tasks', 'replies', 'rental_assessments_v1',
    'rental_task_context_v1', 'customer_outcome_events', 'ui_customer_handoff_v1',
    'ui_reply_requests_v1', 'lead_task_observations_v1',
    'customer_intent_projection_v1', 'customer_intent_projection_scope_v1',
    'intent_rule_policies',
)


_REV_META = 'customer_read_epoch_v1'
_REV_COUNTER = 'customer_read_revision_v1'
_REV_GUARD = 'customer_read_insert_guard_v1'
_REV_PREFIX = 'customer_read_v1_'
_AUX_COLUMNS = {
    'customer_views': ('tenant_id','cloud_owner','kind','author_key','post_key','viewed_at'),
    'contact_events': ('sequence','event_id','reply_id','kind','tenant_id','cloud_owner',
        'provisional','syncable','payload','payload_hash','previous_hash','chain_hash'),
    'contact_event_acks': ('event_id','acked_at'),
    'customer_response_observations': ('tenant_id','cloud_owner','platform','note_id','comment_id','body'),
}
_REV_TABLE_SQL = {
    _REV_META: 'CREATE TABLE '+_REV_META+'(singleton INTEGER PRIMARY KEY CHECK(singleton=1),version INTEGER NOT NULL,epoch TEXT NOT NULL)',
    _REV_COUNTER: 'CREATE TABLE '+_REV_COUNTER+'(tenant_id TEXT PRIMARY KEY,revision INTEGER NOT NULL)',
    _REV_GUARD: 'CREATE TABLE '+_REV_GUARD+'(table_name TEXT NOT NULL,tenant_id TEXT NOT NULL,changed INTEGER NOT NULL,PRIMARY KEY(table_name,tenant_id))',
}


def _quote(value):
    return '"' + value.replace('"','""') + '"'


def _bump(tenant, where='1'):
    return ('INSERT INTO '+_REV_COUNTER+'(tenant_id,revision) SELECT '+tenant+
        ',1 WHERE '+where+' ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;')


def _revision_definition(db):
    """Build exact DDL from the real dependency schemas, never decode a body."""
    expected = dict(_REV_TABLE_SQL)
    tables = {}
    for table, required in {'records':('entity','id','tenant_id','body'), **_AUX_COLUMNS}.items():
        info = list(db.execute('PRAGMA table_info('+_quote(table)+')'))
        if not info:
            if table == 'records': raise ValueError('Missing source schema')
            continue
        columns = tuple(row[1] for row in info)
        if set(columns) != set(required): raise ValueError('Unsupported source schema')
        unique = []
        pk = tuple(row[1] for row in sorted(info,key=lambda row:row[5]) if row[5])
        if pk: unique.append(pk)
        for index in db.execute('PRAGMA index_list('+_quote(table)+')'):
            if not index[2]: continue
            if len(index)>4 and index[4]: raise ValueError('Partial unique dependency index')
            cols = tuple(row[2] for row in db.execute('PRAGMA index_info('+_quote(index[1])+')'))
            if not cols or any(col not in columns for col in cols): raise ValueError('Expression dependency index')
            if cols not in unique: unique.append(cols)
        if not unique: raise ValueError('Dependency has no unique identity')
        # Existing append-only constraints remain installed and run normally.
        known = {'contact_events_no_update','contact_events_no_delete'} if table == 'contact_events' else set()
        for name,sql in db.execute("SELECT name,sql FROM sqlite_schema WHERE type='trigger' AND tbl_name=?",(table,)):
            if name.startswith(_REV_PREFIX): continue
            if name not in known: raise ValueError('Unknown dependency trigger')
        tables[table] = (columns, unique, info)
    if 'contact_event_acks' in tables and 'contact_events' not in tables:
        raise ValueError('ACK dependency unavailable')
    watched = '('+','.join("'"+entity+"'" for entity in _BUSINESS_ENTITIES)+')'
    for table,(columns,unique,info) in tables.items():
        qtable = _quote(table)
        equal = ' AND '.join('t.'+_quote(col)+' IS NEW.'+_quote(col) for col in columns)
        # SQLite uses -1 in BEFORE INSERT for an unspecified INTEGER rowid.
        integer_pk = [row[1] for row in info if row[5] and row[2].upper() == 'INTEGER']
        if len(integer_pk)==1: equal += ' AND NEW.'+_quote(integer_pk[0])+'<>-1'
        conflicts = ' OR '.join('('+' AND '.join(
            'NEW.'+_quote(col)+' IS NOT NULL AND t.'+_quote(col)+'=NEW.'+_quote(col)
            for col in key)+')' for key in unique)
        new_tenant = 'NEW.tenant_id' if table != 'contact_event_acks' else (
            '(SELECT tenant_id FROM contact_events WHERE event_id=NEW.event_id)')
        old_tenant = 'OLD.tenant_id' if table != 'contact_event_acks' else (
            '(SELECT tenant_id FROM contact_events WHERE event_id=OLD.event_id)')
        prior_tenant = 't.tenant_id' if table != 'contact_event_acks' else (
            '(SELECT tenant_id FROM contact_events WHERE event_id=t.event_id)')
        insert_when = ' WHEN NEW.entity IN '+watched if table == 'records' else ''
        delete_when = ' WHEN OLD.entity IN '+watched if table == 'records' else ''
        update_when = (' WHEN (OLD.entity IN '+watched+' OR NEW.entity IN '+watched+') AND NOT ('+
            ' AND '.join('OLD.'+_quote(col)+' IS NEW.'+_quote(col) for col in columns)+')'
            if table == 'records' else ' WHEN NOT ('+
            ' AND '.join('OLD.'+_quote(col)+' IS NEW.'+_quote(col) for col in columns)+')')
        name = _REV_PREFIX+table+'_before_insert'
        expected[name] = ('CREATE TRIGGER '+_quote(name)+' BEFORE INSERT ON '+qtable+insert_when+' BEGIN '+
            'DELETE FROM '+_REV_GUARD+" WHERE table_name='"+table+"';"+
            'INSERT INTO '+_REV_GUARD+'(table_name,tenant_id,changed) SELECT '+"'"+table+"',"+
            prior_tenant+',MAX(NOT ('+equal+')) FROM '+qtable+' t WHERE ('+conflicts+') AND '+
            prior_tenant+' IS NOT NULL GROUP BY '+prior_tenant+'; END')
        name = _REV_PREFIX+table+'_insert'
        expected[name] = ('CREATE TRIGGER '+_quote(name)+' AFTER INSERT ON '+qtable+insert_when+' BEGIN '+
            'INSERT INTO '+_REV_COUNTER+'(tenant_id,revision) SELECT tenant_id,1 FROM '+_REV_GUARD+
            " WHERE table_name='"+table+"' AND changed=1 ON CONFLICT(tenant_id) DO UPDATE SET revision=revision+1;"+
            _bump(new_tenant,new_tenant+' IS NOT NULL AND NOT EXISTS(SELECT 1 FROM '+_REV_GUARD+
                " WHERE table_name='"+table+"' AND tenant_id="+new_tenant+' AND changed=0)')+
            'DELETE FROM '+_REV_GUARD+" WHERE table_name='"+table+"'; END")
        name = _REV_PREFIX+table+'_delete'
        expected[name] = 'CREATE TRIGGER '+_quote(name)+' AFTER DELETE ON '+qtable+delete_when+' BEGIN '+_bump(old_tenant,old_tenant+' IS NOT NULL')+' END'
        name = _REV_PREFIX+table+'_update'
        old_where = old_tenant+' IS NOT NULL'+(' AND OLD.entity IN '+watched if table=='records' else '')
        new_where = new_tenant+' IS NOT NULL'+(' AND NEW.entity IN '+watched if table=='records' else '')
        expected[name] = ('CREATE TRIGGER '+_quote(name)+' AFTER UPDATE ON '+qtable+update_when+' BEGIN '+
            _bump(old_tenant,old_where)+_bump(new_tenant,new_where)+' END')
    return expected


def _canonical_ddl(sql):
    return sql.strip().rstrip(';') if isinstance(sql,str) else ''


def _revision_schema_valid(db):
    try:
        expected = _revision_definition(db)
        actual = dict(db.execute("SELECT name,sql FROM sqlite_schema WHERE name IN ("+
            ','.join('?' for _ in expected)+')',tuple(expected)))
        if set(actual) != set(expected): return False
        if any(_canonical_ddl(actual[name]) != _canonical_ddl(sql) for name,sql in expected.items()): return False
        names = {row[0] for row in db.execute("SELECT name FROM sqlite_schema WHERE type='trigger' AND substr(name,1,?)=?",(len(_REV_PREFIX),_REV_PREFIX))}
        if names != {name for name in expected if name.startswith(_REV_PREFIX)}: return False
        row = db.execute('SELECT version,epoch FROM '+_REV_META+' WHERE singleton=1').fetchone()
        return row is not None and row[0] == 1 and isinstance(row[1],str) and len(row[1]) == 32
    except (sqlite3.DatabaseError,ValueError):
        return False


def _schema_backup(db, destination):
    """A tiny consistent SQLite schema snapshot; never a customer-data backup."""
    rows = list(db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name"))
    destination = Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    target = destination/('customer-read-schema-'+uuid4().hex+'.sqlite3')
    backup = sqlite3.connect(target)
    try:
        backup.execute('CREATE TABLE source_schema(type TEXT,name TEXT PRIMARY KEY,table_name TEXT,ddl TEXT)')
        backup.executemany('INSERT INTO source_schema VALUES(?,?,?,?)',[tuple(row) for row in rows])
        backup.execute('CREATE TABLE scope(kind TEXT PRIMARY KEY,value TEXT NOT NULL)')
        backup.execute('CREATE TABLE migration_objects(name TEXT PRIMARY KEY,ddl TEXT NOT NULL,sha256 TEXT NOT NULL,is_new INTEGER NOT NULL)')
        original_names = {row[1] for row in rows}
        definition = _revision_definition(db)
        backup.executemany('INSERT INTO migration_objects VALUES(?,?,?,?)',[
            (name,ddl,hashlib.sha256(ddl.encode('utf-8')).hexdigest(),int(name not in original_names))
            for name,ddl in definition.items()])
        backup.executemany('INSERT INTO scope VALUES(?,?)',[
            ('purpose','schema-only additive migration rollback; contains no customer records'),
            ('rollback','only exact migration_objects is_new=1 names after live DDL hash verification; never business tables'),
            ('source_schema_version',str(db.execute('PRAGMA schema_version').fetchone()[0]))])
        backup.commit()
        if backup.execute('PRAGMA integrity_check').fetchone()[0] != 'ok': raise ValueError('Backup integrity')
        if list(backup.execute('SELECT type,name,table_name,ddl FROM source_schema ORDER BY type,name')) != [tuple(row) for row in rows]:
            raise ValueError('Backup schema mismatch')
    finally: backup.close()
    return {'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'kind':'schema-only-no-customer-data'}


def prepare_customer_read_concurrency(database_path):
    """Explicit idle-startup preparation, never called from a browse request.

    SQLite's persistent WAL mode permits local readers during collection writes.
    A busy/unavailable database keeps its original journal and data; startup does
    not retry or wait for an existing writer. Read connections stay bounded too.
    """
    db=None
    result={'ready':False,'changed':False,'journalMode':'unknown',
        'busyTimeoutMs':250,'readBusyTimeoutMs':1000,'fallback':'bounded-read-only'}
    try:
        path=Path(database_path).resolve(strict=True)
        if str(path).startswith('\\\\'):
            return {**result,'reason':'network-path-not-supported'}
        db=sqlite3.connect(path.as_uri()+'?mode=rw',uri=True,timeout=.25)
        db.execute('PRAGMA busy_timeout=250')
        before=db.execute('PRAGMA journal_mode').fetchone()[0].lower()
        result['journalMode']=before
        after=db.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower()
        if after!='wal':return {**result,'reason':'wal-not-enabled'}
        return {**result,'ready':True,'changed':before!='wal','journalMode':after,'fallback':None}
    except (OSError,sqlite3.DatabaseError,ValueError):
        return {**result,'reason':'sqlite-busy-or-unavailable'}
    finally:
        if db is not None:db.close()


def prepare_business_revision(database_path, *, backup_directory):
    """Explicit runtime-only additive migration. Failure leaves the old read path."""
    path = Path(database_path).resolve()
    db = None
    try:
        db = sqlite3.connect(path.as_uri()+'?mode=rw',uri=True,timeout=1)
        db.execute('BEGIN IMMEDIATE')
        if _revision_schema_valid(db):
            db.rollback();return {'ready':True,'changed':False}
        expected = _revision_definition(db)
        # Extend only an exact known installation (e.g. a late auxiliary table).
        # Unknown versions or changed owned DDL are never overwritten silently.
        existing = dict(db.execute("SELECT name,sql FROM sqlite_schema WHERE name IN ("+
            ','.join('?' for _ in expected)+')',tuple(expected)))
        owned = {row[0] for row in db.execute("SELECT name FROM sqlite_schema WHERE substr(name,1,?)=?",
            (len(_REV_PREFIX),_REV_PREFIX))} | set(existing)
        if not owned.issubset(expected): raise ValueError('Unknown revision objects')
        if existing:
            if not set(_REV_TABLE_SQL).issubset(existing): raise ValueError('Partial revision metadata')
            if any(_canonical_ddl(sql)!=_canonical_ddl(expected[name]) for name,sql in existing.items()):
                raise ValueError('Changed revision schema')
            row=db.execute('SELECT version,epoch FROM '+_REV_META+' WHERE singleton=1').fetchone()
            if row is None or row[0]!=1 or not isinstance(row[1],str) or len(row[1])!=32:
                raise ValueError('Unknown revision version')
        backup = _schema_backup(db,backup_directory)
        for name,sql in expected.items():
            if name not in existing: db.execute(sql)
        db.execute('INSERT OR REPLACE INTO '+_REV_META+' VALUES(1,1,?)',(uuid4().hex,))
        if not _revision_schema_valid(db): raise ValueError('Revision schema did not verify')
        db.commit()
        return {'ready':True,'changed':True,'backup':backup}
    except (OSError,sqlite3.DatabaseError,ValueError):
        if db is not None: db.rollback()
        return {'ready':False,'changed':False,'fallback':'business-fingerprint'}
    finally:
        if db is not None: db.close()



class _SnapshotConnection:
    # A scoped legacy read helper starts its own transaction. The owner already
    # established this read-only snapshot, so that exact BEGIN is idempotent.
    def __init__(self, db):
        self._db = db

    def execute(self, sql, parameters=()):
        if sql.strip().upper() == 'BEGIN' and self._db.in_transaction:
            return self._db.execute('SELECT 1 WHERE 0')
        return self._db.execute(sql, parameters)

    def __getattr__(self, name):
        return getattr(self._db, name)


class TimingRecorder:
    """Fixed-stage timings only; neither exception text nor request data enters here."""
    STAGES=frozenset(('host_attach','identity','config','directory','core_session',
        'core_lock_wait','core_lock_hold','projection','device_poll','reviewed_reply','other'))
    CODES=frozenset(('', 'AUTH_REQUIRED','AUTH_SERVICE_UNAVAILABLE','STORE_REQUIRED',
        'STORE_FORBIDDEN','WORKSPACE_DATA_UNAVAILABLE','PREFERENCE_SCOPE_INVALID',
        'PREFERENCE_INVALID','BACKEND_CLOSED','CUSTOMER_READ_CHANGED',
        'CUSTOMERS_UNAVAILABLE','REPLIES_UNAVAILABLE','INPUT_INVALID','UNCLASSIFIED',
        'HTTP_400','HTTP_401','HTTP_403','HTTP_404','HTTP_408','HTTP_409','HTTP_429',
        'HTTP_500','HTTP_502','HTTP_503','HTTP_504'))
    CODES=CODES | frozenset(('DEVICE_ACTIVE_LIMIT','DEVICE_AUTH_REQUIRED','DEVICE_OFFLINE','DEVICE_REVOKED',
        'DEVICE_SNAPSHOT_AUTH_REQUIRED','DEVICE_SNAPSHOT_REQUEST_INVALID',
        'DEVICE_SNAPSHOT_STATE_INVALID','DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE',
        'OWNER_INACTIVE','ROLE_INELIGIBLE','VERSION_MISMATCH','PROTOCOL_MISMATCH',
        'POLICY_DISABLED','COMPANY_MISMATCH'))
    CODES=CODES | frozenset(('REQUEST_NOT_ATTACHED','HEARTBEAT_ERROR','CLOUD_NO_GRANT',
        'CLOUD_DENIED','LOCAL_REQUEST_INVALID','LOCAL_RESPONSE_INVALID','LOCAL_SAFETY_HOLD',
        'LOCAL_GRANT_FORMAT','LOCAL_GRANT_SCOPE','LOCAL_PERMISSION','LOCAL_EXPIRY',
        'LOCAL_UNCLASSIFIED','LEASE_ACCEPTED','DIAGNOSTIC_ERROR'))
    KINDS=frozenset(('', 'TimeoutError','ConnectionError','OSError','ValueError',
        'WorkbenchError','IntegrationError','CloudError','CustomerReadChanged','OtherError'))

    def __init__(self,path,*,max_bytes=512*1024,clock=time.monotonic):
        self.path=Path(path);self.max_bytes=max(4096,int(max_bytes));self.clock=clock
        self._lock=threading.RLock();self._sequence=0

    def _write(self,stage,event,span,elapsed=0.0,code='',kind=''):
        # Revalidate even trusted logger extras; never stringify arbitrary objects.
        stage=stage if type(stage) is str and stage in self.STAGES else 'other'
        code=code if type(code) is str and code in self.CODES else 'UNCLASSIFIED'
        kind=kind if type(kind) is str and kind in self.KINDS else 'OtherError'
        elapsed=round(max(0.0,elapsed),3) if type(elapsed) in (int,float) and math.isfinite(elapsed) else 0.0
        record={'v':1,'span':span if type(span) is int else 0,'stage':stage,
            'event':event if event in ('enter','exit') else 'exit',
            'elapsed_ms':elapsed,'error_code':code,'error_kind':kind}
        try:
            with self._lock:
                self.path.parent.mkdir(parents=True,exist_ok=True)
                previous=self.path.with_name('customer-read-timing.previous.jsonl')
                if self.path.is_symlink() or previous.is_symlink():return
                if self.path.exists() and self.path.stat().st_size>=self.max_bytes:
                    os.replace(self.path,previous)
                with self.path.open('a',encoding='ascii',newline='\n') as stream:
                    stream.write(json.dumps(record,separators=(',',':'))+'\n');stream.flush()
        except Exception:
            # Instrumentation cannot change authorization, business results or retries.
            pass

    @contextmanager
    def span(self,stage):
        with self._lock:self._sequence+=1;ident=self._sequence
        started=self.clock();self._write(stage,'enter',ident)
        code=kind=''
        try:yield
        except BaseException as error:
            code=getattr(error,'code','UNCLASSIFIED');kind=type(error).__name__
            raise
        finally:self._write(stage,'exit',ident,(self.clock()-started)*1000,code,kind)

    def attach_control_logger(self):
        recorder=self
        class FixedControlHandler(logging.Handler):
            def emit(self,record):
                if record.msg=='reviewed_reply_stage':
                    code=getattr(record,'diagnostic_code','')
                    allowed=frozenset(('REQUEST_NOT_ATTACHED','HEARTBEAT_ERROR','CLOUD_NO_GRANT',
                        'CLOUD_DENIED','LOCAL_REQUEST_INVALID','LOCAL_RESPONSE_INVALID','LOCAL_SAFETY_HOLD',
                        'LOCAL_GRANT_FORMAT','LOCAL_GRANT_SCOPE','LOCAL_PERMISSION','LOCAL_EXPIRY',
                        'LOCAL_UNCLASSIFIED','LEASE_ACCEPTED','DIAGNOSTIC_ERROR'))
                    recorder._write('reviewed_reply','exit',0,code=code if code in allowed else 'DIAGNOSTIC_ERROR')
                    return
                if record.msg!='device_poll_stage':return
                recorder._write('device_poll',getattr(record,'stage_event','exit'),
                    getattr(record,'span_id',0),getattr(record,'elapsed_ms',0.0),
                    getattr(record,'error_code',''),getattr(record,'error_kind',''))
        logger=logging.getLogger('fangyu.fixed_control_stage')
        logger.handlers[:]=[FixedControlHandler()]
        logger.setLevel(logging.INFO);logger.propagate=False


class CustomerReadChanged(ValueError):
    code = 'CUSTOMER_READ_CHANGED'
    status = 409

    def __init__(self):
        super().__init__('客户资料刚有变化，请重新读取；原评论和草稿已保留')


class ReadRequestStore:
    """Memoize repeated account/task lookups within one authorized read only.

The whole projection reads one transaction. Backend performs verified scope and
live-user scope checks before/after it; no original Core lock is acquired while
this snapshot is open. This wrapper is never installed on the live Core or
used by save, export, review, delivery or platform operations.
"""
    def __init__(self, source):
        self._source = source
        self.path = source.path
        self.directory = getattr(source, 'directory', Path(source.path).parent)
        self._records = {}
        self._lists = {}
        self.customer_key = None
        self.customer_person = None
        active = _READ_SNAPSHOT.get()
        self._snapshot = active[1] if active and active[0] == Path(self.path).resolve() else None
        self._reader = copy(source)
        self._reader.connect = self.connect

    def get(self, entity, ident):
        if entity not in ('accounts', 'tasks'):
            value = self._reader.get(entity, ident)
            if entity == 'leads': self._observe_policy_time((value,))
            return value
        key = (entity, ident)
        if key not in self._records:
            self._records[key] = self._reader.get(entity, ident)
        return deepcopy(self._records[key])

    def list(self, entity, tenant_id=None):
        if entity=='leads' and self.customer_key and callable(self.customer_person):
            return self._customer_leads(tenant_id)
        if entity not in ('leads', 'accounts', 'tasks', 'replies'):
            return self._reader.list(entity, tenant_id)
        key = (entity, tenant_id)
        if key not in self._lists:
            self._lists[key] = self._reader.list(entity, tenant_id)
            if entity == 'leads': self._observe_policy_time(self._lists[key])
        return deepcopy(self._lists[key])

    def cached_projection(self, kind, key, loader):
        shared=_READ_PROJECTION.get()
        if shared is None:return loader()
        cache,revision,scope=shared
        identity=json.dumps([revision,scope,kind,key],sort_keys=True,default=str)
        with cache.lock:
            found=cache._projections.get(identity)
        if found is not None and time.time()<found[1]:
            deadline=_READ_VALID_UNTIL.get()
            if deadline is not None:deadline[0]=min(deadline[0],found[1])
            return found[0]
        value=loader()
        # One bounded snapshot per query, shared across page numbers. It is
        # internal read-only data: callers project/slice without mutating it.
        size=len(json.dumps(value,ensure_ascii=False,default=str).encode('utf-8'))
        if size<=64*1024*1024:
            with cache.lock:
                deadline=_READ_VALID_UNTIL.get()
                cache._projections[identity]=(value,deadline[0] if deadline is not None else float('inf'))
                while len(cache._projections)>2:cache._projections.popitem(last=False)
        return value

    def _customer_leads(self, tenant):
        def build_index():
            groups={}
            # Cold lookup reads identity columns, not comment/analysis bodies.
            # Legacy provisional keys retain the pinned history implementation.
            with self.connect() as db:
                rows=db.execute("SELECT id,json_extract(body,'$.platform'),json_extract(body,'$.author_id'),json_extract(body,'$.comment_id'),json_extract(body,'$.note_url') FROM records WHERE entity='leads' AND tenant_id=?",(tenant,))
                for ident,platform,author,comment,url in rows:
                    key=self.customer_person(dict(id=ident,platform=platform,author_id=author,comment_id=comment,note_url=url))[0]
                    groups.setdefault(key,[]).append(ident)
            return groups
        groups=self.cached_projection('customer-key-index',tenant,build_index)
        ids=groups.get(self.customer_key,[]);result=[]
        with self.connect() as db:
            for start in range(0,len(ids),400):
                batch=ids[start:start+400]
                for row in db.execute("SELECT body FROM records WHERE entity='leads' AND tenant_id=? AND id IN ("+','.join('?' for _ in batch)+')',(tenant,*batch)):
                    result.append(json.loads(row[0]))
        self._observe_policy_time(result)
        return result

    @staticmethod
    def _observe_policy_time(leads):
        # RentalAssessmentService has one sub-day transition: an aware source
        # timestamp ceases being > now+5min. Observe already decoded cold-loader
        # rows; warm revision reads neither bodies nor these timestamps. Naive
        # historical dates remain unknown, exactly as the assessment contract.
        deadline = _READ_VALID_UNTIL.get()
        if deadline is None: return
        now = time.time()
        for lead in leads:
            value = lead.get('published_at') if isinstance(lead,dict) else None
            if not isinstance(value,str): continue
            try:
                published = datetime.fromisoformat(value.replace('Z','+00:00'))
                if published.tzinfo is None: continue
                transition = published.timestamp()-300
                if transition > now: deadline[0] = min(deadline[0],transition)
            except (ValueError,OverflowError,OSError):
                continue

    @contextmanager
    def connect(self):
        if self._snapshot is not None:
            yield _SnapshotConnection(self._snapshot)
            return
        db = sqlite3.connect(Path(self.path).resolve().as_uri() + '?mode=ro', uri=True, timeout=1)
        db.row_factory = sqlite3.Row
        try:
            db.execute('PRAGMA query_only=ON')
            yield db
        finally:
            db.close()

    def __getattr__(self, name):
        if name in ('list_task_leads', 'read_customer_source_history'):
            method = getattr(self._source, name)
            # Existing scoped read helpers must use this read-only connection.
            function = getattr(method, '__func__', None)
            return function.__get__(self, type(self)) if function is not None else method
        raise AttributeError(name)


class CustomerReadStore:
    def __init__(self, database_path, *, ttl=5.0, max_entries=64,
                 max_bytes=8 * 1024 * 1024, clock=time.monotonic):
        self.path = Path(database_path).resolve()
        self.ttl, self.max_entries, self.max_bytes = ttl, max_entries, max_bytes
        self.clock = clock
        self.lock = threading.RLock()
        self._db = None
        self._file_identity = None
        self._entries = OrderedDict()
        self._projections = OrderedDict()
        self._bytes = 0
        self._loading = {}
        self._closed = False
        self._generation = 0
        self._revision_schemas = {}
        self._revision_schema_lock = threading.RLock()

    @staticmethod
    def _stat(path, *, timestamp=True):
        try:
            value = path.stat()
        except FileNotFoundError:
            return None
        return (value.st_dev, value.st_ino, value.st_size,
                value.st_mtime_ns if timestamp else 0)

    def _revision(self, db, scope, identity, generation):
        if self._closed:
            raise CustomerReadChanged()
        actor = scope.get('actor') if isinstance(scope, dict) else None
        tenant = actor.get('tenant_id') if isinstance(actor, dict) else None
        owner = actor.get('username') if isinstance(actor, dict) else None
        # Only a complete, exact validated persistent revision can avoid the
        # business-body fingerprint. This connection already owns the same RO
        # snapshot that the loader will use; no cache lock is held during SQL.
        if isinstance(tenant,str) and tenant:
            schema_version = db.execute('PRAGMA schema_version').fetchone()[0]
            schema_key = (identity,schema_version)
            with self._revision_schema_lock:
                valid = self._revision_schemas.get(schema_key)
            if valid is None:
                valid = _revision_schema_valid(db)
                with self._revision_schema_lock:
                    if len(self._revision_schemas)>=8: self._revision_schemas.clear()
                    self._revision_schemas[schema_key] = valid
            if valid:
                row = db.execute('SELECT version,epoch,COALESCE((SELECT revision FROM '+
                    _REV_COUNTER+' WHERE tenant_id=?),0) FROM '+_REV_META+
                    ' WHERE singleton=1',(tenant,)).fetchone()
                if (row is not None and row[0]==1 and isinstance(row[1],str)
                        and len(row[1])==32 and type(row[2]) is int and row[2]>=0):
                    return (generation,identity,('durable-v1',schema_version,row[1],row[2]))
        # Explicit dependencies of customer/reply projections only. Sessions,
        # users, tenants, audit and platform/control jobs are never selected.
        sql = 'SELECT entity,id,body FROM records WHERE entity IN (' + ','.join(
            '?' for _ in _BUSINESS_ENTITIES) + ')'
        args = _BUSINESS_ENTITIES
        if isinstance(tenant, str):
            sql += ' AND tenant_id=?'
            args += (tenant,)
        digest = hashlib.blake2b(digest_size=24)
        def add(value):
            raw = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            digest.update(len(raw).to_bytes(8, 'big'));digest.update(raw)
        for row in db.execute(sql + ' ORDER BY entity,id', args):
            add(tuple(row))
        where = ' WHERE tenant_id=? AND cloud_owner=?' if isinstance(tenant,str) and isinstance(owner,str) else ''
        params = (tenant,owner) if where else ()
        schemas = {}
        for table in ('customer_views','contact_events','contact_event_acks','customer_response_observations'):
            row = db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            schemas[table] = row is not None
            add((table, row[0] if row else None))
        queries = []
        if schemas['customer_views']:
            queries.append(('SELECT kind,author_key,post_key,viewed_at FROM customer_views' + where +
                ' ORDER BY kind,author_key,post_key', params))
        if schemas['contact_events']:
            event_where = where.replace('tenant_id','e.tenant_id').replace('cloud_owner','e.cloud_owner')
            queries.append(('SELECT e.sequence,e.event_id,e.payload FROM contact_events e' + event_where +
                ' ORDER BY e.sequence,e.event_id', params))
            if schemas['contact_event_acks']:
                queries.append(('SELECT e.event_id,a.acked_at FROM contact_events e JOIN contact_event_acks a '
                    'ON a.event_id=e.event_id' + event_where + ' ORDER BY e.sequence,e.event_id', params))
        if schemas['customer_response_observations']:
            queries.append(('SELECT body FROM customer_response_observations' + where +
                ' ORDER BY platform,note_id,comment_id', params))
        for query, parameters in queries:
            add(query)
            for row in db.execute(query, parameters):
                add(tuple(row))
        return (generation, identity, digest.digest())

    def _clear_entries(self):
        self._entries.clear()
        self._projections.clear()
        self._bytes = 0

    def clear(self):
        with self.lock:
            self._generation += 1
            self._clear_entries()

    def close(self):
        with self.lock:
            self._closed = True
            self._clear_entries()
            if self._db is not None:
                self._db.close()
                self._db = None

    def read(self, scope, action, data, loader):
        if action not in ('customers', 'customer_detail', 'reply_read', 'acquisition_summary'):
            raise ValueError('Only local customer reads can be cached')
        key = json.dumps([str(self.path), scope, action, data], ensure_ascii=False,
                         sort_keys=True, separators=(',', ':'), allow_nan=False)
        for attempt in range(3):
            db = sqlite3.connect(self.path.as_uri() + '?mode=ro', uri=True, timeout=1)
            db.row_factory = sqlite3.Row
            event = None
            owns_load = False
            token = None
            expiry_token = None
            projection_token = None
            try:
                db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
                state = self._stat(self.path)
                if state is None:
                    raise CustomerReadChanged()
                identity = state[:2]
                with self.lock:
                    if self._closed:
                        raise CustomerReadChanged()
                    generation = self._generation
                # A pending rollback-journal writer may wait for another loader's
                # snapshot. Do not hold the cache lock while acquiring SQL reads:
                # that loader needs it to finish and close its transaction.
                revision = self._revision(db,scope,identity,generation)
                with self.lock:
                    if self._closed:
                        raise CustomerReadChanged()
                    if revision[0] != self._generation:
                        continue
                    current = self._stat(self.path)
                    if current is None or current[:2] != identity:
                        continue
                    if self._file_identity != identity:
                        self._file_identity = identity;self._clear_entries()
                    entry = self._entries.get(key)
                    if entry and entry[0] == revision and self.clock() < entry[1]:
                        self._entries.move_to_end(key)
                        return deepcopy(entry[2])
                    if entry:
                        self._bytes -= self._entries.pop(key)[3]
                    event = self._loading.get(key)
                    owns_load = event is None
                    if owns_load:
                        event = self._loading[key] = threading.Event()
                if not owns_load:
                    # Never retain a read transaction while waiting for its owner.
                    db.rollback();db.close();db = None
                    if not event.wait(3):
                        raise CustomerReadChanged()
                    continue
                token = _READ_SNAPSHOT.set((self.path,db))
                projection_token = _READ_PROJECTION.set((self,revision,scope))
                valid_until = [float('inf')]
                expiry_token = _READ_VALID_UNTIL.set(valid_until)
                result = loader()
                with self.lock:
                    # Business writes during this build do not invalidate the
                    # internally consistent result. Next request reads the new
                    # committed state and cannot reuse this older generation.
                    current = self._stat(self.path)
                    if (self._closed or revision[0] != self._generation
                            or current is None or current[:2] != identity):
                        raise CustomerReadChanged()
                    size = len(json.dumps(result,ensure_ascii=False,
                        separators=(',', ':'),allow_nan=False).encode('utf-8'))
                    if size <= self.max_bytes:
                        expires = (self.clock()+max(0.0,valid_until[0]-time.time())
                            if isinstance(revision[2],tuple) else self.clock()+self.ttl)
                        self._entries[key] = (revision,expires,deepcopy(result),size)
                        self._bytes += size
                        while len(self._entries)>self.max_entries or self._bytes>self.max_bytes:
                            self._bytes -= self._entries.popitem(last=False)[1][3]
                    return deepcopy(result)
            finally:
                if token is not None:
                    _READ_SNAPSHOT.reset(token)
                if expiry_token is not None:
                    _READ_VALID_UNTIL.reset(expiry_token)
                if projection_token is not None:
                    _READ_PROJECTION.reset(projection_token)
                if db is not None:
                    db.rollback();db.close()
                if owns_load:
                    with self.lock:
                        self._loading.pop(key,None)
                        event.set()
        raise CustomerReadChanged()
