"""Pinned owned child bridge. No public endpoint or standalone send method."""
import os,subprocess,json,secrets,threading,queue,time
from pathlib import Path
from core.adapters import account_execution_lock,AdapterBusy
from core.reply_execution_policy import current_decision,digest,ReplyPolicyError
LIMIT=65536
def _write(stream,value):
 raw=json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n'
 if len(raw.encode())>LIMIT:raise ValueError('回复协议超出固定范围')
 stream.write(raw);stream.flush()
def _reader(stream,messages):
 try:
  while True:
   raw=stream.readline(LIMIT+1)
   if not raw:break
   if len(raw.encode())>LIMIT:raise ValueError('受控回复子进程输出超出范围')
   messages.put_nowait(json.loads(raw))
 except Exception:pass
 finally:
  try:messages.put_nowait(None)
  except queue.Full:pass
def _drain(stream):
 try:
  while stream.read(4096):pass
 except Exception:pass
def transport(decision,request,authorize):
 core=decision.core;adapters=core.adapters
 if current_decision(core) is not decision:raise ReplyPolicyError('原确认队列线程能力缺失')
 decision.check();home=decision.home;manifest=decision.registration.manifest
 executable=(decision.registration.root/manifest['executable']).resolve()
 channel='xiaohongshu:'+str(home)
 with adapters.channel_guard:lock=adapters.channel_locks.setdefault(channel,threading.Lock())
 if not lock.acquire(blocking=False):raise AdapterBusy('该账号正在执行其他操作，本条未启动')
 process=None;key='reviewed-reply:'+request['attemptId'];messages=queue.Queue(maxsize=16)
 try:
  with account_execution_lock(home):
   decision.check();adapters._guard_platform('xiaohongshu');adapters.require_account_safe('xiaohongshu',home)
   # Reuse the original isolation/environment builder; discard its ordinary CLI
   # command and use only the separately hash-pinned fixed owned helper.
   spec=adapters.account_spec('xiaohongshu',home,['whoami','--json'])
   if Path(spec['env']['HOME']).resolve()!=home or Path(spec['env']['USERPROFILE']).resolve()!=home:raise ReplyPolicyError('受控回复账号会话路径不符')
   with adapters.lifecycle_lock:
    if adapters.closed:raise AdapterBusy('工作台正在关闭，本条未启动')
    decision.check();adapters._guard_platform('xiaohongshu')
    environment={**os.environ,**spec['env'],'WORKSPACE_ACTIVITY_KIND':'reply'}
    for name in ('PYTHONPATH','PYTHONHOME','NODE_OPTIONS','NODE_PATH'):environment.pop(name,None)
    process=subprocess.Popen([str(executable),'--owned-xhs-reviewed-reply'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='strict',env=environment,cwd=str(executable.parent),shell=False,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    adapters.processes[key]=process;adapters.process_accounts[key]=home;adapters.job_processes[key]=process
   threading.Thread(target=_reader,args=(process.stdout,messages),daemon=True).start()
   threading.Thread(target=_drain,args=(process.stderr,),daemon=True).start()
   nonce=secrets.token_hex(32);_write(process.stdin,{'type':'hello','version':1,'nonce':nonce,'scope':decision.plan_digest,'request':request})
   stages=['preflight','identity','before_post','post'];seen=0;deadline=time.monotonic()+90
   while True:
    remaining=deadline-time.monotonic()
    if remaining<=0:raise TimeoutError('本条发送状态待核对')
    try:frame=messages.get(timeout=min(remaining,.25))
    except queue.Empty:
     if adapters.closed or core.remote_safety_hold or decision.runtime.closed:raise RuntimeError('原设备已停止，本条状态待核对')
     continue
    if not isinstance(frame,dict) or frame.get('nonce')!=nonce:raise RuntimeError('受控回复协议中断，禁止重试')
    kind=frame.get('type')
    if kind=='authorize':
     if set(frame)!={'type','nonce','wire','stage','detail'} or seen>=4 or frame['stage']!=stages[seen] or not isinstance(frame['wire'],str) or len(frame['wire'])!=32:raise RuntimeError('受控回复请求顺序不符')
     decision.check();adapters._guard_platform('xiaohongshu');authorize(frame['stage'],frame['detail']);seen+=1
     _write(process.stdin,{'type':'allow','nonce':nonce,'wire':frame['wire']})
    elif kind=='result':
     result=frame.get('result')
     if seen!=4 or set(frame)!={'type','nonce','result','digest'} or frame['digest']!=digest(result):raise RuntimeError('受控回复回执不符')
     _write(process.stdin,{'type':'ack','nonce':nonce,'digest':frame['digest']})
     process.wait(timeout=5)
     if process.returncode!=0:raise RuntimeError('受控回复子进程未正常完成')
     return result
    elif kind=='blocked' and seen<4:raise AdapterBusy('实际账号或本批授权已变化，本条未放行平台发送')
    else:raise RuntimeError('发送结果待核对，禁止重试')
 finally:
  if process is not None:
   if process.poll() is None:
    try:process.kill();process.wait(timeout=5)
    except Exception:pass
   for stream in (process.stdin,process.stdout,process.stderr):
    try:stream.close()
    except Exception:pass
   with adapters.lifecycle_lock:
    if adapters.processes.get(key) is process:adapters.processes.pop(key,None);adapters.process_accounts.pop(key,None)
    if adapters.job_processes.get(key) is process:adapters.job_processes.pop(key,None)
  lock.release()
