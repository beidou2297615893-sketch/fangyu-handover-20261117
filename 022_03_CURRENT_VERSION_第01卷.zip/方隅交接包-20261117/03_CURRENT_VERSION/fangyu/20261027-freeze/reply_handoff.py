"""Account-scoped first-reply assistance; consumes current qualification only.

No model, platform, customer classification or sending operation exists here.
"""
from copy import deepcopy
import hashlib,json,re
from followup_workbench import public_text,phones_in

VERSION='first-reply-handoff-20261027-v1'
class HandoffExpired(ValueError):
 code='REPLY_HANDOFF_EXPIRED'
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def phone_hash(value):return digest(['private-customer-phone',value])
def redact_material(value,key=''):
 if isinstance(value,dict):return {k:redact_material(v,k) for k,v in value.items()}
 if isinstance(value,list):return [redact_material(v,key) for v in value]
 if isinstance(value,str) and key not in ('id','authorId','leadId','customerId','accountId','accountUid','accountBinding','accountIdentity','subjectId','sourceDigest','packetDigest','scopeKey','digest','postUrl','noteUrl','url','publishedAt'):
  return public_text(value)
 return value

def confirmed_claims(snapshot):
 """Conservative hints from this account's confirmed facts, never preset examples."""
 role=snapshot.get('roleProfile') or {}
 facts=role.get('roleFacts','') if role.get('configured') is True and role.get('confirmed') is True else ''
 # Match assertions within a clause. "我朋友住/他介绍" and "我想住" do not
 # establish this account's current residence or referral relationship.
 clauses=[part.strip() for part in re.split(r'[，,。；;\n！？!?]',facts) if part.strip()]
 resident=any(re.search(r'^(?:我是.{0,6}(?:租户|住户)|本人(?:是)?(?:真实)?(?:租户|住户)|真实(?:租户|住户)|我(?:也|就|现在|目前|已经)?住(?:在|着)?|我在方隅住)',part) for part in clauses) and not re.search(r'(不是|非|并非).{0,5}(租户|住户)|(不|没|没有|未|不再).{0,3}住|以前住|曾经住|住过',facts)
 discount=any(re.search(r'^(?:我|本人|找我)(?:给你|给客户|帮你|能|可以|可)?(?:介绍|推荐).{0,12}(?:优惠|便宜)',part) for part in clauses) and not re.search(r'(不能|不享|没有|无|未确认|不确定).{0,12}(优惠|便宜)|(优惠|便宜).{0,8}(未知|待核|未确认|不确定)|有没有|是否|能不能|听说|也许',facts)
 points=any(re.search(r'^(?:我(?:给你|能|可以)?|本人)?(?:推荐|介绍).{0,15}积分',part) for part in clauses) and not re.search(r'(没有|无|不享|不返|未确认).{0,8}积分',facts)
 elevator=any(re.search(r'^方隅.{0,6}(有|带|配有)电梯',part) for part in clauses) and not re.search(r'(没有|无|不带|未确认).{0,6}电梯|电梯.{0,8}(未知|待核|未确认|不确定)',facts)
 pet=any(re.search(r'^方隅.{0,8}(允许|可以|能|可).{0,4}(养猫|养狗|养宠物|带猫|带狗|带宠物)',part) for part in clauses) and not re.search(r'(不|未确认).{0,8}(养猫|养狗|养宠物|带猫|带狗|带宠物)',facts)
 return {'resident':bool(resident),'discount':bool(discount),'points':bool(points),'elevator':bool(elevator),'pet':bool(pet)}

def _strategy(snapshot):
 offer=snapshot.get('firstReplyOffer') or {};q=snapshot.get('qualification') or {}
 if offer.get('enabled') is not True:return {'action':'off','preview':''}
 if q.get('aggregateState')!='current':return {'action':'clarify','preview':'当前客户资格需要重新核对，先确认需求与地区；暂不索号或推销。'}
 if q.get('regionMatch') in ('other','conflict') or q.get('eligibility')=='excluded' or q.get('demandState') in ('ended','unrelated') or q.get('role')=='supply' or q.get('interestStatus')=='unrelated':
  return {'action':'blocked','preview':'这位客户当前不进入销售承接，请按原文核对，保留原判断。'}
 if (q.get('aggregateState')!='current' or q.get('regionMatch')!='match' or q.get('demandState') not in ('active','future')
   or q.get('eligibility')!='no_known_exclusion' or q.get('interestStatus')!='graded' or q.get('role') not in ('demand','mixed')):
  return {'action':'clarify','preview':'先确认客人现在是否仍在找房、是否考虑古北；暂不索号或推销。'}
 contact=snapshot.get('selectedContact') or {}
 if offer.get('mode')=='sales_contact' and offer.get('shareContactApproved') is True:
  if contact.get('wechat'):return {'action':'sales_contact','preview':'需要的话，可以联系销售微信 '+contact['wechat']+'，具体房源请销售核对。'}
  if contact.get('phone'):return {'action':'sales_contact','preview':'需要的话，可以联系销售业务电话 '+contact['phone']+'，具体房源请销售核对。'}
 if offer.get('mode')=='request_phone' and snapshot.get('privateReceiverVerified') is True:
  return {'action':'request_phone','preview':'愿意的话，可私下留个联系电话，我帮你对接销售确认。'}
 return {'action':'offer_help','preview':'需要的话，我可以帮你对接销售确认合适的联系途径。'}

def strategy(snapshot):
 policy=_strategy(snapshot);claims=confirmed_claims(snapshot)
 enabled=(snapshot.get('firstReplyOffer') or {}).get('enabled') is True
 eligible=_strategy({**snapshot,'firstReplyOffer':{**(snapshot.get('firstReplyOffer') or {}),'enabled':True}})['action'] in ('offer_help','sales_contact','request_phone')
 policy['capabilities']={'offerEnabled':enabled,'qualificationEligible':eligible,
  'canOfferHelp':enabled and eligible,'canIntroduceDiscount':enabled and eligible and claims['discount'],
  'canDiscloseResident':claims['resident'],'canDisclosePoints':claims['points'],'canStateElevator':claims['elevator']}
 if policy['action']=='offer_help' and policy['capabilities']['canIntroduceDiscount']:
  policy['preview']='需要的话，我帮你问问、约看；我介绍可优惠，具体条件再向销售核对。'
 return policy

def validate_preset_claims(output,snapshot):
 """Additional v2 wording guards, including when the explicit offer is off."""
 text=output.get('reply','');claims=confirmed_claims(snapshot)
 role=snapshot.get('roleProfile') or {};facts=role.get('roleFacts','') if role.get('configured') is True and role.get('confirmed') is True else ''
 if re.search(r'我.{0,8}(租户|住户)|我.{0,6}住[在着]?|我在.{0,8}住',text) and not claims['resident']:
  raise ValueError('当前账号未确认住户事实，不能由表达预设补出')
 if re.search(r'我.{0,6}(是|叫)小北|找小北|报小北|小北.{0,6}(介绍|推荐|帮)',text) and not re.search(r'(我是|本人|我叫).{0,3}小北',facts):raise ValueError('当前账号未确认小北本人身份')
 if '积分' in text and not claims['points']:raise ValueError('当前账号未确认推荐积分关系')
 if re.search(r'(?:方隅|这里|这边|这儿)?(?:有|带|配有)电梯',text) and not re.search(r'有没有电梯|是否.{0,4}电梯|电梯.{0,5}[吗？?]',text) and not claims['elevator']:raise ValueError('当前账号未确认方隅电梯事实，可改为帮问')
 discount=bool(re.search(r'(介绍|推荐|报.{0,8}名字|报小北).{0,12}(优惠|便宜)',text))
 if discount and not claims['discount']:raise ValueError('当前账号未确认本人介绍优惠关系，可改为本人帮问')
 if re.search(r'(优惠|便宜|减免|减|返).{0,4}[0-9一二两三四五六七八九十百千]+.{0,2}(元|块|折)|(保证|一定|肯定).{0,8}(优惠|便宜|返|退)',text):raise ValueError('不能编造具体优惠数额或保证优惠')
 if re.search(r'(肯定|保证|一定).{0,6}(能|可|允许).{0,4}(养猫|养狗|养宠物|带猫|带狗|带宠物)|方隅.{0,8}(允许|可以|能).{0,4}(养猫|养狗|养宠物|带猫|带狗|带宠物)',text) and not claims['pet']:
  raise ValueError('当前账号未确认宠物政策，请围绕客户需求帮问')
 personal=discount or bool(re.search(r'我.{0,6}(帮|给).{0,8}(问|约|联系|对接|介绍)|找我|加我',text))
 if personal and strategy(snapshot)['action'] in ('off','blocked','clarify'):
  raise ValueError('本人承接尚未开启或当前客户资格不允许，先回应或澄清需求')

def validate_reply(output,snapshot,*,preset=False):
 if snapshot is None:return
 text=output.get('reply','');action=strategy(snapshot)['action']
 if any(phone_hash(phone) in snapshot.get('privatePhoneHashes',[]) for phone in phones_in(text)):raise ValueError('客户私有手机号不能写入公开回复')
 allowed=phones_in((snapshot.get('selectedContact') or {}).get('phone',''))
 if phones_in(text)-allowed:raise ValueError('回复出现未获准展示的电话号码')
 if re.search(r'(公开|评论区|评论里|这里).{0,12}(贴|发|留).{0,8}(电话|手机|号码)|(电话|手机|号码).{0,12}(贴|发|留).{0,8}(评论|公开)',text):raise ValueError('公开评论不能要求客人公开贴手机号')
 if snapshot.get('privateReceiverVerified') is not True and re.search(r'私信我|软件.{0,8}(收到|接收|转交)|自动.{0,6}(转交|联系销售)|留.{0,5}(电话|手机号|号码)',text):raise ValueError('当前没有已验证的私下接收途径，不能索号或声称自动承接')
 if action in ('blocked','clarify') and re.search(r'销售|微信|加微|电话|手机号|对接|推荐.{0,8}方隅',text):raise ValueError('当前资格需要澄清或停止销售承接，不能附销售诉求')
 if preset or (snapshot.get('firstReplyOffer') or {}).get('enabled') is True:validate_preset_claims(output,snapshot)
 if (snapshot.get('firstReplyOffer') or {}).get('enabled') is True:
  role=snapshot.get('roleProfile') or {};facts=role.get('roleFacts','') if role.get('configured') is True and role.get('confirmed') is True else ''
  # Narrow claim guards only: no rental/region classification is done here.
  resident=confirmed_claims(snapshot)['resident']
  if re.search(r'我是.{0,8}(租户|住户)|我.{0,6}住在',text) and not resident:raise ValueError('当前账号资料未支持这段住户身份，不能由风格补出')
  if re.search(r'我是.{0,8}(销售|员工|顾问)',text) and not re.search(r'我是.{0,8}(销售|员工|顾问)',facts):raise ValueError('当前账号资料未支持这段员工身份')
  if '积分' in text and (not re.search(r'(推荐|介绍).{0,15}积分',facts) or re.search(r'(没有|无|不享|不返).{0,8}积分',facts)):raise ValueError('当前账号资料未确认推荐积分关系，不能加入候选')
  if re.search(r'(保证|一定|肯定).{0,8}(返|退|积分)|(返|退).{0,4}[0-9]+.{0,2}元',text):raise ValueError('候选不能承诺固定返额或保证返款')

def capture(backend,user,scope,customer_id,token,row=None,*,db=None):
 service=getattr(backend,'followup_workbench',None)
 if service is None:return None  # Older injected fixtures have no handoff feature.
 identity=getattr(backend,'_analysis_local_identity',None) or backend._identity
 actor,profile=identity(token)
 if any(actor.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')):raise HandoffExpired('员工身份已变化，承接候选已过期')
 check=backend._followup_write_authority(token,actor,profile,scope[2])
 def authority(connection,principal,account_scope,writing):check(connection);return True
 prefs,account=service.workflow_preferences(actor,scope,authority_check=authority,db=db)
 from reply_account_profiles import AccountProfiles
 profiles=AccountProfiles(backend);account_scope=[scope[0],scope[1],actor['username'],scope[2],scope[4]]
 role=profiles.profile(account_scope,scope[3]);role_current=role.get('configured') is True and role.get('confirmed') is True and role.get('accountIdentity')==profiles.identity_binding(account)
 _,_,item,person=backend.customer_workbench.detail_context(actor,scope[2],customer_id,platform=scope[4])
 projection=person.get('_current_projection') or {};record=projection.get('record') or {}
 current=item.get('aggregateState')=='current' and projection.get('state')=='current' and bool(record.get('contract_digest')) and bool(record.get('context_digest'))
 region=item.get('regionMatch') or {};eligibility=item.get('storeEligibility') or {}
 qualification={'aggregateState':'current' if current else 'stale','interestStatus':item.get('interestStatus'),'interestLevel':item.get('interestLevel'),
  'demandState':item.get('demandState'),'regionMatch':region.get('state'),'eligibility':eligibility.get('state'),'role':eligibility.get('role'),
  'contractDigest':record.get('contract_digest',''),'guardVersion':record.get('evidence_guard_version',''),'aggregationVersion':record.get('aggregation_version',''),
  'batchId':record.get('batch_id',''),'contextDigest':record.get('context_digest',''),'recordDigest':digest(record),'membersDigest':digest(record.get('members',[]))}
 private=set()
 for comment in person.get('comments',[]):
  private|=phones_in(str(comment.get('text') or (comment.get('lead') or {}).get('text') or ''))
 for saved in backend.core.store.list('ui_customer_followup_private_phone_v1',scope[0]):
  if all(saved.get(k)==v for k,v in {'owner':actor['username'],'userId':scope[1],'storeId':scope[2],'accountId':scope[3],'customerId':customer_id}.items()):private|=phones_in(str(saved.get('phone') or ''))
 snapshot={'version':VERSION,'scope':{'tenantId':scope[0],'userId':scope[1],'owner':actor['username'],'storeId':scope[2],'accountId':scope[3],'platform':scope[4],'customerId':customer_id},
  'actorDigest':digest({k:actor.get(k) for k in ('id','tenant_id','username','role','cloud_bound','can_reply','permission_revision','disabled')}),
  'firstReplyOffer':deepcopy(prefs['firstReplyOffer']),'preferencesRevision':prefs['version'],'preferencesDigest':digest(prefs),
  'identityDisclosure':public_text(prefs['identityDisclosure']),'referralName':prefs['referralName'],
  'roleProfile':{'revision':role.get('revision',0),'configured':role_current,'confirmed':role_current,'roleFacts':public_text(role.get('roleFacts','')) if role_current else '', 'digest':digest(role)},
  'accountIdentityDigest':profiles.identity_binding(account),'qualification':qualification,'selectedContact':{},'privateReceiverVerified':False,
  'privatePhoneHashes':sorted(phone_hash(phone) for phone in private),'sourceDigest':(row or {}).get('sourceDigest',''),'contextBindingDigest':digest((row or {}).get('sourceBinding'))}
 offer=snapshot['firstReplyOffer']
 if offer['enabled'] and offer['mode']=='sales_contact' and offer['shareContactApproved'] and strategy(snapshot)['action'] not in ('blocked','clarify'):
  wechat=prefs['salesWechat'];phone=prefs['salesPhone']
  if any(number in private for number in phones_in(wechat+phone)):raise ValueError('客户手机号不能被当作销售联系方式')
  snapshot['selectedContact']={**({'wechat':wechat} if wechat else {}),**({'phone':phone} if phone else {})}
 snapshot['policy']=strategy(snapshot)
 return snapshot

def revalidate(backend,user,scope,customer_id,token,expected,row=None,*,db=None):
 if expected is None:return
 try:actual=capture(backend,user,scope,customer_id,token,row,db=db)
 except (ValueError,KeyError,TypeError) as error:raise HandoffExpired('当前身份、权限或承接来源已变化，候选已过期；原草稿保留') from None
 if digest(actual)!=digest(expected):raise HandoffExpired('承接设置、真实身份或客户当前资格已变化，候选已过期；原草稿保留')
