"""RAM-only verified browsing scope; never an online-action authorization.

One daemon serializes refreshes. A blocked transport holds no browsing lock.
Generation comparison prevents old responses restoring logged-out/replaced scopes.
"""
from copy import deepcopy
import hashlib
import threading
import time

ACTOR_FIELDS=('id','tenant_id','username','role','cloud_bound','store_id')

class LocalBrowseScope:
    def __init__(self, refresh, *, interval=60):
        self.refresh=refresh;self.interval=interval
        self.lock=threading.RLock();self.entries={};self.generation=0
        self.stop=threading.Event();self.thread=None

    @staticmethod
    def key(token):return hashlib.sha256(token.encode()).hexdigest()

    @staticmethod
    def authority(profile):
        """Ignore only known issuance/local-display metadata, never grants."""
        value=deepcopy(profile)
        for field in ('_workbench_store_id','_local_browse_generation','_workbench_directory_notice'):
            value.pop(field,None)
        directory=value.get('_central_directory')
        scope=directory.get('scope') if isinstance(directory,dict) else None
        if isinstance(scope,dict):scope.pop('issued_at',None)
        return value

    def remember(self, token, user, profile):
        with self.lock:
            if self.stop.is_set():return False
            key=self.key(token);previous=self.entries.get(key)
            actor={k:user.get(k) for k in ACTOR_FIELDS}
            unchanged=(previous is not None and previous['actor']==actor
                and self.authority(previous['profile'])==self.authority(profile))
            if not unchanged:self.generation+=1
            self.entries[key]={'token':token,'actor':actor,
                'profile':deepcopy(profile),'generation':previous['generation'] if unchanged else self.generation,
                'refresh_revision':previous.get('refresh_revision',0)+1 if previous else 1,
                'next':time.monotonic()+self.interval}
            # Only recent local sessions; no on-disk scope or credential copy.
            while len(self.entries)>8:self.entries.pop(next(iter(self.entries)))
            if self.thread is None:
                self.thread=threading.Thread(target=self._run,name='local-browse-permission-sync',daemon=True)
                self.thread.start()

    def snapshot(self, token):
        with self.lock:return deepcopy(self.entries.get(self.key(token)))

    def invalidate(self, token):
        with self.lock:
            self.generation+=1;self.entries.pop(self.key(token),None)

    def apply(self, saved, profile):
        with self.lock:
            key=self.key(saved['token']);current=self.entries.get(key)
            if (self.stop.is_set() or not current or current['generation']!=saved['generation']
                    or current.get('refresh_revision',0)!=saved.get('refresh_revision',0)):return False
            changed=profile is None or self.authority(current['profile'])!=self.authority(profile)
            if changed:self.generation+=1
            if profile is None:self.entries.pop(key,None)
            else:current.update(profile=deepcopy(profile),
                generation=self.generation if changed else current['generation'],
                refresh_revision=current.get('refresh_revision',0)+1,next=time.monotonic()+self.interval)
            return True

    def _run(self):
        while not self.stop.wait(1):
            with self.lock:
                due=[deepcopy(v) for v in self.entries.values() if v['next']<=time.monotonic()]
                for item in due:self.entries[self.key(item['token'])]['next']=time.monotonic()+self.interval
            for saved in due:
                if self.stop.is_set():return
                try:profile=self.refresh(saved)
                except Exception:continue  # Transport failure does not mean revocation.
                self.apply(saved,profile)

    def close(self):
        self.stop.set()
        with self.lock:self.entries.clear();self.generation+=1
        # Do not join: a transport may still be hung. It can never commit again.
