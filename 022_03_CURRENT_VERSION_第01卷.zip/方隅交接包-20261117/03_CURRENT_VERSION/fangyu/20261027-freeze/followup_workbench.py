"""Scoped customer replies over existing verified response evidence.

No platform or cloud transport is created here. Reads never mark messages read.
Private phones are separate from leads and public customer projections.
"""
from copy import deepcopy
from contextlib import nullcontext
from datetime import datetime,timezone
import hashlib,json,re
from urllib.parse import urlsplit

ACTIONS=frozenset(('followup_inbox_read','followup_thread_read','followup_state_save','followup_draft_save','followup_preferences_read','followup_preferences_save','followup_phone_save','followup_phone_read','followup_request_read'))
STATE='ui_customer_followup_state_v1';DRAFT='ui_customer_followup_draft_v1';PREF='ui_customer_followup_preferences_v1';PHONE='ui_customer_followup_private_phone_v1';REQUEST='ui_customer_followup_request_v1'
ID=re.compile(r'[A-Za-z0-9_-]{1,160}\Z');HASH=re.compile(r'[a-f0-9]{64}\Z')
BASE={'storeId','accountId','platform','viewId'}
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def epoch(value):
 if type(value) in (int,float):return value if 0<value<253402300799 else 0
 try:return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
 except (AttributeError,TypeError,ValueError,OverflowError):return 0
def note(value):
 try:
  u=urlsplit(value);m=re.fullmatch(r'/(?:explore|search_result|discovery/item)/([A-Za-z0-9]{24})/?',u.path)
  if u.scheme=='https' and u.hostname in ('xiaohongshu.com','www.xiaohongshu.com') and u.port in (None,443) and not u.username and not u.password and m:return m[1].lower()
 except (ValueError,TypeError):pass
 return ''
def masked(value):return value[:3]+'****'+value[-4:]
PHONE_PATTERN=re.compile(r'(?<![0-9])1[3-9](?:[ \t()+-]*[0-9]){9}(?![0-9])')
def digits(value):return re.sub(r'[^0-9]','',value)
def phones_in(value):return {digits(m[0]) for m in PHONE_PATTERN.finditer(value)}
def public_text(value):return PHONE_PATTERN.sub(lambda m:masked(digits(m[0])),value)
def first_offer(value=None):
 if value is None:return {'enabled':False,'mode':'request_phone','shareContactApproved':False}
 if not isinstance(value,dict) or set(value)!={'enabled','mode','shareContactApproved'} or type(value['enabled']) is not bool or type(value['shareContactApproved']) is not bool or value['mode'] not in ('request_phone','sales_contact'):fail('FOLLOWUP_CONTACT_INVALID','请选择有效首轮承接设置')
 return deepcopy(value)
class FollowupError(ValueError):
 def __init__(self,code,message,status=400):super().__init__(message);self.code,self.status=code,status
def fail(code,message,status=400):raise FollowupError(code,message,status)

class FollowupWorkbench:
 def __init__(self,core,customers):self.core,self.store,self.customers=core,core.store,customers
 @staticmethod
 def _get(db,entity,key,tenant):
  row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',(entity,key,tenant)).fetchone()
  return json.loads(row['body']) if row else None
 @staticmethod
 def _put(db,entity,row):db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))
 def _authorize(self,db,user,store,account_id,platform,authority,writing):
  saved=self._get(db,'users',user.get('id'),user.get('tenant_id')) or {}
  if saved.get('disabled') or saved.get('cloud_bound') is not True or saved.get('development_local_only') is True or saved.get('role') not in ('operator','admin') or any(saved.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')):fail('FOLLOWUP_FORBIDDEN','员工身份已变化，请重新登录',403)
  account=self._get(db,'accounts',account_id,user['tenant_id']) or {}
  if account.get('cloud_owner')!=user['username'] or account.get('store_id')!=store or account.get('platform')!=platform or not account.get('platform_uid'):fail('FOLLOWUP_ACCOUNT_FORBIDDEN','请选择当前门店本人已核对身份的账号',403)
  self.core._account_access(saved,account)
  scope=dict(tenant_id=user['tenant_id'],owner=user['username'],userId=user['id'],storeId=store,accountId=account_id,platform=platform,accountUid=account['platform_uid'])
  if not callable(authority) or authority(db,saved,scope,writing) is not True:fail('FOLLOWUP_FORBIDDEN','当前会话或门店权限已变化',403)
  return scope,account
 def _sources(self,db,user,store,scope,account):
  if scope['platform']!='xiaohongshu':return []
  if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='contact_response_outbox'").fetchone():return []
  has_blocks=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='contact_response_blocks'").fetchone()
  rows=db.execute('SELECT o.payload,o.payload_hash FROM contact_response_outbox o '+('LEFT JOIN contact_response_blocks b ON b.observation_id=o.observation_id ' if has_blocks else '')+'WHERE o.tenant_id=? AND o.cloud_owner=? '+('AND b.observation_id IS NULL ' if has_blocks else '')+'ORDER BY o.sequence DESC',(scope['tenant_id'],scope['owner'])).fetchall()
  result={};conflicts=set();customer_cache={}
  for row in rows:
   try:
    body=json.loads(row['payload'])
    if not isinstance(body,dict) or not isinstance(body.get('response'),dict):continue
    incoming=body['response']
    if digest(body)!=row['payload_hash'] or incoming.get('platform')!='xiaohongshu':continue
    reply=self._get(db,'replies',body['local_reply_id'],scope['tenant_id']) or {}
    anchor=self._get(db,'leads',reply.get('lead_id'),scope['tenant_id']) or {}
    lead=self.core._reply_source(reply,user,account) if reply.get('followup_target_id') else anchor
    if (reply.get('status')!='sent' or reply.get('account_id')!=account['id'] or reply.get('platform_reply_id')!=body['platform_reply_id'] or lead.get('platform')!='xiaohongshu' or lead.get('cloud_owner')!=scope['owner'] or lead.get('store_id') not in (None,'',store) or body['origin_comment_id']!=lead.get('comment_id') or incoming.get('author_id')!=lead.get('author_id') or incoming.get('target_comment_id')!=reply.get('platform_reply_id') or incoming.get('target_author_id')!=account['platform_uid'] or incoming.get('comment_id') in (lead.get('comment_id'),reply.get('platform_reply_id')) or not note(incoming.get('note_url')) or note(incoming.get('note_url'))!=note(lead.get('note_url')) or epoch(incoming.get('published_at'))<=epoch(reply.get('sent_at')) or not isinstance(incoming.get('text'),str) or not 0<len(incoming['text'])<=3000):continue
    if not all(isinstance(incoming.get(k),str) and ID.fullmatch(incoming[k]) for k in ('author_id','comment_id','target_comment_id','target_author_id')):continue
    proof=self.core.contact_journal.sent_snapshot(scope['tenant_id'],scope['owner'],body['sent_event_id'],reply['id'],lead['id'])
    if not proof or any(proof.get('sender',{}).get(k)!=v for k,v in [('account_id',account['id']),('platform_uid',account['platform_uid'])]) or any(proof.get('lead',{}).get(k)!=lead.get(k) for k in ('author_id','comment_id')) or proof.get('reply',{}).get('platform_reply_id')!=reply['platform_reply_id']:continue
    customer_id=hashlib.sha256(json.dumps((lead['platform'],'uid',lead['author_id']),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    if customer_id not in customer_cache:customer_cache[customer_id]=self.customers.detail_context(user,store,customer_id,platform='xiaohongshu')
    _,_,item,person=customer_cache[customer_id]
    if anchor['id'] not in {c.get('lead_id') for c in person.get('comments',[])} or person.get('author_id')!=lead['author_id']:continue
    binding=dict(platform='xiaohongshu',accountId=account['id'],accountUid=account['platform_uid'],customerId=customer_id,customerUid=lead['author_id'],originLeadId=lead['id'],originReplyId=reply['id'],originCommentId=lead['comment_id'],sentEventId=body['sent_event_id'],platformReplyId=reply['platform_reply_id'],targetCommentId=incoming['comment_id'],targetAuthorId=incoming['author_id'],postId=note(incoming['note_url']),publishedAt=incoming['published_at'],text=incoming['text'])
    key=digest([scope,incoming['comment_id'],binding['postId']]);event_digest=digest(binding)
    event=dict(id=key,eventDigest=event_digest,**binding,name=str(item.get('name') or '客户'),sourceUrl='https://www.xiaohongshu.com/explore/'+binding['postId'],originalText=str(lead.get('text') or ''),sentText=str(reply.get('text') or ''),sentAt=reply.get('sent_at'),sourceLabel='已核对的客户评论回应',channelLabel='小红书评论',observationId=body['observation_id'])
    if key in result and result[key]['eventDigest']!=event_digest:conflicts.add(key)
    else:result[key]=event
   except (ValueError,KeyError,TypeError):continue
  return [value for key,value in result.items() if key not in conflicts]
 def _check_candidates(self,db,user,store,scope,account):
  if scope['platform']!='xiaohongshu':return []
  rows=db.execute("SELECT body FROM records WHERE entity='replies' AND tenant_id=? AND json_extract(body,'$.account_id')=? AND json_extract(body,'$.status')='sent'",(scope['tenant_id'],account['id'])).fetchall()
  candidates=[];cache={}
  for found in rows:
   try:
    reply=json.loads(found['body']);anchor=self._get(db,'leads',reply.get('lead_id'),scope['tenant_id']) or {}
    if not anchor.get('author_id') or anchor.get('platform')!='xiaohongshu' or not ID.fullmatch(str(reply.get('platform_reply_id') or '')):continue
    customer_id=hashlib.sha256(json.dumps(('xiaohongshu','uid',anchor['author_id']),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    if customer_id not in cache:cache[customer_id]=self.customers.detail_context(user,store,customer_id,platform='xiaohongshu')
    _,_,item,person=cache[customer_id]
    if anchor['id'] not in {r.get('lead_id') for r in person.get('comments',[])}:continue
    receipt=self.core.contact_journal.receipt(scope['tenant_id'],scope['owner'],reply['id'],anchor['id'])
    if receipt.get('local_outcome')!='sent' or receipt.get('local_integrity')!='ok' or not receipt.get('local_sent_event_id'):continue
    actual=self.core._reply_source(reply,user,account) if reply.get('followup_target_id') else anchor
    if not note(actual.get('note_url')):continue
    candidates.append(dict(customerId=customer_id,replyId=reply['id'],name=str(item.get('name') or '客户'),sentAt=reply.get('sent_at') or '',sentText=public_text(str(reply.get('text') or '')),sourceText=public_text(str(actual.get('text') or ''))))
   except (ValueError,KeyError,TypeError):continue
  return sorted(candidates,key=lambda r:(epoch(r['sentAt']),r['replyId']),reverse=True)[:100]
 def _project(self,db,scope,event):
  state=self._get(db,STATE,event['id'],scope['tenant_id']) or {};draft=self._get(db,DRAFT,event['id'],scope['tenant_id']);phone=self._get(db,PHONE,event['id'],scope['tenant_id'])
  value=deepcopy(event);value.update(version=state.get('version',0),state=state.get('state','new'),unread=state.get('state','new')=='new')
  for key in ('text','originalText','sentText'):value[key]=public_text(value[key])
  value['draft']={k:draft[k] for k in ('text','version','targetCommentId','originReplyId','savedAt')} if draft and draft.get('eventDigest')==event['eventDigest'] else None
  value['phone']={'masked':masked(phone['phone']),'source':'客户本人自愿提供','savedAt':phone['savedAt'],'referralName':phone.get('referralName',''),'handoffState':'已保存，尚未交销售'} if phone else None
  return value
 def _preferences(self,db,scope):
  key=digest(['followup-preferences',scope]);row=self._get(db,PREF,key,scope['tenant_id'])
  return {**{k:row[k] for k in ('version','mode','salesWechat','salesPhone','identityDisclosure')},'referralName':row.get('referralName','小北'),'firstReplyOffer':first_offer(row.get('firstReplyOffer'))} if row else dict(version=0,mode='request_phone',salesWechat='',salesPhone='',identityDisclosure='',referralName='小北',firstReplyOffer=first_offer())
 def workflow_preferences(self,user,scope,*,authority_check,db=None):
  if len(scope)!=5 or scope[0]!=user.get('tenant_id') or scope[1]!=user.get('id'):fail('FOLLOWUP_FORBIDDEN','承接偏好账号范围已变化',403)
  with nullcontext(db) if db is not None else self.store.connect() as connection:
   if db is None:connection.execute('BEGIN')
   account_scope,account=self._authorize(connection,user,scope[2],scope[3],scope[4],authority_check,False)
   return self._preferences(connection,account_scope),account
 def execute(self,action,user,store,data,*,authority_check=None):
  if action not in ACTIONS or not isinstance(data,dict) or data.get('storeId')!=store or data.get('platform') not in ('xiaohongshu','douyin') or not all(isinstance(data.get(k),str) and ID.fullmatch(data[k]) for k in ('storeId','accountId','viewId')):fail('FOLLOWUP_INPUT','请选择当前门店、账号和回复页面')
  extra={
   'followup_inbox_read':set(),'followup_thread_read':{'eventId'},'followup_state_save':{'eventId','eventDigest','expectedVersion','state','requestId'},'followup_draft_save':{'eventId','eventDigest','expectedVersion','text','requestId'},'followup_preferences_read':set(),'followup_preferences_save':{'expectedVersion','mode','salesWechat','salesPhone','identityDisclosure','referralName','requestId'},'followup_phone_save':{'eventId','eventDigest','expectedVersion','phone','voluntary','consentText','requestId'},'followup_phone_read':{'eventId'},'followup_request_read':{'operation','requestId'}}[action]
  if set(data)-({'firstReplyOffer'} if action=='followup_preferences_save' else set())!=BASE|extra:fail('FOLLOWUP_INPUT','回复操作参数不完整')
  writing=action.endswith('_save')
  if writing and (not isinstance(data.get('requestId'),str) or not ID.fullmatch(data['requestId']) or type(data.get('expectedVersion')) is not int or data['expectedVersion']<0):fail('FOLLOWUP_INPUT','请保留原操作编号和版本')
  with self.store.connect() as db:
   db.execute('BEGIN IMMEDIATE' if writing else 'BEGIN')
   scope,account=self._authorize(db,user,store,data['accountId'],data['platform'],authority_check,writing)
   context=dict(viewId=data['viewId'],storeId=store,accountId=account['id'],platform=account['platform'],actorId=user['id'],scopeKey=digest(scope))
   answer=dict(context=context,refreshedAt=stamp(),capabilities=dict(platformReadConnected=False,commentReplyAvailable=account['platform']=='xiaohongshu',directMessageAvailable=False,message='仅刷新本机已核对的评论回应；平台单次检查由原安全链单独执行。' if account['platform']=='xiaohongshu' else '当前回复箱尚未接入抖音评论回应；私信请使用原私信入口。'))
   if action=='followup_request_read':
    if data['operation'] not in ACTIONS or not data['operation'].endswith('_save') or not isinstance(data['requestId'],str) or not ID.fullmatch(data['requestId']):fail('FOLLOWUP_INPUT','请保留原操作编号')
    request=self._get(db,REQUEST,digest([scope,data['operation'],data['requestId']]),scope['tenant_id'])
    answer['receipt']=deepcopy(request['result']['receipt']) if request else dict(requestId=data['requestId'],state='not_found');return answer
   events=self._sources(db,user,store,scope,account) if not action.startswith('followup_preferences') else []
   event=next((e for e in events if e['id']==data.get('eventId')),None)
   if 'eventId' in data and event is None:fail('FOLLOWUP_SOURCE_CHANGED','回信不在当前账号、门店范围，或原证据已变化',404)
   if action=='followup_inbox_read':
    answer['items']=sorted([self._project(db,scope,e) for e in events],key=lambda e:(e['publishedAt'],e['id']),reverse=True);answer['unreadCount']=sum(e['unread'] for e in answer['items']);answer['checkCandidates']=self._check_candidates(db,user,store,scope,account);return answer
   if action=='followup_thread_read':answer['item']=self._project(db,scope,event);answer['originalInboundText']=event['text'];return answer
   if action=='followup_preferences_read':answer['preferences']=self._preferences(db,scope);return answer
   if action=='followup_phone_read':
    row=self._get(db,PHONE,event['id'],scope['tenant_id']);answer.update(phone=row['phone'] if row else '',sourceText=row['consentText'] if row else '');return answer
   if event and data['eventDigest']!=event['eventDigest']:fail('FOLLOWUP_SOURCE_CHANGED','回信原文已变化，请重新读取',409)
   request_key=digest([scope,action,data['requestId']]);request=self._get(db,REQUEST,request_key,scope['tenant_id']);signature=digest({k:v for k,v in data.items() if k!='viewId'})
   if request:
    if request['signature']!=signature:fail('FOLLOWUP_REQUEST_CONFLICT','原操作编号内容已变化，请保留原操作核对',409)
    answer.update(deepcopy(request['result']));return answer
   current=self._get(db,STATE,event['id'],scope['tenant_id']) if event else None
   version=current.get('version',0) if current else 0
   if action=='followup_preferences_save':version=self._preferences(db,scope)['version']
   if data['expectedVersion']!=version:fail('FOLLOWUP_VERSION_CHANGED','记录已在其他窗口变化，请刷新后核对',409)
   result={}
   if action=='followup_preferences_save':
    mode=data['mode'];wechat=data['salesWechat'];phone=data['salesPhone'];identity=data['identityDisclosure'];referral=data['referralName']
    if mode not in ('unconfigured','share_sales','request_phone') or not all(isinstance(v,str) and len(v)<=120 and not re.search(r'[\x00-\x1f\x7f]',v) for v in (wechat,phone,identity,referral)) or len(referral)>40 or phone and not re.fullmatch(r'\+?[0-9 ()-]{6,30}',phone) or mode=='share_sales' and not (wechat.strip() or phone.strip()):fail('FOLLOWUP_CONTACT_INVALID','请填写真实销售联系方式，或选择请求客户自愿留电话')
    offer=first_offer(data.get('firstReplyOffer',self._preferences(db,scope)['firstReplyOffer']))
    row=dict(id=digest(['followup-preferences',scope]),**scope,version=version+1,mode=mode,salesWechat=wechat.strip(),salesPhone=phone.strip(),identityDisclosure=identity.strip(),referralName=referral.strip(),firstReplyOffer=offer);self._put(db,PREF,row);result['preferences']=self._preferences(db,scope)
   else:
    if action=='followup_state_save' and data['state'] not in ('new','viewed','follow_up'):fail('FOLLOWUP_STATE_INVALID','请选择待查看、已查看或待跟进')
    if action=='followup_draft_save':
     if not isinstance(data['text'],str) or not data['text'].strip() or len(data['text'])>1000 or re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]',data['text']):fail('FOLLOWUP_DRAFT_INVALID','请填写1至1000字的跟进草稿')
     private=self._get(db,PHONE,event['id'],scope['tenant_id']) or {}
     phones=phones_in(event['text'])|({private['phone']} if private.get('phone') else set())
     if phones&phones_in(data['text']):fail('FOLLOWUP_PRIVATE_PHONE','客户手机号只用于私有承接，不能写入公开评论回复')
     self._put(db,DRAFT,dict(id=event['id'],**scope,eventDigest=event['eventDigest'],version=version+1,text=data['text'].strip(),targetCommentId=event['targetCommentId'],originReplyId=event['originReplyId'],originLeadId=event['originLeadId'],savedAt=stamp()))
    if action=='followup_phone_save':
     phone=data['phone'];quote=data['consentText']
     if data['voluntary'] is not True or not isinstance(phone,str) or not re.fullmatch(r'1[3-9][0-9]{9}',phone) or not isinstance(quote,str) or not quote.strip() or quote not in event['text'] or phone not in phones_in(quote):fail('FOLLOWUP_PHONE_INVALID','只登记这条回信中客户本人自愿提供的手机号，请保留对应原话')
     self._put(db,PHONE,dict(id=event['id'],**scope,eventDigest=event['eventDigest'],phone=phone,consentText=quote,savedAt=stamp(),customerId=event['customerId'],sourceEventId=event['id'],referralName=self._preferences(db,scope)['referralName'],handoffState='saved_not_handed_off'))
    state=data['state'] if action=='followup_state_save' else (current or {}).get('state','new')
    self._put(db,STATE,dict(id=event['id'],**scope,eventDigest=event['eventDigest'],version=version+1,state=state,updatedAt=stamp()))
    result['item']=self._project(db,scope,event)
   result['receipt']=dict(requestId=data['requestId'],state='accepted',version=version+1)
   # Receipts store only a request hash and masked projections, never the phone.
   self._put(db,REQUEST,dict(id=request_key,**scope,signature=signature,result=result,createdAt=stamp()))
   answer.update(result);return answer
