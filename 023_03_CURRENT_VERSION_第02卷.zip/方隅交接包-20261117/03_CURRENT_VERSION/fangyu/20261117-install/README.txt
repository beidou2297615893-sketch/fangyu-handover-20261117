方隅自动获客系统（浅色认可界面 · 2026-11-17）

入口：用桌面「方隅工作台（新版试用）」打开。
本目录由 desktop-python + employee.py 启动，窗口可放大、缩小、最大化，画面铺满。

状态目录仍使用：
  %LOCALAPPDATA%\FangyuDesktopDirect-20261114-state
以便继承已记住的门店。

登录只连普通抖音页 https://www.douyin.com/jingxuan，不会打开创作者中心。
启动／暂停接到原来的本地控制通道；外部回复默认草稿审核。
不要用本目录去替换或结束正在跑的采集、发送或 Bridge 进程。
