// Only moves existing nodes and remembers visual disclosure state; no API calls.
const opened=new Map(),bound=new WeakSet(),alerts=new WeakMap();let queued=false;
function refresh(){
 queued=false;const shell=document.querySelector('.shell');if(!shell){opened.clear();return;}
 const host=document.getElementById('platform-notice-host'),status=document.querySelector('.acquire-current .acquire-status-row'),content=document.getElementById('page-content');
 if(host&&status){if(status.nextElementSibling!==host)status.after(host);}
 else if(host&&content&&content.previousElementSibling!==host)content.before(host);
 for(const node of shell.querySelectorAll('details[data-ui-disclosure]')){
   const alert=[...node.querySelectorAll('[role="alert"]')].map(n=>n.textContent.trim()).filter(Boolean).join('\n');
   const newAlert=Boolean(alert&&alerts.get(node)!==alert);alerts.set(node,alert);
   if(newAlert)node.open=true;
   if(bound.has(node))continue;bound.add(node);
   const key=[shell.dataset.current,shell.dataset.platform,node.dataset.uiDisclosure].join('|');
   if(!alert&&opened.has(key))node.open=opened.get(key);
   node.addEventListener('toggle',()=>opened.set(key,node.open));
 }
}
new MutationObserver(()=>{if(!queued){queued=true;requestAnimationFrame(refresh);}}).observe(document.getElementById('app'),{childList:true,subtree:true});
refresh();
