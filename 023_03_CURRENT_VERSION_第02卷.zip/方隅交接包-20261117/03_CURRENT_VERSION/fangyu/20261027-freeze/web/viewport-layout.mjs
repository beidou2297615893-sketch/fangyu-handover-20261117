// The design viewport may reflow; readable type does not shrink indefinitely.
export const DESIGN_VIEWPORTS=Object.freeze({login:[1487,1058],acquire:[1585,992],diversified:[1585,992],content:[1585,992],reply:[1585,992],customers:[1586,992],presets:[1586,992],accounts:[1585,992],rules:[1586,992],tone:[1586,992],aiModel:[1586,992]});
export function viewportMetrics(width,height,page){
  if(!Number.isFinite(width)||!Number.isFinite(height)||width<=0||height<=0)return null;
  const [baseWidth,baseHeight]=DESIGN_VIEWPORTS[page]||DESIGN_VIEWPORTS.login;
  const natural=Math.min(width/baseWidth,height/baseHeight);
  const scale=page==='login'?natural:Math.max(.85,natural);
  return {scale,width:width/scale,height:height/scale,layoutY:(height/scale)/baseHeight};
}
export function paneHeight({viewportHeight,top,footerTop,compact}){
  if(compact)return Math.max(320,Math.min(560,Math.floor(viewportHeight*.62)));
  return Math.max(0,Math.floor(Math.min(footerTop,viewportHeight-24)-top-20));
}
