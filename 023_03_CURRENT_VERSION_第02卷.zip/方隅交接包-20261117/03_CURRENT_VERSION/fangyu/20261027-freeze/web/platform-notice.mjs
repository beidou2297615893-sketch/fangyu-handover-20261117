const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const running=new Set(['queued','running','resuming','pausing','stopping']);
const platforms=['xiaohongshu','douyin'];
const identity=s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId||'']);
function snapshots(s){
  if(s.connection!=='connected'||!s.session)return [];
  return platforms.map(id=>[id,id===(s.activePlatform||'xiaohongshu')?s.platform:s.platformWorkspaces?.[id]?.platform])
    .filter(([id,p])=>p?.actor?.username===s.user&&p?.actor?.storeId===s.storeId&&p?.acquisition?.taskId
      &&(!p.acquisition.taskScope?.platform||p.acquisition.taskScope.platform===id));
}
export function platformNotices(s){
  return snapshots(s).flatMap(([id,p])=>{
    if(id==='xiaohongshu'&&p.capabilities?.browserFirstAcquisition===true)return [];
    const a=p.acquisition,category=a.platformError?.category;
    if(running.has(a.status)||!category)return [];
    const name=id==='xiaohongshu'?'小红书':'抖音';
    const messages={
      verification_required:[`${name}当前读取页需要验证`,id==='xiaohongshu'?'平台要求当前读取页验证；请在原账号网页完成后，点击下方“我已完成验证”核对原任务。':'请到账号页查看此抖音账号的提示，在平台网页完成验证后再继续。'],
      authentication_required:[`${name}登录已失效`,'请在原账号网页重新登录，完成后点击下方“我已完成验证”核对原任务。'],
      platform_rejected:[`${name}暂未允许继续读取`,'请查看账号页面是否有平台提示；当前不能确认是登录问题。'],
      rate_limited:[`${name}暂时限制读取频率`,'请稍后查看账号状态，再手动继续原任务。'],
      transport_error:[`${name}连接中断`,'请检查网络后继续原任务。'],
      compatibility_error:[`${name}接口暂不兼容`,'请联系管理员更新客户端，任务断点已保留。'],
      protocol_error:[`${name}读取结果未确认`,'请联系管理员核对本次记录，避免重复读取。'],
      unknown:[`${name}读取未完成`,'请查看账号状态；仍未恢复时联系管理员。']};
    if(!messages[category])return [];
    return [{id,taskId:a.taskId,category,title:messages[category][0],body:messages[category][1],
      accountId:a.taskScope?.accountId||'',verificationId:a.verificationId||'',verification:a.verification||{},deviceReady:p.device?.state==='online'&&p.device?.bound===true}];
  });
}
const noticeKey=(s,n)=>JSON.stringify([identity(s),n.id,n.taskId,n.accountId,n.category,n.verificationId]);
const verificationStates={waiting_user:'完成验证后即可继续读取。',checking:'正在检查验证状态…',verifying:'正在检查验证状态…',resuming:'验证成功，正在继续读取…',resumed:'验证成功。',cancelled:'本次验证等待已停止，原断点保留；完成平台验证后可再次核对。'};
const verificationErrors={
  VERIFICATION_IDENTITY_MISMATCH:'网页已登录，但登录身份与原任务绑定的账号不一致；请切回原账号，原断点保留。',
  VERIFICATION_DUPLICATE_IDENTITY:'网页已登录，但此身份已有另一条账号记录；请联系管理员核对重复记录，原断点保留。',
  VERIFICATION_CLOUD_CLAIM_FAILED:'网页登录已通过，企业账号身份登记尚未确认；请联系管理员核对授权，原断点保留。',
  VERIFICATION_COMMIT_FAILED:'网页登录已通过，但账号会话尚未安全保存；原任务与断点保留，请联系管理员核对。',
  VERIFICATION_CHECK_TIMEOUT:'账号核对超时，结果尚未确认；原断点保留，请刷新任务状态后再核对。',
  VERIFICATION_CHECK_FAILED:'网页登录核对尚未完成，原任务与断点保留；请刷新任务状态，仍未恢复时联系管理员。',
  VERIFICATION_NOT_FINISHED:'当前网页账号或验证状态尚未核实，请确认使用原采集账号并完成平台验证；原断点保留。',
  VERIFICATION_RECEIPT_REQUIRED:'原失败页尚未确认，暂不恢复；请保持原账号页面打开后再次核对。',
  VERIFICATION_WINDOW_OPENING:'验证窗口正在打开，请保持原窗口打开后再次核对。',
  VERIFICATION_WINDOW_REQUIRED:'请先显示原账号验证窗口，完成本人验证后再次核对。',
  VERIFICATION_WINDOW_INVALID:'原验证窗口尚未核实，请显示原账号验证窗口后再次核对。',
  VERIFICATION_WINDOW_FAILED:'原验证窗口未能打开，请检查工作连接后重试。',
  VERIFICATION_SCOPE_CHANGED:'原任务或原账号已变化，请刷新采集状态后核对；原断点保留。',
  TASK_SCOPE_CHANGED:'原任务或原账号已变化，请刷新采集状态后核对；原断点保留。',
  VERIFICATION_CANCELLED:'本次核对已停止，原任务与断点保留。',
  ACCOUNT_BUSY:'原账号还有操作正在进行，请待其结束后再次核对。',
  DEVICE_NOT_READY:'工作连接尚未就绪，请恢复工作连接后再次核对。',
  DEVICE_LEASE_UNCONFIRMED:'工作连接尚未核实，请恢复工作连接后再次核对。',
  AUTH_REQUIRED:'工作台登录已失效，请重新登录后核对原任务。',
  ACCOUNT_FORBIDDEN:'当前员工无权核对此账号，请联系管理员检查授权。',
  RESULT_UNCONFIRMED:'上次操作回执尚未确认，请先刷新采集状态核对；不会重复提交。',
  timeout:'连接超时，尚未取得核对结果；原断点保留，请刷新状态后再核对。',
  connection_failed:'暂时无法连接工作台，请检查连接后再次核对。'
};
const verificationText=(table,key)=>Object.hasOwn(table,key)?table[key]:'';
const verificationStateMessage=(value,category)=>value==='waiting_user'&&category==='authentication_required'?'原账号仍需重新登录，完成后请再次核对。':verificationText(verificationStates,value);
const verificationFailure=error=>verificationText(verificationErrors,error?.code)||'本次核对尚未完成，原任务与断点保留；请刷新状态后再次核对。';
function verificationResult(job,p){
  if(p.acquisition.status==='running')return '验证已核对，原任务已恢复，请查看采集进度。';
  if(['queued','resuming'].includes(p.acquisition.status))return '验证已核对，正在恢复原任务，请查看采集进度。';
  return verificationStateMessage(job?.state,p.acquisition.platformError?.category)||verificationStateMessage(p.acquisition.verification?.state,p.acquisition.platformError?.category)
    ||(p.acquisition.platformError?.category==='authentication_required'?'原账号仍需重新登录，完成后请再次核对。':p.acquisition.platformError?.category==='verification_required'?'当前读取页仍需平台验证，完成后请再次核对。':'本次核对尚未完成，原任务与断点保留；请刷新状态后再次核对。');
}
export function createVerificationActions({state,open,resume,changed,blocked=()=>false,notify=()=>{}}){
  let pending=false;
  return async function act(kind,n){
    if(!['open','resume'].includes(kind)||pending||state.busy)return false;
    const key=noticeKey(state,n),current=()=>platformNotices(state).some(v=>noticeKey(state,v)===key);
    if(!current()||n.id!=='xiaohongshu'||!n.accountId)return false;
    if(blocked()){state.verificationAction={key,pending:false,kind,message:verificationErrors.RESULT_UNCONFIRMED};changed();return false;}
    if(kind==='open'){state.freshVerificationKeys||={};state.freshVerificationKeys[key]=true;state.verificationCollapsedKeys||={};state.verificationCollapsedKeys[key]=false;}
    pending=true;state.verificationAction={key,pending:true,kind,message:kind==='open'?'正在打开原账号网页…':'正在核对网页验证结果…'};changed();
    try{
      const response=await (kind==='open'?open:resume)(n.taskId);
      if(!current())return;
      const job=response?.job,p=response?.platform;
      if(job?.taskId!==n.taskId||job?.accountId!==n.accountId||p?.actor?.username!==state.user||p?.actor?.storeId!==state.storeId
          ||p.acquisition?.taskId!==n.taskId||p.acquisition.taskScope?.accountId!==n.accountId||p.acquisition.taskScope?.platform!==n.id)
        throw Object.assign(new Error('verification scope changed'),{code:'VERIFICATION_SCOPE_CHANGED'});
      if(p.acquisition?.taskId===n.taskId&&(!p.acquisition.taskScope?.platform||p.acquisition.taskScope.platform===n.id)){
        if(n.id===(state.activePlatform||'xiaohongshu'))state.platform=p;
        else if(state.platformWorkspaces?.[n.id])state.platformWorkspaces[n.id].platform=p;
      }
      if(kind==='open'){state.verificationCollapsedKeys||={};state.verificationCollapsedKeys[key]=job?.windowOpen===true;state.freshVerificationKeys||={};state.freshVerificationKeys[key]=true;}
      const message=kind==='open'?(job?.windowOpen===true?'原账号网页已打开；完成当前页验证后，点击“我已完成验证”。':verificationText(verificationErrors,job?.errorCode)||'正在打开原账号网页；若未出现，请查看本次打开状态。'):verificationResult(job,p);
      const outcome=kind==='resume'&&['running','queued','resuming'].includes(p.acquisition.status)?'resumed':kind==='open'?'opened':'waiting';
      state.verificationAction={key,pending:false,kind,message,outcome};notify(message);
    }catch(error){if(current())state.verificationAction={key,pending:false,kind,message:verificationFailure(error)};if(kind==='open'&&['ACCOUNT_BUSY','VERIFICATION_WINDOW_OPENING','DEVICE_NOT_READY','DEVICE_LEASE_UNCONFIRMED'].includes(error.code))return false;}
    finally{pending=false;if(state.verificationAction?.key===key)state.verificationAction.pending=false;changed();}
    return true;
  };
}
export function createAutomaticVerification({state,act,blocked=()=>false}){
  let scope='',seen=new Set(),observed=new Set();
  return {sync(){
    const current=identity(state);if(current!==scope){scope=current;seen=new Set();observed=new Set();}
    const notices=platformNotices(state);
    for(const [id] of snapshots(state)){if(!observed.has(id)){for(const n of notices.filter(n=>n.id===id))seen.add(noticeKey(state,n));observed.add(id);}}
    if(state.page!=='acquire'||state.busy||blocked())return;
    const targets=notices.filter(n=>n.id==='xiaohongshu'&&n.accountId&&n.deviceReady
      &&n.verificationId&&['verification_required','authentication_required'].includes(n.category));
    for(const n of targets){
      const key=noticeKey(state,n);if(seen.has(key))continue;seen.add(key);state.freshVerificationKeys||={};state.freshVerificationKeys[key]=true;
      Promise.resolve().then(async()=>{if(identity(state)===current&&await act('open',n)===false)seen.delete(key);}).catch(()=>{});
    }
  }};
}
export function updatePlatformNotice(s,host,onAccount,onVerify){
  if(!host)return;
  const notices=s.page==='acquire'?platformNotices(s).filter(n=>n.id===(s.activePlatform||'xiaohongshu')&&(!['verification_required','authentication_required'].includes(n.category)||s.freshVerificationKeys?.[noticeKey(s,n)]||['waiting_user','verifying','resuming'].includes(n.verification?.state))):[],collapsed=n=>Boolean(s.verificationCollapsedKeys?.[noticeKey(s,n)]);
  const key=JSON.stringify([identity(s),s.page,notices,s.verificationAction,s.verificationCollapsedKeys,s.busy]);
  if(host.dataset.noticeKey===key)return;
  host.dataset.noticeKey=key;host.hidden=!notices.length;
  host.classList.toggle('is-collapsed',Boolean(notices.length&&notices.every(collapsed)));
  host.innerHTML=notices.map((n,index)=>{
    const action=s.verificationAction?.key===noticeKey(s,n)?s.verificationAction:null;
    const canVerify=onVerify&&n.id==='xiaohongshu'&&n.accountId&&['verification_required','platform_rejected','authentication_required'].includes(n.category);
    const disabled=action?.pending||s.busy?'disabled':'';
    const compact=collapsed(n),message=action?.message||verificationStateMessage(n.verification.state,n.category);
    return `<section class="platform-alert ${compact?'is-compact':''}" role="status"><div class="platform-alert-heading"><strong>${esc(n.title)}</strong><button type="button" data-notice-toggle="${index}" aria-expanded="${!compact}">${compact?'展开':'收起'}</button></div>${compact?'':`<p>${esc(n.body)} 已读取的数据和断点已保留。</p>`}${message?`<p class="platform-alert-feedback" role="status">${esc(message)}</p>`:''}<div class="platform-alert-actions">${canVerify?`<button type="button" data-verify-action="open" data-notice-index="${index}" ${disabled}>${action?.pending&&action.kind==='open'?'正在打开…':'显示验证窗口'}</button><button type="button" data-verify-action="resume" data-notice-index="${index}" ${disabled}>${action?.pending&&action.kind==='resume'?'正在核对…':'我已完成验证'}</button>`:`<button type="button" data-platform-notice="${n.id}">查看账号</button>`}</div></section>`;
  }).join('');
  host.querySelectorAll('[data-platform-notice]').forEach(button=>button.addEventListener('click',()=>onAccount(button.dataset.platformNotice)));
  host.querySelectorAll('[data-verify-action]').forEach(button=>button.addEventListener('click',()=>onVerify(button.dataset.verifyAction,notices[Number(button.dataset.noticeIndex)])));
  host.querySelectorAll('[data-notice-toggle]').forEach(button=>button.addEventListener('click',()=>{
    const n=notices[Number(button.dataset.noticeToggle)];if(!n)return;
    s.verificationCollapsedKeys||={};const k=noticeKey(s,n);
    s.verificationCollapsedKeys[k]=!s.verificationCollapsedKeys[k];host.dataset.noticeKey='';updatePlatformNotice(s,host,onAccount,onVerify);
  }));
}
export function createCollectionMonitor({state,read,changed,schedule=setTimeout,cancel=clearTimeout}){
  let timer=null,timerScope=null,flight=false;
  const targets=()=>snapshots(state).filter(([id,p])=>(running.has(p.acquisition.status)
    ||['verification_required','authentication_required'].includes(p.acquisition.platformError?.category))
    &&(id!==(state.activePlatform||'xiaohongshu')||!['acquire','accounts'].includes(state.page)));
  function sync(){
    const wanted=targets().length>0,scope=identity(state);
    if(timer!==null&&(!wanted||timerScope!==scope)){
      cancel(timer);timer=null;timerScope=null;
    }
    if(!flight&&wanted&&timer===null){
      timerScope=scope;timer=schedule(tick,5000);
    }
  }
  async function tick(){
    timer=null;timerScope=null;if(flight)return;flight=true;
    const scope=identity(state);
    try{
      for(const [id,prior] of targets()){
        if(scope!==identity(state)||state.connection!=='connected'||!state.session)break;
        try{
          const response=await read({platform:id});
          const p=response?.platform;
          if(scope!==identity(state)||state.connection!=='connected'||!state.session)break;
          const current=snapshots(state).find(([platform])=>platform===id)?.[1];
          if(!p||p.actor?.username!==state.user||p.actor?.storeId!==state.storeId
              ||p.acquisition?.taskId!==prior.acquisition.taskId||current?.acquisition?.taskId!==prior.acquisition.taskId
              ||(p.acquisition.taskScope?.platform&&p.acquisition.taskScope.platform!==id))continue;
          if(id===(state.activePlatform||'xiaohongshu'))state.platform=p;
          else if(state.platformWorkspaces?.[id])state.platformWorkspaces[id].platform=p;
          changed();
        }catch{ /* Preserve the last known task; foreground reads show service errors. */ }
      }
    }finally{flight=false;sync();}
  }
  return {sync};
}
