import {unifiedIntentMarkup,currentQualificationContract} from './unified-intent-view.mjs';
// Pure read-only rendering. Receives the already-authorized projection, never raw data.
import {approvedRulesSection} from './approved-rules-view.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const list=a=>'<ul>'+a.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul>';
const table=(head,rows)=>'<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;text-align:left"><thead><tr>'+head.map(x=>'<th style="padding:10px">'+esc(x)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(v=>'<td style="padding:10px;vertical-align:top">'+esc(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';

export function validateLatestBusinessReview(doc){
  if(doc?.activePolicy?.approved===true){
    const p=doc.activePolicy;
    const validScope=(p.allStores===true&&doc.annualOnly===true)
      ||(p.allStores===false&&doc.annualOnly===false&&doc.scopedStoreCount===1
        &&Array.isArray(doc.stores)&&doc.stores.length===1
        &&doc.selectedStoreName===doc.stores[0].name);
    if(doc.fiveLevelsApproved!==true||!validScope||typeof p.providerVerified!=='boolean'
        ||typeof p.statusText!=='string'||!Array.isArray(p.levels)||p.levels.length!==5
        ||!Array.isArray(p.exclusions)||p.exclusions.length!==15||!Array.isArray(p.annualGuide)
        ||!Array.isArray(p.checks))throw Error('已确认规则没有完整读到，请重新读取。');
    return doc;
  }
  if(!doc||doc.currentFiveLevelsVerified!==true||doc.fiveLevelsLiveVerified!==true
      ||doc.fiveLevelsApproved!==false||doc.proposalsPublished!==false
      ||doc.annualOnlyAppliedToProvider!==false||doc.snapshotOnly!==true
      ||typeof doc.verifiedSnapshot!=='string'||!doc.verifiedSnapshot
      ||!Array.isArray(doc.verifiedFacts)||!Array.isArray(doc.comparisonRows)
      ||!Array.isArray(doc.commentSignals)||!doc.commentSignals.length
      ||!Array.isArray(doc.originalRequirements)||!doc.originalRequirements.length
      ||!Array.isArray(doc.replyCapabilities))
    throw Error('最新核查记录尚未完整读到，未采用较早说明。');
  return doc;
}

const facts=doc=>'<details open><summary>最近核实的实际情况</summary><p>'+esc(doc.verifiedSnapshot)+'</p><p>'+esc(doc.reviewStatusNote)+'</p>'+table(['核对什么','已核实的情况'],doc.verifiedFacts.map(x=>[x.item,x.text]))+'</details>';

export function latestBusinessSection(doc,section,storeName){
  if(section==='checklist'||section==='intent'&&!currentQualificationContract(doc))return unifiedIntentMarkup(doc);
  validateLatestBusinessReview(doc);
  const approved=approvedRulesSection(doc,section,storeName);
  if(approved!==null)return approved;
  if(section==='words'){
    const store=doc.stores.find(s=>s.name===storeName)||doc.stores[0];
    return facts(doc)+'<h3>搜索词分类</h3>'+table(['分类','说明','怎样使用'],doc.categoryGuide.map(x=>[x.name,x.meaning,x.rule]))
      +'<h3>'+esc(store.name)+'</h3><p>原有 '+store.originalCount+' 条，后补 '+store.addedCount+' 条，合计 '+store.totalCount+' 条；资料待核 '+store.pendingTermCount+' 条。</p>'
      +'<p>'+esc(store.taskUsageNote)+'</p><p>'+esc(doc.sourceHoldNotice)+'</p>'
      +doc.groups.map(group=>'<details'+(group==='租房强关联'?' open':'')+'><summary>'+esc(group)+' '+store.counts[group]+'条</summary>'
        +['原有资料','后来补充'].map(origin=>{
          const words=store.terms.filter(t=>t.group===group&&t.origin===origin);
          return words.length?'<h4>'+esc(origin)+'</h4><div class="wf-words">'+words.map(t=>'<span>'+esc(t.word)+'<small style="display:block;color:'+(t.pendingSource?'#89612b':'#63766b')+'">'+esc(t.statusText)+'</small></span>').join('')+'</div>':'';
        }).join('')+'</details>').join('');
  }
  if(section==='exclude')return '<h3>什么时候排除 什么时候保留</h3><p>结合整句话判断，不把这些表达当成见词就删的排除词；本次详细写法尚未启用。</p>'
    +doc.exclusions.map(x=>'<details><summary>'+esc(x.title)+'</summary><p><strong>排除或停止联系：</strong>'+esc(x.exclude)+'</p><p><strong>保留：</strong>'+esc(x.keep)+'</p><p>'+esc(x.example)+'</p><p><strong>现在的说明：</strong>'+esc(x.current)+'</p><p>'+esc(x.statusNote)+'</p></details>').join('')
    +'<h3>只做年租怎样筛</h3>'+table(['客户表达','处理办法'],doc.annualGuide.map(x=>[x.situation,x.handle]));
  if(section==='intent')return unifiedIntentMarkup(doc)+'<p>旧资料中的等级提议不作为当前门店最终意向；请结合上述同源规则查看客户当前投影。</p>';
  if(section==='meeting')return '<h3>尚未明确的事项</h3>'+list(doc.unknown)+'<h3>需要你确定的内容</h3>'
    +table(['问题','为什么要确认','建议或待定处'],doc.meetingQuestions.map(x=>[x.question,x.suggestion,x.decide]))
    +'<details><summary>现有回复口吻的真实能力</summary>'+table(['项目','核对情况'],doc.replyCapabilities.map(x=>[x.item,x.text]))+'</details>'
    +'<h3>原资料其他具体要求</h3><p>以下只作原稿对照，不代表已经批准或实现；旧分法不能当成已生效的新五级。</p>'
    +doc.originalRequirements.map(block=>'<details><summary>'+esc(block.title)+'</summary>'+table(['原要求','原资料意思','这次怎样处理'],block.rows.map(x=>[x.title,x.text,x.handling]))+'</details>').join('')
    +'<p>'+esc(doc.meetingPptNotice)+'</p>';
  return null;
}
