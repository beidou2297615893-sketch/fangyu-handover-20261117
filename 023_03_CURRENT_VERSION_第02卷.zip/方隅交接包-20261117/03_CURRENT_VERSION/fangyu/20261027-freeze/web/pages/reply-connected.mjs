import {replyScopeBlocked} from './reply-scope-guard.mjs';
import {renderContext,renderAI,bindAI} from './reply-ai.mjs';
import {customerShortNeed} from './customers-data.mjs';
import {isCustomerReadUnavailable} from '../customer-read-cache.mjs';
import {readablePostTime} from '../daily-ui.mjs';
import {evidenceSummary,assessmentLabel,workflowScope,renderIntentState,intentChoices,analysisChoices,intentFilterControl,analysisFilterControl} from './workflow-summary.mjs';
import {customerAvatar,postCover,bindCustomerAvatars,warmCustomerMedia} from '../avatar.mjs';
// Connected reply workspace. Preview examples remain confined to reply.mjs.
import {renderDelivery,bindDelivery,prepareReviewed} from './reply-delivery.mjs';
import {personaChoices} from './management-tone.mjs';
import {bindBatch,renderBatch} from './reply-batch.mjs';
import {senderName} from './reply-account.mjs';
import {bindReplyStream} from './reply-list-stream.mjs';
import {renderWordingHints} from './reply-wording.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=name=>`<img class="rp-icon" src="/assets/${name}" alt="">`;
const actor=s=>`${s.authEpoch||0}|${s.user}|${s.storeId||''}|${s.activePlatform||'xiaohongshu'}`;
const matches=(s,value)=>value?.actor?.username===s.user&&value?.actor?.storeId===s.storeId;
const active=s=>s.connection==='connected'&&Boolean(s.session)&&s.page==='reply';
const cachedReadNotice='已显示本地记录，稍后可刷新更新';
function readFailure(state,ctx,v,error,snapshot=false){
  const fallback=(snapshot||Boolean(v.items.length||v.detail))&&isCustomerReadUnavailable(error);
  v.readUnavailable=true;if(v.detail)v.detailSnapshot=true;
  v.error=fallback?cachedReadNotice:error.message;
  if(!fallback&&(active(state)||error.code==='AUTH_REQUIRED'))ctx.replyError(error);
}
const acquisitionStamp=s=>JSON.stringify([s.platform?.acquisition?.taskId,s.platform?.acquisition?.counts?.added,s.platform?.acquisition?.counts?.analyzed]);
const statusLabels={draft:'草稿已保存 · 未发送',approved:'已核对 · 未发送',sent:'已有发送记录',unknown:'发送结果待核对',copied:'已复制 · 未确认发送',superseded:'历史草稿'};
function model(state){
  if(!state.replyLive||state.replyLive.actor!==actor(state))state.replyLive={actor:actor(state),status:'idle',items:[],stats:{},tab:'pending',groupBy:'post',query:'',page:1,generation:0,selectedId:'',leadId:'',text:'',accountId:'',busy:false,pending:null,error:'',detail:null,collapsedGroups:[],intent:'all',analysisStatus:'all',review:'all',checkedIds:[]};
  return state.replyLive;
}
const selected=v=>v.detail?.comments?.find(row=>row.id===v.leadId);
function commentStamp(value){const d=new Date(value);if(!value||Number.isNaN(d.getTime()))return '';const t=d.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}),today=new Date(),yesterday=new Date(today.getFullYear(),today.getMonth(),today.getDate()-1);return (d.toDateString()===yesterday.toDateString()?'昨天 ':'')+t;}
function postStamp(value){const d=new Date(value);return !value||Number.isNaN(d.getTime())?'发布时间待核实':`${d.getMonth()+1}月${d.getDate()}日 ${d.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'})} 发布`;}
function customerRow(p,v){return `<div class="rp-selectable-comment">${v.uiView==='batch'?`<input type="checkbox" data-live-check-customer="${esc(p.id)}" aria-label="选择${esc(p.name)}" ${(v.checkedIds||[]).includes(p.id)?'checked':''}>`:''}<button type="button" class="rp-comment ${v.selectedId===p.id?'is-selected':''}" data-live-customer="${esc(p.id)}" aria-pressed="${v.selectedId===p.id}">${customerAvatar(p,'rp-avatar')}<span class="rp-comment-copy"><strong>${esc(p.name)}</strong><span>${esc(p.quote||customerShortNeed(p)||'需求待了解')}</span></span><span class="rp-comment-meta">${p.publishedAt?`<time datetime="${esc(p.publishedAt)}" title="${esc(readablePostTime(p.publishedAt))}">${esc(commentStamp(p.publishedAt))}</time>`:''}${renderIntentState(p,'rp')}</span><span class="rp-contact-status ${p.replied?'is-replied':''}">${esc(p.contactLabel)}</span>${icon('tabler-chevron-down.svg')}</button></div>`;}
function groups(v){
  if(v.groupBy!=='post')return `<section class="rp-post rp-flat-post" style="min-height:max-content;flex-shrink:0"><div class="rp-flat-title">${v.groupBy==='intent'?'按意向查看':'按时间查看'}<span>已载入 ${v.items.length} 位客户</span></div>${v.items.map(p=>customerRow(p,v)).join('')}</section>`;
  const posts=new Map();
  for(const p of v.items){const key=JSON.stringify([p.platform,p.postUrl||p.postTitle||p.id]);if(!posts.has(key))posts.set(key,[]);posts.get(key).push(p);}
  return [...posts].map(([key,items])=>{const p=items[0],closed=v.collapsedGroups.includes(key);return `<section class="rp-post ${closed?'is-collapsed':''}" style="min-height:max-content;flex-shrink:0"><div class="rp-post-heading" data-live-post-toggle="${esc(key)}" role="button" tabindex="0" aria-label="${closed?'展开':'收起'}帖子客户" aria-expanded="${!closed}">${postCover(p,'rp-post-thumbnail','object-fit:cover;flex-shrink:0')}<div class="rp-post-name" style="min-width:0;flex:1"><div><strong style="overflow:hidden;text-overflow:ellipsis" title="${esc(p.postTitle)}">${esc(p.postTitle||'帖子标题未提供')}</strong></div><span class="rp-post-description">${esc(p.postDescription||p.postSummary||'房源说明待补充')}</span><span class="rp-post-time">${esc(postStamp(p.postPublishedAt))} · ${items.length}条咨询${items.some(p=>p._outsidePage)?' · 含指定客户':''}</span></div><button type="button" class="rp-icon-button rp-collapse ${closed?'is-closed':''}" data-live-collapse="${esc(key)}" aria-label="${closed?'展开':'收起'}帖子客户" aria-expanded="${!closed}">${icon('tabler-chevron-down.svg')}</button></div>${closed?'':`<div class="rp-comment-list">${items.map(p=>customerRow(p,v)).join('')}</div>`}</section>`;}).join('');
}
function choose(v,id){const row=v.detail?.comments?.find(row=>row.id===id);v.leadId=row?.id||'';v.text=row?.draft?.text||'';v.accountId=row?.draft?.review_account_id||row?.accounts?.[0]?.id||'';v.dirty=false;v.evidenceOpen=false;}
function accept(state,v,result,{preserveText=false}={}){
  const previous=selected(v),edited=preserveText&&v.dirty?{text:v.text,leadId:v.leadId,accountId:v.accountId,sourceDigest:previous?.sourceDigest,draftId:previous?.draft?.id||'',version:previous?.draft?.version||0}:null;
  const senderSelection=previous?.accounts?.length?{leadId:previous.id,accountId:v.accountId}:null;
  if(!matches(state,result)||result.customerId!==v.selectedId)throw new Error('员工、门店或客户范围已变化，请重新载入。');
  if(result.item?.platform&&result.item.platform!==(state.activePlatform||'xiaohongshu'))throw new Error('客户平台已变化，请重新读取。');
  if(edited){const fresh=result.comments?.find(row=>row.id===edited.leadId);if(!fresh||fresh.sourceDigest!==edited.sourceDigest||(fresh.draft?.id||'')!==edited.draftId||(fresh.draft?.version||0)!==edited.version){v.detailSnapshot=true;v.readUnavailable=true;v.error='原评论或草稿已变化，已保留本地文字。请重新选择本条核对。';return false;}}
  v.detail=result;v.detailSnapshot=false;v.readUnavailable=false;
  const hint=state.selectedCustomerEvidence,linked=hint?.actor===actor(state)&&hint.customerId===result.customerId?hint.leadId:'';
  const preferred=linked||v.leadId;choose(v,result.comments?.some(row=>row.id===preferred)?preferred:result.comments?.[0]?.id);
  if(senderSelection&&selected(v)?.id===senderSelection.leadId)v.accountId=selected(v).accounts?.some(a=>a.id===senderSelection.accountId)?senderSelection.accountId:'';
  if(edited){v.leadId=edited.leadId;v.text=edited.text;v.dirty=v.text!==(selected(v)?.draft?.text||'');v.accountId=selected(v)?.accounts?.some(a=>a.id===edited.accountId)?edited.accountId:'';}
  if(linked)delete state.selectedCustomerEvidence;
  warmCustomerMedia([result.item],workflowScope(state));
  const pending=result.comments?.find(row=>row.pendingRequestId);
  if(pending)v.pending={customerId:result.customerId,leadId:pending.id,requestId:pending.pendingRequestId};
}
function showReplySnapshot(state,ctx,v,id){
  const snapshot=ctx.replyPeek?.({storeId:state.storeId,customerId:id})?.replyWorkspace;
  if(!matches(state,snapshot)||snapshot.customerId!==id||v.dirty||v.pending)return false;
  v.detail=snapshot;v.detailSnapshot=true;
  v.leadId=snapshot.comments?.some(row=>row.id===v.leadId)?v.leadId:snapshot.comments?.[0]?.id||'';
  v.text='';v.accountId='';return true;
}
function replyScopeControls(state,v,row){
  const stores=state.stores||[],accounts=row?.accounts||[];
  return `<div class="rp-scope-controls"><label class="rp-scope-store">${icon('tabler-upgrade-calendar.svg')}<span data-ref-store-label aria-label="当前门店">${esc(stores.find(s=>s.id===state.storeId)?.name||state.store||'门店待核对')}</span></label><label class="rp-scope-platform">${icon(state.activePlatform==='douyin'?'brand-douyin.svg':'brand-xiaohongshu.svg')}<select data-ref-platform aria-label="平台" ${state.busy?'disabled':''}><option value="xiaohongshu" ${state.activePlatform!=='douyin'?'selected':''}>小红书</option><option value="douyin" ${state.activePlatform==='douyin'?'selected':''}>抖音</option></select></label><label class="rp-scope-account">${icon('approved-icon-user-round.svg')}<select data-ref-reply-account aria-label="回复账号" ${!row||v.detailSnapshot||v.detailLoading||v.readUnavailable||v.busy||v.batchBusy||v.pending||v.batchPending?'disabled':''}><option value="">请选择账号</option>${accounts.map(a=>`<option value="${esc(a.id)}" ${a.id===v.accountId?'selected':''}>${esc(senderName(a))}</option>`).join('')}</select></label></div>`;
}
export function renderConnected(state){
  if(!state.storeId)return '<div class="reply-page" role="status">请先选择门店。</div>';
  const v=model(state),row=selected(v),person=v.detail?.item,view=v.uiView||'manual',deliveryPending=Boolean(state.replyDelivery?.busy||state.replyDelivery?.attempt);
  const known=Number.isSafeInteger(v.stats.total)&&Number.isSafeInteger(v.stats.replied);
  const counts={pending:known?Math.max(0,v.stats.total-v.stats.replied):'—',replied:known?v.stats.replied:'—',all:known?v.stats.total:'—'};
  const toolbar=`<div class="rp-toolbar"><button type="button" class="rp-primary" data-live-mode="${view==='ai'?'manual':'ai'}">${view==='ai'?'普通回复':'AI 回复草稿'}</button><div class="rp-tabs" role="tablist" aria-label="回复状态">${[['pending',view==='ai'?'待处理':'未回复'],['replied','已回复'],['all','全部']].map(([id,label])=>`<button type="button" role="tab" aria-selected="${v.tab===id}" class="rp-tab ${v.tab===id?'is-active':''}" data-live-tab="${id}">${label}${id==='pending'?`<span>${counts[id]}</span>`:''}</button>`).join('')}</div><label class="rp-search">${icon('fy-icon-07-search.png')}<input id="reply-search" type="search" data-live-search value="${esc(v.query)}" maxlength="100" placeholder="搜索客户昵称或内容" aria-label="搜索评论或用户名"></label><details class="rp-reference-more"><summary>${icon('reference-icon-ellipsis.svg')}更多 ${icon('tabler-chevron-down.svg')}</summary><div><button type="button" data-live-mode="batch">批量回复</button><label>排列方式<select data-live-group aria-label="排列方式">${[['post','按帖子'],['intent','按意向'],['time','按时间']].map(([id,label])=>`<option value="${id}" ${v.groupBy===id?'selected':''}>${label}</option>`).join('')}</select></label>${intentFilterControl('live',v.intent||'all')}${analysisFilterControl('live',v.analysisStatus||'all')}<button type="button" data-live-reload ${v.busy||v.refreshing?'disabled':''}>${v.refreshing?'正在更新…':'刷新列表'}</button></div></details></div>`;
  const preview=v.items.find(p=>p.id===v.selectedId);
  let editor=`<div class="rp-empty"><strong>${v.detailLoading?'正在读取评论与草稿':'选择一位客户'}</strong>${preview?.sourceNotice?`<p class="rp-loading-note">${esc(preview.sourceNotice)}</p>`:''}</div>`;
  if(row&&person&&!v.editorClosed){
    const editLocked=v.busy||v.batchBusy||Boolean(v.pending)||Boolean(v.batchPending),locked=v.detailSnapshot||v.detailLoading||v.readUnavailable||editLocked;
    const reasons=[...new Set([person.analysisReason,...(person.evidence||[])].filter(x=>typeof x==='string'&&x.trim()))].slice(0,3);
    editor=`<header class="rp-reference-person">${customerAvatar(person,'rp-detail-avatar')}<div><strong>${esc(person.name)}</strong><p>${esc(customerShortNeed(person)||'需求待了解')}</p></div><details class="rp-person-menu"><summary aria-label="客户更多操作">${icon('reference-icon-ellipsis.svg')}</summary><div><button type="button" data-live-evidence>分析原因</button><button type="button" data-live-copy>复制回复</button></div></details><button type="button" class="rp-close-editor" data-live-close aria-label="关闭客户详情">${icon('tabler-x.svg')}</button></header>
      <section class="rp-reference-original"><div class="rp-reference-label"><strong>客户原话</strong><details class="rp-reference-context" ${v.evidenceOpen?'open':''}><summary>上下文</summary><div>${v.detail.comments.length>1?`<label>原评论<select data-live-comment ${locked?'disabled':''}>${v.detail.comments.map((c,i)=>`<option value="${esc(c.id)}" ${c.id===v.leadId?'selected':''}>${i+1}. ${esc(c.text.slice(0,48))}</option>`).join('')}</select></label>`:''}<p>原评论时间：${esc(row.publishedAt?readablePostTime(row.publishedAt):'原评论时间未记录')}</p>${row.sourceNotice?`<p class="rp-loading-note">${esc(row.sourceNotice)}</p>`:''}${renderContext(row.conversation)}${renderWordingHints(row,v)}${!deliveryPending?renderDelivery(state,v):''}<button type="button" class="rp-text-link" data-live-source>打开原帖</button><div class="rp-evidence" id="reply-live-evidence" ${v.evidenceOpen?'':'hidden'}>${reasons.map(text=>`<span>${esc(text)}</span>`).join('')||'<span>暂无分析原因。</span>'}${v.recoveryText?`<blockquote>${esc(v.recoveryText)}</blockquote>`:''}</div></div></details>${row.publishedAt?`<time datetime="${esc(row.publishedAt)}" title="${esc(readablePostTime(row.publishedAt))}">${esc(new Date(row.publishedAt).toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}))}</time>`:''}</div><p>${esc(row.text)}</p>${row.text.length>150?'<button type="button" class="rp-text-link" data-live-full-comment>查看完整原评论</button>':''}</section>
      <section class="rp-reference-compose"><div class="rp-reference-label"><strong>回复内容</strong><button type="button" data-live-tone ${locked?'disabled':''}>${icon('fy-icon-28-file.png')}话术</button></div><div class="rp-composer"><textarea id="connected-reply-draft" data-live-draft aria-label="回复草稿" maxlength="1000" ${editLocked?'disabled':''} placeholder="请输入回复内容…">${esc(v.text)}</textarea><span class="rp-char-count"><span data-live-count>${v.text.length}</span>/1000</span></div></section>
      <label class="rp-reference-sender"><span>发送账号</span><div>${icon('approved-icon-user-round.svg')}<select data-live-account aria-label="发送账号" ${locked?'disabled':''}><option value="">请选择本人账号</option>${row.accounts.map(a=>`<option value="${esc(a.id)}" ${a.id===v.accountId?'selected':''}>${esc(senderName(a))}</option>`).join('')}</select></div></label>
      <div class="rp-editor-actions"><button type="button" class="rp-secondary" data-live-save ${locked||!row.canSave||!v.text.trim()?'disabled':''}>保存草稿</button><button type="button" class="rp-primary" data-live-review ${locked||!row.canSave||!v.text.trim()?'disabled':''}>${icon('fy-icon-23-send.png')}准备发送</button></div>`;
  }
  const status=v.error||v.pending||v.detailSnapshot||deliveryPending?`<div class="rp-reference-status" role="status">${v.detailSnapshot&&!v.error?'<span>正在核对最新草稿与回复条件。</span>':''}${v.error?`<span role="${v.error===cachedReadNotice?'status':'alert'}">${esc(v.error)}</span>`:''}${v.pending?' <button type="button" class="rp-text-link" data-live-check>核对上次操作</button>':''}${deliveryPending?`<span>${state.replyDelivery?.attempt?'上次发送结果待核对。':'正在处理原发送操作。'}</span>${renderDelivery(state,v)}`:''}</div>`:'';
  const list=`<div class="rp-posts"><div data-live-list aria-busy="${Boolean(v.refreshing||v.loadingMore)}">${v.listError?`<p class="rp-loading-note" role="status">${esc(v.listError)}</p>`:''}${groups(v)||`<div class="rp-empty"><strong>${v.status==='loading'?'正在加载客户…':'暂无符合条件的客户'}</strong></div>`}</div><div class="rp-reference-pagination"><span>已显示 ${v.items.length} / ${v.total||0} 位</span><button type="button" class="rp-text-link" data-live-more ${v.page>=(v.pages||0)||v.loadingMore||v.refreshing?'disabled':''}>${v.loadingMore?'正在加载…':v.page<(v.pages||0)?'加载更多':'已显示全部'}</button></div></div>`;
  const content=view==='ai'?`<div class="rp-reference-ai">${renderAI(state,v)}</div>`:view==='batch'?`<div class="rp-reference-batch"><button type="button" data-live-mode="manual">返回普通回复</button>${renderBatch(state,v)}${list}</div>`:`<div class="rp-workspace">${list}<aside class="rp-editor" aria-label="回复编辑">${status}${editor}${!row?renderDelivery(state,v):''}</aside></div>`;
  return `<div class="reply-page rp-connected rp-reference" data-reply-view="${esc(view)}">${view!=='ai'?replyScopeControls(state,v,row):''}${toolbar}${content}</div>`;
}

async function load(state,ctx,v,{customerId}={}){
  const attemptAcquisitionStamp=acquisitionStamp(state);
  v.listReadFailed=false;
  v.page=1;v.loadingMore=false;v.listError='';v.autoFillBudget=3;
  const generation=++v.generation,scope=actor(state),filterKey=JSON.stringify([v.query,v.tab,v.intent||'all',v.analysisStatus||'all','all',v.groupBy,v.page]);
  const readQuery={query:v.query,filter:v.tab,sort:v.groupBy,page:1,pageSize:50,audience:'all',intent:v.intent||'all',analysisStatus:v.analysisStatus||'all',review:'all'};
  const snapshot=ctx.replyCustomersPeek?.(readQuery)?.customers;
  const cached=Boolean(v.items.length)||Boolean(v.loadedAt&&v.loadedFilter===filterKey)||Boolean(matches(state,snapshot));
  if(snapshot&&matches(state,snapshot)&&!v.dirty){Object.assign(v,{items:snapshot.items,total:snapshot.total,stats:snapshot.stats,pages:snapshot.pages});}
  if(!cached){v.checkedIds=[];v.items=[];v.stats={};if(!v.dirty&&!v.pending&&!v.batchBusy&&!v.batchPending){v.detail=null;v.selectedId='';v.leadId='';v.text='';}}
  v.status=cached?'ready':'loading';v.refreshing=true;v.error='';
  const owns=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&generation===v.generation&&scope===actor(state);
  const redraw=()=>{if(owns()&&active(state))ctx.update(()=>{});};redraw();
  try{
    const result=await ctx.replyCustomers(readQuery);
    if(!owns())return;
    if(!matches(state,result.customers))throw new Error('员工或门店已变化，请重新载入。');
    const visibleIds=new Set(result.customers.items.map(row=>row.id));
    v.checkedIds=cached?(v.checkedIds||[]).filter(id=>visibleIds.has(id)):[];
    Object.assign(v,{items:result.customers.items,total:result.customers.total,stats:result.customers.stats,pages:result.customers.pages,page:result.customers.page,status:'ready',loadedAt:Date.now(),loadedFilter:filterKey});
    v.loadedAcquisition=acquisitionStamp(state);
    warmCustomerMedia(v.items,workflowScope(state));
    if(v.pending||v.busy||v.batchBusy||v.batchPending)return;
    const chosen=customerId||v.selectedId,next=v.dirty?v.selectedId:customerId||(v.items.some(row=>row.id===chosen)?chosen:v.items[0]?.id||'');
    if(next!==v.selectedId){v.detail=null;v.leadId='';v.text='';}v.selectedId=next;
    // Publish the list before the independent draft read. A draft error must
    // not fall through to the list-error branch and erase valid customers.
    v.refreshing=false;redraw();
    if(active(state)&&v.selectedId){if(!v.detail)showReplySnapshot(state,ctx,v,v.selectedId);v.detailLoading=true;redraw();const selectedId=v.selectedId;
      try{
        const detail=await ctx.replyRead({storeId:state.storeId,customerId:selectedId});
        if(!owns()||v.pending||v.selectedId!==selectedId)return;accept(state,v,detail.replyWorkspace,{preserveText:true});
        if(customerId&&!v.items.some(row=>row.id===customerId))v.items.unshift({...detail.replyWorkspace.item,_outsidePage:true});
      }catch(error){if(owns())readFailure(state,ctx,v,error,v.detailSnapshot);}
    }
  }catch(error){if(owns()){
    v.listReadFailed=true;
    v.failedAcquisitionStamp=attemptAcquisitionStamp;
    const keep=cached&&isCustomerReadUnavailable(error);v.status=keep?'ready':'error';
    if(!keep){v.checkedIds=[];v.items=[];v.stats={};v.total=0;v.detail=null;v.leadId='';v.text='';v.dirty=false;if(!v.pending)v.selectedId='';}
    readFailure(state,ctx,v,error,keep);
  }}
  finally{if(owns()){v.detailLoading=false;v.refreshing=false;redraw();}}
}
export function preloadConnected(state,ctx){
  if(state.connection!=='connected'||!state.session||!state.storeId)return null;
  const v=model(state);if(v.status!=='idle')return null;return load(state,ctx,v);
}
async function selectCustomer(state,ctx,v,id){
  if(v.selectedId===id&&v.detail&&!v.detailSnapshot&&!v.detailLoading)return;
  const generation=++v.generation,scope=actor(state);v.selectedId=id;v.detail=null;v.leadId='';v.text='';v.dirty=false;v.detailSnapshot=false;v.detailLoading=true;v.error='';showReplySnapshot(state,ctx,v,id);ctx.update(()=>{});
  const owns=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&generation===v.generation&&scope===actor(state);
  try{const result=await ctx.replyRead({storeId:state.storeId,customerId:id});if(owns()&&!v.dirty&&!v.pending)accept(state,v,result.replyWorkspace);}
  catch(error){if(owns())readFailure(state,ctx,v,error,v.detailSnapshot);}
  finally{if(owns()){v.detailLoading=false;if(active(state))ctx.update(()=>{});}}
}
async function mutate(state,ctx,v,review=false){
  const row=selected(v);if(!row||v.detailSnapshot||v.detailLoading||v.readUnavailable||v.busy||v.pending)return false;
  const scope=actor(state),requestId=crypto.randomUUID(),customerId=v.selectedId,leadId=row.id;
  const generation=v.generation;
  const ownsView=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&scope===actor(state)&&v.generation===generation&&v.selectedId===customerId&&v.leadId===leadId;
  const ownsAttempt=()=>ownsView()&&v.pending?.requestId===requestId;
  const payload={storeId:state.storeId,customerId,leadId,sourceDigest:row.sourceDigest,expectedVersion:row.draft?.version||0,expectedReplyId:row.draft?.id||'',requestId,...(review?{accountId:v.accountId,confirmed:true}:{text:v.text})};
  v.busy=true;v.error='';v.pending={customerId,leadId,requestId};ctx.update(()=>{});
  try{
    const result=await (review?ctx.replyReview(payload):ctx.replySave(payload));
    if(!ownsAttempt())return false;
    if(!matches(state,result.replyWorkspace)||result.replyWorkspace?.customerId!==customerId){const error=new Error('草稿保存结果尚未确认，请核对原操作。');error.code='REPLY_RESULT_UNCONFIRMED';throw error;}
    v.pending=null;accept(state,v,result.replyWorkspace);if(active(state))ctx.toast(review?'草稿已逐条核对，尚未发送。':'草稿已保存，尚未发送。');return true;
  }catch(error){if(ownsAttempt()){if(!['RESULT_UNCONFIRMED','REPLY_RESULT_UNCONFIRMED'].includes(error.code))v.pending=null;v.error=error.message;if(active(state)||error.code==='AUTH_REQUIRED')ctx.replyError(error);}return false;}
  finally{if(ownsView()&&(!v.pending||v.pending.requestId===requestId)){v.busy=false;if(active(state))ctx.update(()=>{});}}
}
async function checkPending(state,ctx,v){
  if(v.busy||!v.pending)return;
  const scope=actor(state),generation=v.generation,pending={...v.pending};
  const ownsView=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&scope===actor(state)&&v.generation===generation&&v.selectedId===pending.customerId;
  const ownsAttempt=()=>ownsView()&&v.pending?.requestId===pending.requestId;
  v.busy=true;ctx.update(()=>{});
  try{
    const result=await ctx.replyCheck({storeId:state.storeId,...pending});if(!ownsAttempt())return;
    accept(state,v,result.replyWorkspace);
    if(['accepted','observed','not_found','not_applied','rejected','changed'].includes(result.replyWorkspace.receipt?.state)){
      v.pending=null;v.recoveryText=result.replyWorkspace.receipt?.attemptText||'';
      v.error=result.replyWorkspace.receipt?.state==='changed'?'原评论或草稿版本已变化，旧操作已关闭。保留当前草稿；请逐条重核，旧审核不代表当前来源有效。':'请逐条核对当前后台正文和版本，尚未发送。';
    }else v.error='后台尚未确认原操作，请保留当前记录，不要重复保存。';
  }catch(error){if(ownsAttempt()){v.error=error.message;if(active(state)||error.code==='AUTH_REQUIRED')ctx.replyError(error);}}
  finally{if(ownsView()&&(!v.pending||v.pending.requestId===pending.requestId)){v.busy=false;if(active(state))ctx.update(()=>{});}}
}
let currentScope='';
export function syncConnected(state,ctx){
  if(!active(state)||!state.storeId){currentScope='';return;}
  const v=model(state);
  if(v.listReadFailed&&v.failedAcquisitionStamp===acquisitionStamp(state)&&!state.selectedCustomer)return;
  const changed=v.loadedAcquisition!==acquisitionStamp(state);
  if(currentScope===actor(state)&&v.status!=='idle'&&!changed)return;
  currentScope=actor(state);
  if(v.refreshing||v.status==='loading'||v.status==='scheduled'||v.pending||v.busy||v.batchBusy||v.batchPending)return;
  if(v.status==='ready'&&!changed&&Date.now()-(v.loadedAt||0)<15000){
    if(v.selectedId&&!v.detail&&!v.detailLoading)queueMicrotask(()=>{if(active(state)&&state.replyLive===v)selectCustomer(state,ctx,v,v.selectedId);});
    return;
  }
  v.status=v.loadedAt?'ready':'scheduled';queueMicrotask(()=>{const id=state.selectedCustomer||state.replyDelivery?.customerIds?.[0];delete state.selectedCustomer;if(active(state)&&state.replyLive===v)load(state,ctx,v,{customerId:id});});
}
export function bindConnected(root,ctx){
  bindCustomerAvatars(root);
  const state=ctx.state,v=model(state);
  async function changeView(next){
    if(replyScopeBlocked(state,v)){ctx.toast('请先核对当前操作结果。');return false;}
    const previous=v.uiView||'manual';
    ctx.update(()=>{v.uiView=next;v.ai ||= {};if(next==='ai')v.ai.open=true;});
    if(next==='ai'&&!v.dirty&&!replyScopeBlocked(state,v)&&!v.detailLoading&&v.items.length&&(!v.selectedId||!v.detail)){
      await selectCustomer(state,ctx,v,v.selectedId||v.items[0].id);
    }
    if(previous==='ai'&&next==='manual'&&!v.dirty&&!replyScopeBlocked(state,v)&&v.selectedId){
      const scope=actor(state),customerId=v.selectedId;
      try{const result=await ctx.replyRead({storeId:state.storeId,customerId});if(state.replyLive===v&&scope===actor(state)&&v.selectedId===customerId&&!v.dirty&&!replyScopeBlocked(state,v)){accept(state,v,result.replyWorkspace,{preserveText:true});ctx.update(()=>{});}}catch(error){if(state.replyLive===v){v.error=error.message;ctx.update(()=>{});}}
    }
  }
  root.querySelectorAll('[data-live-mode]').forEach(el=>el.addEventListener('click',()=>changeView(el.dataset.liveMode)));
  const aiPanel=root.querySelector('[data-ai-panel]');
  aiPanel?.addEventListener('toggle',()=>{if(!aiPanel.open&&v.uiView==='ai'){if(replyScopeBlocked(state,v)){aiPanel.open=true;ctx.toast('请先核对当前操作结果。');return;}changeView('manual');}});
  root.querySelector('[data-ref-platform]')?.addEventListener('change',e=>ctx.switchPlatform(e.target.value));
  root.querySelector('[data-ref-reply-account]')?.addEventListener('change',e=>{if(v.busy||v.pending)return;v.accountId=e.target.value;ctx.update(()=>{});});
  root.querySelector('[data-live-close]')?.addEventListener('click',()=>ctx.update(()=>{v.editorClosed=true;}));
  bindReplyStream(root,ctx,v);
  if(v.uiView==='batch')bindBatch(root,ctx,v);bindAI(root,ctx,v);
  for(const [field,choices] of [['intent',intentChoices],['analysisStatus',analysisChoices]]){
    const suffix=field==='intent'?'intent':'analysis';
    root.querySelector(`[data-live-${suffix}]`)?.addEventListener('change',e=>{const value=e.target.value;if(!Object.hasOwn(choices,value))return;discard(()=>{v[field]=value;v.page=1;v.checkedIds=[];load(state,ctx,v);});});
  }
  root.querySelectorAll('[data-live-tone]').forEach(el=>el.addEventListener('click',()=>ctx.openToneTools?.()));
  root.querySelector('[data-live-evidence]')?.addEventListener('click',()=>ctx.update(()=>{v.evidenceOpen=!v.evidenceOpen;}));
  const discard=fn=>{if(v.busy||v.pending||v.batchBusy||v.batchPending){ctx.toast('请先核对当前操作结果。');return;}if(v.dirty)ctx.modal({title:'有未保存修改',html:'<p>切换后将重新读取后台草稿，未保存文字会丢失。</p>',confirmLabel:'放弃修改并继续',onConfirm:()=>{v.dirty=false;return fn();}});else fn();};
  bindDelivery(root,ctx,v,id=>discard(()=>selectCustomer(state,ctx,v,id)));
  root.querySelector('[data-live-reload]')?.addEventListener('click',()=>{if(!v.busy&&!v.pending&&!v.batchBusy&&!v.batchPending)load(state,ctx,v);});
  const togglePost=key=>{v.autoFillBudget=3;v.collapsedGroups=v.collapsedGroups.includes(key)?v.collapsedGroups.filter(k=>k!==key):[...v.collapsedGroups,key];ctx.update(()=>{});};
  root.querySelectorAll('[data-live-collapse]').forEach(el=>el.addEventListener('click',()=>togglePost(el.dataset.liveCollapse)));
  root.querySelectorAll('[data-live-post-toggle]').forEach(el=>{el.addEventListener('click',event=>{if(!event.target.closest('button,a,input'))togglePost(el.dataset.livePostToggle);});el.addEventListener('keydown',event=>{if(event.target===el&&['Enter',' '].includes(event.key)){event.preventDefault();togglePost(el.dataset.livePostToggle);}});});
  root.querySelectorAll('[data-live-tab]').forEach(el=>el.addEventListener('click',()=>discard(()=>{v.tab=el.dataset.liveTab;v.page=1;load(state,ctx,v);})));
  root.querySelector('[data-live-group]')?.addEventListener('change',e=>discard(()=>{v.groupBy=e.target.value;v.page=1;load(state,ctx,v);}));
  const search=root.querySelector('[data-live-search]');
  search?.addEventListener('change',e=>{const query=e.target.value;discard(()=>{v.query=query;v.page=1;load(state,ctx,v);});});
  root.querySelectorAll('[data-live-page]').forEach(el=>el.addEventListener('click',()=>discard(()=>{v.page+=Number(el.dataset.livePage);load(state,ctx,v);})));
  root.querySelectorAll('[data-live-customer]').forEach(el=>el.addEventListener('click',()=>{if(el.dataset.liveCustomer===v.selectedId){ctx.update(()=>{v.editorClosed=false;});return;}discard(()=>{v.editorClosed=false;selectCustomer(state,ctx,v,el.dataset.liveCustomer);});}));
  root.querySelector('[data-live-comment]')?.addEventListener('change',e=>{const id=e.target.value;discard(()=>{choose(v,id);ctx.update(()=>{});});});
  root.querySelector('[data-live-account]')?.addEventListener('change',e=>{if(v.busy||v.pending)return;v.accountId=e.target.value;ctx.update(()=>{});});
  root.querySelector('[data-live-draft]')?.addEventListener('input',e=>{if(v.busy||v.pending||v.batchBusy||v.batchPending||!selected(v))return;v.text=e.target.value;v.dirty=v.text!==(selected(v)?.draft?.text||'');const hints=root.querySelector('[data-live-wording]');if(hints)hints.hidden=v.dirty;root.querySelector('[data-live-count]').textContent=v.text.length;const blocked=v.detailSnapshot||v.detailLoading||v.readUnavailable||v.busy||v.batchBusy||Boolean(v.pending)||Boolean(v.batchPending)||!selected(v)?.canSave;root.querySelector('[data-live-save]').disabled=blocked||!v.text.trim();root.querySelector('[data-live-review]').disabled=blocked||!v.text.trim();root.querySelector('[data-live-review]').lastChild.textContent='准备发送';});
  root.querySelector('[data-live-copy]')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(v.text);ctx.toast('内容已复制，尚未确认发送。');}catch{root.querySelector('[data-live-draft]')?.select();ctx.toast('已选中文字，可手动复制。');}});
  root.querySelector('[data-live-save]')?.addEventListener('click',()=>mutate(state,ctx,v));
  root.querySelector('[data-live-review]')?.addEventListener('click',async()=>{
    if(!selected(v)||v.detailSnapshot||v.detailLoading||v.readUnavailable||v.busy||v.pending||!v.text.trim())return;
    if(v.dirty&&!(await mutate(state,ctx,v)))return;
    const row=selected(v);if(!row||v.busy||v.pending||v.dirty)return;
    if(row.reviewCurrent&&row.draft?.status==='approved'&&row.draft.review_account_id===v.accountId){prepareReviewed(state,ctx,v);return;}
    if(!row.canReview||!v.accountId){ctx.update(()=>{v.evidenceOpen=true;});ctx.toast(row.reason||(!v.accountId?'请先选择发送账号。':'请先保存草稿并核对当前回复条件。'));return;}
    const expected={actor:actor(state),customerId:v.selectedId,leadId:v.leadId,generation:v.generation,text:v.text,accountId:v.accountId,sourceDigest:row.sourceDigest,replyId:row.draft?.id,version:row.draft?.version};
    const account=row.accounts.find(a=>a.id===v.accountId);
    ctx.modal({title:'确认回复 · 逐条核对',html:`<p>原评论：</p><blockquote style="max-height:30vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere">${esc(row.text)}</blockquote><div class="rp-sender-confirm"><span>发送账号</span><strong>${esc(senderName(account))}</strong></div><blockquote class="rp-confirm-quote">${esc(v.text)}</blockquote><p>本步只保存审核记录，不会发送到平台。下一步须核对完整发送正文并最后授权。</p>`,confirmLabel:'核对本条并继续',onConfirm:async()=>{
      const current=selected(v);
      if(!active(state)||state.replyLive!==v||actor(state)!==expected.actor||v.selectedId!==expected.customerId||v.leadId!==expected.leadId||v.generation!==expected.generation||v.text!==expected.text||v.accountId!==expected.accountId||v.dirty||v.pending||current?.sourceDigest!==expected.sourceDigest||current?.draft?.id!==expected.replyId||current?.draft?.version!==expected.version)return false;
      const reviewed=await mutate(state,ctx,v,true);if(reviewed)await prepareReviewed(state,ctx,v);return reviewed;
    }});
  });
  root.querySelector('[data-live-check]')?.addEventListener('click',()=>checkPending(state,ctx,v));
  root.querySelector('[data-live-full-comment]')?.addEventListener('click',()=>ctx.modal({title:'完整原评论',html:`<blockquote style="max-height:55vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere">${esc(selected(v)?.text)}</blockquote>`,confirmLabel:'知道了'}));
  root.querySelectorAll('[data-live-source]').forEach(button=>button.addEventListener('click',()=>{const row=selected(v);const hosts={xiaohongshu:['www.xiaohongshu.com','xiaohongshu.com'],douyin:['www.douyin.com','douyin.com']};try{const url=new URL(row.postUrl);if(url.protocol!=='https:'||url.username||url.password||url.port||!hosts[row.platform]?.includes(url.hostname))throw new Error();window.open(url.href,'_blank','noopener');}catch{ctx.toast('源帖地址尚未核对，保留原评论来源。');}}));
}
