import {unifiedIntentMarkup,currentQualificationContract} from './unified-intent-view.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function approvedRulesSection(doc,section,storeName){
  if(section==='checklist')return unifiedIntentMarkup(doc);
  if(section==='intent'&&!currentQualificationContract(doc))return unifiedIntentMarkup(doc);
  const p=doc.activePolicy;if(!p?.approved)return null;
  const status=`<p class="br-policy-state" role="status">${esc(p.statusText)}</p>`;
  if(section==='words'){
    const store=doc.stores.find(row=>row.name===storeName)||doc.stores.find(row=>row.name===doc.selectedStoreName)||doc.stores[0];
    const current=store.name===doc.selectedStoreName,used=new Set(current?doc.activeSearch?.keywords||[]:[]);
    return '<h3>'+esc(store.name)+'的搜索词</h3><p>'+(current?'当前已纳入 '+used.size+' 个本店搜索词。':'当前仅查看这家门店的资料；实际搜索以获客页选择的门店为准。')+''+(p.allStores===false?'本店接收1—12个月需求；搜索命中后再核对原评论。':'资料待核和短租日租词不用于本版年租搜索。')+'</p>'+doc.groups.map(group=>`<details class="br-rule-detail"><summary>${esc(group)}（${store.terms.filter(t=>t.group===group).length}个词）</summary><div class="br-word-tags">${store.terms.filter(t=>t.group===group).map(t=>`<span>${esc(t.word)}<small>${t.pendingSource?'资料待核':group==='短租日租'?'不用于年租搜索':current&&used.has(t.word)?'已纳入本店搜索':'已核实资料词'}</small></span>`).join('')}</div></details>`).join('');
  }
  if(section==='intent')return unifiedIntentMarkup(doc)+status+'<h3>租房兴趣五级参考：'+(p.allStores===false?'古北店专用':'所有门店共用')+'</h3><p class="br-intro">以下五级表示租房兴趣强弱；最终门店等级还要结合上方时效、地域与公寓供需核对，不表示可以自动联系。</p><div class="br-level-list">'+p.levels.map(row=>`<section class="br-level"><h4>${esc(row.level)}意向</h4><div><p>${esc(row.text)}</p><p class="br-example"><strong>例如：</strong>${esc(row.example)}</p><p><strong>下一步：</strong>${esc(row.action)}</p></div></section>`).join('')+'</div><details class="br-rule-detail"><summary>租期、付款方式和门店适配怎样区分</summary>'+p.annualGuide.map(row=>`<section><h4>${esc(row.situation)}</h4><p>${esc(row.handle)}</p></section>`).join('')+'</details>';
  if(section==='exclude')return status+'<h3>语境排除与保留</h3><p class="br-intro">结合整句话和帖文判断。提到“中介”“房东”“吃饭”等词，不会直接删掉真实找房需求。</p><div class="br-exclusion-list">'+p.exclusions.map(row=>`<details class="br-rule-detail"><summary>${esc(row.title.split('（')[0])}</summary><div class="br-meaning-grid"><section><h4>这种情况排除</h4><p>${esc(row.exclude)}</p></section><section><h4>这种情况保留</h4><p>${esc(row.keep)}</p></section></div><p class="br-example"><strong>例如：</strong>${esc(row.example)}</p></details>`).join('')+'</div><p class="br-contact-note">'+esc(p.contactRule)+'</p>';
  if(section==='meeting')return '<h3>规则确认情况</h3><p>本版五级意向和语境规则已由你确认，不再列为待确认建议。</p>'+status+'<p>原资料中的地点、商家和待核搜索词仍保留来源状态，不会自动变成已核实事实。</p>';
  if(section==='examples')return status+'<h3>已确认五级的例子</h3>'+p.levels.map(row=>`<section class="br-rule-detail"><h4>${esc(row.level)}意向</h4><p>${esc(row.example)}</p><p>${esc(row.text)}</p></section>`).join('');
  return null;
}
