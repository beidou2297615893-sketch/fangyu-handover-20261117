const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uuid=()=>crypto.randomUUID();
const actor=s=>JSON.stringify([s.authEpoch||0,s.user,s.session?.user?.role,s.storeId,s.activePlatform||'xiaohongshu']);
export function followupSavePayload(scope,row,text,requestId){return {storeId:scope.storeId,customerId:scope.customerId,targetId:row.followupTargetId,sourceDigest:row.sourceDigest,text,expectedVersion:row.draft?.version||0,requestId};}
export function followupReviewPayload(scope,row,requestId){return {storeId:scope.storeId,customerId:scope.customerId,targetId:row.followupTargetId,sourceDigest:row.sourceDigest,replyId:row.draft.id,version:row.draft.version,accountId:scope.accountId,confirmed:true,requestId};}
export function followupDeliveryItem(scope,row){return {customerId:scope.customerId,leadId:row.id,sourceDigest:row.sourceDigest,replyId:row.draft.id,version:row.draft.version,accountId:scope.accountId,followupTargetId:row.followupTargetId};}
export function openFollowupEditor(ctx,input){
 const s=ctx.state,call=ctx.followupReplyAction||ctx.actions?.followupReplyAction,inbox=ctx.followupAction||ctx.actions?.followupAction,delivery=ctx.deliveryAction||ctx.actions?.deliveryAction;
 if(typeof call!=='function'||typeof inbox!=='function'||typeof delivery!=='function'){ctx.toast('原跟进审核发送链尚未完整装入。');return;}
 const original=actor(s),scope={...input},pendingKey='fangyu-followup-editor-v1:'+original+':'+input.eventId;
 const dialog=ctx.modal({title:'继续回复这条客户评论',html:'<p>正在核对原回信与我方账号…</p>'}),owner=dialog.__modalOwner;
 const v={body:null,row:null,text:'',dirty:false,busy:false,error:'',pending:null,plan:null,initialized:false,observationId:''};
 const valid=()=>actor(s)===original&&s.storeId===scope.storeId&&(s.activePlatform||'xiaohongshu')===scope.platform&&dialog.__modalOwner===owner&&(dialog.open||dialog.hasAttribute('open'));
 try{const saved=JSON.parse(localStorage.getItem(pendingKey)||'null');if(saved&&typeof saved.requestId==='string'&&typeof saved.kind==='string')v.pending=saved;}catch{v.pending={kind:'invalid'};}
 function remember(p){if(p)localStorage.setItem(pendingKey,JSON.stringify(p));else localStorage.removeItem(pendingKey);v.pending=p;}
 function adopt(result){
  const body=result.followupReplyWorkspace||result.replyWorkspace||result;
  if(!valid())return false;
  if(body?.actor?.username!==s.user||body.actor.storeId!==scope.storeId||body.customerId!==scope.customerId||!Array.isArray(body.comments)||body.comments.length!==1)throw Error('原客户或门店范围已变化，请重新读取。');
  const row=body.comments[0];if(!row.followupTargetId||row.id!==scope.originLeadId||row.target?.accountId&&row.target.accountId!==scope.accountId)throw Error('原回信目标或我方账号未核对。');
  if(v.row&&row.followupTargetId!==v.row.followupTargetId)throw Error('当前回信目标发生变化。');
  v.body=body;v.row=row;if(!v.dirty)v.text=row.draft?.text||(!v.initialized?scope.initialText||'':'');v.initialized=true;return true;
 }
 const invoke=(action,data)=>call(action,data);
 function paint(){
  if(!valid())return;const row=v.row,locked=v.busy||Boolean(v.pending),reviewed=row?.reviewCurrent&&row.draft?.status==='approved'&&row.draft.review_account_id===scope.accountId&&!v.dirty,plan=v.plan;
  dialog.querySelector('.modal-content').innerHTML=`<link rel="stylesheet" href="/pages/customer-followup.css"><div class="cf-thread"><h3>${esc(v.body?.item?.name||'当前客户')} · 本人账号继续跟进</h3><p role="status">${esc(v.error||row?.reason||'请核对客人的这条回信和回复正文。保存、审核和发送分别操作。')}</p>${row?`<p>这次回复的客户原话：</p><blockquote style="white-space:pre-wrap">${esc(row.text)}</blockquote><p>发送账号：${esc(row.accounts?.find(a=>a.id===scope.accountId)?.name||'本人原账号')} · 平台身份 ${esc(String(row.target?.accountUid||'').slice(-6)||'待核对')}</p><label class="cf-draft">回复正文<textarea data-fe-text rows="5" maxlength="1000" ${locked?'disabled':''}>${esc(v.text)}</textarea></label><div class="cf-actions"><button type="button" data-fe-save ${locked||!row.canSave||!v.text.trim()?'disabled':''}>保存这条跟进草稿</button><button type="button" data-fe-review ${locked||v.dirty||!row.canReview?'disabled':''}>逐条核对并审核</button><button type="button" data-fe-prepare ${locked||!reviewed?'disabled':''}>准备发送</button><button type="button" data-fe-refresh ${v.busy?'disabled':''}>刷新原回合</button></div>`:''}${v.pending?`<p>原${v.pending.kind==='start'?'发送':'保存或审核'}结果待核对，不会自动重试。<button type="button" data-fe-recover ${v.busy||v.pending.kind==='invalid'?'disabled':''}>核对原操作</button></p>`:''}${plan?`<section class="cf-preferences"><h3>最后核对发送</h3><p>${esc(plan.message||plan.state)} · ${plan.items?.length||0} 条</p>${(plan.items||[]).map(item=>`<p>发送账号：${esc(item.accountName)} · ${esc(item.identityMessage||'发送前将核对本人账号实际登录身份')}</p><blockquote style="white-space:pre-wrap">${esc(item.comment)}</blockquote><p>将发送的正文：</p><blockquote style="white-space:pre-wrap">${esc(item.text)}</blockquote>`).join('')}<div class="cf-actions"><button type="button" data-fe-start ${locked||v.dirty||!plan.canStart?'disabled':''}>确认发送这一条跟进</button><button type="button" data-fe-status ${v.busy?'disabled':''}>核对发送结果</button>${plan.canCancel?`<button type="button" data-fe-cancel ${locked?'disabled':''}>停止后续发送</button>`:''}</div><p>只向上面这条真实回信回复。未知结果保留原编号，后续发送停止。</p></section>`:''}</div>`;
  const el=k=>dialog.querySelector('[data-fe-'+k+']');
  el('text')?.addEventListener('input',e=>{v.text=e.target.value;v.dirty=true;v.plan=null;el('save').disabled=locked||!row.canSave||!v.text.trim();el('review').disabled=true;el('prepare').disabled=true;});
  el('save')?.addEventListener('click',()=>mutate('followup_reply_save',followupSavePayload(scope,row,v.text,uuid())));
  el('review')?.addEventListener('click',()=>mutate('followup_reply_review',followupReviewPayload(scope,row,uuid())));
  el('prepare')?.addEventListener('click',()=>deliveryOp('prepare',{items:[followupDeliveryItem(scope,row)],requestId:uuid()}));
  el('refresh')?.addEventListener('click',()=>{if(v.dirty){v.error='请先保存当前草稿；刷新没有覆盖未保存的正文。';paint();return;}load();});
  el('recover')?.addEventListener('click',recover);el('status')?.addEventListener('click',status);
  el('start')?.addEventListener('click',()=>{if(v.plan?.id===plan.id&&v.plan.snapshotDigest===plan.snapshotDigest&&!v.dirty)deliveryOp('start',{id:plan.id,snapshotDigest:plan.snapshotDigest,confirmed:true,requestId:uuid()});});
  el('cancel')?.addEventListener('click',()=>deliveryOp('cancel',{id:plan.id}));
 }
 async function load(){
  if(v.busy||!valid())return;v.busy=true;paint();
  try{
   if(!v.observationId){const viewId=uuid(),r=await inbox('followup_thread_read',{storeId:scope.storeId,accountId:scope.accountId,platform:scope.platform,viewId,eventId:scope.eventId});if(!valid())return;const b=r.followupWorkspace||r;if(b.context?.viewId!==viewId||b.context.accountId!==scope.accountId||b.context.storeId!==scope.storeId||b.item?.eventDigest!==scope.eventDigest||b.item.customerId!==scope.customerId||b.item.originLeadId!==scope.originLeadId)throw Error('这条回信来源已变化，请返回回复箱重新选择。');v.observationId=b.item.observationId;}
   adopt(await invoke('followup_reply_read',{storeId:scope.storeId,customerId:scope.customerId,...(v.row?{targetId:v.row.followupTargetId}:{observationId:v.observationId})}));
  }catch(e){if(valid())v.error=e.message;}
  finally{if(valid()){v.busy=false;paint();}}
 }
 async function mutate(operation,payload){
  if(v.busy||v.pending||!valid())return;try{remember({kind:'reply',operation,requestId:payload.requestId,targetId:v.row.followupTargetId});}catch{v.error='本机无法保留原操作编号，本次未提交。';paint();return;}
  v.busy=true;paint();try{const result=await invoke(operation,payload);if(!valid())return;const body=result.followupReplyWorkspace||result.replyWorkspace||result,receipt=body.request||body.receipt;if(receipt?.requestId!==payload.requestId||receipt.state!=='accepted')throw Error('原保存或审核回执待核对');v.dirty=false;adopt(body);remember(null);v.plan=null;v.error=operation==='followup_reply_save'?'草稿已保存，尚未发送。':'本条已审核，准备后还需要最后确认发送。';}catch(e){if(valid())v.error='原结果待核对：'+e.message;}finally{if(valid()){v.busy=false;paint();}}
 }
 function acceptPlan(result){const p=result.delivery||result;if(p.actor?.username!==s.user||p.actor?.storeId!==scope.storeId)throw Error('发送结果范围已变化');if(p.items?.some(item=>item.followupTargetId!==v.row.followupTargetId||item.accountId!==scope.accountId))throw Error('发送计划不是这条回信或本人账号');v.plan=p;return p;}
 async function deliveryOp(kind,payload){
  if(v.busy||v.pending||!valid())return;
  const requestId=payload.requestId||uuid();try{remember({kind,requestId,...(payload.id?{id:payload.id}:{})});}catch{v.error='本机无法保留原发送编号，本次未提交。';paint();return;}
  v.busy=true;paint();try{const r=await delivery(kind,{storeId:scope.storeId,platform:scope.platform,...payload});if(!valid())return;acceptPlan(r);remember(null);v.error=kind==='prepare'?'原队列已准备，请核对上方完整原话、正文和账号后最后确认。':'已读取本批原发送回执，请核对状态。';}catch(e){if(valid())v.error='原发送或准备结果待核对：'+e.message;}finally{if(valid()){v.busy=false;paint();}}
 }
 async function status(){
  if(v.busy||!valid())return;v.busy=true;paint();try{const p=v.pending,query=p?.kind==='prepare'?{requestId:p.requestId}:v.plan?.id?{id:v.plan.id}:p?.id?{id:p.id}:null;if(!query)throw Error('缺少原发送计划编号，请保留原操作记录');const r=await delivery('status',{storeId:scope.storeId,platform:scope.platform,...query});if(!valid())return;acceptPlan(r);if(v.pending&&v.pending.kind!=='reply')remember(null);v.error='已读取原计划，不会自动续发或换编号重试。';}catch(e){if(valid())v.error=e.message;}finally{if(valid()){v.busy=false;paint();}}
 }
 async function recover(){
  if(!v.pending||v.busy||!valid())return;if(v.pending.kind!=='reply')return status();const p=v.pending;v.busy=true;paint();try{const r=await invoke('followup_reply_request_read',{storeId:scope.storeId,customerId:scope.customerId,targetId:p.targetId,operation:p.operation,requestId:p.requestId});if(!valid())return;const receipt=r.replyFollowupRequest||r.receipt||r;if(receipt.requestId!==p.requestId)throw Error('原回执编号未匹配');if(receipt.state==='accepted'){v.dirty=false;const latest=await invoke('followup_reply_read',{storeId:scope.storeId,customerId:scope.customerId,targetId:p.targetId});if(!valid())return;adopt(latest);remember(null);v.error='原保存或审核已确认。';}else if(receipt.state==='not_found'){remember(null);v.error='原操作未记录，请刷新核对后再明确保存或审核。';}else throw Error('原操作仍待核对，继续保留原编号');}catch(e){if(valid())v.error=e.message;}finally{if(valid()){v.busy=false;paint();}}
 }
 paint();void load();return {close:()=>dialog.close()};
}
