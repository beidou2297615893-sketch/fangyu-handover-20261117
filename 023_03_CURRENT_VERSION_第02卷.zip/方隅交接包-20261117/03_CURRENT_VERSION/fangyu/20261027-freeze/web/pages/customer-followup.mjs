const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const id=()=>crypto.randomUUID();
export const maskPhoneText=value=>String(value??'').replace(/(?<![0-9])1[3-9][0-9]{9}(?![0-9])/g,v=>v.slice(0,3)+'****'+v.slice(-4));
export function acceptFollowupResponse(body,expected){
 const at=body?.context;
 if(!at||['viewId','storeId','accountId','platform'].some(k=>at[k]!==expected[k])||typeof at.actorId!=='string'||!at.actorId||(expected.actorId&&at.actorId!==expected.actorId)||!/^[a-f0-9]{64}$/.test(at.scopeKey||'')||(expected.scopeKey&&at.scopeKey!==expected.scopeKey))throw Error('员工、门店或账号范围已变化，请回原账号重新读取。');
 return body;
}
export function contactDraft(preferences={}){
 const intro=preferences.identityDisclosure?.trim(),prefix=intro?intro.replace(/[。.!！]+$/,'')+'。':'';
 const referral=preferences.referralName?.trim(),referralText=referral?'跟销售说是'+referral+'推荐的。':'';
 if(preferences.mode==='request_phone')return '需要的话，我可以帮你对接销售确认合适的联系途径。';
 if(preferences.mode==='share_sales'&&preferences.salesWechat?.trim())return '需要的话，可以联系销售微信 '+preferences.salesWechat.trim()+'，具体房源让销售帮你核对。';
 if(preferences.mode==='share_sales'&&preferences.salesPhone?.trim())return '需要的话，可以联系销售业务电话 '+preferences.salesPhone.trim()+'，具体房源让销售帮你核对。';
 return '';
}
export function firstReplyPreview(preferences={}){
 const offer=preferences.firstReplyOffer||{};
 if(offer.enabled!==true)return '首轮承接默认关闭，保留原有草稿行为。';
 if(offer.mode==='sales_contact'&&offer.shareContactApproved===true){
  if(preferences.salesWechat?.trim())return '资格合适后示例：需要的话，可以联系销售微信 '+preferences.salesWechat.trim()+'，具体房源请销售核对。';
  if(preferences.salesPhone?.trim())return '资格合适后示例：需要的话，可以联系销售业务电话 '+preferences.salesPhone.trim()+'，具体房源请销售核对。';
 }
 return '资格合适后示例：需要的话，我可以帮你对接销售确认合适的联系途径。';
}
const accountList=s=>(s.platform?.accounts||[]).filter(a=>a.platform===(s.activePlatform||'xiaohongshu'));
const actor=s=>JSON.stringify([s.authEpoch||0,s.user,s.session?.user?.id||'',s.session?.user?.tenant_id||'',s.session?.user?.role||'',s.storeId,s.activePlatform||'xiaohongshu']);
const pendingKey=(a,account)=>'fangyu-followup-pending-v1:'+a+':'+account;
const labels={new:'待查看',viewed:'已查看',follow_up:'待跟进'};
export function openCustomerFollowup(ctx,initialAccount=''){
 const s=ctx.state,call=ctx.followupAction||ctx.actions?.followupAction;
 if(typeof call!=='function'){ctx.toast('客户回复入口尚未完整装入，请更新后再读取。');return;}
 if(!s.session||!s.storeId){ctx.toast('请先登录并选择已授权门店。');return;}
 const ownActor=actor(s),dialog=ctx.modal({title:'客户回复',html:'<p>请选择本人账号读取已保存的客户回复。</p>'}),owner=dialog.__modalOwner;
 const v={account:accountList(s).some(a=>a.id===initialAccount)?initialAccount:'',items:[],selected:'',detail:null,draft:'',dirty:false,prefs:null,busy:false,error:'',refresh:'',viewId:id(),scopeKey:'',actorId:'',filter:'all',pending:null,checkCandidates:[],checkSelected:'',checkJob:null,checkPending:null,checkMessage:''};
 dialog.classList.add('customer-followup-modal');
 const valid=()=>actor(s)===ownActor&&dialog.__modalOwner===owner&&(dialog.open||dialog.hasAttribute('open'));
 const capture=()=>({viewId:v.viewId,storeId:s.storeId,accountId:v.account,platform:s.activePlatform||'xiaohongshu',actorId:v.actorId,scopeKey:v.scopeKey});
 const current=c=>valid()&&c.accountId===v.account&&c.viewId===v.viewId;
 function pendingRead(){try{const p=JSON.parse(localStorage.getItem(pendingKey(ownActor,v.account))||'null');return p&&typeof p.requestId==='string'&&typeof p.operation==='string'&&p.operation.endsWith('_save')?p:null;}catch{return {invalid:true};}}
 function remember(p){const key=pendingKey(ownActor,v.account);if(p)localStorage.setItem(key,JSON.stringify(p));else localStorage.removeItem(key);v.pending=p;}
 async function request(action,data,c){const response=await call(action,{storeId:c.storeId,accountId:c.accountId,platform:c.platform,viewId:c.viewId,...data});if(!current(c))return null;return acceptFollowupResponse(response.followupWorkspace||response,c);}
 function paint(){
  if(!valid())return;const item=v.items.find(e=>e.id===v.selected),locked=v.busy||Boolean(v.pending),items=v.items.filter(e=>v.filter==='all'||v.filter==='new'&&e.unread||e.state===v.filter);
  dialog.querySelector('.modal-content').innerHTML=`<link rel="stylesheet" href="/pages/customer-followup.css"><div class="cf-tools"><label>本人平台账号<select data-cf-account ${v.busy?'disabled':''}><option value="">请选择已授权账号</option>${accountList(s).map(a=>`<option value="${esc(a.id)}" ${v.account===a.id?'selected':''}>${esc(a.platformNickname||a.platform_nickname||a.name||'账号昵称未提供')}</option>`).join('')}</select></label><label>处理状态<select data-cf-filter>${[['all','全部'],['new','待查看'],['follow_up','待跟进'],['viewed','已查看']].map(([k,n])=>`<option value="${k}" ${v.filter===k?'selected':''}>${n}</option>`).join('')}</select></label><button type="button" data-cf-refresh ${!v.account||v.busy?'disabled':''}>刷新已保存回复</button><span>待查看 ${v.items.filter(e=>e.unread).length}</span></div><p class="cf-notice" role="status">${esc(v.error||'这里显示本机已核对的客户评论回应；刷新不会清除未读。')}${v.refresh?' · 最后刷新 '+esc(v.refresh):''}</p>${v.pending?`<p class="cf-notice">${v.pending.invalid?'本机原操作断点无法核对，请保留本机记录。':`原保存结果待核对，继续保留原编号。<button type="button" data-cf-check ${v.busy?'disabled':''}>核对原操作</button>`}</p>`:''}${typeof (ctx.responseCheckAction||ctx.actions?.responseCheckAction)==='function'?`<details class="cf-response-check"><summary>单次检查平台回信</summary><p>只检查已联系客户的原评论线程，不是实时收件。每次由你点击开始，继续使用本人账号、设备权限及原发送凭据核验；最多读取本次受控范围。</p><label>已联系客户<select data-cf-check-customer ${v.busy||v.checkPending?'disabled':''}><option value="">请选择原发送记录</option>${v.checkCandidates.map(c=>`<option value="${esc(c.replyId)}" ${v.checkSelected===c.replyId?'selected':''}>${esc(c.name)} · ${esc(c.sentAt||'发送时间待核对')}</option>`).join('')}</select></label><div class="cf-actions"><button type="button" data-cf-check-start ${v.busy||v.checkPending||v.checkJob&&['queued','running'].includes(v.checkJob.status)||!v.checkSelected?'disabled':''}>读取这位客人的新回复</button><button type="button" data-cf-check-status ${v.busy||!(v.checkPending||v.checkJob)?'disabled':''}>${v.checkPending?'核对原检查请求':'刷新本次检查结果'}</button>${v.checkJob&&!['found','not_found','partial','unavailable','needs_review','failed','cancelled','interrupted'].includes(v.checkJob.status)?`<button type="button" data-cf-check-cancel ${v.busy?'disabled':''}>停止后续读取</button>`:''}</div><p role="status">${esc(v.checkMessage||'不会在后台自动开始或重试平台读取。')}</p></details>`:''}<div class="cf-workspace"><section class="cf-list" aria-label="客户回信" aria-busy="${v.busy}">${items.map(e=>`<button type="button" data-cf-event="${esc(e.id)}" class="cf-row ${e.id===v.selected?'is-selected':''}"><strong>${esc(e.name)} ${e.unread?'●':''}</strong><span>${esc(maskPhoneText(e.text))}</span><small>${esc(e.channelLabel)} · ${esc(labels[e.state]||'待核对')}</small></button>`).join('')||'<p>当前账号没有已保存并核对归属的客户回复。</p>'}</section><section class="cf-thread" aria-label="回复会话">${item?`<h3>${esc(item.name)} · ${esc(item.channelLabel)}</h3><ol class="cf-timeline"><li><small>客户原评论</small><p>${esc(item.originalText)}</p></li><li><small>我方已发送</small><p>${esc(item.sentText)}</p></li><li><small>客户回复 · ${esc(labels[item.state])}</small><p>${esc(v.detail?.id===item.id?v.detail.originalInboundText:item.text)}</p></li></ol><div class="cf-actions"><button type="button" data-cf-view ${locked?'disabled':''}>打开回信并标为已查看</button><button type="button" data-cf-follow ${locked?'disabled':''}>标为待跟进</button><button type="button" data-cf-source>查看原帖</button></div><label class="cf-draft">继续跟进草稿<textarea data-cf-draft maxlength="1000" rows="4" placeholder="按客人的真实问题继续回复，客户手机号不要写入公开评论。" ${locked?'disabled':''}>${esc(v.draft)}</textarea></label><div class="cf-actions"><button type="button" data-cf-contact-draft ${locked||!contactDraft(v.prefs||{})?'disabled':''}>填入承接话术</button><button type="button" data-cf-save ${locked||!v.draft.trim()?'disabled':''}>保存跟进草稿</button>${typeof ctx.openFollowupReply==='function'||typeof ctx.actions?.openFollowupReply==='function'?`<button type="button" data-cf-continue ${locked?'disabled':''}>继续回复这条评论</button>`:'<span>原发送链尚未装入此回合，草稿保留待核对。</span>'}</div><details class="cf-phone"><summary>客户自愿留电话</summary><p>仅登记这条回信中客户本人自愿提供的号码，保存后在清单中遮盖。</p>${item.phone?`<p>${esc(item.phone.masked)} · ${esc(item.phone.source)} · 推荐归因 ${esc(item.phone.referralName||'未填写')} · 已保存，尚未交销售</p><button type="button" data-cf-phone-read ${locked?'disabled':''}>按权限查看号码</button>`:''}<input data-cf-phone inputmode="tel" maxlength="11" placeholder="客户在这条回信中自愿提供的手机号" ${locked?'disabled':''}><textarea data-cf-consent rows="2" placeholder="复制这条回信中客户自愿留号的原话" ${locked?'disabled':''}></textarea><label><input type="checkbox" data-cf-voluntary ${locked?'disabled':''}>我已核对是客户本人自愿提供，用于本次销售联系</label><button type="button" data-cf-phone-save ${locked?'disabled':''}>私有保存</button><output data-cf-private-phone></output></details>`:'<p>选择一条客户回复，查看原评论、我方回复和客人后续回应。</p>'}</section></div><details class="cf-preferences"><summary>销售承接设置</summary><p>仅当前账号使用；身份介绍必须符合本人真实情况，号码未确认时保持留空。</p><label>下一步<select data-cf-mode>${[['unconfigured','暂不配置'],['share_sales','给客人销售联系方式'],['request_phone','请求客人自愿私下留电话']].map(([k,n])=>`<option value="${k}" ${v.prefs?.mode===k?'selected':''}>${n}</option>`).join('')}</select></label><label>推荐代号<input data-cf-referral maxlength="40" value="${esc(v.prefs?.referralName??'小北')}" placeholder="例如：小北，不改变平台昵称或UID"></label><label>真实身份介绍<input data-cf-identity maxlength="120" value="${esc(v.prefs?.identityDisclosure||'')}" placeholder="例如：我是这里的租户（仅本人身份属实时填写）"></label><p>本人已确认的短说明：我是这边租户，小北推荐，推荐有积分。仅限真实本人住户账号，不代表固定返额或保证返款。</p><label><input type="checkbox" data-cf-owner-confirm>当前回复账号确实是本人的真实住户身份</label><button type="button" data-cf-owner-example>填入本人推荐说明</button><label>销售微信<input data-cf-wechat maxlength="120" value="${esc(v.prefs?.salesWechat||'')}" placeholder="真实销售微信，未确认留空"></label><label>销售电话<input data-cf-sales-phone maxlength="30" value="${esc(v.prefs?.salesPhone||'')}" placeholder="真实销售电话，未确认留空"></label><section class="cf-first-offer"><h4>首轮回复的可选销售帮助</h4><label><input type="checkbox" data-cf-first-enabled ${v.prefs?.firstReplyOffer?.enabled?'checked':''}>本账号生成首轮草稿时，可在资格合适后表达销售对接意愿</label><label>首轮承接方式<select data-cf-first-mode><option value="request_phone" ${v.prefs?.firstReplyOffer?.mode!=='sales_contact'?'selected':''}>优先自愿私下联系；无已验证接收途径时仅表达对接意愿</option><option value="sales_contact" ${v.prefs?.firstReplyOffer?.mode==='sales_contact'?'selected':''}>提供已确认可公开展示的销售联系方式</option></select></label><label><input type="checkbox" data-cf-first-public ${v.prefs?.firstReplyOffer?.shareContactApproved?'checked':''}>我确认上面填写的是可向客人展示的真实销售微信或业务电话</label><p data-cf-first-preview>${esc(firstReplyPreview(v.prefs||{}))}</p><p>只影响本账号之后的新候选，不更新旧草稿。未知地域或时效先澄清；地域不符、拒公寓、供给或需求已结束不推销。当前没有已核验的私信接收途径，不要求在公开评论贴手机号，不声称软件能收到或自动转交。身份、小北归因及积分只采用当前账号已确认的真实资料，不能由这处身份说明覆盖。</p></section><button type="button" data-cf-preferences-save ${locked||!v.prefs?'disabled':''}>保存承接设置</button><p>填写设置和保存草稿不会发送消息；积分或返额只写本人已核实事实。</p></details>`;
  const el=name=>dialog.querySelector('[data-cf-'+name+']');
  el('account').onchange=e=>{if(v.dirty){v.error='请先保存当前草稿再切换账号。';paint();return;}v.account=e.target.value;v.checkCandidates=[];v.checkSelected='';v.checkJob=null;v.checkPending=null;v.checkMessage='';try{v.checkPending=JSON.parse(localStorage.getItem(pendingKey(ownActor,v.account)+':platform-check')||'null');}catch{}v.items=[];v.selected='';v.detail=null;v.draft='';v.prefs=null;v.scopeKey='';v.viewId=id();v.pending=pendingRead();load();};
  el('filter').onchange=e=>{v.filter=e.target.value;paint();};el('refresh').onclick=()=>load();el('check')?.addEventListener('click',check);
  dialog.querySelectorAll('[data-cf-event]').forEach(button=>button.onclick=()=>{if(v.dirty){v.error='当前草稿未保存，请先保存再换客人。';paint();return;}v.selected=button.dataset.cfEvent;v.detail=null;v.draft=v.items.find(e=>e.id===v.selected)?.draft?.text||'';paint();});
  if(item){
   el('draft').oninput=e=>{v.draft=e.target.value;v.dirty=true;el('save').disabled=locked||!v.draft.trim();};
   el('view').onclick=()=>openThread(item);el('follow').onclick=()=>mutate('followup_state_save',item,{state:'follow_up'});
   el('source').onclick=()=>{try{const u=new URL(item.sourceUrl);if(u.protocol==='https:'&&u.hostname==='www.xiaohongshu.com'&&/^\/explore\/[a-zA-Z0-9]{24}$/.test(u.pathname)&&!u.search&&!u.hash&&!u.username&&!u.password)window.open(u.href,'_blank','noopener');}catch{}};
   el('contact-draft').onclick=()=>{if(v.dirty&&v.draft.trim()){v.error='请先保存当前草稿，避免承接话术覆盖。';paint();return;}v.draft=contactDraft(v.prefs);v.dirty=true;paint();};
   el('save').onclick=()=>mutate('followup_draft_save',item,{text:v.draft});
   el('continue')?.addEventListener('click',()=>{if(v.dirty){v.error='请先保存当前跟进草稿，再进入原审核发送步骤。';paint();return;}const open=ctx.openFollowupReply||ctx.actions?.openFollowupReply;open({storeId:s.storeId,accountId:v.account,platform:s.activePlatform||'xiaohongshu',eventId:item.id,eventDigest:item.eventDigest,customerId:item.customerId,originLeadId:item.originLeadId,initialText:v.draft});});
   el('phone-save').onclick=()=>mutate('followup_phone_save',item,{phone:el('phone').value,consentText:el('consent').value,voluntary:el('voluntary').checked});
   el('phone-read')?.addEventListener('click',async()=>{const c=capture();try{const r=await request('followup_phone_read',{eventId:item.id},c);if(r&&v.selected===item.id)el('private-phone').textContent=r.phone||'尚未登记号码';}catch(e){if(current(c)){v.error=e.message;paint();}}});
  }
  el('owner-example').onclick=()=>{if(!el('owner-confirm').checked){v.error='请先核对当前账号确实是本人住户身份。';paint();return;}const referral=el('referral').value.trim();el('identity').value='我是这边租户'+(referral?'，'+referral+'推荐':'')+'，推荐有积分';};
  el('check-customer')?.addEventListener('change',e=>{v.checkSelected=e.target.value;paint();});
  el('check-start')?.addEventListener('click',()=>responseCheck('start'));
  el('check-status')?.addEventListener('click',()=>responseCheck('status'));
  el('check-cancel')?.addEventListener('click',()=>responseCheck('cancel'));
  for(const name of ['first-enabled','first-mode','first-public'])el(name)?.addEventListener('change',()=>{el('first-preview').textContent=firstReplyPreview({salesWechat:el('wechat').value,salesPhone:el('sales-phone').value,firstReplyOffer:{enabled:el('first-enabled').checked,mode:el('first-mode').value,shareContactApproved:el('first-public').checked}});});
  el('preferences-save').onclick=()=>mutate('followup_preferences_save',null,{mode:el('mode').value,identityDisclosure:el('identity').value,salesWechat:el('wechat').value,salesPhone:el('sales-phone').value,referralName:el('referral').value,firstReplyOffer:{enabled:el('first-enabled').checked,mode:el('first-mode').value,shareContactApproved:el('first-public').checked}});
 }
 async function load(){
  if(!v.account){paint();return;}if(v.busy)return;const c=capture();v.busy=true;v.error='正在读取本机已保存的评论回应…';paint();
  try{const r=await request('followup_inbox_read',{},c);if(!r)return;v.items=r.items;v.checkCandidates=r.checkCandidates||[];v.scopeKey=r.context.scopeKey;v.actorId=r.context.actorId;v.refresh=r.refreshedAt;v.error=r.capabilities?.message||'';if(v.selected&&!v.items.some(e=>e.id===v.selected)){v.selected='';v.detail=null;}const p=await request('followup_preferences_read',{},capture());if(p)v.prefs=p.preferences;}
  catch(e){if(current(c))v.error=e.message;}
  finally{if(current(c)){v.busy=false;paint();}}
 }
 async function mutate(operation,event,data){
  if(v.busy||v.pending)return;const c=capture(),requestId=id(),payload={...data,expectedVersion:event?event.version:v.prefs.version,requestId,...(event?{eventId:event.id,eventDigest:event.eventDigest}:{})};
  try{remember({operation,requestId});}catch{v.error='本机无法保留原操作编号，本次未提交。';paint();return;}
  v.busy=true;v.error='正在保存，请保留原操作编号…';paint();
  try{const r=await request(operation,payload,c);if(!r)return;if(r.receipt?.requestId!==requestId||r.receipt?.state!=='accepted')throw Error('保存回执待核对');remember(null);if(r.item)v.items=v.items.map(e=>e.id===r.item.id?r.item:e);if(operation==='followup_draft_save')v.dirty=false;if(r.preferences)v.prefs=r.preferences;v.error='已保存，消息尚未发送。';}
  catch(e){if(current(c))v.error='保存结果待核对：'+e.message;}
  finally{if(current(c)){v.busy=false;paint();}}
 }
 async function check(){
  if(!v.pending||v.pending.invalid||v.busy)return;const c=capture(),p=v.pending;v.busy=true;paint();
  try{const r=await request('followup_request_read',p,c);if(!r)return;if(r.receipt?.requestId!==p.requestId)throw Error('原回执编号未匹配');if(['accepted','not_found'].includes(r.receipt.state)){remember(null);v.error=r.receipt.state==='accepted'?'原操作已确认保存，请刷新读取最新记录。':'后台未记录原操作，请刷新核对后重新明确保存。';}else throw Error('原结果仍待核对');}
  catch(e){if(current(c))v.error=e.message;}
  finally{if(current(c)){v.busy=false;paint();}}
 }
 async function responseCheck(kind){
  if(v.busy||!v.account||!valid())return;const c=capture(),api=ctx.responseCheckAction||ctx.actions?.responseCheckAction,candidate=v.checkCandidates.find(x=>x.replyId===v.checkSelected);
  if(kind==='start'&&(!candidate||v.checkPending||v.checkJob&&['queued','running'].includes(v.checkJob.status)))return;
  let data;
  if(kind==='start'){
   const pending={requestId:id()};try{localStorage.setItem(pendingKey(ownActor,v.account)+':platform-check',JSON.stringify(pending));}catch{v.checkMessage='本机无法保留原检查编号，本次未请求平台。';paint();return;}
   v.checkPending=pending;data={customerId:candidate.customerId,replyId:candidate.replyId,requestId:pending.requestId};
  }else if(kind==='cancel'){if(!v.checkJob?.id)return;data={jobId:v.checkJob.id};}
  else data=v.checkPending?{requestId:v.checkPending.requestId}:v.checkJob?.id?{jobId:v.checkJob.id}:null;
  if(!data)return;v.busy=true;v.checkMessage='正在核对原单次检查…';paint();
  try{
   const result=await api('customer_response_check_'+kind,{storeId:c.storeId,accountId:c.accountId,platform:c.platform,viewId:c.viewId,...data});if(!current(c))return;
   const r=result.responseCheck||result;
   if(r.actor?.username!==s.user||r.actor.storeId!==c.storeId||r.accountId!==c.accountId)throw Error('原检查账号或门店范围已变化');
   if(r.state==='accepted'&&r.job){v.checkJob=r.job;v.checkPending=null;localStorage.removeItem(pendingKey(ownActor,v.account)+':platform-check');v.checkMessage=r.job.message||r.message||'已读取本次原检查状态';}
   else v.checkMessage=r.message||'原检查结果待核对，不会自动重复读取。';
  }catch(e){if(current(c)){
   v.checkMessage=e.message;
   if(['FOLLOWUP_RECEIVER_UNAVAILABLE','FOLLOWUP_RECEIVER_FORBIDDEN','FOLLOWUP_CHECK_NOT_FOUND','INPUT_INVALID','STORE_FORBIDDEN','ACCOUNT_FORBIDDEN','FOLLOWUP_SOURCE_CHANGED'].includes(e.code)){v.checkPending=null;try{localStorage.removeItem(pendingKey(ownActor,v.account)+':platform-check');}catch{}}
  }}finally{if(current(c)){v.busy=false;paint();}}
  if(current(c)&&kind!=='start'&&v.checkJob&&!['queued','running'].includes(v.checkJob.status))await load();
 }
 async function openThread(item){const c=capture();v.busy=true;paint();try{const r=await request('followup_thread_read',{eventId:item.id},c);if(r&&v.selected===item.id)v.detail={...r.item,originalInboundText:r.originalInboundText};}catch(e){if(current(c))v.error=e.message;}finally{if(current(c)){v.busy=false;paint();}}if(current(c)&&v.detail?.id===item.id&&item.unread)await mutate('followup_state_save',item,{state:'viewed'});}
 v.pending=pendingRead();try{v.checkPending=JSON.parse(localStorage.getItem(pendingKey(ownActor,v.account)+':platform-check')||'null');}catch{}paint();if(v.account)void load();return {close:()=>dialog.close()};
}
