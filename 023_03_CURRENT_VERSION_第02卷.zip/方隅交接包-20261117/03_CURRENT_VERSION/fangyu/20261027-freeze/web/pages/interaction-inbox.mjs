import {senderName} from './reply-account.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const id=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(v);
const actions=new Set(['new','follow_up','viewed','ignored','restore']);
const scope=(s,account)=>JSON.stringify([globalThis.location?.origin||'',s.session?.user?.tenant_id||'',s.user,s.session?.user?.role||'',s.storeId,account,'xiaohongshu']);
const storageKey=base=>'fangyu-inbox-pending-v1:'+base;
async function requestDigest(request){const canonical=JSON.stringify(Object.fromEntries(Object.keys(request).sort().map(k=>[k,request[k]])));const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(canonical));return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,'0')).join('');}
const accounts=s=>s.platform?.actor?.username===s.user&&s.platform.actor.storeId===s.storeId?(s.platform.accounts||[]).filter(a=>a.platform==='xiaohongshu'&&typeof a.id==='string'):[];
const count=v=>Number.isSafeInteger(v)&&v>=0?v:'—';
function publicUrl(value){try{const u=new URL(value);return u.protocol==='https:'&&['www.xiaohongshu.com','xiaohongshu.com'].includes(u.hostname)&&!u.username&&!u.password&&!u.port&&!u.search&&!u.hash&&/^\/explore\/[A-Za-z0-9]{1,128}$/.test(u.pathname)?u.href:'';}catch{return '';}}
function pendingFrom(base){
  let value;
  try{
    value=globalThis.localStorage?.getItem(storageKey(base));if(value==null)return null;
    const p=JSON.parse(value),parts=JSON.parse(base);
    const r=p?.request;
    if(p?.base===base&&hash(p.scopeKey)&&hash(p.requestDigest)&&typeof p.actorId==='string'&&r&&id(r.requestId)&&id(r.viewId)&&hash(r.eventId)&&hash(r.eventDigest)&&Number.isSafeInteger(r.expectedVersion)&&r.expectedVersion>=0&&actions.has(r.state)
      &&r.storeId===parts[4]&&r.accountId===parts[5]&&r.platform==='xiaohongshu'
      &&Object.keys(p).sort().join(',')===['actorId','base','request','requestDigest','scopeKey'].sort().join(',')
      &&Object.keys(r).sort().join(',')===['storeId','accountId','platform','viewId','eventId','eventDigest','expectedVersion','state','requestId'].sort().join(','))return p;
  }catch{}
  return value!=null?{invalid:true,base,reason:'本机原操作断点不完整或账号范围不一致，不能发送或另建操作；请保留本机记录核对。'}:null;
}
function remember(base,p){try{const key=storageKey(base);if(p){const text=JSON.stringify(p);globalThis.localStorage?.setItem(key,text);return globalThis.localStorage?.getItem(key)===text;}globalThis.localStorage?.removeItem(key);return globalThis.localStorage?.getItem(key)==null;}catch{return false;}}

export function openInteractionInbox(ctx,initialAccount='',options={}){
  const s=ctx.state;
  if(typeof ctx.interactionInboxAction!=='function'){ctx.toast('当前版本的互动收件入口尚未完整装入，请更新后再查看。');return;}
  if(!s.session||!s.storeId||(s.activePlatform||'xiaohongshu')!=='xiaohongshu'){ctx.toast('请先选择已授权门店和小红书。');return;}
  const startActor=JSON.stringify([s.user,s.storeId,s.session?.user?.role,s.authEpoch||0]);
  const u={account:accounts(s).some(a=>a.id===initialAccount)?initialAccount:'',type:'all',state:'all',page:1,pageSize:30,viewId:crypto.randomUUID(),scopeKey:'',actorId:'',items:[],stats:null,total:null,hasMore:false,pending:null,notFound:false,busy:false,message:'',selectedId:''};
  const embedded=Boolean(options.host),dialog=options.host||ctx.modal({title:'已保存互动',html:'<p>正在读取本地互动记录…</p>'});
  let mounted=true;
  if(embedded){dialog.innerHTML='<div class="modal-content"><p>正在读取本地互动记录…</p></div>';dialog.__modalOwner=Symbol('inbox-host');dialog.classList.add('ii-embedded');}
  dialog.classList.add('interaction-inbox-modal');
  const owner=dialog.__modalOwner,oldClose=dialog.onclose;
  const valid=()=>{
    const sameActor=JSON.stringify([s.user,s.storeId,s.session?.user?.role,s.authEpoch||0])===startActor&&(s.activePlatform||'xiaohongshu')==='xiaohongshu';
    const opened=embedded?mounted&&dialog.isConnected&&s.page==='diversified':dialog.open||dialog.hasAttribute('open');
    if(!sameActor&&dialog.__modalOwner===owner&&opened){dialog.querySelector('.modal-content').textContent='账号或门店已变化，原互动页面已关闭。';if(embedded){mounted=false;u.viewId=crypto.randomUUID();}else dialog.close();}
    return sameActor&&dialog.__modalOwner===owner&&opened;
  };
  const capture=()=>({base:scope(s,u.account),accountId:u.account,storeId:s.storeId,viewId:u.viewId,scopeKey:u.scopeKey,actorId:u.actorId,epoch:s.authEpoch||0});
  const current=c=>valid()&&c.base===scope(s,u.account)&&c.viewId===u.viewId&&c.epoch===(s.authEpoch||0)&&accounts(s).some(a=>a.id===u.account);
  function accept(c,response,pending=null){
    if(!current(c))return null;
    const body=response?.interactionInbox,at=body?.context;
    if(response?.ok===false||!at||at.viewId!==c.viewId||at.storeId!==c.storeId||at.accountId!==c.accountId||at.platform!=='xiaohongshu'||typeof at.actorId!=='string'||!at.actorId||!hash(at.scopeKey))throw Error('互动范围回执尚未核对，已保留原操作。');
    if((c.actorId&&at.actorId!==c.actorId)||(c.scopeKey&&at.scopeKey!==c.scopeKey)||(u.pending&&!u.pending.invalid&&(at.actorId!==u.pending.actorId||at.scopeKey!==u.pending.scopeKey)))throw Error('原账号身份或互动范围已变化，请回到原账号核对原操作。');
    if(pending&&(body.receipt?.requestId!==pending.request.requestId||body.receipt?.eventId!==pending.request.eventId||body.item?.id!==pending.request.eventId))throw Error('返回的不是原互动操作，核对断点已保留。');
    if(body.items!==undefined&&!Array.isArray(body.items))throw Error('互动列表回执格式尚未核对，请保留当前账号重新读取。');
    for(const item of [...(body.items||[]),...(body.item?[body.item]:[])]){
      const old=item&&u.items.find(x=>x.id===item.id);
      if(!item||typeof item!=='object'||!hash(item.id)||!hash(item.eventDigest)||!Number.isSafeInteger(item.version)||item.version<0||(old&&item.version<old.version))throw Error('互动版本已更新，较旧结果未覆盖当前记录。');
    }
    u.scopeKey=at.scopeKey;u.actorId=at.actorId;return body;
  }
  if(!embedded)dialog.onclose=e=>{if(dialog.__modalOwner===owner){u.viewId=crypto.randomUUID();dialog.classList.remove('interaction-inbox-modal');}oldClose?.call(dialog,e);};
  const closeView=()=>{mounted=false;u.viewId=crypto.randomUUID();if(embedded){dialog.replaceChildren();delete dialog.__modalOwner;}else dialog.close();};
  function restore(){u.pending=pendingFrom(scope(s,u.account));u.notFound=false;}
  async function verifyPending(p,c){
    if(await requestDigest(p.request)===p.requestDigest)return current(c);
    if(current(c)){u.pending={invalid:true,base:p.base,reason:'本机原操作参数与保存摘要不一致，不能按变更内容重试；已保留原记录待核。'};u.message=u.pending.reason;}
    return false;
  }
  function renderItem(item,locked){return `<article class="ii-row" data-ii-item="${item.id}"><header><strong>${esc(item.actorName||'通知中未提供昵称')} · ${esc(item.typeLabel)}</strong><span>${esc(item.stateLabel||({new:'待查看',follow_up:'待跟进',viewed:'已查看',ignored:'已忽略'}[item.state])||'状态待核对')}</span></header><p>${esc(item.sourceLabel||'小红书本人通知')}${item.observedAt?' · 本机保存于 '+esc(item.observedAt):''}${item.baseline?' · 首轮历史基线':''}</p>${item.commentText?`<blockquote>${esc(item.commentText)}</blockquote>`:`<p>${esc(item.originalCommentReason||'通知没有提供完整评论，当前受控链无法按通知补全文。')}</p>`}<footer>${publicUrl(item.sourceUrl)?`<button type="button" data-ii-source="${item.id}">打开官方原帖</button>`:''}${hash(item.linkedCustomerId)?`<button type="button" data-ii-customer="${item.id}">查看关联客户</button>`:''}${[['follow_up','待跟进'],['viewed','已查看'],['ignored','忽略']].map(([k,v])=>`<button type="button" data-ii-set="${k}" data-ii-id="${item.id}" ${locked||item.state===k?'disabled':''}>${v}</button>`).join('')}${item.state==='ignored'?`<button type="button" data-ii-set="restore" data-ii-id="${item.id}" ${locked?'disabled':''}>恢复之前状态</button>`:''}</footer></article>`;}
  function paint(){
    if(!valid())return;
    const locked=u.busy||Boolean(u.pending),selectedItem=u.items.find(i=>i.id===u.selectedId)||u.items[0];
    dialog.querySelector('.modal-content').innerHTML=`<style>.interaction-inbox-modal{width:min(1040px,calc(100vw - 48px));max-height:90vh}.interaction-inbox-modal .modal-content{max-height:calc(90vh - 160px);overflow:auto}.ii-tools{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.ii-tools label{display:grid;gap:5px}.ii-tools select{min-width:150px}.ii-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:16px 0}.ii-stats div{border:1px solid #dfe8e7;background:#f7faf9;border-radius:9px;padding:12px}.ii-stats strong{display:block;font-size:23px;color:#246d66}.ii-list{display:grid;gap:12px}.ii-row{padding:16px;border:1px solid #dfe8e7;border-radius:10px;background:#fff}.ii-row header{display:flex;justify-content:space-between;gap:12px}.ii-row blockquote{margin:12px 0;white-space:pre-wrap;overflow-wrap:anywhere}.ii-row footer,.ii-pager{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:12px}.ii-row p,.ii-notice{color:#61726e;line-height:1.6}.ii-message{padding:10px;background:#f3f7f6;border-radius:8px;white-space:pre-wrap}.ii-pager{justify-content:flex-end}@media(max-width:720px){.ii-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}</style>
      <p class="ii-notice">${esc(s.store)} · 小红书本人互动。这里读取本地已保存记录；点赞、收藏和关注不代表租房意向，处理状态不改变客户意向。</p>
      <div class="ii-tools"><label>本人小红书账号<select data-ii-account><option value="">请选择已授权账号</option>${accounts(s).map(a=>`<option value="${esc(a.id)}" ${a.id===u.account?'selected':''}>${esc(senderName(a))}</option>`).join('')}</select></label>
      <label>互动类型<select data-ii-type>${[['all','全部类型'],['mentions','评论和提及'],['likes','点赞和收藏'],['connections','新增关注']].map(([k,v])=>`<option value="${k}" ${u.type===k?'selected':''}>${v}</option>`).join('')}</select></label>
      <label>处理状态<select data-ii-state>${[['all','全部状态'],['new','待查看'],['follow_up','待跟进'],['viewed','已查看'],['ignored','已忽略']].map(([k,v])=>`<option value="${k}" ${u.state===k?'selected':''}>${v}</option>`).join('')}</select></label><button type="button" data-ii-refresh ${!u.account||u.busy?'disabled':''}>刷新本地记录</button></div>
      <div class="ii-stats">${[['totalEvents','已保存互动'],['withOriginalCommentEvents','有本人原评论的互动'],['linkedCommentCount','关联已有原评论'],['linkedCustomerCount','关联已有客户']].map(([k,v])=>`<div>${v}<strong>${count(u.stats?.[k])}</strong></div>`).join('')}</div>
      ${u.message?`<p class="ii-message" role="status">${esc(u.message)}</p>`:''}${u.pending?(u.pending.invalid?`<p class="ii-message">${esc(u.pending.reason)}</p>`:`<p class="ii-message">处理结果待核对。保留原操作编号，不会自动重发。<button type="button" data-ii-check ${u.busy?'disabled':''}>核对原操作</button>${u.notFound?` <button type="button" data-ii-retry ${u.busy?'disabled':''}>按原操作重试</button>`:''}</p>`):''}
      <div class="ii-workspace"><div class="ii-list" aria-busy="${u.busy}">${u.items.map(item=>`<button type="button" class="ii-preview ${selectedItem?.id===item.id?'is-selected':''}" data-ii-select="${item.id}" aria-pressed="${selectedItem?.id===item.id}"><img src="/assets/approved-icon-user-round.svg" alt=""><span><strong>${esc(item.actorName||'通知中未提供昵称')}</strong><span>${esc(item.commentText||item.originalCommentReason||'通知未提供原文')}</span></span><small>${item.observedAt?'保存于 '+esc(item.observedAt):''}</small></button>`).join('')||(!u.busy?'<p>当前账号和筛选范围没有已保存互动。</p>':'<p>正在读取本地记录…</p>')}</div><aside class="ii-detail"><h3>互动详情</h3>${selectedItem?renderItem(selectedItem,locked):'<p>选择一条已保存互动查看真实原文与来源。</p>'}</aside></div>
      <div class="ii-pager"><span>共 ${count(u.total)} 条 · 第 ${u.page} 页</span><button type="button" data-ii-page="-1" ${u.busy||u.page===1?'disabled':''}>上一页</button><button type="button" data-ii-page="1" ${u.busy||!u.hasMore?'disabled':''}>下一页</button></div>`;
    if(embedded){
      const content=dialog.querySelector('.modal-content'),list=content.querySelector('.ii-list'),tools=content.querySelector('.ii-tools'),detail=content.querySelector('.ii-detail');
      const heading=document.createElement('h3');heading.textContent='已保存互动';
      const scopeNotes=document.createElement('details');scopeNotes.className='ii-scope-details';scopeNotes.innerHTML='<summary>范围与读取说明</summary>';
      const notice=content.querySelector('.ii-notice');if(notice)scopeNotes.append(notice);content.querySelectorAll('.ii-message').forEach(node=>scopeNotes.append(node));if(u.pending)scopeNotes.open=true;
      list.prepend(heading);if(tools)heading.after(tools);list.append(scopeNotes);if(options.actions&&detail)detail.append(options.actions);
    }
    const content=dialog.querySelector('.modal-content');
    content.querySelectorAll('[data-ii-select]').forEach(b=>b.onclick=()=>{if(!valid())return;u.selectedId=b.dataset.iiSelect;paint();});
    content.querySelector('[data-ii-account]').onchange=e=>{u.account=e.target.value;u.items=[];u.stats=null;u.total=null;u.scopeKey='';u.actorId='';u.page=1;u.busy=false;restore();load();};
    for(const name of ['type','state'])content.querySelector('[data-ii-'+name+']').onchange=e=>{u[name]=e.target.value;u.page=1;load();};
    content.querySelector('[data-ii-refresh]').onclick=()=>load();
    content.querySelectorAll('[data-ii-page]').forEach(b=>b.onclick=()=>{u.page+=Number(b.dataset.iiPage);load();});
    content.querySelector('[data-ii-check]')?.addEventListener('click',()=>check());
    content.querySelector('[data-ii-retry]')?.addEventListener('click',()=>retry());
    content.querySelectorAll('[data-ii-set]').forEach(b=>b.onclick=()=>save(b.dataset.iiId,b.dataset.iiSet));
    content.querySelectorAll('[data-ii-source]').forEach(b=>b.onclick=()=>{if(!valid())return;const item=u.items.find(i=>i.id===b.dataset.iiSource),url=publicUrl(item?.sourceUrl);if(url)window.open(url,'_blank','noopener');});
    content.querySelectorAll('[data-ii-customer]').forEach(b=>b.onclick=()=>{if(!valid())return;const item=u.items.find(i=>i.id===b.dataset.iiCustomer);if(hash(item?.linkedCustomerId)&&typeof ctx.openInteractionCustomer==='function'){closeView();ctx.openInteractionCustomer(item.linkedCustomerId);}});
  }
  async function load(){
    u.viewId=crypto.randomUUID();const c=capture();
    if(!u.account||!current(c)){u.busy=false;u.message='请先明确选择当前门店的本人小红书账号。';paint();return;}
    u.busy=true;u.message='正在读取本地保存的互动，不请求平台。';paint();
    try{
      const body=accept(c,await ctx.interactionInboxAction('interaction_inbox_read',{storeId:c.storeId,accountId:c.accountId,platform:'xiaohongshu',viewId:c.viewId,type:u.type,state:u.state,page:u.page,pageSize:u.pageSize}));
      if(!body)return;u.items=body.items||[];u.stats=body.stats||null;u.total=body.total;u.hasMore=body.hasMore===true;u.message='只显示这个账号已保存的通知；缺原文的记录仍保留待核原因。';
    }catch(e){if(current(c))u.message=e.message;}
    finally{if(current(c)){u.busy=false;paint();}}
    if(current(c)&&u.pending&&!u.pending.invalid)await check();
  }
  function install(body,p){
    if(body.receipt?.state==='accepted'){
      if(!Number.isSafeInteger(body.receipt.version)||body.receipt.version!==p.request.expectedVersion+1
        ||body.receipt.originalResult?.id!==p.request.eventId||body.receipt.originalResult?.version!==body.receipt.version
        ||body.item.version<body.receipt.version)throw Error('原操作回执版本不完整，继续保留核对断点。');
      // Historical originalResult never wins over the current authoritative item.
      u.items=u.items.map(i=>i.id===body.item.id?body.item:i);
      if(!remember(p.base,null))throw Error('原操作已确认，但本机核对标记暂未清理，请继续按原编号核对。');
      u.pending=null;u.notFound=false;u.message='原操作已确认，当前记录使用最新状态。';
    }else if(body.receipt?.state==='not_found'){
      u.notFound=true;u.message='暂未查到原回执，核对断点仍保留。可明确按原操作重试，沿用原编号、原版本和全部原参数；不会新建编号。';
    }else throw Error('处理结果仍待核对，原操作编号已保留。');
  }
  async function check(){
    if(!u.pending||u.pending.invalid||u.busy)return;
    const p=u.pending,c=capture();u.busy=true;paint();
    try{
      if(!await verifyPending(p,c))return;
      const response=await ctx.interactionInboxAction('interaction_inbox_request_read',{storeId:c.storeId,accountId:c.accountId,platform:'xiaohongshu',viewId:c.viewId,eventId:p.request.eventId,requestId:p.request.requestId});
      const body=accept(c,response,p);if(body)install(body,p);
    }catch(e){if(current(c))u.message=e.message;}
    finally{if(current(c)){u.busy=false;paint();}}
    if(current(c)&&!u.pending)await load();
  }
  async function send(p,c){
    u.busy=true;u.message='正在保存本地处理状态…';paint();
    try{
      const response=await ctx.interactionInboxAction('interaction_inbox_state_save',{...p.request});
      if(p.request.viewId===c.viewId){const body=accept(c,response,p);if(body)install(body,p);}
    }catch(e){if(current(c)){if(e.mutationCommitted===false&&remember(p.base,null)){u.pending=null;u.notFound=false;u.message='本次处理未提交：'+e.message+'。请刷新当前状态后再决定。';}else u.message='处理结果待核对：'+e.message;}}
    finally{if(current(c)){u.busy=false;paint();}}
  }
  async function save(eventId,target){
    if(u.busy||u.pending||!actions.has(target))return;
    const item=u.items.find(i=>i.id===eventId),c=capture();if(!current(c)||!item||!hash(u.scopeKey)||!u.actorId)return;
    const p={base:c.base,scopeKey:u.scopeKey,actorId:u.actorId,request:{storeId:c.storeId,accountId:c.accountId,platform:'xiaohongshu',viewId:c.viewId,eventId,eventDigest:item.eventDigest,expectedVersion:item.version,state:target,requestId:crypto.randomUUID()}};
    if(pendingFrom(c.base)){restore();u.message='本账号仍有原操作待核对。';paint();return;}
    u.busy=true;paint();
    try{p.requestDigest=await requestDigest(p.request);}catch{if(current(c)){u.busy=false;u.message='本机无法核对原操作参数，本次没有提交。';paint();}return;}
    if(!current(c))return;
    if(!remember(c.base,p)){u.busy=false;u.message='无法保存本机核对断点，本次没有提交；请恢复本机存储后再试。';paint();return;}
    u.pending=p;await send(p,c);if(current(c)&&!u.pending)await load();
  }
  async function retry(){
    if(!u.pending||!u.notFound||u.busy)return;
    const p=u.pending,c=capture();if(!current(c))return;
    u.busy=true;paint();
    try{if(!await verifyPending(p,c)){if(current(c)){u.busy=false;paint();}return;}}catch{if(current(c)){u.busy=false;u.message='本机原操作摘要暂不能核对，尚未重试。';paint();}return;}
    // Explicit user click only; exact stored payload, including original viewId.
    // A new-view reply is never installed; query current scope with the same key.
    await send(p,c);if(current(c)&&u.pending)await check();else if(current(c))await load();
  }
  restore();paint();if(u.account)load();
  return {close:closeView};
}
