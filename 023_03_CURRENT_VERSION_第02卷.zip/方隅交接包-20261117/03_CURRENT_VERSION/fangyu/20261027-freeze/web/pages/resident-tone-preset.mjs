// Six user-written references; examples are wording references, never account facts.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const RESIDENT_PRESET_ID='resident_seeding_v1';
export const residentReferences=Object.freeze(['宝宝你来看看方隅呗','一房的话你去方隅呗','宝宝你可以看看方隅啊','宝宝你看看古北方隅呗','宝宝你看看方隅呗','宝宝你要租吗？我是租户，有积分的啊']);
export const residentAssistanceReferences=Object.freeze(['宝宝我住方隅，我能给你介绍便宜','宝宝一房的话你可以看一下方隅，我给你介绍能便宜','宝宝方隅带电梯的，你要了解一下不？可以加我，我帮你联系销售']);
export function residentPresetMarkup(preferences={},disabled=''){
 const selected=preferences.stylePresetId===RESIDENT_PRESET_ID;
 return `<section class="mt-card mt-resident-preset"><h3>可选表达预设</h3><label>表达参考<select data-mt-style-preset ${disabled}><option value="" ${selected?'':'selected'}>使用当前门店口吻</option><option value="${RESIDENT_PRESET_ID}" ${selected?'selected':''}>住户种草（校准中）</option></select></label><label>门店方案身份说明<input data-mt-identity maxlength="80" value="${esc(preferences.identity||'')}" placeholder="填写真实身份；实际回复账号仍按各自资料核对" ${disabled}></label><p>选择后只影响表达方式，已保存的账号身份和房源事实保持独立核对。</p><details ${selected?'open':''}><summary>查看本人写的六条参考</summary><ul>${residentReferences.map(v=>`<li>${esc(v)}</li>`).join('')}</ul><p>这些是用户本人提供的措辞参考，品牌字形已统一为“方隅”；不是已发送消息或逐客户定稿。用户另已确认本人推荐租住有积分；该事实不自动属于其他账号。“我是租户、有积分”仅适用于身份及事实确已核对的本人账号，不承诺统一返额。</p></details><details ${selected?'open':''}><summary>来自你的口述：本人介绍与帮约（方隅为规范写法）</summary><ul>${residentAssistanceReferences.map(v=>`<li>${esc(v)}</li>`).join('')}</ul><p>这三条来自你的真实口述，仍是校准中的表达参考；不是47位客户AI拟稿的逐条认可。住户身份、介绍优惠、电梯和联系销售等事实仅适用于小北本人已确认资料的账号，不能用于其他账号。按客户自己的价格、户型、楼层或设施问题接话，再说明本人能怎样帮助；首轮承接仍以当前账号开关为准。</p></details></section>`;
}
