import {renderDM,bindDM,syncDM} from './reply-dm.mjs';
import {renderConnected,bindConnected,syncConnected,preloadConnected} from './reply-connected.mjs';
export const sync=(state,ctx)=>state.replyChannel==='dm'?syncDM(state,ctx):syncConnected(state,ctx);
export const preload=(state,ctx)=>state.replyChannel==='dm'?undefined:preloadConnected(state,ctx);
const PEOPLE = [
  {id:'xiaoyu',name:'小雨',avatar:'portrait-woman-1.png',level:'超高意向',tone:'urgent',comment:'下个月入住，预算3500左右，周末能看房吗？',time:'今天 10:24',post:'gubei',draft:'你好，周末可以安排看房。\n你方便上午还是下午？'},
  {id:'chen',name:'陈先生',avatar:'portrait-man-1.png',level:'高意向',tone:'high',comment:'想在古北找一居室，最好近地铁。',time:'昨天 16:20',post:'gubei',draft:'你好，我们有近地铁的一居室。\n你预计什么时候入住？'},
  {id:'lin',name:'芝士奶盖',avatar:'portrait-woman-2.png',level:'中意向',tone:'medium',comment:'九号线附近有没有精装一居？预算3000左右。',time:'昨天 14:08',post:'commute',draft:'你好，九号线附近有精装一居可选。\n你方便说一下预计入住时间吗？'},
  {id:'zhou',name:'糯米团子',avatar:'portrait-dog.png',level:'中意向',tone:'medium',comment:'可以养宠物吗？两居大概什么价格？',time:'10-13 11:36',post:'commute',draft:'你好，部分房源可以养宠物。\n你想了解哪个区域的两居呢？'},
  {id:'anna',name:'安安',avatar:'portrait-woman-2.png',level:'高意向',tone:'high',comment:'周六下午方便看一下房间吗？',time:'10-12 15:20',post:'gubei',draft:'你好，周六下午可以安排，已为你留好时间。'}
];
const POSTS = {
  gubei:{title:'上海长宁古北求租',count:19,image:'sidebar-approved-photo.png',channel:'小红书'},
  commute:{title:'通勤九号线租房',count:8,image:'fy-login-apartment-photo.webp',channel:'小红书'}
};
const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = (name, cls='') => `<img class="rp-icon ${cls}" src="/assets/${name}" alt="" aria-hidden="true">`;
const badge = person => `<span class="rp-badge rp-${person.tone}">${person.level}</span>`;
const LONG_COMMENT='下个月和朋友一起搬到上海，想在长宁古北附近找一间有独立厨房和卫生间的一居室，预算3500元左右，希望离地铁站步行十分钟以内。我们有一只很安静的猫，平时都在附近上班，想了解水电费、押金和最短租期。这个周末可以安排看房吗？如果下午方便，我们可以一起过来，想先看看采光和收纳空间。';
function data(state){
  state.reply ??= {};
  const value=state.reply;
  const defaults={tab:'pending',groupBy:'post',query:'',selectedId:'xiaoyu',identity:'租房顾问',tone:'亲切',draft:PEOPLE[0].draft,evidenceOpen:false,sentIds:['anna'],savedDrafts:{},collapsedGroups:[]};
  for(const [key,item] of Object.entries(defaults)) if(value[key]===undefined)value[key]=item;
  if(state.selectedCustomer){value.selectedId=state.selectedCustomer==='rain'?'xiaoyu':state.selectedCustomer;value.draft=value.savedDrafts[value.selectedId]??(PEOPLE.find(p=>p.id===value.selectedId)||PEOPLE[0]).draft;delete state.selectedCustomer;}
  return value;
}
function visible(s){
  const query=s.query.trim().toLowerCase();
  return PEOPLE.filter(p=>(s.tab==='all'||(s.tab==='replied' ? s.sentIds.includes(p.id):!s.sentIds.includes(p.id)))&&(!query||`${p.name}${p.comment}${POSTS[p.post].title}${p.level}`.toLowerCase().includes(query)));
}
function personRow(p,s){
  const sent=s.sentIds.includes(p.id);
  return `<button type="button" class="rp-comment ${s.selectedId===p.id?'is-selected':''}" data-reply-person="${p.id}" aria-pressed="${s.selectedId===p.id}"><img class="rp-avatar" src="/assets/${p.avatar}" alt="${p.name}的示例头像"><span class="rp-comment-copy"><strong>${p.name}</strong><span>${p.comment}</span></span>${badge(p)}<span class="rp-status ${sent?'is-replied':''}">${sent?'已回复':'未回复'}</span><time>${p.time}</time></button>`;
}
function sourceGroup(key,people,s){
  const post=POSTS[key],collapsed=s.collapsedGroups.includes(key);
  return `<section class="rp-post rp-post-${key} ${people.length===2?'rp-two-comments':''} ${collapsed?'is-collapsed':''}"><div class="rp-post-heading"><img class="rp-post-thumbnail ${key==='commute'?'rp-thumb-room':''}" src="/assets/${post.image}" alt="${post.title}的示例房源照片"><div class="rp-post-name"><div><strong>${post.title}</strong><button type="button" class="rp-icon-button" data-reply-source="${key}" aria-label="查看${post.title}源帖">${icon('tabler-external-link.svg')}</button></div><span><span class="rp-channel-mark">小</span>${post.channel}<i>·</i>${post.count} 条评论</span></div><button type="button" class="rp-icon-button rp-collapse ${collapsed?'is-closed':''}" data-reply-collapse="${key}" aria-label="${collapsed?'展开':'收起'}${post.title}" aria-expanded="${!collapsed}">${icon('tabler-chevron-down.svg')}</button></div>${collapsed?'':`<div class="rp-comment-list">${people.map(p=>personRow(p,s)).join('')}</div>`}</section>`;
}
function grouped(people,s){
  if(s.groupBy==='post')return Object.keys(POSTS).map(key=>{const list=people.filter(p=>p.post===key);return list.length?sourceGroup(key,list,s):'';}).join('');
  let list=[...people];
  if(s.groupBy==='intent')list.sort((a,b)=>['urgent','high','medium'].indexOf(a.tone)-['urgent','high','medium'].indexOf(b.tone));
  if(s.groupBy==='time')list.sort((a,b)=>PEOPLE.indexOf(a)-PEOPLE.indexOf(b));
  return `<section class="rp-post rp-flat-post"><div class="rp-flat-title">${s.groupBy==='intent'?'按意向查看':'按时间查看'}<span>${list.length} 条评论</span></div>${list.map(p=>personRow(p,s)).join('')}</section>`;
}
function stateScreen(scenario,s){
  const info={empty:['fy-state-01-empty-customers.png','暂时没有待处理评论','新的意向评论会在这里集中显示。'],loading:['fy-state-04-loading.png','正在整理意向评论','稍等片刻，评论与回复记录即将准备好。'],error:['fy-state-03-error.png','评论暂时没有加载出来','可以重新试一次，已保存的草稿仍会保留。']}[scenario];
  return `<div class="reply-page"><div class="rp-toolbar"><div class="rp-tabs" role="tablist" aria-label="回复状态">${[['pending','待处理'],['replied','已回复'],['all','全部']].map(([id,label])=>`<button type="button" role="tab" aria-selected="${s.tab===id}" class="rp-tab ${s.tab===id?'is-active':''}" data-reply-tab="${id}">${label}<span>0</span></button>`).join('')}</div><label class="rp-search">${icon('fy-icon-07-search.png')}<input id="reply-search" type="search" data-reply-search value="${esc(s.query)}" placeholder="搜索评论或用户名…" aria-label="搜索评论或用户名"></label></div><div class="rp-state-screen" role="status"><img src="/assets/${info[0]}" alt=""><h2>${info[1]}</h2><p>${info[2]}</p>${scenario==='error'?'<button type="button" class="rp-state-retry" data-reply-retry>重新加载</button>':scenario==='loading'?'<span class="rp-state-caption">正在加载…</span>':''}</div></div>`;
}
export function render(state){
  if(state.connection!=='preview')return `<button type="button" class="rp-text-link" data-customer-followup-open>客户回复</button><details class="rp-channel-menu"><summary>${state.replyChannel==='dm'?'私信':'评论回复'}<img src="/assets/tabler-chevron-down.svg" alt=""></summary><div class="rp-tabs" role="tablist" aria-label="回复通道"><button type="button" class="rp-tab ${state.replyChannel!=='dm'?'is-active':''}" data-reply-channel="comment" aria-selected="${state.replyChannel!=='dm'}">评论回复</button><button type="button" class="rp-tab ${state.replyChannel==='dm'?'is-active':''}" data-reply-channel="dm" aria-selected="${state.replyChannel==='dm'}">私信</button></div></details>${state.replyChannel==='dm'?renderDM(state):renderConnected(state)}`;
  const s=data(state);
  if(['empty','loading','error'].includes(state.scenario))return stateScreen(state.scenario,s);
  const people=visible(s).map(p=>state.scenario==='long'&&p.id===s.selectedId?{...p,comment:LONG_COMMENT}:p);
  const selected=PEOPLE.find(item=>item.id===s.selectedId)||PEOPLE[0],p=state.scenario==='long'?{...selected,comment:LONG_COMMENT}:selected;
  return `<div class="reply-page"><div class="rp-toolbar"><div class="rp-tabs" role="tablist" aria-label="回复状态">${[['pending','待处理',12-s.sentIds.filter(id=>id!=='anna').length],['replied','已回复',9+s.sentIds.filter(id=>id!=='anna').length],['all','全部',128]].map(([id,label,count])=>`<button type="button" role="tab" aria-selected="${s.tab===id}" class="rp-tab ${s.tab===id?'is-active':''}" data-reply-tab="${id}">${label}<span>${count}</span></button>`).join('')}</div><label class="rp-group"><span class="sr-only">排列方式</span><select data-reply-group><option value="post" ${s.groupBy==='post'?'selected':''}>按帖子</option><option value="intent" ${s.groupBy==='intent'?'selected':''}>按意向</option><option value="time" ${s.groupBy==='time'?'selected':''}>按时间</option></select>${icon('tabler-chevron-down.svg')}</label><label class="rp-search">${icon('fy-icon-07-search.png')}<input id="reply-search" type="search" data-reply-search value="${esc(s.query)}" placeholder="搜索评论或用户名…" aria-label="搜索评论或用户名"></label></div><div class="rp-workspace"><div class="rp-posts">${people.length?grouped(people,s):'<div class="rp-empty"><strong>没有找到相关评论</strong><span>试试其他关键词，或查看全部评论。</span></div>'}</div><aside class="rp-editor" aria-label="回复编辑"><div class="rp-person-summary"><img class="rp-detail-avatar" src="/assets/${p.avatar}" alt="${p.name}的示例头像"><div class="rp-detail-copy"><div class="rp-person-title"><strong>${p.name}</strong>${badge(p)}<button type="button" class="rp-text-link rp-source-link" data-reply-source="${p.post}">查看源帖 ${icon('tabler-external-link.svg')}</button></div><p>${p.comment}</p></div></div><button type="button" class="rp-evidence-toggle" data-reply-evidence aria-expanded="${s.evidenceOpen}">判断依据与记录 ${icon('tabler-chevron-down.svg',s.evidenceOpen?'is-open':'')}</button>${s.evidenceOpen?`<div class="rp-evidence"><span>租房需求明确，已提供预算与入住时间。</span><span>来源：${POSTS[p.post].title} · ${p.time}</span>${s.savedDrafts[p.id]?'<span>已保存本次示例草稿</span>':''}</div>`:''}<div class="rp-persona-controls"><label>身份<select data-reply-identity>${['租房顾问','门店管家','公寓主理人'].map(v=>`<option ${s.identity===v?'selected':''}>${v}</option>`).join('')}</select></label><label>口吻<select data-reply-tone>${['亲切','专业','简洁'].map(v=>`<option ${s.tone===v?'selected':''}>${v}</option>`).join('')}</select></label></div><div class="rp-composer"><textarea data-reply-draft aria-label="回复草稿" maxlength="200" placeholder="写下你想回复的内容…">${esc(s.draft)}</textarea><span class="rp-char-count"><span data-reply-char-count>${s.draft.length}</span> / 200</span></div><div class="rp-draft-tools"><button type="button" data-reply-suggest>${icon('fy-icon-62-ai.png')}建议回复</button><button type="button" data-reply-copy>${icon('fy-icon-25-copy.png')}复制</button>${s.savedDrafts[p.id]?'<span class="rp-saved">草稿已保存</span>':''}</div><div class="rp-editor-actions"><button type="button" class="rp-primary" data-reply-confirm ${!s.draft.trim()?'disabled':''}>${icon('fy-icon-23-send.png')}确认回复</button><button type="button" class="rp-secondary" data-reply-save>保存草稿</button></div></aside></div></div>`;
}
function showSource(ctx,key){
  const post=POSTS[key]||POSTS.gubei;
  ctx.modal({title:'源帖预览',html:`<div class="rp-source-modal"><img src="/assets/${post.image}" alt="示例公寓房源"><h3>${post.title}</h3><p>${post.channel} · ${post.count}条评论</p><p>想在长宁附近找一间温暖的小家，希望近地铁，生活便利。有合适的房源欢迎交流。</p><small>此处展示界面演示用源帖。</small></div>`,confirmLabel:'知道了'});
}
export function bind(root,ctx){
  if(ctx.state.connection!=='preview'){root.querySelector('[data-customer-followup-open]')?.addEventListener('click',()=>ctx.openCustomerFollowup?.());root.querySelectorAll('[data-reply-channel]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{state.replyChannel=el.dataset.replyChannel;})));return ctx.state.replyChannel==='dm'?bindDM(root,ctx):bindConnected(root,ctx);}
  const s=data(ctx.state);
  root.querySelector('[data-reply-retry]')?.addEventListener('click',()=>{ctx.update(state=>{state.scenario='normal';});ctx.toast('意向评论已重新加载');});
  root.querySelectorAll('[data-reply-tab]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state);v.tab=el.dataset.replyTab;const list=visible(v);if(list.length&&!list.some(p=>p.id===v.selectedId)){v.selectedId=list[0].id;v.draft=v.savedDrafts[list[0].id]??list[0].draft;}})));
  root.querySelector('[data-reply-group]')?.addEventListener('change',e=>ctx.update(state=>{data(state).groupBy=e.target.value;}));
  const search=root.querySelector('[data-reply-search]');
  let composing=false;
  search?.addEventListener('compositionstart',()=>{composing=true;});
  search?.addEventListener('input',e=>{
    const value=e.target.value;
    if(composing||e.isComposing){s.query=value;return;}
    if(s.query===value)return;
    ctx.update(state=>{data(state).query=value;});
  });
  search?.addEventListener('compositionend',e=>{composing=false;const value=e.target.value;ctx.update(state=>{data(state).query=value;});});
  root.querySelectorAll('[data-reply-person]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state),p=PEOPLE.find(item=>item.id===el.dataset.replyPerson);v.selectedId=p.id;v.draft=v.savedDrafts[p.id]??p.draft;v.evidenceOpen=false;})));
  root.querySelectorAll('[data-reply-source]').forEach(el=>el.addEventListener('click',()=>showSource(ctx,el.dataset.replySource)));
  root.querySelectorAll('[data-reply-collapse]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state),key=el.dataset.replyCollapse;v.collapsedGroups=v.collapsedGroups.includes(key)?v.collapsedGroups.filter(id=>id!==key):[...v.collapsedGroups,key];})));
  root.querySelector('[data-reply-evidence]')?.addEventListener('click',()=>ctx.update(state=>{data(state).evidenceOpen=!data(state).evidenceOpen;}));
  root.querySelector('[data-reply-identity]')?.addEventListener('change',e=>{s.identity=e.target.value;});
  root.querySelector('[data-reply-tone]')?.addEventListener('change',e=>{s.tone=e.target.value;});
  root.querySelector('[data-reply-draft]')?.addEventListener('input',e=>{s.draft=e.target.value;const count=root.querySelector('[data-reply-char-count]');if(count)count.textContent=s.draft.length;const button=root.querySelector('[data-reply-confirm]');if(button)button.disabled=!s.draft.trim();});
  root.querySelector('[data-reply-suggest]')?.addEventListener('click',()=>ctx.update(state=>{const v=data(state),p=PEOPLE.find(item=>item.id===v.selectedId)||PEOPLE[0];v.draft=v.tone==='专业'?`您好，已了解您的租房需求。\n方便确认一下您的入住时间和看房安排吗？`:v.tone==='简洁'?'你好，有合适房源。\n你方便什么时候看房？':p.draft;}));
  root.querySelector('[data-reply-copy]')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(s.draft);ctx.toast('回复内容已复制');}catch{const input=root.querySelector('[data-reply-draft]');input?.focus();input?.select();ctx.toast('已选中回复内容，可直接复制');}});
  root.querySelector('[data-reply-save]')?.addEventListener('click',()=>{ctx.update(state=>{const v=data(state);v.savedDrafts[v.selectedId]=v.draft;});ctx.toast('示例草稿已保存');});
  root.querySelector('[data-reply-confirm]')?.addEventListener('click',()=>{if(!s.draft.trim())return;const p=PEOPLE.find(item=>item.id===s.selectedId)||PEOPLE[0];ctx.modal({title:'确认回复',html:`<p>向 <strong>${p.name}</strong> 回复：</p><blockquote class="rp-confirm-quote">${esc(s.draft).replace(/\n/g,'<br>')}</blockquote><p class="rp-modal-note">本次为界面演示，确认后更新示例回复状态。</p>`,confirmLabel:'确认演示回复',onConfirm:()=>{ctx.update(state=>{const v=data(state);if(!v.sentIds.includes(p.id))v.sentIds.push(p.id);state.customers??={};state.customers.repliedIds??=[];if(!state.customers.repliedIds.includes(p.id))state.customers.repliedIds.push(p.id);});ctx.toast('示例回复已完成');}});});
}
