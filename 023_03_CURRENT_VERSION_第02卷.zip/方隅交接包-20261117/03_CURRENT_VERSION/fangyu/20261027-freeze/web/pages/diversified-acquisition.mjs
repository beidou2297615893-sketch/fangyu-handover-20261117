import {browserFirstEnabled,currentBrowserContext,browserUI,browserViewState} from '../browser-acquisition.mjs';
import {openInteractionInbox} from './interaction-inbox.mjs';
import * as acquire from './acquire.mjs';
import {openLivestream} from './livestream-acquisition.mjs';
import {sourceSelection,openAcquisitionSources} from './acquisition-source.mjs';
import {senderName} from './reply-account.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const kinds={note_links:['指定笔记','从你指定的笔记读取可见评论。'],profiles:['博主主页','从你指定博主的可见笔记读取评论。'],own_interactions:['我的互动','查看本人账号可见的评论与互动。']};
const label=kind=>kind==='keywords'||!kind?'关键词搜索':kinds[kind]?.[0]||'已保存来源';
const scope=s=>JSON.stringify([s.authEpoch||0,s.session?.user?.tenant_id||'',s.user,s.session?.user?.role||'',s.storeId,s.activePlatform||'xiaohongshu',s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId||'']);
const accounts=s=>browserFirstEnabled(s)?(currentBrowserContext(s)?.resolvedAccount?[{...currentBrowserContext(s).resolvedAccount,status:'ready'}]:[]):(s.platform?.accounts||[]).filter(a=>a.platform===(s.activePlatform||'xiaohongshu'));
const live=s=>browserFirstEnabled(s)?currentBrowserContext(s)?.currentTask||{}:s.platform?.acquisition||{};
const unknown=s=>browserFirstEnabled(s)?Boolean(browserUI(s).unknown||browserUI(s).intent?.unknown||browserUI(s).flight):Boolean(s.acquisitionAttempt?.unconfirmed||s.pendingAction?.unconfirmed||['submitted','unconfirmed'].includes(s.platform?.lastRequest?.state));
const running=s=>['running','queued','pausing','resuming','stopping'].includes(live(s).status);
function chosen(s){const v=sourceSelection(s);return v&&v.selectedFor==='diversified'&&v.selectedAuthEpoch===(s.authEpoch||0)&&kinds[v.source?.kind]?v:null;}
function canStart(s,choice){return Boolean(s.connection==='connected'&&s.session&&s.storeId&&!s.busy&&!s.connectionRecovering&&!s.platformError&&!s.sourceInteractionPending&&!unknown(s)&&!running(s)&&live(s).canStart!==false&&choice?.preview?.canStart===true&&choice.previewDigest&&accounts(s).some(a=>a.id===choice.accountId&&a.status==='ready'));}
function currentTask(s){const a=live(s),t=a.taskScope;if(!a.taskId)return '<p class="da-muted">当前门店暂无采集任务。</p>';return `<p><strong>当前任务：${esc(label(t?.source?.kind))}</strong><span>${esc(accounts(s).find(a=>a.id===t?.accountId)?.name||'原任务账号')} · ${esc({running:'正在采集',paused:'已暂停',completed:'已结束',stopped:'已停止',failed:'已中断'}[a.status]||'状态待核对')}</span></p><p class="da-muted">切换页面或选择下一次来源，不会改变这个任务的方式、账号和断点。</p>`;}
function choose(ctx,kind){
  if(ctx.state.busy||unknown(ctx.state)||ctx.state.sourceInteractionPending)return ctx.toast('请先核对原操作结果；当前任务与草稿均已保留。');
  return openAcquisitionSources(ctx,{kinds:Object.keys(kinds),initialKind:kind,sourceDraft:ctx.state.acquire?.referenceSourceDraft?.[kind],expectedPage:'diversified',selectionContext:{selectedFor:'diversified',selectedAuthEpoch:ctx.state.authEpoch||0}});
}
export function render(s){
  const v=chosen(s),a=live(s),account=browserFirstEnabled(s)?currentBrowserContext(s)?.resolvedAccount:accounts(s).find(a=>a.id===(v?.accountId||s.platformAccountSelections?.[s.activePlatform||'xiaohongshu'])),kind=s.acquire?.referenceKind||v?.source?.kind||'note_links',blocked=unknown(s)||s.sourceInteractionPending;
  const drafts=s.acquire?.referenceSourceDraft||{},value=drafts[kind]??(kind==='profiles'?v?.source?.profiles?.join('\n'):v?.source?.links?.join('\n'))??'';
  const title=kind==='profiles'?'博主主页链接':kind==='own_interactions'?'本人账号互动':kind==='livestream'?'当前直播间':'笔记链接';
  return `<link rel="stylesheet" href="/reference-acquisition.css?ref-v=10"><div class="acquire-page da-page dr-reference" data-page-diversified data-reference-kind="${kind}"><div class="dr-store"><span>门店 · 平台</span><div class="dr-store-value" role="note" aria-label="当前授权门店与平台"><img src="/assets/tabler-upgrade-calendar.svg" alt="">${esc(s.store||'当前门店未返回')} · ${kind==='livestream'||s.activePlatform==='douyin'?'抖音':'小红书'}</div></div><div class="dr-tab-row"><nav aria-label="获客来源">${[['note_links','指定笔记','tabler-upgrade-file.svg'],['profiles','博主主页','tabler-upgrade-user.svg'],['own_interactions','我的互动','icon-message-square-more.svg'],['livestream','直播间','reference-acquire-icon-video.svg']].map(([k,n,i])=>`<button type="button" data-reference-kind="${k}" aria-pressed="${kind===k}"><img src="/assets/${i}" alt="">${n}</button>`).join('')}</nav><button type="button" data-diverse-keywords>返回关键词获客 <img src="/assets/tabler-chevron-down.svg" alt=""></button></div>${kind==='livestream'?`<section class="dr-live-workspace"><div data-reference-livestream></div></section>`:kind==='own_interactions'?`<section class="dr-interaction-workspace"><div data-reference-interactions></div><div class="dr-interaction-actions"><button type="button" data-diverse-configure>更多读取设置</button><button type="button" data-diverse-start ${canStart(s,v)&&v?.source.kind===kind?'':'disabled'}>核对并读取</button></div></section>`:`<section class="dr-workspace"><div class="dr-source"><h2>${title}</h2>${kind==='own_interactions'?`<p>使用当前账号本人可见的评论与互动。</p><button type="button" data-diverse-configure>选择互动类型与首次读取范围</button><p class="da-muted">已保存互动保留真实原文与来源；赞、收藏、关注不直接算作客户。</p>`:kind==='livestream'?`<p>选择本人已打开的直播窗口，核对账号后明确开始本轮。</p><button type="button" data-diverse-live>选择直播间</button>`:`<textarea data-reference-source rows="5" placeholder="${kind==='profiles'?'请输入小红书博主主页链接，每行一个':'请输入小红书笔记链接，每行一个'}">${esc(value)}</textarea><div class="dr-source-actions"><button type="button" data-diverse-configure>${kind==='profiles'?'添加主页':'导入链接'}</button><button type="button" data-diverse-saved>已保存来源</button><button type="button" data-diverse-configure>更多设置</button></div>`}</div><aside>${browserFirstEnabled(s)?`<label>当前网页账号<p role="note">${esc(account?.name||'请先核对网页登录')}</p></label>`:`<label>前台账号<button type="button" data-diverse-account><img src="/assets/tabler-upgrade-user.svg" alt="">${esc(account?.name||'选择读取账号')}<img src="/assets/tabler-chevron-down.svg" alt=""></button></label>`}<label>来源<p>${v&&v.source.kind===kind?esc(v.preview?.sourceCount||1)+' 个已核对来源':'尚未核对来源'}</p></label><label>读取范围<button type="button" data-diverse-configure>全部可见评论<img src="/assets/tabler-chevron-down.svg" alt=""></button></label><button type="button" class="acquire-start" data-diverse-start ${canStart(s,v)&&v?.source.kind===kind?'':'disabled'}>核对并开始</button></aside></section>`}<section class="dr-task"><span>${a.taskId?`原任务${{paused:'已暂停',running:'正在读取',completed:'已完成'}[a.status]||'状态待核对'} · 断点已保留`:'当前门店暂无采集任务'}</span>${a.canPause||(!browserFirstEnabled(s)&&a.canResume)?`<button type="button" ${browserFirstEnabled(s)?'data-browser-pause':'data-acquire-pause'} ${s.busy?'disabled':''}>${a.canPause?'暂停原任务':'继续原任务'}</button>`:''}<details><summary>更多</summary><div>${currentTask(s)}${acquire.renderAcquisitionProgress(browserFirstEnabled(s)?browserViewState(s):s,a)}${!browserFirstEnabled(s)&&acquire.freshAcquisitionCapture?.(s)?'<button type="button" data-diverse-fresh>保留旧批，开始新一轮</button>':''}</div></details></section>${blocked?'<p role="status">上次操作正在确认，请稍候。</p>':''}${s.platformError?`<p role="alert">${esc(s.platformError)}</p>`:''}</div>`;
}
export function bind(root,ctx){
  const cleanup=acquire.bind(root,ctx);
  const inboxHost=root.querySelector('[data-reference-interactions]');
  const liveHost=root.querySelector('[data-reference-livestream]');
  const inlineLive=liveHost?openLivestream(ctx,{host:liveHost}):null;
  const inbox=inboxHost?openInteractionInbox(ctx,(browserFirstEnabled(ctx.state)?currentBrowserContext(ctx.state)?.resolvedAccount?.id:ctx.state.platformAccountSelections?.[ctx.state.activePlatform||'xiaohongshu'])||'',{host:inboxHost,actions:root.querySelector('.dr-interaction-actions')}):null;
  root.querySelectorAll('[data-reference-kind]').forEach(b=>b.onclick=()=>ctx.update(s=>{s.acquire??={};s.acquire.referenceKind=b.dataset.referenceKind;}));
  root.querySelector('[data-reference-source]')?.addEventListener('input',e=>{ctx.state.acquire.referenceSourceDraft??={};ctx.state.acquire.referenceSourceDraft[ctx.state.acquire.referenceKind||chosen(ctx.state)?.source.kind||'note_links']=e.target.value;});
  root.querySelector('[data-diverse-keywords]')?.addEventListener('click',()=>ctx.navigate('acquire'));
  root.querySelector('[data-diverse-account]')?.addEventListener('click',()=>choose(ctx,ctx.state.acquire?.referenceKind||chosen(ctx.state)?.source.kind||'note_links'));
  root.querySelector('[data-diverse-saved]')?.addEventListener('click',()=>choose(ctx,ctx.state.acquire?.referenceKind||'note_links'));
  root.querySelector('[data-diverse-live]')?.addEventListener('click',()=>openLivestream(ctx));
  root.querySelectorAll('[data-diverse-kind]').forEach(button=>button.addEventListener('click',()=>choose(ctx,button.dataset.diverseKind)));
  root.querySelectorAll('[data-diverse-configure]').forEach(b=>b.addEventListener('click',()=>choose(ctx,ctx.state.acquire?.referenceKind||chosen(ctx.state)?.source?.kind)));
  root.querySelector('[data-diverse-fresh]')?.addEventListener('click',()=>acquire.openFreshAcquisition?.(ctx));
  root.querySelector('[data-diverse-start]')?.addEventListener('click',()=>{
    const s=ctx.state,v=chosen(s);if(browserFirstEnabled(s)){if(canStart(s,v))return ctx.actions.browserAcquisitionStart();return;}if(!canStart(s,v)||ctx.actions.hasUnconfirmed?.())return;
    const expected=scope(s),stamp=JSON.stringify(v),account=accounts(s).find(a=>a.id===v.accountId);
    ctx.modal({title:'确认开始多样化获客',html:`<p>本次方式：<strong>${esc(label(v.source.kind))}</strong></p><p>采集账号：<strong>${esc(senderName(account))}</strong></p><p>仅使用已核对的来源与评论范围，新建任务后以真实回执为准。</p>`,confirmLabel:'确认开始',onConfirm:()=>{
      const current=chosen(s);if(s.page!=='diversified'||scope(s)!==expected||JSON.stringify(current)!==stamp||!canStart(s,current)||ctx.actions.hasUnconfirmed?.()){ctx.toast('门店、账号、来源或原任务状态已变化，请重新核对。');return false;}
      return ctx.actions.startAcquisition?.({sourceKind:current.source.kind});
    }});
  });
  return ()=>{inbox?.close();inlineLive?.close();cleanup?.();};
}
// Compose the original page so independently reviewed acquire/fresh behavior is retained.
export const keywordPage={
 render(s){
  if(browserFirstEnabled(s))return acquire.render(s);
  const selected=sourceSelection(s);
  return `<div class="da-keyword-context" role="status"><strong>本页使用关键词搜索</strong>${selected?.source?`<span>另已选“${esc(label(selected.source.kind))}”，本页开始前请明确改用关键词；可在下方选择关键词采集账号。</span>`:''}</div>`+acquire.render(s);
 },
 bind(root,ctx){
  if(browserFirstEnabled(ctx.state))return acquire.bind(root,ctx);
  const s=ctx.state,button=root.querySelector('[data-acquire-start]');
  if(sourceSelection(s)?.source&&!unknown(s)&&!running(s)&&button&&!button.disabled)button.querySelector('span').textContent='确认关键词获客';
  button?.addEventListener('click',event=>{
    if(s.connection==='preview'||unknown(s))return;
    if(live(s).canResume&&!live(s).taskScope?.source&&!sourceSelection(s)?.source)return;
    if(acquire.freshAcquisitionCapture?.(s))return;
    event.stopImmediatePropagation();
    if(s.busy||s.connectionRecovering||s.platformError||running(s)||live(s).canStart===false||ctx.actions.hasUnconfirmed?.())return;
    const expected=scope(s),selection=sourceSelection(s),stamp=JSON.stringify(selection),accountId=s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId;
    ctx.modal({title:'确认使用关键词获客',html:'<p>本次使用当前门店的已选关键词和帖子时间范围。</p><p>此前多样化来源与正在执行任务不会被悄悄复用。新任务以确认后的真实回执为准。</p>',confirmLabel:'确认关键词获客',onConfirm:()=>{
      if(s.page!=='acquire'||scope(s)!==expected||s.busy||unknown(s)||running(s)||live(s).canStart===false||ctx.actions.hasUnconfirmed?.()||JSON.stringify(sourceSelection(s))!==stamp){ctx.toast('当前范围或任务状态已变化，请重新确认。');return false;}
      ctx.update(state=>{state.acquire??={};state.acquire.sourceSelection=selection?{...selection,accountId,source:null,commentWindow:{mode:'all'},execution:{mode:'once'},preview:null,previewDigest:undefined}:null;});
      return ctx.actions.startAcquisition?.({sourceKind:'keywords'});
    }});
  },{capture:true});
  return acquire.bind(root,ctx);
 }
};
