import {unifiedIntentMarkup} from './unified-intent-view.mjs';
import {businessSection,validateBusinessDocument,downloadBusinessFile} from './business-rules.mjs';
import {renderTaskExecution} from './acquire.mjs';
import {openKeywordEffect,canReadKeywordEffect} from './keyword-effect.mjs';
import {renderWorkflowSummary} from './workflow-summary.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scope=s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId,s.activePlatform||'xiaohongshu',s.session?.user?.role]);
function model(state){const key=scope(state);if(state.rulesPage?.scope!==key)state.rulesPage={scope:key,status:'idle',section:'words',tab:'current',query:'',openGroups:[],doc:null,error:''};return state.rulesPage;}
function wordRows(doc,openGroups=[]){
  const store=doc.stores.find(row=>row.name===doc.selectedStoreName)||doc.stores[0];
  const used=new Set(doc.activeSearch?.keywords||[]);
  const intro=`<h3>${esc(store.name)}的搜索词</h3><p class="br-execution-note">选中这家门店后自动使用本店词库。当前已纳入 ${used.size} 个搜索词，每批最多执行100个，后续批次接着轮换。资料词与当前启用词分开显示；使用范围以本店已确认规则为准。</p>`;
  return intro+doc.groups.map(group=>{
    const guide=doc.categoryGuide.find(row=>row.name===group),terms=store.terms.filter(row=>row.group===group);
    return `<details class="br-word-row" data-rules-group="${esc(group)}" ${openGroups.includes(group)?'open':''}><summary><strong>${esc(group)}</strong><span>${terms.length} 个词</span><span class="br-open-label">展开</span><span class="br-close-label">收起</span></summary><p>${esc(guide?.meaning||'')}</p><div class="br-word-tags">${terms.map(term=>`<span title="${esc(term.origin)}">${esc(term.word)}<small>${term.pendingSource?'资料待核':used.has(term.word)?'已纳入本店搜索':'资料词'}</small></span>`).join('')||'<p>这一类暂没有搜索词。</p>'}</div></details>`;
  }).join('');
}
export function render(state){
  const v=model(state),doc=v.doc;let body=doc?businessSection(doc,v.tab==='meeting'?'meeting':v.section,doc.selectedStoreName):`<div class="br-empty"><p>${esc(v.error||'正在读取本店获客规则…')}</p>${v.status==='error'?'<button type="button" data-rules-reload>重新读取</button>':''}</div>`;
  if(doc&&v.tab==='current'&&v.section==='words')body=wordRows(doc,v.openGroups||[]);
  const search=state.catalog?.search?.find(x=>x.id===state.selection?.searchPresetId),intent=state.catalog?.intent?.find(x=>x.id===state.selection?.intentPresetId),keywords=Array.isArray(doc?.activeSearch?.keywords)?doc.activeSearch.keywords:[];
  return `<div class="business-rules-page reference-rules"><link rel="stylesheet" href="/reference-content-management.css"><nav class="reference-rules-nav" aria-label="管理分类"><button type="button" data-reference-rules-nav="rules" aria-current="page">获客规则</button><button type="button" data-reference-rules-nav="tone">回复口吻</button><button type="button" data-reference-rules-nav="presets">门店预设</button><details><summary>更多管理<img src="/assets/reference-management-tabler-chevron-down.svg" alt=""></summary>${state.session?.user?.role==='admin'?'<button type="button" data-reference-rules-nav="aiModel">AI模型</button>':''}</details></nav><div class="br-store"><span>当前门店</span><strong class="reference-rules-store-readonly">${esc(state.store||'当前门店')}</strong></div><div class="reference-rules-columns"><section><header class="reference-rules-section-heading"><img src="/assets/approved-icon-search.svg" alt=""><div><h2>搜索方案</h2><p>查看当前门店已保存的搜索方向</p></div></header><div class="reference-rules-plan-grid">${state.catalog?.search?.length?state.catalog.search.map(x=>`<div class="reference-rules-plan ${search?.id===x.id?'is-current':''}">${search?.id===x.id?'<img src="/assets/reference-management-tabler-circle-check.svg" alt="当前方案">':''}<div><strong>${esc(x.name)}</strong><span>${search?search.id===x.id?'当前已保存':'未选用':'已保存方案待读取'}</span></div></div>`).join(''):'<div class="reference-rules-plan">当前搜索方案未读取</div>'}</div><div class="reference-rules-coverage"><h3>覆盖方向</h3><p>当前已启用的搜索词</p><div>${keywords.slice(0,3).map(word=>`<span>${esc(word)}</span>`).join('')||'<span>启用搜索词尚未读取</span>'}</div></div><details class="reference-rules-exclude"><summary>排除内容 <span>查看已确认的语境排除与保留规则</span></summary>${doc?businessSection(doc,'exclude',doc.selectedStoreName):'<p>规则尚未读取</p>'}</details></section><section><header class="reference-rules-section-heading"><img src="/assets/approved-icon-user-round.svg" alt=""><div><h2>客户判断</h2><p>查看当前门店已保存的意向方案</p></div></header><div class="reference-rules-plan-grid">${state.catalog?.intent?.length?state.catalog.intent.map(x=>`<div class="reference-rules-plan ${intent?.id===x.id?'is-current':''}">${intent?.id===x.id?'<img src="/assets/reference-management-tabler-circle-check.svg" alt="当前方案">':''}<div><strong>${esc(x.name)}</strong><span>${intent?intent.id===x.id?'当前已保存':'未选用':'已保存方案待读取'}</span></div></div>`).join(''):'<div class="reference-rules-plan">当前意向方案未读取</div>'}</div><div class="reference-rules-basis"><h3>判断依据</h3>${unifiedIntentMarkup(doc)}<details><summary>查看已确认与待核内容</summary>${doc?businessSection(doc,'intent',doc.selectedStoreName):'<p>规则尚未读取</p>'}</details></div><div class="reference-rules-budget"><h3>预算依据</h3><p>以本店已确认的判断依据为准；未核实的价格与口径不作承诺。</p><button type="button" data-reference-rules-full>查看规则依据</button></div></section></div><footer class="reference-rules-footer"><span>这里查看当前规则；方案调整请进入管理预设。</span><button type="button" data-rules-reload>重新读取</button><button type="button" class="primary" data-reference-rules-nav="presets">前往调整预设</button></footer><details class="br-advanced" data-reference-rules-source><summary>规则全文与来源</summary><nav class="reference-existing-platform-controls" aria-label="切换平台">${[['xiaohongshu','小红书'],['douyin','抖音']].map(([id,name])=>`<button type="button" data-reference-rules-platform="${id}" aria-pressed="${(state.activePlatform||'xiaohongshu')===id}" ${state.busy?'disabled':''}><img src="/assets/brand-${id}.svg" alt="">${name}</button>`).join('')}</nav><div class="br-tabs"><button type="button" data-rules-tab="current" aria-pressed="${v.tab==='current'}">已确认规则</button><button type="button" data-rules-tab="meeting" aria-pressed="${v.tab==='meeting'}">确认说明</button></div><nav class="br-sections" aria-label="规则内容">${[['words','搜索词'],['exclude','语境排除与保留'],['intent','年租意向']].map(([key,label])=>`<button type="button" data-rules-section="${key}" aria-pressed="${v.section===key&&v.tab==='current'}">${label}</button>`).join('')}</nav><label class="br-search"><img src="/assets/approved-icon-search.svg" alt=""><input data-rules-search type="search" value="${esc(v.query)}" placeholder="搜索本店规则" aria-label="搜索规则"></label><article class="br-content" data-rules-body>${body}</article><button type="button" data-keyword-effect ${canReadKeywordEffect(state)?'':'disabled'}>查看词效</button>${doc?.canExport?'<button type="button" data-rules-export>导出规则清单</button>':''}<p role="status">${esc(v.status==='exporting'?'正在导出规则…':v.error)}</p>${renderWorkflowSummary(state)}${renderTaskExecution(state,state.platform?.acquisition||{})}${state.session?.user?.role==='admin'?'<button type="button" data-rules-files>管理规则文件</button>':''}</details></div>`;
}
export async function preload(state,ctx,force=false){
  const v=model(state),key=v.scope;
  const current=()=>scope(state)===key&&state.rulesPage===v&&state.connection==='connected'&&Boolean(state.session);
  const redraw=()=>{if(current()&&state.page==='rules')ctx.update(()=>{});};
  if(!state.storeId){v.status='error';v.error='请先在获客页选择门店，再查看本店规则。';if(state.page==='rules')ctx.update(()=>{});return null;}
  if(!current())return null;
  if(v.flight)return v.flight;
  if(!force&&v.status==='ready')return v.doc;
  v.status='loading';v.error='';redraw();
  v.flight=(async()=>{
    try{const result=await ctx.readBusinessRules({storeId:state.storeId});if(!current())return null;
      if(result.actor?.username!==state.user||result.actor?.storeId!==state.storeId)throw Error('门店或账号已变化，请重新读取。');
      v.doc=validateBusinessDocument(result.businessReview);v.status='ready';return v.doc;
    }catch(error){if(current()){v.status='error';v.error=error.message;
      if(['AUTH_REQUIRED','STORE_FORBIDDEN','BUSINESS_RULES_FORBIDDEN'].includes(error.code)){v.doc=null;ctx.replyError?.(error);}
    }return null;}
    finally{if(current()){v.flight=null;redraw();}}
  })();
  return v.flight;
}
export function bind(root,ctx){
  root.querySelectorAll('[data-reference-rules-platform]').forEach(e=>e.addEventListener('click',()=>ctx.actions.switchPlatform(e.dataset.referenceRulesPlatform)));
  root.querySelectorAll('[data-reference-rules-nav]').forEach(e=>e.addEventListener('click',()=>ctx.actions.navigate(e.dataset.referenceRulesNav)));
  root.querySelector('[data-reference-rules-full]')?.addEventListener('click',()=>{const d=root.querySelector('[data-reference-rules-source]');if(d)d.open=true;});

  root.querySelector('[data-keyword-effect]')?.addEventListener('click',()=>openKeywordEffect(ctx));
  const state=ctx.state,v=model(state),key=v.scope,own=()=>state.page==='rules'&&scope(state)===key&&state.rulesPage===v;
  const redraw=()=>{if(own())ctx.update(()=>{});};
  const load=()=>preload(state,ctx,true);
  root.querySelector('.br-advanced')?.addEventListener('toggle',e=>{if(own()&&e.target.open)ctx.refreshAIRules?.();});
  root.querySelectorAll('[data-rules-section]').forEach(b=>b.addEventListener('click',()=>{if(own()){v.section=b.dataset.rulesSection;v.tab='current';v.query='';redraw();}}));
  root.querySelectorAll('[data-rules-tab]').forEach(b=>b.addEventListener('click',()=>{if(own()){v.tab=b.dataset.rulesTab;v.query='';redraw();}}));
  root.querySelector('[data-rules-reload]')?.addEventListener('click',load);
  root.querySelectorAll('[data-rules-group]').forEach(node=>node.addEventListener('toggle',()=>{if(!own()||v.query)return;const groups=new Set(v.openGroups||[]);if(node.open)groups.add(node.dataset.rulesGroup);else groups.delete(node.dataset.rulesGroup);v.openGroups=[...groups];}));
  root.querySelector('[data-rules-search]')?.addEventListener('input',e=>{v.query=e.target.value;const q=v.query.trim().toLocaleLowerCase();root.querySelectorAll('[data-rules-body] details,[data-rules-body] tbody tr,[data-rules-body] .br-word-row').forEach(node=>{node.hidden=Boolean(q&&!node.textContent.toLocaleLowerCase().includes(q));if(q&&node.tagName==='DETAILS'&&!node.hidden)node.open=true;});});
  root.querySelector('[data-rules-files]')?.addEventListener('click',()=>{if(own()&&state.session?.user?.role==='admin')ctx.openCentralRuleFiles();});
  root.querySelector('[data-rules-export]')?.addEventListener('click',async()=>{if(!own()||v.status==='exporting'||!v.doc?.canExport)return;v.status='exporting';v.error='';redraw();try{const result=await ctx.aiRulesExport({storeId:state.storeId,format:'html'});if(own()){downloadBusinessFile(result.file,'html');ctx.toast('规则已导出。');}}catch(error){if(own())v.error=error.message;}finally{if(own()){v.status='ready';redraw();}}});
  if(v.status==='idle')queueMicrotask(load);
  return ()=>{};
}
