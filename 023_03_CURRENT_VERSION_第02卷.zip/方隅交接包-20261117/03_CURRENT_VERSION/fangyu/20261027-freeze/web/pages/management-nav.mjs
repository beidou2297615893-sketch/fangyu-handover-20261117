/* Shared view navigation; page state and persistence stay with each page. */
export const renderManagementNav=(active)=>`<nav class="mf-management-nav" aria-label="管理导航"><button type="button" data-mf-nav="rules" ${active==='rules'?'aria-current="page"':''}>获客规则</button><button type="button" data-mf-nav="tone" ${active==='tone'?'aria-current="page"':''}>回复口吻</button><button type="button" data-mf-nav="presets" ${active==='presets'?'aria-current="page"':''}>门店预设</button><details class="mf-management-more"><summary ${active==='aiModel'?'aria-current="page"':''}>更多管理<img src="/assets/reference-management-tabler-chevron-down.svg" alt="" aria-hidden="true"></summary><div><button type="button" data-mf-nav="aiModel">AI 模型</button><button type="button" data-mf-nav="accounts">账号授权</button></div></details></nav>`;
export function bindManagementNavigation(root,ctx){
 for(const node of root.querySelectorAll('[data-mf-nav]'))node.addEventListener('click',()=>{
  const page=node.dataset.mfNav;
  if(['rules','tone','presets','aiModel','accounts','acquire'].includes(page))ctx.navigate(page);
 });
}
