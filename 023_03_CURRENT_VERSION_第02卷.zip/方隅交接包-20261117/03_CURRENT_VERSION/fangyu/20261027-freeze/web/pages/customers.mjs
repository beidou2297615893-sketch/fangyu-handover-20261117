import {calendarControl} from '../daily-ui.mjs';
import {personalTools} from '../platform-ui.mjs';
import {evidenceSummary,assessmentLabel,renderIntentState,intentChoices,analysisChoices,intentFilterControl,analysisFilterControl} from './workflow-summary.mjs';
import {customerModel,customerControls,customerQuery,customerShortNeed,actorMatches,count} from './customers-data.mjs';
import {openHandoff} from './customer-handoff.mjs';
import {openPublicContacts} from './customer-public-contacts.mjs';
import {openOutcomeEditor} from './customer-outcomes.mjs';
import {renderIntentCorrection,bindIntentCorrection} from './customer-intent-correction.mjs';
import {customerAvatar,postCover,bindCustomerAvatars} from '../avatar.mjs';
const PEOPLE = [
  {id:'xiaoyu',name:'小雨',avatar:'portrait-woman-1.png',need:'长宁·3500元·下月入住',level:'超高意向',rank:3,tone:'urgent',time:'今天 10:24',timeOrder:4,replied:false,channel:'小红书',post:'古北求租',quote:'下月入住，预算3500，想周末看房。',next:'确认周末看房时间'},
  {id:'chen',name:'陈先生',avatar:'portrait-man-1.png',need:'九号线·一居·近地铁',level:'高意向',rank:2,tone:'high',time:'昨天 16:20',timeOrder:3,replied:false,channel:'抖音',post:'通勤租房',quote:'想在古北找一居室，最好近地铁。',next:'确认房源偏好与入住安排'},
  {id:'lin',name:'林女士',avatar:'portrait-woman-2.png',need:'近地铁·下月入住',level:'中意向',rank:1,tone:'medium',time:'昨天 14:08',timeOrder:2,replied:false,channel:'小红书',post:'长宁租房',quote:'九号线附近有没有精装一居？预算3000左右。',next:'确认预算与入住安排'},
  {id:'zhou',name:'周先生',avatar:'portrait-man-1.png',need:'两人住·短租',level:'中意向',rank:1,tone:'medium',time:'10月13日',timeOrder:1,replied:false,channel:'抖音',post:'公寓咨询',quote:'两个人想短租两个月，想了解一下合适的房源。',next:'了解租期与区域偏好'}
];
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(name,cls='')=>`<img class="cs-icon ${cls}" src="/assets/${name}" alt="" aria-hidden="true">`;
const badge=p=>`<span class="cs-badge cs-${p.tone}">${p.level}</span>`;
const LONG_QUOTE='下个月和朋友一起搬到上海，想在古北附近找一间采光好的一居室。预算3500元左右，希望近地铁，可以养猫，有独立厨房和卫生间。我们周末都方便看房，也想了解押金、水电和最短租期。';
function data(state){
  state.customers??={};
  const s=state.customers;s.platform=state.activePlatform||'xiaohongshu';const defaults={query:'',sort:'intent',sortDirection:'desc',filter:'all',filterOpen:false,selectedId:'',checkedIds:[],evidenceOpen:false,handedOffIds:[],handoffNotes:{},repliedIds:[]};
  for(const [key,value]of Object.entries(defaults))if(s[key]===undefined)s[key]=value;
  if(state.selectedCustomer){s.selectedId=state.selectedCustomer==='rain'?'xiaoyu':state.selectedCustomer;delete state.selectedCustomer;}
  return s;
}
const isReplied=(p,s)=>p.replied||s.repliedIds.includes(p.id);
function visible(s){
  const query=s.query.trim().toLowerCase();
  let list=PEOPLE.filter(p=>(!query||`${p.name}${p.need}${p.channel}${p.post}${p.level}`.toLowerCase().includes(query))&&(s.filter==='all'||(s.filter==='high'&&p.rank>1)||(s.filter==='medium'&&p.rank===1)||(s.filter==='replied'&&isReplied(p,s))||(s.filter==='pending'&&!isReplied(p,s))));
  const order=s.sortDirection==='asc'?1:-1;
  return list.sort((a,b)=>{let value=0;if(s.sort==='intent')value=a.rank-b.rank;else if(s.sort==='reply')value=Number(isReplied(b,s))-Number(isReplied(a,s));else if(s.sort==='time')value=a.timeOrder-b.timeOrder;else if(s.sort==='post')value=`${a.channel}${a.post}`.localeCompare(`${b.channel}${b.post}`,'zh-CN');return value*order||b.timeOrder-a.timeOrder;});
}
function row(p,s){
  const replied=isReplied(p,s),handed=s.handedOffIds.includes(p.id),action=p.rank===3?'人工回复':replied?'整理交接':'待回复';
  return `<tr class="${s.selectedId===p.id?'is-current':''}" data-customer-row="${p.id}" tabindex="0" aria-label="查看${p.name}客户详情"><td class="cs-check-col"><input type="checkbox" data-customer-check="${p.id}" aria-label="选择${p.name}" ${s.checkedIds.includes(p.id)?'checked':''}></td><td class="cs-person-col"><div class="cs-person-cell"><img src="/assets/${p.avatar}" alt="${p.name}的示例头像"><span><strong>${p.name}</strong><span>${p.need}</span></span></div></td><td class="cs-intent-col">${badge(p)}</td><td class="cs-contact-col"><span class="cs-contact-time"><i class="cs-dot ${replied?'is-green':p.id==='zhou'?'is-muted':''}"></i>${p.time}</span><span class="cs-contact-status">${replied?'已回复':p.id==='zhou'?'未回复':'待回复'}</span></td><td class="cs-channel-col"><strong>${p.channel}</strong><span>${p.post}</span></td><td class="cs-next-col"><button type="button" data-customer-action="${p.id}" class="cs-row-action">${handed?'已整理':action}</button></td></tr>`;
}
function stateScreen(scenario){
  const info={empty:['fy-state-01-empty-customers.png','还没有客户记录','开始获客后，客户需求与来源会集中显示在这里。'],loading:['fy-state-04-loading.png','正在整理客户清单','稍等片刻，客户与联系记录即将准备好。'],error:['fy-state-03-error.png','客户清单暂时没有加载出来','可以重新试一次，已保存的交接记录仍会保留。']}[scenario];
  return `<div class="customers-page"><div class="cs-stats">${[['客户总量',0],['高意向',0],['已回复',0],['待交接',0]].map(([title,count])=>`<div class="cs-stat"><span class="cs-stat-icon">${icon('tabler-upgrade-users.svg')}</span><span><small>${title}</small><strong>${count}</strong></span></div>`).join('')}</div><div class="cs-state-screen" role="status"><img src="/assets/${info[0]}" alt=""><h2>${info[1]}</h2><p>${info[2]}</p>${scenario==='error'?'<button type="button" class="cs-primary cs-state-retry" data-customer-retry>重新加载</button>':scenario==='loading'?'<span>正在加载…</span>':''}</div></div>`;
}
export function render(state){
 if(state.connection!=='preview')return renderConnected(state);
 const s=data(state),channel=state.activePlatform==='douyin'?'抖音':'小红书',items=visible(s).filter(p=>p.channel===channel).map(p=>({...p,shortNeed:p.need,intentLevel:p.rank===3?'super_high':p.rank===2?'high':'medium',analysisStatus:'graded',postTitle:p.post}));
 const actor={username:'preview',storeId:'preview'};
 const projected={...state,user:'preview',storeId:'preview',customers:{...s,actorKey:JSON.stringify([state.authEpoch||0,state.session?.user?.tenant_id||'','preview',state.session?.user?.role||'','preview',state.activePlatform||'xiaohongshu']),pageSize:20},customerView:{actor,status:'ready',items,total:items.length,page:1,pages:1,stats:{}},customerDetail:{actor,id:s.selectedId,status:'ready',item:items.find(p=>p.id===s.selectedId)}};
 return renderConnected(projected);
}
function toReply(ctx,p){ctx.update(state=>{state.reply??={};state.reply.selectedId=p.id;state.reply.tab=state.reply.sentIds?.includes(p.id)?'replied':'pending';state.reply.draft=state.reply.savedDrafts?.[p.id]??`你好，已了解你的租房需求。\n方便确认一下看房时间吗？`;state.reply.evidenceOpen=false;});ctx.navigate('reply');}
function handoff(ctx,p){
  const s=data(ctx.state),done=s.handedOffIds.includes(p.id);
  ctx.modal({title:'客户备忘',html:`<div class="cs-handoff-preview"><h3>${p.name} · ${p.level}</h3><p>${p.quote}</p><dl><dt>来源</dt><dd>${p.channel} · ${p.post}</dd><dt>下一步</dt><dd>${p.next}</dd><dt>门店</dt><dd>${esc(ctx.state.store||'古北店')}</dd></dl><label>我的记录<textarea id="cs-handoff-note" placeholder="记录本次需求…">${esc(s.handoffNotes[p.id]||(done?'需求与来源信息已整理，可安排同事接续联系。':''))}</textarea></label></div>`,confirmLabel:done?'完成':'保存备忘',onConfirm:()=>{
    const note=document.getElementById('cs-handoff-note')?.value.trim()||'';
    ctx.update(state=>{const v=data(state);if(!v.handedOffIds.includes(p.id))v.handedOffIds.push(p.id);v.handoffNotes[p.id]=note;});
    ctx.toast('示例备忘已保存');
  }});
}
export function bind(root,ctx){
  root.querySelector('[data-customer-platform]')?.addEventListener('change',event=>{if(['xiaohongshu','douyin'].includes(event.target.value))ctx.switchPlatform?.(event.target.value);});
  root.querySelectorAll('[data-customer-detail-jump]').forEach(el=>el.addEventListener('click',()=>{const id=el.dataset.customerDetailJump;if(['customer-original','customer-contact'].includes(id)){const target=root.querySelector(`[id="${id}"]`);if(target){for(let parent=target.parentElement;parent&&parent!==root;parent=parent.parentElement)if(parent.tagName==='DETAILS')parent.open=true;target.scrollIntoView({block:'nearest',behavior:'smooth'});}}}));
  if(ctx.state.connection!=='preview')return bindConnected(root,ctx);
  const s=data(ctx.state);
  const close=()=>ctx.update(state=>{data(state).selectedId='';data(state).filterOpen=false;});
  root.querySelectorAll('[data-customer-close],[data-customer-filter-close]').forEach(el=>el.addEventListener('click',close));
  root.querySelectorAll('[data-customer-view]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{data(state).selectedId=el.dataset.customerView;})));
  root.querySelector('[data-customer-priority]')?.addEventListener('click',()=>ctx.update(state=>{data(state).filter='high';}));
  root.querySelector('[data-customer-day]')?.addEventListener('change',e=>ctx.update(state=>{data(state).acquiredDate=e.target.value;data(state).checkedIds=[];}));
  root.querySelector('[data-customer-day-clear]')?.addEventListener('click',()=>ctx.update(state=>{data(state).acquiredDate='';data(state).checkedIds=[];}));
  root.querySelector('[data-customer-retry]')?.addEventListener('click',()=>{ctx.update(state=>{state.scenario='normal';});ctx.toast('客户清单已重新加载');});
  const search=root.querySelector('[data-customer-search]');
  let composing=false;
  search?.addEventListener('compositionstart',()=>{composing=true;});
  search?.addEventListener('input',e=>{
    const value=e.target.value;
    if(composing||e.isComposing){s.query=value;return;}
    if(s.query===value)return;
    ctx.update(state=>{data(state).query=value;});
  });
  search?.addEventListener('compositionend',e=>{composing=false;const value=e.target.value;ctx.update(state=>{data(state).query=value;});});
  root.querySelector('[data-customer-filter]')?.addEventListener('click',()=>ctx.update(state=>{data(state).filterOpen=!data(state).filterOpen;}));
  root.querySelectorAll('[data-customer-filter-value]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state);v.filter=el.dataset.customerFilterValue;v.filterOpen=false;})));
  root.querySelectorAll('[data-customer-sort]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{const v=data(state);v.sortDirection=v.sort===el.dataset.customerSort&&v.sortDirection==='desc'?'asc':'desc';v.sort=el.dataset.customerSort;})));
  root.querySelectorAll('[data-customer-row]').forEach(el=>{const select=()=>ctx.update(state=>{const v=data(state);v.selectedId=el.dataset.customerRow;v.evidenceOpen=false;});el.addEventListener('click',e=>{if(e.target.closest('button,input'))return;select();});el.addEventListener('keydown',e=>{if(e.target===el&&(e.key==='Enter'||e.key===' ')){e.preventDefault();select();}});});
  root.querySelectorAll('[data-customer-check]').forEach(el=>el.addEventListener('change',()=>ctx.update(state=>{const v=data(state),id=el.dataset.customerCheck;v.checkedIds=el.checked?[...new Set([...v.checkedIds,id])]:v.checkedIds.filter(value=>value!==id);})));
  root.querySelector('[data-customer-check-all]')?.addEventListener('change',event=>ctx.update(state=>{data(state).checkedIds=event.target.checked?PEOPLE.map(p=>p.id):[];}));
  root.querySelectorAll('[data-customer-action]').forEach(el=>el.addEventListener('click',()=>{const p=PEOPLE.find(v=>v.id===el.dataset.customerAction);if(isReplied(p,s))handoff(ctx,p);else toReply(ctx,p);}));
  const selected=()=>PEOPLE.find(v=>v.id===data(ctx.state).selectedId)||PEOPLE[0];
  root.querySelector('[data-customer-reply]')?.addEventListener('click',()=>toReply(ctx,selected()));
  root.querySelector('[data-customer-handoff]')?.addEventListener('click',()=>handoff(ctx,selected()));
  root.querySelector('[data-customer-evidence]')?.addEventListener('click',()=>ctx.update(state=>{data(state).evidenceOpen=!data(state).evidenceOpen;}));
  root.querySelector('[data-customer-evidence-link]')?.addEventListener('click',()=>ctx.update(state=>{data(state).evidenceOpen=true;}));
  root.querySelector('[data-customer-source]')?.addEventListener('click',()=>{const p=selected();ctx.modal({title:`${p.channel}源帖`,html:`<div class="cs-source-preview"><img src="/assets/fy-login-apartment-photo.webp" alt="示例公寓房源"><h3>${p.post}</h3><p>${p.quote}</p><p>${p.channel} · ${p.time}</p><small>界面演示用来源内容。</small></div>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-history]')?.addEventListener('click',()=>{const p=selected();ctx.modal({title:'交接记录',html:`<p><strong>${p.name}</strong></p><div class="cs-record-line"><span>${s.handedOffIds.includes(p.id)?'刚刚':'今天 10:24'}</span><p>${s.handedOffIds.includes(p.id)?'已整理需求、来源和下一步安排，等待同事接续联系。':'尚未整理交接，可先确认需求和看房时间。'}</p></div>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-more]')?.addEventListener('click',()=>{const p=selected();ctx.modal({title:'客户操作',html:`<h3>${p.name}</h3><p>${p.need}</p><p>可以在右侧查看来源证据、进行人工回复或整理交接。</p>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-batch]')?.addEventListener('click',()=>{const chosen=PEOPLE.filter(p=>s.checkedIds.includes(p.id)),eligible=chosen.filter(p=>p.rank===1),manual=chosen.filter(p=>p.rank>1);ctx.modal({title:'批量回复',html:`<p>已选 <strong>${chosen.length}</strong> 位客户，可批量回复 <strong>${eligible.length}</strong> 位中意向客户。</p>${manual.length?`<p class="cs-modal-note">${manual.map(p=>p.name).join('、')}建议人工回复。</p>`:''}<div class="cs-batch-names">${eligible.map(p=>`<span>${p.name}</span>`).join('')}</div><label class="cs-batch-label">回复内容<textarea id="cs-batch-draft" maxlength="200">你好，看到你正在了解租房。我们有合适的房源可供参考，方便说一下你的入住时间吗？</textarea></label><p class="cs-modal-note">本次为界面演示，确认后仅更新示例状态。</p>`,confirmLabel:eligible.length?'确认批量演示':'知道了',onConfirm:eligible.length?()=>{const draft=document.getElementById('cs-batch-draft')?.value.trim()||'';if(!draft){ctx.toast('请先填写回复内容');return false;}ctx.update(state=>{const v=data(state);v.lastBatchDraft=draft;state.reply??={};state.reply.sentIds??=['anna'];state.reply.savedDrafts??={};for(const p of eligible){state.reply.savedDrafts[p.id]=draft;if(!v.repliedIds.includes(p.id))v.repliedIds.push(p.id);if(!state.reply.sentIds.includes(p.id))state.reply.sentIds.push(p.id);}});ctx.toast(`已完成 ${eligible.length} 位客户的示例回复`);}:undefined});});
  root.querySelector('[data-customer-export]')?.addEventListener('click',()=>{const list=visible(s);ctx.modal({title:'Excel导出预览',html:`<p>当前清单共 <strong>${list.length}</strong> 位客户。</p><div class="cs-export-preview"><table><thead><tr><th>客户</th><th>意向</th><th>渠道</th></tr></thead><tbody>${list.map(p=>`<tr><td>${p.name}</td><td>${p.level}</td><td>${p.channel}</td></tr>`).join('')}</tbody></table></div><p class="cs-modal-note">此处展示导出列与确认流程。</p>`,confirmLabel:'确认预览',onConfirm:()=>ctx.toast('导出预览已确认')});});
}

function liveStats(){return '';}
function liveState(model){
  const kind=model.status==='error'?'error':model.status==='loading'?'loading':'empty';
  const [asset,title,text]={empty:['fy-state-01-empty-customers.png','还没有客户记录',model.scope==='employee-local-history'?'本机当前员工可见客户将显示在这里；旧记录的门店归属尚未核实。':'采集到的客户会显示在这里。'],loading:['fy-state-04-loading.png','正在读取客户清单','正在核对当前员工可见客户与来源。'],error:['fy-state-03-error.png','客户清单暂时没有加载出来',model.error||'请重新加载当前员工可见客户。']}[kind];
  if(kind==='loading')return '<div class="cs-skeleton" role="status" aria-label="正在加载客户"><div></div><div></div><div></div><div></div><div></div></div>';
  return `<div class="cs-state-screen" role="status"><img src="/assets/${asset}" alt=""><h2>${title}</h2><p>${esc(text)}</p>${kind==='error'?'<button type="button" class="cs-primary cs-state-retry" data-customer-retry>重新加载</button>':kind==='loading'?'<span>正在加载…</span>':''}</div>`;
}
const liveFilterLabels={all:'全部回复状态',pending:'待回复',replied:'已回复'};
const liveBadge=p=>renderIntentState(p);
const contactClock=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
function contactTime(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/.test(value))return {label:'暂无联系时间',title:''};
  const time=new Date(value);if(!Number.isFinite(time.getTime()))return {label:'暂无联系时间',title:''};
  const parts=Object.fromEntries(contactClock.formatToParts(time).map(part=>[part.type,part.value]));
  return {label:`${parts.year.padStart(4,'0')}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}`,title:value};
}
function liveRow(p,s){
  return `<tr class="${s.selectedId===p.id?'is-current':''}" data-customer-row="${esc(p.id)}" tabindex="0" aria-label="查看${esc(p.name||'客户')}客户详情"><td class="cs-check-col"><input type="checkbox" data-customer-check="${esc(p.id)}" aria-label="选择${esc(p.name||'客户')}" ${s.checkedIds.includes(p.id)?'checked':''}></td><td class="cs-person-col"><div class="cs-person-cell">${customerAvatar(p)}<span><strong>${esc(p.name||'未命名客户')}</strong><span>${esc(p.channel||(p.platform==='douyin'?'抖音':'小红书'))}</span></span></div></td><td class="cs-need-col">${esc(customerShortNeed(p)||'需求待了解')}</td><td class="cs-intent-col">${liveBadge(p)}</td><td class="cs-contact-col"><span class="cs-contact-status">${esc(p.contactLabel||(p.replied?'已回复':'待回复'))}</span></td><td class="cs-view-col"><button type="button" data-customer-view="${esc(p.id)}">查看 <span aria-hidden="true">›</span></button></td></tr>`;
}
function analysisRuleNotice(p){
  const note=p.analysisRuleNotice;
  if(!note||typeof note.label!=='string'||typeof note.notice!=='string')return '';
  return `<details class="cs-need" data-analysis-rule-notice><summary>分析记录说明</summary><p><strong>${esc(note.label)}</strong><br>${esc(note.notice)}</p></details>`;
}
function missingFieldMarkup(){return '<strong class="cs-fact-value" title="未提供">未提供</strong>';}
function liveDetail(state,model){
 const s=model.controls;if(!s.selectedId)return '';
 const summary=model.items.find(p=>p.id===s.selectedId),detail=state.customerDetail,accepted=actorMatches(state,detail)&&detail.id===s.selectedId;
 const p=accepted&&detail.item?.id===s.selectedId?detail.item:summary;if(!p)return '';
 const loading=!accepted||detail.status==='loading',failed=accepted&&detail.status==='error',snapshot=accepted&&detail.status==='snapshot',blocked=snapshot||loading||failed||model.status!=='ready';
 return `<div class="cs-drawer-shade" data-customer-close></div><aside class="cs-detail-panel cs-post-detail" role="dialog" aria-modal="true" aria-label="客户详情" tabindex="-1"><button type="button" class="cs-drawer-close" data-customer-close aria-label="关闭客户详情">×</button><div class="cs-detail-person">${customerAvatar(p)}<div><strong>${esc(p.name||'未命名客户')}</strong>${liveBadge(p)}<p>${esc(p.need||'需求待补充')}</p></div></div><div class="cs-detail-tabs"><span>需求</span><button type="button" data-customer-detail-jump="customer-original">原评论</button><button type="button" data-customer-detail-jump="customer-contact">联系记录</button></div><div class="cs-detail-needs"><span>区域</span>${missingFieldMarkup()}<span>租期</span><strong class="cs-fact-value" title="${esc(p.followupLeaseGroup||p.leaseGroup||'未提供')}">${esc(p.followupLeaseGroup||p.leaseGroup||'未提供')}</strong><span>入住</span>${missingFieldMarkup()}<small class="cs-saved-facts-note">需求以原评论和已有分析为准</small></div><h3 id="customer-original">原评论</h3><blockquote class="cs-quote">${esc(loading?p.quote||'正在读取原评论…':failed?detail.error||'详情暂时无法读取':p.quote||'原评论未记录')}</blockquote><div class="cs-post-title"><button type="button" class="cs-source" data-customer-source ${loading||failed||!p.postUrl?'disabled':''}>${esc(p.sourceLinkLabel||'查看来源')} ${icon('tabler-external-link.svg')}</button></div>${loading?'<p class="cs-need" role="status">正在核对完整详情</p>':''}${snapshot?`<p class="cs-need" role="status">${esc(detail.error||'已显示本次使用中读取的资料，正在核对最新内容。')}</p>`:''}<button type="button" class="cs-evidence-toggle" data-customer-evidence aria-expanded="${s.evidenceOpen}">判断依据 ${icon('tabler-chevron-down.svg')}</button>${s.evidenceOpen?evidenceSummary(p):''}<div class="cs-detail-actions"><button type="button" class="cs-primary" data-customer-reply ${blocked||p.commentReplyAllowed===false?'disabled':''}>${icon('tabler-message-dots.svg')}${p.commentReplyAllowed===false?'直播聊天不提供评论回复':'去回复'}</button><details class="cs-detail-more"><summary>更多 <span aria-hidden="true">⌄</span></summary><div>${!blocked?'<button type="button" data-public-contact-open>公开联系方式</button>':''}${personalTools(state)?`<button type="button" data-customer-handoff ${blocked?'disabled':''}>客户备忘</button>`:''}<button type="button" data-customer-outcomes ${blocked?'disabled':''}>登记处理结果</button>${!blocked?renderIntentCorrection(state,p):''}<details class="cs-more-context"><summary>更多资料与原帖</summary><h3>${esc(p.postTitle||'原帖标题未记录')}</h3><div class="cs-post-picture">${postCover(p,'cs-post-cover')}</div><p id="customer-contact">联系记录：${esc(p.contactLabel||(p.replied?'已回复':'待回复'))}<br>最近联系：${esc(contactTime(p.contactAt).title?contactTime(p.contactAt).label:'暂无记录')}</p>${p.need?`<p>${esc(p.need)}</p>`:''}${(p.followupLeaseGroup||p.leaseGroup)?`<p>租期：${esc(p.followupLeaseGroup||p.leaseGroup)} · ${esc(p.storeFit?.status||'适配待核对')}</p>`:''}${!loading&&!failed?analysisRuleNotice(p):''}</details></div></details></div></aside>`;
}
function referenceScope(state,compact=false){return `<details class="cs-reference-scope"><summary aria-label="当前门店与平台">${icon('reference-customers-calendar.svg')}<span>${esc(state.store||'当前门店')}${compact?'':` · ${state.activePlatform==='douyin'?'抖音':'小红书'}`}</span>${icon('reference-customers-chevron.svg')}</summary><div><label>当前门店<span class="cs-current-store-readonly">${esc(state.store||'当前门店')}</span></label><label>平台<select data-customer-platform><option value="xiaohongshu" ${state.activePlatform!=='douyin'?'selected':''}>小红书</option><option value="douyin" ${state.activePlatform==='douyin'?'selected':''}>抖音</option></select></label></div></details>`;}
function detailListRow(person,controls){
 return `<tr data-customer-row="${esc(person.id)}" tabindex="0" class="${controls.selectedId===person.id?'is-current':''}" aria-label="查看${esc(person.name||'客户')}客户详情"><td><div class="cs-person-cell">${customerAvatar(person)}<strong>${esc(person.name||'未命名客户')}</strong></div></td><td>${liveBadge(person)}</td><td>${missingFieldMarkup()}</td><td>${missingFieldMarkup()}</td><td>${missingFieldMarkup()}</td><td class="cs-detail-updated"><span class="cs-fact-value" title="未提供">未提供</span><button type="button" data-customer-view="${esc(person.id)}" aria-label="查看${esc(person.name||'客户')}客户详情">›</button></td></tr>`;
}
function renderDetailWorkspace(state,model,filters){
 const s=model.controls;
 return `<div class="customers-page cs-connected cs-reference cs-detail-open"><div class="cs-detail-list-controls">${referenceScope(state,true)}${intentFilterControl('customer',s.intent||'all')}${analysisFilterControl('customer',s.analysisStatus||'all')}${calendarControl('customers',s.acquiredDate||'','按新增日期筛选客户')}<label class="cs-search">${icon('fy-icon-07-search.png')}<input id="customer-search" type="search" data-customer-search maxlength="100" value="${esc(s.query)}" placeholder="搜索客户" aria-label="搜索客户"></label></div><div class="cs-workspace"><section class="cs-list-panel" aria-label="客户清单"><div class="cs-table-wrap" aria-busy="${Boolean(state.customerLoading)}"><table class="cs-detail-table"><thead><tr><th>客户</th><th>意向</th><th>区域</th><th>预算</th><th>入住时间</th><th>更新时间</th></tr></thead><tbody>${model.items.map(p=>detailListRow(p,s)).join('')}</tbody></table>${!model.items.length?'<div class="cs-empty"><strong>当前筛选没有客户</strong><span>关闭详情后可恢复原清单。</span></div>':''}</div></section>${liveDetail(state,model)}${filters}</div></div>`;
}
function renderConnected(state){
 const model=customerModel(state),s=model.controls,css='';
 const allChecked=model.total>0&&s.checkedIds.length===model.total,page=model.page||1,pages=model.pages||1;
 const filters=s.filterOpen?`<div class="cs-drawer-shade" data-customer-filter-close></div><aside class="cs-filter-drawer" role="dialog" aria-modal="true" aria-label="筛选条件" tabindex="-1"><button class="cs-drawer-close" data-customer-filter-close aria-label="关闭筛选条件">×</button><h2>筛选条件</h2><div class="cs-filter-fields"><label>新增时间 ${calendarControl('customers',s.acquiredDate||'','按新增日期筛选客户')}${s.acquiredDate?'<button data-customer-day-clear>清除日期</button>':''}</label>${intentFilterControl('customer',s.intent||'all')}${analysisFilterControl('customer',s.analysisStatus||'all')}<section><h3>回复状态</h3>${Object.entries(liveFilterLabels).map(([key,label])=>`<button data-customer-filter-value="${key}" aria-pressed="${s.filter===key}">${label}</button>`).join('')}</section>${state.storeId==='fy_s_d343f3a378f48e1bab55df4f'?`<label>租期 <select data-customer-lease aria-label="按租期分组查看客户">${['all','1至3个月','4至11个月','12个月','未说明','其他租期','租期待确认'].map(key=>`<option value="${key}" ${s.leaseGroup===key?'selected':''}>${key==='all'?'全部租期':key}</option>`).join('')}</select></label>`:''}</div><div class="cs-filter-footer"><button class="cs-filter-reset" data-customer-filter-reset>重置</button><button class="cs-primary cs-filter-apply" data-customer-filter-close>完成筛选</button></div></aside>`:'';
 if(model.status!=='ready')return s.selectedId&&s.detailReturn?renderDetailWorkspace(state,model,filters):`${css}<div class="customers-page cs-connected cs-reference">${referenceScope(state)}${liveState(model)}</div>`;
 if(s.selectedId)return renderDetailWorkspace(state,model,filters);
 return `${css}<div class="customers-page cs-connected cs-reference">${referenceScope(state)}<div class="cs-workspace"><section class="cs-list-panel" aria-label="客户清单">${model.snapshot&&model.error?`<p role="status">${esc(model.error)}</p>`:''}<div class="cs-list-toolbar"><nav class="cs-reference-tabs" aria-label="客户范围"><button data-customer-filter-value="all" class="${s.filter==='all'&&s.intent==='all'?'is-active':''}">全部客户（${count(model.total)}）</button><button data-customer-priority class="${s.intent==='high'&&s.filter==='all'?'is-active':''}">高意向</button><button data-customer-filter-value="replied" class="${s.filter==='replied'?'is-active':''}">已回复</button></nav><div class="cs-reference-tools"><label class="cs-search">${icon('fy-icon-07-search.png')}<input id="customer-search" type="search" data-customer-search value="${esc(s.query)}" maxlength="100" placeholder="客户昵称或需求" aria-label="搜索客户"></label><button type="button" class="cs-filter" data-customer-filter aria-expanded="${s.filterOpen}">${icon('fy-icon-09-filter.png')}筛选</button><details class="cs-list-more"><summary>更多⌄</summary><div><span>排序</span>${[['intent','意向'],['reply','回复'],['time','时间'],['post','帖子']].map(([key,label])=>`<button data-customer-sort="${key}" aria-pressed="${s.sort===key}">${label}${s.sort===key?(s.sortDirection==='desc'?' ↓':' ↑'):''}</button>`).join('')}<span>回复范围</span><button type="button" data-customer-filter-value="replied">已回复</button><button type="button" data-customer-filter-value="pending">待回复</button><button data-customer-batch>选择客户回复</button><span>已选 ${s.checkedIds.length} 位客户</span></div></details><button type="button" class="cs-export" data-customer-export ${state.customerExporting?'disabled':''}>${icon('reference-customers-export.svg')}${state.customerExporting?'正在导出…':'导出清单'}</button></div></div><div class="cs-table-wrap" aria-busy="${Boolean(state.customerLoading)}"><table><thead><tr><th class="cs-check-col"><input type="checkbox" data-customer-check-all aria-label="全选当前筛选的所有客户" ${allChecked?'checked':''} ${state.customerLoading||state.customerSelectingAll?'disabled':''}></th><th>客户</th><th>租房需求</th><th>意向</th><th>回复状态</th><th>操作</th></tr></thead><tbody>${model.items.map(p=>liveRow(p,s)).join('')}</tbody></table>${!model.items.length?'<div class="cs-empty"><strong>没有找到相关客户</strong><span>试试其他关键词或筛选条件。</span></div>':''}</div><div class="cs-table-footer"><span>每页 ${s.pageSize||20} 条　⌄　　共 ${count(model.total)} 位客户</span><div><button data-customer-page="previous" aria-label="上一页" ${page<=1?'disabled':''}>‹</button>${Array.from({length:Math.min(3,pages)},(_,i)=>Math.max(1,Math.min(page-1,pages-2))+i).map(n=>`<button type="button" data-customer-page-index="${n}" class="${n===page?'cs-page-current':'cs-page-number'}" ${n===page?'aria-current="page"':''}>${n}</button>`).join('')}<button data-customer-page="next" aria-label="下一页" ${page>=pages?'disabled':''}>›</button></div></div></section>${liveDetail(state,model)}${filters}</div></div>`;
}
export function customerExportSnapshot(state){
  const view=state.customerView,params=customerQuery(state),s=customerControls(state);
  const queryKey=value=>JSON.stringify(['platform','query','filter','intent','analysisStatus','review','sort','sortDirection','page','pageSize','acquiredDate','leaseGroup'].map(key=>value?.[key]));
  if(state.customerLoading||view?.snapshot||!actorMatches(state,view)||view.status!=='ready'
      ||!view.requestQuery||queryKey(view.requestQuery)!==queryKey(params))return null;
  const selectedIds=[...s.checkedIds],amount=selectedIds.length||view.total;
  if(!Number.isSafeInteger(amount)||amount<0)return null;
  const {platform,query,filter,intent,analysisStatus,review,sort,sortDirection,acquiredDate,leaseGroup}=params;
  return {view,amount,payload:{platform,query,filter,intent,analysisStatus,review,sort,sortDirection,acquiredDate,...(leaseGroup?{leaseGroup}:{}),...(selectedIds.length?{selectedIds}:{})},
    signature:JSON.stringify([state.user,state.storeId,state.activePlatform||'xiaohongshu',params,selectedIds,view.total])};
}
function bindConnected(root,ctx){
  const s0=customerControls(ctx.state),wrap=root.querySelector('.cs-table-wrap');
  if(wrap&&s0.restoreListScroll&&Number.isFinite(s0.tableScroll)){wrap.scrollTop=s0.tableScroll;delete s0.restoreListScroll;}
  if(s0.pendingReturnFocus&&!s0.selectedId&&!s0.filterOpen){
    const pending=s0.pendingReturnFocus;
    if(pending.queryKey!==JSON.stringify(customerQuery(ctx.state)))delete s0.pendingReturnFocus;
    else queueMicrotask(()=>{if(customerControls(ctx.state)!==s0||s0.selectedId||s0.filterOpen)return;const key=pending.kind==='row'?'customerRow':'customerView',selector=pending.kind==='row'?'[data-customer-row]':'[data-customer-view]',target=[...root.querySelectorAll(selector)].find(el=>el.dataset[key]===pending.id);if(target){target.focus();delete s0.pendingReturnFocus;}});
  }
  const close=filter=>{
    const current=customerControls(ctx.state),id=current.selectedId,back=current.detailReturn;
    ctx.update(state=>{const s=customerControls(state);if(filter)s.filterOpen=false;else{if(back){s.tableScroll=back.tableScroll;s.restoreListScroll=true;s.pendingReturnFocus={id:back.focusId,kind:back.focusKind,queryKey:JSON.stringify(customerQuery(state))};}s.selectedId='';delete s.detailReturn;}});
    queueMicrotask(()=>{if(!filter&&back){const table=root.querySelector('.cs-table-wrap');if(table)table.scrollTop=back.tableScroll;delete customerControls(ctx.state).restoreListScroll;}const key=back?.focusKind==='row'?'customerRow':'customerView',selector=key==='customerRow'?'[data-customer-row]':'[data-customer-view]';const target=filter?root.querySelector('[data-customer-filter]'):[...root.querySelectorAll(selector)].find(e=>e.dataset[key]===(back?.focusId||id));if(target){target.focus();if(!filter)delete customerControls(ctx.state).pendingReturnFocus;}});
  };
  root.querySelectorAll('[data-customer-close]').forEach(e=>e.addEventListener('click',()=>close(false)));
  root.querySelectorAll('[data-customer-filter-close]').forEach(e=>e.addEventListener('click',()=>close(true)));
  const drawer=root.querySelector('[role="dialog"]');
  if(drawer){queueMicrotask(()=>drawer.querySelector('button')?.focus());drawer.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();close(Boolean(customerControls(ctx.state).filterOpen));}if(e.key==='Tab'){const els=[...drawer.querySelectorAll('button,input,select,textarea,a[href],summary')].filter(x=>!x.disabled&&x.tabIndex>=0&&x.getClientRects().length>0);const first=els[0],last=els.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}});}
  bindCustomerAvatars(root);
  bindIntentCorrection(root,ctx);
  root.querySelector('[data-customer-lease]')?.addEventListener('change',event=>{ctx.update(state=>{const c=customerControls(state);c.leaseGroup=event.target.value;c.page=1;c.checkedIds=[];c.selectedId='';delete c.detailReturn;});ctx.actions.loadCustomers?.();});
  const model=customerModel(ctx.state),boundActor=JSON.stringify([ctx.state.user,ctx.state.storeId,ctx.state.activePlatform||'xiaohongshu']);
  const sameActor=()=>boundActor===JSON.stringify([ctx.state.user,ctx.state.storeId,ctx.state.activePlatform||'xiaohongshu']);
  const accepted=()=>sameActor()&&!ctx.state.customerSelectingAll&&actorMatches(ctx.state,ctx.state.customerView)&&ctx.state.customerView.status==='ready';
  const change=fn=>{if(!accepted())return false;ctx.update(state=>fn(customerControls(state)));return true;};
  const request=()=>{if(sameActor())ctx.actions.loadCustomers?.(customerQuery(ctx.state));};
  const select=id=>{if(!accepted()||!customerModel(ctx.state).items.some(item=>item.id===id))return;change(s=>{if(!s.detailReturn)s.detailReturn={listView:ctx.state.customerView,tableScroll:root.querySelector('.cs-table-wrap')?.scrollTop||0,focusId:id,focusKind:globalThis.document?.activeElement?.hasAttribute?.('data-customer-row')?'row':'view'};s.selectedId=id;s.evidenceOpen=false;});return ctx.actions.loadCustomerDetail?.(id);};

  const linkedDetail=()=>{
    const state=ctx.state,id=customerControls(state).selectedId,detail=state.customerDetail,link=detail?.interactionLink;
    return accepted()&&/^[a-f0-9]{64}$/.test(id||'')&&actorMatches(state,detail)&&detail.status==='ready'
      &&detail.id===id&&detail.item?.id===id&&detail.item.platform===(state.activePlatform||'xiaohongshu')
      &&link?.customerId===id&&link.username===state.user&&link.storeId===state.storeId
      &&link.platform===(state.activePlatform||'xiaohongshu')&&link.authEpoch===(state.authEpoch||0)
      &&link.role===(state.session?.user?.role||'')?detail:null;
  };
  const currentId=()=>{const s=customerControls(ctx.state);return ctx.state.customerDetail?.status!=='snapshot'&&accepted()&&(customerModel(ctx.state).items.some(item=>item.id===s.selectedId)||linkedDetail())?s.selectedId:'';};
  const later=kind=>{if(!accepted())return;ctx.modal({title:kind,html:`<p>${kind==='整理交接'||kind==='交接记录'?'客户交接将在后续批次接入；本次未保存或修改交接状态。':'回复草稿与人工确认发送将在下一批接入；本次未生成草稿或发送消息。'}</p><p>当前可以筛选客户、核对来源及导出Excel。</p>`,confirmLabel:'知道了'});};
  root.querySelector('[data-customer-day]')?.addEventListener('change',e=>{change(s=>{s.acquiredDate=e.target.value;s.page=1;s.checkedIds=[];});request();});
  root.querySelector('[data-customer-day-clear]')?.addEventListener('click',()=>{change(s=>{s.acquiredDate='';s.page=1;s.checkedIds=[];});request();});
  root.querySelector('[data-customer-retry]')?.addEventListener('click',request);
  const search=root.querySelector('[data-customer-search]');let composing=false;
  search?.addEventListener('compositionstart',()=>{composing=true;ctx.actions.setCustomerSearchComposing?.(true);});
  const searchChanged=event=>{if(!accepted())return;const value=String(event.target.value||'').slice(0,100);if(composing||event.isComposing){customerControls(ctx.state).query=value;return;}change(s=>{s.query=value;s.page=1;});request();};
  search?.addEventListener('input',searchChanged);
  search?.addEventListener('compositionend',event=>{
    composing=false;
    // Keep the committed text even if an in-flight request changed the list to
    // an error state; retry must use the completed Chinese query.
    if(sameActor()){const s=customerControls(ctx.state);s.query=String(event.target.value||'').slice(0,100);s.page=1;}
    searchChanged(event);ctx.actions.setCustomerSearchComposing?.(false);
  });
  for(const [field,choices] of [['intent',intentChoices],['analysisStatus',analysisChoices]]){
    const suffix=field==='intent'?'intent':'analysis';
    root.querySelector(`[data-customer-${suffix}]`)?.addEventListener('change',event=>{const value=event.target.value;if(!Object.hasOwn(choices,value))return;if(change(s=>{s[field]=value;if(!['all','pending','replied'].includes(s.filter))s.filter='all';s.page=1;s.checkedIds=[];s.selectedId='';delete s.detailReturn;s.evidenceOpen=false;}))request();});
  }
  root.querySelector('[data-customer-filter-reset]')?.addEventListener('click',()=>{if(change(s=>{Object.assign(s,{acquiredDate:'',intent:'all',analysisStatus:'all',filter:'all',leaseGroup:'all',page:1,checkedIds:[]});}))request();});
  root.querySelector('[data-customer-filter]')?.addEventListener('click',()=>change(s=>{s.filterOpen=!s.filterOpen;}));
  root.querySelectorAll('[data-customer-filter-value]').forEach(el=>el.addEventListener('click',()=>{if(!Object.hasOwn(liveFilterLabels,el.dataset.customerFilterValue))return;if(change(s=>{s.filter=el.dataset.customerFilterValue;s.filterOpen=false;s.page=1;}))request();}));
  root.querySelectorAll('[data-customer-sort]').forEach(el=>el.addEventListener('click',()=>{const sort=el.dataset.customerSort;if(!['intent','reply','time','post'].includes(sort))return;if(change(s=>{s.sortDirection=s.sort===sort&&s.sortDirection==='desc'?'asc':'desc';s.sort=sort;s.page=1;}))request();}));
  root.querySelectorAll('[data-customer-row]').forEach(el=>{el.addEventListener('click',event=>{if(event.target.closest?.('button,input'))return;select(el.dataset.customerRow);});el.addEventListener('keydown',event=>{if(event.target===el&&['Enter',' '].includes(event.key)){event.preventDefault();select(el.dataset.customerRow);}});});
  root.querySelectorAll('[data-customer-view]').forEach(el=>el.addEventListener('click',()=>select(el.dataset.customerView)));
  root.querySelector('[data-customer-priority]')?.addEventListener('click',()=>{if(change(s=>{s.intent='high';if(!['all','pending','replied'].includes(s.filter))s.filter='all';s.page=1;s.checkedIds=[];s.selectedId='';delete s.detailReturn;s.evidenceOpen=false;}))request();});
  root.querySelectorAll('[data-customer-action]').forEach(el=>el.addEventListener('click',async()=>{const id=el.dataset.customerAction;await select(id);if(sameActor())ctx.actions.openCustomerReply?.(id);}));
  root.querySelectorAll('[data-customer-check]').forEach(el=>el.addEventListener('change',()=>{const id=el.dataset.customerCheck;if(!customerModel(ctx.state).items.some(item=>item.id===id))return;change(s=>{s.checkedIds=el.checked?[...new Set([...s.checkedIds,id])]:s.checkedIds.filter(value=>value!==id);});}));
  const allBox=root.querySelector('[data-customer-check-all]');if(allBox)allBox.indeterminate=model.controls.checkedIds.length>0&&model.controls.checkedIds.length<model.total;
  root.querySelector('[data-customer-check-all]')?.addEventListener('change',event=>{if(accepted())ctx.actions.selectAllCustomers?.(event.target.checked);});
  root.querySelectorAll('[data-customer-page-index]').forEach(el=>el.addEventListener('click',()=>{const n=Number(el.dataset.customerPageIndex),m=customerModel(ctx.state);if(Number.isSafeInteger(n)&&n>=1&&n<=m.pages&&change(s=>{s.page=n;s.selectedId='';delete s.detailReturn;s.evidenceOpen=false;}))request();}));
  root.querySelectorAll('[data-customer-page]').forEach(el=>el.addEventListener('click',()=>{const current=customerModel(ctx.state),delta=el.dataset.customerPage==='previous'?-1:1,next=(current.page||1)+delta;if(next<1||next>(current.pages||1))return;if(change(s=>{s.page=next;s.selectedId='';delete s.detailReturn;s.evidenceOpen=false;}))request();}));
  root.querySelector('[data-customer-evidence]')?.addEventListener('click',()=>change(s=>{s.evidenceOpen=!s.evidenceOpen;}));
  root.querySelector('[data-customer-evidence-link]')?.addEventListener('click',()=>change(s=>{s.evidenceOpen=true;}));
  root.querySelector('[data-customer-source]')?.addEventListener('click',()=>{const id=currentId(),detail=ctx.state.customerDetail;if(id&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id&&detail.item?.postUrl)ctx.actions.openCustomerSource?.(id);});
  root.querySelector('[data-customer-reply]')?.addEventListener('click',()=>{if(typeof ctx.actions.openCustomerReply!=='function'){later('人工回复');return;}const id=currentId(),detail=ctx.state.customerDetail;if(detail?.item?.commentReplyAllowed===false){ctx.toast('直播聊天不是视频评论，不能通过评论回复联系。');return;}if(id&&sameActor()&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id)ctx.actions.openCustomerReply(id);});
  root.querySelector('[data-customer-batch]')?.addEventListener('click',()=>{if(typeof ctx.actions.openCustomerBatch!=='function'){later('批量回复');return;}if(sameActor())ctx.actions.openCustomerBatch([...customerControls(ctx.state).checkedIds]);});
  const handoff=history=>{if(!personalTools(ctx.state))return;const id=currentId();if(!id)return;if(typeof ctx.actions.handoffAction!=='function'){later(history?'交接记录':'整理交接');return;}openHandoff(ctx,id,history);};
  root.querySelector('[data-customer-handoff]')?.addEventListener('click',()=>handoff(false));
  root.querySelector('[data-public-contact-open]')?.addEventListener('click',()=>{const id=currentId(),detail=ctx.state.customerDetail;if(id&&sameActor()&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id)openPublicContacts(ctx,id,ctx.state.activePlatform||'xiaohongshu');});
  root.querySelector('[data-customer-outcomes]')?.addEventListener('click',()=>{const id=currentId(),detail=ctx.state.customerDetail;if(id&&sameActor()&&actorMatches(ctx.state,detail)&&detail.id===id&&detail.status==='ready'&&detail.item?.id===id)openOutcomeEditor(ctx,id,ctx.state.activePlatform||'xiaohongshu');});
  root.querySelector('[data-customer-history]')?.addEventListener('click',()=>handoff(true));
  root.querySelector('[data-customer-more]')?.addEventListener('click',()=>{const id=currentId(),p=customerModel(ctx.state).items.find(item=>item.id===id)||linkedDetail()?.item;if(!p)return;ctx.modal({title:'客户操作',html:`<h3>${esc(p.name||'未命名客户')}</h3><p>${esc(p.need||'需求信息未填写')}</p><p>可查看需求与来源证据，或使用Excel导出当前筛选结果。</p>`,confirmLabel:'知道了'});});
  root.querySelector('[data-customer-export]')?.addEventListener('click',()=>{
    if(!accepted()||ctx.state.customerExporting)return;
    const snapshot=!composing&&customerExportSnapshot(ctx.state);
    if(!snapshot){ctx.toast('客户筛选正在更新，请核对列表后再导出。');return;}
    const s=customerControls(ctx.state);
    if(s.checkedIds.length>3000){ctx.toast('已选客户最多导出3000位，请减少勾选数量后重试。');return;}
    const {payload,amount}=snapshot;
    ctx.modal({title:'导出Excel',html:`<p>将导出${s.checkedIds.length?'已选':'当前筛选的全部'} <strong>${count(amount)}</strong> 位客户。</p><p>包含客户需求、来源和原已保存的 AI / 人工意向判断。</p><p class="cs-modal-note">按筛选导出最多3000位；已选客户最多3000位。超过上限时请缩小范围或减少勾选。</p>`,confirmLabel:'确认导出',onConfirm:()=>{
      const fresh=!composing&&customerExportSnapshot(ctx.state);
      if(!accepted()||!fresh||fresh.view!==snapshot.view||fresh.signature!==snapshot.signature){ctx.toast('客户范围已变化，请核对列表后重新导出。');return false;}
      return ctx.actions.exportCustomers?.(payload);
    }});
  });
  return ()=>{composing=false;};
}
