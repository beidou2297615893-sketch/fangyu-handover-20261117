// A view/scope change must never hide or orphan an outstanding write receipt.
// Read-only recovery and a prepared plan remain available under their own guards.
export function replyScopeBlocked(state,v=state.replyLive){
  return Boolean(v?.busy||v?.pending||v?.batchBusy||v?.batchPending||v?.ai?.busy
    ||state.replyDelivery?.busy||state.replyDelivery?.attempt);
}
