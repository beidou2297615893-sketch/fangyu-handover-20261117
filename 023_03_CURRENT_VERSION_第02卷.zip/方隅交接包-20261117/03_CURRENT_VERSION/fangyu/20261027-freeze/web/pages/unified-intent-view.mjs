const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function currentQualificationContract(doc){
 const c=doc?.unifiedIntentContract,version=Number(/-v([0-9]+)$/.exec(c?.regionVersion||'')?.[1]||0);
 return c&&typeof c.version==='string'&&c.version.trim()&&typeof c.regionRules==='string'&&c.regionRules.trim()&&typeof c.aggregationVersion==='string'&&c.aggregationVersion.includes('qualification')&&version>=5?c:null;
}
export function unifiedIntentMarkup(doc){
 const c=currentQualificationContract(doc);
 if(!c)return '<section class="br-qualification" role="status"><h3>规则说明待同步</h3><p>当前资料缺少可核对的新规则版本或四轴说明，暂不沿用旧的单条评论高意向解释。请重新读取当前门店规则。</p></section>';
 const axes=[['租房兴趣','同一客户本人完整上下文所证明的租房兴趣；不取历史最高，也不把一条评论直接当最终等级。'],['当前需求时效','区分当前有效、未来计划、已结束、历史与时间待确认；未来需求不会因此提升为高意向。'],['古北地域匹配','本人明确接受或针对明确古北房源的真实询租才可匹配。同城、搜索词、他人帖子和IP不能单独证明古北；未知仍保留待确认。'],['公寓接受与供需身份','拒绝公寓、纯供给信息独立核对；真实需求与地域匹配也不代表没有门店冲突。']];
 return `<section class="br-qualification"><h3>最终门店意向与租房兴趣分开看</h3><p>最终门店高意向需要当前有效需求、古北明确匹配、没有已知排除，并满足原有兴趣等级门槛。兴趣很强，但地域或时效未知，仍应先核对。</p><dl>${axes.map(([name,text])=>`<dt><strong>${name}</strong></dt><dd>${text}</dd>`).join('')}</dl><p>规则版本：${esc(c.version)} · 地域与门店核对：${esc(c.regionVersion)}</p><details><summary>查看当前同源规则原文</summary><pre style="white-space:pre-wrap">${esc(c.regionRules)}</pre></details><p>这里只解释当前规则，不重新分类客户，也不表示已取得联系或发送授权。</p></section>`;
}
