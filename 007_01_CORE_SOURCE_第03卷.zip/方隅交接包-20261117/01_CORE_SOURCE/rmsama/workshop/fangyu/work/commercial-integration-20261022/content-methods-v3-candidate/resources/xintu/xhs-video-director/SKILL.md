---
name: xhs-video-director
description: >-
  Convert a Xiaohongshu topic, workflow, product, or experiment into a shoot-ready vertical video plan with spoken
  script, phone footage, screen recording, shot timing, on-screen text, edit cues, proof moments, and duration variants.
  Use for 小红书视频脚本, 分镜, 口播, 录屏规划, or deciding what to film with a phone versus capture from a screen.
  For publish captions and tags, use `xhs-note-writer` with `format=video` after the script is ready.
---

# Xiaohongshu Video Director

Create an executable 9:16 video plan, not only a voiceover paragraph.

Read `../references/format-playbook.md`. Pair with `xhs-note-writer` (`format=video`) for publish captions and `xhs-visual-lab` (`mode=video_first_frame`) for the opening frame brief.

If the user uploaded video scripts to `~/.xhs/style-library/`, use them for **spoken tone and pacing** only; captions still come from `xhs-note-writer`.

## Workflow

1. Define the audience problem, promised result, available proof, and target duration.
2. Choose the visual grammar:
   - Phone footage for emotion, physical context, hands, face, and credibility.
   - Native screen recording for UI details and reproducible operations.
   - Graphic cards for comparisons, rankings, and process transitions.
3. Open with conflict, surprising result, or visible proof within the first three seconds.
4. Reveal the main result before explaining the background.
5. Demonstrate one complete task instead of listing every feature.
6. Insert proof: before/after, output, failure case, time comparison, or actual data.
7. Close with a useful conclusion and a specific discussion or next-episode prompt.
8. Produce the shot table from `references/shot-schema.md`.

## Production Rules

- Default mix: 20-30% phone footage, 55-70% screen recording, 10-15% graphic cards.
- Never film a computer display with a phone when native screen capture is possible.
- Keep on-screen text to one idea and roughly 8-12 Chinese characters per line.
- Cut or change framing every 1.5-3 seconds when the information changes.
- Avoid unsupported performance claims and fake app interactions.

## Output

Return: 3 hook options, selected concept, continuous spoken script, timestamped shot table, capture checklist, cover/first-frame copy, and 30/60/90-second trimming guidance.

