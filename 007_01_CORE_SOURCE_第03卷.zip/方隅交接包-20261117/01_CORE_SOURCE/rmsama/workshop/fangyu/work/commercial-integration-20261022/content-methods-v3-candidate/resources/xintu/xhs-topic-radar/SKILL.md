---
name: xhs-topic-radar
description: >-
  Research and rank Xiaohongshu topic opportunities using Just One API search results, optional WebSearch fallback,
  account DNA, and evidence-bounded analysis. Use for 选题, 选题雷达, 发什么, 下一篇写什么, 小红书热点, 关键词选题.
---

# Xiaohongshu Topic Radar

Find evidence-backed topic candidates that fit a specific account. This is research, not generic brainstorming.

Read `../references/justone-api.md` and `../references/websearch-fallback.md`.

## Step 0: probe data source

```bash
test -n "$JUSTONE_API_TOKEN" && echo "justone=set" || echo "justone=missing"
```

| State | Route |
|---|---|
| `justone=set` | Just One API via `scripts/fetch_topic_evidence.py` |
| `justone=missing` or API failure | **WebSearch fallback** — continue workflow, label `data_unverified` |

Do not stop with only a "please configure API" message. WebSearch fallback must still produce bounded candidates.

## Workflow

1. Read account DNA when available; otherwise collect one-sentence direction and audience.
2. Define 1-3 focused search terms. Avoid broad keyword grids.
3. Collect evidence:
   - **Primary**: Just One API
   - **Fallback**: WebSearch (`site:xiaohongshu.com <关键词>`)
4. Map records to `references/evidence-schema.md`. Include `data_source` on every row.
5. Separate engines when applicable:
   - Keyword candidates from search results
   - Account anomalies only when user supplies competitor data or optional external monitor output
6. Deduplicate, cluster by audience problem / promise / format / proof style.
7. Rank by account fit, freshness, evidence strength, distinctiveness, producibility.
8. Produce adapted topics without copying titles or creator-specific experiences.

## Just One API command

Keep the token in the shell profile or a `.env` file, never inline in a command the user will paste.

```bash
python3 scripts/fetch_topic_evidence.py \
  --keyword "AI工具" \
  --keyword "Cursor skill" \
  --count 10 \
  --pages 2 \
  --detail \
  --output ~/.xhs/topic-evidence/latest.json
```

| Flag | Note |
|---|---|
| `--count` | Notes kept per keyword **after** ranking; detail calls only run on kept notes |
| `--pages` | Search pages to scan (1-5); raise this when `--count` exceeds one page |
| `--note-type` | `VIDEO_NOTE` / `NORMAL_NOTE` when format matters, else `ALL` |
| `--time-filter` | `ONE_WEEK` default for trend work; widen to `HALF_YEAR` for evergreen topics |
| `--detail` | Adds a billed request per kept note; skip it when titles and metrics suffice |

Exit code `2` means zero usable notes — switch to WebSearch fallback rather than retrying.

## WebSearch fallback rules

- Record title, URL, snippet only
- No invented likes/comments/dates
- Add disclaimer: `数据源：WebSearch 兜底｜无互动数`
- Confidence for engagement claims = none

## Evidence rules

- Never invent views, likes, dates, comments, or body text
- Missing metrics stay missing, not zero
- One search is not a platform-wide trend
- Label inference and confidence explicitly

## Output

Return up to 10 candidates with:

- evidence table (`data_source` column required)
- inferred pattern
- account fit
- freshness
- production cost
- adaptation angle
- one recommended next topic
- data limitation note when fallback was used
