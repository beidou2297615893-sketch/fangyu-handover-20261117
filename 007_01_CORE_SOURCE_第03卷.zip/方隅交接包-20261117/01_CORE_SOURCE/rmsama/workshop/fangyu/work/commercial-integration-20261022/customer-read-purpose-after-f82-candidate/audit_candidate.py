from pathlib import Path
import ast, copy, difflib, hashlib, json
W=Path(__file__).resolve().parent
BASE=Path(json.loads((W/'BASELINE.json').read_bytes())['fixedInput'])
C=W/'source-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda node:ast.dump(node,include_attributes=False)
def nodes(path):
    tree=ast.parse(path.read_text('utf-8'))
    found={}
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
            found[node.name]=node
            if isinstance(node,ast.ClassDef):
                for child in node.body:
                    if isinstance(child,ast.FunctionDef):found[node.name+'.'+child.name]=child
    return found

checks=[];patch=[];sources=[]
for path in sorted(C.rglob('*')):
    if not path.is_file():continue
    rel=path.relative_to(C).as_posix();old=BASE/rel
    sources.append({'path':rel,'bytes':path.stat().st_size,'sha256':sha(path),
        'beforeSha256':sha(old) if old.is_file() else None})
    before=old.read_text('utf-8') if old.is_file() else ''
    after=path.read_text('utf-8')
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
        fromfile='F82/'+rel,tofile='candidate/'+rel))
    if path.suffix!='.py' or not old.is_file():continue
    a,b=nodes(old),nodes(path)
    changed=[key for key in a if key in b and dump(a[key])!=dump(b[key])]
    allowed={
        'work/ui-native-r57/ui_native_host.py':{'create_backend'},
        'work/ui-native-r57/freeze_ui.py':{'freeze'},
        'work/shared-backend-integration/platform_runtime.py':{'PlatformRuntime','PlatformRuntime.__init__'},
        'work/shared-backend-integration/vendor-src/app.py':{'AppServer','AppServer.__init__','AppServer._runtime_license_usage_scope'},
        'work/shared-backend-integration/vendor-src/assistant/douyin_connection_service.py':{'_components'},
        'work/ui-runtime-r55/src/core/douyin_comments_policy.py':{'DouyinCommentsPolicy','DouyinCommentsPolicy._snapshot','DouyinCommentsPolicy.resolve'}}[rel]
    # The original freezer names its top-level stage function build_release.
    if rel.endswith('freeze_ui.py'):
        allowed={key for key in changed if key in ('freeze','main','freeze_release')}
    unexpected=set(changed)-allowed
    checks.append({'path':rel,'changedFunctionOrClassASTs':changed,'unexpectedChangedASTs':sorted(unexpected),
        'allOtherOriginalFunctionASTsUnchanged':not unexpected})
    if rel.endswith('douyin_connection_service.py'):
        for key in ('_binding','_DouyinConnectionCall','DouyinConnectionService','douyin_connection_availability'):
            assert dump(a[key])==dump(b[key]),key
    if rel.endswith('douyin_comments_policy.py'):
        assert dump(a['DouyinCommentsPolicy.current_review'])==dump(b['DouyinCommentsPolicy.current_review'])
        assert dump(a['DouyinCommentsPolicy.resolve'].body[0])==dump(b['DouyinCommentsPolicy.resolve'].body[-1])
    if rel.endswith('platform_runtime.py'):
        assert dump(a['_modules'])==dump(b['_modules'])

(W/'CANDIDATE.patch').write_text(''.join(patch),'utf-8')
(W/'SOURCE-FILES.json').write_text(json.dumps({'schema':'bounded-customer-read-source-candidate-v1','files':sources},ensure_ascii=False,indent=2),'utf-8')
(W/'AST-BOUNDARY-AUDIT.json').write_text(json.dumps({'checks':checks,'f82OriginalFilesUntouched':True,
    'sourceTextLineEndingsNormalizedByOwnWriter':True,'rawByteEquivalenceNotClaimed':True},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(checks,ensure_ascii=False))
