from pathlib import Path
W=Path(__file__).parent;C=W/'candidate'
def replace(path,old,new):
    p=C/path;t=p.read_text('utf-8');assert t.count(old)==1,(path,t.count(old));p.write_text(t.replace(old,new),'utf-8')
replace('work/ui-runtime-r55/src/assistant/ai_workflow.py',
    '    def correct(self, user, lead, data):\n',
    '''    def correct(self, user, lead, data):
        if 'expected_version' in data:
            from .intent_correction import apply
            return apply(self.core,user,lead,data)
''')
for rel in ('work/ui-runtime-r55/src/assistant/business.py','work/shared-backend-integration/vendor-src/assistant/business.py'):
    replace(rel,"        if action=='lead_detail':\n",'''        if action=='intent_correct' and 'expected_version' in data:
            # A local manual correction uses the already-authenticated employee;
            # never revive a disabled user or acquire any platform session here.
            user=self.principal(command,read_only=True)
            lead=self.core._get('leads',data.get('lead_id'),self.tenant)
            self._lead_access(user,lead)
            return self.ai.correct(user,lead,data)
        if action=='lead_detail':
''')
replace('work/ui-native-r57/ui_native_host.py',
    "'customer_handoff_read','customer_handoff_save','customer_memo_export',",
    "'customer_handoff_read','customer_handoff_save','customer_memo_export','customer_intent_read','customer_intent_correct',")
replace('work/ui-native-r57/workbench_backend.py',
    "'customer_handoff_read','customer_handoff_save','customer_memo_export'})",
    "'customer_handoff_read','customer_handoff_save','customer_memo_export','customer_intent_read','customer_intent_correct'})")
replace('work/ui-native-r57/workbench_backend.py',
    "        selected_platform=_optional_platform(data)\n        with self.lock:\n            user, profile = self._identity(token)\n",
    "        selected_platform=_optional_platform(data)\n        with self.lock:\n            user, profile = self._identity(token)\n") if False else None
# Keep routing before the old customer field allowlist. Each new action has an
# exact allowlist in the narrow bridge and still uses the same fresh identity.
replace('work/ui-native-r57/workbench_backend.py',
    "    def _customer_dispatch(self, action, data, token):\n",'''    def _customer_dispatch(self, action, data, token):
        if action in ('customer_intent_read','customer_intent_correct'):
            return self._customer_intent_dispatch(action,data,token)
''')
replace('work/ui-native-r57/workbench_backend.py',
    "    def _rule_bundle_dispatch(self, action, data, token):\n",'''    def _customer_intent_dispatch(self,action,data,token):
        from customer_intent_workbench import IntentCorrectionWorkbench
        from assistant.intent_correction import IntentCorrectionError
        committed=False
        try:
            with self.lock:
                user,profile=self._identity(token)
                store_id=self._selected_store(user,profile)
                if self.customer_workbench is None:
                    raise WorkbenchError('CUSTOMERS_UNAVAILABLE','客户功能尚未装入当前后台',503)
                service=IntentCorrectionWorkbench(self.core,self.customer_workbench,self.company)
                method=service.correct if action=='customer_intent_correct' else service.read
                result=method(user,store_id,data)
                committed=action=='customer_intent_correct'
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('INTENT_SCOPE_CHANGED','当前身份或门店已变化，请重新核对',403)
                return {'intentCorrection':result}
        except Exception as error:
            known=isinstance(error,(IntentCorrectionError,WorkbenchError)) or hasattr(error,'code')
            failure=WorkbenchError('INTENT_RESULT_UNCONFIRMED' if committed else getattr(error,'code','INTENT_READ_FAILED'),
                '判断已保存，请回到原账号和门店查询原操作' if committed else str(error) if known else '人工判断暂不可用，请保留输入',
                409 if committed else getattr(error,'status',503))
            failure.mutation_committed=True if committed else getattr(error,'mutation_committed',False)
            raise failure from None

    def _rule_bundle_dispatch(self, action, data, token):
''')
print('Patched candidate only')
