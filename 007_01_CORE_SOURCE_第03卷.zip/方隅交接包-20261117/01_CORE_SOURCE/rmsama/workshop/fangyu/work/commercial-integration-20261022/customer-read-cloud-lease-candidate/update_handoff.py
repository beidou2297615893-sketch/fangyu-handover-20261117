from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent
P=D.parents[2]
W=D.parent
target=W/'HANDOFF-THREE-IN-ONE-LATEST.md'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(target)
content=f'''

## 2026-10-23 20:15 客户只读链与公开正文的新实质进展

本条写入UTC {datetime.now(timezone.utc).isoformat()}。正式F82/S/F/N/安装包保持前值；当前C只是root own合版，未经本轮最终冻结安装，不将隔离结果当本人运行成功。

20:08:26只读实核 CURRENT-STATUS-20261023T120826Z.json：63055 HTTP200仍F79，3账号、1888评论、40任务（5ready/35paused/0running），1794 AI/1465评估/4历史reply。无客户或会话写，未重启本人窗。outputs/整合进度/现在可以做什么.md已更新20:08，明确目前未采集、可看高意向/核原文/存草稿，未称全量完成。

根因进一步实证：旧Core/Runner/云员工授权只接受1.1.8-pilot.1+portable，普通r57标准版不应伪装成pilot或移除admin源标记。root固定新独立 customer_read_release 合同，版本1.2.0-read.1，45秒只读RAM租约；保旧employee/general/send/remotecommand语义及global releaseApproved=false。固定spec CUSTOMER-READ-LEASE-SPEC.json SHA18071d2e8609dbd15369488239157689ebf8a15251465974522c83b703503055；HANDSHAKE-ADDENDUM.md补充pair_create/enroll也附相同version/protocol，仅元数据，真实lease只来自原认证heartbeat。

root W/customer-read-cloud-lease-candidate/cloud-candidate-final：实际原createService五源最小接线，默认开关false。test_customer_read_cloud.cjs 实际10组/43原服务请求通过：新admin/operator真login→pair→一次配对→enroll→poll、完整限时lease、错协议/版本/公司/禁用/撤销/令牌/过期拒、remote task_run和reply/queue仍423、旧operator pilot heartbeat和状态原新版deep-equal。全内存、0实云/平台/生产写。ROOT-SOURCE-SERVICE-REVIEW.json SHA e3148c0451e375511a07b29292118afe18b817c79cda9652ed04efb3d327652a。第一cloud-candidate构造在LF/CRLF断言红退出保留，仅新cloud-candidate-final修自己constructor，不改断言/生产。

实云只读CAS遇外部登录断点：旧原PowerShell CLI失败，已用同一已装官方tcb3.5.5+fixed Node直argv确认，DIRECT-SDK-READBACK.json 信号login/credential=True、JSON/network/permission=False。不存raw/令牌/临时URL；未部署、未改环境、未读私库。不反复重试、不造readback、不新申请密钥；本人依赖保断点后继续本地。代码包在自有code-package构造（exec68054待终态），保持旧5616基准，仅四旧源和一新增源；两新非秘密开关尚未上线，不宣称已连线上。

原schedule已封重绑helper W/customer-review-rebinding-helper：customer_review_rebinder.py SHA0f866f5a8cf6c72b11797411122d0169389ed68237f09100dd2dfb1b54ed2f45，FINAL94b0c9da9be9a1e0c6bd9fe228c66be876f1462ebcf0109180c63d641e34881f。4纯检查+1 compiled原factory7案例green；只原2DY purpose，后继新registry/lease必须按实际schema适配，不能盲用或嵌主EXE hash环。junction已安全仅去自有链接、target/sentinel前后不变，旧sealed未动。

三个agent仍真实live，不重复开：
- knowledge_review_4：新XHS customer CLI继承原1592 PYZ/53许可，7写/private等真实EXE拒绝、无实平台；旧employee prototype已保留不混新链。新独立helper/Runner/Service/Runtime等7源shared-read-lease-qa-v1固定（INTERFACE SHA f4c82e9b629c8af2afd88e6aa2e21aac050ed40171e9de4ddc92b877907e4932），新原factory3组、17错shape等负例green；Core/general仍False、Runner portable=False/accept_commands=False、默认executor拒、显式read purpose过。自然3未有材料仍False。自有真实原云createService Node桥PID70216/port52204、exec93580正在跑完整新握手，不是实云。当前manual_permission_snapshot仅manual mode、普通模式false，不会消费旧snapshot续租；不改只读snapshot API。冻结需补customer-read原许可txt安全复制，依赖pin以其最终候选为准。
- experience_independent_review：W/douyin-search-customer-after-f82-candidate 实际原inner链PASS9、21 Node CLI+完整Bridge/userscript VM，入库1、换账号同评论0新/1dup、已有分析不重算；unknown原页重开/换conn 0重派、引号/offset/cursor/租约/OS锁/通道锁/其他账号reply锁均通过，93068终态0。INNER-CHAIN-RECEIPT SHA935ac8958f4ebf26c21d056afd1b3b596b17e9024f43a14c88604a1917eb4f01。后续当前6源纯task_save原factory PASS7，32230终态0，0CLI/模型/自动run，5状态注入拒；缺新helper task_run拒。新current(search/comments)每次重验，正接knowledge固定shared与真createService；旧PASS9不覆盖新lease字节。原task.last_message同步第一页边界，不能伪装整任务完成。
- schedule_finish_4：转 W/general-public-article-after-f82-candidate。root先实际GitHub/npm原源选型：轻量JSDOMParser五样本3红不选；现有Bridge Node22.23.2兼容jsdom30.1.3，原Readability+jsdom五样本全绿，36纯JS包/约21.56MBraw、zip5.09MB，无新Node/GPU/模型。agent固定Node worker5绿，128MB+permission只vendor+无child/workers/主动禁网/6秒杀；早初始化stdio修Windows Socket管道误拦红，未放宽网络。provider固定node/tree前后hash与一次严格HTTPS文字读取3组绿，原generic8/微信7/query10工厂已起跑；headless/UI待其完成。7原源局部+1869 vendor文件，不改customer/Core/Store。原QA freeze2413资源少4旧外部许可系own参数差异待明列，root正式C548基准不可丢。不把通用parser本地绿当实外页或JS/登录墙可用。

根root没有停止目标/取消18范围。ASR引擎与本人Native/平台/第二机仍外部门；不新付费密钥、不下载模型、不真实发送、不绕核验；本人窗口/数据/12其他店保持。后继先看真实exec终态再合新源，统一SOURCE/内部reviews/DM/registry/新lease材料依赖，真正普通编译闭环和线上登录断点必须分开写；不能complete或blocked。
'''
with target.open('a',encoding='utf-8') as f:f.write(content)
receipt={'utc':datetime.now(timezone.utc).isoformat(),'beforeSha256':before,'afterSha256':sha(target),'appended':True}
(D/'HANDOFF-APPEND.json').write_text(json.dumps(receipt,indent=2)+'\n','utf-8')
print(json.dumps(receipt))
