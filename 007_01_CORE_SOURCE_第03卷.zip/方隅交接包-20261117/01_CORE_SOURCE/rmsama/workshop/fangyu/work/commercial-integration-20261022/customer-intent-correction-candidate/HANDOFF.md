# 人工纠错候选：最终审查交接

状态：可供 root 合并的独立候选，尚未接入正式 S、冻结新版或安装。目录所有权已经交还 root；不要整体覆盖 Native 目录。

## 最小合并范围

`integration.patch` 为 v66 保存基线上的 **9 文件、18 个 hunk**。具体基线/最终摘要和新增行数见 `PATCH-MANIFEST.json`；最终文件摘要见 `FINAL-FILES-SHA256.json`。其中两份新文件：

- `work/ui-runtime-r55/src/assistant/intent_correction.py`：原 records 库内原子人工判断、回执、取消墓碑和 AI 末端 CAS。
- `work/ui-native-r57/customer_intent_workbench.py`：原客户详情范围 → 原 Business.intent_correct → 原 LocalAIWorkflow.correct 的窄桥接。

其余为 r55/vendor 两份 Business 的受约束分支、r55 AIWorkflow 的新分支及写回 CAS、Native action/工厂接线、原客户模块依赖摘要、Host 固定资源加载、Freezer 复制一行。

`workbench_backend.py` 的候选基线是原 v66 `ef4a0604...`。root 已独立合入的四个 v3 内容方法 pins 必须保留；应逐 hunk 合并，不能用候选整文件回退它们。Host/action allowlist 与其他候选可能同一行，保留并集并重算最终摘要。CustomerWorkbench 的三个依赖 pins 及 SOURCE 中 vendor Business 来源 pin 必须对应最终合并字节，由 root 复核后更新。

如用 Git 应用本补丁，使用 `git -c core.autocrlf=false apply` 保留原字节；Windows 用户级 autocrlf 默认会转换新文件行尾，导致最终摘要与验收候选不一致。不要改全局 Git 配置。两种基线的代表检查均使用本次命令级选项。

## 复审新修复

发现普通 `import customer_intent_workbench` 只在测试的 Native sys.path 下成立，真实 launcher 以固定字节 exec Host 时并不保证 release 目录可导入。已经改为：Host 从 `RELEASE files` 通过 `read_public(sha,size)` 读取辅助模块，返回局部 class 对象；通过 `customer_intent_factory` 注入 Native。不添加 release sys.path，不注册可串另一版本的全局同名 helper。缺模块时准确拒绝；损坏模块在执行前拒绝。

Freezer 仍只多复制一份辅助文件；其原 LF 行尾已保留。新 helper 包含于 Host 文件白名单与实际集合核对。实际代表检查构造独立合法 RELEASE，运行原 `verify_release` 和新资源 loader，在移除 Native/release sys.path 后，调用实际 helper 完成原 Business → AIWorkflow → SQLite 保存；篡改资源立即拒绝。

## 验证证据

- 保存的 `BEHAVIOR-RESULT.json` / `BEHAVIOR-VENDOR-RESULT.json`：r55/vendor 各 18 项，覆盖双 Core / 双 SQLite 连接的保存竞争、AI 竞争、原键恢复、取消墓碑、跨账号同客与跨店隔离。
- 本次最终 `HTTP-RESULT.json` / `HTTP-VENDOR-RESULT.json`：r55/vendor 各 6 组通过；实际 Host / Native / Business / AIWorkflow / 原 SQLite，只有员工身份及发布配置为合成权威输入。Host 工厂注入字段同步于测试，纠错并未 mock。
- 本次 `FINAL-REVIEW-RESULT.json` / `FINAL-REVIEW-VENDOR-RESULT.json`：各 5 项通过：saved/cancelled 原回执跨有效范围拒绝；最后 audit 插入失败时保存/取消全回滚；真实缓存分析及旧 correct 返回合同；无关元数据 CAS 冲突仍待分析且下一同缓存提交；冻结资源在无 Native sys.path 下加载与坏哈希拒绝。
- `PATCH-APPLY-RESULT.json`：最小 patch 在纯 v66 源码副本、以及 root 四个新 v3 内容 pins 的源码副本上各 9 文件检查/应用一致；不修改真实 S。
- `DIGEST-VECTORS.json` 与 UI 的 20 项测试由 UI 候选另行接入；这里不冒称实际 CUA/真实模型/真实平台验证。

## 对全 body CAS 的结论

保留 `current != before`，因为旧快照整条写回会抹掉另一 Core 刚保存的非 AI 字段。`persisted_before` 是最终锁内重新读取，冲突窗口很小。新增实际原 Business 测试证明：另一 Core 在读后只改非 AI 元数据，首次写回被拒绝并返回 `analyzed=0,pending=1,cache_hits=1`；下一次原 Business 仍选择该条，命中同缓存后返回 `analyzed=1,pending=0,cache_hits=1`，新元数据保留。合成 cloud hook 只收到四次 `ai_profile`，没有模型请求。原 AIWorker 每 15 秒 tick 检查未分析条目，pending 未被终结或移除。持续外部改写可能延后提交，但不会凭此重发模型。

原 `_source_binding` 分支未替换：它已有同事务 `_load/check` 对完整源快照、无 manual_intent 等校验；与人工修改竞争时不会旧写覆盖。旧 `correct` 不带 expected_version 的调用返回单条 lead 合同保留，原 AI 结果不被改写；新 UI 只能走新的严格范围/CAS分支。

## 安全与后续

测试使用本目录临时库；禁止外网、子进程和外部 SQLite，最终审查另加白名单读取与写入围栏。没有读取生产客户库、账号会话或密钥，没有模型/平台调用，没有发送任何评论/私信，没有启动/停止 root 服务。逻辑围栏不等于操作系统沙箱。

辅助生成脚本 `prepare_candidate.py` / `patch_candidate.py` / `complete_candidate_closure.py` 是历史构建步骤，不作为安装入口重跑。合并后由 root 更新所有最终依赖/来源 pins，重新冻结并在新加载的实际版本验收。不要让旧内存中的 AI writer 与新人工纠错 UI 混用；旧进程未重新加载的代码不具备新末端 CAS。

本候选不包含 UI，也不声明所有历史账号数据已可纠错。缺少可核实门店归属的旧评论准确显示待核实，保持旧数据原样；不推断归属。
