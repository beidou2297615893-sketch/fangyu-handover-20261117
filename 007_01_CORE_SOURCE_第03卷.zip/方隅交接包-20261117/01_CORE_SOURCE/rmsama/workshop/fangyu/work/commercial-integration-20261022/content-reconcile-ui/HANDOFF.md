# 内容原结果查询前端交接（停写）

## 改动
只改 U/pages/content-workflow.mjs 与 U/backend.mjs。content-operations.mjs/css 未改，来源 app/acquire/acquisition-source 保持上一轮 SHA。

- running/unknown 原任务，canReconcileTasks=true 且有原 runRequestId 时显示“核对原结果”，说明“查询上次结果，不重新生成”。
- 能力 false 时写明“结果查询尚未开放，原任务与编号已保留”，没有假查询按钮。
- 点击才请求 content_task_reconcile，严格原 task.runRequestId、原 taskId、当前账号平台门店与 expectedRevision；不生成新请求号。
- 先保留持久原编号摘要，写入失败不派发。核对失败、超时、503未开放、编号不符都保留原run断点，不进入本地保存重试、不自动新run。
- 回执必须 action=content_task_run、found=true、requestId和taskId一致、workspace同作用域并且任务状态一致。实际查询结果要求 reconciled/statusChecked=true，modelCalled/newGenerationDispatched=false。
- replayed=true 且终态时允许原普通run回执缺少查询字段；只说“原结果已完成，已读取原回执”，不会把原 modelCalled=true 当本次又调用。
- 成功结果仍需人工采用；未知结果继续保留，归档门禁不变。
- 自动刷新恢复仍仅 content_workspace_read，不主动查询云服务；这些原按钮改称“读取本地执行记录”，区分服务查询。
- 跨账号、门店、平台或authEpoch迟到响应不采用，不清旧作用域持久编号。

## 验证
reconcile-ui-tests.mjs / RESULTS.json：10组 PASS，真实生产前端模块 render/bind + backend，以合成transport测试。覆盖原key、双击只有1次status、unknown保留、候选恢复、终态重放、能力关闭、超时/503/错回执、迟到隔离、自动恢复只读本地、存储失败、running恢复和backend写分类。

保留回归：W/source-interactions-ui/source-ui-tests.mjs 14组PASS；W/content-workflow-ui/archive-ui-unit.mjs 5组PASS。2个修改文件node --check PASS。

没有访问/登录/重启50660，没有调用真实模型、平台、付费服务。未做本轮浏览器视觉验收；root负责Native/CUA。

## CUA代表链
内容运营→任务与结果→选择running/unknown原任务→“核对原结果”。查询中应写“查询上次结果，不重新生成”；结果unknown不能run/归档；结果succeeded后只开放人工采用。默认adapter无status时，应只有未开放说明。

## 哈希
PRODUCT-FILES.json记录本轮2文件最终SHA；before保留改前文件。当前已停写。
