from pathlib import Path
import json,os,shutil,subprocess,hashlib,traceback
W=Path(__file__).resolve().parent;B=W/'own-compiled';D=B/'dist/FangyuWorkbench';cases=json.loads((W/'SCENARIOS.json').read_bytes())
assert not (D/'qa-scenarios').exists();shutil.copytree(B/'payload/qa-scenarios',D/'qa-scenarios')
results=[];passed=False
try:
 for case in cases:
  env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV')}
  for key in ['TEMP','TMP','LOCALAPPDATA','APPDATA']:
   p=B/'run-environment'/case['name']/key;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
  env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
  with (B/('run-'+case['name']+'.log')).open('x',encoding='utf-8') as log:r=subprocess.run([str(D/'FangyuWorkbench.exe'),'--case',case['name']],cwd=D,env=env,creationflags=subprocess.CREATE_NO_WINDOW,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  paths=list(D.glob('case-'+case['name']+'-*/RESULTS.json'));assert len(paths)==1,paths
  data=json.loads(paths[0].read_bytes());results.append({'case':case['name'],'exitCode':r.returncode,'result':data,'evidence':str(paths[0].relative_to(W)).replace('\\','/')})
  (W/'CASE-RESULTS.json').write_text(json.dumps({'status':'IN_PROGRESS','cases':results},ensure_ascii=False,indent=2)+'\n','utf-8')
  assert r.returncode==0 and data['status']=='PASS',(case['name'],data)
 passed=True
finally:
 final={'status':'PASS' if passed else 'RED','actualCompiledCases':len(results),'baseline':1,'redToGreenPairs':3,'cases':results,'exeSha256':hashlib.sha256((D/'FangyuWorkbench.exe').read_bytes()).hexdigest(),'compileCount':1,'realCloudModelPlatform':0,'allCaseProcessesExited':True}
 if __import__('sys').exc_info()[0]:final['error']=traceback.format_exc()
 (W/'CASE-RESULTS.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n','utf-8')
 print(json.dumps({'status':final['status'],'cases':len(results),'redToGreenPairs':3}))
