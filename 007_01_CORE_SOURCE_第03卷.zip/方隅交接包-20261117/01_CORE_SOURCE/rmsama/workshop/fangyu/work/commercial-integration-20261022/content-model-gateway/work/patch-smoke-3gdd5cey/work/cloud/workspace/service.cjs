/* Dedicated-company CloudBase HTTP service. No platform credentials enter this API. */
const crypto = require('node:crypto');
const {handleDevices}=require('./devices.cjs');
const {devicePermissionSnapshot}=require('./device_permission_snapshot.cjs');
const {MAX_BATCH, upsertBatch,readLead}=require('./shared_leads_v2.cjs');
const {SHARED_FEATURE_ENABLED}=require('./shared_feature.cjs');
const {createEnterpriseAi, OPERATIONS: AI_OPERATIONS}=require('./ai_enterprise.cjs');
const {createContactLedger, OPERATIONS: CONTACT_OPERATIONS}=require('./contact_ledger.cjs');
const {createHandoffLedger, OPERATIONS: HANDOFF_OPERATIONS}=require('./handoff-ledger.cjs');
const {createBusinessReconciliation,OPERATIONS: RECONCILIATION_OPERATIONS}=require('./business_reconciliation.cjs');
const {createChannelCandidates,OPERATIONS: CANDIDATE_OPERATIONS}=require('./channel_candidates.cjs');
const {createSourceBinding,OPERATIONS: SOURCE_BINDING_OPERATIONS}=require('./source_binding.cjs');
const {createContactDelivery,OPERATIONS:CONTACT_DELIVERY_OPERATIONS,STATUS:CONTACT_DELIVERY_STATUS}=require('./contact_delivery.cjs');
const {createProductEntitlements,ProductEntitlementError}=require('./product_entitlements.cjs');
const {SharedStoreScopeError,scopeFor,visible,projectLead,rejectClientScope,prepareLead}=require('./shared_store_scope.cjs');
const CONTRACT = 'fangyu-workspace-v1';
const validMemberStore=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,80}$/.test(value);
const memberGrant=u=>!!u&&!u.disabled&&u.role==='operator'&&validMemberStore(u.store_id)
  &&u.store_member_management?.version==='store-members-v1'&&u.store_member_management.store_id===u.store_id
  &&typeof u.store_member_management.granted_by==='string'&&!!u.store_member_management.granted_by;
const publicUser = u => ({username: u.username, role: u.role, disabled: !!u.disabled, can_reply: u.can_reply !== false,
  ...(u.store_id?{store_id:u.store_id}:{}),can_manage_store_members:memberGrant(u)});
function memberScope(user,sessionDigest,companyId){
  if(user.role!=='admin'&&!memberGrant(user))return null;
  const type=user.role==='admin'?'company':'store',store_id=type==='store'?user.store_id:'';
  return {version:'store-members-v1',actor:{username:user.username,role:user.role},
    scope:{type,store_id,stamp:hash(JSON.stringify([companyId,user.username,user.role,store_id,
      user.store_member_management||null,sessionDigest]))},operations:['create','update']};
}
const memberCanEdit=(scope,actor,row)=>scope.scope.type==='company'||row.role==='operator'
  &&row.store_id===scope.scope.store_id&&row.username!==actor.username&&!memberGrant(row);
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const ACCESS_SECONDS = 8 * 3600;
const REMEMBER_IDLE_SECONDS = 30 * 86400;
const REMEMBER_ABSOLUTE_SECONDS = 90 * 86400;
const validDeviceId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{16,100}$/.test(value);
const validRefresh = value => typeof value === 'string' && /^rd_[A-Za-z0-9_-]{40,100}$/.test(value);
const passwordHash = (password, salt) => crypto.scryptSync(password, salt, 64).toString('hex');
function validatePassword(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) throw new Error('密码需要 12 至 256 个字符');
}
function validateUsername(name) {
  if (typeof name !== 'string' || !/^[a-zA-Z0-9_.@-]{3,80}$/.test(name)) throw new Error('用户名需要 3 至 80 位字母、数字或 _.@-');
}
function createUser(username, password, role) {
  validateUsername(username); validatePassword(password);
  const salt = crypto.randomBytes(24).toString('hex');
  return {username, role, salt, digest: passwordHash(password, salt), disabled: false};
}
function cleanLead(item) {
  if (!item || typeof item !== 'object') throw new Error('客户格式错误');
  const allowed = {platform: 40, source_id: 300, author: 120, author_id: 160, text: 3000, url: 1000, grade: 10, reason: 300, content_title: 300, content_author: 120, published_at: 40, region: 120, comment_id: 160, parent_id: 160, reply_status: 40};
  const out = {};
  for (const [key, limit] of Object.entries(allowed)) out[key] = typeof item[key] === 'string' ? item[key].slice(0, limit) : '';
  if (!['xiaohongshu', 'douyin', 'kuaishou', 'weibo', 'wechat_channels'].includes(out.platform) || !out.source_id) throw new Error('客户来源标识不完整');
  if (out.url && !/^https?:\/\//.test(out.url)) throw new Error('来源链接格式错误');
  out.comment_level = item.comment_level === 2 ? 2 : 1;
  out.id = hash(out.platform + '\n' + out.source_id);
  return out;
}
function createService({store, environmentId, companyId, initialAdmin, initialPassword, initialUser, clock = Date.now,
 releaseApproved = false, releaseVersion = '', pairingApproved = false, pairingVersion = '', employeeReleaseEnabled = false, employeeReleaseVersion = '', platformQaDeviceId = '', qaContinuousUntil = 0, continuousReadonlyDeviceId = '', sharedFeatureEnabled = SHARED_FEATURE_ENABLED, aiProvider, aiRetryDelay, productAccessPolicy, servicePeriod, contactDeliveryProvider=null, contactRetentionSeconds=null,contentGeneration=null}) {
  if (!environmentId || !companyId) throw new Error('缺少环境 ID 或公司隔离 ID');
  const reply = (status, data) => ({status, data: {contract: CONTRACT, environment_id: environmentId, company_id: companyId, ...data}});
  const productEntitlements=createProductEntitlements({companyId,clock,productAccessPolicy,servicePeriod});
  const enterpriseAi = createEnterpriseAi({store, companyId, environmentId, clock, provider: aiProvider, retryDelay: aiRetryDelay,productEntitlements,contentGeneration});
  const contactLedger = createContactLedger({store, companyId, clock});
  const handoffLedger = createHandoffLedger({store, companyId, environmentId, clock,productEntitlements});
  const reconciliation = createBusinessReconciliation({store,companyId,clock,handoffLedger});
  const channelCandidates=createChannelCandidates({store,companyId,clock,handoffLedger});
  const sourceBinding=createSourceBinding({store,companyId,clock});
  const contactDelivery=createContactDelivery({store,companyId,environmentId,clock,provider:contactDeliveryProvider,
    retentionSeconds:contactRetentionSeconds,handoffLedger,productEntitlements});
  return async function handle(payload, bearer = '') {
    const readonlyDeviceSnapshot=payload?.operation==='device_permission_snapshot';
    const contactDeliveryRequest=CONTACT_DELIVERY_OPERATIONS.has(payload?.operation);
    const readonlyHandoffStatus=payload?.operation==='acquisition_handoff_operation_status';
    const readonlyHandoffDetail=payload?.operation==='acquisition_handoff_detail';
    const readonlyHandoffList=payload?.operation==='acquisition_handoff_list';
    const readonlySourceBinding=payload?.operation==='acquisition_source_binding_read';
    const readonlyContentStatus=payload?.operation==='content_generate_status';
    const readonlyPureQuery=readonlyHandoffStatus||readonlySourceBinding||readonlyHandoffDetail||readonlyHandoffList||readonlyContentStatus;
    const readonlyFailure=readonlyDeviceSnapshot?{purpose:'device_permission_snapshot',schema:'device-permission-snapshot-v1',read_only:true,mutation_committed:false,command_claimed:false,auto_retry:false}
      :contactDeliveryRequest?{read_only:payload?.operation===CONTACT_DELIVERY_STATUS,mutation_committed:false,auto_retry:false}
      :readonlyHandoffStatus?{read_only:true,mutation_committed:false,original_execution_confirmed:null,auto_retry:false}
      :readonlySourceBinding||readonlyHandoffDetail||readonlyHandoffList?{read_only:true,mutation_committed:false,auto_retry:false}:{};
    if (!payload || payload.environment_id !== environmentId) return reply(400, {error: '环境 ID 不匹配',...readonlyFailure});
    if (payload.operation === 'health' && !bearer) return reply(200, {ok: true});
    let initial = null;
    const result = await store.transaction(async (stored, dbTransaction) => {
      const now = Math.floor(clock() / 1000);
      if (!stored) {
        if(readonlyContentStatus)return {state:stored,result:reply(503,{code:'AI_CONTENT_STORAGE_UNAVAILABLE',
          error:'原内容请求存储尚不可读，请保留原编号',read_only:true,mutation_committed:false,auto_retry:false})};
        if(payload.operation==='health'&&bearer)
          return {state:stored,result:reply(503,{code:'AUTH_SCOPE_REQUIRED',read_only:true,mutation_committed:false,auto_retry:false})};
        if(handoffLedger.ownerOrigin.classify({sessions:[],users:[]},payload,bearer)==='owner')
          return {state:stored,result:reply(503,{code:'UNCONFIGURED',read_only:true,mutation_committed:false,auto_retry:false})};
        if(readonlyDeviceSnapshot)return {state:stored,result:reply(503,{code:'DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE',...readonlyFailure})};
        if(contactDeliveryRequest)return {state:stored,result:reply(503,{error:'公司联系方式存储尚不可读，本次未交付',
          code:'CONTACT_DELIVERY_STORAGE_UNAVAILABLE',...readonlyFailure})};
        if(readonlyHandoffList)return {state:stored,result:reply(503,{error:'公司收件清单尚不可读，请保留原渠道编号',
          code:'HANDOFF_LIST_UNAVAILABLE',...readonlyFailure})};
        if(readonlyHandoffDetail)return {state:stored,result:reply(503,{error:'公司原渠道详情尚不可读，请保留原交接编号',
          code:'HANDOFF_DETAIL_UNAVAILABLE',...readonlyFailure})};
        if(readonlySourceBinding)return {state:stored,result:reply(503,{error:'公司原来源尚不可读，请保留原准备',
          code:'SOURCE_BINDING_STORAGE_UNAVAILABLE',...readonlyFailure})};
        if(readonlyHandoffStatus)return {state:stored,result:reply(503,{error:'公司原操作回执尚不可读，请保留原编号',
          code:'HANDOFF_STORAGE_UNAVAILABLE',read_only:true,mutation_committed:false,original_execution_confirmed:null,auto_retry:false})};
        if (!initial) initial = initialUser ? structuredClone(initialUser) : createUser(initialAdmin, initialPassword, 'admin');
        stored = {companyId, revision: 0, users: [initial], sessions: [], rememberedDevices: [], attempts: {}, items: [], audit: []};
      }
      if (stored.companyId !== companyId) return {state: stored, result: reply(403, {error: '公司隔离检查失败',...readonlyFailure})};
      const originClass=handoffLedger.ownerOrigin.classify(stored,payload,bearer);
      if(originClass==='blocked')return {state:stored,result:reply(403,{code:'AUTH_SCOPE_REQUIRED',error:'合作来源会话仅限原资料包范围',mutation_committed:false,auto_retry:false})};
      if(originClass==='owner')return {state:stored,result:{_ownerOriginRequest:true}};
      if(payload.operation==='health')return {state:stored,result:reply(200,{ok:true})};
      if(readonlyDeviceSnapshot){
        const snapshot=devicePermissionSnapshot({state:stored,payload,bearer,now,companyId,releaseApproved,releaseVersion,pairingApproved,pairingVersion,employeeReleaseEnabled,employeeReleaseVersion,platformQaDeviceId,qaContinuousUntil,continuousReadonlyDeviceId});
        return {state:stored,result:reply(snapshot.status,snapshot.data)};
      }
      const state = structuredClone(stored);
      state.sessions = state.sessions.filter(s => s.expires > now);
      state.rememberedDevices = (state.rememberedDevices || []).filter(d => d.idleExpires > now && d.absoluteExpires > now);
      state.attempts = Object.fromEntries(Object.entries(state.attempts).filter(([, v]) => v.until > now));
      const finish = (status, data) => ({state:readonlyPureQuery||contactDeliveryRequest?stored:state, result: reply(status, {
        ...data,...(readonlyPureQuery||contactDeliveryRequest?(status>=400?readonlyFailure:contactDeliveryRequest?{}:{read_only:true,mutation_committed:false,auto_retry:false}):{})})});
      const audit = (user, operation) => { state.audit.push({user, operation, time: now}); state.audit = state.audit.slice(-300); };
      try {
        if (payload.operation === 'login') {
          const username = String(payload.username || '').slice(0, 80), password = String(payload.password || '');
          // A shared workspace limit also bounds attempts against invented usernames.
          const bucket = hash(username), failures = state.attempts[bucket] || {count: 0, until: now + 300};
          const total = state.attempts.all || {count: 0, until: now + 60};
          if (failures.count >= 8 || total.count >= 40) return finish(429, {error: '登录尝试过多，请稍后再试'});
          const u = state.users.find(x => x.username === username);
          if(u?.role==='origin_partner'||u?.access_class==='owner_origin_only')return finish(403,{code:'AUTH_SCOPE_REQUIRED',error:'合作来源请使用专用资料包登录'});
          const digest = password.length <= 256 ? passwordHash(password, u?.salt || 'invalid-account-fixed-timing-salt') : '';
          if (!u || u.disabled || digest.length !== u.digest.length || !crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(u.digest))) {
            state.attempts[bucket] = {...failures, count: failures.count + 1}; state.attempts.all = {...total, count: total.count + 1};
            return finish(401, {error: '用户名或密码错误'});
          }
          delete state.attempts[bucket];
          const remember = payload.remember_device === true;
          if (remember && !validDeviceId(payload.device_id)) return finish(400, {error: '设备标识无效'});
          const token = crypto.randomBytes(32).toString('base64url'), expires = now + ACCESS_SECONDS;
          const deviceId = remember ? payload.device_id : '';
          if (remember) {
            state.rememberedDevices = state.rememberedDevices.filter(d => d.username !== username || d.deviceId !== deviceId);
            state.sessions = state.sessions.filter(s => s.username !== username || s.deviceId !== deviceId);
            const refreshToken = 'rd_' + crypto.randomBytes(32).toString('base64url');
            const absoluteExpires = now + REMEMBER_ABSOLUTE_SECONDS;
            state.rememberedDevices.push({username, deviceId, digest: hash(refreshToken),
              idleExpires: Math.min(now + REMEMBER_IDLE_SECONDS, absoluteExpires), absoluteExpires});
            state.rememberedDevices = state.rememberedDevices.slice(-200);
            state.sessions.push({digest: hash(token), username, deviceId, expires});
            state.sessions = state.sessions.slice(-200);
            audit(username, 'login');
            return finish(200, {token, expires, device_id: deviceId, refresh_token: refreshToken,
              refresh_idle_expires: Math.min(now + REMEMBER_IDLE_SECONDS, absoluteExpires),
              refresh_absolute_expires: absoluteExpires, user: publicUser(u)});
          }
          state.sessions.push({digest: hash(token), username, expires}); state.sessions = state.sessions.slice(-200);
          audit(username, 'login'); return finish(200, {token, expires, user: publicUser(u)});
        }
        if (payload.operation === 'refresh' || payload.operation === 'refresh_status') {
          if (!validDeviceId(payload.device_id) || !validRefresh(bearer)) return finish(401, {error: '设备登录已过期'});
          const remembered = state.rememberedDevices.find(d => d.deviceId === payload.device_id && d.digest === hash(bearer));
          const rememberedUser = remembered && state.users.find(u => u.username === remembered.username && !u.disabled);
          if (!rememberedUser) return finish(401, {error: '设备登录已过期'});
          if(rememberedUser.role==='origin_partner'||rememberedUser.access_class==='owner_origin_only')return finish(403,{code:'AUTH_SCOPE_REQUIRED',error:'合作来源没有设备续期权限'});
          if (payload.operation === 'refresh') {
            if (!validRefresh(payload.next_refresh_token) || payload.next_refresh_token === bearer)
              return finish(400, {error: '续期参数无效'});
            remembered.digest = hash(payload.next_refresh_token);
            remembered.idleExpires = Math.min(now + REMEMBER_IDLE_SECONDS, remembered.absoluteExpires);
          }
          const token = crypto.randomBytes(32).toString('base64url'), expires = now + ACCESS_SECONDS;
          state.sessions.push({digest: hash(token), username: remembered.username, deviceId: remembered.deviceId, expires});
          state.sessions = state.sessions.slice(-200);
          audit(remembered.username, payload.operation);
          return finish(200, {token, expires, device_id: remembered.deviceId,
            refresh_idle_expires: remembered.idleExpires,
            refresh_absolute_expires: remembered.absoluteExpires, user: publicUser(rememberedUser)});
        }
        const session = state.sessions.find(x => x.digest === hash(bearer));
        const user = session && state.users.find(x => x.username === session.username && !x.disabled);
        if(contactDeliveryRequest){
          if(!user||!['operator','admin'].includes(user.role))return finish(401,{code:'CONTACT_DELIVERY_AUTH_REQUIRED',error:'需有效的当前企业员工会话'});
          const owned=(state.devices||[]).filter(device=>device.owner===user.username&&!device.revoked&&/^[a-f0-9]{64}$/.test(device.digest||''));
          // Remembered-session device binding is authoritative. Legacy sessions
          // without one only resolve a single current owned device; no guessing.
          const device=session.deviceId?owned.find(row=>row.id===session.deviceId):owned.length===1?owned[0]:null;
          if(!device||payload.expected_device_id!==device.id)return finish(403,{code:'CONTACT_DELIVERY_DEVICE_REQUIRED',error:'当前会话设备绑定需核对，本次未交付'});
          return {state:stored,result:{_contactDeliveryRequest:true,identity:{username:user.username,sessionDigest:session.digest,deviceId:device.id}}};
        }
        const deviceResponse=handleDevices({state,payload,bearer,user,now,reply,companyId,releaseApproved,releaseVersion,
          pairingApproved,pairingVersion,employeeReleaseEnabled,employeeReleaseVersion,
          platformQaDeviceId,qaContinuousUntil,continuousReadonlyDeviceId});
        if(deviceResponse)return deviceResponse;
        if (payload.operation === 'contact_events_sync' || payload.operation === 'contact_responses_sync') {
          const device = state.devices?.find(d => !d.revoked && d.digest === hash(bearer));
          const owner = device && state.users.find(u => u.username === device.owner && !u.disabled);
          if (!device || !owner) return finish(401, {error: '设备已撤销或员工已停用', code: 'CONTACT_AUTH_REQUIRED'});
          return {state, result: {_contactRequest: true,
            identity: {username: owner.username, deviceId: device.id, deviceDigest: device.digest}}};
        }
        if (!user) return finish(401, {error: '请重新登录'});
        if(SOURCE_BINDING_OPERATIONS.has(payload.operation))return {state:stored,result:{_sourceBindingRequest:true,
          identity:{username:user.username,sessionDigest:session.digest}}};
        if(['product_entitlement_summary','product_quota_status'].includes(payload.operation)){
          const allowed=payload.operation==='product_entitlement_summary'?['environment_id','operation']:['environment_id','operation','request_id','operation_kind'];
          if(Object.keys(payload).some(k=>!allowed.includes(k)))return finish(400,{code:'PRODUCT_REQUEST_INVALID',error:'服务权益核对参数包含未授权字段'});
          if(!['operator','admin'].includes(user.role))return finish(403,{code:'PRODUCT_AUTH_REQUIRED',error:'需有效的企业成员身份核对'});
          const data=payload.operation==='product_entitlement_summary'
            ?await productEntitlements.summary({state,transaction:dbTransaction})
            :await productEntitlements.status({transaction:dbTransaction,user,key:payload.request_id,operation:payload.operation_kind});
          return finish(200,data);
        }
        if (!sharedFeatureEnabled && (payload.operation === 'list' || payload.operation === 'publish')) {
          return finish(423, {error: 'feature_disabled'});
        }
        // Provider calls happen after this transaction commits; CloudBase may replay
        // transaction callbacks and must never replay a billable network request.
        if (AI_OPERATIONS.has(payload.operation)) return {state:readonlyContentStatus?stored:state, result: {_aiRequest: true,
          identity: {username: user.username, sessionDigest: session.digest}}};
        if (CONTACT_OPERATIONS.has(payload.operation)) return {state, result: {_contactRequest: true,
          identity: {username: user.username, sessionDigest: session.digest}}};
        // Handoff roles and recipients are trusted company configuration. Only
        // this authenticated session identity reaches the ledger, which checks
        // it again inside its transaction before accessing company documents.
        if (HANDOFF_OPERATIONS.has(payload.operation)) return {state:readonlyHandoffStatus||readonlyHandoffDetail||readonlyHandoffList?stored:state, result: {_handoffRequest: true,
          identity: {username: user.username, sessionDigest: session.digest}}};
        if (RECONCILIATION_OPERATIONS.has(payload.operation)) return {state,result:{_reconciliationRequest:true,
          identity:{username:user.username,sessionDigest:session.digest}}};
        if (CANDIDATE_OPERATIONS.has(payload.operation)) return {state,result:{_channelCandidateRequest:true,
          identity:{username:user.username,sessionDigest:session.digest}}};
        if (payload.operation === 'logout') {
          state.sessions = state.sessions.filter(x => x.digest !== hash(bearer)
            && !(session.deviceId && x.username === user.username && x.deviceId === session.deviceId));
          if (session.deviceId) state.rememberedDevices = state.rememberedDevices.filter(d => d.username !== user.username || d.deviceId !== session.deviceId);
          return finish(200, {ok: true});
        }
        if (payload.operation === 'me') return finish(200, {user: publicUser(user)});
        if (payload.operation === 'list') {
          rejectClientScope(payload);
          const sharedScope=scopeFor(user);
          if (state.sharedLeadsMode === 'v2') {
            const cursor = payload.cursor === undefined ? '' : payload.cursor;
            if (typeof cursor !== 'string' || cursor && (!/^[1-9][0-9]*$/.test(cursor) || !Number.isSafeInteger(Number(cursor)))) return finish(400, {error: '清单游标无效'});
            if (payload.revision !== undefined && payload.revision !== state.revision) return finish(409, {error: '清单已更新，请重新读取'});
            return {state, result: {_sharedListPage: true, cursor, revision: state.revision, username: user.username, sessionDigest: session.digest,scopeStamp:sharedScope.stamp}};
          }
          return finish(200, {items: state.items.filter(row=>visible(sharedScope,row)).map(projectLead), revision: state.revision, max_batch: 100});
        }
        if (payload.operation === 'members') {
          const management=memberScope(user,session.digest,companyId);
          if(!management)return finish(403,{error:'没有当前门店人员管理权限',mutation_committed:false});
          const rows=management.scope.type==='company'?state.users:state.users.filter(row=>row.role==='operator'&&row.store_id===management.scope.store_id);
          return finish(200,{users:rows.map(row=>({...publicUser(row),can_edit:memberCanEdit(management,user,row)})),
            member_save_modes:['create','update'],member_management:management});
        }
        if (payload.operation === 'member_save') {
          const management=memberScope(user,session.digest,companyId);
          if(!management)return finish(403,{error:'没有当前门店人员管理权限',mutation_committed:false});
          const manager=management.scope.type==='store';
          if(['store_member_management','member_management','can_edit','member_management_scope'].some(key=>Object.hasOwn(payload,key)))
            return finish(400,{error:'人员管理授权只能由服务器建立',mutation_committed:false});
          const newInterface=manager||Object.hasOwn(payload,'member_scope_stamp')||Object.hasOwn(payload,'can_manage_store_members');
          if(newInterface&&(payload.member_scope_stamp!==management.scope.stamp||!['create','update'].includes(payload.member_mode)))
            return finish(409,{error:'当前人员管理范围已变化，请重新读取成员',mutation_committed:false});
          const {username,password,role}=payload;validateUsername(username);
          if(!['admin','operator','origin_partner'].includes(role))throw new Error('角色无效');
          if(!manager&&username===user.username&&(payload.disabled||role!=='admin'))throw new Error('不能停用自己或取消自己的管理员权限');
          const previous=state.users.find(row=>row.username===username);
          if(payload.member_mode!==undefined&&!['create','update'].includes(payload.member_mode))return finish(400,{error:'成员操作方式无效',mutation_committed:false});
          if(payload.member_mode==='create'&&previous)return finish(409,{error:'用户名已存在，请从成员名单选择编辑；本次没有修改账号',mutation_committed:false});
          if(payload.member_mode==='update'&&!previous)return finish(409,{error:'原成员已不存在，请刷新成员名单；本次没有创建账号',mutation_committed:false});
          if(manager){
            if(role!=='operator'||username===user.username||Object.hasOwn(payload,'can_manage_store_members')
              ||previous&&!memberCanEdit(management,user,previous)
              ||Object.hasOwn(payload,'store_id')&&payload.store_id!==management.scope.store_id
              ||Object.hasOwn(payload,'can_reply')&&payload.can_reply!==(previous?previous.can_reply!==false:false))
              return finish(403,{error:'仅能管理本店普通员工，不能修改授权、角色、门店或回复权限',mutation_committed:false});
          }
          if(previous&&((previous.role==='origin_partner')!==(role==='origin_partner')))throw new Error('合作来源与员工身份不能互相转换');
          if(Object.hasOwn(payload,'can_manage_store_members')&&typeof payload.can_manage_store_members!=='boolean')throw new Error('人员管理授权格式无效');
          let next=previous?{...previous,role,disabled:payload.disabled===true}:createUser(username,password,role);
          if(previous&&password)next={...createUser(username,password,role),disabled:payload.disabled===true};
          if(payload.can_reply!==undefined&&typeof payload.can_reply!=='boolean')throw new Error('回复权限格式无效');
          next.can_reply=manager?(previous?previous.can_reply!==false:false):payload.can_reply===undefined?previous?.can_reply!==false:payload.can_reply;
          next.store_id=manager?management.scope.store_id:payload.store_id===undefined?previous?.store_id||'':payload.store_id;
          if(role==='origin_partner'){
            if(payload.can_reply===true||payload.store_id)throw new Error('合作来源没有回复或门店权限');
            next={...next,access_class:'owner_origin_only',can_reply:false,store_id:'',account_version:(previous?.account_version||0)+1};
          }
          delete next.store_member_management;
          if(!manager&&payload.can_manage_store_members===true){
            if(role!=='operator'||next.disabled||!validMemberStore(next.store_id))throw new Error('仅可授予已启用且绑定门店的员工');
            if(!memberGrant(previous)||previous.store_id!==next.store_id)productEntitlements.requireFeature('team');
            next.store_member_management={version:'store-members-v1',store_id:next.store_id,granted_by:user.username};
          }else if(!manager&&payload.can_manage_store_members===undefined&&memberGrant(previous)
            &&role==='operator'&&!next.disabled&&next.store_id===previous.store_id){
            next.store_member_management={...previous.store_member_management};
          }
          productEntitlements.validateMemberChange(state,next);
          if(!previous&&state.users.length>=100)throw new Error('当前部署支持最多 100 位成员');
          state.users=state.users.filter(row=>row.username!==username).concat(next);
          state.sessions=state.sessions.filter(row=>row.username!==username);
          state.rememberedDevices=state.rememberedDevices.filter(row=>row.username!==username);
          audit(user.username,'member_save');return finish(200,{user:publicUser(next),member_management:management});
        }
        if (payload.operation === 'publish') {
          rejectClientScope(payload);
          const sharedScope=scopeFor(user);
          if (Number.isSafeInteger(state.sharedLeadMigrationOffset) && state.sharedLeadsMode !== 'v2') return finish(423, {error: '企业共享清单迁移中，请稍后重新读取再提交'});
          if (!Number.isSafeInteger(payload.revision) || payload.revision !== state.revision) return finish(409, {error: '清单已更新，请重新读取'});
          const maxBatch = state.sharedLeadsMode === 'v2' ? MAX_BATCH : 100;
          if (!Array.isArray(payload.items) || !payload.items.length || payload.items.length > maxBatch) return finish(400, {error: `每次允许 1 至 ${maxBatch} 位客户`});
          const incoming = payload.items.map(cleanLead);
          if (companyId === 'fangyu-apartment-client' && incoming.some(row => row.platform !== 'xiaohongshu')) {
            return finish(422, {error: '方隅首版只允许共享小红书线索'});
          }
          if (state.sharedLeadsMode === 'v2') {
            if (!dbTransaction) throw new Error('共享清单事务不可用');
            const unique=[];
            // Authorize the entire batch before writing any row. Existing
            // source-store ownership is immutable, including HQ edits.
            for(const row of new Map(incoming.map(row=>[row.id,row])).values()){
              const previous=await readLead(dbTransaction,companyId,row.id);
              unique.push({...prepareLead(sharedScope,row,previous),updatedBy:user.username,updatedAt:now});
            }
            const sequence = state.sharedLeadSequence === undefined ? 0 : state.sharedLeadSequence;
            await upsertBatch(dbTransaction, companyId, unique, sequence);
            state.sharedLeadSequence = sequence + unique.length;
            state.revision++; audit(user.username, 'publish');
            return finish(200, {revision: state.revision, shared: unique.length});
          }
          const map = new Map(state.items.map(x => [x.id, x]));
          for (const row of incoming) map.set(row.id, {...prepareLead(sharedScope,row,map.get(row.id)), updatedBy: user.username, updatedAt: now});
          const items = [...map.values()];
          if (items.length > 1000 || Buffer.byteLength(JSON.stringify(items)) > 1500000) {
            return {state: stored, result: reply(507, {error: '企业共享清单已达当前部署容量（1000 条或 1.5 MB）；本次未上传，请联系管理员扩容'})};
          }
          state.items = items; state.revision++; audit(user.username, 'publish');
          return finish(200, {revision: state.revision, shared: incoming.length});
        }
        return finish(400, {error: '不支持的操作'});
      } catch (e) {
        if(contactDeliveryRequest)return {state:stored,result:reply(503,{code:'CONTACT_DELIVERY_AUTH_UNAVAILABLE',
          error:'当前企业会话暂不可读，本次没有交付或解密',...readonlyFailure})};
        if(e instanceof ProductEntitlementError)return {state:stored,result:reply(e.status,{code:e.code,error:e.message})};
        if(e instanceof SharedStoreScopeError)return {state:stored,result:reply(e.status,{code:e.code,error:e.message,mutation_committed:false,auto_retry:false})};
        // A v2 batch may already have written documents inside the transaction.
        // Throw so CloudBase rolls back the entire batch and revision together.
        if (payload.operation === 'publish' && state.sharedLeadsMode === 'v2') throw e;
        // Do not commit partially changed state after a validation failure.
        return {state: stored, result: reply(400, {error: '请求参数不正确，请核对输入'})};
      }
    }).catch(error=>{
      if(readonlyDeviceSnapshot)return reply(503,{code:'DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE',...readonlyFailure});
      if(contactDeliveryRequest)return reply(503,{code:'CONTACT_DELIVERY_AUTH_UNAVAILABLE',
        error:'当前企业会话暂不可读，本次没有交付或解密',...readonlyFailure});
      if(readonlyHandoffDetail)return reply(503,{error:'公司原渠道详情暂不可读，请保留原交接编号',
        code:'HANDOFF_DETAIL_UNAVAILABLE',...readonlyFailure});
      throw error;
    });
    if(result?._ownerOriginRequest){
      const response=await handoffLedger.ownerOrigin.handle(payload,bearer);
      return reply(response.status,response.data);
    }
    if (result?._aiRequest) {
      const response = await enterpriseAi.handle(payload, result.identity);
      return reply(response.status, response.data);
    }
    if (result?._contactRequest) {
      const response = await contactLedger.handle(payload, result.identity);
      return reply(response.status, response.data);
    }
    if(result?._sourceBindingRequest){
      const response=await sourceBinding.handle(payload,result.identity);
      return reply(response.status,response.data);
    }
    if(result?._contactDeliveryRequest){
      const {expected_device_id:constraint,...contactPayload}=payload;
      const response=await contactDelivery.handle(contactPayload,result.identity);
      return reply(response.status,response.data);
    }
    if (result?._handoffRequest) {
      const response = await handoffLedger.handle(payload, result.identity);
      return reply(response.status, response.data);
    }
    if(result?._reconciliationRequest){
      const response=await reconciliation.handle(payload,result.identity);
      return reply(response.status,response.data);
    }
    if(result?._channelCandidateRequest){
      const response=await channelCandidates.handle(payload,result.identity);
      return reply(response.status,response.data);
    }
    if (result?._sharedListPage) {
      if (!store.listSharedPage) return reply(503, {error: '共享清单分页服务尚未配置'});
      const page = await store.listSharedPage(result.cursor, result.revision, result.username, result.sessionDigest,result.scopeStamp);
      if (!page) return reply(409, {error: '清单已更新，请重新读取'});
      return reply(200, {...page, revision: result.revision, max_batch: MAX_BATCH});
    }
    return result;
  };
}
module.exports = {createService, cleanLead, createUser};
