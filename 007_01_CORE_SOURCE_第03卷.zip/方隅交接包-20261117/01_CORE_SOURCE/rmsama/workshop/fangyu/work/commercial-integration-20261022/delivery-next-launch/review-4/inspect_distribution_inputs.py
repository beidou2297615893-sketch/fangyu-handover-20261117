from pathlib import Path
import ast, importlib.util, json, re, sys
HERE=Path(__file__).resolve().parent
P=HERE.parents[3]
F=P/'work/parallel-integration-20261018/final-integration'
BASE=F/'candidate-unified-v70'
root=BASE/'project'
pins=json.loads((BASE/'UNIFIED-PINS.json').read_text('utf-8'))
imports=set();paths=[];failed=[]
anchor=re.compile(r'(?:[A-Za-z]:[/\\](?:Users|积木)|C:/积木|C:\\\\积木)')
for row in pins['files']:
    path=root/row['path']
    if path.suffix.lower() not in ('.py','.json','.js','.mjs','.md','.txt','.html','.css'):continue
    body=path.read_text('utf-8-sig',errors='replace')
    if anchor.search(body):
        hits=[line.strip()[:220] for line in body.splitlines() if anchor.search(line)]
        paths.append({'path':row['path'],'hits':len(hits),'sample':hits[:2]})
    if path.suffix=='.py':
        try:tree=ast.parse(body)
        except SyntaxError:failed.append(row['path']);continue
        for item in ast.walk(tree):
            if isinstance(item,ast.Import):imports.update(alias.name.split('.')[0] for alias in item.names)
            elif isinstance(item,ast.ImportFrom) and not item.level and item.module:imports.add(item.module.split('.')[0])
stdlib=sorted(name for name in imports if name in sys.stdlib_module_names)
external={}
for name in sorted(imports-set(stdlib)):
    try:external[name]=bool(importlib.util.find_spec(name))
    except (ImportError,ValueError,ModuleNotFoundError):external[name]=False
report={'files':len(pins['files']),'absolutePathText':paths,'stdlibImports':stdlib,'externalAvailable':external,'parseErrors':failed}
(HERE/'INPUT-DISTRIBUTION-INSPECTION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'files':len(pins['files']),'absoluteTextFiles':len(paths),'absolutePython':[r for r in paths if r['path'].endswith('.py')],'stdlibModules':len(stdlib),'externalAvailable':external,'parseErrors':failed},ensure_ascii=True))
