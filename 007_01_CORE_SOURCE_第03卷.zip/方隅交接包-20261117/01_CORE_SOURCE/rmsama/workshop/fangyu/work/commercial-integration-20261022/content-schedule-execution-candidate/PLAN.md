# 内容日历到期执行候选

只写本目录。S/F77/N/outputs/真实数据库、会话保持只读，不运行真实平台或模型。仅按 root 追加授权在本目录由原 freeze_ui --stage 产生 `qa-local-content-schedule-only` 测试快照；不是正式冻结或分发版。

沿原 ContentPublicationWorkbench、Store records、actor/store/account 校验、原 publication slots/AccountModeLeases、原 prepare/confirm/reconcile。新增窄日历模块，不复制发布器、身份库或后台调度程序。

保存固定稿件版本、账号及 UID、带偏移的执行时刻、时区与宽限；本人显式核对后启用固定计划。到期检查只领取本次当前会话授权的项目，以原发布命令执行一次。审批摘要固定时间/版本/账号，RAM grant 不持久保存 token；重开重新启用。改稿/改审核/换账号/超期使原审批失效。未知结果保留原 intent/request，不能暂停取消后换键重发。持久逐项日志、暂停取消与有条件恢复。

预先确认是新明确的日历行为，原 publish_confirm 的快照、humanConfirmed、账号 UID、原权限及 hold 检查保持。默认 WIRE_POLICY=None 无真实发送。队列执行与已发布分开，只有原 verified receipt 才表示成功。

验收 seam 已由 root 指定：原 Native factory HTTP（包括原权限）、实际 Store 持久/并发范围、原 publish 命令与原 key，以及现有内容日历完整 render/bind。先最难链红绿，再 50/100 合成账号负载与隔离；不把合成负载称平台容量。

上游复用：按 social-ops-components 实际读取本地 Yht20927/douyin-cli（4073159bea585de6d33a4747a475669440737932）的 SKILL、MIT、campaign 命令和记忆模块。其固定账号、due task、暂停恢复模式可用；但独立 better-sqlite3 与 detached Node daemon、评论任务语义不符本项目，不引入其第二库/运行器。复用设计并适配既有 Python Store/publication seam。已只读检查 GitHub 主仓及 campaign.js；没有平台动作。
