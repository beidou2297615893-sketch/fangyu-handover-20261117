from pathlib import Path
import hashlib,json,re
W=Path(__file__).parent;C=W/'candidate';S=Path(json.loads((W/'BASELINE.json').read_text('utf-8'))['source'])
baseline=json.loads((W/'BASELINE.json').read_text('utf-8'))
rel='work/ui-native-r57/freeze_ui.py';body=(S/rel).read_bytes()
assert not (C/rel).exists()
(W/'before'/rel).write_bytes(body);(C/rel).write_bytes(body)
baseline['files'].append({'path':rel,'sha256':hashlib.sha256(body).hexdigest()})
(W/'BASELINE.json').write_text(json.dumps(baseline,indent=2),'utf-8')
p=C/rel;t=p.read_text('utf-8');needle="    copy_public(HERE / 'customer_workbench.py', release / 'customer_workbench.py')"
assert t.count(needle)==1
p.write_text(t.replace(needle,needle+"\n    copy_public(HERE / 'customer_intent_workbench.py', release / 'customer_intent_workbench.py')"),'utf-8')
p=C/'work/ui-native-r57/ui_native_host.py';t=p.read_text('utf-8')
t=t.replace("'workbench_backend.py', 'customer_workbench.py',","'workbench_backend.py', 'customer_workbench.py', 'customer_intent_workbench.py',")
t=t.replace("for extra in ('store_materials.py',","for extra in ('customer_intent_workbench.py','store_materials.py',")
p.write_text(t,'utf-8')
p=C/'work/ui-native-r57/customer_workbench.py';t=p.read_text('utf-8')
for name in ('business.py','ai_workflow.py'):
    h=hashlib.sha256((C/'work/ui-runtime-r55/src/assistant'/name).read_bytes()).hexdigest().upper()
    t,n=re.subn(r"('assistant/"+re.escape(name)+r"':')[A-F0-9]{64}",r'\g<1>'+h,t);assert n==1
h=hashlib.sha256((C/'work/ui-runtime-r55/src/assistant/intent_correction.py').read_bytes()).hexdigest().upper()
t=t.replace('DEPENDENCY_SHA256 = {',"DEPENDENCY_SHA256 = {\n    'assistant/intent_correction.py':'"+h+"',")
p.write_text(t,'utf-8')
# Source-only fixture view supplies real, exact candidate dependency pins. No
# sessions, runtime DB, deployment config, or frozen app is copied here.
view=W/'source-view/work/ui-runtime-r55/src'
for name in ('assistant/customer_list.py','assistant/business.py','assistant/ai_workflow.py','assistant/intent_correction.py',
    'xlsxwriter/__init__.py','xlsxwriter/workbook.py','xlsxwriter/worksheet.py'):
    source=C/'work/ui-runtime-r55/src'/name
    if not source.exists():source=S/'work/ui-runtime-r55/src'/name
    target=view/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
print('Candidate exact pins + Native freeze closure prepared; no actual freeze')
