"""Rebind the two reviewed Douyin customer-read purposes to actual final bytes.

No installer, company edit, internal-review edit, permission grant, or manifest
writer lives here. Run only after the original held-compatibility derivation is
stable. The caller is responsible for reviewing the final source and for the
original RELEASE/SHIPPED builder after these four documents are written.
"""
from pathlib import Path
from copy import deepcopy
from datetime import datetime, timezone
import ast,hashlib,json,os,re,stat,uuid

AUTHOR_FINAL='b0d839d70ea5276566ecc484c565c907715450dba23993b386b1cf4bdd376f52'
INDEPENDENT_FINAL='b4faa36859349e9b68b274fead8ad01e181551aebeadfc472425f260fa57cddf'
_COMPANY_AST='abef82b384d9b9c7366fad7fc4117a0c631c141cb50356e2381a484b2c1c6570'
_MIT_SHA='3723b8dae8c5e727627eb68f8dbcd46def7132a18bf50427f689d9cd41d3f9da'
_SCOPE='customer_distribution_read'
_LIMITS={
 'douyin_owned_connection':{'account_network':'fixed_identity_js_only','native_loaded_bytes_verified':False,'public_send_grant':False},
 'douyin_owned_video_comments':{'main_page_only':True,'max_comments':20,'search':False,'reply':False,'dm':False,'platform_identity_before_after':True,'real_platform_verified':False}}
_REVIEW_PATHS={'douyin_owned_connection':('vendor','douyin-connection-review.json'),
 'douyin_owned_video_comments':('source','resources/douyin-owned-comments/review.json')}
_CODE_EXT={'.py','.js','.mjs','.exe','.dll','.pyd'}

class RebindError(ValueError):pass

def _json(raw):
 def pairs(rows):
  out={}
  for k,v in rows:
   if k in out:raise RebindError('duplicate_json_key')
   out[k]=v
  return out
 return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(RebindError('nonfinite_json')))

def _canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def _encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def _digest(raw):return hashlib.sha256(raw).hexdigest()
def _relative(value):return type(value) is str and bool(value) and '\\' not in value and ':' not in value and all(p not in ('','.','..') for p in value.split('/'))

def _plain(path,root,*,directory=False):
 path,root=Path(path),Path(root)
 if not path.is_absolute() or not root.is_absolute() or not path.is_relative_to(root):raise RebindError('path_outside_root')
 for p in (path,*path.parents):
  s=p.lstat()
  if p.is_symlink() or getattr(s,'st_file_attributes',0)&0x400:raise RebindError('linked_path')
 s=path.stat()
 if directory:
  if not stat.S_ISDIR(s.st_mode):raise RebindError('not_directory')
 elif not stat.S_ISREG(s.st_mode) or s.st_nlink!=1:raise RebindError('not_singlelink_regular')
 return path

def _file(path,root):
 p=_plain(path,root);before=p.stat();h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 after=_plain(p,root).stat();sig=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
 if sig(before)!=sig(after):raise RebindError('input_changed_while_hashing')
 return {'bytes':before.st_size,'sha256':h.hexdigest()},sig(after)

def _company(config):
 runtime,managed=config.get('runtime'),config.get('managedWorkspace')
 if (type(runtime) is not dict or type(managed) is not dict or config.get('edition')!='customer'
  or config.get('personalMode') is not False or config.get('authMode')!='managed'
  or runtime.get('public_send_hold') is not True or runtime.get('release_approved') is not False
  or runtime.get('role')!='local_assistant_only' or runtime.get('ui_entry')!='employee_workspace'
  or any(k in runtime for k in ('private_evaluation','private_evaluation_session_id','platform_qa_device_id','portable_employee_release'))):raise RebindError('company_hold_contract_changed')
 return {k:deepcopy(config.get(k)) for k in ('id','edition','personalMode','authMode','releaseVersion','platforms')}|{
  'environment_id':managed.get('environment_id'),'endpoint':managed.get('endpoint'),'role':runtime['role'],
  'ui_entry':runtime['ui_entry'],'public_send_hold':True,'executable':runtime.get('executable'),
  'cli_source_sha256':runtime.get('cli_source_sha256'),'xiaohongshu_automation':runtime.get('xiaohongshu_automation')}

def _held_stable(project,release,company):
 manifest_path=project/'HELD-STANDARD-MANIFEST.json';_plain(manifest_path,project);raw=manifest_path.read_bytes();doc=_json(raw)
 helper=release/'resources/platform-runtime/vendor-src/assistant/employee_distribution.py';_plain(helper,release)
 tree=ast.parse(helper.read_bytes());pins=[n.value.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='HELD_STANDARD_MANIFEST_SHA256' for t in n.targets) and isinstance(n.value,ast.Constant)]
 if pins!=[_digest(raw)]:raise RebindError('held_compatibility_not_stable:helper_pin')
 if (doc.get('schema')!='fangyu-held-standard-code-manifest-v1' or doc.get('channel')!='internal_standard_candidate'
  or doc.get('commercialDistributionApproved') is not False or doc.get('platformExecutionApproved') is not False
  or doc.get('companyId')!=company.get('id') or doc.get('nativeReleaseId')!=release.name
  or doc.get('companyConfigDigest')!=_digest(_canonical(company))):raise RebindError('held_compatibility_not_stable:company_or_decision')
 excluded={helper.relative_to(project).as_posix(),(release/'RELEASE.json').relative_to(project).as_posix()}
 if set(doc.get('excludedFromInnerManifest',[]))!=excluded:raise RebindError('held_compatibility_not_stable:exclusions')
 rows=doc.get('codeFiles')
 if type(rows) is not list or not 1<=len(rows)<=15000 or doc.get('codeFileCount')!=len(rows):raise RebindError('held_compatibility_not_stable:count')
 actual={p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file() and p.suffix.lower() in _CODE_EXT and p.relative_to(project).as_posix() not in excluded}
 listed=set()
 for row in rows:
  if type(row) is not dict or set(row)!={'path','bytes','sha256'} or not _relative(row['path']) or row['path'] in listed:raise RebindError('held_compatibility_not_stable:row')
  record,_=_file(project/row['path'],project)
  if record!={'bytes':row['bytes'],'sha256':row['sha256']}:raise RebindError('held_compatibility_not_stable:code_bytes')
  listed.add(row['path'])
 if listed!=actual:raise RebindError('held_compatibility_not_stable:unlisted_code')
 return _digest(raw),_digest(helper.read_bytes())

def rebind_customer_reviews(project, release, evidence_reference, reviewed_at):
 """Write exactly four JSON files in release/resources/customer-read.

 evidence_reference: a nonempty, bounded local review identifier/digest string;
 it is recorded verbatim and never fetched or interpreted as a grant.
 reviewed_at: timezone-aware ISO string or datetime, never a future time.
 Returns actual four files/pins, changed material pins and input provenance.
 Unknown present/declared purposes fail before writes. RELEASE/SHIPPED and all
 internal reviews are unchanged. There is no main-EXE SHA self-reference.
 """
 project,release=Path(project),Path(release)
 if not project.is_absolute() or not release.is_absolute() or '..' in project.parts or '..' in release.parts:raise RebindError('absolute_roots_required')
 _plain(project,project,directory=True);_plain(release,project,directory=True)
 if not release.is_relative_to(project/'work/ui-native-r57/releases') or release.parent!=project/'work/ui-native-r57/releases':raise RebindError('release_root_mismatch')
 if type(evidence_reference) is not str or not 1<=len(evidence_reference)<=1024 or re.search(r'[\x00-\x1f\x7f]',evidence_reference):raise RebindError('review_reference_required')
 try:stamp=datetime.fromisoformat(reviewed_at.replace('Z','+00:00')) if type(reviewed_at) is str else reviewed_at
 except (ValueError,TypeError,AttributeError):raise RebindError('review_timestamp_invalid') from None
 if not isinstance(stamp,datetime) or stamp.tzinfo is None or stamp>datetime.now(timezone.utc):raise RebindError('review_timestamp_invalid')
 stamp=stamp.astimezone(timezone.utc).isoformat()
 company_path=project/'work/app/company.json';_plain(company_path,project);company=_json(company_path.read_bytes());binding=_company(company)
 carrier=release/'resources/platform-runtime/customer_read_distribution.py';_plain(carrier,release);tree=ast.parse(carrier.read_bytes())
 contract=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_company'),None)
 if contract is None or _digest(ast.dump(contract,include_attributes=False).encode())!=_COMPANY_AST:raise RebindError('unsupported_carrier_company_contract')
 purposes=None
 for n in tree.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_PURPOSES' for t in n.targets):
   if not isinstance(n.value,ast.Call) or not isinstance(n.value.func,ast.Name) or n.value.func.id!='frozenset':raise RebindError('unsupported_carrier_purpose_contract')
   purposes=set(ast.literal_eval(n.value.args[0]))
 if purposes!=set(_LIMITS):raise RebindError('unsupported_carrier_purpose:'+','.join(sorted(purposes or set())))
 out=release/'resources/customer-read';previous_customer={}
 if out.exists():
  _plain(out,release,directory=True)
  if (out/'review-index.json').exists():
   _plain(out/'review-index.json',release);existing=_json((out/'review-index.json').read_bytes())
   for row in existing.get('reviews',[]):
    if type(row) is not dict or row.get('purpose') not in _LIMITS:raise RebindError('unsupported_existing_customer_purpose')
    name=row['purpose'];expected_path='resources/customer-read/'+name+'.json'
    if row.get('path')!=expected_path or name in previous_customer:raise RebindError('invalid_existing_customer_index')
    prior_path=_plain(release/expected_path,release);prior_raw=prior_path.read_bytes()
    if row.get('sha256')!=_digest(prior_raw) or row.get('bytes')!=len(prior_raw):raise RebindError('invalid_existing_customer_document_pin')
    previous_customer[name]=_json(prior_raw)
 held_sha,helper_sha=_held_stable(project,release,company)
 source=project/'work/ui-runtime-r55/src';roots={'source':source,'vendor':release/'resources/platform-runtime/vendor-src','douyin_runtime':source.parent/'work/runtime/douyin-bridge','release':release}
 if _file(roots['douyin_runtime']/'LICENSE',roots['douyin_runtime'])[0]['sha256']!=_MIT_SHA:raise RebindError('unreviewed_license_bytes')
 evidence={'schema':'customer_read_license_source_evidence_v1','reviewer_ref':evidence_reference,
  'review_reference':evidence_reference,'reviewed_at':stamp,'basis_author_final_sha256':AUTHOR_FINAL,
  'basis_independent_final_sha256':INDEPENDENT_FINAL,'license_basis':'Pinned Yht20927 Bridge MIT text; retained exact copyright and permission notice.',
  'license_url':'https://github.com/Yht20927/douyin-cli/blob/main/LICENSE','held_manifest_sha256':held_sha,
  'held_helper_sha256':helper_sha,'company_json_sha256':_digest(company_path.read_bytes()),
  'source_materials':'Actual final canonical, active vendor, host and CLI bytes at explicit rebind.',
  'send_grant':False,'not_account_or_device_enrollment':True,
  'unverified':['actual Native loaded browser process','platform authorization and login/read','second ordinary PC'],
  'engineering_runtime_verification':'Prior fixed independent local compiled/Source contract evidence only; final aggregate must be separately verified.'}
 generated={'distribution-evidence.json':_encoded(evidence)};internal_pins={};snapshots={};changes=[];counts={}
 for purpose,(origin,path) in _REVIEW_PATHS.items():
  old_path=roots[origin]/path;old_raw=_plain(old_path,roots[origin]).read_bytes();old=_json(old_raw);internal_pins[str(old_path)]=_digest(old_raw)
  limits=old.get('material_limits',old.get('limits'))
  if old.get('purpose')!=purpose or old.get('scope')!='internal_self_use_read' or limits!=_LIMITS[purpose] or any(type(limits[k]) is not type(v) for k,v in _LIMITS[purpose].items()):raise RebindError('internal_purpose_or_limits_changed:'+purpose)
  materials={};old_materials={(r['root'],r['path']):r for r in previous_customer.get(purpose,old)['materials']}
  def add(root,path,role):
   if root not in roots or not _relative(path):raise RebindError('unsupported_material_path')
   if (root,path)==('release','resources/customer-read/distribution-evidence.json'):
    record={'bytes':len(generated['distribution-evidence.json']),'sha256':_digest(generated['distribution-evidence.json'])}
   else:
    record,signature=_file(roots[root]/path,roots[root]);snapshots[str(roots[root]/path)]=(roots[root],signature)
   materials[(root,path)]={'root':root,'path':path,**record,'role':role}
   prior=old_materials.get((root,path))
   if prior is None or prior.get('sha256')!=record['sha256']:changes.append({'purpose':purpose,'root':root,'path':path,'beforeSha256':prior.get('sha256') if prior else None,'afterSha256':record['sha256'],'comparisonBase':'prior_customer_review' if purpose in previous_customer else 'original_internal_review'})
  for row in old['materials']:add(row['root'],row['path'],'source' if row.get('role')=='source' else 'dependency')
  for p in sorted(roots['vendor'].rglob('*.py')):add('vendor',p.relative_to(roots['vendor']).as_posix(),'source')
  for path in ['ui_native_host.py','resources/platform-runtime/platform_runtime.py','resources/platform-runtime/customer_read_distribution.py']:add('release',path,'source')
  for path in ['core/douyin_comments_policy.py','core/runtime_license_policy.py']:add('source',path,'source')
  add('douyin_runtime','LICENSE','license');add('release','resources/customer-read/distribution-evidence.json','review_evidence')
  if not 1<=len(materials)<=1024:raise RebindError('material_budget')
  doc={'schema':'fangyu_customer_read_purpose_review_v1','scope':_SCOPE,'purpose':purpose,'company_binding':binding,'limits':deepcopy(_LIMITS[purpose]),'materials':list(materials.values()),
   'distribution_basis':{'reviewer_ref':evidence_reference,'reviewed_at':stamp,'license':'MIT','license_material':{'root':'douyin_runtime','path':'LICENSE'},'permission':'scoped_customer_read_only','evidence_material':{'root':'release','path':'resources/customer-read/distribution-evidence.json'}},
   'evidence':{'review_layer':'license_and_source','real_platform_verified':False,'native_loaded_bytes_verified':False,'public_send_grant':False}}
  generated[purpose+'.json']=_encoded(doc);counts[purpose]=len(materials)
 index={'schema':'fangyu_customer_read_material_index_v1','scope':_SCOPE,'company_binding':binding,'executable':company['runtime']['executable'],'reviews':[{'purpose':p,'path':'resources/customer-read/'+p+'.json','sha256':_digest(generated[p+'.json']),'bytes':len(generated[p+'.json'])} for p in _LIMITS]}
 generated['review-index.json']=_encoded(index)
 for path,(root,signature) in snapshots.items():
  s=_plain(Path(path),root).stat()
  if (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)!=signature:raise RebindError('input_changed_before_write')
 if any(_digest(Path(path).read_bytes())!=pin for path,pin in internal_pins.items()) or _company(_json(company_path.read_bytes()))!=binding:raise RebindError('input_changed_before_write')
 if not out.exists():out.mkdir();_plain(out,release,directory=True)
 results=[]
 # Index is last. During the small multi-file transition the old/new digest
 # mismatch fails closed. No old permission is silently reused.
 for name in ['distribution-evidence.json','douyin_owned_connection.json','douyin_owned_video_comments.json','review-index.json']:
  target=out/name;before=None
  if target.exists():_plain(target,release);before=_digest(target.read_bytes())
  temporary=out/(name+'.tmp-'+uuid.uuid4().hex)
  with temporary.open('xb') as f:f.write(generated[name]);f.flush();os.fsync(f.fileno())
  os.replace(temporary,target)
  results.append({'path':str(target),'relativeReleasePath':target.relative_to(release).as_posix(),'beforeSha256':before,'sha256':_digest(generated[name]),'bytes':len(generated[name])})
 return {'files':results,'changedMaterialPins':changes,'materialCounts':counts,'heldManifestSha256':held_sha,'heldHelperSha256':helper_sha,'internalReviewsUnchanged':internal_pins,'releaseAndShippedNotWritten':True,'mainExeShaNotEmbedded':True,'supportedPurposes':list(_LIMITS),'unknownPurposeRejected':True,'realPlatformNativeApproval':False}
