"""Offline contract verification. Writes only this independent candidate."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
NODE=r'C:\积木软件工坊\核心组件\社媒人设与内容运营组件库\runtime\tools\node-v22.23.4-win-x64\node.exe'
SDK=r'C:\积木软件工坊\项目\方隅公寓客户版\work\cloud\workspace\node_modules'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def execute(name,args):
 env=dict(os.environ,NODE_PATH=SDK,PYTHONUTF8='1',PYTHONIOENCODING='utf8')
 run=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf8',errors='replace',timeout=120)
 output=run.stdout+run.stderr;log='work/'+name+'.log';(ROOT/log).write_bytes(output.encode('utf8'))
 return {'name':name,'exitCode':run.returncode,'log':log,
  'failedNames':re.findall(r'^not ok \d+ - (.+)$',output,re.M),
  'nodeCounts':{k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped) (\d+)$',output,re.M)},
  'pythonTests':int(re.search(r'Ran (\d+) tests?',output).group(1)) if re.search(r'Ran (\d+) tests?',output) else None}

def main():
 baseline=json.loads((ROOT/'BASELINE-PINS.json').read_text('utf8'));source_updates=[]
 for row in baseline['files']:
  assert sha(ROOT/row['snapshot'])==row['sha256'],row['snapshot']
  if sha(Path(row['source']))!=row['sha256']:source_updates.append(row['source'])
 v2=ROOT.parent/'content-model-gateway'
 for row in json.loads((v2/'FILES-SHA256.json').read_text('utf8')):
  assert sha(v2/row['path'])==row['sha256'],'Sealed v2 changed: '+row['path']
 assert sha(v2/'content-model-gateway-candidate-v2.zip')==baseline['v2ArchiveSha256']
 commands=[
  ('V3-NODE-FINAL',[NODE,'--test']+['tests/'+n for n in ('method-versions.test.cjs','content-authority.test.cjs',
   'content-profile.test.cjs','content-review.test.cjs','content-gateway.test.cjs','store-replay.test.cjs','content-methods.test.cjs','approved-live-contract.test.cjs')]),
  ('V3-PYTHON-FINAL',[sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_*.py','-v']),
  ('INHERITED-AI-CORE',[NODE,'--test','cloud/ai_enterprise.test.cjs','cloud/product_entitlements.test.cjs',
   'cloud/intent_policy_publication.test.cjs','cloud/intent_policy_service.test.cjs']),
  ('INHERITED-SERVICE',[NODE,'--test','cloud/service.test.cjs'])]
 checks=[]
 for name,args in commands:
  result=execute(name,args);checks.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
 prior=json.loads((v2/'VERIFICATION.json').read_text('utf8'))
 expected=prior['historicalContractFailedNames'];by={r['name']:r for r in checks}
 historical_equal=by['INHERITED-AI-CORE']['failedNames']==expected and len(expected)==8
 passed=all(r['exitCode']==0 for r in checks if r['name']!='INHERITED-AI-CORE') and historical_equal
 result={'candidateRevision':3,'verifiedAtUtc':datetime.now(timezone.utc).isoformat(),'offlineCandidateVerified':passed,
  'checks':checks,'v2SealedFilesUnchanged':True,'baselineSnapshotsUnchanged':True,
  'concurrentSourceUpdates':source_updates,'requiresRebaseAgainstCurrentSource':bool(source_updates),
  'historicalEightAssertionsUnchangedFromV2AndRealLive':historical_equal,
  'currentResourceMethods':17,'legacyMethodVersionsRetained':17,'allBusinessExecutorsIntegrated':False,
  'sourceResourcesVerified':41,'MITSourceProjects':5,'retainedProjectMapCount':43,'newWireFields':0,'realModelCalls':0,
  'realPlatformActions':0,'deploymentPerformed':False,'stageOrNativeModified':False,
  'qualityAcceptedByUser':False,'realModelQualityVerified':False,
  'limits':['Node22 offline synthetic provider/storage only','No actual media renderer, API sampler, publisher or scheduler added',
   'Full source text is not proof of upstream executor or complete UI support','Native host pins and final merged closure still require parent review']}
 (ROOT/'VERIFICATION.json').write_bytes(json.dumps(result,ensure_ascii=False,indent=2).encode('utf8'))
 assert passed,'Inspect final logs; never rewrite old requests to pass a test'

if __name__=='__main__':main()
