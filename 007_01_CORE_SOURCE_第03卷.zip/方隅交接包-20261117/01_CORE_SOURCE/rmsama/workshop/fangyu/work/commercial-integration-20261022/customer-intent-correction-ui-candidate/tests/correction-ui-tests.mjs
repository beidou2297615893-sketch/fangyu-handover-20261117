import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {parseHTML} from '../../content-workflow-ui/node_modules/linkedom/esm/index.js';
import {renderIntentCorrection,bindIntentCorrection,correctionRequestDigest} from '../candidate/pages/customer-intent-correction.mjs';
import {customerControls} from '../candidate/pages/customers-data.mjs';
import {createBackend} from '../candidate/backend.mjs';
const W=fileURLToPath(new URL('../',import.meta.url));
const {document,window}=parseHTML('<html><body><main></main></body></html>');
globalThis.document=document;
const root=document.querySelector('main'),storage=new Map(),results=[];
globalThis.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const H=n=>n.toString(16).padStart(64,'0'),clone=v=>structuredClone(v);
const requestDigest=data=>createHash('sha256').update(JSON.stringify(Object.fromEntries(Object.keys(data).sort().map(k=>[k,k==='reason'?data[k].trim():data[k]]))),'utf8').digest('hex');
async function settle(){for(let i=0;i<6;i++)await new Promise(r=>setTimeout(r,0));}
function click(q){const e=root.querySelector(q);assert.ok(e,q);assert.equal(e.disabled,false);e.click();return e;}
function input(q,value,type='input'){const e=root.querySelector(q);assert.ok(e,q);if(e.tagName==='SELECT'){for(const opt of e.querySelectorAll('option'))opt.removeAttribute('selected');[...e.querySelectorAll('option')].find(o=>o.value===value)?.setAttribute('selected','');}else e.value=value;e.dispatchEvent(new window.Event(type,{bubbles:true}));}
const view=(lead='comment-a')=>({actor:{username:'employee-a',storeId:'store-a'},scope:'single-comment',customerId:'customer-a',leadId:lead,platform:'xiaohongshu',version:H(1),sourceDigest:H(7),aiIntent:{status:'graded',level:'high',reason:'问价格，原 AI 认为有求租意向',evidence:['原评论：转租多少钱']},manualIntent:null,currentIntent:{status:'graded',level:'high',reason:'问价格'},history:[],receipt:null});
function setup({mode='success',preserveStorage=false}={}){
  if(!preserveStorage)storage.clear();let behavior=mode,release,readMode='normal',active=0,cancelBehavior='success';
  const views=new Map([['comment-a',view()],['comment-b',view('comment-b')]]),receipts=new Map(),calls=[],refresh=[],errors=[],modals=[];
  const state={authEpoch:1,user:'employee-a',storeId:'store-a',activePlatform:'xiaohongshu',page:'customers',connection:'connected',session:{user:{username:'employee-a',role:'operator'}}};
  const item={id:'customer-a',name:'合成客户',platform:'xiaohongshu',representativeLeadId:'comment-a',comments:[{id:'comment-a',text:'转租多少钱？<script>not executable</script>',postTitle:'合成原帖 A',publishedAt:'2026-10-23'},{id:'comment-b',text:'同一客户另一条求租',postTitle:'合成原帖 B',publishedAt:'2026-10-22'}]};
  state.customerDetail={actor:{username:state.user,storeId:state.storeId},id:item.id,status:'ready',item};customerControls(state).selectedId=item.id;
  function result(data){const v=clone(views.get(data.leadId));if(data.requestId)v.receipt=clone(receipts.get(data.requestId)||{requestId:data.requestId,state:'not_found'});if(readMode==='mismatch')v.leadId='wrong-comment';return {intentCorrection:v};}
  function commit(data){const v=views.get(data.leadId),before=clone(v.currentIntent);v.version=H(parseInt(v.version,16)+1);v.manualIntent={status:data.status,level:data.level,reason:data.reason,by:'employee-a',updatedAt:'2026-10-23T01:00:00+08:00'};v.currentIntent=clone(v.manualIntent);v.history.unshift({requestId:data.requestId,by:'employee-a',updatedAt:v.manualIntent.updatedAt,before,after:clone(v.manualIntent)});receipts.set(data.requestId,{requestId:data.requestId,state:'saved',customerId:data.customerId,leadId:data.leadId,platform:data.platform,storeId:data.storeId,version:v.version,sourceDigest:v.sourceDigest,requestDigest:requestDigest(data)});return result(data);}
  const backend=createBackend(async(url,options)=>{const {action,data}=JSON.parse(options.body);calls.push({action,data:clone(data)});active++;try{
    if(action==='customer_intent_read'){if(readMode==='offline')throw Error('synthetic local read loss');return {ok:true,status:200,json:async()=>({ok:true,...result(data)})};}
    if(action==='customer_intent_cancel'){
      if(cancelBehavior==='reject')return {ok:false,status:409,json:async()=>({ok:false,error:{code:'INTENT_CANCEL_DIGEST_MISMATCH',message:'摘要不匹配',mutation_committed:false}})};
      if(cancelBehavior==='saved-race')commit(calls.find(c=>c.action==='customer_intent_correct').data);
      if(!receipts.has(data.requestId))receipts.set(data.requestId,{...data,state:'cancelled',cancelledAt:'2026-10-23T01:00:00Z'});
      if(cancelBehavior==='drop-after')throw Error('cancel receipt dropped');
      const response=result(data);if(cancelBehavior==='wrong-digest')response.intentCorrection.receipt.requestDigest=H(999);
      if(cancelBehavior==='delay')return new Promise(resolve=>{release=()=>resolve({ok:true,status:200,json:async()=>({ok:true,...response})});});
      return {ok:true,status:200,json:async()=>({ok:true,...response})};
    }
    assert.equal(action,'customer_intent_correct');
    if(behavior==='reject')return {ok:false,status:409,json:async()=>({ok:false,error:{code:'CUSTOMER_INTENT_CHANGED',message:'判断已更新',mutation_committed:false}})};
    if(behavior==='ambiguous403')return {ok:false,status:403,json:async()=>({ok:false,error:{code:'CUSTOMER_INTENT_RESULT_UNCONFIRMED',message:'提交后的权限需核对',mutation_committed:true}})};
    if(behavior==='drop-before')throw Error('synthetic network loss before result');
    if(behavior==='delay')return new Promise(resolve=>{release=()=>resolve({ok:true,status:200,json:async()=>({ok:true,...commit(data)})});});
    const value=receipts.has(data.requestId)?result(data):commit(data);
    if(behavior==='drop-after')throw Error('synthetic response lost after local commit');
    if(behavior==='bad-json')return {ok:true,status:200,json:async()=>{throw Error('malformed');}};
    if(behavior==='mismatch')value.intentCorrection.receipt.leadId='wrong-comment';
    return {ok:true,status:200,json:async()=>({ok:true,...value})};
  }finally{active--;}});
  const ctx={state,update:fn=>{fn(state);paint();},toast(){},modal:config=>modals.push(config),actions:{intentCorrectionAction:(a,d)=>backend.intentCorrectionAction(a,d),loadCustomers:()=>refresh.push('list'),loadCustomerDetail:id=>refresh.push(id),replyError:error=>errors.push(error.code)}};
  function paint(){root.innerHTML=renderIntentCorrection(state,state.customerDetail.item);bindIntentCorrection(root,ctx);}
  paint();return {state,item,ctx,paint,views,calls,receipts,refresh,errors,modals,backend,release:()=>release?.(),get active(){return active},set mode(v){behavior=v},set cancelMode(v){cancelBehavior=v},set readMode(v){readMode=v}};
}
async function open(h){click('[data-correction-open]');await settle();assert.equal(h.calls.at(-1).action,'customer_intent_read');}
function fill(level='unrelated',reason='这条评论是在转租，不是求租。'){input('[data-correction-level]',level,'change');input('[data-correction-reason]',reason);}

{
 const h=setup();assert.equal(h.calls.length,0);await open(h);assert.match(root.textContent,/只更正下方这一条评论/);assert.match(root.textContent,/AI 原判断：高意向/);assert.equal(root.querySelector('script'),null);const other=clone(h.views.get('comment-b'));fill();const button=click('[data-correction-save]');button.click();await settle();assert.equal(h.calls.filter(c=>c.action==='customer_intent_correct').length,1);const data=h.calls.at(-1).data;assert.equal(data.customerId,'customer-a');assert.equal(data.leadId,'comment-a');assert.equal(data.status,'unrelated');assert.equal(data.level,null);assert.equal(data.expectedVersion,H(1));assert.equal(data.sourceDigest,H(7));assert.match(root.textContent,/人工更正：不相关/);assert.match(root.textContent,/AI 原判断：高意向/);assert.match(root.textContent,/其他评论决定/);assert.deepEqual(h.views.get('comment-b'),other);assert.equal(storage.size,0);assert.deepEqual(h.refresh,['list','customer-a']);results.push('Exact single-comment wire payload, explicit scope, manual reason + original AI retained, no sibling comment write, duplicate click suppressed');
}
{
 const h=setup();await open(h);fill('medium','第二条评论有明确预算');input('[data-correction-comment]','comment-b','change');await settle();assert.equal(h.calls.length,2);assert.equal(h.calls[1].data.leadId,'comment-b');assert.equal(h.state.customerIntentCorrection.reason,'');assert.equal(h.calls.filter(c=>c.action==='customer_intent_correct').length,0);fill('medium','另一条有求租需求');click('[data-correction-save]');await settle();assert.equal(h.calls.at(-1).data.leadId,'comment-b');assert.equal(h.calls.at(-1).data.status,'graded');assert.equal(h.calls.at(-1).data.level,'medium');results.push('Explicit original-comment selection sends that lead only; draft reason is not copied to a different comment');
}
{
 const h=setup();await open(h);fill('unrelated','   ');click('[data-correction-save]');await settle();assert.equal(h.calls.length,1);assert.match(root.textContent,/1—300 字/);fill('unrelated','字'.repeat(301));click('[data-correction-save]');await settle();assert.equal(h.calls.length,1);results.push('Empty and overlong manual reasons stop before any mutation');
}
{
 const h=setup({mode:'drop-after'});await open(h);fill();click('[data-correction-save]');await settle();const p=h.state.customerIntentCorrection.pending;assert.ok(p);const savedJSON=[...storage.values()][0];assert.ok(!savedJSON.includes('reason'));assert.ok(!savedJSON.includes('转租'));assert.match(root.textContent,/更正结果待核对/);assert.equal(root.querySelector('[data-correction-save]'),null);click('[data-correction-check]');await settle();assert.equal(h.calls.length,3);assert.equal(h.calls[2].action,'customer_intent_read');assert.equal(h.calls[2].data.requestId,p.requestId);assert.equal(storage.size,0);assert.match(root.textContent,/更正已保存/);results.push('Lost response retains only request scope/digests on disk; explicit read of original key recovers without another write');
}
{
 const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();const first=clone(h.calls[1].data);click('[data-correction-check]');await settle();assert.equal(h.state.customerIntentCorrection.pending.notFound,true);assert.equal(h.calls.length,3);h.mode='success';click('[data-correction-retry]');await settle();assert.deepEqual(h.calls[3].data,first);assert.equal(storage.size,0);results.push('not_found never invents a new key; only explicit retry with retained exact original payload can resend');
}
{
 const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();const original=h.calls[1].data.requestId;h.state.customerIntentCorrection=null;h.paint();assert.equal(h.calls.length,2);await open(h);assert.equal(h.calls[2].data.requestId,original);assert.ok(h.state.customerIntentCorrection.pending);assert.equal(root.querySelector('[data-correction-retry]'),null);assert.equal(root.querySelector('[data-correction-save]'),null);assert.match(root.textContent,/无法确认前不能重新提交/);results.push('Refresh recovers original summary, not text; not_found without payload leaves checkpoint and cannot start a new mutation');
}
{
 for(const variation of ['store','platform','employee','epoch','customer']){const h=setup({mode:'delay'});await open(h);fill();click('[data-correction-save]');await settle();const old=h.state.customerIntentCorrection;assert.ok(old.pending);if(variation==='store')h.state.storeId='store-b';if(variation==='platform')h.state.activePlatform='douyin';if(variation==='employee')h.state.user='employee-b';if(variation==='epoch')h.state.authEpoch++;if(variation==='customer')customerControls(h.state).selectedId='customer-b';h.release();await settle();assert.ok(old.pending);assert.equal(storage.size,1);assert.equal(h.refresh.length,0);}results.push('Late saved responses across store, platform, employee, auth epoch or selected customer never update current UI or clear original checkpoint');
}
{
 const h=setup({mode:'reject'});await open(h);fill();click('[data-correction-save]');await settle();assert.equal(h.state.customerIntentCorrection.pending,null);assert.equal(h.state.customerIntentCorrection.reason,'这条评论是在转租，不是求租。');assert.equal(h.state.customerIntentCorrection.view,null);assert.equal(storage.size,0);click('[data-correction-read]');await settle();assert.equal(h.state.customerIntentCorrection.reason,'这条评论是在转租，不是求租。');assert.equal(h.calls.filter(c=>c.action==='customer_intent_correct').length,1);results.push('Explicit uncommitted CAS rejection clears only uncommitted request and keeps manual input for reread; no retry');
}
{
 for(const mode of ['ambiguous403','bad-json','mismatch']){const h=setup({mode});await open(h);fill();click('[data-correction-save]');await settle();assert.ok(h.state.customerIntentCorrection.pending);assert.equal(storage.size,1);assert.equal(h.calls.length,2);assert.equal(root.querySelector('[data-correction-save]'),null);}results.push('Post-commit permission ambiguity, malformed response and wrong comment receipt stay unknown even on 403');
}
{
 const h=setup();await open(h);fill();click('[data-correction-save]');await settle();h.views.get('comment-a').aiIntent={status:'graded',level:'super_high',reason:'后到的旧分析'};click('[data-correction-read]');await settle();assert.match(root.textContent,/AI 原判断：超高意向/);assert.match(root.textContent,/人工更正：不相关/);assert.equal(h.state.customerIntentCorrection.selection,'unrelated');results.push('Returned manual judgment remains selected when a later read includes different AI evidence (UI precedence; Core persistence independently verified by author)');
}
{
 const h=setup();await open(h);fill();const previous=localStorage.setItem;localStorage.setItem=()=>{throw Error('full');};click('[data-correction-save]');await settle();localStorage.setItem=previous;assert.equal(h.calls.length,1);assert.match(root.textContent,/无法保留更正断点/);results.push('Unavailable browser storage refuses mutation before dispatch rather than risking an untracked write');
}
{
 const h=setup();h.readMode='mismatch';await open(h);assert.equal(h.state.customerIntentCorrection.view,null);assert.match(root.textContent,/回执与当前评论不一致/);assert.equal(root.querySelector('[data-correction-save]').disabled,true);assert.throws(()=>h.backend.intentCorrectionAction('intent_correct',{}),e=>e.code==='INPUT_INVALID');results.push('Wrong-scope read is rejected; backend exposes only three precise controlled actions, not unrestricted Core action');
}
{
 const h=setup();await open(h);fill();click('[data-correction-save]');await settle();const n=h.calls.length;click('[data-correction-save]');await settle();assert.equal(h.calls.length,n);assert.match(root.textContent,/无需再次保存/);h.state.activePlatform='douyin';h.paint();assert.equal(root.innerHTML,'');results.push('Already-saved identical manual judgment does not add duplicate history; stale detail from other platform has no correction control');
}
{
 const h=setup();h.views.get('comment-a').history=Array.from({length:11},(_,i)=>({requestId:'history-'+i,by:'员工',updatedAt:'记录时间',before:null,after:{status:'unrelated',level:null,reason:'历史原因'+i+'。'}}));await open(h);const history=root.querySelector('.cs-correction-history');assert.match(history.textContent,/显示最近 10 次/);assert.match(history.textContent,/历史原因0。/);assert.match(history.textContent,/历史原因9。/);assert.doesNotMatch(history.textContent,/历史原因10。/);assert.equal(h.views.get('comment-a').history.length,11);results.push('Newest-first Native history contract displays latest ten with disclosure and never deletes full history');
}
{
 const data={storeId:'门店甲',customerId:'customer-a',leadId:'comment-a',platform:'xiaohongshu',requestId:'original-key',expectedVersion:H(1),sourceDigest:H(7),status:'unrelated',level:null,reason:'  转租\n本人核对：不是求租 🙂  '};assert.equal(await correctionRequestDigest(data),requestDigest(data));
 const vectors=JSON.parse(fs.readFileSync(W+'../customer-intent-correction-candidate/DIGEST-VECTORS.json','utf8').replace(/^\uFEFF/,''));
 assert.ok(vectors.length>=3);for(const v of vectors)assert.equal(await correctionRequestDigest(v.payload),v.requestDigest);
 results.push('Canonical public-payload digest matches current Native DIGEST-VECTORS exactly and handles trimmed Chinese/newline/emoji/null');
}
{
 const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();const original=h.calls[1].data.requestId;assert.equal(root.querySelector('[data-correction-cancel]'),null);h.state.customerIntentCorrection=null;h.paint();await open(h);assert.equal(h.calls.length,3);assert.equal(root.querySelector('[data-correction-retry]'),null);click('[data-correction-cancel]');assert.equal(h.calls.length,3);assert.equal(h.modals.length,1);await h.modals[0].onConfirm();await settle();assert.equal(h.calls[3].action,'customer_intent_cancel');assert.equal(h.calls[3].data.requestId,original);assert.equal(h.calls[3].data.requestDigest,requestDigest(h.calls[1].data));assert.deepEqual(Object.keys(h.calls[3].data).sort(),['customerId','leadId','platform','requestDigest','requestId','storeId']);assert.equal(storage.size,0);assert.ok(root.querySelector('[data-correction-save]'));assert.match(root.textContent,/已取消，可重新填写/);results.push('Refresh without payload can explicitly cancel after original-key not_found; confirmation required, exact digest only, new save unlocks only on cancelled receipt');
}
{
 for(const mode of ['drop-after','reject','wrong-digest']){const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();click('[data-correction-check]');await settle();h.cancelMode=mode;click('[data-correction-cancel]');await h.modals[0].onConfirm();await settle();assert.ok(h.state.customerIntentCorrection.pending);assert.equal(storage.size,1);assert.equal(root.querySelector('[data-correction-cancel]'),null);if(mode==='drop-after'){click('[data-correction-check]');await settle();assert.equal(h.state.customerIntentCorrection.pending,null);assert.equal(storage.size,0);assert.match(root.textContent,/已取消/);}}results.push('Lost/explicitly rejected/mismatched cancellation never clears original pending; lost cancelled receipt is recovered by read, without cancel resend');
}
{
 const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();click('[data-correction-check]');await settle();h.cancelMode='saved-race';click('[data-correction-cancel]');await h.modals[0].onConfirm();await settle();assert.equal(storage.size,0);assert.match(root.textContent,/原更正已经保存/);assert.match(root.textContent,/人工更正：不相关/);assert.equal(h.views.get('comment-a').history.length,1);results.push('If original save wins cancellation race, UI accepts saved receipt and displays saved manual judgment instead of claiming cancellation');
}
{
 const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();click('[data-correction-check]');await settle();h.cancelMode='delay';click('[data-correction-cancel]');const flight=h.modals[0].onConfirm();h.state.authEpoch++;h.state.storeId='other-store';h.release();await flight;await settle();assert.equal(storage.size,1);assert.ok(h.state.customerIntentCorrection.pending);results.push('Late cancel response after scope change cannot clear the old checkpoint or alter the new scope');
}
{
 const h=setup({mode:'drop-before'});await open(h);fill();click('[data-correction-save]');await settle();const k=[...storage.keys()][0],p=JSON.parse(storage.get(k));delete p.requestDigest;storage.set(k,JSON.stringify(p));h.state.customerIntentCorrection=null;h.paint();await open(h);assert.equal(root.querySelector('[data-correction-cancel]'),null);assert.ok(h.state.customerIntentCorrection.pending);results.push('Legacy metadata with no payload/digest cannot invent a cancellation hash and keeps original checkpoint');
}
fs.writeFileSync(W+'RESULTS.json',JSON.stringify({passed:results.length,results,scope:'Candidate render/bind + backend with Node linkedom and synthetic HTTP-shaped transport. No S writes, Native service, real records, production platform/model/network or browser visual claims.'},null,2));
console.log(JSON.stringify({passed:results.length,results},null,2));

