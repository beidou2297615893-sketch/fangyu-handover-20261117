from pathlib import Path
import hashlib,json
W=Path(__file__).parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
FILES=['work/ui-runtime-r55/src/assistant/ai_workflow.py','work/ui-runtime-r55/src/assistant/business.py',
 'work/shared-backend-integration/vendor-src/assistant/business.py','work/ui-native-r57/workbench_backend.py',
 'work/ui-native-r57/ui_native_host.py','work/ui-native-r57/customer_workbench.py']
rows=[]
for rel in FILES:
    src=S/rel; body=src.read_bytes()
    for folder in ('before','candidate'):
        target=W/folder/rel;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():raise RuntimeError('Candidate already prepared: '+rel)
        target.write_bytes(body)
    rows.append({'path':rel,'sha256':hashlib.sha256(body).hexdigest()})
(W/'BASELINE.json').write_text(json.dumps({'source':str(S),'files':rows},indent=2),'utf-8')
print('Prepared '+str(len(rows))+' source copies only')
