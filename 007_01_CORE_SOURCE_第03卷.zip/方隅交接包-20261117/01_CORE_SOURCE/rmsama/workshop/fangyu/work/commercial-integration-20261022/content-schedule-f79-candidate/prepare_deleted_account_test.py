from pathlib import Path
W=Path(__file__).resolve().parent;p=W/'test_factory_schedule.py';s=p.read_text('utf-8');needle="            if case=='safety':"
assert s.count(needle)==1
replacement="""            if case=='account-removed':
                sessions.clear();target,d=setup_account(2);r=arm(target,plan(target,d))['schedule']
                old_schedule=deepcopy(backend.core.store.get('content_schedule_execution_v1',r['id']))
                old_attempt=deepcopy(backend.core.store.get('content_publication_attempt_v1',r['intentId']))
                account=backend.core.store.get('accounts',target['accountId'])
                removed=backend.core.handle('account_delete',{'id':target['accountId'],'expected_account_digest':backend.core.account_delete_digest(account)},user)
                assert backend.core.store.get('accounts',target['accountId']) is None,removed
                after_delete=state()
                answer=action('content_schedule_tick',{**target,'scheduleId':r['id'],'requestId':r['publishRequestId']},403)
                assert answer['error']['code']=='CONTENT_ACCOUNT_CHANGED' and state()==after_delete and dispatches()==0
                assert backend.core.store.get('content_schedule_execution_v1',r['id'])==old_schedule
                assert backend.core.store.get('content_publication_attempt_v1',r['intentId'])==old_attempt
                checks.append('F79 original Core CAS account deletion retained schedule/intent/key byte-identical; actual Native HTTP due tick rejects removed account before synthetic dispatch (Core deletion seam, not Native deletion-entry retest)')
            elif case=='safety':"""
s=s.replace(needle,replacement);(W/'test_f79_deleted_account.py').write_text(s,'utf-8')
print('Added one F79-specific deleted-account→Native due refusal interaction; original seven-case fixture unchanged')
