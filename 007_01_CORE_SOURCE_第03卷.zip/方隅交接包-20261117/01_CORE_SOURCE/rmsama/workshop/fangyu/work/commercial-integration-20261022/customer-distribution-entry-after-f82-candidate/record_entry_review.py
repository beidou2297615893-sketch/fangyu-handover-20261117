from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
def save(path,value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
assert not (D/'SEALED.json').exists()
pure=read(D/'EXISTING-SELECTION-RESULTS.json')
adapted=read(D/'ADAPTED-ENTRY-RESULTS.json')
compiled=read(D/'COMPILED-ENTRY-RESULTS.json')
assert pure['groupCount']==6 and pure['beforeAfterExact'] is True
assert adapted['groupCount']==6 and adapted['protectedBytesUnchanged'] is True
assert compiled['groupCount']==3 and compiled['realCompiledExecutions']==3
assert compiled['existingProtectedBytesExact'] and compiled['originalPyzBytesUnchanged']
assert compiled['actualNewAggregateProductCompiled'] is False
for report in (pure,adapted):
    assert report['adapterSha256']==sha(D/('existing_workspace_entry.py' if report is pure else 'adapt_clean_entry.py'))
assert adapted['selectorSha256']==sha(D/'existing_workspace_entry.py')
assert compiled['sourceEntryEvidenceSha256']==sha(D/'ADAPTED-ENTRY-RESULTS.json')
for run in compiled['runs']:
    p=Path(compiled['ownFixture'])/(run['case']+'.json')
    assert sha(p)==run['resultSha256']
agent=D.parent/'customer-existing-binding-upgrade-after-f82-candidate'
expected={'FINAL-RECEIPT.json':'5cbdc2fa004cc7e5a54fad28b5693bd13e761bfc1f1c33eba436d06cc22813c4',
    'SEALED.json':'f5b87b3769c7fd72c280889329f7d6a995949d8ccf22a0f79c88aca2b8705659',
    'FIXED-INPUTS.json':'c23604ad13db86e38683ca24a9b171ec419c6e202056a3190db7c85004311783'}
for name,pin in expected.items():assert sha(agent/name)==pin,name
for row in read(agent/'SEALED.json')['evidence']:
    p=agent/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
upgrade=read(agent/'FINAL-RECEIPT.json')
assert upgrade['newEnroll']==0 and upgrade['singleEnrollAllStages'] and upgrade['vaultBytesUnchanged']
assert upgrade['protectedRows']==5 and upgrade['allOwnServicesClosed']
result={'status':'REVIEWED_EXPLICIT_EXISTING_WORKSPACE_ENTRY_NOT_FINAL_AGGREGATE',
    'utc':datetime.now(timezone.utc).isoformat(),'selectorPureGroups':6,'adaptedOriginalEntryGroups':6,
    'actualCompiledEntryGroups':3,'originalBoundUpgradeSourceFrozenGroups':3,
    'compiledEntryUsesOriginalF82PublicClosure':True,'compiledReadleaseIntegrationVerified':False,
    'rootReviewedAuthorUpgradeEvidence':expected,'originalBoundUpgradeAuthenticatedRequests':13,
    'noNewEnrollmentOnUpgrade':True,'noDatabaseVaultOrBindingReplacement':True,
    'finalAggregateEntryAndAuthorityAndNaturalHelperPending':True,
    'realCloudNativePlatformProductionOrFormalWrites':False,
    'noUserWindowOrProfileInterference':True,
    'notCommercialDistributionApproval':True}
save(D/'FINAL-RECEIPT.json',result)
names=['existing_workspace_entry.py','adapt_clean_entry.py','test_existing_workspace_entry.py',
    'test_adapted_entry.py','test_compiled_existing_entry.py','record_entry_review.py',
    'EXISTING-SELECTION-RESULTS.json','ADAPTED-ENTRY-RESULTS.json','COMPILED-ENTRY-RESULTS.json',
    'ENTRY-INTEGRATION.md','FINAL-RECEIPT.json']
save(D/'SEALED.json',{'schema':'root-explicit-existing-entry-review-seal-v1','status':'SEALED_STOP_WRITING',
    'files':[{'path':name,'bytes':(D/name).stat().st_size,'sha256':sha(D/name)} for name in names]})
print(json.dumps({'status':result['status'],'finalSha256':sha(D/'FINAL-RECEIPT.json'),
    'sealSha256':sha(D/'SEALED.json')},ensure_ascii=False))
