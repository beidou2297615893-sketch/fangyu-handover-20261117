"""Pinned real-Store workflow -> adapter -> real createService, synthetic provider."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from queue import Queue
import subprocess
import sys
import threading
import unittest
import uuid

ROOT = Path(__file__).resolve().parents[1]
EXTENSION = ROOT.parent / 'content-workflow-extension'
SNAPSHOT = ROOT / 'work/adapter-extension-snapshot-v2'
BUNDLE = SNAPSHOT / 'bundle'
NODE = Path('C:/积木软件工坊/核心组件/社媒人设与内容运营组件库/runtime/tools/node-v22.23.4-win-x64/node.exe')
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from client.gateway_adapter import ContentGatewayAdapter
from client.trusted_method_pins import get_trusted_method

EXTENSION_PINS = {
    'content_workbench.py': '9e6687af1ea74244a3add283fc8bf72b1c25a6a3f9394483c02895cfe5dc24c6',
    'content_workflow.py': 'b3cf0ba0162aad94bf885298137b565793b3adf41a1af713cf3c43b63c19d22c',
    'workflow_methods.py': '60806e678ed6a96a7f3a7a3116a20024e97ac648f59c16cf5cf0eb8838e6b094',
    'workflow_knowledge.py': 'bddb66dc33dfa592fa52cb3bca767bdd8fb8ccc4d4925f0ed4b7fa0174df4afc',
}
BASELINE_PINS = {
    'content_workbench.py': EXTENSION_PINS['content_workbench.py'],
    'store.py': '124e4ca5bd9315ae6f9508fb5d39cd2ea176638cda3aeb9cdec9bbeb4766907d',
    'content_vendor/check_copy.py': 'd384550177c78dde10824866092f3fdfec7135ef22fe428b49e359917eaa420c',
    'content_vendor/diagnose_metrics.py': '9b63fed4c37b671b2e7e7df3044c4c964e5e13b7e4faa3b3538cb66d675a5a98',
    'content_vendor/LICENSE-xintu.txt': '96eb4018645eabca591866033cdccd1e2a9ac19dec3538a265328eeafa943c16',
    'content_vendor/method-bundle.json': 'ddcc17f6a6f5570a52f97b4da3abcc845c8da3acee43aaac876bceeefc61665d',
}
SUPPORT_PIN = '373bdcffb72cffd2cbc84e2bfac6cfd4b7fc0a6196db1299e5c0a877f28aa6af'
LOADER_PIN = 'c2d14566bedf807b21c8912a3ab9b7a7a56bd3a61fba55bcc44a99827e05ad9a'
KNOWLEDGE_VENDOR_PINS = {
    'normalize.py': 'd17449da9cf2942b0e0cc1bbabe29b4793daa6af3dff67b918fd4850e8e33f93',
    'LICENSE': 'b578bcab423726caace355bf28d4b62eaa7762c3fde9612e7de70791a510c3bb',
    'PINS.json': '54f82fb836833fea2c106104df69a33212d68deaa1f093bdb0f988b423b89af0',
}


def copied(source, target, expected=None):
    raw = source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if expected is not None and digest != expected:
        raise RuntimeError('Full-chain source pin changed: ' + source.name)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    return {'source': str(source), 'target': str(target), 'sha256': digest}


def load_file(name, file):
    spec = importlib.util.spec_from_file_location(name, file)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def prepare_snapshot():
    """Original extension/tests/work are never written or instantiated."""
    SNAPSHOT.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, digest in BASELINE_PINS.items():
        source = EXTENSION / 'tests/baseline' / name
        rows.append(copied(source, SNAPSHOT / 'tests/baseline' / name, digest))
    rows.append(copied(EXTENSION / 'tests/baseline/BASELINE-SHA256.json', SNAPSHOT / 'tests/baseline/BASELINE-SHA256.json'))
    for name, digest in EXTENSION_PINS.items():
        source = EXTENSION / 'tests/baseline' / name if name == 'content_workbench.py' else EXTENSION / name
        rows.append(copied(source, BUNDLE / name, digest))
    for name, digest in BASELINE_PINS.items():
        if name.startswith('content_vendor/'):
            rows.append(copied(EXTENSION / 'tests/baseline' / name, BUNDLE / name, digest))
    for name, digest in KNOWLEDGE_VENDOR_PINS.items():
        rows.append(copied(EXTENSION / 'workflow_vendor' / name, BUNDLE / 'workflow_vendor' / name, digest))
    rows.append(copied(EXTENSION / 'content_extension_loader.py', BUNDLE / 'content_extension_loader.py', LOADER_PIN))
    source = EXTENSION / 'tests/support.py'
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SUPPORT_PIN:
        raise RuntimeError('Frozen public Store fixture changed')
    text = raw.decode('utf-8')
    old = "temp_root = ROOT / 'work' / 'test-runs'"
    if text.count(old) != 1:
        raise RuntimeError('Public fixture temp root contract changed')
    text = text.replace(old, 'temp_root = Path(' + repr(str(ROOT / 'work/adapter-runtimes')) + ')')
    # Adapt two synthetic IDs to the verified live central resolver namespace.
    assert text.count("self.store_id = 'fixture-store-a'") == 1
    assert text.count("tenant_id='fixture-tenant-a'") == 1
    text = text.replace("self.store_id = 'fixture-store-a'", "self.store_id = 'fy_s_aaaaaaaaaaaaaaaaaaaaaaaa'")
    text = text.replace("tenant_id='fixture-tenant-a'", "tenant_id='cloud-37dbdbfc497e57f987c94122'")
    target = SNAPSHOT / 'tests/support.py'
    target.write_text(text, encoding='utf-8')
    rows.append({'source': str(source), 'sourceSha256': SUPPORT_PIN, 'target': str(target),
                 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                 'adaptation': 'Temporary path and two synthetic identity literals; canonical tenant and central-store IDs'})
    (ROOT / 'work/adapter-extension-source-pins.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    support = load_file('_gateway_copied_store_fixture', target)
    loader = load_file('_gateway_copied_extension_loader', BUNDLE / 'content_extension_loader.py')
    return support, loader.load_extension(BUNDLE, EXTENSION_PINS)


class NodeBridge:
    def __init__(self):
        self.process = subprocess.Popen([str(NODE), str(ROOT / 'tests/node_bridge.cjs')],
            cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding='utf-8', creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        self.answers = Queue()
        self.errors = []
        self.wires = []
        threading.Thread(target=self._read, daemon=True).start()
        threading.Thread(target=self._stderr, daemon=True).start()

    def _read(self):
        for line in self.process.stdout:
            self.answers.put(line)

    def _stderr(self):
        for line in self.process.stderr:
            if sum(map(len, self.errors)) < 16000:
                self.errors.append(line)

    def request(self, command, **values):
        key = uuid.uuid4().hex
        self.process.stdin.write(json.dumps({'id': key, 'command': command, **values}, ensure_ascii=False, allow_nan=False) + '\n')
        self.process.stdin.flush()
        answer = json.loads(self.answers.get(timeout=20))
        if answer.get('id') != key or answer.get('ok') is not True:
            raise AssertionError('Synthetic Node bridge contract failed')
        return answer['result']

    def transport(self, payload):
        self.wires.append(deepcopy(payload))
        return self.request('call', payload=payload)

    def close(self):
        self.process.stdin.close()
        try:
            self.process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            self.process.wait(timeout=5)
        self.process.stdout.close()
        self.process.stderr.close()


def writing_output():
    return {'summary': '虚构厨房说明候选', 'facts': [], 'hypotheses': ['表达方式仍需人工审核'],
        'artifact': {'title': '公共厨房使用提示', 'body': '公共厨房每周四打扫。请再核对现场实际安排。', 'tags': ['虚构说明']}}


class FullChainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.support, cls.workbench_class = prepare_snapshot()

    def setUp(self):
        self.fx = self.support.WorkflowFixture()
        self.addCleanup(self.fx.close)
        self.bridge = NodeBridge()
        self.addCleanup(self.bridge.close)
        self.ctx = self.bridge.request('init', fixtureOutput=writing_output())['trusted_context']
        self.adapter = ContentGatewayAdapter(self.bridge.transport, lambda: deepcopy(self.ctx))
        self.envelopes = []
        def call_model(envelope):
            self.envelopes.append(deepcopy(envelope))
            return self.adapter(envelope)
        self.wb = type(self).workbench_class(self.fx.store, root_dir=self.fx.directory / 'artifacts', model_adapter=call_model)

    def prepared_run(self, request_id, query='虚构厨房主题'):
        prepared = self.fx.call(self.wb, 'content_task_prepare', methodId='writing', query=query)
        args = {'taskId': prepared['result']['task']['id'],
                'expectedRevision': prepared['workspace']['revision'], 'requestId': request_id}
        return self.fx.call(self.wb, 'content_task_run', **args), args

    def assert_task_cannot_redispatch(self, args):
        replay = self.fx.call(self.wb, 'content_task_run', **args)
        self.assertTrue(replay['replayed'])
        before = len(self.bridge.wires)
        with self.assertRaises(Exception) as caught:
            self.fx.call(self.wb, 'content_task_run', taskId=args['taskId'], requestId='different-original-task-key')
        self.assertEqual(caught.exception.code, 'CONTENT_TASK_ALREADY_RUN')
        self.assertEqual(len(self.bridge.wires), before)

    def assert_no_candidate_or_customer_change(self):
        workspace = self.fx.read(self.wb)
        self.assertEqual(workspace['workflow']['artifacts'], [])
        self.assertEqual(workspace['drafts'], [])
        self.assertEqual(self.fx.customer_records(), self.fx.initial_customer_records)

    def test_original_task_reaches_real_service_and_persists_its_quoted_artifact(self):
        self.fx.call(self.wb, 'content_knowledge_import', document={'title': '虚构厨房资料',
            'text': '公共厨房每周四打扫。资料仅供离线验证。', 'kind': 'fact', 'sourceLabel': '虚构提供者'})
        evidence = self.fx.call(self.wb, 'content_knowledge_search', query='公共厨房')['result']['evidence'][0]
        result = writing_output()
        result['facts'] = [{'quote': '公共厨房每周四打扫。', 'evidenceId': evidence['evidenceId']}]
        self.bridge.request('configure', fixtureOutput=result)
        prepared = self.fx.call(self.wb, 'content_task_prepare', methodId='writing', query='公共厨房')
        task_id = prepared['result']['task']['id']
        args = {'taskId': task_id, 'expectedRevision': prepared['workspace']['revision'], 'requestId': 'full-chain-original-key'}
        completed = self.fx.call(self.wb, 'content_task_run', **args)
        self.assertEqual(completed['result']['task']['state'], 'succeeded')
        workspace = self.fx.read(self.wb)
        self.assertEqual(workspace['workflow']['artifacts'][0]['taskId'], task_id)
        self.assertEqual(workspace['workflow']['artifacts'][0]['output']['facts'][0]['quote'], '公共厨房每周四打扫。')
        replay = self.fx.call(self.wb, 'content_task_run', **args)
        self.assertTrue(replay['replayed'])
        self.assertEqual(len(self.bridge.wires), 1)
        recovered = self.adapter.status(self.envelopes[0])
        self.assertEqual(recovered['state'], 'succeeded')
        stats = self.bridge.request('stats')
        self.assertEqual(stats['providerCalls'], 1)
        self.assertEqual(stats['providerTransactions'], [False])
        self.assertEqual(stats['reserved'], 0)
        self.assertGreater(stats['spent'], 0)
        applied = self.fx.call(self.wb, 'content_task_apply', taskId=task_id)
        draft_id = applied['result']['appliedRefs']['draftIds'][0]
        self.fx.call(self.wb, 'content_draft_audit', draftId=draft_id, decision='approve')
        packet = self.fx.call(self.wb, 'content_package_build', draftId=draft_id)['result']['package']
        self.assertEqual(packet['citations'][0]['quote'], '公共厨房每周四打扫。')
        self.assertFalse(packet['published'])
        self.assertEqual(self.fx.customer_records(), self.fx.initial_customer_records)

    def test_timeout_keeps_original_task_unknown_and_status_never_dispatches_again(self):
        self.bridge.request('configure', mode='timeout')
        result, args = self.prepared_run('full-chain-timeout-key')
        self.assertEqual(result['result']['task']['state'], 'unknown')
        self.assertTrue(result['result']['task']['requiresReconciliation'])
        self.assert_task_cannot_redispatch(args)
        self.assertEqual(self.adapter.status(self.envelopes[0])['state'], 'unknown')
        stats = self.bridge.request('stats')
        self.assertEqual(stats['providerCalls'], 1)
        self.assertEqual(stats['providerTransactions'], [False])
        self.assertGreater(stats['reserved'], 0)
        self.assertEqual(stats['spent'], 0)
        self.assert_no_candidate_or_customer_change()

    def test_budget_denial_has_authoritative_no_execution_proof_and_no_candidate(self):
        self.ctx = self.bridge.request('init', fixtureOutput=writing_output(), budget=0)['trusted_context']
        result, args = self.prepared_run('full-chain-budget-key')
        self.assertEqual(result['result']['task']['state'], 'known_not_executed')
        self.assert_task_cannot_redispatch(args)
        stats = self.bridge.request('stats')
        self.assertEqual(stats['providerCalls'], 0)
        self.assertEqual(stats['reserved'], 0)
        self.assertEqual(stats['spent'], 0)
        self.assert_no_candidate_or_customer_change()

    def test_cloud_rejects_fabricated_quote_without_leaking_it_into_original_task(self):
        self.fx.call(self.wb, 'content_knowledge_import', document={'title': '虚构厨房资料',
            'text': '公共厨房每周四打扫。', 'kind': 'fact', 'sourceLabel': '虚构提供者'})
        evidence = self.fx.call(self.wb, 'content_knowledge_search', query='公共厨房')['result']['evidence'][0]
        candidate = writing_output()
        candidate['facts'] = [{'quote': '虚构价格为一元。', 'evidenceId': evidence['evidenceId']}]
        self.bridge.request('configure', fixtureOutput=candidate)
        result, args = self.prepared_run('full-chain-false-quote-key', '公共厨房')
        self.assertEqual(result['result']['task']['state'], 'unknown')
        self.assert_task_cannot_redispatch(args)
        self.assertEqual(self.adapter.status(self.envelopes[0])['state'], 'unknown')
        stats = self.bridge.request('stats')
        self.assertEqual(stats['providerCalls'], 1)
        self.assertEqual(stats['reserved'], 0)
        self.assertGreater(stats['spent'], 0)
        self.assert_no_candidate_or_customer_change()

    def test_lost_success_is_readable_by_original_key_but_not_privately_installed(self):
        def lost_response(payload):
            self.bridge.transport(payload)
            raise TimeoutError('synthetic-response-lost-after-settlement')
        self.adapter = ContentGatewayAdapter(lost_response, lambda: deepcopy(self.ctx))
        result, args = self.prepared_run('full-chain-lost-response-key')
        self.assertEqual(result['result']['task']['state'], 'unknown')
        self.assert_task_cannot_redispatch(args)
        readonly = ContentGatewayAdapter(self.bridge.transport, lambda: deepcopy(self.ctx))
        for _ in range(2):
            recovered = readonly.status(self.envelopes[0])
            self.assertEqual(recovered['state'], 'succeeded')
        local_task = self.fx.read(self.wb)['workflow']['tasks'][0]
        self.assertEqual(local_task['state'], 'unknown')
        stats = self.bridge.request('stats')
        self.assertEqual(stats['providerCalls'], 1)
        self.assertEqual(stats['reserved'], 0)
        self.assertGreater(stats['spent'], 0)
        self.assert_no_candidate_or_customer_change()

    def test_actual_service_hashes_python_canonical_float_and_unicode_bytes(self):
        content = {'query': '中文厨房😀', 'instructions': '', 'persona': {'score': 1.0},
                   'topic': None, 'draft': None, 'evidence': [], 'artifacts': []}
        raw = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
        envelope = {'contract': 'fangyu-content-workflow-v1', 'requestId': 'b' * 64,
            'taskId': 'fixture-float-task', 'scope': {key: self.ctx[key] for key in
                ('tenant_id', 'store_id', 'account_id', 'platform', 'company_id', 'actor')},
            'method': get_trusted_method('writing'), 'input': content,
            'inputDigest': hashlib.sha256(raw.encode('utf-8')).hexdigest(),
            'requirements': {'platformActionsAllowed': False, 'humanReviewRequired': True,
                             'sourceTextIsUntrustedData': True}}
        self.assertEqual(self.adapter(envelope)['state'], 'succeeded')
        self.assertIn('1.0', self.bridge.wires[-1]['input_json'])
        self.assertIn('中文厨房😀', self.bridge.wires[-1]['input_json'])
        self.assertEqual(self.bridge.wires[-1]['input_json'], raw)
        self.assertEqual(self.bridge.request('stats')['providerCalls'], 1)
        self.assert_no_candidate_or_customer_change()


if __name__ == '__main__':
    unittest.main()
