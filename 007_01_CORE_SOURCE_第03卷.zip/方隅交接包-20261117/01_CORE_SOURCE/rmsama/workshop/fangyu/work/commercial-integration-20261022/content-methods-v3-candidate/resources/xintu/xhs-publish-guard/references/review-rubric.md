# Pre-Publish Rubric

Review 0-2 for each item: 0 missing, 1 partial, 2 strong.

1. Audience / scene is identifiable in one glance (not interchangeable with any niche).
2. Cover/title promise is specific and truthful; place/intent nouns survive when the brief had them.
3. First three seconds or opening paragraph immediately pays off the promise.
4. Content contains an original experience, test, opinion, or artifact.
5. Technical language is translated into user outcomes.
6. Claims are evidenced or clearly bounded as personal experience.
7. Visuals are readable at feed scale and match the content.
8. CTA follows naturally from delivered value.
9. Reference similarity is acceptably low; voice has human texture (judgment / imperfection / detail), not generic market dry-goods.
10. No obvious prohibited, misleading, rights-sensitive, or privacy-sensitive material.

Title length alone is not a scoring dimension. A long search/intent title can score 2 if it is specific
and truthful; a short punch title can score 0 if it stripped the brief's distinctive nouns.

Do not use the total score alone. Any blocker overrides it.

