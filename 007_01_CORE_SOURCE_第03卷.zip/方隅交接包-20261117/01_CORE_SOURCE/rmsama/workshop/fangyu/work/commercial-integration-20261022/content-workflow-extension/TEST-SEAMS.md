# 内容工作流扩展：公开测试边界

本轮公开接口与边界由主窗口明确指定，属于已经批准的测试seam；不再另外请求确认。测试按已读取的`tdd` Skill执行，使用真实临时Store、固定ContentWorkbench原件和公开execute接口。业务测试由根作者维护，本文对应的作者只维护`tests/support.py`、`tests/test_workflow_security.py`及本说明和被授权的最小测试基线。

## 接口与夹具

扩展：`content_workflow.ContentWorkflowWorkbench(store,root_dir=None,model_adapter=None)`，`execute(action,user,store_id,data,authority_check=None)`。BASE仍为`accountId/platform`；写动作带`expectedRevision/requestId`；模型是公开注入边界`model_adapter(envelope)`，不是内部模块替身。

`WorkflowFixture`是唯一夹具：

```python
ctx = WorkflowFixture()
try:
    wb = ctx.make(model_adapter=None)
    workspace = ctx.read(wb)
    answer = ctx.call(wb, 'content_knowledge_import', document={
        'title': '虚构演示', 'text': '只用于临时数据库测试。',
        'kind': 'fact', 'sourceLabel': '测试夹具'})
finally:
    ctx.close()
```

公开属性是`store/user/account/authority`。`call`带默认账号、平台、最新**相同账号工作区**revision和新uuid；允许显式覆盖`accountId/platform/expectedRevision/requestId`。重放必须传原expectedRevision和requestId。读动作workspace/knowledge_search/methods_read不添加写字段。`read`只返回workspace。

Store来自固定真实`core/store.py`副本，不是内存模拟；fixture数据库在本扩展`work/test-runs`的TemporaryDirectory。users、accounts、stores及宿主授权资料均通过真实Store建立，authority回调从execute传入的同一真实连接读取授权，不替代ContentWorkbench内部鉴权。close先确认路径仍在专属临时根内再清理。

测试中的customer/leads/replies/tasks/AI/manual/rules/SOP都是新造记录，使用Store公开list/get/put检查它们保留；没有读取生产数据。只有外部模型Callable返回虚构结果或抛出虚构异常，无平台、网络或付费调用。

## 冻结基线

`tests/baseline`包含6个不可为通过测试而修改的快照：

- 原`stage-02/project/work/ui-native-r57/content_workbench.py`。
- 原`content_vendor/check_copy.py`、`diagnose_metrics.py`、`LICENSE-xintu.txt`、`method-bundle.json`。
- 原`stage-02/project/work/ui-runtime-r55/src/core/store.py`，只用于测试。

来源绝对路径、每文件SHA256和字节数在`tests/baseline/BASELINE-SHA256.json`；support导入前逐个核验。baseline目录用于正常导入原ContentWorkbench，Store使用其真实源码模块加载；未构造假的内部包、未改sys.modules中的产品模块来通过测试。若当前进程先载入了别处的ContentWorkbench，则明确失败，避免暗用正在变更的生产源。

## 安全测试覆盖

- 先成功导入资料，证明新动作确实可用，然后验证缺少authority不能读写。
- 他人员工账号、伪造租户、保存后员工禁用/角色/cloud绑定变化均拒绝。
- 同一员工的两个平台账号不共享documents/tasks/artifacts；不能运行另一账号task，也不能打包另一账号draft。
- prepare后账号owner/store/platform变化时，在模型调用前拒绝，原任务保持。
- 同一个Store的基础人设写入让旧revision失效；陈旧扩展写入返回409，不能覆盖人设、资料或客户记录。
- 同请求同输入重放稳定，不新增资料；同请求键换内容返回请求冲突。
- 无模型适配器返回CONTENT_MODEL_UNAVAILABLE，prepared任务、revision和回执不变。
- unknown或异常保留unknown；同run键重放及新键针对同unknown任务都不得再次调用外部模型。异常细节中的秘密canary不进入公开工作区/回执。
- 模型回调启动另一线程，经**真实基础ContentWorkbench公开API**完成读和人设写，并须在3秒内完成；最终必须保留该基础写入。适配器期间若仍持DB写锁，及时完成标记不会设置，测试明确失败，不能靠回调超时后才写入来冒充事务外执行。并发后run可成功提交，或409保留安全断点。
- 模型调用中撤销宿主权限，返回的生成结果不能安装artifact；既有客户数据保持。

上述测试不证明真实模型质量、平台发送/发布、客户端安装、UI认可或商业流程验收。它们观察公开workspace/receipt、公共Store数据与注入模型边界，未断言私有方法调用顺序。

## 运行

从本扩展根执行：

```text
python -X utf8 -B -m unittest discover -s tests -p test_workflow_security.py -v
```

基线/fixture的自检与core业务测试分开记录。core仍在开发时不把模块导入失败或未实现动作冒充业务red证据；主作者完成对应slice后运行，失败交由主作者修core，安全测试作者不改core或baseline。无需重复下载库或连接真人账号。

## 本作者当前运行记录

- support与安全测试语法检查通过；6个基线摘要一致，真实Store/基础ContentWorkbench读取与既有业务哨兵保留自检通过。
- 首轮运行15项安全测试：14项通过、1项未通过。模型事务外的另一线程基础写入、unknown/异常不重调、调用中撤销权限、账号变化和CAS保护均通过。
- 当时未通过项为内容包跨账号测试。加强正例门槛后曾单跑确认：当前账号已审核虚构稿调用`content_package_build`也在core返回`CONTENT_ACTION_FORBIDDEN`（当时尚未开放）。该red没有被改成接受所有403，不把未实现动作冒充隔离验证。
- 核心作者补齐apply/package后，本作者**只单跑此前失败的包隔离项**：1项通过，耗时0.215秒；当前账号先完成本地审核并成功构建内容包，另一账号不能选取该草稿，原账号内容和客户业务记录保留。未重复全15项，也未修改core或冻结基线。最终全套测试与合同由主作者统一留验收日志；生产模型、前端、平台和安装仍不在本次验证范围。

## 只读检查：接入现有后端的最小路线

以下位置来自本轮只读的`stage-02/project`候选，不代表当前原生进程或canonical已经采用。完整根为`C:\积木软件工坊\项目\方隅公寓客户版\work\parallel-integration-20261018\final-integration\stage-02\project`，本作者未修改该目录。

1. **保留原认证入口和同一Store。** `work/ui-native-r57/workbench_backend.py:1621`的`_content_dispatch`已经检查token身份、当前门店、账号tenant/owner/platform/store和`core._account_access`，去掉请求中的storeId后把BASE与原CAS/requestId传给组件。`:1642`附近authority回调在同一数据库再次核会话有效期、员工和门店选择。继续用这条路径，不增第二客户库，不从页面接收可信actor或模型适配器。
2. **替换组件类与受信闭包加载。** 同文件`:1591`的`_content_component`目前只按CONTENT_MODULE_SHA核一个ContentWorkbench，优先取`resources/content-workbench`副本；`:1648`目前构造`ContentWorkbench(self.core.store)`。生产闭包在旧base+4个content_vendor文件外，增加`content_workflow.py/workflow_methods.py/workflow_knowledge.py`和`workflow_vendor/normalize.py/LICENSE/PINS.json`，固定全部哈希。构造改为同一Store的ContentWorkflowWorkbench，传受控root_dir及明确宿主model_adapter。不要只改一个base SHA却让新增卫星模块从CWD任意导入。当前候选是普通绝对import；生产副本可做独立受信package的相对import适配，由加载器核完整闭包，避免污染全局同名模块。tests/baseline和测试Store不进入客户包。
3. **精确增加7动作。** `workbench_backend.py:54`的CONTENT_ACTIONS、`ui_native_host.py:51`的API_ACTIONS、前端`work/ui-approved-implementation/ui-preview/backend.mjs:145`的contentAction白名单必须一致增加：`content_knowledge_import/content_knowledge_search/content_methods_read/content_task_prepare/content_task_run/content_task_apply/content_package_build`。保留原11动作，不以`content_*`任意前缀替代显式白名单。请求字段只用core ACTION_FIELDS及BASE，写动作仍要求expectedRevision/requestId。
4. **同步读取/写入与大小分类。** `ui_native_host.py:54`的CONTENT_JSON_ACTIONS在旧白名单后立即计算；扩展白名单后必须重新覆盖计算，否则新动作会落入默认16KB预算。`:371`附近现有内容一般预算133120字节、素材300000字节、总硬上限300000字节。knowledge_import的100000字符不等于100000字节：应为该动作显式选择既有高预算，并在UI按完整UTF-8 JSON检查限额、超限返回413，不静默截断，也不为一个文本入口放大所有操作。前端backend.mjs:101的contentRead增加knowledge_search/methods_read；内容页`pages/content-operations.mjs:6`的MUTATIONS增加import/prepare/run/apply/package，继续保留账号切换、旧响应丢弃和未知请求的原编号核对。
5. **模型必须在宿主全局锁外。** 当前`workbench_backend.py:1629`的`with self.lock`覆盖组件整个execute。core已证明模型调用在Store事务外，但如果原样套在这里，仍会持有全局backend锁。主窗口应在短锁内完成身份/门店/账号预检、取不可变上下文，随后在锁外执行task_run；回写仍由组件+authority重新读取当前会话、账号与门店选择，不能把锁外运行当作免鉴权。不要在回调中另开SQLite写事务或依赖已失效的页面权限。其他本地动作可继续使用原短事务机制。
6. **按原冻结发布链装入。** `work/ui-native-r57/freeze_ui.py:251`目前只复制旧base+4vendor到resources/content-workbench，需显式复制新增闭包并进入source_pins/RELEASE.json。`ui_native_host.verify_release`接受resources前缀且要求实际文件集合与清单一致；不能在冻包后手工塞文件或改canonical目录。主窗口在独立候选完成HTTP/CSRF/会话/白名单与并发回归后，统一正常冻结/晋级。

宿主模型桥接尚未实现，本作者没有连接真实DeepSeek或其他服务。默认None时任务只能prepare，run返回CONTENT_MODEL_UNAVAILABLE且保留原状态。若主窗口接已有获准网关，须适配`envelope.requestId`的稳定模型执行键、scope/method/input/outputSchema与`{requestId,state,output}`回执，保留unknown和已知未执行的区别；不能借租房意向分类接口伪造17种内容任务，也不能把HTTP重试变成第二次计费调用。前端需读task.state/generated/artifact而非仅看工作区receipt成功，就宣称AI完成。包目前是带来源和素材状态的**本地Markdown/元数据内容包**，不是已生成视频、已发布、ZIP或可执行定时服务。
