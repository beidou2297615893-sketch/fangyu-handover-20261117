"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = '7350cac18bc023a560ec3592b8d623ccc1213192c0a773c670dd7dab259b1f56'
CLOSURE_SHA = 'a1b6486649cafe9fac8cd15d4aaacdc0ffbe1aa5c5cda59f8c2e27aae9177f21'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

"""Independent compiled representative: real local guards, synthetic cloud only."""
from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import hashlib,http.client,importlib.util,json,os,sys,threading,time,traceback,uuid
assert getattr(sys,'frozen',False) is True,'This positive must execute as an actual compiled EXE'
W=Path(sys.executable).resolve().parent;P=W/'project';OUT=W/('independent-factory-'+uuid.uuid4().hex);OUT.mkdir()
backend=server=None;threads=[];checks=[];events=[];device_calls=[];tamper=[False];passed=False
save=lambda name,v:(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n','utf-8')
def audit(event,args):
 if event in ('os.system','os.startfile','os.posix_spawn','subprocess.Popen'):raise RuntimeError('No platform/browser/process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  writing=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)
  if writing and not path.is_relative_to(OUT) and not (tamper[0] and path.is_relative_to(P)):raise RuntimeError('Own evidence/data or explicit own-copy tamper only')
sys.addaudithook(audit)
def load_fixture(path):
 name='independent_customer_cloud';m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
def denied(fn):
 try:fn()
 except Exception as error:return {'type':type(error).__name__,'message':str(error)}
 raise AssertionError('Expected original rejection')
def wait_state(service,state):
 end=time.monotonic()+9
 while service.state!=state and time.monotonic()<end:time.sleep(.025)
 assert service.state==state,service.status()
try:
 host,project,release,closure=load_host(W)
 _,files=host.verify_release(release,RELEASE_SHA);host.verify_backend_dependencies(release,files,project)
 fixture=load_fixture(W/'qa-fixtures/cloud_fixture.py');cloud=fixture.CloudStandin(json.loads((W/'qa-fixtures/compiled-fixture.json').read_bytes()));company=json.loads((project/'work/app/company.json').read_bytes())
 def transport(*args,**kwargs):
  value=cloud(*args,**kwargs);value['environment_id']=company['managedWorkspace']['environment_id'];return value
 integration=importlib.util.module_from_spec(importlib.util.spec_from_loader('integrations',loader=None));integration.__file__=str(release/'resources/platform-runtime/vendor-src/integrations.py');sys.modules['integrations']=integration;exec(compile(Path(integration.__file__).read_bytes(),integration.__file__,'exec'),integration.__dict__);integration.request_json=transport
 backend=host.create_backend(release,files,project_root=project,data_dir=OUT/'data',company=company)
 runtime=backend.platform_runtime;core=backend.core;app=runtime.server
 app._configure_bundled();runtime._platform_setup=True
 from assistant import douyin_connection_service as connection
 from core.douyin_comments_policy import DouyinCommentsPolicy
 from core.douyin_search_policy import DouyinSearchPolicy
 authority=app._customer_read_authority;assert authority is not None
 assert app._runtime_license_usage_scope()=='customer_distribution_read' and app._runtime_license_usage_scope('internal_self_use_read') is None
 account_revision=connection._components(app);comment=DouyinCommentsPolicy(app).resolve();assert len(account_revision)==64 and comment['purpose']=='douyin_owned_video_comments'
 assert denied(lambda:connection._binding(runtime.service))
 checks.append({'group':'actual_compiled_original_loader_factory_material_scope_without_device_cannot_execute','scope':'customer_distribution_read','componentOnlyNotAccountGrant':True,'closureFiles':len(closure['files'])})
 server=host.StaticServer(release,files,backend=backend,cookie_name='independent_customer_read');t=threading.Thread(target=server.serve_forever,daemon=True);t.start();threads.append(t)
 origin='http://127.0.0.1:'+str(server.server_port);headers={}
 def request(method,path,payload=None):
  c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,headers);r=c.getresponse();raw=r.read();h=dict(r.getheaders());status=r.status;c.close()
  try:value=json.loads(raw)
  except ValueError:value={'nonJsonResponse':True,'bytes':len(raw)}
  events.append({'method':method,'path':path,'action':payload.get('action') if payload else None,'status':status,'body':value});save('HTTP.json',events);return status,value,h
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 status,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});assert status==200
 headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];user=core.session(headers['Cookie'].split('=',1)[1]);store=cloud.first_store
 status,_,_=request('POST','/api/workbench',{'action':'customer_read_scope','data':{'usage_scope':'internal_self_use_read','approved':True}});assert status==403
 held=[False];revoked=[False]
 class OwnCloud:
  def __init__(self,*args,**kwargs):pass
  def call(self,operation,data,credential):
   device_calls.append(operation);save('DEVICE-CLOUD-OPERATIONS.json',device_calls)
   if operation=='device_enroll':return {'device':{'id':'independent-owned-device','owner':'fixture-admin','name':'隔离设备'}}
   if operation=='device_poll':
    if revoked[0]:
     from assistant.transport import CloudError
     raise CloudError(403,'device_revoked')
    return {'safety_hold':held[0],'command':None,'poll_after':1}
   if operation in ('contact_events_sync','contact_responses_sync'):return {'acknowledged':[]}
   if operation=='account_claim':return {'claimed':True}
   raise AssertionError('Unexpected cloud operation '+operation)
  def close(self):pass
 runtime.service.cloud_factory=OwnCloud
 runtime.service.bind('independent_owned_connection_code_abcdefghijklmnopqrstuvwxyz0123456789');wait_state(runtime.service,'online')
 own={'id':'independent-owned-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','status':'ready','name':'隔离账号','platform_uid':'9007199254742999'};core.store.put('accounts',own)
 bound=connection._binding(runtime.service,own['id']);assert bound[3]=='independent-owned-device' and bound[4]['id']==own['id']
 assert device_calls.count('device_enroll')==1 and device_calls.count('device_poll')>0
 held[0]=True;wait_state(runtime.service,'held');assert app._runtime_license_usage_scope()=='customer_distribution_read';denied(lambda:connection._binding(runtime.service,own['id']))
 held[0]=False;wait_state(runtime.service,'online');connection._binding(runtime.service,own['id'])
 original_user=deepcopy(core.store.get('users',user['id']));core.store.put('users',{**original_user,'disabled':True})
 try:denied(lambda:connection._binding(runtime.service,own['id']))
 finally:core.store.put('users',original_user)
 foreign={**own,'id':'independent-foreign-account','tenant_id':'independent-other-tenant'};core.store.put('accounts',foreign);denied(lambda:connection._binding(runtime.service,foreign['id']))
 checks.append({'group':'original_service_bind_dpapi_runner_device_session_and_hold_employee_tenant_guards','deviceEnroll':1,'syntheticCloudBoundaryOnly':True,'noExecutorOrSessionInjection':True})
 forbidden=['douyin_owned_keyword_search_page','dm','dm_listen','livestream_capture','douyin_livestream_messages','xiaohongshu_guarded_read','public_send','douyin_owned_connection_extra']
 assert all(authority.resolve(app,p) is None and app._customer_distribution_purpose(p) is None for p in forbidden)
 assert authority.runtime_license_review(app,'xiaohongshu_guarded_read') is None and DouyinSearchPolicy(app).resolve() is None
 assert app.company['runtime']['public_send_hold'] is True and app.company['runtime']['release_approved'] is False and app.company['runtime']['xiaohongshu_automation']=='hold'
 checks.append({'group':'exact_purpose_nonspill_search_dm_live_xhs_and_no_http_selector','forbiddenPurposes':forbidden,'httpDenied':403,'originalHolds':True})
 # Negative-only typed misattachment cannot lend another root or company.
 app._customer_read_authority=replace(authority,_project=OUT)
 try:assert app._runtime_license_usage_scope() is None;denied(lambda:connection._components(app))
 finally:app._customer_read_authority=authority
 company_id=app.company['id'];app.company['id']='independent-wrong-company'
 try:assert app._runtime_license_usage_scope() is None;denied(lambda:connection._components(app))
 finally:app.company['id']=company_id
 index=release/'resources/customer-read/review-index.json';raw=index.read_bytes();alias=OUT/'index-alias'
 os.link(index,alias)
 try:assert app._runtime_license_usage_scope() is None;denied(lambda:connection._components(app))
 finally:alias.unlink()
 tamper[0]=True
 try:index.write_bytes(raw+b' ');assert app._runtime_license_usage_scope() is None;denied(lambda:connection._components(app))
 finally:index.write_bytes(raw);tamper[0]=False
 license=project/'work/ui-runtime-r55/work/runtime/douyin-bridge/LICENSE';alias=OUT/'license-alias';os.link(license,alias)
 try:denied(lambda:connection._components(app))
 finally:alias.unlink()
 helper=sys.modules['fangyu_customer_read_distribution'];junction=W/'qa-fixtures/physical-junction'
 assert junction.is_dir() and getattr(junction.lstat(),'st_file_attributes',0)&0x400,'Independent physical junction fixture must actually exist'
 denied(lambda:helper._material_file(junction/'sentinel.txt',W/'qa-fixtures'))
 assert connection._components(app)==account_revision
 checks.append({'group':'typed_wrong_root_company_index_exact_bytes_and_physical_hardlinks_refused','originalBytesRestored':True,'ownPayloadOnly':True,'additionalDirectMaterialHelperPhysicalJunctionRejected':True})
 revoked[0]=True;wait_state(runtime.service,'revoked');assert app._runtime_license_usage_scope()=='customer_distribution_read';denied(lambda:connection._binding(runtime.service,own['id']))
 runtime.service.stop(timeout=8);denied(lambda:connection._binding(runtime.service,own['id']))
 # Original loader must accept the now-restored bytes, not a fixture-only hash bypass.
 host.verify_release(release,RELEASE_SHA);host.verify_backend_dependencies(release,files,project)
 checks.append({'group':'original_403_revocation_stop_and_restored_original_integrity_gates','componentMaterialNotCloudPermission':True})
 passed=True
finally:
 if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
 if server:server.shutdown();server.server_close()
 if backend:backend.close()
 for t in threads:t.join(4)
 save('HTTP.json',events);save('RESULTS.json',{'status':'PASS' if passed else 'RED','actualCompiledExe':True,'groups':checks,'groupCount':len(checks),'httpRequests':len(events),'deviceOperations':device_calls,'realCloudModelPlatformCalls':0,'nativeWindowOpened':False,'ownCloudContractResponses':True,'noInternalScopeExecutorOrSessionInjected':True,'allOwnServicesClosed':all(not t.is_alive() for t in threads) and (backend is None or getattr(runtime.service,'thread',None) is None or not runtime.service.thread.is_alive()),'realNativePlatformSecondPcUnverified':True})
 print(json.dumps({'status':'PASS' if passed else 'RED','groups':len(checks),'evidence':str(OUT)},ensure_ascii=False))
