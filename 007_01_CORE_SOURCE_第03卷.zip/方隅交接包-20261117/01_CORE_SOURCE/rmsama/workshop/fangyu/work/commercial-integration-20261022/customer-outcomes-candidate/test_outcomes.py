"""Original Core, SQLite Store and CustomerHistory; fictional candidate data only."""
from pathlib import Path
import hashlib,json,os,sys,tempfile,unittest
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
R=S/'work/ui-runtime-r55/src';N=S/'work/ui-native-r57'
HTTP_MODE='--http-fixture' in sys.argv
if HTTP_MODE:sys.argv.remove('--http-fixture')
def fence(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No subprocess/platform/model')
    if event in ('socket.connect','socket.bind') and (not HTTP_MODE or not isinstance(args[1],tuple) or args[1][0]!='127.0.0.1'):raise RuntimeError('Only candidate localhost HTTP')
    if event=='socket.getaddrinfo' and (not HTTP_MODE or args[0] not in ('127.0.0.1',None)):raise RuntimeError('No external DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):raise RuntimeError('Nonfixture DB forbidden')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not p.is_relative_to(W):raise RuntimeError('Noncandidate write forbidden')
sys.addaudithook(fence)
sys.path[:0]=[str(W),str(N),str(R)]
from core.engine import Core
from assistant.customer_list import _person
from customer_workbench import CustomerWorkbench
from customer_outcomes_workbench import CustomerOutcomesWorkbench,OutcomeError,EVENTS,RECEIPTS,digest,BASE

class OutcomesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=W)
        self.core=Core(Path(self.tmp.name)/'db',R/'resources',defer_startup_recovery=True)
        self.company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed','managedWorkspace':{'environment_id':'outcomes-synthetic'}}
        tenant='cloud-'+hashlib.sha256(b'outcomes-synthetic\nfangyu-apartment-client').hexdigest()[:24]
        self.user={'id':'user-a','tenant_id':tenant,'username':'alice','role':'operator','cloud_bound':True,'disabled':False}
        self.core.store.put('users',self.user);self.core.store.put('tenants',{'id':tenant,'tenant_id':tenant,'name':'fictional'})
        for tid,owner,store in [('task-a','alice','gubei'),('task-b','alice','gubei'),('task-c','alice','other'),('task-d','bob','gubei')]:
            self.core.store.put('accounts',{'id':'account-'+tid,'tenant_id':tenant,'cloud_owner':owner,'store_id':store,'platform':'xiaohongshu'})
            self.core.store.put('tasks',{'id':tid,'tenant_id':tenant,'cloud_owner':owner,'store_id':store,'platform':'xiaohongshu','account_id':'account-'+tid})
        self.customers=CustomerWorkbench(self.core,self.company,S);self.service=CustomerOutcomesWorkbench(self.core,self.customers)
        self.lead=self.add_lead('one');self.cid=_person(self.lead)[0]
        self.base={'storeId':'gubei','customerId':self.cid,'platform':'xiaohongshu'}
        self.costbase={'storeId':'gubei','customerId':'','platform':None}
        self.index=0
    def tearDown(self):self.tmp.cleanup()
    def add_lead(self,ident,task='task-a',author='same-customer'):
        t=self.core.store.get('tasks',task)
        row={'id':ident,'tenant_id':self.user['tenant_id'],'cloud_owner':t['cloud_owner'],'store_id':t['store_id'],'task_id':task,'platform':'xiaohongshu','author_id':author,'author':'合成客户','comment_id':ident,'source_id':'comment:'+ident,'text':'合成求租评论','note_url':'https://www.xiaohongshu.com/explore/0123456789abcdef01234567','created_at':'2026-10-22T16:30:00Z','ai_intent':{'status':'graded','level':'high'}}
        self.assertTrue(self.core.store.insert_lead(row));return row
    def snapshot(self):
        with self.core.store.connect() as db:return tuple(tuple(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records ORDER BY entity,id'))
    def read(self,base=None,**extra):return self.service.read(self.user,'gubei',{**(base or self.base),**extra})
    def request(self,kind='responded',base=None,**extra):
        base=base or self.base;current=self.read(base);self.index+=1
        return {**base,'requestId':'synthetic-request-'+str(self.index),'expectedVersion':current['version'],'sourceDigest':current['sourceDigest'],'operation':'record','targetEventId':None,'kind':kind,'occurredOn':'2026-10-23','fact':'本人核对的合成事实','source':'合成面谈记录','evidenceRef':'合成凭据说明','amountCents':None,'costCategory':None,'confirmed':True,**extra}
    def save(self,kind='responded',base=None,**extra):return self.service.save(self.user,'gubei',self.request(kind,base,**extra))
    def report(self,**extra):return self.service.report(self.user,'gubei',{'storeId':'gubei','dateFrom':'2026-10-23','dateTo':'2026-10-23',**extra})
    def test_01_save_restore_same_key_cross_account_and_distinct_statistics(self):
        self.add_lead('two',task='task-b');self.assertEqual(_person(self.core.store.get('leads','two'))[0],self.cid)
        raw=self.snapshot();request=self.request('responded');one=self.service.save(self.user,'gubei',request)
        recovered=self.read(requestId=request['requestId']);again=self.service.save(self.user,'gubei',request)
        self.assertEqual(one['receipt']['state'],'accepted');self.assertEqual(again['version'],1);self.assertEqual(recovered['receipt']['requestDigest'],digest(request))
        self.assertEqual(len(recovered['history']),1);self.assertEqual(self.report()['visibleCustomers'],1);self.assertEqual(self.report()['registeredCustomers'],1)
        after=tuple(r for r in self.snapshot() if r[0] not in (EVENTS,RECEIPTS));self.assertEqual(raw,after)
    def test_02_cas_versions_source_and_request_content(self):
        stale=self.request();self.save('contacted')
        with self.assertRaisesRegex(OutcomeError,'已更新'):self.service.save(self.user,'gubei',stale)
        request=self.request();lead={**self.lead,'text':'原评论发生变化'};self.core.store.put('leads',lead)
        with self.assertRaisesRegex(OutcomeError,'已变化'):self.service.save(self.user,'gubei',request)
        request=self.request();self.service.save(self.user,'gubei',request)
        with self.assertRaisesRegex(OutcomeError,'内容已变化'):self.service.save(self.user,'gubei',{**request,'fact':'另一个事实'})
    def test_03_cancel_tombstone_wins_against_late_save(self):
        request=self.request();self.assertEqual(self.read(requestId=request['requestId'])['receipt']['state'],'not_found')
        cancelled=self.service.cancel(self.user,'gubei',{**self.base,'requestId':request['requestId'],'requestDigest':digest(request)})
        self.assertEqual(cancelled['receipt']['state'],'cancelled');late=self.service.save(self.user,'gubei',request)
        self.assertEqual(late['receipt']['state'],'cancelled');self.assertEqual(late['version'],0);self.assertEqual(self.report()['registeredCustomers'],0)
    def test_04_saved_request_wins_against_cancel(self):
        request=self.request();self.service.save(self.user,'gubei',request)
        result=self.service.cancel(self.user,'gubei',{**self.base,'requestId':request['requestId'],'requestDigest':digest(request)})
        self.assertEqual(result['receipt']['state'],'accepted');self.assertEqual(result['version'],1)
    def test_05_revoke_keeps_history_and_correction_is_new_event(self):
        result=self.save('payment',amountCents=12345);event=result['history'][0]
        self.save('revoke',operation='revoke',targetEventId=event['id'],fact='金额录错，撤销后重新登记')
        self.assertEqual(self.report()['paymentCents'],None);self.assertTrue(self.read()['history'][1]['revoked'])
        self.save('payment',amountCents=12000);self.assertEqual(self.report()['paymentCents'],12000)
        self.assertEqual(len(self.read()['history']),3)
    def test_06_skipped_stages_no_inference_or_zero_denominator(self):
        self.save('signed');r=self.report();st={x['kind']:x for x in r['stages']}
        self.assertEqual(st['signed']['customers'],1);self.assertEqual(st['contacted']['customers'],0)
        self.assertIsNone(st['signed']['rate']);self.assertEqual(st['signed']['denominator'],0)
        self.assertIsNone(r['paymentCents']);self.assertIsNone(r['knownCostCents']);self.assertIsNone(r['receiptsToSpend']);self.assertIsNone(r['roi'])
    def test_07_cost_missing_zero_cents_and_payment_spend_ratio(self):
        self.save('payment',amountCents=10001);self.save('cost',self.costbase,amountCents=5000,costCategory='software')
        self.assertIsNone(self.report()['receiptsToSpend']);self.save('cost',self.costbase,amountCents=0,costCategory='labor');self.save('cost',self.costbase,amountCents=0,costCategory='channel')
        r=self.report();self.assertEqual(r['paymentCents'],10001);self.assertEqual(r['knownCostCents'],5000);self.assertEqual(r['receiptsToSpend'],2.0002);self.assertIsNone(r['roi'])
        self.assertFalse(r['independentlyReconciled'])
        with self.assertRaises(OutcomeError):self.save('payment',amountCents=1.2)
        with self.assertRaises(OutcomeError):self.save('payment',amountCents=True)
    def test_08_authority_store_scope_and_unknown_customer(self):
        foreign=self.add_lead('foreign',task='task-c',author='foreign')
        with self.assertRaises(Exception):self.read({**self.base,'customerId':_person(foreign)[0]})
        with self.assertRaises(Exception):self.service.read({**self.user,'username':'bob'},'gubei',self.base)
        with self.assertRaises(OutcomeError):self.read(storeId='other')
        self.core.store.put('users',{**self.user,'disabled':True})
        with self.assertRaises(Exception):self.read()
    def test_09_date_scopes_history_corrections_and_readonly(self):
        self.save('contacted',occurredOn='2026-10-22');self.save('responded');before=self.snapshot()
        r=self.report();st={x['kind']:x for x in r['stages']};self.assertEqual(st['contacted']['customers'],0);self.assertEqual(st['responded']['customers'],1);self.assertEqual(before,self.snapshot())
        with self.assertRaises(OutcomeError):self.report(dateTo='2026-02-30')
        with self.assertRaises(OutcomeError):self.save(confirmed=False)
    def test_10_duplicate_request_cannot_rebind_customer(self):
        req=self.request();self.service.save(self.user,'gubei',req);foreign=self.add_lead('another',author='another');new={**self.base,'customerId':_person(foreign)[0]}
        with self.assertRaises(OutcomeError):self.service.read(self.user,'gubei',{**new,'requestId':req['requestId']})
    def test_11_independent_core_connections_cas_serialize_one_event(self):
        import threading
        other=Core(self.core.store.directory,R/'resources',defer_startup_recovery=True)
        second=CustomerOutcomesWorkbench(other,CustomerWorkbench(other,self.company,S))
        one=self.request('contacted');two={**one,'requestId':'synthetic-other-window'};barrier=threading.Barrier(2);results=[]
        def worker(service,payload):
            barrier.wait()
            try:results.append(service.save(self.user,'gubei',payload)['receipt']['state'])
            except OutcomeError as error:results.append(error.code)
        threads=[threading.Thread(target=worker,args=pair) for pair in [(self.service,one),(second,two)]]
        for t in threads:t.start()
        for t in threads:t.join(10);self.assertFalse(t.is_alive())
        self.assertCountEqual(results,['accepted','OUTCOME_VERSION_CONFLICT']);self.assertEqual(len(self.read()['history']),1)
    def test_12_receipt_write_failure_rolls_back_event_in_same_sqlite_transaction(self):
        import sqlite3
        with self.core.store.connect() as db:
            db.execute("CREATE TRIGGER synthetic_receipt_failure BEFORE INSERT ON records WHEN NEW.entity='customer_outcome_receipts' BEGIN SELECT RAISE(ABORT,'synthetic receipt storage failure'); END")
        before=self.snapshot();req=self.request()
        with self.assertRaises(sqlite3.IntegrityError):self.service.save(self.user,'gubei',req)
        self.assertEqual(self.snapshot(),before);self.assertEqual(self.read(requestId=req['requestId'])['receipt']['state'],'not_found')

if __name__=='__main__':unittest.main(verbosity=2)
