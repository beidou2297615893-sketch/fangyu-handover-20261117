# 内容工作流扩展：独立源码候选

本目录供获客主体审后合入v66，未修改stage、canonical、生产数据、平台会话或云。它在原ContentWorkbench/Store之上增加内容业务，**不建立第二个客户库或KB数据库**。

## 已实现的业务

来源文本导入→原文切片→中文检索/引用→研究/定位/栏目→选题→笔记和口播任务→结果校验→应用到原人设/选题/草稿→原人工审核→本地内容包，已有真实临时Store下的连续链路测试。

方法库覆盖完整17模块，分成账号与策略、研究与计划、创作与资料、审核与运营等工作区可操作的结构化任务，不是43个仓库按钮。每项含输入资料、任务说明、严格输出结构、事实原文/假设和待审核产物。persona/topics/writing/video/revision可明确应用到原工作区对应业务记录；其余产物保存为同工作区的方案/报告，供编辑、审核和后续执行器使用。图文仍复用原content_render_cards；发布、排期、私信等产物是方案/内容包，未新接实际平台执行。

知识模块实际复用MIT `veeicwgy/ip-publisher`固定提交`2121445098d46cfa2947e3088f84b1255fa8fa13`的`ip_publisher/kb/normalize.py::normalize_text/extract_keywords`。只带该标准库纯函数、原MIT文本及固定摘要；没有把其另一套SQLite、网络抓取或模板生成器嵌入。原文与位置不规范化，中文匹配额外支持二字词。`fact`只表示来源被标作陈述，不表示世界事实已核实。

## 生产装配闭包

新增4个源码：`content_workflow.py`、`workflow_methods.py`、`workflow_knowledge.py`、`content_extension_loader.py`；新增目录`workflow_vendor/`的normalize.py、LICENSE、PINS.json。保留原`content_workbench.py`及`content_vendor`四文件。无需新Python包；原基础素材/卡片仍使用其已有Pillow。测试Store和tests/baseline绝不能装入客户运行目录。

生产通过受信冻结清单先核加载器本身，再调用：

```python
WorkbenchClass = trusted_loader.load_extension(frozen_directory, trusted_source_pins)
workbench = WorkbenchClass(existing_store, model_adapter=host_model_adapter)
answer = workbench.execute(action, authenticated_user, selected_store_id, payload,
                           authority_check=current_host_authority)
```

`trusted_source_pins`必须是宿主冻结/RELEASE固定的四源码摘要，键严格为content_workbench.py、content_workflow.py、workflow_methods.py、workflow_knowledge.py，不能从同目录可改PINS文件自授权。loader在私有包中执行已核同一份源码字节，按包内相对导入，拒绝路径重解析、多硬链和同名flat模块污染；7个vendor资源另外由源码固定摘要核验。这是可信代码完整性加载，不是操作系统沙箱。不要把候选路径加入全局sys.path来接生产。

## 七个新增动作

所有动作沿用原BASE `accountId/platform`，可信员工、企业、门店、账号与authority由宿主传入。写动作沿用`expectedRevision/requestId`；同键重放必须保留原payload与expectedRevision。读取继续用原`content_workspace_read`，新增数据位于`workspace.workflow`。

| 动作 | 业务字段 | 输出 |
|---|---|---|
| content_methods_read（读） | 无额外字段 | 17项结构化方法、输出schema和待审核说明 |
| content_knowledge_import | document={title,text,kind:fact或hypothesis,sourceLabel} | 文档、切片、摘要、来源标签；不会访问sourceLabel对应URL/文件 |
| content_knowledge_search（读） | query、limit可选1—20 | evidence列表，含原文、字符位置、文档摘要、资料类型 |
| content_task_prepare | methodId、query；可选instructions/topicId/draftId/evidenceIds/artifactIds | prepared任务、不可变输入快照、方法/输入摘要；不调用模型 |
| content_task_run | taskId | 任务状态、产物编号和回执；调用注入宿主，按严格schema校验 |
| content_task_apply | taskId | 将当前有效候选应用到原人设/选题/草稿或同工作区方案，返回appliedRefs；再应用不重复创建 |
| content_package_build | draftId | 经原人工审核的固定版本本地包及Markdown；包含引用、假设、素材和就绪状态 |

17 methodId：strategy/persona/homepage/research/topics/columns/writing/video/visual/knowledge/revision/audit/package/scheduling/engagement/growth/learning。详见METHODS.md。互动方案可产comment_reply或dm草稿及明确targetId，不发送或声称已验证收件人。

普通输入是纯JSON，单次扩展预算500000 UTF-8字节。单文档最多100000字符、当前账号最多100份/总500000字符；不隐式截断。文档正文相同时ID稳定，来源/资料类型不同返回冲突，不悄悄把假设提升成事实。引用位置是Python Unicode字符、0基/end不含终点，JS UTF-16需转换。

## 宿主模型合同

`model_adapter`默认None。未接通时prepare可用，run明确返回CONTENT_MODEL_UNAVAILABLE且不改任务/回执，不返回模板伪装AI。生产必须使用已有获准模型网关的独立内容任务合同，不能借租房意向分类接口伪造17种内容生成。

Callable接收envelope：contract/requestId/taskId、可信scope、method（含instructions/outputSchema）、input（人设/选题/原稿/证据/前置产物）、inputDigest和requirements。资料正文是不可信业务输入，不能扩大工具或执行权限。

返回仅允许：

```text
{requestId: 原envelope.requestId, state: succeeded, output: 结构化结果}
{requestId: 原envelope.requestId, state: unknown}
{requestId: 原envelope.requestId, state: known_not_executed}
```

输出必须为`summary/facts/hypotheses/artifact`四字段。facts只能引用本次kind=fact证据的连续原文；artifact证据标识也需存在，未知状态/执行字段、超长值、无效数字或非法控制字符拒绝。精确引用并不证明正文每句话均被证据支持，仍需事实审核。`example_result`仅供虚构测试，绝不能当生产默认模型。

run先以同一工作区事务保存稳定runId/原requestId与running回执，释放Store连接后才调用宿主；结束再重新认证、核输入版本并保存。异常/无回执为unknown，非法输出为completed_invalid，明确未执行为known_not_executed；这些均不自动重试。进程在预留后中断会保留running和requiresReconciliation，宿主需按原模型键核对，不能换号重发。底层调用/计费不能由本模块独立证明，公开产物标injected_host_adapter/modelExecutionVerified=false/billingVerified=false。

调用中资料变化时保留candidate_stale产物、任务needs_revalidation，拒绝应用。调用中权限撤销则不安装结果，原running回执保留供原主体核对。宿主网关还须持久保存实际提供者回执；本模块不承诺跨云计费恢复或凭空取回原结果。

## 草稿、引用和内容包语义

run成功只生成候选，不直接覆盖原人设或草稿；apply才保存，且再核方法/输入摘要。修订按稿型更新主要字段：视频更新script并保留原body配文，图文更新body并保留原script配套口播。原素材、备注和历史均保留，旧素材标assetsNeedReview；默认携带原稿证据，但模型仍须重新选择有效引文，不盲目沿用已删除语句的旧主张。内容包元数据和Markdown导出同时保留配文与口播。

包要求原稿当前版本已有真实人工approve标记。素材读取核账号范围/实际blob摘要。包可能是package_ready、needs_assets、needs_asset_review、needs_video_asset；全部published=false/platformExecuted=false/factsVerified=false。package_ready只表示本地图片内容包条件具备，不代表平台接受、已发出或取得实际发送权限。视频方法目前产生口播和分镜，未生成视频文件。

结果中的内部来源/任务/资产标识留给软件；用户导出的Markdown只有业务文案、资料标题和待办说明，不夹带本机路径/调试字段。前端应按纯文本或已消毒Markdown显示来源和生成内容，不能执行输入中的HTML/指令。

## 根窗口接入与尚缺工作

具体旧源路径及行号见TEST-SEAMS.md的6项接线路线。需要同步backend.CONTENT_ACTIONS、ui_native_host.API_ACTIONS/CONTENT_JSON_ACTIONS及前端contentAction白名单；只显式增加七动作。knowledge_import单独处理UTF-8预算，不能因旧16KB/300KB上限静默丢内容或放宽全部操作。

**原backend._content_dispatch整段持self.lock。** 模块已证明模型在Store事务外，但宿主也必须在短锁预检后锁外运行task_run，随后让authority重新核会话/门店/账号，不能持全局backend锁等待模型。不要为释放锁而绕过认证。

freeze_ui和source_pins/RELEASE需纳入完整新闭包与loader；不能在冻包后手塞文件或只核旧base摘要。先比对本目录tests/baseline/BASELINE-SHA256.json与实际v65基础，若基础有变化先复核受保护接口与真实Store行为。

尚缺：生产内容模型网关适配、前端任务表单/产物编辑/错误和未知回执处理、HTTP/CSRF/会话/全局锁回归、统一冻结安装，以及真实模型内容质量/平台身份与发布/私信验收。本候选不替root做这些未经验证的完成声明。

## 验证与交付

运行`python -X utf8 -B verify_candidate.py`，查看VERIFICATION.json及FINAL-tests.log。涵盖真实临时Store全链、原客户/人工/AI记录保留、账号员工隔离、CAS/幂等、调用中并发基础写入/权限撤销、unknown不重发、假设/伪引用拒绝、旧稿素材与引用保留、加载器完整性和全部17方法。夹具均为虚构资料，无真实平台/收费模型调用。

日志保留逐段red/green；最初知识存储代码在基线夹具到位前已写，未伪称该段有业务先红证据。方法/prepare/run/apply-package/修订保留等后续slice均有可复现的公开接口红绿日志。
