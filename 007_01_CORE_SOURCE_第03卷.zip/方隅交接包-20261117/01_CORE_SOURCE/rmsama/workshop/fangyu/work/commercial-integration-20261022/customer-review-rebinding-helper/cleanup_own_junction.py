from pathlib import Path
import hashlib,json,os,stat,datetime
W=Path(__file__).resolve().parent
old=W.parent/'customer-read-purpose-after-f82-independent-review'
link=old/'independent-compiled/dist/FangyuWorkbench/qa-fixtures/physical-junction'
target=old/'physical-junction-target'
assert link.absolute().is_relative_to(old.absolute()) and target.absolute().is_relative_to(old.absolute())
info=link.lstat();assert stat.S_ISDIR(info.st_mode) and getattr(info,'st_file_attributes',0)&0x400
assert getattr(info,'st_reparse_tag',0)==0xA0000003
assert link.resolve()==target.resolve() and target.is_dir()
sentinel=target/'sentinel.txt';raw=sentinel.read_bytes();signature=(target.stat().st_dev,target.stat().st_ino)
# Windows os.rmdir on an existing junction removes that directory entry only.
# It never enumerates/recurse-deletes the target directory.
os.rmdir(link)
assert not link.exists() and sentinel.read_bytes()==raw
assert (target.stat().st_dev,target.stat().st_ino)==signature
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorRejectedOperation':'Remove-Item on own test junction','priorToolStatedReason':'rejected: blocked by policy; no more specific reason supplied','link':str(link),'target':str(target),'verifiedReparseTag':'IO_REPARSE_TAG_MOUNT_POINT','replacement':'os.rmdir(exact_verified_junction); no recursion','linkRemoved':True,'targetAndSentinelUnchanged':True,'sentinelBytes':len(raw),'sentinelSha256':hashlib.sha256(raw).hexdigest(),'oldSealedEvidenceNotRewritten':True,'productOrUserFilesTouched':False}
(W/'JUNCTION-CLEANUP-ADDENDUM.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'linkRemoved':True,'targetUntouched':True,'receipt':str(W/'JUNCTION-CLEANUP-ADDENDUM.json')},ensure_ascii=False))
