"""Normal-depth, isolated Native launch of the preserved pre-icon-adapter EXE."""
from pathlib import Path
import argparse,json,os,shutil,subprocess
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'standard-held-sample-v71-native/dist/FangyuWorkbench'
OWN=HERE/'q'
def main():
    global SOURCE,OWN
    parser=argparse.ArgumentParser();parser.add_argument('--secured',action='store_true');options=parser.parse_args()
    if options.secured:
        SOURCE=HERE/'standard-held-sample-v71-secured-native/dist/FangyuWorkbench';OWN=HERE/'z'
    OWN.mkdir(exist_ok=False);target=OWN/'a';shutil.copytree(SOURCE,target)
    env=dict(os.environ)
    for key in list(env):
        if key.startswith(('PYTHON','FANGYU_')) or key=='VIRTUAL_ENV':env.pop(key,None)
    for key,folder in (('LOCALAPPDATA','l'),('APPDATA','r'),('TEMP','t'),('TMP','t')):
        path=OWN/folder;path.mkdir(exist_ok=True);env[key]=str(path)
    env['PATH']=str(Path(env.get('WINDIR','C:/Windows'))/'System32')+';'+env.get('WINDIR','C:/Windows')
    result=OWN/'NATIVE-FIRST-START.json'
    with (OWN/'NATIVE-FIRST-START.log').open('xb') as log:
        child=subprocess.run([str(target/'FangyuWorkbench.exe'),'--native-smoke','--result-file',str(result)],
            cwd=OWN,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    icon=next((target/'project/work/ui-native-r57/releases').glob('*/resources/brand.ico'))
    report={'scope':'Normal installation-depth isolation probe on preserved pre-icon-adapter Native entry',
        'nativeExitCode':child.returncode,'programIconPathCharacters':len(str(icon)),
        'unmodifiedNativeHostAndIconPath':True,'knownCacheGuardIssueRemainsInThisHistoricalSample':True,
        'productionWrites':0,'otherWindowsOperated':False,
        'nativeResult':json.loads(result.read_text('utf-8')) if result.exists() else None}
    (OWN/'PROBE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps({'exit':child.returncode,'iconPathLength':len(str(icon)),
        'nativeStatus':report['nativeResult'].get('status') if report['nativeResult'] else None},ensure_ascii=True))
    if child.returncode:raise SystemExit(1)
if __name__=='__main__':main()
