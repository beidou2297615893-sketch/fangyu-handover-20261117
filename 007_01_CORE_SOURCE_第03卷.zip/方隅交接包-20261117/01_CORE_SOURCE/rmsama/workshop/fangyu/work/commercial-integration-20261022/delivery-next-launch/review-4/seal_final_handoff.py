"""Seal an evidence index; never install or open a Native process."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def evidence(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--independent-report", required=True)
    parser.add_argument("--independent-receipt", required=True)
    args = parser.parse_args()
    independent = Path(args.independent_report).resolve()
    if not independent.is_relative_to(WORK / "standard-distribution-independent-review"):
        raise RuntimeError("Independent report must belong to its assigned review folder")
    independent_value = read(independent)
    receipt = Path(args.independent_receipt).resolve()
    if not receipt.is_relative_to(WORK / "standard-distribution-independent-review"):
        raise RuntimeError("Independent receipt must belong to its assigned review folder")
    receipt_value = read(receipt)
    if evidence(receipt)["sha256"] != "a5350754d2872f05ee56e192a0b1a0d9446d4d3cce2e2a48ec2507571bd84880":
        raise RuntimeError("Independent final receipt changed")
    if receipt_value["blockingFindings"] or not receipt_value["reviewStoppedWriting"]:
        raise RuntimeError("Independent review is not stopped and free of blockers")
    if evidence(independent)["sha256"] != "7c609ac25d3bb3ae960324246f2dbb532b3bd10fe8171f16875d0e86526b1d21":
        raise RuntimeError("Independent final report changed")
    if independent_value["status"] != "PASS_FINAL_V72_CLEAN_AND_QA_ISOLATION_INDEPENDENT_REVIEW":
        raise RuntimeError("Final independent boundary review is not PASS")
    clean = HERE / "standard-held-clean-v72"
    qa = HERE / "standard-held-sample-v72-qa2"
    pins = read(clean / "SOURCE-DERIVED-PINS.json")
    source = read(WORK / "delivery-v72/FINAL-PINS.json")
    native = read(HERE / "c72/RESULT.json")
    qa_value = read(qa / "relocation-qa/RESULT.json")
    content = read(clean / "PACKAGE-CONTENT-SCAN.json")
    entry = (clean / "standard_entry.py").read_text(encoding="utf-8")
    for unwanted in ("CloudStandin", "SAMPLE", "--runtime-smoke", "--native-smoke", "synthetic-standard-admin"):
        if unwanted in entry:
            raise RuntimeError("Clean entry unexpectedly contains a synthetic QA branch")
    if source["unifiedPinsSha256"] != pins["sourceClosureSha256"]:
        raise RuntimeError("Source v72 pin mismatch")
    if evidence(clean / "SOURCE-DERIVED-PINS.json")["sha256"] != receipt_value["cleanSourceDerivedPinsSha256"]:
        raise RuntimeError("Independent reviewed clean inputs changed")
    if evidence(qa / "SOURCE-DERIVED-PINS.json")["sha256"] != receipt_value["qa2SourceDerivedPinsSha256"]:
        raise RuntimeError("Independent reviewed QA inputs changed")
    if not native["status"].startswith("PASS_") or not qa_value["status"].startswith("PASS_"):
        raise RuntimeError("Candidate runtime evidence not PASS")
    if not native["normalCloseByOwnPidOnly"] or not native["cleanEntryHasNoSampleOrFixedIdentityExecution"]:
        raise RuntimeError("Native/default clean entry evidence incomplete")
    if any(content["findings"].values()):
        raise RuntimeError("Static package boundary scan has findings")
    for name, expected in pins["pins"].items():
        if evidence(clean / name)["sha256"] != expected:
            raise RuntimeError("Fixed build/source metadata bytes changed")
    for name, expected in pins["projectPins"].items():
        if evidence(clean / "payload/project" / name)["sha256"] != expected:
            raise RuntimeError("Fixed project contract bytes changed")
    compiled = clean / "dist/FangyuWorkbench/FangyuWorkbench.exe"
    if evidence(compiled)["sha256"] != pins["compiledEntrySha256"]:
        raise RuntimeError("Compiled entry bytes changed")
    if evidence(clean / "installer.original.py")["sha256"] != pins["installerSourceSha256"]:
        raise RuntimeError("Original installer source changed")
    sealed_draft = HERE.parent / "install_next_launch.DRAFT.py"
    if evidence(sealed_draft)["sha256"] != "0fb1fd17be8518541123232666e9f659c0a1b34f39f1ac2c24aacaade986a3d4":
        raise RuntimeError("Original sealed next-launch draft changed")
    artifacts = []
    for name_key, sha_key in (("portableZip", "portableZipSha256"), ("installer", "installerSha256")):
        row = evidence(clean / pins[name_key])
        if row["sha256"] != pins[sha_key]:
            raise RuntimeError("Final package bytes changed")
        artifacts.append(row)
    paths = [
        WORK / "delivery-v72/FINAL-PINS.json",
        WORK / "delivery-v72/frozen-native/SUMMARY.json",
        clean / "SOURCE-DERIVED-PINS.json",
        clean / "SOURCE-DERIVED-DIFF.patch",
        clean / "PACKAGE-CONTENT-SCAN.json",
        clean / "standard_entry.py",
        clean / "BUILD.json",
        clean / "FILE-MANIFEST.json",
        HERE / "c72/RESULT.json",
        HERE / "c72/qa-install-standard/install-result.json",
        qa / "SOURCE-DERIVED-PINS.json",
        qa / "SOURCE-DERIVED-DIFF.patch",
        qa / "relocation-qa/RESULT.json",
        qa / "relocation-qa/native-backend-http.json",
        HERE / "SLIM-WEBVIEW2-DETECTION.json",
        HERE / "FINAL-STANDARD-DISTRIBUTION-READ-ME.md",
        HERE / "seal_final_handoff.py",
        sealed_draft,
        independent,
        receipt,
    ]
    for name, expected in receipt_value["evidence"].items():
        path = receipt.parent / name
        if path.parent != receipt.parent or evidence(path)["sha256"] != expected:
            raise RuntimeError("Independent supporting evidence changed")
        if path not in paths:
            paths.append(path)
    result = {
        "status": "INTERNAL_HELD_STANDARD_V72_EXECUTABLE_CANDIDATE_EVIDENCE_SEALED",
        "createdAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "writeScope": str(HERE),
        "source": source,
        "allFinalBuildPins": pins,
        "artifacts": artifacts,
        "evidence": [evidence(path) for path in paths],
        "independentReviewStatus": independent_value.get("status"),
        "independentReceiptStatus": receipt_value.get("status"),
        "deliveryPolicy": {
            "onlyCleanCandidateMayBeHandedToPeopleAfterRootReview": True,
            "cleanCandidate": str(clean),
            "qa2RunnerIsInternalAndMustNotBeDistributed": True,
            "qa2Runner": str(qa),
            "commercialApprovalStillRequired": True,
        },
        "matureRoute": {
            "route": "Existing PyInstaller onedir and original appended-ZIP self-extracting installer",
            "originalInstallerSha256": pins["installerSourceSha256"],
            "installerSourceUnchanged": True,
            "fullProjectRequired": True,
            "publicSourceFiles": 3152,
            "derivedClosureFiles": 3150,
            "packagedFilesIncludingFrozenHost": 3795,
            "releaseResources": 196,
        },
        "derivedScope": {
            "existingProjectFilesChanged": pins["changedExistingFiles"],
            "localDescriptorsOmitted": pins["omittedLocalInstallationDescriptors"],
            "contractAdded": pins["addedFiles"],
            "additionalEntryAdaptations": [
                "Relocatable frozen entry starts the fixed r57 Native host and original backend",
                "Complete project file-set verification before dynamic code; reject caches and unlisted files",
                "Pinned source-only imports plus cache/extension audit within the packaged project",
                "Verified icon copy to own short state path for the original .NET window icon",
                "Clean product omits synthetic identity, test runner and test execution arguments",
            ],
        },
        "validation": {
            "nativeDefaultStartAndNormalClose": True,
            "nativePage": native["nativeReady"]["dom"]["page"],
            "nativeFontLoaded": native["nativeReady"]["dom"]["font_status"] == "loaded",
            "nativeImages": native["nativeReady"]["dom"]["images"],
            "nativeCoversViewport": native["nativeReady"]["dom"]["fit"]["covers_viewport"],
            "ownedInstallerExtractAndPayloadVerification": True,
            "relocatedCheckAndStaticHttp": True,
            "separateFixtureQaBackendCustomersXlsxKnowledge": True,
            "sevenHoldContractNegativesRefused": qa_value["relocatedFrozenExecutableChecks"]["native-backend-http"]["functionalChecks"]["contractNegatives"],
            "WindowsOnlyPathNoPythonOrVenvEnvironment": True,
            "existingWebView2DetectionUsesOriginalInstaller": True,
            "humanVisualApproval": False,
            "secondPhysicalWindowsPc": False,
            "realEnterpriseOrPlatformLoginCollectionSend": False,
        },
        "size": {
            "cleanSlimZipBytes": artifacts[0]["bytes"],
            "cleanSlimSetupBytes": artifacts[1]["bytes"],
            "cleanSlimZipGroups": content["groups"],
            "preservedV70FullOfflineRepresentativeZipBytes": 482699760,
            "preservedV70OfflineRuntimeCompressedBytes": 213013238,
            "preservedV70OfflineFullPublicProjectCompressedBytes": 238802044,
            "preservedV70OfflineFrozenHostCompressedBytes": 29997408,
            "sizeComparisonUsesDifferentSourceRevisions": True,
        },
        "runtimeRequirementsAndLimits": [
            "Windows 10/11 x64 with supported .NET desktop runtime and already installed WebView2",
            "Slim package has no offline WebView2; original installer stops with instructions if absent",
            "No original machine Python, venv, local model weights or dedicated GPU required",
            "No GPL FFmpeg binary bundled; media depends on separately installed audited external tools/fonts",
            "Historical source-provenance paths are retained as evidence and are not execution dependencies",
            "Normal installation depth passed; very deep nonstandard QA paths previously hit .NET path limit or Native load timeout",
        ],
        "shortPathGuidance": {
            "originalInstallerDefaultTarget": "%LOCALAPPDATA%/fangyu-apartment-clientWorkspaceApp",
            "normalCandidateData": "%LOCALAPPDATA%/FangyuWorkbenchStandard/data",
            "realDefaultTargetInstallationNotPerformedByThisAgent": True,
            "zipQaAdvice": "Use one shallow dedicated extraction directory; avoid repeated archive-name nesting or extracting into a deep evidence tree",
            "testedOwnQaExtractionDirectory": read(HERE / "c72/qa-install-standard/install-result.json")["target"],
            "noFurtherProductionProfileOrNativeTest": True,
        },
        "approval": {
            "release_approved": False,
            "automation": "hold",
            "public_send_hold": True,
            "centralIdentityDeviceAccountAuthorizationPreserved": True,
            "commercialDistributionApproved": False,
            "realInstallationByThisAgent": False,
            "rootCanonicalV72InstallationIsSeparate": True,
            "productionDataSessionBindingWritesByThisAgent": 0,
        },
        "supersededEvidenceFields": [
            "SOURCE-DERIVED-PINS.nativeStartEvidencePending=true was sealed before Native testing; c72/RESULT.json supersedes that field",
            "QA RESULT.remaining mentions future final pins; this index fixes source to root FINAL-PINS v72",
            "The agent's prepared v71 next-launch copy is historical only; root prepared and installed its own reviewed v72 copy",
        ],
        "redEvidencePreserved": [
            "v70 original frozen release approval guard refusal",
            "v71 unlisted cached bytecode execution and old QA normal-data pollution found by independent review",
            "Very deep path .NET icon path limit and Native load timeout",
            "First v72 QA production-profile mutex competition; final QA2 uses original fixture profile",
        ],
        "noFurtherNativeOrProductionProfileTests": True,
    }
    destination = HERE / "FINAL-STANDARD-DISTRIBUTION-HANDOFF.json"
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(evidence(destination), ensure_ascii=False))


if __name__ == "__main__":
    main()
