from pathlib import Path
import json,hashlib
w=Path(__file__).parent
base={'storeId':'gubei','customerId':'a'*64,'leadId':'lead-0','platform':'xiaohongshu','requestId':'digest-vector','expectedVersion':'b'*64,'sourceDigest':'c'*64,'status':'graded','level':'high'}
rows=[]
for reason in ['已核对原评论明确两个月需求','  中文与 emoji 🏠\n第二行理由  ','预算包含人民币 ¥ 与换行\n租期 1—12 个月']:
    payload={**base,'reason':reason};normalized={**payload,'reason':reason.strip()}
    canonical=json.dumps(normalized,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    rows.append({'payload':payload,'canonical':canonical,'requestDigest':hashlib.sha256(canonical.encode()).hexdigest()})
(w/'DIGEST-VECTORS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),'utf-8')
print('3 digest vectors written')
