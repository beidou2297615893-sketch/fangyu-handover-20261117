from pathlib import Path
import ast, hashlib, json

W=Path(__file__).parent
P=W.parents[2]
N=P/'work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-native-r57'
E=W.parent/'content-workflow-extension'
expected=json.loads((E/'CANDIDATE-FILES.json').read_text('utf-8'))
additions={r['path']:r['sha256'] for r in expected['files'] if r['path'].endswith('.py') or r['path'].startswith('workflow_vendor/')}
digests={}
for name,value in additions.items():
    path=N/name;raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest()
    assert actual==value,(name,actual,value)
    if name.endswith('.py'):compile(raw,str(path),'exec')
    digests[name]=actual
tree=ast.parse((N/'workbench_backend.py').read_text('utf-8'))
values={}
for item in tree.body:
    if isinstance(item,ast.Assign) and isinstance(item.targets[0],ast.Name):
        key=item.targets[0].id
        if key in ('CONTENT_MODULE_SHA','CONTENT_EXTENSION_LOADER_SHA'):values[key]=ast.literal_eval(item.value)
        elif key=='CONTENT_EXTENSION_PINS':
            values[key]={ast.literal_eval(k):(values[v.id] if isinstance(v,ast.Name) else ast.literal_eval(v)) for k,v in zip(item.value.keys,item.value.values)}
assert values['CONTENT_EXTENSION_LOADER_SHA']==digests['content_extension_loader.py']
assert values['CONTENT_EXTENSION_PINS']==json.loads((E/'TESTED-LOADER-PINS.json').read_text('utf-8'))
assert hashlib.sha256((N/'content_workbench.py').read_bytes()).hexdigest()==values['CONTENT_MODULE_SHA']
freezer=ast.parse((N/'freeze_ui.py').read_text('utf-8'))
closure=next(ast.literal_eval(node.iter) for node in ast.walk(freezer) if isinstance(node,ast.For) and isinstance(node.iter,ast.Tuple)
    and any(isinstance(v,ast.Constant) and v.value=='content_workbench.py' for v in node.iter.elts))
assert set(additions)<=set(closure)
for name in ('workbench_backend.py','ui_native_host.py','freeze_ui.py'):
    raw=(N/name).read_bytes();compile(raw,str(N/name),'exec');digests[name]=hashlib.sha256(raw).hexdigest()
out=dict(status='PASS_SOURCE_CLOSURE',productionFiles=digests,freezerContentClosure=list(closure),
    exactHostSourcePins=values['CONTENT_EXTENSION_PINS'],baseUnchanged=True,
    newPythonDependencies=False,installed=False,frozenVerified=False,realModelCalls=0)
(W/'PRODUCT-FILES.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(out,ensure_ascii=False))
