# 客户单条评论人工纠错候选

仅候选，未安装。当前 stage / 生产客户数据保持不变。

原同源 HTTP POST `/api/workbench`，继续使用现有 Cookie、Origin、CSRF、员工登录、当前门店权限。

- `customer_intent_read`: `storeId, customerId, leadId, platform`；可选 `requestId` 查询原请求回执。
- `customer_intent_correct`: 上述 4 字段，加 `requestId, expectedVersion, sourceDigest, status, level, reason`；不收多余字段。
- `customer_intent_cancel`: 上述 4 字段，加 `requestId, requestDigest`；明确取消原结果未知的操作，不清除原键。
- `customerId` 是原客户 `author_key`；`leadId` 是该客户 `comments[].id` 的原始评论 ID。不能把聚合客户 ID 当评论 ID，不能用账号昵称匹配。
- `expectedVersion` / `sourceDigest` 均为读结果返回的 64 位十六进制摘要，客户端不得推导。前者绑定 AI / 人工判断状态，后者绑定原评论内容、平台、客户、原任务 / 门店 / 账号归属。
- `status`: `graded | uncertain | unrelated`。`graded` 的 `level`: `super_high | high | medium | low | very_low`；其他状态 level 必须为 null。
- `reason` 去首尾空白后 1–300 字；`requestId` 沿用现有 1–160 位字母数字 / 下划线 / 连字符形式。

返回：`{ok:true,intentCorrection:{actor:{username,storeId},scope:'single-comment',customerId,leadId,platform,version,sourceDigest,aiIntent,manualIntent,currentIntent,history,receipt},csrfToken}`。

`aiIntent/manualIntent/currentIntent` 为 null 或 `{status,level,reason,evidence?}`；manual 另有 `by`（员工 username）、`updatedAt`。未分析的 currentIntent 可以为 `{status:'pending',level:null}`。history 为 `{requestId,updatedAt,by,before,after}[]`，最近在前。

`receipt` 为 null、`{requestId,state:'not_found'}`、`{requestId,state:'saved',customerId,leadId,platform,storeId,version,sourceDigest,requestDigest}`，或 `{requestId,state:'cancelled',customerId,leadId,platform,storeId,requestDigest,cancelledAt}`。saved 的 version 是该次保存后版本；当前 version 可能因后来操作而改变。查询 receipt 必须仍在原员工、门店、客户、评论范围。

预提交校验 / 权限 / CAS / 事务回滚拒绝：明确 `mutation_committed:false`。写后范围变化：`INTENT_RESULT_UNCONFIRMED` 和 true。无法确定提交结果：同错误或未知错误，标志缺失 / null。不能因为 HTTP 4xx 就当作没保存。

查询 not_found 不代表可以新键重发：仍在内存中的原 payload 可以由用户明确选择后以原 requestId、同内容重试；刷新后只剩元数据则保留未知断点，不自动清除、不换键重发。相同 requestId 同内容重放返回原 receipt，不新增历史；同键不同内容拒绝。

新增明确恢复途径：提交前持久化 requestDigest（不保存 reason 正文）。用户明确取消时，服务端与原保存事务在同一个原请求 key 上原子竞争：原保存已成功则返回 saved；尚未保存则写入不可变 cancelled tombstone 和审计，永久阻止迟到的同 key 保存；重复取消返回原 receipt。只有确认 cancelled 后，UI 才能清除这个待确认断点并重新读取、新建更正；不能仅清 localStorage。取消过程中断仍先只读回查。旧断点没有 requestDigest 且没有原 payload 时不能安全取消；回查 saved / cancelled 可取得摘要，not_found 不提供猜测值。

摘要算法：取完整 correct 公共 payload，包含 4 个 BASE、requestId、expectedVersion、sourceDigest、status、level、reason，不含 requestDigest；reason 去首尾空白；所有键按字母升序；UTF-8 编码 JSON，无额外空白，非 ASCII 字符直接保留；SHA256 小写 hex。Python 等价 `json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)`；浏览器为排序键后的 `JSON.stringify` + `TextEncoder` + WebCrypto SHA-256。值只允许字符串和 level:null，不存在浮点数字规范化问题。附 DIGEST-VECTORS.json 供精确比对。

保存只改变选中评论的 manual_intent，同一客户其他评论不动，原 DeepSeek 结果原样保留；客户卡片的汇总意向可能仍由其他评论决定。保存后刷新列表 / 详情。按原 effective_intent，人工优先；原 AI 再分析自动排除人工修改的评论。

内部使用原 Core records SQLite，一个事务写 lead.manual_intent、不可变原回执 / 历史记录和 audit。仍由 BusinessExecutor 的 intent_correct → LocalAIWorkflow.correct 调用，新增受约束分支不启动平台连接 / 模型。无来源门店的历史记录暂时给准确“原评论尚未核实门店归属”提示，不推断或静默重标。

普通 AI 写回的末端新增同一原库事务 CAS：只在该条 lead 快照和来源摘要仍一致、仍无 manual_intent 时写入。两个 Core / 两个 SQLite 连接竞争时，人工先提交则迟到 AI 不覆盖；AI 先提交则人工旧 expectedVersion 被拒绝，用户重新读取后可修改；原 AI 历史保留。此保护不重发模型请求。
