"""Write only the sealed review receipt; no runtime or deployment activity."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
W=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
patch=json.loads((W/'PATCH-MANIFEST.json').read_text('utf-8'))
applied=json.loads((W/'PATCH-APPLY-RESULT.json').read_text('utf-8'))
assert applied['status']=='PASS' and applied['patchSha256']==patch['patchSha256']==sha(W/'integration.patch')
for row in patch['files']:assert sha(W/'candidate'/row['path'])==row['candidateSha256']
names=['BASELINE.json','CONTRACT.md','DIGEST-VECTORS.json','FINAL-FILES-SHA256.json','PATCH-MANIFEST.json',
       'PATCH-APPLY-RESULT.json','HANDOFF.md','test_final_review.py','test_native_http.py','test_intent_correction.py',
       'BEHAVIOR-RESULT.json','BEHAVIOR-VENDOR-RESULT.json','HTTP-RESULT.json','HTTP-VENDOR-RESULT.json',
       'FINAL-REVIEW-RESULT.json','FINAL-REVIEW-VENDOR-RESULT.json','finalize_delivery.py','verify_patch.py']
receipt={'status':'READY_FOR_ROOT_MERGE','sealedAt':datetime.now(timezone.utc).isoformat(),
    'ownership':'root may now merge minimal diff; this agent will not edit source further',
    'candidateFiles':len(patch['files']),'patchHunks':sum(row['hunks'] for row in patch['files']),
    'patchSha256':patch['patchSha256'],'tests':{'savedBehaviorPerVariant':18,'finalHttpGroupsPerVariant':6,'finalReviewPerVariant':5,'variants':['r55','vendor']},
    'evidence':{name:sha(W/name) for name in names},
    'stageWrites':0,'productionReadsOrWrites':0,'modelCalls':0,'platformCalls':0,
    'notVerified':['merged next frozen version','actual installed UI with correction candidate','real provider or platform'],
    'requiredRootWork':['merge 9 source files by hunk and retain independent v3 content pins',
        'recompute final Native/core/vendor provenance and dependency pins',
        'freeze a new version; never alter v66','validate final UI and newly loaded installed version']}
(W/'DELIVERY.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'deliverySha256':sha(W/'DELIVERY.json'),'patchSha256':patch['patchSha256']}))
